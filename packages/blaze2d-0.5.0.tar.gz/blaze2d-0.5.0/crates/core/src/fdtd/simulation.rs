//! FDTD simulation engine.
//!
//! This module implements the core FDTD time-stepping algorithm, combining
//! field storage, dielectric sampling, boundary conditions, and sources.
//!
//! # Algorithm Overview
//!
//! The FDTD algorithm uses a leapfrog time-stepping scheme where E and H
//! fields are updated at alternating half-time-steps:
//!
//! 1. H(n+½) = H(n-½) + (dt/μ) * curl(E(n))
//! 2. Apply PML corrections to H
//! 3. E(n+1) = E(n) + (dt/ε) * curl(H(n+½))
//! 4. Apply PML corrections to E
//! 5. Inject sources
//!
//! # 2D Maxwell Equations
//!
//! For TM mode (Ez, Hx, Hy):
//!   ∂Hx/∂t = -(1/μ) * ∂Ez/∂y
//!   ∂Hy/∂t = (1/μ) * ∂Ez/∂x
//!   ∂Ez/∂t = (1/ε) * (∂Hy/∂x - ∂Hx/∂y) - Jz/ε
//!
//! For TE mode (Hz, Ex, Ey):
//!   ∂Ex/∂t = (1/ε) * ∂Hz/∂y
//!   ∂Ey/∂t = -(1/ε) * ∂Hz/∂x  
//!   ∂Hz/∂t = (1/μ) * (∂Ex/∂y - ∂Ey/∂x) - Mz/μ

use crate::dielectric::{Dielectric2D, DielectricOptions};
use crate::geometry::Geometry2D;
use crate::grid::Grid2D;
use crate::polarization::Polarization;

use super::boundaries::{BoundaryConfig, BoundaryCondition};
use super::config::FdtdConfig;
use super::fields::{FieldComponent, YeeFields2D};
use super::output::FieldSnapshot;
use super::pml::{PmlParams, PmlRegion};
use super::sources::{Source, SourceComponent, SourceGeometry};
use super::yee_grid::YeeGrid2D;
use crate::profile_scope;

#[cfg(feature = "parallel")]
use rayon::prelude::*;

/// Main FDTD simulation structure.
pub struct FdtdSimulation {
    /// Configuration parameters
    config: FdtdConfig,
    /// Yee grid specification
    grid: YeeGrid2D,
    /// Electromagnetic fields
    fields: YeeFields2D,
    /// Sampled dielectric function
    dielectric: Dielectric2D,
    /// PML absorbing boundaries (if enabled)
    pml: Option<PmlRegion>,
    /// Boundary configuration
    boundaries: BoundaryConfig,
    /// List of sources
    sources: Vec<Source>,
    /// Current simulation time
    time: f64,
    /// Current time step number
    step: usize,
    /// Time step size
    dt: f64,
    /// Precomputed update coefficients
    update_coeffs: UpdateCoefficients,
}

/// Precomputed coefficients for field updates.
struct UpdateCoefficients {
    /// dt / (ε * dx) for E-field x-derivative terms
    dt_eps_dx: CoefficientMap,
    /// dt / (ε * dy) for E-field y-derivative terms
    dt_eps_dy: CoefficientMap,
    /// dt / dx for H-field x-derivative terms (assuming μ = 1)
    dt_dx: f64,
    /// dt / dy for H-field y-derivative terms
    dt_dy: f64,
}

/// Helper enum for spatially varying coefficients
enum CoefficientMap {
    /// Uniform coefficient across the grid
    Uniform(f64),
    /// Spatially varying coefficient
    Varying(Vec<f64>),
}

impl CoefficientMap {
    #[inline(always)]
    fn get(&self, idx: usize) -> f64 {
        match self {
            CoefficientMap::Uniform(val) => *val,
            CoefficientMap::Varying(vec) => unsafe { *vec.get_unchecked(idx) },
        }
    }
}

impl FdtdSimulation {
    /// Create a new FDTD simulation from geometry and configuration.
    pub fn new(geometry: Geometry2D, config: FdtdConfig) -> Self {
        let polarization = config.polarization;

        // Create Yee grid
        let grid = YeeGrid2D::from_dimensions(
            config.resolution_x(),
            config.resolution_y(),
            geometry.lattice.characteristic_length() * config.domain_size[0],
            geometry.lattice.characteristic_length() * config.domain_size[1],
        );

        // Compute time step from Courant condition
        let dt = grid.courant_dt(config.courant_factor);

        // Sample dielectric function
        let dielectric_opts = DielectricOptions::default();
        let base_grid = Grid2D::new(grid.nx(), grid.ny(), grid.lx(), grid.ly());
        let dielectric = Dielectric2D::from_geometry(&geometry, base_grid, &dielectric_opts);

        // Initialize fields
        let fields = YeeFields2D::zeros(grid.clone(), polarization);

        // Configure thread pool if parallel
        #[cfg(feature = "parallel")]
        {
            if config.use_parallel {
                // Only configure if RAYON_NUM_THREADS is not set
                if std::env::var("RAYON_NUM_THREADS").is_err() {
                     let physical_cores = num_cpus::get_physical();
                     // best effort initialization
                     let _ = rayon::ThreadPoolBuilder::new()
                         .num_threads(physical_cores)
                         .build_global();
                }
            }
        }

        // Set up boundaries
        let boundaries = config.boundaries.clone();

        // Create PML if needed
        let pml = if boundaries.has_pml_x() || boundaries.has_pml_y() {
            let pml_params = PmlParams::with_thickness(config.pml_thickness)
                .with_optimal_sigma(grid.dx().min(grid.dy()));
            let mut pml = PmlRegion::new(&grid, &pml_params, dt);
            // Disable PML on periodic boundaries
            if boundaries.is_periodic_x() {
                pml.disable_x();
            }
            if boundaries.is_periodic_y() {
                pml.disable_y();
            }
            Some(pml)
        } else {
            None
        };

        // Precompute update coefficients
        let update_coeffs = Self::compute_update_coefficients(&grid, &dielectric, dt);

        Self {
            config,
            grid,
            fields,
            dielectric,
            pml,
            boundaries,
            sources: Vec::new(),
            time: 0.0,
            step: 0,
            dt,
            update_coeffs,
        }
    }

    /// Compute update coefficients from dielectric.
    fn compute_update_coefficients(
        grid: &YeeGrid2D,
        dielectric: &Dielectric2D,
        dt: f64,
    ) -> UpdateCoefficients {
        let nx = grid.nx();
        let ny = grid.ny();
        let dx = grid.dx();
        let dy = grid.dy();

        let eps = dielectric.eps();
        
        // Helper to check uniformity
        let is_uniform = eps.iter().all(|&x| (x - eps[0]).abs() < 1e-12);

        let dt_eps_dx = if is_uniform {
            CoefficientMap::Uniform(dt / (eps[0] * dx))
        } else {
            let mut vec = vec![0.0; nx * ny];
             for iy in 0..ny {
                for ix in 0..nx {
                    let idx = iy * nx + ix;
                    vec[idx] = dt / (eps[idx] * dx);
                }
            }
            CoefficientMap::Varying(vec)
        };

        let dt_eps_dy = if is_uniform {
            CoefficientMap::Uniform(dt / (eps[0] * dy))
        } else {
            let mut vec = vec![0.0; nx * ny];
             for iy in 0..ny {
                for ix in 0..nx {
                    let idx = iy * nx + ix;
                    vec[idx] = dt / (eps[idx] * dy);
                }
            }
            CoefficientMap::Varying(vec)
        };

        UpdateCoefficients {
            dt_eps_dx,
            dt_eps_dy,
            dt_dx: dt / dx,
            dt_dy: dt / dy,
        }
    }

    // ========================================================================
    // Accessors
    // ========================================================================

    /// Get the current simulation time.
    pub fn time(&self) -> f64 {
        self.time
    }

    /// Get the current time step number.
    pub fn step(&self) -> usize {
        self.step
    }

    /// Get the time step size.
    pub fn dt(&self) -> f64 {
        self.dt
    }

    /// Get the Yee grid.
    pub fn grid(&self) -> &YeeGrid2D {
        &self.grid
    }

    /// Get the fields.
    pub fn fields(&self) -> &YeeFields2D {
        &self.fields
    }

    /// Get mutable fields.
    pub fn fields_mut(&mut self) -> &mut YeeFields2D {
        &mut self.fields
    }

    /// Get the dielectric function.
    pub fn dielectric(&self) -> &Dielectric2D {
        &self.dielectric
    }

    /// Get the polarization mode.
    pub fn polarization(&self) -> Polarization {
        self.config.polarization
    }

    // ========================================================================
    // Source management
    // ========================================================================

    /// Add a source to the simulation.
    pub fn add_source(&mut self, source: Source) {
        self.sources.push(source);
    }

    /// Clear all sources.
    pub fn clear_sources(&mut self) {
        self.sources.clear();
    }

    // ========================================================================
    // Time stepping
    // ========================================================================

    /// Perform a single time step.
    pub fn step_once(&mut self) {
        profile_scope!("FdtdSimulation::step_once");
        match self.config.polarization {
            Polarization::TE => self.step_te(),
            Polarization::TM => self.step_tm(),
        }
        self.time += self.dt;
        self.step += 1;
    }

    /// Run for a specified number of steps.
    pub fn run(&mut self, n_steps: usize) {
        profile_scope!("FdtdSimulation::run");
        for _ in 0..n_steps {
            self.step_once();
        }
    }

    /// Run until a specified time.
    pub fn run_until(&mut self, end_time: f64) {
        profile_scope!("FdtdSimulation::run_until");
        while self.time < end_time {
            self.step_once();
        }
    }

    // ========================================================================
    // TE mode update (Hz, Ex, Ey)
    // ========================================================================

    fn step_te(&mut self) {
        profile_scope!("FdtdSimulation::step_te");
        // Step 1: Update H field (Hz)
        self.update_hz();

        // Step 2: Update E fields (Ex, Ey) fused
        // self.update_ex();
        // self.update_ey();
        self.update_e_te_fused();
        
        // Step 4: Apply boundary conditions
        self.apply_boundaries_te();

        // Step 5: Inject sources
        self.inject_sources();
    }

    fn update_e_te_fused(&mut self) {
        profile_scope!("FdtdSimulation::update_e_te_fused");
        let nx = self.grid.nx();
        let ny = self.grid.ny();
        let dt_eps_dx = &self.update_coeffs.dt_eps_dx;
        let dt_eps_dy = &self.update_coeffs.dt_eps_dy;

        let is_periodic_x = self.boundaries.is_periodic_x();
        let is_periodic_y = self.boundaries.is_periodic_y();

        // Use split_all_mut to get references without cloning
        let (hz_field, ex_field, ey_field) = self.fields.split_all_mut();
        let hz = hz_field.as_slice();
        let ex = ex_field.as_mut_slice();
        let ey = ey_field.as_mut_slice();

        // Need to fuse update_ex and update_ey.
        // update_ex: Ex[i,j] += coeff_y[i,j] * (Hz[i,j] - Hz[i,j-1])
        // update_ey: Ey[i,j] -= coeff_x[i,j] * (Hz[i,j] - Hz[i-1,j])

        // Loop fusion strategy:
        // Iterate iy=0..ny.
        //   Inside, iterate ix=0..nx.
        //   We need access to:
        //     Hz[iy, ix]     (Current)
        //     Hz[iy-1, ix]   (Prev Row - for Ex)
        //     Hz[iy, ix-1]   (Prev Col - for Ey)
        
        // 1. Handle iy=0 (Top/Bottom boundary)
        // Ex needs Hz[0, ix] - Hz[-1, ix]. If periodic, Hz[-1] is Hz[ny-1].
        // Ey needs Hz[0, ix] - Hz[0, ix-1]. (Same row).
        
        {
            let iy = 0;
            let offset = 0;
            // Ex update at iy=0
            if is_periodic_y {
                let hz_curr_row = &hz[0..nx];
                let hz_prev_row = &hz[(ny-1)*nx..ny*nx]; 
                let ex_row = &mut ex[0..nx];
                let coeff_row = match dt_eps_dy {
                    CoefficientMap::Uniform(c) => *c,
                    CoefficientMap::Varying(v) => v[0], // Simplified access for now? Or handle fullvarying.
                };
                // Handle Varying properly
                 match dt_eps_dy {
                     CoefficientMap::Uniform(c) => {
                         let c = *c;
                         for ix in 0..nx { ex_row[ix] += (c * ((hz_curr_row[ix] as f64) - (hz_prev_row[ix] as f64))) as f32; }
                     }
                     CoefficientMap::Varying(coeffs) => {
                         let coeff_row = &coeffs[0..nx];
                         for ix in 0..nx { ex_row[ix] += (coeff_row[ix] * ((hz_curr_row[ix] as f64) - (hz_prev_row[ix] as f64))) as f32; }
                     }
                 }
            }
            
            // Ey update at iy=0
            let ey_row = &mut ey[0..nx];
            let hz_row = &hz[0..nx];
            // Handle ix=0 (boundary)
            if is_periodic_x {
                let dhz_dx = (hz_row[0] as f64) - (hz_row[nx-1] as f64);
                let c = match dt_eps_dx { CoefficientMap::Uniform(c) => *c, CoefficientMap::Varying(v) => v[0] };
                ey_row[0] -= (c * dhz_dx) as f32;
            }
            // Handle ix=1..nx
            match dt_eps_dx {
                CoefficientMap::Uniform(c) => {
                    let c = *c;
                     for ix in 1..nx {
                        let dhz_dx = (hz_row[ix] as f64) - (hz_row[ix-1] as f64);
                        ey_row[ix] -= (c * dhz_dx) as f32;
                    }
                }
                CoefficientMap::Varying(coeffs) => {
                    let coeff_row = &coeffs[0..nx];
                     for ix in 1..nx {
                        let dhz_dx = (hz_row[ix] as f64) - (hz_row[ix-1] as f64);
                        ey_row[ix] -= (coeff_row[ix] * dhz_dx) as f32;
                    }
                }
            }
        }
        
        // 2. Main Loop: iy = 1..ny
        #[cfg(feature = "parallel")]
        let use_parallel = self.config.use_parallel;
        #[cfg(not(feature = "parallel"))]
        let use_parallel = false;

        if use_parallel {
             #[cfg(feature = "parallel")]
             {
                 // Tiling Constants
                 const BLOCK_X: usize = 512;
                 const CHUNK_Y: usize = 32;
                 
                 // Slice mutable fields starting from row 1
                 let ex_slice = &mut ex[nx..];
                 let ey_slice = &mut ey[nx..];
                 // Hz is captured as full slice (read-only)
                 
                 match (dt_eps_dx, dt_eps_dy) {
                     (CoefficientMap::Uniform(cx), CoefficientMap::Uniform(cy)) => {
                         let cx = *cx;
                         let cy = *cy;
                         
                         ex_slice.par_chunks_mut(nx * CHUNK_Y)
                            .zip(ey_slice.par_chunks_mut(nx * CHUNK_Y))
                            .enumerate()
                            .for_each(|(chunk_idx, (ex_chunk, ey_chunk))| {
                                let rows_in_chunk = ex_chunk.len() / nx;
                                let j_start = 1 + chunk_idx * CHUNK_Y; // Absolute row index
                                
                                // Iterate Block X
                                for bx in (0..nx).step_by(BLOCK_X) {
                                    // Skip ix=0 if bx=0
                                    let bx_start = if bx == 0 { 1 } else { bx };
                                    let b_end = (bx + BLOCK_X).min(nx);
                                    
                                    // Iterate Rows in Chunk (Strip)
                                    for r in 0..rows_in_chunk {
                                        let iy = j_start + r;
                                        
                                        // Pointers/Slices
                                        let offset = r * nx; // Offset in CHUNK
                                        let ex_row = &mut ex_chunk[offset..];
                                        let ey_row = &mut ey_chunk[offset..];
                                        
                                        // Global Hz Access
                                        let hz_curr_offset = iy * nx;
                                        let hz_prev_offset = (iy - 1) * nx;
                                        let hz_curr = &hz[hz_curr_offset..];
                                        let hz_prev = &hz[hz_prev_offset..];
                                        
                                        // Update Loop (Vectorized)
                                        for ix in bx_start..b_end {
                                            let dhz_dy = (hz_curr[ix] as f64) - (hz_prev[ix] as f64);
                                            ex_row[ix] += (cy * dhz_dy) as f32;
                                            
                                            let dhz_dx = (hz_curr[ix] as f64) - (hz_curr[ix-1] as f64);
                                            ey_row[ix] -= (cx * dhz_dx) as f32;
                                        }
                                        
                                        // Handle ix=0 separately? 
                                        // Wait, the original code handled ix=0 boundary for Ey inside the loop or separately.
                                        // Loop 1..nx skips ix=0.
                                        // We should handle ix=0 separately or inside Block 0.
                                        // Block 0 usually starts at 0.
                                        // But loop is 1..nx.
                                        // So ix=0 is handled outside this loop.
                                    }
                                }
                                
                                // Handle ix=0 for all rows in this chunk
                                if is_periodic_x {
                                    for r in 0..rows_in_chunk {
                                        let iy = j_start + r;
                                        
                                        // We need Ex(iy, 0) and Ey(iy, 0)
                                        let row_chunk_offset = r * nx;
                                        let hz_offset = iy * nx;
                                        
                                        let dhz_dx = (hz[hz_offset] as f64) - (hz[hz_offset + nx - 1] as f64); // wrap
                                        ey_chunk[row_chunk_offset] -= (cx * dhz_dx) as f32;
                                    }
                                }
                                // ix=0 Ex is always updated (no X-dependence for Ex, only Y)
                                for r in 0..rows_in_chunk {
                                    let iy = j_start + r;
                                    let row_chunk_offset = r * nx;
                                    let hz_curr_offset = iy * nx;
                                    let hz_prev_offset = (iy - 1) * nx;
                                    
                                    // Ex[0] += cy * (Hz[0,0] - Hz[-1,0])
                                    let dhz_dy = (hz[hz_curr_offset] as f64) - (hz[hz_prev_offset] as f64);
                                    ex_chunk[row_chunk_offset] += (cy * dhz_dy) as f32;
                                }
                            });
                     }
                     // Fallback for varying
                     (CoefficientMap::Varying(vx), CoefficientMap::Varying(vy)) => {
                        ex_slice.par_chunks_mut(nx * CHUNK_Y)
                            .zip(ey_slice.par_chunks_mut(nx * CHUNK_Y))
                            .enumerate()
                            .for_each(|(chunk_idx, (ex_chunk, ey_chunk))| {
                                let rows_in_chunk = ex_chunk.len() / nx;
                                let j_start = 1 + chunk_idx * CHUNK_Y;

                                for bx in (0..nx).step_by(BLOCK_X) {
                                    let bx_start = if bx == 0 { 1 } else { bx };
                                    let b_end = (bx + BLOCK_X).min(nx);

                                    for r in 0..rows_in_chunk {
                                        let iy = j_start + r;
                                        let offset = r * nx;
                                        let ex_row = &mut ex_chunk[offset..];
                                        let ey_row = &mut ey_chunk[offset..];
                                        
                                        let global_offset = iy * nx;
                                        let c_dx = &vx[global_offset..];
                                        let c_dy = &vy[global_offset..];
                                        let hz_curr = &hz[global_offset..];
                                        let hz_prev = &hz[(iy-1)*nx..];

                                        for ix in bx_start..b_end {
                                            let dhz_dy = (hz_curr[ix] as f64) - (hz_prev[ix] as f64);
                                            ex_row[ix] += (c_dy[ix] * dhz_dy) as f32;
                                            
                                            let dhz_dx = (hz_curr[ix] as f64) - (hz_curr[ix-1] as f64);
                                            ey_row[ix] -= (c_dx[ix] * dhz_dx) as f32;
                                        }
                                    }
                                }
                                
                                // Boundaries ix=0
                                if is_periodic_x {
                                    for r in 0..rows_in_chunk {
                                        let iy = j_start + r;
                                        let global_offset = iy * nx;
                                        let dhz_dx = (hz[global_offset] as f64) - (hz[global_offset + nx - 1] as f64);
                                        ey_chunk[r*nx] -= (vx[global_offset] * dhz_dx) as f32;
                                    }
                                }
                                for r in 0..rows_in_chunk {
                                    let iy = j_start + r;
                                    let global_offset = iy * nx;
                                    let dhz_dy = (hz[global_offset] as f64) - (hz[(iy-1)*nx] as f64);
                                    ex_chunk[r*nx] += (vy[global_offset] * dhz_dy) as f32;
                                }
                            });
                     }
                     _ => {
                         // Mixed cases (rare) - Fallback to simple parallel
                         // Or implement similar tiling with mixed lookups
                     }
                 }
             }
        } else {
             // Serial loop fusion - optimized dispatch
             match (dt_eps_dx, dt_eps_dy) {
                 (CoefficientMap::Uniform(cx), CoefficientMap::Uniform(cy)) => {
                     let cx = *cx;
                     let cy = *cy;
                     for iy in 1..ny {
                        let offset = iy * nx;
                        // Fast direct access
                        // We rely on simple loops for auto-vectorization
                        
                        let ex_row = &mut ex[offset..];
                        let ey_row = &mut ey[offset..];
                        let hz_curr = &hz[offset..];
                        #[allow(unused_variables)]
                        let hz_prev = &hz[offset-nx..];
                        
                        // ix=0 boundary
                        if is_periodic_x {
                            let dhz_dx = (hz_curr[0] as f64) - (hz_curr[nx-1] as f64);
                            ey_row[0] -= (cx * dhz_dx) as f32;
                        }
                        let dhz_dy = (hz_curr[0] as f64) - (hz_prev[0] as f64);
                        ex_row[0] += (cy * dhz_dy) as f32;

                        // Main vector loop: 1..nx
                        // Depending on compiler, we might want to split into two loops to avoid mixing ex/ey writes if aliasing is suspected
                        // But these are distinct slices from split_all_mut.
                        for ix in 1..nx {
                             let dhz_dx = (hz_curr[ix] as f64) - (hz_curr[ix-1] as f64);
                             ey_row[ix] -= (cx * dhz_dx) as f32;
                             
                             let dhz_dy = (hz_curr[ix] as f64) - (hz_prev[ix] as f64);
                             ex_row[ix] += (cy * dhz_dy) as f32;
                        }
                     }
                 },
                 (CoefficientMap::Varying(vx), CoefficientMap::Varying(vy)) => {
                     for iy in 1..ny {
                        let offset = iy * nx;
                        let ex_row = &mut ex[offset..offset+nx];
                        let ey_row = &mut ey[offset..offset+nx];
                        let hz_curr = &hz[offset..offset+nx];
                        let hz_prev = &hz[offset-nx..offset];
                        
                        let cx_row = &vx[offset..offset+nx];
                        let cy_row = &vy[offset..offset+nx];

                         if is_periodic_x {
                            let dhz_dx = (hz_curr[0] as f64) - (hz_curr[nx-1] as f64);
                            ey_row[0] -= (cx_row[0] * dhz_dx) as f32;
                        }
                        let dhz_dy_0 = (hz_curr[0] as f64) - (hz_prev[0] as f64);
                        ex_row[0] += (cy_row[0] * dhz_dy_0) as f32;

                        for ix in 1..nx {
                            let dhz_dx = (hz_curr[ix] as f64) - (hz_curr[ix-1] as f64);
                            ey_row[ix] -= (cx_row[ix] * dhz_dx) as f32;
                            
                            let dhz_dy = (hz_curr[ix] as f64) - (hz_prev[ix] as f64);
                            ex_row[ix] += (cy_row[ix] * dhz_dy) as f32;
                        }
                     }
                 },
                 (CoefficientMap::Uniform(cx), CoefficientMap::Varying(vy)) => {
                     let cx = *cx;
                     for iy in 1..ny {
                        let offset = iy * nx;
                        let ex_row = &mut ex[offset..offset+nx];
                        let ey_row = &mut ey[offset..offset+nx];
                        let hz_curr = &hz[offset..offset+nx];
                        let hz_prev = &hz[offset-nx..offset];
                        let cy_row = &vy[offset..offset+nx];

                         if is_periodic_x {
                            let dhz_dx = hz_curr[0] as f64 - hz_curr[nx-1] as f64;
                            ey_row[0] -= (cx * dhz_dx) as f32;
                        }
                        let dhz_dy_0 = hz_curr[0] as f64 - hz_prev[0] as f64;
                        ex_row[0] += (cy_row[0] * dhz_dy_0) as f32;

                        for ix in 1..nx {
                            let dhz_dx = hz_curr[ix] as f64 - hz_curr[ix-1] as f64;
                            ey_row[ix] -= (cx * dhz_dx) as f32;
                            let dhz_dy = hz_curr[ix] as f64 - hz_prev[ix] as f64;
                            ex_row[ix] += (cy_row[ix] * dhz_dy) as f32;
                        }
                     }
                 },
                 (CoefficientMap::Varying(vx), CoefficientMap::Uniform(cy)) => {
                     let cy = *cy;
                     for iy in 1..ny {
                        let offset = iy * nx;
                        let ex_row = &mut ex[offset..offset+nx];
                        let ey_row = &mut ey[offset..offset+nx];
                        let hz_curr = &hz[offset..offset+nx];
                        let hz_prev = &hz[offset-nx..offset];
                        let cx_row = &vx[offset..offset+nx];

                         if is_periodic_x {
                            let dhz_dx = hz_curr[0] as f64 - hz_curr[nx-1] as f64;
                            ey_row[0] -= (cx_row[0] * dhz_dx) as f32;
                        }
                        let dhz_dy_0 = hz_curr[0] as f64 - hz_prev[0] as f64;
                        ex_row[0] += (cy * dhz_dy_0) as f32;

                        for ix in 1..nx {
                            let dhz_dx = hz_curr[ix] as f64 - hz_curr[ix-1] as f64;
                            ey_row[ix] -= (cx_row[ix] * dhz_dx) as f32;
                            let dhz_dy = hz_curr[ix] as f64 - hz_prev[ix] as f64;
                            ex_row[ix] += (cy * dhz_dy) as f32;
                        }
                     }
                 }
             }
        }
    }

    fn update_hz(&mut self) {
        profile_scope!("FdtdSimulation::update_hz");
        let nx = self.grid.nx();
        let ny = self.grid.ny();
        let dt_dx = self.update_coeffs.dt_dx;
        let dt_dy = self.update_coeffs.dt_dy;

        let is_periodic_x = self.boundaries.is_periodic_x();
        let is_periodic_y = self.boundaries.is_periodic_y();

        // Borrow fields mutably together to avoid cloning
        let (hz_field, ex_field, ey_field) = self.fields.split_all_mut();
        
        let hz = hz_field.as_mut_slice();
        let ex = ex_field.as_slice();
        let ey = ey_field.as_slice();

        // SIMD-friendly loop
        // We iterate 0..ny and 0..nx.
        // To maximize performance, handle inner part (no boundary check) and boundaries separately.
        
        // Inner blocks: 1..ny-1, 1..nx-1 (assuming no periodic checks needed there)
        // Actually, periodic checks are at iy=ny-1 and ix=nx-1.
        
        // Optimization: Use `for` loops with unchecked indexing or slices for the bulk 
        // and handle edges separately.
        
        // Using slices for the main body 0..ny-1 (if periodic y) or 0..ny-1 (if not periodic y)
        // If not periodic Y, iy=ny-1 simply has dex_dy = 0 (logic: "continue" means skip update?)
        // The original logic:
        // if iy + 1 < ny { iy + 1 } else if periodic { 0 } else { continue }
        // If continue, that means we DON'T update Hz at the boundary? 
        // Wait, standard Yee cell: Hz is at (i+0.5, j+0.5).
        // Ex is at (i+0.5, j). Ey is at (i, j+0.5).
        // Hz(i,j) depends on Ex(i,j+1)-Ex(i,j) and Ey(i+1,j)-Ey(i,j).
        // If j=ny-1, we need Ex(i, ny) which is outside.
        // If periodic, Ex(i, ny) -> Ex(i, 0).
        // If restricted (PEC/PMC/ABC), we either have ghost cells or don't update derivative.
        
        // Faster logic:
        // iterate iy from 0 to ny-1.
        //   iterate ix from 0 to nx-1.
        //     calculate indices.
        
        // Fast Iteration Strategy:
        // 1. Loop 0..ny-1
        //    2. Loop 0..nx-1
        //       Compute without checks.
        // 3. Handle last row/col separately.

        // Pre-slice coefficient arrays if they were arrays (here scalars).
        
        // Tiling optimization:
        // By processing small blocks of X (width < L1 size), we ensure that 
        // the "next row" accessed here remains in L1 when it becomes the "current row" 
        // in the next iy iteration.
        // N=2048 (16KB/row). L1=32KB. 3 arrays read/write -> we spill if we stream full rows.
        
        const BLOCK_X: usize = 256; // 2KB doubles, fits easily in L1 along with others
        // const CHUNK_Y: usize = 32; // Unused in Serial path

        #[cfg(feature = "parallel")]
        let use_parallel = self.config.use_parallel;
        #[cfg(not(feature = "parallel"))]
        let use_parallel = false;

        let n_rows_bulk = ny - 1;

        if use_parallel {
            #[cfg(feature = "parallel")]
            {
               // Simplified Parallel logic (just strip mining for now, full tiling later)
               // Parallelize outer chunks of Y.
               hz.par_chunks_mut(nx).take(n_rows_bulk)
                   .zip(ex.par_chunks(nx).take(n_rows_bulk))
                   .zip(ex.par_chunks(nx).skip(1).take(n_rows_bulk))
                   .zip(ey.par_chunks(nx).take(n_rows_bulk))
                   .for_each(|(((hz_row, ex_curr), ex_next), ey_row)| {
                       // We can block X here inside the thread
                       for bx in (0..nx-1).step_by(BLOCK_X) {
                           let b_end = (bx + BLOCK_X).min(nx - 1);
                           for ix in bx..b_end {
                               let dex_dy = (ex_next[ix] as f64) - (ex_curr[ix] as f64);
                               let dey_dx = (ey_row[ix+1] as f64) - (ey_row[ix] as f64);
                               hz_row[ix] += (dt_dy * dex_dy - dt_dx * dey_dx) as f32;
                           }
                       }
                       // last col
                       let ix = nx - 1;
                       let dex_dy = (ex_next[ix] as f64) - (ex_curr[ix] as f64);
                       if is_periodic_x {
                            let dey_dx = (ey_row[0] as f64) - (ey_row[ix] as f64);
                            hz_row[ix] += (dt_dy * dex_dy - dt_dx * dey_dx) as f32;
                       }
                   });
            }
        } else {
            // Serial (Linear Processing - Prefetcher Friendly)
            for iy in 0..n_rows_bulk {
                let offset = iy * nx;
                let next_offset = offset + nx;
                
                let hz_row = &mut hz[offset..];
                let ex_curr = &ex[offset..];
                let ex_next = &ex[next_offset..];
                let ey_row = &ey[offset..];
                
                // Main loop
                for ix in 0..nx-1 {
                    let dex_dy = (ex_next[ix] as f64) - (ex_curr[ix] as f64);
                    let dey_dx = (ey_row[ix+1] as f64) - (ey_row[ix] as f64);
                    hz_row[ix] += (dt_dy * dex_dy - dt_dx * dey_dx) as f32;
                }
                
                // Boundary ix=nx-1
                if is_periodic_x {
                    let ix = nx - 1;
                    let dex_dy = (ex_next[ix] as f64) - (ex_curr[ix] as f64);
                    let dey_dx = (ey[offset] as f64) - (ey[offset + ix] as f64); // wrap 
                    hz_row[ix] += (dt_dy * dex_dy - dt_dx * dey_dx) as f32;
                }
            }
        }
        
        // Handle last row (iy = ny-1)
        {
            let iy = ny - 1;
            let offset = iy * nx;
            let hz_row = &mut hz[offset..offset+nx];
            let ex_curr = &ex[offset..offset+nx];
            let ey_row = &ey[offset..offset+nx];
            
            // To get Ex(i, j+1), we need j+1=ny.
            if is_periodic_y {
                let next_offset = 0; // wrap to iy=0
                let ex_next = &ex[next_offset..next_offset+nx];
                
                // Inner X (0..nx-1)
                for ix in 0..nx-1 {
                    let dex_dy = (ex_next[ix] as f64) - (ex_curr[ix] as f64);
                    let dey_dx = (ey_row[ix+1] as f64) - (ey_row[ix] as f64);
                    hz_row[ix] += (dt_dy * dex_dy - dt_dx * dey_dx) as f32;
                }
                
                // Corner (nx-1, ny-1)
                let ix = nx - 1;
                let dex_dy = (ex_next[ix] as f64) - (ex_curr[ix] as f64);
                if is_periodic_x {
                    let dey_dx = (ey[offset] as f64) - (ey_row[ix] as f64);
                    hz_row[ix] += (dt_dy * dex_dy - dt_dx * dey_dx) as f32;
                }
            } else {
                // Boundary: skip update
            }
        }
    }

    fn update_ex(&mut self) {
        let nx = self.grid.nx();
        let ny = self.grid.ny();
        let dt_eps_dy = &self.update_coeffs.dt_eps_dy;

        let is_periodic_y = self.boundaries.is_periodic_y();

        // Use split_all_mut to get references without cloning
        let (hz_field, ex_field, _) = self.fields.split_all_mut();
        let hz = hz_field.as_slice();
        let ex = ex_field.as_mut_slice();

        // Optimization: Loop separation to avoid if inside loop
        
        // 1. Handle iy=0 (Boundary condition)
        if is_periodic_y {
            let hz_curr = &hz[0..nx];
            let hz_prev = &hz[(ny-1)*nx..ny*nx]; // Wrap to last row
            let ex_row = &mut ex[0..nx];
            
            match dt_eps_dy {
                CoefficientMap::Uniform(c) => {
                    for ix in 0..nx {
                        let dhz_dy = hz_curr[ix] as f64 - hz_prev[ix] as f64;
                        ex_row[ix] += (c * dhz_dy) as f32;
                    }
                }
                CoefficientMap::Varying(coeffs) => {
                    let coeff_row = &coeffs[0..nx];
                    for ix in 0..nx {
                        let dhz_dy = hz_curr[ix] as f64 - hz_prev[ix] as f64;
                        ex_row[ix] += (coeff_row[ix] * dhz_dy) as f32;
                    }
                }
            }
        }
        
        // 2. Main Loop: iy = 1..ny
        #[cfg(feature = "parallel")]
        let use_parallel = self.config.use_parallel;
        #[cfg(not(feature = "parallel"))]
        let use_parallel = false;

        if use_parallel {
            #[cfg(feature = "parallel")]
            match dt_eps_dy {
                CoefficientMap::Uniform(c) => {
                     ex.par_chunks_mut(nx).skip(1)
                    .zip(hz.par_chunks(nx).skip(1))
                    .zip(hz.par_chunks(nx))
                    .for_each(|((ex_row, hz_curr), hz_prev)| {
                        for ix in 0..nx {
                            let dhz_dy = hz_curr[ix] as f64 - hz_prev[ix] as f64;
                            ex_row[ix] += (c * dhz_dy) as f32;
                        }
                    });
                }
                CoefficientMap::Varying(coeffs) => {
                     ex.par_chunks_mut(nx).skip(1)
                    .zip(hz.par_chunks(nx).skip(1))
                    .zip(hz.par_chunks(nx))
                    .zip(coeffs.par_chunks(nx).skip(1))
                    .for_each(|(((ex_row, hz_curr), hz_prev), coeff_row)| {
                        for ix in 0..nx {
                            let dhz_dy = hz_curr[ix] as f64 - hz_prev[ix] as f64;
                            ex_row[ix] += (coeff_row[ix] * dhz_dy) as f32;
                        }
                    });
                }
            }
        } else {
            //    ∂Hz/∂y ≈ (Hz[i,j] - Hz[i,j-1]) / dy
            match dt_eps_dy {
                CoefficientMap::Uniform(c) => {
                    for iy in 1..ny {
                        let offset = iy * nx;
                        let prev_offset = offset - nx;
                        
                        let ex_row = &mut ex[offset..offset+nx];
                        let hz_curr = &hz[offset..offset+nx];
                        let hz_prev = &hz[prev_offset..prev_offset+nx];
                        
                        for ix in 0..nx {
                            let dhz_dy = hz_curr[ix] as f64 - hz_prev[ix] as f64;
                            ex_row[ix] += (c * dhz_dy) as f32;
                        }
                    }
                }
                CoefficientMap::Varying(coeffs) => {
                    for iy in 1..ny {
                        let offset = iy * nx;
                        let prev_offset = offset - nx;
                        
                        let ex_row = &mut ex[offset..offset+nx];
                        let hz_curr = &hz[offset..offset+nx];
                        let hz_prev = &hz[prev_offset..prev_offset+nx];
                        let coeff_row = &coeffs[offset..offset+nx];
                        
                        for ix in 0..nx {
                            let dhz_dy = hz_curr[ix] as f64 - hz_prev[ix] as f64;
                            ex_row[ix] += (coeff_row[ix] * dhz_dy) as f32;
                        }
                    }
                }
            }
        }
    }

    fn update_ey(&mut self) {
        let nx = self.grid.nx();
        let ny = self.grid.ny();
        let dt_eps_dx = &self.update_coeffs.dt_eps_dx;

        let is_periodic_x = self.boundaries.is_periodic_x();

        let (hz_field, _, ey_field) = self.fields.split_all_mut();
        let hz = hz_field.as_slice();
        let ey = ey_field.as_mut_slice();

        // Loop iy: 0..ny
        #[cfg(feature = "parallel")]
        let use_parallel = self.config.use_parallel;
        #[cfg(not(feature = "parallel"))]
        let use_parallel = false;

        if use_parallel {
            #[cfg(feature = "parallel")]
             match dt_eps_dx {
                CoefficientMap::Uniform(c) => {
                    ey.par_chunks_mut(nx)
                    .zip(hz.par_chunks(nx))
                    .for_each(|(ey_row, hz_row)| {
                        // 1. Handle ix=0 (Boundary)
                        if is_periodic_x {
                            let dhz_dx = hz_row[0] as f64 - hz_row[nx-1] as f64;
                            ey_row[0] -= (c * dhz_dx) as f32;
                        }
                        
                        // 2. Main Loop: ix = 1..nx
                        for ix in 1..nx {
                            let dhz_dx = hz_row[ix] as f64 - hz_row[ix-1] as f64;
                            ey_row[ix] -= (c * dhz_dx) as f32;
                        }
                    });
                }
                CoefficientMap::Varying(coeffs) => {
                    ey.par_chunks_mut(nx)
                    .zip(hz.par_chunks(nx))
                    .zip(coeffs.par_chunks(nx))
                    .for_each(|((ey_row, hz_row), coeff_row)| {
                        // 1. Handle ix=0 (Boundary)
                        if is_periodic_x {
                            let dhz_dx = hz_row[0] as f64 - hz_row[nx-1] as f64;
                            ey_row[0] -= (coeff_row[0] * dhz_dx) as f32;
                        }
                        
                        // 2. Main Loop: ix = 1..nx
                        for ix in 1..nx {
                            let dhz_dx = hz_row[ix] as f64 - hz_row[ix-1] as f64;
                            ey_row[ix] -= (coeff_row[ix] * dhz_dx) as f32;
                        }
                    });
                }
             }
        } else {
            match dt_eps_dx {
                CoefficientMap::Uniform(c) => {
                    for iy in 0..ny {
                        let offset = iy * nx;
                        let ey_row = &mut ey[offset..offset+nx];
                        let hz_row = &hz[offset..offset+nx]; 
                        
                        // 1. Handle ix=0 (Boundary)
                        if is_periodic_x {
                            let dhz_dx = hz_row[0] as f64 - hz_row[nx-1] as f64;
                            ey_row[0] -= (c * dhz_dx) as f32;
                        }
                        
                        // 2. Main Loop: ix = 1..nx
                        for ix in 1..nx {
                            let dhz_dx = hz_row[ix] as f64 - hz_row[ix-1] as f64;
                            ey_row[ix] -= (c * dhz_dx) as f32;
                        }
                    }
                }
                CoefficientMap::Varying(coeffs) => {
                    for iy in 0..ny {
                        let offset = iy * nx;
                        let ey_row = &mut ey[offset..offset+nx];
                        let hz_row = &hz[offset..offset+nx];
                        let coeff_row = &coeffs[offset..offset+nx];
                        
                        // 1. Handle ix=0 (Boundary)
                        if is_periodic_x {
                            // ix=0, prev=nx-1
                            let dhz_dx = hz_row[0] as f64 - hz_row[nx-1] as f64;
                            ey_row[0] -= (coeff_row[0] * dhz_dx) as f32;
                        }
                        
                        // 2. Main Loop: ix = 1..nx
                        //    ∂Hz/∂x ≈ (Hz[i,j] - Hz[i-1,j]) / dx
                        for ix in 1..nx {
                            let dhz_dx = hz_row[ix] as f64 - hz_row[ix-1] as f64;
                            ey_row[ix] -= (coeff_row[ix] * dhz_dx) as f32;
                        }
                    }
                }
            }
        }
    }

    fn apply_boundaries_te(&mut self) {
        let nx = self.grid.nx();
        let ny = self.grid.ny();

        // Apply PEC/PMC boundary conditions
        // PEC: tangential E = 0
        // PMC: tangential H = 0

        if self.boundaries.x_lo.condition == BoundaryCondition::Pec {
            // Ey = 0 at x = 0
            let ey = self.fields.secondary_y_mut().as_mut_slice();
            for iy in 0..ny {
                ey[iy * nx] = 0.0;
            }
        }
        if self.boundaries.x_hi.condition == BoundaryCondition::Pec {
            let ey = self.fields.secondary_y_mut().as_mut_slice();
            for iy in 0..ny {
                ey[iy * nx + nx - 1] = 0.0;
            }
        }
        if self.boundaries.y_lo.condition == BoundaryCondition::Pec {
            let ex = self.fields.secondary_x_mut().as_mut_slice();
            for ix in 0..nx {
                ex[ix] = 0.0;
            }
        }
        if self.boundaries.y_hi.condition == BoundaryCondition::Pec {
            let ex = self.fields.secondary_x_mut().as_mut_slice();
            for ix in 0..nx {
                ex[(ny - 1) * nx + ix] = 0.0;
            }
        }
    }

    // ========================================================================
    // TM mode update (Ez, Hx, Hy)
    // ========================================================================

    fn step_tm(&mut self) {
        // Step 1: Update H fields (Hx, Hy)
        // ∂Hx/∂t = -(1/μ) * ∂Ez/∂y
        // ∂Hy/∂t = (1/μ) * ∂Ez/∂x
        self.update_hx();
        self.update_hy();

        // Step 2: Update E field (Ez)
        // ∂Ez/∂t = (1/ε) * (∂Hy/∂x - ∂Hx/∂y)
        self.update_ez();

        // Step 3: Apply boundary conditions
        self.apply_boundaries_tm();

        // Step 4: Inject sources
        self.inject_sources();
    }

    fn update_hx(&mut self) {
        let nx = self.grid.nx();
        let ny = self.grid.ny();
        let dt_dy = self.update_coeffs.dt_dy;

        let is_periodic_y = self.boundaries.is_periodic_y();

        let (ez_field, hx_field, _) = self.fields.split_all_mut();
        let ez = ez_field.as_slice();
        let hx = hx_field.as_mut_slice();

        // Loop iy: 0..ny-1
        #[cfg(feature = "parallel")]
        let use_parallel = self.config.use_parallel;
        #[cfg(not(feature = "parallel"))]
        let use_parallel = false;

        if use_parallel {
            #[cfg(feature = "parallel")]
            {
                let n_rows = ny - 1;
                hx.par_chunks_mut(nx).take(n_rows)
                    .zip(ez.par_chunks(nx).take(n_rows))
                    .zip(ez.par_chunks(nx).skip(1).take(n_rows))
                    .for_each(|((hx_row, ez_curr), ez_next)| {
                        for ix in 0..nx {
                            let dez_dy = (ez_next[ix] as f64) - (ez_curr[ix] as f64);
                            hx_row[ix] -= (dt_dy * dez_dy) as f32;
                        }
                    });
            }
        } else {
            for iy in 0..ny-1 {
                let offset = iy * nx;
                let hx_row = &mut hx[offset..offset+nx];
                let ez_curr = &ez[offset..offset+nx];
                let ez_next = &ez[offset+nx..offset+2*nx];

                for ix in 0..nx {
                    let dez_dy = (ez_next[ix] as f64) - (ez_curr[ix] as f64);
                    hx_row[ix] -= (dt_dy * dez_dy) as f32;
                }
            }
        }

        // Handle last row (iy = ny-1)
        {
            let iy = ny - 1;
            let offset = iy * nx;
            let hx_row = &mut hx[offset..offset+nx];
            let ez_curr = &ez[offset..offset+nx];
            
            if is_periodic_y {
                let ez_next = &ez[0..nx]; // Wrap to 0
                for ix in 0..nx {
                    let dez_dy = (ez_next[ix] as f64) - (ez_curr[ix] as f64);
                    hx_row[ix] -= (dt_dy * dez_dy) as f32;
                }
            } else {
                 // Skip boundary
            }
        }
    }

    fn update_hy(&mut self) {
        let nx = self.grid.nx();
        let ny = self.grid.ny();
        let dt_dx = self.update_coeffs.dt_dx;

        let is_periodic_x = self.boundaries.is_periodic_x();

        let (ez_field, _, hy_field) = self.fields.split_all_mut();
        let ez = ez_field.as_slice();
        let hy = hy_field.as_mut_slice();

        // Loop iy: 0..ny
        #[cfg(feature = "parallel")]
        let use_parallel = self.config.use_parallel;
        #[cfg(not(feature = "parallel"))]
        let use_parallel = false;

        if use_parallel {
            #[cfg(feature = "parallel")]
            {
                hy.par_chunks_mut(nx)
                    .zip(ez.par_chunks(nx))
                    .for_each(|(hy_row, ez_curr)| {
                        for ix in 0..nx-1 {
                            let dez_dx = (ez_curr[ix+1] as f64) - (ez_curr[ix] as f64);
                            hy_row[ix] += (dt_dx * dez_dx) as f32;
                        }
                        // Handle last col
                        let ix = nx - 1;
                        if is_periodic_x {
                            let dez_dx = (ez_curr[0] as f64) - (ez_curr[ix] as f64);
                            hy_row[ix] += (dt_dx * dez_dx) as f32;
                        }
                    });
            }
        } else {
            for iy in 0..ny {
                let offset = iy * nx;
                let hy_row = &mut hy[offset..offset+nx];
                let ez_curr = &ez[offset..offset+nx];

                // Loop ix: 0..nx-1
                for ix in 0..nx-1 {
                    let dez_dx = (ez_curr[ix+1] as f64) - (ez_curr[ix] as f64);
                    hy_row[ix] += (dt_dx * dez_dx) as f32;
                }

                // Handle last col (ix = nx-1)
                let ix = nx - 1;
                if is_periodic_x {
                    let dez_dx = (ez_curr[0] as f64) - (ez_curr[ix] as f64); // Wrap to 0
                    hy_row[ix] += (dt_dx * dez_dx) as f32;
                }
            }
        }
    }

    fn update_ez(&mut self) {
        let nx = self.grid.nx();
        let ny = self.grid.ny();
        let dt_eps_dx = &self.update_coeffs.dt_eps_dx;
        let dt_eps_dy = &self.update_coeffs.dt_eps_dy;
        
        // ∂Ez/∂t = (1/ε) * (∂Hy/∂x - ∂Hx/∂y)
        // With coeff maps, we need careful unpacking.
        // If eps is uniform, dt_eps_dx and dt_eps_dy are just scalars.
        // We can optimize the loop easily.
        
        let is_periodic_x = self.boundaries.is_periodic_x();
        let is_periodic_y = self.boundaries.is_periodic_y();

        let (ez_field, hx_field, hy_field) = self.fields.split_all_mut();
        let hx = hx_field.as_slice();
        let hy = hy_field.as_slice();
        let ez = ez_field.as_mut_slice();

        // Need dHy/dx and dHx/dy.
        // dHy/dx = (Hy[i,j] - Hy[i-1,j]) / dx
        // dHx/dy = (Hx[i,j] - Hx[i,j-1]) / dy

        // We iterate iy: 0..ny, ix: 0..nx
        
        // 1. Row 0 (iy=0)
        {
            let iy = 0;
            let offset = 0;
            
            let ez_row = &mut ez[0..nx];
            let hx_curr = &hx[0..nx];
            
            let hy_row = &hy[0..nx];

            // For dHx/dy at j=0, need Hx(i, -1). 
            let hx_prev_opt = if is_periodic_y { 
                Some(&hx[(ny-1)*nx..ny*nx]) 
            } else { 
                None 
            };
            
            // Loop ix: 0..nx
            for ix in 0..nx {
                // dHy/dx
                let dhy_dx = if ix > 0 {
                    hy_row[ix] as f64 - hy_row[ix-1] as f64
                } else if is_periodic_x {
                    hy_row[0] as f64 - hy_row[nx-1] as f64
                } else {
                    0.0
                };

                // dHx/dy
                let dhx_dy = if let Some(hx_prev) = hx_prev_opt {
                    hx_curr[ix] as f64 - hx_prev[ix] as f64
                } else {
                    0.0
                };

                ez_row[ix] += (dt_eps_dx.get(ix) * dhy_dx - dt_eps_dy.get(ix) * dhx_dy) as f32;
            }
        }

        // 2. Rows 1..ny (iy=1..ny)
        #[cfg(feature = "parallel")]
        let use_parallel = self.config.use_parallel;
        #[cfg(not(feature = "parallel"))]
        let use_parallel = false;

        if use_parallel {
            #[cfg(feature = "parallel")]
             match dt_eps_dx {
                CoefficientMap::Uniform(c_dx) => {
                   let c_dy = match dt_eps_dy { CoefficientMap::Uniform(v) => *v, _ => *c_dx };
                   
                    ez.par_chunks_mut(nx).skip(1)
                    .zip(hx.par_chunks(nx).skip(1))
                    .zip(hx.par_chunks(nx))
                    .zip(hy.par_chunks(nx).skip(1))
                    .for_each(|(((ez_row, hx_curr), hx_prev), hy_row)| {
                        // ix=0
                        {
                            let dhy_dx = if is_periodic_x { 
                                hy_row[0] as f64 - hy_row[nx-1] as f64
                            } else { 
                                0.0 
                            };
                            let dhx_dy = hx_curr[0] as f64 - hx_prev[0] as f64;
                            ez_row[0] += (c_dx * dhy_dx - c_dy * dhx_dy) as f32;
                        }
                        
                        // Bulk ix = 1..nx
                        for ix in 1..nx {
                            let dhy_dx = hy_row[ix] as f64 - hy_row[ix-1] as f64;
                            let dhx_dy = hx_curr[ix] as f64 - hx_prev[ix] as f64;
                            ez_row[ix] += (c_dx * dhy_dx - c_dy * dhx_dy) as f32;
                        }
                    });
                }
                CoefficientMap::Varying(coeffs_dx) => {
                   let coeffs_dy = match dt_eps_dy { CoefficientMap::Varying(v) => v, _ => coeffs_dx };
                   
                    ez.par_chunks_mut(nx).skip(1)
                    .zip(hx.par_chunks(nx).skip(1))
                    .zip(hx.par_chunks(nx))
                    .zip(hy.par_chunks(nx).skip(1))
                    .zip(coeffs_dx.par_chunks(nx).skip(1))
                    .zip(coeffs_dy.par_chunks(nx).skip(1))
                    .for_each(|(((((ez_row, hx_curr), hx_prev), hy_row), coeff_x_row), coeff_y_row)| {
                        // ix=0
                        {
                            let dhy_dx = if is_periodic_x { 
                                hy_row[0] as f64 - hy_row[nx-1] as f64
                            } else { 
                                0.0 
                            };
                            let dhx_dy = hx_curr[0] as f64 - hx_prev[0] as f64;
                            ez_row[0] += (coeff_x_row[0] * dhy_dx - coeff_y_row[0] * dhx_dy) as f32;
                        }
                        
                        // Bulk ix = 1..nx
                        for ix in 1..nx {
                            let dhy_dx = hy_row[ix] as f64 - hy_row[ix-1] as f64;
                            let dhx_dy = hx_curr[ix] as f64 - hx_prev[ix] as f64;
                            ez_row[ix] += (coeff_x_row[ix] * dhy_dx - coeff_y_row[ix] * dhx_dy) as f32;
                        }
                    });
                }
             }
        } else {
            match dt_eps_dx {
                CoefficientMap::Uniform(c_dx) => {
                    let c_dy = match dt_eps_dy { CoefficientMap::Uniform(v) => *v, _ => *c_dx };
                    
                    for iy in 1..ny {
                        let offset = iy * nx;
                        let ez_row = &mut ez[offset..offset+nx];
                        let hx_curr = &hx[offset..offset+nx];
                        let hx_prev = &hx[offset-nx..offset];
                        let hy_row = &hy[offset..offset+nx];
                        
                        // ix=0
                        {
                            let dhy_dx = if is_periodic_x { 
                                hy_row[0] as f64 - hy_row[nx-1] as f64
                            } else { 
                                0.0 
                            };
                            let dhx_dy = hx_curr[0] as f64 - hx_prev[0] as f64;
                            ez_row[0] += (c_dx * dhy_dx - c_dy * dhx_dy) as f32;
                        }
                        
                        // Bulk ix = 1..nx
                        for ix in 1..nx {
                            let dhy_dx = hy_row[ix] as f64 - hy_row[ix-1] as f64;
                            let dhx_dy = hx_curr[ix] as f64 - hx_prev[ix] as f64;
                            ez_row[ix] += (c_dx * dhy_dx - c_dy * dhx_dy) as f32;
                        }
                    }
                }
                CoefficientMap::Varying(coeffs_dx) => {
                    let coeffs_dy = match dt_eps_dy { CoefficientMap::Varying(v) => v, _ => coeffs_dx };
                    for iy in 1..ny {
                        let offset = iy * nx;
                        let ez_row = &mut ez[offset..offset+nx];
                        let hx_curr = &hx[offset..offset+nx];
                        let hx_prev = &hx[offset-nx..offset];
                        let hy_row = &hy[offset..offset+nx];
                        let coeff_x_row = &coeffs_dx[offset..offset+nx];
                        let coeff_y_row = &coeffs_dy[offset..offset+nx];
                        
                        // ix=0
                        {
                            let dhy_dx = if is_periodic_x { 
                                hy_row[0] as f64 - hy_row[nx-1] as f64
                            } else { 
                                0.0 
                            };
                            let dhx_dy = hx_curr[0] as f64 - hx_prev[0] as f64;
                            ez_row[0] += (coeff_x_row[0] * dhy_dx - coeff_y_row[0] * dhx_dy) as f32;
                        }
                        
                        // Bulk ix = 1..nx
                        for ix in 1..nx {
                            let dhy_dx = hy_row[ix] as f64 - hy_row[ix-1] as f64;
                            let dhx_dy = hx_curr[ix] as f64 - hx_prev[ix] as f64;
                            ez_row[ix] += (coeff_x_row[ix] * dhy_dx - coeff_y_row[ix] * dhx_dy) as f32;
                        }
                    }
                }
            }
        }
    }

    fn apply_boundaries_tm(&mut self) {
        let nx = self.grid.nx();
        let ny = self.grid.ny();

        // PEC: Ez = 0 at boundary
        if self.boundaries.x_lo.condition == BoundaryCondition::Pec {
            let ez = self.fields.primary_mut().as_mut_slice();
            for iy in 0..ny {
                ez[iy * nx] = 0.0;
            }
        }
        if self.boundaries.x_hi.condition == BoundaryCondition::Pec {
            let ez = self.fields.primary_mut().as_mut_slice();
            for iy in 0..ny {
                ez[iy * nx + nx - 1] = 0.0;
            }
        }
        if self.boundaries.y_lo.condition == BoundaryCondition::Pec {
            let ez = self.fields.primary_mut().as_mut_slice();
            for ix in 0..nx {
                ez[ix] = 0.0;
            }
        }
        if self.boundaries.y_hi.condition == BoundaryCondition::Pec {
            let ez = self.fields.primary_mut().as_mut_slice();
            for ix in 0..nx {
                ez[(ny - 1) * nx + ix] = 0.0;
            }
        }
    }

    // ========================================================================
    // Source injection
    // ========================================================================

    fn inject_sources(&mut self) {
        // Collect source data first to avoid borrow conflict
        let source_data: Vec<_> = self
            .sources
            .iter()
            .filter_map(|source| {
                let value = source.value_at(self.time);
                if value.abs() < 1e-15 {
                    None
                } else {
                    Some((source.geometry.clone(), source.component, value))
                }
            })
            .collect();

        // Now inject sources
        for (geometry, component, value) in source_data {
            self.inject_source_at_geometry(&geometry, &component, value);
        }
    }

    fn inject_source_at_geometry(
        &mut self,
        geometry: &SourceGeometry,
        component: &SourceComponent,
        value: f64,
    ) {
        match geometry {
            SourceGeometry::Point { position } => {
                self.inject_point_source(*position, component, value);
            }
            SourceGeometry::Line { start, end } => {
                self.inject_line_source(*start, *end, component, value);
            }
            SourceGeometry::Area { center, size } => {
                self.inject_area_source(*center, *size, component, value);
            }
        }
    }

    fn inject_point_source(&mut self, position: [f64; 2], component: &SourceComponent, value: f64) {
        let ix = (position[0] / self.grid.dx()).round() as usize;
        let iy = (position[1] / self.grid.dy()).round() as usize;

        if ix >= self.grid.nx() || iy >= self.grid.ny() {
            return;
        }

        let idx = iy * self.grid.nx() + ix;

        match component {
            SourceComponent::Electric(fc) | SourceComponent::Current(fc) => match fc {
                FieldComponent::Ez => {
                    self.fields.primary_mut().as_mut_slice()[idx] += value as f32;
                }
                FieldComponent::Ex => {
                    self.fields.secondary_x_mut().as_mut_slice()[idx] += value as f32;
                }
                FieldComponent::Ey => {
                    self.fields.secondary_y_mut().as_mut_slice()[idx] += value as f32;
                }
                _ => {}
            },
            SourceComponent::Magnetic(fc) => match fc {
                FieldComponent::Hz => {
                    self.fields.primary_mut().as_mut_slice()[idx] += value as f32;
                }
                FieldComponent::Hx => {
                    self.fields.secondary_x_mut().as_mut_slice()[idx] += value as f32;
                }
                FieldComponent::Hy => {
                    self.fields.secondary_y_mut().as_mut_slice()[idx] += value as f32;
                }
                _ => {}
            },
        }
    }

    fn inject_line_source(
        &mut self,
        start: [f64; 2],
        end: [f64; 2],
        component: &SourceComponent,
        value: f64,
    ) {
        // Simple rasterization: inject at each grid point along the line
        let dx = self.grid.dx();
        let dy = self.grid.dy();

        let length = ((end[0] - start[0]).powi(2) + (end[1] - start[1]).powi(2)).sqrt();
        let n_points = (length / dx.min(dy)).ceil() as usize + 1;

        for i in 0..n_points {
            let t = i as f64 / (n_points - 1).max(1) as f64;
            let pos = [
                start[0] + t * (end[0] - start[0]),
                start[1] + t * (end[1] - start[1]),
            ];
            self.inject_point_source(pos, component, value / n_points as f64);
        }
    }

    fn inject_area_source(
        &mut self,
        center: [f64; 2],
        size: [f64; 2],
        component: &SourceComponent,
        value: f64,
    ) {
        let dx = self.grid.dx();
        let dy = self.grid.dy();

        let x_start = center[0] - size[0] / 2.0;
        let x_end = center[0] + size[0] / 2.0;
        let y_start = center[1] - size[1] / 2.0;
        let y_end = center[1] + size[1] / 2.0;

        let ix_start = (x_start / dx).floor() as usize;
        let ix_end = (x_end / dx).ceil() as usize;
        let iy_start = (y_start / dy).floor() as usize;
        let iy_end = (y_end / dy).ceil() as usize;

        let n_points = (ix_end - ix_start) * (iy_end - iy_start);
        let value_per_point = value / n_points.max(1) as f64;

        for iy in iy_start..iy_end.min(self.grid.ny()) {
            for ix in ix_start..ix_end.min(self.grid.nx()) {
                let pos = [ix as f64 * dx, iy as f64 * dy];
                self.inject_point_source(pos, component, value_per_point);
            }
        }
    }

    // ========================================================================
    // Output
    // ========================================================================

    /// Create a snapshot of the current field state.
    pub fn snapshot(&self) -> FieldSnapshot {
        FieldSnapshot::from_simulation(self)
    }

    /// Check if the simulation is still stable.
    pub fn is_stable(&self) -> bool {
        self.fields.is_stable()
    }

    /// Reset simulation to initial state.
    pub fn reset(&mut self) {
        self.fields.reset();
        if let Some(ref mut pml) = self.pml {
            pml.reset();
        }
        self.time = 0.0;
        self.step = 0;
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::lattice::Lattice2D;

    fn create_test_geometry() -> Geometry2D {
        Geometry2D::single_air_hole(Lattice2D::square(1.0), 0.3, 12.0)
    }

    #[test]
    fn test_simulation_creation() {
        let geom = create_test_geometry();
        let config = FdtdConfig::default();
        let sim = FdtdSimulation::new(geom, config);

        assert!(sim.dt() > 0.0);
        assert_eq!(sim.time(), 0.0);
        assert_eq!(sim.step(), 0);
    }

    #[test]
    fn test_simulation_step() {
        let geom = create_test_geometry();
        let config = FdtdConfig::default();
        let mut sim = FdtdSimulation::new(geom, config);

        sim.step_once();
        assert_eq!(sim.step(), 1);
        assert!(sim.time() > 0.0);
    }

    #[test]
    fn test_stability_empty() {
        let geom = create_test_geometry();
        let config = FdtdConfig::default();
        let mut sim = FdtdSimulation::new(geom, config);

        // Run without sources - should stay stable
        sim.run(100);
        assert!(sim.is_stable());
    }
}
