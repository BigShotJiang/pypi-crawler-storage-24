//! Yee lattice grid for FDTD simulations.
//!
//! The Yee grid is a staggered spatial grid where electric and magnetic field
//! components are offset by half a grid cell. This staggering is crucial for
//! accurate finite-difference approximations of Maxwell's curl equations.
//!
//! # 2D Yee Cell Layout
//!
//! For TM polarization (Ez, Hx, Hy):
//! ```text
//!     Hy[i,j+1]
//!        |
//!        v
//!    +---+---+
//!    |       |
//! Hx[i,j]--> Ez[i,j]
//!    |       |
//!    +---+---+
//! ```
//!
//! - Ez is at integer grid points (i, j)
//! - Hx is at (i, j+½) - offset in y
//! - Hy is at (i+½, j) - offset in x
//!
//! For TE polarization (Hz, Ex, Ey):
//! ```text
//!     Ey[i,j+1]
//!        |
//!        v
//!    +---+---+
//!    |       |
//! Ex[i,j]--> Hz[i,j]
//!    |       |
//!    +---+---+
//! ```
//!
//! - Hz is at integer grid points (i, j)
//! - Ex is at (i, j+½) - offset in y  
//! - Ey is at (i+½, j) - offset in x

use serde::{Deserialize, Serialize};

use crate::grid::Grid2D;
use crate::lattice::Lattice2D;
use crate::polarization::Polarization;

/// Yee grid for 2D FDTD simulations.
///
/// Wraps a standard `Grid2D` and provides methods for accessing staggered
/// field positions according to the Yee cell layout.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct YeeGrid2D {
    /// Base grid (integer positions)
    grid: Grid2D,
    /// Spatial resolution (grid points per unit length)
    resolution: f64,
    /// Grid spacing in x direction
    dx: f64,
    /// Grid spacing in y direction  
    dy: f64,
    /// Physical domain size in x
    lx: f64,
    /// Physical domain size in y
    ly: f64,
}

impl YeeGrid2D {
    /// Create a new Yee grid from physical dimensions and resolution.
    ///
    /// # Arguments
    /// - `lx`, `ly`: Physical domain size
    /// - `resolution`: Grid points per unit length (same in both directions)
    ///
    /// # Example
    /// ```ignore
    /// let grid = YeeGrid2D::new(10.0, 10.0, 32.0);
    /// // Creates a 320x320 grid for a 10x10 domain
    /// ```
    pub fn new(lx: f64, ly: f64, resolution: f64) -> Self {
        let nx = (lx * resolution).round() as usize;
        let ny = (ly * resolution).round() as usize;
        let dx = lx / nx as f64;
        let dy = ly / ny as f64;

        Self {
            grid: Grid2D::new(nx, ny, lx, ly),
            resolution,
            dx,
            dy,
            lx,
            ly,
        }
    }

    /// Create a Yee grid from a lattice with specified resolution.
    ///
    /// For non-orthogonal lattices, the grid covers the bounding box of the
    /// unit cell. The actual lattice geometry is handled by the dielectric
    /// sampling.
    pub fn from_lattice(lattice: &Lattice2D, resolution: f64) -> Self {
        // Compute bounding box of the unit cell
        let corners = [
            [0.0, 0.0],
            lattice.a1,
            lattice.a2,
            [lattice.a1[0] + lattice.a2[0], lattice.a1[1] + lattice.a2[1]],
        ];

        let min_x = corners.iter().map(|c| c[0]).fold(f64::INFINITY, f64::min);
        let max_x = corners
            .iter()
            .map(|c| c[0])
            .fold(f64::NEG_INFINITY, f64::max);
        let min_y = corners.iter().map(|c| c[1]).fold(f64::INFINITY, f64::min);
        let max_y = corners
            .iter()
            .map(|c| c[1])
            .fold(f64::NEG_INFINITY, f64::max);

        let lx = max_x - min_x;
        let ly = max_y - min_y;

        Self::new(lx.max(1e-10), ly.max(1e-10), resolution)
    }

    /// Create from explicit grid dimensions.
    pub fn from_dimensions(nx: usize, ny: usize, lx: f64, ly: f64) -> Self {
        let dx = lx / nx as f64;
        let dy = ly / ny as f64;
        let resolution = nx as f64 / lx;

        Self {
            grid: Grid2D::new(nx, ny, lx, ly),
            resolution,
            dx,
            dy,
            lx,
            ly,
        }
    }

    // ========================================================================
    // Accessors
    // ========================================================================

    /// Get the underlying Grid2D.
    #[inline]
    pub fn grid(&self) -> &Grid2D {
        &self.grid
    }

    /// Number of grid points in x.
    #[inline]
    pub fn nx(&self) -> usize {
        self.grid.nx
    }

    /// Number of grid points in y.
    #[inline]
    pub fn ny(&self) -> usize {
        self.grid.ny
    }

    /// Total number of grid points.
    #[inline]
    pub fn len(&self) -> usize {
        self.grid.len()
    }

    /// Check if grid is empty.
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Grid spacing in x direction.
    #[inline]
    pub fn dx(&self) -> f64 {
        self.dx
    }

    /// Grid spacing in y direction.
    #[inline]
    pub fn dy(&self) -> f64 {
        self.dy
    }

    /// Physical size in x direction.
    #[inline]
    pub fn lx(&self) -> f64 {
        self.lx
    }

    /// Physical size in y direction.
    #[inline]
    pub fn ly(&self) -> f64 {
        self.ly
    }

    /// Resolution (grid points per unit length).
    #[inline]
    pub fn resolution(&self) -> f64 {
        self.resolution
    }

    // ========================================================================
    // Indexing
    // ========================================================================

    /// Linear index from 2D indices (row-major order).
    #[inline]
    pub fn idx(&self, ix: usize, iy: usize) -> usize {
        self.grid.idx(ix, iy)
    }

    /// Convert linear index to 2D indices.
    #[inline]
    pub fn idx_to_2d(&self, idx: usize) -> (usize, usize) {
        let iy = idx / self.grid.nx;
        let ix = idx % self.grid.nx;
        (ix, iy)
    }

    // ========================================================================
    // Position queries
    // ========================================================================

    /// Cartesian position of an integer grid point.
    ///
    /// This is where Ez (TM) or Hz (TE) is located.
    #[inline]
    pub fn position(&self, ix: usize, iy: usize) -> [f64; 2] {
        [ix as f64 * self.dx, iy as f64 * self.dy]
    }

    /// Position offset by half cell in x (where Hy or Ey is located).
    #[inline]
    pub fn position_half_x(&self, ix: usize, iy: usize) -> [f64; 2] {
        [(ix as f64 + 0.5) * self.dx, iy as f64 * self.dy]
    }

    /// Position offset by half cell in y (where Hx or Ex is located).
    #[inline]
    pub fn position_half_y(&self, ix: usize, iy: usize) -> [f64; 2] {
        [ix as f64 * self.dx, (iy as f64 + 0.5) * self.dy]
    }

    /// Get fractional coordinates from Cartesian position.
    pub fn cartesian_to_fractional(&self, pos: [f64; 2]) -> [f64; 2] {
        [pos[0] / self.lx, pos[1] / self.ly]
    }

    /// Get Cartesian position from fractional coordinates.
    pub fn fractional_to_cartesian(&self, frac: [f64; 2]) -> [f64; 2] {
        [frac[0] * self.lx, frac[1] * self.ly]
    }

    // ========================================================================
    // Courant condition
    // ========================================================================

    /// Compute the Courant-stable time step.
    ///
    /// For 2D FDTD, the Courant condition is:
    ///   dt <= 1 / (c * sqrt(1/dx² + 1/dy²))
    ///
    /// where c = 1 in normalized units.
    ///
    /// # Arguments
    /// - `courant_factor`: Safety factor (typically 0.5)
    pub fn courant_dt(&self, courant_factor: f64) -> f64 {
        let c = 1.0; // Speed of light in normalized units
        let max_dt = 1.0 / (c * (1.0 / (self.dx * self.dx) + 1.0 / (self.dy * self.dy)).sqrt());
        courant_factor * max_dt
    }

    // ========================================================================
    // Field component positions (for documentation/debugging)
    // ========================================================================

    /// Describe field positions for a given polarization.
    pub fn describe_layout(&self, pol: Polarization) -> FieldLayout {
        match pol {
            Polarization::TM => FieldLayout {
                primary: FieldPosition::Integer,       // Ez
                secondary_x: FieldPosition::HalfY,     // Hx at (i, j+½)
                secondary_y: FieldPosition::HalfX,     // Hy at (i+½, j)
                primary_name: "Ez",
                secondary_x_name: "Hx",
                secondary_y_name: "Hy",
            },
            Polarization::TE => FieldLayout {
                primary: FieldPosition::Integer,       // Hz
                secondary_x: FieldPosition::HalfY,     // Ex at (i, j+½)
                secondary_y: FieldPosition::HalfX,     // Ey at (i+½, j)
                primary_name: "Hz",
                secondary_x_name: "Ex",
                secondary_y_name: "Ey",
            },
        }
    }
}

/// Position type within a Yee cell.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FieldPosition {
    /// Integer grid point (i, j)
    Integer,
    /// Half-step in x: (i+½, j)
    HalfX,
    /// Half-step in y: (i, j+½)
    HalfY,
}

/// Layout of field components for a given polarization.
#[derive(Debug, Clone)]
pub struct FieldLayout {
    /// Position of primary field (Ez or Hz)
    pub primary: FieldPosition,
    /// Position of x-component of secondary field (Hx or Ex)
    pub secondary_x: FieldPosition,
    /// Position of y-component of secondary field (Hy or Ey)
    pub secondary_y: FieldPosition,
    /// Name of primary field
    pub primary_name: &'static str,
    /// Name of secondary x-component
    pub secondary_x_name: &'static str,
    /// Name of secondary y-component
    pub secondary_y_name: &'static str,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_yee_grid_creation() {
        let grid = YeeGrid2D::new(1.0, 1.0, 32.0);
        assert_eq!(grid.nx(), 32);
        assert_eq!(grid.ny(), 32);
        assert!((grid.dx() - 1.0 / 32.0).abs() < 1e-10);
    }

    #[test]
    fn test_position_calculations() {
        let grid = YeeGrid2D::new(1.0, 1.0, 4.0);
        
        // Integer position
        let pos = grid.position(2, 3);
        assert!((pos[0] - 0.5).abs() < 1e-10);
        assert!((pos[1] - 0.75).abs() < 1e-10);
        
        // Half-x position
        let pos_hx = grid.position_half_x(2, 3);
        assert!((pos_hx[0] - 0.625).abs() < 1e-10);
        assert!((pos_hx[1] - 0.75).abs() < 1e-10);
    }

    #[test]
    fn test_courant_condition() {
        let grid = YeeGrid2D::new(1.0, 1.0, 32.0);
        let dt = grid.courant_dt(0.5);
        
        // Should be less than dx / (sqrt(2) * c)
        let dx = 1.0 / 32.0;
        let max_dt = dx / 2.0_f64.sqrt();
        assert!(dt < max_dt);
        assert!(dt > 0.0);
    }
}
