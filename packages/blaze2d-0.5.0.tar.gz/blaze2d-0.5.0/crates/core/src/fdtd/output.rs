//! Field snapshot output for FDTD simulations.
//!
//! This module provides functionality for saving field snapshots during
//! FDTD simulations. Snapshots can be saved in various formats for
//! visualization and analysis.

use std::fs::File;
use std::io::{BufWriter, Write};
use std::path::Path;

use serde::{Deserialize, Serialize};

use super::fields::FieldComponent;
use super::yee_grid::YeeGrid2D;
use crate::polarization::Polarization;

/// Format for saving snapshots.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "lowercase")]
pub enum SnapshotFormat {
    /// CSV format: x,y,value per line
    #[default]
    Csv,
    /// Binary format (raw f64 values, row-major)
    Binary,
    /// NumPy .npy format
    Numpy,
}

/// A snapshot of the field state at a specific time.
#[derive(Debug, Clone)]
pub struct FieldSnapshot {
    /// Time at which snapshot was taken
    pub time: f64,
    /// Time step number
    pub step: usize,
    /// Grid specification
    pub grid: YeeGrid2D,
    /// Polarization mode
    pub polarization: Polarization,
    /// Primary field data (Ez for TM, Hz for TE)
    pub primary: Vec<f64>,
    /// Secondary x-component (Hx for TM, Ex for TE)
    pub secondary_x: Vec<f64>,
    /// Secondary y-component (Hy for TM, Ey for TE)
    pub secondary_y: Vec<f64>,
}

impl FieldSnapshot {
    /// Create a snapshot from an FDTD simulation.
    pub fn from_simulation(sim: &super::simulation::FdtdSimulation) -> Self {
        Self {
            time: sim.time(),
            step: sim.step(),
            grid: sim.grid().clone(),
            polarization: sim.polarization(),
            primary: sim.fields().primary().as_slice().iter().map(|&x| x as f64).collect(),
            secondary_x: sim.fields().secondary_x().as_slice().iter().map(|&x| x as f64).collect(),
            secondary_y: sim.fields().secondary_y().as_slice().iter().map(|&x| x as f64).collect(),
        }
    }

    /// Get the primary field name.
    pub fn primary_name(&self) -> &'static str {
        match self.polarization {
            Polarization::TM => "Ez",
            Polarization::TE => "Hz",
        }
    }

    /// Get the secondary x field name.
    pub fn secondary_x_name(&self) -> &'static str {
        match self.polarization {
            Polarization::TM => "Hx",
            Polarization::TE => "Ex",
        }
    }

    /// Get the secondary y field name.
    pub fn secondary_y_name(&self) -> &'static str {
        match self.polarization {
            Polarization::TM => "Hy",
            Polarization::TE => "Ey",
        }
    }

    /// Get field data by component.
    pub fn get_component(&self, component: FieldComponent) -> Option<&[f64]> {
        match (self.polarization, component) {
            (Polarization::TM, FieldComponent::Ez) => Some(&self.primary),
            (Polarization::TM, FieldComponent::Hx) => Some(&self.secondary_x),
            (Polarization::TM, FieldComponent::Hy) => Some(&self.secondary_y),
            (Polarization::TE, FieldComponent::Hz) => Some(&self.primary),
            (Polarization::TE, FieldComponent::Ex) => Some(&self.secondary_x),
            (Polarization::TE, FieldComponent::Ey) => Some(&self.secondary_y),
            _ => None,
        }
    }

    /// Save all field components to files.
    ///
    /// Creates files named `{base}_Ez.csv`, `{base}_Hx.csv`, etc.
    pub fn save_all(&self, base_path: &Path, format: SnapshotFormat) -> std::io::Result<()> {
        let ext = match format {
            SnapshotFormat::Csv => "csv",
            SnapshotFormat::Binary => "bin",
            SnapshotFormat::Numpy => "npy",
        };

        let base = base_path.to_string_lossy();

        // Primary field
        let primary_path = format!("{}_{}.{}", base, self.primary_name(), ext);
        self.save_field(&self.primary, Path::new(&primary_path), format)?;

        // Secondary x
        let sec_x_path = format!("{}_{}.{}", base, self.secondary_x_name(), ext);
        self.save_field(&self.secondary_x, Path::new(&sec_x_path), format)?;

        // Secondary y
        let sec_y_path = format!("{}_{}.{}", base, self.secondary_y_name(), ext);
        self.save_field(&self.secondary_y, Path::new(&sec_y_path), format)?;

        Ok(())
    }

    /// Save the primary field to a file.
    pub fn save_primary(&self, path: &Path, format: SnapshotFormat) -> std::io::Result<()> {
        self.save_field(&self.primary, path, format)
    }

    /// Save a specific field component to a file.
    pub fn save_field(
        &self,
        data: &[f64],
        path: &Path,
        format: SnapshotFormat,
    ) -> std::io::Result<()> {
        match format {
            SnapshotFormat::Csv => self.save_csv(data, path),
            SnapshotFormat::Binary => self.save_binary(data, path),
            SnapshotFormat::Numpy => self.save_numpy(data, path),
        }
    }

    fn save_csv(&self, data: &[f64], path: &Path) -> std::io::Result<()> {
        let file = File::create(path)?;
        let mut writer = BufWriter::new(file);

        // Header with metadata
        writeln!(
            writer,
            "# FDTD Field Snapshot - Blaze2D"
        )?;
        writeln!(writer, "# time: {}", self.time)?;
        writeln!(writer, "# step: {}", self.step)?;
        writeln!(writer, "# nx: {}", self.grid.nx())?;
        writeln!(writer, "# ny: {}", self.grid.ny())?;
        writeln!(writer, "# lx: {}", self.grid.lx())?;
        writeln!(writer, "# ly: {}", self.grid.ly())?;
        writeln!(writer, "# polarization: {:?}", self.polarization)?;
        writeln!(writer, "ix,iy,x,y,value")?;

        let nx = self.grid.nx();
        let ny = self.grid.ny();
        let dx = self.grid.dx();
        let dy = self.grid.dy();

        for iy in 0..ny {
            for ix in 0..nx {
                let idx = iy * nx + ix;
                let x = ix as f64 * dx;
                let y = iy as f64 * dy;
                writeln!(writer, "{},{},{},{},{}", ix, iy, x, y, data[idx])?;
            }
        }

        Ok(())
    }

    fn save_binary(&self, data: &[f64], path: &Path) -> std::io::Result<()> {
        let file = File::create(path)?;
        let mut writer = BufWriter::new(file);

        // Write header: nx, ny, time as f64
        let nx = self.grid.nx() as f64;
        let ny = self.grid.ny() as f64;
        writer.write_all(&nx.to_le_bytes())?;
        writer.write_all(&ny.to_le_bytes())?;
        writer.write_all(&self.time.to_le_bytes())?;

        // Write data
        for &value in data {
            writer.write_all(&value.to_le_bytes())?;
        }

        Ok(())
    }

    fn save_numpy(&self, data: &[f64], path: &Path) -> std::io::Result<()> {
        // Simple NumPy v1.0 format
        let file = File::create(path)?;
        let mut writer = BufWriter::new(file);

        let nx = self.grid.nx();
        let ny = self.grid.ny();

        // Magic number
        writer.write_all(&[0x93])?;
        writer.write_all(b"NUMPY")?;

        // Version 1.0
        writer.write_all(&[0x01, 0x00])?;

        // Header (dict describing array)
        let header = format!(
            "{{'descr': '<f8', 'fortran_order': False, 'shape': ({}, {}), }}",
            ny, nx
        );

        // Pad header to multiple of 64 bytes (including 10-byte preamble)
        let header_len = header.len();
        let padding = 64 - ((10 + header_len + 1) % 64);
        let total_header_len = header_len + padding + 1;

        // Write header length as u16 little-endian
        writer.write_all(&(total_header_len as u16).to_le_bytes())?;

        // Write header
        writer.write_all(header.as_bytes())?;

        // Padding spaces and newline
        for _ in 0..padding {
            writer.write_all(b" ")?;
        }
        writer.write_all(b"\n")?;

        // Write data in row-major order
        for &value in data {
            writer.write_all(&value.to_le_bytes())?;
        }

        Ok(())
    }

    /// Get maximum absolute value across all components.
    pub fn max_amplitude(&self) -> f64 {
        let max_primary = self.primary.iter().map(|x| x.abs()).fold(0.0_f64, f64::max);
        let max_sec_x = self
            .secondary_x
            .iter()
            .map(|x| x.abs())
            .fold(0.0_f64, f64::max);
        let max_sec_y = self
            .secondary_y
            .iter()
            .map(|x| x.abs())
            .fold(0.0_f64, f64::max);
        max_primary.max(max_sec_x).max(max_sec_y)
    }

    /// Get total electromagnetic energy (simplified).
    pub fn total_energy(&self) -> f64 {
        let e_primary: f64 = self.primary.iter().map(|x| x * x).sum();
        let e_sec_x: f64 = self.secondary_x.iter().map(|x| x * x).sum();
        let e_sec_y: f64 = self.secondary_y.iter().map(|x| x * x).sum();
        e_primary + e_sec_x + e_sec_y
    }
}

/// Builder for creating snapshot sequences.
pub struct SnapshotSequence {
    /// Base path for output files
    base_path: String,
    /// Output format
    format: SnapshotFormat,
    /// Which components to save
    components: Vec<FieldComponent>,
    /// Counter for sequential naming
    counter: usize,
}

impl SnapshotSequence {
    /// Create a new snapshot sequence.
    pub fn new(base_path: &str) -> Self {
        Self {
            base_path: base_path.to_string(),
            format: SnapshotFormat::Csv,
            components: Vec::new(),
            counter: 0,
        }
    }

    /// Set output format.
    pub fn format(mut self, format: SnapshotFormat) -> Self {
        self.format = format;
        self
    }

    /// Add a component to save.
    pub fn component(mut self, component: FieldComponent) -> Self {
        self.components.push(component);
        self
    }

    /// Save all active components (TE: Hz, Ex, Ey; TM: Ez, Hx, Hy).
    pub fn all_components(mut self, polarization: Polarization) -> Self {
        self.components = match polarization {
            Polarization::TE => vec![FieldComponent::Hz, FieldComponent::Ex, FieldComponent::Ey],
            Polarization::TM => vec![FieldComponent::Ez, FieldComponent::Hx, FieldComponent::Hy],
        };
        self
    }

    /// Save a snapshot with sequential numbering.
    pub fn save(&mut self, snapshot: &FieldSnapshot) -> std::io::Result<()> {
        let ext = match self.format {
            SnapshotFormat::Csv => "csv",
            SnapshotFormat::Binary => "bin",
            SnapshotFormat::Numpy => "npy",
        };

        if self.components.is_empty() {
            // Save all by default
            let path = format!("{}_{:06}", self.base_path, self.counter);
            snapshot.save_all(Path::new(&path), self.format)?;
        } else {
            for component in &self.components {
                if let Some(data) = snapshot.get_component(*component) {
                    let path = format!(
                        "{}_{:06}_{}.{}",
                        self.base_path,
                        self.counter,
                        component.name(),
                        ext
                    );
                    snapshot.save_field(data, Path::new(&path), self.format)?;
                }
            }
        }

        self.counter += 1;
        Ok(())
    }

    /// Reset the counter.
    pub fn reset(&mut self) {
        self.counter = 0;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_snapshot_format_default() {
        let format = SnapshotFormat::default();
        assert_eq!(format, SnapshotFormat::Csv);
    }

    #[test]
    fn test_snapshot_sequence() {
        let mut seq = SnapshotSequence::new("/tmp/test_snapshot")
            .format(SnapshotFormat::Csv)
            .all_components(Polarization::TE);

        assert_eq!(seq.components.len(), 3);
        assert_eq!(seq.counter, 0);
    }
}
