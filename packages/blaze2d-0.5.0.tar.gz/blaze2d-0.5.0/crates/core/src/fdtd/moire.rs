//! Moiré lattice builder for twisted bilayer photonic crystals.
//!
//! This module provides tools for creating moiré superlattices from two
//! twisted monolayers. When two identical periodic lattices are rotated
//! relative to each other by a small angle θ, they form a moiré pattern
//! with a much larger periodicity.
//!
//! # Moiré Lattice Constant
//!
//! For two identical lattices with lattice constant `a` twisted by angle θ:
//!
//! L_m = a / (2 * sin(θ/2))
//!
//! For small angles: L_m ≈ a / θ
//!
//! Example: a = 1.0, θ = 1.1° → L_m ≈ 52.1
//!
//! # Permittivity Combination
//!
//! When sampling the permittivity, we check both layers. The combination
//! rule determines how overlapping regions are handled:
//! - **Max**: Use the higher permittivity (dielectric dominates)
//! - **Min**: Use the lower permittivity (air holes dominate)
//! - **Average**: Average of both layers
//! - **Product**: Effective medium approximation

use std::f64::consts::PI;

use serde::{Deserialize, Serialize};

use crate::dielectric::{Dielectric2D, DielectricOptions, SmoothingMethod, SmoothingOptions};
use crate::geometry::{BasisAtom, Geometry2D};
use crate::grid::Grid2D;
use crate::lattice::Lattice2D;

/// How to combine permittivities from overlapping layers.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "lowercase")]
pub enum PermittivityCombination {
    /// Use the maximum permittivity (dielectric dominates)
    #[default]
    Max,
    /// Use the minimum permittivity (holes dominate)
    Min,
    /// Average of both layers
    Average,
    /// First layer takes precedence where it has inclusions
    Layer1First,
    /// Second layer takes precedence where it has inclusions
    Layer2First,
}

/// Configuration for a single monolayer in the moiré structure.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MonolayerConfig {
    /// Lattice type: "square", "triangular", "hexagonal", "rectangular"
    pub lattice_type: String,
    /// Lattice constant
    #[serde(default = "default_lattice_constant")]
    pub a: f64,
    /// Second lattice constant (for rectangular)
    pub b: Option<f64>,
    /// Rotation angle in degrees (relative to reference)
    #[serde(default)]
    pub rotation_deg: f64,
    /// Atoms in the basis
    #[serde(default)]
    pub atoms: Vec<MonolayerAtom>,
    /// Background permittivity for this layer
    #[serde(default = "default_eps_bg")]
    pub eps_bg: f64,
}

fn default_lattice_constant() -> f64 {
    1.0
}

fn default_eps_bg() -> f64 {
    1.0
}

/// Atom configuration for a monolayer.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MonolayerAtom {
    /// Position in fractional coordinates [0, 1)
    #[serde(default)]
    pub pos: [f64; 2],
    /// Radius as fraction of lattice constant (r/a)
    pub r_over_a: f64,
    /// Permittivity inside the atom
    #[serde(default = "default_eps_inside")]
    pub eps_inside: f64,
}

fn default_eps_inside() -> f64 {
    1.0
}

impl Default for MonolayerAtom {
    fn default() -> Self {
        Self {
            pos: [0.0, 0.0],
            r_over_a: 0.3,
            eps_inside: 1.0,
        }
    }
}

/// A single monolayer with its lattice and atoms.
#[derive(Debug, Clone)]
pub struct Monolayer {
    /// The 2D lattice (possibly rotated)
    pub lattice: Lattice2D,
    /// Atoms in the unit cell
    pub atoms: Vec<BasisAtom>,
    /// Background permittivity
    pub eps_bg: f64,
    /// Rotation angle applied (radians)
    pub rotation: f64,
}

impl Monolayer {
    /// Create a monolayer from configuration.
    pub fn from_config(config: &MonolayerConfig) -> Self {
        let rotation = config.rotation_deg.to_radians();

        // Create base lattice
        let base_lattice = match config.lattice_type.to_lowercase().as_str() {
            "square" => Lattice2D::square(config.a),
            "triangular" | "hexagonal" => Lattice2D::hexagonal(config.a),
            "rectangular" => {
                let b = config.b.unwrap_or(config.a * 1.5);
                Lattice2D::rectangular(config.a, b)
            }
            _ => Lattice2D::square(config.a),
        };

        // Apply rotation to lattice vectors
        let lattice = rotate_lattice(&base_lattice, rotation);

        // Convert atoms
        let atoms: Vec<BasisAtom> = config
            .atoms
            .iter()
            .map(|a| BasisAtom {
                pos: a.pos,
                radius: a.r_over_a, // Will be scaled by lattice constant when sampling
                eps_inside: a.eps_inside,
            })
            .collect();

        Self {
            lattice,
            atoms,
            eps_bg: config.eps_bg,
            rotation,
        }
    }

    /// Create a simple monolayer with a single centered atom.
    pub fn simple(lattice_type: &str, a: f64, r_over_a: f64, eps_bg: f64, eps_inside: f64) -> Self {
        let config = MonolayerConfig {
            lattice_type: lattice_type.to_string(),
            a,
            b: None,
            rotation_deg: 0.0,
            atoms: vec![MonolayerAtom {
                pos: [0.0, 0.0],
                r_over_a,
                eps_inside,
            }],
            eps_bg,
        };
        Self::from_config(&config)
    }

    /// Create a rotated copy of this monolayer.
    pub fn rotated(&self, angle_deg: f64) -> Self {
        let angle_rad = angle_deg.to_radians();
        let new_rotation = self.rotation + angle_rad;

        // Rotate the lattice vectors
        let lattice = rotate_lattice(&self.lattice, angle_rad);

        Self {
            lattice,
            atoms: self.atoms.clone(),
            eps_bg: self.eps_bg,
            rotation: new_rotation,
        }
    }

    /// Get permittivity at a Cartesian position, considering periodic images.
    pub fn permittivity_at(&self, pos: [f64; 2]) -> f64 {
        // Convert to fractional coordinates
        let frac = self.lattice.cartesian_to_fractional(pos);

        // Wrap to unit cell
        let wrapped = [wrap_unit(frac[0]), wrap_unit(frac[1])];

        // Check each atom
        for atom in &self.atoms {
            if self.point_inside_atom(wrapped, atom) {
                return atom.eps_inside;
            }
        }

        self.eps_bg
    }

    fn point_inside_atom(&self, frac_point: [f64; 2], atom: &BasisAtom) -> bool {
        // Minimum image convention for periodic boundary
        let delta_frac = [
            wrap_signed(frac_point[0] - atom.pos[0]),
            wrap_signed(frac_point[1] - atom.pos[1]),
        ];

        // Convert to Cartesian
        let delta_cart = self.lattice.fractional_to_cartesian(delta_frac);
        let dist_sq = delta_cart[0] * delta_cart[0] + delta_cart[1] * delta_cart[1];

        // Radius in Cartesian units
        let r_cart = atom.radius * self.lattice.characteristic_length();
        dist_sq <= r_cart * r_cart
    }
}

/// Moiré lattice configuration.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MoireConfig {
    /// First layer configuration
    pub layer1: MonolayerConfig,
    /// Second layer configuration (if None, uses layer1 with twist)
    pub layer2: Option<MonolayerConfig>,
    /// Twist angle in degrees (applied to layer2 if layer2 is None)
    pub twist_angle_deg: f64,
    /// How to combine permittivities from both layers
    #[serde(default)]
    pub combination: PermittivityCombination,
    /// Number of moiré unit cells in x direction
    #[serde(default = "default_cells")]
    pub cells_x: usize,
    /// Number of moiré unit cells in y direction
    #[serde(default = "default_cells")]
    pub cells_y: usize,
}

fn default_cells() -> usize {
    1
}

/// A moiré lattice composed of two twisted monolayers.
#[derive(Debug, Clone)]
pub struct MoireLattice {
    /// First monolayer (reference, unrotated or with its own rotation)
    pub layer1: Monolayer,
    /// Second monolayer (twisted relative to layer1)
    pub layer2: Monolayer,
    /// Twist angle between layers (radians)
    pub twist_angle: f64,
    /// Moiré superlattice constant
    pub moire_length: f64,
    /// Moiré superlattice vectors
    pub moire_lattice: Lattice2D,
    /// Combination rule for permittivities
    pub combination: PermittivityCombination,
}

impl MoireLattice {
    /// Create a moiré lattice from configuration.
    pub fn from_config(config: &MoireConfig) -> Self {
        let layer1 = Monolayer::from_config(&config.layer1);

        let layer2 = if let Some(ref l2_config) = config.layer2 {
            Monolayer::from_config(l2_config)
        } else {
            // Use layer1 rotated by twist angle (negative for correct convention)
            layer1.rotated(-config.twist_angle_deg)
        };

        let twist_angle = config.twist_angle_deg.to_radians();
        let a = config.layer1.a;

        // Calculate moiré length
        let moire_length = compute_moire_length(a, twist_angle);

        // Create moiré superlattice
        // For small angles, the moiré lattice is approximately the same type
        // as the original but with lattice constant L_m
        let moire_lattice = match config.layer1.lattice_type.to_lowercase().as_str() {
            "square" => Lattice2D::square(moire_length),
            "triangular" | "hexagonal" => Lattice2D::hexagonal(moire_length),
            _ => Lattice2D::square(moire_length),
        };

        Self {
            layer1,
            layer2,
            twist_angle,
            moire_length,
            moire_lattice,
            combination: config.combination,
        }
    }

    /// Create a simple moiré lattice from basic parameters.
    ///
    /// # Arguments
    /// - `lattice_type`: "square", "triangular", etc.
    /// - `a`: Lattice constant of monolayers
    /// - `r_over_a`: Radius of inclusions as fraction of a
    /// - `eps_bg`: Background permittivity
    /// - `eps_inside`: Permittivity inside inclusions
    /// - `twist_angle_deg`: Twist angle in degrees
    pub fn simple(
        lattice_type: &str,
        a: f64,
        r_over_a: f64,
        eps_bg: f64,
        eps_inside: f64,
        twist_angle_deg: f64,
    ) -> Self {
        let layer1 = Monolayer::simple(lattice_type, a, r_over_a, eps_bg, eps_inside);
        let layer2 = layer1.rotated(-twist_angle_deg);  // Negative for correct convention

        let twist_angle = twist_angle_deg.to_radians();
        let moire_length = compute_moire_length(a, twist_angle);

        let moire_lattice = match lattice_type.to_lowercase().as_str() {
            "square" => Lattice2D::square(moire_length),
            "triangular" | "hexagonal" => Lattice2D::hexagonal(moire_length),
            _ => Lattice2D::square(moire_length),
        };

        Self {
            layer1,
            layer2,
            twist_angle,
            moire_length,
            moire_lattice,
            combination: PermittivityCombination::Max,
        }
    }

    /// Get the moiré superlattice constant.
    pub fn moire_length(&self) -> f64 {
        self.moire_length
    }

    /// Get the twist angle in degrees.
    pub fn twist_angle_deg(&self) -> f64 {
        self.twist_angle.to_degrees()
    }

    /// Get the twist angle in radians.
    pub fn twist_angle_rad(&self) -> f64 {
        self.twist_angle
    }

    /// Get the moiré superlattice.
    pub fn moire_lattice(&self) -> &Lattice2D {
        &self.moire_lattice
    }

    /// Get permittivity at a Cartesian position.
    ///
    /// Combines the permittivity from both layers according to the
    /// combination rule.
    pub fn permittivity_at(&self, pos: [f64; 2]) -> f64 {
        let eps1 = self.layer1.permittivity_at(pos);
        let eps2 = self.layer2.permittivity_at(pos);

        self.combine_permittivity(eps1, eps2)
    }

    /// Combine permittivities according to the combination rule.
    fn combine_permittivity(&self, eps1: f64, eps2: f64) -> f64 {
        match self.combination {
            PermittivityCombination::Max => eps1.max(eps2),
            PermittivityCombination::Min => eps1.min(eps2),
            PermittivityCombination::Average => (eps1 + eps2) / 2.0,
            PermittivityCombination::Layer1First => {
                if (eps1 - self.layer1.eps_bg).abs() > 1e-10 {
                    eps1
                } else {
                    eps2
                }
            }
            PermittivityCombination::Layer2First => {
                if (eps2 - self.layer2.eps_bg).abs() > 1e-10 {
                    eps2
                } else {
                    eps1
                }
            }
        }
    }

    /// Sample permittivity on a grid.
    ///
    /// Returns a vector of permittivity values in row-major order.
    pub fn sample_permittivity(&self, grid: &Grid2D) -> Vec<f64> {
        let mut eps = vec![0.0; grid.len()];

        for iy in 0..grid.ny {
            for ix in 0..grid.nx {
                let idx = grid.idx(ix, iy);
                let pos = grid.cartesian_coords(ix, iy);
                eps[idx] = self.permittivity_at(pos);
            }
        }

        eps
    }

    /// Sample permittivity on a grid with subpixel smoothing (Meep-style).
    ///
    /// This method applies MPB/Meep-style subpixel averaging at material interfaces.
    /// It uses numerical integration with a sub-grid mesh to compute filling
    /// fractions at each grid point.
    ///
    /// # Arguments
    /// - `grid`: The computational grid
    /// - `subgrid_resolution`: Number of subpixel samples per dimension (typically 3-5)
    ///
    /// # Returns
    /// A vector of smoothed permittivity values in row-major order.
    pub fn sample_permittivity_smoothed(&self, grid: &Grid2D, subgrid_resolution: usize) -> Vec<f64> {
        let mesh = subgrid_resolution.max(1);
        let mut eps = vec![0.0; grid.len()];

        // Pixel size in physical units
        let dx = grid.lx / grid.nx as f64;
        let dy = grid.ly / grid.ny as f64;

        // Subpixel size
        let sub_dx = dx / mesh as f64;
        let sub_dy = dy / mesh as f64;
        let inv_mesh2 = 1.0 / (mesh * mesh) as f64;

        for iy in 0..grid.ny {
            for ix in 0..grid.nx {
                let idx = grid.idx(ix, iy);

                // Pixel center in Cartesian coordinates
                let center = grid.cartesian_coords(ix, iy);

                // Pixel corner (bottom-left of the pixel)
                let corner_x = center[0] - dx / 2.0;
                let corner_y = center[1] - dy / 2.0;

                // Integrate over sub-pixels
                let mut eps_sum = 0.0;
                for sub_y in 0..mesh {
                    for sub_x in 0..mesh {
                        let sample_x = corner_x + (sub_x as f64 + 0.5) * sub_dx;
                        let sample_y = corner_y + (sub_y as f64 + 0.5) * sub_dy;

                        eps_sum += self.permittivity_at([sample_x, sample_y]);
                    }
                }

                eps[idx] = eps_sum * inv_mesh2;
            }
        }

        eps
    }

    /// Sample permittivity with efficient tiled analytic smoothing.
    ///
    /// This method is much more efficient than smoothing the entire domain:
    /// 1. Compute analytic subpixel smoothing for ONE unit cell (using Blaze's Dielectric2D)
    /// 2. Tile the unit cell to create the full monolayer
    /// 3. For the second layer: copy, rotate (with margin), and clip
    /// 4. Combine pixel-by-pixel using min (air holes dominate)
    ///
    /// # Arguments
    /// - `grid`: The computational grid (centered on origin)
    /// - `resolution`: Grid points per lattice constant (for the unit cell)
    pub fn sample_permittivity_tiled_analytic(&self, grid: &Grid2D, resolution: usize) -> Vec<f64> {
        // Step 1: Create analytically smoothed unit cell for layer 1
        let a = self.layer1.lattice.characteristic_length();
        let unit_cell_grid = Grid2D::new(resolution, resolution, a, a);
        
        // Create geometry for one unit cell
        let unit_cell_geom = self.create_unit_cell_geometry(&self.layer1);
        
        // Use Blaze's analytic smoothing
        let opts = DielectricOptions {
            smoothing: SmoothingOptions {
                mesh_size: 3,
                interface_tolerance: 1e-6,
                method: SmoothingMethod::Analytic,
            },
        };
        let dielectric = Dielectric2D::from_geometry(&unit_cell_geom, unit_cell_grid, &opts);
        let unit_cell_eps = dielectric.eps();
        
        // Step 2: Tile the unit cell to create layer 1 matrix
        // We need to cover the grid plus margin for rotation
        let margin_cells = 2; // Extra cells for rotation margin
        let cells_x = (grid.lx / a).ceil() as usize + 2 * margin_cells;
        let cells_y = (grid.ly / a).ceil() as usize + 2 * margin_cells;
        
        let tiled_nx = cells_x * resolution;
        let tiled_ny = cells_y * resolution;
        let tiled_lx = cells_x as f64 * a;
        let tiled_ly = cells_y as f64 * a;
        
        // Tile the unit cell
        let mut layer1_eps = vec![self.layer1.eps_bg; tiled_nx * tiled_ny];
        for ty in 0..cells_y {
            for tx in 0..cells_x {
                for uy in 0..resolution {
                    for ux in 0..resolution {
                        let src_idx = uy * resolution + ux;
                        let dst_x = tx * resolution + ux;
                        let dst_y = ty * resolution + uy;
                        let dst_idx = dst_y * tiled_nx + dst_x;
                        layer1_eps[dst_idx] = unit_cell_eps[src_idx];
                    }
                }
            }
        }
        
        // Step 3: Create layer 2 by rotating layer 1
        // For identical layers, we just rotate the tiled matrix
        let layer2_eps = self.rotate_eps_matrix(
            &layer1_eps,
            tiled_nx, tiled_ny,
            tiled_lx, tiled_ly,
            -self.twist_angle, // Negative because we already negated in construction
        );
        
        // Step 4: Sample both layers at the output grid positions and combine
        let mut output_eps = vec![self.layer1.eps_bg; grid.len()];
        
        // Coordinate mapping:
        // - Tiled grid covers [0, tiled_lx] x [0, tiled_ly]
        // - Output grid is centered: [-lx/2, lx/2] x [-ly/2, ly/2]
        // - Unit cell has atom at fractional (0,0), so holes at corners of unit cells
        // - Adding a/2 shifts so a hole lands at the origin
        let dx = tiled_lx / tiled_nx as f64;
        let dy = tiled_ly / tiled_ny as f64;
        let offset_x = tiled_lx / 2.0 + a / 2.0;
        let offset_y = tiled_ly / 2.0 + a / 2.0;
        
        for iy in 0..grid.ny {
            for ix in 0..grid.nx {
                let idx = grid.idx(ix, iy);
                let pos = grid.cartesian_coords(ix, iy);
                
                // Map to tiled grid coordinates
                let tx = pos[0] + offset_x;
                let ty = pos[1] + offset_y;
                
                // Get indices in tiled grid
                let tix = ((tx / dx).floor() as usize).min(tiled_nx - 1);
                let tiy = ((ty / dy).floor() as usize).min(tiled_ny - 1);
                let tidx = tiy * tiled_nx + tix;
                
                // Get eps from both layers
                let eps1 = layer1_eps[tidx];
                let eps2 = layer2_eps[tidx];
                
                // Combine: min for air holes (eps closer to non-background)
                output_eps[idx] = self.combine_permittivity(eps1, eps2);
            }
        }
        
        output_eps
    }
    
    /// Create a Geometry2D for one unit cell of a monolayer.
    fn create_unit_cell_geometry(&self, layer: &Monolayer) -> Geometry2D {
        // Create a simple square/rectangular lattice for one unit cell
        let a = layer.lattice.characteristic_length();
        let unit_lattice = Lattice2D::square(a);
        
        // Convert atoms to the geometry format
        let atoms: Vec<BasisAtom> = layer.atoms.iter().map(|atom| {
            BasisAtom {
                pos: atom.pos,
                radius: atom.radius, // r_over_a
                eps_inside: atom.eps_inside,
            }
        }).collect();
        
        Geometry2D {
            lattice: unit_lattice,
            eps_bg: layer.eps_bg,
            atoms,
        }
    }
    
    /// Rotate an eps matrix by a given angle.
    /// 
    /// Uses bilinear interpolation for smooth rotation.
    fn rotate_eps_matrix(
        &self,
        eps: &[f64],
        nx: usize, ny: usize,
        lx: f64, ly: f64,
        angle: f64,
    ) -> Vec<f64> {
        let cos_a = angle.cos();
        let sin_a = angle.sin();
        
        let dx = lx / nx as f64;
        let dy = ly / ny as f64;
        
        // Center of the matrix
        let cx = lx / 2.0;
        let cy = ly / 2.0;
        
        let mut rotated = vec![self.layer1.eps_bg; nx * ny];
        
        for iy in 0..ny {
            for ix in 0..nx {
                // Position in physical coordinates (relative to center)
                let x = ix as f64 * dx - cx + dx / 2.0;
                let y = iy as f64 * dy - cy + dy / 2.0;
                
                // Rotate BACKWARDS to find source position
                // (we want to know where this pixel came from)
                let src_x = x * cos_a + y * sin_a + cx;
                let src_y = -x * sin_a + y * cos_a + cy;
                
                // Bilinear interpolation
                let fx = src_x / dx - 0.5;
                let fy = src_y / dy - 0.5;
                
                let ix0 = fx.floor() as isize;
                let iy0 = fy.floor() as isize;
                let tx = fx - ix0 as f64;
                let ty = fy - iy0 as f64;
                
                // Get the four surrounding pixels (with bounds checking)
                let get_eps = |iix: isize, iiy: isize| -> f64 {
                    if iix < 0 || iiy < 0 || iix >= nx as isize || iiy >= ny as isize {
                        self.layer1.eps_bg
                    } else {
                        eps[iiy as usize * nx + iix as usize]
                    }
                };
                
                let e00 = get_eps(ix0, iy0);
                let e10 = get_eps(ix0 + 1, iy0);
                let e01 = get_eps(ix0, iy0 + 1);
                let e11 = get_eps(ix0 + 1, iy0 + 1);
                
                // Bilinear interpolation
                let e0 = e00 * (1.0 - tx) + e10 * tx;
                let e1 = e01 * (1.0 - tx) + e11 * tx;
                let interpolated = e0 * (1.0 - ty) + e1 * ty;
                
                rotated[iy * nx + ix] = interpolated;
            }
        }
        
        rotated
    }

    /// Sample permittivity on a grid covering N×M moiré unit cells.
    ///
    /// # Arguments
    /// - `resolution`: Grid points per unit length (of original lattice constant)
    /// - `cells_x`, `cells_y`: Number of moiré cells to cover
    pub fn sample_moire_cells(
        &self,
        resolution: f64,
        cells_x: usize,
        cells_y: usize,
    ) -> (Grid2D, Vec<f64>) {
        let lx = self.moire_length * cells_x as f64;
        let ly = self.moire_length * cells_y as f64;
        let nx = (lx * resolution).round() as usize;
        let ny = (ly * resolution).round() as usize;

        let grid = Grid2D::new(nx, ny, lx, ly);
        let eps = self.sample_permittivity(&grid);

        (grid, eps)
    }

    /// Convert to a Geometry2D for compatibility with existing code.
    ///
    /// Note: This creates a "fake" geometry that only works for permittivity
    /// sampling. The atoms are approximated and won't be exact.
    pub fn to_geometry(&self, _grid: &Grid2D) -> Geometry2D {
        // We can't easily convert a moiré lattice to Geometry2D since it
        // has complex overlapping patterns. Instead, we create an empty
        // geometry and the caller should use sample_permittivity directly.
        Geometry2D {
            lattice: self.moire_lattice.clone(),
            eps_bg: self.layer1.eps_bg.max(self.layer2.eps_bg),
            atoms: vec![],
        }
    }

    /// Generate a Geometry2D with explicit atoms for use with Dielectric2D smoothing.
    ///
    /// This generates atoms at all lattice sites from both layers within the
    /// specified domain bounds. For moiré patterns, this can create MANY atoms.
    ///
    /// # Arguments
    /// - `bounds`: Physical extent of domain [x_min, x_max, y_min, y_max]
    /// - `margin`: Extra margin around bounds (in units of lattice constant a)
    pub fn to_explicit_geometry(&self, bounds: [f64; 4], margin: f64) -> Geometry2D {
        let [x_min, x_max, y_min, y_max] = bounds;
        let margin_phys = margin * self.layer1.lattice.characteristic_length();

        let extended_x_min = x_min - margin_phys;
        let extended_x_max = x_max + margin_phys;
        let extended_y_min = y_min - margin_phys;
        let extended_y_max = y_max + margin_phys;

        let mut all_atoms: Vec<BasisAtom> = Vec::new();

        // Generate atoms from layer 1
        let atoms1 = self.generate_layer_atoms(
            &self.layer1,
            [extended_x_min, extended_x_max, extended_y_min, extended_y_max],
        );
        all_atoms.extend(atoms1);

        // Generate atoms from layer 2
        let atoms2 = self.generate_layer_atoms(
            &self.layer2,
            [extended_x_min, extended_x_max, extended_y_min, extended_y_max],
        );
        all_atoms.extend(atoms2);

        // Create a simple square lattice that spans the domain
        // The atoms are in absolute Cartesian coordinates, so we use
        // a unit lattice centered at origin
        let domain_lx = x_max - x_min;
        let domain_ly = y_max - y_min;
        let domain_lattice = Lattice2D::rectangular(domain_lx, domain_ly);

        // Convert atoms to fractional coordinates relative to domain lattice
        // Origin at (x_min, y_min)
        let fractional_atoms: Vec<BasisAtom> = all_atoms
            .iter()
            .map(|atom| {
                // Convert Cartesian position to fractional in domain lattice
                let frac_x = (atom.pos[0] - x_min) / domain_lx;
                let frac_y = (atom.pos[1] - y_min) / domain_ly;
                BasisAtom {
                    pos: [frac_x, frac_y],
                    radius: atom.radius, // Already in lattice units
                    eps_inside: atom.eps_inside,
                }
            })
            .collect();

        Geometry2D {
            lattice: domain_lattice,
            eps_bg: self.layer1.eps_bg,
            atoms: fractional_atoms,
        }
    }

    /// Generate atoms from a single layer within the specified bounds.
    fn generate_layer_atoms(&self, layer: &Monolayer, bounds: [f64; 4]) -> Vec<BasisAtom> {
        let [x_min, x_max, y_min, y_max] = bounds;
        let a = layer.lattice.characteristic_length();

        // Estimate how many lattice sites we need
        let n_sites = ((x_max - x_min) / a).ceil() as i32 + 2;

        let mut atoms = Vec::new();

        // Generate lattice sites
        for ni in -n_sites..=n_sites {
            for nj in -n_sites..=n_sites {
                // Position in fractional coordinates of the layer
                let frac = [ni as f64, nj as f64];

                // Convert to Cartesian
                let cart = layer.lattice.fractional_to_cartesian(frac);

                // Check if within bounds
                if cart[0] >= x_min && cart[0] <= x_max && cart[1] >= y_min && cart[1] <= y_max {
                    // Add atoms at this lattice site
                    for atom in &layer.atoms {
                        // Atom position relative to lattice site
                        let atom_frac = [frac[0] + atom.pos[0], frac[1] + atom.pos[1]];
                        let atom_cart = layer.lattice.fractional_to_cartesian(atom_frac);

                        // Radius in physical units (atom.radius is r_over_a)
                        let radius_cart = atom.radius * a;

                        // Store as Cartesian position with physical radius
                        atoms.push(BasisAtom {
                            pos: atom_cart,
                            radius: radius_cart,
                            eps_inside: atom.eps_inside,
                        });
                    }
                }
            }
        }

        atoms
    }

    /// Export permittivity field to CSV.
    pub fn save_permittivity_csv(
        &self,
        grid: &Grid2D,
        path: &std::path::Path,
    ) -> std::io::Result<()> {
        use std::fs::File;
        use std::io::{BufWriter, Write};

        let eps = self.sample_permittivity(grid);
        let file = File::create(path)?;
        let mut writer = BufWriter::new(file);

        writeln!(writer, "# Moiré Permittivity Field")?;
        writeln!(writer, "# twist_angle_deg: {}", self.twist_angle_deg())?;
        writeln!(writer, "# moire_length: {}", self.moire_length)?;
        writeln!(writer, "# nx: {}, ny: {}", grid.nx, grid.ny)?;
        writeln!(writer, "# lx: {}, ly: {}", grid.lx, grid.ly)?;
        writeln!(writer, "ix,iy,x,y,eps")?;

        for iy in 0..grid.ny {
            for ix in 0..grid.nx {
                let idx = grid.idx(ix, iy);
                let pos = grid.cartesian_coords(ix, iy);
                writeln!(writer, "{},{},{},{},{}", ix, iy, pos[0], pos[1], eps[idx])?;
            }
        }

        Ok(())
    }

    /// Get statistics about the permittivity distribution.
    pub fn permittivity_stats(&self, grid: &Grid2D) -> PermittivityStats {
        let eps = self.sample_permittivity(grid);

        let min = eps.iter().cloned().fold(f64::INFINITY, f64::min);
        let max = eps.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
        let mean = eps.iter().sum::<f64>() / eps.len() as f64;

        // Count distinct values (for fill fraction estimation)
        let bg_eps = self.layer1.eps_bg;
        let inclusion_count = eps.iter().filter(|&&e| (e - bg_eps).abs() > 1e-10).count();
        let fill_fraction = inclusion_count as f64 / eps.len() as f64;

        PermittivityStats {
            min,
            max,
            mean,
            fill_fraction,
        }
    }
}

/// Statistics about a permittivity distribution.
#[derive(Debug, Clone)]
pub struct PermittivityStats {
    pub min: f64,
    pub max: f64,
    pub mean: f64,
    pub fill_fraction: f64,
}

// ============================================================================
// Helper functions
// ============================================================================

/// Compute the moiré superlattice constant.
///
/// L_m = a / (2 * sin(θ/2))
///
/// For small angles: L_m ≈ a / θ
pub fn compute_moire_length(a: f64, twist_angle_rad: f64) -> f64 {
    if twist_angle_rad.abs() < 1e-10 {
        // No twist, infinite moiré length
        f64::INFINITY
    } else {
        a / (2.0 * (twist_angle_rad / 2.0).sin())
    }
}

/// Compute the twist angle needed for a given moiré length.
///
/// θ = 2 * arcsin(a / (2 * L_m))
pub fn compute_twist_angle(a: f64, moire_length: f64) -> f64 {
    2.0 * (a / (2.0 * moire_length)).asin()
}

/// Rotate a 2D lattice by an angle.
fn rotate_lattice(lattice: &Lattice2D, angle: f64) -> Lattice2D {
    let cos_a = angle.cos();
    let sin_a = angle.sin();

    let a1 = [
        lattice.a1[0] * cos_a - lattice.a1[1] * sin_a,
        lattice.a1[0] * sin_a + lattice.a1[1] * cos_a,
    ];
    let a2 = [
        lattice.a2[0] * cos_a - lattice.a2[1] * sin_a,
        lattice.a2[0] * sin_a + lattice.a2[1] * cos_a,
    ];

    Lattice2D::oblique(a1, a2)
}

/// Wrap value to [0, 1).
fn wrap_unit(value: f64) -> f64 {
    value - value.floor()
}

/// Wrap value to [-0.5, 0.5) for minimum image convention.
fn wrap_signed(mut delta: f64) -> f64 {
    while delta >= 0.5 {
        delta -= 1.0;
    }
    while delta < -0.5 {
        delta += 1.0;
    }
    delta
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_moire_length_calculation() {
        let a = 1.0_f64;
        let theta_deg = 1.1_f64;
        let theta_rad = theta_deg.to_radians();

        let l_m = compute_moire_length(a, theta_rad);

        // Expected: L_m ≈ 52.1 for a=1, θ=1.1°
        assert!((l_m - 52.1).abs() < 0.5, "L_m = {}, expected ~52.1", l_m);
    }

    #[test]
    fn test_moire_length_small_angle_approx() {
        let a = 1.0_f64;
        let theta_deg = 1.0_f64;
        let theta_rad = theta_deg.to_radians();

        let l_m_exact = compute_moire_length(a, theta_rad);
        let l_m_approx = a / theta_rad; // Small angle approximation

        // Should be close for small angles
        let rel_error = (l_m_exact - l_m_approx).abs() / l_m_exact;
        assert!(rel_error < 0.001, "Relative error: {}", rel_error);
    }

    #[test]
    fn test_rotate_lattice() {
        let lattice = Lattice2D::square(1.0);
        let rotated = rotate_lattice(&lattice, PI / 4.0); // 45 degrees

        // After 45° rotation, a1 = [1, 0] becomes [cos(45), sin(45)]
        let expected_a1 = [0.5_f64.sqrt(), 0.5_f64.sqrt()];
        assert!((rotated.a1[0] - expected_a1[0]).abs() < 1e-10);
        assert!((rotated.a1[1] - expected_a1[1]).abs() < 1e-10);
    }

    #[test]
    fn test_monolayer_permittivity() {
        let layer = Monolayer::simple("square", 1.0, 0.3, 12.0, 1.0);

        // At center (0, 0), should be inside the atom → eps = 1.0
        let eps_center = layer.permittivity_at([0.0, 0.0]);
        assert!((eps_center - 1.0).abs() < 1e-10);

        // Far from center, should be background → eps = 12.0
        let eps_far = layer.permittivity_at([0.5, 0.5]);
        assert!((eps_far - 12.0).abs() < 1e-10);
    }

    #[test]
    fn test_moire_simple_creation() {
        let moire = MoireLattice::simple("square", 1.0, 0.22, 6.2, 1.0, 1.1);

        assert!((moire.moire_length() - 52.1).abs() < 0.5);
        assert!((moire.twist_angle_deg() - 1.1).abs() < 1e-10);
    }

    #[test]
    fn test_moire_permittivity_sampling() {
        let moire = MoireLattice::simple("square", 1.0, 0.22, 6.2, 1.0, 1.1);

        // Sample on a small grid
        let grid = Grid2D::new(10, 10, 5.0, 5.0);
        let eps = moire.sample_permittivity(&grid);

        // Should have some variation
        let min = eps.iter().cloned().fold(f64::INFINITY, f64::min);
        let max = eps.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
        assert!(min < max);
    }

    #[test]
    fn test_permittivity_combination_max() {
        let mut moire = MoireLattice::simple("square", 1.0, 0.3, 12.0, 1.0, 5.0);
        moire.combination = PermittivityCombination::Max;

        // Max of (12, 1) = 12, Max of (1, 12) = 12
        assert_eq!(moire.combine_permittivity(12.0, 1.0), 12.0);
        assert_eq!(moire.combine_permittivity(1.0, 12.0), 12.0);
    }

    #[test]
    fn test_permittivity_combination_min() {
        let mut moire = MoireLattice::simple("square", 1.0, 0.3, 12.0, 1.0, 5.0);
        moire.combination = PermittivityCombination::Min;

        assert_eq!(moire.combine_permittivity(12.0, 1.0), 1.0);
        assert_eq!(moire.combine_permittivity(1.0, 12.0), 1.0);
    }
}
