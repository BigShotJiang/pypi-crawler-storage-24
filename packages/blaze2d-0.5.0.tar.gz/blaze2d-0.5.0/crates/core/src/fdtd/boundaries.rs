//! Boundary conditions for FDTD simulations.
//!
//! This module defines the boundary conditions that can be applied at the
//! edges of the computational domain. The two main types are:
//!
//! - **PML (Perfectly Matched Layer)**: Absorbing boundaries for open systems
//! - **Periodic (Bloch)**: For infinite periodic structures like photonic crystals
//!
//! # Boundary Configuration
//!
//! Each boundary (x_lo, x_hi, y_lo, y_hi) can have its own condition.
//! Common configurations:
//!
//! - All PML: Open system, waves absorbed at all edges
//! - All Periodic: Infinite periodic structure (unit cell simulation)
//! - Mixed: Periodic in x, PML in y (e.g., waveguide simulation)

use serde::{Deserialize, Serialize};

use super::pml::PmlParams;

/// Type of boundary condition.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "lowercase")]
pub enum BoundaryCondition {
    /// Perfectly Matched Layer - absorbing boundary.
    #[default]
    Pml,
    /// Periodic boundary condition.
    /// Fields at one edge equal fields at opposite edge.
    Periodic,
    /// Bloch periodic boundary condition.
    /// Fields differ by a phase factor: F(x+L) = F(x) * exp(i*k*L)
    /// Requires specifying the Bloch wavevector.
    Bloch,
    /// Perfect Electric Conductor (PEC).
    /// Tangential E = 0 at boundary.
    Pec,
    /// Perfect Magnetic Conductor (PMC).
    /// Tangential H = 0 at boundary.
    Pmc,
}

impl BoundaryCondition {
    /// Check if this is an absorbing boundary.
    pub fn is_absorbing(&self) -> bool {
        matches!(self, Self::Pml)
    }

    /// Check if this is a periodic boundary.
    pub fn is_periodic(&self) -> bool {
        matches!(self, Self::Periodic | Self::Bloch)
    }
}

/// Configuration for a single boundary.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BoundarySide {
    /// Type of boundary condition
    pub condition: BoundaryCondition,
    /// PML parameters (only used if condition is PML)
    #[serde(default)]
    pub pml: Option<PmlParams>,
    /// Bloch wavevector component (only used if condition is Bloch)
    /// This is k_x or k_y depending on which boundary
    #[serde(default)]
    pub bloch_k: Option<f64>,
}

impl Default for BoundarySide {
    fn default() -> Self {
        Self {
            condition: BoundaryCondition::Pml,
            pml: Some(PmlParams::default()),
            bloch_k: None,
        }
    }
}

impl BoundarySide {
    /// Create a PML boundary with default parameters.
    pub fn pml() -> Self {
        Self {
            condition: BoundaryCondition::Pml,
            pml: Some(PmlParams::default()),
            bloch_k: None,
        }
    }

    /// Create a PML boundary with custom parameters.
    pub fn pml_with(params: PmlParams) -> Self {
        Self {
            condition: BoundaryCondition::Pml,
            pml: Some(params),
            bloch_k: None,
        }
    }

    /// Create a periodic boundary.
    pub fn periodic() -> Self {
        Self {
            condition: BoundaryCondition::Periodic,
            pml: None,
            bloch_k: None,
        }
    }

    /// Create a Bloch periodic boundary with given wavevector component.
    pub fn bloch(k: f64) -> Self {
        Self {
            condition: BoundaryCondition::Bloch,
            pml: None,
            bloch_k: Some(k),
        }
    }

    /// Create a PEC boundary.
    pub fn pec() -> Self {
        Self {
            condition: BoundaryCondition::Pec,
            pml: None,
            bloch_k: None,
        }
    }

    /// Create a PMC boundary.
    pub fn pmc() -> Self {
        Self {
            condition: BoundaryCondition::Pmc,
            pml: None,
            bloch_k: None,
        }
    }
}

/// Complete boundary configuration for all sides.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BoundaryConfig {
    /// Boundary at x = 0 (left)
    pub x_lo: BoundarySide,
    /// Boundary at x = Lx (right)
    pub x_hi: BoundarySide,
    /// Boundary at y = 0 (bottom)
    pub y_lo: BoundarySide,
    /// Boundary at y = Ly (top)
    pub y_hi: BoundarySide,
}

impl Default for BoundaryConfig {
    fn default() -> Self {
        Self::all_pml()
    }
}

impl BoundaryConfig {
    /// All boundaries are PML (open system).
    pub fn all_pml() -> Self {
        Self {
            x_lo: BoundarySide::pml(),
            x_hi: BoundarySide::pml(),
            y_lo: BoundarySide::pml(),
            y_hi: BoundarySide::pml(),
        }
    }

    /// All boundaries are PML with custom parameters.
    pub fn all_pml_with(params: PmlParams) -> Self {
        Self {
            x_lo: BoundarySide::pml_with(params.clone()),
            x_hi: BoundarySide::pml_with(params.clone()),
            y_lo: BoundarySide::pml_with(params.clone()),
            y_hi: BoundarySide::pml_with(params),
        }
    }

    /// All boundaries are periodic (infinite crystal).
    pub fn all_periodic() -> Self {
        Self {
            x_lo: BoundarySide::periodic(),
            x_hi: BoundarySide::periodic(),
            y_lo: BoundarySide::periodic(),
            y_hi: BoundarySide::periodic(),
        }
    }

    /// Periodic in x, PML in y.
    pub fn periodic_x_pml_y() -> Self {
        Self {
            x_lo: BoundarySide::periodic(),
            x_hi: BoundarySide::periodic(),
            y_lo: BoundarySide::pml(),
            y_hi: BoundarySide::pml(),
        }
    }

    /// PML in x, periodic in y.
    pub fn pml_x_periodic_y() -> Self {
        Self {
            x_lo: BoundarySide::pml(),
            x_hi: BoundarySide::pml(),
            y_lo: BoundarySide::periodic(),
            y_hi: BoundarySide::periodic(),
        }
    }

    /// Bloch periodic in x with given k_x, PML in y.
    pub fn bloch_x_pml_y(kx: f64) -> Self {
        Self {
            x_lo: BoundarySide::bloch(kx),
            x_hi: BoundarySide::bloch(kx),
            y_lo: BoundarySide::pml(),
            y_hi: BoundarySide::pml(),
        }
    }

    /// Check if x boundaries are periodic (regular or Bloch).
    pub fn is_periodic_x(&self) -> bool {
        self.x_lo.condition.is_periodic() && self.x_hi.condition.is_periodic()
    }

    /// Check if y boundaries are periodic (regular or Bloch).
    pub fn is_periodic_y(&self) -> bool {
        self.y_lo.condition.is_periodic() && self.y_hi.condition.is_periodic()
    }

    /// Check if x boundaries use PML.
    pub fn has_pml_x(&self) -> bool {
        self.x_lo.condition == BoundaryCondition::Pml
            || self.x_hi.condition == BoundaryCondition::Pml
    }

    /// Check if y boundaries use PML.
    pub fn has_pml_y(&self) -> bool {
        self.y_lo.condition == BoundaryCondition::Pml
            || self.y_hi.condition == BoundaryCondition::Pml
    }

    /// Get the PML thickness for x boundaries (returns 0 if no PML).
    pub fn pml_thickness_x(&self) -> usize {
        let lo = self
            .x_lo
            .pml
            .as_ref()
            .map(|p| p.thickness)
            .unwrap_or(0);
        let hi = self
            .x_hi
            .pml
            .as_ref()
            .map(|p| p.thickness)
            .unwrap_or(0);
        lo.max(hi)
    }

    /// Get the PML thickness for y boundaries (returns 0 if no PML).
    pub fn pml_thickness_y(&self) -> usize {
        let lo = self
            .y_lo
            .pml
            .as_ref()
            .map(|p| p.thickness)
            .unwrap_or(0);
        let hi = self
            .y_hi
            .pml
            .as_ref()
            .map(|p| p.thickness)
            .unwrap_or(0);
        lo.max(hi)
    }

    /// Get array of which boundaries have PML: [x_lo, x_hi, y_lo, y_hi]
    pub fn pml_enabled(&self) -> [bool; 4] {
        [
            self.x_lo.condition == BoundaryCondition::Pml,
            self.x_hi.condition == BoundaryCondition::Pml,
            self.y_lo.condition == BoundaryCondition::Pml,
            self.y_hi.condition == BoundaryCondition::Pml,
        ]
    }

    /// Validate boundary configuration.
    ///
    /// Returns an error message if the configuration is invalid.
    pub fn validate(&self) -> Result<(), String> {
        // Periodic boundaries must come in pairs
        if self.x_lo.condition.is_periodic() != self.x_hi.condition.is_periodic() {
            return Err("Periodic boundaries must be applied to both x_lo and x_hi".to_string());
        }
        if self.y_lo.condition.is_periodic() != self.y_hi.condition.is_periodic() {
            return Err("Periodic boundaries must be applied to both y_lo and y_hi".to_string());
        }

        // Bloch boundaries must have matching k values
        if self.x_lo.condition == BoundaryCondition::Bloch {
            if self.x_lo.bloch_k != self.x_hi.bloch_k {
                return Err("Bloch k values must match for x boundaries".to_string());
            }
            if self.x_lo.bloch_k.is_none() {
                return Err("Bloch boundaries require bloch_k to be specified".to_string());
            }
        }
        if self.y_lo.condition == BoundaryCondition::Bloch {
            if self.y_lo.bloch_k != self.y_hi.bloch_k {
                return Err("Bloch k values must match for y boundaries".to_string());
            }
            if self.y_lo.bloch_k.is_none() {
                return Err("Bloch boundaries require bloch_k to be specified".to_string());
            }
        }

        Ok(())
    }
}

/// Helper for applying periodic boundary conditions.
pub struct PeriodicBoundary;

impl PeriodicBoundary {
    /// Wrap an index with periodic boundary conditions.
    #[inline]
    pub fn wrap(idx: isize, size: usize) -> usize {
        let n = size as isize;
        ((idx % n) + n) as usize % size
    }

    /// Get the index for accessing a neighbor with periodic wrapping.
    #[inline]
    pub fn neighbor_x(ix: usize, offset: isize, nx: usize) -> usize {
        Self::wrap(ix as isize + offset, nx)
    }

    #[inline]
    pub fn neighbor_y(iy: usize, offset: isize, ny: usize) -> usize {
        Self::wrap(iy as isize + offset, ny)
    }
}

/// Helper for applying Bloch periodic boundary conditions.
///
/// For Bloch boundaries: F(x+L) = F(x) * exp(i*k*L)
/// Since we work with real fields in FDTD, we need to handle the
/// phase factor specially (typically by storing complex amplitudes
/// or using two real fields for real/imaginary parts).
pub struct BlochBoundary {
    /// Bloch phase factor exp(i*k*L) for x direction
    pub phase_x: (f64, f64), // (cos(k*Lx), sin(k*Lx))
    /// Bloch phase factor for y direction  
    pub phase_y: (f64, f64),
}

impl BlochBoundary {
    /// Create Bloch boundary helper from k-vector and domain size.
    pub fn new(kx: f64, ky: f64, lx: f64, ly: f64) -> Self {
        let phi_x = kx * lx;
        let phi_y = ky * ly;
        Self {
            phase_x: (phi_x.cos(), phi_x.sin()),
            phase_y: (phi_y.cos(), phi_y.sin()),
        }
    }

    /// Apply Bloch phase when reading from opposite boundary in x.
    /// Returns (real_part, imag_part) of the phase-shifted value.
    pub fn apply_phase_x(&self, value: f64) -> (f64, f64) {
        (value * self.phase_x.0, value * self.phase_x.1)
    }

    /// Apply Bloch phase when reading from opposite boundary in y.
    pub fn apply_phase_y(&self, value: f64) -> (f64, f64) {
        (value * self.phase_y.0, value * self.phase_y.1)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_boundary_config_default() {
        let config = BoundaryConfig::default();
        assert_eq!(config.x_lo.condition, BoundaryCondition::Pml);
        assert!(config.has_pml_x());
        assert!(config.has_pml_y());
    }

    #[test]
    fn test_all_periodic() {
        let config = BoundaryConfig::all_periodic();
        assert!(config.is_periodic_x());
        assert!(config.is_periodic_y());
        assert!(!config.has_pml_x());
    }

    #[test]
    fn test_mixed_boundaries() {
        let config = BoundaryConfig::periodic_x_pml_y();
        assert!(config.is_periodic_x());
        assert!(!config.is_periodic_y());
        assert!(!config.has_pml_x());
        assert!(config.has_pml_y());
    }

    #[test]
    fn test_validate_valid() {
        let config = BoundaryConfig::all_pml();
        assert!(config.validate().is_ok());

        let config = BoundaryConfig::all_periodic();
        assert!(config.validate().is_ok());
    }

    #[test]
    fn test_validate_invalid_periodic() {
        let mut config = BoundaryConfig::all_pml();
        config.x_lo.condition = BoundaryCondition::Periodic;
        // x_hi is still PML - invalid
        assert!(config.validate().is_err());
    }

    #[test]
    fn test_periodic_wrap() {
        assert_eq!(PeriodicBoundary::wrap(0, 10), 0);
        assert_eq!(PeriodicBoundary::wrap(9, 10), 9);
        assert_eq!(PeriodicBoundary::wrap(10, 10), 0);
        assert_eq!(PeriodicBoundary::wrap(-1, 10), 9);
        assert_eq!(PeriodicBoundary::wrap(-10, 10), 0);
    }

    #[test]
    fn test_pml_enabled() {
        let config = BoundaryConfig::periodic_x_pml_y();
        let enabled = config.pml_enabled();
        assert_eq!(enabled, [false, false, true, true]);
    }
}
