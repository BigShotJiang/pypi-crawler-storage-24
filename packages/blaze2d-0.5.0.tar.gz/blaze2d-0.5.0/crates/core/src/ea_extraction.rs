//! Envelope-approximation Hamiltonian ingredient extraction.
//!
//! This module computes the matrix elements and physical quantities needed
//! to assemble the multi-band envelope Hamiltonian for moiré photonic crystals.
//!
//! # Physical setup
//!
//! At each registry point **R** and carrier momentum **k₀**, we solve the local
//! Maxwell eigenproblem and extract:
//!
//! 1. **Eigenvalues** λₙ and **eigenvectors** uₙ
//! 2. **Velocity matrices** v^(i)_mn = ⟨uₘ|∂L₀/∂kᵢ|uₙ⟩
//! 3. **Second-derivative elements** w^(ij)_mn = ⟨uₘ|∂²L₀/∂kᵢ∂kⱼ|uₙ⟩
//! 4. **Effective mass tensor** M⁻¹_{ij,mn} (Löwdin-corrected)
//! 5. **R-derivative matrix elements** ⟨uₘ|∂L₀/∂Rⱼ|uₙ⟩
//! 6. **Born–Huang potential** Φ_mn
//! 7. **Overlap matrices** S_mn(R→R') for gauge transport
//!
//! # Units
//!
//! All quantities are in **eigenvalue units**: λ = (ω/c)² in (2π/a)².
//! This is consistent with the Rust eigensolver which stores eigenvalues as
//! λ = ω² (with c = 1 and lengths in units of the lattice constant a).
//!
//! The k-vectors are in units of 2π/a (Cartesian reciprocal space).
//! Registry coordinates R are in fractional lattice coordinates.
//!
//! # Inner products
//!
//! - **TE**: standard ⟨u|v⟩ = (1/N) Σ_G u*(G) v(G)  (identity mass)
//! - **TM**: B-weighted ⟨u|v⟩_B = (1/N) Σ_r u*(r) ε(r) v(r)
//!
//! The dot product from `SpectralBackend::dot` computes u†·v without the 1/N
//! normalization, so we divide by grid_size where needed. However, since the
//! eigenvectors are already B-orthonormal (from the solver), these normalizations
//! are consistent.
//!
//! # Polarization handling
//!
//! - **TE**: L₀ is the standard eigenproblem operator. `apply_dL_dk` etc. apply
//!   derivatives of L₀ directly. Inner products are unweighted.
//!
//! - **TM**: The eigenproblem is Au = λBu (generalized). The perturbation theory
//!   for the generalized eigenproblem gives:
//!
//!   v^(i)_mn = ⟨uₘ|∂A/∂kᵢ|uₙ⟩_B / ⟨uₘ|B|uₙ⟩ - λₙ·⟨uₘ|∂B/∂kᵢ|uₙ⟩_B / ⟨uₘ|B|uₙ⟩
//!
//!   Since B doesn't depend on k (ε is independent of k), this simplifies to
//!   v^(i)_mn = ⟨uₘ|∂A/∂kᵢ|uₙ⟩ (using B-orthonormality ⟨uₘ|B|uₙ⟩ = δ_mn).
//!
//!   But the inner product ⟨·|·⟩ means the B-weighted one, and ∂A/∂kᵢ is applied
//!   by `apply_dL_dk`, so we need: v^(i)_mn = ⟨uₘ|∂A/∂kᵢ|uₙ⟩_std where the
//!   eigenvectors satisfy ⟨uₘ|B|uₙ⟩_std = δ_mn.
//!
//!   In practice, since the eigensolver stores B-orthonormal eigenvectors, we
//!   compute: v^(i)_mn = dot(uₘ, ∂A/∂kᵢ · uₙ) for both TE and TM, because
//!   ∂A/∂kᵢ is already the correctly differentiated part of the operator.

use num_complex::Complex64;

use crate::backend::{SpectralBackend, SpectralBuffer};
use crate::dielectric::DielectricDerivative;
use crate::field::Field2D;
use crate::operators::maxwell::ThetaOperator;
use crate::operators::LinearOperator;
use crate::polarization::Polarization;

// ============================================================================
// EA Ingredients — the output data structure
// ============================================================================

/// Which inner product convention is in use.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum InnerProductKind {
    /// Standard unweighted ⟨u|v⟩ (TE mode).
    Standard,
    /// B-weighted ⟨u|B|v⟩ where B = ε(r) (TM mode).
    BWeighted,
}

impl InnerProductKind {
    pub fn from_polarization(pol: Polarization) -> Self {
        match pol {
            Polarization::TE => Self::Standard,
            Polarization::TM => Self::BWeighted,
        }
    }

    pub fn label(&self) -> &'static str {
        match self {
            Self::Standard => "standard",
            Self::BWeighted => "B_weighted",
        }
    }
}

/// All EA Hamiltonian ingredients extracted at one (R, k₀) point.
///
/// Matrix elements are stored in **row-major** order: for a matrix M_{mn},
/// the element at (m, n) is at index `m * n_cols + n`.
///
/// # Units
///
/// | Quantity | Units | Description |
/// |----------|-------|-------------|
/// | eigenvalues | (2π/a)² | λ = (ω/c)², same as eigensolver output |
/// | velocity_matrices | (2π/a)² per (2π/a) = (2π/a) | ∂λ/∂k derivative units |
/// | w_matrices | (2π/a)² per (2π/a)² = dimensionless | ∂²λ/∂k² units |
/// | mass_tensor_inv | same as w_matrices | Löwdin-corrected ∂²λ/∂k² |
/// | r_derivative_matrices | (2π/a)² / fractional | ∂λ/∂R, R in frac. coords |
/// | born_huang | (2π/a)² | scalar potential units |
/// | k0 | 2π/a | Cartesian k-vector |
/// | registry | fractional | atom shift in lattice units |
#[derive(Debug, Clone)]
pub struct EAIngredients {
    // -- Metadata --
    pub polarization: Polarization,
    pub inner_product: InnerProductKind,
    /// Carrier momentum k₀ in Cartesian reciprocal-space units (2π/a).
    pub k0: [f64; 2],
    /// Registry point (fractional atom shift coordinates).
    pub registry: [f64; 2],
    pub n_retained: usize,
    pub n_remote: usize,
    pub grid_dims: [usize; 2],

    // -- Eigensystem --
    /// Eigenvalues λₙ for ALL n_total = n_retained + n_remote bands.
    /// Units: (2π/a)².
    pub eigenvalues: Vec<f64>,

    /// Eigenvectors as Fourier coefficients. Shape: [n_total][grid_size].
    /// Complex64 values in the same representation as the solver output.
    pub eigenvectors: Vec<Vec<Complex64>>,

    // -- First-order: velocity matrices --
    /// v^(i)_{mn} = ⟨uₘ|∂L₀/∂kᵢ|uₙ⟩
    /// Shape per direction: [n_retained × n_total], row-major.
    /// Units: (2π/a) (eigenvalue per k-unit).
    pub velocity_matrices: [Vec<Complex64>; 2],

    // -- Second-order: raw operator 2nd derivatives --
    /// w^(ij)_{mn} = ⟨uₘ|∂²L₀/∂kᵢ∂kⱼ|uₙ⟩
    /// Shape: [n_retained × n_retained], row-major.
    /// Units: dimensionless (eigenvalue per k²-unit).
    pub w_matrices: [[Vec<Complex64>; 2]; 2],

    // -- Second-order: Löwdin-corrected mass tensor --
    /// M⁻¹_{ij,mn} including remote-band Löwdin sums.
    /// Shape: [n_retained × n_retained], row-major.
    /// Units: dimensionless.
    pub mass_tensor_inv: [[Vec<Complex64>; 2]; 2],

    // -- Registry-derivative matrix elements --
    /// ⟨uₘ|∂L₀/∂Rⱼ|uₙ⟩, shape: [n_retained × n_total], row-major.
    /// Units: (2π/a)² / fractional.
    /// None if R-derivatives were not requested.
    pub r_derivative_matrices: Option<[Vec<Complex64>; 2]>,

    // -- Born–Huang potential --
    /// Φ_{mn}(R), shape: [n_retained × n_retained], row-major.
    /// Units: (2π/a)².
    /// None if Born–Huang was not requested.
    pub born_huang: Option<Vec<Complex64>>,

    // -- Overlap matrix for gauge transport --
    /// S_{mn} = ⟨uₘ(R)|uₙ(R')⟩, shape: [n_retained × n_retained], row-major.
    /// None if overlap was not requested.
    pub overlap_matrix: Option<Vec<Complex64>>,

    // -- Solver metadata --
    pub n_iterations: usize,
    pub converged: bool,
}

// ============================================================================
// EA Extraction Configuration
// ============================================================================

/// Configuration for what to extract.
#[derive(Debug, Clone)]
pub struct EAExtractionConfig {
    /// Number of bands to keep in the retained (active) subspace.
    pub n_retained: usize,
    /// Number of additional remote bands to compute for Löwdin sums.
    pub n_remote: usize,
    /// Whether to compute the Löwdin-corrected mass tensor.
    pub compute_mass_tensor: bool,
    /// Whether to compute Born–Huang matrix elements.
    pub compute_born_huang: bool,
    /// Whether to compute overlap matrix with reference eigenvectors.
    pub compute_overlap: bool,
}

impl Default for EAExtractionConfig {
    fn default() -> Self {
        Self {
            n_retained: 4,
            n_remote: 8,
            compute_mass_tensor: true,
            compute_born_huang: false,
            compute_overlap: false,
        }
    }
}

// ============================================================================
// EA Extractor — the computation engine
// ============================================================================

/// Extracts EA Hamiltonian ingredients from a solved eigenproblem.
///
/// # Typical usage
///
/// ```ignore
/// let extractor = EAExtractor::new(&operator, &eigenvectors, &eigenvalues, config);
/// let ingredients = extractor.extract(
///     k0, registry,
///     dielectric_derivs.as_deref(),
///     reference_eigvecs.as_deref(),
///     solver_metadata,
/// );
/// ```
pub struct EAExtractor<'a, B: SpectralBackend> {
    operator: &'a mut ThetaOperator<B>,
    eigenvectors: &'a [Field2D],
    eigenvalues: &'a [f64],
    config: EAExtractionConfig,
}

impl<'a, B: SpectralBackend> EAExtractor<'a, B> {
    pub fn new(
        operator: &'a mut ThetaOperator<B>,
        eigenvectors: &'a [Field2D],
        eigenvalues: &'a [f64],
        config: EAExtractionConfig,
    ) -> Self {
        let n_total = config.n_retained + config.n_remote;
        assert!(
            eigenvectors.len() >= n_total,
            "Need at least {} eigenvectors (got {})",
            n_total,
            eigenvectors.len()
        );
        assert!(
            eigenvalues.len() >= n_total,
            "Need at least {} eigenvalues (got {})",
            n_total,
            eigenvalues.len()
        );
        Self {
            operator,
            eigenvectors,
            eigenvalues,
            config,
        }
    }

    /// Run the full extraction pipeline.
    ///
    /// # Arguments
    ///
    /// * `k0` — Carrier momentum (Cartesian, 2π/a units)
    /// * `registry` — Registry point (fractional coordinates)
    /// * `diel_derivs` — Optional dielectric derivatives for ∂L₀/∂Rⱼ (2 directions)
    /// * `reference_eigvecs` — Optional eigenvectors from a neighboring R for overlap matrix
    /// * `n_iterations` — Solver iteration count (metadata)
    /// * `converged` — Whether the solver converged (metadata)
    pub fn extract(
        &mut self,
        k0: [f64; 2],
        registry: [f64; 2],
        diel_derivs: Option<&[DielectricDerivative; 2]>,
        reference_eigvecs: Option<&[Field2D]>,
        n_iterations: usize,
        converged: bool,
    ) -> EAIngredients {
        let n_ret = self.config.n_retained;
        let n_total = n_ret + self.config.n_remote;
        let grid = self.operator.grid();
        let pol = self.operator.polarization();
        let inner_product = InnerProductKind::from_polarization(pol);

        // Collect eigenvalues and eigenvectors
        let eigenvalues = self.eigenvalues[..n_total].to_vec();
        let eigenvectors: Vec<Vec<Complex64>> = self.eigenvectors[..n_total]
            .iter()
            .map(|f| {
                f.as_slice()
                    .iter()
                    .map(|&c| Complex64::new(c.re as f64, c.im as f64))
                    .collect()
            })
            .collect();

        // -- Velocity matrices v^(i)_mn --
        let velocity_matrices = self.compute_velocity_matrices(n_ret, n_total);

        // -- Second-derivative elements w^(ij)_mn --
        let w_matrices = self.compute_w_matrices(n_ret);

        // -- Mass tensor M⁻¹_{ij,mn} --
        let mass_tensor_inv = if self.config.compute_mass_tensor {
            self.compute_mass_tensor(&velocity_matrices, &w_matrices, n_ret, n_total)
        } else {
            // Just copy w_matrices as a placeholder (no Löwdin correction)
            w_matrices.clone()
        };

        // -- R-derivative matrix elements --
        let r_derivative_matrices = diel_derivs.map(|derivs| {
            self.compute_r_derivative_matrices(derivs, n_ret, n_total)
        });

        // -- Born–Huang potential --
        let born_huang = if self.config.compute_born_huang {
            r_derivative_matrices.as_ref().map(|r_mats| {
                self.compute_born_huang(r_mats, n_ret, n_total)
            })
        } else {
            None
        };

        // -- Overlap matrix --
        let overlap_matrix = if self.config.compute_overlap {
            reference_eigvecs.map(|ref_vecs| {
                self.compute_overlap_matrix(ref_vecs, n_ret, pol)
            })
        } else {
            None
        };

        EAIngredients {
            polarization: pol,
            inner_product,
            k0,
            registry,
            n_retained: n_ret,
            n_remote: self.config.n_remote,
            grid_dims: [grid.nx, grid.ny],
            eigenvalues,
            eigenvectors,
            velocity_matrices,
            w_matrices,
            mass_tensor_inv,
            r_derivative_matrices,
            born_huang,
            overlap_matrix,
            n_iterations,
            converged,
        }
    }

    // ========================================================================
    // Velocity matrices: v^(i)_mn = ⟨uₘ|∂L₀/∂kᵢ|uₙ⟩
    // ========================================================================

    fn compute_velocity_matrices(
        &mut self,
        n_ret: usize,
        n_total: usize,
    ) -> [Vec<Complex64>; 2] {
        let mut v = [
            vec![Complex64::new(0.0, 0.0); n_ret * n_total],
            vec![Complex64::new(0.0, 0.0); n_ret * n_total],
        ];

        let mut scratch = self.operator.alloc_field();

        for dir in 0..2 {
            for n in 0..n_total {
                // Apply ∂L₀/∂kᵢ to uₙ → scratch
                let u_n = self.eigenvector_buffer(n);
                self.operator.apply_dL_dk(&u_n, &mut scratch, dir);

                // Compute ⟨uₘ|result⟩ for m ∈ retained bands
                for m in 0..n_ret {
                    let u_m = self.eigenvector_buffer(m);
                    let element = self.operator.backend().dot(&u_m, &scratch);
                    v[dir][m * n_total + n] = element;
                }

                self.return_buffer(u_n);
            }
        }

        v
    }

    // ========================================================================
    // Second-derivative elements: w^(ij)_mn = ⟨uₘ|∂²L₀/∂kᵢ∂kⱼ|uₙ⟩
    // ========================================================================

    fn compute_w_matrices(&mut self, n_ret: usize) -> [[Vec<Complex64>; 2]; 2] {
        let mut w = [[
            vec![Complex64::new(0.0, 0.0); n_ret * n_ret],
            vec![Complex64::new(0.0, 0.0); n_ret * n_ret],
        ], [
            vec![Complex64::new(0.0, 0.0); n_ret * n_ret],
            vec![Complex64::new(0.0, 0.0); n_ret * n_ret],
        ]];

        let mut scratch = self.operator.alloc_field();

        for i in 0..2 {
            for j in 0..2 {
                for n in 0..n_ret {
                    let u_n = self.eigenvector_buffer(n);
                    self.operator.apply_d2L_dk2(&u_n, &mut scratch, i, j);

                    for m in 0..n_ret {
                        let u_m = self.eigenvector_buffer(m);
                        let element = self.operator.backend().dot(&u_m, &scratch);
                        w[i][j][m * n_ret + n] = element;
                        self.return_buffer(u_m);
                    }

                    self.return_buffer(u_n);
                }
            }
        }

        w
    }

    // ========================================================================
    // Löwdin-corrected mass tensor
    // ========================================================================
    //
    // M⁻¹_{ij,mn} = w^(ij)_{mn} + Σ_{ℓ∉S} [ v^(i)_{mℓ} v^(j)_{ℓn} / (λₙ - λℓ)
    //                                        + v^(j)_{mℓ} v^(i)_{ℓn} / (λₘ - λℓ) ]
    //
    // where S is the retained set {1..n_ret} and ℓ runs over remote bands.

    fn compute_mass_tensor(
        &self,
        velocity: &[Vec<Complex64>; 2],
        w: &[[Vec<Complex64>; 2]; 2],
        n_ret: usize,
        n_total: usize,
    ) -> [[Vec<Complex64>; 2]; 2] {
        let eigenvalues = &self.eigenvalues[..n_total];
        let mut m_inv = [[
            vec![Complex64::new(0.0, 0.0); n_ret * n_ret],
            vec![Complex64::new(0.0, 0.0); n_ret * n_ret],
        ], [
            vec![Complex64::new(0.0, 0.0); n_ret * n_ret],
            vec![Complex64::new(0.0, 0.0); n_ret * n_ret],
        ]];

        for i in 0..2 {
            for j in 0..2 {
                for m in 0..n_ret {
                    for n in 0..n_ret {
                        let idx = m * n_ret + n;

                        // Start with the direct second-derivative element
                        let mut val = w[i][j][idx];

                        // Add Löwdin sum over remote bands ℓ ∉ {0..n_ret}
                        for ell in n_ret..n_total {
                            let lambda_n = eigenvalues[n];
                            let lambda_m = eigenvalues[m];
                            let lambda_ell = eigenvalues[ell];

                            // v^(i)_{m,ℓ} and v^(j)_{ℓ,n}
                            // velocity layout: v[dir][m * n_total + n], shape [n_ret × n_total]
                            let v_i_m_ell = velocity[i][m * n_total + ell];

                            // We need ⟨uℓ|∂L/∂kⱼ|uₙ⟩ for ℓ ≥ n_ret. Since ∂L₀/∂kᵢ
                            // is Hermitian (L₀(k) is a Hermitian family):
                            //   ⟨uℓ|∂L₀/∂kᵢ|uₙ⟩ = ⟨uₙ|∂L₀/∂kᵢ|uℓ⟩*
                            let v_j_ell_n = velocity[j][n * n_total + ell].conj();

                            let v_j_m_ell = velocity[j][m * n_total + ell];
                            let v_i_ell_n = velocity[i][n * n_total + ell].conj();

                            // Löwdin contribution:
                            //   v^(i)_{m,ℓ} v^(j)_{ℓ,n} / (λₙ - λℓ)
                            // + v^(j)_{m,ℓ} v^(i)_{ℓ,n} / (λₘ - λℓ)

                            let denom_n = lambda_n - lambda_ell;
                            let denom_m = lambda_m - lambda_ell;

                            // Guard against near-degeneracy (shouldn't happen for remote bands)
                            if denom_n.abs() > 1e-15 {
                                val += v_i_m_ell * v_j_ell_n / denom_n;
                            }
                            if denom_m.abs() > 1e-15 {
                                val += v_j_m_ell * v_i_ell_n / denom_m;
                            }
                        }

                        m_inv[i][j][idx] = val;
                    }
                }
            }
        }

        m_inv
    }

    // ========================================================================
    // R-derivative matrix elements: ⟨uₘ|∂L₀/∂Rⱼ|uₙ⟩
    // ========================================================================

    fn compute_r_derivative_matrices(
        &mut self,
        diel_derivs: &[DielectricDerivative; 2],
        n_ret: usize,
        n_total: usize,
    ) -> [Vec<Complex64>; 2] {
        let mut r_mats = [
            vec![Complex64::new(0.0, 0.0); n_ret * n_total],
            vec![Complex64::new(0.0, 0.0); n_ret * n_total],
        ];

        let mut scratch = self.operator.alloc_field();

        for dir in 0..2 {
            for n in 0..n_total {
                let u_n = self.eigenvector_buffer(n);
                self.operator.apply_dL_dR(&u_n, &mut scratch, &diel_derivs[dir]);

                for m in 0..n_ret {
                    let u_m = self.eigenvector_buffer(m);
                    let element = self.operator.backend().dot(&u_m, &scratch);
                    r_mats[dir][m * n_total + n] = element;
                    self.return_buffer(u_m);
                }

                self.return_buffer(u_n);
            }
        }

        r_mats
    }

    // ========================================================================
    // Born–Huang potential
    // ========================================================================
    //
    // Φ_{mn}(R) = Σ_j Σ_{ℓ∉S} ⟨∂Rⱼ uₘ|(1-P)|∂Rⱼ uₙ⟩
    //
    // Using perturbation theory:
    //   ⟨uℓ|∂Rⱼ uₙ⟩ = ⟨uℓ|∂L₀/∂Rⱼ|uₙ⟩ / (λₙ - λℓ)
    //
    // So:
    //   Φ_{mn} = Σ_j Σ_{ℓ∉S} [⟨uℓ|∂L₀/∂Rⱼ|uₘ⟩* ⟨uℓ|∂L₀/∂Rⱼ|uₙ⟩] / [(λₘ - λℓ)(λₙ - λℓ)]
    //
    // Using Hermiticity of ∂L₀/∂Rⱼ:
    //   ⟨uℓ|∂L₀/∂Rⱼ|uₘ⟩ = ⟨uₘ|∂L₀/∂Rⱼ|uℓ⟩* = r_mats[j][m * n_total + ℓ]*

    fn compute_born_huang(
        &self,
        r_mats: &[Vec<Complex64>; 2],
        n_ret: usize,
        n_total: usize,
    ) -> Vec<Complex64> {
        let eigenvalues = &self.eigenvalues[..n_total];
        let mut phi = vec![Complex64::new(0.0, 0.0); n_ret * n_ret];

        for m in 0..n_ret {
            for n in 0..n_ret {
                let idx = m * n_ret + n;
                let lambda_m = eigenvalues[m];
                let lambda_n = eigenvalues[n];

                for dir in 0..2 {
                    for ell in n_ret..n_total {
                        let lambda_ell = eigenvalues[ell];
                        let denom_m = lambda_m - lambda_ell;
                        let denom_n = lambda_n - lambda_ell;

                        if denom_m.abs() > 1e-15 && denom_n.abs() > 1e-15 {
                            // ⟨uℓ|∂L₀/∂Rⱼ|uₘ⟩ = r_mats[dir][m * n_total + ell]* (Hermiticity)
                            // ⟨uℓ|∂L₀/∂Rⱼ|uₙ⟩ = r_mats[dir][n * n_total + ell]* (Hermiticity)
                            // Wait: r_mats[dir][m * n_total + ell] = ⟨uₘ|∂L₀/∂Rⱼ|uℓ⟩
                            // We need ⟨uℓ|∂L₀/∂Rⱼ|uₘ⟩ = conj of the above (Hermiticity of ∂L₀/∂Rⱼ)
                            // So: ⟨uℓ|∂L₀/∂Rⱼ|uₘ⟩ = r_mats[dir][m * n_total + ell].conj()

                            let r_ell_m = r_mats[dir][m * n_total + ell].conj();
                            let r_ell_n = r_mats[dir][n * n_total + ell].conj();

                            phi[idx] += r_ell_m.conj() * r_ell_n / (denom_m * denom_n);
                        }
                    }
                }
            }
        }

        phi
    }

    // ========================================================================
    // Overlap matrix: S_mn = ⟨uₘ(R)|uₙ(R')⟩
    // ========================================================================

    fn compute_overlap_matrix(
        &mut self,
        reference_eigvecs: &[Field2D],
        n_ret: usize,
        _pol: Polarization,
    ) -> Vec<Complex64> {
        let mut overlap = vec![Complex64::new(0.0, 0.0); n_ret * n_ret];
        let n_ref = reference_eigvecs.len().min(n_ret);

        for n in 0..n_ref {
            // For TE: ⟨uₘ|uₙ'⟩ = dot(uₘ, uₙ')
            // For TM: ⟨uₘ|B|uₙ'⟩ = dot(uₘ, B·uₙ')
            // apply_mass handles both cases (identity for TE, ε multiply for TM)
            let u_n_ref = self.field_to_buffer(&reference_eigvecs[n]);
            let mut mass_u_n = self.operator.alloc_field();
            self.operator.apply_mass(&u_n_ref, &mut mass_u_n);

            for m in 0..n_ret {
                let u_m = self.eigenvector_buffer(m);
                overlap[m * n_ret + n] = self.operator.backend().dot(&u_m, &mass_u_n);
                self.return_buffer(u_m);
            }

            self.return_buffer(u_n_ref);
        }

        overlap
    }

    // ========================================================================
    // Helper: convert Field2D eigenvectors into backend buffers
    // ========================================================================

    /// Create a backend buffer from an eigenvector.
    fn eigenvector_buffer(&self, index: usize) -> B::Buffer {
        let field = &self.eigenvectors[index];
        let mut buf = self.operator.alloc_field();
        buf.as_mut_slice().copy_from_slice(field.as_slice());
        buf
    }

    /// Convert a Field2D into a backend buffer.
    fn field_to_buffer(&self, field: &Field2D) -> B::Buffer {
        let mut buf = self.operator.alloc_field();
        buf.as_mut_slice().copy_from_slice(field.as_slice());
        buf
    }

    /// Placeholder for returning a buffer (no-op for now, would be a pool in production).
    #[inline(always)]
    fn return_buffer(&self, _buf: B::Buffer) {
        // Buffer is dropped; could be returned to a pool for reuse
    }
}
