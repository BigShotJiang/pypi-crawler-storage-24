//! Simple FDTD runner for testing comparison with Meep.
//!
//! This is a standalone binary for running FDTD simulations based on TOML config.
//! Run with: cargo run --release -p blaze2d-core --example fdtd_runner -- testing_fdtd/config.toml

use std::env;
use std::fs::{self, File};
use std::io::{BufWriter, Write};
use std::path::Path;

use blaze2d_core::fdtd::{FdtdTomlConfig, YeeGrid2D};
use blaze2d_core::grid::Grid2D;

fn main() {
    // Get config path from args
    let args: Vec<String> = env::args().collect();
    let config_path = if args.len() > 1 {
        &args[1]
    } else {
        "testing_fdtd/config.toml"
    };

    println!("============================================================");
    println!("Blaze2D FDTD Moiré Photonic Crystal Simulation");
    println!("============================================================");
    println!("Loading config from: {}", config_path);

    // Load and parse TOML config
    let toml_content = fs::read_to_string(config_path).expect("Failed to read config file");
    let config: FdtdTomlConfig = toml::from_str(&toml_content).expect("Failed to parse TOML config");

    // Validate
    config.validate().expect("Invalid configuration");

    // Extract parameters
    let resolution = config.fdtd.resolution;
    let pml_thickness = config.fdtd.boundaries.pml_thickness;
    let polarization = config.fdtd.polarization;
    let run_time = config.fdtd.run_time.unwrap_or(20.0);
    let courant = config.fdtd.courant_factor;

    // Build moiré lattice
    let moire_params = config.moire.as_ref().expect("Expected moiré config");
    let moire = moire_params.to_moire_lattice();

    let twist_angle = moire_params.twist_angle_deg;
    let a = moire_params.layer1.a;
    let r_over_a = moire_params.layer1.atoms.first().map(|atom| atom.r_over_a).unwrap_or(0.22);
    let eps_bg = moire_params.layer1.eps_bg;

    // Domain: 5x5 unit cells + PML
    let n_cells = 5;
    let domain_size = n_cells as f64 * a;
    let total_size = domain_size + 2.0 * (pml_thickness as f64 / resolution);

    println!("Lattice constant a = {}", a);
    println!("Hole radius r/a = {}", r_over_a);
    println!("Background eps = {}", eps_bg);
    println!("Twist angle = {}°", twist_angle);
    println!("Domain: {}x{} unit cells = {}x{}", n_cells, n_cells, domain_size, domain_size);
    println!("Total size (with PML): {}x{}", total_size, total_size);
    println!("Resolution = {}", resolution);
    println!("PML thickness = {} grid points", pml_thickness);
    println!("Polarization = {:?}", polarization);
    println!("Run time = {}", run_time);
    println!("============================================================");

    // Create Yee grid
    let grid = YeeGrid2D::new(total_size, total_size, resolution);
    let dx = grid.dx();
    let dt = courant * grid.courant_dt(courant);
    let nx = grid.nx();
    let ny = grid.ny();

    println!("Grid size: {} x {}", nx, ny);

    // Calculate number of time steps
    let n_steps = (run_time / dt).ceil() as usize;
    println!("\nTime step dt = {:.6e}", dt);
    println!("Number of steps = {}", n_steps);

    // Debug: Print lattice vectors for layer2
    println!("\n=== DEBUG: Layer 2 lattice vectors ===");
    println!("  a1 = {:?}", moire.layer2.lattice.a1);
    println!("  a2 = {:?}", moire.layer2.lattice.a2);
    println!("  rotation = {} rad = {} deg", moire.layer2.rotation, moire.layer2.rotation.to_degrees());
    println!("======================================\n");

    // =========================================================================
    // Sample permittivity with TILED ANALYTIC smoothing
    // This uses Blaze's analytic smoothing for ONE unit cell, then tiles and rotates
    // =========================================================================
    println!("\nSampling permittivity with TILED ANALYTIC smoothing...");
    println!("  - Analytically smooth ONE unit cell");
    println!("  - Tile to create layer 1");
    println!("  - Rotate to create layer 2");
    println!("  - Combine with min (air holes dominate)");

    // Create Grid2D for sampling (centered on origin)
    let sample_grid = Grid2D::new_centered(nx, ny, total_size, total_size);

    // Sample permittivity with tiled analytic smoothing
    // resolution = 32 pixels per unit cell (matches the overall resolution)
    let eps_grid = moire.sample_permittivity_tiled_analytic(&sample_grid, resolution as usize);

    // Find eps range
    let eps_min = eps_grid.iter().cloned().fold(f64::INFINITY, f64::min);
    let eps_max = eps_grid.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
    println!("Eps range: [{:.3}, {:.3}]", eps_min, eps_max);

    // Initialize fields (TE: Hz, Ex, Ey)
    println!("\nInitializing fields...");
    let mut hz = vec![0.0f64; nx * ny];
    let mut ex = vec![0.0f64; nx * ny];
    let mut ey = vec![0.0f64; nx * ny];

    // PML auxiliary fields
    let mut psi_hzx = vec![0.0f64; nx * ny];
    let mut psi_hzy = vec![0.0f64; nx * ny];
    let mut psi_eyx = vec![0.0f64; nx * ny];
    let mut psi_exy = vec![0.0f64; nx * ny];

    // PML parameters
    let pml_sigma_max = 1.5 * (3.0 + 1.0) / (2.0 * (pml_thickness as f64) * dx);
    let pml_kappa_max = 1.0;
    let pml_alpha = 0.0;

    // Compute PML conductivity profile (polynomial grading)
    let compute_sigma = |d: f64, thickness: f64| -> f64 {
        if d <= 0.0 {
            0.0
        } else {
            pml_sigma_max * (d / thickness).powi(3)
        }
    };

    // Source parameters
    let source_params = config.sources.first().expect("Need at least one source");
    let fcen = source_params.frequency;
    let fwidth = source_params.fwidth;
    let source_x = source_params.position[0];
    let source_y = source_params.position[1];

    // Convert source position to grid indices (accounting for centered domain)
    let src_ix = ((source_x + total_size / 2.0 - domain_size / 2.0 + total_size / 2.0) / dx).round() as usize;
    let src_iy = ((source_y + total_size / 2.0 - domain_size / 2.0 + total_size / 2.0) / dx).round() as usize;
    let src_ix = src_ix.min(nx - 1);
    let src_iy = src_iy.min(ny - 1);

    // Gaussian source timing (Meep-compatible)
    let omega0 = 2.0 * std::f64::consts::PI * fcen;
    let sigma_t = 1.0 / (2.0 * std::f64::consts::PI * fwidth);
    let t0 = 5.0 * sigma_t; // Peak time

    println!("Source at grid position ({}, {})", src_ix, src_iy);
    println!("Gaussian pulse: f_cen = {}, fwidth = {}", fcen, fwidth);
    println!("Peak time t0 = {:.3}", t0);

    // Create output directory
    let output_dir = Path::new("testing_fdtd/rust_output");
    fs::create_dir_all(output_dir).expect("Failed to create output directory");

    // Time stepping
    println!("\nRunning simulation for {} steps...", n_steps);

    let update_interval = n_steps / 10;

    for step in 0..n_steps {
        let t = step as f64 * dt;

        // Progress update
        if step % update_interval == 0 {
            println!("  Step {}/{} (t = {:.3})", step, n_steps, t);
        }

        // 1. Update Hz (from Ex, Ey)
        for iy in 0..ny - 1 {
            for ix in 0..nx - 1 {
                let idx = iy * nx + ix;

                // dHz/dt = (dEy/dx - dEx/dy)
                let dey_dx = (ey[idx + 1] - ey[idx]) / dx;
                let dex_dy = (ex[idx + nx] - ex[idx]) / dx;

                // PML: compute sigma at this location
                let x = (ix as f64 + 0.5) * dx;
                let y = (iy as f64 + 0.5) * dx;

                // Distance into PML (0 if inside main domain)
                let pml_x_lo = (pml_thickness as f64 * dx - x).max(0.0);
                let pml_x_hi = (x - (total_size - pml_thickness as f64 * dx)).max(0.0);
                let pml_y_lo = (pml_thickness as f64 * dx - y).max(0.0);
                let pml_y_hi = (y - (total_size - pml_thickness as f64 * dx)).max(0.0);

                let sigma_x = compute_sigma(pml_x_lo.max(pml_x_hi), pml_thickness as f64 * dx);
                let sigma_y = compute_sigma(pml_y_lo.max(pml_y_hi), pml_thickness as f64 * dx);

                // CPML update for Hz
                // Equation: dHz/dt = (1/mu) * [ (dEx/dy + Psi_y) - (dEy/dx + Psi_x) ]
                let bx = (-sigma_x * dt).exp();
                let by = (-sigma_y * dt).exp();
                let cx = if sigma_x > 1e-10 { (bx - 1.0) * dt / (sigma_x * dt + 1e-20) } else { 0.0 };
                let cy = if sigma_y > 1e-10 { (by - 1.0) * dt / (sigma_y * dt + 1e-20) } else { 0.0 };

                psi_hzy[idx] = by * psi_hzy[idx] + cy * dex_dy;
                psi_hzx[idx] = bx * psi_hzx[idx] + cx * dey_dx;

                // Sign correction: Hz update involves (dEx/dy - dEy/dx)
                hz[idx] += dt * ( (dex_dy + psi_hzy[idx]) - (dey_dx + psi_hzx[idx]) );
            }
        }

        // 2. Inject Hz source (Gaussian pulse)
        let src_val = (-0.5 * ((t - t0) / sigma_t).powi(2)).exp()
            * (omega0 * (t - t0)).cos();
        let src_idx = src_iy * nx + src_ix;
        hz[src_idx] += src_val * dt;

        // 3. Update Ex (from Hz)
        for iy in 1..ny {
            for ix in 0..nx {
                let idx = iy * nx + ix;

                // dEx/dt = dHz/dy / eps
                let dhz_dy = (hz[idx] - hz[idx - nx]) / dx;
                let eps = eps_grid[idx];

                // PML
                let y = iy as f64 * dx;
                let pml_y_lo = (pml_thickness as f64 * dx - y).max(0.0);
                let pml_y_hi = (y - (total_size - pml_thickness as f64 * dx)).max(0.0);
                let sigma_y = compute_sigma(pml_y_lo.max(pml_y_hi), pml_thickness as f64 * dx);

                // CPML coefficients
                let by = (-sigma_y * dt).exp();
                let cy = if sigma_y > 1e-10 { (by - 1.0) * dt / (sigma_y * dt + 1e-20) } else { 0.0 };

                psi_exy[idx] = by * psi_exy[idx] + cy * dhz_dy;

                ex[idx] += (dt / eps) * (dhz_dy + psi_exy[idx]);
            }
        }

        // 4. Update Ey (from Hz)
        for iy in 0..ny {
            for ix in 1..nx {
                let idx = iy * nx + ix;

                // dEy/dt = -dHz/dx / eps
                let dhz_dx = (hz[idx] - hz[idx - 1]) / dx;
                let eps = eps_grid[idx];

                // PML
                let x = ix as f64 * dx;
                let pml_x_lo = (pml_thickness as f64 * dx - x).max(0.0);
                let pml_x_hi = (x - (total_size - pml_thickness as f64 * dx)).max(0.0);
                let sigma_x = compute_sigma(pml_x_lo.max(pml_x_hi), pml_thickness as f64 * dx);

                // CPML coefficients
                let bx = (-sigma_x * dt).exp();
                let cx = if sigma_x > 1e-10 { (bx - 1.0) * dt / (sigma_x * dt + 1e-20) } else { 0.0 };

                psi_eyx[idx] = bx * psi_eyx[idx] + cx * dhz_dx;

                ey[idx] -= (dt / eps) * (dhz_dx + psi_eyx[idx]);
            }
        }
            }
        }
    }

    println!("Simulation complete!");

    // Find field range
    let hz_min = hz.iter().cloned().fold(f64::INFINITY, f64::min);
    let hz_max = hz.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
    println!("\nHz range: [{:.6e}, {:.6e}]", hz_min, hz_max);

    // Save output
    println!("\nSaving field data...");

    // Save Hz as CSV
    let hz_path = output_dir.join("rust_hz.csv");
    let mut hz_file = BufWriter::new(File::create(&hz_path).expect("Failed to create Hz file"));
    for iy in 0..ny {
        let row: Vec<String> = (0..nx)
            .map(|ix| format!("{:.10e}", hz[iy * nx + ix]))
            .collect();
        writeln!(hz_file, "{}", row.join(",")).unwrap();
    }
    println!("  Saved {}", hz_path.display());

    // Save Ex as CSV
    let ex_path = output_dir.join("rust_ex.csv");
    let mut ex_file = BufWriter::new(File::create(&ex_path).expect("Failed to create Ex file"));
    for iy in 0..ny {
        let row: Vec<String> = (0..nx)
            .map(|ix| format!("{:.10e}", ex[iy * nx + ix]))
            .collect();
        writeln!(ex_file, "{}", row.join(",")).unwrap();
    }
    println!("  Saved {}", ex_path.display());

    // Save Ey as CSV
    let ey_path = output_dir.join("rust_ey.csv");
    let mut ey_file = BufWriter::new(File::create(&ey_path).expect("Failed to create Ey file"));
    for iy in 0..ny {
        let row: Vec<String> = (0..nx)
            .map(|ix| format!("{:.10e}", ey[iy * nx + ix]))
            .collect();
        writeln!(ey_file, "{}", row.join(",")).unwrap();
    }
    println!("  Saved {}", ey_path.display());

    // Save permittivity as CSV
    let eps_path = output_dir.join("rust_eps.csv");
    let mut eps_file = BufWriter::new(File::create(&eps_path).expect("Failed to create eps file"));
    for iy in 0..ny {
        let row: Vec<String> = (0..nx)
            .map(|ix| format!("{:.6}", eps_grid[iy * nx + ix]))
            .collect();
        writeln!(eps_file, "{}", row.join(",")).unwrap();
    }
    println!("  Saved {}", eps_path.display());

    // Save coordinates
    let x_path = output_dir.join("rust_x.csv");
    let mut x_file = BufWriter::new(File::create(&x_path).expect("Failed to create x file"));
    for ix in 0..nx {
        writeln!(x_file, "{:.10e}", (ix as f64 + 0.5) * dx - total_size / 2.0).unwrap();
    }
    println!("  Saved {}", x_path.display());

    let y_path = output_dir.join("rust_y.csv");
    let mut y_file = BufWriter::new(File::create(&y_path).expect("Failed to create y file"));
    for iy in 0..ny {
        writeln!(y_file, "{:.10e}", (iy as f64 + 0.5) * dx - total_size / 2.0).unwrap();
    }
    println!("  Saved {}", y_path.display());

    // Save metadata as JSON
    let metadata = serde_json::json!({
        "a": a,
        "r_over_a": r_over_a,
        "eps_bg": eps_bg,
        "twist_angle_deg": twist_angle,
        "n_cells": n_cells,
        "domain_size": domain_size,
        "total_size": total_size,
        "resolution": resolution,
        "pml_thickness": pml_thickness,
        "nx": nx,
        "ny": ny,
        "dx": dx,
        "dt": dt,
        "n_steps": n_steps,
        "run_time": run_time,
        "fcen": fcen,
        "fwidth": fwidth,
        "source_ix": src_ix,
        "source_iy": src_iy,
        "final_time": n_steps as f64 * dt
    });

    let meta_path = output_dir.join("rust_metadata.json");
    let mut meta_file = File::create(&meta_path).expect("Failed to create metadata file");
    writeln!(meta_file, "{}", serde_json::to_string_pretty(&metadata).unwrap()).unwrap();
    println!("  Saved {}", meta_path.display());

    println!("\nDone!");
}
