//! Benchmark of the core FdtdSimulation library class.
//! Run: cargo run --release -p blaze2d-core --example library_benchmark -- testing_fdtd/bench_config.toml

use std::env;
use std::fs;
use std::time::Instant; 
use clap::Parser;

use blaze2d_core::fdtd::{FdtdConfig, FdtdSimulation, FdtdTomlConfig, BoundaryConfig};
use blaze2d_core::geometry::Geometry2D;
use blaze2d_core::lattice::Lattice2D;

#[derive(Parser, Debug)]
#[command(author, version, about, long_about = None)]
struct Args {
    /// Path to config file (optional, used as base)
    #[arg(short, long, default_value = "testing_fdtd/bench_config.toml")]
    config: String,

    /// Override grid resolution (N for NxN grid inside domain)
    #[arg(short, long)]
    resolution: Option<f64>,

    /// Override number of steps
    #[arg(short, long)]
    steps: Option<usize>,

    /// Force parallel execution
    #[arg(long)]
    parallel: bool,
    
    /// Do not output anything except the time (machine readable)
    #[arg(long)]
    silent: bool,
}

fn main() {
    let args = Args::parse();
    let config_path = &args.config;

    // Default values if toml missing or just ignored lightly
    // We try to read it, if fail, we assume defaults for benchmarks
    let toml_content = fs::read_to_string(config_path).unwrap_or_default();
    
    // Create dummy geometry
    let lattice = Lattice2D::square(1.0);
    let geometry = Geometry2D::single_air_hole(lattice, 0.3, 12.0);
    let boundaries = BoundaryConfig::default();
    
    // Determine Resolution
    // If user passes --resolution N, and domain is 1.0, then we get NxN points.
    let resolution = args.resolution.unwrap_or(32.0);
    let steps = args.steps.unwrap_or(1000);

    // Construct FdtdConfig
    let fdtd_config = FdtdConfig {
        resolution: resolution,
        resolution_y: None,
        courant_factor: 0.5,
        domain_size: [1.0, 1.0], // Fixed 1.0x1.0 for easy N scaling
        boundaries: boundaries,
        polarization: blaze2d_core::polarization::Polarization::TE,
        pml_thickness: 10,
        run_time: None,
        n_steps: Some(steps), 
        verbosity: if args.silent { 0 } else { 1 },
        use_parallel: args.parallel,
    };

    if !args.silent {
        println!("Initializing Simulation...");
        println!("Grid: {} x {}", fdtd_config.domain_size[0] * fdtd_config.resolution, fdtd_config.domain_size[1] * fdtd_config.resolution);
        println!("Steps: {}", steps);
        println!("Parallel: {}", args.parallel);
    }
    let mut sim = FdtdSimulation::new(geometry, fdtd_config);
    
    if !args.silent {
        println!("Running library benchmark for {} steps...", steps);
    }
    
    let start = Instant::now();
    sim.run(steps);
    let duration = start.elapsed();
    
    #[cfg(feature = "profiling")]
    blaze2d_core::profiler::print_stats();

    if args.silent {
        println!("{}", duration.as_secs_f64());
    } else {
        println!("Library Core Benchmark finished in {:.4} seconds", duration.as_secs_f64());
    }
}
