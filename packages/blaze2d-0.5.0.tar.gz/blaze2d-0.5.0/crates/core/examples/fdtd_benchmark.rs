//! FDTD benchmark runner (no I/O, pure computation)
//! 
//! Run with: cargo run --release -p blaze2d-core --example fdtd_benchmark -- testing_fdtd/bench_config.toml

use std::env;
use std::fs;
use std::time::Instant;

use blaze2d_core::fdtd::{FdtdTomlConfig, YeeGrid2D};
use blaze2d_core::grid::Grid2D;

fn main() {
    let args: Vec<String> = env::args().collect();
    let config_path = if args.len() > 1 {
        &args[1]
    } else {
        "testing_fdtd/bench_config.toml"
    };

    println!("Loading config from: {}", config_path);
    let toml_content = fs::read_to_string(config_path).expect("Failed to read config file");
    let config: FdtdTomlConfig = toml::from_str(&toml_content).expect("Failed to parse TOML config");
    config.validate().expect("Invalid configuration");

    let resolution = config.fdtd.resolution;
    // Hardcoded parameter for benchmark to match Meep script
    let n_cells = 15; 
    let pml_cells = 32; // 1.0 thickness * res 32
    
    // Geometry params
    let moire_params = config.moire.as_ref().expect("Expected moiré config");
    let moire = moire_params.to_moire_lattice();
    let a = moire_params.layer1.a;
    let eps_bg = moire_params.layer1.eps_bg;
    
    let domain_size = n_cells as f64 * a;
    let total_size = domain_size + 2.0 * (pml_cells as f64 / resolution);
    
    // Grid Setup
    let grid = YeeGrid2D::new(total_size, total_size, resolution);
    let dx = grid.dx();
    let courant = config.fdtd.courant_factor;
    let dt = courant * dx; // Vacuum limit, Meep uses 0.5 usually
    let nx = grid.nx();
    let ny = grid.ny();
    
    // Steps
    let n_steps = config.fdtd.n_steps.unwrap_or(1000);
    
    println!("Rust Benchmark");
    println!("Domain: {}x{} cells ({:.2}x{:.2})", n_cells, n_cells, total_size, total_size);
    println!("Grid: {} x {}", nx, ny);
    println!("Total grid points: {}", nx * ny);
    println!("Steps: {}", n_steps);
    
    // Pre-simulation setup
    println!("Initializing...");
    let sample_grid = Grid2D::new_centered(nx, ny, total_size, total_size);
    let eps_grid = moire.sample_permittivity_tiled_analytic(&sample_grid, resolution as usize);
    let eps_vec = eps_grid; // Take ownership if it's a Vec or slice

    let mut hz = vec![0.0f64; nx * ny];
    let mut ex = vec![0.0f64; nx * ny];
    let mut ey = vec![0.0f64; nx * ny];
    
    // Aux fields for PML
    let mut psi_hzx = vec![0.0f64; nx * ny];
    let mut psi_hzy = vec![0.0f64; nx * ny];
    let mut psi_eyx = vec![0.0f64; nx * ny];
    let mut psi_exy = vec![0.0f64; nx * ny];
    
    // Source params
    let source_params = config.sources.first().expect("Need source");
    let fcen = source_params.frequency;
    let fwidth = source_params.fwidth;
    let omega0 = 2.0 * std::f64::consts::PI * fcen;
    let sigma_t = 1.0 / fwidth; // Matched to Meep
    // Center pulse such that it plays during the simulation
    // Center at step 500
    let t_peak = 500.0 * dt;
    let t0 = t_peak; 
    
    let src_ix = nx / 2;
    let src_iy = ny / 2;
    let src_idx = src_iy * nx + src_ix;
    
    // PML Coeffs
    let pml_sigma_max = 0.8 * (3.0 + 1.0) / dx;
    let pml_thickness_phys = pml_cells as f64 * dx;
    let compute_sigma = |d: f64| -> f64 {
        if d <= 0.0 { 0.0 } else { pml_sigma_max * (d / pml_thickness_phys).powi(3) }
    };
    
    // Precompute Sigma and Coeffs to be fair? 
    // Meep precomputes/stores conductivity. 
    // Let's precompute coeffs logic or do it inline efficiently.
    // In fdtd_video we did it inline which is slow.
    // For benchmark, "fast as possible", we should precompute coefficients.
    // But to be fair to "what we have implemented", if the video code did it inline, that's the current state.
    // However, the prompt says "Making the algorithm as fast as possible".
    // So I should optimize.
    
    // Optimization: Precompute CPML coefficients
    let mut cx_vec = vec![0.0f64; nx]; // For Ex/Hy locations (staggered)
    let mut bx_vec = vec![0.0f64; nx];
    let mut cy_vec = vec![0.0f64; ny];
    let mut by_vec = vec![0.0f64; ny];
    
    // Aux coeffs for E update (sigma at Integer grid points? or Half?)
    // This depends on where sigma is defined.
    // Standard Yee:
    // Ex is at (i+0.5, j). Sigma_y depends on y = j*dx.
    // Ey is at (i, j+0.5). Sigma_x depends on x = i*dx.
    // Hz is at (i+0.5, j+0.5).
    // Let's approximate or just map to grid index.
    
    // To keep it simple and correct:
    // Sigma X arrays
    let mut sig_x_ex = vec![0.0f64; nx]; // At x = (i+0.5) dx
    let mut sig_x_ey = vec![0.0f64; nx]; // At x = i dx
    // Let's just use the loop logic but precompute into a 1D array
    
    // Helper to get distance into PML
    let pml_dist = |u: f64, L: f64| -> f64 {
        let lo = (pml_thickness_phys - u).max(0.0);
        let hi = (u - (L - pml_thickness_phys)).max(0.0);
        lo.max(hi)
    };
    
    // X coefficients (size nx) - Used for Ey update (depends on x) and Hz update (depends on x)
    // Actually, Ey is at (i, j+0.5). x = i*dx.
    // Hz is at (i+0.5, j+0.5). x = (i+0.5)*dx.
    
    // Let's define:
    // cx_ey: for updating Ey (at integer x)
    // cx_hz: for updating Hz (at half x)
    // Same for y.
    
    let mut bx_ey = vec![0.0f64; nx];
    let mut cx_ey = vec![0.0f64; nx];
    
    let mut bx_hz = vec![0.0f64; nx]; // Also used for Ex update? Ex is at (i+0.5, j) -> x is half.
    // Wait, Ex update involves dHz/dy. No x-derivative. So Ex doesn't value sigma_x.
    // Ex depends on sigma_y.
    
    let mut cx_hz = vec![0.0f64; nx];
    
    for ix in 0..nx {
        // Integer x (for Ey)
        let x_int = ix as f64 * dx;
        let s_int = compute_sigma(pml_dist(x_int, total_size));
        bx_ey[ix] = (-s_int * dt).exp();
        cx_ey[ix] = if s_int > 1e-10 { bx_ey[ix] - 1.0 } else { 0.0 };
        
        // Half x (for Hz, Ex)
        let x_half = (ix as f64 + 0.5) * dx;
        let s_half = compute_sigma(pml_dist(x_half, total_size));
        bx_hz[ix] = (-s_half * dt).exp();
        cx_hz[ix] = if s_half > 1e-10 { bx_hz[ix] - 1.0 } else { 0.0 };
    }
    
    let mut by_ex = vec![0.0f64; ny];
    let mut cy_ex = vec![0.0f64; ny];
    
    let mut by_hz = vec![0.0f64; ny];
    let mut cy_hz = vec![0.0f64; ny];
    
    for iy in 0..ny {
        // Integer y (Ex is at j*dx? No, Ex is at (i+0.5, j)*dx) -> Integer y
        let y_int = iy as f64 * dx;
        let s_int = compute_sigma(pml_dist(y_int, total_size));
        by_ex[iy] = (-s_int * dt).exp();
        cy_ex[iy] = if s_int > 1e-10 { by_ex[iy] - 1.0 } else { 0.0 };
        
        // Half y (Hz, Ey)
        let y_half = (iy as f64 + 0.5) * dx;
        let s_half = compute_sigma(pml_dist(y_half, total_size));
        by_hz[iy] = (-s_half * dt).exp();
        cy_hz[iy] = if s_half > 1e-10 { by_hz[iy] - 1.0 } else { 0.0 };
    }
    
    println!("Starting simulation...");
    let start = Instant::now();
    
    for step in 0..n_steps {
        let t = step as f64 * dt;
        
        // 1. Update Hz
        for iy in 0..ny-1 {
            // Preload Y-coeffs outside inner loop
            let by = by_hz[iy];
            let cy = cy_hz[iy];
            
            for ix in 0..nx-1 {
                let idx = iy * nx + ix;
                
                let dey_dx = (ey[idx+1] - ey[idx]) / dx;
                let dex_dy = (ex[idx+nx] - ex[idx]) / dx;
                
                // PML Hz (needs sigma_x at half, sigma_y at half)
                // Use stored coeffs
                let bx = bx_hz[ix];
                let cx = cx_hz[ix];
                
                // Update Psi
                psi_hzy[idx] = by * psi_hzy[idx] + cy * dex_dy;
                psi_hzx[idx] = bx * psi_hzx[idx] + cx * dey_dx;
                
                hz[idx] += dt * ((dex_dy + psi_hzy[idx]) - (dey_dx + psi_hzx[idx]));
            }
        }
        
        // Source
        let src_val = (-0.5 * ((t - t0) / sigma_t).powi(2)).exp() * (omega0 * (t - t0)).cos();
        hz[src_idx] -= src_val * dt / (dx * dx);

        // 2. Update Ex
        for iy in 1..ny {
            let by = by_ex[iy];
            let cy = cy_ex[iy];
            for ix in 0..nx {
                let idx = iy * nx + ix;
                let dhz_dy = (hz[idx] - hz[idx - nx]) / dx;
                let eps = eps_vec[idx];
                
                psi_exy[idx] = by * psi_exy[idx] + cy * dhz_dy;
                ex[idx] += (dt / eps) * (dhz_dy + psi_exy[idx]);
            }
        }
        
        // 3. Update Ey
        for iy in 0..ny {
            for ix in 1..nx {
                let idx = iy * nx + ix;
                let dhz_dx = (hz[idx] - hz[idx - 1]) / dx;
                let eps = eps_vec[idx];
                
                // Use integer x kernels
                let bx = bx_ey[ix];
                let cx = cx_ey[ix];
                
                psi_eyx[idx] = bx * psi_eyx[idx] + cx * dhz_dx;
                ey[idx] -= (dt / eps) * (dhz_dx + psi_eyx[idx]);
            }
        }
    }
    
    let duration = start.elapsed();
    println!("Rust finished in {:.4} seconds", duration.as_secs_f64());
}
