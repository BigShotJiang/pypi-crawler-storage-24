//! Minimal FDTD test - no PML, homogeneous medium
//! This is to verify the basic FDTD algorithm is correct.
//!
//! Run with: cargo run --release -p blaze2d-core --example fdtd_minimal

use std::fs::{self, File};
use std::io::{BufWriter, Write};
use std::path::Path;

fn main() {
    println!("============================================================");
    println!("Minimal FDTD Test - Homogeneous Medium, No PML");
    println!("============================================================");

    // Simple parameters
    let nx = 100;
    let ny = 100;
    let dx = 0.1;  // Grid spacing
    let total_size = nx as f64 * dx;
    
    // Time stepping (Courant condition: dt <= dx / (c * sqrt(2)) for 2D)
    // In normalized units where c = 1
    let courant = 0.5;
    let dt = courant * dx / (2.0_f64).sqrt();
    
    let run_time = 5.0;
    let n_steps = (run_time / dt).ceil() as usize;
    
    println!("Grid: {} x {}", nx, ny);
    println!("dx = {}, dt = {}", dx, dt);
    println!("Courant number = {}", dt * (2.0_f64).sqrt() / dx);
    println!("Steps: {}", n_steps);

    // Homogeneous medium (eps = 1, no geometry)
    let eps = 1.0;

    // Initialize fields (TE: Hz, Ex, Ey)
    let mut hz = vec![0.0f64; nx * ny];
    let mut ex = vec![0.0f64; nx * ny];
    let mut ey = vec![0.0f64; nx * ny];

    // Source at center
    let src_ix = nx / 2;
    let src_iy = ny / 2;
    
    // Gaussian pulse parameters
    let fcen = 0.4;
    let fwidth = 0.2;
    let omega0 = 2.0 * std::f64::consts::PI * fcen;
    let sigma_t = 1.0 / (2.0 * std::f64::consts::PI * fwidth);
    let t0 = 5.0 * sigma_t;

    println!("Source at ({}, {})", src_ix, src_iy);
    println!("Gaussian: fcen={}, fwidth={}, t0={:.3}", fcen, fwidth, t0);

    // Output directory
    let output_dir = Path::new("testing_fdtd/minimal_test");
    fs::create_dir_all(output_dir).expect("Failed to create output directory");

    // Frame output
    let dt_output = 0.25;
    let steps_per_frame = (dt_output / dt).round() as usize;
    let mut frame_count = 0;
    let mut frame_times = Vec::new();

    println!("\nRunning simulation...");

    for step in 0..=n_steps {
        let t = step as f64 * dt;

        // Save frame
        if step % steps_per_frame == 0 {
            let hz_min = hz.iter().cloned().fold(f64::INFINITY, f64::min);
            let hz_max = hz.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
            
            if step % (steps_per_frame * 4) == 0 {
                println!("  Step {}: t={:.3}, Hz=[{:.3e}, {:.3e}]", step, t, hz_min, hz_max);
            }

            // Save frame
            let frame_path = output_dir.join(format!("frame_{:06}.csv", frame_count));
            let mut frame_file = BufWriter::new(File::create(&frame_path).unwrap());
            for iy in 0..ny {
                let row: Vec<String> = (0..nx)
                    .map(|ix| format!("{:.10e}", hz[iy * nx + ix]))
                    .collect();
                writeln!(frame_file, "{}", row.join(",")).unwrap();
            }
            frame_times.push(t);
            frame_count += 1;
        }

        if step >= n_steps {
            break;
        }

        // =====================================================
        // FDTD Update Equations (TE mode: Hz, Ex, Ey)
        // 
        // Maxwell's equations (TE, 2D):
        //   ∂Hz/∂t = (1/μ) * (∂Ey/∂x - ∂Ex/∂y)
        //   ∂Ex/∂t = (1/ε) * ∂Hz/∂y  
        //   ∂Ey/∂t = -(1/ε) * ∂Hz/∂x
        //
        // In normalized units (c = 1, μ = 1):
        //   ∂Hz/∂t = ∂Ey/∂x - ∂Ex/∂y
        //   ∂Ex/∂t = (1/ε) * ∂Hz/∂y
        //   ∂Ey/∂t = -(1/ε) * ∂Hz/∂x
        // =====================================================

        // 1. Update Hz (interior points only to avoid boundary issues)
        for iy in 0..ny - 1 {
            for ix in 0..nx - 1 {
                let idx = iy * nx + ix;
                
                // Finite differences
                let dey_dx = (ey[idx + 1] - ey[idx]) / dx;
                let dex_dy = (ex[idx + nx] - ex[idx]) / dx;
                
                hz[idx] += dt * (dey_dx - dex_dy);
            }
        }

        // 2. Add source to Hz (soft source - add, don't replace)
        let src_val = (-0.5 * ((t - t0) / sigma_t).powi(2)).exp() 
                    * (omega0 * (t - t0)).cos();
        let src_idx = src_iy * nx + src_ix;
        hz[src_idx] += src_val;  // Note: NOT multiplied by dt for soft source!

        // 3. Update Ex (interior points)
        for iy in 1..ny {
            for ix in 0..nx {
                let idx = iy * nx + ix;
                
                let dhz_dy = (hz[idx] - hz[idx - nx]) / dx;
                
                ex[idx] += (dt / eps) * dhz_dy;
            }
        }

        // 4. Update Ey (interior points)
        for iy in 0..ny {
            for ix in 1..nx {
                let idx = iy * nx + ix;
                
                let dhz_dx = (hz[idx] - hz[idx - 1]) / dx;
                
                ey[idx] -= (dt / eps) * dhz_dx;
            }
        }
    }

    println!("\nSimulation complete!");
    println!("Saved {} frames to {}", frame_count, output_dir.display());

    // Save metadata
    let metadata = serde_json::json!({
        "nx": nx,
        "ny": ny,
        "dx": dx,
        "dt": dt,
        "total_size": total_size,
        "n_frames": frame_count,
        "fps": 20,
        "times": frame_times
    });
    let meta_path = output_dir.join("metadata.json");
    let mut meta_file = File::create(&meta_path).unwrap();
    writeln!(meta_file, "{}", serde_json::to_string_pretty(&metadata).unwrap()).unwrap();
}
