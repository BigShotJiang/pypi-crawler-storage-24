//! Scaling benchmark for FDTD core.
//! Usage: cargo run --release --example scaling_benchmark -- --size <N> --threads <T>

use std::env;
use std::time::Instant;
use blaze2d_core::fdtd::{FdtdConfig, FdtdSimulation, BoundaryConfig};
use blaze2d_core::geometry::Geometry2D;
use blaze2d_core::lattice::Lattice2D;
use blaze2d_core::polarization::Polarization;

fn main() {
    let args: Vec<String> = env::args().collect();
    let mut size = 512;
    let mut threads = 1;
    let mut steps = 1000;

    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "--size" => {
                if i + 1 < args.len() {
                    size = args[i + 1].parse().unwrap_or(512);
                }
                i += 1;
            }
            "--threads" => {
                if i + 1 < args.len() {
                    threads = args[i + 1].parse().unwrap_or(1);
                }
                i += 1;
            }
            "--steps" => {
                 if i + 1 < args.len() {
                    steps = args[i + 1].parse().unwrap_or(1000);
                }
                i += 1;
            }
            _ => {}
        }
        i += 1;
    }

    // Configure Rayon if needed
    if threads > 1 {
        // We must do this before any rayon usage
        rayon::ThreadPoolBuilder::new()
            .num_threads(threads)
            .build_global()
            .expect("Failed to build global thread pool");
    }

    // Geometry
    let lattice = Lattice2D::square(1.0);
    let geometry = Geometry2D::single_air_hole(lattice, 0.3, 12.0);

    // Config
    // We want N x N grid points.
    // Domain size is 1.0 x 1.0. Resolution = N.
    let config = FdtdConfig {
        resolution: size as f64,
        resolution_y: None,
        domain_size: [1.0, 1.0],
        courant_factor: 0.5,
        pml_thickness: 10,
        boundaries: BoundaryConfig::default(),
        polarization: Polarization::TE,
        run_time: None,
        n_steps: Some(steps),
        verbosity: 0, // silent
        use_parallel: threads > 1,
    };

    println!("Setup: Grid={}x{}, Threads={}", size, size, threads);
    let mut sim = FdtdSimulation::new(geometry, config);

    let start = Instant::now();
    sim.run(steps);
    let duration = start.elapsed();

    println!("Time: {:.4}", duration.as_secs_f64());
}
