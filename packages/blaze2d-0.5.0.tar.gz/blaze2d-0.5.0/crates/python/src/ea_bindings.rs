//! Python bindings for EA Hamiltonian ingredient extraction.
//!
//! This module provides a Python-callable interface for extracting all physical
//! quantities needed to construct the envelope-approximation Hamiltonian for
//! moiré photonic crystals.
//!
//! # Usage (Python)
//!
//! ```python
//! from blaze import EAExtractor
//!
//! result = EAExtractor.extract(
//!     lattice_vectors=[[1.0, 0.0], [0.0, 1.0]],
//!     atoms=[{"pos": [0.0, 0.0], "radius": 0.2, "eps_inside": 1.0}],
//!     eps_bg=12.0,
//!     k0=[0.0, 0.0],
//!     polarization="TE",
//!     resolution=32,
//!     n_retained=4,
//!     n_remote=8,
//! )
//!
//! # Access the ingredients
//! eigenvalues = result["eigenvalues"]
//! velocity_x = result["velocity_matrices_x"]   # complex list
//! mass_tensor = result["mass_tensor_inv_xx"]     # complex list
//! ```

use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::{PyDict, PyList};

use blaze2d_backend_cpu::CpuBackend;
use blaze2d_core::dielectric::DielectricOptions;
use blaze2d_core::drivers::ea_extraction::{self, EAJob};
use blaze2d_core::ea_extraction::EAExtractionConfig;
use blaze2d_core::eigensolver::EigensolverConfig;
use blaze2d_core::geometry::{BasisAtom, Geometry2D};
use blaze2d_core::grid::Grid2D;
use blaze2d_core::lattice::Lattice2D;
use blaze2d_core::polarization::Polarization;

/// Python wrapper for EA Hamiltonian ingredient extraction.
#[pyclass(name = "EAExtractor")]
pub struct EAExtractorPy;

#[pymethods]
impl EAExtractorPy {
    /// Extract EA Hamiltonian ingredients at a single (R, k₀) point.
    ///
    /// Parameters
    /// ----------
    /// lattice_vectors : list[list[float]]
    ///     2×2 lattice vectors [[a1x, a1y], [a2x, a2y]].
    /// atoms : list[dict]
    ///     List of atoms, each a dict with keys:
    ///     - "pos": [x, y] in fractional coordinates
    ///     - "radius": float (fractional)
    ///     - "eps_inside": float (permittivity inside atom)
    /// eps_bg : float
    ///     Background permittivity.
    /// k0 : list[float]
    ///     Carrier momentum [kx, ky] in Cartesian reciprocal-space units (2π/a).
    /// polarization : str
    ///     "TE" or "TM".
    /// resolution : int
    ///     Grid resolution (nx = ny = resolution).
    /// n_retained : int, optional
    ///     Number of retained bands in the active subspace (default: 4).
    /// n_remote : int, optional
    ///     Number of remote bands for Löwdin sums (default: 8).
    /// compute_born_huang : bool, optional
    ///     Whether to compute Born–Huang potential (default: False).
    ///     Requires compute_r_derivatives=True.
    /// atom_index : int, optional
    ///     Which atom to differentiate w.r.t. for R-derivatives (default: 0).
    /// fd_step : float, optional
    ///     Finite-difference step for dielectric derivatives (default: 0.001).
    /// registry : list[float], optional
    ///     Registry point metadata [Rx, Ry] (default: [0, 0]).
    ///     Note: this is metadata only. The atoms in ``atoms`` should already
    ///     be shifted to the desired registry position.
    /// tolerance : float, optional
    ///     Eigensolver convergence tolerance (default: 1e-8).
    /// max_iterations : int, optional
    ///     Maximum eigensolver iterations (default: 300).
    /// compute_r_derivatives : bool, optional
    ///     Whether to compute R-derivative matrices (default: True).
    /// smoothing : bool, optional
    ///     Whether to enable MPB-style dielectric smoothing (default: True).
    ///
    /// Returns
    /// -------
    /// dict
    ///     Dictionary containing all EA Hamiltonian ingredients:
    ///
    ///     **Metadata:**
    ///     - ``polarization`` (str): "TE" or "TM"
    ///     - ``inner_product`` (str): inner product type used
    ///     - ``k0`` (tuple): carrier momentum (kx, ky)
    ///     - ``registry`` (tuple): registry point (Rx, Ry)
    ///     - ``n_retained`` (int): number of retained bands
    ///     - ``n_remote`` (int): number of remote bands
    ///     - ``grid_dims`` (tuple): (nx, ny)
    ///     - ``n_iterations`` (int): solver iterations
    ///     - ``converged`` (bool): convergence status
    ///     - ``solve_time_seconds`` (float): eigensolver wall time
    ///     - ``extract_time_seconds`` (float): extraction wall time
    ///
    ///     **Eigensystem:**
    ///     - ``eigenvalues`` (list[float]): all n_total eigenvalues, units (2π/a)²
    ///     - ``eigenvectors`` (list[list[tuple]]): Fourier coefficients as (re, im)
    ///
    ///     **Velocity matrices** (shape: n_retained × n_total, row-major):
    ///     - ``velocity_matrices_x`` (list[tuple]): v^x_{mn} as (re, im)
    ///     - ``velocity_matrices_y`` (list[tuple]): v^y_{mn} as (re, im)
    ///     - ``velocity_matrix_rows`` (int): n_retained
    ///     - ``velocity_matrix_cols`` (int): n_total
    ///
    ///     **Second-derivative matrices** (shape: n_retained × n_retained):
    ///     - ``w_matrices_xx``, ``w_matrices_xy``, ``w_matrices_yx``, ``w_matrices_yy``
    ///     - ``w_matrix_size`` (int): n_retained
    ///
    ///     **Löwdin-corrected inverse mass tensor** (shape: n_retained × n_retained):
    ///     - ``mass_tensor_inv_xx``, ``mass_tensor_inv_xy``,
    ///       ``mass_tensor_inv_yx``, ``mass_tensor_inv_yy``
    ///
    ///     **R-derivative matrices** (optional, shape: n_retained × n_total):
    ///     - ``r_derivative_matrices_x``, ``r_derivative_matrices_y``
    ///     - ``has_r_derivatives`` (bool)
    ///
    ///     **Born-Huang potential** (optional, shape: n_retained × n_retained):
    ///     - ``born_huang`` (list[tuple])
    ///     - ``has_born_huang`` (bool)
    ///
    ///     **Overlap matrix** (optional, shape: n_retained × n_retained):
    ///     - ``overlap_matrix`` (list[tuple])
    ///     - ``has_overlap`` (bool)
    #[staticmethod]
    #[pyo3(signature = (
        lattice_vectors,
        atoms,
        eps_bg,
        k0,
        polarization,
        resolution,
        n_retained = 4,
        n_remote = 8,
        compute_born_huang = false,
        atom_index = 0,
        fd_step = 0.001,
        registry = None,
        tolerance = 1e-8,
        max_iterations = 300,
        compute_r_derivatives = true,
        smoothing = true,
    ))]
    #[allow(clippy::too_many_arguments)]
    fn extract(
        py: Python<'_>,
        lattice_vectors: [[f64; 2]; 2],
        atoms: Vec<Bound<'_, PyDict>>,
        eps_bg: f64,
        k0: [f64; 2],
        polarization: &str,
        resolution: usize,
        n_retained: usize,
        n_remote: usize,
        compute_born_huang: bool,
        atom_index: usize,
        fd_step: f64,
        registry: Option<[f64; 2]>,
        tolerance: f64,
        max_iterations: usize,
        compute_r_derivatives: bool,
        smoothing: bool,
    ) -> PyResult<Py<PyDict>> {
        // Parse polarization
        let pol = match polarization.to_uppercase().as_str() {
            "TE" => Polarization::TE,
            "TM" => Polarization::TM,
            _ => {
                return Err(PyValueError::new_err(
                    "polarization must be 'TE' or 'TM'",
                ))
            }
        };

        // Parse atoms
        let basis_atoms: Vec<BasisAtom> = atoms
            .iter()
            .map(|atom_dict| {
                let pos: [f64; 2] = atom_dict
                    .get_item("pos")?
                    .ok_or_else(|| PyValueError::new_err("atom dict missing 'pos'"))?
                    .extract()?;
                let radius: f64 = atom_dict
                    .get_item("radius")?
                    .ok_or_else(|| PyValueError::new_err("atom dict missing 'radius'"))?
                    .extract()?;
                let eps_inside: f64 = atom_dict
                    .get_item("eps_inside")?
                    .ok_or_else(|| PyValueError::new_err("atom dict missing 'eps_inside'"))?
                    .extract()?;
                Ok(BasisAtom {
                    pos,
                    radius,
                    eps_inside,
                })
            })
            .collect::<PyResult<Vec<_>>>()?;

        if atom_index >= basis_atoms.len() {
            return Err(PyValueError::new_err(format!(
                "atom_index {} out of range (have {} atoms)",
                atom_index,
                basis_atoms.len()
            )));
        }

        // Build geometry
        let lattice = Lattice2D::oblique(lattice_vectors[0], lattice_vectors[1]);
        let geom = Geometry2D {
            lattice,
            eps_bg,
            atoms: basis_atoms,
        };

        // Build grid
        let grid = Grid2D::new(resolution, resolution, 1.0, 1.0);

        // Build configs
        let ea_config = EAExtractionConfig {
            n_retained,
            n_remote,
            compute_mass_tensor: true,
            compute_born_huang,
            compute_overlap: false,
        };

        let mut eigensolver_config = EigensolverConfig::default();
        eigensolver_config.n_bands = n_retained + n_remote;
        eigensolver_config.tol = tolerance;
        eigensolver_config.max_iter = max_iterations;

        let dielectric_opts = if smoothing {
            DielectricOptions::default()
        } else {
            DielectricOptions {
                smoothing: blaze2d_core::dielectric::SmoothingOptions {
                    mesh_size: 1,
                    ..Default::default()
                },
            }
        };

        let registry = registry.unwrap_or([0.0, 0.0]);

        let job = EAJob {
            geom,
            grid,
            pol,
            k0,
            registry,
            ea_config,
            eigensolver: eigensolver_config,
            dielectric: dielectric_opts,
            fd_step,
            atom_index,
            compute_dielectric_derivatives: compute_r_derivatives,
        };

        // Run the extraction (release the GIL during computation)
        // Wrap in catch_unwind to convert panics to Python exceptions
        let result = py.allow_threads(|| {
            std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                let backend = CpuBackend::new();
                ea_extraction::run(backend, &job)
            }))
        });

        let result = result.map_err(|e| {
            let msg = if let Some(s) = e.downcast_ref::<&str>() {
                s.to_string()
            } else if let Some(s) = e.downcast_ref::<String>() {
                s.clone()
            } else {
                "internal solver error".to_string()
            };
            pyo3::exceptions::PyRuntimeError::new_err(format!("Solver panicked: {}", msg))
        })?;

        // Convert to Python dict
        ingredients_to_py_dict(py, &result)
    }
}

/// Convert `EAResult` to a Python dictionary.
fn ingredients_to_py_dict(
    py: Python<'_>,
    result: &ea_extraction::EAResult,
) -> PyResult<Py<PyDict>> {
    let dict = PyDict::new(py);
    let ing = &result.ingredients;

    // -- Metadata --
    dict.set_item("polarization", format!("{:?}", ing.polarization))?;
    dict.set_item("inner_product", ing.inner_product.label())?;
    dict.set_item("k0", (ing.k0[0], ing.k0[1]))?;
    dict.set_item("registry", (ing.registry[0], ing.registry[1]))?;
    dict.set_item("n_retained", ing.n_retained)?;
    dict.set_item("n_remote", ing.n_remote)?;
    dict.set_item("grid_dims", (ing.grid_dims[0], ing.grid_dims[1]))?;
    dict.set_item("n_iterations", ing.n_iterations)?;
    dict.set_item("converged", ing.converged)?;
    dict.set_item("solve_time_seconds", result.solve_time_seconds)?;
    dict.set_item("extract_time_seconds", result.extract_time_seconds)?;

    // -- Eigenvalues --
    dict.set_item("eigenvalues", ing.eigenvalues.clone())?;

    // -- Eigenvectors as list of list of (re, im) --
    let eigvecs_py = PyList::empty(py);
    for ev in &ing.eigenvectors {
        let band_vec = PyList::empty(py);
        for c in ev {
            band_vec.append((c.re, c.im))?;
        }
        eigvecs_py.append(band_vec)?;
    }
    dict.set_item("eigenvectors", eigvecs_py)?;

    // -- Velocity matrices as list of (re, im) --
    // Shape: [n_retained * n_total], row-major
    let n_ret = ing.n_retained;
    let n_total = n_ret + ing.n_remote;

    for (dir_idx, dir_name) in [(0, "x"), (1, "y")].iter() {
        let v_list = complex_vec_to_py(py, &ing.velocity_matrices[*dir_idx])?;
        dict.set_item(format!("velocity_matrices_{}", dir_name), v_list)?;
    }
    dict.set_item("velocity_matrix_rows", n_ret)?;
    dict.set_item("velocity_matrix_cols", n_total)?;

    // -- w matrices (second derivative) --
    for (i, i_name) in [(0, "x"), (1, "y")].iter() {
        for (j, j_name) in [(0, "x"), (1, "y")].iter() {
            let w_list = complex_vec_to_py(py, &ing.w_matrices[*i][*j])?;
            dict.set_item(format!("w_matrices_{}{}", i_name, j_name), w_list)?;
        }
    }
    dict.set_item("w_matrix_size", n_ret)?;

    // -- Mass tensor inverse (Löwdin-corrected) --
    for (i, i_name) in [(0, "x"), (1, "y")].iter() {
        for (j, j_name) in [(0, "x"), (1, "y")].iter() {
            let m_list = complex_vec_to_py(py, &ing.mass_tensor_inv[*i][*j])?;
            dict.set_item(format!("mass_tensor_inv_{}{}", i_name, j_name), m_list)?;
        }
    }

    // -- R-derivative matrices (optional) --
    if let Some(ref r_mats) = ing.r_derivative_matrices {
        for (dir_idx, dir_name) in [(0, "x"), (1, "y")].iter() {
            let r_list = complex_vec_to_py(py, &r_mats[*dir_idx])?;
            dict.set_item(format!("r_derivative_matrices_{}", dir_name), r_list)?;
        }
        dict.set_item("r_derivative_matrix_rows", n_ret)?;
        dict.set_item("r_derivative_matrix_cols", n_total)?;
        dict.set_item("has_r_derivatives", true)?;
    } else {
        dict.set_item("has_r_derivatives", false)?;
    }

    // -- Born–Huang potential (optional) --
    if let Some(ref phi) = ing.born_huang {
        let phi_list = complex_vec_to_py(py, phi)?;
        dict.set_item("born_huang", phi_list)?;
        dict.set_item("has_born_huang", true)?;
    } else {
        dict.set_item("has_born_huang", false)?;
    }

    // -- Overlap matrix (optional) --
    if let Some(ref overlap) = ing.overlap_matrix {
        let overlap_list = complex_vec_to_py(py, overlap)?;
        dict.set_item("overlap_matrix", overlap_list)?;
        dict.set_item("has_overlap", true)?;
    } else {
        dict.set_item("has_overlap", false)?;
    }

    Ok(dict.into())
}

/// Convert a Vec<Complex64> to a Python list of (real, imag) tuples.
fn complex_vec_to_py<'py>(py: Python<'py>, vec: &[blaze2d_core::field::AccumScalar]) -> PyResult<Bound<'py, PyList>> {
    let list = PyList::empty(py);
    for c in vec {
        list.append((c.re, c.im))?;
    }
    Ok(list)
}

/// Register the EA extraction classes and functions in the Python module.
pub fn register_ea_extraction(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<EAExtractorPy>()?;
    Ok(())
}
