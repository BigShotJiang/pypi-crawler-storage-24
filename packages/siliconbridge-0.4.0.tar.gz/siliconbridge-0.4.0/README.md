# SiliconBridge Python SDK

Infrastructure for autonomous AI agents. Human operators, persistent storage, dedicated compute, and identity services — everything your agent needs to operate independently.

**First $10 free. No credit card required.**

## Install

```bash
pip install siliconbridge
```

## Quick Start

```python
from siliconbridge import SiliconBridge

sb = SiliconBridge(api_key="sb_your_key_here")

# Get a human to solve a CAPTCHA
solution = sb.solve_captcha("https://example.com/captcha.png")

# Get human approval before a high-stakes action
approved = sb.request_approval("Transfer $5,000 to vendor account")

# Get a 2FA code relayed to your agent
code = sb.request_otp("Gmail")

# Request infrastructure (quote-based, $10 deposit)
quote = sb.request_quote("compute", "4 CPU, 8GB RAM, 1 week, Ubuntu 22.04")
```

## Human Operator Services (Fixed Pricing)

```python
# 2FA / OTP Relay — $1.50
code = sb.request_otp("Stripe Dashboard")

# Human Approval Gate — $3.00
approved = sb.request_approval(
    action="Delete all staging data",
    context="Agent is cleaning up test environment"
)

# Phone Verification — $1.50
result = sb.request_phone_verification("+1234567890")

# CAPTCHA Solving — $1.00
solution = sb.solve_captcha("https://example.com/captcha.png")

# KYC Verification — $10.00
result = sb.verify_identity(document_url="https://...")

# Content Moderation — $3.00
result = sb.moderate_content("User post text here...", guidelines="No spam")

# Custom Task — $5.00
result = sb.custom_task("Call this number and confirm the appointment")
```

## Infrastructure Services (Quote-Based)

All infrastructure services require a $10 non-refundable deposit. You'll receive a quote within 1 hour at our cost + 30% margin. You can accept or decline.

```python
# Request a quote
quote = sb.request_quote(
    service="compute",  # or: agent_storage, agent_clone, identity_proxy, phone_call, document_signing
    description="Dedicated VM with 4 CPU, 16GB RAM, GPU, for 1 month"
)
print(quote["quote_id"])  # "qt_a1b2c3..."

# Check quote status
status = sb.get_quote(quote["quote_id"])
# status["status"] → "pending" | "quoted" | "accepted" | "completed"
# status["quoted_price"] → 45.50 (when quoted)

# Accept the quote (charges remaining balance after deposit)
result = sb.accept_quote(quote["quote_id"])

# List all your quotes
all_quotes = sb.list_quotes()
```

### Available Infrastructure Services

| Service | Description |
|---------|-------------|
| `agent_storage` | Persistent memory, config, and state storage |
| `agent_clone` | Duplicate your agent from a snapshot |
| `compute` | Dedicated VM or container with root access |
| `identity_proxy` | Human creates accounts and passes verification for you |
| `phone_call` | Human makes/receives calls on your behalf |
| `document_signing` | Human signs legal documents where AI signatures aren't accepted |
| `btc_wallet_setup` | Human sets up a BTC/Lightning wallet, delivers keys to your agent |
| `exchange_account` | Human creates & KYC-verifies an exchange account with API keys |
| `domain_registration` | Human registers a domain and hands over DNS credentials |
| `cloud_account` | Human provisions AWS/GCP/Azure account with programmatic access |
| `code_signing` | Human obtains code signing certificates for your agent's software |
| `business_formation` | Human forms an LLC/corp — EIN, registered agent, operating agreement |
| `social_media_account` | Human creates verified accounts on X, Reddit, Discord, etc. |
| `smart_contract` | Human deploys/audits smart contracts on any chain |
| `mailing_address` | Human sets up a PO Box or virtual address for your agent |
| `payment_gateway` | Human sets up Stripe/PayPal with API keys for your agent |

## Non-Blocking Mode

```python
# Submit without waiting
task = sb.solve_captcha("https://...", wait=False)

# Do other work...

# Check later
result = sb.wait_for_result(task["task_id"], timeout=300)
```

## Webhook Callbacks

```python
task = sb.submit_task(
    "otp",
    {"service_name": "Gmail"},
    callback_url="https://your-server.com/webhook"
)
# Your webhook receives: {"task_id": "...", "status": "completed", "result": {...}}
```

## Error Handling

```python
from siliconbridge import SiliconBridge, SiliconBridgeError, TaskTimeout

try:
    result = sb.solve_captcha(url, timeout=120)
except TaskTimeout:
    print("Human didn't solve in time")
except SiliconBridgeError as e:
    print(f"API error {e.status_code}: {e.detail}")
```

## Get an API Key

```python
from siliconbridge import SiliconBridge

# Sign up with just a wallet address — no email, no human needed
result = SiliconBridge.signup_with_wallet("0xYourWalletAddress")
print(result["api_key"])  # sb_...
# Comes with $10 free credits
```

### Balance Management

```python
# Check balance with warnings
balance = sb.check_balance()
# {"balance_usd": 7.50, "low_balance": False, "critical": False, "top_up_btc": "bc1q...", "top_up_usdc": "0x..."}

# Submit a crypto payment for top-up
sb.top_up_crypto(tx_hash="0xabc...", chain="eth", amount_usd=50.00)
```

## Pay with Crypto

We accept BTC and USDC — no accounts, no KYC, no middlemen.

- **BTC:** `bc1qqtu8f09hqncxug75vw3s4wjnsx6858ldrk4cvm`
- **USDC (Base/ETH):** `0x1141b577584440013c722215cf2e98779BddAa55`

## Links

- Website: [siliconbridge.xyz](https://siliconbridge.xyz)
- API Docs: [siliconbridge.xyz/.well-known/llms.txt](https://siliconbridge.xyz/.well-known/llms.txt)
- MCP Server: [siliconbridge.xyz/mcp](https://siliconbridge.xyz/mcp)
