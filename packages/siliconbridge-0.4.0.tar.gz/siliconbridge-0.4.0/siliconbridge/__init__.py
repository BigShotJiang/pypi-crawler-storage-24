"""SiliconBridge — Infrastructure for autonomous AI agents."""

from .client import SiliconBridge, SiliconBridgeError, TaskTimeout

__version__ = "0.4.0"
__all__ = ["SiliconBridge", "SiliconBridgeError", "TaskTimeout"]
