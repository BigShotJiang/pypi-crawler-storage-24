from setuptools import setup, find_packages

setup(
    name="siliconbridge",
    version="0.1.0",
    description="Python SDK for SiliconBridge — Human-in-the-loop API for AI agents",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="SiliconBridge",
    author_email="xsiliconbridgex@gmail.com",
    url="https://siliconbridge.xyz",
    project_urls={
        "Documentation": "https://siliconbridge.xyz",
        "Source": "https://github.com/aataqi-boop/siliconbridge-python",
    },
    packages=find_packages(),
    install_requires=["httpx>=0.24.0"],
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries",
    ],
    keywords="ai agents human-in-the-loop captcha verification moderation",
)
