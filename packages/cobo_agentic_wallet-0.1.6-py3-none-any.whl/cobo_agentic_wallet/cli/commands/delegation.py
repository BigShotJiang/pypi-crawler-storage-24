"""Delegation management commands."""

from __future__ import annotations

from typing import Any

import typer

from cobo_agentic_wallet.cli._common import get_context, run_with_client, resolve_wallet_uuid
from cobo_agentic_wallet.cli._freeze import (
    FreezeScope,
    estimate_affected_count,
    infer_owner_id,
    validate_scope_params,
)
from cobo_agentic_wallet.cli._common import run_command
from cobo_agentic_wallet.cli._output import emit
from cobo_agentic_wallet.client import WalletAPIClient
from cobo_agentic_wallet_api.models.delegation_permission import DelegationPermission
from cobo_agentic_wallet_api.models.freeze_scope import FreezeScope as SDKFreezeScope
from cobo_agentic_wallet_api.models.inline_policy_create import InlinePolicyCreate
from cobo_agentic_wallet_api.models.policy_type import PolicyType

app = typer.Typer(no_args_is_help=True)


@app.command("create")
def create_delegation(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(None, help="Wallet UUID. Falls back to config file."),
    to: str = typer.Option(..., "--to", help="Operator principal UUID."),
    max_tx: str = typer.Option(..., "--max-tx", help="Maximum amount per transaction."),
    permission: list[str] | None = typer.Option(
        None,
        "--permission",
        help="Permission to grant. Can be repeated.",
    ),
) -> None:
    """Create a delegation with an operator role and max-per-tx constraint."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)
    permission_list = permission or ["operator"]
    permissions_enum = [DelegationPermission(p) for p in permission_list]
    policies = [
        InlinePolicyCreate(
            name="max_per_tx",
            type=PolicyType.TRANSFER,
            rules={"max_per_tx": max_tx},
        )
    ]

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.create_delegation(
            operator_id=to,
            wallet_id=wallet_uuid,
            permissions=permissions_enum,
            policies=policies,
        )

    run_command(ctx, _operation)


@app.command("list")
def list_delegations(
    ctx: typer.Context,
    wallet_id: str | None = typer.Option(None, "--wallet-id", help="Filter by wallet UUID."),
    status: str | None = typer.Option(None, "--status", help="Filter by delegation status."),
    limit: int = typer.Option(50, min=1, max=200),
    offset: int = typer.Option(0, min=0),
) -> None:
    """List delegations created by the current principal (as owner)."""
    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_delegations(
            wallet_id=wallet_id, status=status, limit=limit, offset=offset,
        )

    run_command(ctx, _operation)


@app.command("get")
def get_delegation(
    ctx: typer.Context,
    delegation_id: str = typer.Argument(..., help="Delegation UUID."),
) -> None:
    """Get delegation details by ID."""
    async def _operation(client: WalletAPIClient) -> Any:
        return await client.get_delegation(delegation_id)

    run_command(ctx, _operation)


@app.command("update")
def update_delegation(
    ctx: typer.Context,
    delegation_id: str = typer.Argument(..., help="Delegation UUID."),
    max_tx: str | None = typer.Option(None, "--max-tx", help="New maximum amount per transaction."),
) -> None:
    """Update delegation properties."""
    async def _operation(client: WalletAPIClient) -> Any:
        from cobo_agentic_wallet_api.models.delegation_update import DelegationUpdate
        policies = None
        if max_tx is not None:
            policies = [
                InlinePolicyCreate(
                    name="max_per_tx",
                    type=PolicyType.TRANSFER,
                    rules={"max_per_tx": max_tx},
                )
            ]
        update = DelegationUpdate(policies=policies)
        return await client.update_delegation(delegation_id, update)

    run_command(ctx, _operation)


@app.command("revoke")
def revoke_delegation(
    ctx: typer.Context,
    delegation_id: str = typer.Argument(..., help="Delegation UUID."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
) -> None:
    """Revoke a delegation."""
    context = get_context(ctx)

    if not yes:
        confirmed = typer.confirm(f"Revoke delegation {delegation_id}?", default=False)
        if not confirmed:
            emit({"cancelled": True, "delegation_id": delegation_id}, context.output_format)
            return

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.revoke_delegation(delegation_id)

    run_command(ctx, _operation)


@app.command("received")
def received_delegations(
    ctx: typer.Context,
    owner_id: str | None = typer.Option(None, "--owner-id", help="Filter by owner principal UUID."),
    wallet_id: str | None = typer.Option(None, "--wallet-id", help="Filter by wallet UUID."),
    status: str | None = typer.Option(None, "--status", help="Filter by delegation status."),
    limit: int = typer.Option(50, min=1, max=200),
    offset: int = typer.Option(0, min=0),
) -> None:
    """List delegations received by the current principal (as operator)."""
    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_received_delegations(
            owner_id=owner_id, wallet_id=wallet_id, status=status, limit=limit, offset=offset,
        )

    run_command(ctx, _operation)


def _apply_freeze(
    ctx: typer.Context,
    *,
    frozen: bool,
    scope: FreezeScope,
    owner_id: str | None,
    wallet_id: str | None,
    delegation_id: str | None,
    reason: str | None,
    yes: bool,
    dry_run: bool,
) -> None:
    """Shared implementation for freeze and unfreeze commands."""
    context = get_context(ctx)
    validate_scope_params(
        scope=scope, owner_id=owner_id, wallet_id=wallet_id, delegation_id=delegation_id,
    )
    verb = "Freeze" if frozen else "Unfreeze"

    async def _operation(client: WalletAPIClient) -> Any:
        resolved_owner_id = owner_id
        if scope == FreezeScope.OWNER and resolved_owner_id is None:
            resolved_owner_id = await infer_owner_id(client)
            if resolved_owner_id is None:
                raise RuntimeError(
                    "Unable to infer owner_id automatically. Pass --owner-id for --scope owner."
                )

        estimated: int | None = None
        if dry_run or not yes:
            estimated = await estimate_affected_count(
                client,
                scope=scope,
                delegation_id=delegation_id,
                wallet_id=wallet_id,
                frozen_state=frozen,
            )
        if dry_run:
            assert estimated is not None
            return {"dry_run": True, "scope": scope.value, "estimated_count": estimated}
        if not yes:
            confirmed = typer.confirm(f"{verb} {estimated} delegation(s)?", default=False)
            if not confirmed:
                return {"cancelled": True, "scope": scope.value, "estimated_count": estimated}

        if frozen:
            return await client.freeze_delegations(
                scope=SDKFreezeScope(scope.value),
                owner_id=resolved_owner_id,
                wallet_id=wallet_id,
                delegation_id=delegation_id,
                reason=reason,
            )
        return await client.unfreeze_delegations(
            scope=SDKFreezeScope(scope.value),
            owner_id=resolved_owner_id,
            wallet_id=wallet_id,
            delegation_id=delegation_id,
            reason=reason,
        )

    result = run_with_client(context, _operation)
    emit(result, context.output_format)


@app.command("freeze")
def freeze(
    ctx: typer.Context,
    scope: FreezeScope = typer.Option(..., "--scope", case_sensitive=False),
    owner_id: str | None = typer.Option(
        None, "--owner-id", help="Owner principal UUID. Optional for --scope owner if inferable.",
    ),
    wallet_id: str | None = typer.Option(
        None, "--wallet-id", help="Wallet UUID for --scope wallet.",
    ),
    delegation_id: str | None = typer.Option(
        None, "--delegation-id", help="Delegation UUID for --scope delegation.",
    ),
    reason: str | None = typer.Option(None, "--reason", help="Optional freeze reason."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview affected count without applying."),
) -> None:
    """Freeze delegations by owner, wallet, or delegation scope."""
    _apply_freeze(
        ctx, frozen=True, scope=scope, owner_id=owner_id, wallet_id=wallet_id,
        delegation_id=delegation_id, reason=reason, yes=yes, dry_run=dry_run,
    )


@app.command("unfreeze")
def unfreeze(
    ctx: typer.Context,
    scope: FreezeScope = typer.Option(..., "--scope", case_sensitive=False),
    owner_id: str | None = typer.Option(
        None, "--owner-id", help="Owner principal UUID. Optional for --scope owner if inferable.",
    ),
    wallet_id: str | None = typer.Option(
        None, "--wallet-id", help="Wallet UUID for --scope wallet.",
    ),
    delegation_id: str | None = typer.Option(
        None, "--delegation-id", help="Delegation UUID for --scope delegation.",
    ),
    reason: str | None = typer.Option(None, "--reason", help="Optional unfreeze reason."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview affected count without applying."),
) -> None:
    """Unfreeze delegations by owner, wallet, or delegation scope."""
    _apply_freeze(
        ctx, frozen=False, scope=scope, owner_id=owner_id, wallet_id=wallet_id,
        delegation_id=delegation_id, reason=reason, yes=yes, dry_run=dry_run,
    )