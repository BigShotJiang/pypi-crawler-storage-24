"""Agent management commands."""

from __future__ import annotations

from typing import Any

import typer

from cobo_agentic_wallet.cli._common import get_context
from cobo_agentic_wallet.cli._common import run_command
from cobo_agentic_wallet.cli._output import emit
from cobo_agentic_wallet.client import WalletAPIClient

app = typer.Typer(no_args_is_help=True)

# Sub-group for API key management
apikey_app = typer.Typer(no_args_is_help=True, help="API key management")
app.add_typer(apikey_app, name="api-key")


@app.command("status")
def agent_status(
    ctx: typer.Context,
    agent_id: str | None = typer.Option(None, "--agent-id", help="Agent ID. If not provided, uses current agent."),
) -> None:
    """Get agent status."""
    async def _operation(client: WalletAPIClient) -> Any:
        return await client.get_agent_status(agent_id=agent_id)

    run_command(ctx, _operation)


@app.command("list")
def list_agents(
    ctx: typer.Context,
    limit: int = typer.Option(50, min=1, max=200),
    offset: int = typer.Option(0, min=0),
) -> None:
    """List agents owned by current principal."""
    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_my_agents(limit=limit, offset=offset)

    run_command(ctx, _operation)


@apikey_app.command("create")
def create_api_key(
    ctx: typer.Context,
    name: str = typer.Option(..., "--name", help="API key name."),
    agent_id: str | None = typer.Option(None, "--agent-id", help="Agent ID. If not provided, uses current agent."),
) -> None:
    """Create a new API key."""
    async def _operation(client: WalletAPIClient) -> Any:
        return await client.create_api_key(name=name, agent_id=agent_id)

    run_command(ctx, _operation)


@apikey_app.command("list")
def list_api_keys(
    ctx: typer.Context,
    agent_id: str | None = typer.Option(None, "--agent-id", help="Agent ID. If not provided, uses current agent."),
    limit: int = typer.Option(50, min=1, max=200),
    offset: int = typer.Option(0, min=0),
) -> None:
    """List API keys."""
    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_api_keys(agent_id=agent_id, limit=limit, offset=offset)

    run_command(ctx, _operation)


@apikey_app.command("revoke")
def revoke_api_key(
    ctx: typer.Context,
    api_key_id: str = typer.Argument(..., help="API key ID to revoke."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
) -> None:
    """Revoke an API key."""
    context = get_context(ctx)

    if not yes:
        confirmed = typer.confirm(f"Revoke API key {api_key_id}?", default=False)
        if not confirmed:
            emit({"cancelled": True, "api_key_id": api_key_id}, context.output_format)
            return

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.revoke_api_key(api_key_id)

    run_command(ctx, _operation)