"""Audit log commands."""

from __future__ import annotations

from typing import Any

import typer

from cobo_agentic_wallet.cli._common import run_command
from cobo_agentic_wallet.client import WalletAPIClient

app = typer.Typer(no_args_is_help=True)


@app.command("logs")
def audit_logs(
    ctx: typer.Context,
    wallet: str | None = typer.Option(None, "--wallet", help="Wallet UUID filter."),
    result: str | None = typer.Option(
        None, "--result", help="Result filter: allowed/denied/error."
    ),
    action: str | None = typer.Option(None, "--action", help="Action filter."),
    cursor: str | None = typer.Option(None, "--cursor", help="Cursor token."),
    limit: int = typer.Option(50, min=1, max=200),
) -> None:
    """Query audit logs with optional filters."""
    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_audit_logs(
            wallet_id=wallet, result=result, action=action, cursor=cursor, limit=limit,
        )

    run_command(ctx, _operation)