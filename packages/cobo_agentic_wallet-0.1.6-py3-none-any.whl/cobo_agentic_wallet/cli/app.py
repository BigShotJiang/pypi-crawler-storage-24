"""Typer CLI application definition."""

from __future__ import annotations

from contextlib import suppress

import typer

from cobo_agentic_wallet.cli._common import (
    AGENT_WALLET_API_KEY,
    AGENT_WALLET_API_URL,
    AGENT_WALLET_TIMEOUT,
    CLIContext,
    OutputFormat,
)
from cobo_agentic_wallet.cli.config import load_config

app = typer.Typer(
    add_completion=False,
    no_args_is_help=True,
    help="Cobo Agent Wallet CLI",
)


@app.callback()
def main(
    ctx: typer.Context,
    api_key: str | None = typer.Option(
        None,
        "--api-key",
        envvar=AGENT_WALLET_API_KEY,
        help="AgentWallet API key. Falls back to AGENT_WALLET_API_KEY.",
    ),
    api_url: str = typer.Option(
        "http://localhost:8000",
        "--api-url",
        envvar=AGENT_WALLET_API_URL,
        help="AgentWallet API URL. Falls back to AGENT_WALLET_API_URL.",
    ),
    timeout: float = typer.Option(
        30.0,
        "--timeout",
        envvar=AGENT_WALLET_TIMEOUT,
        help="Request timeout in seconds. Falls back to AGENT_WALLET_TIMEOUT.",
    ),
    output_format: OutputFormat = typer.Option(
        OutputFormat.JSON,
        "--format",
        case_sensitive=False,
        help="Output format: json or table.",
    ),
) -> None:
    """Configure global CLI options."""
    if ctx.resilient_parsing:
        return

    # Fall back to config file for api_key and api_url when not explicitly provided.
    if not api_key or api_url == "http://localhost:8000":
        with suppress(FileNotFoundError, ValueError):
            config = load_config()
            if not api_key:
                api_key = str(config.get("api_key", "")).strip() or None
            if api_url == "http://localhost:8000" and config.get("api_url"):
                api_url = str(config["api_url"]).strip()

    ctx.obj = CLIContext(
        api_key=api_key or "",
        api_url=api_url,
        timeout=timeout,
        output_format=output_format,
    )


# Import and register command groups
from cobo_agentic_wallet.cli.commands import (  # noqa: E402
    address,
    agent,
    audit,
    delegation,
    meta,
    onboard,
    pending,
    policy,
    tx,
    wallet,
)

app.add_typer(wallet.app, name="wallet", help="Wallet management commands")
app.add_typer(address.app, name="address", help="Address management commands")
app.add_typer(tx.app, name="tx", help="Transaction and contract call commands")
app.add_typer(delegation.app, name="delegation", help="Delegation management commands")
app.add_typer(policy.app, name="policy", help="Policy management commands")
app.add_typer(pending.app, name="pending", help="Pending operation commands")
app.add_typer(agent.app, name="agent", help="Agent management commands")
app.add_typer(audit.app, name="audit", help="Audit log commands")
app.add_typer(meta.app, name="meta", help="Metadata commands (chains, tokens, prices)")
app.add_typer(onboard.app, name="onboard", help="Onboarding commands")


@app.command("demo")
def demo(ctx: typer.Context) -> None:
    """Run quickstart demo workflow."""
    from cobo_agentic_wallet.cli.commands.onboard import demo as onboard_demo
    onboard_demo(ctx)