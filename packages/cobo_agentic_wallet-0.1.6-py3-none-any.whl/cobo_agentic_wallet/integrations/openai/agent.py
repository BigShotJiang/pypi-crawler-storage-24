"""OpenAI Agents SDK helper for Cobo Agent Wallet."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from cobo_agentic_wallet.client import WalletAPIClient
from cobo_agentic_wallet.integrations.openai.tools import build_function_tools
from cobo_agentic_wallet.toolkit import AgentWalletToolkit

try:
    from agents import Agent
    from agents.run_context import RunContextWrapper
    from agents.tool import FunctionTool
except Exception as exc:  # pragma: no cover - import guard
    # Catch all exceptions (not just ImportError) to handle cases where
    # the package is installed but fails during import (e.g., ValidationError)
    raise ImportError(
        "openai-agents is required for this integration. "
        f"Install with: pip install 'cobo-agent-wallet[openai]'. Original error: {exc}"
    ) from exc


@dataclass
class CoboOpenAIAgentContext:
    """Mutable local run context for Cobo OpenAI agents."""

    denial_messages: list[str] = field(default_factory=list)

    @property
    def last_policy_denial(self) -> str | None:
        if not self.denial_messages:
            return None
        return self.denial_messages[-1]


def create_cobo_agent_context() -> CoboOpenAIAgentContext:
    """Create a default run context object for ``create_cobo_agent``."""

    return CoboOpenAIAgentContext()


def _record_policy_denial(context: Any, denial_text: str) -> None:
    if context is None:
        return

    denial_messages = getattr(context, "denial_messages", None)
    if isinstance(denial_messages, list):
        denial_messages.append(denial_text)
        return

    # Best-effort fallback for custom contexts.
    if hasattr(context, "last_policy_denial"):
        setattr(context, "last_policy_denial", denial_text)


def _build_instructions(
    *,
    base_instructions: str,
) -> Callable[[RunContextWrapper[Any], Agent[Any]], str]:
    def _instructions(wrapper: RunContextWrapper[Any], _agent: Agent[Any]) -> str:
        context = getattr(wrapper, "context", None)
        latest_denial: str | None = None

        if context is not None:
            denial_messages = getattr(context, "denial_messages", None)
            if isinstance(denial_messages, list) and denial_messages:
                latest_denial = str(denial_messages[-1])
            else:
                fallback_denial = getattr(context, "last_policy_denial", None)
                if isinstance(fallback_denial, str) and fallback_denial:
                    latest_denial = fallback_denial

        if not latest_denial:
            return base_instructions

        return (
            f"{base_instructions}\n\n"
            "Latest wallet policy denial guidance from previous tool execution:\n"
            f"{latest_denial}\n\n"
            "If you retry, strictly follow the denial suggestion."
        )

    return _instructions


def get_cobo_tools(client: WalletAPIClient) -> list[FunctionTool]:
    """Return OpenAI FunctionTool instances for all canonical Cobo wallet tools."""

    base_toolkit = AgentWalletToolkit(client)
    return build_function_tools(base_toolkit, denial_recorder=_record_policy_denial)


def create_cobo_agent(
    client: WalletAPIClient,
    *,
    name: str = "cobo-wallet-agent",
    model: str | Any | None = "gpt-4.1-mini",
    instructions: str | None = None,
    **agent_kwargs: Any,
) -> Agent[Any]:
    """Create an OpenAI Agent preconfigured with all Cobo wallet tools."""

    tools = get_cobo_tools(client)
    resolved_instructions = instructions or (
        "You are a wallet operator. Use Cobo wallet tools for all balance, transfer, "
        "audit, delegation, and policy tasks. If a transfer is denied by policy, read "
        "the denial details and retry with compliant parameters."
    )

    resolved_agent_kwargs: dict[str, Any] = {
        "name": name,
        "instructions": _build_instructions(base_instructions=resolved_instructions),
        "tools": tools,
    }
    if model is not None:
        resolved_agent_kwargs["model"] = model
    resolved_agent_kwargs.update(agent_kwargs)
    return Agent(**resolved_agent_kwargs)


__all__ = [
    "CoboOpenAIAgentContext",
    "create_cobo_agent",
    "create_cobo_agent_context",
    "get_cobo_tools",
]
