"""Identity operations mixin (auto-generated).

DO NOT EDIT MANUALLY. Run scripts/generate_mixins.py to regenerate.
"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

from cobo_agentic_wallet_api.models.activate_request import ActivateRequest
from cobo_agentic_wallet_api.models.api_key_create import ApiKeyCreate
from cobo_agentic_wallet_api.models.principal_create import PrincipalCreate
from cobo_agentic_wallet_api.models.provision_request import ProvisionRequest

if TYPE_CHECKING:
    from cobo_agentic_wallet._mixins.base import BaseClient


class IdentityMixin:
    """Identity operations mixin (auto-generated)."""

    _extract_result: Any
    _identity_api: Any

    async def activate_agent(self: "BaseClient", agent_id: str, *, owner_id: str, onboarding_session_id: str | None = None, activation_secret: str | None = None) -> Any:
        """Activate Agent"""
        activate_request = ActivateRequest(owner_id=owner_id, onboarding_session_id=onboarding_session_id, activation_secret=activation_secret)
        response = await self._identity_api.activate_agent(agent_id, activate_request)
        return self._extract_result(response)

    async def create_api_key(self: "BaseClient", name: str, principal_id: str | None = None, scopes: Optional[list[str]] = None, expires_at: datetime | None = None) -> Any:
        """Create Api Key"""
        api_key_create = ApiKeyCreate(principal_id=principal_id, name=name, scopes=scopes, expires_at=expires_at)
        response = await self._identity_api.create_api_key(api_key_create)
        return self._extract_result(response)

    async def create_principal(self: "BaseClient", external_id: str, wallet_type: Any, name: str, metadata: Optional[dict[str, Any]] = None) -> Any:
        """Create Principal"""
        principal_create = PrincipalCreate(external_id=external_id, type=wallet_type, name=name, metadata=metadata)
        response = await self._identity_api.create_principal(principal_create)
        return self._extract_result(response)

    async def get_agent_status(self: "BaseClient", agent_id: str) -> Any:
        """Get Agent Status"""
        response = await self._identity_api.get_agent_status(agent_id)
        return self._extract_result(response)

    async def list_api_keys(self: "BaseClient", offset: int | None = None, limit: int | None = None) -> Any:
        """List Api Keys"""
        response = await self._identity_api.list_api_keys(offset, limit)
        return self._extract_result(response)

    async def list_my_agents(self: "BaseClient", offset: int | None = None, limit: int | None = None) -> Any:
        """List My Agents"""
        response = await self._identity_api.list_my_agents(offset, limit)
        return self._extract_result(response)

    async def list_principals(self: "BaseClient", offset: int | None = None, limit: int | None = None) -> Any:
        """List Principals"""
        response = await self._identity_api.list_principals(offset, limit)
        return self._extract_result(response)

    async def provision_agent(self: "BaseClient", token: str | None = None) -> Any:
        """Provision Agent"""
        provision_request = ProvisionRequest(token=token)
        response = await self._identity_api.provision_agent(provision_request)
        return self._extract_result(response)

    async def revoke_api_key(self: "BaseClient", api_key_id: str) -> Any:
        """Revoke Api Key"""
        response = await self._identity_api.revoke_api_key(api_key_id)
        return self._extract_result(response)
