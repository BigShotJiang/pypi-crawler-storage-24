"""Wallet operations mixin (auto-generated).

DO NOT EDIT MANUALLY. Run scripts/generate_mixins.py to regenerate.
"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

from cobo_agentic_wallet_api.models.wallet_address_create import WalletAddressCreate
from cobo_agentic_wallet_api.models.wallet_create import WalletCreate

if TYPE_CHECKING:
    from cobo_agentic_wallet._mixins.base import BaseClient


class WalletMixin:
    """Wallet operations mixin (auto-generated)."""

    _extract_result: Any
    _wallets_api: Any

    async def archive_wallet(self: "BaseClient", wallet_uuid: str) -> Any:
        """Archive Wallet"""
        response = await self._wallets_api.archive_wallet(wallet_uuid)
        return self._extract_result(response)

    async def create_wallet(self: "BaseClient", wallet_type: Any, name: str, group_type: Any = None, main_node_id: str | None = None, backup_node_id: str | None = None, metadata: Optional[dict[str, Any]] = None, for_owner: bool | None = False) -> Any:
        """Create Wallet"""
        wallet_create = WalletCreate(type=wallet_type, name=name, group_type=group_type, main_node_id=main_node_id, backup_node_id=backup_node_id, metadata=metadata, for_owner=for_owner)
        response = await self._wallets_api.create_wallet(wallet_create)
        return self._extract_result(response)

    async def create_wallet_address(self: "BaseClient", wallet_uuid: str, *, chain_id: str) -> Any:
        """Create Wallet Address"""
        wallet_address_create = WalletAddressCreate(chain_id=chain_id)
        response = await self._wallets_api.create_wallet_address(wallet_uuid, wallet_address_create)
        return self._extract_result(response)

    async def get_wallet(self: "BaseClient", wallet_uuid: str, include_spend_summary: bool | None = None) -> Any:
        """Get Wallet"""
        response = await self._wallets_api.get_wallet(wallet_uuid, include_spend_summary)
        return self._extract_result(response)

    async def get_wallet_node_status(self: "BaseClient", wallet_uuid: str) -> Any:
        """Get Wallet Node Status"""
        response = await self._wallets_api.get_wallet_node_status(wallet_uuid)
        return self._extract_result(response)

    async def list_wallet_addresses(self: "BaseClient", wallet_uuid: str) -> Any:
        """List Wallet Addresses"""
        response = await self._wallets_api.list_wallet_addresses(wallet_uuid)
        return self._extract_result(response)

    async def list_wallet_balances(self: "BaseClient", wallet_uuid: str, address: Optional = None, token_ids: str | None = None, limit: int | None = None, before: str | None = None, after: str | None = None) -> Any:
        """List Wallet Balances"""
        response = await self._wallets_api.list_wallet_balances(wallet_uuid, address, token_ids, limit, before, after)
        return self._extract_result(response)

    async def list_wallets(self: "BaseClient", offset: int | None = None, limit: int | None = None, include_archived: bool | None = None) -> Any:
        """List Wallets"""
        response = await self._wallets_api.list_wallets(offset, limit, include_archived)
        return self._extract_result(response)

    async def update_wallet(self: "BaseClient", wallet_uuid: str, wallet_update: Any) -> Any:
        """Update Wallet"""
        response = await self._wallets_api.update_wallet(wallet_uuid, wallet_update)
        return self._extract_result(response)
