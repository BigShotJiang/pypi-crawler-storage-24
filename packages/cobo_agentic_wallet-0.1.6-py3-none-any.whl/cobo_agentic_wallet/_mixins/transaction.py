"""Transaction operations mixin (auto-generated).

DO NOT EDIT MANUALLY. Run scripts/generate_mixins.py to regenerate.
"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

from cobo_agentic_wallet_api.models.contract_call_create import ContractCallCreate
from cobo_agentic_wallet_api.models.drop_transaction_request import DropTransactionRequest
from cobo_agentic_wallet_api.models.estimate_contract_call_fee_request import EstimateContractCallFeeRequest
from cobo_agentic_wallet_api.models.estimate_transfer_fee_request import EstimateTransferFeeRequest
from cobo_agentic_wallet_api.models.transfer_create import TransferCreate

if TYPE_CHECKING:
    from cobo_agentic_wallet._mixins.base import BaseClient


class TransactionMixin:
    """Transaction operations mixin (auto-generated)."""

    _extract_result: Any
    _transactions_api: Any

    async def contract_call(self: "BaseClient", wallet_uuid: str, *, chain_id: str, contract_addr: str | None = None, value: str | None = '0', calldata: str | None = None, instructions: Any = None, address_lookup_table_accounts: Any = None, request_id: str | None = None, fee: Any = None, src_addr: str | None = None, sponsor: bool | None = True) -> Any:
        """Contract Call"""
        contract_call_create = ContractCallCreate(chain_id=chain_id, contract_addr=contract_addr, value=value, calldata=calldata, instructions=instructions, address_lookup_table_accounts=address_lookup_table_accounts, request_id=request_id, fee=fee, src_addr=src_addr, sponsor=sponsor)
        response = await self._transactions_api.contract_call(wallet_uuid, contract_call_create)
        return self._extract_result(response)

    async def drop_transaction(self: "BaseClient", wallet_uuid: str, transaction_uuid: str, *, request_id: str | None = None, fee: Any = None, cobo_transaction_id: str | None = None) -> Any:
        """Drop Transaction"""
        drop_transaction_request = DropTransactionRequest(request_id=request_id, fee=fee, cobo_transaction_id=cobo_transaction_id)
        response = await self._transactions_api.drop_transaction(wallet_uuid, transaction_uuid, drop_transaction_request)
        return self._extract_result(response)

    async def estimate_contract_call_fee(self: "BaseClient", wallet_uuid: str, *, chain_id: str, contract_addr: str | None = None, value: str | None = '0', calldata: str | None = None, instructions: Any = None, address_lookup_table_accounts: Any = None, src_addr: str | None = None) -> Any:
        """Estimate Contract Call Fee"""
        estimate_contract_call_fee_request = EstimateContractCallFeeRequest(chain_id=chain_id, contract_addr=contract_addr, value=value, calldata=calldata, instructions=instructions, address_lookup_table_accounts=address_lookup_table_accounts, src_addr=src_addr)
        response = await self._transactions_api.estimate_contract_call_fee(wallet_uuid, estimate_contract_call_fee_request)
        return self._extract_result(response)

    async def estimate_transfer_fee(self: "BaseClient", wallet_uuid: str, *, chain_id: str, dst_addr: str, amount: str, token_id: str | None = 'SETH', src_addr: str | None = None) -> Any:
        """Estimate Transfer Fee"""
        estimate_transfer_fee_request = EstimateTransferFeeRequest(chain_id=chain_id, dst_addr=dst_addr, amount=amount, token_id=token_id, src_addr=src_addr)
        response = await self._transactions_api.estimate_transfer_fee(wallet_uuid, estimate_transfer_fee_request)
        return self._extract_result(response)

    async def get_transaction(self: "BaseClient", wallet_uuid: str, transaction_uuid: str) -> Any:
        """Get Transaction"""
        response = await self._transactions_api.get_transaction(wallet_uuid, transaction_uuid)
        return self._extract_result(response)

    async def handle_waas_webhook(self: "BaseClient", body: dict[str, Any], biz_timestamp: str | None = None, biz_resp_signature: str | None = None) -> Any:
        """Handle Waas Webhook"""
        response = await self._transactions_api.handle_waas_webhook(body, biz_timestamp, biz_resp_signature)
        return self._extract_result(response)

    async def list_recent_addresses(self: "BaseClient", wallet_uuid: str, limit: int | None = None) -> Any:
        """List Recent Addresses"""
        response = await self._transactions_api.list_recent_addresses(wallet_uuid, limit)
        return self._extract_result(response)

    async def list_transactions(self: "BaseClient", wallet_uuid: str, offset: int | None = None, limit: int | None = None, status: str | None = None, token_id: str | None = None, chain_id: str | None = None) -> Any:
        """List Transactions"""
        response = await self._transactions_api.list_transactions(wallet_uuid, offset, limit, status, token_id, chain_id)
        return self._extract_result(response)

    async def transfer_tokens(self: "BaseClient", wallet_uuid: str, *, chain_id: str, dst_addr: str, amount: str, token_id: str | None = 'SETH', request_id: str | None = None, fee: Any = None, src_addr: str | None = None, sponsor: bool | None = True) -> Any:
        """Transfer Tokens"""
        transfer_create = TransferCreate(chain_id=chain_id, dst_addr=dst_addr, amount=amount, token_id=token_id, request_id=request_id, fee=fee, src_addr=src_addr, sponsor=sponsor)
        response = await self._transactions_api.transfer_tokens(wallet_uuid, transfer_create)
        return self._extract_result(response)
