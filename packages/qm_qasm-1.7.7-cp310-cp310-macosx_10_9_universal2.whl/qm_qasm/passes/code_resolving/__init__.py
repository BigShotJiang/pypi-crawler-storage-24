from typing import Set, Tuple

from qm_qasm.configurations.compilation_config import CompilationConfig
from qm_qasm.passes.compilation_pass import CompilationPass, Step
from qm_qasm.passes.code_resolving.assignment_normalizer import ClassicalAssignmentNormalizer
from qm_qasm.passes.code_resolving.validators import does_not_contain_modifiers, are_quantum_statements_explicitly_defined
from qm_qasm.passes.code_resolving.constants_resolving_step import ConstantsResolvingStep
from qm_qasm.passes.code_resolving.expression_optimization_step import ExpressionsOptimizationStep
from qm_qasm.passes.feature_validation import AllowedFeatureValidation
from qm_qasm.passes.code_resolving.gate_resolver_step import GateSignature, GateResolverStep
from qm_qasm.programs import OpenQasmProgram


class CodeResolvingPass(CompilationPass):
    input_class = OpenQasmProgram
    output_class = OpenQasmProgram

    def __init__(self, compilation_config: CompilationConfig, built_in_gates: Set[GateSignature]):
        steps: Tuple[Step, ...] = (
            # AllowedFeatureValidation(criterion=is_same_types),
            AllowedFeatureValidation(criterion=does_not_contain_modifiers),
            AllowedFeatureValidation(criterion=are_quantum_statements_explicitly_defined),
            GateResolverStep(built_in_gates=built_in_gates),
            ConstantsResolvingStep(),
            ClassicalAssignmentNormalizer(),
            ExpressionsOptimizationStep(),
        )
        super().__init__(steps, compilation_config)
