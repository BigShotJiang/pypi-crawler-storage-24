from qm_qasm.configurations.compilation_config import CompilationConfig
from qm_qasm.passes.allowed_types import INITIALLY_ALLOWED_TYPES
from qm_qasm.passes.compilation_pass import CompilationPass
from qm_qasm.passes.feature_validation import AllowedNodeTypesValidator
from qm_qasm.passes.parsing.oq3_code_normalizer import OQ3CodeNormalizer
from qm_qasm.passes.parsing.physical_qubit_resolver import PhysicalQubitResolver
from qm_qasm.passes.parsing.validators import VersionValidation, NonEmptySourceValidation, ReferencingValidation
from qm_qasm.passes.parsing.ast_builder import AstBuilder
from qm_qasm.passes.parsing.includes_resolver import IncludesResolver


class ParsingPass(CompilationPass):
    def __init__(self, compilation_config: CompilationConfig):
        steps = (
            NonEmptySourceValidation(),
            AstBuilder(),
            VersionValidation(supported_versions=["2", "2.0", "3", "3.0"]),
            IncludesResolver(compilation_config.max_inclusion_depth),
            AllowedNodeTypesValidator(INITIALLY_ALLOWED_TYPES),
            PhysicalQubitResolver(),
            ReferencingValidation(),
            OQ3CodeNormalizer(),
        )
        super().__init__(steps, compilation_config)
