from typing import Tuple, Optional

from openqasm3 import ast

from qm_qasm.configurations.compilation_config import CompilationConfig
from qm_qasm.configurations.hardware_config import HardwareConfig
from qm_qasm.passes.allowed_types import INITIALLY_ALLOWED_TYPES
from qm_qasm.passes.code_generation.qubits_allocator import QubitAllocator
from qm_qasm.passes.compilation_pass import CompilationPass, Step
from qm_qasm.passes.code_generation.declaration_normalizer import DeclarationNormalizer
from qm_qasm.passes.feature_validation import AllowedNodeTypesValidator, AllowedFeatureValidation
from qm_qasm.passes.code_generation.inputs_declaration_values_replacement import QuaDeclaration, DeclarationResolvingStep
from qm_qasm.passes.code_generation.variable_saver import VariablesSaver
from qm_qasm.passes.code_generation.validators import (
    QUA1_INT_SIZE,
    create_declaration_size_validator,
    is_declaration_init_value_none,
)
from qm_qasm.passes.code_generation.code_generation_transformation import CodeGeneration, Inputs


class Qua1GenerationPass(CompilationPass):
    def __init__(
        self, hardware_config: HardwareConfig, compilation_config: CompilationConfig, inputs: Optional[Inputs] = None
    ):

        allowed_input_types = INITIALLY_ALLOWED_TYPES - {ast.QuantumGateDefinition} | {ast.ClassicalAssignment}
        allowed_embedding_types = allowed_input_types - {ast.ClassicalDeclaration, ast.IODeclaration} | {QuaDeclaration}
        steps: Tuple[Step, ...] = (
            AllowedNodeTypesValidator(allowed_input_types),
            # AllowedFeatureValidation(criterion=create_declaration_size_validator(QUA1_INT_SIZE)),
            DeclarationNormalizer(),
            AllowedFeatureValidation(criterion=is_declaration_init_value_none),
            DeclarationResolvingStep(),
            AllowedNodeTypesValidator(allowed_embedding_types),
            QubitAllocator(hardware_config),
            CodeGeneration(hardware_config, inputs),
            VariablesSaver(),
        )
        super().__init__(steps, compilation_config)


__all__ = ["Qua1GenerationPass", "Inputs"]
