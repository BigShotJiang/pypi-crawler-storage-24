from qm import qua, generate_qua_script
from qm.qua._expressions import QuaExpression

from qm_qasm import Compiler, HardwareConfig, OperationsMapping


THRESHOLD = 3.097e-6
COOLDOWN_DURATION_NS = 15000


def measure_0() -> QuaExpression:
    i = qua.declare(qua.fixed)
    qua.align("resonator", "qubit")
    demod_operation = qua.dual_demod.full("cos", "out1", "sin", "out2", i)
    qua.measure("long_readout", "resonator", None, demod_operation)
    qua.align("resonator", "qubit")
    return i < THRESHOLD


def reset_0() -> None:
    qua.align("resonator", "qubit")
    qua.wait(COOLDOWN_DURATION_NS, "resonator")
    qua.align("resonator", "qubit")


def x_0() -> None:
    qua.play("pi", "qubit")


def y_0() -> None:
    qua.play("piY", "qubit")


def main() -> None:
    operations_db: OperationsMapping = {
        "measure $0;": measure_0,
        "reset $0;": reset_0,
        "x $0;": x_0,
        "y $0;": y_0,
    }
    hw_config = HardwareConfig(operations_db, physical_qubits={0: tuple()})
    example_oq_code = """
    OPENQASM 3;
    bit c;
    reset $0;
    x $0;
    y $0;
    c = measure $0;
    """
    compiler = Compiler(hw_config)
    compilation_result = compiler.compile(code=example_oq_code)
    qua_program = compilation_result.result_program.dsl_program
    qua_script = generate_qua_script(qua_program)
    print(qua_script)


if __name__ == "__main__":
    main()
