import io
import logging
import pytest

from qm_qasm.configurations.compilation_config import CompilationConfig
from qm_qasm.programs import Program
from qm_qasm.passes.compilation_pass import CompilationPass, Step, Validation, Optimization, ValidationException


class ExceptionForTests(Exception):
    pass


class SuccessValidation(Validation):
    def __call__(self, program: Program) -> Program:
        return program


class FailureValidation(Validation):
    def __call__(self, program: Program) -> Program:
        raise ValidationException


class ExceptionValidation(Validation):
    def __call__(self, program: Program) -> Program:
        raise ExceptionForTests


class ExceptionStep(Step):
    def __call__(self, program: Program) -> Program:
        raise ExceptionForTests


class ExceptionOptimization(Optimization):
    def __call__(self, program: Program) -> Program:
        raise ExceptionForTests


class IdentityValidation(Validation):
    def __call__(self, program: Program) -> Program:
        return program


class IdentityOptimization(Optimization):
    def __call__(self, program: Program) -> Program:
        return program


class IdentityStep(Step):
    def __call__(self, program: Program) -> Program:
        return program


class AddColorOptimization(Optimization):
    def __call__(self, program: Program) -> Program:
        program.color = "red"  # type: ignore
        return program


class AddColorStep(Step):
    def __call__(self, program: Program) -> Program:
        program.color = "red"  # type: ignore
        return program


def test_pass_custom_log_stream(fake_program: Program) -> None:
    stdout = io.StringIO()
    logging.getLogger().addHandler(logging.StreamHandler(stdout))
    compilation_pass = CompilationPass((), CompilationConfig())
    compilation_pass(fake_program)
    expected_log = f"Pass '{compilation_pass.name}': starting"
    assert expected_log in stdout.getvalue()


def test_validation_success(fake_program: Program) -> None:
    compilation_pass = CompilationPass((SuccessValidation(),), CompilationConfig())
    compilation_pass(fake_program)


def test_validation_fails(fake_program: Program) -> None:
    compilation_pass = CompilationPass((FailureValidation(),), CompilationConfig())
    with pytest.raises(ValidationException):
        compilation_pass(fake_program)


def test_invalid_transformation(fake_program: Program) -> None:
    exception_step = ExceptionStep()
    compilation_pass = CompilationPass((exception_step,), CompilationConfig())
    with pytest.raises(ExceptionForTests):
        compilation_pass(fake_program)


def test_invalid_validation(fake_program: Program) -> None:
    exception_step = ExceptionValidation()
    compilation_pass = CompilationPass((exception_step,), CompilationConfig())
    with pytest.raises(ExceptionForTests):
        compilation_pass(fake_program)


def test_invalid_optimization(fake_program: Program) -> None:
    exception_step = ExceptionOptimization("Exception step")
    compilation_pass = CompilationPass((exception_step,), CompilationConfig())
    compilation_pass(fake_program)


@pytest.mark.parametrize(
    "identity_step",
    [
        IdentityValidation(),
        IdentityOptimization(),
        IdentityStep(),
    ],
)
def test_identity_step(fake_program: Program, identity_step: Step) -> None:
    compilation_pass = CompilationPass((identity_step,), CompilationConfig())
    result_program: Program = compilation_pass(fake_program)
    assert result_program == fake_program


@pytest.mark.parametrize(
    "add_color_step",
    [
        AddColorOptimization(),
        AddColorStep(),
    ],
)
def test_active_step(fake_program: Program, add_color_step: Step) -> None:
    compilation_pass = CompilationPass((add_color_step,), CompilationConfig())
    result_program: Program = compilation_pass(fake_program)
    assert result_program.color == "red"  # type: ignore
