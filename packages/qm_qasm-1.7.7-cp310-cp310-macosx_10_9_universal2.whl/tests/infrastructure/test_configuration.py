import pytest

from qm_qasm.compiler import Compiler, CompilationResult
from qm_qasm.configurations.compilation_config import CompilationConfig
from qm_qasm.passes.compilation_pass import CompilationPass
from qm_qasm.programs import Program
from tests.infrastructure.test_compilation_pass import (
    ExceptionOptimization,
    ExceptionValidation,
    IdentityOptimization,
    ExceptionForTests,
)


def test_compilation_result_default_flags(no_operations_compiler: Compiler, fake_source: str) -> None:
    result: CompilationResult = no_operations_compiler.compile(fake_source)
    expected_flag = CompilationConfig().optimization_level
    actual_flag = result.flags["optimization_level"]
    assert actual_flag == expected_flag


def test_compilation_result_custom_compiler_flags(no_operations_compiler: Compiler, fake_source: str) -> None:
    result: CompilationResult = no_operations_compiler.compile(
        fake_source, compilation_config=CompilationConfig(optimization_level=2)
    )
    assert result.flags["optimization_level"] == 2
    assert CompilationConfig().optimization_level == 0


def test_skip_invalid_validation(fake_program: Program) -> None:
    exception_step = ExceptionValidation("Exception-step")
    compilation_pass = CompilationPass(
        (exception_step,), compilation_config=CompilationConfig(validations_to_skip=exception_step.name))
    compilation_pass(fake_program)


def test_skip_all_validations(fake_program: Program) -> None:
    exception_step1 = ExceptionValidation("Exception-step1")
    exception_step2 = ExceptionValidation("Exception-step2")
    compilation_pass = CompilationPass((exception_step1, exception_step2),
                                       compilation_config=CompilationConfig(validations_to_skip="all"))
    compilation_pass(fake_program)


def test_skip_invalid_optimization(fake_program: Program) -> None:
    exception_step = ExceptionOptimization("Exception-step")
    compilation_pass = CompilationPass((exception_step,),
                                       compilation_config=CompilationConfig(optimizations_to_skip=exception_step.name))
    compilation_pass(fake_program)


def test_skip_validation_doesnt_affect_optimization(fake_program: Program) -> None:
    exception_step1 = ExceptionOptimization("Exception-step1")
    exception_step2 = ExceptionValidation("Exception-step2")
    compilation_pass = CompilationPass((exception_step1, exception_step2),
                                       compilation_config=CompilationConfig(validations_to_skip=exception_step2.name))
    compilation_pass(fake_program)


def test_skip_validation_enforce_optimization(fake_program: Program) -> None:
    exception_step1 = ExceptionOptimization("Exception-step1")
    exception_step2 = ExceptionValidation("Exception-step2")
    compilation_pass = CompilationPass(
        (exception_step1, exception_step2),
        compilation_config=CompilationConfig(
            optimizations_to_enforce=exception_step1.name, validations_to_skip=exception_step2.name
        ),
    )
    with pytest.raises(ExceptionForTests):
        compilation_pass(fake_program)


def test_skip_all_validation_enforce_optimization(fake_program: Program) -> None:
    exception_step1 = ExceptionOptimization("Exception-step1")
    exception_step2 = ExceptionValidation("Exception-step2")
    compilation_pass = CompilationPass(
        (exception_step1, exception_step2),
        compilation_config=CompilationConfig(optimizations_to_enforce=exception_step1.name, validations_to_skip="all"),
    )
    with pytest.raises(ExceptionForTests):
        compilation_pass(fake_program)


def test_skip_validation_enforce_all_optimization(fake_program: Program) -> None:
    exception_step1 = ExceptionOptimization("Exception-step1")
    exception_step2 = ExceptionValidation("Exception-step2")
    exception_step3 = IdentityOptimization("Exception-step1")
    compilation_pass = CompilationPass(
        (exception_step1, exception_step2, exception_step3),
        compilation_config=CompilationConfig(optimizations_to_enforce="all", validations_to_skip=exception_step2.name),
    )
    with pytest.raises(ExceptionForTests):
        compilation_pass(fake_program)


def test_skip_all_validation_enforce_all_optimization(fake_program: Program) -> None:
    exception_step1 = ExceptionOptimization("Exception-step1")
    exception_step2 = ExceptionValidation("Exception-step2")
    exception_step3 = IdentityOptimization("Exception-step1")
    compilation_pass = CompilationPass(
        (exception_step1, exception_step2, exception_step3),
        compilation_config=CompilationConfig(optimizations_to_enforce="all", validations_to_skip="all"),
    )
    with pytest.raises(ExceptionForTests):
        compilation_pass(fake_program)


def test_skip_optimization_doesnt_affect_validation(fake_program: Program) -> None:
    exception_step1 = ExceptionOptimization("Exception-step1")
    exception_step2 = ExceptionValidation("Exception-step2")
    compilation_pass = CompilationPass(
        (exception_step1, exception_step2),
        compilation_config=CompilationConfig(optimizations_to_skip=exception_step1.name),
    )
    with pytest.raises(ExceptionForTests):
        compilation_pass(fake_program)


def test_enforce_optimization_doesnt_affect_validation(fake_program: Program) -> None:
    exception_step1 = IdentityOptimization("Exception-step1")
    exception_step2 = ExceptionValidation("Exception-step2")
    compilation_pass = CompilationPass(
        (exception_step1, exception_step2),
        compilation_config=CompilationConfig(optimizations_to_enforce=exception_step1.name),
    )
    with pytest.raises(ExceptionForTests):
        compilation_pass(fake_program)


def test_skip_specific_optimization_only_without_enforcement(fake_program: Program) -> None:
    exception_step1 = ExceptionOptimization("Exception-step1")
    exception_step2 = ExceptionOptimization("Exception-step2")
    compilation_pass = CompilationPass(
        (exception_step1, exception_step2),
        compilation_config=CompilationConfig(optimizations_to_skip=exception_step1.name))
    compilation_pass(fake_program)


def test_skip_specific_optimization_only_with_enforcement(fake_program: Program) -> None:
    exception_step1 = ExceptionOptimization("Exception-step1")
    exception_step2 = ExceptionOptimization("Exception-step2")
    compilation_pass = CompilationPass(
        (exception_step1, exception_step2),
        compilation_config=CompilationConfig(
            optimizations_to_skip=exception_step1.name, optimizations_to_enforce=exception_step2.name
        ),
    )
    with pytest.raises(ExceptionForTests):
        compilation_pass(fake_program)


@pytest.mark.parametrize(
    "compilation_config",
    [
        CompilationConfig(optimizations_to_skip="Exception-step", optimizations_to_enforce="Exception-step"),
        CompilationConfig(optimizations_to_skip="all", optimizations_to_enforce="Exception-step"),
        CompilationConfig(optimizations_to_skip="Exception-step", optimizations_to_enforce="all"),
    ],
)
def test_skip_and_enforce_optimization_should_pass(
    fake_program: Program, compilation_config: CompilationConfig
) -> None:
    exception_step = ExceptionOptimization("Exception-step")
    compilation_pass = CompilationPass((exception_step,), compilation_config=compilation_config)
    compilation_pass(fake_program)


def test_skip_all_optimizations(fake_program: Program) -> None:
    exception_step1 = ExceptionOptimization("Exception-step1")
    exception_step2 = ExceptionOptimization("Exception-step2")
    compilation_pass = CompilationPass(
        (exception_step1, exception_step2),
        compilation_config=CompilationConfig(optimizations_to_enforce="all", optimizations_to_skip="all"))
    compilation_pass(fake_program)


def test_enforce_invalid_optimization(fake_program: Program) -> None:
    exception_step = ExceptionOptimization("Exception-step")
    compilation_pass = CompilationPass(
        (exception_step,),
        compilation_config=CompilationConfig(optimizations_to_enforce=exception_step.name))
    with pytest.raises(ExceptionForTests):
        compilation_pass(fake_program)


def test_enforce_specific_invalid_optimization_only(fake_program: Program) -> None:
    exception_step1 = IdentityOptimization("Exception-step1")
    exception_step2 = ExceptionOptimization("Exception-step2")
    compilation_pass = CompilationPass(
        (exception_step1, exception_step2),
        compilation_config=CompilationConfig(optimizations_to_enforce=exception_step1.name))
    compilation_pass(fake_program)


def test_enforce_all_optimizations(fake_program: Program) -> None:
    exception_step1 = ExceptionOptimization("Exception-step1")
    exception_step2 = IdentityOptimization("Exception-step2")
    compilation_pass = CompilationPass((exception_step1, exception_step2),
                                       compilation_config=CompilationConfig(optimizations_to_enforce="all"))
    with pytest.raises(ExceptionForTests):
        compilation_pass(fake_program)
