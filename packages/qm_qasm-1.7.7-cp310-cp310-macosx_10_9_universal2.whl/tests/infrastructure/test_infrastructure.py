import logging
from datetime import datetime, timedelta

import pytest
from _pytest.logging import LogCaptureFixture

from tests.conftest import no_operations_hardware_config
from qm_qasm.compiler import Compiler, CompilationResult, CompilerMetadata, CompilationException
from qm_qasm.passes.parsing.validators import EmptySourceException


def test_compiler_custom_name() -> None:
    c = Compiler(no_operations_hardware_config(), name="MyCompiler")
    assert c.name == "MyCompiler"


def test_compilation_correct_compiler_info(no_operations_compiler: Compiler, fake_source: str) -> None:
    result = no_operations_compiler.compile(fake_source)
    assert result.compiler_metadata.name == no_operations_compiler.name
    assert result.compiler_metadata.uuid == no_operations_compiler.uuid


def test_compilations_uuid_unique(no_operations_compiler: Compiler, fake_source: str) -> None:
    result1 = no_operations_compiler.compile(fake_source)
    result2 = no_operations_compiler.compile(fake_source)
    assert result1.uuid != result2.uuid


def test_compilers_uuid_unique() -> None:
    compiler1 = Compiler(no_operations_hardware_config())
    compiler2 = Compiler(no_operations_hardware_config())
    assert compiler1.uuid != compiler2.uuid


def test_compilation_custom_name(no_operations_compiler: Compiler, fake_source: str) -> None:
    result = no_operations_compiler.compile(fake_source, compilation_name="MyCompilation")
    assert result.name == "MyCompilation"


def test_compiler_default_log_stream(caplog: LogCaptureFixture) -> None:
    c = Compiler(no_operations_hardware_config())
    expected_log = f"Compiler '{c.name}' initialized, with uuid {c.uuid}"
    assert expected_log in [rec.message for rec in caplog.records]


def test_compiler_log_stream_custom_level(no_operations_compiler: Compiler, caplog: LogCaptureFixture) -> None:
    no_operations_compiler.compile("OPENQASM 3.0;")
    expected_log = f"Compilation 'compilation' ended"
    assert expected_log in [rec.message for rec in caplog.records]


def test_compiler_log_stream_level_change_per_compilation(
    no_operations_compiler: Compiler, caplog: LogCaptureFixture
) -> None:
    expected_log_template = "Compilation '{}' ended"
    code = "OPENQASM 3.0;"
    no_operations_compiler.compile(code, compilation_name="c1")
    assert expected_log_template.format("c1") in [rec.message for rec in caplog.records]
    caplog.set_level(logging.WARNING)
    no_operations_compiler.compile(code, compilation_name="c2")
    assert expected_log_template.format("c2") not in [rec.message for rec in caplog.records]
    caplog.set_level(logging.DEBUG)
    no_operations_compiler.compile(code, compilation_name="c3")
    assert expected_log_template.format("c3") in [rec.message for rec in caplog.records]


def test_compiler_custom_log_stream(caplog: LogCaptureFixture) -> None:
    c = Compiler(no_operations_hardware_config())
    expected_log = f"Compiler '{c.name}' initialized, with uuid {c.uuid}"
    assert expected_log in [rec.message for rec in caplog.records]


def test_compilation_fails_with_empty_source(no_operations_compiler: Compiler) -> None:
    with pytest.raises(CompilationException) as e:
        no_operations_compiler.compile("")
    assert isinstance(e.value.__cause__, EmptySourceException)


def test_compilation_successful(no_operations_compiler: Compiler, fake_source: str) -> None:
    result = no_operations_compiler.compile(fake_source)
    assert isinstance(result, CompilationResult) and result is not None


def test_compilation_compiler_metadata(no_operations_compiler: Compiler, fake_source: str) -> None:
    metadata = no_operations_compiler.compile(fake_source).compiler_metadata
    expected_metadata = CompilerMetadata(
        name=no_operations_compiler.name,
        uuid=no_operations_compiler.uuid,
        creation_time=no_operations_compiler.creation_time,
        hardware_config=no_operations_compiler._hardware_config,
    )
    assert metadata == expected_metadata


def test_compilation_result_start_time(no_operations_compiler: Compiler, fake_source: str) -> None:
    before_start_time: datetime = datetime.now()
    result: CompilationResult = no_operations_compiler.compile(fake_source)
    assert before_start_time <= result.start_time <= before_start_time + timedelta(seconds=1)


def test_compilation_result_run_duration(no_operations_compiler: Compiler, fake_source: str) -> None:
    before_start_time: datetime = datetime.now()
    result: CompilationResult = no_operations_compiler.compile(fake_source)
    after_end_time: datetime = datetime.now()
    larger_duration = after_end_time - before_start_time
    assert timedelta(0) <= result.running_duration <= larger_duration


def test_compilation_result_source_code(no_operations_compiler: Compiler, fake_source: str) -> None:
    result: CompilationResult = no_operations_compiler.compile(fake_source)
    assert result.source_code == fake_source
