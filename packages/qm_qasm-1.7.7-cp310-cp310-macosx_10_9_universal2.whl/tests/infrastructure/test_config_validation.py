import pytest

from qm_qasm import HardwareConfig


def test_validating_hardware_config() -> None:
    with pytest.raises(Exception):
        HardwareConfig({})  # type: ignore
