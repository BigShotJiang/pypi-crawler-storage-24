import pytest
from qm import Program
import qm.qua as qua
from qm.qua.type_hints import Scalar
from qm.serialization.generate_qua_script import _program_string

from qm_qasm.compiler import Compiler
from qm_qasm.configurations.physical_qubit import QubitsMapping
from qm_qasm.configurations.hardware_config import HardwareConfig
from qm_qasm.configurations.operations_db import OperationsMapping
from qm_qasm.programs import TextualProgram


@pytest.fixture()
def fake_source() -> str:
    return "OPENQASM 3.0;"


@pytest.fixture()
def fake_program(fake_source: str) -> TextualProgram:
    return TextualProgram(fake_source)


def fake_hardware_config() -> HardwareConfig:
    return HardwareConfig(fake_operations_db(), fake_qubits())


@pytest.fixture()
def fake_compiler() -> Compiler:
    return Compiler(fake_hardware_config())


def no_operations_hardware_config() -> HardwareConfig:
    return HardwareConfig({}, physical_qubits={})


@pytest.fixture()
def no_operations_compiler() -> Compiler:
    hardware_config = no_operations_hardware_config()
    return Compiler(hardware_config)


def qe_name_by_indexes(*indexes: int) -> str:
    postfix = "_".join([str(i) for i in indexes])
    return f"qe_{postfix}"


def pulse_name_by_gate_name(gate: str) -> str:
    return f"pulse_{gate}"


def apply_x(q: int) -> None:
    qua.play(pulse_name_by_gate_name("x"), qe_name_by_indexes(q))


def apply_y_on_0() -> None:
    qua.play(pulse_name_by_gate_name("y"), qe_name_by_indexes(0))


def apply_rx_on_0(amplitude: Scalar[float]) -> None:
    qua.play(pulse_name_by_gate_name("rx") * qua.amp(amplitude), qe_name_by_indexes(0))


def apply_cx_01() -> None:
    indexes = (0, 1)
    qua.play(pulse_name_by_gate_name("cx"), qe_name_by_indexes(*indexes))


def apply_cx_12() -> None:
    indexes = (1, 2)
    qua.play(pulse_name_by_gate_name("cx"), qe_name_by_indexes(*indexes))


def phase(gamma: Scalar[float], *qubits: int) -> None:
    for q in qubits:
        qua.frame_rotation_2pi(gamma, qe_name_by_indexes(q))


def barrier(*indexes: int) -> None:
    qua.align(*[qe_name_by_indexes(index) for index in indexes])


def reset(*indexes: int) -> None:
    qua.wait(100, *[qe_name_by_indexes(index) for index in indexes])


def delay(duration: Scalar[int], *indexes: int) -> None:
    qua.wait(duration, *[qe_name_by_indexes(index) for index in indexes])


def parametric_gate_g(p: Scalar[float], *indexes: int) -> None:
    qua.play(pulse_name_by_gate_name("g") * qua.amp(p), qe_name_by_indexes(*indexes))


def measure(q: int) -> Scalar[bool]:
    """
    qe_3 with its readout resonator was added to test alignment
    """
    qe_name = qe_name_by_indexes(q) if q != 3 else "rr_3"
    demod_result = qua.declare(qua.fixed)
    demod = qua.dual_demod.full("integ_w1_I", "out1", "integ_w2_I", "out2", demod_result)
    qua.measure(pulse_name_by_gate_name("measure"), qe_name, None, demod)
    return demod_result > 0


def fake_qubits() -> QubitsMapping:
    return {0: ("qe_0",), 1: ("qe_1",), 2: ("qe_2",), 3: ("qe_3", "rr_3"), 5: ("qe_5",)}


def fake_operations_db() -> OperationsMapping:
    return {
        "x q;": apply_x,
        "delay": delay,
        "measure q;": measure,
        "gphase": phase,
        "y $0;": apply_y_on_0,
        "rx(t) $0;": apply_rx_on_0,
        "reset": reset,
        "barrier": barrier,
        "cx $0, $1;": apply_cx_01,
        "cx $1, $2;": apply_cx_12,
    }


def assert_equal_programs(p0: Program, p1: Program) -> None:
    assert _program_string(p0._program) == _program_string(p1._program)


def convert_to_qua1_fixed(x: float) -> float:
    return round(x * (2**28)) * 2 ** (-28)
