def foo_0_params() -> None:
    pass


def foo_0_params_args(*args: None) -> None:
    pass


def foo_1_param(p0: None) -> None:
    pass


def foo_1_param_args(p0: None, *args: None) -> None:
    pass


def foo_2_params(p0: None, p1: None) -> None:
    pass


def foo_2_params_args(p0: None, p1: None, *args: None) -> None:
    pass


def foo_3_params(p0: None, p1: None, p2: None) -> None:
    pass


def foo_3_params_args(p0: None, p1: None, p2: None, *args: None) -> None:
    pass


def foo_4_params(p0: None, p1: None, p2: None, p3: None) -> None:
    pass


def foo_4_params_args(p0: None, p1: None, p2: None, p3: None, *args: None) -> None:
    pass


def foo_5_params(p0: None, p1: None, p2: None, p3: None, p4: None) -> None:
    pass


def foo_5_params_args(p0: None, p1: None, p2: None, p3: None, p4: None, *args: None) -> None:
    pass
