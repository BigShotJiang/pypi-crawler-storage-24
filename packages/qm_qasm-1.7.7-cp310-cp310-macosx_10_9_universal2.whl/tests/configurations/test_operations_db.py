from typing import Tuple

import pytest

from qm_qasm.configurations.operation_identifier import OperationIdentifier, VaryingQubits
from qm_qasm.configurations.operations_db import OperationsDatabase, UnresolvableOperation
from tests.configurations.help_functions import foo_0_params, foo_1_param, foo_1_param_args, foo_2_params


def foo_0_params_2() -> None:
    pass


def another_foo_1_param() -> None:
    pass


def test_resolving_existing_operation() -> None:
    name = "gate_on_physical_qubit"
    db = OperationsDatabase({OperationIdentifier(name, qubits_pattern=(0,)): foo_0_params})
    f, args = db.resolve_operation(name, (0,))
    assert f == foo_0_params
    assert args == tuple()


def test_resolving_existing_operation_with_parameter() -> None:
    name = "gate_on_physical_qubit"
    db = OperationsDatabase({OperationIdentifier(name, number_of_params=1, qubits_pattern=(0,)): foo_1_param})
    f, args = db.resolve_operation(name, (0,), 3)
    assert f == foo_1_param
    assert args == (3,)


@pytest.mark.parametrize("qubit", [0, 1, 2, -1, 17])
def test_resolving_existing_operation_with_parametric_qubit(qubit: int) -> None:
    name = "gate_on_physical_qubit"
    db = OperationsDatabase({OperationIdentifier(name, number_of_parametric_qubits=1): foo_1_param})
    f, args = db.resolve_operation(name, (qubit,))
    assert f == foo_1_param
    assert args == (qubit,)


@pytest.mark.parametrize("args", [
    ("wrong_name", (0,)),
    ("name", (1,)),
    ("name", (0, 1)),
    ("name", tuple(), 1),
    ("name", (0,), 3),
])
def test_not_resolving_existing_operation(args: Tuple[str, Tuple[int, ...]]) -> None:
    db = OperationsDatabase({OperationIdentifier("name", qubits_pattern=(0,)): foo_0_params})
    with pytest.raises(UnresolvableOperation):
        db.resolve_operation(*args)


@pytest.mark.parametrize("args", [
    ("wrong_name", (0,), 1),
    ("name", (0,), 1, 2),
    ("name", (0,)),
    ("name", (0, 1), 1),
    ("name", tuple(), 1),
])
def test_not_resolving_existing_operation_parameter(args: Tuple[str, Tuple[int, ...], int]) -> None:
    db = OperationsDatabase(
        {OperationIdentifier("name", number_of_parametric_qubits=1, number_of_params=1): foo_2_params})
    with pytest.raises(UnresolvableOperation):
        db.resolve_operation(*args)


@pytest.mark.parametrize("param", [0, 1, -17])
@pytest.mark.parametrize("qubits", [(0,), (1,), (0, 1), (1, 0), (1, 1), (0,) * 5, tuple(), (0, 1, 2, 16, 2)])
def test_resolving_existing_operation_with_args(param: int, qubits: Tuple[int, ...]) -> None:
    db = OperationsDatabase({
        OperationIdentifier("name", number_of_params=1, qubits_pattern=VaryingQubits()): foo_1_param_args})
    f, args = db.resolve_operation("name", qubits, param)
    assert f == foo_1_param_args
    assert args == (param,) + qubits


@pytest.mark.parametrize("qubits", [(0,), (1,), (0, 1), (1, 0), (1, 1), (0,) * 5, tuple(), (0, 1, 2, 16, 2)])
def test_not_finding_function_when_there_is_no_param(qubits: Tuple[int, ...]) -> None:
    db = OperationsDatabase({
        OperationIdentifier("name", number_of_params=1, qubits_pattern=VaryingQubits()): foo_1_param_args})
    with pytest.raises(UnresolvableOperation):
        db.resolve_operation("name", qubits)


def test_resolving_function_when_there_are_multiple_entries_with_the_same_name() -> None:
    db = OperationsDatabase({
        OperationIdentifier("name", qubits_pattern=(0, 1)): foo_0_params,
        OperationIdentifier("name", qubits_pattern=(1, 2)): foo_0_params_2,
        OperationIdentifier("name", qubits_pattern=(1, 3), number_of_params=1): foo_1_param,
    })
    f, args = db.resolve_operation("name", (0, 1))
    assert f == foo_0_params
    assert args == tuple()


def test_not_resolving_function_when_there_are_multiple_entries_with_the_same_name() -> None:
    db = OperationsDatabase({
        OperationIdentifier("name", qubits_pattern=(0, 1)): foo_0_params,
        OperationIdentifier("name", qubits_pattern=(1, 2)): foo_0_params_2,
    })
    with pytest.raises(UnresolvableOperation):
        db.resolve_operation("name", (0, 2))
