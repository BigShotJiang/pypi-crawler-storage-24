import logging
from typing import Tuple, Callable

import pytest

from tests.configurations.help_functions import foo_0_params, foo_0_params_args, foo_1_param, foo_1_param_args, \
    foo_2_params, foo_2_params_args, foo_3_params, foo_3_params_args, foo_4_params, foo_4_params_args, foo_5_params, \
    foo_5_params_args
from qm_qasm.configurations.operation_identifier import OperationIdentifier, VaryingQubits
from qm_qasm.configurations.operations_db import validate_identifier_operation_match, OperationDefinitionException


def foo_args_in_the_middle(a: None, *args: None, b: None) -> None:
    pass


def foo_args_first(*args: None, b: None) -> None:
    pass


candidates: Tuple[Callable[..., None], ...] = (
    foo_0_params, foo_0_params_args, foo_1_param, foo_1_param_args, foo_2_params, foo_2_params_args,
    foo_3_params, foo_3_params_args, foo_4_params, foo_4_params_args, foo_5_params, foo_5_params_args
)


@pytest.mark.parametrize("number_of_params", [0, 1, 2])
@pytest.mark.parametrize("number_of_parametric_qubits", [None, 0, 1, 2])
@pytest.mark.parametrize("qubits_pattern", [tuple(), (0,), (1,), (0, 1), (0, 2), (0, 1, 2), VaryingQubits()])
def test_only_one_function_passes_validation(
        number_of_params: int, number_of_parametric_qubits: int, qubits_pattern: Tuple[int, ...]) -> None:
    if qubits_pattern and number_of_parametric_qubits is not None:
        return

    identifier = OperationIdentifier("operation", number_of_params, qubits_pattern=qubits_pattern,
                                     number_of_parametric_qubits=number_of_parametric_qubits)
    passed_functions = []
    for candidate in candidates:
        try:
            validate_identifier_operation_match(identifier, candidate)
        except OperationDefinitionException:
            continue
        passed_functions.append(candidate)
    logging.debug(f"Matching functions for ({identifier.number_of_params}, {identifier.qubits_pattern} - "
                  f"{[f.__name__ for f in passed_functions]}")
    assert len(passed_functions) == 1


@pytest.mark.parametrize("number_of_params", [0, 1, 2])
@pytest.mark.parametrize("number_of_parametric_qubits", [None, 0, 1, 2])
@pytest.mark.parametrize("qubits_pattern", [tuple(), (0,), (1,), (0, 1), (0, 2), (0, 1, 2), VaryingQubits()])
@pytest.mark.parametrize("candidate_function", [foo_args_in_the_middle, foo_args_first])
def test_args_not_last_never_passes(
        number_of_params: int, number_of_parametric_qubits: int, qubits_pattern: Tuple[int, ...],
        candidate_function: Callable[..., None]
) -> None:
    if qubits_pattern and number_of_parametric_qubits is not None:
        return

    identifier = OperationIdentifier("operation", number_of_params, qubits_pattern=qubits_pattern)
    with pytest.raises(OperationDefinitionException):
        validate_identifier_operation_match(identifier, candidate_function)


def test_function_with_keyword_arguments_with_defaults_passes_validation() -> None:
    def foo(a: None, b: None = None) -> None:
        pass

    identifier = OperationIdentifier("operation", 1, qubits_pattern=tuple())
    validate_identifier_operation_match(identifier, foo)


def test_function_with_positional_and_keyword_arguments_with_defaults_passes_validation() -> None:
    def foo(a: None, *args, b: None = None) -> None:
        pass

    identifier = OperationIdentifier("operation", 1, qubits_pattern=VaryingQubits())
    validate_identifier_operation_match(identifier, foo)
