from typing import Tuple

import pytest

from tests.configurations.help_functions import foo_1_param
from qm_qasm.configurations.physical_qubit import QubitsMapping
from qm_qasm.configurations.operation_identifier import OperationIdentifier
from qm_qasm.configurations.hardware_config import HardwareConfig, NotSupportedQubits

qubits: QubitsMapping = \
    {0: ("qe_0", "common_rr"), 1: ("qe_1", "common_rr", "another"), 3: tuple(), 4: ("common_rr",), 17: ("qe_17",)}


@pytest.mark.parametrize("indexes", [(0,), (1,), (0, 1), (0, 1, 3), (0, 1, 3, 4)])
def test_returning_channels_relevant_to_qubits(indexes: Tuple[int, ...]) -> None:
    hw_config = HardwareConfig({}, physical_qubits=qubits)
    channels = hw_config.get_elements_to_align(indexes)
    assert "qe_17" not in channels


@pytest.mark.parametrize("indexes", [(0,), (1,), (0, 1), (0, 1, 3), (0, 1, 3, 4)])
def test_returning_each_channel_once(indexes: Tuple[int, ...]) -> None:
    hw_config = HardwareConfig({}, physical_qubits=qubits)
    channels = hw_config.get_elements_to_align(indexes)
    assert len(channels) == len(set(channels))


@pytest.mark.parametrize("indexes", [(0, 3, 1), (1, 0, 3), (1, 3, 0), (3, 0, 1), (3, 1, 0)])
def test_channels_are_invariant_to_order_of_qubits(indexes: Tuple[int, int, int]) -> None:
    hw_config = HardwareConfig({}, physical_qubits=qubits)
    assert hw_config.get_elements_to_align((0, 1, 3)) == hw_config.get_elements_to_align(indexes)


def test_function_that_runs_on_non_existent_qubit() -> None:
    hw_config = HardwareConfig(
        {OperationIdentifier("name", number_of_parametric_qubits=1): foo_1_param}, physical_qubits=qubits)
    with pytest.raises(NotSupportedQubits):
        hw_config.resolve_operation("name", (54,))


# Todo: check that no align is added
def test_qubit_with_no_channels() -> None:
    hw_config = HardwareConfig({}, physical_qubits=qubits)
    assert hw_config.get_elements_to_align((3,)) == tuple()
