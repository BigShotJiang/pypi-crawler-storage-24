from typing import Dict, List, Union, Any

import pytest
from tests.conftest import no_operations_hardware_config
from qm_qasm.compiler import Compiler
from qm_qasm.passes.code_generation.validators import QUA1_INT_SIZE
from qm_qasm.programs import Qua1Program


IOTYPE = Dict[str, List[Union[bool, int]]]


CONFIG: Dict[str, Any] = {
    "elements": {},
    "pulses": {},
    "waveforms": {},
}


def _convert_to_2s_complement(n: int, number_of_bits: int = QUA1_INT_SIZE) -> int:
    n %= 1 << number_of_bits
    msb = n >> (number_of_bits - 1)
    n -= msb * (1 << number_of_bits)
    return n


def run_test_from_oq_to_output(oq_code: str, inputs: IOTYPE, expected_outputs: IOTYPE) -> None:
    from qua_emulator.emulator import emulate
    from qua_emulator.qua_models import QuaVersion

    hardware_config = no_operations_hardware_config()
    compiler = Compiler(hardware_config)
    result_program = compiler.compile(oq_code).result_program
    assert isinstance(result_program, Qua1Program)
    program = result_program.dsl_program
    program_specific_inputs = {str(result_program[k]): v for k, v in inputs.items()}
    final_state = emulate(program, CONFIG, qua_version=QuaVersion.V1_0, input=program_specific_inputs)
    assert final_state.output == expected_outputs


@pytest.mark.needs_emulator
def test_saving_from_oq() -> None:
    oq_code = "OPENQASM 3.0; output bit c;"
    run_test_from_oq_to_output(oq_code, inputs={}, expected_outputs={"c": [False]})


@pytest.mark.needs_emulator
@pytest.mark.parametrize("register_length", [1, 4, 17])
def test_saving_register_from_oq(register_length: int) -> None:
    oq_code = f"OPENQASM 3.0; output bit[{register_length}] c;"
    run_test_from_oq_to_output(oq_code, inputs={}, expected_outputs={"c": [False] * register_length})


@pytest.mark.needs_emulator
@pytest.mark.parametrize("expected_bool", [True, False])
def test_initializing_variable_and_saving(expected_bool: bool) -> None:
    source_code = f"OPENQASM 3.0; bit c = {str(expected_bool).lower()};"
    run_test_from_oq_to_output(source_code, inputs={}, expected_outputs={"c": [expected_bool]})


@pytest.mark.needs_emulator
def test_saving_input() -> None:
    oq_code = "OPENQASM 3.0; input bit a; output bit b; b = a;"
    run_test_from_oq_to_output(oq_code, inputs={"a": [True]}, expected_outputs={"b": [True]})


@pytest.mark.parametrize(
    "a_input, operation, expected_b_output",
    [
        (2, "b = a;", 2),
        (2, "b = a - 3;", -1),
        (3, "b *= a;", 0),
        (1, "b += a;", 1),
        (8, "b -= a * 2;", -16),
        (8, "b -= a * 2; b *= b;", 256),
        (1, "b += a; b <<= 3;", 2**3),
        (8, "b += a; b >>= 2;", 2),
        (3, "b += a; b = -b;", -3),
    ],
)
@pytest.mark.needs_emulator
def test_int_operations(a_input: int, operation: str, expected_b_output: int) -> None:
    oq_code = f"OPENQASM 3.0; input int a; output int b; {operation}"
    run_test_from_oq_to_output(oq_code, inputs={"a": [a_input]}, expected_outputs={"b": [expected_b_output]})


@pytest.mark.xfail(reason="Boolean operations is not supported")
@pytest.mark.parametrize(
    "a_input, operation, expected_b_output",
    [
        (3, "b += a; b ^= 7;", 7),
        (3, "b += a; b |= 7;", 3),
        (3, "b += a; b &= 0;", 0),
        (3, "b += a; b &= 1;", 1),
        (7, "b += a; b = !b;", -8),
    ],
)
@pytest.mark.needs_emulator
def test_int_boolean_operations(a_input: int, operation: str, expected_b_output: int) -> None:
    oq_code = f"OPENQASM 3.0; input int a; output int b; {operation}"
    run_test_from_oq_to_output(oq_code, inputs={"a": [a_input]}, expected_outputs={"b": [expected_b_output]})


@pytest.mark.parametrize(
    "a_input, operation, expected_b_output",
    [
        (7, "b += a; b /= 2;", 3),
        (-7, "b += a; b /= 2;", -4),
        (7, "b += a; b /= -2;", -4),
        (6, "b += a; b /= 2;", 3),
        (-7, "b += a; b /= -2;", 3),
    ],
)
@pytest.mark.needs_emulator
def test_division(a_input: int, operation: str, expected_b_output: int) -> None:
    oq_code = f"OPENQASM 3.0; input int a; output int b; {operation}"
    run_test_from_oq_to_output(oq_code, inputs={"a": [a_input]}, expected_outputs={"b": [expected_b_output]})


@pytest.mark.parametrize(
    "a_input, operation, expected_b_output",
    [
        (7, "b = a == 7;", True),
        (7, "b = a == a;", True),
        (7, "b = a > 3;", True),
        (7, "b = a >= 7;", True),
        (7, "b = a <= 7;", True),
        (7, "b = a < 8;", True),
        (7, "b = a != 8;", True),
        (7, "b = a != 7;", False),
        (7, "b = a == 6;", False),
        (7, "b = a < 6;", False),
        (7, "b = a <= 6;", False),
        (7, "b = a >= 9;", False),
        (7, "b = a > 9;", False),
        (7, "b = a != a;", False),
        (7, "b = !(a != a);", True),
    ],
)
@pytest.mark.needs_emulator
def test_comparison(a_input: int, operation: str, expected_b_output: bool) -> None:
    oq_code = f"OPENQASM 3.0; input int a; output bit b; {operation}"
    run_test_from_oq_to_output(oq_code, inputs={"a": [a_input]}, expected_outputs={"b": [expected_b_output]})


@pytest.mark.needs_emulator
@pytest.mark.parametrize("input_val", [True, False])
def test_saving_not_input(input_val: bool) -> None:
    oq_code = "OPENQASM 3.0; input bit a; output bit b; b = !a;"
    run_test_from_oq_to_output(oq_code, inputs={"a": [input_val]}, expected_outputs={"b": [not input_val]})


@pytest.mark.needs_emulator
def test_declaration_and_saving_int() -> None:
    oq_code = "OPENQASM 3.0; input int a; output int b; b = a;"
    run_test_from_oq_to_output(oq_code, inputs={"a": [2]}, expected_outputs={"b": [2]})


@pytest.mark.needs_emulator
def test_basic_int_operations() -> None:
    oq_code = f"OPENQASM 3.0; output int b; int a = 5; b = a + 1;"
    run_test_from_oq_to_output(oq_code, inputs={}, expected_outputs={"b": [6]})


@pytest.mark.needs_emulator
def test_int_declaration_with_var_ref() -> None:
    oq_code = f"OPENQASM 3.0; output int c; int a = 5; int b = a + 1; c = b;"
    run_test_from_oq_to_output(oq_code, inputs={}, expected_outputs={"c": [6]})


@pytest.mark.parametrize(
    "a_input, operation, expected_b_output",
    [
        (2**31, "b = a + a;", 2**32),
        (2**31, "b = a + 3;", 2**31 + 3),
        (2**31, "b *= a;", 0),
        (2**31, "b -= a * 2;", -(2**32)),
        (2**31, "b += a * 4;", 2**35),
    ],
)
@pytest.mark.needs_emulator
def test_overflow(a_input: int, operation: str, expected_b_output: int) -> None:
    oq_code = f"OPENQASM 3.0; input int a; output int b; {operation}"
    expected_b_output = _convert_to_2s_complement(expected_b_output)
    run_test_from_oq_to_output(oq_code, inputs={"a": [a_input]}, expected_outputs={"b": [expected_b_output]})


@pytest.mark.needs_emulator
@pytest.mark.parametrize("input_val, output_val", [(True, 7), (False, 8)])
def test_if_and_else(input_val: bool, output_val: int) -> None:
    oq_code = """
        OPENQASM 3.0;
        input bit a;
        output int b;
        if (a) {
            b = 7;
        } else {
            b = 8;
        }
    """
    run_test_from_oq_to_output(oq_code, inputs={"a": [input_val]}, expected_outputs={"b": [output_val]})


FIBONACCI = [0, 1]
for _ in range(40):
    FIBONACCI.append(FIBONACCI[-1] + FIBONACCI[-2])


@pytest.mark.needs_emulator
@pytest.mark.parametrize("max_idx", [1, 3, 10, 17, 35])
def test_while_using_fibonacci(max_idx: int) -> None:
    oq_code = """
        OPENQASM 3.0;
        output int b;
        b = 1;
        input int max_idx;
        int a;
        int tmp;
        int counter = 1;
        while(counter < max_idx) {
            tmp = a;
            a = b;
            b += tmp;
            counter += 1;
        }
    """
    run_test_from_oq_to_output(oq_code, inputs={"max_idx": [max_idx]}, expected_outputs={"b": [FIBONACCI[max_idx]]})


@pytest.mark.needs_emulator
@pytest.mark.parametrize("a, num_steps", [(1, 0), (2, 1), (3, 7), (4, 2), (12, 9), (27, 111), (32, 5)])
def test_while_and_if_with_collatz_sequence(a: int, num_steps: int) -> None:
    oq_code = """
        OPENQASM 3.0;
        output int counter;
        input int a;
        while(a > 1) {
            counter += 1;
            if(a - ((a >> 1) << 1) == 0) {
                a /= 2;
            } else {
                a = 3*a + 1;
            }
        }
    """
    run_test_from_oq_to_output(oq_code, inputs={"a": [a]}, expected_outputs={"counter": [num_steps]})


@pytest.mark.needs_emulator
@pytest.mark.parametrize("max_idx", [1, 3, 10, 17, 35])
def test_for_using_fibonacci(max_idx: int) -> None:
    oq_code = """
        OPENQASM 3.0;
        output int b;
        b = 1;
        input int max_idx;
        int a;
        int tmp;
        for int counter in [1: max_idx-1] {
            tmp = a;
            a = b;
            b += tmp;
        }
    """
    run_test_from_oq_to_output(oq_code, inputs={"max_idx": [max_idx]}, expected_outputs={"b": [FIBONACCI[max_idx]]})


@pytest.mark.needs_emulator
@pytest.mark.parametrize("n", [1, 4, 17, 35])
def test_for_using_triangular_numbers_adding_1(n: int) -> None:
    oq_code = """
        OPENQASM 3.0;
        output int s;
        input int n;
        for int i in [1: n] {
            for int j in [1: i] {
                s += 1;
            }
        }
    """
    run_test_from_oq_to_output(oq_code, inputs={"n": [n]}, expected_outputs={"s": [n * (n + 1) // 2]})


@pytest.mark.needs_emulator
@pytest.mark.parametrize("n", [1, 4, 17, 35, 100])
def test_for_using_sum_of_squares(n: int) -> None:
    oq_code = """
        OPENQASM 3.0;
        output int s;
        input int n;
        for int i in [1: n] {
            s += i * i;
        }
    """
    run_test_from_oq_to_output(oq_code, inputs={"n": [n]}, expected_outputs={"s": [n * (n + 1) * (2 * n + 1) // 6]})


@pytest.mark.needs_emulator
def test_assigning_to_an_array() -> None:
    oq_code = """
            OPENQASM 3.0;
            output bit[10] b;
            for int a in [0: 9] {
                if(a - ((a >> 1) << 1) == 0) {
                    b[a] = true;
                }
            }
        """
    run_test_from_oq_to_output(oq_code, inputs={}, expected_outputs={"b": [True, False] * 5})


@pytest.mark.needs_emulator
@pytest.mark.parametrize("n", list(range(20)))
@pytest.mark.parametrize("m", [2, 3, 5, 7, 10])
def test_modulo(n: int, m: int) -> None:
    oq_code = """
        OPENQASM 3.0;
        output int s;
        input int n;
        input int m;
        s = n - m * (n / m);
    """
    run_test_from_oq_to_output(oq_code, inputs={"n": [n], "m": [m]}, expected_outputs={"s": [n % m]})
