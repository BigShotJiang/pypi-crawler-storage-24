from typing import Type, Optional, List

import pytest
from qm import qua
from qm import _Program as QuaProgram
from qm.exceptions import QmQuaException

from qm_qasm import Compiler
from qm_qasm.compiler import CompilationException
from qm_qasm.passes.feature_validation import DisallowedNodeTypeException
from qm_qasm.passes.parsing.validators import RedeclarationException, UnresolvableIdentifierException
from qm_qasm.programs import Qua1Program
from qm_qasm.qua_var import QuaAssignmentException
from tests.conftest import assert_equal_programs


def assert_causes(
    exception: Optional[BaseException], causes: List[Type[BaseException]], check_root_cause: bool = True
) -> None:
    cause = exception
    for cause_class in causes:
        assert isinstance(cause, cause_class)
        cause = cause.__cause__

    if check_root_cause:
        assert cause is None


def run_test_from_open_qasm_to_qua(oq_code: str, expected_qua1_program: QuaProgram, fake_compiler: Compiler) -> None:
    result = fake_compiler.compile(oq_code)
    assert isinstance(result.result_program, Qua1Program)
    assert_equal_programs(result.result_program.dsl_program, expected_qua1_program)


def run_test_with_expected_error(
    oq_code: str, expected_causes: List[Type[BaseException]], fake_compiler: Compiler
) -> None:
    with pytest.raises(CompilationException) as e:
        fake_compiler.compile(oq_code)
    assert_causes(e.value, expected_causes)


def test_gate(fake_compiler: Compiler) -> None:
    oq_code = "OPENQASM 3.0; x $0;"
    with qua.program() as expected_qua1_program:
        qua.play("pulse_x", "qe_0")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program, fake_compiler)


def test_parametric_gate(fake_compiler: Compiler) -> None:
    oq_code = "OPENQASM 3.0; rx(0.3) $0;"
    with qua.program() as expected_qua1_program:
        qua.play("pulse_rx" * qua.amp(0.3), "qe_0")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program, fake_compiler)


def test_2q_gate(fake_compiler: Compiler) -> None:
    oq_code = "OPENQASM 3.0; cx $0, $1;"
    with qua.program() as expected_qua1_program:
        qua.align("qe_0", "qe_1")
        qua.play("pulse_cx", "qe_0_1")
        qua.align("qe_0", "qe_1")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program, fake_compiler)


def test_multiple_instructions(fake_compiler: Compiler) -> None:
    oq_code = """
    OPENQASM 3.0;
    x $0;
    delay[10us] $0;
    gphase(0.5) $1;
    """
    with qua.program() as expected_qua1_program:
        qua.play("pulse_x", "qe_0")
        qua.wait(2500, "qe_0")
        qua.frame_rotation_2pi(0.5, "qe_1")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program, fake_compiler)


@pytest.mark.parametrize("init_value", [False, True])
def test_basic_classical_declaration_with_init_value(init_value: bool, fake_compiler: Compiler) -> None:
    oq_code = f"OPENQASM 3.0; bit b = {str(init_value).lower()};"
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        qua.assign(b, init_value)
        stream = qua.declare_stream()
        qua.save(b, stream)
        with qua.stream_processing():
            stream.save_all("b")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program, fake_compiler)


@pytest.mark.parametrize(
    "oq_code",
    [
        "OPENQASM 3.0; bit b;",
    ],
)
def test_basic_classical_declaration_without_init_value(oq_code: str, fake_compiler: Compiler) -> None:
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        stream = qua.declare_stream()
        qua.save(b, stream)
        with qua.stream_processing():
            stream.save_all("b")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program, fake_compiler)


def test_measurement_with_assignment(fake_compiler: Compiler) -> None:
    oq_code = """
    OPENQASM 3.0;
    bit b = measure $0;
    """
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        demod_result = qua.declare(qua.fixed)
        demod = qua.dual_demod.full("integ_w1_I", "out1", "integ_w2_I", "out2", demod_result)
        qua.measure("pulse_measure", "qe_0", None, demod)
        qua.assign(b, demod_result > 0)
        stream = qua.declare_stream()
        qua.save(b, stream)
        with qua.stream_processing():
            stream.save_all("b")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program, fake_compiler)


def test_measurement_of_two_qubits(fake_compiler: Compiler) -> None:
    oq_code = """
    OPENQASM 3.0;
    bit b = measure $0;
    bit c = measure $1;
    """
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        demod_result = qua.declare(qua.fixed)
        demod = qua.dual_demod.full("integ_w1_I", "out1", "integ_w2_I", "out2", demod_result)
        qua.measure("pulse_measure", f"qe_0", None, demod)
        qua.assign(b, demod_result > 0)

        c = qua.declare(bool, value=False)
        demod_result = qua.declare(qua.fixed)
        demod = qua.dual_demod.full("integ_w1_I", "out1", "integ_w2_I", "out2", demod_result)
        qua.measure("pulse_measure", f"qe_1", None, demod)
        qua.assign(c, demod_result > 0)

        stream = qua.declare_stream()
        qua.save(b, stream)
        with qua.stream_processing():
            stream.save_all("b")

        stream = qua.declare_stream()
        qua.save(c, stream)
        with qua.stream_processing():
            stream.save_all("c")

    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program, fake_compiler)


@pytest.mark.parametrize(
    "bit_value, assigned_value",
    [
        ("false", False),
        ("true", True),
    ],
)
def test_bit_declaration(bit_value: str, assigned_value: bool, fake_compiler: Compiler) -> None:
    oq_code = f"OPENQASM 3.0; bit b = {bit_value};"
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        qua.assign(b, assigned_value)
        stream = qua.declare_stream()
        qua.save(b, stream)
        with qua.stream_processing():
            stream.save_all("b")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program, fake_compiler)


@pytest.mark.parametrize(
    "bit_value, assigned_value",
    [
        ("0", 0),
        ("1", 1),
    ],
)
def test_bit_declaration_with_casting(bit_value: str, assigned_value: bool, fake_compiler: Compiler) -> None:
    oq_code = f"OPENQASM 3.0; bit b = {bit_value};"
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        qua.assign(b, assigned_value)
        stream = qua.declare_stream()
        qua.save(b, stream)
        with qua.stream_processing():
            stream.save_all("b")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program, fake_compiler)


@pytest.mark.parametrize("reg_length", [2, 4, 5])
def test_creg(reg_length: int, fake_compiler: Compiler) -> None:
    oq_code = f"OPENQASM 3.0; creg c[{reg_length}];"
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=[False] * reg_length)
        stream = qua.declare_stream()
        idx = qua.declare(int)
        with qua.for_(idx, 0, idx < reg_length, idx + 1):
            qua.save(b[idx], stream)
        with qua.stream_processing():
            stream.save_all("c")

    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program, fake_compiler)


def test_redeclaration(fake_compiler: Compiler) -> None:
    oq_code = f"""
    OPENQASM 3.0;
    bit c;
    int c;
    """
    run_test_with_expected_error(oq_code, [CompilationException, RedeclarationException], fake_compiler)


def test_self_referencing(fake_compiler: Compiler) -> None:
    oq_code = f"""
        OPENQASM 3.0;
        int x = x;
        """
    run_test_with_expected_error(oq_code, [CompilationException, UnresolvableIdentifierException], fake_compiler)


@pytest.mark.parametrize("assigned_value", [-5])
def test_int_declaration_with_unary_expression(assigned_value: int, fake_compiler: Compiler) -> None:
    oq_code = f"OPENQASM 3.0; int b = {assigned_value};"
    with qua.program() as expected_qua1_program:
        b = qua.declare(int, value=0)
        qua.assign(b, assigned_value)

        stream = qua.declare_stream()
        qua.save(b, stream)
        with qua.stream_processing():
            stream.save_all("b")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program, fake_compiler)


@pytest.mark.parametrize(
    "oq_code",
    [
        "OPENQASM 3.0; bit b; b = 19;",
        "OPENQASM 3.0; int b; b = 0.5;",
        "OPENQASM 3.0; bit[8] b; b = 3;" "OPENQASM 3.0; bit[8] b; b = 0.5;",
    ],
)
@pytest.mark.xfail(reason="There is no protection against inappropriate types inside operations")
def test_assignment_fails_with_bad_input(oq_code: str, fake_compiler: Compiler) -> None:
    run_test_with_expected_error(oq_code, [CompilationException, Exception], fake_compiler)


def test_register_assignment_fails_with_bad_input(fake_compiler: Compiler) -> None:
    reg_length = 8
    oq_code = f"OPENQASM 3.0; bit[{reg_length}] b; b = true;"
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=[False] * reg_length)
        stream = qua.declare_stream()
        idx = qua.declare(int)
        with qua.for_(idx, 0, idx < reg_length, idx + 1):
            qua.assign(b[idx], True)
        idx2 = qua.declare(int)
        with qua.for_(idx2, 0, idx2 < reg_length, idx2 + 1):
            qua.save(b[idx2], stream)
        with qua.stream_processing():
            stream.save_all("b")

    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program, fake_compiler)


@pytest.mark.xfail(reason="Compiler has no validation on init value")
@pytest.mark.parametrize(
    "declaration",
    [
        "int x = 1.5;",
        "bit c = 6;",
        "bit c = 3.2;",
        "bit c = pi;",
        "bit c = π;",
        "bit[8] c = 6;",
        "bit[8] c = 3.2;",
        "bit[8] c = pi;",
        "bit[8] c = π;",
    ],
)
def test_improper_implicit_cast_on_init_fails(declaration: str, fake_compiler: Compiler) -> None:
    oq_code = f"""
        OPENQASM 3.0;
        {declaration}
        """
    run_test_with_expected_error(oq_code, [CompilationException, Exception], fake_compiler)


@pytest.mark.parametrize(
    "declaration, exceptions",
    [
        ("int x = {1, 2};", [CompilationException, QuaAssignmentException, QmQuaException]),
        ('bit c = "0";', [CompilationException, NotImplementedError]),
        ('bit[3] c = "00";', [CompilationException, NotImplementedError]),
    ],
)
def test_improper_implicit_cast_we_are_protected_against(
    declaration: str, exceptions: List[Type[BaseException]], fake_compiler: Compiler
) -> None:
    """Things that we are protected against, but not the way we want it to be"""
    oq_code = f"""
        OPENQASM 3.0;
        {declaration}
        """
    run_test_with_expected_error(oq_code, exceptions, fake_compiler)


def test_if_else(fake_compiler: Compiler) -> None:
    oq_code = """
    OPENQASM 3.0;
    bit b;
    if (b) {
        b = measure $0;
    } else {
        b = !b;
    }
    """
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        with qua.if_(b):
            demod_result = qua.declare(qua.fixed)
            demod = qua.dual_demod.full("integ_w1_I", "out1", "integ_w2_I", "out2", demod_result)
            qua.measure("pulse_measure", f"qe_0", None, demod)
            qua.assign(b, demod_result > 0)
        with qua.else_():
            qua.assign(b, ~b)

        stream = qua.declare_stream()
        qua.save(b, stream)
        with qua.stream_processing():
            stream.save_all("b")

    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program, fake_compiler)


def test_embedding_a_program(fake_compiler: Compiler) -> None:

    with qua.program() as program:
        with qua.if_(False):
            fake_compiler.compile("OPENQASM 3; input bit b;", inputs={"b": True})
            qua.wait(222)

    with qua.program() as expected_qua1_program:
        with qua.if_(False):
            b = qua.declare(bool, value=False)
            qua.assign(b, True)
            qua.wait(222)

    assert_equal_programs(program, expected_qua1_program)


def test_embedding_the_same_program_twice(fake_compiler: Compiler) -> None:

    with qua.program() as program:
        with qua.if_(True):
            fake_compiler.compile("OPENQASM 3; input bit b;", inputs={"b": True})
            qua.wait(222)
            fake_compiler.compile("OPENQASM 3; input bit b;", inputs={"b": True})

    with qua.program() as expected_qua1_program:
        with qua.if_(True):
            b = qua.declare(bool, value=False)
            qua.assign(b, True)
            qua.wait(222)
            b = qua.declare(bool, value=False)
            qua.assign(b, True)

    assert_equal_programs(program, expected_qua1_program)
