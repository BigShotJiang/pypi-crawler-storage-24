from typing import Type

import pytest

from openqasm3 import parser
from qm_qasm.passes.code_generation.inputs_declaration_values_replacement import DeclarationResolvingStep
from qm_qasm.passes.parsing.physical_qubit_resolver import PhysicalQubitResolver
from qm_qasm.programs import OpenQasmProgram
from qm_qasm.passes.code_generation.qubits_allocator import QubitAllocator
from qm_qasm.passes.code_generation.code_generation_transformation import CodeGeneration
from tests.conftest import fake_hardware_config


def run_and_compre_codes(oq_code: str, target_code: str) -> None:
    qubits_resolver = PhysicalQubitResolver()
    declarations_transformer = DeclarationResolvingStep()
    allocator = QubitAllocator(fake_hardware_config())
    oq_program = OpenQasmProgram(parser.parse(oq_code))
    actual_program = allocator(declarations_transformer(qubits_resolver(oq_program)))
    assert isinstance(actual_program, OpenQasmProgram)
    expected = qubits_resolver(OpenQasmProgram(parser.parse(target_code)))
    assert isinstance(expected, OpenQasmProgram)
    assert expected.ast == actual_program.ast


def run_test_with_expected_error(oq_code: str, expected_error: Type[BaseException]) -> None:
    qubits_resolver = PhysicalQubitResolver()
    allocator = QubitAllocator(fake_hardware_config())
    code_generation = CodeGeneration(fake_hardware_config())
    oq_program = qubits_resolver(OpenQasmProgram(parser.parse(oq_code)))
    with pytest.raises(expected_error):
        code_generation(allocator(oq_program))


@pytest.mark.parametrize(
    "oq_code, target_code",
    [
        ("qubit q; x q;", "x $0;"),
        ("qubit q; rx(0.3) q;", "rx(0.3) $0;"),
    ],
)
def test_gate(oq_code: str, target_code: str) -> None:
    run_and_compre_codes(oq_code, target_code)


@pytest.mark.parametrize(
    "oq_code, target_code",
    [
        ("qubit q; cx $0, q;", "cx $0, $1;"),
        ("qubit q; cx q, q;", "cx $0, $0;"),
        ("qubit q; cx q, $1;", "cx $0, $1;"),
        ("qubit q; qubit w; cx q, w;", "cx $0, $1;"),
    ],
)
def test_2_qubit_gate(oq_code: str, target_code: str) -> None:
    run_and_compre_codes(oq_code, target_code)


@pytest.mark.parametrize(
    "oq_code, target_code",
    [
        ("qubit[1] q; x q[0];", "x $0;"),
        ("qubit[2] q; cx q[0], q[1];", "cx $0, $1;"),
        ("qubit w; qubit[2] q; cx q[0], q[1];", "cx $1, $2;"),
        ("qubit[2] w; qubit[2] q; cx q[0], q[1];", "cx $2, $3;"),
        ("qubit[5] q; cx q[3], q[4];", "cx $3, $5;"),
        ("qubit[4] q; cx $0, q[3];", "cx $0, $5;"),
    ],
)
def test_array(oq_code: str, target_code: str) -> None:
    run_and_compre_codes(oq_code, target_code)


def test_not_enough_qubits() -> None:
    pass


def test_using_non_supported_qubit() -> None:
    pass
