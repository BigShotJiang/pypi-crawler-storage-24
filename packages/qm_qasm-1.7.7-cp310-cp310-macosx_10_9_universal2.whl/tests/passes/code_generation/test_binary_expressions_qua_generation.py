import operator
from typing import Callable, Type, Any

import pytest
from qm import qua
from qm import _Program as QuaProgram

from openqasm3 import parser
from qm.qua import Cast

from qm_qasm.passes.code_generation.inputs_declaration_values_replacement import DeclarationResolvingStep
from qm_qasm.programs import OpenQasmProgram, Qua1Program
from qm_qasm.passes.code_generation.code_generation_transformation import CodeGeneration
from tests.conftest import assert_equal_programs, no_operations_hardware_config

BINARY_OPERATION_STR_TO_OPERATION = [
    (">", operator.gt),
    ("<", operator.lt),
    (">=", operator.ge),
    ("<=", operator.le),
    ("==", operator.eq),
    ("!=", lambda x, y: ~(x == y)),
    ("|", operator.or_),
    ("^", operator.xor),
    ("&", operator.and_),
    ("<<", operator.lshift),
    (">>", operator.rshift),
    ("+", operator.add),
    ("-", operator.sub),
    ("*", operator.mul),
    ("/", operator.truediv),
]


NOT_IMPLEMENTED_BINARY_OPERATORS = ["&&", "||", "%", "**"]


UNARY_OPERATION_STR_TO_OPERATION = {
    ("-", operator.neg),
    ("!", operator.invert),
}


NOT_IMPLEMENTED_UNARY_OPERATORS = ["~"]


def run_test_from_open_qasm_to_qua(oq_code: str, expected_qua1_program: QuaProgram) -> None:
    declarations_transformer = DeclarationResolvingStep()
    code_generation = CodeGeneration(no_operations_hardware_config())
    oq_program = OpenQasmProgram(parser.parse(oq_code))
    actual_qua1_program = code_generation(declarations_transformer(oq_program))
    assert isinstance(actual_qua1_program, Qua1Program)
    assert_equal_programs(actual_qua1_program.dsl_program, expected_qua1_program)


def run_test_with_expected_error(oq_code: str, expected_error: Type[BaseException]) -> None:
    declarations_transformer = DeclarationResolvingStep()
    code_generation = CodeGeneration(no_operations_hardware_config())
    oq_program = OpenQasmProgram(parser.parse(oq_code))
    with pytest.raises(expected_error):
        code_generation(declarations_transformer(oq_program))


@pytest.mark.parametrize("operator_str, operation", BINARY_OPERATION_STR_TO_OPERATION)
def test_assignment_with_an_expression(operator_str: str, operation: Callable[[Any, Any], Any]) -> None:
    oq_code = f"""
    bit x;
    bit y;
    y = x {operator_str} y;
    """
    with qua.program() as expected_qua1_program:
        a = qua.declare(bool, value=False)
        b = qua.declare(bool, value=False)
        qua.assign(b, operation(a, b))
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


@pytest.mark.parametrize("operator_str, operation", BINARY_OPERATION_STR_TO_OPERATION)
def test_expression_two_literals(operator_str: str, operation: Callable[[Any, Any], Any]) -> None:
    m, n = 4, 5
    oq_code = f"""
    bit b;
    b = {m} {operator_str} {n};
    """
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        qua.assign(b, operation(m, n))
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


@pytest.mark.parametrize("operator_str, operation", BINARY_OPERATION_STR_TO_OPERATION)
def test_expression_identifier_and_literal(operator_str: str, operation: Callable[[Any, Any], Any]) -> None:
    oq_code = f"""
    bit b;
    b = b {operator_str} 5;
    """
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        qua.assign(b, operation(b, 5))
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


@pytest.mark.parametrize("operator_str", NOT_IMPLEMENTED_BINARY_OPERATORS)
def test_unsupported_binary_expressions(operator_str: str) -> None:
    oq_code = f"""
    bit b;
    b = b {operator_str} 5;
    """
    run_test_with_expected_error(oq_code, NotImplementedError)


@pytest.mark.parametrize("operator_str", NOT_IMPLEMENTED_UNARY_OPERATORS)
def test_unsupported_unary_expressions(operator_str: str) -> None:
    oq_code = f"""
    bit b;
    b = {operator_str}b;
    """
    run_test_with_expected_error(oq_code, NotImplementedError)


def test_nested_expression() -> None:
    oq_code = f"""
    bit x;
    bit y;
    y = (x - x) * (y - x + 3);
    """
    with qua.program() as expected_qua1_program:
        a = qua.declare(bool, value=False)
        b = qua.declare(bool, value=False)
        qua.assign(b, (a - a) * (b - a + 3))
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


@pytest.mark.parametrize("operator_str, operation", UNARY_OPERATION_STR_TO_OPERATION)
def test_unary_expression(operator_str: str, operation: Callable[[Any], Any]) -> None:
    oq_code = f"""
    bit x;
    x = {operator_str}x;
    """
    with qua.program() as expected_qua1_program:
        a = qua.declare(bool, value=False)
        qua.assign(a, operation(a))
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


@pytest.mark.parametrize("operator_str, operation", UNARY_OPERATION_STR_TO_OPERATION)
def test_unary_expression_on_a_literal(operator_str: str, operation: Callable[[Any], Any]) -> None:
    n = 5
    oq_code = f"""
    bit x;
    x = {operator_str}{n};
    """
    with qua.program() as expected_qua1_program:
        a = qua.declare(bool, value=False)
        qua.assign(a, operation(n))
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_casting() -> None:
    oq_code = f"""
    float x;
    int y;
    y = int(x);
    """
    with qua.program() as expected_qua1_program:
        x = qua.declare(float, value=0)
        y = qua.declare(int, value=0)
        qua.assign(y, Cast.to_int(x))
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_not_neeeded_casting() -> None:
    oq_code = f"""
        int x;
        int y;
        y = int(x + 1);
        """
    with qua.program() as expected_qua1_program:
        x = qua.declare(int, value=0)
        y = qua.declare(int, value=0)
        qua.assign(y, x + 1)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)