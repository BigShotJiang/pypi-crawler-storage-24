import pytest
from qm import qua
from qm import _Program as QuaProgram

from openqasm3 import parser

from qm_qasm.passes.code_generation.inputs_declaration_values_replacement import DeclarationResolvingStep
from qm_qasm.programs import OpenQasmProgram, Qua1Program
from qm_qasm.passes.code_generation.code_generation_transformation import CodeGeneration
from qm_qasm.passes.code_generation.variable_saver import VariablesSaver
from tests.conftest import assert_equal_programs, no_operations_hardware_config


def run_test_from_open_qasm_to_qua(oq_code: str, expected_qua1_program: QuaProgram) -> None:
    declarations_transformer = DeclarationResolvingStep()
    code_generator = CodeGeneration(no_operations_hardware_config())
    saver = VariablesSaver()
    oq_program = OpenQasmProgram(parser.parse(oq_code))
    actual_qua1_program = saver(code_generator(declarations_transformer(oq_program)))
    assert isinstance(actual_qua1_program, Qua1Program)
    assert_equal_programs(actual_qua1_program.dsl_program, expected_qua1_program)


@pytest.mark.parametrize(
    "oq_code, expected_variables",
    [
        ("output bit c;", "c"),
        ("output bit[2] c;", "c"),
        ("output bit a; output bit b; bit c;", "ab"),
        ("bit a; bit b; bit c;", ""),
    ],
)
def test_variable_appears_in_variables_to_save(oq_code: str, expected_variables: str) -> None:
    declarations_transformer = DeclarationResolvingStep()
    code_generator = CodeGeneration(hardware_config=no_operations_hardware_config())
    oq_program = OpenQasmProgram(parser.parse(oq_code))
    qua1_program = code_generator(declarations_transformer(oq_program))
    assert isinstance(qua1_program, Qua1Program)
    assert set(expected_variables) == set(qua1_program.outputs)


@pytest.mark.parametrize(
    "oq_code",
    [
        "output bit c;",
    ],
)
def test_saving_variables(oq_code: str) -> None:
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        stream = qua.declare_stream()
        qua.save(b, stream)
        with qua.stream_processing():
            stream.save_all("c")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_assignment_input_to_output() -> None:
    oq_code = """
    input bit x;
    output bit y;
    y = x;
    """
    with qua.program() as expected_qua1_program:
        a = qua.declare_input_stream(bool, "x", value=False)
        qua.advance_input_stream(a)
        b = qua.declare(bool, value=False)
        stream = qua.declare_stream()
        qua.assign(b, a)
        qua.save(b, stream)
        with qua.stream_processing():
            stream.save_all("y")

    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


@pytest.mark.parametrize(
    "oq_code",
    [
        "input bit c;",
    ],
)
def test_input(oq_code: str) -> None:
    with qua.program() as expected_qua1_program:
        a = qua.declare_input_stream(bool, "c", value=False)
        qua.advance_input_stream(a)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_input_array() -> None:
    oq_code = "input bit[2] c;"
    with qua.program() as expected_qua1_program:
        a = qua.declare_input_stream(bool, "c", value=[False, False])
        qua.advance_input_stream(a)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_saving_arrays() -> None:
    oq_code = "input bit[2] c;"
    with qua.program() as expected_qua1_program:
        a = qua.declare_input_stream(bool, "c", value=[False, False])
        qua.advance_input_stream(a)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_saving_multiple_variables() -> None:
    oq_code = "output bit b; output bit c; output bit[2] d;"
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        stream = qua.declare_stream()
        qua.save(b, stream)
        with qua.stream_processing():
            stream.save_all("b")

        b = qua.declare(bool, value=False)
        stream = qua.declare_stream()
        qua.save(b, stream)
        with qua.stream_processing():
            stream.save_all("c")

        b = qua.declare(bool, value=[False, False])
        stream = qua.declare_stream()
        idx = qua.declare(int)
        with qua.for_(idx, 0, idx < 2, idx + 1):
            qua.save(b[idx], stream)
        with qua.stream_processing():
            stream.save_all("d")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)
