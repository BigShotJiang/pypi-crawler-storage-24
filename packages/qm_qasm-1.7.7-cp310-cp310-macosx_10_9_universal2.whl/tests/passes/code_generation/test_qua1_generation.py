from typing import Type

import pytest
from qm import qua
from qm import _Program as QuaProgram

from openqasm3 import parser
from qm.qua._expressions import QuaExpression

from qm_qasm.configurations.physical_qubit import QubitsMapping
from qm_qasm.configurations.hardware_config import HardwareConfig
from qm_qasm.configurations.operations_db import OperationsMapping
from qm_qasm.configurations.compilation_config import CompilationConfig
from qm_qasm.passes.code_generation.inputs_declaration_values_replacement import DeclarationResolvingStep
from qm_qasm.passes.parsing.physical_qubit_resolver import PhysicalQubitResolver
from qm_qasm.programs import OpenQasmProgram, Qua1Program, UndeclaredVariableReferenceException
from qm_qasm.passes.code_generation import Qua1GenerationPass
from qm_qasm.passes.code_generation.code_generation_transformation import CodeGeneration
from tests.conftest import assert_equal_programs, fake_hardware_config


def run_test_from_open_qasm_to_qua(oq_code: str, expected_qua1_program: QuaProgram) -> None:
    qubits_resolver = PhysicalQubitResolver()
    declarations_transformer = DeclarationResolvingStep()
    code_generation = CodeGeneration(fake_hardware_config())
    oq_program = OpenQasmProgram(parser.parse(oq_code))
    actual_qua1_program = code_generation(declarations_transformer(qubits_resolver(oq_program)))
    assert isinstance(actual_qua1_program, Qua1Program)
    assert_equal_programs(actual_qua1_program.dsl_program, expected_qua1_program)


def run_test_with_expected_error(oq_code: str, expected_error: Type[BaseException]) -> None:
    qubits_resolver = PhysicalQubitResolver()
    declarations_transformer = DeclarationResolvingStep()
    code_generation = CodeGeneration(fake_hardware_config())
    oq_program = qubits_resolver(OpenQasmProgram(parser.parse(oq_code)))
    with pytest.raises(expected_error):
        code_generation(declarations_transformer(oq_program))


def test_gate() -> None:
    oq_code = "x $0;"
    with qua.program() as expected_qua1_program:
        qua.play("pulse_x", "qe_0")

    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_parametric_gate() -> None:
    oq_code = "rx(0.3) $0;"
    with qua.program() as expected_qua1_program:
        qua.play("pulse_rx" * qua.amp(0.3), "qe_0")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_2q_gate() -> None:
    oq_code = "cx $0, $1;"
    with qua.program() as expected_qua1_program:
        qua.align("qe_0", "qe_1")
        qua.play("pulse_cx", "qe_0_1")
        qua.align("qe_0", "qe_1")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_multiple_gates() -> None:
    oq_code = """
    x $0;
    y $0;
    x $1;
    """
    with qua.program() as expected_qua1_program:
        qua.play("pulse_x", "qe_0")
        qua.play("pulse_y", "qe_0")
        qua.play("pulse_x", "qe_1")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_phase() -> None:
    oq_code = "gphase(0.5) $0;"
    with qua.program() as expected_qua1_program:
        qua.frame_rotation_2pi(0.5, "qe_0")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_multiple_phases() -> None:
    oq_code = """
    gphase(0.5) $0;
    gphase(0.4) $0;
    gphase(0.3) $1;
    """
    with qua.program() as expected_qua1_program:
        qua.frame_rotation_2pi(0.5, "qe_0")
        qua.frame_rotation_2pi(0.4, "qe_0")
        qua.frame_rotation_2pi(0.3, "qe_1")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_multiple_phases_in_one_command() -> None:
    oq_code = """
        gphase(0.5) $0, $1;
        """
    with qua.program() as expected_qua1_program:
        qua.align("qe_0", "qe_1")
        qua.frame_rotation_2pi(0.5, "qe_0")
        qua.frame_rotation_2pi(0.5, "qe_1")
        qua.align("qe_0", "qe_1")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_delay() -> None:
    oq_code = "delay[100ns] $0;"
    with qua.program() as expected_qua1_program:
        qua.wait(25, "qe_0")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_multiple_delays() -> None:
    oq_code = """
    delay[100ns] $0;
    delay[10us] $0;
    delay[40ms] $1;
    delay[40s] $2;
    delay[4dt] $2;
    """
    with qua.program() as expected_qua1_program:
        qua.wait(25, "qe_0")
        qua.wait(2500, "qe_0")
        qua.wait(10_000_000, "qe_1")
        qua.wait(10_000_000_000, "qe_2")
        qua.wait(1, "qe_2")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_multiple_instructions() -> None:
    oq_code = """
    x $0;
    delay[10us] $0;
    gphase(0.5) $1;
    """
    with qua.program() as expected_qua1_program:
        qua.play("pulse_x", "qe_0")
        qua.wait(2500, "qe_0")
        qua.frame_rotation_2pi(0.5, "qe_1")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_static_circuit() -> None:
    oq_code = """
    y $0;
    x $1;
    cx $0,$1;
    x $0;
    cx $0,$1;
    """
    with qua.program() as expected_qua1_program:
        qua.play("pulse_y", "qe_0")
        qua.play("pulse_x", "qe_1")

        qua.align("qe_0", "qe_1")
        qua.play("pulse_cx", "qe_0_1")
        qua.align("qe_0", "qe_1")

        qua.play("pulse_x", "qe_0")

        qua.align("qe_0", "qe_1")
        qua.play("pulse_cx", "qe_0_1")
        qua.align("qe_0", "qe_1")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_fully_scheduled_static_circuit() -> None:
    oq_code = """
    y $0;
    x $1;
    cx $0,$1;
    x $0;
    delay[100ns] $1;
    cx $0,$1;
    """
    with qua.program() as expected_qua1_program:
        qua.play("pulse_y", "qe_0")
        qua.play("pulse_x", "qe_1")

        qua.align("qe_0", "qe_1")
        qua.play("pulse_cx", "qe_0_1")
        qua.align("qe_0", "qe_1")

        qua.play("pulse_x", "qe_0")

        qua.wait(25, "qe_1")

        qua.align("qe_0", "qe_1")
        qua.play("pulse_cx", "qe_0_1")
        qua.align("qe_0", "qe_1")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_tweezers_case() -> None:

    def apply_x(q: int) -> None:
        qua.play(f"pulse_{q}", "qe_horizontal")
        qua.play(f"pulse_{q}", "qe_vertical")
        qua.play("pulse_x", "qe_gate")

    def delay(duration_in_cycles: QuaExpression, *indexes: int) -> None:
        qua.wait(duration_in_cycles, *[f"qe_{index}" for index in indexes])

    tweezers_operations_db: OperationsMapping = {
        "x q;": apply_x,
        "delay": delay,
    }
    physical_qubits: QubitsMapping = {
        0: ("qe_horizontal", "qe_vertical", "qe_gate"),
        1: ("qe_horizontal", "qe_vertical", "qe_gate"),
    }
    hardware_config = HardwareConfig(tweezers_operations_db, physical_qubits)
    qubits_resolver = PhysicalQubitResolver()
    compilation_pass = Qua1GenerationPass(hardware_config, compilation_config=CompilationConfig())
    oq_program = OpenQasmProgram(
        parser.parse(
            """
            x $0;
            delay[100ns] $1;
            x $1;
            """
        )
    )
    result_program = compilation_pass(qubits_resolver(oq_program))
    assert isinstance(result_program, Qua1Program)
    actual_qua1_program = result_program.dsl_program
    with qua.program() as expected_qua1_program:
        qua.align("qe_gate", "qe_horizontal", "qe_vertical")
        qua.play("pulse_0", "qe_horizontal")
        qua.play("pulse_0", "qe_vertical")
        qua.play("pulse_x", "qe_gate")
        qua.align("qe_gate", "qe_horizontal", "qe_vertical")

        qua.align("qe_gate", "qe_horizontal", "qe_vertical")
        qua.wait(25, "qe_1")
        qua.align("qe_gate", "qe_horizontal", "qe_vertical")

        qua.align("qe_gate", "qe_horizontal", "qe_vertical")
        qua.play("pulse_1", "qe_horizontal")
        qua.play("pulse_1", "qe_vertical")
        qua.play("pulse_x", "qe_gate")
        qua.align("qe_gate", "qe_horizontal", "qe_vertical")
    assert_equal_programs(actual_qua1_program, expected_qua1_program)


def test_basic_classical_declaration() -> None:
    oq_code = "bit b;"
    with qua.program() as expected_qua1_program:
        qua.declare(bool, value=False)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_measurement_with_assignment() -> None:
    oq_code = """
    bit b;
    b = measure $0;
    """
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        demod_result = qua.declare(qua.fixed)
        demod = qua.dual_demod.full("integ_w1_I", "out1", "integ_w2_I", "out2", demod_result)
        qua.measure("pulse_measure", "qe_0", None, demod)
        qua.assign(b, demod_result > 0)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_measurement_of_two_qubits() -> None:
    oq_code = """
    bit b;
    b = measure $0;
    bit c;
    c = measure $1;
    """
    with qua.program() as expected_qua1_program:
        for i in [0, 1]:
            b = qua.declare(bool, value=False)
            demod_result = qua.declare(qua.fixed)
            demod = qua.dual_demod.full("integ_w1_I", "out1", "integ_w2_I", "out2", demod_result)
            qua.measure("pulse_measure", f"qe_{i}", None, demod)
            qua.assign(b, demod_result > 0)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_consecutive_measurement_of_the_same_qubit() -> None:
    oq_code = """
    bit b;
    b = measure $0;
    bit c;
    c = measure $0;
    """
    with qua.program() as expected_qua1_program:
        for _ in range(2):
            b = qua.declare(bool, value=False)
            demod_result = qua.declare(qua.fixed)
            demod = qua.dual_demod.full("integ_w1_I", "out1", "integ_w2_I", "out2", demod_result)
            qua.measure("pulse_measure", f"qe_0", None, demod)
            qua.assign(b, demod_result > 0)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_measurement_without_assignment() -> None:
    oq_code = "measure $0;"
    with qua.program() as expected_qua1_program:
        demod_result = qua.declare(qua.fixed)
        demod = qua.dual_demod.full("integ_w1_I", "out1", "integ_w2_I", "out2", demod_result)
        qua.measure("pulse_measure", "qe_0", None, demod)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


@pytest.mark.parametrize("reg_length", [2, 4, 5])
def test_creg(reg_length: int) -> None:
    oq_code = f"creg c[{reg_length}];"
    with qua.program() as expected_qua1_program:
        qua.declare(bool, value=[False] * reg_length)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


@pytest.mark.parametrize("size", ["", "[1]", "[2]", "[10]", "[32]", "[43]"])
def test_int_declaration_no_value(size: str) -> None:
    oq_code = f"int{size} b;"
    with qua.program() as expected_qua1_program:
        qua.declare(int, value=0)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_unimplemented_operation() -> None:
    run_test_with_expected_error("y $1;", Exception)


@pytest.mark.parametrize(
    "code_line",
    [
        "bit c = q[1];",
        "int c = 8;",
    ],
)
def test_not_implemented_declarations(code_line: str) -> None:
    run_test_with_expected_error(code_line, Exception)


def test_bit_redeclaration() -> None:
    oq_code = "bit c; bit c;"
    with qua.program() as expected_qua1_program:
        qua.declare(bool, value=False)
        qua.declare(bool, value=False)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


@pytest.mark.parametrize(
    "code_line",
    [
        "b = measure q;",
        "measure q;",
        "measure q[1:3];",
    ],
)
def test_measurement_of_non_physical_qubit(code_line: str) -> None:
    run_test_with_expected_error(code_line, Exception)


@pytest.mark.parametrize(
    "code_line",
    [
        "b = measure $0;",
    ],
)
def test_measure_into_undeclared(code_line: str) -> None:
    run_test_with_expected_error(code_line, UndeclaredVariableReferenceException)


@pytest.mark.parametrize(
    "code_line",
    [
        "b = a;",
        "b = a > b;",
    ],
)
def test_assignment_into_undeclared(code_line: str) -> None:
    run_test_with_expected_error(code_line, UndeclaredVariableReferenceException)


@pytest.mark.parametrize(
    "code_line",
    [
        "bit[1] b; b[0] = measure $0;",
    ],
)
def test_measure_into_indexed_array(code_line: str) -> None:
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=[False])
        demod_result = qua.declare(qua.fixed)
        demod = qua.dual_demod.full("integ_w1_I", "out1", "integ_w2_I", "out2", demod_result)
        qua.measure("pulse_measure", f"qe_0", None, demod)
        qua.assign(b[0], demod_result > 0)
    run_test_from_open_qasm_to_qua(code_line, expected_qua1_program)


@pytest.mark.parametrize(
    "code_line",
    [
        "bit[1] a; rx(a[0]) $0;",
    ],
)
def test_gate_with_indexed_array(code_line: str) -> None:
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=[False])
        qua.play("pulse_rx" * qua.amp(b[0]), "qe_0")
    run_test_from_open_qasm_to_qua(code_line, expected_qua1_program)


def test_declare_with_measure() -> None:
    OpenQasmProgram(parser.parse(f"bit b = measure $0;"))
    assert True


def test_single_reset() -> None:
    oq_code = "reset $0;"
    with qua.program() as expected_qua1_program:
        qua.wait(100, "qe_0")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_consecutive_same_reset() -> None:
    oq_code = """
    reset $0;
    reset $0;
    reset $0;
    """
    with qua.program() as expected_qua1_program:
        qua.wait(100, "qe_0")
        qua.wait(100, "qe_0")
        qua.wait(100, "qe_0")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_consecutive_different_reset() -> None:
    oq_code = """
    reset $2;
    reset $0;
    reset $1;
    """
    with qua.program() as expected_qua1_program:
        qua.wait(100, "qe_2")
        qua.wait(100, "qe_0")
        qua.wait(100, "qe_1")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_barrier_single_qubit() -> None:
    oq_code = "barrier $0;"
    with qua.program() as expected_qua1_program:
        qua.align("qe_0")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_barrier_multiple_qubits() -> None:
    oq_code = """
        barrier $0;
        barrier $2;
        barrier $1;
    """
    with qua.program() as expected_qua1_program:
        qua.align("qe_0")
        qua.align("qe_2")
        qua.align("qe_1")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_barrier_same_qubit() -> None:
    oq_code = """
        barrier $2;
        barrier $1;
        barrier $2;
    """
    with qua.program() as expected_qua1_program:
        qua.align("qe_2")
        qua.align("qe_1")
        qua.align("qe_2")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_barrier_multiple_qubits_together() -> None:
    oq_code = """barrier $0, $1;"""
    with qua.program() as expected_qua1_program:
        qua.align("qe_0", "qe_1")
        qua.align("qe_0", "qe_1")
        qua.align("qe_0", "qe_1")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_basic_assignment() -> None:
    oq_code = """
    bit x;
    x = true;
    """
    with qua.program() as expected_qua1_program:
        x = qua.declare(bool, value=False)
        qua.assign(x, True)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_assignment_of_other_variable() -> None:
    oq_code = """
    bit x;
    bit y;
    y = x;
    """
    with qua.program() as expected_qua1_program:
        a = qua.declare(bool, value=False)
        b = qua.declare(bool, value=False)
        qua.assign(b, a)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_self_assignment() -> None:
    oq_code = """
    bit x;
    x = x;
    """
    with qua.program() as expected_qua1_program:
        a = qua.declare(bool, value=False)
        qua.assign(a, a)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_assignment_with_an_expression() -> None:
    oq_code = """
    bit x;
    bit y;
    y = x > y;
    """
    with qua.program() as expected_qua1_program:
        a = qua.declare(bool, value=False)
        b = qua.declare(bool, value=False)
        qua.assign(b, a > b)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_negation() -> None:
    oq_code = """
    bit x;
    x = !x;
    """
    with qua.program() as expected_qua1_program:
        a = qua.declare(bool, value=False)
        qua.assign(a, ~a)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_assignment_and_measurement() -> None:
    oq_code = """
    bit b;
    b = true;
    b = measure $0;
    """
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        qua.assign(b, True)
        demod_result = qua.declare(qua.fixed)
        demod = qua.dual_demod.full("integ_w1_I", "out1", "integ_w2_I", "out2", demod_result)
        qua.measure("pulse_measure", "qe_0", None, demod)
        qua.assign(b, demod_result > 0)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_gate_with_align() -> None:
    oq_code = """
    x $3;
    """
    with qua.program() as expected_qua1_program:
        qua.align("qe_3", "rr_3")
        qua.play("pulse_x", "qe_3")
        qua.align("qe_3", "rr_3")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_gate_and_measurement_with_align() -> None:
    oq_code = """
    x $3;
    measure $3;
    """
    with qua.program() as expected_qua1_program:
        qua.align("qe_3", "rr_3")
        qua.play("pulse_x", "qe_3")
        qua.align("qe_3", "rr_3")
        qua.align("qe_3", "rr_3")
        demod_result = qua.declare(qua.fixed)
        demod = qua.dual_demod.full("integ_w1_I", "out1", "integ_w2_I", "out2", demod_result)
        qua.measure("pulse_measure", "rr_3", None, demod)
        qua.align("qe_3", "rr_3")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_if_else() -> None:
    oq_code = """
    bit b;
    if (b) {
        x $0;
        y $0;
        measure $0;
    } else {
        b = !b;
    }
    """
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        with qua.if_(b):
            qua.play("pulse_x", "qe_0")
            qua.play("pulse_y", "qe_0")
            demod_result = qua.declare(qua.fixed)
            demod = qua.dual_demod.full("integ_w1_I", "out1", "integ_w2_I", "out2", demod_result)
            qua.measure("pulse_measure", f"qe_0", demod)
        with qua.else_():
            qua.assign(b, ~b)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_if() -> None:
    oq_code = """
    bit b;
    if (b) {
        b = !b;
    }
    """
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        with qua.if_(b):
            qua.assign(b, ~b)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_empty_else() -> None:
    oq_code = """
    bit b;
    if (b) {
        b = !b;
    } else {}
    """
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        with qua.if_(b):
            qua.assign(b, ~b)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_empty_if() -> None:
    oq_code = """
    bit b;
    if (b) {
    } else {
        b = !b;
    }
    """
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        with qua.if_(~b):
            qua.assign(b, ~b)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_empty_if_empty_else() -> None:
    oq_code = """
    bit b;
    if (b) {}
    else {}
    b = !b;
    """
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        qua.assign(b, ~b)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_nested_if() -> None:
    oq_code = """
        bit b;
        if (b) {
            if (b) {
                b = !b;
            } else {
                measure $0;
            }
        }
    """
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        with qua.if_(b):
            with qua.if_(b):
                qua.assign(b, ~b)
            with qua.else_():
                demod_result = qua.declare(qua.fixed)
                demod = qua.dual_demod.full("integ_w1_I", "out1", "integ_w2_I", "out2", demod_result)
                qua.measure("pulse_measure", f"qe_0", None, demod)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_nested_else() -> None:
    oq_code = """
        bit b;
        if (b) {
            b = !b;
        } else {
            if (b) {
                measure $0;
            }
        }
    """
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        with qua.if_(b):
            qua.assign(b, ~b)
        with qua.else_():
            with qua.if_(b):
                demod_result = qua.declare(qua.fixed)
                demod = qua.dual_demod.full("integ_w1_I", "out1", "integ_w2_I", "out2", demod_result)
                qua.measure("pulse_measure", "qe_0", None, demod)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_complex_conditional() -> None:
    oq_code = """
        bit b;
        if ((b > 6) & (b < 19)) {
            b = !b;
        }
    """
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        with qua.if_((b > 6) & (b < 19)):
            qua.assign(b, ~b)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_simple_while() -> None:
    oq_code = """
        bit b;
        while(b) {
            b = !b;
        }
    """
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        with qua.while_(b):
            qua.assign(b, ~b)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_while_with_complex_condition() -> None:
    oq_code = """
        int a;
        a = 5;
        int b;
        while((a > 1) & (b < 4)) {
            a = a - 1;
            a = 2 * a;
            b = a * 3;
        }
        """
    with qua.program() as expected_qua1_program:
        a = qua.declare(int, value=0)
        b = qua.declare(int, value=0)
        qua.assign(a, 5)
        with qua.while_((a > 1) & (b < 4)):
            qua.assign(a, a - 1)
            qua.assign(a, 2 * a)
            qua.assign(b, a * 3)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_empty_while() -> None:
    oq_code = """
        bit b;
        while(b) {}
    """
    with qua.program() as expected_qua1_program:
        qua.declare(bool, value=False)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_nested_while_while() -> None:
    oq_code = """
        bit b;
        while(b) {
            while(!b) {
                b = !b;
            }
        }
    """
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        with qua.while_(b):
            with qua.while_(~b):
                qua.assign(b, ~b)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_nested_while_if() -> None:
    oq_code = """
        bit b;
        while(b) {
            if(!b) {
                b = !b;
            }
        }
    """
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        with qua.while_(b):
            with qua.if_(~b):
                qua.assign(b, ~b)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_simple_for() -> None:
    oq_code = """
    int y;
    for int x in [0: 8] {
        y = y + 2*x;
    }
    """
    with qua.program() as expected_qua1_program:
        y = qua.declare(int, value=0)
        iterator = qua.declare(int, value=0)
        with qua.for_(iterator, 0, iterator <= 8, iterator + 1):
            qua.assign(y, y + 2 * iterator)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_for_in_var_ref() -> None:
    oq_code = """
        bit y;
        bit[8] reg;
        for bit z in reg {
            y = y | z;
        }
        """
    with qua.program() as expected_qua1_program:
        y = qua.declare(bool, value=False)
        reg = qua.declare(bool, value=[False] * 8)
        iterator = qua.declare(bool, value=False)
        with qua.for_each_(iterator, reg):
            qua.assign(y, y | iterator)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_for_in_a_set() -> None:
    oq_code = """
        int y;
        for int z in {1, 3, 12} {
            y = y + z;
        }
        """
    with qua.program() as expected_qua1_program:
        y = qua.declare(int, value=0)
        iterator = qua.declare(int, value=0)
        with qua.for_each_(iterator, [1, 3, 12]):
            qua.assign(y, y + iterator)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


@pytest.mark.parametrize("iterable", ["x", "{1, 3, 12}", "[0: 8]"])
def test_empty_for(iterable: str) -> None:
    oq_code = f"""
        int y;
        for int z in {iterable} {{}}
        """
    with qua.program() as expected_qua1_program:
        qua.declare(int, value=0)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_dsl_program() -> None:
    my_qua_prog_scope = qua.program()
    with my_qua_prog_scope:
        qua.wait(100, "qe_test")
    with qua.program() as my_qua_dsl_program:
        qua.wait(100, "qe_test")
    # assert type(my_qua_prog_scope) == QuaProgramScope
    qua1_program = Qua1Program(my_qua_prog_scope)
    assert type(qua1_program.dsl_program) == QuaProgram
    assert_equal_programs(my_qua_dsl_program, qua1_program.dsl_program)


def test_switch() -> None:
    oq_code = """
    int x;
    switch (x) {
        case 0 {
            x = x + 1;
        }
        case 1 {
            x = 3;
        }
        case 2 {
            x = -x;
        }
    }
    """
    with qua.program() as expected_qua1_program:
        x = qua.declare(int, value=0)
        with qua.switch_(x, unsafe=True):
            with qua.case_(0):
                qua.assign(x, x + 1)
            with qua.case_(1):
                qua.assign(x, 3)
            with qua.case_(2):
                qua.assign(x, -x)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_switch_with_default() -> None:
    oq_code = """
    int x;
    switch (x) {
        case 0 {
            x = x + 1;
        }
        default {
            x = 3;
        }
    }
    """
    with qua.program() as expected_qua1_program:
        x = qua.declare(int, value=0)
        with qua.switch_(x):
            with qua.case_(0):
                qua.assign(x, x + 1)
            with qua.default_():
                qua.assign(x, 3)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_switch_empty_case_and_default() -> None:
    oq_code = """
    int x;
    switch (x) {
        case 0 {}
        default {
            x = 3;
        }
    }
    """
    with qua.program() as expected_qua1_program:
        x = qua.declare(int, value=0)
        with qua.switch_(x):
            with qua.case_(0):
                pass
            with qua.default_():
                qua.assign(x, 3)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_switch_with_empty_default() -> None:
    oq_code = """
        int x;
        switch (x) {
            case 0 {}
            default {
            }
        }
        """
    with qua.program() as expected_qua1_program:
        x = qua.declare(int, value=0)
        with qua.switch_(x):
            with qua.case_(0):
                pass
            with qua.default_():
                pass
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_nested_switch() -> None:
    oq_code = """
    int x;
    int y;
    switch (x) {
        case 0 {
            switch (y) {
                case 1 {
                    y = 3;
                }
            }
        }
    }
    """
    with qua.program() as expected_qua1_program:
        x = qua.declare(int, value=0)
        y = qua.declare(int, value=0)
        with qua.switch_(x, unsafe=True):
            with qua.case_(0):
                with qua.switch_(y, unsafe=True):
                    with qua.case_(1):
                        qua.assign(y, 3)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)
