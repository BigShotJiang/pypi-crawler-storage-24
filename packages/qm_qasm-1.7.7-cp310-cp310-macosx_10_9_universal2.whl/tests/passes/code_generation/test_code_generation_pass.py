from typing import Type, List

import pytest
from qm import qua
from qm import _Program as QuaProgram

from openqasm3 import parser
from qm_qasm.configurations.compilation_config import CompilationConfig
from qm_qasm.passes.code_generation.default_value_concluder import InvalidArraySizeException
from qm_qasm.passes.code_resolving.constants_resolving_step import ConstantsResolvingStep
from qm_qasm.passes.parsing.physical_qubit_resolver import PhysicalQubitResolver
from qm_qasm.programs import OpenQasmProgram, Qua1Program
from qm_qasm.passes.code_generation import Qua1GenerationPass
from qm_qasm.qua_var import IndexingVariableException
from tests.conftest import assert_equal_programs, fake_hardware_config


def run_test_from_open_qasm_to_qua(oq_code: str, expected_qua1_program: QuaProgram) -> None:
    qubits_resolver = PhysicalQubitResolver()
    constants_resolver = ConstantsResolvingStep()
    code_generation = Qua1GenerationPass(hardware_config=fake_hardware_config(), compilation_config=CompilationConfig())
    oq_program = OpenQasmProgram(parser.parse(oq_code))
    actual_qua1_program = code_generation(qubits_resolver(constants_resolver(oq_program)))
    assert isinstance(actual_qua1_program, Qua1Program)
    assert_equal_programs(actual_qua1_program.dsl_program, expected_qua1_program)


def run_test_with_expected_error(oq_code: str, expected_error: Type[BaseException]) -> None:
    qubits_resolver = PhysicalQubitResolver()
    code_generation = Qua1GenerationPass(hardware_config=fake_hardware_config(), compilation_config=CompilationConfig())
    oq_program = qubits_resolver(OpenQasmProgram(parser.parse(oq_code)))
    with pytest.raises(expected_error):
        code_generation(oq_program)


@pytest.mark.parametrize("init_value", [False, True])
def test_basic_classical_declaration_with_init_value(init_value: bool) -> None:
    oq_code = f"bit b = {str(init_value).lower()};"
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        qua.assign(b, init_value)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_basic_classical_declaration_without_init_value() -> None:
    oq_code = "bit b;"
    with qua.program() as expected_qua1_program:
        qua.declare(bool, value=False)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


@pytest.mark.xfail(reason="There is a bug in QUA SDK that prevents us from using arrays")
@pytest.mark.parametrize(
    "bit_value, assigned_value",
    [
        ("0", [False]),
        ("1", [True]),
        ("10", [True, False]),
        ("01_10", [False, True, True, False]),
        ("0001_0001", [False, False, False, True, False, False, False, True]),
    ],
)
def test_bit_array_declaration(bit_value: str, assigned_value: List[bool]) -> None:
    oq_code = f'bit[{len(assigned_value)}] b = "{bit_value}";'
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=[False] * len(assigned_value))
        for idx, v in enumerate(assigned_value):
            qua.assign(b[idx], assigned_value[idx])
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_multiple_gates() -> None:
    oq_code = """
    x $0;
    y $0;
    x $1;
    """
    with qua.program() as expected_qua1_program:
        qua.play("pulse_x", "qe_0")
        qua.play("pulse_y", "qe_0")
        qua.play("pulse_x", "qe_1")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_box_with_gates() -> None:
    oq_code = """
    box {
        x $0;
        y $0;
        x $1;
    }
    """
    with qua.program() as expected_qua1_program:
        qua.play("pulse_x", "qe_0")
        qua.play("pulse_y", "qe_0")
        qua.play("pulse_x", "qe_1")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_box_consecutive_same_reset() -> None:
    oq_code = """
    box {
        reset $0;
        reset $0;
        reset $0;
    }
    """
    with qua.program() as expected_qua1_program:
        qua.wait(100, "qe_0")
        qua.wait(100, "qe_0")
        qua.wait(100, "qe_0")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_box_consecutive_different_reset() -> None:
    oq_code = """
    box {
        reset $2;
        reset $0;
        reset $1;
    }
    """
    with qua.program() as expected_qua1_program:
        qua.wait(100, "qe_2")
        qua.wait(100, "qe_0")
        qua.wait(100, "qe_1")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_box_with_duration() -> None:
    oq_code = """
    box [150ns]{
        x $0;
        y $0;
        x $1;
    }
    """
    with qua.program() as expected_qua1_program:
        qua.play("pulse_x", "qe_0")
        qua.play("pulse_y", "qe_0")
        qua.play("pulse_x", "qe_1")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_box_within_control_flow() -> None:
    oq_code = """
    for int _ in [0: 10] {
        box {
            x $0;
        }
    }
    """
    with qua.program() as expected_qua1_program:
        i = qua.declare(int, value=0)
        with qua.for_(i, 0, i <= 10, i + 1):
            qua.play("pulse_x", "qe_0")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_two_for_loops_with_same_iterator_name() -> None:
    """Ensure we can use '_' as the iterator name in multiple for-loops without redeclaration errors."""
    oq_code = """
    for int _ in [0: 2] {
        x $0;
    }
    for int _ in [0: 1] {
        x $1;
    }
    """
    with qua.program() as expected_qua1_program:
        i = qua.declare(int, value=0)
        j = qua.declare(int, value=0)
        with qua.for_(i, 0, i <= 2, i + 1):
            qua.play("pulse_x", "qe_0")
        with qua.for_(j, 0, j <= 1, j + 1):
            qua.play("pulse_x", "qe_1")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_nested_for_loops_with_same_iterator_name() -> None:
    oq_code = """
    for int _ in [0: 2] {
        for int _ in [0: 1] {
            x $0;
        }
    }
    """
    with qua.program() as expected_qua1_program:
        i = qua.declare(int, value=0)
        j = qua.declare(int, value=0)
        with qua.for_(i, 0, i <= 2, i + 1):
            with qua.for_(j, 0, j <= 1, j + 1):
                qua.play("pulse_x", "qe_0")

    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_underscore_as_proper_variable_name() -> None:
    """Ensure we can use '_' as a variable as long as it is not an iterator name."""
    oq_code = """
    int _;
    for int a in [0: 2] {
        _ = _ + 1;
    }
    """
    with qua.program() as expected_qua1_program:
        i = qua.declare(int, value=0)
        j = qua.declare(int, value=0)
        with qua.for_(j, 0, j <= 2, j + 1):
            qua.assign(i, i + 1)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_empty_box() -> None:
    oq_code = """
    bit b;
    box {
    }
    """
    with qua.program() as expected_qua1_program:
        qua.declare(bool, value=False)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_consecutive_same_reset() -> None:
    oq_code = """
    reset $0;
    reset $0;
    reset $0;
    """
    with qua.program() as expected_qua1_program:
        qua.wait(100, "qe_0")
        qua.wait(100, "qe_0")
        qua.wait(100, "qe_0")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_consecutive_different_reset() -> None:
    oq_code = """
    reset $2;
    reset $0;
    reset $1;
    """
    with qua.program() as expected_qua1_program:
        qua.wait(100, "qe_2")
        qua.wait(100, "qe_0")
        qua.wait(100, "qe_1")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


# @pytest.mark.parametrize("size", [33, 47, 1.5, "a"])  # non-positive values raise error in parsing phase
# @pytest.mark.parametrize("var_type", [int, float])
# def test_declaring_non_supported_size_int(size: int, var_type: type) -> None:
#     oq_code = f"{var_type.__name__}[{size}] x;"
#     run_test_with_expected_error(oq_code, Exception)


@pytest.mark.xfail(reason="Parser does not support such declarations")
@pytest.mark.parametrize(
    "assigned_value",
    [
        "0xff",
        "0xffff_ffff",
        "0XBEEF",
        "0o73",
        "0b1101",
        "0B0110_1001",
        "1_000_000",
    ],
)
def test_int_different_declarations(assigned_value: str) -> None:
    oq_code = f"int[32] x = {assigned_value};"
    number_as_int = int(assigned_value, 0)
    with qua.program() as expected_qua1_program:
        qua.declare(int, value=number_as_int)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_measurement_of_two_qubits() -> None:
    oq_code = """
    bit b = measure $0;
    bit c = measure $1;
    """
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        demod_result = qua.declare(qua.fixed)
        demod = qua.dual_demod.full("integ_w1_I", "out1", "integ_w2_I", "out2", demod_result)
        qua.measure("pulse_measure", f"qe_0", None, demod)
        qua.assign(b, demod_result > 0)

        c = qua.declare(bool, value=False)
        demod_result = qua.declare(qua.fixed)
        demod = qua.dual_demod.full("integ_w1_I", "out1", "integ_w2_I", "out2", demod_result)
        qua.measure("pulse_measure", f"qe_1", None, demod)
        qua.assign(c, demod_result > 0)

    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


@pytest.mark.parametrize("assigned_value", [0, 1, 2, 10, 10**3, 2**45])
@pytest.mark.parametrize("size", ["", "[1]", "[2]", "[10]", "[32]"])
def test_int_declaration(assigned_value: int, size: int) -> None:
    oq_code = f"int{size} b = {assigned_value};"
    with qua.program() as expected_qua1_program:
        b = qua.declare(int, value=0)
        qua.assign(b, assigned_value)

    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


@pytest.mark.parametrize("assigned_value", [0.0, 1.5, -0.3, 10.0, 1000.0, 2**45])
@pytest.mark.parametrize("size", ["", "[1]", "[2]", "[10]", "[32]"])
def test_fixed_declaration(assigned_value: float, size: int) -> None:
    oq_code = f"float{size} b = {assigned_value};"
    with qua.program() as expected_qua1_program:
        b = qua.declare(float, value=0.0)
        qua.assign(b, assigned_value)

    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_declaration_with_measurement() -> None:
    oq_code = "bit b = measure $0;"
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=False)
        demod_result = qua.declare(qua.fixed)
        demod = qua.dual_demod.full("integ_w1_I", "out1", "integ_w2_I", "out2", demod_result)
        qua.measure("pulse_measure", f"qe_0", None, demod)
        qua.assign(b, demod_result > 0)

    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


@pytest.mark.parametrize("var_type", [int, float])
def test_declaring_with_var_ref(var_type) -> None:
    oq_code = f"""
        output {var_type.__name__} x;
        {var_type.__name__} y = x + {var_type(5)};
    """
    with qua.program() as expected_qua1_program:
        x = qua.declare(var_type, value=0)
        y = qua.declare(var_type, value=0)
        qua.assign(y, x + var_type(5))

        stream = qua.declare_stream()
        qua.save(x, stream)
        with qua.stream_processing():
            stream.save_all("x")

    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


@pytest.mark.parametrize("var_type", [int, float])
def test_declaring_with_two_var_ref(var_type) -> None:
    oq_code = f"""
        output {var_type.__name__} x;
        {var_type.__name__} y = x;
        {var_type.__name__} z = x * y;
    """
    with qua.program() as expected_qua1_program:
        x = qua.declare(var_type, value=0)
        y = qua.declare(var_type, value=0)
        z = qua.declare(var_type, value=0)
        qua.assign(y, x)
        qua.assign(z, x * y)

        stream = qua.declare_stream()
        qua.save(x, stream)
        with qua.stream_processing():
            stream.save_all("x")

    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_basic_indexing() -> None:
    oq_code = """bit[8] b; bit c; c = b[1];"""
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=[False] * 8)
        c = qua.declare(bool, value=False)
        qua.assign(c, b[1])

    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_dynamic_indexing() -> None:
    oq_code = """bit[8] b; bit c; int idx = 3; c = b[idx+1];"""
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=[False] * 8)
        c = qua.declare(bool, value=False)
        idx = qua.declare(int, value=0)
        qua.assign(idx, 3)
        qua.assign(c, b[idx + 1])

    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_nested_indexing() -> None:
    oq_code = """bit[8] b; bit c; c = b[b[3] + 2];"""
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=[False] * 8)
        c = qua.declare(bool, value=False)
        qua.assign(c, b[b[3] + 2])

    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_self_assignment() -> None:
    oq_code = """bit[8] b; b[1] = b[1];"""
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=[False] * 8)
        qua.assign(b[1], b[1])

    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


@pytest.mark.parametrize("idx", [0, 1, 2, 3])
def test_negative_assignment(idx: int) -> None:
    oq_code = f"bit[8] b; b[0] = b[-{idx}];"
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=[False] * 8)
        qua.assign(b[0], b[-idx])

    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


@pytest.mark.parametrize("idx", [0, 1, 2, 3])
def test_indexed_assignment_to_scalar(idx: int) -> None:
    oq_code = f"bit b; b[{idx}] = 3;"
    run_test_with_expected_error(oq_code, IndexingVariableException)


@pytest.mark.parametrize("var_type", ["bit", "int"])
def test_indexed_fetching_to_scalar(var_type: str) -> None:
    oq_code = f"{var_type} b; {var_type} a; a = b[0];"
    run_test_with_expected_error(oq_code, IndexingVariableException)


@pytest.mark.parametrize("idx", [0, 1, 2, 3])
def test_measurement_to_array(idx: int) -> None:
    oq_code = f"""
        bit[8] b;
        b[{idx}] = measure $0;
    """
    with qua.program() as expected_qua1_program:
        b = qua.declare(bool, value=[False] * 8)
        demod_result = qua.declare(qua.fixed)
        demod = qua.dual_demod.full("integ_w1_I", "out1", "integ_w2_I", "out2", demod_result)
        qua.measure("pulse_measure", f"qe_0", None, demod)
        qua.assign(b[idx], demod_result > 0)

    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


@pytest.mark.parametrize("size", [1, 2, 3, 5, 1000])
@pytest.mark.parametrize("var_type", [int, float])
def test_array_declaration(size: int, var_type: type) -> None:
    oq_code = f"""
    array[{var_type.__name__}, {size}] x;
    """
    with qua.program() as expected_qua1_program:
        qua.declare(var_type, value=[0] * size)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


@pytest.mark.parametrize("size", [0, 1.5, "a"])  # negative values raise error in parsing phase
@pytest.mark.parametrize("var_type", [int, float])
def test_array_definition_illegal_size(size, var_type) -> None:
    oq_code = f"""
        array[{var_type.__name__}, {size}] y;
    """
    run_test_with_expected_error(oq_code, InvalidArraySizeException)


def test_array_indexing() -> None:
    oq_code = f"""
    int x = 1;
    array[float, 4] y = {{0.0, 0.1, 0.2, 0.3}};
    float b = y[x];
    """
    with qua.program() as expected_qua1_program:
        x = qua.declare(int, value=0)
        qua.assign(x, 1)
        y = qua.declare(float, value=[0.0, 0.0, 0.0, 0.0])
        for idx, z in enumerate([0.0, 0.1, 0.2, 0.3]):
            qua.assign(y[idx], z)
        b = qua.declare(float, value=0.0)
        qua.assign(b, y[x])
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)



def test_array_assignment() -> None:
    oq_code = f"""
    int x = 1;
    array[float, 4] y;
    float b = 0.7;
    y[x] = b;
    """
    with qua.program() as expected_qua1_program:
        x = qua.declare(int, value=0)
        qua.assign(x, 1)
        y = qua.declare(float, value=[0.0, 0.0, 0.0, 0.0])
        b = qua.declare(float, value=0.0)
        qua.assign(b, 0.7)
        qua.assign(y[x], b)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


def test_nested_array_indexing() -> None:
    oq_code = f"""
    array[int, 4] idx = {{3, 2, 1, 0}};
    array[float, 4] y = {{0.0, 0.1, 0.2, 0.3}};
    float b = y[idx[2]];
    """
    with qua.program() as expected_qua1_program:
        idx_arr = qua.declare(int, value=[0.0, 0.0, 0.0, 0.0])
        for idx, z in enumerate([3, 2, 1, 0]):
            qua.assign(idx_arr[idx], z)
        y = qua.declare(float, value=[0.0, 0.0, 0.0, 0.0])
        for idx, w in enumerate([0.0, 0.1, 0.2, 0.3]):
            qua.assign(y[idx], w)
        b = qua.declare(float, value=0.0)
        qua.assign(b, y[idx_arr[2]])
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)


@pytest.mark.parametrize("value", [1, 2, 3, 100])
def test_constant_declaration(value) -> None:
    oq_code = f"""
    OPENQASM 3;
    const int SIZE = {value};
    int x = SIZE + 3;
    array[float, SIZE] y;
    """
    with qua.program() as expected_qua1_program:
        x = qua.declare(int, value=0)
        qua.declare(float, value=[0.0] * value)
        qua.assign(x, value + 3)
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program)
