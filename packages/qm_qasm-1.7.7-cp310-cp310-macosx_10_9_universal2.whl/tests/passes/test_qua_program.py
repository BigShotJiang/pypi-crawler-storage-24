from typing import Dict, List, Union, Any
import pytest

from qm import qua

from qm_qasm.programs import Qua1Program
from qm_qasm.qua_var import QuaVar


IOTYPE = Dict[str, List[Union[bool, int]]]


CONFIG: Dict[str, Any] = {
    "elements": {},
    "pulses": {},
    "waveforms": {},
}


def run_test_on_qua_prog_wrapper(program: Qua1Program, inputs: IOTYPE, expected_outputs: IOTYPE) -> None:
    from qua_emulator.emulator import emulate
    from qua_emulator.qua_models import QuaVersion

    program_specific_inputs = {str(program[k]): v for k, v in inputs.items()}
    final_state = emulate(program.dsl_program, CONFIG, qua_version=QuaVersion.V1_0, input=program_specific_inputs)
    assert final_state.output == expected_outputs


@pytest.mark.needs_emulator
def test_variable_input_and_output() -> None:
    prog = Qua1Program(qua.program())
    prog.declare_variable(var=QuaVar("x", int), is_input=True, is_output=True, is_stream=True)
    prog.assign("x", prog["x"] * prog["x"])
    prog.save_all_outputs()
    run_test_on_qua_prog_wrapper(prog, inputs={"x": [-3]}, expected_outputs={"x": [9]})
