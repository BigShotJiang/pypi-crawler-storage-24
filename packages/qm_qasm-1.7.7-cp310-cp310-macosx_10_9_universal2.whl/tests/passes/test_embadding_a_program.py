from typing import Dict, Any, List

import pytest

from qm import qua
from qm.program import _Program

from qm_qasm import Compiler
from qm_qasm.compiler import CompilationException

CONFIG: Dict[str, Any] = {
    "elements": {},
    "pulses": {},
    "waveforms": {},
}


def run_emulated_test(program: _Program, expected_outputs: Dict[str, List[Any]]) -> None:
    from qua_emulator import emulate, QuaVersion

    final_state = emulate(program, CONFIG, qua_version=QuaVersion.V1_0)
    for output_name, expected_output in expected_outputs.items():
        assert final_state.output[output_name] == expected_output


@pytest.mark.needs_emulator
def test_running_openqasm_inside_qua(no_operations_compiler: Compiler) -> None:
    with qua.program() as program:
        idx = qua.declare(int)
        stream = qua.declare_stream()
        with qua.for_(idx, init=-3, cond=idx < 10, update=idx + 1):
            result = no_operations_compiler.compile(
                "OPENQASM 3.0; input int a; output int b; b = a*a;", inputs={"a": idx}
            )
            b = result.result_program["b"]
            qua.assign(b, b - 1)
            qua.save(b, stream)

        with qua.stream_processing():
            stream.save_all("b")

    run_emulated_test(program, {"b": [x**2 - 1 for x in range(-3, 10)]})


@pytest.mark.needs_emulator
@pytest.mark.xfail(reason="There is a bug in the emulator that prevents us from saving two variables")
def test_embedding_a_program_in_two_different_contexts(no_operations_compiler: Compiler) -> None:
    oq_code = "OPENQASM 3.0; input int a; output int b; b = a*a;"
    with qua.program() as program:
        idx = qua.declare(int)
        stream_b = qua.declare_stream()
        stream_c = qua.declare_stream()
        with qua.for_(idx, init=0, cond=idx < 10, update=idx + 1):
            result_b = no_operations_compiler.compile(oq_code, inputs={"a": idx})
            b = result_b.result_program["b"]
            qua.save(b, stream_b)
            with qua.if_(idx < 4):
                result_c = no_operations_compiler.compile(oq_code, inputs={"a": 2 * idx})
                c = result_c.result_program["b"]
                qua.save(c, stream_c)

        with qua.stream_processing():
            stream_b.save_all("b")
            stream_c.save_all("c")

    run_emulated_test(program, {"b": [x**2 for x in range(10)], "c": [(2 * x) ** 2 for x in range(4)]})


@pytest.mark.needs_emulator
def test_embedding_a_program_in_two_different_contexts_one_output(no_operations_compiler: Compiler) -> None:
    oq_code = "OPENQASM 3.0; input int a; output int b; b = a*a;"
    with qua.program() as program:
        idx = qua.declare(int)
        stream_b = qua.declare_stream()
        with qua.for_(idx, init=0, cond=idx < 4, update=idx + 1):
            result_b = no_operations_compiler.compile(oq_code, inputs={"a": idx})
            b = result_b.result_program["b"]
            qua.save(b, stream_b)
            with qua.if_(idx > 1):
                result_c = no_operations_compiler.compile(oq_code, inputs={"a": 2 * idx})
                b = result_c.result_program["b"]
                qua.save(b, stream_b)

        with qua.stream_processing():
            stream_b.save_all("b")

    run_emulated_test(program, {"b": [0, 1, 4, 16, 9, 36]})


@pytest.mark.needs_emulator
def test_embedding_a_program_with_no_inputs(no_operations_compiler: Compiler) -> None:
    with qua.program() as program:
        idx = qua.declare(int)
        stream = qua.declare_stream()
        with qua.for_(idx, init=0, cond=idx < 3, update=idx + 1):
            result = no_operations_compiler.compile("OPENQASM 3.0; output int b; b = 3;")
            b = result.result_program["b"]
            qua.save(b, stream)

        with qua.stream_processing():
            stream.save_all("b")

    run_emulated_test(program, {"b": [3, 3, 3]})


def test_embedding_a_program_with_irrelevant_inputs(no_operations_compiler: Compiler) -> None:
    with qua.program():
        with pytest.raises(CompilationException):
            no_operations_compiler.compile("OPENQASM 3.0; input int a; output int b; b = a*a;", inputs={"b": 5})


def test_embedding_a_program_with_no_relevant_inputs(no_operations_compiler: Compiler) -> None:
    with qua.program():
        with pytest.raises(CompilationException):
            no_operations_compiler.compile("OPENQASM 3.0; input int a; output int b; b = a*a;")


@pytest.mark.needs_emulator
def test_standalone_program(no_operations_compiler: Compiler) -> None:
    result = no_operations_compiler.compile("OPENQASM 3.0; input int a; output int b; b = a*a;", inputs={"a": 3})
    run_emulated_test(result.result_program.dsl_program, {"b": [9]})


@pytest.mark.needs_emulator
def test_embedding_the_same_program_twice(no_operations_compiler: Compiler) -> None:
    oq_code = "OPENQASM 3.0; input int a; output int b; b = a*a;"
    with qua.program() as program:
        idx = qua.declare(int)
        stream = qua.declare_stream()
        with qua.for_(idx, init=0, cond=idx < 5, update=idx + 1):
            result = no_operations_compiler.compile(oq_code, inputs={"a": idx})
            result = no_operations_compiler.compile(oq_code, inputs={"a": result.result_program["b"]})
            result = no_operations_compiler.compile(oq_code, inputs={"a": result.result_program["b"]})
            b = result.result_program["b"]
            qua.save(b, stream)

        with qua.stream_processing():
            stream.save_all("b")

    run_emulated_test(program, {"b": [x**8 for x in range(5)]})


@pytest.mark.needs_emulator
def test_embedding_two_different_programs_with_the_same_variable_names(no_operations_compiler: Compiler) -> None:
    oq_code_1 = "OPENQASM 3.0; input int a; output int b; b = a * a;"
    oq_code_2 = "OPENQASM 3.0; input int a; output int b; b = a + a;"
    with qua.program() as program:
        idx = qua.declare(int)
        stream = qua.declare_stream()
        with qua.for_(idx, init=0, cond=idx < 5, update=idx + 1):
            result = no_operations_compiler.compile(oq_code_1, inputs={"a": idx})
            result = no_operations_compiler.compile(oq_code_2, inputs={"a": result.result_program["b"]})
            b = result.result_program["b"]
            qua.save(b, stream)

        with qua.stream_processing():
            stream.save_all("b")

    run_emulated_test(program, {"b": [2 * (x**2) for x in range(5)]})


@pytest.mark.needs_emulator
def test_modifying_the_input_inside_the_compiled_code(no_operations_compiler: Compiler) -> None:
    """Notice that the index itself does not change, and the loop does not break."""

    with qua.program() as program:
        idx = qua.declare(int)
        stream = qua.declare_stream()
        with qua.for_(idx, init=0, cond=idx < 3, update=idx + 1):
            result = no_operations_compiler.compile(
                "OPENQASM 3.0; input int a; output int b; a += 5; b = a;", inputs={"a": idx}
            )
            b = result.result_program["b"]
            qua.save(b, stream)

        with qua.stream_processing():
            stream.save_all("b")

    run_emulated_test(program, {"b": [5, 6, 7]})


@pytest.mark.needs_emulator
@pytest.mark.parametrize("register_length", [1, 4, 17])
def test_using_register_inside_another_program(register_length: int, no_operations_compiler: Compiler) -> None:
    oq_code = f"OPENQASM 3.0; output bit[{register_length}] b;"
    with qua.program() as program:
        stream = qua.declare_stream()
        result = no_operations_compiler.compile(oq_code)
        b = result.result_program["b"]
        qua.assign(b[0], True)

        idx = qua.declare(int)
        with qua.for_(idx, 0, idx < register_length, idx + 1):
            qua.save(b[idx], stream)
        with qua.stream_processing():
            stream.save_all("b")

    run_emulated_test(program, {"b": [True] + [False] * (register_length - 1)})
