import pytest

from openqasm3 import parser
from qm_qasm.passes.code_resolving.assignment_normalizer import ClassicalAssignmentNormalizer
from qm_qasm.programs import OpenQasmProgram


def transform_and_compare(source_program: str, target_program: str) -> None:
    oq3_program = OpenQasmProgram(parser.parse(source_program))
    g = ClassicalAssignmentNormalizer()
    current = g(oq3_program)
    assert isinstance(current, OpenQasmProgram)
    expected = parser.parse(target_program)
    assert expected == current.ast


@pytest.mark.parametrize(
    "source_program, target_program",
    [
        ("a = a + b;", "a = a + b;"),
        ("a += b;", "a = a + b;"),
        ("a -= 3;", "a = a - 3;"),
        ("a *= 1;", "a = a * 1;"),
        ("a /= 0;", "a = a / 0;"),
        ("a >>= 2;", "a = a >> 2;"),
        ("a <<= 3;", "a = a << 3;"),
        ("a %= 4;", "a = a % 4;"),
        ("a &= b;", "a = a & b;"),
        ("a |= b;", "a = a | b;"),
        ("a ^= b;", "a = a ^ b;"),
        ("a **= b;", "a = a ** b;"),
        ("a **= a;", "a = a ** a;"),
        ("a **= b[2];", "a = a ** b[2];"),
    ],
)
def test_assignment_replacements(source_program: str, target_program: str) -> None:
    transform_and_compare(source_program, target_program)


@pytest.mark.xfail(raises=NotImplementedError)
@pytest.mark.parametrize(
    "source_program, target_program",
    [
        ("a[2] **= b;", "a[2] = a[2] ** b;"),
    ],
)
def test_not_supported_indexed_identifier(source_program: str, target_program: str) -> None:
    transform_and_compare(source_program, target_program)


@pytest.mark.parametrize(
    "source_program",
    [
        "a ~= b;",
    ],
)
def test_not_supported_operation(source_program: str) -> None:
    oq3_program = OpenQasmProgram(parser.parse(source_program))
    g = ClassicalAssignmentNormalizer()
    with pytest.raises(KeyError):
        g(oq3_program)
