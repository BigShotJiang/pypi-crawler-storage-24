import math
import pytest

from openqasm3 import ast, parser
from tests.passes.code_resolving.expression_utils import RecursiveExpression, create_expression
from qm_qasm.programs import OpenQasmProgram
from qm_qasm.passes.code_resolving.constants_resolving_step import ConstantsResolvingStep


def create_program(expression: ast.Expression) -> OpenQasmProgram:
    return OpenQasmProgram(ast=ast.Program([ast.ExpressionStatement(expression)]))


def run_constants_resolving_test(test_input: RecursiveExpression, expected_output: RecursiveExpression) -> None:
    # TODO - this is very similar to the function of the expression optimization.
    #  The only difference is the class in use and the method name, it can be unified.
    start_expression = create_expression(test_input)
    target_expression = create_expression(expected_output)
    start_program = create_program(start_expression)
    target_program = create_program(target_expression)
    resolver = ConstantsResolvingStep()
    result_program = resolver(start_program)
    assert isinstance(result_program, OpenQasmProgram)
    assert result_program.ast == target_program.ast


@pytest.mark.parametrize(
    "test_input, expected_output",
    [
        (("π", "*", 0.0), (math.pi, "*", 0.0)),
        ((2.0, "*", "π"), (2.0, "*", math.pi)),
        (("log", "ℇ"), ("log", math.e)),
        (("log", (2.0, "*", "pi")), ("log", (2.0, "*", math.pi))),
        (("𝜏", "*", "x"), (math.tau, "*", "x")),
        (("x", "/", "pi"), ("x", "/", math.pi)),
        ((1, "*", "euler"), (1, "*", math.e)),
    ],
)
def test_constants(test_input: RecursiveExpression, expected_output: RecursiveExpression) -> None:
    run_constants_resolving_test(test_input, expected_output)


@pytest.mark.parametrize(
    "constant, value",
    [
        ("pi", math.pi),
        ("π", math.pi),
        ("tau", math.tau),
        ("𝜏", math.tau),
        ("euler", math.e),
        ("ℇ", math.e),
    ],
)
def test_constants_inside_a_function(constant: str, value: float) -> None:
    source_code = f"gphase({constant}) $0;"
    target_code = f"gphase({value}) $0;"

    oq3_ast = OpenQasmProgram(parser.parse(source_code))
    transformer = ConstantsResolvingStep()
    current = transformer(oq3_ast)
    expected = parser.parse(target_code)
    assert isinstance(current, OpenQasmProgram)
    assert expected == current.ast


@pytest.mark.parametrize("value", [1, 2, 3, 4])
def test_constants_declaration(value: int) -> None:
    source_code = f"const int A = {value}; int x = A;"
    target_code = f"int x = {value};"

    oq3_ast = OpenQasmProgram(parser.parse(source_code))
    transformer = ConstantsResolvingStep()
    current = transformer(oq3_ast)
    expected = parser.parse(target_code)
    assert isinstance(current, OpenQasmProgram)
    assert expected == current.ast