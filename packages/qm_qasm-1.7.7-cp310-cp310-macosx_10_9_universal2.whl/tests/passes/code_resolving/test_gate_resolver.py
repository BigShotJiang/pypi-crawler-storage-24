from typing import Any

import pytest

from openqasm3 import parser
from qm_qasm.programs import OpenQasmProgram
from qm_qasm.passes.code_resolving.gate_resolver_step import (
    GateResolverStep,
    GateSignature,
    SignatureNotFoundException,
    ArgumentsMismatchException,
    MultipleDefinitionsException,
    MissingDefinitionException,
)


def transform_and_compare(source_program: str, target_program: str) -> None:
    oq3_program = OpenQasmProgram(parser.parse(source_program))
    g = GateResolverStep(built_in_gates={GateSignature("U")})
    current = g(oq3_program)
    assert isinstance(current, OpenQasmProgram)
    expected = parser.parse(target_program)
    assert expected == current.ast


def transform_and_catch_exception(source_program: str, expected_exception: Any) -> None:
    oq3_program = OpenQasmProgram(parser.parse(source_program))
    g = GateResolverStep(built_in_gates={GateSignature("U")})
    with pytest.raises(expected_exception):
        g(oq3_program)


@pytest.mark.parametrize(
    "source_program, target_program",
    [
        (
            """
            gate x q { U(π, 0, π) q; }
            x q1;
            """,
            """
            U(π, 0, π) q1;
            """,
        ),
        (
            """
            gate x q { U(π, 0, π) q; }
            x q1;
            x q2;
            """,
            """
            U(π, 0, π) q1;
            U(π, 0, π) q2;
            """,
        ),
        (
            """
            gate x q0, q1 {
                U(π, 0, π) q0;
                U(7, 0, 7) q1;
            }
            x q0, q1;
            """,
            """
            U(π, 0, π) q0;
            U(7, 0, 7) q1;
            """,
        ),
        (
            """
            gate x q0 { U(π, 0, π) q0; }
            gate y q1 { U(1, 0, 2) q1; }
            x q1;
            y q0;
            """,
            """
            U(π, 0, π) q1;
            U(1, 0, 2) q0;
            """,
        ),
    ],
)
def test_qubits_replacements(source_program: str, target_program: str) -> None:
    transform_and_compare(source_program, target_program)


@pytest.mark.parametrize(
    "source_program, target_program",
    [
        (
            """
            gate x q { U(π, 0, π) q; }
            x w[0];
            """,
            """
            U(π, 0, π) w[0];
            """,
        ),
        (
            """
            gate x q { U(π, 0, π) q; }
            x w[0];
            x w[1];
            """,
            """
            U(π, 0, π) w[0];
            U(π, 0, π) w[1];
            """,
        ),
        (
            """
            gate x q0, q1 {
                U(π, 0, π) q0;
                U(7, 0, 7) q1;
            }
            x w[0], w[1];
            """,
            """
            U(π, 0, π) w[0];
            U(7, 0, 7) w[1];
            """,
        ),
        (
            """
            gate x q0 { U(π, 0, π) q0; }
            gate y q1 { U(1, 0, 2) q1; }
            x w[0];
            y w[1];
            """,
            """
            U(π, 0, π) w[0];
            U(1, 0, 2) w[1];
            """,
        ),
    ],
)
def test_qubit_replacement_indexed_arrays(source_program: str, target_program: str) -> None:
    transform_and_compare(source_program, target_program)


@pytest.mark.parametrize(
    "source_program, target_program",
    [
        (
            """
            gate r(t) q { gphase(t) q; }
            r(π) q1;
            """,
            """
            gphase(π) q1;
            """,
        ),
        (
            """
            gate r q { barrier q; }
            r q1;
            """,
            """
            barrier q1;
            """,
        ),
        (
            """
            gate r(t) q { gphase(t) q; }
            r(π) w[1:5];
            """,
            """
            gphase(π) w[1:5];
            """,
        ),
    ],
)
def test_quantum_instructions(source_program: str, target_program: str) -> None:
    transform_and_compare(source_program, target_program)


@pytest.mark.parametrize(
    "source_program, target_program",
    [
        (
            """
            gate g(t) q { U(t, 0, t) q; }
            g(π) q1;
            """,
            """
            U(π, 0, π) q1;
            """,
        ),
        (
            """
            gate g(t) q { U(t, 0, t) q; }
            g(x) q1;
            """,
            """
            U(x, 0, x) q1;
            """,
        ),
        (
            """
            gate g(t) q { U(t, 0, t) q; }
            g(x[0]) q1;
            """,
            """
            U(x[0], 0, x[0]) q1;
            """,
        ),
        (
            """
            gate g(t) q { U(t, 0, t) q; }
            g(3+5) q1;
            """,
            """
            U(3+5, 0, 3+5) q1;
            """,
        ),
        (
            """
            gate g(t) q { U(t, 0, t) q; }
            g(π) q1;
            g(8) q2;
            """,
            """
            U(π, 0, π) q1;
            U(8, 0, 8) q2;
            """,
        ),
    ],
)
def test_parameters_and_qubits_replacement(source_program: str, target_program: str) -> None:
    transform_and_compare(source_program, target_program)


@pytest.mark.parametrize(
    "source_program, target_program",
    [
        (
            """
            gate x q { U(π, 0, π) q; }
            gate h q { U(π/2, 0, π) q; }
            gate hx q {
                h q;
                x q;
            }
            hx q1;
            """,
            """
            U(π/2, 0, π) q1;
            U(π, 0, π) q1;
            """,
        ),
        (
            """
            gate x q { U(π, 0, π) q; }
            gate h q { U(π/2, 0, π) q; }
            gate hx q {
                h q;
                x q;
            }
            hx w[0];
            """,
            """
            U(π/2, 0, π) w[0];
            U(π, 0, π) w[0];
            """,
        ),
    ],
)
def test_nested_definition(source_program: str, target_program: str) -> None:
    transform_and_compare(source_program, target_program)


@pytest.mark.parametrize(
    "source_program",
    [
        """x q;""",
        """
        x q;
        gate x q { U(π, 0, π) q; }
        """,
    ],
)
def test_call_undefined_gate(source_program: str) -> None:
    transform_and_catch_exception(source_program, expected_exception=SignatureNotFoundException)


@pytest.mark.parametrize(
    "source_program",
    [
        """
        gate x q { U(π, 0, π) q; }
        x(4) q1;
        """,
        """
        gate x(t) q { U(t, 0, t) q; }
        x q1;
        """,
        """
        gate x(t) q { U(t, 0, t) q; }
        x(3, 4) q1;
        """,
    ],
)
def test_arguments_mismatch(source_program: str) -> None:
    transform_and_catch_exception(source_program, expected_exception=ArgumentsMismatchException)


@pytest.mark.parametrize(
    "source_program",
    [
        """
        gate x q { U(π, 0, π) q; }
        x q1, q2;
        """,
        """
        gate x q1, q2 {
            U(π, 0, π) q1;
            U(1, 0, 1) q2;
        }
        x q1;
        """,
    ],
)
def test_qubits_mismatch(source_program: str) -> None:
    transform_and_catch_exception(source_program, expected_exception=ArgumentsMismatchException)


@pytest.mark.parametrize(
    "source_program",
    [
        """
        inv @ U(π, 0, π) q;
        """,
        """
        gate g q {inv @ U(π, 0, π) q; }
        g q1;
        """,
        """
        gate g q1, q2 {
        ctrl @ U(π, 0, π) q1, q2;
        }
        g q3, q4;
        """,
        """
        ctrl @ U(π, 0, π) q1, q2;
        """,
        """
        pow(2) @ U(π, 0, π) q;
        """,
    ],
)
def test_modifiers_are_not_supported(source_program: str) -> None:
    transform_and_catch_exception(source_program, expected_exception=NotImplementedError)


@pytest.mark.parametrize(
    "source_program",
    [
        """
        gate g q1 { U(π, 0, π) q1; }
        gate g q2 { U(1, 0, 1) q2; }
        """,
        """
        gate g q { U(π, 0, π) q; }
        gate g q1, q2 { U(π, 0, π) q1; U(π, 0, π) q2; }
        """,
        """
        gate g q1 { U(π, 0, π) q1; }
        gate g(t) q2 { U(t, 0, t) q2; }
        """,
        """gate U q {}""",
        """gate U(t) q {}""",
    ],
)
def test_double_definition(source_program: str) -> None:
    transform_and_catch_exception(source_program, expected_exception=MultipleDefinitionsException)


@pytest.mark.parametrize(
    "source_program",
    [
        """gate g q { g2 q; }""",
    ],
)
def test_missing_definition(source_program: str) -> None:
    transform_and_catch_exception(source_program, expected_exception=MissingDefinitionException)


@pytest.mark.parametrize(
    "source_program",
    [
        """
        gate g(t) q1 { U(t, 0, t) q1; }
        gate g(s) q2 { U(s, 0, s) q2; }
        """,
        """
        gate g q1 { U(π, 0, π) q1; }
        gate g q2 { U(π, 0, π) q2; }
        """,
        """
        gate g(t) q { U(t, 0, t) q; }
        gate g(s) q { U(s, 0, s) q; }
        """,
        """
        gate g q1 { U(π, 0, π) q1; }
        gate g q2 { U(π, 0, π) q2; }
        gate g2 q3 { U(π, 0, π) q3; }
        """,
    ],
)
def test_double_definition_with_the_same_meaning(source_program: str) -> None:
    transform_and_catch_exception(source_program, expected_exception=MultipleDefinitionsException)


@pytest.mark.parametrize(
    "source_program, target_program",
    [
        (
            """
            gate g(t) q { U(t, 0, t) q; }
            gate g(t) q { U(t, 0, t) q; }
            g(π) q1;
            """,
            """
            U(π, 0, π) q1;
            """,
        ),
        (
            """
            gate g(t) q { U(t, 0, t) q; }
            gate g(t) q { U(t, 0, t) q; }
            gate g(t) q { U(t, 0, t) q; }
            g(π) q1;
            """,
            """
            U(π, 0, π) q1;
            """,
        ),
        (
            """
            gate g(t) q { U(t, 0, t) q; }
            gate g(t) q { U(t, 0, t) q; }
            gate g2(t) q { U(t, 0, t) q; }
            g(π) q1;
            """,
            """
            U(π, 0, π) q1;
            """,
        ),
    ],
)
def test_allowed_exact_multiple_gate_definition(source_program: str, target_program: str) -> None:
    transform_and_compare(source_program, target_program)


@pytest.mark.parametrize(
    "source_program",
    [
        """
        gate g1 q { g2 q; }
        gate g2 q { g1 q; }
        """,
        """
        gate g1 q { g2 q; }
        gate g2 q { g3 q; }
        gate g3 q { g4 q; }
        gate g4 q { g1 q; }
        """,
    ],
)
def test_cyclic_definition(source_program: str) -> None:
    transform_and_catch_exception(source_program, expected_exception=MissingDefinitionException)


@pytest.mark.parametrize(
    "source_program",
    [
        """
        gate g q { g q; }
        """
    ],
)
def test_self_recurring_definition(source_program: str) -> None:
    transform_and_catch_exception(source_program, expected_exception=MissingDefinitionException)
