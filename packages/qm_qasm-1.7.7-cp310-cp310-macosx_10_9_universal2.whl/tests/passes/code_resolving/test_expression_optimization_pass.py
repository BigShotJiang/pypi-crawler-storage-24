import math
from typing import Any

import pytest

from openqasm3 import ast, parser
from tests.passes.code_resolving.expression_utils import create_expression, RecursiveExpression
from qm_qasm.programs import OpenQasmProgram
from qm_qasm.passes.code_resolving.expression_optimization_step import ExpressionsOptimizationStep, IllegalMathExpression


def create_program(expression: ast.Expression) -> OpenQasmProgram:
    return OpenQasmProgram(ast=ast.Program([ast.ExpressionStatement(expression)]))


def run_expression_simplification_test(test_input: RecursiveExpression, expected_output: RecursiveExpression) -> None:
    start_expression = create_expression(test_input)
    target_expression = create_expression(expected_output)
    start_program = create_program(start_expression)
    target_program = create_program(target_expression)
    optimizer = ExpressionsOptimizationStep()
    result_program = optimizer(start_program)
    assert isinstance(result_program, OpenQasmProgram)
    assert result_program.ast == target_program.ast


@pytest.mark.parametrize(
    "test_input, expected_output",
    [
        ((2, "+", 3), 5),
        ((5, "-", 2), 3),
        ((3, "-", 5), -2),
        ((2, "*", 3), 6),
        ((3, "*", 0), 0),
        ((0, "*", 3), 0),
        ((0.0, "*", 3.0), 0.0),
        ((0, "*", 0), 0),
        ((1, "*", 0), 0),
        ((0, "*", 1), 0),
        ((1, "*", 3), 3),
        ((1, "*", 1), 1),
        ((5, "*", 1), 5),
        ((1, "*", (1, "*", 3)), 3),
        (((1, "*", 3), "*", 1), 3),
        (((3, "*", 1), "*", 1), 3),
        (((1, "*", 3), "*", (1, "*", 3)), 9),
        (((1, "*", 3), "*", (0, "*", 3)), 0),
        ((5, "**", 2), 25),
        ((25, "**", 0.5), 5.0),
        ((True, "&&", False), False),
        ((17, ">>", 1), 17 // 2),
        ((17, "<<", 1), 17 * 2),
    ],
)
def test_simple_expressions(test_input: RecursiveExpression, expected_output: RecursiveExpression) -> None:
    run_expression_simplification_test(test_input, expected_output)


@pytest.mark.parametrize(
    "test_input, expected_output",
    [
        ((1, "+", 0.0), 1.0),
        ((3, "*", 1.0), 3.0),
        ((3, "/", 1.0), 3.0),
        ((3, "**", 1.0), 3.0),
        ((3, "**", 0.0), 1.0),
        ((2, "+", True), 3),
        ((0.0, "+", 1), 1.0),
        ((1.0, "*", 3), 3.0),
        ((3.0, "/", 1), 3.0),
        ((3.0, "**", 1), 3.0),
        ((3.0, "**", 0), 1.0),
        ((True, "+", 2), 3),
        ((math.tau, "/", 2), math.pi),
        ((math.tau, "/", math.pi), 2.0),
    ],
)
def test_binary_implicit_casting(test_input: RecursiveExpression, expected_output: RecursiveExpression) -> None:
    run_expression_simplification_test(test_input, expected_output)


@pytest.mark.parametrize(
    "test_input, expected_output",
    [
        ((6, "/", 2), 3),
        ((6.0, "/", 2.0), 3.0),
        ((7, "/", 2), 3),
    ],
)
def test_division(test_input: RecursiveExpression, expected_output: RecursiveExpression) -> None:
    run_expression_simplification_test(test_input, expected_output)


@pytest.mark.parametrize(
    "test_input, expected_output",
    [
        (("sin", (math.pi, "/", 2.0)), 1.0),
        (("log", math.e), 1.0),
        (("cos", 1), math.cos(1)),
        (("sqrt", 2), 2**0.5),
        (("unknown_function", 1), ("unknown_function", 1)),
    ],
)
def test_function_calling(test_input: RecursiveExpression, expected_output: RecursiveExpression) -> None:
    run_expression_simplification_test(test_input, expected_output)


@pytest.mark.parametrize(
    "test_input, expected_output",
    [
        (("-", 1), -1),
        (("!", True), False),
        ((3, "+", ("-", 1)), 2),
    ],
)
def test_unary_expressions(test_input: RecursiveExpression, expected_output: RecursiveExpression) -> None:
    run_expression_simplification_test(test_input, expected_output)


@pytest.mark.parametrize(
    "test_input, expected_output",
    [
        (("-", True), -1),
        (("-", False), 0),
        (("!", 3.0), False),
        (("!", 0.0), True),
        (("!", 7), False),
        (("!", 0), True),
        (("!", math.pi), False),
    ],
)
def test_unary_implicit_casting(test_input: RecursiveExpression, expected_output: RecursiveExpression) -> None:
    run_expression_simplification_test(test_input, expected_output)


@pytest.mark.parametrize(
    "test_input, expected_output",
    [
        (("x", "*", 0), 0),
        (("x", "*", 0.0), 0.0),
        ((1, "*", "x"), "x"),
        (("x", "*", (3, "+", ("-", 2))), "x"),
        (((1, "*", "x"), "*", (1, "*", "x")), ("x", "*", "x")),
        (("-", ("-", "x")), "x"),
        ((3, "*", (2, "*", "x")), (3, "*", (2, "*", "x"))),
    ],
)
def test_heuristics(test_input: RecursiveExpression, expected_output: RecursiveExpression) -> None:
    run_expression_simplification_test(test_input, expected_output)


@pytest.mark.parametrize(
    "test_input, expected_output",
    [
        (("x", "*", False), False),
        ((True, "*", "x"), "x"),
        (("x", "/", True), "x"),
        ((False, "+", "x"), "x"),
    ],
)
def test_heuristics_with_implicit_casting(
    test_input: RecursiveExpression, expected_output: RecursiveExpression
) -> None:
    run_expression_simplification_test(test_input, expected_output)


@pytest.mark.parametrize(
    "test_input, expected_exception",
    [
        ((3, "/", 0), IllegalMathExpression),
        ((3, "/", (1, "-", 1)), IllegalMathExpression),
        ((-25, "**", 0.5), NotImplementedError),
    ],
)
def test_mathematical_illegal_operations(test_input: RecursiveExpression, expected_exception: Any) -> None:
    start_expression = create_expression(test_input)
    start_program = create_program(start_expression)
    step = ExpressionsOptimizationStep()
    with pytest.raises(expected_exception):
        step(start_program)


@pytest.mark.parametrize(
    "source_program, target_program",
    [
        ("b = A[1+3];", "b = A[4];"),
        ("b = A[2] + 0;", "b = A[2];"),
        ("array[int[32], 2] myArray = {0, 2+2};", "array[int[32], 2] myArray = {0, 4};"),
    ],
)
def test_array_resolving(source_program: str, target_program: str) -> None:
    optimizer = ExpressionsOptimizationStep()
    source_oq3_program = OpenQasmProgram(parser.parse(source_program))
    transformed_program = optimizer(source_oq3_program)
    assert isinstance(transformed_program, OpenQasmProgram)
    source_ast = transformed_program.ast
    target_ast = parser.parse(target_program)
    assert source_ast == target_ast
