from typing import Union, Tuple, Any

from openqasm3 import ast
from qm_qasm.passes.utils import PythonLiterals, create_literal

RecursiveExpression = Union[str, PythonLiterals, Tuple[Any, ...]]


def create_expression(t: RecursiveExpression) -> ast.Expression:
    if isinstance(t, (int, bool, float)):
        return create_literal(t)
    if isinstance(t, str):
        return ast.Identifier(t)
    if len(t) == 3:
        lhs, op, rhs = t
        return ast.BinaryExpression(
            lhs=create_expression(lhs),
            op=ast.BinaryOperator[op],
            rhs=create_expression(rhs),
        )
    elif len(t) == 2:
        op, expression = t
        expression = create_expression(expression)
        try:
            return ast.UnaryExpression(op=ast.UnaryOperator[op], expression=expression)
        except KeyError:
            return ast.FunctionCall(name=ast.Identifier(op), arguments=[expression])
            # It doesn't support function of two args
    else:
        raise NotImplementedError
