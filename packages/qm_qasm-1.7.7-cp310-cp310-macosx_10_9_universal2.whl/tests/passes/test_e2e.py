import math

from qm import qua
from qm import Program as QuaProgram

from qm_qasm import Compiler
from qm_qasm.programs import Qua1Program
from tests.conftest import assert_equal_programs


def run_test_from_open_qasm_to_qua(oq_code: str, expected_qua1_program: QuaProgram, fake_compiler: Compiler) -> None:
    result = fake_compiler.compile(oq_code)
    assert isinstance(result.result_program, Qua1Program)
    assert_equal_programs(result.result_program.dsl_program, expected_qua1_program)


def test_running_gates_and_measuring(fake_compiler: Compiler) -> None:
    oq_code = """
    OPENQASM 3.0;
    bit b;
    y $0;
    x $1;
    cx $0,$1;
    x $0;
    delay[100ns] $1;
    cx $0,$1;
    gphase(1*pi+0) $2;
    b = measure $0;
    """
    with qua.program() as expected_qua1_program:
        qua.play("pulse_y", "qe_0")
        qua.play("pulse_x", "qe_1")

        qua.align("qe_0", "qe_1")
        qua.play("pulse_cx", "qe_0_1")
        qua.align("qe_0", "qe_1")

        qua.play("pulse_x", "qe_0")
        qua.wait(25, "qe_1")

        qua.align("qe_0", "qe_1")
        qua.play("pulse_cx", "qe_0_1")
        qua.align("qe_0", "qe_1")

        qua.frame_rotation_2pi(math.pi, "qe_2")

        b = qua.declare(bool, value=False)
        demod_result = qua.declare(qua.fixed)
        demod = qua.dual_demod.full("integ_w1_I", "out1", "integ_w2_I", "out2", demod_result)
        qua.measure("pulse_measure", "qe_0", None, demod)

        qua.assign(b, demod_result > 0)
        stream = qua.declare_stream()
        qua.save(b, stream)
        with qua.stream_processing():
            stream.save_all("b")
    run_test_from_open_qasm_to_qua(oq_code, expected_qua1_program, fake_compiler)
