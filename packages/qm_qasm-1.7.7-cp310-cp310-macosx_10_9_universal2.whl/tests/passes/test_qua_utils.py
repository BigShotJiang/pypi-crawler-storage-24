from qm import qua

from qm_qasm.passes.utils import is_inside_scope


def test_out_of_scope() -> None:
    assert not is_inside_scope()


def test_after_getting_out_of_program_scope() -> None:
    with qua.program():
        qua.play("pulse_cx", "qe_0_1")
    assert not is_inside_scope()


def test_inside_a_regular_scope() -> None:
    with qua.program():
        qua.play("pulse_cx", "qe_0_1")
        assert is_inside_scope()


def test_inside_an_if() -> None:
    with qua.program():
        with qua.if_(1 < 0):
            qua.play("pulse_cx", "qe_0_1")
            assert is_inside_scope()


def test_inside_a_for() -> None:
    with qua.program():
        with qua.while_(1 < 0):
            qua.play("pulse_cx", "qe_0_1")
            assert is_inside_scope()
