import pytest
from typing import Type
from openqasm3 import parser, ast
from qm_qasm.passes.parsing.oq3_code_normalizer import OQ3CodeNormalizer, IOVariablesTransformer
from qm_qasm.passes.init_value_separator import ClassicalDeclarationInitValueSeparator
from qm_qasm.programs import OpenQasmProgram


def check_io_transformer(source_program: str, target_program: str) -> None:
    oq3_ast = parser.parse(source_program)
    visitor = IOVariablesTransformer()
    current = visitor.visit(oq3_ast)
    expected = parser.parse(target_program)
    assert expected == current


def check_io_transformer_with_expected_exception(source_program: str, expected_exception: Type[BaseException]) -> None:
    oq3_ast = parser.parse(source_program)
    visitor = IOVariablesTransformer()
    with pytest.raises(expected_exception):
        visitor.visit(oq3_ast)


@pytest.mark.parametrize(
    "source_program",
    [
        "output bit a;",
        "output bit a; bit b;",
        "output bit a; output bit b;",
        "input bit a; bit b;",
        "input bit a; output bit b;",
    ],
)
def test_no_change_when_io_defined(source_program: str) -> None:
    check_io_transformer(source_program, source_program)


@pytest.mark.parametrize(
    "source_program, target_program",
    [
        ("bit a;", "output bit a;"),
        ("bit a; bit b;", "output bit a; output bit b;"),
        ("bit[8] a;", "output bit[8] a;"),
        ("int[17] b;", "output int[17] b;"),
        ("float[3] c;", "output float[3] c;"),
        ("array[int[2], 10] d;", "output array[int[2], 10] d;"),
    ],
)
def test_when_no_io_defined(source_program: str, target_program: str) -> None:
    check_io_transformer(source_program, target_program)


def test_init_with_measurement() -> None:
    # The statement "output bit a = measure q;" is not allowed by the parser, but is still allowed by the language.
    #  So we create the node directly
    oq3_ast = parser.parse("bit a = measure q;")
    visitor = IOVariablesTransformer()
    current = visitor.visit(oq3_ast)
    expected = ast.Program(
        [
            ast.IODeclaration(ast.IOKeyword.output, type=ast.BitType(), identifier=ast.Identifier("a")),
            ast.QuantumMeasurementStatement(ast.QuantumMeasurement(ast.Identifier("q")), target=ast.Identifier("a")),
        ]
    )
    assert expected == current


def test_init_with_measurement_of_an_array() -> None:
    # The statement "output bit a = measure q;" is not allowed by the parser, but is still allowed by the language.
    #  So we create the node directly
    oq3_ast = parser.parse("bit[3] a = measure q[1:3];")
    visitor = IOVariablesTransformer()
    current = visitor.visit(oq3_ast)
    expected = ast.Program(
        [
            ast.IODeclaration(
                ast.IOKeyword.output, type=ast.BitType(size=ast.IntegerLiteral(3)), identifier=ast.Identifier("a")
            ),
            ast.QuantumMeasurementStatement(
                measure=ast.QuantumMeasurement(
                    ast.IndexedIdentifier(
                        ast.Identifier("q"),
                        indices=[[ast.RangeDefinition(ast.IntegerLiteral(1), ast.IntegerLiteral(3), None)]],
                    )
                ),
                target=ast.Identifier("a"),
            ),
        ]
    )
    assert expected == current


@pytest.mark.parametrize("source_version", ["2", "2.0", "2.0", "3", "3.0"])
def test_version_normalization(source_version: str) -> None:
    source_program = f"OPENQASM {source_version};"
    target_program = f"OPENQASM {OQ3CodeNormalizer.target_version_str};"
    oq3_program = OpenQasmProgram(parser.parse(source_program))
    normalizer = OQ3CodeNormalizer()
    current = normalizer(oq3_program)
    expected = OpenQasmProgram(parser.parse(target_program))
    assert isinstance(current, OpenQasmProgram)
    assert expected.ast == current.ast


@pytest.mark.parametrize("bit_value", ["0", "false", "1", "true"])
def test_bit_declaration(bit_value: str) -> None:
    oq_code = f"bit b = {bit_value};"
    target_code = f"output bit b; b = {bit_value};"
    check_io_transformer(oq_code, target_code)


@pytest.mark.parametrize("bit_value", ["0", "1", "10", "01_10", "0001_0001"])
def test_bit_array_declaration(bit_value: str) -> None:
    string_length = len(bit_value.replace("_", ""))
    oq_code = f"bit[{string_length}] b = {bit_value};"
    target_code = f"output bit[{string_length}] b; b = {bit_value};"
    check_io_transformer(oq_code, target_code)


@pytest.mark.parametrize("declaration_type", ["int", "bit", "angle"])
@pytest.mark.parametrize("length", ["", "[1]", "[10]", "[x]"])
@pytest.mark.parametrize("value", ["0", "1.3", "x", "b", "0001_0001", "13"])
def test_declaration_with_init_value(declaration_type: str, length: str, value: str) -> None:
    oq_code = f"{declaration_type}{length} b = {value};"
    target_code = f"{declaration_type}{length} b; b = {value};"
    oq3_ast = parser.parse(oq_code)
    transformer = ClassicalDeclarationInitValueSeparator()
    current = transformer.visit(oq3_ast)
    expected = parser.parse(target_code)
    assert expected == current
