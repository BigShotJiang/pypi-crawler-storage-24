import pytest

from openqasm3 import ast
from qm_qasm.programs import OpenQasmProgram, TextualProgram
from qm_qasm.passes.parsing.ast_builder import GrammarParserException
from qm_qasm.passes.parsing.ast_builder import AstBuilder
from qm_qasm.passes.parsing.validators import VersionValidation, UnsupportedOpenQASMVersionException
from qm_qasm.passes.feature_validation import AllowedFeatureValidation, InvalidFeatureException


def generate_example_oq3_ast() -> ast.Program:
    program = ast.Program([])
    program.version = "3.1"
    program.statements = [ast.Include("qelib7.inc"), ast.QubitDeclaration(ast.Identifier("q"), ast.IntegerLiteral(12))]
    return program


@pytest.mark.parametrize(
    "source_program,target_program",
    [
        (
            """
            OPENQASM 3.1;
            // hello world
            include "qelib7.inc";
            qreg q[12];
            """,
            generate_example_oq3_ast(),
        ),
    ],
)
def test_ast_builder(source_program: str, target_program: ast.Program) -> None:
    builder = AstBuilder()
    program = TextualProgram(source_program)
    transformed_program = builder(program)
    assert transformed_program.ast == target_program


def test_ast_builder_invalid_source() -> None:
    builder = AstBuilder()
    program = TextualProgram("lol")
    with pytest.raises(GrammarParserException):
        builder(program)


SUPPORTED_VERSIONS = ["3.0.1", "3.0.0"]


def get_version_validator() -> VersionValidation:
    return VersionValidation(SUPPORTED_VERSIONS)


def run_test_on_unsupported_version(version: str) -> None:
    program = OpenQasmProgram(ast.Program([]))
    program.ast.version = version
    v = get_version_validator()
    with pytest.raises(UnsupportedOpenQASMVersionException):
        v(program)


@pytest.mark.parametrize(
    "version",
    [
        "0.0.0",
        "2.0.0",
        "2.9.1",
        "2",
        "2.3",
        "2.3.0rc",
    ],
)
def test_deprecated_versions(version: str) -> None:
    run_test_on_unsupported_version(version)


@pytest.mark.parametrize(
    "version",
    [
        "3.0.1rc",
        "3.0.2",
        "3.1",
        "4",
    ],
)
def test_future_versions(version: str) -> None:
    run_test_on_unsupported_version(version)


@pytest.mark.parametrize("version", SUPPORTED_VERSIONS)
def test_supported_versions(version: str) -> None:
    program = OpenQasmProgram(ast.Program([]))
    program.ast.version = version
    v = get_version_validator()
    v(program)
    assert True


def test_allowed_nodes() -> None:
    def is_allowed_feature(node: ast.QASMNode) -> bool:
        return isinstance(node, (ast.Program, ast.Include))
    validator = AllowedFeatureValidation(is_allowed_feature)
    program = ast.Program([ast.Include("example_327687812634234.inc")])
    validator(OpenQasmProgram(program))
    assert True


def test_disallowed_features() -> None:
    def is_allowed_feature(_node: ast.QASMNode) -> bool:
        return not (isinstance(_node, ast.Include) and _node.filename == "example.inc")
    validator = AllowedFeatureValidation(is_allowed_feature)
    node = ast.Include("example.inc")
    program = ast.Program([node])
    with pytest.raises(InvalidFeatureException) as e:
        validator(OpenQasmProgram(program))

    assert e.value.node == node
