from typing import Type, Optional, Set

import pytest

from openqasm3 import parser
from qm_qasm.passes.parsing.physical_qubit_resolver import PhysicalQubitsTransformer
from qm_qasm.passes.parsing.validators import (
    ReferencingValidator,
    RedeclarationException,
    UnresolvableIdentifierException,
    ReferencingException,
)


def init_validator(existing_names: Optional[Set[str]] = None) -> ReferencingValidator:
    existing_names = existing_names or set()
    return ReferencingValidator(existing_names)


def run_test_with_no_error(oq_code: str, existing_names: Optional[Set[str]] = None) -> None:
    validator = init_validator(existing_names)
    qubits_transformer = PhysicalQubitsTransformer()
    oq_program = qubits_transformer.visit(parser.parse(oq_code))
    validator.visit(oq_program)
    assert True


def run_test_with_expected_error(
        oq_code: str, expected_error: Type[ReferencingException],
        existing_names: Optional[Set[str]] = None,
        value_name: str = "x",
) -> None:
    """In all the erroneous tests, the name of the problematic variable is x"""
    validator = init_validator(existing_names)
    oq_program = parser.parse(oq_code)
    with pytest.raises(expected_error) as e:
        validator.visit(oq_program)
    assert e.value.name == value_name


@pytest.mark.parametrize(
    "oq_code",
    [
        "int x; x += 1;",
        "int x; x = x;",
        "gate g(y) q {} int x; g(x) $0;",
    ],
)
def test_referencing_existing_variable(oq_code: str) -> None:
    run_test_with_no_error(oq_code)


@pytest.mark.parametrize(
    "oq_code",
    [
        "int x; int y; for int z in {x, y} {z += x;}",
        "int x; int y; for int z in [x: y] {z += x;}",
        "int x; int y; for int z in x {for int w in y {z += y;}}",
        "for int z in [1: 10] {for int y in [1: z] {z += y;}}",
    ],
)
def test_referencing_existing_variable_in_a_for_loop(oq_code: str) -> None:
    run_test_with_no_error(oq_code)


@pytest.mark.parametrize(
    "oq_code",
    [
        "int x; for int x in {1, 2} {}",
        "for int x in {1, 2} {for int x in {3, 4} {}}",
    ],
)
def test_for_loops_redeclaration(oq_code: str) -> None:
    run_test_with_expected_error(oq_code, RedeclarationException)


@pytest.mark.parametrize(
    "oq_code",
    [
        "for int z in {1, 2} {z += x;}",
        "for int z in {1, x} {}",
    ],
)
def test_for_loops_no_ref(oq_code: str) -> None:
    run_test_with_expected_error(oq_code, UnresolvableIdentifierException)


@pytest.mark.parametrize(
    "oq_code",
    [
        "for int x in x {}",
        "for int x in {x} {}",
        "for int x in {1, x + 1} {}",
        "for int x in [1: x] {}",
    ],
)
def test_for_self_referencing(oq_code: str) -> None:
    run_test_with_expected_error(oq_code, UnresolvableIdentifierException)


@pytest.mark.parametrize(
    "oq_code",
    [
        "int x = x;",
        "int x = x + 1;",
        "int y = x;",
        "bit[8] b = x;",
        "int x = 7 + (8 * x);",
    ],
)
def test_declaration_without_referencing(oq_code: str) -> None:
    run_test_with_expected_error(oq_code, UnresolvableIdentifierException)


@pytest.mark.parametrize(
    "oq_code",
    [
        "int y; y = x + 1;",
        "x = y;",
        "x = x;",
        "gate g(x) q {} g(x) $0;",
        "gate g(r) q {} int r; g(r) x;",
    ],
)
def test_calling_without_referencing(oq_code: str) -> None:
    run_test_with_expected_error(oq_code, UnresolvableIdentifierException)


@pytest.mark.xfail(reason="We don't support gate validation in this step, only in the gate resolver")
def test_calling_gate_without_referencing() -> None:
    run_test_with_expected_error("x $0;", UnresolvableIdentifierException)


DECLARATIONS = [
    "bit x;",
    "bit x = false;",
    "int x;",
    "int x = 5;",
    "int x; int c = x + 1;",
    "gate x q {}",
    "qubit x;",
    "const int x = 5;",
]


@pytest.mark.parametrize("declaration1", DECLARATIONS)
@pytest.mark.parametrize("declaration2", DECLARATIONS)
def test_redeclaration_of_variables(declaration1: str, declaration2: str) -> None:
    oq_code = f"""
    {declaration1}
    {declaration2}
    """
    run_test_with_expected_error(oq_code, RedeclarationException)


def test_underscore_as_iterator_name() -> None:
    oq_code = """
    int _ = 0;
    for int _ in [0: 1] {
        x $0;
    }
    """
    run_test_with_expected_error(oq_code, RedeclarationException, value_name="_")


def test_underscore_in_a_for_loop() -> None:
    oq_code = """
    for int _ in [0: 1] {
        x $0;
    }
    """
    run_test_with_no_error(oq_code)
