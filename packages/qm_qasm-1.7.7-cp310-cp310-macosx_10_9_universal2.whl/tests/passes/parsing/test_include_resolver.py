import os
import pytest
import tempfile
from typing import Dict, Type

from openqasm3 import ast, parser
from qm_qasm.programs import OpenQasmProgram
from qm_qasm.passes.parsing.includes_resolver import DeepInclusionError, IncludeFileDeclaresVersionException
from qm_qasm.passes.parsing.includes_resolver import IncludesResolver

_FILES = {
    "example0.inc": "x = 0;",
    "example1.inc": "x = 1;",
    "example3.inc": "x = 3;",
    "file_with_include.inc": 'include "example0.inc"; x = 2;',
    "file_with_include2.inc": 'include "file_with_include.inc"; x = 4;',
    "bad_file_with_version.inc": 'OPENQASM 3.0; include "example2.inc";',
    "self_recursive_file.inc": 'include "self_recursive_file.inc"; x = 17;',
    "recursive_file1.inc": 'include "recursive_file2.inc"; x = 3.14;',
    "recursive_file2.inc": 'include "recursive_file1.inc"; y = 6.28;',
    "statement_and_then_include.inc": 'x = 35; include "example0.inc"; y = 9.8;',
}


def _get_source_program_ast(source_program: str) -> OpenQasmProgram:
    filenames_translation = _generate_tmp_files(_FILES)
    for original_filename, actual_filename in filenames_translation.items():
        source_program = source_program.replace(original_filename, actual_filename)
    source_oq3_program = OpenQasmProgram(parser.parse(source_program))
    return source_oq3_program


def _generate_tmp_files(files: Dict[str, str]) -> Dict[str, str]:
    filenames_translation = {}
    fds_by_filename = {}
    for filename, content in files.items():
        fd, actual_filename = tempfile.mkstemp()
        filenames_translation[filename] = actual_filename
        fds_by_filename[filename] = fd
    for filename in files.keys():
        for original_filename, actual_filename in filenames_translation.items():
            files[filename] = files[filename].replace(original_filename, actual_filename)
    for filename, fd in fds_by_filename.items():
        with os.fdopen(fd, "w") as file:
            file.write(files[filename])
    return filenames_translation


def _test_includes_resolver(source_program: str, target_program: str, max_inclusion_depth: int = 10) -> None:
    source_oq3_program = _get_source_program_ast(source_program)
    resolver = IncludesResolver(max_depth=max_inclusion_depth)
    transformed_program = resolver(source_oq3_program)
    source_ast = transformed_program.ast
    target_ast = parser.parse(target_program)
    assert source_ast == target_ast


def _test_includes_resolver_with_error(
    source_program: str, expected_error: Type[BaseException], max_inclusion_depth: int = 10
) -> None:
    resolver = IncludesResolver(max_depth=max_inclusion_depth)
    source_oq3_program = _get_source_program_ast(source_program)
    with pytest.raises(expected_error):
        resolver(source_oq3_program)


@pytest.mark.parametrize(
    "source_program",
    [
        "OPENQASM 3.0;",
        "OPENQASM 3.0; xxx q;",
        "OPENQASM 3.0; qreg q[3];",
    ],
)
def test_no_includes(source_program: str) -> None:
    _test_includes_resolver(source_program=source_program, target_program=source_program)


@pytest.mark.parametrize(
    "source_program, target_program",
    [
        (
            """
            OPENQASM 3.0;
            include "example0.inc";
            gate xxx q {}
            """,
            """
            OPENQASM 3.0;
            x = 0;
            gate xxx q {}
            """,
        ),
        (
            """
            OPENQASM 3.0;
            include "example0.inc";
            include "example1.inc";
            gate xxx q {}
            """,
            """
            OPENQASM 3.0;
            x = 0;
            x = 1;
            gate xxx q {}
            """,
        ),
        (
            """
            OPENQASM 3.0;
            include "example0.inc";
            include "example1.inc";
            include "example3.inc";
            gate xxx q {}
            """,
            """
            OPENQASM 3.0;
            x = 0;
            x = 1;
            x = 3;
            gate xxx q {}
            """,
        ),
    ],
)
def test_sanity(source_program: str, target_program: str) -> None:
    _test_includes_resolver(source_program, target_program)


@pytest.mark.parametrize(
    "source_program, target_program",
    [
        (
            """
            OPENQASM 3.0;
            include "file_with_include.inc";
            include "example3.inc";
            gate xxx q {}
            """,
            """
            OPENQASM 3.0;
            x = 0;
            x = 2;
            x = 3;
            gate xxx q {}
            """,
        )
    ],
)
def test_nested_includes(source_program: str, target_program: str) -> None:
    _test_includes_resolver(source_program, target_program)


@pytest.mark.parametrize(
    "source_program, target_program",
    [
        (
            """
            OPENQASM 3.0;
            include "example0.inc";
            include "example1.inc";
            gate example2 q { H q; }
            """,
            """
            OPENQASM 3.0;
            x = 0;
            x = 1;
            gate example2 q { H q; }
            """,
        ),
    ],
)
def test_multiple_includes(source_program: str, target_program: str) -> None:
    _test_includes_resolver(source_program, target_program)


@pytest.mark.parametrize(
    "source_program, target_program",
    [
        (
            """
            OPENQASM 3.0;
            include "example0.inc";
            include "file_with_include.inc";
            """,
            """
            OPENQASM 3.0;
            x = 0;
            x = 0;
            x = 2;
            """,
        ),
        (
            """
            OPENQASM 3.0;
            include "example0.inc";
            include "example1.inc";
            include "file_with_include.inc";
            gate example3 q { H q; }
            """,
            """
            OPENQASM 3.0;
            x = 0;
            x = 1;
            x = 0;
            x = 2;
            gate example3 q { H q; }
            """,
        ),
        (
            """
            OPENQASM 3.0;
            include "file_with_include.inc";
            include "example0.inc";
            include "example1.inc";
            """,
            """
            OPENQASM 3.0;
            x = 0;
            x = 2;
            x = 0;
            x = 1;
            """,
        ),
    ],
)
def test_duplicated_includes(source_program: str, target_program: str) -> None:
    _test_includes_resolver(source_program, target_program)


@pytest.mark.parametrize(
    "source_program, target_program",
    [
        (
            """
            OPENQASM 3.0;
            x = 13;
            include "example0.inc";
            x = 1234;
            """,
            """
            OPENQASM 3.0;
            x = 13;
            x = 0;
            x = 1234;
            """,
        ),
        (
            """
            OPENQASM 3.0;
            x = 0;
            include "statement_and_then_include.inc";
            x = 9;
            """,
            """
            OPENQASM 3.0;
            x = 0;
            x = 35;
            x = 0;
            y = 9.8;
            x = 9;
            """,
        ),
    ],
)
def test_include_in_the_middle_of_the_code(source_program: str, target_program: str) -> None:
    _test_includes_resolver(source_program, target_program)


def test_includes_resolver_not_found() -> None:
    resolver = IncludesResolver(max_depth=10)
    program = ast.Program([ast.Include("example_327687812634234.inc")])
    with pytest.raises(FileNotFoundError):
        resolver(OpenQasmProgram(program))


@pytest.mark.parametrize(
    "filename",
    [
        "recursive_file1.inc",
        "recursive_file2.inc",
        "self_recursive_file.inc",
    ],
)
def test_cyclic_include(filename: str) -> None:
    source = f'OPENQASM 3.0; include "{filename}";'
    _test_includes_resolver_with_error(source, DeepInclusionError)


def test_too_deep_include() -> None:
    filename = "file_with_include2.inc"
    source = f'OPENQASM 3.0; include "{filename}";'
    _test_includes_resolver_with_error(source, DeepInclusionError, max_inclusion_depth=2)


def test_exact_depth_include() -> None:
    filename = "file_with_include2.inc"
    source = f'OPENQASM 3.0; include "{filename}";'
    target_program = """
    OPENQASM 3.0;
    x = 0;
    x = 2;
    x = 4;
    """
    _test_includes_resolver(source, target_program, 3)


@pytest.mark.parametrize(
    "filename",
    [
        "bad_file_with_version.inc",
    ],
)
def test_includes_resolver_invalid_content(filename: str) -> None:
    source = f'OPENQASM 3.0; include "{filename}";'
    _test_includes_resolver_with_error(source, IncludeFileDeclaresVersionException)
