# Roadmap

Things I want done with this micro-framework before I use it in other personal projects.

## Phase 1: Refactor

* [ ] Refactor server.py into a package with split files
* [ ] Use pyproject.toml, remove requirements.txt
* [ ] (OPTIONAL) Use poetry

## Phase 2: Robustness

* [ ] Use read streams for sending raw files to avoid gagging on really big ones
* [ ] Add `filters/` dynamic loading system for custom Jinja plugins/filters
* [ ] Escape attributes
* [ ] Map HTML empty attributes (e.g. `!DOCTYPE html=#null"` = `<!DOCTYPE html>`)
