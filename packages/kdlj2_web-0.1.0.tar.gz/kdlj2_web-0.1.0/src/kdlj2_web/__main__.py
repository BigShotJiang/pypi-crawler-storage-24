"""
The kdlj2-web utility.

Supports both rendering static websites and serving them as a dev server.
"""

from .main import main

if __name__ == "__main__":
    main()
