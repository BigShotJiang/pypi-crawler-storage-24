"""
kdlj2-web library entrypoint.

Provides utilities and classes for handling Jinja2 -> KDL -> HTML conversion, or
piecemeal parts of that pipeline, as well as dynamic serving and static rendering of
directory structures.
"""

# TODO: add AppOptions named tuple for things like using a custom loader (instead of
#       src_path / 'templates'), etc

from .errors import TemplateNotFoundException
from .filters import is_overdue
from .mime import setup_mime
from .render import render_node_list, render_template
from .server import make_kdlj2_http_handler, setup_debug_server
from .static import static_build

__all__ = [
    "TemplateNotFoundException",
    "is_overdue",
    "parentpath",
    "str_esc",
    "time_is_past",
    "render_node_list",
    "render_template",
    "make_kdlj2_http_handler",
    "setup_debug_server",
    "render_template",
    "static_build",
    "setup_mime",
]
