"""Mimetype related utilities for kdlj2."""

import mimetypes


def setup_mime() -> None:
    """
    Add KDL and KDL.j2 types to the mimetype registry.

    Applies directly to the mimetypes module's global registry.
    """
    mimetypes.add_type("text/jinja2+kdl", ".kdl.j2")
    mimetypes.add_type("text/kdl", ".kdl")
