"""Tiny utility functions used by kdlj2."""

import datetime


def str_esc(s: str) -> str:
    """
    Escapes string contents for quoting.

    Use Jinja2's own builtin escape/e filter for HTML escaping!
    """
    if s is None:
        return ""

    return str(s).replace('"', '\\"').replace("'", "\\'")


def time_is_past(dt: datetime.datetime) -> bool:
    """Check whether the given datetime has already elapsed."""
    return dt < datetime.datetime.now()


def parse_time(time_string: str) -> datetime.datetime:
    """Parse a YYYY-MM-DD format string into a datetime."""
    return datetime.datetime.strptime(time_string, "%Y-%m-%d")
