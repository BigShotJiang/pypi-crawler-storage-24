"""Jinja2 environment setup utilities."""

import os

from jinja2 import Environment, FileSystemLoader

from .filters import setup_filters


def setup_environment(src_path: str = ".") -> Environment:
    """Create a Jinja2 environment premade with kdlj2 settings.

    Automatically registers the default kdlj2-web filters and, optionally,
    a custom base path from which to find the `templates` folder.
    """
    env = Environment(loader=FileSystemLoader([os.path.join(src_path, "templates")]))
    setup_filters(env)
    return env
