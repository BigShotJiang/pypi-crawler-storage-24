"""Error types used by kdlj2."""


class DatetimeParseErrorValue:
    """Wraps around a ValueError emitted by strptime when fed an invalid string."""

    def __init__(self, ve: ValueError):
        """
        Wrap an error.

        - ve: the error to wrap around
        """
        self.error = ve

    def throw(self) -> None:
        """Raise the wrapped error."""
        raise self.error


class TemplateNotFoundException(BaseException):
    """
    kdlj2 attempted to load a template which was not found by Jinja2.

    Wraps an Exception value or a string.
    """

    def __init__(self, name: str, err: Exception | str = "template not found"):
        """
        Wrap an unfound template name and error object or explanation.

        - name: the name of the template that could not be found
        - err: an explanation of, or exception object tied to, the failure
        """
        self.name = name
        self.err = err

    def __str__(self) -> str:
        """
        Stringify the error into a simple summary.

        Returns an explanation of the error, with the template name as context and
        the wrapped error ahead.
        """
        return f"Template {repr(self.name)} could not be found: {self.err}"
