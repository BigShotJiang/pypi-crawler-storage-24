"""Problem solving frameworks."""
