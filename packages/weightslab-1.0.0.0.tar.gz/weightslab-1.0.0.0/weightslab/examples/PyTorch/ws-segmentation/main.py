import os
import time
import logging
import tempfile
import itertools

import tqdm
import yaml
import torch
import numpy as np

from torch import nn, optim
from torchvision import transforms
from torchmetrics import JaccardIndex
from torch.utils.data import Dataset
from PIL import Image

import weightslab as wl

from weightslab.utils.logger import LoggerQueue
from weightslab.components.global_monitoring import (
    guard_training_context,
    guard_testing_context,
)


# Setup loggers
logging.basicConfig(level=logging.ERROR)
logging.getLogger("PIL").setLevel(logging.INFO)


# =============================================================================
# Small UNet-ish segmentation model
# =============================================================================
import torch
import torch.nn as nn
import torch.nn.functional as F


class DoubleConv(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.block(x)


class SmallUNet(nn.Module):
    def __init__(self, in_channels=3, num_classes=6, image_size=256):
        super().__init__()
        # For WeightsLab
        self.task_type = "segmentation"
        self.num_classes = num_classes
        self.class_names = ["Background", "Ego Road", "Driveable Area", "Lane Line 1", "Lane Line 2", "Lane Line 3"]
        self.input_shape = (1, in_channels, image_size, image_size)

        self.enc1 = DoubleConv(in_channels, 32)
        self.pool1 = nn.MaxPool2d(2)
        self.enc2 = DoubleConv(32, 64)
        self.pool2 = nn.MaxPool2d(2)

        self.bottleneck = DoubleConv(64, 128)

        self.up2 = nn.ConvTranspose2d(128, 64, 2, stride=2)
        self.dec2 = DoubleConv(64 + 64, 64)
        self.up1 = nn.ConvTranspose2d(64, 32, 2, stride=2)
        self.dec1 = DoubleConv(32 + 32, 32)

        self.head = nn.Conv2d(32, num_classes, 1)

    def forward(self, x):
        # Encoder
        e1 = self.enc1(x)
        p1 = self.pool1(e1)

        e2 = self.enc2(p1)
        p2 = self.pool2(e2)

        # Bottleneck
        b = self.bottleneck(p2)

        # Decoder
        u2 = self.up2(b)
        # ⚠️ Important: no `if` on shapes; always interpolate
        u2 = F.interpolate(u2, size=e2.shape[-2:], mode="bilinear", align_corners=False)
        d2 = self.dec2(torch.cat([u2, e2], dim=1))

        u1 = self.up1(d2)
        u1 = F.interpolate(u1, size=e1.shape[-2:], mode="bilinear", align_corners=False)
        d1 = self.dec1(torch.cat([u1, e1], dim=1))

        logits = self.head(d1)  # [B, C, H, W]
        return logits


# =============================================================================
# BDD100k segmentation dataset
# =============================================================================
class BDD100kSegDataset(Dataset):
    """
    Uses your existing layout:

      data/BDD100k_reduced/
        images_1280x720/
          train/
          val/
        bdd100k_labels_dac_daa_lls_lld_curbs/
          train/
          val/

    Assumes image & label share basename (e.g. 0001.jpg / 0001.png).
    """

    def __init__(
        self,
        root,
        split="train",
        num_classes=6,
        ignore_index=255,
        image_size=256,
        max_samples=None
    ):
        super().__init__()
        self.root = root
        self.split = split
        self.num_classes = num_classes
        self.ignore_index = ignore_index
        self.task_type = "segmentation"

        img_dir = os.path.join(root, "images", split)
        lbl_dir = os.path.join(root, "labels", split)

        image_files = [
            f
            for f in os.listdir(img_dir)
            if f.lower().endswith((".jpg", ".jpeg", ".png"))
        ]
        image_files = sorted(set(image_files))[:max_samples] if max_samples is not None else sorted(set(image_files))  # Optionally limit number of samples for faster testing

        self.images = []
        self.masks = []
        for fname in image_files:
            img_path = os.path.join(img_dir, fname)
            base, _ = os.path.splitext(fname)
            lbl_name = base + ".png"
            lbl_path = os.path.join(lbl_dir, lbl_name)
            if os.path.exists(lbl_path):
                self.images.append(img_path)
                self.masks.append(lbl_path)

        if len(self.images) == 0:
            raise RuntimeError(f"No image/label pairs found in {img_dir} / {lbl_dir}")

        # This is used by load_raw_image in DataService / trainer_tools
        # so exposing .images is enough.
        self.image_transform = transforms.Compose(
            [
                transforms.Resize(
                    (
                        image_size,
                        image_size
                    ),
                    interpolation=Image.BILINEAR
                ),
                transforms.ToTensor(),
            ]
        )
        self.mask_resize = transforms.Resize(
            (image_size, image_size), interpolation=Image.NEAREST
        )

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        """
            IMPORTANT: returns (item, uid, target) only.
                - item: transformed input (e.g. image tensor)
                - uid: unique identifier for the sample (e.g. filename)
                - target: transformed label/target (e.g. mask tensor)
        """
        img_path = self.images[idx]
        mask_path = self.masks[idx]
        uid = os.path.basename(img_path)

        img = Image.open(img_path).convert("RGB")
        mask = Image.open(mask_path)

        img_t = self.image_transform(img)

        mask_r = self.mask_resize(mask)
        mask_np = np.array(mask_r, dtype=np.int64)
        mask_t = torch.from_numpy(mask_np)  # [H, W] int64

        return img_t, uid, mask_t


# =============================================================================
# Train / Test loops (segmentation, using watcher-wrapped loaders)
# =============================================================================
def train(loader, model, optimizer, criterion_mlt, device):
    """
    Single training step using the tracked dataloader + watched loss.

    loader yields (inputs, ids, labels) because of DataSampleTrackingWrapper.
    """
    with guard_training_context:
        (inputs, ids, labels) = next(loader)
        inputs = inputs.to(device)
        labels = labels.to(device)  # [B,H,W]

        optimizer.zero_grad()
        outputs = model(inputs)  # [B,C,H,W]

        preds = outputs.argmax(dim=1)  # [B,H,W]

        loss_batch = criterion_mlt(
            outputs.float(),
            labels.long(),
            batch_ids=ids,
            preds=preds,
        )  # CrossEntropyLoss(reduction="none") → [B,H,W]
        loss = loss_batch.mean()

        loss.backward()
        optimizer.step()

    return float(loss.detach().cpu().item())


def test(loader, model, criterion_mlt, metric_mlt, device, test_loader_len):
    """Full evaluation pass over the val loader."""
    losses = 0.0
    metric_mlt.reset()

    with guard_testing_context, torch.no_grad():
        for inputs, ids, labels in loader:
            inputs = inputs.to(device)
            labels = labels.to(device)

            outputs = model(inputs)
            preds = outputs.argmax(dim=1)  # [B,H,W]

            loss_batch = criterion_mlt(
                outputs.float(),
                labels.long(),
                batch_ids=ids,
                preds=preds,
            )
            losses += torch.mean(loss_batch)

            metric_mlt.update(preds, labels)

    loss = float((losses / test_loader_len).detach().cpu().item())
    miou = float(metric_mlt.compute().detach().cpu().item() * 100.0)
    return loss, miou


# =============================================================================
# Signal Definitions
# =============================================================================

"""
The ctx (SignalContext) object contains:
1. data: Raw input sample (image/tensor). [Used in STATIC mode]
2. image: Automatically converted HWC uint8 numpy image. [Used in STATIC mode]
3. subscribed_value: Live metric/loss value from the training loop. [Used in DYNAMIC mode]
4. sample_id: Unique identifier for the sample. [Available in BOTH]
5. dataframe: Proxy to query previously computed signals. [Available in BOTH]
6. origin: The dataset split name (e.g. 'train_loader'). [Available in BOTH]
7. is_static / is_dynamic: Helper flags for mode detection.
"""

@wl.signal(name="blue_pixels")
def compute_blue_pixels(ctx: wl.SignalContext) -> int:
    """
    Static signal counting pixels where Blue channel is dominant.

    Context Attributes Used:
        ctx.image
    """
    img_np = ctx.image
    if img_np is None or img_np.ndim != 3: return 0

    # R, G, B
    r, g, b = img_np[:,:,0], img_np[:,:,1], img_np[:,:,2]

    # Blue is dominant and bright
    blue_mask = (b > 150) & (b > r) & (b > g)
    return int(np.sum(blue_mask))


@wl.signal(name="blue_weighted_loss", subscribe_to="train_mlt_loss/CE", compute_every_n_steps=1)
def compute_blue_weighted_loss(ctx: wl.SignalContext) -> float:
    """
    Dynamic signal combining current loss with static blue pixel count.

    Context Attributes Used:
        ctx.subscribed_value: The current 'train_mlt_loss/CE' value for this sample.
        ctx.sample_id: Unique identifier used to link the loss to historical data.
        ctx.dataframe: Used to look up the pre-computed 'blue_pixels' signal.
        ctx.origin: The dataset split (train/val) needed for the dataframe query.
    """
    loss = ctx.subscribed_value

    # Note: origin is typically 'train_loader' or 'test_loader' in this script
    origin = ctx.origin or "train_loader"
    blue_val = ctx.dataframe.get_value(origin, ctx.sample_id, "signals_blue_pixels")

    if blue_val is None or (isinstance(blue_val, float) and np.isnan(blue_val)):
        blue_val = 0.0

    norm_blue = float(blue_val) / (128 * 128)
    return loss * norm_blue


# =============================================================================
# Main
# =============================================================================
if __name__ == "__main__":
    # --- 1) Load hyperparameters from YAML (if present) ---
    config_path = os.path.join(os.path.dirname(__file__), "config_mz.yaml")
    if os.path.exists(config_path):
        with open(config_path, "r") as fh:
            parameters = yaml.safe_load(fh) or {}
    else:
        parameters = {}

    # Defaults
    parameters.setdefault("experiment_name", "bdd_segmentation")
    parameters.setdefault("device", "auto")
    parameters.setdefault("training_steps_to_do", 500)
    parameters.setdefault("eval_full_to_train_steps_ratio", 50)
    parameters.setdefault("number_of_workers", 4)
    parameters.setdefault("num_classes", 6)      # adjust to your label set
    parameters.setdefault("ignore_index", 255)   # if you have void pixels
    parameters.setdefault("image_size", 256)
    parameters.setdefault("compute_natural_sort", True)

    exp_name = parameters["experiment_name"]
    num_classes = int(parameters["num_classes"])
    ignore_index = int(parameters["ignore_index"])
    image_size = int(parameters["image_size"])

    # --- 2) Device selection ---
    if parameters.get("device", "auto") == "auto":
        parameters["device"] = torch.device(
            "cuda" if torch.cuda.is_available() else "cpu"
        )
    device = parameters["device"]

    # --- 3) Logging directory ---
    if not parameters.get("root_log_dir"):
        tmp_dir = tempfile.mkdtemp()
        parameters["root_log_dir"] = tmp_dir
        print(f"No root_log_dir specified, using temporary directory: {parameters['root_log_dir']}")
    os.makedirs(parameters["root_log_dir"], exist_ok=True)

    log_dir = parameters["root_log_dir"]
    max_steps = parameters["training_steps_to_do"]
    eval_every = parameters["eval_full_to_train_steps_ratio"]
    verbose = parameters.get("verbose", True)
    tqdm_display = parameters.get("tqdm_display", True)

    # --- 4) Register logger + hyperparameters ---
    logger = LoggerQueue()
    wl.watch_or_edit(logger, flag="logger", name=exp_name, log_dir=log_dir)

    wl.watch_or_edit(
        parameters,
        flag="hyperparameters",
        name=exp_name,
        defaults=parameters,
        poll_interval=1.0,
    )

    # --- 5) Data (BDD100k reduced) ---
    default_data_root = os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..", "..", "data", "BDD100k_reduced")
    )
    data_root = parameters.get("data_root", default_data_root)

    train_cfg = parameters.get("data", {}).get("train_loader", {})
    test_cfg = parameters.get("data", {}).get("test_loader", {})

    _train_dataset = BDD100kSegDataset(
        root=data_root,
        split="train",
        num_classes=num_classes,
        ignore_index=ignore_index,
        image_size=image_size,
        max_samples=train_cfg.get("max_samples", None)  # Optionally limit number of samples for faster testing
    )
    _val_dataset = BDD100kSegDataset(
        root=data_root,
        split="val",
        num_classes=num_classes,
        ignore_index=ignore_index,
        image_size=image_size,
        max_samples=test_cfg.get("max_samples", None)  # Optionally limit number of samples for faster testing
    )

    train_loader = wl.watch_or_edit(
        _train_dataset,
        flag="data",
        loader_name="train_loader",
        batch_size=train_cfg.get("batch_size", 2),
        shuffle=train_cfg.get("shuffle", True),
        compute_hash=False,
        is_training=True,
        array_autoload_arrays=False,
        array_return_proxies=True,
        array_use_cache=True,
        preload_labels = False,
    )
    test_loader = wl.watch_or_edit(
        _val_dataset,
        flag="data",
        loader_name="test_loader",
        batch_size=test_cfg.get("batch_size", 2),
        shuffle=test_cfg.get("shuffle", False),
        compute_hash=False,
        is_training=False,
        array_autoload_arrays=False,
        array_return_proxies=True,
        array_use_cache=True,
        preload_labels = False
    )

    # --- 6) Model, optimizer, losses, metric ---
    _model = SmallUNet(
        in_channels=3, num_classes=num_classes, image_size=image_size
    ).to(device)
    model = wl.watch_or_edit(
        _model,
        flag="model",
        device=device
    )
    lr = parameters.get("optimizer", {}).get("lr", 1e-3)
    _optimizer = optim.Adam(model.parameters(), lr=lr)
    optimizer = wl.watch_or_edit(
        _optimizer,
        flag="optimizer",
    )

    # --- Compute class weights to handle class imbalance ---
    print("\n" + "=" * 60)
    print("Computing class weights to address class imbalance...")
    print("=" * 60)

    # Create weighted loss functions
    train_criterion_mlt = wl.watch_or_edit(
        nn.CrossEntropyLoss(
            reduction="none",
            ignore_index=ignore_index,
        ),
        flag="loss",
        name="train_mlt_loss/CE",
        per_sample=True,
        log=True,
    )
    test_criterion_mlt = wl.watch_or_edit(
        nn.CrossEntropyLoss(
            reduction="none",
            ignore_index=ignore_index,
        ),
        flag="loss",
        name="test_mlt_loss/CE",
        per_sample=True,
        log=True,
    )
    test_metric_mlt = wl.watch_or_edit(
        JaccardIndex(
            task="multiclass",
            num_classes=num_classes,
            ignore_index=ignore_index,
        ).to(device),
        flag="metric",
        name="test_metric/JaccardIndex",
        log=True,
    )

    # --- 7) Start WeightsLab services ---
    wl.serve(
        serving_grpc=parameters.get("serving_grpc", True),
        serving_cli=parameters.get("serving_cli", True),
    )

    print("=" * 60)
    print("🚀 STARTING BDD100k SEGMENTATION TRAINING")
    print(f"📈 Total steps: {max_steps}")
    print(f"🔄 Evaluation every {eval_every} steps")
    print(f"💾 Logs will be saved to: {log_dir}")
    print(f"📂 Data root: {data_root}")
    print("=" * 60 + "\n")

    # ================
    # 7. Training Loop
    train_range = tqdm.tqdm(itertools.count(), desc="Training") if tqdm_display else itertools.count()
    test_loss, test_metric = None, None
    start_time = time.time()
    for train_step in train_range:
        age = model.get_age() if hasattr(model, "get_age") else train_step  # Get model age in steps (not necessarily equal to train_step if model was reloaded or has seen more data than training steps)

        # Train
        train_loss = train(train_loader, model, optimizer, train_criterion_mlt, device)

        # Test
        if age == 0 or age % eval_every == 0:
            test_loader_len = len(test_loader)  # Store length before wrapping with tqdm
            test_loader_it = tqdm.tqdm(test_loader, desc="Evaluating") if tqdm_display else test_loader
            test_loss, test_metric = test(test_loader_it, model, test_criterion_mlt, test_metric_mlt, device, test_loader_len)

        # Verbose
        if verbose and not tqdm_display:
            print(
                "Training.. " +
                f"Step {train_step} (Age {age}): " +
                f"| Train Loss: {train_loss:.4f} " +
                (f"| Test Loss: {test_loss:.4f} " if test_loss is not None else '') +
                (f"| Test Acc mlt: {test_metric:.2f}% " if test_metric is not None else '')
            )
        elif tqdm_display:
            train_range.set_description("Step")
            train_range.set_postfix(
                train_loss=f"{train_loss:.4f}",
                test_loss=f"{test_loss:.4f}" if test_loss is not None else "N/A",
                acc=f"{test_metric:.2f}%" if test_metric is not None else "N/A"
            )

    print("\n" + "=" * 60)
    print(f"✅ Training completed in {time.time() - start_time:.2f} seconds")
    print(f"💾 Logs saved to: {log_dir}")
    print("=" * 60)

    # Keep the main thread alive to allow background serving threads to run
    wl.keep_serving()
