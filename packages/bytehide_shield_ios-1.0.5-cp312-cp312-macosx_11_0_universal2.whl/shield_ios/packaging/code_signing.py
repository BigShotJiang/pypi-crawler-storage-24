#!/usr/bin/env python3
"""Shield iOS - Code Signing Integration

Handles iOS app code signing after protection is applied.

iOS Code Signing Process:
    1. Remove old signature (_CodeSignature/)
    2. Sign embedded frameworks (inside-out)
    3. Sign embedded plugins/extensions
    4. Extract/preserve entitlements
    5. Update provisioning profile
    6. Sign main app bundle
    7. Verify signature

Requirements:
    - macOS (codesign tool)
    - Valid signing certificate
    - Provisioning profile (optional, can extract from original)
    - Entitlements (optional, can extract from original)

Signing Order (inside-out):
    1. Frameworks/MyFramework.framework/MyFramework
    2. PlugIns/MyExtension.appex
    3. MyApp.app/MyApp (main binary)

Author: ByteHide Shield iOS
"""

import platform
import subprocess
import shutil
from pathlib import Path
from typing import Optional, Dict
import plistlib

from shield_ios.core.pipeline import ProtectionStage
from shield_ios.core.context import ShieldContext


class CodeSigningStage(ProtectionStage):
    """Code Signing protection stage

    This stage handles:
    - Removing old signatures
    - Extracting entitlements from original binary
    - Signing embedded frameworks (inside-out)
    - Signing embedded plugins/extensions
    - Updating provisioning profile
    - Signing main app bundle
    - Verifying signature

    REQUIRES: macOS (codesign tool)
    """

    def __init__(self):
        super().__init__(name="Code Signing")
        self.is_macos = platform.system() == 'Darwin'
        self.signing_identity: Optional[str] = None
        self.provisioning_profile: Optional[Path] = None
        self.entitlements: Optional[Dict] = None
        self.entitlements_file: Optional[Path] = None

    def pre_execute(self, context: ShieldContext) -> None:
        """Validate code signing requirements"""

        # Check if we're on macOS
        if not self.is_macos:
            context.logger.warning("Code signing requires macOS (codesign tool)")
            context.logger.info("Current platform: " + platform.system())
            context.logger.info("You can:")
            context.logger.info("  1. Run Shield on macOS")
            context.logger.info("  2. Sign manually with: codesign -f -s 'Identity' MyApp.app")
            context.logger.info("  3. Skip signing for testing (app won't install on device)")

            # Check if user wants to skip signing
            skip_signing = context.config.protection.code_signing.get('skip_if_not_macos', True)
            if skip_signing:
                context.logger.warning("Skipping code signing (skip_if_not_macos=true)")
                context.skip_code_signing = True
                return
            else:
                raise RuntimeError("Code signing requires macOS, set skip_if_not_macos=true to skip")

        # Check if codesign tool is available
        if not self._check_codesign_available():
            raise RuntimeError("codesign tool not found (install Xcode Command Line Tools)")

        # Get signing identity
        self.signing_identity = context.config.protection.code_signing.get('identity')

        if not self.signing_identity:
            context.logger.warning("No signing identity provided")
            context.logger.info("Available identities:")
            self._list_signing_identities(context)
            raise ValueError("Code signing identity required (config: protection.code_signing.identity)")

        # Get provisioning profile (optional)
        profile_path = context.config.protection.code_signing.get('provisioning_profile')
        if profile_path:
            self.provisioning_profile = Path(profile_path)
            if not self.provisioning_profile.exists():
                raise FileNotFoundError(f"Provisioning profile not found: {self.provisioning_profile}")

        context.logger.info(f"Signing identity: {self.signing_identity}")
        if self.provisioning_profile:
            context.logger.info(f"Provisioning profile: {self.provisioning_profile.name}")

    def execute(self, context: ShieldContext) -> None:
        """Sign the app bundle"""

        # Skip if not on macOS
        if getattr(context, 'skip_code_signing', False):
            context.logger.section("Code Signing (SKIPPED)")
            return

        context.logger.section("Code Signing")

        app_bundle = context.app_bundle_path

        if not app_bundle or not app_bundle.exists():
            raise FileNotFoundError(f"App bundle not found: {app_bundle}")

        # Step 1: Remove old signature
        self._remove_old_signature(context, app_bundle)

        # Step 2: Extract entitlements from original binary
        self._extract_entitlements(context, context.binary_path)

        # Step 3: Update provisioning profile (if provided)
        if self.provisioning_profile:
            self._update_provisioning_profile(context, app_bundle)

        # Step 4: Sign embedded frameworks (inside-out)
        self._sign_frameworks(context, app_bundle)

        # Step 5: Sign embedded plugins/extensions
        self._sign_plugins(context, app_bundle)

        # Step 6: Sign main app bundle
        self._sign_app_bundle(context, app_bundle)

        # Step 7: Verify signature
        self._verify_signature(context, app_bundle)

        context.logger.success("Code signing completed")

    def _check_codesign_available(self) -> bool:
        """Check if codesign tool is available"""
        try:
            result = subprocess.run(
                ['which', 'codesign'],
                capture_output=True,
                text=True
            )
            return result.returncode == 0
        except Exception:
            return False

    def _list_signing_identities(self, context: ShieldContext) -> None:
        """List available signing identities"""
        try:
            result = subprocess.run(
                ['security', 'find-identity', '-v', '-p', 'codesigning'],
                capture_output=True,
                text=True,
                timeout=10
            )

            if result.returncode == 0 and result.stdout:
                for line in result.stdout.split('\n'):
                    if 'iPhone' in line or 'Apple' in line:
                        context.logger.info(f"  {line.strip()}")
            else:
                context.logger.warning("No signing identities found")

        except Exception as e:
            context.logger.warning(f"Failed to list identities: {e}")

    def _remove_old_signature(self, context: ShieldContext, app_bundle: Path) -> None:
        """Remove old code signature"""
        context.logger.info("Removing old signature...")

        signature_dir = app_bundle / "_CodeSignature"

        if signature_dir.exists():
            shutil.rmtree(signature_dir)
            context.logger.success(f"Removed old signature: {signature_dir.name}")
        else:
            context.logger.info("No old signature found (already removed)")

    def _extract_entitlements(self, context: ShieldContext, binary_path: Path) -> None:
        """Extract entitlements from original binary

        Entitlements are required for many iOS features (push notifications, iCloud, etc.)
        We extract them from the original binary before it was protected.
        """
        context.logger.info("Extracting entitlements...")

        try:
            # Create temp file for entitlements
            entitlements_path = binary_path.parent / "entitlements.plist"

            # Extract entitlements using codesign
            result = subprocess.run(
                ['codesign', '-d', '--entitlements', ':-', str(binary_path)],
                capture_output=True,
                timeout=30
            )

            if result.returncode == 0 and result.stdout:
                # Parse entitlements plist
                try:
                    # Skip the XML header if present
                    plist_data = result.stdout

                    # Save to file
                    with open(entitlements_path, 'wb') as f:
                        f.write(plist_data)

                    # Parse to validate
                    with open(entitlements_path, 'rb') as f:
                        self.entitlements = plistlib.load(f)

                    self.entitlements_file = entitlements_path

                    context.logger.success(f"Extracted entitlements ({len(self.entitlements)} keys)")

                    # Log key entitlements
                    important_keys = [
                        'application-identifier',
                        'com.apple.developer.team-identifier',
                        'aps-environment',
                        'keychain-access-groups',
                    ]

                    for key in important_keys:
                        if key in self.entitlements:
                            value = self.entitlements[key]
                            if isinstance(value, list):
                                value = ', '.join(str(v) for v in value)
                            context.logger.info(f"  {key}: {value}")

                except Exception as e:
                    context.logger.warning(f"Failed to parse entitlements: {e}")
                    self.entitlements = None
                    self.entitlements_file = None

            else:
                context.logger.warning("No entitlements found in original binary")
                self.entitlements = None
                self.entitlements_file = None

        except Exception as e:
            context.logger.warning(f"Failed to extract entitlements: {e}")
            self.entitlements = None
            self.entitlements_file = None

    def _update_provisioning_profile(self, context: ShieldContext, app_bundle: Path) -> None:
        """Update provisioning profile"""
        context.logger.info("Updating provisioning profile...")

        embedded_profile = app_bundle / "embedded.mobileprovision"

        # Copy new provisioning profile
        shutil.copy2(self.provisioning_profile, embedded_profile)

        context.logger.success(f"Updated provisioning profile: {self.provisioning_profile.name}")

    def _sign_frameworks(self, context: ShieldContext, app_bundle: Path) -> None:
        """Sign embedded frameworks (inside-out signing)

        Frameworks must be signed before the main app bundle.
        """
        frameworks_dir = app_bundle / "Frameworks"

        if not frameworks_dir.exists():
            context.logger.info("No frameworks to sign")
            return

        frameworks = list(frameworks_dir.glob("*.framework"))

        if not frameworks:
            context.logger.info("No frameworks found")
            return

        context.logger.info(f"Signing {len(frameworks)} framework(s)...")

        for framework in frameworks:
            framework_name = framework.name

            # Find framework binary (same name as framework, without .framework)
            binary_name = framework.stem
            framework_binary = framework / binary_name

            if not framework_binary.exists():
                context.logger.warning(f"Framework binary not found: {framework_name}/{binary_name}")
                continue

            # Sign framework
            self._sign_binary(
                context,
                framework_binary,
                f"Framework: {framework_name}"
            )

    def _sign_plugins(self, context: ShieldContext, app_bundle: Path) -> None:
        """Sign embedded plugins/extensions

        Plugins must be signed before the main app bundle.
        """
        plugins_dir = app_bundle / "PlugIns"

        if not plugins_dir.exists():
            context.logger.info("No plugins to sign")
            return

        plugins = list(plugins_dir.glob("*.appex"))

        if not plugins:
            context.logger.info("No plugins found")
            return

        context.logger.info(f"Signing {len(plugins)} plugin(s)...")

        for plugin in plugins:
            plugin_name = plugin.name

            # Sign entire plugin bundle
            self._sign_bundle(
                context,
                plugin,
                f"Plugin: {plugin_name}"
            )

    def _sign_app_bundle(self, context: ShieldContext, app_bundle: Path) -> None:
        """Sign main app bundle"""
        context.logger.info("Signing main app bundle...")

        self._sign_bundle(
            context,
            app_bundle,
            f"App: {app_bundle.name}"
        )

    def _sign_binary(self, context: ShieldContext, binary_path: Path, label: str) -> None:
        """Sign a single binary file"""

        cmd = [
            'codesign',
            '--force',
            '--sign', self.signing_identity,
            '--timestamp',
        ]

        # Add entitlements if available
        if self.entitlements_file and self.entitlements_file.exists():
            cmd.extend(['--entitlements', str(self.entitlements_file)])

        cmd.append(str(binary_path))

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=60
            )

            if result.returncode == 0:
                context.logger.success(f"✓ Signed: {label}")
            else:
                context.logger.error(f"✗ Failed to sign {label}")
                context.logger.error(f"  Error: {result.stderr.strip()}")
                raise RuntimeError(f"Failed to sign {label}")

        except subprocess.TimeoutExpired:
            raise RuntimeError(f"Signing timeout for {label}")
        except Exception as e:
            raise RuntimeError(f"Failed to sign {label}: {e}")

    def _sign_bundle(self, context: ShieldContext, bundle_path: Path, label: str) -> None:
        """Sign an app bundle or framework"""

        cmd = [
            'codesign',
            '--force',
            '--sign', self.signing_identity,
            '--timestamp',
            '--deep',  # Sign nested code
        ]

        # Add entitlements if available
        if self.entitlements_file and self.entitlements_file.exists():
            cmd.extend(['--entitlements', str(self.entitlements_file)])

        cmd.append(str(bundle_path))

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=120
            )

            if result.returncode == 0:
                context.logger.success(f"✓ Signed: {label}")
            else:
                context.logger.error(f"✗ Failed to sign {label}")
                context.logger.error(f"  Error: {result.stderr.strip()}")
                raise RuntimeError(f"Failed to sign {label}")

        except subprocess.TimeoutExpired:
            raise RuntimeError(f"Signing timeout for {label}")
        except Exception as e:
            raise RuntimeError(f"Failed to sign {label}: {e}")

    def _verify_signature(self, context: ShieldContext, app_bundle: Path) -> None:
        """Verify code signature"""
        context.logger.info("Verifying signature...")

        try:
            # Verify signature
            result = subprocess.run(
                ['codesign', '--verify', '--verbose=2', str(app_bundle)],
                capture_output=True,
                text=True,
                timeout=30
            )

            if result.returncode == 0:
                context.logger.success("✓ Signature valid")
            else:
                context.logger.error("✗ Signature verification failed")
                context.logger.error(f"  Error: {result.stderr.strip()}")
                raise RuntimeError("Signature verification failed")

            # Display signature info
            result = subprocess.run(
                ['codesign', '--display', '--verbose=2', str(app_bundle)],
                capture_output=True,
                text=True,
                timeout=30
            )

            if result.returncode == 0:
                context.logger.info("Signature info:")
                for line in result.stderr.split('\n'):
                    if line.strip():
                        context.logger.info(f"  {line.strip()}")

        except Exception as e:
            context.logger.warning(f"Failed to verify signature: {e}")

    def get_metadata(self) -> dict:
        """Return metadata about this protection stage"""
        return {
            'name': self.name,
            'description': self.description,
            'type': 'packaging',
            'modifies_binary': False,
            'app_store_safe': True,
            'requires_macos': True,
            'capabilities': [
                'Old signature removal',
                'Entitlements extraction',
                'Provisioning profile update',
                'Framework signing (inside-out)',
                'Plugin/extension signing',
                'App bundle signing',
                'Signature verification',
            ],
            'requirements': [
                'macOS (Darwin)',
                'codesign tool (Xcode Command Line Tools)',
                'Valid signing certificate',
                'Provisioning profile (optional)',
            ],
        }
