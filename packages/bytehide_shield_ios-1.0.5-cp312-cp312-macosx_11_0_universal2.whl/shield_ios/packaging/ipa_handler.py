#!/usr/bin/env python3
"""Shield iOS - IPA Packer/Unpacker

Handles unpacking, processing, and repacking of iOS IPA files.

IPA Structure:
    MyApp.ipa (ZIP archive)
    └── Payload/
        └── MyApp.app/
            ├── MyApp (Mach-O binary - THIS IS WHAT WE PROTECT)
            ├── Info.plist
            ├── Assets.car
            ├── embedded.mobileprovision
            ├── _CodeSignature/
            ├── Frameworks/
            ├── PlugIns/
            └── ... other resources

Workflow:
    1. Unpack IPA → Extract to temp directory
    2. Locate Mach-O binary (Payload/MyApp.app/MyApp)
    3. Apply protections to binary
    4. Repack IPA with protected binary
    5. Output protected IPA

Author: ByteHide Shield iOS
"""

import os
import shutil
import zipfile
import tempfile
from pathlib import Path
from typing import Optional
import plistlib

from shield_ios.core.pipeline import ProtectionStage
from shield_ios.core.context import ShieldContext


class IpaPackerStage(ProtectionStage):
    """IPA Packer/Unpacker protection stage

    This stage handles:
    - Unpacking IPA files (unzip)
    - Extracting app bundle and binary
    - Preserving app structure
    - Repacking IPA after protections applied
    - Maintaining Info.plist and resources

    SAFE: Pure Python, no binary modification (that's done by other protections)
    """

    def __init__(self):
        super().__init__(name="IPA Packer/Unpacker")
        self.temp_dir: Optional[Path] = None
        self.app_bundle_path: Optional[Path] = None
        self.binary_path: Optional[Path] = None
        self.app_name: Optional[str] = None

    def pre_execute(self, context: ShieldContext) -> None:
        """Validate input IPA file exists"""
        input_ipa = context.input_file

        if not input_ipa.exists():
            raise FileNotFoundError(f"Input IPA not found: {input_ipa}")

        if not input_ipa.suffix == '.ipa':
            raise ValueError(f"Input must be .ipa file, got: {input_ipa.suffix}")

        # Verify it's a valid ZIP file
        if not zipfile.is_zipfile(input_ipa):
            raise ValueError(f"Input IPA is not a valid ZIP archive: {input_ipa}")

        context.logger.info(f"Input IPA validated: {input_ipa.name} ({input_ipa.stat().st_size / (1024*1024):.2f} MB)")

    def execute(self, context: ShieldContext) -> None:
        """Unpack IPA and prepare for protection"""
        context.logger.section("IPA Unpacker")

        # Create temporary directory for extraction
        self.temp_dir = Path(tempfile.mkdtemp(prefix='shield_ios_'))
        context.logger.info(f"Created temp directory: {self.temp_dir}")

        # Unpack IPA
        self._unpack_ipa(context)

        # Locate app bundle and binary
        self._locate_app_bundle(context)

        # Parse Info.plist for app information
        self._parse_app_info(context)

        # Store paths in context for other protections
        context.working_directory = self.temp_dir
        context.app_bundle_path = self.app_bundle_path
        context.binary_path = self.binary_path
        context.app_name = self.app_name

        context.logger.success("IPA unpacked successfully")
        context.logger.info(f"App bundle: {self.app_bundle_path}")
        context.logger.info(f"Binary: {self.binary_path}")
        context.logger.info(f"App name: {self.app_name}")

    def post_execute(self, context: ShieldContext) -> None:
        """Repack IPA after all protections applied"""
        context.logger.section("IPA Repacker")

        # Repack IPA
        output_ipa = self._repack_ipa(context)

        context.logger.success("IPA repacked successfully")
        context.logger.info(f"Output IPA: {output_ipa}")
        context.logger.info(f"Size: {output_ipa.stat().st_size / (1024*1024):.2f} MB")

        # Cleanup temp directory
        if self.temp_dir and self.temp_dir.exists():
            shutil.rmtree(self.temp_dir)
            context.logger.info("Cleaned up temporary files")

    def _unpack_ipa(self, context: ShieldContext) -> None:
        """Unpack IPA file to temporary directory

        IPA is just a ZIP archive, so we use zipfile to extract it.
        """
        input_ipa = context.input_file

        context.logger.info(f"Unpacking IPA: {input_ipa.name}")

        try:
            with zipfile.ZipFile(input_ipa, 'r') as zip_ref:
                # Get list of files
                file_count = len(zip_ref.namelist())
                context.logger.info(f"Extracting {file_count} files...")

                # Extract all files
                zip_ref.extractall(self.temp_dir)

                context.logger.success(f"Extracted {file_count} files")

        except zipfile.BadZipFile:
            raise ValueError(f"Invalid IPA file (corrupt ZIP): {input_ipa}")
        except Exception as e:
            raise RuntimeError(f"Failed to unpack IPA: {e}")

    def _locate_app_bundle(self, context: ShieldContext) -> None:
        """Locate the .app bundle and Mach-O binary

        IPA structure:
            Payload/
                MyApp.app/  <- This is the app bundle
                    MyApp   <- This is the Mach-O binary
        """
        context.logger.info("Locating app bundle...")

        # Find Payload directory
        payload_dir = self.temp_dir / "Payload"
        if not payload_dir.exists():
            raise FileNotFoundError("Payload directory not found in IPA")

        # Find .app bundle (should be only one)
        app_bundles = list(payload_dir.glob("*.app"))

        if len(app_bundles) == 0:
            raise FileNotFoundError("No .app bundle found in Payload/")

        if len(app_bundles) > 1:
            context.logger.warning(f"Multiple .app bundles found, using first: {app_bundles[0].name}")

        self.app_bundle_path = app_bundles[0]
        self.app_name = self.app_bundle_path.stem

        context.logger.info(f"Found app bundle: {self.app_bundle_path.name}")

        # Locate Mach-O binary (same name as .app bundle, but without extension)
        binary_path = self.app_bundle_path / self.app_name

        if not binary_path.exists():
            raise FileNotFoundError(f"Mach-O binary not found: {binary_path}")

        # Verify it's a binary file (not a text file)
        with open(binary_path, 'rb') as f:
            magic = f.read(4)

            # Mach-O magic numbers
            # 0xFEEDFACE = MH_MAGIC (32-bit)
            # 0xFEEDFACF = MH_MAGIC_64 (64-bit)
            # 0xCAFEBABE = FAT_MAGIC (universal binary)
            # 0xBEBAFECA = FAT_MAGIC_REVERSE
            valid_magics = [
                b'\xfe\xed\xfa\xce',  # MH_MAGIC
                b'\xfe\xed\xfa\xcf',  # MH_MAGIC_64
                b'\xcf\xfa\xed\xfe',  # MH_MAGIC_64 (reversed)
                b'\xca\xfe\xba\xbe',  # FAT_MAGIC
                b'\xbe\xba\xfe\xca',  # FAT_MAGIC_REVERSE
            ]

            if magic not in valid_magics:
                raise ValueError(f"Binary is not a valid Mach-O file (magic: {magic.hex()})")

        self.binary_path = binary_path
        context.logger.success(f"Found Mach-O binary: {self.app_name}")

    def _parse_app_info(self, context: ShieldContext) -> None:
        """Parse Info.plist to get app information"""
        info_plist_path = self.app_bundle_path / "Info.plist"

        if not info_plist_path.exists():
            context.logger.warning("Info.plist not found in app bundle")
            return

        try:
            with open(info_plist_path, 'rb') as f:
                plist = plistlib.load(f)

            # Extract useful information
            bundle_id = plist.get('CFBundleIdentifier', 'unknown')
            bundle_name = plist.get('CFBundleName', self.app_name)
            bundle_version = plist.get('CFBundleShortVersionString', 'unknown')
            bundle_build = plist.get('CFBundleVersion', 'unknown')
            min_ios = plist.get('MinimumOSVersion', 'unknown')

            context.logger.info(f"Bundle ID: {bundle_id}")
            context.logger.info(f"Bundle Name: {bundle_name}")
            context.logger.info(f"Version: {bundle_version} (build {bundle_build})")
            context.logger.info(f"Minimum iOS: {min_ios}")

            # Store in context
            context.bundle_id = bundle_id
            context.bundle_version = bundle_version
            context.min_ios_version = min_ios

        except Exception as e:
            context.logger.warning(f"Failed to parse Info.plist: {e}")

    def _repack_ipa(self, context: ShieldContext) -> Path:
        """Repack the IPA file with protected binary

        Creates a new ZIP archive with all the files from the unpacked IPA.
        Preserves directory structure and file permissions.
        """
        # Determine output path
        if context.output_file:
            output_ipa = context.output_file
        else:
            # Default: input_protected.ipa
            input_stem = context.input_file.stem
            output_ipa = context.input_file.parent / f"{input_stem}_protected.ipa"

        context.logger.info(f"Repacking IPA: {output_ipa.name}")

        # Get working directory from context or fall back to instance variable
        working_dir = context.working_directory if context.working_directory else self.temp_dir

        if not working_dir:
            raise RuntimeError("No working directory available for repacking")

        context.logger.debug(f"Working directory: {working_dir}")
        context.logger.debug(f"Working directory exists: {working_dir.exists() if working_dir else False}")

        if working_dir and working_dir.exists():
            # List contents for debugging
            all_files = list(working_dir.rglob("*"))
            context.logger.debug(f"Total files in working dir: {len(all_files)}")

        try:
            # Create ZIP archive
            with zipfile.ZipFile(output_ipa, 'w', zipfile.ZIP_DEFLATED) as zip_ref:
                # Walk through temp directory and add all files
                file_count = 0

                for root, dirs, files in os.walk(working_dir):
                    context.logger.debug(f"Walking: {root}, dirs: {len(dirs)}, files: {len(files)}")
                    for file in files:
                        file_path = Path(root) / file

                        # Calculate archive name (relative to working_dir)
                        arcname = file_path.relative_to(working_dir)

                        context.logger.debug(f"  Adding: {arcname}")

                        # Add to ZIP
                        zip_ref.write(file_path, arcname)
                        file_count += 1

                context.logger.success(f"Packed {file_count} files into IPA")

        except Exception as e:
            raise RuntimeError(f"Failed to repack IPA: {e}")

        return output_ipa

    def cleanup(self, context: ShieldContext) -> None:
        """Cleanup temporary files if needed"""
        if self.temp_dir and self.temp_dir.exists():
            try:
                shutil.rmtree(self.temp_dir)
                context.logger.info("Cleaned up temporary files")
            except Exception as e:
                context.logger.warning(f"Failed to cleanup temp directory: {e}")

    def get_metadata(self) -> dict:
        """Return metadata about this protection stage"""
        return {
            'name': self.name,
            'description': self.description,
            'type': 'packaging',
            'modifies_binary': False,
            'app_store_safe': True,
            'requires_macos': False,
            'capabilities': [
                'IPA unpacking (unzip)',
                'App bundle extraction',
                'Mach-O binary location',
                'Info.plist parsing',
                'IPA repacking (zip)',
                'Structure preservation',
            ],
            'supported_formats': ['.ipa'],
        }
