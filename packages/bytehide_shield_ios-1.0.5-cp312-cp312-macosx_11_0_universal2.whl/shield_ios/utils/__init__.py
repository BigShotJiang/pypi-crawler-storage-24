"""Shield iOS Utilities - Helper functions"""

__all__ = []
