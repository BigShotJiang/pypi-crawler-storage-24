"""Shield iOS - Resource Encryption Protection"""

from shield_ios.protections.resource_encryption.resource_encryption_protection import ResourceEncryptionStage

__all__ = ['ResourceEncryptionStage']
