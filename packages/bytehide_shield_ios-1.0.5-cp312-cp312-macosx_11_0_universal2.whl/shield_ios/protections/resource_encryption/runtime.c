/*
 * Shield iOS - Resource Encryption Runtime Decryptor
 *
 * This runtime code is injected into the iOS binary to transparently
 * decrypt encrypted resources (Assets.car, plists, storyboards, nibs)
 * at runtime.
 *
 * WHAT IT DOES:
 * - Hooks resource loading methods (NSData, UIImage, etc.)
 * - Detects encrypted resources
 * - Decrypts using AES-256-CBC
 * - Returns decrypted data to app
 * - Transparent to application code
 *
 * THREAD SAFETY:
 * - Uses pthread mutexes for thread-safe decryption
 * - Safe for multi-threaded apps
 *
 * Author: ByteHide Shield iOS
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#import <Foundation/Foundation.h>
#include <objc/runtime.h>
#include <objc/message.h>
#include <CommonCrypto/CommonCryptor.h>

// Include generated config with key and IV
#include "shield_config.h"

// ============================================================================
// GLOBAL STATE
// ============================================================================

static pthread_mutex_t shield_resource_mutex = PTHREAD_MUTEX_INITIALIZER;
static int shield_resource_initialized = 0;

// ============================================================================
// AES DECRYPTION
// ============================================================================

/**
 * Decrypt data using AES-256-CBC
 *
 * @param encrypted_data Encrypted data
 * @param encrypted_size Size of encrypted data
 * @param decrypted_data Output buffer for decrypted data (caller must free)
 * @param decrypted_size Output size of decrypted data
 * @return 0 on success, -1 on failure
 */
static int shield_aes_decrypt(
    const unsigned char* encrypted_data,
    size_t encrypted_size,
    unsigned char** decrypted_data,
    size_t* decrypted_size
) {
    if (!encrypted_data || encrypted_size == 0) {
        return -1;
    }

    // Allocate buffer for decrypted data
    // AES block size is 16 bytes, decrypted size will be <= encrypted size
    unsigned char* buffer = malloc(encrypted_size);
    if (!buffer) {
        return -1;
    }

    size_t moved_bytes = 0;

    // Perform AES-256-CBC decryption
    CCCryptorStatus status = CCCrypt(
        kCCDecrypt,                     // Operation
        kCCAlgorithmAES,                // Algorithm
        kCCOptionPKCS7Padding,          // Options (PKCS7 padding)
        SHIELD_RESOURCE_KEY,            // Key
        SHIELD_RESOURCE_KEY_SIZE,       // Key length
        SHIELD_RESOURCE_IV,             // IV
        encrypted_data,                 // Input
        encrypted_size,                 // Input length
        buffer,                         // Output
        encrypted_size,                 // Output buffer size
        &moved_bytes                    // Bytes written
    );

    if (status != kCCSuccess) {
        free(buffer);
        return -1;
    }

    *decrypted_data = buffer;
    *decrypted_size = moved_bytes;

    return 0;
}

// ============================================================================
// RESOURCE DETECTION
// ============================================================================

/**
 * Check if a file path is an encrypted resource
 *
 * Encrypted resources include:
 * - Assets.car
 * - *.plist files
 * - *.storyboardc directories
 * - *.nib files
 *
 * @param path File path
 * @return 1 if encrypted resource, 0 otherwise
 */
static int shield_is_encrypted_resource(const char* path) {
    if (!path) {
        return 0;
    }

    // Check for Assets.car
    if (strstr(path, "Assets.car")) {
        return 1;
    }

    // Check for .plist
    if (strstr(path, ".plist")) {
        return 1;
    }

    // Check for .storyboardc
    if (strstr(path, ".storyboardc")) {
        return 1;
    }

    // Check for .nib
    if (strstr(path, ".nib")) {
        return 1;
    }

    return 0;
}

// ============================================================================
// NSDATA HOOK
// ============================================================================

// Store original NSData dataWithContentsOfFile: method
static id (*original_dataWithContentsOfFile)(id, SEL, id) = NULL;

/**
 * Hooked NSData dataWithContentsOfFile:
 *
 * Intercepts file loading, decrypts if encrypted resource
 */
static id hooked_dataWithContentsOfFile(id self, SEL _cmd, id path) {
    // Get path as C string
    const char* path_cstr = [path UTF8String];

    // Check if this is an encrypted resource
    if (shield_is_encrypted_resource(path_cstr)) {
        // Load encrypted data using original method
        id encrypted_data = original_dataWithContentsOfFile(self, _cmd, path);

        if (!encrypted_data) {
            return nil;
        }

        // Get encrypted bytes
        const unsigned char* encrypted_bytes = [encrypted_data bytes];
        size_t encrypted_size = [encrypted_data length];

        // Decrypt
        unsigned char* decrypted_bytes = NULL;
        size_t decrypted_size = 0;

        pthread_mutex_lock(&shield_resource_mutex);
        int result = shield_aes_decrypt(
            encrypted_bytes,
            encrypted_size,
            &decrypted_bytes,
            &decrypted_size
        );
        pthread_mutex_unlock(&shield_resource_mutex);

        if (result != 0 || !decrypted_bytes) {
            // Decryption failed, return original data
            return encrypted_data;
        }

        // Create NSData from decrypted bytes
        id decrypted_data = [[NSData alloc] initWithBytes:decrypted_bytes length:decrypted_size];

        // Free decrypted buffer
        free(decrypted_bytes);

        return decrypted_data;
    }

    // Not encrypted, use original method
    return original_dataWithContentsOfFile(self, _cmd, path);
}

// ============================================================================
// NSDATA INIT HOOK
// ============================================================================

// Store original NSData initWithContentsOfFile: method
static id (*original_initWithContentsOfFile)(id, SEL, id) = NULL;

/**
 * Hooked NSData initWithContentsOfFile:
 *
 * Intercepts file loading, decrypts if encrypted resource
 */
static id hooked_initWithContentsOfFile(id self, SEL _cmd, id path) {
    // Get path as C string
    const char* path_cstr = [path UTF8String];

    // Check if this is an encrypted resource
    if (shield_is_encrypted_resource(path_cstr)) {
        // Load encrypted data using original method
        id encrypted_data = original_initWithContentsOfFile(self, _cmd, path);

        if (!encrypted_data) {
            return nil;
        }

        // Get encrypted bytes
        const unsigned char* encrypted_bytes = [encrypted_data bytes];
        size_t encrypted_size = [encrypted_data length];

        // Decrypt
        unsigned char* decrypted_bytes = NULL;
        size_t decrypted_size = 0;

        pthread_mutex_lock(&shield_resource_mutex);
        int result = shield_aes_decrypt(
            encrypted_bytes,
            encrypted_size,
            &decrypted_bytes,
            &decrypted_size
        );
        pthread_mutex_unlock(&shield_resource_mutex);

        if (result != 0 || !decrypted_bytes) {
            // Decryption failed, return original data
            return encrypted_data;
        }

        // Create NSData from decrypted bytes
        id decrypted_data = [[NSData alloc] initWithBytes:decrypted_bytes length:decrypted_size];

        // Free decrypted buffer
        free(decrypted_bytes);

        return decrypted_data;
    }

    // Not encrypted, use original method
    return original_initWithContentsOfFile(self, _cmd, path);
}

// ============================================================================
// METHOD SWIZZLING
// ============================================================================

/**
 * Swizzle a method
 *
 * @param class_name Class name
 * @param selector_name Selector name
 * @param new_implementation New implementation
 * @param original_implementation Pointer to store original implementation
 */
static void shield_swizzle_method(
    const char* class_name,
    const char* selector_name,
    IMP new_implementation,
    IMP* original_implementation
) {
    Class class = objc_getClass(class_name);
    if (!class) {
        return;
    }

    SEL selector = sel_registerName(selector_name);
    if (!selector) {
        return;
    }

    Method original_method = class_getClassMethod(class, selector);
    if (!original_method) {
        // Try instance method
        original_method = class_getInstanceMethod(class, selector);
    }

    if (!original_method) {
        return;
    }

    // Store original implementation
    *original_implementation = method_getImplementation(original_method);

    // Replace with new implementation
    method_setImplementation(original_method, new_implementation);
}

// ============================================================================
// INITIALIZATION
// ============================================================================

/**
 * Initialize resource encryption runtime
 */
static void shield_resource_encryption_init(void) {
    pthread_mutex_lock(&shield_resource_mutex);

    if (shield_resource_initialized) {
        pthread_mutex_unlock(&shield_resource_mutex);
        return;
    }

    // Swizzle NSData dataWithContentsOfFile:
    shield_swizzle_method(
        "NSData",
        "dataWithContentsOfFile:",
        (IMP)hooked_dataWithContentsOfFile,
        (IMP*)&original_dataWithContentsOfFile
    );

    // Swizzle NSData initWithContentsOfFile:
    shield_swizzle_method(
        "NSData",
        "initWithContentsOfFile:",
        (IMP)hooked_initWithContentsOfFile,
        (IMP*)&original_initWithContentsOfFile
    );

    shield_resource_initialized = 1;

    pthread_mutex_unlock(&shield_resource_mutex);
}

/**
 * Cleanup resource encryption runtime
 */
static void shield_resource_encryption_cleanup(void) {
    pthread_mutex_lock(&shield_resource_mutex);

    // Restore original methods if needed
    if (original_dataWithContentsOfFile) {
        shield_swizzle_method(
            "NSData",
            "dataWithContentsOfFile:",
            (IMP)original_dataWithContentsOfFile,
            (IMP*)&original_dataWithContentsOfFile
        );
    }

    if (original_initWithContentsOfFile) {
        shield_swizzle_method(
            "NSData",
            "initWithContentsOfFile:",
            (IMP)original_initWithContentsOfFile,
            (IMP*)&original_initWithContentsOfFile
        );
    }

    shield_resource_initialized = 0;

    pthread_mutex_unlock(&shield_resource_mutex);
}

// ============================================================================
// CONSTRUCTOR/DESTRUCTOR
// ============================================================================

/**
 * Constructor - called when library is loaded
 */
__attribute__((constructor))
static void shield_resource_encryption_load(void) {
    shield_resource_encryption_init();
}

/**
 * Destructor - called when library is unloaded
 */
__attribute__((destructor))
static void shield_resource_encryption_unload(void) {
    shield_resource_encryption_cleanup();
}
