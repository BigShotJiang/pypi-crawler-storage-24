"""Shield iOS Renamer Protection
Symbol renaming with framework-aware safety
"""

from shield_ios.protections.renamer.renamer_protection import RenamerStage

__all__ = ['RenamerStage']
