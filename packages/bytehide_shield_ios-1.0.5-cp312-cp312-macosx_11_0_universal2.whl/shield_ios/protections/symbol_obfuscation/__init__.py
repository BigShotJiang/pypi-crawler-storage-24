#!/usr/bin/env python3
"""Shield iOS - Symbol Obfuscation Protection

Obfuscates all user-defined symbols (classes, methods, properties) to make
reverse engineering significantly harder.
"""

from .symbol_obfuscator import SymbolObfuscationProtection

__all__ = ['SymbolObfuscationProtection']
