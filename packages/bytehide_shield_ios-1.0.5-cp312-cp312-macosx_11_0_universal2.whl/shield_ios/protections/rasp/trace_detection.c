/*
 * Shield iOS - Code Tracing Detection
 *
 * Detects code tracing and debugging:
 * - Debuggers (lldb, gdb)
 * - DTrace
 * - Binary instrumentation
 * - Breakpoints
 *
 * TECHNIQUES:
 * 1. ptrace PT_DENY_ATTACH (prevents debugger attach)
 * 2. sysctl P_TRACED flag check
 * 3. Exception port checking
 * 4. Parent process inspection
 * 5. Breakpoint detection (INT3/0xCC scanning)
 * 6. Timing attacks (debugger slows execution)
 * 7. Code integrity checking
 *
 * Author: ByteHide Shield iOS
 */

#include "rasp_common.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/sysctl.h>
#include <sys/ptrace.h>
#include <mach/mach.h>
#include <mach/mach_time.h>
#include <dlfcn.h>

// ============================================================================
// DEBUGGER DETECTION
// ============================================================================

/**
 * Deny debugger attach using ptrace
 *
 * This is a preventive measure - once called, debuggers cannot attach
 */
void shield_deny_debugger_attach(void) {
    // PT_DENY_ATTACH is not defined in public headers on iOS
    // but the value is 31
    #define PT_DENY_ATTACH 31

    ptrace(PT_DENY_ATTACH, 0, 0, 0);
}

/**
 * Check if debugger is attached using sysctl
 *
 * Checks the P_TRACED flag in process info
 */
static bool shield_detect_debugger_sysctl(void) {
    int mib[4];
    struct kinfo_proc info;
    size_t size = sizeof(info);

    // Initialize mib
    mib[0] = CTL_KERN;
    mib[1] = KERN_PROC;
    mib[2] = KERN_PROC_PID;
    mib[3] = getpid();

    // Get process info
    if (sysctl(mib, 4, &info, &size, NULL, 0) != 0) {
        return false;
    }

    // Check P_TRACED flag (0x00000800)
    return ((info.kp_proc.p_flag & 0x00000800) != 0);
}

/**
 * Check exception ports for debugger
 *
 * Debuggers install exception handlers on the task
 */
static bool shield_detect_debugger_exception_ports(void) {
    exception_mask_t masks[EXC_TYPES_COUNT];
    mach_port_t ports[EXC_TYPES_COUNT];
    exception_behavior_t behaviors[EXC_TYPES_COUNT];
    thread_state_flavor_t flavors[EXC_TYPES_COUNT];
    mach_msg_type_number_t count = 0;

    kern_return_t kr = task_get_exception_ports(
        mach_task_self(),
        EXC_MASK_ALL,
        masks,
        &count,
        ports,
        behaviors,
        flavors
    );

    if (kr != KERN_SUCCESS) {
        return false;
    }

    // If there are exception ports set, might be debugger
    // In normal execution, count should be 0 or very low
    if (count > 2) {
        return true;
    }

    return false;
}

/**
 * Check parent process name
 *
 * If parent is lldb, debugserver, gdb, etc., we're being debugged
 */
static bool shield_detect_debugger_parent_process(void) {
    pid_t parent_pid = getppid();

    int mib[4];
    struct kinfo_proc info;
    size_t size = sizeof(info);

    mib[0] = CTL_KERN;
    mib[1] = KERN_PROC;
    mib[2] = KERN_PROC_PID;
    mib[3] = parent_pid;

    if (sysctl(mib, 4, &info, &size, NULL, 0) != 0) {
        return false;
    }

    // Check parent process name
    const char* process_name = info.kp_proc.p_comm;

    const char* debugger_names[] = {
        "lldb",
        "debugserver",
        "gdb",
        "lldb-rpc-server",
        NULL
    };

    for (int i = 0; debugger_names[i] != NULL; i++) {
        if (strstr(process_name, debugger_names[i]) != NULL) {
            return true;
        }
    }

    return false;
}

/**
 * Main debugger detection
 */
bool shield_detect_debugger(rasp_detection_result_t* result) {
    result->threat_type = RASP_THREAT_DEBUGGER;
    result->threat_level = RASP_LEVEL_NONE;
    result->detected = false;
    result->details[0] = '\0';

    // Check sysctl P_TRACED
    if (shield_detect_debugger_sysctl()) {
        result->detected = true;
        result->threat_level = RASP_LEVEL_CRITICAL;
        snprintf(result->details, sizeof(result->details),
                "Debugger attached (P_TRACED flag set)");
        return true;
    }

    // Check exception ports
    if (shield_detect_debugger_exception_ports()) {
        result->detected = true;
        result->threat_level = RASP_LEVEL_HIGH;
        snprintf(result->details, sizeof(result->details),
                "Suspicious exception ports (possible debugger)");
        return true;
    }

    // Check parent process
    if (shield_detect_debugger_parent_process()) {
        result->detected = true;
        result->threat_level = RASP_LEVEL_CRITICAL;
        snprintf(result->details, sizeof(result->details),
                "Debugger detected as parent process");
        return true;
    }

    return false;
}

// ============================================================================
// DTRACE DETECTION
// ============================================================================

/**
 * Check if dtrace is running
 *
 * Enumerates all processes looking for dtrace
 */
static bool shield_detect_dtrace_process(void) {
    int mib[4];
    size_t size;

    // Get size needed
    mib[0] = CTL_KERN;
    mib[1] = KERN_PROC;
    mib[2] = KERN_PROC_ALL;
    mib[3] = 0;

    if (sysctl(mib, 4, NULL, &size, NULL, 0) != 0) {
        return false;
    }

    struct kinfo_proc* processes = malloc(size);
    if (!processes) {
        return false;
    }

    if (sysctl(mib, 4, processes, &size, NULL, 0) != 0) {
        free(processes);
        return false;
    }

    int process_count = size / sizeof(struct kinfo_proc);
    bool detected = false;

    for (int i = 0; i < process_count; i++) {
        const char* name = processes[i].kp_proc.p_comm;
        if (strstr(name, "dtrace") != NULL) {
            detected = true;
            break;
        }
    }

    free(processes);
    return detected;
}

/**
 * Main DTrace detection
 */
bool shield_detect_dtrace(rasp_detection_result_t* result) {
    result->threat_type = RASP_THREAT_DTRACE;
    result->threat_level = RASP_LEVEL_NONE;
    result->detected = false;
    result->details[0] = '\0';

    if (shield_detect_dtrace_process()) {
        result->detected = true;
        result->threat_level = RASP_LEVEL_HIGH;
        snprintf(result->details, sizeof(result->details),
                "DTrace process detected");
        return true;
    }

    return false;
}

// ============================================================================
// BINARY INSTRUMENTATION DETECTION
// ============================================================================

/**
 * Detect INT3 breakpoints in code
 *
 * Scans text section for 0xCC (INT3) instructions
 */
static bool shield_detect_breakpoints(void) {
    // Get address of current function
    Dl_info info;
    if (dladdr((void*)shield_detect_breakpoints, &info) == 0) {
        return false;
    }

    // Scan some bytes around current function for INT3 (0xCC on x86, different on ARM)
    const unsigned char* code = (const unsigned char*)info.dli_saddr;
    size_t scan_size = 1024;  // Scan 1KB

    #if defined(__arm64__) || defined(__aarch64__)
    // ARM64: Look for BRK instruction (0xD4200000)
    for (size_t i = 0; i < scan_size - 3; i += 4) {
        uint32_t instruction = *(uint32_t*)(code + i);
        // BRK #0 is 0xD4200000
        if ((instruction & 0xFFE0001F) == 0xD4200000) {
            return true;
        }
    }
    #else
    // x86/x86_64: Look for INT3 (0xCC)
    for (size_t i = 0; i < scan_size; i++) {
        if (code[i] == 0xCC) {
            return true;
        }
    }
    #endif

    return false;
}

/**
 * Timing attack to detect debugger
 *
 * Debuggers significantly slow down execution
 */
static bool shield_detect_timing_anomaly(void) {
    uint64_t start = mach_absolute_time();

    // Do some work
    volatile int sum = 0;
    for (int i = 0; i < 1000; i++) {
        sum += i;
    }

    uint64_t end = mach_absolute_time();
    uint64_t elapsed = end - start;

    // Get timebase info to convert to nanoseconds
    mach_timebase_info_data_t timebase;
    mach_timebase_info(&timebase);

    uint64_t elapsed_ns = elapsed * timebase.numer / timebase.denom;

    // If this simple loop took more than 1ms, something is wrong
    // (normal execution should be << 1ms)
    if (elapsed_ns > 1000000) {  // 1ms
        return true;
    }

    return false;
}

/**
 * Main instrumentation detection
 */
bool shield_detect_instrumentation(rasp_detection_result_t* result) {
    result->threat_type = RASP_THREAT_INSTRUMENTATION;
    result->threat_level = RASP_LEVEL_NONE;
    result->detected = false;
    result->details[0] = '\0';

    // Check for breakpoints
    if (shield_detect_breakpoints()) {
        result->detected = true;
        result->threat_level = RASP_LEVEL_CRITICAL;
        snprintf(result->details, sizeof(result->details),
                "Breakpoint detected in code");
        return true;
    }

    // Check timing
    if (shield_detect_timing_anomaly()) {
        result->detected = true;
        result->threat_level = RASP_LEVEL_MEDIUM;
        snprintf(result->details, sizeof(result->details),
                "Timing anomaly detected (possible debugger)");
        return true;
    }

    return false;
}

// ============================================================================
// COMPREHENSIVE TRACING DETECTION
// ============================================================================

/**
 * Run all tracing detection checks
 *
 * @param config RASP configuration
 * @param result Detection result (out parameter)
 * @return true if tracing detected
 */
bool shield_detect_tracing(const rasp_config_t* config, rasp_detection_result_t* result) {
    // Deny debugger attach (preventive)
    shield_deny_debugger_attach();

    // Check debugger
    if (config->enable_debugger_detection) {
        if (shield_detect_debugger(result)) {
            return true;
        }
    }

    // Check DTrace
    if (config->enable_dtrace_detection) {
        if (shield_detect_dtrace(result)) {
            return true;
        }
    }

    // Check instrumentation
    if (config->enable_instrumentation_detection) {
        if (shield_detect_instrumentation(result)) {
            return true;
        }
    }

    return false;
}
