/*
 * Shield iOS - RASP Runtime
 *
 * Main RASP (Runtime Application Self-Protection) implementation
 *
 * Integrates:
 * - Hook Detection (Frida, Cycript, Substrate)
 * - Trace Detection (Debuggers, DTrace, Instrumentation)
 * - Tamper Detection (Signature, Hash, Repackaging)
 *
 * ARCHITECTURE:
 * - Distributed checks (not centralized)
 * - Polymorphic (different each build)
 * - Callback-based (app can handle threats)
 * - Thread-safe
 *
 * Author: ByteHide Shield iOS
 */

#include "rasp_common.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>

// External detection functions
extern bool shield_detect_hooks(const rasp_config_t* config, rasp_detection_result_t* result);
extern bool shield_detect_tracing(const rasp_config_t* config, rasp_detection_result_t* result);
extern bool shield_detect_tampering(const rasp_config_t* config, rasp_detection_result_t* result);

// ============================================================================
// GLOBAL STATE
// ============================================================================

static rasp_state_t g_rasp_state = {
    .initialized = false,
    .check_count = 0,
    .threat_count = 0,
};

static pthread_mutex_t g_rasp_mutex = PTHREAD_MUTEX_INITIALIZER;

// ============================================================================
// INITIALIZATION
// ============================================================================

/**
 * Initialize RASP with configuration
 *
 * @param config RASP configuration
 */
void shield_rasp_init(const rasp_config_t* config) {
    pthread_mutex_lock(&g_rasp_mutex);

    if (g_rasp_state.initialized) {
        pthread_mutex_unlock(&g_rasp_mutex);
        return;
    }

    // Copy configuration
    if (config) {
        memcpy(&g_rasp_state.config, config, sizeof(rasp_config_t));
    } else {
        // Default configuration
        g_rasp_state.config.enable_frida_detection = true;
        g_rasp_state.config.enable_cycript_detection = true;
        g_rasp_state.config.enable_substrate_detection = true;
        g_rasp_state.config.enable_debugger_detection = true;
        g_rasp_state.config.enable_dtrace_detection = true;
        g_rasp_state.config.enable_instrumentation_detection = true;
        g_rasp_state.config.enable_signature_check = true;
        g_rasp_state.config.enable_hash_check = true;
        g_rasp_state.config.enable_dylib_check = true;
        g_rasp_state.config.default_action = RASP_ACTION_EXIT;
        g_rasp_state.config.callback = NULL;
        g_rasp_state.config.sensitivity = 1;
    }

    g_rasp_state.initialized = true;
    g_rasp_state.check_count = 0;
    g_rasp_state.threat_count = 0;

    pthread_mutex_unlock(&g_rasp_mutex);
}

/**
 * Initialize RASP with default configuration
 */
void shield_rasp_init_default(void) {
    shield_rasp_init(NULL);
}

// ============================================================================
// CALLBACK REGISTRATION
// ============================================================================

/**
 * Register callback for threat detection
 *
 * @param callback Callback function
 */
void shield_rasp_register_callback(rasp_callback_t callback) {
    pthread_mutex_lock(&g_rasp_mutex);
    g_rasp_state.config.callback = callback;
    pthread_mutex_unlock(&g_rasp_mutex);
}

// ============================================================================
// THREAT HANDLING
// ============================================================================

/**
 * Handle detected threat
 *
 * @param result Detection result
 */
static void shield_rasp_handle_threat(const rasp_detection_result_t* result) {
    if (!result || !result->detected) {
        return;
    }

    pthread_mutex_lock(&g_rasp_mutex);
    g_rasp_state.threat_count++;
    pthread_mutex_unlock(&g_rasp_mutex);

    // Call custom callback if registered
    if (g_rasp_state.config.callback) {
        g_rasp_state.config.callback(
            result->threat_type,
            result->threat_level,
            result->details
        );
    }

    // Take default action
    switch (g_rasp_state.config.default_action) {
        case RASP_ACTION_LOG:
            // Just log (callback handles this)
            break;

        case RASP_ACTION_ALERT:
            // Alert (callback handles this)
            break;

        case RASP_ACTION_EXIT:
            // Exit app gracefully
            exit(0);
            break;

        case RASP_ACTION_CRASH:
            // Crash app
            abort();
            break;

        case RASP_ACTION_CUSTOM:
            // Custom callback handles everything
            break;
    }
}

// ============================================================================
// DETECTION CHECKS
// ============================================================================

/**
 * Run all RASP checks
 *
 * This is the main entry point for periodic checks
 */
void shield_rasp_check_all(void) {
    if (!g_rasp_state.initialized) {
        shield_rasp_init_default();
    }

    pthread_mutex_lock(&g_rasp_mutex);
    g_rasp_state.check_count++;
    pthread_mutex_unlock(&g_rasp_mutex);

    rasp_detection_result_t result;

    // Check for hooks
    if (shield_detect_hooks(&g_rasp_state.config, &result)) {
        shield_rasp_handle_threat(&result);
        return;
    }

    // Check for tracing
    if (shield_detect_tracing(&g_rasp_state.config, &result)) {
        shield_rasp_handle_threat(&result);
        return;
    }

    // Check for tampering
    if (shield_detect_tampering(&g_rasp_state.config, &result)) {
        shield_rasp_handle_threat(&result);
        return;
    }
}

/**
 * Check for hooks only
 */
void shield_rasp_check_hooks(void) {
    if (!g_rasp_state.initialized) {
        shield_rasp_init_default();
    }

    rasp_detection_result_t result;
    if (shield_detect_hooks(&g_rasp_state.config, &result)) {
        shield_rasp_handle_threat(&result);
    }
}

/**
 * Check for tracing only
 */
void shield_rasp_check_tracing(void) {
    if (!g_rasp_state.initialized) {
        shield_rasp_init_default();
    }

    rasp_detection_result_t result;
    if (shield_detect_tracing(&g_rasp_state.config, &result)) {
        shield_rasp_handle_threat(&result);
    }
}

/**
 * Check for tampering only
 */
void shield_rasp_check_tampering(void) {
    if (!g_rasp_state.initialized) {
        shield_rasp_init_default();
    }

    rasp_detection_result_t result;
    if (shield_detect_tampering(&g_rasp_state.config, &result)) {
        shield_rasp_handle_threat(&result);
    }
}

// ============================================================================
// STATISTICS
// ============================================================================

/**
 * Get RASP statistics
 *
 * @param check_count Number of checks performed (out)
 * @param threat_count Number of threats detected (out)
 */
void shield_rasp_get_stats(uint64_t* check_count, uint64_t* threat_count) {
    pthread_mutex_lock(&g_rasp_mutex);

    if (check_count) {
        *check_count = g_rasp_state.check_count;
    }

    if (threat_count) {
        *threat_count = g_rasp_state.threat_count;
    }

    pthread_mutex_unlock(&g_rasp_mutex);
}

// ============================================================================
// DISTRIBUTED CHECKS (Inline)
// ============================================================================

/**
 * Inline hook check
 *
 * This is designed to be called inline in app code at various points
 */
static inline void __attribute__((always_inline)) shield_inline_check_hooks(void) {
    shield_rasp_check_hooks();
}

/**
 * Inline tracing check
 */
static inline void __attribute__((always_inline)) shield_inline_check_tracing(void) {
    shield_rasp_check_tracing();
}

/**
 * Inline tampering check
 */
static inline void __attribute__((always_inline)) shield_inline_check_tampering(void) {
    shield_rasp_check_tampering();
}

// ============================================================================
// CONSTRUCTOR - Auto-initialize on load
// ============================================================================

/**
 * Constructor - called when library is loaded
 */
__attribute__((constructor))
static void shield_rasp_load(void) {
    // Initialize with default config
    shield_rasp_init_default();

    // Run initial check
    shield_rasp_check_all();
}

/**
 * Destructor - called when library is unloaded
 */
__attribute__((destructor))
static void shield_rasp_unload(void) {
    // Cleanup if needed
    pthread_mutex_lock(&g_rasp_mutex);
    g_rasp_state.initialized = false;
    pthread_mutex_unlock(&g_rasp_mutex);
}

// ============================================================================
// PERIODIC CHECKS (Background Thread)
// ============================================================================

static pthread_t g_rasp_thread = NULL;
static bool g_rasp_thread_running = false;

/**
 * Background thread that periodically runs RASP checks
 */
static void* shield_rasp_background_thread(void* arg) {
    (void)arg;

    while (g_rasp_thread_running) {
        // Run all checks
        shield_rasp_check_all();

        // Sleep for 5 seconds
        sleep(5);
    }

    return NULL;
}

/**
 * Start background RASP checks
 */
void shield_rasp_start_background_checks(void) {
    if (g_rasp_thread_running) {
        return;
    }

    g_rasp_thread_running = true;

    pthread_create(&g_rasp_thread, NULL, shield_rasp_background_thread, NULL);
}

/**
 * Stop background RASP checks
 */
void shield_rasp_stop_background_checks(void) {
    if (!g_rasp_thread_running) {
        return;
    }

    g_rasp_thread_running = false;

    if (g_rasp_thread) {
        pthread_join(g_rasp_thread, NULL);
        g_rasp_thread = NULL;
    }
}
