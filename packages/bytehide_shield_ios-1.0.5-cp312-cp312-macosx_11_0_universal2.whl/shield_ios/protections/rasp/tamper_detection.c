/*
 * Shield iOS - Tampering Detection
 *
 * Detects binary tampering and repackaging:
 * - Code signature validation
 * - Binary hash verification
 * - Dylib injection detection
 * - Info.plist modification
 * - Provisioning profile tampering
 *
 * TECHNIQUES:
 * 1. SecStaticCode signature verification
 * 2. SHA256 hash checking of binary
 * 3. Dylib whitelist verification
 * 4. Info.plist integrity check
 * 5. Bundle identifier verification
 *
 * Author: ByteHide Shield iOS
 */

#include "rasp_common.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <dlfcn.h>
#include <mach-o/dyld.h>
#include <CommonCrypto/CommonDigest.h>
#include <sys/stat.h>

#if TARGET_OS_IPHONE
#import <Foundation/Foundation.h>
#import <Security/Security.h>
#endif

// ============================================================================
// CODE SIGNATURE DETECTION
// ============================================================================

/**
 * Verify code signature using Security framework
 *
 * Uses SecStaticCodeCheckValidity to verify the app hasn't been modified
 */
bool shield_verify_code_signature(rasp_detection_result_t* result) {
    result->threat_type = RASP_THREAT_SIGNATURE_INVALID;
    result->threat_level = RASP_LEVEL_NONE;
    result->detected = false;
    result->details[0] = '\0';

#if TARGET_OS_IPHONE
    @autoreleasepool {
        // Get reference to self
        SecStaticCodeRef staticCode = NULL;
        OSStatus status = SecStaticCodeCreateWithPath(
            (__bridge CFURLRef)[NSURL fileURLWithPath:[[NSBundle mainBundle] executablePath]],
            kSecCSDefaultFlags,
            &staticCode
        );

        if (status != errSecSuccess) {
            result->detected = true;
            result->threat_level = RASP_LEVEL_HIGH;
            snprintf(result->details, sizeof(result->details),
                    "Failed to get code reference (status: %d)", (int)status);
            return true;
        }

        // Check validity
        status = SecStaticCodeCheckValidity(
            staticCode,
            kSecCSDefaultFlags,
            NULL
        );

        CFRelease(staticCode);

        if (status != errSecSuccess) {
            result->detected = true;
            result->threat_level = RASP_LEVEL_CRITICAL;
            snprintf(result->details, sizeof(result->details),
                    "Code signature invalid (status: %d)", (int)status);
            return true;
        }
    }
#endif

    return false;
}

// ============================================================================
// HASH VERIFICATION
// ============================================================================

/**
 * Calculate SHA256 hash of data
 */
static void shield_calculate_sha256(const unsigned char* data, size_t length, unsigned char* hash) {
    CC_SHA256(data, (CC_LONG)length, hash);
}

/**
 * Verify binary hash
 *
 * NOTE: The expected hash should be embedded in the binary (obfuscated)
 * For this example, we just calculate and report - in production, you'd compare
 * against an embedded hash
 */
bool shield_verify_binary_hash(rasp_detection_result_t* result) {
    result->threat_type = RASP_THREAT_HASH_MISMATCH;
    result->threat_level = RASP_LEVEL_NONE;
    result->detected = false;
    result->details[0] = '\0';

#if TARGET_OS_IPHONE
    @autoreleasepool {
        NSString* executablePath = [[NSBundle mainBundle] executablePath];
        NSData* binaryData = [NSData dataWithContentsOfFile:executablePath];

        if (!binaryData) {
            result->detected = true;
            result->threat_level = RASP_LEVEL_HIGH;
            snprintf(result->details, sizeof(result->details),
                    "Failed to read binary for hash verification");
            return true;
        }

        // Calculate hash
        unsigned char hash[CC_SHA256_DIGEST_LENGTH];
        shield_calculate_sha256(binaryData.bytes, binaryData.length, hash);

        // In production, compare against embedded hash
        // For now, we just calculate it
        // Example:
        // unsigned char expected_hash[CC_SHA256_DIGEST_LENGTH] = { EMBEDDED_HASH };
        // if (memcmp(hash, expected_hash, CC_SHA256_DIGEST_LENGTH) != 0) {
        //     result->detected = true;
        //     result->threat_level = RASP_LEVEL_CRITICAL;
        //     snprintf(result->details, sizeof(result->details), "Binary hash mismatch");
        //     return true;
        // }
    }
#endif

    return false;
}

// ============================================================================
// DYLIB INJECTION DETECTION
// ============================================================================

/**
 * Check for injected dylibs
 *
 * Maintains a whitelist of expected dylibs and alerts on unknown ones
 */
bool shield_detect_dylib_injection(rasp_detection_result_t* result) {
    result->threat_type = RASP_THREAT_DYLIB_INJECTION;
    result->threat_level = RASP_LEVEL_NONE;
    result->detected = false;
    result->details[0] = '\0';

    // Known safe dylib patterns
    const char* safe_patterns[] = {
        "/System/Library/",
        "/usr/lib/",
        "@rpath/",
        "/Developer/",
        NULL
    };

    // Known malicious/suspicious patterns
    const char* suspicious_patterns[] = {
        "frida",
        "cycript",
        "substrate",
        "substitute",
        "inject",
        "hook",
        NULL
    };

    uint32_t count = _dyld_image_count();
    int suspicious_count = 0;

    for (uint32_t i = 0; i < count; i++) {
        const char* name = _dyld_get_image_name(i);
        if (name == NULL) {
            continue;
        }

        // Check if it's a known safe dylib
        bool is_safe = false;
        for (int j = 0; safe_patterns[j] != NULL; j++) {
            if (strstr(name, safe_patterns[j]) != NULL) {
                is_safe = true;
                break;
            }
        }

        if (is_safe) {
            continue;
        }

        // Check if it matches suspicious patterns
        for (int j = 0; suspicious_patterns[j] != NULL; j++) {
            if (strstr(name, suspicious_patterns[j]) != NULL) {
                result->detected = true;
                result->threat_level = RASP_LEVEL_CRITICAL;
                snprintf(result->details, sizeof(result->details),
                        "Suspicious dylib detected: %s", name);
                return true;
            }
        }

        // Unknown dylib (not system, not suspicious by name)
        // This could be legitimate (app's own dylibs) or injected
        suspicious_count++;
    }

    // If there are too many non-system dylibs, might be injection
    if (suspicious_count > 10) {
        result->detected = true;
        result->threat_level = RASP_LEVEL_MEDIUM;
        snprintf(result->details, sizeof(result->details),
                "Unusually high number of non-system dylibs (%d)", suspicious_count);
        return true;
    }

    return false;
}

// ============================================================================
// INFO.PLIST VERIFICATION
// ============================================================================

/**
 * Verify Info.plist integrity
 *
 * Checks if Info.plist has been modified
 */
bool shield_verify_info_plist(rasp_detection_result_t* result) {
    result->threat_type = RASP_THREAT_PLIST_MODIFIED;
    result->threat_level = RASP_LEVEL_NONE;
    result->detected = false;
    result->details[0] = '\0';

#if TARGET_OS_IPHONE
    @autoreleasepool {
        // Get bundle identifier
        NSString* bundleId = [[NSBundle mainBundle] bundleIdentifier];

        if (!bundleId || bundleId.length == 0) {
            result->detected = true;
            result->threat_level = RASP_LEVEL_HIGH;
            snprintf(result->details, sizeof(result->details),
                    "Bundle identifier missing or empty");
            return true;
        }

        // In production, you'd verify against expected bundle ID
        // Example:
        // NSString* expectedBundleId = @"com.example.myapp";
        // if (![bundleId isEqualToString:expectedBundleId]) {
        //     result->detected = true;
        //     result->threat_level = RASP_LEVEL_CRITICAL;
        //     snprintf(result->details, sizeof(result->details),
        //             "Bundle identifier mismatch: %s", [bundleId UTF8String]);
        //     return true;
        // }

        // Check Info.plist file integrity
        NSString* plistPath = [[NSBundle mainBundle] pathForResource:@"Info" ofType:@"plist"];
        if (!plistPath) {
            result->detected = true;
            result->threat_level = RASP_LEVEL_HIGH;
            snprintf(result->details, sizeof(result->details),
                    "Info.plist not found");
            return true;
        }

        // Read plist
        NSDictionary* plist = [NSDictionary dictionaryWithContentsOfFile:plistPath];
        if (!plist) {
            result->detected = true;
            result->threat_level = RASP_LEVEL_HIGH;
            snprintf(result->details, sizeof(result->details),
                    "Failed to read Info.plist");
            return true;
        }

        // Calculate hash of plist
        NSData* plistData = [NSData dataWithContentsOfFile:plistPath];
        if (plistData) {
            unsigned char hash[CC_SHA256_DIGEST_LENGTH];
            shield_calculate_sha256(plistData.bytes, plistData.length, hash);

            // In production, compare against embedded hash
            // For now, we just calculate it
        }
    }
#endif

    return false;
}

// ============================================================================
// REPACKAGING DETECTION
// ============================================================================

/**
 * Detect if app has been repackaged
 *
 * Combines multiple checks to determine if app was repackaged
 */
bool shield_detect_repackaging(rasp_detection_result_t* result) {
    result->threat_type = RASP_THREAT_REPACKAGED;
    result->threat_level = RASP_LEVEL_NONE;
    result->detected = false;
    result->details[0] = '\0';

    // Repackaged apps often have:
    // 1. Invalid signature
    // 2. Modified Info.plist
    // 3. Injected dylibs

    int indicators = 0;

    // Check signature
    rasp_detection_result_t sig_result;
    if (shield_verify_code_signature(&sig_result)) {
        indicators++;
    }

    // Check Info.plist
    rasp_detection_result_t plist_result;
    if (shield_verify_info_plist(&plist_result)) {
        indicators++;
    }

    // Check dylibs
    rasp_detection_result_t dylib_result;
    if (shield_detect_dylib_injection(&dylib_result)) {
        indicators++;
    }

    // If 2+ indicators, likely repackaged
    if (indicators >= 2) {
        result->detected = true;
        result->threat_level = RASP_LEVEL_CRITICAL;
        snprintf(result->details, sizeof(result->details),
                "App appears to be repackaged (%d indicators)", indicators);
        return true;
    } else if (indicators == 1) {
        result->detected = true;
        result->threat_level = RASP_LEVEL_MEDIUM;
        snprintf(result->details, sizeof(result->details),
                "Possible repackaging (1 indicator)");
        return true;
    }

    return false;
}

// ============================================================================
// COMPREHENSIVE TAMPERING DETECTION
// ============================================================================

/**
 * Run all tampering detection checks
 *
 * @param config RASP configuration
 * @param result Detection result (out parameter)
 * @return true if tampering detected
 */
bool shield_detect_tampering(const rasp_config_t* config, rasp_detection_result_t* result) {
    // Check code signature
    if (config->enable_signature_check) {
        if (shield_verify_code_signature(result)) {
            return true;
        }
    }

    // Check binary hash
    if (config->enable_hash_check) {
        if (shield_verify_binary_hash(result)) {
            return true;
        }
    }

    // Check dylib injection
    if (config->enable_dylib_check) {
        if (shield_detect_dylib_injection(result)) {
            return true;
        }
    }

    // Check Info.plist
    if (shield_verify_info_plist(result)) {
        return true;
    }

    // Check for repackaging
    if (shield_detect_repackaging(result)) {
        return true;
    }

    return false;
}
