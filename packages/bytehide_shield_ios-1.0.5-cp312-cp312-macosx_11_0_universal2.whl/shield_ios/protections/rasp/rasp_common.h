/*
 * Shield iOS - RASP Common Definitions
 *
 * Common types, enums, and structures for RASP (Runtime Application Self-Protection)
 *
 * Author: ByteHide Shield iOS
 */

#ifndef SHIELD_RASP_COMMON_H
#define SHIELD_RASP_COMMON_H

#include <stdint.h>
#include <stdbool.h>

// ============================================================================
// THREAT TYPES
// ============================================================================

typedef enum {
    RASP_THREAT_NONE = 0,

    // Hook detection threats
    RASP_THREAT_FRIDA = 1,
    RASP_THREAT_CYCRIPT = 2,
    RASP_THREAT_SUBSTRATE = 3,
    RASP_THREAT_UNKNOWN_HOOK = 4,

    // Tracing threats
    RASP_THREAT_DEBUGGER = 10,
    RASP_THREAT_DTRACE = 11,
    RASP_THREAT_LLDB = 12,
    RASP_THREAT_INSTRUMENTATION = 13,
    RASP_THREAT_BREAKPOINT = 14,

    // Tampering threats
    RASP_THREAT_SIGNATURE_INVALID = 20,
    RASP_THREAT_HASH_MISMATCH = 21,
    RASP_THREAT_REPACKAGED = 22,
    RASP_THREAT_DYLIB_INJECTION = 23,
    RASP_THREAT_PLIST_MODIFIED = 24,

} rasp_threat_type_t;

// ============================================================================
// THREAT LEVELS
// ============================================================================

typedef enum {
    RASP_LEVEL_NONE = 0,
    RASP_LEVEL_LOW = 1,        // Suspicious
    RASP_LEVEL_MEDIUM = 2,     // Probable attack
    RASP_LEVEL_HIGH = 3,       // Confirmed attack
    RASP_LEVEL_CRITICAL = 4,   // Active attack
} rasp_threat_level_t;

// ============================================================================
// ACTIONS
// ============================================================================

typedef enum {
    RASP_ACTION_LOG = 0,       // Just log
    RASP_ACTION_ALERT = 1,     // Alert user/backend
    RASP_ACTION_EXIT = 2,      // Exit app
    RASP_ACTION_CRASH = 3,     // Crash app
    RASP_ACTION_CUSTOM = 4,    // Custom callback
} rasp_action_t;

// ============================================================================
// CALLBACK
// ============================================================================

/**
 * RASP callback function type
 *
 * @param threat_type Type of threat detected
 * @param threat_level Severity level
 * @param details Human-readable details (can be NULL)
 */
typedef void (*rasp_callback_t)(
    rasp_threat_type_t threat_type,
    rasp_threat_level_t threat_level,
    const char* details
);

// ============================================================================
// CONFIGURATION
// ============================================================================

typedef struct {
    // Hook detection
    bool enable_frida_detection;
    bool enable_cycript_detection;
    bool enable_substrate_detection;

    // Tracing detection
    bool enable_debugger_detection;
    bool enable_dtrace_detection;
    bool enable_instrumentation_detection;

    // Tampering detection
    bool enable_signature_check;
    bool enable_hash_check;
    bool enable_dylib_check;

    // Actions
    rasp_action_t default_action;
    rasp_callback_t callback;

    // Sensitivity (0-2)
    int sensitivity;

} rasp_config_t;

// ============================================================================
// DETECTION RESULT
// ============================================================================

typedef struct {
    rasp_threat_type_t threat_type;
    rasp_threat_level_t threat_level;
    char details[256];
    bool detected;
} rasp_detection_result_t;

// ============================================================================
// GLOBAL STATE
// ============================================================================

typedef struct {
    rasp_config_t config;
    bool initialized;
    uint64_t check_count;
    uint64_t threat_count;
} rasp_state_t;

#endif // SHIELD_RASP_COMMON_H
