"""
Shield iOS - Arithmetic Obfuscation (Mixed Boolean-Arithmetic)

Transforms simple arithmetic operations into complex equivalent expressions
using a mix of boolean and arithmetic operations.

Compatible with Shield .NET and inspired by iXGuard.
"""

from .arithmetic_obfuscation_protection import (
    ArithmeticObfuscationProtection,
    create_protection
)

__all__ = [
    'ArithmeticObfuscationProtection',
    'create_protection'
]
