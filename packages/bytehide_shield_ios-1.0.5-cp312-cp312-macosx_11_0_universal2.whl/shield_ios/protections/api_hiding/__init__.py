"""
Shield iOS - API Call Hiding Protection

Hides API calls to system frameworks by replacing direct calls with
dynamic resolution and indirect calls.

This makes static analysis harder and hides what APIs are being used.

Compatible with Shield .NET and inspired by iXGuard.
"""

from .api_hiding_protection import APIHidingProtection, create_protection

__all__ = ['APIHidingProtection', 'create_protection']
