"""
Shield iOS - Register Shuffling Protection

Reorganizes and redistributes register usage in ARM64 code to make
static and dynamic analysis more difficult.

Compatible with Shield .NET and inspired by iXGuard.
"""

from .register_shuffling_protection import RegisterShufflingProtection, create_protection

__all__ = ['RegisterShufflingProtection', 'create_protection']
