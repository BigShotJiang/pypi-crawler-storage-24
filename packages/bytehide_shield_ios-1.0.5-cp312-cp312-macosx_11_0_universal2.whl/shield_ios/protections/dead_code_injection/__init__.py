#!/usr/bin/env python3
"""Shield iOS - Dead Code Injection Protection

This module injects unreachable ARM64 instructions into iOS binaries to confuse
static analysis tools and make reverse engineering harder.

Main components:
- ARM64DeadInstructionGenerator: Generates legitimate-looking ARM64 dead code
- DeadCodeInjector: Finds injection points and injects dead code
- SmartDeadCodeInjector: Advanced injector that avoids critical functions
- DeadCodeInjectionProtection: Main protection stage

Example usage:
    from shield_ios.protections.dead_code_injection import create_protection

    protection = create_protection(logger, aggressiveness='medium', smart_mode=True)
    protected_binary = protection.execute(binary_path)
"""

from .arm64_dead_instructions import (
    ARM64Register,
    DeadInstructionType,
    ARM64DeadInstructionGenerator
)

from .code_injector import (
    InjectionPoint,
    DeadCodeInjector,
    SmartDeadCodeInjector
)

from .dead_code_injection_protection import (
    DeadCodeInjectionProtection,
    create_protection
)

__all__ = [
    # ARM64 instruction generation
    'ARM64Register',
    'DeadInstructionType',
    'ARM64DeadInstructionGenerator',

    # Code injection
    'InjectionPoint',
    'DeadCodeInjector',
    'SmartDeadCodeInjector',

    # Main protection
    'DeadCodeInjectionProtection',
    'create_protection',
]
