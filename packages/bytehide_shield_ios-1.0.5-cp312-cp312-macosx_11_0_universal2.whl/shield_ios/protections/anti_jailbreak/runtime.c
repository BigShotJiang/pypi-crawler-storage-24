/*
 * Shield iOS - Anti-Jailbreak Runtime (ENHANCED)
 *
 * Comprehensive jailbreak detection with 10+ methods.
 * Detects all major jailbreaks: checkra1n, unc0ver, Taurine, Odyssey, etc.
 * Runs automatically on app launch.
 *
 * ENHANCED VERSION with advanced detection methods.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <dlfcn.h>
#include <spawn.h>
#include <signal.h>
#include <mach-o/dyld.h>
#include <fcntl.h>
#include <dirent.h>

// Configuration
#ifndef SHIELD_JAILBREAK_EXIT_ON_DETECT
#define SHIELD_JAILBREAK_EXIT_ON_DETECT 1
#endif

// Detection sensitivity (0-2)
// 0 = Basic (fast, few false positives)
// 1 = Standard (balanced)
// 2 = Paranoid (all checks, may be slower)
#ifndef SHIELD_JAILBREAK_SENSITIVITY
#define SHIELD_JAILBREAK_SENSITIVITY 1
#endif


// ============================================================================
// COMPREHENSIVE JAILBREAK PATHS (70+ paths)
// ============================================================================

// Cydia & Package Managers
static const char* jailbreak_cydia_paths[] = {
    "/Applications/Cydia.app",
    "/Applications/Cydia.app/Cydia",
    "/Library/MobileSubstrate/MobileSubstrate.dylib",
    "/var/cache/apt",
    "/var/lib/cydia",
    "/var/lib/apt",
    "/var/log/apt",
    "/etc/apt",
    "/private/var/lib/apt/",
    "/usr/libexec/cydia/",
    "/usr/bin/cydia",
    "/usr/sbin/frida-server",
    "/usr/bin/cycript",
    "/usr/local/bin/cycript",
    "/usr/lib/libcycript.dylib",
    "/var/mobile/Library/Cydia",
    NULL
};

// Sileo & Modern Package Managers
static const char* jailbreak_sileo_paths[] = {
    "/Applications/Sileo.app",
    "/Applications/Sileo.app/Sileo",
    "/Applications/Zebra.app",
    "/Applications/Installer.app",
    "/var/mobile/Library/Sileo",
    "/var/mobile/Library/Installer",
    "/usr/bin/sileo",
    NULL
};

// Substrate & Substitute & libhooker
static const char* jailbreak_substrate_paths[] = {
    "/Library/MobileSubstrate/DynamicLibraries/",
    "/usr/lib/libsubstrate.dylib",
    "/usr/lib/substrate",
    "/usr/lib/TweakInject",
    "/Library/Frameworks/CydiaSubstrate.framework",
    "/Library/Frameworks/CydiaSubstrate.framework/CydiaSubstrate",
    "/usr/lib/libsubstitute.dylib",
    "/usr/lib/libhooker.dylib",
    "/usr/lib/libblackjack.dylib",
    "/usr/lib/libsubstitute.0.dylib",
    "/Library/Substitute",
    NULL
};

// SSH & Command Line Tools
static const char* jailbreak_ssh_paths[] = {
    "/usr/sbin/sshd",
    "/usr/bin/sshd",
    "/usr/libexec/sftp-server",
    "/usr/bin/ssh",
    "/etc/ssh/sshd_config",
    "/etc/ssh",
    "/private/etc/ssh/sshd_config",
    "/var/log/syslog",
    NULL
};

// Jailbreak Tools & Binaries
static const char* jailbreak_tools_paths[] = {
    "/bin/bash",
    "/bin/sh",
    "/usr/bin/bash",
    "/usr/bin/sh",
    "/usr/libexec/apt",
    "/usr/bin/apt",
    "/usr/bin/apt-get",
    "/usr/bin/dpkg",
    "/usr/bin/uicache",
    "/usr/local/bin/zsign",
    "/usr/bin/ldrestart",
    NULL
};

// checkra1n specific
static const char* jailbreak_checkrain_paths[] = {
    "/var/checkra1n.dmg",
    "/var/binpack",
    "/var/binpack/Applications",
    "/Library/PreferenceBundles/checkra1nSettings.bundle",
    "/Applications/checkra1n.app",
    "/var/lib/checkra1n",
    "/var/LIB",  // checkra1n lowercase lib
    NULL
};

// unc0ver specific
static const char* jailbreak_uncover_paths[] = {
    "/var/lib/dpkg",
    "/var/lib/dpkg/info",
    "/.installed_unc0ver",
    "/var/jb",
    "/Applications/unc0ver.app",
    NULL
};

// Taurine/Odyssey specific
static const char* jailbreak_taurine_paths[] = {
    "/taurine",
    "/.taurine",
    "/odyssey",
    "/.odyssey",
    "/Applications/Taurine.app",
    "/Applications/Odyssey.app",
    "/var/lib/dpkg/info/ws.hbang.",  // libhooker
    "/usr/lib/libhooker.dylib",
    NULL
};

// Development & Debugging Tools
static const char* jailbreak_debug_paths[] = {
    "/usr/sbin/frida-server",
    "/usr/bin/frida-server",
    "/usr/sbin/frida",
    "/Applications/FakeCarrier.app",
    "/Applications/Icy.app",
    "/Applications/IntelliScreen.app",
    "/Applications/MxTube.app",
    "/Applications/RockApp.app",
    "/Applications/SBSettings.app",
    "/Applications/WinterBoard.app",
    "/Applications/blackra1n.app",
    NULL
};

// File managers (often used on jailbroken devices)
static const char* jailbreak_filemanager_paths[] = {
    "/Applications/Filza.app",
    "/Applications/iFile.app",
    NULL
};

// Common jailbreak detection bypass tools
static const char* jailbreak_bypass_paths[] = {
    "/Library/MobileSubstrate/DynamicLibraries/xCon.dylib",
    "/Library/MobileSubstrate/DynamicLibraries/xCon.plist",
    "/Library/MobileSubstrate/DynamicLibraries/BypassJB.dylib",
    "/Library/MobileSubstrate/DynamicLibraries/Liberty.dylib",
    "/Library/MobileSubstrate/DynamicLibraries/FlyJB.dylib",
    "/Library/MobileSubstrate/DynamicLibraries/Shadow.dylib",
    "/Library/MobileSubstrate/DynamicLibraries/HideJB.dylib",
    NULL
};


// ============================================================================
// ENHANCED DETECTION METHOD 1: Comprehensive File System Check
// ============================================================================

static int shield_check_jailbreak_files_comprehensive(void) {
    struct stat stat_buf;

    // Array of all path arrays
    const char** path_arrays[] = {
        jailbreak_cydia_paths,
        jailbreak_sileo_paths,
        jailbreak_substrate_paths,
        jailbreak_ssh_paths,
        jailbreak_tools_paths,
        jailbreak_checkrain_paths,
        jailbreak_uncover_paths,
        jailbreak_taurine_paths,
        jailbreak_debug_paths,
        jailbreak_filemanager_paths,
        jailbreak_bypass_paths,
        NULL
    };

    // Check all path arrays
    for (int i = 0; path_arrays[i] != NULL; i++) {
        const char** paths = path_arrays[i];

        for (int j = 0; paths[j] != NULL; j++) {
            // Try stat() - more reliable than fopen
            if (stat(paths[j], &stat_buf) == 0) {
                return 1;  // File exists - jailbreak detected
            }

            // Also try access() as backup
            if (access(paths[j], F_OK) == 0) {
                return 1;
            }
        }
    }

    return 0;
}


// ============================================================================
// ENHANCED DETECTION METHOD 2: Advanced Symbolic Link Detection
// ============================================================================

static int shield_check_symlinks_advanced(void) {
    struct stat stat_buf;

    // Common symlinked directories on jailbroken devices
    const char* symlink_checks[] = {
        "/Applications",
        "/Library/Ringtones",
        "/Library/Wallpaper",
        "/usr/arm-apple-darwin9",
        "/usr/include",
        "/usr/libexec",
        "/usr/share",
        "/var/stash",  // Common stash location
        NULL
    };

    for (int i = 0; symlink_checks[i] != NULL; i++) {
        if (lstat(symlink_checks[i], &stat_buf) == 0) {
            if (S_ISLNK(stat_buf.st_mode)) {
                return 1;  // Is a symbolic link - likely jailbroken
            }
        }
    }

    return 0;
}


// ============================================================================
// DETECTION METHOD 3: Dyld Environment Variable Check
// ============================================================================

static int shield_check_dyld_environment(void) {
    // Check for dyld environment variables (often used by tweaks)
    const char* suspicious_vars[] = {
        "DYLD_INSERT_LIBRARIES",
        "_MSSafeMode",
        "_SafeMode",
        "DYLD_PRINT_LIBRARIES",
        "DYLD_PRINT_APIS",
        "DYLD_PRINT_BINDINGS",
        NULL
    };

    for (int i = 0; suspicious_vars[i] != NULL; i++) {
        char* value = getenv(suspicious_vars[i]);
        if (value != NULL && strlen(value) > 0) {
            return 1;
        }
    }

    return 0;
}


// ============================================================================
// DETECTION METHOD 4: Dynamic Library Loading Check
// ============================================================================

static int shield_check_loaded_libraries(void) {
    // Suspicious library names
    const char* suspicious_libs[] = {
        "MobileSubstrate",
        "Substrate",
        "cycript",
        "SSLKillSwitch",
        "PreferenceLoader",
        "RocketBootstrap",
        "AppList",
        "libhooker",
        "substitute",
        "TweakInject",
        "FlyJB",
        "Liberty",
        "Shadow",
        "xCon",
        NULL
    };

    // Check if any suspicious library is loaded
    for (int i = 0; suspicious_libs[i] != NULL; i++) {
        void* handle = dlopen(suspicious_libs[i], RTLD_NOLOAD);
        if (handle != NULL) {
            dlclose(handle);
            return 1;
        }
    }

    // Check all loaded dylibs
    uint32_t count = _dyld_image_count();
    for (uint32_t i = 0; i < count; i++) {
        const char* name = _dyld_get_image_name(i);
        if (name != NULL) {
            // Check for suspicious substrings
            const char* suspicious[] = {
                "MobileSubstrate",
                "Substrate",
                "cycript",
                "frida",
                "PreferenceLoader",
                "libhooker",
                "substitute",
                NULL
            };

            for (int j = 0; suspicious[j] != NULL; j++) {
                if (strstr(name, suspicious[j]) != NULL) {
                    return 1;
                }
            }
        }
    }

    return 0;
}


// ============================================================================
// DETECTION METHOD 5: URL Scheme Check
// ============================================================================

static int shield_check_url_schemes(void) {
    // Try to check if jailbreak-related URL schemes can be opened
    // Note: This is a heuristic check, requires UIApplication in real implementation

    // For C-only implementation, we check for scheme handler files
    const char* scheme_handler_paths[] = {
        "/System/Library/LaunchDaemons/com.saurik.Cydia.Startup.plist",
        "/System/Library/LaunchDaemons/com.ikey.bbot.plist",
        "/private/var/db/dpkg",
        NULL
    };

    struct stat stat_buf;
    for (int i = 0; scheme_handler_paths[i] != NULL; i++) {
        if (stat(scheme_handler_paths[i], &stat_buf) == 0) {
            return 1;
        }
    }

    return 0;
}


// ============================================================================
// DETECTION METHOD 6: Write Permission Test (Enhanced)
// ============================================================================

static int shield_check_write_permissions(void) {
    // Try to write to various protected locations
    const char* test_paths[] = {
        "/private/.shield_jailbreak_test",
        "/.file",
        "/private/test_jb",
        NULL
    };

    for (int i = 0; test_paths[i] != NULL; i++) {
        FILE* file = fopen(test_paths[i], "w");
        if (file != NULL) {
            fclose(file);
            unlink(test_paths[i]);  // Clean up
            return 1;  // Write succeeded - likely jailbroken
        }
    }

    return 0;
}


// ============================================================================
// DETECTION METHOD 7: System Call Behavior Check
// ============================================================================

static int shield_check_system_calls(void) {
    // Check if we can execute system commands (should fail on non-jailbroken)

    // Try system() - should be blocked on stock iOS
    int result = system("ls");
    if (result == 0) {
        return 1;  // system() worked - likely jailbroken
    }

    return 0;
}


// ============================================================================
// DETECTION METHOD 8: Fork Bomb Detection (Safe)
// ============================================================================

static int shield_check_fork_safe(void) {
    // Safer fork test that doesn't actually fork
    // Check if fork() exists and is not stubbed

    // On stock iOS, fork() should fail
    // We check without actually forking to avoid potential issues

    #if SHIELD_JAILBREAK_SENSITIVITY >= 1
    // Only do actual fork test if sensitivity is medium or high
    pid_t pid = fork();

    if (pid >= 0) {
        // fork() succeeded
        if (pid > 0) {
            // Parent - kill child immediately
            kill(pid, SIGKILL);
        } else {
            // Child - exit immediately
            exit(0);
        }
        return 1;  // Jailbroken
    }
    #endif

    return 0;
}


// ============================================================================
// DETECTION METHOD 9: Stat System Files (Permission Check)
// ============================================================================

static int shield_check_system_file_permissions(void) {
    // On stock iOS, certain system files have specific permissions
    // Jailbreaks often modify these

    struct stat stat_buf;

    // Check /Applications permissions
    if (stat("/Applications", &stat_buf) == 0) {
        // On stock iOS, /Applications is owned by root
        // Jailbreaks often change this
        if (stat_buf.st_uid != 0 || stat_buf.st_gid != 0) {
            return 1;
        }
    }

    // Check /var permissions
    if (stat("/var", &stat_buf) == 0) {
        // Check if we have unexpected write permissions
        if (stat_buf.st_mode & S_IWOTH) {
            return 1;  // World-writable - suspicious
        }
    }

    return 0;
}


// ============================================================================
// DETECTION METHOD 10: Directory Listing Check
// ============================================================================

static int shield_check_directory_listing(void) {
    // Try to list directories that should be inaccessible

    const char* restricted_dirs[] = {
        "/var/mobile/Library",
        "/var/log",
        "/var/tmp",
        NULL
    };

    for (int i = 0; restricted_dirs[i] != NULL; i++) {
        DIR* dir = opendir(restricted_dirs[i]);
        if (dir != NULL) {
            // Count entries
            int count = 0;
            struct dirent* entry;
            while ((entry = readdir(dir)) != NULL && count < 100) {
                count++;
            }
            closedir(dir);

            // If we can read many entries, might be jailbroken
            if (count > 50) {
                return 1;
            }
        }
    }

    return 0;
}


// ============================================================================
// Main Detection Function (COMPREHENSIVE)
// ============================================================================

__attribute__((visibility("hidden")))
int shield_is_jailbroken(void) {
    // Method 1: Comprehensive file check (ALWAYS)
    if (shield_check_jailbreak_files_comprehensive()) {
        return 1;
    }

    // Method 2: Symbolic links (ALWAYS)
    if (shield_check_symlinks_advanced()) {
        return 1;
    }

    // Method 3: Environment variables (ALWAYS)
    if (shield_check_dyld_environment()) {
        return 1;
    }

    // Method 4: Loaded libraries (ALWAYS)
    if (shield_check_loaded_libraries()) {
        return 1;
    }

    // Method 5: URL schemes (STANDARD+)
    #if SHIELD_JAILBREAK_SENSITIVITY >= 1
    if (shield_check_url_schemes()) {
        return 1;
    }
    #endif

    // Method 6: Write permissions (ALWAYS)
    if (shield_check_write_permissions()) {
        return 1;
    }

    // Method 7: System calls (STANDARD+)
    #if SHIELD_JAILBREAK_SENSITIVITY >= 1
    if (shield_check_system_calls()) {
        return 1;
    }
    #endif

    // Method 8: Fork test (STANDARD+)
    #if SHIELD_JAILBREAK_SENSITIVITY >= 1
    if (shield_check_fork_safe()) {
        return 1;
    }
    #endif

    // Method 9: System file permissions (PARANOID)
    #if SHIELD_JAILBREAK_SENSITIVITY >= 2
    if (shield_check_system_file_permissions()) {
        return 1;
    }
    #endif

    // Method 10: Directory listing (PARANOID)
    #if SHIELD_JAILBREAK_SENSITIVITY >= 2
    if (shield_check_directory_listing()) {
        return 1;
    }
    #endif

    // No jailbreak detected
    return 0;
}


// ============================================================================
// Auto-initialization
// ============================================================================

__attribute__((constructor))
static void shield_anti_jailbreak_init(void) {
    if (shield_is_jailbroken()) {
        #if SHIELD_JAILBREAK_EXIT_ON_DETECT
            exit(-1);
        #endif
    }
}


// ============================================================================
// Public API
// ============================================================================

__attribute__((visibility("default")))
int shield_is_device_jailbroken(void) {
    return shield_is_jailbroken();
}

__attribute__((visibility("default")))
const char* shield_get_jailbreak_version(void) {
    return "Shield iOS Anti-Jailbreak v2.0 Enhanced";
}
