"""
Shield iOS - Instruction Substitution

Replaces simple ARM64 instructions with functionally equivalent but more complex
sequences.

Compatible with Shield .NET and inspired by iXGuard.
"""

from .instruction_substitution_protection import (
    InstructionSubstitutionProtection,
    create_protection
)

__all__ = [
    'InstructionSubstitutionProtection',
    'create_protection'
]
