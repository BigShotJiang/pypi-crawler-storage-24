"""Shield iOS Protections"""

from shield_ios.protections.anti_debug.anti_debug_protection import AntiDebugStage
from shield_ios.protections.anti_jailbreak.anti_jailbreak_protection import AntiJailbreakStage
from shield_ios.protections.strings.string_protection import StringEncryptionStage
from shield_ios.protections.renamer.renamer_protection import RenamerStage
from shield_ios.protections.swift_symbols.symbol_stripper import SwiftSymbolStripperStage
from shield_ios.protections.control_flow.control_flow_protection import ControlFlowStage
from shield_ios.protections.symbol_obfuscation.symbol_obfuscator import SymbolObfuscationProtection

__all__ = [
    'AntiDebugStage',
    'AntiJailbreakStage',
    'StringEncryptionStage',
    'RenamerStage',
    'SwiftSymbolStripperStage',
    'ControlFlowStage',
    'SymbolObfuscationProtection'
]
