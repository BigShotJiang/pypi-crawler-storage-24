/*
 * Shield iOS - Class Encryption Runtime Decryptor
 *
 * Decrypts Objective-C class metadata at runtime
 *
 * WHAT IT DOES:
 * 1. Hooks objc_getClass() to intercept class lookups
 * 2. Decrypts encrypted class data on first access
 * 3. Caches decrypted classes for performance
 * 4. Prevents static analysis of class structures
 *
 * ENCRYPTION:
 * - Class names (class_ro_t->name)
 * - Method names (method_t->name)
 * - Ivar names (ivar_t->name)
 * - Property names (property_t->name)
 *
 * Author: ByteHide Shield iOS
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <objc/runtime.h>
#include <objc/message.h>
#include <dlfcn.h>
#include <pthread.h>

/*============================================================================
 * Configuration
 *============================================================================*/

// Encryption key (will be randomized during protection)
#ifndef SHIELD_CLASS_ENCRYPTION_KEY
#define SHIELD_CLASS_ENCRYPTION_KEY 0x5A
#endif

// Maximum encrypted classes
#define SHIELD_MAX_ENCRYPTED_CLASSES 1024

// Debug output (disable in production)
#ifdef DEBUG
#define SHIELD_DEBUG_LOG(fmt, ...) printf("[ShieldClassEncryption] " fmt "\n", ##__VA_ARGS__)
#else
#define SHIELD_DEBUG_LOG(fmt, ...)
#endif

/*============================================================================
 * Data Structures
 *============================================================================*/

/**
 * Encrypted class entry
 *
 * Stores information about an encrypted Objective-C class
 */
typedef struct {
    const char* encrypted_name;  // Encrypted class name
    char* decrypted_name;        // Decrypted class name (cached)
    void* class_data;            // Pointer to class_ro_t structure
    int is_decrypted;            // Decryption status flag
} shield_encrypted_class_t;

/**
 * Encryption context
 *
 * Global state for class encryption system
 */
typedef struct {
    shield_encrypted_class_t classes[SHIELD_MAX_ENCRYPTED_CLASSES];
    int num_classes;
    pthread_mutex_t lock;
    int initialized;
    unsigned char encryption_key;
} shield_encryption_context_t;

// Global encryption context
static shield_encryption_context_t g_shield_context = {
    .num_classes = 0,
    .initialized = 0,
    .encryption_key = SHIELD_CLASS_ENCRYPTION_KEY
};

// Original objc_getClass function pointer
static Class (*original_objc_getClass)(const char *name) = NULL;

/*============================================================================
 * Encryption/Decryption Functions
 *============================================================================*/

/**
 * XOR-based encryption/decryption
 *
 * Simple but effective encryption for class names
 *
 * @param data: Data to encrypt/decrypt
 * @param length: Length of data
 * @param key: Encryption key
 */
static void shield_xor_crypt(unsigned char* data, size_t length, unsigned char key) {
    for (size_t i = 0; i < length; i++) {
        data[i] ^= key;
    }
}

/**
 * Decrypt a class name
 *
 * @param encrypted_name: Encrypted class name
 * @return: Decrypted class name (caller must free)
 */
static char* shield_decrypt_class_name(const char* encrypted_name) {
    if (!encrypted_name) {
        return NULL;
    }

    size_t length = strlen(encrypted_name);
    char* decrypted = (char*)malloc(length + 1);

    if (!decrypted) {
        return NULL;
    }

    memcpy(decrypted, encrypted_name, length + 1);
    shield_xor_crypt((unsigned char*)decrypted, length, g_shield_context.encryption_key);

    SHIELD_DEBUG_LOG("Decrypted class: %s", decrypted);

    return decrypted;
}

/**
 * Decrypt class metadata
 *
 * Decrypts all metadata associated with a class:
 * - Class name
 * - Method names
 * - Ivar names
 * - Property names
 *
 * @param class_entry: Encrypted class entry
 */
static void shield_decrypt_class_metadata(shield_encrypted_class_t* class_entry) {
    if (!class_entry || class_entry->is_decrypted) {
        return;
    }

    // Decrypt class name
    class_entry->decrypted_name = shield_decrypt_class_name(class_entry->encrypted_name);

    if (!class_entry->decrypted_name) {
        SHIELD_DEBUG_LOG("Failed to decrypt class name");
        return;
    }

    // TODO: Decrypt method names, ivar names, property names
    // This would require parsing the class_ro_t structure
    // For now, we just decrypt the class name

    class_entry->is_decrypted = 1;

    SHIELD_DEBUG_LOG("Class metadata decrypted: %s", class_entry->decrypted_name);
}

/*============================================================================
 * Class Lookup Hooks
 *============================================================================*/

/**
 * Hooked objc_getClass
 *
 * Intercepts class lookups and decrypts classes on first access
 *
 * @param name: Class name to look up
 * @return: Class object
 */
Class shield_hooked_objc_getClass(const char *name) {
    if (!name) {
        return original_objc_getClass(name);
    }

    // Check if this class is encrypted
    pthread_mutex_lock(&g_shield_context.lock);

    for (int i = 0; i < g_shield_context.num_classes; i++) {
        shield_encrypted_class_t* entry = &g_shield_context.classes[i];

        // Check if we need to decrypt this class
        if (!entry->is_decrypted) {
            // Try to match encrypted name
            // In practice, we'd compare hashes or use other techniques
            shield_decrypt_class_metadata(entry);
        }

        // Check if this is the class we're looking for
        if (entry->is_decrypted && entry->decrypted_name &&
            strcmp(entry->decrypted_name, name) == 0) {

            SHIELD_DEBUG_LOG("Found encrypted class: %s", name);

            pthread_mutex_unlock(&g_shield_context.lock);

            // Return the class (it's now decrypted)
            return original_objc_getClass(entry->decrypted_name);
        }
    }

    pthread_mutex_unlock(&g_shield_context.lock);

    // Not an encrypted class, use original function
    return original_objc_getClass(name);
}

/*============================================================================
 * Initialization
 *============================================================================*/

/**
 * Register an encrypted class
 *
 * Called by Shield during protection to register encrypted classes
 *
 * @param encrypted_name: Encrypted class name
 * @param class_data: Pointer to class data
 */
__attribute__((visibility("default")))
void shield_register_encrypted_class(const char* encrypted_name, void* class_data) {
    if (!g_shield_context.initialized) {
        return;
    }

    pthread_mutex_lock(&g_shield_context.lock);

    if (g_shield_context.num_classes >= SHIELD_MAX_ENCRYPTED_CLASSES) {
        SHIELD_DEBUG_LOG("Maximum encrypted classes reached");
        pthread_mutex_unlock(&g_shield_context.lock);
        return;
    }

    shield_encrypted_class_t* entry = &g_shield_context.classes[g_shield_context.num_classes];
    entry->encrypted_name = encrypted_name;
    entry->decrypted_name = NULL;
    entry->class_data = class_data;
    entry->is_decrypted = 0;

    g_shield_context.num_classes++;

    SHIELD_DEBUG_LOG("Registered encrypted class (total: %d)", g_shield_context.num_classes);

    pthread_mutex_unlock(&g_shield_context.lock);
}

/**
 * Initialize class encryption system
 *
 * Sets up hooks and prepares the encryption context
 */
__attribute__((constructor))
static void shield_class_encryption_init(void) {
    SHIELD_DEBUG_LOG("Initializing class encryption runtime");

    // Initialize mutex
    pthread_mutex_init(&g_shield_context.lock, NULL);

    // Save original objc_getClass
    original_objc_getClass = (Class (*)(const char *))dlsym(RTLD_DEFAULT, "objc_getClass");

    if (!original_objc_getClass) {
        SHIELD_DEBUG_LOG("Failed to find objc_getClass");
        return;
    }

    // TODO: Hook objc_getClass using method swizzling or dyld interposing
    // For now, we just save the pointer
    // In production, we'd use:
    // - dyld_interpose (dyld interposing)
    // - or fishhook (Facebook's hooking library)

    g_shield_context.initialized = 1;

    SHIELD_DEBUG_LOG("Class encryption runtime initialized");
}

/**
 * Cleanup
 */
__attribute__((destructor))
static void shield_class_encryption_cleanup(void) {
    SHIELD_DEBUG_LOG("Cleaning up class encryption runtime");

    pthread_mutex_lock(&g_shield_context.lock);

    // Free decrypted names
    for (int i = 0; i < g_shield_context.num_classes; i++) {
        if (g_shield_context.classes[i].decrypted_name) {
            free(g_shield_context.classes[i].decrypted_name);
        }
    }

    g_shield_context.num_classes = 0;

    pthread_mutex_unlock(&g_shield_context.lock);
    pthread_mutex_destroy(&g_shield_context.lock);
}

/*============================================================================
 * Public API
 *============================================================================*/

/**
 * Get number of encrypted classes
 */
__attribute__((visibility("default")))
int shield_get_encrypted_class_count(void) {
    return g_shield_context.num_classes;
}

/**
 * Get encryption statistics
 */
__attribute__((visibility("default")))
void shield_get_encryption_stats(int* total, int* decrypted) {
    pthread_mutex_lock(&g_shield_context.lock);

    *total = g_shield_context.num_classes;
    *decrypted = 0;

    for (int i = 0; i < g_shield_context.num_classes; i++) {
        if (g_shield_context.classes[i].is_decrypted) {
            (*decrypted)++;
        }
    }

    pthread_mutex_unlock(&g_shield_context.lock);
}

/*
 * Version information
 */
__attribute__((visibility("default")))
const char* shield_class_encryption_version(void) {
    return "Shield iOS Class Encryption v1.0.0";
}
