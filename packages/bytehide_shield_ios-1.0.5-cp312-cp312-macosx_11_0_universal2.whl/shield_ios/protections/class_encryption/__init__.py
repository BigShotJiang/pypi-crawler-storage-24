"""Shield iOS - Class Encryption Protection"""

from shield_ios.protections.class_encryption.class_encryption_protection import ClassEncryptionStage

__all__ = ['ClassEncryptionStage']
