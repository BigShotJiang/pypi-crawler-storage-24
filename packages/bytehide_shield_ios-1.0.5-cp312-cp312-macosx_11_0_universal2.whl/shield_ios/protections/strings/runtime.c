/*
 * Shield iOS - String Decryption Runtime
 *
 * Decrypts encrypted strings at runtime
 * Compatible with Shield .NET string decryption patterns
 *
 * Usage:
 *   const char* str = ShieldGetString(index);
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

// Encrypted string structure (must be defined before use)
typedef struct {
    uint32_t index;
    uint32_t length;
    const uint8_t* data;
} EncryptedString;

// PLACEHOLDER: These will be generated and replaced during encryption
// #define ENCRYPTION_KEY_PLACEHOLDER
// #define ENCRYPTED_STRINGS_PLACEHOLDER

// Default key (will be replaced)
static const uint8_t ENCRYPTION_KEY[] = { 0x00 };

// Default empty table (will be replaced)
static const EncryptedString ENCRYPTED_STRINGS[] = { {0, 0, NULL} };
static const uint32_t NUM_STRINGS = 0;

// Decryption buffer (thread-local for thread safety)
#define MAX_STRING_LENGTH 4096
static __thread char decryption_buffer[MAX_STRING_LENGTH];

/*
 * XOR decryption
 *
 * Args:
 *   encrypted: Encrypted data
 *   length: Length of encrypted data
 *   output: Output buffer
 *
 * Returns:
 *   Decrypted string in output buffer
 */
__attribute__((always_inline))
static inline void xor_decrypt(const uint8_t* encrypted, uint32_t length, char* output) {
    uint32_t key_length = sizeof(ENCRYPTION_KEY);

    for (uint32_t i = 0; i < length && i < MAX_STRING_LENGTH - 1; i++) {
        output[i] = encrypted[i] ^ ENCRYPTION_KEY[i % key_length];
    }

    // Null-terminate
    output[length < MAX_STRING_LENGTH ? length : MAX_STRING_LENGTH - 1] = '\0';
}

/*
 * Get decrypted string by index
 *
 * This is the main API function called from the protected app.
 *
 * Args:
 *   index: String index
 *
 * Returns:
 *   Decrypted string (valid until next call in same thread)
 */
__attribute__((visibility("default")))
const char* ShieldGetString(uint32_t index) {
    // Check bounds
    if (index >= NUM_STRINGS) {
        return "";
    }

    // Get encrypted string
    const EncryptedString* enc_str = &ENCRYPTED_STRINGS[index];

    // Decrypt using XOR
    xor_decrypt(enc_str->data, enc_str->length, decryption_buffer);

    return decryption_buffer;
}

/*
 * Get number of encrypted strings
 *
 * Returns:
 *   Total number of encrypted strings
 */
__attribute__((visibility("default")))
uint32_t ShieldGetStringCount(void) {
    return NUM_STRINGS;
}

/*
 * Initialize string decryption system
 * Called automatically on load
 */
__attribute__((constructor))
__attribute__((visibility("hidden")))
void shield_strings_init(void) {
    // Initialization code (if needed)
    // For now, just a placeholder
}

/*
 * Alternative API: Get string with explicit length
 *
 * Args:
 *   index: String index
 *   out_length: Output parameter for string length
 *
 * Returns:
 *   Decrypted string
 */
__attribute__((visibility("default")))
const char* ShieldGetStringWithLength(uint32_t index, uint32_t* out_length) {
    if (index >= NUM_STRINGS) {
        if (out_length) *out_length = 0;
        return "";
    }

    const EncryptedString* enc_str = &ENCRYPTED_STRINGS[index];

    xor_decrypt(enc_str->data, enc_str->length, decryption_buffer);

    if (out_length) {
        *out_length = enc_str->length;
    }

    return decryption_buffer;
}
