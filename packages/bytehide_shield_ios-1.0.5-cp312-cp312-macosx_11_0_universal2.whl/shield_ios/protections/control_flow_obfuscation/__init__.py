"""
Shield iOS - Control Flow Obfuscation

Transforms control flow to make reverse engineering harder.

Compatible with Shield .NET ControlFlow protection.
"""

from .control_flow_protection import (
    ControlFlowProtection,
    create_protection
)

__all__ = [
    'ControlFlowProtection',
    'create_protection'
]
