#!/usr/bin/env python3
"""Shield iOS - Opaque Predicates Protection

This module implements opaque predicate injection for ARM64 binaries to obfuscate
control flow and confuse static analysis tools.

Main components:
- OpaquePredicateGenerator: Generates various types of opaque predicates
- ARM64PredicateInjector: Injects predicates into binary
- FakeCodeGenerator: Generates convincing dead code for false branches
- OpaquePredicatesProtection: Main protection stage

Example usage:
    from shield_ios.protections.opaque_predicates import create_protection

    protection = create_protection(logger, complexity='medium')
    protected_binary = protection.execute(binary_path)
"""

from .opaque_predicate_generator import (
    OpaquePredicateType,
    OpaquePredicate,
    OpaquePredicateGenerator
)

from .arm64_predicate_injector import (
    PredicateInjectionPoint,
    ARM64PredicateInjector
)

from .fake_code_generator import (
    FakeCodeGenerator,
    FakeCodePattern
)

from .opaque_predicates_protection import (
    OpaquePredicatesProtection,
    create_protection
)

__all__ = [
    # Predicate generation
    'OpaquePredicateType',
    'OpaquePredicate',
    'OpaquePredicateGenerator',

    # ARM64 injection
    'PredicateInjectionPoint',
    'ARM64PredicateInjector',

    # Fake code generation
    'FakeCodeGenerator',
    'FakeCodePattern',

    # Main protection
    'OpaquePredicatesProtection',
    'create_protection',
]
