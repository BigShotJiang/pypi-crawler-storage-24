/*
 * Shield iOS - Control Flow Obfuscation Runtime
 *
 * Provides obfuscated utility functions that apps can use.
 * Makes static analysis harder without modifying ARM64 instructions.
 *
 * SAFE APPROACH: Pure C code injection, no binary modification.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <time.h>

// ============================================================================
// Opaque Predicates - Always true/false but hard to determine statically
// ============================================================================

/**
 * Opaque predicate that always evaluates to true
 *
 * Uses mathematical property: (x * x) >= 0 for all real x
 *
 * Static analyzers cannot easily prove this is always true
 */
__attribute__((visibility("hidden")))
static inline bool shield_opaque_true(int x) {
    // (x * x) >= 0 is always true
    // But static analyzer needs to prove it
    int y = x * x;

    // Add some extra complexity
    int z = (y >> 1) + (y & 1);

    return (z >= 0);
}

/**
 * Opaque predicate that always evaluates to false
 *
 * Uses mathematical property: (x^2 + y^2 + 1) > (x + y)^2 is always false
 */
__attribute__((visibility("hidden")))
static inline bool shield_opaque_false(int x, int y) {
    // (x^2 + y^2 + 1) > (x + y)^2 is mathematically always false
    // But requires algebraic analysis to prove

    int lhs = (x * x) + (y * y) + 1;
    int rhs_temp = x + y;
    int rhs = rhs_temp * rhs_temp;

    return (lhs > rhs);
}

/**
 * Opaque value - Returns x but in a hard-to-analyze way
 *
 * Uses identity: x = (x * 2) - x
 */
__attribute__((visibility("hidden")))
static inline int shield_opaque_identity(int x) {
    // x = (x * 2) - x
    // Trivial algebraically, but adds indirection

    volatile int temp = x * 2;  // volatile prevents optimization
    return temp - x;
}


// ============================================================================
// Fake Conditional Branches - Dead code that looks alive
// ============================================================================

/**
 * Fake conditional that never executes but looks like it might
 *
 * Returns input unchanged, but appears to have complex branching
 */
__attribute__((visibility("hidden")))
static int shield_fake_branch_complex(int input) {
    int result = input;

    // This branch will NEVER execute (opaque false)
    // But static analyzer cannot easily prove it
    if (shield_opaque_false(result, result)) {
        // Dead code - never executes
        result = result * 999 + 42;
        result = result ^ 0xDEADBEEF;
        result = ~result;
    }

    // This branch ALWAYS executes (opaque true)
    if (shield_opaque_true(result)) {
        // This is the real logic
        result = shield_opaque_identity(result);
    }

    return result;
}


// ============================================================================
// Obfuscated Arithmetic - Simple operations made complex
// ============================================================================

/**
 * Obfuscated addition: a + b
 *
 * Uses identity: a + b = (a ^ b) + 2 * (a & b)
 * (Mixed Boolean-Arithmetic)
 */
__attribute__((visibility("hidden")))
static inline int shield_obf_add(int a, int b) {
    // a + b = (a XOR b) + 2 * (a AND b)
    int xor_part = a ^ b;
    int and_part = a & b;
    int shifted = and_part << 1;

    return xor_part + shifted;
}

/**
 * Obfuscated subtraction: a - b
 *
 * Uses identity: a - b = (a ^ b) - 2 * (~a & b)
 */
__attribute__((visibility("hidden")))
static inline int shield_obf_sub(int a, int b) {
    // a - b = (a XOR b) - 2 * ((NOT a) AND b)
    int xor_part = a ^ b;
    int and_part = (~a) & b;
    int shifted = and_part << 1;

    return xor_part - shifted;
}

/**
 * Obfuscated multiplication by constant
 *
 * Replaces simple multiply with shift-add sequence
 */
__attribute__((visibility("hidden")))
static inline int shield_obf_mul_const(int x, int constant) {
    // Example: x * 7 = (x << 3) - x
    // Different for each constant

    int result = 0;

    // Decompose constant into powers of 2
    // This is a simplified version - real one would handle any constant

    if (constant == 2) {
        result = x << 1;
    } else if (constant == 3) {
        result = (x << 1) + x;
    } else if (constant == 5) {
        result = (x << 2) + x;
    } else if (constant == 7) {
        result = (x << 3) - x;
    } else {
        // Fallback
        result = x * constant;
    }

    return result;
}


// ============================================================================
// Block Splitting - Divide basic blocks to confuse analysis
// ============================================================================

/**
 * Example of block splitting - Simple validation split into multiple blocks
 *
 * Original:
 *   if (x > 0 && x < 100) return true;
 *   return false;
 *
 * Obfuscated: Split into multiple blocks with opaque predicates
 */
__attribute__((visibility("hidden")))
static bool shield_validate_range_obfuscated(int x) {
    bool result = false;

    // Block 1: Check lower bound
    if (shield_opaque_true(x)) {
        if (x > 0) {
            result = true;  // Tentative

            // Block 2: Check upper bound
            if (shield_opaque_true(x)) {
                if (x >= 100) {
                    result = false;  // Out of range
                }

                // Block 3: Fake check (never executes)
                if (shield_opaque_false(x, x)) {
                    result = !result;  // Dead code
                }
            }
        }
    }

    return result;
}


// ============================================================================
// Flattening Simulation - Dispatcher pattern for control flow
// ============================================================================

/**
 * Control flow flattening example
 *
 * Original linear flow converted to switch-based dispatcher
 * Makes it harder to follow execution flow statically
 */
__attribute__((visibility("hidden")))
static int shield_flattened_function(int input) {
    int state = 0;
    int result = input;

    // Dispatcher loop
    while (state != 99) {
        switch (state) {
            case 0:
                // First block
                result = shield_obf_add(result, 10);
                state = 1;
                break;

            case 1:
                // Second block
                if (result > 100) {
                    state = 2;
                } else {
                    state = 3;
                }
                break;

            case 2:
                // Branch 1
                result = shield_obf_sub(result, 50);
                state = 4;
                break;

            case 3:
                // Branch 2
                result = shield_obf_mul_const(result, 2);
                state = 4;
                break;

            case 4:
                // Final block
                result = shield_opaque_identity(result);
                state = 99;  // Exit
                break;

            default:
                // Should never reach here
                state = 99;
                break;
        }
    }

    return result;
}


// ============================================================================
// Public API - Apps can call these obfuscated functions
// ============================================================================

/**
 * Public obfuscated integer validation
 *
 * Example usage from Swift/ObjC:
 *   extern bool shield_validate_int(int value, int min, int max);
 *   if (shield_validate_int(age, 0, 150)) { ... }
 */
__attribute__((visibility("default")))
bool shield_validate_int(int value, int min, int max) {
    // Use obfuscated operations
    bool above_min = (shield_obf_sub(value, min) >= 0);
    bool below_max = (shield_obf_sub(max, value) >= 0);

    // Use opaque predicates
    if (shield_opaque_true(value)) {
        return above_min && below_max;
    }

    return false;  // Should never reach (opaque true always true)
}

/**
 * Public obfuscated hash function
 *
 * Simple hash but with obfuscated control flow
 *
 * Example usage:
 *   extern uint32_t shield_hash_string(const char* str);
 *   uint32_t hash = shield_hash_string("password");
 */
__attribute__((visibility("default")))
uint32_t shield_hash_string(const char* str) {
    if (!str) return 0;

    uint32_t hash = 5381;
    int c;
    int state = 0;

    // Flattened hash loop
    const char* ptr = str;

    while (*ptr) {
        c = *ptr++;

        // Obfuscated hash update
        hash = ((hash << 5) + hash) + c;  // hash * 33 + c

        // Add fake branches
        if (shield_opaque_false(hash, c)) {
            hash = ~hash;  // Never executes
        }

        // Use obfuscated arithmetic
        hash = shield_fake_branch_complex(hash);
    }

    return hash;
}

/**
 * Public obfuscated comparison function
 *
 * Compare two strings but with obfuscated flow
 *
 * Example usage:
 *   extern bool shield_strings_equal(const char* a, const char* b);
 *   if (shield_strings_equal(input, "secret")) { ... }
 */
__attribute__((visibility("default")))
bool shield_strings_equal(const char* a, const char* b) {
    if (!a || !b) return false;

    bool equal = true;
    int i = 0;

    // Obfuscated comparison loop
    while (shield_opaque_true(i)) {
        char ca = a[i];
        char cb = b[i];

        // Check if at end of both strings
        if (ca == '\0' && cb == '\0') {
            break;  // Both ended - equal so far
        }

        // Check if one ended but not the other
        if (ca == '\0' || cb == '\0') {
            equal = false;
            break;
        }

        // Compare characters using obfuscated arithmetic
        int diff = shield_obf_sub((int)ca, (int)cb);

        if (diff != 0) {
            equal = false;

            // Fake branch - never skips
            if (shield_opaque_false(diff, i)) {
                equal = true;  // Dead code
            }

            break;
        }

        i = shield_obf_add(i, 1);
    }

    return equal;
}

/**
 * Public obfuscated array sum
 *
 * Sum array elements with obfuscated control flow
 *
 * Example usage:
 *   extern int shield_sum_array(const int* arr, int count);
 *   int total = shield_sum_array(values, 10);
 */
__attribute__((visibility("default")))
int shield_sum_array(const int* arr, int count) {
    if (!arr || count <= 0) return 0;

    int sum = 0;
    int state = 0;
    int i = 0;

    // Flattened loop using dispatcher pattern
    while (state != 999) {
        switch (state) {
            case 0:
                // Check if done
                if (i >= count) {
                    state = 999;
                } else {
                    state = 1;
                }
                break;

            case 1:
                // Add element using obfuscated arithmetic
                sum = shield_obf_add(sum, arr[i]);

                // Fake branch
                if (shield_opaque_false(sum, i)) {
                    sum = 0;  // Dead code
                }

                state = 2;
                break;

            case 2:
                // Increment using obfuscated arithmetic
                i = shield_obf_add(i, 1);
                state = 0;  // Back to check
                break;

            default:
                state = 999;
                break;
        }
    }

    return sum;
}


// ============================================================================
// Initialization (Optional)
// ============================================================================

/**
 * Auto-initialization for control flow runtime
 *
 * Runs before main() to set up any necessary state
 */
__attribute__((constructor))
static void shield_control_flow_init(void) {
    // Initialize any state if needed
    // For now, this is just a placeholder

    // Could seed random number generator for runtime randomization
    // srand((unsigned int)time(NULL));
}
