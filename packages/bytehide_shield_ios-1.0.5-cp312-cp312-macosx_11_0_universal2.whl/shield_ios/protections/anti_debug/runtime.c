/*
 * Shield iOS - AntiDebug Runtime
 *
 * Detects and blocks debugger attachment on iOS
 * Compatible with Shield .NET AntiDebug patterns
 *
 * Techniques:
 * 1. ptrace(PT_DENY_ATTACH) - Blocks debugger from attaching
 * 2. sysctl(KERN_PROC) - Detects if process is being traced
 * 3. isatty() - Detects debugger console
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/sysctl.h>
#include <unistd.h>
#include <stdbool.h>

// Import ptrace
#include <sys/ptrace.h>

// Deny attach constant
#ifndef PT_DENY_ATTACH
#define PT_DENY_ATTACH 31
#endif

/*
 * Check if debugger is attached using sysctl
 * Returns: true if debugger detected, false otherwise
 */
__attribute__((always_inline))
static inline bool shield_is_debugger_attached(void) {
    int mib[4];
    struct kinfo_proc info;
    size_t size = sizeof(info);

    // Initialize mib for sysctl
    mib[0] = CTL_KERN;
    mib[1] = KERN_PROC;
    mib[2] = KERN_PROC_PID;
    mib[3] = getpid();

    // Get process info
    if (sysctl(mib, 4, &info, &size, NULL, 0) == -1) {
        // sysctl failed, assume no debugger for safety
        return false;
    }

    // Check if P_TRACED flag is set
    return (info.kp_proc.p_flag & P_TRACED) != 0;
}

/*
 * Check if running in debugger console using isatty
 * Returns: true if debugger console detected
 */
__attribute__((always_inline))
static inline bool shield_is_debugger_console(void) {
    // Check if stderr is a tty (debugger console)
    return isatty(STDERR_FILENO) != 0;
}

/*
 * Deny debugger attachment using ptrace
 * This prevents LLDB/GDB from attaching to the process
 */
__attribute__((always_inline))
static inline void shield_deny_debugger_attach(void) {
    // Call ptrace with PT_DENY_ATTACH
    ptrace(PT_DENY_ATTACH, 0, 0, 0);
}

/*
 * Continuous debugger detection (runs in background)
 * If debugger detected, terminates the app
 */
__attribute__((visibility("hidden")))
void shield_anti_debug_monitor(void) {
    // Check every second for debugger
    while (1) {
        if (shield_is_debugger_attached()) {
            // Debugger detected - exit immediately
            printf("[Shield] Debugger detected - terminating\n");
            exit(-1);
        }
        sleep(1);
    }
}

/*
 * Initialize anti-debug protection
 * Called automatically on app startup via constructor attribute
 */
__attribute__((constructor))
__attribute__((visibility("hidden")))
void shield_anti_debug_init(void) {
    // Method 1: Deny debugger attachment immediately
    shield_deny_debugger_attach();

    // Method 2: Check if already being debugged
    if (shield_is_debugger_attached()) {
        printf("[Shield] Debugger detected at startup - terminating\n");
        exit(-1);
    }

    // Method 3: Check for debugger console
    if (shield_is_debugger_console()) {
        printf("[Shield] Debugger console detected - terminating\n");
        exit(-1);
    }

    // Optional: Start continuous monitoring in background
    // Uncomment if you want continuous checks
    // pthread_t thread;
    // pthread_create(&thread, NULL, (void*)shield_anti_debug_monitor, NULL);
    // pthread_detach(thread);
}

/*
 * Public API: Manual debugger check
 * Returns: true if debugger detected
 */
__attribute__((visibility("default")))
bool ShieldIsDebuggerPresent(void) {
    return shield_is_debugger_attached() || shield_is_debugger_console();
}
