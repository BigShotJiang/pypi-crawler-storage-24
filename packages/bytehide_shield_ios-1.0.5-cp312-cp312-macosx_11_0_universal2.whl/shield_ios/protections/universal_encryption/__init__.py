"""
Shield iOS - Universal Asset Encryption

Encrypts ALL non-executable files in the IPA for maximum protection.

Extends resource encryption to cover:
- Images (PNG, JPG, etc.)
- Videos (MP4, MOV, etc.)
- Fonts (TTF, OTF, etc.)
- JSON files
- Text files
- Audio files
- Any other assets

Compatible with Shield .NET and inspired by iXGuard.
"""

from .universal_encryption_protection import UniversalEncryptionStage

__all__ = ['UniversalEncryptionStage']
