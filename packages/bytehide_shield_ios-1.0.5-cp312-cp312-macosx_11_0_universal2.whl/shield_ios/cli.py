#!/usr/bin/env python3
"""Shield iOS CLI - Main command-line interface
Zero-friction integration, compatible with Shield .NET CLI philosophy
"""

import sys
import click
from pathlib import Path
from typing import Optional

from shield_ios.core.config import Config
from shield_ios.core.context import ShieldContext
from shield_ios.core.pipeline import ProtectionPipeline
from shield_ios.core.macho_parser import MachOParser
from shield_ios import __version__


def print_banner():
    """Print Shield iOS banner"""
    banner = f"""
╔══════════════════════════════════════════════════════════╗
║              Shield iOS v{__version__:<28}║
║         iOS Application Protection & Obfuscation        ║
║                     by ByteHide                          ║
╚══════════════════════════════════════════════════════════╝
    """
    click.echo(banner)


@click.group()
@click.version_option(version=__version__)
def cli():
    """Shield iOS - iOS Application Obfuscator"""
    pass


@cli.command()
@click.option(
    '--input', '-i',
    required=True,
    type=click.Path(exists=True, path_type=Path),
    help='Input binary path (.app or Mach-O executable)'
)
@click.option(
    '--output', '-o',
    required=True,
    type=click.Path(path_type=Path),
    help='Output binary path'
)
@click.option(
    '--config', '-c',
    type=click.Path(exists=True, path_type=Path),
    help='Configuration file (YAML)'
)
@click.option(
    '--rename/--no-rename',
    default=True,
    help='Enable/disable symbol renaming'
)
@click.option(
    '--encrypt-strings/--no-encrypt-strings',
    default=True,
    help='Enable/disable string encryption'
)
@click.option(
    '--anti-debug/--no-anti-debug',
    default=True,
    help='Enable/disable anti-debug protection'
)
@click.option(
    '--anti-jailbreak/--no-anti-jailbreak',
    default=True,
    help='Enable/disable anti-jailbreak detection'
)
@click.option(
    '--mapping-file', '-m',
    type=click.Path(path_type=Path),
    default='mapping.txt',
    help='Output mapping file path'
)
@click.option(
    '--verbose', '-v',
    is_flag=True,
    help='Verbose output (debug logging)'
)
def protect(
    input: Path,
    output: Path,
    config: Optional[Path],
    rename: bool,
    encrypt_strings: bool,
    anti_debug: bool,
    anti_jailbreak: bool,
    mapping_file: Path,
    verbose: bool
):
    """
    Protect an iOS application

    Examples:
        shield-ios protect -i MyApp.app -o MyApp_protected.app

        shield-ios protect -i MyApp.app -o MyApp_protected.app -c shield.yml

        shield-ios protect -i MyApp.app -o MyApp_protected.app --no-rename
    """
    print_banner()

    try:
        # Load configuration
        if config:
            click.echo(f"📄 Loading configuration: {config}")
            cfg = Config.load(config)
        else:
            click.echo("📄 Using default configuration")
            cfg = Config()

        # Override with CLI options
        cfg.input_path = input
        cfg.output_path = output
        cfg.mapping.output_file = str(mapping_file)

        if verbose:
            cfg.logging_config.level = "debug"

        # CLI options override config file
        if not rename:
            cfg.protection.renamer.enabled = False
        if not encrypt_strings:
            cfg.protection.strings.enabled = False
        if not anti_debug:
            cfg.protection.anti_debug.enabled = False
        if not anti_jailbreak:
            cfg.protection.anti_jailbreak.enabled = False

        # Validate configuration
        cfg.validate()

        # Create context
        context = ShieldContext(cfg)
        context.logger.section("Shield iOS Protection Starting")
        context.logger.info(f"Input:  {input}")
        context.logger.info(f"Output: {output}")

        # Parse binary
        context.logger.section("Loading Binary")
        parser = MachOParser(input, context.logger)
        context.binary = parser.binary
        context.binary_path = input

        # Show binary info
        info = parser.get_binary_info()
        context.logger.info(f"CPU Type: {info['cpu_type']}")
        context.logger.info(f"Has Objective-C: {info['has_objc']}")
        context.logger.info(f"Has Swift: {info['has_swift']}")
        context.logger.info(f"Symbols: {info['num_symbols']}")

        # Create pipeline
        pipeline = ProtectionPipeline(context)

        # Add stages based on configuration
        # Note: Actual protection stages will be implemented in Weeks 3-7
        # For now, this is just the skeleton

        if cfg.protection.renamer.enabled:
            context.logger.info("✓ Renamer: Enabled (implementation pending)")
            # TODO: pipeline.add_stage(RenamerStage())

        if cfg.protection.strings.enabled:
            context.logger.info("✓ String Encryption: Enabled (implementation pending)")
            # TODO: pipeline.add_stage(StringEncryptionStage())

        if cfg.protection.anti_debug.enabled:
            context.logger.info("✓ Anti-Debug: Enabled (implementation pending)")
            # TODO: pipeline.add_stage(AntiDebugStage())

        if cfg.protection.anti_jailbreak.enabled:
            context.logger.info("✓ Anti-Jailbreak: Enabled (implementation pending)")
            # TODO: pipeline.add_stage(AntiJailbreakStage())

        # Execute pipeline
        if pipeline.stages:
            pipeline.execute()
        else:
            context.logger.warning("No protection stages enabled - copying binary as-is")

        # Save binary
        context.logger.section("Saving Protected Binary")
        parser.binary_path = output
        if parser.save(output):
            context.logger.success(f"Binary saved: {output}")
        else:
            context.logger.error("Failed to save binary")
            sys.exit(1)

        # Save mapping file
        if context.mappings:
            context.save_mapping_file(mapping_file)

        # Show statistics
        context.log_statistics()

        # Success
        context.logger.section("Protection Complete")
        context.logger.success("Shield iOS protection completed successfully!")

    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        if verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


@cli.command()
@click.argument('binary_path', type=click.Path(exists=True, path_type=Path))
def info(binary_path: Path):
    """
    Display information about a Mach-O binary

    Examples:
        shield-ios info MyApp.app/MyApp
        shield-ios info MyApp
    """
    print_banner()

    try:
        click.echo(f"📱 Analyzing: {binary_path}\n")

        parser = MachOParser(binary_path)
        info = parser.get_binary_info()

        click.echo("Binary Information:")
        click.echo(f"  CPU Type:        {info['cpu_type']}")
        click.echo(f"  File Type:       {info['file_type']}")
        click.echo(f"  Segments:        {info['num_segments']}")
        click.echo(f"  Symbols:         {info['num_symbols']}")
        click.echo(f"  Has Objective-C: {'Yes' if info['has_objc'] else 'No'}")
        click.echo(f"  Has Swift:       {'Yes' if info['has_swift'] else 'No'}")

        # Show sections
        click.echo("\nSections:")
        sections = parser.list_sections()
        for section in sections[:10]:  # Show first 10
            click.echo(f"  - {section}")
        if len(sections) > 10:
            click.echo(f"  ... and {len(sections) - 10} more")

        # Show Swift symbols count
        swift_symbols = parser.get_swift_symbols()
        if swift_symbols:
            click.echo(f"\nSwift Symbols: {len(swift_symbols)}")

        # Show strings count
        strings = parser.get_cstrings()
        if strings:
            click.echo(f"C Strings: {len(strings)}")

    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        sys.exit(1)


@cli.command()
def version():
    """Display version information"""
    print_banner()
    click.echo(f"Version: {__version__}")
    click.echo(f"Python:  {sys.version.split()[0]}")


def main():
    """Main entry point"""
    cli()


if __name__ == '__main__':
    main()
