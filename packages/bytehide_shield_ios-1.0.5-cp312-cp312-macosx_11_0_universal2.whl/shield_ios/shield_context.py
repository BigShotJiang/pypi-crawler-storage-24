#!/usr/bin/env python3
"""Shield iOS - Minimal Context for Pipeline

Simple context object that passes data between pipeline stages
"""

from pathlib import Path
from typing import Optional, Any


class SimpleNamespace:
    """Simple namespace for nested config access"""

    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            if isinstance(value, dict):
                setattr(self, key, SimpleNamespace(**value))
            else:
                setattr(self, key, value)

    def get(self, key: str, default=None):
        """Get attribute with default"""
        return getattr(self, key, default)


class ShieldContext:
    """Minimal context for Shield iOS pipeline

    Passes data between stages without complex inheritance
    """

    def __init__(self, input_file: Optional[Path], output_file: Optional[Path], config: Any, logger: Any):
        """Initialize context

        Args:
            input_file: Input file path
            output_file: Output file path
            config: Shield configuration
            logger: Shield logger
        """
        # I/O
        self.input_file = input_file
        self.output_file = output_file

        # Configuration
        self.shield_config = config  # ShieldConfig instance
        self.logger = logger

        # Create nested config namespace for backward compatibility
        self.config = SimpleNamespace(
            protection=SimpleNamespace(
                anti_debug=SimpleNamespace(),
                anti_jailbreak=SimpleNamespace(),
                string_encryption=SimpleNamespace(),
                strings=SimpleNamespace(exclude=[], algorithm='xor', encryption_key='auto'),  # For string protection
                renamer=SimpleNamespace(),
                swift_stripping=SimpleNamespace(),
                swift_symbols=SimpleNamespace(enabled=True, level='minimal', preserve_public_symbols=True),
                control_flow=SimpleNamespace(),
                code_signing=SimpleNamespace(),
            )
        )

        # Working data (set by pipeline stages)
        self.working_directory: Optional[Path] = None
        self.app_bundle_path: Optional[Path] = None
        self.binary_path: Optional[Path] = None
        self.binary = None  # LIEF Mach-O binary object
        self.app_name: Optional[str] = None
        self.bundle_id: Optional[str] = None
        self.bundle_version: Optional[str] = None
        self.min_ios_version: Optional[str] = None

        # Services registry (stub)
        self.services = SimpleNamespace()
        self.services._registry = {}
        self.services.register = lambda name, obj: self.services._registry.update({name: obj})
        self.services.get = lambda name: self.services._registry.get(name)

    def increment_stat(self, key: str, value: int = 1) -> None:
        """Increment a statistic (stub for compatibility)"""
        # Simplified - just log for now
        pass

    def add_mapping(self, category: str, original: str, obfuscated: str) -> None:
        """Add obfuscation mapping (stub for compatibility)"""
        # Simplified - just log for now
        pass

    def __repr__(self) -> str:
        """String representation"""
        return f"ShieldContext(input={self.input_file}, output={self.output_file})"
