#!/usr/bin/env python3
"""Shield iOS - Ultra-Simple CLI

Like Shield .NET NuGet package - just install and protect!

Usage:
    shield-ios protect MyApp.ipa
    shield-ios protect MyApp.ipa --config shield-ios.json
    shield-ios protect MyApp.ipa --output MyApp_secure.ipa

Super simple! 🎉
"""

import sys
import argparse
from pathlib import Path
from typing import Optional

from shield_ios import __version__ as VERSION
from shield_ios.shield_config import ShieldConfig
from shield_ios.shield_logger import ShieldLogger
from shield_ios.shield_pipeline import ShieldPipeline


def main():
    """Main entry point for Shield iOS CLI"""

    # Parse arguments
    parser = argparse.ArgumentParser(
        description="Shield iOS - iOS Application Protection & Obfuscation",
        epilog="https://docs.bytehide.com/platforms/ios/products/shield"
    )

    parser.add_argument(
        'command',
        choices=['protect', 'version', 'init'],
        help='Command to execute'
    )

    parser.add_argument(
        'input_ipa',
        nargs='?',
        type=Path,
        help='Input IPA file to protect'
    )

    parser.add_argument(
        '--config', '-c',
        type=Path,
        help='Configuration file (shield-ios.json)'
    )

    parser.add_argument(
        '--output', '-o',
        type=Path,
        help='Output IPA file (default: input_protected.ipa)'
    )

    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Verbose output'
    )

    args = parser.parse_args()

    # Create logger
    logger = ShieldLogger(verbose=args.verbose)

    # Handle commands
    if args.command == 'version':
        show_version(logger)
        return 0

    elif args.command == 'init':
        init_config(logger)
        return 0

    elif args.command == 'protect':
        if not args.input_ipa:
            logger.error("Error: input_ipa is required for 'protect' command")
            logger.info("Usage: shield-ios protect MyApp.ipa")
            return 1

        return protect(args.input_ipa, args.output, args.config, logger)

    return 0


def show_version(logger: ShieldLogger):
    """Show version information

    Args:
        logger: Shield logger
    """
    logger.banner(VERSION)
    print(f"Version: {VERSION}")
    print(f"Python:  {sys.version.split()[0]}")
    print()
    print("https://docs.bytehide.com/platforms/ios/products/shield")


def init_config(logger: ShieldLogger):
    """Initialize shield-ios.json configuration file

    Args:
        logger: Shield logger
    """
    logger.banner(VERSION)
    logger.info("Creating default configuration file...")

    config_path = Path('shield-ios.json')

    if config_path.exists():
        logger.warning(f"{config_path} already exists!")
        response = input("Overwrite? (y/N): ")
        if response.lower() != 'y':
            logger.info("Aborted")
            return

    # Create default config
    config = ShieldConfig.default()
    config.save(config_path)

    logger.success(f"Created: {config_path}")
    logger.info("")
    logger.info("Example configuration:")
    logger.info("")
    logger.info("  {")
    logger.info('    "protections": {')
    logger.info('      "anti_debug": true,')
    logger.info('      "anti_jailbreak": {')
    logger.info('        "enabled": true,')
    logger.info('        "sensitivity": 1')
    logger.info('      },')
    logger.info('      "string_encryption": true,')
    logger.info('      "symbol_renaming": true,')
    logger.info('      "swift_stripping": true,')
    logger.info('      "control_flow": "light"')
    logger.info('    },')
    logger.info('    "code_signing": {')
    logger.info('      "identity": "iPhone Developer: ...",')
    logger.info('      "skip_if_not_macos": true')
    logger.info('    }')
    logger.info('  }')
    logger.info("")
    logger.info("Edit shield-ios.json to customize protections")
    logger.info("")
    logger.info("Then run: shield-ios protect MyApp.ipa")


def protect(input_ipa: Path, output_ipa: Optional[Path], config_path: Optional[Path], logger: ShieldLogger) -> int:
    """Protect an IPA file

    Args:
        input_ipa: Input IPA path
        output_ipa: Output IPA path (optional)
        config_path: Configuration file path (optional)
        logger: Shield logger

    Returns:
        Exit code (0 = success, 1 = error)
    """
    logger.banner(VERSION)

    try:
        # Validate input
        if not input_ipa.exists():
            logger.error(f"Input file not found: {input_ipa}")
            return 1

        if not input_ipa.suffix == '.ipa':
            logger.error(f"Input must be .ipa file, got: {input_ipa.suffix}")
            return 1

        # Load configuration
        if config_path:
            if not config_path.exists():
                logger.error(f"Config file not found: {config_path}")
                return 1

            logger.info(f"Loading config: {config_path}")
            config = ShieldConfig.load(config_path)
        else:
            # Check for shield-ios.json in current directory
            default_config = Path('shield-ios.json')
            if default_config.exists():
                logger.info(f"Loading config: {default_config}")
                config = ShieldConfig.load(default_config)
            else:
                logger.info("Using default configuration")
                logger.info("(run 'shield-ios init' to create shield-ios.json)")
                config = ShieldConfig.default()

        # Validate configuration (requires project token)
        try:
            config.validate()
        except ValueError as e:
            logger.error(f"Configuration error: {e}")
            return 1

        # Create pipeline
        pipeline = ShieldPipeline(config, logger)

        # Protect!
        output = pipeline.protect(input_ipa, output_ipa)

        logger.section("Success!")
        logger.success("Your iOS app is now protected! 🛡️")
        logger.info("")
        logger.info(f"Protected IPA: {output}")
        logger.info(f"Size: {output.stat().st_size / (1024*1024):.2f} MB")
        logger.info("")
        logger.info("Install it on your device and enjoy the protection!")

        return 0

    except KeyboardInterrupt:
        logger.warning("\nAborted by user")
        return 1

    except Exception as e:
        from shield_ios.licensing import CloudException
        if not isinstance(e, CloudException):
            logger.error(f"Protection failed: {e}")
        if logger.verbose:
            import traceback
            traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())
