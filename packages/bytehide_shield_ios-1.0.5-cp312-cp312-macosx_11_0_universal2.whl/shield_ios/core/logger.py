"""Shield iOS Logger - Logging framework
Similar to Shield .NET logging system
"""

import logging
import sys
from typing import Optional
from pathlib import Path
from colorama import Fore, Style, init

# Initialize colorama
init(autoreset=True)


class ColoredFormatter(logging.Formatter):
    """Custom formatter with colors for console output"""

    COLORS = {
        'DEBUG': Fore.CYAN,
        'INFO': Fore.GREEN,
        'WARNING': Fore.YELLOW,
        'ERROR': Fore.RED,
        'CRITICAL': Fore.RED + Style.BRIGHT,
    }

    PREFIXES = {
        'DEBUG': '🔍',
        'INFO': '✓',
        'WARNING': '⚠️',
        'ERROR': '✗',
        'CRITICAL': '🔥',
    }

    def format(self, record):
        color = self.COLORS.get(record.levelname, '')
        prefix = self.PREFIXES.get(record.levelname, '')
        record.levelname = f"{color}{prefix} {record.levelname}{Style.RESET_ALL}"
        return super().format(record)


class Logger:
    """
    Shield iOS Logger

    Compatible with Shield .NET logging philosophy:
    - Console output with colors
    - File output for debugging
    - Structured messages
    """

    def __init__(self, name: str = "shield-ios", level: str = "INFO"):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(getattr(logging, level.upper()))
        self.logger.handlers.clear()  # Clear existing handlers

        # Console handler with colors
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.DEBUG)
        console_formatter = ColoredFormatter(
            '%(levelname)s | %(message)s'
        )
        console_handler.setFormatter(console_formatter)
        self.logger.addHandler(console_handler)

        self.file_handler: Optional[logging.FileHandler] = None

    def add_file_handler(self, log_file: Path):
        """Add file handler for persistent logging"""
        if self.file_handler:
            self.logger.removeHandler(self.file_handler)

        self.file_handler = logging.FileHandler(log_file, mode='w', encoding='utf-8')
        self.file_handler.setLevel(logging.DEBUG)
        file_formatter = logging.Formatter(
            '%(asctime)s | %(levelname)-8s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        self.file_handler.setFormatter(file_formatter)
        self.logger.addHandler(self.file_handler)

    def debug(self, message: str):
        """Debug level message"""
        self.logger.debug(message)

    def info(self, message: str):
        """Info level message"""
        self.logger.info(message)

    def warning(self, message: str):
        """Warning level message"""
        self.logger.warning(message)

    def error(self, message: str):
        """Error level message"""
        self.logger.error(message)

    def critical(self, message: str):
        """Critical level message"""
        self.logger.critical(message)

    def section(self, title: str):
        """Log a section header (like Shield .NET)"""
        separator = "─" * 60
        self.info(f"\n{separator}")
        self.info(f"  {title}")
        self.info(f"{separator}")

    def success(self, message: str):
        """Log success message with special formatting"""
        self.info(f"✅ {message}")

    def step(self, step_num: int, total: int, message: str):
        """Log pipeline step (like Shield .NET stages)"""
        self.info(f"[{step_num}/{total}] {message}")

    def progress(self, current: int, total: int, item: str):
        """Log progress for batch operations"""
        percentage = (current / total) * 100
        self.debug(f"  └─ [{current}/{total}] ({percentage:.1f}%) {item}")


# Global logger instance (similar to Shield .NET)
_default_logger: Optional[Logger] = None


def get_logger(name: str = "shield-ios", level: str = "INFO") -> Logger:
    """Get or create default logger instance"""
    global _default_logger
    if _default_logger is None:
        _default_logger = Logger(name, level)
    return _default_logger
