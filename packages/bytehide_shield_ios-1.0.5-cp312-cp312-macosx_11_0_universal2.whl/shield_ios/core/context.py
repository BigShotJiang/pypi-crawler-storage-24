"""Shield iOS Context - Global state management
Similar to Shield .NET Context and ServiceRegistry pattern
"""

from typing import Dict, Any, Optional, Type, TypeVar
from pathlib import Path
import lief

from shield_ios.core.config import Config
from shield_ios.core.logger import Logger

T = TypeVar('T')


class ServiceRegistry:
    """
    Service Registry Pattern (like Shield .NET)

    Manages registered services that can be shared across
    different protection stages.
    """

    def __init__(self):
        self._services: Dict[str, Any] = {}

    def register(self, name: str, service: Any) -> None:
        """Register a service by name"""
        self._services[name] = service

    def get(self, name: str, default: Any = None) -> Any:
        """Get a service by name"""
        return self._services.get(name, default)

    def get_typed(self, name: str, service_type: Type[T]) -> Optional[T]:
        """Get a service with type checking"""
        service = self._services.get(name)
        if service and isinstance(service, service_type):
            return service
        return None

    def has(self, name: str) -> bool:
        """Check if a service is registered"""
        return name in self._services

    def unregister(self, name: str) -> None:
        """Unregister a service"""
        if name in self._services:
            del self._services[name]

    def clear(self) -> None:
        """Clear all registered services"""
        self._services.clear()

    def __repr__(self) -> str:
        return f"ServiceRegistry(services={list(self._services.keys())})"


class ShieldContext:
    """
    Shield iOS Context - Global execution context

    Compatible with Shield .NET Context architecture:
    - Holds configuration
    - Manages binary state
    - Provides service registry
    - Tracks mappings
    - Handles logging

    This is the central object passed through the protection pipeline.
    """

    def __init__(self, config: Config):
        self.config = config

        # Logging
        self.logger = Logger(
            name="shield-ios",
            level=config.logging_config.level.upper()
        )
        if config.logging_config.file:
            log_path = Path(config.logging_config.file)
            self.logger.add_file_handler(log_path)

        # Service registry
        self.services = ServiceRegistry()

        # Binary state
        self.binary: Optional[lief.MachO.Binary] = None
        self.binary_path: Optional[Path] = None

        # Mappings (ProGuard-style: original -> obfuscated)
        self.mappings: Dict[str, Dict[str, str]] = {
            'classes': {},      # Class name mappings
            'methods': {},      # Method name mappings
            'properties': {},   # Property name mappings
            'protocols': {},    # Protocol name mappings
            'strings': {},      # String mappings (original -> encrypted)
        }

        # Reverse mappings (obfuscated -> original)
        self.reverse_mappings: Dict[str, Dict[str, str]] = {
            'classes': {},
            'methods': {},
            'properties': {},
            'protocols': {},
            'strings': {},
        }

        # Statistics (for logging)
        self.stats: Dict[str, int] = {
            'classes_renamed': 0,
            'methods_renamed': 0,
            'properties_renamed': 0,
            'strings_encrypted': 0,
        }

        # Working directory (for temporary files)
        self.work_dir: Optional[Path] = None

    def add_mapping(self, category: str, original: str, obfuscated: str) -> None:
        """
        Add a mapping (original -> obfuscated)

        Args:
            category: Category (classes, methods, properties, etc.)
            original: Original name
            obfuscated: Obfuscated name
        """
        if category not in self.mappings:
            self.mappings[category] = {}
            self.reverse_mappings[category] = {}

        self.mappings[category][original] = obfuscated
        self.reverse_mappings[category][obfuscated] = original

    def get_mapping(self, category: str, original: str) -> Optional[str]:
        """Get obfuscated name for original"""
        return self.mappings.get(category, {}).get(original)

    def get_reverse_mapping(self, category: str, obfuscated: str) -> Optional[str]:
        """Get original name for obfuscated"""
        return self.reverse_mappings.get(category, {}).get(obfuscated)

    def has_mapping(self, category: str, original: str) -> bool:
        """Check if mapping exists"""
        return original in self.mappings.get(category, {})

    def increment_stat(self, stat_name: str, count: int = 1) -> None:
        """Increment a statistic counter"""
        if stat_name not in self.stats:
            self.stats[stat_name] = 0
        self.stats[stat_name] += count

    def get_stat(self, stat_name: str) -> int:
        """Get a statistic value"""
        return self.stats.get(stat_name, 0)

    def save_mapping_file(self, output_path: Optional[Path] = None) -> None:
        """
        Save mapping file in ProGuard-compatible format

        Format:
            OriginalClass -> a:
                originalMethod -> x1
                originalProperty -> p1
        """
        if output_path is None:
            output_path = Path(self.config.mapping.output_file)

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write("# Shield iOS Mapping File\n")
            f.write("# Compatible with ProGuard format\n\n")

            # Write class mappings
            if self.mappings['classes']:
                f.write("# Classes\n")
                for original, obfuscated in sorted(self.mappings['classes'].items()):
                    f.write(f"{original} -> {obfuscated}:\n")

                    # Write method mappings for this class
                    class_prefix = f"{original}."
                    for orig_method, obf_method in sorted(self.mappings['methods'].items()):
                        if orig_method.startswith(class_prefix):
                            method_name = orig_method[len(class_prefix):]
                            f.write(f"    {method_name} -> {obf_method}\n")

                    # Write property mappings for this class
                    for orig_prop, obf_prop in sorted(self.mappings['properties'].items()):
                        if orig_prop.startswith(class_prefix):
                            prop_name = orig_prop[len(class_prefix):]
                            f.write(f"    {prop_name} -> {obf_prop}\n")

                f.write("\n")

            # Write string mappings
            if self.mappings['strings']:
                f.write("# Strings (encrypted)\n")
                for original, encrypted_id in sorted(self.mappings['strings'].items()):
                    # Truncate long strings for readability
                    display_str = original[:50] + "..." if len(original) > 50 else original
                    f.write(f'"{display_str}" -> {encrypted_id}\n')

        self.logger.info(f"Mapping file saved: {output_path}")

    def log_statistics(self) -> None:
        """Log final statistics (like Shield .NET)"""
        self.logger.section("Protection Statistics")
        for stat_name, value in sorted(self.stats.items()):
            self.logger.info(f"  {stat_name}: {value}")

    def cleanup(self) -> None:
        """Cleanup temporary resources"""
        if self.work_dir and self.work_dir.exists():
            import shutil
            shutil.rmtree(self.work_dir, ignore_errors=True)

    def __repr__(self) -> str:
        return (
            f"ShieldContext(project={self.config.project_name}, "
            f"binary={self.binary_path}, "
            f"services={self.services})"
        )
