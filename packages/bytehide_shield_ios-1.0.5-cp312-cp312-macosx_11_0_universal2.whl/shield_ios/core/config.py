"""Shield iOS Configuration System
YAML-based configuration compatible with Shield .NET philosophy
"""

import yaml
from pathlib import Path
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field


@dataclass
class RenamerConfig:
    """Renamer/Symbol obfuscation configuration"""
    enabled: bool = True
    mode: str = "short"  # short, unicode, random
    exclude: List[str] = field(default_factory=list)
    rename_classes: bool = True
    rename_methods: bool = True
    rename_properties: bool = True
    rename_protocols: bool = False


@dataclass
class StringsConfig:
    """String encryption configuration"""
    enabled: bool = True
    algorithm: str = "xor"  # xor, aes
    encryption_key: str = "auto"
    exclude: List[str] = field(default_factory=list)


@dataclass
class AntiDebugConfig:
    """Anti-debug configuration"""
    enabled: bool = True
    ptrace: bool = True
    sysctl: bool = True


@dataclass
class AntiJailbreakConfig:
    """Anti-jailbreak configuration"""
    enabled: bool = True
    check_paths: bool = True
    check_cydia: bool = True


@dataclass
class SwiftConfig:
    """Swift symbol configuration"""
    strip_symbols: bool = True
    strip_debug: bool = True
    demangle: bool = False


@dataclass
class MappingConfig:
    """Mapping file configuration (ProGuard-compatible)"""
    output_file: str = "mapping.txt"
    format: str = "proguard"
    include_line_numbers: bool = False


@dataclass
class LoggingConfig:
    """Logging configuration"""
    level: str = "info"  # debug, info, warning, error
    file: Optional[str] = "shield.log"
    console: bool = True


@dataclass
class CodesignConfig:
    """Code signing configuration"""
    enabled: bool = False
    identity: Optional[str] = None
    provisioning_profile: Optional[str] = None


@dataclass
class ProtectionConfig:
    """Protection settings container"""
    renamer: RenamerConfig = field(default_factory=RenamerConfig)
    strings: StringsConfig = field(default_factory=StringsConfig)
    anti_debug: AntiDebugConfig = field(default_factory=AntiDebugConfig)
    anti_jailbreak: AntiJailbreakConfig = field(default_factory=AntiJailbreakConfig)
    swift: SwiftConfig = field(default_factory=SwiftConfig)


class Config:
    """
    Shield iOS Configuration

    Loads and manages configuration from YAML file.
    Compatible with Shield .NET configuration structure.
    """

    def __init__(self, config_path: Optional[Path] = None):
        self.config_path = config_path
        self.raw_config: Dict[str, Any] = {}

        # Project settings
        self.project_name: str = "MyiOSApp"
        self.input_path: Optional[Path] = None
        self.output_path: Optional[Path] = None

        # Protection configuration
        self.protection = ProtectionConfig()

        # Other configurations
        self.mapping = MappingConfig()
        self.logging_config = LoggingConfig()
        self.codesign = CodesignConfig()

        if config_path and config_path.exists():
            self._load_from_file(config_path)

    @classmethod
    def load(cls, config_path: Path) -> "Config":
        """Load configuration from YAML file"""
        config = cls(None)  # Don't pass config_path to avoid recursion
        config._load_from_file(config_path)
        return config

    def _load_from_file(self, config_path: Path) -> None:
        """Internal method to load configuration from file"""

        with open(config_path, 'r', encoding='utf-8') as f:
            self.raw_config = yaml.safe_load(f) or {}

        # Load project settings
        self.project_name = self.raw_config.get('project', 'MyiOSApp')

        # Load project token
        self.project_token = self.raw_config.get('projectToken') or self.raw_config.get('project_token')

        input_str = self.raw_config.get('input')
        if input_str:
            self.input_path = Path(input_str)

        output_cfg = self.raw_config.get('output')
        if output_cfg:
            if isinstance(output_cfg, str):
                self.output_path = Path(output_cfg)
            elif isinstance(output_cfg, dict):
                # Output is a dict with 'suffix' or 'path'
                if 'path' in output_cfg:
                    self.output_path = Path(output_cfg['path'])
                # suffix will be handled later

        # Load protection settings
        protection_config = self.raw_config.get('protection', {}) or self.raw_config.get('protections', {})
        self._load_protection_config(protection_config)

        # Load mapping settings
        mapping_config = self.raw_config.get('mapping', {})
        self._load_mapping_config(mapping_config)

        # Load logging settings
        logging_config = self.raw_config.get('logging', {})
        self._load_logging_config(logging_config)

        # Load codesign settings
        codesign_config = self.raw_config.get('codesign', {}) or self.raw_config.get('code_signing', {})
        self._load_codesign_config(codesign_config)

    def _load_protection_config(self, protection_dict: Dict[str, Any]):
        """Load protection configuration"""

        # Renamer configuration (support both 'renamer' and 'symbol_renaming')
        renamer_dict = protection_dict.get('renamer', {}) or protection_dict.get('symbol_renaming', {})
        if isinstance(renamer_dict, bool):
            renamer_dict = {'enabled': renamer_dict}
        self.protection.renamer = RenamerConfig(
            enabled=renamer_dict.get('enabled', True),
            mode=renamer_dict.get('mode', 'short'),
            exclude=renamer_dict.get('exclude', []),
            rename_classes=renamer_dict.get('rename_classes', True),
            rename_methods=renamer_dict.get('rename_methods', True),
            rename_properties=renamer_dict.get('rename_properties', True),
            rename_protocols=renamer_dict.get('rename_protocols', False),
        )

        # Strings configuration (support both 'strings' and 'string_encryption')
        strings_dict = protection_dict.get('strings', {}) or protection_dict.get('string_encryption', {})
        if isinstance(strings_dict, bool):
            strings_dict = {'enabled': strings_dict}
        self.protection.strings = StringsConfig(
            enabled=strings_dict.get('enabled', True),
            algorithm=strings_dict.get('algorithm', 'xor'),
            encryption_key=strings_dict.get('encryption_key', 'auto'),
            exclude=strings_dict.get('exclude', []),
        )

        # Anti-debug configuration
        anti_debug_dict = protection_dict.get('anti_debug', {})
        if isinstance(anti_debug_dict, bool):
            anti_debug_dict = {'enabled': anti_debug_dict}
        self.protection.anti_debug = AntiDebugConfig(
            enabled=anti_debug_dict.get('enabled', True),
            ptrace=anti_debug_dict.get('ptrace', True),
            sysctl=anti_debug_dict.get('sysctl', True),
        )

        # Anti-jailbreak configuration
        anti_jailbreak_dict = protection_dict.get('anti_jailbreak', {})
        if isinstance(anti_jailbreak_dict, bool):
            anti_jailbreak_dict = {'enabled': anti_jailbreak_dict}
        self.protection.anti_jailbreak = AntiJailbreakConfig(
            enabled=anti_jailbreak_dict.get('enabled', True),
            check_paths=anti_jailbreak_dict.get('check_paths', True),
            check_cydia=anti_jailbreak_dict.get('check_cydia', True),
        )

        # Swift configuration
        swift_dict = protection_dict.get('swift', {}) or protection_dict.get('swift_stripping', {})
        if isinstance(swift_dict, bool):
            swift_dict = {'strip_symbols': swift_dict}
        self.protection.swift = SwiftConfig(
            strip_symbols=swift_dict.get('strip_symbols', True),
            strip_debug=swift_dict.get('strip_debug', True),
            demangle=swift_dict.get('demangle', False),
        )

    def _load_mapping_config(self, mapping_dict: Dict[str, Any]):
        """Load mapping file configuration"""
        self.mapping = MappingConfig(
            output_file=mapping_dict.get('output_file', 'mapping.txt'),
            format=mapping_dict.get('format', 'proguard'),
            include_line_numbers=mapping_dict.get('include_line_numbers', False),
        )

    def _load_logging_config(self, logging_dict: Dict[str, Any]):
        """Load logging configuration"""
        self.logging_config = LoggingConfig(
            level=logging_dict.get('level', 'info'),
            file=logging_dict.get('file', 'shield.log'),
            console=logging_dict.get('console', True),
        )

    def _load_codesign_config(self, codesign_dict: Dict[str, Any]):
        """Load code signing configuration"""
        self.codesign = CodesignConfig(
            enabled=codesign_dict.get('enabled', False),
            identity=codesign_dict.get('identity'),
            provisioning_profile=codesign_dict.get('provisioning_profile'),
        )

    def validate(self) -> bool:
        """Validate configuration"""
        if not self.input_path or not self.input_path.exists():
            raise ValueError(f"Input path does not exist: {self.input_path}")

        if not self.output_path:
            raise ValueError("Output path is required")

        return True

    def __repr__(self) -> str:
        return f"Config(project={self.project_name}, input={self.input_path}, output={self.output_path})"
