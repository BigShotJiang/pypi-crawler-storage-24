"""Shield iOS Renamer
Symbol obfuscation with maximum safety
Compatible with Shield .NET Renamer architecture
"""

from shield_ios.renamer.name_service import NameService, RenameMode

__all__ = ['NameService', 'RenameMode']
