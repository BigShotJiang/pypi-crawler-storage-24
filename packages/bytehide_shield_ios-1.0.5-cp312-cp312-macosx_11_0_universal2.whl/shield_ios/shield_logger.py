#!/usr/bin/env python3
"""Shield iOS - Simple Logger

Clean, beautiful logging for CLI output
"""

from typing import Optional
import sys


class ShieldLogger:
    """Simple logger for Shield iOS CLI

    Provides clean, colorful output with emojis for better UX
    """

    # ANSI color codes
    RESET = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'

    # Colors
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    GRAY = '\033[90m'

    def __init__(self, verbose: bool = False):
        """Initialize logger

        Args:
            verbose: Enable verbose logging
        """
        self.verbose = verbose

    def section(self, message: str) -> None:
        """Print section header

        Args:
            message: Section title
        """
        print()
        print(f"{self.BOLD}{self.CYAN}{'═' * 60}{self.RESET}")
        print(f"{self.BOLD}{self.CYAN}{message}{self.RESET}")
        print(f"{self.BOLD}{self.CYAN}{'═' * 60}{self.RESET}")
        print()

    def info(self, message: str) -> None:
        """Print info message

        Args:
            message: Info message
        """
        print(f"{self.BLUE}ℹ{self.RESET}  {message}")

    def success(self, message: str) -> None:
        """Print success message

        Args:
            message: Success message
        """
        print(f"{self.GREEN}✓{self.RESET}  {self.GREEN}{message}{self.RESET}")

    def warning(self, message: str) -> None:
        """Print warning message

        Args:
            message: Warning message
        """
        print(f"{self.YELLOW}⚠{self.RESET}  {self.YELLOW}{message}{self.RESET}")

    def error(self, message: str) -> None:
        """Print error message

        Args:
            message: Error message
        """
        print(f"{self.RED}✗{self.RESET}  {self.RED}{message}{self.RESET}", file=sys.stderr)

    def debug(self, message: str) -> None:
        """Print debug message (only if verbose)

        Args:
            message: Debug message
        """
        if self.verbose:
            print(f"{self.GRAY}  {message}{self.RESET}")

    def progress(self, current: int, total: int, message: str) -> None:
        """Print progress indicator

        Args:
            current: Current step
            total: Total steps
            message: Progress message
        """
        percentage = int((current / total) * 100)
        print(f"{self.CYAN}[{current}/{total}]{self.RESET} {message} {self.GRAY}({percentage}%){self.RESET}")

    def protection(self, name: str, status: str = "enabled") -> None:
        """Print protection status

        Args:
            name: Protection name
            status: Status (enabled, disabled, running, complete)
        """
        if status == "enabled":
            print(f"  {self.GREEN}✓{self.RESET} {name}: {self.DIM}Enabled{self.RESET}")
        elif status == "disabled":
            print(f"  {self.GRAY}○{self.RESET} {name}: {self.DIM}Disabled{self.RESET}")
        elif status == "running":
            print(f"  {self.CYAN}⚙{self.RESET} {name}: {self.CYAN}Running...{self.RESET}")
        elif status == "complete":
            print(f"  {self.GREEN}✓{self.RESET} {name}: {self.GREEN}Complete{self.RESET}")

    def banner(self, version: Optional[str] = None) -> None:
        """Print Shield iOS banner

        Args:
            version: Version string (defaults to package version)
        """
        if version is None:
            from shield_ios import __version__
            version = __version__
        banner = f"""
{self.BOLD}{self.CYAN}╔══════════════════════════════════════════════════════════╗
║              Shield iOS v{version:<28}║
║         iOS Application Protection & Obfuscation        ║
║                     by ByteHide                          ║
╚══════════════════════════════════════════════════════════╝{self.RESET}
"""
        print(banner)
