"""Shield iOS - iOS Application Obfuscator
Architecture compatible with Shield .NET

Like Shield .NET NuGet package - just install and protect!
"""

try:
    from shield_ios._version import version as __version__
except ImportError:
    __version__ = "0.0.0.dev0"

__author__ = "ByteHide"

__all__ = [
    "__version__",
    "__author__",
]
