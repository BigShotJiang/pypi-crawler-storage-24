# Attestant

Upload model data for AI compliance analysis.

All compliance checks, fair lending analysis, and reporting happen in the
[Attestant dashboard](https://getattestant.com/client/).

## Install

```bash
pip install attestant
```

## Configure

```python
import attestant

attestant.configure(api_key="pvt_live_...")
```

Or set `ATTESTANT_API_KEY` in your environment.

## Upload

```python
result = attestant.upload(
    model=clf,
    test_df=holdout_df,
    label_column="approved",
    protected_columns=["race", "sex", "age"],
    age_column="age",
    age_format="years",
    model_name="loan_approval_v2",
)

print(result.dashboard_url)
```

`age_column` identifies which protected column holds applicant age.
`age_format` specifies the format: `"years"`, `"months"`, `"dob"`, or `"birth_year"`.

## Dashboard

View results at [getattestant.com/client](https://getattestant.com/client/).

## License

Apache-2.0
