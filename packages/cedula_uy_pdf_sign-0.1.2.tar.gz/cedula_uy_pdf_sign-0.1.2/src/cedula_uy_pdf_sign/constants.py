DEFAULT_PKCS11_LIB = "/usr/lib/pkcs11/libgclib.so"
DEFAULT_TIMEZONE = "America/Montevideo"

# Dimensiones de referencia del campo de firma:
# Rect [20 20 225 90] => 205 x 70
APPEARANCE_WIDTH = 205
APPEARANCE_HEIGHT = 70

DEFAULT_X1 = 20
DEFAULT_Y1 = 20
DEFAULT_X2 = DEFAULT_X1 + APPEARANCE_WIDTH   # 225
DEFAULT_Y2 = DEFAULT_Y1 + APPEARANCE_HEIGHT  # 90

# Valores de fuente del campo de firma
STAMP_FONT_NAME = "Helvetica"
STAMP_FONT_SIZE = 8.0
STAMP_LEADING = 9.6
STAMP_TEXT_X = 4.0
STAMP_TEXT_Y = 58.0

