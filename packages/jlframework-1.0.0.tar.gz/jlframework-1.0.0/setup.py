"""Setup configuration for jlframework."""

from setuptools import setup, find_packages
from pathlib import Path

# Read README
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(
    encoding="utf-8") if readme_file.exists() else ""

# Read version
version_file = Path(__file__).parent / "jlframework" / "__version__.py"
version = {}
exec(version_file.read_text(), version)

setup(
    name="jlframework",
    version=version["__version__"],
    description="A complete Python framework for full-stack development with FastAPI and Vue.js",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="JL Framework Team",
    author_email="contact@jlframework.dev",
    url="https://github.com/jlframework/jlframework",
    packages=find_packages(exclude=["tests", "tests.*", "plans", "plans.*"]),
    include_package_data=True,
    install_requires=[
        "click>=8.0.0",
        "jinja2>=3.0.0",
        "pydantic>=2.0.0",
        "pydantic-settings>=2.0.0",
        "fastapi>=0.104.0",
        "sqlalchemy>=2.0.0",
        "uvicorn>=0.24.0",
        "pymongo>=4.0.0",
        "pyodbc>=5.0.0",
        "python-dotenv>=1.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
            "mypy>=1.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "jlframework=jlframework.cli.main:cli",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Framework :: FastAPI",
        "Topic :: Software Development :: Libraries :: Application Frameworks",
        "Topic :: Software Development :: Code Generators",
    ],
    python_requires=">=3.9",
    keywords="fastapi vue framework boilerplate cli scaffolding",
)
