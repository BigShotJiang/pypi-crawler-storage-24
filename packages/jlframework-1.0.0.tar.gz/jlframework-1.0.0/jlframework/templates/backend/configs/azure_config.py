import os

from azure.appconfiguration import AzureAppConfigurationClient
from azure.core.exceptions import ResourceNotFoundError


class ConfigurationManager:
    """Manager for Azure App Configuration settings."""

    def __init__(self):
        """Initialize the Azure App Configuration client."""
        self.APPLICATION_ENVIRONMENT = os.getenv("APPLICATION_ENVIRONMENT")
        if not self.APPLICATION_ENVIRONMENT:
            raise ValueError(
                "APPLICATION_ENVIRONMENT environment variable is required")

        self.AZURE_APP_CONFIG_CONNECTION_STRING = os.getenv(
            "APP_CONFIGURATION_CONNECTION_STRING")
        if not self.AZURE_APP_CONFIG_CONNECTION_STRING:
            raise ValueError(
                "APP_CONFIGURATION_CONNECTION_STRING environment variable is required")

        try:
            self.client = AzureAppConfigurationClient.from_connection_string(
                self.AZURE_APP_CONFIG_CONNECTION_STRING
            )
        except Exception as e:
            raise ValueError(
                f"Failed to initialize Azure App Configuration client: {e}")

    def get_config_value(self, key: str) -> str:
        """Get configuration value by key and environment label.

        Args:
            key: Configuration key to retrieve.

        Returns:
            Configuration value as string.

        Raises:
            ValueError: If the configuration key is not found.
        """
        if not key:
            raise ValueError("Configuration key cannot be empty")

        try:
            setting = self.client.get_configuration_setting(
                key=key,
                label=self.APPLICATION_ENVIRONMENT
            )
            if setting and setting.value:
                return setting.value
            else:
                raise ValueError(
                    f"Configuration key '{key}' not found or has no value")
        except ResourceNotFoundError:
            raise ValueError(
                f"Configuration key '{key}' not found in environment '{self.APPLICATION_ENVIRONMENT}'")
        except Exception as e:
            raise ValueError(
                f"Failed to retrieve configuration for key '{key}': {e}")

    def parse_connection_string(self, connection_string: str) -> dict:
        """Parse connection string into dictionary of key-value pairs.

        Args:
            connection_string: Connection string to parse.

        Returns:
            Dictionary of parsed key-value pairs.

        Raises:
            ValueError: If connection string is invalid.
        """
        if not connection_string:
            raise ValueError("Connection string cannot be empty")

        try:
            items = connection_string.split(";")
            parsed_items = {}
            for item in items:
                if "=" in item:
                    key, value = item.split("=", 1)
                    parsed_items[key.strip().strip(
                        '"')] = value.strip().strip('"')

            if not parsed_items:
                raise ValueError(
                    "No valid key-value pairs found in connection string")

            return parsed_items
        except Exception as e:
            raise ValueError(f"Failed to parse connection string: {e}")


class configurations:
    """Global configuration settings loaded from Azure App Configuration."""

    try:
        config_manager = ConfigurationManager()

        # Database configuration
        _automation_db_conn_str = config_manager.get_config_value(
            "JobLogicAutomationDb")
        db_settings = config_manager.parse_connection_string(
            _automation_db_conn_str)

        # API configuration
        MainSubSysAutomationAPI = config_manager.get_config_value(
            'MainSubSysAutomationAPI')
        MainSubSysAutomationAPIHeader = config_manager.get_config_value(
            'MainSubSysAutomationAPIHeader')

        # Application configuration
        app_default = config_manager.get_config_value('app_default')
        mongo_db_connection_string = config_manager.get_config_value(
            'mongo_db_connection_string')

    except Exception as e:
        raise ValueError(f"Failed to load configurations: {e}")
