"""JLFramework - A comprehensive framework for FastAPI and Vue.js applications.

This package provides:
- CLI tools for project initialization and template management
- Core utilities for database, handlers, middleware, and enums
- Reusable components for multi-tenant applications
- Django-like import patterns for common functionality
"""

from jlframework.__version__ import __version__

# Database utilities
from jlframework.core.database import (
    close_db_session,
    database_middleware,
    get_db,
    get_db_session,
    get_request_db,
    initialize_database,
)

# Azure database initialization
from jlframework.core.azure_db import initialize_database_from_azure

# Enums
from jlframework.core.enums import AuditAction, AuditStatus, EntityType

# Handlers
from jlframework.core.handlers import AuditData, AuditManager, CommonManager

# Middleware
from jlframework.core.middleware import (
    get_tenant_id,
    restrict_access_middleware,
)

# API Client
from jlframework.core.api_client import (
    ApiError,
    MainSubSysApiManager,
    RequestType,
    retry_with_backoff,
)

# Utilities
from jlframework.core.utils import deprecated

__all__ = [
    # Version
    "__version__",
    # Database
    "initialize_database",
    "initialize_database_from_azure",
    "get_db",
    "get_db_session",
    "close_db_session",
    "get_request_db",
    "database_middleware",
    # Enums
    "AuditStatus",
    "AuditAction",
    "EntityType",
    # Handlers
    "CommonManager",
    "AuditManager",
    "AuditData",
    # Middleware
    "restrict_access_middleware",
    "get_tenant_id",
    # API Client
    "MainSubSysApiManager",
    "RequestType",
    "ApiError",
    "retry_with_backoff",
    # Utilities
    "deprecated",
]
