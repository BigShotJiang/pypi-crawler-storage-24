#[path = "test_support/mod.rs"]
mod test_support;

use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};
use fers_calculations::models::supports::supportconditiontype::SupportConditionType;
use fers_calculations::models::loads::loadcombination::LoadCombination;
use std::collections::HashMap;

use test_support::helpers::*;
use test_support::*;

// ─────────────────────────────────────────────────────────────────────────────
//  093 — Hooked cantilever with two tension ropes, combined loading
//
//  N1(0,0,0) ── beam1 ── N2(5,0,0) ── beam2 ── N3(5,5,0)
//                                                 │  │
//                                          rope1  │  │  rope2
//                                                 │  │
//                                          N4(5,0,−1) N5(5,0,1)
//
//  Supports:  N1, N2 pinned;  N4, N5 pinned
//  Loads:     LC_x = −100 N in X,  LC_y = −10000 N in Y,  LC_z = −100 N in Z
//  Combo:     1×LC_x + 1×LC_y + 1×LC_z
//  Checks:    Equilibrium of combo result
// ─────────────────────────────────────────────────────────────────────────────

fn test_093_case(strategy: RigidStrategy, lu: LengthUnit, fu: ForceUnit, pu: PressureUnit) {
    let ctx = make_ctx("093_hooked_combo", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    let mat = add_material_s235(&mut model, 1);
    let sec = add_section_ipe180_like(&mut model, 1, mat, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    // Single pinned support shared by nodes 1, 2, 4, 5
    model.nodal_supports.push(make_support_custom(
        1,
        SupportConditionType::Fixed,
        SupportConditionType::Fixed,
        SupportConditionType::Fixed,
        SupportConditionType::Free,
        SupportConditionType::Free,
        SupportConditionType::Free,
    ));

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, 5.0 / l, 0.0, 0.0, Some(1));
    let n3 = make_node(3, 5.0 / l, 5.0 / l, 0.0, None);
    let n4 = make_node(4, 5.0 / l, 0.0, -1.0 / l, Some(1));
    let n5 = make_node(5, 5.0 / l, 0.0, 1.0 / l, Some(1));

    add_member_set(
        &mut model,
        1,
        vec![
            make_beam_member(1, &n1, &n2, sec),
            make_beam_member(2, &n2, &n3, sec),
            make_tension_only_member(3, &n3, &n4, sec),
            make_tension_only_member(4, &n3, &n5, sec),
        ],
    );

    // Three load cases
    let lc_x = add_load_case(&mut model, 1, "End Load X");
    add_nodal_load(&mut model, 1, lc_x, 3, 100.0 / f, (-1.0, 0.0, 0.0));

    let lc_y = add_load_case(&mut model, 2, "End Load Y");
    add_nodal_load(&mut model, 2, lc_y, 3, 10000.0 / f, (0.0, -1.0, 0.0));

    let lc_z = add_load_case(&mut model, 3, "End Load Z");
    add_nodal_load(&mut model, 3, lc_z, 3, 100.0 / f, (0.0, 0.0, -1.0));

    // Combination: equal factors
    model.load_combinations.push(LoadCombination {
        id: 1,
        name: "Combined".to_string(),
        load_cases_factors: HashMap::from([(1, 1.0), (2, 1.0), (3, 1.0)]),
        situation: Some("ULS".to_string()),
        check: "ALL".to_string(),
        limit_state: None,
    });

    model.normalize_units();
    model
        .solve_for_load_case(lc_x)
        .unwrap_or_else(|e| panic!("{ctx}: LCx {e}"));
    model
        .solve_for_load_case(lc_y)
        .unwrap_or_else(|e| panic!("{ctx}: LCy {e}"));
    model
        .solve_for_load_case(lc_z)
        .unwrap_or_else(|e| panic!("{ctx}: LCz {e}"));
    model
        .solve_for_load_combination(1)
        .unwrap_or_else(|e| panic!("{ctx}: combo {e}"));
    denorm_results_in_place(&mut model);

    let results = model.results.as_ref().unwrap();
    let combo = &results.loadcombinations["1"];

    // Sum reactions across all supported nodes (1, 2, 4, 5)
    let mut sum_fx = 0.0;
    let mut sum_fy = 0.0;
    let mut sum_fz = 0.0;
    for nid in [1u32, 2, 4, 5] {
        let rx = combo.reaction_nodes.get(&nid).unwrap().nodal_forces;
        sum_fx += rx.fx;
        sum_fy += rx.fy;
        sum_fz += rx.fz;
    }

    let tol_f = tol_force_user(TOL_ABSOLUTE_FORCE_IN_NEWTON, f);

    // Applied: (−100, −10000, −100) → reactions sum to (+100, +10000, +100)
    assert_close_ctx(&ctx, 100.0 / f, sum_fx, tol_f, "combo_sum_Fx");
    assert_close_ctx(&ctx, 10000.0 / f, sum_fy, tol_f, "combo_sum_Fy");
    assert_close_ctx(&ctx, 100.0 / f, sum_fz, tol_f, "combo_sum_Fz");
}

#[test]
fn test_093_hooked_cantilever_load_combination_equilibrium() {
    for s in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_093_case(s, lu, fu, pu);
        }
    }
}
