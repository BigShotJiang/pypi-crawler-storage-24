import json
import math
import time
from collections.abc import Callable
from enum import Enum
from typing import Any, Self, cast

from pydantic import SecretStr

from planar.logging import get_logger
from planar.secrets.protocol import SecretProvider
from planar.secrets.providers import (
    AwsSecretsManagerProvider,
    AzureKeyVaultProvider,
    EnvVarSecretProvider,
)

logger = get_logger(__name__)


_CLOUD_PROVIDER_TTL_SECONDS = 300.0


class ProviderType(str, Enum):
    ENV = "env"
    AWS_SECRETS_MANAGER = "aws_secrets_manager"
    AZURE_KEY_VAULT = "azure_key_vault"


def _default_ttl(provider_type: str) -> float:
    if provider_type in {
        ProviderType.AWS_SECRETS_MANAGER,
        ProviderType.AZURE_KEY_VAULT,
    }:
        return _CLOUD_PROVIDER_TTL_SECONDS
    return math.inf


class SecretRegistry:
    _provider_types: dict[str, type[SecretProvider]] = {
        ProviderType.ENV: EnvVarSecretProvider,
        ProviderType.AWS_SECRETS_MANAGER: AwsSecretsManagerProvider,
        ProviderType.AZURE_KEY_VAULT: AzureKeyVaultProvider,
    }

    def __init__(self):
        self._providers: dict[str, SecretProvider] = {}
        self._ttls: dict[str, float] = {}
        self._cache: dict[tuple[str, str], tuple[str, float]] = {}

    @classmethod
    def register_provider_type(
        cls, name: str, provider_cls: type[SecretProvider]
    ) -> None:
        """
        Register a custom secret provider class with a label.
        This must be called before configuration is loaded.
        """
        if name in cls._provider_types:
            logger.warning("overriding secret provider type", name=name)
        cls._provider_types[name] = provider_cls

    def register(
        self, name: str, provider: SecretProvider, ttl: float | None = None
    ) -> None:
        self._providers[name] = provider
        if ttl is not None:
            self._ttls[name] = ttl

    def get_provider(self, name: str) -> SecretProvider:
        if name not in self._providers:
            logger.error("secret provider not found", provider_name=name)
            raise ValueError(f"Secret provider '{name}' not found in registry.")
        return self._providers[name]

    def resolve_secret(
        self, provider_name: str, secret_id: str, json_key: str | None = None
    ) -> SecretStr:
        """
        Resolve a secret value, using a per-provider TTL cache.

        The cache is keyed by (provider_name, secret_id) so that multiple
        json_key extractions from the same secret share one provider fetch.
        """
        cache_key = (provider_name, secret_id)
        now = time.monotonic()
        cached = self._cache.get(cache_key)
        if cached is not None:
            raw_value, fetched_at = cached
            ttl = self._ttls.get(provider_name, math.inf)
            if now - fetched_at < ttl:
                if json_key:
                    return SecretStr(
                        self._extract_json_key(raw_value, secret_id, json_key)
                    )
                return SecretStr(raw_value)

        provider = self.get_provider(provider_name)
        raw_value = provider.get_secret(secret_id)
        self._cache[cache_key] = (raw_value, now)

        if json_key:
            return SecretStr(self._extract_json_key(raw_value, secret_id, json_key))
        return SecretStr(raw_value)

    @staticmethod
    def _extract_json_key(raw_value: str, secret_id: str, json_key: str) -> str:
        try:
            secret_json = json.loads(raw_value)
            if not isinstance(secret_json, dict):
                logger.error("secret is not a json object", secret_id=secret_id)
                raise ValueError(
                    f"Secret '{secret_id}' is not a valid JSON object, cannot extract key '{json_key}'"
                )
            if json_key not in secret_json:
                logger.error(
                    "json key not found in secret",
                    secret_id=secret_id,
                    json_key=json_key,
                )
                raise ValueError(f"Key '{json_key}' not found in secret '{secret_id}'")
            return str(secret_json[json_key])
        except json.JSONDecodeError as e:
            logger.error("secret is not valid json", secret_id=secret_id, error=str(e))
            raise ValueError(
                f"Secret '{secret_id}' is not valid JSON, cannot extract key '{json_key}'"
            ) from e

    @classmethod
    def from_config(cls, providers_config: dict[str, Any]) -> Self:
        registry = cls()
        for name, config_entry in providers_config.items():
            provider_type = config_entry.get("provider")
            provider_config = dict(config_entry.get("options", {}))

            if not provider_type:
                logger.error("provider type missing", provider_name=name)
                raise ValueError(f"Provider type missing for secret provider '{name}'")

            if provider_type in cls._provider_types:
                provider_class = cls._provider_types[provider_type]
                try:
                    ttl = float(provider_config.pop("ttl", _default_ttl(provider_type)))
                    provider_factory = cast(
                        Callable[[dict[str, Any]], SecretProvider], provider_class
                    )
                    provider_instance = provider_factory(provider_config)
                except Exception as e:
                    raise ValueError(
                        f"Failed to initialize secret provider '{name}' ({provider_type}): {e}"
                    ) from e
            else:
                logger.error("unknown provider type", provider_type=provider_type)
                raise ValueError(f"Unknown secret provider type: '{provider_type}'")

            registry.register(name, provider_instance, ttl=ttl)

        return registry
