"""add eval trial count and trial number

Revision ID: 28c48a017ceb
Revises: a1b2c3d4e5f6
Create Date: 2026-02-12 18:13:52.158242

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "28c48a017ceb"
down_revision: str | None = "a1b2c3d4e5f6"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    conn = op.get_bind()
    dialect_name = conn.dialect.name
    schema = "planar" if dialect_name == "postgresql" else None

    with op.batch_alter_table("eval_case_result", schema=schema) as batch_op:
        batch_op.add_column(
            sa.Column(
                "trial_number",
                sa.Integer(),
                nullable=False,
                server_default=sa.text("1"),
            )
        )
        batch_op.drop_constraint(
            batch_op.f("uq_eval_case_result_run_case"),
            type_="unique",
        )
        batch_op.create_unique_constraint(
            "uq_eval_case_result_run_case_trial_number",
            ["run_id", "eval_case_id", "trial_number"],
        )

    with op.batch_alter_table("eval_suite", schema=schema) as batch_op:
        batch_op.add_column(
            sa.Column(
                "trial_count",
                sa.Integer(),
                nullable=False,
                server_default=sa.text("1"),
            )
        )


def downgrade() -> None:
    conn = op.get_bind()
    dialect_name = conn.dialect.name
    schema = "planar" if dialect_name == "postgresql" else None

    with op.batch_alter_table("eval_suite", schema=schema) as batch_op:
        batch_op.drop_column("trial_count")

    with op.batch_alter_table("eval_case_result", schema=schema) as batch_op:
        batch_op.drop_constraint(
            "uq_eval_case_result_run_case_trial_number",
            type_="unique",
        )
        batch_op.create_unique_constraint(
            batch_op.f("uq_eval_case_result_run_case"),
            ["run_id", "eval_case_id"],
            postgresql_nulls_not_distinct=False,
        )
        batch_op.drop_column("trial_number")
