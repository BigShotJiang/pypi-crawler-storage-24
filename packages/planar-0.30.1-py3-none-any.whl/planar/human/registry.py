from collections.abc import Awaitable, Callable

from planar.human.models import HumanTask
from planar.logging import get_logger

logger = get_logger(__name__)

OrphanHandler = Callable[[HumanTask], Awaitable[None]]

# Registry of orphaned scope/assignment handlers that let us
# map from a `HumanTask` via the name.
_ORPHAN_SCOPE_HANDLER_REGISTRY: dict[str, OrphanHandler] = {}
_ORPHAN_ASSIGNMENT_HANDLER_REGISTRY: dict[str, OrphanHandler] = {}


def register_orphaned_scope_handler(name: str, handler: OrphanHandler) -> None:
    if name not in _ORPHAN_SCOPE_HANDLER_REGISTRY:
        _ORPHAN_SCOPE_HANDLER_REGISTRY[name] = handler


def register_orphaned_assignment_handler(name: str, handler: OrphanHandler) -> None:
    if name not in _ORPHAN_ASSIGNMENT_HANDLER_REGISTRY:
        _ORPHAN_ASSIGNMENT_HANDLER_REGISTRY[name] = handler


def get_orphaned_scope_handler(name: str) -> OrphanHandler | None:
    return _ORPHAN_SCOPE_HANDLER_REGISTRY.get(name)


def get_orphaned_assignment_handler(name: str) -> OrphanHandler | None:
    return _ORPHAN_ASSIGNMENT_HANDLER_REGISTRY.get(name)
