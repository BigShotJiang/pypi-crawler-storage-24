from collections.abc import Sequence

from pydantic import BaseModel
from sqlalchemy.orm.strategy_options import selectinload
from sqlmodel import col, select

from planar.db.db import PlanarSession
from planar.modeling.orm.reexports import SQLModel
from planar.session import get_session
from planar.user import models as m
from planar.utils import utc_now


def _update(existing: SQLModel, new: SQLModel, update_columns: list[str]) -> bool:
    """Apply updates in `update_columns` from `new` to `existing`."""

    changed = False
    for col_name in update_columns:
        old_value = getattr(existing, col_name)
        new_value = getattr(new, col_name)

        if old_value != new_value:
            changed = True
            setattr(existing, col_name, new_value)

    return changed


async def _upsert[T: SQLModel](
    session: PlanarSession,
    id_col: str,
    db_model: type[T],
    to_upsert: list[T],
    update_columns: list[str],
) -> bool:
    """Create or update existing instances of the synced model."""
    if not to_upsert:
        return False

    external_ids = {getattr(obj, id_col) for obj in to_upsert}
    existing_query = await session.exec(
        select(db_model).where(col(getattr(db_model, id_col)).in_(external_ids))
    )
    existing_dict = {getattr(obj, id_col): obj for obj in existing_query.all()}

    changed = False
    # We don't use `session.upsert` because it fires a bulk SQL insert that bypasses
    # `session.add()` and thus the `after_insert`, which is needed for the changelog.
    for new in to_upsert:
        # Exists -> update
        if (_id := getattr(new, id_col)) in existing_dict:
            existing = existing_dict[_id]
            if _update(existing, new, update_columns):
                changed = True
                session.add(existing)
        # Doesn't exist -> create
        else:
            session.add(new)
            changed = True

    return changed


async def _disable_dropoffs[T: SQLModel](
    existing_dict: dict[str, T],
    dir_objs: Sequence[BaseModel],
    dir_key: str,
):
    """Disable instances of the synced model that are no longer present."""

    new_ids: set[str] = {getattr(i, dir_key) for i in dir_objs}
    existing_ids: set[str] = set(existing_dict.keys())

    dropoffs = existing_ids - new_ids
    changed = False
    for _id in dropoffs:
        obj = existing_dict[_id]
        if getattr(obj, "disabled_at") is None:
            setattr(obj, "disabled_at", utc_now())
            changed = True

    return changed


async def _sync_users(session: PlanarSession, dir_users: list[m.DirectoryUser]):
    existing_query = await session.exec(select(m.IDPUser))
    existing_dict = {i.external_id: i for i in existing_query}
    disabled_any = await _disable_dropoffs(existing_dict, dir_users, "sync_id")

    to_upsert = [m.IDPUser.from_directory(i) for i in dir_users]
    update_columns = [
        "email",
        "first_name",
        "last_name",
        "external_created_at",
        "external_updated_at",
        "disabled_at",  # re-enables a previously disabled user
    ]
    upserted_any = await _upsert(
        session, "external_id", m.IDPUser, to_upsert, update_columns
    )

    return disabled_any or upserted_any


async def _sync_groups(session: PlanarSession, dir_groups: list[m.DirectoryGroup]):
    existing_query = await session.exec(select(m.IDPGroup))
    existing_dict = {i.external_id: i for i in existing_query}
    disabled_any = await _disable_dropoffs(existing_dict, dir_groups, "sync_id")

    to_upsert = [m.IDPGroup.from_directory(i) for i in dir_groups]
    update_columns = [
        "name",
        "external_created_at",
        "external_updated_at",
        "disabled_at",  # re-enables a previously disabled group
    ]
    upserted_any = await _upsert(
        session, "external_id", m.IDPGroup, to_upsert, update_columns
    )

    membership_changed = False
    for dir_group in dir_groups:
        if await _sync_members(session, dir_group):
            membership_changed = True

    return disabled_any or upserted_any or membership_changed


async def _sync_members(session: PlanarSession, dir_group: m.DirectoryGroup):
    latest_external_ids = {i.sync_id for i in dir_group.members}
    latest_users_query = await session.exec(
        select(m.IDPUser).where(col(m.IDPUser.external_id).in_(latest_external_ids))
    )
    latest_users = list(latest_users_query.all())

    group_q = await session.exec(
        select(m.IDPGroup)
        .where(m.IDPGroup.external_id == dir_group.sync_id)
        .options(selectinload(m.IDPGroup.users_including_disabled))  # pyright: ignore[reportArgumentType]
    )
    group = group_q.one()

    # We use explicit inserts/deletes on UserGroupMembership rather than relationship assignment
    # via `group.users_including_disabled = users` because SQLA's bulk relationship sync
    # bypasses our `after_insert` and `after_delete` event listeners.

    already_in_group_user_ids = {u.id for u in group.users_including_disabled}
    latest_user_ids = {u.id for u in latest_users}

    net_new_users = latest_user_ids - already_in_group_user_ids
    users_to_remove = already_in_group_user_ids - latest_user_ids

    for user_id in net_new_users:
        membership = m.UserGroupMembership(user_id=user_id, group_id=group.id)
        session.add(membership)

    for user_id in users_to_remove:
        delete_query = await session.exec(
            select(m.UserGroupMembership).where(
                m.UserGroupMembership.user_id == user_id,
                m.UserGroupMembership.group_id == group.id,
            )
        )
        membership = delete_query.one()
        await session.delete(membership)

    group.num_members = len(latest_external_ids)

    return len(net_new_users) > 0 or len(users_to_remove) > 0


async def sync_users_and_groups(
    users: list[m.DirectoryUser], groups: list[m.DirectoryGroup]
) -> bool:
    """Sync the state of the Users/Groups with the API outputs from the CoPlane backend.

    Returns:
        True if any users, groups, or memberships were created, updated, or disabled, False otherwise.
    """

    session = get_session()

    users_changed = await _sync_users(session, users)
    groups_changed = await _sync_groups(session, groups)
    await session.commit()

    return users_changed or groups_changed
