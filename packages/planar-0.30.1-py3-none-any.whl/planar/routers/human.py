"""
Human tasks API router for Planar workflows.

This module provides API routes for managing human task instances,
including task listing, completion, cancellation, and retrieval.
"""

from contextlib import contextmanager
from datetime import datetime
from typing import Any, Self
from uuid import UUID

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel

from planar.human import api
from planar.human import models as m
from planar.human.exceptions import TaskNotFound, TaskNotPending, UserNotFound
from planar.human.human import (
    HumanTask,
    HumanTaskStatus,
    cancel_human_task,
    complete_human_task,
    get_human_task,
    get_human_tasks,
)
from planar.logging import get_logger
from planar.routers.user import User
from planar.security.auth_context import require_principal
from planar.security.authorization import (
    AssignmentResource,
    HumanTaskAction,
    HumanTaskResource,
    UserResource,
    validate_authorization_for,
)
from planar.security.models import Principal
from planar.user.api import get_user_with_groups
from planar.user.models import IDPUser
from planar.utils import flatmap

logger = get_logger(__name__)


class CompleteTaskRequest(BaseModel):
    """Request model for completing a human task."""

    output_data: dict[str, Any]
    completed_by: str | None = None


class CancelTaskRequest(BaseModel):
    """Request model for cancelling a human task."""

    reason: str = "cancelled"
    cancelled_by: str | None = None


class Assignment(BaseModel):
    created_at: datetime
    assignee: str
    assignor: str | None

    @classmethod
    def from_assignment(cls, assignment: m.Assignment) -> Self:
        return cls(
            created_at=assignment.created_at,
            assignee=assignment.assignee.email,
            assignor=flatmap(assignment.assignor, lambda x: x.email),
        )


class HumanTaskWithAssignment(BaseModel):
    human_task: HumanTask
    assignment: Assignment | None
    can_self_assign: bool
    can_unassign: bool

    @classmethod
    def from_human_task(cls, human_task: HumanTask) -> Self:
        principal = require_principal()
        if not principal.user:
            raise UserNotFound(principal.user_email)

        return cls(
            human_task=human_task,
            assignment=flatmap(human_task.assignment, Assignment.from_assignment),
            can_self_assign=_can_assign(principal, human_task, principal.user),
            can_unassign=_can_unassign(principal, human_task),
        )


def _can_view(task: HumanTask) -> bool:
    """The current principal is allowed to view `task`."""

    try:
        validate_authorization_for(
            HumanTaskResource.from_human_task(task),
            HumanTaskAction.TASK_VIEW,
        )
        return True
    except HTTPException as e:
        if e.status_code != 403:
            raise
    return False


def _can_assign(principal: Principal, task: HumanTask, assignee: UserResource) -> bool:
    """`principal` is allowed to assign `task` to `assignee`."""

    proposed_assignment = AssignmentResource(
        task_id=str(task.id),
        assignee=assignee,
        assignor=principal.user,
    )
    if principal.user is None:
        raise UserNotFound(principal.user_email)

    try:
        validate_authorization_for(
            HumanTaskResource.from_human_task(task, proposed_assignment),
            HumanTaskAction.TASK_ASSIGN,
        )
        return True
    except HTTPException as e:
        if e.status_code != 403:
            raise
    return False


def _can_unassign(principal: Principal, task: HumanTask) -> bool:
    """The current principal is allowed to unassign `task`."""

    proposed_assignment = AssignmentResource(
        task_id=str(task.id),
        assignee=None,
        assignor=principal.user,
    )
    if principal.user is None:
        raise UserNotFound(principal.user_email)

    try:
        validate_authorization_for(
            HumanTaskResource.from_human_task(task, proposed_assignment),
            HumanTaskAction.TASK_ASSIGN,
        )
        return True
    except HTTPException as e:
        if e.status_code != 403:
            raise
    return False


def filter_viewable_tasks(tasks: list[HumanTask]) -> list[HumanTask]:
    return [task for task in tasks if _can_view(task)]


def assignable_users(task: HumanTask, assignees: list[IDPUser]) -> list[IDPUser]:
    """Return the list of `IDPUser`s that the current principal can assign `task` to based on cedar policies."""

    principal = require_principal()
    return [
        assignee
        for assignee in assignees
        if _can_assign(principal, task, UserResource.from_user(assignee))
    ]


def tasks_with_assignments(tasks: list[HumanTask]) -> list[HumanTaskWithAssignment]:
    return [HumanTaskWithAssignment.from_human_task(task) for task in tasks]


@contextmanager
def _raise_http_exceptions():
    try:
        yield
    except HTTPException:
        raise
    except TaskNotFound as e:
        raise HTTPException(404, str(e)) from e
    except UserNotFound as e:
        raise HTTPException(401, str(e)) from e
    except TaskNotPending as e:
        raise HTTPException(400, str(e)) from e
    except Exception as e:
        raise HTTPException(500, str(e)) from e


def create_human_task_routes() -> APIRouter:
    router = APIRouter(tags=["Human Tasks"])

    """Register human task routes on the provided router and return it."""

    @router.get("/", response_model=list[HumanTask])
    async def list_human_tasks(
        status: HumanTaskStatus | None = None,
        workflow_id: UUID | None = None,
        name: str | None = None,
        limit: int = Query(100, ge=1, le=1000),
        offset: int = Query(0, ge=0),
    ):
        """
        List human tasks with optional filtering.

        Args:
            status: Filter by task status
            workflow_id: Filter by workflow ID
            name: Filter by task name
            limit: Maximum number of tasks to return
            offset: Pagination offset
        """
        try:
            return await get_human_tasks(
                status=status,
                workflow_id=workflow_id,
                name=name,
                limit=limit,
                offset=offset,
            )
        except Exception as e:
            logger.exception("error listing human tasks")
            raise HTTPException(status_code=500, detail=str(e)) from e

    @router.get("/{task_id}", response_model=HumanTask)
    async def get_task(task_id: UUID):
        """
        Get a human task by its ID.

        Args:
            task_id: The ID of the task to retrieve
        """
        try:
            task = await api.query_task(task_id)
        except HTTPException:
            raise
        except TaskNotFound as e:
            raise HTTPException(status_code=404, detail=str(e)) from e
        except Exception as e:
            logger.exception("error getting human task", task_id=task_id)
            raise HTTPException(status_code=500, detail=str(e)) from e

        return task

    @router.post("/{task_id}/complete", response_model=HumanTask)
    async def complete_task(task_id: UUID, request: CompleteTaskRequest = Body(...)):
        """
        Complete a human task with the provided output data.

        Args:
            task_id: The ID of the task to complete
            request: The completion data
        """
        try:
            await complete_human_task(
                task_id=task_id,
                output_data=request.output_data,
                completed_by=request.completed_by,
            )

            # Fetch the updated task to return
            task = await get_human_task(task_id)
            if not task:  # Should not happen if complete_human_task succeeded
                raise HTTPException(status_code=404, detail=f"Task {task_id} not found")

            logger.info("human task completed successfully", task_id=task_id)
            return task
        except ValueError as e:
            logger.exception("valueerror completing task", task_id=task_id)
            raise HTTPException(status_code=400, detail=str(e)) from e
        except Exception as e:
            logger.exception("exception completing task", task_id=task_id)
            raise HTTPException(status_code=500, detail=str(e)) from e

    @router.post("/{task_id}/cancel", response_model=HumanTask)
    async def cancel_task(task_id: UUID, request: CancelTaskRequest = Body(...)):
        """
        Cancel a pending human task.

        Args:
            task_id: The ID of the task to cancel
            request: The cancellation details
        """
        try:
            await cancel_human_task(
                task_id=task_id,
                reason=request.reason,
                cancelled_by=request.cancelled_by,
            )

            # Fetch the updated task to return
            task = await get_human_task(task_id)
            if not task:  # Should not happen if cancel_human_task succeeded
                logger.warning(
                    "human task not found after cancellation attempt", task_id=task_id
                )
                raise HTTPException(status_code=404, detail=f"Task {task_id} not found")

            logger.info("human task cancelled successfully", task_id=task_id)
            return task
        except ValueError as e:
            logger.exception("valueerror cancelling task", task_id=task_id)
            raise HTTPException(status_code=400, detail=str(e)) from e
        except Exception as e:
            logger.exception("exception cancelling task", task_id=task_id)
            raise HTTPException(status_code=500, detail=str(e)) from e

    # Task assignment endpoints return the enriched `HumanTaskWithAssignment` object.
    @router.post("/with-assignment", response_model=list[HumanTaskWithAssignment])
    # We use POST here so that we can pass complex query parameters via the request body.
    async def tasks(
        attribute_filters: m.TaskAttributeFilters = Depends(),
        scope_filter: m.TaskScopeFilter = Depends(),
        assignment_filter: m.TaskAssignmentFilter = Depends(),
    ) -> list[HumanTaskWithAssignment]:
        """List human tasks w/ their assignments."""
        with _raise_http_exceptions():
            tasks = await api.query_tasks(
                attribute_filters=attribute_filters,
                scope_filter=scope_filter,
                assignment_filter=assignment_filter,
            )
            return tasks_with_assignments(filter_viewable_tasks(tasks))

    @router.post(
        "/with-assignment/scoped-to-user/{user_id}",
        response_model=list[HumanTaskWithAssignment],
    )
    async def tasks_scoped_to_user(
        user_id: UUID,
        attribute_filters: m.TaskAttributeFilters = Depends(),
        assignment_filter: m.TaskAssignmentFilter = Depends(),
    ):
        """List human tasks scoped to a user directly or via their groups."""
        with _raise_http_exceptions():
            user_scoped_tasks = await api.query_tasks(
                attribute_filters=attribute_filters,
                scope_filter=m.TaskScopeFilter(scope=m.UserScope(ids={user_id})),
                assignment_filter=assignment_filter,
            )

            user = await get_user_with_groups(user_id)
            if not user:
                raise UserNotFound(str(user_id))

            group_scoped_tasks = await api.query_tasks(
                attribute_filters=attribute_filters,
                scope_filter=m.TaskScopeFilter(
                    scope=m.GroupScope(ids={g.id for g in user.groups})
                ),
                assignment_filter=assignment_filter,
            )
            return tasks_with_assignments(
                filter_viewable_tasks(user_scoped_tasks + group_scoped_tasks)
            )

    @router.get(
        "/with-assignment/orphaned-scope", response_model=list[HumanTaskWithAssignment]
    )
    async def orphaned_scope_tasks():
        with _raise_http_exceptions():
            tasks = await api.orphaned_scope_tasks()
            return tasks_with_assignments(filter_viewable_tasks(tasks))

    @router.get(
        "/with-assignment/orphaned-assignment",
        response_model=list[HumanTaskWithAssignment],
    )
    async def orphaned_assignment_tasks():
        with _raise_http_exceptions():
            tasks = await api.orphaned_assignment_tasks()
            return tasks_with_assignments(filter_viewable_tasks(tasks))

    @router.get("/with-assignment/{task_id}", response_model=HumanTaskWithAssignment)
    async def task_with_assignment(task_id: UUID) -> HumanTaskWithAssignment:
        with _raise_http_exceptions():
            task = await api.query_task(task_id)
            validate_authorization_for(
                HumanTaskResource.from_human_task(task),
                HumanTaskAction.TASK_VIEW,
            )
            return HumanTaskWithAssignment.from_human_task(task)

    @router.get(
        "/with-assignment/{task_id}/assignable-users", response_model=list[User]
    )
    async def get_assignable_users(task_id: UUID):
        """Get list of users in the task's scope who the current user can assign the task to."""
        with _raise_http_exceptions():
            task = await api.query_task(task_id, load_deep_scope=True)
            validate_authorization_for(
                HumanTaskResource.from_human_task(task),
                HumanTaskAction.TASK_VIEW,
            )

            if not task.scope:
                return []

            scoped_users: list[IDPUser] = []

            if task.scope.users:
                # Tasks can be scoped to a deleted user, but we don't want to include these as potential assignees.
                scoped_users.extend(
                    u for u in task.scope.users if u.disabled_at is None
                )

            if task.scope.groups:
                for group in task.scope.groups:
                    scoped_users.extend(group.users)

            can_assign_to = assignable_users(task, scoped_users)
            return [User.from_(u) for u in can_assign_to]

    @router.post(
        "/with-assignment/{task_id}/reassign", response_model=HumanTaskWithAssignment
    )
    async def reassign_task_endpoint(
        task_id: UUID, user_id: UUID = Body(..., embed=True)
    ):
        """
        Reassign a pending human task to a different user.

        Args:
            task_id: The ID of the task to reassign
            user_id: The ID of the user to assign the task to
        """
        with _raise_http_exceptions():
            await api.reassign_task(task_id, user_id)

            # Fetch the updated task to return
            task = await api.query_task(task_id)
            if not task:
                raise HTTPException(status_code=404, detail=f"Task {task_id} not found")

            return HumanTaskWithAssignment.from_human_task(task)

    @router.post(
        "/with-assignment/{task_id}/unassign", response_model=HumanTaskWithAssignment
    )
    async def unassign_task_endpoint(task_id: UUID):
        """
        Unassign a pending human task.

        Args:
            task_id: The ID of the task to unassign
        """
        with _raise_http_exceptions():
            await api.reassign_task(task_id, None)

            # Fetch the updated task to return
            task = await api.query_task(task_id)
            if not task:
                raise HTTPException(status_code=404, detail=f"Task {task_id} not found")

            return HumanTaskWithAssignment.from_human_task(task)

    return router
