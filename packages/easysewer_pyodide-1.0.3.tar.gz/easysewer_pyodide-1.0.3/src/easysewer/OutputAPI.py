from .utils import NativeCapabilityError

MESSAGE = "该能力仅 native 环境可用，Pyodide 不支持"


class SWMMOutputAPI:
    def __init__(self, *args, **kwargs):
        raise NativeCapabilityError(MESSAGE)
