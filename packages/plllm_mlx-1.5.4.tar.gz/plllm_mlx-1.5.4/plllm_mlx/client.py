"""
HTTP client for plllm-mlx service.

This module provides a client to interact with the plllm-mlx service API.
"""

from __future__ import annotations

import json
import sys
import time
from typing import Any, Dict, List, Optional

import httpx

from plllm_mlx.daemon import STATUS_FILE

_verbose = False


def set_verbose(verbose: bool):
    global _verbose
    _verbose = verbose


def _log_time(operation: str, elapsed: float):
    if _verbose:
        print(f"[TIMING] {operation}: {elapsed * 1000:.1f}ms")


class PlClient:
    """Client for plllm-mlx HTTP API."""

    def __init__(self, url: Optional[str] = None, timeout: float = 5.0):
        """
        Initialize client.

        Args:
            url: Service URL. If None, will auto-discover.
            timeout: HTTP request timeout in seconds.
        """
        start = time.time()
        self._timeout = timeout
        self._url = url
        self._client: Optional[httpx.Client] = None
        self._base_url: Optional[str] = None
        _log_time("PlClient.__init__", time.time() - start)

    @property
    def client(self) -> httpx.Client:
        """Get or create HTTP client."""
        if self._client is None:
            self._client = httpx.Client(timeout=self._timeout)
        return self._client

    @property
    def base_url(self) -> str:
        """Get base URL, discovering if needed."""
        if self._base_url is None:
            self._base_url = self._discover_service_url()
        return self._base_url

    def _get_url_from_status(self) -> Optional[str]:
        """Get URL from status file (fastest)."""
        if STATUS_FILE.exists():
            try:
                status = json.loads(STATUS_FILE.read_text())
                port = status.get("port", 8000)
                return f"http://localhost:{port}"
            except Exception:
                pass
        return None

    def _discover_service_url(self) -> str:
        """Auto-discover service URL by trying to connect."""
        # Fast: read from status file
        if self._url:
            return self._url

        url = self._get_url_from_status() or "http://localhost:8000"

        try:
            resp = self.client.get(f"{url}/health", timeout=1.0)
            if resp.status_code == 200:
                return url
        except Exception:
            pass

        print("Error: Service not running")
        print("Start with: plllm-mlx serve")
        sys.exit(1)

    def _check_service(self) -> bool:
        """Check if service is running."""
        try:
            response = self.client.get(f"{self.base_url}/health", timeout=1.0)
            return response.status_code == 200
        except Exception:
            return False

    def health_check(self) -> Dict[str, Any]:
        """Check service health."""
        response = self.client.get(f"{self.base_url}/health")
        response.raise_for_status()
        return response.json()

    def list_models(self, loaded_only: bool = False) -> List[Dict[str, Any]]:
        """
        List models.

        Args:
            loaded_only: If True, only return loaded models.

        Returns:
            List of model information.
        """
        response = self.client.get(f"{self.base_url}/v1/model/list")
        response.raise_for_status()
        models = response.json().get("data", [])

        if loaded_only:
            models = [m for m in models if m.get("is_loaded")]

        return models

    def search_models(self, keyword: str = "", limit: int = 50) -> List[Dict[str, Any]]:
        """
        Search models on HuggingFace.

        Args:
            keyword: Search keyword.
            limit: Maximum results.

        Returns:
            List of search results.
        """
        response = self.client.get(
            f"{self.base_url}/v1/model/search", params={"keyword": keyword}
        )
        response.raise_for_status()
        return response.json().get("data", [])[:limit]

    def load_model(
        self,
        model_name: str,
        loader: Optional[str] = None,
        step_processor: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Load a model.

        Args:
            model_name: Model name.
            loader: Model loader type (mlx/mlxvlm). If None, auto-detect.
            step_processor: Step processor type (base/qwen3think/openai). If None, auto-detect.
            timeout: Request timeout in seconds. If None, no timeout (wait for completion).

        Returns:
            Response data.
        """
        payload: Dict[str, Any] = {"model_name": model_name}
        if loader is not None:
            payload["loader"] = loader
        if step_processor is not None:
            payload["step_processor"] = step_processor

        request_timeout = timeout if timeout is not None else 300.0
        response = self.client.post(
            f"{self.base_url}/v1/model/load", json=payload, timeout=request_timeout
        )
        response.raise_for_status()
        return response.json()

    def unload_model(self, model_name: str) -> Dict[str, Any]:
        """
        Unload a model.

        Args:
            model_name: Model name.

        Returns:
            Response data.
        """
        response = self.client.post(
            f"{self.base_url}/v1/model/unload", json={"model_name": model_name}
        )
        response.raise_for_status()
        return response.json()

    def download_model(
        self,
        model_id: str,
        loader: Optional[str] = None,
        step_processor: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Download a model.

        Args:
            model_id: HuggingFace model ID.
            loader: Model loader type (mlx/mlxvlm). If None, auto-detect.
            step_processor: Step processor type (base/qwen3think/openai). If None, auto-detect.

        Returns:
            Response with task_id.
        """
        payload: Dict[str, Any] = {"model_id": model_id}
        if loader is not None:
            payload["model_loader"] = loader
        if step_processor is not None:
            payload["step_processor"] = step_processor

        response = self.client.post(
            f"{self.base_url}/v1/model/download",
            json=payload,
        )
        response.raise_for_status()
        return response.json()

    def get_download_status(self, task_id: str) -> Dict[str, Any]:
        """
        Get download task status.

        Args:
            task_id: Task ID.

        Returns:
            Task status.
        """
        response = self.client.get(
            f"{self.base_url}/v1/model/download/status/{task_id}"
        )
        response.raise_for_status()
        return response.json()

    def delete_model(self, model_name: str) -> Dict[str, Any]:
        """
        Delete a model.

        Args:
            model_name: Model name.

        Returns:
            Response data.
        """
        response = self.client.post(
            f"{self.base_url}/v1/model/delete", json={"model_name": model_name}
        )
        response.raise_for_status()
        return response.json()

    def update_config(self, model_name: str, key: str, value: Any) -> Dict[str, Any]:
        """
        Update model config.

        Args:
            model_name: Model name.
            key: Config key.
            value: Config value.

        Returns:
            Response data.
        """
        response = self.client.post(
            f"{self.base_url}/v1/model/update/config",
            json={"model_name": model_name, "key": key, "value": value},
        )
        response.raise_for_status()
        return response.json()

    def close(self):
        """Close client."""
        if self._client:
            self._client.close()
