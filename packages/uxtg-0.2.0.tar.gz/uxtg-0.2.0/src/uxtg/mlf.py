from __future__ import annotations

import io
import os.path
import re
from pathlib import Path
from typing import TextIO

from .constants import DEFAULT_MLF_PRECISION
from .textgrid import TextGrid
from .tiers import IntervalTier


class MLF:
    def __init__(self, text: str | None = None, samplerate: float = 10e6):
        self.grids: list[TextGrid] = []
        if text is not None:
            self.read_string(text, samplerate=samplerate)

    def __iter__(self):
        return iter(self.grids)

    def __str__(self) -> str:
        return f"<MLF, {len(self)} TextGrids>"

    def __repr__(self) -> str:
        return f"MLF({self.grids})"

    def __len__(self) -> int:
        return len(self.grids)

    def __getitem__(self, index: int) -> TextGrid:
        return self.grids[index]

    def _read_source(
        self,
        source: TextIO,
        samplerate: float,
        round_digits: int = DEFAULT_MLF_PRECISION,
    ) -> None:
        self.grids = []
        source.readline()

        while True:
            line = source.readline()
            if not line:
                break

            match = re.match(r'"(.*)"', line.rstrip())
            if not match:
                continue

            name = match.groups()[0]
            grid = TextGrid(name=name)
            phones = IntervalTier(name="phones")
            words = IntervalTier(name="words")
            current_word = ""
            word_start = 0.0
            word_end = 0.0

            while True:
                parts = source.readline().rstrip().split()
                if len(parts) == 4:
                    phone_min = round(float(parts[0]) / samplerate, round_digits)
                    phone_max = round(float(parts[1]) / samplerate, round_digits)
                    if phone_min == phone_max:
                        raise ValueError("null duration interval")
                    phones.add(phone_min, phone_max, parts[2])
                    if current_word:
                        words.add(word_start, word_end, current_word)
                    current_word = parts[3]
                    word_start = phone_min
                    word_end = phone_max
                elif len(parts) == 3:
                    phone_min = round(float(parts[0]) / samplerate, round_digits)
                    phone_max = round(float(parts[1]) / samplerate, round_digits)
                    if parts[2] == "sp" and phone_min != phone_max:
                        if current_word:
                            words.add(word_start, word_end, current_word)
                        current_word = parts[2]
                        word_start = phone_min
                        word_end = phone_max
                    elif phone_min != phone_max:
                        phones.add(phone_min, phone_max, parts[2])
                    word_end = phone_max
                else:
                    if current_word:
                        words.add(word_start, word_end, current_word)
                    break

            grid.append(phones)
            grid.append(words)
            self.grids.append(grid)

    def read_string(
        self,
        text: str,
        samplerate: float,
        round_digits: int = DEFAULT_MLF_PRECISION,
    ) -> None:
        self._read_source(io.StringIO(text), samplerate=samplerate, round_digits=round_digits)

    def read_file(
        self,
        path: str | Path,
        samplerate: float,
        round_digits: int = DEFAULT_MLF_PRECISION,
    ) -> None:
        with open(path, "r", encoding="utf-8") as source:
            self._read_source(source, samplerate=samplerate, round_digits=round_digits)

    def write(self, prefix: str | Path = "") -> int:
        for grid in self.grids:
            _, tail = os.path.split(grid.name or "")
            root, _ = os.path.splitext(tail)
            output_path = Path(prefix) / f"{root}.TextGrid"
            grid.write(output_path)
        return len(self.grids)

    @classmethod
    def from_string(cls, text: str, samplerate: float = 10e6) -> "MLF":
        return cls(text=text, samplerate=samplerate)

    @classmethod
    def from_file(cls, path: str | Path, samplerate: float = 10e6) -> "MLF":
        instance = cls()
        instance.read_file(path, samplerate=samplerate)
        return instance
