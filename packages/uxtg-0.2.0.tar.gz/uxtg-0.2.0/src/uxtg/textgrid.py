from __future__ import annotations

import io
from typing import TextIO

from ._io import PraatIO
from ._praat import format_mark, get_mark, parse_header, parse_line
from .constants import DEFAULT_TEXTGRID_PRECISION
from .exceptions import TextGridError
from .items import Interval, Point
from .tiers import IntervalTier, PointTier


class TextGrid(PraatIO):
    def __init__(
        self,
        name: str | None = None,
        minTime: float = 0.0,
        maxTime: float | None = None,
        strict: bool = True,
    ):
        self.name = name
        self.minTime = minTime
        self.maxTime = maxTime
        self.tiers: list[IntervalTier | PointTier] = []
        self.strict = strict

    def __eq__(self, other: object) -> bool:
        return (
            isinstance(other, TextGrid)
            and self.name == other.name
            and self.minTime == other.minTime
            and self.maxTime == other.maxTime
            and self.strict == other.strict
            and self.tiers == other.tiers
        )

    def __str__(self) -> str:
        return f"<TextGrid {self.name}, {len(self)} Tiers>"

    def __repr__(self) -> str:
        return f"TextGrid({self.name}, {self.tiers})"

    def __iter__(self):
        return iter(self.tiers)

    def __len__(self) -> int:
        return len(self.tiers)

    def __getitem__(self, index: int) -> IntervalTier | PointTier:
        return self.tiers[index]

    def get_first(self, tier_name: str) -> IntervalTier | PointTier | None:
        for tier in self.tiers:
            if tier.name == tier_name:
                return tier
        return None

    def get_list(self, tier_name: str) -> list[IntervalTier | PointTier]:
        return [tier for tier in self.tiers if tier.name == tier_name]

    def get_names(self) -> list[str | None]:
        return [tier.name for tier in self.tiers]

    def bounds(self) -> tuple[float, float]:
        if self.maxTime is not None:
            return self.minTime, self.maxTime
        if not self.tiers:
            return self.minTime, self.minTime
        return self.minTime, max(tier.bounds()[1] for tier in self.tiers)

    def append(self, tier: IntervalTier | PointTier) -> None:
        tier_min, tier_max = tier.bounds()
        if tier_min < self.minTime:
            raise ValueError(self.minTime)
        if self.maxTime is not None and tier_max > self.maxTime:
            raise ValueError(self.maxTime)
        if isinstance(tier, IntervalTier):
            tier.strict = self.strict
        self.tiers.append(tier)

    def extend(self, tiers: list[IntervalTier | PointTier]) -> None:
        for tier in tiers:
            self.append(tier)

    def pop(self, index: int | None = None) -> IntervalTier | PointTier:
        return self.tiers.pop() if index is None else self.tiers.pop(index)

    def _read_source(self, source: TextIO, round_digits: int = DEFAULT_TEXTGRID_PRECISION) -> None:
        file_type, short = parse_header(source)
        if file_type != "TextGrid":
            raise TextGridError(
                "The input could not be parsed as a TextGrid because it is lacking a proper header."
            )

        self.tiers = []
        first_line = source.readline()
        try:
            parse_line(first_line, short, round_digits)
        except ValueError:
            short = True

        self.minTime = parse_line(first_line, short, round_digits)
        self.maxTime = parse_line(source.readline(), short, round_digits)
        source.readline()

        if short:
            tier_count = int(source.readline().strip())
        else:
            tier_count = int(source.readline().strip().split()[2])
            source.readline()

        for _ in range(tier_count):
            if not short:
                source.readline()

            tier_type = parse_line(source.readline(), short, round_digits)
            tier_name = parse_line(source.readline(), short, round_digits)
            tier_min = parse_line(source.readline(), short, round_digits)
            tier_max = parse_line(source.readline(), short, round_digits)

            if tier_type == "IntervalTier":
                tier = IntervalTier(name=tier_name, minTime=tier_min, maxTime=tier_max, strict=self.strict)
                item_count = int(parse_line(source.readline(), short, round_digits))
                for _ in range(item_count):
                    if not short:
                        source.readline()
                    item_min = parse_line(source.readline(), short, round_digits)
                    item_max = parse_line(source.readline(), short, round_digits)
                    item_mark = get_mark(source, short)
                    if item_min < item_max:
                        tier.add_interval(Interval(item_min, item_max, item_mark))
            elif tier_type == "TextTier":
                tier = PointTier(name=tier_name, minTime=tier_min, maxTime=tier_max)
                item_count = int(parse_line(source.readline(), short, round_digits))
                for _ in range(item_count):
                    if not short:
                        source.readline()
                    point_time = parse_line(source.readline(), short, round_digits)
                    point_mark = get_mark(source, short)
                    tier.add_point(Point(point_time, point_mark))
            else:
                raise TextGridError(f"Unsupported tier type: {tier_type}")

            self.append(tier)

    def to_string(self, null: str | None = "") -> str:
        sink = io.StringIO()
        _, max_time = self.bounds()

        print('File type = "ooTextFile"', file=sink)
        print('Object class = "TextGrid"\n', file=sink)
        print(f"xmin = {self.minTime}", file=sink)
        print(f"xmax = {max_time}", file=sink)
        print("tiers? <exists>", file=sink)
        print(f"size = {len(self)}", file=sink)
        print("item []:", file=sink)

        for tier_index, tier in enumerate(self.tiers, start=1):
            tier_min, tier_max = tier.bounds()
            print(f"\titem [{tier_index}]:", file=sink)
            if isinstance(tier, IntervalTier):
                output = tier._fill_gaps(null)
                print('\t\tclass = "IntervalTier"', file=sink)
                print(f'\t\tname = "{format_mark(tier.name)}"', file=sink)
                print(f"\t\txmin = {tier_min}", file=sink)
                print(f"\t\txmax = {tier_max}", file=sink)
                print(f"\t\tintervals: size = {len(output)}", file=sink)
                for item_index, interval in enumerate(output, start=1):
                    print(f"\t\t\tintervals [{item_index}]:", file=sink)
                    print(f"\t\t\t\txmin = {interval.minTime}", file=sink)
                    print(f"\t\t\t\txmax = {interval.maxTime}", file=sink)
                    print(f'\t\t\t\ttext = "{format_mark(interval.mark)}"', file=sink)
            else:
                print('\t\tclass = "TextTier"', file=sink)
                print(f'\t\tname = "{format_mark(tier.name)}"', file=sink)
                print(f"\t\txmin = {tier_min}", file=sink)
                print(f"\t\txmax = {tier_max}", file=sink)
                print(f"\t\tpoints: size = {len(tier)}", file=sink)
                for item_index, point in enumerate(tier, start=1):
                    print(f"\t\t\tpoints [{item_index}]:", file=sink)
                    print(f"\t\t\t\ttime = {point.time}", file=sink)
                    print(f'\t\t\t\tmark = "{format_mark(point.mark)}"', file=sink)

        return sink.getvalue()
