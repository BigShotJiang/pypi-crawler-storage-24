from __future__ import annotations

import io
from bisect import bisect_left, bisect_right
from typing import TextIO

from ._io import PraatIO
from ._praat import format_mark, get_mark, parse_header, parse_line
from .constants import DEFAULT_TEXTGRID_PRECISION
from .exceptions import TextGridError
from .items import Interval, Point


def _point_insert_index(points: list[Point], time: float) -> int:
    return bisect_left([point.time for point in points], time)


def _interval_insert_index(intervals: list[Interval], min_time: float) -> int:
    return bisect_right([interval.minTime for interval in intervals], min_time)


class PointTier(PraatIO):
    def __init__(self, name: str | None = None, minTime: float = 0.0, maxTime: float | None = None):
        self.name = name
        self.minTime = minTime
        self.maxTime = maxTime
        self.points: list[Point] = []

    def __eq__(self, other: object) -> bool:
        return (
            isinstance(other, PointTier)
            and self.name == other.name
            and self.minTime == other.minTime
            and self.maxTime == other.maxTime
            and self.points == other.points
        )

    def __str__(self) -> str:
        return f"<PointTier {self.name}, {len(self)} points>"

    def __repr__(self) -> str:
        return f"PointTier({self.name}, {self.points})"

    def __iter__(self):
        return iter(self.points)

    def __len__(self) -> int:
        return len(self.points)

    def __getitem__(self, index: int) -> Point:
        return self.points[index]

    def add(self, time: float, mark: str | None) -> None:
        self.add_point(Point(time, mark))

    def add_point(self, point: Point) -> None:
        if point.time < self.minTime:
            raise ValueError(self.minTime)
        if self.maxTime is not None and point.time > self.maxTime:
            raise ValueError(self.maxTime)

        index = _point_insert_index(self.points, point.time)
        if index < len(self.points) and self.points[index].time == point.time:
            raise ValueError(point)
        self.points.insert(index, point)

    def remove(self, time: float, mark: str | None) -> None:
        self.remove_point(Point(time, mark))

    def remove_point(self, point: Point) -> None:
        self.points.remove(point)

    def bounds(self) -> tuple[float, float]:
        if self.maxTime is not None:
            return self.minTime, self.maxTime
        if not self.points:
            return self.minTime, self.minTime
        return self.minTime, self.points[-1].time

    def _read_source(self, source: TextIO, round_digits: int = DEFAULT_TEXTGRID_PRECISION) -> None:
        file_type, short = parse_header(source)
        if file_type != "TextTier":
            raise TextGridError(
                "The input could not be parsed as a PointTier because it is lacking a proper header."
            )

        self.points = []
        self.minTime = parse_line(source.readline(), short, round_digits)
        self.maxTime = parse_line(source.readline(), short, round_digits)
        point_count = int(parse_line(source.readline(), short, round_digits))

        for _ in range(point_count):
            if not short:
                source.readline()
            point_time = parse_line(source.readline(), short, round_digits)
            point_mark = get_mark(source, short)
            self.add_point(Point(point_time, point_mark))

    def to_string(self) -> str:
        sink = io.StringIO()
        _, max_time = self.bounds()
        print('File type = "ooTextFile"', file=sink)
        print('Object class = "TextTier"\n', file=sink)
        print(f"xmin = {self.minTime}", file=sink)
        print(f"xmax = {max_time}", file=sink)
        print(f"points: size = {len(self)}", file=sink)
        for index, point in enumerate(self.points, start=1):
            print(f"points [{index}]:", file=sink)
            print(f"\ttime = {point.time}", file=sink)
            print(f'\tmark = "{format_mark(point.mark)}"', file=sink)
        return sink.getvalue()


class IntervalTier(PraatIO):
    def __init__(
        self,
        name: str | None = None,
        minTime: float = 0.0,
        maxTime: float | None = None,
        strict: bool = True,
    ):
        self.name = name
        self.minTime = minTime
        self.maxTime = maxTime
        self.intervals: list[Interval] = []
        self.strict = strict

    def __eq__(self, other: object) -> bool:
        return (
            isinstance(other, IntervalTier)
            and self.name == other.name
            and self.minTime == other.minTime
            and self.maxTime == other.maxTime
            and self.strict == other.strict
            and self.intervals == other.intervals
        )

    def __str__(self) -> str:
        return f"<IntervalTier {self.name}, {len(self)} intervals>"

    def __repr__(self) -> str:
        return f"IntervalTier({self.name}, {self.intervals})"

    def __iter__(self):
        return iter(self.intervals)

    def __len__(self) -> int:
        return len(self.intervals)

    def __getitem__(self, index: int) -> Interval:
        return self.intervals[index]

    def add(self, minTime: float, maxTime: float, mark: str | None) -> None:
        self.add_interval(Interval(minTime, maxTime, mark))

    def add_interval(self, interval: Interval) -> None:
        if interval.minTime < self.minTime:
            raise ValueError(self.minTime)
        if self.maxTime is not None and interval.maxTime > self.maxTime:
            raise ValueError(self.maxTime)

        index = _interval_insert_index(self.intervals, interval.minTime)
        previous = self.intervals[index - 1] if index > 0 else None
        following = self.intervals[index] if index < len(self.intervals) else None

        if self.strict:
            if previous is not None and previous.overlaps(interval):
                raise ValueError(previous, interval)
            if following is not None and interval.overlaps(following):
                raise ValueError(interval, following)

        self.intervals.insert(index, interval)

    def remove(self, minTime: float, maxTime: float, mark: str | None) -> None:
        self.remove_interval(Interval(minTime, maxTime, mark))

    def remove_interval(self, interval: Interval) -> None:
        self.intervals.remove(interval)

    def index_containing(self, time: float) -> int | None:
        index = bisect_right([interval.minTime for interval in self.intervals], time) - 1
        if index < 0:
            return None

        if self.strict:
            return index if self.intervals[index].contains_time(time) else None

        while index >= 0:
            interval = self.intervals[index]
            if interval.contains_time(time):
                return index
            index -= 1
        return None

    def interval_containing(self, time: float) -> Interval | None:
        index = self.index_containing(time)
        return self.intervals[index] if index is not None else None

    def bounds(self) -> tuple[float, float]:
        if self.maxTime is not None:
            return self.minTime, self.maxTime
        if not self.intervals:
            return self.minTime, self.minTime
        return self.minTime, self.intervals[-1].maxTime

    def _fill_gaps(self, null: str | None) -> list[Interval]:
        prev_time = self.minTime
        output: list[Interval] = []
        for interval in self.intervals:
            if prev_time < interval.minTime:
                output.append(Interval(prev_time, interval.minTime, null))
            output.append(interval)
            prev_time = interval.maxTime
        if self.maxTime is not None and prev_time < self.maxTime:
            output.append(Interval(prev_time, self.maxTime, null))
        return output

    def _read_source(self, source: TextIO, round_digits: int = DEFAULT_TEXTGRID_PRECISION) -> None:
        file_type, short = parse_header(source)
        if file_type != "IntervalTier":
            raise TextGridError(
                "The input could not be parsed as an IntervalTier because it is lacking a proper header."
            )

        self.intervals = []
        self.minTime = parse_line(source.readline(), short, round_digits)
        self.maxTime = parse_line(source.readline(), short, round_digits)
        interval_count = int(parse_line(source.readline(), short, round_digits))

        for _ in range(interval_count):
            if not short:
                source.readline()
            interval_min = parse_line(source.readline(), short, round_digits)
            interval_max = parse_line(source.readline(), short, round_digits)
            interval_mark = get_mark(source, short)
            if interval_min < interval_max:
                self.add_interval(Interval(interval_min, interval_max, interval_mark))

    def to_string(self, null: str | None = "") -> str:
        sink = io.StringIO()
        _, max_time = self.bounds()
        output = self._fill_gaps(null)
        print('File type = "ooTextFile"', file=sink)
        print('Object class = "IntervalTier"\n', file=sink)
        print(f"xmin = {self.minTime}", file=sink)
        print(f"xmax = {max_time}", file=sink)
        print(f"intervals: size = {len(output)}", file=sink)
        for index, interval in enumerate(output, start=1):
            print(f"intervals [{index}]:", file=sink)
            print(f"\txmin = {interval.minTime}", file=sink)
            print(f"\txmax = {interval.maxTime}", file=sink)
            print(f'\ttext = "{format_mark(interval.mark)}"', file=sink)
        return sink.getvalue()
