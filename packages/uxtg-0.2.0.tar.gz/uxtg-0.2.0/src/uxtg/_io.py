from __future__ import annotations

import codecs
import io
from pathlib import Path
from typing import Any, TextIO, TypeVar

from ._praat import detect_encoding
from .constants import DEFAULT_TEXTGRID_PRECISION

ReadableWritable = TypeVar("ReadableWritable", bound="PraatIO")


class PraatIO:
    def _read_source(self, source: TextIO, round_digits: int = DEFAULT_TEXTGRID_PRECISION) -> None:
        raise NotImplementedError

    def to_string(self, **kwargs: Any) -> str:
        raise NotImplementedError

    def read_string(self, text: str, round_digits: int = DEFAULT_TEXTGRID_PRECISION) -> None:
        self._read_source(io.StringIO(text), round_digits=round_digits)

    def read(self, text: str, round_digits: int = DEFAULT_TEXTGRID_PRECISION) -> None:
        self.read_string(text, round_digits=round_digits)

    def read_file(
        self,
        path: str | Path,
        round_digits: int = DEFAULT_TEXTGRID_PRECISION,
        encoding: str | None = None,
    ) -> None:
        file_encoding = encoding or detect_encoding(path)
        with codecs.open(path, "r", encoding=file_encoding) as source:
            self._read_source(source, round_digits=round_digits)

    def write(self, target: str | Path | TextIO, **kwargs: Any) -> None:
        text = self.to_string(**kwargs)
        if hasattr(target, "write"):
            target.write(text)
            return
        with codecs.open(target, "w", "utf-8") as sink:
            sink.write(text)

    @classmethod
    def from_string(
        cls: type[ReadableWritable],
        text: str,
        round_digits: int = DEFAULT_TEXTGRID_PRECISION,
        **kwargs: Any,
    ) -> ReadableWritable:
        instance = cls(**kwargs)
        instance.read_string(text, round_digits=round_digits)
        return instance

    @classmethod
    def from_file(
        cls: type[ReadableWritable],
        path: str | Path,
        round_digits: int = DEFAULT_TEXTGRID_PRECISION,
        encoding: str | None = None,
        **kwargs: Any,
    ) -> ReadableWritable:
        instance = cls(**kwargs)
        instance.read_file(path, round_digits=round_digits, encoding=encoding)
        return instance
