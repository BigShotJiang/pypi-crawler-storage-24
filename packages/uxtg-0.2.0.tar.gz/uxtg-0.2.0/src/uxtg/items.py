from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class Point:
    time: float
    mark: str | None

    def shift(self, offset: float) -> "Point":
        self.time += offset
        return self


@dataclass(slots=True)
class Interval:
    minTime: float
    maxTime: float
    mark: str | None

    def __post_init__(self) -> None:
        if self.minTime >= self.maxTime:
            raise ValueError(self.minTime, self.maxTime)

    def duration(self) -> float:
        return self.maxTime - self.minTime

    def bounds(self) -> tuple[float, float]:
        return self.minTime, self.maxTime

    def overlaps(self, other: "Interval") -> bool:
        return other.minTime < self.maxTime and self.minTime < other.maxTime

    def contains_time(self, time: float) -> bool:
        return self.minTime <= time <= self.maxTime

    def contains_interval(self, other: "Interval") -> bool:
        return self.minTime <= other.minTime and other.maxTime <= self.maxTime

    def shift(self, offset: float) -> "Interval":
        self.minTime += offset
        self.maxTime += offset
        return self
