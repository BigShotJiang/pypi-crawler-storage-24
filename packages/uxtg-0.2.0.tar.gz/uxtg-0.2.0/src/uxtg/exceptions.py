class TextGridError(Exception):
    """Raised when Praat/TextGrid content cannot be parsed."""

