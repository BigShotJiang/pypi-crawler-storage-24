# uxtg

`uxtg` 提供 Praat `TextGrid` / `TextTier` / `IntervalTier` 与 HTK `MLF` 的读取、写出和基础操作接口。

## Features

- `Point` / `Interval` 基础数据对象
- `PointTier` / `IntervalTier` 容器与区间查询
- `TextGrid` 读写与层级管理
- `MLF` 到 `TextGrid` 的转换
- 统一使用 snake_case API，如 `from_file`、`get_first`
