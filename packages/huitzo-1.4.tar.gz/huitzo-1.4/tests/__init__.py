"""Test suite for Huitzo CLI."""
