"""
Module: test_config_cmd
Description: Tests for configuration management commands

Implements:
    - docs/cli/reference.md#huitzo-config
"""

from pathlib import Path

import pytest
from typer.testing import CliRunner

from huitzo_cli.commands.config_cmd import config_app
from huitzo_cli.config import ConfigManager


def test_config_get(cli_runner: CliRunner, temp_dir: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Test getting config value."""
    monkeypatch.setattr(ConfigManager, "_get_config_dir", staticmethod(lambda: temp_dir / "config"))

    result = cli_runner.invoke(config_app, ["get", "api_url"])
    assert result.exit_code == 0
    assert "https://api.huitzo.ai" in result.stdout


def test_config_set(cli_runner: CliRunner, temp_dir: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Test setting config value."""
    monkeypatch.setattr(ConfigManager, "_get_config_dir", staticmethod(lambda: temp_dir / "config"))

    result = cli_runner.invoke(config_app, ["set", "api_url", "https://test.example.com"])
    assert result.exit_code == 0
    assert "set to" in result.stdout


def test_config_list(
    cli_runner: CliRunner, temp_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test listing config values."""
    monkeypatch.setattr(ConfigManager, "_get_config_dir", staticmethod(lambda: temp_dir / "config"))

    result = cli_runner.invoke(config_app, ["list"])
    assert result.exit_code == 0
    assert "api_url" in result.stdout


def test_config_list_masks_sensitive(
    cli_runner: CliRunner, temp_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test config list masks sensitive values like auth.token."""
    monkeypatch.setattr(ConfigManager, "_get_config_dir", staticmethod(lambda: temp_dir / "config"))

    # Set a sensitive value
    manager = ConfigManager(project_root=temp_dir)
    manager.set("auth.token", "super-secret-token", scope="user")

    result = cli_runner.invoke(config_app, ["list"])
    assert result.exit_code == 0
    assert "********" in result.stdout
    assert "super-secret-token" not in result.stdout


def test_config_get_masks_sensitive(
    cli_runner: CliRunner, temp_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test config get masks sensitive values by default."""
    monkeypatch.setattr(ConfigManager, "_get_config_dir", staticmethod(lambda: temp_dir / "config"))

    manager = ConfigManager(project_root=temp_dir)
    manager.set("auth.token", "super-secret-token", scope="user")

    result = cli_runner.invoke(config_app, ["get", "auth.token"])
    assert result.exit_code == 0
    assert "********" in result.stdout
    assert "super-secret-token" not in result.stdout


def test_config_get_reveal(
    cli_runner: CliRunner, temp_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test config get --reveal shows sensitive values unmasked."""
    monkeypatch.setattr(ConfigManager, "_get_config_dir", staticmethod(lambda: temp_dir / "config"))

    manager = ConfigManager(project_root=temp_dir)
    manager.set("auth.token", "super-secret-token", scope="user")

    result = cli_runner.invoke(config_app, ["get", "auth.token", "--reveal"])
    assert result.exit_code == 0
    assert "super-secret-token" in result.stdout
    assert "********" not in result.stdout


def test_config_path(
    cli_runner: CliRunner, temp_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test showing config path."""
    monkeypatch.setattr(ConfigManager, "_get_config_dir", staticmethod(lambda: temp_dir / "config"))

    result = cli_runner.invoke(config_app, ["path"])
    assert result.exit_code == 0
    assert "config.yaml" in result.stdout
