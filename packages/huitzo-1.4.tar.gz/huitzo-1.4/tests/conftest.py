"""
Module: conftest
Description: Pytest fixtures for CLI tests

Implements:
    - docs/cli/reference.md#testing
"""

import os
import tempfile
from pathlib import Path
from typing import Generator

import pytest
from typer.testing import CliRunner


@pytest.fixture(scope="session", autouse=True)
def set_test_mode() -> None:
    """Set HUITZO_TEST_MODE environment variable for all tests."""
    os.environ["HUITZO_TEST_MODE"] = "1"


@pytest.fixture
def cli_runner() -> CliRunner:
    """Provide a CLI test runner."""
    return CliRunner()


@pytest.fixture
def temp_dir() -> Generator[Path, None, None]:
    """Provide a temporary directory that is cleaned up after the test."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def temp_config_dir(temp_dir: Path) -> Path:
    """Provide a temporary config directory."""
    config_dir = temp_dir / ".huitzo"
    config_dir.mkdir(parents=True, exist_ok=True)
    return config_dir
