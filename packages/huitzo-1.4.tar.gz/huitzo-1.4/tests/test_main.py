"""
Module: test_main
Description: Tests for main CLI entry point

Implements:
    - docs/cli/reference.md#testing
"""

from typer.testing import CliRunner

from huitzo_cli.main import app
from huitzo_cli.version import get_version


def test_version_flag(cli_runner: CliRunner) -> None:
    """Test --version flag."""
    result = cli_runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "huitzo-cli" in result.stdout
    assert get_version() in result.stdout


def test_help_flag(cli_runner: CliRunner) -> None:
    """Test --help flag."""
    result = cli_runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "Huitzo CLI" in result.stdout


def test_no_args_shows_help(cli_runner: CliRunner) -> None:
    """Test that running with no args shows help."""
    result = cli_runner.invoke(app, [])
    assert result.exit_code == 0
    assert "Huitzo CLI" in result.stdout


def test_verbose_flag(cli_runner: CliRunner) -> None:
    """Test --verbose flag parsing."""
    result = cli_runner.invoke(app, ["--verbose", "--help"])
    assert result.exit_code == 0


def test_quiet_flag(cli_runner: CliRunner) -> None:
    """Test --quiet flag parsing."""
    result = cli_runner.invoke(app, ["--quiet", "--help"])
    assert result.exit_code == 0


def test_config_option(cli_runner: CliRunner) -> None:
    """Test --config option parsing."""
    result = cli_runner.invoke(app, ["--config", "/path/to/config", "--help"])
    assert result.exit_code == 0
