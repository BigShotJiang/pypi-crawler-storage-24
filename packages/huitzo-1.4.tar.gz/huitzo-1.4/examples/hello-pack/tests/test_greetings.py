"""
Module: test_greetings
Description: Tests for greeting commands
"""

import pytest

from hello_pack.commands.greetings import goodbye, hello


@pytest.mark.asyncio
async def test_hello_default() -> None:
    """Test hello command with default name."""
    result = await hello({}, None)  # type: ignore
    assert result["message"] == "Hello, World!"


@pytest.mark.asyncio
async def test_hello_with_name() -> None:
    """Test hello command with custom name."""
    result = await hello({"name": "Alice"}, None)  # type: ignore
    assert result["message"] == "Hello, Alice!"


@pytest.mark.asyncio
async def test_goodbye_default() -> None:
    """Test goodbye command with default name."""
    result = await goodbye({}, None)  # type: ignore
    assert result["message"] == "Goodbye, friend!"


@pytest.mark.asyncio
async def test_goodbye_with_name() -> None:
    """Test goodbye command with custom name."""
    result = await goodbye({"name": "Bob"}, None)  # type: ignore
    assert result["message"] == "Goodbye, Bob!"
