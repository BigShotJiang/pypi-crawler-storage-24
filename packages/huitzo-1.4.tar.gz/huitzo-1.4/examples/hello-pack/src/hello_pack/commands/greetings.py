"""
Module: greetings
Description: Greeting commands for Hello Pack

Implements:
    - docs/sdk/commands.md
"""

from huitzo_sdk import Context, command


@command("hello", namespace="hello", timeout=30)
async def hello(args: dict, ctx: Context) -> dict:
    """Greet someone.

    Args:
        args: Should contain 'name' key (optional)
        ctx: Huitzo context

    Returns:
        Greeting message
    """
    name = args.get("name", "World")
    return {"message": f"Hello, {name}!"}


@command("goodbye", namespace="hello", timeout=30)
async def goodbye(args: dict, ctx: Context) -> dict:
    """Say goodbye.

    Args:
        args: Should contain 'name' key (optional)
        ctx: Huitzo context

    Returns:
        Goodbye message
    """
    name = args.get("name", "friend")
    return {"message": f"Goodbye, {name}!"}
