"""
Module: repl.formatter
Description: Output formatting for REPL responses using rich for syntax highlighting.

Implements:
    - docs/cli/reference.md#interactive-repl
    - docs/cli/reference.md#huitzo-pack-dev

See Also:
    - docs/cli/reference.md#repl-features
"""

from __future__ import annotations

import json
from typing import Any

from rich.console import Console
from rich.syntax import Syntax
from rich.table import Table


class OutputFormatter:
    """Formats REPL output with syntax-highlighted JSON and rich tables.

    Uses the rich library to produce colorized, readable output in the terminal.
    """

    def __init__(self, console: Console | None = None) -> None:
        """Initialize the output formatter.

        Args:
            console: Rich Console instance. Creates one if not provided.
        """
        self.console = console or Console()

    def format_json(self, data: Any) -> None:
        """Print data as syntax-highlighted JSON.

        Args:
            data: Any JSON-serializable data
        """
        text = json.dumps(data, indent=2, default=str)
        syntax = Syntax(text, "json", theme="monokai", padding=0)
        self.console.print(syntax)

    def format_command_list(self, commands: list[dict[str, Any]]) -> None:
        """Print a table of available commands.

        Args:
            commands: List of command metadata dicts with name, namespace, description
        """
        if not commands:
            self.console.print("[yellow]No commands available.[/yellow]")
            return

        table = Table(title="Available Commands")
        table.add_column("Command", style="bold cyan")
        table.add_column("Namespace", style="green")
        table.add_column("Description")

        for cmd in commands:
            table.add_row(
                cmd.get("name", ""),
                cmd.get("namespace", ""),
                (cmd.get("description", "") or "")[:60],
            )

        self.console.print(table)

    def format_command_detail(self, cmd: dict[str, Any]) -> None:
        """Print detailed info for a single command.

        Args:
            cmd: Command metadata dict
        """
        self.console.print(f"\n[bold cyan]{cmd.get('name', 'unknown')}[/bold cyan]")
        self.console.print(f"  Namespace: [green]{cmd.get('namespace', 'N/A')}[/green]")
        self.console.print(f"  Timeout:   {cmd.get('timeout', 'default')}s")
        self.console.print(f"  Queue:     {cmd.get('queue', 'auto')}")
        if cmd.get("description"):
            self.console.print(f"  Description: {cmd['description']}")
        self.console.print()

    def format_file_list(self, files: list[dict[str, Any]]) -> None:
        """Print a table of uploaded files.

        Args:
            files: List of file metadata dicts with name, size, path
        """
        if not files:
            self.console.print("[yellow]No files uploaded.[/yellow]")
            return

        table = Table(title="Uploaded Files")
        table.add_column("Name", style="bold cyan")
        table.add_column("Size", justify="right", style="green")
        table.add_column("Sandbox Path")

        for f in files:
            size = f.get("size", 0)
            if size >= 1024 * 1024:
                size_str = f"{size / (1024 * 1024):.1f} MB"
            elif size >= 1024:
                size_str = f"{size / 1024:.1f} KB"
            else:
                size_str = f"{size} B"
            table.add_row(
                f.get("name", ""),
                size_str,
                f.get("path", ""),
            )

        self.console.print(table)

    def format_error(self, message: str) -> None:
        """Print an error message.

        Args:
            message: Error text to display
        """
        self.console.print(f"[red]Error: {message}[/red]")

    def format_success(self, message: str) -> None:
        """Print a success message.

        Args:
            message: Success text to display
        """
        self.console.print(f"[green]{message}[/green]")

    def format_info(self, message: str) -> None:
        """Print an informational message.

        Args:
            message: Info text to display
        """
        self.console.print(f"[dim]{message}[/dim]")
