"""
Module: repl.client
Description: HTTP client wrapper for REPL communication with the local sandbox.

Implements:
    - docs/cli/reference.md#interactive-repl
    - docs/cli/reference.md#huitzo-pack-dev

See Also:
    - docs/cli/reference.md#endpoints-available-via-proxy
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import httpx


class REPLClient:
    """HTTP client for communicating with the local sandbox server.

    Wraps httpx.AsyncClient to provide typed methods for listing commands,
    executing commands, and checking health. Uses verify=False since the
    sandbox uses a self-signed certificate.
    """

    def __init__(self, base_url: str, auth_token: str | None = None) -> None:
        """Initialize the REPL client.

        Args:
            base_url: Base URL of the sandbox server (e.g. https://localhost:8080)
            auth_token: Bearer token for sandbox authentication
        """
        self._base_url = base_url.rstrip("/")
        self._auth_token = auth_token
        self._client: httpx.AsyncClient | None = None

    async def _ensure_client(self) -> httpx.AsyncClient:
        """Lazily create the async HTTP client."""
        if self._client is None:
            headers: dict[str, str] = {}
            if self._auth_token:
                headers["Authorization"] = f"Bearer {self._auth_token}"
            self._client = httpx.AsyncClient(
                base_url=self._base_url,
                headers=headers,
                verify=False,  # Self-signed cert from sandbox
                timeout=60.0,
            )
        return self._client

    async def list_commands(self) -> dict[str, Any]:
        """Fetch available commands from the sandbox.

        Returns:
            Dict with "commands" key containing list of command metadata.

        Raises:
            httpx.HTTPStatusError: On non-2xx response
        """
        client = await self._ensure_client()
        response = await client.get("/commands")
        response.raise_for_status()
        result: dict[str, Any] = response.json()
        return result

    async def execute_command(self, name: str, args: dict[str, Any]) -> dict[str, Any]:
        """Execute a pack command via the sandbox.

        Args:
            name: Command name (short name, not namespaced)
            args: Command arguments as a dict

        Returns:
            Command result wrapped in {"data": ...}

        Raises:
            httpx.HTTPStatusError: On non-2xx response
        """
        client = await self._ensure_client()
        response = await client.post(f"/commands/{name}", json={"args": args})
        response.raise_for_status()
        result: dict[str, Any] = response.json()
        return result

    async def describe_command(self, name: str) -> dict[str, Any] | None:
        """Get metadata for a specific command.

        Args:
            name: Command name to describe

        Returns:
            Command metadata dict, or None if not found
        """
        data = await self.list_commands()
        commands: list[dict[str, Any]] = data.get("commands", [])
        for cmd in commands:
            if cmd.get("name") == name:
                return cmd
        return None

    async def health(self) -> bool:
        """Check if the sandbox is healthy.

        Returns:
            True if the sandbox responds with status ok
        """
        try:
            client = await self._ensure_client()
            response = await client.get("/health")
            return response.status_code == 200
        except httpx.HTTPError:
            return False

    async def upload_file(self, path: Path) -> dict[str, Any]:
        """Upload a local file to the sandbox.

        Args:
            path: Local filesystem path to the file

        Returns:
            Dict with sandbox path, size, and original_name

        Raises:
            FileNotFoundError: If the local file does not exist
            httpx.HTTPStatusError: On non-2xx response
        """
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        if not path.is_file():
            raise FileNotFoundError(f"Not a file: {path}")

        client = await self._ensure_client()
        with open(path, "rb") as f:
            response = await client.post(
                "/files",
                files={"file": (path.name, f)},
            )
        response.raise_for_status()
        result: dict[str, Any] = response.json()
        return result

    async def list_files(self) -> dict[str, Any]:
        """List files uploaded to the sandbox.

        Returns:
            Dict with "files" key containing list of file metadata

        Raises:
            httpx.HTTPStatusError: On non-2xx response
        """
        client = await self._ensure_client()
        response = await client.get("/files")
        response.raise_for_status()
        result: dict[str, Any] = response.json()
        return result

    async def clear_files(self) -> dict[str, Any]:
        """Delete all uploaded files from the sandbox.

        Returns:
            Dict with "deleted" key containing count of deleted files

        Raises:
            httpx.HTTPStatusError: On non-2xx response
        """
        client = await self._ensure_client()
        response = await client.delete("/files")
        response.raise_for_status()
        result: dict[str, Any] = response.json()
        return result

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None
