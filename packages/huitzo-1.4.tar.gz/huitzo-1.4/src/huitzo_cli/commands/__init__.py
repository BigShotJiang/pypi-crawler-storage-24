"""
Module: commands
Description: CLI commands for Huitzo.

Implements:
    - docs/cli/reference.md
"""
