"""
Module: validate_command
Description: Pack validation command

Implements:
    - docs/cli/reference.md#huitzo-validate
"""

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from huitzo_cli.validator import PackValidator

console = Console()


def validate(
    path: Optional[Path] = typer.Option(None, "--path", help="Path to pack root"),
    strict: bool = typer.Option(False, "--strict", help="Treat warnings as errors"),
) -> None:
    """Validate Intelligence Pack structure.

    Checks for:
    - pyproject.toml with required fields
    - huitzo.yaml manifest with required fields
    - Source directory with Python package
    - Test directory with tests
    - README documentation
    """
    pack_root = path or Path.cwd()

    if not pack_root.exists():
        console.print(f"[red]❌ Pack path not found: {pack_root}[/red]")
        raise typer.Exit(1)

    validator = PackValidator(pack_root=pack_root)
    result = validator.validate(strict=strict)

    # Print results
    console.print()
    if result.valid:
        console.print("[green]✅ Validation: PASSED[/green]")
    else:
        console.print("[red]❌ Validation: FAILED[/red]")

    if result.errors:
        console.print("\n[red]Errors:[/red]")
        for error in result.errors:
            console.print(f"  • {error}")

    if result.warnings:
        console.print("\n[yellow]Warnings:[/yellow]")
        for warning in result.warnings:
            console.print(f"  • {warning}")

    console.print()

    if not result.valid:
        raise typer.Exit(1)
