"""
Module: secrets_command
Description: Secrets management commands (local storage only)

Implements:
    - docs/cli/reference.md#huitzo-secrets
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import typer
from rich.console import Console
from rich.table import Table

console = Console()
secrets_app = typer.Typer(help="Manage secrets")


@secrets_app.callback(invoke_without_command=True)
def secrets_callback(ctx: typer.Context) -> None:
    """Manage secrets - set, list, and remove pack secrets."""
    if ctx.invoked_subcommand is None:
        console.print(ctx.get_help())
        raise typer.Exit(0)


class SecretsStore:
    """Local secrets storage."""

    @staticmethod
    def _get_secrets_dir() -> Path:
        """Get platform-specific secrets directory."""
        if os.name == "nt":  # Windows
            base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
            return base / "huitzo" / "secrets"
        else:  # Unix-like
            return Path.home() / ".huitzo" / "secrets"

    @classmethod
    def _get_secrets_file(cls, pack_name: str = "default") -> Path:
        """Get secrets file for pack."""
        return cls._get_secrets_dir() / f"{pack_name}.json"

    @classmethod
    def set(cls, name: str, value: str, pack: str = "default") -> None:
        """Store a secret."""
        secrets_dir = cls._get_secrets_dir()
        secrets_dir.mkdir(parents=True, exist_ok=True)

        # Set restrictive permissions on directory
        if os.name != "nt":
            secrets_dir.chmod(0o700)

        secrets_file = cls._get_secrets_file(pack)

        # Load existing secrets
        secrets = {}
        if secrets_file.exists():
            try:
                with open(secrets_file) as f:
                    secrets = json.load(f)
            except (json.JSONDecodeError, OSError):
                pass

        # Add new secret
        secrets[name] = value

        # Save secrets with restrictive permissions atomically
        if os.name != "nt":
            fd = os.open(str(secrets_file), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w") as f:
                json.dump(secrets, f)
        else:
            with open(secrets_file, "w") as f:
                json.dump(secrets, f)

    @classmethod
    def get(cls, name: str, pack: str = "default") -> str | None:
        """Get a secret."""
        secrets_file = cls._get_secrets_file(pack)

        if not secrets_file.exists():
            return None

        try:
            with open(secrets_file) as f:
                secrets: dict[str, Any] = json.load(f)
                value: str | None = secrets.get(name)
                return value
        except (json.JSONDecodeError, OSError):
            return None

    @classmethod
    def list_secrets(cls, pack: str = "default") -> dict[str, Any]:
        """List all secrets for a pack."""
        secrets_file = cls._get_secrets_file(pack)

        if not secrets_file.exists():
            return {}

        try:
            with open(secrets_file) as f:
                result: dict[str, Any] = json.load(f)
                return result
        except (json.JSONDecodeError, OSError):
            return {}

    @classmethod
    def remove(cls, name: str, pack: str = "default") -> bool:
        """Remove a secret.

        Returns:
            True if the key was found and removed, False if not found.
        """
        secrets_file = cls._get_secrets_file(pack)

        if not secrets_file.exists():
            return False

        try:
            with open(secrets_file) as f:
                secrets = json.load(f)
        except (json.JSONDecodeError, OSError):
            return False

        if name not in secrets:
            return False

        del secrets[name]

        if os.name != "nt":
            fd = os.open(str(secrets_file), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w") as f:
                json.dump(secrets, f)
        else:
            with open(secrets_file, "w") as f:
                json.dump(secrets, f)

        return True


@secrets_app.command()
def set(
    name: str,
    value: str | None = typer.Argument(None, help="Secret value (omit to enter interactively)"),
    pack: str = typer.Option("default", "--pack", help="Pack name"),
) -> None:
    """Set a secret.

    If VALUE is omitted, you will be prompted to enter it interactively
    (input is hidden). This avoids exposing secrets in shell history.

    Args:
        name: Secret name
        value: Secret value (optional — prompted if omitted)
    """
    if value is None:
        value = typer.prompt("Secret value", hide_input=True)

    console.print("[yellow]Secrets are stored locally only[/yellow]")
    console.print("[yellow]Cloud sync is not yet available[/yellow]")
    console.print()

    SecretsStore.set(name, value, pack=pack)
    console.print(f"[green]Secret '{name}' set[/green]")


@secrets_app.command(name="list")
def list_secrets(pack: str = typer.Option("default", "--pack", help="Pack name")) -> None:
    """List all secrets."""
    console.print("[yellow]ℹ️  Secrets are stored locally only[/yellow]")
    console.print()

    secrets = SecretsStore.list_secrets(pack=pack)

    if not secrets:
        console.print(f"[yellow]No secrets for pack '{pack}'[/yellow]")
        return

    table = Table(title=f"Secrets (pack: {pack})")
    table.add_column("Name", style="cyan")
    table.add_column("Value", style="yellow")

    for name, value in secrets.items():
        masked_value = "*" * 8 if value else "(empty)"
        table.add_row(name, masked_value)

    console.print(table)


@secrets_app.command()
def remove(
    name: str,
    pack: str = typer.Option("default", "--pack", help="Pack name"),
) -> None:
    """Remove a secret.

    Args:
        name: Secret name
    """
    removed = SecretsStore.remove(name, pack=pack)
    if removed:
        console.print(f"[green]Secret '{name}' removed[/green]")
    else:
        console.print(f"[yellow]Secret '{name}' not found[/yellow]")
        raise typer.Exit(1)
