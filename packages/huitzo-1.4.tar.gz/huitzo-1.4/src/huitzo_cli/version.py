"""
Module: version
Description: Version management for Huitzo CLI

Implements:
    - docs/cli/reference.md#version-management
"""

from importlib.metadata import PackageNotFoundError, version


def get_version() -> str:
    """Get the current version of Huitzo CLI from package metadata."""
    try:
        return version("huitzo")
    except PackageNotFoundError:
        return "0.0.0-dev"
