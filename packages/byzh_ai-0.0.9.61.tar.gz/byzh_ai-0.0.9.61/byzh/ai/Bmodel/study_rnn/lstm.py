import torch
import torch.nn as nn
import torch.nn.functional as F

from byzh.ai.Butils import b_get_params

class B_LSTM_Paper(nn.Module):
    """
    单层 LSTM（教学/论文公式对齐版）

    每个时间步:
        f_t = sigmoid(x_t W_xf + h_{t-1} W_hf + b_f)
        i_t = sigmoid(x_t W_xi + h_{t-1} W_hi + b_i)
        g_t = tanh(   x_t W_xg + h_{t-1} W_hg + b_g)
        o_t = sigmoid(x_t W_xo + h_{t-1} W_ho + b_o)

        c_t = f_t * c_{t-1} + i_t * g_t
        h_t = o_t * tanh(c_t)

    B = batch size
    T = sequence length
    D = input_size
    H = hidden_size
    C = output_size
    """

    def __init__(self, input_size: int, hidden_size: int,
                 output_size: int = None, batch_first: bool = True, bias: bool = True):
        super().__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.batch_first = batch_first

        # forget gate
        self.x2f = nn.Linear(input_size, hidden_size, bias=bias)
        self.h2f = nn.Linear(hidden_size, hidden_size, bias=bias)

        # input gate
        self.x2i = nn.Linear(input_size, hidden_size, bias=bias)
        self.h2i = nn.Linear(hidden_size, hidden_size, bias=bias)

        # candidate memory
        self.x2g = nn.Linear(input_size, hidden_size, bias=bias)
        self.h2g = nn.Linear(hidden_size, hidden_size, bias=bias)

        # output gate
        self.x2o = nn.Linear(input_size, hidden_size, bias=bias)
        self.h2o = nn.Linear(hidden_size, hidden_size, bias=bias)

        self.h2y = nn.Linear(hidden_size, output_size, bias=bias) if output_size is not None else None

        self.reset_parameters()

    def step(self, x_t, h_prev, c_prev):
        """
        x_t:    (B, D)
        h_prev: (B, H)
        c_prev: (B, H)
        """
        f_t = torch.sigmoid(self.x2f(x_t) + self.h2f(h_prev)) # 遗忘门
        i_t = torch.sigmoid(self.x2i(x_t) + self.h2i(h_prev)) # 输入门
        g_t = torch.tanh(   self.x2g(x_t) + self.h2g(h_prev)) # 候选记忆 \tilde{c_t}
        o_t = torch.sigmoid(self.x2o(x_t) + self.h2o(h_prev)) # 输出门

        c_t = f_t * c_prev + i_t * g_t # 更新细胞状态
        h_t = o_t * torch.tanh(c_t) # 更新隐藏状态

        return h_t, c_t

    def forward(self, x, h0=None, c0=None, return_sequences=True):
        """
        x:
            batch_first=True  -> (B, T, D)
            batch_first=False -> (T, B, D)

        h0, c0:
            (B, H)

        return:
            hs: (B, T, H) or (T, B, H) or None
            hT: (B, H)
            cT: (B, H)
            ys: (B, T, C) or (T, B, C) or None
        """
        if not self.batch_first:
            x = x.transpose(0, 1)  # -> (B, T, D)

        B, T, D = x.shape

        h_t = x.new_zeros(B, self.hidden_size) if h0 is None else h0 # (B, H)
        c_t = x.new_zeros(B, self.hidden_size) if c0 is None else c0 # (B, H)

        hs = [] if return_sequences else None
        ys = [] if (return_sequences and self.h2y is not None) else None

        for t in range(T):
            x_t = x[:, t, :]
            h_t, c_t = self.step(x_t, h_t, c_t)

            if return_sequences:
                hs.append(h_t)
                if self.h2y is not None:
                    ys.append(self.h2y(h_t))

        hT, cT = h_t, c_t

        if return_sequences:
            hs = torch.stack(hs, dim=1)  # (B, T, H)
            if ys is not None:
                ys = torch.stack(ys, dim=1)  # (B, T, C)

            if not self.batch_first:
                hs = hs.transpose(0, 1)
                if ys is not None:
                    ys = ys.transpose(0, 1)

        return hs, hT, cT, ys

    def reset_parameters(self):
        modules = [
            self.x2f, self.h2f,
            self.x2i, self.h2i,
            self.x2g, self.h2g,
            self.x2o, self.h2o
        ]

        for m in modules:
            nn.init.xavier_uniform_(m.weight)
            if m.bias is not None:
                nn.init.zeros_(m.bias)

        if self.h2y is not None:
            nn.init.xavier_uniform_(self.h2y.weight)
            if self.h2y.bias is not None:
                nn.init.zeros_(self.h2y.bias)

class B_LSTM_Paper_Layers(nn.Module):
    """
    多层 LSTM（通过堆叠多个 B_LSTM_Paper 实现）
    """

    def __init__(self, input_size, hidden_size, num_layers=2, output_size=None, batch_first=True):
        super().__init__()

        self.num_layers = num_layers
        self.batch_first = batch_first

        layers = []

        for i in range(num_layers):

            if i == 0:
                in_dim = input_size
            else:
                in_dim = hidden_size

            # 最后一层才接输出
            out_dim = output_size if i == num_layers - 1 else None

            layers.append(
                B_LSTM_Paper(
                    input_size=in_dim,
                    hidden_size=hidden_size,
                    output_size=out_dim,
                    batch_first=batch_first
                )
            )

        self.layers = nn.ModuleList(layers)

    def forward(self, x):

        hs = x

        hT_list = []
        cT_list = []

        ys = None

        for i, layer in enumerate(self.layers):

            hs, hT, cT, ys = layer(hs, return_sequences=True)

            hT_list.append(hT)
            cT_list.append(cT)

        return hs, hT_list, cT_list, ys

if __name__ == '__main__':
    # ===== 超参数 =====
    B = 50  # batch size
    T = 6  # sequence length
    D = 8  # input_size
    H = 16  # hidden_size
    C = 5  # output_size

    net = B_LSTM_Paper(D, H, C, batch_first=True)
    a = torch.randn(B, T, D)
    hs, hT, cT, ys = net(a)
    print(hT.shape)
    print(f"参数量: {b_get_params(net)}")  # 1_749