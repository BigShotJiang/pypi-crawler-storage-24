# copy all the codes from here to run

import torch
import torch.nn as nn
import torch.nn.functional as F

from byzh.ai.Btrainer import B_Classification_Trainer
from byzh.ai.Bdata import B_Download_MNIST, b_get_dataloader_from_tensor, b_stratified_indices
# from uploadToPypi_ai.byzh.ai.Bmodel.study_rnn import B_GRU_Paper
from byzh.ai.Bmodel.study_rnn import B_GRU_Paper
from byzh.ai.Butils import b_get_device

##### hyper params #####
epochs = 10
lr = 1e-3
batch_size = 128
device = b_get_device(use_idle_gpu=True)

##### data #####
downloader = B_Download_MNIST(save_dir='D:/study_model/datasets/MNIST')
data_dict = downloader.get_data()
X_train = data_dict['X_train_standard']
y_train = data_dict['y_train']
X_test = data_dict['X_test_standard']
y_test = data_dict['y_test']
num_classes = data_dict['num_classes']

train_dataloader, val_dataloader = b_get_dataloader_from_tensor(
    X_train, y_train, X_test, y_test,
    batch_size=batch_size
)

##### model #####
class MNIST_PixelGRU(nn.Module):
    """
    用 GRU 做 pixel-wise MNIST 分类。

    输入:
        x: (B, 1, 28, 28)

    处理流程:
        (B, 1, 28, 28)
        -> reshape
        -> (B, 28, 28)
        -> RNN
        -> 取最终隐藏状态 hT
        -> Linear(H, 10)
        -> logits: (B, 10)
    """

    def __init__(self, hidden_size=128, num_classes=10):
        super().__init__()

        self.gru = B_GRU_Paper(
            input_size=28,          # 每个时间步有28个像素值
            hidden_size=hidden_size,
            output_size=None,      # backbone 先不直接输出类别
            batch_first=True,
        )

        self.cls = nn.Linear(hidden_size, num_classes, bias=True)

        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.cls.weight)
        if self.cls.bias is not None:
            nn.init.zeros_(self.cls.bias)

    def forward(self, x):
        """
        x: (B, 1, 28, 28)

        return:
            logits: (B, 10)
        """
        # (B, 1, 28, 28) -> (B, 28, 28)
        x = x.squeeze(1)

        # RNN 编码
        hs, hT, ys = self.gru(x, return_sequences=False)

        # 最终分类
        logits = self.cls(hT)  # (B, 10)
        return logits

model = MNIST_PixelGRU(num_classes=num_classes)

##### else #####
optimizer = torch.optim.Adam(model.parameters(), lr=lr)
criterion = torch.nn.CrossEntropyLoss()

##### trainer #####
trainer = B_Classification_Trainer(
    model=model,
    optimizer=optimizer,
    criterion=criterion,
    train_loader=train_dataloader,
    val_loader=val_dataloader,
    device=device
)
trainer.set_writer1('./runs/gru/log.txt')

##### run #####
trainer.train_eval_s(epochs=epochs)

##### calculate #####
trainer.draw_loss_acc('./runs/gru/loss_acc.png', y_lim=False)
trainer.save_best_checkpoint('./runs/gru/best_checkpoint.pth')
trainer.calculate_model()

