import torch
import torch.nn as nn
import torch.nn.functional as F

from byzh.ai.Butils import b_get_params


class B_GRU_Paper(nn.Module):
    """
    单层 GRU（教学/论文公式对齐版）

    每个时间步:
        z_t = sigmoid(x_t W_xz + h_{t-1} W_hz + b_z)
        r_t = sigmoid(x_t W_xr + h_{t-1} W_hr + b_r)
        h~_t = tanh( x_t W_xh + (r_t * h_{t-1}) W_hh + b_h )

        h_t = (1 - z_t) * h_{t-1} + z_t * h~_t

    B = batch size
    T = sequence length
    D = input_size
    H = hidden_size
    C = output_size
    """

    def __init__(self, input_size: int, hidden_size: int,
                 output_size: int = None, batch_first: bool = True, bias: bool = True):
        super().__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.batch_first = batch_first

        # update gate
        self.x2z = nn.Linear(input_size, hidden_size, bias=bias)
        self.h2z = nn.Linear(hidden_size, hidden_size, bias=bias)

        # reset gate
        self.x2r = nn.Linear(input_size, hidden_size, bias=bias)
        self.h2r = nn.Linear(hidden_size, hidden_size, bias=bias)

        # candidate hidden state
        self.x2h = nn.Linear(input_size, hidden_size, bias=bias)
        self.h2h = nn.Linear(hidden_size, hidden_size, bias=bias)

        # optional output projection
        self.h2y = nn.Linear(hidden_size, output_size, bias=bias) if output_size is not None else None

        self.reset_parameters()

    def step(self, x_t, h_prev):
        """
        x_t:    (B, D)
        h_prev: (B, H)
        """
        z_t = torch.sigmoid(self.x2z(x_t) + self.h2z(h_prev))         # 更新门
        r_t = torch.sigmoid(self.x2r(x_t) + self.h2r(h_prev))         # 重置门
        h_hat = torch.tanh(self.x2h(x_t) + self.h2h(r_t * h_prev))    # 候选隐藏状态

        h_t = (1 - z_t) * h_prev + z_t * h_hat                        # 更新隐藏状态

        return h_t

    def forward(self, x, h0=None, return_sequences=True):
        """
        x:
            batch_first=True  -> (B, T, D)
            batch_first=False -> (T, B, D)

        h0:
            (B, H)

        return:
            hs: (B, T, H) or (T, B, H) or None
            hT: (B, H)
            ys: (B, T, C) or (T, B, C) or None
        """
        if not self.batch_first:
            x = x.transpose(0, 1)  # -> (B, T, D)

        B, T, D = x.shape

        h_t = x.new_zeros(B, self.hidden_size) if h0 is None else h0  # (B, H)

        hs = [] if return_sequences else None
        ys = [] if (return_sequences and self.h2y is not None) else None

        for t in range(T):
            x_t = x[:, t, :]
            h_t = self.step(x_t, h_t)

            if return_sequences:
                hs.append(h_t)
                if self.h2y is not None:
                    ys.append(self.h2y(h_t))

        hT = h_t

        if return_sequences:
            hs = torch.stack(hs, dim=1)  # (B, T, H)
            if ys is not None:
                ys = torch.stack(ys, dim=1)  # (B, T, C)

            if not self.batch_first:
                hs = hs.transpose(0, 1)
                if ys is not None:
                    ys = ys.transpose(0, 1)

        return hs, hT, ys

    def reset_parameters(self):
        modules = [
            self.x2z, self.h2z,
            self.x2r, self.h2r,
            self.x2h, self.h2h
        ]

        for m in modules:
            nn.init.xavier_uniform_(m.weight)
            if m.bias is not None:
                nn.init.zeros_(m.bias)

        if self.h2y is not None:
            nn.init.xavier_uniform_(self.h2y.weight)
            if self.h2y.bias is not None:
                nn.init.zeros_(self.h2y.bias)

class B_GRU_Paper_Layers(nn.Module):
    """
    多层 GRU（通过堆叠多个 B_GRU_Paper 实现）
    """

    def __init__(self, input_size, hidden_size, num_layers=2, output_size=None, batch_first=True):
        super().__init__()

        self.num_layers = num_layers
        self.batch_first = batch_first

        layers = []

        for i in range(num_layers):

            if i == 0:
                in_dim = input_size
            else:
                in_dim = hidden_size

            # 最后一层才接输出
            out_dim = output_size if i == num_layers - 1 else None

            layers.append(
                B_GRU_Paper(
                    input_size=in_dim,
                    hidden_size=hidden_size,
                    output_size=out_dim,
                    batch_first=batch_first
                )
            )

        self.layers = nn.ModuleList(layers)

    def forward(self, x):
        """
        return:
            hs: 最后一层所有时间步隐藏状态
            hT_list: 每一层最后时刻隐藏状态列表
            ys: 最后一层每个时间步输出（如果最后一层有 output_size）
        """
        hs = x
        hT_list = []
        ys = None

        for i, layer in enumerate(self.layers):
            hs, hT, ys = layer(hs, return_sequences=True)
            hT_list.append(hT)

        return hs, hT_list, ys


if __name__ == '__main__':
    # ===== 超参数 =====
    B = 50  # batch size
    T = 6  # sequence length
    D = 8  # input_size
    H = 16  # hidden_size
    C = 5  # output_size

    net = B_GRU_Paper(D, H, C, batch_first=True)
    a = torch.randn(B, T, D)
    hs, hT, ys = net(a)
    print(hT.shape)
    print(f"参数量: {b_get_params(net)}")  # 1_333