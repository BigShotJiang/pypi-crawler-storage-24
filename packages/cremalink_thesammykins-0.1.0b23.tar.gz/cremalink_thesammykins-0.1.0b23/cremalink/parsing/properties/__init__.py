"""
This package handles the parsing and decoding of device 'properties'.

Properties are key-value pairs that represent the static or semi-static
attributes of the coffee machine, such as configuration settings or counters.
"""

from cremalink.parsing.properties.decode import PropertiesSnapshot
from cremalink.parsing.properties.recipes import (
    RecipeIngredientValue,
    RecipeOrder,
    StoredRecipe,
    StoredRecipeCatalog,
    build_stored_recipe_catalog,
    decode_favorite_priority,
    decode_recipe_priority,
    decode_stored_recipe,
)

__all__ = [
    "PropertiesSnapshot",
    "RecipeIngredientValue",
    "RecipeOrder",
    "StoredRecipe",
    "StoredRecipeCatalog",
    "build_stored_recipe_catalog",
    "decode_favorite_priority",
    "decode_recipe_priority",
    "decode_stored_recipe",
]
