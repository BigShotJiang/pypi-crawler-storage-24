"""Decoders for stored recipe, priority, and favorite property blobs.

These blobs are exposed by the ECAM450 through Ayla properties such as
``d231_rec_bs_recipe`` and ``d240_rec_custom_1``. They are not live brew
commands; instead they represent stored recipe definitions and ordering data.
"""

from __future__ import annotations

import base64
from dataclasses import dataclass
from typing import Optional


INGREDIENT_NAMES: dict[int, str] = {
    0x00: "temp",
    0x01: "coffee",
    0x02: "taste",
    0x03: "granulometry",
    0x04: "blend",
    0x05: "infusion_speed",
    0x06: "preinfusion",
    0x07: "crema",
    0x08: "due_x_per",
    0x09: "milk",
    0x0A: "milk_temp",
    0x0B: "milk_froth",
    0x0C: "inversion",
    0x0D: "the_temp",
    0x0E: "the_profile",
    0x0F: "hot_water",
    0x10: "mix_velocity",
    0x11: "mix_duration",
    0x12: "density_multi_beverage",
    0x13: "temp_multi_beverage",
    0x14: "decalc_type",
    0x15: "temp_risciaquo",
    0x16: "water_risciaquo",
    0x17: "clean_type",
    0x18: "programmable",
    0x19: "visible",
    0x1A: "visible_in_programming",
    0x1B: "index_length",
    0x1C: "accessory",
}

_WIDE_INGREDIENT_IDS = {0x01, 0x09, 0x0F}

STORED_RECIPE_NAMES: dict[int, str] = {
    0x6B: "cold_milk",
    0x78: "coffee",
    0x79: "coffee_ess",
    0x7A: "coffee_pot",
    0x7B: "latte",
    0x7C: "cappuccino",
    0x8C: "mug",
    0x8D: "latte_mug",
    0x8E: "capp_mug",
    0xC8: "espresso_soul",
    0xE6: "custom_1",
    0xE7: "custom_2",
    0xE8: "custom_3",
    0xE9: "custom_4",
    0xEA: "custom_5",
    0xEB: "custom_6",
}


@dataclass(frozen=True)
class RecipeIngredientValue:
    ingredient_id: int
    ingredient_name: str
    value: int
    wide_encoding: bool


@dataclass(frozen=True)
class StoredRecipe:
    profile_id: int
    recipe_id: int
    recipe_name: str
    source_key: Optional[str]
    family_name: Optional[str]
    ingredients: tuple[RecipeIngredientValue, ...]
    checksum: int
    raw: bytes


@dataclass(frozen=True)
class RecipeOrder:
    bucket: int
    recipe_ids: tuple[int, ...]
    checksum: int
    raw: bytes

    @property
    def nonzero_recipe_ids(self) -> tuple[int, ...]:
        return tuple(recipe_id for recipe_id in self.recipe_ids if recipe_id)


def _decode_base64(blob_b64: Optional[str]) -> Optional[bytes]:
    if not blob_b64:
        return None
    try:
        return base64.b64decode(blob_b64)
    except Exception:
        return None


def _decode_ingredients(payload: bytes) -> tuple[RecipeIngredientValue, ...]:
    ingredients: list[RecipeIngredientValue] = []
    i = 0
    while i < len(payload):
        ingredient_id = payload[i]
        i += 1
        wide_encoding = ingredient_id in _WIDE_INGREDIENT_IDS
        if wide_encoding:
            if i + 1 >= len(payload):
                break
            value = (payload[i] << 8) | payload[i + 1]
            i += 2
        else:
            if i >= len(payload):
                break
            value = payload[i]
            i += 1
        ingredients.append(
            RecipeIngredientValue(
                ingredient_id=ingredient_id,
                ingredient_name=INGREDIENT_NAMES.get(
                    ingredient_id, f"unknown_{ingredient_id:02x}"
                ),
                value=value,
                wide_encoding=wide_encoding,
            )
        )
    return tuple(ingredients)


def decode_stored_recipe(blob_b64: Optional[str]) -> Optional[StoredRecipe]:
    """Decode a stored recipe blob from d230/d231/d240 properties.

    The observed ECAM450 format is:

    - bytes[0:2] wrapper header
    - byte[2]   request id 0xA6
    - byte[3]   response flag 0xF0
    - byte[4]   profile/group id
    - byte[5]   recipe id
    - bytes[6:-2] ingredient/value payload
    - bytes[-2:] checksum/trailer
    """
    raw = _decode_base64(blob_b64)
    if raw is None or len(raw) < 8:
        return None
    if raw[2] != 0xA6 or raw[3] != 0xF0:
        return None
    return StoredRecipe(
        profile_id=raw[4],
        recipe_id=raw[5],
        recipe_name=STORED_RECIPE_NAMES.get(raw[5], f"recipe_{raw[5]:02x}"),
        source_key=None,
        family_name=None,
        ingredients=_decode_ingredients(raw[6:-2]),
        checksum=int.from_bytes(raw[-2:], "big"),
        raw=raw,
    )


@dataclass(frozen=True)
class StoredRecipeCatalog:
    by_key: dict[str, StoredRecipe]
    by_profile: dict[int, dict[str, StoredRecipe]]
    by_recipe_id: dict[int, list[StoredRecipe]]
    current_profile_id: Optional[int]

    def current_profile_recipes(self) -> dict[str, StoredRecipe]:
        if self.current_profile_id is None:
            return {}
        return self.by_profile.get(self.current_profile_id, {})


def _family_name_from_key(source_key: str) -> str:
    parts = source_key.split("_")
    if len(parts) >= 4:
        return "_".join(parts[3:])
    return source_key


def build_stored_recipe_catalog(
    property_values: dict[str, str],
    current_profile_id: Optional[int] = None,
) -> StoredRecipeCatalog:
    by_key: dict[str, StoredRecipe] = {}
    by_profile: dict[int, dict[str, StoredRecipe]] = {}
    by_recipe_id: dict[int, list[StoredRecipe]] = {}

    for source_key, value in sorted(property_values.items()):
        recipe = decode_stored_recipe(value)
        if recipe is None:
            continue
        family_name = _family_name_from_key(source_key)
        recipe = StoredRecipe(
            profile_id=recipe.profile_id,
            recipe_id=recipe.recipe_id,
            recipe_name=recipe.recipe_name,
            source_key=source_key,
            family_name=family_name,
            ingredients=recipe.ingredients,
            checksum=recipe.checksum,
            raw=recipe.raw,
        )
        by_key[source_key] = recipe
        by_profile.setdefault(recipe.profile_id, {})[family_name] = recipe
        by_recipe_id.setdefault(recipe.recipe_id, []).append(recipe)

    return StoredRecipeCatalog(
        by_key=by_key,
        by_profile=by_profile,
        by_recipe_id=by_recipe_id,
        current_profile_id=current_profile_id,
    )


def decode_recipe_priority(blob_b64: Optional[str]) -> Optional[RecipeOrder]:
    """Decode a d261/d262/d263/d264 recipe-priority blob."""
    raw = _decode_base64(blob_b64)
    if raw is None or len(raw) < 7:
        return None
    if raw[2] != 0xA8 or raw[3] != 0xF0:
        return None
    return RecipeOrder(
        bucket=raw[4],
        recipe_ids=tuple(raw[5:-2]),
        checksum=int.from_bytes(raw[-2:], "big"),
        raw=raw,
    )


def decode_favorite_priority(blob_b64: Optional[str]) -> Optional[RecipeOrder]:
    """Decode a d265/d266/d267/d268 favorite-priority blob."""
    raw = _decode_base64(blob_b64)
    if raw is None or len(raw) < 7:
        return None
    if raw[2] != 0xAC or raw[3] != 0xF0:
        return None
    return RecipeOrder(
        bucket=raw[4],
        recipe_ids=tuple(raw[5:-2]),
        checksum=int.from_bytes(raw[-2:], "big"),
        raw=raw,
    )
