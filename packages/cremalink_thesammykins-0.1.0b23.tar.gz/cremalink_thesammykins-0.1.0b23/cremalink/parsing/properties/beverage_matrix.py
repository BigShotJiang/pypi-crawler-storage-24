"""Helpers for analyzing static and captured beverage command packets.

These functions are intentionally read-only. They help build a validated matrix of
which ingredient/value positions appear in static device-map commands and in live
captured app packets before we attempt any write-side generalization.
"""

from __future__ import annotations

from dataclasses import dataclass

from cremalink.parsing.properties.recipes import INGREDIENT_NAMES


_WIDE_INGREDIENT_IDS = {0x01, 0x09, 0x0F}
_BREW_MODE_NAMES = {
    0: "delete",
    1: "save",
    2: "prepare",
    3: "prepare_and_save",
    5: "save_inversion",
    6: "prepare_inversion",
    7: "prepare_and_save_inversion",
}
_TRIGGER_NAMES = {
    0: "dont_care",
    1: "start",
    2: "start_program_or_stop_v2",
    3: "next_step",
    4: "stop",
    5: "stop_program",
    6: "exit_program_ok",
    7: "advanced_mode",
}


@dataclass(frozen=True)
class BeverageIngredientValue:
    ingredient_id: int
    ingredient_name: str
    value: int
    wide_encoding: bool


@dataclass(frozen=True)
class BeverageCommandMatrixEntry:
    beverage_id: int
    trigger: int
    trigger_name: str
    mode: int
    mode_name: str
    ingredients: tuple[BeverageIngredientValue, ...]
    raw: bytes


def _decode_ingredients(payload: bytes) -> tuple[BeverageIngredientValue, ...]:
    ingredients: list[BeverageIngredientValue] = []
    i = 0
    while i < len(payload):
        ingredient_id = payload[i]
        i += 1
        wide_encoding = ingredient_id in _WIDE_INGREDIENT_IDS
        if wide_encoding:
            if i + 1 >= len(payload):
                break
            value = (payload[i] << 8) | payload[i + 1]
            i += 2
        else:
            if i >= len(payload):
                break
            value = payload[i]
            i += 1
        ingredients.append(
            BeverageIngredientValue(
                ingredient_id=ingredient_id,
                ingredient_name=INGREDIENT_NAMES.get(
                    ingredient_id, f"unknown_{ingredient_id:02x}"
                ),
                value=value,
                wide_encoding=wide_encoding,
            )
        )
    return tuple(ingredients)


def decode_beverage_command(hex_command: str) -> BeverageCommandMatrixEntry:
    raw = bytes.fromhex(hex_command)
    if len(raw) < 8 or raw[2] != 0x83 or raw[3] != 0xF0:
        raise ValueError("Not a beverage-dispensing packet")
    beverage_id = raw[4]
    trigger = raw[5]
    mode = raw[-3]
    payload = raw[6:-4]
    return BeverageCommandMatrixEntry(
        beverage_id=beverage_id,
        trigger=trigger,
        trigger_name=_TRIGGER_NAMES.get(trigger, f"unknown_{trigger}"),
        mode=mode,
        mode_name=_BREW_MODE_NAMES.get(mode, f"unknown_{mode}"),
        ingredients=_decode_ingredients(payload),
        raw=raw,
    )


def summarize_matrix(command_map: dict[str, dict[str, str]]) -> dict[str, dict]:
    matrix: dict[str, dict] = {}
    for key, entry in command_map.items():
        hex_command = entry.get("command")
        if not hex_command:
            continue
        try:
            decoded = decode_beverage_command(hex_command)
        except ValueError:
            continue
        matrix[key] = {
            "beverage_id": decoded.beverage_id,
            "trigger": decoded.trigger_name,
            "mode": decoded.mode_name,
            "ingredients": [
                {
                    "id": item.ingredient_id,
                    "name": item.ingredient_name,
                    "value": item.value,
                    "wide": item.wide_encoding,
                }
                for item in decoded.ingredients
            ],
        }
    return matrix
