#!/usr/bin/env python3
"""Print a decoded summary for an ECAM450 reverse-engineering dataset."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from cremalink.parsing.properties.recipes import (
    decode_favorite_priority,
    decode_recipe_priority,
    decode_stored_recipe,
)
from cremalink.parsing.properties.settings import decode_custom_recipe_names


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dataset", help="Path to a dataset JSON file")
    args = parser.parse_args()

    dataset = json.loads(Path(args.dataset).read_text())
    properties = dataset.get("properties", {})

    if not properties and dataset.get("recipes"):
        print("Structured dump summary:")
        print(f"  property_count: {dataset.get('property_count')}")
        print(f"  decoded_recipes: {len(dataset.get('recipes', {}))}")
        print(f"  recipe_priorities: {len(dataset.get('recipe_priorities', {}))}")
        print(f"  favorite_priorities: {len(dataset.get('favorite_priorities', {}))}")
        decoded = dataset.get("decoded", {})
        print(f"  custom_recipe_names: {decoded.get('custom_recipe_names', {})}")
        print(f"  profile_names: {decoded.get('profile_names', {})}")
        print(f"  active_profile: {decoded.get('active_profile')}")
        print(f"  temperature: {decoded.get('temperature')}")
        print("\nRecipe samples:")
        for key in sorted(dataset.get("recipes", {}))[:20]:
            recipe = dataset["recipes"][key]
            ingredients = ", ".join(
                f"{item['name']}={item['value']}" for item in recipe["ingredients"]
            )
            print(
                f"  {key}: {recipe['recipe_name']} ({recipe['recipe_id']:#04x}) [{ingredients}]"
            )
        return

    print("Custom recipe names:")
    names = decode_custom_recipe_names(
        properties.get("d053_custom_name_13"),
        properties.get("d054_custom_name_46"),
    )
    for slot, name in sorted(names.items()):
        print(f"  slot {slot}: {name}")

    print("\nStored recipes:")
    for key, value in sorted(properties.items()):
        if not key.startswith(
            ("d230_", "d231_", "d240_", "d241_", "d242_", "d243_", "d244_", "d245_")
        ):
            continue
        recipe = decode_stored_recipe(value)
        if recipe is None:
            continue
        ingredients = ", ".join(
            f"{item.ingredient_name}={item.value}" for item in recipe.ingredients
        )
        print(
            f"  {key}: {recipe.recipe_name} ({recipe.recipe_id:#04x}) [{ingredients}]"
        )

    print("\nRecipe priorities:")
    for key, value in sorted(properties.items()):
        if not key.startswith("d26"):
            continue
        order = decode_recipe_priority(value)
        if order is not None:
            print(
                f"  {key}: bucket={order.bucket} ids={list(order.nonzero_recipe_ids)}"
            )
            continue
        order = decode_favorite_priority(value)
        if order is not None:
            print(
                f"  {key}: bucket={order.bucket} ids={list(order.nonzero_recipe_ids)}"
            )


if __name__ == "__main__":
    main()
