#!/usr/bin/env python3
"""Group decoded ECAM450 recipes by family suffix and profile.

This script works on the structured dump produced by `capture_ayla_dataset.py`
or the checked-in `tests/fixtures/ecam450_full_dump.json` fixture.
"""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path


def family_name(key: str) -> str:
    parts = key.split("_")
    if len(parts) < 4:
        return key
    return "_".join(parts[3:])


def profile_id_from_key(key: str) -> int | None:
    parts = key.split("_")
    if len(parts) < 3:
        return None
    try:
        return int(parts[2])
    except ValueError:
        return None


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dataset", help="Path to a structured ECAM450 dump JSON file")
    args = parser.parse_args()

    data = json.loads(Path(args.dataset).read_text())
    recipes: dict[str, dict] = data["recipes"]

    grouped: dict[str, list[tuple[int | None, str, dict]]] = defaultdict(list)
    for key, recipe in sorted(recipes.items()):
        grouped[family_name(key)].append((profile_id_from_key(key), key, recipe))

    for family in sorted(grouped):
        print(f"\n[{family}]")
        for profile_id, key, recipe in grouped[family]:
            ingredients = ", ".join(
                f"{item['name']}={item['value']}" for item in recipe["ingredients"]
            )
            print(
                f"  profile={profile_id} key={key} recipe_id={recipe['recipe_id']} "
                f"name={recipe['recipe_name']} [{ingredients}]"
            )


if __name__ == "__main__":
    main()
