#!/usr/bin/env python3
"""Capture a reusable Ayla dataset for reverse engineering.

Usage:
    python scripts/capture_ayla_dataset.py \
      --token-file /path/to/token.json \
      --dsn AC000W032240853 \
      --output dataset.json
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import requests

from cremalink.clients.cloud import Client


DEFAULT_PROPERTY_PREFIXES = ("app_", "d23", "d24", "d25", "d26", "d28")


def fetch_json(url: str, headers: dict[str, str], params: dict[str, str] | None = None):
    response = requests.get(url, headers=headers, params=params, timeout=30)
    response.raise_for_status()
    return response.json()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--token-file", required=True)
    parser.add_argument("--dsn", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--history-pages", type=int, default=10)
    args = parser.parse_args()

    client = Client(args.token_file)
    api_url = client.ayla_api.get("API_URL")
    headers = {
        "User-Agent": "datatransport/3.1.2 android/",
        "Authorization": f"auth_token {client.access_token}",
        "Accept": "application/json",
    }

    dataset: dict[str, object] = {}
    dataset["device"] = fetch_json(f"{api_url}/dsns/{args.dsn}.json", headers)

    properties = fetch_json(f"{api_url}/dsns/{args.dsn}/properties.json", headers)
    property_map: dict[str, str] = {}
    interesting_properties: list[str] = []
    for item in properties:
        prop = item["property"]
        name = prop["name"]
        if name.startswith(DEFAULT_PROPERTY_PREFIXES):
            interesting_properties.append(name)
            if isinstance(prop.get("value"), str):
                property_map[name] = prop["value"]
    dataset["properties"] = property_map

    history: dict[str, object] = {}
    for prop_name in ("app_data_request", "app_data_response"):
        page = None
        batches = []
        for _ in range(args.history_pages):
            params = {"paginated": "true", "per_page": "100"}
            if page:
                params["page"] = page
            data = fetch_json(
                f"{api_url}/dsns/{args.dsn}/properties/{prop_name}/datapoints.json",
                headers,
                params=params,
            )
            batches.extend(data.get("datapoints", []))
            page = data.get("meta", {}).get("next_page")
            if not page:
                break
        history[prop_name] = batches
    dataset["history"] = history

    Path(args.output).write_text(json.dumps(dataset, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
