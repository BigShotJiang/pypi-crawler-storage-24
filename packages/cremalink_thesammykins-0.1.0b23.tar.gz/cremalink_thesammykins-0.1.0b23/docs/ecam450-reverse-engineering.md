# ECAM450 Reverse Engineering

This repository includes a reusable ECAM450 dataset fixture at `tests/fixtures/ecam450_dataset.json`.

What it contains:
- live custom recipe name blobs (`d053`, `d054`)
- built-in recipe definition blobs (`d230`, `d231`)
- custom recipe definition blobs (`d240`-`d245`)
- recipe/favorite ordering blobs (`d261`-`d268`)
- a sampled `app_data_request` history summary

Useful scripts:

```bash
python scripts/capture_ayla_dataset.py --token-file /path/to/token.json --dsn AC000W032240853 --output dataset.json
python scripts/validate_ecam450_dataset.py dataset.json
```

Current validated findings:
- `d240_rec_custom_1`-`d245_rec_custom_6` are real custom recipe definitions.
- `d261_recipe_priority_1` starts with custom recipe id `0xE6`, matching slot 1 / `Speshul`.
- stored recipe blobs decode cleanly as `recipe_id + ingredient/value pairs`.
- `app_data_request` remains the source of truth for live brew execution packets.

Safety notes:
- recipe decoding is model-gated through device-map `capabilities`
- ECAM450 currently opts into stored recipe decoding and priority decoding
- custom recipe execution is intentionally still disabled until an execution packet is validated

Other models:
- `tests/fixtures/ecam452_dataset.json` and `tests/fixtures/ecam612_dataset.json` are placeholders only
- do not enable recipe capabilities for those models until a real capture has been added and validated
