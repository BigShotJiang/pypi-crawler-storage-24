# ECAM450 Beverage Matrix Notes

This file tracks validated beverage-command structure from the static device map and captured app packets.

Current validated patterns:
- request id `0x83 0xF0` = beverage dispensing mode
- byte `4` = beverage id
- byte `5` = trigger (`1=start`, `3=next_step` observed)
- trailing mode byte distinguishes prepare/save variants
- a validated subset of payload bytes decodes as ingredient/value pairs using the same ingredient ids seen in stored recipe blobs
- static commands can contain additional model-specific framing bytes that should not be generalized without capture-backed validation

Current code/tests:
- `cremalink/parsing/properties/beverage_matrix.py`
- `tests/test_beverage_matrix.py`

Important caution:
- captured app packets can contain multi-step execution frames that are not identical to the static device-map command
- do not generalize write-side behavior from a single beverage capture without cross-drink validation
