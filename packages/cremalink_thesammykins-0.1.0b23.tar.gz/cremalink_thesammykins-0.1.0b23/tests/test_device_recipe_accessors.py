from pathlib import Path

from tests.helpers import make_fixture_device


FIXTURE_PATH = Path(__file__).parent / "fixtures" / "ecam450_dataset.json"
DEVICE_MAP_PATH = (
    Path(__file__).resolve().parents[1] / "cremalink" / "devices" / "ECAM450.json"
)


def _device():
    return make_fixture_device(
        FIXTURE_PATH,
        DEVICE_MAP_PATH,
    )


def test_get_custom_recipe_names_uses_fixture_dataset() -> None:
    device = _device()

    assert device.get_custom_recipe_names() == {
        1: "Speshul",
        2: "Custom 2",
        3: "Custom 3",
        4: "Custom 4",
        5: "Custom 5",
        6: "Custom 6",
    }


def test_get_custom_recipes_decodes_slots() -> None:
    device = _device()
    recipes = device.get_custom_recipes()

    assert sorted(recipes) == [1, 2, 3, 4, 5, 6]
    assert recipes[1].recipe_id == 0xE6
    assert recipes[1].recipe_name == "custom_1"
    assert [(item.ingredient_name, item.value) for item in recipes[1].ingredients] == [
        ("coffee", 110),
        ("taste", 5),
        ("hot_water", 0),
        ("milk", 299),
        ("inversion", 1),
        ("accessory", 2),
        ("visible", 1),
        ("milk_froth", 255),
    ]


def test_get_recipe_and_favorite_priorities_decode_fixture_data() -> None:
    device = _device()

    recipe_priorities = device.get_recipe_priorities()
    favorite_priorities = device.get_favorite_priorities()

    assert recipe_priorities[1].bucket == 1
    assert recipe_priorities[1].recipe_ids[0] == 0xE6
    assert recipe_priorities[2].recipe_ids[0] == 0xC8
    assert favorite_priorities[1].nonzero_recipe_ids == (0x07, 0x0C, 0xE6)
