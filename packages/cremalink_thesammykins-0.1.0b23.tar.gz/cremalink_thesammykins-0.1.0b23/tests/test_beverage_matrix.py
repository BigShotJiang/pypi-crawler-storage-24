import json
from pathlib import Path

from cremalink.parsing.properties.beverage_matrix import (
    decode_beverage_command,
    summarize_matrix,
)


DEVICE_MAP = json.loads(
    (
        Path(__file__).resolve().parents[1] / "cremalink" / "devices" / "ECAM450.json"
    ).read_text()
)
COMMAND_MAP = DEVICE_MAP["command_map"]


def test_decode_static_americano_command() -> None:
    decoded = decode_beverage_command(COMMAND_MAP["americano"]["command"])

    assert decoded.beverage_id == 0x06
    assert decoded.trigger_name == "start"
    assert decoded.mode_name == "prepare_inversion"
    assert [(item.ingredient_name, item.value) for item in decoded.ingredients] == [
        ("coffee", 40),
        ("hot_water", 110),
        ("index_length", 1),
        ("taste", 3),
    ]


def test_decode_static_cappuccino_mix_command() -> None:
    decoded = decode_beverage_command(COMMAND_MAP["cappuccino_mix"]["command"])

    assert decoded.beverage_id == 0x0F
    assert decoded.trigger_name == "start"
    assert decoded.mode_name == "unknown_10"
    assert [(item.ingredient_name, item.value) for item in decoded.ingredients] == [
        ("inversion", 1),
        ("accessory", 2),
        ("coffee", 50),
        ("index_length", 4),
        ("taste", 3),
        ("milk", 247),
    ]


def test_decode_live_americano_variant_matches_override_fields() -> None:
    decoded = decode_beverage_command("0d1283f0060301001402040f00b72701067224")

    assert decoded.beverage_id == 0x06
    assert decoded.trigger_name == "next_step"
    assert decoded.mode_name == "prepare_inversion"
    assert [(item.ingredient_name, item.value) for item in decoded.ingredients] == [
        ("coffee", 20),
        ("taste", 4),
        ("hot_water", 183),
    ]


def test_summarize_matrix_builds_entries_for_static_drinks() -> None:
    matrix = summarize_matrix(COMMAND_MAP)

    assert matrix["americano"]["beverage_id"] == 0x06
    assert matrix["americano"]["ingredients"][0] == {
        "id": 1,
        "name": "coffee",
        "value": 40,
        "wide": True,
    }
    assert matrix["cappuccino_mix"]["beverage_id"] == 0x0F
    assert matrix["hot_water"]["ingredients"][0]["name"] == "hot_water"
