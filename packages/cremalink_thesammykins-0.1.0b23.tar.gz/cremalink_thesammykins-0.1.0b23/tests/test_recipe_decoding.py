import json
from pathlib import Path

from cremalink.parsing.properties.recipes import (
    decode_favorite_priority,
    decode_recipe_priority,
    decode_stored_recipe,
)


FIXTURE_PATH = Path(__file__).parent / "fixtures" / "ecam450_dataset.json"
FIXTURE = json.loads(FIXTURE_PATH.read_text())
PROPS = FIXTURE["properties"]


def test_decode_builtin_espresso_soul_recipe() -> None:
    recipe = decode_stored_recipe(PROPS["d231_rec_bs_recipe"])

    assert recipe is not None
    assert recipe.profile_id == 1
    assert recipe.recipe_id == 0xC8
    assert recipe.recipe_name == "espresso_soul"
    assert [(item.ingredient_name, item.value) for item in recipe.ingredients] == [
        ("coffee", 40),
        ("index_length", 1),
        ("taste", 0),
        ("visible", 1),
    ]


def test_decode_builtin_cappuccino_recipe() -> None:
    recipe = decode_stored_recipe(PROPS["d231_rec_4_e_cb_cappuccino"])

    assert recipe is not None
    assert recipe.profile_id == 4
    assert recipe.recipe_id == 0x7C
    assert recipe.recipe_name == "cappuccino"
    assert [(item.ingredient_name, item.value) for item in recipe.ingredients] == [
        ("milk_froth", 2),
        ("inversion", 1),
        ("accessory", 6),
        ("visible", 1),
        ("coffee", 60),
        ("index_length", 1),
        ("milk", 96),
        ("taste", 1),
    ]


def test_decode_custom_recipe_slot_one() -> None:
    recipe = decode_stored_recipe(PROPS["d240_rec_custom_1"])

    assert recipe is not None
    assert recipe.profile_id == 1
    assert recipe.recipe_id == 0xE6
    assert recipe.recipe_name == "custom_1"
    assert [(item.ingredient_name, item.value) for item in recipe.ingredients] == [
        ("coffee", 110),
        ("taste", 5),
        ("hot_water", 0),
        ("milk", 299),
        ("inversion", 1),
        ("accessory", 2),
        ("visible", 1),
        ("milk_froth", 255),
    ]


def test_decode_recipe_priority_bucket_one() -> None:
    order = decode_recipe_priority(PROPS["d261_recipe_priority_1"])

    assert order is not None
    assert order.bucket == 1
    assert order.recipe_ids[:5] == (0xE6, 0x0F, 0x06, 0x01, 0x0A)
    assert order.nonzero_recipe_ids[0] == 0xE6


def test_decode_recipe_priority_bucket_three_empty() -> None:
    order = decode_recipe_priority(PROPS["d263_recipe_priority_3"])

    assert order is not None
    assert order.bucket == 3
    assert order.recipe_ids == ()


def test_decode_favorite_priority_bucket_one() -> None:
    order = decode_favorite_priority(PROPS["d265_favorite_priority_1"])

    assert order is not None
    assert order.bucket == 1
    assert order.recipe_ids[:3] == (0x07, 0x0C, 0xE6)
    assert order.nonzero_recipe_ids == (0x07, 0x0C, 0xE6)
