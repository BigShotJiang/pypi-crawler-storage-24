import json
from pathlib import Path

from cremalink.parsing.properties.recipes import build_stored_recipe_catalog


FULL_DUMP_PATH = Path(__file__).parent / "fixtures" / "ecam450_full_dump.json"
FULL_DUMP = json.loads(FULL_DUMP_PATH.read_text())


def test_full_dump_contains_large_recipe_catalog() -> None:
    assert FULL_DUMP["property_count"] == 298
    assert len(FULL_DUMP["recipes"]) >= 200
    assert len(FULL_DUMP["recipe_priorities"]) == 4
    assert len(FULL_DUMP["favorite_priorities"]) == 4


def test_full_dump_confirms_custom_recipe_slot_one() -> None:
    custom = FULL_DUMP["recipes"]["d240_rec_custom_1"]

    assert custom["recipe_id"] == 230
    assert custom["recipe_name"] == "custom_1"
    assert custom["ingredients"] == [
        {"id": 1, "name": "coffee", "value": 110, "wide": True},
        {"id": 2, "name": "taste", "value": 5, "wide": False},
        {"id": 15, "name": "hot_water", "value": 0, "wide": True},
        {"id": 9, "name": "milk", "value": 299, "wide": True},
        {"id": 12, "name": "inversion", "value": 1, "wide": False},
        {"id": 28, "name": "accessory", "value": 2, "wide": False},
        {"id": 25, "name": "visible", "value": 1, "wide": False},
        {"id": 11, "name": "milk_froth", "value": 255, "wide": False},
    ]


def test_full_dump_confirms_variant_recipe_families() -> None:
    americano = FULL_DUMP["recipes"]["d064_rec_1_americano"]
    iced_americano = FULL_DUMP["recipes"]["d079_rec_1_i_americano"]
    milk_americano = FULL_DUMP["recipes"]["d095_rec_1_mi_americano"]

    assert americano["recipe_id"] == 6
    assert iced_americano["recipe_id"] == 50
    assert milk_americano["recipe_id"] == 101
    assert americano["ingredients"] != iced_americano["ingredients"]
    assert iced_americano["ingredients"] != milk_americano["ingredients"]


def test_full_dump_confirms_favorite_and_usage_signals() -> None:
    assert FULL_DUMP["favorite_priorities"]["d265_favorite_priority_1"] == {
        "bucket": 1,
        "recipe_ids": [7, 12, 230],
    }
    assert FULL_DUMP["counters"]["d709_id6_americano"] == 40
    assert FULL_DUMP["counters"]["d717_id15_caprev"] == 462


def test_build_stored_recipe_catalog_groups_by_profile_and_family() -> None:
    catalog = build_stored_recipe_catalog(
        {
            key: row["value"]
            for key, row in {
                item["name"]: item
                for item in FULL_DUMP["raw_properties"]
                if isinstance(item["value"], str)
            }.items()
        },
        current_profile_id=FULL_DUMP["decoded"]["active_profile"],
    )

    assert catalog.current_profile_id == 1
    assert catalog.current_profile_recipes()["americano"].recipe_id == 6
    assert (
        catalog.current_profile_recipes()["americano"].source_key
        == "d064_rec_1_americano"
    )
    assert catalog.current_profile_recipes()["cappuccino"].recipe_id == 7
    assert catalog.by_profile[4]["americano"].source_key == "d193_rec_4_americano"
    assert {recipe.source_key for recipe in catalog.by_recipe_id[230]} == {
        "d240_rec_custom_1"
    }
