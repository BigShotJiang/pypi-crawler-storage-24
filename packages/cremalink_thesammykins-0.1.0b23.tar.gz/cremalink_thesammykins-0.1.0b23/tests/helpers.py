import json
from pathlib import Path

from cremalink.domain.device import Device


class FixtureTransport:
    def __init__(self, properties: dict[str, str]) -> None:
        self.properties = properties

    def configure(self):
        return None

    def send_command(self, command: str, alternative_property=None):
        return command

    def set_mappings(self, command_map, property_map):
        return None

    def get_monitor(self):
        return None

    def refresh_monitor(self):
        return None

    def get_properties(self):
        return self.properties

    def get_property(self, name: str):
        value = self.properties.get(name)
        if value is None:
            return None
        return {"name": name, "value": value}

    def set_property(self, name: str, value):
        self.properties[name] = value
        return {"name": name, "value": value}

    def health(self):
        return "ok"


def load_fixture_dataset(path: str | Path) -> dict:
    return json.loads(Path(path).read_text())


def make_fixture_device(
    dataset_path: str | Path, device_map_path: str | Path
) -> Device:
    dataset = load_fixture_dataset(dataset_path)
    return Device.from_map(
        FixtureTransport(dataset["properties"]),
        device_map_path=str(device_map_path),
    )
