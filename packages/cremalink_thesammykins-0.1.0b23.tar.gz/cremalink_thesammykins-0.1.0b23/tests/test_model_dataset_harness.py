from pathlib import Path

from tests.helpers import load_fixture_dataset, make_fixture_device


FIXTURE_DIR = Path(__file__).parent / "fixtures"
DEVICE_DIR = Path(__file__).resolve().parents[1] / "cremalink" / "devices"


def test_ecam450_dataset_matches_device_capabilities() -> None:
    dataset = load_fixture_dataset(FIXTURE_DIR / "ecam450_dataset.json")
    device = make_fixture_device(
        FIXTURE_DIR / "ecam450_dataset.json",
        DEVICE_DIR / "ECAM450.json",
    )

    assert dataset["device"]["model"] == "AY008ESP1"
    assert device.supports("stored_recipes") is True
    assert device.supports("custom_recipe_names") is True
    assert device.supports("recipe_priorities") is True
    assert device.supports("favorite_priorities") is True
    assert device.supports("custom_recipe_execution") is False


def test_models_without_recipe_capabilities_fail_closed() -> None:
    for model in ("ECAM452", "ECAM612"):
        device = make_fixture_device(
            FIXTURE_DIR / "ecam450_dataset.json",
            DEVICE_DIR / f"{model}.json",
        )
        assert device.supports("stored_recipes") is False
        assert device.get_custom_recipes() == {}
        assert device.get_recipe_priorities() == {}
        assert device.get_favorite_priorities() == {}


def test_pending_model_fixtures_are_explicitly_marked_pending() -> None:
    for fixture_name in ("ecam452_dataset.json", "ecam612_dataset.json"):
        dataset = load_fixture_dataset(FIXTURE_DIR / fixture_name)
        assert dataset["device"]["capture_status"] == "pending"
