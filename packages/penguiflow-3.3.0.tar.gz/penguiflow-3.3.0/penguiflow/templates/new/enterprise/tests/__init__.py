"""Tests for enterprise template."""
