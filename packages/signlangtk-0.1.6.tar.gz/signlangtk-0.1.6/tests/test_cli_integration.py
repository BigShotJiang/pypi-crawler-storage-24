"""
CLI integration tests for SLTK.

Tests all CLI commands, argument parsing, and error handling.
"""

import json
from pathlib import Path
from unittest.mock import MagicMock, PropertyMock, patch

import numpy as np
import pytest
import torch
from click.testing import CliRunner

from sltk.cli.main import main


@pytest.fixture
def runner():
    """Create a CLI runner for testing."""
    return CliRunner()


class TestMainGroup:
    """Tests for main CLI group."""

    def test_help(self, runner):
        """Test --help flag."""
        result = runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "Sign Language Toolkit" in result.output

    def test_version(self, runner):
        """Test --version flag."""
        result = runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        # Should show version number


class TestConvertCommand:
    """Tests for the convert command."""

    def test_convert_help(self, runner):
        """Test convert --help."""
        result = runner.invoke(main, ["convert", "--help"])
        assert result.exit_code == 0
        assert "--from" in result.output
        assert "--to" in result.output

    def test_convert_missing_from_format(self, runner, tmp_path):
        """Test convert fails without --from."""
        input_file = tmp_path / "input.h5"
        input_file.touch()
        output_file = tmp_path / "output.h5"

        result = runner.invoke(
            main,
            ["convert", str(input_file), str(output_file), "--to", "mediapipe"],
        )
        assert result.exit_code != 0
        assert "Missing option" in result.output or "required" in result.output.lower()

    def test_convert_missing_to_format(self, runner, tmp_path):
        """Test convert fails without --to."""
        input_file = tmp_path / "input.h5"
        input_file.touch()
        output_file = tmp_path / "output.h5"

        result = runner.invoke(
            main,
            ["convert", str(input_file), str(output_file), "--from", "wilor"],
        )
        assert result.exit_code != 0
        assert "Missing option" in result.output or "required" in result.output.lower()

    def test_convert_nonexistent_input(self, runner, tmp_path):
        """Test convert fails with nonexistent input file."""
        result = runner.invoke(
            main,
            [
                "convert",
                "/nonexistent/path/file.h5",
                str(tmp_path / "output.h5"),
                "--from",
                "wilor",
                "--to",
                "mediapipe",
            ],
        )
        assert result.exit_code != 0

    @patch("sltk.data.core.PoseSequence")
    def test_convert_success(self, mock_pose_seq, runner, tmp_path):
        """Test successful convert command with mocked PoseSequence."""
        input_file = tmp_path / "input.h5"
        input_file.touch()
        output_file = tmp_path / "output.h5"

        # Mock the PoseSequence class
        mock_instance = MagicMock()
        mock_instance.num_frames = 100
        mock_pose_seq.load.return_value = mock_instance
        mock_instance.to_format.return_value = mock_instance

        runner.invoke(
            main,
            [
                "convert",
                str(input_file),
                str(output_file),
                "--from",
                "wilor",
                "--to",
                "mediapipe",
                "--fps",
                "30.0",
            ],
        )

        # Even if it fails due to file format, the CLI structure is tested


class TestEvaluateCommand:
    """Tests for the evaluate command."""

    def test_evaluate_help(self, runner):
        """Test evaluate --help."""
        result = runner.invoke(main, ["evaluate", "--help"])
        assert result.exit_code == 0
        assert "--task" in result.output
        assert "translation" in result.output

    def test_evaluate_missing_task(self, runner, temp_predictions_file, temp_references_file):
        """Test evaluate fails without --task."""
        result = runner.invoke(
            main,
            [
                "evaluate",
                str(temp_predictions_file),
                str(temp_references_file),
            ],
        )
        assert result.exit_code != 0
        assert "Missing option" in result.output or "required" in result.output.lower()

    def test_evaluate_nonexistent_predictions(self, runner, tmp_path):
        """Test evaluate fails with nonexistent predictions file."""
        refs = tmp_path / "refs.txt"
        refs.write_text("hello\n")

        result = runner.invoke(
            main,
            [
                "evaluate",
                "/nonexistent/preds.txt",
                str(refs),
                "--task",
                "translation",
            ],
        )
        assert result.exit_code != 0

    def test_evaluate_nonexistent_references(self, runner, tmp_path):
        """Test evaluate fails with nonexistent references file."""
        preds = tmp_path / "preds.txt"
        preds.write_text("hello\n")

        result = runner.invoke(
            main,
            [
                "evaluate",
                str(preds),
                "/nonexistent/refs.txt",
                "--task",
                "translation",
            ],
        )
        assert result.exit_code != 0

    def test_evaluate_translation_length_mismatch(self, runner, tmp_path):
        """Test evaluate fails with mismatched line counts."""
        preds = tmp_path / "preds.txt"
        refs = tmp_path / "refs.txt"
        preds.write_text("hello\nworld\n")
        refs.write_text("hello\n")

        result = runner.invoke(
            main,
            [
                "evaluate",
                str(preds),
                str(refs),
                "--task",
                "translation",
            ],
        )
        assert result.exit_code != 0
        assert "mismatch" in result.output.lower() or "Error" in result.output

    def test_evaluate_translation_empty_files(self, runner, tmp_path):
        """Test evaluate fails with empty files."""
        preds = tmp_path / "preds.txt"
        refs = tmp_path / "refs.txt"
        preds.write_text("")
        refs.write_text("")

        result = runner.invoke(
            main,
            [
                "evaluate",
                str(preds),
                str(refs),
                "--task",
                "translation",
            ],
        )
        assert result.exit_code != 0

    @patch("sltk.metrics.translation.translation_metrics")
    def test_evaluate_translation_success(
        self, mock_metrics, runner, temp_predictions_file, temp_references_file
    ):
        """Test successful translation evaluation."""
        mock_metrics.return_value = {
            "bleu1": 50.0,
            "bleu4": 30.0,
            "rouge_l": 0.6,
        }

        result = runner.invoke(
            main,
            [
                "evaluate",
                str(temp_predictions_file),
                str(temp_references_file),
                "--task",
                "translation",
            ],
        )

        assert result.exit_code == 0
        assert "Results" in result.output

    @patch("sltk.metrics.translation.translation_metrics")
    def test_evaluate_with_output_file(
        self, mock_metrics, runner, temp_predictions_file, temp_references_file, tmp_path
    ):
        """Test evaluate with --output flag."""
        mock_metrics.return_value = {
            "bleu1": 50.0,
            "bleu4": 30.0,
        }

        output_file = tmp_path / "results.json"

        result = runner.invoke(
            main,
            [
                "evaluate",
                str(temp_predictions_file),
                str(temp_references_file),
                "--task",
                "translation",
                "--output",
                str(output_file),
            ],
        )

        assert result.exit_code == 0
        assert output_file.exists()

        with open(output_file) as f:
            data = json.load(f)
        assert "bleu1" in data


class TestToElanCommand:
    """Tests for the to-elan command."""

    def test_to_elan_help(self, runner):
        """Test to-elan --help."""
        result = runner.invoke(main, ["to-elan", "--help"])
        assert result.exit_code == 0
        assert "--output" in result.output

    def test_to_elan_missing_output(self, runner, temp_json_segments):
        """Test to-elan fails without --output."""
        result = runner.invoke(main, ["to-elan", str(temp_json_segments)])
        assert result.exit_code != 0
        assert "Missing option" in result.output or "required" in result.output.lower()

    def test_to_elan_nonexistent_input(self, runner, tmp_path):
        """Test to-elan fails with nonexistent input."""
        result = runner.invoke(
            main,
            [
                "to-elan",
                "/nonexistent/segments.json",
                "--output",
                str(tmp_path / "output.eaf"),
            ],
        )
        assert result.exit_code != 0

    def test_to_elan_invalid_json(self, runner, tmp_path):
        """Test to-elan fails with invalid JSON."""
        bad_json = tmp_path / "bad.json"
        bad_json.write_text("not valid json {{{")

        result = runner.invoke(
            main,
            [
                "to-elan",
                str(bad_json),
                "--output",
                str(tmp_path / "output.eaf"),
            ],
        )
        assert result.exit_code != 0
        assert "Invalid JSON" in result.output or "Error" in result.output

    def test_to_elan_invalid_schema(self, runner, tmp_path):
        """Test to-elan fails with invalid schema (not a list)."""
        bad_schema = tmp_path / "bad_schema.json"
        bad_schema.write_text('{"not": "a list"}')

        result = runner.invoke(
            main,
            [
                "to-elan",
                str(bad_schema),
                "--output",
                str(tmp_path / "output.eaf"),
            ],
        )
        assert result.exit_code != 0
        assert "Invalid" in result.output or "Error" in result.output

    def test_to_elan_empty_segments(self, runner, tmp_path):
        """Test to-elan fails with empty segments list."""
        empty = tmp_path / "empty.json"
        empty.write_text("[]")

        result = runner.invoke(
            main,
            [
                "to-elan",
                str(empty),
                "--output",
                str(tmp_path / "output.eaf"),
            ],
        )
        assert result.exit_code != 0
        assert "no segments" in result.output.lower() or "Error" in result.output

    def test_to_elan_missing_start_field(self, runner, tmp_path):
        """Test to-elan fails when segment missing 'start'."""
        bad_seg = tmp_path / "bad_seg.json"
        bad_seg.write_text('[{"end": 1.0, "label": "TEST"}]')

        result = runner.invoke(
            main,
            [
                "to-elan",
                str(bad_seg),
                "--output",
                str(tmp_path / "output.eaf"),
            ],
        )
        assert result.exit_code != 0
        assert "start" in result.output.lower() or "Error" in result.output

    def test_to_elan_success(self, runner, temp_json_segments, tmp_path):
        """Test successful to-elan conversion."""
        output_file = tmp_path / "output.eaf"

        result = runner.invoke(
            main,
            [
                "to-elan",
                str(temp_json_segments),
                "--output",
                str(output_file),
            ],
        )

        assert result.exit_code == 0
        assert output_file.exists()
        assert "Exported" in result.output

    def test_to_elan_with_tier(self, runner, temp_json_segments, tmp_path):
        """Test to-elan with custom tier name."""
        output_file = tmp_path / "output.eaf"

        result = runner.invoke(
            main,
            [
                "to-elan",
                str(temp_json_segments),
                "--output",
                str(output_file),
                "--tier",
                "CustomTier",
            ],
        )

        assert result.exit_code == 0
        assert output_file.exists()


class TestFromElanCommand:
    """Tests for the from-elan command."""

    def test_from_elan_help(self, runner):
        """Test from-elan --help."""
        result = runner.invoke(main, ["from-elan", "--help"])
        assert result.exit_code == 0
        assert "--output" in result.output
        assert "--tier" in result.output

    def test_from_elan_nonexistent_input(self, runner):
        """Test from-elan fails with nonexistent input."""
        result = runner.invoke(main, ["from-elan", "/nonexistent/file.eaf"])
        assert result.exit_code != 0

    def test_from_elan_success(self, runner, temp_elan_file):
        """Test successful from-elan import."""
        result = runner.invoke(main, ["from-elan", str(temp_elan_file)])

        assert result.exit_code == 0
        assert "Loaded" in result.output
        assert "segments" in result.output

    def test_from_elan_with_output(self, runner, temp_elan_file, tmp_path):
        """Test from-elan with JSON output."""
        output_file = tmp_path / "segments.json"

        result = runner.invoke(
            main,
            [
                "from-elan",
                str(temp_elan_file),
                "--output",
                str(output_file),
            ],
        )

        assert result.exit_code == 0
        assert output_file.exists()

        with open(output_file) as f:
            data = json.load(f)
        assert isinstance(data, list)
        assert len(data) > 0

    def test_from_elan_warns_non_eaf_extension(self, runner, tmp_path):
        """Test from-elan warns about non-.eaf extension."""
        # Create a file with wrong extension but valid content
        from sltk.data.core import Segment, SegmentList
        from sltk.io.elan import write_eaf

        segments = SegmentList([Segment(0.0, 1.0, "TEST")])
        eaf_content = tmp_path / "test.xml"  # Wrong extension
        write_eaf(segments, tmp_path / "temp.eaf")

        # Copy content to .xml file
        import shutil

        shutil.copy(tmp_path / "temp.eaf", eaf_content)

        result = runner.invoke(main, ["from-elan", str(eaf_content)])

        assert result.exit_code == 0
        assert "Warning" in result.output or "Loaded" in result.output


class TestInfoCommand:
    """Tests for the info command."""

    def test_info_help(self, runner):
        """Test info --help."""
        result = runner.invoke(main, ["info", "--help"])
        assert result.exit_code == 0

    def test_info_nonexistent_file(self, runner):
        """Test info fails with nonexistent file."""
        result = runner.invoke(main, ["info", "/nonexistent/file.h5"])
        assert result.exit_code != 0

    def test_info_unsupported_format(self, runner, tmp_path):
        """Test info fails with unsupported file type."""
        txt_file = tmp_path / "test.txt"
        txt_file.write_text("hello")

        result = runner.invoke(main, ["info", str(txt_file)])
        assert result.exit_code != 0
        assert "Unsupported" in result.output or "Error" in result.output

    def test_info_h5_file(self, runner, temp_h5_file):
        """Test info for H5 file."""
        result = runner.invoke(main, ["info", str(temp_h5_file)])

        assert result.exit_code == 0
        assert "H5 File" in result.output or "Frames" in result.output

    def test_info_elan_file(self, runner, temp_elan_file):
        """Test info for ELAN file."""
        result = runner.invoke(main, ["info", str(temp_elan_file)])

        assert result.exit_code == 0
        assert "ELAN" in result.output
        assert "segments" in result.output.lower()


class TestFormatsCommand:
    """Tests for the formats command."""

    def test_formats_help(self, runner):
        """Test formats --help."""
        result = runner.invoke(main, ["formats", "--help"])
        assert result.exit_code == 0

    def test_formats_lists_formats(self, runner):
        """Test formats shows available formats."""
        result = runner.invoke(main, ["formats"])

        assert result.exit_code == 0
        assert "Supported" in result.output


class TestConvertAnnotationsCommand:
    """Tests for the convert-annotations command."""

    def test_convert_annotations_help(self, runner):
        """Test convert-annotations --help."""
        result = runner.invoke(main, ["convert-annotations", "--help"])
        assert result.exit_code == 0
        assert "--source" in result.output
        assert "--output" in result.output

    def test_convert_annotations_missing_source(self, runner, tmp_path):
        """Test convert-annotations fails without --source."""
        result = runner.invoke(
            main,
            [
                "convert-annotations",
                "test_dataset",
                "--output",
                str(tmp_path / "output"),
            ],
        )
        assert result.exit_code != 0

    def test_convert_annotations_nonexistent_source(self, runner, tmp_path):
        """Test convert-annotations fails with nonexistent source."""
        result = runner.invoke(
            main,
            [
                "convert-annotations",
                "test_dataset",
                "--source",
                "/nonexistent/dir",
                "--output",
                str(tmp_path / "output"),
            ],
        )
        assert result.exit_code != 0

    def test_convert_annotations_source_not_directory(self, runner, tmp_path):
        """Test convert-annotations fails when source is not a directory."""
        source_file = tmp_path / "source.txt"
        source_file.write_text("not a directory")

        result = runner.invoke(
            main,
            [
                "convert-annotations",
                "test_dataset",
                "--source",
                str(source_file),
                "--output",
                str(tmp_path / "output"),
            ],
        )
        # Should fail because it's a file, not a directory
        assert result.exit_code != 0


class TestValidateAnnotationsCommand:
    """Tests for the validate-annotations command."""

    def test_validate_annotations_help(self, runner):
        """Test validate-annotations --help."""
        result = runner.invoke(main, ["validate-annotations", "--help"])
        assert result.exit_code == 0
        assert "--strict" in result.output

    def test_validate_annotations_nonexistent_path(self, runner):
        """Test validate-annotations fails with nonexistent path."""
        result = runner.invoke(
            main,
            ["validate-annotations", "/nonexistent/path"],
        )
        assert result.exit_code != 0

    def test_validate_annotations_valid_file(self, runner, temp_unified_annotation_file):
        """Test validate-annotations with valid annotation file."""
        result = runner.invoke(
            main,
            ["validate-annotations", str(temp_unified_annotation_file)],
        )

        assert result.exit_code == 0
        assert "Valid" in result.output

    def test_validate_annotations_invalid_file(self, runner, tmp_path):
        """Test validate-annotations with invalid annotation file."""
        invalid_file = tmp_path / "invalid.json"
        invalid_file.write_text('{"not": "valid schema"}')

        result = runner.invoke(
            main,
            ["validate-annotations", str(invalid_file)],
        )

        # Should report errors but complete
        assert "Invalid" in result.output or "Error" in result.output or "Missing" in result.output

    def test_validate_annotations_directory(self, runner, tmp_path, sample_unified_annotation):
        """Test validate-annotations on a directory."""
        # Create multiple annotation files
        for i in range(3):
            annotation = sample_unified_annotation.copy()
            annotation["sample_id"] = f"sample_{i}"
            path = tmp_path / f"sample_{i}.json"
            with open(path, "w") as f:
                json.dump(annotation, f)

        result = runner.invoke(
            main,
            ["validate-annotations", str(tmp_path)],
        )

        assert result.exit_code == 0
        assert "Validating 3 files" in result.output

    def test_validate_annotations_empty_directory(self, runner, tmp_path):
        """Test validate-annotations on empty directory."""
        empty_dir = tmp_path / "empty"
        empty_dir.mkdir()

        result = runner.invoke(
            main,
            ["validate-annotations", str(empty_dir)],
        )

        assert result.exit_code != 0
        assert "No JSON" in result.output or "Error" in result.output


class TestGenerateManifestCommand:
    """Tests for the generate-manifest command."""

    def test_generate_manifest_help(self, runner):
        """Test generate-manifest --help."""
        result = runner.invoke(main, ["generate-manifest", "--help"])
        assert result.exit_code == 0
        assert "--dataset" in result.output

    def test_generate_manifest_missing_dataset(self, runner, tmp_path):
        """Test generate-manifest fails without --dataset."""
        result = runner.invoke(
            main,
            ["generate-manifest", str(tmp_path)],
        )
        assert result.exit_code != 0

    def test_generate_manifest_nonexistent_dir(self, runner):
        """Test generate-manifest fails with nonexistent directory."""
        result = runner.invoke(
            main,
            ["generate-manifest", "/nonexistent/dir", "--dataset", "test"],
        )
        assert result.exit_code != 0

    def test_generate_manifest_empty_dir(self, runner, tmp_path):
        """Test generate-manifest fails on empty directory."""
        empty_dir = tmp_path / "empty"
        empty_dir.mkdir()

        result = runner.invoke(
            main,
            ["generate-manifest", str(empty_dir), "--dataset", "test"],
        )
        assert result.exit_code != 0
        assert "No annotation" in result.output or "Error" in result.output

    def test_generate_manifest_success(self, runner, tmp_path, sample_unified_annotation):
        """Test successful manifest generation."""
        # Create annotation files
        for i in range(3):
            annotation = sample_unified_annotation.copy()
            annotation["sample_id"] = f"sample_{i}"
            path = tmp_path / f"sample_{i}.json"
            with open(path, "w") as f:
                json.dump(annotation, f)

        result = runner.invoke(
            main,
            ["generate-manifest", str(tmp_path), "--dataset", "test_dataset"],
        )

        assert result.exit_code == 0
        assert "Manifest generated" in result.output
        assert (tmp_path / "manifest.json").exists()


class TestAnnotationFormatsCommand:
    """Tests for the annotation-formats command."""

    def test_annotation_formats_help(self, runner):
        """Test annotation-formats --help."""
        result = runner.invoke(main, ["annotation-formats", "--help"])
        assert result.exit_code == 0

    def test_annotation_formats_lists_formats(self, runner):
        """Test annotation-formats shows available formats."""
        result = runner.invoke(main, ["annotation-formats"])

        assert result.exit_code == 0
        assert "Supported annotation formats" in result.output
        assert "elan" in result.output.lower()


class TestAnnotationInfoCommand:
    """Tests for the annotation-info command."""

    def test_annotation_info_help(self, runner):
        """Test annotation-info --help."""
        result = runner.invoke(main, ["annotation-info", "--help"])
        assert result.exit_code == 0

    def test_annotation_info_nonexistent_path(self, runner):
        """Test annotation-info fails with nonexistent path."""
        result = runner.invoke(
            main,
            ["annotation-info", "/nonexistent/path"],
        )
        assert result.exit_code != 0

    def test_annotation_info_single_file(self, runner, temp_unified_annotation_file):
        """Test annotation-info for single file."""
        result = runner.invoke(
            main,
            ["annotation-info", str(temp_unified_annotation_file)],
        )

        assert result.exit_code == 0
        assert "Sample" in result.output
        assert "test_sample_001" in result.output

    def test_annotation_info_manifest(self, runner, tmp_path, sample_unified_annotation):
        """Test annotation-info for manifest.json."""
        from sltk.io.annotations import generate_manifest

        # Create annotation files
        for i in range(3):
            annotation = sample_unified_annotation.copy()
            annotation["sample_id"] = f"sample_{i}"
            path = tmp_path / f"sample_{i}.json"
            with open(path, "w") as f:
                json.dump(annotation, f)

        # Generate manifest
        generate_manifest(tmp_path, "test_dataset")

        manifest_path = tmp_path / "manifest.json"
        result = runner.invoke(
            main,
            ["annotation-info", str(manifest_path)],
        )

        assert result.exit_code == 0
        assert "Manifest" in result.output or "Dataset" in result.output

    def test_annotation_info_directory(self, runner, tmp_path, sample_unified_annotation):
        """Test annotation-info for directory."""
        # Create annotation files
        for i in range(3):
            annotation = sample_unified_annotation.copy()
            annotation["sample_id"] = f"sample_{i}"
            path = tmp_path / f"sample_{i}.json"
            with open(path, "w") as f:
                json.dump(annotation, f)

        result = runner.invoke(
            main,
            ["annotation-info", str(tmp_path)],
        )

        assert result.exit_code == 0
        assert "Directory" in result.output or "JSON files" in result.output


# =============================================================================
# Extract Command Tests
# =============================================================================


class TestExtractCommand:
    """Tests for the extract command."""

    def test_extract_help(self, runner):
        result = runner.invoke(main, ["extract", "--help"])
        assert result.exit_code == 0
        assert "wilor" in result.output
        assert "nlf" in result.output
        assert "teaser" in result.output

    def test_extract_invalid_backend(self, runner, tmp_path):
        video = tmp_path / "test.mp4"
        video.touch()
        result = runner.invoke(main, ["extract", "invalid_backend", str(video)])
        assert result.exit_code != 0

    def test_extract_nonexistent_video(self, runner):
        result = runner.invoke(main, ["extract", "wilor", "/nonexistent/video.mp4"])
        assert result.exit_code != 0

    @patch("sltk.extraction.wilor.WiLoRExtractor")
    def test_extract_wilor_success(self, mock_extractor_cls, runner, tmp_path):
        video = tmp_path / "test.mp4"
        video.touch()
        output = tmp_path / "test_wilor.h5"

        mock_result = MagicMock()
        mock_result.num_frames = 100
        mock_result.num_detections = 50
        mock_result.fps = 25.0

        mock_ext = MagicMock()
        mock_ext.__enter__ = MagicMock(return_value=mock_ext)
        mock_ext.__exit__ = MagicMock(return_value=False)
        mock_ext.extract_from_video.return_value = mock_result
        mock_extractor_cls.return_value = mock_ext

        with patch("torch.cuda.empty_cache"):
            result = runner.invoke(
                main,
                ["extract", "wilor", str(video), "-o", str(output)],
            )

        assert result.exit_code == 0
        assert "100" in result.output  # num_frames
        assert "50" in result.output  # num_detections

    @patch("sltk.extraction.nlf.NLFExtractor")
    def test_extract_nlf_success(self, mock_extractor_cls, runner, tmp_path):
        video = tmp_path / "test.mp4"
        video.touch()

        mock_result = MagicMock()
        mock_result.num_frames = 200
        mock_result.num_detections = 200
        mock_result.fps = 30.0

        mock_ext = MagicMock()
        mock_ext.__enter__ = MagicMock(return_value=mock_ext)
        mock_ext.__exit__ = MagicMock(return_value=False)
        mock_ext.extract_from_video.return_value = mock_result
        mock_extractor_cls.return_value = mock_ext

        with patch("torch.cuda.empty_cache"):
            result = runner.invoke(
                main,
                ["extract", "nlf", str(video)],
            )

        assert result.exit_code == 0
        assert "200" in result.output

    @patch("sltk.extraction.teaser.TeaserExtractor")
    def test_extract_teaser_success(self, mock_extractor_cls, runner, tmp_path):
        video = tmp_path / "test.mp4"
        video.touch()

        mock_result = MagicMock()
        mock_result.num_frames = 150
        mock_result.num_detections = 148
        mock_result.fps = 25.0

        mock_ext = MagicMock()
        mock_ext.__enter__ = MagicMock(return_value=mock_ext)
        mock_ext.__exit__ = MagicMock(return_value=False)
        mock_ext.extract_from_video.return_value = mock_result
        mock_extractor_cls.return_value = mock_ext

        with patch("torch.cuda.empty_cache"):
            result = runner.invoke(
                main,
                ["extract", "teaser", str(video)],
            )

        assert result.exit_code == 0
        assert "150" in result.output

    @patch("sltk.extraction.wilor.WiLoRExtractor")
    def test_extract_default_output_path(self, mock_extractor_cls, runner, tmp_path):
        """Output defaults to <stem>_<backend>.h5 in the same directory."""
        video = tmp_path / "my_video.mp4"
        video.touch()

        mock_result = MagicMock(num_frames=10, num_detections=5, fps=25.0)
        mock_ext = MagicMock()
        mock_ext.__enter__ = MagicMock(return_value=mock_ext)
        mock_ext.__exit__ = MagicMock(return_value=False)
        mock_ext.extract_from_video.return_value = mock_result
        mock_extractor_cls.return_value = mock_ext

        with patch("torch.cuda.empty_cache"):
            result = runner.invoke(main, ["extract", "wilor", str(video)])

        assert result.exit_code == 0
        assert "my_video_wilor.h5" in result.output

    @patch("sltk.extraction.wilor.WiLoRExtractor")
    def test_extract_with_batch_size(self, mock_extractor_cls, runner, tmp_path):
        video = tmp_path / "test.mp4"
        video.touch()

        mock_result = MagicMock(num_frames=10, num_detections=5, fps=25.0)
        mock_ext = MagicMock()
        mock_ext.__enter__ = MagicMock(return_value=mock_ext)
        mock_ext.__exit__ = MagicMock(return_value=False)
        mock_ext.extract_from_video.return_value = mock_result
        mock_extractor_cls.return_value = mock_ext

        with patch("torch.cuda.empty_cache"):
            result = runner.invoke(
                main,
                ["extract", "wilor", str(video), "--batch-size", "16"],
            )

        assert result.exit_code == 0

    @patch("sltk.extraction.wilor.WiLoRExtractor")
    def test_extract_cuda_oom_error(self, mock_extractor_cls, runner, tmp_path):
        video = tmp_path / "test.mp4"
        video.touch()

        mock_ext = MagicMock()
        mock_ext.__enter__ = MagicMock(return_value=mock_ext)
        mock_ext.__exit__ = MagicMock(return_value=False)
        mock_ext.extract_from_video.side_effect = RuntimeError(
            "CUDA out of memory. Tried to allocate 2.00 GiB"
        )
        mock_extractor_cls.return_value = mock_ext

        with patch("torch.cuda.empty_cache"):
            result = runner.invoke(main, ["extract", "wilor", str(video)])

        assert result.exit_code != 0
        assert "GPU error" in result.output
        assert "batch-size" in result.output


# =============================================================================
# Segment Command Tests
# =============================================================================


class TestSegmentCommand:
    """Tests for the segment command."""

    def test_segment_help(self, runner):
        result = runner.invoke(main, ["segment", "--help"])
        assert result.exit_code == 0
        assert "WiLoR H5" in result.output or "video" in result.output.lower()
        assert "--format" in result.output

    def test_segment_nonexistent_input(self, runner):
        result = runner.invoke(main, ["segment", "/nonexistent/file.h5"])
        assert result.exit_code != 0

    @patch("sltk.segmentation.runner.segment_h5")
    def test_segment_h5_success(self, mock_segment, runner, tmp_path):
        h5_file = tmp_path / "video_wilor.h5"
        h5_file.touch()

        mock_segment.return_value = {
            "video_wilor": torch.tensor([0, 0, 2, 1, 1, 0, 0, 2, 1, 0])
        }

        result = runner.invoke(main, ["segment", str(h5_file)])

        assert result.exit_code == 0
        assert "segments" in result.output
        mock_segment.assert_called_once()

    @patch("sltk.segmentation.runner.segment_h5")
    def test_segment_h5_elan_output(self, mock_segment, runner, tmp_path):
        h5_file = tmp_path / "video_wilor.h5"
        h5_file.touch()
        video = tmp_path / "video.mp4"
        video.touch()

        mock_segment.return_value = {
            "video_wilor": torch.tensor([0, 2, 1, 0])
        }

        result = runner.invoke(
            main,
            [
                "segment", str(h5_file),
                "-f", "elan",
                "-o", str(tmp_path / "out.eaf"),
                "--video", str(video),
            ],
        )

        assert result.exit_code == 0
        # Verify elan format was passed
        call_kwargs = mock_segment.call_args
        assert call_kwargs is not None

    @patch("sltk.segmentation.runner.segment_h5")
    def test_segment_default_output_path(self, mock_segment, runner, tmp_path):
        h5_file = tmp_path / "clip_wilor.h5"
        h5_file.touch()

        mock_segment.return_value = {
            "clip_wilor": torch.tensor([0, 2, 1, 0])
        }

        result = runner.invoke(main, ["segment", str(h5_file)])

        assert result.exit_code == 0
        assert "clip_wilor_segments.json" in result.output

    @patch("sltk.segmentation.runner.segment_h5")
    @patch("sltk.extraction.wilor.WiLoRExtractor")
    def test_segment_video_auto_extract(self, mock_extractor_cls, mock_segment, runner, tmp_path):
        """When input is a video, WiLoR should be run first."""
        video = tmp_path / "clip.mp4"
        video.touch()

        # Mock WiLoR extraction
        mock_result = MagicMock()
        mock_result.num_frames = 100
        mock_result.num_detections = 80
        mock_result.fps = 25.0

        mock_ext = MagicMock()
        mock_ext.__enter__ = MagicMock(return_value=mock_ext)
        mock_ext.__exit__ = MagicMock(return_value=False)
        mock_ext.extract_from_video.return_value = mock_result
        mock_extractor_cls.return_value = mock_ext

        # Mock segmentation
        mock_segment.return_value = {
            "clip_wilor": torch.tensor([0, 2, 1, 1, 0, 2, 1, 0])
        }

        with patch("torch.cuda.empty_cache"):
            result = runner.invoke(main, ["segment", str(video)])

        assert result.exit_code == 0
        assert "[1/2]" in result.output
        assert "[2/2]" in result.output
        assert "WiLoR" in result.output
        assert "segments" in result.output
        mock_ext.load_model.assert_called_once()
        mock_ext.extract_from_video.assert_called_once()
        mock_segment.assert_called_once()

    @patch("sltk.segmentation.runner.segment_h5")
    @patch("sltk.extraction.wilor.WiLoRExtractor")
    def test_segment_video_uses_extracted_fps(self, mock_extractor_cls, mock_segment, runner, tmp_path):
        """FPS should be auto-detected from the WiLoR extraction result."""
        video = tmp_path / "clip.mp4"
        video.touch()

        mock_result = MagicMock(num_frames=100, num_detections=80, fps=30.0)
        mock_ext = MagicMock()
        mock_ext.__enter__ = MagicMock(return_value=mock_ext)
        mock_ext.__exit__ = MagicMock(return_value=False)
        mock_ext.extract_from_video.return_value = mock_result
        mock_extractor_cls.return_value = mock_ext

        mock_segment.return_value = {"clip_wilor": torch.tensor([0, 2, 1, 0])}

        with patch("torch.cuda.empty_cache"):
            result = runner.invoke(main, ["segment", str(video)])

        assert result.exit_code == 0
        # segment_h5 should have been called with fps=30.0
        _, kwargs = mock_segment.call_args
        assert kwargs["fps"] == 30.0

    @patch("sltk.segmentation.runner.segment_h5")
    @patch("sltk.extraction.wilor.WiLoRExtractor")
    def test_segment_video_no_keep_h5(self, mock_extractor_cls, mock_segment, runner, tmp_path):
        """--no-keep-h5 should remove the intermediate WiLoR H5."""
        video = tmp_path / "clip.mp4"
        video.touch()
        wilor_h5 = tmp_path / "clip_wilor.h5"
        wilor_h5.touch()  # Simulate it being created

        mock_result = MagicMock(num_frames=10, num_detections=5, fps=25.0)
        mock_ext = MagicMock()
        mock_ext.__enter__ = MagicMock(return_value=mock_ext)
        mock_ext.__exit__ = MagicMock(return_value=False)
        mock_ext.extract_from_video.return_value = mock_result
        mock_extractor_cls.return_value = mock_ext

        mock_segment.return_value = {"clip_wilor": torch.tensor([0, 2, 1, 0])}

        with patch("torch.cuda.empty_cache"):
            result = runner.invoke(
                main,
                ["segment", str(video), "--no-keep-h5"],
            )

        assert result.exit_code == 0
        assert "Removed intermediate" in result.output

    @patch("sltk.segmentation.runner.segment_h5")
    @patch("sltk.extraction.wilor.WiLoRExtractor")
    def test_segment_video_logs_steps(self, mock_extractor_cls, mock_segment, runner, tmp_path):
        """Verify all user-facing log messages appear."""
        video = tmp_path / "clip.mp4"
        video.touch()

        mock_result = MagicMock(num_frames=250, num_detections=480, fps=25.0)
        mock_ext = MagicMock()
        mock_ext.__enter__ = MagicMock(return_value=mock_ext)
        mock_ext.__exit__ = MagicMock(return_value=False)
        mock_ext.extract_from_video.return_value = mock_result
        mock_extractor_cls.return_value = mock_ext

        mock_segment.return_value = {"clip_wilor": torch.tensor([0, 2, 1, 0, 2, 1, 1, 0])}

        with patch("torch.cuda.empty_cache"):
            result = runner.invoke(main, ["segment", str(video)])

        assert result.exit_code == 0
        assert "Extracting WiLoR hands" in result.output
        assert "Loading WiLoR model" in result.output
        assert "hand detection" in result.output
        assert "250 frames" in result.output
        assert "480 hand detections" in result.output
        assert "WiLoR H5:" in result.output
        assert "Loading segmentation model" in result.output

    @patch("sltk.extraction.wilor.WiLoRExtractor")
    def test_segment_video_wilor_failure(self, mock_extractor_cls, runner, tmp_path):
        """WiLoR failure should produce a clear error."""
        video = tmp_path / "clip.mp4"
        video.touch()

        mock_ext = MagicMock()
        mock_ext.__enter__ = MagicMock(return_value=mock_ext)
        mock_ext.__exit__ = MagicMock(return_value=False)
        mock_ext.extract_from_video.side_effect = RuntimeError(
            "CUDA out of memory"
        )
        mock_extractor_cls.return_value = mock_ext

        with patch("torch.cuda.empty_cache"):
            result = runner.invoke(main, ["segment", str(video)])

        assert result.exit_code != 0
        assert "GPU error" in result.output
        assert "batch-size" in result.output

    @patch("sltk.segmentation.runner.segment_h5")
    @patch("sltk.extraction.wilor.WiLoRExtractor")
    def test_segment_video_links_video_in_elan(self, mock_extractor_cls, mock_segment, runner, tmp_path):
        """When segmenting a video with elan output, video should be auto-linked."""
        video = tmp_path / "clip.mp4"
        video.touch()

        mock_result = MagicMock(num_frames=10, num_detections=5, fps=25.0)
        mock_ext = MagicMock()
        mock_ext.__enter__ = MagicMock(return_value=mock_ext)
        mock_ext.__exit__ = MagicMock(return_value=False)
        mock_ext.extract_from_video.return_value = mock_result
        mock_extractor_cls.return_value = mock_ext

        mock_segment.return_value = {"clip_wilor": torch.tensor([0, 2, 1, 0])}

        with patch("torch.cuda.empty_cache"):
            result = runner.invoke(
                main,
                ["segment", str(video), "-f", "elan"],
            )

        assert result.exit_code == 0
        _, kwargs = mock_segment.call_args
        assert kwargs["media_path"] == str(video)

    @patch("sltk.segmentation.runner.segment_h5")
    def test_segment_h5_does_not_run_wilor(self, mock_segment, runner, tmp_path):
        """H5 input should NOT trigger WiLoR extraction."""
        h5_file = tmp_path / "video_wilor.h5"
        h5_file.touch()

        mock_segment.return_value = {"video_wilor": torch.tensor([0, 2, 1, 0])}

        result = runner.invoke(main, ["segment", str(h5_file)])

        assert result.exit_code == 0
        assert "[1/2]" not in result.output
        assert "WiLoR" not in result.output


# =============================================================================
# Spot Command Tests
# =============================================================================


class TestSpotCommand:
    """Tests for the spot command."""

    def test_spot_help(self, runner):
        result = runner.invoke(main, ["spot", "--help"])
        assert result.exit_code == 0
        assert "--segments" in result.output
        assert "--dictionary" in result.output

    def test_spot_missing_segments(self, runner, tmp_path):
        video = tmp_path / "test.mp4"
        video.touch()
        dict_dir = tmp_path / "dict"
        dict_dir.mkdir()

        result = runner.invoke(
            main,
            ["spot", str(video), "-D", str(dict_dir)],
        )
        assert result.exit_code != 0

    def test_spot_missing_dictionary(self, runner, tmp_path):
        video = tmp_path / "test.mp4"
        video.touch()
        seg_file = tmp_path / "segments.json"
        seg_file.write_text("[]")

        result = runner.invoke(
            main,
            ["spot", str(video), "-s", str(seg_file)],
        )
        assert result.exit_code != 0

    @patch("sltk.embedding.pipeline.SignRepPipeline")
    def test_spot_success(self, mock_pipeline_cls, runner, tmp_path):
        video = tmp_path / "test.mp4"
        video.touch()
        seg_file = tmp_path / "segments.json"
        seg_file.write_text('[{"segment_id": 0, "start_frame": 0, "end_frame": 25}]')
        dict_dir = tmp_path / "dict"
        dict_dir.mkdir()

        # Mock SpottingResult
        mock_seg = MagicMock()
        mock_seg.start_ms = 0
        mock_seg.end_ms = 1000
        mock_seg.top_glosses = [
            {"gloss": "HELLO", "similarity": 0.95, "rank": 1},
        ]
        mock_seg.segment_id = 0

        mock_spot_result = MagicMock()
        mock_spot_result.segments = [mock_seg]

        mock_pipeline = MagicMock()
        mock_pipeline.spot_from_video.return_value = mock_spot_result
        mock_pipeline_cls.return_value = mock_pipeline

        result = runner.invoke(
            main,
            [
                "spot", str(video),
                "-s", str(seg_file),
                "-D", str(dict_dir),
                "-o", str(tmp_path / "spotted.eaf"),
            ],
        )

        assert result.exit_code == 0
        assert "1" in result.output  # segments matched
        assert "HELLO" in result.output
        mock_spot_result.save_eaf.assert_called_once()

    @patch("sltk.embedding.pipeline.SignRepPipeline")
    def test_spot_default_output_path(self, mock_pipeline_cls, runner, tmp_path):
        video = tmp_path / "my_clip.mp4"
        video.touch()
        seg_file = tmp_path / "segments.json"
        seg_file.write_text("[]")
        dict_dir = tmp_path / "dict"
        dict_dir.mkdir()

        mock_spot_result = MagicMock()
        mock_spot_result.segments = []
        mock_pipeline = MagicMock()
        mock_pipeline.spot_from_video.return_value = mock_spot_result
        mock_pipeline_cls.return_value = mock_pipeline

        result = runner.invoke(
            main,
            ["spot", str(video), "-s", str(seg_file), "-D", str(dict_dir)],
        )

        assert result.exit_code == 0
        assert "my_clip_spotted.eaf" in result.output


# =============================================================================
# NMS Command Tests
# =============================================================================


class TestNMSCommand:
    """Tests for the nms command."""

    def test_nms_help(self, runner):
        result = runner.invoke(main, ["nms", "--help"])
        assert result.exit_code == 0
        assert "blink" in result.output.lower() or "non-manual" in result.output.lower()
        assert "--detectors" in result.output

    def test_nms_nonexistent_input(self, runner):
        result = runner.invoke(main, ["nms", "/nonexistent/teaser.h5"])
        assert result.exit_code != 0

    @patch("sltk.nms.runner.export_results")
    @patch("sltk.nms.runner.detect_nms")
    def test_nms_success(self, mock_detect, mock_export, runner, tmp_path):
        h5_file = tmp_path / "video_teaser.h5"
        h5_file.touch()

        mock_blink = MagicMock()
        mock_blink.start_frame = 10
        mock_blink.end_frame = 15

        mock_event = MagicMock()
        mock_event.tier = "HEAD-NOD"
        mock_event.start_frame = 20
        mock_event.end_frame = 30
        mock_event.label = "nod"

        mock_quality = MagicMock()
        mock_quality.detection_rate = 0.95

        mock_detect.return_value = ([mock_blink], [mock_event], mock_quality)
        mock_export.return_value = {"elan": str(tmp_path / "video_teaser_nms.eaf")}

        result = runner.invoke(main, ["nms", str(h5_file)])

        assert result.exit_code == 0
        assert "95" in result.output  # detection rate
        assert "1" in result.output  # blink count
        assert "HEAD-NOD" in result.output
        mock_detect.assert_called_once()
        mock_export.assert_called_once()

    @patch("sltk.nms.runner.export_results")
    @patch("sltk.nms.runner.detect_nms")
    def test_nms_with_nlf(self, mock_detect, mock_export, runner, tmp_path):
        teaser_h5 = tmp_path / "video_teaser.h5"
        teaser_h5.touch()
        nlf_h5 = tmp_path / "video_nlf.h5"
        nlf_h5.touch()

        mock_quality = MagicMock(detection_rate=0.90)
        mock_detect.return_value = ([], [], mock_quality)
        mock_export.return_value = {}

        result = runner.invoke(
            main,
            ["nms", str(teaser_h5), "--nlf", str(nlf_h5)],
        )

        assert result.exit_code == 0
        _, kwargs = mock_detect.call_args
        assert kwargs["smpl_path"] == str(nlf_h5)

    @patch("sltk.nms.runner.export_results")
    @patch("sltk.nms.runner.detect_nms")
    def test_nms_specific_detectors(self, mock_detect, mock_export, runner, tmp_path):
        h5_file = tmp_path / "video_teaser.h5"
        h5_file.touch()

        mock_quality = MagicMock(detection_rate=0.85)
        mock_detect.return_value = ([], [], mock_quality)
        mock_export.return_value = {}

        result = runner.invoke(
            main,
            ["nms", str(h5_file), "--detectors", "blink,nod"],
        )

        assert result.exit_code == 0
        _, kwargs = mock_detect.call_args
        assert kwargs["detectors"] == {"blink", "nod"}

    @patch("sltk.nms.runner.export_results")
    @patch("sltk.nms.runner.detect_nms")
    def test_nms_json_format(self, mock_detect, mock_export, runner, tmp_path):
        h5_file = tmp_path / "video_teaser.h5"
        h5_file.touch()

        mock_quality = MagicMock(detection_rate=0.90)
        mock_detect.return_value = ([], [], mock_quality)
        mock_export.return_value = {"json": str(tmp_path / "video_teaser_nms.json")}

        result = runner.invoke(
            main,
            ["nms", str(h5_file), "-f", "json"],
        )

        assert result.exit_code == 0
        _, kwargs = mock_export.call_args
        assert "json" in kwargs["formats"]

    @patch("sltk.nms.runner.export_results")
    @patch("sltk.nms.runner.detect_nms")
    def test_nms_no_adaptive(self, mock_detect, mock_export, runner, tmp_path):
        h5_file = tmp_path / "video_teaser.h5"
        h5_file.touch()

        mock_quality = MagicMock(detection_rate=0.90)
        mock_detect.return_value = ([], [], mock_quality)
        mock_export.return_value = {}

        result = runner.invoke(
            main,
            ["nms", str(h5_file), "--no-adaptive"],
        )

        assert result.exit_code == 0
        _, kwargs = mock_detect.call_args
        assert kwargs["no_adaptive"] is True


# =============================================================================
# Pipeline Command Tests
# =============================================================================


class TestPipelineCommand:
    """Tests for the pipeline command."""

    def test_pipeline_help(self, runner):
        result = runner.invoke(main, ["pipeline", "--help"])
        assert result.exit_code == 0
        assert "extraction-to-ELAN" in result.output or "full" in result.output.lower()
        assert "--skip-nlf" in result.output
        assert "--skip-teaser" in result.output

    def test_pipeline_nonexistent_video(self, runner):
        result = runner.invoke(main, ["pipeline", "/nonexistent/video.mp4"])
        assert result.exit_code != 0

    @patch("sltk.io.elan_roundtrip.ElanDocument")
    @patch("sltk.nms.runner.detect_nms")
    @patch("sltk.segmentation.runner.get_runner")
    @patch("sltk.segmentation.h5_loader.h5_to_features")
    @patch("sltk.extraction.teaser.TeaserExtractor")
    @patch("sltk.extraction.nlf.NLFExtractor")
    @patch("sltk.extraction.wilor.WiLoRExtractor")
    def test_pipeline_full_success(
        self,
        mock_wilor_cls,
        mock_nlf_cls,
        mock_teaser_cls,
        mock_h5_to_features,
        mock_get_runner,
        mock_detect_nms,
        mock_elan_doc,
        runner,
        tmp_path,
    ):
        video = tmp_path / "test.mp4"
        video.touch()

        # Mock all extractors
        for mock_cls, frames, dets, fps in [
            (mock_wilor_cls, 100, 80, 25.0),
            (mock_nlf_cls, 100, 100, 25.0),
            (mock_teaser_cls, 100, 98, 25.0),
        ]:
            mock_result = MagicMock(num_frames=frames, num_detections=dets, fps=fps)
            mock_ext = MagicMock()
            mock_ext.__enter__ = MagicMock(return_value=mock_ext)
            mock_ext.__exit__ = MagicMock(return_value=False)
            mock_ext.extract_from_video.return_value = mock_result
            mock_cls.return_value = mock_ext

        # Mock segmentation
        mock_h5_to_features.return_value = torch.randn(100, 192)
        mock_seg_runner = MagicMock()
        mock_seg_runner.predict.return_value = torch.tensor(
            [0] * 10 + [2, 1, 1, 1, 1] + [0] * 10 + [2, 1, 1] + [0] * 72
        )
        mock_get_runner.return_value = mock_seg_runner

        # Mock NMS
        mock_blink = MagicMock(start_frame=5, end_frame=8)
        mock_event = MagicMock(tier="HEAD-NOD", start_frame=20, end_frame=30, label="nod")
        mock_quality = MagicMock(detection_rate=0.92)
        mock_detect_nms.return_value = ([mock_blink], [mock_event], mock_quality)

        # Mock ELAN document — use real int values so format strings work
        mock_doc = MagicMock()
        mock_tier = MagicMock()
        mock_tier.name = "Segmentation"
        mock_tier.segment_count = 2
        mock_doc.get_tiers.return_value = [mock_tier]
        mock_elan_doc.new.return_value = mock_doc

        with patch("torch.cuda.empty_cache"):
            result = runner.invoke(
                main,
                ["pipeline", str(video), "-o", str(tmp_path / "out")],
            )

        assert result.exit_code == 0
        assert "[1/5]" in result.output
        assert "[2/5]" in result.output
        assert "[3/5]" in result.output
        assert "[4/5]" in result.output
        assert "[5/5]" in result.output
        assert "Saved" in result.output

    @patch("sltk.io.elan_roundtrip.ElanDocument")
    @patch("sltk.segmentation.runner.get_runner")
    @patch("sltk.segmentation.h5_loader.h5_to_features")
    @patch("sltk.extraction.wilor.WiLoRExtractor")
    def test_pipeline_skip_nlf_and_teaser(
        self,
        mock_wilor_cls,
        mock_h5_to_features,
        mock_get_runner,
        mock_elan_doc,
        runner,
        tmp_path,
    ):
        video = tmp_path / "test.mp4"
        video.touch()

        mock_result = MagicMock(num_frames=50, num_detections=40, fps=25.0)
        mock_ext = MagicMock()
        mock_ext.__enter__ = MagicMock(return_value=mock_ext)
        mock_ext.__exit__ = MagicMock(return_value=False)
        mock_ext.extract_from_video.return_value = mock_result
        mock_wilor_cls.return_value = mock_ext

        mock_h5_to_features.return_value = torch.randn(50, 192)
        mock_seg_runner = MagicMock()
        mock_seg_runner.predict.return_value = torch.tensor([0] * 50)
        mock_get_runner.return_value = mock_seg_runner

        mock_doc = MagicMock()
        mock_tier = MagicMock()
        mock_tier.name = "Segmentation"
        mock_tier.segment_count = 0
        mock_doc.get_tiers.return_value = [mock_tier]
        mock_elan_doc.new.return_value = mock_doc

        with patch("torch.cuda.empty_cache"):
            result = runner.invoke(
                main,
                ["pipeline", str(video), "--skip-nlf", "--skip-teaser"],
            )

        assert result.exit_code == 0
        assert "Skipping NLF" in result.output
        assert "Skipping TEASER" in result.output
        assert "Skipping NMS" in result.output

    @patch("sltk.extraction.wilor.WiLoRExtractor")
    def test_pipeline_wilor_failure_aborts(self, mock_wilor_cls, runner, tmp_path):
        video = tmp_path / "test.mp4"
        video.touch()

        mock_ext = MagicMock()
        mock_ext.__enter__ = MagicMock(return_value=mock_ext)
        mock_ext.__exit__ = MagicMock(return_value=False)
        mock_ext.extract_from_video.side_effect = RuntimeError("Model load failed")
        mock_wilor_cls.return_value = mock_ext

        with patch("torch.cuda.empty_cache"):
            result = runner.invoke(main, ["pipeline", str(video)])

        assert result.exit_code != 0
        assert "WiLoR extraction failed" in result.output
