"""
Auto-download model weights from Hugging Face Hub.

Downloads weights on first use per model, caching them locally.
Respects SLTK_WEIGHTS_DIR environment variable for custom cache location.

Usage:
    from sltk.weights.hub import ensure_weights

    # Download only what you need
    paths = ensure_weights("wilor")      # downloads WiLoR weights only
    paths = ensure_weights("segmentor")  # downloads segmentor weights only

    # Skip confirmation prompt (e.g. in scripts)
    paths = ensure_weights("wilor", confirm=False)

    # Or set SLTK_AUTO_DOWNLOAD=1 to always skip prompts
"""

from __future__ import annotations

import logging
import os
import sys
from pathlib import Path

logger = logging.getLogger(__name__)

# HF repo containing all SLTK weights
HF_REPO_ID = "fiskenai/vltk"

# Default cache location
_DEFAULT_CACHE_DIR = Path.home() / ".cache" / "sltk" / "weights"

# Which HF repo files belong to each model
MODEL_FILES: dict[str, list[str]] = {
    "wilor": [
        "wilor/wilor_final.ckpt",
        "wilor/detector.pt",
        "wilor/model_config.yaml",
        "wilor/mano_data/MANO_LEFT.pkl",
        "wilor/mano_data/MANO_RIGHT.pkl",
        "wilor/mano_data/mano_mean_params.npz",
    ],
    "nlf": [
        "nlf/nlf_l_multi_0.3.2.torchscript",
        "nlf/SMPLX_NEUTRAL.npz",
        "nlf/yolov8x.pt",
    ],
    "signrep": [
        "signrep/ckpt.pt",
    ],
    "segmentor": [
        "segmentor/segmentor_v2.ckpt",
    ],
    "teaser": [
        "Teaser.pt",
    ],
}

# Approximate download sizes per model group (MB)
MODEL_SIZES_MB: dict[str, float] = {
    "wilor": 2500.0,
    "nlf": 540.0,
    "signrep": 350.0,
    "segmentor": 180.0,
    "teaser": 360.0,
}

# Environment variables for setting custom weight paths per model
MODEL_ENV_VARS: dict[str, str] = {
    "wilor": "SLTK_WILOR_CHECKPOINT",
    "nlf": "SLTK_NLF_MODEL",
    "signrep": "SLTK_SIGNREP_CHECKPOINT",
    "segmentor": "SLTK_SEGMENTOR_V2_CHECKPOINT",
    "teaser": "SLTK_TEASER_CHECKPOINT",
}

# Map weight registry names (from weights.py) to model groups
WEIGHT_TO_MODEL: dict[str, str] = {
    "wilor_checkpoint": "wilor",
    "wilor_detector": "wilor",
    "wilor_config": "wilor",
    "nlf_model": "nlf",
    "nlf_smplx": "nlf",
    "nlf_detector": "nlf",
    "signrep_checkpoint": "signrep",
    "segmentor": "segmentor",
    "segmentor_v2": "segmentor",
    "teaser_checkpoint": "teaser",
}


def get_cache_dir() -> Path:
    """Get the weights cache directory, respecting SLTK_WEIGHTS_DIR env var."""
    env_dir = os.environ.get("SLTK_WEIGHTS_DIR")
    if env_dir:
        return Path(env_dir)
    return _DEFAULT_CACHE_DIR


def _should_auto_download() -> bool:
    """Check if auto-download is enabled via environment variable."""
    return os.environ.get("SLTK_AUTO_DOWNLOAD", "").lower() in ("1", "true", "yes")


def _prompt_download(model: str) -> bool:
    """
    Prompt the user for confirmation before downloading model weights.

    Shows model size and how to set paths manually. Returns True if the
    user confirms, False otherwise. Non-interactive sessions (no TTY)
    will always return False.
    """
    size_mb = MODEL_SIZES_MB.get(model, 0)
    env_var = MODEL_ENV_VARS.get(model, "SLTK_WEIGHTS_DIR")
    cache_dir = get_cache_dir()

    if size_mb >= 1000:
        size_str = f"{size_mb / 1000:.1f} GB"
    else:
        size_str = f"{size_mb:.0f} MB"

    print(f"\n{'=' * 60}", file=sys.stderr)
    print(f"  SLTK: {model.upper()} model weights not found locally", file=sys.stderr)
    print(f"{'=' * 60}", file=sys.stderr)
    print(f"  Download size:  ~{size_str}", file=sys.stderr)
    print(f"  Source:         huggingface.co/{HF_REPO_ID}", file=sys.stderr)
    print(f"  Cache location: {cache_dir}/{model}/", file=sys.stderr)
    print("", file=sys.stderr)
    print("  To skip this prompt, set one of:", file=sys.stderr)
    print("    export SLTK_AUTO_DOWNLOAD=1", file=sys.stderr)
    print(f"    export {env_var}=/path/to/your/weights", file=sys.stderr)
    print("    export SLTK_WEIGHTS_DIR=/path/to/all/weights", file=sys.stderr)
    print(f"{'=' * 60}", file=sys.stderr)

    # Check if we're in an interactive terminal
    if not sys.stdin.isatty():
        print("  Non-interactive session detected. Skipping download.", file=sys.stderr)
        print("  Set SLTK_AUTO_DOWNLOAD=1 to enable automatic downloads.\n", file=sys.stderr)
        return False

    try:
        response = input("  Download now? [y/N]: ").strip().lower()
        return response in ("y", "yes")
    except (EOFError, KeyboardInterrupt):
        print("", file=sys.stderr)
        return False


def ensure_weights(model: str, *, confirm: bool = True) -> dict[str, Path]:
    """
    Ensure all weight files for a model are downloaded.

    Downloads from Hugging Face Hub on first use. Subsequent calls
    return cached paths immediately. Prompts for confirmation before
    downloading unless ``confirm=False`` or ``SLTK_AUTO_DOWNLOAD=1``.

    Args:
        model: Model name — one of "wilor", "nlf", "signrep", "segmentor", "teaser"
        confirm: If True (default), prompt user before downloading.
                 Set to False to download without prompting.

    Returns:
        Dict mapping relative file paths to their local absolute paths.

    Raises:
        ValueError: If model name is unknown.
        ImportError: If huggingface_hub is not installed.
        RuntimeError: If user declines the download.
    """
    if model not in MODEL_FILES:
        available = ", ".join(sorted(MODEL_FILES.keys()))
        raise ValueError(f"Unknown model '{model}'. Available: {available}")

    try:
        from huggingface_hub import hf_hub_download
    except ImportError:
        raise ImportError(
            "huggingface_hub is required for weight downloads. "
            "Install with: pip install huggingface_hub"
        )

    cache_dir = get_cache_dir()
    files = MODEL_FILES[model]
    paths: dict[str, Path] = {}

    # Check which files need downloading
    missing: list[str] = []
    for rel_path in files:
        local_path = cache_dir / rel_path
        if local_path.exists():
            paths[rel_path] = local_path
        else:
            missing.append(rel_path)

    # If everything is cached, return immediately
    if not missing:
        logger.debug("All %s weights found in cache at %s", model, cache_dir)
        return paths

    # Prompt user before downloading
    if confirm and not _should_auto_download():
        if not _prompt_download(model):
            env_var = MODEL_ENV_VARS.get(model, "SLTK_WEIGHTS_DIR")
            raise RuntimeError(
                f"Download declined for {model} weights. "
                f"Set {env_var}=/path/to/weights or SLTK_AUTO_DOWNLOAD=1"
            )

    # Download missing files
    logger.info("Downloading %d file(s) for %s model...", len(missing), model)
    for rel_path in missing:
        logger.info("Downloading %s from %s...", rel_path, HF_REPO_ID)
        downloaded = hf_hub_download(  # type: ignore[call-overload]
            repo_id=HF_REPO_ID,
            filename=rel_path,
            local_dir=str(cache_dir),
            local_dir_use_symlinks=False,
        )
        paths[rel_path] = Path(downloaded)
        logger.info("Downloaded %s", rel_path)

    logger.info("All %s weights ready at %s", model, cache_dir)
    return paths


def ensure_weight_by_name(name: str) -> Path | None:
    """
    Ensure a specific weight is available by its registry name.

    This is the integration point with weights.py — call this when
    the bundled/env path doesn't exist to auto-download.

    Args:
        name: Weight registry name (e.g., "wilor_checkpoint")

    Returns:
        Path to the weight file, or None if the weight name is unknown.
    """
    model = WEIGHT_TO_MODEL.get(name)
    if not model:
        return None

    from sltk.extraction.weights import WEIGHT_PATHS_RELATIVE

    paths = ensure_weights(model)
    rel_path = WEIGHT_PATHS_RELATIVE.get(name)
    if rel_path and rel_path in paths:
        return paths[rel_path]

    return None
