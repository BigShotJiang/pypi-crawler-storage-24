# Pydantic schemas package
