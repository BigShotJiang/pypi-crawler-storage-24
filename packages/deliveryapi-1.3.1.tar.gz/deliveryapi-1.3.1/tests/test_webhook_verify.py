import hashlib
import hmac
import time

import pytest

from deliveryapi import WebhookSignatureError, verify_webhook_signature

SECRET = "whsec_testsecretvalue"


def _make_signature(payload: str, secret: str, ts: int) -> str:
    signed = f"{ts}.{payload}"
    hex_sig = hmac.new(secret.encode(), signed.encode(), hashlib.sha256).hexdigest()
    return f"sha256={hex_sig}"


def test_valid_signature():
    payload = '{"event":"tracking.status_changed"}'
    ts = int(time.time())
    sig = _make_signature(payload, SECRET, ts)
    # Should not raise
    verify_webhook_signature(
        payload=payload,
        signature=sig,
        timestamp=str(ts),
        secret=SECRET,
    )


def test_stale_timestamp_raises():
    payload = "{}"
    old_ts = int(time.time()) - 400
    sig = _make_signature(payload, SECRET, old_ts)
    with pytest.raises(WebhookSignatureError, match="tolerance"):
        verify_webhook_signature(
            payload=payload,
            signature=sig,
            timestamp=str(old_ts),
            secret=SECRET,
        )


def test_wrong_secret_raises():
    payload = "{}"
    ts = int(time.time())
    sig = _make_signature(payload, "wrong_secret", ts)
    with pytest.raises(WebhookSignatureError, match="failed"):
        verify_webhook_signature(
            payload=payload,
            signature=sig,
            timestamp=str(ts),
            secret=SECRET,
        )


def test_invalid_timestamp_raises():
    with pytest.raises(WebhookSignatureError, match="Invalid timestamp"):
        verify_webhook_signature(
            payload="{}",
            signature="sha256=abc",
            timestamp="not-a-number",
            secret=SECRET,
        )


def test_custom_tolerance():
    payload = "{}"
    ts = int(time.time()) - 10
    sig = _make_signature(payload, SECRET, ts)
    # tolerance=5 → should raise
    with pytest.raises(WebhookSignatureError):
        verify_webhook_signature(
            payload=payload,
            signature=sig,
            timestamp=str(ts),
            secret=SECRET,
            tolerance_seconds=5,
        )


def test_tampered_payload_fails():
    """Changing the payload after signing must fail verification."""
    payload = '{"event":"tracking.status_changed"}'
    ts = int(time.time())
    sig = _make_signature(payload, SECRET, ts)
    with pytest.raises(WebhookSignatureError, match="failed"):
        verify_webhook_signature(
            payload='{"event":"tampered"}',
            signature=sig,
            timestamp=str(ts),
            secret=SECRET,
        )
