from __future__ import annotations

from .._types import CourierListResult
from ._base import AsyncAPIResource, SyncAPIResource


class CouriersResource(SyncAPIResource):
    """Supported couriers."""

    def list(self) -> CourierListResult:
        """Retrieve the list of all supported couriers."""
        return self._http.get("/v1/courier/list")


class AsyncCouriersResource(AsyncAPIResource):
    """Supported couriers (async)."""

    async def list(self) -> CourierListResult:
        """Retrieve the list of all supported couriers."""
        return await self._http.get("/v1/courier/list")
