from __future__ import annotations

from typing import Any

from .._types import (
    BatchResultItem,
    BatchResultsResponse,
    ListSubscriptionsResponse,
    RegisterItem,
    RegisterResponse,
    SubscriptionDetail,
)
from ._base import AsyncAPIResource, SyncAPIResource


class SubscriptionsResource(SyncAPIResource):
    """택배 추적 웹훅 구독 관리.

    구독은 하나 이상의 운송장을 감시하다가 배송 상태가 변경되면 웹훅 이벤트를 발송합니다.
    """

    def register(
        self,
        items: list[RegisterItem],
        *,
        recurring: bool,
        endpoint_id: str | None = None,
        metadata: dict[str, str] | None = None,
    ) -> RegisterResponse:
        """택배 추적 구독을 등록합니다.

        Args:
            items: 추적할 운송장 목록. 각 항목에 ``courierCode``와 ``trackingNumber``는 필수,
                ``clientId``는 선택 (웹훅 페이로드에 그대로 포함됨).
            recurring: ``True``이면 배송 완료 또는 14일까지 반복 추적.
                ``False``이면 1회 조회 후 종료.
            endpoint_id: 웹훅 엔드포인트 ID. 제공 시 상태 변경 때 웹훅 발송.
                생략 시 ``get()``으로 직접 폴링.
            metadata: 웹훅 페이로드에 포함할 임의 키-값 쌍.

        Returns:
            ``requestId``, ``itemCount``, ``recurring``을 포함하는 dict.

        Example::

            sub = client.webhooks.subscriptions.register(
                items=[{"courierCode": "cj", "trackingNumber": "1234567890", "clientId": "order_001"}],
                recurring=True,
                endpoint_id="ep_xxxx",
                metadata={"orderId": "ORD-001"},
            )
            print(sub["requestId"])  # 'req_xxxx'
        """
        body: dict[str, Any] = {"items": items, "recurring": recurring}
        if endpoint_id is not None:
            body["endpointId"] = endpoint_id
        if metadata is not None:
            body["metadata"] = metadata
        return self._http.post("/v1/webhooks/register", json=body)  # type: ignore[return-value]

    def list(self, *, cursor: str | None = None) -> ListSubscriptionsResponse:
        """구독 목록을 조회합니다 (커서 기반 페이지네이션).

        한 페이지당 최대 50건을 반환합니다.

        Args:
            cursor: 이전 응답의 ``nextCursor`` 값. 생략 시 처음부터 조회.

        Returns:
            ``subscriptions``, ``total``, 선택적 ``nextCursor``를 포함하는 dict.

        Example::

            cursor = None
            while True:
                page = client.webhooks.subscriptions.list(cursor=cursor)
                for sub in page["subscriptions"]:
                    print(sub["requestId"], sub["isActive"])
                cursor = page.get("nextCursor")
                if not cursor:
                    break
        """
        params: dict[str, str] = {}
        if cursor is not None:
            params["cursor"] = cursor
        return self._http.get("/v1/webhooks/subscriptions", params=params or None)  # type: ignore[return-value]

    def get(self, request_id: str) -> SubscriptionDetail:
        """구독 상세 정보를 조회합니다.

        Args:
            request_id: 구독 ID (``req_...``).

        Returns:
            ``requestId``, 운송장별 상태(``items``), ``summary``,
            폴링 일정 필드 등을 포함하는 dict.

        Raises:
            ApiError: ``NOT_FOUND`` — 구독이 존재하지 않음.

        Example::

            detail = client.webhooks.subscriptions.get("req_xxxx")
            for item in detail["items"]:
                print(item["trackingNumber"], item["currentStatus"])
        """
        return self._http.get(f"/v1/webhooks/subscriptions/{request_id}")  # type: ignore[return-value]

    def cancel(self, request_id: str) -> None:
        """활성 구독을 취소합니다.

        Args:
            request_id: 구독 ID (``req_...``).

        Raises:
            ApiError: ``NOT_FOUND`` — 구독이 존재하지 않음.

        Example::

            client.webhooks.subscriptions.cancel("req_xxxx")
        """
        self._http.delete(f"/v1/webhooks/subscriptions/{request_id}")

    def batch_results(self, items: list[BatchResultItem]) -> BatchResultsResponse:
        """여러 운송장의 최신 배송 상태를 한 번에 조회합니다.

        (택배사 코드 + 송장번호)로 이 계정에 등록된 구독을 검색합니다.

        Args:
            items: ``courierCode``와 ``trackingNumber``를 가진 항목 목록.

        Returns:
            ``results``와 ``total``을 포함하는 dict.

        Example::

            result = client.webhooks.subscriptions.batch_results(
                items=[
                    {"courierCode": "cj",    "trackingNumber": "1111111111"},
                    {"courierCode": "lotte", "trackingNumber": "2222222222"},
                ],
            )
            for r in result["results"]:
                print(r["currentStatus"], r["isDelivered"])
        """
        return self._http.post("/v1/webhooks/results", json={"items": items})  # type: ignore[return-value]


class AsyncSubscriptionsResource(AsyncAPIResource):
    """택배 추적 웹훅 구독 관리 (비동기)."""

    async def register(
        self,
        items: list[RegisterItem],
        *,
        recurring: bool,
        endpoint_id: str | None = None,
        metadata: dict[str, str] | None = None,
    ) -> RegisterResponse:
        """택배 추적 구독을 등록합니다 (비동기)."""
        body: dict[str, Any] = {"items": items, "recurring": recurring}
        if endpoint_id is not None:
            body["endpointId"] = endpoint_id
        if metadata is not None:
            body["metadata"] = metadata
        return await self._http.post("/v1/webhooks/register", json=body)  # type: ignore[return-value]

    async def list(self, *, cursor: str | None = None) -> ListSubscriptionsResponse:
        """구독 목록을 조회합니다 (비동기)."""
        params: dict[str, str] = {}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._http.get("/v1/webhooks/subscriptions", params=params or None)  # type: ignore[return-value]

    async def get(self, request_id: str) -> SubscriptionDetail:
        """구독 상세 정보를 조회합니다 (비동기)."""
        return await self._http.get(f"/v1/webhooks/subscriptions/{request_id}")  # type: ignore[return-value]

    async def cancel(self, request_id: str) -> None:
        """활성 구독을 취소합니다 (비동기)."""
        await self._http.delete(f"/v1/webhooks/subscriptions/{request_id}")

    async def batch_results(self, items: list[BatchResultItem]) -> BatchResultsResponse:
        """여러 운송장의 최신 배송 상태를 한 번에 조회합니다 (비동기)."""
        return await self._http.post("/v1/webhooks/results", json={"items": items})  # type: ignore[return-value]
