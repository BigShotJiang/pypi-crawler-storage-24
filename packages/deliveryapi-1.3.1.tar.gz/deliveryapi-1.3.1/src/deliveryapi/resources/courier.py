from __future__ import annotations

from .._http import AsyncHttpClient, HttpClient
from .courier_accounts import AccountsResource, AsyncAccountsResource
from .courier_deliveries import AsyncDeliveriesResource, DeliveriesResource
from .courier_print import AsyncPrintResource, PrintResource


class CourierResource:
    """택배 계정 서비스.

    - ``accounts`` — 택배사 계정 등록·조회·삭제
    - ``deliveries`` — 대량 등록, 배송 조회, 통계, 취소
    - ``deliveries.histories`` — 대량 등록 이력 관리
    - ``print`` — 송장 출력 세션

    Example::

        # 1. 계정 등록
        account = client.courier.accounts.register(
            provider_id="lotte",
            account_id="your_id",
            account_password="your_password",
        )

        # 2. 대량 등록
        result = client.courier.deliveries.bulk_upload(
            courier_account_key=account["courierAccountKey"],
            items=[{
                "clientOrderId": "ORDER-001",
                "receiverName": "홍길동",
                "receiverPhone1": "01012345678",
                "receiverAddress": "서울특별시 중구 세종대로 110",
                "productName": "테스트 상품",
                "quantity": 1,
            }],
        )

        # 3. 송장 출력
        session = client.courier.print.create_session(
            courier_account_key=account["courierAccountKey"],
            provider_id="lotte",
            courier_tracking_ids=[r["courierDeliveryId"] for r in result["results"] if r["success"]],
        )
    """

    def __init__(self, http: HttpClient) -> None:
        self.accounts = AccountsResource(http)
        self.deliveries = DeliveriesResource(http)
        self.print = PrintResource(http)


class AsyncCourierResource:
    """택배 계정 서비스 (비동기).

    Same interface as ``CourierResource`` but all methods are coroutines.
    """

    def __init__(self, http: AsyncHttpClient) -> None:
        self.accounts = AsyncAccountsResource(http)
        self.deliveries = AsyncDeliveriesResource(http)
        self.print = AsyncPrintResource(http)
