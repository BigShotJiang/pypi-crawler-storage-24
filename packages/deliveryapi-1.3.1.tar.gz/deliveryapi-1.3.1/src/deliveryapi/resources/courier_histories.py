from __future__ import annotations

from typing import Any

from .._types import HistoryDetailResponse, ListHistoriesResponse
from ._base import AsyncAPIResource, SyncAPIResource


class HistoriesResource(SyncAPIResource):
    """대량 등록 이력 관리.

    대량 등록 후 생성된 이력을 조회·삭제합니다.
    """

    def list(
        self,
        *,
        provider_id: str,
        courier_account_key: str | None = None,
        from_date: str | None = None,
        to_date: str | None = None,
        limit: int | None = None,
    ) -> ListHistoriesResponse:
        """대량 등록 이력 목록을 조회합니다.

        Args:
            provider_id: 택배사 ID (필수).
            courier_account_key: 계정 키로 필터 (선택).
            from_date: 시작일 ``YYYY-MM-DD`` (선택).
            to_date: 종료일 ``YYYY-MM-DD`` (선택).
            limit: 최대 결과 수 (기본 50, 선택).

        Returns:
            ``histories`` 배열을 포함하는 dict.

        Example::

            result = client.courier.deliveries.histories.list(
                provider_id="lotte",
                courier_account_key="YOUR_ACCOUNT_KEY",
                limit=10,
            )
            for h in result["histories"]:
                print(h["id"], h["status"], h["totalCount"])
        """
        params: dict[str, str] = {"providerId": provider_id}
        if courier_account_key is not None:
            params["courierAccountKey"] = courier_account_key
        if from_date is not None:
            params["fromDate"] = from_date
        if to_date is not None:
            params["toDate"] = to_date
        if limit is not None:
            params["limit"] = str(limit)
        return self._http.get("/v1/courier/deliveries/bulk-upload-histories", params=params)  # type: ignore[return-value]

    def get(
        self,
        history_id: str,
        *,
        courier_account_key: str,
    ) -> HistoryDetailResponse:
        """대량 등록 이력의 상세 정보를 조회합니다.

        택배사 API를 호출하여 실시간 배송 상태를 함께 반환합니다.

        Args:
            history_id: 이력 ID.
            courier_account_key: 계정 키 (소유권 확인용).

        Returns:
            ``history`` (이력 정보) + ``detailItems`` (실시간 배송 상태).

        Raises:
            ApiError: ``NOT_FOUND`` — 존재하지 않는 이력 또는 계정.

        Example::

            result = client.courier.deliveries.histories.get(
                "20260320_1430_abc12",
                courier_account_key="YOUR_ACCOUNT_KEY",
            )
            for item in result["detailItems"]:
                print(item["trackingNumber"], item["deliveryStatus"])
        """
        return self._http.get(  # type: ignore[return-value]
            f"/v1/courier/deliveries/bulk-upload-histories/{history_id}/detail",
            params={"courierAccountKey": courier_account_key},
        )

    def delete(
        self,
        history_id: str,
        *,
        courier_account_key: str,
        courier_delivery_ids: list[str] | None = None,
    ) -> None:
        """대량 등록 이력을 삭제(취소)합니다.

        ``courier_delivery_ids``를 지정하면 부분 취소, 생략하면 전체 취소입니다.
        택배사 API를 호출하여 실제 접수도 취소합니다.

        Args:
            history_id: 이력 ID.
            courier_account_key: 계정 키 (소유권 확인용).
            courier_delivery_ids: 취소할 배송 ID 목록 (선택, 생략 시 전체 취소).

        Raises:
            ApiError: ``NOT_FOUND`` — 존재하지 않는 이력 또는 계정.

        Example::

            # 전체 취소
            client.courier.deliveries.histories.delete(
                "20260320_1430_abc12",
                courier_account_key="YOUR_ACCOUNT_KEY",
            )

            # 부분 취소
            client.courier.deliveries.histories.delete(
                "20260320_1430_abc12",
                courier_account_key="YOUR_ACCOUNT_KEY",
                courier_delivery_ids=["7705459135", "7705459136"],
            )
        """
        body: dict[str, Any] | None = None
        if courier_delivery_ids is not None:
            body = {"courierDeliveryIds": courier_delivery_ids}
        self._http.delete(
            f"/v1/courier/deliveries/bulk-upload-histories/{history_id}",
            params={"courierAccountKey": courier_account_key},
            json=body,
        )


class AsyncHistoriesResource(AsyncAPIResource):
    """대량 등록 이력 관리 (비동기)."""

    async def list(
        self,
        *,
        provider_id: str,
        courier_account_key: str | None = None,
        from_date: str | None = None,
        to_date: str | None = None,
        limit: int | None = None,
    ) -> ListHistoriesResponse:
        """대량 등록 이력 목록을 조회합니다 (비동기)."""
        params: dict[str, str] = {"providerId": provider_id}
        if courier_account_key is not None:
            params["courierAccountKey"] = courier_account_key
        if from_date is not None:
            params["fromDate"] = from_date
        if to_date is not None:
            params["toDate"] = to_date
        if limit is not None:
            params["limit"] = str(limit)
        return await self._http.get("/v1/courier/deliveries/bulk-upload-histories", params=params)  # type: ignore[return-value]

    async def get(
        self,
        history_id: str,
        *,
        courier_account_key: str,
    ) -> HistoryDetailResponse:
        """대량 등록 이력의 상세 정보를 조회합니다 (비동기)."""
        return await self._http.get(  # type: ignore[return-value]
            f"/v1/courier/deliveries/bulk-upload-histories/{history_id}/detail",
            params={"courierAccountKey": courier_account_key},
        )

    async def delete(
        self,
        history_id: str,
        *,
        courier_account_key: str,
        courier_delivery_ids: list[str] | None = None,
    ) -> None:
        """대량 등록 이력을 삭제(취소)합니다 (비동기)."""
        body: dict[str, Any] | None = None
        if courier_delivery_ids is not None:
            body = {"courierDeliveryIds": courier_delivery_ids}
        await self._http.delete(
            f"/v1/courier/deliveries/bulk-upload-histories/{history_id}",
            params={"courierAccountKey": courier_account_key},
            json=body,
        )
