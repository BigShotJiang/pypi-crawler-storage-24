from __future__ import annotations

from typing import Any

from .._types import CourierAccountDetail, CourierAccountInfo, RegisterAccountResponse
from ._base import AsyncAPIResource, SyncAPIResource


class AccountsResource(SyncAPIResource):
    """택배사 계정 관리.

    택배사(롯데, CJ 등) 로그인 계정을 등록·조회·삭제합니다.
    """

    def register(
        self,
        *,
        provider_id: str,
        account_id: str,
        account_password: str,
        account_name: str | None = None,
        description: str | None = None,
        sms_auto_capture: bool | None = None,
        phone_number: str | None = None,
    ) -> RegisterAccountResponse:
        """택배사 계정을 등록합니다.

        등록 후 반환되는 ``courierAccountKey``를 저장하세요.
        이후 대량 등록, 조회, 송장 출력 등에 사용됩니다.

        Args:
            provider_id: 택배사 ID (``'lotte'`` 또는 ``'cj'``).
            account_id: 택배사 로그인 ID.
            account_password: 택배사 로그인 비밀번호.
            account_name: 계정 표시 이름 (선택).
            description: 계정 설명 (선택).
            sms_auto_capture: SMS OTP 자동 캡처 활성화 (CJ 2FA 계정용, 선택).
            phone_number: OTP 수신 전화번호 (``sms_auto_capture`` 사용 시, 선택).

        Returns:
            등록된 계정 정보 (``courierAccountKey``, ``providerId``, ``accountId`` 등).

        Raises:
            ApiError: ``FORBIDDEN`` — 계정 슬롯 한도 초과.
            ApiError: ``INVALID_PARAMS`` — 잘못된 파라미터.

        Example::

            account = client.courier.accounts.register(
                provider_id="lotte",
                account_id="your_id",
                account_password="your_password",
            )
            print(account["courierAccountKey"])
        """
        body: dict[str, Any] = {
            "providerId": provider_id,
            "accountId": account_id,
            "accountPassword": account_password,
        }
        if account_name is not None:
            body["accountName"] = account_name
        if description is not None:
            body["description"] = description
        if sms_auto_capture is not None:
            body["smsAutoCapture"] = sms_auto_capture
        if phone_number is not None:
            body["phoneNumber"] = phone_number
        return self._http.post("/v1/courier/accounts/register", json=body)  # type: ignore[return-value]

    def list(self) -> list[CourierAccountInfo]:
        """등록된 택배사 계정 목록을 조회합니다.

        Returns:
            계정 정보 리스트.

        Example::

            accounts = client.courier.accounts.list()
            for a in accounts:
                print(a["courierAccountKey"], a["providerId"], a["isActive"])
        """
        return self._http.get("/v1/courier/accounts")  # type: ignore[return-value]

    def get(self, courier_account_key: str) -> CourierAccountDetail:
        """택배사 계정 상세 정보를 조회합니다.

        Args:
            courier_account_key: 계정 키.

        Returns:
            계정 상세 정보 (비밀번호는 "(암호화하여 저장중)"으로 마스킹).

        Raises:
            ApiError: ``NOT_FOUND`` — 존재하지 않는 계정.

        Example::

            detail = client.courier.accounts.get("YOUR_ACCOUNT_KEY")
            print(detail["accountId"], detail["isActive"])
        """
        return self._http.get(f"/v1/courier/accounts/{courier_account_key}")  # type: ignore[return-value]

    def delete(self, courier_account_key: str) -> None:
        """택배사 계정을 삭제합니다.

        Args:
            courier_account_key: 삭제할 계정 키.

        Raises:
            ApiError: ``NOT_FOUND`` — 존재하지 않는 계정.

        Example::

            client.courier.accounts.delete("YOUR_ACCOUNT_KEY")
        """
        self._http.delete(f"/v1/courier/accounts/{courier_account_key}")


class AsyncAccountsResource(AsyncAPIResource):
    """택배사 계정 관리 (비동기)."""

    async def register(
        self,
        *,
        provider_id: str,
        account_id: str,
        account_password: str,
        account_name: str | None = None,
        description: str | None = None,
        sms_auto_capture: bool | None = None,
        phone_number: str | None = None,
    ) -> RegisterAccountResponse:
        """택배사 계정을 등록합니다 (비동기)."""
        body: dict[str, Any] = {
            "providerId": provider_id,
            "accountId": account_id,
            "accountPassword": account_password,
        }
        if account_name is not None:
            body["accountName"] = account_name
        if description is not None:
            body["description"] = description
        if sms_auto_capture is not None:
            body["smsAutoCapture"] = sms_auto_capture
        if phone_number is not None:
            body["phoneNumber"] = phone_number
        return await self._http.post("/v1/courier/accounts/register", json=body)  # type: ignore[return-value]

    async def list(self) -> list[CourierAccountInfo]:
        """등록된 택배사 계정 목록을 조회합니다 (비동기)."""
        return await self._http.get("/v1/courier/accounts")  # type: ignore[return-value]

    async def get(self, courier_account_key: str) -> CourierAccountDetail:
        """택배사 계정 상세 정보를 조회합니다 (비동기)."""
        return await self._http.get(f"/v1/courier/accounts/{courier_account_key}")  # type: ignore[return-value]

    async def delete(self, courier_account_key: str) -> None:
        """택배사 계정을 삭제합니다 (비동기)."""
        await self._http.delete(f"/v1/courier/accounts/{courier_account_key}")
