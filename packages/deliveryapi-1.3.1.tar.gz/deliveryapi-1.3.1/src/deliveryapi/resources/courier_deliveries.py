from __future__ import annotations

from typing import Any

from .._http import AsyncHttpClient, HttpClient
from .._types import AccountInquiryResponse, BulkUploadResponse, DashboardStatsResponse
from .courier_histories import AsyncHistoriesResource, HistoriesResource


class DeliveriesResource:
    """택배 배송 관리.

    대량 등록, 배송 조회, 대시보드 통계, 배송 취소 등.
    """

    def __init__(self, http: HttpClient) -> None:
        self._http = http
        self.histories = HistoriesResource(http)

    def bulk_upload(
        self,
        *,
        courier_account_key: str,
        items: list[dict[str, Any]],
    ) -> BulkUploadResponse:
        """택배를 대량 등록합니다. 최대 1,000건까지 한 번에 등록 가능합니다.

        등록 직후에는 관리번호(``courierDeliveryId``)만 발급됩니다.
        송장번호(``trackingNumber``)는 **송장 출력 시점에 발급**됩니다.

        부분 실패가 가능하므로 ``results`` 내 개별 ``success`` 값을 확인하세요.

        Args:
            courier_account_key: 계정 키.
            items: 등록할 배송 목록. 각 항목에 ``clientOrderId``, ``receiverName``,
                ``receiverPhone1``, ``receiverAddress``, ``productName``, ``quantity`` 필수.

        Returns:
            등록 결과 (``success``, ``historyId``, ``totalUploaded``, ``results`` 등).

        Raises:
            ApiError: ``RATE_LIMITED`` — 요청 한도 초과.
            ApiError: ``FORBIDDEN`` — 계정 슬롯 한도 초과.

        Example::

            result = client.courier.deliveries.bulk_upload(
                courier_account_key="YOUR_ACCOUNT_KEY",
                items=[{
                    "clientOrderId": "ORDER-001",
                    "receiverName": "홍길동",
                    "receiverPhone1": "01012345678",
                    "receiverAddress": "서울특별시 중구 세종대로 110",
                    "productName": "테스트 상품",
                    "quantity": 1,
                }],
            )
            failed = [r for r in result["results"] if not r["success"]]
        """
        return self._http.post("/v1/courier/deliveries/bulk-upload", json={  # type: ignore[return-value]
            "courierAccountKey": courier_account_key,
            "items": items,
        })

    def inquiry(
        self,
        *,
        courier_account_key: str,
        from_date: str,
        to_date: str,
        status_filter: str | None = None,
        include_details: bool | None = None,
    ) -> AccountInquiryResponse:
        """택배사 계정의 배송 목록을 조회합니다.

        택배사 API를 실시간으로 호출하여 최신 배송 상태를 반환합니다.

        Args:
            courier_account_key: 계정 키.
            from_date: 시작일 ``YYYY-MM-DD``.
            to_date: 종료일 ``YYYY-MM-DD``.
            status_filter: 상태 필터 (``'all'``, ``'delivered'``, ``'not_delivered'``,
                ``'in_transit'``, ``'pending'``). 기본값 ``'all'``.
            include_details: 상세 데이터 포함 여부 (선택).

        Returns:
            ``items`` (배송 목록) + ``summary`` (요약 통계).

        Raises:
            ApiError: ``NOT_FOUND`` — 존재하지 않는 계정.

        Example::

            result = client.courier.deliveries.inquiry(
                courier_account_key="YOUR_ACCOUNT_KEY",
                from_date="2026-01-01",
                to_date="2026-01-31",
            )
            print(result["summary"]["delivered"])
        """
        body: dict[str, Any] = {
            "courierAccountKey": courier_account_key,
            "fromDate": from_date,
            "toDate": to_date,
        }
        if status_filter is not None:
            body["statusFilter"] = status_filter
        if include_details is not None:
            body["includeDetails"] = include_details
        return self._http.post("/v1/courier/deliveries/inquiry", json=body)  # type: ignore[return-value]

    def dashboard(
        self,
        *,
        courier_account_key: str,
        from_date: str,
        to_date: str,
    ) -> DashboardStatsResponse:
        """택배사 계정의 배송 통계(대시보드)를 조회합니다.

        Args:
            courier_account_key: 계정 키.
            from_date: 시작일 ``YYYY-MM-DD``.
            to_date: 종료일 ``YYYY-MM-DD``.

        Returns:
            ``items`` (상세 행) + ``summary`` (요약 통계).

        Raises:
            ApiError: ``NOT_FOUND`` — 존재하지 않는 계정.

        Example::

            stats = client.courier.deliveries.dashboard(
                courier_account_key="YOUR_ACCOUNT_KEY",
                from_date="2026-01-01",
                to_date="2026-01-31",
            )
            print(stats["summary"]["totalCount"])
        """
        return self._http.get("/v1/courier/deliveries/dashboard", params={  # type: ignore[return-value]
            "courierAccountKey": courier_account_key,
            "fromDate": from_date,
            "toDate": to_date,
        })

    def cancel(
        self,
        *,
        courier_account_key: str,
        courier_delivery_ids: list[str],
    ) -> None:
        """등록된 배송을 취소합니다.

        **주의**: 등록 후 7일 이내의 배송만 취소 가능합니다.

        Args:
            courier_account_key: 계정 키.
            courier_delivery_ids: 취소할 배송 ID 목록.

        Raises:
            ApiError: ``NOT_FOUND`` — 존재하지 않는 계정.
            ApiError: ``INVALID_PARAMS`` — 택배사가 배송 취소를 지원하지 않음.

        Example::

            client.courier.deliveries.cancel(
                courier_account_key="YOUR_ACCOUNT_KEY",
                courier_delivery_ids=["7705459135"],
            )
        """
        self._http.post("/v1/courier/deliveries/cancel", json={
            "courierAccountKey": courier_account_key,
            "courierDeliveryIds": courier_delivery_ids,
        })


class AsyncDeliveriesResource:
    """택배 배송 관리 (비동기)."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http
        self.histories = AsyncHistoriesResource(http)

    async def bulk_upload(
        self,
        *,
        courier_account_key: str,
        items: list[dict[str, Any]],
    ) -> BulkUploadResponse:
        """택배를 대량 등록합니다 (비동기)."""
        return await self._http.post("/v1/courier/deliveries/bulk-upload", json={  # type: ignore[return-value]
            "courierAccountKey": courier_account_key,
            "items": items,
        })

    async def inquiry(
        self,
        *,
        courier_account_key: str,
        from_date: str,
        to_date: str,
        status_filter: str | None = None,
        include_details: bool | None = None,
    ) -> AccountInquiryResponse:
        """택배사 계정의 배송 목록을 조회합니다 (비동기)."""
        body: dict[str, Any] = {
            "courierAccountKey": courier_account_key,
            "fromDate": from_date,
            "toDate": to_date,
        }
        if status_filter is not None:
            body["statusFilter"] = status_filter
        if include_details is not None:
            body["includeDetails"] = include_details
        return await self._http.post("/v1/courier/deliveries/inquiry", json=body)  # type: ignore[return-value]

    async def dashboard(
        self,
        *,
        courier_account_key: str,
        from_date: str,
        to_date: str,
    ) -> DashboardStatsResponse:
        """택배사 계정의 배송 통계(대시보드)를 조회합니다 (비동기)."""
        return await self._http.get("/v1/courier/deliveries/dashboard", params={  # type: ignore[return-value]
            "courierAccountKey": courier_account_key,
            "fromDate": from_date,
            "toDate": to_date,
        })

    async def cancel(
        self,
        *,
        courier_account_key: str,
        courier_delivery_ids: list[str],
    ) -> None:
        """등록된 배송을 취소합니다 (비동기)."""
        await self._http.post("/v1/courier/deliveries/cancel", json={
            "courierAccountKey": courier_account_key,
            "courierDeliveryIds": courier_delivery_ids,
        })
