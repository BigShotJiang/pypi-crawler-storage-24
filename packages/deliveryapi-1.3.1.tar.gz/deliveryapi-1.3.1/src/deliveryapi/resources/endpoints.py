from __future__ import annotations

from typing import Any

from .._types import CreateEndpointResponse, ListEndpointsResponse, RotateSecretResponse
from ._base import AsyncAPIResource, SyncAPIResource


class EndpointsResource(SyncAPIResource):
    """웹훅 엔드포인트 관리.

    엔드포인트는 배송 상태 변경 이벤트를 수신할 URL입니다.
    """

    def create(self, url: str, *, name: str | None = None, webhook_secret: str | None = None) -> CreateEndpointResponse:
        """웹훅 엔드포인트를 등록합니다.

        등록 시 서버에서 URL로 테스트 POST 요청을 전송하여 수신 가능 여부를 검증합니다.
        응답의 ``webhookSecret``은 **이 응답에서만** 평문으로 반환됩니다 — 안전하게 보관하세요.
        분실 시 ``rotate_secret()``으로 재발급해야 합니다.

        Args:
            url: 웹훅을 수신할 URL (``https://``로 시작해야 함).
            name: 엔드포인트 관리용 이름 (선택).
            webhook_secret: 서명 시크릿 직접 지정 (선택, 최소 5자).
                미제공 시 서버가 랜덤 시크릿을 생성합니다.

        Raises:
            ApiError: ``INVALID_PARAMS`` — 최대 엔드포인트 수 초과.
            ApiError: ``WEBHOOK_ENDPOINT_UNREACHABLE`` — URL 검증 실패.

        Example::

            endpoint = client.webhooks.endpoints.create(
                url="https://my.server/webhook",
                name="운영 서버",
            )
            # endpoint["webhookSecret"]을 안전하게 보관하세요 — 이후 조회 불가!
            print(endpoint["endpointId"])
        """
        body: dict[str, Any] = {"url": url}
        if name is not None:
            body["name"] = name
        if webhook_secret is not None:
            body["webhookSecret"] = webhook_secret
        return self._http.post("/v1/webhooks/endpoints", json=body)  # type: ignore[return-value]

    def list(self) -> ListEndpointsResponse:
        """등록된 웹훅 엔드포인트 목록을 조회합니다.

        Example::

            result = client.webhooks.endpoints.list()
            for ep in result["endpoints"]:
                print(ep["endpointId"], ep["status"])
        """
        return self._http.get("/v1/webhooks/endpoints")  # type: ignore[return-value]

    def update(self, endpoint_id: str, *, name: str) -> None:
        """엔드포인트 이름을 수정합니다.

        URL은 변경할 수 없습니다. URL을 바꾸려면 삭제 후 재등록하세요.

        Args:
            endpoint_id: 엔드포인트 ID (``ep_...``).
            name: 새 이름.

        Raises:
            ApiError: ``NOT_FOUND`` — 엔드포인트가 존재하지 않음.

        Example::

            client.webhooks.endpoints.update("ep_xxxx", name="스테이징")
        """
        self._http.put(f"/v1/webhooks/endpoints/{endpoint_id}", json={"name": name})

    def delete(self, endpoint_id: str) -> None:
        """웹훅 엔드포인트를 삭제합니다.

        연결된 모든 구독도 함께 삭제됩니다 (cascade).

        Args:
            endpoint_id: 엔드포인트 ID (``ep_...``).

        Raises:
            ApiError: ``NOT_FOUND`` — 엔드포인트가 존재하지 않음.

        Example::

            client.webhooks.endpoints.delete("ep_xxxx")
        """
        self._http.delete(f"/v1/webhooks/endpoints/{endpoint_id}")

    def rotate_secret(self, endpoint_id: str, *, webhook_secret: str | None = None) -> RotateSecretResponse:
        """웹훅 서명 시크릿을 재발급합니다.

        기존 시크릿은 즉시 무효화됩니다.
        새 시크릿은 **이 응답에서만** 평문으로 반환됩니다 — 안전하게 보관하세요.

        Args:
            endpoint_id: 엔드포인트 ID (``ep_...``).
            webhook_secret: 새 시크릿 직접 지정 (선택).
                미제공 시 서버가 랜덤 시크릿을 생성합니다.

        Raises:
            ApiError: ``NOT_FOUND`` — 엔드포인트가 존재하지 않음.

        Example::

            result = client.webhooks.endpoints.rotate_secret("ep_xxxx")
            # result["webhookSecret"]을 안전하게 보관하세요!
        """
        body: dict[str, Any] = {}
        if webhook_secret is not None:
            body["webhookSecret"] = webhook_secret
        return self._http.post(f"/v1/webhooks/endpoints/{endpoint_id}/rotate", json=body)  # type: ignore[return-value]


class AsyncEndpointsResource(AsyncAPIResource):
    """웹훅 엔드포인트 관리 (비동기)."""

    async def create(self, url: str, *, name: str | None = None, webhook_secret: str | None = None) -> CreateEndpointResponse:
        """웹훅 엔드포인트를 등록합니다 (비동기)."""
        body: dict[str, Any] = {"url": url}
        if name is not None:
            body["name"] = name
        if webhook_secret is not None:
            body["webhookSecret"] = webhook_secret
        return await self._http.post("/v1/webhooks/endpoints", json=body)  # type: ignore[return-value]

    async def list(self) -> ListEndpointsResponse:
        """등록된 웹훅 엔드포인트 목록을 조회합니다 (비동기)."""
        return await self._http.get("/v1/webhooks/endpoints")  # type: ignore[return-value]

    async def update(self, endpoint_id: str, *, name: str) -> None:
        """엔드포인트 이름을 수정합니다 (비동기)."""
        await self._http.put(f"/v1/webhooks/endpoints/{endpoint_id}", json={"name": name})

    async def delete(self, endpoint_id: str) -> None:
        """웹훅 엔드포인트를 삭제합니다 (비동기)."""
        await self._http.delete(f"/v1/webhooks/endpoints/{endpoint_id}")

    async def rotate_secret(self, endpoint_id: str, *, webhook_secret: str | None = None) -> RotateSecretResponse:
        """웹훅 서명 시크릿을 재발급합니다 (비동기)."""
        body: dict[str, Any] = {}
        if webhook_secret is not None:
            body["webhookSecret"] = webhook_secret
        return await self._http.post(f"/v1/webhooks/endpoints/{endpoint_id}/rotate", json=body)  # type: ignore[return-value]
