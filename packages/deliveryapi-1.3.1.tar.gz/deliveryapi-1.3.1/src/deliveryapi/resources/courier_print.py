from __future__ import annotations

from typing import Any

from .._types import PrintSessionResponse
from ._base import AsyncAPIResource, SyncAPIResource


class PrintResource(SyncAPIResource):
    """송장 출력 세션 관리."""

    def create_session(
        self,
        *,
        courier_account_key: str,
        provider_id: str,
        courier_tracking_ids: list[str] | None = None,
        bulk_upload_history_id: str | None = None,
    ) -> PrintSessionResponse:
        """송장 출력 세션을 생성합니다.

        세션 ID로 출력 페이지(``https://print.deliveryapi.co.kr?session={sessionId}``)에
        접속할 수 있습니다. 세션은 **10분 유효, 1회용**입니다.

        ``courier_tracking_ids`` 또는 ``bulk_upload_history_id`` 중 하나를 지정하세요.

        **중요**: 대부분의 택배사에서 송장번호(trackingNumber)는 이 출력 시점에 발급됩니다.

        Args:
            courier_account_key: 계정 키.
            provider_id: 택배사 ID.
            courier_tracking_ids: 개별 출력할 택배사 추적 ID 목록 (선택).
            bulk_upload_history_id: 이력 전체 출력용 이력 ID (선택).

        Returns:
            ``sessionId``와 ``expiresAt``을 포함하는 dict.

        Raises:
            ApiError: ``NOT_FOUND`` — 존재하지 않는 계정 또는 배송 ID.

        Example::

            session = client.courier.print.create_session(
                courier_account_key="YOUR_ACCOUNT_KEY",
                provider_id="lotte",
                courier_tracking_ids=["7705241632", "7705241633"],
            )
            print(f"https://print.deliveryapi.co.kr?session={session['sessionId']}")
        """
        body: dict[str, Any] = {
            "courierAccountKey": courier_account_key,
            "providerId": provider_id,
        }
        if courier_tracking_ids is not None:
            body["courierTrackingIds"] = courier_tracking_ids
        if bulk_upload_history_id is not None:
            body["bulkUploadHistoryId"] = bulk_upload_history_id
        return self._http.post("/v1/courier/print/sessions", json=body)  # type: ignore[return-value]


class AsyncPrintResource(AsyncAPIResource):
    """송장 출력 세션 관리 (비동기)."""

    async def create_session(
        self,
        *,
        courier_account_key: str,
        provider_id: str,
        courier_tracking_ids: list[str] | None = None,
        bulk_upload_history_id: str | None = None,
    ) -> PrintSessionResponse:
        """송장 출력 세션을 생성합니다 (비동기)."""
        body: dict[str, Any] = {
            "courierAccountKey": courier_account_key,
            "providerId": provider_id,
        }
        if courier_tracking_ids is not None:
            body["courierTrackingIds"] = courier_tracking_ids
        if bulk_upload_history_id is not None:
            body["bulkUploadHistoryId"] = bulk_upload_history_id
        return await self._http.post("/v1/courier/print/sessions", json=body)  # type: ignore[return-value]
