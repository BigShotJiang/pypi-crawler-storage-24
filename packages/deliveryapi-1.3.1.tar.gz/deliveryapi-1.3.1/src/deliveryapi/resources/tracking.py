from __future__ import annotations

from .._types import GetCouriersResponse, TraceItem, TraceResponse
from ._base import AsyncAPIResource, SyncAPIResource


class TrackingResource(SyncAPIResource):
    """Courier tracking."""

    def get_couriers(self) -> GetCouriersResponse:
        """지원 택배사 목록을 조회합니다.

        ``trace()`` 호출 시 사용할 ``trackingApiCode``와 표시명(``displayName``)을 반환합니다.

        Example::

            result = client.tracking.get_couriers()
            for c in result["couriers"]:
                print(c["trackingApiCode"], c["displayName"])
        """
        return self._http.get("/v1/tracking/couriers")  # type: ignore[return-value]

    def trace(
        self,
        items: list[TraceItem],
        *,
        include_progresses: bool = True,
    ) -> TraceResponse:
        """운송장 배송 상태를 조회합니다 (최대 10건 배치 처리).

        Args:
            items: 조회할 운송장 목록. 각 항목에 ``courierCode``와 ``trackingNumber``는 필수,
                ``clientId``는 선택 (응답에 그대로 반환됨).
            include_progresses: 배송 진행 내역 포함 여부 (기본값: True).
                상태만 확인할 때 ``False``로 설정하면 응답 크기가 줄어듭니다.

        Returns:
            ``results`` (운송장별 결과)와 ``summary`` (집계)를 포함하는 dict.
            개별 건이 실패해도 전체 요청은 성공할 수 있으므로
            각 항목의 ``results[i]["success"]``를 확인하세요.

        Raises:
            ApiError: 인증 실패, 요청 한도 초과 등.

        Example::

            result = client.tracking.trace(
                items=[
                    {"courierCode": "cj",    "trackingNumber": "1234567890", "clientId": "order_001"},
                    {"courierCode": "lotte", "trackingNumber": "9876543210"},
                ],
            )
            for r in result["results"]:
                if r["success"]:
                    print(r["data"]["deliveryStatus"])
                else:
                    print(r["error"]["code"])
        """
        return self._http.post("/v1/tracking/trace", json={  # type: ignore[return-value]
            "items": items,
            "includeProgresses": include_progresses,
        })


class AsyncTrackingResource(AsyncAPIResource):
    """Courier tracking (async)."""

    async def get_couriers(self) -> GetCouriersResponse:
        """지원 택배사 목록을 조회합니다 (비동기)."""
        return await self._http.get("/v1/tracking/couriers")  # type: ignore[return-value]

    async def trace(
        self,
        items: list[TraceItem],
        *,
        include_progresses: bool = True,
    ) -> TraceResponse:
        """운송장 배송 상태를 조회합니다 (비동기)."""
        return await self._http.post("/v1/tracking/trace", json={  # type: ignore[return-value]
            "items": items,
            "includeProgresses": include_progresses,
        })
