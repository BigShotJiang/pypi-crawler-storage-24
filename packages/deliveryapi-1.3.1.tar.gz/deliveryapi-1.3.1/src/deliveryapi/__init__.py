"""DeliveryAPI Python SDK.

Quick start::

    from deliveryapi import DeliveryAPIClient

    client = DeliveryAPIClient(api_key="pk_...", secret_key="sk_...")

    # List couriers
    couriers = client.tracking.get_couriers()

    # Query tracking status
    result = client.tracking.trace(
        items=[{"courierCode": "cj", "trackingNumber": "1234567890"}]
    )
    print(result["results"][0]["data"]["deliveryStatus"])

    # Webhook management
    endpoint = client.webhooks.endpoints.create(
        url="https://my.server/webhook",
        name="Production",
    )
    sub = client.webhooks.subscriptions.register(
        items=[{"courierCode": "cj", "trackingNumber": "1234567890"}],
        recurring=True,
        endpoint_id=endpoint["endpointId"],
    )

    # Courier account management
    account = client.courier.accounts.register(
        provider_id="lotte",
        account_id="your_id",
        account_password="your_password",
    )
    result = client.courier.deliveries.bulk_upload(
        courier_account_key=account["courierAccountKey"],
        items=[{
            "clientOrderId": "ORDER-001",
            "receiverName": "홍길동",
            "receiverPhone1": "01012345678",
            "receiverAddress": "서울특별시 중구 세종대로 110",
            "productName": "테스트 상품",
            "quantity": 1,
        }],
    )
"""
from __future__ import annotations

from ._client import AsyncDeliveryAPIClient, DeliveryAPIClient
from ._exceptions import ApiError, AuthenticationError, NotFoundError, RateLimitError
from ._types import (
    AccountInquiryItem,
    AccountInquiryResponse,
    BatchResultItem,
    BatchResultsResponse,
    BulkUploadHistoryInfo,
    BulkUploadHistoryItemInfo,
    BulkUploadResponse,
    BulkUploadResultItem,
    BulkUploadStatus,
    CourierAccountDetail,
    CourierAccountInfo,
    CourierDeliveryStatus,
    CourierInfo,
    CreateEndpointResponse,
    DashboardStatsItem,
    DashboardStatsResponse,
    DashboardSummary,
    EndpointInfo,
    GetCouriersResponse,
    HistoryDetailResponse,
    ListEndpointsResponse,
    ListHistoriesResponse,
    ListSubscriptionsResponse,
    PrintSessionResponse,
    RegisterAccountResponse,
    RegisterItem,
    RegisterResponse,
    RotateSecretResponse,
    SubscriptionDetail,
    SubscriptionItem,
    SubscriptionListItem,
    TraceItem,
    TraceResponse,
    TraceResult,
    UnifiedTrackingResponse,
    WebhookPayload,
    WebhookSummary,
)
from ._webhook import WebhookSignatureError, verify_webhook_signature

__version__ = "1.3.1"

__all__ = [
    # Clients
    "DeliveryAPIClient",
    "AsyncDeliveryAPIClient",
    # Exceptions
    "ApiError",
    "AuthenticationError",
    "RateLimitError",
    "NotFoundError",
    # Webhook utils
    "verify_webhook_signature",
    "WebhookSignatureError",
    # Types — Tracking
    "CourierDeliveryStatus",
    "CourierInfo",
    "GetCouriersResponse",
    "TraceItem",
    "TraceResult",
    "TraceResponse",
    "UnifiedTrackingResponse",
    # Types — Webhooks
    "CreateEndpointResponse",
    "EndpointInfo",
    "ListEndpointsResponse",
    "RotateSecretResponse",
    "RegisterItem",
    "RegisterResponse",
    "ListSubscriptionsResponse",
    "SubscriptionListItem",
    "SubscriptionDetail",
    "SubscriptionItem",
    "BatchResultItem",
    "BatchResultsResponse",
    "WebhookPayload",
    "WebhookSummary",
    # Types — Courier Accounts
    "RegisterAccountResponse",
    "CourierAccountInfo",
    "CourierAccountDetail",
    # Types — Courier Deliveries
    "BulkUploadResultItem",
    "BulkUploadResponse",
    "AccountInquiryItem",
    "AccountInquiryResponse",
    "DashboardStatsItem",
    "DashboardStatsResponse",
    "DashboardSummary",
    # Types — Courier Histories
    "BulkUploadStatus",
    "BulkUploadHistoryItemInfo",
    "BulkUploadHistoryInfo",
    "ListHistoriesResponse",
    "HistoryDetailResponse",
    # Types — Courier Print
    "PrintSessionResponse",
]
