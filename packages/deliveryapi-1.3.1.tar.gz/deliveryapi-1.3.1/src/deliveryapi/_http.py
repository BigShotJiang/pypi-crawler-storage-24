"""HTTP client wrappers (sync and async) using httpx."""
from __future__ import annotations

from typing import Any

import httpx

from ._exceptions import ApiError, AuthenticationError, NotFoundError, RateLimitError

_BASE_URL = "https://api.deliveryapi.co.kr"
DEFAULT_TIMEOUT = 30.0
_SDK_VERSION = "1.3.1"


def _make_headers(api_key: str, secret_key: str) -> dict[str, str]:
    return {
        "Authorization": f"Bearer {api_key}:{secret_key}",
        "Content-Type": "application/json",
        "User-Agent": f"deliveryapi-python/{_SDK_VERSION}",
    }


def _parse_response(response: httpx.Response) -> Any:
    body: dict[str, Any] = response.json()

    if not body.get("isSuccess"):
        error_code: str = body.get("errorCode") or "INTERNAL_ERROR"
        message: str = body.get("error") or body.get("message") or f"HTTP {response.status_code}"
        status: int = body.get("statusCode") or response.status_code
        data = body.get("data")

        if error_code == "UNAUTHORIZED" or status == 401:
            raise AuthenticationError(message, data)
        if error_code == "NOT_FOUND" or status == 404:
            raise NotFoundError(message, data)
        if error_code == "RATE_LIMITED" or status == 429:
            raise RateLimitError(message, data)
        raise ApiError(error_code, message, status, data)

    return body.get("data")


# ---------------------------------------------------------------------------
# Sync client
# ---------------------------------------------------------------------------


class HttpClient:
    def __init__(self, api_key: str, secret_key: str, timeout: float) -> None:
        self._client = httpx.Client(
            base_url=_BASE_URL,
            headers=_make_headers(api_key, secret_key),
            timeout=timeout,
        )

    def get(self, path: str, params: dict[str, str] | None = None) -> Any:
        return _parse_response(self._client.get(path, params=params))

    def post(self, path: str, json: Any = None) -> Any:
        return _parse_response(self._client.post(path, json=json))

    def put(self, path: str, json: Any = None) -> Any:
        return _parse_response(self._client.put(path, json=json))

    def delete(self, path: str, *, params: dict[str, str] | None = None, json: Any = None) -> Any:
        return _parse_response(self._client.request("DELETE", path, params=params, json=json))

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> HttpClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


# ---------------------------------------------------------------------------
# Async client
# ---------------------------------------------------------------------------


class AsyncHttpClient:
    def __init__(self, api_key: str, secret_key: str, timeout: float) -> None:
        self._client = httpx.AsyncClient(
            base_url=_BASE_URL,
            headers=_make_headers(api_key, secret_key),
            timeout=timeout,
        )

    async def get(self, path: str, params: dict[str, str] | None = None) -> Any:
        return _parse_response(await self._client.get(path, params=params))

    async def post(self, path: str, json: Any = None) -> Any:
        return _parse_response(await self._client.post(path, json=json))

    async def put(self, path: str, json: Any = None) -> Any:
        return _parse_response(await self._client.put(path, json=json))

    async def delete(self, path: str, *, params: dict[str, str] | None = None, json: Any = None) -> Any:
        return _parse_response(await self._client.request("DELETE", path, params=params, json=json))

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> AsyncHttpClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.aclose()
