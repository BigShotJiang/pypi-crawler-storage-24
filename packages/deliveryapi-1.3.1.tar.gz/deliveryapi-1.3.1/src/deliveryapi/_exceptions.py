from __future__ import annotations


class ApiError(Exception):
    """Exception raised for DeliveryAPI errors.

    Attributes:
        code: Machine-readable error code (e.g. ``"RATE_LIMITED"``).
        status: HTTP status code.
        data: Additional error data (optional, depends on error type).

    Example::

        try:
            client.tracking.trace(items=[...])
        except ApiError as e:
            print(e.code)    # 'RATE_LIMITED'
            print(e.status)  # 429
            print(e)         # human-readable message
    """

    def __init__(self, code: str, message: str, status: int, data: object = None) -> None:
        super().__init__(message)
        self.code = code
        self.status = status
        self.data = data


class AuthenticationError(ApiError):
    def __init__(self, message: str = "Invalid API key or secret key", data: object = None) -> None:
        super().__init__("UNAUTHORIZED", message, 401, data)


class RateLimitError(ApiError):
    def __init__(self, message: str = "Rate limit exceeded", data: object = None) -> None:
        super().__init__("RATE_LIMITED", message, 429, data)


class NotFoundError(ApiError):
    def __init__(self, message: str = "Resource not found", data: object = None) -> None:
        super().__init__("NOT_FOUND", message, 404, data)
