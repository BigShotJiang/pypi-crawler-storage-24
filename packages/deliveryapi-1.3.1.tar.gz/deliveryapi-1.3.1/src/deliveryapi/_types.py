"""TypedDict definitions mirroring the Node.js SDK public types."""
from __future__ import annotations

from typing import Literal
from typing_extensions import NotRequired, TypedDict

# ---------------------------------------------------------------------------
# Courier Delivery Status
# ---------------------------------------------------------------------------

CourierDeliveryStatus = Literal[
    "PENDING",
    "REGISTERED",
    "PICKUP_READY",
    "PICKED_UP",
    "IN_TRANSIT",
    "OUT_FOR_DELIVERY",
    "DELIVERED",
    "FAILED",
    "RETURNED",
    "CANCELLED",
    "HOLD",
    "UNKNOWN",
]

# ---------------------------------------------------------------------------
# Tracking — get_couriers()
# ---------------------------------------------------------------------------


class CourierInfo(TypedDict):
    """Supported courier info returned by ``tracking.get_couriers()``."""

    trackingApiCode: str
    displayName: str


class GetCouriersResponse(TypedDict):
    """Response from ``tracking.get_couriers()``."""

    couriers: list[CourierInfo]
    total: int


# ---------------------------------------------------------------------------
# Tracking — trace()
# ---------------------------------------------------------------------------


class TraceItem(TypedDict):
    """Single item for ``tracking.trace()``."""

    courierCode: str
    trackingNumber: str
    clientId: NotRequired[str]


TrackingErrorCode = Literal[
    "MISSING_PARAMS",
    "INVALID_TRACKING_NUMBER",
    "UNSUPPORTED_COURIER",
    "NOT_FOUND",
    "TRACKING_FAILED",
]


class TrackingProgress(TypedDict):
    dateTime: str
    location: str
    status: str
    statusCode: NotRequired[CourierDeliveryStatus]
    description: NotRequired[str]
    telno: NotRequired[str]
    telno2: NotRequired[str]


class UnifiedTrackingResponse(TypedDict):
    trackingNumber: str
    courierCode: str
    courierName: str
    deliveryStatus: CourierDeliveryStatus
    deliveryStatusText: str
    isDelivered: bool
    senderName: NotRequired[str]
    receiverName: NotRequired[str]
    receiverAddress: NotRequired[str]
    productName: NotRequired[str]
    productQuantity: NotRequired[int]
    dateDelivered: NotRequired[str]
    dateEstimated: NotRequired[str]
    dateLastProgress: str
    progresses: list[TrackingProgress]
    queriedAt: str


class TraceItemError(TypedDict):
    code: TrackingErrorCode
    message: str
    courierCode: NotRequired[str]
    trackingNumber: NotRequired[str]
    billable: bool


class TraceCacheInfo(TypedDict):
    fromCache: bool
    cachedAt: NotRequired[str]


class TraceResult(TypedDict):
    """Per-item result in ``TraceResponse.results``."""

    success: bool
    clientId: NotRequired[str]
    data: NotRequired[UnifiedTrackingResponse]
    error: NotRequired[TraceItemError]
    cache: NotRequired[TraceCacheInfo]


class TraceSummary(TypedDict):
    total: int
    successful: int
    failed: int
    billable: int


class TraceResponse(TypedDict):
    """Response from ``tracking.trace()``."""

    results: list[TraceResult]
    summary: TraceSummary


# ---------------------------------------------------------------------------
# Webhooks — endpoints
# ---------------------------------------------------------------------------


class CreateEndpointResponse(TypedDict):
    """Response from ``webhooks.endpoints.create()``."""

    endpointId: str
    url: str
    name: NotRequired[str]
    webhookSecret: str
    dateCreated: str


class EndpointInfo(TypedDict):
    """Single item in ``ListEndpointsResponse.endpoints``."""

    endpointId: str
    url: str
    name: NotRequired[str]
    status: Literal["active", "inactive"]
    consecutiveFailures: int
    dateCreated: str
    dateModified: str


class ListEndpointsResponse(TypedDict):
    """Response from ``webhooks.endpoints.list()``."""

    endpoints: list[EndpointInfo]
    total: int


class RotateSecretResponse(TypedDict):
    """Response from ``webhooks.endpoints.rotate_secret()``."""

    endpointId: str
    webhookSecret: str
    dateRotated: str


# ---------------------------------------------------------------------------
# Webhooks — subscriptions
# ---------------------------------------------------------------------------


class RegisterItem(TypedDict):
    """Single item for ``webhooks.subscriptions.register()``."""

    courierCode: str
    trackingNumber: str
    clientId: NotRequired[str]


class RegisterResponse(TypedDict):
    """Response from ``webhooks.subscriptions.register()``."""

    requestId: str
    itemCount: int
    recurring: bool


class SubscriptionSummary(TypedDict):
    total: int
    delivered: int
    active: int
    failed: int


class SubscriptionListItem(TypedDict):
    requestId: str
    endpointId: NotRequired[str]
    recurring: bool
    isActive: bool
    itemCount: int
    summary: SubscriptionSummary
    dateCreated: str


class ListSubscriptionsResponse(TypedDict):
    """Response from ``webhooks.subscriptions.list()``."""

    subscriptions: list[SubscriptionListItem]
    total: int
    nextCursor: NotRequired[str]


class SubscriptionItem(TypedDict):
    courierCode: str
    trackingNumber: str
    clientId: NotRequired[str]
    currentStatus: CourierDeliveryStatus
    previousStatus: NotRequired[CourierDeliveryStatus]
    hasChanged: bool
    isDelivered: bool
    trackingData: NotRequired[UnifiedTrackingResponse]
    error: NotRequired[str]


class SubscriptionDetail(TypedDict):
    """Response from ``webhooks.subscriptions.get()``."""

    requestId: str
    endpointId: NotRequired[str]
    recurring: bool
    isActive: bool
    itemCount: int
    summary: SubscriptionSummary
    items: list[SubscriptionItem]
    lastPolledAt: NotRequired[str]
    nextPollAt: NotRequired[str]
    metadata: NotRequired[dict[str, str]]
    dateCreated: str
    dateModified: str


class BatchResultItem(TypedDict):
    """Single item for ``webhooks.subscriptions.batch_results()``."""

    courierCode: str
    trackingNumber: str


class BatchResultEntry(TypedDict):
    courierCode: str
    trackingNumber: str
    clientId: NotRequired[str]
    requestId: str
    currentStatus: CourierDeliveryStatus
    isDelivered: bool
    trackingData: NotRequired[UnifiedTrackingResponse]
    error: NotRequired[str]
    lastPolledAt: NotRequired[str]


class BatchResultsResponse(TypedDict):
    """Response from ``webhooks.subscriptions.batch_results()``."""

    results: list[BatchResultEntry]
    total: int


# ---------------------------------------------------------------------------
# Webhook Payload (received by the user's endpoint)
# ---------------------------------------------------------------------------


class WebhookSummary(TypedDict):
    """Summary block inside ``WebhookPayload``."""

    total: int
    delivered: int
    active: int
    hasChanges: bool


class WebhookPayload(TypedDict):
    """Webhook POST payload delivered to the registered endpoint."""

    event: Literal["tracking.polled", "tracking.completed"]
    requestId: str
    metadata: NotRequired[dict[str, str]]
    items: list[SubscriptionItem]
    summary: WebhookSummary
    timestamp: str


# ---------------------------------------------------------------------------
# Courier Accounts
# ---------------------------------------------------------------------------


class RegisterAccountResponse(TypedDict):
    """Response from ``courier.accounts.register()``."""

    courierAccountKey: str
    providerId: str
    accountId: str
    accountName: str
    isActive: bool
    requires2FA: bool


class CourierAccountInfo(TypedDict):
    """Account info returned in ``courier.accounts.list()``."""

    courierAccountKey: str
    providerId: str
    accountId: str
    accountName: str
    description: str
    isActive: bool
    requires2FA: bool
    smsAutoCapture: bool
    lastInquiryDate: NotRequired[str]
    dateCreated: NotRequired[str]
    expiresAt: NotRequired[str]


class CourierAccountDetail(TypedDict):
    """Account detail from ``courier.accounts.get()``."""

    courierAccountKey: str
    providerId: str
    accountId: str
    accountName: str
    description: str
    isActive: bool
    requires2FA: bool
    smsAutoCapture: bool
    lastInquiryDate: NotRequired[str]
    dateCreated: NotRequired[str]
    accountPassword: str


# ---------------------------------------------------------------------------
# Courier Bulk Upload
# ---------------------------------------------------------------------------


class BulkUploadResultItem(TypedDict):
    """Individual item result in ``BulkUploadResponse.results``."""

    requestIndex: int
    success: bool
    message: str
    trackingNumber: NotRequired[str]
    courierDeliveryId: NotRequired[str]
    clientOrderId: NotRequired[str]
    quantityOriginal: int
    quantityUploaded: int
    skipped: bool
    skipReason: NotRequired[str]
    deliveryItem: NotRequired[dict[str, object]]
    courierMetadata: NotRequired[dict[str, str]]


class BulkUploadResponse(TypedDict):
    """Response from ``courier.deliveries.bulk_upload()``."""

    success: bool
    historyId: str
    totalRequested: int
    totalUploaded: int
    totalSkipped: int
    totalFailed: int
    results: list[BulkUploadResultItem]
    fileAcptOdrNo: NotRequired[str]
    acptDt: NotRequired[str]
    warning: NotRequired[str]


# ---------------------------------------------------------------------------
# Courier Delivery Inquiry
# ---------------------------------------------------------------------------


class DeliveryAddress(TypedDict):
    """Delivery address info."""

    fullAddress: str
    zipCode: NotRequired[str]
    roadAddress: NotRequired[str]
    jibunAddress: NotRequired[str]
    detailAddress: NotRequired[str]


class DeliveryPerson(TypedDict):
    """Delivery person info."""

    name: str
    phoneNumber: NotRequired[str]
    branchName: NotRequired[str]
    branchCode: NotRequired[str]
    branchPhone: NotRequired[str]


class FareInfo(TypedDict):
    """Fare info."""

    fareType: str
    fareTypeCode: NotRequired[str]


class InquirySummary(TypedDict):
    """Summary in ``AccountInquiryResponse``."""

    total: int
    pending: int
    inTransit: int
    delivered: int
    cancelled: int
    returned: int


class InquiryCourierInfo(TypedDict):
    """Courier info in ``AccountInquiryResponse``."""

    courierCode: str
    courierName: str
    accountId: str


class AccountInquiryItem(TypedDict):
    """Individual delivery item from ``courier.deliveries.inquiry()``."""

    courierTrackingId: str
    trackingNumber: str
    orderNumber: NotRequired[str]
    courierCode: str
    courierName: str
    deliveryStatus: CourierDeliveryStatus
    deliveryStatusText: str
    isDelivered: bool
    cancelReason: NotRequired[str]
    isReturn: NotRequired[bool]
    returnType: NotRequired[str]
    originalTrackingNumber: NotRequired[str]
    senderName: str
    senderPhone: NotRequired[str]
    senderPhone2: NotRequired[str]
    senderAddress: NotRequired[DeliveryAddress]
    receiverName: str
    receiverPhone: str
    receiverPhone2: NotRequired[str]
    receiverAddress: DeliveryAddress
    productName: str
    productQuantity: int
    productDetails: NotRequired[str]
    productOption: NotRequired[str]
    deliveryMessage: NotRequired[str]
    pickupDate: NotRequired[str]
    firstScanDate: NotRequired[str]
    deliveryDate: NotRequired[str]
    estimatedDeliveryDate: NotRequired[str]
    pickupBranch: NotRequired[DeliveryPerson]
    deliveryBranch: NotRequired[DeliveryPerson]
    pickupPerson: NotRequired[DeliveryPerson]
    deliveryPerson: NotRequired[DeliveryPerson]
    fareInfo: NotRequired[FareInfo]
    accountCustomerCode: NotRequired[str]
    accountCustomerName: NotRequired[str]
    pickupCustomerCode: NotRequired[str]
    pickupCustomerName: NotRequired[str]
    queriedAt: str
    rawData: NotRequired[dict[str, object]]


class AccountInquiryResponse(TypedDict):
    """Response from ``courier.deliveries.inquiry()``."""

    items: list[AccountInquiryItem]
    summary: InquirySummary
    dateRange: dict[str, str]
    courierInfo: InquiryCourierInfo
    lastUpdated: str


# ---------------------------------------------------------------------------
# Courier Dashboard
# ---------------------------------------------------------------------------


class DashboardStatsItem(TypedDict):
    """Individual stats row from ``courier.deliveries.dashboard()``."""

    totCnt: int
    prtCnt: int
    nonPrtCnt: int
    pickCnt: int
    pickCclCnt: int
    outCnt: int
    nonOutCnt: int
    arvCnt: int
    nonArvCnt: int
    dlvcpCnt: int
    nonDlvCnt: int
    invRgstCnt: int
    nonInvRgstCnt: int
    dlvbCnt: int
    pcadCnt: int
    stbhCnt: int
    pickYmd: NotRequired[str]
    fstmIstrYmd: NotRequired[str]
    ustRtgSctCd: NotRequired[str]
    ustRtgSctNm: str
    ustRtgSct: NotRequired[str]
    jobCustCd: NotRequired[str]
    jobCustNm: str
    pickYmdGrouping: int
    ustRtgSctCdGrouping: int
    ustRtgSctNmGrouping: int
    jobCustCdGrouping: int
    jobCustNmGrouping: int


class DashboardSummary(TypedDict):
    """Summary stats from ``courier.deliveries.dashboard()``."""

    totalCount: int
    pending: int
    inTransit: int
    delivered: int
    problem: int


class DashboardStatsResponse(TypedDict):
    """Response from ``courier.deliveries.dashboard()``."""

    items: list[DashboardStatsItem]
    summary: DashboardSummary
    dateRange: dict[str, str]
    lastUpdated: str


# ---------------------------------------------------------------------------
# Courier Bulk Upload Histories
# ---------------------------------------------------------------------------

BulkUploadStatus = Literal["transmitting", "completed", "failed", "deleted"]


class BulkUploadHistoryItemInfo(TypedDict):
    """Individual item in a bulk upload history."""

    requestIndex: int
    clientOrderId: str
    receiverName: str
    productName: str
    success: bool
    message: str
    trackingNumber: NotRequired[str]
    courierDeliveryId: NotRequired[str]
    datePrinted: NotRequired[str]


class BulkUploadHistoryInfo(TypedDict):
    """Bulk upload history record."""

    id: str
    courierAccountKey: str
    providerId: str
    status: BulkUploadStatus
    totalCount: int
    successCount: int
    failCount: int
    items: list[BulkUploadHistoryItemInfo]
    fileAcptOdrNo: NotRequired[str]
    lastRsrvMgrNo: NotRequired[str]
    dateCreated: NotRequired[str]
    dateModified: NotRequired[str]


class ListHistoriesResponse(TypedDict):
    """Response from ``courier.deliveries.histories.list()``."""

    histories: list[BulkUploadHistoryInfo]


class HistoryDetailResponse(TypedDict):
    """Response from ``courier.deliveries.histories.get()``."""

    history: BulkUploadHistoryInfo
    detailItems: list[AccountInquiryItem]


# ---------------------------------------------------------------------------
# Courier Print Sessions
# ---------------------------------------------------------------------------


class PrintSessionResponse(TypedDict):
    """Response from ``courier.print.create_session()``."""

    sessionId: str
    expiresAt: str


# ---------------------------------------------------------------------------
# Type aliases for convenience
# ---------------------------------------------------------------------------

CourierListResult = GetCouriersResponse
