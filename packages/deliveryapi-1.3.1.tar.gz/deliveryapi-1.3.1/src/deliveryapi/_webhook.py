"""Webhook signature verification utility.

The server signs webhooks with HMAC-SHA256 over "{timestamp}.{json_body}"
and sends the result as the ``X-Webhook-Signature`` header prefixed with
``sha256=``.

Example (Flask)::

    from deliveryapi import verify_webhook_signature, WebhookSignatureError

    @app.route("/webhook", methods=["POST"])
    def handle_webhook():
        try:
            verify_webhook_signature(
                payload=request.get_data(as_text=True),
                signature=request.headers["X-Webhook-Signature"],
                timestamp=request.headers["X-Webhook-Timestamp"],
                secret="whsec_...",
            )
        except WebhookSignatureError:
            return "Invalid signature", 400

        data = request.json
        ...

Example (FastAPI)::

    from fastapi import Request
    from deliveryapi import verify_webhook_signature, WebhookSignatureError

    @app.post("/webhook")
    async def handle_webhook(request: Request):
        body = await request.body()
        try:
            verify_webhook_signature(
                payload=body.decode(),
                signature=request.headers["X-Webhook-Signature"],
                timestamp=request.headers["X-Webhook-Timestamp"],
                secret="whsec_...",
            )
        except WebhookSignatureError:
            return Response(status_code=400)
        ...
"""
from __future__ import annotations

import hashlib
import hmac
import time


class WebhookSignatureError(Exception):
    """Raised when webhook signature verification fails."""


def verify_webhook_signature(
    *,
    payload: str,
    signature: str,
    timestamp: str,
    secret: str,
    tolerance_seconds: int = 300,
) -> None:
    """Verify an incoming DeliveryAPI webhook signature.

    Args:
        payload: The raw request body as a string (do NOT parse JSON first).
        signature: Value of the ``X-Webhook-Signature`` header.
        timestamp: Value of the ``X-Webhook-Timestamp`` header.
        secret: Your webhook endpoint's secret (``whsec_...`` value).
        tolerance_seconds: Max allowed clock skew in seconds (default: 300).

    Raises:
        WebhookSignatureError: If the signature is invalid or the timestamp
            is outside the tolerance window.
    """
    try:
        ts = int(timestamp)
    except (ValueError, TypeError):
        raise WebhookSignatureError("Invalid timestamp format")

    now = int(time.time())
    if abs(now - ts) > tolerance_seconds:
        raise WebhookSignatureError(
            f"Webhook timestamp {ts} is outside the tolerance window "
            f"of {tolerance_seconds}s"
        )

    # Mirror server logic: signed_payload = "{timestamp}.{json_body}"
    signed_payload = f"{timestamp}.{payload}"
    expected_sig = hmac.new(
        secret.encode(),
        signed_payload.encode(),
        hashlib.sha256,
    ).hexdigest()

    received_sig = signature.removeprefix("sha256=")

    if not hmac.compare_digest(expected_sig, received_sig):
        raise WebhookSignatureError("Webhook signature verification failed")
