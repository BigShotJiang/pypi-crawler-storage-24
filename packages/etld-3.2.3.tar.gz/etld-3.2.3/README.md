# ETL-D SDK: The Agentic Data & Finance Middleware
Stop wasting LLM context windows and tokens on basic data parsing and complex financial logic. ETL-D is a stateless, deterministic middleware designed specifically for AI Agents, No-Code automation (n8n, Make), and high-performance integrations. We handle chaotic global data and B2B financial pipelines using algorithmic parsing with an LLM-Routing Fallback to guarantee 100% accuracy and perfect JSON schemas.

🚀 The Arsenal (Available Endpoints)
ETL-D goes far beyond basic string manipulation. Your AI agents gain instant access to:

- **B2B Parsing**: Transform raw Norma 43 (N43) bank statements and complex nested XMLs into flat, queryable JSONs.
- **Financial Operations**: Generate SEPA Direct Debit (PAIN.008) XMLs, fetch historical Forex rates, and autonomously map messy transactions to GAAP/PGC accounting codes.
- **Data Engineering Magic**: Generate E-commerce Cartesian product variants, normalize physical measurement units, and intelligently split chaotic contact strings.
- **Core Enrichment**: E.164 phone validation, ISO 8601 relative date parsing (timezone-aware), and global address structuring with LLM-fallback for complex regions (e.g., UAE, Japan).

🤖 The Agentic Workflow (Autonomous Billing)
ETL-D V1.0+ introduces features strictly designed for autonomous systems that handle their own billing lifecycles.

### 1. Zero-Touch Agent Provisioning
If your AI agent is booting up for the first time and lacks an API key, it can provision one programmatically. No emails, no logins.

```python
import etld_sdk
from etld_sdk.api import system_api

configuration = etld_sdk.Configuration(host="https://api.etl-d.net")

with etld_sdk.ApiClient(configuration) as api_client:
    api_instance = system_api.SystemApi(api_client)
    # Provision a new session
    provision = api_instance.provision_agent_v1_system_billing_provision_post()
    print(f"Pay here: {provision.checkout_url}")

    # Poll for the key
    status = api_instance.get_provision_status_v1_system_billing_provision_poll_id_get(provision.poll_id)
    if status.status == "ready":
        print(f"Your API Key: {status.api_key}")
```

### 2. Handling 402 Payment Required
When an agent exhausts its credits, the API returns a HTTP 402. The SDK intercepts this and raises a `PaymentRequiredError` (or similar depending on generated names) containing a `checkout_url`. The agent can autonomously navigate to the URL, pay for a top-up, and resume execution.

```python
import etld_sdk
from etld_sdk.rest import ApiException

try:
    # Your API call here
    api_instance.enrich_date_v1_enrich_date_post(date_input)
except ApiException as e:
    if e.status == 402:
        # Extract checkout_url from response body
        import json
        error_data = json.loads(e.body)
        checkout_url = error_data.get("checkout_url")
        print(f"Credits exhausted. Top up at: {checkout_url}")
```

⚡ Async Batch Processing
Process 10,000+ records without blocking your server. Queue the batch, and the SDK automatically polls the background worker until the job is done.

```python
from etld_sdk.api import async_batch_api
from etld_sdk.models.batch_input import BatchInput

batch_api = async_batch_api.AsyncBatchApi(api_client)
batch_input = BatchInput(items=["next Tuesday", "27/10/2023"])

task = batch_api.create_batch_task_v1_enrich_batch_entity_type_post(
    entity_type="date",
    batch_input=batch_input
)
print(f"Task ID: {task.task_id}")
```

## Installation
```bash
pip install etld
```
