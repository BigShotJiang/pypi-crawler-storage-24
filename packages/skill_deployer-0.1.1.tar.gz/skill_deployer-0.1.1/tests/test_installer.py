"""Tests for skill_deployer.installer."""

import tempfile
from pathlib import Path

from skill_deployer.detector import Platform
from skill_deployer.installer import install_skill, uninstall_skill, list_installed

FIXTURES = Path(__file__).parent / "fixtures"


def _make_platform(tmpdir):
    skills_dir = Path(tmpdir) / "skills"
    skills_dir.mkdir()
    return Platform(name="Test", skills_dir=skills_dir, has_cli=False)


def test_install_valid_skill():
    with tempfile.TemporaryDirectory() as tmpdir:
        platform = _make_platform(tmpdir)
        results = install_skill(FIXTURES / "valid-skill", [platform])
        assert len(results) == 1
        assert results[0].success
        assert (platform.skills_dir / "test-skill" / "SKILL.md").exists()
        assert (platform.skills_dir / "test-skill" / ".skill-deployer-meta.json").exists()


def test_install_refuses_overwrite_without_force():
    with tempfile.TemporaryDirectory() as tmpdir:
        platform = _make_platform(tmpdir)
        install_skill(FIXTURES / "valid-skill", [platform])
        results = install_skill(FIXTURES / "valid-skill", [platform])
        assert not results[0].success
        assert "Already exists" in results[0].message


def test_install_force_overwrite():
    with tempfile.TemporaryDirectory() as tmpdir:
        platform = _make_platform(tmpdir)
        install_skill(FIXTURES / "valid-skill", [platform])
        results = install_skill(FIXTURES / "valid-skill", [platform], force=True)
        assert results[0].success


def test_install_invalid_skill():
    with tempfile.TemporaryDirectory() as tmpdir:
        platform = _make_platform(tmpdir)
        results = install_skill(FIXTURES / "invalid-skill", [platform])
        assert not results[0].success


def test_uninstall_managed_skill():
    with tempfile.TemporaryDirectory() as tmpdir:
        platform = _make_platform(tmpdir)
        install_skill(FIXTURES / "valid-skill", [platform])
        results = uninstall_skill("test-skill", [platform])
        assert results[0].success
        assert not (platform.skills_dir / "test-skill").exists()


def test_uninstall_unmanaged_refuses():
    with tempfile.TemporaryDirectory() as tmpdir:
        platform = _make_platform(tmpdir)
        # Manually create a skill dir (not managed)
        (platform.skills_dir / "manual-skill").mkdir()
        results = uninstall_skill("manual-skill", [platform])
        assert not results[0].success
        assert "not installed by" in results[0].message.lower()


def test_uninstall_not_found():
    with tempfile.TemporaryDirectory() as tmpdir:
        platform = _make_platform(tmpdir)
        results = uninstall_skill("nonexistent", [platform])
        assert not results[0].success


def test_list_installed():
    with tempfile.TemporaryDirectory() as tmpdir:
        platform = _make_platform(tmpdir)
        install_skill(FIXTURES / "valid-skill", [platform])
        installed = list_installed(platform)
        assert len(installed) == 1
        assert installed[0][0] == "test-skill"
        assert installed[0][1] is True  # managed
