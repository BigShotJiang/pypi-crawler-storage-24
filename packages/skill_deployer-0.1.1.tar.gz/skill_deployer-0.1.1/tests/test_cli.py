"""Tests for skill_deployer.cli."""

import subprocess
import sys


def test_help_exit_code():
    result = subprocess.run(
        [sys.executable, "-m", "skill_deployer.cli", "--help"],
        capture_output=True, text=True,
    )
    assert result.returncode == 0
    assert "skill-deployer" in result.stdout


def test_version():
    result = subprocess.run(
        [sys.executable, "-m", "skill_deployer.cli", "--version"],
        capture_output=True, text=True,
    )
    assert result.returncode == 0
    assert "0.1.0" in result.stdout


def test_status_runs():
    result = subprocess.run(
        [sys.executable, "-m", "skill_deployer.cli", "status"],
        capture_output=True, text=True,
    )
    # Should succeed if any CLI is detected, or return 1 if none
    assert result.returncode in (0, 1)
