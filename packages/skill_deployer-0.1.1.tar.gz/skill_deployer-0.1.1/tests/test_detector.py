"""Tests for skill_deployer.detector."""

from skill_deployer.detector import detect_claude, detect_codex, detect_all


def test_detect_all_returns_list():
    result = detect_all()
    assert isinstance(result, list)


def test_detect_claude_returns_platform_or_none():
    result = detect_claude()
    if result is not None:
        assert result.name == "Claude Code"
        assert result.skills_dir is not None


def test_detect_codex_returns_platform_or_none():
    result = detect_codex()
    if result is not None:
        assert result.name == "Codex"
        assert result.skills_dir is not None
