"""Tests for skill_deployer.validator."""

import tempfile
from pathlib import Path

from skill_deployer.validator import parse_frontmatter, validate_skill, get_skill_name

FIXTURES = Path(__file__).parent / "fixtures"


def test_parse_valid_frontmatter():
    text = '---\nname: my-skill\ndescription: Does stuff\n---\n# Content'
    fm = parse_frontmatter(text)
    assert fm is not None
    assert fm["name"] == "my-skill"
    assert fm["description"] == "Does stuff"


def test_parse_quoted_values():
    text = '---\nname: "quoted-name"\ndescription: \'single quoted\'\n---\n'
    fm = parse_frontmatter(text)
    assert fm["name"] == "quoted-name"
    assert fm["description"] == "single quoted"


def test_parse_boolean_values():
    text = '---\nname: test\ndescription: test\nuser-invocable: false\n---\n'
    fm = parse_frontmatter(text)
    assert fm["user-invocable"] is False


def test_parse_no_frontmatter():
    assert parse_frontmatter("# Just markdown") is None


def test_parse_no_closing_delimiter():
    assert parse_frontmatter("---\nname: test\n") is None


def test_parse_empty_frontmatter():
    assert parse_frontmatter("---\n---\n") is None


def test_validate_valid_skill():
    valid, msg = validate_skill(FIXTURES / "valid-skill")
    assert valid
    assert "test-skill" in msg


def test_validate_missing_skill_md():
    valid, msg = validate_skill(FIXTURES / "invalid-skill")
    assert not valid
    assert "No SKILL.md" in msg


def test_validate_not_a_directory():
    valid, msg = validate_skill(FIXTURES / "valid-skill" / "SKILL.md")
    assert not valid
    assert "Not a directory" in msg


def test_validate_missing_fields():
    with tempfile.TemporaryDirectory() as tmpdir:
        p = Path(tmpdir) / "SKILL.md"
        p.write_text("---\nname: test\n---\n")
        valid, msg = validate_skill(tmpdir)
        assert not valid
        assert "description" in msg


def test_get_skill_name_from_frontmatter():
    name = get_skill_name(FIXTURES / "valid-skill")
    assert name == "test-skill"


def test_get_skill_name_fallback():
    with tempfile.TemporaryDirectory() as tmpdir:
        name = get_skill_name(tmpdir)
        assert name == Path(tmpdir).name
