# skill-deployer

Install AI coding CLI skills to **Claude Code** and **Codex** with one command.

Both platforms use the same skill format (`SKILL.md` + optional `references/` and `scripts/` directories) but store them in different locations and register MCP servers differently. This tool bridges that gap.

## Install

```bash
pip install skill-deployer
```

## Usage

### Check detected platforms

```bash
skill-deployer status
```

### Install skills

```bash
# Install all bundled skills to all detected platforms
skill-deployer install

# Install a specific bundled skill
skill-deployer install my-skill-name

# Install from a GitHub URL
skill-deployer install https://github.com/user/repo/tree/main/skills/my-skill

# Install from a local directory
skill-deployer install ./path/to/skill

# Target a specific platform
skill-deployer install --claude
skill-deployer install --codex

# Overwrite existing skills
skill-deployer install --force
```

### List skills

```bash
# List skills installed on detected platforms
skill-deployer list

# List bundled skills available in this package
skill-deployer list --bundled
```

### Uninstall skills

```bash
skill-deployer uninstall my-skill-name
```

### Register MCP servers

Register an MCP server on both Claude Code and Codex in one command:

```bash
skill-deployer mcp picocalc picocalc-mcp
skill-deployer mcp picocalc python3 /path/to/mcp_server.py
```

This writes to `.mcp.json` for Claude Code and runs `codex mcp add` for Codex.

## How it works

| | Claude Code | Codex |
|---|---|---|
| Skills dir | `~/.claude/skills/` | `~/.codex/skills/` |
| Skill format | `SKILL.md` (YAML frontmatter) | `SKILL.md` (YAML frontmatter) |
| MCP config | `.mcp.json` in project root | `codex mcp add` command |

`skill-deployer` detects which platforms are installed, copies skill directories to the right location, and handles MCP registration for each platform's config format.

## For skill authors

Bundle your skills in the package by adding them to `src/skill_deployer/_skills/` and updating `manifest.json`:

```json
{
  "skills": [
    {
      "name": "my-skill",
      "version": "1.0.0",
      "description": "What my skill does"
    }
  ]
}
```

Each skill directory needs a `SKILL.md` with YAML frontmatter:

```yaml
---
name: my-skill
description: Trigger description for the AI assistant
---

# Skill content here
```

## Requirements

- Python 3.9+
- Zero runtime dependencies (stdlib only)

## License

MIT
