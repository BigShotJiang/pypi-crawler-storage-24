"""skill-deployer -- Install AI coding CLI skills to Claude Code and Codex."""

__version__ = "0.1.1"
