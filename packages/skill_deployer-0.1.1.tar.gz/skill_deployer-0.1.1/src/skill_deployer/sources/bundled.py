"""Resolve skills bundled in the package."""

from ..manifest import get_bundled_skill_path, list_bundled_names


def resolve(name):
    """Resolve a bundled skill by name. Returns path or None."""
    return get_bundled_skill_path(name)


def list_all():
    """Return all bundled skill names."""
    return list_bundled_names()
