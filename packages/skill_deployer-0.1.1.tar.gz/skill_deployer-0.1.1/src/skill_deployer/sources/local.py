"""Resolve skills from local directories."""

from pathlib import Path

from ..validator import validate_skill


def resolve(path_str):
    """Resolve a local directory as a skill source.

    Returns (path, None) on success or (None, error_message) on failure.
    """
    path = Path(path_str).resolve()
    if not path.exists():
        return None, f"Path does not exist: {path}"
    if not path.is_dir():
        return None, f"Not a directory: {path}"

    valid, msg = validate_skill(path)
    if not valid:
        return None, msg

    return path, None
