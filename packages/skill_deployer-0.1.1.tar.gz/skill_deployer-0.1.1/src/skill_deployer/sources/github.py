"""Fetch skills from GitHub URLs."""

import io
import json
import os
import shutil
import tempfile
import urllib.request
import zipfile
from pathlib import Path

from ..validator import validate_skill


def _parse_github_url(url):
    """Parse a GitHub tree or blob URL.

    Returns (owner, repo, branch, path) or None.
    """
    # https://github.com/owner/repo/tree/branch/path/to/skill
    # https://github.com/owner/repo/blob/branch/path/to/SKILL.md
    url = url.rstrip("/")
    if not url.startswith("https://github.com/"):
        return None

    parts = url.replace("https://github.com/", "").split("/")
    if len(parts) < 4:
        return None

    owner = parts[0]
    repo = parts[1]
    kind = parts[2]  # tree or blob
    branch = parts[3]
    path = "/".join(parts[4:]) if len(parts) > 4 else ""

    if kind not in ("tree", "blob"):
        return None

    # If blob URL points to SKILL.md, walk up to parent dir
    if kind == "blob" and path.endswith((".md", ".MD")):
        path = "/".join(path.split("/")[:-1])

    return owner, repo, branch, path


def _download_zip(owner, repo, branch):
    """Download repo as zip, return bytes."""
    url = f"https://codeload.github.com/{owner}/{repo}/zip/{branch}"
    headers = {}
    token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    if token:
        headers["Authorization"] = f"token {token}"

    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=30) as resp:
        return resp.read()


def _try_gh_api(owner, repo, branch, path):
    """Try using gh CLI to download files. Returns temp dir path or None."""
    if not shutil.which("gh"):
        return None

    import subprocess

    tmpdir = tempfile.mkdtemp(prefix="skill-deployer-")
    try:
        # Get recursive tree
        result = subprocess.run(
            ["gh", "api", f"repos/{owner}/{repo}/git/trees/{branch}",
             "-q", f'.tree[] | select(.path | startswith("{path}/")) | select(.type=="blob") | .path'],
            capture_output=True, text=True, timeout=30,
        )
        if result.returncode != 0:
            shutil.rmtree(tmpdir, ignore_errors=True)
            return None

        files = [f for f in result.stdout.strip().split("\n") if f]
        if not files:
            shutil.rmtree(tmpdir, ignore_errors=True)
            return None

        for fpath in files:
            rel = fpath[len(path):].lstrip("/")
            dest = Path(tmpdir) / rel
            dest.parent.mkdir(parents=True, exist_ok=True)

            dl = subprocess.run(
                ["gh", "api", f"repos/{owner}/{repo}/contents/{fpath}",
                 "-q", ".content"],
                capture_output=True, text=True, timeout=15,
            )
            if dl.returncode == 0:
                import base64
                content = base64.b64decode(dl.stdout.strip())
                dest.write_bytes(content)

        return tmpdir
    except Exception:
        shutil.rmtree(tmpdir, ignore_errors=True)
        return None


def resolve(url):
    """Resolve a GitHub URL to a local temp directory containing the skill.

    Returns (path, None) on success or (None, error_message) on failure.
    Caller is responsible for cleaning up the temp dir.
    """
    parsed = _parse_github_url(url)
    if parsed is None:
        return None, f"Could not parse GitHub URL: {url}"

    owner, repo, branch, path = parsed
    skill_name = path.split("/")[-1] if path else repo

    # Try gh CLI first (handles private repos)
    tmpdir = _try_gh_api(owner, repo, branch, path)
    if tmpdir:
        valid, msg = validate_skill(tmpdir)
        if valid:
            return Path(tmpdir), None
        shutil.rmtree(tmpdir, ignore_errors=True)

    # Fall back to zip download (public repos)
    try:
        zip_bytes = _download_zip(owner, repo, branch)
    except Exception as e:
        return None, f"Failed to download from GitHub: {e}"

    tmpdir = tempfile.mkdtemp(prefix="skill-deployer-")
    try:
        zf = zipfile.ZipFile(io.BytesIO(zip_bytes))
        # Zip root is usually "{repo}-{branch}/"
        prefix = None
        for name in zf.namelist():
            if prefix is None:
                prefix = name.split("/")[0]
            # Extract only files under the target path
            full_prefix = f"{prefix}/{path}/" if path else f"{prefix}/"
            if name.startswith(full_prefix) and not name.endswith("/"):
                rel = name[len(full_prefix):]
                dest = Path(tmpdir) / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(zf.read(name))

        valid, msg = validate_skill(tmpdir)
        if valid:
            return Path(tmpdir), None

        shutil.rmtree(tmpdir, ignore_errors=True)
        return None, f"Downloaded content is not a valid skill: {msg}"

    except Exception as e:
        shutil.rmtree(tmpdir, ignore_errors=True)
        return None, f"Failed to extract skill from zip: {e}"


def is_github_url(source):
    """Check if a source string looks like a GitHub URL."""
    return source.startswith("https://github.com/")
