"""Detect installed AI coding CLIs (Claude Code, Codex)."""

import os
import shutil
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Platform:
    name: str
    skills_dir: Path
    has_cli: bool

    def __str__(self):
        status = "installed" if self.has_cli else "dir only"
        return f"{self.name} ({status}) -> {self.skills_dir}"


def detect_claude():
    """Detect Claude Code installation."""
    skills_dir = Path.home() / ".claude" / "skills"
    has_cli = shutil.which("claude") is not None
    if skills_dir.exists() or has_cli:
        return Platform(
            name="Claude Code",
            skills_dir=skills_dir,
            has_cli=has_cli,
        )
    return None


def detect_codex():
    """Detect Codex installation."""
    codex_home = os.environ.get("CODEX_HOME")
    if codex_home:
        skills_dir = Path(codex_home) / "skills"
    else:
        skills_dir = Path.home() / ".codex" / "skills"
    has_cli = shutil.which("codex") is not None
    if skills_dir.exists() or has_cli:
        return Platform(
            name="Codex",
            skills_dir=skills_dir,
            has_cli=has_cli,
        )
    return None


def detect_all():
    """Return list of all detected platforms."""
    platforms = []
    claude = detect_claude()
    if claude:
        platforms.append(claude)
    codex = detect_codex()
    if codex:
        platforms.append(codex)
    return platforms
