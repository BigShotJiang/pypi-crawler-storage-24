"""Load and query the bundled skills manifest."""

import json
from importlib import resources
from dataclasses import dataclass
from pathlib import Path


@dataclass
class SkillEntry:
    name: str
    version: str
    description: str


def _skills_root():
    """Return path to the _skills package data directory."""
    return resources.files("skill_deployer") / "_skills"


def load_manifest():
    """Load manifest.json and return list of SkillEntry."""
    manifest_path = _skills_root() / "manifest.json"
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    return [
        SkillEntry(
            name=s["name"],
            version=s.get("version", "0.0.0"),
            description=s.get("description", ""),
        )
        for s in data.get("skills", [])
    ]


def get_bundled_skill_path(name):
    """Return path to a bundled skill directory, or None if not found."""
    skill_dir = _skills_root() / name
    # importlib.resources returns a Traversable; check it exists
    try:
        if skill_dir.is_dir():
            return Path(str(skill_dir))
    except (TypeError, FileNotFoundError):
        pass
    return None


def list_bundled_names():
    """Return list of bundled skill names."""
    return [s.name for s in load_manifest()]
