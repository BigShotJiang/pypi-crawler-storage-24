"""Core install/uninstall logic for skills."""

import json
import shutil
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from .validator import validate_skill, get_skill_name


META_FILE = ".skill-deployer-meta.json"


@dataclass
class InstallResult:
    platform: str
    skill_name: str
    success: bool
    message: str


def _write_meta(dest, skill_name, version="0.0.0"):
    """Write tracking metadata alongside installed skill."""
    meta = {
        "installed_by": "skill-deployer",
        "skill_name": skill_name,
        "version": version,
        "installed_at": datetime.now(timezone.utc).isoformat(),
    }
    meta_path = dest / META_FILE
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")


def _is_managed(skill_dir):
    """Check if a skill was installed by skill-deployer."""
    return (skill_dir / META_FILE).exists()


def install_skill(source_path, platforms, force=False, version="0.0.0"):
    """Install a skill from source_path to all target platforms.

    Returns list of InstallResult.
    """
    source_path = Path(source_path)
    valid, msg = validate_skill(source_path)
    if not valid:
        return [InstallResult("all", "", False, msg)]

    skill_name = get_skill_name(source_path)
    results = []

    for platform in platforms:
        dest = platform.skills_dir / skill_name

        if dest.exists() and not force:
            results.append(InstallResult(
                platform.name, skill_name, False,
                f"Already exists (use --force to overwrite): {dest}",
            ))
            continue

        try:
            platform.skills_dir.mkdir(parents=True, exist_ok=True)
            if dest.exists():
                shutil.rmtree(dest)
            shutil.copytree(source_path, dest)
            _write_meta(dest, skill_name, version)
            results.append(InstallResult(
                platform.name, skill_name, True,
                f"Installed to {dest}",
            ))
        except Exception as e:
            results.append(InstallResult(
                platform.name, skill_name, False, str(e),
            ))

    return results


def uninstall_skill(skill_name, platforms, force=False):
    """Remove a skill from target platforms.

    Returns list of InstallResult.
    """
    results = []

    for platform in platforms:
        dest = platform.skills_dir / skill_name

        if not dest.exists():
            results.append(InstallResult(
                platform.name, skill_name, False, "Not installed",
            ))
            continue

        if not _is_managed(dest) and not force:
            results.append(InstallResult(
                platform.name, skill_name, False,
                "Not installed by skill-deployer (use --force to remove anyway)",
            ))
            continue

        try:
            shutil.rmtree(dest)
            results.append(InstallResult(
                platform.name, skill_name, True, "Removed",
            ))
        except Exception as e:
            results.append(InstallResult(
                platform.name, skill_name, False, str(e),
            ))

    return results


def list_installed(platform):
    """List skills installed on a platform. Returns list of (name, managed, version)."""
    skills_dir = platform.skills_dir
    if not skills_dir.exists():
        return []

    installed = []
    for child in sorted(skills_dir.iterdir()):
        if not child.is_dir() or child.name.startswith("."):
            continue
        managed = _is_managed(child)
        version = None
        if managed:
            try:
                meta = json.loads((child / META_FILE).read_text(encoding="utf-8"))
                version = meta.get("version")
            except Exception:
                pass
        installed.append((child.name, managed, version))

    return installed
