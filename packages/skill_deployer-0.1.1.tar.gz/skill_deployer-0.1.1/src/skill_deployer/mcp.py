"""Register MCP servers on Claude Code and Codex."""

import json
import shutil
import subprocess
from pathlib import Path


def _register_claude(name, command, args, project_dir=None):
    """Register MCP server in Claude Code's .mcp.json."""
    if project_dir:
        mcp_path = Path(project_dir) / ".mcp.json"
    else:
        mcp_path = Path.cwd() / ".mcp.json"

    # Read existing config
    config = {}
    if mcp_path.exists():
        try:
            config = json.loads(mcp_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass

    servers = config.setdefault("mcpServers", {})

    # Build server entry
    entry = {"command": command}
    if args:
        entry["args"] = args

    if name in servers and servers[name] == entry:
        return True, f"Already configured in {mcp_path}"

    servers[name] = entry
    mcp_path.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
    return True, f"Added to {mcp_path}"


def _register_codex(name, command, args):
    """Register MCP server in Codex via codex mcp add."""
    if not shutil.which("codex"):
        return False, "Codex CLI not found in PATH"

    cmd = ["codex", "mcp", "add", name, "--", command] + list(args)
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        if result.returncode == 0:
            return True, f"Registered via: {' '.join(cmd)}"
        return False, f"codex mcp add failed: {result.stderr.strip()}"
    except Exception as e:
        return False, str(e)


def register_mcp(name, command, args, platforms, project_dir=None):
    """Register MCP server on all target platforms.

    Returns list of (platform_name, success, message).
    """
    results = []

    for platform in platforms:
        if platform.name == "Claude Code":
            ok, msg = _register_claude(name, command, args, project_dir)
            results.append(("Claude Code", ok, msg))
        elif platform.name == "Codex":
            ok, msg = _register_codex(name, command, args)
            results.append(("Codex", ok, msg))

    return results
