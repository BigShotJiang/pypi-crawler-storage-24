"""CLI entry point for skill-deployer."""

import argparse
import shutil
import sys
from pathlib import Path

from . import __version__
from .detector import detect_all, detect_claude, detect_codex
from .installer import install_skill, uninstall_skill, list_installed
from .manifest import load_manifest
from .sources import bundled, local
from .sources.github import is_github_url, resolve as github_resolve


def _resolve_platforms(args):
    """Determine target platforms from CLI flags."""
    if getattr(args, "claude", False) and not getattr(args, "codex", False):
        p = detect_claude()
        return [p] if p else []
    if getattr(args, "codex", False) and not getattr(args, "claude", False):
        p = detect_codex()
        return [p] if p else []
    return detect_all()


def _resolve_source(source):
    """Resolve a source string to (path, is_temp, error).

    is_temp=True means caller should clean up the path.
    """
    if source is None:
        return None, False, None

    # GitHub URL
    if is_github_url(source):
        path, err = github_resolve(source)
        if err:
            return None, False, err
        return path, True, None

    # Local directory
    local_path = Path(source)
    if local_path.exists():
        path, err = local.resolve(source)
        if err:
            return None, False, err
        return path, False, None

    # Bundled skill name
    path = bundled.resolve(source)
    if path:
        return path, False, None

    return None, False, f"Not found: {source} (not a bundled skill, local path, or GitHub URL)"


def cmd_install(args):
    platforms = _resolve_platforms(args)
    if not platforms:
        print("No supported platforms detected.")
        print("Install Claude Code or Codex first.")
        return 1

    force = getattr(args, "force", False)

    # Install all bundled skills
    if args.all or args.source is None:
        manifest = load_manifest()
        if not manifest:
            print("No bundled skills in this package.")
            return 1

        any_fail = False
        for entry in manifest:
            path = bundled.resolve(entry.name)
            if not path:
                print(f"  SKIP  {entry.name} (bundled path missing)")
                continue
            results = install_skill(path, platforms, force=force, version=entry.version)
            for r in results:
                icon = "OK" if r.success else "FAIL"
                print(f"  {icon:4}  {r.skill_name} -> {r.platform}: {r.message}")
                if not r.success:
                    any_fail = True
        return 1 if any_fail else 0

    # Install single skill
    source_path, is_temp, err = _resolve_source(args.source)
    if err:
        print(f"Error: {err}")
        return 1

    try:
        results = install_skill(source_path, platforms, force=force)
        for r in results:
            icon = "OK" if r.success else "FAIL"
            print(f"  {icon:4}  {r.skill_name} -> {r.platform}: {r.message}")
        return 0 if all(r.success for r in results) else 1
    finally:
        if is_temp and source_path:
            shutil.rmtree(source_path, ignore_errors=True)


def cmd_uninstall(args):
    platforms = _resolve_platforms(args)
    if not platforms:
        print("No supported platforms detected.")
        return 1

    force = getattr(args, "force", False)
    results = uninstall_skill(args.name, platforms, force=force)
    for r in results:
        icon = "OK" if r.success else "FAIL"
        print(f"  {icon:4}  {r.skill_name} -> {r.platform}: {r.message}")
    return 0 if all(r.success for r in results) else 1


def cmd_list(args):
    if getattr(args, "bundled", False):
        manifest = load_manifest()
        if not manifest:
            print("No bundled skills.")
            return 0
        print("Bundled skills:")
        for entry in manifest:
            print(f"  {entry.name:30s} v{entry.version:8s} {entry.description}")
        return 0

    # Default: list installed
    platforms = detect_all()
    if not platforms:
        print("No supported platforms detected.")
        return 1

    for platform in platforms:
        installed = list_installed(platform)
        print(f"\n{platform.name} ({platform.skills_dir}):")
        if not installed:
            print("  (none)")
            continue
        for name, managed, version in installed:
            marker = "*" if managed else " "
            ver = f"v{version}" if version else "      "
            print(f"  {marker} {name:30s} {ver}")
    print("\n  * = installed by skill-deployer")
    return 0


def cmd_status(args):
    platforms = detect_all()
    if not platforms:
        print("No AI coding CLIs detected.")
        print("Supported: Claude Code, Codex")
        return 1

    print("Detected platforms:")
    for p in platforms:
        cli_status = "CLI found" if p.has_cli else "no CLI in PATH"
        print(f"  {p.name:15s} {cli_status:15s} {p.skills_dir}")
    return 0


def cmd_mcp(args):
    from .mcp import register_mcp
    platforms = _resolve_platforms(args)
    if not platforms:
        print("No supported platforms detected.")
        return 1

    project_dir = getattr(args, "project", None)
    results = register_mcp(
        args.name, args.cmd, args.args,
        platforms=platforms,
        project_dir=project_dir,
    )
    for platform_name, success, msg in results:
        icon = "OK" if success else "FAIL"
        print(f"  {icon:4}  {platform_name}: {msg}")
    return 0 if all(s for _, s, _ in results) else 1


def main():
    parser = argparse.ArgumentParser(
        prog="skill-deployer",
        description="Install AI coding CLI skills to Claude Code and Codex",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command")

    # install
    p_install = sub.add_parser("install", help="Install skills")
    p_install.add_argument("source", nargs="?", default=None,
        help="Bundled skill name, GitHub URL, or local path (omit for all bundled)")
    p_install.add_argument("--claude", action="store_true", help="Claude Code only")
    p_install.add_argument("--codex", action="store_true", help="Codex only")
    p_install.add_argument("--all", action="store_true", help="Install all bundled skills")
    p_install.add_argument("--force", action="store_true", help="Overwrite existing")

    # uninstall
    p_uninstall = sub.add_parser("uninstall", help="Remove a skill")
    p_uninstall.add_argument("name", help="Skill name")
    p_uninstall.add_argument("--claude", action="store_true")
    p_uninstall.add_argument("--codex", action="store_true")
    p_uninstall.add_argument("--force", action="store_true", help="Remove even if not managed")

    # list
    p_list = sub.add_parser("list", help="List skills")
    p_list.add_argument("--bundled", action="store_true", help="Show bundled skills")

    # status
    sub.add_parser("status", help="Show detected platforms")

    # mcp
    p_mcp = sub.add_parser("mcp", help="Register MCP server on both platforms")
    p_mcp.add_argument("name", help="Server name (e.g. picocalc)")
    p_mcp.add_argument("cmd", help="Command to run (e.g. picocalc-mcp)")
    p_mcp.add_argument("args", nargs="*", default=[], help="Command arguments")
    p_mcp.add_argument("--claude", action="store_true")
    p_mcp.add_argument("--codex", action="store_true")
    p_mcp.add_argument("--project", default=None, help="Project dir for .mcp.json (default: cwd)")

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        return 0

    handlers = {
        "install": cmd_install,
        "uninstall": cmd_uninstall,
        "list": cmd_list,
        "status": cmd_status,
        "mcp": cmd_mcp,
    }

    return handlers[args.command](args)


if __name__ == "__main__":
    sys.exit(main() or 0)
