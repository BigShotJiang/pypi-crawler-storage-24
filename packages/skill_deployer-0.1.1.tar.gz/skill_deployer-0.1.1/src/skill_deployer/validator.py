"""Validate skill directories and parse SKILL.md frontmatter."""

from pathlib import Path


def parse_frontmatter(text):
    """Parse YAML frontmatter from SKILL.md content.

    Returns dict with name, description, and optional fields.
    Returns None if frontmatter is missing or malformed.
    """
    text = text.strip()
    if not text.startswith("---"):
        return None

    end = text.find("---", 3)
    if end == -1:
        return None

    block = text[3:end].strip()
    result = {}
    for line in block.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        colon = line.find(":")
        if colon == -1:
            continue
        key = line[:colon].strip()
        val = line[colon + 1:].strip()
        # Strip quotes
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        # Handle booleans
        if val.lower() == "true":
            val = True
        elif val.lower() == "false":
            val = False
        result[key] = val

    return result if result else None


def validate_skill(path):
    """Validate a skill directory.

    Returns (is_valid, message) tuple.
    """
    path = Path(path)

    if not path.is_dir():
        return False, f"Not a directory: {path}"

    # Check for SKILL.md (case-insensitive)
    skill_md = None
    for name in ("SKILL.md", "skill.md"):
        candidate = path / name
        if candidate.exists():
            skill_md = candidate
            break

    if skill_md is None:
        return False, f"No SKILL.md found in {path}"

    text = skill_md.read_text(encoding="utf-8")
    fm = parse_frontmatter(text)

    if fm is None:
        return False, f"Missing or invalid frontmatter in {skill_md.name}"

    if "name" not in fm:
        return False, "Frontmatter missing 'name' field"

    if "description" not in fm:
        return False, "Frontmatter missing 'description' field"

    return True, f"Valid skill: {fm['name']}"


def get_skill_name(path):
    """Extract skill name from SKILL.md frontmatter, or fall back to dir name."""
    path = Path(path)
    for name in ("SKILL.md", "skill.md"):
        candidate = path / name
        if candidate.exists():
            fm = parse_frontmatter(candidate.read_text(encoding="utf-8"))
            if fm and "name" in fm:
                return fm["name"]
    return path.name
