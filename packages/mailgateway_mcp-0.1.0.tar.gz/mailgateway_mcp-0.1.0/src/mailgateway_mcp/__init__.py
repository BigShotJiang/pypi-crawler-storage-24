"""MailGateway MCP server package."""
