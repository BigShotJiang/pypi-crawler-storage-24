"""pypaginate test suite."""
