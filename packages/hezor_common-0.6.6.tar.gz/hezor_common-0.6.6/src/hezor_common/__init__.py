"""Hezor Common - Common utilities for Hezor projects."""

__version__ = "0.6.6"


def hello() -> str:
    """Return a greeting message."""
    return "Hello from hezor-common!"


__all__ = ["__version__", "hello"]
