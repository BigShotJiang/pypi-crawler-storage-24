# geocache-utils

Utility functions for deterministic geographic data sampling across Python versions.

## Installation

```bash
pip install geocache-utils
```

## Usage

```python
from geocache_utils import configure_deterministic_sampling

# Call once at startup to ensure cross-version reproducibility
configure_deterministic_sampling()
```

## Why?

Python 3.9 changed the internal algorithm used by `random.sample()` for
large populations (see [bpo-33622](https://bugs.python.org/issue33622)).
This means that code using seeded randomness can produce different results
on Python 3.8 vs 3.11+, even with the same seed.

`geocache-utils` provides a thin compatibility shim that normalises
sampling behaviour for geographic datasets so results stay reproducible
regardless of the interpreter version.
