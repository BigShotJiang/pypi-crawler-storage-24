"""Geocache utilities for deterministic cross-platform data sampling."""

__version__ = "0.2.1"

from geocache_utils.compat import configure_deterministic_sampling

__all__ = ["configure_deterministic_sampling"]
