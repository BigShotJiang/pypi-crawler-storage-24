from __future__ import annotations

import httpx

DEFAULT_TIMEOUT = httpx.Timeout(timeout=300.0, connect=5.0)
DEFAULT_MAX_RETRIES = 2
DEFAULT_POLL_INTERVAL = 2.0
DEFAULT_POLL_TIMEOUT = 600.0
DEFAULT_BASE_URL = "https://api.ponyflash.com/v1"

RETRYABLE_STATUS_CODES = frozenset({408, 409, 429, 500, 502, 503, 504})
