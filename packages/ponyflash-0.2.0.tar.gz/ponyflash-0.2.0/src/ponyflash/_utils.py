from __future__ import annotations

from typing import Any, Mapping


def deepcopy_minimal(item: Any) -> Any:
    """Shallow-deep copy: only recurse into dicts and lists."""
    if isinstance(item, dict):
        return {k: deepcopy_minimal(v) for k, v in item.items()}
    if isinstance(item, list):
        return [deepcopy_minimal(entry) for entry in item]
    return item


def strip_not_given(d: dict[str, Any]) -> dict[str, Any]:
    from ._types import is_given

    return {k: v for k, v in d.items() if is_given(v)}
