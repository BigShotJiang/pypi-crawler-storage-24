from __future__ import annotations


class ComposeError(Exception):
    """Base exception for all editor/compose errors."""


class FFmpegNotFoundError(ComposeError):
    """Raised when neither system ffmpeg nor static-ffmpeg is available."""

    def __init__(self) -> None:
        super().__init__(
            "ffmpeg not found. Install it via your system package manager, "
            "or run: pip install ponyflash[editor]"
        )


class FFprobeNotFoundError(ComposeError):
    """Raised when ffprobe is not available."""

    def __init__(self) -> None:
        super().__init__(
            "ffprobe not found. It is usually bundled with ffmpeg. "
            "Install ffmpeg or run: pip install ponyflash[editor]"
        )


class ProbeError(ComposeError):
    """Raised when ffprobe fails to inspect a media file."""

    def __init__(self, source: str, detail: str = "") -> None:
        msg = f"Failed to probe media: {source}"
        if detail:
            msg += f" — {detail}"
        super().__init__(msg)
        self.source = source


class RenderError(ComposeError):
    """Raised when an ffmpeg render command fails."""

    stderr: str | None

    def __init__(self, message: str, stderr: str | None = None) -> None:
        super().__init__(message)
        self.stderr = stderr


class ClipOverlapError(ComposeError):
    """Raised when clips on the same track overlap in time."""

    def __init__(self, track_index: int, clip_a: str, clip_b: str) -> None:
        super().__init__(
            f"Clips overlap on track {track_index}: "
            f"{clip_a} and {clip_b}. "
            "Use separate tracks for layered content."
        )


class ValidationError(ComposeError):
    """Raised for invalid parameter combinations detected before render."""
