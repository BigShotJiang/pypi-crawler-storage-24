"""PonyFlash Editor — local video composition powered by FFmpeg.

A VideoDB-style 4-layer architecture (Asset → Clip → Track → Timeline)
for programmatic video editing with 60+ xfade transitions, fit modes,
text overlays, and multi-format output.

Quick start::

    from ponyflash.editor import Timeline, Track, Clip, VideoAsset, Transition

    intro = VideoAsset("intro.mp4")
    main  = VideoAsset("main.mp4")

    track = Track()
    track.add_clip(0, Clip(asset=intro, duration=5))
    track.add_clip(5, Clip(asset=main, duration=8), transition=Transition.DISSOLVE)

    timeline = Timeline(aspect_ratio="16:9")
    timeline.add_track(track)
    timeline.render("output.mp4", resolution="1080p")
"""
from __future__ import annotations

from ._asset import AudioAsset, ImageAsset, TextAsset, VideoAsset
from ._clip import Clip
from ._errors import (
    ClipOverlapError,
    ComposeError,
    FFmpegNotFoundError,
    FFprobeNotFoundError,
    ProbeError,
    RenderError,
    ValidationError,
)
from ._timeline import Timeline
from ._track import Track
from ._transition import Transition, XFade
from ._types import AspectRatio, CropGravity, Fit, Position

__all__ = [
    # Core objects
    "Timeline",
    "Track",
    "Clip",
    # Assets
    "VideoAsset",
    "AudioAsset",
    "ImageAsset",
    "TextAsset",
    # Enums
    "Fit",
    "Position",
    "CropGravity",
    "AspectRatio",
    "Transition",
    "XFade",
    # Errors
    "ComposeError",
    "FFmpegNotFoundError",
    "FFprobeNotFoundError",
    "ProbeError",
    "RenderError",
    "ClipOverlapError",
    "ValidationError",
]
