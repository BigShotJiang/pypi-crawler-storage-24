from __future__ import annotations

from enum import Enum


class Fit(str, Enum):
    """How a clip scales to fill the canvas. Mirrors CSS object-fit semantics."""

    COVER = "cover"
    """Scale up to fill canvas, crop overflow (like CSS object-fit: cover)."""

    CONTAIN = "contain"
    """Scale to fit entirely within canvas, show background on empty space."""

    FILL = "fill"
    """Stretch to fill canvas exactly, may distort aspect ratio."""

    NONE = "none"
    """Use native pixel dimensions, centered on canvas."""


class CropGravity(str, Enum):
    """Which part to keep when cropping in COVER mode."""

    CENTER = "center"
    TOP = "top"
    BOTTOM = "bottom"
    LEFT = "left"
    RIGHT = "right"


class Position(str, Enum):
    """9-zone anchor for clip placement (used by overlays and text)."""

    TOP_LEFT = "top_left"
    TOP = "top"
    TOP_RIGHT = "top_right"
    CENTER_LEFT = "center_left"
    CENTER = "center"
    CENTER_RIGHT = "center_right"
    BOTTOM_LEFT = "bottom_left"
    BOTTOM = "bottom"
    BOTTOM_RIGHT = "bottom_right"


# Pre-computed overlay x:y expressions for each position
POSITION_OVERLAY_XY: dict[Position, tuple[str, str]] = {
    Position.TOP_LEFT: ("0", "0"),
    Position.TOP: ("(W-w)/2", "0"),
    Position.TOP_RIGHT: ("W-w", "0"),
    Position.CENTER_LEFT: ("0", "(H-h)/2"),
    Position.CENTER: ("(W-w)/2", "(H-h)/2"),
    Position.CENTER_RIGHT: ("W-w", "(H-h)/2"),
    Position.BOTTOM_LEFT: ("0", "H-h"),
    Position.BOTTOM: ("(W-w)/2", "H-h"),
    Position.BOTTOM_RIGHT: ("W-w", "H-h"),
}

# drawtext uses lowercase w/h for video size, text_w/text_h for text size
POSITION_DRAWTEXT_XY: dict[Position, tuple[str, str]] = {
    Position.TOP_LEFT: ("20", "20"),
    Position.TOP: ("(w-text_w)/2", "20"),
    Position.TOP_RIGHT: ("w-text_w-20", "20"),
    Position.CENTER_LEFT: ("20", "(h-text_h)/2"),
    Position.CENTER: ("(w-text_w)/2", "(h-text_h)/2"),
    Position.CENTER_RIGHT: ("w-text_w-20", "(h-text_h)/2"),
    Position.BOTTOM_LEFT: ("20", "h-text_h-20"),
    Position.BOTTOM: ("(w-text_w)/2", "h-text_h-20"),
    Position.BOTTOM_RIGHT: ("w-text_w-20", "h-text_h-20"),
}


class AspectRatio(str, Enum):
    """Common aspect ratio presets."""

    LANDSCAPE_16_9 = "16:9"
    PORTRAIT_9_16 = "9:16"
    SQUARE_1_1 = "1:1"
    LANDSCAPE_4_3 = "4:3"
    PORTRAIT_3_4 = "3:4"
    ULTRAWIDE_21_9 = "21:9"


def parse_aspect_ratio(value: str | AspectRatio) -> tuple[int, int]:
    """Parse an aspect ratio string like ``"16:9"`` into (w_ratio, h_ratio)."""
    s = value.value if isinstance(value, AspectRatio) else value
    parts = s.split(":")
    if len(parts) != 2:
        raise ValueError(f"Invalid aspect ratio format: {value!r}. Expected 'W:H'.")
    try:
        w, h = int(parts[0]), int(parts[1])
    except ValueError:
        raise ValueError(f"Aspect ratio components must be integers: {value!r}")
    if w <= 0 or h <= 0:
        raise ValueError(f"Aspect ratio components must be positive: {value!r}")
    return w, h
