from __future__ import annotations

from typing import Any, Optional, Type

from .._models import FinalRequestOptions
from .._resource import AsyncAPIResource, SyncAPIResource
from .._types import NOT_GIVEN, NotGiven, is_given
from .._utils import strip_not_given
from ..pagination import AsyncPage, SyncPage
from ..types.model_detail import ModelDetail
from ..types.model_info import ModelInfo


class Models(SyncAPIResource):
    def list(
        self,
        *,
        page: int | NotGiven = NOT_GIVEN,
        page_size: int | NotGiven = NOT_GIVEN,
        type: str | NotGiven = NOT_GIVEN,
    ) -> SyncPage[ModelInfo]:
        params = strip_not_given({"page": page, "pageSize": page_size, "type": type})
        opts = FinalRequestOptions(method="GET", url="/listmodels", params=params or None)
        return self._get_api_list(
            "/listmodels",
            page=SyncPage[ModelInfo],
            model=ModelInfo,
            options=opts,
        )

    def get(self, model_id: str) -> ModelDetail:
        if not model_id:
            raise ValueError(f"Expected a non-empty value for `model_id` but received {model_id!r}")
        return self._get(f"/models/{model_id}", cast_to=ModelDetail)


class AsyncModels(AsyncAPIResource):
    async def list(
        self,
        *,
        page: int | NotGiven = NOT_GIVEN,
        page_size: int | NotGiven = NOT_GIVEN,
        type: str | NotGiven = NOT_GIVEN,
    ) -> AsyncPage[ModelInfo]:
        params = strip_not_given({"page": page, "pageSize": page_size, "type": type})
        opts = FinalRequestOptions(method="GET", url="/listmodels", params=params or None)
        return await self._get_api_list(
            "/listmodels",
            page=AsyncPage[ModelInfo],
            model=ModelInfo,
            options=opts,
        )

    async def get(self, model_id: str) -> ModelDetail:
        if not model_id:
            raise ValueError(f"Expected a non-empty value for `model_id` but received {model_id!r}")
        return await self._get(f"/models/{model_id}", cast_to=ModelDetail)
