from __future__ import annotations

from .._resource import AsyncAPIResource, SyncAPIResource
from .._types import NOT_GIVEN, NotGiven
from .._utils import strip_not_given
from ..types.credit_balance import CreditBalance
from ..types.recharge_response import RechargeResponse


class Account(SyncAPIResource):
    def credits(self) -> CreditBalance:
        return self._get("/account/credits", cast_to=CreditBalance)

    def recharge(
        self,
        *,
        amount: int | NotGiven = NOT_GIVEN,
        redirect_url: str | NotGiven = NOT_GIVEN,
    ) -> RechargeResponse:
        body = strip_not_given({"amount": amount, "redirect_url": redirect_url})
        return self._post("/account/recharge", cast_to=RechargeResponse, body=body or None)


class AsyncAccount(AsyncAPIResource):
    async def credits(self) -> CreditBalance:
        return await self._get("/account/credits", cast_to=CreditBalance)

    async def recharge(
        self,
        *,
        amount: int | NotGiven = NOT_GIVEN,
        redirect_url: str | NotGiven = NOT_GIVEN,
    ) -> RechargeResponse:
        body = strip_not_given({"amount": amount, "redirect_url": redirect_url})
        return await self._post("/account/recharge", cast_to=RechargeResponse, body=body or None)
