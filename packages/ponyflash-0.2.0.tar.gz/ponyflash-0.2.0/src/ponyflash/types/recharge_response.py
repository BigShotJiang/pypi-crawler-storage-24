from __future__ import annotations

from pydantic import Field

from .._models import BaseModel


class RechargeResponse(BaseModel):
    recharge_url: str = Field(alias="rechargeUrl")
    expires_at: str | None = Field(default=None, alias="expiresAt")
    purchase_id: str | None = Field(default=None, alias="purchaseId")
    status: str | None = None
