from __future__ import annotations

from typing import List, Optional

from typing_extensions import Required, TypedDict

from .._types import FileInput, NotGiven


class ImageGenerateParams(TypedDict, total=False):
    model: Required[str]
    prompt: Required[str]
    resolution: str
    aspect_ratio: str
    size: str
    n: int
    quality: str
    output_format: str
    reference_images: List[FileInput]
    mask: FileInput
    context: str
