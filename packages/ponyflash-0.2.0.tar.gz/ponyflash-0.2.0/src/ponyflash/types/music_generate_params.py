from __future__ import annotations

from typing_extensions import Required, TypedDict

from .._types import FileInput


class MusicGenerateParams(TypedDict, total=False):
    model: Required[str]
    prompt: Required[str]
    lyrics: str
    title: str
    style: str
    duration: int
    instrumental: bool
    reference_audio: FileInput
    continue_at: float
    format: str
    quality: str
