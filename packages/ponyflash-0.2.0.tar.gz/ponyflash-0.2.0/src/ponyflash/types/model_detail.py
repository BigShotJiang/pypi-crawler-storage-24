from __future__ import annotations

from typing import List, Optional

from pydantic import Field

from .._models import BaseModel


class SupportedMode(BaseModel):
    name: str
    description: Optional[str] = None
    required_fields: List[str] = Field(default=[], alias="requiredFields")
    optional_fields: List[str] = Field(default=[], alias="optionalFields")


class ModelLimits(BaseModel):
    max_prompt_length: Optional[int] = Field(default=None, alias="maxPromptLength")
    max_images: Optional[int] = Field(default=None, alias="maxImages")
    max_file_size_mb: Optional[int] = Field(default=None, alias="maxFileSizeMb")


class ModelPricing(BaseModel):
    unit: str
    credits: int


class ModelDetail(BaseModel):
    id: str
    type: str
    name: Optional[str] = None
    description: Optional[str] = None
    input: List[str] = []
    output: List[str] = []
    supported_sizes: List[str] = Field(default=[], alias="supportedSizes")
    supported_durations: List[int] = Field(default=[], alias="supportedDurations")
    supported_qualities: List[str] = Field(default=[], alias="supportedQualities")
    supported_output_formats: List[str] = Field(default=[], alias="supportedOutputFormats")
    supported_modes: List[SupportedMode] = Field(default=[], alias="supportedModes")
    limits: Optional[ModelLimits] = None
    pricing: Optional[ModelPricing] = None
