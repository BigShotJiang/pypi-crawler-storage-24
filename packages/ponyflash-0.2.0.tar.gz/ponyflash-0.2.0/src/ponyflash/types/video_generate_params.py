from __future__ import annotations

from typing import List, Optional

from typing_extensions import Required, TypedDict

from .._types import FileInput


class VideoGenerateParams(TypedDict, total=False):
    model: Required[str]
    prompt: str
    size: str
    duration: int
    quality: str
    first_frame: FileInput
    last_frame: FileInput
    video: FileInput
    audio: FileInput
    reference_images: List[FileInput]
    motion_video: FileInput
    resolution: str
    aspect_ratio: str
    generate_audio: bool
    negative_prompt: str
