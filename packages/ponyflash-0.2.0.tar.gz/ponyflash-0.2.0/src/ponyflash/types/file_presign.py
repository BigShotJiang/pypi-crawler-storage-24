from __future__ import annotations

from typing import Dict, Optional

from pydantic import Field

from .._models import BaseModel


class PresignResponse(BaseModel):
    file_id: str = Field(alias="fileId")
    upload_url: str = Field(alias="uploadUrl")
    expires_at: str = Field(alias="expiresAt")
    method: str = "PUT"
    headers: Dict[str, str] = {}
