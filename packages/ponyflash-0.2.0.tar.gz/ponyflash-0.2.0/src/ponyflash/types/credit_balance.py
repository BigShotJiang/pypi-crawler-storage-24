from __future__ import annotations

from pydantic import Field

from .._models import BaseModel


class CreditBalance(BaseModel):
    balance: int
    currency: str = "credits"
    updated_at: str | None = Field(default=None, alias="updatedAt")
