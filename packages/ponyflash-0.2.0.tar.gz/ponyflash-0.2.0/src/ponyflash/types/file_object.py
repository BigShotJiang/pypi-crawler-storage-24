from __future__ import annotations

from typing import Optional

from pydantic import Field

from .._models import BaseModel


class FileObject(BaseModel):
    """Represents an uploaded file in PonyFlash storage."""

    file_id: str = Field(alias="fileId")
    filename: str
    content_type: str = Field(alias="contentType")
    size: int
    status: str
    created_at: str = Field(alias="createdAt")
    expires_at: Optional[str] = Field(default=None, alias="expiresAt")
