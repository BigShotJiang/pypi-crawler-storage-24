from __future__ import annotations

from typing import Optional

from pydantic import Field

from .._models import BaseModel


class CreateResponse(BaseModel):
    request_id: str = Field(alias="requestId")
    estimated_credits: Optional[int] = Field(default=None, alias="estimatedCredits")
