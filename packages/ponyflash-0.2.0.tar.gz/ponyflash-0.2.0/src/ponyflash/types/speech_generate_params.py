from __future__ import annotations

from typing import Optional

from typing_extensions import Required, TypedDict


class VoiceSettings(TypedDict, total=False):
    stability: float
    similarity_boost: float
    style: float
    use_speaker_boost: bool


class SpeechGenerateParams(TypedDict, total=False):
    model: Required[str]
    input: Required[str]
    voice: Required[str]
    language: str
    speed: float
    pitch: int
    emotion: str
    instructions: str
    voice_settings: VoiceSettings
    sample_rate: int
    format: str
