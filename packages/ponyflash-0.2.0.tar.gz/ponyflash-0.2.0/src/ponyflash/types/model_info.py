from __future__ import annotations

from typing import Dict, List, Optional

from pydantic import Field

from .._models import BaseModel


class ModelPricing(BaseModel):
    unit: str
    credits: int


class ModelInfo(BaseModel):
    id: str
    type: str
    input: List[str] = []
    output: List[str] = []
    supported_sizes: List[str] = Field(default=[], alias="supportedSizes")
    supported_durations: List[int] = Field(default=[], alias="supportedDurations")
    supported_qualities: List[str] = Field(default=[], alias="supportedQualities")
    supported_output_formats: List[str] = Field(default=[], alias="supportedOutputFormats")
    pricing: Optional[ModelPricing] = None
