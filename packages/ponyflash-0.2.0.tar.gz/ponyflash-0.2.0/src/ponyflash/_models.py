from __future__ import annotations

from typing import Any, Optional

import pydantic
from pydantic import ConfigDict


class BaseModel(pydantic.BaseModel):
    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class FinalRequestOptions(pydantic.BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    method: str
    url: str
    json_data: Any = None
    files: Any = None
    headers: dict[str, str] | None = None
    params: dict[str, object] | None = None
    timeout: Any = None
    max_retries: int | None = None
