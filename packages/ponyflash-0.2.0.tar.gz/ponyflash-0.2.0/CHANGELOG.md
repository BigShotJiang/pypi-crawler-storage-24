# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2026-03-11

### Added

- **`ponyflash.editor` — 本地视频合成模块**
  - VideoDB 风格 4 层架构：Asset → Clip → Track → Timeline
  - `VideoAsset` / `AudioAsset` / `ImageAsset` / `TextAsset`：支持本地文件和 URL
  - `Clip`：展示层，支持 fit mode（cover/contain/fill/none）、position（9 宫格）、scale、opacity、volume、speed、mute
  - `Track`：无 type 通用轨道，`add_clip(start, clip)` VideoDB 兼容签名
  - `Timeline`：顶层画布，`add_track()` 组装，`render()` 本地渲染
  - 58 种 FFmpeg xfade 转场（fade/dissolve/wipe/slide/radial/pixelize 等）
  - Clip 级别淡入淡出 + Track 级别 xfade 两层转场模型
  - `crop_gravity` 控制 COVER 模式裁剪位置（center/top/bottom/left/right）
  - 文字叠层：fontsize、color、box、stroke、fade_in/fade_out 动画
  - 多格式输出：MP4(H.264)、MP4(H.265)、WebM(VP9)、MOV(ProRes)、GIF
  - 分辨率预设（360p ~ 4k）+ 自定义 WxH + aspect_ratio 自动计算
  - FFmpeg 自动发现（系统 PATH → static-ffmpeg fallback）
  - URL 素材自动下载 + 缓存 + 清理
  - 渲染进度回调
  - `pyproject.toml` 新增 `editor` optional extra（`pip install ponyflash[editor]`）

## [0.1.2] - 2026-03-10

### Changed
- 默认 API base URL 切换至 `https://api.ponyflash.com/v1`

## [0.1.0] - 2026-03-09

### Added

- Initial release of PonyFlash Python SDK
- Sync (`PonyFlash`) and async (`AsyncPonyFlash`) client
- Image generation: text-to-image, image-to-image, multi-image, inpainting with mask
- Video generation: text-to-video, first-frame, first+last-frame, OmniHuman (portrait+audio), Motion Transfer (portrait+motion_video), multi-image reference, video remix
- Audio generation: text-to-audio
- Unified polling with `generate()` (blocking) and `submit()` (non-blocking)
- File uploads via presigned URL (Tencent Cloud COS)
- Unified `FileInput` supporting local paths, bytes, URLs, and file_ids
- Cursor-based pagination for model listing
- Model detail retrieval with supported modes and limits
- Account credits query and recharge link
- Custom exception hierarchy with automatic retry on transient errors
- PEP 561 `py.typed` marker for type checker support
