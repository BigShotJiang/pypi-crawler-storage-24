# AskUI Agent OS Deliveries

This repository contains the delivery pipelines and assets for **AskUI Agent OS** and **AskUI Suite Installers**. Use it to build, release, and publish installers and the Agent OS Python package.

---

## Overview

You can use this repo in two main ways:

| Delivery type | What it does | How to trigger |
|---------------|--------------|----------------|
| **Suite Installer** | Build and release AskUI Suite Installers (Web/Full) for Windows, macOS, and Linux | Create a **GitHub Release** with a version tag, or run the **Build Suite Installer** workflow manually |
| **Agent OS** | Publish the Agent OS Python package to PyPI and build Windows service installers (AMD64/ARM64) | Run the **Release Agent OS** workflow manually and provide a version |

---

## Suite Installer releases

### Version and tag format

- **Stable:** `26.2.1` (semver: `YY.MINOR.PATCH`)
- **Release candidate:** `26.2.1.1` (e.g. `26.2.1.1` = rc1 for 26.2.1)

### Option A: Release from a GitHub Release

1. In this repo, go to **Releases** → **Draft a new release**.
2. Create a **tag** with the version (e.g. `26.2.1` or `26.2.1.1`).
3. Publish the release.

Publishing the release triggers **Build Suite Installer** and builds installers for:

- Windows (AMD64): Web, Full  
- Windows (ARM64): Web  
- macOS (ARM64): Web  
- Linux (AMD64, ARM64): Web  

Installers are released to the configured S3 bucket. Only tags **without** the `agent-os-` prefix trigger this behavior.

### Option B: Manual build (single or all)

1. Go to **Actions** → **Build Suite Installer** → **Run workflow**.
2. Choose:
   - **all_builds:** `true` to build all OS/arch/type combinations (as above), or `false` to pick one.
   - **os:** Windows, MacOS, or Linux (ignored if `all_builds` is true).
   - **architecture:** AMD64 or ARM64 (ignored if `all_builds` is true).
   - **version:** e.g. `26.2.1`.
   - **installationType:** Web or Full.
   - **release:** set to `true` to publish the built installer to the S3 bucket.

---

## Agent OS releases (Python package + Windows installers)

### Version format

- **Stable:** `26.2.1` → tag `agent-os-v26.2.1`, PyPI version `26.2.1`.
- **Release candidate:** `26.2.1.5` → tag `agent-os-v26.2.1.5`, PyPI version `26.2.1.rc5`.

Version must match: `YY.MINOR.PATCH` or `YY.MINOR.PATCH.RC` (e.g. `26.1.1` or `26.1.1.5` for rc5).

### How to release

1. Go to **Actions** → **Release Agent OS** → **Run workflow**.
2. Enter the **version** (e.g. `26.1.1` or `26.1.1.5` for rc5).
3. Run the workflow.

The workflow will:

1. Bump the version and create the Git tag (e.g. `agent-os-v26.2.1` or `agent-os-v26.2.1.5`).
2. Publish the **Python package** to PyPI (e.g. `pip install askui-agent-os==26.2.1`).
3. Build **Agent OS Windows service installers** for AMD64 and ARM64 and upload them to the S3 bucket.
4. Create a **GitHub Release** with generated release notes (PyPI install instructions and installer download links).

---

## Summary

- **Suite Installers:** Use a **GitHub Release** with a version tag (`26.2.1` or `26.2.1.1`), or run **Build Suite Installer** manually for a single or full matrix.
- **Agent OS:** Run **Release Agent OS** with a version; it handles tagging, PyPI, Windows installers, and the GitHub Release.
