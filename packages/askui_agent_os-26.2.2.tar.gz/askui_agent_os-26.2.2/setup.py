"""Setup script: wires custom build command so platform binary is downloaded during build."""

import sys
from pathlib import Path
from setuptools import setup, Distribution

# So the isolated build env can import build_scripts (not installed there)
sys.path.insert(0, str(Path(__file__).resolve().parent))
from build_scripts.build_cmd import BuildPYWithBinaries


# hardcode to not pure
class BinaryDistribution(Distribution):
    def has_ext_modules(self):
        return True


setup(
    cmdclass={"build_py": BuildPYWithBinaries},
    distclass=BinaryDistribution,
    install_requires=[],
)
