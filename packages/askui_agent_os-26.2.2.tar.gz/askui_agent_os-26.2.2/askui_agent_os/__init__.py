from askui_agent_os.agent_os import AgentOS

AgentOS.setup()

__all__ = ["AgentOS"]
