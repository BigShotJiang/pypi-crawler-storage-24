"""Public API: single entry point for AskUI Agent OS functionality."""

import platform
from pathlib import Path

from askui_agent_os._runtime_check import (
    check_windows_cpp_runtime,
)


class AgentOS:
    """
    Platform-specific binaries and helpers for the AskUI Remote Device Controller.

    Use static methods to get paths, check runtimes, and prepare the environment.
    Setup runs on import; prerequisites (e.g. Windows VC++ runtime check) run on each call.
    """

    _MIN_VC_RUNTIME_MAJOR = 14
    _MIN_VC_RUNTIME_MINOR = 34
    _MIN_VC_RUNTIME_PATCH = 31938

    @staticmethod
    def setup() -> None:
        """Prepare the environment: make binary executable. Called on import."""
        AgentOS._make_binary_executable()

    @staticmethod
    def bin_path() -> Path:
        """Return the path to the package's bin directory (where binaries are installed)."""
        AgentOS._ensure_prerequisites()
        return AgentOS._get_bin_dir()

    @staticmethod
    def controller_path() -> Path:
        """Return the path to the remote device controller binary."""
        AgentOS._ensure_prerequisites()
        return AgentOS._get_remote_device_controller_path()

    @staticmethod
    def make_executable() -> None:
        """Make the controller binary executable (no-op on Windows)."""
        AgentOS._ensure_prerequisites()
        AgentOS._make_binary_executable()

    @staticmethod
    def require_vc_redistributable() -> None:
        """
        Require a sufficient Microsoft Visual C++ Redistributable on Windows.

        No-op on non-Windows platforms. On Windows, raises RuntimeError if the
        minimum required version is not found.
        """
        if not check_windows_cpp_runtime(
            min_major=AgentOS._MIN_VC_RUNTIME_MAJOR,
            min_minor=AgentOS._MIN_VC_RUNTIME_MINOR,
            min_patch=AgentOS._MIN_VC_RUNTIME_PATCH,
        ):
            raise RuntimeError(
                f"[AskUI Agent OS]: Microsoft Visual C++ Redistributable (minimum "
                f"{AgentOS._MIN_VC_RUNTIME_MAJOR}.{AgentOS._MIN_VC_RUNTIME_MINOR}.{AgentOS._MIN_VC_RUNTIME_PATCH}) "
                "is required on Windows. Install from: "
                "https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist"
            )

    @staticmethod
    def _ensure_prerequisites() -> None:
        """Run prerequisites (e.g. require Windows VC++ runtime). Called before each operation."""
        AgentOS.require_vc_redistributable()

    @staticmethod
    def _get_bin_dir() -> Path:
        """Return the path to the package's bin directory (where binaries are installed)."""
        return Path(__file__).resolve().parent / "bin"

    @staticmethod
    def _get_remote_device_controller_path() -> Path:
        """Return the path to the remote device controller binary."""
        binary_name = "AskuiRemoteDeviceController"
        if platform.system() == "Windows":
            binary_name += ".exe"
        return (AgentOS._get_bin_dir() / binary_name).absolute()

    @staticmethod
    def _make_binary_executable() -> None:
        """Make the binary executable (no-op on Windows)."""
        if platform.system() == "Windows":
            return
        AgentOS._get_remote_device_controller_path().chmod(0o755)

