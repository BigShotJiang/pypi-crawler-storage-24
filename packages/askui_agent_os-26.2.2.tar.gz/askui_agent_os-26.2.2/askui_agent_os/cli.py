"""CLI for askui-agent-os."""

import argparse

from askui_agent_os import AgentOS


def main() -> None:
    parser = argparse.ArgumentParser(prog="askui-agent-os")
    subparsers = parser.add_subparsers(dest="command", required=True)

    path_parser = subparsers.add_parser("get-binary-path")
    path_parser.set_defaults(func=_cmd_controller_path)

    args = parser.parse_args()
    args.func(args)


def _cmd_controller_path(_args: argparse.Namespace) -> None:
    path = AgentOS.controller_path()
    print(path)


if __name__ == "__main__":
    main()
