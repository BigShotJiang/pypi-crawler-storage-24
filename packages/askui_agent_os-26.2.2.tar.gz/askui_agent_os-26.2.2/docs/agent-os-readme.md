# AskUI AgentOS (User-Mode)

Platform-specific binaries for the **AskUI Remote Device Controller**, shipped as a Python package. It is optimized for automation within an **Active Interactive Session** (local development and manual testing).

For **Enterprise & CI/CD** requirements—including headless VMs, RDP Resilience, and logon screen control—install the **AskUI AgentOS System Service**.

## Comparison: User-Mode vs. System Service

| **Feature** | **User-Mode (pip package)** | **System Service (EXE Installer)** |
|---|---|---|
| **Primary Use Case** | Local Dev / Desktop | **Enterprise / CI/CD Pipelines** |
| **CI/CD Ready** | ❌ No | ✅ **Yes** (Unattended/Headless) |
| **RDP Resilience** | ❌ Session locks on disconnect | ✅ **Yes** (Transmission Mode) |
| **Enterprise Ready** | ❌ No | ✅ **Yes** |
| **Logon Screen Control** | ❌ No | ✅ **Yes** |
| **Send CTRL+ALT+DEL** | ❌ No | ✅ **Yes** (Secure Attention Sequence) |
| **Admin Privilege** | Limited to current user | ✅ **Full System Access** |

## Requirements

- **Python:** 3.10+
- **Platforms:** Windows, Linux, macOS
- **Windows only:** [Microsoft Visual C++ Redistributable](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist) (minimum version 14.34.31938). The package checks this automatically when you use the API.

## Installation

```bash
pip install askui-agent-os
```

## Usage

### Command line

Get the path to the Remote Device Controller binary:

```bash
askui-agent-os get-binary-path
```

### Python API

The package exposes a single class, **`AgentOS`**, with static methods. On import, `AgentOS.setup()` runs and makes the controller binary executable (no-op on Windows). Prerequisites (e.g. Windows VC++ runtime) are checked when you call `bin_path()` or `controller_path()`.

```python
from askui_agent_os import AgentOS

# Directory containing platform binaries
bin_dir = AgentOS.bin_path()

# Full path to the controller executable (use this with the AskUI SDK)
path = AgentOS.controller_path()

# Optional: require Windows VC++ runtime (raises RuntimeError if missing on Windows)
AgentOS.require_vc_redistributable()
```

| Method | Description |
|--------|-------------|
| `AgentOS.bin_path()` | Path to the package `bin` directory. |
| `AgentOS.controller_path()` | Full path to the controller executable. |
| `AgentOS.require_vc_redistributable()` | No-op on non-Windows; on Windows, raises if the required VC++ runtime is missing. |

## Why upgrade to the System Service?

If any of these scenarios apply to you, you need the **AskUI AgentOS System Service**:

- **"I need to automate the Windows logon screen."** The user-mode package only works inside an active session. The System Service runs at the system level and can interact with the logon screen, lock screen, and UAC prompts.
- **"I need to send CTRL+ALT+DEL."** Windows reserves this key combination (the Secure Attention Sequence) and blocks it from regular user-mode applications. The System Service has the privileges to trigger SAS programmatically.
- **"My automation breaks when I disconnect from RDP."** RDP disconnects destroy the interactive session, killing user-mode automation. The System Service keeps running and reconnects transparently.
- **"I want to run automation in a CI/CD pipeline on a headless VM."** Without an active user session there is no desktop to attach to. The System Service creates and manages its own session.

Visit [docs.askui.com](https://docs.askui.com/) to download the **Enterprise-Ready** EXE installer.

## License

Non-commercial use is free; commercial use requires a separate Commercial Licence from AskUI — contact [sales@askui.com](mailto:sales@askui.com).

View the full Terms of Service:

```bash
pip show askui-agent-os
```

## Links

- [Homepage](https://www.askui.com/)
- [Python SDK](https://github.com/askui/python-sdk)
- [Documentation](https://docs.askui.com)
- [Support](mailto:support@askui.com)
