from .blazen import *

__doc__ = blazen.__doc__
if hasattr(blazen, "__all__"):
    __all__ = blazen.__all__