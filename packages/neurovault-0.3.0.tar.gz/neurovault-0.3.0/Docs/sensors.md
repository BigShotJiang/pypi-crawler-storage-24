# NEUROVAULT Sensors

NEUROVAULT v0.1 includes seven passive sensors.

## Clipboard
- Poll interval: 500ms
- Detects text/code/url/path/json
- Deduplicates by recent hashes

## File Watcher
- Monitors configured paths recursively
- Captures modified file diffs
- Applies extension filters and path blocklists

## Browser
- Reads local browser history stores
- Captures title + URL
- Deduplicates visited URLs over 24h window

## Screenshot
- Optional OCR sensor
- Captures text only, never stores images

## Audio
- Optional transcription sensor
- Watches local recording directories

## Calendar
- Reads local `.ics` exports
- Captures event summary/location/details

## Git
- Reads recent commits from configured repos
- Captures author/message and short stats
