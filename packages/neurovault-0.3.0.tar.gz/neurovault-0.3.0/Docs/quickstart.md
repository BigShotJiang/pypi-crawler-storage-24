# NEUROVAULT Quickstart

## Install

```bash
pip install -e ".[dev]"
```

## Initialize

```bash
neurovault init my-brain
```

## Ingest and Recall

```bash
neurovault ingest "Alex prefers keyboard shortcuts"
neurovault recall "preferences" --mode multi
```

## Consolidate

```bash
neurovault consolidate --force
neurovault insights --limit 5
```

## Daemon

```bash
neurovault start --verbose
neurovault status
neurovault stop
```

## API

```bash
neurovault serve --host 127.0.0.1 --port 8787
curl -sS http://127.0.0.1:8787/api/v1/health
```
