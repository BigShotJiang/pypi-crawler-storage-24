from neurovault.cli import main

main()
