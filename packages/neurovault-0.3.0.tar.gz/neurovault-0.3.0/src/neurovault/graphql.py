"""Compatibility wrapper for GraphQL service module naming."""

from neurovault.graphql_api import GraphQLService

__all__ = ["GraphQLService"]
