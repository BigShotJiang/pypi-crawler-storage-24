"""NEUROVAULT exception hierarchy."""


class NeurovaultError(Exception):
    """Base error for NEUROVAULT."""


class VaultNotFoundError(NeurovaultError):
    """Raised when a requested vault cannot be opened."""


class VaultExistsError(NeurovaultError):
    """Raised when creating a vault that already exists."""


class SensorError(NeurovaultError):
    """Raised for sensor failures."""


class ConsolidationError(NeurovaultError):
    """Raised for consolidation failures."""


class EntityNotFoundError(NeurovaultError):
    """Raised for unknown entities."""


class PredictionError(NeurovaultError):
    """Raised for prediction engine failures."""
