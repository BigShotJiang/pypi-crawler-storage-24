"""Compatibility wrapper for docs that reference neurovault/dashboard.py."""

from neurovault.dashboard.app import check_deps, main, run_dashboard

__all__ = ["run_dashboard", "check_deps", "main"]
