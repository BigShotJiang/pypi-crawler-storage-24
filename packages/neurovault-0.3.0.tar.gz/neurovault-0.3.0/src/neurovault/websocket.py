"""Compatibility wrapper for WebSocket streaming module naming."""

from neurovault.websocket_stream import EVENT_TYPES, EventStream, WebSocketServer

__all__ = ["EventStream", "WebSocketServer", "EVENT_TYPES"]
