"""Base sensor interface for NEUROVAULT ingestion."""

from __future__ import annotations

from abc import ABC, abstractmethod


class BaseSensor(ABC):
    """Base class for all NEUROVAULT sensors."""

    @property
    @abstractmethod
    def name(self) -> str:
        raise NotImplementedError

    @property
    @abstractmethod
    def source_tag(self) -> str:
        raise NotImplementedError

    @property
    @abstractmethod
    def poll_interval(self) -> float:
        """Seconds between polls."""
        raise NotImplementedError

    def is_enabled(self, config) -> bool:
        disabled = config.get("disabled_sensors", [])
        if self.name in disabled:
            return False

        sensors_cfg = config.get("sensors", {})
        if isinstance(sensors_cfg, dict):
            sensor_cfg = sensors_cfg.get(self.name, {})
            if isinstance(sensor_cfg, dict):
                return bool(sensor_cfg.get("enabled", True))
        return True

    @abstractmethod
    def poll(self) -> list[tuple[str, dict]]:
        """Return list of (content, metadata) tuples."""
        raise NotImplementedError

    def start(self) -> None:
        """Optional sensor startup hook."""

    def stop(self) -> None:
        """Optional sensor shutdown hook."""
