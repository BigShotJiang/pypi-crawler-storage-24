"""Sensor implementations."""

from neurovault.sensors.audio import AudioSensor
from neurovault.sensors.browser import BrowserSensor
from neurovault.sensors.calendar import CalendarSensor
from neurovault.sensors.calendar_integration import CalendarIntegration
from neurovault.sensors.clipboard import ClipboardSensor
from neurovault.sensors.continuous_screen import ContinuousScreenMonitor
from neurovault.sensors.document_parser import DocumentParser
from neurovault.sensors.file_watcher import FileWatcherSensor
from neurovault.sensors.git import GitSensor
from neurovault.sensors.screenshot import ScreenshotSensor

__all__ = [
    "ClipboardSensor",
    "FileWatcherSensor",
    "BrowserSensor",
    "GitSensor",
    "ScreenshotSensor",
    "ContinuousScreenMonitor",
    "DocumentParser",
    "AudioSensor",
    "CalendarSensor",
    "CalendarIntegration",
]
