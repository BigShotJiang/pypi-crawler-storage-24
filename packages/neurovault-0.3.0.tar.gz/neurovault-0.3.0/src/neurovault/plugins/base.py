"""Plugin sensor base class for community ingestion plugins."""

from __future__ import annotations

import abc
from typing import Any


class PluginSensor(abc.ABC):
    """Base class for plugin sensors."""

    @property
    @abc.abstractmethod
    def name(self) -> str:
        """Human-readable sensor name."""

    @property
    @abc.abstractmethod
    def source_tag(self) -> str:
        """Source tag applied to ingested memories."""

    @property
    def poll_interval(self) -> float:
        """Seconds between poll calls."""
        return 300.0

    def setup(self, config: dict[str, Any]) -> None:
        """Initialize with user-provided configuration."""

    @abc.abstractmethod
    def poll(self) -> list[tuple[str, dict[str, Any]]]:
        """Poll for new content and return (content, metadata) tuples."""

    def teardown(self) -> None:
        """Cleanup when sensor is stopped."""

    def health_check(self) -> dict[str, Any]:
        """Return health status for this plugin sensor."""
        return {"status": "ok", "name": self.name}
