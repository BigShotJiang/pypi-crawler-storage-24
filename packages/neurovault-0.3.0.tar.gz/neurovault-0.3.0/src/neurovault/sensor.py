"""Compatibility wrapper for base sensor module naming."""

from neurovault.sensors.base import BaseSensor

__all__ = ["BaseSensor"]
