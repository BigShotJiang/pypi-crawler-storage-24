"""Compatibility wrapper for peer discovery module naming."""

from neurovault.network.peer_discovery import PeerDiscovery

__all__ = ["PeerDiscovery"]
