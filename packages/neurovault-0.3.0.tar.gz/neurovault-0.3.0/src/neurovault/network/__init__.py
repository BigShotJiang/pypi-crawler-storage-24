"""v0.3 network and federation modules."""

from neurovault.network.bundle import KnowledgeBundle
from neurovault.network.identity import DeviceIdentity
from neurovault.network.peer_discovery import PeerDiscovery
from neurovault.network.strategies import (
    ManualStrategy,
    NewerWinsStrategy,
    SemanticMergeStrategy,
    SyncStrategy,
)
from neurovault.network.sync_engine import SyncEngine
from neurovault.network.sync_log import SyncLog
from neurovault.network.delta_sync import DeltaSyncEngine
from neurovault.network.codec import pack_message, unpack_message
from neurovault.network.kg_merge import EntityResolver, KnowledgeGraphMerger

__all__ = [
    "KnowledgeBundle",
    "DeviceIdentity",
    "PeerDiscovery",
    "SyncStrategy",
    "NewerWinsStrategy",
    "ManualStrategy",
    "SemanticMergeStrategy",
    "SyncEngine",
    "SyncLog",
    "DeltaSyncEngine",
    "EntityResolver",
    "KnowledgeGraphMerger",
    "pack_message",
    "unpack_message",
]
