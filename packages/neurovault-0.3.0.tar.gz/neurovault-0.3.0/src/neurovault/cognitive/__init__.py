"""Cognitive modules."""

from neurovault.cognitive.consolidation import ConsolidationEngine
from neurovault.cognitive.consolidation_v2 import ConsolidationEngineV2
from neurovault.cognitive.consolidation_v3 import ConsolidationEngineV3
from neurovault.cognitive.consolidation_strategy import ConsolidationStrategy
from neurovault.cognitive.advanced_llm import AdvancedLLMConsolidation
from neurovault.cognitive.decay import ebbinghaus_retention, next_review_time_ms, temporal_weight
from neurovault.cognitive.embedding_engine import EmbeddingEngine
from neurovault.cognitive.embedding_router import EmbeddingRouter, OpenAICompatBackend, PCAReducer
from neurovault.cognitive.emotional import EmotionalAnalyzer
from neurovault.cognitive.entity_extractor import EntityExtractor
from neurovault.cognitive.hybrid_ner import HybridNERExtractor
from neurovault.cognitive.importance_calibrator import ImportanceCalibrator
from neurovault.cognitive.llm_client import OllamaClient
from neurovault.cognitive.llm_insights import LLMInsightGenerator
from neurovault.cognitive.llm_relationships import LLMRelationshipExtractor
from neurovault.cognitive.ontology import OntologyEngine
from neurovault.cognitive.prediction import ContextMonitor, PredictionEngine
from neurovault.cognitive.semantic_dedup import SemanticDeduplicator
from neurovault.cognitive.clustering import Cluster, threshold_cluster

__all__ = [
    "ConsolidationEngine",
    "ConsolidationEngineV2",
    "ConsolidationEngineV3",
    "ConsolidationStrategy",
    "AdvancedLLMConsolidation",
    "ContextMonitor",
    "PredictionEngine",
    "EmotionalAnalyzer",
    "EntityExtractor",
    "HybridNERExtractor",
    "OntologyEngine",
    "OllamaClient",
    "LLMInsightGenerator",
    "LLMRelationshipExtractor",
    "ImportanceCalibrator",
    "EmbeddingEngine",
    "EmbeddingRouter",
    "OpenAICompatBackend",
    "PCAReducer",
    "SemanticDeduplicator",
    "Cluster",
    "threshold_cluster",
    "ebbinghaus_retention",
    "temporal_weight",
    "next_review_time_ms",
]
