"""Compatibility wrapper for clustering module naming."""

from neurovault.cognitive.clustering import Cluster, threshold_cluster

__all__ = ["Cluster", "threshold_cluster"]
