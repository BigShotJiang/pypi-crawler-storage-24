"""Compatibility wrapper for mobile API module naming."""

from neurovault.mobile_api import create_mobile_api

__all__ = ["create_mobile_api"]
