"""Compatibility wrapper for REST API module naming."""

from neurovault.api import create_app, create_mobile_app

__all__ = ["create_app", "create_mobile_app"]
