"""Dashboard package for NEUROVAULT visualizer."""

from neurovault.dashboard.app import check_deps, main, run_dashboard

__all__ = ["run_dashboard", "check_deps", "main"]
