# Contributing to NeuroVault

Thank you for your interest in contributing to **NeuroVault**!

## Getting Started

```bash
git clone https://github.com/myProjectsRavi/neuroVault.git
cd neuroVault
pip install -e ".[dev,full]"
pytest tests/
```

## Development Workflow

1. Fork the repository and create a feature branch from `main`.
2. Write tests for new functionality in `tests/unit/` or `tests/integration/`.
3. Ensure all checks pass:
   ```bash
   make lint      # ruff check + format
   make test      # pytest
   mypy src/neurovault/ --ignore-missing-imports
   ```
4. Open a pull request against `main`.

## Code Style

- Follow [PEP 8](https://peps.python.org/pep-0008/).
- Use `from __future__ import annotations` in every module.
- Format with `ruff format`, lint with `ruff check`.
- All public functions and classes need docstrings.

## Reporting Issues

Open a GitHub issue with:
- A clear, descriptive title.
- Steps to reproduce (if applicable).
- Expected vs. actual behaviour.
- Python version and OS.

Issue and PR templates are available under `.github/` and should be used for all contributions.

## Security Vulnerabilities

Please see [SECURITY.md](SECURITY.md) for responsible disclosure instructions.

## Code of Conduct

By participating in this project, you agree to follow [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md).

## License

By contributing you agree that your contributions will be licensed under the MIT License.
