# Security Policy

## Supported Versions

| Version | Supported          |
|---------|--------------------|
| 0.3.x   | ✅ Current release |
| < 0.3   | ❌ No longer supported |

## Reporting a Vulnerability

If you discover a security vulnerability in NeuroVault, **please do not open a public issue**.

Instead, email **security@neurovault.dev** (or open a private GitHub Security Advisory) with:

1. A description of the vulnerability.
2. Steps to reproduce.
3. The potential impact.

We will acknowledge receipt within **48 hours** and aim to release a fix within **7 days** for critical issues.

## Security Model

NeuroVault is designed as a **local-first personal memory tool**. Its threat model assumes:

- **The REST API binds to `127.0.0.1` by default.** Exposing it on `0.0.0.0` without additional authentication is not recommended for production.
- **Federation (peer-to-peer sync) uses Ed25519 challenge-response authentication** but transmits data over unencrypted WebSocket (`ws://`). For cross-network sync, deploy behind a TLS-terminating proxy or VPN.
- **Sensor data (clipboard, browser history, screenshots) is processed and stored locally.** Sensitive patterns (API keys, credentials, SSNs, credit card numbers) are automatically redacted by the content filter before storage.
- **Encryption at rest** is available via SQLCipher when the `encryption` extra is installed and a passphrase is configured.

## Responsible Disclosure

We follow [coordinated vulnerability disclosure](https://en.wikipedia.org/wiki/Coordinated_vulnerability_disclosure). Reporters will be credited in the CHANGELOG unless they prefer to remain anonymous.
