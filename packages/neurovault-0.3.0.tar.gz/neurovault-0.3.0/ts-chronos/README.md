# ts-chronos

TypeScript SDK for CHRONOS v0.6/v0.7 API surfaces.

## Install

```bash
npm install ts-chronos
```

## Usage

```ts
import { ChronosClient } from "ts-chronos";

const client = new ChronosClient("http://localhost:8420");

const agent = await client.registerAgent("ResearchBot", ["ml", "ops"]);
await client.storeEpisode(agent.agent_id, "Investigated model drift root causes");

const timeline = await client.buildTimeline(agent.agent_id, "model drift", {
  granularity: "day",
  window_days: 30,
});
console.log(timeline.narrative);
```

## Covered Surfaces

- v0.6 agent memory, dream, defense, goals
- v0.7 temporal reasoning, causal inference, morphology, predictive recall
