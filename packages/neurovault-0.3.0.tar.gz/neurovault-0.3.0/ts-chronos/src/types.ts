export interface AgentProfile {
  agent_id: string;
  name: string;
  did: string;
  expertise_domains: string[];
  personality_vector: number[] | null;
  created_at: number;
  total_memories: number;
  curiosity_score: number;
  confidence_score: number;
}

export interface EpisodicMemory {
  memory_id: string;
  agent_id: string;
  content: string;
  occurred_at: number;
  location: string;
  emotional_valence: number;
  vividness: number;
  importance: number;
}

export interface DreamCycleResult {
  cycle_id: string;
  agent_id: string;
  duration_ms: number;
  insights_generated: number;
  connections_formed: number;
  memories_pruned: number;
  creativity_score: number;
  dream_log: string[];
}

export interface AnomalyReport {
  report_id: string;
  timestamp: number;
  threat_level: "safe" | "low" | "medium" | "high" | "critical";
  category: string;
  description: string;
  action_taken: string;
}

export interface PlanStep {
  step_number: number;
  action: string;
  status: "pending" | "in_progress" | "completed" | "blocked";
}

export interface Goal {
  goal_id: string;
  agent_id: string;
  title: string;
  description: string;
  status: "proposed" | "active" | "in_progress" | "blocked" | "completed" | "abandoned";
  priority: "critical" | "high" | "medium" | "low";
  confidence: number;
  progress_pct: number;
  plan_steps: PlanStep[];
}

export interface TemporalSlice {
  start_ms: number;
  end_ms: number;
  memory_count: number;
  topic_distribution: Record<string, number>;
  avg_importance: number;
  emotional_valence: number;
  dominant_context: string;
}

export interface TemporalTrend {
  metric_name: string;
  direction: "rising" | "falling" | "stable" | "oscillating";
  magnitude: number;
  confidence: number;
}

export interface Timeline {
  agent_id: string;
  query: string;
  slices: TemporalSlice[];
  trends: TemporalTrend[];
  narrative: string;
}

export interface CausalEdge {
  source_id: string;
  target_id: string;
  relation: "causes" | "prevents" | "enables" | "correlates";
  confidence: number;
  mechanism: string;
  temporal_lag_ms: number;
}

export interface ShapeAnalysis {
  shape: "linear" | "exponential" | "plateau" | "spiral" | "burst" | "fragmented" | "convergent";
  confidence: number;
  description: string;
  metrics: Record<string, number>;
}

export interface PredictedRecall {
  memory_id: string;
  content_preview: string;
  predicted_relevance: number;
  prediction_reason: string;
}
