## Summary

Describe the change and why it is needed.

## Scope

- [ ] Engine / cognitive pipeline
- [ ] API / CLI surface
- [ ] Security / auth / encryption
- [ ] Deployment / observability
- [ ] Documentation only

## Validation

- [ ] Tests added or updated where needed
- [ ] `pytest -q` passes locally
- [ ] `ruff check src/` passes
- [ ] `mypy src/neurovault/ --ignore-missing-imports` passes

## Security and Privacy

- [ ] No secrets, credentials, or personal data introduced
- [ ] Any auth/permission changes are documented
- [ ] Any new network-exposed surface is explicit and justified

## Breaking Changes

- [ ] None
- [ ] Yes (describe below)

## Checklist

- [ ] I read `CONTRIBUTING.md`
- [ ] I kept changes focused and production-oriented
- [ ] I updated docs/changelog where appropriate
