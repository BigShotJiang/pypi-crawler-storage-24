from neurovault.engine import NeurovaultEngine


def test_consolidation_generates_entities_and_promotions(tmp_path):
    vault = NeurovaultEngine.init("test", no_embedding=True, base_dir=str(tmp_path))

    for i in range(6):
        vault.ingest(
            f"Alex and Sarah using Python on Project Alpha milestone {i}",
            source="user",
            importance=0.9,
        )

    report = vault.consolidate(force=True, phases=["entities", "promote"])
    assert report.entities_extracted > 0
    assert report.memories_promoted >= 0


def test_insights_interface_returns_list(tmp_path):
    vault = NeurovaultEngine.init("test", no_embedding=True, base_dir=str(tmp_path))
    vault.ingest("One memory", source="user")
    insights = vault.get_insights(limit=5)
    assert isinstance(insights, list)
