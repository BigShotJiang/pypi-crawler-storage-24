import pytest

pytest.importorskip("fastapi")
from fastapi.testclient import TestClient

from neurovault.engine import NeurovaultEngine
from neurovault.mobile_api import create_mobile_api


def test_mobile_api_basic_flow(tmp_path):
    engine = NeurovaultEngine.init("mobile", no_embedding=True, base_dir=str(tmp_path))
    app = create_mobile_api(engine, config={"api_keys": ["mobile-token"]})
    client = TestClient(app)

    health = client.get("/api/v1/health")
    assert health.status_code == 200

    stats_unauth = client.get("/api/v1/stats")
    assert stats_unauth.status_code == 401

    headers = {"Authorization": "Bearer mobile-token"}
    stats = client.get("/api/v1/stats", headers=headers)
    assert stats.status_code == 200

    ingest = client.post(
        "/api/v1/ingest",
        headers=headers,
        json={"content": "Mobile ingestion works", "source": "mobile", "importance": 0.7},
    )
    assert ingest.status_code == 200

    recall = client.post("/api/v1/recall", headers=headers, json={"query": "Mobile", "limit": 5})
    assert recall.status_code == 200
    assert recall.json()["count"] >= 1
