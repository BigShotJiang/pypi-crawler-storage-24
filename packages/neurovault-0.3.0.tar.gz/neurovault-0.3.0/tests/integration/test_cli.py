from click.testing import CliRunner

from neurovault.cli import main
from neurovault.engine import NeurovaultEngine


def test_cli_recall_and_status(monkeypatch, tmp_path):
    vault = NeurovaultEngine.init("test", no_embedding=True, base_dir=str(tmp_path))
    vault.ingest("Python auth handler fix", source="user")

    import neurovault.cli as cli_module

    monkeypatch.setattr(cli_module, "_get_vault", lambda name="default": vault)

    runner = CliRunner()
    result = runner.invoke(main, ["recall", "Python", "--mode", "multi"])
    assert result.exit_code == 0
    assert "Python" in result.output

    status_result = runner.invoke(main, ["status"])
    assert status_result.exit_code == 0
    assert "NEUROVAULT Status" in status_result.output


def test_cli_checkpoint_and_log(monkeypatch, tmp_path):
    vault = NeurovaultEngine.init("test", no_embedding=True, base_dir=str(tmp_path))
    import neurovault.cli as cli_module

    monkeypatch.setattr(cli_module, "_get_vault", lambda name="default": vault)
    runner = CliRunner()

    cp = runner.invoke(main, ["checkpoint", "--message", "first"])
    assert cp.exit_code == 0
    assert "Checkpoint" in cp.output

    log = runner.invoke(main, ["log"])
    assert log.exit_code == 0
    assert "Checkpoint Log" in log.output
