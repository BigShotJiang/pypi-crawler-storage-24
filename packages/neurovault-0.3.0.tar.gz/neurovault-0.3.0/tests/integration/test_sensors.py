from neurovault.sensors.audio import AudioSensor
from neurovault.sensors.browser import BrowserSensor
from neurovault.sensors.calendar import CalendarSensor
from neurovault.sensors.clipboard import ClipboardSensor
from neurovault.sensors.file_watcher import FileWatcherSensor
from neurovault.sensors.git import GitSensor
from neurovault.sensors.screenshot import ScreenshotSensor


def test_clipboard_sensor_poll_with_mock(monkeypatch):
    sensor = ClipboardSensor()
    monkeypatch.setattr(sensor, "_read_clipboard", lambda: "print('hello from clipboard')")
    items = sensor.poll()
    assert len(items) == 1


def test_file_watcher_sensor_poll_no_crash():
    sensor = FileWatcherSensor(watch_paths=[])
    items = sensor.poll()
    assert isinstance(items, list)


def test_browser_sensor_poll_no_crash(monkeypatch):
    sensor = BrowserSensor()
    monkeypatch.setattr(sensor, "_read_chrome", lambda: [])
    items = sensor.poll()
    assert items == []


def test_git_sensor_poll_no_crash(monkeypatch):
    sensor = GitSensor(repo_paths=["/path/that/does/not/exist"])
    items = sensor.poll()
    assert items == []


def test_optional_sensors_poll_no_crash(tmp_path):
    screenshot = ScreenshotSensor()
    assert isinstance(screenshot.poll(), list)

    audio = AudioSensor(watch_paths=[str(tmp_path)])
    assert isinstance(audio.poll(), list)

    calendar = CalendarSensor(watch_paths=[str(tmp_path)])
    assert isinstance(calendar.poll(), list)
