import pytest

from neurovault.engine import NeurovaultEngine


@pytest.fixture
def vault(tmp_path):
    v = NeurovaultEngine.init("test", no_embedding=True, base_dir=str(tmp_path))
    yield v
    v._nv.close()
    v._bridge.repo._storage.close()
