from neurovault.events import EventBus, NeurovaultEvents


def test_event_bus_emit_and_subscribe():
    bus = EventBus()
    seen = []

    def handler(payload):
        seen.append(payload)

    bus.subscribe(NeurovaultEvents.MEMORY_INGESTED, handler)
    bus.emit(NeurovaultEvents.MEMORY_INGESTED, {"id": "abc"})
    assert seen == [{"id": "abc"}]


def test_event_constants_include_v03_catalog_entries():
    assert NeurovaultEvents.PREDICTION_CALENDAR == "prediction.calendar"
    assert NeurovaultEvents.CONSOLIDATION_ENTITY_EXTRACTED == "consolidation.entity_extracted"
    assert NeurovaultEvents.PEER_DISCOVERED == "peer.discovered"
    assert NeurovaultEvents.SYNC_COMPLETED == "sync.completed"
