import os
import tempfile

from neurovault.security.audit import AuditTrail


def test_audit_log_and_query_file_mode():
    with tempfile.NamedTemporaryFile(suffix=".audit", delete=False) as handle:
        path = handle.name
    try:
        audit = AuditTrail(log_path=path)
        audit.log("alice", "recall", "memories", {"query": "python"})
        audit.log("bob", "ingest", "memories", {"source": "clipboard"})

        rows = audit.query(user="alice")
        assert len(rows) == 1
        assert rows[0]["action"] == "recall"
    finally:
        os.unlink(path)
