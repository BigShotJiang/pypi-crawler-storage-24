from neurovault.pipeline.hooks import HookManager


def test_hook_registration_and_run_sync():
    hooks = HookManager()
    events = []

    def callback(payload):
        events.append(payload)
        return "ok"

    hooks.register("pre_ingest", callback)
    results = hooks.run_sync("pre_ingest", {"value": 1})

    assert len(results) == 1
    assert results[0] == "ok"
    assert events == [{"value": 1}]


def test_hook_error_isolation():
    hooks = HookManager()

    def bad(_payload):
        raise RuntimeError("boom")

    def good(payload):
        return payload["x"]

    hooks.register("pre_ingest", bad)
    hooks.register("pre_ingest", good)

    results = hooks.run_sync("pre_ingest", {"x": 7})
    assert results == [7]
