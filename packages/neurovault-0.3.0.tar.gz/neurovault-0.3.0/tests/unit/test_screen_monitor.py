from neurovault.sensors.continuous_screen import ContinuousScreenMonitor


def test_capture_and_compare_detects_change(monkeypatch):
    monitor = ContinuousScreenMonitor(config={})

    monkeypatch.setattr(
        ContinuousScreenMonitor,
        "_get_active_window",
        staticmethod(lambda: {"app": "Editor", "title": "notes"}),
    )
    monkeypatch.setattr(
        ContinuousScreenMonitor,
        "_capture_screenshot",
        staticmethod(lambda: b"fake-image-bytes"),
    )
    monkeypatch.setattr(
        ContinuousScreenMonitor,
        "_ocr_screenshot",
        staticmethod(lambda _data: "This is enough OCR text to be accepted."),
    )

    first = monitor.capture_and_compare()
    second = monitor.capture_and_compare()

    assert first is not None
    assert first["app_name"] == "Editor"
    assert second is None
