from neurovault.cognitive.embedding_engine import EmbeddingEngine


def test_embedding_engine_tfidf_mode():
    engine = EmbeddingEngine(config={"embedding_backend": "tfidf"})
    vec = engine.embed("neurovault embedding smoke test")

    assert engine.backend_name == "tfidf"
    assert len(vec) == engine.dimension
