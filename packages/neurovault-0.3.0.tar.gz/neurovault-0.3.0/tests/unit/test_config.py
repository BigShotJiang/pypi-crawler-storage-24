from neurovault.config import NeurovaultConfig


def test_config_save_and_load(tmp_path):
    path = tmp_path / "config.toml"
    cfg = NeurovaultConfig.load(path=str(path))
    cfg.set_sensor_enabled("clipboard", False)
    cfg.privacy["url_blocklist"] = ["*://example.com/*"]
    cfg.network["enabled"] = True
    cfg.save(path=str(path))

    loaded = NeurovaultConfig.load(path=str(path))
    assert "clipboard" in loaded.disabled_sensors
    assert loaded.privacy["url_blocklist"] == ["*://example.com/*"]
    assert loaded.network["enabled"] is True
    assert "hnsw" in loaded.search
