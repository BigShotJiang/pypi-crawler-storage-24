def test_doc_compat_module_paths():
    from neurovault.cognitive.cluster import Cluster
    from neurovault.dashboard import run_dashboard
    from neurovault.graphql import GraphQLService
    from neurovault.mobile import create_mobile_api
    from neurovault.network.discovery import PeerDiscovery
    from neurovault.rest import create_app
    from neurovault.sensor import BaseSensor
    from neurovault.websocket import EventStream

    assert Cluster is not None
    assert run_dashboard is not None
    assert GraphQLService is not None
    assert create_mobile_api is not None
    assert PeerDiscovery is not None
    assert create_app is not None
    assert BaseSensor is not None
    assert EventStream is not None
