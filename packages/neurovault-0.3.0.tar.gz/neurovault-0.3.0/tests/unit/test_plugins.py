from neurovault.plugins.loader import PluginLoader


def test_plugin_loader_discover_and_load(tmp_path):
    plugin_dir = tmp_path / "plugins"
    plugin_path = plugin_dir / "demo_plugin"
    plugin_path.mkdir(parents=True)

    (plugin_path / "plugin.toml").write_text(
        """
name = "Demo Plugin"
version = "0.1.0"

[sensor]
module = "sensor"
class = "DemoSensor"
""".strip()
        + "\n",
        encoding="utf-8",
    )

    (plugin_path / "sensor.py").write_text(
        """
from neurovault.plugins.base import PluginSensor

class DemoSensor(PluginSensor):
    @property
    def name(self) -> str:
        return "demo"

    @property
    def source_tag(self) -> str:
        return "demo"

    def poll(self):
        return [("hello", {"k": "v"})]
""".strip()
        + "\n",
        encoding="utf-8",
    )

    loader = PluginLoader(plugin_dir=plugin_dir)
    discovered = loader.discover()
    assert len(discovered) == 1
    assert discovered[0]["_id"] == "demo_plugin"

    sensor = loader.load("demo_plugin", config={"x": 1})
    assert sensor.name == "demo"
    assert "demo_plugin" in loader.get_loaded()
