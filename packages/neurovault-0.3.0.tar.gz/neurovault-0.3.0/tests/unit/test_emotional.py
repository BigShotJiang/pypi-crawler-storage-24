from neurovault.cognitive.emotional import EmotionalAnalyzer

analyzer = EmotionalAnalyzer()


def test_positive_valence():
    result = analyzer.analyze("This is amazing and wonderful!")
    assert result.valence > 0


def test_negative_valence():
    result = analyzer.analyze("This is terrible and broken")
    assert result.valence < 0


def test_neutral_valence():
    result = analyzer.analyze("The meeting is at 3pm in room 5")
    assert -0.3 <= result.valence <= 0.3


def test_high_arousal():
    result = analyzer.analyze("CRITICAL EMERGENCY!!! Production is DOWN!!!")
    assert result.arousal > 0.5


def test_dominance_high():
    result = analyzer.analyze("I solved the bug and built the feature")
    assert result.dominance > 0.5
