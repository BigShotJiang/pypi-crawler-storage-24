import asyncio
from types import SimpleNamespace

from neurovault.pipeline.streaming import StreamingPipeline


class _Filter:
    def filter(self, content, source):
        return content, None


class _Embedder:
    def embed_batch(self, texts):
        return [[1.0, 0.0, 0.0] for _ in texts]


class _Dedup:
    def check_duplicate(self, content, embedding):
        del content, embedding
        return None


class _Bridge:
    def store_memory(self, content, source, importance, metadata):
        del content, source, importance, metadata
        return SimpleNamespace(id=b"m1")


def test_streaming_pipeline_ingests_item():
    async def _run():
        pipe = StreamingPipeline(
            content_filter=_Filter(),
            embedding_engine=_Embedder(),
            deduplicator=_Dedup(),
            storage=SimpleNamespace(),
            bridge=_Bridge(),
        )
        pipe.BATCH_SIZE = 1
        pipe.BATCH_TIMEOUT = 0.01

        await pipe.start()
        await pipe.submit("hello pipeline", source="test")
        await asyncio.sleep(0.05)
        await pipe.stop()

        assert pipe.stats["ingested"] == 1

    asyncio.run(_run())
