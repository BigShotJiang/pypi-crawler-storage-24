from neurovault.cognitive.advanced_llm import AdvancedLLMConsolidation


class _UnavailableClient:
    def is_available(self):
        return False


def test_advanced_llm_fallback_mode():
    engine = AdvancedLLMConsolidation(client=_UnavailableClient())
    result = engine.chain_of_thought_insight(
        memories=[{"content": "Working on distributed sync architecture"}],
        entities=["sync", "architecture"],
        relationships=[],
    )
    assert result["llm_used"] is False
    assert "Knowledge pattern" in result["insight"]

    quality = engine.quality_score_insight("test insight")
    assert quality == 0.5

    cross = engine.cross_domain_association(
        {"id": "a", "label": "A", "memory_samples": ["one"]},
        {"id": "b", "label": "B", "memory_samples": ["two"]},
    )
    assert cross is None
