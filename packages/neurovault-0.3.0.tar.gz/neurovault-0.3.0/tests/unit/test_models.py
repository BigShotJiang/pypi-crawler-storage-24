from neurovault.models import EmotionalValence, Entity, MemoryTier


def test_entity_id_deterministic():
    e1 = Entity(name="Python", entity_type="TECHNOLOGY")
    e2 = Entity(name="Python", entity_type="TECHNOLOGY")
    assert e1.id == e2.id


def test_entity_id_differs():
    e1 = Entity(name="Python", entity_type="TECHNOLOGY")
    e2 = Entity(name="React", entity_type="TECHNOLOGY")
    assert e1.id != e2.id


def test_entity_canonical():
    e = Entity(name="  Python  ", entity_type="TECHNOLOGY")
    assert e.canonical_name == "python"


def test_emotional_modifier():
    calm = EmotionalValence(valence=0, arousal=0)
    assert calm.importance_modifier == 1.0
    intense = EmotionalValence(valence=0.5, arousal=1.0)
    assert intense.importance_modifier == 1.5


def test_memory_tiers():
    assert MemoryTier.WORKING.value == "working"
    assert MemoryTier.ARCHIVE.value == "archive"
