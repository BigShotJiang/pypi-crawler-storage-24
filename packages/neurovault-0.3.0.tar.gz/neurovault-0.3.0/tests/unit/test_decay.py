from neurovault.cognitive.decay import ebbinghaus_retention, next_review_time_ms, temporal_weight


def test_ebbinghaus_retention_floor():
    value = ebbinghaus_retention(0.1, hours_since_last_access=24 * 365, reinforcement_count=0)
    assert value >= 0.01


def test_ebbinghaus_retention_reinforcement():
    low = ebbinghaus_retention(0.8, hours_since_last_access=72, reinforcement_count=1)
    high = ebbinghaus_retention(0.8, hours_since_last_access=72, reinforcement_count=8)
    assert high >= low


def test_temporal_weight_bands():
    now = 1_000_000
    assert temporal_weight(now - 1_000, now) == 1.0
    assert temporal_weight(now - (2 * 3600 * 1000), now) == 0.8


def test_next_review_time_increases():
    base = 1_700_000_000_000
    t1 = next_review_time_ms(0, base)
    t2 = next_review_time_ms(3, base)
    assert t2 > t1
