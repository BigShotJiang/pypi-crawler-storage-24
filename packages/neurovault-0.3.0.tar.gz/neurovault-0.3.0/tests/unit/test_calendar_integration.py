from types import SimpleNamespace
from unittest.mock import MagicMock

from neurovault.sensors.calendar_integration import CalendarIntegration


def test_surface_memories_for_event_calls_recall():
    recall = MagicMock(return_value=[])
    cal = CalendarIntegration(recall_fn=recall, entity_lookup_fn=MagicMock(return_value=[]))

    event = {"title": "Python review", "attendees": "Alice,Bob", "notes": ""}
    cal.surface_memories_for_event(event)

    assert recall.called


def test_check_and_notify_skips_duplicate_events():
    memory = SimpleNamespace(id=b"m1", content="Remember Alice", source="user")
    result = SimpleNamespace(memory=memory, score=0.9)

    cal = CalendarIntegration(
        recall_fn=MagicMock(return_value=[result]),
        entity_lookup_fn=MagicMock(return_value=[]),
    )
    cal.get_upcoming_events = MagicMock(
        return_value=[{"title": "Team sync", "start": "soon", "attendees": "Alice", "notes": ""}]
    )

    first = cal.check_and_notify()
    assert len(first) == 1
    assert first[0]["count"] == 1

    cal._last_check = 0  # bypass cooldown for deterministic duplicate check
    second = cal.check_and_notify()
    assert second == []
