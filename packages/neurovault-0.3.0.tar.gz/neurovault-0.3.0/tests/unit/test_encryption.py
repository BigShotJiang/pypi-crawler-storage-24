from neurovault.security.encryption import EncryptionManager


def test_key_derivation_is_deterministic(monkeypatch, tmp_path):
    manager = EncryptionManager(vault_dir=tmp_path, vault_name="test")

    salt = b"x" * manager.SALT_SIZE
    monkeypatch.setattr(manager, "_get_or_create_salt", lambda: salt)

    key1 = manager.derive_key("passphrase")
    key2 = manager.derive_key("passphrase")
    assert key1 == key2
    assert len(key1) == 64
