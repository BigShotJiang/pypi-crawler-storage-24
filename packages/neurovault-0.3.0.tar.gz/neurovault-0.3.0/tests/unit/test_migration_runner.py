import sqlite3

from neurovault.migrations.runner import MigrationRunner


def test_migration_runner_to_v03(tmp_path):
    db_path = tmp_path / "vault.db"
    conn = sqlite3.connect(db_path)
    conn.execute("CREATE TABLE IF NOT EXISTS schema_info (key TEXT PRIMARY KEY, value TEXT)")
    conn.execute("INSERT OR REPLACE INTO schema_info (key, value) VALUES ('version', '0.1.0')")
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS memories (
            id BLOB PRIMARY KEY,
            persona_id BLOB NOT NULL,
            content TEXT NOT NULL,
            source TEXT NOT NULL,
            importance REAL NOT NULL DEFAULT 0.5,
            metadata TEXT NOT NULL DEFAULT '{}',
            embedding BLOB,
            created_at INTEGER NOT NULL,
            is_active INTEGER NOT NULL DEFAULT 1
        )
        """
    )
    conn.commit()
    conn.close()

    runner = MigrationRunner(str(db_path))
    assert runner.migrate_to("0.3.0") is True
    assert runner.get_current_version() == "0.3.0"
