from neurovault.cognitive.hybrid_ner import HybridNERExtractor


def test_hybrid_ner_extract_returns_list():
    extractor = HybridNERExtractor()
    entities = extractor.extract("Alice met Bob at OpenAI in San Francisco on 2026-03-09.")

    assert isinstance(entities, list)
