from neurovault.cognitive.consolidation import ConsolidationEngine
from neurovault.cognitive.consolidation_strategy import ConsolidationStrategy
from neurovault.cognitive.consolidation_v3 import ConsolidationEngineV3


class _Config:
    def __init__(self, consolidation: dict, llm: dict):
        self.consolidation = consolidation
        self.llm = llm


class _Dummy:
    pass


def test_strategy_uses_baseline_when_llm_disabled():
    cfg = _Config(consolidation={"llm_enabled": False, "version": "v3"}, llm={"enabled": False})
    engine = ConsolidationStrategy.build(_Dummy(), _Dummy(), _Dummy(), cfg)
    assert isinstance(engine, ConsolidationEngine)


def test_strategy_prefers_requested_llm_version():
    cfg = _Config(consolidation={"llm_enabled": True, "version": "v3"}, llm={"enabled": True})
    engine = ConsolidationStrategy.build(_Dummy(), _Dummy(), _Dummy(), cfg)
    assert isinstance(engine, ConsolidationEngineV3)

