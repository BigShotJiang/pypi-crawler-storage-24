from neurovault.cognitive.ontology import OntologyEngine
from neurovault.storage import NeurovaultStorage


def test_bootstrap_taxonomy(tmp_path):
    db_path = tmp_path / "ontology.db"
    storage = NeurovaultStorage(db_path)
    storage.initialize_schema()

    engine = OntologyEngine(storage)
    inserted = engine.bootstrap_taxonomy()
    assert inserted > 0
    assert storage.get_concept_count() > 0


def test_query_expansion(tmp_path):
    db_path = tmp_path / "ontology.db"
    storage = NeurovaultStorage(db_path)
    storage.initialize_schema()

    engine = OntologyEngine(storage)
    engine.bootstrap_taxonomy()

    expanded = engine.expand_query_with_ontology(["Programming Language"])
    lowered = {x.lower() for x in expanded}
    assert "python" in lowered
    assert "javascript" in lowered
