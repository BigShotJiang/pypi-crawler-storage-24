from neurovault.cognitive.semantic_dedup import SemanticDeduplicator


class _FakeStorage:
    def __init__(self, rows):
        self._rows = rows

    def get_recent_embeddings(self, limit=20):
        return self._rows[:limit]


def test_detect_near_duplicate():
    storage = _FakeStorage(rows=[{"id": b"a", "embedding": [1.0, 0.0, 0.0]}])
    dedup = SemanticDeduplicator(storage, embedding_engine=None)
    result = dedup.check_duplicate("x", [0.9999, 0.0, 0.0])
    assert result is not None
    assert result["action"] == "skip"


def test_no_false_positive():
    storage = _FakeStorage(rows=[{"id": b"a", "embedding": [1.0, 0.0, 0.0]}])
    dedup = SemanticDeduplicator(storage, embedding_engine=None)
    result = dedup.check_duplicate("x", [0.0, 1.0, 0.0])
    assert result is None
