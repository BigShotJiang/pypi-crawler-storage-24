from neurovault.cognitive.embedding_router import EmbeddingRouter


def test_tfidf_fallback_router():
    router = EmbeddingRouter({"preferred_backend": "tfidf"})
    vec = router.embed("hello world")

    assert router.active_backend == "tfidf"
    assert len(vec) == 384
