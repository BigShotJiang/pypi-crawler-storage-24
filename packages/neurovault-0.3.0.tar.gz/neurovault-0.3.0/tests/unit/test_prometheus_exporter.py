from neurovault.observability.prometheus import PrometheusExporter


class _Engine:
    def stats(self):
        return {
            "memory_count": 12,
            "entity_count": 5,
            "relationship_count": 8,
            "cluster_count": 2,
            "insight_count": 3,
            "plugin_count": 1,
            "daemon_running": True,
            "tier_distribution": {"working": 4, "long_term": 8},
            "source_distribution": {"api": 6, "clipboard": 6},
            "pipeline": {"ingested": 10, "errors": 1},
        }


def test_prometheus_exporter_contains_core_metrics():
    exporter = PrometheusExporter(_Engine())
    text = exporter.generate_metrics()
    assert "neurovault_memories_total 12" in text
    assert "neurovault_entities_total 5" in text
    assert 'neurovault_memories_by_tier{tier="working"} 4' in text
    assert 'neurovault_memories_by_source{source="api"} 6' in text
