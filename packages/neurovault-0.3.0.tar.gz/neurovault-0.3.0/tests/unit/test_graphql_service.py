from neurovault.graphql_api import GraphQLService


class _Memory:
    def __init__(self, content, source="api", importance=0.6):
        self.id = b"\x00" * 31 + b"\x01"
        self.content = content
        self.source = source
        self.importance = importance


class _RecallResult:
    def __init__(self, content="hello"):
        self.memory = _Memory(content)
        self.score = 0.9
        self.match_type = "keyword"


class _Entity:
    def __init__(self):
        self.id = b"\x00" * 31 + b"\x02"
        self.name = "Python"
        self.entity_type = "TECHNOLOGY"
        self.importance = 0.8
        self.mention_count = 3


class _Engine:
    def stats(self):
        return {
            "memory_count": 1,
            "entity_count": 1,
            "relationship_count": 0,
            "cluster_count": 0,
            "insight_count": 0,
            "plugin_count": 0,
        }

    def recall(self, query, limit=10, mode="multi"):
        del query, limit, mode
        return [_RecallResult("GraphQL recall sample")]

    def get_entities(self, entity_type=None, limit=50):
        del entity_type, limit
        return [_Entity()]

    def ingest(self, content, source="graphql", importance=0.5, metadata=None):
        del source, importance, metadata
        return _Memory(content)


def test_graphql_service_query_stats_and_recall():
    service = GraphQLService(_Engine())
    res = service.execute("query { stats recall }", variables={"query": "GraphQL", "limit": 5})
    assert "data" in res
    assert "stats" in res["data"]
    assert "recall" in res["data"]
    assert len(res["data"]["recall"]) == 1


def test_graphql_service_mutation_ingest():
    service = GraphQLService(_Engine())
    res = service.execute(
        "mutation Ingest { ingest }",
        variables={"content": "GraphQL ingest mutation"},
    )
    assert "data" in res
    assert res["data"]["ingest"]["content"] == "GraphQL ingest mutation"
