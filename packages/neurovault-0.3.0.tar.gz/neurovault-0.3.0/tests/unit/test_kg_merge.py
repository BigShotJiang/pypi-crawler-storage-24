from neurovault.network.kg_merge import EntityResolver


def test_entity_resolver_exact_match():
    resolver = EntityResolver()
    result = resolver.resolve(
        [{"name": "Python", "entity_type": "TECHNOLOGY"}],
        [{"name": "Python", "entity_type": "TECHNOLOGY"}],
    )
    assert result[0]["confidence"] == 1.0
    assert result[0]["action"] == "merge"


def test_entity_resolver_abbreviation_match():
    resolver = EntityResolver()
    score = resolver._compute_similarity(
        {"name": "Sarah Chen", "entity_type": "PERSON"},
        {"name": "S. Chen", "entity_type": "PERSON"},
    )
    assert score >= 0.85


def test_entity_resolver_type_mismatch():
    resolver = EntityResolver()
    score = resolver._compute_similarity(
        {"name": "Python", "entity_type": "TECHNOLOGY"},
        {"name": "Python", "entity_type": "PERSON"},
    )
    assert score == 0.0
