from neurovault.sensors.document_parser import DocumentParser


def test_parse_markdown_file(tmp_path):
    parser = DocumentParser()
    path = tmp_path / "notes.md"
    path.write_text("# Title\n\nhello world", encoding="utf-8")

    parsed = parser.parse(path)

    assert parsed["format"] == "markdown"
    assert "hello world" in parsed["text"]


def test_can_parse_known_extensions():
    parser = DocumentParser()
    assert parser.can_parse("a.pdf")
    assert parser.can_parse("a.docx")
    assert parser.can_parse("a.pptx")
    assert parser.can_parse("a.html")
    assert parser.can_parse("a.md")
    assert not parser.can_parse("a.txt")
