from neurovault.cognitive.llm_client import OllamaClient


def test_ollama_client_unavailable_returns_empty():
    client = OllamaClient(base_url="http://127.0.0.1:99999")
    assert client.is_available() is False
    assert client.generate("test") == ""
    assert client.embed("test") == []
