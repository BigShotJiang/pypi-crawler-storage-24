from __future__ import annotations

"""Compatibility facade for the orderwave validation pipeline."""

from orderwave._validation import (
    BASELINE_THROUGHPUT_FLOOR,
    BYTES_PER_LOGGED_EVENT_BUDGET,
    CORE_SENSITIVITY_KNOBS,
    DEFAULT_PRESETS,
    DEFAULT_SENSITIVITY_KNOBS,
    DEFAULT_SENSITIVITY_SCALES,
    INVARIANT_FAILURE_COLUMNS,
    PHASE_ORDER,
    SOAK_PEAK_MEMORY_BUDGET_MB,
    ValidationPipelineResult,
    ValidationRun,
    benchmark_logging_modes,
    collect_invariant_failures,
    compare_validation_baseline,
    compute_run_metrics,
    evaluate_validation_results,
    extract_validation_baseline,
    load_validation_baseline,
    measure_performance,
    run_market_validation,
    run_reproducibility_checks,
    run_sensitivity_grid,
    run_validation_pipeline,
    summarize_sensitivity_grid,
    summarize_validation_grid,
    write_validation_baseline,
)
from orderwave._validation.metrics import reproducibility_failures as _reproducibility_failures
from orderwave._validation.metrics import table_nonfinite_failures as _table_nonfinite_failures
from orderwave._validation.reporting import write_acceptance_decision as _write_acceptance_decision
from orderwave._validation.reporting import write_validation_summary as _write_validation_summary
from orderwave._validation.run import _select_diagnostics_seeds

__all__ = [
    "BASELINE_THROUGHPUT_FLOOR",
    "BYTES_PER_LOGGED_EVENT_BUDGET",
    "CORE_SENSITIVITY_KNOBS",
    "DEFAULT_PRESETS",
    "DEFAULT_SENSITIVITY_KNOBS",
    "DEFAULT_SENSITIVITY_SCALES",
    "INVARIANT_FAILURE_COLUMNS",
    "PHASE_ORDER",
    "SOAK_PEAK_MEMORY_BUDGET_MB",
    "ValidationPipelineResult",
    "ValidationRun",
    "benchmark_logging_modes",
    "collect_invariant_failures",
    "compare_validation_baseline",
    "compute_run_metrics",
    "evaluate_validation_results",
    "extract_validation_baseline",
    "load_validation_baseline",
    "measure_performance",
    "run_market_validation",
    "run_reproducibility_checks",
    "run_sensitivity_grid",
    "run_validation_pipeline",
    "summarize_sensitivity_grid",
    "summarize_validation_grid",
    "write_validation_baseline",
]
