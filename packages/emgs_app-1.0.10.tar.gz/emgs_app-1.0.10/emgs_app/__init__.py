"""EMGS PyQt6 application (clean rewrite).

Run with:
    python -m emgs_app
"""

from __future__ import annotations

import sys

__all__ = ["__version__"]

# Safety: never write __pycache__/bytecode into the checked-out repo / installed package.
# This avoids "accidental updates" to a git checkout when running `emgs` or `python -m emgs_app`.
sys.dont_write_bytecode = True

__version__ = "1.0.10"

