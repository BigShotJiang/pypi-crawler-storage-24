from smart_bot_factory.i18n.translator import translate


def _split(value: str) -> list[str]:
    return [part.strip() for part in value.split("|")]


def test_calendar_weekdays_short_has_7_items_ru() -> None:
    value = translate("common.calendar.weekdays_short", lang="ru")
    assert len(_split(value)) == 7


def test_calendar_weekdays_short_has_7_items_lt() -> None:
    value = translate("common.calendar.weekdays_short", lang="lt")
    assert len(_split(value)) == 7


def test_calendar_months_short_has_12_items_ru() -> None:
    value = translate("common.calendar.months_short", lang="ru")
    assert len(_split(value)) == 12


def test_calendar_months_short_has_12_items_lt() -> None:
    value = translate("common.calendar.months_short", lang="lt")
    assert len(_split(value)) == 12

