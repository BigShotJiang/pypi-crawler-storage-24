import json
from importlib import resources
from typing import Any


def _load_locale_json(lang: str) -> dict[str, str]:
    locale_path = resources.files("smart_bot_factory.i18n") / "locales" / f"{lang}.json"
    raw = locale_path.read_text(encoding="utf-8")
    data: Any = json.loads(raw)
    if not isinstance(data, dict):
        raise TypeError(f"Locale JSON must be an object: {lang}")
    invalid = [k for k, v in data.items() if not isinstance(k, str) or not isinstance(v, str)]
    if invalid:
        raise TypeError(f"Locale JSON must be string->string mapping: {lang}")
    return data


def test_locales_have_same_keyset() -> None:
    ru = _load_locale_json("ru")
    lt = _load_locale_json("lt")

    ru_keys = set(ru.keys())
    lt_keys = set(lt.keys())

    only_ru = sorted(ru_keys - lt_keys)
    only_lt = sorted(lt_keys - ru_keys)

    assert only_ru == [], f"Missing in lt.json: {only_ru[:50]}"
    assert only_lt == [], f"Missing in ru.json: {only_lt[:50]}"

