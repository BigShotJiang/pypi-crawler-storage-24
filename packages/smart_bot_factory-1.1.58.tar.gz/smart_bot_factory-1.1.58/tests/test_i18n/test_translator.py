import json

import pytest

from smart_bot_factory.i18n import TranslationMissingError, translate


def test_translate_existing_key_ru():
    assert isinstance(translate("error.processing_generic", lang="ru"), str)


def test_translate_existing_key_lt():
    assert isinstance(translate("error.processing_generic", lang="lt"), str)


def test_translate_missing_key_raises():
    with pytest.raises(TranslationMissingError):
        translate("error.__missing__", lang="ru")


def test_locales_have_same_keys():
    from importlib import resources

    ru = json.loads((resources.files("smart_bot_factory.i18n") / "locales" / "ru.json").read_text(encoding="utf-8"))
    lt = json.loads((resources.files("smart_bot_factory.i18n") / "locales" / "lt.json").read_text(encoding="utf-8"))

    assert set(ru.keys()) == set(lt.keys())
