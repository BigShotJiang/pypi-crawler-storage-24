import time
from collections import deque
from datetime import datetime
from unittest.mock import AsyncMock, Mock, patch

import pytest
from aiogram.types import Chat, Message, User

from smart_bot_factory.handlers.middlewares.rate_limit import RateLimitMiddleware


class TestRateLimitMiddleware:
    def test_init_default_params(self):
        """Тест дефолтных параметров"""
        mw = RateLimitMiddleware()
        assert mw.max_messages == 3
        assert mw.window_seconds == 10

    def test_init_custom_params(self):
        """Тест кастомных параметров"""
        mw = RateLimitMiddleware(max_messages=5, window_seconds=30)
        assert mw.max_messages == 5
        assert mw.window_seconds == 30

    @pytest.mark.asyncio
    async def test_caption_passes_through(self):
        """Тест что сообщение с caption (фото с подписью) проходит rate limit"""
        mw = RateLimitMiddleware()
        mock_handler = AsyncMock(return_value="ok")

        event = Mock()
        event.from_user = Mock()
        event.from_user.id = 12345
        event.text = None
        event.caption = "Вопрос по фото"

        with patch("smart_bot_factory.handlers.middlewares.rate_limit.ctx") as mock_ctx:
            mock_ctx.admin_manager = Mock()
            mock_ctx.admin_manager.is_admin = Mock(return_value=False)

            await mw(mock_handler, event, {})
            mock_handler.assert_called_once()

    @pytest.mark.asyncio
    async def test_no_text_no_caption_ignored(self):
        """Тест что сообщение без текста и подписи игнорируется"""
        mw = RateLimitMiddleware()
        mock_handler = AsyncMock()

        event = Message(
            message_id=1,
            date=datetime.now(),
            chat=Chat(id=1, type="private"),
            from_user=User(id=12345, is_bot=False, first_name="Test"),
            text=None,
            caption=None,
        )

        await mw(mock_handler, event, {})
        mock_handler.assert_not_called()

    def test_cleanup_stale_entries(self):
        """Тест очистки устаревших записей"""
        mw = RateLimitMiddleware(window_seconds=10)

        old_time = time.monotonic() - 200
        mw._timestamps[111] = deque([old_time])
        mw._timestamps[222] = deque([time.monotonic()])

        mw._last_cleanup = 0
        mw._maybe_cleanup()

        assert 111 not in mw._timestamps
        assert 222 in mw._timestamps
