"""Тесты для admin_chat_handlers.check_and_handle_admin_chat"""

from unittest.mock import AsyncMock, Mock, patch

import pytest
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from smart_bot_factory.handlers.routers.admin_chat import check_and_handle_admin_chat
from smart_bot_factory.handlers.types.states import UserStates


@pytest.mark.asyncio
async def test_check_and_handle_admin_chat_active_conversation():
    message = Mock(spec=Message)
    message.from_user = Mock()
    message.from_user.id = 123
    message.text = "hello"
    message.answer = AsyncMock()

    state = Mock(spec=FSMContext)
    state.set_state = AsyncMock()
    state.update_data = AsyncMock()

    conversation = {"id": "conv-1", "admin_id": 42}
    session_info = {"id": "sess-1"}

    with patch("smart_bot_factory.handlers.routers.admin_chat.ctx") as mock_ctx:
        mock_ctx.conversation_manager = AsyncMock()
        mock_ctx.conversation_manager.is_user_in_admin_chat = AsyncMock(return_value=conversation)
        mock_ctx.conversation_manager.forward_message_to_admin = AsyncMock()

        mock_ctx.supabase_client = AsyncMock()
        mock_ctx.supabase_client.get_active_session = AsyncMock(return_value=session_info)
        mock_ctx.supabase_client.add_message = AsyncMock()

        handled = await check_and_handle_admin_chat(message, state)

        assert handled is True
        state.set_state.assert_awaited_once_with(UserStates.admin_chat)
        mock_ctx.conversation_manager.forward_message_to_admin.assert_awaited_once()
        mock_ctx.supabase_client.add_message.assert_awaited_once()


@pytest.mark.asyncio
async def test_check_and_handle_admin_chat_no_conversation():
    message = Mock(spec=Message)
    message.from_user = Mock()
    message.from_user.id = 123
    message.text = "hello"

    state = Mock(spec=FSMContext)

    with patch("smart_bot_factory.handlers.routers.admin_chat.ctx") as mock_ctx:
        mock_ctx.conversation_manager = AsyncMock()
        mock_ctx.conversation_manager.is_user_in_admin_chat = AsyncMock(return_value=None)

        handled = await check_and_handle_admin_chat(message, state)

        assert handled is False
