"""
Тесты для PromptWatcher.
"""

import asyncio
import time
from pathlib import Path
from unittest.mock import AsyncMock, Mock, patch

import pytest

from smart_bot_factory.creation.prompt_watcher import PromptReloadHandler, PromptWatcher


class TestPromptReloadHandler:
    @pytest.fixture
    def mock_prompt_loader(self):
        loader = Mock()
        loader.reload_system_prompt = AsyncMock(return_value="New prompt content")
        return loader

    @pytest.fixture
    def handler(self, mock_prompt_loader):
        loop = asyncio.new_event_loop()
        try:
            yield PromptReloadHandler(mock_prompt_loader, loop=loop)
        finally:
            loop.close()

    @pytest.mark.asyncio
    async def test_init(self, mock_prompt_loader):
        loop = asyncio.get_running_loop()
        handler = PromptReloadHandler(mock_prompt_loader, loop=loop)
        assert handler.prompt_loader == mock_prompt_loader
        assert handler._pending_reloads == {}
        assert handler._debounce_delay == 0.5
        assert handler._max_reloads_per_minute == 10

    def test_on_modified_ignores_directory(self, handler):
        event = Mock()
        event.is_directory = True
        event.src_path = "/tmp/test_dir"
        handler.on_modified(event)
        assert len(handler._pending_reloads) == 0

    def test_on_modified_ignores_non_txt_files(self, handler):
        event = Mock()
        event.is_directory = False
        event.src_path = "/tmp/test.py"
        handler.on_modified(event)
        assert len(handler._pending_reloads) == 0

    def test_on_modified_ignores_temp_files(self, handler):
        for temp_file in [".test.txt", "test.txt~", "test.txt.swp"]:
            event = Mock()
            event.is_directory = False
            event.src_path = f"/tmp/{temp_file}"
            handler.on_modified(event)
        assert len(handler._pending_reloads) == 0

    @pytest.mark.asyncio
    async def test_debounced_reload_calls_reload_prompt(self, handler, mock_prompt_loader):
        await handler._debounced_reload("system_prompt.txt")
        mock_prompt_loader.reload_system_prompt.assert_called_once()

    @pytest.mark.asyncio
    async def test_debounced_reload_respects_rate_limit(self, handler, mock_prompt_loader):
        now = time.time()
        handler._reload_times = [now - i for i in range(10)]
        await handler._debounced_reload("system_prompt.txt")
        mock_prompt_loader.reload_system_prompt.assert_not_called()

    @pytest.mark.asyncio
    async def test_reload_prompt_success(self, handler, mock_prompt_loader):
        await handler._reload_prompt("system_prompt.txt")
        mock_prompt_loader.reload_system_prompt.assert_called_once()

    @pytest.mark.asyncio
    async def test_reload_prompt_handles_error(self, handler, mock_prompt_loader):
        mock_prompt_loader.reload_system_prompt.side_effect = Exception("Test error")
        await handler._reload_prompt("system_prompt.txt")
        mock_prompt_loader.reload_system_prompt.assert_called_once()


class TestPromptWatcher:
    @pytest.fixture
    def temp_prompts_dir(self, tmp_path: Path):
        prompts_dir = tmp_path / "prompts"
        prompts_dir.mkdir()
        return prompts_dir

    @pytest.fixture
    def mock_prompt_loader(self):
        loader = Mock()
        loader.reload_system_prompt = AsyncMock(return_value="New prompt")
        return loader

    @pytest.mark.asyncio
    async def test_init(self, temp_prompts_dir, mock_prompt_loader):
        loop = asyncio.get_running_loop()
        watcher = PromptWatcher(temp_prompts_dir, mock_prompt_loader, loop=loop)
        assert watcher.prompts_dir == temp_prompts_dir
        assert watcher.prompt_loader == mock_prompt_loader
        assert watcher.observer is None
        assert watcher._is_running is False

    @pytest.mark.asyncio
    async def test_start_with_nonexistent_dir(self, tmp_path, mock_prompt_loader):
        loop = asyncio.get_running_loop()
        watcher = PromptWatcher(tmp_path / "missing", mock_prompt_loader, loop=loop)
        watcher.start()
        assert watcher.observer is None
        assert watcher._is_running is False

    @pytest.mark.asyncio
    async def test_start_and_stop(self, temp_prompts_dir, mock_prompt_loader):
        loop = asyncio.get_running_loop()
        watcher = PromptWatcher(temp_prompts_dir, mock_prompt_loader, loop=loop)
        watcher.start()
        assert watcher.is_running() is True
        watcher.stop()
        assert watcher.is_running() is False

    @pytest.mark.asyncio
    async def test_integration_file_change_triggers_reload(self, temp_prompts_dir, mock_prompt_loader):
        loop = asyncio.get_running_loop()
        watcher = PromptWatcher(temp_prompts_dir, mock_prompt_loader, loop=loop)
        watcher.start()
        try:
            test_file = temp_prompts_dir / "system_prompt.txt"
            test_file.write_text("original", encoding="utf-8")
            await asyncio.sleep(0.5)
            test_file.write_text("modified", encoding="utf-8")
            await asyncio.sleep(1.2)
            assert mock_prompt_loader.reload_system_prompt.called
        finally:
            watcher.stop()


class TestBackwardCompatibility:
    def test_works_when_disabled(self):
        config = Mock()
        config.ENABLE_PROMPT_HOT_RELOAD = False
        assert config.ENABLE_PROMPT_HOT_RELOAD is False
