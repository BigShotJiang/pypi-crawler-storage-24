"""Тесты явной передачи зависимостей в event decorators."""

from pathlib import Path
from unittest.mock import AsyncMock, Mock

import pytest

from smart_bot_factory.event.decorators.admin import (
    prepare_dashboard_info,
    prepare_dashboard_info_with_deps,
    process_admin_event,
    process_admin_event_with_deps,
)
from smart_bot_factory.event.decorators.checks import check_event_already_processed_with_deps
from smart_bot_factory.event.decorators.db import update_event_result_with_deps
from smart_bot_factory.event.decorators.utils import EventDeps, get_supabase_client_or_raise, resolve_event_deps_from_ctx
from smart_bot_factory.utils.context import ctx


class TestEventDeps:
    def test_resolve_event_deps_from_ctx_raises_without_supabase(self):
        original_supabase = ctx.supabase_client
        original_bot = ctx.bot
        try:
            ctx.supabase_client = None
            ctx.bot = None
            with pytest.raises(RuntimeError, match="Supabase клиент не инициализирован"):
                resolve_event_deps_from_ctx()
        finally:
            ctx.supabase_client = original_supabase
            ctx.bot = original_bot

    def test_get_supabase_client_or_raise_uses_explicit_deps(self):
        fake_supabase = Mock()
        deps = EventDeps(supabase_client=fake_supabase, bot=None)
        resolved = get_supabase_client_or_raise(deps)
        assert resolved is fake_supabase

    @pytest.mark.asyncio
    async def test_check_event_already_processed_with_deps_uses_injected_client(self):
        query = Mock()
        query.eq.return_value = query
        query.in_.return_value = query
        query.is_.return_value = query
        query.execute.return_value = Mock(data=[])

        client = Mock()
        client.table.return_value = query

        supabase_client = Mock()
        supabase_client.client = client
        supabase_client._with_bot_id = Mock(return_value=query)

        deps = EventDeps(supabase_client=supabase_client, bot=None)
        result = await check_event_already_processed_with_deps(deps, "test_event", user_id=1, session_id=None)
        assert result is False

    @pytest.mark.asyncio
    async def test_update_event_result_with_deps_raises_on_update_failure(self):
        query = Mock()
        query.eq.return_value = query
        query.execute.side_effect = RuntimeError("db down")

        client = Mock()
        client.table.return_value = query

        supabase_client = Mock()
        supabase_client.client = client
        supabase_client._with_bot_id = Mock(return_value=query)

        deps = EventDeps(supabase_client=supabase_client, bot=None)

        with pytest.raises(Exception, match="Failed to update event result"):
            await update_event_result_with_deps(
                deps=deps,
                event_id="evt_1",
                status="failed",
                result_data=None,
                error_message=None,
            )

    @pytest.mark.asyncio
    async def test_process_admin_event_wrapper_raises_without_supabase(self):
        original_supabase = ctx.supabase_client
        original_bot = ctx.bot
        try:
            ctx.supabase_client = None
            ctx.bot = None
            with pytest.raises(RuntimeError, match="Supabase клиент не инициализирован"):
                await process_admin_event({"id": 1, "event_type": "admin_event", "event_data": '{"message":"hello","files":[]}'})
        finally:
            ctx.supabase_client = original_supabase
            ctx.bot = original_bot

    @pytest.mark.asyncio
    async def test_process_admin_event_with_deps_uses_injected_deps(self):
        supabase_client = Mock()
        supabase_client.download_event_file = AsyncMock(side_effect=RuntimeError("download failed"))
        deps = EventDeps(supabase_client=supabase_client, bot=Mock())
        Path("temp/admin_events/1").mkdir(parents=True, exist_ok=True)

        event_payload = {
            "id": 1,
            "event_type": "admin_event",
            "event_data": '{"segment":"all","message":"hello","files":[{"storage_path":"a/b","original_name":"f.txt","stage":"with_message","type":"document"}]}',
        }
        result = await process_admin_event_with_deps(deps, event_payload)
        assert "error" in result

    @pytest.mark.asyncio
    async def test_prepare_dashboard_info_with_deps_uses_injected_supabase(self):
        query = Mock()
        query.select.return_value = query
        query.eq.return_value = query
        query.execute.return_value = Mock(data=[{"username": "alice"}])

        client = Mock()
        client.table.return_value = query

        supabase_client = Mock()
        supabase_client.client = client
        supabase_client._with_bot_id = Mock(return_value=query)

        deps = EventDeps(supabase_client=supabase_client, bot=None)
        info = await prepare_dashboard_info_with_deps(deps, "{username} did action", "Title", 123)
        assert info["title"] == "Title"
        assert "alice" in info["description"]

    @pytest.mark.asyncio
    async def test_prepare_dashboard_info_wrapper_raises_without_supabase(self):
        original_supabase = ctx.supabase_client
        original_bot = ctx.bot
        try:
            ctx.supabase_client = None
            ctx.bot = None
            with pytest.raises(RuntimeError, match="Supabase клиент не инициализирован"):
                await prepare_dashboard_info("{username}", "Title", 123)
        finally:
            ctx.supabase_client = original_supabase
            ctx.bot = original_bot
