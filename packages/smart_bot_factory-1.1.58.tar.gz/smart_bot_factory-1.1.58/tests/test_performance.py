"""
Проверка производительности после рефакторинга.
"""

import time

from smart_bot_factory.handlers.helpers.converters import MessageConverter
from smart_bot_factory.models import parse_ai_metadata_safe


def test_converter_performance():
    """Конвертация не должна быть медленной."""
    messages = [{"role": "user", "content": f"Message {i}"} for i in range(100)]

    start = time.perf_counter()
    for msg in messages:
        MessageConverter.openai_to_langchain(msg)
    elapsed = time.perf_counter() - start

    assert elapsed < 0.1, f"Слишком медленно: {elapsed}s"


def test_metadata_parsing_performance():
    """Парсинг метаданных не должен быть медленным."""
    data = {
        "этап": "test",
        "качество": 5,
        "события": [{"тип": f"event_{i}", "инфо": "test"} for i in range(10)],
    }

    start = time.perf_counter()
    for _ in range(100):
        parse_ai_metadata_safe(data)
    elapsed = time.perf_counter() - start

    assert elapsed < 0.5, f"Слишком медленно: {elapsed}s"
