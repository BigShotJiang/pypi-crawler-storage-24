import asyncio
import json
import logging
from typing import Optional

from ...utils.context import ctx
from ...event.decorators.notifications import notify_admins_about_event

logger = logging.getLogger(__name__)


def _get_event_handlers():
    from ...event.decorators.registry import (
        _event_handlers,
        _global_handlers,
        _scheduled_tasks,
        get_router_manager,
    )

    router_manager = get_router_manager()
    if router_manager:
        event_handlers = router_manager.get_event_handlers()
        scheduled_tasks = router_manager.get_scheduled_tasks()
        global_handlers = router_manager.get_global_handlers()
        logger.debug(
            f"🔍 RouterManager найден: {len(event_handlers)} событий, {len(scheduled_tasks)} задач, {len(global_handlers)} глобальных обработчиков"
        )
        logger.debug(f"🔍 Доступные scheduled_tasks: {list(scheduled_tasks.keys())}")
    else:
        event_handlers = _event_handlers
        scheduled_tasks = _scheduled_tasks
        global_handlers = _global_handlers
        logger.warning("⚠️ RouterManager не найден, используем старые декораторы")
        logger.debug(f"🔍 Старые scheduled_tasks: {list(scheduled_tasks.keys())}")

    return event_handlers, scheduled_tasks, global_handlers


def _find_handler_for_event(event_type: str, event_handlers: dict, scheduled_tasks: dict):
    handler_info = event_handlers.get(event_type)
    if handler_info is not None:
        return "event", handler_info
    task_info = scheduled_tasks.get(event_type)
    if task_info is not None:
        return "task", task_info
    return None, None


async def _check_event_already_executed(event_type: str, user_id: int, supabase_client) -> bool:
    check_query = (
        supabase_client.client.table("scheduled_events")
        .select("id, status, session_id")
        .eq("event_type", event_type)
        .eq("user_id", user_id)
        .eq("status", "completed")
    )
    check_query = supabase_client._with_bot_id(check_query)
    existing = check_query.execute()
    count = len(existing.data) if existing.data else 0
    logger.debug(f"Проверка БД: найдено {count} выполненных событий '{event_type}' для user_id={user_id}")
    if existing.data:
        logger.debug(f"Событие '{event_type}' уже выполнялось для пользователя {user_id}, пропускаем")
        return True
    return False


def _create_event_record(
    event_type: str,
    event_info: str,
    user_id: int,
    session_id: Optional[str],
    status: str,
    result: Optional[dict] = None,
    error: Optional[str] = None,
    supabase_client=None,
) -> dict:
    from datetime import datetime, timezone

    event_record = {
        "event_type": event_type,
        "event_category": "user_event",
        "user_id": user_id,
        "event_data": event_info,
        "scheduled_at": None,
        "status": status,
        "session_id": session_id,
    }
    if status == "completed":
        event_record["executed_at"] = datetime.now(timezone.utc).isoformat()
        event_record["result_data"] = json.dumps(result, ensure_ascii=False) if result else None
        if isinstance(result, dict) and "info" in result:
            event_record["info_dashboard"] = json.dumps(result["info"], ensure_ascii=False)
            logger.debug(f"Дашборд данные добавлены: {result['info'].get('title', 'N/A')}")
    elif status == "failed":
        event_record["last_error"] = error
    if supabase_client and supabase_client.bot_id:
        event_record["bot_id"] = supabase_client.bot_id
    return event_record


async def _execute_and_save_event(
    handler_type: str,
    event_type: str,
    event_info: str,
    user_id: int,
    handler_info: dict,
    supabase_client,
    session_id: Optional[str] = None,
    defer_save: bool = False,
) -> tuple[str | None | dict, bool]:
    from ...event.decorators.execution import execute_event_handler
    from ...event.decorators.scheduling import execute_scheduled_task_from_event

    logger.debug(f"Немедленно выполняем {handler_type}: '{event_type}'")
    try:
        if handler_type == "event":
            result = await execute_event_handler(event_type, user_id, event_info)
        elif handler_type == "task":
            result = await execute_scheduled_task_from_event(user_id, event_type, event_info, session_id)
        else:
            raise ValueError(f"Неизвестный тип обработчика: {handler_type}")

        event_record = _create_event_record(
            event_type=event_type,
            event_info=event_info,
            user_id=user_id,
            session_id=session_id,
            status="completed",
            result=result,
            supabase_client=supabase_client,
        )
        if defer_save:
            logger.debug(f"Событие '{event_type}' подготовлено для батч-сохранения")
            return event_record, handler_info.get("notify", False)

        response = supabase_client.client.table("scheduled_events").insert(event_record).execute()
        event_id = response.data[0]["id"]
        logger.debug(f"Событие {event_id} выполнено и сохранено как completed")
        return event_id, handler_info.get("notify", False)
    except Exception as e:
        logger.error(f"   ❌ Ошибка выполнения события: {e}")
        event_record = _create_event_record(
            event_type=event_type,
            event_info=event_info,
            user_id=user_id,
            session_id=session_id,
            status="failed",
            error=str(e),
            supabase_client=supabase_client,
        )
        try:
            supabase_client.client.table("scheduled_events").insert(event_record).execute()
            logger.debug("Ошибка сохранена в БД")
        except Exception as db_error:
            logger.error(f"Не удалось сохранить ошибку в БД: {db_error}")
        raise


async def _handle_scheduled_task(
    event_type: str,
    event_info: str,
    user_id: int,
    session_id: str,
    scheduled_tasks: dict,
    supabase_client,
) -> tuple[bool, bool]:
    from ...event.decorators.scheduling import execute_scheduled_task_from_event

    task_info = scheduled_tasks.get(event_type, {})
    send_ai_response_flag = task_info.get("send_ai_response", True)
    logger.debug(f"Планируем scheduled_task: '{event_type}', send_ai_response={send_ai_response_flag}")
    if not send_ai_response_flag:
        logger.debug(f"Задача '{event_type}' запретила отправку сообщения от ИИ")

    try:
        result = await execute_scheduled_task_from_event(user_id, event_type, event_info, session_id)
        event_id = result.get("event_id", "unknown")
        should_notify = result.get("notify", False)
        logger.debug(f"Задача запланирована: {event_id}")
        return send_ai_response_flag, should_notify
    except Exception as e:
        if "once_only=True" in str(e):
            logger.debug(f"Задача '{event_type}' уже запланирована, пропускаем")
            return True, False
        logger.error(f"   ❌ Ошибка планирования scheduled_task '{event_type}': {e}")
        raise


async def _handle_global_handler(event_type: str, event_info: str, global_handlers: dict) -> bool:
    from ...event.decorators.scheduling import execute_global_handler_from_event

    logger.debug(f"Планируем global_handler: '{event_type}'")
    try:
        result = await execute_global_handler_from_event(event_type, event_info)
        event_id = result.get("event_id", "unknown")
        should_notify = result.get("notify", False)
        logger.debug(f"Глобальное событие запланировано: {event_id}")
        return should_notify
    except Exception as e:
        if "once_only=True" in str(e):
            logger.debug(f"Глобальное событие '{event_type}' уже запланировано, пропускаем")
            return False
        logger.error(f"   ❌ Ошибка планирования global_handler '{event_type}': {e}")
        raise


async def _handle_event_notification(
    handler_type: str,
    handler_info: dict,
    should_notify: bool,
    user_id: int,
    event: dict,
):
    if handler_type == "task":
        notify_time = handler_info.get("notify_time", "after")
        if notify_time == "before" and should_notify:
            await notify_admins_about_event(user_id, event)
            logger.debug("Админы уведомлены (notify_time=before)")
        elif notify_time == "after":
            logger.debug("Уведомление будет отправлено после выполнения задачи")
    else:
        if should_notify:
            await notify_admins_about_event(user_id, event)
            logger.debug("Админы уведомлены")


async def _process_single_event(
    event: dict,
    session_id: str,
    user_id: int,
    event_handlers: dict,
    scheduled_tasks: dict,
    global_handlers: dict,
    supabase_client,
    executed_events: Optional[set] = None,
    defer_save: bool = False,
) -> tuple[bool, dict | None]:
    event_type = event.get("тип", "")
    event_info = event.get("инфо", "")
    if not event_type:
        logger.warning(f"⚠️ Событие без типа: {event}")
        return True, None

    should_send_ai_response = True
    handler_type = None
    handler_info = None
    should_notify = False
    event_record = None
    if executed_events is None:
        executed_events = set()

    try:
        handler_type, handler_info = _find_handler_for_event(event_type, event_handlers, scheduled_tasks)
        if handler_info:
            once_only = handler_info.get("once_only", True)
            send_ai_response_flag = handler_info.get("send_ai_response", True)
            should_notify = handler_info.get("notify", False)
            if not send_ai_response_flag:
                should_send_ai_response = False

            if once_only:
                if event_type in executed_events:
                    return should_send_ai_response, None
                if await _check_event_already_executed(event_type, user_id, supabase_client):
                    return should_send_ai_response, None

            try:
                result = await _execute_and_save_event(
                    handler_type=handler_type,
                    event_type=event_type,
                    event_info=event_info,
                    user_id=user_id,
                    session_id=session_id,
                    handler_info=handler_info,
                    supabase_client=supabase_client,
                    defer_save=defer_save,
                )
                if isinstance(result, tuple):
                    event_data, should_notify = result
                    if defer_save and isinstance(event_data, dict):
                        event_record = event_data
            except Exception:
                return should_send_ai_response, None
        elif event_type in scheduled_tasks:
            try:
                send_ai_response_flag, should_notify = await _handle_scheduled_task(
                    event_type=event_type,
                    event_info=event_info,
                    user_id=user_id,
                    session_id=session_id,
                    scheduled_tasks=scheduled_tasks,
                    supabase_client=supabase_client,
                )
                if not send_ai_response_flag:
                    should_send_ai_response = False
            except Exception:
                return should_send_ai_response, None
        elif event_type in global_handlers:
            try:
                should_notify = await _handle_global_handler(event_type, event_info, global_handlers)
            except Exception:
                return should_send_ai_response, None
        else:
            logger.warning(f"   ⚠️ Обработчик '{event_type}' не найден среди зарегистрированных")
    except ValueError as e:
        logger.warning(f"   ⚠️ Обработчик/задача не найдены: {e}")
    except Exception as e:
        logger.error(f"   ❌ Ошибка в обработчике/задаче: {e}")
        logger.exception("   Стек ошибки:")

    if handler_info and handler_type and not defer_save:
        await _handle_event_notification(handler_type, handler_info, should_notify, user_id, event)
    return should_send_ai_response, event_record


async def process_file_events(
    events: list,
    user_id: int,
    session_id: str,
    chat_id: int,
    supabase_client,
) -> list:
    from ...file_router.execution import execute_file_event_handler
    from ...file_router.sender import FileSender

    event_handlers, _, _ = _get_event_handlers()
    file_senders = []

    events_to_check = set()
    for event in events:
        event_type = event.get("тип", "")
        if not event_type:
            continue
        handler_info = event_handlers.get(event_type, {})
        if handler_info.get("file_handler") and handler_info.get("once_only", False):
            events_to_check.add(event_type)

    executed_events = set()
    if events_to_check:
        executed_events = await supabase_client.batch_check_events_executed(
            event_types=list(events_to_check),
            user_id=user_id,
        )

    events_to_save = []
    for event in events:
        event_type = event.get("тип", "")
        event_info = event.get("инфо", "")
        if not event_type:
            continue

        handler_info = event_handlers.get(event_type, {})
        if not handler_info.get("file_handler"):
            continue

        try:
            once_only = handler_info.get("once_only", False)
            if once_only:
                if event_type in executed_events:
                    continue
                if await _check_event_already_executed(event_type, user_id, supabase_client):
                    continue

            file_sender = FileSender(user_id=user_id, chat_id=chat_id)
            await execute_file_event_handler(event_type, file_sender, user_id, event_info)
            if file_sender.has_files():
                file_senders.append(file_sender)

            event_record = _create_event_record(
                event_type=event_type,
                event_info=event_info,
                user_id=user_id,
                session_id=session_id,
                status="completed",
                result={"file_sender": "created"},
                supabase_client=supabase_client,
            )
            events_to_save.append(event_record)
        except Exception as e:
            logger.error(f"❌ Ошибка обработки файлового события '{event_type}': {e}")
            logger.exception("Стек ошибки:")

    if events_to_save:
        try:
            await supabase_client.batch_insert_events(events_to_save)
        except Exception as e:
            logger.error(f"❌ Ошибка батч-INSERT файловых событий: {e}")
            logger.exception("Стек ошибки:")
    return file_senders


async def process_events(session_id: str, events: list, user_id: int) -> bool:
    custom_processor = getattr(ctx, "custom_event_processor", None) or getattr(ctx, "custom_event_proceses", None)
    if custom_processor:
        processor_name = getattr(custom_processor, "__name__", type(custom_processor).__name__)
        logger.info(f"🔄 Используется кастомная обработка событий: {processor_name}")
        await custom_processor(session_id, events, user_id)
        return True

    should_send_ai_response = True
    event_handlers, scheduled_tasks, global_handlers = _get_event_handlers()

    regular_events = []
    for event in events:
        event_type = event.get("тип", "")
        handler_info = event_handlers.get(event_type, {})
        if not handler_info.get("file_handler"):
            regular_events.append(event)

    events_to_check = set()
    for event in regular_events:
        event_type = event.get("тип", "")
        if not event_type:
            continue
        _, handler_info = _find_handler_for_event(event_type, event_handlers, scheduled_tasks)
        if handler_info and handler_info.get("once_only", True):
            events_to_check.add(event_type)

    executed_events = set()
    if events_to_check:
        executed_events = await ctx.supabase_client.batch_check_events_executed(event_types=list(events_to_check), user_id=user_id)

    events_to_save = []
    events_notifications = []
    for event in regular_events:
        try:
            event_should_send, event_record = await _process_single_event(
                event=event,
                session_id=session_id,
                user_id=user_id,
                event_handlers=event_handlers,
                scheduled_tasks=scheduled_tasks,
                global_handlers=global_handlers,
                supabase_client=ctx.supabase_client,
                executed_events=executed_events,
                defer_save=True,
            )
            if not event_should_send:
                should_send_ai_response = False
            if event_record:
                events_to_save.append(event_record)
                event_type = event.get("тип", "")
                handler_info = event_handlers.get(event_type, {})
                if handler_info and handler_info.get("notify", False):
                    handler_type, _ = _find_handler_for_event(event_type, event_handlers, scheduled_tasks)
                    events_notifications.append((event_record, handler_type, handler_info, user_id, event))
        except Exception as e:
            logger.error(f"❌ Ошибка обработки события {event}: {e}")
            logger.exception("Стек ошибки:")

    if events_to_save:
        try:
            await ctx.supabase_client.batch_insert_events(events_to_save)
            for event_record, handler_type, handler_info, user_id_notif, event_notif in events_notifications:
                try:
                    await _handle_event_notification(handler_type, handler_info, True, user_id_notif, event_notif)
                except Exception as e:
                    logger.error(f"Ошибка отправки уведомления для события {event_record.get('event_type', 'unknown')}: {e}")
        except Exception as e:
            logger.error(f"❌ Ошибка батч-INSERT событий: {e}")
            logger.exception("Стек ошибки:")

    logger.debug(f"Итоговый флаг send_ai_response: {should_send_ai_response}")
    return should_send_ai_response


async def cleanup_expired_conversations():
    while True:
        try:
            await asyncio.sleep(300)
            await ctx.conversation_manager.cleanup_expired_conversations()
        except Exception:
            pass
