import logging
import re
import time
from collections import defaultdict, deque
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import Message, TelegramObject

from ...utils.context import ctx

logger = logging.getLogger(__name__)


class RateLimitMiddleware(BaseMiddleware):
    """Middleware: rate-limit по user_id + игнорирование не-текстовых сообщений."""

    def __init__(self, max_messages: int = 3, window_seconds: int = 10):
        super().__init__()
        self.max_messages = max_messages
        self.window_seconds = window_seconds
        self._timestamps: dict[int, deque[float]] = defaultdict(deque)
        self._last_cleanup: float = time.monotonic()
        self._cleanup_interval: float = 300.0  # очистка раз в 5 минут

    def _maybe_cleanup(self):
        """Периодически удаляет устаревшие записи для неактивных пользователей"""
        now = time.monotonic()
        if now - self._last_cleanup < self._cleanup_interval:
            return
        self._last_cleanup = now
        stale_uids = [uid for uid, q in self._timestamps.items() if not q or q[-1] <= now - self.window_seconds * 10]
        for uid in stale_uids:
            del self._timestamps[uid]
        if stale_uids:
            logger.debug(f"🧹 Очищено {len(stale_uids)} устаревших записей rate limit")

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        if not isinstance(event, Message) or not event.from_user:
            return await handler(event, data)

        self._maybe_cleanup()

        # Берём текст из text или caption (фото/документы с подписью)
        user_text = event.text or event.caption
        if not user_text:
            logger.debug(f"🚫 Игнорируем сообщение без текста и подписи от {event.from_user.id}")
            return

        if user_text.startswith("/"):
            return await handler(event, data)

        # Игнорируем сообщения без букв/цифр (emoji, стикеры-текст и т.д.)
        if not re.search(r"\w", user_text):
            logger.debug(f"🚫 Игнорируем emoji-сообщение от {event.from_user.id}: '{user_text}'")
            return

        if ctx.admin_manager and ctx.admin_manager.is_admin(event.from_user.id):
            return await handler(event, data)

        now = time.monotonic()
        uid = event.from_user.id
        q = self._timestamps[uid]

        while q and q[0] <= now - self.window_seconds:
            q.popleft()

        if len(q) >= self.max_messages:
            logger.warning(f"🛑 Rate limit: пользователь {uid} превысил {self.max_messages} сообщений за {self.window_seconds}с")
            return

        q.append(now)
        return await handler(event, data)
