from typing import Any, Awaitable, Callable, Dict

from aiogram.types import TelegramObject
from aiogram.utils.chat_action import ChatActionMiddleware

from ..types.states import UserStates


class ConditionalChatActionMiddleware(ChatActionMiddleware):
    """
    ChatActionMiddleware, который пропускает typing-анимацию
    для сообщений в состоянии UserStates.admin_chat.
    Для всех остальных сообщений ведёт себя как стандартный ChatActionMiddleware.
    """

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        state = data.get("state")

        if state is not None:
            # FSMContext.get_state() возвращает строку состояния
            current_state = await state.get_state()
            if current_state == UserStates.admin_chat.state:
                # В admin_chat не отправляем typing, просто вызываем handler
                return await handler(event, data)

        # Для всех остальных случаев работаем как обычный ChatActionMiddleware
        return await super().__call__(handler, event, data)
