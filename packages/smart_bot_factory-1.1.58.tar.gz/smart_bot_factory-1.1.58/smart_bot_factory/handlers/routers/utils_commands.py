import logging

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from ...i18n.translator import translate
from ...utils.context import ctx
from ..helpers.messaging import send_message

logger = logging.getLogger(__name__)

utils_router = Router()


@utils_router.message(Command("help"))
async def help_handler(message: Message):
    """Справка"""
    try:
        if ctx.admin_manager.is_admin(message.from_user.id):
            if ctx.admin_manager.is_in_admin_mode(message.from_user.id):
                lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
                help_text = translate("admin.help.text", lang=lang)
                await message.answer(help_text, parse_mode="Markdown")
                return

        help_text = await ctx.prompt_loader.load_help_message()
        await send_message(message, help_text)

    except Exception as e:
        logger.error(f"Ошибка загрузки справки: {e}")
        await send_message(
            message,
            "🤖 Ваш помощник готов к работе! Напишите /start для начала диалога.",
        )


@utils_router.message(Command("status"))
async def status_handler(message: Message):
    """Проверка статуса системы"""
    try:
        openai_status = await ctx.openai_client.check_api_health()
        prompts_status = await ctx.prompt_loader.validate_prompts()

        if ctx.admin_manager.is_admin(message.from_user.id):
            status_message = f"""
🔧 **Статус системы:**

OpenAI API: {"✅" if openai_status else "❌"}
Промпты: {"✅ " + str(sum(prompts_status.values())) + "/" + str(len(prompts_status)) + " загружено" if any(prompts_status.values()) else "❌"}
База данных: ✅ (соединение активно)

👑 **Админы:** {ctx.admin_manager.get_stats()["active_admins"]}/{ctx.admin_manager.get_stats()["total_admins"]} активны
🐛 **Режим отладки:** {"Включен" if ctx.config.DEBUG_MODE else "Выключен"}

Все системы работают нормально!
            """
        else:
            status_message = f"""
🔧 **Статус системы:**

OpenAI API: {"✅" if openai_status else "❌"}
Промпты: {"✅ " + str(sum(prompts_status.values())) + "/" + str(len(prompts_status)) + " загружено" if any(prompts_status.values()) else "❌"}
База данных: ✅ (соединение активно)

Все системы работают нормально!
            """

        await send_message(message, status_message)

    except Exception as e:
        logger.error(f"Ошибка проверки статуса: {e}")
        await send_message(message, "❌ Ошибка при проверке статуса системы")
