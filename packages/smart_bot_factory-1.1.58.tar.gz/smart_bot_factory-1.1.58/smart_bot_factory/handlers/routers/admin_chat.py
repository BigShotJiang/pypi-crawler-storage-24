import logging

from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from ...i18n.translator import translate
from ...utils.context import ctx
from ..types.states import UserStates

logger = logging.getLogger(__name__)


async def check_and_handle_admin_chat(message: Message, state: FSMContext) -> bool:
    """
    Проверяет, находится ли пользователь в диалоге с админом.
    Если да — обрабатывает сообщение (сохранение в БД + пересылка админу) и возвращает True.
    Если нет — возвращает False.
    """
    if ctx.conversation_manager is None or message.from_user is None:
        return False

    user_id = message.from_user.id
    conversation = await ctx.conversation_manager.is_user_in_admin_chat(user_id)
    if not conversation:
        return False

    try:
        await state.set_state(UserStates.admin_chat)
        update_data: dict = {"admin_conversation": conversation}
        if conversation.get("session_id"):
            update_data["session_id"] = conversation["session_id"]
        await state.update_data(update_data)

        session_info = await ctx.supabase_client.get_active_session(user_id)
        if session_info and message.text:
            session_id = getattr(session_info, "id", None) or (session_info.get("id") if isinstance(session_info, dict) else None)
            if not session_id:
                raise ValueError("get_active_session returned object without id")
            await ctx.supabase_client.add_message(
                session_id=session_id,
                role="user",
                content=message.text,
                message_type="text",
                metadata={
                    "in_admin_chat": True,
                    "admin_id": conversation.get("admin_id"),
                },
            )

        await ctx.conversation_manager.forward_message_to_admin(message, conversation)
        return True
    except Exception as e:
        logger.error(f"❌ Ошибка обработки admin_chat: {e}", exc_info=True)
        try:
            lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
            await message.answer(translate("admin_chat.error_try_later", lang=lang))
        except Exception:
            logger.warning(
                "Failed to send admin_chat error message",
                extra={"user_id": user_id},
                exc_info=True,
            )
        return True
