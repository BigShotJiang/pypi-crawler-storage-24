import logging
from pathlib import Path
from typing import Optional

from aiogram.types import FSInputFile, Message
from aiogram.utils.media_group import MediaGroupBuilder
from sulguk import SULGUK_PARSE_MODE
from telegramify_markdown import standardize

from ...i18n import translate
from ...utils.context import ctx

logger = logging.getLogger(__name__)


def _get_parse_mode() -> str | None:
    parse_mode = ctx.config.MESSAGE_PARSE_MODE if ctx.config.MESSAGE_PARSE_MODE != "None" else None
    if parse_mode and parse_mode.upper() == "HTML":
        logger.debug("Parse mode: SULGUK_PARSE_MODE (для HTML)")
        return SULGUK_PARSE_MODE
    logger.debug(f"Parse mode: {parse_mode}")
    return parse_mode


def _get_media_type(file_path: str) -> str:
    ext = Path(file_path).suffix.lower()
    photo_extensions = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".tiff", ".tif", ".svg", ".ico", ".heic", ".heif"}
    video_extensions = {".mp4", ".mov", ".avi", ".mkv", ".webm", ".m4v", ".3gp", ".flv", ".wmv", ".mpg", ".mpeg"}
    if ext in photo_extensions:
        return "photo"
    if ext in video_extensions:
        return "video"
    return "document"


async def _filter_sent_files(user_id: int, files_list: list, directories_list: list) -> tuple[list, list]:
    logger.debug(f"Передано файлов: {files_list}, каталогов: {directories_list}")
    return files_list, directories_list


def _process_files(actual_files_list: list, actual_directories_list: list) -> tuple[list, list, list]:
    video_files = []
    photo_files = []
    document_files = []

    def add_file(file_path: Path, source: str = ""):
        if not file_path.is_file():
            logger.warning(f"   ⚠️ Файл не найден: {file_path}")
            return
        media_type = _get_media_type(str(file_path))
        source_text = f" из {source}" if source else ""
        if media_type == "video":
            video_files.append(file_path)
            logger.debug(f"Добавлено видео{source_text}: {file_path.name}")
        elif media_type == "photo":
            photo_files.append(file_path)
            logger.debug(f"Добавлено фото{source_text}: {file_path.name}")
        else:
            document_files.append(file_path)
            logger.debug(f"Добавлен документ{source_text}: {file_path.name}")

    files_dir = Path("files").resolve()
    if not files_dir.exists():
        try:
            if ctx.config and ctx.config.PROMPT_FILES_DIR:
                prompts_dir = Path(ctx.config.PROMPT_FILES_DIR)
                files_dir = prompts_dir.parent / "files"
        except Exception:
            logger.debug(
                "Failed to resolve files_dir from PROMPT_FILES_DIR",
                extra={"prompt_files_dir": getattr(getattr(ctx, "config", None), "PROMPT_FILES_DIR", None)},
                exc_info=True,
            )

    for file_name in actual_files_list:
        try:
            add_file(files_dir / file_name)
        except Exception as e:
            logger.error(f"   ❌ Ошибка обработки файла {file_name}: {e}")

    for dir_name in actual_directories_list:
        dir_path = Path(dir_name)
        try:
            if dir_path.is_dir():
                for file_path in dir_path.iterdir():
                    try:
                        add_file(file_path, str(dir_path))
                    except Exception as e:
                        logger.error(f"   ❌ Ошибка обработки файла {file_path}: {e}")
            else:
                logger.warning(f"   ⚠️ Каталог не найден: {dir_path}")
        except Exception as e:
            logger.error(f"   ❌ Ошибка обработки каталога {dir_path}: {e}")

    return video_files, photo_files, document_files


def _get_chat_action_for_file_lists(video_files: list, photo_files: list, document_files: list) -> str:
    if video_files:
        return "upload_video"
    if photo_files:
        return "upload_photo"
    if document_files:
        return "upload_document"
    return "typing"


def _is_parse_error(error: Exception) -> bool:
    error_str = str(error)
    error_type = type(error).__name__
    parse_errors = ["can't parse entities", "Bad Request", "parse", "Unexpected end tag", "Unclosed tag"]
    return any(parse_err.lower() in error_str.lower() for parse_err in parse_errors) or "TelegramBadRequest" in error_type


async def _send_media_groups(
    message: Message,
    video_files: list,
    photo_files: list,
    document_files: list,
    text: str,
    parse_mode: str | None,
) -> Message:
    chat_action = _get_chat_action_for_file_lists(video_files, photo_files, document_files)
    if chat_action != "typing":
        try:
            await ctx.bot.send_chat_action(chat_id=message.chat.id, action=chat_action)
            logger.debug(f"📤 Chat action отправлен: {chat_action}")
        except Exception as e:
            logger.warning(f"⚠️ Не удалось отправить chat action '{chat_action}': {e}")

    if video_files:
        video_group = MediaGroupBuilder()
        for file_path in video_files:
            video_group.add_video(media=FSInputFile(str(file_path)))
        videos = video_group.build()
        if videos:
            await message.answer_media_group(media=videos)
            logger.debug(f"Отправлено {len(videos)} видео")

    if photo_files:
        photo_group = MediaGroupBuilder()
        for file_path in photo_files:
            photo_group.add_photo(media=FSInputFile(str(file_path)))
        photos = photo_group.build()
        if photos:
            await message.answer_media_group(media=photos)
            logger.debug(f"Отправлено {len(photos)} фото")

    if parse_mode in ("Markdown", "MarkdownV2") and text:
        text_to_send = standardize(text)
        parse_mode = "MarkdownV2"
    else:
        text_to_send = text

    try:
        result = await message.answer(text_to_send, parse_mode=parse_mode)
    except Exception as e:
        if _is_parse_error(e):
            result = await message.answer(text_to_send, parse_mode=None)
        else:
            raise

    if document_files:
        doc_group = MediaGroupBuilder()
        for file_path in document_files:
            doc_group.add_document(media=FSInputFile(str(file_path)))
        docs = doc_group.build()
        if docs:
            await message.answer_media_group(media=docs)
            logger.debug(f"Отправлено {len(docs)} документов")

    return result


async def _save_sent_files_to_db(
    user_id: int,
    actual_files_list: list,
    actual_directories_list: list,
    video_files: list,
    photo_files: list,
    document_files: list,
):
    pass


def _validate_text(text: str) -> str:
    if not text or not text.strip():
        logger.error("❌ КРИТИЧЕСКАЯ ОШИБКА: final_text пуст после обработки!")
        logger.error(f"   Исходный text: '{text[:200]}...'")
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        return translate("error.response_build_failed", lang=lang)
    return text


def _is_bot_blocked_error(error: Exception) -> bool:
    error_str = str(error)
    error_type = type(error).__name__
    return "Forbidden: bot was blocked by the user" in error_str or "TelegramForbiddenError" in error_type


async def _handle_send_error(message: Message, error: Exception, user_id: int, original_text: Optional[str] = None):
    from ...error_handling import get_error_handler

    handler = get_error_handler()
    context = {"user_id": user_id, "function": "send_message", "has_original_text": bool(original_text)}
    result = await handler.handle(error=error, context=context, suppress=True)
    if result and result.get("status") == "blocked":
        return None

    if _is_parse_error(error) and original_text:
        logger.warning("⚠️ Ошибка парсинга разметки, пытаемся отправить текст без форматирования")
        try:
            result_msg = await message.answer(original_text, parse_mode=None)
            logger.info("✅ Сообщение отправлено без форматирования")
            return result_msg
        except Exception as e2:
            res2 = await handler.handle(e2, context=context, suppress=True)
            if res2 and res2.get("status") == "blocked":
                return None
            logger.error(f"❌ Не удалось отправить даже без форматирования: {e2}")

    logger.exception("Полный стек ошибки send_message:")
    try:
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        fallback_text = translate("error.send_response_failed", lang=lang)
        return await message.answer(fallback_text, parse_mode=None)
    except Exception as e2:
        res2 = await handler.handle(e2, context=context, suppress=True)
        if res2 and res2.get("status") == "blocked":
            return None
        logger.error(f"❌ Даже запасное сообщение не отправилось: {e2}")
        raise


async def send_message(
    message: Message,
    text: str,
    files_list: Optional[list] = None,
    directories_list: Optional[list] = None,
    parse_mode: str | None = None,
    **kwargs,
):
    files_list = files_list or []
    directories_list = directories_list or []
    user_id = message.from_user.id

    logger.debug(
        "send_message called",
        extra={"user_id": user_id, "text_len": len(text), "debug": getattr(getattr(ctx, "config", None), "DEBUG_MODE", False)},
    )

    try:
        if parse_mode is None:
            parse_mode = _get_parse_mode()
        final_text = _validate_text(text)

        if parse_mode in ("Markdown", "MarkdownV2"):
            final_text = standardize(final_text)
            parse_mode = "MarkdownV2"

        actual_files_list, actual_directories_list = await _filter_sent_files(user_id, files_list, directories_list)
        if actual_files_list or actual_directories_list:
            video_files, photo_files, document_files = _process_files(actual_files_list, actual_directories_list)
            return await _send_media_groups(
                message=message,
                video_files=video_files,
                photo_files=photo_files,
                document_files=document_files,
                text=final_text,
                parse_mode=parse_mode,
            )
        return await message.answer(final_text, parse_mode=parse_mode, **kwargs)
    except Exception as e:
        return await _handle_send_error(message, e, user_id, final_text)
