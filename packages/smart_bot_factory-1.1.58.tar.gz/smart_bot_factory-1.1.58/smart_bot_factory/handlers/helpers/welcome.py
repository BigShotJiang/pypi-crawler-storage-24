import logging
from pathlib import Path

from aiogram.types import FSInputFile, Message
from telegramify_markdown import standardize

from ...utils.context import ctx
from .messaging import _validate_text

logger = logging.getLogger(__name__)


async def get_welcome_file_path() -> str | None:
    try:
        from project_root_finder import root

        if not ctx.config.WELCOME_FILE_DIR:
            return None

        welcome_dir_name = ctx.config.WELCOME_FILE_DIR.rstrip("/")
        bot_id = ctx.config.BOT_ID
        if not bot_id:
            logger.warning("BOT_ID не установлен, не могу найти директорию welcome files")
            return None

        folder = root / "bots" / bot_id / welcome_dir_name
        if not folder.exists():
            logger.info(f"Директория приветственных файлов не существует: {folder.absolute()}")
            return None
        if not folder.is_dir():
            logger.info(f"Путь не является директорией: {folder.absolute()}")
            return None

        for path in folder.iterdir():
            if path.is_file() and path.suffix.lower() == ".pdf":
                logger.info(f"Найден PDF файл: {path.absolute()}")
                return str(path)
        logger.info(f"PDF файл не найден в директории: {folder.absolute()}")
        return None
    except Exception as e:
        logger.error(f"Ошибка при поиске приветственного файла: {e}")
        return None


async def get_welcome_msg_path() -> str | None:
    try:
        pdf_path = await get_welcome_file_path()
        if not pdf_path:
            return None

        msg_path = str(Path(pdf_path).parent / "welcome_file_msg.txt")
        if not Path(msg_path).is_file():
            logger.info(f"Файл подписи не найден: {msg_path}")
            return None
        return msg_path
    except Exception as e:
        logger.error(f"Ошибка при поиске файла подписи: {e}")
        return None


async def send_welcome_file(message: Message) -> str:
    try:
        file_path = await get_welcome_file_path()
        if not file_path:
            return ""

        caption = ""
        msg_path = await get_welcome_msg_path()
        if msg_path:
            try:
                with open(msg_path, "r", encoding="utf-8") as f:
                    caption = f.read().strip()
                    logger.info(f"Подпись загружена из файла: {msg_path}")
            except Exception as e:
                logger.error(f"Ошибка при чтении файла подписи {msg_path}: {e}")

        if caption:
            caption = _validate_text(caption)
            caption = standardize(caption)

        document = FSInputFile(file_path)
        await message.answer_document(document=document, caption=caption, parse_mode="MarkdownV2")
        logger.info(f"Приветственный файл отправлен: {file_path}")
        return caption
    except Exception as e:
        logger.error(f"Ошибка при отправке приветственного файла: {e}")
        return ""
