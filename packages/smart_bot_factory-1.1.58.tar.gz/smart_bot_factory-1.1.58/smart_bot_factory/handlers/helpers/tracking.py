import re
from urllib.parse import unquote


def parse_utm_from_start_param(start_param: str) -> dict:
    """Парсит UTM-метки и сегмент из start параметра."""
    utm_data = {}

    try:
        if "t.me/" in start_param or "https://" in start_param:
            match = re.search(r"[?&]start=([^&]+)", start_param)
            if match:
                start_param = unquote(match.group(1))
            else:
                return {}

        if "-" in start_param:
            parts = start_param.split("_") if "_" in start_param else [start_param]
            for part in parts:
                if "-" in part:
                    key, value = part.split("-", 1)
                    if key in ["source", "medium", "campaign", "content", "term"]:
                        key = "utm_" + key
                        utm_data[key] = value
                    elif key == "seg":
                        utm_data["segment"] = value
    except Exception as e:
        print(f"Ошибка парсинга UTM параметров: {e}")

    return utm_data
