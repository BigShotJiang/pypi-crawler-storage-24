"""
Пакет обработчиков сообщений для Telegram-бота.

Структура:
- routers: основные роутеры (main/voice/commands/admin_chat)
- middlewares: мидлвари (rate_limit, admin)
- helpers: утилиты и конвертеры
- types: состояния и константы
- processing: основная логика обработки сообщений

Импорты сознательно не выполняются на уровне пакета,
чтобы избежать циклических зависимостей.
"""

__all__ = ["routers", "middlewares", "helpers", "types", "processing"]
