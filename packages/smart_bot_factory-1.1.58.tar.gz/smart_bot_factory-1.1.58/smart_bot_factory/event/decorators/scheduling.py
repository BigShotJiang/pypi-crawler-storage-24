"""
Планирование задач и глобальных обработчиков.
"""

import asyncio
import logging
from datetime import datetime, timedelta, timezone
from typing import Optional

from .db import save_global_event_with_deps, save_scheduled_task_with_deps
from .execution import execute_global_handler, execute_scheduled_task
from .registry import _get_registry
from .utils import EventDeps, format_seconds_to_human, parse_appointment_data, resolve_event_deps_from_ctx

logger = logging.getLogger(__name__)


async def schedule_task_for_later(task_name: str, delay_seconds: int, user_id: int, user_data: str):
    """
    Планирует выполнение задачи через указанное время

    Args:
        task_name: Название задачи
        delay_seconds: Задержка в секундах
        user_id: ID пользователя
        user_data: Простой текст для задачи
    """
    scheduled_tasks, source = _get_registry("task")
    logger.debug(
        "Scheduling: looking up task in registry",
        extra={"task_name": task_name, "source": source},
    )

    if task_name not in scheduled_tasks:
        available_tasks = list(scheduled_tasks.keys())
        logger.error(
            "Scheduling: task not found in registry",
            extra={"task_name": task_name, "available_tasks": available_tasks},
        )
        raise ValueError(f"Задача '{task_name}' не найдена. Доступные: {available_tasks}")

    logger.info(
        "Scheduling: schedule in-memory task with delay",
        extra={"task_name": task_name, "delay_seconds": delay_seconds, "user_id": user_id},
    )

    async def delayed_task():
        await asyncio.sleep(delay_seconds)
        await execute_scheduled_task(task_name, user_id, user_data)

    asyncio.create_task(delayed_task())

    return {
        "status": "scheduled",
        "task_name": task_name,
        "delay_seconds": delay_seconds,
        "scheduled_at": datetime.now().isoformat(),
    }


async def execute_scheduled_task_from_event(user_id: int, task_name: str, event_info: str, session_id: Optional[str] = None):
    deps = resolve_event_deps_from_ctx()
    return await execute_scheduled_task_from_event_with_deps(deps, user_id, task_name, event_info, session_id)


async def execute_scheduled_task_from_event_with_deps(
    deps: EventDeps,
    user_id: int,
    task_name: str,
    event_info: str,
    session_id: Optional[str] = None,
):
    """
    Выполняет запланированную задачу на основе события от ИИ

    Args:
        user_id: ID пользователя
        task_name: Название задачи
        event_info: Информация от ИИ (только текст, время задается в декораторе или событии)
        session_id: ID сессии для отслеживания
    """
    scheduled_tasks, source = _get_registry("task")
    logger.debug(
        "Scheduling: loaded task registry",
        extra={"source": source, "available_tasks": list(scheduled_tasks.keys())},
    )

    if task_name not in scheduled_tasks:
        available_tasks = list(scheduled_tasks.keys())
        logger.error(
            "Scheduling: task not found in registry",
            extra={"task_name": task_name, "available_tasks": available_tasks},
        )
        raise ValueError(f"Задача '{task_name}' не найдена. Доступные задачи: {available_tasks}")

    task_info = scheduled_tasks[task_name]
    default_delay = task_info.get("default_delay")
    event_type = task_info.get("event_type")

    if default_delay is None:
        raise ValueError(f"Для задачи '{task_name}' не указано время в декораторе (параметр delay)")

    user_data = event_info.strip() if event_info else ""

    if event_type:
        event_datetime = None

        if callable(event_type):
            logger.info(
                "Scheduling: calling event_type function for task",
                extra={"task_name": task_name, "user_id": user_id},
            )

            try:
                event_datetime = await event_type(user_id, user_data)

                if not isinstance(event_datetime, datetime):
                    raise ValueError(f"Функция event_type должна вернуть datetime, получен {type(event_datetime)}")

                logger.info(
                    "Scheduling: event_type function returned datetime",
                    extra={"task_name": task_name, "event_datetime": event_datetime.isoformat()},
                )

            except Exception as e:
                logger.error(
                    "Scheduling: error in event_type function",
                    extra={"task_name": task_name, "user_id": user_id, "error_type": type(e).__name__},
                    exc_info=True,
                )
                    result = await schedule_task_for_later_with_db_with_deps(deps, task_name, user_id, user_data, default_delay, session_id)
                return result

        else:
            logger.info(
                "Scheduling: reminder task based on event type",
                extra={"task_name": task_name, "event_type": event_type, "default_delay": default_delay},
            )

            try:
                event_data_str = await deps.supabase_client.get_last_event_info_by_user_and_type(user_id, event_type)

                if not event_data_str:
                    logger.warning(
                        "Scheduling: no event found for user and type",
                        extra={"user_id": user_id, "event_type": event_type},
                    )
                    result = await schedule_task_for_later_with_db_with_deps(deps, task_name, user_id, user_data, default_delay, session_id)
                    return result

                event_data = parse_appointment_data(event_data_str)

                if "datetime" not in event_data:
                    logger.warning(
                        "Scheduling: failed to parse datetime from event data",
                        extra={"user_id": user_id, "event_type": event_type},
                    )
                    result = await schedule_task_for_later_with_db_with_deps(deps, task_name, user_id, user_data, default_delay, session_id)
                    return result

                event_datetime = event_data["datetime"]
                logger.info(
                    "Scheduling: obtained event datetime from DB",
                    extra={"user_id": user_id, "event_type": event_type, "event_datetime": event_datetime.isoformat()},
                )

            except Exception as e:
                logger.error(
                    "Scheduling: error while getting event from DB",
                    extra={
                        "user_id": user_id,
                        "event_type": event_type,
                        "task_name": task_name,
                        "error_type": type(e).__name__,
                    },
                    exc_info=True,
                )
                result = await schedule_task_for_later_with_db_with_deps(deps, task_name, user_id, user_data, default_delay, session_id)
                return result

        now = datetime.now()
        reminder_datetime = event_datetime - timedelta(seconds=default_delay)

        if reminder_datetime <= now:
            logger.warning(
                "Scheduling: reminder time is in the past, executing immediately",
                extra={"task_name": task_name, "user_id": user_id, "event_datetime": event_datetime.isoformat()},
            )
            result = await execute_scheduled_task(task_name, user_id, user_data)
            return {
                "status": "executed_immediately",
                "task_name": task_name,
                "reason": "reminder_time_passed",
                "event_datetime": event_datetime.isoformat(),
                "result": result,
            }

        delay_seconds = int((reminder_datetime - now).total_seconds())

        event_source = "function" if callable(task_info.get("event_type")) else "event"
        human_time = format_seconds_to_human(delay_seconds)
        logger.info(
            "Scheduling: plan reminder task",
            extra={
                "task_name": task_name,
                "user_id": user_id,
                "event_source": event_source,
                "default_delay": default_delay,
                "delay_seconds": delay_seconds,
                "human_delay": human_time,
                "event_datetime": event_datetime.isoformat(),
            },
        )

        result = await schedule_task_for_later_with_db_with_deps(deps, task_name, user_id, user_data, delay_seconds, session_id)
        result["event_datetime"] = event_datetime.isoformat()
        result["reminder_type"] = "event_reminder"

        return result
    else:
        human_time = format_seconds_to_human(default_delay)
        logger.info(
            "Scheduling: plan simple delayed task",
            extra={
                "task_name": task_name,
                "user_id": user_id,
                "default_delay": default_delay,
                "delay_seconds": default_delay,
                "human_delay": human_time,
            },
        )

        result = await schedule_task_for_later_with_db_with_deps(deps, task_name, user_id, user_data, default_delay, session_id)

        return result


async def schedule_global_handler_for_later(handler_type: str, delay_seconds: int, handler_data: str):
    """
    Планирует выполнение глобального обработчика через указанное время

    Args:
        handler_type: Тип глобального обработчика
        delay_seconds: Задержка в секундах
        handler_data: Данные для обработчика
    """
    global_handlers, source = _get_registry("global")
    logger.debug(
        "Scheduling: looking up global handler in registry",
        extra={"handler_type": handler_type, "source": source},
    )

    if handler_type not in global_handlers:
        available_handlers = list(global_handlers.keys())
        logger.error(
            "Scheduling: global handler not found in registry",
            extra={"handler_type": handler_type, "available_handlers": available_handlers},
        )
        raise ValueError(f"Глобальный обработчик '{handler_type}' не найден. Доступные: {available_handlers}")

    logger.info(
        "Scheduling: schedule in-memory global handler with delay",
        extra={"handler_type": handler_type, "delay_seconds": delay_seconds},
    )

    async def delayed_global_handler():
        await asyncio.sleep(delay_seconds)
        await execute_global_handler(handler_type, handler_data)

    asyncio.create_task(delayed_global_handler())

    return {
        "status": "scheduled",
        "handler_type": handler_type,
        "delay_seconds": delay_seconds,
        "scheduled_at": datetime.now().isoformat(),
    }


async def execute_global_handler_from_event(handler_type: str, event_info: str):
    deps = resolve_event_deps_from_ctx()
    return await execute_global_handler_from_event_with_deps(deps, handler_type, event_info)


async def execute_global_handler_from_event_with_deps(deps: EventDeps, handler_type: str, event_info: str):
    """
    Выполняет глобальный обработчик на основе события от ИИ

    Args:
        handler_type: Тип глобального обработчика
        event_info: Информация от ИИ (только текст, время задается в декораторе или функции)
    """
    global_handlers, source = _get_registry("global")

    if handler_type not in global_handlers:
        available = list(global_handlers.keys())
        logger.error(
            "Scheduling: global handler not found in registry",
            extra={"handler_type": handler_type, "source": source, "available_handlers": available},
        )
        raise ValueError(f"Глобальный обработчик '{handler_type}' не найден")

    handler_info = global_handlers[handler_type]
    default_delay = handler_info.get("default_delay")
    event_type = handler_info.get("event_type")

    if default_delay is None:
        raise ValueError(f"Для глобального обработчика '{handler_type}' не указано время в декораторе (параметр delay)")

    handler_data = event_info.strip() if event_info else ""

    if event_type:
        event_datetime = None

        if callable(event_type):
            logger.info(
                "Scheduling: calling event_type function for global handler",
                extra={"handler_type": handler_type},
            )

            try:
                event_datetime = await event_type(handler_data)

                if not isinstance(event_datetime, datetime):
                    raise ValueError(f"Функция event_type должна вернуть datetime, получен {type(event_datetime)}")

                logger.info(
                    "Scheduling: global handler event_type returned datetime",
                    extra={"handler_type": handler_type, "event_datetime": event_datetime.isoformat()},
                )

            except Exception as e:
                logger.error(
                    "Scheduling: error in global handler event_type function",
                    extra={"handler_type": handler_type, "error_type": type(e).__name__},
                    exc_info=True,
                )
                result = await schedule_global_handler_for_later_with_db_with_deps(deps, handler_type, default_delay, handler_data)
                return result

        else:
            logger.info(
                "Scheduling: global handler uses string event_type",
                extra={"handler_type": handler_type, "event_type": event_type},
            )
            result = await schedule_global_handler_for_later_with_db_with_deps(deps, handler_type, default_delay, handler_data)
            return result

        now = datetime.now()
        reminder_datetime = event_datetime - timedelta(seconds=default_delay)

        if reminder_datetime <= now:
            logger.warning(
                "Scheduling: global event reminder is in the past, executing immediately",
                extra={"handler_type": handler_type, "event_datetime": event_datetime.isoformat()},
            )
            result = await execute_global_handler(handler_type, handler_data)
            return {
                "status": "executed_immediately",
                "handler_type": handler_type,
                "reason": "reminder_time_passed",
                "event_datetime": event_datetime.isoformat(),
                "result": result,
            }

        delay_seconds = int((reminder_datetime - now).total_seconds())

        human_time = format_seconds_to_human(delay_seconds)
        logger.info(
            "Scheduling: plan global handler reminder",
            extra={
                "handler_type": handler_type,
                "default_delay": default_delay,
                "delay_seconds": delay_seconds,
                "human_delay": human_time,
                "event_datetime": event_datetime.isoformat(),
            },
        )

        result = await schedule_global_handler_for_later_with_db_with_deps(deps, handler_type, delay_seconds, handler_data)
        result["event_datetime"] = event_datetime.isoformat()
        result["reminder_type"] = "global_event_reminder"

        return result

    else:
        logger.info(
            "Scheduling: plan simple delayed global handler",
            extra={"handler_type": handler_type, "delay_seconds": default_delay},
        )

        result = await schedule_global_handler_for_later_with_db_with_deps(deps, handler_type, default_delay, handler_data)

        return result


async def schedule_task_for_later_with_db(
    task_name: str,
    user_id: int,
    user_data: str,
    delay_seconds: int,
    session_id: Optional[str] = None,
):
    deps = resolve_event_deps_from_ctx()
    return await schedule_task_for_later_with_db_with_deps(deps, task_name, user_id, user_data, delay_seconds, session_id)


async def schedule_task_for_later_with_db_with_deps(
    deps: EventDeps,
    task_name: str,
    user_id: int,
    user_data: str,
    delay_seconds: int,
    session_id: Optional[str] = None,
):
    """Планирует выполнение задачи через указанное время с сохранением в БД (без asyncio.sleep)"""

    scheduled_tasks, _ = _get_registry("task")

    if task_name not in scheduled_tasks:
        import inspect

        frame = inspect.currentframe()
        line_no = frame.f_lineno if frame else "unknown"
        available_tasks = list(scheduled_tasks.keys())
        logger.error(
            "Scheduling: task not found in registry (DB)",
            extra={
                "task_name": task_name,
                "available_tasks": available_tasks,
                "file": "decorators_scheduling.py",
                "line": line_no,
            },
        )
        raise ValueError(f"Задача '{task_name}' не найдена")

    human_time = format_seconds_to_human(delay_seconds)
    logger.info(
        "Scheduling: plan task with DB persistence",
        extra={
            "task_name": task_name,
            "user_id": user_id,
            "delay_seconds": delay_seconds,
            "human_delay": human_time,
            "session_id": session_id,
        },
    )

    event_id = await save_scheduled_task_with_deps(deps, task_name, user_id, user_data, delay_seconds, session_id)

    logger.info(
        "Scheduling: task persisted to DB",
        extra={"task_name": task_name, "event_id": event_id, "user_id": user_id},
    )

    return {
        "status": "scheduled",
        "task_name": task_name,
        "delay_seconds": delay_seconds,
        "event_id": event_id,
        "scheduled_at": datetime.now(timezone.utc).isoformat(),
    }


async def schedule_global_handler_for_later_with_db(handler_type: str, delay_seconds: int, handler_data: str):
    deps = resolve_event_deps_from_ctx()
    return await schedule_global_handler_for_later_with_db_with_deps(deps, handler_type, delay_seconds, handler_data)


async def schedule_global_handler_for_later_with_db_with_deps(
    deps: EventDeps,
    handler_type: str,
    delay_seconds: int,
    handler_data: str,
):
    """Планирует выполнение глобального обработчика через указанное время с сохранением в БД (без asyncio.sleep)"""

    global_handlers, _ = _get_registry("global")

    if handler_type not in global_handlers:
        raise ValueError(f"Глобальный обработчик '{handler_type}' не найден")

    logger.info(
        "Scheduling: plan global handler with DB persistence",
        extra={"handler_type": handler_type, "delay_seconds": delay_seconds},
    )

    event_id = await save_global_event_with_deps(deps, handler_type, handler_data, delay_seconds)

    logger.info(
        "Scheduling: global handler persisted to DB",
        extra={"handler_type": handler_type, "event_id": event_id},
    )

    return {
        "status": "scheduled",
        "handler_type": handler_type,
        "delay_seconds": delay_seconds,
        "event_id": event_id,
        "scheduled_at": datetime.now(timezone.utc).isoformat(),
    }
