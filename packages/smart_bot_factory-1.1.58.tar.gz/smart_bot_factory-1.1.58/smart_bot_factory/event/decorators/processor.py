"""
Фоновый процессор событий.
"""

import asyncio
import logging
from datetime import datetime, timedelta, timezone
from typing import Optional

from ...utils.performance import measure_time
from .admin import AdminEventResult, process_admin_event
from .checks import ensure_not_processed_once_with_deps, smart_execute_check_with_deps
from .constants import EventCategory, EventStatus, NotifyTime, SmartCheckAction
from .db import (
    ScheduledEvent,
    get_pending_events_in_next_minute_with_deps,
    update_event_result_with_deps,
)
from .execution import execute_event_handler, execute_global_handler, execute_scheduled_task
from .registry import _get_registry
from .utils import EventDeps, get_supabase_client_or_raise, resolve_event_deps_from_ctx

logger = logging.getLogger(__name__)


@measure_time(custom_name="Event:background_event_processor", min_ms=500)
async def background_event_processor() -> None:
    deps = resolve_event_deps_from_ctx()
    await background_event_processor_with_deps(deps)


@measure_time(custom_name="Event:background_event_processor", min_ms=500)
async def background_event_processor_with_deps(deps: EventDeps) -> None:
    """Фоновый процессор для ВСЕХ типов событий включая админские (проверяет БД каждую минуту)"""

    logger.info("🔄 Запуск фонового процессора событий (user_event, scheduled_task, global_handler, admin_event)")

    async def handle_admin_event(event: ScheduledEvent) -> None:
        """Обрабатывает админское событие и обновляет статус"""
        if not event.get("bot_id"):
            logger.warning("⚠️ Админское событие не имеет bot_id", extra={"event_id": event["id"]})

        try:
            logger.debug("🔄 Начало обработки админского события", extra={"event_id": event["id"]})
            logger.debug("📝 Данные admin-события", extra={"event_id": event["id"], "event_type": event["event_type"]})

            result: AdminEventResult = await process_admin_event(event)
            logger.debug("📦 Результат process_admin_event получен", extra={"event_id": event["id"]})

            import json

            supabase_client = get_supabase_client_or_raise(deps)

            result_data_json = json.dumps(result, ensure_ascii=False) if result else None
            logger.debug("📝 result_data для сохранения", extra={"event_id": event["id"]})

            update_data = {
                "status": EventStatus.COMPLETED,
                "executed_at": datetime.now(timezone.utc).isoformat(),
                "result_data": result_data_json,
            }

            if not event.get("bot_id") and supabase_client.bot_id:
                update_data["bot_id"] = supabase_client.bot_id
                logger.debug("📝 Добавлен bot_id к admin-событию", extra={"event_id": event["id"], "bot_id": supabase_client.bot_id})

            query = supabase_client.client.table("scheduled_events").update(update_data).eq("id", event["id"])

            if event.get("bot_id"):
                query = query.eq("bot_id", event["bot_id"])

            query.execute()

            logger.info("✅ Админское событие выполнено и обновлено в БД", extra={"event_id": event["id"]})
        except Exception as e:
            logger.error("❌ Ошибка обработки админского события", extra={"event_id": event["id"]}, exc_info=True)

            try:
                supabase_client = get_supabase_client_or_raise(deps)

                update_data = {
                    "status": EventStatus.FAILED,
                    "last_error": str(e),
                    "executed_at": datetime.now(timezone.utc).isoformat(),
                }

                if not event.get("bot_id") and supabase_client.bot_id:
                    update_data["bot_id"] = supabase_client.bot_id
                    logger.info("📝 Добавлен bot_id к admin-событию (ошибка)", extra={"event_id": event["id"], "bot_id": supabase_client.bot_id})

                query = supabase_client.client.table("scheduled_events").update(update_data).eq("id", event["id"])

                if event.get("bot_id"):
                    query = query.eq("bot_id", event["bot_id"])

                query.execute()
                logger.info("✅ Статус admin-события обновлен на failed", extra={"event_id": event["id"]})
            except Exception:
                logger.error("❌ Ошибка обновления статуса admin-события", extra={"event_id": event["id"]}, exc_info=True)

    async def should_skip_user_event(event: ScheduledEvent, event_type: str, user_id: Optional[int], session_id: Optional[str]) -> bool:
        """Проверяет once_only для user_event"""
        event_handlers, _ = _get_registry("event")
        event_handler_info = event_handlers.get(event_type, {})
        once_only = event_handler_info.get("once_only", True)

        if not once_only:
            return False

        already_done = await ensure_not_processed_once_with_deps(
            deps,
            event_type,
            user_id=user_id,
            session_id=session_id,
            current_event_id=event["id"],
        )
        if already_done:
            await update_event_result_with_deps(
                deps,
                event["id"],
                EventStatus.CANCELLED,
                {"reason": "already_executed_once_only"},
            )
            logger.info(
                "⛔ Событие пропущено: once_only уже выполнено",
                extra={"event_id": event["id"], "event_type": event_type, "user_id": user_id},
            )
            return True
        return False

    async def should_skip_scheduled_task(event: ScheduledEvent, event_type: str, user_id: Optional[int], session_id: Optional[str]) -> bool:
        """Проверяет once_only и smart_check для scheduled_task"""
        scheduled_tasks, _ = _get_registry("task")
        task_info = scheduled_tasks.get(event_type, {})
        use_smart_check = task_info.get("smart_check", True)
        once_only = task_info.get("once_only", True)

        if once_only:
            already_done = await ensure_not_processed_once_with_deps(
                deps,
                event_type,
                user_id=user_id,
                session_id=session_id,
                current_event_id=event["id"],
            )
            if already_done:
                await update_event_result_with_deps(
                    deps,
                    event["id"],
                    EventStatus.CANCELLED,
                    {"reason": "already_executed_once_only"},
                )
                logger.info(
                    "⛔ Задача пропущена: once_only уже выполнена",
                    extra={"event_id": event["id"], "event_type": event_type, "user_id": user_id},
                )
                return True

        if not use_smart_check:
            return False

        check_result = await smart_execute_check_with_deps(
            deps,
            event["id"],
            user_id,
            session_id,
            event_type,
            event["event_data"],
        )

        if check_result["action"] == SmartCheckAction.CANCEL:
            await update_event_result_with_deps(
                deps,
                event["id"],
                EventStatus.CANCELLED,
                {"reason": check_result["reason"]},
            )
            logger.info(f"⛔ Задача {event['id']} отменена: {check_result['reason']}")
            return True

        if check_result["action"] == SmartCheckAction.RESCHEDULE:
            new_scheduled_at = datetime.now(timezone.utc) + timedelta(seconds=check_result["new_delay"])
            supabase_client = get_supabase_client_or_raise(deps)
            supabase_client.client.table("scheduled_events").update(
                {
                    "scheduled_at": new_scheduled_at.isoformat(),
                    "status": EventStatus.PENDING,
                }
            ).eq("id", event["id"]).execute()
            logger.info(
                "🔄 Задача перенесена smart_check",
                extra={"event_id": event["id"], "new_delay": check_result["new_delay"]},
            )
            return True

        return False

    while True:
        try:
            pending_events = await get_pending_events_in_next_minute_with_deps(deps, limit=100)

            if pending_events:
                logger.info("📋 Найдены события для обработки", extra={"count": len(pending_events)})

                for event in pending_events:
                    try:
                        event_type = event["event_type"]
                        event_category = event["event_category"]
                        user_id = event.get("user_id")
                        session_id = event.get("session_id")

                        if event_category == EventCategory.ADMIN_EVENT:
                            await handle_admin_event(event)
                            continue

                        if event_category == EventCategory.USER_EVENT:
                            skip = await should_skip_user_event(event, event_type, user_id, session_id)
                            if skip:
                                continue

                        if event_category == EventCategory.SCHEDULED_TASK:
                            skip = await should_skip_scheduled_task(event, event_type, user_id, session_id)
                            if skip:
                                continue

                        result = await process_scheduled_event_with_deps(deps, event)

                        result_data = {"processed": True}
                        if isinstance(result, dict):
                            result_data.update(result)
                            if "info" in result:
                                logger.debug(
                                    "📊 Дашборд данные для задачи",
                                    extra={
                                        "event_id": event["id"],
                                        "event_type": event_type,
                                        "title": result["info"].get("title", "N/A"),
                                    },
                                )

                        await update_event_result_with_deps(deps, event["id"], "completed", result_data)
                        logger.debug("✅ Событие выполнено", extra={"event_id": event["id"], "event_type": event_type})

                    except Exception as e:
                        logger.error("❌ Ошибка обработки события", extra={"event_id": event["id"], "event_type": event_type}, exc_info=True)
                        await update_event_result_with_deps(deps, event["id"], "failed", None, str(e))

            await asyncio.sleep(60)

        except Exception:
            logger.error("❌ Ошибка в фоновом процессоре", exc_info=True)
            await asyncio.sleep(60)


async def process_scheduled_event(event: ScheduledEvent):
    deps = resolve_event_deps_from_ctx()
    return await process_scheduled_event_with_deps(deps, event)


async def process_scheduled_event_with_deps(deps: EventDeps, event: ScheduledEvent):
    """Обрабатывает одно событие из БД и возвращает результат"""

    event_type = event["event_type"]
    event_category = event["event_category"]
    event_data = event["event_data"]
    user_id = event.get("user_id")

    logger.debug(
        "🔄 Обработка события",
        extra={"event_id": event["id"], "event_type": event_type, "event_category": event_category},
    )

    async def handle_scheduled_task():
        scheduled_tasks, _ = _get_registry("task")
        task_info = scheduled_tasks.get(event_type, {})
        notify = task_info.get("notify", False)
        notify_time = task_info.get("notify_time", "after")

        result = await execute_scheduled_task(event_type, user_id, event_data)

        if notify and notify_time == NotifyTime.AFTER:
            from .notifications import notify_admins_about_event

            event_for_notify = {"тип": event_type, "инфо": event_data}
            await notify_admins_about_event(user_id, event_for_notify)
            logger.info("   ✅ Админы уведомлены после выполнения задачи", extra={"event_type": event_type, "user_id": user_id})

        return result

    async def handle_global_handler():
        return await execute_global_handler(event_type, event_data)

    async def handle_user_event():
        return await execute_event_handler(event_type, user_id, event_data)

    handlers = {
        "scheduled_task": handle_scheduled_task,
        "global_handler": handle_global_handler,
        "user_event": handle_user_event,
    }

    handler = handlers.get(event_category)
    if not handler:
        logger.warning("⚠️ Неизвестная категория события", extra={"event_category": event_category, "event_id": event["id"]})
        return None

    return await handler()
