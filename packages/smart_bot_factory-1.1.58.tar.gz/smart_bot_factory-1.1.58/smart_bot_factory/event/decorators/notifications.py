import logging
from datetime import datetime

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from ...utils.context import ctx

logger = logging.getLogger(__name__)


async def notify_admins_about_event(user_id: int, event: dict):
    """Отправляем уведомление админам о событии с явным указанием ID пользователя."""
    event_type = event.get("тип", "")
    event_info = event.get("инфо", "")

    if not event_type:
        return

    try:
        user_response = (
            ctx.supabase_client.client.table("sales_users").select("first_name", "last_name", "username").eq("telegram_id", user_id).execute()
        )
        user_info = user_response.data[0] if user_response.data else {}

        name_parts = []
        if user_info.get("first_name"):
            name_parts.append(user_info["first_name"])
        if user_info.get("last_name"):
            name_parts.append(user_info["last_name"])
        user_name = " ".join(name_parts) if name_parts else "Без имени"

        if user_info.get("username"):
            user_display = f"{user_name} (@{user_info['username']})"
        else:
            user_display = user_name
    except Exception as e:
        logger.error(f"Ошибка получения информации о пользователе {user_id}: {e}")
        user_display = "Пользователь"

    emoji_map = {"телефон": "📱", "консультация": "💬", "покупка": "💰", "отказ": "❌"}
    emoji = emoji_map.get(event_type, "🔔")

    notification = f"""
{emoji} {event_type.upper()}!
👤 {user_display}
🆔 ID: {user_id}
📝 {event_info}
🕐 {datetime.now().strftime("%H:%M")}
"""

    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="💬 Чат", callback_data=f"admin_chat_{user_id}"),
                InlineKeyboardButton(text="📋 История", callback_data=f"admin_history_{user_id}"),
            ]
        ]
    )

    try:
        active_admins = await ctx.admin_manager.get_active_admins()
        for admin_id in active_admins:
            try:
                await ctx.bot.send_message(admin_id, notification.strip(), reply_markup=keyboard)
            except Exception as e:
                logger.error(f"Ошибка отправки уведомления админу {admin_id}: {e}")
    except Exception as e:
        logger.error(f"Ошибка отправки уведомления админам: {e}")
