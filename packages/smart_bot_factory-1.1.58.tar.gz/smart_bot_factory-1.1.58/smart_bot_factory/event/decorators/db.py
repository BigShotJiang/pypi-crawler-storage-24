"""
Функции для работы с БД событий.
"""

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, List, Optional, TypedDict, cast

from ...error_handling import SupabaseError
from .checks import check_event_already_processed_with_deps
from .constants import EventCategory, EventStatus
from .registry import _get_registry
from .utils import EventDeps, get_supabase_client_or_raise, resolve_event_deps_from_ctx

logger = logging.getLogger(__name__)


class ScheduledEvent(TypedDict, total=False):
    """
    Минимальное представление записи из таблицы scheduled_events,
    используемое модулем decorators.
    """

    id: str
    event_type: str
    event_category: str
    user_id: Optional[int]
    event_data: str
    scheduled_at: Optional[str]
    status: str
    session_id: Optional[str]
    bot_id: Optional[str]
    retry_count: int
    created_at: str


async def save_immediate_event(event_type: str, user_id: int, event_data: str, session_id: Optional[str] = None) -> str:
    deps = resolve_event_deps_from_ctx()
    return await save_immediate_event_with_deps(deps, event_type, user_id, event_data, session_id)


async def save_immediate_event_with_deps(
    deps: EventDeps,
    event_type: str,
    user_id: int,
    event_data: str,
    session_id: Optional[str] = None,
) -> str:
    """Сохраняет событие для немедленного выполнения"""

    supabase_client = get_supabase_client_or_raise(deps)

    # Проверяем, нужно ли предотвращать дублирование
    event_handlers, _ = _get_registry("event")

    event_handler_info = event_handlers.get(event_type, {})
    once_only = event_handler_info.get("once_only", True)

    if once_only:
        already_processed = await check_event_already_processed_with_deps(deps, event_type, user_id, session_id)
        if already_processed:
            logger.info(
                "Events DB: immediate event already processed, skipping",
                extra={"event_type": event_type, "user_id": user_id, "session_id": session_id},
            )
            raise ValueError(f"Событие '{event_type}' уже обрабатывалось (once_only=True)")

    # Получаем bot_id
    if not supabase_client.bot_id:
        logger.warning(
            "Events DB: bot_id is not set when creating immediate_event",
            extra={"event_type": event_type, "user_id": user_id},
        )

    event_record = {
        "event_type": event_type,
        "event_category": EventCategory.USER_EVENT,
        "user_id": user_id,
        "event_data": event_data,
        "scheduled_at": None,  # Немедленное выполнение
        "status": EventStatus.IMMEDIATE,
        "session_id": session_id,
        "bot_id": supabase_client.bot_id,  # Всегда добавляем bot_id
    }

    try:
        response = supabase_client.client.table("scheduled_events").insert(event_record).execute()
        event_id = response.data[0]["id"]
        logger.info(
            "Events DB: immediate event saved",
            extra={"event_id": event_id, "event_type": event_type, "user_id": user_id},
        )
        return event_id
    except Exception as e:
        logger.error(
            "Events DB: failed to save immediate event",
            extra={"event_type": event_type, "user_id": user_id, "error_type": type(e).__name__},
            exc_info=True,
        )
        raise


async def save_scheduled_task(
    task_name: str,
    user_id: int,
    user_data: str,
    delay_seconds: int,
    session_id: Optional[str] = None,
) -> str:
    deps = resolve_event_deps_from_ctx()
    return await save_scheduled_task_with_deps(deps, task_name, user_id, user_data, delay_seconds, session_id)


async def save_scheduled_task_with_deps(
    deps: EventDeps,
    task_name: str,
    user_id: int,
    user_data: str,
    delay_seconds: int,
    session_id: Optional[str] = None,
) -> str:
    """Сохраняет запланированную задачу"""

    supabase_client = get_supabase_client_or_raise(deps)

    # Проверяем, нужно ли предотвращать дублирование
    scheduled_tasks, _ = _get_registry("task")

    task_info = scheduled_tasks.get(task_name, {})
    once_only = task_info.get("once_only", True)

    if once_only:
        already_processed = await check_event_already_processed_with_deps(deps, task_name, user_id, session_id)
        if already_processed:
            logger.info(
                "Events DB: scheduled task already exists, skipping",
                extra={"task_name": task_name, "user_id": user_id, "session_id": session_id},
            )
            raise ValueError(f"Задача '{task_name}' уже запланирована (once_only=True)")

    scheduled_at = datetime.now(timezone.utc) + timedelta(seconds=delay_seconds)

    # Получаем bot_id
    if not supabase_client.bot_id:
        logger.warning(
            "Events DB: bot_id is not set when creating scheduled_task",
            extra={"task_name": task_name, "user_id": user_id},
        )

    event_record = {
        "event_type": task_name,
        "event_category": EventCategory.SCHEDULED_TASK,
        "user_id": user_id,
        "event_data": user_data,
        "scheduled_at": scheduled_at.isoformat(),
        "status": EventStatus.PENDING,
        "session_id": session_id,
        "bot_id": supabase_client.bot_id,  # Всегда добавляем bot_id
    }

    try:
        response = supabase_client.client.table("scheduled_events").insert(event_record).execute()
        event_id = response.data[0]["id"]
        logger.info(
            "Events DB: scheduled task saved",
            extra={
                "event_id": event_id,
                "task_name": task_name,
                "user_id": user_id,
                "delay_seconds": delay_seconds,
            },
        )
        return event_id
    except Exception as e:
        logger.error(
            "Events DB: failed to save scheduled task",
            extra={
                "task_name": task_name,
                "user_id": user_id,
                "delay_seconds": delay_seconds,
                "error_type": type(e).__name__,
            },
            exc_info=True,
        )
        raise


async def save_global_event(handler_type: str, handler_data: str, delay_seconds: int = 0) -> str:
    deps = resolve_event_deps_from_ctx()
    return await save_global_event_with_deps(deps, handler_type, handler_data, delay_seconds)


async def save_global_event_with_deps(
    deps: EventDeps,
    handler_type: str,
    handler_data: str,
    delay_seconds: int = 0,
) -> str:
    """Сохраняет глобальное событие"""

    supabase_client = get_supabase_client_or_raise(deps)

    # Проверяем, нужно ли предотвращать дублирование
    global_handlers, _ = _get_registry("global")

    handler_info = global_handlers.get(handler_type, {})
    once_only = handler_info.get("once_only", True)

    if once_only:
        already_processed = await check_event_already_processed_with_deps(deps, handler_type, user_id=None)
        if already_processed:
            logger.info(
                "Events DB: global event already scheduled, skipping",
                extra={"handler_type": handler_type},
            )
            raise ValueError(f"Глобальное событие '{handler_type}' уже запланировано (once_only=True)")

    scheduled_at = None
    status = EventStatus.IMMEDIATE

    if delay_seconds > 0:
        scheduled_at = datetime.now(timezone.utc) + timedelta(seconds=delay_seconds)
        status = EventStatus.PENDING

    # Получаем bot_id
    if not supabase_client.bot_id:
        logger.warning(
            "Events DB: bot_id is not set when creating global_event",
            extra={"handler_type": handler_type},
        )

    event_record = {
        "event_type": handler_type,
        "event_category": EventCategory.GLOBAL_HANDLER,
        "user_id": None,  # Глобальное событие
        "event_data": handler_data,
        "scheduled_at": scheduled_at.isoformat() if scheduled_at else None,
        "status": status,
        "bot_id": supabase_client.bot_id,  # Всегда добавляем bot_id (глобальные события тоже привязаны к боту)
    }

    try:
        response = supabase_client.client.table("scheduled_events").insert(event_record).execute()
        event_id = response.data[0]["id"]
        logger.info(
            "Events DB: global event saved",
            extra={"event_id": event_id, "handler_type": handler_type, "delay_seconds": delay_seconds},
        )
        return event_id
    except Exception as e:
        logger.error(
            "Events DB: failed to save global event",
            extra={"handler_type": handler_type, "delay_seconds": delay_seconds, "error_type": type(e).__name__},
            exc_info=True,
        )
        raise


async def update_event_result(event_id: str, status: str, result_data: Any = None, error_message: Optional[str] = None) -> None:
    deps = resolve_event_deps_from_ctx()
    await update_event_result_with_deps(deps, event_id, status, result_data, error_message)


async def update_event_result_with_deps(
    deps: EventDeps,
    event_id: str,
    status: str,
    result_data: Any = None,
    error_message: Optional[str] = None,
) -> None:
    """Обновляет результат выполнения события"""

    supabase_client = get_supabase_client_or_raise(deps)

    update_data = {
        "status": status,
        "executed_at": datetime.now(timezone.utc).isoformat(),
    }

    if result_data:
        import json

        update_data["result_data"] = json.dumps(result_data, ensure_ascii=False)

        # Проверяем наличие поля 'info' для дашборда
        if isinstance(result_data, dict) and "info" in result_data:
            update_data["info_dashboard"] = json.dumps(result_data["info"], ensure_ascii=False)
            logger.info(
                "Events DB: dashboard info added to event",
                extra={"event_id": event_id},
            )

    if error_message:
        update_data["last_error"] = error_message
        # Получаем текущее количество попыток
        try:
            query = supabase_client.client.table("scheduled_events").select("retry_count").eq("id", event_id)

            query = supabase_client._with_bot_id(query)

            current_retry = query.execute().data[0]["retry_count"]
            update_data["retry_count"] = current_retry + 1
        except Exception:
            logger.debug(
                "Events DB: failed to get current retry_count, defaulting to 1",
                extra={"event_id": event_id},
                exc_info=True,
            )
            update_data["retry_count"] = 1

    try:
        query = supabase_client.client.table("scheduled_events").update(update_data).eq("id", event_id)

        query = supabase_client._with_bot_id(query)

        query.execute()
        logger.info(
            "Events DB: event result updated",
            extra={"event_id": event_id, "status": status},
        )
    except Exception as e:
        logger.error(
            "Events DB: failed to update event result",
            extra={"event_id": event_id, "status": status, "error_type": type(e).__name__},
            exc_info=True,
        )
        raise SupabaseError(
            f"Failed to update event result for event_id={event_id}",
            event_id=event_id,
            status=status,
        ) from e


async def get_pending_events(limit: int = 50) -> list[ScheduledEvent]:
    deps = resolve_event_deps_from_ctx()
    return await get_pending_events_with_deps(deps, limit)


async def get_pending_events_with_deps(deps: EventDeps, limit: int = 50) -> list[ScheduledEvent]:
    """Получает события готовые к выполнению СЕЙЧАС"""

    supabase_client = get_supabase_client_or_raise(deps)

    try:
        now = datetime.now(timezone.utc).isoformat()

        query = (
            supabase_client.client.table("scheduled_events")
            .select("*")
            .in_("status", [EventStatus.PENDING, EventStatus.IMMEDIATE])
            .or_(f"scheduled_at.is.null,scheduled_at.lte.{now}")
            .order("created_at")
            .limit(limit)
        )

        query = supabase_client._with_bot_id(query)

        response = query.execute()

        return cast(List[ScheduledEvent], response.data)
    except Exception as e:
        logger.error(
            "Failed to get pending events from DB",
            extra={"limit": limit, "bot_id": getattr(supabase_client, "bot_id", None)},
            exc_info=True,
        )
        raise SupabaseError(
            f"Failed to get pending events: {e}",
            limit=limit,
            bot_id=getattr(supabase_client, "bot_id", None),
        )


async def get_pending_events_in_next_minute(limit: int = 100) -> list[ScheduledEvent]:
    deps = resolve_event_deps_from_ctx()
    return await get_pending_events_in_next_minute_with_deps(deps, limit)


async def get_pending_events_in_next_minute_with_deps(deps: EventDeps, limit: int = 100) -> list[ScheduledEvent]:
    """Получает события готовые к выполнению в течение следующей минуты"""

    supabase_client = get_supabase_client_or_raise(deps)

    try:
        now = datetime.now(timezone.utc)
        next_minute = now + timedelta(seconds=60)

        query = (
            supabase_client.client.table("scheduled_events")
            .select("*")
            .in_("status", [EventStatus.PENDING, EventStatus.IMMEDIATE])
            .or_(f"scheduled_at.is.null,scheduled_at.lte.{next_minute.isoformat()}")
            .order("created_at")
            .limit(limit)
        )

        query = supabase_client._with_bot_id(query)

        response = query.execute()

        return cast(List[ScheduledEvent], response.data)
    except Exception as e:
        logger.error(
            "Failed to get pending events in next minute from DB",
            extra={"limit": limit, "bot_id": getattr(supabase_client, "bot_id", None)},
            exc_info=True,
        )
        raise SupabaseError(
            f"Failed to get pending events in next minute: {e}",
            limit=limit,
            bot_id=getattr(supabase_client, "bot_id", None),
        )
