"""
Централизованная система обработки ошибок для smart-bot-factory
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from .context import error_boundary, sync_error_boundary
from .exceptions import (
    APIError,
    BotBlockedError,
    BotFileNotFoundError,
    BusinessLogicError,
    ConfigurationError,
    EventValidationError,
    FileError,
    FileProcessingError,
    InvalidConfigError,
    MessageValidationError,
    MissingConfigError,
    OpenAIError,
    OpenAIRateLimitError,
    OpenAITimeoutError,
    SessionNotFoundError,
    SmartBotFactoryError,
    SupabaseConnectionError,
    SupabaseError,
    TelegramError,
    TelegramRateLimitError,
    UserNotFoundError,
    ValidationError,
)
from .handler import ErrorHandler, get_error_handler, set_error_handler
from .migration_utils import convert_to_custom_exception, is_bot_blocked_error
from .retry import (
    OPENAI_RETRY_STRATEGY,
    RATE_LIMIT_RETRY_STRATEGY,
    SUPABASE_RETRY_STRATEGY,
    TELEGRAM_RETRY_STRATEGY,
    RetryStrategy,
    with_retry,
)

if TYPE_CHECKING:
    from .middleware import ErrorHandlingMiddleware as ErrorHandlingMiddleware


def __getattr__(name: str):
    if name == "ErrorHandlingMiddleware":
        from .middleware import ErrorHandlingMiddleware as cls

        return cls
    raise AttributeError(name)


__all__ = [
    # Exceptions
    "SmartBotFactoryError",
    "APIError",
    "OpenAIError",
    "OpenAIRateLimitError",
    "OpenAITimeoutError",
    "SupabaseError",
    "SupabaseConnectionError",
    "TelegramError",
    "BotBlockedError",
    "TelegramRateLimitError",
    "ValidationError",
    "MessageValidationError",
    "EventValidationError",
    "ConfigurationError",
    "MissingConfigError",
    "InvalidConfigError",
    "BusinessLogicError",
    "SessionNotFoundError",
    "UserNotFoundError",
    "FileError",
    "BotFileNotFoundError",
    "FileProcessingError",
    # Handler
    "ErrorHandler",
    "get_error_handler",
    "set_error_handler",
    # Context managers
    "error_boundary",
    "sync_error_boundary",
    # Retry
    "RetryStrategy",
    "with_retry",
    "OPENAI_RETRY_STRATEGY",
    "SUPABASE_RETRY_STRATEGY",
    "TELEGRAM_RETRY_STRATEGY",
    "RATE_LIMIT_RETRY_STRATEGY",
    # Migration utils
    "is_bot_blocked_error",
    "convert_to_custom_exception",
    # Middleware
    "ErrorHandlingMiddleware",
]
