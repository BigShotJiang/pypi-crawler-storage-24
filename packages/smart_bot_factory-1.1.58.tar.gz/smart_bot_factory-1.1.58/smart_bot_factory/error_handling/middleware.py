"""
Middleware для централизованной обработки ошибок в Telegram handlers
"""

import logging
from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Update

from ..i18n.translator import translate
from .exceptions import BotBlockedError, TelegramError
from .handler import get_error_handler

logger = logging.getLogger(__name__)


class ErrorHandlingMiddleware(BaseMiddleware):
    """
    Middleware для автоматической обработки ошибок в Telegram handlers.

    Перехватывает все исключения и обрабатывает через ErrorHandler.
    """

    def __init__(self):
        super().__init__()
        self.error_handler = get_error_handler()

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        """Обработка события с автоматическим error handling"""
        context = self._extract_context(event, data)

        try:
            return await handler(event, data)

        except BotBlockedError as e:
            await self.error_handler.handle(e, context=context, suppress=True)
            return None

        except TelegramError as e:
            await self.error_handler.handle(e, context=context, suppress=True)
            logger.error(f"Telegram error in handler: {e}")
            return None

        except Exception as e:
            await self.error_handler.handle(e, context=context, suppress=True)
            logger.error(f"Unexpected error in handler: {e}", exc_info=True)
            await self._send_error_message(event, context)
            return None

    def _extract_context(self, event: TelegramObject, data: Dict[str, Any]) -> Dict[str, Any]:
        """Извлечь контекст из события"""
        context = {"middleware": "ErrorHandlingMiddleware"}

        if hasattr(event, "from_user") and event.from_user:
            context["user_id"] = event.from_user.id
        elif hasattr(event, "message") and event.message and hasattr(event.message, "from_user"):
            context["user_id"] = event.message.from_user.id

        if hasattr(event, "chat") and event.chat:
            context["chat_id"] = event.chat.id
        elif hasattr(event, "message") and event.message and hasattr(event.message, "chat"):
            context["chat_id"] = event.message.chat.id

        if isinstance(event, Update):
            context["update_type"] = getattr(event, "update_type", "unknown")

        return context

    async def _send_error_message(self, event: TelegramObject, context: Dict[str, Any]):
        """Попытаться отправить сообщение об ошибке пользователю"""
        try:
            from ..utils.context import ctx

            user_id = context.get("user_id")
            if user_id and ctx.bot:
                lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
                await ctx.bot.send_message(user_id, translate("error.processing_generic", lang=lang))
        except Exception as e:
            logger.error(f"Не удалось отправить сообщение об ошибке: {e}")
