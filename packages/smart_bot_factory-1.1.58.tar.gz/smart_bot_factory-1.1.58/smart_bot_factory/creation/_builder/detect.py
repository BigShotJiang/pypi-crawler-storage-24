"""
Internal helpers for BotBuilder detection logic.
"""

import inspect
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def detect_bot_id_from_filename() -> Optional[str]:
    """
    Automatically detects bot_id from the filename that instantiates BotBuilder.

    Returns:
        bot_id if detected, otherwise None.
    """
    try:
        # stack[0] - current frame (detect_bot_id_from_filename)
        # stack[1] - BotBuilder._detect_bot_id_from_filename wrapper
        # stack[2] - BotBuilder.__init__
        # stack[3] - the file that calls BotBuilder()
        stack = inspect.stack()

        logger.debug("🔍 Анализ стека вызовов для определения bot_id (всего кадров: %s)", len(stack))

        # Skip helper frames and search for the first external caller file.
        for i, frame_info in enumerate(stack[3:], start=3):
            filename = frame_info.filename
            logger.debug("🔍 Кадр %s: %s", i, filename)

            # Skip system and library files
            if "site-packages" in filename or "__pycache__" in filename:
                logger.debug("   Пропущен (системный файл)")
                continue

            # Skip smart_bot_factory library files (except bot launchers under bots/)
            if "smart_bot_factory" in filename and "bots" not in filename:
                logger.debug("   Пропущен (файл библиотеки)")
                continue

            file_path = Path(filename)
            if file_path.suffix != ".py":
                logger.debug("   Пропущен (не .py файл)")
                continue

            bot_id = file_path.stem
            if bot_id and not bot_id.startswith("_"):
                logger.debug("🔍 Найден файл для определения bot_id: %s -> %s", filename, bot_id)
                return bot_id

            logger.debug("   Пропущен (служебный файл: %s)", bot_id)

        logger.debug("🔍 Не удалось найти подходящий файл в стеке вызовов")
        return None
    except Exception as e:
        logger.debug("Ошибка при определении bot_id из имени файла: %s", e, exc_info=True)
        return None
