"""
Internal helpers for BotBuilder.test().
"""

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)


async def run_tests(builder: Any, scenario_file: Optional[str], max_concurrent: int, verbose: bool) -> int:
    """Implementation of BotBuilder.test()."""
    if not builder._initialized:
        logger.info("🔧 Компоненты бота %s не инициализированы, вызываем build()", builder.bot_id)
        await builder.build()

    logger.info("🧪 Запускаем тестирование бота %s", builder.bot_id)

    try:
        logger.info("=" * 70)
        logger.info("📋 ИНФОРМАЦИЯ О НАСТРОЙКАХ БОТА:")
        logger.info("=" * 70)

        if builder.openai_client:
            tools = builder.openai_client.get_tools()
            logger.info("🔧 Инструментов зарегистрировано в OpenAI клиенте: %s", len(tools))
            if tools:
                logger.info("   Список инструментов:")
                for i, tool in enumerate(tools, 1):
                    tool_name = getattr(tool, "name", str(tool))
                    logger.info("   %s. %s", i, tool_name)

        if builder.prompt_loader:
            tools_description = getattr(builder.prompt_loader, "_tools_description", "")
            if tools_description:
                logger.info("📝 Описание инструментов в промпт-лоадере: %s символов", len(tools_description))
                if verbose:
                    logger.info("   Превью: %s...", tools_description[:200])
            else:
                logger.info("⚠️ Описание инструментов не найдено в промпт-лоадере")

        if builder._rag_routers:
            logger.info("🔍 RAG-роутеров зарегистрировано: %s", len(builder._rag_routers))
            for i, rag_router in enumerate(builder._rag_routers, 1):
                router_name = getattr(rag_router, "name", f"rag_router_{i}")
                tools = getattr(rag_router, "get_tools", lambda: [])()
                tool_count = len(tools) if tools else 0
                logger.info("   %s. %s (%s инструментов)", i, router_name, tool_count)
        else:
            logger.info("🔍 RAG-роутеров: 0")

        if builder._tool_routers:
            logger.info("🔧 Tool роутеров зарегистрировано: %s", len(builder._tool_routers))
            for i, tool_router in enumerate(builder._tool_routers, 1):
                router_name = getattr(tool_router, "name", f"tool_router_{i}")
                tools = getattr(tool_router, "get_tools", lambda: [])()
                tool_count = len(tools) if tools else 0
                logger.info("   %s. %s (%s инструментов)", i, router_name, tool_count)
        else:
            logger.info("🔧 Tool роутеров: 0")

        if builder.router_manager:
            routers = getattr(builder.router_manager, "_routers", [])
            if routers:
                logger.info("📡 Event роутеров зарегистрировано: %s", len(routers))
                for i, router in enumerate(routers, 1):
                    router_name = getattr(router, "name", f"event_router_{i}")
                    handlers = getattr(router, "_handlers", {})
                    handler_count = sum(len(h) for h in handlers.values()) if handlers else 0
                    logger.info("   %s. %s (%s обработчиков)", i, router_name, handler_count)
            else:
                logger.info("📡 Event роутеров: 0")
        else:
            logger.info("📡 Event роутеров: 0")

        if builder._telegram_routers:
            logger.info("💬 Telegram роутеров зарегистрировано: %s", len(builder._telegram_routers))
            for i, telegram_router in enumerate(builder._telegram_routers, 1):
                router_name = getattr(telegram_router, "name", f"telegram_router_{i}")
                logger.info("   %s. %s", i, router_name)
        else:
            logger.info("💬 Telegram роутеров: 0")

        message_hooks = builder.get_message_hooks()
        total_hooks = sum(len(hooks) for hooks in message_hooks.values())
        logger.info("🎣 Хуков зарегистрировано: %s", total_hooks)
        for hook_type, hooks in message_hooks.items():
            if hooks:
                logger.info("   - %s: %s", hook_type, len(hooks))

        logger.info("=" * 70)

        from ..bot_testing import ReportGenerator, ScenarioLoader, TestRunner

        if scenario_file:
            if not scenario_file.endswith(".yaml"):
                scenario_file = f"{scenario_file}.yaml"
            scenario_path = builder.config_dir / "tests" / scenario_file
            scenarios = ScenarioLoader.load_scenarios_from_file(str(scenario_path))
            if not scenarios:
                logger.error("Файл сценариев '%s' не найден или пуст", scenario_file)
                return 1
        else:
            scenarios = ScenarioLoader.load_all_scenarios_for_bot(builder.bot_id, builder.config_dir.parent.parent)
            if not scenarios:
                logger.error("Сценарии для бота '%s' не найдены", builder.bot_id)
                return 1

        logger.info("📋 Найдено сценариев: %s", len(scenarios))
        if scenario_file:
            logger.info("📋 Тестируется файл: %s", scenario_file)
        else:
            logger.info("📋 Тестируются все файлы сценариев")

        from ..bot_testing import BotTesterIntegrated

        bot_tester = BotTesterIntegrated(
            bot_id=builder.bot_id,
            openai_client=builder.openai_client,
            prompt_loader=builder.prompt_loader,
            supabase_client=builder.supabase_client,
            config_dir=builder.config_dir,
            message_hooks=message_hooks,
        )
        logger.info("✅ Тестер создан с использованием всех настроек из BotBuilder")
        logger.info("   - OpenAI клиент: %s", type(builder.openai_client).__name__)
        logger.info("   - PromptLoader: %s", type(builder.prompt_loader).__name__)
        logger.info("   - Supabase клиент: %s", type(builder.supabase_client).__name__)
        logger.info("   - Хуков передано: %s", total_hooks)

        test_runner = TestRunner(builder.bot_id, max_concurrent, builder.config_dir.parent.parent)
        test_runner.bot_tester = bot_tester

        results = await test_runner.run_tests(scenarios)

        ReportGenerator.generate_console_report(builder.bot_id, results)
        report_file = ReportGenerator.save_report(builder.bot_id, results, builder.config_dir.parent.parent)

        logger.info("📄 Подробный отчет сохранен: %s", report_file)

        failed_count = sum(1 for r in results if not r.passed)
        return 0 if failed_count == 0 else 1
    except Exception as e:
        logger.error("❌ Ошибка при тестировании бота %s: %s", builder.bot_id, e)
        import traceback

        logger.error("Стек ошибки: %s", traceback.format_exc())
        return 1
