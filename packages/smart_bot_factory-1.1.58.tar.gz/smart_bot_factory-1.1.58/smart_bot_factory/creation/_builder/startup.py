"""
Internal helpers for BotBuilder startup/runtime lifecycle.
"""

import asyncio
import logging
from typing import Any, Optional

from sulguk import AiogramSulgukMiddleware

logger = logging.getLogger(__name__)


def setup_context(builder: Any, bot: Any, dp: Any) -> None:
    """Implementation of BotBuilder._setup_context()."""
    from ...utils.context import ctx

    logger.info("🔧 Установка компонентов в глобальный контекст ctx")

    ctx.config = builder.config
    ctx.supabase_client = builder.supabase_client
    ctx.openai_client = builder.openai_client
    ctx.prompt_loader = builder.prompt_loader

    ctx.admin_manager = builder.admin_manager
    ctx.analytics_manager = builder.analytics_manager
    ctx.conversation_manager = builder.conversation_manager
    ctx.memory_manager = builder.memory_manager
    ctx.router_manager = builder.router_manager

    ctx.message_hooks = builder.get_message_hooks()
    ctx.tools_prompt = builder.get_tools_prompt()
    ctx.start_handlers = builder._start_handlers
    ctx.rag_pipeline = getattr(builder, "rag_pipeline", None)
    ctx.utm_triggers = builder._utm_triggers
    ctx.custom_event_processor = builder._custom_event_processor
    ctx.custom_event_proceses = builder._custom_event_processor  # DEPRECATED

    ctx.bot = bot
    ctx.dp = dp


async def cleanup_resources(builder: Any, bot: Any, dp: Any) -> None:
    """Implementation of BotBuilder._cleanup_resources()."""
    try:
        if builder.prompt_watcher and builder.prompt_watcher.is_running():
            builder.prompt_watcher.stop()
            logger.info("✅ PromptWatcher остановлен")

        if bot and hasattr(bot, "session"):
            await bot.session.close()

        if builder.supabase_client:
            close_method = getattr(builder.supabase_client, "close", None)
            if close_method and callable(close_method):
                await close_method()

        if builder.prompt_loader and hasattr(builder.prompt_loader, "cleanup_temp_files"):
            builder.prompt_loader.cleanup_temp_files()

        from ...utils.context import ctx

        ctx.bot = None
        ctx.dp = None
    except Exception:
        logger.debug("Failed to cleanup BotBuilder resources", exc_info=True)


async def setup_bot_commands(builder: Any, bot: Any) -> None:
    """Implementation of BotBuilder._setup_bot_commands()."""
    from aiogram.types import BotCommand, BotCommandScopeChat, BotCommandScopeDefault

    from ...i18n.translator import translate

    if not builder.config:
        raise RuntimeError("Config не инициализирован")

    lang = getattr(builder.config, "UI_LANGUAGE", "ru")

    try:
        user_commands = [
            BotCommand(
                command="start",
                description=translate("commands_menu.user.start", lang=lang),
            ),
            BotCommand(
                command="help",
                description=translate("commands_menu.user.help", lang=lang),
            ),
        ]
        await bot.set_my_commands(user_commands, scope=BotCommandScopeDefault())
        logger.info("✅ Установлены команды для обычных пользователей")

        admin_commands = [
            BotCommand(
                command="start",
                description=translate("commands_menu.admin.start", lang=lang),
            ),
            BotCommand(
                command="help",
                description=translate("commands_menu.admin.help", lang=lang),
            ),
            BotCommand(
                command="cancel",
                description=translate("commands_menu.admin.cancel", lang=lang),
            ),
            BotCommand(
                command="admin",
                description=translate("commands_menu.admin.admin", lang=lang),
            ),
            BotCommand(
                command="stats",
                description=translate("commands_menu.admin.stats", lang=lang),
            ),
            BotCommand(
                command="dashboard",
                description=translate("commands_menu.admin.dashboard", lang=lang),
            ),
            BotCommand(
                command="chat",
                description=translate("commands_menu.admin.chat", lang=lang),
            ),
            BotCommand(
                command="chats",
                description=translate("commands_menu.admin.chats", lang=lang),
            ),
            BotCommand(
                command="stop",
                description=translate("commands_menu.admin.stop", lang=lang),
            ),
            BotCommand(
                command="history",
                description=translate("commands_menu.admin.history", lang=lang),
            ),
            BotCommand(
                command="create_event",
                description=translate("commands_menu.admin.create_event", lang=lang),
            ),
            BotCommand(
                command="list_events",
                description=translate("commands_menu.admin.list_events", lang=lang),
            ),
            BotCommand(
                command="delete_event",
                description=translate("commands_menu.admin.delete_event", lang=lang),
            ),
            BotCommand(
                command="edit_event",
                description=translate("commands_menu.admin.edit_event", lang=lang),
            ),
        ]

        for admin_id in builder.config.ADMIN_TELEGRAM_IDS:
            try:
                await bot.set_my_commands(admin_commands, scope=BotCommandScopeChat(chat_id=admin_id))
                logger.info("✅ Установлены админские команды для %s", admin_id)
            except Exception as e:
                logger.warning("⚠️ Не удалось установить команды для админа %s: %s", admin_id, e)

        logger.info("✅ Меню команд настроено (%s админов)", len(builder.config.ADMIN_TELEGRAM_IDS))
    except Exception as e:
        logger.error("❌ Ошибка установки команд бота: %s", e)


async def start(builder: Any) -> None:
    """Implementation of BotBuilder.start()."""
    if not builder._initialized:
        logger.info("🔧 Бот %s не инициализирован, вызываем build() автоматически", builder.bot_id)
        await builder.build()

    logger.info("🚀 Запускаем бота %s", builder.bot_id)

    bot: Optional[Any] = None
    dp: Optional[Any] = None
    try:
        from aiogram import Bot, Dispatcher
        from aiogram.fsm.storage.memory import MemoryStorage

        if not builder.config:
            raise RuntimeError("Config не инициализирован. Вызовите build() перед start()")

        bot = Bot(token=builder.config.TELEGRAM_BOT_TOKEN)

        if builder.config.MESSAGE_PARSE_MODE.upper() == "HTML":
            bot.session.middleware(AiogramSulgukMiddleware())
            logger.info("✅ Sulguk middleware добавлен для обработки HTML")

        storage = MemoryStorage()
        dp = Dispatcher(storage=storage)

        from ...error_handling import ErrorHandlingMiddleware

        dp.message.middleware(ErrorHandlingMiddleware())
        dp.callback_query.middleware(ErrorHandlingMiddleware())
        logger.info("✅ Error handling middleware зарегистрирован")

        await setup_bot_commands(builder, bot)

        from ...admin.admin_events import admin_events_router
        from ...admin.admin_events_edit import admin_events_edit_router
        from ...admin.admin_logic import admin_router
        from ...handlers.routers.main import router as handlers_router
        from ...rag.refresh_rag_handlers import refresh_rag_router
        from ...handlers.routers.utils_commands import utils_router

        if builder._telegram_routers:
            logger.info("🔗 Подключаем %s пользовательских Telegram роутеров", len(builder._telegram_routers))
            for telegram_router in builder._telegram_routers:
                dp.include_router(telegram_router)
                router_name = getattr(telegram_router, "name", "unnamed")
                logger.info("✅ Подключен Telegram роутер: %s", router_name)

        standard_routers = [
            admin_events_router,
            admin_events_edit_router,
            admin_router,
            utils_router,
            handlers_router,
        ]
        if getattr(builder, "rag_pipeline", None) is not None:
            standard_routers.insert(4, refresh_rag_router)
        dp.include_routers(*standard_routers)
        logger.info("✅ Все стандартные роутеры подключены")

        if builder.router_manager:
            from ...event.decorators.registry import set_router_manager

            set_router_manager(builder.router_manager)
            logger.info("✅ RouterManager установлен в decorators")

            builder.router_manager._update_combined_handlers()
            logger.info("✅ RouterManager обработчики обновлены")

        setup_context(builder, bot=bot, dp=dp)

        from ...event.decorators.processor import background_event_processor_with_deps
        from ...event.decorators.utils import resolve_event_deps_from_ctx

        event_deps = resolve_event_deps_from_ctx()
        asyncio.create_task(background_event_processor_with_deps(event_deps))
        logger.info("✅ Фоновый процессор событий запущен (user_event, scheduled_task, global_handler, admin_event)")

        for start_task_fn in builder._start_tasks:
            asyncio.create_task(start_task_fn())
            logger.info("✅ Стартовая задача запущена: %s", getattr(start_task_fn, "__name__", "?"))

        logger.info("✅ Бот %s запущен и готов к работе!", builder.bot_id)
        if builder.config:
            logger.info("   📊 Изоляция данных: bot_id = %s", builder.config.BOT_ID)
            logger.info("   👑 Админов настроено: %s", len(builder.config.ADMIN_TELEGRAM_IDS))
            logger.info("   📝 Загружено промптов: %s", len(builder.config.PROMPT_FILES))

        print(f"\n🤖 БОТ {builder.bot_id.upper()} УСПЕШНО ЗАПУЩЕН!")
        if builder.config:
            print(f"📱 Telegram Bot ID: {builder.config.BOT_ID}")
            print(f"👑 Админов: {len(builder.config.ADMIN_TELEGRAM_IDS)}")
            print(f"📝 Промптов: {len(builder.config.PROMPT_FILES)}")
        print("⏳ Ожидание сообщений...")
        print("⏹️ Для остановки нажмите Ctrl+C\n")

        await dp.start_polling(bot)
    except Exception as e:
        logger.error("❌ Ошибка при запуске бота %s: %s", builder.bot_id, e)
        import traceback

        logger.error("Стек ошибки: %s", traceback.format_exc())
        raise
    finally:
        await cleanup_resources(builder, bot=bot, dp=dp)
