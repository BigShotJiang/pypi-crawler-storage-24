"""
Internal helpers for BotBuilder message hooks registration.
"""

import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


def validate_message(builder: Any, handler: Any) -> Any:
    """Internal implementation for BotBuilder.validate_message()."""
    if not callable(handler):
        raise TypeError(f"Обработчик должен быть callable, получен {type(handler)}")
    builder._message_validators.append(handler)
    logger.info("✅ Зарегистрирован валидатор сообщений: %s", getattr(handler, "__name__", "?"))
    return handler


def enrich_prompt(builder: Any, handler: Any) -> Any:
    """Internal implementation for BotBuilder.enrich_prompt()."""
    if not callable(handler):
        raise TypeError(f"Обработчик должен быть callable, получен {type(handler)}")
    builder._prompt_enrichers.append(handler)
    logger.info("✅ Зарегистрирован обогатитель промпта: %s", getattr(handler, "__name__", "?"))
    return handler


def enrich_context(builder: Any, handler: Any) -> Any:
    """Internal implementation for BotBuilder.enrich_context()."""
    if not callable(handler):
        raise TypeError(f"Обработчик должен быть callable, получен {type(handler)}")
    builder._context_enrichers.append(handler)
    logger.info("✅ Зарегистрирован обогатитель контекста: %s", getattr(handler, "__name__", "?"))
    return handler


def process_response(builder: Any, handler: Any) -> Any:
    """Internal implementation for BotBuilder.process_response()."""
    if not callable(handler):
        raise TypeError(f"Обработчик должен быть callable, получен {type(handler)}")
    builder._response_processors.append(handler)
    logger.info("✅ Зарегистрирован обработчик ответа: %s", getattr(handler, "__name__", "?"))
    return handler


def filter_send(builder: Any, handler: Any) -> Any:
    """Internal implementation for BotBuilder.filter_send()."""
    if not callable(handler):
        raise TypeError(f"Обработчик должен быть callable, получен {type(handler)}")
    builder._send_filters.append(handler)
    logger.info("✅ Зарегистрирован фильтр отправки: %s", getattr(handler, "__name__", "?"))
    return handler


def get_message_hooks(builder: Any) -> Dict[str, List[Any]]:
    """Internal implementation for BotBuilder.get_message_hooks()."""
    return {
        "validators": builder._message_validators.copy(),
        "prompt_enrichers": builder._prompt_enrichers.copy(),
        "context_enrichers": builder._context_enrichers.copy(),
        "response_processors": builder._response_processors.copy(),
        "send_filters": builder._send_filters.copy(),
    }
