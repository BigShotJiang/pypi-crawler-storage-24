from __future__ import annotations

import asyncio
import logging
import time
from pathlib import Path
from typing import Optional

from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

logger = logging.getLogger(__name__)


class PromptReloadHandler(FileSystemEventHandler):
    """Обработчик изменений файлов промптов."""

    def __init__(self, prompt_loader, loop: asyncio.AbstractEventLoop):
        self.prompt_loader = prompt_loader
        self.loop = loop
        self._pending_reloads: dict[str, asyncio.Task] = {}
        self._debounce_delay = 0.5
        self._reload_times: list[float] = []
        self._max_reloads_per_minute = 10

    def on_modified(self, event):
        """Обработчик изменения файлов."""
        if event.is_directory:
            return

        if not event.src_path.endswith(".txt"):
            return

        file_name = Path(event.src_path).name
        if file_name.startswith(".") or file_name.endswith("~") or file_name.endswith(".swp"):
            return

        logger.info(f"🔄 Обнаружено изменение файла: {file_name}")
        self.loop.call_soon_threadsafe(self._schedule_reload, file_name)

    def _schedule_reload(self, file_name: str) -> None:
        """Планирует debounce-задачу в event loop бота."""
        old_task = self._pending_reloads.get(file_name)
        if old_task:
            old_task.cancel()
            logger.debug(f"Отменена предыдущая задача перезагрузки для {file_name}")

        task = self.loop.create_task(self._debounced_reload(file_name))
        self._pending_reloads[file_name] = task

    async def _debounced_reload(self, file_name: str):
        """Перезагрузка с debounce + rate limit."""
        try:
            await asyncio.sleep(self._debounce_delay)

            now = time.time()
            self._reload_times = [t for t in self._reload_times if now - t < 60]
            if len(self._reload_times) >= self._max_reloads_per_minute:
                logger.warning(
                    f"⚠️ Rate limit: превышен лимит {self._max_reloads_per_minute} перезагрузок в минуту. Пропускаю перезагрузку {file_name}"
                )
                return

            logger.info(f"♻️ Перезагрузка промпта: {file_name}")
            await self._reload_prompt(file_name)
            self._reload_times.append(now)
        except asyncio.CancelledError:
            logger.debug(f"Задача перезагрузки {file_name} отменена (debouncing)")
        except Exception as e:
            logger.error(f"❌ Ошибка в _debounced_reload для {file_name}: {e}")
        finally:
            self._pending_reloads.pop(file_name, None)

    async def _reload_prompt(self, file_name: str):
        """Перезагрузка через PromptLoader."""
        try:
            new_prompt = await self.prompt_loader.reload_system_prompt()
            logger.info(f"✅ Промпт успешно перезагружен! ({len(new_prompt)} символов)")
        except Exception as e:
            logger.error(f"❌ Ошибка перезагрузки промпта {file_name}: {e}")
            logger.exception("Стек ошибки:")


class PromptWatcher:
    """Менеджер watchdog-наблюдателя за файлами промптов."""

    def __init__(self, prompts_dir: Path, prompt_loader, loop: asyncio.AbstractEventLoop):
        self.prompts_dir = Path(prompts_dir)
        self.prompt_loader = prompt_loader
        self.loop = loop
        self.observer: Optional[Observer] = None
        self._is_running = False

    def start(self):
        """Запуск наблюдения."""
        if not self.prompts_dir.exists():
            logger.warning(f"⚠️ Папка промптов не найдена: {self.prompts_dir}")
            logger.warning("Hot Reload для промптов НЕ активирован")
            return

        if self._is_running:
            logger.warning("⚠️ PromptWatcher уже запущен")
            return

        try:
            handler = PromptReloadHandler(self.prompt_loader, self.loop)
            self.observer = Observer()
            self.observer.schedule(handler, path=str(self.prompts_dir), recursive=False)
            self.observer.start()
            self._is_running = True
            logger.info(f"👁️ Hot Reload активирован для: {self.prompts_dir}")
            logger.info("Отслеживаются изменения .txt файлов")
        except Exception as e:
            logger.error(f"❌ Ошибка запуска PromptWatcher: {e}")
            logger.exception("Стек ошибки:")
            self._is_running = False

    def stop(self):
        """Остановка наблюдения."""
        if not self._is_running or not self.observer:
            return

        try:
            logger.info("👁️ Остановка PromptWatcher...")
            self.observer.stop()
            self.observer.join(timeout=5)
            self._is_running = False
            logger.info("👁️ PromptWatcher остановлен")
        except Exception as e:
            logger.error(f"❌ Ошибка остановки PromptWatcher: {e}")

    def is_running(self) -> bool:
        return self._is_running

