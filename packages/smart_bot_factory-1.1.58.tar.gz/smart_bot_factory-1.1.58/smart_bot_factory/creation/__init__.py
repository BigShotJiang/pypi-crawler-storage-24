"""
Creation modules for smart_bot_factory.

Keep imports lazy to avoid circular import chains during test collection.
"""

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .bot_builder import BotBuilder

__all__ = ["BotBuilder"]


def __getattr__(name: str) -> Any:
    if name == "BotBuilder":
        from .bot_builder import BotBuilder

        return BotBuilder
    raise AttributeError(name)
