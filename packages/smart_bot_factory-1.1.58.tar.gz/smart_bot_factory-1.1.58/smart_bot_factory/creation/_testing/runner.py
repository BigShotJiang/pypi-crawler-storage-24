import asyncio
import logging
from pathlib import Path
from typing import List

from .models import StepResult, TestResult, TestScenario
from .testers import BotTester


class TestRunner:
    """Запускатель тестов"""

    def __init__(self, bot_id: str, max_concurrent: int, project_root: Path):
        self.bot_id = bot_id
        self.max_concurrent = max_concurrent
        self.project_root = project_root
        self.bot_tester = BotTester(bot_id, self.project_root)

    async def run_tests(self, scenarios: List[TestScenario]) -> List[TestResult]:
        """Запускает тесты асинхронно"""
        semaphore = asyncio.Semaphore(self.max_concurrent)

        async def run_single_test(scenario: TestScenario) -> TestResult:
            async with semaphore:
                logging.info(f"🧪 Выполнение теста: {scenario.name}")
                result = await self.bot_tester.test_scenario(scenario)
                status = "✅" if result.passed else "❌"
                logging.info(f"   {status} {scenario.name}")
                return result

        tasks = [run_single_test(scenario) for scenario in scenarios]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        processed_results: List[TestResult] = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                logging.error(f"Исключение в тесте {scenarios[i].name}: {result}")
                step_results = []
                for step in scenarios[i].steps:
                    missing_keywords_flat = []
                    for group in step.expected_keywords:
                        if isinstance(group, list):
                            missing_keywords_flat.extend(group)
                        else:
                            missing_keywords_flat.append(str(group))

                    step_result = StepResult(
                        step=step,
                        bot_response=f"ИСКЛЮЧЕНИЕ: {str(result)}",
                        passed=False,
                        missing_keywords=missing_keywords_flat,
                        found_forbidden=[],
                    )
                    step_results.append(step_result)

                processed_results.append(TestResult(scenario=scenarios[i], step_results=step_results))
            else:
                processed_results.append(result)

        return processed_results
