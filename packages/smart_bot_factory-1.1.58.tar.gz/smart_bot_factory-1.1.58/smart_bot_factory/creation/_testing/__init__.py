"""
Internal implementation of bot testing utilities.

Public surface stays in `smart_bot_factory.creation.bot_testing`.
"""
