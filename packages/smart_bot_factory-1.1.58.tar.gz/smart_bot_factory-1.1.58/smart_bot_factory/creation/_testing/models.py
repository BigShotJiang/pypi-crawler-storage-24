from typing import List, Optional


class TestStep:
    """Класс для представления одного шага в сценарии"""

    def __init__(
        self,
        user_input: str,
        expected_keywords: List[str],
        forbidden_keywords: List[str] = [],
    ):
        self.user_input = user_input
        # Поддержка синонимов: если элемент списка - список, то это синонимы
        self.expected_keywords = self._process_keywords(expected_keywords)
        self.forbidden_keywords = [kw.lower() for kw in (forbidden_keywords or [])]

    def _process_keywords(self, keywords: List) -> List:
        """Обрабатывает ключевые слова, поддерживая синонимы"""
        processed = []
        for kw in keywords:
            if isinstance(kw, list):
                # Это группа синонимов
                synonyms = [s.lower() for s in kw if isinstance(s, str)]
                processed.append(synonyms)
            elif isinstance(kw, str):
                # Одно слово
                processed.append([kw.lower()])
            else:
                # Игнорируем неверные типы
                continue
        return processed


class TestScenario:
    """Класс для представления тестового сценария с последовательными шагами"""

    def __init__(self, name: str, steps: List[TestStep]):
        self.name = name
        self.steps = steps
        self.source_file: Optional[str] = None
        self.scenario_number: Optional[int] = None


class StepResult:
    """Класс для представления результата одного шага"""

    def __init__(
        self,
        step: TestStep,
        bot_response: str,
        passed: bool,
        missing_keywords: Optional[List[str]] = None,
        found_forbidden: Optional[List[str]] = None,
    ):
        self.step = step
        self.bot_response = bot_response
        self.passed = passed
        self.missing_keywords = missing_keywords or []
        self.found_forbidden = found_forbidden or []


class TestResult:
    """Класс для представления результата тестирования сценария"""

    def __init__(self, scenario: TestScenario, step_results: List[StepResult]):
        self.scenario = scenario
        self.step_results = step_results
        self.passed = all(step.passed for step in step_results)
        self.total_steps = len(step_results)
        self.passed_steps = sum(1 for step in step_results if step.passed)
        self.failed_steps = self.total_steps - self.passed_steps
