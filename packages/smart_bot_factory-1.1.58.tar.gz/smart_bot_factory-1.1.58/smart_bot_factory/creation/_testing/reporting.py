import glob
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from .models import TestResult
from .project_root import get_project_root


class ReportGenerator:
    """Генератор отчетов о тестировании"""

    @staticmethod
    def cleanup_old_reports(reports_dir: str, max_reports: int = 10):
        """Удаляет старые отчеты, оставляя только max_reports самых новых"""
        if not os.path.exists(reports_dir):
            return

        report_pattern = os.path.join(reports_dir, "test_*.txt")
        report_files = glob.glob(report_pattern)

        if len(report_files) <= max_reports:
            return

        report_files.sort(key=lambda x: os.path.getmtime(x))
        files_to_delete = report_files[: -(max_reports - 1)]

        for file_path in files_to_delete:
            try:
                os.remove(file_path)
                filename = os.path.basename(file_path)
                logging.info(f"🗑️ Удален старый отчет: {filename}")
            except Exception as e:
                logging.warning(f"Не удалось удалить отчет {file_path}: {e}")

    @staticmethod
    def generate_console_report(bot_id: str, results: List[TestResult]):
        """Генерирует отчет в консоль"""
        passed_count = sum(1 for r in results if r.passed)
        total_steps = sum(r.total_steps for r in results)
        passed_steps = sum(r.passed_steps for r in results)
        success_rate = (passed_count / len(results)) * 100 if results else 0
        step_success_rate = (passed_steps / total_steps) * 100 if total_steps else 0

        print(f"\n📊 РЕЗУЛЬТАТЫ: {bot_id.upper()}")
        print(f"✅ Сценариев пройдено: {passed_count}/{len(results)} ({success_rate:.1f}%)")
        print(f"📝 Шагов пройдено: {passed_steps}/{total_steps} ({step_success_rate:.1f}%)")

        if success_rate >= 90:
            print("🎉 ОТЛИЧНО — бот готов к продакшену")
        elif success_rate >= 80:
            print("✅ ХОРОШО — небольшие улучшения")
        elif success_rate >= 60:
            print("⚠️ УДОВЛЕТВОРИТЕЛЬНО — требуются улучшения")
        else:
            print("🚨 ПЛОХО — критические проблемы с промптами")

    @staticmethod
    def generate_detailed_report(bot_id: str, results: List[TestResult]) -> str:
        """Генерирует подробный отчет"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        report_lines = [
            f"ОТЧЕТ ТЕСТИРОВАНИЯ: {bot_id.upper()}",
            f"Время: {timestamp}",
            f"Сценариев: {len(results)}",
            "",
        ]

        passed_count = sum(1 for r in results if r.passed)
        total_steps = sum(r.total_steps for r in results)
        passed_steps = sum(r.passed_steps for r in results)
        success_rate = (passed_count / len(results)) * 100 if results else 0
        step_success_rate = (passed_steps / total_steps) * 100 if total_steps else 0

        report_lines.extend(
            [
                f"УСПЕШНОСТЬ СЦЕНАРИЕВ: {success_rate:.1f}% ({passed_count}/{len(results)})",
                f"УСПЕШНОСТЬ ШАГОВ: {step_success_rate:.1f}% ({passed_steps}/{total_steps})",
                "",
            ]
        )

        failed_tests = [r for r in results if not r.passed]
        if failed_tests:
            report_lines.extend(
                [
                    "═══════════════════════════════════════════════════════════════",
                    "СПИСОК ОШИБОК:",
                    "═══════════════════════════════════════════════════════════════",
                ]
            )

            for result in failed_tests:
                scenario = result.scenario
                source_file = getattr(scenario, "source_file", "unknown")
                scenario_number = getattr(scenario, "scenario_number", "?")

                display_name = scenario.name if not scenario.name.startswith("[") else f"[{source_file}-{scenario_number}]"
                report_lines.extend(
                    [
                        f"ФАЙЛ: {source_file}.yaml | СЦЕНАРИЙ: {display_name}",
                        f"СТАТУС: {result.passed_steps}/{result.total_steps} шагов пройдено",
                        "",
                    ]
                )

                for i, step_result in enumerate(result.step_results):
                    step_num = i + 1
                    status = "✅" if step_result.passed else "❌"

                    expected_display = []
                    for group in step_result.step.expected_keywords:
                        if len(group) == 1:
                            expected_display.append(group[0])
                        else:
                            expected_display.append(f"[{'/'.join(group)}]")

                    report_lines.extend(
                        [
                            f"ШАГ {step_num} {status}:",
                            f'  Ввод: "{step_result.step.user_input}"',
                            f"  Ожидаемые: {expected_display}",
                            f"  Запрещенные: {step_result.step.forbidden_keywords}",
                            "",
                        ]
                    )

                    bot_response = step_result.bot_response.strip()
                    bot_response_formatted = bot_response.replace("\n", "\\n")
                    report_lines.extend(["  Полный ответ бота:", f'  "{bot_response_formatted}"', ""])

                    if not step_result.passed:
                        if step_result.missing_keywords:
                            missing_str = []
                            for kw in step_result.missing_keywords:
                                if isinstance(kw, list):
                                    missing_str.extend(str(item) for item in kw)
                                else:
                                    missing_str.append(str(kw))
                            report_lines.append(f"    ❌ НЕ НАЙДЕНЫ: {', '.join(missing_str)}")

                        if step_result.found_forbidden:
                            report_lines.append(f"    ❌ НАЙДЕНЫ ЗАПРЕЩЕННЫЕ: {', '.join(step_result.found_forbidden)}")

                        report_lines.append("")

                report_lines.extend(["-" * 67, ""])

        passed_tests = [r for r in results if r.passed]
        if passed_tests:
            report_lines.extend(["ПРОЙДЕННЫЕ СЦЕНАРИИ:", ""])
            for result in passed_tests:
                scenario = result.scenario
                source_file = getattr(scenario, "source_file", "unknown")
                scenario_number = getattr(scenario, "scenario_number", "?")

                display_name = scenario.name if not scenario.name.startswith("[") else f"[{source_file}-{scenario_number}]"
                report_lines.append(f"✅ {source_file}.yaml | {display_name}")

        return "\n".join(report_lines)

    @staticmethod
    def save_report(bot_id: str, results: List[TestResult], project_root: Optional[Path] = None) -> str:
        """Сохраняет отчет в файл"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        user_root_dir = project_root or get_project_root()

        bots_dir = user_root_dir / "bots" / bot_id
        if not bots_dir.exists():
            logging.warning(f"Папка bots/{bot_id} не найдена в проекте: {bots_dir}")
            return ""

        reports_dir = user_root_dir / "bots" / bot_id / "reports"
        os.makedirs(reports_dir, exist_ok=True)

        ReportGenerator.cleanup_old_reports(str(reports_dir), max_reports=10)

        report_filename = reports_dir / f"test_{timestamp}.txt"
        report_content = ReportGenerator.generate_detailed_report(bot_id, results)

        with open(report_filename, "w", encoding="utf-8") as f:
            f.write(report_content)

        return str(report_filename)
