import logging
import os
from pathlib import Path

from project_root_finder import root

# Global project root (smart_bot_factory/creation/ -> project_root)
PROJECT_ROOT = root


def set_project_root(new_root: Path) -> None:
    """Устанавливает новую корневую директорию проекта"""
    global PROJECT_ROOT
    PROJECT_ROOT = Path(new_root).resolve()
    logging.info("Корневая директория проекта изменена на: %s", PROJECT_ROOT)


def get_project_root() -> Path:
    """Возвращает текущую корневую директорию проекта"""
    env_project_root = os.getenv("PROJECT_ROOT")
    if env_project_root:
        return Path(env_project_root).resolve()
    return PROJECT_ROOT
