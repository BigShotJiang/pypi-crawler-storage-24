import logging
from pathlib import Path
from typing import List, Optional

import yaml

from .models import TestScenario, TestStep
from .project_root import get_project_root


class ScenarioLoader:
    """Загрузчик тестовых сценариев из YAML файлов"""

    @staticmethod
    def load_scenarios_from_file(file_path: str) -> List[TestScenario]:
        """Загружает сценарии из YAML файла"""
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                data = yaml.safe_load(file)

            scenarios = []
            file_name = Path(file_path).stem

            for i, scenario_data in enumerate(data.get("scenarios", [])):
                # Проверяем новый формат со steps
                if "steps" in scenario_data:
                    # Новый формат: сценарий с шагами
                    name = scenario_data.get("name", f"[{file_name}-{i + 1}]")
                    steps = []

                    for step_data in scenario_data["steps"]:
                        step = TestStep(
                            user_input=step_data.get("user_input", ""),
                            expected_keywords=step_data.get("expected_keywords", []),
                            forbidden_keywords=step_data.get("forbidden_keywords", []),
                        )
                        steps.append(step)

                    scenario = TestScenario(name=name, steps=steps)

                else:
                    # Старый формат: одиночный вопрос -> превращаем в сценарий с одним шагом
                    name = scenario_data.get("name", f"[{file_name}-{i + 1}]")
                    step = TestStep(
                        user_input=scenario_data.get("user_input", ""),
                        expected_keywords=scenario_data.get("expected_keywords", []),
                        forbidden_keywords=scenario_data.get("forbidden_keywords", []),
                    )
                    scenario = TestScenario(name=name, steps=[step])

                # Добавляем информацию о файле для отчетности
                scenario.source_file = file_name
                scenario.scenario_number = i + 1

                scenarios.append(scenario)

            return scenarios

        except Exception as e:
            logging.error("Ошибка загрузки сценариев из %s: %s", file_path, e)
            return []

    @staticmethod
    def load_all_scenarios_for_bot(bot_id: str, project_root: Optional[Path] = None) -> List[TestScenario]:
        """Загружает все сценарии для указанного бота"""
        user_root_dir = project_root or get_project_root()

        bots_dir = user_root_dir / "bots" / bot_id
        if not bots_dir.exists():
            logging.warning("Папка bots/%s не найдена в проекте: %s", bot_id, bots_dir)
            return []

        tests_dir = user_root_dir / "bots" / bot_id / "tests"
        if not tests_dir.exists():
            logging.warning("Каталог тестов не найден: %s", tests_dir)
            return []

        all_scenarios: List[TestScenario] = []
        for yaml_file in tests_dir.glob("*.yaml"):
            scenarios = ScenarioLoader.load_scenarios_from_file(str(yaml_file))
            all_scenarios.extend(scenarios)

        return all_scenarios
