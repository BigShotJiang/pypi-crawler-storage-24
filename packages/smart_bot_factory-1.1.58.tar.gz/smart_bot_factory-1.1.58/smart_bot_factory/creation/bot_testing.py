#!/usr/bin/env python3
"""
Система тестирования ботов (публичный фасад).

Реализация находится в `smart_bot_factory/creation/_testing/`,
а этот модуль сохраняет обратную совместимость импортов и CLI.
"""

from __future__ import annotations

# Allow running as a script: `python smart_bot_factory/creation/bot_testing.py ...`
if __name__ == "__main__" and __package__ is None:
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
    __package__ = "smart_bot_factory.creation"

from ._testing.cli import main, run_cli
from ._testing.models import StepResult, TestResult, TestScenario, TestStep
from ._testing.project_root import get_project_root, set_project_root
from ._testing.reporting import ReportGenerator
from ._testing.runner import TestRunner
from ._testing.scenario_loader import ScenarioLoader
from ._testing.testers import BotTester, BotTesterIntegrated

__all__ = [
    "BotTester",
    "BotTesterIntegrated",
    "ReportGenerator",
    "ScenarioLoader",
    "StepResult",
    "TestResult",
    "TestRunner",
    "TestScenario",
    "TestStep",
    "get_project_root",
    "main",
    "set_project_root",
]


if __name__ == "__main__":
    run_cli()
