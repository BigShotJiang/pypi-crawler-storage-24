"""Lightweight CLI command handlers."""

from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path
from typing import Callable, List, Optional

import click


def handle_create(bot_id: str, template: str, create_new_bot_structure: Callable[[str, str], bool]) -> None:
    success = create_new_bot_structure(template, bot_id)
    if not success:
        sys.exit(1)


def handle_list(list_bots_in_bots_folder: Callable[[], List[str]]) -> None:
    bots = list_bots_in_bots_folder()
    if not bots:
        click.echo("🤖 Нет доступных ботов")
        return
    click.echo("🤖 Доступные боты:")
    for bot in sorted(bots):
        click.echo(f"  📱 {bot}")


def handle_config(bot_id: str, root: Path, open_in_editor: Callable[[Path], None]) -> None:
    try:
        bot_path = root / Path("bots") / bot_id
        if not bot_path.exists():
            raise click.ClickException(f"Бот {bot_id} не найден в папке bots/")
        env_file = bot_path / ".env"
        if not env_file.exists():
            raise click.ClickException(f"Файл .env не найден для бота {bot_id}")
        click.echo(f"⚙️ Открываем конфигурацию бота {bot_id}...")
        open_in_editor(env_file)
    except subprocess.CalledProcessError as e:
        click.echo(f"❌ Ошибка при открытии редактора: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Ошибка: {e}", err=True)
        sys.exit(1)


def handle_prompts(
    bot_id: str,
    root: Path,
    open_in_editor: Callable[[Path], None],
    list_prompts: bool,
    edit_prompt: Optional[str],
    add_prompt: Optional[str],
) -> None:
    try:
        bot_path = root / Path("bots") / bot_id
        if not bot_path.exists():
            raise click.ClickException(f"Бот {bot_id} не найден в папке bots/")
        prompts_dir = bot_path / "prompts"
        if not prompts_dir.exists():
            raise click.ClickException(f"Папка промптов не найдена для бота {bot_id}")

        if list_prompts or (not edit_prompt and not add_prompt):
            prompt_files = [f.name for f in prompts_dir.glob("*.txt")]
            if not prompt_files:
                click.echo("📝 Промпты не найдены")
                return
            click.echo(f"📝 Промпты бота {bot_id}:")
            for prompt_file in sorted(prompt_files):
                click.echo(f"  📄 {prompt_file[:-4]}")
            if not list_prompts:
                click.echo()
                click.echo("Использование:")
                click.echo("  sbf prompts <bot_id> --edit <prompt_name>      # Редактировать промпт")
                click.echo("  sbf prompts <bot_id> --add <prompt_name>       # Добавить новый промпт")
        elif edit_prompt:
            prompt_file = prompts_dir / f"{edit_prompt}.txt"
            if not prompt_file.exists():
                raise click.ClickException(f"Промпт {edit_prompt} не найден")
            click.echo(f"✏️ Редактируем промпт {edit_prompt}...")
            open_in_editor(prompt_file)
        elif add_prompt:
            prompt_file = prompts_dir / f"{add_prompt}.txt"
            if prompt_file.exists():
                raise click.ClickException(f"Промпт {add_prompt} уже существует")
            prompt_file.write_text(
                f"# Промпт: {add_prompt}\n\nВведите содержимое промпта здесь...",
                encoding="utf-8",
            )
            click.echo(f"📝 Создаем новый промпт {add_prompt}...")
            open_in_editor(prompt_file)
    except subprocess.CalledProcessError as e:
        click.echo(f"❌ Ошибка при открытии редактора: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Ошибка: {e}", err=True)
        sys.exit(1)


def handle_path(root: Path) -> None:
    click.echo(root)


def handle_rm(bot_id: str, root: Path, force: bool) -> None:
    try:
        bot_path = root / Path("bots") / bot_id
        if not bot_path.exists():
            raise click.ClickException(f"🤖 Бот {bot_id} не найден в папке bots/")
        bot_file = root / Path(f"{bot_id}.py")
        if not bot_file.exists():
            raise click.ClickException(f"📄 Файл {bot_id}.py не найден в корневой директории")
        click.echo("🗑️ Будет удалено:")
        click.echo(f"  📄 Файл запускалки: {bot_file}")
        click.echo(f"  📁 Папка бота: {bot_path}")
        if not force and not click.confirm(f"⚠️ Вы уверены, что хотите удалить бота {bot_id}?"):
            click.echo("❌ Удаление отменено")
            return
        if bot_file.exists():
            bot_file.unlink()
            click.echo(f"✅ Файл {bot_file} удален")
        if bot_path.exists():
            shutil.rmtree(bot_path)
            click.echo(f"✅ Папка {bot_path} удалена")
        click.echo(f"🎉 Бот {bot_id} полностью удален")
    except Exception as e:
        click.echo(f"❌ Ошибка при удалении бота: {e}", err=True)
        sys.exit(1)


def handle_copy(
    source_bot_id: str,
    new_bot_id: str,
    root: Path,
    copy_bot_template: Callable[[str, str], None],
    force: bool,
) -> None:
    try:
        source_bot_path = root / "bots" / source_bot_id
        if not source_bot_path.exists():
            raise click.ClickException(f"Исходный бот {source_bot_id} не найден в папке bots/")
        source_bot_file = root / f"{source_bot_id}.py"
        if not source_bot_file.exists():
            raise click.ClickException(f"Файл запускалки {source_bot_id}.py не найден в корневой директории")
        new_bot_path = root / "bots" / new_bot_id
        new_bot_file = root / f"{new_bot_id}.py"
        if (new_bot_path.exists() or new_bot_file.exists()) and not force:
            if not click.confirm(f"Бот {new_bot_id} уже существует. Перезаписать?"):
                click.echo("Копирование отменено")
                return
        elif new_bot_path.exists() or new_bot_file.exists():
            click.echo(f"⚠️ Перезаписываем существующего бота {new_bot_id}")
        click.echo(f"📋 Копируем бота {source_bot_id} → {new_bot_id}...")
        copy_bot_template(source_bot_id, new_bot_id)
        click.echo(f"✅ Бот {new_bot_id} успешно скопирован из {source_bot_id}")
        click.echo("📝 Не забудьте настроить .env файл для нового бота")
    except Exception as e:
        click.echo(f"❌ Ошибка при копировании бота: {e}", err=True)
        sys.exit(1)


def handle_link() -> None:
    try:
        link_script = Path(__file__).parent.parent / "utm_link_generator.py"
        if not link_script.exists():
            raise click.ClickException("Скрипт utm_link_generator.py не найден")
        click.echo("🔗 Запускаем генератор UTM-ссылок...")
        subprocess.run([sys.executable, str(link_script)], check=True)
    except subprocess.CalledProcessError as e:
        click.echo(f"❌ Ошибка при запуске генератора ссылок: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Ошибка: {e}", err=True)
        sys.exit(1)
