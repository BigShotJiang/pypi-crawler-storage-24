"""Main CLI entrypoint implementation."""

from __future__ import annotations

from typing import Optional

import click
from project_root_finder import root

from .commands_heavy import handle_doctor, handle_run, handle_test
from .commands_light import (
    handle_config,
    handle_copy,
    handle_create,
    handle_link,
    handle_list,
    handle_path,
    handle_prompts,
    handle_rm,
)
from .services import (
    add_project_root_to_syspath,
    ensure_bot_exists,
    ensure_bot_file_exists,
    ensure_env_file,
    find_builder_by_attrs,
    load_bot_module,
    load_env_file,
    open_in_editor,
    resolve_bot_id_and_file,
    set_runtime_env,
)
from .templates import copy_bot_template, create_new_bot_structure, list_bots_in_bots_folder


@click.group()
def cli():
    """Smart Bot Factory - инструмент для создания умных чат-ботов"""
    pass


@cli.command()
@click.argument("bot_id")
@click.argument("template", required=False, default="base")
def create(bot_id: str, template: str = "base"):
    """Создать нового бота"""
    handle_create(bot_id, template, create_new_bot_structure)


@cli.command()
def list():
    """Показать список доступных ботов"""
    handle_list(list_bots_in_bots_folder)


@cli.command()
@click.argument("bot_id_or_file")
def run(bot_id_or_file: str):
    """Запустить бота (можно указать bot_id или имя файла запускалки, например mdclinica.py)"""
    handle_run(
        bot_id_or_file,
        root,
        resolve_bot_id_and_file=resolve_bot_id_and_file,
        ensure_bot_exists=ensure_bot_exists,
        ensure_env_file=ensure_env_file,
        add_project_root_to_syspath=add_project_root_to_syspath,
        load_env_file=load_env_file,
        set_runtime_env=set_runtime_env,
        load_bot_module=load_bot_module,
        find_builder_by_attrs=find_builder_by_attrs,
    )


@cli.command()
@click.argument("bot_id")
@click.option("--file", help="Запустить тесты только из указанного файла")
@click.option("-v", "--verbose", is_flag=True, help="Подробный вывод")
@click.option("--max-concurrent", default=5, help="Максимальное количество потоков")
def test(bot_id: str, file: Optional[str] = None, verbose: bool = False, max_concurrent: int = 5):
    """Запустить тесты бота через BotBuilder"""
    handle_test(
        bot_id,
        root,
        ensure_bot_file_exists=ensure_bot_file_exists,
        add_project_root_to_syspath=add_project_root_to_syspath,
        load_env_file=load_env_file,
        set_runtime_env=set_runtime_env,
        load_bot_module=load_bot_module,
        find_builder_by_attrs=find_builder_by_attrs,
        file=file,
        verbose=verbose,
        max_concurrent=max_concurrent,
    )


@cli.command()
@click.argument("bot_id")
def config(bot_id: str):
    """Настроить конфигурацию бота"""
    handle_config(bot_id, root, open_in_editor)


@cli.command()
@click.argument("bot_id")
def doctor(bot_id: str) -> None:
    """Диагностика окружения и интеграций бота"""
    handle_doctor(
        bot_id,
        root,
        load_env_file=load_env_file,
        set_runtime_env=set_runtime_env,
        add_project_root_to_syspath=add_project_root_to_syspath,
    )


@cli.command()
@click.argument("bot_id")
@click.option("--list", "list_prompts", is_flag=True, help="Показать список промптов")
@click.option("--edit", "edit_prompt", help="Редактировать промпт")
@click.option("--add", "add_prompt", help="Добавить новый промпт")
def prompts(
    bot_id: str,
    list_prompts: bool = False,
    edit_prompt: Optional[str] = None,
    add_prompt: Optional[str] = None,
):
    """Управление промптами бота"""
    handle_prompts(bot_id, root, open_in_editor, list_prompts, edit_prompt, add_prompt)


@cli.command()
def path():
    """Показать путь к проекту"""
    handle_path(root)


@cli.command()
@click.argument("bot_id")
@click.option("--force", "-f", is_flag=True, help="Удалить без подтверждения")
def rm(bot_id: str, force: bool = False):
    """Удалить бота и все его файлы"""
    handle_rm(bot_id, root, force)


@cli.command()
@click.argument("source_bot_id")
@click.argument("new_bot_id")
@click.option("--force", "-f", is_flag=True, help="Перезаписать существующего бота без подтверждения")
def copy(source_bot_id: str, new_bot_id: str, force: bool = False):
    """Скопировать существующего бота как шаблон"""
    handle_copy(source_bot_id, new_bot_id, root, copy_bot_template, force)


@cli.command()
def link():
    """Создать UTM-ссылку для бота"""
    handle_link()


if __name__ == "__main__":
    cli()
