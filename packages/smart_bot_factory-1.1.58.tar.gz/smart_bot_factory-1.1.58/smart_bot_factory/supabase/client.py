"""
Supabase клиент с автоматической загрузкой настроек из .env файла.

Thin subclass of the main SupabaseClient that auto-discovers
SUPABASE_URL and SUPABASE_KEY from ``bots/{bot_id}/.env``
and initialises the underlying connection synchronously.
"""

import logging
import os
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from project_root_finder import root

from ..integrations.supabase_client import SupabaseClient as _BaseSupabaseClient

logger = logging.getLogger(__name__)


class SupabaseClient(_BaseSupabaseClient):
    """SupabaseClient with automatic .env config loading.

    Usage::

        client = SupabaseClient("my-bot-id")
        # ready to use — no await initialize() needed
    """

    def __init__(self, bot_id: str):
        env_path = self._find_env_file(bot_id)
        if not env_path or not env_path.exists():
            raise FileNotFoundError(f".env файл не найден для бота {bot_id}: {env_path}")

        load_dotenv(env_path)

        url = os.getenv("SUPABASE_URL")
        key = os.getenv("SUPABASE_KEY")

        missing = [v for v, val in [("SUPABASE_URL", url), ("SUPABASE_KEY", key)] if not val]
        if missing:
            raise ValueError(f"Отсутствуют обязательные переменные в .env: {', '.join(missing)}")

        super().__init__(url=url, key=key, bot_id=bot_id)

        from supabase import create_client

        self.client = create_client(self.url, self.key)
        logger.info(f"SupabaseClient инициализирован для bot_id: {self.bot_id} (из {env_path})")

    @staticmethod
    def _find_env_file(bot_id: str) -> Optional[Path]:
        """Locate the .env file for the given bot."""
        bot_env_path = root / "bots" / bot_id / ".env"
        if bot_env_path.exists():
            return bot_env_path
        logger.error(f".env файл не найден для бота {bot_id}, искали в: {bot_env_path}")
        return None
