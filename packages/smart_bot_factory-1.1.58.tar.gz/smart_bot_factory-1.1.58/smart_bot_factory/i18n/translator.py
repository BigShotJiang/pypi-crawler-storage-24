import json
from functools import lru_cache
from importlib import resources
from typing import Literal, Mapping

from ..error_handling.exceptions import SmartBotFactoryError

Language = Literal["ru", "lt"]


class TranslationMissingError(SmartBotFactoryError):
    def __init__(self, key: str, lang: str):
        self.key = key
        self.lang = lang
        super().__init__(
            message="Missing translation",
            error_code="TRANSLATION_MISSING",
            key=key,
            lang=lang,
        )


@lru_cache(maxsize=8)
def _load_locale(lang: Language) -> Mapping[str, str]:
    try:
        locale_path = resources.files(__package__) / "locales" / f"{lang}.json"
        raw = locale_path.read_text(encoding="utf-8")
    except Exception as e:
        raise SmartBotFactoryError(
            message="Locale file cannot be loaded",
            error_code="LOCALE_LOAD_FAILED",
            lang=lang,
            reason=str(e),
        ) from e

    try:
        data = json.loads(raw)
    except Exception as e:
        raise SmartBotFactoryError(
            message="Locale file is not valid JSON",
            error_code="LOCALE_JSON_INVALID",
            lang=lang,
            reason=str(e),
        ) from e

    if not isinstance(data, dict):
        raise SmartBotFactoryError(
            message="Locale JSON must be an object",
            error_code="LOCALE_JSON_NOT_OBJECT",
            lang=lang,
            actual_type=type(data).__name__,
        )

    invalid = [k for k, v in data.items() if not isinstance(k, str) or not isinstance(v, str)]
    if invalid:
        raise SmartBotFactoryError(
            message="Locale JSON must be a mapping of string to string",
            error_code="LOCALE_JSON_INVALID_SHAPE",
            lang=lang,
            invalid_keys=invalid,
        )

    return data


def translate(key: str, *, lang: Language) -> str:
    locale = _load_locale(lang)
    value = locale.get(key)
    if value is None:
        raise TranslationMissingError(key=key, lang=lang)
    return value
