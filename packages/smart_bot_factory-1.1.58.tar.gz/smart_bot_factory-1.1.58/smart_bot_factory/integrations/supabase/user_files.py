"""User files/directories repository (sales_users.files, sales_users.directories)."""

import logging
from typing import Any, List

from supabase import Client

from ...error_handling import SupabaseError

logger = logging.getLogger(__name__)


class UserFilesRepo:
    def __init__(self, client: Client, bot_id: Any) -> None:
        self._client = client
        self._bot_id = bot_id

    def _with_bot_id(self, query: Any) -> Any:
        if self._bot_id:
            return query.eq("bot_id", self._bot_id)
        return query

    async def get_sent_files(self, user_id: int) -> List[str]:
        try:
            query = self._client.table("sales_users").select("files").eq("telegram_id", user_id)
            query = self._with_bot_id(query)
            response = query.execute()
            if response.data and response.data[0].get("files"):
                files_str = response.data[0]["files"]
                return [f.strip() for f in files_str.split(",") if f.strip()]
            return []
        except Exception as e:
            logger.error("Error getting sent files for user %s", user_id, exc_info=True)
            raise SupabaseError(f"Failed to get sent files: {e}", user_id=user_id)

    async def get_sent_directories(self, user_id: int) -> List[str]:
        try:
            query = self._client.table("sales_users").select("directories").eq("telegram_id", user_id)
            query = self._with_bot_id(query)
            response = query.execute()
            if response.data and response.data[0].get("directories"):
                dirs_str = response.data[0]["directories"]
                return [d.strip() for d in dirs_str.split(",") if d.strip()]
            return []
        except Exception as e:
            logger.error("Error getting sent directories for user %s", user_id, exc_info=True)
            raise SupabaseError(f"Failed to get sent directories: {e}", user_id=user_id)

    async def add_sent_files(self, user_id: int, files_list: List[str]) -> None:
        try:
            logger.info("Saving files for user %s: %s", user_id, files_list)
            files_str = ", ".join(files_list)
            query = self._client.table("sales_users").update({"files": files_str}).eq("telegram_id", user_id)
            query = self._with_bot_id(query)
            query.execute()
            logger.info("Saved %s files for user %s", len(files_list), user_id)
        except Exception as e:
            logger.error("Error saving sent files for user %s: %s", user_id, e)
            raise

    async def add_sent_directories(self, user_id: int, dirs_list: List[str]) -> None:
        try:
            logger.info("Saving directories for user %s: %s", user_id, dirs_list)
            dirs_str = ", ".join(dirs_list)
            query = self._client.table("sales_users").update({"directories": dirs_str}).eq("telegram_id", user_id)
            query = self._with_bot_id(query)
            query.execute()
            logger.info("Saved %s directories for user %s", len(dirs_list), user_id)
        except Exception as e:
            logger.error("Error saving sent directories for user %s: %s", user_id, e)
            raise
