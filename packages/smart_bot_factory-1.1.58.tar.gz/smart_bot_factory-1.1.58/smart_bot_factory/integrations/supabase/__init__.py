# Supabase repositories and batch metrics. Public API remains in integrations.supabase_client.
