"""Batch operation metrics for Supabase client."""

import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)


class BatchMetrics:
    """Metrics for SupabaseClient batch operations."""

    def __init__(self) -> None:
        self.batch_calls: int = 0
        self.single_calls: int = 0
        self.total_time_saved_ms: float = 0.0

    def record_batch(self, items_count: int, estimated_time_saved_ms: float) -> None:
        self.batch_calls += 1
        self.total_time_saved_ms += max(0.0, float(estimated_time_saved_ms))

    def record_single(self) -> None:
        self.single_calls += 1

    def get_stats(self) -> Dict[str, Any]:
        total_calls = self.batch_calls + self.single_calls
        batch_usage_percent = (self.batch_calls / total_calls * 100.0) if total_calls else 0.0

        return {
            "batch_calls": self.batch_calls,
            "single_calls": self.single_calls,
            "batch_usage_percent": round(batch_usage_percent, 1),
            "total_time_saved_ms": int(self.total_time_saved_ms),
        }


_batch_metrics = BatchMetrics()


def get_batch_metrics() -> Dict[str, Any]:
    """Return current batch operation metrics."""
    return _batch_metrics.get_stats()


def get_metrics_instance() -> BatchMetrics:
    """Return the singleton BatchMetrics instance (for repos that record)."""
    return _batch_metrics
