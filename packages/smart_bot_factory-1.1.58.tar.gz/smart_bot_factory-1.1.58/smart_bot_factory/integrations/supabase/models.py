from __future__ import annotations

from typing import Any, Dict, Optional

from pydantic import BaseModel, ConfigDict


class SupabaseRecord(BaseModel):
    model_config = ConfigDict(extra="allow")


class UserRecord(SupabaseRecord):
    telegram_id: int
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    language_code: Optional[str] = None
    is_active: Optional[bool] = None
    source: Optional[str] = None
    medium: Optional[str] = None
    campaign: Optional[str] = None
    content: Optional[str] = None
    term: Optional[str] = None
    segments: Optional[str] = None
    bot_id: Optional[str] = None


class SessionRecord(SupabaseRecord):
    id: str
    user_id: Optional[int] = None
    bot_id: Optional[str] = None
    system_prompt: Optional[str] = None
    status: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    current_stage: Optional[str] = None
    lead_quality_score: Optional[int] = None
    summary: Optional[str] = None
    messages_len: Optional[int] = None
    service_info: Optional[Dict[str, Any]] = None


class MessageRecord(SupabaseRecord):
    id: Optional[int] = None
    session_id: Optional[str] = None
    role: Optional[str] = None
    content: Optional[str] = None
    message_type: Optional[str] = None
    created_at: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    ai_metadata: Optional[Dict[str, Any]] = None
    message_id: Optional[int] = None
    tokens_used: Optional[int] = None
    processing_time_ms: Optional[int] = None


class EventRecord(SupabaseRecord):
    id: Optional[str] = None
    session_id: Optional[str] = None
    event_type: Optional[str] = None
    event_info: Optional[str] = None
    created_at: Optional[str] = None
    bot_id: Optional[str] = None
