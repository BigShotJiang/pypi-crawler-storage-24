"""Admin events repository (scheduled_events, event_category=admin_event)."""

import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from supabase import Client

from ...error_handling import SupabaseError

logger = logging.getLogger(__name__)


class AdminEventsRepo:
    def __init__(self, client: Client, bot_id: Optional[str]) -> None:
        self._client = client
        self._bot_id = bot_id

    def _with_bot_id(self, query: Any) -> Any:
        if self._bot_id:
            return query.eq("bot_id", self._bot_id)
        return query

    async def save_admin_event(
        self,
        event_name: str,
        event_data: Dict[str, Any],
        scheduled_datetime: datetime,
    ) -> Dict[str, Any]:
        try:
            if scheduled_datetime.tzinfo is None:
                logger.warning("scheduled_datetime has no timezone, assuming UTC")
                scheduled_datetime = scheduled_datetime.replace(tzinfo=timezone.utc)

            event_record: Dict[str, Any] = {
                "event_type": event_name,
                "event_category": "admin_event",
                "user_id": None,
                "event_data": json.dumps(event_data, ensure_ascii=False),
                "scheduled_at": scheduled_datetime.isoformat(),
                "status": "pending",
            }
            if self._bot_id:
                event_record["bot_id"] = self._bot_id
                logger.info("Added bot_id %s for admin event", self._bot_id)

            response = self._client.table("scheduled_events").insert(event_record).execute()
            event = response.data[0]
            logger.info("Admin event %r saved: %s at %s", event_name, event["id"], scheduled_datetime.isoformat())
            return event
        except Exception as e:
            logger.error("Error saving admin event: %s", e)
            raise

    async def get_admin_events(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        try:
            query = self._client.table("scheduled_events").select("*").eq("event_category", "admin_event")
            if status:
                query = query.eq("status", status)
            query = self._with_bot_id(query)
            response = query.order("scheduled_at", desc=False).execute()
            logger.info("Found %s admin events", len(response.data or []))
            return response.data or []
        except Exception as e:
            logger.error(
                "Error getting admin events",
                extra={"status": status, "bot_id": self._bot_id},
                exc_info=True,
            )
            raise SupabaseError(f"Failed to get admin events: {e}", status=status, bot_id=self._bot_id)

    async def check_event_name_exists(self, event_name: str) -> bool:
        try:
            query = (
                self._client.table("scheduled_events")
                .select("id", "event_type", "status")
                .eq("event_category", "admin_event")
                .eq("event_type", event_name)
                .in_("status", ["pending", "immediate", "completed", "failed"])
            )
            query = self._with_bot_id(query)
            response = query.execute()
            exists = len(response.data or []) > 0
            if exists:
                logger.info("Event with name %r already exists (not cancelled/removed)", event_name)
            return exists
        except Exception as e:
            logger.error(
                "Error checking admin event name",
                extra={"event_name": event_name, "bot_id": self._bot_id},
                exc_info=True,
            )
            raise SupabaseError(
                f"Failed to check admin event name exists: {e}",
                event_name=event_name,
                bot_id=self._bot_id,
            )
