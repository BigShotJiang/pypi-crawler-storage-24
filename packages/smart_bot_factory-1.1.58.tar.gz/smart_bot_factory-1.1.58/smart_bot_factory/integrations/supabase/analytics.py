"""Analytics repository (sales_session_analytics, funnel stats)."""

import logging
from datetime import datetime, timedelta
from typing import Any, Dict, Optional

from postgrest.exceptions import APIError
from supabase import Client

logger = logging.getLogger(__name__)


class AnalyticsRepo:
    def __init__(self, client: Client, bot_id: Optional[str]) -> None:
        self._client = client
        self._bot_id = bot_id

    def _with_bot_id(self, query: Any) -> Any:
        if self._bot_id:
            return query.eq("bot_id", self._bot_id)
        return query

    async def create_session_analytics(self, session_id: str) -> None:
        try:
            self._client.table("sales_session_analytics").insert(
                {
                    "session_id": session_id,
                    "total_messages": 0,
                    "total_tokens": 0,
                    "average_response_time_ms": 0,
                    "conversion_stage": "initial",
                    "lead_quality_score": 5,
                }
            ).execute()
            logger.debug("Created analytics for session %s", session_id)
        except APIError as e:
            logger.error("Error creating analytics: %s", e)
            raise

    async def get_analytics_summary(self, days: int = 7) -> Dict[str, Any]:
        try:
            cutoff_date = datetime.now() - timedelta(days=days)
            query = (
                self._client.table("sales_chat_sessions")
                .select("id", "current_stage", "lead_quality_score", "created_at")
                .gte("created_at", cutoff_date.isoformat())
            )
            query = self._with_bot_id(query)
            sessions_response = query.execute()
            sessions = sessions_response.data or []
            total_sessions = len(sessions)
            stages: Dict[str, int] = {}
            quality_scores: list[float] = []
            for session in sessions:
                stage = session.get("current_stage", "unknown")
                stages[stage] = stages.get(stage, 0) + 1
                score = session.get("lead_quality_score", 5)
                if score:
                    quality_scores.append(score)
            avg_quality = sum(quality_scores) / len(quality_scores) if quality_scores else 5
            return {
                "bot_id": self._bot_id,
                "period_days": days,
                "total_sessions": total_sessions,
                "stages": stages,
                "average_lead_quality": round(avg_quality, 1),
                "generated_at": datetime.now().isoformat(),
            }
        except APIError as e:
            logger.error("Error getting analytics summary: %s", e)
            return {
                "bot_id": self._bot_id,
                "error": str(e),
                "generated_at": datetime.now().isoformat(),
            }

    async def update_session_analytics(
        self,
        session_id: str,
        tokens_used: int = 0,
        processing_time_ms: int = 0,
    ) -> None:
        try:
            response = (
                self._client.table("sales_session_analytics")
                .select("total_messages", "total_tokens", "average_response_time_ms")
                .eq("session_id", session_id)
                .execute()
            )
            if response.data:
                current = response.data[0]
                new_total_messages = current["total_messages"] + 1
                new_total_tokens = current["total_tokens"] + tokens_used
                if processing_time_ms > 0:
                    current_avg = current["average_response_time_ms"]
                    new_avg = ((current_avg * (new_total_messages - 1)) + processing_time_ms) / new_total_messages
                else:
                    new_avg = current["average_response_time_ms"]
                self._client.table("sales_session_analytics").update(
                    {
                        "total_messages": new_total_messages,
                        "total_tokens": new_total_tokens,
                        "average_response_time_ms": int(new_avg),
                        "updated_at": datetime.now().isoformat(),
                    }
                ).eq("session_id", session_id).execute()
        except APIError as e:
            logger.error("Error updating session analytics: %s", e)

    async def update_session_analytics_batch(
        self,
        session_id: str,
        messages_count: int = 1,
        tokens_used: int = 0,
        processing_time_ms: int = 0,
    ) -> None:
        try:
            response = (
                self._client.table("sales_session_analytics")
                .select("total_messages", "total_tokens", "average_response_time_ms")
                .eq("session_id", session_id)
                .execute()
            )
            if response.data:
                current = response.data[0]
                new_total_messages = current["total_messages"] + messages_count
                new_total_tokens = current["total_tokens"] + tokens_used
                if processing_time_ms > 0:
                    current_avg = current["average_response_time_ms"]
                    current_messages = current["total_messages"]
                    new_avg = ((current_avg * current_messages) + processing_time_ms) / new_total_messages
                else:
                    new_avg = current["average_response_time_ms"]
                self._client.table("sales_session_analytics").update(
                    {
                        "total_messages": new_total_messages,
                        "total_tokens": new_total_tokens,
                        "average_response_time_ms": int(new_avg),
                        "updated_at": datetime.now().isoformat(),
                    }
                ).eq("session_id", session_id).execute()
                logger.debug(
                    "Session analytics updated (batch) for %s: +%s messages, +%s tokens",
                    session_id,
                    messages_count,
                    tokens_used,
                )
        except APIError as e:
            logger.error("Error batch-updating session analytics: %s", e)

    async def get_funnel_stats(self, days: int = 7) -> Dict[str, Any]:
        try:
            cutoff_date = datetime.now() - timedelta(days=days)
            users_query = self._client.table("sales_users").select("telegram_id")
            users_query = self._with_bot_id(users_query)
            users_query = users_query.neq("username", "test_user")
            users_response = users_query.execute()
            total_unique_users = len(users_response.data) if users_response.data else 0

            sessions_query = (
                self._client.table("sales_chat_sessions")
                .select("id", "user_id", "current_stage", "lead_quality_score", "created_at")
                .gte("created_at", cutoff_date.isoformat())
            )
            sessions_query = self._with_bot_id(sessions_query)
            sessions_response = sessions_query.execute()
            sessions = sessions_response.data or []

            if sessions:
                test_users_query = self._client.table("sales_users").select("telegram_id").eq("username", "test_user")
                test_users_query = self._with_bot_id(test_users_query)
                test_users_response = test_users_query.execute()
                test_user_ids = {u["telegram_id"] for u in (test_users_response.data or [])}
                sessions = [s for s in sessions if s["user_id"] not in test_user_ids]

            total_sessions = len(sessions)
            stages: Dict[str, int] = {}
            quality_scores: list[float] = []
            for session in sessions:
                stage = session.get("current_stage", "unknown")
                stages[stage] = stages.get(stage, 0) + 1
                score = session.get("lead_quality_score", 5)
                if score:
                    quality_scores.append(score)
            avg_quality = sum(quality_scores) / len(quality_scores) if quality_scores else 5
            return {
                "total_sessions": total_sessions,
                "total_unique_users": total_unique_users,
                "stages": stages,
                "avg_quality": round(avg_quality, 1),
                "period_days": days,
            }
        except APIError as e:
            logger.error("Error getting funnel stats: %s", e)
            return {
                "total_sessions": 0,
                "total_unique_users": 0,
                "stages": {},
                "avg_quality": 0,
                "period_days": days,
            }
