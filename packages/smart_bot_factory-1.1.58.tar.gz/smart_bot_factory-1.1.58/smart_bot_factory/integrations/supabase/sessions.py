"""Sessions repository (sales_chat_sessions)."""

import json
import logging
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from postgrest.exceptions import APIError
from supabase import Client

from ...error_handling import SUPABASE_RETRY_STRATEGY, SupabaseError, with_retry
from ...utils.performance import measure_time
from ._batch_metrics import get_metrics_instance
from .models import SessionRecord

logger = logging.getLogger(__name__)


class SessionsRepo:
    def __init__(self, client: Client, bot_id: Optional[str]) -> None:
        self._client = client
        self._bot_id = bot_id

    def _with_bot_id(self, query: Any) -> Any:
        if self._bot_id:
            return query.eq("bot_id", self._bot_id)
        return query

    async def close_active_sessions(self, user_id: int) -> None:
        try:
            query = (
                self._client.table("sales_chat_sessions")
                .update({"status": "completed", "updated_at": datetime.now().isoformat()})
                .eq("user_id", user_id)
                .eq("status", "active")
            )
            query = self._with_bot_id(query)
            query.execute()
            logger.info("Closed active sessions for user %s", user_id)
        except APIError as e:
            logger.error("Error closing sessions: %s", e)
            raise

    async def get_active_session(self, telegram_id: int) -> Optional[SessionRecord]:
        try:
            query = (
                self._client.table("sales_chat_sessions")
                .select("id", "user_id", "system_prompt", "created_at", "current_stage", "lead_quality_score")
                .eq("user_id", telegram_id)
                .eq("status", "active")
            )
            query = self._with_bot_id(query)
            response = query.execute()
            if response.data:
                logger.info("Found active session %s for user %s", response.data[0]["id"], telegram_id)
                return SessionRecord.model_validate(response.data[0])
            return None
        except APIError as e:
            logger.error("Error getting active session: %s", e)
            return None

    async def create_session(self, session_data: Dict[str, Any]) -> str:
        """Insert session and return session id."""
        response = self._client.table("sales_chat_sessions").insert(session_data).execute()
        return response.data[0]["id"]

    @measure_time(custom_name="Supabase:get_session_info")
    async def get_session_info(self, session_id: str) -> Optional[SessionRecord]:
        try:
            response = (
                self._client.table("sales_chat_sessions")
                .select(
                    "id",
                    "user_id",
                    "bot_id",
                    "system_prompt",
                    "status",
                    "created_at",
                    "metadata",
                    "current_stage",
                    "lead_quality_score",
                    "summary",
                    "messages_len",
                )
                .eq("id", session_id)
                .execute()
            )
            if response.data:
                session = SessionRecord.model_validate(response.data[0])
                if self._bot_id and session.bot_id != self._bot_id:
                    logger.warning("Access to session %s of another bot", session_id)
                    return None
                return session
            return None
        except APIError as e:
            logger.error("Error getting session info: %s", e)
            raise

    async def get_session_service_info(self, session_id: str) -> Optional[Dict[str, Any]]:
        try:
            response = self._client.table("sales_chat_sessions").select("service_info", "bot_id").eq("id", session_id).execute()
            if not response.data:
                logger.debug("Session %s not found", session_id)
                return None
            session = response.data[0]
            if self._bot_id and session.get("bot_id") != self._bot_id:
                logger.warning("Access to session %s of another bot", session_id)
                return None
            service_info = session.get("service_info")
            if service_info is None:
                logger.debug("service_info missing for session %s", session_id)
                return None
            if isinstance(service_info, str):
                try:
                    service_info = json.loads(service_info)
                except json.JSONDecodeError as e:
                    logger.warning("Failed to parse service_info JSON for session %s: %s", session_id, e)
                    return None
            if isinstance(service_info, dict) and service_info:
                logger.debug("Got service_info for session %s", session_id)
                return service_info
            logger.debug("service_info empty or not dict for session %s", session_id)
            return None
        except APIError as e:
            logger.error("Error getting service_info for session %s: %s", session_id, e)
            raise
        except Exception as e:
            logger.error(
                "Unexpected error getting service_info for session %s",
                session_id,
                exc_info=True,
            )
            raise SupabaseError(f"Unexpected error getting service_info: {e}", session_id=session_id)

    async def update_session_service_info(self, session_id: str, service_info: Dict[str, Any]) -> bool:
        try:
            if not isinstance(service_info, dict):
                logger.error("service_info must be dict, got %s", type(service_info))
                return False
            query = (
                self._client.table("sales_chat_sessions")
                .update({"service_info": service_info, "updated_at": datetime.now().isoformat()})
                .eq("id", session_id)
            )
            query = self._with_bot_id(query)
            response = query.execute()
            if response.data:
                logger.info("Updated service_info for session %s (%s keys)", session_id, len(service_info))
                return True
            logger.warning("Could not update service_info for session %s", session_id)
            return False
        except APIError as e:
            logger.error("Error updating service_info for session %s: %s", session_id, e)
            raise
        except Exception as e:
            logger.error("Unexpected error updating service_info for session %s: %s", session_id, e)
            return False

    async def update_session_all(
        self,
        session_id: str,
        stage: Optional[str] = None,
        quality_score: Optional[int] = None,
        service_info: Optional[Dict[str, Any]] = None,
    ) -> bool:
        try:
            update_data: Dict[str, Any] = {"updated_at": datetime.now().isoformat()}
            if stage:
                update_data["current_stage"] = stage
            if quality_score is not None:
                update_data["lead_quality_score"] = quality_score
            if service_info:
                if not isinstance(service_info, dict):
                    logger.error("service_info must be dict, got %s", type(service_info))
                    return False
                update_data["service_info"] = service_info
            if len(update_data) == 1:
                return False
            query = self._client.table("sales_chat_sessions").update(update_data).eq("id", session_id)
            query = self._with_bot_id(query)
            response = query.execute()
            if response.data:
                logger.info("Updated session %s", session_id)
                return True
            logger.warning("Could not update session %s", session_id)
            return False
        except APIError as e:
            logger.error("Error updating session %s: %s", session_id, e)
            raise
        except Exception as e:
            logger.error("Unexpected error updating session %s: %s", session_id, e)
            return False

    @with_retry(SUPABASE_RETRY_STRATEGY)
    @measure_time(min_ms=50, custom_name="Supabase:update_session")
    async def update_session(self, session_id: str, updates: Dict[str, Any]) -> Optional[SessionRecord]:
        if not updates:
            logger.warning("Empty update for session %s skipped", session_id)
            return None
        try:
            payload = updates.copy()
            query = self._client.table("sales_chat_sessions").update(payload).eq("id", session_id)
            query = self._with_bot_id(query)
            response = query.execute()
            if not response.data:
                logger.warning("Could not update session %s", session_id)
                return None
            return SessionRecord.model_validate(response.data[0])
        except APIError as e:
            logger.error("Error updating session %s: %s", session_id, e)
            raise SupabaseError(f"Failed to update session: {e}", session_id=session_id)

    async def update_session_stage(
        self,
        session_id: str,
        stage: Optional[str] = None,
        quality_score: Optional[int] = None,
    ) -> None:
        try:
            update_data: Dict[str, Any] = {"updated_at": datetime.now().isoformat()}
            if stage:
                update_data["current_stage"] = stage
            if quality_score is not None:
                update_data["lead_quality_score"] = quality_score
            query = self._client.table("sales_chat_sessions").update(update_data).eq("id", session_id)
            query = self._with_bot_id(query)
            query.execute()
            logger.debug("Updated session stage %s: stage=%s, quality=%s", session_id, stage, quality_score)
        except APIError as e:
            logger.error("Error updating session stage: %s", e)
            raise

    async def get_user_sessions(self, telegram_id: int) -> List[Dict[str, Any]]:
        try:
            query = (
                self._client.table("sales_chat_sessions")
                .select("id", "status", "created_at", "updated_at", "current_stage", "lead_quality_score")
                .eq("user_id", telegram_id)
                .order("created_at", desc=True)
            )
            query = self._with_bot_id(query)
            response = query.execute()
            return response.data or []
        except APIError as e:
            logger.error("Error getting user sessions: %s", e)
            raise

    async def add_session_event(self, session_id: str, event_type: str, event_info: str) -> int:
        try:
            response = (
                self._client.table("session_events")
                .insert(
                    {
                        "session_id": session_id,
                        "event_type": event_type,
                        "event_info": event_info,
                        "notified_admins": [],
                    }
                )
                .execute()
            )
            event_id = response.data[0]["id"]
            logger.info("Added event %s for session %s", event_type, session_id)
            return event_id
        except APIError as e:
            logger.error("Error adding session event: %s", e)
            raise

    async def get_sessions_batch(self, session_ids: List[str]) -> Dict[str, Dict[str, Any]]:
        if not session_ids:
            logger.debug("get_sessions_batch called with empty list")
            return {}
        try:
            query = self._client.table("sales_chat_sessions").select("*").in_("id", session_ids)
            query = self._with_bot_id(query)
            response = query.execute()
            sessions = response.data or []
            result: Dict[str, Dict[str, Any]] = {str(row["id"]): row for row in sessions if "id" in row}
            unique_ids_count = len(session_ids)
            if unique_ids_count > 1:
                estimated_saved = max(0, (unique_ids_count - 1) * 30)
                get_metrics_instance().record_batch(unique_ids_count, estimated_saved)
            logger.info("get_sessions_batch: requested %s, found %s", len(session_ids), len(result))
            return result
        except APIError:
            logger.error("Error in sessions batch", extra={"bot_id": self._bot_id}, exc_info=True)
            raise
        except Exception as e:
            logger.error(
                "Unexpected error in get_sessions_batch",
                extra={"bot_id": self._bot_id, "requested_count": len(session_ids)},
                exc_info=True,
            )
            raise SupabaseError(f"Unexpected error in get_sessions_batch: {e}", session_ids=session_ids, bot_id=self._bot_id)

    async def archive_old_sessions(self, days: int = 7) -> None:
        try:
            cutoff_date = datetime.now() - timedelta(days=days)
            query = (
                self._client.table("sales_chat_sessions")
                .update({"status": "archived"})
                .eq("status", "completed")
                .lt("updated_at", cutoff_date.isoformat())
            )
            query = self._with_bot_id(query)
            query.execute()
            logger.info("Archived sessions older than %s days", days)
        except APIError as e:
            logger.error("Error archiving sessions: %s", e)
            raise

    async def get_user_last_message_info(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Get last activity info from user's most recent session (sales_chat_sessions)."""
        try:
            response = (
                self._client.table("sales_chat_sessions")
                .select("id", "current_stage", "created_at", "updated_at")
                .eq("user_id", user_id)
                .order("updated_at", desc=True)
                .limit(1)
                .execute()
            )
            if not response.data:
                return None
            session = response.data[0]
            return {
                "last_message_at": session["updated_at"],
                "session_id": session["id"],
                "current_stage": session["current_stage"],
                "session_updated_at": session["updated_at"],
            }
        except Exception as e:
            logger.error("Unexpected error getting last message info for user %s", user_id, exc_info=True)
            raise SupabaseError(f"Unexpected error getting last message info: {e}", user_id=user_id, bot_id=self._bot_id)
