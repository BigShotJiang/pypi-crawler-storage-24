"""Admin conversations repository (sales_admins, admin_user_conversations)."""

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

from postgrest.exceptions import APIError
from supabase import Client

logger = logging.getLogger(__name__)


class AdminConversationsRepo:
    def __init__(self, client: Client, bot_id: Optional[str]) -> None:
        self._client = client
        self._bot_id = bot_id

    def _with_bot_id(self, query: Any) -> Any:
        if self._bot_id:
            return query.eq("bot_id", self._bot_id)
        return query

    async def sync_admin(self, admin_data: Dict[str, Any]) -> None:
        try:
            response = (
                self._client.table("sales_admins")
                .select("telegram_id")
                .eq("telegram_id", admin_data["telegram_id"])
                .eq("bot_id", self._bot_id)
                .execute()
            )
            if response.data:
                self._client.table("sales_admins").update(
                    {
                        "username": admin_data.get("username"),
                        "first_name": admin_data.get("first_name"),
                        "last_name": admin_data.get("last_name"),
                        "is_active": True,
                    }
                ).eq("telegram_id", admin_data["telegram_id"]).eq("bot_id", self._bot_id).execute()
                logger.debug("Updated admin %s", admin_data["telegram_id"])
            else:
                self._client.table("sales_admins").insert(
                    {
                        "telegram_id": admin_data["telegram_id"],
                        "bot_id": self._bot_id,
                        "username": admin_data.get("username"),
                        "first_name": admin_data.get("first_name"),
                        "last_name": admin_data.get("last_name"),
                        "role": "admin",
                        "is_active": True,
                    }
                ).execute()
                logger.info("Created new admin %s", admin_data["telegram_id"])
        except APIError as e:
            logger.error("Error syncing admin: %s", e)
            raise

    async def start_admin_conversation(self, admin_id: int, user_id: int, session_id: str) -> int:
        try:
            user_query = self._client.table("sales_users").select("telegram_id").eq("telegram_id", user_id)
            user_query = self._with_bot_id(user_query)
            user_response = user_query.execute()
            if not user_response.data:
                logger.error("User %s not found in sales_users", user_id)
                raise APIError("User not found in sales_users")

            await self.end_admin_conversations(admin_id=admin_id)

            conversation_data: Dict[str, Any] = {
                "admin_id": admin_id,
                "user_id": user_id,
                "session_id": session_id,
                "status": "active",
                "auto_end_at": (datetime.now(timezone.utc) + timedelta(minutes=30)).isoformat(),
            }
            if self._bot_id:
                conversation_data["bot_id"] = self._bot_id

            response = self._client.table("admin_user_conversations").insert(conversation_data).execute()
            conversation_id = response.data[0]["id"]
            logger.info("Started conversation %s: admin %s with user %s", conversation_id, admin_id, user_id)
            return conversation_id
        except APIError as e:
            logger.error("Error starting conversation: %s", e)
            raise

    async def end_admin_conversations(
        self,
        admin_id: Optional[int] = None,
        user_id: Optional[int] = None,
    ) -> int:
        try:
            query = (
                self._client.table("admin_user_conversations")
                .update(
                    {
                        "status": "completed",
                        "ended_at": datetime.now(timezone.utc).isoformat(),
                    }
                )
                .eq("status", "active")
            )
            if admin_id is not None:
                query = query.eq("admin_id", admin_id)
            if user_id is not None:
                query = query.eq("user_id", user_id)
            query = self._with_bot_id(query)
            response = query.execute()
            ended_count = len(response.data)
            if ended_count > 0:
                logger.info("Ended %s active conversations", ended_count)
            return ended_count
        except APIError as e:
            logger.error("Error ending conversations: %s", e)
            return 0

    async def get_admin_active_conversation(self, admin_id: int) -> Optional[Dict[str, Any]]:
        try:
            response = (
                self._client.table("admin_user_conversations")
                .select("id", "user_id", "session_id", "started_at", "auto_end_at")
                .eq("admin_id", admin_id)
                .eq("status", "active")
                .execute()
            )
            return response.data[0] if response.data else None
        except APIError as e:
            logger.error("Error getting admin conversation: %s", e)
            return None

    async def get_user_conversation(self, user_id: int) -> Optional[Dict[str, Any]]:
        try:
            query = (
                self._client.table("admin_user_conversations")
                .select("id", "admin_id", "session_id", "started_at", "auto_end_at")
                .eq("user_id", user_id)
                .eq("status", "active")
            )
            query = self._with_bot_id(query)
            response = query.execute()
            return response.data[0] if response.data else None
        except APIError as e:
            logger.error("Error getting user conversation: %s", e)
            return None

    async def cleanup_expired_conversations(self) -> int:
        try:
            now = datetime.now(timezone.utc).isoformat()
            response = (
                self._client.table("admin_user_conversations")
                .update({"status": "expired", "ended_at": now})
                .eq("status", "active")
                .lt("auto_end_at", now)
                .execute()
            )
            ended_count = len(response.data)
            if ended_count > 0:
                logger.info("Auto-ended %s expired conversations", ended_count)
            return ended_count
        except APIError as e:
            logger.error("Error cleaning expired conversations: %s", e)
            return 0

    async def end_expired_conversations(self) -> int:
        return await self.cleanup_expired_conversations()

    async def get_user_admin_conversation(self, user_id: int) -> Optional[Dict[str, Any]]:
        return await self.get_user_conversation(user_id)
