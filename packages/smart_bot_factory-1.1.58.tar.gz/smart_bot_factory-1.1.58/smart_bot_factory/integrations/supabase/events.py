"""Events repositories (scheduled_events, session_events)."""

import logging
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Set

from postgrest.exceptions import APIError
from supabase import Client

from ...error_handling import SupabaseError

logger = logging.getLogger(__name__)


class SessionEventsRepo:
    def __init__(self, client: Client, bot_id: Optional[str]) -> None:
        self._client = client
        self._bot_id = bot_id

    def _with_bot_id(self, query: Any) -> Any:
        if self._bot_id:
            return query.eq("bot_id", self._bot_id)
        return query

    async def batch_check_events_executed(self, event_types: List[str], user_id: int) -> Set[str]:
        if not event_types:
            return set()
        try:
            query = (
                self._client.table("scheduled_events")
                .select("event_type")
                .in_("event_type", event_types)
                .eq("user_id", user_id)
                .eq("status", "completed")
            )
            query = self._with_bot_id(query)
            response = query.execute()
            executed = {e["event_type"] for e in (response.data or [])}
            logger.debug("Batch check: %s types, %s already executed", len(event_types), len(executed))
            return executed
        except APIError as e:
            logger.error("Error batch-checking events: %s", e)
            return set()

    async def batch_insert_events(self, events: List[Dict[str, Any]]) -> List[str]:
        if not events:
            return []
        try:
            response = self._client.table("scheduled_events").insert(events).execute()
            event_ids = [e["id"] for e in response.data] if response.data else []
            logger.debug("Batch insert: %s events inserted", len(event_ids))
            return event_ids
        except APIError as e:
            logger.error("Error batch-inserting events: %s", e)
            logger.warning("Trying to insert one by one...")
            event_ids = []
            for event in events:
                try:
                    response = self._client.table("scheduled_events").insert(event).execute()
                    if response.data:
                        event_ids.append(response.data[0]["id"])
                except Exception as single_error:
                    logger.error("Failed to insert event %s: %s", event.get("event_type", "unknown"), single_error)
            return event_ids

    async def get_session_processed_events(self, session_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        try:
            query = (
                self._client.table("scheduled_events")
                .select("event_type, event_data, executed_at, created_at")
                .eq("session_id", session_id)
                .eq("status", "completed")
            )
            query = self._with_bot_id(query)
            response = query.order("executed_at", desc=True).limit(limit).execute()
            events = [
                {
                    "event_type": e.get("event_type", ""),
                    "event_data": e.get("event_data", ""),
                    "executed_at": e.get("executed_at") or e.get("created_at"),
                }
                for e in response.data or []
            ]
            logger.debug("Got %s processed events for session %s", len(events), session_id)
            return events
        except APIError as e:
            logger.error("Error getting events for session %s: %s", session_id, e)
            raise
        except Exception as e:
            logger.error("Unexpected error getting events for session %s", session_id, exc_info=True)
            raise SupabaseError(f"Unexpected error getting processed events: {e}", session_id=session_id, bot_id=self._bot_id)

    async def get_events_stats(self, days: int = 7) -> Dict[str, int]:
        try:
            cutoff_date = datetime.now() - timedelta(days=days)
            event_counts: Dict[str, int] = {}

            query = self._client.table("session_events").select("event_type", "session_id").gte("created_at", cutoff_date.isoformat())
            events_response = query.execute()
            events = events_response.data or []

            if self._bot_id and events:
                sessions_query = self._client.table("sales_chat_sessions").select("id", "user_id").eq("bot_id", self._bot_id)
                sessions_response = sessions_query.execute()
                if sessions_response.data:
                    test_users_query = self._client.table("sales_users").select("telegram_id").eq("username", "test_user")
                    test_users_query = self._with_bot_id(test_users_query)
                    test_users_response = test_users_query.execute()
                    test_user_ids = {u["telegram_id"] for u in (test_users_response.data or [])}
                    bot_sessions = [s for s in sessions_response.data if s["user_id"] not in test_user_ids]
                    bot_session_ids = {s["id"] for s in bot_sessions}
                else:
                    bot_session_ids = set()
                events = [e for e in events if e["session_id"] in bot_session_ids]

            for event in events:
                event_type = event.get("event_type", "unknown")
                event_counts[event_type] = event_counts.get(event_type, 0) + 1

            scheduled_query = (
                self._client.table("scheduled_events")
                .select("event_type")
                .eq("event_category", "user_event")
                .eq("status", "completed")
                .gte("created_at", cutoff_date.isoformat())
            )
            scheduled_query = self._with_bot_id(scheduled_query)
            scheduled_response = scheduled_query.execute()
            for event in scheduled_response.data or []:
                event_type = event.get("event_type", "unknown")
                event_counts[event_type] = event_counts.get(event_type, 0) + 1

            return event_counts
        except APIError as e:
            logger.error("Error getting events stats: %s", e)
            return {}

    async def get_last_event_info_by_user_and_type(self, user_id: int, event_type: str) -> Optional[str]:
        try:
            sessions_query = self._client.table("sales_chat_sessions").select("id").eq("user_id", user_id).order("created_at", desc=True).limit(1)
            sessions_query = self._with_bot_id(sessions_query)
            sessions_response = sessions_query.execute()
            if not sessions_response.data:
                logger.info("User %s not found in sessions", user_id)
                return None
            session_id = sessions_response.data[0]["id"]
            logger.info("Found latest session %s for user %s", session_id, user_id)

            events_response = (
                self._client.table("session_events")
                .select("event_info", "created_at")
                .eq("session_id", session_id)
                .eq("event_type", event_type)
                .order("created_at", desc=True)
                .limit(1)
                .execute()
            )
            if not events_response.data:
                logger.info("No events of type %r for session %s", event_type, session_id)
                return None
            event_info = events_response.data[0]["event_info"]
            logger.info("Found latest event %r for user %s", event_type, user_id)
            return event_info
        except Exception as e:
            logger.error(
                "Unexpected error getting last event info",
                extra={"user_id": user_id, "event_type": event_type, "bot_id": self._bot_id},
                exc_info=True,
            )
            raise SupabaseError(
                f"Unexpected error getting last event info: {e}",
                user_id=user_id,
                event_type=event_type,
                bot_id=self._bot_id,
            )

    async def check_user_stage_changed(self, user_id: int, original_session_id: str) -> bool:
        try:
            query = (
                self._client.table("sales_chat_sessions").select("id", "current_stage").eq("user_id", user_id).order("created_at", desc=True).limit(1)
            )
            query = self._with_bot_id(query)
            current_response = query.execute()
            if not current_response.data:
                return False
            current_session = current_response.data[0]
            if current_session["id"] != original_session_id:
                return True
            original_response = self._client.table("sales_chat_sessions").select("current_stage").eq("id", original_session_id).execute()
            if not original_response.data:
                return False
            original_stage = original_response.data[0]["current_stage"]
            current_stage = current_session["current_stage"]
            if original_stage != current_stage:
                logger.info("Stage changed: %s -> %s (session %s)", original_stage, current_stage, original_session_id)
                return True
            return False
        except Exception as e:
            logger.error("Error checking stage change for user %s: %s", user_id, e)
            return False
