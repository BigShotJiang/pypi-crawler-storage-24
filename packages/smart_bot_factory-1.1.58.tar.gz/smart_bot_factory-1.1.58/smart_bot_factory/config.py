# Обновленный config.py с автоопределением bot_id

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Mapping

# Переменные из .env файла загружаются в BotBuilder

logger = logging.getLogger(__name__)


def _env_get(env: Mapping[str, str], key: str, default: str) -> str:
    value = env.get(key)
    if value is None or value == "":
        return default
    return value


def _parse_bool_strict(env: Mapping[str, str], key: str, default: str) -> bool:
    raw = _env_get(env, key, default).strip().lower()
    if raw == "true":
        return True
    if raw == "false":
        return False
    raise ValueError(f"Invalid boolean env var {key}={raw!r}. Expected 'true' or 'false'.")


def _parse_int(env: Mapping[str, str], key: str, default: str) -> int:
    raw = _env_get(env, key, default).strip()
    try:
        return int(raw)
    except ValueError as e:
        raise ValueError(f"Invalid integer env var {key}={raw!r}.") from e


def _parse_float(env: Mapping[str, str], key: str, default: str) -> float:
    raw = _env_get(env, key, default).strip()
    try:
        return float(raw)
    except ValueError as e:
        raise ValueError(f"Invalid float env var {key}={raw!r}.") from e


@dataclass
class Config:
    """Конфигурация приложения"""

    # 🆕 Bot ID автоматически из переменной окружения (устанавливается в запускалке)
    BOT_ID: str = field(init=False)

    # Telegram Bot Token
    TELEGRAM_BOT_TOKEN: str = field(init=False)

    # Supabase настройки
    SUPABASE_URL: str = field(init=False)
    SUPABASE_KEY: str = field(init=False)

    # OpenAI настройки
    OPENAI_API_KEY: str = field(init=False)
    OPENAI_MODEL: str = field(init=False)
    # Модель для вспомогательных задач (суммаризация, парсинг сайтов). По умолчанию gpt-5-mini
    UTILITY_MODEL: str = field(init=False)
    OPENAI_MAX_TOKENS: int = field(init=False)
    OPENAI_TEMPERATURE: float = field(init=False)

    # Каталог с файлами промптов
    PROMPT_FILES_DIR: str = field(init=False)

    # Файл после стартого сообщения
    WELCOME_FILE_DIR: str = field(init=False)
    WELCOME_FILE_MSG: str = field(init=False)

    # Настройки базы данных
    MAX_CONTEXT_MESSAGES: int = field(init=False)
    HISTORY_MIN_MESSAGES: int = field(init=False)
    HISTORY_MAX_TOKENS: int = field(init=False)

    # Настройки логирования
    LOG_LEVEL: str = field(init=False)

    # Настройки продаж
    LEAD_QUALIFICATION_THRESHOLD: int = field(init=False)
    SESSION_TIMEOUT_HOURS: int = field(init=False)

    # Настройки форматирования сообщений
    MESSAGE_PARSE_MODE: str = field(init=False)
    PARSE_DATE_FORMAT: bool = field(init=False)

    # Язык пользовательских сообщений об ошибках (ru/lt)
    UI_LANGUAGE: str = field(init=False)

    # Список найденных файлов промптов (заполняется автоматически)
    PROMPT_FILES: List[str] = field(default_factory=list)

    # Администраторы (заполняется из переменной окружения)
    ADMIN_TELEGRAM_IDS: List[int] = field(default_factory=list)
    ADMIN_SESSION_TIMEOUT_MINUTES: int = field(init=False)

    # Режим отладки - показывать JSON пользователям
    DEBUG_MODE: bool = field(init=False)
    ENABLE_PROMPT_HOT_RELOAD: bool = field(init=False)

    # ============= PERFORMANCE MONITORING =============
    ENABLE_PERFORMANCE_LOGGING: bool = field(init=False)
    PERFORMANCE_LOG_MIN_MS: int = field(init=False)
    PERFORMANCE_LOG_LEVEL: str = field(init=False)

    def __post_init__(self):
        """Проверка обязательных параметров и инициализация"""
        env = os.environ

        # Поддержка тестов/спец-случаев, где объект создается через Config.__new__(Config)
        # и затем __post_init__ вызывается вручную: в таком случае dataclass __init__
        # не срабатывает, поэтому полей с default_factory может не быть.
        if not hasattr(self, "PROMPT_FILES"):
            self.PROMPT_FILES = []
        if not hasattr(self, "ADMIN_TELEGRAM_IDS"):
            self.ADMIN_TELEGRAM_IDS = []

        # ВАЖНО: все переменные окружения читаем на этапе создания экземпляра,
        # а не при импорте модуля (это упрощает тестирование и делает поведение предсказуемым).
        if not hasattr(self, "TELEGRAM_BOT_TOKEN"):
            self.TELEGRAM_BOT_TOKEN = env.get("TELEGRAM_BOT_TOKEN", "")
        if not hasattr(self, "SUPABASE_URL"):
            self.SUPABASE_URL = env.get("SUPABASE_URL", "")
        if not hasattr(self, "SUPABASE_KEY"):
            self.SUPABASE_KEY = env.get("SUPABASE_KEY", "")

        if not hasattr(self, "OPENAI_API_KEY"):
            self.OPENAI_API_KEY = env.get("OPENAI_API_KEY", "")
        if not hasattr(self, "OPENAI_MODEL"):
            self.OPENAI_MODEL = _env_get(env, "OPENAI_MODEL", "gpt-5-mini")
        if not hasattr(self, "UTILITY_MODEL"):
            self.UTILITY_MODEL = _env_get(env, "UTILITY_MODEL", "gpt-5-mini")
        if not hasattr(self, "OPENAI_MAX_TOKENS"):
            self.OPENAI_MAX_TOKENS = _parse_int(env, "OPENAI_MAX_TOKENS", "1500")
        if not hasattr(self, "OPENAI_TEMPERATURE"):
            self.OPENAI_TEMPERATURE = _parse_float(env, "OPENAI_TEMPERATURE", "0.7")

        if not hasattr(self, "PROMPT_FILES_DIR"):
            self.PROMPT_FILES_DIR = _env_get(env, "PROMPT_FILES_DIR", "prompts")
        if not hasattr(self, "WELCOME_FILE_DIR"):
            self.WELCOME_FILE_DIR = _env_get(env, "WELCOME_FILE_URL", "welcome_file")
        if not hasattr(self, "WELCOME_FILE_MSG"):
            self.WELCOME_FILE_MSG = _env_get(env, "WELCOME_FILE_MSG", "welcome_file_msg.txt")

        if not hasattr(self, "MAX_CONTEXT_MESSAGES"):
            self.MAX_CONTEXT_MESSAGES = _parse_int(env, "MAX_CONTEXT_MESSAGES", "50")
        if not hasattr(self, "HISTORY_MIN_MESSAGES"):
            self.HISTORY_MIN_MESSAGES = _parse_int(env, "HISTORY_MIN_MESSAGES", "4")
        if not hasattr(self, "HISTORY_MAX_TOKENS"):
            self.HISTORY_MAX_TOKENS = _parse_int(env, "HISTORY_MAX_TOKENS", "5000")

        if not hasattr(self, "LOG_LEVEL"):
            self.LOG_LEVEL = _env_get(env, "LOG_LEVEL", "INFO")
        if not hasattr(self, "LEAD_QUALIFICATION_THRESHOLD"):
            self.LEAD_QUALIFICATION_THRESHOLD = _parse_int(env, "LEAD_QUALIFICATION_THRESHOLD", "7")
        if not hasattr(self, "SESSION_TIMEOUT_HOURS"):
            self.SESSION_TIMEOUT_HOURS = _parse_int(env, "SESSION_TIMEOUT_HOURS", "24")

        if not hasattr(self, "MESSAGE_PARSE_MODE"):
            self.MESSAGE_PARSE_MODE = _env_get(env, "MESSAGE_PARSE_MODE", "Markdown")
        if not hasattr(self, "PARSE_DATE_FORMAT"):
            self.PARSE_DATE_FORMAT = _parse_bool_strict(env, "PARSE_DATE_FORMAT", "true")

        if not hasattr(self, "ADMIN_SESSION_TIMEOUT_MINUTES"):
            self.ADMIN_SESSION_TIMEOUT_MINUTES = _parse_int(env, "ADMIN_SESSION_TIMEOUT_MINUTES", "30")
        if not hasattr(self, "DEBUG_MODE"):
            self.DEBUG_MODE = _parse_bool_strict(env, "DEBUG_MODE", "false")
        if not hasattr(self, "ENABLE_PROMPT_HOT_RELOAD"):
            self.ENABLE_PROMPT_HOT_RELOAD = _parse_bool_strict(env, "ENABLE_PROMPT_HOT_RELOAD", "true")

        if not hasattr(self, "ENABLE_PERFORMANCE_LOGGING"):
            self.ENABLE_PERFORMANCE_LOGGING = _parse_bool_strict(env, "ENABLE_PERFORMANCE_LOGGING", "false")
        if not hasattr(self, "PERFORMANCE_LOG_MIN_MS"):
            self.PERFORMANCE_LOG_MIN_MS = _parse_int(env, "PERFORMANCE_LOG_MIN_MS", "10")
        if not hasattr(self, "PERFORMANCE_LOG_LEVEL"):
            self.PERFORMANCE_LOG_LEVEL = _env_get(env, "PERFORMANCE_LOG_LEVEL", "basic")

        # 🆕 Автоматически получаем BOT_ID из переменной окружения
        if not hasattr(self, "BOT_ID"):
            self.BOT_ID = env.get("BOT_ID", "")
        if not hasattr(self, "UI_LANGUAGE"):
            self.UI_LANGUAGE = _env_get(env, "UI_LANGUAGE", "ru")

        if not self.BOT_ID or not self.BOT_ID.strip():
            error_msg = "BOT_ID не установлен. Запускайте бота через запускалку (например: python growthmed-october-24.py)"
            logger.error(error_msg)
            raise ValueError(error_msg)

        # Проверяем формат BOT_ID
        import re

        if not re.match(r"^[a-z0-9\-]+$", self.BOT_ID):
            error_msg = f"BOT_ID должен содержать только латинские буквы, цифры и дефисы: {self.BOT_ID}"
            logger.error(error_msg)
            raise ValueError(error_msg)

        # Валидация языка пользовательских сообщений
        if self.UI_LANGUAGE not in ["ru", "lt"]:
            error_msg = f"UI_LANGUAGE должен быть 'ru' или 'lt': {self.UI_LANGUAGE}"
            logger.error(error_msg)
            raise ValueError(error_msg)

        # Сканируем каталог с промптами
        self._scan_prompt_files()

        # Парсим список админов
        self._parse_admin_ids()

        # Проверяем обязательные поля
        required_fields = [
            "TELEGRAM_BOT_TOKEN",
            "SUPABASE_URL",
            "SUPABASE_KEY",
            "OPENAI_API_KEY",
        ]

        missing_fields = []
        for field_name in required_fields:
            if not getattr(self, field_name):
                missing_fields.append(field_name)

        if missing_fields:
            error_msg = f"Отсутствуют обязательные переменные окружения: {', '.join(missing_fields)}"
            logger.error(error_msg)
            raise ValueError(error_msg)

        # Настройка уровня логирования
        log_level = getattr(logging, self.LOG_LEVEL.upper(), logging.INFO)

        # Настраиваем корневой логгер
        root_logger = logging.getLogger()
        root_logger.setLevel(log_level)

        # Настраиваем форматтер
        if not root_logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
            handler.setFormatter(formatter)
            root_logger.addHandler(handler)

        # Устанавливаем уровень для всех модулей
        module_loggers = [
            "smart_bot_factory",
            "smart_bot_factory.message",
            "smart_bot_factory.handlers",
            "smart_bot_factory.utils",
            "smart_bot_factory.utils.bot_utils",
            "smart_bot_factory.admin.conversation_manager",
            "smart_bot_factory.integrations",
            "smart_bot_factory.integrations.supabase_client",
            "smart_bot_factory.integrations.openai",
            "smart_bot_factory.integrations.openai.prompt_loader",
            "smart_bot_factory.memory",
            "smart_bot_factory.memory.memory_manager",
            "smart_bot_factory.admin",
            "smart_bot_factory.admin.admin_manager",
            "smart_bot_factory.admin.admin_logic",
            "smart_bot_factory.event",
            "smart_bot_factory.creation",
            "openai_client",
            "supabase_client",
            "handlers",
            "bot_utils",
            "smart_bot_factory.admin.conversation_manager",
            "admin_manager",
            "prompt_loader",
            "admin_logic",
            "smart_bot_factory.debug.debug_routing",
        ]
        for module_name in module_loggers:
            logging.getLogger(module_name).setLevel(log_level)

        # Полностью отключаем шумные логи aiogram о сетевых ошибках
        aiogram_loggers = [
            "aiogram.dispatcher",
            "aiogram.client.session",
            "aiogram.client.telegram",
        ]
        for logger_name in aiogram_loggers:
            aiogram_logger = logging.getLogger(logger_name)
            aiogram_logger.setLevel(logging.CRITICAL + 1)  # Выше CRITICAL - ничего не показывать
            aiogram_logger.disabled = True  # Полностью отключаем логгер

        # Валидация значений
        if self.OPENAI_MAX_TOKENS < 100 or self.OPENAI_MAX_TOKENS > 4000:
            logger.warning(f"Необычное значение OPENAI_MAX_TOKENS: {self.OPENAI_MAX_TOKENS}")

        if self.OPENAI_TEMPERATURE < 0 or self.OPENAI_TEMPERATURE > 1:
            logger.warning(f"Необычное значение OPENAI_TEMPERATURE: {self.OPENAI_TEMPERATURE}")

        # Валидация performance настроек
        if self.PERFORMANCE_LOG_MIN_MS < 0:
            raise ValueError(f"PERFORMANCE_LOG_MIN_MS must be >= 0, got: {self.PERFORMANCE_LOG_MIN_MS}")

        if self.PERFORMANCE_LOG_LEVEL not in ["basic", "detailed"]:
            raise ValueError(f"Invalid PERFORMANCE_LOG_LEVEL: {self.PERFORMANCE_LOG_LEVEL!r}. Expected 'basic' or 'detailed'.")

        if self.ENABLE_PERFORMANCE_LOGGING:
            logger.info(f"⏱️  Performance logging ВКЛЮЧЕН (min={self.PERFORMANCE_LOG_MIN_MS}ms, level={self.PERFORMANCE_LOG_LEVEL})")

        logger.info("✅ Конфигурация загружена успешно")
        logger.info(f"🤖 Bot ID (автоопределен): {self.BOT_ID}")
        logger.debug(f"Модель OpenAI: {self.OPENAI_MODEL}")
        logger.debug(f"Каталог промптов: {self.PROMPT_FILES_DIR}")
        logger.debug(f"Найдено файлов: {len(self.PROMPT_FILES)}")
        logger.info(f"👥 Админов настроено: {len(self.ADMIN_TELEGRAM_IDS)}")
        if self.DEBUG_MODE:
            logger.warning("🐛 Режим отладки ВКЛЮЧЕН - JSON будет показываться пользователям")

    def get_summary(self) -> dict:
        """Возвращает сводку конфигурации (без секретов)"""
        return {
            "bot_id": self.BOT_ID,  # 🆕 автоопределенный
            "openai_model": self.OPENAI_MODEL,
            "max_tokens": self.OPENAI_MAX_TOKENS,
            "temperature": self.OPENAI_TEMPERATURE,
            "prompts_dir": self.PROMPT_FILES_DIR,
            "max_context": self.MAX_CONTEXT_MESSAGES,
            "log_level": self.LOG_LEVEL,
            "prompt_files_count": len(self.PROMPT_FILES),
            "prompt_files": self.PROMPT_FILES,
            "has_telegram_token": bool(self.TELEGRAM_BOT_TOKEN),
            "has_supabase_config": bool(self.SUPABASE_URL and self.SUPABASE_KEY),
            "has_openai_key": bool(self.OPENAI_API_KEY),
            "admin_count": len(self.ADMIN_TELEGRAM_IDS),
            "debug_mode": self.DEBUG_MODE,
        }

    def _parse_admin_ids(self):
        """Парсит список ID админов из переменной окружения"""
        admin_ids_str = os.environ.get("ADMIN_TELEGRAM_IDS", "")

        if not admin_ids_str.strip():
            logger.warning("⚠️ ADMIN_TELEGRAM_IDS не настроен - админские функции недоступны")
            return

        try:
            # Парсим строку вида "123456,789012,345678"
            ids = admin_ids_str.split(",")
            admin_ids = [int(id_str.strip()) for id_str in ids if id_str.strip()]

            if not admin_ids:
                logger.warning("⚠️ ADMIN_TELEGRAM_IDS пуст - админские функции недоступны")
            else:
                self.ADMIN_TELEGRAM_IDS.extend(admin_ids)
                logger.info(f"👥 Загружены админы: {self.ADMIN_TELEGRAM_IDS}")

        except ValueError as e:
            raise ValueError(f"Invalid ADMIN_TELEGRAM_IDS={admin_ids_str!r}. Expected comma-separated integers.") from e

    def _scan_prompt_files(self):
        """Сканирует каталог с промптами и проверяет необходимые файлы"""
        prompts_dir = Path(self.PROMPT_FILES_DIR).absolute()

        # Проверяем существование каталога
        if not prompts_dir.exists():
            error_msg = f"Каталог с промптами не найден: {prompts_dir.absolute()}"
            logger.error(error_msg)
            raise FileNotFoundError(error_msg)

        if not prompts_dir.is_dir():
            error_msg = f"Путь не является каталогом: {prompts_dir.absolute()}"
            logger.error(error_msg)
            raise NotADirectoryError(error_msg)

        # Ищем все .txt файлы
        txt_files = list(prompts_dir.glob("*.txt"))

        if not txt_files:
            error_msg = f"В каталоге {prompts_dir.absolute()} не найдено ни одного .txt файла"
            logger.error(error_msg)
            raise FileNotFoundError(error_msg)

        # Проверяем обязательное наличие welcome_message.txt
        welcome_file = prompts_dir / "welcome_message.txt"
        if not welcome_file.exists():
            error_msg = f"Обязательный файл welcome_message.txt не найден в {prompts_dir}"
            logger.error(error_msg)
            raise FileNotFoundError(error_msg)

        # Формируем список файлов промптов (исключая welcome_message.txt и help_message.txt)
        excluded_files = {"welcome_message.txt", "help_message.txt"}
        for txt_file in txt_files:
            if txt_file.name not in excluded_files:
                self.PROMPT_FILES.append(txt_file.name)

        if not self.PROMPT_FILES:
            error_msg = f"В каталоге {prompts_dir.absolute()} найден только welcome_message.txt, но нет других файлов промптов"
            logger.error(error_msg)
            raise FileNotFoundError(error_msg)

        # Сортируем для предсказуемого порядка
        self.PROMPT_FILES.sort()

        logger.info(f"📁 Найдено файлов промптов: {len(self.PROMPT_FILES)}")
        logger.info(f"📝 Файлы промптов: {', '.join(self.PROMPT_FILES)}")
        logger.info("👋 Файл приветствия: welcome_message.txt")
