"""Public compatibility facade for bot utilities."""

from ..event.decorators.notifications import notify_admins_about_event
from ..handlers.helpers.messaging import send_message
from ..handlers.helpers.tracking import parse_utm_from_start_param
from ..handlers.helpers.welcome import send_welcome_file
from ..handlers.processing.event_processing import process_events, process_file_events
from ..handlers.routers.utils_commands import utils_router

__all__ = [
    "utils_router",
    "process_events",
    "process_file_events",
    "send_message",
    "notify_admins_about_event",
    "send_welcome_file",
    "parse_utm_from_start_param",
]
