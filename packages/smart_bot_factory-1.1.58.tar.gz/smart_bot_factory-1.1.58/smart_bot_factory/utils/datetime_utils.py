"""Utilities for parsing ISO 8601 datetime strings into timezone-aware UTC datetimes."""

from datetime import datetime, timezone


def parse_iso_to_utc(value: str) -> datetime:
    """Parse an ISO 8601 datetime string and return a timezone-aware UTC datetime.

    Handles three formats from Supabase/PostgreSQL:
    - Trailing 'Z': '2024-01-01T12:00:00Z'
    - Explicit offset: '2024-01-01T12:00:00+03:00'
    - Naive (no timezone): '2024-01-01T12:00:00' — assumed UTC

    Args:
        value: ISO 8601 datetime string

    Returns:
        datetime with tzinfo=timezone.utc
    """
    if value.endswith("Z"):
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    elif "+" in value or value.count(":") >= 3:
        dt = datetime.fromisoformat(value)
    else:
        dt = datetime.fromisoformat(value).replace(tzinfo=timezone.utc)

    return dt.astimezone(timezone.utc)
