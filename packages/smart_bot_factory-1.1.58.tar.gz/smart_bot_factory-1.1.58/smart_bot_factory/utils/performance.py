"""
Утилиты для мониторинга производительности.
"""

from __future__ import annotations

import asyncio
import functools
import logging
import time
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)


def measure_time(
    func: Optional[Callable] = None,
    *,
    min_ms: Optional[int] = None,
    log_args: Optional[bool] = None,
    custom_name: Optional[str] = None,
):
    """
    Декоратор для измерения времени выполнения функций (sync/async).
    Поведение полностью прозрачно, когда логирование выключено.
    """

    def decorator(f: Callable) -> Callable:
        is_async = asyncio.iscoroutinefunction(f)

        @functools.wraps(f)
        async def async_wrapper(*args, **kwargs) -> Any:
            return await _execute_with_timing(f, args, kwargs, True, min_ms, log_args, custom_name)

        @functools.wraps(f)
        def sync_wrapper(*args, **kwargs) -> Any:
            return _execute_with_timing(f, args, kwargs, False, min_ms, log_args, custom_name)

        return async_wrapper if is_async else sync_wrapper

    if func is None:
        return decorator
    return decorator(func)


async def _execute_with_timing_async(
    func: Callable,
    args: tuple,
    kwargs: dict,
    min_ms: Optional[int],
    log_args: Optional[bool],
    custom_name: Optional[str],
) -> Any:
    should_log, threshold_ms, should_log_args, func_name = _prepare_settings(func, min_ms=min_ms, log_args=log_args, custom_name=custom_name)
    if not should_log:
        return await func(*args, **kwargs)

    start = time.perf_counter()
    try:
        result = await func(*args, **kwargs)
        elapsed_ms = (time.perf_counter() - start) * 1000
        _log_and_record(func_name, elapsed_ms, threshold_ms, should_log_args, args, kwargs, error=False)
        return result
    except Exception:
        elapsed_ms = (time.perf_counter() - start) * 1000
        _log_and_record(func_name, elapsed_ms, threshold_ms, should_log_args, args, kwargs, error=True)
        raise


def _execute_with_timing(
    func: Callable,
    args: tuple,
    kwargs: dict,
    is_async: bool,
    min_ms: Optional[int],
    log_args: Optional[bool],
    custom_name: Optional[str],
):
    should_log, threshold_ms, should_log_args, func_name = _prepare_settings(func, min_ms=min_ms, log_args=log_args, custom_name=custom_name)
    if not should_log:
        return func(*args, **kwargs)

    start = time.perf_counter()

    if is_async:

        async def runner():
            try:
                result = await func(*args, **kwargs)
                elapsed_ms = (time.perf_counter() - start) * 1000
                _log_and_record(func_name, elapsed_ms, threshold_ms, should_log_args, args, kwargs, error=False)
                return result
            except Exception:
                elapsed_ms = (time.perf_counter() - start) * 1000
                _log_and_record(func_name, elapsed_ms, threshold_ms, should_log_args, args, kwargs, error=True)
                raise

        return runner()

    try:
        result = func(*args, **kwargs)
        elapsed_ms = (time.perf_counter() - start) * 1000
        _log_and_record(func_name, elapsed_ms, threshold_ms, should_log_args, args, kwargs, error=False)
        return result
    except Exception:
        elapsed_ms = (time.perf_counter() - start) * 1000
        _log_and_record(func_name, elapsed_ms, threshold_ms, should_log_args, args, kwargs, error=True)
        raise


def _prepare_settings(
    func: Callable,
    *,
    min_ms: Optional[int],
    log_args: Optional[bool],
    custom_name: Optional[str],
):
    """Читает настройки из ctx.config, не ломая код при отсутствии конфига."""
    try:
        from .context import ctx  # локальный импорт, чтобы избежать циклов

        cfg = getattr(ctx, "config", None)
        enable = getattr(cfg, "ENABLE_PERFORMANCE_LOGGING", False) if cfg else False
        if not isinstance(enable, bool) or not enable:
            return False, 0, False, func.__name__

        threshold_ms = min_ms if min_ms is not None else getattr(cfg, "PERFORMANCE_LOG_MIN_MS", 10)
        if not isinstance(threshold_ms, (int, float)):
            return False, 0, False, func.__name__

        should_log_args = log_args if log_args is not None else getattr(cfg, "PERFORMANCE_LOG_LEVEL", "basic") == "detailed"
        func_name = custom_name if custom_name else func.__name__
        return True, threshold_ms, should_log_args, func_name
    except Exception:
        return False, 0, False, func.__name__


def _log_and_record(
    func_name: str,
    elapsed_ms: float,
    threshold_ms: int,
    log_args: bool,
    args: tuple,
    kwargs: dict,
    error: bool = False,
):
    if elapsed_ms < threshold_ms:
        return

    emoji = "❌" if error else "⏱️"
    status = " (ERROR)" if error else ""
    message = f"{emoji} {func_name}: {elapsed_ms:.1f} мс{status}"

    if log_args and (args or kwargs):
        args_str = _format_args(args, kwargs)
        message += f" | args: {args_str}"

    if elapsed_ms > 1000:
        logger.warning(message)
    elif elapsed_ms > 500:
        logger.info(message)
    else:
        logger.debug(message)

    _performance_stats.record(func_name, elapsed_ms)


def _format_args(args: tuple, kwargs: dict, max_length: int = 100) -> str:
    parts = []
    for arg in args:
        parts.append(_format_value(arg))
    for key, value in kwargs.items():
        parts.append(f"{key}={_format_value(value)}")
    result = ", ".join(parts)
    if len(result) > max_length:
        result = result[:max_length] + "..."
    return result


def _format_value(value: Any, max_length: int = 50) -> str:
    if isinstance(value, str):
        if len(value) > max_length:
            return f'"{value[:max_length]}..."'
        return f'"{value}"'
    if isinstance(value, (list, tuple)):
        return f"{type(value).__name__}({len(value)} items)"
    if isinstance(value, dict):
        return f"dict({len(value)} keys)"
    try:
        s = str(value)
        if len(s) > max_length:
            return s[:max_length] + "..."
        return s
    except Exception:
        return f"<{type(value).__name__}>"


class PerformanceStats:
    """Хранит агрегированную статистику по функциям."""

    def __init__(self) -> None:
        self._stats: dict[str, dict[str, float | int]] = {}

    def record(self, func_name: str, elapsed_ms: float) -> None:
        if func_name not in self._stats:
            self._stats[func_name] = {
                "count": 0,
                "total_ms": 0.0,
                "min_ms": float("inf"),
                "max_ms": 0.0,
            }
        stats = self._stats[func_name]
        stats["count"] += 1
        stats["total_ms"] += elapsed_ms
        stats["min_ms"] = min(stats["min_ms"], elapsed_ms)
        stats["max_ms"] = max(stats["max_ms"], elapsed_ms)

    def get_stats(self, top_n: int = 10) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        for func_name, stats in self._stats.items():
            count = stats["count"] or 1
            avg_ms = stats["total_ms"] / count
            result.append(
                {
                    "function": func_name,
                    "calls": int(stats["count"]),
                    "avg_ms": round(avg_ms, 2),
                    "min_ms": round(stats["min_ms"], 2),
                    "max_ms": round(stats["max_ms"], 2),
                    "total_ms": round(stats["total_ms"], 2),
                }
            )
        result.sort(key=lambda x: x["avg_ms"], reverse=True)
        return result[:top_n]

    def reset(self) -> None:
        self._stats.clear()


_performance_stats = PerformanceStats()


def get_performance_stats(top_n: int = 10) -> list[dict[str, Any]]:
    """Возвращает статистику производительности."""
    return _performance_stats.get_stats(top_n)
