"""
Compatibility wrapper for debug routing helpers.

The implementation was moved to `smart_bot_factory.debug.debug_routing`.
"""

from ..debug.debug_routing import (  # noqa: F401
    debug_admin_conversation_creation,
    debug_router,
    debug_user_state,
    setup_debug_handlers,
    test_message_routing,
)

__all__ = [
    "debug_router",
    "setup_debug_handlers",
    "debug_user_state",
    "debug_admin_conversation_creation",
    "test_message_routing",
]

