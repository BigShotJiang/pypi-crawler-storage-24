#!/usr/bin/python3
# -*- coding: utf-8 -*-

import requests
import logging
import http
import atexit
import time
import random
import hashlib
import ddddocr
import telegram
import asyncio
import base64
from urllib.parse import urljoin
from json_utils import to_json
import json
from wechatpy.enterprise import WeChatClient

logger = logging.getLogger(__name__)


class OnebotClient:
    OK = 0

    def __init__(self, api_key, api_url='http://localhost:8080/'):
        self.api_url = api_url
        if not api_url.endswith("/"):
            self.api_url += "/"
        self.verify = True
        self.api_key = api_key
        self.session = ''
        self.send_private_msg_url = urljoin(self.api_url, 'send_private_msg')

    @classmethod
    def from_settings(cls, settings):
        client = cls(
            api_key=settings.get('ONEBOT_API_KEY'),
            api_url=settings.get('ONEBOT_API_URL', 'http://localhost:8080/')
        )
        return client

    def process_res(self, res):
        if res.status_code != http.HTTPStatus.OK:
            logger.error(
                f'request {res.url} failed, status: {res.status_code}')
            return None
        try:
            res_json = res.json()
            if res_json['retcode'] != self.OK:
                logger.error(f'request {res.url} failed, {res_json}')
                return None
            else:
                logger.debug(f'request {res.url} success, {res_json}')
                return res_json
        except Exception as e:
            logger.error(f'request {res.url} failed, exception: {e}')
            return None

    def send_text_msg(self, recipients, msg):
        if type(recipients) is int or type(recipients) is str:
            self._send_text_msg(recipients, msg)
            return
        for recipient in recipients:
            self._send_text_msg(recipient, msg)

    def _send_text_msg(self, recipient, msg):
        res = requests.post(self.send_private_msg_url, headers={
            "Authorization": f"Bearer {self.api_key}"
        }, json={
            "user_id": int(recipient),
            "message": msg
        }, verify=self.verify)
        res_json = self.process_res(res)
        logger.info(f'client_send_text_msg({msg}) to ({recipient}) {res_json}')

def generate_nonce():
    nonce = ''
    for c in 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx':
        if c == 'x' or c == 'y':
            rn = int(random.random()*16)
            n = rn if c == 'x' else (rn & 0x3 | 0x8)
            nonce += '%x' % n
        else :
            nonce += c
    return nonce

def calc_signature(token, nonce, ts_str):
    s = token + 'g8SzIXPkOm' + ts_str + nonce
    return hashlib.md5(s.encode()).hexdigest()

async def test_telegram(bot: telegram.Bot, chat_id: int):
    msg = 'hello'
    # print(await bot.get_updates())
    # print(await bot.get_me())
    # print(await bot.send_message(chat_id=chat_id, text=msg))
    await get_house_stats_info(bot, chat_id)

async def get_house_stats_info(bot: telegram.Bot, chat_id: int):
    msg = 'hello'
    session = requests.Session()
    res = session.get('https://prh.shcngz.com/getVerifiCode')
    res_json = res.json()
    img_data = res_json['data']['data']['session_vcode'].replace('data:image/jpeg;base64,', '')
    print(img_data)
    print(res.cookies)
    ocr = ddddocr.DdddOcr()
    vcode = ocr.classification(base64.b64decode(img_data))
    vkey = res_json['data']['data']['key']
    print(vkey)
    print(vcode)
    res = session.post('https://prh.shcngz.com/doLogin', json={
        "loginPwd": "pwd",
        "loginUser": "user",
        "loginIp": "",
        "key": vkey,
        "verifyInput": vcode})
    res_json = res.json()
    print(res_json)
    token = res_json['data']['token']
    nonce = generate_nonce()
    ts = int(time.time())*1000
    headers = {
        'Authorization': token,
        'timestamp': str(ts),
        'nonce': nonce,
        'signature': calc_signature(token, nonce, str(ts))
    }
    project_info = session.get('https://prh.shcngz.com/getUserProjectSummaryInfo?projectName=&district=%E9%95%BF%E5%AE%81%E5%8C%BA&layout=&houseType=&sortType=0&pageIndex=0&st=', headers = headers)
    print(to_json(project_info.json()))
    nonce = generate_nonce()
    ts = int(time.time())*1000
    headers = {
        'Authorization': token,
        'timestamp': str(ts),
        'nonce': nonce,
        'signature': calc_signature(token, nonce, str(ts))
    }
    queue_info = session.get('https://prh.shcngz.com/getMyQueueList', headers = headers)
    print(to_json(queue_info.json()))

if __name__ == '__main__':
    sh = logging.StreamHandler()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(sh)
    # sender = 0
    # api_key = 'a123456789'
    # api_url = "http://localhost:8080/"
    # recipients = [0]
    # client = OnebotClient(api_key, api_url)
    # client.send_text_msg(recipients, 'hello world')

    # bot = telegram.Bot("bot")
    # chat_id = 1
    # asyncio.run(test_telegram(bot, chat_id))

    corpid = ""
    secret = ""
    agent_id = 1000002
    to_user = "@all"

    # token_url = f"https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={corpid}&corpsecret={secret}"
    # token = requests.get(token_url).json()['access_token']

    # data = {
    #     "touser": to_user,
    #     "msgtype": "text",
    #     "agentid": agent_id,
    #     "text": {
    #         "content": "这是来自自建应用的微信弹窗提醒！"
    #     }
    # }

    # send_url = f"https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={token}"
    # response = requests.post(send_url, data=json.dumps(data))
    # print(response.json())

    wechat_client = WeChatClient(corpid, secret)
    wechat_client.message.send_text(
        agent_id=agent_id,
        user_ids=to_user,
        content='Hello! 这是来自 Python SDK 的消息'
    )