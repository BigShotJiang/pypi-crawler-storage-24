from typing import Optional
from dataclasses import dataclass, asdict
import copy

@dataclass
class CmpDictResult:
    left_only_keys: list[str]
    right_only_keys: list[str]
    diff_keys: list[str]
    all_diff_keys: list[str]

    def has_diff(self) -> bool:
        return len(self.all_diff_keys) > 0

def cmp_dict(left: dict, right: dict, ignore_keys: Optional[list[str]] = None) -> CmpDictResult:
    if ignore_keys is None:
        ignore_keys = []

    left_only_keys = []
    right_only_keys = []
    diff_keys = []
    all_diff_keys = []

    left_keys = set(left.keys()) - set(ignore_keys)
    right_keys = set(right.keys()) - set(ignore_keys)

    for key in left_keys - right_keys:
        left_only_keys.append(key)
        all_diff_keys.append(key)

    for key in right_keys - left_keys:
        right_only_keys.append(key)
        all_diff_keys.append(key)

    for key in left_keys & right_keys:
        if left[key] != right[key]:
            diff_keys.append(key)
            all_diff_keys.append(key)

    return CmpDictResult(
        left_only_keys=sorted(list(set(left_only_keys))),
        right_only_keys=sorted(list(set(right_only_keys))),
        diff_keys=sorted(list(set(diff_keys))),
        all_diff_keys=sorted(list(set(all_diff_keys)))
    )

def merge_dict(base_dict: dict, update_dict: dict) -> dict:
    result_dict = copy.deepcopy(base_dict)
    for key, value in update_dict.items():
        if key in result_dict and isinstance(result_dict[key], dict) and isinstance(value, dict):
            result_dict[key] = merge_dict(result_dict[key], value)
        else:
            result_dict[key] = value
    return result_dict

if __name__ == "__main__":
    a = {
        "a": 1,
        "b": 2,
        "c": {
            "d": 3,
            "e": 4
        }
    }
    b = {
        "a": 1,
        "b": 2,
        "c": {
            "d": 33,
            "e": 4,
            "g": "g"
        },
        "f": 5
    }
    print(merge_dict(a, b))