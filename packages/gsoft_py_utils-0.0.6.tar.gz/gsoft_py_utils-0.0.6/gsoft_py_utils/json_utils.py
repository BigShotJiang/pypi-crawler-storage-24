from dataclasses import dataclass, asdict
import json
from enum import Enum
from datetime import datetime
from decimal import Decimal
from typing import Type, TypeVar
import dacite

T = TypeVar("T", bound="BaseModel")


def to_json(obj, **kw):
    return json.dumps(to_dict(obj), separators=(',', ':'), ensure_ascii=False, **kw)


def to_dict(obj):
    return to_dict_ignore(obj)


def to_dict_ignore(obj, ignore: list[str] = None):
    if obj is None:
        return None

    if ignore is None:
        ignore = []

    if isinstance(obj, BaseModel):
        return obj.to_dict_ignore(ignore)
    elif isinstance(obj, (list, tuple, set)):
        return [to_dict_ignore(item) for item in obj]
    elif isinstance(obj, (datetime, Decimal)):
        # datetime 和 Decimal 转字符串
        return str(obj)
    elif issubclass(type(obj), Enum):
        return str(obj)
    elif isinstance(obj, dict):
        dd = {}
        for k, v in obj.items():
            dd[k] = to_dict(v)
        return dd
    else:
        return obj


def from_json(cls: Type[T], json_str: str) -> T:
    data = json.loads(json_str)
    return dacite.from_dict(cls, data)


def from_dict(cls: Type[T], d) -> T:
    return dacite.from_dict(cls, d)


@dataclass
class BaseModel:
    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self) -> dict:
        return to_json(self.to_dict())

    def to_dict_ignore(self, ignore: list[str] = None) -> dict:
        result = {}
        for k, v in asdict(self).items():
            if k in ignore:
                continue
            if v is None:
                continue
            result[k] = to_dict(v)
        return result

    def to_json_ignore(self, ignore: list[str] = None, **kwargs) -> str:
        """
        将对象序列化为 JSON 字符串
        :param ignore: 要忽略的字段列表
        :param kwargs: json.dumps 额外参数
        """
        return to_json(self.to_dict_ignore(ignore), **kwargs)


def load_json_from_file(file_name: str):
    with open(file_name, "r", encoding="utf-8") as f:
        r = json.load(f)
    return r
