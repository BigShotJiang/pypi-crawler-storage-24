"""wbapi-async code generator."""

from .codegen import run


__all__ = ("run",)
