"""
CLI entry point.

Usage:
    wbapi-codegen --target ./wbapi-async --swagger-dir ./.wb/swagger
    wbapi-codegen --target ./wbapi-async .wb/swagger/02-products.yaml
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .codegen import run


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="wbapi-codegen",
        description="Generate wbapi-async types, methods and client from Wildberries OpenAPI YAML files.",
    )
    parser.add_argument(
        "--target",
        type=Path,
        default=Path("."),
        help="Path to the wbapi-async project root (default: current directory)",
    )
    parser.add_argument(
        "--swagger-dir",
        type=Path,
        default=None,
        help="Directory with YAML files (default: <target>/.wb/swagger)",
    )
    parser.add_argument(
        "files",
        nargs="*",
        type=Path,
        help="Explicit YAML files to process (overrides --swagger-dir)",
    )
    args = parser.parse_args()

    target: Path = args.target.resolve()

    if args.files:
        yaml_files = [Path(f).resolve() for f in args.files]
    else:
        swagger_dir: Path = args.swagger_dir or (target / ".wb" / "swagger")
        yaml_files = sorted(swagger_dir.glob("*.yaml")) + sorted(swagger_dir.glob("*.yml"))

    if not yaml_files:
        print(f"No YAML files found. Pass files explicitly or check --swagger-dir.", file=sys.stderr)
        sys.exit(1)

    run(yaml_files, target)


if __name__ == "__main__":
    main()
