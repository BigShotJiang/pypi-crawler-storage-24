# wbapi-codegen

Code generator for [wbapi-async](https://github.com/serdukow/wbapi-async).

Parses Wildberries OpenAPI YAML specs and generates:
- `src/wbapi_async/types/` — Pydantic response models
- `src/wbapi_async/methods/` — `WbMethod` request classes
- `src/wbapi_async/client/api.py` — `WbAPI` wrapper methods

Files marked `__unofficial__ = True` are never overwritten.

## Install

```bash
pip install wbapi-codegen
```

## Usage

```bash
# process all YAMLs from .wb/swagger/ into current directory
wbapi-codegen --target /path/to/wbapi-async

# custom swagger directory
wbapi-codegen --target /path/to/wbapi-async --swagger-dir /path/to/yaml/files

# single file
wbapi-codegen --target /path/to/wbapi-async /path/to/02-products.yaml
```

## How it works

1. Downloads OpenAPI YAMLs from Wildberries developer portal
2. Parses paths, parameters, request bodies and response schemas
3. Generates typed Python files following the `wbapi-async` conventions
4. Creates a PR in the `wbapi-async` repo via GitHub Actions (runs daily at 04:00 UTC)

## Setup for GitHub Actions

In the `wbapi-codegen` repo, add a secret `WBAPI_PAT` — a GitHub Personal Access Token
with `repo` scope on the `wbapi-async` repository.
