# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""OSINT Researcher job class — open-source intelligence, investigations, and due diligence."""

from . import JobClass, register_job_class

OSINT_RESEARCHER = JobClass(
    key="osint_researcher",
    name="OSINT Researcher",
    icon="fa-magnifying-glass-location",
    description="Open-source intelligence gathering, investigations, and due diligence research",
    prompt_fragment="""You are operating in OSINT Researcher mode — an open-source intelligence assistant. Your focus areas:
- **Authorization first**: Before running ANY OSINT tool against a target, you MUST call confirm_osint_target() to establish explicit authorization with justification and scope. The public record is not a license. (Constitution Article 8)
- **Investigations**: Manage investigation workflows from hypothesis to findings. Track entities, relationships, and evidence chains.
- **Entity research**: Look up domains, IPs, organizations, and public figures using publicly available sources — WHOIS, DNS, certificate transparency, Shodan, breach databases.
- **Digital footprint analysis**: Map online presence through subdomains, email harvesting, social profiles, and linked accounts.
- **Due diligence**: Research companies and individuals for business relationships — corporate registrations, legal history, public filings.
- **OSINT automation**: Use SpiderFoot for comprehensive automated reconnaissance. Interpret results and identify significant findings.
- **Source verification**: Cross-reference findings across multiple sources. Note confidence levels and data freshness.
- **Report writing**: Structure findings into clear investigation reports with source citations, confidence ratings, and limitations.
- **Ethics & law**: OSINT must be legal in your jurisdiction and proportionate to the purpose. Never use gathered intelligence for harassment, stalking, or unauthorized access.""",
    skill_weights={
        "confirm_osint_target": 1.0,
        # SpiderFoot orchestration
        "start_spiderfoot_scan": 0.9,
        "get_scan_status": 0.9,
        "get_scan_findings": 0.9,
        "list_spiderfoot_scans": 0.8,
        "export_scan_report": 0.8,
        # OSINT investigation persistence
        "create_investigation": 0.9,
        "update_investigation_status": 0.8,
        "add_finding": 0.9,
        "list_investigations": 0.8,
        "get_investigation_findings": 0.8,
        "summarize_investigation": 0.8,
        # Single-purpose OSINT tools
        "harvest_emails": 0.8,
        "enumerate_subdomains": 0.8,
        "dns_enumerate": 0.8,
        "whois_lookup": 0.8,
        "certificate_transparency": 0.8,
        "shodan_lookup": 0.7,
        "ip_geolocation": 0.7,
        "search_breach_data": 0.7,
        "web_search": 0.9,
        "web_read": 0.9,
        "write_note": 0.9,
        "search_notes": 0.8,
        "remember": 0.8,
        "recall": 0.9,
        "query_chairman": 0.7,
        "smart_intake": 0.5,
        "review_intake": 0.4,
    },
    species_flavor={
        "fox": (
            "Your fox brings investigative cunning — following threads,"
            " making unexpected connections, and knowing when a source is being deceptive."
        ),
        "owl": (
            "Your owl brings meticulous documentation — cross-referencing sources,"
            " tracking confidence levels, and building bulletproof evidence chains."
        ),
        "cat": (
            "Your cat brings quiet persistence — patient digital footprint tracing,"
            " waiting for targets to reveal themselves, and noticing what's conspicuously absent."
        ),
        "dragon": (
            "Your dragon brings comprehensive reach — casting wide nets,"
            " aggressive automation, and thorough coverage across data sources."
        ),
        "wolf": (
            "Your wolf brings pack coordination — organizing complex multi-entity investigations,"
            " tracking relationship networks, and maintaining investigation continuity."
        ),
        "frog": (
            "Your frog brings creative lateral thinking — finding unexpected data sources,"
            " using obscure OSINT techniques, and leaping to novel connections."
        ),
    },
    recommended_connects=[
        "joplin",
        "email",
    ],
    proactive_focus=[
        "check on active SpiderFoot scan progress",
        "review authorization log for expiring targets",
        "check for new findings on monitored domains",
    ],
    workspace={
        "label": "OSINT Lab",
        "icon": "fa-magnifying-glass-location",
        "description": (
            "Your investigation hub — manage targets, track findings,"
            " run automated scans, and build evidence chains."
        ),
        "overview": {
            "cards": [
                {
                    "key": "server_setup_cta",
                    "type": "cta",
                    "icon": "fa-server",
                    "color": "#60a5fa",
                    "label": "OSINT Infrastructure",
                    "message": (
                        "No server infrastructure detected. Deploy SpiderFoot,"
                        " SearXNG, and supporting services to power your"
                        " investigations with self-hosted tools."
                    ),
                    "button_label": "Deploy OSINT Stack",
                    "button_action": "full_server_setup",
                    "source": "server",
                    "show_when": "needs_setup",
                    "service_keys": ["spiderfoot", "searxng", "gitea", "joplin"],
                },
                {
                    "key": "osint_services",
                    "type": "service_status",
                    "icon": "fa-server",
                    "color": "#60a5fa",
                    "label": "OSINT Services",
                    "source": "server",
                    "service_keys": [
                        "spiderfoot",
                        "searxng",
                        "gitea",
                        "joplin",
                    ],
                },
                {
                    "key": "active_investigations",
                    "label": "Active",
                    "icon": "fa-folder-open",
                    "color": "#60a5fa",
                    "source": "osint",
                    "metric": "investigations.active_count",
                    "format": "number",
                },
                {
                    "key": "authorized_targets",
                    "label": "Authorized Targets",
                    "icon": "fa-check-shield",
                    "color": "#22c55e",
                    "source": "osint",
                    "metric": "authorizations.active_count",
                    "format": "number",
                },
                {
                    "key": "total_findings",
                    "label": "Findings",
                    "icon": "fa-magnifying-glass",
                    "color": "#fbbf24",
                    "source": "osint",
                    "metric": "findings.total_count",
                    "format": "number",
                },
                {
                    "key": "running_scans",
                    "label": "Running Scans",
                    "icon": "fa-spinner",
                    "color": "#8b5cf6",
                    "source": "spiderfoot",
                    "metric": "scans.running_count",
                    "format": "number",
                },
            ],
        },
        "sections": [
            {
                "key": "investigations",
                "label": "Investigations",
                "icon": "fa-folder-open",
                "type": "pipeline",
                "source": "osint",
                "source_key": "investigations",
                "empty_message": "No investigations yet. Tell me what you want to investigate and I'll set it up!",
                "stages": ["open", "active", "review", "complete", "archived"],
                "stage_field": "status",
                "card_title_field": "name",
                "card_subtitle_field": "target_type",
                "card_badge_field": "finding_count",
            },
            {
                "key": "authorization_log",
                "label": "Authorization Log",
                "icon": "fa-check-shield",
                "type": "table",
                "source": "osint",
                "source_key": "authorizations",
                "empty_message": "No authorizations recorded yet. Before scanning any target, I'll ask you to authorize it here first — this keeps your work ethical and documented.",
                "columns": [
                    {"key": "target", "label": "Target", "type": "text", "sortable": True},
                    {
                        "key": "justification",
                        "label": "Justification",
                        "type": "text",
                        "sortable": False,
                    },
                    {"key": "scope", "label": "Scope", "type": "badge", "sortable": True},
                    {"key": "created_at", "label": "Authorized", "type": "date", "sortable": True},
                    {"key": "expires_at", "label": "Expires", "type": "date", "sortable": True},
                    {"key": "status", "label": "Status", "type": "badge", "sortable": True},
                ],
                "default_sort": "expires_at",
                "default_sort_dir": "asc",
            },
            {
                "key": "spiderfoot_scans",
                "label": "SpiderFoot Scans",
                "icon": "fa-spider",
                "type": "table",
                "source": "spiderfoot",
                "source_key": "scans",
                "empty_message": "No SpiderFoot scans yet. Open SpiderFoot to run your first scan, or tell me a target and I'll start one!",
                "service_key": "spiderfoot",
                "columns": [
                    {"key": "name", "label": "Target", "type": "text", "sortable": True},
                    {"key": "status", "label": "Status", "type": "badge", "sortable": True},
                    {
                        "key": "finding_count",
                        "label": "Findings",
                        "type": "number",
                        "sortable": True,
                    },
                    {"key": "started", "label": "Started", "type": "date", "sortable": True},
                    {"key": "finished", "label": "Finished", "type": "date", "sortable": True},
                ],
                "default_sort": "started",
                "default_sort_dir": "desc",
                "row_actions": [
                    {
                        "key": "review_findings",
                        "label": "Review",
                        "icon": "fa-magnifying-glass",
                        "mode": "agent",
                        "prompt_template": (
                            "Review the SpiderFoot scan results for {name}."
                            " What are the most significant findings?"
                            " Highlight anything that warrants further investigation."
                        ),
                    },
                ],
            },
            {
                "key": "entity_findings",
                "label": "Entity Findings",
                "icon": "fa-sitemap",
                "type": "table",
                "source": "osint",
                "source_key": "entity_findings",
                "empty_message": "No entity findings yet. As you investigate, discovered domains, IPs, and organizations will be cataloged here!",
                "columns": [
                    {"key": "entity", "label": "Entity", "type": "text", "sortable": True},
                    {"key": "type", "label": "Type", "type": "badge", "sortable": True},
                    {"key": "source", "label": "Source", "type": "text", "sortable": True},
                    {"key": "confidence", "label": "Confidence", "type": "badge", "sortable": True},
                    {"key": "found_at", "label": "Found", "type": "date", "sortable": True},
                ],
                "default_sort": "found_at",
                "default_sort_dir": "desc",
            },
        ],
        "quick_actions": [
            {
                "key": "new_investigation",
                "label": "New Investigation",
                "icon": "fa-folder-plus",
                "mode": "agent",
                "prompt": (
                    "I want to start a new OSINT investigation."
                    " What is the target (person, domain, organization, IP),"
                    " what is the purpose, and what's the scope?"
                    " I'll need to authorize this target before we begin."
                ),
            },
            {
                "key": "domain_footprint",
                "label": "Domain Footprint",
                "icon": "fa-globe",
                "mode": "agent",
                "prompt": (
                    "I want to map the digital footprint of a domain."
                    " I'll provide the domain. We'll need authorization first,"
                    " then run DNS enumeration, subdomain discovery, WHOIS, and certificate transparency."
                ),
            },
            {
                "key": "spiderfoot_scan",
                "label": "SpiderFoot Scan",
                "icon": "fa-spider",
                "mode": "agent",
                "prompt": (
                    "I want to run a SpiderFoot scan."
                    " Provide the target and I'll check authorization,"
                    " then start the scan and monitor progress."
                ),
            },
            {
                "key": "investigation_report",
                "label": "Investigation Report",
                "icon": "fa-file-lines",
                "mode": "agent",
                "prompt": (
                    "I want to write up an investigation report."
                    " Which investigation? I'll compile the findings,"
                    " source citations, confidence levels, and conclusions."
                ),
            },
        ],
    },
)

register_job_class(OSINT_RESEARCHER)
