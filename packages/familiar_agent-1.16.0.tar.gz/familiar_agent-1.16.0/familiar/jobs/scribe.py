# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""Scribe job class — records management, document intake, and cross-job routing."""

from . import JobClass, register_job_class

SCRIBE = JobClass(
    key="scribe",
    name="Scribe",
    icon="fa-pen-nib",
    description="Records management, document intake, review queue, and cross-job routing",
    prompt_fragment="""You are operating in Scribe mode — the Records Office. Your focus areas:
- **Intake pipeline**: You OWN Smart Intake. When any file arrives — photo, PDF, audio, document — you extract text, classify content, and route it to the correct job class (donations → Nonprofit Director, recipes → Chef, case notes → Social Worker, etc.).
- **Review queue**: Low-confidence classifications land in your review queue. Inspect them, correct the type if needed, and approve or reject. Every correction teaches the system through extraction templates.
- **Watch folders**: Monitor directories for new files and auto-intake them. Great for scan folders, download directories, or shared drives.
- **Web clipping**: Clip web pages into your records — articles, grant listings, resource pages. Content is extracted, classified, and routed like any other document.
- **Template learning**: When you correct a classification, offer to save the correction as an extraction template so similar documents are classified correctly next time.
- **Cross-job routing**: You serve ALL other job classes. A donation receipt goes to Nonprofit Director's donor store. A recipe goes to Chef's kitchen. A case note goes to Social Worker. You are the mailroom.
- **Audit trail**: Every intake is recorded in history. You can search, filter, and report on what's been processed.
- **Accuracy focus**: Track your classification accuracy. Review misrouted items and improve templates.""",
    skill_weights={
        "smart_intake": 1.0,
        "batch_intake": 0.9,
        "intake_history": 0.9,
        "review_intake": 1.0,
        "watch_folder": 0.9,
        "check_watches": 0.8,
        "clip_webpage": 0.8,
        "list_templates": 0.7,
        "write_note": 0.6,
        "search_notes": 0.6,
        "remember": 0.6,
        "recall": 0.6,
        "web_search": 0.5,
        "web_read": 0.5,
        "query_chairman": 0.6,
    },
    species_flavor={
        "fox": "Your fox's quick eyes catch every detail — sorting, filing, nothing escapes your notice.",
        "owl": "Your owl's meticulous nature makes you the perfect archivist — every document cataloged precisely.",
        "cat": "Your cat's curiosity drives you to investigate every document — what is it, where does it belong?",
        "dragon": "Your dragon's hoard instinct extends to information — every record treasured and protected.",
        "wolf": "Your wolf's pack loyalty means every document reaches the right teammate, every time.",
        "frog": "Your frog's keen observation catches patterns others miss — connecting documents across job classes.",
    },
    recommended_connects=[
        "email",
        "nextcloud",
        "joplin",
        "searxng",
    ],
    proactive_focus=[
        "check watch folders for new files",
        "review queue items awaiting decision",
        "classification accuracy trends",
        "remind about unprocessed inbox items",
    ],
    workspace={
        "label": "Records Office",
        "icon": "fa-pen-nib",
        "description": (
            "Your records management hub — intake documents, review classifications,"
            " manage watch folders, and track processing accuracy."
        ),
        "overview": {
            "cards": [
                {
                    "key": "server_setup_cta",
                    "type": "cta",
                    "icon": "fa-pen-nib",
                    "color": "#818cf8",
                    "label": "Records Server",
                    "message": (
                        "Set up your own document server — Nextcloud for file storage,"
                        " Joplin for notes, and SearXNG for web research."
                        " Your records stay on your machine."
                    ),
                    "button_label": "Set Up My Server",
                    "button_action": "full_server_setup",
                    "source": "server",
                    "show_when": "needs_setup",
                    "service_keys": ["nextcloud", "joplin", "searxng"],
                },
                {
                    "key": "scribe_services",
                    "type": "service_status",
                    "icon": "fa-pen-nib",
                    "color": "#818cf8",
                    "label": "Records Services",
                    "source": "server",
                    "service_keys": ["nextcloud", "joplin", "searxng"],
                },
                {
                    "key": "inbox_count",
                    "label": "Inbox",
                    "icon": "fa-inbox",
                    "color": "#60a5fa",
                    "source": "scribe",
                    "metric": "inbox_count",
                    "format": "number",
                },
                {
                    "key": "needs_review",
                    "label": "Needs Review",
                    "icon": "fa-magnifying-glass",
                    "color": "#fbbf24",
                    "source": "scribe",
                    "metric": "review_count",
                    "format": "number",
                },
                {
                    "key": "processed_today",
                    "label": "Processed Today",
                    "icon": "fa-check-circle",
                    "color": "#4ade80",
                    "source": "scribe",
                    "metric": "processed_today",
                    "format": "number",
                },
                {
                    "key": "total_processed",
                    "label": "Total Processed",
                    "icon": "fa-layer-group",
                    "color": "#818cf8",
                    "source": "scribe",
                    "metric": "total_processed",
                    "format": "number",
                },
                {
                    "key": "accuracy",
                    "label": "Accuracy",
                    "icon": "fa-bullseye",
                    "color": "#f472b6",
                    "source": "scribe",
                    "metric": "accuracy_pct",
                    "format": "percent",
                },
                {
                    "key": "watch_folders",
                    "label": "Watch Folders",
                    "icon": "fa-eye",
                    "color": "#a78bfa",
                    "source": "scribe",
                    "metric": "watch_count",
                    "format": "number",
                },
            ],
        },
        "sections": [
            {
                "key": "inbox",
                "label": "Inbox",
                "icon": "fa-inbox",
                "type": "table",
                "source": "scribe",
                "source_key": "inbox_entries",
                "empty_message": (
                    "No documents in the inbox. Drop files here, set up a watch folder,"
                    " or clip a web page to get started!"
                ),
                "columns": [
                    {"key": "timestamp", "label": "Date", "type": "date", "sortable": True},
                    {"key": "source_file", "label": "File", "type": "text", "sortable": True},
                    {"key": "content_type", "label": "Type", "type": "badge", "sortable": True},
                    {"key": "confidence", "label": "Confidence", "type": "text", "sortable": True},
                    {"key": "destination", "label": "Routed To", "type": "text", "sortable": True},
                    {"key": "summary", "label": "Summary", "type": "text", "sortable": False},
                ],
                "default_sort": "timestamp",
                "default_sort_dir": "desc",
            },
            {
                "key": "recent_scans",
                "label": "Recent Scans",
                "icon": "fa-clock-rotate-left",
                "type": "table",
                "source": "scribe",
                "source_key": "recent_entries",
                "empty_message": "No scans yet. Use Smart Intake to process your first document!",
                "columns": [
                    {"key": "timestamp", "label": "Date", "type": "date", "sortable": True},
                    {"key": "source_file", "label": "File", "type": "text", "sortable": True},
                    {"key": "content_type", "label": "Type", "type": "badge", "sortable": True},
                    {"key": "method", "label": "Method", "type": "text", "sortable": True},
                    {"key": "success", "label": "Status", "type": "badge", "sortable": True},
                ],
                "default_sort": "timestamp",
                "default_sort_dir": "desc",
            },
            {
                "key": "review_queue",
                "label": "Review Queue",
                "icon": "fa-magnifying-glass",
                "type": "table",
                "source": "scribe",
                "source_key": "review_items",
                "empty_message": "No items need review. The system is handling classifications well!",
                "columns": [
                    {"key": "timestamp", "label": "Date", "type": "date", "sortable": True},
                    {"key": "source_file", "label": "File", "type": "text", "sortable": True},
                    {
                        "key": "suggested_type",
                        "label": "Suggested Type",
                        "type": "badge",
                        "sortable": True,
                    },
                    {"key": "confidence", "label": "Confidence", "type": "text", "sortable": True},
                    {"key": "text_preview", "label": "Preview", "type": "text", "sortable": False},
                ],
                "default_sort": "timestamp",
                "default_sort_dir": "desc",
                "row_actions": [
                    {
                        "key": "approve",
                        "label": "Approve",
                        "icon": "fa-check",
                        "mode": "agent",
                        "prompt_template": (
                            "Approve review item for {source_file} with suggested type"
                            " {suggested_type}."
                        ),
                    },
                    {
                        "key": "reject",
                        "label": "Reject",
                        "icon": "fa-xmark",
                        "mode": "agent",
                        "prompt_template": "Reject review item for {source_file}.",
                    },
                ],
            },
            {
                "key": "search",
                "label": "Search",
                "icon": "fa-search",
                "type": "table",
                "source": "scribe",
                "source_key": "search_results",
                "empty_message": "Search intake history by content type, file name, or date.",
                "columns": [
                    {"key": "timestamp", "label": "Date", "type": "date", "sortable": True},
                    {"key": "source_file", "label": "File", "type": "text", "sortable": True},
                    {"key": "content_type", "label": "Type", "type": "badge", "sortable": True},
                    {
                        "key": "destination",
                        "label": "Destination",
                        "type": "text",
                        "sortable": True,
                    },
                ],
                "default_sort": "timestamp",
                "default_sort_dir": "desc",
            },
            {
                "key": "transcriptions",
                "label": "Transcriptions",
                "icon": "fa-microphone",
                "type": "table",
                "source": "scribe",
                "source_key": "transcription_entries",
                "empty_message": "No audio transcriptions yet. Process audio files to see them here!",
                "columns": [
                    {"key": "timestamp", "label": "Date", "type": "date", "sortable": True},
                    {"key": "source_file", "label": "Audio File", "type": "text", "sortable": True},
                    {"key": "summary", "label": "Summary", "type": "text", "sortable": False},
                    {"key": "destination", "label": "Routed To", "type": "text", "sortable": True},
                ],
                "default_sort": "timestamp",
                "default_sort_dir": "desc",
            },
            {
                "key": "statistics",
                "label": "Statistics",
                "icon": "fa-chart-bar",
                "type": "table",
                "source": "scribe",
                "source_key": "stats_breakdown",
                "empty_message": "No statistics available yet. Process some documents to see trends!",
                "columns": [
                    {
                        "key": "content_type",
                        "label": "Content Type",
                        "type": "text",
                        "sortable": True,
                    },
                    {"key": "count", "label": "Count", "type": "text", "sortable": True},
                    {
                        "key": "success_rate",
                        "label": "Success Rate",
                        "type": "text",
                        "sortable": True,
                    },
                ],
                "default_sort": "count",
                "default_sort_dir": "desc",
            },
        ],
        "quick_actions": [
            {
                "key": "scan_document",
                "label": "Scan Document",
                "icon": "fa-file-import",
                "mode": "agent",
                "prompt": "I want to scan a document. What file should I process?",
            },
            {
                "key": "batch_scan",
                "label": "Batch Scan",
                "icon": "fa-folder-open",
                "mode": "agent",
                "prompt": "I want to batch process a folder of documents. Which directory?",
            },
            {
                "key": "review_queue",
                "label": "Review Queue",
                "icon": "fa-magnifying-glass",
                "mode": "agent",
                "prompt": "Show me items in the review queue that need my attention.",
            },
            {
                "key": "add_watch",
                "label": "Watch Folder",
                "icon": "fa-eye",
                "mode": "agent",
                "prompt": "I want to set up a watch folder. Which directory should I monitor?",
            },
            {
                "key": "clip_page",
                "label": "Clip Web Page",
                "icon": "fa-scissors",
                "mode": "agent",
                "prompt": "I want to clip a web page. What URL should I save?",
            },
            {
                "key": "intake_stats",
                "label": "Statistics",
                "icon": "fa-chart-bar",
                "mode": "agent",
                "prompt": "Show me intake statistics — how many documents processed, accuracy rate, breakdown by type.",
            },
        ],
    },
)

register_job_class(SCRIBE)
