# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Centralized default constants for the agent core.

Values that were previously hardcoded across agent.py, prompt_builder.py,
provider_manager.py, and tool_executor.py. Collected here so they can be
found, reviewed, and overridden in one place.

All values are module-level constants (not a dataclass) to keep imports
lightweight — no instantiation required.
"""

# ── Tool Router ───────────────────────────────────────────────────────────────
ROUTER_MAX_TOOLS_LOCAL = 6
ROUTER_MAX_TOOLS_CLOUD = 15
ROUTER_FALLBACK_COUNT_LOCAL = 10
ROUTER_FALLBACK_COUNT_CLOUD = 20
ROUTER_CONFIDENCE_THRESHOLD = 0.10
ROUTER_MIN_ROUTING_CONFIDENCE = 0.15

# ── RAG Retriever ─────────────────────────────────────────────────────────────
RAG_TOP_K = 5
RAG_MIN_SCORE = 0.05
RAG_MAX_TOKENS = 1500
RAG_CHUNK_SIZE = 400
RAG_CHUNK_OVERLAP = 40

# ── Mesh ──────────────────────────────────────────────────────────────────────
MESH_CONTEXT_TIMEOUT = 1.5
MESH_DEFAULT_HOST = "127.0.0.1"
MESH_DEFAULT_PORT = 18789

# ── Health Checker ────────────────────────────────────────────────────────────
HEALTH_CHECK_TIMEOUT = 5.0
HEALTH_CACHE_TTL = 10.0
BACKUP_STALE_MULTIPLIER = 2  # stale threshold = retention_days × this

# ── Episodic Memory ──────────────────────────────────────────────────────────
EPISODIC_TOP_K = 5
EPISODIC_MIN_STRENGTH = 0.1
EPISODIC_DEFAULT_MAX_TOKENS = 400

# ── Prompt Builder ────────────────────────────────────────────────────────────
MARKDOWN_MEMORY_CHAR_BUDGET = 800
MEMORY_TREE_DEFAULT_MAX_TOKENS = 600

# ── SkillBus ──────────────────────────────────────────────────────────────────
SKILLBUS_DLQ_SIZE = 1000

# ── Structured Generator ─────────────────────────────────────────────────────
STRUCTURED_MAX_RETRIES = 3

# ── Provider Manager (Ollama) ─────────────────────────────────────────────────
OLLAMA_HEALTH_TIMEOUT = 2
OLLAMA_TAG_TIMEOUT = 1
OLLAMA_API_TIMEOUT = 3

# ── Compliance ────────────────────────────────────────────────────────────────
DEFAULT_RETENTION_DAYS = 365
