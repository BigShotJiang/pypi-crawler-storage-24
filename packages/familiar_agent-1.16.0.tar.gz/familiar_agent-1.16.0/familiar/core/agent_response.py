"""Structured response types for agent chat_with_results()."""

from dataclasses import dataclass, field


@dataclass
class ToolResult:
    """A single tool execution result."""

    tool_name: str
    tool_input: dict
    output: str
    tool_use_id: str = ""


@dataclass
class AgentResponse:
    """Structured response from agent.chat_with_results()."""

    text: str
    tool_results: list = field(default_factory=list)

    @property
    def has_tool_results(self) -> bool:
        return len(self.tool_results) > 0

    def get_results_by_tool(self, tool_name: str) -> list:
        return [r for r in self.tool_results if r.tool_name == tool_name]
