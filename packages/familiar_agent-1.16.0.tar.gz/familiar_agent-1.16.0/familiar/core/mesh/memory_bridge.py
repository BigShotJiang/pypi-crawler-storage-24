# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Licensed under the MIT License

"""
Mesh Memory Bridge — Phase 3 (v2.7.2)

Enables opt-in memory sharing across trusted mesh peers.
Rides on the existing SkillBus (core/bus.py) pub/sub system and
the existing Memory class (core/memory.py) semantic search.

Design principles:
  - Memories are PRIVATE by default. User must explicitly share.
  - Queries sent as TEXT, not vectors (embedding compatibility).
  - Each peer runs their own embedding provider for local search.
  - Results tagged with origin node for transparency.
  - 2-second timeout on mesh searches (never block conversation).
  - HIPAA tenants: memory sharing disabled entirely.

Event topics (only mesh.* topics forwarded across gateways):
  mesh.memory.query         — incoming query from a peer
  mesh.memory.query_response — results sent back to querying peer
  mesh.memory.push          — peer pushing a shared memory to us
  mesh.memory.revoke        — peer revoking a previously shared memory

Integration:
  Called from agent.py when building context. Agent calls
  bridge.search_mesh() which fans out to trusted peers and
  merges results with local context.
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

MESH_MEMORY_QUERY = "mesh.memory.query"
MESH_MEMORY_RESPONSE = "mesh.memory.query_response"
MESH_MEMORY_PUSH = "mesh.memory.push"
MESH_MEMORY_REVOKE = "mesh.memory.revoke"

# Markdown memory sharing
MESH_MARKDOWN_PUSH = "mesh.markdown.push"
MESH_MARKDOWN_LIST = "mesh.markdown.list"
MESH_MARKDOWN_LIST_RESPONSE = "mesh.markdown.list_response"
MESH_MARKDOWN_REQUEST = "mesh.markdown.request"
MESH_MARKDOWN_RESPONSE = "mesh.markdown.response"

# Usage recording
MESH_USAGE_RECORD = "mesh.usage.record"

# Default timeout for mesh memory searches (seconds)
MESH_SEARCH_TIMEOUT = 2.0
# Maximum results per peer
MAX_RESULTS_PER_PEER = 5


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


# ============================================================
# SHARED MEMORY METADATA
# ============================================================


@dataclass
class SharedMemoryMeta:
    """
    Metadata tracking which memories are shared and with whom.
    Stored alongside normal memories in a separate sidecar file.
    """

    key: str
    shareable: bool = False
    share_scope: str = "all"  # "all" or comma-separated node_ids
    mesh_origin: Optional[str] = None  # node_id if received from a peer
    mesh_origin_name: Optional[str] = None  # display name of origin node
    mesh_origin_genesis_hash: Optional[str] = None  # genesis hash of origin
    mesh_ttl: int = 3600  # seconds before cache expires
    shared_at: Optional[str] = None
    received_at: Optional[str] = None

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "SharedMemoryMeta":
        known = {f.name for f in cls.__dataclass_fields__.values()}
        return cls(**{k: v for k, v in d.items() if k in known})

    def is_shared_with(self, node_id: str) -> bool:
        """Check if this memory is shared with a specific node."""
        if not self.shareable:
            return False
        if self.share_scope == "all":
            return True
        return node_id in self.share_scope.split(",")


# ============================================================
# SHARED MEMORY STORE — sidecar for Memory
# ============================================================

import json  # noqa: E402


class SharedMemoryStore:
    """
    Sidecar store tracking which memories are shared.
    Stored in MESH_DIR/shared_memories.json.
    Does NOT store the memories themselves — those stay in Memory.
    """

    def __init__(self, storage_path: Path):
        self._path = storage_path / "shared_memories.json"
        self._lock = threading.Lock()
        self._meta: Dict[str, SharedMemoryMeta] = {}
        self._load()

    def _load(self):
        if self._path.exists():
            try:
                data = json.loads(self._path.read_text())
                for entry in data.get("shared", []):
                    meta = SharedMemoryMeta.from_dict(entry)
                    self._meta[meta.key] = meta
            except (json.JSONDecodeError, IOError, OSError) as e:
                logger.warning(f"Failed to load shared memory store: {e}")

    def _save(self):
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            data = {"shared": [m.to_dict() for m in self._meta.values()]}
            self._path.write_text(json.dumps(data, indent=2))
        except (IOError, OSError) as e:
            logger.warning(f"Failed to save shared memory store: {e}")

    def share(self, key: str, scope: str = "all") -> SharedMemoryMeta:
        """Mark a memory as shareable."""
        with self._lock:
            meta = self._meta.get(key, SharedMemoryMeta(key=key))
            meta.shareable = True
            meta.share_scope = scope
            meta.shared_at = _utcnow().isoformat()
            self._meta[key] = meta
            self._save()
            return meta

    def unshare(self, key: str) -> bool:
        """Remove sharing from a memory."""
        with self._lock:
            if key in self._meta:
                self._meta[key].shareable = False
                self._save()
                return True
            return False

    def store_received(
        self, key: str, origin_id: str, origin_name: str, ttl: int = 3600
    ) -> SharedMemoryMeta:
        """Track a memory received from a peer."""
        with self._lock:
            meta = SharedMemoryMeta(
                key=key,
                shareable=False,  # Received memories not re-shared by default
                mesh_origin=origin_id,
                mesh_origin_name=origin_name,
                mesh_ttl=ttl,
                received_at=_utcnow().isoformat(),
            )
            self._meta[key] = meta
            self._save()
            return meta

    def get(self, key: str) -> Optional[SharedMemoryMeta]:
        with self._lock:
            return self._meta.get(key)

    def get_shareable_keys(self, for_node: Optional[str] = None) -> List[str]:
        """Get keys of all shareable memories, optionally filtered by node."""
        with self._lock:
            keys = []
            for key, meta in self._meta.items():
                if meta.shareable:
                    if for_node is None or meta.is_shared_with(for_node):
                        keys.append(key)
            return keys

    def get_received_keys(self) -> List[str]:
        """Get keys of memories received from peers."""
        with self._lock:
            return [k for k, m in self._meta.items() if m.mesh_origin]

    def remove(self, key: str) -> bool:
        with self._lock:
            if key in self._meta:
                del self._meta[key]
                self._save()
                return True
            return False

    def count_shared(self) -> int:
        with self._lock:
            return len([m for m in self._meta.values() if m.shareable])

    def count_received(self) -> int:
        with self._lock:
            return len([m for m in self._meta.values() if m.mesh_origin])


# ============================================================
# MESH SEARCH RESULT
# ============================================================


@dataclass
class MeshMemoryResult:
    """A single memory result from a mesh peer."""

    key: str
    value: str
    category: str
    importance: int
    origin_node_id: str
    origin_node_name: str
    relevance_score: float = 0.0

    @property
    def tagged_value(self) -> str:
        """Value with origin tag for context injection."""
        return f"[{self.origin_node_name}] {self.value}"

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "MeshMemoryResult":
        known = {f.name for f in cls.__dataclass_fields__.values()}
        return cls(**{k: v for k, v in d.items() if k in known})


# ============================================================
# MEMORY BRIDGE — the main class
# ============================================================


class MemoryBridge:
    """
    Bridges local Memory with mesh peers for shared context.

    Handles:
      - Publishing shareable memories in response to peer queries
      - Querying peers for context relevant to the current conversation
      - Receiving pushed memories from peers
      - Revoking shared memories

    Usage:
        bridge = MemoryBridge(
            memory=agent.memory,
            node_id="local_123",
            node_name="Kitchen Pi",
            mesh_dir=MESH_DIR,
        )

        # Wire into bus
        bridge.register_bus_handlers(skill_bus)

        # In agent context building:
        mesh_results = bridge.search_mesh(
            "What dietary restrictions?",
            peer_ids=["peer_abc"],
            timeout=2.0,
        )
    """

    def __init__(
        self,
        memory: Any,  # Memory instance
        node_id: str,
        node_name: str,
        mesh_dir: Optional[Path] = None,
        trust_manager: Any = None,  # MeshTrustManager
        hipaa_enabled: bool = False,
    ):
        self.memory = memory
        self.node_id = node_id
        self.node_name = node_name
        self.trust_manager = trust_manager
        self.hipaa_enabled = hipaa_enabled

        if mesh_dir is None:
            mesh_dir = Path.home() / ".familiar" / "data" / "mesh"
        self.shared_store = SharedMemoryStore(mesh_dir)

        # Pending query responses (query_id -> list of results)
        self._pending_responses: Dict[str, List[MeshMemoryResult]] = {}
        self._response_events: Dict[str, threading.Event] = {}
        self._lock = threading.Lock()

        # Gateway reference (set by MeshGateway after init)
        self._gateway = None

        # Markdown memory store (set via init_markdown_store)
        self._markdown_store = None

        # Usage tracker (set via set_usage_tracker, Phase 3)
        self._usage_tracker = None

        # MemoryTree reference (set via init_memory_tree, Sprint 11)
        self._memory_tree = None

        # Pending markdown responses
        self._markdown_pending: Dict[str, Any] = {}
        self._markdown_events: Dict[str, threading.Event] = {}

        # Thread pool for parallel peer queries
        self._executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="mesh_mem")

        if hipaa_enabled:
            logger.info("HIPAA mode: memory sharing disabled")

    def set_gateway(self, gateway):
        """Set reference to MeshGateway for sending messages."""
        self._gateway = gateway

    # ── Sharing commands ──

    def share_memory(self, key: str, scope: str = "all") -> bool:
        """
        Mark a local memory as shareable with mesh peers.

        Args:
            key: Memory key to share
            scope: "all" for all trusted peers, or comma-separated node_ids
        """
        if self.hipaa_enabled:
            logger.warning("Cannot share memories in HIPAA mode")
            return False

        if key not in self.memory.memories:
            logger.warning(f"Memory key '{key}' not found")
            return False

        self.shared_store.share(key, scope)
        logger.info(f"Memory shared: '{key}' (scope={scope})")
        return True

    def unshare_memory(self, key: str) -> bool:
        """Remove sharing from a memory and notify peers."""
        result = self.shared_store.unshare(key)
        if result:
            logger.info(f"Memory unshared: '{key}'")
            # Broadcast revocation to peers
            self._broadcast_revocation(key)
        return result

    def get_shared_keys(self) -> List[str]:
        """Get all shared memory keys."""
        return self.shared_store.get_shareable_keys()

    # ── Query handling (responding to peer queries) ──

    def handle_remote_query(self, message: dict) -> Optional[dict]:
        """
        Handle an incoming memory query from a peer.
        Called when a mesh.memory.query event arrives.

        Args:
            message: {query_text, requesting_node, query_id, max_results}

        Returns:
            Response dict with results, or None if denied
        """
        if self.hipaa_enabled:
            return None

        requesting_node = message.get("requesting_node", "")

        # Check permission
        if self.trust_manager and not self.trust_manager.check_permission(
            requesting_node, "request_memory"
        ):
            logger.debug(f"Memory query denied for {requesting_node}: no request_memory permission")
            return None

        query_text = message.get("query_text", "")
        max_results = min(message.get("max_results", MAX_RESULTS_PER_PEER), MAX_RESULTS_PER_PEER)
        query_id = message.get("query_id", "")

        # Search only shareable memories
        shareable_keys = set(self.shared_store.get_shareable_keys(for_node=requesting_node))
        if not shareable_keys:
            return {
                "query_id": query_id,
                "results": [],
                "origin_node": self.node_id,
                "origin_name": self.node_name,
            }

        # Run local search
        all_results = self.memory.search(query_text, max_results=max_results * 2)

        # Filter to only shareable
        filtered = [r for r in all_results if r.key in shareable_keys][:max_results]

        results = [
            {
                "key": r.key,
                "value": r.value,
                "category": r.category,
                "importance": r.importance,
            }
            for r in filtered
        ]

        return {
            "query_id": query_id,
            "results": results,
            "origin_node": self.node_id,
            "origin_name": self.node_name,
        }

    def handle_remote_response(self, message: dict):
        """
        Handle a query response from a peer.
        Called when a mesh.memory.query_response arrives.
        """
        query_id = message.get("query_id", "")
        origin_node = message.get("origin_node", "")
        origin_name = message.get("origin_name", origin_node)

        results = []
        for r in message.get("results", []):
            results.append(
                MeshMemoryResult(
                    key=r.get("key", ""),
                    value=r.get("value", ""),
                    category=r.get("category", "fact"),
                    importance=r.get("importance", 5),
                    origin_node_id=origin_node,
                    origin_node_name=origin_name,
                )
            )

        with self._lock:
            if query_id in self._pending_responses:
                self._pending_responses[query_id].extend(results)
                event = self._response_events.get(query_id)
                if event:
                    event.set()

    def handle_remote_push(self, message: dict):
        """Handle a peer pushing a shared memory to us."""
        if self.hipaa_enabled:
            return

        origin_node = message.get("origin_node", "")

        # Check permission
        if self.trust_manager and not self.trust_manager.check_permission(
            origin_node, "request_memory"
        ):
            return

        key = message.get("key", "")
        value = message.get("value", "")
        category = message.get("category", "fact")
        origin_name = message.get("origin_name", origin_node)
        ttl = message.get("ttl", 3600)

        if not key or not value:
            return

        # Store as a received memory with mesh origin tag
        mesh_key = f"mesh:{origin_node[:8]}:{key}"
        self.memory.remember(
            mesh_key,
            value,
            category=category,
            source=f"mesh:{origin_name}",
            importance=3,  # Mesh memories start at lower importance
        )
        self.shared_store.store_received(mesh_key, origin_node, origin_name, ttl)
        logger.debug(f"Received memory from {origin_name}: {key}")

    def handle_remote_revoke(self, message: dict):
        """Handle a peer revoking a previously shared memory."""
        origin_node = message.get("origin_node", "")
        key = message.get("key", "")
        mesh_key = f"mesh:{origin_node[:8]}:{key}"

        if mesh_key in self.memory.memories:
            self.memory.forget(mesh_key)
            self.shared_store.remove(mesh_key)
            logger.debug(f"Revoked mesh memory: {mesh_key}")

    # ── Outgoing queries ──

    def search_mesh(
        self,
        query: str,
        peer_ids: Optional[List[str]] = None,
        max_results: int = MAX_RESULTS_PER_PEER,
        timeout: float = MESH_SEARCH_TIMEOUT,
    ) -> List[MeshMemoryResult]:
        """
        Search memories across mesh peers.

        Sends query to all trusted peers (or specific peer_ids),
        waits up to timeout seconds, merges results.

        Args:
            query: Natural language query
            peer_ids: Specific peers to query (None = all trusted)
            max_results: Max total results
            timeout: Seconds to wait (default 2.0)

        Returns:
            List of MeshMemoryResult sorted by importance
        """
        if self.hipaa_enabled:
            return []

        if not self._gateway:
            return []

        # Determine target peers
        targets = peer_ids or self._get_queryable_peers()
        if not targets:
            return []

        # Create query with unique ID
        query_id = hashlib.sha256(f"{query}:{time.time()}:{self.node_id}".encode()).hexdigest()[:16]

        # Set up response collection
        with self._lock:
            self._pending_responses[query_id] = []
            self._response_events[query_id] = threading.Event()

        # Send query to each peer
        query_msg = {
            "query_text": query,
            "requesting_node": self.node_id,
            "query_id": query_id,
            "max_results": max_results,
        }

        for peer_id in targets:
            try:
                self._send_to_peer(peer_id, MESH_MEMORY_QUERY, query_msg)
            except Exception as e:
                logger.debug(f"Failed to send query to {peer_id}: {e}")

        # Wait for responses (up to timeout)
        event = self._response_events[query_id]
        event.wait(timeout=timeout)

        # Small grace period for additional responses
        time.sleep(min(0.1, timeout * 0.05))

        # Collect and clean up
        with self._lock:
            results = self._pending_responses.pop(query_id, [])
            self._response_events.pop(query_id, None)

        # Sort by importance and deduplicate
        seen_values = set()
        deduped = []
        for r in sorted(results, key=lambda x: x.importance, reverse=True):
            if r.value not in seen_values:
                seen_values.add(r.value)
                deduped.append(r)

        return deduped[:max_results]

    def get_mesh_context(
        self,
        query: str,
        timeout: float = MESH_SEARCH_TIMEOUT,
    ) -> str:
        """
        Get mesh memory context formatted for LLM prompt injection.

        Returns a string like:
            ## Mesh Context
            - [Kitchen Pi] User is gluten-free
            - [Office Desktop] User prefers dark roast coffee
        """
        results = self.search_mesh(query, timeout=timeout)
        if not results:
            return ""

        # Record usage for Dross tracking
        if results and self._usage_tracker:
            for origin_id in {r.origin_node_id for r in results}:
                self._usage_tracker.record_usage(
                    provider_node=origin_id,
                    consumer_node=self.node_id,
                    resource_type="memory_query",
                    resource_id=query[:64],
                    count=len([r for r in results if r.origin_node_id == origin_id]),
                )

        lines = ["<mesh_context>"]
        for r in results:
            lines.append(f"- {r.tagged_value}")
        lines.append("</mesh_context>")

        return "\n".join(lines)

    # ── Markdown memory sharing ──

    def init_markdown_store(self, markdown_store):
        """Set the markdown memory store for push/pull/list operations."""
        self._markdown_store = markdown_store

    def set_usage_tracker(self, tracker):
        """Set the usage tracker for Dross integration."""
        self._usage_tracker = tracker

    def init_memory_tree(self, tree=None):
        """Set the MemoryTree for mesh sharing (Sprint 11).

        If tree is None, tries to get the singleton.
        """
        if tree is not None:
            self._memory_tree = tree
        else:
            try:
                from familiar.core.memory_tree import get_memory_tree

                self._memory_tree = get_memory_tree()
            except Exception:
                pass

    def share_tree_memory(self, memory_id: str, peer_ids=None) -> int:
        """Push a MemoryTree entry to mesh peers.

        Returns count of peers notified.
        """
        if self.hipaa_enabled or not self._memory_tree:
            return 0

        entry = self._memory_tree.get(memory_id)
        if not entry or not entry.is_valid():
            return 0

        payload = {
            "memory_id": entry.memory_id,
            "title": entry.title,
            "body": entry.body,
            "tier": entry.tier,
            "tags": entry.tags,
            "importance": entry.importance,
            "source": f"mesh:{self.node_id}",
        }

        count = 0
        target_peers = self._get_share_peers(peer_ids)
        for pid in target_peers:
            try:
                if self._gateway:
                    self._gateway.send_to_peer(pid, "mesh.tree.push", payload)
                    count += 1
            except Exception as e:
                logger.debug("Failed to push tree memory to %s: %s", pid, e)

        return count

    def handle_tree_push(self, data: dict, sender_id: str) -> bool:
        """Handle incoming MemoryTree entry from a peer.

        Creates a local long-tier entry with mesh provenance.
        Returns True if stored.
        """
        if self.hipaa_enabled or not self._memory_tree:
            return False

        title = data.get("title", "")
        body = data.get("body", "")
        if not title:
            return False

        # Check permission
        if self.trust_manager:
            if not self.trust_manager.check_permission(sender_id, "share_markdown_memories"):
                logger.warning("Peer %s not permitted to share memories", sender_id)
                return False

        # Deduplicate
        existing = self._memory_tree.find_duplicate(title, body)
        if existing:
            return False

        tags = data.get("tags", [])
        if "mesh" not in tags:
            tags.append("mesh")
        tags.append(f"from:{sender_id[:8]}")

        self._memory_tree.store(
            title=title,
            body=body,
            tier="long",
            tags=tags,
            importance=data.get("importance", 0.3),
            source=data.get("source", f"mesh:{sender_id}"),
        )

        if self._usage_tracker:
            try:
                self._usage_tracker.record(
                    peer_id=sender_id,
                    resource_type="memory",
                    resource_id=data.get("memory_id", ""),
                    action="tree_push_received",
                )
            except Exception:
                pass

        return True

    def search_tree(self, query: str, limit: int = 5) -> list:
        """Search MemoryTree for mesh context building.

        Returns list of dicts with title, body, tier, tags.
        """
        if not self._memory_tree:
            return []

        results = self._memory_tree.search(query, limit=limit)
        return [
            {
                "title": e.title,
                "body": e.body[:200],
                "tier": e.tier,
                "tags": e.tags,
                "importance": e.importance,
            }
            for e in results
        ]

    def _get_share_peers(self, peer_ids=None) -> list:
        """Get peers eligible for memory sharing."""
        if peer_ids:
            return peer_ids
        if not self.trust_manager:
            return []
        try:
            return [
                p.peer_id
                for p in self.trust_manager.list_peers()
                if self.trust_manager.check_permission(p.peer_id, "share_markdown_memories")
            ]
        except Exception:
            return []

    def push_markdown_memory(self, topic: str, peer_ids=None) -> int:
        """
        Push a markdown memory topic to peers.

        Args:
            topic: The markdown topic slug to push
            peer_ids: Specific peers (None = all with share_markdown_memories)

        Returns:
            Number of peers the memory was sent to
        """
        if self.hipaa_enabled or not self._markdown_store:
            return 0

        content = self._markdown_store.read_topic(topic)
        if content is None:
            logger.warning(f"Markdown topic not found: {topic}")
            return 0

        # Get genesis hash for provenance
        genesis_hash = ""
        try:
            from ...skills.training.bridge import get_chain_status

            status = get_chain_status()
            if status.get("initialized"):
                genesis_hash = status.get("genesis_hash", "")
        except Exception:
            pass

        content_hash = hashlib.sha256(content.encode()).hexdigest()
        tags = (
            self._markdown_store.get_tags(topic)
            if hasattr(self._markdown_store, "get_tags")
            else []
        )
        revision = (
            self._markdown_store.get_revision(topic)
            if hasattr(self._markdown_store, "get_revision")
            else 1
        )

        payload = {
            "origin_node": self.node_id,
            "origin_name": self.node_name,
            "origin_genesis_hash": genesis_hash,
            "topic": topic,
            "content": content,
            "content_hash": content_hash,
            "tags": tags if isinstance(tags, list) else [],
            "revision": revision if isinstance(revision, int) else 1,
            "provenance": {"genesis_hash": genesis_hash, "pushed_at": _utcnow().isoformat()},
        }

        targets = peer_ids or self._get_markdown_peers()
        sent = 0
        for peer_id in targets:
            try:
                self._send_to_peer(peer_id, MESH_MARKDOWN_PUSH, payload)
                sent += 1
            except Exception as e:
                logger.debug(f"Failed to push markdown to {peer_id}: {e}")

        return sent

    def handle_markdown_push(self, message: dict):
        """Handle a peer pushing a markdown memory to us."""
        if self.hipaa_enabled or not self._markdown_store:
            return

        origin_node = message.get("origin_node", "")
        if self.trust_manager and not self.trust_manager.check_permission(
            origin_node, "share_markdown_memories"
        ):
            logger.debug(f"Markdown push denied for {origin_node}: no permission")
            return

        topic = message.get("topic", "")
        content = message.get("content", "")
        origin_name = message.get("origin_name", origin_node)
        origin_genesis_hash = message.get("origin_genesis_hash", "")
        content_hash = message.get("content_hash", "")

        if not topic or not content:
            return

        # Verify content integrity
        computed = hashlib.sha256(content.encode()).hexdigest()
        if content_hash and computed != content_hash:
            logger.warning(f"Content hash mismatch for markdown push from {origin_name}")
            return

        # Store with mesh prefix
        mesh_topic = f"mesh:{origin_node[:8]}:{topic}"
        if hasattr(self._markdown_store, "write_topic"):
            self._markdown_store.write_topic(
                mesh_topic,
                content,
                origin=origin_node,
                origin_name=origin_name,
                origin_genesis_hash=origin_genesis_hash,
            )
        logger.debug(f"Received markdown from {origin_name}: {topic}")

    def handle_markdown_list(self, message: dict) -> Optional[dict]:
        """Handle a peer requesting our markdown topic list."""
        if self.hipaa_enabled or not self._markdown_store:
            return None

        requesting_node = message.get("requesting_node", "")
        if self.trust_manager and not self.trust_manager.check_permission(
            requesting_node, "share_markdown_memories"
        ):
            return None

        query_id = message.get("query_id", "")

        # Get genesis hash
        genesis_hash = ""
        try:
            from ...skills.training.bridge import get_chain_status

            status = get_chain_status()
            if status.get("initialized"):
                genesis_hash = status.get("genesis_hash", "")
        except Exception:
            pass

        topics = []
        if hasattr(self._markdown_store, "list_topics"):
            for t_info in self._markdown_store.list_topics():
                t_name = t_info["topic"] if isinstance(t_info, dict) else t_info
                entry = {
                    "topic": t_name,
                    "tags": t_info.get("tags", []) if isinstance(t_info, dict) else [],
                    "revision": t_info.get("revision", 1) if isinstance(t_info, dict) else 1,
                    "content_hash": "",
                }
                if hasattr(self._markdown_store, "read_topic"):
                    c = self._markdown_store.read_topic(t_name)
                    if c:
                        entry["content_hash"] = hashlib.sha256(c.encode()).hexdigest()
                topics.append(entry)

        return {
            "query_id": query_id,
            "origin_node": self.node_id,
            "origin_name": self.node_name,
            "origin_genesis_hash": genesis_hash,
            "topics": topics,
        }

    def handle_markdown_list_response(self, message: dict):
        """Handle a peer's response to our topic list request."""
        query_id = message.get("query_id", "")
        with self._lock:
            if query_id in self._markdown_pending:
                self._markdown_pending[query_id] = message
                event = self._markdown_events.get(query_id)
                if event:
                    event.set()

    def handle_markdown_request(self, message: dict) -> Optional[dict]:
        """Handle a peer requesting a specific markdown topic."""
        if self.hipaa_enabled or not self._markdown_store:
            return None

        requesting_node = message.get("requesting_node", "")
        if self.trust_manager and not self.trust_manager.check_permission(
            requesting_node, "share_markdown_memories"
        ):
            return None

        query_id = message.get("query_id", "")
        topic = message.get("topic", "")

        if not topic:
            return None

        content = None
        if hasattr(self._markdown_store, "read_topic"):
            content = self._markdown_store.read_topic(topic)
        if content is None:
            return None

        genesis_hash = ""
        try:
            from ...skills.training.bridge import get_chain_status

            status = get_chain_status()
            if status.get("initialized"):
                genesis_hash = status.get("genesis_hash", "")
        except Exception:
            pass

        content_hash = hashlib.sha256(content.encode()).hexdigest()
        tags = (
            self._markdown_store.get_tags(topic)
            if hasattr(self._markdown_store, "get_tags")
            else []
        )
        revision = (
            self._markdown_store.get_revision(topic)
            if hasattr(self._markdown_store, "get_revision")
            else 1
        )

        return {
            "query_id": query_id,
            "origin_node": self.node_id,
            "origin_name": self.node_name,
            "origin_genesis_hash": genesis_hash,
            "topic": topic,
            "content": content,
            "content_hash": content_hash,
            "tags": tags if isinstance(tags, list) else [],
            "revision": revision if isinstance(revision, int) else 1,
            "provenance": {"genesis_hash": genesis_hash},
        }

    def handle_markdown_response(self, message: dict):
        """Handle a peer's response to our markdown topic request."""
        query_id = message.get("query_id", "")
        with self._lock:
            if query_id in self._markdown_pending:
                self._markdown_pending[query_id] = message
                event = self._markdown_events.get(query_id)
                if event:
                    event.set()

        # Record usage if tracker available
        if self._usage_tracker:
            origin_node = message.get("origin_node", "")
            topic = message.get("topic", "")
            if origin_node and topic:
                self._usage_tracker.record_usage(
                    provider_node=origin_node,
                    consumer_node=self.node_id,
                    resource_type="markdown_pull",
                    resource_id=topic,
                )

    def list_peer_markdown_topics(self, peer_id: str, timeout: float = 2.0) -> list:
        """
        Request a list of markdown topics from a peer.

        Returns list of topic dicts: [{topic, tags, revision, content_hash}]
        """
        if self.hipaa_enabled or not self._gateway:
            return []

        query_id = hashlib.sha256(
            f"mdlist:{peer_id}:{time.time()}:{self.node_id}".encode()
        ).hexdigest()[:16]

        with self._lock:
            self._markdown_pending[query_id] = None
            self._markdown_events[query_id] = threading.Event()

        self._send_to_peer(
            peer_id,
            MESH_MARKDOWN_LIST,
            {
                "requesting_node": self.node_id,
                "query_id": query_id,
            },
        )

        event = self._markdown_events[query_id]
        event.wait(timeout=timeout)

        with self._lock:
            result = self._markdown_pending.pop(query_id, None)
            self._markdown_events.pop(query_id, None)

        if result and isinstance(result, dict):
            return result.get("topics", [])
        return []

    def pull_markdown_topic(self, peer_id: str, topic: str, timeout: float = 5.0) -> Optional[str]:
        """
        Pull a specific markdown topic from a peer.

        Returns the content string, or None on failure/timeout.
        """
        if self.hipaa_enabled or not self._gateway:
            return None

        query_id = hashlib.sha256(f"mdpull:{peer_id}:{topic}:{time.time()}".encode()).hexdigest()[
            :16
        ]

        with self._lock:
            self._markdown_pending[query_id] = None
            self._markdown_events[query_id] = threading.Event()

        self._send_to_peer(
            peer_id,
            MESH_MARKDOWN_REQUEST,
            {
                "requesting_node": self.node_id,
                "query_id": query_id,
                "topic": topic,
            },
        )

        event = self._markdown_events[query_id]
        event.wait(timeout=timeout)

        with self._lock:
            result = self._markdown_pending.pop(query_id, None)
            self._markdown_events.pop(query_id, None)

        if result and isinstance(result, dict):
            content = result.get("content")
            content_hash = result.get("content_hash", "")
            # Verify integrity
            if content and content_hash:
                computed = hashlib.sha256(content.encode()).hexdigest()
                if computed != content_hash:
                    logger.warning(f"Content hash mismatch pulling {topic} from {peer_id}")
                    return None
            return content
        return None

    def _get_markdown_peers(self) -> List[str]:
        """Get peer IDs with share_markdown_memories permission."""
        if not self.trust_manager:
            if self._gateway:
                return list(self._gateway.peer_gateways.keys())
            return []
        trusted = self.trust_manager.get_trusted_peers()
        return [r.node_id for r in trusted if r.permissions.check("share_markdown_memories")]

    # ── Bus registration ──

    def register_bus_handlers(self, bus):
        """Register event handlers on the SkillBus."""
        bus.subscribe(MESH_MEMORY_QUERY, self._bus_handle_query, skill="mesh_memory")
        bus.subscribe(MESH_MEMORY_RESPONSE, self._bus_handle_response, skill="mesh_memory")
        bus.subscribe(MESH_MEMORY_PUSH, self._bus_handle_push, skill="mesh_memory")
        bus.subscribe(MESH_MEMORY_REVOKE, self._bus_handle_revoke, skill="mesh_memory")

        # Markdown memory handlers
        bus.subscribe(MESH_MARKDOWN_PUSH, self._bus_handle_markdown_push, skill="mesh_memory")
        bus.subscribe(MESH_MARKDOWN_LIST, self._bus_handle_markdown_list, skill="mesh_memory")
        bus.subscribe(
            MESH_MARKDOWN_LIST_RESPONSE,
            self._bus_handle_markdown_list_response,
            skill="mesh_memory",
        )
        bus.subscribe(MESH_MARKDOWN_REQUEST, self._bus_handle_markdown_request, skill="mesh_memory")
        bus.subscribe(
            MESH_MARKDOWN_RESPONSE, self._bus_handle_markdown_response, skill="mesh_memory"
        )
        logger.info("Memory bridge: bus handlers registered")

    def _bus_handle_query(self, message):
        """Bus handler for incoming queries."""
        response = self.handle_remote_query(message.payload)
        if response and self._gateway:
            requesting_node = message.payload.get("requesting_node", "")
            self._send_to_peer(requesting_node, MESH_MEMORY_RESPONSE, response)

    def _bus_handle_response(self, message):
        """Bus handler for incoming responses."""
        self.handle_remote_response(message.payload)

    def _bus_handle_push(self, message):
        """Bus handler for pushed memories."""
        self.handle_remote_push(message.payload)

    def _bus_handle_revoke(self, message):
        """Bus handler for revocations."""
        self.handle_remote_revoke(message.payload)

    def _bus_handle_markdown_push(self, message):
        """Bus handler for markdown pushes."""
        self.handle_markdown_push(message.payload)

    def _bus_handle_markdown_list(self, message):
        """Bus handler for markdown list requests."""
        response = self.handle_markdown_list(message.payload)
        if response and self._gateway:
            requesting_node = message.payload.get("requesting_node", "")
            self._send_to_peer(requesting_node, MESH_MARKDOWN_LIST_RESPONSE, response)

    def _bus_handle_markdown_list_response(self, message):
        """Bus handler for markdown list responses."""
        self.handle_markdown_list_response(message.payload)

    def _bus_handle_markdown_request(self, message):
        """Bus handler for markdown topic requests."""
        response = self.handle_markdown_request(message.payload)
        if response and self._gateway:
            requesting_node = message.payload.get("requesting_node", "")
            self._send_to_peer(requesting_node, MESH_MARKDOWN_RESPONSE, response)

    def _bus_handle_markdown_response(self, message):
        """Bus handler for markdown topic responses."""
        self.handle_markdown_response(message.payload)

    # ── Internal helpers ──

    def _get_queryable_peers(self) -> List[str]:
        """Get peer IDs that have request_memory permission."""
        if not self.trust_manager:
            # Without trust manager, query all connected peers
            if self._gateway:
                return list(self._gateway.peer_gateways.keys())
            return []

        trusted = self.trust_manager.get_trusted_peers()
        return [r.node_id for r in trusted if r.permissions.check("request_memory")]

    def _send_to_peer(self, peer_id: str, topic: str, payload: dict):
        """Send a mesh event to a specific peer via the gateway."""
        if not self._gateway:
            return

        from .gateway import Message, MsgType

        msg = Message(
            type=MsgType.TOOL_REQUEST,
            payload={
                "mesh_event": True,
                "topic": topic,
                "data": payload,
            },
        )

        ws = self._gateway.peer_gateways.get(peer_id)
        if ws:
            # We're in a sync context but ws.send is async
            # Use the gateway's event loop
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    asyncio.ensure_future(ws.send(msg.to_json()))
                else:
                    loop.run_until_complete(ws.send(msg.to_json()))
            except RuntimeError:
                # No event loop — create one
                asyncio.run(ws.send(msg.to_json()))

    def _broadcast_revocation(self, key: str):
        """Broadcast a memory revocation to all connected peers."""
        if not self._gateway:
            return

        revoke_msg = {
            "origin_node": self.node_id,
            "key": key,
        }
        for peer_id in self._gateway.peer_gateways:
            try:
                self._send_to_peer(peer_id, MESH_MEMORY_REVOKE, revoke_msg)
            except Exception as e:
                logger.debug(f"Failed to send revocation to {peer_id}: {e}")

    # ── Status ──

    def get_status(self) -> dict:
        """Get memory bridge status for CLI/dashboard."""
        return {
            "hipaa_mode": self.hipaa_enabled,
            "shared_count": self.shared_store.count_shared(),
            "received_count": self.shared_store.count_received(),
            "shared_keys": self.get_shared_keys(),
            "queryable_peers": len(self._get_queryable_peers()),
            "gateway_connected": self._gateway is not None,
        }
