# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Licensed under the MIT License

"""
Mesh Network Package v2.7.8

Complete peer-to-peer agent networking:
  Phase 1 (v2.7.0): mDNS Discovery + Peer Gateway Mode
  Phase 2 (v2.7.1): Signal Protocol Trust + PermissionMatrix
  Phase 3 (v2.7.2): Shared Memory Bridge via SkillBus
  Phase 4 (v2.7.3): Orchestrated Delegation via RemoteAgent
  Phase 5 (v2.7.4): Model Sharing + Markdown Memory Push/Pull
  Phase 6 (v2.7.5): Borrowed-Use Tracking via Dross
  Phase 7 (v2.7.6): Tor Transport
  Phase 8 (v2.7.7): Encrypted Peer Messaging
  Phase 9 (v2.7.8): Rendezvous Server (Internet-Wide Discovery)
"""

from .discovery import DiscoveredPeer, MeshDiscovery, PeerStore
from .gateway import (
    MeshConfig,
    MeshGateway,
    MeshNode,
    Message,
    MsgType,
    NodeInfo,
    generate_connection_string,
    get_mesh_config,
    run_gateway,
    run_node,
)
from .memory_bridge import (
    MemoryBridge,
    MeshMemoryResult,
    SharedMemoryMeta,
    SharedMemoryStore,
)
from .mesh_skill_endpoint import (
    MeshSkillEndpoint,
    register_remote_skills,
    unregister_remote_skills,
)
from .message_bridge import MessageBridge, MessageStore
from .model_bridge import ModelBridge, ModelEntry, ModelRegistry
from .remote_agent import RemoteAgent
from .rendezvous import (
    COMMUNITY_RDV_URL,
    PeerRecord,
    PeerRegistry,
    RendezvousServer,
    start_local_server,
)
from .tor_transport import TorState, TorTransport
from .trust import (
    MeshTrustManager,
    PermissionMatrix,
    TrustRecord,
    TrustStore,
    compute_fingerprint,
    compute_verification_code,
)
from .usage_tracker import UsageRecord, UsageTracker

__all__ = [
    # Gateway
    "MeshGateway",
    "MeshNode",
    "MeshConfig",
    "Message",
    "MsgType",
    "NodeInfo",
    "get_mesh_config",
    "generate_connection_string",
    "run_gateway",
    "run_node",
    # Discovery (v2.7.0)
    "MeshDiscovery",
    "DiscoveredPeer",
    "PeerStore",
    # Trust (v2.7.1)
    "MeshTrustManager",
    "TrustRecord",
    "TrustStore",
    "PermissionMatrix",
    "compute_verification_code",
    "compute_fingerprint",
    # Shared Memory (v2.7.2)
    "MemoryBridge",
    "SharedMemoryStore",
    "SharedMemoryMeta",
    "MeshMemoryResult",
    # Delegation (v2.7.3)
    "RemoteAgent",
    "MeshSkillEndpoint",
    "register_remote_skills",
    "unregister_remote_skills",
    # Model Sharing (v2.7.4)
    "ModelBridge",
    "ModelEntry",
    "ModelRegistry",
    # Usage Tracking (v2.7.5)
    "UsageTracker",
    "UsageRecord",
    # Tor Transport (v2.7.6)
    "TorTransport",
    "TorState",
    # Peer Messaging (v2.7.7)
    "MessageBridge",
    "MessageStore",
    # Rendezvous (v2.7.8)
    "RendezvousServer",
    "PeerRegistry",
    "PeerRecord",
    "COMMUNITY_RDV_URL",
    "start_local_server",
]
