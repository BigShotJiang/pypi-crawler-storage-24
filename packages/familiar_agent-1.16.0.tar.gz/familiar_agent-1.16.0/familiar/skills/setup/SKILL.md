# Setup Skill

Check and manage service connections. See which integrations are configured,
test connectivity, and add new API keys without leaving the conversation.

## Usage

Use this skill when the user wants to:
- Check which services are connected or missing
- Add an API key or credential for a service
- Test if a configured service is working
- See recommended services for their job class

## Tools

- **check_setup_status** — Show configured, missing, and recommended services
- **auto_configure_service** — Save an API key and test the connection
