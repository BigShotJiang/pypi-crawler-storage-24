# QuickBooks Online

View invoices, expenses, P&L reports, and customers.

## Setup

```bash
export QUICKBOOKS_ACCESS_TOKEN=your_oauth_token
export QUICKBOOKS_REALM_ID=your_company_id
```

Get credentials at: https://developer.intuit.com/

## Tools

| Tool | Description |
|------|-------------|
| `qb_invoices` | List recent invoices |
| `qb_expenses` | List recent expenses |
| `qb_profit_loss` | Profit and loss report |
| `qb_customers` | List customers |
