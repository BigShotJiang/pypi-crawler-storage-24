# Advocacy & Legislative Tracking

Track legislation, coordinate testimony, manage coalition partners, and send action alerts.

## Tools

| Tool | Description |
|------|-------------|
| `track_bill` | Start tracking a legislative bill |
| `list_bills` | List bills with filters (position, priority, jurisdiction) |
| `bill_details` | Full bill details with hearings, testimony, coalition |
| `update_bill` | Update bill status, position, priority |
| `remove_bill` | Stop tracking a bill |
| `add_hearing` | Add hearing date to a bill |
| `add_testimony` | Record testimony submitted |
| `add_coalition_partner` | Add coalition partner org |
| `upcoming_hearings` | Cross-bill hearing calendar |
| `draft_action_alert` | Draft alert (call_to_action/hearing_notice/vote_alert/victory_report) |
| `add_supporter` | Add supporter to advocacy list |
| `import_supporters` | Import supporters from CSV |
| `list_supporters` | List advocacy supporters |
| `advocacy_dashboard` | Overview of active bills, hearings, supporters |

## Data

- Bills: `~/.familiar/data/advocacy.json`
- Supporters: `~/.familiar/data/advocacy_supporters.json`
