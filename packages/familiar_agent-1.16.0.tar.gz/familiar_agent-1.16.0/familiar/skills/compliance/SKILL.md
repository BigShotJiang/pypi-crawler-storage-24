# Nonprofit Compliance Calendar Skill

Track IRS filing deadlines, state registration requirements, and compliance checklists.

## Setup

No API key required — uses curated local data.

## Tools

| Tool | Description |
|------|-------------|
| `filing_deadlines` | List upcoming IRS deadlines with urgency tags |
| `state_requirements` | State-specific nonprofit registration requirements |
| `compliance_checklist` | Governance and filing compliance checklist |
