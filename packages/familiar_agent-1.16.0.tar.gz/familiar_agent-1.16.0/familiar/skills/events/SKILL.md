# Event Management

Full lifecycle event planning for nonprofits — from pride marches (30K+ attendees) to board meetings.

## Tools

| Tool | Description |
|------|-------------|
| `create_event` | Create event with auto-generated milestone timeline |
| `list_events` | List events, filter by status |
| `event_details` | Full event details with milestones, budget, venue |
| `update_event` | Update event fields |
| `delete_event` | Delete an event |
| `update_milestone` | Mark milestone as pending/in_progress/done |
| `event_timeline` | Show milestone timeline with urgency indicators |
| `add_vendor` | Add vendor (catering, sound, staging, etc) |
| `list_vendors` | List vendors for an event |
| `update_vendor` | Update vendor status, payment, insurance |
| `add_volunteer` | Add volunteer with role and shift |
| `list_volunteers` | List volunteers for an event |
| `check_in_volunteer` | Check in volunteer at event |
| `volunteer_summary` | Count volunteers by role |

## Event Types

pride_march, gala, fundraiser, workshop, rally, meeting, conference, volunteer_day

## Milestone Templates

Each event type gets auto-generated milestones with countdown offsets:
- **pride_march**: 12 milestones (permits, vendors, volunteers, marketing, etc)
- **gala**: 10 milestones (venue, keynote, catering, invitations, seating)
- **fundraiser**: 8 milestones (goal, sponsors, marketing, peer outreach)
- **workshop**: 6 milestones (facilitator, materials, registration)
- **rally**: 8 milestones (coalition, permits, speakers, safety plan)
- **meeting**: 4 milestones (agenda, materials, reminder, minutes)
- **conference**: 9 milestones (CFP, venue, speakers, registration, AV)
- **volunteer_day**: 6 milestones (scope, logistics, recruitment, supplies)

## Data

- Events: `~/.familiar/data/events.json`
- Vendors: `~/.familiar/data/event_vendors.json`
- Volunteers: `~/.familiar/data/event_volunteers.json`
