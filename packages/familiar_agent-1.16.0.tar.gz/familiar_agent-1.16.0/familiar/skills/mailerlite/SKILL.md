# MailerLite

Manage email newsletters — subscribers, campaigns, and analytics.

## Setup

```bash
export MAILERLITE_API_KEY=your_api_token
```

Get your key at: https://www.mailerlite.com/

## Tools

| Tool | Description |
|------|-------------|
| `list_subscribers` | List subscribers with open/click stats |
| `add_subscriber` | Add a new email subscriber |
| `list_campaigns` | List campaigns with send stats |
| `campaign_stats` | Detailed stats for a specific campaign |

## Examples

- "Show my active subscribers"
- "Add jane@example.com to the mailing list"
- "List recent campaigns"
- "Show stats for campaign 12345"
