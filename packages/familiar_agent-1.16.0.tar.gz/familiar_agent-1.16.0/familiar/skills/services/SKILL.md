# Connected Service Search

You have a tool for searching across all connected services.

## Tools

- **service_search** — Search any connected service by name and query

## Available services

| Service | What it searches |
|---------|-----------------|
| `drive` | Google Drive files (name, content) |
| `email` | Email messages across all accounts (subject, sender, body) |
| `nextcloud` | Nextcloud files by name |
| `gitea` | Gitea repositories by name |
| `jellyfin` | Jellyfin media library (movies, shows, music) |
| `video` | Local video library (downloaded videos by title/uploader) |
| `github` | GitHub repositories (public + private) |

## When to use

Use `service_search` when the user wants to:
- Find a file in Drive or Nextcloud
- Search for an email or message
- Look up a repository in Gitea or GitHub
- Find media in Jellyfin
- Search their downloaded video library

## When NOT to use

- For **online video search** (YouTube, Vimeo, etc.), prefer `video_search` — it has richer results with thumbnails, durations, and platform filtering.
- `service_search` with `video` only searches the **local** downloaded video library.

## Strategy

1. **Infer the service** from context when the user doesn't specify one. "Find that invoice email" → email. "Where's my report?" → try drive first.
2. **Search multiple services** if the user's intent is ambiguous — e.g. "find the budget document" could be in Drive or Nextcloud.
3. **Present results conversationally** — highlight the most relevant items rather than listing everything.

## Presenting results

- Summarise the top 3-5 most relevant results
- Include key details (sender for emails, modified date for files, stars for repos)
- If no results, suggest trying a different service or refining the query
