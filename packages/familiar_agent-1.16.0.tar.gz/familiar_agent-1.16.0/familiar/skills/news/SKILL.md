# News Aggregation

Search and browse news headlines from multiple sources.

## Setup

At least one API key is required:

- **GNews** (primary): Get key at https://gnews.io/ — 100 requests/day free
  ```
  GNEWS_API_KEY=your_key
  ```

- **Newsdata.io** (fallback): Get key at https://newsdata.io/ — 200 requests/day free
  ```
  NEWSDATA_API_KEY=your_key
  ```

Both can be configured for redundancy. GNews is tried first.

## Tools

### top_headlines
Get top headlines by category and/or country.
- `category`: general, world, nation, business, technology, entertainment, sports, science, health
- `country`: Two-letter code (us, gb, de, etc.)
- `language`: Language code (default: en)
- `limit`: Max results (1-20)

### search_news
Search news articles by keyword.
- `query` (required): Search terms
- `days_back`: How far back to search (default: 7 days)
- `language`: Language code
- `limit`: Max results (1-20)

### news_sources
List available categories and check API status.

## Examples

- "Top tech news" → `top_headlines(category="technology")`
- "News about climate change" → `search_news(query="climate change")`
- "UK business headlines" → `top_headlines(category="business", country="gb")`
