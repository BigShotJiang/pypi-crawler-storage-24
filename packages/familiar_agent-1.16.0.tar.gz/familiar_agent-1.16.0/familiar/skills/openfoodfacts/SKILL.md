# Open Food Facts

Barcode lookup, product search, and allergen checking for packaged foods.

## Setup

No setup required. Uses the Open Food Facts open database (free, no auth).

## Tools

### barcode_lookup
Look up a product by UPC/EAN barcode. Returns name, brand, nutrition, allergens, ingredients.

### product_search
Search products by name. Returns name, brand, Nutri-Score, and barcodes.

### allergen_check
Check a product for allergens by barcode. Shows confirmed allergens, traces, and ingredients.

## Examples

- "Look up barcode 3017624010701" → `barcode_lookup(barcode="3017624010701")`
- "Search for oat milk" → `product_search(query="oat milk")`
- "Is this product safe for nut allergies?" → `allergen_check(barcode="...")`
