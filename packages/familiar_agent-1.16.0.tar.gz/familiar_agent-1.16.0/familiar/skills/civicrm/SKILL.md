# CiviCRM

Manage donors, donations, and events via your self-hosted CiviCRM instance.

## Setup

```bash
export CIVICRM_URL=https://your-site.org
export CIVICRM_API_KEY=your_api_key
export CIVICRM_SITE_KEY=your_site_key
```

## Tools

| Tool | Description |
|------|-------------|
| `crm_contacts` | List/search contacts (donors, members, volunteers) |
| `crm_donations` | List recent donations/contributions |
| `crm_add_donation` | Log a new donation |
| `crm_events` | List upcoming events |

## Examples

- "Show recent donors"
- "List donations from contact 42"
- "Log a $500 donation from contact 15"
- "Show upcoming events"
