# Instagram Graph API Skill

View insights, recent media, and audience demographics for business/creator accounts.

## Setup

```bash
export INSTAGRAM_ACCESS_TOKEN=your_long_lived_token
export INSTAGRAM_BUSINESS_ID=your_ig_user_id
```

Get credentials at: https://developers.facebook.com/

## Tools

| Tool | Description |
|------|-------------|
| `ig_insights` | Get account impressions, reach, follower count |
| `ig_recent_media` | List recent posts with type and caption |
| `ig_audience` | Get audience demographics (gender, age, country) |
