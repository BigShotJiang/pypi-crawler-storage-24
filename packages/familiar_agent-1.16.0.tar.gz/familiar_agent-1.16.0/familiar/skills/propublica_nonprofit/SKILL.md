# ProPublica Nonprofit Explorer

Search nonprofits, view 990 filings, and compare organizations using ProPublica's free API.

## Setup

No authentication required.

## Tools

| Tool | Description |
|------|-------------|
| `nonprofit_search` | Search by name, state, or NTEE code |
| `nonprofit_990` | Get 990 filing data by EIN |
| `compare_nonprofits` | Side-by-side comparison of two nonprofits |

## Examples

- "Search for food banks in New York"
- "Show 990 data for EIN 131624100"
- "Compare Red Cross and Salvation Army"
