# Clockify

Track time, log entries, and view reports.

## Setup

```bash
export CLOCKIFY_API_KEY=your_api_key
export CLOCKIFY_WORKSPACE_ID=your_workspace_id
```

Get a key at: https://clockify.me/user/preferences#advanced

## Tools

| Tool | Description |
|------|-------------|
| `start_timer` | Start a time tracking timer |
| `stop_timer` | Stop the current timer |
| `log_time` | Log a completed time entry |
| `time_report` | View recent time entries |
| `clockify_projects` | List projects |
