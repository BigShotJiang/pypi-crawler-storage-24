# SAMHSA Treatment Locator

Find substance abuse and mental health treatment facilities.
No setup required.

## Usage

Use this skill when the user needs to find treatment facilities for
substance abuse, mental health, or detox services. Critical for the
Social Worker job class.

## Examples

- "Find mental health treatment in Portland, OR"
- "Substance abuse facilities near 97201"
- "Find detox centers in New York"

## Important

Always include crisis hotline numbers when discussing mental health
or substance abuse topics.

**24/7 SAMHSA Helpline: 1-800-662-4357**

## Tools

- **find_treatment** — Search for treatment facilities by location and service type
