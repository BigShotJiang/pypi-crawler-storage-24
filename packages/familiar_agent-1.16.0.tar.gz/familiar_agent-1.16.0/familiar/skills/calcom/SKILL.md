# Cal.com Scheduling Skill

Manage availability, bookings, and event types via the Cal.com API v2.

## Setup

```bash
export CALCOM_API_KEY=cal_live_...
export CALCOM_URL=https://api.cal.com  # or self-hosted instance
```

Get a key at: https://app.cal.com/settings/developer/api-keys

## Tools

| Tool | Description |
|------|-------------|
| `calcom_availability` | Check available time slots for a date range |
| `calcom_bookings` | List bookings with attendees and status |
| `calcom_create_event_type` | Create a scheduling template |
| `calcom_cancel` | Cancel a booking by UID |
