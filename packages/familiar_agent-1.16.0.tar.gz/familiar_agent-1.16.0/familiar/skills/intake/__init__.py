# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""Smart Intake — unified document/image/audio intake with auto-classification and routing.

Modules:
  skill.py       — Main pipeline, 8 tools (smart_intake, batch_intake, intake_history,
                   review_intake, watch_folder, check_watches, clip_webpage, list_templates)
  classifiers.py — Keyword + template + LLM tiered classification
  router.py      — Content-type → store routing
  history.py     — Audit trail (IntakeHistory)
  review.py      — Human-in-the-loop review queue (ReviewQueue)
  watcher.py     — Poll-based folder watcher (FolderWatcher)
  clipper.py     — Web page clipper (WebClipper)
  templates.py   — Extraction template learning (TemplateStore)
  vision.py      — Vision LLM / OCR text extraction
"""
