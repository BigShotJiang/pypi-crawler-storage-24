# USDA FoodData Central

Search 380K+ foods for nutrition data, dietary analysis, and ingredient details.

## Usage

Use this skill when the user asks about nutrition information, food composition,
calorie counts, macronutrients, or ingredient comparisons. Especially useful for
the Chef job class for recipe cost and nutrition analysis.

## Examples

- "How many calories are in chicken breast?"
- "Compare nutrition of white rice vs brown rice vs quinoa"
- "What's the protein content of tofu?"
- "Look up nutrition facts for olive oil"

## Setup

Get a free API key at https://fdc.nal.usda.gov/api-key-signup/
Set `FOODDATA_API_KEY` in your environment, or use `/connect fooddata`.

Falls back to DEMO_KEY with lower rate limits if no key is set.

## Tools

- **food_search** — Search foods by name, get FDC IDs
- **nutrition_lookup** — Full nutrition facts for a food by FDC ID
- **nutrient_report** — Compare nutrition across multiple foods
