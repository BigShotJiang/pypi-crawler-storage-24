# HubSpot CRM

Manage contacts, deals, and search the CRM.

## Setup

```bash
export HUBSPOT_ACCESS_TOKEN=your_token
```

Get a token at: https://developers.hubspot.com/

## Tools

| Tool | Description |
|------|-------------|
| `hubspot_contacts` | List CRM contacts |
| `hubspot_deals` | List deals/opportunities |
| `hubspot_add_contact` | Create a new contact |
| `hubspot_search` | Search contacts or deals |
