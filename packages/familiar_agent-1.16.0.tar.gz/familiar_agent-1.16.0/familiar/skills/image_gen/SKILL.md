# Image Generation

Generate images from text prompts using multiple AI providers.

## Tools

- `generate_image` — Create an image from a text description
- `list_image_providers` — Show available providers and status

## Providers

| Provider | Type | Cost | Requirements |
|----------|------|------|-------------|
| Gemini (Nano Banana) | Cloud | ~$0.02/image | GEMINI_API_KEY |
| OpenAI DALL-E 3 | Cloud | ~$0.04/image | OPENAI_API_KEY |
| ComfyUI | Local | Free | GPU + ComfyUI at localhost:8188 |
| Automatic1111 | Local | Free | GPU + A1111 at localhost:7860 |

## Usage

```
Generate an oil painting of a sunset over mountains
Generate a photograph of a cat wearing a hat, style: professional photography
Generate a logo for a coffee shop called "Bean There"
```

## Gallery Integration

Set `register_in_gallery: true` to auto-register generated images
with provenance chain, watermark, and certificate.
