# NPI Provider Registry

Search the National Provider Identifier registry for healthcare providers.
Free, no setup required — data updated daily from NPPES.

## Usage

Use this skill when the user needs to find a doctor, therapist, clinic,
or other healthcare provider. Especially useful for the Social Worker
job class for case management and referrals.

## Examples

- "Find psychiatrists in Portland, OR"
- "Look up NPI 1234567890"
- "Find physical therapists near ZIP 10001"
- "Search for Dr. Smith, Family Medicine"

## Setup

No setup required. The NPI Registry API is free and public.

## Tools

- **provider_search** — Search providers by name, specialty, location, or NPI number
