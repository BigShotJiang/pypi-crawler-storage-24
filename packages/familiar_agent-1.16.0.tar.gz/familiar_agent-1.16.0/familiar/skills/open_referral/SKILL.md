# Open Referral / 211 Social Services Skill

Search for health, human, and social services using the HSDS standard.

## Setup

```bash
export OPEN_REFERRAL_URL=https://api.example-211.org
export OPEN_REFERRAL_API_KEY=your_api_key  # optional for public instances
```

Standard: https://openreferral.org/

## Tools

| Tool | Description |
|------|-------------|
| `find_services` | Search for social services (food, housing, healthcare) |
| `service_details` | Get locations, contacts, and schedules for a service |
| `find_organizations` | Search for organizations providing services |
