# Documents Skill

Generate professional documents, presentations, and templated content.
Thank-you letters, board reports, grant narratives, receipts, newsletters,
memos, and PowerPoint presentations.

## Usage

Use this skill when the user wants to:
- Draft a letter, report, receipt, memo, or newsletter
- Create a document from a template with provided data (mail merge)
- Export or convert between DOCX, PDF, and Markdown formats
- List or manage available document templates
- Create a PowerPoint presentation with slides, tables, and charts

## Bundled Templates

27 job-class templates ship with the package and are available immediately:

- **Helper** (3): research_brief, comparison_matrix, topic_summary
- **Social Worker** (4): case_intake, safety_plan, resource_referral, case_closure
- **Business Buddy** (4): invoice, meeting_agenda, project_proposal, weekly_report
- **Nonprofit Director** (5): donor_thankyou, grant_proposal, board_report, annual_report, campaign_letter
- **Chef** (5): recipe_card, menu_template, cost_analysis, vendor_order, prep_list
- **Artist** (6): commission_agreement, show_application, artist_statement, client_invoice, consignment_agreement, kiln_log

User templates in ~/.familiar/templates/ override bundled ones of the same name.

## Template System

Templates use JSON schema files with {{placeholder}} syntax.
Custom templates go in ~/.familiar/templates/ as JSON files.

## Presentations

The `create_presentation` tool generates PPTX files with slide types:
- **title**: Title slide with subtitle
- **content**: Title + bullet points or body text
- **table**: Title + data table
- **chart**: Title + embedded chart (via charts skill)
- **section**: Divider slide with large centered text

Three layout variants: `report`, `pitch`, `meeting`.
Falls back to DOCX when python-pptx is unavailable.

## Chart Embedding

Documents and presentations can embed charts inline.
Add `chart_data` to any document section or presentation slide:
```json
{"chart_type": "bar", "labels": ["Q1", "Q2"], "values": [10000, 15000]}
```

## Letterhead

Place organization logo at ~/.familiar/templates/letterhead.png.
The document skill auto-inserts it in headers. Organization name,
address, and EIN are pulled from config.yaml.

## Output

Files are saved to ~/.familiar/documents/ with date-based naming.
The agent provides the file path for download via dashboard or email attachment.

## Cross-Skill Integration

- **charts**: Chart embedding in documents and presentations via render_chart_bytes()
- **nonprofit**: donors_needing_thanks triggers create_letter. Grants link to docs.
- **bookkeeping**: generate_receipt creates formatted PDF via this skill.
- **reports**: All reports output as formatted DOCX/PDF.
- **meetings**: Agendas and minutes generated as DOCX/PDF.
