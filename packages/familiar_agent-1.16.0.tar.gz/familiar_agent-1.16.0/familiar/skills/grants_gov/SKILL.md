# Grants.gov

Search federal funding opportunities, view grant details, and track deadlines.

## Setup

Free API — works without authentication for basic searches.
Optional: Set `GRANTS_GOV_API_KEY` for higher rate limits.

## Tools

| Tool | Description |
|------|-------------|
| `search_grants` | Search by keyword, agency, or funding category |
| `grant_details` | Get details about a specific opportunity |
| `grant_deadlines` | Find grants with upcoming deadlines |

## Examples

- "Search for community health grants"
- "Find HHS grants for education"
- "Show grant deadlines in the next 30 days"
