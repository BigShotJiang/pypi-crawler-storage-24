# GlobalGiving

Search international development projects and NGOs worldwide.

## Setup

```bash
export GLOBALGIVING_API_KEY=your_api_key
```

Get a key at: https://www.globalgiving.org/api/

## Tools

| Tool | Description |
|------|-------------|
| `search_projects` | Search by keyword, theme, or country |
| `project_details` | Get details about a specific project |

## Examples

- "Search for education projects in Kenya"
- "Find climate change projects"
- "Show details for project 12345"
