# Jitsi Meet Video Conferencing Skill

Generate video conference links with optional JWT authentication.

## Setup (Minimal)

```bash
export JITSI_URL=https://meet.jit.si  # or self-hosted instance
```

## Setup (Self-Hosted with JWT)

```bash
export JITSI_URL=https://jitsi.example.com
export JITSI_APP_ID=my_app
export JITSI_APP_SECRET=your_shared_secret
```

## Tools

| Tool | Description |
|------|-------------|
| `create_meeting_link` | Generate a Jitsi meeting URL with optional JWT |
| `jitsi_status` | Show server config and auth status |
