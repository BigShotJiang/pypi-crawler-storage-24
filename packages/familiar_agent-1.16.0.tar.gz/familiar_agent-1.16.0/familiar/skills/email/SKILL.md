# Email Management Skill

Help manage email inbox - triage, summarize, draft responses.

## Transport Paths

Three transport paths — whichever is configured is used automatically:

**Path A — Gmail API (preferred for Gmail users):**
Run `/connect google auth gmail` to authorize. Token stored at `~/.familiar/data/google_token_gmail.json`.

**Path B — Local Stalwart Mail (self-hosted):**
Provision via Server tab → Stalwart Mail. Auto-detected on localhost ports 9930 (IMAPS) / 5870 (SMTP submission). Configure your account via `/connect email`.

**Path C — IMAP/SMTP (any provider):**
Set `EMAIL_ADDRESS`, `EMAIL_PASSWORD`, `EMAIL_IMAP_SERVER`, `EMAIL_SMTP_SERVER` env vars or use `/connect email` wizard.

## Usage

Use this skill when the user wants to:
- Check their inbox or get a summary of unread emails
- Find specific emails
- Draft responses to emails
- Send emails on their behalf (with confirmation)

## Important

- Always summarize what you find before taking action
- Get explicit confirmation before sending any emails
- Prioritize emails from donors, board members, and grant organizations
- Flag urgent items (deadlines, time-sensitive requests)

## Nonprofit Context

Pay special attention to:
- Donor communications (thank you notes, acknowledgments)
- Grant-related emails (deadlines, reporting requirements)
- Board member communications
- Volunteer coordination
- Event-related correspondence
