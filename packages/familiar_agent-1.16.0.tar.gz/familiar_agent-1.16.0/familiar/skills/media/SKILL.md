# Media — Online Radio & Podcasts

Stream online radio and browse podcasts directly from Familiar.

## Tools

| Tool | Description |
|------|-------------|
| `radio_search` | Search radio stations by name, genre, or country |
| `radio_genres` | List popular genres with station counts |
| `podcast_search` | Search iTunes for podcasts |
| `podcast_episodes` | Get episodes from a podcast RSS feed |
| `media_favorites` | List your saved favorites |

## Setup

**No setup required!** Radio Browser and iTunes Search are free APIs with no authentication needed.

## APIs Used

- **Radio Browser** (`https://de1.api.radio-browser.info`) — Free, no auth, no rate limit. Community-maintained directory of internet radio stations.
- **iTunes Search** (`https://itunes.apple.com/search`) — Free, no auth, 20 calls/min limit. Podcast search and metadata.
- **RSS feeds** — Standard podcast RSS feeds parsed with Python stdlib.

## Dashboard

The Media panel in the dashboard provides:

1. **Radio** — Search and stream radio stations with genre filtering
2. **Podcasts** — Search podcasts and browse episodes
3. **Favorites** — Saved stations and podcasts
4. **History** — Recently played items

A Winamp-inspired mini-player widget in the right sidebar provides persistent playback controls across all dashboard panels.

## Data Storage

Favorites and history are stored in `~/.familiar/data/media/`:
- `favorites.json` — Saved stations and podcasts
- `history.json` — Recently played items (last 100)
