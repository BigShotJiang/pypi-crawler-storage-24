# Cloudinary Image Management

Upload, browse, transform, and generate URLs for images.

## Setup

1. Create a free account at https://cloudinary.com/
2. Set environment variables:
   ```
   CLOUDINARY_CLOUD_NAME=your_cloud_name
   CLOUDINARY_API_KEY=your_api_key
   CLOUDINARY_API_SECRET=your_api_secret
   ```

Free tier: 25 credits/month (sufficient for moderate use).

## Tools

### gallery_images
Browse images in your account, filter by folder.

### upload_image
Upload an image from a URL with optional custom ID, folder, and tags.

### transform_image
Generate transformed image URLs (resize, crop, format, effects).

### image_url
Get original and thumbnail URLs for an image by public ID.

## Examples

- "Show my portfolio images" → `gallery_images(folder="portfolio")`
- "Upload this image" → `upload_image(url="https://...", folder="art")`
- "Make a thumbnail" → `transform_image(public_id="my-art", width=300, height=300, crop="thumb")`
