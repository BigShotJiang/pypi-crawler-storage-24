# Markdown Memories Skill

Wiki-style markdown memories with provenance tracking. Each topic is a
single `.md` file with YAML frontmatter that grows via appended sections.
Human-readable, editable, and linked to the genesis block chain for
verifiable training-data lineage.

## Usage

- Save knowledge about any topic — each save appends a new section
- Search across all topics by keyword
- List topics filtered by tags
- Export memories as structured training data with provenance
- Auto-curated: meaningful conversations are captured automatically

## Relationship to Other Skills

- **knowledge_base**: JSON-backed quick notes and snippets. Use for short
  items that don't need revision history.
- **knowledge** (vector): Semantic search over large document collections.
- **memories** (this skill): Long-lived topic files that accumulate over
  time, with revision tracking and genesis-anchored provenance for
  training data export.
