# Shippo Shipping

Get shipping rates, create labels, and track shipments.

## Setup

1. Create an account at https://goshippo.com/
2. Set environment variable: `SHIPPO_API_KEY=your_key`

No monthly fee — pay per label. Supports USPS, UPS, FedEx, DHL, and more.

## Tools

### shipping_rates
Get rate quotes for a package by origin/destination ZIP and weight.

### create_label
Purchase a shipping label from a rate quote. Returns tracking number and PDF link.

### track_shipment
Track a shipment by carrier and tracking number.

## Examples

- "Ship a 2lb package from 97201 to 10001" → `shipping_rates(from_zip="97201", to_zip="10001", weight=2)`
- "Buy the cheapest label" → `create_label(rate_id="...")`
- "Track my USPS package" → `track_shipment(carrier="usps", tracking_number="...")`
