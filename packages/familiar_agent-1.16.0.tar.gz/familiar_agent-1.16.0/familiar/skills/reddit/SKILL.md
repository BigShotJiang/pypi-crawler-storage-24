# Reddit Search & Trends Skill

Search posts, view trending content, and get top posts from subreddits.

## Setup

```bash
export REDDIT_CLIENT_ID=your_app_id
export REDDIT_CLIENT_SECRET=your_secret
```

Create an app at: https://www.reddit.com/prefs/apps (select "script" type)

## Tools

| Tool | Description |
|------|-------------|
| `reddit_search` | Search posts by keyword with sort and time filters |
| `reddit_trending` | Get hot/trending posts from a subreddit |
| `subreddit_top` | Get top-rated posts by time period |
