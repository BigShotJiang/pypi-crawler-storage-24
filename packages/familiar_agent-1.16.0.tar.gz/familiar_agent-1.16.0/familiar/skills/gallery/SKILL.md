# Gallery Vault

Protect your artwork with digital watermarks and blockchain-backed provenance certificates.

## Tools

| Tool | Description |
|------|-------------|
| `watermark_art` | Apply visible or invisible watermarks to images |
| `register_artwork` | Register artwork with watermarks + chain notarization |
| `verify_artwork` | Verify provenance chain integrity for artwork |
| `gallery_list` | List all Gallery Vault contents |
| `gallery_search` | Search gallery by title, artist, or tags |

## Watermark Types

- **Visible**: Semi-transparent text overlay (configurable position and opacity)
- **Invisible**: LSB steganography — data hidden in pixel channel bits (lossless PNG)
- **Certificate**: Markdown provenance certificate with SHA-256 hashes and chain references

## Chain Integration

Each artwork registration creates a `watermark` block on the genesis block chain containing:
- SHA-256 hashes of both original and watermarked images
- Artist identity and licensing info
- Certificate hash for integrity verification

## Prerequisites

- **Pillow**: `pip install familiar-agent[docs]`
- **Genesis block**: Required for chain notarization (watermarking works without it)

## Examples

```
Register my painting "Sunset Harbor" — I'm the artist, medium is oil on canvas, 24x36 inches
```

```
Watermark this image with my copyright notice: /path/to/image.png
```

```
Verify the provenance of artwork abc123def456
```

## Storage

Gallery data is stored in `~/.familiar/data/gallery/`:
- `originals/` — original uploaded images
- `watermarked/` — watermarked copies
- `thumbnails/` — 300x300 thumbnails
- `certificates/` — markdown provenance certificates
- `gallery.json` — artwork metadata registry
