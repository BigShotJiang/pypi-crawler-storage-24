# KoboToolbox Intake Forms Skill

List forms, view submissions, and get statistics for social worker case management.

## Setup

```bash
export KOBO_URL=https://kf.kobotoolbox.org  # or self-hosted instance
export KOBO_TOKEN=your_api_token
```

Get a token at: Account Settings > Security > API Key

## Tools

| Tool | Description |
|------|-------------|
| `kobo_forms` | List forms with status and owner |
| `kobo_submissions` | View form submissions with field data |
| `kobo_form_stats` | Get form statistics and submission count |
