# Brave Search

Web search, news, and suggestions via the Brave Search API.

## Setup

1. Get a free API key at https://brave.com/search/api/
2. Set environment variable: `BRAVE_SEARCH_API_KEY=your_key`

Free tier includes ~1,000 queries/month.

## Tools

### brave_search
Search the web with freshness filtering.
- `query` (required): Search terms
- `count`: Results to return (1-20, default 10)
- `freshness`: Time filter — `pd` (day), `pw` (week), `pm` (month), `py` (year)

### brave_news
Search recent news articles.
- `query` (required): News search terms
- `count`: Results (1-20, default 10)
- `freshness`: Time filter (default: past day)

### brave_suggest
Get search query suggestions.
- `query` (required): Partial query

## Examples

- "Search for Python web frameworks" → `brave_search(query="Python web frameworks")`
- "Latest AI news" → `brave_news(query="artificial intelligence")`
- "Suggestions for machine" → `brave_suggest(query="machine")`
