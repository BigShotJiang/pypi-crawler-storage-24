# Charts Skill

Generate charts and visualizations from data. Bar charts, pie charts,
line graphs, and horizontal bar charts with consistent professional styling.

## Usage

Use this skill when the user wants to:
- Create a chart or graph from provided data
- Visualize financial data (income vs expenses, donor tiers, etc.)
- Generate charts from existing Familiar datasets (nonprofit, bookkeeping)
- Embed charts in documents or presentations

## Chart Types

- **bar**: Vertical bar chart (default for comparisons)
- **hbar**: Horizontal bar chart (good for long labels)
- **pie**: Pie chart (percentages, breakdowns)
- **line**: Line chart (trends over time)

## Data Sources

`create_chart_from_data` supports these built-in datasets:
- `donor_tiers` — Donor count by giving tier (pie)
- `income_vs_expense` — Income vs expense totals (bar)
- `income_by_category` — Income breakdown by category (pie)
- `expense_by_category` — Expense breakdown by category (pie)
- `grant_pipeline` — Grant amounts by status (hbar)
- `monthly_revenue` — Monthly revenue trend (line)

## Embedding

Charts can be embedded in DOCX and PPTX documents via the documents skill.
Use `chart_data` in document sections or presentation slides.

## Output

Files are saved to ~/.familiar/documents/ as PNG or PDF.
