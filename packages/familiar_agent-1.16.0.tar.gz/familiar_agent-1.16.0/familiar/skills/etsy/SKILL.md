# Etsy Shop Management

Manage your Etsy shop listings, orders, and stats.

## Setup

1. Register an app at https://www.etsy.com/developers/
2. Set environment variables:
   ```
   ETSY_API_KEY=your_keystring
   ETSY_SHOP_ID=your_numeric_shop_id
   ETSY_ACCESS_TOKEN=your_oauth_token
   ```

The API key enables read-only access. OAuth token required for orders and creating/updating listings.

## Tools

### etsy_listings
List shop listings with prices, quantities, views, and favorites.

### etsy_orders
View recent orders with buyer info, totals, and items.

### etsy_stats
Get shop overview: active listings, total sales, reviews, favorites.

### etsy_create_listing
Create a new draft listing with title, description, and price.

### etsy_update_listing
Update an existing listing's title, description, price, quantity, or state.

## Examples

- "Show my active listings" → `etsy_listings(state="active")`
- "Recent orders" → `etsy_orders(limit=10)`
- "Shop stats" → `etsy_stats()`
