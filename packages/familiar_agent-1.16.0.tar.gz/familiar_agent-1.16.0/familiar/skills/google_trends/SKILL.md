# Google Trends

Discover trending searches, track interest over time, and find related queries.

## Setup

1. Enable the Google Trends API in your Google Cloud Console
2. Create an API key
3. Set environment variable: `GOOGLE_TRENDS_API_KEY=your_key`

Note: The Google Trends API (v1alpha) may require alpha program enrollment.

## Tools

### trending_now
Get currently trending searches for a region.
- `geo`: Region code (default: US)

### interest_over_time
Track search interest for up to 5 terms over time.
- `terms` (required): List of search terms to compare
- `geo`: Region code (default: US)
- `timeframe`: Time range — `today 1-m`, `today 3-m`, `today 12-m`, `today 5-y`

### related_queries
Find queries related to a search term.
- `term` (required): Search term
- `geo`: Region code

## Examples

- "What's trending?" → `trending_now(geo="US")`
- "Compare Python vs JavaScript interest" → `interest_over_time(terms=["Python", "JavaScript"])`
- "What's related to machine learning?" → `related_queries(term="machine learning")`
