# Mealie (Self-Hosted Recipe Manager)

Integration with your self-hosted Mealie instance for recipe management, meal planning, and shopping lists.

## Setup

1. Install Mealie: https://docs.mealie.io/
2. Create an API token: Mealie → User Profile → Manage API Tokens
3. Set environment variables:
   ```
   MEALIE_URL=https://mealie.example.com
   MEALIE_TOKEN=your_api_token
   ```

## Docker Quick Start

```yaml
services:
  mealie:
    image: ghcr.io/mealie-recipes/mealie:latest
    ports:
      - "9925:9000"
    environment:
      ALLOW_SIGNUP: "true"
      TZ: America/New_York
    volumes:
      - mealie-data:/app/data
volumes:
  mealie-data:
```

## Tools

### mealie_recipes
List or search your recipes.

### mealie_recipe_detail
Get full recipe with ingredients, instructions, and notes.

### mealie_add_recipe
Import a recipe from a URL (auto-extraction).

### mealie_meal_plan
View the current meal plan.

### mealie_shopping_list
View shopping lists (all lists or a specific one by ID).

## Examples

- "Show my recipes" → `mealie_recipes()`
- "Find chicken recipes" → `mealie_recipes(query="chicken")`
- "Import this recipe" → `mealie_add_recipe(url="https://...")`
- "What's for dinner this week?" → `mealie_meal_plan()`
