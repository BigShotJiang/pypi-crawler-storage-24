# HRSA Health Center Finder

Find free and sliding-scale health centers funded by HRSA.
No setup required.

## Usage

Use this skill when the user needs to find affordable healthcare,
free clinics, or community health centers. Critical for the Social
Worker job class when connecting clients to primary care, dental,
mental health, or substance abuse services.

## Examples

- "Find free health centers near ZIP 97201"
- "Where can I get affordable dental care in Portland, OR?"
- "Find sliding-scale clinics near me"

## Important

All HRSA health centers (FQHCs) accept patients regardless of
ability to pay. Fees are based on income using a sliding scale.

## Tools

- **find_health_center** — Search for HRSA-funded health centers by location
