# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Marketplace entity definitions.

Five entity types that form the unified catalog:
  - familiar  (bundle) — complete creation package
  - species   — sprite + personality overlay
  - job       — professional role template
  - skill     — grouped tools + docs
  - tool      — individual atomic capability
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class EntityType(str, Enum):
    """Marketplace entity types."""

    FAMILIAR = "familiar"
    SPECIES = "species"
    JOB = "job"
    SKILL = "skill"
    TOOL = "tool"


@dataclass
class CatalogEntry:
    """Unified catalog wrapper for any marketplace entity."""

    id: str
    entity_type: EntityType
    name: str
    version: str
    author: str
    description: str
    tags: list[str] = field(default_factory=list)
    familiar_version: str = ""
    source: str = "builtin"  # "builtin", "custom", "marketplace"
    entity_data: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Serialize to JSON-safe dict."""
        return {
            "id": self.id,
            "entity_type": self.entity_type.value,
            "name": self.name,
            "version": self.version,
            "author": self.author,
            "description": self.description,
            "tags": self.tags,
            "familiar_version": self.familiar_version,
            "source": self.source,
            "entity_data": self.entity_data,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "CatalogEntry":
        """Deserialize from dict."""
        return cls(
            id=data["id"],
            entity_type=EntityType(data["entity_type"]),
            name=data["name"],
            version=data.get("version", "0.0.0"),
            author=data.get("author", ""),
            description=data.get("description", ""),
            tags=data.get("tags", []),
            familiar_version=data.get("familiar_version", ""),
            source=data.get("source", "builtin"),
            entity_data=data.get("entity_data", {}),
        )

    def matches(self, query: str) -> bool:
        """Check if this entry matches a search query (case-insensitive)."""
        q = query.lower()
        return (
            q in self.id.lower()
            or q in self.name.lower()
            or q in self.description.lower()
            or any(q in t.lower() for t in self.tags)
        )


@dataclass
class SpeciesEntry:
    """Species definition for marketplace serialization."""

    key: str
    label: str
    description: str
    personality: str
    baby_preview: list[str]
    voice_directive: str = ""
    evolution_flavor: Optional[dict[str, str]] = None
    sprites: Optional[dict] = None


@dataclass
class JobEntry:
    """Job class definition for marketplace serialization."""

    key: str
    name: str
    icon: str
    description: str
    prompt_fragment: str
    skill_weights: dict[str, float] = field(default_factory=dict)
    species_flavor: dict[str, str] = field(default_factory=dict)
    recommended_connects: list[str] = field(default_factory=list)
    proactive_focus: list[str] = field(default_factory=list)


@dataclass
class SkillEntry:
    """Skill definition for marketplace serialization."""

    key: str
    name: str
    description: str
    tool_names: list[str] = field(default_factory=list)
    category: str = ""


@dataclass
class ToolEntry:
    """Tool definition for marketplace serialization."""

    name: str
    description: str
    skill: str = ""
    category: str = ""
    input_schema: dict = field(default_factory=dict)


@dataclass
class FamiliarBundle:
    """Complete Familiar creation package."""

    name: str
    species_key: str
    job_key: str
    skill_keys: list[str] = field(default_factory=list)
    description: str = ""
    icon: str = ""
    author: str = ""
