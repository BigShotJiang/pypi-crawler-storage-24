# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Unified Marketplace — catalog, entities, and validation for all entity types.
"""

from .catalog import MarketplaceCatalog
from .entities import (
    CatalogEntry,
    EntityType,
    FamiliarBundle,
    JobEntry,
    SkillEntry,
    SpeciesEntry,
    ToolEntry,
)
from .validation import check_compatibility, validate_package

__all__ = [
    "CatalogEntry",
    "EntityType",
    "FamiliarBundle",
    "JobEntry",
    "MarketplaceCatalog",
    "SkillEntry",
    "SpeciesEntry",
    "ToolEntry",
    "check_compatibility",
    "validate_package",
]
