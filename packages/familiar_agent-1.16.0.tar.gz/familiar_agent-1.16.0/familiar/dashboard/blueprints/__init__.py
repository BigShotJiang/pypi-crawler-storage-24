# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# Licensed under the MIT License

"""Blueprint registration — imports and registers all route blueprints."""

from __future__ import annotations

from flask import Flask


def register_all_blueprints(app: Flask) -> None:
    """Register all dashboard blueprints with the Flask app.

    Called once from app.py after Flask init. Blueprints are imported
    lazily here so import errors in one feature don't crash the whole
    dashboard.
    """
    blueprints = []

    # Import each blueprint — wrapped in try/except so a broken
    # feature module doesn't prevent the dashboard from starting.
    try:
        from .status import bp as status_bp
        blueprints.append(status_bp)
    except ImportError as e:
        app.logger.warning("Failed to load status blueprint: %s", e)

    try:
        from .nonprofit import bp as nonprofit_bp
        blueprints.append(nonprofit_bp)
    except ImportError as e:
        app.logger.warning("Failed to load nonprofit blueprint: %s", e)

    try:
        from .social_worker import bp as social_worker_bp
        blueprints.append(social_worker_bp)
    except ImportError as e:
        app.logger.warning("Failed to load social_worker blueprint: %s", e)

    try:
        from .email import bp as email_bp
        blueprints.append(email_bp)
    except ImportError as e:
        app.logger.warning("Failed to load email blueprint: %s", e)

    try:
        from .connect import bp as connect_bp
        blueprints.append(connect_bp)
    except ImportError as e:
        app.logger.warning("Failed to load connect blueprint: %s", e)

    try:
        from .mesh import bp as mesh_bp
        blueprints.append(mesh_bp)
    except ImportError as e:
        app.logger.warning("Failed to load mesh blueprint: %s", e)

    try:
        from .server import bp as server_bp
        blueprints.append(server_bp)
    except ImportError as e:
        app.logger.warning("Failed to load server blueprint: %s", e)

    try:
        from .onboard import bp as onboard_bp
        blueprints.append(onboard_bp)
    except ImportError as e:
        app.logger.warning("Failed to load onboard blueprint: %s", e)

    try:
        from .activity import bp as activity_bp
        blueprints.append(activity_bp)
    except ImportError as e:
        app.logger.warning("Failed to load activity blueprint: %s", e)

    try:
        from .chat import bp as chat_bp
        blueprints.append(chat_bp)
    except ImportError as e:
        app.logger.warning("Failed to load chat blueprint: %s", e)

    try:
        from .memory import bp as memory_bp
        blueprints.append(memory_bp)
    except ImportError as e:
        app.logger.warning("Failed to load memory blueprint: %s", e)

    try:
        from .workspace import bp as workspace_bp
        blueprints.append(workspace_bp)
    except ImportError as e:
        app.logger.warning("Failed to load workspace blueprint: %s", e)

    try:
        from .media import bp as media_bp
        blueprints.append(media_bp)
    except ImportError as e:
        app.logger.warning("Failed to load media blueprint: %s", e)

    try:
        from .gallery import bp as gallery_bp
        blueprints.append(gallery_bp)
    except ImportError as e:
        app.logger.warning("Failed to load gallery blueprint: %s", e)

    try:
        from .skills import bp as skills_bp
        blueprints.append(skills_bp)
    except ImportError as e:
        app.logger.warning("Failed to load skills blueprint: %s", e)

    try:
        from .misc import bp as misc_bp
        blueprints.append(misc_bp)
    except ImportError as e:
        app.logger.warning("Failed to load misc blueprint: %s", e)

    try:
        from .settings import bp as settings_bp
        blueprints.append(settings_bp)
    except ImportError as e:
        app.logger.warning("Failed to load settings blueprint: %s", e)

    for bp in blueprints:
        app.register_blueprint(bp)

    app.logger.info("Registered %d blueprint(s)", len(blueprints))
