# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# Licensed under the MIT License

"""Status & version routes — /api/status, /api/version/*, /api/provider-health."""

from __future__ import annotations

from datetime import datetime

from flask import Blueprint, jsonify

from ..auth import require_auth
from ..helpers import get_agent

bp = Blueprint("status", __name__)


def _get_uptime() -> str:
    """Get system uptime."""
    try:
        with open("/proc/uptime") as f:
            seconds = float(f.read().split()[0])
            days = int(seconds // 86400)
            hours = int((seconds % 86400) // 3600)
            mins = int((seconds % 3600) // 60)
            return f"{days}d {hours}h {mins}m"
    except Exception:
        return "unknown"


@bp.route("/api/status")
@require_auth
def api_status():
    """Get system status."""
    agent = get_agent()
    status = agent.get_status()
    status["timestamp"] = datetime.now().isoformat()
    status["uptime"] = _get_uptime()
    return jsonify(status)
