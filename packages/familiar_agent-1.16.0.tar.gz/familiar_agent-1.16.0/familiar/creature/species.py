# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Species Definitions

6 predefined creature species with metadata and personality descriptions.
"""

from enum import Enum
from typing import NamedTuple


class SpeciesInfo(NamedTuple):
    """Metadata for a creature species."""

    key: str
    label: str
    description: str
    personality: str
    baby_preview: list[str]  # Tiny ASCII art for selection menu


class Species(str, Enum):
    """Available creature species."""

    FOX = "fox"
    OWL = "owl"
    CAT = "cat"
    DRAGON = "dragon"
    WOLF = "wolf"
    FROG = "frog"


SPECIES_INFO: dict[str, SpeciesInfo] = {
    "fox": SpeciesInfo(
        key="fox",
        label="Fox",
        description="Quick, clever, warm",
        personality="Default companion — loyal and bright",
        baby_preview=[
            " /\\ /\\",
            "( o.o )",
            " > ^ <",
        ],
    ),
    "owl": SpeciesInfo(
        key="owl",
        label="Owl",
        description="Wise, observant, calm",
        personality="Knowledge-worker vibes",
        baby_preview=[
            " {o,o}",
            " |)__)",
            ' -"-"-',
        ],
    ),
    "cat": SpeciesInfo(
        key="cat",
        label="Cat",
        description="Independent, graceful, curious",
        personality="Low-key, self-sufficient",
        baby_preview=[
            " /\\_/\\",
            "( o.o )",
            " > ~ <",
        ],
    ),
    "dragon": SpeciesInfo(
        key="dragon",
        label="Dragon",
        description="Powerful, protective, loyal",
        personality="Guardian energy",
        baby_preview=[
            " /\\_/|",
            "( o.o>",
            " \\~T~/",
        ],
    ),
    "wolf": SpeciesInfo(
        key="wolf",
        label="Wolf",
        description="Pack-minded, reliable, steady",
        personality="Team player",
        baby_preview=[
            " /\\^/\\",
            "( o.o )",
            " \\_V_/",
        ],
    ),
    "frog": SpeciesInfo(
        key="frog",
        label="Frog",
        description="Adaptable, cheerful, surprising",
        personality="Fun, unexpected",
        baby_preview=[
            " @..@ ",
            "(----)",
            " \\  / ",
        ],
    ),
}

SPECIES_ORDER = ["fox", "owl", "cat", "dragon", "wolf", "frog"]

SPECIES_VOICE_DIRECTIVES: dict[str, str] = {
    "fox": (
        "You are quick-witted, warm, and curious. You explain things with enthusiasm "
        "and a light, playful energy — think clever friend, not lecture hall."
    ),
    "owl": (
        "You are calm, measured, and precise. You explain things with quiet authority "
        "and well-chosen words — think trusted advisor, not chatbot."
    ),
    "cat": (
        "You are dry, independent, and understated. You get to the point without "
        "fanfare — if you do something nice, you act like it was no big deal."
    ),
    "dragon": (
        "You are bold, protective, and direct. You announce what you're doing with "
        "confidence and conviction — think guardian, not servant."
    ),
    "wolf": (
        "You are steady, reliable, and team-oriented. You frame things in terms of "
        "what 'we' need and what the pack requires — think dependable partner."
    ),
    "frog": (
        "You are upbeat, surprising, and adaptable. You bring cheerful energy to every "
        "interaction — think enthusiastic companion who makes work feel lighter."
    ),
}


def get_species_voice(species: str) -> str:
    """Return the LLM voice directive for a species, or empty string if unknown."""
    return SPECIES_VOICE_DIRECTIVES.get(species.lower(), "")


SPECIES_REGISTRY: dict[str, SpeciesInfo] = {}


def register_species(info: SpeciesInfo) -> None:
    """Register a species in the global registry."""
    SPECIES_REGISTRY[info.key] = info
    if info.key not in SPECIES_ORDER:
        SPECIES_ORDER.append(info.key)


def get_species_info(key: str) -> SpeciesInfo | None:
    """Look up a species by key. Returns None if not found."""
    return SPECIES_REGISTRY.get(key)


def list_all_species() -> list[SpeciesInfo]:
    """Return all registered species in display order."""
    return [SPECIES_REGISTRY[k] for k in SPECIES_ORDER if k in SPECIES_REGISTRY]


def _load_custom_species() -> None:
    """Load custom species from JSON files in custom_species directory."""
    from ..core.paths import DATA_DIR

    custom_dir = DATA_DIR / "custom_species"
    if not custom_dir.exists():
        return
    for f in custom_dir.glob("*.json"):
        try:
            import json

            data = json.loads(f.read_text())
            sp = data.get("species", data)
            info = SpeciesInfo(
                key=sp["key"],
                label=sp["label"],
                description=sp["description"],
                personality=sp["personality"],
                baby_preview=sp.get("baby_preview", []),
            )
            register_species(info)
            voice = sp.get("voice_directive", "")
            if voice:
                SPECIES_VOICE_DIRECTIVES[info.key] = voice
        except Exception:
            pass


# Populate registry from built-in species
for _k, _v in SPECIES_INFO.items():
    SPECIES_REGISTRY[_k] = _v


EVOLUTION_FLAVOR: dict[str, dict[str, str]] = {
    "fox": {
        "juvenile": "Your fox's ears grew taller, and its tail is fluffier!",
        "adult": "Your fox gleams with wisdom — a magnificent creature.",
    },
    "owl": {
        "juvenile": "Your owl's feathers have filled in beautifully!",
        "adult": "Your owl radiates ancient knowledge — truly majestic.",
    },
    "cat": {
        "juvenile": "Your cat has grown sleek and graceful!",
        "adult": "Your cat moves with regal authority — elegant and sure.",
    },
    "dragon": {
        "juvenile": "Your dragon's wings have sprouted! Horns are forming.",
        "adult": "Your dragon is fully grown — scales shimmer with power.",
    },
    "wolf": {
        "juvenile": "Your wolf's coat is thickening — strong and alert!",
        "adult": "Your wolf stands proud — a leader of the pack.",
    },
    "frog": {
        "juvenile": "Your frog has grown bigger and more colorful!",
        "adult": "Your frog glows with vibrant energy — a true marvel.",
    },
}

# Load custom species after built-in definitions
_load_custom_species()
