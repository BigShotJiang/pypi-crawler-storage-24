# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Sprite Renderer

Pure function: sprite grid + color map -> ANSI-colored string lines.
Each non-'.' character becomes a full block character in the mapped color.
"""

from .palette import ansi_fg, ansi_reset

BLOCK = "\u2588"  # █


def render_frame(frame: list[str], colors: dict[str, tuple[int, int, int]]) -> list[str]:
    """Render a sprite frame to ANSI-colored strings.

    Args:
        frame: List of row strings where each char is a role code.
        colors: Mapping of role codes to (R, G, B) tuples.

    Returns:
        List of strings with ANSI escape codes, ready to print.
    """
    result = []
    reset = ansi_reset()
    for row in frame:
        line_parts = []
        for ch in row:
            if ch == ".":
                line_parts.append(" ")
            elif ch in colors:
                r, g, b = colors[ch]
                line_parts.append(f"{ansi_fg(r, g, b)}{BLOCK}{reset}")
            else:
                # Unknown code — render as outline
                line_parts.append(f"{ansi_fg(30, 30, 30)}{BLOCK}{reset}")
        result.append("".join(line_parts))
    return result


def render_frame_plain(frame: list[str]) -> list[str]:
    """Render a sprite frame without colors (for non-color terminals).

    Uses '#' for filled pixels and ' ' for transparent.
    """
    result = []
    for row in frame:
        line_parts = []
        for ch in row:
            if ch == ".":
                line_parts.append(" ")
            else:
                line_parts.append(BLOCK)
        result.append("".join(line_parts))
    return result
