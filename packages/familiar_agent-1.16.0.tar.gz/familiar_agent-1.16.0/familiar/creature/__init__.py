# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Familiar Creature — Tamagotchi Avatar System

A pixel creature that lives in the CLI, evolving through 3 stages
as the relationship deepens.

Public API:
    load_creature()      — Load saved creature or return None
    save_creature()      — Persist creature state to disk
    run_creature_intro() — First-run creature birth sequence
    CreatureDisplay      — Render creature in retro box frame

    # Extracted helpers (used by onboard.py unified flow):
    show_logo, present_constitution, ask_consent, ask_owner_name,
    show_egg, ask_creature_name, ask_species, prompt_color,
    prompt_choice, run_birth_animation, show_channel_info
"""

from .display import CreatureDisplay
from .intro import (
    CreatureIntroResult,
    ask_consent,
    ask_creature_name,
    ask_owner_name,
    ask_species,
    present_constitution,
    prompt_choice,
    prompt_color,
    run_birth_animation,
    run_creature_intro,
    show_channel_info,
    show_egg,
    show_logo,
)
from .state import (
    ActivityState,
    CreatureState,
    EvolutionStage,
    load_creature,
    save_creature,
)

__all__ = [
    "CreatureDisplay",
    "CreatureIntroResult",
    "CreatureState",
    "ActivityState",
    "EvolutionStage",
    "load_creature",
    "save_creature",
    "run_creature_intro",
    "show_logo",
    "present_constitution",
    "ask_consent",
    "ask_owner_name",
    "show_egg",
    "ask_creature_name",
    "ask_species",
    "prompt_color",
    "prompt_choice",
    "run_birth_animation",
    "show_channel_info",
]
