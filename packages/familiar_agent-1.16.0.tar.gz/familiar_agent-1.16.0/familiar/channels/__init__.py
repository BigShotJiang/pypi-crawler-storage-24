# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Familiar Channels

Interfaces for interacting with the agent:
- CLI (command line)
- Telegram
- Discord
- GitHub (notification polling)
- Slack (Socket Mode)
- iMessage (macOS)
- WhatsApp (via bridge)
- Signal (via signal-cli)

Phase 1 (v1.6): Multi-user authentication via auth module
"""

# Phase 1: Channel authentication (import first as it has fewer dependencies)
try:
    from .auth import (
        AuthMode,
        ChannelAuthenticator,
        ChannelType,
        ChannelUser,
        create_authenticator,
        get_user_data_store,
        require_linked,
        require_role,
    )

    HAS_AUTH = True
except ImportError:
    HAS_AUTH = False
    ChannelAuthenticator = None
    ChannelUser = None
    ChannelType = None
    AuthMode = None
    create_authenticator = None
    get_user_data_store = None
    require_linked = None
    require_role = None

# CLI is always available
from .cli import CLIChannel, run_cli

# Optional channels (may not be available on all systems)
try:
    from .telegram import TelegramChannel
except ImportError:
    TelegramChannel = None

try:
    from .discord import DiscordChannel
except ImportError:
    DiscordChannel = None

try:
    from .imessage import iMessageChannel
except ImportError:
    iMessageChannel = None

try:
    from .whatsapp import WhatsAppChannel
except ImportError:
    WhatsAppChannel = None

try:
    from .signal import SignalChannel
except ImportError:
    SignalChannel = None

try:
    from .matrix import MatrixChannel
except ImportError:
    MatrixChannel = None

try:
    from .github import GitHubChannel
except ImportError:
    GitHubChannel = None

try:
    from .slack import SlackChannel
except ImportError:
    SlackChannel = None

try:
    from .mastodon import MastodonChannel
except ImportError:
    MastodonChannel = None

try:
    from .bluesky import BlueskyChannel
except ImportError:
    BlueskyChannel = None

__all__ = [
    # Channels
    "CLIChannel",
    "run_cli",
    "TelegramChannel",
    "DiscordChannel",
    "iMessageChannel",
    "WhatsAppChannel",
    "SignalChannel",
    "MatrixChannel",
    "GitHubChannel",
    "SlackChannel",
    "MastodonChannel",
    "BlueskyChannel",
    # Authentication (Phase 1)
    "ChannelAuthenticator",
    "ChannelUser",
    "ChannelType",
    "AuthMode",
    "create_authenticator",
    "get_user_data_store",
    "require_linked",
    "require_role",
    "HAS_AUTH",
]
