"""llmpm — LLM Package Manager."""

__version__ = "3.1.3"
__author__ = "llmpm contributors"
