from pydantic import BaseModel, Field, model_validator
from typing import Annotated, Literal, Self
from nexo.enums.system import SystemRole, FullSystemRoleMixin
from nexo.schemas.security.enums import Domain, DomainMixin
from nexo.schemas.error.enums import ErrorCode
from ..enums.user import IdentifierType
from ..mixins.authentication import OrganizationKey
from ..mixins.user import UserIdentifier


class UserCredentials(BaseModel):
    identifier_type: Annotated[
        Literal[IdentifierType.EMAIL, IdentifierType.USERNAME],
        Field(..., description="Identifier's Type"),
    ]
    identifier_value: Annotated[str, Field(..., description="Identifier's Value")]
    password: Annotated[str, Field(..., description="Password")]


class OldOrganizationCredentials(
    OrganizationKey,
    FullSystemRoleMixin[Literal[SystemRole.ADMINISTRATOR, SystemRole.USER]],
):
    @model_validator(mode="after")
    def validate_components(self) -> Self:
        if self.system_role is SystemRole.ADMINISTRATOR:
            if self.organization_key is not None:
                raise ValueError(
                    ErrorCode.BAD_REQUEST,
                    "Organization Key must be None for Administrator System Role",
                )
        elif self.system_role is SystemRole.USER:
            if self.organization_key is None:
                raise ValueError(
                    ErrorCode.BAD_REQUEST,
                    "Organization Key can not be None for User System Role",
                )
        return self


class OrganizationCredentials(
    OrganizationKey,
    DomainMixin[Domain],
):
    @model_validator(mode="after")
    def validate_components(self) -> Self:
        if (
            self.domain in [Domain.PERSONAL, Domain.SYSTEM]
            and self.organization_key is not None
        ):
            raise ValueError(
                ErrorCode.BAD_REQUEST,
                "Organization Key must be None for Personal and System domain",
            )
        elif self.domain is Domain.TENANT and self.organization_key is None:
            raise ValueError(
                ErrorCode.BAD_REQUEST,
                "Organization Key can not be None for Tenant domain",
            )
        return self


class OldAuthenticateData(
    UserCredentials,
    OldOrganizationCredentials,
):
    pass


class AuthenticateData(
    UserCredentials,
    OrganizationCredentials,
):
    pass


class RegularAuthenticationParameters(OrganizationCredentials):
    identifier: Annotated[UserIdentifier, Field(..., description="User's Identifier")]
    password: Annotated[str, Field(..., description="Password")]

    @classmethod
    def from_old_data(cls, data: OldAuthenticateData) -> Self:
        return cls(
            domain=(
                Domain.SYSTEM
                if data.system_role is SystemRole.ADMINISTRATOR
                else Domain.PERSONAL
            ),
            organization_key=data.organization_key,
            identifier=UserIdentifier(
                type=data.identifier_type,
                value=data.identifier_value,
            ),
            password=data.password,
        )

    @classmethod
    def from_data(cls, data: AuthenticateData) -> Self:
        return cls(
            domain=data.domain,
            organization_key=data.organization_key,
            identifier=UserIdentifier(
                type=data.identifier_type,
                value=data.identifier_value,
            ),
            password=data.password,
        )


class RefreshAuthenticationParameters(BaseModel):
    refresh_token: Annotated[str, Field(..., description="Refresh Token")]


AuthenticationParameters = (
    RegularAuthenticationParameters | RefreshAuthenticationParameters
)
