from enum import Enum


class LogMode(str, Enum):
    DEFAULT = "default"
    ALL = "all"
    NONE = "none"
