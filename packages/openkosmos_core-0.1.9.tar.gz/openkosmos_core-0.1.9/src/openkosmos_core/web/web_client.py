from abc import ABC

import httpx
from openkosmos_core.setting import Setting
from openkosmos_core.web.model import ClientConfig

log = Setting.logger("web")


class WebClientConfig(ClientConfig):
    pass


class WebClientResponse:
    pass


class WebClientCallback:
    pass


class WebClientExecutor(ABC):
    def __init__(self):
        with httpx.Client() as client:
            response = client.get("")
            print(response.status_code)
            print(response.text)


class WebClient:
    def __init__(self, config: WebClientConfig):
        self._api_config = config
        self._callback: WebClientCallback = WebClientCallback()

    def callback(self, callback: WebClientCallback):
        self._callback = callback
        return self

    def api_config(self):
        return self._api_config

    def get(self, path: str = None, callback: WebClientCallback = None):
        pass

    def post(self, path: str = None, callback: WebClientCallback = None):
        pass

    def put(self, path: str = None, callback: WebClientCallback = None):
        pass

    def delete(self, path: str = None, callback: WebClientCallback = None):
        pass
