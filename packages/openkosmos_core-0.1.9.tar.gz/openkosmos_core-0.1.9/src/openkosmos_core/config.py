import json
import os
from typing import TypeVar, Type

import dotenv
import yaml

from openkosmos_core.auth import AuthTokenConfig
from openkosmos_core.common.model import BaseConfig
from openkosmos_core.web.rest_client import RestClientConfig

CONFIG_T = TypeVar('CONFIG_T', bound=BaseConfig)


class Config:
    __instance = None

    @classmethod
    def instance(cls, instance=None):
        if instance is not None:
            Config.__instance = instance
        return Config.__instance

    def __init__(self, config_file=None, load_env=True, as_instance=True):
        if load_env:
            dotenv.load_dotenv()
        self._config = self.load(config_file)
        if as_instance:
            Config.instance(self)

    def load(self, config_file=None):
        c_file = config_file
        if c_file is None:
            c_file = os.getenv("KOSMOS_CONFIG", default="config.yml")
        with open(c_file, "r", encoding="utf-8") as f:
            self._config = yaml.load(f, Loader=yaml.FullLoader)
            return self._config

    def save(self, config_file=None):
        c_file = config_file
        if c_file is None:
            c_file = os.getenv("KOSMOS_CONFIG", default="config.yml")
        with open(c_file, "w", encoding="utf-8") as f:
            yaml.dump(self._config, f, indent=2)

    def get(self, name: str | list[str], config_type: Type[CONFIG_T] = None) -> CONFIG_T:
        if type(name) is str:
            last = self._config.get(name)
        else:
            last = self._config
            for n in name:
                last = last.get(n)

        if config_type is None:
            return last
        else:
            return config_type(**last)

    def get_auth_config(self, name: str | list[str] = "auth") -> AuthTokenConfig:
        return self.get(name, AuthTokenConfig)

    def get_rest_client_config(self, name: str | list[str] = "rest_client") -> RestClientConfig:
        return self.get(name, RestClientConfig)

    def __str__(self):
        return json.dumps(self._config, indent=3, ensure_ascii=False)
