---
name: deploy-app
description: Deploy a web app on the Datatailr platform using the Python SDK. Supports Streamlit, Dash, Flask, FastAPI, and Panel frameworks. Use when the user asks to create and deploy an app, dashboard, or web application on Datatailr, or to make existing code run on Datatailr / dt.
---

# Deploy an App on Datatailr

## Overview

Datatailr deploys apps as containerized jobs. You write a standard web app using any supported framework, then use the `datatailr` Python SDK to deploy it. The SDK handles packaging, image building, and scheduling. The SDK is already installed in the workspace -- do not look for it.

## Project layout

The deploy script must live **outside** the app module directory. Do not use hyphens in directory names -- use underscores.

```
my_project/
├── my_app/
│   ├── __init__.py
│   └── app.py        # App code
└── deploy.py         # Deploy script (outside my_app/)
```

## Deploy script pattern

Import the app **module** and pass it as the entrypoint:

```python
# deploy.py
import my_app.app as entrypoint
from datatailr import App, Resources

app = App(
    name="My App Name",
    entrypoint=entrypoint,
    framework="<framework>",
    resources=Resources(memory="2g", cpu=1),
    python_requirements=["<framework>", "<other deps>"],
)
app.run()
```

Key parameters:
- `name`: human-readable name for the app on the platform.
- `entrypoint`: the app module (imported, not a string). For Streamlit, can also be the `main` function.
- `framework`: one of `"streamlit"`, `"dash"`, `"flask"`, `"fastapi"`, `"panel"`.
- `resources`: CPU and memory for the container. Defaults to 128MB / 0.25 CPU.
- `python_requirements`: list of pip packages. Must include the framework itself.
- `app.run()` saves the definition AND starts the app. Use `app.save()` to only save.
- `python_version`: Python version for the container image (default `"auto"` -- auto-detects from your environment).
- `build_script_pre` / `build_script_post`: shell commands for the Docker image build. If the user needs to install OS packages or system libraries, see [build-scripts.md](../build-scripts.md) for formatting details.
- `env_vars`: dict of environment variables passed to the running container.
- `run_as` / `acl`: leave unset to use default permissions. Only if the user explicitly requests access restrictions, see [acl.md](../acl.md). If their request is vague (e.g., "restrict access"), ask who should be able to see, edit, and operate the job before proceeding.

## Framework-specific details

Read **only** the file for the framework being deployed:

- Streamlit: see [streamlit.md](streamlit.md)
- Dash: see [dash.md](dash.md)
- Flask: see [flask.md](flask.md)
- FastAPI: see [fastapi.md](fastapi.md)
- Panel: see [panel.md](panel.md)

## Deploying

Run the deploy script:

```bash
python deploy.py
```

The SDK will output the job name and a URL to view the deployment status. Advise the user to go to the "App Launcher" page to see the app. Do not print the full app code content at the end of the interaction.

## Checklist

- [ ] App code follows the framework-specific pattern (see the framework file)
- [ ] Deploy script is outside the app module directory
- [ ] Deploy script imports the app module (not a string path)
- [ ] `framework` is explicitly set
- [ ] `python_requirements` includes the framework and all dependencies
- [ ] No hyphens in directory names (use underscores)

## Platform environment variables

The platform sets these environment variables in every running app container. Use them when the app needs to know its runtime context:

- `DATATAILR_JOB_NAME`: name of the running job.
- `DATATAILR_USER`: username running the job.
- `DATATAILR_JOB_TYPE`: always `app` for apps.
- `DATATAILR_DOMAIN`: platform domain (useful for constructing URLs).

Dash apps also get `DASH_REQUESTS_PATHNAME_PREFIX` for URL routing (see [dash.md](dash.md)).

## Calling other services

If the app needs to fetch data from a Datatailr service, see [service-communication.md](../service-communication.md) for how to construct the internal URL and authenticate.
