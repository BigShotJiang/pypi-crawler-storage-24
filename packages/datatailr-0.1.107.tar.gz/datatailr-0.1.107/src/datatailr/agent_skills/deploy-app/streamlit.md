# Streamlit

## App code

Write a standard Streamlit app with a `main()` function. No Datatailr-specific code needed.

```python
# my_app/app.py
import streamlit as st

def main():
    st.title("My App")
    st.write("Hello from Datatailr!")

if __name__ == "__main__":
    main()
```

Multi-page apps: use the `pages/` subdirectory convention inside the app module.

## Deploy script

For Streamlit, you can pass either the module or the `main` function as entrypoint:

```python
# deploy.py
import my_app.app as entrypoint
from datatailr import App, Resources

app = App(
    name="My Streamlit App",
    entrypoint=entrypoint,
    framework="streamlit",
    resources=Resources(memory="2g", cpu=1),
    python_requirements=["streamlit"],
)
app.run()
```

## Requirements

Always include `"streamlit"`. Add any other imports your app uses (e.g., `"pandas"`, `"requests"`, `"plotly"`).

## Local testing

```bash
streamlit run my_app/app.py
```
