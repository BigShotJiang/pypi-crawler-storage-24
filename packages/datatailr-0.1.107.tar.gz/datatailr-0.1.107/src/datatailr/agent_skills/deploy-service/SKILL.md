---
name: deploy-service
description: Deploy a long-running service on the Datatailr platform using the Python SDK. Services are background processes like API servers, message consumers, or workers that auto-restart on exit. Use when the user asks to deploy a service, API, or background worker on Datatailr, or to make existing service code run on Datatailr / dt.
---

# Deploy a Service on Datatailr

## Overview

A Datatailr service is a long-running background process (API server, message consumer, worker). It auto-restarts if it exits. The `datatailr` Python SDK handles packaging, image building, and scheduling. The SDK is already installed in the workspace -- do not look for it.

## Project layout

The deploy script must live **outside** the service module directory. Do not use hyphens in directory names -- use underscores.

```
my_project/
├── my_service/
│   ├── __init__.py
│   └── app.py        # Service code
└── deploy.py         # Deploy script (outside my_service/)
```

## Service code

Write a module with a `main(port)` function that starts the service. The platform calls `main` with the assigned port.

```python
# my_service/app.py
from flask import Flask, jsonify, request

app = Flask(__name__)

@app.route("/")
def index():
    return jsonify({"status": "running"})

@app.route("/__health_check__.html")
def health_check():
    return "OK\n"

def main(port):
    app.run("0.0.0.0", port=int(port), debug=False)

if __name__ == "__main__":
    main(1024)
```

Key points:
- `main(port)` is required -- the platform passes the port to bind to.
- Include a `/__health_check__.html` endpoint returning `"OK"` for platform health monitoring.
- The service can use any HTTP framework (Flask, FastAPI, etc.) or no framework at all.

## Deploy script

Import the `main` function (not the module) and use the `Service` class. No `framework` parameter.

```python
# deploy.py
from my_service.app import main
from datatailr import Service, Resources

service = Service(
    name="My Service",
    entrypoint=main,
    resources=Resources(memory="2g", cpu=1),
    python_requirements=["flask"],
)
service.run()
```

Key parameters:
- `name`: human-readable name on the platform.
- `entrypoint`: the `main` function (imported callable, not a string).
- `resources`: CPU and memory for the container. Defaults to 128MB / 0.25 CPU.
- `python_requirements`: list of pip packages the service needs.
- `service.run()` saves the definition AND starts it. Use `service.save()` to only save.
- `python_version`: Python version for the container image (default `"auto"` -- auto-detects from your environment).
- `build_script_pre` / `build_script_post`: shell commands for the Docker image build. If the user needs to install OS packages or system libraries, see [build-scripts.md](../build-scripts.md) for formatting details.
- `env_vars`: dict of environment variables passed to the running container.
- `run_as` / `acl`: leave unset to use default permissions. Only if the user explicitly requests access restrictions, see [acl.md](../acl.md). If their request is vague (e.g., "restrict access"), ask who should be able to see, edit, and operate the job before proceeding.

## Deploying

Run the deploy script:

```bash
python deploy.py
```

## Calling this service from other jobs

Once deployed, the service is reachable from any other Datatailr job (app, workflow, add-in, or another service) at `http://<normalized-name>`. The name is derived from the `name` parameter: lowercased, non-alphanumeric characters replaced with hyphens (e.g., `"My Service"` becomes `http://my-service`).

For full details on constructing URLs, authentication patterns, and naming conventions, see [service-communication.md](../service-communication.md).

## Checklist

- [ ] Service has a `main(port)` function
- [ ] Service has a `/__health_check__.html` endpoint returning `"OK"`
- [ ] Deploy script is outside the service module directory
- [ ] Deploy script imports the `main` function (not a string path)
- [ ] `python_requirements` includes all dependencies
- [ ] No hyphens in directory names (use underscores)

## Platform environment variables

The platform sets these environment variables in every running service container. Use them when the service needs to know its runtime context:

- `DATATAILR_JOB_NAME`: name of the running service.
- `DATATAILR_USER`: username running the service.
- `DATATAILR_JOB_TYPE`: always `service` for services.
- `DATATAILR_DOMAIN`: platform domain (useful for constructing URLs).
