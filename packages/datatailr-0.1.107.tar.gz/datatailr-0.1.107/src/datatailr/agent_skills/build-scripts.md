# Customizing the container image with build scripts

Every Datatailr job type (`App`, `Service`, `ExcelAddin`, `@workflow`) accepts two optional parameters for running shell commands during the Docker image build:

- `build_script_pre`: runs **before** pip install -- use for OS packages, system libraries, etc.
- `build_script_post`: runs **after** pip install -- use for post-install configuration, compiling extensions, etc.

The debian slim base image is very minimal, so if you plan to use any OS packages at runtime, you must install them in the build script.

## Formatting rules

Each script is a **single string**. The build system writes the string to a `.sh` file using `echo -e`, so escape sequences like `\n` are interpreted as real newlines.

### Multi-line: separate commands with literal `\n`

```python
build_script_pre="apt-get update\napt-get install -y libpq-dev libssl-dev\nrm -rf /var/lib/apt/lists/*"
```

### Single-line: chain with `&&`

```python
build_script_pre="apt-get update && apt-get install -y libpq-dev"
```

### File path: point to a `.sh` script

If the value is a path to an existing file, the SDK reads its contents automatically:

```python
build_script_pre="scripts/pre_build.sh"
```

This is the cleanest option for complex scripts.

## Example deploy script with build scripts

```python
from datatailr import App, Resources

app = App(
    name="My App",
    entrypoint=entrypoint,
    framework="streamlit",
    resources=Resources(memory="2g", cpu=1),
    python_requirements=["streamlit", "psycopg2"],
    build_script_pre="apt-get update\napt-get install -y libpq-dev",
)
app.run()
```

## Common use cases

| Need | `build_script_pre` example |
|---|---|
| PostgreSQL client libs | `"apt-get update\napt-get install -y libpq-dev"` |
| OpenCV / image processing | `"apt-get update\napt-get install -y libgl1-mesa-glx libglib2.0-0"` |
| Git (for pip git deps) | `"apt-get update\napt-get install -y git"` |
| ODBC drivers | `"apt-get update\napt-get install -y unixodbc-dev"` |
| Custom CA certificates | `"cp /tmp/my-ca.crt /usr/local/share/ca-certificates/\nupdate-ca-certificates"` |
