from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import Literal, cast






T = TypeVar("T", bound="CreatePlanDetail")



@_attrs_define
class CreatePlanDetail:
    """ Detail for a create_plan tool call.

        Attributes:
            query (str): Planning query (truncated to 80 chars)
            tool (Literal['create_plan'] | Unset):  Default: 'create_plan'.
     """

    query: str
    tool: Literal['create_plan'] | Unset = 'create_plan'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        query = self.query

        tool = self.tool


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "query": query,
        })
        if tool is not UNSET:
            field_dict["tool"] = tool

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        query = d.pop("query")

        tool = cast(Literal['create_plan'] | Unset , d.pop("tool", UNSET))
        if tool != 'create_plan'and not isinstance(tool, Unset):
            raise ValueError(f"tool must match const 'create_plan', got '{tool}'")

        create_plan_detail = cls(
            query=query,
            tool=tool,
        )


        create_plan_detail.additional_properties = d
        return create_plan_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
