from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.review_llm_config_api_type import ReviewLLMConfigApiType
from ..types import UNSET, Unset






T = TypeVar("T", bound="ReviewLLMConfig")



@_attrs_define
class ReviewLLMConfig:
    r""" Configuration for ReviewLLM - reviews agent draft answers against source material.

        Attributes:
            api_type (ReviewLLMConfigApiType | Unset): The inference type (local or remote). Default:
                ReviewLLMConfigApiType.REMOTE.
            enable_thinking (bool | Unset): Enable reasoning/thinking mode. Default: False.
            model_name (str | Unset): The model for reviewing agent draft answers. Defaults to reasoning model. Default:
                'dummy'.
            system_instruction (str | Unset): System instruction for reviewing agent draft answers against source material.
                Default: 'You are reviewing a draft answer prepared by a research agent. The draft was written based on
                summaries, but you now have access to the full source material.\n\nYour task:\n1. Review the draft answer
                against the source material provided\n2. Verify claims are supported by the sources\n3. Correct any inaccuracies
                or unsupported statements\n4. Add any important details from the sources that were missed\n5. Maintain formal,
                objective tone appropriate for professional contexts\n\nIf information is not found in the sources but the draft
                answer is based on web search results or general knowledge, preserve it and ensure it is clearly labelled as
                such. Only flag missing source support for claims that purport to come from the documents.\nDo not add inline
                citation markers - the system handles citations automatically.'.
            temperature (float | Unset): Temperature for review. Default: 0.1.
            max_tokens (int | Unset): Maximum tokens for review response. Default: 5000.
            max_char_size_to_answer (int | Unset): Maximum character size for review context. Default: 200000.
     """

    api_type: ReviewLLMConfigApiType | Unset = ReviewLLMConfigApiType.REMOTE
    enable_thinking: bool | Unset = False
    model_name: str | Unset = 'dummy'
    system_instruction: str | Unset = 'You are reviewing a draft answer prepared by a research agent. The draft was written based on summaries, but you now have access to the full source material.\n\nYour task:\n1. Review the draft answer against the source material provided\n2. Verify claims are supported by the sources\n3. Correct any inaccuracies or unsupported statements\n4. Add any important details from the sources that were missed\n5. Maintain formal, objective tone appropriate for professional contexts\n\nIf information is not found in the sources but the draft answer is based on web search results or general knowledge, preserve it and ensure it is clearly labelled as such. Only flag missing source support for claims that purport to come from the documents.\nDo not add inline citation markers - the system handles citations automatically.'
    temperature: float | Unset = 0.1
    max_tokens: int | Unset = 5000
    max_char_size_to_answer: int | Unset = 200000
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        api_type: str | Unset = UNSET
        if not isinstance(self.api_type, Unset):
            api_type = self.api_type.value


        enable_thinking = self.enable_thinking

        model_name = self.model_name

        system_instruction = self.system_instruction

        temperature = self.temperature

        max_tokens = self.max_tokens

        max_char_size_to_answer = self.max_char_size_to_answer


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if api_type is not UNSET:
            field_dict["API_TYPE"] = api_type
        if enable_thinking is not UNSET:
            field_dict["ENABLE_THINKING"] = enable_thinking
        if model_name is not UNSET:
            field_dict["MODEL_NAME"] = model_name
        if system_instruction is not UNSET:
            field_dict["SYSTEM_INSTRUCTION"] = system_instruction
        if temperature is not UNSET:
            field_dict["TEMPERATURE"] = temperature
        if max_tokens is not UNSET:
            field_dict["MAX_TOKENS"] = max_tokens
        if max_char_size_to_answer is not UNSET:
            field_dict["MAX_CHAR_SIZE_TO_ANSWER"] = max_char_size_to_answer

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _api_type = d.pop("API_TYPE", UNSET)
        api_type: ReviewLLMConfigApiType | Unset
        if isinstance(_api_type,  Unset):
            api_type = UNSET
        else:
            api_type = ReviewLLMConfigApiType(_api_type)




        enable_thinking = d.pop("ENABLE_THINKING", UNSET)

        model_name = d.pop("MODEL_NAME", UNSET)

        system_instruction = d.pop("SYSTEM_INSTRUCTION", UNSET)

        temperature = d.pop("TEMPERATURE", UNSET)

        max_tokens = d.pop("MAX_TOKENS", UNSET)

        max_char_size_to_answer = d.pop("MAX_CHAR_SIZE_TO_ANSWER", UNSET)

        review_llm_config = cls(
            api_type=api_type,
            enable_thinking=enable_thinking,
            model_name=model_name,
            system_instruction=system_instruction,
            temperature=temperature,
            max_tokens=max_tokens,
            max_char_size_to_answer=max_char_size_to_answer,
        )


        review_llm_config.additional_properties = d
        return review_llm_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
