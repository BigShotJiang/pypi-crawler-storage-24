from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="LoginRequest")



@_attrs_define
class LoginRequest:
    """ Unified login request for users and agents.

    For local users: email + signature + timestamp
    For SSO users: email + signature + timestamp + sso_token
    For agents: agent_ext_id + signature + timestamp

    Exactly one of ``email`` or ``agent_ext_id`` must be provided.

    Authentication flow:
    1. Client derives Ed25519 keypair from password (users) or has stored key (agents)
    2. Client signs "identity|timestamp" with Ed25519 private key
    3. Server verifies signature using stored Ed25519 public key

        Attributes:
            signature (str):
            timestamp (int):
            email (None | str | Unset):
            agent_ext_id (None | str | Unset):
            sso_token (None | str | Unset):
     """

    signature: str
    timestamp: int
    email: None | str | Unset = UNSET
    agent_ext_id: None | str | Unset = UNSET
    sso_token: None | str | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        signature = self.signature

        timestamp = self.timestamp

        email: None | str | Unset
        if isinstance(self.email, Unset):
            email = UNSET
        else:
            email = self.email

        agent_ext_id: None | str | Unset
        if isinstance(self.agent_ext_id, Unset):
            agent_ext_id = UNSET
        else:
            agent_ext_id = self.agent_ext_id

        sso_token: None | str | Unset
        if isinstance(self.sso_token, Unset):
            sso_token = UNSET
        else:
            sso_token = self.sso_token


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "signature": signature,
            "timestamp": timestamp,
        })
        if email is not UNSET:
            field_dict["email"] = email
        if agent_ext_id is not UNSET:
            field_dict["agent_ext_id"] = agent_ext_id
        if sso_token is not UNSET:
            field_dict["sso_token"] = sso_token

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        signature = d.pop("signature")

        timestamp = d.pop("timestamp")

        def _parse_email(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        email = _parse_email(d.pop("email", UNSET))


        def _parse_agent_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        agent_ext_id = _parse_agent_ext_id(d.pop("agent_ext_id", UNSET))


        def _parse_sso_token(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        sso_token = _parse_sso_token(d.pop("sso_token", UNSET))


        login_request = cls(
            signature=signature,
            timestamp=timestamp,
            email=email,
            agent_ext_id=agent_ext_id,
            sso_token=sso_token,
        )

        return login_request

