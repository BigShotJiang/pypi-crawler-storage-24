from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import Literal, cast






T = TypeVar("T", bound="AskUserDetail")



@_attrs_define
class AskUserDetail:
    """ Detail for an ask_user tool call.

        Attributes:
            question (str): Question for the user (truncated to 80 chars)
            tool (Literal['ask_user'] | Unset):  Default: 'ask_user'.
     """

    question: str
    tool: Literal['ask_user'] | Unset = 'ask_user'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        question = self.question

        tool = self.tool


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "question": question,
        })
        if tool is not UNSET:
            field_dict["tool"] = tool

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        question = d.pop("question")

        tool = cast(Literal['ask_user'] | Unset , d.pop("tool", UNSET))
        if tool != 'ask_user'and not isinstance(tool, Unset):
            raise ValueError(f"tool must match const 'ask_user', got '{tool}'")

        ask_user_detail = cls(
            question=question,
            tool=tool,
        )


        ask_user_detail.additional_properties = d
        return ask_user_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
