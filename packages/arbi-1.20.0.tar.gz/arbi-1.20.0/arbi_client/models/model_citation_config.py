from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="ModelCitationConfig")



@_attrs_define
class ModelCitationConfig:
    """ 
        Attributes:
            sim_threashold (float | Unset): Minimum similarity score for a chunk to be cited. Default: 0.5.
            min_char_size_to_answer (int | Unset): Minimum character length to be considered as a statement for citation.
                Default: 30.
            max_numb_citations (int | Unset): Maximum number of citations to return per statement. Default: 5.
            citation_instruction (str | Unset): Instruction for the <Instruct> tag when scoring chunks for citation
                attribution. Default: 'Judge whether the passage contains evidence that directly supports or sources the claim
                made in the query. Only answer yes if the passage provides the basis for the statement'.
     """

    sim_threashold: float | Unset = 0.5
    min_char_size_to_answer: int | Unset = 30
    max_numb_citations: int | Unset = 5
    citation_instruction: str | Unset = 'Judge whether the passage contains evidence that directly supports or sources the claim made in the query. Only answer yes if the passage provides the basis for the statement'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        sim_threashold = self.sim_threashold

        min_char_size_to_answer = self.min_char_size_to_answer

        max_numb_citations = self.max_numb_citations

        citation_instruction = self.citation_instruction


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if sim_threashold is not UNSET:
            field_dict["SIM_THREASHOLD"] = sim_threashold
        if min_char_size_to_answer is not UNSET:
            field_dict["MIN_CHAR_SIZE_TO_ANSWER"] = min_char_size_to_answer
        if max_numb_citations is not UNSET:
            field_dict["MAX_NUMB_CITATIONS"] = max_numb_citations
        if citation_instruction is not UNSET:
            field_dict["CITATION_INSTRUCTION"] = citation_instruction

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        sim_threashold = d.pop("SIM_THREASHOLD", UNSET)

        min_char_size_to_answer = d.pop("MIN_CHAR_SIZE_TO_ANSWER", UNSET)

        max_numb_citations = d.pop("MAX_NUMB_CITATIONS", UNSET)

        citation_instruction = d.pop("CITATION_INSTRUCTION", UNSET)

        model_citation_config = cls(
            sim_threashold=sim_threashold,
            min_char_size_to_answer=min_char_size_to_answer,
            max_numb_citations=max_numb_citations,
            citation_instruction=citation_instruction,
        )


        model_citation_config.additional_properties = d
        return model_citation_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
