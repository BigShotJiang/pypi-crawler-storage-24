from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.summarise_llm_config_api_type import SummariseLLMConfigApiType
from ..types import UNSET, Unset






T = TypeVar("T", bound="SummariseLLMConfig")



@_attrs_define
class SummariseLLMConfig:
    r""" Configuration for conversation summarisation. Used for compaction and general summaries.

        Attributes:
            api_type (SummariseLLMConfigApiType | Unset): The inference type (local or remote). Default:
                SummariseLLMConfigApiType.REMOTE.
            enable_thinking (bool | Unset): Enable reasoning/thinking mode. Default: False.
            model_name (str | Unset): The model for conversation summarisation. Defaults to reasoning model. Default:
                'dummy'.
            system_instruction (str | Unset): System instruction for conversation summarisation. Default: "You are a
                conversation summariser. Condense the conversation history into a concise summary that preserves:\n- Key
                decisions and conclusions reached\n- Specific names, dates, numbers, and document references\n- Open questions
                and unresolved items\n- The user's goals and constraints\n\nWrite in past tense, third person. Be specific, not
                vague. Do not omit important details in favour of brevity.".
            temperature (float | Unset): Low temperature for factual summarisation. Default: 0.1.
            max_tokens (int | Unset): Maximum tokens for the summary output. Default: 2000.
            max_char_size_to_answer (int | Unset): Maximum character size of conversation history to summarise. Default:
                200000.
            compaction_threshold_tokens (int | Unset): Auto-compact when thread tokens exceed this threshold. 0 = disabled.
                Default: 0.
            compaction_keep_recent (int | Unset): Number of recent messages to preserve verbatim in the compaction summary.
                Default: 4.
     """

    api_type: SummariseLLMConfigApiType | Unset = SummariseLLMConfigApiType.REMOTE
    enable_thinking: bool | Unset = False
    model_name: str | Unset = 'dummy'
    system_instruction: str | Unset = "You are a conversation summariser. Condense the conversation history into a concise summary that preserves:\n- Key decisions and conclusions reached\n- Specific names, dates, numbers, and document references\n- Open questions and unresolved items\n- The user's goals and constraints\n\nWrite in past tense, third person. Be specific, not vague. Do not omit important details in favour of brevity."
    temperature: float | Unset = 0.1
    max_tokens: int | Unset = 2000
    max_char_size_to_answer: int | Unset = 200000
    compaction_threshold_tokens: int | Unset = 0
    compaction_keep_recent: int | Unset = 4
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        api_type: str | Unset = UNSET
        if not isinstance(self.api_type, Unset):
            api_type = self.api_type.value


        enable_thinking = self.enable_thinking

        model_name = self.model_name

        system_instruction = self.system_instruction

        temperature = self.temperature

        max_tokens = self.max_tokens

        max_char_size_to_answer = self.max_char_size_to_answer

        compaction_threshold_tokens = self.compaction_threshold_tokens

        compaction_keep_recent = self.compaction_keep_recent


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if api_type is not UNSET:
            field_dict["API_TYPE"] = api_type
        if enable_thinking is not UNSET:
            field_dict["ENABLE_THINKING"] = enable_thinking
        if model_name is not UNSET:
            field_dict["MODEL_NAME"] = model_name
        if system_instruction is not UNSET:
            field_dict["SYSTEM_INSTRUCTION"] = system_instruction
        if temperature is not UNSET:
            field_dict["TEMPERATURE"] = temperature
        if max_tokens is not UNSET:
            field_dict["MAX_TOKENS"] = max_tokens
        if max_char_size_to_answer is not UNSET:
            field_dict["MAX_CHAR_SIZE_TO_ANSWER"] = max_char_size_to_answer
        if compaction_threshold_tokens is not UNSET:
            field_dict["COMPACTION_THRESHOLD_TOKENS"] = compaction_threshold_tokens
        if compaction_keep_recent is not UNSET:
            field_dict["COMPACTION_KEEP_RECENT"] = compaction_keep_recent

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _api_type = d.pop("API_TYPE", UNSET)
        api_type: SummariseLLMConfigApiType | Unset
        if isinstance(_api_type,  Unset):
            api_type = UNSET
        else:
            api_type = SummariseLLMConfigApiType(_api_type)




        enable_thinking = d.pop("ENABLE_THINKING", UNSET)

        model_name = d.pop("MODEL_NAME", UNSET)

        system_instruction = d.pop("SYSTEM_INSTRUCTION", UNSET)

        temperature = d.pop("TEMPERATURE", UNSET)

        max_tokens = d.pop("MAX_TOKENS", UNSET)

        max_char_size_to_answer = d.pop("MAX_CHAR_SIZE_TO_ANSWER", UNSET)

        compaction_threshold_tokens = d.pop("COMPACTION_THRESHOLD_TOKENS", UNSET)

        compaction_keep_recent = d.pop("COMPACTION_KEEP_RECENT", UNSET)

        summarise_llm_config = cls(
            api_type=api_type,
            enable_thinking=enable_thinking,
            model_name=model_name,
            system_instruction=system_instruction,
            temperature=temperature,
            max_tokens=max_tokens,
            max_char_size_to_answer=max_char_size_to_answer,
            compaction_threshold_tokens=compaction_threshold_tokens,
            compaction_keep_recent=compaction_keep_recent,
        )


        summarise_llm_config.additional_properties = d
        return summarise_llm_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
