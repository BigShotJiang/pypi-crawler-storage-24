from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.authorize_request_workspaces import AuthorizeRequestWorkspaces





T = TypeVar("T", bound="AuthorizeRequest")



@_attrs_define
class AuthorizeRequest:
    """ Authorize a delegated session with workspace keys.

    Used by: POST /user/authorize (authenticated)

    Frontend sends workspace keys SealedBox-encrypted with the user's session public key.
    Server decrypts them, re-encrypts with a new session keypair, and creates a pending
    session keyed by a 3-word claim code. The recipient redeems the code via POST /user/token.

    If persist_identity is True, the claim creates a persistent Agent identity
    with its own keypair and WorkspaceUsers rows. The agent can then re-login.

        Attributes:
            workspaces (AuthorizeRequestWorkspaces):
            name (str):
            active_workspace (None | str | Unset):
            ttl (int | Unset):  Default: 3600.
            persist_identity (bool | Unset):  Default: False.
     """

    workspaces: AuthorizeRequestWorkspaces
    name: str
    active_workspace: None | str | Unset = UNSET
    ttl: int | Unset = 3600
    persist_identity: bool | Unset = False





    def to_dict(self) -> dict[str, Any]:
        from ..models.authorize_request_workspaces import AuthorizeRequestWorkspaces
        workspaces = self.workspaces.to_dict()

        name = self.name

        active_workspace: None | str | Unset
        if isinstance(self.active_workspace, Unset):
            active_workspace = UNSET
        else:
            active_workspace = self.active_workspace

        ttl = self.ttl

        persist_identity = self.persist_identity


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "workspaces": workspaces,
            "name": name,
        })
        if active_workspace is not UNSET:
            field_dict["active_workspace"] = active_workspace
        if ttl is not UNSET:
            field_dict["ttl"] = ttl
        if persist_identity is not UNSET:
            field_dict["persist_identity"] = persist_identity

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.authorize_request_workspaces import AuthorizeRequestWorkspaces
        d = dict(src_dict)
        workspaces = AuthorizeRequestWorkspaces.from_dict(d.pop("workspaces"))




        name = d.pop("name")

        def _parse_active_workspace(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        active_workspace = _parse_active_workspace(d.pop("active_workspace", UNSET))


        ttl = d.pop("ttl", UNSET)

        persist_identity = d.pop("persist_identity", UNSET)

        authorize_request = cls(
            workspaces=workspaces,
            name=name,
            active_workspace=active_workspace,
            ttl=ttl,
            persist_identity=persist_identity,
        )

        return authorize_request

