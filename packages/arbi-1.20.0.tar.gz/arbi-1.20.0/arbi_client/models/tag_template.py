from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.tag_format import TagFormat





T = TypeVar("T", bound="TagTemplate")



@_attrs_define
class TagTemplate:
    """ Base template for tag configuration - used for seeding default tags.

        Attributes:
            name (str):
            instruction (None | str | Unset):
            tag_type (TagFormat | Unset): Tag format configuration stored as JSONB.

                Type-specific fields:
                - select: options (list of choices, can be single or multi-select)
                - search: tag name is the query, chunks include relevance scores
                - checkbox, text, number: type only
     """

    name: str
    instruction: None | str | Unset = UNSET
    tag_type: TagFormat | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.tag_format import TagFormat
        name = self.name

        instruction: None | str | Unset
        if isinstance(self.instruction, Unset):
            instruction = UNSET
        else:
            instruction = self.instruction

        tag_type: dict[str, Any] | Unset = UNSET
        if not isinstance(self.tag_type, Unset):
            tag_type = self.tag_type.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
        })
        if instruction is not UNSET:
            field_dict["instruction"] = instruction
        if tag_type is not UNSET:
            field_dict["tag_type"] = tag_type

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.tag_format import TagFormat
        d = dict(src_dict)
        name = d.pop("name")

        def _parse_instruction(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        instruction = _parse_instruction(d.pop("instruction", UNSET))


        _tag_type = d.pop("tag_type", UNSET)
        tag_type: TagFormat | Unset
        if isinstance(_tag_type,  Unset):
            tag_type = UNSET
        else:
            tag_type = TagFormat.from_dict(_tag_type)




        tag_template = cls(
            name=name,
            instruction=instruction,
            tag_type=tag_type,
        )


        tag_template.additional_properties = d
        return tag_template

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
