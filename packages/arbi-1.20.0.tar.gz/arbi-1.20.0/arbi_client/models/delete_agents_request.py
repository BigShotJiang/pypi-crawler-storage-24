from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast






T = TypeVar("T", bound="DeleteAgentsRequest")



@_attrs_define
class DeleteAgentsRequest:
    """ Request to delete agents by external ID.

        Attributes:
            agent_ext_ids (list[str]):
     """

    agent_ext_ids: list[str]





    def to_dict(self) -> dict[str, Any]:
        agent_ext_ids = self.agent_ext_ids




        field_dict: dict[str, Any] = {}

        field_dict.update({
            "agent_ext_ids": agent_ext_ids,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        agent_ext_ids = cast(list[str], d.pop("agent_ext_ids"))


        delete_agents_request = cls(
            agent_ext_ids=agent_ext_ids,
        )

        return delete_agents_request

