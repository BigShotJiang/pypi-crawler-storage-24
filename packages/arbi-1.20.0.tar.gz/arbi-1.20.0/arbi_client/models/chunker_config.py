from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.chunker_config_tokenizer_type import ChunkerConfigTokenizerType
from ..types import UNSET, Unset






T = TypeVar("T", bound="ChunkerConfig")



@_attrs_define
class ChunkerConfig:
    """ 
        Attributes:
            max_chunk_tokens (int | Unset): Maximum tokens per chunk. The tokenizer used depends on TOKENIZER_TYPE. Default:
                1200.
            tokenizer_type (ChunkerConfigTokenizerType | Unset): Tokenizer backend: 'tiktoken' for OpenAI models
                (cl100k_base, etc.) or 'huggingface' for HF models (Qwen3-Embedding, etc.). Default:
                ChunkerConfigTokenizerType.HUGGINGFACE.
            tokenizer_name (str | Unset): Tokenizer name. For tiktoken: 'cl100k_base', 'o200k_base', etc. For huggingface:
                model name like 'Qwen/Qwen3-Embedding-0.6B'. Default: 'Qwen/Qwen3-Embedding-0.6B'.
     """

    max_chunk_tokens: int | Unset = 1200
    tokenizer_type: ChunkerConfigTokenizerType | Unset = ChunkerConfigTokenizerType.HUGGINGFACE
    tokenizer_name: str | Unset = 'Qwen/Qwen3-Embedding-0.6B'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        max_chunk_tokens = self.max_chunk_tokens

        tokenizer_type: str | Unset = UNSET
        if not isinstance(self.tokenizer_type, Unset):
            tokenizer_type = self.tokenizer_type.value


        tokenizer_name = self.tokenizer_name


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if max_chunk_tokens is not UNSET:
            field_dict["MAX_CHUNK_TOKENS"] = max_chunk_tokens
        if tokenizer_type is not UNSET:
            field_dict["TOKENIZER_TYPE"] = tokenizer_type
        if tokenizer_name is not UNSET:
            field_dict["TOKENIZER_NAME"] = tokenizer_name

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        max_chunk_tokens = d.pop("MAX_CHUNK_TOKENS", UNSET)

        _tokenizer_type = d.pop("TOKENIZER_TYPE", UNSET)
        tokenizer_type: ChunkerConfigTokenizerType | Unset
        if isinstance(_tokenizer_type,  Unset):
            tokenizer_type = UNSET
        else:
            tokenizer_type = ChunkerConfigTokenizerType(_tokenizer_type)




        tokenizer_name = d.pop("TOKENIZER_NAME", UNSET)

        chunker_config = cls(
            max_chunk_tokens=max_chunk_tokens,
            tokenizer_type=tokenizer_type,
            tokenizer_name=tokenizer_name,
        )


        chunker_config.additional_properties = d
        return chunker_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
