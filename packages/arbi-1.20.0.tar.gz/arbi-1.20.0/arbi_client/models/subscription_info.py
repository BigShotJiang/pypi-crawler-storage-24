from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="SubscriptionInfo")



@_attrs_define
class SubscriptionInfo:
    """ Subscription info exposed to frontend in user settings.

    Note: stripe_customer_id is deliberately excluded for security.
    This is a minimal model used in UserSettingsResponse.
    For full subscription details, use GET /subscription endpoint.

        Attributes:
            status (str | Unset):  Default: 'restricted'.
            trial_expires (int | None | Unset):
     """

    status: str | Unset = 'restricted'
    trial_expires: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        status = self.status

        trial_expires: int | None | Unset
        if isinstance(self.trial_expires, Unset):
            trial_expires = UNSET
        else:
            trial_expires = self.trial_expires


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if status is not UNSET:
            field_dict["status"] = status
        if trial_expires is not UNSET:
            field_dict["trial_expires"] = trial_expires

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        status = d.pop("status", UNSET)

        def _parse_trial_expires(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        trial_expires = _parse_trial_expires(d.pop("trial_expires", UNSET))


        subscription_info = cls(
            status=status,
            trial_expires=trial_expires,
        )


        subscription_info.additional_properties = d
        return subscription_info

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
