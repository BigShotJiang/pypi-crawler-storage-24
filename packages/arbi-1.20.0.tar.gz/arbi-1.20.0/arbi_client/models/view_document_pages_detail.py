from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import Literal, cast






T = TypeVar("T", bound="ViewDocumentPagesDetail")



@_attrs_define
class ViewDocumentPagesDetail:
    """ Detail for a view_document_pages tool call.

        Attributes:
            doc_ext_id (str): Document external ID
            from_page (int): Start page number
            to_page (int): End page number
            tool (Literal['view_document_pages'] | Unset):  Default: 'view_document_pages'.
     """

    doc_ext_id: str
    from_page: int
    to_page: int
    tool: Literal['view_document_pages'] | Unset = 'view_document_pages'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        doc_ext_id = self.doc_ext_id

        from_page = self.from_page

        to_page = self.to_page

        tool = self.tool


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "doc_ext_id": doc_ext_id,
            "from_page": from_page,
            "to_page": to_page,
        })
        if tool is not UNSET:
            field_dict["tool"] = tool

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        doc_ext_id = d.pop("doc_ext_id")

        from_page = d.pop("from_page")

        to_page = d.pop("to_page")

        tool = cast(Literal['view_document_pages'] | Unset , d.pop("tool", UNSET))
        if tool != 'view_document_pages'and not isinstance(tool, Unset):
            raise ValueError(f"tool must match const 'view_document_pages', got '{tool}'")

        view_document_pages_detail = cls(
            doc_ext_id=doc_ext_id,
            from_page=from_page,
            to_page=to_page,
            tool=tool,
        )


        view_document_pages_detail.additional_properties = d
        return view_document_pages_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
