from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.product_price import ProductPrice





T = TypeVar("T", bound="ProductResponse")



@_attrs_define
class ProductResponse:
    """ Stripe product with pricing information.

        Attributes:
            product_id (str):
            name (str):
            prices (list[ProductPrice]):
            description (None | str | Unset):
     """

    product_id: str
    name: str
    prices: list[ProductPrice]
    description: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.product_price import ProductPrice
        product_id = self.product_id

        name = self.name

        prices = []
        for prices_item_data in self.prices:
            prices_item = prices_item_data.to_dict()
            prices.append(prices_item)



        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "product_id": product_id,
            "name": name,
            "prices": prices,
        })
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.product_price import ProductPrice
        d = dict(src_dict)
        product_id = d.pop("product_id")

        name = d.pop("name")

        prices = []
        _prices = d.pop("prices")
        for prices_item_data in (_prices):
            prices_item = ProductPrice.from_dict(prices_item_data)



            prices.append(prices_item)


        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        product_response = cls(
            product_id=product_id,
            name=name,
            prices=prices,
            description=description,
        )


        product_response.additional_properties = d
        return product_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
