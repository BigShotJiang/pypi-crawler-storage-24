from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.retrieval_chunk_tool_args import RetrievalChunkToolArgs
  from ..models.retrieval_chunk_tool_tool_responses import RetrievalChunkToolToolResponses





T = TypeVar("T", bound="RetrievalChunkTool")



@_attrs_define
class RetrievalChunkTool:
    """ 
        Attributes:
            name (Literal['retrieval_chunk'] | Unset):  Default: 'retrieval_chunk'.
            description (str | Unset):  Default: 'retrieval chunk'.
            tool_args (RetrievalChunkToolArgs | Unset): Typed arguments for retrieval chunk tool.
            tool_responses (RetrievalChunkToolToolResponses | Unset):
     """

    name: Literal['retrieval_chunk'] | Unset = 'retrieval_chunk'
    description: str | Unset = 'retrieval chunk'
    tool_args: RetrievalChunkToolArgs | Unset = UNSET
    tool_responses: RetrievalChunkToolToolResponses | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.retrieval_chunk_tool_tool_responses import RetrievalChunkToolToolResponses
        from ..models.retrieval_chunk_tool_args import RetrievalChunkToolArgs
        name = self.name

        description = self.description

        tool_args: dict[str, Any] | Unset = UNSET
        if not isinstance(self.tool_args, Unset):
            tool_args = self.tool_args.to_dict()

        tool_responses: dict[str, Any] | Unset = UNSET
        if not isinstance(self.tool_responses, Unset):
            tool_responses = self.tool_responses.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if tool_args is not UNSET:
            field_dict["tool_args"] = tool_args
        if tool_responses is not UNSET:
            field_dict["tool_responses"] = tool_responses

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.retrieval_chunk_tool_args import RetrievalChunkToolArgs
        from ..models.retrieval_chunk_tool_tool_responses import RetrievalChunkToolToolResponses
        d = dict(src_dict)
        name = cast(Literal['retrieval_chunk'] | Unset , d.pop("name", UNSET))
        if name != 'retrieval_chunk'and not isinstance(name, Unset):
            raise ValueError(f"name must match const 'retrieval_chunk', got '{name}'")

        description = d.pop("description", UNSET)

        _tool_args = d.pop("tool_args", UNSET)
        tool_args: RetrievalChunkToolArgs | Unset
        if isinstance(_tool_args,  Unset):
            tool_args = UNSET
        else:
            tool_args = RetrievalChunkToolArgs.from_dict(_tool_args)




        _tool_responses = d.pop("tool_responses", UNSET)
        tool_responses: RetrievalChunkToolToolResponses | Unset
        if isinstance(_tool_responses,  Unset):
            tool_responses = UNSET
        else:
            tool_responses = RetrievalChunkToolToolResponses.from_dict(_tool_responses)




        retrieval_chunk_tool = cls(
            name=name,
            description=description,
            tool_args=tool_args,
            tool_responses=tool_responses,
        )


        retrieval_chunk_tool.additional_properties = d
        return retrieval_chunk_tool

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
