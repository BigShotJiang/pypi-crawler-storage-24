from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast






T = TypeVar("T", bound="ReadDocumentDetail")



@_attrs_define
class ReadDocumentDetail:
    """ Detail for a read_document tool call.

        Attributes:
            doc_ext_id (str): Document external ID
            range_count (int): Number of page ranges requested (0 = full document)
            digest (bool): Whether learnings extraction was requested
            tool (Literal['read_document'] | Unset):  Default: 'read_document'.
            label (str | Unset): Display label for the tool step Default: 'Reading document'.
            icon (str | Unset): Lucide icon name for the tool step Default: 'file-text'.
            summary (None | str | Unset): Human-readable summary (e.g. 'Reading {doc-abc12345} pp. 5–10')
     """

    doc_ext_id: str
    range_count: int
    digest: bool
    tool: Literal['read_document'] | Unset = 'read_document'
    label: str | Unset = 'Reading document'
    icon: str | Unset = 'file-text'
    summary: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        doc_ext_id = self.doc_ext_id

        range_count = self.range_count

        digest = self.digest

        tool = self.tool

        label = self.label

        icon = self.icon

        summary: None | str | Unset
        if isinstance(self.summary, Unset):
            summary = UNSET
        else:
            summary = self.summary


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "doc_ext_id": doc_ext_id,
            "range_count": range_count,
            "digest": digest,
        })
        if tool is not UNSET:
            field_dict["tool"] = tool
        if label is not UNSET:
            field_dict["label"] = label
        if icon is not UNSET:
            field_dict["icon"] = icon
        if summary is not UNSET:
            field_dict["summary"] = summary

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        doc_ext_id = d.pop("doc_ext_id")

        range_count = d.pop("range_count")

        digest = d.pop("digest")

        tool = cast(Literal['read_document'] | Unset , d.pop("tool", UNSET))
        if tool != 'read_document'and not isinstance(tool, Unset):
            raise ValueError(f"tool must match const 'read_document', got '{tool}'")

        label = d.pop("label", UNSET)

        icon = d.pop("icon", UNSET)

        def _parse_summary(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        summary = _parse_summary(d.pop("summary", UNSET))


        read_document_detail = cls(
            doc_ext_id=doc_ext_id,
            range_count=range_count,
            digest=digest,
            tool=tool,
            label=label,
            icon=icon,
            summary=summary,
        )


        read_document_detail.additional_properties = d
        return read_document_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
