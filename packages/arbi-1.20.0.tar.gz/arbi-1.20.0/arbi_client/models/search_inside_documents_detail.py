from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast






T = TypeVar("T", bound="SearchInsideDocumentsDetail")



@_attrs_define
class SearchInsideDocumentsDetail:
    """ Detail for a search_inside_documents tool call.

        Attributes:
            query (str): Search query (truncated to 80 chars)
            search_mode (str): Search mode: hybrid, semantic, keyword
            tool (Literal['search_inside_documents'] | Unset):  Default: 'search_inside_documents'.
            label (str | Unset): Display label for the tool step Default: 'Searching documents'.
            icon (str | Unset): Lucide icon name for the tool step Default: 'search'.
            summary (None | str | Unset): Human-readable summary (e.g. 'Search: "query" (hybrid)')
     """

    query: str
    search_mode: str
    tool: Literal['search_inside_documents'] | Unset = 'search_inside_documents'
    label: str | Unset = 'Searching documents'
    icon: str | Unset = 'search'
    summary: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        query = self.query

        search_mode = self.search_mode

        tool = self.tool

        label = self.label

        icon = self.icon

        summary: None | str | Unset
        if isinstance(self.summary, Unset):
            summary = UNSET
        else:
            summary = self.summary


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "query": query,
            "search_mode": search_mode,
        })
        if tool is not UNSET:
            field_dict["tool"] = tool
        if label is not UNSET:
            field_dict["label"] = label
        if icon is not UNSET:
            field_dict["icon"] = icon
        if summary is not UNSET:
            field_dict["summary"] = summary

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        query = d.pop("query")

        search_mode = d.pop("search_mode")

        tool = cast(Literal['search_inside_documents'] | Unset , d.pop("tool", UNSET))
        if tool != 'search_inside_documents'and not isinstance(tool, Unset):
            raise ValueError(f"tool must match const 'search_inside_documents', got '{tool}'")

        label = d.pop("label", UNSET)

        icon = d.pop("icon", UNSET)

        def _parse_summary(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        summary = _parse_summary(d.pop("summary", UNSET))


        search_inside_documents_detail = cls(
            query=query,
            search_mode=search_mode,
            tool=tool,
            label=label,
            icon=icon,
            summary=summary,
        )


        search_inside_documents_detail.additional_properties = d
        return search_inside_documents_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
