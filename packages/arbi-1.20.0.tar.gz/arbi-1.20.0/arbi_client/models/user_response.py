from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="UserResponse")



@_attrs_define
class UserResponse:
    """ Standard user representation used across all endpoints.

    Used for: login response, workspace users, contacts (when registered).
    Agents have agt- prefix and may have nullable name/email fields.

        Attributes:
            external_id (str):
            email (str):
            given_name (str):
            encryption_public_key (str):
            parent_ext_id (None | str | Unset):
            family_name (None | str | Unset):
            picture (None | str | Unset):
     """

    external_id: str
    email: str
    given_name: str
    encryption_public_key: str
    parent_ext_id: None | str | Unset = UNSET
    family_name: None | str | Unset = UNSET
    picture: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        external_id = self.external_id

        email = self.email

        given_name = self.given_name

        encryption_public_key = self.encryption_public_key

        parent_ext_id: None | str | Unset
        if isinstance(self.parent_ext_id, Unset):
            parent_ext_id = UNSET
        else:
            parent_ext_id = self.parent_ext_id

        family_name: None | str | Unset
        if isinstance(self.family_name, Unset):
            family_name = UNSET
        else:
            family_name = self.family_name

        picture: None | str | Unset
        if isinstance(self.picture, Unset):
            picture = UNSET
        else:
            picture = self.picture


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "external_id": external_id,
            "email": email,
            "given_name": given_name,
            "encryption_public_key": encryption_public_key,
        })
        if parent_ext_id is not UNSET:
            field_dict["parent_ext_id"] = parent_ext_id
        if family_name is not UNSET:
            field_dict["family_name"] = family_name
        if picture is not UNSET:
            field_dict["picture"] = picture

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        external_id = d.pop("external_id")

        email = d.pop("email")

        given_name = d.pop("given_name")

        encryption_public_key = d.pop("encryption_public_key")

        def _parse_parent_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parent_ext_id = _parse_parent_ext_id(d.pop("parent_ext_id", UNSET))


        def _parse_family_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        family_name = _parse_family_name(d.pop("family_name", UNSET))


        def _parse_picture(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        picture = _parse_picture(d.pop("picture", UNSET))


        user_response = cls(
            external_id=external_id,
            email=email,
            given_name=given_name,
            encryption_public_key=encryption_public_key,
            parent_ext_id=parent_ext_id,
            family_name=family_name,
            picture=picture,
        )


        user_response.additional_properties = d
        return user_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
