from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.output_tokens_details import OutputTokensDetails





T = TypeVar("T", bound="ResponseUsage")



@_attrs_define
class ResponseUsage:
    """ Token usage summary in a completed response (OpenAI format).

        Attributes:
            input_tokens (int): Total input tokens consumed
            output_tokens (int): Output tokens generated (excluding reasoning)
            total_tokens (int): Sum of input + output + reasoning tokens
            output_tokens_details (OutputTokensDetails | Unset): Nested output token details per OpenAI spec.
     """

    input_tokens: int
    output_tokens: int
    total_tokens: int
    output_tokens_details: OutputTokensDetails | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.output_tokens_details import OutputTokensDetails
        input_tokens = self.input_tokens

        output_tokens = self.output_tokens

        total_tokens = self.total_tokens

        output_tokens_details: dict[str, Any] | Unset = UNSET
        if not isinstance(self.output_tokens_details, Unset):
            output_tokens_details = self.output_tokens_details.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": total_tokens,
        })
        if output_tokens_details is not UNSET:
            field_dict["output_tokens_details"] = output_tokens_details

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.output_tokens_details import OutputTokensDetails
        d = dict(src_dict)
        input_tokens = d.pop("input_tokens")

        output_tokens = d.pop("output_tokens")

        total_tokens = d.pop("total_tokens")

        _output_tokens_details = d.pop("output_tokens_details", UNSET)
        output_tokens_details: OutputTokensDetails | Unset
        if isinstance(_output_tokens_details,  Unset):
            output_tokens_details = UNSET
        else:
            output_tokens_details = OutputTokensDetails.from_dict(_output_tokens_details)




        response_usage = cls(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=total_tokens,
            output_tokens_details=output_tokens_details,
        )


        response_usage.additional_properties = d
        return response_usage

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
