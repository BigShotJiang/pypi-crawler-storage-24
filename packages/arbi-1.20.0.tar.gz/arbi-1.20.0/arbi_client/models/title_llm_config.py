from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.title_llm_config_api_type import TitleLLMConfigApiType
from ..types import UNSET, Unset






T = TypeVar("T", bound="TitleLLMConfig")



@_attrs_define
class TitleLLMConfig:
    """ 
        Attributes:
            api_type (TitleLLMConfigApiType | Unset): The inference type (local or remote). Default:
                TitleLLMConfigApiType.REMOTE.
            enable_thinking (bool | Unset): Enable reasoning/thinking mode. Default: False.
            model_name (str | Unset): The name of the non-reasoning model to be used. Default: 'dummy'.
            system_instruction (str | Unset):  Default: 'You are a title generator that creates concise, descriptive
                titles.'.
            max_char_size_to_answer (int | Unset): Maximum character size to answer. Default: 50.
            temperature (float | Unset): Temperature value for randomness. Default: 0.3.
            max_tokens (int | Unset): Maximum number of tokens allowed. Default: 20.
     """

    api_type: TitleLLMConfigApiType | Unset = TitleLLMConfigApiType.REMOTE
    enable_thinking: bool | Unset = False
    model_name: str | Unset = 'dummy'
    system_instruction: str | Unset = 'You are a title generator that creates concise, descriptive titles.'
    max_char_size_to_answer: int | Unset = 50
    temperature: float | Unset = 0.3
    max_tokens: int | Unset = 20
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        api_type: str | Unset = UNSET
        if not isinstance(self.api_type, Unset):
            api_type = self.api_type.value


        enable_thinking = self.enable_thinking

        model_name = self.model_name

        system_instruction = self.system_instruction

        max_char_size_to_answer = self.max_char_size_to_answer

        temperature = self.temperature

        max_tokens = self.max_tokens


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if api_type is not UNSET:
            field_dict["API_TYPE"] = api_type
        if enable_thinking is not UNSET:
            field_dict["ENABLE_THINKING"] = enable_thinking
        if model_name is not UNSET:
            field_dict["MODEL_NAME"] = model_name
        if system_instruction is not UNSET:
            field_dict["SYSTEM_INSTRUCTION"] = system_instruction
        if max_char_size_to_answer is not UNSET:
            field_dict["MAX_CHAR_SIZE_TO_ANSWER"] = max_char_size_to_answer
        if temperature is not UNSET:
            field_dict["TEMPERATURE"] = temperature
        if max_tokens is not UNSET:
            field_dict["MAX_TOKENS"] = max_tokens

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _api_type = d.pop("API_TYPE", UNSET)
        api_type: TitleLLMConfigApiType | Unset
        if isinstance(_api_type,  Unset):
            api_type = UNSET
        else:
            api_type = TitleLLMConfigApiType(_api_type)




        enable_thinking = d.pop("ENABLE_THINKING", UNSET)

        model_name = d.pop("MODEL_NAME", UNSET)

        system_instruction = d.pop("SYSTEM_INSTRUCTION", UNSET)

        max_char_size_to_answer = d.pop("MAX_CHAR_SIZE_TO_ANSWER", UNSET)

        temperature = d.pop("TEMPERATURE", UNSET)

        max_tokens = d.pop("MAX_TOKENS", UNSET)

        title_llm_config = cls(
            api_type=api_type,
            enable_thinking=enable_thinking,
            model_name=model_name,
            system_instruction=system_instruction,
            max_char_size_to_answer=max_char_size_to_answer,
            temperature=temperature,
            max_tokens=max_tokens,
        )


        title_llm_config.additional_properties = d
        return title_llm_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
