from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="ProductPrice")



@_attrs_define
class ProductPrice:
    """ Stripe product price information.

        Attributes:
            price_id (str):
            amount (int):
            currency (str):
            interval (str):
            interval_count (int):
            default_price (bool):
     """

    price_id: str
    amount: int
    currency: str
    interval: str
    interval_count: int
    default_price: bool
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        price_id = self.price_id

        amount = self.amount

        currency = self.currency

        interval = self.interval

        interval_count = self.interval_count

        default_price = self.default_price


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "price_id": price_id,
            "amount": amount,
            "currency": currency,
            "interval": interval,
            "interval_count": interval_count,
            "default_price": default_price,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        price_id = d.pop("price_id")

        amount = d.pop("amount")

        currency = d.pop("currency")

        interval = d.pop("interval")

        interval_count = d.pop("interval_count")

        default_price = d.pop("default_price")

        product_price = cls(
            price_id=price_id,
            amount=amount,
            currency=currency,
            interval=interval,
            interval_count=interval_count,
            default_price=default_price,
        )


        product_price.additional_properties = d
        return product_price

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
