from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="ConversationTitleUpdateRequest")



@_attrs_define
class ConversationTitleUpdateRequest:
    """ 
        Attributes:
            title (str): New conversation title (1-60 characters)
     """

    title: str





    def to_dict(self) -> dict[str, Any]:
        title = self.title


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "title": title,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        title = d.pop("title")

        conversation_title_update_request = cls(
            title=title,
        )

        return conversation_title_update_request

