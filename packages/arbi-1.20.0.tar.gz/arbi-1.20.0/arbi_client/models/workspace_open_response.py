from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.conversation_response import ConversationResponse
  from ..models.workspace_response import WorkspaceResponse





T = TypeVar("T", bound="WorkspaceOpenResponse")



@_attrs_define
class WorkspaceOpenResponse:
    """ Response from opening a workspace — workspace data (no new JWT).

        Attributes:
            workspace (WorkspaceResponse):
            conversations (list[ConversationResponse]):
            documents (list[Any]):
            tags (list[Any]):
     """

    workspace: WorkspaceResponse
    conversations: list[ConversationResponse]
    documents: list[Any]
    tags: list[Any]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.conversation_response import ConversationResponse
        from ..models.workspace_response import WorkspaceResponse
        workspace = self.workspace.to_dict()

        conversations = []
        for conversations_item_data in self.conversations:
            conversations_item = conversations_item_data.to_dict()
            conversations.append(conversations_item)



        documents = self.documents



        tags = self.tags




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "workspace": workspace,
            "conversations": conversations,
            "documents": documents,
            "tags": tags,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.conversation_response import ConversationResponse
        from ..models.workspace_response import WorkspaceResponse
        d = dict(src_dict)
        workspace = WorkspaceResponse.from_dict(d.pop("workspace"))




        conversations = []
        _conversations = d.pop("conversations")
        for conversations_item_data in (_conversations):
            conversations_item = ConversationResponse.from_dict(conversations_item_data)



            conversations.append(conversations_item)


        documents = cast(list[Any], d.pop("documents"))


        tags = cast(list[Any], d.pop("tags"))


        workspace_open_response = cls(
            workspace=workspace,
            conversations=conversations,
            documents=documents,
            tags=tags,
        )


        workspace_open_response.additional_properties = d
        return workspace_open_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
