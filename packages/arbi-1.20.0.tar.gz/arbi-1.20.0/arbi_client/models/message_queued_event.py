from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.user_message_event import UserMessageEvent





T = TypeVar("T", bound="MessageQueuedEvent")



@_attrs_define
class MessageQueuedEvent:
    """ ``arbi.message_queued`` — immediate ack when query is received.

    For continuation queries (previous_response_id set), includes the full
    ``user_message`` (UserMessageEvent with status="queued") so the frontend
    can display it before the response gate opens.

        Attributes:
            response_id (str): Assistant message external ID for this response
            input_ (str): User's query text
            type_ (Literal['arbi.message_queued'] | Unset):  Default: 'arbi.message_queued'.
            previous_response_id (None | str | Unset): Parent message ext_id (set for continuations)
            user_message_id (None | str | Unset): User message ext_id (present for continuations, saved before gate wait)
            user_message (None | Unset | UserMessageEvent): Full UserMessageEvent with status='queued' (present for
                continuations)
     """

    response_id: str
    input_: str
    type_: Literal['arbi.message_queued'] | Unset = 'arbi.message_queued'
    previous_response_id: None | str | Unset = UNSET
    user_message_id: None | str | Unset = UNSET
    user_message: None | Unset | UserMessageEvent = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.user_message_event import UserMessageEvent
        response_id = self.response_id

        input_ = self.input_

        type_ = self.type_

        previous_response_id: None | str | Unset
        if isinstance(self.previous_response_id, Unset):
            previous_response_id = UNSET
        else:
            previous_response_id = self.previous_response_id

        user_message_id: None | str | Unset
        if isinstance(self.user_message_id, Unset):
            user_message_id = UNSET
        else:
            user_message_id = self.user_message_id

        user_message: dict[str, Any] | None | Unset
        if isinstance(self.user_message, Unset):
            user_message = UNSET
        elif isinstance(self.user_message, UserMessageEvent):
            user_message = self.user_message.to_dict()
        else:
            user_message = self.user_message


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "response_id": response_id,
            "input": input_,
        })
        if type_ is not UNSET:
            field_dict["type"] = type_
        if previous_response_id is not UNSET:
            field_dict["previous_response_id"] = previous_response_id
        if user_message_id is not UNSET:
            field_dict["user_message_id"] = user_message_id
        if user_message is not UNSET:
            field_dict["user_message"] = user_message

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user_message_event import UserMessageEvent
        d = dict(src_dict)
        response_id = d.pop("response_id")

        input_ = d.pop("input")

        type_ = cast(Literal['arbi.message_queued'] | Unset , d.pop("type", UNSET))
        if type_ != 'arbi.message_queued'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'arbi.message_queued', got '{type_}'")

        def _parse_previous_response_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        previous_response_id = _parse_previous_response_id(d.pop("previous_response_id", UNSET))


        def _parse_user_message_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        user_message_id = _parse_user_message_id(d.pop("user_message_id", UNSET))


        def _parse_user_message(data: object) -> None | Unset | UserMessageEvent:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                user_message_type_0 = UserMessageEvent.from_dict(data)



                return user_message_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UserMessageEvent, data)

        user_message = _parse_user_message(d.pop("user_message", UNSET))


        message_queued_event = cls(
            response_id=response_id,
            input_=input_,
            type_=type_,
            previous_response_id=previous_response_id,
            user_message_id=user_message_id,
            user_message=user_message,
        )


        message_queued_event.additional_properties = d
        return message_queued_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
