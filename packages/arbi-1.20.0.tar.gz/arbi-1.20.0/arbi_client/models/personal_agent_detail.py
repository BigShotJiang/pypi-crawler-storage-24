from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import Literal, cast






T = TypeVar("T", bound="PersonalAgentDetail")



@_attrs_define
class PersonalAgentDetail:
    """ Detail for a personal_agent tool call.

        Attributes:
            task (str): Task description (truncated to 120 chars)
            tool (Literal['personal_agent'] | Unset):  Default: 'personal_agent'.
     """

    task: str
    tool: Literal['personal_agent'] | Unset = 'personal_agent'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        task = self.task

        tool = self.tool


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "task": task,
        })
        if tool is not UNSET:
            field_dict["tool"] = tool

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        task = d.pop("task")

        tool = cast(Literal['personal_agent'] | Unset , d.pop("tool", UNSET))
        if tool != 'personal_agent'and not isinstance(tool, Unset):
            raise ValueError(f"tool must match const 'personal_agent', got '{tool}'")

        personal_agent_detail = cls(
            task=task,
            tool=tool,
        )


        personal_agent_detail.additional_properties = d
        return personal_agent_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
