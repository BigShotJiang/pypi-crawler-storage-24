from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="AgentSessionClaimRequest")



@_attrs_define
class AgentSessionClaimRequest:
    """ Claim an agent session using a 3-word code.

    If the pending session has persist_identity=True, signing_key is required
    to create the Agent identity. Otherwise it is accepted but ignored.

        Attributes:
            claim_code (str):
            signing_key (None | str | Unset):
     """

    claim_code: str
    signing_key: None | str | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        claim_code = self.claim_code

        signing_key: None | str | Unset
        if isinstance(self.signing_key, Unset):
            signing_key = UNSET
        else:
            signing_key = self.signing_key


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "claim_code": claim_code,
        })
        if signing_key is not UNSET:
            field_dict["signing_key"] = signing_key

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        claim_code = d.pop("claim_code")

        def _parse_signing_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        signing_key = _parse_signing_key(d.pop("signing_key", UNSET))


        agent_session_claim_request = cls(
            claim_code=claim_code,
            signing_key=signing_key,
        )

        return agent_session_claim_request

