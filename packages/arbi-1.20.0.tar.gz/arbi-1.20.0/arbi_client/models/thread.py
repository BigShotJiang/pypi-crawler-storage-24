from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.message_response import MessageResponse





T = TypeVar("T", bound="Thread")



@_attrs_define
class Thread:
    """ 
        Attributes:
            leaf_message_ext_id (str):
            history (list[MessageResponse]):
     """

    leaf_message_ext_id: str
    history: list[MessageResponse]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.message_response import MessageResponse
        leaf_message_ext_id = self.leaf_message_ext_id

        history = []
        for history_item_data in self.history:
            history_item = history_item_data.to_dict()
            history.append(history_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "leaf_message_ext_id": leaf_message_ext_id,
            "history": history,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.message_response import MessageResponse
        d = dict(src_dict)
        leaf_message_ext_id = d.pop("leaf_message_ext_id")

        history = []
        _history = d.pop("history")
        for history_item_data in (_history):
            history_item = MessageResponse.from_dict(history_item_data)



            history.append(history_item)


        thread = cls(
            leaf_message_ext_id=leaf_message_ext_id,
            history=history,
        )


        thread.additional_properties = d
        return thread

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
