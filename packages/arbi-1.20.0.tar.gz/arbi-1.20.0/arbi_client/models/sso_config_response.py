from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="SSOConfigResponse")



@_attrs_define
class SSOConfigResponse:
    """ Public SSO configuration for device flow / CLI login.

        Attributes:
            sso_enabled (bool):
            domain (str | Unset):  Default: ''.
            client_id (str | Unset):  Default: ''.
            cli_client_id (str | Unset):  Default: ''.
            audience (str | Unset):  Default: ''.
     """

    sso_enabled: bool
    domain: str | Unset = ''
    client_id: str | Unset = ''
    cli_client_id: str | Unset = ''
    audience: str | Unset = ''
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        sso_enabled = self.sso_enabled

        domain = self.domain

        client_id = self.client_id

        cli_client_id = self.cli_client_id

        audience = self.audience


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "sso_enabled": sso_enabled,
        })
        if domain is not UNSET:
            field_dict["domain"] = domain
        if client_id is not UNSET:
            field_dict["client_id"] = client_id
        if cli_client_id is not UNSET:
            field_dict["cli_client_id"] = cli_client_id
        if audience is not UNSET:
            field_dict["audience"] = audience

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        sso_enabled = d.pop("sso_enabled")

        domain = d.pop("domain", UNSET)

        client_id = d.pop("client_id", UNSET)

        cli_client_id = d.pop("cli_client_id", UNSET)

        audience = d.pop("audience", UNSET)

        sso_config_response = cls(
            sso_enabled=sso_enabled,
            domain=domain,
            client_id=client_id,
            cli_client_id=cli_client_id,
            audience=audience,
        )


        sso_config_response.additional_properties = d
        return sso_config_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
