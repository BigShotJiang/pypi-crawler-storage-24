from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="AllLlmCallsAggregate")



@_attrs_define
class AllLlmCallsAggregate:
    """ Aggregate token usage across all LLM calls within a single request.

        Attributes:
            count (int): Number of LLM calls made
            input_tokens (int): Sum of prompt tokens across all calls
            output_tokens (int): Sum of completion tokens across all calls
            reasoning_tokens (int): Sum of reasoning tokens across all calls
            total_tokens (int): Sum of all tokens across all calls
            last_input_tokens (int): Input tokens from the most recent LLM call (= current thread size)
     """

    count: int
    input_tokens: int
    output_tokens: int
    reasoning_tokens: int
    total_tokens: int
    last_input_tokens: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        count = self.count

        input_tokens = self.input_tokens

        output_tokens = self.output_tokens

        reasoning_tokens = self.reasoning_tokens

        total_tokens = self.total_tokens

        last_input_tokens = self.last_input_tokens


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "count": count,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "reasoning_tokens": reasoning_tokens,
            "total_tokens": total_tokens,
            "last_input_tokens": last_input_tokens,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        count = d.pop("count")

        input_tokens = d.pop("input_tokens")

        output_tokens = d.pop("output_tokens")

        reasoning_tokens = d.pop("reasoning_tokens")

        total_tokens = d.pop("total_tokens")

        last_input_tokens = d.pop("last_input_tokens")

        all_llm_calls_aggregate = cls(
            count=count,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            reasoning_tokens=reasoning_tokens,
            total_tokens=total_tokens,
            last_input_tokens=last_input_tokens,
        )


        all_llm_calls_aggregate.additional_properties = d
        return all_llm_calls_aggregate

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
