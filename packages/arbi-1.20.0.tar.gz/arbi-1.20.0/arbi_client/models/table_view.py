from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast






T = TypeVar("T", bound="TableView")



@_attrs_define
class TableView:
    """ Saved column configuration for the document table.

    Column ID formats:
    - Standard columns: "doc_date", "title", "file_name", "status", "n_pages", "created_at"
    - Tags: tag external ID (e.g., "tag-a1b2c3d4")

        Attributes:
            workspace (str):
            name (str):
            columns (list[str]):
     """

    workspace: str
    name: str
    columns: list[str]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        workspace = self.workspace

        name = self.name

        columns = self.columns




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "workspace": workspace,
            "name": name,
            "columns": columns,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        workspace = d.pop("workspace")

        name = d.pop("name")

        columns = cast(list[str], d.pop("columns"))


        table_view = cls(
            workspace=workspace,
            name=name,
            columns=columns,
        )


        table_view.additional_properties = d
        return table_view

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
