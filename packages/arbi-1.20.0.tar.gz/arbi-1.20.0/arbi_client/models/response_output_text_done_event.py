from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import Literal, cast






T = TypeVar("T", bound="ResponseOutputTextDoneEvent")



@_attrs_define
class ResponseOutputTextDoneEvent:
    """ OpenAI response.output_text.done: final assembled text for a content part.

        Attributes:
            sequence_number (int): Monotonic sequence number for event ordering
            item_id (str): ID of the parent output message
            text (str): The complete assembled text
            type_ (Literal['response.output_text.done'] | Unset):  Default: 'response.output_text.done'.
            output_index (int | Unset):  Default: 0.
            content_index (int | Unset):  Default: 0.
     """

    sequence_number: int
    item_id: str
    text: str
    type_: Literal['response.output_text.done'] | Unset = 'response.output_text.done'
    output_index: int | Unset = 0
    content_index: int | Unset = 0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        sequence_number = self.sequence_number

        item_id = self.item_id

        text = self.text

        type_ = self.type_

        output_index = self.output_index

        content_index = self.content_index


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "sequence_number": sequence_number,
            "item_id": item_id,
            "text": text,
        })
        if type_ is not UNSET:
            field_dict["type"] = type_
        if output_index is not UNSET:
            field_dict["output_index"] = output_index
        if content_index is not UNSET:
            field_dict["content_index"] = content_index

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        sequence_number = d.pop("sequence_number")

        item_id = d.pop("item_id")

        text = d.pop("text")

        type_ = cast(Literal['response.output_text.done'] | Unset , d.pop("type", UNSET))
        if type_ != 'response.output_text.done'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'response.output_text.done', got '{type_}'")

        output_index = d.pop("output_index", UNSET)

        content_index = d.pop("content_index", UNSET)

        response_output_text_done_event = cls(
            sequence_number=sequence_number,
            item_id=item_id,
            text=text,
            type_=type_,
            output_index=output_index,
            content_index=content_index,
        )


        response_output_text_done_event.additional_properties = d
        return response_output_text_done_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
