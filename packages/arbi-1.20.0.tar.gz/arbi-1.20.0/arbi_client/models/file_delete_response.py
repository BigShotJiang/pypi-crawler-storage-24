from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="FileDeleteResponse")



@_attrs_define
class FileDeleteResponse:
    """ OpenAI-compatible file deletion response.

        Attributes:
            id (str):
            object_ (str | Unset):  Default: 'file'.
            deleted (bool | Unset):  Default: True.
     """

    id: str
    object_: str | Unset = 'file'
    deleted: bool | Unset = True
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        object_ = self.object_

        deleted = self.deleted


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
        })
        if object_ is not UNSET:
            field_dict["object"] = object_
        if deleted is not UNSET:
            field_dict["deleted"] = deleted

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        object_ = d.pop("object", UNSET)

        deleted = d.pop("deleted", UNSET)

        file_delete_response = cls(
            id=id,
            object_=object_,
            deleted=deleted,
        )


        file_delete_response.additional_properties = d
        return file_delete_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
