from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="CitationData")



@_attrs_define
class CitationData:
    """ Data for a single citation - shared by DocTags and ModelCitationTool.

        Attributes:
            chunk_ids (list[str]):
            statement (str):
            offset_start (int):
            offset_end (int):
            scores (list[float] | Unset):
     """

    chunk_ids: list[str]
    statement: str
    offset_start: int
    offset_end: int
    scores: list[float] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        chunk_ids = self.chunk_ids



        statement = self.statement

        offset_start = self.offset_start

        offset_end = self.offset_end

        scores: list[float] | Unset = UNSET
        if not isinstance(self.scores, Unset):
            scores = self.scores




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "chunk_ids": chunk_ids,
            "statement": statement,
            "offset_start": offset_start,
            "offset_end": offset_end,
        })
        if scores is not UNSET:
            field_dict["scores"] = scores

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        chunk_ids = cast(list[str], d.pop("chunk_ids"))


        statement = d.pop("statement")

        offset_start = d.pop("offset_start")

        offset_end = d.pop("offset_end")

        scores = cast(list[float], d.pop("scores", UNSET))


        citation_data = cls(
            chunk_ids=chunk_ids,
            statement=statement,
            offset_start=offset_start,
            offset_end=offset_end,
            scores=scores,
        )


        citation_data.additional_properties = d
        return citation_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
