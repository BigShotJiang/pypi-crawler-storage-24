from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="OutputTokensDetails")



@_attrs_define
class OutputTokensDetails:
    """ Nested output token details per OpenAI spec.

        Attributes:
            reasoning_tokens (int | Unset): Reasoning tokens used by the model Default: 0.
     """

    reasoning_tokens: int | Unset = 0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        reasoning_tokens = self.reasoning_tokens


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if reasoning_tokens is not UNSET:
            field_dict["reasoning_tokens"] = reasoning_tokens

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        reasoning_tokens = d.pop("reasoning_tokens", UNSET)

        output_tokens_details = cls(
            reasoning_tokens=reasoning_tokens,
        )


        output_tokens_details.additional_properties = d
        return output_tokens_details

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
