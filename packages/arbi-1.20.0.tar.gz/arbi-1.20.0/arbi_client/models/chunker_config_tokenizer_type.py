from enum import Enum

class ChunkerConfigTokenizerType(str, Enum):
    HUGGINGFACE = "huggingface"
    TIKTOKEN = "tiktoken"

    def __str__(self) -> str:
        return str(self.value)
