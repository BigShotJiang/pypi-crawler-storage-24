from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.share_conversation_response import ShareConversationResponse
from typing import cast



def _get_kwargs(
    conversation_ext_id: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/conversation/{conversation_ext_id}/share".format(conversation_ext_id=quote(str(conversation_ext_id), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | ShareConversationResponse | None:
    if response.status_code == 200:
        response_200 = ShareConversationResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | ShareConversationResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    conversation_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[HTTPValidationError | ShareConversationResponse]:
    """ Share Conversation

     Share all messages in a conversation by setting their shared flag to true.

    Only the conversation creator can share a conversation.

    Args:
        conversation_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ShareConversationResponse]
     """


    kwargs = _get_kwargs(
        conversation_ext_id=conversation_ext_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    conversation_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> HTTPValidationError | ShareConversationResponse | None:
    """ Share Conversation

     Share all messages in a conversation by setting their shared flag to true.

    Only the conversation creator can share a conversation.

    Args:
        conversation_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ShareConversationResponse
     """


    return sync_detailed(
        conversation_ext_id=conversation_ext_id,
client=client,

    ).parsed

async def asyncio_detailed(
    conversation_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[HTTPValidationError | ShareConversationResponse]:
    """ Share Conversation

     Share all messages in a conversation by setting their shared flag to true.

    Only the conversation creator can share a conversation.

    Args:
        conversation_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ShareConversationResponse]
     """


    kwargs = _get_kwargs(
        conversation_ext_id=conversation_ext_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    conversation_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> HTTPValidationError | ShareConversationResponse | None:
    """ Share Conversation

     Share all messages in a conversation by setting their shared flag to true.

    Only the conversation creator can share a conversation.

    Args:
        conversation_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ShareConversationResponse
     """


    return (await asyncio_detailed(
        conversation_ext_id=conversation_ext_id,
client=client,

    )).parsed
