from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.message_response import MessageResponse
from typing import cast



def _get_kwargs(
    message_ext_id: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/conversation/message/{message_ext_id}".format(message_ext_id=quote(str(message_ext_id), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | MessageResponse | None:
    if response.status_code == 200:
        response_200 = MessageResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | MessageResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    message_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[HTTPValidationError | MessageResponse]:
    """ Get Message Details

     Get a single message with full details including decrypted execution trace.
    Always includes the trace with decrypted sensitive fields.

    Args:
        message_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | MessageResponse]
     """


    kwargs = _get_kwargs(
        message_ext_id=message_ext_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    message_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> HTTPValidationError | MessageResponse | None:
    """ Get Message Details

     Get a single message with full details including decrypted execution trace.
    Always includes the trace with decrypted sensitive fields.

    Args:
        message_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | MessageResponse
     """


    return sync_detailed(
        message_ext_id=message_ext_id,
client=client,

    ).parsed

async def asyncio_detailed(
    message_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[HTTPValidationError | MessageResponse]:
    """ Get Message Details

     Get a single message with full details including decrypted execution trace.
    Always includes the trace with decrypted sensitive fields.

    Args:
        message_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | MessageResponse]
     """


    kwargs = _get_kwargs(
        message_ext_id=message_ext_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    message_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> HTTPValidationError | MessageResponse | None:
    """ Get Message Details

     Get a single message with full details including decrypted execution trace.
    Always includes the trace with decrypted sensitive fields.

    Args:
        message_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | MessageResponse
     """


    return (await asyncio_detailed(
        message_ext_id=message_ext_id,
client=client,

    )).parsed
