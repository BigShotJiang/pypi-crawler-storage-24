from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from typing import cast



def _get_kwargs(
    document_ext_id: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/document/{document_ext_id}/view".format(document_ext_id=quote(str(document_ext_id), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = cast(Any, None)
        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    document_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[Any | HTTPValidationError]:
    """ View Document Inline

     View a document inline in the browser.
    Retrieves and decrypts the document for inline viewing with optional page specification.

    Args:
        document_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        document_ext_id=document_ext_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    document_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Any | HTTPValidationError | None:
    """ View Document Inline

     View a document inline in the browser.
    Retrieves and decrypts the document for inline viewing with optional page specification.

    Args:
        document_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
     """


    return sync_detailed(
        document_ext_id=document_ext_id,
client=client,

    ).parsed

async def asyncio_detailed(
    document_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[Any | HTTPValidationError]:
    """ View Document Inline

     View a document inline in the browser.
    Retrieves and decrypts the document for inline viewing with optional page specification.

    Args:
        document_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        document_ext_id=document_ext_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    document_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Any | HTTPValidationError | None:
    """ View Document Inline

     View a document inline in the browser.
    Retrieves and decrypts the document for inline viewing with optional page specification.

    Args:
        document_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
     """


    return (await asyncio_detailed(
        document_ext_id=document_ext_id,
client=client,

    )).parsed
