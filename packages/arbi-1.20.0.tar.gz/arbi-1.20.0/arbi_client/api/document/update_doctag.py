from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.doc_tag_response import DocTagResponse
from ...models.http_validation_error import HTTPValidationError
from ...models.update_doc_tag_request import UpdateDocTagRequest
from typing import cast



def _get_kwargs(
    *,
    body: UpdateDocTagRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v1/document/doctag",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> DocTagResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = DocTagResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[DocTagResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UpdateDocTagRequest,

) -> Response[DocTagResponse | HTTPValidationError]:
    """ Update Doctag

     Update a doctag's note or citations.

    Args:
        body (UpdateDocTagRequest): Update a doctag's note or citations. Identified by
            (tag_ext_id, doc_ext_id) pair.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DocTagResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: UpdateDocTagRequest,

) -> DocTagResponse | HTTPValidationError | None:
    """ Update Doctag

     Update a doctag's note or citations.

    Args:
        body (UpdateDocTagRequest): Update a doctag's note or citations. Identified by
            (tag_ext_id, doc_ext_id) pair.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DocTagResponse | HTTPValidationError
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UpdateDocTagRequest,

) -> Response[DocTagResponse | HTTPValidationError]:
    """ Update Doctag

     Update a doctag's note or citations.

    Args:
        body (UpdateDocTagRequest): Update a doctag's note or citations. Identified by
            (tag_ext_id, doc_ext_id) pair.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DocTagResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: UpdateDocTagRequest,

) -> DocTagResponse | HTTPValidationError | None:
    """ Update Doctag

     Update a doctag's note or citations.

    Args:
        body (UpdateDocTagRequest): Update a doctag's note or citations. Identified by
            (tag_ext_id, doc_ext_id) pair.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DocTagResponse | HTTPValidationError
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
