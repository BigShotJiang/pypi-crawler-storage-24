from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.logout_response import LogoutResponse
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    all_sessions: bool | Unset = False,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["all_sessions"] = all_sessions


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/user/logout",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | LogoutResponse | None:
    if response.status_code == 200:
        response_200 = LogoutResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | LogoutResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    all_sessions: bool | Unset = False,

) -> Response[HTTPValidationError | LogoutResponse]:
    """ Logout

     Log out the current user. Pass ?all_sessions=true to log out from all devices.

    Args:
        all_sessions (bool | Unset): If true, log out from all sessions (all devices) Default:
            False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | LogoutResponse]
     """


    kwargs = _get_kwargs(
        all_sessions=all_sessions,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    all_sessions: bool | Unset = False,

) -> HTTPValidationError | LogoutResponse | None:
    """ Logout

     Log out the current user. Pass ?all_sessions=true to log out from all devices.

    Args:
        all_sessions (bool | Unset): If true, log out from all sessions (all devices) Default:
            False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | LogoutResponse
     """


    return sync_detailed(
        client=client,
all_sessions=all_sessions,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    all_sessions: bool | Unset = False,

) -> Response[HTTPValidationError | LogoutResponse]:
    """ Logout

     Log out the current user. Pass ?all_sessions=true to log out from all devices.

    Args:
        all_sessions (bool | Unset): If true, log out from all sessions (all devices) Default:
            False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | LogoutResponse]
     """


    kwargs = _get_kwargs(
        all_sessions=all_sessions,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    all_sessions: bool | Unset = False,

) -> HTTPValidationError | LogoutResponse | None:
    """ Logout

     Log out the current user. Pass ?all_sessions=true to log out from all devices.

    Args:
        all_sessions (bool | Unset): If true, log out from all sessions (all devices) Default:
            False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | LogoutResponse
     """


    return (await asyncio_detailed(
        client=client,
all_sessions=all_sessions,

    )).parsed
