from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.authorize_request import AuthorizeRequest
from ...models.authorize_response import AuthorizeResponse
from ...models.http_validation_error import HTTPValidationError
from typing import cast



def _get_kwargs(
    *,
    body: AuthorizeRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/user/authorize",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> AuthorizeResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = AuthorizeResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[AuthorizeResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AuthorizeRequest,

) -> Response[AuthorizeResponse | HTTPValidationError]:
    """ Authorize Session Endpoint

     Create a delegated session with pre-populated workspace keys.

    Frontend sends workspace keys SealedBox-encrypted with the user's session public key.
    Server decrypts them, re-encrypts with a new session keypair, and creates a pending
    session keyed by a 3-word claim code. The recipient redeems the code via POST /user/token.

    If persist_identity is True, the claim also creates a persistent Agent identity
    with WorkspaceUsers rows so the agent can re-login later.

    Args:
        body (AuthorizeRequest): Authorize a delegated session with workspace keys.

            Used by: POST /user/authorize (authenticated)

            Frontend sends workspace keys SealedBox-encrypted with the user's session public key.
            Server decrypts them, re-encrypts with a new session keypair, and creates a pending
            session keyed by a 3-word claim code. The recipient redeems the code via POST /user/token.

            If persist_identity is True, the claim creates a persistent Agent identity
            with its own keypair and WorkspaceUsers rows. The agent can then re-login.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AuthorizeResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: AuthorizeRequest,

) -> AuthorizeResponse | HTTPValidationError | None:
    """ Authorize Session Endpoint

     Create a delegated session with pre-populated workspace keys.

    Frontend sends workspace keys SealedBox-encrypted with the user's session public key.
    Server decrypts them, re-encrypts with a new session keypair, and creates a pending
    session keyed by a 3-word claim code. The recipient redeems the code via POST /user/token.

    If persist_identity is True, the claim also creates a persistent Agent identity
    with WorkspaceUsers rows so the agent can re-login later.

    Args:
        body (AuthorizeRequest): Authorize a delegated session with workspace keys.

            Used by: POST /user/authorize (authenticated)

            Frontend sends workspace keys SealedBox-encrypted with the user's session public key.
            Server decrypts them, re-encrypts with a new session keypair, and creates a pending
            session keyed by a 3-word claim code. The recipient redeems the code via POST /user/token.

            If persist_identity is True, the claim creates a persistent Agent identity
            with its own keypair and WorkspaceUsers rows. The agent can then re-login.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AuthorizeResponse | HTTPValidationError
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AuthorizeRequest,

) -> Response[AuthorizeResponse | HTTPValidationError]:
    """ Authorize Session Endpoint

     Create a delegated session with pre-populated workspace keys.

    Frontend sends workspace keys SealedBox-encrypted with the user's session public key.
    Server decrypts them, re-encrypts with a new session keypair, and creates a pending
    session keyed by a 3-word claim code. The recipient redeems the code via POST /user/token.

    If persist_identity is True, the claim also creates a persistent Agent identity
    with WorkspaceUsers rows so the agent can re-login later.

    Args:
        body (AuthorizeRequest): Authorize a delegated session with workspace keys.

            Used by: POST /user/authorize (authenticated)

            Frontend sends workspace keys SealedBox-encrypted with the user's session public key.
            Server decrypts them, re-encrypts with a new session keypair, and creates a pending
            session keyed by a 3-word claim code. The recipient redeems the code via POST /user/token.

            If persist_identity is True, the claim creates a persistent Agent identity
            with its own keypair and WorkspaceUsers rows. The agent can then re-login.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AuthorizeResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: AuthorizeRequest,

) -> AuthorizeResponse | HTTPValidationError | None:
    """ Authorize Session Endpoint

     Create a delegated session with pre-populated workspace keys.

    Frontend sends workspace keys SealedBox-encrypted with the user's session public key.
    Server decrypts them, re-encrypts with a new session keypair, and creates a pending
    session keyed by a 3-word claim code. The recipient redeems the code via POST /user/token.

    If persist_identity is True, the claim also creates a persistent Agent identity
    with WorkspaceUsers rows so the agent can re-login later.

    Args:
        body (AuthorizeRequest): Authorize a delegated session with workspace keys.

            Used by: POST /user/authorize (authenticated)

            Frontend sends workspace keys SealedBox-encrypted with the user's session public key.
            Server decrypts them, re-encrypts with a new session keypair, and creates a pending
            session keyed by a 3-word claim code. The recipient redeems the code via POST /user/token.

            If persist_identity is True, the claim creates a persistent Agent identity
            with its own keypair and WorkspaceUsers rows. The agent can then re-login.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AuthorizeResponse | HTTPValidationError
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
