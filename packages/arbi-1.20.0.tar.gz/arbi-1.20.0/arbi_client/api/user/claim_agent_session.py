from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.agent_session_claim_request import AgentSessionClaimRequest
from ...models.http_validation_error import HTTPValidationError
from ...models.login_response import LoginResponse
from typing import cast



def _get_kwargs(
    *,
    body: AgentSessionClaimRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/user/token",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | LoginResponse | None:
    if response.status_code == 200:
        response_200 = LoginResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | LoginResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AgentSessionClaimRequest,

) -> Response[HTTPValidationError | LoginResponse]:
    """ Claim Agent Session Endpoint

     Claim an agent session using a 3-word code.

    Returns LoginResponse so the frontend can use the same auth code path as login.
    Workspaces are filtered to only those included in the delegation.

    If persist_identity was set on delegation:
    - signing_key is required in the request
    - Creates an Agent row and WorkspaceUsers rows (role=guest)

    Args:
        body (AgentSessionClaimRequest): Claim an agent session using a 3-word code.

            If the pending session has persist_identity=True, signing_key is required
            to create the Agent identity. Otherwise it is accepted but ignored.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | LoginResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: AgentSessionClaimRequest,

) -> HTTPValidationError | LoginResponse | None:
    """ Claim Agent Session Endpoint

     Claim an agent session using a 3-word code.

    Returns LoginResponse so the frontend can use the same auth code path as login.
    Workspaces are filtered to only those included in the delegation.

    If persist_identity was set on delegation:
    - signing_key is required in the request
    - Creates an Agent row and WorkspaceUsers rows (role=guest)

    Args:
        body (AgentSessionClaimRequest): Claim an agent session using a 3-word code.

            If the pending session has persist_identity=True, signing_key is required
            to create the Agent identity. Otherwise it is accepted but ignored.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | LoginResponse
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AgentSessionClaimRequest,

) -> Response[HTTPValidationError | LoginResponse]:
    """ Claim Agent Session Endpoint

     Claim an agent session using a 3-word code.

    Returns LoginResponse so the frontend can use the same auth code path as login.
    Workspaces are filtered to only those included in the delegation.

    If persist_identity was set on delegation:
    - signing_key is required in the request
    - Creates an Agent row and WorkspaceUsers rows (role=guest)

    Args:
        body (AgentSessionClaimRequest): Claim an agent session using a 3-word code.

            If the pending session has persist_identity=True, signing_key is required
            to create the Agent identity. Otherwise it is accepted but ignored.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | LoginResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: AgentSessionClaimRequest,

) -> HTTPValidationError | LoginResponse | None:
    """ Claim Agent Session Endpoint

     Claim an agent session using a 3-word code.

    Returns LoginResponse so the frontend can use the same auth code path as login.
    Workspaces are filtered to only those included in the delegation.

    If persist_identity was set on delegation:
    - signing_key is required in the request
    - Creates an Agent row and WorkspaceUsers rows (role=guest)

    Args:
        body (AgentSessionClaimRequest): Claim an agent session using a 3-word code.

            If the pending session has persist_identity=True, signing_key is required
            to create the Agent identity. Otherwise it is accepted but ignored.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | LoginResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
