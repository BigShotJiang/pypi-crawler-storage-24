from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.user_settings_update import UserSettingsUpdate
from typing import cast



def _get_kwargs(
    *,
    body: UserSettingsUpdate,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v1/user/settings",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | HTTPValidationError | None:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UserSettingsUpdate,

) -> Response[Any | HTTPValidationError]:
    """ Update User Settings

     Update user's settings (merge with existing).

    Note: subscription fields are managed automatically and cannot be patched.

    Args:
        body (UserSettingsUpdate): User settings update request - allows partial updates.

            Note: stripe_customer_id and status are not patchable.
            trial_expires can only be set once (to start trial).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: UserSettingsUpdate,

) -> Any | HTTPValidationError | None:
    """ Update User Settings

     Update user's settings (merge with existing).

    Note: subscription fields are managed automatically and cannot be patched.

    Args:
        body (UserSettingsUpdate): User settings update request - allows partial updates.

            Note: stripe_customer_id and status are not patchable.
            trial_expires can only be set once (to start trial).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UserSettingsUpdate,

) -> Response[Any | HTTPValidationError]:
    """ Update User Settings

     Update user's settings (merge with existing).

    Note: subscription fields are managed automatically and cannot be patched.

    Args:
        body (UserSettingsUpdate): User settings update request - allows partial updates.

            Note: stripe_customer_id and status are not patchable.
            trial_expires can only be set once (to start trial).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: UserSettingsUpdate,

) -> Any | HTTPValidationError | None:
    """ Update User Settings

     Update user's settings (merge with existing).

    Note: subscription fields are managed automatically and cannot be patched.

    Args:
        body (UserSettingsUpdate): User settings update request - allows partial updates.

            Note: stripe_customer_id and status are not patchable.
            trial_expires can only be set once (to start trial).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
