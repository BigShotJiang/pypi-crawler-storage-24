from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.delete_agents_request import DeleteAgentsRequest
from ...models.delete_agents_response_delete_agents import DeleteAgentsResponseDeleteAgents
from ...models.http_validation_error import HTTPValidationError
from typing import cast



def _get_kwargs(
    *,
    body: DeleteAgentsRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v1/user/agents",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> DeleteAgentsResponseDeleteAgents | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = DeleteAgentsResponseDeleteAgents.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[DeleteAgentsResponseDeleteAgents | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: DeleteAgentsRequest,

) -> Response[DeleteAgentsResponseDeleteAgents | HTTPValidationError]:
    """ Delete User Agents

     Delete agents by external ID.

    A BEFORE DELETE trigger on users reassigns created_by to parent_user_id,
    nulls updated_by, and deletes contacts. CASCADE handles WorkspaceUsers.

    Args:
        body (DeleteAgentsRequest): Request to delete agents by external ID.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteAgentsResponseDeleteAgents | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: DeleteAgentsRequest,

) -> DeleteAgentsResponseDeleteAgents | HTTPValidationError | None:
    """ Delete User Agents

     Delete agents by external ID.

    A BEFORE DELETE trigger on users reassigns created_by to parent_user_id,
    nulls updated_by, and deletes contacts. CASCADE handles WorkspaceUsers.

    Args:
        body (DeleteAgentsRequest): Request to delete agents by external ID.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteAgentsResponseDeleteAgents | HTTPValidationError
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: DeleteAgentsRequest,

) -> Response[DeleteAgentsResponseDeleteAgents | HTTPValidationError]:
    """ Delete User Agents

     Delete agents by external ID.

    A BEFORE DELETE trigger on users reassigns created_by to parent_user_id,
    nulls updated_by, and deletes contacts. CASCADE handles WorkspaceUsers.

    Args:
        body (DeleteAgentsRequest): Request to delete agents by external ID.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteAgentsResponseDeleteAgents | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: DeleteAgentsRequest,

) -> DeleteAgentsResponseDeleteAgents | HTTPValidationError | None:
    """ Delete User Agents

     Delete agents by external ID.

    A BEFORE DELETE trigger on users reassigns created_by to parent_user_id,
    nulls updated_by, and deletes contacts. CASCADE handles WorkspaceUsers.

    Args:
        body (DeleteAgentsRequest): Request to delete agents by external ID.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteAgentsResponseDeleteAgents | HTTPValidationError
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
