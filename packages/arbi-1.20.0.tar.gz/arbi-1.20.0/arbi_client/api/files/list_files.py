from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.file_list_response import FileListResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    purpose: None | str | Unset = UNSET,
    limit: int | Unset = 10000,
    order: str | Unset = 'desc',
    after: None | str | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    json_purpose: None | str | Unset
    if isinstance(purpose, Unset):
        json_purpose = UNSET
    else:
        json_purpose = purpose
    params["purpose"] = json_purpose

    params["limit"] = limit

    params["order"] = order

    json_after: None | str | Unset
    if isinstance(after, Unset):
        json_after = UNSET
    else:
        json_after = after
    params["after"] = json_after


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/files",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> FileListResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = FileListResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[FileListResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    purpose: None | str | Unset = UNSET,
    limit: int | Unset = 10000,
    order: str | Unset = 'desc',
    after: None | str | Unset = UNSET,

) -> Response[FileListResponse | HTTPValidationError]:
    """ List Files

     List files in the workspace (OpenAI-compatible) with cursor pagination.

    Args:
        purpose (None | str | Unset): Filter by purpose
        limit (int | Unset): Number of files to return Default: 10000.
        order (str | Unset): Sort order by created_at: 'asc' or 'desc' Default: 'desc'.
        after (None | str | Unset): Cursor for pagination (file ID to start after)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FileListResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        purpose=purpose,
limit=limit,
order=order,
after=after,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    purpose: None | str | Unset = UNSET,
    limit: int | Unset = 10000,
    order: str | Unset = 'desc',
    after: None | str | Unset = UNSET,

) -> FileListResponse | HTTPValidationError | None:
    """ List Files

     List files in the workspace (OpenAI-compatible) with cursor pagination.

    Args:
        purpose (None | str | Unset): Filter by purpose
        limit (int | Unset): Number of files to return Default: 10000.
        order (str | Unset): Sort order by created_at: 'asc' or 'desc' Default: 'desc'.
        after (None | str | Unset): Cursor for pagination (file ID to start after)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileListResponse | HTTPValidationError
     """


    return sync_detailed(
        client=client,
purpose=purpose,
limit=limit,
order=order,
after=after,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    purpose: None | str | Unset = UNSET,
    limit: int | Unset = 10000,
    order: str | Unset = 'desc',
    after: None | str | Unset = UNSET,

) -> Response[FileListResponse | HTTPValidationError]:
    """ List Files

     List files in the workspace (OpenAI-compatible) with cursor pagination.

    Args:
        purpose (None | str | Unset): Filter by purpose
        limit (int | Unset): Number of files to return Default: 10000.
        order (str | Unset): Sort order by created_at: 'asc' or 'desc' Default: 'desc'.
        after (None | str | Unset): Cursor for pagination (file ID to start after)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FileListResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        purpose=purpose,
limit=limit,
order=order,
after=after,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    purpose: None | str | Unset = UNSET,
    limit: int | Unset = 10000,
    order: str | Unset = 'desc',
    after: None | str | Unset = UNSET,

) -> FileListResponse | HTTPValidationError | None:
    """ List Files

     List files in the workspace (OpenAI-compatible) with cursor pagination.

    Args:
        purpose (None | str | Unset): Filter by purpose
        limit (int | Unset): Number of files to return Default: 10000.
        order (str | Unset): Sort order by created_at: 'asc' or 'desc' Default: 'desc'.
        after (None | str | Unset): Cursor for pagination (file ID to start after)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileListResponse | HTTPValidationError
     """


    return (await asyncio_detailed(
        client=client,
purpose=purpose,
limit=limit,
order=order,
after=after,

    )).parsed
