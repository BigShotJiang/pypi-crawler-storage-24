from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.file_object import FileObject
from ...models.upload_file_body import UploadFileBody
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    body: UploadFileBody | Unset = UNSET,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/files",
    }

    if not isinstance(body, Unset):
        _kwargs["files"] = body.to_multipart()



    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> FileObject | None:
    if response.status_code == 200:
        response_200 = FileObject.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[FileObject]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UploadFileBody | Unset = UNSET,

) -> Response[FileObject]:
    """ Upload File

     Upload a file (OpenAI-compatible).

    Accepts a multipart form with 'file' (binary) and 'purpose' (string) fields.

    Args:
        body (UploadFileBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FileObject]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: UploadFileBody | Unset = UNSET,

) -> FileObject | None:
    """ Upload File

     Upload a file (OpenAI-compatible).

    Accepts a multipart form with 'file' (binary) and 'purpose' (string) fields.

    Args:
        body (UploadFileBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileObject
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UploadFileBody | Unset = UNSET,

) -> Response[FileObject]:
    """ Upload File

     Upload a file (OpenAI-compatible).

    Accepts a multipart form with 'file' (binary) and 'purpose' (string) fields.

    Args:
        body (UploadFileBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FileObject]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: UploadFileBody | Unset = UNSET,

) -> FileObject | None:
    """ Upload File

     Upload a file (OpenAI-compatible).

    Accepts a multipart form with 'file' (binary) and 'purpose' (string) fields.

    Args:
        body (UploadFileBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileObject
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
