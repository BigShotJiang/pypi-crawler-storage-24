from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.file_delete_response import FileDeleteResponse
from ...models.http_validation_error import HTTPValidationError
from typing import cast



def _get_kwargs(
    file_id: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v1/files/{file_id}".format(file_id=quote(str(file_id), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> FileDeleteResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = FileDeleteResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[FileDeleteResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    file_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[FileDeleteResponse | HTTPValidationError]:
    """ Delete File

     Delete a file by ID (OpenAI-compatible).

    Args:
        file_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FileDeleteResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        file_id=file_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    file_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> FileDeleteResponse | HTTPValidationError | None:
    """ Delete File

     Delete a file by ID (OpenAI-compatible).

    Args:
        file_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileDeleteResponse | HTTPValidationError
     """


    return sync_detailed(
        file_id=file_id,
client=client,

    ).parsed

async def asyncio_detailed(
    file_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[FileDeleteResponse | HTTPValidationError]:
    """ Delete File

     Delete a file by ID (OpenAI-compatible).

    Args:
        file_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FileDeleteResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        file_id=file_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    file_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> FileDeleteResponse | HTTPValidationError | None:
    """ Delete File

     Delete a file by ID (OpenAI-compatible).

    Args:
        file_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileDeleteResponse | HTTPValidationError
     """


    return (await asyncio_detailed(
        file_id=file_id,
client=client,

    )).parsed
