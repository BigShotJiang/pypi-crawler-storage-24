from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.copy_request import CopyRequest
from ...models.copy_response import CopyResponse
from ...models.http_validation_error import HTTPValidationError
from typing import cast



def _get_kwargs(
    *,
    body: CopyRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/workspace/copy",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> CopyResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = CopyResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[CopyResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CopyRequest,

) -> Response[CopyResponse | HTTPValidationError]:
    """ Copy Workspace Data

     Copy documents from source workspace (current) to target workspace.

    Requires workspace-scoped JWT for the source workspace.
    Target workspace key is provided in the request body (SecretBox-encrypted with session key).

    Copies:
    - Document metadata (title, doc_date, shared status, etc.)
    - MinIO encrypted files (downloaded to server memory, re-encrypted, uploaded)
    - Qdrant vectors (with updated doc_ext_id and chunk_ext_id references)

    Args:
        body (CopyRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CopyResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CopyRequest,

) -> CopyResponse | HTTPValidationError | None:
    """ Copy Workspace Data

     Copy documents from source workspace (current) to target workspace.

    Requires workspace-scoped JWT for the source workspace.
    Target workspace key is provided in the request body (SecretBox-encrypted with session key).

    Copies:
    - Document metadata (title, doc_date, shared status, etc.)
    - MinIO encrypted files (downloaded to server memory, re-encrypted, uploaded)
    - Qdrant vectors (with updated doc_ext_id and chunk_ext_id references)

    Args:
        body (CopyRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CopyResponse | HTTPValidationError
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CopyRequest,

) -> Response[CopyResponse | HTTPValidationError]:
    """ Copy Workspace Data

     Copy documents from source workspace (current) to target workspace.

    Requires workspace-scoped JWT for the source workspace.
    Target workspace key is provided in the request body (SecretBox-encrypted with session key).

    Copies:
    - Document metadata (title, doc_date, shared status, etc.)
    - MinIO encrypted files (downloaded to server memory, re-encrypted, uploaded)
    - Qdrant vectors (with updated doc_ext_id and chunk_ext_id references)

    Args:
        body (CopyRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CopyResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CopyRequest,

) -> CopyResponse | HTTPValidationError | None:
    """ Copy Workspace Data

     Copy documents from source workspace (current) to target workspace.

    Requires workspace-scoped JWT for the source workspace.
    Target workspace key is provided in the request body (SecretBox-encrypted with session key).

    Copies:
    - Document metadata (title, doc_date, shared status, etc.)
    - MinIO encrypted files (downloaded to server memory, re-encrypted, uploaded)
    - Qdrant vectors (with updated doc_ext_id and chunk_ext_id references)

    Args:
        body (CopyRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CopyResponse | HTTPValidationError
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
