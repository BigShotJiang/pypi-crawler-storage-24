from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.update_workspace_user_roles_request import UpdateWorkspaceUserRolesRequest
from ...models.workspace_user_response import WorkspaceUserResponse
from typing import cast



def _get_kwargs(
    *,
    body: UpdateWorkspaceUserRolesRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v1/workspace/users",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | list[WorkspaceUserResponse] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in (_response_200):
            response_200_item = WorkspaceUserResponse.from_dict(response_200_item_data)



            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | list[WorkspaceUserResponse]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UpdateWorkspaceUserRolesRequest,

) -> Response[HTTPValidationError | list[WorkspaceUserResponse]]:
    """ Update Workspace User Roles

     Update user roles in a workspace (bulk operation). Only workspace owners can update roles.
    Returns the full WorkspaceUserResponse for each successfully updated user.

    Args:
        body (UpdateWorkspaceUserRolesRequest): Request to update user or agent roles in a
            workspace (PATCH /workspace/{id}/users).

            All specified users/agents are updated to the same role.
            Accepts both usr-XXXXXXXX and agt-XXXXXXXX external IDs.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[WorkspaceUserResponse]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: UpdateWorkspaceUserRolesRequest,

) -> HTTPValidationError | list[WorkspaceUserResponse] | None:
    """ Update Workspace User Roles

     Update user roles in a workspace (bulk operation). Only workspace owners can update roles.
    Returns the full WorkspaceUserResponse for each successfully updated user.

    Args:
        body (UpdateWorkspaceUserRolesRequest): Request to update user or agent roles in a
            workspace (PATCH /workspace/{id}/users).

            All specified users/agents are updated to the same role.
            Accepts both usr-XXXXXXXX and agt-XXXXXXXX external IDs.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[WorkspaceUserResponse]
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UpdateWorkspaceUserRolesRequest,

) -> Response[HTTPValidationError | list[WorkspaceUserResponse]]:
    """ Update Workspace User Roles

     Update user roles in a workspace (bulk operation). Only workspace owners can update roles.
    Returns the full WorkspaceUserResponse for each successfully updated user.

    Args:
        body (UpdateWorkspaceUserRolesRequest): Request to update user or agent roles in a
            workspace (PATCH /workspace/{id}/users).

            All specified users/agents are updated to the same role.
            Accepts both usr-XXXXXXXX and agt-XXXXXXXX external IDs.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[WorkspaceUserResponse]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: UpdateWorkspaceUserRolesRequest,

) -> HTTPValidationError | list[WorkspaceUserResponse] | None:
    """ Update Workspace User Roles

     Update user roles in a workspace (bulk operation). Only workspace owners can update roles.
    Returns the full WorkspaceUserResponse for each successfully updated user.

    Args:
        body (UpdateWorkspaceUserRolesRequest): Request to update user or agent roles in a
            workspace (PATCH /workspace/{id}/users).

            All specified users/agents are updated to the same role.
            Accepts both usr-XXXXXXXX and agt-XXXXXXXX external IDs.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[WorkspaceUserResponse]
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
