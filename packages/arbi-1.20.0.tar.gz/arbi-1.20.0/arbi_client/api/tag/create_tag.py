from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_tag_request import CreateTagRequest
from ...models.http_validation_error import HTTPValidationError
from ...models.tag_response import TagResponse
from typing import cast



def _get_kwargs(
    *,
    body: CreateTagRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/tag/",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | TagResponse | None:
    if response.status_code == 201:
        response_201 = TagResponse.from_dict(response.json())



        return response_201

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | TagResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateTagRequest,

) -> Response[HTTPValidationError | TagResponse]:
    """ Create Tag

     Create a new tag for a given workspace.

    If 'shared' is provided, the tag will be set to shared or private accordingly.
    If 'shared' is not provided, it defaults to True (shared).

    Args:
        body (CreateTagRequest): Request to create a new tag in a workspace.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | TagResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CreateTagRequest,

) -> HTTPValidationError | TagResponse | None:
    """ Create Tag

     Create a new tag for a given workspace.

    If 'shared' is provided, the tag will be set to shared or private accordingly.
    If 'shared' is not provided, it defaults to True (shared).

    Args:
        body (CreateTagRequest): Request to create a new tag in a workspace.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | TagResponse
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateTagRequest,

) -> Response[HTTPValidationError | TagResponse]:
    """ Create Tag

     Create a new tag for a given workspace.

    If 'shared' is provided, the tag will be set to shared or private accordingly.
    If 'shared' is not provided, it defaults to True (shared).

    Args:
        body (CreateTagRequest): Request to create a new tag in a workspace.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | TagResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CreateTagRequest,

) -> HTTPValidationError | TagResponse | None:
    """ Create Tag

     Create a new tag for a given workspace.

    If 'shared' is provided, the tag will be set to shared or private accordingly.
    If 'shared' is not provided, it defaults to True (shared).

    Args:
        body (CreateTagRequest): Request to create a new tag in a workspace.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | TagResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
