from __future__ import annotations

import json
import os
import signal
import subprocess
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from task_tracker.models import DATA_DIR

RECORDING_STATE_FILE = DATA_DIR / "recording.json"

# Auto-stop after 4 hours to prevent infinite recording
MAX_DURATION_SECONDS = 4 * 3600


class RecordingError(Exception):
    """Raised when recording fails."""


def _find_record_command() -> Optional[str]:
    """Find a CLI audio recorder: sox (rec) or ffmpeg."""
    for cmd in ("rec", "ffmpeg"):
        try:
            subprocess.run(
                [cmd, "--help"], capture_output=True, timeout=5,
            )
            return cmd
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue
    return None


def _find_concat_command() -> Optional[str]:
    """Find a tool to concatenate audio: sox or ffmpeg."""
    for cmd in ("sox", "ffmpeg"):
        try:
            subprocess.run(
                [cmd, "--help"], capture_output=True, timeout=5,
            )
            return cmd
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue
    return None


def _load_state() -> Optional[dict]:
    if not RECORDING_STATE_FILE.exists():
        return None
    try:
        return json.loads(RECORDING_STATE_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return None


def _save_state(state: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    RECORDING_STATE_FILE.write_text(json.dumps(state, indent=2))


def _clear_state() -> None:
    try:
        RECORDING_STATE_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def _is_process_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def _stop_process(pid: int) -> None:
    """Send SIGINT and wait for clean shutdown, force kill if needed."""
    if not _is_process_running(pid):
        return
    try:
        os.kill(pid, signal.SIGINT)
    except OSError:
        return

    for _ in range(100):
        if not _is_process_running(pid):
            return
        time.sleep(0.1)

    try:
        os.kill(pid, signal.SIGKILL)
    except OSError:
        pass


def _new_segment_path() -> str:
    """Create a new temp WAV file for a recording segment."""
    fd, path = tempfile.mkstemp(suffix=".wav", prefix="task-mom-")
    os.close(fd)
    return path


def _start_recorder(cmd: str, audio_path: str) -> subprocess.Popen:
    """Launch the recording process."""
    if cmd == "rec":
        args = [
            "rec", audio_path,
            "rate", "16000", "channels", "1",
            "trim", "0", str(MAX_DURATION_SECONDS),
        ]
    else:
        args = [
            "ffmpeg", "-y", "-f", "avfoundation", "-i", ":default",
            "-ac", "1", "-ar", "16000",
            "-t", str(MAX_DURATION_SECONDS),
            audio_path,
        ]

    return subprocess.Popen(
        args,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )


def _concat_segments(segments: list[str], output: str) -> None:
    """Concatenate multiple WAV segments into one file."""
    if len(segments) == 1:
        os.rename(segments[0], output)
        return

    cmd = _find_concat_command()
    if cmd == "sox":
        subprocess.run(
            ["sox"] + segments + [output],
            capture_output=True, timeout=120,
        )
    elif cmd == "ffmpeg":
        # Build concat filter input
        inputs = []
        for seg in segments:
            inputs.extend(["-i", seg])
        filter_str = "".join(f"[{i}:a]" for i in range(len(segments)))
        filter_str += f"concat=n={len(segments)}:v=0:a=1[out]"
        subprocess.run(
            ["ffmpeg", "-y"] + inputs +
            ["-filter_complex", filter_str, "-map", "[out]", output],
            capture_output=True, timeout=120,
        )
    else:
        # Fallback: just use the first segment
        os.rename(segments[0], output)


def is_recording() -> bool:
    state = _load_state()
    if not state:
        return False
    if state.get("paused"):
        return True
    return _is_process_running(state.get("pid", -1))


def start_recording() -> str:
    """Start recording from the microphone in the background."""
    state = _load_state()
    if state:
        if state.get("paused"):
            raise RecordingError(
                "Recording is paused. Resume with: task mom resume\n"
                "Or stop with: task mom stop"
            )
        if _is_process_running(state.get("pid", -1)):
            started = state.get("started_at", "unknown")
            raise RecordingError(
                f"Already recording since {started}. "
                "Stop it first with: task mom stop"
            )

    cmd = _find_record_command()
    if not cmd:
        raise RecordingError(
            "No audio recorder found. Install sox:\n"
            "  brew install sox"
        )

    segment = _new_segment_path()
    proc = _start_recorder(cmd, segment)
    now = datetime.now(timezone.utc).astimezone()

    _save_state({
        "pid": proc.pid,
        "segments": [segment],
        "started_at": now.isoformat(),
        "recorder": cmd,
        "paused": False,
    })

    max_hrs = MAX_DURATION_SECONDS // 3600
    return (
        f"Recording started (using {cmd})\n"
        f"  File: {segment}\n"
        f"  Time: {now.strftime('%H:%M:%S')}\n"
        f"  Max:  {max_hrs}h (auto-stops to prevent infinite recording)\n"
        "\n"
        "  task mom pause   — pause recording\n"
        "  task mom stop    — stop and generate minutes"
    )


def pause_recording() -> str:
    """Pause the current recording by stopping the process, keeping the segment."""
    state = _load_state()
    if not state:
        raise RecordingError("No recording in progress. Start one with: task mom listen")
    if state.get("paused"):
        raise RecordingError("Recording is already paused. Resume with: task mom resume")

    pid = state.get("pid", -1)
    if not _is_process_running(pid):
        raise RecordingError(
            "Recording process is no longer running.\n"
            "Use 'task mom stop' to process what was captured."
        )

    _stop_process(pid)

    state["paused"] = True
    state["pid"] = -1
    _save_state(state)

    segment_count = len(state.get("segments", []))
    return (
        f"Recording paused ({segment_count} segment{'s' if segment_count > 1 else ''} captured)\n"
        "\n"
        "  task mom resume  — continue recording\n"
        "  task mom stop    — stop and generate minutes"
    )


def resume_recording() -> str:
    """Resume a paused recording by starting a new segment."""
    state = _load_state()
    if not state:
        raise RecordingError("No recording in progress. Start one with: task mom listen")
    if not state.get("paused"):
        if _is_process_running(state.get("pid", -1)):
            raise RecordingError("Recording is already running.")
        raise RecordingError("Recording is not paused. Start a new one with: task mom listen")

    cmd = state.get("recorder") or _find_record_command()
    if not cmd:
        raise RecordingError("No audio recorder found. Install sox:\n  brew install sox")

    segment = _new_segment_path()
    proc = _start_recorder(cmd, segment)

    state["pid"] = proc.pid
    state["segments"].append(segment)
    state["paused"] = False
    _save_state(state)

    segment_count = len(state["segments"])
    return (
        f"Recording resumed (segment {segment_count})\n"
        "\n"
        "  task mom pause   — pause recording\n"
        "  task mom stop    — stop and generate minutes"
    )


def stop_recording() -> str:
    """Stop recording and return path to the final audio file."""
    state = _load_state()
    if not state:
        raise RecordingError(
            "No recording in progress. Start one with: task mom listen"
        )

    pid = state.get("pid", -1)
    segments = state.get("segments", [])

    # Stop the process if still running
    if pid > 0 and _is_process_running(pid):
        _stop_process(pid)

    _clear_state()

    # Filter to segments that actually have audio
    valid_segments = [
        s for s in segments
        if os.path.isfile(s) and os.path.getsize(s) > 0
    ]

    if not valid_segments:
        raise RecordingError(
            "No audio was captured. Check your microphone permissions:\n"
            "  System Settings → Privacy & Security → Microphone"
        )

    # Concatenate segments if multiple
    if len(valid_segments) == 1:
        return valid_segments[0]

    fd, output_path = tempfile.mkstemp(suffix=".wav", prefix="task-mom-merged-")
    os.close(fd)
    _concat_segments(valid_segments, output_path)

    # Clean up individual segments
    for seg in valid_segments:
        try:
            os.unlink(seg)
        except OSError:
            pass

    return output_path


def cleanup_audio(audio_file: str) -> None:
    """Delete an audio file after successful processing."""
    try:
        if os.path.isfile(audio_file):
            os.unlink(audio_file)
    except OSError:
        pass
