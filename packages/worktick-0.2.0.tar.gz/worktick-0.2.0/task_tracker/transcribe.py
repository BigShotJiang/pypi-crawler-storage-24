from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from typing import Optional

AUDIO_EXTENSIONS = {".wav", ".mp3", ".m4a", ".webm", ".ogg", ".flac"}

# Default model to use — medium handles non-native English accents well
DEFAULT_MODEL = "ggml-medium.bin"

# Common locations where whisper models might live
_MODEL_SEARCH_DIRS = [
    Path.home() / ".cache" / "whisper",
    Path.home() / ".local" / "share" / "whisper",
    Path.home() / "models",
    Path("/opt/homebrew/share/whisper-cpp"),
    Path("/usr/local/share/whisper-cpp"),
]


class TranscribeError(Exception):
    """Raised when audio transcription fails."""


def is_audio_file(path: str) -> bool:
    _, ext = os.path.splitext(path)
    return ext.lower() in AUDIO_EXTENSIONS


def _find_whisper_command() -> Optional[str]:
    """Find the whisper-cpp binary (whisper-cli from brew, or whisper-cpp)."""
    for cmd in ("whisper-cli", "whisper-cpp", "whisper"):
        try:
            subprocess.run(
                [cmd, "--help"], capture_output=True, timeout=5,
            )
            return cmd
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue
    return None


def _find_model(model_name: str = DEFAULT_MODEL) -> Optional[str]:
    """Search common directories for a whisper GGML model file."""
    for d in _MODEL_SEARCH_DIRS:
        candidate = d / model_name
        if candidate.is_file():
            return str(candidate)
    return None


def transcribe(audio_path: str) -> str:
    if not os.path.isfile(audio_path):
        raise TranscribeError(f"Audio file not found: {audio_path}")

    cmd = _find_whisper_command()
    if not cmd:
        raise TranscribeError(
            "whisper-cpp not found. Install it:\n"
            "  brew install whisper-cpp\n\n"
            "Then download a model:\n"
            "  mkdir -p ~/.cache/whisper\n"
            "  curl -L -o ~/.cache/whisper/ggml-medium.bin \\\n"
            "    https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-medium.bin"
        )

    model_path = _find_model()
    if not model_path:
        raise TranscribeError(
            "Whisper model not found. Download it:\n"
            "  mkdir -p ~/.cache/whisper\n"
            "  curl -L -o ~/.cache/whisper/ggml-medium.bin \\\n"
            "    https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-medium.bin\n\n"
            "Or specify a custom path with a smaller model:\n"
            "  curl -L -o ~/.cache/whisper/ggml-base.bin \\\n"
            "    https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin"
        )

    try:
        result = subprocess.run(
            [cmd, "-m", model_path, "-f", audio_path, "--no-timestamps"],
            capture_output=True, text=True, timeout=600,
        )
        if result.returncode != 0:
            stderr = result.stderr.strip()
            raise TranscribeError(f"whisper-cpp failed: {stderr}")
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        raise TranscribeError(
            "Transcription timed out (10 min). "
            "The audio file may be too long."
        )


def read_input(file_arg: str) -> tuple[str, str]:
    """Read input from stdin, audio file, or text file.

    Returns (content, source_label).
    """
    if file_arg == "-":
        content = sys.stdin.read().strip()
        if not content:
            raise TranscribeError("No input received from stdin.")
        return content, "stdin"

    if not os.path.exists(file_arg):
        raise TranscribeError(f"File not found: {file_arg}")

    if is_audio_file(file_arg):
        return transcribe(file_arg), os.path.basename(file_arg)

    with open(file_arg) as f:
        content = f.read().strip()
    if not content:
        raise TranscribeError(f"File is empty: {file_arg}")
    return content, os.path.basename(file_arg)
