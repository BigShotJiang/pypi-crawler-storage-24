from __future__ import annotations

import subprocess
from datetime import datetime, timedelta, timezone
from itertools import groupby

from task_tracker.models import TaskEntry, load_store
from task_tracker.core import format_duration


def _date_key(task: TaskEntry) -> str:
    return datetime.fromisoformat(task.started_at).strftime("%Y-%m-%d")


def _date_label(date_str: str) -> str:
    dt = datetime.strptime(date_str, "%Y-%m-%d")
    return dt.strftime("%Y-%m-%d (%A)")


def _date_label_short(date_str: str) -> str:
    dt = datetime.strptime(date_str, "%Y-%m-%d")
    return dt.strftime("%a, %d %b %Y")


def _task_block(task: TaskEntry) -> str:
    dur = format_duration(task.elapsed_seconds())
    title = f"**{task.title}** ({dur})"
    if task.card_url:
        title += f" [Trello]({task.card_url})"
    lines = [title]

    for c in task.commits:
        lines.append(f"- {c['message']} ({c['short_hash']})")
    for n in task.notes:
        lines.append(f"- {n}")

    return "\n".join(lines)


def _filter_tasks(period: str) -> list[TaskEntry]:
    store = load_store()
    now = datetime.now(timezone.utc).astimezone()
    today = now.date()

    if period == "today":
        start_date = today
    elif period == "yesterday":
        start_date = today - timedelta(days=1)
    elif period == "week":
        start_date = today - timedelta(days=today.weekday())
    else:
        raise ValueError(f"Unknown period: {period}. Use today, yesterday, or week.")

    return [
        t for t in store.tasks
        if datetime.fromisoformat(t.started_at).date() >= start_date
        and t.stopped_at
    ]


def _format_duration_hours(seconds: int) -> str:
    hours = seconds / 3600
    if hours >= 10:
        return f"{hours:.1f}H"
    return f"{hours:.2f}H".lstrip("0") or "0H"


def _build_task_data_for_prompt(tasks: list[TaskEntry]) -> str:
    lines = []
    for i, t in enumerate(tasks, 1):
        parts = [f"{i}. Title: {t.title}"]
        if t.commits:
            msgs = [c["message"] for c in t.commits]
            parts.append(f"   Commits: {'; '.join(msgs)}")
        if t.notes:
            parts.append(f"   Notes: {'; '.join(t.notes)}")
        lines.append("\n".join(parts))
    return "\n".join(lines)


def generate_summary(period: str = "today") -> str:
    tasks = _filter_tasks(period)

    if not tasks:
        return f"No completed tasks for '{period}'."

    tasks.sort(key=lambda t: t.started_at)

    sections = []
    for date_str, group in groupby(tasks, key=_date_key):
        group_list = list(group)
        total_secs = sum(t.duration_seconds for t in group_list)
        section_lines = [f"## {_date_label(date_str)}", ""]
        for t in group_list:
            section_lines.append(_task_block(t))
            section_lines.append("")
        section_lines.append(f"**Total: {format_duration(total_secs)}**")
        sections.append("\n".join(section_lines))

    return "\n\n".join(sections)


def generate_daily(period: str = "today", model: str = "gemma3") -> str:
    tasks = _filter_tasks(period)

    if not tasks:
        return f"No completed tasks for '{period}'."

    tasks.sort(key=lambda t: t.started_at)

    # Try to clean up titles with Ollama
    cleaned_titles = _ollama_clean_titles(tasks, model)

    sections = []
    for date_str, group in groupby(tasks, key=_date_key):
        group_list = list(group)
        total_secs = sum(t.duration_seconds for t in group_list)
        header = f"{_date_label_short(date_str)} - {_format_duration_hours(total_secs)}"
        lines = [header, ""]
        for t in group_list:
            dur = _format_duration_hours(t.duration_seconds)
            title = cleaned_titles.get(t.id, t.title)
            lines.append(f"{dur} - {title}")
        sections.append("\n".join(lines))

    return "\n\n".join(sections)


def _ollama_clean_titles(tasks: list[TaskEntry], model: str) -> dict[str, str]:
    """Use Ollama to produce clean one-liner titles. Returns {task_id: title}."""
    from task_tracker import ollama

    if not ollama.check_ollama_available():
        return {}

    task_data = _build_task_data_for_prompt(tasks)
    prompt = (
        "You are a concise task summarizer. Below are tasks with their titles, "
        "git commits, and notes. Produce exactly one clean one-liner per task.\n\n"
        "Rules:\n"
        "- Use active past tense (\"Fixed\", \"Refactored\", \"Added\")\n"
        "- Remove filler words and redundancy\n"
        "- Don't reorder, add, merge, or remove tasks\n"
        "- Output ONLY the numbered list, nothing else\n\n"
        f"Tasks:\n{task_data}\n\n"
        "Output (one line per task, numbered):"
    )

    try:
        result = ollama.generate(prompt, model=model)
    except ollama.OllamaError:
        return {}

    # Parse numbered lines
    cleaned = {}
    result_lines = [l.strip() for l in result.strip().splitlines() if l.strip()]
    # Strip numbering prefixes like "1. " or "1) "
    parsed = []
    for line in result_lines:
        for sep in (". ", ") ", ": "):
            idx = line.find(sep)
            if idx != -1 and line[:idx].strip().isdigit():
                parsed.append(line[idx + len(sep):].strip())
                break
        else:
            parsed.append(line.strip())

    # Validate: must match task count
    if len(parsed) != len(tasks):
        return {}

    for task, title in zip(tasks, parsed):
        if title:
            cleaned[task.id] = title

    return cleaned


def generate_mom_from_transcript(transcript: str, source: str = "unknown", model: str = "gemma3") -> str:
    """Generate meeting minutes from an already-obtained transcript."""
    from task_tracker import ollama

    prompt = (
        "You are a meeting minutes generator. Below is a meeting transcript. "
        "Generate structured meeting minutes.\n\n"
        "Format:\n"
        "## Meeting Minutes\n\n"
        "### Topics Discussed\n"
        "- Topic 1: brief summary\n\n"
        "### Key Decisions\n"
        "- Decision 1\n\n"
        "### Action Items\n"
        "- [ ] Action item (Owner)\n\n"
        "### Notes\n"
        "- Any additional context\n\n"
        "Rules:\n"
        "- Be concise and factual\n"
        "- Don't invent information not in the transcript\n"
        "- Handle garbled/unclear text gracefully (skip or mark as unclear)\n"
        "- Use bullet points, not paragraphs\n\n"
        f"Transcript (source: {source}):\n{transcript}"
    )

    return ollama.generate(prompt, model=model)


def copy_to_clipboard(text: str) -> bool:
    try:
        proc = subprocess.run(
            ["pbcopy"], input=text, text=True, timeout=5,
        )
        return proc.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False
