from __future__ import annotations

import enum
import os
import sys

import typer
from rich.console import Console
from rich.table import Table

from task_tracker.core import TaskTracker
from task_tracker.summary import generate_summary, generate_daily, generate_mom_from_transcript, copy_to_clipboard

app = typer.Typer(name="task", no_args_is_help=True)
mom_app = typer.Typer(name="mom", no_args_is_help=True, help="Meeting minutes commands")
app.add_typer(mom_app, name="mom")

console = Console()
err_console = Console(stderr=True)


class Period(str, enum.Enum):
    today = "today"
    yesterday = "yesterday"
    week = "week"


@app.command()
def start(
    title: str = typer.Argument(help="Task title"),
    card: str = typer.Option("", help="Trello/link URL"),
) -> None:
    """Start a new task."""
    tracker = TaskTracker()
    try:
        console.print(tracker.start(title, card), style="green")
    except RuntimeError as e:
        err_console.print(f"Error: {e}", style="bold red")
        raise typer.Exit(code=1)


@app.command()
def stop(
    at: str | None = typer.Option(None, help="Override stop time (HH:MM)"),
) -> None:
    """Stop the current task."""
    tracker = TaskTracker()
    try:
        console.print(tracker.stop(at), style="green")
    except RuntimeError as e:
        err_console.print(f"Error: {e}", style="bold red")
        raise typer.Exit(code=1)


@app.command()
def status() -> None:
    """Show current task and elapsed time."""
    tracker = TaskTracker()
    result = tracker.status()
    if "No task" in result:
        console.print(result, style="bright_black")
    elif "PAUSED" in result or "paused" in result.lower():
        console.print(result, style="yellow")
    else:
        console.print(result, style="green")


@app.command()
def pause() -> None:
    """Pause the current task timer."""
    tracker = TaskTracker()
    try:
        console.print(tracker.pause(), style="yellow")
    except RuntimeError as e:
        err_console.print(f"Error: {e}", style="bold red")
        raise typer.Exit(code=1)


@app.command()
def resume() -> None:
    """Resume the paused task timer."""
    tracker = TaskTracker()
    try:
        console.print(tracker.resume(), style="green")
    except RuntimeError as e:
        err_console.print(f"Error: {e}", style="bold red")
        raise typer.Exit(code=1)


@app.command()
def note(
    text: str = typer.Argument(help="Note text"),
) -> None:
    """Add a note to the current task."""
    tracker = TaskTracker()
    try:
        console.print(tracker.note(text), style="green")
    except RuntimeError as e:
        err_console.print(f"Error: {e}", style="bold red")
        raise typer.Exit(code=1)


@app.command("list")
def list_tasks(
    days: int = typer.Option(7, help="Number of days"),
) -> None:
    """List recent tasks."""
    tracker = TaskTracker()
    print(tracker.list_tasks(days))


@app.command()
def summary(
    period: Period = typer.Argument(Period.today, help="Time period"),
) -> None:
    """Generate markdown summary."""
    md = generate_summary(period.value)
    print(md)
    if copy_to_clipboard(md):
        print("\n(Copied to clipboard)")


@app.command()
def daily(
    period: Period = typer.Argument(Period.today, help="Time period"),
    model: str = typer.Option("gemma3", help="Ollama model"),
    no_copy: bool = typer.Option(False, help="Don't copy to clipboard"),
) -> None:
    """Compact daily summary with hours."""
    md = generate_daily(period.value, model=model)
    print(md)
    if not no_copy and copy_to_clipboard(md):
        print("\n(Copied to clipboard)")


@app.command()
def repo(
    path: str = typer.Argument(".", help="Repo path or parent dir"),
) -> None:
    """Register git repo(s) for the current task."""
    tracker = TaskTracker()
    try:
        console.print(tracker.repo_add(path), style="green")
    except RuntimeError as e:
        err_console.print(f"Error: {e}", style="bold red")
        raise typer.Exit(code=1)


@app.command()
def cancel() -> None:
    """Discard the current task."""
    tracker = TaskTracker()
    try:
        console.print(tracker.cancel(), style="green")
    except RuntimeError as e:
        err_console.print(f"Error: {e}", style="bold red")
        raise typer.Exit(code=1)


@app.command()
def edit(
    task_id: str = typer.Argument(help="Task ID (or prefix)"),
    title: str | None = typer.Option(None, help="New title"),
    card: str | None = typer.Option(None, help="New card URL"),
) -> None:
    """Edit a past task."""
    tracker = TaskTracker()
    try:
        console.print(tracker.edit(task_id, title=title, card_url=card), style="green")
    except RuntimeError as e:
        err_console.print(f"Error: {e}", style="bold red")
        raise typer.Exit(code=1)


# --- mom subcommands ---


@mom_app.command()
def listen() -> None:
    """Start recording from mic."""
    from task_tracker.recorder import RecordingError, start_recording

    try:
        console.print(start_recording(), style="green")
    except RecordingError as e:
        err_console.print(f"Recording error: {e}", style="bold red")
        raise typer.Exit(code=1)


@mom_app.command("pause")
def mom_pause() -> None:
    """Pause recording."""
    from task_tracker.recorder import RecordingError, pause_recording

    try:
        console.print(pause_recording(), style="yellow")
    except RecordingError as e:
        err_console.print(f"Recording error: {e}", style="bold red")
        raise typer.Exit(code=1)


@mom_app.command("resume")
def mom_resume() -> None:
    """Resume recording."""
    from task_tracker.recorder import RecordingError, resume_recording

    try:
        console.print(resume_recording(), style="green")
    except RecordingError as e:
        err_console.print(f"Recording error: {e}", style="bold red")
        raise typer.Exit(code=1)


@mom_app.command("stop")
def mom_stop(
    model: str = typer.Option("gemma3", help="Ollama model"),
    no_copy: bool = typer.Option(False, help="Don't copy to clipboard"),
) -> None:
    """Stop recording, transcribe, and generate minutes."""
    from task_tracker.meetings import MeetingEntry
    from task_tracker.recorder import RecordingError, stop_recording

    try:
        console.print("Stopping recording...", style="bright_black")
        audio_file = stop_recording()
    except RecordingError as e:
        err_console.print(f"Recording error: {e}", style="bold red")
        raise typer.Exit(code=1)

    size_mb = os.path.getsize(audio_file) / (1024 * 1024)
    console.print(f"Recorded: {audio_file} ({size_mb:.1f} MB)", style="bright_black")

    meeting = MeetingEntry.new(
        source="recording",
        source_file=audio_file,
        audio_file=audio_file,
    )
    meeting.model = model
    _process_meeting(meeting, audio_file, model, no_copy)


@mom_app.command("file")
def mom_file(
    path: str = typer.Argument(help="File path or '-' for stdin"),
    model: str = typer.Option("gemma3", help="Ollama model"),
    no_copy: bool = typer.Option(False, help="Don't copy to clipboard"),
) -> None:
    """Generate minutes from a file or stdin."""
    from task_tracker.meetings import MeetingEntry
    from task_tracker.transcribe import is_audio_file

    source_file = "" if path == "-" else path
    audio_file = source_file if source_file and is_audio_file(source_file) else ""
    meeting = MeetingEntry.new(
        source="stdin" if path == "-" else "file",
        source_file=source_file,
        audio_file=audio_file,
    )
    meeting.model = model
    _process_meeting(meeting, path, model, no_copy)


@mom_app.command("list")
def mom_list() -> None:
    """List all saved meetings."""
    from task_tracker.meetings import load_meetings

    store = load_meetings()
    if not store.meetings:
        console.print("No meeting minutes saved yet.", style="bright_black")
        return

    table = Table(title="Meetings")
    table.add_column("Status", width=3)
    table.add_column("ID", style="cyan")
    table.add_column("Time")
    table.add_column("Source")
    table.add_column("Result")
    table.add_column("Note", style="bright_black")

    for m in reversed(store.meetings):
        if m.status == "completed":
            status_marker = "[green]+[/green]"
            result_style = "green"
        else:
            status_marker = "[red]x[/red]"
            result_style = "red"

        audio_note = ""
        if m.status == "failed":
            if m.audio_file:
                audio_note = "audio: exists" if m.audio_exists() else "audio: gone"
            elif m.transcript:
                audio_note = "transcript saved"

        table.add_row(
            status_marker,
            m.id,
            m.short_time(),
            m.source,
            f"[{result_style}]{m.status}[/{result_style}]",
            audio_note,
        )

    console.print(table)
    console.print()
    console.print("  task mom show <id>   -- view minutes", style="bright_black")
    console.print("  task mom retry <id>  -- retry failed meeting", style="bright_black")


@mom_app.command()
def show(
    meeting_id: str = typer.Argument(help="Meeting ID (or prefix)"),
) -> None:
    """View meeting minutes."""
    from task_tracker.meetings import load_meetings

    store = load_meetings()
    meeting = store.find(meeting_id)
    if not meeting:
        err_console.print(f"Meeting not found: {meeting_id}", style="bold red")
        raise typer.Exit(code=1)

    console.print(f"Meeting {meeting.id} ({meeting.short_time()}) -- {meeting.status}")
    console.print(f"  Source: {meeting.source}")
    if meeting.source_file:
        console.print(f"  File:   {meeting.source_file}")
    if meeting.audio_file:
        exists = "exists" if meeting.audio_exists() else "not found"
        console.print(f"  Audio:  {meeting.audio_file} ({exists})")
    console.print()

    if meeting.minutes:
        print(meeting.minutes)
    elif meeting.transcript:
        console.print("No minutes generated. Transcript:", style="yellow")
        print(meeting.transcript)
    elif meeting.error:
        err_console.print(f"Error: {meeting.error}", style="bold red")
    else:
        console.print("No content available.", style="bright_black")


@mom_app.command()
def retry(
    meeting_id: str = typer.Argument(help="Meeting ID (or prefix)"),
    model: str = typer.Option("gemma3", help="Ollama model"),
    no_copy: bool = typer.Option(False, help="Don't copy to clipboard"),
) -> None:
    """Retry a failed meeting."""
    from task_tracker.meetings import load_meetings, save_meetings
    from task_tracker.ollama import OllamaError
    from task_tracker.transcribe import TranscribeError, read_input

    store = load_meetings()
    meeting = store.find(meeting_id)
    if not meeting:
        err_console.print(f"Meeting not found: {meeting_id}", style="bold red")
        raise typer.Exit(code=1)

    if meeting.status == "completed":
        console.print(
            f"Meeting {meeting.id} already completed. Use 'task mom show {meeting.id}' to view.",
            style="bright_black",
        )
        return

    meeting.model = model
    meeting.error = ""

    # Step 1: Get transcript (from saved or re-transcribe)
    if meeting.transcript:
        console.print("Using saved transcript...", style="bright_black")
        transcript = meeting.transcript
        source_label = meeting.source
    elif meeting.audio_file and meeting.audio_exists():
        try:
            console.print("Re-transcribing audio...", style="bright_black")
            transcript, source_label = read_input(meeting.audio_file)
            meeting.transcript = transcript
        except TranscribeError as e:
            meeting.error = str(e)
            save_meetings(store)
            err_console.print(f"Transcription error: {e}", style="bold red")
            raise typer.Exit(code=1)
    else:
        err_console.print(
            f"No transcript or audio file available for meeting {meeting.id}.",
            style="bold red",
        )
        if meeting.audio_file:
            err_console.print(
                f"Audio file was at: {meeting.audio_file} (no longer exists)",
                style="bright_black",
            )
        raise typer.Exit(code=1)

    # Step 2: Generate minutes
    try:
        minutes = generate_mom_from_transcript(transcript, source_label, model=model)
        meeting.minutes = minutes
        meeting.status = "completed"
    except OllamaError as e:
        meeting.error = str(e)
        save_meetings(store)
        err_console.print(f"Ollama error: {e}", style="bold red")
        raise typer.Exit(code=1)

    save_meetings(store)

    # Cleanup audio on success
    if meeting.audio_file and meeting.audio_exists():
        from task_tracker.recorder import cleanup_audio
        cleanup_audio(meeting.audio_file)

    print(minutes)
    if not no_copy and copy_to_clipboard(minutes):
        print("\n(Copied to clipboard)")
    console.print(f"\nMeeting {meeting.id} completed.", style="green")


def _process_meeting(meeting, file_arg: str, model: str, no_copy: bool) -> None:
    """Transcribe input, generate minutes, save meeting, handle errors."""
    from task_tracker.meetings import load_meetings, save_meetings
    from task_tracker.ollama import OllamaError
    from task_tracker.recorder import cleanup_audio
    from task_tracker.transcribe import TranscribeError, read_input

    store = load_meetings()

    # Step 1: Transcribe
    try:
        console.print(
            "Transcribing..." if meeting.audio_file else "Reading input...",
            style="bright_black",
        )
        transcript, source_label = read_input(file_arg)
        meeting.transcript = transcript
    except TranscribeError as e:
        meeting.status = "failed"
        meeting.error = str(e)
        store.meetings.append(meeting)
        save_meetings(store)
        err_console.print(f"Transcription error: {e}", style="bold red")
        if meeting.audio_file:
            err_console.print(f"\nAudio saved at: {meeting.audio_file}", style="bright_black")
            err_console.print(f"Retry with: task mom retry {meeting.id}", style="bright_black")
        raise typer.Exit(code=1)

    # Step 2: Generate minutes
    try:
        minutes = generate_mom_from_transcript(transcript, source_label, model=model)
        meeting.minutes = minutes
        meeting.status = "completed"
    except OllamaError as e:
        meeting.status = "failed"
        meeting.error = str(e)
        store.meetings.append(meeting)
        save_meetings(store)
        err_console.print(f"Ollama error: {e}", style="bold red")
        err_console.print(
            f"\nTranscript saved. Retry with: task mom retry {meeting.id}",
            style="bright_black",
        )
        raise typer.Exit(code=1)

    # Success — save meeting, cleanup audio, output
    store.meetings.append(meeting)
    save_meetings(store)

    if meeting.audio_file:
        cleanup_audio(meeting.audio_file)

    print(minutes)
    if not no_copy and copy_to_clipboard(minutes):
        print("\n(Copied to clipboard)")
    console.print(
        f"\nSaved as meeting {meeting.id}. View later with: task mom show {meeting.id}",
        style="green",
    )


def main() -> None:
    app()
