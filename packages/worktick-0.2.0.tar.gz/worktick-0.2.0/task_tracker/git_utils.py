from __future__ import annotations

import os
import subprocess
from typing import Optional

from task_tracker.models import Commit


def get_git_author() -> Optional[str]:
    try:
        result = subprocess.run(
            ["git", "config", "user.email"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return None


def get_git_root(path: str) -> Optional[str]:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, timeout=5,
            cwd=path,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return None


def is_valid_git_repo(path: str) -> bool:
    """Check if a path exists and is inside a git working tree."""
    if not os.path.isdir(path):
        return False
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            capture_output=True, text=True, timeout=5,
            cwd=path,
        )
        return result.returncode == 0 and result.stdout.strip() == "true"
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def scan_commits(
    repo_path: str,
    after: str,
    before: str,
    author: Optional[str] = None,
) -> list[dict]:
    """Scan git commits in a repo between two ISO timestamps."""
    cmd = [
        "git", "log",
        f"--after={after}",
        f"--before={before}",
        "--format=%H%x00%h%x00%s%x00%aI",
    ]
    if author:
        cmd.append(f"--author={author}")
    cmd.append("--all")

    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=10,
            cwd=repo_path,
        )
        if result.returncode != 0 or not result.stdout.strip():
            return []
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return []

    commits = []
    repo_name = os.path.basename(repo_path)
    for line in result.stdout.strip().split("\n"):
        parts = line.split("\x00")
        if len(parts) != 4:
            continue
        full_hash, short_hash, message, timestamp = parts
        commits.append(Commit(
            hash=full_hash,
            short_hash=short_hash,
            message=message,
            repo=repo_name,
            timestamp=timestamp,
        ).model_dump())
    return commits
