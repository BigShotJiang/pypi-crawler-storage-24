# CLAUDE.md

## Project Overview

`task-tracker` is a local CLI tool (`task` command) for tracking work time, capturing git commits, and generating markdown summaries. Optional local AI tools (Ollama, whisper.cpp, sox) for meeting minutes and daily summaries.

## Tech Stack

- **Python 3.10+**
- **uv** for project management (`uv sync`, `uv run task ...`)
- **hatchling** as build backend
- **typer** for CLI, **rich** for terminal output
- **pydantic** for data models, **httpx** for HTTP client
- **JSON files** for persistence (`~/.task-tracker/tasks.json`, `meetings.json`, `recording.json`)
- **Optional**: Ollama (LLM), whisper-cli (transcription), sox (preferred) or ffmpeg (fallback) for recording
- See [docs/tools.md](docs/tools.md) for detailed tool rationale

## File Structure

```
task_tracker/
  __init__.py       # version string only
  __main__.py       # `python -m task_tracker` support
  cli.py            # typer CLI — all commands wired here
  core.py           # TaskTracker — business logic (start/stop/note/status/list/cancel/edit/repo)
  models.py         # TaskEntry, TaskStore (pydantic), JSON load/save with atomic writes
  git_utils.py      # git commit scanning via subprocess, repo validation
  summary.py        # markdown summary, daily summary, meeting minutes generation
  ollama.py         # Ollama HTTP client via httpx
  transcribe.py     # whisper-cli wrapper — audio transcription, model discovery, stdin/file input
  recorder.py       # live mic recording — pause/resume, multi-segment, max duration, auto-cleanup
  meetings.py       # MeetingEntry, MeetingStore (pydantic) — persistent meeting minutes with retry support
```

## Architecture

- **models.py** — foundation: `TaskEntry`, `TaskStore` (pydantic models), `load_store()`/`save_store()` with atomic writes
- **core.py** — `TaskTracker` wraps the store and implements all task operations
- **cli.py** — thin typer layer with rich output; delegates to `core.py`, `summary.py`, `recorder.py`, `meetings.py`
- **git_utils.py** — used by `core.py` on `task stop` to scan commits; provides `is_valid_git_repo()`
- **ollama.py** — thin httpx client for Ollama `/api/generate`; used by `summary.py`
- **transcribe.py** — wraps `whisper-cli` (from `brew install whisper-cpp`); searches `~/.cache/whisper/` for GGML models
- **recorder.py** — manages mic recording via `rec` (sox, preferred) or `ffmpeg` (fallback); state in `recording.json`
- **meetings.py** — `MeetingEntry` + `MeetingStore` (pydantic models); stores transcript, minutes, audio path, status; prefix matching on IDs

## Data Model

**Tasks** (`tasks.json`): `current` field (task ID or null) + `tasks` array. Each task: id, title, card_url, started_at, stopped_at, duration_seconds, git_repos, commits, notes, tags.

**Meetings** (`meetings.json`): `meetings` array. Each meeting: id, timestamp, source, source_file, audio_file, status (completed/failed), transcript, minutes, model, error. Both success and failure are persisted.

**Recording** (`recording.json`): PID, segment paths, paused flag, recorder command. Auto-cleaned on stop.

All writes are atomic: temp file + `os.replace()`.

## Key Patterns

- **No background process** — timestamps only, duration calculated from start/stop
- **`--at HH:MM`** on stop for retroactive time correction
- **Git scanning** — null-byte delimiters in `git log` format for safe parsing
- **Prefix matching** — works on task IDs (`task edit`), meeting IDs (`task mom show/retry`)
- **`task start` refuses** if a task is already running
- **Multi-repo tracking** — `_register_cwd_repo()` auto-detects git root from cwd; `task repo` for explicit registration
- **Lazy imports** — `ollama`, `transcribe`, `recorder`, `meetings` imported inside functions
- **Graceful degradation** — `task daily` works without Ollama; `task mom` gives clear setup errors
- **Multi-segment recording** — pause/resume creates separate WAV files, merged on stop
- **Safe recording** — 4hr max duration, auto-cleanup on success, audio preserved on failure
- **Meeting persistence** — all meetings saved; `list/show/retry` for browsing and recovery

## Commands

```
task start "title" [--card URL]     # start timer, detect git repo
task stop [--at HH:MM]              # stop timer, scan git commits
task status                          # show running task + elapsed
task pause                           # pause task timer
task resume                          # resume paused task timer
task note "text"                     # append note, auto-register cwd repo
task repo [path]                     # register git repo(s)
task list [--days N]                 # list recent tasks
task summary [today|yesterday|week]  # markdown output + clipboard
task daily [today|yesterday|week]    # compact hours summary (Ollama optional)
task mom listen                      # start recording from mic
task mom pause                       # pause recording
task mom resume                      # resume recording
task mom stop [--model M]            # stop → merge → transcribe → minutes
task mom file <path> [--model M]    # minutes from file/stdin
task mom list                        # list saved meetings
task mom show <id>                   # view meeting minutes
task mom retry <id> [--model M]      # retry failed meeting
task cancel                          # discard current task
task edit ID [--title T] [--card U]  # modify a past task
```

## Install & Development

```bash
# Global install (recommended)
uv tool install .

# After code changes
uv tool install . --force --reinstall

# Dev mode
uv sync
uv run task --help
```

## Future Plans (Not Yet Built)

- **n8n webhook** — auto-push summaries to Trello/Slack
- **Trello API** — move cards, add comments directly from CLI
