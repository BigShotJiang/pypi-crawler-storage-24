# Tools & Architecture

How `task mom` and `task daily` work under the hood, and why each external tool was chosen.

## The Pipeline

```
Microphone → sox/ffmpeg → .wav file → whisper-cli → text transcript → Ollama → meeting minutes
```

For text input (`task mom notes.txt` or `pbpaste | task mom -`), the pipeline skips straight to Ollama — no sox or whisper needed.

## sox — Mic Recording (preferred)

**What it does:** Records audio from your microphone to a WAV file.

**Why we need it:** Python stdlib has no microphone access. We need an external binary to capture audio.

**Why sox is preferred over ffmpeg:**

| | sox (`rec` command) | ffmpeg (fallback) |
|---|---|---|
| **Install** | `brew install sox` | `brew install ffmpeg` |
| **Size** | ~5 MB | ~80 MB |
| **Audio quality** | Better — purpose-built for audio processing, uses high-quality resampling | Good — general purpose, optimized for speed over quality |
| **Recording command** | `rec output.wav rate 16k channels 1` | `ffmpeg -f avfoundation -i :default -ac 1 -ar 16000 output.wav` |
| **Focus** | Audio only — recording, conversion, effects | Everything — video, streaming, encoding |
| **Segment merging** | `sox seg1.wav seg2.wav out.wav` — lossless concat | Filter chain concat — works but heavier |

Sox was designed specifically for audio processing. Its resampling algorithms (used when converting to 16kHz mono for whisper) produce cleaner output with less aliasing artifacts compared to ffmpeg's default resampler. For speech transcription, cleaner audio = better accuracy.

**The code tries sox first, falls back to ffmpeg** if sox isn't installed. Both produce valid 16kHz mono WAV that whisper-cli accepts.

```bash
# Recommended
brew install sox

# Or if you already have ffmpeg, that works too — no need to install both
```

## whisper.cpp (`whisper-cli`) — Speech-to-Text

**What it does:** Converts audio files to text. Takes a `.wav` and outputs a transcript.

**Why we need it:** Python stdlib can't do speech recognition.

**Why whisper.cpp:**
- **Standalone C++ binary** — no Python packages, just called via `subprocess`
- **Apple Silicon optimized** — uses Metal GPU acceleration on M-series chips
- **Accent-friendly** — the medium model was trained on 680,000 hours of diverse multilingual audio, handles Indian, Romanian, and other non-native English accents well
- **Long-form audio** — designed for full meetings, not just short voice commands
- **Model choice** — pick your accuracy/speed tradeoff:

| Model | Size | Speed | Best for |
|-------|------|-------|----------|
| `ggml-tiny.bin` | ~75 MB | fastest | quick notes, clear audio |
| `ggml-base.bin` | ~150 MB | fast | good audio, native speakers |
| `ggml-small.bin` | ~500 MB | moderate | mixed quality audio |
| `ggml-medium.bin` | ~1.5 GB | slower | accented speech, noisy rooms (recommended) |
| `ggml-large-v3.bin` | ~3 GB | slowest | maximum accuracy |

We default to **medium** — the sweet spot for meeting transcription on M4 16GB.

**Why not these alternatives:**
- **Apple Speech API** — requires Swift/ObjC bridge (`pyobjc`), designed for short dictation not hour-long meetings, worse with accents
- **OpenAI Whisper (Python)** — requires pip packages (`torch`, `openai-whisper`), breaks our stdlib-only constraint
- **Cloud APIs (Google STT, AWS Transcribe)** — needs API keys, costs money, breaks the "no cloud" principle

## Ollama — Local LLM

**What it does:** Runs large language models locally. We send prompts via HTTP to `localhost:11434` and get structured text back.

**What we use it for:**
- **`task mom`** — raw transcript → structured meeting minutes (topics, decisions, action items, owners)
- **`task daily`** — messy task titles + git commits → clean one-liner summaries in past tense

**Why Ollama:**
- **Simple HTTP API** — just `urllib.request` (stdlib), POST JSON to `/api/generate`, parse JSON response. No SDK needed.
- **Model management** — `ollama pull gemma3` handles download, quantization, GPU memory
- **gemma3** — Google's 4B parameter model, ~5GB, fits in 16GB RAM, fast on Apple Silicon
- **Zero config** — `brew install ollama && ollama serve && ollama pull gemma3`, done

**Why not cloud LLM APIs (OpenAI, Claude, etc.):**
- Requires API keys and internet
- Costs money per request
- Meeting transcripts can contain sensitive/private information — keeping everything local is a feature

**Timeout handling:** We set a 5-minute timeout on Ollama requests. If a model is too large for your system and takes longer, you'll get a clear error suggesting a smaller model:
```
task mom --model gemma3:1b transcript.txt
```

## How Recording State Works

When you run `task mom listen`, the recorder:

1. Finds `rec` (sox) or `ffmpeg`
2. Starts a background process (`subprocess.Popen` with `start_new_session=True`)
3. Saves state to `~/.task-tracker/recording.json`:
   ```json
   {
     "pid": 12345,
     "segments": ["/tmp/task-mom-abc.wav"],
     "started_at": "2026-03-09T10:00:00+05:30",
     "recorder": "rec",
     "paused": false
   }
   ```
4. The process records independently — survives terminal close, app switching, etc.

**Pause/resume** works by:
- `task mom pause` → sends SIGINT to stop the process cleanly (finalizes WAV header), marks `paused: true`
- `task mom resume` → starts a new recording process, adds new segment to the list
- `task mom stop` → stops process, merges all segments with `sox` or `ffmpeg`, feeds merged file to whisper

**Safety:**
- Max 4 hours recording (sox: `trim 0 14400`, ffmpeg: `-t 14400`)
- Audio auto-deleted after successful processing
- On failure, audio and transcript saved to `meetings.json` for `task mom retry`

## How Meeting Storage Works

Every `task mom` invocation (success or failure) is saved to `~/.task-tracker/meetings.json`:

```json
{
  "meetings": [
    {
      "id": "abc123def456",
      "timestamp": "2026-03-09T10:00:00+05:30",
      "source": "recording",
      "source_file": "/tmp/task-mom-abc.wav",
      "audio_file": "/tmp/task-mom-abc.wav",
      "status": "completed",
      "transcript": "We discussed the API redesign...",
      "minutes": "## Meeting Minutes\n...",
      "model": "gemma3",
      "error": ""
    }
  ]
}
```

**On failure**, the entry is saved with `status: "failed"` and the error message. The transcript (if transcription succeeded) and audio path are preserved so `task mom retry <id>` can pick up where it left off without re-transcribing.
