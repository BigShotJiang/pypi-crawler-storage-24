# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class VerifyOrderResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'str',
        'ret_status': 'str'
    }

    attribute_map = {
        'id': 'id',
        'ret_status': 'ret_status'
    }

    def __init__(self, id=None, ret_status=None):
        r"""VerifyOrderResponse

        The model defined in huaweicloud sdk

        :param id: 标识
        :type id: str
        :param ret_status: 状态，successful/error
        :type ret_status: str
        """
        
        super().__init__()

        self._id = None
        self._ret_status = None
        self.discriminator = None

        if id is not None:
            self.id = id
        if ret_status is not None:
            self.ret_status = ret_status

    @property
    def id(self):
        r"""Gets the id of this VerifyOrderResponse.

        标识

        :return: The id of this VerifyOrderResponse.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this VerifyOrderResponse.

        标识

        :param id: The id of this VerifyOrderResponse.
        :type id: str
        """
        self._id = id

    @property
    def ret_status(self):
        r"""Gets the ret_status of this VerifyOrderResponse.

        状态，successful/error

        :return: The ret_status of this VerifyOrderResponse.
        :rtype: str
        """
        return self._ret_status

    @ret_status.setter
    def ret_status(self, ret_status):
        r"""Sets the ret_status of this VerifyOrderResponse.

        状态，successful/error

        :param ret_status: The ret_status of this VerifyOrderResponse.
        :type ret_status: str
        """
        self._ret_status = ret_status

    def to_dict(self):
        import warnings
        warnings.warn("VerifyOrderResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, VerifyOrderResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
