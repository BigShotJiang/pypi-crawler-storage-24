# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowOrderInformationRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'model_code': 'str'
    }

    attribute_map = {
        'model_code': 'model_code'
    }

    def __init__(self, model_code=None):
        r"""ShowOrderInformationRequest

        The model defined in huaweicloud sdk

        :param model_code: 服务单类型编码
        :type model_code: str
        """
        
        

        self._model_code = None
        self.discriminator = None

        self.model_code = model_code

    @property
    def model_code(self):
        r"""Gets the model_code of this ShowOrderInformationRequest.

        服务单类型编码

        :return: The model_code of this ShowOrderInformationRequest.
        :rtype: str
        """
        return self._model_code

    @model_code.setter
    def model_code(self, model_code):
        r"""Sets the model_code of this ShowOrderInformationRequest.

        服务单类型编码

        :param model_code: The model_code of this ShowOrderInformationRequest.
        :type model_code: str
        """
        self._model_code = model_code

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowOrderInformationRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
