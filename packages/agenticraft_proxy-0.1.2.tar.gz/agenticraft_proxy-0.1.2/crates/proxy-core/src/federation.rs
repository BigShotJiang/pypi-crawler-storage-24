// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Identity Federation (F20).
//!
//! Cross-organization DID-based trust and agent discovery.

use std::collections::HashSet;
use std::net::IpAddr;

use dashmap::DashMap;

/// Trust level for a federated organization.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub enum TrustLevel {
    /// Trust all DIDs from this organization.
    Full,
    /// Verify each DID individually.
    Verified,
    /// Only pre-registered DIDs allowed.
    Restricted,
}

/// A trusted federated organization.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct TrustedOrganization {
    pub org_did: String,
    pub name: String,
    pub trust_level: TrustLevel,
    /// Well-known endpoint for agent discovery.
    pub discovery_endpoint: Option<String>,
    /// Pre-registered agent DIDs (for Restricted trust).
    pub allowed_agents: HashSet<String>,
    /// Capabilities this org is allowed to access.
    pub allowed_capabilities: HashSet<String>,
    pub added_at: u64,
}

/// A federation agreement between organizations.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct FederationAgreement {
    pub id: String,
    pub local_org_did: String,
    pub remote_org_did: String,
    pub trust_level: TrustLevel,
    pub created_at: u64,
    pub expires_at: Option<u64>,
    pub capabilities_shared: HashSet<String>,
}

/// A discovered remote agent.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct RemoteAgent {
    pub agent_did: String,
    pub org_did: String,
    pub name: String,
    pub capabilities: HashSet<String>,
    pub endpoint: String,
    pub discovered_at: u64,
}

/// Result of a federation verification check.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FederationVerifyResult {
    /// Agent is from a trusted org and verified.
    Trusted { org_name: String },
    /// Agent's org is known but this specific DID needs verification.
    NeedsVerification { org_did: String },
    /// Agent's org is not in the federation.
    Unknown,
    /// Agent is explicitly denied.
    Denied { reason: String },
}

/// Federation statistics snapshot.
pub struct FederationStats {
    pub trusted_orgs: usize,
    pub agreements: usize,
    pub remote_agents: usize,
}

// ---------------------------------------------------------------------------
// SSRF endpoint validation
// ---------------------------------------------------------------------------

/// Validate that a federation endpoint is safe (not pointing to internal networks).
///
/// Rejects:
/// - Non-HTTPS schemes (http://, file://, ftp://, gopher://, etc.)
/// - Loopback addresses (127.0.0.0/8, ::1, localhost)
/// - Private RFC 1918 ranges (10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16)
/// - Link-local (169.254.0.0/16) including AWS metadata (169.254.169.254)
/// - Unspecified address (0.0.0.0, ::)
///
/// # Limitations
///
/// This validates the URL string only — it does **not** resolve DNS. A hostname
/// like `evil.com` pointing to `127.0.0.1` will pass validation. For full SSRF
/// protection, callers should also validate the resolved IP at connection time
/// (e.g., via a custom DNS resolver or connect callback). See security-audit-report.md.
pub fn validate_endpoint(url: &str) -> Result<(), String> {
    // Reject non-URL inputs
    let parsed = url::Url::parse(url).map_err(|e| format!("invalid URL: {e}"))?;

    // Scheme check: only HTTPS
    if parsed.scheme() != "https" {
        return Err(format!(
            "scheme '{}' not allowed — only HTTPS is permitted",
            parsed.scheme()
        ));
    }

    // Extract host
    let host = parsed
        .host_str()
        .ok_or_else(|| "URL has no host".to_string())?;

    // Reject localhost
    if host == "localhost" {
        return Err("localhost is not allowed".to_string());
    }

    // Try parsing as IP address
    if let Ok(ip) = host.parse::<IpAddr>() {
        if is_private_ip(&ip) {
            return Err(format!("private/reserved IP address {ip} is not allowed"));
        }
    }

    // Also handle bracketed IPv6 (e.g., [::1])
    let trimmed = host.trim_start_matches('[').trim_end_matches(']');
    if let Ok(ip) = trimmed.parse::<IpAddr>() {
        if is_private_ip(&ip) {
            return Err(format!("private/reserved IP address {ip} is not allowed"));
        }
    }

    Ok(())
}

/// Check if an IP address is private, loopback, link-local, or otherwise reserved.
///
/// Covers: 127.0.0.0/8, 0.0.0.0, 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16,
/// 169.254.0.0/16, ::1, ::, and IPv4-mapped IPv6 (::ffff:x.x.x.x).
pub fn is_private_ip(ip: &IpAddr) -> bool {
    match ip {
        IpAddr::V4(v4) => {
            let octets = v4.octets();
            v4.is_loopback()                              // 127.0.0.0/8
                || v4.is_unspecified()                     // 0.0.0.0
                || octets[0] == 10                         // 10.0.0.0/8
                || (octets[0] == 172 && (16..=31).contains(&octets[1])) // 172.16.0.0/12
                || (octets[0] == 192 && octets[1] == 168)  // 192.168.0.0/16
                || (octets[0] == 169 && octets[1] == 254) // 169.254.0.0/16 (link-local + AWS metadata)
        }
        IpAddr::V6(v6) => {
            v6.is_loopback()       // ::1
                || v6.is_unspecified() // ::
                // IPv4-mapped IPv6 (::ffff:x.x.x.x) — extract the inner v4 and check it
                || v6.to_ipv4_mapped().is_some_and(|v4| is_private_ip(&IpAddr::V4(v4)))
        }
    }
}

/// Federation manager for cross-org identity.
pub struct FederationManager {
    trusted_orgs: DashMap<String, TrustedOrganization>,
    agreements: DashMap<String, FederationAgreement>,
    /// Index: remote_org_did → list of agreement IDs for O(1) lookup.
    agreements_by_org: DashMap<String, Vec<String>>,
    remote_agents: DashMap<String, RemoteAgent>,
}

impl Default for FederationManager {
    fn default() -> Self {
        Self::new()
    }
}

impl FederationManager {
    /// Create a new, empty federation manager.
    pub fn new() -> Self {
        Self {
            trusted_orgs: DashMap::new(),
            agreements: DashMap::new(),
            agreements_by_org: DashMap::new(),
            remote_agents: DashMap::new(),
        }
    }

    /// Register a trusted organization.
    pub fn add_trusted_org(&self, org: TrustedOrganization) {
        self.trusted_orgs.insert(org.org_did.clone(), org);
    }

    /// Register a trusted organization with SSRF-safe endpoint validation.
    /// Returns an error if the discovery endpoint points to a private network.
    pub fn add_trusted_org_validated(&self, org: TrustedOrganization) -> Result<(), String> {
        if let Some(ref endpoint) = org.discovery_endpoint {
            validate_endpoint(endpoint)?;
        }
        self.add_trusted_org(org);
        Ok(())
    }

    /// Remove a trusted organization by DID. Returns `true` if it existed.
    pub fn remove_trusted_org(&self, org_did: &str) -> bool {
        self.trusted_orgs.remove(org_did).is_some()
    }

    /// Create (or replace) a federation agreement.
    pub fn create_agreement(&self, agreement: FederationAgreement) {
        self.agreements_by_org
            .entry(agreement.remote_org_did.clone())
            .or_default()
            .push(agreement.id.clone());
        self.agreements.insert(agreement.id.clone(), agreement);
    }

    /// Verify an agent DID against federation rules.
    pub fn verify_agent(&self, agent_did: &str, org_did: &str) -> FederationVerifyResult {
        // Check if org is trusted
        let org = match self.trusted_orgs.get(org_did) {
            Some(org) => org,
            None => return FederationVerifyResult::Unknown,
        };

        // Check agreement expiry if there is one
        if let Some(agreement) = self.find_agreement(org_did) {
            if let Some(expires) = agreement.expires_at {
                let now = std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .unwrap_or_default()
                    .as_secs();
                if now > expires {
                    return FederationVerifyResult::Denied {
                        reason: "federation agreement expired".to_string(),
                    };
                }
            }
        }

        match org.trust_level {
            TrustLevel::Full => FederationVerifyResult::Trusted {
                org_name: org.name.clone(),
            },
            TrustLevel::Verified => FederationVerifyResult::NeedsVerification {
                org_did: org_did.to_string(),
            },
            TrustLevel::Restricted => {
                if org.allowed_agents.contains(agent_did) {
                    FederationVerifyResult::Trusted {
                        org_name: org.name.clone(),
                    }
                } else {
                    FederationVerifyResult::Denied {
                        reason: format!(
                            "agent {} not in allowed list for org {}",
                            agent_did, org.name
                        ),
                    }
                }
            }
        }
    }

    /// Register a discovered remote agent.
    pub fn register_remote_agent(&self, agent: RemoteAgent) {
        self.remote_agents.insert(agent.agent_did.clone(), agent);
    }

    /// Register a discovered remote agent with SSRF-safe endpoint validation.
    /// Returns an error if the agent endpoint points to a private network.
    pub fn register_remote_agent_validated(&self, agent: RemoteAgent) -> Result<(), String> {
        validate_endpoint(&agent.endpoint)?;
        self.register_remote_agent(agent);
        Ok(())
    }

    /// Find remote agents that advertise a given capability.
    pub fn find_agents_by_capability(&self, capability: &str) -> Vec<RemoteAgent> {
        self.remote_agents
            .iter()
            .filter(|entry| entry.capabilities.contains(capability))
            .map(|entry| entry.value().clone())
            .collect()
    }

    /// Get all trusted organizations.
    pub fn list_trusted_orgs(&self) -> Vec<TrustedOrganization> {
        self.trusted_orgs
            .iter()
            .map(|entry| entry.value().clone())
            .collect()
    }

    /// Get all federation agreements.
    pub fn list_agreements(&self) -> Vec<FederationAgreement> {
        self.agreements
            .iter()
            .map(|entry| entry.value().clone())
            .collect()
    }

    /// Get all remote agents.
    pub fn list_remote_agents(&self) -> Vec<RemoteAgent> {
        self.remote_agents
            .iter()
            .map(|entry| entry.value().clone())
            .collect()
    }

    /// Check if a capability is shared in a federation agreement with a given org.
    pub fn is_capability_shared(&self, org_did: &str, capability: &str) -> bool {
        let Some(ids) = self.agreements_by_org.get(org_did) else {
            return false;
        };
        for id in ids.value() {
            if let Some(agreement) = self.agreements.get(id) {
                if agreement.capabilities_shared.contains(capability) {
                    return true;
                }
            }
        }
        false
    }

    /// Get federation statistics.
    pub fn stats(&self) -> FederationStats {
        FederationStats {
            trusted_orgs: self.trusted_orgs.len(),
            agreements: self.agreements.len(),
            remote_agents: self.remote_agents.len(),
        }
    }

    fn find_agreement(&self, remote_org_did: &str) -> Option<FederationAgreement> {
        let ids = self.agreements_by_org.get(remote_org_did)?;
        for id in ids.value() {
            if let Some(agreement) = self.agreements.get(id) {
                return Some(agreement.value().clone());
            }
        }
        None
    }
}

// ---------------------------------------------------------------------------
// Unit tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    fn now_secs() -> u64 {
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs()
    }

    fn make_org(org_did: &str, name: &str, trust_level: TrustLevel) -> TrustedOrganization {
        TrustedOrganization {
            org_did: org_did.to_string(),
            name: name.to_string(),
            trust_level,
            discovery_endpoint: None,
            allowed_agents: HashSet::new(),
            allowed_capabilities: HashSet::new(),
            added_at: now_secs(),
        }
    }

    fn make_agreement(
        id: &str,
        local: &str,
        remote: &str,
        capabilities: &[&str],
        expires_at: Option<u64>,
    ) -> FederationAgreement {
        FederationAgreement {
            id: id.to_string(),
            local_org_did: local.to_string(),
            remote_org_did: remote.to_string(),
            trust_level: TrustLevel::Full,
            created_at: now_secs(),
            expires_at,
            capabilities_shared: capabilities.iter().map(|s| s.to_string()).collect(),
        }
    }

    #[test]
    fn add_and_verify_full_trust() {
        let mgr = FederationManager::new();
        let org = make_org("did:web:acme.example", "Acme Corp", TrustLevel::Full);
        mgr.add_trusted_org(org);

        let result = mgr.verify_agent("did:key:agent1", "did:web:acme.example");
        assert_eq!(
            result,
            FederationVerifyResult::Trusted {
                org_name: "Acme Corp".to_string()
            }
        );
    }

    #[test]
    fn verify_restricted_allowed_agent() {
        let mgr = FederationManager::new();
        let mut org = make_org(
            "did:web:partner.example",
            "Partner Inc",
            TrustLevel::Restricted,
        );
        org.allowed_agents
            .insert("did:key:trusted-agent".to_string());
        mgr.add_trusted_org(org);

        let result = mgr.verify_agent("did:key:trusted-agent", "did:web:partner.example");
        assert_eq!(
            result,
            FederationVerifyResult::Trusted {
                org_name: "Partner Inc".to_string()
            }
        );
    }

    #[test]
    fn verify_restricted_denied_agent() {
        let mgr = FederationManager::new();
        let org = make_org(
            "did:web:partner.example",
            "Partner Inc",
            TrustLevel::Restricted,
        );
        mgr.add_trusted_org(org);

        let result = mgr.verify_agent("did:key:unknown-agent", "did:web:partner.example");
        match result {
            FederationVerifyResult::Denied { reason } => {
                assert!(reason.contains("not in allowed list"));
            }
            other => panic!("expected Denied, got {other:?}"),
        }
    }

    #[test]
    fn verify_unknown_org() {
        let mgr = FederationManager::new();

        let result = mgr.verify_agent("did:key:some-agent", "did:web:unknown.example");
        assert_eq!(result, FederationVerifyResult::Unknown);
    }

    #[test]
    fn expired_agreement_denied() {
        let mgr = FederationManager::new();
        let org = make_org("did:web:expired.example", "Expired Org", TrustLevel::Full);
        mgr.add_trusted_org(org);

        // Set expiry one second in the past
        let agreement = make_agreement(
            "agr-expired",
            "did:web:local.example",
            "did:web:expired.example",
            &["read"],
            Some(now_secs() - 1),
        );
        mgr.create_agreement(agreement);

        let result = mgr.verify_agent("did:key:agent1", "did:web:expired.example");
        match result {
            FederationVerifyResult::Denied { reason } => {
                assert!(reason.contains("expired"), "reason was: {reason}");
            }
            other => panic!("expected Denied for expired agreement, got {other:?}"),
        }
    }

    #[test]
    fn find_agents_by_capability() {
        let mgr = FederationManager::new();

        mgr.register_remote_agent(RemoteAgent {
            agent_did: "did:key:a1".to_string(),
            org_did: "did:web:org1.example".to_string(),
            name: "Agent One".to_string(),
            capabilities: ["summarize", "translate"]
                .iter()
                .map(|s| s.to_string())
                .collect(),
            endpoint: "https://org1.example/agent".to_string(),
            discovered_at: now_secs(),
        });

        mgr.register_remote_agent(RemoteAgent {
            agent_did: "did:key:a2".to_string(),
            org_did: "did:web:org2.example".to_string(),
            name: "Agent Two".to_string(),
            capabilities: ["summarize"].iter().map(|s| s.to_string()).collect(),
            endpoint: "https://org2.example/agent".to_string(),
            discovered_at: now_secs(),
        });

        mgr.register_remote_agent(RemoteAgent {
            agent_did: "did:key:a3".to_string(),
            org_did: "did:web:org3.example".to_string(),
            name: "Agent Three".to_string(),
            capabilities: ["code_gen"].iter().map(|s| s.to_string()).collect(),
            endpoint: "https://org3.example/agent".to_string(),
            discovered_at: now_secs(),
        });

        let summarizers = mgr.find_agents_by_capability("summarize");
        assert_eq!(summarizers.len(), 2);

        let translators = mgr.find_agents_by_capability("translate");
        assert_eq!(translators.len(), 1);
        assert_eq!(translators[0].agent_did, "did:key:a1");

        let no_match = mgr.find_agents_by_capability("does_not_exist");
        assert!(no_match.is_empty());
    }

    #[test]
    fn capability_sharing_check() {
        let mgr = FederationManager::new();
        let agreement = make_agreement(
            "agr-1",
            "did:web:local.example",
            "did:web:remote.example",
            &["read", "write"],
            None,
        );
        mgr.create_agreement(agreement);

        assert!(mgr.is_capability_shared("did:web:remote.example", "read"));
        assert!(mgr.is_capability_shared("did:web:remote.example", "write"));
        assert!(!mgr.is_capability_shared("did:web:remote.example", "admin"));
        assert!(!mgr.is_capability_shared("did:web:other.example", "read"));
    }

    #[test]
    fn federation_stats_accurate() {
        let mgr = FederationManager::new();

        let stats = mgr.stats();
        assert_eq!(stats.trusted_orgs, 0);
        assert_eq!(stats.agreements, 0);
        assert_eq!(stats.remote_agents, 0);

        mgr.add_trusted_org(make_org(
            "did:web:org1.example",
            "Org One",
            TrustLevel::Full,
        ));
        mgr.add_trusted_org(make_org(
            "did:web:org2.example",
            "Org Two",
            TrustLevel::Verified,
        ));
        mgr.create_agreement(make_agreement(
            "agr-1",
            "did:web:local.example",
            "did:web:org1.example",
            &[],
            None,
        ));
        mgr.register_remote_agent(RemoteAgent {
            agent_did: "did:key:r1".to_string(),
            org_did: "did:web:org1.example".to_string(),
            name: "Remote One".to_string(),
            capabilities: HashSet::new(),
            endpoint: "https://org1.example/agent".to_string(),
            discovered_at: now_secs(),
        });

        let stats = mgr.stats();
        assert_eq!(stats.trusted_orgs, 2);
        assert_eq!(stats.agreements, 1);
        assert_eq!(stats.remote_agents, 1);

        // remove_trusted_org returns true when it existed
        assert!(mgr.remove_trusted_org("did:web:org1.example"));
        // and false when it doesn't
        assert!(!mgr.remove_trusted_org("did:web:org1.example"));

        let stats = mgr.stats();
        assert_eq!(stats.trusted_orgs, 1);
    }
}
