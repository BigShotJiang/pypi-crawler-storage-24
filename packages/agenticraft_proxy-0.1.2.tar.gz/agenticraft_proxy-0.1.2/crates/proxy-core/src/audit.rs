// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! # Audit Hash Chain
//!
//! Tamper-evident audit log using SHA-256 hash chaining. Each entry includes
//! the hash of the previous entry, forming a verifiable chain.
//!
//! ## Design decisions
//!
//! 1. **Persistence is mandatory.** `[audit] enabled = true` requires an export
//!    backend (NATS, file, or both). In-memory head for verification; all
//!    entries durably exported.
//!
//! 2. **Lock contention:** `Mutex` serializes sequence + hash update
//!    (~50ns held). `crossbeam::ArrayQueue` ring buffer for recent entries.
//!
//! 3. **`verify()` is static:** Works on any `&[AuditEntry]` slice. Entries
//!    are self-contained (each has `prev_hash`).

use std::collections::VecDeque;
// AtomicU64 no longer needed — sequence is a plain u64 under the Mutex.
use std::time::{SystemTime, UNIX_EPOCH};

use parking_lot::Mutex;
use sha2::{Digest, Sha256};

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

/// Audit export backend.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
#[cfg_attr(feature = "serde", serde(rename_all = "snake_case"))]
pub enum AuditExport {
    Nats,
    File { path: String },
    Both { path: String },
}

/// Audit configuration.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct AuditConfig {
    pub enabled: bool,
    pub export: AuditExport,
    #[cfg_attr(feature = "serde", serde(default = "default_buffer_size"))]
    pub buffer_size: usize,
}

fn default_buffer_size() -> usize {
    1024
}

impl Default for AuditConfig {
    fn default() -> Self {
        Self {
            enabled: false,
            export: AuditExport::Nats,
            buffer_size: default_buffer_size(),
        }
    }
}

// ---------------------------------------------------------------------------
// Audit entry
// ---------------------------------------------------------------------------

/// Audit event types.
#[derive(Debug, Clone, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
#[cfg_attr(feature = "serde", serde(rename_all = "snake_case"))]
pub enum AuditEventType {
    RequestReceived,
    RequestRouted,
    ResponseSent,
    PolicyViolation,
    AuthFailure,
    ConfigChange,
}

/// A single audit entry with hash chain linkage.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct AuditEntry {
    /// Monotonically increasing sequence number.
    pub sequence: u64,
    /// SHA-256 hash of this entry (hex-encoded).
    pub hash: String,
    /// SHA-256 hash of the previous entry (hex-encoded). Empty for first entry.
    pub prev_hash: String,
    /// Unix timestamp in milliseconds.
    pub timestamp_ms: u64,
    /// Event type.
    pub event_type: AuditEventType,
    /// SHA-256 hash of the request/response payload (hex-encoded).
    pub payload_hash: String,
    /// Tenant ID (empty if not multi-tenant).
    pub tenant_id: String,
    /// Correlation ID for distributed tracing.
    pub correlation_id: String,
}

impl AuditEntry {
    /// Compute the hash of this entry (excluding the `hash` field itself).
    fn compute_hash(
        sequence: u64,
        prev_hash: &str,
        timestamp_ms: u64,
        event_type: &AuditEventType,
        payload_hash: &str,
        tenant_id: &str,
        correlation_id: &str,
    ) -> String {
        let mut hasher = Sha256::new();
        hasher.update(sequence.to_le_bytes());
        hasher.update(prev_hash.as_bytes());
        hasher.update(timestamp_ms.to_le_bytes());
        hasher.update(format!("{event_type:?}").as_bytes());
        hasher.update(payload_hash.as_bytes());
        hasher.update(tenant_id.as_bytes());
        hasher.update(correlation_id.as_bytes());
        hex::encode(hasher.finalize())
    }
}

// ---------------------------------------------------------------------------
// Audit chain
// ---------------------------------------------------------------------------

/// Tamper-evident audit hash chain.
pub struct AuditChain {
    /// Sequence counter lives inside `head_hash` lock — no need for atomic.
    /// The lock serializes sequence allocation + hash computation.
    sequence: Mutex<u64>,
    head_hash: Mutex<String>,
    recent_entries: Mutex<VecDeque<AuditEntry>>,
    buffer_capacity: usize,
    export_tx: tokio::sync::mpsc::Sender<AuditEntry>,
}

/// Handle for the background export task.
pub struct AuditExportHandle {
    pub handle: tokio::task::JoinHandle<()>,
}

impl AuditChain {
    /// Create a new audit chain with a background export channel.
    ///
    /// Returns `(chain, receiver)`. The caller should spawn a background task
    /// that reads from the receiver and exports entries.
    pub fn new(buffer_size: usize) -> (Self, tokio::sync::mpsc::Receiver<AuditEntry>) {
        let (tx, rx) = tokio::sync::mpsc::channel(buffer_size);
        let chain = Self {
            sequence: Mutex::new(0),
            head_hash: Mutex::new(String::new()),
            recent_entries: Mutex::new(VecDeque::with_capacity(buffer_size.max(1))),
            buffer_capacity: buffer_size.max(1),
            export_tx: tx,
        };
        (chain, rx)
    }

    /// Append an audit entry to the chain.
    pub fn append(
        &self,
        event_type: AuditEventType,
        payload_hash: String,
        tenant_id: String,
        correlation_id: String,
    ) -> AuditEntry {
        let timestamp_ms = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis() as u64;

        // Both sequence allocation and hash computation under the same lock
        // to guarantee chain ordering matches sequence ordering under
        // concurrent appends. The sequence counter is a plain u64 (not atomic)
        // because it is only ever accessed under this lock.
        let (sequence, hash, prev_hash) = {
            let mut seq = self.sequence.lock();
            let mut head = self.head_hash.lock();
            let current_seq = *seq;
            *seq += 1;
            let prev = head.clone();
            let hash = AuditEntry::compute_hash(
                current_seq,
                &prev,
                timestamp_ms,
                &event_type,
                &payload_hash,
                &tenant_id,
                &correlation_id,
            );
            *head = hash.clone();
            (current_seq, hash, prev)
        };

        let entry = AuditEntry {
            sequence,
            hash,
            prev_hash,
            timestamp_ms,
            event_type,
            payload_hash,
            tenant_id,
            correlation_id,
        };

        // Bounded recent-entries buffer — evict oldest when full
        {
            let mut recent = self.recent_entries.lock();
            if recent.len() >= self.buffer_capacity {
                recent.pop_front();
            }
            recent.push_back(entry.clone());
        }

        // Send to export channel (non-blocking — drops if full, which is logged)
        let _ = self.export_tx.try_send(entry.clone());

        entry
    }

    /// Get the most recent entries (non-destructive read).
    ///
    /// Returns up to `count` entries in chronological order.
    pub fn recent(&self, count: usize) -> Vec<AuditEntry> {
        let recent = self.recent_entries.lock();
        let len = recent.len();
        let skip = len.saturating_sub(count);
        recent.iter().skip(skip).cloned().collect()
    }

    /// Current sequence number.
    pub fn sequence(&self) -> u64 {
        *self.sequence.lock()
    }

    /// Verify that a chain of audit entries is valid (no tampering).
    ///
    /// Static method — works on any slice of entries.
    pub fn verify(entries: &[AuditEntry]) -> bool {
        if entries.is_empty() {
            return true;
        }

        for (i, entry) in entries.iter().enumerate() {
            // Verify hash
            let expected_hash = AuditEntry::compute_hash(
                entry.sequence,
                &entry.prev_hash,
                entry.timestamp_ms,
                &entry.event_type,
                &entry.payload_hash,
                &entry.tenant_id,
                &entry.correlation_id,
            );
            if entry.hash != expected_hash {
                return false;
            }

            // Verify chain linkage (except first entry)
            if i > 0 && entry.prev_hash != entries[i - 1].hash {
                return false;
            }
        }

        true
    }

    /// Hash a payload for inclusion in an audit entry.
    pub fn hash_payload(payload: &[u8]) -> String {
        let mut hasher = Sha256::new();
        hasher.update(payload);
        hex::encode(hasher.finalize())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn appends_entries() {
        let (chain, _rx) = AuditChain::new(16);
        let entry = chain.append(
            AuditEventType::RequestReceived,
            "payload_hash".to_string(),
            "tenant-1".to_string(),
            "corr-1".to_string(),
        );
        assert_eq!(entry.sequence, 0);
        assert!(!entry.hash.is_empty());
        assert!(entry.prev_hash.is_empty()); // First entry
    }

    #[tokio::test]
    async fn links_hashes() {
        let (chain, _rx) = AuditChain::new(16);
        let e1 = chain.append(
            AuditEventType::RequestReceived,
            "p1".to_string(),
            String::new(),
            "c1".to_string(),
        );
        let e2 = chain.append(
            AuditEventType::RequestRouted,
            "p2".to_string(),
            String::new(),
            "c1".to_string(),
        );
        assert_eq!(e2.prev_hash, e1.hash);
        assert_eq!(e2.sequence, 1);
    }

    #[tokio::test]
    async fn verify_valid_chain() {
        let (chain, _rx) = AuditChain::new(16);
        let e1 = chain.append(
            AuditEventType::RequestReceived,
            "p1".to_string(),
            String::new(),
            "c1".to_string(),
        );
        let e2 = chain.append(
            AuditEventType::RequestRouted,
            "p2".to_string(),
            String::new(),
            "c1".to_string(),
        );
        let e3 = chain.append(
            AuditEventType::ResponseSent,
            "p3".to_string(),
            String::new(),
            "c1".to_string(),
        );

        assert!(AuditChain::verify(&[e1, e2, e3]));
    }

    #[tokio::test]
    async fn detect_tamper() {
        let (chain, _rx) = AuditChain::new(16);
        let e1 = chain.append(
            AuditEventType::RequestReceived,
            "p1".to_string(),
            String::new(),
            "c1".to_string(),
        );
        let mut e2 = chain.append(
            AuditEventType::RequestRouted,
            "p2".to_string(),
            String::new(),
            "c1".to_string(),
        );

        // Tamper with the entry
        e2.payload_hash = "tampered".to_string();
        assert!(!AuditChain::verify(&[e1, e2]));
    }

    #[tokio::test]
    async fn concurrent_safe() {
        let (chain, _rx) = AuditChain::new(1024);
        let chain = std::sync::Arc::new(chain);

        let mut handles = vec![];
        for i in 0..10 {
            let c = chain.clone();
            handles.push(tokio::spawn(async move {
                for j in 0..10 {
                    c.append(
                        AuditEventType::RequestReceived,
                        format!("p-{i}-{j}"),
                        String::new(),
                        format!("c-{i}-{j}"),
                    );
                }
            }));
        }

        for h in handles {
            h.await.unwrap();
        }

        assert_eq!(chain.sequence(), 100);
    }

    #[tokio::test]
    async fn sequence_monotonic() {
        let (chain, _rx) = AuditChain::new(16);
        let mut prev_seq = 0u64;
        for i in 0..10 {
            let entry = chain.append(
                AuditEventType::RequestReceived,
                format!("p-{i}"),
                String::new(),
                "c1".to_string(),
            );
            if i > 0 {
                assert!(
                    entry.sequence > prev_seq,
                    "sequence not monotonic: {} <= {}",
                    entry.sequence,
                    prev_seq
                );
            }
            prev_seq = entry.sequence;
        }
    }

    #[tokio::test]
    async fn includes_correlation_id() {
        let (chain, _rx) = AuditChain::new(16);
        let entry = chain.append(
            AuditEventType::RequestReceived,
            "p1".to_string(),
            "tenant-1".to_string(),
            "trace-abc-123".to_string(),
        );
        assert_eq!(entry.correlation_id, "trace-abc-123");
        assert_eq!(entry.tenant_id, "tenant-1");
    }

    #[tokio::test]
    async fn export_channel_receives() {
        let (chain, mut rx) = AuditChain::new(16);
        chain.append(
            AuditEventType::RequestReceived,
            "p1".to_string(),
            String::new(),
            "c1".to_string(),
        );

        let received = rx.try_recv();
        assert!(received.is_ok());
        assert_eq!(received.unwrap().sequence, 0);
    }

    #[tokio::test]
    async fn verify_empty_chain() {
        assert!(AuditChain::verify(&[]));
    }

    #[test]
    fn hash_payload_deterministic() {
        let h1 = AuditChain::hash_payload(b"hello");
        let h2 = AuditChain::hash_payload(b"hello");
        assert_eq!(h1, h2);

        let h3 = AuditChain::hash_payload(b"world");
        assert_ne!(h1, h3);
    }
}
