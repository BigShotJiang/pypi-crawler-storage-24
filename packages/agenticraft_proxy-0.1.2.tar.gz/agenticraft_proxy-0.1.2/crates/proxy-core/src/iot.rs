// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! IoT Device Gateway (F25).
//!
//! MQTT-style device registry, telemetry buffering, and topic routing for
//! edge IoT devices connecting through the proxy.

use std::collections::HashMap;
use std::collections::VecDeque;
use std::sync::atomic::{AtomicU64, Ordering};

use dashmap::DashMap;
use parking_lot::RwLock;

// ---------------------------------------------------------------------------
// Error types
// ---------------------------------------------------------------------------

/// Errors returned by IoT gateway operations.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
pub enum IoTError {
    #[error("device not found: {0}")]
    DeviceNotFound(String),

    #[error("device already registered: {0}")]
    DeviceAlreadyRegistered(String),

    #[error("no route matched for topic: {0}")]
    NoRouteMatched(String),

    #[error("invalid device type: {0}")]
    InvalidDeviceType(String),
}

// ---------------------------------------------------------------------------
// Data types
// ---------------------------------------------------------------------------

/// Runtime status of an IoT device.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum DeviceStatus {
    Online,
    Offline,
    Error(String),
}

/// Registered device information.
///
/// Contains interior-mutable fields (RwLock, AtomicU64) so this type is
/// not serializable — status and last_seen are updated in-place.
pub struct DeviceInfo {
    pub device_id: String,
    pub device_type: String,
    pub status: RwLock<DeviceStatus>,
    /// Unix timestamp of last heartbeat or telemetry.
    pub last_seen: AtomicU64,
    pub metadata: RwLock<HashMap<String, String>>,
}

impl std::fmt::Debug for DeviceInfo {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("DeviceInfo")
            .field("device_id", &self.device_id)
            .field("device_type", &self.device_type)
            .field("status", &*self.status.read())
            .field("last_seen", &self.last_seen.load(Ordering::Relaxed))
            .finish()
    }
}

/// A single telemetry data point.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct TelemetryRecord {
    pub device_id: String,
    pub metric_name: String,
    pub value: f64,
    pub timestamp: u64,
    pub tags: Vec<(String, String)>,
}

/// An MQTT-style topic route.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct TopicRoute {
    /// Topic pattern, e.g. `"devices/+/telemetry"` or `"devices/#"`.
    pub pattern: String,
    /// Logical handler name for the matched route.
    pub handler_name: String,
    /// MQTT QoS level (0, 1, or 2).
    pub qos: u8,
}

/// IoT gateway statistics snapshot.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct IoTGatewayStats {
    pub registered_devices: usize,
    pub online_devices: usize,
    pub buffered_telemetry: usize,
    pub total_ingested: u64,
    pub routes_count: usize,
}

/// Telemetry buffer statistics snapshot.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct TelemetryStats {
    pub total_received: u64,
    pub total_dropped: u64,
    pub buffered_count: usize,
}

// ---------------------------------------------------------------------------
// DeviceRegistry
// ---------------------------------------------------------------------------

/// Manages device lifecycle: registration, heartbeats, status updates.
pub struct DeviceRegistry {
    devices: DashMap<String, DeviceInfo>,
}

impl Default for DeviceRegistry {
    fn default() -> Self {
        Self::new()
    }
}

impl DeviceRegistry {
    pub fn new() -> Self {
        Self {
            devices: DashMap::new(),
        }
    }

    /// Register a new device. Returns error if `device_id` is already registered.
    pub fn register_device(
        &self,
        device_id: &str,
        device_type: &str,
        metadata: HashMap<String, String>,
    ) -> Result<(), IoTError> {
        // Validate device type.
        match device_type {
            "sensor" | "actuator" | "gateway" => {}
            other => return Err(IoTError::InvalidDeviceType(other.to_string())),
        }

        let info = DeviceInfo {
            device_id: device_id.to_string(),
            device_type: device_type.to_string(),
            status: RwLock::new(DeviceStatus::Online),
            last_seen: AtomicU64::new(unix_now()),
            metadata: RwLock::new(metadata),
        };

        // DashMap::entry ensures atomic check-and-insert.
        use dashmap::mapref::entry::Entry;
        match self.devices.entry(device_id.to_string()) {
            Entry::Occupied(_) => Err(IoTError::DeviceAlreadyRegistered(device_id.to_string())),
            Entry::Vacant(v) => {
                v.insert(info);
                Ok(())
            }
        }
    }

    /// Unregister a device. Returns error if not found.
    pub fn unregister_device(&self, device_id: &str) -> Result<(), IoTError> {
        self.devices
            .remove(device_id)
            .map(|_| ())
            .ok_or_else(|| IoTError::DeviceNotFound(device_id.to_string()))
    }

    /// Update the status of a device. Returns error if not found.
    pub fn update_status(&self, device_id: &str, status: DeviceStatus) -> Result<(), IoTError> {
        let entry = self
            .devices
            .get(device_id)
            .ok_or_else(|| IoTError::DeviceNotFound(device_id.to_string()))?;
        *entry.status.write() = status;
        Ok(())
    }

    /// Update the `last_seen` timestamp to now.
    pub fn heartbeat(&self, device_id: &str) -> Result<(), IoTError> {
        let entry = self
            .devices
            .get(device_id)
            .ok_or_else(|| IoTError::DeviceNotFound(device_id.to_string()))?;
        entry.last_seen.store(unix_now(), Ordering::Relaxed);
        Ok(())
    }

    /// Get a snapshot of device info. Returns cloned status and metadata.
    pub fn get_device(&self, device_id: &str) -> Option<DeviceSnapshot> {
        let entry = self.devices.get(device_id)?;
        let snapshot = DeviceSnapshot::from_parts(
            entry.device_id.clone(),
            entry.device_type.clone(),
            entry.status.read().clone(),
            entry.last_seen.load(Ordering::Relaxed),
            entry.metadata.read().clone(),
        );
        Some(snapshot)
    }

    /// List all registered devices as snapshots.
    pub fn list_devices(&self) -> Vec<DeviceSnapshot> {
        self.devices
            .iter()
            .map(|entry| {
                DeviceSnapshot::from_parts(
                    entry.device_id.clone(),
                    entry.device_type.clone(),
                    entry.status.read().clone(),
                    entry.last_seen.load(Ordering::Relaxed),
                    entry.metadata.read().clone(),
                )
            })
            .collect()
    }

    /// Number of registered devices.
    pub fn len(&self) -> usize {
        self.devices.len()
    }

    /// Returns true if no devices are registered.
    pub fn is_empty(&self) -> bool {
        self.devices.is_empty()
    }

    /// Count devices currently online.
    pub fn online_count(&self) -> usize {
        self.devices
            .iter()
            .filter(|e| *e.status.read() == DeviceStatus::Online)
            .count()
    }

    /// Check whether a device is registered.
    pub fn contains(&self, device_id: &str) -> bool {
        self.devices.contains_key(device_id)
    }
}

/// Serializable snapshot of a [`DeviceInfo`].
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct DeviceSnapshot {
    pub device_id: String,
    pub device_type: String,
    pub status: String,
    pub last_seen: u64,
    pub metadata: HashMap<String, String>,
}

// Manual conversion for DeviceSnapshot::status — DeviceStatus is not serde-friendly
// because of the Error(String) variant's semantic collision with serde errors.
impl DeviceSnapshot {
    fn from_parts(
        device_id: String,
        device_type: String,
        status: DeviceStatus,
        last_seen: u64,
        metadata: HashMap<String, String>,
    ) -> Self {
        let status_str = match &status {
            DeviceStatus::Online => "online".to_string(),
            DeviceStatus::Offline => "offline".to_string(),
            DeviceStatus::Error(msg) => format!("error: {msg}"),
        };
        Self {
            device_id,
            device_type,
            status: status_str,
            last_seen,
            metadata,
        }
    }
}

// ---------------------------------------------------------------------------
// TelemetryBuffer
// ---------------------------------------------------------------------------

/// Bounded ring-buffer for telemetry records.
///
/// O(1) push with automatic eviction of the oldest record when capacity is
/// reached. Designed for upstream batch forwarding via [`drain_batch`].
pub struct TelemetryBuffer {
    buffer: RwLock<VecDeque<TelemetryRecord>>,
    capacity: usize,
    total_received: AtomicU64,
    total_dropped: AtomicU64,
}

impl TelemetryBuffer {
    pub fn new(capacity: usize) -> Self {
        Self {
            buffer: RwLock::new(VecDeque::with_capacity(capacity)),
            capacity,
            total_received: AtomicU64::new(0),
            total_dropped: AtomicU64::new(0),
        }
    }

    /// Push a record into the buffer. If at capacity, the oldest record is
    /// evicted (counted as dropped).
    pub fn push(&self, record: TelemetryRecord) {
        self.total_received.fetch_add(1, Ordering::Relaxed);
        let mut buf = self.buffer.write();
        if buf.len() >= self.capacity {
            buf.pop_front();
            self.total_dropped.fetch_add(1, Ordering::Relaxed);
        }
        buf.push_back(record);
    }

    /// Drain up to `limit` records from the front of the buffer for upstream
    /// forwarding. Returns fewer than `limit` if the buffer has less.
    pub fn drain_batch(&self, limit: usize) -> Vec<TelemetryRecord> {
        let mut buf = self.buffer.write();
        let n = limit.min(buf.len());
        buf.drain(..n).collect()
    }

    /// Current buffer statistics.
    pub fn stats(&self) -> TelemetryStats {
        TelemetryStats {
            total_received: self.total_received.load(Ordering::Relaxed),
            total_dropped: self.total_dropped.load(Ordering::Relaxed),
            buffered_count: self.buffer.read().len(),
        }
    }

    /// Number of records currently buffered.
    pub fn len(&self) -> usize {
        self.buffer.read().len()
    }

    /// Returns true if no records are buffered.
    pub fn is_empty(&self) -> bool {
        self.buffer.read().is_empty()
    }
}

// ---------------------------------------------------------------------------
// TopicRouter
// ---------------------------------------------------------------------------

/// Routes MQTT-style topic strings to handlers using wildcard matching.
///
/// Supports `+` (single-level wildcard) and `#` (multi-level wildcard).
/// Routes are evaluated in order; the first match wins.
pub struct TopicRouter {
    routes: Vec<TopicRoute>,
}

impl TopicRouter {
    /// Build a router from a list of routes. Order matters — first match wins.
    pub fn new(routes: Vec<TopicRoute>) -> Self {
        Self { routes }
    }

    /// Match a concrete topic string against registered route patterns.
    ///
    /// Wildcard rules (simplified MQTT):
    /// - `+` matches exactly one topic level (e.g. `devices/+/telemetry`
    ///   matches `devices/temp-01/telemetry` but not `devices/a/b/telemetry`).
    /// - `#` matches zero or more remaining levels. Must be the last segment
    ///   (e.g. `devices/#` matches `devices/a`, `devices/a/b`, and `devices`).
    pub fn match_topic(&self, topic: &str) -> Option<&TopicRoute> {
        self.routes
            .iter()
            .find(|route| topic_matches(&route.pattern, topic))
    }

    /// Number of registered routes.
    pub fn len(&self) -> usize {
        self.routes.len()
    }

    /// Returns true if no routes are registered.
    pub fn is_empty(&self) -> bool {
        self.routes.is_empty()
    }
}

/// Check whether a pattern matches a topic.
fn topic_matches(pattern: &str, topic: &str) -> bool {
    let pattern_parts: Vec<&str> = pattern.split('/').collect();
    let topic_parts: Vec<&str> = topic.split('/').collect();

    let mut pi = 0; // pattern index
    let mut ti = 0; // topic index

    while pi < pattern_parts.len() && ti < topic_parts.len() {
        match pattern_parts[pi] {
            "#" => {
                // Multi-level wildcard — matches the rest.
                return true;
            }
            "+" => {
                // Single-level wildcard — matches exactly one level.
                pi += 1;
                ti += 1;
            }
            literal => {
                if literal != topic_parts[ti] {
                    return false;
                }
                pi += 1;
                ti += 1;
            }
        }
    }

    // Both must be fully consumed (unless pattern ended with #, handled above).
    pi == pattern_parts.len() && ti == topic_parts.len()
}

// ---------------------------------------------------------------------------
// IoTGateway
// ---------------------------------------------------------------------------

/// Top-level IoT gateway coordinator.
///
/// Combines device registry, telemetry buffering, and topic routing into a
/// single facade used by the proxy data plane.
pub struct IoTGateway {
    pub registry: DeviceRegistry,
    pub telemetry: TelemetryBuffer,
    pub router: TopicRouter,
    total_ingested: AtomicU64,
}

impl IoTGateway {
    pub fn new(telemetry_capacity: usize, routes: Vec<TopicRoute>) -> Self {
        Self {
            registry: DeviceRegistry::new(),
            telemetry: TelemetryBuffer::new(telemetry_capacity),
            router: TopicRouter::new(routes),
            total_ingested: AtomicU64::new(0),
        }
    }

    /// Ingest a telemetry data point from a device.
    ///
    /// 1. Validate that `device_id` is registered.
    /// 2. Route the `topic` to a handler.
    /// 3. Buffer the telemetry record.
    /// 4. Update the device heartbeat.
    pub fn ingest(
        &self,
        device_id: &str,
        topic: &str,
        payload_value: f64,
        metric_name: &str,
    ) -> Result<String, IoTError> {
        // 1. Device must exist.
        if !self.registry.contains(device_id) {
            return Err(IoTError::DeviceNotFound(device_id.to_string()));
        }

        // 2. Route topic.
        let route = self
            .router
            .match_topic(topic)
            .ok_or_else(|| IoTError::NoRouteMatched(topic.to_string()))?;
        let handler = route.handler_name.clone();

        // 3. Buffer telemetry.
        let record = TelemetryRecord {
            device_id: device_id.to_string(),
            metric_name: metric_name.to_string(),
            value: payload_value,
            timestamp: unix_now(),
            tags: vec![("topic".to_string(), topic.to_string())],
        };
        self.telemetry.push(record);
        self.total_ingested.fetch_add(1, Ordering::Relaxed);

        // 4. Heartbeat.
        let _ = self.registry.heartbeat(device_id);

        Ok(handler)
    }

    /// Gateway-level statistics snapshot.
    pub fn stats(&self) -> IoTGatewayStats {
        IoTGatewayStats {
            registered_devices: self.registry.len(),
            online_devices: self.registry.online_count(),
            buffered_telemetry: self.telemetry.len(),
            total_ingested: self.total_ingested.load(Ordering::Relaxed),
            routes_count: self.router.len(),
        }
    }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/// Current unix timestamp in seconds.
fn unix_now() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

// ---------------------------------------------------------------------------
// Unit tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    // -- DeviceRegistry ---------------------------------------------------

    #[test]
    fn register_device_and_heartbeat() {
        let registry = DeviceRegistry::new();
        registry
            .register_device("sensor-01", "sensor", HashMap::new())
            .unwrap();
        assert_eq!(registry.len(), 1);

        let snap = registry.get_device("sensor-01").unwrap();
        assert_eq!(snap.device_type, "sensor");
        let first_seen = snap.last_seen;

        // Heartbeat updates last_seen.
        std::thread::sleep(std::time::Duration::from_millis(10));
        registry.heartbeat("sensor-01").unwrap();
        let snap2 = registry.get_device("sensor-01").unwrap();
        assert!(snap2.last_seen >= first_seen);
    }

    #[test]
    fn duplicate_registration_rejected() {
        let registry = DeviceRegistry::new();
        registry
            .register_device("gw-01", "gateway", HashMap::new())
            .unwrap();
        let err = registry
            .register_device("gw-01", "gateway", HashMap::new())
            .unwrap_err();
        assert_eq!(err, IoTError::DeviceAlreadyRegistered("gw-01".to_string()));
    }

    // -- TelemetryBuffer --------------------------------------------------

    #[test]
    fn buffer_capacity_eviction() {
        let buf = TelemetryBuffer::new(3);
        for i in 0..5 {
            buf.push(TelemetryRecord {
                device_id: "d1".into(),
                metric_name: format!("m{i}"),
                value: i as f64,
                timestamp: i as u64,
                tags: vec![],
            });
        }
        // Capacity is 3, so only the last 3 should remain.
        assert_eq!(buf.len(), 3);
        let stats = buf.stats();
        assert_eq!(stats.total_received, 5);
        assert_eq!(stats.total_dropped, 2);
        assert_eq!(stats.buffered_count, 3);

        // Drain should return records m2, m3, m4 (oldest first).
        let batch = buf.drain_batch(10);
        assert_eq!(batch.len(), 3);
        assert_eq!(batch[0].metric_name, "m2");
        assert_eq!(batch[1].metric_name, "m3");
        assert_eq!(batch[2].metric_name, "m4");
        assert!(buf.is_empty());
    }

    // -- TopicRouter ------------------------------------------------------

    #[test]
    fn topic_routing_with_wildcards() {
        let router = TopicRouter::new(vec![
            TopicRoute {
                pattern: "devices/+/telemetry".into(),
                handler_name: "telemetry_handler".into(),
                qos: 1,
            },
            TopicRoute {
                pattern: "devices/+/control".into(),
                handler_name: "control_handler".into(),
                qos: 2,
            },
            TopicRoute {
                pattern: "system/#".into(),
                handler_name: "system_handler".into(),
                qos: 0,
            },
        ]);

        // Single-level wildcard match.
        let m1 = router.match_topic("devices/temp-01/telemetry").unwrap();
        assert_eq!(m1.handler_name, "telemetry_handler");
        assert_eq!(m1.qos, 1);

        // Single-level wildcard, different device.
        let m2 = router.match_topic("devices/pump-02/control").unwrap();
        assert_eq!(m2.handler_name, "control_handler");

        // Multi-level wildcard.
        let m3 = router.match_topic("system/status/heartbeat").unwrap();
        assert_eq!(m3.handler_name, "system_handler");

        // Multi-level wildcard, single level.
        let m4 = router.match_topic("system/alerts").unwrap();
        assert_eq!(m4.handler_name, "system_handler");

        // No match.
        assert!(router.match_topic("unknown/topic").is_none());

        // Too many levels for single-level wildcard.
        assert!(router.match_topic("devices/a/b/telemetry").is_none());
    }

    // -- IoTGateway -------------------------------------------------------

    #[test]
    fn ingest_flow_register_ingest_check_buffer() {
        let gw = IoTGateway::new(
            100,
            vec![TopicRoute {
                pattern: "devices/+/telemetry".into(),
                handler_name: "telem".into(),
                qos: 1,
            }],
        );
        gw.registry
            .register_device("s1", "sensor", HashMap::new())
            .unwrap();

        let handler = gw
            .ingest("s1", "devices/s1/telemetry", 23.5, "temperature")
            .unwrap();
        assert_eq!(handler, "telem");

        // Telemetry should be buffered.
        assert_eq!(gw.telemetry.len(), 1);
        let batch = gw.telemetry.drain_batch(10);
        assert_eq!(batch.len(), 1);
        assert_eq!(batch[0].device_id, "s1");
        assert_eq!(batch[0].metric_name, "temperature");
        assert!((batch[0].value - 23.5).abs() < f64::EPSILON);
    }

    #[test]
    fn ingest_unregistered_device_rejected() {
        let gw = IoTGateway::new(
            100,
            vec![TopicRoute {
                pattern: "devices/+/telemetry".into(),
                handler_name: "telem".into(),
                qos: 1,
            }],
        );

        let err = gw
            .ingest(
                "unknown-device",
                "devices/unknown-device/telemetry",
                1.0,
                "temp",
            )
            .unwrap_err();
        assert_eq!(err, IoTError::DeviceNotFound("unknown-device".to_string()));
        // Nothing should have been buffered.
        assert!(gw.telemetry.is_empty());
    }

    #[test]
    fn stats_accuracy() {
        let gw = IoTGateway::new(
            50,
            vec![
                TopicRoute {
                    pattern: "devices/+/telemetry".into(),
                    handler_name: "telem".into(),
                    qos: 1,
                },
                TopicRoute {
                    pattern: "system/#".into(),
                    handler_name: "sys".into(),
                    qos: 0,
                },
            ],
        );

        // Register two devices: one online, one set to offline.
        gw.registry
            .register_device("d1", "sensor", HashMap::new())
            .unwrap();
        gw.registry
            .register_device("d2", "actuator", HashMap::new())
            .unwrap();
        gw.registry
            .update_status("d2", DeviceStatus::Offline)
            .unwrap();

        // Ingest three records from d1.
        for i in 0..3 {
            gw.ingest("d1", "devices/d1/telemetry", i as f64, "metric")
                .unwrap();
        }

        let stats = gw.stats();
        assert_eq!(stats.registered_devices, 2);
        assert_eq!(stats.online_devices, 1);
        assert_eq!(stats.buffered_telemetry, 3);
        assert_eq!(stats.total_ingested, 3);
        assert_eq!(stats.routes_count, 2);
    }
}
