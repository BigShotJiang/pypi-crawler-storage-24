// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! OpenAPI 3.x → MCP tool auto-conversion (F4).
//!
//! Parses a simplified OpenAPI 3.x specification into MCP tool definitions,
//! and routes `tools/call` invocations back to the original HTTP operations.
//!
//! Each OpenAPI operation becomes one MCP tool:
//! - Tool name: `{prefix}_{operationId}` or `{prefix}_{method}_{path_slug}`
//! - Parameters (path, query, header) become JSON Schema `properties`
//! - Request body schema is merged into `input_schema`
//!
//! Reverse routing via [`McpCallRouter`] maps tool calls back to
//! [`HttpCallSpec`] with path parameters substituted, query params extracted,
//! headers assembled, and request body separated.

use std::collections::HashMap;

// ---------------------------------------------------------------------------
// OpenAPI types (simplified, inline — no external crate dependency)
// ---------------------------------------------------------------------------

/// HTTP method.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[cfg_attr(feature = "serde", serde(rename_all = "UPPERCASE"))]
pub enum HttpMethod {
    Get,
    Post,
    Put,
    Patch,
    Delete,
    Head,
    Options,
}

impl HttpMethod {
    /// Lowercase string representation.
    pub fn as_str(&self) -> &'static str {
        match self {
            HttpMethod::Get => "get",
            HttpMethod::Post => "post",
            HttpMethod::Put => "put",
            HttpMethod::Patch => "patch",
            HttpMethod::Delete => "delete",
            HttpMethod::Head => "head",
            HttpMethod::Options => "options",
        }
    }
}

impl std::fmt::Display for HttpMethod {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.as_str())
    }
}

/// Where a parameter is located in the HTTP request.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[cfg_attr(feature = "serde", serde(rename_all = "lowercase"))]
pub enum ParameterLocation {
    Path,
    Query,
    Header,
}

/// Simplified JSON Schema representation (subset sufficient for MCP).
///
/// Uses `serde_json::Value` for the actual schema content so we stay
/// dependency-free beyond `serde_json` (already in Cargo.toml).
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct JsonSchema {
    /// The raw JSON Schema object.
    #[cfg_attr(feature = "serde", serde(flatten))]
    pub value: serde_json::Value,
}

impl JsonSchema {
    /// Create a string schema.
    pub fn string() -> Self {
        Self {
            value: serde_json::json!({"type": "string"}),
        }
    }

    /// Create an integer schema.
    pub fn integer() -> Self {
        Self {
            value: serde_json::json!({"type": "integer"}),
        }
    }

    /// Create a boolean schema.
    pub fn boolean() -> Self {
        Self {
            value: serde_json::json!({"type": "boolean"}),
        }
    }

    /// Create a number schema.
    pub fn number() -> Self {
        Self {
            value: serde_json::json!({"type": "number"}),
        }
    }

    /// Create a schema from a raw `serde_json::Value`.
    pub fn from_value(value: serde_json::Value) -> Self {
        Self { value }
    }
}

/// An OpenAPI parameter (path, query, or header).
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct Parameter {
    /// Parameter name.
    pub name: String,
    /// Where the parameter appears.
    pub location: ParameterLocation,
    /// Human-readable description.
    pub description: Option<String>,
    /// Whether the parameter is required.
    pub required: bool,
    /// JSON Schema for the parameter value.
    pub schema: JsonSchema,
}

/// An OpenAPI request body.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct RequestBody {
    /// Human-readable description.
    pub description: Option<String>,
    /// Whether the body is required.
    pub required: bool,
    /// JSON Schema for the body content (assumes `application/json`).
    pub schema: JsonSchema,
}

/// A single OpenAPI operation (one method on one path).
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct Operation {
    /// The HTTP method.
    pub method: HttpMethod,
    /// The path template (e.g., `/users/{user_id}/posts`).
    pub path: String,
    /// Optional `operationId` from the spec.
    pub operation_id: Option<String>,
    /// Human-readable summary.
    pub summary: Option<String>,
    /// Human-readable description.
    pub description: Option<String>,
    /// Parameters (path, query, header).
    pub parameters: Vec<Parameter>,
    /// Optional request body.
    pub request_body: Option<RequestBody>,
}

/// A simplified OpenAPI 3.x specification.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct OpenApiSpec {
    /// API title.
    pub title: String,
    /// API version.
    pub version: String,
    /// Optional base URL (server URL).
    pub base_url: Option<String>,
    /// All operations extracted from the spec.
    pub operations: Vec<Operation>,
}

// ---------------------------------------------------------------------------
// MCP tool definition
// ---------------------------------------------------------------------------

/// An MCP tool definition produced from an OpenAPI operation.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct McpToolDef {
    /// Tool name: `{prefix}_{operationId}` or `{prefix}_{method}_{path_slug}`.
    pub name: String,
    /// Human-readable description (from summary or description).
    pub description: String,
    /// JSON Schema for the tool's input (object with properties).
    pub input_schema: serde_json::Value,
}

// ---------------------------------------------------------------------------
// HTTP call spec (reverse routing)
// ---------------------------------------------------------------------------

/// Resolved HTTP call spec for executing a routed MCP tool invocation.
#[derive(Debug, Clone, PartialEq)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct HttpCallSpec {
    /// HTTP method (uppercase string, e.g., "GET").
    pub method: String,
    /// Path with path parameters substituted (e.g., `/users/42/posts`).
    pub path: String,
    /// Query parameters extracted from arguments.
    pub query_params: Vec<(String, String)>,
    /// Header parameters extracted from arguments.
    pub headers: Vec<(String, String)>,
    /// JSON body (if the operation had a request body).
    pub body: Option<serde_json::Value>,
}

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------

/// Errors from OpenAPI → MCP conversion.
#[derive(Debug, thiserror::Error)]
pub enum ConversionError {
    #[error("empty specification: no operations found")]
    EmptySpec,

    #[error("duplicate tool name: `{0}`")]
    DuplicateToolName(String),

    #[error("invalid path template: `{0}`")]
    InvalidPath(String),
}

// ---------------------------------------------------------------------------
// Converter
// ---------------------------------------------------------------------------

/// Converts an [`OpenApiSpec`] into a list of [`McpToolDef`]s.
pub struct OpenApiToMcpConverter {
    /// Prefix prepended to every tool name (e.g., `"petstore"`).
    prefix: String,
}

impl OpenApiToMcpConverter {
    /// Create a new converter with the given tool name prefix.
    pub fn new(prefix: impl Into<String>) -> Self {
        Self {
            prefix: prefix.into(),
        }
    }

    /// Convert all operations in the spec to MCP tool definitions.
    pub fn convert(&self, spec: &OpenApiSpec) -> Vec<McpToolDef> {
        spec.operations
            .iter()
            .map(|op| self.operation_to_tool(op))
            .collect()
    }

    /// Convert a single operation to an MCP tool definition.
    fn operation_to_tool(&self, op: &Operation) -> McpToolDef {
        let name = self.tool_name(op);
        let description = self.tool_description(op);
        let input_schema = self.build_input_schema(op);

        McpToolDef {
            name,
            description,
            input_schema,
        }
    }

    /// Derive the tool name from the operation.
    ///
    /// - If `operationId` is set: `{prefix}_{operationId}`
    /// - Otherwise: `{prefix}_{method}_{path_slug}`
    fn tool_name(&self, op: &Operation) -> String {
        match &op.operation_id {
            Some(id) => format!("{}_{}", self.prefix, id),
            None => {
                let slug = path_to_slug(&op.path);
                format!("{}_{}_{}", self.prefix, op.method.as_str(), slug)
            }
        }
    }

    /// Derive a description from summary and/or description fields.
    fn tool_description(&self, op: &Operation) -> String {
        match (&op.summary, &op.description) {
            (Some(s), Some(d)) => format!("{s}. {d}"),
            (Some(s), None) => s.clone(),
            (None, Some(d)) => d.clone(),
            (None, None) => format!("{} {}", op.method.as_str().to_uppercase(), op.path),
        }
    }

    /// Build a JSON Schema `object` that merges parameters and request body.
    fn build_input_schema(&self, op: &Operation) -> serde_json::Value {
        let mut properties = serde_json::Map::new();
        let mut required = Vec::new();

        // Add parameters (path, query, header) as top-level properties.
        for param in &op.parameters {
            let mut schema = param.schema.value.clone();
            if let Some(desc) = &param.description {
                if let serde_json::Value::Object(ref mut m) = schema {
                    m.insert(
                        "description".into(),
                        serde_json::Value::String(desc.clone()),
                    );
                }
            }
            properties.insert(param.name.clone(), schema);
            if param.required {
                required.push(serde_json::Value::String(param.name.clone()));
            }
        }

        // Merge request body schema properties into the top-level object.
        if let Some(body) = &op.request_body {
            if let serde_json::Value::Object(body_obj) = &body.schema.value {
                // If the body schema is an object type, merge its properties.
                if let Some(serde_json::Value::Object(body_props)) = body_obj.get("properties") {
                    for (key, val) in body_props {
                        properties.insert(key.clone(), val.clone());
                    }
                }
                // Merge required fields from body schema.
                if let Some(serde_json::Value::Array(body_req)) = body_obj.get("required") {
                    for r in body_req {
                        required.push(r.clone());
                    }
                }
            } else {
                // Non-object body: wrap under a `body` property.
                let mut schema = body.schema.value.clone();
                if let Some(desc) = &body.description {
                    if let serde_json::Value::Object(ref mut m) = schema {
                        m.insert(
                            "description".into(),
                            serde_json::Value::String(desc.clone()),
                        );
                    }
                }
                properties.insert("body".into(), schema);
                if body.required {
                    required.push(serde_json::Value::String("body".into()));
                }
            }
        }

        let mut schema = serde_json::json!({
            "type": "object",
            "properties": serde_json::Value::Object(properties),
        });

        if !required.is_empty() {
            schema["required"] = serde_json::Value::Array(required);
        }

        schema
    }
}

/// Convert a path template to a slug for tool naming.
///
/// `/users/{user_id}/posts` → `users_by_user_id_posts`
fn path_to_slug(path: &str) -> String {
    let mut slug = String::new();
    let segments: Vec<&str> = path.split('/').filter(|s| !s.is_empty()).collect();

    for (i, segment) in segments.iter().enumerate() {
        if i > 0 {
            slug.push('_');
        }
        if segment.starts_with('{') && segment.ends_with('}') {
            let param_name = &segment[1..segment.len() - 1];
            slug.push_str("by_");
            slug.push_str(param_name);
        } else {
            slug.push_str(segment);
        }
    }

    slug
}

// ---------------------------------------------------------------------------
// MCP Call Router
// ---------------------------------------------------------------------------

/// Internal record linking a tool name back to its originating operation.
#[derive(Debug, Clone)]
struct RouteEntry {
    method: HttpMethod,
    path_template: String,
    parameters: Vec<Parameter>,
    has_request_body: bool,
}

/// Routes `tools/call` invocations back to the original HTTP operation.
///
/// Built from the same [`OpenApiSpec`] and prefix used for conversion.
/// Uses a plain `HashMap` since routes are immutable after construction.
pub struct McpCallRouter {
    /// tool_name → route metadata (read-only after construction).
    routes: HashMap<String, RouteEntry>,
}

impl McpCallRouter {
    /// Build a router from an OpenAPI spec and a tool name prefix.
    ///
    /// Uses the same naming logic as [`OpenApiToMcpConverter`] so tool names
    /// match exactly.
    pub fn new(spec: &OpenApiSpec, prefix: &str) -> Self {
        let converter = OpenApiToMcpConverter::new(prefix);
        let mut routes = HashMap::with_capacity(spec.operations.len());

        for op in &spec.operations {
            let tool_name = converter.tool_name(op);

            routes.insert(
                tool_name,
                RouteEntry {
                    method: op.method,
                    path_template: op.path.clone(),
                    parameters: op.parameters.clone(),
                    has_request_body: op.request_body.is_some(),
                },
            );
        }

        Self { routes }
    }

    /// Route a `tools/call` invocation to an [`HttpCallSpec`].
    ///
    /// Returns `None` if the tool name is not recognized.
    pub fn route(&self, tool_name: &str, arguments: &serde_json::Value) -> Option<HttpCallSpec> {
        let entry = self.routes.get(tool_name)?;
        let empty_map = serde_json::Map::new();
        let args = arguments.as_object().unwrap_or(&empty_map);

        // Substitute path parameters.
        let mut path = entry.path_template.clone();
        let mut query_params = Vec::new();
        let mut headers = Vec::new();

        for param in &entry.parameters {
            let value_str = args.get(&param.name).map(|v| match v {
                serde_json::Value::String(s) => s.clone(),
                other => other.to_string(),
            });

            match param.location {
                ParameterLocation::Path => {
                    if let Some(val) = &value_str {
                        path = path.replace(&format!("{{{}}}", param.name), val);
                    }
                }
                ParameterLocation::Query => {
                    if let Some(val) = value_str {
                        query_params.push((param.name.clone(), val));
                    }
                }
                ParameterLocation::Header => {
                    if let Some(val) = value_str {
                        headers.push((param.name.clone(), val));
                    }
                }
            }
        }

        // Extract body: collect all argument keys that are not parameters.
        let body = if entry.has_request_body {
            let param_names: std::collections::HashSet<&str> =
                entry.parameters.iter().map(|p| p.name.as_str()).collect();

            let body_obj: serde_json::Map<String, serde_json::Value> = args
                .iter()
                .filter(|(k, _)| !param_names.contains(k.as_str()))
                .map(|(k, v)| (k.clone(), v.clone()))
                .collect();

            if body_obj.is_empty() {
                None
            } else {
                Some(serde_json::Value::Object(body_obj))
            }
        } else {
            None
        };

        Some(HttpCallSpec {
            method: entry.method.as_str().to_uppercase(),
            path,
            query_params,
            headers,
            body,
        })
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    /// Helper: build a minimal spec with one GET endpoint.
    fn simple_get_spec() -> OpenApiSpec {
        OpenApiSpec {
            title: "Test API".into(),
            version: "1.0.0".into(),
            base_url: Some("https://api.example.com".into()),
            operations: vec![Operation {
                method: HttpMethod::Get,
                path: "/users".into(),
                operation_id: Some("listUsers".into()),
                summary: Some("List all users".into()),
                description: None,
                parameters: vec![Parameter {
                    name: "limit".into(),
                    location: ParameterLocation::Query,
                    description: Some("Maximum number of results".into()),
                    required: false,
                    schema: JsonSchema::integer(),
                }],
                request_body: None,
            }],
        }
    }

    /// Helper: build a spec with a POST endpoint that has a request body.
    fn post_with_body_spec() -> OpenApiSpec {
        OpenApiSpec {
            title: "Test API".into(),
            version: "1.0.0".into(),
            base_url: None,
            operations: vec![Operation {
                method: HttpMethod::Post,
                path: "/users".into(),
                operation_id: Some("createUser".into()),
                summary: Some("Create a new user".into()),
                description: Some("Creates a user with the given data".into()),
                parameters: vec![],
                request_body: Some(RequestBody {
                    description: Some("User object".into()),
                    required: true,
                    schema: JsonSchema::from_value(serde_json::json!({
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "email": {"type": "string", "format": "email"}
                        },
                        "required": ["name", "email"]
                    })),
                }),
            }],
        }
    }

    /// Helper: build a spec with path + query parameters.
    fn path_and_query_spec() -> OpenApiSpec {
        OpenApiSpec {
            title: "Test API".into(),
            version: "1.0.0".into(),
            base_url: None,
            operations: vec![Operation {
                method: HttpMethod::Get,
                path: "/users/{user_id}/posts".into(),
                operation_id: Some("getUserPosts".into()),
                summary: Some("Get posts for a user".into()),
                description: None,
                parameters: vec![
                    Parameter {
                        name: "user_id".into(),
                        location: ParameterLocation::Path,
                        description: Some("The user ID".into()),
                        required: true,
                        schema: JsonSchema::string(),
                    },
                    Parameter {
                        name: "page".into(),
                        location: ParameterLocation::Query,
                        description: Some("Page number".into()),
                        required: false,
                        schema: JsonSchema::integer(),
                    },
                    Parameter {
                        name: "Authorization".into(),
                        location: ParameterLocation::Header,
                        description: Some("Bearer token".into()),
                        required: true,
                        schema: JsonSchema::string(),
                    },
                ],
                request_body: None,
            }],
        }
    }

    // ----- Test 1: Convert simple GET endpoint to MCP tool -----

    #[test]
    fn convert_simple_get_endpoint() {
        let spec = simple_get_spec();
        let converter = OpenApiToMcpConverter::new("testapi");
        let tools = converter.convert(&spec);

        assert_eq!(tools.len(), 1);
        let tool = &tools[0];
        assert_eq!(tool.name, "testapi_listUsers");
        assert_eq!(tool.description, "List all users");

        // input_schema should be an object with a "limit" property.
        let props = tool.input_schema["properties"].as_object().unwrap();
        assert!(props.contains_key("limit"));
        assert_eq!(props["limit"]["type"], "integer");
        assert_eq!(props["limit"]["description"], "Maximum number of results");

        // "limit" is not required.
        assert!(tool.input_schema.get("required").is_none());
    }

    // ----- Test 2: Convert POST with request body -----

    #[test]
    fn convert_post_with_request_body() {
        let spec = post_with_body_spec();
        let converter = OpenApiToMcpConverter::new("testapi");
        let tools = converter.convert(&spec);

        assert_eq!(tools.len(), 1);
        let tool = &tools[0];
        assert_eq!(tool.name, "testapi_createUser");
        // Summary + description concatenated.
        assert_eq!(
            tool.description,
            "Create a new user. Creates a user with the given data"
        );

        // Body properties should be merged into input_schema.
        let props = tool.input_schema["properties"].as_object().unwrap();
        assert!(props.contains_key("name"));
        assert!(props.contains_key("email"));
        assert_eq!(props["name"]["type"], "string");
        assert_eq!(props["email"]["format"], "email");

        // Required fields from body should be present.
        let required = tool.input_schema["required"].as_array().unwrap();
        let req_strings: Vec<&str> = required.iter().filter_map(|v| v.as_str()).collect();
        assert!(req_strings.contains(&"name"));
        assert!(req_strings.contains(&"email"));
    }

    // ----- Test 3: Convert endpoint with path + query + header parameters -----

    #[test]
    fn convert_endpoint_with_mixed_parameters() {
        let spec = path_and_query_spec();
        let converter = OpenApiToMcpConverter::new("testapi");
        let tools = converter.convert(&spec);

        assert_eq!(tools.len(), 1);
        let tool = &tools[0];

        let props = tool.input_schema["properties"].as_object().unwrap();
        assert!(props.contains_key("user_id"), "path param missing");
        assert!(props.contains_key("page"), "query param missing");
        assert!(props.contains_key("Authorization"), "header param missing");

        // user_id and Authorization are required.
        let required = tool.input_schema["required"].as_array().unwrap();
        let req_strings: Vec<&str> = required.iter().filter_map(|v| v.as_str()).collect();
        assert!(req_strings.contains(&"user_id"));
        assert!(req_strings.contains(&"Authorization"));
        assert!(!req_strings.contains(&"page"));
    }

    // ----- Test 4: Tool name generation from operationId -----

    #[test]
    fn tool_name_from_operation_id() {
        let spec = simple_get_spec();
        let converter = OpenApiToMcpConverter::new("myapi");
        let tools = converter.convert(&spec);

        assert_eq!(tools[0].name, "myapi_listUsers");
    }

    // ----- Test 5: Tool name generation from method + path (no operationId) -----

    #[test]
    fn tool_name_from_method_and_path() {
        let spec = OpenApiSpec {
            title: "Test".into(),
            version: "1.0.0".into(),
            base_url: None,
            operations: vec![Operation {
                method: HttpMethod::Delete,
                path: "/users/{user_id}/posts/{post_id}".into(),
                operation_id: None,
                summary: None,
                description: Some("Delete a specific post".into()),
                parameters: vec![
                    Parameter {
                        name: "user_id".into(),
                        location: ParameterLocation::Path,
                        description: None,
                        required: true,
                        schema: JsonSchema::string(),
                    },
                    Parameter {
                        name: "post_id".into(),
                        location: ParameterLocation::Path,
                        description: None,
                        required: true,
                        schema: JsonSchema::string(),
                    },
                ],
                request_body: None,
            }],
        };

        let converter = OpenApiToMcpConverter::new("blog");
        let tools = converter.convert(&spec);

        assert_eq!(
            tools[0].name,
            "blog_delete_users_by_user_id_posts_by_post_id"
        );

        // Description falls back to the description field.
        assert_eq!(tools[0].description, "Delete a specific post");
    }

    // ----- Test 6: Route MCP tool call back to HTTP spec -----

    #[test]
    fn route_mcp_tool_call_to_http_spec() {
        let spec = path_and_query_spec();
        let router = McpCallRouter::new(&spec, "testapi");

        let arguments = serde_json::json!({
            "user_id": "42",
            "page": 3,
            "Authorization": "Bearer tok_abc123"
        });

        let call_spec = router
            .route("testapi_getUserPosts", &arguments)
            .expect("route should succeed");

        assert_eq!(call_spec.method, "GET");
        assert_eq!(call_spec.path, "/users/42/posts");
        assert_eq!(call_spec.query_params, vec![("page".into(), "3".into())]);
        assert_eq!(
            call_spec.headers,
            vec![("Authorization".into(), "Bearer tok_abc123".into())]
        );
        assert!(call_spec.body.is_none());
    }

    // ----- Additional: Route POST with body -----

    #[test]
    fn route_post_with_body_arguments() {
        let spec = post_with_body_spec();
        let router = McpCallRouter::new(&spec, "testapi");

        let arguments = serde_json::json!({
            "name": "Alice",
            "email": "alice@example.com"
        });

        let call_spec = router
            .route("testapi_createUser", &arguments)
            .expect("route should succeed");

        assert_eq!(call_spec.method, "POST");
        assert_eq!(call_spec.path, "/users");
        assert!(call_spec.query_params.is_empty());
        assert!(call_spec.headers.is_empty());

        let body = call_spec.body.unwrap();
        assert_eq!(body["name"], "Alice");
        assert_eq!(body["email"], "alice@example.com");
    }

    // ----- Additional: Unknown tool returns None -----

    #[test]
    fn route_unknown_tool_returns_none() {
        let spec = simple_get_spec();
        let router = McpCallRouter::new(&spec, "testapi");

        let result = router.route("nonexistent_tool", &serde_json::json!({}));
        assert!(result.is_none());
    }

    // ----- Additional: path_to_slug helper -----

    #[test]
    fn path_to_slug_conversion() {
        assert_eq!(path_to_slug("/users"), "users");
        assert_eq!(path_to_slug("/users/{id}"), "users_by_id");
        assert_eq!(
            path_to_slug("/users/{user_id}/posts/{post_id}"),
            "users_by_user_id_posts_by_post_id"
        );
        assert_eq!(path_to_slug("/health"), "health");
        assert_eq!(path_to_slug("/"), "");
    }

    // ----- Additional: description fallback when both fields missing -----

    #[test]
    fn description_fallback_to_method_and_path() {
        let spec = OpenApiSpec {
            title: "Test".into(),
            version: "1.0.0".into(),
            base_url: None,
            operations: vec![Operation {
                method: HttpMethod::Get,
                path: "/health".into(),
                operation_id: Some("healthCheck".into()),
                summary: None,
                description: None,
                parameters: vec![],
                request_body: None,
            }],
        };

        let converter = OpenApiToMcpConverter::new("svc");
        let tools = converter.convert(&spec);
        assert_eq!(tools[0].description, "GET /health");
    }
}
