// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Governance & Policy Lifecycle (F18).
//!
//! Policy versioning with Draft → PendingApproval → Active → Superseded/RolledBack states.

use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{SystemTime, UNIX_EPOCH};

use dashmap::DashMap;

// ---------------------------------------------------------------------------
// Policy lifecycle states
// ---------------------------------------------------------------------------

/// Policy lifecycle states.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub enum PolicyState {
    Draft,
    PendingApproval,
    Active,
    Superseded,
    RolledBack,
}

// ---------------------------------------------------------------------------
// PolicyVersion
// ---------------------------------------------------------------------------

/// A versioned policy.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct PolicyVersion {
    pub policy_id: String,
    pub version: u64,
    pub state: PolicyState,
    pub content: String,
    pub description: String,
    pub author: String,
    pub created_at: u64,
    pub activated_at: Option<u64>,
    pub deactivated_at: Option<u64>,
}

// ---------------------------------------------------------------------------
// Error types
// ---------------------------------------------------------------------------

/// Errors returned by the governance lifecycle manager.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
pub enum GovernanceError {
    #[error("policy not found: {0}")]
    PolicyNotFound(String),
    #[error("version not found: {policy_id} v{version}")]
    VersionNotFound { policy_id: String, version: u64 },
    #[error("invalid state transition: {from:?} → {to:?}")]
    InvalidTransition { from: PolicyState, to: PolicyState },
    #[error("no active version to rollback")]
    NoActiveVersion,
    #[error("cannot rollback to non-Active/Superseded version")]
    InvalidRollbackTarget,
}

// ---------------------------------------------------------------------------
// Governance report
// ---------------------------------------------------------------------------

/// Summary report produced by [`PolicyLifecycleManager::report`].
#[derive(Debug, Clone)]
pub struct GovernanceReport {
    pub total_policies: usize,
    pub active_policies: usize,
    pub draft_policies: usize,
    pub total_versions: usize,
    pub rollback_count: usize,
}

// ---------------------------------------------------------------------------
// PolicyLifecycleManager
// ---------------------------------------------------------------------------

/// Policy lifecycle manager.
///
/// Manages policies through the state machine:
/// `Draft → PendingApproval → Active → Superseded/RolledBack`
///
/// All methods are lock-free for reads; mutations use `DashMap` entry APIs.
pub struct PolicyLifecycleManager {
    /// policy_id → list of versions (newest last).
    history: DashMap<String, Vec<PolicyVersion>>,
    /// policy_id → currently active version number.
    active: DashMap<String, u64>,
    /// Monotonically increasing version counter (shared across all policies).
    next_version: AtomicU64,
}

impl PolicyLifecycleManager {
    /// Create a new, empty lifecycle manager.
    pub fn new() -> Self {
        Self {
            history: DashMap::new(),
            active: DashMap::new(),
            next_version: AtomicU64::new(1),
        }
    }

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------

    fn now_secs() -> u64 {
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs()
    }

    fn next_ver(&self) -> u64 {
        self.next_version.fetch_add(1, Ordering::Relaxed)
    }

    // -----------------------------------------------------------------------
    // Lifecycle operations
    // -----------------------------------------------------------------------

    /// Create a new draft policy. Returns the assigned version number.
    pub fn create_draft(
        &self,
        policy_id: &str,
        content: &str,
        description: &str,
        author: &str,
    ) -> u64 {
        let version = self.next_ver();
        let pv = PolicyVersion {
            policy_id: policy_id.to_string(),
            version,
            state: PolicyState::Draft,
            content: content.to_string(),
            description: description.to_string(),
            author: author.to_string(),
            created_at: Self::now_secs(),
            activated_at: None,
            deactivated_at: None,
        };
        self.history
            .entry(policy_id.to_string())
            .or_default()
            .push(pv);
        version
    }

    /// Submit a draft for approval (Draft → PendingApproval).
    pub fn submit_for_approval(
        &self,
        policy_id: &str,
        version: u64,
    ) -> Result<(), GovernanceError> {
        let mut entry = self
            .history
            .get_mut(policy_id)
            .ok_or_else(|| GovernanceError::PolicyNotFound(policy_id.to_string()))?;

        let pv = entry
            .iter_mut()
            .find(|v| v.version == version)
            .ok_or_else(|| GovernanceError::VersionNotFound {
                policy_id: policy_id.to_string(),
                version,
            })?;

        if pv.state != PolicyState::Draft {
            return Err(GovernanceError::InvalidTransition {
                from: pv.state,
                to: PolicyState::PendingApproval,
            });
        }

        pv.state = PolicyState::PendingApproval;
        Ok(())
    }

    /// Approve a policy version (PendingApproval → Active).
    ///
    /// If another version is currently active, it is moved to Superseded.
    pub fn approve(&self, policy_id: &str, version: u64) -> Result<(), GovernanceError> {
        let mut entry = self
            .history
            .get_mut(policy_id)
            .ok_or_else(|| GovernanceError::PolicyNotFound(policy_id.to_string()))?;

        // Verify the target version exists and is in PendingApproval state.
        {
            let pv = entry.iter().find(|v| v.version == version).ok_or_else(|| {
                GovernanceError::VersionNotFound {
                    policy_id: policy_id.to_string(),
                    version,
                }
            })?;

            if pv.state != PolicyState::PendingApproval {
                return Err(GovernanceError::InvalidTransition {
                    from: pv.state,
                    to: PolicyState::Active,
                });
            }
        }

        let now = Self::now_secs();

        // Supersede the current active version (if any).
        if let Some(prev_version) = self.active.get(policy_id).map(|v| *v) {
            if let Some(prev) = entry.iter_mut().find(|v| v.version == prev_version) {
                if prev.state == PolicyState::Active {
                    prev.state = PolicyState::Superseded;
                    prev.deactivated_at = Some(now);
                }
            }
        }

        // Activate the target version.
        if let Some(pv) = entry.iter_mut().find(|v| v.version == version) {
            pv.state = PolicyState::Active;
            pv.activated_at = Some(now);
        }

        // Record as active.
        self.active.insert(policy_id.to_string(), version);

        Ok(())
    }

    /// Rollback: deactivate current active version, reactivate a previous one.
    ///
    /// `target_version` must be in `Active` or `Superseded` state.
    /// The current active version is moved to `RolledBack`.
    /// The target version is moved to `Active` (and records are updated).
    pub fn rollback(&self, policy_id: &str, target_version: u64) -> Result<(), GovernanceError> {
        let current_active = *self
            .active
            .get(policy_id)
            .ok_or(GovernanceError::NoActiveVersion)?;

        let mut entry = self
            .history
            .get_mut(policy_id)
            .ok_or_else(|| GovernanceError::PolicyNotFound(policy_id.to_string()))?;

        // Validate target version exists and is eligible.
        {
            let target = entry
                .iter()
                .find(|v| v.version == target_version)
                .ok_or_else(|| GovernanceError::VersionNotFound {
                    policy_id: policy_id.to_string(),
                    version: target_version,
                })?;

            if target.state != PolicyState::Active && target.state != PolicyState::Superseded {
                return Err(GovernanceError::InvalidRollbackTarget);
            }
        }

        let now = Self::now_secs();

        // Mark the current active version as RolledBack.
        if let Some(cur) = entry.iter_mut().find(|v| v.version == current_active) {
            cur.state = PolicyState::RolledBack;
            cur.deactivated_at = Some(now);
        }

        // Reactivate target.
        if let Some(pv) = entry.iter_mut().find(|v| v.version == target_version) {
            pv.state = PolicyState::Active;
            pv.activated_at = Some(now);
            pv.deactivated_at = None;
        }

        self.active.insert(policy_id.to_string(), target_version);

        Ok(())
    }

    // -----------------------------------------------------------------------
    // Query operations
    // -----------------------------------------------------------------------

    /// Get the currently active version of a policy.
    pub fn get_active(&self, policy_id: &str) -> Option<PolicyVersion> {
        let version = *self.active.get(policy_id)?;
        self.get_version(policy_id, version)
    }

    /// Get full version history for a policy (oldest first).
    pub fn get_history(&self, policy_id: &str) -> Vec<PolicyVersion> {
        self.history
            .get(policy_id)
            .map(|v| v.value().clone())
            .unwrap_or_default()
    }

    /// Get a specific version of a policy.
    pub fn get_version(&self, policy_id: &str, version: u64) -> Option<PolicyVersion> {
        self.history
            .get(policy_id)?
            .iter()
            .find(|v| v.version == version)
            .cloned()
    }

    /// List all known policies with their currently active version (if any).
    pub fn list_policies(&self) -> Vec<(String, Option<PolicyVersion>)> {
        self.history
            .iter()
            .map(|entry| {
                let policy_id = entry.key().clone();
                let active = self.get_active(&policy_id);
                (policy_id, active)
            })
            .collect()
    }

    /// Generate a summary governance report.
    pub fn report(&self) -> GovernanceReport {
        let total_policies = self.history.len();
        let active_policies = self.active.len();

        let mut draft_policies = 0usize;
        let mut total_versions = 0usize;
        let mut rollback_count = 0usize;

        for entry in self.history.iter() {
            for pv in entry.value().iter() {
                total_versions += 1;
                if pv.state == PolicyState::Draft {
                    draft_policies += 1;
                }
                if pv.state == PolicyState::RolledBack {
                    rollback_count += 1;
                }
            }
        }

        GovernanceReport {
            total_policies,
            active_policies,
            draft_policies,
            total_versions,
            rollback_count,
        }
    }
}

impl Default for PolicyLifecycleManager {
    fn default() -> Self {
        Self::new()
    }
}

// ---------------------------------------------------------------------------
// Unit tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn create_draft_and_submit() {
        let mgr = PolicyLifecycleManager::new();
        let v = mgr.create_draft("pol-1", "content", "desc", "alice");
        assert!(v > 0);

        let history = mgr.get_history("pol-1");
        assert_eq!(history.len(), 1);
        assert_eq!(history[0].state, PolicyState::Draft);
        assert_eq!(history[0].author, "alice");

        mgr.submit_for_approval("pol-1", v).unwrap();
        let history = mgr.get_history("pol-1");
        assert_eq!(history[0].state, PolicyState::PendingApproval);
    }

    #[test]
    fn approve_activates_policy() {
        let mgr = PolicyLifecycleManager::new();
        let v = mgr.create_draft("pol-2", "allow *", "initial", "bob");
        mgr.submit_for_approval("pol-2", v).unwrap();
        mgr.approve("pol-2", v).unwrap();

        let active = mgr.get_active("pol-2").unwrap();
        assert_eq!(active.version, v);
        assert_eq!(active.state, PolicyState::Active);
        assert!(active.activated_at.is_some());
    }

    #[test]
    fn approve_supersedes_previous() {
        let mgr = PolicyLifecycleManager::new();

        // First version: Draft → Pending → Active
        let v1 = mgr.create_draft("pol-3", "v1", "first", "carol");
        mgr.submit_for_approval("pol-3", v1).unwrap();
        mgr.approve("pol-3", v1).unwrap();

        // Second version: Draft → Pending → Active
        let v2 = mgr.create_draft("pol-3", "v2", "second", "carol");
        mgr.submit_for_approval("pol-3", v2).unwrap();
        mgr.approve("pol-3", v2).unwrap();

        // v1 should be Superseded
        let ver1 = mgr.get_version("pol-3", v1).unwrap();
        assert_eq!(ver1.state, PolicyState::Superseded);
        assert!(ver1.deactivated_at.is_some());

        // v2 should be Active
        let active = mgr.get_active("pol-3").unwrap();
        assert_eq!(active.version, v2);
        assert_eq!(active.state, PolicyState::Active);
    }

    #[test]
    fn rollback_to_previous_version() {
        let mgr = PolicyLifecycleManager::new();

        let v1 = mgr.create_draft("pol-4", "v1-content", "first", "dave");
        mgr.submit_for_approval("pol-4", v1).unwrap();
        mgr.approve("pol-4", v1).unwrap();

        let v2 = mgr.create_draft("pol-4", "v2-content", "second", "dave");
        mgr.submit_for_approval("pol-4", v2).unwrap();
        mgr.approve("pol-4", v2).unwrap();

        // Rollback from v2 to v1
        mgr.rollback("pol-4", v1).unwrap();

        // v1 is now Active again
        let active = mgr.get_active("pol-4").unwrap();
        assert_eq!(active.version, v1);
        assert_eq!(active.state, PolicyState::Active);

        // v2 is RolledBack
        let ver2 = mgr.get_version("pol-4", v2).unwrap();
        assert_eq!(ver2.state, PolicyState::RolledBack);
        assert!(ver2.deactivated_at.is_some());
    }

    #[test]
    fn invalid_state_transitions() {
        let mgr = PolicyLifecycleManager::new();

        // Cannot submit a Draft directly to approve
        let v = mgr.create_draft("pol-5", "content", "desc", "eve");
        let err = mgr.approve("pol-5", v).unwrap_err();
        assert!(
            matches!(
                err,
                GovernanceError::InvalidTransition {
                    from: PolicyState::Draft,
                    to: PolicyState::Active
                }
            ),
            "expected InvalidTransition, got: {err}"
        );

        // Cannot submit a PendingApproval again
        mgr.submit_for_approval("pol-5", v).unwrap();
        let err = mgr.submit_for_approval("pol-5", v).unwrap_err();
        assert!(
            matches!(
                err,
                GovernanceError::InvalidTransition {
                    from: PolicyState::PendingApproval,
                    to: PolicyState::PendingApproval
                }
            ),
            "expected InvalidTransition, got: {err}"
        );

        // Unknown policy returns PolicyNotFound
        let err = mgr.submit_for_approval("nonexistent", 1).unwrap_err();
        assert!(matches!(err, GovernanceError::PolicyNotFound(_)));

        // Unknown version returns VersionNotFound
        let err = mgr.get_version("pol-5", 9999);
        assert!(err.is_none());
        let err = mgr.submit_for_approval("pol-5", 9999).unwrap_err();
        assert!(matches!(err, GovernanceError::VersionNotFound { .. }));
    }

    #[test]
    fn governance_report_accurate() {
        let mgr = PolicyLifecycleManager::new();

        // Policy A: one draft (never approved)
        mgr.create_draft("pol-a", "draft content", "draft", "frank");

        // Policy B: draft → pending → active (v1), then v2 active (v1 superseded)
        let b1 = mgr.create_draft("pol-b", "b-v1", "b first", "grace");
        mgr.submit_for_approval("pol-b", b1).unwrap();
        mgr.approve("pol-b", b1).unwrap();

        let b2 = mgr.create_draft("pol-b", "b-v2", "b second", "grace");
        mgr.submit_for_approval("pol-b", b2).unwrap();
        mgr.approve("pol-b", b2).unwrap();

        // Policy C: one version active, one rolled back
        let c1 = mgr.create_draft("pol-c", "c-v1", "c first", "henry");
        mgr.submit_for_approval("pol-c", c1).unwrap();
        mgr.approve("pol-c", c1).unwrap();

        let c2 = mgr.create_draft("pol-c", "c-v2", "c second", "henry");
        mgr.submit_for_approval("pol-c", c2).unwrap();
        mgr.approve("pol-c", c2).unwrap();
        mgr.rollback("pol-c", c1).unwrap();

        let report = mgr.report();

        assert_eq!(report.total_policies, 3);
        // pol-b (b2 active) + pol-c (c1 active) = 2
        assert_eq!(report.active_policies, 2);
        // pol-a has one draft
        assert_eq!(report.draft_policies, 1);
        // pol-a: 1, pol-b: 2, pol-c: 2 = 5 total versions
        assert_eq!(report.total_versions, 5);
        // pol-c v2 was rolled back
        assert_eq!(report.rollback_count, 1);
    }

    #[test]
    fn rollback_without_active_version_errors() {
        let mgr = PolicyLifecycleManager::new();
        let err = mgr.rollback("pol-x", 1).unwrap_err();
        assert!(matches!(err, GovernanceError::NoActiveVersion));
    }

    #[test]
    fn rollback_to_draft_errors() {
        let mgr = PolicyLifecycleManager::new();

        // Create v1 (active) and v2 (draft, never approved)
        let v1 = mgr.create_draft("pol-6", "v1", "first", "alice");
        mgr.submit_for_approval("pol-6", v1).unwrap();
        mgr.approve("pol-6", v1).unwrap();

        let v2 = mgr.create_draft("pol-6", "v2", "second", "alice");

        let err = mgr.rollback("pol-6", v2).unwrap_err();
        assert!(
            matches!(err, GovernanceError::InvalidRollbackTarget),
            "expected InvalidRollbackTarget, got: {err}"
        );
    }
}
