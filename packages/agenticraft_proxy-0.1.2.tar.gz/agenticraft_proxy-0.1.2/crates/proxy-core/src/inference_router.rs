// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! AI-aware backend routing with GPU metrics (F30).
//!
//! Routes requests to self-hosted inference backends based on real-time GPU state:
//! KV cache utilization, running/waiting requests, LoRA adapter affinity,
//! and prefix cache affinity. Falls through to Thompson sampling for
//! third-party API providers (OpenAI, Anthropic, etc.) that lack GPU metrics.
//!
//! Routing priority:
//! 1. Filter unhealthy + KV cache > threshold
//! 2. Prefix cache affinity
//! 3. LoRA adapter affinity
//! 4. Lowest KV cache utilization
//! 5. Thompson sampling fallback

use std::collections::HashSet;
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::Instant;

use dashmap::DashMap;

/// Real-time metrics for an inference backend.
#[derive(Debug)]
pub struct InferenceBackendMetrics {
    /// KV cache utilization (0.0 - 1.0).
    pub kv_cache_utilization: f64,
    /// Number of currently running requests.
    pub running_requests: u32,
    /// Number of requests waiting in queue.
    pub waiting_requests: u32,
    /// Set of currently loaded LoRA adapter names.
    pub loaded_lora_adapters: HashSet<String>,
    /// Set of cached prefix hashes (for prefix cache affinity).
    pub cached_prefixes: HashSet<u64>,
    /// Estimated available token budget.
    pub available_token_budget: u64,
    /// Whether this backend is healthy.
    pub healthy: AtomicBool,
    /// Last time metrics were updated.
    pub last_updated: Instant,
}

impl Clone for InferenceBackendMetrics {
    fn clone(&self) -> Self {
        Self {
            kv_cache_utilization: self.kv_cache_utilization,
            running_requests: self.running_requests,
            waiting_requests: self.waiting_requests,
            loaded_lora_adapters: self.loaded_lora_adapters.clone(),
            cached_prefixes: self.cached_prefixes.clone(),
            available_token_budget: self.available_token_budget,
            healthy: AtomicBool::new(self.healthy.load(Ordering::Relaxed)),
            last_updated: self.last_updated,
        }
    }
}

impl Default for InferenceBackendMetrics {
    fn default() -> Self {
        Self {
            kv_cache_utilization: 0.0,
            running_requests: 0,
            waiting_requests: 0,
            loaded_lora_adapters: HashSet::new(),
            cached_prefixes: HashSet::new(),
            available_token_budget: u64::MAX,
            healthy: AtomicBool::new(true),
            last_updated: Instant::now(),
        }
    }
}

/// Configuration for the inference router.
#[derive(Debug, Clone)]
pub struct InferenceRouterConfig {
    /// Maximum KV cache utilization before excluding a backend.
    pub kv_cache_max_utilization: f64,
    /// Maximum queue depth before excluding a backend.
    pub queue_depth_max: u32,
    /// Maximum age of metrics before considering them stale (seconds).
    pub metrics_staleness_secs: u64,
}

impl Default for InferenceRouterConfig {
    fn default() -> Self {
        Self {
            kv_cache_max_utilization: 0.90,
            queue_depth_max: 50,
            metrics_staleness_secs: 10,
        }
    }
}

/// Reason a backend was selected.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RoutingReason {
    /// Selected due to prefix cache hit.
    PrefixCacheAffinity,
    /// Selected due to LoRA adapter already loaded.
    LoraAffinity,
    /// Selected as the backend with lowest KV cache utilization.
    LowestKvCache,
    /// No GPU metrics available — fell through to external routing.
    NoGpuMetrics,
}

impl std::fmt::Display for RoutingReason {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            RoutingReason::PrefixCacheAffinity => write!(f, "prefix_cache_affinity"),
            RoutingReason::LoraAffinity => write!(f, "lora_affinity"),
            RoutingReason::LowestKvCache => write!(f, "lowest_kv_cache"),
            RoutingReason::NoGpuMetrics => write!(f, "no_gpu_metrics"),
        }
    }
}

/// Routing decision from the inference router.
#[derive(Debug, Clone)]
pub struct InferenceRoutingDecision {
    /// Selected backend ID.
    pub backend_id: String,
    /// Why this backend was selected.
    pub reason: RoutingReason,
}

/// AI-aware inference router.
pub struct InferenceRouter {
    /// Per-backend metrics. Key: backend_id.
    backends: DashMap<String, InferenceBackendMetrics>,
    /// Configuration.
    config: InferenceRouterConfig,
}

impl InferenceRouter {
    /// Create a new inference router.
    pub fn new(config: InferenceRouterConfig) -> Self {
        Self {
            backends: DashMap::new(),
            config,
        }
    }

    /// Update metrics for a backend (called by the scraper).
    pub fn update_metrics(&self, backend_id: &str, metrics: InferenceBackendMetrics) {
        self.backends.insert(backend_id.to_string(), metrics);
    }

    /// Mark a backend as healthy or unhealthy.
    pub fn set_healthy(&self, backend_id: &str, healthy: bool) {
        if let Some(m) = self.backends.get(backend_id) {
            m.healthy.store(healthy, Ordering::Relaxed);
        }
    }

    /// Select the best backend for a request.
    ///
    /// `prefix_hash`: Optional hash of the request prefix (for cache affinity).
    /// `lora_adapter`: Optional LoRA adapter name required by the request.
    ///
    /// Returns `None` if no healthy, non-saturated backends are available
    /// (caller should fall through to Thompson sampling).
    pub fn select(
        &self,
        prefix_hash: Option<u64>,
        lora_adapter: Option<&str>,
    ) -> Option<InferenceRoutingDecision> {
        let now = Instant::now();
        let staleness = std::time::Duration::from_secs(self.config.metrics_staleness_secs);

        // Collect candidate IDs and metrics values without cloning the full struct.
        // We iterate the DashMap once and extract only what we need.
        let candidates: Vec<(String, f64, u32, bool, bool)> = self
            .backends
            .iter()
            .filter_map(|entry| {
                let m = entry.value();
                let healthy = m.healthy.load(Ordering::Relaxed);
                let fresh = now.duration_since(m.last_updated) < staleness;
                let not_saturated_kv =
                    m.kv_cache_utilization < self.config.kv_cache_max_utilization;
                let not_saturated_queue = m.waiting_requests < self.config.queue_depth_max;

                if healthy && fresh && not_saturated_kv && not_saturated_queue {
                    let has_prefix = prefix_hash.is_some_and(|h| m.cached_prefixes.contains(&h));
                    let has_lora = lora_adapter.is_some_and(|a| m.loaded_lora_adapters.contains(a));
                    Some((
                        entry.key().clone(),
                        m.kv_cache_utilization,
                        m.waiting_requests,
                        has_prefix,
                        has_lora,
                    ))
                } else {
                    None
                }
            })
            .collect();

        if candidates.is_empty() {
            return None;
        }

        // Priority 1: Prefix cache affinity
        if prefix_hash.is_some() {
            if let Some((id, ..)) = candidates
                .iter()
                .find(|(_, _, _, has_prefix, _)| *has_prefix)
            {
                return Some(InferenceRoutingDecision {
                    backend_id: id.clone(),
                    reason: RoutingReason::PrefixCacheAffinity,
                });
            }
        }

        // Priority 2: LoRA adapter affinity
        if lora_adapter.is_some() {
            if let Some((id, ..)) = candidates.iter().find(|(_, _, _, _, has_lora)| *has_lora) {
                return Some(InferenceRoutingDecision {
                    backend_id: id.clone(),
                    reason: RoutingReason::LoraAffinity,
                });
            }
        }

        // Priority 3: Lowest KV cache utilization
        candidates
            .iter()
            .min_by(|(_, kv_a, _, _, _), (_, kv_b, _, _, _)| {
                kv_a.partial_cmp(kv_b).unwrap_or(std::cmp::Ordering::Equal)
            })
            .map(|(id, ..)| InferenceRoutingDecision {
                backend_id: id.clone(),
                reason: RoutingReason::LowestKvCache,
            })
    }

    /// Remove a backend from the router.
    pub fn remove_backend(&self, backend_id: &str) {
        self.backends.remove(backend_id);
    }

    /// Get the number of registered backends.
    pub fn backend_count(&self) -> usize {
        self.backends.len()
    }

    /// Get the number of healthy backends.
    pub fn healthy_backend_count(&self) -> usize {
        self.backends
            .iter()
            .filter(|e| e.value().healthy.load(Ordering::Relaxed))
            .count()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_backend(kv: f64, queue: u32) -> InferenceBackendMetrics {
        InferenceBackendMetrics {
            kv_cache_utilization: kv,
            waiting_requests: queue,
            ..Default::default()
        }
    }

    #[test]
    fn selects_lowest_kv_cache() {
        let router = InferenceRouter::new(InferenceRouterConfig::default());
        router.update_metrics("a", make_backend(0.5, 10));
        router.update_metrics("b", make_backend(0.3, 10));
        router.update_metrics("c", make_backend(0.7, 10));

        let decision = router.select(None, None).unwrap();
        assert_eq!(decision.backend_id, "b");
        assert_eq!(decision.reason, RoutingReason::LowestKvCache);
    }

    #[test]
    fn excludes_saturated() {
        let router = InferenceRouter::new(InferenceRouterConfig {
            kv_cache_max_utilization: 0.8,
            ..Default::default()
        });
        router.update_metrics("a", make_backend(0.95, 10)); // Saturated
        router.update_metrics("b", make_backend(0.5, 10));

        let decision = router.select(None, None).unwrap();
        assert_eq!(decision.backend_id, "b");
    }

    #[test]
    fn excludes_unhealthy() {
        let router = InferenceRouter::new(InferenceRouterConfig::default());
        router.update_metrics("a", make_backend(0.1, 0));
        router.set_healthy("a", false);
        router.update_metrics("b", make_backend(0.5, 0));

        let decision = router.select(None, None).unwrap();
        assert_eq!(decision.backend_id, "b");
    }

    #[test]
    fn excludes_high_queue_depth() {
        let router = InferenceRouter::new(InferenceRouterConfig {
            queue_depth_max: 20,
            ..Default::default()
        });
        router.update_metrics("a", make_backend(0.1, 30)); // Queue too deep
        router.update_metrics("b", make_backend(0.3, 5));

        let decision = router.select(None, None).unwrap();
        assert_eq!(decision.backend_id, "b");
    }

    #[test]
    fn prefix_cache_affinity() {
        let router = InferenceRouter::new(InferenceRouterConfig::default());

        let mut m_a = make_backend(0.5, 10);
        m_a.cached_prefixes.insert(42);
        router.update_metrics("a", m_a);

        router.update_metrics("b", make_backend(0.1, 0)); // Lower KV but no prefix

        let decision = router.select(Some(42), None).unwrap();
        assert_eq!(decision.backend_id, "a");
        assert_eq!(decision.reason, RoutingReason::PrefixCacheAffinity);
    }

    #[test]
    fn lora_affinity() {
        let router = InferenceRouter::new(InferenceRouterConfig::default());

        let mut m_a = make_backend(0.5, 10);
        m_a.loaded_lora_adapters.insert("fine-tuned-v1".into());
        router.update_metrics("a", m_a);

        router.update_metrics("b", make_backend(0.1, 0)); // Lower KV but no adapter

        let decision = router.select(None, Some("fine-tuned-v1")).unwrap();
        assert_eq!(decision.backend_id, "a");
        assert_eq!(decision.reason, RoutingReason::LoraAffinity);
    }

    #[test]
    fn all_saturated_returns_none() {
        let router = InferenceRouter::new(InferenceRouterConfig {
            kv_cache_max_utilization: 0.8,
            ..Default::default()
        });
        router.update_metrics("a", make_backend(0.95, 10));
        router.update_metrics("b", make_backend(0.85, 10));

        assert!(router.select(None, None).is_none());
    }

    #[test]
    fn empty_router_returns_none() {
        let router = InferenceRouter::new(InferenceRouterConfig::default());
        assert!(router.select(None, None).is_none());
    }

    #[test]
    fn stale_metrics_excluded() {
        let router = InferenceRouter::new(InferenceRouterConfig {
            metrics_staleness_secs: 0, // 0 seconds = immediately stale
            ..Default::default()
        });
        router.update_metrics("a", make_backend(0.1, 0));
        // Metrics are immediately stale
        assert!(router.select(None, None).is_none());
    }

    #[test]
    fn backend_counts() {
        let router = InferenceRouter::new(InferenceRouterConfig::default());
        router.update_metrics("a", make_backend(0.1, 0));
        router.update_metrics("b", make_backend(0.2, 0));
        router.set_healthy("b", false);

        assert_eq!(router.backend_count(), 2);
        assert_eq!(router.healthy_backend_count(), 1);
    }

    #[test]
    fn remove_backend() {
        let router = InferenceRouter::new(InferenceRouterConfig::default());
        router.update_metrics("a", make_backend(0.1, 0));
        router.update_metrics("b", make_backend(0.2, 0));
        assert_eq!(router.backend_count(), 2);

        router.remove_backend("a");
        assert_eq!(router.backend_count(), 1);

        let decision = router.select(None, None).unwrap();
        assert_eq!(decision.backend_id, "b");
    }
}
