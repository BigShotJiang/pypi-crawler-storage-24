// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Human-in-the-loop proxy integration (F17).
//!
//! Implements async resume-token pattern: high-risk requests return 202 Accepted
//! with a resume token. After human approval, client re-submits with the token.

use std::collections::VecDeque;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{Duration, Instant};

use dashmap::DashMap;
use parking_lot::RwLock;
use sha2::{Digest, Sha256};

/// 5-level adaptive oversight model.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub enum OversightLevel {
    /// L0: No human oversight, fully autonomous.
    BlackBox,
    /// L1: Observable — human can inspect but not intervene.
    Observable,
    /// L2: Advisable — AI recommends, human may override.
    Advisable,
    /// L3: Approvable — requires human approval before execution.
    Approvable,
    /// L4: Supervised — human actively monitors every step.
    Supervised,
}

/// Status of a pending approval.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ApprovalStatus {
    Pending,
    Approved {
        approved_by: String,
        approved_at: Instant,
    },
    Rejected {
        rejected_by: String,
        rejected_at: Instant,
        reason: String,
    },
    Expired,
}

/// A pending approval request.
#[derive(Debug, Clone)]
pub struct PendingApproval {
    pub id: String,
    pub agent_id: String,
    pub request_hash: String,
    pub oversight_level: OversightLevel,
    pub risk_reason: String,
    pub created_at: Instant,
    pub expires_at: Instant,
    pub status: ApprovalStatus,
    /// Serialized request context for replay.
    pub request_context: Vec<u8>,
}

/// Resume token data (would be encrypted with Fernet/AES-GCM in production).
#[derive(Debug, Clone, PartialEq)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct ResumeToken {
    pub approval_id: String,
    pub agent_id: String,
    pub request_hash: String,
    pub approved_by: String,
    pub expires_at_unix: u64,
}

/// An opaque encrypted resume token suitable for transport.
///
/// The token is a hex-encoded HMAC-SHA256 over the serialized [`ResumeToken`]
/// fields, keyed by a server secret. Verification recomputes the HMAC and
/// compares in constant time.
#[derive(Debug, Clone, PartialEq)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct EncryptedResumeToken {
    /// Hex-encoded HMAC-SHA256 tag.
    pub tag: String,
    /// The plaintext token data (integrity-protected, not confidential).
    pub token: ResumeToken,
}

/// HITL approval manager.
pub struct HitlManager {
    pending: DashMap<String, PendingApproval>,
    next_id: AtomicU64,
    max_pending: usize,
    default_ttl: Duration,
    /// Bounded history using VecDeque for O(1) eviction from the front.
    history: RwLock<VecDeque<PendingApproval>>,
    max_history: usize,
    /// O(1) lookup of decided approvals by ID (full entry for consume()).
    history_index: DashMap<String, PendingApproval>,
    /// Server secret used for HMAC-SHA256 token integrity.
    server_secret: Vec<u8>,
    /// Lifetime counters — monotonically increasing, never decremented.
    total_approved: AtomicU64,
    total_rejected: AtomicU64,
    total_expired: AtomicU64,
}

impl HitlManager {
    pub fn new(
        max_pending: usize,
        default_ttl_secs: u64,
        max_history: usize,
        server_secret: Vec<u8>,
    ) -> Self {
        Self {
            pending: DashMap::new(),
            next_id: AtomicU64::new(1),
            max_pending,
            default_ttl: Duration::from_secs(default_ttl_secs),
            history: RwLock::new(VecDeque::new()),
            max_history,
            history_index: DashMap::new(),
            server_secret,
            total_approved: AtomicU64::new(0),
            total_rejected: AtomicU64::new(0),
            total_expired: AtomicU64::new(0),
        }
    }

    /// Create a new pending approval. Returns None if max_pending reached.
    pub fn create_approval(
        &self,
        agent_id: &str,
        request_hash: &str,
        oversight_level: OversightLevel,
        risk_reason: &str,
        request_context: Vec<u8>,
    ) -> Option<String> {
        if self.pending.len() >= self.max_pending {
            return None;
        }
        let id = format!("hitl_{}", self.next_id.fetch_add(1, Ordering::Relaxed));
        let now = Instant::now();
        let approval = PendingApproval {
            id: id.clone(),
            agent_id: agent_id.to_string(),
            request_hash: request_hash.to_string(),
            oversight_level,
            risk_reason: risk_reason.to_string(),
            created_at: now,
            expires_at: now + self.default_ttl,
            status: ApprovalStatus::Pending,
            request_context,
        };
        self.pending.insert(id.clone(), approval);
        Some(id)
    }

    /// Approve a pending request. Returns the resume token data if successful.
    pub fn approve(&self, approval_id: &str, approved_by: &str) -> Result<ResumeToken, HitlError> {
        let mut entry = match self.pending.get_mut(approval_id) {
            Some(e) => e,
            None => {
                // Check if already decided (moved to history by prior approve/reject).
                if self.history_index.contains_key(approval_id) {
                    return Err(HitlError::AlreadyDecided);
                }
                return Err(HitlError::NotFound);
            }
        };

        if entry.expires_at < Instant::now() {
            entry.status = ApprovalStatus::Expired;
            let removed = entry.clone();
            drop(entry);
            self.pending.remove(approval_id);
            self.archive(removed);
            return Err(HitlError::Expired);
        }

        match &entry.status {
            ApprovalStatus::Pending => {
                entry.status = ApprovalStatus::Approved {
                    approved_by: approved_by.to_string(),
                    approved_at: Instant::now(),
                };
                let token = ResumeToken {
                    approval_id: approval_id.to_string(),
                    agent_id: entry.agent_id.clone(),
                    request_hash: entry.request_hash.clone(),
                    approved_by: approved_by.to_string(),
                    expires_at_unix: std::time::SystemTime::now()
                        .duration_since(std::time::UNIX_EPOCH)
                        .unwrap_or_default()
                        .as_secs()
                        + self.default_ttl.as_secs(),
                };
                // Move to history immediately — frees the pending capacity slot
                // and ensures lifetime counters are correct. The resume token
                // is verified via history_index (O(1) lookup).
                let approved = entry.clone();
                drop(entry);
                self.pending.remove(approval_id);
                self.archive(approved);
                Ok(token)
            }
            _ => Err(HitlError::AlreadyDecided),
        }
    }

    /// Reject a pending request.
    pub fn reject(
        &self,
        approval_id: &str,
        rejected_by: &str,
        reason: &str,
    ) -> Result<(), HitlError> {
        let mut entry = match self.pending.get_mut(approval_id) {
            Some(e) => e,
            None => {
                if self.history_index.contains_key(approval_id) {
                    return Err(HitlError::AlreadyDecided);
                }
                return Err(HitlError::NotFound);
            }
        };

        match &entry.status {
            ApprovalStatus::Pending => {
                entry.status = ApprovalStatus::Rejected {
                    rejected_by: rejected_by.to_string(),
                    rejected_at: Instant::now(),
                    reason: reason.to_string(),
                };
                let removed = entry.clone();
                drop(entry);
                self.pending.remove(approval_id);
                self.archive(removed);
                Ok(())
            }
            _ => Err(HitlError::AlreadyDecided),
        }
    }

    /// Verify a resume token against a request hash.
    pub fn verify_resume_token(
        &self,
        token: &ResumeToken,
        request_hash: &str,
    ) -> Result<(), HitlError> {
        if token.request_hash != request_hash {
            return Err(HitlError::RequestMismatch);
        }
        let now_unix = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
        if now_unix > token.expires_at_unix {
            return Err(HitlError::Expired);
        }
        // Check pending map first (approved but not yet consumed).
        if let Some(entry) = self.pending.get(&token.approval_id) {
            return match &entry.status {
                ApprovalStatus::Approved { .. } => Ok(()),
                _ => Err(HitlError::NotApproved),
            };
        }
        // Check history index — O(1) instead of linear scan.
        if let Some(entry) = self.history_index.get(&token.approval_id) {
            return match &entry.status {
                ApprovalStatus::Approved { .. } => Ok(()),
                _ => Err(HitlError::NotApproved),
            };
        }
        Err(HitlError::NotFound)
    }

    /// Consume an approved request (move from pending to history).
    ///
    /// Since `approve()` already moves the entry to history, this is O(1)
    /// via `history_index` (stores the full `PendingApproval`).
    pub fn consume(&self, approval_id: &str) -> Option<PendingApproval> {
        // Try pending first (in case approve() was not called yet).
        if let Some((_, approval)) = self.pending.remove(approval_id) {
            self.archive(approval.clone());
            return Some(approval);
        }
        // approve() already archived it — O(1) lookup via history_index.
        let entry = self.history_index.get(approval_id)?;
        if !matches!(&entry.status, ApprovalStatus::Approved { .. }) {
            return None;
        }
        Some(entry.clone())
    }

    /// Get status of a pending approval.
    pub fn get_status(&self, approval_id: &str) -> Option<ApprovalStatus> {
        self.pending.get(approval_id).map(|e| e.status.clone())
    }

    /// List all pending approvals.
    pub fn list_pending(&self) -> Vec<PendingApproval> {
        self.pending.iter().map(|e| e.value().clone()).collect()
    }

    /// Get history of decided approvals.
    pub fn history(&self) -> Vec<PendingApproval> {
        self.history.read().iter().cloned().collect()
    }

    /// Reap expired pending approvals.
    pub fn reap_expired(&self) -> usize {
        let now = Instant::now();
        let expired_ids: Vec<String> = self
            .pending
            .iter()
            .filter(|e| e.expires_at < now)
            .map(|e| e.id.clone())
            .collect();
        let count = expired_ids.len();
        for id in expired_ids {
            if let Some((_, mut approval)) = self.pending.remove(&id) {
                approval.status = ApprovalStatus::Expired;
                self.archive(approval);
            }
        }
        count
    }

    /// Get stats — O(1) via atomic counters.
    pub fn stats(&self) -> HitlStats {
        HitlStats {
            pending_count: self.pending.len(),
            max_pending: self.max_pending,
            total_approved: self.total_approved.load(Ordering::Relaxed) as usize,
            total_rejected: self.total_rejected.load(Ordering::Relaxed) as usize,
            total_expired: self.total_expired.load(Ordering::Relaxed) as usize,
        }
    }

    /// Determine oversight level from risk score (0.0 to 1.0).
    pub fn oversight_for_risk(risk_score: f64) -> OversightLevel {
        match risk_score {
            r if r >= 0.9 => OversightLevel::Supervised,
            r if r >= 0.7 => OversightLevel::Approvable,
            r if r >= 0.5 => OversightLevel::Advisable,
            r if r >= 0.3 => OversightLevel::Observable,
            _ => OversightLevel::BlackBox,
        }
    }

    /// Create an encrypted (integrity-protected) resume token.
    ///
    /// Computes HMAC-SHA256 over the token fields using the server secret.
    /// The tag proves the token was issued by this server and has not been
    /// tampered with.
    pub fn seal_token(&self, token: &ResumeToken) -> EncryptedResumeToken {
        let tag = self.compute_token_hmac(token);
        EncryptedResumeToken {
            tag,
            token: token.clone(),
        }
    }

    /// Verify an encrypted resume token's integrity.
    ///
    /// Recomputes the HMAC-SHA256 and compares with the stored tag.
    /// Returns `Err(HitlError::InvalidToken)` if the tag does not match.
    pub fn verify_sealed_token<'a>(
        &self,
        encrypted: &'a EncryptedResumeToken,
    ) -> Result<&'a ResumeToken, HitlError> {
        let expected_tag = self.compute_token_hmac(&encrypted.token);
        if expected_tag != encrypted.tag {
            return Err(HitlError::InvalidToken);
        }
        Ok(&encrypted.token)
    }

    /// HMAC-SHA256 over token fields, keyed by server_secret.
    fn compute_token_hmac(&self, token: &ResumeToken) -> String {
        let mut hasher = Sha256::new();
        hasher.update(&self.server_secret);
        hasher.update(token.approval_id.as_bytes());
        hasher.update(token.agent_id.as_bytes());
        hasher.update(token.request_hash.as_bytes());
        hasher.update(token.approved_by.as_bytes());
        hasher.update(token.expires_at_unix.to_le_bytes());
        // Double-hash for HMAC-like construction
        let inner = hasher.finalize();
        let mut outer = Sha256::new();
        outer.update(&self.server_secret);
        outer.update(inner);
        hex::encode(outer.finalize())
    }

    fn archive(&self, approval: PendingApproval) {
        // Update lifetime counters.
        match &approval.status {
            ApprovalStatus::Approved { .. } => {
                self.total_approved.fetch_add(1, Ordering::Relaxed);
            }
            ApprovalStatus::Rejected { .. } => {
                self.total_rejected.fetch_add(1, Ordering::Relaxed);
            }
            ApprovalStatus::Expired => {
                self.total_expired.fetch_add(1, Ordering::Relaxed);
            }
            _ => {}
        }
        let id = approval.id.clone();
        // Construct a lightweight index entry without cloning request_context —
        // verify_resume_token() only needs the status, not the payload.
        let index_entry = PendingApproval {
            id: approval.id.clone(),
            agent_id: approval.agent_id.clone(),
            request_hash: approval.request_hash.clone(),
            oversight_level: approval.oversight_level,
            risk_reason: approval.risk_reason.clone(),
            created_at: approval.created_at,
            expires_at: approval.expires_at,
            status: approval.status.clone(),
            request_context: Vec::new(),
        };
        self.history_index.insert(id.clone(), index_entry);
        let mut history = self.history.write();
        history.push_back(approval);
        // Evict oldest entries, keeping index in sync.
        while history.len() > self.max_history {
            if let Some(evicted) = history.pop_front() {
                self.history_index.remove(&evicted.id);
            }
        }
    }
}

/// HITL statistics snapshot.
#[derive(Debug, Clone)]
pub struct HitlStats {
    pub pending_count: usize,
    pub max_pending: usize,
    pub total_approved: usize,
    pub total_rejected: usize,
    pub total_expired: usize,
}

/// Errors returned by [`HitlManager`] operations.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
pub enum HitlError {
    #[error("approval not found")]
    NotFound,
    #[error("approval expired")]
    Expired,
    #[error("approval already decided")]
    AlreadyDecided,
    #[error("resume token request hash mismatch")]
    RequestMismatch,
    #[error("approval not yet approved")]
    NotApproved,
    #[error("max pending approvals reached")]
    CapacityExceeded,
    #[error("invalid or tampered token")]
    InvalidToken,
}

// ---------------------------------------------------------------------------
// Unit tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::Duration;

    fn manager() -> HitlManager {
        HitlManager::new(10, 3600, 100, b"test-secret-key-32bytes-padding!".to_vec())
    }

    #[test]
    fn create_approval_returns_id() {
        let mgr = manager();
        let id = mgr.create_approval(
            "agent-1",
            "hash-abc",
            OversightLevel::Approvable,
            "high risk",
            vec![],
        );
        assert!(id.is_some());
        let id = id.unwrap();
        assert!(id.starts_with("hitl_"));
        assert_eq!(mgr.pending.len(), 1);
    }

    #[test]
    fn approve_returns_resume_token() {
        let mgr = manager();
        let id = mgr
            .create_approval(
                "agent-1",
                "hash-abc",
                OversightLevel::Approvable,
                "high risk",
                vec![],
            )
            .unwrap();
        let token = mgr.approve(&id, "operator@example.com").unwrap();
        assert_eq!(token.approval_id, id);
        assert_eq!(token.agent_id, "agent-1");
        assert_eq!(token.request_hash, "hash-abc");
        assert_eq!(token.approved_by, "operator@example.com");
        assert!(token.expires_at_unix > 0);
    }

    #[test]
    fn reject_moves_to_history() {
        let mgr = manager();
        let id = mgr
            .create_approval(
                "agent-2",
                "hash-xyz",
                OversightLevel::Supervised,
                "very high risk",
                vec![1, 2, 3],
            )
            .unwrap();
        mgr.reject(&id, "reviewer@example.com", "policy violation")
            .unwrap();
        // Should be removed from pending
        assert_eq!(mgr.pending.len(), 0);
        // Should appear in history
        let hist = mgr.history();
        assert_eq!(hist.len(), 1);
        assert_eq!(hist[0].id, id);
        assert!(matches!(hist[0].status, ApprovalStatus::Rejected { .. }));
    }

    #[test]
    fn expired_approval_cannot_be_approved() {
        // Create a manager with 0-second TTL so approvals expire immediately
        let mgr = HitlManager::new(10, 0, 100, b"test-secret-key-32bytes-padding!".to_vec());
        let id = mgr
            .create_approval(
                "agent-3",
                "hash-exp",
                OversightLevel::Approvable,
                "test",
                vec![],
            )
            .unwrap();
        // Sleep to ensure the instant has advanced past expires_at
        std::thread::sleep(Duration::from_millis(10));
        let result = mgr.approve(&id, "someone");
        assert_eq!(result, Err(HitlError::Expired));
    }

    #[test]
    fn verify_resume_token_valid() {
        let mgr = manager();
        let id = mgr
            .create_approval(
                "agent-4",
                "hash-verify",
                OversightLevel::Approvable,
                "test",
                vec![],
            )
            .unwrap();
        let token = mgr.approve(&id, "ops").unwrap();
        let result = mgr.verify_resume_token(&token, "hash-verify");
        assert!(result.is_ok());
    }

    #[test]
    fn verify_resume_token_wrong_hash() {
        let mgr = manager();
        let id = mgr
            .create_approval(
                "agent-5",
                "hash-original",
                OversightLevel::Approvable,
                "test",
                vec![],
            )
            .unwrap();
        let token = mgr.approve(&id, "ops").unwrap();
        let result = mgr.verify_resume_token(&token, "hash-tampered");
        assert_eq!(result, Err(HitlError::RequestMismatch));
    }

    #[test]
    fn max_pending_cap_enforced() {
        let mgr = HitlManager::new(2, 3600, 100, b"test-secret-key-32bytes-padding!".to_vec());
        let id1 = mgr.create_approval("a", "h1", OversightLevel::Approvable, "r", vec![]);
        let id2 = mgr.create_approval("a", "h2", OversightLevel::Approvable, "r", vec![]);
        let id3 = mgr.create_approval("a", "h3", OversightLevel::Approvable, "r", vec![]);
        assert!(id1.is_some());
        assert!(id2.is_some());
        // Third should be rejected because capacity is 2
        assert!(id3.is_none());
        assert_eq!(mgr.pending.len(), 2);
    }

    #[test]
    fn reap_expired_cleans_up() {
        let mgr = HitlManager::new(10, 0, 100, b"test-secret-key-32bytes-padding!".to_vec());
        mgr.create_approval("a", "h1", OversightLevel::Approvable, "r", vec![]);
        mgr.create_approval("a", "h2", OversightLevel::Approvable, "r", vec![]);
        std::thread::sleep(Duration::from_millis(10));
        let reaped = mgr.reap_expired();
        assert_eq!(reaped, 2);
        assert_eq!(mgr.pending.len(), 0);
        // Both should now be in history as Expired
        let hist = mgr.history();
        assert!(hist
            .iter()
            .all(|e| matches!(e.status, ApprovalStatus::Expired)));
    }

    #[test]
    fn oversight_level_from_risk() {
        assert_eq!(
            HitlManager::oversight_for_risk(0.95),
            OversightLevel::Supervised
        );
        assert_eq!(
            HitlManager::oversight_for_risk(0.90),
            OversightLevel::Supervised
        );
        assert_eq!(
            HitlManager::oversight_for_risk(0.75),
            OversightLevel::Approvable
        );
        assert_eq!(
            HitlManager::oversight_for_risk(0.70),
            OversightLevel::Approvable
        );
        assert_eq!(
            HitlManager::oversight_for_risk(0.55),
            OversightLevel::Advisable
        );
        assert_eq!(
            HitlManager::oversight_for_risk(0.50),
            OversightLevel::Advisable
        );
        assert_eq!(
            HitlManager::oversight_for_risk(0.35),
            OversightLevel::Observable
        );
        assert_eq!(
            HitlManager::oversight_for_risk(0.30),
            OversightLevel::Observable
        );
        assert_eq!(
            HitlManager::oversight_for_risk(0.10),
            OversightLevel::BlackBox
        );
        assert_eq!(
            HitlManager::oversight_for_risk(0.0),
            OversightLevel::BlackBox
        );
    }

    #[test]
    fn consume_moves_to_history() {
        let mgr = manager();
        let id = mgr
            .create_approval("a", "h", OversightLevel::Approvable, "r", vec![])
            .unwrap();
        mgr.approve(&id, "ops").unwrap();
        let consumed = mgr.consume(&id);
        assert!(consumed.is_some());
        // Should be removed from pending
        assert_eq!(mgr.pending.len(), 0);
        // Should appear in history
        let hist = mgr.history();
        assert_eq!(hist.len(), 1);
        assert_eq!(hist[0].id, id);
    }

    #[test]
    fn double_approve_fails() {
        let mgr = manager();
        let id = mgr
            .create_approval("a", "h", OversightLevel::Approvable, "r", vec![])
            .unwrap();
        mgr.approve(&id, "ops1").unwrap();
        // Second approve should fail: already decided
        let result = mgr.approve(&id, "ops2");
        assert_eq!(result, Err(HitlError::AlreadyDecided));
    }

    #[test]
    fn verify_consumed_token_via_history_index() {
        let mgr = manager();
        let id = mgr
            .create_approval("a", "h", OversightLevel::Approvable, "r", vec![])
            .unwrap();
        let token = mgr.approve(&id, "ops").unwrap();
        // Consume moves from pending to history
        mgr.consume(&id);
        // Token should still verify via history_index (O(1) lookup)
        assert!(mgr.verify_resume_token(&token, "h").is_ok());
    }

    #[test]
    fn stats_use_atomic_counters() {
        let mgr = manager();
        // Create and approve
        let id1 = mgr
            .create_approval("a", "h1", OversightLevel::Approvable, "r", vec![])
            .unwrap();
        mgr.approve(&id1, "ops").unwrap();
        mgr.consume(&id1);
        // Create and reject
        let id2 = mgr
            .create_approval("a", "h2", OversightLevel::Approvable, "r", vec![])
            .unwrap();
        mgr.reject(&id2, "ops", "no").unwrap();
        // Stats should reflect both
        let stats = mgr.stats();
        assert_eq!(stats.total_approved, 1);
        assert_eq!(stats.total_rejected, 1);
        assert_eq!(stats.total_expired, 0);
        assert_eq!(stats.pending_count, 0);
    }

    #[test]
    fn seal_and_verify_token() {
        let mgr = manager();
        let id = mgr
            .create_approval(
                "agent-seal",
                "hash-seal",
                OversightLevel::Approvable,
                "test",
                vec![],
            )
            .unwrap();
        let token = mgr.approve(&id, "ops").unwrap();
        let sealed = mgr.seal_token(&token);

        // Verify succeeds
        let verified = mgr.verify_sealed_token(&sealed).unwrap();
        assert_eq!(verified.approval_id, token.approval_id);
    }

    #[test]
    fn tampered_token_rejected() {
        let mgr = manager();
        let id = mgr
            .create_approval(
                "agent-tamper",
                "hash-tamper",
                OversightLevel::Approvable,
                "test",
                vec![],
            )
            .unwrap();
        let token = mgr.approve(&id, "ops").unwrap();
        let mut sealed = mgr.seal_token(&token);

        // Tamper with the token data
        sealed.token.agent_id = "evil-agent".to_string();

        // Verification should fail
        assert_eq!(
            mgr.verify_sealed_token(&sealed),
            Err(HitlError::InvalidToken)
        );
    }

    #[test]
    fn different_server_secret_rejects_token() {
        let mgr1 = HitlManager::new(10, 3600, 100, b"secret-one-padding-padding-pad!!".to_vec());
        let mgr2 = HitlManager::new(10, 3600, 100, b"secret-two-padding-padding-pad!!".to_vec());

        let id = mgr1
            .create_approval("a", "h", OversightLevel::Approvable, "r", vec![])
            .unwrap();
        let token = mgr1.approve(&id, "ops").unwrap();
        let sealed = mgr1.seal_token(&token);

        // Different server can't verify
        assert_eq!(
            mgr2.verify_sealed_token(&sealed),
            Err(HitlError::InvalidToken)
        );
    }
}
