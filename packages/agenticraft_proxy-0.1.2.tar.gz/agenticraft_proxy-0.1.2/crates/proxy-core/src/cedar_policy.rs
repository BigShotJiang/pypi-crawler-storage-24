// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Cedar/OPA-inspired lightweight RBAC/ABAC policy engine (F14).
//!
//! Provides a deny-overrides policy evaluation model with attribute-based
//! conditions. Rules are evaluated in priority order (highest first); any
//! matching `Deny` rule overrides all `Allow` rules regardless of priority.
//!
//! This is **not** the full Cedar policy language — it is a purpose-built
//! subset covering the RBAC/ABAC needs of the proxy without pulling in the
//! `cedar-policy` crate.

use std::collections::HashMap;
use std::sync::atomic::{AtomicU64, Ordering};

use parking_lot::RwLock;

// ---------------------------------------------------------------------------
// PolicyEffect
// ---------------------------------------------------------------------------

/// The effect of a policy rule when it matches a request.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub enum PolicyEffect {
    /// The request is allowed.
    Allow,
    /// The request is denied.
    Deny,
}

// ---------------------------------------------------------------------------
// AttributeValue
// ---------------------------------------------------------------------------

/// A typed attribute value used in policy condition evaluation.
#[derive(Debug, Clone, PartialEq)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub enum AttributeValue {
    /// A string value.
    String(String),
    /// A numeric value.
    Number(f64),
    /// A boolean value.
    Bool(bool),
    /// A list of strings.
    StringList(Vec<String>),
}

// ---------------------------------------------------------------------------
// PolicyCondition
// ---------------------------------------------------------------------------

/// An attribute-based condition that must hold for a rule to match.
///
/// Missing attributes cause the condition to evaluate to `false` (fail-closed).
#[derive(Debug, Clone, PartialEq)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub enum PolicyCondition {
    /// Attribute exists and equals the given string.
    StringEquals { attribute: String, value: String },
    /// Attribute exists and does **not** equal the given string.
    StringNotEquals { attribute: String, value: String },
    /// Attribute exists and is contained in the given set of strings.
    StringIn {
        attribute: String,
        values: Vec<String>,
    },
    /// Attribute exists, is numeric, and is greater than the given value.
    NumericGreaterThan { attribute: String, value: f64 },
    /// Attribute exists, is numeric, and is less than the given value.
    NumericLessThan { attribute: String, value: f64 },
    /// Attribute key exists (any type).
    Exists { attribute: String },
    /// Logical negation.
    Not(Box<PolicyCondition>),
    /// All sub-conditions must be true.
    And(Vec<PolicyCondition>),
    /// At least one sub-condition must be true.
    Or(Vec<PolicyCondition>),
}

// ---------------------------------------------------------------------------
// PolicyRule
// ---------------------------------------------------------------------------

/// A single policy rule with optional principal/action/resource constraints and
/// attribute-based conditions.
#[derive(Debug, Clone, PartialEq)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct PolicyRule {
    /// Unique identifier for this rule.
    pub rule_id: String,
    /// Human-readable description.
    pub description: String,
    /// The effect when this rule matches.
    pub effect: PolicyEffect,
    /// Matching agent IDs or roles. `None` matches any principal.
    pub principals: Option<Vec<String>>,
    /// Matching tool names or operations. `None` matches any action.
    pub actions: Option<Vec<String>>,
    /// Matching providers or endpoints. `None` matches any resource.
    pub resources: Option<Vec<String>>,
    /// All conditions must be true for the rule to apply.
    pub conditions: Vec<PolicyCondition>,
    /// Higher priority rules are evaluated first.
    pub priority: u32,
}

// ---------------------------------------------------------------------------
// PolicyRequest
// ---------------------------------------------------------------------------

/// A request to be evaluated against the policy engine.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct PolicyRequest {
    /// The agent ID or role making the request.
    pub principal: String,
    /// The tool name or operation being requested.
    pub action: String,
    /// The provider or endpoint being accessed.
    pub resource: String,
    /// Context attributes for condition evaluation.
    pub attributes: HashMap<String, AttributeValue>,
}

// ---------------------------------------------------------------------------
// PolicyDecision
// ---------------------------------------------------------------------------

/// The outcome of evaluating a [`PolicyRequest`] against the engine.
#[derive(Debug, Clone, PartialEq)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct PolicyDecision {
    /// The resulting effect.
    pub effect: PolicyEffect,
    /// The `rule_id` of the rule that determined the outcome, if any.
    pub matched_rule: Option<String>,
    /// Human-readable explanation.
    pub reason: String,
}

// ---------------------------------------------------------------------------
// PolicyStats
// ---------------------------------------------------------------------------

/// Summary statistics from [`PolicyEngine::stats`].
#[derive(Debug, Clone, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct PolicyStats {
    /// Number of rules loaded.
    pub total_rules: usize,
    /// Total number of evaluations performed.
    pub total_evaluations: u64,
    /// Total number of Allow decisions.
    pub total_allowed: u64,
    /// Total number of Deny decisions.
    pub total_denied: u64,
}

// ---------------------------------------------------------------------------
// Condition evaluation
// ---------------------------------------------------------------------------

/// Evaluate a [`PolicyCondition`] against a set of attributes.
///
/// Missing attributes cause the condition to evaluate to `false` (fail-closed).
pub fn evaluate_condition(
    condition: &PolicyCondition,
    attributes: &HashMap<String, AttributeValue>,
) -> bool {
    match condition {
        PolicyCondition::StringEquals { attribute, value } => {
            matches!(attributes.get(attribute), Some(AttributeValue::String(v)) if v == value)
        }
        PolicyCondition::StringNotEquals { attribute, value } => {
            matches!(attributes.get(attribute), Some(AttributeValue::String(v)) if v != value)
        }
        PolicyCondition::StringIn { attribute, values } => {
            matches!(
                attributes.get(attribute),
                Some(AttributeValue::String(v)) if values.contains(v)
            )
        }
        PolicyCondition::NumericGreaterThan { attribute, value } => {
            matches!(
                attributes.get(attribute),
                Some(AttributeValue::Number(n)) if *n > *value
            )
        }
        PolicyCondition::NumericLessThan { attribute, value } => {
            matches!(
                attributes.get(attribute),
                Some(AttributeValue::Number(n)) if *n < *value
            )
        }
        PolicyCondition::Exists { attribute } => attributes.contains_key(attribute),
        PolicyCondition::Not(inner) => !evaluate_condition(inner, attributes),
        PolicyCondition::And(conditions) => {
            conditions.iter().all(|c| evaluate_condition(c, attributes))
        }
        PolicyCondition::Or(conditions) => {
            conditions.iter().any(|c| evaluate_condition(c, attributes))
        }
    }
}

// ---------------------------------------------------------------------------
// PolicyEngine
// ---------------------------------------------------------------------------

/// RBAC/ABAC policy engine with deny-overrides evaluation.
///
/// Rules are stored sorted by priority (descending). On each evaluation every
/// matching rule is collected — if **any** matching rule has [`PolicyEffect::Deny`],
/// the request is denied regardless of Allow rules. If no rules match, the
/// configured `default_effect` applies.
pub struct PolicyEngine {
    /// Rules sorted by priority descending.
    rules: RwLock<Vec<PolicyRule>>,
    /// Default effect when no rules match.
    default_effect: PolicyEffect,
    /// Counter: total evaluations.
    total_evaluations: AtomicU64,
    /// Counter: total Allow decisions.
    total_allowed: AtomicU64,
    /// Counter: total Deny decisions.
    total_denied: AtomicU64,
}

impl PolicyEngine {
    /// Create a new engine with the given default effect.
    pub fn new(default_effect: PolicyEffect) -> Self {
        Self {
            rules: RwLock::new(Vec::new()),
            default_effect,
            total_evaluations: AtomicU64::new(0),
            total_allowed: AtomicU64::new(0),
            total_denied: AtomicU64::new(0),
        }
    }

    /// Add a rule to the engine. Re-sorts by priority (descending).
    pub fn add_rule(&self, rule: PolicyRule) {
        let mut rules = self.rules.write();
        rules.push(rule);
        rules.sort_unstable_by_key(|r| std::cmp::Reverse(r.priority));
    }

    /// Remove a rule by `rule_id`. Returns `true` if a rule was removed.
    pub fn remove_rule(&self, rule_id: &str) -> bool {
        let mut rules = self.rules.write();
        let len_before = rules.len();
        rules.retain(|r| r.rule_id != rule_id);
        rules.len() < len_before
    }

    /// Evaluate a request against all rules.
    ///
    /// **Deny-overrides**: if any matching rule has `Deny` effect, the decision
    /// is `Deny`. Otherwise, if at least one `Allow` rule matches, the decision
    /// is `Allow`. If no rules match, the engine's `default_effect` is used.
    pub fn evaluate(&self, request: &PolicyRequest) -> PolicyDecision {
        self.total_evaluations.fetch_add(1, Ordering::Relaxed);

        let rules = self.rules.read();

        let mut first_deny: Option<&PolicyRule> = None;
        let mut first_allow: Option<&PolicyRule> = None;

        for rule in rules.iter() {
            if !Self::matches_rule(rule, request) {
                continue;
            }

            match rule.effect {
                PolicyEffect::Deny => {
                    // Deny overrides everything — no need to check remaining rules.
                    first_deny = Some(rule);
                    break;
                }
                PolicyEffect::Allow => {
                    if first_allow.is_none() {
                        first_allow = Some(rule);
                    }
                }
            }
        }

        let decision = if let Some(deny_rule) = first_deny {
            // Deny overrides any Allow.
            PolicyDecision {
                effect: PolicyEffect::Deny,
                matched_rule: Some(deny_rule.rule_id.clone()),
                reason: format!(
                    "Denied by rule '{}': {}",
                    deny_rule.rule_id, deny_rule.description
                ),
            }
        } else if let Some(allow_rule) = first_allow {
            PolicyDecision {
                effect: PolicyEffect::Allow,
                matched_rule: Some(allow_rule.rule_id.clone()),
                reason: format!(
                    "Allowed by rule '{}': {}",
                    allow_rule.rule_id, allow_rule.description
                ),
            }
        } else {
            PolicyDecision {
                effect: self.default_effect,
                matched_rule: None,
                reason: format!(
                    "No matching rules; default effect is {:?}",
                    self.default_effect
                ),
            }
        };

        match decision.effect {
            PolicyEffect::Allow => {
                self.total_allowed.fetch_add(1, Ordering::Relaxed);
            }
            PolicyEffect::Deny => {
                self.total_denied.fetch_add(1, Ordering::Relaxed);
            }
        }

        decision
    }

    /// Summary statistics.
    pub fn stats(&self) -> PolicyStats {
        PolicyStats {
            total_rules: self.rules.read().len(),
            total_evaluations: self.total_evaluations.load(Ordering::Relaxed),
            total_allowed: self.total_allowed.load(Ordering::Relaxed),
            total_denied: self.total_denied.load(Ordering::Relaxed),
        }
    }

    // -----------------------------------------------------------------------
    // Internal helpers
    // -----------------------------------------------------------------------

    /// Check whether a rule matches the given request (principal, action,
    /// resource, and all conditions).
    fn matches_rule(rule: &PolicyRule, request: &PolicyRequest) -> bool {
        // Principal match.
        if let Some(ref principals) = rule.principals {
            if !principals.iter().any(|p| p == &request.principal) {
                return false;
            }
        }

        // Action match.
        if let Some(ref actions) = rule.actions {
            if !actions.iter().any(|a| a == &request.action) {
                return false;
            }
        }

        // Resource match.
        if let Some(ref resources) = rule.resources {
            if !resources.iter().any(|r| r == &request.resource) {
                return false;
            }
        }

        // All conditions must hold.
        rule.conditions
            .iter()
            .all(|c| evaluate_condition(c, &request.attributes))
    }
}

impl Default for PolicyEngine {
    /// Default engine denies when no rules match (deny-by-default).
    fn default() -> Self {
        Self::new(PolicyEffect::Deny)
    }
}

// ---------------------------------------------------------------------------
// Unit tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    /// Helper: build a request with the given principal/action/resource and
    /// optional attributes.
    fn request(
        principal: &str,
        action: &str,
        resource: &str,
        attrs: Vec<(&str, AttributeValue)>,
    ) -> PolicyRequest {
        PolicyRequest {
            principal: principal.into(),
            action: action.into(),
            resource: resource.into(),
            attributes: attrs.into_iter().map(|(k, v)| (k.to_string(), v)).collect(),
        }
    }

    #[test]
    fn allow_rule_matches_and_allows() {
        let engine = PolicyEngine::new(PolicyEffect::Deny);
        engine.add_rule(PolicyRule {
            rule_id: "allow-read".into(),
            description: "Allow agents to read openai".into(),
            effect: PolicyEffect::Allow,
            principals: Some(vec!["agent-1".into()]),
            actions: Some(vec!["read".into()]),
            resources: Some(vec!["openai".into()]),
            conditions: vec![],
            priority: 10,
        });

        let decision = engine.evaluate(&request("agent-1", "read", "openai", vec![]));

        assert_eq!(decision.effect, PolicyEffect::Allow);
        assert_eq!(decision.matched_rule, Some("allow-read".into()));
    }

    #[test]
    fn deny_rule_overrides_allow_rule() {
        let engine = PolicyEngine::new(PolicyEffect::Deny);

        // Lower-priority Allow rule.
        engine.add_rule(PolicyRule {
            rule_id: "allow-all".into(),
            description: "Allow everything".into(),
            effect: PolicyEffect::Allow,
            principals: None,
            actions: None,
            resources: None,
            conditions: vec![],
            priority: 1,
        });

        // Higher-priority Deny rule for a specific action.
        engine.add_rule(PolicyRule {
            rule_id: "deny-delete".into(),
            description: "Deny delete operations".into(),
            effect: PolicyEffect::Deny,
            principals: None,
            actions: Some(vec!["delete".into()]),
            resources: None,
            conditions: vec![],
            priority: 100,
        });

        // Delete should be denied even though the Allow-all rule also matches.
        let decision = engine.evaluate(&request("agent-1", "delete", "openai", vec![]));
        assert_eq!(decision.effect, PolicyEffect::Deny);
        assert_eq!(decision.matched_rule, Some("deny-delete".into()));

        // Read should still be allowed (only the Allow-all matches).
        let decision = engine.evaluate(&request("agent-1", "read", "openai", vec![]));
        assert_eq!(decision.effect, PolicyEffect::Allow);
    }

    #[test]
    fn condition_based_policy() {
        let engine = PolicyEngine::new(PolicyEffect::Deny);

        engine.add_rule(PolicyRule {
            rule_id: "allow-admin".into(),
            description: "Allow admin role".into(),
            effect: PolicyEffect::Allow,
            principals: None,
            actions: None,
            resources: None,
            conditions: vec![PolicyCondition::StringEquals {
                attribute: "role".into(),
                value: "admin".into(),
            }],
            priority: 10,
        });

        // Request with role=admin → allowed.
        let decision = engine.evaluate(&request(
            "agent-1",
            "write",
            "openai",
            vec![("role", AttributeValue::String("admin".into()))],
        ));
        assert_eq!(decision.effect, PolicyEffect::Allow);

        // Request with role=viewer → no match → default deny.
        let decision = engine.evaluate(&request(
            "agent-1",
            "write",
            "openai",
            vec![("role", AttributeValue::String("viewer".into()))],
        ));
        assert_eq!(decision.effect, PolicyEffect::Deny);
        assert_eq!(decision.matched_rule, None);

        // Request with missing role attribute → condition fails (fail-closed) → default deny.
        let decision = engine.evaluate(&request("agent-1", "write", "openai", vec![]));
        assert_eq!(decision.effect, PolicyEffect::Deny);
        assert_eq!(decision.matched_rule, None);
    }

    #[test]
    fn no_matching_rules_uses_default_effect() {
        // Default Allow engine.
        let engine = PolicyEngine::new(PolicyEffect::Allow);

        engine.add_rule(PolicyRule {
            rule_id: "specific-rule".into(),
            description: "Only matches agent-99".into(),
            effect: PolicyEffect::Deny,
            principals: Some(vec!["agent-99".into()]),
            actions: None,
            resources: None,
            conditions: vec![],
            priority: 10,
        });

        // agent-1 does not match any rule → default Allow.
        let decision = engine.evaluate(&request("agent-1", "read", "openai", vec![]));
        assert_eq!(decision.effect, PolicyEffect::Allow);
        assert_eq!(decision.matched_rule, None);

        // Default Deny engine.
        let engine_deny = PolicyEngine::default();
        let decision = engine_deny.evaluate(&request("agent-1", "read", "openai", vec![]));
        assert_eq!(decision.effect, PolicyEffect::Deny);
        assert_eq!(decision.matched_rule, None);
    }

    #[test]
    fn priority_ordering() {
        let engine = PolicyEngine::new(PolicyEffect::Deny);

        // Two Allow rules for the same request, different priorities.
        engine.add_rule(PolicyRule {
            rule_id: "low-priority".into(),
            description: "Low priority allow".into(),
            effect: PolicyEffect::Allow,
            principals: None,
            actions: None,
            resources: None,
            conditions: vec![],
            priority: 1,
        });

        engine.add_rule(PolicyRule {
            rule_id: "high-priority".into(),
            description: "High priority allow".into(),
            effect: PolicyEffect::Allow,
            principals: None,
            actions: None,
            resources: None,
            conditions: vec![],
            priority: 100,
        });

        // The highest-priority matching rule should be reported.
        let decision = engine.evaluate(&request("agent-1", "read", "openai", vec![]));
        assert_eq!(decision.effect, PolicyEffect::Allow);
        assert_eq!(decision.matched_rule, Some("high-priority".into()));
    }

    #[test]
    fn complex_conditions_and_or_not() {
        let engine = PolicyEngine::new(PolicyEffect::Deny);

        // Allow if: (role = "admin" OR role = "operator") AND NOT (environment = "production")
        engine.add_rule(PolicyRule {
            rule_id: "complex-rule".into(),
            description: "Admin/operator access except production".into(),
            effect: PolicyEffect::Allow,
            principals: None,
            actions: None,
            resources: None,
            conditions: vec![PolicyCondition::And(vec![
                PolicyCondition::Or(vec![
                    PolicyCondition::StringEquals {
                        attribute: "role".into(),
                        value: "admin".into(),
                    },
                    PolicyCondition::StringEquals {
                        attribute: "role".into(),
                        value: "operator".into(),
                    },
                ]),
                PolicyCondition::Not(Box::new(PolicyCondition::StringEquals {
                    attribute: "environment".into(),
                    value: "production".into(),
                })),
            ])],
            priority: 10,
        });

        // admin + staging → allowed.
        let decision = engine.evaluate(&request(
            "agent-1",
            "deploy",
            "cluster",
            vec![
                ("role", AttributeValue::String("admin".into())),
                ("environment", AttributeValue::String("staging".into())),
            ],
        ));
        assert_eq!(decision.effect, PolicyEffect::Allow);

        // operator + staging → allowed.
        let decision = engine.evaluate(&request(
            "agent-1",
            "deploy",
            "cluster",
            vec![
                ("role", AttributeValue::String("operator".into())),
                ("environment", AttributeValue::String("staging".into())),
            ],
        ));
        assert_eq!(decision.effect, PolicyEffect::Allow);

        // admin + production → denied (NOT production fails).
        let decision = engine.evaluate(&request(
            "agent-1",
            "deploy",
            "cluster",
            vec![
                ("role", AttributeValue::String("admin".into())),
                ("environment", AttributeValue::String("production".into())),
            ],
        ));
        assert_eq!(decision.effect, PolicyEffect::Deny);
        assert_eq!(decision.matched_rule, None);

        // viewer + staging → denied (neither admin nor operator).
        let decision = engine.evaluate(&request(
            "agent-1",
            "deploy",
            "cluster",
            vec![
                ("role", AttributeValue::String("viewer".into())),
                ("environment", AttributeValue::String("staging".into())),
            ],
        ));
        assert_eq!(decision.effect, PolicyEffect::Deny);
        assert_eq!(decision.matched_rule, None);
    }

    #[test]
    fn stats_track_evaluations() {
        let engine = PolicyEngine::new(PolicyEffect::Deny);

        engine.add_rule(PolicyRule {
            rule_id: "allow-read".into(),
            description: "Allow reads".into(),
            effect: PolicyEffect::Allow,
            principals: None,
            actions: Some(vec!["read".into()]),
            resources: None,
            conditions: vec![],
            priority: 10,
        });

        // Two reads (allowed) + one write (denied by default).
        engine.evaluate(&request("a", "read", "r", vec![]));
        engine.evaluate(&request("b", "read", "r", vec![]));
        engine.evaluate(&request("c", "write", "r", vec![]));

        let stats = engine.stats();
        assert_eq!(stats.total_rules, 1);
        assert_eq!(stats.total_evaluations, 3);
        assert_eq!(stats.total_allowed, 2);
        assert_eq!(stats.total_denied, 1);
    }

    #[test]
    fn remove_rule_works() {
        let engine = PolicyEngine::new(PolicyEffect::Deny);

        engine.add_rule(PolicyRule {
            rule_id: "temp-rule".into(),
            description: "Temporary".into(),
            effect: PolicyEffect::Allow,
            principals: None,
            actions: None,
            resources: None,
            conditions: vec![],
            priority: 10,
        });

        assert_eq!(engine.stats().total_rules, 1);

        let removed = engine.remove_rule("temp-rule");
        assert!(removed);
        assert_eq!(engine.stats().total_rules, 0);

        // Removing non-existent rule returns false.
        let removed = engine.remove_rule("nonexistent");
        assert!(!removed);
    }

    #[test]
    fn numeric_and_exists_conditions() {
        let engine = PolicyEngine::new(PolicyEffect::Deny);

        engine.add_rule(PolicyRule {
            rule_id: "cost-limit".into(),
            description: "Allow if cost under budget and token exists".into(),
            effect: PolicyEffect::Allow,
            principals: None,
            actions: None,
            resources: None,
            conditions: vec![
                PolicyCondition::NumericLessThan {
                    attribute: "cost".into(),
                    value: 100.0,
                },
                PolicyCondition::Exists {
                    attribute: "auth_token".into(),
                },
            ],
            priority: 10,
        });

        // cost=50, auth_token exists → allowed.
        let decision = engine.evaluate(&request(
            "agent-1",
            "query",
            "openai",
            vec![
                ("cost", AttributeValue::Number(50.0)),
                ("auth_token", AttributeValue::String("tok-abc".into())),
            ],
        ));
        assert_eq!(decision.effect, PolicyEffect::Allow);

        // cost=200 → NumericLessThan fails → denied.
        let decision = engine.evaluate(&request(
            "agent-1",
            "query",
            "openai",
            vec![
                ("cost", AttributeValue::Number(200.0)),
                ("auth_token", AttributeValue::String("tok-abc".into())),
            ],
        ));
        assert_eq!(decision.effect, PolicyEffect::Deny);

        // Missing auth_token → Exists fails → denied.
        let decision = engine.evaluate(&request(
            "agent-1",
            "query",
            "openai",
            vec![("cost", AttributeValue::Number(50.0))],
        ));
        assert_eq!(decision.effect, PolicyEffect::Deny);
    }

    #[test]
    fn string_in_and_not_equals_conditions() {
        let engine = PolicyEngine::new(PolicyEffect::Deny);

        engine.add_rule(PolicyRule {
            rule_id: "tier-check".into(),
            description: "Allow premium tiers except blocked region".into(),
            effect: PolicyEffect::Allow,
            principals: None,
            actions: None,
            resources: None,
            conditions: vec![
                PolicyCondition::StringIn {
                    attribute: "tier".into(),
                    values: vec!["gold".into(), "platinum".into()],
                },
                PolicyCondition::StringNotEquals {
                    attribute: "region".into(),
                    value: "restricted".into(),
                },
            ],
            priority: 10,
        });

        // gold + us-east → allowed.
        let decision = engine.evaluate(&request(
            "agent-1",
            "query",
            "api",
            vec![
                ("tier", AttributeValue::String("gold".into())),
                ("region", AttributeValue::String("us-east".into())),
            ],
        ));
        assert_eq!(decision.effect, PolicyEffect::Allow);

        // silver → StringIn fails → denied.
        let decision = engine.evaluate(&request(
            "agent-1",
            "query",
            "api",
            vec![
                ("tier", AttributeValue::String("silver".into())),
                ("region", AttributeValue::String("us-east".into())),
            ],
        ));
        assert_eq!(decision.effect, PolicyEffect::Deny);

        // gold + restricted → StringNotEquals fails → denied.
        let decision = engine.evaluate(&request(
            "agent-1",
            "query",
            "api",
            vec![
                ("tier", AttributeValue::String("gold".into())),
                ("region", AttributeValue::String("restricted".into())),
            ],
        ));
        assert_eq!(decision.effect, PolicyEffect::Deny);
    }
}
