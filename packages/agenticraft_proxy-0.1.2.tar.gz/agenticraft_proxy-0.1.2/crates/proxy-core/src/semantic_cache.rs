// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Semantic cache with embedding-based similarity search (F1).
//!
//! Two-level lookup:
//! 1. Exact match via SHA-256 hash (existing cache, ~10ns)
//! 2. Embedding nearest-neighbor (~1-5ms) via cosine similarity
//!
//! Embeddings are provided externally via the `EmbeddingProvider` trait.
//! This module handles only the similarity search and cache management.

use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{Duration, Instant};

use parking_lot::RwLock;

/// Trait for embedding providers (API-based or local).
///
/// Implementations must be `Send + Sync` for use in async contexts.
pub trait EmbeddingProvider: Send + Sync {
    /// Compute an embedding vector for the given text.
    ///
    /// Returns an error string on failure — the caller should fall through
    /// to the provider without caching on error.
    fn embed(&self, text: &str) -> Result<Vec<f32>, String>;
}

/// A cached response with its embedding vector.
#[derive(Debug, Clone)]
pub struct SemanticCacheEntry {
    /// The embedding vector of the original request.
    pub embedding: Vec<f32>,
    /// The cached response bytes.
    pub response: Vec<u8>,
    /// When this entry was inserted.
    pub inserted_at: Instant,
    /// Time-to-live for this entry.
    pub ttl: Duration,
    /// SHA-256 hash of the original request (for dedup).
    pub request_hash: String,
}

/// Semantic cache with configurable similarity threshold.
pub struct SemanticCache {
    /// Cached entries with their embeddings.
    entries: RwLock<Vec<SemanticCacheEntry>>,
    /// Maximum number of entries (evict oldest when full).
    max_entries: usize,
    /// Cosine similarity threshold for a "hit" (0.0 - 1.0).
    threshold: f32,
    /// Cache hit counter.
    hits: AtomicU64,
    /// Cache miss counter.
    misses: AtomicU64,
}

/// Result of a semantic cache lookup.
#[derive(Debug)]
pub enum CacheLookup {
    /// Exact semantic match found (similarity >= threshold).
    Hit { response: Vec<u8>, similarity: f32 },
    /// No match above threshold.
    Miss,
}

impl SemanticCache {
    /// Create a new semantic cache.
    pub fn new(max_entries: usize, threshold: f32) -> Self {
        Self {
            entries: RwLock::new(Vec::with_capacity(max_entries)),
            max_entries,
            threshold: threshold.clamp(0.0, 1.0),
            hits: AtomicU64::new(0),
            misses: AtomicU64::new(0),
        }
    }

    /// Search for a semantically similar cached response.
    ///
    /// Returns the closest match if similarity >= threshold and the entry
    /// hasn't expired. Only clones the response of the best match (not all candidates).
    pub fn search(&self, query_embedding: &[f32]) -> CacheLookup {
        let entries = self.entries.read();
        let now = Instant::now();

        let mut best_similarity: f32 = -1.0;
        let mut best_idx: Option<usize> = None;

        for (idx, entry) in entries.iter().enumerate() {
            // Skip expired entries
            if now.duration_since(entry.inserted_at) > entry.ttl {
                continue;
            }

            let sim = cosine_similarity(query_embedding, &entry.embedding);
            if sim > best_similarity {
                best_similarity = sim;
                best_idx = Some(idx);
            }
        }

        if best_similarity >= self.threshold {
            if let Some(idx) = best_idx {
                self.hits.fetch_add(1, Ordering::Relaxed);
                // Only clone the winning response, not all candidates
                let response = entries[idx].response.clone();
                return CacheLookup::Hit {
                    response,
                    similarity: best_similarity,
                };
            }
            self.misses.fetch_add(1, Ordering::Relaxed);
            CacheLookup::Miss
        } else {
            self.misses.fetch_add(1, Ordering::Relaxed);
            CacheLookup::Miss
        }
    }

    /// Insert a new entry into the cache.
    ///
    /// Evicts the oldest entry if the cache is full.
    /// Deduplicates by request_hash (updates existing entry if found).
    pub fn insert(&self, entry: SemanticCacheEntry) {
        let mut entries = self.entries.write();

        // Dedup: replace existing entry with same request hash
        if let Some(pos) = entries
            .iter()
            .position(|e| e.request_hash == entry.request_hash)
        {
            entries[pos] = entry;
            return;
        }

        // Evict oldest if at capacity
        if entries.len() >= self.max_entries {
            // Find and remove the oldest entry
            if let Some(oldest_idx) = entries
                .iter()
                .enumerate()
                .min_by_key(|(_, e)| e.inserted_at)
                .map(|(i, _)| i)
            {
                entries.swap_remove(oldest_idx);
            }
        }

        entries.push(entry);
    }

    /// Remove expired entries from the cache.
    pub fn evict_expired(&self) -> usize {
        let mut entries = self.entries.write();
        let now = Instant::now();
        let before = entries.len();
        entries.retain(|e| now.duration_since(e.inserted_at) <= e.ttl);
        before - entries.len()
    }

    /// Get cache statistics.
    pub fn stats(&self) -> SemanticCacheStats {
        SemanticCacheStats {
            entries: self.entries.read().len() as u64,
            max_entries: self.max_entries as u64,
            hits: self.hits.load(Ordering::Relaxed),
            misses: self.misses.load(Ordering::Relaxed),
            threshold: self.threshold,
        }
    }

    /// Get current entry count.
    pub fn len(&self) -> usize {
        self.entries.read().len()
    }

    /// Check if cache is empty.
    pub fn is_empty(&self) -> bool {
        self.entries.read().is_empty()
    }
}

/// Semantic cache statistics.
#[derive(Debug, Clone)]
pub struct SemanticCacheStats {
    pub entries: u64,
    pub max_entries: u64,
    pub hits: u64,
    pub misses: u64,
    pub threshold: f32,
}

/// Compute cosine similarity between two vectors.
///
/// Returns a value in [-1.0, 1.0]. Returns 0.0 if either vector has zero magnitude.
pub fn cosine_similarity(a: &[f32], b: &[f32]) -> f32 {
    if a.len() != b.len() || a.is_empty() {
        return 0.0;
    }

    let mut dot = 0.0f32;
    let mut mag_a = 0.0f32;
    let mut mag_b = 0.0f32;

    for (x, y) in a.iter().zip(b.iter()) {
        dot += x * y;
        mag_a += x * x;
        mag_b += y * y;
    }

    let denom = mag_a.sqrt() * mag_b.sqrt();
    if denom == 0.0 {
        0.0
    } else {
        dot / denom
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_embedding(values: &[f32]) -> Vec<f32> {
        values.to_vec()
    }

    #[test]
    fn cosine_identical_vectors() {
        let a = make_embedding(&[1.0, 0.0, 0.0]);
        assert!((cosine_similarity(&a, &a) - 1.0).abs() < 1e-6);
    }

    #[test]
    fn cosine_orthogonal_vectors() {
        let a = make_embedding(&[1.0, 0.0]);
        let b = make_embedding(&[0.0, 1.0]);
        assert!(cosine_similarity(&a, &b).abs() < 1e-6);
    }

    #[test]
    fn cosine_opposite_vectors() {
        let a = make_embedding(&[1.0, 0.0]);
        let b = make_embedding(&[-1.0, 0.0]);
        assert!((cosine_similarity(&a, &b) + 1.0).abs() < 1e-6);
    }

    #[test]
    fn cosine_different_lengths() {
        let a = make_embedding(&[1.0, 0.0]);
        let b = make_embedding(&[1.0, 0.0, 0.0]);
        assert_eq!(cosine_similarity(&a, &b), 0.0);
    }

    #[test]
    fn cosine_empty_vectors() {
        assert_eq!(cosine_similarity(&[], &[]), 0.0);
    }

    #[test]
    fn exact_match_hit() {
        let cache = SemanticCache::new(100, 0.9);
        let emb = make_embedding(&[1.0, 0.0, 0.0]);

        cache.insert(SemanticCacheEntry {
            embedding: emb.clone(),
            response: b"cached response".to_vec(),
            inserted_at: Instant::now(),
            ttl: Duration::from_secs(300),
            request_hash: "hash1".into(),
        });

        match cache.search(&emb) {
            CacheLookup::Hit {
                response,
                similarity,
            } => {
                assert_eq!(response, b"cached response");
                assert!((similarity - 1.0).abs() < 1e-6);
            }
            CacheLookup::Miss => panic!("expected hit"),
        }
    }

    #[test]
    fn similar_embedding_hit() {
        let cache = SemanticCache::new(100, 0.92);
        let emb = make_embedding(&[1.0, 0.0, 0.0]);
        // Slightly different vector — high cosine similarity
        let query = make_embedding(&[0.99, 0.1, 0.0]);

        cache.insert(SemanticCacheEntry {
            embedding: emb,
            response: b"cached".to_vec(),
            inserted_at: Instant::now(),
            ttl: Duration::from_secs(300),
            request_hash: "hash1".into(),
        });

        match cache.search(&query) {
            CacheLookup::Hit { similarity, .. } => {
                assert!(
                    similarity > 0.92,
                    "similarity {} should be > 0.92",
                    similarity
                );
            }
            CacheLookup::Miss => panic!("expected hit for similar embedding"),
        }
    }

    #[test]
    fn dissimilar_embedding_miss() {
        let cache = SemanticCache::new(100, 0.92);
        let emb = make_embedding(&[1.0, 0.0, 0.0]);
        // Orthogonal vector — cosine similarity = 0
        let query = make_embedding(&[0.0, 1.0, 0.0]);

        cache.insert(SemanticCacheEntry {
            embedding: emb,
            response: b"cached".to_vec(),
            inserted_at: Instant::now(),
            ttl: Duration::from_secs(300),
            request_hash: "hash1".into(),
        });

        assert!(matches!(cache.search(&query), CacheLookup::Miss));
    }

    #[test]
    fn expired_entry_skipped() {
        let cache = SemanticCache::new(100, 0.9);
        let emb = make_embedding(&[1.0, 0.0, 0.0]);

        cache.insert(SemanticCacheEntry {
            embedding: emb.clone(),
            response: b"old".to_vec(),
            inserted_at: Instant::now() - Duration::from_secs(600),
            ttl: Duration::from_secs(300),
            request_hash: "hash1".into(),
        });

        assert!(matches!(cache.search(&emb), CacheLookup::Miss));
    }

    #[test]
    fn evicts_oldest_at_capacity() {
        let cache = SemanticCache::new(2, 0.9);

        for i in 0..3 {
            cache.insert(SemanticCacheEntry {
                embedding: make_embedding(&[i as f32, 0.0, 0.0]),
                response: format!("resp_{i}").into_bytes(),
                inserted_at: Instant::now() + Duration::from_millis(i * 10),
                ttl: Duration::from_secs(300),
                request_hash: format!("hash_{i}"),
            });
        }

        assert_eq!(cache.len(), 2);
    }

    #[test]
    fn dedup_by_request_hash() {
        let cache = SemanticCache::new(100, 0.9);
        let emb = make_embedding(&[1.0, 0.0, 0.0]);

        cache.insert(SemanticCacheEntry {
            embedding: emb.clone(),
            response: b"first".to_vec(),
            inserted_at: Instant::now(),
            ttl: Duration::from_secs(300),
            request_hash: "same_hash".into(),
        });
        cache.insert(SemanticCacheEntry {
            embedding: emb.clone(),
            response: b"second".to_vec(),
            inserted_at: Instant::now(),
            ttl: Duration::from_secs(300),
            request_hash: "same_hash".into(),
        });

        assert_eq!(cache.len(), 1);
        match cache.search(&emb) {
            CacheLookup::Hit { response, .. } => {
                assert_eq!(response, b"second");
            }
            CacheLookup::Miss => panic!("expected hit"),
        }
    }

    #[test]
    fn evict_expired_removes_stale() {
        let cache = SemanticCache::new(100, 0.9);

        // Insert one fresh and one expired
        cache.insert(SemanticCacheEntry {
            embedding: make_embedding(&[1.0, 0.0]),
            response: b"fresh".to_vec(),
            inserted_at: Instant::now(),
            ttl: Duration::from_secs(300),
            request_hash: "fresh".into(),
        });
        cache.insert(SemanticCacheEntry {
            embedding: make_embedding(&[0.0, 1.0]),
            response: b"expired".to_vec(),
            inserted_at: Instant::now() - Duration::from_secs(600),
            ttl: Duration::from_secs(300),
            request_hash: "expired".into(),
        });

        let evicted = cache.evict_expired();
        assert_eq!(evicted, 1);
        assert_eq!(cache.len(), 1);
    }

    #[test]
    fn stats_tracks_hits_and_misses() {
        let cache = SemanticCache::new(100, 0.9);
        let emb = make_embedding(&[1.0, 0.0, 0.0]);

        cache.insert(SemanticCacheEntry {
            embedding: emb.clone(),
            response: b"data".to_vec(),
            inserted_at: Instant::now(),
            ttl: Duration::from_secs(300),
            request_hash: "h".into(),
        });

        // One hit
        cache.search(&emb);
        // One miss
        cache.search(&make_embedding(&[0.0, 1.0, 0.0]));

        let stats = cache.stats();
        assert_eq!(stats.hits, 1);
        assert_eq!(stats.misses, 1);
    }

    /// Test that the EmbeddingProvider trait is object-safe.
    struct MockEmbedder;
    impl EmbeddingProvider for MockEmbedder {
        fn embed(&self, _text: &str) -> Result<Vec<f32>, String> {
            Ok(vec![1.0, 0.0, 0.0])
        }
    }

    #[test]
    fn embedding_provider_trait_object_safe() {
        let provider: Box<dyn EmbeddingProvider> = Box::new(MockEmbedder);
        let embedding = provider.embed("test").unwrap();
        assert_eq!(embedding, vec![1.0, 0.0, 0.0]);
    }
}
