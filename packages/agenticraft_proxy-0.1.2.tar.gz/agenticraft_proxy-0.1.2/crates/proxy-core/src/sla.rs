// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! SLA enforcement engine with cold-start buffering (F16).
//!
//! 6 SLA tiers: Critical (99.99%), Core (99.95%), Platform (99.9%),
//! Standard (99.5%), Background (99%), Utility (95%).
//!
//! Features:
//! - Pre-route: SLA hints constrain provider selection
//! - Post-response: Track latency/success, detect violations
//! - Cold-start buffering: Buffer requests when no healthy backends, with tier-based timeouts
//! - Violation actions: Alert, Reroute, Degrade, CircuitBreak, Escalate

use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{Duration, Instant};

use dashmap::DashMap;

/// SLA tier with availability target.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub enum SlaTier {
    Critical,   // 99.99% — max 52.6 min downtime/year
    Core,       // 99.95% — max 4.38 hr/year
    Platform,   // 99.9%  — max 8.76 hr/year
    Standard,   // 99.5%  — max 43.8 hr/year
    Background, // 99%    — max 87.6 hr/year
    Utility,    // 95%    — max 18.25 days/year
}

impl SlaTier {
    /// Target availability as a fraction (0.0 - 1.0).
    pub fn target_availability(&self) -> f64 {
        match self {
            SlaTier::Critical => 0.9999,
            SlaTier::Core => 0.9995,
            SlaTier::Platform => 0.999,
            SlaTier::Standard => 0.995,
            SlaTier::Background => 0.99,
            SlaTier::Utility => 0.95,
        }
    }

    /// Maximum acceptable latency (p99) in milliseconds.
    pub fn max_latency_ms(&self) -> u64 {
        match self {
            SlaTier::Critical => 200,
            SlaTier::Core => 500,
            SlaTier::Platform => 1000,
            SlaTier::Standard => 3000,
            SlaTier::Background => 10000,
            SlaTier::Utility => 30000,
        }
    }

    /// Cold-start buffer timeout in seconds.
    pub fn cold_start_timeout_secs(&self) -> u64 {
        match self {
            SlaTier::Critical => 30,
            SlaTier::Core => 60,
            SlaTier::Standard => 120,
            SlaTier::Platform => 120,
            SlaTier::Background => 300,
            SlaTier::Utility => 300,
        }
    }

    /// Maximum queue depth for inference routing integration.
    pub fn max_queue_depth(&self) -> u32 {
        match self {
            SlaTier::Critical => 10,
            SlaTier::Core => 25,
            SlaTier::Platform => 50,
            SlaTier::Standard => 100,
            SlaTier::Background => 200,
            SlaTier::Utility => 500,
        }
    }
}

impl std::fmt::Display for SlaTier {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            SlaTier::Critical => write!(f, "critical"),
            SlaTier::Core => write!(f, "core"),
            SlaTier::Platform => write!(f, "platform"),
            SlaTier::Standard => write!(f, "standard"),
            SlaTier::Background => write!(f, "background"),
            SlaTier::Utility => write!(f, "utility"),
        }
    }
}

/// SLA definition for a tenant/service.
#[derive(Debug, Clone)]
pub struct SlaDefinition {
    pub tier: SlaTier,
    /// Optional custom latency target (overrides tier default).
    pub custom_max_latency_ms: Option<u64>,
    /// Optional custom availability target.
    pub custom_availability: Option<f64>,
}

impl SlaDefinition {
    pub fn new(tier: SlaTier) -> Self {
        Self {
            tier,
            custom_max_latency_ms: None,
            custom_availability: None,
        }
    }

    pub fn effective_max_latency_ms(&self) -> u64 {
        self.custom_max_latency_ms
            .unwrap_or_else(|| self.tier.max_latency_ms())
    }

    pub fn effective_availability(&self) -> f64 {
        self.custom_availability
            .unwrap_or_else(|| self.tier.target_availability())
    }
}

/// Default sliding window duration: 5 minutes.
const DEFAULT_WINDOW_SECS: u64 = 300;

/// Counters for a single measurement window.
#[derive(Debug)]
struct WindowCounters {
    total_requests: AtomicU64,
    successful_requests: AtomicU64,
    latency_violations: AtomicU64,
    latency_sum_us: AtomicU64,
}

impl WindowCounters {
    fn new() -> Self {
        Self {
            total_requests: AtomicU64::new(0),
            successful_requests: AtomicU64::new(0),
            latency_violations: AtomicU64::new(0),
            latency_sum_us: AtomicU64::new(0),
        }
    }

    fn reset(&self) {
        self.total_requests.store(0, Ordering::Relaxed);
        self.successful_requests.store(0, Ordering::Relaxed);
        self.latency_violations.store(0, Ordering::Relaxed);
        self.latency_sum_us.store(0, Ordering::Relaxed);
    }

    fn total(&self) -> u64 {
        self.total_requests.load(Ordering::Relaxed)
    }

    fn successful(&self) -> u64 {
        self.successful_requests.load(Ordering::Relaxed)
    }

    fn violations(&self) -> u64 {
        self.latency_violations.load(Ordering::Relaxed)
    }

    fn violation_rate(&self) -> f64 {
        let total = self.total();
        if total == 0 {
            return 0.0;
        }
        self.violations() as f64 / total as f64
    }

    fn availability(&self) -> f64 {
        let total = self.total();
        if total == 0 {
            return 1.0;
        }
        self.successful() as f64 / total as f64
    }
}

/// Tracks SLA compliance for a specific entity (tenant, service, etc.).
///
/// Uses a double-buffered sliding window to prevent cliff-edge resets.
/// When the current window expires, its counters move to the "previous"
/// buffer and the current buffer is zeroed. The violation rate is computed
/// as a time-weighted blend: `w_curr * current_rate + w_prev * prev_rate`
/// where `w_curr = elapsed_in_window / window_duration`. Right after reset,
/// `w_curr ≈ 0` so the rate is almost entirely from the previous (fully
/// populated) window, eliminating the cliff edge.
#[derive(Debug)]
pub struct SlaTracker {
    /// Current window counters.
    current: WindowCounters,
    /// Previous window counters (for blending during transition).
    previous: WindowCounters,
    /// Window start time (reset when window expires).
    window_start: parking_lot::Mutex<Instant>,
    /// Window duration.
    window_duration: Duration,
    /// Current violation state.
    pub in_violation: std::sync::atomic::AtomicBool,
}

impl SlaTracker {
    pub fn new() -> Self {
        Self {
            current: WindowCounters::new(),
            previous: WindowCounters::new(),
            window_start: parking_lot::Mutex::new(Instant::now()),
            window_duration: Duration::from_secs(DEFAULT_WINDOW_SECS),
            in_violation: std::sync::atomic::AtomicBool::new(false),
        }
    }

    /// Rotate windows: move current → previous, zero current.
    fn rotate(&self) {
        // Copy current counters to previous.
        self.previous.total_requests.store(
            self.current.total_requests.load(Ordering::Relaxed),
            Ordering::Relaxed,
        );
        self.previous.successful_requests.store(
            self.current.successful_requests.load(Ordering::Relaxed),
            Ordering::Relaxed,
        );
        self.previous.latency_violations.store(
            self.current.latency_violations.load(Ordering::Relaxed),
            Ordering::Relaxed,
        );
        self.previous.latency_sum_us.store(
            self.current.latency_sum_us.load(Ordering::Relaxed),
            Ordering::Relaxed,
        );
        // Zero current.
        self.current.reset();
    }

    /// Compute the time-weighted blended violation rate.
    ///
    /// When the previous window has no data (fresh tracker or after full
    /// reset), uses current window rate only — blending with an empty
    /// previous window would incorrectly pull the rate to zero.
    fn blended_violation_rate(&self, elapsed_in_window: Duration) -> f64 {
        if self.previous.total() == 0 {
            return self.current.violation_rate();
        }
        let w_curr =
            (elapsed_in_window.as_secs_f64() / self.window_duration.as_secs_f64()).clamp(0.0, 1.0);
        let w_prev = 1.0 - w_curr;
        let curr_rate = self.current.violation_rate();
        let prev_rate = self.previous.violation_rate();
        w_curr * curr_rate + w_prev * prev_rate
    }

    /// Compute the time-weighted blended availability.
    fn blended_availability(&self, elapsed_in_window: Duration) -> f64 {
        if self.previous.total() == 0 {
            return self.current.availability();
        }
        let w_curr =
            (elapsed_in_window.as_secs_f64() / self.window_duration.as_secs_f64()).clamp(0.0, 1.0);
        let w_prev = 1.0 - w_curr;
        let curr_avail = self.current.availability();
        let prev_avail = self.previous.availability();
        w_curr * curr_avail + w_prev * prev_avail
    }

    /// Record a request outcome.
    ///
    /// `target_availability` enables availability breach detection when `Some`.
    /// Pass `None` to check only latency violations.
    pub fn record(
        &self,
        success: bool,
        latency_ms: u64,
        max_latency_ms: u64,
        target_availability: Option<f64>,
    ) -> Option<SlaViolation> {
        let elapsed_in_window;
        // Auto-rotate when the window expires.
        {
            let mut ws = self.window_start.lock();
            let elapsed = ws.elapsed();
            if elapsed >= self.window_duration {
                self.rotate();
                *ws = Instant::now();
                elapsed_in_window = Duration::ZERO;
            } else {
                elapsed_in_window = elapsed;
            }
        }

        self.current.total_requests.fetch_add(1, Ordering::Relaxed);
        if success {
            self.current
                .successful_requests
                .fetch_add(1, Ordering::Relaxed);
        }
        self.current
            .latency_sum_us
            .fetch_add(latency_ms * 1000, Ordering::Relaxed);

        if latency_ms > max_latency_ms {
            self.current
                .latency_violations
                .fetch_add(1, Ordering::Relaxed);
        }

        // Compute blended violation rate (uses previous window to avoid cliff).
        // Need minimum combined samples to avoid noise.
        let combined_total = self.current.total() + self.previous.total();
        if combined_total >= 100 {
            // Check availability first — a hard outage is more severe than
            // slow responses, and callers should learn about it immediately.
            if let Some(target) = target_availability {
                let avail = self.blended_availability(elapsed_in_window);
                if avail < target {
                    self.in_violation.store(true, Ordering::Relaxed);
                    return Some(SlaViolation::AvailabilityBreach {
                        current: avail,
                        target,
                    });
                }
            }

            let violation_rate = self.blended_violation_rate(elapsed_in_window);
            if violation_rate > 0.01 {
                self.in_violation.store(true, Ordering::Relaxed);
                return Some(SlaViolation::LatencyExceeded {
                    violation_rate,
                    threshold_ms: max_latency_ms,
                });
            }

            self.in_violation.store(false, Ordering::Relaxed);
        }

        None
    }

    /// Get current blended availability.
    pub fn availability(&self) -> f64 {
        let elapsed = self.window_start.lock().elapsed();
        self.blended_availability(elapsed)
    }

    /// Get average latency in milliseconds (current window only).
    pub fn avg_latency_ms(&self) -> f64 {
        let total = self.current.total();
        let sum_us = self.current.latency_sum_us.load(Ordering::Relaxed);
        if total == 0 {
            return 0.0;
        }
        (sum_us as f64 / total as f64) / 1000.0
    }

    /// Reset both windows.
    pub fn reset(&self) {
        self.current.reset();
        self.previous.reset();
        self.in_violation.store(false, Ordering::Relaxed);
        *self.window_start.lock() = Instant::now();
    }

    /// Get current stats snapshot.
    pub fn stats(&self) -> SlaTrackerStats {
        SlaTrackerStats {
            total_requests: self.current.total(),
            successful_requests: self.current.successful(),
            latency_violations: self.current.violations(),
            availability: self.availability(),
            avg_latency_ms: self.avg_latency_ms(),
            in_violation: self.in_violation.load(Ordering::Relaxed),
        }
    }
}

impl Default for SlaTracker {
    fn default() -> Self {
        Self::new()
    }
}

/// SLA violation event.
#[derive(Debug, Clone)]
pub enum SlaViolation {
    LatencyExceeded {
        violation_rate: f64,
        threshold_ms: u64,
    },
    AvailabilityBreach {
        current: f64,
        target: f64,
    },
}

impl std::fmt::Display for SlaViolation {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            SlaViolation::LatencyExceeded {
                violation_rate,
                threshold_ms,
            } => {
                write!(
                    f,
                    "latency exceeded: {:.1}% violations above {}ms",
                    violation_rate * 100.0,
                    threshold_ms
                )
            }
            SlaViolation::AvailabilityBreach { current, target } => {
                write!(
                    f,
                    "availability breach: {:.2}% < {:.2}% target",
                    current * 100.0,
                    target * 100.0
                )
            }
        }
    }
}

/// Action to take on SLA violation.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ViolationAction {
    /// Log an alert.
    Alert,
    /// Reroute to alternative provider.
    Reroute,
    /// Degrade to lower-quality but faster provider.
    Degrade,
    /// Open circuit breaker for violating provider.
    CircuitBreak,
    /// Escalate to HITL or control plane.
    Escalate,
}

/// SLA tracker statistics snapshot.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct SlaTrackerStats {
    pub total_requests: u64,
    pub successful_requests: u64,
    pub latency_violations: u64,
    pub availability: f64,
    pub avg_latency_ms: f64,
    pub in_violation: bool,
}

/// SLA enforcement engine.
pub struct SlaEngine {
    /// SLA definitions. Key: entity_id (tenant_id, service_id, etc.).
    slas: DashMap<String, SlaDefinition>,
    /// Per-entity SLA trackers.
    trackers: DashMap<String, SlaTracker>,
}

impl SlaEngine {
    /// Create a new SLA engine.
    pub fn new() -> Self {
        Self {
            slas: DashMap::new(),
            trackers: DashMap::new(),
        }
    }

    /// Set SLA definition for an entity.
    pub fn set_sla(&self, entity_id: &str, definition: SlaDefinition) {
        self.slas.insert(entity_id.to_string(), definition);
        self.trackers.entry(entity_id.to_string()).or_default();
    }

    /// Get SLA tier for an entity (returns None if no SLA defined).
    pub fn get_tier(&self, entity_id: &str) -> Option<SlaTier> {
        self.slas.get(entity_id).map(|d| d.tier)
    }

    /// Record a request outcome and check for violations.
    pub fn record_observation(
        &self,
        entity_id: &str,
        success: bool,
        latency_ms: u64,
    ) -> Option<SlaViolation> {
        let sla = self.slas.get(entity_id)?;
        let tracker = self.trackers.entry(entity_id.to_string()).or_default();
        tracker.record(
            success,
            latency_ms,
            sla.effective_max_latency_ms(),
            Some(sla.effective_availability()),
        )
    }

    /// Get recommended action for a violation.
    pub fn recommended_action(&self, entity_id: &str) -> Option<ViolationAction> {
        let sla = self.slas.get(entity_id)?;
        let tracker = self.trackers.get(entity_id)?;

        if !tracker.in_violation.load(Ordering::Relaxed) {
            return None;
        }

        // Tier determines severity of response
        Some(match sla.tier {
            SlaTier::Critical => ViolationAction::CircuitBreak,
            SlaTier::Core => ViolationAction::Reroute,
            SlaTier::Platform => ViolationAction::Reroute,
            SlaTier::Standard => ViolationAction::Alert,
            SlaTier::Background => ViolationAction::Alert,
            SlaTier::Utility => ViolationAction::Alert,
        })
    }

    /// Get tracker stats for an entity.
    pub fn tracker_stats(&self, entity_id: &str) -> Option<SlaTrackerStats> {
        self.trackers.get(entity_id).map(|t| t.stats())
    }

    /// Reset all trackers (new window).
    pub fn reset_all(&self) {
        for tracker in self.trackers.iter() {
            tracker.value().reset();
        }
    }

    /// Get total number of tracked entities.
    pub fn entity_count(&self) -> usize {
        self.slas.len()
    }

    /// Check if an entity is currently in SLA violation.
    pub fn is_in_violation(&self, entity_id: &str) -> bool {
        self.trackers
            .get(entity_id)
            .map(|t| t.in_violation.load(Ordering::Relaxed))
            .unwrap_or(false)
    }
}

impl Default for SlaEngine {
    fn default() -> Self {
        Self::new()
    }
}

/// Cold-start buffer configuration.
#[derive(Debug, Clone)]
pub struct ColdStartConfig {
    /// Whether cold-start buffering is enabled.
    pub enabled: bool,
    /// Default timeout in seconds (overridden by SLA tier).
    pub default_timeout_secs: u64,
    /// Maximum buffered requests (prevents memory exhaustion).
    pub max_buffered_requests: usize,
}

impl Default for ColdStartConfig {
    fn default() -> Self {
        Self {
            enabled: false,
            default_timeout_secs: 60,
            max_buffered_requests: 1000,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn tier_properties() {
        assert!(SlaTier::Critical.target_availability() > SlaTier::Core.target_availability());
        assert!(SlaTier::Critical.max_latency_ms() < SlaTier::Standard.max_latency_ms());
        assert!(
            SlaTier::Critical.cold_start_timeout_secs()
                < SlaTier::Background.cold_start_timeout_secs()
        );
        assert!(SlaTier::Critical.max_queue_depth() < SlaTier::Utility.max_queue_depth());
    }

    #[test]
    fn sla_definition_custom_overrides() {
        let mut def = SlaDefinition::new(SlaTier::Standard);
        assert_eq!(def.effective_max_latency_ms(), 3000);

        def.custom_max_latency_ms = Some(1500);
        assert_eq!(def.effective_max_latency_ms(), 1500);
    }

    #[test]
    fn tracker_records_and_computes() {
        let tracker = SlaTracker::new();

        // Record 10 successful requests at 100ms
        for _ in 0..10 {
            tracker.record(true, 100, 200, None);
        }

        assert_eq!(tracker.availability(), 1.0);
        assert!((tracker.avg_latency_ms() - 100.0).abs() < 0.01);
    }

    #[test]
    fn tracker_detects_latency_violation() {
        let tracker = SlaTracker::new();

        // Record 100 requests — all successful but 5 exceed latency
        for i in 0..100 {
            let latency = if i < 95 { 100 } else { 500 };
            tracker.record(true, latency, 200, None);
        }

        assert!(tracker.in_violation.load(Ordering::Relaxed));
    }

    #[test]
    fn engine_set_and_observe() {
        let engine = SlaEngine::new();
        engine.set_sla("tenant1", SlaDefinition::new(SlaTier::Standard));

        // Record observations
        for _ in 0..50 {
            engine.record_observation("tenant1", true, 100);
        }

        let stats = engine.tracker_stats("tenant1").unwrap();
        assert_eq!(stats.total_requests, 50);
        assert_eq!(stats.availability, 1.0);
    }

    #[test]
    fn engine_violation_action() {
        let engine = SlaEngine::new();
        engine.set_sla("critical-svc", SlaDefinition::new(SlaTier::Critical));

        // No violation initially
        assert!(engine.recommended_action("critical-svc").is_none());

        // Trigger violation (many latency violations)
        for i in 0..100 {
            let latency = if i < 50 { 100 } else { 500 };
            engine.record_observation("critical-svc", true, latency);
        }

        // Critical tier should recommend CircuitBreak
        if engine.is_in_violation("critical-svc") {
            assert_eq!(
                engine.recommended_action("critical-svc"),
                Some(ViolationAction::CircuitBreak)
            );
        }
    }

    #[test]
    fn tracker_reset() {
        let tracker = SlaTracker::new();
        tracker.record(true, 100, 200, None);
        tracker.record(false, 500, 200, None);

        assert_eq!(tracker.stats().total_requests, 2);

        tracker.reset();
        assert_eq!(tracker.stats().total_requests, 0);
        assert_eq!(tracker.availability(), 1.0);
    }

    #[test]
    fn engine_get_tier() {
        let engine = SlaEngine::new();
        engine.set_sla("t1", SlaDefinition::new(SlaTier::Critical));

        assert_eq!(engine.get_tier("t1"), Some(SlaTier::Critical));
        assert_eq!(engine.get_tier("unknown"), None);
    }

    #[test]
    fn engine_entity_count() {
        let engine = SlaEngine::new();
        engine.set_sla("t1", SlaDefinition::new(SlaTier::Critical));
        engine.set_sla("t2", SlaDefinition::new(SlaTier::Standard));
        assert_eq!(engine.entity_count(), 2);
    }

    #[test]
    fn tracker_blends_across_window_reset() {
        // Use a very short window so we can test the rotation.
        let tracker = SlaTracker {
            current: WindowCounters::new(),
            previous: WindowCounters::new(),
            window_start: parking_lot::Mutex::new(Instant::now()),
            window_duration: Duration::from_millis(50),
            in_violation: std::sync::atomic::AtomicBool::new(false),
        };

        // Fill the first window with 100 requests, 10 latency violations (10%).
        for i in 0..100 {
            let latency = if i < 90 { 100 } else { 500 };
            tracker.record(true, latency, 200, None);
        }
        assert!(
            tracker.in_violation.load(Ordering::Relaxed),
            "should be in violation with 10% violation rate"
        );

        // Wait for window to expire, then record one clean request.
        std::thread::sleep(Duration::from_millis(60));
        let result = tracker.record(true, 50, 200, None);

        // Right after rotation with only 1 new request, the blended rate
        // should still reflect the previous window (≈10%), not drop to 0%.
        // The violation rate is prev_weight * 10% + curr_weight * 0%
        // with curr_weight ≈ 0, so blended ≈ 10%.
        let blended = tracker.blended_violation_rate(Duration::from_millis(1));
        assert!(
            blended > 0.05,
            "blended rate should carry over from previous window, got {blended}"
        );

        // The combined total (100 + 1 = 101) exceeds the 100 threshold,
        // so violation detection should still fire.
        assert!(
            result.is_some() || tracker.in_violation.load(Ordering::Relaxed),
            "violation should persist through window transition"
        );
    }

    #[test]
    fn tracker_detects_availability_breach() {
        let tracker = SlaTracker::new();

        // Record 100 requests with 20 failures (80% availability).
        for i in 0..100 {
            let success = i < 80;
            tracker.record(success, 100, 200, Some(0.999));
        }

        assert!(
            tracker.in_violation.load(Ordering::Relaxed),
            "should be in violation with 80% availability vs 99.9% target"
        );
    }

    #[test]
    fn engine_detects_availability_breach() {
        let engine = SlaEngine::new();
        engine.set_sla("svc", SlaDefinition::new(SlaTier::Critical)); // 99.99% target

        // Record 100 requests with 20 failures.
        let mut violation = None;
        for i in 0..100 {
            let success = i < 80;
            let v = engine.record_observation("svc", success, 100);
            if v.is_some() {
                violation = v;
            }
        }

        assert!(violation.is_some(), "should detect availability breach");
        assert!(
            matches!(violation.unwrap(), SlaViolation::AvailabilityBreach { .. }),
            "violation should be AvailabilityBreach"
        );
    }

    #[test]
    fn cold_start_config_defaults() {
        let config = ColdStartConfig::default();
        assert!(!config.enabled);
        assert_eq!(config.default_timeout_secs, 60);
        assert_eq!(config.max_buffered_requests, 1000);
    }

    #[test]
    fn tier_display() {
        assert_eq!(SlaTier::Critical.to_string(), "critical");
        assert_eq!(SlaTier::Background.to_string(), "background");
    }
}
