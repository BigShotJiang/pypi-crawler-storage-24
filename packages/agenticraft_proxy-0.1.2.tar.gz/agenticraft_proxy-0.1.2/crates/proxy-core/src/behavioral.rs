// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Behavioral analysis infrastructure (shared by F19 zero-trust and F23 fraud).
//!
//! Tracks per-agent behavioral baselines and detects anomalies using
//! exponential moving averages for online learning.

use std::collections::HashSet;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::Instant;

use dashmap::DashMap;

/// Per-agent behavioral baseline (learned from observations).
#[derive(Debug, Clone)]
pub struct AgentBehaviorBaseline {
    /// Normal requests per second (rolling average).
    pub normal_rps: f64,
    /// Normal tokens per request (rolling average).
    pub normal_tokens: f64,
    /// Set of tools this agent normally uses.
    pub known_tools: HashSet<String>,
    /// Normal operating hours (0-23, UTC).
    pub normal_hours: HashSet<u8>,
    /// Total observations (baseline is "learned" after min_observations).
    pub observations: u64,
    /// Timestamp of the most recent observation (for stale-agent reaping).
    pub last_observed: Instant,
}

impl Default for AgentBehaviorBaseline {
    fn default() -> Self {
        Self {
            normal_rps: 0.0,
            normal_tokens: 0.0,
            known_tools: HashSet::new(),
            normal_hours: HashSet::new(),
            observations: 0,
            last_observed: Instant::now(),
        }
    }
}

/// An observation about agent behavior.
#[derive(Debug, Clone)]
pub struct BehavioralObservation {
    pub agent_id: String,
    pub rps: f64,
    pub tokens: u64,
    pub tool_name: Option<String>,
    pub hour: u8,
}

/// Detected anomaly type.
#[derive(Debug, Clone, PartialEq)]
pub enum AnomalyType {
    RateSpike { current: f64, normal: f64 },
    TokenSpike { current: u64, normal: u64 },
    UnknownTool { tool: String },
    OffHoursAccess { hour: u8 },
}

/// Anomaly severity.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum AnomalySeverity {
    Low,
    Medium,
    High,
    Critical,
}

/// A detected behavioral anomaly.
#[derive(Debug, Clone)]
pub struct BehavioralAnomaly {
    pub agent_id: String,
    pub anomaly_type: AnomalyType,
    pub severity: AnomalySeverity,
    pub description: String,
}

/// Configuration thresholds for anomaly detection.
#[derive(Debug, Clone)]
pub struct BehavioralThresholds {
    /// Rate spike multiplier (e.g., 5.0 = 5x normal).
    pub rate_spike_multiplier: f64,
    /// Token spike multiplier (e.g., 10.0 = 10x normal).
    pub token_spike_multiplier: f64,
    /// Minimum observations before baseline is considered learned.
    pub min_observations: u64,
}

impl Default for BehavioralThresholds {
    fn default() -> Self {
        Self {
            rate_spike_multiplier: 5.0,
            token_spike_multiplier: 10.0,
            min_observations: 100,
        }
    }
}

/// EMA smoothing factor — 10% weight on each new observation.
const EMA_ALPHA: f64 = 0.1;

/// Maximum distinct tools tracked per agent. Once saturated, the unknown-tool
/// detector is disabled for that agent (it legitimately uses many tools).
const MAX_KNOWN_TOOLS: usize = 64;

/// Shared behavioral analyzer.
pub struct BehavioralAnalyzer {
    baselines: DashMap<String, AgentBehaviorBaseline>,
    thresholds: BehavioralThresholds,
}

impl BehavioralAnalyzer {
    /// Create a new analyzer with the given thresholds.
    pub fn new(thresholds: BehavioralThresholds) -> Self {
        Self {
            baselines: DashMap::new(),
            thresholds,
        }
    }

    /// Record an observation and update the agent's baseline using exponential
    /// moving average (alpha = 0.1).
    pub fn observe(&self, obs: &BehavioralObservation) {
        let mut entry = self.baselines.entry(obs.agent_id.clone()).or_default();

        // EMA update: new_avg = alpha * observed + (1 - alpha) * old_avg
        if entry.observations == 0 {
            // First observation — seed the baseline directly.
            entry.normal_rps = obs.rps;
            entry.normal_tokens = obs.tokens as f64;
        } else {
            entry.normal_rps = EMA_ALPHA * obs.rps + (1.0 - EMA_ALPHA) * entry.normal_rps;
            entry.normal_tokens =
                EMA_ALPHA * obs.tokens as f64 + (1.0 - EMA_ALPHA) * entry.normal_tokens;
        }

        if let Some(ref tool) = obs.tool_name {
            if entry.known_tools.len() < MAX_KNOWN_TOOLS {
                entry.known_tools.insert(tool.clone());
            }
        }

        entry.normal_hours.insert(obs.hour);
        entry.last_observed = Instant::now();
        entry.observations += 1;
    }

    /// Check an observation against the baseline. Returns anomalies (empty = OK).
    ///
    /// During the learning phase (observations < `min_observations`), returns no
    /// anomalies — the baseline is not yet reliable.
    pub fn check(&self, obs: &BehavioralObservation) -> Vec<BehavioralAnomaly> {
        let Some(baseline) = self.baselines.get(&obs.agent_id) else {
            return Vec::new();
        };

        // Learning phase — trust nothing, flag nothing.
        if baseline.observations < self.thresholds.min_observations {
            return Vec::new();
        }

        let mut anomalies = Vec::new();

        // Rate spike check.
        if baseline.normal_rps > 0.0
            && obs.rps > baseline.normal_rps * self.thresholds.rate_spike_multiplier
        {
            let current = obs.rps;
            let normal = baseline.normal_rps;
            let multiplier = obs.rps / baseline.normal_rps;
            let severity = if multiplier >= 20.0 {
                AnomalySeverity::Critical
            } else if multiplier >= 10.0 {
                AnomalySeverity::High
            } else {
                AnomalySeverity::Medium
            };
            anomalies.push(BehavioralAnomaly {
                agent_id: obs.agent_id.clone(),
                anomaly_type: AnomalyType::RateSpike { current, normal },
                severity,
                description: format!(
                    "rate spike: {current} rps vs normal {normal} rps ({multiplier:.1}x)"
                ),
            });
        }

        // Token spike check.
        if baseline.normal_tokens > 0.0
            && obs.tokens as f64 > baseline.normal_tokens * self.thresholds.token_spike_multiplier
        {
            let current = obs.tokens;
            let normal = baseline.normal_tokens as u64;
            let multiplier = obs.tokens as f64 / baseline.normal_tokens;
            let severity = if multiplier >= 50.0 {
                AnomalySeverity::Critical
            } else if multiplier >= 20.0 {
                AnomalySeverity::High
            } else {
                AnomalySeverity::Medium
            };
            anomalies.push(BehavioralAnomaly {
                agent_id: obs.agent_id.clone(),
                anomaly_type: AnomalyType::TokenSpike { current, normal },
                severity,
                description: format!(
                    "token spike: {current} tokens vs normal {normal} ({multiplier:.1}x)"
                ),
            });
        }

        // Unknown tool check — skip if tool set is saturated (agent uses many tools).
        if let Some(ref tool) = obs.tool_name {
            if baseline.known_tools.len() < MAX_KNOWN_TOOLS
                && !baseline.known_tools.is_empty()
                && !baseline.known_tools.contains(tool)
            {
                anomalies.push(BehavioralAnomaly {
                    agent_id: obs.agent_id.clone(),
                    anomaly_type: AnomalyType::UnknownTool { tool: tool.clone() },
                    severity: AnomalySeverity::Medium,
                    description: format!("unknown tool used: {tool}"),
                });
            }
        }

        // Off-hours access check.
        if !baseline.normal_hours.is_empty() && !baseline.normal_hours.contains(&obs.hour) {
            anomalies.push(BehavioralAnomaly {
                agent_id: obs.agent_id.clone(),
                anomaly_type: AnomalyType::OffHoursAccess { hour: obs.hour },
                severity: AnomalySeverity::Low,
                description: format!("off-hours access at hour {}", obs.hour),
            });
        }

        anomalies
    }

    /// Get baseline for an agent (cloned snapshot).
    pub fn get_baseline(&self, agent_id: &str) -> Option<AgentBehaviorBaseline> {
        self.baselines.get(agent_id).map(|b| b.clone())
    }

    /// Get total number of tracked agents.
    pub fn agent_count(&self) -> usize {
        self.baselines.len()
    }

    /// Remove agents that haven't been observed for longer than `max_idle`.
    /// Returns the number of agents reaped.
    pub fn reap_stale(&self, max_idle: std::time::Duration) -> usize {
        let now = Instant::now();
        let stale: Vec<String> = self
            .baselines
            .iter()
            .filter(|e| now.duration_since(e.last_observed) > max_idle)
            .map(|e| e.key().clone())
            .collect();
        let count = stale.len();
        for key in stale {
            self.baselines.remove(&key);
        }
        count
    }
}

// ---------------------------------------------------------------------------
// Per-agent RPS tracker (lock-free sliding window)
// ---------------------------------------------------------------------------

/// Number of sub-buckets in the sliding window.
const RPS_NUM_BUCKETS: usize = 10;

/// Total window duration in milliseconds (1 second).
const RPS_WINDOW_MS: u64 = 1000;

/// Duration of each sub-bucket in milliseconds.
const RPS_BUCKET_MS: u64 = RPS_WINDOW_MS / RPS_NUM_BUCKETS as u64;

/// Per-agent entry in the RPS tracker using a lock-free multi-bucket sliding window.
///
/// Each bucket is an `AtomicU64` packing `(epoch: u32, count: u32)` where
/// `epoch = elapsed_ms / RPS_BUCKET_MS` since the tracker was created. When
/// a bucket's epoch is stale (older than `NUM_BUCKETS` epochs ago), its count
/// is zero. This gives a true sliding window with `RPS_BUCKET_MS` granularity
/// and zero mutex contention.
struct RpsEntry {
    /// Ring buffer of `(epoch, count)` packed into AtomicU64.
    buckets: [AtomicU64; RPS_NUM_BUCKETS],
    /// Epoch of the last `record()` call (for stale-agent reaping).
    last_seen_epoch: AtomicU64,
    /// Reference instant for epoch computation.
    created_at: Instant,
}

/// Pack (epoch, count) into a single u64.
#[inline]
fn pack(epoch: u32, count: u32) -> u64 {
    ((epoch as u64) << 32) | (count as u64)
}

/// Unpack a u64 into (epoch, count).
#[inline]
fn unpack(val: u64) -> (u32, u32) {
    ((val >> 32) as u32, val as u32)
}

impl RpsEntry {
    fn new() -> Self {
        Self {
            buckets: std::array::from_fn(|_| AtomicU64::new(0)),
            last_seen_epoch: AtomicU64::new(0),
            created_at: Instant::now(),
        }
    }

    /// Current epoch (bucket-granularity time index).
    #[inline]
    fn current_epoch(&self) -> u32 {
        let elapsed_ms = self.created_at.elapsed().as_millis() as u64;
        (elapsed_ms / RPS_BUCKET_MS) as u32
    }

    /// Record a request. Returns the current RPS estimate.
    fn record(&self) -> f64 {
        let epoch = self.current_epoch();
        self.last_seen_epoch.store(epoch as u64, Ordering::Relaxed);
        let idx = (epoch as usize) % RPS_NUM_BUCKETS;
        let bucket = &self.buckets[idx];

        // CAS loop: if epoch matches, increment count; otherwise reset bucket.
        loop {
            let current = bucket.load(Ordering::Relaxed);
            let (stored_epoch, stored_count) = unpack(current);
            let new_val = if stored_epoch == epoch {
                pack(epoch, stored_count + 1)
            } else {
                pack(epoch, 1)
            };
            if bucket
                .compare_exchange_weak(current, new_val, Ordering::Relaxed, Ordering::Relaxed)
                .is_ok()
            {
                break;
            }
        }

        self.compute_rps(epoch)
    }

    /// Compute RPS by summing live buckets.
    fn compute_rps(&self, now_epoch: u32) -> f64 {
        let mut total: u64 = 0;
        for bucket in &self.buckets {
            let (epoch, count) = unpack(bucket.load(Ordering::Relaxed));
            // Bucket is live if its epoch is within the window.
            if now_epoch.wrapping_sub(epoch) < RPS_NUM_BUCKETS as u32 {
                total += count as u64;
            }
        }
        // Window covers RPS_WINDOW_MS milliseconds.
        total as f64 / (RPS_WINDOW_MS as f64 / 1000.0)
    }

    /// Get the current RPS estimate without recording a request.
    fn current_rps(&self) -> f64 {
        self.compute_rps(self.current_epoch())
    }
}

/// Tracks per-agent requests-per-second using a lock-free sliding window.
///
/// Used by zero-trust (F19) and fraud (F23) middlewares to provide real RPS
/// values in [`BehavioralObservation`] instead of hardcoded `1.0`.
///
/// Design: 10 sub-buckets of 100ms each, covering a 1-second window. Each
/// bucket uses `AtomicU64` CAS for lock-free updates. No mutex contention
/// even under high concurrency.
pub struct AgentRpsTracker {
    entries: DashMap<String, RpsEntry>,
}

impl AgentRpsTracker {
    pub fn new() -> Self {
        Self {
            entries: DashMap::new(),
        }
    }

    /// Record a request for the given agent and return the current RPS.
    pub fn record(&self, agent_id: &str) -> f64 {
        self.entries
            .entry(agent_id.to_string())
            .or_insert_with(RpsEntry::new)
            .record()
    }

    /// Get the current RPS for an agent without recording a request.
    pub fn get_rps(&self, agent_id: &str) -> f64 {
        self.entries
            .get(agent_id)
            .map(|e| e.current_rps())
            .unwrap_or(0.0)
    }

    /// Number of tracked agents.
    pub fn agent_count(&self) -> usize {
        self.entries.len()
    }

    /// Remove agents that haven't been seen for longer than `max_idle`.
    /// Returns the number of agents reaped.
    pub fn reap_stale(&self, max_idle: std::time::Duration) -> usize {
        let max_idle_epochs = (max_idle.as_millis() as u64 / RPS_BUCKET_MS) as u32;
        let mut reaped = 0;
        // Collect keys to remove (can't remove during iteration with DashMap).
        let stale_keys: Vec<String> = self
            .entries
            .iter()
            .filter_map(|entry| {
                let now_epoch = entry.value().current_epoch();
                let last = entry.value().last_seen_epoch.load(Ordering::Relaxed) as u32;
                if now_epoch.wrapping_sub(last) > max_idle_epochs {
                    Some(entry.key().clone())
                } else {
                    None
                }
            })
            .collect();
        for key in stale_keys {
            self.entries.remove(&key);
            reaped += 1;
        }
        reaped
    }
}

impl Default for AgentRpsTracker {
    fn default() -> Self {
        Self::new()
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    fn make_obs(
        agent_id: &str,
        rps: f64,
        tokens: u64,
        tool: Option<&str>,
        hour: u8,
    ) -> BehavioralObservation {
        BehavioralObservation {
            agent_id: agent_id.to_string(),
            rps,
            tokens,
            tool_name: tool.map(|t| t.to_string()),
            hour,
        }
    }

    fn trained_analyzer(
        agent_id: &str,
        rps: f64,
        tokens: u64,
        tool: Option<&str>,
        hour: u8,
    ) -> BehavioralAnalyzer {
        let thresholds = BehavioralThresholds {
            min_observations: 5,
            ..Default::default()
        };
        let analyzer = BehavioralAnalyzer::new(thresholds);
        for _ in 0..5 {
            analyzer.observe(&make_obs(agent_id, rps, tokens, tool, hour));
        }
        analyzer
    }

    #[test]
    fn learning_phase_allows_all() {
        // With min_observations = 100 and only 1 observation, no anomalies.
        let analyzer = BehavioralAnalyzer::new(BehavioralThresholds::default());
        let obs = make_obs("agent-1", 1.0, 100, Some("search"), 9);
        analyzer.observe(&obs);

        // Even with a wildly different observation, learning phase returns nothing.
        let spike = make_obs("agent-1", 10000.0, 1_000_000, Some("exec"), 3);
        let anomalies = analyzer.check(&spike);
        assert!(
            anomalies.is_empty(),
            "learning phase should return no anomalies"
        );
    }

    #[test]
    fn rate_spike_detected_after_baseline() {
        let analyzer = trained_analyzer("agent-2", 2.0, 100, Some("search"), 10);
        // 100x normal rate — well above 5x multiplier threshold.
        let spike = make_obs("agent-2", 200.0, 100, Some("search"), 10);
        let anomalies = analyzer.check(&spike);
        assert!(
            anomalies
                .iter()
                .any(|a| matches!(a.anomaly_type, AnomalyType::RateSpike { .. })),
            "expected RateSpike anomaly"
        );
    }

    #[test]
    fn token_spike_detected() {
        let analyzer = trained_analyzer("agent-3", 1.0, 200, Some("search"), 9);
        // 100x normal tokens — well above 10x multiplier threshold.
        let spike = make_obs("agent-3", 1.0, 20_000, Some("search"), 9);
        let anomalies = analyzer.check(&spike);
        assert!(
            anomalies
                .iter()
                .any(|a| matches!(a.anomaly_type, AnomalyType::TokenSpike { .. })),
            "expected TokenSpike anomaly"
        );
    }

    #[test]
    fn unknown_tool_flagged() {
        let analyzer = trained_analyzer("agent-4", 1.0, 100, Some("search"), 9);
        let obs = make_obs("agent-4", 1.0, 100, Some("exec_arbitrary_code"), 9);
        let anomalies = analyzer.check(&obs);
        assert!(
            anomalies.iter().any(|a| matches!(&a.anomaly_type, AnomalyType::UnknownTool { tool } if tool == "exec_arbitrary_code")),
            "expected UnknownTool anomaly"
        );
    }

    #[test]
    fn off_hours_detected() {
        // Train with hour=9 (business hours).
        let analyzer = trained_analyzer("agent-5", 1.0, 100, Some("search"), 9);
        // Access at hour=3 (off-hours).
        let obs = make_obs("agent-5", 1.0, 100, Some("search"), 3);
        let anomalies = analyzer.check(&obs);
        assert!(
            anomalies
                .iter()
                .any(|a| matches!(a.anomaly_type, AnomalyType::OffHoursAccess { hour: 3 })),
            "expected OffHoursAccess anomaly at hour 3"
        );
    }

    #[test]
    fn baseline_ema_updates_correctly() {
        let thresholds = BehavioralThresholds {
            min_observations: 1,
            ..Default::default()
        };
        let analyzer = BehavioralAnalyzer::new(thresholds);

        // First observation seeds directly.
        let obs1 = make_obs("agent-ema", 10.0, 1000, None, 9);
        analyzer.observe(&obs1);
        {
            let b = analyzer.get_baseline("agent-ema").unwrap();
            assert!(
                (b.normal_rps - 10.0).abs() < 1e-6,
                "first obs seeds directly"
            );
        }

        // Second observation: EMA = 0.1 * 20 + 0.9 * 10 = 2 + 9 = 11
        let obs2 = make_obs("agent-ema", 20.0, 1000, None, 9);
        analyzer.observe(&obs2);
        {
            let b = analyzer.get_baseline("agent-ema").unwrap();
            let expected = 0.1 * 20.0 + 0.9 * 10.0;
            assert!(
                (b.normal_rps - expected).abs() < 1e-6,
                "EMA should be {expected}, got {}",
                b.normal_rps
            );
        }
    }

    #[test]
    fn reap_stale_behavioral_baselines() {
        let thresholds = BehavioralThresholds {
            min_observations: 1,
            ..Default::default()
        };
        let analyzer = BehavioralAnalyzer::new(thresholds);

        // Observe both agents.
        analyzer.observe(&make_obs("active", 1.0, 100, None, 9));
        analyzer.observe(&make_obs("stale", 1.0, 100, None, 9));
        assert_eq!(analyzer.agent_count(), 2);

        // Wait so both become stale-eligible.
        std::thread::sleep(std::time::Duration::from_millis(200));

        // Refresh "active" — its last_observed is now recent.
        analyzer.observe(&make_obs("active", 1.0, 100, None, 9));

        // Reap agents idle for more than 100ms.
        let reaped = analyzer.reap_stale(std::time::Duration::from_millis(100));
        assert_eq!(reaped, 1, "only 'stale' should be reaped");
        assert_eq!(analyzer.agent_count(), 1);
        assert!(analyzer.get_baseline("active").is_some());
        assert!(analyzer.get_baseline("stale").is_none());
    }

    #[test]
    fn agent_count_tracks_unique_agents() {
        let analyzer = BehavioralAnalyzer::new(BehavioralThresholds::default());
        assert_eq!(analyzer.agent_count(), 0);
        analyzer.observe(&make_obs("a1", 1.0, 100, None, 9));
        analyzer.observe(&make_obs("a2", 1.0, 100, None, 9));
        analyzer.observe(&make_obs("a1", 1.0, 100, None, 9));
        assert_eq!(analyzer.agent_count(), 2);
    }

    // --- AgentRpsTracker tests ---

    #[test]
    fn rps_tracker_records_and_returns_positive() {
        let tracker = AgentRpsTracker::new();
        let rps = tracker.record("agent-1");
        assert!(rps > 0.0, "first request should produce positive RPS");
    }

    #[test]
    fn rps_tracker_multiple_records_increase_rps() {
        let tracker = AgentRpsTracker::new();
        tracker.record("agent-1");
        tracker.record("agent-1");
        let rps = tracker.record("agent-1");
        assert!(
            rps >= 1.0,
            "multiple rapid requests should yield high RPS: {rps}"
        );
    }

    #[test]
    fn rps_tracker_separate_agents_independent() {
        let tracker = AgentRpsTracker::new();
        tracker.record("agent-a");
        tracker.record("agent-b");
        assert_eq!(tracker.agent_count(), 2);
    }

    #[test]
    fn rps_tracker_get_rps_unknown_agent_is_zero() {
        let tracker = AgentRpsTracker::new();
        assert_eq!(tracker.get_rps("nonexistent"), 0.0);
    }

    #[test]
    fn rps_tracker_default() {
        let tracker = AgentRpsTracker::default();
        assert_eq!(tracker.agent_count(), 0);
    }

    #[test]
    fn rps_tracker_reap_stale() {
        let tracker = AgentRpsTracker::new();
        tracker.record("active");
        tracker.record("stale");
        assert_eq!(tracker.agent_count(), 2);

        // Sleep past the window so "stale" ages out.
        std::thread::sleep(std::time::Duration::from_millis(1200));

        // Record "active" again to refresh it.
        tracker.record("active");

        // Reap agents idle for more than 1 second.
        let reaped = tracker.reap_stale(std::time::Duration::from_secs(1));
        assert_eq!(reaped, 1);
        assert_eq!(tracker.agent_count(), 1);
        assert!(tracker.get_rps("active") > 0.0);
        assert_eq!(tracker.get_rps("stale"), 0.0);
    }

    #[test]
    fn rps_pack_unpack_roundtrip() {
        for epoch in [0u32, 1, 100, u32::MAX] {
            for count in [0u32, 1, 100, u32::MAX] {
                let packed = super::pack(epoch, count);
                let (e, c) = super::unpack(packed);
                assert_eq!((e, c), (epoch, count));
            }
        }
    }
}
