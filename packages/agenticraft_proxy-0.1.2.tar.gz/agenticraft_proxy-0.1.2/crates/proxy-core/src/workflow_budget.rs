// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Cross-request workflow budgets (F7).
//!
//! Tracks token, cost, and request budgets across multiple requests belonging
//! to the same workflow. Each workflow is identified by a string ID carried in
//! the `x-workflow-id` request header.
//!
//! All counters use atomic `compare_exchange` loops (same pattern as `budgets.rs`)
//! to prevent TOCTOU races under concurrent access.

use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{SystemTime, UNIX_EPOCH};

use dashmap::DashMap;
use thiserror::Error;

/// HTTP header that carries the workflow identifier.
pub const WORKFLOW_ID_HEADER: &str = "x-workflow-id";

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------

/// Errors returned by workflow budget operations.
#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum WorkflowBudgetError {
    /// The requested workflow does not exist.
    #[error("workflow not found: {workflow_id}")]
    WorkflowNotFound { workflow_id: String },

    /// The token budget for this workflow would be exceeded.
    #[error("token budget exceeded for workflow {workflow_id}")]
    TokenBudgetExceeded { workflow_id: String },

    /// The cost budget for this workflow would be exceeded.
    #[error("cost budget exceeded for workflow {workflow_id}")]
    CostBudgetExceeded { workflow_id: String },

    /// The maximum request count for this workflow would be exceeded.
    #[error("request limit exceeded for workflow {workflow_id}")]
    RequestLimitExceeded { workflow_id: String },

    /// The workflow has expired.
    #[error("workflow expired: {workflow_id}")]
    WorkflowExpired { workflow_id: String },
}

// ---------------------------------------------------------------------------
// Usage snapshot
// ---------------------------------------------------------------------------

/// A point-in-time snapshot of a workflow's resource usage.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct WorkflowUsage {
    pub tokens_used: u64,
    pub tokens_remaining: u64,
    pub cost_used_micro_usd: u64,
    pub cost_remaining_micro_usd: u64,
    pub requests: u64,
    pub max_requests: u64,
}

// ---------------------------------------------------------------------------
// Single workflow budget
// ---------------------------------------------------------------------------

/// Budget counters for a single workflow.
#[derive(Debug)]
pub struct WorkflowBudget {
    /// Workflow identifier.
    pub workflow_id: String,
    /// Maximum tokens allowed across all requests in this workflow.
    pub token_limit: AtomicU64,
    /// Tokens consumed so far.
    pub tokens_used: AtomicU64,
    /// Maximum cost (micro-USD) across all requests.
    pub cost_limit_micro_usd: AtomicU64,
    /// Cost consumed so far (micro-USD).
    pub cost_used_micro_usd: AtomicU64,
    /// Number of requests executed against this workflow.
    pub request_count: AtomicU64,
    /// Maximum number of requests allowed.
    pub max_requests: AtomicU64,
    /// Creation timestamp (seconds since UNIX epoch).
    pub created_at: u64,
    /// Expiry timestamp (seconds since UNIX epoch).
    pub expires_at: u64,
}

impl WorkflowBudget {
    /// Create a new workflow budget.
    fn new(
        workflow_id: String,
        token_limit: u64,
        cost_limit_micro_usd: u64,
        max_requests: u64,
        ttl_secs: u64,
    ) -> Self {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("system clock before UNIX epoch")
            .as_secs();
        Self {
            workflow_id,
            token_limit: AtomicU64::new(token_limit),
            tokens_used: AtomicU64::new(0),
            cost_limit_micro_usd: AtomicU64::new(cost_limit_micro_usd),
            cost_used_micro_usd: AtomicU64::new(0),
            request_count: AtomicU64::new(0),
            max_requests: AtomicU64::new(max_requests),
            created_at: now,
            expires_at: now + ttl_secs,
        }
    }

    /// Create a workflow budget with explicit timestamps (for testing).
    #[cfg(test)]
    fn new_with_timestamps(
        workflow_id: String,
        token_limit: u64,
        cost_limit_micro_usd: u64,
        max_requests: u64,
        created_at: u64,
        expires_at: u64,
    ) -> Self {
        Self {
            workflow_id,
            token_limit: AtomicU64::new(token_limit),
            tokens_used: AtomicU64::new(0),
            cost_limit_micro_usd: AtomicU64::new(cost_limit_micro_usd),
            cost_used_micro_usd: AtomicU64::new(0),
            request_count: AtomicU64::new(0),
            max_requests: AtomicU64::new(max_requests),
            created_at,
            expires_at,
        }
    }

    /// Returns `true` if this workflow has expired.
    fn is_expired(&self) -> bool {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("system clock before UNIX epoch")
            .as_secs();
        now >= self.expires_at
    }

    /// Atomically try to consume `tokens` from this budget.
    ///
    /// Uses a `compare_exchange` loop to prevent TOCTOU races.
    fn try_consume_tokens(&self, tokens: u64) -> bool {
        let limit = self.token_limit.load(Ordering::Relaxed);
        loop {
            let current = self.tokens_used.load(Ordering::Relaxed);
            let new_total = current + tokens;
            if new_total > limit {
                return false;
            }
            if self
                .tokens_used
                .compare_exchange_weak(current, new_total, Ordering::Relaxed, Ordering::Relaxed)
                .is_ok()
            {
                return true;
            }
            // CAS failed — another thread updated; retry
        }
    }

    /// Atomically try to consume `cost_micro_usd` from this budget.
    fn try_consume_cost(&self, cost_micro_usd: u64) -> bool {
        let limit = self.cost_limit_micro_usd.load(Ordering::Relaxed);
        loop {
            let current = self.cost_used_micro_usd.load(Ordering::Relaxed);
            let new_total = current + cost_micro_usd;
            if new_total > limit {
                return false;
            }
            if self
                .cost_used_micro_usd
                .compare_exchange_weak(current, new_total, Ordering::Relaxed, Ordering::Relaxed)
                .is_ok()
            {
                return true;
            }
        }
    }

    /// Atomically try to increment the request counter.
    fn try_increment_requests(&self) -> bool {
        let limit = self.max_requests.load(Ordering::Relaxed);
        loop {
            let current = self.request_count.load(Ordering::Relaxed);
            let new_total = current + 1;
            if new_total > limit {
                return false;
            }
            if self
                .request_count
                .compare_exchange_weak(current, new_total, Ordering::Relaxed, Ordering::Relaxed)
                .is_ok()
            {
                return true;
            }
        }
    }

    /// Take a point-in-time usage snapshot.
    fn usage(&self) -> WorkflowUsage {
        let token_limit = self.token_limit.load(Ordering::Relaxed);
        let tokens_used = self.tokens_used.load(Ordering::Relaxed);
        let cost_limit = self.cost_limit_micro_usd.load(Ordering::Relaxed);
        let cost_used = self.cost_used_micro_usd.load(Ordering::Relaxed);
        let requests = self.request_count.load(Ordering::Relaxed);
        let max_requests = self.max_requests.load(Ordering::Relaxed);

        WorkflowUsage {
            tokens_used,
            tokens_remaining: token_limit.saturating_sub(tokens_used),
            cost_used_micro_usd: cost_used,
            cost_remaining_micro_usd: cost_limit.saturating_sub(cost_used),
            requests,
            max_requests,
        }
    }
}

// ---------------------------------------------------------------------------
// Manager
// ---------------------------------------------------------------------------

/// Manages budgets across multiple concurrent workflows.
pub struct WorkflowBudgetManager {
    workflows: DashMap<String, WorkflowBudget>,
}

impl WorkflowBudgetManager {
    /// Create a new, empty manager.
    pub fn new() -> Self {
        Self {
            workflows: DashMap::new(),
        }
    }

    /// Register a new workflow with the given budget limits.
    pub fn create_workflow(
        &self,
        workflow_id: &str,
        token_limit: u64,
        cost_limit_micro_usd: u64,
        max_requests: u64,
        ttl_secs: u64,
    ) {
        self.workflows.insert(
            workflow_id.to_string(),
            WorkflowBudget::new(
                workflow_id.to_string(),
                token_limit,
                cost_limit_micro_usd,
                max_requests,
                ttl_secs,
            ),
        );
    }

    /// Atomically try to consume `tokens` from a workflow's token budget.
    ///
    /// Returns an error if the workflow is not found, has expired, or
    /// would exceed its token limit.
    pub fn try_consume_tokens(
        &self,
        workflow_id: &str,
        tokens: u64,
    ) -> Result<(), WorkflowBudgetError> {
        let budget = self.workflows.get(workflow_id).ok_or_else(|| {
            WorkflowBudgetError::WorkflowNotFound {
                workflow_id: workflow_id.to_string(),
            }
        })?;

        if budget.is_expired() {
            return Err(WorkflowBudgetError::WorkflowExpired {
                workflow_id: workflow_id.to_string(),
            });
        }

        if !budget.try_consume_tokens(tokens) {
            return Err(WorkflowBudgetError::TokenBudgetExceeded {
                workflow_id: workflow_id.to_string(),
            });
        }

        Ok(())
    }

    /// Atomically try to consume `cost_micro_usd` from a workflow's cost budget.
    ///
    /// Returns an error if the workflow is not found, has expired, or
    /// would exceed its cost limit.
    pub fn try_consume_cost(
        &self,
        workflow_id: &str,
        cost_micro_usd: u64,
    ) -> Result<(), WorkflowBudgetError> {
        let budget = self.workflows.get(workflow_id).ok_or_else(|| {
            WorkflowBudgetError::WorkflowNotFound {
                workflow_id: workflow_id.to_string(),
            }
        })?;

        if budget.is_expired() {
            return Err(WorkflowBudgetError::WorkflowExpired {
                workflow_id: workflow_id.to_string(),
            });
        }

        if !budget.try_consume_cost(cost_micro_usd) {
            return Err(WorkflowBudgetError::CostBudgetExceeded {
                workflow_id: workflow_id.to_string(),
            });
        }

        Ok(())
    }

    /// Atomically try to increment a workflow's request counter.
    ///
    /// Returns an error if the workflow is not found, has expired, or
    /// would exceed its maximum request count.
    pub fn try_increment_requests(&self, workflow_id: &str) -> Result<(), WorkflowBudgetError> {
        let budget = self.workflows.get(workflow_id).ok_or_else(|| {
            WorkflowBudgetError::WorkflowNotFound {
                workflow_id: workflow_id.to_string(),
            }
        })?;

        if budget.is_expired() {
            return Err(WorkflowBudgetError::WorkflowExpired {
                workflow_id: workflow_id.to_string(),
            });
        }

        if !budget.try_increment_requests() {
            return Err(WorkflowBudgetError::RequestLimitExceeded {
                workflow_id: workflow_id.to_string(),
            });
        }

        Ok(())
    }

    /// Get a point-in-time usage snapshot for a workflow.
    pub fn get_usage(&self, workflow_id: &str) -> Option<WorkflowUsage> {
        self.workflows.get(workflow_id).map(|b| b.usage())
    }

    /// Remove a workflow from the manager. Returns `true` if it existed.
    pub fn remove_workflow(&self, workflow_id: &str) -> bool {
        self.workflows.remove(workflow_id).is_some()
    }

    /// Remove all expired workflows. Returns the number removed.
    pub fn reap_expired(&self) -> usize {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("system clock before UNIX epoch")
            .as_secs();

        let expired_keys: Vec<String> = self
            .workflows
            .iter()
            .filter(|entry| now >= entry.value().expires_at)
            .map(|entry| entry.key().clone())
            .collect();

        let count = expired_keys.len();
        for key in expired_keys {
            self.workflows.remove(&key);
        }
        count
    }
}

impl Default for WorkflowBudgetManager {
    fn default() -> Self {
        Self::new()
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn create_and_consume_tokens_successfully() {
        let mgr = WorkflowBudgetManager::new();
        mgr.create_workflow("wf-1", 1000, 5_000_000, 100, 3600);

        assert!(mgr.try_consume_tokens("wf-1", 400).is_ok());
        assert!(mgr.try_consume_tokens("wf-1", 500).is_ok());

        let usage = mgr.get_usage("wf-1").unwrap();
        assert_eq!(usage.tokens_used, 900);
        assert_eq!(usage.tokens_remaining, 100);
    }

    #[test]
    fn token_budget_exceeded() {
        let mgr = WorkflowBudgetManager::new();
        mgr.create_workflow("wf-2", 100, 5_000_000, 100, 3600);

        assert!(mgr.try_consume_tokens("wf-2", 80).is_ok());

        let err = mgr.try_consume_tokens("wf-2", 30).unwrap_err();
        assert_eq!(
            err,
            WorkflowBudgetError::TokenBudgetExceeded {
                workflow_id: "wf-2".into(),
            }
        );

        // Should not have mutated on failure
        let usage = mgr.get_usage("wf-2").unwrap();
        assert_eq!(usage.tokens_used, 80);
        assert_eq!(usage.tokens_remaining, 20);
    }

    #[test]
    fn cost_budget_exceeded() {
        let mgr = WorkflowBudgetManager::new();
        mgr.create_workflow("wf-3", 10_000, 500_000, 100, 3600);

        assert!(mgr.try_consume_cost("wf-3", 400_000).is_ok());

        let err = mgr.try_consume_cost("wf-3", 200_000).unwrap_err();
        assert_eq!(
            err,
            WorkflowBudgetError::CostBudgetExceeded {
                workflow_id: "wf-3".into(),
            }
        );

        let usage = mgr.get_usage("wf-3").unwrap();
        assert_eq!(usage.cost_used_micro_usd, 400_000);
        assert_eq!(usage.cost_remaining_micro_usd, 100_000);
    }

    #[test]
    fn request_limit_exceeded() {
        let mgr = WorkflowBudgetManager::new();
        mgr.create_workflow("wf-4", 10_000, 5_000_000, 3, 3600);

        assert!(mgr.try_increment_requests("wf-4").is_ok());
        assert!(mgr.try_increment_requests("wf-4").is_ok());
        assert!(mgr.try_increment_requests("wf-4").is_ok());

        let err = mgr.try_increment_requests("wf-4").unwrap_err();
        assert_eq!(
            err,
            WorkflowBudgetError::RequestLimitExceeded {
                workflow_id: "wf-4".into(),
            }
        );

        let usage = mgr.get_usage("wf-4").unwrap();
        assert_eq!(usage.requests, 3);
        assert_eq!(usage.max_requests, 3);
    }

    #[test]
    fn expired_workflow_returns_error() {
        let mgr = WorkflowBudgetManager::new();

        // Insert a workflow that has already expired by using internal constructor
        let budget = WorkflowBudget::new_with_timestamps(
            "wf-expired".to_string(),
            10_000,
            5_000_000,
            100,
            0, // created_at: epoch
            1, // expires_at: 1 second after epoch (long expired)
        );
        mgr.workflows.insert("wf-expired".to_string(), budget);

        let err = mgr.try_consume_tokens("wf-expired", 10).unwrap_err();
        assert_eq!(
            err,
            WorkflowBudgetError::WorkflowExpired {
                workflow_id: "wf-expired".into(),
            }
        );

        let err = mgr.try_consume_cost("wf-expired", 100).unwrap_err();
        assert_eq!(
            err,
            WorkflowBudgetError::WorkflowExpired {
                workflow_id: "wf-expired".into(),
            }
        );

        let err = mgr.try_increment_requests("wf-expired").unwrap_err();
        assert_eq!(
            err,
            WorkflowBudgetError::WorkflowExpired {
                workflow_id: "wf-expired".into(),
            }
        );
    }

    #[test]
    fn reap_expired_removes_old_workflows() {
        let mgr = WorkflowBudgetManager::new();

        // One expired workflow
        let expired = WorkflowBudget::new_with_timestamps(
            "wf-old".to_string(),
            1000,
            1_000_000,
            10,
            0,
            1, // expired
        );
        mgr.workflows.insert("wf-old".to_string(), expired);

        // One still-valid workflow (expires far in the future)
        mgr.create_workflow("wf-active", 1000, 1_000_000, 10, 86400);

        assert_eq!(mgr.reap_expired(), 1);

        // Expired workflow is gone
        assert!(mgr.get_usage("wf-old").is_none());

        // Active workflow is still present
        assert!(mgr.get_usage("wf-active").is_some());
    }

    #[test]
    fn workflow_not_found() {
        let mgr = WorkflowBudgetManager::new();

        let err = mgr.try_consume_tokens("nonexistent", 10).unwrap_err();
        assert_eq!(
            err,
            WorkflowBudgetError::WorkflowNotFound {
                workflow_id: "nonexistent".into(),
            }
        );
    }

    #[test]
    fn remove_workflow() {
        let mgr = WorkflowBudgetManager::new();
        mgr.create_workflow("wf-rm", 1000, 1_000_000, 10, 3600);

        assert!(mgr.remove_workflow("wf-rm"));
        assert!(!mgr.remove_workflow("wf-rm")); // already gone
        assert!(mgr.get_usage("wf-rm").is_none());
    }

    #[test]
    fn concurrent_token_consumption_no_overcommit() {
        use std::sync::Arc;
        use std::thread;

        let mgr = Arc::new(WorkflowBudgetManager::new());
        mgr.create_workflow("wf-conc", 100, 100_000_000, 1000, 3600);

        let success_count = Arc::new(AtomicU64::new(0));
        let mut handles = vec![];

        // 20 threads each trying to consume 10 tokens
        // Budget is 100, so exactly 10 should succeed
        for _ in 0..20 {
            let mgr = mgr.clone();
            let sc = success_count.clone();
            handles.push(thread::spawn(move || {
                if mgr.try_consume_tokens("wf-conc", 10).is_ok() {
                    sc.fetch_add(1, Ordering::Relaxed);
                }
            }));
        }

        for handle in handles {
            handle.join().unwrap();
        }

        assert_eq!(success_count.load(Ordering::Relaxed), 10);
        let usage = mgr.get_usage("wf-conc").unwrap();
        assert_eq!(usage.tokens_used, 100);
        assert_eq!(usage.tokens_remaining, 0);
    }
}
