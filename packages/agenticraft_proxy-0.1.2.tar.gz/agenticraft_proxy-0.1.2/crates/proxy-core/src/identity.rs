// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Ed25519 DID verification with public key cache.
//!
//! Supports two paths:
//! 1. `did:key` — decoded inline from the DID string (~1μs)
//! 2. All other methods — looked up from cache (populated by Python gRPC push)
//!
//! This lives in proxy-core (proprietary) because zero-trust agent identity
//! verification in the data plane is an exclusive AgentiCraft capability.

use dashmap::DashMap;
use ed25519_dalek::{Signature, Verifier, VerifyingKey};

/// Errors from identity operations.
#[derive(Debug, thiserror::Error)]
pub enum IdentityError {
    #[error("unsupported DID method: {0}")]
    UnsupportedMethod(String),

    #[error("invalid did:key encoding: {0}")]
    InvalidDidKey(String),

    #[error("invalid public key: {0}")]
    InvalidPublicKey(String),

    #[error("signature verification failed")]
    VerificationFailed,

    #[error("DID not found in cache: {0}")]
    NotCached(String),

    #[error("key already cached for DID: {0}")]
    KeyAlreadyCached(String),
}

/// Ed25519 DID verifier with public key cache.
///
/// Performance: ~50μs per verification (dominated by Ed25519).
/// Cache lookups: O(1) via DashMap (~10ns).
pub struct DidVerifier {
    /// did → VerifyingKey cache. Populated by:
    /// - did:key inline decoding (on first use)
    /// - gRPC IdentityConfig push (pre-resolved by Python)
    cached_keys: DashMap<String, VerifyingKey>,
}

impl DidVerifier {
    pub fn new() -> Self {
        Self {
            cached_keys: DashMap::new(),
        }
    }

    /// Verify an Ed25519 signature for a DID.
    ///
    /// Returns `Ok(())` if the signature is valid, `Err(VerificationFailed)` if invalid.
    ///
    /// 1. Look up VerifyingKey in cache
    /// 2. If not cached and did:key, resolve inline
    /// 3. Verify signature
    pub fn verify(
        &self,
        did: &str,
        message: &[u8],
        signature_bytes: &[u8],
    ) -> Result<(), IdentityError> {
        let key = self.resolve_key(did)?;

        let signature = Signature::from_slice(signature_bytes)
            .map_err(|_| IdentityError::VerificationFailed)?;

        key.verify(message, &signature)
            .map_err(|_| IdentityError::VerificationFailed)
    }

    /// Resolve a DID to a VerifyingKey.
    /// Cache hit: O(1) DashMap lookup (~10ns)
    /// Cache miss + did:key: inline decode (~1μs)
    /// Cache miss + other: error (must be pre-cached via gRPC push)
    pub fn resolve_key(&self, did: &str) -> Result<VerifyingKey, IdentityError> {
        // Check cache first
        if let Some(key) = self.cached_keys.get(did) {
            return Ok(*key.value());
        }

        // did:key can be resolved inline without network
        if did.starts_with("did:key:") {
            let key = Self::decode_did_key(did)?;
            self.cached_keys.insert(did.to_string(), key);
            return Ok(key);
        }

        // All other methods must be pre-cached by Python
        Err(IdentityError::NotCached(did.to_string()))
    }

    /// Decode a did:key DID to an Ed25519 VerifyingKey.
    ///
    /// Format: `did:key:z<multibase-base58btc-encoded-multicodec-key>`
    /// Multicodec prefix for Ed25519: `[0xed, 0x01]`
    fn decode_did_key(did: &str) -> Result<VerifyingKey, IdentityError> {
        let key_part = did
            .strip_prefix("did:key:z")
            .ok_or_else(|| IdentityError::InvalidDidKey("missing 'z' multibase prefix".into()))?;

        let decoded = bs58::decode(key_part)
            .into_vec()
            .map_err(|e| IdentityError::InvalidDidKey(format!("base58 decode: {e}")))?;

        // Verify multicodec prefix: 0xed 0x01 = Ed25519 public key
        if decoded.len() < 2 || decoded[0] != 0xed || decoded[1] != 0x01 {
            return Err(IdentityError::InvalidDidKey(
                "missing Ed25519 multicodec prefix (0xed01)".into(),
            ));
        }

        let key_bytes = &decoded[2..];
        if key_bytes.len() != 32 {
            return Err(IdentityError::InvalidDidKey(format!(
                "expected 32 bytes, got {}",
                key_bytes.len()
            )));
        }

        let key_array: &[u8; 32] = key_bytes.try_into().map_err(|_| {
            IdentityError::InvalidDidKey(format!("expected 32 bytes, got {}", key_bytes.len()))
        })?;
        let key = VerifyingKey::from_bytes(key_array)
            .map_err(|e| IdentityError::InvalidPublicKey(e.to_string()))?;
        if key.is_weak() {
            return Err(IdentityError::InvalidPublicKey(
                "weak/low-order public key".into(),
            ));
        }
        Ok(key)
    }

    /// Cache a pre-resolved public key (from Python gRPC push).
    ///
    /// If `overwrite` is false, returns `KeyAlreadyCached` when the DID already has a key.
    pub fn cache_key(
        &self,
        did: &str,
        public_key_bytes: &[u8],
        overwrite: bool,
    ) -> Result<(), IdentityError> {
        if public_key_bytes.len() != 32 {
            return Err(IdentityError::InvalidPublicKey(format!(
                "expected 32 bytes, got {}",
                public_key_bytes.len()
            )));
        }

        let key_array: &[u8; 32] = public_key_bytes.try_into().map_err(|_| {
            IdentityError::InvalidPublicKey(format!(
                "expected 32 bytes, got {}",
                public_key_bytes.len()
            ))
        })?;
        let key = VerifyingKey::from_bytes(key_array)
            .map_err(|e| IdentityError::InvalidPublicKey(e.to_string()))?;
        if key.is_weak() {
            return Err(IdentityError::InvalidPublicKey(
                "weak/low-order public key".into(),
            ));
        }

        if !overwrite && self.cached_keys.contains_key(did) {
            return Err(IdentityError::KeyAlreadyCached(did.to_string()));
        }
        self.cached_keys.insert(did.to_string(), key);
        Ok(())
    }

    /// Remove a cached key (agent deregistered).
    pub fn remove_key(&self, did: &str) -> bool {
        self.cached_keys.remove(did).is_some()
    }

    /// Clear all cached keys.
    pub fn clear_cache(&self) {
        self.cached_keys.clear();
    }

    /// Number of cached keys.
    pub fn cached_count(&self) -> usize {
        self.cached_keys.len()
    }
}

impl Default for DidVerifier {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ed25519_dalek::{Signer, SigningKey};

    /// Helper: generate a did:key from a signing key.
    fn signing_key_to_did(sk: &SigningKey) -> String {
        let vk = sk.verifying_key();
        let mut multicodec = vec![0xed, 0x01];
        multicodec.extend_from_slice(vk.as_bytes());
        format!("did:key:z{}", bs58::encode(&multicodec).into_string())
    }

    #[test]
    fn decode_did_key_valid() {
        let sk = SigningKey::from_bytes(&[1u8; 32]);
        let did = signing_key_to_did(&sk);
        let verifier = DidVerifier::new();
        let key = verifier.resolve_key(&did).unwrap();
        assert_eq!(key, sk.verifying_key());
    }

    #[test]
    fn decode_did_key_missing_prefix() {
        let verifier = DidVerifier::new();
        let result = verifier.resolve_key("did:key:abc");
        assert!(matches!(result, Err(IdentityError::InvalidDidKey(_))));
    }

    #[test]
    fn decode_did_key_wrong_multicodec() {
        // Encode with wrong multicodec prefix
        let mut bad = vec![0xaa, 0xbb];
        bad.extend_from_slice(&[0u8; 32]);
        let did = format!("did:key:z{}", bs58::encode(&bad).into_string());
        let verifier = DidVerifier::new();
        let result = verifier.resolve_key(&did);
        assert!(matches!(result, Err(IdentityError::InvalidDidKey(_))));
    }

    #[test]
    fn decode_did_key_wrong_length() {
        let mut short = vec![0xed, 0x01];
        short.extend_from_slice(&[0u8; 16]); // 16 bytes instead of 32
        let did = format!("did:key:z{}", bs58::encode(&short).into_string());
        let verifier = DidVerifier::new();
        let result = verifier.resolve_key(&did);
        assert!(matches!(result, Err(IdentityError::InvalidDidKey(_))));
    }

    #[test]
    fn verify_valid_signature() {
        let sk = SigningKey::from_bytes(&[2u8; 32]);
        let did = signing_key_to_did(&sk);
        let message = b"hello world";
        let sig = sk.sign(message);

        let verifier = DidVerifier::new();
        verifier.verify(&did, message, &sig.to_bytes()).unwrap();
    }

    #[test]
    fn verify_invalid_signature() {
        let sk = SigningKey::from_bytes(&[3u8; 32]);
        let did = signing_key_to_did(&sk);
        let message = b"hello world";
        let sig = sk.sign(b"different message");

        let verifier = DidVerifier::new();
        let result = verifier.verify(&did, message, &sig.to_bytes());
        assert!(matches!(result, Err(IdentityError::VerificationFailed)));
    }

    #[test]
    fn verify_wrong_key() {
        let sk1 = SigningKey::from_bytes(&[4u8; 32]);
        let sk2 = SigningKey::from_bytes(&[5u8; 32]);
        let did2 = signing_key_to_did(&sk2);
        let message = b"hello world";
        let sig = sk1.sign(message); // signed with sk1 but verifying with sk2's DID

        let verifier = DidVerifier::new();
        let result = verifier.verify(&did2, message, &sig.to_bytes());
        assert!(matches!(result, Err(IdentityError::VerificationFailed)));
    }

    #[test]
    fn reject_weak_key() {
        // The identity point (all zeros) is a weak/low-order point
        let weak_key_bytes = [0u8; 32];
        let verifier = DidVerifier::new();
        let result = verifier.cache_key("did:web:weak", &weak_key_bytes, true);
        assert!(matches!(result, Err(IdentityError::InvalidPublicKey(_))));
    }

    #[test]
    fn cache_key_and_resolve() {
        let sk = SigningKey::from_bytes(&[6u8; 32]);
        let vk = sk.verifying_key();
        let did = "did:web:example.com:agent-1";

        let verifier = DidVerifier::new();
        verifier.cache_key(did, vk.as_bytes(), true).unwrap();
        let resolved = verifier.resolve_key(did).unwrap();
        assert_eq!(resolved, vk);
    }

    #[test]
    fn cache_key_no_overwrite_rejects_duplicate() {
        let sk = SigningKey::from_bytes(&[6u8; 32]);
        let vk = sk.verifying_key();
        let did = "did:web:example.com:agent-dup";

        let verifier = DidVerifier::new();
        verifier.cache_key(did, vk.as_bytes(), false).unwrap();
        let result = verifier.cache_key(did, vk.as_bytes(), false);
        assert!(matches!(result, Err(IdentityError::KeyAlreadyCached(_))));
    }

    #[test]
    fn resolve_did_key_caches() {
        let sk = SigningKey::from_bytes(&[7u8; 32]);
        let did = signing_key_to_did(&sk);

        let verifier = DidVerifier::new();
        assert_eq!(verifier.cached_count(), 0);

        verifier.resolve_key(&did).unwrap();
        assert_eq!(verifier.cached_count(), 1);

        // Second resolve should be from cache
        verifier.resolve_key(&did).unwrap();
        assert_eq!(verifier.cached_count(), 1);
    }

    #[test]
    fn resolve_unknown_method_fails() {
        let verifier = DidVerifier::new();
        let result = verifier.resolve_key("did:web:example.com:not-cached");
        assert!(matches!(result, Err(IdentityError::NotCached(_))));
    }

    #[test]
    fn remove_key_works() {
        let sk = SigningKey::from_bytes(&[8u8; 32]);
        let vk = sk.verifying_key();
        let did = "did:web:example.com:agent-2";

        let verifier = DidVerifier::new();
        verifier.cache_key(did, vk.as_bytes(), true).unwrap();
        assert_eq!(verifier.cached_count(), 1);

        assert!(verifier.remove_key(did));
        assert_eq!(verifier.cached_count(), 0);

        let result = verifier.resolve_key(did);
        assert!(matches!(result, Err(IdentityError::NotCached(_))));
    }

    #[test]
    fn clear_cache_works() {
        let verifier = DidVerifier::new();
        for i in 0..3u8 {
            let sk = SigningKey::from_bytes(&[10 + i; 32]);
            let vk = sk.verifying_key();
            verifier
                .cache_key(
                    &format!("did:web:example.com:agent-{i}"),
                    vk.as_bytes(),
                    true,
                )
                .unwrap();
        }
        assert_eq!(verifier.cached_count(), 3);

        verifier.clear_cache();
        assert_eq!(verifier.cached_count(), 0);
    }
}
