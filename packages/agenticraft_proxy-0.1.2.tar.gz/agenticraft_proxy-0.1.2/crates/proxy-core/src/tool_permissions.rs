// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Formal tool permission verification (F8).
//!
//! Models a finite state automaton (FSA) for tool permission enforcement.
//! Python compiles CSP → LTS → FSA and pushes the transition table to Rust.
//! Rust enforces O(1) lookup per tool call via a flat `HashMap` keyed on
//! `(current_state, tool_name)`.
//!
//! [`ToolPermissionEngine`] manages per-agent permission graphs, tracking each
//! agent's current FSA state independently.

use std::collections::{HashMap, HashSet};

use dashmap::DashMap;

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/// FSA state identifier.
pub type ToolPermissionState = u32;

/// A single FSA transition: `(from_state, tool_name) → (to_state, allowed)`.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct ToolTransition {
    pub from_state: u32,
    pub tool_name: String,
    pub to_state: u32,
    pub allowed: bool,
}

// ---------------------------------------------------------------------------
// ToolPermissionResult
// ---------------------------------------------------------------------------

/// Result of checking a tool permission against the FSA.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ToolPermissionResult {
    /// The tool is allowed and the FSA advances to `next_state`.
    Allowed { next_state: u32 },
    /// The tool is explicitly denied in the current state.
    Denied {
        current_state: u32,
        tool_name: String,
    },
    /// No transition exists for this tool in the current state.
    Unknown {
        current_state: u32,
        tool_name: String,
    },
}

// ---------------------------------------------------------------------------
// ToolPermissionGraph
// ---------------------------------------------------------------------------

/// A compiled FSA transition table for tool permissions.
///
/// Transitions are stored as `state → { tool_name → (next_state, allowed) }`,
/// yielding O(1) lookup per tool call without allocating a `String` key on
/// each check (inner `HashMap<String, _>` supports `&str` lookups via `Borrow`).
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct ToolPermissionGraph {
    /// `state → { tool_name → (next_state, allowed) }`.
    transitions: HashMap<u32, HashMap<String, (u32, bool)>>,
    /// The FSA initial state.
    initial_state: u32,
    /// Set of accepting (terminal-ok) states.
    accepting_states: HashSet<u32>,
}

impl ToolPermissionGraph {
    /// Create a new, empty permission graph with the given initial state.
    pub fn new(initial_state: u32) -> Self {
        Self {
            transitions: HashMap::new(),
            initial_state,
            accepting_states: HashSet::new(),
        }
    }

    /// Build a graph from a batch of transitions.
    pub fn from_transitions(
        initial_state: u32,
        accepting_states: HashSet<u32>,
        transitions: Vec<ToolTransition>,
    ) -> Self {
        let mut graph = Self {
            transitions: HashMap::new(),
            initial_state,
            accepting_states,
        };
        for t in transitions {
            graph
                .transitions
                .entry(t.from_state)
                .or_default()
                .insert(t.tool_name, (t.to_state, t.allowed));
        }
        graph
    }

    /// Add a single transition to the graph.
    pub fn add_transition(&mut self, from: u32, tool_name: &str, to: u32, allowed: bool) {
        self.transitions
            .entry(from)
            .or_default()
            .insert(tool_name.to_string(), (to, allowed));
    }

    /// Check whether `tool_name` is permitted in `current_state`.
    ///
    /// O(1) HashMap lookup — no graph traversal, no allocation.
    pub fn check(&self, current_state: u32, tool_name: &str) -> ToolPermissionResult {
        match self
            .transitions
            .get(&current_state)
            .and_then(|m| m.get(tool_name))
        {
            Some(&(next_state, true)) => ToolPermissionResult::Allowed { next_state },
            Some(&(_, false)) => ToolPermissionResult::Denied {
                current_state,
                tool_name: tool_name.to_string(),
            },
            None => ToolPermissionResult::Unknown {
                current_state,
                tool_name: tool_name.to_string(),
            },
        }
    }

    /// The initial state of this FSA.
    pub fn initial_state(&self) -> u32 {
        self.initial_state
    }

    /// The set of accepting states.
    pub fn accepting_states(&self) -> &HashSet<u32> {
        &self.accepting_states
    }
}

// ---------------------------------------------------------------------------
// ToolPermissionStats
// ---------------------------------------------------------------------------

/// Summary statistics from [`ToolPermissionEngine::stats`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ToolPermissionStats {
    /// Number of permission graphs loaded (one per agent).
    pub graphs_loaded: usize,
    /// Number of agents currently tracked (have a current state).
    pub agents_tracked: usize,
}

// ---------------------------------------------------------------------------
// ToolPermissionEngine
// ---------------------------------------------------------------------------

/// Per-agent tool permission enforcement engine.
///
/// Manages one [`ToolPermissionGraph`] per agent and tracks each agent's
/// current FSA state independently. All operations are lock-free reads
/// via [`DashMap`].
pub struct ToolPermissionEngine {
    /// agent_id → compiled FSA graph.
    graphs: DashMap<String, ToolPermissionGraph>,
    /// agent_id → current FSA state.
    agent_states: DashMap<String, u32>,
}

impl ToolPermissionEngine {
    /// Create a new, empty engine.
    pub fn new() -> Self {
        Self {
            graphs: DashMap::new(),
            agent_states: DashMap::new(),
        }
    }

    /// Load (or replace) a permission graph for an agent.
    ///
    /// The agent's current state is reset to the graph's initial state.
    pub fn load_graph(&self, agent_id: &str, graph: ToolPermissionGraph) {
        let initial = graph.initial_state;
        self.graphs.insert(agent_id.to_string(), graph);
        self.agent_states.insert(agent_id.to_string(), initial);
    }

    /// Check whether `tool_name` is permitted for `agent_id` in its current state.
    ///
    /// Does **not** advance the agent's state. Returns [`ToolPermissionResult::Unknown`]
    /// if no graph is loaded for the agent.
    pub fn check_permission(&self, agent_id: &str, tool_name: &str) -> ToolPermissionResult {
        let graph = match self.graphs.get(agent_id) {
            Some(g) => g,
            None => {
                return ToolPermissionResult::Unknown {
                    current_state: 0,
                    tool_name: tool_name.to_string(),
                }
            }
        };

        let current_state = self
            .agent_states
            .get(agent_id)
            .map(|s| *s)
            .unwrap_or(graph.initial_state);

        graph.check(current_state, tool_name)
    }

    /// Check permission **and** advance the agent's FSA state if allowed.
    ///
    /// If the tool is allowed, the agent's current state is updated to the
    /// transition's `next_state`. Denied and Unknown results leave the state
    /// unchanged.
    pub fn advance(&self, agent_id: &str, tool_name: &str) -> ToolPermissionResult {
        let graph = match self.graphs.get(agent_id) {
            Some(g) => g,
            None => {
                return ToolPermissionResult::Unknown {
                    current_state: 0,
                    tool_name: tool_name.to_string(),
                }
            }
        };

        let current_state = self
            .agent_states
            .get(agent_id)
            .map(|s| *s)
            .unwrap_or(graph.initial_state);

        let result = graph.check(current_state, tool_name);

        if let ToolPermissionResult::Allowed { next_state } = &result {
            self.agent_states.insert(agent_id.to_string(), *next_state);
        }

        result
    }

    /// Reset an agent's FSA state back to its graph's initial state.
    ///
    /// No-op if the agent has no loaded graph.
    pub fn reset(&self, agent_id: &str) {
        if let Some(graph) = self.graphs.get(agent_id) {
            let initial = graph.initial_state;
            self.agent_states.insert(agent_id.to_string(), initial);
        }
    }

    /// Summary statistics.
    pub fn stats(&self) -> ToolPermissionStats {
        ToolPermissionStats {
            graphs_loaded: self.graphs.len(),
            agents_tracked: self.agent_states.len(),
        }
    }
}

impl Default for ToolPermissionEngine {
    fn default() -> Self {
        Self::new()
    }
}

// ---------------------------------------------------------------------------
// Unit tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    /// Helper: build a simple graph with three states and a few transitions.
    ///
    /// ```text
    ///   0 --[read]--> 1  (allowed)
    ///   1 --[write]--> 2 (allowed)
    ///   0 --[delete]--> 0 (denied)
    /// ```
    fn sample_graph() -> ToolPermissionGraph {
        let mut accepting = HashSet::new();
        accepting.insert(2);

        ToolPermissionGraph::from_transitions(
            0,
            accepting,
            vec![
                ToolTransition {
                    from_state: 0,
                    tool_name: "read".into(),
                    to_state: 1,
                    allowed: true,
                },
                ToolTransition {
                    from_state: 1,
                    tool_name: "write".into(),
                    to_state: 2,
                    allowed: true,
                },
                ToolTransition {
                    from_state: 0,
                    tool_name: "delete".into(),
                    to_state: 0,
                    allowed: false,
                },
            ],
        )
    }

    #[test]
    fn allowed_transition_returns_next_state() {
        let graph = sample_graph();
        let result = graph.check(0, "read");
        assert_eq!(result, ToolPermissionResult::Allowed { next_state: 1 });
    }

    #[test]
    fn denied_transition_returns_denied() {
        let graph = sample_graph();
        let result = graph.check(0, "delete");
        assert_eq!(
            result,
            ToolPermissionResult::Denied {
                current_state: 0,
                tool_name: "delete".into(),
            }
        );
    }

    #[test]
    fn unknown_tool_returns_unknown() {
        let graph = sample_graph();
        let result = graph.check(0, "execute");
        assert_eq!(
            result,
            ToolPermissionResult::Unknown {
                current_state: 0,
                tool_name: "execute".into(),
            }
        );
    }

    #[test]
    fn advance_updates_agent_state() {
        let engine = ToolPermissionEngine::new();
        engine.load_graph("agent-1", sample_graph());

        // Advance through read (0 → 1).
        let result = engine.advance("agent-1", "read");
        assert_eq!(result, ToolPermissionResult::Allowed { next_state: 1 });

        // Now the agent is in state 1; write should be allowed (1 → 2).
        let result = engine.advance("agent-1", "write");
        assert_eq!(result, ToolPermissionResult::Allowed { next_state: 2 });

        // read is not defined in state 2 → Unknown.
        let result = engine.check_permission("agent-1", "read");
        assert_eq!(
            result,
            ToolPermissionResult::Unknown {
                current_state: 2,
                tool_name: "read".into(),
            }
        );
    }

    #[test]
    fn reset_returns_to_initial_state() {
        let engine = ToolPermissionEngine::new();
        engine.load_graph("agent-2", sample_graph());

        // Advance to state 1.
        engine.advance("agent-2", "read");

        // Reset back to initial state 0.
        engine.reset("agent-2");

        // read should be available again from state 0.
        let result = engine.check_permission("agent-2", "read");
        assert_eq!(result, ToolPermissionResult::Allowed { next_state: 1 });
    }

    #[test]
    fn multiple_agents_have_independent_states() {
        let engine = ToolPermissionEngine::new();
        engine.load_graph("alpha", sample_graph());
        engine.load_graph("beta", sample_graph());

        // Advance alpha to state 1.
        engine.advance("alpha", "read");

        // Beta should still be in state 0.
        let alpha_result = engine.check_permission("alpha", "write");
        assert_eq!(
            alpha_result,
            ToolPermissionResult::Allowed { next_state: 2 },
            "alpha should be in state 1 (write available)"
        );

        let beta_result = engine.check_permission("beta", "write");
        assert_eq!(
            beta_result,
            ToolPermissionResult::Unknown {
                current_state: 0,
                tool_name: "write".into(),
            },
            "beta should still be in state 0 (write not available)"
        );

        // Stats should reflect both agents.
        let stats = engine.stats();
        assert_eq!(stats.graphs_loaded, 2);
        assert_eq!(stats.agents_tracked, 2);
    }
}
