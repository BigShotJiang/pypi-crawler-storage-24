// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Agent economy engine (F22).
//!
//! Per-agent metering and billing event log. Tracks token usage, cost, and
//! request counts across providers and tools. All meter counters use `AtomicU64`
//! with `fetch_add` for lock-free concurrent updates (metering is additive, so
//! there is no TOCTOU concern). The event log is bounded and protected by a
//! `parking_lot::RwLock`.

use std::collections::VecDeque;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{SystemTime, UNIX_EPOCH};

use dashmap::DashMap;
use parking_lot::RwLock;

/// Type of billing event.
#[derive(Debug, Clone, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[cfg_attr(feature = "serde", serde(rename_all = "snake_case"))]
pub enum BillingEventType {
    LlmCompletion,
    ToolCall,
    MemoryAccess,
    McpRequest,
    A2ATask,
}

/// A single billing event.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct BillingEvent {
    /// Unique event identifier.
    pub event_id: String,
    /// Agent that incurred the charge.
    pub agent_id: String,
    /// Type of event.
    pub event_type: BillingEventType,
    /// Tokens consumed.
    pub tokens: u64,
    /// Cost in micro-USD (1 USD = 1_000_000).
    pub cost_micro_usd: u64,
    /// Provider that served the request.
    pub provider_id: String,
    /// Tool name, if this event is a tool call.
    pub tool_name: Option<String>,
    /// Workflow ID, if part of a workflow.
    pub workflow_id: Option<String>,
    /// Unix timestamp in seconds.
    pub timestamp: u64,
}

/// Per-agent usage meter with atomic counters.
#[derive(Debug)]
pub struct AgentMeter {
    /// Agent identifier.
    pub agent_id: String,
    /// Total tokens consumed.
    pub total_tokens: AtomicU64,
    /// Total cost in micro-USD.
    pub total_cost_micro_usd: AtomicU64,
    /// Total number of requests.
    pub total_requests: AtomicU64,
    /// Tokens consumed per tool. Key: tool name.
    pub per_tool_tokens: DashMap<String, AtomicU64>,
    /// Tokens consumed per provider. Key: provider ID.
    pub per_provider_tokens: DashMap<String, AtomicU64>,
}

impl AgentMeter {
    /// Create a new meter for the given agent.
    pub fn new(agent_id: String) -> Self {
        Self {
            agent_id,
            total_tokens: AtomicU64::new(0),
            total_cost_micro_usd: AtomicU64::new(0),
            total_requests: AtomicU64::new(0),
            per_tool_tokens: DashMap::new(),
            per_provider_tokens: DashMap::new(),
        }
    }

    /// Record usage against this meter.
    fn record(&self, tokens: u64, cost_micro_usd: u64, provider_id: &str, tool_name: Option<&str>) {
        self.total_tokens.fetch_add(tokens, Ordering::Relaxed);
        self.total_cost_micro_usd
            .fetch_add(cost_micro_usd, Ordering::Relaxed);
        self.total_requests.fetch_add(1, Ordering::Relaxed);

        // Per-provider tracking
        self.per_provider_tokens
            .entry(provider_id.to_string())
            .or_insert_with(|| AtomicU64::new(0))
            .fetch_add(tokens, Ordering::Relaxed);

        // Per-tool tracking (only if a tool name is provided)
        if let Some(tool) = tool_name {
            self.per_tool_tokens
                .entry(tool.to_string())
                .or_insert_with(|| AtomicU64::new(0))
                .fetch_add(tokens, Ordering::Relaxed);
        }
    }

    /// Take a point-in-time snapshot of this meter.
    pub fn snapshot(&self) -> AgentMeterSnapshot {
        AgentMeterSnapshot {
            agent_id: self.agent_id.clone(),
            total_tokens: self.total_tokens.load(Ordering::Relaxed),
            total_cost_micro_usd: self.total_cost_micro_usd.load(Ordering::Relaxed),
            total_requests: self.total_requests.load(Ordering::Relaxed),
        }
    }
}

/// Point-in-time snapshot of an agent's meter (all plain values, no atomics).
#[derive(Debug, Clone, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct AgentMeterSnapshot {
    pub agent_id: String,
    pub total_tokens: u64,
    pub total_cost_micro_usd: u64,
    pub total_requests: u64,
}

/// Aggregate statistics across all agents.
#[derive(Debug, Clone, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct EconomyStats {
    /// Number of tracked agents.
    pub total_agents: usize,
    /// Total billing events recorded.
    pub total_events: usize,
    /// Sum of all tokens across all agents.
    pub total_tokens_all: u64,
    /// Sum of all costs across all agents (micro-USD).
    pub total_cost_all_micro_usd: u64,
}

/// Central economy engine that manages agent meters and billing events.
pub struct EconomyEngine {
    /// Per-agent meters. Key: agent_id.
    meters: DashMap<String, AgentMeter>,
    /// Bounded billing event log (VecDeque for O(1) front eviction).
    events: RwLock<VecDeque<BillingEvent>>,
    /// Monotonically increasing event ID counter.
    next_event_id: AtomicU64,
    /// Maximum number of events to retain.
    max_events: usize,
}

impl EconomyEngine {
    /// Create a new economy engine with the given event history capacity.
    pub fn new(max_events: usize) -> Self {
        Self {
            meters: DashMap::new(),
            events: RwLock::new(VecDeque::with_capacity(max_events.min(4096))),
            next_event_id: AtomicU64::new(0),
            max_events,
        }
    }

    /// Record a billing event.
    ///
    /// Creates a `BillingEvent`, updates the agent's `AgentMeter` atomically,
    /// and appends the event to the bounded history.
    #[allow(clippy::too_many_arguments)]
    pub fn record(
        &self,
        agent_id: &str,
        event_type: BillingEventType,
        tokens: u64,
        cost_micro_usd: u64,
        provider_id: &str,
        tool_name: Option<&str>,
        workflow_id: Option<&str>,
    ) -> BillingEvent {
        let event_id = self.next_event_id.fetch_add(1, Ordering::Relaxed);
        let timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();

        let event = BillingEvent {
            event_id: event_id.to_string(),
            agent_id: agent_id.to_string(),
            event_type,
            tokens,
            cost_micro_usd,
            provider_id: provider_id.to_string(),
            tool_name: tool_name.map(|s| s.to_string()),
            workflow_id: workflow_id.map(|s| s.to_string()),
            timestamp,
        };

        // Update (or create) the agent meter
        let meter = self
            .meters
            .entry(agent_id.to_string())
            .or_insert_with(|| AgentMeter::new(agent_id.to_string()));
        meter.record(tokens, cost_micro_usd, provider_id, tool_name);

        // Append to bounded event log
        {
            let mut events = self.events.write();
            if events.len() >= self.max_events {
                // O(1) eviction of oldest event
                events.pop_front();
            }
            events.push_back(event.clone());
        }

        event
    }

    /// Get a snapshot of the meter for a specific agent.
    pub fn get_meter(&self, agent_id: &str) -> Option<AgentMeterSnapshot> {
        self.meters.get(agent_id).map(|m| m.snapshot())
    }

    /// Get recent billing events for a specific agent, up to `limit`.
    ///
    /// Returns events in chronological order (oldest first).
    pub fn get_events(&self, agent_id: &str, limit: usize) -> Vec<BillingEvent> {
        let events = self.events.read();
        let matching: Vec<_> = events
            .iter()
            .filter(|e| e.agent_id == agent_id)
            .cloned()
            .collect();
        let skip = matching.len().saturating_sub(limit);
        matching.into_iter().skip(skip).collect()
    }

    /// Get aggregate statistics across all agents.
    pub fn stats(&self) -> EconomyStats {
        let mut total_tokens_all = 0u64;
        let mut total_cost_all_micro_usd = 0u64;

        for entry in self.meters.iter() {
            total_tokens_all += entry.value().total_tokens.load(Ordering::Relaxed);
            total_cost_all_micro_usd += entry.value().total_cost_micro_usd.load(Ordering::Relaxed);
        }

        let total_events = self.events.read().len();

        EconomyStats {
            total_agents: self.meters.len(),
            total_events,
            total_tokens_all,
            total_cost_all_micro_usd,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn record_event_updates_agent_meter() {
        let engine = EconomyEngine::new(100);

        engine.record(
            "agent-1",
            BillingEventType::LlmCompletion,
            500,
            1_000,
            "openai",
            None,
            None,
        );

        let snap = engine.get_meter("agent-1").unwrap();
        assert_eq!(snap.agent_id, "agent-1");
        assert_eq!(snap.total_tokens, 500);
        assert_eq!(snap.total_cost_micro_usd, 1_000);
        assert_eq!(snap.total_requests, 1);
    }

    #[test]
    fn multiple_events_accumulate() {
        let engine = EconomyEngine::new(100);

        engine.record(
            "agent-1",
            BillingEventType::LlmCompletion,
            500,
            1_000,
            "openai",
            None,
            None,
        );
        engine.record(
            "agent-1",
            BillingEventType::McpRequest,
            200,
            400,
            "anthropic",
            None,
            Some("wf-1"),
        );
        engine.record(
            "agent-1",
            BillingEventType::ToolCall,
            100,
            200,
            "openai",
            Some("search"),
            None,
        );

        let snap = engine.get_meter("agent-1").unwrap();
        assert_eq!(snap.total_tokens, 800);
        assert_eq!(snap.total_cost_micro_usd, 1_600);
        assert_eq!(snap.total_requests, 3);
    }

    #[test]
    fn per_tool_token_tracking() {
        let engine = EconomyEngine::new(100);

        engine.record(
            "agent-1",
            BillingEventType::ToolCall,
            300,
            600,
            "openai",
            Some("search"),
            None,
        );
        engine.record(
            "agent-1",
            BillingEventType::ToolCall,
            200,
            400,
            "openai",
            Some("search"),
            None,
        );
        engine.record(
            "agent-1",
            BillingEventType::ToolCall,
            100,
            200,
            "openai",
            Some("calculator"),
            None,
        );

        let meter = engine.meters.get("agent-1").unwrap();
        let search_tokens = meter
            .per_tool_tokens
            .get("search")
            .unwrap()
            .load(Ordering::Relaxed);
        assert_eq!(search_tokens, 500);

        let calc_tokens = meter
            .per_tool_tokens
            .get("calculator")
            .unwrap()
            .load(Ordering::Relaxed);
        assert_eq!(calc_tokens, 100);
    }

    #[test]
    fn per_provider_token_tracking() {
        let engine = EconomyEngine::new(100);

        engine.record(
            "agent-1",
            BillingEventType::LlmCompletion,
            400,
            800,
            "openai",
            None,
            None,
        );
        engine.record(
            "agent-1",
            BillingEventType::LlmCompletion,
            300,
            900,
            "anthropic",
            None,
            None,
        );
        engine.record(
            "agent-1",
            BillingEventType::LlmCompletion,
            100,
            200,
            "openai",
            None,
            None,
        );

        let meter = engine.meters.get("agent-1").unwrap();
        let openai_tokens = meter
            .per_provider_tokens
            .get("openai")
            .unwrap()
            .load(Ordering::Relaxed);
        assert_eq!(openai_tokens, 500);

        let anthropic_tokens = meter
            .per_provider_tokens
            .get("anthropic")
            .unwrap()
            .load(Ordering::Relaxed);
        assert_eq!(anthropic_tokens, 300);
    }

    #[test]
    fn event_history_bounded_at_max() {
        let engine = EconomyEngine::new(3);

        for i in 0..5 {
            engine.record(
                "agent-1",
                BillingEventType::LlmCompletion,
                100,
                200,
                "openai",
                None,
                Some(&format!("wf-{i}")),
            );
        }

        let events = engine.get_events("agent-1", 10);
        assert_eq!(events.len(), 3);

        // Should retain the 3 most recent events (IDs 2, 3, 4)
        assert_eq!(events[0].event_id, "2");
        assert_eq!(events[1].event_id, "3");
        assert_eq!(events[2].event_id, "4");
    }

    #[test]
    fn stats_aggregate_across_agents() {
        let engine = EconomyEngine::new(100);

        engine.record(
            "agent-1",
            BillingEventType::LlmCompletion,
            500,
            1_000,
            "openai",
            None,
            None,
        );
        engine.record(
            "agent-2",
            BillingEventType::ToolCall,
            300,
            600,
            "anthropic",
            Some("search"),
            None,
        );
        engine.record(
            "agent-1",
            BillingEventType::MemoryAccess,
            200,
            400,
            "openai",
            None,
            None,
        );

        let stats = engine.stats();
        assert_eq!(stats.total_agents, 2);
        assert_eq!(stats.total_events, 3);
        assert_eq!(stats.total_tokens_all, 1_000);
        assert_eq!(stats.total_cost_all_micro_usd, 2_000);
    }
}
