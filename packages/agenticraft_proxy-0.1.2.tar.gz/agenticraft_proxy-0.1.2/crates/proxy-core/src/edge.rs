// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Edge proxy with offline-first capabilities (F24).
//!
//! Enables agents deployed at the edge to continue operating when connectivity
//! to the backend is lost. Requests are queued locally, prioritised, and
//! replayed in batch once connectivity is restored.
//!
//! ## Components
//!
//! - **`EdgeMode`** — Online, OfflineFirst, or Hybrid operating mode.
//! - **`OfflineQueue`** — Bounded, priority-aware request queue backed by
//!   `VecDeque` under a `RwLock`.
//! - **`ConnectivityMonitor`** — Lock-free reachability tracker using atomics.
//! - **`SyncEngine`** — Tracks pending / completed sync counts for replay.
//! - **`EdgeManager`** — Top-level coordinator that ties the above together.

use std::collections::VecDeque;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};

use parking_lot::RwLock;
use thiserror::Error;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------

/// Errors returned by edge proxy operations.
#[derive(Debug, Error)]
pub enum EdgeError {
    #[error("offline queue is full ({capacity} items)")]
    QueueFull { capacity: usize },

    #[error("offline queue is empty")]
    QueueEmpty,

    #[error("connectivity lost: {consecutive_failures} consecutive failures")]
    ConnectivityLost { consecutive_failures: u64 },
}

// ---------------------------------------------------------------------------
// EdgeMode
// ---------------------------------------------------------------------------

/// Operating mode for the edge proxy.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum EdgeMode {
    /// Always forward to backend; fail if unreachable.
    #[default]
    Online,
    /// Queue locally first, sync to backend opportunistically.
    OfflineFirst,
    /// Forward when connected, queue when disconnected.
    Hybrid,
}

impl std::fmt::Display for EdgeMode {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Online => write!(f, "online"),
            Self::OfflineFirst => write!(f, "offline_first"),
            Self::Hybrid => write!(f, "hybrid"),
        }
    }
}

// ---------------------------------------------------------------------------
// QueuedRequest
// ---------------------------------------------------------------------------

/// A request buffered while the backend is unreachable.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct QueuedRequest {
    /// Unique identifier for this request.
    pub request_id: String,
    /// Agent that originated the request.
    pub agent_id: String,
    /// Serialised request payload.
    pub payload: Vec<u8>,
    /// Unix timestamp (seconds) when the request was queued.
    pub queued_at: u64,
    /// Priority (higher = more important). Used for eviction decisions.
    pub priority: u8,
    /// Number of times this request has been retried.
    pub retries: u32,
}

// ---------------------------------------------------------------------------
// OfflineQueue
// ---------------------------------------------------------------------------

/// Bounded, priority-aware request queue for offline operation.
///
/// When the queue is at capacity, `enqueue` evicts the oldest low-priority
/// request to make room. If every queued request has priority >= the incoming
/// request, the enqueue is rejected.
pub struct OfflineQueue {
    queue: RwLock<VecDeque<QueuedRequest>>,
    max_queue_size: usize,
    total_enqueued: AtomicU64,
    total_dropped: AtomicU64,
}

impl OfflineQueue {
    /// Create a new offline queue with the given capacity.
    pub fn new(max_queue_size: usize) -> Self {
        Self {
            queue: RwLock::new(VecDeque::with_capacity(max_queue_size)),
            max_queue_size,
            total_enqueued: AtomicU64::new(0),
            total_dropped: AtomicU64::new(0),
        }
    }

    /// Add a request to the queue.
    ///
    /// If the queue is at capacity, the oldest request whose priority is
    /// strictly less than the incoming request's priority is evicted. If no
    /// such request exists, the enqueue fails with [`EdgeError::QueueFull`].
    pub fn enqueue(&self, request: QueuedRequest) -> Result<(), EdgeError> {
        let mut q = self.queue.write();

        if q.len() >= self.max_queue_size {
            // Find the first (oldest) entry with strictly lower priority.
            let evict_idx = q.iter().position(|r| r.priority < request.priority);
            match evict_idx {
                Some(idx) => {
                    q.remove(idx);
                    self.total_dropped.fetch_add(1, Ordering::Relaxed);
                }
                None => {
                    return Err(EdgeError::QueueFull {
                        capacity: self.max_queue_size,
                    });
                }
            }
        }

        q.push_back(request);
        self.total_enqueued.fetch_add(1, Ordering::Relaxed);
        Ok(())
    }

    /// Pop the highest-priority request from the front of the queue.
    ///
    /// Scans the queue and removes the first request with the highest
    /// priority value (FIFO among equal priorities).
    pub fn dequeue(&self) -> Result<QueuedRequest, EdgeError> {
        let mut q = self.queue.write();

        if q.is_empty() {
            return Err(EdgeError::QueueEmpty);
        }

        // Find the index of the highest-priority request (first occurrence).
        let mut best_idx = 0;
        let mut best_priority = q[0].priority;
        for (i, r) in q.iter().enumerate().skip(1) {
            if r.priority > best_priority {
                best_priority = r.priority;
                best_idx = i;
            }
        }

        q.remove(best_idx).ok_or(EdgeError::QueueEmpty)
    }

    /// Drain all queued requests for replay. Returns them in queue order.
    pub fn drain(&self) -> Vec<QueuedRequest> {
        let mut q = self.queue.write();
        q.drain(..).collect()
    }

    /// Number of requests currently in the queue.
    pub fn len(&self) -> usize {
        self.queue.read().len()
    }

    /// Whether the queue is empty.
    pub fn is_empty(&self) -> bool {
        self.queue.read().is_empty()
    }

    /// Total number of requests ever enqueued.
    pub fn total_enqueued(&self) -> u64 {
        self.total_enqueued.load(Ordering::Relaxed)
    }

    /// Total number of requests evicted to make room.
    pub fn total_dropped(&self) -> u64 {
        self.total_dropped.load(Ordering::Relaxed)
    }
}

// ---------------------------------------------------------------------------
// ConnectivityMonitor
// ---------------------------------------------------------------------------

/// Lock-free backend reachability tracker.
///
/// Uses atomic operations so health probes on the hot path never contend
/// with request processing.
pub struct ConnectivityMonitor {
    is_connected: AtomicBool,
    last_check_timestamp: AtomicU64,
    consecutive_failures: AtomicU64,
    /// Number of consecutive failures before we declare disconnected.
    failure_threshold: u64,
}

impl ConnectivityMonitor {
    /// Create a new monitor that starts in the connected state.
    pub fn new(failure_threshold: u64) -> Self {
        Self {
            is_connected: AtomicBool::new(true),
            last_check_timestamp: AtomicU64::new(0),
            consecutive_failures: AtomicU64::new(0),
            failure_threshold,
        }
    }

    /// Record a successful health check / response from the backend.
    pub fn record_success(&self) {
        self.consecutive_failures.store(0, Ordering::Relaxed);
        self.is_connected.store(true, Ordering::Release);
    }

    /// Record a failed health check / response from the backend.
    ///
    /// After `failure_threshold` consecutive failures the monitor transitions
    /// to disconnected.
    pub fn record_failure(&self) {
        let prev = self.consecutive_failures.fetch_add(1, Ordering::Relaxed);
        // prev is the value *before* the add, so prev + 1 is the new count.
        if prev + 1 >= self.failure_threshold {
            self.is_connected.store(false, Ordering::Release);
        }
    }

    /// Whether the backend is currently considered reachable.
    pub fn is_connected(&self) -> bool {
        self.is_connected.load(Ordering::Acquire)
    }

    /// Update the last-check timestamp (unix seconds).
    pub fn set_last_check(&self, timestamp: u64) {
        self.last_check_timestamp
            .store(timestamp, Ordering::Relaxed);
    }

    /// Last health-check timestamp.
    pub fn last_check_timestamp(&self) -> u64 {
        self.last_check_timestamp.load(Ordering::Relaxed)
    }

    /// Current consecutive failure count.
    pub fn consecutive_failures(&self) -> u64 {
        self.consecutive_failures.load(Ordering::Relaxed)
    }
}

// ---------------------------------------------------------------------------
// SyncEngine
// ---------------------------------------------------------------------------

/// Sync statistics snapshot.
#[derive(Debug, Clone, Default)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct SyncStats {
    /// Number of requests awaiting sync to backend.
    pub pending: u64,
    /// Total requests successfully synced.
    pub total_synced: u64,
    /// Configured batch size.
    pub batch_size: usize,
}

/// Manages offline-to-online replay bookkeeping.
pub struct SyncEngine {
    sync_batch_size: usize,
    pending_sync: AtomicU64,
    total_synced: AtomicU64,
}

impl SyncEngine {
    /// Create a new sync engine with the given batch size.
    pub fn new(sync_batch_size: usize) -> Self {
        Self {
            sync_batch_size,
            pending_sync: AtomicU64::new(0),
            total_synced: AtomicU64::new(0),
        }
    }

    /// Mark `count` requests as pending sync.
    pub fn mark_pending(&self, count: u64) {
        self.pending_sync.fetch_add(count, Ordering::Relaxed);
    }

    /// Mark one request as successfully synced.
    pub fn mark_synced(&self) {
        // CAS loop prevents TOCTOU: without this, two threads could both
        // load pending=1, both pass the >0 check, and both subtract —
        // wrapping pending_sync to u64::MAX.
        let _ = self
            .pending_sync
            .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |prev| {
                if prev > 0 {
                    Some(prev - 1)
                } else {
                    None
                }
            });
        self.total_synced.fetch_add(1, Ordering::Relaxed);
    }

    /// Current sync statistics.
    pub fn stats(&self) -> SyncStats {
        SyncStats {
            pending: self.pending_sync.load(Ordering::Relaxed),
            total_synced: self.total_synced.load(Ordering::Relaxed),
            batch_size: self.sync_batch_size,
        }
    }

    /// Configured batch size for replay.
    pub fn batch_size(&self) -> usize {
        self.sync_batch_size
    }
}

// ---------------------------------------------------------------------------
// EdgeStats
// ---------------------------------------------------------------------------

/// Aggregate statistics for the edge proxy.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct EdgeStats {
    /// Current operating mode.
    pub mode: EdgeMode,
    /// Whether the backend is reachable.
    pub is_connected: bool,
    /// Number of requests currently queued.
    pub queued_count: usize,
    /// Total requests ever enqueued.
    pub total_queued: u64,
    /// Total requests successfully synced to backend.
    pub total_synced: u64,
    /// Total requests dropped (evicted from queue).
    pub total_dropped: u64,
    /// Current consecutive backend failures.
    pub consecutive_failures: u64,
}

// ---------------------------------------------------------------------------
// EdgeManager
// ---------------------------------------------------------------------------

/// Top-level coordinator for edge proxy operations.
///
/// Decides whether to forward requests directly (online) or queue them
/// locally (offline / hybrid) based on the current [`EdgeMode`] and
/// backend connectivity.
pub struct EdgeManager {
    mode: EdgeMode,
    queue: OfflineQueue,
    connectivity: ConnectivityMonitor,
    sync: SyncEngine,
}

impl EdgeManager {
    /// Create a new edge manager.
    pub fn new(mode: EdgeMode, max_queue_size: usize, failure_threshold: u64) -> Self {
        Self {
            mode,
            queue: OfflineQueue::new(max_queue_size),
            connectivity: ConnectivityMonitor::new(failure_threshold),
            sync: SyncEngine::new(10),
        }
    }

    /// Create an edge manager with a custom sync batch size.
    pub fn with_sync_batch_size(
        mode: EdgeMode,
        max_queue_size: usize,
        failure_threshold: u64,
        sync_batch_size: usize,
    ) -> Self {
        Self {
            mode,
            queue: OfflineQueue::new(max_queue_size),
            connectivity: ConnectivityMonitor::new(failure_threshold),
            sync: SyncEngine::new(sync_batch_size),
        }
    }

    /// Submit a request through the edge proxy.
    ///
    /// Returns `Ok(true)` if the request should be forwarded to the backend
    /// immediately (pass-through). Returns `Ok(false)` if the request was
    /// queued for later replay. Returns `Err` if the request could not be
    /// queued (e.g., queue full in offline mode, or connectivity lost in
    /// online mode).
    pub fn submit_request(&self, request: QueuedRequest) -> Result<bool, EdgeError> {
        match self.mode {
            EdgeMode::Online => {
                if self.connectivity.is_connected() {
                    Ok(true)
                } else {
                    Err(EdgeError::ConnectivityLost {
                        consecutive_failures: self.connectivity.consecutive_failures(),
                    })
                }
            }
            EdgeMode::OfflineFirst => {
                self.queue.enqueue(request)?;
                Ok(false)
            }
            EdgeMode::Hybrid => {
                if self.connectivity.is_connected() {
                    Ok(true)
                } else {
                    self.queue.enqueue(request)?;
                    Ok(false)
                }
            }
        }
    }

    /// Called when connectivity is restored.
    ///
    /// Resets the connectivity monitor, drains the offline queue, marks the
    /// drained requests as pending sync, and returns them for replay.
    pub fn on_connectivity_restored(&self) -> Vec<QueuedRequest> {
        self.connectivity.record_success();
        let requests = self.queue.drain();
        let count = requests.len() as u64;
        if count > 0 {
            self.sync.mark_pending(count);
        }
        requests
    }

    /// Record a successful backend interaction.
    pub fn record_success(&self) {
        self.connectivity.record_success();
    }

    /// Record a failed backend interaction.
    pub fn record_failure(&self) {
        self.connectivity.record_failure();
    }

    /// Mark a single request as successfully synced.
    pub fn mark_synced(&self) {
        self.sync.mark_synced();
    }

    /// Current operating mode.
    pub fn mode(&self) -> EdgeMode {
        self.mode
    }

    /// Reference to the connectivity monitor.
    pub fn connectivity(&self) -> &ConnectivityMonitor {
        &self.connectivity
    }

    /// Reference to the offline queue.
    pub fn queue(&self) -> &OfflineQueue {
        &self.queue
    }

    /// Reference to the sync engine.
    pub fn sync_engine(&self) -> &SyncEngine {
        &self.sync
    }

    /// Aggregate statistics snapshot.
    pub fn stats(&self) -> EdgeStats {
        let sync_stats = self.sync.stats();
        EdgeStats {
            mode: self.mode,
            is_connected: self.connectivity.is_connected(),
            queued_count: self.queue.len(),
            total_queued: self.queue.total_enqueued(),
            total_synced: sync_stats.total_synced,
            total_dropped: self.queue.total_dropped(),
            consecutive_failures: self.connectivity.consecutive_failures(),
        }
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    fn make_request(id: &str, agent: &str, priority: u8) -> QueuedRequest {
        QueuedRequest {
            request_id: id.to_string(),
            agent_id: agent.to_string(),
            payload: vec![1, 2, 3],
            queued_at: 1000,
            priority,
            retries: 0,
        }
    }

    #[test]
    fn enqueue_dequeue_priority_ordering() {
        let queue = OfflineQueue::new(10);

        queue.enqueue(make_request("r1", "a1", 1)).unwrap();
        queue.enqueue(make_request("r2", "a1", 5)).unwrap();
        queue.enqueue(make_request("r3", "a1", 3)).unwrap();

        // Dequeue should return highest priority first.
        let r = queue.dequeue().unwrap();
        assert_eq!(r.request_id, "r2");
        assert_eq!(r.priority, 5);

        let r = queue.dequeue().unwrap();
        assert_eq!(r.request_id, "r3");
        assert_eq!(r.priority, 3);

        let r = queue.dequeue().unwrap();
        assert_eq!(r.request_id, "r1");
        assert_eq!(r.priority, 1);

        assert!(queue.dequeue().is_err());
    }

    #[test]
    fn queue_capacity_eviction() {
        let queue = OfflineQueue::new(3);

        queue.enqueue(make_request("r1", "a1", 1)).unwrap();
        queue.enqueue(make_request("r2", "a1", 2)).unwrap();
        queue.enqueue(make_request("r3", "a1", 3)).unwrap();
        assert_eq!(queue.len(), 3);

        // Queue is full. Enqueue a high-priority request — should evict the
        // oldest low-priority entry (r1, priority 1).
        queue.enqueue(make_request("r4", "a1", 5)).unwrap();
        assert_eq!(queue.len(), 3);
        assert_eq!(queue.total_dropped(), 1);

        // All remaining items should be r2 (prio 2), r3 (prio 3), r4 (prio 5).
        let items = queue.drain();
        let ids: Vec<&str> = items.iter().map(|r| r.request_id.as_str()).collect();
        assert_eq!(ids, vec!["r2", "r3", "r4"]);

        // Enqueueing when all existing have same priority should fail.
        let queue2 = OfflineQueue::new(2);
        queue2.enqueue(make_request("x1", "a1", 5)).unwrap();
        queue2.enqueue(make_request("x2", "a1", 5)).unwrap();
        let result = queue2.enqueue(make_request("x3", "a1", 5));
        assert!(result.is_err());
    }

    #[test]
    fn connectivity_monitor_threshold() {
        let monitor = ConnectivityMonitor::new(3);
        assert!(monitor.is_connected());

        // Two failures — still connected.
        monitor.record_failure();
        monitor.record_failure();
        assert!(monitor.is_connected());
        assert_eq!(monitor.consecutive_failures(), 2);

        // Third failure — disconnected.
        monitor.record_failure();
        assert!(!monitor.is_connected());
        assert_eq!(monitor.consecutive_failures(), 3);

        // Success resets.
        monitor.record_success();
        assert!(monitor.is_connected());
        assert_eq!(monitor.consecutive_failures(), 0);
    }

    #[test]
    fn submit_request_offline_mode_queues() {
        let mgr = EdgeManager::new(EdgeMode::OfflineFirst, 100, 3);

        let req = make_request("r1", "a1", 5);
        let result = mgr.submit_request(req).unwrap();

        // OfflineFirst always queues — returns false (not pass-through).
        assert!(!result);
        assert_eq!(mgr.queue().len(), 1);
    }

    #[test]
    fn submit_request_hybrid_queues_when_disconnected() {
        let mgr = EdgeManager::new(EdgeMode::Hybrid, 100, 3);

        // While connected, pass-through.
        let req = make_request("r1", "a1", 5);
        assert!(mgr.submit_request(req).unwrap());
        assert_eq!(mgr.queue().len(), 0);

        // Simulate disconnection.
        mgr.record_failure();
        mgr.record_failure();
        mgr.record_failure();
        assert!(!mgr.connectivity().is_connected());

        // Now requests should be queued.
        let req2 = make_request("r2", "a1", 5);
        let result = mgr.submit_request(req2).unwrap();
        assert!(!result);
        assert_eq!(mgr.queue().len(), 1);
    }

    #[test]
    fn on_connectivity_restored_drains_queue() {
        let mgr = EdgeManager::new(EdgeMode::OfflineFirst, 100, 3);

        // Queue several requests.
        for i in 0..5 {
            let req = make_request(&format!("r{i}"), "a1", 3);
            mgr.submit_request(req).unwrap();
        }
        assert_eq!(mgr.queue().len(), 5);

        // Restore connectivity — should drain all.
        let drained = mgr.on_connectivity_restored();
        assert_eq!(drained.len(), 5);
        assert_eq!(mgr.queue().len(), 0);

        // Sync engine should show 5 pending.
        let sync_stats = mgr.sync_engine().stats();
        assert_eq!(sync_stats.pending, 5);

        // Mark them synced one by one.
        for _ in 0..5 {
            mgr.mark_synced();
        }
        let sync_stats = mgr.sync_engine().stats();
        assert_eq!(sync_stats.pending, 0);
        assert_eq!(sync_stats.total_synced, 5);
    }

    #[test]
    fn stats_accuracy() {
        let mgr = EdgeManager::new(EdgeMode::Hybrid, 50, 3);

        // Start connected.
        let s = mgr.stats();
        assert_eq!(s.mode, EdgeMode::Hybrid);
        assert!(s.is_connected);
        assert_eq!(s.queued_count, 0);
        assert_eq!(s.total_queued, 0);
        assert_eq!(s.total_synced, 0);
        assert_eq!(s.total_dropped, 0);
        assert_eq!(s.consecutive_failures, 0);

        // Disconnect and queue requests.
        mgr.record_failure();
        mgr.record_failure();
        mgr.record_failure();

        for i in 0..3 {
            let req = make_request(&format!("r{i}"), "a1", 5);
            mgr.submit_request(req).unwrap();
        }

        let s = mgr.stats();
        assert!(!s.is_connected);
        assert_eq!(s.queued_count, 3);
        assert_eq!(s.total_queued, 3);
        assert_eq!(s.consecutive_failures, 3);

        // Restore and sync.
        let drained = mgr.on_connectivity_restored();
        assert_eq!(drained.len(), 3);
        for _ in 0..3 {
            mgr.mark_synced();
        }

        let s = mgr.stats();
        assert!(s.is_connected);
        assert_eq!(s.queued_count, 0);
        assert_eq!(s.total_queued, 3);
        assert_eq!(s.total_synced, 3);
        assert_eq!(s.total_dropped, 0);
    }
}
