// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Multi-agent transaction coordination using the Saga pattern (F11).
//!
//! Orchestrates multi-step distributed transactions across agent boundaries.
//! Each saga consists of an ordered sequence of steps (A2A tasks, MCP tool
//! calls, HTTP requests, or custom actions). If any step fails, previously
//! completed steps are compensated in reverse order.
//!
//! ## Concurrency model
//!
//! - `DashMap` for the saga registry (lock-free reads, sharded writes).
//! - `parking_lot::RwLock` per saga for interior mutability of step state.
//! - `AtomicU64` for aggregate counters (no lock needed for stats).

use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{SystemTime, UNIX_EPOCH};

use dashmap::DashMap;
use parking_lot::RwLock;
use thiserror::Error;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------

/// Errors returned by saga coordination operations.
#[derive(Debug, Error, Clone, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum SagaError {
    /// The requested saga does not exist.
    #[error("saga not found: `{saga_id}`")]
    SagaNotFound { saga_id: String },

    /// A saga with the given ID already exists.
    #[error("saga already exists: `{saga_id}`")]
    SagaAlreadyExists { saga_id: String },

    /// The saga is in a state that does not permit the requested operation.
    #[error("invalid state for saga `{saga_id}`: current state is {state:?}")]
    InvalidState { saga_id: String, state: SagaState },

    /// The referenced step does not exist within the saga.
    #[error("step not found: `{step_id}` in saga `{saga_id}`")]
    StepNotFound { saga_id: String, step_id: String },
}

// ---------------------------------------------------------------------------
// Step types
// ---------------------------------------------------------------------------

/// The kind of action a saga step performs.
#[derive(Debug, Clone, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum SagaStepType {
    /// An Agent-to-Agent protocol task.
    A2ATask,
    /// A Model Context Protocol tool invocation.
    McpToolCall,
    /// A plain HTTP request.
    HttpRequest,
    /// A user-defined action type.
    Custom(String),
}

// ---------------------------------------------------------------------------
// States
// ---------------------------------------------------------------------------

/// Top-level state of a saga.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum SagaState {
    Created,
    Running,
    Completed,
    Failed,
    Compensating,
    Compensated,
}

/// Status of an individual saga step.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum SagaStepStatus {
    Pending,
    Running,
    Completed,
    Failed,
    Compensating,
    Compensated,
    Skipped,
}

// ---------------------------------------------------------------------------
// Step
// ---------------------------------------------------------------------------

/// A single step within a saga transaction.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct SagaStep {
    /// Unique identifier for this step within the saga.
    pub step_id: String,
    /// The kind of action this step performs.
    pub step_type: SagaStepType,
    /// Human-readable description of the step.
    pub description: String,
    /// Serialized request payload.
    pub payload: Vec<u8>,
    /// Serialized compensation action (if any).
    pub compensation_payload: Option<Vec<u8>>,
    /// Maximum time allowed for this step, in milliseconds.
    pub timeout_ms: u64,
    /// Current status of this step.
    pub status: SagaStepStatus,
}

// ---------------------------------------------------------------------------
// Step result
// ---------------------------------------------------------------------------

/// The outcome of executing a saga step.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct SagaStepResult {
    /// Step this result corresponds to.
    pub step_id: String,
    /// Whether the step succeeded.
    pub success: bool,
    /// Serialized output on success.
    pub output: Option<Vec<u8>>,
    /// Error message on failure.
    pub error: Option<String>,
    /// Wall-clock duration of step execution in milliseconds.
    pub duration_ms: u64,
}

// ---------------------------------------------------------------------------
// Advance outcome
// ---------------------------------------------------------------------------

/// The outcome of advancing a saga after recording a step result.
#[derive(Debug, Clone, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum SagaAdvanceOutcome {
    /// The saga has more steps to execute.
    NextStep { step_index: usize },
    /// All steps completed successfully.
    Completed,
    /// A step failed; compensation is needed from `compensate_from` backwards.
    CompensationNeeded {
        failed_step: usize,
        compensate_from: usize,
    },
}

// ---------------------------------------------------------------------------
// Saga (internal, mutable)
// ---------------------------------------------------------------------------

/// Internal mutable saga state, protected by `RwLock` within the `DashMap`.
struct Saga {
    saga_id: String,
    agent_id: String,
    steps: Vec<SagaStep>,
    results: Vec<SagaStepResult>,
    state: SagaState,
    created_at: u64,
    completed_at: Option<u64>,
    current_step: usize,
    /// True if this saga was explicitly cancelled (vs failed).
    cancelled: bool,
}

impl Saga {
    /// Create a new saga in `Created` state.
    fn new(saga_id: String, agent_id: String, steps: Vec<SagaStep>) -> Self {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
        Self {
            saga_id,
            agent_id,
            steps,
            results: Vec::new(),
            state: SagaState::Created,
            created_at: now,
            completed_at: None,
            current_step: 0,
            cancelled: false,
        }
    }

    /// Take a point-in-time snapshot (all owned, safe to send).
    fn snapshot(&self) -> SagaSnapshot {
        SagaSnapshot {
            saga_id: self.saga_id.clone(),
            agent_id: self.agent_id.clone(),
            steps: self.steps.clone(),
            results: self.results.clone(),
            state: self.state,
            created_at: self.created_at,
            completed_at: self.completed_at,
            current_step: self.current_step,
        }
    }

    /// Mark the saga as finished with a timestamp.
    fn mark_finished(&mut self) {
        self.completed_at = Some(
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs(),
        );
    }
}

// ---------------------------------------------------------------------------
// Snapshot (read-only view)
// ---------------------------------------------------------------------------

/// Point-in-time snapshot of a saga (no locks, safe to send).
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct SagaSnapshot {
    pub saga_id: String,
    pub agent_id: String,
    pub steps: Vec<SagaStep>,
    pub results: Vec<SagaStepResult>,
    pub state: SagaState,
    pub created_at: u64,
    pub completed_at: Option<u64>,
    pub current_step: usize,
}

// ---------------------------------------------------------------------------
// Stats
// ---------------------------------------------------------------------------

/// Aggregate statistics for the saga coordinator.
#[derive(Debug, Clone, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct SagaStats {
    /// Number of currently tracked (non-removed) sagas.
    pub active_sagas: usize,
    /// Total sagas ever created.
    pub total_created: u64,
    /// Total sagas that reached `Completed` state.
    pub total_completed: u64,
    /// Total sagas that reached `Failed` state (step failure, NOT cancellation).
    pub total_failed: u64,
    /// Total sagas that reached `Compensated` state.
    pub total_compensated: u64,
    /// Total sagas explicitly cancelled by the caller.
    pub total_cancelled: u64,
}

// ---------------------------------------------------------------------------
// Coordinator
// ---------------------------------------------------------------------------

/// Registry and orchestrator for saga transactions.
///
/// The coordinator manages the lifecycle of sagas: creation, step advancement,
/// failure handling with compensation, and cancellation. Each saga is stored
/// behind a `RwLock` within a `DashMap` for safe concurrent access.
pub struct SagaCoordinator {
    sagas: DashMap<String, RwLock<Saga>>,
    total_created: AtomicU64,
    total_completed: AtomicU64,
    total_failed: AtomicU64,
    total_compensated: AtomicU64,
    total_cancelled: AtomicU64,
}

impl SagaCoordinator {
    /// Create a new, empty coordinator.
    pub fn new() -> Self {
        Self {
            sagas: DashMap::new(),
            total_created: AtomicU64::new(0),
            total_completed: AtomicU64::new(0),
            total_failed: AtomicU64::new(0),
            total_compensated: AtomicU64::new(0),
            total_cancelled: AtomicU64::new(0),
        }
    }

    /// Register a new saga with the given steps.
    ///
    /// Returns `SagaAlreadyExists` if a saga with the same ID is already tracked.
    pub fn create_saga(
        &self,
        saga_id: impl Into<String>,
        agent_id: impl Into<String>,
        steps: Vec<SagaStep>,
    ) -> Result<(), SagaError> {
        let id = saga_id.into();
        // Use DashMap::entry() for atomic check-and-insert — prevents TOCTOU
        // where two threads both pass contains_key() and one silently overwrites.
        use dashmap::mapref::entry::Entry;
        match self.sagas.entry(id) {
            Entry::Occupied(e) => {
                return Err(SagaError::SagaAlreadyExists {
                    saga_id: e.key().clone(),
                });
            }
            Entry::Vacant(e) => {
                let saga = Saga::new(e.key().clone(), agent_id.into(), steps);
                e.insert(RwLock::new(saga));
            }
        }
        self.total_created.fetch_add(1, Ordering::Relaxed);
        Ok(())
    }

    /// Record a step result and advance the saga.
    ///
    /// - On success: marks the current step `Completed`, advances `current_step`,
    ///   and returns `NextStep` or `Completed`.
    /// - On failure: marks the current step `Failed`, transitions the saga to
    ///   `Compensating`, and returns `CompensationNeeded` indicating which steps
    ///   need compensation (all completed steps before the failed one).
    pub fn advance_step(
        &self,
        saga_id: &str,
        result: SagaStepResult,
    ) -> Result<SagaAdvanceOutcome, SagaError> {
        let entry = self
            .sagas
            .get(saga_id)
            .ok_or_else(|| SagaError::SagaNotFound {
                saga_id: saga_id.to_string(),
            })?;

        let mut saga = entry.write();

        // Only allow advancing in Created or Running states.
        match saga.state {
            SagaState::Created | SagaState::Running => {}
            other => {
                return Err(SagaError::InvalidState {
                    saga_id: saga_id.to_string(),
                    state: other,
                });
            }
        }

        // Transition from Created to Running on first advance.
        if saga.state == SagaState::Created {
            saga.state = SagaState::Running;
        }

        let step_index = saga.current_step;
        if step_index >= saga.steps.len() {
            return Err(SagaError::InvalidState {
                saga_id: saga_id.to_string(),
                state: saga.state,
            });
        }

        if result.success {
            saga.steps[step_index].status = SagaStepStatus::Completed;
            saga.results.push(result);
            saga.current_step += 1;

            if saga.current_step >= saga.steps.len() {
                // All steps completed.
                saga.state = SagaState::Completed;
                saga.mark_finished();
                self.total_completed.fetch_add(1, Ordering::Relaxed);
                Ok(SagaAdvanceOutcome::Completed)
            } else {
                Ok(SagaAdvanceOutcome::NextStep {
                    step_index: saga.current_step,
                })
            }
        } else {
            // Step failed — trigger compensation.
            saga.steps[step_index].status = SagaStepStatus::Failed;
            saga.results.push(result);
            saga.state = SagaState::Compensating;

            let failed_step = step_index;
            // Compensate all previously completed steps (not the failed one).
            let compensate_from = if failed_step > 0 {
                // Mark steps that need compensation.
                for i in (0..failed_step).rev() {
                    if saga.steps[i].status == SagaStepStatus::Completed {
                        saga.steps[i].status = SagaStepStatus::Compensating;
                    }
                }
                failed_step - 1
            } else {
                // No prior steps to compensate — go straight to Compensated.
                saga.state = SagaState::Compensated;
                saga.mark_finished();
                self.total_failed.fetch_add(1, Ordering::Relaxed);
                self.total_compensated.fetch_add(1, Ordering::Relaxed);
                0
            };

            Ok(SagaAdvanceOutcome::CompensationNeeded {
                failed_step,
                compensate_from,
            })
        }
    }

    /// Record the result of compensating a specific step.
    ///
    /// When all compensating steps have been resolved, the saga transitions to
    /// `Compensated` state.
    pub fn record_compensation(
        &self,
        saga_id: &str,
        step_id: &str,
        success: bool,
    ) -> Result<(), SagaError> {
        let entry = self
            .sagas
            .get(saga_id)
            .ok_or_else(|| SagaError::SagaNotFound {
                saga_id: saga_id.to_string(),
            })?;

        let mut saga = entry.write();

        if saga.state != SagaState::Compensating {
            return Err(SagaError::InvalidState {
                saga_id: saga_id.to_string(),
                state: saga.state,
            });
        }

        // Find the step by ID.
        let step_pos = saga
            .steps
            .iter()
            .position(|s| s.step_id == step_id)
            .ok_or_else(|| SagaError::StepNotFound {
                saga_id: saga_id.to_string(),
                step_id: step_id.to_string(),
            })?;

        if success {
            saga.steps[step_pos].status = SagaStepStatus::Compensated;
        } else {
            // Even if compensation fails, mark it so we can make progress.
            // The saga will still transition to Compensated (best effort).
            saga.steps[step_pos].status = SagaStepStatus::Compensated;
        }

        // Check if all compensating steps are done.
        let all_compensated = saga
            .steps
            .iter()
            .all(|s| s.status != SagaStepStatus::Compensating);

        if all_compensated {
            saga.state = SagaState::Compensated;
            saga.mark_finished();
            // Only count as "failed" for actual step failures, not cancellations.
            if !saga.cancelled {
                self.total_failed.fetch_add(1, Ordering::Relaxed);
            }
            self.total_compensated.fetch_add(1, Ordering::Relaxed);
        }

        Ok(())
    }

    /// Get a point-in-time snapshot of a saga.
    pub fn get_saga(&self, saga_id: &str) -> Option<SagaSnapshot> {
        self.sagas.get(saga_id).map(|entry| entry.read().snapshot())
    }

    /// Cancel a saga and trigger compensation from the current step backwards.
    ///
    /// Only sagas in `Created` or `Running` state can be cancelled. Steps that
    /// were already `Completed` are marked `Compensating`; pending steps are
    /// marked `Skipped`.
    pub fn cancel_saga(&self, saga_id: &str) -> Result<(), SagaError> {
        let entry = self
            .sagas
            .get(saga_id)
            .ok_or_else(|| SagaError::SagaNotFound {
                saga_id: saga_id.to_string(),
            })?;

        let mut saga = entry.write();

        match saga.state {
            SagaState::Created | SagaState::Running => {}
            other => {
                return Err(SagaError::InvalidState {
                    saga_id: saga_id.to_string(),
                    state: other,
                });
            }
        }

        let mut has_compensable = false;
        for step in saga.steps.iter_mut() {
            match step.status {
                SagaStepStatus::Completed => {
                    step.status = SagaStepStatus::Compensating;
                    has_compensable = true;
                }
                SagaStepStatus::Pending | SagaStepStatus::Running => {
                    step.status = SagaStepStatus::Skipped;
                }
                _ => {}
            }
        }

        saga.cancelled = true;
        if has_compensable {
            saga.state = SagaState::Compensating;
            self.total_cancelled.fetch_add(1, Ordering::Relaxed);
        } else {
            // Nothing to compensate — mark as Compensated immediately.
            saga.state = SagaState::Compensated;
            saga.mark_finished();
            self.total_cancelled.fetch_add(1, Ordering::Relaxed);
            self.total_compensated.fetch_add(1, Ordering::Relaxed);
        }

        Ok(())
    }

    /// Aggregate statistics across all tracked sagas.
    pub fn stats(&self) -> SagaStats {
        SagaStats {
            active_sagas: self.sagas.len(),
            total_created: self.total_created.load(Ordering::Relaxed),
            total_completed: self.total_completed.load(Ordering::Relaxed),
            total_failed: self.total_failed.load(Ordering::Relaxed),
            total_compensated: self.total_compensated.load(Ordering::Relaxed),
            total_cancelled: self.total_cancelled.load(Ordering::Relaxed),
        }
    }
}

impl Default for SagaCoordinator {
    fn default() -> Self {
        Self::new()
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    /// Helper: create a saga step with sensible defaults.
    fn make_step(step_id: &str, step_type: SagaStepType) -> SagaStep {
        SagaStep {
            step_id: step_id.to_string(),
            step_type,
            description: format!("Step {step_id}"),
            payload: vec![1, 2, 3],
            compensation_payload: Some(vec![3, 2, 1]),
            timeout_ms: 5000,
            status: SagaStepStatus::Pending,
        }
    }

    /// Helper: create a successful step result.
    fn ok_result(step_id: &str) -> SagaStepResult {
        SagaStepResult {
            step_id: step_id.to_string(),
            success: true,
            output: Some(vec![42]),
            error: None,
            duration_ms: 100,
        }
    }

    /// Helper: create a failed step result.
    fn err_result(step_id: &str, msg: &str) -> SagaStepResult {
        SagaStepResult {
            step_id: step_id.to_string(),
            success: false,
            output: None,
            error: Some(msg.to_string()),
            duration_ms: 50,
        }
    }

    #[test]
    fn create_saga_and_verify_initial_state() {
        let coord = SagaCoordinator::new();
        let steps = vec![
            make_step("s1", SagaStepType::A2ATask),
            make_step("s2", SagaStepType::McpToolCall),
        ];

        coord.create_saga("saga-1", "agent-a", steps).unwrap();

        let snap = coord.get_saga("saga-1").unwrap();
        assert_eq!(snap.saga_id, "saga-1");
        assert_eq!(snap.agent_id, "agent-a");
        assert_eq!(snap.state, SagaState::Created);
        assert_eq!(snap.steps.len(), 2);
        assert_eq!(snap.results.len(), 0);
        assert_eq!(snap.current_step, 0);
        assert!(snap.completed_at.is_none());
        assert!(snap.created_at > 0);
    }

    #[test]
    fn advance_through_all_steps_to_completion() {
        let coord = SagaCoordinator::new();
        let steps = vec![
            make_step("s1", SagaStepType::A2ATask),
            make_step("s2", SagaStepType::McpToolCall),
            make_step("s3", SagaStepType::HttpRequest),
        ];
        coord.create_saga("saga-ok", "agent-a", steps).unwrap();

        // Advance step 1.
        let outcome = coord.advance_step("saga-ok", ok_result("s1")).unwrap();
        assert_eq!(outcome, SagaAdvanceOutcome::NextStep { step_index: 1 });

        // Verify Running state.
        let snap = coord.get_saga("saga-ok").unwrap();
        assert_eq!(snap.state, SagaState::Running);
        assert_eq!(snap.current_step, 1);

        // Advance step 2.
        let outcome = coord.advance_step("saga-ok", ok_result("s2")).unwrap();
        assert_eq!(outcome, SagaAdvanceOutcome::NextStep { step_index: 2 });

        // Advance step 3 — should complete.
        let outcome = coord.advance_step("saga-ok", ok_result("s3")).unwrap();
        assert_eq!(outcome, SagaAdvanceOutcome::Completed);

        let snap = coord.get_saga("saga-ok").unwrap();
        assert_eq!(snap.state, SagaState::Completed);
        assert_eq!(snap.results.len(), 3);
        assert!(snap.completed_at.is_some());

        // Stats should reflect completion.
        let stats = coord.stats();
        assert_eq!(stats.total_completed, 1);
        assert_eq!(stats.total_failed, 0);
    }

    #[test]
    fn step_failure_triggers_compensation_needed() {
        let coord = SagaCoordinator::new();
        let steps = vec![
            make_step("s1", SagaStepType::A2ATask),
            make_step("s2", SagaStepType::McpToolCall),
            make_step("s3", SagaStepType::HttpRequest),
        ];
        coord.create_saga("saga-fail", "agent-b", steps).unwrap();

        // Complete step 1.
        coord.advance_step("saga-fail", ok_result("s1")).unwrap();

        // Fail step 2.
        let outcome = coord
            .advance_step("saga-fail", err_result("s2", "timeout"))
            .unwrap();

        assert_eq!(
            outcome,
            SagaAdvanceOutcome::CompensationNeeded {
                failed_step: 1,
                compensate_from: 0,
            }
        );

        let snap = coord.get_saga("saga-fail").unwrap();
        assert_eq!(snap.state, SagaState::Compensating);
        assert_eq!(snap.steps[0].status, SagaStepStatus::Compensating);
        assert_eq!(snap.steps[1].status, SagaStepStatus::Failed);
        assert_eq!(snap.steps[2].status, SagaStepStatus::Pending);
    }

    #[test]
    fn record_compensation_marks_saga_compensated() {
        let coord = SagaCoordinator::new();
        let steps = vec![
            make_step("s1", SagaStepType::A2ATask),
            make_step("s2", SagaStepType::McpToolCall),
        ];
        coord.create_saga("saga-comp", "agent-c", steps).unwrap();

        // Complete step 1, fail step 2.
        coord.advance_step("saga-comp", ok_result("s1")).unwrap();
        coord
            .advance_step("saga-comp", err_result("s2", "error"))
            .unwrap();

        // Saga should be Compensating.
        let snap = coord.get_saga("saga-comp").unwrap();
        assert_eq!(snap.state, SagaState::Compensating);

        // Record compensation for step 1.
        coord.record_compensation("saga-comp", "s1", true).unwrap();

        let snap = coord.get_saga("saga-comp").unwrap();
        assert_eq!(snap.state, SagaState::Compensated);
        assert_eq!(snap.steps[0].status, SagaStepStatus::Compensated);
        assert!(snap.completed_at.is_some());

        let stats = coord.stats();
        assert_eq!(stats.total_failed, 1);
        assert_eq!(stats.total_compensated, 1);
    }

    #[test]
    fn cancel_saga_triggers_compensation() {
        let coord = SagaCoordinator::new();
        let steps = vec![
            make_step("s1", SagaStepType::A2ATask),
            make_step("s2", SagaStepType::McpToolCall),
            make_step("s3", SagaStepType::HttpRequest),
        ];
        coord.create_saga("saga-cancel", "agent-d", steps).unwrap();

        // Complete step 1.
        coord.advance_step("saga-cancel", ok_result("s1")).unwrap();

        // Cancel — step 1 should be Compensating, steps 2 and 3 Skipped.
        coord.cancel_saga("saga-cancel").unwrap();

        let snap = coord.get_saga("saga-cancel").unwrap();
        assert_eq!(snap.state, SagaState::Compensating);
        assert_eq!(snap.steps[0].status, SagaStepStatus::Compensating);
        assert_eq!(snap.steps[1].status, SagaStepStatus::Skipped);
        assert_eq!(snap.steps[2].status, SagaStepStatus::Skipped);

        // Complete compensation.
        coord
            .record_compensation("saga-cancel", "s1", true)
            .unwrap();

        let snap = coord.get_saga("saga-cancel").unwrap();
        assert_eq!(snap.state, SagaState::Compensated);
    }

    #[test]
    fn advance_on_completed_saga_returns_error() {
        let coord = SagaCoordinator::new();
        let steps = vec![make_step("s1", SagaStepType::A2ATask)];
        coord.create_saga("saga-done", "agent-e", steps).unwrap();

        // Complete the only step.
        let outcome = coord.advance_step("saga-done", ok_result("s1")).unwrap();
        assert_eq!(outcome, SagaAdvanceOutcome::Completed);

        // Attempt to advance again — should fail with InvalidState.
        let err = coord
            .advance_step("saga-done", ok_result("s1"))
            .unwrap_err();
        assert!(
            matches!(
                err,
                SagaError::InvalidState {
                    state: SagaState::Completed,
                    ..
                }
            ),
            "expected InvalidState(Completed), got {err:?}"
        );
    }

    #[test]
    fn saga_not_found_error() {
        let coord = SagaCoordinator::new();

        let err = coord
            .advance_step("nonexistent", ok_result("s1"))
            .unwrap_err();
        assert!(
            matches!(err, SagaError::SagaNotFound { .. }),
            "expected SagaNotFound, got {err:?}"
        );

        assert!(coord.get_saga("nonexistent").is_none());

        let err = coord.cancel_saga("nonexistent").unwrap_err();
        assert!(
            matches!(err, SagaError::SagaNotFound { .. }),
            "expected SagaNotFound, got {err:?}"
        );

        let err = coord
            .record_compensation("nonexistent", "s1", true)
            .unwrap_err();
        assert!(
            matches!(err, SagaError::SagaNotFound { .. }),
            "expected SagaNotFound, got {err:?}"
        );
    }

    #[test]
    fn saga_already_exists_error() {
        let coord = SagaCoordinator::new();
        let steps = vec![make_step("s1", SagaStepType::A2ATask)];

        coord
            .create_saga("saga-dup", "agent-f", steps.clone())
            .unwrap();

        let err = coord.create_saga("saga-dup", "agent-g", steps).unwrap_err();
        assert!(
            matches!(err, SagaError::SagaAlreadyExists { .. }),
            "expected SagaAlreadyExists, got {err:?}"
        );
    }

    #[test]
    fn stats_accuracy_across_multiple_sagas() {
        let coord = SagaCoordinator::new();

        // Create three sagas.
        for i in 0..3 {
            let id = format!("saga-stats-{i}");
            let steps = vec![
                make_step("s1", SagaStepType::A2ATask),
                make_step("s2", SagaStepType::McpToolCall),
            ];
            coord.create_saga(&id, "agent-x", steps).unwrap();
        }

        let stats = coord.stats();
        assert_eq!(stats.active_sagas, 3);
        assert_eq!(stats.total_created, 3);
        assert_eq!(stats.total_completed, 0);
        assert_eq!(stats.total_failed, 0);

        // Complete saga 0.
        coord.advance_step("saga-stats-0", ok_result("s1")).unwrap();
        coord.advance_step("saga-stats-0", ok_result("s2")).unwrap();

        // Fail saga 1 at step 2 and compensate.
        coord.advance_step("saga-stats-1", ok_result("s1")).unwrap();
        coord
            .advance_step("saga-stats-1", err_result("s2", "boom"))
            .unwrap();
        coord
            .record_compensation("saga-stats-1", "s1", true)
            .unwrap();

        // Leave saga 2 as Created.

        let stats = coord.stats();
        assert_eq!(stats.active_sagas, 3);
        assert_eq!(stats.total_created, 3);
        assert_eq!(stats.total_completed, 1);
        assert_eq!(stats.total_failed, 1);
        assert_eq!(stats.total_compensated, 1);
    }

    #[test]
    fn multi_step_saga_partial_completion_then_failure() {
        let coord = SagaCoordinator::new();
        let steps = vec![
            make_step("s1", SagaStepType::A2ATask),
            make_step("s2", SagaStepType::McpToolCall),
            make_step("s3", SagaStepType::HttpRequest),
            make_step("s4", SagaStepType::Custom("validate".to_string())),
        ];
        coord.create_saga("saga-partial", "agent-h", steps).unwrap();

        // Complete steps 1, 2, 3.
        coord.advance_step("saga-partial", ok_result("s1")).unwrap();
        coord.advance_step("saga-partial", ok_result("s2")).unwrap();
        coord.advance_step("saga-partial", ok_result("s3")).unwrap();

        // Fail step 4.
        let outcome = coord
            .advance_step("saga-partial", err_result("s4", "validation failed"))
            .unwrap();

        assert_eq!(
            outcome,
            SagaAdvanceOutcome::CompensationNeeded {
                failed_step: 3,
                compensate_from: 2,
            }
        );

        let snap = coord.get_saga("saga-partial").unwrap();
        assert_eq!(snap.state, SagaState::Compensating);
        assert_eq!(snap.steps[0].status, SagaStepStatus::Compensating);
        assert_eq!(snap.steps[1].status, SagaStepStatus::Compensating);
        assert_eq!(snap.steps[2].status, SagaStepStatus::Compensating);
        assert_eq!(snap.steps[3].status, SagaStepStatus::Failed);
        assert_eq!(snap.results.len(), 4);

        // Compensate in reverse order.
        coord
            .record_compensation("saga-partial", "s3", true)
            .unwrap();
        // Still compensating — s1 and s2 remain.
        let snap = coord.get_saga("saga-partial").unwrap();
        assert_eq!(snap.state, SagaState::Compensating);

        coord
            .record_compensation("saga-partial", "s2", true)
            .unwrap();
        let snap = coord.get_saga("saga-partial").unwrap();
        assert_eq!(snap.state, SagaState::Compensating);

        coord
            .record_compensation("saga-partial", "s1", true)
            .unwrap();
        let snap = coord.get_saga("saga-partial").unwrap();
        assert_eq!(snap.state, SagaState::Compensated);
        assert!(snap.completed_at.is_some());

        // All completed steps should now be Compensated.
        assert_eq!(snap.steps[0].status, SagaStepStatus::Compensated);
        assert_eq!(snap.steps[1].status, SagaStepStatus::Compensated);
        assert_eq!(snap.steps[2].status, SagaStepStatus::Compensated);
    }

    #[test]
    fn cancel_saga_with_no_completed_steps() {
        let coord = SagaCoordinator::new();
        let steps = vec![
            make_step("s1", SagaStepType::A2ATask),
            make_step("s2", SagaStepType::McpToolCall),
        ];
        coord
            .create_saga("saga-cancel-empty", "agent-i", steps)
            .unwrap();

        // Cancel before any steps are executed.
        coord.cancel_saga("saga-cancel-empty").unwrap();

        let snap = coord.get_saga("saga-cancel-empty").unwrap();
        // No completed steps, so it goes directly to Compensated.
        assert_eq!(snap.state, SagaState::Compensated);
        assert_eq!(snap.steps[0].status, SagaStepStatus::Skipped);
        assert_eq!(snap.steps[1].status, SagaStepStatus::Skipped);
        assert!(snap.completed_at.is_some());
    }
}
