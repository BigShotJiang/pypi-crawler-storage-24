// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! API key pool with 5 rotation strategies.

use std::collections::VecDeque;
use std::sync::Arc;

use indexmap::IndexMap;
use parking_lot::Mutex;
use rand::Rng;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

use crate::clock::{Clock, MonotonicClock};
use crate::error::{ProxyError, Result};

// ---------------------------------------------------------------------------
// Enums
// ---------------------------------------------------------------------------

/// Key rotation strategy.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum RotationStrategy {
    RoundRobin,
    LeastUsed,
    Random,
    Weighted,
    Adaptive,
}

/// Status of a single API key.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum KeyStatus {
    Active,
    RateLimited,
    CoolingDown,
    Disabled,
    Exhausted,
}

// ---------------------------------------------------------------------------
// Health weights
// ---------------------------------------------------------------------------

/// Configurable weights for health score calculation.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct HealthWeights {
    pub success_rate: f64,
    pub error_penalty: f64,
    pub rate_limit_penalty: f64,
    pub latency: f64,
}

impl Default for HealthWeights {
    fn default() -> Self {
        Self {
            success_rate: 0.4,
            error_penalty: 0.3,
            rate_limit_penalty: 0.2,
            latency: 0.1,
        }
    }
}

// ---------------------------------------------------------------------------
// Key metrics
// ---------------------------------------------------------------------------

const MAX_LATENCY_SAMPLES: usize = 100;

/// Per-key usage metrics.
#[derive(Debug, Clone)]
pub struct KeyMetrics {
    pub total_requests: u64,
    pub total_errors: u64,
    pub total_rate_limits: u64,
    latency_samples: VecDeque<f64>,
}

impl Default for KeyMetrics {
    fn default() -> Self {
        Self {
            total_requests: 0,
            total_errors: 0,
            total_rate_limits: 0,
            latency_samples: VecDeque::with_capacity(MAX_LATENCY_SAMPLES),
        }
    }
}

impl KeyMetrics {
    pub fn record_latency(&mut self, ms: f64) {
        if self.latency_samples.len() >= MAX_LATENCY_SAMPLES {
            self.latency_samples.pop_front();
        }
        self.latency_samples.push_back(ms);
    }

    pub fn avg_latency_ms(&self) -> f64 {
        if self.latency_samples.is_empty() {
            return 0.0;
        }
        let sum: f64 = self.latency_samples.iter().sum();
        sum / self.latency_samples.len() as f64
    }

    pub fn success_rate(&self) -> f64 {
        if self.total_requests == 0 {
            return 1.0;
        }
        let successes = self.total_requests - self.total_errors;
        successes as f64 / self.total_requests as f64
    }

    /// Health score in [0, 1] using configurable weights.
    pub fn health_score(&self, weights: &HealthWeights) -> f64 {
        let sr = self.success_rate();
        let error_rate = if self.total_requests == 0 {
            0.0
        } else {
            self.total_errors as f64 / self.total_requests as f64
        };
        let rl_rate = if self.total_requests == 0 {
            0.0
        } else {
            self.total_rate_limits as f64 / self.total_requests as f64
        };
        // Latency penalty: normalize to [0, 1] assuming 5000ms is worst
        let latency_penalty = (self.avg_latency_ms() / 5000.0).min(1.0);

        let score = sr * weights.success_rate
            - error_rate * weights.error_penalty
            - rl_rate * weights.rate_limit_penalty
            - latency_penalty * weights.latency;

        score.clamp(0.0, 1.0)
    }
}

// ---------------------------------------------------------------------------
// Key state
// ---------------------------------------------------------------------------

/// Complete state for a single API key.
#[derive(Debug, Clone)]
pub struct KeyState {
    pub key: String,
    pub status: KeyStatus,
    pub weight: f64,
    pub metrics: KeyMetrics,
    /// Daily request limit (None = unlimited).
    pub daily_limit: Option<u64>,
    pub daily_requests: u64,
    /// Time (secs) when rate limit / cooldown expires.
    pub cooldown_until: f64,
}

impl KeyState {
    fn new(key: String, weight: f64, daily_limit: Option<u64>) -> Self {
        Self {
            key,
            status: KeyStatus::Active,
            weight,
            metrics: KeyMetrics::default(),
            daily_limit,
            daily_requests: 0,
            cooldown_until: 0.0,
        }
    }

    /// Whether this key is available for use right now.
    fn is_available(&self, now: f64) -> bool {
        match self.status {
            KeyStatus::Active => true,
            KeyStatus::RateLimited | KeyStatus::CoolingDown => now >= self.cooldown_until,
            KeyStatus::Disabled | KeyStatus::Exhausted => false,
        }
    }
}

// ---------------------------------------------------------------------------
// Key summary (for external visibility — never exposes raw key material)
// ---------------------------------------------------------------------------

/// Summary of a key's state and metrics, with the key material masked.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct KeySummary {
    pub key_masked: String,
    pub status: KeyStatus,
    pub total_requests: u64,
    pub total_errors: u64,
    pub total_rate_limits: u64,
    pub avg_latency_ms: f64,
    pub health_score: f64,
    pub weight: f64,
}

/// Mask a key for safe display: keys ≤8 chars → `"***"`, else `first4...last4`.
pub fn mask_key(key: &str) -> String {
    if key.len() <= 8 {
        "***".into()
    } else {
        format!("{}...{}", &key[..4], &key[key.len() - 4..])
    }
}

// ---------------------------------------------------------------------------
// Key pool
// ---------------------------------------------------------------------------

struct Inner {
    keys: IndexMap<String, KeyState>,
    strategy: RotationStrategy,
    round_robin_idx: usize,
    health_weights: HealthWeights,
}

/// Thread-safe API key pool with 5 rotation strategies.
pub struct KeyPool {
    inner: Mutex<Inner>,
    clock: Arc<dyn Clock>,
}

impl KeyPool {
    pub fn new(strategy: RotationStrategy) -> Self {
        Self::with_clock(strategy, Arc::new(MonotonicClock::new()))
    }

    pub fn with_clock(strategy: RotationStrategy, clock: Arc<dyn Clock>) -> Self {
        Self {
            inner: Mutex::new(Inner {
                keys: IndexMap::new(),
                strategy,
                round_robin_idx: 0,
                health_weights: HealthWeights::default(),
            }),
            clock,
        }
    }

    /// Set custom health weights for adaptive strategy.
    pub fn set_health_weights(&self, weights: HealthWeights) {
        self.inner.lock().health_weights = weights;
    }

    /// Add a key to the pool.
    pub fn add_key(&self, key: impl Into<String>, weight: f64, daily_limit: Option<u64>) {
        let key = key.into();
        let id = key.clone();
        let state = KeyState::new(key, weight, daily_limit);
        self.inner.lock().keys.insert(id, state);
    }

    /// Number of keys in the pool.
    pub fn len(&self) -> usize {
        self.inner.lock().keys.len()
    }

    /// Whether the pool is empty.
    pub fn is_empty(&self) -> bool {
        self.inner.lock().keys.is_empty()
    }

    /// Check if a key exists in the pool.
    pub fn has_key(&self, key: &str) -> bool {
        self.inner.lock().keys.contains_key(key)
    }

    /// Remove a key from the pool. Returns true if it was present.
    pub fn remove_key(&self, key: &str) -> bool {
        let mut inner = self.inner.lock();
        let removed = inner.keys.shift_remove(key).is_some();
        if removed {
            // Clamp round_robin_idx if it's now out of bounds
            if !inner.keys.is_empty() {
                inner.round_robin_idx %= inner.keys.len();
            } else {
                inner.round_robin_idx = 0;
            }
        }
        removed
    }

    /// List all keys with masked key material and current metrics.
    pub fn list_keys(&self) -> Vec<KeySummary> {
        let inner = self.inner.lock();
        let weights = &inner.health_weights;
        inner
            .keys
            .values()
            .map(|state| KeySummary {
                key_masked: mask_key(&state.key),
                status: state.status,
                total_requests: state.metrics.total_requests,
                total_errors: state.metrics.total_errors,
                total_rate_limits: state.metrics.total_rate_limits,
                avg_latency_ms: state.metrics.avg_latency_ms(),
                health_score: state.metrics.health_score(weights),
                weight: state.weight,
            })
            .collect()
    }

    /// Select a key using the configured strategy.
    pub fn select_key(&self) -> Result<String> {
        self.select_key_with_rng(&mut rand::thread_rng())
    }

    /// Select a key with an explicit RNG (for testing).
    pub fn select_key_with_rng<R: Rng>(&self, rng: &mut R) -> Result<String> {
        let mut inner = self.inner.lock();
        let now = self.clock.now_secs();

        // Refresh cooldowns
        for state in inner.keys.values_mut() {
            if (state.status == KeyStatus::RateLimited || state.status == KeyStatus::CoolingDown)
                && now >= state.cooldown_until
            {
                state.status = KeyStatus::Active;
            }
        }

        let strategy = inner.strategy;
        match strategy {
            RotationStrategy::RoundRobin => Self::select_round_robin(&mut inner, now),
            RotationStrategy::LeastUsed => Self::select_least_used(&inner, now),
            RotationStrategy::Random => Self::select_random(&inner, now, rng),
            RotationStrategy::Weighted => Self::select_weighted(&inner, now, rng),
            RotationStrategy::Adaptive => Self::select_adaptive(&mut inner, now, rng),
        }
    }

    // -- Strategy implementations --

    fn select_round_robin(inner: &mut Inner, now: f64) -> Result<String> {
        let available: Vec<usize> = inner
            .keys
            .values()
            .enumerate()
            .filter(|(_, s)| s.is_available(now))
            .map(|(i, _)| i)
            .collect();

        if available.is_empty() {
            return Err(Self::no_keys_error(&inner.keys));
        }

        // Find the next available index >= round_robin_idx
        let start = inner.round_robin_idx % inner.keys.len();
        let mut selected = None;
        for offset in 0..inner.keys.len() {
            let idx = (start + offset) % inner.keys.len();
            if available.contains(&idx) {
                selected = Some(idx);
                inner.round_robin_idx = idx + 1;
                break;
            }
        }

        let idx = selected.ok_or_else(|| Self::no_keys_error(&inner.keys))?;
        let err = Self::no_keys_error(&inner.keys);
        let (_, state) = inner.keys.get_index_mut(idx).ok_or(err)?;
        state.metrics.total_requests += 1;
        state.daily_requests += 1;
        Ok(state.key.clone())
    }

    fn select_least_used(inner: &Inner, now: f64) -> Result<String> {
        inner
            .keys
            .values()
            .filter(|s| s.is_available(now))
            .min_by_key(|s| s.metrics.total_requests)
            .map(|s| {
                // Note: can't mutate through shared ref, metrics updated post-select
                s.key.clone()
            })
            .ok_or_else(|| Self::no_keys_error(&inner.keys))
    }

    fn select_random<R: Rng>(inner: &Inner, now: f64, rng: &mut R) -> Result<String> {
        let available: Vec<&KeyState> = inner
            .keys
            .values()
            .filter(|s| s.is_available(now))
            .collect();

        if available.is_empty() {
            return Err(Self::no_keys_error(&inner.keys));
        }

        let idx = rng.gen_range(0..available.len());
        Ok(available[idx].key.clone())
    }

    fn select_weighted<R: Rng>(inner: &Inner, now: f64, rng: &mut R) -> Result<String> {
        let available: Vec<&KeyState> = inner
            .keys
            .values()
            .filter(|s| s.is_available(now))
            .collect();

        if available.is_empty() {
            return Err(Self::no_keys_error(&inner.keys));
        }

        let total_weight: f64 = available.iter().map(|s| s.weight).sum();
        if total_weight <= 0.0 {
            // Fall back to uniform random
            let idx = rng.gen_range(0..available.len());
            return Ok(available[idx].key.clone());
        }

        let mut r = rng.gen::<f64>() * total_weight;
        for s in &available {
            r -= s.weight;
            if r <= 0.0 {
                return Ok(s.key.clone());
            }
        }
        // Safety: `available` is non-empty (checked above).
        Ok(available
            .last()
            .ok_or_else(|| Self::no_keys_error(&inner.keys))?
            .key
            .clone())
    }

    fn select_adaptive<R: Rng>(inner: &mut Inner, now: f64, rng: &mut R) -> Result<String> {
        let weights_config = inner.health_weights.clone();
        let available: Vec<(usize, f64)> = inner
            .keys
            .values()
            .enumerate()
            .filter(|(_, s)| s.is_available(now))
            .map(|(i, s)| {
                let health = s.metrics.health_score(&weights_config);
                // Combine health with weight and freshness bonus
                let freshness = if s.metrics.total_requests == 0 {
                    0.2
                } else {
                    0.0
                };
                let usage_penalty = if inner.keys.len() > 1 {
                    let avg_usage = inner
                        .keys
                        .values()
                        .map(|k| k.metrics.total_requests)
                        .sum::<u64>() as f64
                        / inner.keys.len() as f64;
                    if avg_usage > 0.0 {
                        (s.metrics.total_requests as f64 / avg_usage - 1.0).max(0.0) * 0.1
                    } else {
                        0.0
                    }
                } else {
                    0.0
                };
                let score = (health * s.weight + freshness - usage_penalty).max(0.01);
                (i, score)
            })
            .collect();

        if available.is_empty() {
            return Err(Self::no_keys_error(&inner.keys));
        }

        let total: f64 = available.iter().map(|(_, s)| s).sum();
        let mut r = rng.gen::<f64>() * total;
        for &(idx, score) in &available {
            r -= score;
            if r <= 0.0 {
                let err = Self::no_keys_error(&inner.keys);
                let (_, state) = inner.keys.get_index_mut(idx).ok_or(err)?;
                state.metrics.total_requests += 1;
                state.daily_requests += 1;
                return Ok(state.key.clone());
            }
        }

        // Safety: `available` is non-empty (checked above).
        let &(idx, _) = available
            .last()
            .ok_or_else(|| Self::no_keys_error(&inner.keys))?;
        let err = Self::no_keys_error(&inner.keys);
        let (_, state) = inner.keys.get_index_mut(idx).ok_or(err)?;
        state.metrics.total_requests += 1;
        state.daily_requests += 1;
        Ok(state.key.clone())
    }

    // -- Outcome recording --

    /// Record a successful request for a key.
    pub fn record_success(&self, key: &str, latency_ms: f64) {
        let mut inner = self.inner.lock();
        if let Some(state) = inner.keys.get_mut(key) {
            state.metrics.total_requests += 1;
            state.daily_requests += 1;
            state.metrics.record_latency(latency_ms);
        }
    }

    /// Record an error for a key.
    pub fn record_error(&self, key: &str) {
        let mut inner = self.inner.lock();
        if let Some(state) = inner.keys.get_mut(key) {
            state.metrics.total_requests += 1;
            state.metrics.total_errors += 1;
        }
    }

    /// Record a rate limit hit. Puts key into cooldown.
    pub fn record_rate_limit(&self, key: &str, cooldown_secs: f64) {
        let mut inner = self.inner.lock();
        let now = self.clock.now_secs();
        if let Some(state) = inner.keys.get_mut(key) {
            state.metrics.total_requests += 1;
            state.metrics.total_rate_limits += 1;
            state.status = KeyStatus::RateLimited;
            state.cooldown_until = now + cooldown_secs;
        }
    }

    /// Record quota exhaustion. Disables the key.
    pub fn record_exhausted(&self, key: &str) {
        let mut inner = self.inner.lock();
        if let Some(state) = inner.keys.get_mut(key) {
            state.status = KeyStatus::Exhausted;
        }
    }

    /// Disable a key manually.
    pub fn disable_key(&self, key: &str) {
        let mut inner = self.inner.lock();
        if let Some(state) = inner.keys.get_mut(key) {
            state.status = KeyStatus::Disabled;
        }
    }

    /// Re-enable a disabled key.
    pub fn enable_key(&self, key: &str) {
        let mut inner = self.inner.lock();
        if let Some(state) = inner.keys.get_mut(key) {
            state.status = KeyStatus::Active;
            state.cooldown_until = 0.0;
        }
    }

    /// Reset daily counters for all keys.
    pub fn reset_daily_counters(&self) {
        let mut inner = self.inner.lock();
        for state in inner.keys.values_mut() {
            state.daily_requests = 0;
            if state.status == KeyStatus::Exhausted {
                state.status = KeyStatus::Active;
            }
        }
    }

    fn no_keys_error(keys: &IndexMap<String, KeyState>) -> ProxyError {
        let active = keys
            .values()
            .filter(|s| s.status == KeyStatus::Active)
            .count();
        ProxyError::NoAvailableKeys {
            total: keys.len(),
            active,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::clock::ManualClock;
    use rand::rngs::StdRng;
    use rand::SeedableRng;
    use std::sync::Arc;

    fn make_pool(strategy: RotationStrategy) -> (KeyPool, Arc<ManualClock>) {
        let clock = Arc::new(ManualClock::new(0.0));
        let pool = KeyPool::with_clock(strategy, clock.clone());
        (pool, clock)
    }

    fn seeded_rng() -> StdRng {
        StdRng::seed_from_u64(42)
    }

    #[test]
    fn empty_pool_errors() {
        let (pool, _) = make_pool(RotationStrategy::RoundRobin);
        assert!(pool.select_key().is_err());
        assert_eq!(pool.len(), 0);
        assert!(pool.is_empty());
    }

    #[test]
    fn add_and_select() {
        let (pool, _) = make_pool(RotationStrategy::RoundRobin);
        pool.add_key("key1", 1.0, None);
        assert_eq!(pool.len(), 1);
        assert!(!pool.is_empty());

        let k = pool.select_key().unwrap();
        assert_eq!(k, "key1");
    }

    #[test]
    fn round_robin_cycles() {
        let (pool, _) = make_pool(RotationStrategy::RoundRobin);
        pool.add_key("a", 1.0, None);
        pool.add_key("b", 1.0, None);
        pool.add_key("c", 1.0, None);

        let k1 = pool.select_key().unwrap();
        let k2 = pool.select_key().unwrap();
        let k3 = pool.select_key().unwrap();
        let k4 = pool.select_key().unwrap();

        assert_eq!(k1, "a");
        assert_eq!(k2, "b");
        assert_eq!(k3, "c");
        assert_eq!(k4, "a"); // wraps around
    }

    #[test]
    fn least_used_picks_minimum() {
        let (pool, _) = make_pool(RotationStrategy::LeastUsed);
        pool.add_key("busy", 1.0, None);
        pool.add_key("idle", 1.0, None);

        // Record usage on "busy"
        pool.record_success("busy", 100.0);
        pool.record_success("busy", 100.0);
        pool.record_success("busy", 100.0);

        let k = pool.select_key().unwrap();
        assert_eq!(k, "idle");
    }

    #[test]
    fn random_picks_from_available() {
        let (pool, _) = make_pool(RotationStrategy::Random);
        pool.add_key("a", 1.0, None);
        pool.add_key("b", 1.0, None);

        let mut rng = seeded_rng();
        let mut seen = std::collections::HashSet::new();
        for _ in 0..50 {
            let k = pool.select_key_with_rng(&mut rng).unwrap();
            seen.insert(k);
        }
        assert_eq!(seen.len(), 2);
    }

    #[test]
    fn weighted_favors_higher_weight() {
        let (pool, _) = make_pool(RotationStrategy::Weighted);
        pool.add_key("heavy", 10.0, None);
        pool.add_key("light", 1.0, None);

        let mut rng = seeded_rng();
        let mut heavy_count = 0;
        let trials = 200;
        for _ in 0..trials {
            let k = pool.select_key_with_rng(&mut rng).unwrap();
            if k == "heavy" {
                heavy_count += 1;
            }
        }
        // With 10:1 weight ratio, heavy should be selected ~90% of the time
        assert!(
            heavy_count > trials * 7 / 10,
            "heavy selected {heavy_count}/{trials} times"
        );
    }

    #[test]
    fn adaptive_considers_health() {
        let (pool, _) = make_pool(RotationStrategy::Adaptive);
        pool.add_key("healthy", 1.0, None);
        pool.add_key("unhealthy", 1.0, None);

        // Make "unhealthy" have bad metrics
        for _ in 0..20 {
            pool.record_error("unhealthy");
        }
        // Give "healthy" good metrics
        for _ in 0..20 {
            pool.record_success("healthy", 100.0);
        }

        let mut rng = seeded_rng();
        let mut healthy_count = 0;
        let trials = 100;
        for _ in 0..trials {
            let k = pool.select_key_with_rng(&mut rng).unwrap();
            if k == "healthy" {
                healthy_count += 1;
            }
        }
        assert!(
            healthy_count > trials / 2,
            "healthy selected {healthy_count}/{trials} times"
        );
    }

    #[test]
    fn rate_limit_cooldown() {
        let (pool, clock) = make_pool(RotationStrategy::RoundRobin);
        pool.add_key("a", 1.0, None);
        pool.add_key("b", 1.0, None);

        // Rate limit "a" for 30 seconds
        pool.record_rate_limit("a", 30.0);

        // Should only get "b"
        let k = pool.select_key().unwrap();
        assert_eq!(k, "b");

        // After cooldown, "a" is available again
        clock.advance(31.0);
        let mut seen = std::collections::HashSet::new();
        for _ in 0..10 {
            seen.insert(pool.select_key().unwrap());
        }
        assert!(
            seen.contains("a"),
            "key 'a' should be available after cooldown"
        );
    }

    #[test]
    fn exhausted_key_excluded() {
        let (pool, _) = make_pool(RotationStrategy::RoundRobin);
        pool.add_key("a", 1.0, None);
        pool.add_key("b", 1.0, None);

        pool.record_exhausted("a");
        let k = pool.select_key().unwrap();
        assert_eq!(k, "b");
    }

    #[test]
    fn disable_and_enable() {
        let (pool, _) = make_pool(RotationStrategy::RoundRobin);
        pool.add_key("a", 1.0, None);

        pool.disable_key("a");
        assert!(pool.select_key().is_err());

        pool.enable_key("a");
        assert!(pool.select_key().is_ok());
    }

    #[test]
    fn reset_daily_counters_reactivates() {
        let (pool, _) = make_pool(RotationStrategy::RoundRobin);
        pool.add_key("a", 1.0, None);
        pool.record_exhausted("a");
        assert!(pool.select_key().is_err());

        pool.reset_daily_counters();
        assert!(pool.select_key().is_ok());
    }

    #[test]
    fn health_score_calculation() {
        let mut metrics = KeyMetrics::default();
        let weights = HealthWeights::default();

        // No requests → perfect health
        assert!((metrics.health_score(&weights) - 0.4).abs() < 0.01);

        // Record some successes
        metrics.total_requests = 10;
        metrics.record_latency(100.0);
        let score = metrics.health_score(&weights);
        assert!(score > 0.3, "healthy key should score well: {score}");

        // Record errors
        metrics.total_errors = 5;
        let score2 = metrics.health_score(&weights);
        assert!(score2 < score, "errors should lower health score");
    }

    #[test]
    fn list_keys_returns_summaries() {
        let (pool, _) = make_pool(RotationStrategy::RoundRobin);
        pool.add_key("sk-1234567890abcdef", 1.5, None);
        pool.add_key("short", 2.0, Some(1000));

        let summaries = pool.list_keys();
        assert_eq!(summaries.len(), 2);

        // First key should be masked properly (>8 chars)
        assert_eq!(summaries[0].key_masked, "sk-1...cdef");
        assert_eq!(summaries[0].weight, 1.5);
        assert_eq!(summaries[0].status, KeyStatus::Active);

        // Short key should be masked as "***"
        assert_eq!(summaries[1].key_masked, "***");
        assert_eq!(summaries[1].weight, 2.0);
    }

    #[test]
    fn has_key_works() {
        let (pool, _) = make_pool(RotationStrategy::RoundRobin);
        pool.add_key("key1", 1.0, None);

        assert!(pool.has_key("key1"));
        assert!(!pool.has_key("key2"));
    }

    #[test]
    fn remove_key_works() {
        let (pool, _) = make_pool(RotationStrategy::RoundRobin);
        pool.add_key("a", 1.0, None);
        pool.add_key("b", 1.0, None);
        pool.add_key("c", 1.0, None);

        assert_eq!(pool.len(), 3);
        assert!(pool.remove_key("b"));
        assert_eq!(pool.len(), 2);
        assert!(!pool.has_key("b"));
        assert!(!pool.remove_key("b")); // already removed

        // Remaining keys still work
        let k = pool.select_key().unwrap();
        assert!(k == "a" || k == "c");
    }

    #[test]
    fn mask_key_variants() {
        assert_eq!(super::mask_key("abc"), "***");
        assert_eq!(super::mask_key("12345678"), "***");
        assert_eq!(super::mask_key("123456789"), "1234...6789");
        assert_eq!(super::mask_key("sk-1234567890abcdef"), "sk-1...cdef");
    }

    #[test]
    fn latency_rolling_window() {
        let mut metrics = KeyMetrics::default();
        for i in 0..150 {
            metrics.record_latency(i as f64);
        }
        // Should only keep last 100
        assert_eq!(metrics.latency_samples.len(), MAX_LATENCY_SAMPLES);
        // Average of 50..150 = 99.5
        assert!((metrics.avg_latency_ms() - 99.5).abs() < 0.1);
    }
}
