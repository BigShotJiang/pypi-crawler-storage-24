// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Circuit breaker with LLM-specific failure classification.
//!
//! State machine: CLOSED → OPEN (threshold breached) → HALF_OPEN
//! (recovery_timeout elapsed) → CLOSED (success_threshold met).

use std::sync::Arc;

use parking_lot::Mutex;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

use crate::clock::{Clock, MonotonicClock};
use crate::error::{ProxyError, Result};

/// LLM-specific failure types.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum FailureType {
    RateLimit,
    Auth,
    Timeout,
    Connection,
    ServiceError,
    Unknown,
}

impl FailureType {
    /// Human-readable label for Prometheus metrics.
    pub fn name(&self) -> &'static str {
        match self {
            FailureType::RateLimit => "rate_limit",
            FailureType::Auth => "auth",
            FailureType::Timeout => "timeout",
            FailureType::Connection => "connection",
            FailureType::ServiceError => "service_error",
            FailureType::Unknown => "unknown",
        }
    }
}

/// Circuit breaker state.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum CircuitState {
    Closed,
    Open,
    HalfOpen,
}

impl std::fmt::Display for CircuitState {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Closed => write!(f, "closed"),
            Self::Open => write!(f, "open"),
            Self::HalfOpen => write!(f, "half_open"),
        }
    }
}

/// Configuration for a circuit breaker.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct CircuitBreakerConfig {
    /// Number of failures before opening.
    pub failure_threshold: u32,
    /// Seconds to stay open before trying half-open.
    pub recovery_timeout_secs: f64,
    /// Consecutive successes in half-open to close.
    pub success_threshold: u32,
    /// Provider name (for error messages).
    pub provider: String,
}

impl CircuitBreakerConfig {
    pub fn new(provider: impl Into<String>) -> Self {
        Self {
            failure_threshold: 5,
            recovery_timeout_secs: 60.0,
            success_threshold: 2,
            provider: provider.into(),
        }
    }

    pub fn failure_threshold(mut self, n: u32) -> Self {
        self.failure_threshold = n;
        self
    }

    pub fn recovery_timeout(mut self, secs: f64) -> Self {
        self.recovery_timeout_secs = secs;
        self
    }

    pub fn success_threshold(mut self, n: u32) -> Self {
        self.success_threshold = n;
        self
    }
}

/// Metrics snapshot.
#[derive(Debug, Clone, Default)]
pub struct CircuitBreakerMetrics {
    pub total_calls: u64,
    pub total_successes: u64,
    pub total_failures: u64,
    pub state_transitions: u64,
}

struct Inner {
    state: CircuitState,
    failure_count: u32,
    success_count: u32,
    opened_at: f64,
    // Mutable config fields (moved here for hot-reload support)
    failure_threshold: u32,
    recovery_timeout_secs: f64,
    success_threshold: u32,
    metrics: CircuitBreakerMetrics,
}

/// Thread-safe circuit breaker with injectable clock.
pub struct CircuitBreaker {
    /// Provider name (immutable — never changes at runtime).
    provider_name: String,
    inner: Mutex<Inner>,
    clock: Arc<dyn Clock>,
}

impl CircuitBreaker {
    pub fn new(config: CircuitBreakerConfig) -> Self {
        Self::with_clock(config, Arc::new(MonotonicClock::new()))
    }

    pub fn with_clock(config: CircuitBreakerConfig, clock: Arc<dyn Clock>) -> Self {
        Self {
            provider_name: config.provider,
            inner: Mutex::new(Inner {
                state: CircuitState::Closed,
                failure_count: 0,
                success_count: 0,
                opened_at: 0.0,
                failure_threshold: config.failure_threshold,
                recovery_timeout_secs: config.recovery_timeout_secs,
                success_threshold: config.success_threshold,
                metrics: CircuitBreakerMetrics::default(),
            }),
            clock,
        }
    }

    /// Check if the circuit allows a call through.
    ///
    /// Automatically transitions OPEN → HALF_OPEN if recovery timeout elapsed.
    pub fn allow_request(&self) -> Result<()> {
        let mut inner = self.inner.lock();
        let now = self.clock.now_secs();

        match inner.state {
            CircuitState::Closed | CircuitState::HalfOpen => Ok(()),
            CircuitState::Open => {
                if now - inner.opened_at >= inner.recovery_timeout_secs {
                    // Transition to half-open
                    inner.state = CircuitState::HalfOpen;
                    inner.success_count = 0;
                    inner.metrics.state_transitions += 1;
                    Ok(())
                } else {
                    Err(ProxyError::CircuitOpen {
                        provider: self.provider_name.clone(),
                        failures: inner.failure_count,
                    })
                }
            }
        }
    }

    /// Record a successful call.
    pub fn record_success(&self) {
        self.record_success_transition();
    }

    /// Record a successful call, returning `(previous_state, new_state)` atomically.
    ///
    /// Use this when you need to detect state transitions without a TOCTOU race.
    pub fn record_success_transition(&self) -> (CircuitState, CircuitState) {
        let mut inner = self.inner.lock();
        let prev = inner.state;
        inner.metrics.total_calls += 1;
        inner.metrics.total_successes += 1;

        match inner.state {
            CircuitState::HalfOpen => {
                inner.success_count += 1;
                if inner.success_count >= inner.success_threshold {
                    inner.state = CircuitState::Closed;
                    inner.failure_count = 0;
                    inner.success_count = 0;
                    inner.metrics.state_transitions += 1;
                }
            }
            CircuitState::Closed => {
                // Reset failure count on success in closed state
                inner.failure_count = 0;
            }
            CircuitState::Open => {}
        }
        (prev, inner.state)
    }

    /// Record a failed call.
    pub fn record_failure(&self, failure_type: FailureType) {
        self.record_failure_transition(failure_type);
    }

    /// Record a failed call, returning `(previous_state, new_state)` atomically.
    ///
    /// Use this when you need to detect state transitions without a TOCTOU race.
    pub fn record_failure_transition(
        &self,
        _failure_type: FailureType,
    ) -> (CircuitState, CircuitState) {
        let mut inner = self.inner.lock();
        let now = self.clock.now_secs();
        let prev = inner.state;
        inner.metrics.total_calls += 1;
        inner.metrics.total_failures += 1;

        match inner.state {
            CircuitState::Closed => {
                inner.failure_count += 1;
                if inner.failure_count >= inner.failure_threshold {
                    inner.state = CircuitState::Open;
                    inner.opened_at = now;
                    inner.metrics.state_transitions += 1;
                }
            }
            CircuitState::HalfOpen => {
                // Any failure in half-open → back to open
                inner.state = CircuitState::Open;
                inner.opened_at = now;
                inner.success_count = 0;
                inner.metrics.state_transitions += 1;
            }
            CircuitState::Open => {}
        }
        (prev, inner.state)
    }

    /// Current state (with auto-transition check).
    pub fn state(&self) -> CircuitState {
        let mut inner = self.inner.lock();
        let now = self.clock.now_secs();

        if inner.state == CircuitState::Open && now - inner.opened_at >= inner.recovery_timeout_secs
        {
            inner.state = CircuitState::HalfOpen;
            inner.success_count = 0;
            inner.metrics.state_transitions += 1;
        }
        inner.state
    }

    /// Read-only state peek — does NOT trigger Open→HalfOpen auto-transition.
    ///
    /// Use this for observability (metrics, health RPCs) where you need to
    /// report state without side effects.
    pub fn peek_state(&self) -> CircuitState {
        self.inner.lock().state
    }

    /// Reset to closed state.
    pub fn reset(&self) {
        let mut inner = self.inner.lock();
        inner.state = CircuitState::Closed;
        inner.failure_count = 0;
        inner.success_count = 0;
        inner.metrics.state_transitions += 1;
    }

    /// Hot-reload circuit breaker thresholds at runtime.
    ///
    /// Updates failure threshold, recovery timeout, and success threshold
    /// without resetting current state or counters.
    pub fn update_thresholds(
        &self,
        failure_threshold: u32,
        recovery_timeout_secs: f64,
        success_threshold: u32,
    ) {
        let mut inner = self.inner.lock();
        inner.failure_threshold = failure_threshold;
        inner.recovery_timeout_secs = recovery_timeout_secs;
        inner.success_threshold = success_threshold;
    }

    pub fn metrics(&self) -> CircuitBreakerMetrics {
        self.inner.lock().metrics.clone()
    }
}

/// Classify an error message into a failure type.
pub fn classify_error(error_msg: &str) -> FailureType {
    let lower = error_msg.to_lowercase();
    if lower.contains("rate limit") || lower.contains("429") || lower.contains("too many") {
        FailureType::RateLimit
    } else if lower.contains("auth")
        || lower.contains("401")
        || lower.contains("api key")
        || lower.contains("unauthorized")
        || lower.contains("forbidden")
        || lower.contains("403")
    {
        FailureType::Auth
    } else if lower.contains("timeout") || lower.contains("timed out") || lower.contains("deadline")
    {
        FailureType::Timeout
    } else if lower.contains("connection")
        || lower.contains("network")
        || lower.contains("dns")
        || lower.contains("refused")
        || lower.contains("reset")
    {
        FailureType::Connection
    } else if lower.contains("500")
        || lower.contains("502")
        || lower.contains("503")
        || lower.contains("server error")
        || lower.contains("internal error")
        || lower.contains("overloaded")
    {
        FailureType::ServiceError
    } else {
        FailureType::Unknown
    }
}

/// Provider-specific default configurations.
pub fn provider_defaults(provider: &str) -> Option<CircuitBreakerConfig> {
    let (ft, rt, st) = match provider {
        "openai" => (5, 60.0, 2),
        "anthropic" => (5, 60.0, 2),
        "google" => (5, 60.0, 2),
        "azure_openai" => (5, 45.0, 2),
        "groq" => (3, 30.0, 1),
        "fireworks" => (5, 45.0, 2),
        "cerebras" => (3, 30.0, 1),
        "ollama" => (10, 15.0, 1),
        "together" => (5, 45.0, 2),
        "deepseek" => (5, 60.0, 2),
        "mistral" => (5, 60.0, 2),
        "cohere" => (5, 60.0, 2),
        "bedrock" => (5, 45.0, 2),
        "xai" => (5, 60.0, 2),
        "openrouter" => (5, 45.0, 2),
        _ => return None,
    };
    Some(
        CircuitBreakerConfig::new(provider)
            .failure_threshold(ft)
            .recovery_timeout(rt)
            .success_threshold(st),
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::clock::ManualClock;
    use std::sync::Arc;

    fn make_cb(threshold: u32, recovery: f64) -> (CircuitBreaker, Arc<ManualClock>) {
        let clock = Arc::new(ManualClock::new(0.0));
        let config = CircuitBreakerConfig::new("test")
            .failure_threshold(threshold)
            .recovery_timeout(recovery)
            .success_threshold(2);
        let cb = CircuitBreaker::with_clock(config, clock.clone());
        (cb, clock)
    }

    #[test]
    fn starts_closed() {
        let (cb, _) = make_cb(3, 10.0);
        assert_eq!(cb.state(), CircuitState::Closed);
        assert!(cb.allow_request().is_ok());
    }

    #[test]
    fn opens_after_threshold() {
        let (cb, _) = make_cb(3, 10.0);
        for _ in 0..3 {
            cb.record_failure(FailureType::ServiceError);
        }
        assert_eq!(cb.state(), CircuitState::Open);
        assert!(cb.allow_request().is_err());
    }

    #[test]
    fn transitions_to_half_open() {
        let (cb, clock) = make_cb(3, 10.0);
        for _ in 0..3 {
            cb.record_failure(FailureType::ServiceError);
        }
        assert_eq!(cb.state(), CircuitState::Open);

        clock.advance(10.0);
        assert_eq!(cb.state(), CircuitState::HalfOpen);
        assert!(cb.allow_request().is_ok());
    }

    #[test]
    fn half_open_to_closed_on_successes() {
        let (cb, clock) = make_cb(3, 10.0);
        for _ in 0..3 {
            cb.record_failure(FailureType::ServiceError);
        }
        clock.advance(10.0);
        assert_eq!(cb.state(), CircuitState::HalfOpen);

        cb.record_success();
        assert_eq!(cb.state(), CircuitState::HalfOpen);
        cb.record_success();
        assert_eq!(cb.state(), CircuitState::Closed);
    }

    #[test]
    fn half_open_failure_reopens() {
        let (cb, clock) = make_cb(3, 10.0);
        for _ in 0..3 {
            cb.record_failure(FailureType::ServiceError);
        }
        clock.advance(10.0);
        let _ = cb.state(); // trigger transition
        cb.record_failure(FailureType::ServiceError);
        assert_eq!(cb.state(), CircuitState::Open);
    }

    #[test]
    fn success_resets_failure_count() {
        let (cb, _) = make_cb(3, 10.0);
        cb.record_failure(FailureType::ServiceError);
        cb.record_failure(FailureType::ServiceError);
        cb.record_success(); // resets count
        cb.record_failure(FailureType::ServiceError);
        cb.record_failure(FailureType::ServiceError);
        // Only 2 failures since reset, not 3
        assert_eq!(cb.state(), CircuitState::Closed);
    }

    #[test]
    fn reset_works() {
        let (cb, _) = make_cb(3, 10.0);
        for _ in 0..3 {
            cb.record_failure(FailureType::ServiceError);
        }
        assert_eq!(cb.state(), CircuitState::Open);
        cb.reset();
        assert_eq!(cb.state(), CircuitState::Closed);
    }

    #[test]
    fn classify_error_types() {
        assert_eq!(
            classify_error("rate limit exceeded"),
            FailureType::RateLimit
        );
        assert_eq!(classify_error("HTTP 429"), FailureType::RateLimit);
        assert_eq!(classify_error("invalid API key"), FailureType::Auth);
        assert_eq!(classify_error("401 Unauthorized"), FailureType::Auth);
        assert_eq!(classify_error("request timeout"), FailureType::Timeout);
        assert_eq!(
            classify_error("connection refused"),
            FailureType::Connection
        );
        assert_eq!(
            classify_error("500 internal server error"),
            FailureType::ServiceError
        );
        assert_eq!(classify_error("something weird"), FailureType::Unknown);
    }

    #[test]
    fn provider_defaults_exist() {
        for name in &[
            "openai",
            "anthropic",
            "google",
            "groq",
            "fireworks",
            "cerebras",
            "ollama",
            "together",
            "deepseek",
            "mistral",
            "cohere",
            "bedrock",
            "xai",
            "openrouter",
            "azure_openai",
        ] {
            assert!(
                provider_defaults(name).is_some(),
                "missing default for {name}"
            );
        }
        assert!(provider_defaults("nonexistent").is_none());
    }

    #[test]
    fn metrics_tracking() {
        let (cb, clock) = make_cb(3, 10.0);
        cb.record_success();
        cb.record_failure(FailureType::Timeout);
        cb.record_failure(FailureType::Timeout);
        cb.record_failure(FailureType::Timeout);
        // Now open
        clock.advance(10.0);
        let _ = cb.state(); // half-open transition
        cb.record_success();
        cb.record_success(); // closes

        let m = cb.metrics();
        assert_eq!(m.total_calls, 6);
        assert_eq!(m.total_successes, 3);
        assert_eq!(m.total_failures, 3);
        // Transitions: closed→open, open→half_open, half_open→closed = 3
        assert_eq!(m.state_transitions, 3);
    }

    #[test]
    fn failure_type_names() {
        assert_eq!(FailureType::RateLimit.name(), "rate_limit");
        assert_eq!(FailureType::Auth.name(), "auth");
        assert_eq!(FailureType::Timeout.name(), "timeout");
        assert_eq!(FailureType::Connection.name(), "connection");
        assert_eq!(FailureType::ServiceError.name(), "service_error");
        assert_eq!(FailureType::Unknown.name(), "unknown");
    }

    #[test]
    fn peek_state_does_not_auto_transition() {
        let (cb, clock) = make_cb(3, 10.0);
        // Open the circuit
        for _ in 0..3 {
            cb.record_failure(FailureType::ServiceError);
        }
        assert_eq!(cb.peek_state(), CircuitState::Open);

        // Advance past recovery timeout
        clock.advance(10.0);

        // peek_state should NOT trigger Open→HalfOpen
        assert_eq!(cb.peek_state(), CircuitState::Open);

        // state() SHOULD trigger the auto-transition
        assert_eq!(cb.state(), CircuitState::HalfOpen);
    }

    #[test]
    fn transition_methods_return_prev_and_curr() {
        let (cb, clock) = make_cb(3, 10.0);

        // Failure that doesn't trigger transition
        let (prev, curr) = cb.record_failure_transition(FailureType::ServiceError);
        assert_eq!(prev, CircuitState::Closed);
        assert_eq!(curr, CircuitState::Closed);

        // Two more failures → should open
        cb.record_failure(FailureType::ServiceError);
        let (prev, curr) = cb.record_failure_transition(FailureType::ServiceError);
        assert_eq!(prev, CircuitState::Closed);
        assert_eq!(curr, CircuitState::Open);

        // Recover to half-open
        clock.advance(10.0);
        let _ = cb.state(); // trigger transition

        // Success in half-open (need 2 for close)
        let (prev, curr) = cb.record_success_transition();
        assert_eq!(prev, CircuitState::HalfOpen);
        assert_eq!(curr, CircuitState::HalfOpen);

        // Second success → closes
        let (prev, curr) = cb.record_success_transition();
        assert_eq!(prev, CircuitState::HalfOpen);
        assert_eq!(curr, CircuitState::Closed);
    }

    #[test]
    fn update_thresholds_at_runtime() {
        let (cb, clock) = make_cb(3, 10.0);

        // Default: opens after 3 failures
        cb.record_failure(FailureType::ServiceError);
        cb.record_failure(FailureType::ServiceError);
        assert_eq!(cb.state(), CircuitState::Closed);

        // Hot-reload: lower threshold to 2
        cb.update_thresholds(2, 5.0, 1);

        // Already have 2 failures, so next check should see threshold met
        // Need one more failure to trigger the check (failure_count is already 2 ≥ 2)
        // Actually failure_count is already 2, but the open transition happens
        // on record_failure when failure_count >= threshold. Since we already
        // recorded 2 and old threshold was 3, the state is still closed.
        // The next failure (3rd) will check against new threshold (2) — but
        // failure_count will be 3 ≥ 2, so it opens.
        cb.record_failure(FailureType::ServiceError);
        assert_eq!(cb.state(), CircuitState::Open);

        // Verify new recovery timeout: 5s instead of 10s
        clock.advance(5.0);
        assert_eq!(cb.state(), CircuitState::HalfOpen);

        // Verify new success threshold: 1 instead of 2
        cb.record_success();
        assert_eq!(cb.state(), CircuitState::Closed);
    }
}
