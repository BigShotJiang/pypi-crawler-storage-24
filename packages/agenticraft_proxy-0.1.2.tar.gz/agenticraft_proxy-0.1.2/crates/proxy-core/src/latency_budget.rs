// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Per-stage latency budgets (S6).
//!
//! Defines compile-time budget constants for every middleware stage in the
//! 41-stage pipeline. Without per-stage budgets, latency regressions hide
//! until production.
//!
//! ## Budget philosophy
//!
//! The pipeline grows from 15 to 41 middleware stages. If each stage adds 5μs,
//! that's 205μs overhead. Per-stage budgets keep total overhead under the
//! <50μs target for the fast path (excluding async stages like semantic cache
//! and output guardrails which run concurrently).

use std::time::Duration;

/// Latency budget for a single middleware stage.
#[derive(Debug, Clone)]
pub struct StageBudget {
    /// Stage name (matches the name used in `TimingLayer`).
    pub stage_name: &'static str,
    /// Maximum acceptable latency for this stage.
    pub budget: Duration,
    /// Threshold at which to emit a warning (typically 80% of budget).
    pub warn_threshold: Duration,
    /// Whether this stage runs asynchronously (exempt from fast-path budget).
    pub is_async: bool,
}

impl StageBudget {
    /// Create a budget with microsecond precision.
    const fn new_us(stage_name: &'static str, budget_us: u64, warn_us: u64) -> Self {
        Self {
            stage_name,
            budget: Duration::from_micros(budget_us),
            warn_threshold: Duration::from_micros(warn_us),
            is_async: false,
        }
    }

    /// Create a budget for an async stage (exempt from fast-path total).
    const fn new_async(stage_name: &'static str) -> Self {
        Self {
            stage_name,
            budget: Duration::from_millis(0), // No budget — runs concurrently
            warn_threshold: Duration::from_millis(0),
            is_async: true,
        }
    }

    /// Check if a measured duration exceeds this stage's budget.
    pub fn is_over_budget(&self, measured: Duration) -> bool {
        !self.is_async && measured > self.budget
    }

    /// Check if a measured duration exceeds the warning threshold.
    pub fn is_warning(&self, measured: Duration) -> bool {
        !self.is_async && measured > self.warn_threshold
    }
}

/// All stage budgets for the full 41-stage pipeline.
///
/// Stages are ordered as they appear in the pipeline (outermost → innermost).
pub static STAGE_BUDGETS: &[StageBudget] = &[
    // Stage 0: Admission control
    StageBudget::new_us("admission", 3, 2),
    // Stage 1: Output guardrails — async, runs on response path
    StageBudget::new_async("output_guardrails"),
    // Stage 2: Correlation ID
    StageBudget::new_us("correlation_id", 2, 1),
    // Stage 3: Security headers
    StageBudget::new_us("security_headers", 1, 1),
    // Stage 4: CORS — handled by tower-http, minimal overhead
    StageBudget::new_us("cors", 1, 1),
    // Stage 5: TraceLayer + RequestBodyLimitLayer + TimeoutLayer
    StageBudget::new_us("trace_body_timeout", 3, 2),
    // Stage 6: Identity (DID verify — Ed25519 is ~8μs)
    StageBudget::new_us("identity", 10, 8),
    // Stage 7: Federation verification (F20)
    StageBudget::new_us("federation", 5, 4),
    // Stage 8: Delegation chain verification (F12)
    StageBudget::new_us("delegation", 5, 4),
    // Stage 9: Zero-trust behavioral evaluation (F19)
    StageBudget::new_us("zero_trust", 5, 4),
    // Stage 10: Session (create/resume)
    StageBudget::new_us("session", 3, 2),
    // Stage 11: Auth (tenant resolution)
    StageBudget::new_us("auth", 3, 2),
    // Stage 12: Fraud detection (F23)
    StageBudget::new_us("fraud", 5, 4),
    // Stage 13: HITL check (F17 — may pause, but check itself is fast)
    StageBudget::new_us("hitl_check", 3, 2),
    // Stage 14: Idempotency check
    StageBudget::new_us("idempotency", 3, 2),
    // Stage 15: PII masking input (F2/AC1)
    StageBudget::new_us("pii_mask_input", 10, 8),
    // Stage 16: Input guardrails
    StageBudget::new_us("guardrails", 10, 8),
    // Stage 17: SLA pre-route check (F16)
    StageBudget::new_us("sla_pre_route", 3, 2),
    // Stage 18: Global rate limit
    StageBudget::new_us("rate_limit", 3, 2),
    // Stage 19: Tenant guard
    StageBudget::new_us("tenant_guard", 3, 2),
    // Stage 20: Budget check (hierarchical + workflow) (F5, F7)
    StageBudget::new_us("budget_check", 3, 2),
    // Stage 21: Tool call chain check (F6)
    StageBudget::new_us("tool_chain_check", 3, 2),
    // Stage 22: Tool permission verification WASM (F8)
    StageBudget::new_us("tool_permission", 50, 40),
    // Stage 23: Request validation
    StageBudget::new_us("validate_request", 5, 4),
    // Stage 24: Cache read — exact match
    StageBudget::new_us("cache_read", 2, 1),
    // Stage 25: Cache read — semantic (F1) — async, HNSW search ~1-5ms
    StageBudget::new_async("cache_semantic"),
    // Stage 26: Policy enforcement
    StageBudget::new_us("policy", 50, 40),
    // Stage 27: Compliance RequestReceived (F15)
    StageBudget::new_us("compliance_received", 2, 1),
    // Stage 28: Quality gate / A/B test routing (F21)
    StageBudget::new_us("quality_gate", 5, 4),
    // Stage 29: Cold-start buffer (F16/AC7) — may wait, budget is for check only
    StageBudget::new_us("cold_start_check", 3, 2),
    // Stage 30: Bulkhead acquire
    StageBudget::new_us("bulkhead", 3, 2),
    // Stage 31: Provider selection (F30 GPU-aware → Thompson fallback)
    StageBudget::new_us("provider_selection", 10, 8),
    // Stage 32: Compliance RequestRouted (F15)
    StageBudget::new_us("compliance_routed", 2, 1),
    // Stage 33: Provider dispatch — async, network I/O
    StageBudget::new_async("provider_dispatch"),
    // Stage 34: Output guardrails mode selection (F2)
    StageBudget::new_us("output_guard_select", 3, 2),
    // Stage 35: PII unmasking (F2/AC1)
    StageBudget::new_us("pii_unmask", 5, 4),
    // Stage 36: Stream instrumentation TTFT/ITL (F31) — async
    StageBudget::new_async("stream_instrumentation"),
    // Stage 37: Streaming transformers (F26) — async
    StageBudget::new_async("stream_transformers"),
    // Stage 38: Quality assessment (F21)
    StageBudget::new_us("quality_assess", 5, 4),
    // Stage 39: Economy metering (F22)
    StageBudget::new_us("economy_meter", 3, 2),
    // Stage 40: SLA record observation (F16)
    StageBudget::new_us("sla_record", 3, 2),
    // Stage 41: Compliance ResponseSent (F15)
    StageBudget::new_us("compliance_sent", 2, 1),
];

/// Calculate the total fast-path budget (sum of all non-async stages).
pub fn total_fast_path_budget() -> Duration {
    STAGE_BUDGETS
        .iter()
        .filter(|s| !s.is_async)
        .map(|s| s.budget)
        .sum()
}

/// Get the budget for a specific stage by name.
pub fn get_stage_budget(name: &str) -> Option<&'static StageBudget> {
    STAGE_BUDGETS.iter().find(|s| s.stage_name == name)
}

/// Check if a set of stage measurements violates any budgets.
/// Returns a list of (stage_name, measured, budget) for violations.
pub fn check_violations(
    measurements: &[(&str, Duration)],
) -> Vec<(&'static str, Duration, Duration)> {
    let mut violations = Vec::new();
    for (name, measured) in measurements {
        if let Some(budget) = get_stage_budget(name) {
            if budget.is_over_budget(*measured) {
                violations.push((budget.stage_name, *measured, budget.budget));
            }
        }
    }
    violations
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn total_budget_under_200us() {
        let total = total_fast_path_budget();
        // The 41-stage pipeline fast-path should stay well under 200μs
        assert!(
            total < Duration::from_micros(250),
            "total fast-path budget is {}μs, expected < 250μs",
            total.as_micros()
        );
    }

    #[test]
    fn all_stages_have_names() {
        for budget in STAGE_BUDGETS {
            assert!(!budget.stage_name.is_empty(), "stage budget has empty name");
        }
    }

    #[test]
    fn async_stages_have_zero_budget() {
        for budget in STAGE_BUDGETS {
            if budget.is_async {
                assert_eq!(
                    budget.budget,
                    Duration::ZERO,
                    "async stage {} should have zero budget",
                    budget.stage_name
                );
            }
        }
    }

    #[test]
    fn warn_threshold_lte_budget() {
        for budget in STAGE_BUDGETS {
            if !budget.is_async {
                assert!(
                    budget.warn_threshold <= budget.budget,
                    "stage {} warn threshold {}μs > budget {}μs",
                    budget.stage_name,
                    budget.warn_threshold.as_micros(),
                    budget.budget.as_micros()
                );
            }
        }
    }

    #[test]
    fn get_stage_budget_returns_correct() {
        let budget = get_stage_budget("identity").unwrap();
        assert_eq!(budget.budget, Duration::from_micros(10));
    }

    #[test]
    fn get_stage_budget_returns_none_for_unknown() {
        assert!(get_stage_budget("nonexistent").is_none());
    }

    #[test]
    fn is_over_budget_works() {
        let budget = get_stage_budget("admission").unwrap();
        assert!(!budget.is_over_budget(Duration::from_micros(2)));
        assert!(budget.is_over_budget(Duration::from_micros(5)));
    }

    #[test]
    fn async_stages_never_over_budget() {
        let budget = get_stage_budget("output_guardrails").unwrap();
        assert!(!budget.is_over_budget(Duration::from_secs(10)));
    }

    #[test]
    fn check_violations_detects_overage() {
        let measurements = vec![
            ("admission", Duration::from_micros(2)),    // within budget
            ("identity", Duration::from_micros(15)),    // over budget (10μs)
            ("rate_limit", Duration::from_micros(100)), // over budget (3μs)
        ];
        let violations = check_violations(&measurements);
        assert_eq!(violations.len(), 2);
    }

    #[test]
    fn check_violations_ignores_unknown_stages() {
        let measurements = vec![("nonexistent", Duration::from_secs(1))];
        let violations = check_violations(&measurements);
        assert!(violations.is_empty());
    }
}
