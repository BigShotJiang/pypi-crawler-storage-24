// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Evaluation & Quality Gates (F21).
//!
//! Lightweight heuristic quality scoring for LLM responses, per-provider
//! quality tracking, and A/B test infrastructure.
//!
//! - `QualityScorer::score()` runs in <1ms — no model calls.
//! - `QualityEvaluator` tracks running provider quality via `DashMap`.
//! - A/B tests split traffic and collect per-variant scores.

use std::collections::HashSet;

use dashmap::DashMap;
use parking_lot::RwLock;
use rand::Rng;

use crate::thompson::BetaPosterior;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

// ---------------------------------------------------------------------------
// Quality score
// ---------------------------------------------------------------------------

/// Heuristic quality assessment of a single LLM response.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct QualityScore {
    /// Sentence structure quality (0.0 - 1.0).
    pub coherence: f64,
    /// Keyword overlap between prompt and response (0.0 - 1.0).
    pub relevance: f64,
    /// `response.len() / prompt.len()` (unbounded, but clamped for `overall`).
    pub length_ratio: f64,
    /// Weighted average: `0.4 * coherence + 0.4 * relevance + 0.2 * length_ratio.min(1.0)`.
    pub overall: f64,
}

// ---------------------------------------------------------------------------
// Quality scorer
// ---------------------------------------------------------------------------

/// Stateless, lightweight quality scorer.
///
/// All heuristics are pure string analysis — no model calls, no allocations
/// beyond temporary word sets.
pub struct QualityScorer;

impl QualityScorer {
    /// Score a prompt/response pair.
    ///
    /// Runs in <1ms for typical LLM exchanges.
    pub fn score(prompt: &str, response: &str) -> QualityScore {
        let coherence = Self::compute_coherence(response);
        let relevance = Self::compute_relevance(prompt, response);
        let length_ratio = Self::compute_length_ratio(prompt, response);
        let overall = 0.4 * coherence + 0.4 * relevance + 0.2 * length_ratio.min(1.0);

        QualityScore {
            coherence,
            relevance,
            length_ratio,
            overall,
        }
    }

    /// Coherence heuristic based on sentence structure and vocabulary diversity.
    ///
    /// Components (equally weighted):
    /// - Sentence count score: penalise zero sentences, reward 2-20.
    /// - Average sentence length score: sweet spot around 10-25 words.
    /// - Vocabulary diversity: `unique_words / total_words`.
    fn compute_coherence(response: &str) -> f64 {
        if response.is_empty() {
            return 0.0;
        }

        // Split into sentences on '.', '!', '?'
        let sentences: Vec<&str> = response
            .split(|c: char| ['.', '!', '?'].contains(&c))
            .map(|s| s.trim())
            .filter(|s| !s.is_empty())
            .collect();

        let sentence_count = sentences.len();

        // Sentence count score: 0 for none, ramp up to 1.0 at 3+ sentences
        let sentence_count_score = match sentence_count {
            0 => 0.0,
            1 => 0.4,
            2 => 0.7,
            _ => 1.0,
        };

        // Word-level analysis
        let words: Vec<&str> = response
            .split_whitespace()
            .map(|w| w.trim_matches(|c: char| !c.is_alphanumeric()))
            .filter(|w| !w.is_empty())
            .collect();

        let total_words = words.len();
        if total_words == 0 {
            return 0.0;
        }

        // Average sentence length score: sweet spot 10-25 words
        let avg_sentence_len = total_words as f64 / sentence_count.max(1) as f64;
        let sentence_len_score = if avg_sentence_len < 3.0 {
            0.3
        } else if avg_sentence_len <= 25.0 {
            // Ramp from 0.5 at 3 words to 1.0 at 10 words, stay at 1.0 to 25
            if avg_sentence_len < 10.0 {
                0.5 + 0.5 * (avg_sentence_len - 3.0) / 7.0
            } else {
                1.0
            }
        } else {
            // Penalise very long sentences
            (25.0 / avg_sentence_len).min(1.0)
        };

        // Vocabulary diversity
        let unique: HashSet<&str> = words.iter().copied().collect();
        let diversity = unique.len() as f64 / total_words as f64;

        // Combine with equal weights
        (sentence_count_score + sentence_len_score + diversity) / 3.0
    }

    /// Relevance as keyword overlap ratio between prompt and response.
    fn compute_relevance(prompt: &str, response: &str) -> f64 {
        let prompt_words = Self::extract_keywords(prompt);
        if prompt_words.is_empty() {
            // No keywords in prompt — can't measure relevance, return neutral
            return 0.5;
        }

        let response_words = Self::extract_keywords(response);
        if response_words.is_empty() {
            return 0.0;
        }

        let overlap = prompt_words.intersection(&response_words).count();
        overlap as f64 / prompt_words.len() as f64
    }

    /// Length ratio: `response.len() / prompt.len().max(1)`.
    fn compute_length_ratio(prompt: &str, response: &str) -> f64 {
        response.len() as f64 / prompt.len().max(1) as f64
    }

    /// Extract lowercased alphanumeric keywords (words with 2+ chars).
    fn extract_keywords(text: &str) -> HashSet<String> {
        text.split_whitespace()
            .map(|w| {
                w.trim_matches(|c: char| !c.is_alphanumeric())
                    .to_lowercase()
            })
            .filter(|w| w.len() >= 2)
            .collect()
    }
}

// ---------------------------------------------------------------------------
// Provider quality tracker
// ---------------------------------------------------------------------------

/// Running average tracker for a single provider.
#[derive(Debug)]
pub struct ProviderQualityTracker {
    pub total_score: f64,
    pub count: u64,
}

impl ProviderQualityTracker {
    pub fn new() -> Self {
        Self {
            total_score: 0.0,
            count: 0,
        }
    }

    /// Record a score and update the running average.
    pub fn record(&mut self, score: f64) {
        self.total_score += score;
        self.count += 1;
    }

    /// Current running average, or `None` if no scores recorded.
    pub fn average(&self) -> Option<f64> {
        if self.count == 0 {
            None
        } else {
            Some(self.total_score / self.count as f64)
        }
    }
}

impl Default for ProviderQualityTracker {
    fn default() -> Self {
        Self::new()
    }
}

// ---------------------------------------------------------------------------
// Thompson sampling quality tracker
// ---------------------------------------------------------------------------

/// Thompson sampling-based provider quality tracker.
///
/// Uses a Beta posterior to track quality as a success/failure signal
/// (score above/below threshold). Supports decay to adapt to provider
/// quality changes over time.
#[derive(Debug)]
pub struct ThompsonQualityTracker {
    /// Beta posterior tracking success rate.
    pub posterior: BetaPosterior,
    /// Threshold above which a score counts as "success".
    pub threshold: f64,
    /// Decay factor for posterior updates.
    pub decay_factor: f64,
}

impl ThompsonQualityTracker {
    /// Create a new tracker with the given quality threshold and decay.
    pub fn new(threshold: f64, decay_factor: f64) -> Self {
        Self {
            posterior: BetaPosterior::new(),
            threshold,
            decay_factor,
        }
    }

    /// Record a quality score. Scores above `threshold` are treated as
    /// successes (reward = 1.0), below as failures (reward = 0.0).
    pub fn record(&mut self, score: f64) {
        let reward = if score >= self.threshold { 1.0 } else { 0.0 };
        self.posterior.update_with_decay(reward, self.decay_factor);
    }

    /// Expected quality rate (probability of above-threshold score).
    pub fn expected_quality(&self) -> f64 {
        self.posterior.expected_value()
    }
}

impl Default for ThompsonQualityTracker {
    fn default() -> Self {
        Self::new(0.5, 0.95)
    }
}

// ---------------------------------------------------------------------------
// A/B test types
// ---------------------------------------------------------------------------

/// Definition of an A/B test between two providers.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct ABTestDefinition {
    pub test_id: String,
    pub control_provider: String,
    pub treatment_provider: String,
    /// Fraction of traffic routed to treatment (0.0 - 1.0).
    pub traffic_split: f64,
    /// Unix timestamp (seconds).
    pub created_at: u64,
}

/// Aggregated results of an A/B test.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct ABTestResult {
    pub test_id: String,
    pub control_scores: Vec<f64>,
    pub treatment_scores: Vec<f64>,
    pub control_mean: f64,
    pub treatment_mean: f64,
    pub sample_count: usize,
}

/// Internal mutable state for a running A/B test.
#[derive(Debug)]
struct ABTestState {
    definition: ABTestDefinition,
    control_scores: RwLock<Vec<f64>>,
    treatment_scores: RwLock<Vec<f64>>,
}

// ---------------------------------------------------------------------------
// Quality stats
// ---------------------------------------------------------------------------

/// Snapshot of quality evaluator statistics.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct QualityStats {
    pub tracked_providers: usize,
    pub active_ab_tests: usize,
    pub quality_threshold: f64,
}

// ---------------------------------------------------------------------------
// Quality evaluator
// ---------------------------------------------------------------------------

/// Central quality evaluation engine.
///
/// Thread-safe — all public methods take `&self`.
pub struct QualityEvaluator {
    /// Running quality stats per provider.
    provider_quality: DashMap<String, ProviderQualityTracker>,
    /// Active A/B tests.
    ab_tests: DashMap<String, ABTestState>,
    /// Minimum acceptable overall quality score.
    pub quality_threshold: f64,
}

impl QualityEvaluator {
    /// Create a new evaluator with the given quality threshold.
    pub fn new(quality_threshold: f64) -> Self {
        Self {
            provider_quality: DashMap::new(),
            ab_tests: DashMap::new(),
            quality_threshold,
        }
    }

    /// Record a quality score for a provider, updating the running average.
    pub fn record_quality(&self, provider_id: &str, score: &QualityScore) {
        self.provider_quality
            .entry(provider_id.to_string())
            .or_default()
            .record(score.overall);
    }

    /// Get the running average quality for a provider.
    pub fn get_provider_quality(&self, provider_id: &str) -> Option<f64> {
        self.provider_quality
            .get(provider_id)
            .and_then(|t| t.average())
    }

    /// Check whether a request should be routed to the treatment variant.
    ///
    /// Returns `true` with probability `traffic_split` for the given test.
    /// Returns `false` if the test does not exist.
    pub fn should_route_to_treatment(&self, test_id: &str) -> bool {
        let split = match self.ab_tests.get(test_id) {
            Some(state) => state.definition.traffic_split,
            None => return false,
        };
        let mut rng = rand::thread_rng();
        rng.gen::<f64>() < split
    }

    /// Register a new A/B test.
    pub fn create_ab_test(&self, definition: ABTestDefinition) {
        let test_id = definition.test_id.clone();
        self.ab_tests.insert(
            test_id,
            ABTestState {
                definition,
                control_scores: RwLock::new(Vec::new()),
                treatment_scores: RwLock::new(Vec::new()),
            },
        );
    }

    /// Record a quality score observation for an A/B test variant.
    pub fn record_ab_result(&self, test_id: &str, is_treatment: bool, score: f64) {
        if let Some(state) = self.ab_tests.get(test_id) {
            if is_treatment {
                state.treatment_scores.write().push(score);
            } else {
                state.control_scores.write().push(score);
            }
        }
    }

    /// Get aggregated results for an A/B test.
    pub fn get_ab_results(&self, test_id: &str) -> Option<ABTestResult> {
        let state = self.ab_tests.get(test_id)?;

        let control = state.control_scores.read().clone();
        let treatment = state.treatment_scores.read().clone();

        let control_mean = if control.is_empty() {
            0.0
        } else {
            control.iter().sum::<f64>() / control.len() as f64
        };

        let treatment_mean = if treatment.is_empty() {
            0.0
        } else {
            treatment.iter().sum::<f64>() / treatment.len() as f64
        };

        let sample_count = control.len() + treatment.len();

        Some(ABTestResult {
            test_id: test_id.to_string(),
            control_scores: control,
            treatment_scores: treatment,
            control_mean,
            treatment_mean,
            sample_count,
        })
    }

    /// Snapshot of evaluator statistics.
    pub fn stats(&self) -> QualityStats {
        QualityStats {
            tracked_providers: self.provider_quality.len(),
            active_ab_tests: self.ab_tests.len(),
            quality_threshold: self.quality_threshold,
        }
    }
}

impl Default for QualityEvaluator {
    fn default() -> Self {
        Self::new(0.5)
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn score_simple_prompt_response() {
        let prompt = "What is the capital of France?";
        let response = "The capital of France is Paris. It is known for the Eiffel Tower.";

        let score = QualityScorer::score(prompt, response);

        assert!(score.coherence > 0.0 && score.coherence <= 1.0);
        assert!(score.relevance > 0.0 && score.relevance <= 1.0);
        assert!(score.length_ratio > 0.0);
        assert!(score.overall > 0.0 && score.overall <= 1.0);
    }

    #[test]
    fn empty_response_gets_low_score() {
        let prompt = "Explain quantum computing.";
        let response = "";

        let score = QualityScorer::score(prompt, response);

        assert_eq!(score.coherence, 0.0);
        assert_eq!(score.relevance, 0.0);
        assert!(score.length_ratio < f64::EPSILON);
        assert!(score.overall < 0.1);
    }

    #[test]
    fn high_quality_response_gets_high_score() {
        let prompt = "Explain the benefits of Rust for systems programming.";
        let response = "\
            Rust offers several key benefits for systems programming. \
            First, Rust provides memory safety without garbage collection, \
            eliminating entire classes of bugs at compile time. \
            Second, Rust enables fearless concurrency through its ownership \
            and borrowing system, preventing data races. \
            Third, Rust achieves zero-cost abstractions, meaning high-level \
            constructs compile to efficient machine code. \
            Finally, Rust has excellent tooling including Cargo for package \
            management and built-in testing support.";

        let score = QualityScorer::score(prompt, response);

        // Long, relevant, coherent response should score well
        assert!(
            score.coherence > 0.5,
            "coherence should be high, got {}",
            score.coherence
        );
        assert!(
            score.relevance > 0.3,
            "relevance should be decent, got {}",
            score.relevance
        );
        assert!(
            score.overall > 0.4,
            "overall should be above threshold, got {}",
            score.overall
        );
    }

    #[test]
    fn provider_quality_tracking() {
        let evaluator = QualityEvaluator::new(0.5);

        let prompt = "test prompt";
        let response1 = "First response with some content here.";
        let response2 = "Second response with different content and more words included.";

        let score1 = QualityScorer::score(prompt, response1);
        let score2 = QualityScorer::score(prompt, response2);

        evaluator.record_quality("openai", &score1);
        evaluator.record_quality("openai", &score2);

        let avg = evaluator.get_provider_quality("openai").unwrap();
        let expected = (score1.overall + score2.overall) / 2.0;
        assert!(
            (avg - expected).abs() < 1e-10,
            "running average should be ({} + {}) / 2 = {}, got {}",
            score1.overall,
            score2.overall,
            expected,
            avg
        );

        // Unknown provider returns None
        assert!(evaluator.get_provider_quality("unknown").is_none());
    }

    #[test]
    fn ab_test_creation_and_recording() {
        let evaluator = QualityEvaluator::new(0.5);

        let def = ABTestDefinition {
            test_id: "test-1".to_string(),
            control_provider: "openai".to_string(),
            treatment_provider: "anthropic".to_string(),
            traffic_split: 0.5,
            created_at: 1700000000,
        };

        evaluator.create_ab_test(def);

        // Record some results
        evaluator.record_ab_result("test-1", false, 0.8);
        evaluator.record_ab_result("test-1", false, 0.7);
        evaluator.record_ab_result("test-1", true, 0.9);
        evaluator.record_ab_result("test-1", true, 0.85);

        let results = evaluator.get_ab_results("test-1").unwrap();
        assert_eq!(results.control_scores.len(), 2);
        assert_eq!(results.treatment_scores.len(), 2);
        assert_eq!(results.sample_count, 4);
    }

    #[test]
    fn ab_test_computes_correct_means() {
        let evaluator = QualityEvaluator::new(0.5);

        let def = ABTestDefinition {
            test_id: "test-means".to_string(),
            control_provider: "openai".to_string(),
            treatment_provider: "anthropic".to_string(),
            traffic_split: 0.5,
            created_at: 1700000000,
        };

        evaluator.create_ab_test(def);

        evaluator.record_ab_result("test-means", false, 0.6);
        evaluator.record_ab_result("test-means", false, 0.8);
        evaluator.record_ab_result("test-means", false, 1.0);

        evaluator.record_ab_result("test-means", true, 0.5);
        evaluator.record_ab_result("test-means", true, 0.7);

        let results = evaluator.get_ab_results("test-means").unwrap();

        let expected_control_mean = (0.6 + 0.8 + 1.0) / 3.0;
        let expected_treatment_mean = (0.5 + 0.7) / 2.0;

        assert!(
            (results.control_mean - expected_control_mean).abs() < 1e-10,
            "control mean: expected {}, got {}",
            expected_control_mean,
            results.control_mean
        );
        assert!(
            (results.treatment_mean - expected_treatment_mean).abs() < 1e-10,
            "treatment mean: expected {}, got {}",
            expected_treatment_mean,
            results.treatment_mean
        );
    }

    #[test]
    fn quality_threshold_comparison() {
        let evaluator = QualityEvaluator::new(0.6);

        let prompt = "test prompt for quality";
        let good_response = "This is a well-written response about the test prompt for quality. \
            It covers the topic thoroughly and provides detailed information.";
        let bad_response = "ok";

        let good_score = QualityScorer::score(prompt, good_response);
        let bad_score = QualityScorer::score(prompt, bad_response);

        evaluator.record_quality("good-provider", &good_score);
        evaluator.record_quality("bad-provider", &bad_score);

        let good_avg = evaluator.get_provider_quality("good-provider").unwrap();
        let bad_avg = evaluator.get_provider_quality("bad-provider").unwrap();

        // The good provider should exceed threshold, bad should not
        assert!(
            good_avg > bad_avg,
            "good provider ({}) should outscore bad provider ({})",
            good_avg,
            bad_avg
        );

        // Stats should reflect tracked state
        let stats = evaluator.stats();
        assert_eq!(stats.tracked_providers, 2);
        assert!((stats.quality_threshold - 0.6).abs() < 1e-10);
    }

    #[test]
    fn traffic_split_routes_correctly() {
        let evaluator = QualityEvaluator::new(0.5);

        let def = ABTestDefinition {
            test_id: "split-test".to_string(),
            control_provider: "openai".to_string(),
            treatment_provider: "anthropic".to_string(),
            traffic_split: 0.3, // 30% to treatment
            created_at: 1700000000,
        };

        evaluator.create_ab_test(def);

        let trials = 1000;
        let mut treatment_count = 0;
        for _ in 0..trials {
            if evaluator.should_route_to_treatment("split-test") {
                treatment_count += 1;
            }
        }

        let treatment_ratio = treatment_count as f64 / trials as f64;

        // With 1000 trials at 30% split, we expect ~300 treatments.
        // Allow generous margin: 20%-40% (binomial 99.9% CI is roughly +-4.5%).
        assert!(
            (0.20..=0.40).contains(&treatment_ratio),
            "treatment ratio should be ~0.30, got {} ({}/{} trials)",
            treatment_ratio,
            treatment_count,
            trials
        );

        // Non-existent test should always return false
        assert!(!evaluator.should_route_to_treatment("nonexistent"));
    }

    // -----------------------------------------------------------------------
    // ThompsonQualityTracker tests
    // -----------------------------------------------------------------------

    #[test]
    fn thompson_quality_tracker_high_scores_increase_expected() {
        let mut tracker = ThompsonQualityTracker::new(0.5, 0.95);

        // Record several high quality scores
        for _ in 0..20 {
            tracker.record(0.8);
        }

        assert!(
            tracker.expected_quality() > 0.7,
            "expected quality should be high after consistent good scores, got {}",
            tracker.expected_quality()
        );
    }

    #[test]
    fn thompson_quality_tracker_low_scores_decrease_expected() {
        let mut tracker = ThompsonQualityTracker::new(0.5, 0.95);

        // Record several low quality scores
        for _ in 0..20 {
            tracker.record(0.2);
        }

        assert!(
            tracker.expected_quality() < 0.3,
            "expected quality should be low after consistent bad scores, got {}",
            tracker.expected_quality()
        );
    }
}
