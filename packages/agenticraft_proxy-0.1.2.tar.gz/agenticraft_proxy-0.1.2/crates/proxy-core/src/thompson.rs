// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Cost-aware Thompson sampling router for LLM providers.
//!
//! Multi-objective scoring combining quality, cost, and latency signals.

use parking_lot::Mutex;
use rand::Rng;
use rand_distr::{Beta, Distribution};

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

use crate::error::{ProxyError, Result};
use crate::routing::RoutingStrategy;
use std::time::Duration;

// ---------------------------------------------------------------------------
// Beta posterior
// ---------------------------------------------------------------------------

/// Beta distribution posterior for a single provider.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct BetaPosterior {
    pub alpha: f64,
    pub beta: f64,
}

impl BetaPosterior {
    pub fn new() -> Self {
        Self {
            alpha: 1.0,
            beta: 1.0,
        }
    }

    pub fn with_params(alpha: f64, beta: f64) -> Self {
        Self { alpha, beta }
    }

    /// Sample from the Beta(α, β) distribution.
    pub fn sample<R: Rng>(&self, rng: &mut R) -> Result<f64> {
        let dist = Beta::new(self.alpha, self.beta).map_err(|e| {
            ProxyError::SamplingError(format!(
                "invalid Beta({}, {}): {}",
                self.alpha, self.beta, e
            ))
        })?;
        Ok(dist.sample(rng))
    }

    /// Expected value E[X] = α / (α + β).
    pub fn expected_value(&self) -> f64 {
        self.alpha / (self.alpha + self.beta)
    }

    /// Standard Bayesian update.
    pub fn update(&mut self, reward: f64) {
        self.alpha += reward;
        self.beta += 1.0 - reward;
    }

    /// Update with exponential decay to prevent posterior rigidity.
    ///
    /// α = α * decay + reward
    /// β = β * decay + (1 - reward)
    /// Both floored at 1.0 to keep the distribution valid.
    pub fn update_with_decay(&mut self, reward: f64, decay_factor: f64) {
        self.alpha = (self.alpha * decay_factor + reward).max(1.0);
        self.beta = (self.beta * decay_factor + (1.0 - reward)).max(1.0);
    }
}

impl Default for BetaPosterior {
    fn default() -> Self {
        Self::new()
    }
}

// ---------------------------------------------------------------------------
// Provider profile
// ---------------------------------------------------------------------------

/// Static cost/quality/latency profile for a provider.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct ProviderProfile {
    pub id: String,
    /// Cost per 1k tokens (blended input/output).
    pub cost_per_1k: f64,
    /// Baseline quality score in [0, 1].
    pub base_quality: f64,
    /// Baseline P50 latency in milliseconds.
    pub base_latency_ms: f64,
    /// Learned posterior.
    pub posterior: BetaPosterior,
}

impl ProviderProfile {
    pub fn new(
        id: impl Into<String>,
        cost_per_1k: f64,
        base_quality: f64,
        base_latency_ms: f64,
    ) -> Self {
        Self {
            id: id.into(),
            cost_per_1k,
            base_quality,
            base_latency_ms,
            posterior: BetaPosterior::new(),
        }
    }
}

// ---------------------------------------------------------------------------
// Weights and config
// ---------------------------------------------------------------------------

/// Scoring weights — fully configurable, no hardcoded formulas.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct RouterWeights {
    pub cost: f64,
    pub quality: f64,
    pub latency: f64,
}

impl Default for RouterWeights {
    fn default() -> Self {
        Self {
            cost: 0.5,
            quality: 0.35,
            latency: 0.15,
        }
    }
}

/// Router configuration.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct RouterConfig {
    pub weights: RouterWeights,
    /// Enable Thompson sampling exploration (vs. deterministic).
    pub explore_mode: bool,
    /// Decay factor for posterior updates (prevents rigidity).
    pub decay_factor: f64,
    /// Fallback provider ID when all others score below zero.
    pub fallback_provider: Option<String>,
}

impl Default for RouterConfig {
    fn default() -> Self {
        Self {
            weights: RouterWeights::default(),
            explore_mode: true,
            decay_factor: 0.95,
            fallback_provider: None,
        }
    }
}

impl RouterConfig {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn weights(mut self, w: RouterWeights) -> Self {
        self.weights = w;
        self
    }

    pub fn explore(mut self, on: bool) -> Self {
        self.explore_mode = on;
        self
    }

    pub fn decay_factor(mut self, d: f64) -> Self {
        self.decay_factor = d;
        self
    }

    pub fn fallback(mut self, provider: impl Into<String>) -> Self {
        self.fallback_provider = Some(provider.into());
        self
    }
}

// ---------------------------------------------------------------------------
// Routing decision
// ---------------------------------------------------------------------------

/// Result of a routing decision.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct RoutingDecision {
    pub provider_id: String,
    pub score: f64,
    pub is_explore: bool,
}

// ---------------------------------------------------------------------------
// Thompson router
// ---------------------------------------------------------------------------

struct Inner {
    providers: Vec<ProviderProfile>,
    config: RouterConfig,
}

/// Thread-safe Thompson sampling router.
///
/// All public methods are `&self` (no `&mut self`) — internal mutation
/// is behind a [`parking_lot::Mutex`].
pub struct ThompsonRouter {
    inner: Mutex<Inner>,
}

impl ThompsonRouter {
    pub fn new(config: RouterConfig) -> Self {
        Self {
            inner: Mutex::new(Inner {
                providers: Vec::new(),
                config,
            }),
        }
    }

    /// Add a provider profile.
    pub fn add_provider(&self, profile: ProviderProfile) {
        self.inner.lock().providers.push(profile);
    }

    /// Number of registered providers.
    pub fn provider_count(&self) -> usize {
        self.inner.lock().providers.len()
    }

    /// Deterministic selection using expected values (no sampling).
    pub fn select_deterministic(&self) -> Result<RoutingDecision> {
        let inner = self.inner.lock();
        if inner.providers.is_empty() {
            return Err(ProxyError::NoProviders);
        }

        let w = &inner.config.weights;
        let mut best: Option<(usize, f64)> = None;

        for (i, p) in inner.providers.iter().enumerate() {
            let quality_prob = p.posterior.expected_value();
            let score = Self::compute_score(quality_prob, p, w);
            let is_better = match best {
                None => true,
                Some((_, best_score)) => score > best_score,
            };
            if is_better {
                best = Some((i, score));
            }
        }

        let (idx, score) = best.ok_or(ProxyError::NoProviders)?;
        Ok(RoutingDecision {
            provider_id: inner.providers[idx].id.clone(),
            score,
            is_explore: false,
        })
    }

    /// Exploration selection using Thompson sampling with an explicit RNG.
    pub fn select_explore<R: Rng>(&self, rng: &mut R) -> Result<RoutingDecision> {
        let inner = self.inner.lock();
        if inner.providers.is_empty() {
            return Err(ProxyError::NoProviders);
        }

        let w = &inner.config.weights;
        let mut best: Option<(usize, f64)> = None;

        for (i, p) in inner.providers.iter().enumerate() {
            let quality_prob = p.posterior.sample(rng)?;
            let score = Self::compute_score(quality_prob, p, w);
            let is_better = match best {
                None => true,
                Some((_, best_score)) => score > best_score,
            };
            if is_better {
                best = Some((i, score));
            }
        }

        let (idx, score) = best.ok_or(ProxyError::NoProviders)?;
        Ok(RoutingDecision {
            provider_id: inner.providers[idx].id.clone(),
            score,
            is_explore: true,
        })
    }

    /// Auto selection: uses `thread_rng` if explore_mode, else deterministic.
    pub fn select_auto(&self) -> Result<RoutingDecision> {
        let explore = self.inner.lock().config.explore_mode;
        if explore {
            self.select_explore(&mut rand::thread_rng())
        } else {
            self.select_deterministic()
        }
    }

    /// Rank providers filtered to `eligible_ids`, best-to-worst.
    ///
    /// If `eligible_ids` is empty, **all** providers are ranked — this gives
    /// unknown/fine-tuned models a full fallback chain rather than a single pick.
    ///
    /// Respects `explore_mode`: samples Beta posteriors when exploring, uses
    /// expected values when deterministic. Posteriors are sampled once per call.
    pub fn rank_among(&self, eligible_ids: &[&str]) -> Result<Vec<RoutingDecision>> {
        let inner = self.inner.lock();
        let explore = inner.config.explore_mode;

        let candidates: Vec<&ProviderProfile> = if eligible_ids.is_empty() {
            inner.providers.iter().collect()
        } else {
            inner
                .providers
                .iter()
                .filter(|p| eligible_ids.contains(&p.id.as_str()))
                .collect()
        };

        if candidates.is_empty() {
            return Err(ProxyError::NoProviders);
        }

        let w = &inner.config.weights;
        let mut rng = rand::thread_rng();
        let mut scored: Vec<RoutingDecision> = Vec::with_capacity(candidates.len());

        for p in &candidates {
            let quality_prob = if explore {
                p.posterior.sample(&mut rng)?
            } else {
                p.posterior.expected_value()
            };
            let score = Self::compute_score(quality_prob, p, w);
            scored.push(RoutingDecision {
                provider_id: p.id.clone(),
                score,
                is_explore: explore,
            });
        }

        scored.sort_by(|a, b| {
            b.score
                .partial_cmp(&a.score)
                .unwrap_or(std::cmp::Ordering::Equal)
        });
        Ok(scored)
    }

    /// Record an observed outcome for a provider.
    ///
    /// `reward` should be in [0, 1]: 1.0 = perfect, 0.0 = total failure.
    pub fn record_outcome(&self, provider_id: &str, reward: f64) -> Result<()> {
        let mut inner = self.inner.lock();
        let decay = inner.config.decay_factor;
        let profile = inner
            .providers
            .iter_mut()
            .find(|p| p.id == provider_id)
            .ok_or_else(|| ProxyError::ProviderNotFound(provider_id.to_string()))?;
        profile.posterior.update_with_decay(reward, decay);
        Ok(())
    }

    /// Update router config.
    pub fn set_config(&self, config: RouterConfig) {
        self.inner.lock().config = config;
    }

    /// Get current config (clone).
    pub fn config(&self) -> RouterConfig {
        self.inner.lock().config.clone()
    }

    /// Get Thompson posteriors for all providers: `(id, alpha, beta)`.
    pub fn get_posteriors(&self) -> Vec<(String, f64, f64)> {
        let inner = self.inner.lock();
        inner
            .providers
            .iter()
            .map(|p| (p.id.clone(), p.posterior.alpha, p.posterior.beta))
            .collect()
    }

    /// Restore posteriors from a previous session.
    /// Unknown provider IDs silently skipped (handles provider list changes).
    /// Invalid params (alpha < 1.0 or beta < 1.0) silently skipped.
    pub fn restore_posteriors(&self, posteriors: &[(String, f64, f64)]) {
        let mut inner = self.inner.lock();
        for (id, alpha, beta) in posteriors {
            if *alpha >= 1.0 && *beta >= 1.0 {
                if let Some(profile) = inner.providers.iter_mut().find(|p| p.id == *id) {
                    profile.posterior = BetaPosterior::with_params(*alpha, *beta);
                }
            }
        }
    }

    /// Remove a provider by ID. Returns `true` if found and removed.
    pub fn remove_provider(&self, id: &str) -> bool {
        let mut inner = self.inner.lock();
        let before = inner.providers.len();
        inner.providers.retain(|p| p.id != id);
        inner.providers.len() < before
    }

    /// Multi-objective score combining quality, cost, and latency.
    fn compute_score(quality_prob: f64, p: &ProviderProfile, w: &RouterWeights) -> f64 {
        quality_prob * p.base_quality * w.quality
            - p.cost_per_1k * w.cost
            - (p.base_latency_ms / 1000.0) * w.latency
    }
}

// ---------------------------------------------------------------------------
// Default provider profiles
// ---------------------------------------------------------------------------

/// Default profiles for 12 common providers.
pub fn default_profiles() -> Vec<ProviderProfile> {
    vec![
        ProviderProfile::new("openai", 0.030, 0.92, 800.0),
        ProviderProfile::new("anthropic", 0.025, 0.93, 900.0),
        ProviderProfile::new("google", 0.020, 0.90, 750.0),
        ProviderProfile::new("groq", 0.002, 0.85, 200.0),
        ProviderProfile::new("together", 0.008, 0.84, 400.0),
        ProviderProfile::new("fireworks", 0.005, 0.83, 350.0),
        ProviderProfile::new("deepseek", 0.004, 0.86, 600.0),
        ProviderProfile::new("cerebras", 0.003, 0.82, 250.0),
        ProviderProfile::new("ollama", 0.000, 0.78, 500.0),
        ProviderProfile::new("mistral", 0.012, 0.88, 650.0),
        ProviderProfile::new("cohere", 0.015, 0.85, 700.0),
        ProviderProfile::new("azure_openai", 0.030, 0.92, 780.0),
    ]
}

impl RoutingStrategy for ThompsonRouter {
    fn select(&self, candidates: &[&str], _key: Option<&str>) -> Option<String> {
        self.rank_among(candidates)
            .ok()
            .and_then(|decisions| decisions.into_iter().next())
            .map(|d| d.provider_id)
    }

    fn record_success(&self, provider: &str, _latency: Duration) {
        let _ = self.record_outcome(provider, 1.0);
    }

    fn record_failure(&self, provider: &str) {
        let _ = self.record_outcome(provider, 0.0);
    }

    fn name(&self) -> &str {
        "thompson"
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use rand::rngs::StdRng;
    use rand::SeedableRng;

    fn seeded_rng() -> StdRng {
        StdRng::seed_from_u64(42)
    }

    #[test]
    fn beta_posterior_expected_value() {
        let p = BetaPosterior::new();
        assert!((p.expected_value() - 0.5).abs() < 1e-10);

        let p2 = BetaPosterior::with_params(10.0, 2.0);
        assert!((p2.expected_value() - 10.0 / 12.0).abs() < 1e-10);
    }

    #[test]
    fn beta_posterior_sample_in_range() {
        let p = BetaPosterior::with_params(2.0, 5.0);
        let mut rng = seeded_rng();
        for _ in 0..100 {
            let s = p.sample(&mut rng).unwrap();
            assert!((0.0..=1.0).contains(&s));
        }
    }

    #[test]
    fn beta_posterior_update() {
        let mut p = BetaPosterior::new();
        p.update(1.0);
        assert_eq!(p.alpha, 2.0);
        assert_eq!(p.beta, 1.0);

        p.update(0.0);
        assert_eq!(p.alpha, 2.0);
        assert_eq!(p.beta, 2.0);
    }

    #[test]
    fn beta_posterior_update_with_decay() {
        let mut p = BetaPosterior::with_params(10.0, 10.0);
        p.update_with_decay(1.0, 0.9);
        // α = 10 * 0.9 + 1.0 = 10.0
        assert!((p.alpha - 10.0).abs() < 1e-10);
        // β = 10 * 0.9 + 0.0 = 9.0
        assert!((p.beta - 9.0).abs() < 1e-10);
    }

    #[test]
    fn decay_floors_at_one() {
        let mut p = BetaPosterior::with_params(0.5, 0.5);
        p.update_with_decay(0.0, 0.1);
        assert!(p.alpha >= 1.0);
        assert!(p.beta >= 1.0);
    }

    #[test]
    fn router_no_providers_errors() {
        let router = ThompsonRouter::new(RouterConfig::default());
        assert!(router.select_deterministic().is_err());
        assert!(router.select_auto().is_err());
    }

    #[test]
    fn router_deterministic_picks_best() {
        let config = RouterConfig::new().explore(false);
        let router = ThompsonRouter::new(config);

        // Add two providers: one cheap/fast/low-quality, one expensive/slow/high-quality
        router.add_provider(ProviderProfile::new("cheap", 0.001, 0.5, 100.0));
        router.add_provider(ProviderProfile::new("quality", 0.050, 0.99, 1000.0));

        let decision = router.select_deterministic().unwrap();
        assert!(!decision.is_explore);
        // With default weights (cost=0.5, quality=0.35, latency=0.15),
        // both are competitive — just verify we get a valid decision
        assert!(!decision.provider_id.is_empty());
    }

    #[test]
    fn router_explore_produces_variance() {
        let router = ThompsonRouter::new(RouterConfig::new().explore(true));
        for p in default_profiles() {
            router.add_provider(p);
        }

        let mut rng = seeded_rng();
        let mut selections = std::collections::HashMap::new();
        for _ in 0..100 {
            let d = router.select_explore(&mut rng).unwrap();
            *selections.entry(d.provider_id).or_insert(0) += 1;
        }
        // Thompson sampling should explore multiple providers
        assert!(
            selections.len() > 1,
            "expected exploration across providers, got {:?}",
            selections
        );
    }

    #[test]
    fn router_record_outcome() {
        let router = ThompsonRouter::new(RouterConfig::default());
        router.add_provider(ProviderProfile::new("test", 0.01, 0.9, 500.0));

        router.record_outcome("test", 1.0).unwrap();
        router.record_outcome("test", 0.0).unwrap();

        // Unknown provider errors
        assert!(router.record_outcome("unknown", 1.0).is_err());
    }

    #[test]
    fn router_auto_respects_config() {
        let router = ThompsonRouter::new(RouterConfig::new().explore(false));
        router.add_provider(ProviderProfile::new("a", 0.01, 0.9, 500.0));

        let d = router.select_auto().unwrap();
        assert!(!d.is_explore);
    }

    #[test]
    fn rank_among_filtered_selection() {
        let config = RouterConfig::new().explore(false);
        let router = ThompsonRouter::new(config);
        router.add_provider(ProviderProfile::new("openai", 0.03, 0.92, 800.0));
        router.add_provider(ProviderProfile::new("groq", 0.002, 0.85, 200.0));
        router.add_provider(ProviderProfile::new("anthropic", 0.025, 0.93, 900.0));

        let ranked = router.rank_among(&["openai", "groq"]).unwrap();
        assert_eq!(ranked.len(), 2);
        // Both should be openai or groq, not anthropic
        for d in &ranked {
            assert!(
                d.provider_id == "openai" || d.provider_id == "groq",
                "unexpected provider: {}",
                d.provider_id
            );
        }
        // Should be sorted best-to-worst
        assert!(ranked[0].score >= ranked[1].score);
    }

    #[test]
    fn rank_among_empty_filter_ranks_all() {
        let config = RouterConfig::new().explore(false);
        let router = ThompsonRouter::new(config);
        router.add_provider(ProviderProfile::new("openai", 0.03, 0.92, 800.0));
        router.add_provider(ProviderProfile::new("groq", 0.002, 0.85, 200.0));

        let ranked = router.rank_among(&[]).unwrap();
        assert_eq!(ranked.len(), 2, "empty filter should rank all providers");
    }

    #[test]
    fn rank_among_no_match_returns_error() {
        let config = RouterConfig::new().explore(false);
        let router = ThompsonRouter::new(config);
        router.add_provider(ProviderProfile::new("openai", 0.03, 0.92, 800.0));

        let result = router.rank_among(&["nonexistent"]);
        assert!(result.is_err());
    }

    #[test]
    fn rank_among_single_eligible() {
        let config = RouterConfig::new().explore(false);
        let router = ThompsonRouter::new(config);
        router.add_provider(ProviderProfile::new("openai", 0.03, 0.92, 800.0));
        router.add_provider(ProviderProfile::new("groq", 0.002, 0.85, 200.0));

        let ranked = router.rank_among(&["groq"]).unwrap();
        assert_eq!(ranked.len(), 1);
        assert_eq!(ranked[0].provider_id, "groq");
    }

    #[test]
    fn default_profiles_count() {
        assert_eq!(default_profiles().len(), 12);
    }

    #[test]
    fn router_config_builder() {
        let w = RouterWeights {
            cost: 0.8,
            quality: 0.1,
            latency: 0.1,
        };
        let config = RouterConfig::new()
            .weights(w)
            .explore(false)
            .decay_factor(0.99)
            .fallback("openai".to_string());

        assert!(!config.explore_mode);
        assert!((config.decay_factor - 0.99).abs() < 1e-10);
        assert_eq!(config.fallback_provider.as_deref(), Some("openai"));
        assert!((config.weights.cost - 0.8).abs() < 1e-10);
    }

    #[test]
    fn get_posteriors_returns_all_providers() {
        let router = ThompsonRouter::new(RouterConfig::default());
        router.add_provider(ProviderProfile::new("openai", 0.03, 0.92, 800.0));
        router.add_provider(ProviderProfile::new("groq", 0.002, 0.85, 200.0));

        // Record some outcomes to shift posteriors
        router.record_outcome("openai", 1.0).unwrap();
        router.record_outcome("openai", 1.0).unwrap();
        router.record_outcome("groq", 0.0).unwrap();

        let posteriors = router.get_posteriors();
        assert_eq!(posteriors.len(), 2);

        let openai = posteriors.iter().find(|(id, _, _)| id == "openai").unwrap();
        // After 2 successes with decay: alpha > 1.0
        assert!(openai.1 > 1.0, "expected alpha > 1.0, got {}", openai.1);

        let groq = posteriors.iter().find(|(id, _, _)| id == "groq").unwrap();
        // After 1 failure with decay: beta > 1.0
        assert!(groq.2 > 1.0, "expected beta > 1.0, got {}", groq.2);
    }

    #[test]
    fn restore_posteriors_updates_matching_providers() {
        let router = ThompsonRouter::new(RouterConfig::default());
        router.add_provider(ProviderProfile::new("openai", 0.03, 0.92, 800.0));
        router.add_provider(ProviderProfile::new("groq", 0.002, 0.85, 200.0));

        router.restore_posteriors(&[
            ("openai".to_string(), 5.0, 3.0),
            ("groq".to_string(), 2.0, 8.0),
        ]);

        let posteriors = router.get_posteriors();
        let openai = posteriors.iter().find(|(id, _, _)| id == "openai").unwrap();
        assert!((openai.1 - 5.0).abs() < 1e-10);
        assert!((openai.2 - 3.0).abs() < 1e-10);

        let groq = posteriors.iter().find(|(id, _, _)| id == "groq").unwrap();
        assert!((groq.1 - 2.0).abs() < 1e-10);
        assert!((groq.2 - 8.0).abs() < 1e-10);
    }

    #[test]
    fn restore_posteriors_rejects_invalid_params() {
        let router = ThompsonRouter::new(RouterConfig::default());
        router.add_provider(ProviderProfile::new("openai", 0.03, 0.92, 800.0));

        // alpha < 1.0 — should be skipped
        router.restore_posteriors(&[("openai".to_string(), 0.5, 3.0)]);
        let posteriors = router.get_posteriors();
        let openai = posteriors.iter().find(|(id, _, _)| id == "openai").unwrap();
        assert!((openai.1 - 1.0).abs() < 1e-10, "alpha should remain 1.0");

        // beta < 1.0 — should be skipped
        router.restore_posteriors(&[("openai".to_string(), 3.0, 0.5)]);
        let posteriors = router.get_posteriors();
        let openai = posteriors.iter().find(|(id, _, _)| id == "openai").unwrap();
        assert!((openai.1 - 1.0).abs() < 1e-10, "alpha should remain 1.0");
    }

    #[test]
    fn restore_posteriors_ignores_unknown_ids() {
        let router = ThompsonRouter::new(RouterConfig::default());
        router.add_provider(ProviderProfile::new("openai", 0.03, 0.92, 800.0));

        // Unknown provider — should not panic or modify anything
        router.restore_posteriors(&[("nonexistent".to_string(), 5.0, 3.0)]);
        let posteriors = router.get_posteriors();
        assert_eq!(posteriors.len(), 1);
        let openai = &posteriors[0];
        assert!((openai.1 - 1.0).abs() < 1e-10, "should be unchanged");
    }

    #[test]
    fn remove_provider_by_id() {
        let router = ThompsonRouter::new(RouterConfig::default());
        router.add_provider(ProviderProfile::new("a", 0.01, 0.9, 500.0));
        router.add_provider(ProviderProfile::new("b", 0.02, 0.8, 600.0));
        router.add_provider(ProviderProfile::new("c", 0.03, 0.7, 700.0));
        assert_eq!(router.provider_count(), 3);

        // Remove existing
        assert!(router.remove_provider("b"));
        assert_eq!(router.provider_count(), 2);

        // Remove non-existent
        assert!(!router.remove_provider("nonexistent"));
        assert_eq!(router.provider_count(), 2);

        // Verify remaining providers
        let posteriors = router.get_posteriors();
        let ids: Vec<&str> = posteriors.iter().map(|(id, _, _)| id.as_str()).collect();
        assert!(ids.contains(&"a"));
        assert!(ids.contains(&"c"));
        assert!(!ids.contains(&"b"));
    }

    #[test]
    fn thompson_routing_strategy_select() {
        let config = RouterConfig::new().explore(false);
        let router = ThompsonRouter::new(config);
        router.add_provider(ProviderProfile::new("openai", 0.03, 0.92, 800.0));
        router.add_provider(ProviderProfile::new("groq", 0.002, 0.85, 200.0));

        let candidates = vec!["openai", "groq"];
        let selected = router.select(&candidates, None);
        assert!(selected.is_some());
        let id = selected.unwrap();
        assert!(id == "openai" || id == "groq");
    }

    #[test]
    fn thompson_routing_strategy_record_success() {
        let router = ThompsonRouter::new(RouterConfig::default());
        router.add_provider(ProviderProfile::new("test", 0.01, 0.9, 500.0));

        let before = router.get_posteriors();
        let alpha_before = before[0].1;

        router.record_success("test", Duration::from_millis(100));

        let after = router.get_posteriors();
        let alpha_after = after[0].1;
        assert!(
            alpha_after > alpha_before,
            "alpha should increase after success"
        );
    }

    #[test]
    fn thompson_routing_strategy_record_failure() {
        let router = ThompsonRouter::new(RouterConfig::default());
        router.add_provider(ProviderProfile::new("test", 0.01, 0.9, 500.0));

        let before = router.get_posteriors();
        let beta_before = before[0].2;

        router.record_failure("test");

        let after = router.get_posteriors();
        let beta_after = after[0].2;
        assert!(
            beta_after > beta_before,
            "beta should increase after failure"
        );
    }
}

#[cfg(test)]
mod proptests {
    use super::*;
    use proptest::prelude::*;

    proptest! {
        #[test]
        fn restore_then_get_roundtrips(
            alphas in prop::collection::vec(1.0f64..1000.0, 1..5),
            betas in prop::collection::vec(1.0f64..1000.0, 1..5),
        ) {
            let n = alphas.len().min(betas.len());
            let router = ThompsonRouter::new(RouterConfig::default());
            let mut input = Vec::new();
            for i in 0..n {
                let id = format!("provider-{i}");
                router.add_provider(ProviderProfile::new(&id, 0.01, 0.9, 500.0));
                input.push((id, alphas[i], betas[i]));
            }

            router.restore_posteriors(&input);
            let output = router.get_posteriors();

            for (id, alpha, beta) in &input {
                let found = output.iter().find(|(oid, _, _)| oid == id).unwrap();
                prop_assert!((found.1 - alpha).abs() < 1e-10);
                prop_assert!((found.2 - beta).abs() < 1e-10);
            }
        }
    }
}
