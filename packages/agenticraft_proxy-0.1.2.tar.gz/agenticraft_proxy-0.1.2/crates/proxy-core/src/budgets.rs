// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Hierarchical budget management (F5).
//!
//! Three-level budget hierarchy: Organization → Team → User.
//! Enforcement checks bottom-up: user → team → org, returning the most
//! restrictive limit. All counters are atomic for lock-free concurrent access.
//!
//! `try_record()` atomically checks AND records in a single operation using
//! `compare_exchange` loops, eliminating the TOCTOU race between `check()` + `record()`.

use std::sync::atomic::{AtomicU64, Ordering};

use dashmap::DashMap;

/// A single budget with token and cost limits.
#[derive(Debug)]
pub struct Budget {
    /// Maximum tokens allowed in the current period.
    pub token_limit: AtomicU64,
    /// Tokens consumed in the current period.
    pub tokens_used: AtomicU64,
    /// Maximum cost (in micro-USD, 1 USD = 1_000_000) in the current period.
    pub cost_limit_micro_usd: AtomicU64,
    /// Cost consumed (micro-USD) in the current period.
    pub cost_used_micro_usd: AtomicU64,
}

impl Budget {
    /// Create a new budget with specified limits.
    pub fn new(token_limit: u64, cost_limit_micro_usd: u64) -> Self {
        Self {
            token_limit: AtomicU64::new(token_limit),
            tokens_used: AtomicU64::new(0),
            cost_limit_micro_usd: AtomicU64::new(cost_limit_micro_usd),
            cost_used_micro_usd: AtomicU64::new(0),
        }
    }

    /// Check if this budget can afford `tokens` additional tokens (read-only).
    pub fn can_afford_tokens(&self, tokens: u64) -> bool {
        self.tokens_used
            .load(Ordering::Relaxed)
            .checked_add(tokens)
            .is_some_and(|sum| sum <= self.token_limit.load(Ordering::Relaxed))
    }

    /// Check if this budget can afford `cost_micro_usd` additional cost (read-only).
    pub fn can_afford_cost(&self, cost_micro_usd: u64) -> bool {
        self.cost_used_micro_usd
            .load(Ordering::Relaxed)
            .checked_add(cost_micro_usd)
            .is_some_and(|sum| sum <= self.cost_limit_micro_usd.load(Ordering::Relaxed))
    }

    /// Atomically try to consume `tokens` from this budget.
    ///
    /// Uses a `compare_exchange` loop to prevent TOCTOU races:
    /// checks the limit and records usage in a single atomic operation.
    /// Returns `true` if the tokens were consumed, `false` if it would exceed the limit.
    pub fn try_consume_tokens(&self, tokens: u64) -> bool {
        let limit = self.token_limit.load(Ordering::Relaxed);
        loop {
            let current = self.tokens_used.load(Ordering::Relaxed);
            let new_total = match current.checked_add(tokens) {
                Some(t) => t,
                None => return false, // overflow → reject
            };
            if new_total > limit {
                return false;
            }
            if self
                .tokens_used
                .compare_exchange_weak(current, new_total, Ordering::Relaxed, Ordering::Relaxed)
                .is_ok()
            {
                return true;
            }
            // CAS failed — another thread updated; retry
        }
    }

    /// Atomically try to consume `cost_micro_usd` from this budget.
    ///
    /// Uses a `compare_exchange` loop to prevent TOCTOU races.
    /// Returns `true` if the cost was consumed, `false` if it would exceed the limit.
    pub fn try_consume_cost(&self, cost_micro_usd: u64) -> bool {
        let limit = self.cost_limit_micro_usd.load(Ordering::Relaxed);
        loop {
            let current = self.cost_used_micro_usd.load(Ordering::Relaxed);
            let new_total = match current.checked_add(cost_micro_usd) {
                Some(t) => t,
                None => return false, // overflow → reject
            };
            if new_total > limit {
                return false;
            }
            if self
                .cost_used_micro_usd
                .compare_exchange_weak(current, new_total, Ordering::Relaxed, Ordering::Relaxed)
                .is_ok()
            {
                return true;
            }
        }
    }

    /// Roll back a token charge (e.g., after a failed request).
    pub fn refund_tokens(&self, tokens: u64) {
        // Saturating subtract via CAS loop
        loop {
            let current = self.tokens_used.load(Ordering::Relaxed);
            let new_val = current.saturating_sub(tokens);
            if self
                .tokens_used
                .compare_exchange_weak(current, new_val, Ordering::Relaxed, Ordering::Relaxed)
                .is_ok()
            {
                return;
            }
        }
    }

    /// Roll back a cost charge (e.g., after a failed request).
    pub fn refund_cost(&self, cost_micro_usd: u64) {
        loop {
            let current = self.cost_used_micro_usd.load(Ordering::Relaxed);
            let new_val = current.saturating_sub(cost_micro_usd);
            if self
                .cost_used_micro_usd
                .compare_exchange_weak(current, new_val, Ordering::Relaxed, Ordering::Relaxed)
                .is_ok()
            {
                return;
            }
        }
    }

    /// Reset counters for a new period.
    pub fn reset(&self) {
        self.tokens_used.store(0, Ordering::Relaxed);
        self.cost_used_micro_usd.store(0, Ordering::Relaxed);
    }

    /// Get remaining token budget.
    pub fn tokens_remaining(&self) -> u64 {
        let limit = self.token_limit.load(Ordering::Relaxed);
        let used = self.tokens_used.load(Ordering::Relaxed);
        limit.saturating_sub(used)
    }

    /// Get remaining cost budget (micro-USD).
    pub fn cost_remaining_micro_usd(&self) -> u64 {
        let limit = self.cost_limit_micro_usd.load(Ordering::Relaxed);
        let used = self.cost_used_micro_usd.load(Ordering::Relaxed);
        limit.saturating_sub(used)
    }
}

/// Reason a budget check failed.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum BudgetExceeded {
    /// User-level budget exceeded.
    User { user_id: String },
    /// Team-level budget exceeded.
    Team { team_id: String },
    /// Organization-level budget exceeded.
    Org { org_id: String },
}

impl std::fmt::Display for BudgetExceeded {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            BudgetExceeded::User { user_id } => write!(f, "user budget exceeded: {user_id}"),
            BudgetExceeded::Team { team_id } => write!(f, "team budget exceeded: {team_id}"),
            BudgetExceeded::Org { org_id } => write!(f, "org budget exceeded: {org_id}"),
        }
    }
}

/// Hierarchical budget manager: org → team → user.
pub struct BudgetHierarchy {
    /// Organization budgets. Key: org_id.
    orgs: DashMap<String, Budget>,
    /// Team budgets. Key: (org_id, team_id).
    teams: DashMap<(String, String), Budget>,
    /// User budgets. Key: (org_id, team_id, user_id).
    users: DashMap<(String, String, String), Budget>,
}

impl BudgetHierarchy {
    /// Create a new empty budget hierarchy.
    pub fn new() -> Self {
        Self {
            orgs: DashMap::new(),
            teams: DashMap::new(),
            users: DashMap::new(),
        }
    }

    /// Set an organization-level budget.
    pub fn set_org_budget(&self, org_id: &str, token_limit: u64, cost_limit_micro_usd: u64) {
        self.orgs.insert(
            org_id.to_string(),
            Budget::new(token_limit, cost_limit_micro_usd),
        );
    }

    /// Set a team-level budget.
    pub fn set_team_budget(
        &self,
        org_id: &str,
        team_id: &str,
        token_limit: u64,
        cost_limit_micro_usd: u64,
    ) {
        self.teams.insert(
            (org_id.to_string(), team_id.to_string()),
            Budget::new(token_limit, cost_limit_micro_usd),
        );
    }

    /// Set a user-level budget.
    pub fn set_user_budget(
        &self,
        org_id: &str,
        team_id: &str,
        user_id: &str,
        token_limit: u64,
        cost_limit_micro_usd: u64,
    ) {
        self.users.insert(
            (org_id.to_string(), team_id.to_string(), user_id.to_string()),
            Budget::new(token_limit, cost_limit_micro_usd),
        );
    }

    /// Atomically try to consume `tokens` and `cost_micro_usd` at all levels.
    ///
    /// Checks and records bottom-up (user → team → org) in a single operation.
    /// If any level fails, previously consumed amounts are rolled back.
    /// Returns `Ok(())` on success, or `Err(BudgetExceeded)` with the failing level.
    pub fn try_record(
        &self,
        org_id: &str,
        team_id: &str,
        user_id: &str,
        tokens: u64,
        cost_micro_usd: u64,
    ) -> Result<(), BudgetExceeded> {
        let user_key = (org_id.to_string(), team_id.to_string(), user_id.to_string());
        let team_key = (org_id.to_string(), team_id.to_string());

        // Phase 1: User level
        if let Some(budget) = self.users.get(&user_key) {
            let tok_ok = budget.try_consume_tokens(tokens);
            if !tok_ok {
                return Err(BudgetExceeded::User {
                    user_id: user_id.to_string(),
                });
            }
            let cost_ok = budget.try_consume_cost(cost_micro_usd);
            if !cost_ok {
                // Tokens succeeded but cost failed — roll back tokens only
                budget.refund_tokens(tokens);
                return Err(BudgetExceeded::User {
                    user_id: user_id.to_string(),
                });
            }
        }

        // Phase 2: Team level
        if let Some(budget) = self.teams.get(&team_key) {
            let tok_ok = budget.try_consume_tokens(tokens);
            if !tok_ok {
                // Roll back user level
                if let Some(ub) = self.users.get(&user_key) {
                    ub.refund_tokens(tokens);
                    ub.refund_cost(cost_micro_usd);
                }
                return Err(BudgetExceeded::Team {
                    team_id: team_id.to_string(),
                });
            }
            let cost_ok = budget.try_consume_cost(cost_micro_usd);
            if !cost_ok {
                budget.refund_tokens(tokens);
                if let Some(ub) = self.users.get(&user_key) {
                    ub.refund_tokens(tokens);
                    ub.refund_cost(cost_micro_usd);
                }
                return Err(BudgetExceeded::Team {
                    team_id: team_id.to_string(),
                });
            }
        }

        // Phase 3: Org level
        if let Some(budget) = self.orgs.get(org_id) {
            let tok_ok = budget.try_consume_tokens(tokens);
            if !tok_ok {
                // Roll back team and user levels
                if let Some(tb) = self.teams.get(&team_key) {
                    tb.refund_tokens(tokens);
                    tb.refund_cost(cost_micro_usd);
                }
                if let Some(ub) = self.users.get(&user_key) {
                    ub.refund_tokens(tokens);
                    ub.refund_cost(cost_micro_usd);
                }
                return Err(BudgetExceeded::Org {
                    org_id: org_id.to_string(),
                });
            }
            let cost_ok = budget.try_consume_cost(cost_micro_usd);
            if !cost_ok {
                budget.refund_tokens(tokens);
                if let Some(tb) = self.teams.get(&team_key) {
                    tb.refund_tokens(tokens);
                    tb.refund_cost(cost_micro_usd);
                }
                if let Some(ub) = self.users.get(&user_key) {
                    ub.refund_tokens(tokens);
                    ub.refund_cost(cost_micro_usd);
                }
                return Err(BudgetExceeded::Org {
                    org_id: org_id.to_string(),
                });
            }
        }

        Ok(())
    }

    /// Read-only budget check (no side effects). Use `try_record` for enforcement.
    pub fn check(
        &self,
        org_id: &str,
        team_id: &str,
        user_id: &str,
        tokens: u64,
        cost_micro_usd: u64,
    ) -> Result<(), BudgetExceeded> {
        // User check
        let user_key = (org_id.to_string(), team_id.to_string(), user_id.to_string());
        if let Some(budget) = self.users.get(&user_key) {
            if !budget.can_afford_tokens(tokens) || !budget.can_afford_cost(cost_micro_usd) {
                return Err(BudgetExceeded::User {
                    user_id: user_id.to_string(),
                });
            }
        }

        // Team check
        let team_key = (org_id.to_string(), team_id.to_string());
        if let Some(budget) = self.teams.get(&team_key) {
            if !budget.can_afford_tokens(tokens) || !budget.can_afford_cost(cost_micro_usd) {
                return Err(BudgetExceeded::Team {
                    team_id: team_id.to_string(),
                });
            }
        }

        // Org check
        if let Some(budget) = self.orgs.get(org_id) {
            if !budget.can_afford_tokens(tokens) || !budget.can_afford_cost(cost_micro_usd) {
                return Err(BudgetExceeded::Org {
                    org_id: org_id.to_string(),
                });
            }
        }

        Ok(())
    }

    /// Reset all budgets at all levels (for period rollover).
    pub fn reset_all(&self) {
        for entry in self.orgs.iter() {
            entry.value().reset();
        }
        for entry in self.teams.iter() {
            entry.value().reset();
        }
        for entry in self.users.iter() {
            entry.value().reset();
        }
    }
}

impl Default for BudgetHierarchy {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn budget_within_limits() {
        let budget = Budget::new(1000, 5_000_000);
        assert!(budget.can_afford_tokens(500));
        assert!(budget.can_afford_cost(2_000_000));
        assert!(budget.try_consume_tokens(500));
        assert!(budget.try_consume_cost(2_000_000));
    }

    #[test]
    fn budget_exceeds_token_limit() {
        let budget = Budget::new(100, 5_000_000);
        assert!(budget.try_consume_tokens(80));
        assert!(!budget.can_afford_tokens(30));
        assert!(!budget.try_consume_tokens(30));
        // Should not have changed
        assert_eq!(budget.tokens_remaining(), 20);
    }

    #[test]
    fn budget_exceeds_cost_limit() {
        let budget = Budget::new(1000, 100);
        assert!(budget.try_consume_cost(90));
        assert!(!budget.can_afford_cost(20));
        assert!(!budget.try_consume_cost(20));
        assert_eq!(budget.cost_remaining_micro_usd(), 10);
    }

    #[test]
    fn budget_reset() {
        let budget = Budget::new(100, 100);
        budget.try_consume_tokens(100);
        budget.try_consume_cost(100);
        assert!(!budget.can_afford_tokens(1));
        budget.reset();
        assert!(budget.can_afford_tokens(100));
        assert!(budget.can_afford_cost(100));
    }

    #[test]
    fn budget_remaining() {
        let budget = Budget::new(1000, 5_000_000);
        budget.try_consume_tokens(300);
        budget.try_consume_cost(1_000_000);
        assert_eq!(budget.tokens_remaining(), 700);
        assert_eq!(budget.cost_remaining_micro_usd(), 4_000_000);
    }

    #[test]
    fn budget_refund() {
        let budget = Budget::new(100, 100);
        assert!(budget.try_consume_tokens(80));
        assert!(budget.try_consume_cost(80));
        budget.refund_tokens(30);
        budget.refund_cost(30);
        assert_eq!(budget.tokens_remaining(), 50);
        assert_eq!(budget.cost_remaining_micro_usd(), 50);
    }

    #[test]
    fn try_consume_rejects_and_doesnt_mutate() {
        let budget = Budget::new(100, 100);
        assert!(budget.try_consume_tokens(60));
        // Should reject — would exceed limit
        assert!(!budget.try_consume_tokens(50));
        // Should still have 40 remaining, not 40-50
        assert_eq!(budget.tokens_remaining(), 40);
    }

    #[test]
    fn hierarchy_try_record_user_exceeds() {
        let h = BudgetHierarchy::new();
        h.set_org_budget("acme", 10000, 50_000_000);
        h.set_team_budget("acme", "eng", 5000, 25_000_000);
        h.set_user_budget("acme", "eng", "alice", 100, 500_000);

        assert!(h.try_record("acme", "eng", "alice", 50, 200_000).is_ok());
        assert_eq!(
            h.try_record("acme", "eng", "alice", 200, 100_000),
            Err(BudgetExceeded::User {
                user_id: "alice".into()
            })
        );
        // User budget should show the first 50 tokens consumed, not 50+200
        let user = h
            .users
            .get(&("acme".into(), "eng".into(), "alice".into()))
            .unwrap();
        assert_eq!(user.tokens_remaining(), 50);
    }

    #[test]
    fn hierarchy_try_record_team_exceeds_rolls_back_user() {
        let h = BudgetHierarchy::new();
        h.set_org_budget("acme", 10000, 50_000_000);
        h.set_team_budget("acme", "eng", 100, 500_000);
        h.set_user_budget("acme", "eng", "alice", 1000, 5_000_000);

        assert_eq!(
            h.try_record("acme", "eng", "alice", 200, 100_000),
            Err(BudgetExceeded::Team {
                team_id: "eng".into()
            })
        );
        // User budget should NOT have been consumed (rolled back)
        let user = h
            .users
            .get(&("acme".into(), "eng".into(), "alice".into()))
            .unwrap();
        assert_eq!(user.tokens_remaining(), 1000);
    }

    #[test]
    fn hierarchy_try_record_org_exceeds_rolls_back_all() {
        let h = BudgetHierarchy::new();
        h.set_org_budget("acme", 50, 100_000);
        h.set_team_budget("acme", "eng", 5000, 25_000_000);
        h.set_user_budget("acme", "eng", "alice", 1000, 5_000_000);

        assert_eq!(
            h.try_record("acme", "eng", "alice", 100, 50_000),
            Err(BudgetExceeded::Org {
                org_id: "acme".into()
            })
        );
        // Both user and team should be rolled back
        let user = h
            .users
            .get(&("acme".into(), "eng".into(), "alice".into()))
            .unwrap();
        assert_eq!(user.tokens_remaining(), 1000);
        let team = h.teams.get(&("acme".into(), "eng".into())).unwrap();
        assert_eq!(team.tokens_remaining(), 5000);
    }

    #[test]
    fn hierarchy_no_budgets_allows() {
        let h = BudgetHierarchy::new();
        // No budgets configured — everything passes
        assert!(h.try_record("acme", "eng", "alice", 9999, 9999).is_ok());
    }

    #[test]
    fn hierarchy_try_record_updates_all_levels() {
        let h = BudgetHierarchy::new();
        h.set_org_budget("acme", 1000, 5_000_000);
        h.set_team_budget("acme", "eng", 500, 2_500_000);
        h.set_user_budget("acme", "eng", "alice", 200, 1_000_000);

        h.try_record("acme", "eng", "alice", 100, 400_000).unwrap();

        // All levels should show usage
        let user = h
            .users
            .get(&("acme".into(), "eng".into(), "alice".into()))
            .unwrap();
        assert_eq!(user.tokens_remaining(), 100);

        let team = h.teams.get(&("acme".into(), "eng".into())).unwrap();
        assert_eq!(team.tokens_remaining(), 400);

        let org = h.orgs.get("acme").unwrap();
        assert_eq!(org.tokens_remaining(), 900);
    }

    #[test]
    fn hierarchy_reset_all() {
        let h = BudgetHierarchy::new();
        h.set_org_budget("acme", 1000, 5_000_000);
        h.set_user_budget("acme", "eng", "alice", 100, 500_000);

        h.try_record("acme", "eng", "alice", 100, 500_000).unwrap();
        h.reset_all();

        assert!(h.try_record("acme", "eng", "alice", 100, 500_000).is_ok());
    }

    #[test]
    fn budget_exceeded_display() {
        let e = BudgetExceeded::User {
            user_id: "alice".into(),
        };
        assert!(e.to_string().contains("alice"));
    }

    #[test]
    fn concurrent_try_record_no_overcommit() {
        use std::sync::Arc;
        use std::thread;

        let h = Arc::new(BudgetHierarchy::new());
        h.set_user_budget("acme", "eng", "alice", 100, 100_000_000);

        let mut handles = vec![];
        let success_count = Arc::new(AtomicU64::new(0));

        // 20 threads each trying to consume 10 tokens
        // Budget is 100 tokens, so exactly 10 should succeed
        for _ in 0..20 {
            let h = h.clone();
            let sc = success_count.clone();
            handles.push(thread::spawn(move || {
                if h.try_record("acme", "eng", "alice", 10, 0).is_ok() {
                    sc.fetch_add(1, Ordering::Relaxed);
                }
            }));
        }

        for handle in handles {
            handle.join().unwrap();
        }

        assert_eq!(success_count.load(Ordering::Relaxed), 10);
        let user = h
            .users
            .get(&("acme".into(), "eng".into(), "alice".into()))
            .unwrap();
        assert_eq!(user.tokens_remaining(), 0);
    }
}
