// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Unified error type for proxy-core.

use thiserror::Error;

/// All errors that proxy-core algorithms can produce.
#[derive(Debug, Error)]
pub enum ProxyError {
    #[error("no providers registered")]
    NoProviders,

    #[error("circuit open for provider `{provider}`: tripped at {failures} failures")]
    CircuitOpen { provider: String, failures: u32 },

    #[error("rate limited: {available} tokens available, {requested} requested")]
    RateLimited {
        available: f64,
        requested: u64,
        /// Advisory seconds until `requested` tokens are available (RFC 6585).
        retry_after_secs: f64,
    },

    #[error("no available keys in pool (total: {total}, active: {active})")]
    NoAvailableKeys { total: usize, active: usize },

    #[error("provider `{0}` not found")]
    ProviderNotFound(String),

    #[error("invalid parameter: {0}")]
    InvalidParameter(String),

    #[error("sampling error: {0}")]
    SamplingError(String),
}

impl ProxyError {
    /// Extract the advisory Retry-After seconds. Returns `0.0` for non-rate-limit errors.
    pub fn retry_after_secs(&self) -> f64 {
        match self {
            ProxyError::RateLimited {
                retry_after_secs, ..
            } => *retry_after_secs,
            _ => 0.0,
        }
    }
}

/// Convenience alias.
pub type Result<T> = std::result::Result<T, ProxyError>;
