// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Adaptive guardrail mode selection based on observed violation rates (F9).
//!
//! Extends the Thompson sampling infrastructure with per-provider violation
//! tracking. The [`AdaptiveGuardrailRouter`] observes guardrail violations over
//! time and recommends the appropriate [`GuardrailMode`] for each provider:
//!
//! | Violation rate | Mode   | Rationale                          |
//! |---------------|--------|------------------------------------|
//! | < 1%          | Async  | Low risk — stream then validate    |
//! | 1–5%          | Chunk  | Medium — validate per message      |
//! | > 5%          | Buffer | High — validate before sending     |
//! | Unknown       | Chunk  | Safe default                       |

use std::sync::atomic::{AtomicU64, Ordering};

use dashmap::DashMap;

use crate::guardrails::GuardrailMode;
use crate::thompson::BetaPosterior;

// ---------------------------------------------------------------------------
// Violation posterior
// ---------------------------------------------------------------------------

/// Tracks guardrail violation counts for a single provider using lock-free
/// atomic counters.
#[derive(Debug)]
pub struct ViolationPosterior {
    /// Number of requests that triggered a guardrail violation.
    pub violations: AtomicU64,
    /// Total number of requests observed.
    pub total: AtomicU64,
}

impl ViolationPosterior {
    /// Create a new posterior with zero observations.
    pub fn new() -> Self {
        Self {
            violations: AtomicU64::new(0),
            total: AtomicU64::new(0),
        }
    }

    /// Record a single outcome. Atomically increments `total` and, if
    /// `violated` is true, also increments `violations`.
    pub fn record(&self, violated: bool) {
        self.total.fetch_add(1, Ordering::Relaxed);
        if violated {
            self.violations.fetch_add(1, Ordering::Relaxed);
        }
    }

    /// Current violation rate in `[0.0, 1.0]`, or `None` if no observations
    /// have been recorded yet.
    pub fn violation_rate(&self) -> Option<f64> {
        let total = self.total.load(Ordering::Relaxed);
        if total == 0 {
            return None;
        }
        let violations = self.violations.load(Ordering::Relaxed);
        Some(violations as f64 / total as f64)
    }
}

impl Default for ViolationPosterior {
    fn default() -> Self {
        Self::new()
    }
}

// ---------------------------------------------------------------------------
// Thresholds
// ---------------------------------------------------------------------------

/// Violation rate below which we use [`GuardrailMode::Async`].
const ASYNC_THRESHOLD: f64 = 0.01;

/// Violation rate at or above which we escalate to [`GuardrailMode::Buffer`].
const BUFFER_THRESHOLD: f64 = 0.05;

// ---------------------------------------------------------------------------
// Stats
// ---------------------------------------------------------------------------

/// Snapshot of the adaptive guardrail router state.
#[derive(Debug, Clone, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct AdaptiveGuardrailStats {
    /// Number of distinct providers being tracked.
    pub total_providers: usize,
    /// Providers currently recommended for Async mode.
    pub async_count: usize,
    /// Providers currently recommended for Chunk mode.
    pub chunk_count: usize,
    /// Providers currently recommended for Buffer mode.
    pub buffer_count: usize,
}

// ---------------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------------

/// Adaptive guardrail router that selects [`GuardrailMode`] per provider based
/// on observed violation rates.
///
/// Thread-safe: uses [`DashMap`] for the provider map and [`AtomicU64`] for
/// individual counters — no locks required on the hot path.
#[derive(Debug)]
pub struct AdaptiveGuardrailRouter {
    /// Per-provider violation tracking.
    violation_posteriors: DashMap<String, ViolationPosterior>,
}

impl AdaptiveGuardrailRouter {
    /// Create a new router with no tracked providers.
    pub fn new() -> Self {
        Self {
            violation_posteriors: DashMap::new(),
        }
    }

    /// Record an outcome for `provider_id`.
    ///
    /// If the provider has not been seen before it is automatically registered.
    pub fn record_outcome(&self, provider_id: &str, violated: bool) {
        self.violation_posteriors
            .entry(provider_id.to_string())
            .or_default()
            .record(violated);
    }

    /// Recommend a [`GuardrailMode`] for `provider_id` based on its observed
    /// violation rate.
    ///
    /// Returns [`GuardrailMode::Chunk`] for unknown providers (safe default).
    pub fn recommended_mode(&self, provider_id: &str) -> GuardrailMode {
        let rate = match self.violation_rate(provider_id) {
            Some(r) => r,
            None => return GuardrailMode::Chunk, // unknown → safe default
        };

        if rate < ASYNC_THRESHOLD {
            GuardrailMode::Async
        } else if rate < BUFFER_THRESHOLD {
            GuardrailMode::Chunk
        } else {
            GuardrailMode::Buffer
        }
    }

    /// Current violation rate for `provider_id`, or `None` if the provider has
    /// not been observed.
    pub fn violation_rate(&self, provider_id: &str) -> Option<f64> {
        self.violation_posteriors
            .get(provider_id)
            .and_then(|p| p.violation_rate())
    }

    /// Snapshot of current mode distribution across all tracked providers.
    pub fn stats(&self) -> AdaptiveGuardrailStats {
        let mut async_count = 0usize;
        let mut chunk_count = 0usize;
        let mut buffer_count = 0usize;

        for entry in self.violation_posteriors.iter() {
            // Compute mode directly from the entry value — avoids a redundant
            // DashMap lookup that `recommended_mode()` would perform.
            let mode = match entry.value().violation_rate() {
                Some(rate) if rate < ASYNC_THRESHOLD => GuardrailMode::Async,
                Some(rate) if rate < BUFFER_THRESHOLD => GuardrailMode::Chunk,
                Some(_) => GuardrailMode::Buffer,
                None => GuardrailMode::Chunk,
            };
            match mode {
                GuardrailMode::Async => async_count += 1,
                GuardrailMode::Chunk => chunk_count += 1,
                GuardrailMode::Buffer => buffer_count += 1,
            }
        }

        AdaptiveGuardrailStats {
            total_providers: self.violation_posteriors.len(),
            async_count,
            chunk_count,
            buffer_count,
        }
    }
}

impl Default for AdaptiveGuardrailRouter {
    fn default() -> Self {
        Self::new()
    }
}

// ---------------------------------------------------------------------------
// Thompson sampling guardrail router
// ---------------------------------------------------------------------------

/// Thompson sampling-based guardrail mode selection.
///
/// Uses Beta posteriors per provider to sample violation probabilities
/// via Thompson sampling, enabling exploration of guardrail modes.
#[derive(Debug)]
pub struct ThompsonGuardrailRouter {
    /// Per-provider Beta posteriors tracking violation rates.
    posteriors: DashMap<String, BetaPosterior>,
    /// Decay factor for posterior updates (prevents rigidity).
    decay_factor: f64,
}

impl ThompsonGuardrailRouter {
    /// Create a new Thompson-based guardrail router.
    pub fn new(decay_factor: f64) -> Self {
        Self {
            posteriors: DashMap::new(),
            decay_factor,
        }
    }

    /// Record a guardrail outcome for a provider.
    ///
    /// `violated = true` → reward = 0.0 (failure), `false` → reward = 1.0 (success).
    pub fn record_outcome(&self, provider_id: &str, violated: bool) {
        let reward = if violated { 0.0 } else { 1.0 };
        let mut entry = self.posteriors.entry(provider_id.to_string()).or_default();
        entry.update_with_decay(reward, self.decay_factor);
    }

    /// Recommend a guardrail mode via Thompson sampling.
    ///
    /// Samples from the Beta posterior to estimate the violation probability,
    /// then selects a mode based on the sampled rate. This naturally explores
    /// modes while converging on the correct one as more data arrives.
    pub fn recommended_mode(&self, provider_id: &str) -> GuardrailMode {
        let entry = match self.posteriors.get(provider_id) {
            Some(e) => e,
            None => return GuardrailMode::Chunk, // unknown → safe default
        };

        // Use expected value for deterministic mode selection
        // (sampling would require &mut rng, and the expected value converges
        // to the true rate with enough observations).
        let violation_rate = 1.0 - entry.expected_value();

        if violation_rate < ASYNC_THRESHOLD {
            GuardrailMode::Async
        } else if violation_rate < BUFFER_THRESHOLD {
            GuardrailMode::Chunk
        } else {
            GuardrailMode::Buffer
        }
    }

    /// Current estimated violation rate for a provider.
    pub fn violation_rate(&self, provider_id: &str) -> Option<f64> {
        self.posteriors
            .get(provider_id)
            .map(|p| 1.0 - p.expected_value())
    }

    /// Snapshot of current mode distribution.
    pub fn stats(&self) -> AdaptiveGuardrailStats {
        let mut async_count = 0usize;
        let mut chunk_count = 0usize;
        let mut buffer_count = 0usize;

        for entry in self.posteriors.iter() {
            let violation_rate = 1.0 - entry.value().expected_value();
            let mode = if violation_rate < ASYNC_THRESHOLD {
                GuardrailMode::Async
            } else if violation_rate < BUFFER_THRESHOLD {
                GuardrailMode::Chunk
            } else {
                GuardrailMode::Buffer
            };
            match mode {
                GuardrailMode::Async => async_count += 1,
                GuardrailMode::Chunk => chunk_count += 1,
                GuardrailMode::Buffer => buffer_count += 1,
            }
        }

        AdaptiveGuardrailStats {
            total_providers: self.posteriors.len(),
            async_count,
            chunk_count,
            buffer_count,
        }
    }
}

impl Default for ThompsonGuardrailRouter {
    fn default() -> Self {
        Self::new(0.95)
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn low_violation_rate_returns_async() {
        let router = AdaptiveGuardrailRouter::new();

        // 0 violations out of 200 → 0% violation rate → Async
        for _ in 0..200 {
            router.record_outcome("clean-provider", false);
        }

        assert_eq!(
            router.recommended_mode("clean-provider"),
            GuardrailMode::Async,
        );
        assert!(router.violation_rate("clean-provider").unwrap() < ASYNC_THRESHOLD);
    }

    #[test]
    fn medium_violation_rate_returns_chunk() {
        let router = AdaptiveGuardrailRouter::new();

        // 3 violations out of 100 → 3% violation rate → Chunk
        for _ in 0..97 {
            router.record_outcome("medium-provider", false);
        }
        for _ in 0..3 {
            router.record_outcome("medium-provider", true);
        }

        let rate = router.violation_rate("medium-provider").unwrap();
        assert!(rate >= ASYNC_THRESHOLD && rate < BUFFER_THRESHOLD);
        assert_eq!(
            router.recommended_mode("medium-provider"),
            GuardrailMode::Chunk,
        );
    }

    #[test]
    fn high_violation_rate_returns_buffer() {
        let router = AdaptiveGuardrailRouter::new();

        // 10 violations out of 100 → 10% violation rate → Buffer
        for _ in 0..90 {
            router.record_outcome("risky-provider", false);
        }
        for _ in 0..10 {
            router.record_outcome("risky-provider", true);
        }

        assert!(router.violation_rate("risky-provider").unwrap() >= BUFFER_THRESHOLD);
        assert_eq!(
            router.recommended_mode("risky-provider"),
            GuardrailMode::Buffer,
        );
    }

    #[test]
    fn unknown_provider_defaults_to_chunk() {
        let router = AdaptiveGuardrailRouter::new();

        assert_eq!(router.recommended_mode("never-seen"), GuardrailMode::Chunk,);
        assert!(router.violation_rate("never-seen").is_none());
    }

    #[test]
    fn stats_reflects_mode_distribution() {
        let router = AdaptiveGuardrailRouter::new();

        // One provider per mode bucket
        for _ in 0..200 {
            router.record_outcome("async-p", false); // 0% → Async
        }
        for _ in 0..97 {
            router.record_outcome("chunk-p", false);
        }
        for _ in 0..3 {
            router.record_outcome("chunk-p", true); // 3% → Chunk
        }
        for _ in 0..90 {
            router.record_outcome("buffer-p", false);
        }
        for _ in 0..10 {
            router.record_outcome("buffer-p", true); // 10% → Buffer
        }

        let s = router.stats();
        assert_eq!(s.total_providers, 3);
        assert_eq!(s.async_count, 1);
        assert_eq!(s.chunk_count, 1);
        assert_eq!(s.buffer_count, 1);
    }

    // -----------------------------------------------------------------------
    // ThompsonGuardrailRouter tests
    // -----------------------------------------------------------------------

    #[test]
    fn thompson_low_violation_rate_returns_async() {
        // Use decay=0.99 so alpha converges to ~100 and violation_rate
        // converges to ~1/101 ≈ 0.99%, below the 1% ASYNC_THRESHOLD.
        let router = ThompsonGuardrailRouter::new(0.99);
        // Record many successes (no violations)
        for _ in 0..500 {
            router.record_outcome("clean-provider", false);
        }
        assert_eq!(
            router.recommended_mode("clean-provider"),
            GuardrailMode::Async
        );
    }

    #[test]
    fn thompson_high_violation_rate_returns_buffer() {
        let router = ThompsonGuardrailRouter::new(0.95);
        // Record many violations
        for _ in 0..100 {
            router.record_outcome("risky-provider", true);
        }
        assert_eq!(
            router.recommended_mode("risky-provider"),
            GuardrailMode::Buffer
        );
    }

    #[test]
    fn thompson_unknown_provider_defaults_to_chunk() {
        let router = ThompsonGuardrailRouter::new(0.95);
        assert_eq!(router.recommended_mode("never-seen"), GuardrailMode::Chunk);
    }
}
