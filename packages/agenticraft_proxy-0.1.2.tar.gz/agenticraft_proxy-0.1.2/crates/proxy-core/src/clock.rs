// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Injectable clock for deterministic testing.

use std::time::Instant;

/// Abstraction over time sources.
///
/// Production code uses [`MonotonicClock`]; tests use [`ManualClock`]
/// for fully deterministic time control.
pub trait Clock: Send + Sync {
    /// Returns the current time as fractional seconds.
    fn now_secs(&self) -> f64;
}

/// Real monotonic clock backed by [`std::time::Instant`].
#[derive(Debug)]
pub struct MonotonicClock {
    epoch: Instant,
}

impl MonotonicClock {
    pub fn new() -> Self {
        Self {
            epoch: Instant::now(),
        }
    }
}

impl Default for MonotonicClock {
    fn default() -> Self {
        Self::new()
    }
}

impl Clock for MonotonicClock {
    fn now_secs(&self) -> f64 {
        self.epoch.elapsed().as_secs_f64()
    }
}

/// Manual clock for deterministic tests.
///
/// Time only advances when explicitly set or advanced.
#[derive(Debug)]
pub struct ManualClock {
    now: parking_lot::Mutex<f64>,
}

impl ManualClock {
    pub fn new(initial_secs: f64) -> Self {
        Self {
            now: parking_lot::Mutex::new(initial_secs),
        }
    }

    /// Set the clock to an absolute time.
    pub fn set(&self, secs: f64) {
        *self.now.lock() = secs;
    }

    /// Advance the clock by `delta` seconds.
    pub fn advance(&self, delta: f64) {
        *self.now.lock() += delta;
    }
}

impl Default for ManualClock {
    fn default() -> Self {
        Self::new(0.0)
    }
}

impl Clock for ManualClock {
    fn now_secs(&self) -> f64 {
        *self.now.lock()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn manual_clock_set_and_advance() {
        let clock = ManualClock::new(10.0);
        assert_eq!(clock.now_secs(), 10.0);

        clock.advance(5.0);
        assert_eq!(clock.now_secs(), 15.0);

        clock.set(100.0);
        assert_eq!(clock.now_secs(), 100.0);
    }

    #[test]
    fn monotonic_clock_advances() {
        let clock = MonotonicClock::new();
        let t1 = clock.now_secs();
        // Spin briefly
        for _ in 0..10_000 {}
        let t2 = clock.now_secs();
        assert!(t2 >= t1);
    }
}
