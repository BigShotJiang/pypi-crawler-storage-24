// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Output guardrails and reversible PII masking (F2).
//!
//! Three operating modes based on risk level:
//! - **Async**: Low risk — stream then validate (non-blocking)
//! - **Chunk**: Medium risk — validate per chunk
//! - **Buffer**: High risk — validate before sending
//!
//! PII actions: Pass, Redact (irreversible), Mask (reversible), Block, Flag.
//!
//! Detects 6 PII types: Email, Phone, SSN, CreditCard, IpAddress, ApiKey.

use std::collections::HashMap;
use std::sync::atomic::{AtomicU64, Ordering};

use parking_lot::Mutex;

/// PII entity type.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum PiiType {
    Email,
    Phone,
    Ssn,
    CreditCard,
    IpAddress,
    ApiKey,
}

impl PiiType {
    /// Tag prefix for masked placeholders.
    fn tag(&self) -> &'static str {
        match self {
            PiiType::Email => "EMAIL",
            PiiType::Phone => "PHONE",
            PiiType::Ssn => "SSN",
            PiiType::CreditCard => "CC",
            PiiType::IpAddress => "IP",
            PiiType::ApiKey => "APIKEY",
        }
    }
}

/// A detected PII entity with its position.
#[derive(Debug, Clone)]
pub struct PiiDetection {
    pub pii_type: PiiType,
    pub start: usize,
    pub end: usize,
    pub matched: String,
}

/// Action to take when PII is detected.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PiiAction {
    /// Allow through unchanged.
    Pass,
    /// Replace with `[REDACTED]` (irreversible).
    Redact,
    /// Replace with `<TYPE_NNNN>` placeholder (reversible).
    Mask,
    /// Block the entire request/response.
    Block,
    /// Allow through but flag for review.
    Flag,
}

/// Guardrail operating mode.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum GuardrailMode {
    /// Low risk: stream then validate.
    Async,
    /// Medium risk: validate per chunk.
    Chunk,
    /// High risk: validate before sending.
    Buffer,
}

/// Reversible PII masking map.
///
/// Maps placeholder strings to original values. Carried through the pipeline
/// in request extensions. Used to unmask responses before delivery.
#[derive(Debug, Clone, Default)]
pub struct PiiMaskingMap {
    /// Placeholder → original value.
    mappings: HashMap<String, String>,
    /// Counter for unique placeholder generation.
    counter: u32,
}

impl PiiMaskingMap {
    /// Create a new empty masking map.
    pub fn new() -> Self {
        Self::default()
    }

    /// Mask a PII detection, returning the placeholder string.
    pub fn mask(&mut self, detection: &PiiDetection) -> String {
        self.counter += 1;
        let placeholder = format!("<{}_{:04}>", detection.pii_type.tag(), self.counter);
        self.mappings
            .insert(placeholder.clone(), detection.matched.clone());
        placeholder
    }

    /// Unmask all placeholders in a text, restoring original values.
    pub fn unmask(&self, text: &str) -> String {
        let mut result = text.to_string();
        for (placeholder, original) in &self.mappings {
            result = result.replace(placeholder, original);
        }
        result
    }

    /// Number of masked entities.
    pub fn len(&self) -> usize {
        self.mappings.len()
    }

    /// Whether any entities have been masked.
    pub fn is_empty(&self) -> bool {
        self.mappings.is_empty()
    }
}

/// Detect PII entities in text using pattern matching.
///
/// Detects 6 PII types:
/// - **Email**: standard email patterns
/// - **Phone**: US phone numbers (10-11 digits with separators)
/// - **SSN**: XXX-XX-XXXX pattern
/// - **Credit Card**: 13-19 digit card numbers (with optional separators)
/// - **IP Address**: IPv4 dotted decimal (excluding private ranges common in configs)
/// - **API Key**: long hex/base64 strings prefixed with common key markers
pub fn detect_pii(text: &str) -> Vec<PiiDetection> {
    let mut results = Vec::new();

    // Email: walk backwards from @ to find start, forward to find end
    for (at_pos, _) in text.match_indices('@') {
        let email_start = text[..at_pos]
            .rfind(|c: char| !c.is_alphanumeric() && c != '.' && c != '_' && c != '-' && c != '+')
            .map(|p| p + 1)
            .unwrap_or(0);
        let after_at = &text[at_pos + 1..];
        let email_end = after_at
            .find(|c: char| !c.is_alphanumeric() && c != '.' && c != '-')
            .map(|p| at_pos + 1 + p)
            .unwrap_or(text.len());

        let candidate = &text[email_start..email_end];
        if candidate.contains('.') && candidate.len() > 5 {
            results.push(PiiDetection {
                pii_type: PiiType::Email,
                start: email_start,
                end: email_end,
                matched: candidate.to_string(),
            });
        }
    }

    // SSN: XXX-XX-XXXX (exactly 11 chars: 3-2-4 digits with dashes)
    let bytes = text.as_bytes();
    let mut i = 0;
    while i + 11 <= bytes.len() {
        if bytes[i].is_ascii_digit()
            && bytes[i + 1].is_ascii_digit()
            && bytes[i + 2].is_ascii_digit()
            && bytes[i + 3] == b'-'
            && bytes[i + 4].is_ascii_digit()
            && bytes[i + 5].is_ascii_digit()
            && bytes[i + 6] == b'-'
            && bytes[i + 7].is_ascii_digit()
            && bytes[i + 8].is_ascii_digit()
            && bytes[i + 9].is_ascii_digit()
            && bytes[i + 10].is_ascii_digit()
        {
            // Don't match if preceded or followed by a digit (avoids partial matches)
            let preceded_by_digit = i > 0 && bytes[i - 1].is_ascii_digit();
            let followed_by_digit = i + 11 < bytes.len() && bytes[i + 11].is_ascii_digit();
            if !preceded_by_digit && !followed_by_digit {
                results.push(PiiDetection {
                    pii_type: PiiType::Ssn,
                    start: i,
                    end: i + 11,
                    matched: text[i..i + 11].to_string(),
                });
                i += 11;
                continue;
            }
        }
        i += 1;
    }

    // Phone: US phone numbers — (XXX) XXX-XXXX, XXX-XXX-XXXX, +1XXXXXXXXXX
    i = 0;
    while i < bytes.len() {
        // (XXX) XXX-XXXX  or  (XXX)XXX-XXXX
        if bytes[i] == b'(' && i + 13 <= bytes.len() {
            if let Some(phone) = try_match_paren_phone(bytes, i) {
                results.push(PiiDetection {
                    pii_type: PiiType::Phone,
                    start: i,
                    end: i + phone.len(),
                    matched: phone,
                });
                i += 14;
                continue;
            }
        }
        // +1XXXXXXXXXX or +1-XXX-XXX-XXXX
        if bytes[i] == b'+' && i + 1 < bytes.len() && bytes[i + 1] == b'1' {
            if let Some((phone, len)) = try_match_plus1_phone(bytes, i) {
                results.push(PiiDetection {
                    pii_type: PiiType::Phone,
                    start: i,
                    end: i + len,
                    matched: phone,
                });
                i += len;
                continue;
            }
        }
        // XXX-XXX-XXXX (avoid matching SSNs — SSN is 3-2-4, phone is 3-3-4)
        if i + 12 <= bytes.len()
            && bytes[i].is_ascii_digit()
            && bytes[i + 1].is_ascii_digit()
            && bytes[i + 2].is_ascii_digit()
            && bytes[i + 3] == b'-'
            && bytes[i + 4].is_ascii_digit()
            && bytes[i + 5].is_ascii_digit()
            && bytes[i + 6].is_ascii_digit()
            && bytes[i + 7] == b'-'
            && bytes[i + 8].is_ascii_digit()
            && bytes[i + 9].is_ascii_digit()
            && bytes[i + 10].is_ascii_digit()
            && bytes[i + 11].is_ascii_digit()
        {
            let preceded_by_digit = i > 0 && bytes[i - 1].is_ascii_digit();
            let followed_by_digit = i + 12 < bytes.len() && bytes[i + 12].is_ascii_digit();
            if !preceded_by_digit && !followed_by_digit {
                results.push(PiiDetection {
                    pii_type: PiiType::Phone,
                    start: i,
                    end: i + 12,
                    matched: text[i..i + 12].to_string(),
                });
                i += 12;
                continue;
            }
        }
        i += 1;
    }

    // Credit Card: 13-19 consecutive digits (with optional - or space separators)
    // Simplified: match runs of 13-19 digits (ignoring separators)
    i = 0;
    while i < bytes.len() {
        if bytes[i].is_ascii_digit() {
            let start = i;
            let mut digit_count = 0;
            let mut j = i;
            while j < bytes.len()
                && (bytes[j].is_ascii_digit() || bytes[j] == b'-' || bytes[j] == b' ')
            {
                if bytes[j].is_ascii_digit() {
                    digit_count += 1;
                }
                j += 1;
                if digit_count >= 19 {
                    break;
                }
            }
            if (13..=19).contains(&digit_count) {
                // Trim trailing separators first
                let trimmed_end = text[start..j].trim_end_matches(['-', ' ']).len() + start;
                // Don't match if preceded by alphanumeric (avoid matching within larger numbers/tokens)
                let preceded_by_alnum = start > 0 && bytes[start - 1].is_ascii_alphanumeric();
                let followed_by_alnum =
                    trimmed_end < bytes.len() && bytes[trimmed_end].is_ascii_alphanumeric();
                if !preceded_by_alnum && !followed_by_alnum {
                    results.push(PiiDetection {
                        pii_type: PiiType::CreditCard,
                        start,
                        end: trimmed_end,
                        matched: text[start..trimmed_end].to_string(),
                    });
                    i = j;
                    continue;
                }
            }
            i = if digit_count > 0 { j } else { i + 1 };
            continue;
        }
        i += 1;
    }

    // IP Address: X.X.X.X where each octet is 0-255
    i = 0;
    while i < bytes.len() {
        if bytes[i].is_ascii_digit() {
            if let Some((ip, len)) = try_match_ipv4(text, i) {
                let preceded_by_alnum =
                    i > 0 && (bytes[i - 1].is_ascii_alphanumeric() || bytes[i - 1] == b'.');
                let followed_by_dot = i + len < bytes.len() && bytes[i + len] == b'.';
                if !preceded_by_alnum && !followed_by_dot {
                    results.push(PiiDetection {
                        pii_type: PiiType::IpAddress,
                        start: i,
                        end: i + len,
                        matched: ip,
                    });
                    i += len;
                    continue;
                }
            }
        }
        i += 1;
    }

    // API Key: common prefixes followed by long alphanumeric strings
    for prefix in &["sk-", "pk-", "api_", "key_", "token_", "bearer "] {
        let search_text = if *prefix == "bearer " {
            text.to_lowercase()
        } else {
            text.to_string()
        };
        let actual_prefix = if *prefix == "bearer " {
            "bearer "
        } else {
            *prefix
        };
        for (pos, _) in search_text.match_indices(actual_prefix) {
            let after_prefix = pos + actual_prefix.len();
            if after_prefix >= text.len() {
                continue;
            }
            // Count alphanumeric + common key chars after prefix
            let key_end = text[after_prefix..]
                .find(|c: char| !c.is_alphanumeric() && c != '-' && c != '_')
                .map(|p| after_prefix + p)
                .unwrap_or(text.len());
            let key_part_len = key_end - after_prefix;
            // API keys are typically 20+ chars
            if key_part_len >= 20 {
                results.push(PiiDetection {
                    pii_type: PiiType::ApiKey,
                    start: pos,
                    end: key_end,
                    matched: text[pos..key_end].to_string(),
                });
            }
        }
    }

    results
}

/// Try to match (XXX) XXX-XXXX or (XXX)XXX-XXXX at position `i`.
fn try_match_paren_phone(bytes: &[u8], i: usize) -> Option<String> {
    // Need at least 14 chars for (XXX) XXX-XXXX
    if i + 14 > bytes.len() {
        return None;
    }
    // (XXX)
    if !bytes[i + 1].is_ascii_digit()
        || !bytes[i + 2].is_ascii_digit()
        || !bytes[i + 3].is_ascii_digit()
        || bytes[i + 4] != b')'
    {
        return None;
    }
    // Optional space after )
    let offset = if bytes[i + 5] == b' ' { 6 } else { 5 };
    if i + offset + 8 > bytes.len() {
        return None;
    }
    // XXX-XXXX
    if bytes[i + offset].is_ascii_digit()
        && bytes[i + offset + 1].is_ascii_digit()
        && bytes[i + offset + 2].is_ascii_digit()
        && bytes[i + offset + 3] == b'-'
        && bytes[i + offset + 4].is_ascii_digit()
        && bytes[i + offset + 5].is_ascii_digit()
        && bytes[i + offset + 6].is_ascii_digit()
        && bytes[i + offset + 7].is_ascii_digit()
    {
        let end = i + offset + 8;
        return Some(String::from_utf8_lossy(&bytes[i..end]).to_string());
    }
    None
}

/// Try to match +1XXXXXXXXXX or +1-XXX-XXX-XXXX at position `i`.
fn try_match_plus1_phone(bytes: &[u8], i: usize) -> Option<(String, usize)> {
    let after_1 = i + 2;
    if after_1 >= bytes.len() {
        return None;
    }

    // Count digits and separators after +1
    let mut j = after_1;
    // Skip optional separator after +1
    if j < bytes.len() && (bytes[j] == b'-' || bytes[j] == b' ') {
        j += 1;
    }
    let mut digit_count = 0;
    let start_of_number = j;
    while j < bytes.len() && (bytes[j].is_ascii_digit() || bytes[j] == b'-' || bytes[j] == b' ') {
        if bytes[j].is_ascii_digit() {
            digit_count += 1;
        }
        j += 1;
        if digit_count >= 10 {
            break;
        }
    }
    if digit_count == 10 {
        let _ = start_of_number; // suppress unused warning
        return Some((String::from_utf8_lossy(&bytes[i..j]).to_string(), j - i));
    }
    None
}

/// Try to match an IPv4 address at position `i`. Returns (ip_string, length).
fn try_match_ipv4(text: &str, start: usize) -> Option<(String, usize)> {
    let remaining = &text[start..];
    let mut octets = Vec::with_capacity(4);
    let mut pos = 0;

    for octet_idx in 0..4 {
        if pos >= remaining.len() {
            return None;
        }
        let octet_start = pos;
        while pos < remaining.len() && remaining.as_bytes()[pos].is_ascii_digit() {
            pos += 1;
        }
        let octet_str = &remaining[octet_start..pos];
        if octet_str.is_empty() || octet_str.len() > 3 {
            return None;
        }
        let val: u16 = octet_str.parse().ok()?;
        if val > 255 {
            return None;
        }
        // Leading zeros check (e.g., "01" is not valid)
        if octet_str.len() > 1 && octet_str.starts_with('0') {
            return None;
        }
        octets.push(val);
        if octet_idx < 3 {
            if pos >= remaining.len() || remaining.as_bytes()[pos] != b'.' {
                return None;
            }
            pos += 1; // skip dot
        }
    }

    if octets.len() == 4 {
        // Skip common private/loopback ranges that appear in configs
        if octets[0] == 127 || (octets[0] == 10) || (octets[0] == 0) {
            return None;
        }
        let ip = remaining[..pos].to_string();
        Some((ip, pos))
    } else {
        None
    }
}

/// Apply PII masking to text, returning masked text and the masking map.
pub fn mask_pii(text: &str) -> (String, PiiMaskingMap) {
    let detections = detect_pii(text);
    if detections.is_empty() {
        return (text.to_string(), PiiMaskingMap::new());
    }

    let mut map = PiiMaskingMap::new();
    let mut result = text.to_string();

    // Sort detections by start position descending (for reverse-order replacement).
    let mut sorted = detections;
    sorted.sort_by(|a, b| b.start.cmp(&a.start).then(a.end.cmp(&b.end)));

    // Merge overlapping detections to prevent replace_range panics when
    // multiple detectors match the same byte range (e.g., a number matching
    // both phone and credit-card patterns). After merging, no two detections
    // overlap, so reverse-order replacement is safe.
    let mut merged: Vec<PiiDetection> = Vec::with_capacity(sorted.len());
    for det in sorted {
        if let Some(last) = merged.last_mut() {
            // Sorted descending by start, so det.start <= last.start.
            // Overlap if det.end >= last.start (the ranges touch or cross).
            if det.end >= last.start {
                // Widen the span to cover both detections.
                last.start = last.start.min(det.start);
                last.end = last.end.max(det.end);
                // Keep the wider detection's entity_type (first one wins).
                continue;
            }
        }
        merged.push(det);
    }

    for detection in &merged {
        let placeholder = map.mask(detection);
        result.replace_range(detection.start..detection.end, &placeholder);
    }

    (result, map)
}

/// Output guardrail engine.
pub struct OutputGuardrails {
    /// Default operating mode.
    pub default_mode: GuardrailMode,
    /// Default PII action.
    pub default_pii_action: PiiAction,
    /// Total violations detected.
    violations: AtomicU64,
    /// Pending flag entries for review.
    flagged: Mutex<Vec<String>>,
}

impl OutputGuardrails {
    /// Create a new output guardrails engine.
    pub fn new(default_mode: GuardrailMode, default_pii_action: PiiAction) -> Self {
        Self {
            default_mode,
            default_pii_action,
            violations: AtomicU64::new(0),
            flagged: Mutex::new(Vec::new()),
        }
    }

    /// Scan text for PII and apply the configured action.
    ///
    /// Returns the processed text and an optional masking map (for Mask action).
    pub fn scan(&self, text: &str) -> GuardrailResult {
        let detections = detect_pii(text);
        if detections.is_empty() {
            return GuardrailResult::Clean(text.to_string());
        }

        self.violations.fetch_add(1, Ordering::Relaxed);

        match self.default_pii_action {
            PiiAction::Pass => GuardrailResult::Clean(text.to_string()),
            PiiAction::Block => GuardrailResult::Blocked {
                reason: format!("PII detected: {} entities", detections.len()),
            },
            PiiAction::Redact => {
                let mut result = text.to_string();
                let mut sorted = detections;
                sorted.sort_by_key(|d| std::cmp::Reverse(d.start));
                for d in &sorted {
                    result.replace_range(d.start..d.end, "[REDACTED]");
                }
                GuardrailResult::Redacted(result)
            }
            PiiAction::Mask => {
                let (masked, map) = mask_pii(text);
                GuardrailResult::Masked { text: masked, map }
            }
            PiiAction::Flag => {
                let mut flagged = self.flagged.lock();
                flagged.push(text.to_string());
                GuardrailResult::Flagged(text.to_string())
            }
        }
    }

    /// Get the total number of violations detected.
    pub fn violation_count(&self) -> u64 {
        self.violations.load(Ordering::Relaxed)
    }
}

/// Result of a guardrail scan.
#[derive(Debug)]
pub enum GuardrailResult {
    /// No issues detected.
    Clean(String),
    /// PII was redacted (irreversible).
    Redacted(String),
    /// PII was masked (reversible via map).
    Masked { text: String, map: PiiMaskingMap },
    /// Content was blocked.
    Blocked { reason: String },
    /// Content was flagged for review.
    Flagged(String),
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn detect_email() {
        let detections = detect_pii("Contact us at user@example.com for info");
        assert!(detections
            .iter()
            .any(|d| d.pii_type == PiiType::Email && d.matched == "user@example.com"));
    }

    #[test]
    fn detect_ssn() {
        let detections = detect_pii("SSN: 123-45-6789 is sensitive");
        assert!(detections
            .iter()
            .any(|d| d.pii_type == PiiType::Ssn && d.matched == "123-45-6789"));
    }

    #[test]
    fn detect_phone_dashed() {
        let detections = detect_pii("Call 555-123-4567 now");
        assert!(
            detections.iter().any(|d| d.pii_type == PiiType::Phone),
            "should detect phone: {:?}",
            detections
        );
    }

    #[test]
    fn detect_phone_parens() {
        let detections = detect_pii("Call (555) 123-4567 now");
        assert!(
            detections.iter().any(|d| d.pii_type == PiiType::Phone),
            "should detect parenthesized phone: {:?}",
            detections
        );
    }

    #[test]
    fn detect_credit_card() {
        let detections = detect_pii("Card: 4111-1111-1111-1111 expires 12/25");
        assert!(
            detections.iter().any(|d| d.pii_type == PiiType::CreditCard),
            "should detect credit card: {:?}",
            detections
        );
    }

    #[test]
    fn detect_ip_address() {
        let detections = detect_pii("Server at 203.0.113.42 is down");
        assert!(
            detections
                .iter()
                .any(|d| d.pii_type == PiiType::IpAddress && d.matched == "203.0.113.42"),
            "should detect IP: {:?}",
            detections
        );
    }

    #[test]
    fn detect_api_key() {
        let detections = detect_pii("Use key sk-abcdefghijklmnopqrstuvwxyz1234 for access");
        assert!(
            detections.iter().any(|d| d.pii_type == PiiType::ApiKey),
            "should detect API key: {:?}",
            detections
        );
    }

    #[test]
    fn skip_private_ip() {
        let detections = detect_pii("localhost 127.0.0.1 and private 10.0.0.1");
        assert!(
            !detections.iter().any(|d| d.pii_type == PiiType::IpAddress),
            "should skip private/loopback IPs: {:?}",
            detections
        );
    }

    #[test]
    fn detect_multiple_pii() {
        let detections = detect_pii("Email: alice@corp.com, SSN: 999-88-7777 end");
        assert!(detections.len() >= 2);
    }

    #[test]
    fn no_pii_in_clean_text() {
        let detections = detect_pii("Hello, this is a normal message with no sensitive data.");
        assert!(detections.is_empty());
    }

    #[test]
    fn mask_and_unmask_roundtrip() {
        let text = "Contact user@example.com for details";
        let (masked, map) = mask_pii(text);
        assert!(!masked.contains("user@example.com"));
        assert!(masked.contains("<EMAIL_"));
        let unmasked = map.unmask(&masked);
        assert_eq!(unmasked, text);
    }

    #[test]
    fn masking_map_unique_placeholders() {
        let mut map = PiiMaskingMap::new();
        let d1 = PiiDetection {
            pii_type: PiiType::Email,
            start: 0,
            end: 5,
            matched: "a@b.c".into(),
        };
        let d2 = PiiDetection {
            pii_type: PiiType::Email,
            start: 10,
            end: 15,
            matched: "x@y.z".into(),
        };
        let p1 = map.mask(&d1);
        let p2 = map.mask(&d2);
        assert_ne!(p1, p2);
        assert_eq!(map.len(), 2);
    }

    #[test]
    fn guardrail_pass_action() {
        let g = OutputGuardrails::new(GuardrailMode::Buffer, PiiAction::Pass);
        match g.scan("user@example.com") {
            GuardrailResult::Clean(text) => assert!(text.contains("user@example.com")),
            _ => panic!("expected Clean"),
        }
    }

    #[test]
    fn guardrail_block_action() {
        let g = OutputGuardrails::new(GuardrailMode::Buffer, PiiAction::Block);
        match g.scan("user@example.com") {
            GuardrailResult::Blocked { reason } => assert!(reason.contains("PII")),
            _ => panic!("expected Blocked"),
        }
    }

    #[test]
    fn guardrail_redact_action() {
        let g = OutputGuardrails::new(GuardrailMode::Buffer, PiiAction::Redact);
        match g.scan("Contact user@example.com now") {
            GuardrailResult::Redacted(text) => {
                assert!(text.contains("[REDACTED]"));
                assert!(!text.contains("user@example.com"));
            }
            _ => panic!("expected Redacted"),
        }
    }

    #[test]
    fn guardrail_mask_action() {
        let g = OutputGuardrails::new(GuardrailMode::Buffer, PiiAction::Mask);
        match g.scan("Contact user@example.com now") {
            GuardrailResult::Masked { text, map } => {
                assert!(!text.contains("user@example.com"));
                assert!(!map.is_empty());
                let unmasked = map.unmask(&text);
                assert!(unmasked.contains("user@example.com"));
            }
            _ => panic!("expected Masked"),
        }
    }

    #[test]
    fn guardrail_flag_action() {
        let g = OutputGuardrails::new(GuardrailMode::Buffer, PiiAction::Flag);
        match g.scan("user@example.com") {
            GuardrailResult::Flagged(text) => assert!(text.contains("user@example.com")),
            _ => panic!("expected Flagged"),
        }
    }

    #[test]
    fn guardrail_no_violation_for_clean_text() {
        let g = OutputGuardrails::new(GuardrailMode::Async, PiiAction::Block);
        match g.scan("Hello world") {
            GuardrailResult::Clean(_) => {}
            _ => panic!("expected Clean"),
        }
        assert_eq!(g.violation_count(), 0);
    }

    #[test]
    fn guardrail_violation_counter() {
        let g = OutputGuardrails::new(GuardrailMode::Buffer, PiiAction::Redact);
        g.scan("user@example.com");
        g.scan("another@test.org");
        assert_eq!(g.violation_count(), 2);
    }

    #[test]
    fn ssn_not_matched_at_end_of_string() {
        // Regression: SSN at very end of string should still be detected
        let detections = detect_pii("SSN is 123-45-6789");
        assert!(detections.iter().any(|d| d.pii_type == PiiType::Ssn));
    }

    #[test]
    fn ssn_not_partial_match() {
        // Should not match partial SSN-like patterns within longer numbers
        let detections = detect_pii("code 1234-56-78901 is not SSN");
        assert!(
            !detections.iter().any(|d| d.pii_type == PiiType::Ssn),
            "should not match partial SSN: {:?}",
            detections
        );
    }
}
