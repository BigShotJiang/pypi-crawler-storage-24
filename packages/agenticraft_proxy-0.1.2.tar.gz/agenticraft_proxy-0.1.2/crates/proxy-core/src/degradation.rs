// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Graceful degradation paths (S7).
//!
//! Defines degradation modes for every feature so the proxy can continue
//! operating when individual components fail. Without defined degradation
//! modes, the proxy either crashes or silently drops guarantees.

use std::fmt;

/// How a feature should behave when its dependencies fail.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum DegradationMode {
    /// Allow the request through without this feature's processing.
    /// Used when skipping is safe (e.g., cache miss is harmless).
    FailOpen,

    /// Reject the request when this feature can't process it.
    /// Used when processing is required for correctness/compliance.
    FailClosed,
}

impl fmt::Display for DegradationMode {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::FailOpen => write!(f, "fail_open"),
            Self::FailClosed => write!(f, "fail_closed"),
        }
    }
}

/// Health status of a feature.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FeatureHealthStatus {
    /// Feature is operating normally.
    Healthy,
    /// Feature is degraded but still operational.
    Degraded,
    /// Feature has failed and is using its degradation mode.
    Failed,
    /// Feature is disabled by configuration.
    Disabled,
}

impl fmt::Display for FeatureHealthStatus {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Healthy => write!(f, "healthy"),
            Self::Degraded => write!(f, "degraded"),
            Self::Failed => write!(f, "failed"),
            Self::Disabled => write!(f, "disabled"),
        }
    }
}

/// Degradation policy for a specific feature.
#[derive(Debug, Clone)]
pub struct FeatureDegradation {
    /// Feature identifier (e.g., "F1", "F2", "F15").
    pub feature: &'static str,
    /// Human-readable name.
    pub name: &'static str,
    /// Default degradation mode when the feature fails.
    pub default_mode: DegradationMode,
    /// Description of what happens in FailOpen mode.
    pub fail_open_behavior: &'static str,
    /// Description of what happens in FailClosed mode.
    pub fail_closed_behavior: &'static str,
}

/// All feature degradation policies.
///
/// Each feature must define both FailOpen and FailClosed behaviors,
/// even if only one is the default.
pub static FEATURE_DEGRADATIONS: &[FeatureDegradation] = &[
    FeatureDegradation {
        feature: "F1",
        name: "Semantic Cache",
        default_mode: DegradationMode::FailOpen,
        fail_open_behavior: "Skip semantic search, use exact cache only",
        fail_closed_behavior: "N/A (cache miss is always safe)",
    },
    FeatureDegradation {
        feature: "F2",
        name: "Output Guardrails",
        default_mode: DegradationMode::FailClosed,
        fail_open_behavior: "Pass response unscanned + flag in compliance log",
        fail_closed_behavior: "Block response with 503",
    },
    FeatureDegradation {
        feature: "F5",
        name: "Budget Enforcement",
        default_mode: DegradationMode::FailClosed,
        fail_open_behavior: "Allow request + log budget check skip",
        fail_closed_behavior: "Reject with 503 Service Unavailable",
    },
    FeatureDegradation {
        feature: "F15",
        name: "Compliance Engine",
        default_mode: DegradationMode::FailClosed,
        fail_open_behavior: "Buffer in-memory (bounded) + alert",
        fail_closed_behavior: "Reject request (regulatory requirement)",
    },
    FeatureDegradation {
        feature: "F16",
        name: "SLA Engine",
        default_mode: DegradationMode::FailOpen,
        fail_open_behavior: "Skip SLA hints, route normally",
        fail_closed_behavior: "Reject if SLA can't be guaranteed",
    },
    FeatureDegradation {
        feature: "F17",
        name: "HITL Manager",
        default_mode: DegradationMode::FailOpen,
        fail_open_behavior: "Allow request without human review + flag",
        fail_closed_behavior: "Reject high-risk requests without review",
    },
    FeatureDegradation {
        feature: "F19",
        name: "Zero-Trust Engine",
        default_mode: DegradationMode::FailOpen,
        fail_open_behavior: "Allow + flag for async review",
        fail_closed_behavior: "Block agent until behavioral check available",
    },
    FeatureDegradation {
        feature: "F23",
        name: "Fraud Detector",
        default_mode: DegradationMode::FailOpen,
        fail_open_behavior: "Allow + schedule async re-check",
        fail_closed_behavior: "Block until fraud check completes",
    },
    FeatureDegradation {
        feature: "F30",
        name: "AI-Aware Routing",
        default_mode: DegradationMode::FailOpen,
        fail_open_behavior: "Fall through to Thompson sampling",
        fail_closed_behavior: "N/A (Thompson sampling is always available)",
    },
];

/// Get the degradation policy for a specific feature.
pub fn get_degradation(feature: &str) -> Option<&'static FeatureDegradation> {
    FEATURE_DEGRADATIONS.iter().find(|d| d.feature == feature)
}

/// Trait that features must implement to support degradation.
pub trait Degradable {
    /// Return the current health status.
    fn health_status(&self) -> FeatureHealthStatus;

    /// Return the degradation action to take when this feature fails.
    fn degraded_action(&self) -> DegradationMode;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn all_features_have_degradation_policies() {
        assert!(FEATURE_DEGRADATIONS.len() >= 9);
    }

    #[test]
    fn compliance_defaults_to_fail_closed() {
        let d = get_degradation("F15").unwrap();
        assert_eq!(d.default_mode, DegradationMode::FailClosed);
    }

    #[test]
    fn semantic_cache_defaults_to_fail_open() {
        let d = get_degradation("F1").unwrap();
        assert_eq!(d.default_mode, DegradationMode::FailOpen);
    }

    #[test]
    fn output_guardrails_defaults_to_fail_closed() {
        let d = get_degradation("F2").unwrap();
        assert_eq!(d.default_mode, DegradationMode::FailClosed);
    }

    #[test]
    fn unknown_feature_returns_none() {
        assert!(get_degradation("F99").is_none());
    }

    #[test]
    fn degradation_mode_display() {
        assert_eq!(DegradationMode::FailOpen.to_string(), "fail_open");
        assert_eq!(DegradationMode::FailClosed.to_string(), "fail_closed");
    }

    #[test]
    fn feature_health_display() {
        assert_eq!(FeatureHealthStatus::Healthy.to_string(), "healthy");
        assert_eq!(FeatureHealthStatus::Degraded.to_string(), "degraded");
        assert_eq!(FeatureHealthStatus::Failed.to_string(), "failed");
        assert_eq!(FeatureHealthStatus::Disabled.to_string(), "disabled");
    }

    #[test]
    fn all_policies_have_both_behaviors() {
        for d in FEATURE_DEGRADATIONS {
            assert!(
                !d.fail_open_behavior.is_empty(),
                "feature {} missing fail_open_behavior",
                d.feature
            );
            assert!(
                !d.fail_closed_behavior.is_empty(),
                "feature {} missing fail_closed_behavior",
                d.feature
            );
        }
    }
}
