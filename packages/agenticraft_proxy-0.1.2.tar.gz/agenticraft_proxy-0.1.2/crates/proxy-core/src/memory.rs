// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Agent memory gateway with privacy enforcement (F10).
//!
//! Three-tier architecture:
//! - Hot: In-context memory (<200 items per agent, fast access)
//! - Warm: Vector-indexed, searchable via embeddings
//! - Cold: Archived, compressed (serialized to bytes)
//!
//! Privacy enforcement: cross-agent isolation, configurable sharing rules,
//! PII scan on write (reuses F2 guardrail engine).

use std::collections::HashMap;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{Duration, Instant};

use dashmap::DashMap;

/// Memory tier classification.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub enum MemoryTier {
    Hot,
    Warm,
    Cold,
}

/// Helper for serde default on Instant fields.
fn instant_now() -> Instant {
    Instant::now()
}

/// A single memory entry.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct MemoryEntry {
    /// Unique memory ID.
    pub id: String,
    /// Agent that owns this memory.
    pub agent_id: String,
    /// Content of the memory.
    pub content: String,
    /// Memory tier.
    pub tier: MemoryTier,
    /// Optional embedding vector (for warm tier search).
    #[cfg_attr(feature = "serde", serde(skip))]
    pub embedding: Option<Vec<f32>>,
    /// Metadata key-value pairs.
    pub metadata: HashMap<String, String>,
    /// When this memory was created.
    #[cfg_attr(feature = "serde", serde(skip, default = "instant_now"))]
    pub created_at: Instant,
    /// When this memory was last accessed.
    #[cfg_attr(feature = "serde", serde(skip, default = "instant_now"))]
    pub last_accessed: Instant,
    /// Access count (for triage decisions).
    pub access_count: u64,
    /// Whether PII was detected and handled on write.
    pub pii_scanned: bool,
}

/// Privacy sharing rule between agents.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub enum SharingRule {
    /// No sharing — strict isolation (default).
    #[default]
    None,
    /// Share with specific agents.
    AllowList(Vec<String>),
    /// Share within a team/org scope.
    SameTeam,
    /// Share everything (open).
    Open,
}

/// Per-agent memory store.
struct AgentMemoryStore {
    /// Hot tier: in-context, fast access. Bounded to max_hot items.
    hot: Vec<MemoryEntry>,
    /// Warm tier: vector-indexed for search.
    warm: Vec<MemoryEntry>,
    /// Cold tier: archived, compressed.
    cold: Vec<MemoryEntry>,
    /// Maximum hot tier items before auto-triage to warm.
    max_hot: usize,
    /// Sharing rules for this agent.
    sharing_rule: SharingRule,
}

impl AgentMemoryStore {
    fn new(max_hot: usize) -> Self {
        Self {
            hot: Vec::new(),
            warm: Vec::new(),
            cold: Vec::new(),
            max_hot,
            sharing_rule: SharingRule::None,
        }
    }

    /// Total memory count across all tiers.
    fn total_count(&self) -> usize {
        self.hot.len() + self.warm.len() + self.cold.len()
    }
}

/// Agent Memory Gateway — manages per-agent memory with privacy enforcement.
pub struct MemoryGateway {
    /// Per-agent memory stores. Key: agent_id.
    stores: DashMap<String, AgentMemoryStore>,
    /// Default max hot tier items per agent.
    default_max_hot: usize,
    /// Total writes across all agents.
    total_writes: AtomicU64,
    /// Total reads across all agents.
    total_reads: AtomicU64,
    /// Total search queries.
    total_searches: AtomicU64,
}

impl MemoryGateway {
    /// Create a new memory gateway.
    pub fn new(default_max_hot: usize) -> Self {
        Self {
            stores: DashMap::new(),
            default_max_hot,
            total_writes: AtomicU64::new(0),
            total_reads: AtomicU64::new(0),
            total_searches: AtomicU64::new(0),
        }
    }

    /// Write a memory entry for an agent.
    ///
    /// Auto-triages to warm tier when hot tier is full.
    /// PII scanning should be done by the caller before writing.
    pub fn write(&self, entry: MemoryEntry) {
        let agent_id = entry.agent_id.clone();
        let mut store = self
            .stores
            .entry(agent_id)
            .or_insert_with(|| AgentMemoryStore::new(self.default_max_hot));

        // If hot tier is full, triage oldest to warm
        if store.hot.len() >= store.max_hot {
            if let Some(oldest) = store
                .hot
                .iter()
                .enumerate()
                .min_by_key(|(_, e)| e.access_count)
                .map(|(i, _)| i)
            {
                let mut triaged = store.hot.swap_remove(oldest);
                triaged.tier = MemoryTier::Warm;
                store.warm.push(triaged);
            }
        }

        store.hot.push(entry);
        self.total_writes.fetch_add(1, Ordering::Relaxed);
    }

    /// Read all hot-tier memories for an agent.
    pub fn read_hot(&self, agent_id: &str) -> Vec<MemoryEntry> {
        self.total_reads.fetch_add(1, Ordering::Relaxed);
        self.stores
            .get(agent_id)
            .map(|store| store.hot.clone())
            .unwrap_or_default()
    }

    /// Read a specific memory by ID for an agent.
    pub fn read_by_id(&self, agent_id: &str, memory_id: &str) -> Option<MemoryEntry> {
        self.total_reads.fetch_add(1, Ordering::Relaxed);
        let store = self.stores.get(agent_id)?;
        store
            .hot
            .iter()
            .chain(store.warm.iter())
            .chain(store.cold.iter())
            .find(|e| e.id == memory_id)
            .cloned()
    }

    /// Search warm-tier memories using cosine similarity.
    ///
    /// Returns entries with similarity >= threshold, sorted by similarity descending.
    pub fn search(
        &self,
        agent_id: &str,
        query_embedding: &[f32],
        threshold: f32,
        max_results: usize,
    ) -> Vec<(MemoryEntry, f32)> {
        self.total_searches.fetch_add(1, Ordering::Relaxed);
        let store = match self.stores.get(agent_id) {
            Some(s) => s,
            None => return Vec::new(),
        };

        let mut results: Vec<(MemoryEntry, f32)> = store
            .warm
            .iter()
            .filter_map(|entry| {
                entry.embedding.as_ref().map(|emb| {
                    let sim = crate::semantic_cache::cosine_similarity(query_embedding, emb);
                    (entry.clone(), sim)
                })
            })
            .filter(|(_, sim)| *sim >= threshold)
            .collect();

        results.sort_by(|(_, a), (_, b)| b.partial_cmp(a).unwrap_or(std::cmp::Ordering::Equal));
        results.truncate(max_results);
        results
    }

    /// Search with cross-agent access (respects sharing rules).
    ///
    /// `requesting_agent_id` is the agent making the query.
    /// `target_agent_id` is the agent whose memories are being searched.
    pub fn search_cross_agent(
        &self,
        requesting_agent_id: &str,
        target_agent_id: &str,
        query_embedding: &[f32],
        threshold: f32,
        max_results: usize,
    ) -> Result<Vec<(MemoryEntry, f32)>, MemoryAccessDenied> {
        // Same agent = always allowed
        if requesting_agent_id == target_agent_id {
            return Ok(self.search(target_agent_id, query_embedding, threshold, max_results));
        }

        // Check sharing rules
        let store = self
            .stores
            .get(target_agent_id)
            .ok_or(MemoryAccessDenied::AgentNotFound)?;

        match &store.sharing_rule {
            SharingRule::None => Err(MemoryAccessDenied::NotShared),
            SharingRule::AllowList(allowed) => {
                if allowed.contains(&requesting_agent_id.to_string()) {
                    drop(store); // Release DashMap ref before calling search
                    Ok(self.search(target_agent_id, query_embedding, threshold, max_results))
                } else {
                    Err(MemoryAccessDenied::NotInAllowList)
                }
            }
            SharingRule::SameTeam => {
                // For now, same-team check is delegated to the caller
                drop(store);
                Ok(self.search(target_agent_id, query_embedding, threshold, max_results))
            }
            SharingRule::Open => {
                drop(store);
                Ok(self.search(target_agent_id, query_embedding, threshold, max_results))
            }
        }
    }

    /// Set sharing rules for an agent.
    pub fn set_sharing_rule(&self, agent_id: &str, rule: SharingRule) {
        if let Some(mut store) = self.stores.get_mut(agent_id) {
            store.sharing_rule = rule;
        }
    }

    /// Manually triage: move entries from hot to warm or warm to cold.
    pub fn triage(&self, agent_id: &str) -> TriageResult {
        let mut store = match self.stores.get_mut(agent_id) {
            Some(s) => s,
            None => {
                return TriageResult {
                    hot_to_warm: 0,
                    warm_to_cold: 0,
                }
            }
        };

        let mut hot_to_warm = 0;
        let mut warm_to_cold = 0;

        // Move low-access hot entries to warm
        let threshold = store.max_hot / 2;
        if store.hot.len() > threshold {
            let mut sorted_indices: Vec<usize> = (0..store.hot.len()).collect();
            sorted_indices.sort_by_key(|&i| store.hot[i].access_count);
            let to_move = store.hot.len() - threshold;
            // Collect entries to move (take from lowest access count)
            let mut entries_to_move = Vec::new();
            for &idx in sorted_indices.iter().take(to_move) {
                entries_to_move.push(idx);
            }
            entries_to_move.sort_unstable_by(|a, b| b.cmp(a)); // reverse order for removal
            for idx in entries_to_move {
                let mut entry = store.hot.swap_remove(idx);
                entry.tier = MemoryTier::Warm;
                store.warm.push(entry);
                hot_to_warm += 1;
            }
        }

        // Move old warm entries to cold (accessed > 1 hour ago)
        let cold_threshold = Duration::from_secs(3600);
        let now = Instant::now();
        let mut warm_to_cold_entries = Vec::new();
        store.warm.retain(|e| {
            if now.duration_since(e.last_accessed) > cold_threshold {
                warm_to_cold_entries.push(e.clone());
                false
            } else {
                true
            }
        });
        for mut entry in warm_to_cold_entries {
            entry.tier = MemoryTier::Cold;
            store.cold.push(entry);
            warm_to_cold += 1;
        }

        TriageResult {
            hot_to_warm,
            warm_to_cold,
        }
    }

    /// Get memory statistics for an agent.
    pub fn stats(&self, agent_id: &str) -> MemoryStats {
        match self.stores.get(agent_id) {
            Some(store) => MemoryStats {
                hot_count: store.hot.len() as u64,
                warm_count: store.warm.len() as u64,
                cold_count: store.cold.len() as u64,
                total_count: store.total_count() as u64,
                sharing_rule: format!("{:?}", store.sharing_rule),
            },
            None => MemoryStats::default(),
        }
    }

    /// Get global gateway statistics.
    pub fn global_stats(&self) -> GatewayStats {
        GatewayStats {
            total_agents: self.stores.len() as u64,
            total_writes: self.total_writes.load(Ordering::Relaxed),
            total_reads: self.total_reads.load(Ordering::Relaxed),
            total_searches: self.total_searches.load(Ordering::Relaxed),
        }
    }

    /// Get agent count.
    pub fn agent_count(&self) -> usize {
        self.stores.len()
    }

    /// Remove all memories for an agent.
    pub fn delete_agent(&self, agent_id: &str) -> bool {
        self.stores.remove(agent_id).is_some()
    }
}

/// Result of a triage operation.
#[derive(Debug, Clone)]
pub struct TriageResult {
    pub hot_to_warm: usize,
    pub warm_to_cold: usize,
}

/// Per-agent memory statistics.
#[derive(Debug, Clone, Default)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct MemoryStats {
    pub hot_count: u64,
    pub warm_count: u64,
    pub cold_count: u64,
    pub total_count: u64,
    pub sharing_rule: String,
}

/// Global gateway statistics.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct GatewayStats {
    pub total_agents: u64,
    pub total_writes: u64,
    pub total_reads: u64,
    pub total_searches: u64,
}

/// Error when cross-agent memory access is denied.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum MemoryAccessDenied {
    AgentNotFound,
    NotShared,
    NotInAllowList,
}

impl std::fmt::Display for MemoryAccessDenied {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            MemoryAccessDenied::AgentNotFound => write!(f, "target agent not found"),
            MemoryAccessDenied::NotShared => write!(f, "agent memory is not shared"),
            MemoryAccessDenied::NotInAllowList => {
                write!(f, "requesting agent not in allow list")
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_entry(agent_id: &str, id: &str, content: &str) -> MemoryEntry {
        MemoryEntry {
            id: id.to_string(),
            agent_id: agent_id.to_string(),
            content: content.to_string(),
            tier: MemoryTier::Hot,
            embedding: None,
            metadata: HashMap::new(),
            created_at: Instant::now(),
            last_accessed: Instant::now(),
            access_count: 0,
            pii_scanned: false,
        }
    }

    fn make_warm_entry(agent_id: &str, id: &str, embedding: Vec<f32>) -> MemoryEntry {
        MemoryEntry {
            id: id.to_string(),
            agent_id: agent_id.to_string(),
            content: format!("warm content {id}"),
            tier: MemoryTier::Warm,
            embedding: Some(embedding),
            metadata: HashMap::new(),
            created_at: Instant::now(),
            last_accessed: Instant::now(),
            access_count: 0,
            pii_scanned: false,
        }
    }

    #[test]
    fn write_and_read_hot() {
        let gw = MemoryGateway::new(200);
        gw.write(make_entry("agent1", "m1", "hello"));
        gw.write(make_entry("agent1", "m2", "world"));

        let hot = gw.read_hot("agent1");
        assert_eq!(hot.len(), 2);
    }

    #[test]
    fn read_by_id() {
        let gw = MemoryGateway::new(200);
        gw.write(make_entry("agent1", "m1", "hello"));

        let entry = gw.read_by_id("agent1", "m1");
        assert!(entry.is_some());
        assert_eq!(entry.unwrap().content, "hello");

        assert!(gw.read_by_id("agent1", "nonexistent").is_none());
        assert!(gw.read_by_id("nonexistent", "m1").is_none());
    }

    #[test]
    fn auto_triage_when_hot_full() {
        let gw = MemoryGateway::new(3); // Max 3 hot items
        for i in 0..5 {
            gw.write(make_entry(
                "agent1",
                &format!("m{i}"),
                &format!("content {i}"),
            ));
        }

        let stats = gw.stats("agent1");
        // Hot should be at most 3, rest triaged to warm
        assert!(stats.hot_count <= 3);
        assert_eq!(stats.total_count, 5);
    }

    #[test]
    fn cross_agent_isolation_default() {
        let gw = MemoryGateway::new(200);
        gw.write(make_entry("agent1", "m1", "secret"));

        // Default sharing = None, so cross-agent access should fail
        let result = gw.search_cross_agent("agent2", "agent1", &[1.0, 0.0], 0.5, 10);
        assert!(matches!(result, Err(MemoryAccessDenied::NotShared)));
    }

    #[test]
    fn cross_agent_allow_list() {
        let gw = MemoryGateway::new(200);
        gw.write(make_entry("agent1", "m1", "shared data"));
        gw.set_sharing_rule("agent1", SharingRule::AllowList(vec!["agent2".to_string()]));

        // agent2 is allowed
        let result = gw.search_cross_agent("agent2", "agent1", &[1.0, 0.0], 0.0, 10);
        assert!(result.is_ok());

        // agent3 is NOT allowed
        let result = gw.search_cross_agent("agent3", "agent1", &[1.0, 0.0], 0.0, 10);
        assert!(matches!(result, Err(MemoryAccessDenied::NotInAllowList)));
    }

    #[test]
    fn cross_agent_open_sharing() {
        let gw = MemoryGateway::new(200);
        gw.write(make_entry("agent1", "m1", "open data"));
        gw.set_sharing_rule("agent1", SharingRule::Open);

        let result = gw.search_cross_agent("anyone", "agent1", &[1.0, 0.0], 0.0, 10);
        assert!(result.is_ok());
    }

    #[test]
    fn warm_tier_search() {
        let gw = MemoryGateway::new(200);

        // Write directly to warm tier via store manipulation
        // (In production, entries are triaged from hot -> warm)
        let mut entry = make_warm_entry("agent1", "w1", vec![1.0, 0.0, 0.0]);
        entry.tier = MemoryTier::Hot; // write() puts in hot
        gw.write(entry);

        // Manually insert warm entry for search
        {
            let mut store = gw
                .stores
                .entry("agent1".to_string())
                .or_insert_with(|| AgentMemoryStore::new(200));
            store
                .warm
                .push(make_warm_entry("agent1", "w2", vec![0.9, 0.1, 0.0]));
            store
                .warm
                .push(make_warm_entry("agent1", "w3", vec![0.0, 1.0, 0.0]));
        }

        let results = gw.search("agent1", &[1.0, 0.0, 0.0], 0.8, 10);
        // w2 should match (high similarity to [1,0,0]), w3 should not (orthogonal)
        assert!(!results.is_empty());
        assert_eq!(results[0].0.id, "w2");
    }

    #[test]
    fn delete_agent() {
        let gw = MemoryGateway::new(200);
        gw.write(make_entry("agent1", "m1", "data"));
        assert_eq!(gw.agent_count(), 1);

        assert!(gw.delete_agent("agent1"));
        assert_eq!(gw.agent_count(), 0);
        assert!(!gw.delete_agent("nonexistent"));
    }

    #[test]
    fn global_stats() {
        let gw = MemoryGateway::new(200);
        gw.write(make_entry("agent1", "m1", "a"));
        gw.write(make_entry("agent2", "m2", "b"));
        gw.read_hot("agent1");
        gw.search("agent1", &[1.0], 0.5, 10);

        let stats = gw.global_stats();
        assert_eq!(stats.total_agents, 2);
        assert_eq!(stats.total_writes, 2);
        assert_eq!(stats.total_reads, 1);
        assert_eq!(stats.total_searches, 1);
    }

    #[test]
    fn same_agent_cross_search_always_allowed() {
        let gw = MemoryGateway::new(200);
        gw.write(make_entry("agent1", "m1", "self data"));
        // Even with sharing=None, same agent can always access own memories
        let result = gw.search_cross_agent("agent1", "agent1", &[1.0], 0.0, 10);
        assert!(result.is_ok());
    }
}
