// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! # Routing Strategies
//!
//! Trait-based routing with pluggable strategies. Each strategy maintains its
//! own state and selection algorithm. `Box<dyn RoutingStrategy>` is selected by
//! config at startup.
//!
//! The existing [`ThompsonRouter`] implements this trait as `ThompsonStrategy`.

use std::sync::Arc;
use std::time::{Duration, Instant};

use parking_lot::Mutex;
use rand::Rng;

/// A routing strategy selects a provider from a set of candidates.
///
/// Implementations must be thread-safe (`Send + Sync`).
pub trait RoutingStrategy: Send + Sync {
    /// Select a provider from the given candidates.
    ///
    /// `key` is an optional routing key (e.g., tenant_id, session_id) for
    /// strategies that support sticky routing (consistent hashing).
    fn select(&self, candidates: &[&str], key: Option<&str>) -> Option<String>;

    /// Record a successful request to a provider.
    fn record_success(&self, provider: &str, latency: Duration);

    /// Record a failed request to a provider.
    fn record_failure(&self, provider: &str);

    /// Strategy name for config/logging.
    fn name(&self) -> &str;
}

// ---------------------------------------------------------------------------
// Peak EWMA
// ---------------------------------------------------------------------------

struct EwmaState {
    load: f64,
    last_update: Instant,
    active: u32,
}

/// Peak EWMA (Exponentially Weighted Moving Average) routing.
///
/// `load = ewma_latency * active_requests`. Select provider with lowest load.
/// Decay: `e^(-elapsed / half_life)`. Providers with zero samples get a
/// configurable penalty multiplier to encourage exploration.
pub struct PeakEwmaStrategy {
    half_life: Duration,
    zero_penalty_multiplier: f64,
    states: Mutex<std::collections::HashMap<String, EwmaState>>,
}

impl PeakEwmaStrategy {
    pub fn new(half_life: Duration, zero_penalty_multiplier: f64) -> Self {
        Self {
            half_life,
            zero_penalty_multiplier,
            states: Mutex::new(std::collections::HashMap::new()),
        }
    }

    fn decay_factor(&self, elapsed: Duration) -> f64 {
        let t = elapsed.as_secs_f64();
        let hl = self.half_life.as_secs_f64();
        if hl <= 0.0 {
            return 0.0;
        }
        (-t * std::f64::consts::LN_2 / hl).exp()
    }
}

impl RoutingStrategy for PeakEwmaStrategy {
    fn select(&self, candidates: &[&str], _key: Option<&str>) -> Option<String> {
        if candidates.is_empty() {
            return None;
        }

        let mut states = self.states.lock();
        let now = Instant::now();

        // Check if all providers have zero samples
        let all_zero = candidates.iter().all(|c| !states.contains_key(*c));
        if all_zero {
            // Random fallback when all are zero
            let idx = rand::thread_rng().gen_range(0..candidates.len());
            return Some(candidates[idx].to_string());
        }

        let mut best: Option<(String, f64)> = None;

        for &candidate in candidates {
            let load = match states.get(candidate) {
                Some(state) => {
                    let elapsed = now.duration_since(state.last_update);
                    let decay = self.decay_factor(elapsed);
                    let ewma = state.load * decay;
                    ewma * (state.active as f64 + 1.0) // +1 for the request being routed
                }
                None => {
                    // No data — apply penalty to encourage exploration
                    self.zero_penalty_multiplier
                }
            };

            let is_better = match &best {
                None => true,
                Some((_, best_load)) => load < *best_load,
            };
            if is_better {
                best = Some((candidate.to_string(), load));
            }
        }

        // Increment active count for the selected provider.
        // Contract: every select() MUST be followed by exactly one
        // record_success() or record_failure() to decrement.
        if let Some((ref id, _)) = best {
            if let Some(state) = states.get_mut(id.as_str()) {
                state.active += 1;
            }
        }

        best.map(|(id, _)| id)
    }

    fn record_success(&self, provider: &str, latency: Duration) {
        let mut states = self.states.lock();
        let now = Instant::now();
        let latency_ms = latency.as_secs_f64() * 1000.0;

        let state = states
            .entry(provider.to_string())
            .or_insert_with(|| EwmaState {
                load: 0.0,
                last_update: now,
                active: 0,
            });

        let elapsed = now.duration_since(state.last_update);
        let decay = self.decay_factor(elapsed);
        // EWMA update: new_load = old_load * decay + latency_ms * (1 - decay)
        state.load = state.load * decay + latency_ms * (1.0 - decay);
        state.last_update = now;
        state.active = state.active.saturating_sub(1);
    }

    fn record_failure(&self, provider: &str) {
        let mut states = self.states.lock();
        if let Some(state) = states.get_mut(provider) {
            state.active = state.active.saturating_sub(1);
            // Increase load on failure to steer traffic away
            state.load *= 2.0;
            state.last_update = Instant::now();
        }
    }

    fn name(&self) -> &str {
        "peak_ewma"
    }
}

// ---------------------------------------------------------------------------
// Consistent Hash
// ---------------------------------------------------------------------------

/// Consistent hashing for sticky routing.
///
/// Uses jump hash (O(ln n), zero allocation) for deterministic placement.
/// `key=None` falls back to random selection (documented + tested).
///
/// Note: Jump hash does not use virtual nodes — the `new()` parameter is
/// accepted for config compatibility but unused.
pub struct ConsistentHashStrategy;

impl ConsistentHashStrategy {
    pub fn new(_virtual_nodes: usize) -> Self {
        Self
    }

    /// Jump hash algorithm — O(ln(n)), no memory allocation.
    fn jump_hash(key: u64, num_buckets: usize) -> usize {
        if num_buckets == 0 {
            return 0;
        }
        let mut b: i64 = -1;
        let mut j: i64 = 0;
        let mut key = key;
        while j < num_buckets as i64 {
            b = j;
            key = key.wrapping_mul(2862933555777941757).wrapping_add(1);
            j = ((b + 1) as f64 * (1i64 << 31) as f64 / ((key >> 33) as i64 + 1) as f64) as i64;
        }
        b as usize
    }

    fn hash_key(key: &str) -> u64 {
        // FNV-1a hash for simplicity
        let mut hash: u64 = 14695981039346656037;
        for byte in key.bytes() {
            hash ^= byte as u64;
            hash = hash.wrapping_mul(1099511628211);
        }
        hash
    }
}

impl RoutingStrategy for ConsistentHashStrategy {
    fn select(&self, candidates: &[&str], key: Option<&str>) -> Option<String> {
        if candidates.is_empty() {
            return None;
        }

        match key {
            Some(k) => {
                let hash = Self::hash_key(k);
                let idx = Self::jump_hash(hash, candidates.len());
                Some(candidates[idx].to_string())
            }
            None => {
                // No key — random fallback (documented behavior)
                let idx = rand::thread_rng().gen_range(0..candidates.len());
                Some(candidates[idx].to_string())
            }
        }
    }

    fn record_success(&self, _provider: &str, _latency: Duration) {
        // Consistent hashing doesn't use latency data
    }

    fn record_failure(&self, _provider: &str) {
        // Consistent hashing doesn't react to failures
    }

    fn name(&self) -> &str {
        "consistent_hash"
    }
}

// ---------------------------------------------------------------------------
// Weighted Round Robin
// ---------------------------------------------------------------------------

struct WrrState {
    weights: Vec<f64>,
    /// Smooth WRR accumulator (Nginx algorithm). Each entry tracks the
    /// "current weight" that is incremented by the effective weight on each
    /// round and decremented by the total weight when selected.
    current_weights: Vec<f64>,
}

/// Weighted Round Robin with dynamic weights.
///
/// Uses the smooth WRR algorithm (Nginx): on each selection, every candidate's
/// current_weight is incremented by its effective weight, the candidate with
/// the highest current_weight is selected, and its current_weight is decremented
/// by the sum of all weights. This produces an interleaved distribution that
/// matches the weight ratios.
///
/// Weights are derived from success rate and inverse latency. Higher success
/// rate and lower latency → higher weight.
pub struct WeightedRoundRobinStrategy {
    state: Mutex<WrrState>,
    success_counts: Mutex<std::collections::HashMap<String, (u64, u64)>>, // (success, total)
    latencies: Mutex<std::collections::HashMap<String, f64>>,
}

impl WeightedRoundRobinStrategy {
    pub fn new(num_providers: usize) -> Self {
        Self {
            state: Mutex::new(WrrState {
                weights: vec![1.0; num_providers],
                current_weights: vec![0.0; num_providers],
            }),
            success_counts: Mutex::new(std::collections::HashMap::new()),
            latencies: Mutex::new(std::collections::HashMap::new()),
        }
    }
}

impl RoutingStrategy for WeightedRoundRobinStrategy {
    fn select(&self, candidates: &[&str], _key: Option<&str>) -> Option<String> {
        if candidates.is_empty() {
            return None;
        }

        // Snapshot metrics data (short-lived locks, released before state lock)
        let weights: Vec<f64> = {
            let success = self.success_counts.lock();
            let latencies = self.latencies.lock();
            candidates
                .iter()
                .map(|&c| {
                    let success_rate = success
                        .get(c)
                        .map(|(s, t)| if *t > 0 { *s as f64 / *t as f64 } else { 1.0 })
                        .unwrap_or(1.0);
                    let inv_latency = latencies
                        .get(c)
                        .map(|l| if *l > 0.0 { 1000.0 / l } else { 1.0 })
                        .unwrap_or(1.0);
                    success_rate * inv_latency
                })
                .collect()
        };

        let mut state = self.state.lock();

        // Reset accumulators if candidate set changed
        if state.weights.len() != candidates.len() {
            state.current_weights = vec![0.0; candidates.len()];
        }
        state.current_weights.resize(candidates.len(), 0.0);
        state.weights = weights;

        let total: f64 = state.weights.iter().sum();
        if total <= 0.0 {
            return Some(candidates[0].to_string());
        }

        // Smooth WRR (Nginx algorithm):
        // 1. Add effective weight to each current_weight
        // 2. Pick highest current_weight
        // 3. Subtract total from winner
        let mut best_idx = 0;
        let mut best_cw = f64::NEG_INFINITY;
        for i in 0..candidates.len() {
            state.current_weights[i] += state.weights[i];
            if state.current_weights[i] > best_cw {
                best_cw = state.current_weights[i];
                best_idx = i;
            }
        }
        state.current_weights[best_idx] -= total;

        Some(candidates[best_idx].to_string())
    }

    fn record_success(&self, provider: &str, latency: Duration) {
        let mut counts = self.success_counts.lock();
        let entry = counts.entry(provider.to_string()).or_insert((0, 0));
        entry.0 += 1;
        entry.1 += 1;

        let mut latencies = self.latencies.lock();
        let lat = latency.as_secs_f64() * 1000.0;
        let entry = latencies.entry(provider.to_string()).or_insert(lat);
        // EWMA latency
        *entry = *entry * 0.8 + lat * 0.2;
    }

    fn record_failure(&self, provider: &str) {
        let mut counts = self.success_counts.lock();
        let entry = counts.entry(provider.to_string()).or_insert((0, 0));
        entry.1 += 1;
    }

    fn name(&self) -> &str {
        "weighted_round_robin"
    }
}

// ---------------------------------------------------------------------------
// Least Loaded
// ---------------------------------------------------------------------------

/// Least Loaded routing — selects the provider with fewest active requests.
pub struct LeastLoadedStrategy {
    active: Arc<Mutex<std::collections::HashMap<String, u32>>>,
}

impl LeastLoadedStrategy {
    pub fn new() -> Self {
        Self {
            active: Arc::new(Mutex::new(std::collections::HashMap::new())),
        }
    }

    /// Increment active count for a provider. Returns an RAII guard that
    /// decrements on drop.
    pub fn track_request(&self, provider: &str) -> LeastLoadedGuard {
        let mut active = self.active.lock();
        *active.entry(provider.to_string()).or_insert(0) += 1;
        LeastLoadedGuard {
            provider: provider.to_string(),
            active: self.active.clone(),
        }
    }
}

/// RAII guard that decrements active count on drop.
pub struct LeastLoadedGuard {
    provider: String,
    active: Arc<Mutex<std::collections::HashMap<String, u32>>>,
}

impl Drop for LeastLoadedGuard {
    fn drop(&mut self) {
        let mut active = self.active.lock();
        if let Some(count) = active.get_mut(&self.provider) {
            *count = count.saturating_sub(1);
        }
    }
}

impl Default for LeastLoadedStrategy {
    fn default() -> Self {
        Self::new()
    }
}

impl RoutingStrategy for LeastLoadedStrategy {
    fn select(&self, candidates: &[&str], _key: Option<&str>) -> Option<String> {
        if candidates.is_empty() {
            return None;
        }

        let active = self.active.lock();
        let mut best: Option<(String, u32)> = None;

        for &candidate in candidates {
            let count = active.get(candidate).copied().unwrap_or(0);

            let is_better = match &best {
                None => true,
                Some((_, best_count)) => count < *best_count,
            };
            if is_better {
                best = Some((candidate.to_string(), count));
            }
        }

        best.map(|(id, _)| id)
    }

    fn record_success(&self, _provider: &str, _latency: Duration) {
        // Active count managed by LeastLoadedGuard
    }

    fn record_failure(&self, _provider: &str) {
        // Active count managed by LeastLoadedGuard
    }

    fn name(&self) -> &str {
        "least_loaded"
    }
}

// ---------------------------------------------------------------------------
// Strategy factory
// ---------------------------------------------------------------------------

/// Routing strategy names for configuration.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[cfg_attr(feature = "serde", serde(rename_all = "snake_case"))]
pub enum StrategyKind {
    #[default]
    Thompson,
    PeakEwma,
    ConsistentHash,
    WeightedRoundRobin,
    LeastLoaded,
}

/// Configuration for routing strategy selection.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct RoutingConfig {
    pub strategy: StrategyKind,
    #[cfg_attr(feature = "serde", serde(default = "default_ewma_half_life"))]
    pub ewma_half_life_secs: f64,
    #[cfg_attr(feature = "serde", serde(default = "default_zero_penalty"))]
    pub ewma_zero_penalty_multiplier: f64,
    #[cfg_attr(feature = "serde", serde(default = "default_virtual_nodes"))]
    pub hash_virtual_nodes: usize,
}

fn default_ewma_half_life() -> f64 {
    10.0
}
fn default_zero_penalty() -> f64 {
    5.0
}
fn default_virtual_nodes() -> usize {
    150
}

impl Default for RoutingConfig {
    fn default() -> Self {
        Self {
            strategy: StrategyKind::default(),
            ewma_half_life_secs: default_ewma_half_life(),
            ewma_zero_penalty_multiplier: default_zero_penalty(),
            hash_virtual_nodes: default_virtual_nodes(),
        }
    }
}

/// Create a routing strategy from configuration.
///
/// Note: `Thompson` returns `None` — the existing `ThompsonRouter` is used
/// directly rather than through the trait, since it has a richer API.
pub fn create_strategy(config: &RoutingConfig) -> Option<Box<dyn RoutingStrategy>> {
    match config.strategy {
        StrategyKind::Thompson => None, // Use ThompsonRouter directly
        StrategyKind::PeakEwma => Some(Box::new(PeakEwmaStrategy::new(
            Duration::from_secs_f64(config.ewma_half_life_secs),
            config.ewma_zero_penalty_multiplier,
        ))),
        StrategyKind::ConsistentHash => Some(Box::new(ConsistentHashStrategy::new(
            config.hash_virtual_nodes,
        ))),
        StrategyKind::WeightedRoundRobin => Some(Box::new(WeightedRoundRobinStrategy::new(0))),
        StrategyKind::LeastLoaded => Some(Box::new(LeastLoadedStrategy::new())),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ewma_load_score() {
        let strategy = PeakEwmaStrategy::new(Duration::from_secs(10), 5.0);
        let candidates = vec!["a", "b"];

        // Record different latencies
        strategy.record_success("a", Duration::from_millis(100));
        strategy.record_success("b", Duration::from_millis(500));

        // Provider "a" should have lower load
        let selected = strategy.select(&candidates, None).unwrap();
        assert_eq!(selected, "a");
    }

    #[test]
    fn ewma_decay() {
        let strategy = PeakEwmaStrategy::new(Duration::from_millis(1), 5.0);
        strategy.record_success("a", Duration::from_millis(1000));

        // After decay, load should approach zero
        std::thread::sleep(std::time::Duration::from_millis(10));

        let factor = strategy.decay_factor(Duration::from_millis(10));
        assert!(factor < 0.01, "decay should be very small: {factor}");
    }

    #[test]
    fn ewma_configurable_penalty() {
        let strategy = PeakEwmaStrategy::new(Duration::from_secs(10), 100.0);
        let candidates = vec!["known", "unknown"];

        // Record low latency for "known"
        strategy.record_success("known", Duration::from_millis(10));

        // "unknown" gets penalty of 100.0, should not be selected
        let selected = strategy.select(&candidates, None).unwrap();
        assert_eq!(selected, "known");
    }

    #[test]
    fn ewma_all_zero_random() {
        let strategy = PeakEwmaStrategy::new(Duration::from_secs(10), 5.0);
        let candidates = vec!["a", "b", "c"];

        // No data for any provider — should return something (random)
        let selected = strategy.select(&candidates, None);
        assert!(selected.is_some());
        assert!(candidates.contains(&selected.as_deref().unwrap()));
    }

    #[test]
    fn hash_sticky() {
        let strategy = ConsistentHashStrategy::new(150);
        let candidates = vec!["a", "b", "c"];

        let r1 = strategy.select(&candidates, Some("user-123")).unwrap();
        let r2 = strategy.select(&candidates, Some("user-123")).unwrap();
        assert_eq!(r1, r2, "same key should route to same provider");
    }

    #[test]
    fn hash_rebalance() {
        let strategy = ConsistentHashStrategy::new(150);

        let three = vec!["a", "b", "c"];
        let two = vec!["a", "c"]; // "b" removed

        // Some keys that went to "a" or "c" should still go to the same place
        let mut stable = 0;
        for i in 0..100 {
            let key = format!("key-{i}");
            let r3 = strategy.select(&three, Some(&key)).unwrap();
            let r2 = strategy.select(&two, Some(&key)).unwrap();
            if r3 != "b" && r3 == r2 {
                stable += 1;
            }
        }
        // At least some keys should remain stable
        assert!(stable > 0, "expected some stable mappings after rebalance");
    }

    #[test]
    fn hash_no_key_fallback() {
        let strategy = ConsistentHashStrategy::new(150);
        let candidates = vec!["a", "b", "c"];

        // No key — random fallback
        let selected = strategy.select(&candidates, None);
        assert!(selected.is_some());
    }

    #[test]
    fn wrr_proportional() {
        let strategy = WeightedRoundRobinStrategy::new(3);
        let candidates = vec!["a", "b", "c"];

        // Select many times
        let mut counts = std::collections::HashMap::new();
        for _ in 0..30 {
            let selected = strategy.select(&candidates, None).unwrap();
            *counts.entry(selected).or_insert(0) += 1;
        }

        // With equal weights, each should get roughly 1/3
        for candidate in &candidates {
            assert!(
                counts.contains_key(*candidate),
                "expected {candidate} to be selected"
            );
        }
    }

    #[test]
    fn wrr_dynamic_weights() {
        let strategy = WeightedRoundRobinStrategy::new(2);

        // Record different success rates: "fast" has 100% success + low latency,
        // "slow" has 0% success rate
        for _ in 0..10 {
            strategy.record_success("fast", Duration::from_millis(50));
            strategy.record_failure("slow");
        }

        // Weights should heavily favor "fast" (100% success + low latency vs 0% success)
        let candidates = vec!["fast", "slow"];
        let mut fast_count = 0;
        for _ in 0..20 {
            let selected = strategy.select(&candidates, None).unwrap();
            if selected == "fast" {
                fast_count += 1;
            }
        }
        // "fast" should dominate selections (smooth WRR distributes proportionally)
        assert!(
            fast_count > 10,
            "expected 'fast' to be selected majority of times, got {fast_count}/20"
        );
    }

    #[test]
    fn least_loaded_idle() {
        let strategy = LeastLoadedStrategy::new();
        let candidates = vec!["a", "b", "c"];

        // All idle — should return first
        let selected = strategy.select(&candidates, None).unwrap();
        assert!(candidates.contains(&selected.as_str()));
    }

    #[test]
    fn least_loaded_concurrent() {
        let strategy = LeastLoadedStrategy::new();
        let candidates = vec!["busy", "idle"];

        // Make "busy" have active requests
        let _g1 = strategy.track_request("busy");
        let _g2 = strategy.track_request("busy");

        let selected = strategy.select(&candidates, None).unwrap();
        assert_eq!(selected, "idle");
    }

    #[test]
    fn config_selection() {
        let config = RoutingConfig {
            strategy: StrategyKind::PeakEwma,
            ..Default::default()
        };
        let strategy = create_strategy(&config);
        assert!(strategy.is_some());
        assert_eq!(strategy.unwrap().name(), "peak_ewma");

        let config = RoutingConfig {
            strategy: StrategyKind::Thompson,
            ..Default::default()
        };
        assert!(create_strategy(&config).is_none());
    }

    #[test]
    fn empty_candidates() {
        let strategy = PeakEwmaStrategy::new(Duration::from_secs(10), 5.0);
        assert!(strategy.select(&[], None).is_none());

        let strategy = ConsistentHashStrategy::new(150);
        assert!(strategy.select(&[], None).is_none());

        let strategy = LeastLoadedStrategy::new();
        assert!(strategy.select(&[], None).is_none());
    }
}
