// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Delegation Chain Verification (F12) — Delegation Chain Tokens (DCTs).
//!
//! Verifies chains of delegation tokens from a trusted root to a leaf subject,
//! enforcing capability attenuation (capabilities can only narrow, never widen),
//! chain continuity, depth limits, and expiry.
//!
//! Each [`DelegationToken`] grants a set of capabilities from an issuer to a
//! subject. Tokens are chained: a child token's `parent_token_hash` must equal
//! the SHA-256 hash of the parent's `token_id`, and the child's `issuer_did`
//! must match the parent's `subject_did`.

use std::collections::HashSet;
use std::sync::atomic::{AtomicU64, Ordering};

use dashmap::DashMap;
use sha2::{Digest, Sha256};

// ---------------------------------------------------------------------------
// Helper
// ---------------------------------------------------------------------------

/// Compute the SHA-256 hex digest of a token ID.
pub fn hash_token_id(token_id: &str) -> String {
    let mut hasher = Sha256::new();
    hasher.update(token_id.as_bytes());
    let result = hasher.finalize();
    hex::encode(result)
}

// ---------------------------------------------------------------------------
// Core types
// ---------------------------------------------------------------------------

/// A single delegation token granting capabilities from an issuer to a subject.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct DelegationToken {
    /// Unique identifier for this token.
    pub token_id: String,
    /// DID of the entity granting the delegation.
    pub issuer_did: String,
    /// DID of the entity receiving the delegation.
    pub subject_did: String,
    /// Set of allowed actions (e.g. "read", "write", "execute", "admin").
    pub capabilities: HashSet<String>,
    /// SHA-256 hash of the parent token's `token_id`. `None` for root tokens.
    pub parent_token_hash: Option<String>,
    /// Delegation depth (0 for root-issued tokens).
    pub depth: u32,
    /// Unix timestamp when the token was issued.
    pub issued_at: u64,
    /// Unix timestamp when the token expires.
    pub expires_at: u64,
    /// Hex-encoded signature (simplified — real implementation would use Ed25519).
    pub signature: String,
}

/// An ordered chain of delegation tokens from root to leaf.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct DelegationChain {
    /// Tokens ordered from root (index 0) to leaf (last index).
    pub tokens: Vec<DelegationToken>,
}

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------

/// Errors that can occur during delegation chain verification.
#[derive(Debug, thiserror::Error)]
pub enum DelegationError {
    #[error("delegation chain is empty")]
    EmptyChain,

    #[error("max depth exceeded: depth {depth} exceeds max {max}")]
    MaxDepthExceeded { depth: u32, max: u32 },

    #[error("untrusted root issuer: {issuer}")]
    UntrustedRoot { issuer: String },

    #[error("chain continuity broken at depth {at_depth}: expected parent hash {expected_hash}")]
    ContinuityBroken {
        at_depth: u32,
        expected_hash: String,
    },

    #[error("privilege escalation at depth {at_depth}: extra capabilities {extra_capabilities:?}")]
    PrivilegeEscalation {
        at_depth: u32,
        extra_capabilities: Vec<String>,
    },

    #[error("token {token_id} expired at {expired_at}")]
    Expired { token_id: String, expired_at: u64 },

    #[error(
        "subject-issuer mismatch at depth {at_depth}: expected issuer {expected_issuer}, got {actual_issuer}"
    )]
    SubjectIssuerMismatch {
        at_depth: u32,
        expected_issuer: String,
        actual_issuer: String,
    },

    #[error("invalid signature on token {token_id}")]
    InvalidSignature { token_id: String },
}

// ---------------------------------------------------------------------------
// Verified delegation result
// ---------------------------------------------------------------------------

/// The result of a successful delegation chain verification.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct VerifiedDelegation {
    /// DID of the leaf subject (the entity at the end of the chain).
    pub subject_did: String,
    /// Effective capabilities — the leaf token's capabilities (already verified
    /// as a subset of all ancestors).
    pub effective_capabilities: HashSet<String>,
    /// Depth of the delegation chain.
    pub chain_depth: u32,
    /// DID of the root issuer.
    pub root_issuer: String,
    /// Minimum expiry across all tokens in the chain.
    pub expires_at: u64,
}

// ---------------------------------------------------------------------------
// Verifier
// ---------------------------------------------------------------------------

/// Stateless delegation chain verifier.
///
/// Validates that a [`DelegationChain`] is well-formed, rooted at a trusted
/// issuer, and respects capability attenuation at every link.
pub struct DelegationChainVerifier {
    /// Maximum allowed delegation depth.
    pub max_depth: u32,
    /// Set of trusted root DIDs.
    pub trusted_roots: HashSet<String>,
}

impl DelegationChainVerifier {
    /// Create a new verifier with the given max depth and trusted roots.
    pub fn new(max_depth: u32, trusted_roots: HashSet<String>) -> Self {
        Self {
            max_depth,
            trusted_roots,
        }
    }

    /// Verify a delegation chain against the current time.
    ///
    /// Verification steps (in order):
    /// 1. Chain must not be empty.
    /// 2. Root token issuer must be in `trusted_roots`.
    /// 3. For each token in the chain:
    ///    - Not expired (`expires_at > current_time`).
    ///    - Depth matches position in chain.
    ///    - Depth does not exceed `max_depth`.
    ///    - Signature is non-empty (simplified verification).
    ///    - If not root: `parent_token_hash` matches SHA-256 of previous `token_id`.
    ///    - If not root: `issuer_did` == previous token's `subject_did`.
    ///    - If not root: capabilities are a subset of parent capabilities (attenuation).
    /// 4. Returns [`VerifiedDelegation`] with the leaf token's capabilities.
    pub fn verify(
        &self,
        chain: &DelegationChain,
        current_time: u64,
    ) -> Result<VerifiedDelegation, DelegationError> {
        // 1. Chain must not be empty.
        if chain.tokens.is_empty() {
            return Err(DelegationError::EmptyChain);
        }

        // 2. Root token issuer must be trusted.
        let root = &chain.tokens[0];
        if !self.trusted_roots.contains(&root.issuer_did) {
            return Err(DelegationError::UntrustedRoot {
                issuer: root.issuer_did.clone(),
            });
        }

        let mut min_expires_at = u64::MAX;

        // 3. Validate each token.
        for (i, token) in chain.tokens.iter().enumerate() {
            let expected_depth = i as u32;

            // Check expiry.
            if token.expires_at <= current_time {
                return Err(DelegationError::Expired {
                    token_id: token.token_id.clone(),
                    expired_at: token.expires_at,
                });
            }

            // Track minimum expiry.
            if token.expires_at < min_expires_at {
                min_expires_at = token.expires_at;
            }

            // Check depth matches position.
            if token.depth != expected_depth {
                return Err(DelegationError::MaxDepthExceeded {
                    depth: token.depth,
                    max: self.max_depth,
                });
            }

            // Check depth does not exceed max.
            if token.depth > self.max_depth {
                return Err(DelegationError::MaxDepthExceeded {
                    depth: token.depth,
                    max: self.max_depth,
                });
            }

            // Check signature is non-empty (simplified verification).
            if token.signature.is_empty() {
                return Err(DelegationError::InvalidSignature {
                    token_id: token.token_id.clone(),
                });
            }

            // For non-root tokens, verify chain linkage.
            if i > 0 {
                let parent = &chain.tokens[i - 1];

                // Check parent_token_hash matches SHA-256 of parent's token_id.
                let expected_hash = hash_token_id(&parent.token_id);
                match &token.parent_token_hash {
                    Some(hash) if hash == &expected_hash => {}
                    _ => {
                        return Err(DelegationError::ContinuityBroken {
                            at_depth: expected_depth,
                            expected_hash,
                        });
                    }
                }

                // Check issuer_did == parent's subject_did (continuity).
                if token.issuer_did != parent.subject_did {
                    return Err(DelegationError::SubjectIssuerMismatch {
                        at_depth: expected_depth,
                        expected_issuer: parent.subject_did.clone(),
                        actual_issuer: token.issuer_did.clone(),
                    });
                }

                // Check capability attenuation: child ⊆ parent.
                let extra: Vec<String> = token
                    .capabilities
                    .difference(&parent.capabilities)
                    .cloned()
                    .collect();
                if !extra.is_empty() {
                    return Err(DelegationError::PrivilegeEscalation {
                        at_depth: expected_depth,
                        extra_capabilities: extra,
                    });
                }
            }
        }

        // 4. Build the verified delegation from the leaf token.
        // Safety: chain.tokens is non-empty (checked at step 1).
        let leaf = match chain.tokens.last() {
            Some(token) => token,
            None => return Err(DelegationError::EmptyChain),
        };
        Ok(VerifiedDelegation {
            subject_did: leaf.subject_did.clone(),
            effective_capabilities: leaf.capabilities.clone(),
            chain_depth: leaf.depth,
            root_issuer: root.issuer_did.clone(),
            expires_at: min_expires_at,
        })
    }
}

impl Default for DelegationChainVerifier {
    fn default() -> Self {
        Self {
            max_depth: 10,
            trusted_roots: HashSet::new(),
        }
    }
}

// ---------------------------------------------------------------------------
// Registry
// ---------------------------------------------------------------------------

/// Statistics for the delegation registry.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct DelegationStats {
    /// Number of currently active (registered) delegations.
    pub active_delegations: usize,
    /// Total number of successfully verified chains.
    pub total_verified: u64,
    /// Total number of rejected chains.
    pub total_rejected: u64,
}

/// Registry that tracks active delegation chains.
///
/// Chains are keyed by the leaf `subject_did`. Registration verifies the chain
/// before storing it.
pub struct DelegationRegistry {
    /// Active delegation chains, keyed by leaf subject DID.
    delegations: DashMap<String, DelegationChain>,
    /// The verifier used for chain validation.
    verifier: DelegationChainVerifier,
    /// Total number of successfully verified registrations.
    total_verified: AtomicU64,
    /// Total number of rejected registrations.
    total_rejected: AtomicU64,
}

impl DelegationRegistry {
    /// Create a new registry with the given verifier.
    pub fn new(verifier: DelegationChainVerifier) -> Self {
        Self {
            delegations: DashMap::new(),
            verifier,
            total_verified: AtomicU64::new(0),
            total_rejected: AtomicU64::new(0),
        }
    }

    /// Register a delegation chain for the given subject DID.
    ///
    /// The chain is verified first. On success, it is stored and the verified
    /// delegation is returned. On failure, the rejection counter is incremented.
    pub fn register_chain(
        &self,
        subject_did: String,
        chain: DelegationChain,
        current_time: u64,
    ) -> Result<VerifiedDelegation, DelegationError> {
        match self.verifier.verify(&chain, current_time) {
            Ok(verified) => {
                self.delegations.insert(subject_did, chain);
                self.total_verified.fetch_add(1, Ordering::Relaxed);
                Ok(verified)
            }
            Err(e) => {
                self.total_rejected.fetch_add(1, Ordering::Relaxed);
                Err(e)
            }
        }
    }

    /// Get the effective capabilities for a subject DID.
    ///
    /// Returns `None` if no delegation chain is registered for the subject.
    pub fn get_capabilities(&self, subject_did: &str) -> Option<HashSet<String>> {
        self.delegations.get(subject_did).map(|entry| {
            entry
                .value()
                .tokens
                .last()
                .map(|t| t.capabilities.clone())
                .unwrap_or_default()
        })
    }

    /// Revoke a delegation chain for the given subject DID.
    ///
    /// Returns `true` if a chain was removed, `false` if none existed.
    pub fn revoke(&self, subject_did: &str) -> bool {
        self.delegations.remove(subject_did).is_some()
    }

    /// Get registry statistics.
    pub fn stats(&self) -> DelegationStats {
        DelegationStats {
            active_delegations: self.delegations.len(),
            total_verified: self.total_verified.load(Ordering::Relaxed),
            total_rejected: self.total_rejected.load(Ordering::Relaxed),
        }
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    /// Helper: create a root delegation token.
    fn make_root_token(
        token_id: &str,
        issuer: &str,
        subject: &str,
        capabilities: &[&str],
        expires_at: u64,
    ) -> DelegationToken {
        DelegationToken {
            token_id: token_id.to_string(),
            issuer_did: issuer.to_string(),
            subject_did: subject.to_string(),
            capabilities: capabilities.iter().map(|c| c.to_string()).collect(),
            parent_token_hash: None,
            depth: 0,
            issued_at: 1000,
            expires_at,
            signature: "root-sig-placeholder".to_string(),
        }
    }

    /// Helper: create a child delegation token linked to a parent.
    fn make_child_token(
        token_id: &str,
        parent_token_id: &str,
        issuer: &str,
        subject: &str,
        capabilities: &[&str],
        depth: u32,
        expires_at: u64,
    ) -> DelegationToken {
        DelegationToken {
            token_id: token_id.to_string(),
            issuer_did: issuer.to_string(),
            subject_did: subject.to_string(),
            capabilities: capabilities.iter().map(|c| c.to_string()).collect(),
            parent_token_hash: Some(hash_token_id(parent_token_id)),
            depth,
            issued_at: 1000,
            expires_at,
            signature: "child-sig-placeholder".to_string(),
        }
    }

    /// Helper: create a verifier with a single trusted root.
    fn make_verifier(trusted_root: &str, max_depth: u32) -> DelegationChainVerifier {
        let mut roots = HashSet::new();
        roots.insert(trusted_root.to_string());
        DelegationChainVerifier::new(max_depth, roots)
    }

    #[test]
    fn valid_single_token_root_chain() {
        let verifier = make_verifier("did:key:root-authority", 10);
        let chain = DelegationChain {
            tokens: vec![make_root_token(
                "tok-root-1",
                "did:key:root-authority",
                "did:key:agent-1",
                &["read", "write"],
                5000,
            )],
        };

        let result = verifier.verify(&chain, 2000).unwrap();
        assert_eq!(result.subject_did, "did:key:agent-1");
        assert_eq!(result.chain_depth, 0);
        assert_eq!(result.root_issuer, "did:key:root-authority");
        assert_eq!(result.expires_at, 5000);
        assert!(result.effective_capabilities.contains("read"));
        assert!(result.effective_capabilities.contains("write"));
        assert_eq!(result.effective_capabilities.len(), 2);
    }

    #[test]
    fn valid_multi_level_delegation_chain() {
        let verifier = make_verifier("did:key:root", 10);

        let root = make_root_token(
            "tok-root",
            "did:key:root",
            "did:key:level-1",
            &["read", "write", "execute"],
            5000,
        );
        let level1 = make_child_token(
            "tok-level1",
            "tok-root",
            "did:key:level-1",
            "did:key:level-2",
            &["read", "write"],
            1,
            4000,
        );
        let level2 = make_child_token(
            "tok-level2",
            "tok-level1",
            "did:key:level-2",
            "did:key:level-3",
            &["read"],
            2,
            3000,
        );

        let chain = DelegationChain {
            tokens: vec![root, level1, level2],
        };

        let result = verifier.verify(&chain, 2000).unwrap();
        assert_eq!(result.subject_did, "did:key:level-3");
        assert_eq!(result.chain_depth, 2);
        assert_eq!(result.root_issuer, "did:key:root");
        // Minimum expiry across the chain.
        assert_eq!(result.expires_at, 3000);
        // Only "read" remains after attenuation.
        assert_eq!(result.effective_capabilities.len(), 1);
        assert!(result.effective_capabilities.contains("read"));
    }

    #[test]
    fn untrusted_root_rejected() {
        let verifier = make_verifier("did:key:trusted-root", 10);
        let chain = DelegationChain {
            tokens: vec![make_root_token(
                "tok-1",
                "did:key:untrusted-entity",
                "did:key:agent-1",
                &["read"],
                5000,
            )],
        };

        let err = verifier.verify(&chain, 2000).unwrap_err();
        assert!(
            matches!(err, DelegationError::UntrustedRoot { ref issuer } if issuer == "did:key:untrusted-entity")
        );
    }

    #[test]
    fn expired_token_rejected() {
        let verifier = make_verifier("did:key:root", 10);
        let chain = DelegationChain {
            tokens: vec![make_root_token(
                "tok-expired",
                "did:key:root",
                "did:key:agent-1",
                &["read"],
                1500, // expires at 1500
            )],
        };

        let err = verifier.verify(&chain, 2000).unwrap_err(); // current_time = 2000 > 1500
        assert!(
            matches!(err, DelegationError::Expired { ref token_id, expired_at } if token_id == "tok-expired" && expired_at == 1500)
        );
    }

    #[test]
    fn privilege_escalation_detected() {
        let verifier = make_verifier("did:key:root", 10);

        let root = make_root_token(
            "tok-root",
            "did:key:root",
            "did:key:level-1",
            &["read"],
            5000,
        );
        // Child claims "write" which the parent doesn't have.
        let child = make_child_token(
            "tok-child",
            "tok-root",
            "did:key:level-1",
            "did:key:level-2",
            &["read", "write"],
            1,
            5000,
        );

        let chain = DelegationChain {
            tokens: vec![root, child],
        };

        let err = verifier.verify(&chain, 2000).unwrap_err();
        match err {
            DelegationError::PrivilegeEscalation {
                at_depth,
                extra_capabilities,
            } => {
                assert_eq!(at_depth, 1);
                assert_eq!(extra_capabilities, vec!["write"]);
            }
            other => panic!("expected PrivilegeEscalation, got: {other:?}"),
        }
    }

    #[test]
    fn continuity_broken_wrong_parent_hash() {
        let verifier = make_verifier("did:key:root", 10);

        let root = make_root_token(
            "tok-root",
            "did:key:root",
            "did:key:level-1",
            &["read", "write"],
            5000,
        );
        // Child references wrong parent token ID in its hash.
        let mut child = make_child_token(
            "tok-child",
            "tok-root",
            "did:key:level-1",
            "did:key:level-2",
            &["read"],
            1,
            5000,
        );
        child.parent_token_hash = Some(hash_token_id("tok-WRONG-parent"));

        let chain = DelegationChain {
            tokens: vec![root, child],
        };

        let err = verifier.verify(&chain, 2000).unwrap_err();
        assert!(matches!(
            err,
            DelegationError::ContinuityBroken { at_depth: 1, .. }
        ));
    }

    #[test]
    fn subject_issuer_mismatch() {
        let verifier = make_verifier("did:key:root", 10);

        let root = make_root_token(
            "tok-root",
            "did:key:root",
            "did:key:level-1",
            &["read", "write"],
            5000,
        );
        // Child's issuer doesn't match parent's subject.
        let child = make_child_token(
            "tok-child",
            "tok-root",
            "did:key:WRONG-issuer",
            "did:key:level-2",
            &["read"],
            1,
            5000,
        );

        let chain = DelegationChain {
            tokens: vec![root, child],
        };

        let err = verifier.verify(&chain, 2000).unwrap_err();
        match err {
            DelegationError::SubjectIssuerMismatch {
                at_depth,
                expected_issuer,
                actual_issuer,
            } => {
                assert_eq!(at_depth, 1);
                assert_eq!(expected_issuer, "did:key:level-1");
                assert_eq!(actual_issuer, "did:key:WRONG-issuer");
            }
            other => panic!("expected SubjectIssuerMismatch, got: {other:?}"),
        }
    }

    #[test]
    fn max_depth_exceeded() {
        let verifier = make_verifier("did:key:root", 1); // max_depth = 1

        let root = make_root_token(
            "tok-root",
            "did:key:root",
            "did:key:level-1",
            &["read", "write"],
            5000,
        );
        let level1 = make_child_token(
            "tok-level1",
            "tok-root",
            "did:key:level-1",
            "did:key:level-2",
            &["read"],
            1,
            5000,
        );
        // Depth 2 exceeds max_depth of 1.
        let level2 = make_child_token(
            "tok-level2",
            "tok-level1",
            "did:key:level-2",
            "did:key:level-3",
            &["read"],
            2,
            5000,
        );

        let chain = DelegationChain {
            tokens: vec![root, level1, level2],
        };

        let err = verifier.verify(&chain, 2000).unwrap_err();
        assert!(matches!(
            err,
            DelegationError::MaxDepthExceeded { depth: 2, max: 1 }
        ));
    }

    #[test]
    fn empty_chain_rejected() {
        let verifier = make_verifier("did:key:root", 10);
        let chain = DelegationChain { tokens: vec![] };

        let err = verifier.verify(&chain, 2000).unwrap_err();
        assert!(matches!(err, DelegationError::EmptyChain));
    }

    #[test]
    fn registry_register_and_revoke() {
        let verifier = make_verifier("did:key:root", 10);
        let registry = DelegationRegistry::new(verifier);

        let chain = DelegationChain {
            tokens: vec![make_root_token(
                "tok-reg-1",
                "did:key:root",
                "did:key:agent-A",
                &["read", "write"],
                5000,
            )],
        };

        // Register succeeds.
        let verified = registry
            .register_chain("did:key:agent-A".to_string(), chain, 2000)
            .unwrap();
        assert_eq!(verified.subject_did, "did:key:agent-A");

        // Capabilities are retrievable.
        let caps = registry.get_capabilities("did:key:agent-A").unwrap();
        assert!(caps.contains("read"));
        assert!(caps.contains("write"));

        // Stats reflect one verified registration.
        let stats = registry.stats();
        assert_eq!(stats.active_delegations, 1);
        assert_eq!(stats.total_verified, 1);
        assert_eq!(stats.total_rejected, 0);

        // Revoke removes the chain.
        assert!(registry.revoke("did:key:agent-A"));
        assert!(registry.get_capabilities("did:key:agent-A").is_none());

        // Revoking again returns false.
        assert!(!registry.revoke("did:key:agent-A"));

        // Stats still reflect the previous verification.
        let stats = registry.stats();
        assert_eq!(stats.active_delegations, 0);
        assert_eq!(stats.total_verified, 1);
    }

    #[test]
    fn registry_tracks_rejections() {
        let verifier = make_verifier("did:key:root", 10);
        let registry = DelegationRegistry::new(verifier);

        // Attempt to register an untrusted chain.
        let bad_chain = DelegationChain {
            tokens: vec![make_root_token(
                "tok-bad",
                "did:key:untrusted",
                "did:key:agent-B",
                &["read"],
                5000,
            )],
        };

        let err = registry
            .register_chain("did:key:agent-B".to_string(), bad_chain, 2000)
            .unwrap_err();
        assert!(matches!(err, DelegationError::UntrustedRoot { .. }));

        let stats = registry.stats();
        assert_eq!(stats.total_verified, 0);
        assert_eq!(stats.total_rejected, 1);
        assert_eq!(stats.active_delegations, 0);
    }

    #[test]
    fn hash_token_id_deterministic() {
        let hash1 = hash_token_id("tok-abc-123");
        let hash2 = hash_token_id("tok-abc-123");
        assert_eq!(hash1, hash2);

        // Different input produces different hash.
        let hash3 = hash_token_id("tok-xyz-456");
        assert_ne!(hash1, hash3);

        // SHA-256 produces 64 hex characters.
        assert_eq!(hash1.len(), 64);
    }

    #[test]
    fn invalid_signature_rejected() {
        let verifier = make_verifier("did:key:root", 10);

        let mut token = make_root_token(
            "tok-no-sig",
            "did:key:root",
            "did:key:agent-1",
            &["read"],
            5000,
        );
        token.signature = String::new(); // empty signature

        let chain = DelegationChain {
            tokens: vec![token],
        };

        let err = verifier.verify(&chain, 2000).unwrap_err();
        assert!(matches!(
            err,
            DelegationError::InvalidSignature { ref token_id } if token_id == "tok-no-sig"
        ));
    }

    #[test]
    fn verified_delegation_uses_minimum_expiry() {
        let verifier = make_verifier("did:key:root", 10);

        let root = make_root_token(
            "tok-root",
            "did:key:root",
            "did:key:level-1",
            &["read", "write", "execute"],
            8000, // expires later
        );
        let child = make_child_token(
            "tok-child",
            "tok-root",
            "did:key:level-1",
            "did:key:level-2",
            &["read"],
            1,
            3000, // expires sooner
        );

        let chain = DelegationChain {
            tokens: vec![root, child],
        };

        let result = verifier.verify(&chain, 2000).unwrap();
        assert_eq!(
            result.expires_at, 3000,
            "should use minimum expiry across chain"
        );
    }
}
