// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Retry policy with exponential backoff and jitter.

use std::time::Duration;

use rand::Rng;

/// Retry policy for failed provider requests.
///
/// Uses exponential backoff with configurable jitter:
/// `delay = min(base_delay * 2^attempt, max_delay) * (1 ± jitter_factor)`
#[derive(Debug, Clone)]
pub struct RetryPolicy {
    pub max_retries: u32,
    pub base_delay_ms: u64,
    pub max_delay_ms: u64,
    pub jitter_factor: f64,
}

impl Default for RetryPolicy {
    fn default() -> Self {
        Self {
            max_retries: 2,
            base_delay_ms: 500,
            max_delay_ms: 10_000,
            jitter_factor: 0.5,
        }
    }
}

impl RetryPolicy {
    /// Whether attempt `n` (0-indexed) should be retried.
    pub fn should_retry(&self, attempt: u32) -> bool {
        attempt < self.max_retries
    }

    /// Compute the delay before attempt `n` (0-indexed) using exponential
    /// backoff with jitter. Uses the thread-local RNG.
    pub fn delay_for_attempt(&self, attempt: u32) -> Duration {
        let mut rng = rand::thread_rng();
        self.delay_for_attempt_with_rng(attempt, &mut rng)
    }

    /// Deterministic variant for testing.
    pub fn delay_for_attempt_with_rng<R: Rng>(&self, attempt: u32, rng: &mut R) -> Duration {
        let exp_delay = self.base_delay_ms.saturating_mul(1u64 << attempt.min(20));
        let capped = exp_delay.min(self.max_delay_ms);
        let capped_f = capped as f64;

        // Jitter: uniform in [delay * (1 - jitter), delay * (1 + jitter)]
        let jitter = self.jitter_factor.clamp(0.0, 1.0);
        let lo = capped_f * (1.0 - jitter);
        let hi = capped_f * (1.0 + jitter);
        let jittered = rng.gen_range(lo..=hi);

        Duration::from_millis(jittered.round() as u64)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use rand::SeedableRng;

    fn seeded_rng() -> rand::rngs::StdRng {
        rand::rngs::StdRng::seed_from_u64(42)
    }

    #[test]
    fn default_values() {
        let p = RetryPolicy::default();
        assert_eq!(p.max_retries, 2);
        assert_eq!(p.base_delay_ms, 500);
        assert_eq!(p.max_delay_ms, 10_000);
        assert!((p.jitter_factor - 0.5).abs() < f64::EPSILON);
    }

    #[test]
    fn should_retry_logic() {
        let p = RetryPolicy {
            max_retries: 3,
            ..Default::default()
        };
        assert!(p.should_retry(0));
        assert!(p.should_retry(1));
        assert!(p.should_retry(2));
        assert!(!p.should_retry(3));
        assert!(!p.should_retry(4));
    }

    #[test]
    fn exponential_backoff_increases() {
        let p = RetryPolicy {
            jitter_factor: 0.0, // no jitter for deterministic test
            ..Default::default()
        };
        let mut rng = seeded_rng();
        let d0 = p.delay_for_attempt_with_rng(0, &mut rng);
        let d1 = p.delay_for_attempt_with_rng(1, &mut rng);
        let d2 = p.delay_for_attempt_with_rng(2, &mut rng);

        assert_eq!(d0.as_millis(), 500); // 500 * 2^0
        assert_eq!(d1.as_millis(), 1000); // 500 * 2^1
        assert_eq!(d2.as_millis(), 2000); // 500 * 2^2
    }

    #[test]
    fn max_delay_caps() {
        let p = RetryPolicy {
            base_delay_ms: 5000,
            max_delay_ms: 8000,
            jitter_factor: 0.0,
            ..Default::default()
        };
        let mut rng = seeded_rng();
        // 5000 * 2^1 = 10000, capped to 8000
        let d = p.delay_for_attempt_with_rng(1, &mut rng);
        assert_eq!(d.as_millis(), 8000);
    }

    #[test]
    fn jitter_within_bounds() {
        let p = RetryPolicy {
            base_delay_ms: 1000,
            max_delay_ms: 10_000,
            jitter_factor: 0.5,
            max_retries: 5,
        };
        let mut rng = seeded_rng();
        for attempt in 0..3 {
            for _ in 0..100 {
                let d = p.delay_for_attempt_with_rng(attempt, &mut rng);
                let exp = 1000u64.saturating_mul(1u64 << attempt).min(10_000);
                let lo = (exp as f64 * 0.5) as u128;
                let hi = (exp as f64 * 1.5).ceil() as u128;
                assert!(
                    d.as_millis() >= lo && d.as_millis() <= hi,
                    "attempt {attempt}: {d:?} not in [{lo}, {hi}]"
                );
            }
        }
    }

    #[test]
    fn large_attempt_no_overflow() {
        let p = RetryPolicy::default();
        let mut rng = seeded_rng();
        // Should not panic with large attempt numbers
        let d = p.delay_for_attempt_with_rng(30, &mut rng);
        // Should be capped to max_delay ± jitter
        assert!(d.as_millis() <= 15_000); // 10000 * 1.5
    }
}
