// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Zero-trust agent security (F19).
//!
//! Wraps `BehavioralAnalyzer` to make block / flag / allow decisions based on
//! per-agent behavioral anomaly detection.

use std::sync::Arc;

use crate::behavioral::{AnomalySeverity, BehavioralAnalyzer, BehavioralObservation};

/// Zero-trust action taken on a request.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ZeroTrustAction {
    /// Request allowed (no anomalies or within learning phase).
    Allow,
    /// Request flagged for review (moderate anomalies detected).
    Flag { anomalies: Vec<String> },
    /// Request blocked (high or critical anomalies detected).
    Block { reason: String },
}

/// Zero-trust evaluation engine.
pub struct ZeroTrustEngine {
    analyzer: Arc<BehavioralAnalyzer>,
}

impl ZeroTrustEngine {
    /// Create a new engine backed by the given shared analyzer.
    pub fn new(analyzer: Arc<BehavioralAnalyzer>) -> Self {
        Self { analyzer }
    }

    /// Evaluate a request. Returns the action to take.
    ///
    /// Decision priority (highest wins):
    /// 1. Any `Critical` anomaly → `Block`
    /// 2. Any `High` anomaly → `Block`
    /// 3. Any anomaly at all → `Flag`
    /// 4. No anomalies / learning phase → `Allow`
    pub fn evaluate(&self, obs: &BehavioralObservation) -> ZeroTrustAction {
        let anomalies = self.analyzer.check(obs);
        if anomalies.is_empty() {
            return ZeroTrustAction::Allow;
        }

        // Any Critical → Block
        if let Some(critical) = anomalies
            .iter()
            .find(|a| a.severity == AnomalySeverity::Critical)
        {
            return ZeroTrustAction::Block {
                reason: critical.description.clone(),
            };
        }

        // Any High → Block
        if let Some(high) = anomalies
            .iter()
            .find(|a| a.severity == AnomalySeverity::High)
        {
            return ZeroTrustAction::Block {
                reason: high.description.clone(),
            };
        }

        // Otherwise flag with all anomaly descriptions.
        ZeroTrustAction::Flag {
            anomalies: anomalies.iter().map(|a| a.description.clone()).collect(),
        }
    }

    /// Record an observation (updates baseline regardless of the action taken).
    pub fn observe(&self, obs: &BehavioralObservation) {
        self.analyzer.observe(obs);
    }

    /// Get the shared underlying analyzer.
    pub fn analyzer(&self) -> &Arc<BehavioralAnalyzer> {
        &self.analyzer
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::behavioral::BehavioralThresholds;

    fn make_engine(min_obs: u64) -> ZeroTrustEngine {
        let thresholds = BehavioralThresholds {
            min_observations: min_obs,
            rate_spike_multiplier: 5.0,
            token_spike_multiplier: 10.0,
        };
        let analyzer = Arc::new(BehavioralAnalyzer::new(thresholds));
        ZeroTrustEngine::new(analyzer)
    }

    fn make_obs(
        agent_id: &str,
        rps: f64,
        tokens: u64,
        tool: Option<&str>,
        hour: u8,
    ) -> BehavioralObservation {
        BehavioralObservation {
            agent_id: agent_id.to_string(),
            rps,
            tokens,
            tool_name: tool.map(|t| t.to_string()),
            hour,
        }
    }

    fn train_engine(
        engine: &ZeroTrustEngine,
        agent_id: &str,
        rps: f64,
        tokens: u64,
        tool: Option<&str>,
        hour: u8,
        n: usize,
    ) {
        for _ in 0..n {
            engine.observe(&make_obs(agent_id, rps, tokens, tool, hour));
        }
    }

    #[test]
    fn zero_trust_allows_during_learning_phase() {
        // min_observations = 100, but we only train 2 times → learning phase.
        let engine = make_engine(100);
        engine.observe(&make_obs("agent-zt-learn", 1.0, 100, Some("search"), 9));
        engine.observe(&make_obs("agent-zt-learn", 1.0, 100, Some("search"), 9));
        // Even a wild spike should be allowed during learning.
        let action = engine.evaluate(&make_obs(
            "agent-zt-learn",
            99999.0,
            999_999,
            Some("hack"),
            3,
        ));
        assert_eq!(
            action,
            ZeroTrustAction::Allow,
            "should allow during learning phase"
        );
    }

    #[test]
    fn zero_trust_blocks_critical() {
        // Use min_obs = 5 so we can reach the decision phase quickly.
        let engine = make_engine(5);
        train_engine(&engine, "agent-zt-crit", 1.0, 100, Some("search"), 9, 5);

        // 20x+ rate spike is Critical severity.
        let spike = make_obs("agent-zt-crit", 25.0, 100, Some("search"), 9);
        let action = engine.evaluate(&spike);
        assert!(
            matches!(action, ZeroTrustAction::Block { .. }),
            "20x+ rate spike should be blocked, got: {action:?}"
        );
    }

    #[test]
    fn zero_trust_flags_moderate() {
        let engine = make_engine(5);
        train_engine(&engine, "agent-zt-flag", 1.0, 100, Some("search"), 9, 5);

        // Unknown tool usage → Medium severity → Flag (not Block).
        let obs = make_obs("agent-zt-flag", 1.0, 100, Some("exfiltrate_data"), 9);
        let action = engine.evaluate(&obs);
        assert!(
            matches!(action, ZeroTrustAction::Flag { .. }),
            "unknown tool should be flagged, got: {action:?}"
        );
    }

    #[test]
    fn zero_trust_allows_normal_behavior() {
        let engine = make_engine(5);
        train_engine(&engine, "agent-zt-ok", 2.0, 200, Some("search"), 9, 5);

        // Normal behavior — no anomalies.
        let obs = make_obs("agent-zt-ok", 2.0, 200, Some("search"), 9);
        let action = engine.evaluate(&obs);
        assert_eq!(action, ZeroTrustAction::Allow);
    }

    #[test]
    fn observe_updates_baseline() {
        let engine = make_engine(1);
        engine.observe(&make_obs("agent-zt-baseline", 5.0, 500, Some("tool_a"), 10));

        let baseline = engine.analyzer().get_baseline("agent-zt-baseline");
        assert!(
            baseline.is_some(),
            "baseline should exist after observation"
        );
        let b = baseline.unwrap();
        assert_eq!(b.observations, 1);
        assert!((b.normal_rps - 5.0).abs() < 1e-6);
    }

    #[test]
    fn zero_trust_blocks_high_rate_spike() {
        // 10x–19x is High severity → Block.
        let engine = make_engine(5);
        train_engine(&engine, "agent-zt-high", 1.0, 100, Some("search"), 9, 5);

        // 12x spike → High → Block.
        let spike = make_obs("agent-zt-high", 12.0, 100, Some("search"), 9);
        let action = engine.evaluate(&spike);
        assert!(
            matches!(action, ZeroTrustAction::Block { .. }),
            "10x+ rate spike should block, got: {action:?}"
        );
    }

    #[test]
    fn zero_trust_off_hours_flags() {
        let engine = make_engine(5);
        // Train on hour 10 (business hours).
        train_engine(
            &engine,
            "agent-zt-offhours",
            1.0,
            100,
            Some("search"),
            10,
            5,
        );

        // Access at 2am — off-hours (Low severity → Flag, not Block).
        let obs = make_obs("agent-zt-offhours", 1.0, 100, Some("search"), 2);
        let action = engine.evaluate(&obs);
        assert!(
            matches!(action, ZeroTrustAction::Flag { .. }),
            "off-hours access should be flagged, got: {action:?}"
        );
    }
}
