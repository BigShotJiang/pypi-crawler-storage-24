// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

#![warn(clippy::unwrap_used)]

pub mod adaptive_guardrails;
pub mod audit;
pub mod behavioral;
pub mod budgets;
pub mod bulkhead;
pub mod cedar_policy;
pub mod circuit_breaker;
pub mod clock;
pub mod coherence;
pub mod degradation;
pub mod delegation;
pub mod economy;
pub mod edge;
pub mod error;
pub mod federation;
pub mod fraud;
pub mod governance;
pub mod guardrails;
pub mod hitl;
pub mod identity;
pub mod inference_router;
pub mod iot;
pub mod key_pool;
pub mod latency_budget;
pub mod memory;
pub mod openapi_to_mcp;
pub mod quality;
pub mod rate_limiter;
pub mod retry;
pub mod retry_budget;
pub mod routing;
pub mod saga;
pub mod semantic_cache;
pub mod sla;
pub mod streaming;
pub mod thompson;
pub mod timeout;
pub mod tool_chain;
pub mod tool_permissions;
pub mod verification;
pub mod workflow_budget;
pub mod zero_trust;

pub use clock::{Clock, ManualClock, MonotonicClock};
pub use error::{ProxyError, Result};
