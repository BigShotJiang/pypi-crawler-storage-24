// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! # Verification Service (F27)
//!
//! Property verification for agent workflow graphs. Checks structural
//! properties — deadlock freedom, liveness, safety, and bounded liveness —
//! on directed graphs that represent agent workflows.
//!
//! The full WASM-based verification integration comes later; this module
//! provides the core graph algorithms.

use std::collections::{HashMap, HashSet, VecDeque};

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

// ---------------------------------------------------------------------------
// Verification properties
// ---------------------------------------------------------------------------

/// A property that can be checked against a workflow graph.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum VerificationProperty {
    /// No cycles in required-before relationships (i.e. the graph is a DAG).
    Deadlock,
    /// All states can reach an accepting state.
    Liveness,
    /// No invalid state transitions (all edges reference valid nodes).
    Safety,
    /// An accepting state is reachable within `max_steps` transitions.
    BoundedLiveness { max_steps: u32 },
}

// ---------------------------------------------------------------------------
// Graph definition
// ---------------------------------------------------------------------------

/// A single node in the workflow graph.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct GraphNode {
    /// Unique identifier for this node.
    pub id: String,
    /// IDs of nodes reachable via outgoing edges.
    pub outgoing_edges: Vec<String>,
}

/// A directed graph representing an agent workflow.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct GraphDefinition {
    /// All nodes in the graph.
    pub nodes: Vec<GraphNode>,
    /// ID of the initial (entry) node.
    pub initial_node: String,
    /// IDs of accepting (terminal/goal) nodes.
    pub accepting_nodes: HashSet<String>,
}

// ---------------------------------------------------------------------------
// Verification result
// ---------------------------------------------------------------------------

/// The outcome of checking a single property against a graph.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct VerificationResult {
    /// The property that was checked.
    pub property: VerificationProperty,
    /// Whether the property holds.
    pub passed: bool,
    /// If the property was violated, a path (sequence of node IDs)
    /// demonstrating the violation.
    pub counterexample: Option<Vec<String>>,
    /// Number of states examined during verification.
    pub checked_states: usize,
}

// ---------------------------------------------------------------------------
// Verifier
// ---------------------------------------------------------------------------

/// Stateless verifier that checks properties against workflow graphs.
pub struct Verifier;

impl Verifier {
    /// Check a single property against the given graph.
    pub fn verify(graph: &GraphDefinition, property: &VerificationProperty) -> VerificationResult {
        match property {
            VerificationProperty::Deadlock => Self::check_deadlock(graph),
            VerificationProperty::Liveness => Self::check_liveness(graph),
            VerificationProperty::Safety => Self::check_safety(graph),
            VerificationProperty::BoundedLiveness { max_steps } => {
                Self::check_bounded_liveness(graph, *max_steps)
            }
        }
    }

    /// Check all properties against the given graph, returning one result per
    /// property.
    pub fn verify_all(
        graph: &GraphDefinition,
        properties: &[VerificationProperty],
    ) -> Vec<VerificationResult> {
        properties
            .iter()
            .map(|prop| Self::verify(graph, prop))
            .collect()
    }

    // -----------------------------------------------------------------------
    // Internal checkers
    // -----------------------------------------------------------------------

    /// Deadlock check: DFS cycle detection.
    ///
    /// Uses the standard three-colour (White/Gray/Black) DFS algorithm.
    /// Returns a counterexample containing the cycle path if one is found.
    fn check_deadlock(graph: &GraphDefinition) -> VerificationResult {
        // Build adjacency map for fast lookup.
        let adj = Self::adjacency_map(graph);
        let node_ids: Vec<&str> = adj.keys().copied().collect();

        // Track visit state: 0 = unvisited, 1 = in-stack (gray), 2 = done.
        let mut state: HashMap<&str, u8> = node_ids.iter().map(|id| (*id, 0u8)).collect();
        let mut checked_states: usize = 0;

        // Parent tracking for counterexample reconstruction.
        let mut parent: HashMap<&str, &str> = HashMap::new();

        for &start in &node_ids {
            if state[start] != 0 {
                continue;
            }

            // Iterative DFS using an explicit stack.
            // Stack entries: (node, edge_index, is_entry).
            let mut stack: Vec<(&str, usize, bool)> = vec![(start, 0, true)];

            while let Some((node, edge_idx, is_entry)) = stack.last_mut() {
                if *is_entry {
                    *is_entry = false;
                    state.insert(node, 1); // mark gray
                    checked_states += 1;
                }

                let edges = adj.get(node).map(|e| e.as_slice()).unwrap_or(&[]);

                if *edge_idx < edges.len() {
                    let neighbour = edges[*edge_idx];
                    *edge_idx += 1;

                    match state.get(neighbour).copied().unwrap_or(0) {
                        0 => {
                            // Unvisited — descend.
                            parent.insert(neighbour, node);
                            stack.push((neighbour, 0, true));
                        }
                        1 => {
                            // Back edge — cycle found.
                            let cycle = Self::reconstruct_cycle(node, neighbour, &parent);
                            return VerificationResult {
                                property: VerificationProperty::Deadlock,
                                passed: false,
                                counterexample: Some(cycle),
                                checked_states,
                            };
                        }
                        _ => {
                            // Already fully processed — skip.
                        }
                    }
                } else {
                    // All neighbours explored — mark black and pop.
                    let finished_node = *node;
                    state.insert(finished_node, 2);
                    stack.pop();
                }
            }
        }

        VerificationResult {
            property: VerificationProperty::Deadlock,
            passed: true,
            counterexample: None,
            checked_states,
        }
    }

    /// Liveness check: every node can reach at least one accepting node.
    ///
    /// Approach: build a reverse adjacency list, then BFS backwards from all
    /// accepting nodes. Any node NOT reached cannot reach an accepting state.
    fn check_liveness(graph: &GraphDefinition) -> VerificationResult {
        let adj = Self::adjacency_map(graph);
        let node_ids: HashSet<&str> = adj.keys().copied().collect();

        // Build reverse adjacency list.
        let mut rev_adj: HashMap<&str, Vec<&str>> = HashMap::new();
        for &node in &node_ids {
            rev_adj.entry(node).or_default();
        }
        for (&src, dests) in &adj {
            for &dst in dests {
                rev_adj.entry(dst).or_default().push(src);
            }
        }

        // BFS backwards from accepting nodes.
        let mut reachable: HashSet<&str> = HashSet::new();
        let mut queue: VecDeque<&str> = VecDeque::new();

        for acc in &graph.accepting_nodes {
            if let Some(acc_ref) = node_ids.get(acc.as_str()) {
                reachable.insert(acc_ref);
                queue.push_back(acc_ref);
            }
        }

        while let Some(node) = queue.pop_front() {
            if let Some(predecessors) = rev_adj.get(node) {
                for &pred in predecessors {
                    if reachable.insert(pred) {
                        queue.push_back(pred);
                    }
                }
            }
        }

        let checked_states = node_ids.len();

        // Find any node that cannot reach an accepting state.
        for &node in &node_ids {
            if !reachable.contains(node) {
                // Build a counterexample: forward BFS from `node` showing the
                // path that never reaches an accepting state.
                let path = Self::bfs_path_from(node, &adj);
                return VerificationResult {
                    property: VerificationProperty::Liveness,
                    passed: false,
                    counterexample: Some(path.into_iter().map(String::from).collect()),
                    checked_states,
                };
            }
        }

        VerificationResult {
            property: VerificationProperty::Liveness,
            passed: true,
            counterexample: None,
            checked_states,
        }
    }

    /// Safety check: all edges reference valid (existing) nodes.
    fn check_safety(graph: &GraphDefinition) -> VerificationResult {
        let valid_ids: HashSet<&str> = graph.nodes.iter().map(|n| n.id.as_str()).collect();
        let mut checked_states: usize = 0;

        for node in &graph.nodes {
            checked_states += 1;
            for target in &node.outgoing_edges {
                if !valid_ids.contains(target.as_str()) {
                    return VerificationResult {
                        property: VerificationProperty::Safety,
                        passed: false,
                        counterexample: Some(vec![node.id.clone(), target.clone()]),
                        checked_states,
                    };
                }
            }
        }

        VerificationResult {
            property: VerificationProperty::Safety,
            passed: true,
            counterexample: None,
            checked_states,
        }
    }

    /// Bounded liveness check: an accepting state is reachable from the
    /// initial node within `max_steps` transitions.
    ///
    /// Uses BFS with a depth limit.
    fn check_bounded_liveness(graph: &GraphDefinition, max_steps: u32) -> VerificationResult {
        let adj = Self::adjacency_map(graph);
        let mut visited: HashSet<&str> = HashSet::new();
        let mut checked_states: usize = 0;

        // BFS queue entries: (node, depth).
        let mut queue: VecDeque<(&str, u32)> = VecDeque::new();

        if let Some(initial) = adj.keys().find(|&&k| k == graph.initial_node.as_str()) {
            visited.insert(initial);
            queue.push_back((initial, 0));
        }

        while let Some((node, depth)) = queue.pop_front() {
            checked_states += 1;

            if graph.accepting_nodes.contains(node) {
                return VerificationResult {
                    property: VerificationProperty::BoundedLiveness { max_steps },
                    passed: true,
                    counterexample: None,
                    checked_states,
                };
            }

            if depth >= max_steps {
                continue;
            }

            if let Some(neighbours) = adj.get(node) {
                for &neighbour in neighbours {
                    if visited.insert(neighbour) {
                        queue.push_back((neighbour, depth + 1));
                    }
                }
            }
        }

        // BFS exhausted without reaching an accepting node within max_steps.
        VerificationResult {
            property: VerificationProperty::BoundedLiveness { max_steps },
            passed: false,
            counterexample: Some(vec![graph.initial_node.clone()]),
            checked_states,
        }
    }

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------

    /// Build an adjacency map from the graph definition, keyed by node ID.
    fn adjacency_map(graph: &GraphDefinition) -> HashMap<&str, Vec<&str>> {
        let mut adj: HashMap<&str, Vec<&str>> = HashMap::new();
        for node in &graph.nodes {
            let edges: Vec<&str> = node.outgoing_edges.iter().map(|s| s.as_str()).collect();
            adj.insert(node.id.as_str(), edges);
        }
        adj
    }

    /// Reconstruct a cycle path from `current` back to `cycle_target` using
    /// the parent map built during DFS.
    fn reconstruct_cycle<'a>(
        current: &'a str,
        cycle_target: &'a str,
        parent: &HashMap<&'a str, &'a str>,
    ) -> Vec<String> {
        let mut path = vec![cycle_target.to_string()];
        let mut cursor = current;
        while cursor != cycle_target {
            path.push(cursor.to_string());
            cursor = match parent.get(cursor) {
                Some(&p) => p,
                None => break,
            };
        }
        path.push(cycle_target.to_string());
        path.reverse();
        path
    }

    /// Forward BFS from a node, returning all nodes visited in BFS order.
    fn bfs_path_from<'a>(start: &'a str, adj: &HashMap<&'a str, Vec<&'a str>>) -> Vec<&'a str> {
        let mut visited: HashSet<&str> = HashSet::new();
        let mut order: Vec<&str> = Vec::new();
        let mut queue: VecDeque<&str> = VecDeque::new();

        visited.insert(start);
        queue.push_back(start);

        while let Some(node) = queue.pop_front() {
            order.push(node);
            if let Some(neighbours) = adj.get(node) {
                for &neighbour in neighbours {
                    if visited.insert(neighbour) {
                        queue.push_back(neighbour);
                    }
                }
            }
        }

        order
    }
}

// ---------------------------------------------------------------------------
// Typed graph verification (extended model)
// ---------------------------------------------------------------------------

/// Node types matching the Python execution graph model.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
#[cfg_attr(feature = "serde", serde(rename_all = "snake_case"))]
pub enum NodeType {
    /// Execute a handler function.
    Action,
    /// Evaluate a boolean expression.
    Condition,
    /// Reference to another graph.
    Subgraph,
    /// Delegate to an AI agent.
    Agent,
    /// Protocol-specific operation (MCP/A2A).
    Protocol,
    /// Entry point.
    Start,
    /// Terminal node.
    End,
}

/// Edge types matching the Python execution graph model.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
#[cfg_attr(feature = "serde", serde(rename_all = "snake_case"))]
pub enum EdgeType {
    /// Unconditional transition.
    Normal,
    /// Guarded by a boolean expression.
    Conditional,
    /// Error/fallback path.
    Exception,
    /// Fork to concurrent branch.
    Parallel,
}

/// A typed node for richer graph verification.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct TypedNode {
    /// Unique node identifier.
    pub id: String,
    /// The semantic type of this node.
    pub node_type: NodeType,
    /// Human-readable label.
    #[cfg_attr(feature = "serde", serde(default))]
    pub label: String,
    /// For Subgraph nodes: reference to another graph ID.
    #[cfg_attr(feature = "serde", serde(default))]
    pub subgraph_ref: Option<String>,
    /// For Condition nodes: the condition expression (documentation).
    #[cfg_attr(feature = "serde", serde(default))]
    pub condition: Option<String>,
    /// For Agent nodes: agent DID or capability requirement.
    #[cfg_attr(feature = "serde", serde(default))]
    pub agent_ref: Option<String>,
    /// For Protocol nodes: protocol type (mcp/a2a).
    #[cfg_attr(feature = "serde", serde(default))]
    pub protocol: Option<String>,
}

/// A typed edge for richer graph verification.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct TypedEdge {
    /// Source node ID.
    pub from: String,
    /// Target node ID.
    pub to: String,
    /// The semantic type of this edge.
    pub edge_type: EdgeType,
    /// For Conditional edges: the guard expression.
    #[cfg_attr(feature = "serde", serde(default))]
    pub guard: Option<String>,
    /// Edge weight/priority (for routing decisions).
    #[cfg_attr(feature = "serde", serde(default = "default_weight"))]
    pub weight: f64,
}

fn default_weight() -> f64 {
    1.0
}

/// A verification error with affected node IDs.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct VerificationError {
    /// Which check produced this error.
    pub check: String,
    /// Human-readable description.
    pub message: String,
    /// Affected node IDs.
    pub nodes: Vec<String>,
}

/// A verification warning with affected node IDs.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct VerificationWarning {
    /// Which check produced this warning.
    pub check: String,
    /// Human-readable description.
    pub message: String,
    /// Affected node IDs.
    pub nodes: Vec<String>,
}

/// Aggregate statistics about a typed graph.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct GraphStats {
    pub node_count: usize,
    pub edge_count: usize,
    pub max_depth: usize,
    pub has_cycles: bool,
    pub parallel_branches: usize,
    pub subgraph_references: usize,
}

/// The result of verifying a typed graph.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct TypedVerificationResult {
    /// Whether the graph passed all checks (no errors).
    pub valid: bool,
    /// Hard errors that make the graph invalid.
    pub errors: Vec<VerificationError>,
    /// Soft warnings (graph is valid but may have issues).
    pub warnings: Vec<VerificationWarning>,
    /// Aggregate statistics.
    pub stats: GraphStats,
}

/// Stateless verifier for typed execution graphs.
pub struct TypedGraphVerifier;

impl TypedGraphVerifier {
    /// Run all structural checks on a typed graph.
    pub fn verify(
        nodes: &[TypedNode],
        edges: &[TypedEdge],
        max_iteration_depth: Option<u32>,
    ) -> TypedVerificationResult {
        let mut errors = Vec::new();
        let mut warnings = Vec::new();

        let node_map: HashMap<&str, &TypedNode> =
            nodes.iter().map(|n| (n.id.as_str(), n)).collect();

        // Build adjacency: node_id → [(target_id, edge_type)]
        let mut adj: HashMap<&str, Vec<(&str, &EdgeType)>> = HashMap::new();
        for n in nodes {
            adj.entry(n.id.as_str()).or_default();
        }
        for e in edges {
            adj.entry(e.from.as_str())
                .or_default()
                .push((e.to.as_str(), &e.edge_type));
        }

        // Build reverse adjacency for reachability
        let mut rev_adj: HashMap<&str, Vec<&str>> = HashMap::new();
        for n in nodes {
            rev_adj.entry(n.id.as_str()).or_default();
        }
        for e in edges {
            rev_adj
                .entry(e.to.as_str())
                .or_default()
                .push(e.from.as_str());
        }

        // 1. Start/End node validation
        Self::check_start_end_nodes(&node_map, &mut errors);

        // 2. Orphan node detection (no incoming and no outgoing, and not Start/End)
        Self::check_orphan_nodes(&adj, &rev_adj, &node_map, &mut warnings);

        // 3. Cycle detection with iteration limits
        let has_cycles = Self::check_cycles(
            &adj,
            &node_map,
            max_iteration_depth,
            &mut errors,
            &mut warnings,
        );

        // 4. Conditional edge completeness
        Self::check_conditional_completeness(&adj, &node_map, &mut errors);

        // 5. Subgraph reference validation
        Self::check_subgraph_references(&node_map, &mut errors);

        // 6. Parallel branch join-point warnings
        let parallel_branches = Self::check_parallel_joins(&adj, &node_map, edges, &mut warnings);

        // 7. Reachability from Start to End
        Self::check_reachability(&adj, &node_map, &mut errors);

        // 8. Agent/Protocol node validation
        Self::check_agent_protocol_nodes(&node_map, &mut warnings);

        // Compute stats
        let max_depth = Self::compute_max_depth(&adj, &node_map);
        let subgraph_references = nodes
            .iter()
            .filter(|n| n.node_type == NodeType::Subgraph)
            .count();

        let stats = GraphStats {
            node_count: nodes.len(),
            edge_count: edges.len(),
            max_depth,
            has_cycles,
            parallel_branches,
            subgraph_references,
        };

        TypedVerificationResult {
            valid: errors.is_empty(),
            errors,
            warnings,
            stats,
        }
    }

    /// Exactly one Start node required.
    fn check_start_end_nodes(
        node_map: &HashMap<&str, &TypedNode>,
        errors: &mut Vec<VerificationError>,
    ) {
        let start_nodes: Vec<&str> = node_map
            .iter()
            .filter(|(_, n)| n.node_type == NodeType::Start)
            .map(|(&id, _)| id)
            .collect();
        let end_nodes: Vec<&str> = node_map
            .iter()
            .filter(|(_, n)| n.node_type == NodeType::End)
            .map(|(&id, _)| id)
            .collect();

        if start_nodes.is_empty() {
            errors.push(VerificationError {
                check: "start_node".into(),
                message: "graph has no Start node".into(),
                nodes: vec![],
            });
        } else if start_nodes.len() > 1 {
            errors.push(VerificationError {
                check: "start_node".into(),
                message: format!(
                    "graph has {} Start nodes, expected exactly 1",
                    start_nodes.len()
                ),
                nodes: start_nodes.iter().map(|s| s.to_string()).collect(),
            });
        }

        if end_nodes.is_empty() {
            errors.push(VerificationError {
                check: "end_node".into(),
                message: "graph has no End node".into(),
                nodes: vec![],
            });
        }
    }

    /// Detect orphan nodes (no incoming edges AND no outgoing edges, excluding Start/End).
    fn check_orphan_nodes(
        adj: &HashMap<&str, Vec<(&str, &EdgeType)>>,
        rev_adj: &HashMap<&str, Vec<&str>>,
        node_map: &HashMap<&str, &TypedNode>,
        warnings: &mut Vec<VerificationWarning>,
    ) {
        for (&id, &node) in node_map {
            if node.node_type == NodeType::Start || node.node_type == NodeType::End {
                continue;
            }
            let has_outgoing = adj.get(id).is_some_and(|e| !e.is_empty());
            let has_incoming = rev_adj.get(id).is_some_and(|e| !e.is_empty());
            if !has_outgoing && !has_incoming {
                warnings.push(VerificationWarning {
                    check: "orphan_node".into(),
                    message: format!("node '{}' has no incoming or outgoing edges", id),
                    nodes: vec![id.to_string()],
                });
            }
        }
    }

    /// DFS cycle detection. Returns `true` if cycles exist.
    /// With `max_iteration_depth` set, cycles produce warnings instead of errors.
    fn check_cycles(
        adj: &HashMap<&str, Vec<(&str, &EdgeType)>>,
        node_map: &HashMap<&str, &TypedNode>,
        max_iteration_depth: Option<u32>,
        errors: &mut Vec<VerificationError>,
        warnings: &mut Vec<VerificationWarning>,
    ) -> bool {
        let node_ids: Vec<&str> = node_map.keys().copied().collect();
        let mut state: HashMap<&str, u8> = node_ids.iter().map(|&id| (id, 0u8)).collect();
        let mut has_cycles = false;

        for &start in &node_ids {
            if state[start] != 0 {
                continue;
            }
            let mut stack: Vec<(&str, usize, bool)> = vec![(start, 0, true)];

            while let Some((node, edge_idx, is_entry)) = stack.last_mut() {
                if *is_entry {
                    *is_entry = false;
                    state.insert(node, 1);
                }

                let edges = adj.get(node).map(|e| e.as_slice()).unwrap_or(&[]);

                if *edge_idx < edges.len() {
                    let (neighbour, _) = edges[*edge_idx];
                    *edge_idx += 1;

                    match state.get(neighbour).copied().unwrap_or(0) {
                        0 => {
                            stack.push((neighbour, 0, true));
                        }
                        1 => {
                            has_cycles = true;
                            let cycle_nodes = vec![node.to_string(), neighbour.to_string()];
                            if max_iteration_depth.is_some() {
                                warnings.push(VerificationWarning {
                                    check: "cycle".into(),
                                    message: format!(
                                        "cycle detected (allowed with max_iteration_depth={})",
                                        max_iteration_depth.unwrap_or(0)
                                    ),
                                    nodes: cycle_nodes,
                                });
                            } else {
                                errors.push(VerificationError {
                                    check: "cycle".into(),
                                    message: "cycle detected in graph".into(),
                                    nodes: cycle_nodes,
                                });
                            }
                            // Continue to find all cycles
                        }
                        _ => {}
                    }
                } else {
                    let finished = *node;
                    state.insert(finished, 2);
                    stack.pop();
                }
            }
        }

        has_cycles
    }

    /// Condition nodes must have >= 2 outgoing edges (true/false branches).
    fn check_conditional_completeness(
        adj: &HashMap<&str, Vec<(&str, &EdgeType)>>,
        node_map: &HashMap<&str, &TypedNode>,
        errors: &mut Vec<VerificationError>,
    ) {
        for (&id, &node) in node_map {
            if node.node_type == NodeType::Condition {
                let out_count = adj.get(id).map_or(0, |e| e.len());
                if out_count < 2 {
                    errors.push(VerificationError {
                        check: "conditional_completeness".into(),
                        message: format!(
                            "Condition node '{}' has {} outgoing edge(s), needs at least 2",
                            id, out_count
                        ),
                        nodes: vec![id.to_string()],
                    });
                }
            }
        }
    }

    /// Subgraph nodes must have a `subgraph_ref`.
    fn check_subgraph_references(
        node_map: &HashMap<&str, &TypedNode>,
        errors: &mut Vec<VerificationError>,
    ) {
        for (&id, &node) in node_map {
            if node.node_type == NodeType::Subgraph && node.subgraph_ref.is_none() {
                errors.push(VerificationError {
                    check: "subgraph_ref".into(),
                    message: format!("Subgraph node '{}' is missing subgraph_ref", id),
                    nodes: vec![id.to_string()],
                });
            }
        }
    }

    /// Warn when parallel edges fork without a clear join point.
    /// Returns the count of parallel fork edges.
    fn check_parallel_joins(
        adj: &HashMap<&str, Vec<(&str, &EdgeType)>>,
        node_map: &HashMap<&str, &TypedNode>,
        edges: &[TypedEdge],
        warnings: &mut Vec<VerificationWarning>,
    ) -> usize {
        let parallel_count = edges
            .iter()
            .filter(|e| e.edge_type == EdgeType::Parallel)
            .count();

        // Find nodes that emit parallel edges
        for &id in node_map.keys() {
            let parallel_targets: Vec<&str> = adj
                .get(id)
                .map(|e| {
                    e.iter()
                        .filter(|(_, et)| **et == EdgeType::Parallel)
                        .map(|(t, _)| *t)
                        .collect()
                })
                .unwrap_or_default();

            if parallel_targets.len() >= 2 {
                warnings.push(VerificationWarning {
                    check: "parallel_join".into(),
                    message: format!(
                        "node '{}' forks into {} parallel branches — ensure a join point exists",
                        id,
                        parallel_targets.len()
                    ),
                    nodes: std::iter::once(id.to_string())
                        .chain(parallel_targets.iter().map(|t| t.to_string()))
                        .collect(),
                });
            }
        }

        parallel_count
    }

    /// Every End node must be reachable from every Start node.
    fn check_reachability(
        adj: &HashMap<&str, Vec<(&str, &EdgeType)>>,
        node_map: &HashMap<&str, &TypedNode>,
        errors: &mut Vec<VerificationError>,
    ) {
        let start_nodes: Vec<&str> = node_map
            .iter()
            .filter(|(_, n)| n.node_type == NodeType::Start)
            .map(|(&id, _)| id)
            .collect();
        let end_nodes: Vec<&str> = node_map
            .iter()
            .filter(|(_, n)| n.node_type == NodeType::End)
            .map(|(&id, _)| id)
            .collect();

        for &start in &start_nodes {
            // BFS from start
            let mut visited: HashSet<&str> = HashSet::new();
            let mut queue: VecDeque<&str> = VecDeque::new();
            visited.insert(start);
            queue.push_back(start);

            while let Some(node) = queue.pop_front() {
                if let Some(neighbours) = adj.get(node) {
                    for &(target, _) in neighbours {
                        if visited.insert(target) {
                            queue.push_back(target);
                        }
                    }
                }
            }

            for &end in &end_nodes {
                if !visited.contains(end) {
                    errors.push(VerificationError {
                        check: "reachability".into(),
                        message: format!(
                            "End node '{}' is not reachable from Start node '{}'",
                            end, start
                        ),
                        nodes: vec![start.to_string(), end.to_string()],
                    });
                }
            }
        }
    }

    /// Warn when Agent nodes lack agent_ref or Protocol nodes lack protocol.
    fn check_agent_protocol_nodes(
        node_map: &HashMap<&str, &TypedNode>,
        warnings: &mut Vec<VerificationWarning>,
    ) {
        for (&id, &node) in node_map {
            if node.node_type == NodeType::Agent && node.agent_ref.is_none() {
                warnings.push(VerificationWarning {
                    check: "agent_ref".into(),
                    message: format!("Agent node '{}' has no agent_ref", id),
                    nodes: vec![id.to_string()],
                });
            }
            if node.node_type == NodeType::Protocol && node.protocol.is_none() {
                warnings.push(VerificationWarning {
                    check: "protocol_ref".into(),
                    message: format!("Protocol node '{}' has no protocol type specified", id),
                    nodes: vec![id.to_string()],
                });
            }
        }
    }

    /// BFS from Start nodes to compute max depth.
    fn compute_max_depth(
        adj: &HashMap<&str, Vec<(&str, &EdgeType)>>,
        node_map: &HashMap<&str, &TypedNode>,
    ) -> usize {
        let mut max_depth: usize = 0;

        for (&start_id, &node) in node_map {
            if node.node_type != NodeType::Start {
                continue;
            }
            let mut visited: HashSet<&str> = HashSet::new();
            let mut queue: VecDeque<(&str, usize)> = VecDeque::new();
            visited.insert(start_id);
            queue.push_back((start_id, 0));

            while let Some((current, depth)) = queue.pop_front() {
                if depth > max_depth {
                    max_depth = depth;
                }
                if let Some(neighbours) = adj.get(current) {
                    for &(target, _) in neighbours {
                        if visited.insert(target) {
                            queue.push_back((target, depth + 1));
                        }
                    }
                }
            }
        }

        max_depth
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    /// Helper: build a graph from a list of (id, edges) tuples.
    fn make_graph(nodes: &[(&str, &[&str])], initial: &str, accepting: &[&str]) -> GraphDefinition {
        GraphDefinition {
            nodes: nodes
                .iter()
                .map(|(id, edges)| GraphNode {
                    id: id.to_string(),
                    outgoing_edges: edges.iter().map(|e| e.to_string()).collect(),
                })
                .collect(),
            initial_node: initial.to_string(),
            accepting_nodes: accepting.iter().map(|s| s.to_string()).collect(),
        }
    }

    #[test]
    fn acyclic_graph_passes_deadlock_check() {
        // A -> B -> C -> D (linear DAG)
        let graph = make_graph(
            &[("A", &["B"]), ("B", &["C"]), ("C", &["D"]), ("D", &[])],
            "A",
            &["D"],
        );

        let result = Verifier::verify(&graph, &VerificationProperty::Deadlock);
        assert!(result.passed, "acyclic graph should pass deadlock check");
        assert!(result.counterexample.is_none());
        assert!(result.checked_states > 0);
    }

    #[test]
    fn cyclic_graph_fails_deadlock_check_with_counterexample() {
        // A -> B -> C -> A (cycle)
        let graph = make_graph(&[("A", &["B"]), ("B", &["C"]), ("C", &["A"])], "A", &["C"]);

        let result = Verifier::verify(&graph, &VerificationProperty::Deadlock);
        assert!(!result.passed, "cyclic graph should fail deadlock check");

        let counter = result.counterexample.expect("should have counterexample");
        // The counterexample should form a cycle: first and last elements match.
        assert!(
            counter.len() >= 2,
            "counterexample should have at least 2 elements, got {counter:?}"
        );
        assert_eq!(
            counter.first(),
            counter.last(),
            "cycle counterexample should start and end at the same node: {counter:?}"
        );
    }

    #[test]
    fn all_nodes_reach_accepting_passes_liveness() {
        // A -> B -> C (accepting), A -> C
        let graph = make_graph(
            &[("A", &["B", "C"]), ("B", &["C"]), ("C", &[])],
            "A",
            &["C"],
        );

        let result = Verifier::verify(&graph, &VerificationProperty::Liveness);
        assert!(result.passed, "all nodes can reach accepting state C");
        assert!(result.counterexample.is_none());
    }

    #[test]
    fn unreachable_accepting_state_fails_liveness() {
        // A -> B, C is disconnected. Accepting = {C}.
        // Neither A nor B can reach C.
        let graph = make_graph(&[("A", &["B"]), ("B", &[]), ("C", &[])], "A", &["C"]);

        let result = Verifier::verify(&graph, &VerificationProperty::Liveness);
        assert!(!result.passed, "A and B cannot reach accepting node C");
        assert!(
            result.counterexample.is_some(),
            "should provide a counterexample path"
        );
    }

    #[test]
    fn safety_passes_when_all_edges_valid() {
        let graph = make_graph(&[("A", &["B"]), ("B", &["C"]), ("C", &[])], "A", &["C"]);

        let result = Verifier::verify(&graph, &VerificationProperty::Safety);
        assert!(result.passed);
    }

    #[test]
    fn safety_fails_on_dangling_edge() {
        let graph = make_graph(&[("A", &["B"]), ("B", &["NONEXISTENT"])], "A", &["B"]);

        let result = Verifier::verify(&graph, &VerificationProperty::Safety);
        assert!(!result.passed);
        let counter = result.counterexample.unwrap();
        assert_eq!(counter, vec!["B", "NONEXISTENT"]);
    }

    #[test]
    fn bounded_liveness_within_limit() {
        // A -> B -> C (accepting), max_steps = 2
        let graph = make_graph(&[("A", &["B"]), ("B", &["C"]), ("C", &[])], "A", &["C"]);

        let result = Verifier::verify(
            &graph,
            &VerificationProperty::BoundedLiveness { max_steps: 2 },
        );
        assert!(result.passed, "C is reachable in 2 steps from A");
    }

    #[test]
    fn bounded_liveness_exceeds_limit() {
        // A -> B -> C -> D (accepting), max_steps = 2 (needs 3)
        let graph = make_graph(
            &[("A", &["B"]), ("B", &["C"]), ("C", &["D"]), ("D", &[])],
            "A",
            &["D"],
        );

        let result = Verifier::verify(
            &graph,
            &VerificationProperty::BoundedLiveness { max_steps: 2 },
        );
        assert!(!result.passed, "D is 3 steps from A, exceeds max_steps=2");
    }

    #[test]
    fn verify_all_runs_multiple_properties() {
        let graph = make_graph(&[("A", &["B"]), ("B", &["C"]), ("C", &[])], "A", &["C"]);

        let props = vec![
            VerificationProperty::Deadlock,
            VerificationProperty::Liveness,
            VerificationProperty::Safety,
            VerificationProperty::BoundedLiveness { max_steps: 5 },
        ];

        let results = Verifier::verify_all(&graph, &props);
        assert_eq!(results.len(), 4);
        assert!(results.iter().all(|r| r.passed));
    }

    // -----------------------------------------------------------------------
    // Typed graph verification tests
    // -----------------------------------------------------------------------

    fn make_typed_node(id: &str, node_type: NodeType) -> TypedNode {
        TypedNode {
            id: id.to_string(),
            node_type,
            label: String::new(),
            subgraph_ref: None,
            condition: None,
            agent_ref: None,
            protocol: None,
        }
    }

    fn make_typed_edge(from: &str, to: &str, edge_type: EdgeType) -> TypedEdge {
        TypedEdge {
            from: from.to_string(),
            to: to.to_string(),
            edge_type,
            guard: None,
            weight: 1.0,
        }
    }

    #[test]
    fn typed_check_missing_start_node() {
        let nodes = vec![
            make_typed_node("a", NodeType::Action),
            make_typed_node("end", NodeType::End),
        ];
        let edges = vec![make_typed_edge("a", "end", EdgeType::Normal)];
        let result = TypedGraphVerifier::verify(&nodes, &edges, None);
        assert!(!result.valid);
        assert!(result.errors.iter().any(|e| e.check == "start_node"));
    }

    #[test]
    fn typed_check_multiple_start_nodes() {
        let nodes = vec![
            make_typed_node("s1", NodeType::Start),
            make_typed_node("s2", NodeType::Start),
            make_typed_node("end", NodeType::End),
        ];
        let edges = vec![
            make_typed_edge("s1", "end", EdgeType::Normal),
            make_typed_edge("s2", "end", EdgeType::Normal),
        ];
        let result = TypedGraphVerifier::verify(&nodes, &edges, None);
        assert!(!result.valid);
        let err = result
            .errors
            .iter()
            .find(|e| e.check == "start_node")
            .expect("start_node error");
        assert_eq!(err.nodes.len(), 2);
    }

    #[test]
    fn typed_check_missing_end_node() {
        let nodes = vec![
            make_typed_node("start", NodeType::Start),
            make_typed_node("a", NodeType::Action),
        ];
        let edges = vec![make_typed_edge("start", "a", EdgeType::Normal)];
        let result = TypedGraphVerifier::verify(&nodes, &edges, None);
        assert!(!result.valid);
        assert!(result.errors.iter().any(|e| e.check == "end_node"));
    }

    #[test]
    fn typed_check_conditional_incomplete() {
        let nodes = vec![
            make_typed_node("start", NodeType::Start),
            make_typed_node("cond", NodeType::Condition),
            make_typed_node("end", NodeType::End),
        ];
        // Only 1 outgoing edge from condition — should need >= 2
        let edges = vec![
            make_typed_edge("start", "cond", EdgeType::Normal),
            make_typed_edge("cond", "end", EdgeType::Conditional),
        ];
        let result = TypedGraphVerifier::verify(&nodes, &edges, None);
        assert!(!result.valid);
        assert!(result
            .errors
            .iter()
            .any(|e| e.check == "conditional_completeness"));
    }

    #[test]
    fn typed_check_conditional_complete() {
        let nodes = vec![
            make_typed_node("start", NodeType::Start),
            make_typed_node("cond", NodeType::Condition),
            make_typed_node("a", NodeType::Action),
            make_typed_node("end", NodeType::End),
        ];
        let edges = vec![
            make_typed_edge("start", "cond", EdgeType::Normal),
            make_typed_edge("cond", "a", EdgeType::Conditional),
            make_typed_edge("cond", "end", EdgeType::Conditional),
            make_typed_edge("a", "end", EdgeType::Normal),
        ];
        let result = TypedGraphVerifier::verify(&nodes, &edges, None);
        assert!(!result
            .errors
            .iter()
            .any(|e| e.check == "conditional_completeness"));
    }

    #[test]
    fn typed_check_subgraph_no_ref() {
        let nodes = vec![
            make_typed_node("start", NodeType::Start),
            make_typed_node("sub", NodeType::Subgraph),
            make_typed_node("end", NodeType::End),
        ];
        let edges = vec![
            make_typed_edge("start", "sub", EdgeType::Normal),
            make_typed_edge("sub", "end", EdgeType::Normal),
        ];
        let result = TypedGraphVerifier::verify(&nodes, &edges, None);
        assert!(!result.valid);
        assert!(result.errors.iter().any(|e| e.check == "subgraph_ref"));
    }

    #[test]
    fn typed_check_cycle_no_limit() {
        let nodes = vec![
            make_typed_node("start", NodeType::Start),
            make_typed_node("a", NodeType::Action),
            make_typed_node("b", NodeType::Action),
            make_typed_node("end", NodeType::End),
        ];
        let edges = vec![
            make_typed_edge("start", "a", EdgeType::Normal),
            make_typed_edge("a", "b", EdgeType::Normal),
            make_typed_edge("b", "a", EdgeType::Normal), // cycle
            make_typed_edge("b", "end", EdgeType::Normal),
        ];
        let result = TypedGraphVerifier::verify(&nodes, &edges, None);
        assert!(!result.valid);
        assert!(result.errors.iter().any(|e| e.check == "cycle"));
        assert!(result.stats.has_cycles);
    }

    #[test]
    fn typed_check_cycle_with_limit() {
        let nodes = vec![
            make_typed_node("start", NodeType::Start),
            make_typed_node("a", NodeType::Action),
            make_typed_node("b", NodeType::Action),
            make_typed_node("end", NodeType::End),
        ];
        let edges = vec![
            make_typed_edge("start", "a", EdgeType::Normal),
            make_typed_edge("a", "b", EdgeType::Normal),
            make_typed_edge("b", "a", EdgeType::Normal), // cycle
            make_typed_edge("b", "end", EdgeType::Normal),
        ];
        let result = TypedGraphVerifier::verify(&nodes, &edges, Some(10));
        // With max_iteration_depth, cycles become warnings not errors
        assert!(!result.errors.iter().any(|e| e.check == "cycle"));
        assert!(result.warnings.iter().any(|w| w.check == "cycle"));
        assert!(result.stats.has_cycles);
    }

    #[test]
    fn typed_check_unreachable_end() {
        let nodes = vec![
            make_typed_node("start", NodeType::Start),
            make_typed_node("a", NodeType::Action),
            make_typed_node("end", NodeType::End),
        ];
        // No path from start to end
        let edges = vec![make_typed_edge("start", "a", EdgeType::Normal)];
        let result = TypedGraphVerifier::verify(&nodes, &edges, None);
        assert!(!result.valid);
        assert!(result.errors.iter().any(|e| e.check == "reachability"));
    }

    #[test]
    fn typed_check_parallel_fork_warning() {
        let nodes = vec![
            make_typed_node("start", NodeType::Start),
            make_typed_node("fork", NodeType::Action),
            make_typed_node("a", NodeType::Action),
            make_typed_node("b", NodeType::Action),
            make_typed_node("end", NodeType::End),
        ];
        let edges = vec![
            make_typed_edge("start", "fork", EdgeType::Normal),
            make_typed_edge("fork", "a", EdgeType::Parallel),
            make_typed_edge("fork", "b", EdgeType::Parallel),
            make_typed_edge("a", "end", EdgeType::Normal),
            make_typed_edge("b", "end", EdgeType::Normal),
        ];
        let result = TypedGraphVerifier::verify(&nodes, &edges, None);
        assert!(result.warnings.iter().any(|w| w.check == "parallel_join"));
        assert!(result.stats.parallel_branches >= 2);
    }

    #[test]
    fn typed_check_valid_graph() {
        let nodes = vec![
            make_typed_node("start", NodeType::Start),
            make_typed_node("action", NodeType::Action),
            make_typed_node("end", NodeType::End),
        ];
        let edges = vec![
            make_typed_edge("start", "action", EdgeType::Normal),
            make_typed_edge("action", "end", EdgeType::Normal),
        ];
        let result = TypedGraphVerifier::verify(&nodes, &edges, None);
        assert!(result.valid);
        assert!(result.errors.is_empty());
        assert_eq!(result.stats.node_count, 3);
        assert_eq!(result.stats.edge_count, 2);
        assert_eq!(result.stats.max_depth, 2);
        assert!(!result.stats.has_cycles);
    }
}
