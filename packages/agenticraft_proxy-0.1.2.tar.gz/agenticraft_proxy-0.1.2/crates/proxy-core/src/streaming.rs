// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Streaming enhancements with backpressure management (F26).
//!
//! Provides bounded stream buffers with configurable backpressure policies:
//! - **Buffer**: accept chunks up to capacity, then apply slow-consumer action
//! - **Drop**: drop oldest chunk when full to make room for new data
//! - **Disconnect**: reject writes when buffer is full
//!
//! `StreamManager` holds multiple named streams (via DashMap for concurrent
//! access) and exposes aggregate statistics.

use std::collections::VecDeque;
use std::sync::atomic::{AtomicU32, AtomicU64, Ordering};

use dashmap::DashMap;
use parking_lot::RwLock;
use thiserror::Error;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------

/// Errors returned by streaming operations.
#[derive(Debug, Error)]
pub enum StreamError {
    #[error("stream `{0}` not found")]
    StreamNotFound(String),

    #[error("stream `{0}` is full")]
    StreamFull(String),
}

// ---------------------------------------------------------------------------
// Backpressure types
// ---------------------------------------------------------------------------

/// Action to take when a stream buffer is full and a slow consumer hasn't
/// drained it.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum BackpressureAction {
    /// Accept and buffer chunks (push will block conceptually — in practice
    /// the buffer just grows up to `max_buffered_chunks`).
    #[default]
    Buffer,
    /// Drop the **oldest** buffered chunk to make room for the new one.
    Drop,
    /// Reject the push and signal the caller to disconnect.
    Disconnect,
}

/// Configuration for stream backpressure.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct BackpressureConfig {
    /// Maximum number of chunks that can be buffered before backpressure
    /// kicks in.
    pub max_buffered_chunks: usize,
    /// What to do when the buffer is full and a new chunk arrives.
    pub slow_consumer_action: BackpressureAction,
}

impl Default for BackpressureConfig {
    fn default() -> Self {
        Self {
            max_buffered_chunks: 256,
            slow_consumer_action: BackpressureAction::Buffer,
        }
    }
}

// ---------------------------------------------------------------------------
// BackpressureResult
// ---------------------------------------------------------------------------

/// Outcome of a `push_chunk` call.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BackpressureResult {
    /// Chunk was buffered normally (buffer was not full).
    Buffered,
    /// Buffer was full; the oldest chunk was dropped to make room.
    Dropped,
    /// Buffer was full and backpressure was triggered (chunk rejected).
    BackpressureTriggered,
}

// ---------------------------------------------------------------------------
// StreamBuffer
// ---------------------------------------------------------------------------

/// Per-stream buffer statistics snapshot.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct StreamBufferStats {
    pub chunks_sent: u64,
    pub chunks_dropped: u64,
    pub bytes_sent: u64,
    pub buffered_chunks: usize,
    pub max_buffered_chunks: usize,
}

/// A bounded chunk buffer with backpressure.
pub struct StreamBuffer {
    buffer: RwLock<VecDeque<Vec<u8>>>,
    config: BackpressureConfig,
    chunks_sent: AtomicU64,
    chunks_dropped: AtomicU64,
    bytes_sent: AtomicU64,
}

impl StreamBuffer {
    /// Create a new stream buffer with the given backpressure config.
    pub fn new(config: BackpressureConfig) -> Self {
        Self {
            buffer: RwLock::new(VecDeque::with_capacity(
                config.max_buffered_chunks.min(1024),
            )),
            config,
            chunks_sent: AtomicU64::new(0),
            chunks_dropped: AtomicU64::new(0),
            bytes_sent: AtomicU64::new(0),
        }
    }

    /// Push a chunk into the buffer.
    ///
    /// Returns `Ok(Buffered)` if the chunk fit, `Ok(Dropped)` if the oldest
    /// chunk was evicted (Drop action), or `Err(BackpressureTriggered)` if the
    /// push was rejected (Disconnect action). With the Buffer action and a
    /// full buffer, the result is `BackpressureTriggered` since there is no
    /// room.
    pub fn push_chunk(&self, chunk: Vec<u8>) -> BackpressureResult {
        let chunk_len = chunk.len() as u64;
        let mut buf = self.buffer.write();

        if buf.len() < self.config.max_buffered_chunks {
            // Room available — just buffer it.
            buf.push_back(chunk);
            self.chunks_sent.fetch_add(1, Ordering::Relaxed);
            self.bytes_sent.fetch_add(chunk_len, Ordering::Relaxed);
            return BackpressureResult::Buffered;
        }

        // Buffer is full — apply backpressure policy.
        match self.config.slow_consumer_action {
            BackpressureAction::Drop => {
                // Evict oldest chunk, insert new one.
                buf.pop_front();
                self.chunks_dropped.fetch_add(1, Ordering::Relaxed);
                buf.push_back(chunk);
                self.chunks_sent.fetch_add(1, Ordering::Relaxed);
                self.bytes_sent.fetch_add(chunk_len, Ordering::Relaxed);
                BackpressureResult::Dropped
            }
            BackpressureAction::Buffer | BackpressureAction::Disconnect => {
                // Both Buffer-at-capacity and Disconnect reject the chunk.
                BackpressureResult::BackpressureTriggered
            }
        }
    }

    /// Pop the oldest chunk from the buffer, if any.
    pub fn pop_chunk(&self) -> Option<Vec<u8>> {
        self.buffer.write().pop_front()
    }

    /// Number of chunks currently buffered.
    pub fn len(&self) -> usize {
        self.buffer.read().len()
    }

    /// Whether the buffer is empty.
    pub fn is_empty(&self) -> bool {
        self.buffer.read().is_empty()
    }

    /// Whether the buffer has reached its maximum capacity.
    pub fn is_full(&self) -> bool {
        self.buffer.read().len() >= self.config.max_buffered_chunks
    }

    /// Snapshot of buffer statistics.
    pub fn stats(&self) -> StreamBufferStats {
        StreamBufferStats {
            chunks_sent: self.chunks_sent.load(Ordering::Relaxed),
            chunks_dropped: self.chunks_dropped.load(Ordering::Relaxed),
            bytes_sent: self.bytes_sent.load(Ordering::Relaxed),
            buffered_chunks: self.buffer.read().len(),
            max_buffered_chunks: self.config.max_buffered_chunks,
        }
    }
}

// ---------------------------------------------------------------------------
// StreamStats (aggregate)
// ---------------------------------------------------------------------------

/// Aggregate statistics across all streams in a `StreamManager`.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct StreamStats {
    pub chunks_sent: u64,
    pub chunks_dropped: u64,
    pub bytes_sent: u64,
    pub active_consumers: u32,
    pub total_streams: u64,
}

// ---------------------------------------------------------------------------
// StreamManager
// ---------------------------------------------------------------------------

/// Manages multiple named streams with backpressure.
pub struct StreamManager {
    /// Active stream buffers, keyed by stream ID.
    streams: DashMap<String, StreamBuffer>,
    /// Default backpressure config for newly created streams.
    config: BackpressureConfig,
    /// Number of currently active consumers (externally managed).
    active_consumers: AtomicU32,
    /// Total streams created over the lifetime of this manager.
    total_streams_created: AtomicU64,
}

impl StreamManager {
    /// Create a new stream manager with the given default config.
    pub fn new(config: BackpressureConfig) -> Self {
        Self {
            streams: DashMap::new(),
            config,
            active_consumers: AtomicU32::new(0),
            total_streams_created: AtomicU64::new(0),
        }
    }

    /// Create a stream with the manager's default backpressure config.
    pub fn create_stream(&self, stream_id: &str) {
        self.streams.insert(
            stream_id.to_string(),
            StreamBuffer::new(self.config.clone()),
        );
        self.total_streams_created.fetch_add(1, Ordering::Relaxed);
        self.active_consumers.fetch_add(1, Ordering::Relaxed);
    }

    /// Create a stream with a custom backpressure config.
    pub fn create_stream_with_config(&self, stream_id: &str, config: BackpressureConfig) {
        self.streams
            .insert(stream_id.to_string(), StreamBuffer::new(config));
        self.total_streams_created.fetch_add(1, Ordering::Relaxed);
        self.active_consumers.fetch_add(1, Ordering::Relaxed);
    }

    /// Push a chunk into the named stream.
    pub fn push(&self, stream_id: &str, chunk: Vec<u8>) -> Result<BackpressureResult, StreamError> {
        let stream = self
            .streams
            .get(stream_id)
            .ok_or_else(|| StreamError::StreamNotFound(stream_id.to_string()))?;

        let result = stream.push_chunk(chunk);
        if result == BackpressureResult::BackpressureTriggered {
            return Err(StreamError::StreamFull(stream_id.to_string()));
        }
        Ok(result)
    }

    /// Pop the oldest chunk from the named stream.
    pub fn pop(&self, stream_id: &str) -> Result<Option<Vec<u8>>, StreamError> {
        let stream = self
            .streams
            .get(stream_id)
            .ok_or_else(|| StreamError::StreamNotFound(stream_id.to_string()))?;
        Ok(stream.pop_chunk())
    }

    /// Remove a stream, returning `true` if it existed.
    pub fn remove_stream(&self, stream_id: &str) -> bool {
        let removed = self.streams.remove(stream_id).is_some();
        if removed {
            self.active_consumers.fetch_sub(1, Ordering::Relaxed);
        }
        removed
    }

    /// Aggregate statistics across all active streams.
    pub fn stats(&self) -> StreamStats {
        let mut chunks_sent: u64 = 0;
        let mut chunks_dropped: u64 = 0;
        let mut bytes_sent: u64 = 0;

        for entry in self.streams.iter() {
            let s = entry.value().stats();
            chunks_sent += s.chunks_sent;
            chunks_dropped += s.chunks_dropped;
            bytes_sent += s.bytes_sent;
        }

        StreamStats {
            chunks_sent,
            chunks_dropped,
            bytes_sent,
            active_consumers: self.active_consumers.load(Ordering::Relaxed),
            total_streams: self.total_streams_created.load(Ordering::Relaxed),
        }
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn push_and_pop_chunks() {
        let buf = StreamBuffer::new(BackpressureConfig {
            max_buffered_chunks: 16,
            slow_consumer_action: BackpressureAction::Buffer,
        });

        assert_eq!(
            buf.push_chunk(b"hello".to_vec()),
            BackpressureResult::Buffered
        );
        assert_eq!(
            buf.push_chunk(b"world".to_vec()),
            BackpressureResult::Buffered
        );
        assert_eq!(buf.len(), 2);

        let c1 = buf.pop_chunk().unwrap();
        assert_eq!(c1, b"hello");
        let c2 = buf.pop_chunk().unwrap();
        assert_eq!(c2, b"world");
        assert!(buf.pop_chunk().is_none());
    }

    #[test]
    fn buffer_action_rejects_when_full() {
        let buf = StreamBuffer::new(BackpressureConfig {
            max_buffered_chunks: 2,
            slow_consumer_action: BackpressureAction::Buffer,
        });

        assert_eq!(buf.push_chunk(b"a".to_vec()), BackpressureResult::Buffered);
        assert_eq!(buf.push_chunk(b"b".to_vec()), BackpressureResult::Buffered);
        assert!(buf.is_full());

        // Buffer action with full buffer -> backpressure triggered
        assert_eq!(
            buf.push_chunk(b"c".to_vec()),
            BackpressureResult::BackpressureTriggered
        );
        // Original chunks are still intact
        assert_eq!(buf.len(), 2);
        assert_eq!(buf.pop_chunk().unwrap(), b"a");
    }

    #[test]
    fn drop_action_evicts_oldest_when_full() {
        let buf = StreamBuffer::new(BackpressureConfig {
            max_buffered_chunks: 2,
            slow_consumer_action: BackpressureAction::Drop,
        });

        buf.push_chunk(b"first".to_vec());
        buf.push_chunk(b"second".to_vec());
        assert!(buf.is_full());

        // Drop action: oldest ("first") is evicted, new chunk inserted
        assert_eq!(
            buf.push_chunk(b"third".to_vec()),
            BackpressureResult::Dropped
        );
        assert_eq!(buf.len(), 2);

        // "first" was dropped, so next pop should be "second"
        assert_eq!(buf.pop_chunk().unwrap(), b"second");
        assert_eq!(buf.pop_chunk().unwrap(), b"third");
    }

    #[test]
    fn disconnect_action_returns_error_when_full() {
        let mgr = StreamManager::new(BackpressureConfig {
            max_buffered_chunks: 1,
            slow_consumer_action: BackpressureAction::Disconnect,
        });
        mgr.create_stream("s1");

        // First push succeeds
        assert!(mgr.push("s1", b"ok".to_vec()).is_ok());

        // Second push should fail with StreamFull
        let err = mgr.push("s1", b"overflow".to_vec());
        assert!(err.is_err());
        assert!(matches!(err.unwrap_err(), StreamError::StreamFull(_)));
    }

    #[test]
    fn stream_stats_track_correctly() {
        let buf = StreamBuffer::new(BackpressureConfig {
            max_buffered_chunks: 4,
            slow_consumer_action: BackpressureAction::Drop,
        });

        buf.push_chunk(b"aaa".to_vec()); // 3 bytes
        buf.push_chunk(b"bb".to_vec()); // 2 bytes
        buf.push_chunk(b"c".to_vec()); // 1 byte

        let stats = buf.stats();
        assert_eq!(stats.chunks_sent, 3);
        assert_eq!(stats.bytes_sent, 6);
        assert_eq!(stats.chunks_dropped, 0);
        assert_eq!(stats.buffered_chunks, 3);
        assert_eq!(stats.max_buffered_chunks, 4);

        // Fill up and trigger a drop
        buf.push_chunk(b"d".to_vec());
        assert_eq!(buf.len(), 4);
        buf.push_chunk(b"e".to_vec()); // evicts "aaa"

        let stats = buf.stats();
        assert_eq!(stats.chunks_sent, 5);
        assert_eq!(stats.chunks_dropped, 1);
        assert_eq!(stats.bytes_sent, 8); // 3+2+1+1+1
    }

    #[test]
    fn multiple_streams_independent() {
        let mgr = StreamManager::new(BackpressureConfig::default());
        mgr.create_stream("alpha");
        mgr.create_stream("beta");

        mgr.push("alpha", b"a1".to_vec()).unwrap();
        mgr.push("alpha", b"a2".to_vec()).unwrap();
        mgr.push("beta", b"b1".to_vec()).unwrap();

        // Each stream has its own data
        assert_eq!(mgr.pop("alpha").unwrap().unwrap(), b"a1");
        assert_eq!(mgr.pop("beta").unwrap().unwrap(), b"b1");
        assert_eq!(mgr.pop("alpha").unwrap().unwrap(), b"a2");
        assert!(mgr.pop("beta").unwrap().is_none());

        // Accessing a nonexistent stream is an error
        assert!(matches!(
            mgr.pop("nonexistent"),
            Err(StreamError::StreamNotFound(_))
        ));

        // Aggregate stats
        let stats = mgr.stats();
        assert_eq!(stats.chunks_sent, 3);
        assert_eq!(stats.active_consumers, 2);
        assert_eq!(stats.total_streams, 2);

        // Remove one stream
        assert!(mgr.remove_stream("alpha"));
        assert!(!mgr.remove_stream("alpha")); // already removed
        assert_eq!(mgr.stats().active_consumers, 1);
    }

    #[test]
    fn stream_not_found_error() {
        let mgr = StreamManager::new(BackpressureConfig::default());

        assert!(matches!(
            mgr.push("missing", b"x".to_vec()),
            Err(StreamError::StreamNotFound(_))
        ));
        assert!(matches!(
            mgr.pop("missing"),
            Err(StreamError::StreamNotFound(_))
        ));
    }
}
