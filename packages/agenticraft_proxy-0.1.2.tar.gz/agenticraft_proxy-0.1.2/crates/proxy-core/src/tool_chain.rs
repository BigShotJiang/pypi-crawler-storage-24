// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! # Tool Call Chain Tracking (F6)
//!
//! Tracks sequences of tool calls within a single agent interaction, enforcing
//! depth, token budget, and duration limits. Each chain is identified by a
//! unique `chain_id` (typically propagated via the `x-tool-chain-id` header).
//!
//! ## Concurrency model
//!
//! - `DashMap` for the chain registry (lock-free reads, sharded writes).
//! - `parking_lot::RwLock` for the per-chain record list (append-heavy).
//! - `AtomicU32` / `AtomicU64` for depth and token counters (no lock needed
//!   for limit checks).

use std::sync::atomic::{AtomicU32, AtomicU64, Ordering};
use std::time::{SystemTime, UNIX_EPOCH};

use dashmap::DashMap;
use parking_lot::RwLock;
use thiserror::Error;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// HTTP header used to propagate the tool chain ID across requests.
pub const TOOL_CHAIN_HEADER: &str = "x-tool-chain-id";

// ---------------------------------------------------------------------------
// Error
// ---------------------------------------------------------------------------

/// Errors returned when recording a tool call violates chain limits.
#[derive(Debug, Error, Clone, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum ToolChainError {
    #[error("max depth exceeded: chain `{chain_id}` at depth {current}/{max}")]
    MaxDepthExceeded {
        chain_id: String,
        current: u32,
        max: u32,
    },

    #[error("token budget exceeded: chain `{chain_id}` used {current}/{max} tokens")]
    TokenBudgetExceeded {
        chain_id: String,
        current: u64,
        max: u64,
    },

    #[error("duration exceeded: chain `{chain_id}` elapsed {elapsed_secs}s/{max_secs}s")]
    DurationExceeded {
        chain_id: String,
        elapsed_secs: u64,
        max_secs: u64,
    },

    #[error("chain not found: `{chain_id}`")]
    ChainNotFound { chain_id: String },
}

// ---------------------------------------------------------------------------
// Record
// ---------------------------------------------------------------------------

/// A single tool call within a chain.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct ToolCallRecord {
    /// Name of the tool that was invoked.
    pub tool_name: String,
    /// Agent that initiated the tool call.
    pub agent_id: String,
    /// Unix timestamp in seconds when the call was recorded.
    pub timestamp: u64,
    /// Number of tokens consumed by this call.
    pub tokens_used: u64,
    /// Wall-clock duration of the tool call in milliseconds.
    pub duration_ms: u64,
}

// ---------------------------------------------------------------------------
// Chain
// ---------------------------------------------------------------------------

/// A tracked sequence of tool calls with enforced limits.
pub struct ToolCallChain {
    chain_id: String,
    records: RwLock<Vec<ToolCallRecord>>,
    depth: AtomicU32,
    max_depth: u32,
    total_tokens: AtomicU64,
    max_tokens: u64,
    started_at: u64,
    max_duration_secs: u64,
}

impl ToolCallChain {
    /// Create a new chain with the given limits.
    fn new(chain_id: String, max_depth: u32, max_tokens: u64, max_duration_secs: u64) -> Self {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
        Self {
            chain_id,
            records: RwLock::new(Vec::new()),
            depth: AtomicU32::new(0),
            max_depth,
            total_tokens: AtomicU64::new(0),
            max_tokens,
            started_at: now,
            max_duration_secs,
        }
    }

    /// Take a point-in-time snapshot of this chain.
    fn snapshot(&self) -> ToolCallChainSnapshot {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
        ToolCallChainSnapshot {
            chain_id: self.chain_id.clone(),
            records: self.records.read().clone(),
            depth: self.depth.load(Ordering::Relaxed),
            total_tokens: self.total_tokens.load(Ordering::Relaxed),
            elapsed_secs: now.saturating_sub(self.started_at),
        }
    }

    /// Elapsed seconds since the chain was created.
    fn elapsed_secs(&self) -> u64 {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
        now.saturating_sub(self.started_at)
    }
}

// ---------------------------------------------------------------------------
// Snapshot (read-only view)
// ---------------------------------------------------------------------------

/// Point-in-time snapshot of a tool call chain (no locks, safe to send).
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct ToolCallChainSnapshot {
    pub chain_id: String,
    pub records: Vec<ToolCallRecord>,
    pub depth: u32,
    pub total_tokens: u64,
    pub elapsed_secs: u64,
}

// ---------------------------------------------------------------------------
// Stats
// ---------------------------------------------------------------------------

/// Aggregate statistics for the chain manager.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct ToolChainStats {
    /// Number of currently active (tracked) chains.
    pub active_chains: usize,
    /// Total number of chains ever created.
    pub total_chains_created: u64,
}

// ---------------------------------------------------------------------------
// Manager
// ---------------------------------------------------------------------------

/// Registry of active tool call chains with limit enforcement.
pub struct ToolChainManager {
    chains: DashMap<String, ToolCallChain>,
    total_created: AtomicU64,
}

impl ToolChainManager {
    /// Create a new, empty manager.
    pub fn new() -> Self {
        Self {
            chains: DashMap::new(),
            total_created: AtomicU64::new(0),
        }
    }

    /// Create a new tool call chain with the given limits.
    ///
    /// If a chain with the same `chain_id` already exists it is replaced.
    pub fn create_chain(
        &self,
        chain_id: impl Into<String>,
        max_depth: u32,
        max_tokens: u64,
        max_duration_secs: u64,
    ) {
        let id = chain_id.into();
        self.chains.insert(
            id.clone(),
            ToolCallChain::new(id, max_depth, max_tokens, max_duration_secs),
        );
        self.total_created.fetch_add(1, Ordering::Relaxed);
    }

    /// Record a tool call in the given chain.
    ///
    /// Checks depth, token, and duration limits **before** appending the
    /// record. Returns `Err` if any limit would be exceeded.
    pub fn record_call(
        &self,
        chain_id: &str,
        record: ToolCallRecord,
    ) -> Result<(), ToolChainError> {
        // Use get_mut() for exclusive access — prevents TOCTOU races where two
        // concurrent calls both pass limit checks and both commit, exceeding limits.
        let chain = self
            .chains
            .get_mut(chain_id)
            .ok_or_else(|| ToolChainError::ChainNotFound {
                chain_id: chain_id.to_string(),
            })?;

        // Check duration limit
        let elapsed = chain.elapsed_secs();
        if elapsed >= chain.max_duration_secs {
            return Err(ToolChainError::DurationExceeded {
                chain_id: chain_id.to_string(),
                elapsed_secs: elapsed,
                max_secs: chain.max_duration_secs,
            });
        }

        // Check depth limit
        let current_depth = chain.depth.load(Ordering::Relaxed);
        if current_depth >= chain.max_depth {
            return Err(ToolChainError::MaxDepthExceeded {
                chain_id: chain_id.to_string(),
                current: current_depth,
                max: chain.max_depth,
            });
        }

        // Check token budget
        let current_tokens = chain.total_tokens.load(Ordering::Relaxed);
        let new_tokens = current_tokens + record.tokens_used;
        if new_tokens > chain.max_tokens {
            return Err(ToolChainError::TokenBudgetExceeded {
                chain_id: chain_id.to_string(),
                current: new_tokens,
                max: chain.max_tokens,
            });
        }

        // All checks passed — commit (safe: exclusive access via get_mut)
        chain.depth.fetch_add(1, Ordering::Relaxed);
        chain
            .total_tokens
            .fetch_add(record.tokens_used, Ordering::Relaxed);
        chain.records.write().push(record);

        Ok(())
    }

    /// Get a point-in-time snapshot of a chain.
    pub fn get_chain(&self, chain_id: &str) -> Option<ToolCallChainSnapshot> {
        self.chains.get(chain_id).map(|c| c.snapshot())
    }

    /// Remove a chain and return its final snapshot.
    pub fn remove_chain(&self, chain_id: &str) -> Option<ToolCallChainSnapshot> {
        self.chains.remove(chain_id).map(|(_, c)| c.snapshot())
    }

    /// Aggregate statistics across all active chains.
    pub fn stats(&self) -> ToolChainStats {
        ToolChainStats {
            active_chains: self.chains.len(),
            total_chains_created: self.total_created.load(Ordering::Relaxed),
        }
    }
}

impl Default for ToolChainManager {
    fn default() -> Self {
        Self::new()
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    fn make_record(tool: &str, agent: &str, tokens: u64) -> ToolCallRecord {
        ToolCallRecord {
            tool_name: tool.to_string(),
            agent_id: agent.to_string(),
            timestamp: SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs(),
            tokens_used: tokens,
            duration_ms: 100,
        }
    }

    #[test]
    fn create_and_record_calls() {
        let mgr = ToolChainManager::new();
        mgr.create_chain("chain-1", 10, 10_000, 3600);

        let r1 = make_record("search", "agent-a", 50);
        let r2 = make_record("summarize", "agent-a", 120);

        assert!(mgr.record_call("chain-1", r1).is_ok());
        assert!(mgr.record_call("chain-1", r2).is_ok());

        let snap = mgr.get_chain("chain-1").unwrap();
        assert_eq!(snap.depth, 2);
        assert_eq!(snap.total_tokens, 170);
        assert_eq!(snap.records.len(), 2);
        assert_eq!(snap.records[0].tool_name, "search");
        assert_eq!(snap.records[1].tool_name, "summarize");
    }

    #[test]
    fn max_depth_exceeded() {
        let mgr = ToolChainManager::new();
        mgr.create_chain("chain-depth", 2, 100_000, 3600);

        assert!(mgr
            .record_call("chain-depth", make_record("t1", "a", 10))
            .is_ok());
        assert!(mgr
            .record_call("chain-depth", make_record("t2", "a", 10))
            .is_ok());

        // Third call should exceed max_depth=2
        let err = mgr
            .record_call("chain-depth", make_record("t3", "a", 10))
            .unwrap_err();
        assert!(
            matches!(
                err,
                ToolChainError::MaxDepthExceeded {
                    current: 2,
                    max: 2,
                    ..
                }
            ),
            "expected MaxDepthExceeded, got {err:?}"
        );
    }

    #[test]
    fn token_budget_exceeded() {
        let mgr = ToolChainManager::new();
        mgr.create_chain("chain-tok", 100, 500, 3600);

        assert!(mgr
            .record_call("chain-tok", make_record("t1", "a", 300))
            .is_ok());

        // This would bring total to 600, exceeding budget of 500
        let err = mgr
            .record_call("chain-tok", make_record("t2", "a", 300))
            .unwrap_err();
        assert!(
            matches!(err, ToolChainError::TokenBudgetExceeded { max: 500, .. }),
            "expected TokenBudgetExceeded, got {err:?}"
        );

        // Depth should NOT have incremented on failure
        let snap = mgr.get_chain("chain-tok").unwrap();
        assert_eq!(snap.depth, 1);
        assert_eq!(snap.total_tokens, 300);
    }

    #[test]
    fn duration_exceeded() {
        let mgr = ToolChainManager::new();

        // Create a chain with max_duration_secs = 0 so it's immediately expired
        let chain_id = "chain-dur".to_string();
        let chain = ToolCallChain {
            chain_id: chain_id.clone(),
            records: RwLock::new(Vec::new()),
            depth: AtomicU32::new(0),
            max_depth: 100,
            total_tokens: AtomicU64::new(0),
            max_tokens: 100_000,
            // Started 1000 seconds ago
            started_at: SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs()
                .saturating_sub(1000),
            max_duration_secs: 60, // 60s limit, but 1000s elapsed
        };
        mgr.chains.insert(chain_id.clone(), chain);
        mgr.total_created.fetch_add(1, Ordering::Relaxed);

        let err = mgr
            .record_call("chain-dur", make_record("t1", "a", 10))
            .unwrap_err();
        assert!(
            matches!(err, ToolChainError::DurationExceeded { max_secs: 60, .. }),
            "expected DurationExceeded, got {err:?}"
        );
    }

    #[test]
    fn get_chain_snapshot() {
        let mgr = ToolChainManager::new();
        mgr.create_chain("snap-chain", 10, 10_000, 3600);

        mgr.record_call("snap-chain", make_record("search", "agent-1", 100))
            .unwrap();
        mgr.record_call("snap-chain", make_record("fetch", "agent-2", 200))
            .unwrap();

        let snap = mgr.get_chain("snap-chain").unwrap();
        assert_eq!(snap.chain_id, "snap-chain");
        assert_eq!(snap.depth, 2);
        assert_eq!(snap.total_tokens, 300);
        assert_eq!(snap.records.len(), 2);
        assert_eq!(snap.records[0].agent_id, "agent-1");
        assert_eq!(snap.records[1].agent_id, "agent-2");

        // Elapsed should be very small (test runs in <1s)
        assert!(snap.elapsed_secs < 5);
    }

    #[test]
    fn chain_not_found() {
        let mgr = ToolChainManager::new();

        let err = mgr
            .record_call("nonexistent", make_record("t1", "a", 10))
            .unwrap_err();
        assert!(
            matches!(err, ToolChainError::ChainNotFound { .. }),
            "expected ChainNotFound, got {err:?}"
        );
        assert!(mgr.get_chain("nonexistent").is_none());
    }

    #[test]
    fn remove_chain_returns_snapshot() {
        let mgr = ToolChainManager::new();
        mgr.create_chain("rm-chain", 10, 10_000, 3600);
        mgr.record_call("rm-chain", make_record("t1", "a", 50))
            .unwrap();

        let snap = mgr.remove_chain("rm-chain").unwrap();
        assert_eq!(snap.chain_id, "rm-chain");
        assert_eq!(snap.depth, 1);
        assert_eq!(snap.total_tokens, 50);

        // Should be gone now
        assert!(mgr.get_chain("rm-chain").is_none());
        assert!(mgr.remove_chain("rm-chain").is_none());
    }

    #[test]
    fn stats_tracks_counts() {
        let mgr = ToolChainManager::new();

        let s0 = mgr.stats();
        assert_eq!(s0.active_chains, 0);
        assert_eq!(s0.total_chains_created, 0);

        mgr.create_chain("c1", 10, 10_000, 3600);
        mgr.create_chain("c2", 10, 10_000, 3600);

        let s1 = mgr.stats();
        assert_eq!(s1.active_chains, 2);
        assert_eq!(s1.total_chains_created, 2);

        mgr.remove_chain("c1");

        let s2 = mgr.stats();
        assert_eq!(s2.active_chains, 1);
        assert_eq!(s2.total_chains_created, 2); // Total doesn't decrease
    }
}
