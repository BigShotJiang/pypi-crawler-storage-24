// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! # Retry Budget
//!
//! Linkerd-style retry budget that prevents retry storms by limiting the ratio
//! of retries to total requests over a sliding window.
//!
//! Under normal conditions, retries are unlimited (bounded by the per-request
//! retry policy). Under load, the budget limits total retry rate to prevent
//! cascading failures.
//!
//! ## Design
//!
//! All counters are behind a single `Mutex` so that `can_retry()` reads a
//! consistent (requests, retries) pair. A lock-free design with separate
//! atomics would allow a window reset between the two reads, producing a
//! ratio computed from stale numerator and fresh denominator (or vice versa).
//! The Mutex is uncontended in practice (~10ns with parking_lot) because
//! budget checks happen once per retry decision, not per request.

use std::time::Duration;

use parking_lot::Mutex;

struct Counters {
    recent_requests: u64,
    recent_retries: u64,
    last_reset_ms: u64,
}

/// Retry budget that limits retry rate as a fraction of total requests.
pub struct RetryBudget {
    counters: Mutex<Counters>,
    /// Maximum retry ratio (e.g., 0.2 = 20% of requests can be retries).
    max_retry_ratio: f64,
    /// Always allow at least this many retries per second, even if ratio is exceeded.
    min_retries_per_second: u64,
    /// Window duration for tracking.
    window: Duration,
}

impl RetryBudget {
    pub fn new(max_retry_ratio: f64, min_retries_per_second: u64, window: Duration) -> Self {
        let now_ms = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis() as u64;

        Self {
            counters: Mutex::new(Counters {
                recent_requests: 0,
                recent_retries: 0,
                last_reset_ms: now_ms,
            }),
            max_retry_ratio,
            min_retries_per_second,
            window,
        }
    }

    /// Check if a retry is allowed by the budget.
    pub fn can_retry(&self) -> bool {
        let mut c = self.counters.lock();
        Self::maybe_reset(&mut c, &self.window);

        // Always allow minimum retries
        let window_secs = self.window.as_secs_f64();
        let min_allowed = (self.min_retries_per_second as f64 * window_secs) as u64;
        if c.recent_retries < min_allowed {
            return true;
        }

        // Check ratio (consistent read — both values from the same lock scope)
        if c.recent_requests == 0 {
            return true;
        }

        let ratio = c.recent_retries as f64 / c.recent_requests as f64;
        ratio < self.max_retry_ratio
    }

    /// Record a new request (not a retry).
    pub fn record_request(&self) {
        let mut c = self.counters.lock();
        Self::maybe_reset(&mut c, &self.window);
        c.recent_requests += 1;
    }

    /// Record a retry attempt.
    pub fn record_retry(&self) {
        let mut c = self.counters.lock();
        Self::maybe_reset(&mut c, &self.window);
        c.recent_retries += 1;
    }

    /// Atomically check budget and record a retry in one lock scope.
    ///
    /// Eliminates the TOCTOU race between `can_retry()` + `record_retry()`:
    /// without this, two threads could both see budget=1, both pass the check,
    /// and both record — exceeding the budget by 1.
    pub fn try_consume_retry(&self) -> bool {
        let mut c = self.counters.lock();
        Self::maybe_reset(&mut c, &self.window);

        // Always allow minimum retries
        let window_secs = self.window.as_secs_f64();
        let min_allowed = (self.min_retries_per_second as f64 * window_secs) as u64;
        if c.recent_retries < min_allowed {
            c.recent_retries += 1;
            return true;
        }

        // Check ratio
        if c.recent_requests == 0 {
            c.recent_retries += 1;
            return true;
        }

        let ratio = c.recent_retries as f64 / c.recent_requests as f64;
        if ratio < self.max_retry_ratio {
            c.recent_retries += 1;
            true
        } else {
            false
        }
    }

    /// Current retry ratio.
    pub fn retry_ratio(&self) -> f64 {
        let c = self.counters.lock();
        if c.recent_requests == 0 {
            return 0.0;
        }
        c.recent_retries as f64 / c.recent_requests as f64
    }

    /// Reset counters if the window has elapsed.
    fn maybe_reset(c: &mut Counters, window: &Duration) {
        let now_ms = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis() as u64;

        let window_ms = window.as_millis() as u64;

        if now_ms.saturating_sub(c.last_reset_ms) >= window_ms {
            c.recent_requests = 0;
            c.recent_retries = 0;
            c.last_reset_ms = now_ms;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn allows_under_ratio() {
        let budget = RetryBudget::new(0.2, 0, Duration::from_secs(60));

        // 10 requests
        for _ in 0..10 {
            budget.record_request();
        }

        // 1 retry (10%) should be allowed (under 20%)
        budget.record_retry();
        assert!(budget.can_retry());
    }

    #[test]
    fn blocks_over_ratio() {
        let budget = RetryBudget::new(0.2, 0, Duration::from_secs(60));

        // 10 requests
        for _ in 0..10 {
            budget.record_request();
        }

        // 3 retries (30%) — over 20% limit
        for _ in 0..3 {
            budget.record_retry();
        }

        assert!(!budget.can_retry());
    }

    #[test]
    fn always_allows_minimum() {
        let budget = RetryBudget::new(0.0, 10, Duration::from_secs(60));

        // Ratio is 0% but min is 10/sec, so 600 retries in 60s window
        // With no requests, retries < min_allowed (600), so should be allowed
        assert!(budget.can_retry());
    }

    #[test]
    fn empty_budget_allows() {
        let budget = RetryBudget::new(0.2, 0, Duration::from_secs(60));
        // No requests, no retries — should allow
        assert!(budget.can_retry());
    }

    #[test]
    fn retry_ratio_tracks() {
        let budget = RetryBudget::new(0.5, 0, Duration::from_secs(60));

        for _ in 0..10 {
            budget.record_request();
        }
        for _ in 0..3 {
            budget.record_retry();
        }

        let ratio = budget.retry_ratio();
        assert!((ratio - 0.3).abs() < 0.01);
    }

    #[test]
    fn try_consume_retry_atomic() {
        let budget = RetryBudget::new(0.2, 0, Duration::from_secs(60));

        for _ in 0..10 {
            budget.record_request();
        }

        // 1 retry (10%) — under 20%, should succeed
        assert!(budget.try_consume_retry());
        // Now at 1/10 = 10%, still under
        assert!(budget.try_consume_retry());
        // Now at 2/10 = 20%, at limit — should fail
        assert!(!budget.try_consume_retry());
        // Counter should NOT have incremented on failure
        assert!((budget.retry_ratio() - 0.2).abs() < 0.01);
    }
}
