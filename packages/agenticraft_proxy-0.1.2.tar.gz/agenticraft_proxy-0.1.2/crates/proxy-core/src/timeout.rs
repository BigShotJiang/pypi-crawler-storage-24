// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! # Timeout Configuration
//!
//! Layered timeout enforcement for LLM proxy requests.
//!
//! ## Nesting (outermost → innermost)
//!
//! ```text
//! request_timeout {
//!     bulkhead.acquire()           // cancelled by request_timeout
//!     provider_timeout {
//!         connect_timeout {
//!             TCP connect
//!         }
//!         provider.send(request)
//!     }
//! }
//! ```
//!
//! If queued behind a bulkhead and `request_timeout` expires, the outer
//! timeout cancels the bulkhead wait — the request never reaches the provider.

use std::time::Duration;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Layered timeout configuration.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct TimeoutConfig {
    /// Outermost timeout — covers the entire request lifecycle including
    /// bulkhead wait, routing, provider call, and response streaming.
    pub request_timeout: Duration,

    /// Per-provider call timeout — covers connect + send + receive.
    /// Must be less than `request_timeout` to leave room for bulkhead wait.
    pub provider_timeout: Duration,

    /// TCP connect timeout — innermost layer.
    pub connect_timeout: Duration,
}

impl Default for TimeoutConfig {
    fn default() -> Self {
        Self {
            request_timeout: Duration::from_secs(60),
            provider_timeout: Duration::from_secs(30),
            connect_timeout: Duration::from_secs(5),
        }
    }
}

impl TimeoutConfig {
    pub fn new(request_secs: u64, provider_secs: u64, connect_secs: u64) -> Self {
        Self {
            request_timeout: Duration::from_secs(request_secs),
            provider_timeout: Duration::from_secs(provider_secs),
            connect_timeout: Duration::from_secs(connect_secs),
        }
    }

    /// Validate that timeouts are properly nested (request > provider > connect).
    pub fn validate(&self) -> Result<(), String> {
        if self.provider_timeout >= self.request_timeout {
            return Err(format!(
                "provider_timeout ({:?}) must be less than request_timeout ({:?})",
                self.provider_timeout, self.request_timeout
            ));
        }
        if self.connect_timeout >= self.provider_timeout {
            return Err(format!(
                "connect_timeout ({:?}) must be less than provider_timeout ({:?})",
                self.connect_timeout, self.provider_timeout
            ));
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_timeout_valid() {
        let config = TimeoutConfig::default();
        assert!(config.validate().is_ok());
    }

    #[test]
    fn valid_custom_timeout() {
        let config = TimeoutConfig::new(120, 60, 10);
        assert!(config.validate().is_ok());
    }

    #[test]
    fn provider_exceeds_request_invalid() {
        let config = TimeoutConfig::new(30, 60, 5);
        assert!(config.validate().is_err());
    }

    #[test]
    fn connect_exceeds_provider_invalid() {
        let config = TimeoutConfig::new(60, 10, 15);
        assert!(config.validate().is_err());
    }

    #[test]
    fn equal_timeouts_invalid() {
        let config = TimeoutConfig::new(30, 30, 5);
        assert!(config.validate().is_err());
    }

    #[tokio::test]
    async fn timeout_passes_fast_request() {
        let config = TimeoutConfig::new(5, 3, 1);
        let result = tokio::time::timeout(config.request_timeout, async {
            tokio::time::timeout(config.provider_timeout, async { 42 })
                .await
                .unwrap()
        })
        .await;
        assert_eq!(result.unwrap(), 42);
    }

    #[tokio::test]
    async fn timeout_cancels_slow_request() {
        let config = TimeoutConfig::new(1, 1, 1);
        let result = tokio::time::timeout(config.provider_timeout, async {
            tokio::time::sleep(Duration::from_secs(10)).await;
            42
        })
        .await;
        assert!(result.is_err()); // Elapsed
    }
}
