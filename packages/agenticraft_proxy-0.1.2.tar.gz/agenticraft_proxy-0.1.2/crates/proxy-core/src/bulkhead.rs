// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! # Bulkhead Pattern
//!
//! Limits concurrent requests per provider. Unlike circuit breakers (react to
//! failures), bulkheads proactively prevent resource exhaustion from slow providers.
//!
//! ## Why not just circuit breakers?
//! A provider can return 200 OK but with 30s latency. CB won't trip. But 50
//! concurrent 30s requests consume all connections, starving other providers.

use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;

use thiserror::Error;
use tokio::sync::{OwnedSemaphorePermit, Semaphore, TryAcquireError};

#[derive(Debug, Error)]
pub enum BulkheadError {
    #[error("bulkhead `{name}` rejected: {current}/{max_concurrent} active, queue full ({queued}/{queue_size})")]
    Rejected {
        name: String,
        current: usize,
        max_concurrent: usize,
        queued: usize,
        queue_size: usize,
    },
}

/// RAII permit that releases the bulkhead slot on drop.
pub struct BulkheadPermit {
    _permit: OwnedSemaphorePermit,
    queued: Arc<AtomicUsize>,
    was_queued: bool,
}

impl Drop for BulkheadPermit {
    fn drop(&mut self) {
        if self.was_queued {
            self.queued.fetch_sub(1, Ordering::Relaxed);
        }
    }
}

/// Concurrency limiter for a single provider.
pub struct Bulkhead {
    semaphore: Arc<Semaphore>,
    max_concurrent: usize,
    queue_size: usize,
    /// Approximate number of waiters (observability only — not for rejection).
    queued: Arc<AtomicUsize>,
    name: String,
}

impl Bulkhead {
    pub fn new(name: impl Into<String>, max_concurrent: usize, queue_size: usize) -> Self {
        Self {
            semaphore: Arc::new(Semaphore::new(max_concurrent)),
            max_concurrent,
            queue_size,
            queued: Arc::new(AtomicUsize::new(0)),
            name: name.into(),
        }
    }

    /// Try to acquire a permit immediately (no waiting).
    pub fn try_acquire(&self) -> Result<BulkheadPermit, BulkheadError> {
        match self.semaphore.clone().try_acquire_owned() {
            Ok(permit) => Ok(BulkheadPermit {
                _permit: permit,
                queued: self.queued.clone(),
                was_queued: false,
            }),
            Err(TryAcquireError::NoPermits) => {
                let queued = self.queued.load(Ordering::Relaxed);
                Err(BulkheadError::Rejected {
                    name: self.name.clone(),
                    current: self.max_concurrent,
                    max_concurrent: self.max_concurrent,
                    queued,
                    queue_size: self.queue_size,
                })
            }
            Err(TryAcquireError::Closed) => Err(BulkheadError::Rejected {
                name: self.name.clone(),
                current: 0,
                max_concurrent: self.max_concurrent,
                queued: 0,
                queue_size: self.queue_size,
            }),
        }
    }

    /// Acquire a permit, waiting if necessary. Rejects if queue is full.
    pub async fn acquire(&self) -> Result<BulkheadPermit, BulkheadError> {
        // Fast path: try without queuing
        match self.semaphore.clone().try_acquire_owned() {
            Ok(permit) => {
                return Ok(BulkheadPermit {
                    _permit: permit,
                    queued: self.queued.clone(),
                    was_queued: false,
                });
            }
            Err(TryAcquireError::Closed) => {
                return Err(BulkheadError::Rejected {
                    name: self.name.clone(),
                    current: 0,
                    max_concurrent: self.max_concurrent,
                    queued: 0,
                    queue_size: self.queue_size,
                });
            }
            Err(TryAcquireError::NoPermits) => {
                // Fall through to queuing path
            }
        }

        // Check queue capacity (approximate — race is acceptable for observability)
        let queued = self.queued.fetch_add(1, Ordering::Relaxed);
        if queued >= self.queue_size {
            self.queued.fetch_sub(1, Ordering::Relaxed);
            return Err(BulkheadError::Rejected {
                name: self.name.clone(),
                current: self.max_concurrent,
                max_concurrent: self.max_concurrent,
                queued,
                queue_size: self.queue_size,
            });
        }

        // Wait for a permit
        let permit =
            self.semaphore
                .clone()
                .acquire_owned()
                .await
                .map_err(|_| BulkheadError::Rejected {
                    name: self.name.clone(),
                    current: 0,
                    max_concurrent: self.max_concurrent,
                    queued: 0,
                    queue_size: self.queue_size,
                })?;

        Ok(BulkheadPermit {
            _permit: permit,
            queued: self.queued.clone(),
            was_queued: true,
        })
    }

    /// Current number of queued waiters (approximate).
    pub fn queued(&self) -> usize {
        self.queued.load(Ordering::Relaxed)
    }

    /// Number of available permits.
    pub fn available(&self) -> usize {
        self.semaphore.available_permits()
    }

    /// Maximum concurrent requests.
    pub fn max_concurrent(&self) -> usize {
        self.max_concurrent
    }

    /// Name of this bulkhead (typically provider name).
    pub fn name(&self) -> &str {
        &self.name
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn allows_under_limit() {
        let bh = Bulkhead::new("test", 2, 10);
        let _p1 = bh.acquire().await.unwrap();
        let _p2 = bh.acquire().await.unwrap();
        assert_eq!(bh.available(), 0);
    }

    #[tokio::test]
    async fn blocks_at_capacity() {
        let bh = Bulkhead::new("test", 1, 0);
        let _p1 = bh.acquire().await.unwrap();
        // Queue size is 0, so next request should be rejected immediately
        let result = bh.acquire().await;
        assert!(result.is_err());
    }

    #[tokio::test]
    async fn queues_waiters() {
        let bh = Arc::new(Bulkhead::new("test", 1, 10));
        let p1 = bh.acquire().await.unwrap();

        let bh2 = bh.clone();
        let handle = tokio::spawn(async move { bh2.acquire().await });

        // Give the spawned task time to enqueue
        tokio::time::sleep(std::time::Duration::from_millis(10)).await;
        assert!(bh.queued() > 0);

        // Release first permit
        drop(p1);
        let p2 = handle.await.unwrap();
        assert!(p2.is_ok());
    }

    #[tokio::test]
    async fn rejects_queue_full() {
        let bh = Bulkhead::new("test", 1, 0);
        let _p1 = bh.acquire().await.unwrap();
        let result = bh.acquire().await;
        assert!(result.is_err());
        if let Err(BulkheadError::Rejected {
            queue_size, queued, ..
        }) = result
        {
            assert_eq!(queue_size, 0);
            assert_eq!(queued, 0); // Was cleaned up
        }
    }

    #[tokio::test]
    async fn permit_raii_drop() {
        let bh = Bulkhead::new("test", 1, 10);
        {
            let _p = bh.acquire().await.unwrap();
            assert_eq!(bh.available(), 0);
        }
        // Permit dropped, slot should be available again
        assert_eq!(bh.available(), 1);
    }

    #[tokio::test]
    async fn queued_counter_approximate() {
        let bh = Arc::new(Bulkhead::new("test", 1, 100));
        let _p = bh.acquire().await.unwrap();

        // Spawn multiple waiters
        let mut handles = vec![];
        for _ in 0..3 {
            let bh2 = bh.clone();
            handles.push(tokio::spawn(async move { bh2.acquire().await }));
        }

        tokio::time::sleep(std::time::Duration::from_millis(20)).await;
        let q = bh.queued();
        assert!(q > 0, "expected some queued, got {q}");

        drop(_p);
        for h in handles {
            let _ = h.await;
        }
    }

    #[tokio::test]
    async fn try_acquire_immediate() {
        let bh = Bulkhead::new("test", 2, 10);
        let _p1 = bh.try_acquire().unwrap();
        let _p2 = bh.try_acquire().unwrap();
        assert!(bh.try_acquire().is_err());
    }

    #[tokio::test]
    async fn per_provider_independent() {
        let bh_a = Bulkhead::new("provider_a", 1, 0);
        let bh_b = Bulkhead::new("provider_b", 1, 0);

        let _pa = bh_a.acquire().await.unwrap();
        // Provider B should still be available
        let _pb = bh_b.acquire().await.unwrap();

        // Provider A should be full
        assert!(bh_a.acquire().await.is_err());
        // Provider B should also be full
        assert!(bh_b.acquire().await.is_err());
    }
}
