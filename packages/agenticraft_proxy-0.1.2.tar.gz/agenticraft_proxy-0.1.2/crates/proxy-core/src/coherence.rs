// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Multi-instance state coherence (S5).
//!
//! Defines coherence categories for every piece of shared state in the proxy.
//! In a multi-instance deployment behind a load balancer, each DashMap is
//! local — without synchronization, instances diverge.
//!
//! ## Coherence categories
//!
//! | Category              | Mechanism                          | Features                     |
//! |-----------------------|------------------------------------|------------------------------|
//! | Eventually consistent | NATS JetStream pub/sub             | F1 cache inv, F2 config, F19 |
//! | Strongly consistent   | Sticky routing (hash agent_id)     | F6, F7, F10, F16, F17        |
//! | Broadcast             | gRPC fan-out from control plane    | F8, F14, F18                 |
//! | Local-only            | Per-instance is correct             | F15 compliance, F31 metrics  |
//! | Atomic counters       | Local AtomicU64 + NATS KV CAS sync | F5 budgets                   |

use std::fmt;

/// How a piece of shared state is kept coherent across proxy instances.
///
/// Every `DashMap` in `AppState` **must** have a coherence category comment.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum CoherenceMode {
    /// State is synced via NATS JetStream pub/sub.
    /// Eventual consistency with configurable lag.
    EventuallyConsistent,

    /// Requests for this state are routed to a consistent instance
    /// via sticky routing (e.g., hash of `agent_id`).
    StronglyConsistent,

    /// State is pushed from the control plane to all instances via gRPC.
    /// All instances receive the same update atomically.
    Broadcast,

    /// No synchronization needed — per-instance state is correct.
    /// Examples: append-only compliance logs, Prometheus metrics.
    LocalOnly,

    /// Local fast-path with periodic NATS KV CAS reconciliation.
    /// Used for budget counters where immediate consistency is not required
    /// but eventual accuracy is.
    AtomicCounters,
}

impl fmt::Display for CoherenceMode {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::EventuallyConsistent => write!(f, "eventually_consistent"),
            Self::StronglyConsistent => write!(f, "strongly_consistent"),
            Self::Broadcast => write!(f, "broadcast"),
            Self::LocalOnly => write!(f, "local_only"),
            Self::AtomicCounters => write!(f, "atomic_counters"),
        }
    }
}

/// Trait for state that can be synchronized across instances.
///
/// Implementors define how to serialize state changes for replication
/// and how to apply incoming replicated state.
pub trait StateSync: Send + Sync {
    /// The coherence mode for this state.
    fn coherence_mode(&self) -> CoherenceMode;

    /// Serialize a state change for replication.
    /// Returns `None` if the state doesn't need replication (LocalOnly).
    fn serialize_change(&self, key: &str) -> Option<Vec<u8>>;

    /// Apply a replicated state change from another instance.
    fn apply_change(&self, key: &str, data: &[u8]) -> Result<(), String>;
}

/// Deployment mode for the proxy.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum DeploymentMode {
    /// Single instance — no synchronization needed.
    #[default]
    SingleInstance,
    /// Multiple instances behind a load balancer.
    MultiInstance,
}

/// Registry of state coherence requirements.
///
/// Used to validate that all shared state has an assigned coherence mode
/// and to generate documentation for operators.
pub struct CoherenceRegistry {
    entries: Vec<CoherenceEntry>,
}

/// A registered piece of shared state with its coherence requirements.
#[derive(Debug, Clone)]
pub struct CoherenceEntry {
    /// Name of the state (e.g., "semantic_cache", "budget_hierarchy").
    pub name: String,
    /// Feature this state belongs to.
    pub feature: String,
    /// Coherence mode.
    pub mode: CoherenceMode,
    /// Human-readable description.
    pub description: String,
}

impl CoherenceRegistry {
    /// Create a new registry with all known state coherence requirements.
    pub fn new() -> Self {
        let entries = vec![
            // F1: Semantic cache — invalidation events synced via NATS
            CoherenceEntry {
                name: "semantic_cache".into(),
                feature: "F1".into(),
                mode: CoherenceMode::EventuallyConsistent,
                description: "Cache invalidation events broadcast via NATS JetStream".into(),
            },
            // F2: Output guardrails config — synced via NATS
            CoherenceEntry {
                name: "output_guardrails_config".into(),
                feature: "F2".into(),
                mode: CoherenceMode::EventuallyConsistent,
                description: "Guardrail configuration changes broadcast via NATS".into(),
            },
            // F5: Budget hierarchy — local AtomicU64 + NATS KV CAS sync
            CoherenceEntry {
                name: "budget_hierarchy".into(),
                feature: "F5".into(),
                mode: CoherenceMode::AtomicCounters,
                description: "Local fast-path with periodic NATS KV reconciliation".into(),
            },
            // F6: Tool call chain — sticky routing by agent_id
            CoherenceEntry {
                name: "tool_chain".into(),
                feature: "F6".into(),
                mode: CoherenceMode::StronglyConsistent,
                description: "Routed to consistent instance via agent_id hash".into(),
            },
            // F7: Workflow budget — sticky routing by workflow_id
            CoherenceEntry {
                name: "workflow_budget".into(),
                feature: "F7".into(),
                mode: CoherenceMode::StronglyConsistent,
                description: "Routed to consistent instance via workflow_id hash".into(),
            },
            // F8: WASM policy — broadcast from control plane
            CoherenceEntry {
                name: "wasm_policy".into(),
                feature: "F8".into(),
                mode: CoherenceMode::Broadcast,
                description: "Policy graphs pushed from control plane via gRPC".into(),
            },
            // F10: Agent memory — sticky routing by agent_id
            CoherenceEntry {
                name: "memory_gateway".into(),
                feature: "F10".into(),
                mode: CoherenceMode::StronglyConsistent,
                description: "Memory reads/writes routed to consistent instance".into(),
            },
            // F14: Cedar policy — broadcast from control plane
            CoherenceEntry {
                name: "cedar_policy".into(),
                feature: "F14".into(),
                mode: CoherenceMode::Broadcast,
                description: "Cedar policies pushed from control plane via gRPC".into(),
            },
            // F15: Compliance audit — local-only (per-instance chain)
            CoherenceEntry {
                name: "compliance_engine".into(),
                feature: "F15".into(),
                mode: CoherenceMode::LocalOnly,
                description: "Append-only audit log per instance, independently verifiable".into(),
            },
            // F16: SLA tracking — sticky routing
            CoherenceEntry {
                name: "sla_engine".into(),
                feature: "F16".into(),
                mode: CoherenceMode::StronglyConsistent,
                description: "SLA observations routed to consistent instance".into(),
            },
            // F17: HITL pending approvals — sticky routing
            CoherenceEntry {
                name: "hitl_manager".into(),
                feature: "F17".into(),
                mode: CoherenceMode::StronglyConsistent,
                description: "Pending approvals routed to consistent instance".into(),
            },
            // F18: Governance — broadcast from control plane
            CoherenceEntry {
                name: "governance_manager".into(),
                feature: "F18".into(),
                mode: CoherenceMode::Broadcast,
                description: "Governance policies pushed from control plane".into(),
            },
            // F19: Zero-trust behavioral baselines — eventually consistent
            CoherenceEntry {
                name: "zero_trust_engine".into(),
                feature: "F19".into(),
                mode: CoherenceMode::EventuallyConsistent,
                description: "Behavioral baselines synced via NATS JetStream".into(),
            },
            // F23: Fraud scores — eventually consistent
            CoherenceEntry {
                name: "fraud_detector".into(),
                feature: "F23".into(),
                mode: CoherenceMode::EventuallyConsistent,
                description: "Fraud scores synced via NATS JetStream".into(),
            },
            // F31: LLM metrics — local-only (Prometheus scrapes all instances)
            CoherenceEntry {
                name: "llm_metrics".into(),
                feature: "F31".into(),
                mode: CoherenceMode::LocalOnly,
                description: "Per-instance Prometheus metrics, scraped individually".into(),
            },
        ];
        Self { entries }
    }

    /// Get all entries.
    pub fn entries(&self) -> &[CoherenceEntry] {
        &self.entries
    }

    /// Get entries that require NATS for synchronization.
    pub fn nats_required_entries(&self) -> Vec<&CoherenceEntry> {
        self.entries
            .iter()
            .filter(|e| {
                matches!(
                    e.mode,
                    CoherenceMode::EventuallyConsistent | CoherenceMode::AtomicCounters
                )
            })
            .collect()
    }

    /// Get entries that require sticky routing.
    pub fn sticky_routing_entries(&self) -> Vec<&CoherenceEntry> {
        self.entries
            .iter()
            .filter(|e| e.mode == CoherenceMode::StronglyConsistent)
            .collect()
    }

    /// Check if multi-instance deployment requires NATS.
    pub fn requires_nats(&self, features_enabled: &[&str]) -> bool {
        self.entries.iter().any(|e| {
            features_enabled.contains(&e.feature.as_str())
                && matches!(
                    e.mode,
                    CoherenceMode::EventuallyConsistent | CoherenceMode::AtomicCounters
                )
        })
    }
}

impl Default for CoherenceRegistry {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn registry_has_all_features() {
        let reg = CoherenceRegistry::new();
        assert!(reg.entries().len() >= 15);
    }

    #[test]
    fn nats_required_entries_are_correct() {
        let reg = CoherenceRegistry::new();
        let nats_entries = reg.nats_required_entries();
        for entry in &nats_entries {
            assert!(matches!(
                entry.mode,
                CoherenceMode::EventuallyConsistent | CoherenceMode::AtomicCounters
            ));
        }
    }

    #[test]
    fn sticky_routing_entries_are_correct() {
        let reg = CoherenceRegistry::new();
        let sticky_entries = reg.sticky_routing_entries();
        for entry in &sticky_entries {
            assert_eq!(entry.mode, CoherenceMode::StronglyConsistent);
        }
    }

    #[test]
    fn requires_nats_when_f1_enabled() {
        let reg = CoherenceRegistry::new();
        assert!(reg.requires_nats(&["F1"]));
    }

    #[test]
    fn does_not_require_nats_for_local_only() {
        let reg = CoherenceRegistry::new();
        assert!(!reg.requires_nats(&["F15", "F31"]));
    }

    #[test]
    fn deployment_mode_default_is_single() {
        assert_eq!(DeploymentMode::default(), DeploymentMode::SingleInstance);
    }

    #[test]
    fn coherence_mode_display() {
        assert_eq!(
            CoherenceMode::EventuallyConsistent.to_string(),
            "eventually_consistent"
        );
        assert_eq!(CoherenceMode::AtomicCounters.to_string(), "atomic_counters");
    }
}
