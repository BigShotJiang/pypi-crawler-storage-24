// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Token bucket rate limiter with injectable clock.

use std::sync::Arc;

use parking_lot::Mutex;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

use crate::clock::{Clock, MonotonicClock};
use crate::error::{ProxyError, Result};

/// Configuration for a token bucket rate limiter.
#[derive(Debug, Clone)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct RateLimitConfig {
    /// Maximum calls allowed in the time window.
    pub max_calls: u64,
    /// Time window in seconds.
    pub time_window_secs: f64,
    /// Burst size (bucket capacity). Defaults to `max_calls` if `None`.
    pub burst_size: Option<u64>,
}

impl RateLimitConfig {
    pub fn new(max_calls: u64, time_window_secs: f64) -> Self {
        Self {
            max_calls,
            time_window_secs,
            burst_size: None,
        }
    }

    pub fn with_burst(mut self, burst: u64) -> Self {
        self.burst_size = Some(burst);
        self
    }

    fn capacity(&self) -> u64 {
        self.burst_size.unwrap_or(self.max_calls)
    }

    fn refill_rate(&self) -> f64 {
        if self.time_window_secs <= 0.0 {
            return f64::MAX;
        }
        self.max_calls as f64 / self.time_window_secs
    }
}

/// Metrics snapshot for a token bucket.
#[derive(Debug, Clone, Default)]
pub struct TokenBucketMetrics {
    pub total_acquired: u64,
    pub total_rejected: u64,
}

struct Inner {
    tokens: f64,
    capacity: u64,
    refill_rate: f64,
    last_refill: f64,
    metrics: TokenBucketMetrics,
}

/// Thread-safe token bucket rate limiter.
///
/// Uses [`parking_lot::Mutex`] (non-poisoning) and an injectable [`Clock`]
/// for deterministic testing.
pub struct TokenBucket {
    inner: Mutex<Inner>,
    clock: Arc<dyn Clock>,
}

// parking_lot::Mutex is Send+Sync, Arc<dyn Clock> requires Send+Sync on Clock
unsafe impl Send for TokenBucket {}
unsafe impl Sync for TokenBucket {}

/// Refill tokens based on elapsed time. Called under lock.
fn refill(inner: &mut Inner, now: f64) {
    let elapsed = now - inner.last_refill;
    if elapsed > 0.0 {
        inner.tokens = (inner.tokens + elapsed * inner.refill_rate).min(inner.capacity as f64);
        inner.last_refill = now;
    }
}

impl TokenBucket {
    /// Create a new token bucket from config, using the real monotonic clock.
    pub fn new(config: &RateLimitConfig) -> Self {
        Self::with_clock(config, Arc::new(MonotonicClock::new()))
    }

    /// Create a new token bucket with an injectable clock.
    pub fn with_clock(config: &RateLimitConfig, clock: Arc<dyn Clock>) -> Self {
        let capacity = config.capacity();
        let now = clock.now_secs();
        Self {
            inner: Mutex::new(Inner {
                tokens: capacity as f64,
                capacity,
                refill_rate: config.refill_rate(),
                last_refill: now,
                metrics: TokenBucketMetrics::default(),
            }),
            clock,
        }
    }

    /// Try to acquire `n` tokens. Returns `Ok(())` on success.
    ///
    /// On failure the error includes `retry_after_secs` — an advisory wait
    /// computed inside the same lock scope (zero extra locking).
    pub fn try_acquire(&self, n: u64) -> Result<()> {
        let mut inner = self.inner.lock();
        let now = self.clock.now_secs();
        refill(&mut inner, now);

        let n_f = n as f64;
        if inner.tokens >= n_f {
            inner.tokens -= n_f;
            inner.metrics.total_acquired += n;
            Ok(())
        } else {
            inner.metrics.total_rejected += n;
            let deficit = n_f - inner.tokens;
            let retry_after_secs = if inner.refill_rate <= 0.0 || inner.refill_rate == f64::MAX {
                1.0
            } else {
                (deficit / inner.refill_rate).max(1.0)
            };
            Err(ProxyError::RateLimited {
                available: inner.tokens,
                requested: n,
                retry_after_secs,
            })
        }
    }

    /// Number of tokens currently available (performs refill).
    pub fn available_tokens(&self) -> f64 {
        let mut inner = self.inner.lock();
        let now = self.clock.now_secs();
        refill(&mut inner, now);
        inner.tokens
    }

    /// Maximum burst capacity of the token bucket.
    pub fn capacity(&self) -> u64 {
        self.inner.lock().capacity
    }

    /// Estimated seconds until the bucket is fully refilled from current level.
    ///
    /// Returns 0 if already full. Used for IETF `RateLimit-Reset` header.
    pub fn time_to_full_secs(&self) -> u64 {
        let mut inner = self.inner.lock();
        let now = self.clock.now_secs();
        refill(&mut inner, now);
        let deficit = inner.capacity as f64 - inner.tokens;
        if deficit <= 0.0 || inner.refill_rate <= 0.0 || inner.refill_rate == f64::MAX {
            0
        } else {
            (deficit / inner.refill_rate).ceil() as u64
        }
    }

    /// Hot-reload configuration.
    ///
    /// CRITICAL: Must refill with the OLD rate before applying new config.
    /// Without this, changing rate from 10000/min → 10/min could overflow
    /// the bucket on the next tick due to stale elapsed-time × new-rate.
    pub fn update_config(&self, config: &RateLimitConfig) {
        let mut inner = self.inner.lock();
        let now = self.clock.now_secs();
        refill(&mut inner, now);

        // Now safe to apply new config
        inner.capacity = config.capacity();
        inner.refill_rate = config.refill_rate();
        inner.tokens = inner.tokens.min(config.capacity() as f64);
    }

    /// Deduct `n` tokens unconditionally. Used for post-response accounting
    /// where tokens are already consumed. Bucket clamps to 0, blocking future
    /// requests until refill.
    pub fn force_deduct(&self, n: u64) {
        let mut inner = self.inner.lock();
        let now = self.clock.now_secs();
        refill(&mut inner, now);
        inner.tokens = (inner.tokens - n as f64).max(0.0);
        inner.metrics.total_acquired += n;
    }

    /// Check if at least `n` tokens are available without consuming them.
    /// Performs refill but does NOT deduct.
    pub fn check_available(&self, n: u64) -> Result<()> {
        let mut inner = self.inner.lock();
        let now = self.clock.now_secs();
        refill(&mut inner, now);
        if inner.tokens >= n as f64 {
            Ok(())
        } else {
            let deficit = n as f64 - inner.tokens;
            let retry_after_secs = if inner.refill_rate <= 0.0 || inner.refill_rate == f64::MAX {
                1.0
            } else {
                (deficit / inner.refill_rate).max(1.0)
            };
            Err(ProxyError::RateLimited {
                available: inner.tokens,
                requested: n,
                retry_after_secs,
            })
        }
    }

    /// Snapshot of metrics.
    pub fn metrics(&self) -> TokenBucketMetrics {
        self.inner.lock().metrics.clone()
    }
}

/// Provider rate limit presets.
///
/// Returns `(max_calls_per_minute, burst_size)` for known providers.
pub fn provider_rate_limits(provider: &str) -> Option<RateLimitConfig> {
    let (max_calls, window, burst) = match provider {
        "openai" => (500, 60.0, 600),
        "anthropic" => (400, 60.0, 500),
        "google" => (360, 60.0, 400),
        "azure_openai" => (600, 60.0, 700),
        "groq" => (30, 60.0, 40),
        "fireworks" => (600, 60.0, 700),
        "cerebras" => (30, 60.0, 40),
        "ollama" => (1000, 60.0, 1200),
        "together" => (600, 60.0, 700),
        "deepseek" => (60, 60.0, 80),
        "mistral" => (120, 60.0, 150),
        "cohere" => (100, 60.0, 120),
        "bedrock" => (300, 60.0, 400),
        "xai" => (60, 60.0, 80),
        "openrouter" => (200, 60.0, 250),
        _ => return None,
    };
    Some(RateLimitConfig {
        max_calls,
        time_window_secs: window,
        burst_size: Some(burst),
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::clock::ManualClock;
    use std::sync::Arc;

    fn make_bucket(max_calls: u64, window: f64) -> (TokenBucket, Arc<ManualClock>) {
        let clock = Arc::new(ManualClock::new(0.0));
        let config = RateLimitConfig::new(max_calls, window);
        let bucket = TokenBucket::with_clock(&config, clock.clone());
        (bucket, clock)
    }

    #[test]
    fn acquire_within_capacity() {
        let (bucket, _) = make_bucket(10, 1.0);
        for _ in 0..10 {
            assert!(bucket.try_acquire(1).is_ok());
        }
        assert!(bucket.try_acquire(1).is_err());
    }

    #[test]
    fn refill_after_time() {
        let (bucket, clock) = make_bucket(10, 1.0);
        // Drain all tokens
        for _ in 0..10 {
            bucket.try_acquire(1).unwrap();
        }
        assert!(bucket.try_acquire(1).is_err());

        // Advance half the window → should get ~5 tokens
        clock.advance(0.5);
        assert!(bucket.try_acquire(5).is_ok());
        assert!(bucket.try_acquire(1).is_err());
    }

    #[test]
    fn burst_size() {
        let clock = Arc::new(ManualClock::new(0.0));
        let config = RateLimitConfig::new(10, 1.0).with_burst(20);
        let bucket = TokenBucket::with_clock(&config, clock.clone());

        // Capacity is 20 (burst), but refill rate is 10/sec
        for _ in 0..20 {
            assert!(bucket.try_acquire(1).is_ok());
        }
        assert!(bucket.try_acquire(1).is_err());

        // After 1 second, get 10 tokens (not 20)
        clock.advance(1.0);
        assert!(bucket.try_acquire(10).is_ok());
        assert!(bucket.try_acquire(1).is_err());
    }

    #[test]
    fn available_tokens_reflects_refill() {
        let (bucket, clock) = make_bucket(100, 10.0);
        // Drain
        bucket.try_acquire(100).unwrap();
        assert!(bucket.available_tokens() < 1.0);

        clock.advance(5.0);
        let avail = bucket.available_tokens();
        assert!((avail - 50.0).abs() < 1.0);
    }

    #[test]
    fn metrics_tracking() {
        let (bucket, _) = make_bucket(5, 1.0);
        for _ in 0..5 {
            bucket.try_acquire(1).unwrap();
        }
        let _ = bucket.try_acquire(1);
        let _ = bucket.try_acquire(1);

        let m = bucket.metrics();
        assert_eq!(m.total_acquired, 5);
        assert_eq!(m.total_rejected, 2);
    }

    #[test]
    fn bulk_acquire() {
        let (bucket, _) = make_bucket(10, 1.0);
        assert!(bucket.try_acquire(7).is_ok());
        assert!(bucket.try_acquire(4).is_err());
        assert!(bucket.try_acquire(3).is_ok());
    }

    #[test]
    fn provider_presets_exist() {
        for name in &[
            "openai",
            "anthropic",
            "google",
            "groq",
            "fireworks",
            "cerebras",
            "ollama",
            "together",
            "deepseek",
            "mistral",
            "cohere",
            "bedrock",
            "xai",
            "openrouter",
            "azure_openai",
        ] {
            assert!(
                provider_rate_limits(name).is_some(),
                "missing preset for {name}"
            );
        }
        assert!(provider_rate_limits("nonexistent").is_none());
    }

    #[test]
    fn update_config_changes_capacity() {
        let clock = Arc::new(ManualClock::new(0.0));
        let config = RateLimitConfig::new(10, 1.0); // 10 req/sec, capacity 10
        let bucket = TokenBucket::with_clock(&config, clock.clone());

        // Use 8 tokens
        bucket.try_acquire(8).unwrap();
        assert!((bucket.available_tokens() - 2.0).abs() < 0.1);

        // Advance 0.5s → refill 5 tokens → available ~7
        clock.advance(0.5);

        // Hot-reload: shrink capacity to 5
        let new_config = RateLimitConfig::new(5, 1.0);
        bucket.update_config(&new_config);

        // Tokens should be clamped to new capacity (5)
        let avail = bucket.available_tokens();
        assert!(avail <= 5.0, "expected ≤5, got {avail}");
        assert!(avail >= 4.9, "expected ~5, got {avail}");

        // Verify new refill rate: drain and wait 1s
        bucket.try_acquire(5).unwrap();
        clock.advance(1.0);
        let avail = bucket.available_tokens();
        assert!(
            (avail - 5.0).abs() < 0.1,
            "expected ~5 after 1s refill, got {avail}"
        );
    }

    #[test]
    fn capacity_getter() {
        let (bucket, _) = make_bucket(10, 1.0);
        assert_eq!(bucket.capacity(), 10);

        let clock = Arc::new(ManualClock::new(0.0));
        let config = RateLimitConfig::new(10, 1.0).with_burst(20);
        let bucket = TokenBucket::with_clock(&config, clock);
        assert_eq!(bucket.capacity(), 20);
    }

    #[test]
    fn update_config_refills_with_old_rate_first() {
        // Regression test: changing from high→low rate must refill with OLD rate first.
        let clock = Arc::new(ManualClock::new(0.0));
        let config = RateLimitConfig::new(10000, 60.0); // 10000/min = ~166.7/sec
        let bucket = TokenBucket::with_clock(&config, clock.clone());

        // Drain all tokens
        bucket.try_acquire(10000).unwrap();

        // Advance 30s (half window) → should refill ~5000 tokens at OLD rate
        clock.advance(30.0);

        // Now hot-reload to 10/min
        let new_config = RateLimitConfig::new(10, 60.0); // 10/min = ~0.167/sec
        bucket.update_config(&new_config);

        // After update: tokens should be clamped to new capacity (10)
        let avail = bucket.available_tokens();
        assert!(avail <= 10.0, "expected ≤10, got {avail}");
        assert!(avail >= 9.9, "expected ~10 (clamped), got {avail}");
    }

    /// Extract `retry_after_secs` from a `ProxyError::RateLimited`.
    fn extract_retry_after(err: &crate::error::ProxyError) -> f64 {
        match err {
            crate::error::ProxyError::RateLimited {
                retry_after_secs, ..
            } => *retry_after_secs,
            other => panic!("expected RateLimited, got {other:?}"),
        }
    }

    #[test]
    fn retry_after_secs_when_empty() {
        // 1 token/sec, drain all tokens
        let (bucket, _) = make_bucket(60, 60.0);
        bucket.try_acquire(60).unwrap();
        let err = bucket.try_acquire(1).unwrap_err();
        let wait = extract_retry_after(&err);
        assert!((wait - 1.0).abs() < 0.1, "expected ~1s, got {wait}");
    }

    #[test]
    fn retry_after_secs_when_partially_refilled() {
        let (bucket, clock) = make_bucket(60, 60.0); // 1 token/sec
        bucket.try_acquire(60).unwrap();
        clock.advance(0.5); // 0.5 tokens refilled
        let err = bucket.try_acquire(1).unwrap_err();
        let wait = extract_retry_after(&err);
        // Deficit is ~0.5s but retry_after floors at 1.0 to avoid rounding to 0 in ceil() as u64
        assert!(
            (wait - 1.0).abs() < 0.1,
            "expected 1.0s (floored), got {wait}"
        );
    }

    #[test]
    fn retry_after_secs_zero_when_available() {
        let (bucket, _) = make_bucket(10, 1.0);
        // Bucket is full — try_acquire succeeds, no retry_after to test.
        // Drain to 1 token remaining, then request 1 → succeeds.
        bucket.try_acquire(9).unwrap();
        assert!(bucket.try_acquire(1).is_ok());
    }

    #[test]
    fn force_deduct_reduces_to_zero() {
        let (bucket, _) = make_bucket(10, 1.0);
        bucket.force_deduct(10);
        assert!(bucket.available_tokens() < 0.1);
    }

    #[test]
    fn force_deduct_blocks_next_acquire() {
        let (bucket, _) = make_bucket(10, 1.0);
        bucket.force_deduct(10);
        assert!(bucket.try_acquire(1).is_err());
    }

    #[test]
    fn check_available_does_not_consume() {
        let (bucket, _) = make_bucket(10, 1.0);
        assert!(bucket.check_available(5).is_ok());
        // Tokens should still be full
        assert!((bucket.available_tokens() - 10.0).abs() < 0.1);
    }

    #[test]
    fn check_available_returns_error_when_exhausted() {
        let (bucket, _) = make_bucket(10, 1.0);
        bucket.try_acquire(10).unwrap();
        let err = bucket.check_available(1).unwrap_err();
        let retry = err.retry_after_secs();
        assert!(retry >= 1.0, "retry_after should be >= 1.0, got {retry}");
    }

    #[test]
    fn retry_after_floors_to_one() {
        // Very fast refill: 1000 tokens/sec. Even with tiny deficit, retry_after >= 1.0
        let (bucket, _) = make_bucket(1000, 1.0);
        bucket.try_acquire(1000).unwrap();
        let err = bucket.try_acquire(1).unwrap_err();
        let wait = extract_retry_after(&err);
        assert!(wait >= 1.0, "expected >= 1.0s, got {wait}");
    }

    #[test]
    fn time_to_full_when_full() {
        let (bucket, _) = make_bucket(10, 1.0);
        assert_eq!(bucket.time_to_full_secs(), 0);
    }

    #[test]
    fn time_to_full_after_drain() {
        let (bucket, _) = make_bucket(60, 60.0); // 1 token/sec, capacity 60
        bucket.try_acquire(60).unwrap();
        let ttf = bucket.time_to_full_secs();
        assert_eq!(ttf, 60, "expected 60s to refill, got {ttf}");
    }
}
