// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Python bindings for Thompson sampling router.

use pyo3::prelude::*;

use proxy_core::thompson::{self, ProviderProfile, RouterConfig, RouterWeights, ThompsonRouter};

use crate::exceptions::to_pyerr;

/// Python-visible routing decision.
#[pyclass(name = "RoutingDecision")]
#[derive(Clone)]
pub struct PyRoutingDecision {
    #[pyo3(get)]
    pub provider_id: String,
    #[pyo3(get)]
    pub score: f64,
    #[pyo3(get)]
    pub is_explore: bool,
}

#[pymethods]
impl PyRoutingDecision {
    fn __repr__(&self) -> String {
        format!(
            "RoutingDecision(provider_id='{}', score={:.4}, is_explore={})",
            self.provider_id, self.score, self.is_explore
        )
    }
}

/// Python-visible provider profile.
#[pyclass(name = "ProviderProfile")]
#[derive(Clone)]
pub struct PyProviderProfile {
    #[pyo3(get)]
    pub id: String,
    #[pyo3(get)]
    pub cost_per_1k: f64,
    #[pyo3(get)]
    pub base_quality: f64,
    #[pyo3(get)]
    pub base_latency_ms: f64,
}

#[pymethods]
impl PyProviderProfile {
    #[new]
    #[pyo3(signature = (id, cost_per_1k, base_quality, base_latency_ms))]
    fn new(id: String, cost_per_1k: f64, base_quality: f64, base_latency_ms: f64) -> Self {
        Self {
            id,
            cost_per_1k,
            base_quality,
            base_latency_ms,
        }
    }

    fn __repr__(&self) -> String {
        format!(
            "ProviderProfile(id='{}', cost={:.4}, quality={:.2}, latency={:.0}ms)",
            self.id, self.cost_per_1k, self.base_quality, self.base_latency_ms
        )
    }
}

/// Python-visible router config.
#[pyclass(name = "RouterConfig")]
#[derive(Clone)]
pub struct PyRouterConfig {
    #[pyo3(get)]
    pub cost_weight: f64,
    #[pyo3(get)]
    pub quality_weight: f64,
    #[pyo3(get)]
    pub latency_weight: f64,
    #[pyo3(get)]
    pub explore_mode: bool,
    #[pyo3(get)]
    pub decay_factor: f64,
    #[pyo3(get)]
    pub fallback_provider: Option<String>,
}

#[pymethods]
impl PyRouterConfig {
    #[new]
    #[pyo3(signature = (
        cost_weight = 0.5,
        quality_weight = 0.35,
        latency_weight = 0.15,
        explore_mode = true,
        decay_factor = 0.95,
        fallback_provider = None
    ))]
    fn new(
        cost_weight: f64,
        quality_weight: f64,
        latency_weight: f64,
        explore_mode: bool,
        decay_factor: f64,
        fallback_provider: Option<String>,
    ) -> Self {
        Self {
            cost_weight,
            quality_weight,
            latency_weight,
            explore_mode,
            decay_factor,
            fallback_provider,
        }
    }

    fn __repr__(&self) -> String {
        format!(
            "RouterConfig(cost={:.2}, quality={:.2}, latency={:.2}, explore={}, decay={:.2})",
            self.cost_weight,
            self.quality_weight,
            self.latency_weight,
            self.explore_mode,
            self.decay_factor
        )
    }
}

impl PyRouterConfig {
    fn to_core(&self) -> RouterConfig {
        RouterConfig {
            weights: RouterWeights {
                cost: self.cost_weight,
                quality: self.quality_weight,
                latency: self.latency_weight,
            },
            explore_mode: self.explore_mode,
            decay_factor: self.decay_factor,
            fallback_provider: self.fallback_provider.clone(),
        }
    }
}

/// Thompson sampling router for LLM providers.
#[pyclass(name = "ThompsonRouter")]
pub struct PyThompsonRouter {
    inner: ThompsonRouter,
}

#[pymethods]
impl PyThompsonRouter {
    #[new]
    #[pyo3(signature = (config = None))]
    fn new(config: Option<PyRouterConfig>) -> Self {
        let core_config = config.map(|c| c.to_core()).unwrap_or_default();
        Self {
            inner: ThompsonRouter::new(core_config),
        }
    }

    /// Add a provider to the router.
    fn add_provider(&self, profile: &PyProviderProfile) {
        self.inner.add_provider(ProviderProfile::new(
            &profile.id,
            profile.cost_per_1k,
            profile.base_quality,
            profile.base_latency_ms,
        ));
    }

    /// Number of registered providers.
    #[getter]
    fn provider_count(&self) -> usize {
        self.inner.provider_count()
    }

    /// Select a provider (auto mode: explore or deterministic based on config).
    fn select(&self) -> PyResult<PyRoutingDecision> {
        let d = self.inner.select_auto().map_err(to_pyerr)?;
        Ok(PyRoutingDecision {
            provider_id: d.provider_id,
            score: d.score,
            is_explore: d.is_explore,
        })
    }

    /// Select deterministically (no sampling).
    fn select_deterministic(&self) -> PyResult<PyRoutingDecision> {
        let d = self.inner.select_deterministic().map_err(to_pyerr)?;
        Ok(PyRoutingDecision {
            provider_id: d.provider_id,
            score: d.score,
            is_explore: d.is_explore,
        })
    }

    /// Record an outcome for a provider. Reward should be in [0, 1].
    fn record_outcome(&self, provider_id: &str, reward: f64) -> PyResult<()> {
        self.inner
            .record_outcome(provider_id, reward)
            .map_err(to_pyerr)
    }

    /// Rank providers by score (best-to-worst).
    /// If `eligible_ids` is empty, all providers are ranked.
    #[pyo3(signature = (eligible_ids = vec![]))]
    fn rank_among(&self, eligible_ids: Vec<String>) -> PyResult<Vec<PyRoutingDecision>> {
        let refs: Vec<&str> = eligible_ids.iter().map(|s| s.as_str()).collect();
        let ranked = self.inner.rank_among(&refs).map_err(to_pyerr)?;
        Ok(ranked
            .into_iter()
            .map(|d| PyRoutingDecision {
                provider_id: d.provider_id,
                score: d.score,
                is_explore: d.is_explore,
            })
            .collect())
    }

    /// Load default profiles for 12 common providers.
    fn load_defaults(&self) {
        for p in thompson::default_profiles() {
            self.inner.add_provider(p);
        }
    }

    fn __repr__(&self) -> String {
        format!("ThompsonRouter(providers={})", self.inner.provider_count())
    }
}

pub fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyThompsonRouter>()?;
    m.add_class::<PyRouterConfig>()?;
    m.add_class::<PyProviderProfile>()?;
    m.add_class::<PyRoutingDecision>()?;
    Ok(())
}
