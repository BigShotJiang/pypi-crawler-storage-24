// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Python exception hierarchy mapped from `ProxyError`.

use pyo3::create_exception;
use pyo3::exceptions::PyException;
use pyo3::prelude::*;

use proxy_core::ProxyError;

// Exception hierarchy: ProxyError (base) → specific exceptions
create_exception!(agenticraft_proxy, ProxyBaseError, PyException);
create_exception!(agenticraft_proxy, CircuitOpenError, ProxyBaseError);
create_exception!(agenticraft_proxy, RateLimitedError, ProxyBaseError);
create_exception!(agenticraft_proxy, NoAvailableKeysError, ProxyBaseError);
create_exception!(agenticraft_proxy, NoProvidersError, ProxyBaseError);
create_exception!(agenticraft_proxy, ProviderNotFoundError, ProxyBaseError);
create_exception!(agenticraft_proxy, InvalidParameterError, ProxyBaseError);
create_exception!(agenticraft_proxy, SamplingError, ProxyBaseError);

/// Convert a `ProxyError` into a Python exception with full error message.
pub fn to_pyerr(e: ProxyError) -> PyErr {
    let msg = e.to_string();
    match e {
        ProxyError::NoProviders => NoProvidersError::new_err(msg),
        ProxyError::CircuitOpen { .. } => CircuitOpenError::new_err(msg),
        ProxyError::RateLimited { .. } => RateLimitedError::new_err(msg),
        ProxyError::NoAvailableKeys { .. } => NoAvailableKeysError::new_err(msg),
        ProxyError::ProviderNotFound(_) => ProviderNotFoundError::new_err(msg),
        ProxyError::InvalidParameter(_) => InvalidParameterError::new_err(msg),
        ProxyError::SamplingError(_) => SamplingError::new_err(msg),
    }
}

/// Register all exception classes on the module.
pub fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add("ProxyError", m.py().get_type::<ProxyBaseError>())?;
    m.add("CircuitOpenError", m.py().get_type::<CircuitOpenError>())?;
    m.add("RateLimitedError", m.py().get_type::<RateLimitedError>())?;
    m.add(
        "NoAvailableKeysError",
        m.py().get_type::<NoAvailableKeysError>(),
    )?;
    m.add("NoProvidersError", m.py().get_type::<NoProvidersError>())?;
    m.add(
        "ProviderNotFoundError",
        m.py().get_type::<ProviderNotFoundError>(),
    )?;
    m.add(
        "InvalidParameterError",
        m.py().get_type::<InvalidParameterError>(),
    )?;
    m.add("SamplingError", m.py().get_type::<SamplingError>())?;
    Ok(())
}
