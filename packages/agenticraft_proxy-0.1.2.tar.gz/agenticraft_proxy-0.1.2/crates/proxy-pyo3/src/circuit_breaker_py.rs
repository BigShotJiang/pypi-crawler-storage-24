// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Python bindings for circuit breaker.

use std::sync::Arc;

use pyo3::prelude::*;

use proxy_core::circuit_breaker::{self, CircuitBreaker, CircuitBreakerConfig, FailureType};
use proxy_core::clock::MonotonicClock;

use crate::exceptions::to_pyerr;

/// Python-visible circuit breaker config.
#[pyclass(name = "CircuitBreakerConfig")]
#[derive(Clone)]
pub struct PyCircuitBreakerConfig {
    #[pyo3(get)]
    pub failure_threshold: u32,
    #[pyo3(get)]
    pub recovery_timeout_secs: f64,
    #[pyo3(get)]
    pub success_threshold: u32,
    #[pyo3(get)]
    pub provider: String,
}

#[pymethods]
impl PyCircuitBreakerConfig {
    #[new]
    #[pyo3(signature = (provider, failure_threshold = 5, recovery_timeout_secs = 60.0, success_threshold = 2))]
    fn new(
        provider: String,
        failure_threshold: u32,
        recovery_timeout_secs: f64,
        success_threshold: u32,
    ) -> Self {
        Self {
            failure_threshold,
            recovery_timeout_secs,
            success_threshold,
            provider,
        }
    }

    fn __repr__(&self) -> String {
        format!(
            "CircuitBreakerConfig(provider='{}', threshold={}, recovery={:.0}s)",
            self.provider, self.failure_threshold, self.recovery_timeout_secs
        )
    }
}

impl PyCircuitBreakerConfig {
    fn to_core(&self) -> CircuitBreakerConfig {
        CircuitBreakerConfig::new(&self.provider)
            .failure_threshold(self.failure_threshold)
            .recovery_timeout(self.recovery_timeout_secs)
            .success_threshold(self.success_threshold)
    }
}

/// Circuit breaker for LLM provider resilience.
#[pyclass(name = "CircuitBreaker")]
pub struct PyCircuitBreaker {
    inner: CircuitBreaker,
}

#[pymethods]
impl PyCircuitBreaker {
    #[new]
    #[pyo3(signature = (config = None, provider = None))]
    fn new(config: Option<PyCircuitBreakerConfig>, provider: Option<String>) -> Self {
        let core_config = if let Some(c) = config {
            c.to_core()
        } else {
            CircuitBreakerConfig::new(provider.unwrap_or_else(|| "default".to_string()))
        };
        Self {
            inner: CircuitBreaker::with_clock(core_config, Arc::new(MonotonicClock::new())),
        }
    }

    /// Current state as a string: "closed", "open", or "half_open".
    #[getter]
    fn state(&self) -> String {
        self.inner.state().to_string()
    }

    /// Check if the circuit allows a request through.
    fn allow_request(&self) -> PyResult<()> {
        self.inner.allow_request().map_err(to_pyerr)
    }

    /// Record a successful call.
    fn record_success(&self) {
        self.inner.record_success();
    }

    /// Record a failed call with a failure type string.
    ///
    /// Valid types: "rate_limit", "auth", "timeout", "connection", "service_error", "unknown".
    #[pyo3(signature = (failure_type = "unknown"))]
    fn record_failure(&self, failure_type: &str) {
        let ft = parse_failure_type(failure_type);
        self.inner.record_failure(ft);
    }

    /// Reset the circuit breaker to closed state.
    fn reset(&self) {
        self.inner.reset();
    }

    /// Classify an error message into a failure type string.
    #[staticmethod]
    fn classify_error(error_msg: &str) -> String {
        let ft = circuit_breaker::classify_error(error_msg);
        failure_type_to_str(ft)
    }

    /// Get provider-specific default config, or None if unknown.
    #[staticmethod]
    fn provider_defaults(provider: &str) -> Option<PyCircuitBreakerConfig> {
        circuit_breaker::provider_defaults(provider).map(|c| PyCircuitBreakerConfig {
            failure_threshold: c.failure_threshold,
            recovery_timeout_secs: c.recovery_timeout_secs,
            success_threshold: c.success_threshold,
            provider: c.provider,
        })
    }

    fn __repr__(&self) -> String {
        format!("CircuitBreaker(state='{}')", self.inner.state())
    }
}

fn parse_failure_type(s: &str) -> FailureType {
    match s {
        "rate_limit" => FailureType::RateLimit,
        "auth" => FailureType::Auth,
        "timeout" => FailureType::Timeout,
        "connection" => FailureType::Connection,
        "service_error" => FailureType::ServiceError,
        _ => FailureType::Unknown,
    }
}

fn failure_type_to_str(ft: FailureType) -> String {
    match ft {
        FailureType::RateLimit => "rate_limit",
        FailureType::Auth => "auth",
        FailureType::Timeout => "timeout",
        FailureType::Connection => "connection",
        FailureType::ServiceError => "service_error",
        FailureType::Unknown => "unknown",
    }
    .to_string()
}

pub fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyCircuitBreaker>()?;
    m.add_class::<PyCircuitBreakerConfig>()?;
    Ok(())
}
