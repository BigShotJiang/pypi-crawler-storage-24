// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Python bindings for token bucket rate limiter.

use std::sync::Arc;

use pyo3::prelude::*;

use proxy_core::clock::MonotonicClock;
use proxy_core::rate_limiter::{self, RateLimitConfig, TokenBucket};

use crate::exceptions::to_pyerr;

/// Python-visible rate limit config.
#[pyclass(name = "RateLimitConfig")]
#[derive(Clone)]
pub struct PyRateLimitConfig {
    #[pyo3(get)]
    pub max_calls: u64,
    #[pyo3(get)]
    pub time_window_secs: f64,
    #[pyo3(get)]
    pub burst_size: Option<u64>,
}

#[pymethods]
impl PyRateLimitConfig {
    #[new]
    #[pyo3(signature = (max_calls, time_window_secs, burst_size = None))]
    fn new(max_calls: u64, time_window_secs: f64, burst_size: Option<u64>) -> Self {
        Self {
            max_calls,
            time_window_secs,
            burst_size,
        }
    }

    fn __repr__(&self) -> String {
        format!(
            "RateLimitConfig(max_calls={}, window={:.0}s, burst={:?})",
            self.max_calls, self.time_window_secs, self.burst_size
        )
    }
}

impl PyRateLimitConfig {
    fn to_core(&self) -> RateLimitConfig {
        let mut config = RateLimitConfig::new(self.max_calls, self.time_window_secs);
        if let Some(burst) = self.burst_size {
            config = config.with_burst(burst);
        }
        config
    }
}

/// Token bucket rate limiter.
#[pyclass(name = "TokenBucket")]
pub struct PyTokenBucket {
    inner: TokenBucket,
}

#[pymethods]
impl PyTokenBucket {
    #[new]
    #[pyo3(signature = (config = None, max_calls = None, time_window_secs = None))]
    fn new(
        config: Option<PyRateLimitConfig>,
        max_calls: Option<u64>,
        time_window_secs: Option<f64>,
    ) -> PyResult<Self> {
        let core_config = if let Some(c) = config {
            c.to_core()
        } else if let (Some(mc), Some(tw)) = (max_calls, time_window_secs) {
            RateLimitConfig::new(mc, tw)
        } else {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "provide either config or both max_calls and time_window_secs",
            ));
        };

        Ok(Self {
            inner: TokenBucket::with_clock(&core_config, Arc::new(MonotonicClock::new())),
        })
    }

    /// Try to acquire `n` tokens. Returns True on success, raises RateLimitedError on failure.
    #[pyo3(signature = (n = 1))]
    fn try_acquire(&self, n: u64) -> PyResult<bool> {
        self.inner.try_acquire(n).map(|()| true).map_err(to_pyerr)
    }

    /// Number of tokens currently available.
    #[getter]
    fn available_tokens(&self) -> f64 {
        self.inner.available_tokens()
    }

    /// Get a provider preset config, or None if unknown.
    #[staticmethod]
    fn provider_preset(provider: &str) -> Option<PyRateLimitConfig> {
        rate_limiter::provider_rate_limits(provider).map(|c| PyRateLimitConfig {
            max_calls: c.max_calls,
            time_window_secs: c.time_window_secs,
            burst_size: c.burst_size,
        })
    }

    fn __repr__(&self) -> String {
        format!(
            "TokenBucket(available={:.1})",
            self.inner.available_tokens()
        )
    }
}

pub fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyTokenBucket>()?;
    m.add_class::<PyRateLimitConfig>()?;
    Ok(())
}
