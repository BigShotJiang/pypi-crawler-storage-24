// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

// pyo3 0.22's `create_exception!` macro checks `cfg(feature = "gil-refs")`
// internally, which triggers unexpected_cfgs in consumer crates.
// pyo3's `#[pymethods]` proc macro generates `.into()` on `PyErr` return types,
// which clippy flags as a useless identity conversion.
#![allow(unexpected_cfgs, clippy::useless_conversion)]
#![warn(clippy::unwrap_used)]

use pyo3::prelude::*;

mod circuit_breaker_py;
mod exceptions;
mod key_pool_py;
mod rate_limiter_py;
mod retry_py;
mod thompson_py;

/// Native extension module: `agenticraft_proxy._native`
#[pymodule]
fn _native(m: &Bound<'_, PyModule>) -> PyResult<()> {
    exceptions::register(m)?;
    thompson_py::register(m)?;
    circuit_breaker_py::register(m)?;
    rate_limiter_py::register(m)?;
    key_pool_py::register(m)?;
    retry_py::register(m)?;
    Ok(())
}
