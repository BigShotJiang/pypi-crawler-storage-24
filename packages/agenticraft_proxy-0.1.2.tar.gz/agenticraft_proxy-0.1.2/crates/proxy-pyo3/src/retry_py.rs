// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Python bindings for retry policy.

use proxy_core::retry::RetryPolicy;
use pyo3::prelude::*;

/// Retry policy with exponential backoff and jitter.
#[pyclass(name = "RetryPolicy")]
#[derive(Clone)]
pub struct PyRetryPolicy {
    #[pyo3(get)]
    pub max_retries: u32,
    #[pyo3(get)]
    pub base_delay_ms: u64,
    #[pyo3(get)]
    pub max_delay_ms: u64,
    #[pyo3(get)]
    pub jitter_factor: f64,
}

#[pymethods]
impl PyRetryPolicy {
    #[new]
    #[pyo3(signature = (max_retries=2, base_delay_ms=500, max_delay_ms=10_000, jitter_factor=0.5))]
    fn new(max_retries: u32, base_delay_ms: u64, max_delay_ms: u64, jitter_factor: f64) -> Self {
        Self {
            max_retries,
            base_delay_ms,
            max_delay_ms,
            jitter_factor,
        }
    }

    /// Whether attempt `n` (0-indexed) should be retried.
    fn should_retry(&self, attempt: u32) -> bool {
        attempt < self.max_retries
    }

    /// Delay in milliseconds before attempt `n` (exponential backoff + jitter).
    fn delay_ms(&self, attempt: u32) -> u64 {
        self.to_core().delay_for_attempt(attempt).as_millis() as u64
    }

    fn __repr__(&self) -> String {
        format!(
            "RetryPolicy(max_retries={}, base={}ms, max={}ms, jitter={:.2})",
            self.max_retries, self.base_delay_ms, self.max_delay_ms, self.jitter_factor
        )
    }
}

impl PyRetryPolicy {
    fn to_core(&self) -> RetryPolicy {
        RetryPolicy {
            max_retries: self.max_retries,
            base_delay_ms: self.base_delay_ms,
            max_delay_ms: self.max_delay_ms,
            jitter_factor: self.jitter_factor,
        }
    }
}

pub fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyRetryPolicy>()?;
    Ok(())
}
