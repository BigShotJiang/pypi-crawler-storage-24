// Copyright (c) 2026 AgentiCraft. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AgentiCraft-Proprietary

//! Python bindings for API key pool.

use std::sync::Arc;

use pyo3::prelude::*;

use proxy_core::clock::MonotonicClock;
use proxy_core::key_pool::{KeyPool, KeyStatus, RotationStrategy};

use crate::exceptions::to_pyerr;

/// Summary of a key's state (key material is masked).
#[pyclass(name = "KeySummary")]
#[derive(Clone)]
pub struct PyKeySummary {
    #[pyo3(get)]
    pub key_masked: String,
    #[pyo3(get)]
    pub status: String,
    #[pyo3(get)]
    pub total_requests: u64,
    #[pyo3(get)]
    pub total_errors: u64,
    #[pyo3(get)]
    pub total_rate_limits: u64,
    #[pyo3(get)]
    pub avg_latency_ms: f64,
    #[pyo3(get)]
    pub health_score: f64,
    #[pyo3(get)]
    pub weight: f64,
}

#[pymethods]
impl PyKeySummary {
    fn __repr__(&self) -> String {
        format!(
            "KeySummary(key='{}', status='{}', health={:.2})",
            self.key_masked, self.status, self.health_score
        )
    }
}

fn status_to_str(status: KeyStatus) -> &'static str {
    match status {
        KeyStatus::Active => "active",
        KeyStatus::RateLimited => "rate_limited",
        KeyStatus::CoolingDown => "cooling_down",
        KeyStatus::Disabled => "disabled",
        KeyStatus::Exhausted => "exhausted",
    }
}

/// API key pool with 5 rotation strategies.
#[pyclass(name = "KeyPool")]
pub struct PyKeyPool {
    inner: KeyPool,
}

#[pymethods]
impl PyKeyPool {
    /// Create a new key pool.
    ///
    /// Strategy: "round_robin", "least_used", "random", "weighted", "adaptive".
    #[new]
    #[pyo3(signature = (strategy = "round_robin"))]
    fn new(strategy: &str) -> PyResult<Self> {
        let strat = parse_strategy(strategy)?;
        Ok(Self {
            inner: KeyPool::with_clock(strat, Arc::new(MonotonicClock::new())),
        })
    }

    /// Add a key to the pool.
    #[pyo3(signature = (key, weight = 1.0, daily_limit = None))]
    fn add_key(&self, key: String, weight: f64, daily_limit: Option<u64>) {
        self.inner.add_key(key, weight, daily_limit);
    }

    /// Select a key using the configured strategy.
    fn select_key(&self) -> PyResult<String> {
        self.inner.select_key().map_err(to_pyerr)
    }

    /// Record a successful request.
    fn record_success(&self, key: &str, latency_ms: f64) {
        self.inner.record_success(key, latency_ms);
    }

    /// Record an error.
    fn record_error(&self, key: &str) {
        self.inner.record_error(key);
    }

    /// Record a rate limit hit with cooldown.
    fn record_rate_limit(&self, key: &str, cooldown_secs: f64) {
        self.inner.record_rate_limit(key, cooldown_secs);
    }

    /// Record quota exhaustion.
    fn record_exhausted(&self, key: &str) {
        self.inner.record_exhausted(key);
    }

    /// Disable a key.
    fn disable_key(&self, key: &str) {
        self.inner.disable_key(key);
    }

    /// Re-enable a disabled key.
    fn enable_key(&self, key: &str) {
        self.inner.enable_key(key);
    }

    /// Reset daily counters for all keys.
    fn reset_daily_counters(&self) {
        self.inner.reset_daily_counters();
    }

    /// Check if a key exists in the pool.
    fn has_key(&self, key: &str) -> bool {
        self.inner.has_key(key)
    }

    /// Remove a key from the pool. Returns true if it was present.
    fn remove_key(&self, key: &str) -> bool {
        self.inner.remove_key(key)
    }

    /// List all keys with masked key material and current metrics.
    fn list_keys(&self) -> Vec<PyKeySummary> {
        self.inner
            .list_keys()
            .into_iter()
            .map(|s| PyKeySummary {
                key_masked: s.key_masked,
                status: status_to_str(s.status).to_owned(),
                total_requests: s.total_requests,
                total_errors: s.total_errors,
                total_rate_limits: s.total_rate_limits,
                avg_latency_ms: s.avg_latency_ms,
                health_score: s.health_score,
                weight: s.weight,
            })
            .collect()
    }

    fn __len__(&self) -> usize {
        self.inner.len()
    }

    fn __bool__(&self) -> bool {
        !self.inner.is_empty()
    }

    fn __repr__(&self) -> String {
        format!("KeyPool(keys={})", self.inner.len())
    }
}

fn parse_strategy(s: &str) -> PyResult<RotationStrategy> {
    match s {
        "round_robin" => Ok(RotationStrategy::RoundRobin),
        "least_used" => Ok(RotationStrategy::LeastUsed),
        "random" => Ok(RotationStrategy::Random),
        "weighted" => Ok(RotationStrategy::Weighted),
        "adaptive" => Ok(RotationStrategy::Adaptive),
        _ => Err(pyo3::exceptions::PyValueError::new_err(format!(
            "unknown strategy '{}', expected: round_robin, least_used, random, weighted, adaptive",
            s
        ))),
    }
}

pub fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyKeyPool>()?;
    m.add_class::<PyKeySummary>()?;
    Ok(())
}
