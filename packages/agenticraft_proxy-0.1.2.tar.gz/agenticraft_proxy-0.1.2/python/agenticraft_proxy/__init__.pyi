"""Type stubs for agenticraft_proxy."""

from typing import Optional

__version__: str

# --------------------------------------------------------------------------
# Exceptions
# --------------------------------------------------------------------------

class ProxyError(Exception): ...
class CircuitOpenError(ProxyError): ...
class RateLimitedError(ProxyError): ...
class NoAvailableKeysError(ProxyError): ...
class NoProvidersError(ProxyError): ...
class ProviderNotFoundError(ProxyError): ...
class InvalidParameterError(ProxyError): ...
class SamplingError(ProxyError): ...

# --------------------------------------------------------------------------
# Thompson Sampling Router
# --------------------------------------------------------------------------

class ProviderProfile:
    id: str
    cost_per_1k: float
    base_quality: float
    base_latency_ms: float

    def __init__(
        self,
        id: str,
        cost_per_1k: float,
        base_quality: float,
        base_latency_ms: float,
    ) -> None: ...

class RouterConfig:
    cost_weight: float
    quality_weight: float
    latency_weight: float
    explore_mode: bool
    decay_factor: float
    fallback_provider: Optional[str]

    def __init__(
        self,
        cost_weight: float = 0.5,
        quality_weight: float = 0.35,
        latency_weight: float = 0.15,
        explore_mode: bool = True,
        decay_factor: float = 0.95,
        fallback_provider: Optional[str] = None,
    ) -> None: ...

class RoutingDecision:
    provider_id: str
    score: float
    is_explore: bool

class ThompsonRouter:
    provider_count: int

    def __init__(self, config: Optional[RouterConfig] = None) -> None: ...
    def add_provider(self, profile: ProviderProfile) -> None: ...
    def select(self) -> RoutingDecision: ...
    def select_deterministic(self) -> RoutingDecision: ...
    def record_outcome(self, provider_id: str, reward: float) -> None: ...
    def rank_among(self, eligible_ids: list[str] = ...) -> list[RoutingDecision]: ...
    def load_defaults(self) -> None: ...

# --------------------------------------------------------------------------
# Circuit Breaker
# --------------------------------------------------------------------------

class CircuitBreakerConfig:
    failure_threshold: int
    recovery_timeout_secs: float
    success_threshold: int
    provider: str

    def __init__(
        self,
        provider: str,
        failure_threshold: int = 5,
        recovery_timeout_secs: float = 60.0,
        success_threshold: int = 2,
    ) -> None: ...

class CircuitBreaker:
    state: str

    def __init__(
        self,
        config: Optional[CircuitBreakerConfig] = None,
        provider: Optional[str] = None,
    ) -> None: ...
    def allow_request(self) -> None: ...
    def record_success(self) -> None: ...
    def record_failure(self, failure_type: str = "unknown") -> None: ...
    def reset(self) -> None: ...

    @staticmethod
    def classify_error(error_msg: str) -> str: ...

    @staticmethod
    def provider_defaults(provider: str) -> Optional[CircuitBreakerConfig]: ...

# --------------------------------------------------------------------------
# Rate Limiter
# --------------------------------------------------------------------------

class RateLimitConfig:
    max_calls: int
    time_window_secs: float
    burst_size: Optional[int]

    def __init__(
        self,
        max_calls: int,
        time_window_secs: float,
        burst_size: Optional[int] = None,
    ) -> None: ...

class TokenBucket:
    available_tokens: float

    def __init__(
        self,
        config: Optional[RateLimitConfig] = None,
        max_calls: Optional[int] = None,
        time_window_secs: Optional[float] = None,
    ) -> None: ...
    def try_acquire(self, n: int = 1) -> bool: ...

    @staticmethod
    def provider_preset(provider: str) -> Optional[RateLimitConfig]: ...

# --------------------------------------------------------------------------
# Key Pool
# --------------------------------------------------------------------------

class KeyPool:
    def __init__(self, strategy: str = "round_robin") -> None: ...
    def add_key(
        self,
        key: str,
        weight: float = 1.0,
        daily_limit: Optional[int] = None,
    ) -> None: ...
    def select_key(self) -> str: ...
    def record_success(self, key: str, latency_ms: float) -> None: ...
    def record_error(self, key: str) -> None: ...
    def record_rate_limit(self, key: str, cooldown_secs: float) -> None: ...
    def record_exhausted(self, key: str) -> None: ...
    def disable_key(self, key: str) -> None: ...
    def enable_key(self, key: str) -> None: ...
    def has_key(self, key: str) -> bool: ...
    def remove_key(self, key: str) -> bool: ...
    def list_keys(self) -> list[KeySummary]: ...
    def reset_daily_counters(self) -> None: ...
    def __len__(self) -> int: ...
    def __bool__(self) -> bool: ...

# --------------------------------------------------------------------------
# Key Summary
# --------------------------------------------------------------------------

class KeySummary:
    key_masked: str
    status: str
    total_requests: int
    total_errors: int
    total_rate_limits: int
    avg_latency_ms: float
    health_score: float
    weight: float

# --------------------------------------------------------------------------
# Retry Policy
# --------------------------------------------------------------------------

class RetryPolicy:
    max_retries: int
    base_delay_ms: int
    max_delay_ms: int
    jitter_factor: float

    def __init__(
        self,
        max_retries: int = 2,
        base_delay_ms: int = 500,
        max_delay_ms: int = 10_000,
        jitter_factor: float = 0.5,
    ) -> None: ...
    def should_retry(self, attempt: int) -> bool: ...
    def delay_ms(self, attempt: int) -> int: ...
