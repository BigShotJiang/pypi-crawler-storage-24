"""Async gRPC client for the AgentiCraft proxy control plane.

Wraps generated stubs with a clean Python API and async context manager
hygiene (ensures HTTP/2 sockets are freed even on task cancellation).

Usage:
    async with ProxyControlClient("localhost:50051") as client:
        ack = await client.push_config(config)
        snapshot = await client.export_metrics()
        async for snap in client.stream_metrics(interval_ms=500):
            print(snap.timestamp_ms)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, AsyncIterator

import grpc.aio  # type: ignore[import-untyped]

from . import config_pb2, config_pb2_grpc
from . import context_pb2, context_pb2_grpc
from . import keypool_pb2, keypool_pb2_grpc
from . import metrics_pb2, metrics_pb2_grpc
from . import policy_pb2, policy_pb2_grpc

if TYPE_CHECKING:
    pass


class _BearerAuthInterceptor(
    grpc.aio.UnaryUnaryClientInterceptor,
    grpc.aio.UnaryStreamClientInterceptor,
):
    """Injects Bearer auth metadata into every gRPC call."""

    __slots__ = ("_metadata",)

    def __init__(self, token: str) -> None:
        self._metadata = grpc.aio.Metadata(("authorization", f"Bearer {token}"))

    async def intercept_unary_unary(self, continuation, client_call_details, request):
        new_details = grpc.aio.ClientCallDetails(
            client_call_details.method,
            client_call_details.timeout,
            self._metadata if client_call_details.metadata is None
            else client_call_details.metadata + self._metadata,
            client_call_details.credentials,
            client_call_details.wait_for_ready,
        )
        return await continuation(new_details, request)

    async def intercept_unary_stream(self, continuation, client_call_details, request):
        new_details = grpc.aio.ClientCallDetails(
            client_call_details.method,
            client_call_details.timeout,
            self._metadata if client_call_details.metadata is None
            else client_call_details.metadata + self._metadata,
            client_call_details.credentials,
            client_call_details.wait_for_ready,
        )
        return await continuation(new_details, request)


class ProxyControlClient:
    """Async gRPC client for the proxy control plane.

    Implements ``__aenter__``/``__aexit__`` for async context manager
    hygiene — ensures HTTP/2 sockets are freed even on task cancellation.
    """

    def __init__(
        self,
        target: str = "localhost:50051",
        ssl_credentials: "grpc.ChannelCredentials | None" = None,
        auth_token: str | None = None,
    ) -> None:
        self._target = target
        self._ssl_credentials = ssl_credentials
        self._interceptors: list[grpc.aio.ClientInterceptor] = []
        if auth_token:
            self._interceptors.append(_BearerAuthInterceptor(auth_token))
        self._channel: grpc.aio.Channel | None = None
        self._control_stub: config_pb2_grpc.ProxyControlStub | None = None
        self._keypool_stub: keypool_pb2_grpc.KeyPoolServiceStub | None = None
        self._metrics_stub: metrics_pb2_grpc.MetricsServiceStub | None = None
        self._policy_stub: policy_pb2_grpc.PolicyServiceStub | None = None
        self._context_stub: context_pb2_grpc.ContextServiceStub | None = None
        self._identity_stub: "identity_pb2_grpc.IdentityServiceStub | None" = None

    def channel_state(self) -> "grpc.ChannelConnectivity | None":
        """Return the current channel connectivity state, or None if no channel."""
        if self._channel is None:
            return None
        return self._channel.get_state(try_to_connect=False)

    def _ensure_channel(self) -> None:
        if self._channel is None:
            if self._ssl_credentials is not None:
                self._channel = grpc.aio.secure_channel(
                    self._target,
                    self._ssl_credentials,
                    interceptors=self._interceptors or None,
                )
            else:
                self._channel = grpc.aio.insecure_channel(
                    self._target,
                    interceptors=self._interceptors or None,
                )
            self._control_stub = config_pb2_grpc.ProxyControlStub(self._channel)
            self._keypool_stub = keypool_pb2_grpc.KeyPoolServiceStub(self._channel)
            self._metrics_stub = metrics_pb2_grpc.MetricsServiceStub(self._channel)
            self._policy_stub = policy_pb2_grpc.PolicyServiceStub(self._channel)
            self._context_stub = context_pb2_grpc.ContextServiceStub(self._channel)
            try:
                from . import identity_pb2_grpc

                self._identity_stub = identity_pb2_grpc.IdentityServiceStub(
                    self._channel
                )
            except ImportError:
                self._identity_stub = None

    async def __aenter__(self) -> ProxyControlClient:
        self._ensure_channel()
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.close()

    # -----------------------------------------------------------------
    # Config push
    # -----------------------------------------------------------------

    async def push_config(
        self,
        config: config_pb2.ProxyConfig,
    ) -> config_pb2.ConfigAck:
        """Push configuration to the proxy data plane."""
        self._ensure_channel()
        assert self._control_stub is not None
        return await self._control_stub.PushConfig(config)

    # -----------------------------------------------------------------
    # Policy
    # -----------------------------------------------------------------

    async def update_policy(
        self,
        graph: policy_pb2.CompiledPolicyGraph,
    ) -> policy_pb2.PolicyAck:
        """Push a compiled policy graph to the proxy."""
        self._ensure_channel()
        assert self._policy_stub is not None
        return await self._policy_stub.UpdatePolicy(graph)

    # -----------------------------------------------------------------
    # Metrics
    # -----------------------------------------------------------------

    async def export_metrics(self) -> metrics_pb2.MetricsSnapshot:
        """Pull a single metrics snapshot from the proxy."""
        self._ensure_channel()
        assert self._metrics_stub is not None
        req = metrics_pb2.MetricsRequest()
        return await self._metrics_stub.ExportMetrics(req)

    async def stream_metrics(
        self,
        interval_ms: int = 1000,
    ) -> AsyncIterator[metrics_pb2.MetricsSnapshot]:
        """Stream metrics snapshots at the given interval.

        Yields ``MetricsSnapshot`` messages until the caller breaks or
        the server disconnects.
        """
        self._ensure_channel()
        assert self._metrics_stub is not None
        req = metrics_pb2.MetricsRequest(interval_ms=interval_ms)
        stream = self._metrics_stub.StreamMetrics(req)
        async for snapshot in stream:
            yield snapshot

    # -----------------------------------------------------------------
    # Key pool
    # -----------------------------------------------------------------

    async def add_key(
        self,
        provider: str,
        key: str,
        weight: float = 1.0,
        daily_limit: int = 0,
    ) -> "keypool_pb2.KeyPoolAck":
        """Add an API key to a provider's key pool."""
        self._ensure_channel()
        assert self._keypool_stub is not None
        return await self._keypool_stub.AddKey(
            keypool_pb2.AddKeyRequest(
                provider=provider,
                key=key,
                weight=weight,
                daily_limit=daily_limit,
            ),
        )

    async def remove_key(
        self,
        provider: str,
        key: str,
    ) -> "keypool_pb2.KeyPoolAck":
        """Remove an API key from a provider's key pool."""
        self._ensure_channel()
        assert self._keypool_stub is not None
        return await self._keypool_stub.RemoveKey(
            keypool_pb2.RemoveKeyRequest(provider=provider, key=key),
        )

    async def enable_key(
        self,
        provider: str,
        key: str,
    ) -> "keypool_pb2.KeyPoolAck":
        """Re-enable a disabled API key."""
        self._ensure_channel()
        assert self._keypool_stub is not None
        return await self._keypool_stub.EnableKey(
            keypool_pb2.EnableKeyRequest(provider=provider, key=key),
        )

    async def disable_key(
        self,
        provider: str,
        key: str,
    ) -> "keypool_pb2.KeyPoolAck":
        """Disable an API key."""
        self._ensure_channel()
        assert self._keypool_stub is not None
        return await self._keypool_stub.DisableKey(
            keypool_pb2.DisableKeyRequest(provider=provider, key=key),
        )

    async def list_key_metrics(
        self,
        provider: str = "",
    ) -> "keypool_pb2.ListKeyMetricsResponse":
        """List key metrics for a provider (or all providers if empty)."""
        self._ensure_channel()
        assert self._keypool_stub is not None
        return await self._keypool_stub.ListKeyMetrics(
            keypool_pb2.ListKeyMetricsRequest(provider=provider),
        )

    # -----------------------------------------------------------------
    # Context store
    # -----------------------------------------------------------------

    async def store_context(
        self,
        key: str,
        value: bytes,
        ttl_secs: int = 0,
    ) -> context_pb2.ContextAck:
        """Store a context entry."""
        self._ensure_channel()
        assert self._context_stub is not None
        return await self._context_stub.Store(
            context_pb2.ContextStoreRequest(key=key, value=value, ttl_secs=ttl_secs),
        )

    async def retrieve_context(
        self,
        key: str,
    ) -> context_pb2.ContextRetrieveResponse:
        """Retrieve a context entry by key."""
        self._ensure_channel()
        assert self._context_stub is not None
        return await self._context_stub.Retrieve(
            context_pb2.ContextRetrieveRequest(key=key),
        )

    async def delete_context(
        self,
        key: str,
    ) -> context_pb2.ContextAck:
        """Delete a context entry."""
        self._ensure_channel()
        assert self._context_stub is not None
        return await self._context_stub.Delete(
            context_pb2.ContextDeleteRequest(key=key),
        )

    async def context_info(self) -> context_pb2.ContextInfoResponse:
        """Get context store information."""
        self._ensure_channel()
        assert self._context_stub is not None
        return await self._context_stub.Info(
            context_pb2.ContextInfoRequest()
        )

    # -----------------------------------------------------------------
    # Identity
    # -----------------------------------------------------------------

    async def push_identities(
        self,
        agents: list[dict],
        full_sync: bool = True,
    ) -> "identity_pb2.PushIdentitiesResponse":
        """Push agent identities to the Rust proxy."""
        self._ensure_channel()
        assert self._identity_stub is not None
        from . import identity_pb2

        request = identity_pb2.PushIdentitiesRequest(
            agents=[identity_pb2.AgentIdentity(**a) for a in agents],
            full_sync=full_sync,
        )
        return await self._identity_stub.PushIdentities(
            request
        )

    async def push_session_policy(
        self,
        policy: dict,
    ) -> "identity_pb2.PushSessionPolicyResponse":
        """Push session policy to the Rust proxy."""
        self._ensure_channel()
        assert self._identity_stub is not None
        from . import identity_pb2

        request = identity_pb2.SessionPolicy(**policy)
        return await self._identity_stub.PushSessionPolicy(
            request
        )

    async def remove_agent_identity(
        self,
        agent_id: str,
    ) -> "identity_pb2.RemoveAgentResponse":
        """Remove an agent from the Rust proxy's identity registry."""
        self._ensure_channel()
        assert self._identity_stub is not None
        from . import identity_pb2

        request = identity_pb2.RemoveAgentRequest(agent_id=agent_id)
        return await self._identity_stub.RemoveAgent(
            request
        )

    async def get_identity_state(self) -> "identity_pb2.IdentityState":
        """Query current identity state from the Rust proxy."""
        self._ensure_channel()
        assert self._identity_stub is not None
        from . import identity_pb2

        return await self._identity_stub.GetIdentityState(
            identity_pb2.GetIdentityStateRequest()
        )

    # -----------------------------------------------------------------
    # Lifecycle
    # -----------------------------------------------------------------

    async def close(self) -> None:
        """Close the gRPC channel."""
        if self._channel is not None:
            await self._channel.close()
            self._channel = None
            self._control_stub = None
            self._keypool_stub = None
            self._metrics_stub = None
            self._policy_stub = None
            self._context_stub = None
            self._identity_stub = None
