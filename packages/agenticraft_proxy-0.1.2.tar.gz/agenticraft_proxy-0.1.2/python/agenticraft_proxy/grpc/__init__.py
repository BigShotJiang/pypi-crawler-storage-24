"""gRPC control plane client and generated protocol buffer stubs.

Usage:
    from agenticraft_proxy.grpc import ProxyControlClient

    async with ProxyControlClient("localhost:50051") as client:
        snapshot = await client.export_metrics()
        print(snapshot.timestamp_ms)
"""

from .client import ProxyControlClient

__all__ = [
    "ProxyControlClient",
    # Proto modules re-exported for advanced usage
    "config_pb2",
    "config_pb2_grpc",
    "context_pb2",
    "context_pb2_grpc",
    "keypool_pb2",
    "keypool_pb2_grpc",
    "metrics_pb2",
    "metrics_pb2_grpc",
    "policy_pb2",
    "policy_pb2_grpc",
    # Generated from mesh/v1 and identity/v1 protos
    "broker_pb2",
    "broker_pb2_grpc",
    "orchestration_pb2",
    "orchestration_pb2_grpc",
    "identity_pb2",
    "identity_pb2_grpc",
    # Generated from proxy/v1 protos
    "budgets_pb2",
    "budgets_pb2_grpc",
    "compliance_pb2",
    "compliance_pb2_grpc",
    "federation_pb2",
    "federation_pb2_grpc",
    "governance_pb2",
    "governance_pb2_grpc",
    "guardrails_pb2",
    "guardrails_pb2_grpc",
    "hitl_pb2",
    "hitl_pb2_grpc",
    "inference_routing_pb2",
    "inference_routing_pb2_grpc",
    "memory_pb2",
    "memory_pb2_grpc",
    "sla_pb2",
    "sla_pb2_grpc",
    "zero_trust_pb2",
    "zero_trust_pb2_grpc",
]
