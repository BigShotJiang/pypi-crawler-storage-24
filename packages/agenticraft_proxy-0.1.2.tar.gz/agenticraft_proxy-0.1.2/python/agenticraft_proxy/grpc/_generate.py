"""Generate Python protobuf stubs from .proto files.

Runs grpc_tools.protoc against the 3 proto files, moves generated files
from the nested package path to the flat grpc/ directory, and patches
imports from absolute to relative.

Usage:
    python -m agenticraft_proxy.grpc._generate
"""

from __future__ import annotations

import re
import shutil
import sys
from pathlib import Path


def generate() -> None:
    try:
        from grpc_tools import protoc  # type: ignore[import-untyped]
    except ImportError:
        print(
            "grpc_tools not installed. Run: pip install grpcio-tools",
            file=sys.stderr,
        )
        sys.exit(1)

    # Paths
    this_dir = Path(__file__).resolve().parent
    proto_root = this_dir.parents[2] / "proto"
    proto_root = proto_root.resolve()

    # Proto directories to generate from
    proto_dirs = [
        proto_root / "agenticraft" / "proxy" / "v1",
        proto_root / "agenticraft" / "identity" / "v1",
        proto_root / "agenticraft" / "mesh" / "v1",
    ]

    proto_files: list[Path] = []
    for proto_dir in proto_dirs:
        if not proto_dir.exists():
            print(f"Proto directory not found (skipping): {proto_dir}", file=sys.stderr)
            continue
        found = list(proto_dir.glob("*.proto"))
        if not found:
            print(f"No .proto files in {proto_dir} (skipping)", file=sys.stderr)
            continue
        proto_files.extend(found)

    if not proto_files:
        print("No .proto files found in any proto directory", file=sys.stderr)
        sys.exit(1)

    print(f"Generating from {len(proto_files)} proto files...")

    for proto_file in proto_files:
        args = [
            "grpc_tools.protoc",
            f"--proto_path={proto_root}",
            f"--python_out={this_dir}",
            f"--grpc_python_out={this_dir}",
            str(proto_file),
        ]
        result = protoc.main(args)
        if result != 0:
            print(f"protoc failed for {proto_file.name} (exit {result})", file=sys.stderr)
            sys.exit(1)
        print(f"  generated {proto_file.name}")

    # Move all generated *_pb2*.py from nested package dirs to flat grpc/ directory
    nested_root = this_dir / "agenticraft"
    if nested_root.exists():
        for f in nested_root.rglob("*_pb2*.py"):
            dest = this_dir / f.name
            shutil.move(str(f), str(dest))
            print(f"  moved {f.name}")
        shutil.rmtree(nested_root, ignore_errors=True)

    # Post-process: fix absolute imports to relative
    _patch_imports(this_dir)
    print("Done — imports patched to relative.")


def _patch_imports(output_dir: Path) -> None:
    """Patch generated *_pb2_grpc.py files: absolute -> relative imports.

    protoc generates: ``from agenticraft.proxy.v1 import X_pb2 as ...``
                  or: ``from agenticraft.identity.v1 import X_pb2 as ...``
    We need:          ``from . import X_pb2 as ...``
    """
    pattern = re.compile(
        r"^from agenticraft\.(?:proxy|identity|mesh)\.v1 import (\w+_pb2) as (\w+)",
        re.MULTILINE,
    )

    for grpc_file in output_dir.glob("*_pb2_grpc.py"):
        text = grpc_file.read_text()
        patched = pattern.sub(r"from . import \1 as \2", text)
        if patched != text:
            grpc_file.write_text(patched)
            print(f"  patched {grpc_file.name}")


if __name__ == "__main__":
    generate()
