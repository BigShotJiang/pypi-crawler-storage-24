"""Policy compiler: CSP Process → LTS → proto CompiledPolicyGraph.

Usage:
    from agenticraft_proxy.policy import PolicyCompiler

    compiler = PolicyCompiler()
    graph = compiler.compile(process, "my-policy")
"""

from .compiler import PolicyCompiler

__all__ = ["PolicyCompiler"]
