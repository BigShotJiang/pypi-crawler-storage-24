"""Compile CSP processes into proto CompiledPolicyGraph messages.

The mapping is direct:
- LTSState.id → StateNode.state_hash (as ``f"s{id}"``)
- Transition(source, event, target) → proto Transition
- LTSState.is_deadlock / is_terminal → StateNode flags
- Probability = 1.0 for all (deterministic CSP; nondeterministic weights deferred)

Uses lazy import of agenticraft.mesh.foundation.formal.algebra (optional dep).
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


class PolicyCompiler:
    """Compile CSP Process → proto CompiledPolicyGraph.

    Parameters
    ----------
    max_states : int
        Maximum states the LTS builder will explore (safety bound).
    """

    def __init__(self, max_states: int = 10_000) -> None:
        self.max_states = max_states

    def compile(
        self,
        process: Any,
        policy_id: str,
        version: str = "v1",
    ) -> Any:
        """Compile a CSP Process into a proto CompiledPolicyGraph.

        Parameters
        ----------
        process : agenticraft.mesh.foundation.formal.algebra.Process
            The CSP process to compile.
        policy_id : str
            Identifier for the compiled policy.
        version : str
            Policy version string.

        Returns
        -------
        agenticraft_proxy.grpc.policy_pb2.CompiledPolicyGraph
            The compiled policy graph as a protobuf message.
        """
        # Lazy import: agenticraft foundation is an optional dependency
        try:
            from agenticraft.mesh.foundation.formal.algebra import (
                LTSBuilder,
                TICK,
                TAU,
            )
        except ImportError as e:
            raise ImportError(
                "Policy compiler requires the agenticraft package. "
                "Install it or ensure it's on PYTHONPATH."
            ) from e

        # Build LTS from CSP process
        lts = LTSBuilder(max_states=self.max_states).build(process)

        logger.info(
            "compiled LTS: %d states, %d transitions",
            len(lts.states),
            len(lts.transitions),
        )

        return self._lts_to_proto(lts, policy_id, version, tick=TICK, tau=TAU)

    def _lts_to_proto(
        self,
        lts: Any,
        policy_id: str,
        version: str,
        tick: Any,
        tau: Any,
    ) -> Any:
        """Convert an LTS to a proto CompiledPolicyGraph."""
        from agenticraft_proxy.grpc import policy_pb2

        # Group transitions by source state
        transitions_by_source: dict[int, list[Any]] = {}
        for t in lts.transitions:
            transitions_by_source.setdefault(t.source, []).append(t)

        state_nodes = []
        for state_id, lts_state in lts.states.items():
            state_hash = f"s{state_id}"

            proto_transitions = []
            for t in transitions_by_source.get(state_id, []):
                event_name = str(t.event)
                # Skip internal tau events in the policy graph
                if t.event == tau:
                    event_name = "__tau__"

                # Map tick to terminal marker
                if t.event == tick:
                    event_name = "__tick__"

                proto_transitions.append(
                    policy_pb2.Transition(
                        event_name=event_name,
                        next_state_hash=f"s{t.target}",
                        probability=1.0,  # Deterministic CSP
                        cost_threshold=0.0,
                    )
                )

            state_nodes.append(
                policy_pb2.StateNode(
                    state_hash=state_hash,
                    transitions=proto_transitions,
                    is_deadlock=lts_state.is_deadlock,
                    is_terminal=lts_state.is_terminal,
                )
            )

        return policy_pb2.CompiledPolicyGraph(
            policy_id=policy_id,
            policy_version=version,
            states=state_nodes,
        )
