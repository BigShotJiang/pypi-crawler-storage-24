import pytest
from pydantic import ValidationError

from bluefox_yml.models import (
    ComputeProcess,
    DataPrimitive,
    InMemoryPrimitive,
    Manifest,
)


def test_compute_process__with_port():
    p = ComputeProcess(mode="app", port=8000)
    assert p.mode == "app"
    assert p.port == 8000
    assert p.healthcheck == "/health"


def test_compute_process__without_port():
    p = ComputeProcess(mode="worker")
    assert p.mode == "worker"
    assert p.port is None
    assert p.healthcheck is None


def test_compute_process__custom_healthcheck():
    p = ComputeProcess(mode="app", port=8000, healthcheck="/ready")
    assert p.healthcheck == "/ready"


def test_data_primitive__with_migrate():
    d = DataPrimitive(engine="postgres", version=17, migrate="uv run alembic upgrade head")
    assert d.engine == "postgres"
    assert d.version == 17
    assert d.migrate == "uv run alembic upgrade head"


def test_data_primitive__without_migrate():
    d = DataPrimitive(engine="postgres", version=17)
    assert d.migrate is None


def test_data_primitive__invalid_engine_rejected():
    with pytest.raises(ValidationError, match="unsupported data engine.*mysql"):
        DataPrimitive(engine="mysql", version=8)


def test_data_primitive__sqlite_rejected():
    with pytest.raises(ValidationError, match="unsupported data engine.*sqlite"):
        DataPrimitive(engine="sqlite", version=3)


def test_data_primitive__version_positive():
    d = DataPrimitive(engine="postgres", version=17)
    assert d.version == 17


def test_data_primitive__version_zero_rejected():
    with pytest.raises(ValidationError, match="version must be a positive integer"):
        DataPrimitive(engine="postgres", version=0)


def test_data_primitive__version_negative_rejected():
    with pytest.raises(ValidationError, match="version must be a positive integer"):
        DataPrimitive(engine="postgres", version=-1)


def test_in_memory_primitive__basic():
    im = InMemoryPrimitive(engine="redis", version=7)
    assert im.engine == "redis"
    assert im.version == 7


def test_in_memory_primitive__invalid_engine_rejected():
    with pytest.raises(ValidationError, match="unsupported in-memory engine.*memcached"):
        InMemoryPrimitive(engine="memcached", version=1)


def test_in_memory_primitive__valkey_rejected():
    with pytest.raises(ValidationError, match="unsupported in-memory engine.*valkey"):
        InMemoryPrimitive(engine="valkey", version=8)


def test_in_memory_primitive__version_positive():
    im = InMemoryPrimitive(engine="redis", version=7)
    assert im.version == 7


def test_in_memory_primitive__version_zero_rejected():
    with pytest.raises(ValidationError, match="version must be a positive integer"):
        InMemoryPrimitive(engine="redis", version=0)


def test_in_memory_primitive__version_negative_rejected():
    with pytest.raises(ValidationError, match="version must be a positive integer"):
        InMemoryPrimitive(engine="redis", version=-1)


def test_manifest__full():
    m = Manifest(
        version=1,
        name="my-saas",
        compute={
            "app": ComputeProcess(mode="app", port=8000),
            "worker": ComputeProcess(mode="worker"),
        },
        data=DataPrimitive(engine="postgres", version=17),
        in_memory=InMemoryPrimitive(engine="redis", version=7),
    )
    assert m.version == 1
    assert m.name == "my-saas"
    assert len(m.compute) == 2
    assert m.compute["app"].port == 8000
    assert m.compute["worker"].port is None
    assert m.data.engine == "postgres"
    assert m.in_memory.engine == "redis"


def test_manifest__minimal():
    m = Manifest(
        version=1,
        name="my-api",
        compute={"app": ComputeProcess(mode="app", port=8000)},
    )
    assert m.data is None
    assert m.in_memory is None


def test_manifest__in_memory_alias():
    """in-memory (hyphenated YAML key) maps to in_memory Python field."""
    m = Manifest(
        **{
            "version": 1,
            "name": "test-app",
            "compute": {"app": {"mode": "app", "port": 8000}},
            "in-memory": {"engine": "redis", "version": 7},
        }
    )
    assert m.in_memory is not None
    assert m.in_memory.engine == "redis"
    assert m.in_memory.version == 7


def test_manifest__in_memory_python_name():
    """in_memory (Python name) also works via populate_by_name."""
    m = Manifest(
        version=1,
        name="test-app",
        compute={"app": ComputeProcess(mode="app", port=8000)},
        in_memory=InMemoryPrimitive(engine="redis", version=7),
    )
    assert m.in_memory.engine == "redis"


def _minimal_manifest(**overrides):
    defaults = {
        "version": 1,
        "name": "test-app",
        "compute": {"app": ComputeProcess(mode="app", port=8000)},
    }
    defaults.update(overrides)
    return defaults


def test_manifest__version_1_passes():
    m = Manifest(**_minimal_manifest(version=1))
    assert m.version == 1


def test_manifest__version_2_rejected():
    with pytest.raises(ValidationError, match="unsupported manifest version"):
        Manifest(**_minimal_manifest(version=2))


def test_manifest__version_0_rejected():
    with pytest.raises(ValidationError, match="unsupported manifest version"):
        Manifest(**_minimal_manifest(version=0))


def test_manifest__name_valid():
    m = Manifest(**_minimal_manifest(name="my-app"))
    assert m.name == "my-app"


def test_manifest__name_valid_canada_days():
    m = Manifest(**_minimal_manifest(name="canada-days"))
    assert m.name == "canada-days"


def test_manifest__name_too_short_single_char():
    with pytest.raises(ValidationError, match="DNS-safe"):
        Manifest(**_minimal_manifest(name="a"))


def test_manifest__name_too_short_two_chars():
    with pytest.raises(ValidationError, match="DNS-safe"):
        Manifest(**_minimal_manifest(name="ab"))


def test_manifest__name_uppercase():
    with pytest.raises(ValidationError, match="DNS-safe"):
        Manifest(**_minimal_manifest(name="My-App"))


def test_manifest__name_starts_with_hyphen():
    with pytest.raises(ValidationError, match="DNS-safe"):
        Manifest(**_minimal_manifest(name="-bad"))


def test_manifest__name_ends_with_hyphen():
    with pytest.raises(ValidationError, match="DNS-safe"):
        Manifest(**_minimal_manifest(name="bad-"))


def test_manifest__name_too_long():
    long_name = "a" + "b" * 62 + "c"  # 64 chars
    with pytest.raises(ValidationError, match="DNS-safe"):
        Manifest(**_minimal_manifest(name=long_name))


def test_manifest__name_max_length():
    name = "a" + "b" * 61 + "c"  # 63 chars
    m = Manifest(**_minimal_manifest(name=name))
    assert m.name == name


def test_manifest__name_min_length():
    m = Manifest(**_minimal_manifest(name="abc"))
    assert m.name == "abc"


def test_manifest__name_reserved_bluefox_prefix():
    with pytest.raises(ValidationError, match="reserved.*bluefox-"):
        Manifest(**_minimal_manifest(name="bluefox-anything"))


def test_manifest__name_reserved_bluefox_platform():
    with pytest.raises(ValidationError, match="reserved.*bluefox-"):
        Manifest(**_minimal_manifest(name="bluefox-platform"))


def test_manifest__name_bluefox_cloud_allowed():
    m = Manifest(**_minimal_manifest(name="bluefox-cloud"))
    assert m.name == "bluefox-cloud"


def test_manifest__name_not_reserved_without_hyphen():
    m = Manifest(**_minimal_manifest(name="bluefoxapp"))
    assert m.name == "bluefoxapp"


def test_manifest__compute_empty_rejected():
    with pytest.raises(ValidationError, match="at least one process"):
        Manifest(**_minimal_manifest(compute={}))


def test_manifest__compute_one_process_passes():
    m = Manifest(**_minimal_manifest(compute={"app": ComputeProcess(mode="app", port=8000)}))
    assert len(m.compute) == 1


def test_manifest__single_port_passes():
    m = Manifest(**_minimal_manifest(compute={
        "app": ComputeProcess(mode="app", port=8000),
        "worker": ComputeProcess(mode="worker"),
    }))
    assert len(m.compute) == 2


def test_manifest__zero_ports_passes():
    m = Manifest(**_minimal_manifest(compute={
        "worker1": ComputeProcess(mode="worker1"),
        "worker2": ComputeProcess(mode="worker2"),
    }))
    assert len(m.compute) == 2


def test_manifest__multiple_ports_rejected():
    with pytest.raises(ValidationError, match="only one compute process may declare port"):
        Manifest(**_minimal_manifest(compute={
            "app": ComputeProcess(mode="app", port=8000),
            "frontend": ComputeProcess(mode="frontend", port=3000),
        }))


def test_manifest__healthcheck_defaults_on_routable():
    m = Manifest(**_minimal_manifest(compute={
        "app": ComputeProcess(mode="app", port=8000),
    }))
    assert m.compute["app"].healthcheck == "/health"


def test_manifest__healthcheck_custom_on_routable():
    m = Manifest(**_minimal_manifest(compute={
        "app": ComputeProcess(mode="app", port=8000, healthcheck="/ready"),
    }))
    assert m.compute["app"].healthcheck == "/ready"


def test_manifest__healthcheck_none_on_worker():
    m = Manifest(**_minimal_manifest(compute={
        "app": ComputeProcess(mode="app", port=8000),
        "worker": ComputeProcess(mode="worker"),
    }))
    assert m.compute["worker"].healthcheck is None


def test_manifest__healthcheck_on_worker_rejected():
    with pytest.raises(ValidationError, match="healthcheck is only valid"):
        Manifest(**_minimal_manifest(compute={
            "worker": ComputeProcess(mode="worker", healthcheck="/health"),
        }))


# --- Service name helpers ---


def _full_manifest(**overrides):
    defaults = {
        "version": 1,
        "name": "my-saas",
        "compute": {
            "app": ComputeProcess(mode="app", port=8000),
            "worker": ComputeProcess(mode="worker"),
        },
        "data": DataPrimitive(engine="postgres", version=17),
        "in_memory": InMemoryPrimitive(engine="redis", version=7),
    }
    defaults.update(overrides)
    return defaults


def test_manifest__service_name_app():
    m = Manifest(**_full_manifest())
    assert m.service_name("app") == "my-saas_app"


def test_manifest__service_name_worker():
    m = Manifest(**_full_manifest())
    assert m.service_name("worker") == "my-saas_worker"


def test_manifest__db_service_name_with_data():
    m = Manifest(**_full_manifest())
    assert m.db_service_name() == "my-saas-db"


def test_manifest__db_service_name_without_data():
    m = Manifest(**_minimal_manifest())
    assert m.db_service_name() is None


def test_manifest__redis_service_name_with_in_memory():
    m = Manifest(**_full_manifest())
    assert m.redis_service_name() == "my-saas-redis"


def test_manifest__redis_service_name_without_in_memory():
    m = Manifest(**_minimal_manifest())
    assert m.redis_service_name() is None


# --- Docker image tag helpers ---


def test_manifest__image_tag():
    m = Manifest(**_full_manifest())
    assert m.image_tag(3) == "localhost:5000/my-saas:v3"


def test_manifest__image_tag_version_1():
    m = Manifest(**_full_manifest())
    assert m.image_tag(1) == "localhost:5000/my-saas:v1"


def test_manifest__db_image_with_data():
    m = Manifest(**_full_manifest())
    assert m.db_image() == "postgres:17-alpine"


def test_manifest__db_image_without_data():
    m = Manifest(**_minimal_manifest())
    assert m.db_image() is None


def test_manifest__redis_image_with_in_memory():
    m = Manifest(**_full_manifest())
    assert m.redis_image() == "redis:7-alpine"


def test_manifest__redis_image_without_in_memory():
    m = Manifest(**_minimal_manifest())
    assert m.redis_image() is None


# --- Environment variable helpers ---


def test_manifest__routable_process_with_port():
    m = Manifest(**_full_manifest())
    name, proc = m.routable_process()
    assert name == "app"
    assert proc.port == 8000


def test_manifest__routable_process_headless():
    m = Manifest(**_minimal_manifest(compute={
        "worker": ComputeProcess(mode="worker"),
    }))
    assert m.routable_process() is None


def test_manifest__env_vars_app():
    m = Manifest(**_full_manifest())
    env = m.env_vars("app")
    assert env == {"APP_NAME": "my-saas", "MODE": "app", "PORT": "8000"}


def test_manifest__env_vars_worker():
    m = Manifest(**_full_manifest())
    env = m.env_vars("worker")
    assert env == {"APP_NAME": "my-saas", "MODE": "worker"}
    assert "PORT" not in env
