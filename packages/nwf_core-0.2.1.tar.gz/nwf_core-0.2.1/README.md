# nwf-core

[![PyPI version](https://badge.fury.io/py/nwf-core.svg)](https://pypi.org/project/nwf-core/)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![Tests](https://github.com/romero19912017-ui/nwf-core/actions/workflows/test.yml/badge.svg)](https://github.com/romero19912017-ui/nwf-core/actions/workflows/test.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Core library for **Neural Weight Fields (NWF)** - charge, field, metrics, indices, calibration.

## Installation

```bash
pip install nwf-core
# With FAISS: pip install nwf-core[faiss]
# With VAE (torch): pip install nwf-core[torch]
# All: pip install nwf-core[all]
```

## Quick start

```python
import numpy as np
from nwf import Charge, Field, mahalanobis_symmetric

# Create charges
c1 = Charge(z=np.array([0.0, 0.0]), sigma=np.array([0.1, 0.1]))
c2 = Charge(z=np.array([1.0, 1.0]), sigma=np.array([0.1, 0.1]))

# Build field and search
field = Field()
field.add([c1, c2], labels=[0, 1])
distances, indices, labels = field.search(c1, k=2)
```

See [documentation](https://romero19912017-ui.github.io/nwf-core/) and [nwf-vision](https://github.com/romero19912017-ui/nwf-vision) for examples.

## Components

- **Charge**: `(z, sigma)` - center and diagonal covariance
- **Field**: Container for charges with add/remove/search
- **Metric**: mahalanobis_symmetric, euclidean, cosine
- **Index**: BruteForceIndex, FAISSIndex (l2, cosine, ip; optional rerank with Mahalanobis)
- **Calibration**: AgreementRatio, PlattScaler
- **Encoders**: VAEEncoder (optional, requires torch)

## Development

```bash
pip install -e ".[dev,docs]"
pre-commit install   # optional: run checks before commit
make lint            # black, isort, flake8
make format          # auto-format
make html            # build Sphinx docs -> docs/_build/html
```

## License

MIT
