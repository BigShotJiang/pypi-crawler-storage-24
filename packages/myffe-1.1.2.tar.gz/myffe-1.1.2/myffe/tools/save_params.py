import json
import os
from myffe.tools.color_printer import ColorPrinter


def save_config(config, path='ffe_config.json'):
    """保存配置到文件
    
    Args:
        config (dict): 参数字典
        path (str): 保存路径，默认为 'ffe_config.json'
    
    Returns:
        bool: 保存是否成功
    """
    try:
        # 确保目录存在
        dir_path = os.path.dirname(path)
        if dir_path and not os.path.exists(dir_path):
            os.makedirs(dir_path)
        
        # 保存配置
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        ColorPrinter.print_success(f"配置已保存到 {path}")
        return True
    except Exception as e:
        ColorPrinter.print_error(f"保存配置失败: {e}")
        return False


def load_config(path='ffe_config.json'):
    """从文件加载配置
    
    Args:
        path (str): 配置文件路径，默认为 'ffe_config.json'
    
    Returns:
        dict: 加载的参数字典，如果加载失败返回空字典
    """
    try:
        if not os.path.exists(path):
            ColorPrinter.print_warning(f"配置文件 {path} 不存在")
            return {}
        
        with open(path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        ColorPrinter.print_success(f"配置已从 {path} 加载")
        return config
    except Exception as e:
        ColorPrinter.print_error(f"加载配置失败: {e}")
        return {}


def get_default_config_path():
    """获取默认配置文件路径
    
    Returns:
        str: 默认配置文件路径
    """
    # 默认保存在当前目录
    return os.path.join(os.getcwd(), 'ffe_config.json')


def process_save_path(path):
    """
    处理保存路径，包括路径验证和交互式选择
    
    Args:
        path (str): 用户提供的路径
        
    Returns:
        str: 验证后的路径或None（如果跳过）
    """
    from pathlib import Path
    from datetime import datetime
    
    # 转换为Path对象
    path_obj = Path(path)
    
    # 检查路径是否存在
    if path_obj.exists():
        if path_obj.is_dir():
            # 如果是目录，使用默认文件名
            return str(path_obj / f"ffe_params_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        else:
            # 如果是文件，直接使用
            return str(path_obj)
    
    # 路径不存在，搜索相似文件名
    similar_files = find_similar_files(path_obj)
    
    if similar_files:
        # 让用户从相似文件中选择
        return prompt_file_selection(similar_files)
    else:
        # 没有找到相似文件，询问用户
        return prompt_no_file_found(path)


def find_similar_files(path_obj):
    """
    在父目录中查找相似文件名
    
    Args:
        path_obj (Path): 目标路径
        
    Returns:
        list: 相似文件路径列表
    """
    similar_files = []
    target_name = path_obj.name
    
    # 在当前目录和父目录中搜索（最多2层）
    for i in range(3):  # 当前目录 + 2个父目录
        search_dir = path_obj.parent
        if not search_dir.exists():
            break
        
        # 查找名称中包含目标名称的文件
        for file in search_dir.iterdir():
            if file.is_file() and target_name in file.name:
                similar_files.append(str(file))
        
        # 向上移动一层
        path_obj = search_dir
    
    return similar_files


def prompt_file_selection(files):
    """
    提示用户从相似文件中选择
    
    Args:
        files (list): 相似文件路径列表
        
    Returns:
        str: 选中的文件路径或None（如果跳过）
    """
    try:
        from myffe.tools.interactive import interactive_select
        
        # 添加跳过选项
        options = files + ["skip"]
        
        ColorPrinter.print_info("找到相似文件:")
        for i, file in enumerate(options):
            ColorPrinter.print_info(f"{i+1}. {file}")
        
        # 使用交互式选择
        selected = interactive_select(
            "选择一个文件来保存参数，或跳过:",
            options,
            default=len(options)-1  # 默认选择跳过
        )
        
        if selected == "skip":
            ColorPrinter.print_info("跳过参数保存")
            return None
        else:
            return selected
    except ImportError:
        # 如果交互式模块不可用
        ColorPrinter.print_warning("交互式模块不可用，跳过参数保存")
        return None


def prompt_no_file_found(path):
    """
    当没有找到相似文件时提示用户
    
    Args:
        path (str): 原始路径
        
    Returns:
        str: 用户选择的路径或None（如果跳过）
    """
    try:
        from myffe.tools.interactive import interactive_select
        
        options = ["跳过", "使用原始路径（如果需要则创建）"]
        
        ColorPrinter.print_warning(f"文件不存在: {path}")
        ColorPrinter.print_info("未找到相似文件")
        
        selected = interactive_select(
            "您想要做什么?",
            options,
            default=0  # 默认选择跳过
        )
        
        if selected == "跳过":
            ColorPrinter.print_info("跳过参数保存")
            return None
        else:
            # 使用原始路径，必要时创建目录
            from pathlib import Path
            path_obj = Path(path)
            if not path_obj.parent.exists():
                path_obj.parent.mkdir(parents=True, exist_ok=True)
            return path
    except ImportError:
        # 如果交互式模块不可用
        ColorPrinter.print_warning("交互式模块不可用，跳过参数保存")
        return None
