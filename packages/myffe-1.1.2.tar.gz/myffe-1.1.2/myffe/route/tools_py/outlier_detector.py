import numpy as np
from scipy import stats

def is_numeric_columns(col):
    """检查列是否为数值列"""
    for s in col:
        try:
            float(s)
        except ValueError:  
            return False
    return True

def detect_outliers_iqr(data, column):
    """使用IQR方法检测异常值"""
    Q1 = data[column].quantile(0.25)
    Q3 = data[column].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    outliers = data[(data[column] < lower_bound) | (data[column] > upper_bound)]
    return len(outliers) > 0

def detect_outliers_zscore(data, column):
    """使用Z-score方法检测异常值"""
    z_scores = np.abs(stats.zscore(data[column]))
    outliers = data[z_scores > 3]
    return len(outliers) > 0
