import pandas as pd
import numpy as np
import asyncio
from myffe.tools.color_printer import ColorPrinter

async def detect_time_columns(data):
    """异步检测时间列
    
    Args:
        data: pandas DataFrame，输入数据
        
    Returns:
        list: 检测到的时间列列表
    """
    time_columns = []
    # 常见的时间列名称
    time_column_names = [
        'date', 'time', 'timestamp', 'datetime', 'Date', 'Time', 'Timestamp', 'Datetime',
        'created_at', 'updated_at', 'start_time', 'end_time', 'event_time', 'record_time',
        'order_time', 'purchase_time', 'transaction_time', 'register_time', 'login_time',
        'created', 'updated', 'start', 'end', 'event', 'record',
        'order', 'purchase', 'transaction', 'register', 'login'
    ]
    
    # 首先检查常见的时间列名称
    for col in data.columns:
        if col.lower() in [name.lower() for name in time_column_names]:
            time_columns.append(col)
    
    # 检查已经是datetime类型的列
    for col in data.columns:
        if pd.api.types.is_datetime64_any_dtype(data[col]):
            if col not in time_columns:
                time_columns.append(col)
    
    # 尝试检测具有时间格式的列
    if not time_columns:
        for col in data.columns:
            # 跳过数字列
            if pd.api.types.is_numeric_dtype(data[col]):
                continue
                
            # 处理字符串类型的列
            if data[col].dtype == 'object' or data[col].dtype == 'string' or str(data[col].dtype) == 'str':
                try:
                    # 尝试将列转换为数字，如果能转换则排除
                    numeric_data = pd.to_numeric(data[col], errors='coerce')
                    if numeric_data.notnull().mean() > 0.9:  # 90%以上能转换为数字，则排除
                        continue
                        
                    # 只取第一行数据进行测试
                    first_value = data[col].iloc[0]
                    if pd.isna(first_value):
                        continue
                        
                    # 检查第一行是否为时间格式
                    time_data = pd.to_datetime(first_value, errors='coerce')
                    if pd.notna(time_data):
                        # 检查整体转换率
                        full_time_data = pd.to_datetime(data[col], errors='coerce')
                        conversion_rate = full_time_data.notnull().mean()
                        if conversion_rate > 0.6:  # 至少60%的数据可以转换为时间
                            time_columns.append(col)
                except Exception as e:
                    ColorPrinter.print_warning(f"检测列 {col} 时出错: {e}")
    
    return time_columns

async def analyze_time_column(data, col):
    """异步分析时间列特征
    
    Args:
        data: pandas DataFrame，输入数据
        col: 时间列名
        
    Returns:
        dict: 时间列特征分析结果
    """
    result = {
        'column': col,
        'has_time_info': False,
        'recommended_type': 'basic'
    }
    
    try:
        # 检查时间列是否包含时分秒信息
        test_data = pd.to_datetime(data[col], errors='coerce')
        
        # 检查是否有小时信息
        has_time_info = False
        try:
            hour_info = test_data.dt.hour
            has_time_info = not hour_info.isnull().all()
            result['has_time_info'] = has_time_info
        except Exception:
            pass
        
        # 检查数据量，数据量较大时推荐高级处理
        if len(data) > 1000 or has_time_info:
            result['recommended_type'] = 'advance'
    except Exception as e:
        ColorPrinter.print_warning(f"分析列 {col} 时出错: {e}")
    
    return result

async def batch_analyze_time_columns(data, time_columns):
    """批量分析时间列
    
    Args:
        data: pandas DataFrame，输入数据
        time_columns: 时间列列表
        
    Returns:
        list: 时间列分析结果列表
    """
    tasks = []
    for col in time_columns:
        task = asyncio.create_task(analyze_time_column(data, col))
        tasks.append(task)
    
    results = await asyncio.gather(*tasks)
    return results
