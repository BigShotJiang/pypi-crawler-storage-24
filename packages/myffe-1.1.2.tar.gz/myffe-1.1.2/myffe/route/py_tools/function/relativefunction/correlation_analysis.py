import pandas as pd
import numpy as np


def calculate_correlation_matrix(data, selected_cols):
    """计算相关性矩阵
    
    Args:
        data: pandas DataFrame，输入数据
        selected_cols: list，选择的列
    
    Returns:
        pd.DataFrame: 相关性矩阵
    """
    return data[selected_cols].corr()


def analyze_correlation_features(corr_matrix):
    """分析相关性特征
    
    Args:
        corr_matrix: pd.DataFrame，相关性矩阵
    
    Returns:
        tuple: (max_corr, mean_corr)，最大相关性和平均相关性
    """
    max_corr = corr_matrix.abs().max().max()
    mean_corr = corr_matrix.abs().mean().mean()
    return max_corr, mean_corr


def analyze_data_features(data, selected_cols):
    """分析数据特征
    
    Args:
        data: pandas DataFrame，输入数据
        selected_cols: list，选择的列
    
    Returns:
        tuple: (data_size, num_features)，数据大小和特征数量
    """
    data_size = len(data)
    num_features = len(selected_cols)
    return data_size, num_features
