# 预定义特征工程路线
# 用户可以通过传入数字来选择不同的预定义路线

import sys
import os
import pandas as pd
from myffe.tools.color_printer import ColorPrinter
from myffe.tools.interactive import interactive
from myffe.tools.interactive_utils import get_interactive_choice

# 添加MFM目录到路径
current_dir = os.path.dirname(os.path.abspath(__file__))
route_dir = os.path.dirname(current_dir)
ffe_dir = os.path.dirname(route_dir)
mfm_dir = os.path.dirname(os.path.dirname(ffe_dir))  # 向上两级目录，得到 D:\HP\pythonwork\MFM
if mfm_dir not in sys.path:
    sys.path.append(mfm_dir)

# 全局routes字典，避免重复定义
ROUTES = {
    1: {
        "name": "基础路线",
        "description": "适合大多数数据集的基础预处理流程",
        "tools": ["缺失值处理", "异常值处理", "数据标准化"],
        "suitable_for": "通用数据集，快速处理"
    },
    2: {
        "name": "股票数据路线",
        "description": "专为股票数据优化的预处理流程",
        "tools": ["缺失值处理", "异常值处理", "时间处理", "特征工程", "数据标准化"],
        "suitable_for": "股票价格、交易量等金融时间序列数据"
    },
    3: {
        "name": "文本数据路线",
        "description": "包含文本处理的预处理流程",
        "tools": ["缺失值处理", "文本处理", "数据标准化"],
        "suitable_for": "包含文本特征的数据集"
    },
    4: {
        "name": "时间序列路线",
        "description": "强化时间特征提取的预处理流程",
        "tools": ["缺失值处理", "时间处理", "特征工程", "数据标准化"],
        "suitable_for": "时间序列预测任务"
    },
    5: {
        "name": "完整路线",
        "description": "包含所有预处理步骤的完整流程",
        "tools": ["缺失值处理", "异常值处理", "时间处理", "特征工程", "数据标准化", "数据归一化"],
        "suitable_for": "需要全面处理的复杂数据集"
    },
    6: {
        "name": "轻量级路线",
        "description": "快速处理小数据集的轻量级流程",
        "tools": ["缺失值处理", "数据标准化"],
        "suitable_for": "小数据集，快速原型开发"
    },
    7: {
        "name": "异常检测路线",
        "description": "专注于异常值检测和处理的流程",
        "tools": ["缺失值处理", "异常值处理", "数据标准化"],
        "suitable_for": "需要严格异常值处理的数据集"
    },
    8: {
        "name": "特征增强路线",
        "description": "强化特征工程的预处理流程",
        "tools": ["缺失值处理", "时间处理", "特征工程", "数据标准化", "数据归一化"],
        "suitable_for": "需要丰富特征的复杂预测任务"
    },
    9: {
        "name": "分类数据路线",
        "description": "适合分类任务的预处理流程",
        "tools": ["缺失值处理", "异常值处理", "文本处理", "特征工程", "数据标准化"],
        "suitable_for": "分类任务数据集"
    },
    10: {
        "name": "回归数据路线",
        "description": "适合回归任务的预处理流程",
        "tools": ["缺失值处理", "异常值处理", "时间处理", "特征工程", "数据标准化", "数据归一化"],
        "suitable_for": "回归任务数据集"
    },
    11: {
        "name": "中文文本路线",
        "description": "专为中文文本数据优化的预处理流程",
        "tools": ["缺失值处理", "文本处理（中文分词）", "特征选择", "数据标准化"],
        "suitable_for": "包含中文文本的数据集，如新闻、评论等"
    },
    12: {
        "name": "不平衡数据路线",
        "description": "处理类别不平衡的数据集的预处理流程",
        "tools": ["缺失值处理", "异常值处理", "样本处理（SMOTE）", "数据标准化"],
        "suitable_for": "类别不平衡的分类数据集"
    },
    13: {
        "name": "高维数据路线",
        "description": "处理特征维度较高的数据集的预处理流程",
        "tools": ["缺失值处理", "特征工程（降维）", "数据标准化"],
        "suitable_for": "高维数据集，如基因表达数据、图像特征等"
    },
    14: {
        "name": "金融数据路线",
        "description": "专为金融数据优化的预处理流程",
        "tools": ["缺失值处理（前向填充）", "异常值处理（Isolation Forest）", "时间处理", "特征工程", "数据标准化"],
        "suitable_for": "金融时间序列数据，如股票、期货、外汇等"
    },
    15: {
        "name": "医疗数据路线",
        "description": "适合医疗数据集的预处理流程",
        "tools": ["缺失值处理（智能填充）", "异常值处理", "特征工程", "数据标准化（RobustScaler）"],
        "suitable_for": "医疗健康数据集，如患者记录、医学影像特征等"
    },
    16: {
        "name": "电商数据路线",
        "description": "专为电商数据优化的预处理流程",
        "tools": ["缺失值处理（众数填充）", "文本处理（产品描述）", "时间处理（购买时间）", "数据标准化（Min-Max）"],
        "suitable_for": "电商交易数据，如用户购买记录、产品信息等"
    },
    17: {
        "name": "社交媒体数据路线",
        "description": "处理社交媒体数据的预处理流程",
        "tools": ["缺失值处理", "文本处理（社交媒体文本）", "时间处理（发布时间）", "数据标准化"],
        "suitable_for": "社交媒体数据，如微博、微信、Twitter等"
    },
    18: {
        "name": "传感器数据路线",
        "description": "处理传感器数据的预处理流程",
        "tools": ["缺失值处理（前向填充）", "异常值处理（多变量检测）", "时间处理", "特征工程（降维）", "数据标准化"],
        "suitable_for": "传感器采集的数据，如工业传感器、IoT设备数据等"
    },
    19: {
        "name": "多模态数据路线",
        "description": "处理包含多种类型数据的数据集的预处理流程",
        "tools": ["缺失值处理（智能填充）", "文本处理", "时间处理", "特征工程", "数据标准化", "数据归一化"],
        "suitable_for": "包含多种数据类型的数据集，如文本+图像+时间序列等"
    },
    20: {
        "name": "实时数据路线",
        "description": "适合实时数据流处理的预处理流程",
        "tools": ["缺失值处理（快速）", "异常值处理（快速）", "时间处理（基础）", "数据标准化"],
        "suitable_for": "实时数据流，如在线推荐系统、实时监控数据等"
    }
}


def get_route_params(route_number, data=None, auto_test=False):
    """
    根据路线编号获取预定义的特征工程参数
    
    Args:
        route_number (int): 路线编号
        1: 基础路线 - 适合大多数数据集
        2: 股票数据路线 - 专为股票数据优化
        3: 文本数据路线 - 包含文本处理
        4: 时间序列路线 - 强化时间特征提取
        5: 完整路线 - 包含所有预处理步骤
        6: 轻量级路线 - 快速处理小数据集
        7: 异常检测路线 - 专注于异常值处理
        8: 特征增强路线 - 强化特征工程
        9: 分类数据路线 - 适合分类任务
        10: 回归数据路线 - 适合回归任务
        11: 中文文本路线 - 专为中文文本数据优化
        12: 不平衡数据路线 - 处理类别不平衡的数据集
        13: 高维数据路线 - 处理特征维度较高的数据集
        14: 金融数据路线 - 专为金融数据优化
        15: 医疗数据路线 - 适合医疗数据集的处理
        16: 电商数据路线 - 专为电商数据优化
        17: 社交媒体数据路线 - 处理社交媒体数据
        18: 传感器数据路线 - 处理传感器数据
        19: 多模态数据路线 - 处理包含多种类型数据的数据集
        20: 实时数据路线 - 适合实时数据流处理
        data (DataFrame, optional): 输入数据集，用于自动检测列信息
        auto_test (bool): 是否为自动测试模式，为True时自动选择所有列
        data (DataFrame, optional): 输入数据集，用于自动检测列信息
    
    Returns:
        dict: 预定义的参数配置
    """
    # 配置前展示所有路线
    ColorPrinter.print_info("配置前 - 所有可用路线:")
    show_routes_visual()
    
    if route_number == 1:
        # 路线1: 基础路线
        ColorPrinter.print_info("选择了路线1: 基础路线 - 适合大多数数据集")
        
        params = {
            'nan_preprocessing': {
                'nan_ways': [
                    {
                        'col': 'all',
                        'method': 'fill_nan_mean',
                        'drop_threshold': 0.5,
                        'knn_n_neighbors': 5
                    }
                ]
            },
            'outlier_preprocessing': {
                'outlier_choice': 'thres_sigma_auto',
                'row_drop_thres': 3.0,
                'auto_drop_row': True,
                'specify_auto_drop_row_extr': 'auto',
                'outlier_action': 'drop',
                'contamination': 0.1,
                'outlier_replace_method': None
            },
            'standard_preprocessing': {
                'standard_ways': [
                    {
                        'col': 'all',
                        'method': 'Z-score标准化'
                    }
                ]
            }
        }
        
    elif route_number == 2:
        # 路线2: 股票数据路线
        ColorPrinter.print_info("选择了路线2: 股票数据路线 - 专为股票数据优化")
        
        params = {
            'nan_preprocessing': {
                'nan_ways': [
                    {
                        'col': 'all',
                        'method': 'fill_nan_mean',
                        'drop_threshold': 0.5,
                        'knn_n_neighbors': 5
                    }
                ]
            },
            'outlier_preprocessing': {
                'outlier_choice': 'thres_sigma_auto',
                'row_drop_thres': 3.0,
                'auto_drop_row': True,
                'specify_auto_drop_row_extr': 'auto',
                'outlier_action': 'drop',
                'contamination': 0.1,
                'outlier_replace_method': None
            },
            'time_preprocessing': {
                'time_col': 'auto',
                'time_type': 'advance'
            },
            'relative_preprocessing': {
                'linear_cols': 'all',
                'linear_threshold': 0.9,
                'feature_cols': 'all',
                'feature_threshold': 0.5,
                'relation_func': 'func1',
                'pca_cols': 'all',
                'n_components': 5,
                'kernel_selection': 'pca',
                'n_features': 10
            },
            'standard_preprocessing': {
                'standard_ways': [
                    {
                        'col': 'all',
                        'method': 'Z-score标准化'
                    }
                ]
            }
        }
        
    elif route_number == 3:
        # 路线3: 文本数据路线
        ColorPrinter.print_info("选择了路线3: 文本数据路线 - 包含文本处理")
        
        params = {
            'nan_preprocessing': {
                'nan_ways': [
                    {
                        'col': 'all',
                        'method': 'fill_nan_mean',
                        'drop_threshold': 0.5,
                        'knn_n_neighbors': 5
                    }
                ]
            },
            'str_preprocessing': {
                'str_ways': [{
                    'method': ['tfidf'],
                    'str_cols': 'all',
                    'tfidf_min_df': 0.01,
                    'tfidf_max_df': 0.95,
                    'tfidf_max_features': 1000,
                    'use_chinese_tokenizer': False,
                    'feature_selection': False,
                    'k_features': 100
                }]
            },
            'standard_preprocessing': {
                'standard_ways': [
                    {
                        'col': 'all',
                        'method': 'Z-score标准化'
                    }
                ]
            }
        }
        
    elif route_number == 4:
        # 路线4: 时间序列路线
        ColorPrinter.print_info("选择了路线4: 时间序列路线 - 强化时间特征提取")
        
        params = {
            'nan_preprocessing': {
                'nan_ways': [
                    {
                        'col': 'all',
                        'method': 'fill_nan_mean',
                        'drop_threshold': 0.5,
                        'knn_n_neighbors': 5
                    }
                ]
            },
            'time_preprocessing': {
                'time_col': 'auto',
                'time_type': 'advance'
            },
            'relative_preprocessing': {
                'linear_cols': 'all',
                'linear_threshold': 0.9,
                'feature_cols': 'all',
                'feature_threshold': 0.5,
                'relation_func': 'func1',
                'pca_cols': 'all',
                'n_components': 3,
                'kernel_selection': 'pca',
                'n_features': 10
            },
            'standard_preprocessing': {
                'standard_ways': [
                    {
                        'col': 'all',
                        'method': 'Z-score标准化'
                    }
                ]
            }
        }
        
    elif route_number == 5:
        # 路线5: 完整路线
        ColorPrinter.print_info("选择了路线5: 完整路线 - 包含所有预处理步骤")
        
        params = {
            'nan_preprocessing': {
                'nan_ways': [
                    {
                        'col': 'all',
                        'method': 'fill_nan_mean',
                        'drop_threshold': 0.5,
                        'knn_n_neighbors': 5
                    }
                ]
            },
            'outlier_preprocessing': {
                'outlier_choice': 'thres_sigma_auto',
                'row_drop_thres': 3.0,
                'auto_drop_row': True,
                'specify_auto_drop_row_extr': 'auto',
                'outlier_action': 'drop',
                'contamination': 0.1,
                'outlier_replace_method': None
            },
            'time_preprocessing': {
                'time_col': 'auto',
                'time_type': 'advance'
            },
            'relative_preprocessing': {
                'linear_cols': 'all',
                'linear_threshold': 0.9,
                'feature_cols': 'all',
                'feature_threshold': 0.5,
                'relation_func': 'func1',
                'pca_cols': 'all',
                'n_components': 3,
                'kernel_selection': 'pca',
                'n_features': 10
            },
            'standard_preprocessing': {
                'standard_ways': [
                    {
                        'col': 'all',
                        'method': 'Z-score标准化'
                    }
                ]
            },
            'normalized_preprocessing': {
                'normalized_ways': [
                    {
                        'col': 'all',
                        'method': 'L2归一化'
                    }
                ]
            },
            'str_preprocessing': {
                'str_ways': []
            },
            'sample_preprocessing': {
                'sample_ways': []
            },
            'specify_preprocessing': {
                'specify_ways': []
            }
        }
        
    elif route_number == 6:
        # 路线6: 轻量级路线
        ColorPrinter.print_info("选择了路线6: 轻量级路线 - 快速处理小数据集")
        
        params = {
            'nan_preprocessing': {
                'nan_ways': [
                    {
                        'col': 'all',
                        'method': 'fill_nan_mean',
                        'drop_threshold': 0.5,
                        'knn_n_neighbors': 5
                    }
                ]
            },
            'standard_preprocessing': {
                'standard_ways': [
                    {
                        'col': 'all',
                        'method': 'Z-score标准化'
                    }
                ]
            }
        }
        
    elif route_number == 7:
        # 路线7: 异常检测路线
        ColorPrinter.print_info("选择了路线7: 异常检测路线 - 专注于异常值处理")
        
        params = {
            'nan_preprocessing': {
                'nan_ways': [
                    {
                        'col': 'all',
                        'method': 'fill_nan_mean',
                        'drop_threshold': 0.5,
                        'knn_n_neighbors': 5
                    }
                ]
            },
            'outlier_preprocessing': {
                'outlier_choice': 'thres_sigma_auto',
                'row_drop_thres': 2.5,
                'auto_drop_row': True,
                'specify_auto_drop_row_extr': 'auto',
                'outlier_action': 'drop',
                'contamination': 0.1,
                'outlier_replace_method': None
            },
            'standard_preprocessing': {
                'standard_ways': [
                    {
                        'col': 'all',
                        'method': 'Z-score标准化'
                    }
                ]
            }
        }
        
    elif route_number == 8:
        # 路线8: 特征增强路线
        ColorPrinter.print_info("选择了路线8: 特征增强路线 - 强化特征工程")
        
        params = {
            'nan_preprocessing': {
                'nan_ways': [
                    {
                        'col': 'all',
                        'method': 'fill_nan_mean',
                        'drop_threshold': 0.5,
                        'knn_n_neighbors': 5
                    }
                ]
            },
            'time_preprocessing': {
                'time_col': 'auto',
                'time_type': 'advance'
            },
            'relative_preprocessing': {
                'linear_cols': 'all',
                'linear_threshold': 0.85,
                'feature_cols': 'all',
                'feature_threshold': 0.5,
                'relation_func': 'func1',
                'pca_cols': 'all',
                'n_components': 4,
                'kernel_selection': 'pca',
                'n_features': 10
            },
            'standard_preprocessing': {
                'standard_ways': [
                    {
                        'col': 'all',
                        'method': 'Z-score标准化'
                    }
                ]
            },
            'normalized_preprocessing': {
                'normalized_ways': [
                    {
                        'col': 'all',
                        'method': 'L2归一化'
                    }
                ]
            }
        }
        
    elif route_number == 9:
        # 路线9: 分类数据路线
        ColorPrinter.print_info("选择了路线9: 分类数据路线 - 适合分类任务")
        
        params = {
            'nan_preprocessing': {
                'nan_ways': [
                    {
                        'col': 'all',
                        'method': 'fill_nan_mean',
                        'drop_threshold': 0.5,
                        'knn_n_neighbors': 5
                    }
                ]
            },
            'outlier_preprocessing': {
                'outlier_choice': 'thres_sigma_auto',
                'row_drop_thres': 3.0,
                'auto_drop_row': True,
                'specify_auto_drop_row_extr': 'auto',
                'outlier_action': 'drop',
                'contamination': 0.1,
                'outlier_replace_method': None
            },
            'str_preprocessing': {
                'str_ways': [{
                    'method': ['tfidf'],
                    'str_cols': 'all',
                    'tfidf_min_df': 0.01,
                    'tfidf_max_df': 0.95,
                    'tfidf_max_features': 1000,
                    'use_chinese_tokenizer': False,
                    'feature_selection': False,
                    'k_features': 100
                }]
            },
            'relative_preprocessing': {
                'linear_cols': 'all',
                'linear_threshold': 0.9,
                'feature_cols': 'all',
                'feature_threshold': 0.5,
                'relation_func': 'func1',
                'pca_cols': 'all',
                'n_components': 5,
                'kernel_selection': 'pca',
                'n_features': 10
            },
            'standard_preprocessing': {
                'standard_ways': [
                    {
                        'col': 'all',
                        'method': 'Z-score标准化'
                    }
                ]
            }
        }
        
    elif route_number == 10:
        # 路线10: 回归数据路线
        ColorPrinter.print_info("选择了路线10: 回归数据路线 - 适合回归任务")
        
        params = {
            'nan_preprocessing': {
                'nan_ways': [
                    {
                        'col': 'all',
                        'method': 'fill_nan_mean',
                        'drop_threshold': 0.5,
                        'knn_n_neighbors': 5
                    }
                ]
            },
            'outlier_preprocessing': {
                'outlier_choice': 'thres_sigma_auto',
                'row_drop_thres': 3.0,
                'auto_drop_row': True,
                'specify_auto_drop_row_extr': 'auto',
                'outlier_action': 'drop',
                'contamination': 0.1,
                'outlier_replace_method': None
            },
            'time_preprocessing': {
                'time_col': 'auto',
                'time_type': 'advance'
            },
            'relative_preprocessing': {
                'linear_cols': 'all',
                'linear_threshold': 0.9,
                'feature_cols': 'all',
                'feature_threshold': 0.5,
                'relation_func': 'func1',
                'pca_cols': 'all',
                'n_components': 3,
                'kernel_selection': 'pca',
                'n_features': 10
            },
            'standard_preprocessing': {
                'standard_ways': [
                    {
                        'col': 'all',
                        'method': 'Z-score标准化'
                    }
                ]
            },
            'normalized_preprocessing': {
                'normalized_ways': [
                    {
                        'col': 'all',
                        'method': 'L2归一化'
                    }
                ]
            }
        }
        
    elif route_number == 11:
        # 路线11: 中文文本路线
        ColorPrinter.print_info("选择了路线11: 中文文本路线 - 专为中文文本数据优化")
        
        params = {
            'nan_preprocessing': {
                'nan_ways': [
                    {
                        'col': 'all',
                        'method': 'fill_nan_mean',
                        'drop_threshold': 0.5,
                        'knn_n_neighbors': 5
                    }
                ]
            },
            'str_preprocessing': {
                'str_ways': [{
                    'method': ['tfidf'],
                    'str_cols': 'all',
                    'tfidf_min_df': 0.01,
                    'tfidf_max_df': 0.95,
                    'tfidf_max_features': 2000,
                    'use_chinese_tokenizer': True,
                    'feature_selection': True,
                    'k_features': 1000
                }]
            },
            'standard_preprocessing': {
                'standard_ways': [
                    {
                        'col': 'all',
                        'method': 'Z-score标准化'
                    }
                ]
            }
        }
        
    elif route_number == 12:
        # 路线12: 不平衡数据路线
        ColorPrinter.print_info("选择了路线12: 不平衡数据路线 - 处理类别不平衡的数据集")
        
        params = {
            'nan_preprocessing': {
                'nan_ways': [
                    {
                        'col': 'all',
                        'method': 'fill_nan_mean',
                        'drop_threshold': 0.5,
                        'knn_n_neighbors': 5
                    }
                ]
            },
            'outlier_preprocessing': {
                'outlier_choice': 'thres_sigma_auto',
                'row_drop_thres': 3.0,
                'auto_drop_row': True,
                'specify_auto_drop_row_extr': 'auto',
                'outlier_action': 'drop',
                'contamination': 0.1,
                'outlier_replace_method': None
            },
            'sample_preprocessing': {
                'sample_ways': [
                    {
                        'mode': 'advance',
                        'method': ['MY_high_sample'],
                        'balance_method': 'oversample',
                        'random_state': 42,
                        'high_sample_selection': 'BorderlineSMOTE'
                    }
                ]
            },
            'standard_preprocessing': {
                'standard_ways': [
                    {
                        'col': 'all',
                        'method': 'Z-score标准化'
                    }
                ]
            }
        }
        
    elif route_number == 13:
        # 路线13: 高维数据路线
        ColorPrinter.print_info("选择了路线13: 高维数据路线 - 处理特征维度较高的数据集")
        
        params = {
            'nan_preprocessing': {
                'nan_ways': [
                    {
                        'col': 'all',
                        'method': 'fill_nan_mean',
                        'drop_threshold': 0.5,
                        'knn_n_neighbors': 5
                    }
                ]
            },
            'relative_preprocessing': {
                'linear_cols': 'all',
                'linear_threshold': 0.9,
                'feature_cols': 'all',
                'feature_threshold': 0.5,
                'relation_func': 'func1',
                'pca_cols': 'all',
                'n_components': 50,
                'kernel_selection': 'pca',
                'n_features': 10
            },
            'standard_preprocessing': {
                'standard_ways': [
                    {
                        'col': 'all',
                        'method': 'Z-score标准化'
                    }
                ]
            }
        }
        
    elif route_number == 14:
        # 路线14: 金融数据路线
        ColorPrinter.print_info("选择了路线14: 金融数据路线 - 专为金融数据优化")
        
        params = {
            'nan_preprocessing': {
                'nan_ways': [
                    {
                        'col': 'all',
                        'method': 'fill_nan_forward',
                        'drop_threshold': 0.5,
                        'knn_n_neighbors': 5
                    }
                ]
            },
            'outlier_preprocessing': {
                'outlier_choice': 'isolation_forest',
                'row_drop_thres': 3.0,
                'auto_drop_row': True,
                'specify_auto_drop_row_extr': 'auto',
                'outlier_action': 'replace',
                'contamination': 0.1,
                'outlier_replace_method': 'median'
            },
            'time_preprocessing': {
                'time_col': 'auto',
                'time_type': 'advance'
            },
            'relative_preprocessing': {
                'linear_cols': 'all',
                'linear_threshold': 0.9,
                'feature_cols': 'all',
                'feature_threshold': 0.5,
                'relation_func': 'func1',
                'pca_cols': 'all',
                'n_components': 3,
                'kernel_selection': 'pca',
                'n_features': 10
            },
            'standard_preprocessing': {
                'standard_ways': [
                    {
                        'col': 'all',
                        'method': 'Z-score标准化'
                    }
                ]
            }
        }
        
    elif route_number == 15:
        # 路线15: 医疗数据路线
        ColorPrinter.print_info("选择了路线15: 医疗数据路线 - 适合医疗数据集的处理")
        
        params = {
            'nan_preprocessing': {
                'nan_ways': [
                    {
                        'col': 'all',
                        'method': 'fill_nan_intelligent',  # 智能填充适合医疗数据
                        'drop_threshold': 0.3,  # 更严格的缺失值阈值
                        'knn_n_neighbors': 5
                    }
                ]
            },
            'outlier_preprocessing': {
                'outlier_choice': 'boxplot',
                'row_drop_thres': 3.0,
                'auto_drop_row': True,
                'specify_auto_drop_row_extr': 'auto',
                'outlier_action': 'replace',
                'contamination': 0.1,
                'outlier_replace_method': 'median'
            },
            'relative_preprocessing': {
                'linear_cols': 'all',
                'linear_threshold': 0.85,
                'feature_cols': 'all',
                'feature_threshold': 0.5,
                'relation_func': 'func1',
                'pca_cols': 'all',
                'n_components': 5,
                'kernel_selection': 'pca',
                'n_features': 10
            },
            'standard_preprocessing': {
                'standard_ways': [
                    {
                        'col': 'all',
                        'method': 'RobustScaler标准化'  # 对异常值不敏感
                    }
                ]
            }
        }
        
    elif route_number == 16:
        # 路线16: 电商数据路线
        ColorPrinter.print_info("选择了路线16: 电商数据路线 - 专为电商数据优化")
        
        params = {
            'nan_preprocessing': {
                'nan_ways': [
                    {
                        'col': 'all',
                        'method': 'fill_nan_mode',  # 众数填充适合分类数据
                        'drop_threshold': 0.5,
                        'knn_n_neighbors': 5
                    }
                ]
            },
            'str_preprocessing': {
                'str_ways': [{
                    'method': ['tfidf'],
                    'str_cols': 'all',
                    'tfidf_min_df': 0.001,
                    'tfidf_max_df': 0.9,
                    'tfidf_max_features': 1500,
                    'use_chinese_tokenizer': True,
                    'feature_selection': False,
                    'k_features': 100
                }]
            },
            'time_preprocessing': {
                'time_col': 'auto',
                'time_type': 'advance'
            },
            'standard_preprocessing': {
                'standard_ways': [
                    {
                        'col': 'all',
                        'method': 'Min-Max标准化'  # 缩放到[0,1]范围
                    }
                ]
            }
        }
        
    elif route_number == 17:
        # 路线17: 社交媒体数据路线
        ColorPrinter.print_info("选择了路线17: 社交媒体数据路线 - 处理社交媒体数据")
        
        params = {
            'nan_preprocessing': {
                'nan_ways': [
                    {
                        'col': 'all',
                        'method': 'fill_nan_mode',
                        'drop_threshold': 0.5,
                        'knn_n_neighbors': 5
                    }
                ]
            },
            'str_preprocessing': {
                'str_ways': [{
                    'method': ['tfidf'],
                    'str_cols': 'all',
                    'tfidf_min_df': 0.001,
                    'tfidf_max_df': 0.8,
                    'tfidf_max_features': 3000,
                    'use_chinese_tokenizer': True,
                    'feature_selection': True,
                    'k_features': 1500
                }]
            },
            'time_preprocessing': {
                'time_col': 'auto',
                'time_type': 'advance'
            },
            'standard_preprocessing': {
                'standard_ways': [
                    {
                        'col': 'all',
                        'method': 'Z-score标准化'
                    }
                ]
            }
        }
        
    elif route_number == 18:
        # 路线18: 传感器数据路线
        ColorPrinter.print_info("选择了路线18: 传感器数据路线 - 处理传感器数据")
        
        params = {
            'nan_preprocessing': {
                'nan_ways': [
                    {
                        'col': 'all',
                        'method': 'fill_nan_forward',  # 前向填充适合时间序列传感器数据
                        'drop_threshold': 0.2,  # 更严格的缺失值阈值
                        'knn_n_neighbors': 5
                    }
                ]
            },
            'outlier_preprocessing': {
                'outlier_choice': 'multivariate',  # 多变量异常检测适合传感器数据
                'row_drop_thres': 3.0,
                'auto_drop_row': True,
                'specify_auto_drop_row_extr': 'auto',
                'outlier_action': 'replace',
                'contamination': 0.1,
                'outlier_replace_method': 'median'
            },
            'time_preprocessing': {
                'time_col': 'auto',
                'time_type': 'advance'
            },
            'relative_preprocessing': {
                'linear_cols': 'all',
                'linear_threshold': 0.9,
                'feature_cols': 'all',
                'feature_threshold': 0.5,
                'relation_func': 'func1',
                'pca_cols': 'all',
                'n_components': 10,
                'kernel_selection': 'pca',
                'n_features': 10
            },
            'standard_preprocessing': {
                'standard_ways': [
                    {
                        'col': 'all',
                        'method': 'Z-score标准化'
                    }
                ]
            }
        }
        
    elif route_number == 19:
        # 路线19: 多模态数据路线
        ColorPrinter.print_info("选择了路线19: 多模态数据路线 - 处理包含多种类型数据的数据集")
        
        params = {
            'nan_preprocessing': {
                'nan_ways': [
                    {
                        'col': 'all',
                        'method': 'fill_nan_intelligent',
                        'drop_threshold': 0.5,
                        'knn_n_neighbors': 5
                    }
                ]
            },
            'str_preprocessing': {
                'str_ways': [{
                    'method': ['tfidf'],
                    'str_cols': 'all',
                    'tfidf_min_df': 0.01,
                    'tfidf_max_df': 0.9,
                    'tfidf_max_features': 2000,
                    'use_chinese_tokenizer': True,
                    'feature_selection': True,
                    'k_features': 1000
                }]
            },
            'time_preprocessing': {
                'time_col': 'auto',
                'time_type': 'advance'
            },
            'relative_preprocessing': {
                'linear_cols': 'all',
                'linear_threshold': 0.9,
                'feature_cols': 'all',
                'feature_threshold': 0.5,
                'relation_func': 'func1',
                'pca_cols': 'all',
                'n_components': 50,
                'kernel_selection': 'pca',
                'n_features': 10
            },
            'standard_preprocessing': {
                'standard_ways': [
                    {
                        'col': 'all',
                        'method': 'Z-score标准化'
                    }
                ]
            },
            'normalized_preprocessing': {
                'normalized_ways': [
                    {
                        'col': 'all',
                        'method': 'L2归一化'
                    }
                ]
            }
        }
        
    elif route_number == 20:
        # 路线20: 实时数据路线
        ColorPrinter.print_info("选择了路线20: 实时数据路线 - 适合实时数据流处理")
        
        params = {
            'nan_preprocessing': {
                'nan_ways': [
                    {
                        'col': 'all',
                        'method': 'fill_nan_mean',
                        'drop_threshold': 0.5,
                        'knn_n_neighbors': 5
                    }
                ]
            },
            'outlier_preprocessing': {
                'outlier_choice': 'thres_sigma_auto',
                'row_drop_thres': 3.0,
                'auto_drop_row': True,
                'specify_auto_drop_row_extr': 'auto',
                'outlier_action': 'drop',
                'contamination': 0.1,
                'outlier_replace_method': None
            },
            'time_preprocessing': {
                'time_col': 'auto',
                'time_type': 'basic'  # 基础时间特征，速度更快
            },
            'standard_preprocessing': {
                'standard_ways': [
                    {
                        'col': 'all',
                        'method': 'Z-score标准化'
                    }
                ]
            }
        }
        
    else:
        ColorPrinter.print_error(f"错误: 无效的路线编号 {route_number}")
        ColorPrinter.print_error("请选择以下路线之一:")
        ColorPrinter.print_error("1: 基础路线 - 适合大多数数据集")
        ColorPrinter.print_error("2: 股票数据路线 - 专为股票数据优化")
        ColorPrinter.print_error("3: 文本数据路线 - 包含文本处理")
        ColorPrinter.print_error("4: 时间序列路线 - 强化时间特征提取")
        ColorPrinter.print_error("5: 完整路线 - 包含所有预处理步骤")
        ColorPrinter.print_error("6: 轻量级路线 - 快速处理小数据集")
        ColorPrinter.print_error("7: 异常检测路线 - 专注于异常值处理")
        ColorPrinter.print_error("8: 特征增强路线 - 强化特征工程")
        ColorPrinter.print_error("9: 分类数据路线 - 适合分类任务")
        ColorPrinter.print_error("10: 回归数据路线 - 适合回归任务")
        ColorPrinter.print_error("11: 中文文本路线 - 专为中文文本数据优化")
        ColorPrinter.print_error("12: 不平衡数据路线 - 处理类别不平衡的数据集")
        ColorPrinter.print_error("13: 高维数据路线 - 处理特征维度较高的数据集")
        ColorPrinter.print_error("14: 金融数据路线 - 专为金融数据优化")
        ColorPrinter.print_error("15: 医疗数据路线 - 适合医疗数据集的处理")
        ColorPrinter.print_error("16: 电商数据路线 - 专为电商数据优化")
        ColorPrinter.print_error("17: 社交媒体数据路线 - 处理社交媒体数据")
        ColorPrinter.print_error("18: 传感器数据路线 - 处理传感器数据")
        ColorPrinter.print_error("19: 多模态数据路线 - 包含多种类型数据的数据集")
        ColorPrinter.print_error("20: 实时数据路线 - 适合实时数据流处理")
        return None
    
    # 配置后展示用户选择的路线
    ColorPrinter.print_success("\n参数配置完成！")
    ColorPrinter.print_info("配置的预处理工具:")
    for tool_name in params.keys():
        ColorPrinter.print_info(f"- {tool_name}")
    
    # 如果提供了数据，使用Interactive让用户选择每个工具要处理的列
    if data is not None:
        # 获取所有列名
        all_cols = list(data.columns)
        # 获取数值列
        numeric_cols = [col for col in all_cols if data[col].dtype in ['int64', 'float64']]
        # 获取字符串列
        string_cols = [col for col in all_cols if data[col].dtype == 'object']
        
        # 处理nan_preprocessing - 让用户选择要填充缺失值的列
        if 'nan_preprocessing' in params:
            if 'nan_ways' in params['nan_preprocessing']:
                for way in params['nan_preprocessing']['nan_ways']:
                    if way.get('col') == 'all':
                        if auto_test:
                            # 自动测试模式，选择所有数值列
                            if numeric_cols:
                                way['col'] = numeric_cols
                                ColorPrinter.print_info(f"自动测试模式: 选择所有数值列进行缺失值处理: {numeric_cols}")
                        else:
                            ColorPrinter.print_info("\n=== 缺失值处理 ===")
                            ColorPrinter.print_info("当前方法: " + way.get('method', 'fill_nan_mean'))
                            if numeric_cols:
                                inter = interactive(
                                    options=numeric_cols,
                                    title="选择要处理缺失值的列（按m多选）",
                                    description="选择要填充缺失值的列，按m选择多个，按回车确认",
                                    min_select=1,
                                    max_select=len(numeric_cols)
                                )
                                selected_cols = inter.run()
                                if selected_cols:
                                    way['col'] = selected_cols
        
        # 处理outlier_preprocessing - 让用户选择要检测异常值的列
        if 'outlier_preprocessing' in params:
            if numeric_cols:
                if auto_test:
                    # 自动测试模式，选择所有数值列
                    params['outlier_preprocessing']['outlier_cols'] = numeric_cols
                    ColorPrinter.print_info(f"自动测试模式: 选择所有数值列进行异常值检测: {numeric_cols}")
                else:
                    ColorPrinter.print_info("\n=== 异常值处理 ===")
                    ColorPrinter.print_info("当前方法: " + params['outlier_preprocessing'].get('outlier_choice', 'thres_sigma_auto'))
                    inter = interactive(
                        options=numeric_cols,
                        title="选择要检测异常值的列（按m多选）",
                        description="选择要检测异常值的列，按m选择多个，按回车确认",
                        min_select=1,
                        max_select=len(numeric_cols)
                    )
                    selected_cols = inter.run()
                    if selected_cols:
                        params['outlier_preprocessing']['outlier_cols'] = selected_cols
        
        # 处理str_preprocessing - 让用户选择要进行字符串编码的列
        if 'str_preprocessing' in params:
            if 'str_ways' in params['str_preprocessing']:
                for way in params['str_preprocessing']['str_ways']:
                    if way.get('str_cols') == 'all' and string_cols:
                        if auto_test:
                            # 自动测试模式，选择所有字符串列
                            way['str_cols'] = string_cols
                            ColorPrinter.print_info(f"自动测试模式: 选择所有字符串列进行字符串处理: {string_cols}")
                        else:
                            ColorPrinter.print_info("\n=== 字符串处理 ===")
                            ColorPrinter.print_info("当前方法: " + str(way.get('method', ['tfidf'])))
                            inter = interactive(
                                options=string_cols,
                                title="选择要进行字符串处理的列（按m多选）",
                                description="选择要编码的字符串列，按m选择多个，按回车确认",
                                min_select=1,
                                max_select=len(string_cols)
                            )
                            selected_cols = inter.run()
                            if selected_cols:
                                way['str_cols'] = selected_cols
        
        # 处理standard_preprocessing - 让用户选择要标准化的列
        if 'standard_preprocessing' in params:
            if 'standard_ways' in params['standard_preprocessing']:
                for way in params['standard_preprocessing']['standard_ways']:
                    if way.get('col') == 'all':
                        if numeric_cols:
                            if auto_test:
                                # 自动测试模式，选择所有数值列
                                way['col'] = numeric_cols
                                ColorPrinter.print_info(f"自动测试模式: 选择所有数值列进行标准化处理: {numeric_cols}")
                            else:
                                ColorPrinter.print_info("\n=== 标准化处理 ===")
                                ColorPrinter.print_info("当前方法: " + way.get('method', 'Z-score标准化'))
                                inter = interactive(
                                    options=numeric_cols,
                                    title="选择要标准化的列（按m多选）",
                                    description="选择要标准化的列，按m选择多个，按回车确认",
                                    min_select=1,
                                    max_select=len(numeric_cols)
                                )
                                selected_cols = inter.run()
                                if selected_cols:
                                    way['col'] = selected_cols
        
        # 处理normalized_preprocessing - 让用户选择要归一化的列
        if 'normalized_preprocessing' in params:
            if 'normalized_ways' in params['normalized_preprocessing']:
                for way in params['normalized_preprocessing']['normalized_ways']:
                    if way.get('col') == 'all':
                        if numeric_cols:
                            if auto_test:
                                # 自动测试模式，选择所有数值列
                                way['col'] = numeric_cols
                                ColorPrinter.print_info(f"自动测试模式: 选择所有数值列进行归一化处理: {numeric_cols}")
                            else:
                                ColorPrinter.print_info("\n=== 归一化处理 ===")
                                ColorPrinter.print_info("当前方法: " + way.get('method', 'L2归一化'))
                                inter = interactive(
                                    options=numeric_cols,
                                    title="选择要归一化的列（按m多选）",
                                    description="选择要归一化的列，按m选择多个，按回车确认",
                                    min_select=1,
                                    max_select=len(numeric_cols)
                                )
                                selected_cols = inter.run()
                                if selected_cols:
                                    way['col'] = selected_cols
        
        # 处理time_preprocessing - 让用户选择时间列
        if 'time_preprocessing' in params:
            if params['time_preprocessing'].get('time_col') == 'auto':
                # 尝试自动检测时间列
                time_cols = []
                for col in all_cols:
                    try:
                        pd.to_datetime(data[col], errors='coerce')
                        # 检查该列是否有有效的时间数据
                        if pd.to_datetime(data[col], errors='coerce').notna().any():
                            time_cols.append(col)
                    except:
                        pass
                
                if time_cols:
                    if auto_test:
                        # 自动测试模式，选择第一个时间列
                        params['time_preprocessing']['time_col'] = time_cols[0]
                        ColorPrinter.print_info(f"自动测试模式: 选择第一个时间列: {time_cols[0]}")
                    else:
                        ColorPrinter.print_info("\n=== 时间处理 ===")
                        inter = interactive(
                            options=time_cols,
                            title="选择时间列",
                            description="选择包含时间信息的列",
                            min_select=1,
                            max_select=1
                        )
                        selected_cols = inter.run()
                        if selected_cols:
                            params['time_preprocessing']['time_col'] = selected_cols[0] if selected_cols else None
                else:
                    # 没有检测到时间列
                    ColorPrinter.print_warning("未检测到时间列")
        
        # 处理relative_preprocessing - 让用户选择特征工程相关的列
        if 'relative_preprocessing' in params:
            if params['relative_preprocessing'].get('linear_cols') == 'all':
                if numeric_cols:
                    if auto_test:
                        # 自动测试模式，选择所有数值列
                        params['relative_preprocessing']['linear_cols'] = numeric_cols
                        params['relative_preprocessing']['feature_cols'] = numeric_cols
                        params['relative_preprocessing']['pca_cols'] = numeric_cols
                        ColorPrinter.print_info(f"自动测试模式: 选择所有数值列进行特征工程: {numeric_cols}")
                    else:
                        ColorPrinter.print_info("\n=== 特征工程（线性组合） ===")
                        inter = interactive(
                            options=numeric_cols,
                            title="选择用于线性组合的列（按m多选）",
                            description="选择要计算线性组合特征的列，按m选择多个，按回车确认",
                            min_select=1,
                            max_select=len(numeric_cols)
                        )
                        selected_cols = inter.run()
                        if selected_cols:
                            params['relative_preprocessing']['linear_cols'] = selected_cols
    
    # 配置后展示用户选择的路线
    ColorPrinter.print_info("\n配置后 - 您选择的路线详细信息:")
    
    if route_number in ROUTES:
        route_info = ROUTES[route_number]
        ColorPrinter.print_info(f"\n{route_number}. {route_info['name']}")
        ColorPrinter.print_info(f"   📝 描述: {route_info['description']}")
        ColorPrinter.print_info(f"   🔧 工具: {', '.join(route_info['tools'])}")
        ColorPrinter.print_info(f"   🎯 适用: {route_info['suitable_for']}")
    
    return params


def show_available_routes():
    """
    显示所有可用的预定义路线
    
    Returns:
        list: 路线列表，包含所有可用的预定义路线编号和名称
    """
    routes = [
        "1: 基础路线 - 适合大多数数据集",
        "2: 股票数据路线 - 专为股票数据优化",
        "3: 文本数据路线 - 包含文本处理",
        "4: 时间序列路线 - 强化时间特征提取",
        "5: 完整路线 - 包含所有预处理步骤",
        "6: 轻量级路线 - 快速处理小数据集",
        "7: 异常检测路线 - 专注于异常值处理",
        "8: 特征增强路线 - 强化特征工程",
        "9: 分类数据路线 - 适合分类任务",
        "10: 回归数据路线 - 适合回归任务",
        "11: 中文文本路线 - 专为中文文本数据优化",
        "12: 不平衡数据路线 - 处理类别不平衡的数据集",
        "13: 高维数据路线 - 处理特征维度较高的数据集",
        "14: 金融数据路线 - 专为金融数据优化",
        "15: 医疗数据路线 - 适合医疗数据集的处理",
        "16: 电商数据路线 - 专为电商数据优化",
        "17: 社交媒体数据路线 - 处理社交媒体数据",
        "18: 传感器数据路线 - 处理传感器数据",
        "19: 多模态数据路线 - 处理包含多种类型数据的数据集",
        "20: 实时数据路线 - 适合实时数据流处理"
    ]
    
    ColorPrinter.print_info("\n可用的预定义路线:")
    for route in routes:
        ColorPrinter.print_info(route)
    
    return routes


def show_routes_visual():
    """
    可视化显示所有可用的预定义路线及其详细简介
    """
    ColorPrinter.print_info("\n" + "=" * 80)
    ColorPrinter.print_info("📋 预定义特征工程路线详细说明")
    ColorPrinter.print_info("=" * 80)
    
    for route_number, route_info in ROUTES.items():
        ColorPrinter.print_info(f"\n{route_number}. {route_info['name']}")
        ColorPrinter.print_info(f"   📝 描述: {route_info['description']}")
        ColorPrinter.print_info(f"   🔧 工具: {', '.join(route_info['tools'])}")
        ColorPrinter.print_info(f"   🎯 适用: {route_info['suitable_for']}")
    
    ColorPrinter.print_info("\n" + "=" * 80)
