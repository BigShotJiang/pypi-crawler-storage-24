# 集成参数基因清单 (Integration Genes)

本文档汇总了 `MFM/MTE` 目录下所有可编码为遗传算法基因的离散或连续参数。包含流水线配置、数据拆分配置、集成策略配置以及各基础业务模型的超参数配置。

## 1. 流水线核心配置 (Pipeline Config)
**路径:** `MFM/MTE/TEv2_0/tools/MTE_config.py` (`PIPELINE_DEFAULT_PARAMS`)

此部分决定了整个模型训练流水线的基本行为。

### 主要参数结构
```python
PIPELINE_DEFAULT_PARAMS = {
    'change_ffe_console': 'no',
    'split_data_console': 'train_data',
    'split_type_console': 'normal_split',
    'split_data_num_console': 0,
    'split_type1_console': 'normal_split',
    'label_name_ffe': None,
    'clean_ffe': 'nor_clean',
    'str_clean_ways': 'tokenizer',
    'time_col': None,
    'me_choice_me': '分类模型',
    'data_type_me': 'train_data',
    'data_name_me': None,
    'batch_size': None,
    'use_gpu': False,
    'model_choice_judge': '分类模型'
}
```

### 参数字典对照表

| 参数键名 | 类型/候选集合 | 默认占位值 | 占位策略与备注 |
| :--- | :--- | :--- | :--- |
| `change_ffe_console` | `['yes', 'no']` | `'no'` | 保留键值；控制是否改变FFE控制台配置 |
| `split_data_console` | 字符串 | `'train_data'` | 保留键值 |
| `split_type_console` | `['normal_split', 'advanced_split', 'Choose one by one']` | `'normal_split'` | 保留键值；控制使用哪种拆分策略 |
| `split_data_num_console` | 整数 | `0` | 保留键值 |
| `split_type1_console` | 字符串 | `'normal_split'` | 保留键值 |
| `label_name_ffe` | 字符串 / None | `None` | 保留键值；缺失时需要手动或通过上游传入 |
| `clean_ffe` | 字符串 | `'nor_clean'` | 保留键值 |
| `str_clean_ways` | 字符串 | `'tokenizer'` | 保留键值 |
| `time_col` | 字符串 / None | `None` | 保留键值 |
| `me_choice_me` | `['分类模型', '回归模型']` | `'分类模型'` | 保留键值；强依赖项，决定后续加载的子模型类型 |
| `data_type_me` | 字符串 | `'train_data'` | 保留键值 |
| `data_name_me` | 字符串 / None | `None` | 保留键值 |
| `batch_size` | 整数 / None | `None` | 保留键值；若为None则不分批 |
| `use_gpu` | `[True, False]` | `False` | 保留键值；依赖硬件配置 |
| `model_choice_judge` | 字符串 | `'分类模型'` | 保留键值 |

## 2. 数据拆分配置 (Data Split Config)
**路径:** `MFM/MTE/TEv2_0/tools/MTE_config.py` (`DATA_SPLIT_DEFAULT_PARAMS`)

控制数据集划分策略，这些参数相互之间存在依赖关系。

### 主要参数结构
```python
DATA_SPLIT_DEFAULT_PARAMS = {
    'split_type': 'normal_split',
    'method': 'train_test_split',
    'test_size': 0.25,
    'random_state': 42,
    'n_splits': 5,
    'shuffle': True,
    'group_column': None
}
```

### 参数字典对照表

| 参数键名 | 类型/候选集合 | 默认占位值 | 占位策略与备注 |
| :--- | :--- | :--- | :--- |
| `split_type` | `['normal_split', 'advanced_split']` | `'normal_split'` | 保留键值；决定可用的 method 集合 |
| `method` | `['train_test_split', 'stratified_fold', 'Time_series_split', 'Group_K_fold']` | `'train_test_split'` | 保留键值；必须与 `split_type` 匹配 |
| `test_size` | 浮点数 (0~1) | `0.25` | 仅在 `train_test_split` 激活时有效，否则作占位保留 |
| `random_state` | 整数 | `42` | 保留键值 |
| `n_splits` | 整数 | `5` | 仅在高级交叉验证（如 `stratified_fold`）时有效 |
| `shuffle` | `[True, False]` | `True` | 仅在高级拆分时有效 |
| `group_column` | 字符串 / None | `None` | 仅在 `Group_K_fold` 时有效 |

## 3. 集成策略配置 (Ensemble Config)
**路径:** `MFM/MTE/TEv2_0/tools/MTE_config.py` (`ENSEMBLE_DEFAULT_PARAMS`)

控制最终集成的决策机制。

### 主要参数结构
```python
ENSEMBLE_DEFAULT_PARAMS = {
    'way_ensemble_console': 'ADG',
    'save_model_option': '否',
    'estimator_adg': 'Classifier',
    'selection_model_adg': ['RandomForest'],
    'selection_model_reg_adg': ['RandomForestRegressor'],
    'selection_model_clu_adg': ['K-mean'],
    'models_num_adg': 1,
    'default_path_adg': None,
    'selection_fe_adg': False,
    'label_name_adg': None,
    'interactive_estimator1_adg': 'DecisionTreeRegressor',
    'interactive_selection2_adg': 'K-mean'
}
```

### 参数字典对照表

| 参数键名 | 类型/候选集合 | 默认占位值 | 占位策略与备注 |
| :--- | :--- | :--- | :--- |
| `way_ensemble_console` | `['ADG', 'WDG', 'EDG']` | `'ADG'` | 保留键值；决定使用哪种集成核心策略 |
| `save_model_option` | `['是', '否']` | `'否'` | 保留键值 |
| `estimator_adg` | `['Classifier', 'Regressor', 'Clustering']` | `'Classifier'` | 保留键值 |
| `selection_model_adg` | 列表 (分类模型名称) | `['RandomForest']` | 保留键值 |
| `selection_model_reg_adg`| 列表 (回归模型名称) | `['RandomForestRegressor']` | 保留键值 |
| `selection_model_clu_adg`| 列表 (聚类模型名称) | `['K-mean']` | 保留键值 |
| `models_num_adg` | 整数 | `1` | 保留键值 |
| `selection_fe_adg` | `[True, False]` | `False` | 保留键值 |
| `interactive_estimator1_adg`| 字符串 | `'DecisionTreeRegressor'` | 保留键值 |
| `interactive_selection2_adg`| 字符串 | `'K-mean'` | 保留键值 |

## 4. 基础模型超参数 (ME Models)
**路径:** `MFM/MTE/ME/tools/interactive_model_params.py`

各个模型在未被选中（未包含在集成模型列表中）时，可以完全剔除对应的配置字典以缩减搜索空间；当模型被选中时，其对应的字典及占位值必须保留。

### 4.1 分类模型 (Classification)
| 模型名称 | 参数键名 | 类型/候选集合 | 默认占位值 | 备注 |
| :--- | :--- | :--- | :--- | :--- |
| **RandomForest** | `n_estimators` | 整数 | `100` | 森林中树的数量 |
| | `max_depth` | 整数 / None | `10` | 树的最大深度 |
| | `min_samples_split` | 整数 | `2` | 拆分内部节点所需的最小样本数 |
| | `min_samples_leaf` | 整数 | `1` | 叶节点所需的最小样本数 |
| | `max_features` | `['sqrt', 'log2', None]` | `'sqrt'` | 寻找最佳拆分时考虑的特征数 |
| | `bootstrap` | `[True, False]` | `True` | 是否使用自助法采样 |
| | `random_state` | 整数 | `42` | 随机种子 |
| **Catboost** | `iterations` | 整数 | `5000` | 最大迭代次数 |
| | `learning_rate` | 浮点数 | `0.03` | 学习率 |
| | `depth` | 整数 | `6` | 树深 |
| | `loss_function` | `['MultiClass', 'Logloss', 'CrossEntropy', 'PairwiseLogloss']` | 取决于具体数据 | 损失函数类型 |
| | `one_hot_max_size`| 整数 | `5` | one-hot 编码的最大类别数 |
| | `l2_leaf_reg` | 浮点数 | `3.0` | L2正则化系数 |
| | `colsample_bylevel` | 浮点数 | `1.0` | 每层的列采样比例 |
| | `use_gpu` | `[True, False]` | `False` | 依赖硬件支持 |
| **Lightgbm** | `n_estimators` | 整数 | `5000` | 树的数量 |
| | `learning_rate` | 浮点数 | `0.03` | 学习率 |
| | `max_depth` | 整数 | `6` | 树深 |
| | `num_leaves` | 整数 | `31` | 最大叶子节点数 |
| | `min_child_samples`| 整数 | `20` | 叶子节点最小样本数 |
| | `objective` | `['binary', 'multiclass', 'regression']` | 取决于数据 | 目标函数 |
| | `reg_alpha` | 浮点数 | `0.0` | L1正则化 |
| | `reg_lambda` | 浮点数 | `3.0` | L2正则化 |
| | `subsample` | 浮点数 (0~1) | `0.8` | 行采样比例 |
| | `colsample_bytree`| 浮点数 (0~1) | `1.0` | 列采样比例 |
| **Xgboost** | `n_estimators` | 整数 | `5000` | 树的数量 |
| | `learning_rate` | 浮点数 | `0.03` | 学习率 |
| | `max_depth` | 整数 | `6` | 树深 |
| | `min_child_weight` | 整数 | `1` | 最小叶子节点样本权重和 |
| | `gamma` | 浮点数 | `0.0` | 节点分裂最小损失下降值 |
| | `subsample` | 浮点数 (0~1) | `0.8` | 行采样比例 |
| | `colsample_bytree`| 浮点数 (0~1) | `1.0` | 列采样比例 |
| | `reg_alpha` | 浮点数 | `0.0` | L1正则化 |
| | `reg_lambda` | 浮点数 | `1.0` | L2正则化 |
| **AdaBoost** | `n_estimators` | 整数 | `100` | 弱学习器数量 |
| | `learning_rate` | 浮点数 | `1.0` | 学习率权重缩减 |

### 4.2 回归模型 (Regression)
| 模型名称 | 参数键名 | 类型/候选集合 | 默认占位值 | 备注 |
| :--- | :--- | :--- | :--- | :--- |
| **RandomForestRegressor** | (参数与RandomForest分类一致) | | |
| **DecisionTreeRegressor** | `max_depth` | 整数 / None | `None` | 树深 |
| | `min_samples_split` | 整数 | `2` | - |
| | `min_samples_leaf` | 整数 | `1` | - |
| | `max_features` | `['sqrt', 'log2', None]` | `None` | - |
| **LinearRegression**| `fit_intercept` | `[True, False]` | `True` | 是否计算截距 |
| | `n_jobs` | `[-1, 1, 2, 4]` | `-1` | 并行计算数 |
| **ElasticNet** | `alpha` | 浮点数 | `1.0` | 惩罚项乘数 |
| | `l1_ratio` | 浮点数 (0~1) | `0.5` | L1 与 L2 惩罚项比率 |
| | `max_iter` | 整数 | `1000` | 最大迭代次数 |
| **XGBRegressor** | (参数与Xgboost分类一致) | | |
| **RANSACRegressor** | `min_samples` | 浮点数 (0~1) | `0.6` | 最小采样比例 |
| | `max_trials` | 整数 | `150` | 最大迭代次数 |

### 4.3 聚类模型 (Clustering)
| 模型名称 | 参数键名 | 类型/候选集合 | 默认占位值 | 备注 |
| :--- | :--- | :--- | :--- | :--- |
| **Kmean** | `n_clusters` | 整数 | `3` | 簇数量 |
| | `init` | `['k-means++', 'random']` | `'k-means++'` | 初始化方法 |
| | `n_init` | `['auto', 10, 20, 30]` | `'auto'` | 随机初始化运行次数 |
| | `max_iter` | 整数 | `300` | 最大单次运行迭代数 |
| **DBSCAN** | `eps` | 浮点数 | `0.5` | 邻域最大距离 |
| | `min_samples` | 整数 | `5` | 核心点邻域最小样本数 |
| | `metric` | `['euclidean', 'manhattan', 'cosine', 'l1', 'l2']` | `'euclidean'` | 距离度量方式 |
| **OPTICS** | `eps` | 浮点数 | `0.5` | 邻域最大距离 |
| | `min_samples` | 整数 | `5` | 核心点邻域最小样本数 |
| | `xi` | 浮点数 | `0.05` | 决定簇边界的相对下降陡度 |
| **AgglomerativeClustering** | `n_clusters` | 整数 | `3` | 簇数量 |
| | `linkage` | `['ward', 'complete', 'average', 'single']` | `'ward'` | 链接准则 |
| | `metric` | `['euclidean', 'manhattan', 'cosine', 'l1', 'l2']` | `'euclidean'` | 距离度量方式 |

