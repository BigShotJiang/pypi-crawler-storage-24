"""Version information for llama-cpp-py-sync."""

__version__ = "0.8233"
__llama_cpp_commit__ = "c5a778891"
__llama_cpp_tag__ = "b8233"
