"""Device client wrapper for MCP Junos functionality."""

from typing import Dict, Optional


class MCPDeviceClient:
    """Wrapper for MCP Junos device functions.

    This class provides a simplified interface to the MCP Junos functions
    for device communication and XML retrieval.
    """

    def __init__(self, mcp_functions: Dict):
        """Initialize with MCP function references.

        Args:
            mcp_functions: Dictionary of MCP function references
        """
        self.execute_command = mcp_functions.get("mcp__junos__execute_junos_command")
        self.get_config = mcp_functions.get("mcp__junos__get_junos_config")
        self.get_router_list = mcp_functions.get("mcp__junos__get_router_list")

    def execute_junos_command(
        self, router_name: str, command: str, timeout: int = 360
    ) -> str:
        """Execute a command on the Junos device.

        Args:
            router_name: Name of the router
            command: Command to execute
            timeout: Command timeout in seconds

        Returns:
            Command output as string
        """
        if not self.execute_command:
            raise RuntimeError("MCP execute command function not available")

        return self.execute_command(
            router_name=router_name, command=command, timeout=timeout
        )

    def get_available_routers(self) -> list:
        """Get list of available routers.

        Returns:
            List of router names
        """
        if not self.get_router_list:
            raise RuntimeError("MCP get router list function not available")

        result = self.get_router_list()
        # Handle different return formats
        if isinstance(result, list):
            return result
        elif isinstance(result, str):
            return [result]  # Single router returned as string
        else:
            return []


def create_device_client():
    """Create a device client with MCP functions.

    This is a placeholder that would be replaced with actual MCP function
    references in the real implementation.

    Returns:
        MCPDeviceClient instance
    """
    # This would be populated with actual MCP function references
    # in the real implementation when integrated with the CLI
    mcp_functions = {
        "mcp__junos__execute_junos_command": None,
        "mcp__junos__get_junos_config": None,
        "mcp__junos__get_router_list": None,
    }

    return MCPDeviceClient(mcp_functions)
