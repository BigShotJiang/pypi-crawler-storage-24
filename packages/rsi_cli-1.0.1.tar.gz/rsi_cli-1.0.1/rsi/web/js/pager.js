/**
 * Pager - JavaScript implementation of less-style paging
 * Provides scrollable paged output for long command results
 */

class Pager {
    constructor(terminal) {
        this.terminal = terminal;
        this.isActive = false;
        this.content = '';
        this.lines = [];
        this.currentLine = 0;
        this.pageSize = 20; // Default page size
        this.isEnabled = true;
        this.pagerContainer = null;
        this.statusLine = null;
        
        this.setupPager();
        this.bindEvents();
    }

    setupPager() {
        // Create pager container (initially hidden)
        this.pagerContainer = document.createElement('div');
        this.pagerContainer.className = 'pager-container';
        this.pagerContainer.style.cssText = `
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: #1a1a1a;
            color: #f0f0f0;
            font-family: monospace;
            font-size: 14px;
            z-index: 1000;
            display: none;
            flex-direction: column;
        `;

        // Create content area
        this.contentArea = document.createElement('div');
        this.contentArea.className = 'pager-content';
        this.contentArea.style.cssText = `
            flex: 1;
            padding: 10px;
            white-space: pre-wrap;
            word-wrap: break-word;
            overflow: hidden;
        `;

        // Create status line
        this.statusLine = document.createElement('div');
        this.statusLine.className = 'pager-status';
        this.statusLine.style.cssText = `
            background: #333;
            color: #fff;
            padding: 5px 10px;
            font-weight: bold;
            border-top: 1px solid #555;
            flex-shrink: 0;
        `;

        this.pagerContainer.appendChild(this.contentArea);
        this.pagerContainer.appendChild(this.statusLine);
        
        // Add to terminal container
        this.terminal.container.style.position = 'relative';
        this.terminal.container.appendChild(this.pagerContainer);
    }

    bindEvents() {
        // Bind keyboard events to document when pager is active
        this.keyHandler = (e) => this.handleKeyPress(e);
    }

    calculatePageSize() {
        // Calculate how many lines fit in the content area
        const containerHeight = this.contentArea.offsetHeight;
        
        // Create a temporary element to measure actual line height
        const tempDiv = document.createElement('div');
        tempDiv.style.cssText = `
            position: absolute;
            visibility: hidden;
            font-family: monospace;
            font-size: 14px;
            line-height: 1.4;
            white-space: pre;
        `;
        tempDiv.textContent = 'Test line';
        document.body.appendChild(tempDiv);
        
        const actualLineHeight = tempDiv.offsetHeight;
        document.body.removeChild(tempDiv);
        
        // Calculate page size with some padding
        this.pageSize = Math.max(3, Math.floor(containerHeight / actualLineHeight) - 2);
    }

    show(content, forceNoPaging = false) {
        if (!this.isEnabled || forceNoPaging) {
            // No paging - show content directly
            this.terminal.addOutput(content, 'output');
            return;
        }

        this.content = content;
        this.lines = content.split('\n');
        this.currentLine = 0;

        // Show pager first to ensure container is visible for measurement
        this.isActive = true;
        this.pagerContainer.style.display = 'flex';
        
        // Wait for next frame to ensure container is rendered, then calculate page size
        requestAnimationFrame(() => {
            this.calculatePageSize();
            
            // Check if paging is still needed after accurate measurement
            if (this.lines.length <= this.pageSize) {
                // Content fits in one page - hide pager and show directly
                this.hide();
                this.terminal.addOutput(content, 'output');
                return;
            }
            
            // Set up pager
            document.addEventListener('keydown', this.keyHandler);
            
            // Prevent terminal input
            this.terminal.inputElement.disabled = true;
            
            this.updateDisplay();
        });
    }

    updateDisplay() {
        const startLine = this.currentLine;
        const endLine = Math.min(startLine + this.pageSize, this.lines.length);
        const visibleLines = this.lines.slice(startLine, endLine);
        
        this.contentArea.textContent = visibleLines.join('\n');
        
        // Update status line
        const percentage = Math.round((endLine / this.lines.length) * 100);
        let status;
        
        if (endLine >= this.lines.length) {
            status = '(END)';
        } else {
            status = `:${percentage}%`;
        }
        
        this.statusLine.textContent = status;
    }

    handleKeyPress(e) {
        if (!this.isActive) return;

        e.preventDefault();
        e.stopPropagation();

        switch (e.key) {
            case ' ':
            case 'f':
                // Page down
                this.pageDown();
                break;
            case 'b':
                // Page up
                this.pageUp();
                break;
            case 'j':
            case 'ArrowDown':
                // Line down
                this.lineDown();
                break;
            case 'k':
            case 'ArrowUp':
                // Line up
                this.lineUp();
                break;
            case 'g':
                // Go to beginning
                this.goToStart();
                break;
            case 'G':
                // Go to end
                this.goToEnd();
                break;
            case 'q':
            case 'Escape':
                // Quit pager
                this.hide();
                break;
            case 'h':
            case '?':
                // Show help
                this.showHelp();
                break;
        }
    }

    pageDown() {
        const maxStartLine = Math.max(0, this.lines.length - this.pageSize);
        const newLine = Math.min(this.currentLine + this.pageSize, maxStartLine);
        
        if (newLine !== this.currentLine) {
            this.currentLine = newLine;
            this.updateDisplay();
        } else {
            // At end - quit pager
            this.hide();
        }
    }

    pageUp() {
        const newLine = Math.max(this.currentLine - this.pageSize, 0);
        this.currentLine = newLine;
        this.updateDisplay();
    }

    lineDown() {
        const maxStartLine = Math.max(0, this.lines.length - this.pageSize);
        if (this.currentLine < maxStartLine) {
            this.currentLine++;
            this.updateDisplay();
        } else {
            // At end - quit pager
            this.hide();
        }
    }

    lineUp() {
        if (this.currentLine > 0) {
            this.currentLine--;
            this.updateDisplay();
        }
    }

    goToStart() {
        this.currentLine = 0;
        this.updateDisplay();
    }

    goToEnd() {
        const maxStartLine = Math.max(0, this.lines.length - this.pageSize);
        this.currentLine = maxStartLine;
        this.updateDisplay();
    }

    showHelp() {
        const helpText = `
Pager Help:

Navigation:
  SPACE, f     - Page forward
  b            - Page backward
  j, ↓         - Line down
  k, ↑         - Line up
  g            - Go to beginning
  G            - Go to end

Commands:
  q, ESC       - Quit pager
  h, ?         - Show this help

Press any key to continue...`;

        const originalContent = this.contentArea.textContent;
        const originalStatus = this.statusLine.textContent;
        
        this.contentArea.textContent = helpText;
        this.statusLine.textContent = 'Help - Press any key to continue';
        
        // Wait for next key press to return to content
        const helpHandler = (e) => {
            e.preventDefault();
            e.stopPropagation();
            document.removeEventListener('keydown', helpHandler);
            this.contentArea.textContent = originalContent;
            this.statusLine.textContent = originalStatus;
        };
        
        document.addEventListener('keydown', helpHandler);
    }

    hide() {
        if (!this.isActive) return;
        
        this.isActive = false;
        this.pagerContainer.style.display = 'none';
        document.removeEventListener('keydown', this.keyHandler);
        
        // Re-enable terminal input and ensure focus
        this.terminal.inputElement.disabled = false;
        
        // Use setTimeout to ensure the input is properly re-enabled before focusing
        setTimeout(() => {
            this.terminal.inputElement.focus();
            console.log('Pager hidden, input refocused');
        }, 10);
        
        // Add a summary line to terminal
        const totalLines = this.lines.length;
        this.terminal.addOutput(`-- ${totalLines} lines --`, 'suggestion');
    }

    setEnabled(enabled) {
        this.isEnabled = enabled;
    }

    isEnabledState() {
        return this.isEnabled;
    }
}

// Export for use in other modules (if using modules)
if (typeof module !== 'undefined' && typeof module.exports !== 'undefined') {
    module.exports = { Pager };
}