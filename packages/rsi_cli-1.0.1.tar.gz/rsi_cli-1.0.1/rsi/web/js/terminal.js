/**
 * RSI Terminal - Terminal interface for RSI CLI simulation
 * Provides interactive command-line interface that mirrors Python CLI functionality
 */

class RSITerminal {
    constructor(containerElement, rsiParser, user, hostname) {
        this.container = containerElement;
        this.rsiParser = rsiParser;
        this.user = user;
        this.hostname = hostname;
        this.promptText = `${user}@${hostname}> `;
        
        // CLI components
        this.commandTree = new CommandTree(Object.keys(rsiParser.getCommands()));
        this.matcher = new CommandMatcher(rsiParser.getCommands());
        this.pipeProcessor = new PipeProcessor();
        this.pager = null; // Will be initialized in setupTerminal
        
        // Terminal state
        this.commandHistory = [];
        this.historyIndex = -1;
        this.currentInput = '';
        this.isActive = false;
        this.pagingEnabled = true;
        this.maxHistorySize = 1000;
        this.historySearchMode = false;
        this.historySearchTerm = '';
        this.historySearchResults = [];
        this.historySearchIndex = -1;
        
        this.setupTerminal();
        this.bindEvents();
    }

    setupTerminal() {
        // Create terminal elements
        this.container.innerHTML = '';
        
        // Create terminal output area
        this.outputArea = document.createElement('div');
        this.outputArea.className = 'terminal-output';
        this.outputArea.style.cssText = `
            flex: 1;
            overflow-y: auto;
            padding: 10px;
            font-family: monospace;
            white-space: pre-wrap;
            word-wrap: break-word;
            min-height: 0;
        `;
        
        // Create input area
        this.inputArea = document.createElement('div');
        this.inputArea.className = 'terminal-input';
        this.inputArea.style.cssText = `
            display: flex;
            padding: 5px 10px;
            border-top: 1px solid #404040;
            background: #1a1a1a;
            flex-shrink: 0;
        `;
        
        // Create prompt
        this.promptElement = document.createElement('span');
        this.promptElement.className = 'terminal-prompt';
        this.promptElement.textContent = this.promptText;
        this.promptElement.style.cssText = `
            color: #00ff88;
            font-weight: bold;
            white-space: nowrap;
        `;
        
        // Create input field
        this.inputElement = document.createElement('input');
        this.inputElement.type = 'text';
        this.inputElement.className = 'terminal-input-field';
        this.inputElement.style.cssText = `
            flex: 1;
            background: transparent;
            border: none;
            outline: none;
            color: #f0f0f0;
            font-family: monospace;
            font-size: 14px;
            margin-left: 5px;
        `;
        
        // Assemble terminal
        this.inputArea.appendChild(this.promptElement);
        this.inputArea.appendChild(this.inputElement);
        
        this.container.style.cssText = `
            display: flex;
            flex-direction: column;
            height: 100%;
            background: #1a1a1a;
            color: #f0f0f0;
        `;
        
        this.container.appendChild(this.outputArea);
        this.container.appendChild(this.inputArea);
        
        // Initialize pager
        this.pager = new Pager(this);
        
        // Load command history from localStorage
        this.loadHistory();
    }

    bindEvents() {
        this.inputElement.addEventListener('keydown', (e) => this.handleKeyDown(e));
        this.inputElement.addEventListener('input', (e) => this.handleInput(e));
        
        // Focus input when terminal is clicked
        this.container.addEventListener('click', () => {
            if (this.isActive) {
                this.inputElement.focus();
                console.log('Terminal clicked, input focused');
            }
        });

        // Also focus on any interaction with the terminal area
        this.outputArea.addEventListener('click', () => {
            if (this.isActive) {
                this.inputElement.focus();
            }
        });
    }

    handleKeyDown(e) {
        console.log('KeyDown event:', e.key, 'Focus:', document.activeElement === this.inputElement, 'SearchMode:', this.historySearchMode);
        
        // Handle history search mode
        if (this.historySearchMode) {
            this.handleHistorySearchKey(e);
            return;
        }

        switch (e.key) {
            case 'Enter':
                e.preventDefault();
                this.executeCommand();
                break;
            case 'Tab':
                e.preventDefault();
                this.handleTabCompletion();
                break;
            case 'ArrowUp':
                console.log('ArrowUp pressed - going back in history');
                e.preventDefault();
                this.navigateHistory(1); // Up = go back (older commands)
                break;
            case 'ArrowDown':
                console.log('ArrowDown pressed - going forward in history');
                e.preventDefault();
                this.navigateHistory(-1); // Down = go forward (newer commands)
                break;
            case 'p':
                if (e.ctrlKey) {
                    console.log('Ctrl+P pressed - going back in history');
                    e.preventDefault();
                    this.navigateHistory(1); // Previous = go back (older commands)
                }
                break;
            case 'n':
                if (e.ctrlKey) {
                    console.log('Ctrl+N pressed - going forward in history');
                    e.preventDefault();
                    this.navigateHistory(-1); // Next = go forward (newer commands)
                }
                break;
            case 'r':
                if (e.ctrlKey) {
                    e.preventDefault();
                    this.startHistorySearch();
                }
                break;
            case 'c':
                if (e.ctrlKey) {
                    e.preventDefault();
                    this.cancelCurrentOperation();
                }
                break;
            case 'F11':
                e.preventDefault();
                if (window.rsiApp) {
                    window.rsiApp.toggleFullscreen();
                }
                break;
            case 'Escape':
                // Only toggle fullscreen if we're in fullscreen mode
                if (document.querySelector('.terminal-container.fullscreen')) {
                    e.preventDefault();
                    if (window.rsiApp) {
                        window.rsiApp.toggleFullscreen();
                    }
                }
                break;
            case '?':
                // Don't prevent default - let the character be typed
                // Help will be handled on input event
                break;
        }
    }

    handleInput(e) {
        const input = this.inputElement.value;
        
        // Handle help request (ending with ?)
        if (input.endsWith('?')) {
            // Remove the ? and show help
            const partialCommand = input.slice(0, -1).trim();
            this.showHelp(partialCommand);
            this.inputElement.value = partialCommand;
        }
    }

    executeCommand() {
        const input = this.inputElement.value.trim();
        if (!input) return;

        // Add to history
        this.addToHistory(input);
        this.historyIndex = -1;

        // Display command
        this.addOutput(`${this.promptText}${input}`, 'command');

        // Handle special commands
        if (input.toLowerCase() === 'clear') {
            this.clear();
            this.clearInput();
            return;
        }

        if (['quit', 'exit'].includes(input.toLowerCase())) {
            this.addOutput('Goodbye!', 'info');
            this.clearInput();
            return;
        }

        // Handle history commands
        if (input.toLowerCase() === 'history') {
            this.showHistory();
            this.clearInput();
            return;
        }

        if (input.toLowerCase() === 'history clear') {
            this.clearHistory();
            this.clearInput();
            return;
        }

        // Handle pager control commands
        if (input.toLowerCase() === 'set pager on' || input.toLowerCase() === 'pager on') {
            this.pagingEnabled = true;
            this.pager.setEnabled(true);
            this.addOutput('Pager enabled', 'info');
            this.clearInput();
            return;
        }
        
        if (input.toLowerCase() === 'set pager off' || input.toLowerCase() === 'pager off') {
            this.pagingEnabled = false;
            this.pager.setEnabled(false);
            this.addOutput('Pager disabled', 'info');
            this.clearInput();
            return;
        }

        // Execute command
        this.processCommand(input);
        this.clearInput();
        
        // Ensure input remains focused after command execution
        setTimeout(() => {
            this.inputElement.focus();
        }, 10);
    }

    processCommand(command) {
        try {
            // Check for pipe commands
            if (this.pipeProcessor.hasPipes(command)) {
                this.executePipedCommand(command);
            } else {
                this.executeSimpleCommand(command);
            }
        } catch (error) {
            if (error instanceof PipeError) {
                this.addOutput(`% Pipe error: ${error.message}`, 'error');
            } else {
                this.addOutput(`% Error: ${error.message}`, 'error');
            }
        }
    }

    executeSimpleCommand(command) {
        const output = this.matcher.getCommandOutput(command);

        if (output !== null) {
            // Found exact or close match
            const bestMatch = this.matcher.findBestMatch(command);
            if (bestMatch !== command) {
                this.addOutput(`% Executing: ${bestMatch}`, 'suggestion');
            }

            if (output.trim()) {
                this.displayOutput(output);
            } else {
                this.addOutput('% Command completed successfully', 'suggestion');
            }
        } else {
            // Command not found
            this.addOutput(`% Unknown command: ${command}`, 'error');

            // Suggest similar commands
            const suggestions = this.matcher.suggestCommands(command);
            if (suggestions.length > 0) {
                this.addOutput('Did you mean:', 'suggestion');
                suggestions.slice(0, 3).forEach(suggestion => {
                    this.addOutput(`  ${suggestion}`, 'suggestion');
                });
            }
        }
    }

    executePipedCommand(command) {
        // Parse the command and pipes
        const { baseCommand, pipeChain } = this.pipeProcessor.parseCommand(command);

        // Execute the base command
        const baseOutput = this.matcher.getCommandOutput(baseCommand);

        if (baseOutput === null) {
            this.addOutput(`% Unknown command: ${baseCommand}`, 'error');

            // Suggest similar commands
            const suggestions = this.matcher.suggestCommands(baseCommand);
            if (suggestions.length > 0) {
                this.addOutput('Did you mean:', 'suggestion');
                suggestions.slice(0, 3).forEach(suggestion => {
                    this.addOutput(`  ${suggestion}`, 'suggestion');
                });
            }
            return;
        }

        // Show what command is being executed if it was fuzzy matched
        const bestMatch = this.matcher.findBestMatch(baseCommand);
        if (bestMatch !== baseCommand) {
            this.addOutput(`% Executing: ${bestMatch}`, 'suggestion');
        }

        // Process through pipe chain
        try {
            const finalOutput = this.pipeProcessor.processPipes(baseOutput, pipeChain);

            if (finalOutput.trim()) {
                // Check if paging should be disabled by pipe commands
                const disablePaging = this.pipeProcessor.shouldDisablePaging();
                this.displayOutput(finalOutput, disablePaging);
            } else {
                this.addOutput('% Command completed successfully', 'suggestion');
            }
        } catch (error) {
            if (error instanceof PipeError) {
                this.addOutput(`% Pipe error: ${error.message}`, 'error');
            } else {
                this.addOutput(`% Error: ${error.message}`, 'error');
            }
        }
    }

    handleTabCompletion() {
        const input = this.inputElement.value;
        const completions = this.commandTree.getCompletions(input);

        if (completions.length === 1) {
            // Single completion - complete it
            const words = input.trim().split(/\s+/);
            if (words.length > 0) {
                words[words.length - 1] = completions[0];
                this.inputElement.value = words.join(' ') + ' ';
            } else {
                this.inputElement.value = completions[0] + ' ';
            }
        } else if (completions.length > 1) {
            // Multiple completions - show them
            this.addOutput(`${this.promptText}${input}`, 'command');
            this.addOutput('Available completions:', 'info');
            completions.slice(0, 10).forEach(completion => {
                this.addOutput(`  ${completion}`, 'info');
            });
            if (completions.length > 10) {
                this.addOutput(`  ... and ${completions.length - 10} more`, 'info');
            }
        }
    }

    showHelp(partialCommand) {
        this.addOutput(`${this.promptText}${partialCommand}?`, 'command');
        
        const helpLines = this.commandTree.getHelp(partialCommand);
        
        if (helpLines.length > 0) {
            if (partialCommand) {
                this.addOutput(`Available options for '${partialCommand}':`, 'info');
            } else {
                this.addOutput('Available commands:', 'info');
            }

            helpLines.forEach(line => {
                this.addOutput(line, 'info');
            });
        } else {
            this.addOutput(`No help available for: ${partialCommand}`, 'error');
        }

        // Show pipe commands help if no partial command or if asking about pipes
        if (!partialCommand || partialCommand.toLowerCase().includes('pipe')) {
            this.showPipeHelp();
        }
    }

    showPipeHelp() {
        this.addOutput('\nAvailable pipe commands (use after |):', 'info');

        const pipeHelp = [
            '  no-more          - Disable paging for this command',
            '  save <filename>   - Save output to file',
            '  count            - Count lines in output',
            '  match <pattern>   - Show lines matching pattern (regex)',
            '  except <pattern>  - Show lines NOT matching pattern (regex)',
            '  last <N>         - Show last N lines',
            '  find <pattern>    - Show from first matching line onward',
            '  trim <N>         - Remove N characters from left of each line',
            '  display set      - Convert config to set commands',
            '',
            'Paging commands:',
            '  pager on/off     - Enable/disable paging globally',
            '',
            'Terminal controls:',
            '  F11 or ⛶ button - Toggle fullscreen mode',
            '  ESC              - Exit fullscreen mode',
            '  Drag edges       - Resize terminal window',
            '',
            'History commands:',
            '  history          - Show command history',
            '  history clear    - Clear command history',
            '  Ctrl+R           - Reverse history search',
            '  ↑/↓ arrows      - Navigate command history',
            '  Ctrl+P           - Previous command (same as ↑)',
            '  Ctrl+N           - Next command (same as ↓)',
            '',
            'Pager controls (when viewing long output):',
            '  SPACE, f         - Page forward',
            '  b                - Page backward', 
            '  j, ↓             - Line down',
            '  k, ↑             - Line up',
            '  g                - Go to beginning',
            '  G                - Go to end',
            '  q, ESC           - Quit pager',
            '  h, ?             - Pager help',
            '',
            'Examples:',
            '  show version | no-more',
            '  show config | save backup.conf',
            '  show interfaces | match ge-0/0/0',
            '  show config | display set | save commands.txt'
        ];

        pipeHelp.forEach(line => {
            this.addOutput(line, 'info');
        });
    }

    navigateHistory(direction) {
        console.log('navigateHistory called:', direction, 'historyLength:', this.commandHistory.length, 'currentIndex:', this.historyIndex);
        
        // Ensure input has focus
        if (document.activeElement !== this.inputElement) {
            console.log('Input not focused, focusing now');
            this.inputElement.focus();
        }
        
        if (this.commandHistory.length === 0) {
            console.log('No history to navigate');
            return;
        }

        if (this.historyIndex === -1) {
            // Save current input
            this.currentInput = this.inputElement.value;
            console.log('Saved current input:', this.currentInput);
        }

        this.historyIndex += direction;
        console.log('New historyIndex:', this.historyIndex);

        // Bounds checking
        if (this.historyIndex < -1) {
            this.historyIndex = -1;
        } else if (this.historyIndex >= this.commandHistory.length) {
            this.historyIndex = this.commandHistory.length - 1;
        }

        // Set input value
        if (this.historyIndex === -1) {
            this.inputElement.value = this.currentInput;
            console.log('Restored current input:', this.currentInput);
        } else {
            const historyCmd = this.commandHistory[this.commandHistory.length - 1 - this.historyIndex];
            this.inputElement.value = historyCmd;
            console.log('Set history command:', historyCmd, 'from index:', this.commandHistory.length - 1 - this.historyIndex);
        }
        
        // Move cursor to end of input
        this.inputElement.setSelectionRange(this.inputElement.value.length, this.inputElement.value.length);
    }

    addOutput(text, type = 'output') {
        const line = document.createElement('div');
        line.className = `terminal-line terminal-${type}`;
        
        // Apply appropriate styling based on type
        const styles = {
            command: 'color: #f0f0f0; margin: 2px 0;',
            output: 'color: #d0d0d0; margin: 2px 0;',
            error: 'color: #ff6b6b; margin: 2px 0;',
            info: 'color: #b0b0b0; margin: 2px 0;',
            suggestion: 'color: #888; font-style: italic; margin: 2px 0;'
        };
        
        line.style.cssText = styles[type] || styles.output;
        line.textContent = text;
        
        this.outputArea.appendChild(line);
        
        // Always scroll to bottom
        this.scrollToBottom();
    }

    scrollToBottom() {
        // Use requestAnimationFrame to ensure the DOM has been updated
        requestAnimationFrame(() => {
            this.outputArea.scrollTop = this.outputArea.scrollHeight;
        });
    }

    displayOutput(output, forceNoPaging = false) {
        // Use pager for long output, unless paging is disabled
        if (this.pagingEnabled && !forceNoPaging && this.pager) {
            this.pager.show(output, false);
        } else {
            this.addOutput(output, 'output');
        }
    }

    clearInput() {
        this.inputElement.value = '';
    }

    clear() {
        this.outputArea.innerHTML = '';
    }

    start() {
        this.isActive = true;
        
        // Show welcome message
        this.addOutput('Junos CLI Simulator', 'info');
        this.addOutput(`Loaded ${Object.keys(this.rsiParser.getCommands()).length} commands from RSI`, 'info');
        const pagerStatus = this.pagingEnabled ? 'enabled' : 'disabled';
        this.addOutput(`Pager is ${pagerStatus} (use 'pager on/off' to control)`, 'suggestion');
        this.addOutput("Type 'clear' to clear terminal, '?' for help\n", 'suggestion');
        
        // Focus input with timeout to ensure DOM is ready
        setTimeout(() => {
            this.inputElement.focus();
            console.log('Terminal started, input focused');
        }, 100);
    }

    stop() {
        this.isActive = false;
        this.inputElement.blur();
    }

    focus() {
        if (this.isActive) {
            this.inputElement.focus();
        }
    }

    // History Management Methods
    loadHistory() {
        try {
            const savedHistory = localStorage.getItem('rsi-cli-history');
            if (savedHistory) {
                this.commandHistory = JSON.parse(savedHistory);
                // Ensure history size limit
                if (this.commandHistory.length > this.maxHistorySize) {
                    this.commandHistory = this.commandHistory.slice(-this.maxHistorySize);
                }
            }
        } catch (error) {
            console.warn('Failed to load command history:', error);
            this.commandHistory = [];
        }
    }

    saveHistory() {
        try {
            localStorage.setItem('rsi-cli-history', JSON.stringify(this.commandHistory));
        } catch (error) {
            console.warn('Failed to save command history:', error);
        }
    }

    addToHistory(command) {
        // Don't add empty commands or duplicates of the last command
        if (!command.trim() || this.commandHistory[this.commandHistory.length - 1] === command) {
            return;
        }

        // Remove any previous occurrence of this command
        const existingIndex = this.commandHistory.indexOf(command);
        if (existingIndex !== -1) {
            this.commandHistory.splice(existingIndex, 1);
        }

        // Add to end of history
        this.commandHistory.push(command);

        // Maintain history size limit
        if (this.commandHistory.length > this.maxHistorySize) {
            this.commandHistory.shift();
        }

        // Save to localStorage
        this.saveHistory();
    }

    startHistorySearch() {
        this.historySearchMode = true;
        this.historySearchTerm = '';
        this.historySearchResults = [];
        this.historySearchIndex = -1;
        
        // Change prompt to show search mode
        this.promptElement.textContent = '(reverse-i-search)`\': ';
        this.promptElement.style.color = '#ffaa00';
        this.inputElement.value = '';
        this.inputElement.placeholder = 'Type to search history...';
    }

    handleHistorySearchKey(e) {
        switch (e.key) {
            case 'Enter':
                e.preventDefault();
                this.acceptHistorySearch();
                break;
            case 'Escape':
            case 'c':
                if (e.key === 'c' && e.ctrlKey) {
                    e.preventDefault();
                }
                this.cancelHistorySearch();
                break;
            case 'r':
                if (e.ctrlKey) {
                    e.preventDefault();
                    this.nextHistorySearchResult();
                }
                break;
            case 'Backspace':
                e.preventDefault();
                this.historySearchTerm = this.historySearchTerm.slice(0, -1);
                this.updateHistorySearch();
                break;
            default:
                if (e.key.length === 1 && !e.ctrlKey && !e.altKey) {
                    e.preventDefault();
                    this.historySearchTerm += e.key;
                    this.updateHistorySearch();
                }
                break;
        }
    }

    updateHistorySearch() {
        // Find matching commands
        this.historySearchResults = this.commandHistory.filter(cmd => 
            cmd.toLowerCase().includes(this.historySearchTerm.toLowerCase())
        ).reverse(); // Most recent first

        this.historySearchIndex = 0;
        
        // Update display
        const currentMatch = this.historySearchResults[0] || '';
        this.inputElement.value = currentMatch;
        
        // Update prompt to show search term
        this.promptElement.textContent = `(reverse-i-search)\`${this.historySearchTerm}': `;
    }

    nextHistorySearchResult() {
        if (this.historySearchResults.length === 0) return;
        
        this.historySearchIndex = (this.historySearchIndex + 1) % this.historySearchResults.length;
        const currentMatch = this.historySearchResults[this.historySearchIndex];
        this.inputElement.value = currentMatch;
    }

    acceptHistorySearch() {
        // Exit search mode and keep the selected command
        this.exitHistorySearch();
        // Execute the command if one was selected
        if (this.inputElement.value.trim()) {
            this.executeCommand();
        }
    }

    cancelHistorySearch() {
        this.inputElement.value = '';
        this.exitHistorySearch();
    }

    exitHistorySearch() {
        this.historySearchMode = false;
        this.historySearchTerm = '';
        this.historySearchResults = [];
        this.historySearchIndex = -1;
        
        // Restore normal prompt
        this.promptElement.textContent = this.promptText;
        this.promptElement.style.color = '#00ff88';
        this.inputElement.placeholder = '';
        
        // Ensure input maintains focus after search
        setTimeout(() => {
            this.inputElement.focus();
        }, 10);
    }

    cancelCurrentOperation() {
        if (this.historySearchMode) {
            this.cancelHistorySearch();
        } else {
            // Clear current input
            this.inputElement.value = '';
            this.historyIndex = -1;
        }
    }

    showHistory() {
        if (this.commandHistory.length === 0) {
            this.addOutput('No commands in history', 'info');
            return;
        }

        const historyOutput = this.commandHistory
            .map((cmd, index) => `${String(index + 1).padStart(4)} ${cmd}`)
            .join('\n');
        
        this.displayOutput(historyOutput);
    }

    clearHistory() {
        this.commandHistory = [];
        this.saveHistory();
        this.addOutput('Command history cleared', 'info');
    }
}

// Export for use in other modules (if using modules)
if (typeof module !== 'undefined' && typeof module.exports !== 'undefined') {
    module.exports = { RSITerminal };
}