/**
 * Pipe Processor - JavaScript port of the Python PipeProcessor class
 * Processes Junos CLI-style pipe commands
 */

class PipeError extends Error {
    constructor(message) {
        super(message);
        this.name = 'PipeError';
    }
}

/**
 * Base class for pipe commands
 */
class PipeCommand {
    constructor(args) {
        this.args = args;
        this.validateArgs();
    }

    validateArgs() {
        // Override in subclasses
    }

    process(inputText) {
        throw new Error('Subclasses must implement process()');
    }
}

/**
 * Disable paging for current command output
 */
class NoMoreCommand extends PipeCommand {
    validateArgs() {
        if (this.args.length > 0) {
            throw new PipeError('no-more does not accept arguments');
        }
    }

    process(inputText) {
        return inputText;
    }
}

/**
 * Save output to file (browser implementation downloads file)
 */
class SaveCommand extends PipeCommand {
    validateArgs() {
        if (this.args.length !== 1) {
            throw new PipeError('save requires exactly one filename argument');
        }
    }

    process(inputText) {
        const filename = this.args[0];
        try {
            // Create downloadable blob
            const blob = new Blob([inputText], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            
            // Create temporary download link
            const link = document.createElement('a');
            link.href = url;
            link.download = filename;
            link.style.display = 'none';
            
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            // Clean up
            URL.revokeObjectURL(url);
            
            return `Output saved to ${filename}`;
        } catch (error) {
            throw new PipeError(`Failed to save to ${filename}: ${error.message}`);
        }
    }
}

/**
 * Count lines in output
 */
class CountCommand extends PipeCommand {
    validateArgs() {
        if (this.args.length > 0) {
            throw new PipeError('count does not accept arguments');
        }
    }

    process(inputText) {
        if (!inputText.trim()) {
            return '0 lines';
        }

        const lines = inputText.split('\n');
        // Don't count trailing empty line from split if text ends with newline
        if (lines.length > 0 && lines[lines.length - 1] === '') {
            lines.pop();
        }

        const lineCount = lines.length;
        return `${lineCount} lines`;
    }
}

/**
 * Filter lines matching a pattern
 */
class MatchCommand extends PipeCommand {
    validateArgs() {
        if (this.args.length !== 1) {
            throw new PipeError('match requires exactly one pattern argument');
        }
    }

    process(inputText) {
        const pattern = this.args[0];
        let regex;
        try {
            regex = new RegExp(pattern, 'i');
        } catch (error) {
            throw new PipeError(`Invalid regex pattern '${pattern}': ${error.message}`);
        }

        const lines = inputText.split('\n');
        const matchingLines = lines.filter(line => regex.test(line));

        return matchingLines.join('\n');
    }
}

/**
 * Filter out lines matching a pattern
 */
class ExceptCommand extends PipeCommand {
    validateArgs() {
        if (this.args.length !== 1) {
            throw new PipeError('except requires exactly one pattern argument');
        }
    }

    process(inputText) {
        const pattern = this.args[0];
        let regex;
        try {
            regex = new RegExp(pattern, 'i');
        } catch (error) {
            throw new PipeError(`Invalid regex pattern '${pattern}': ${error.message}`);
        }

        const lines = inputText.split('\n');
        const nonMatchingLines = lines.filter(line => !regex.test(line));

        return nonMatchingLines.join('\n');
    }
}

/**
 * Show last N lines
 */
class LastCommand extends PipeCommand {
    validateArgs() {
        if (this.args.length !== 1) {
            throw new PipeError('last requires exactly one numeric argument');
        }

        try {
            this.lineCount = parseInt(this.args[0], 10);
            if (isNaN(this.lineCount) || this.lineCount < 0) {
                throw new Error('Invalid number');
            }
        } catch (error) {
            throw new PipeError(`Invalid line count '${this.args[0]}': must be a non-negative integer`);
        }
    }

    process(inputText) {
        if (!inputText.trim()) {
            return '';
        }

        const lines = inputText.split('\n');
        // Remove trailing empty line if text ends with newline
        if (lines.length > 0 && lines[lines.length - 1] === '') {
            lines.pop();
        }

        const lastLines = this.lineCount > 0 ? lines.slice(-this.lineCount) : [];
        return lastLines.join('\n');
    }
}

/**
 * Show output starting from first line matching pattern
 */
class FindCommand extends PipeCommand {
    validateArgs() {
        if (this.args.length !== 1) {
            throw new PipeError('find requires exactly one pattern argument');
        }
    }

    process(inputText) {
        const pattern = this.args[0];
        let regex;
        try {
            regex = new RegExp(pattern, 'i');
        } catch (error) {
            throw new PipeError(`Invalid regex pattern '${pattern}': ${error.message}`);
        }

        const lines = inputText.split('\n');

        // Find first matching line
        let startIndex = null;
        for (let i = 0; i < lines.length; i++) {
            if (regex.test(lines[i])) {
                startIndex = i;
                break;
            }
        }

        if (startIndex === null) {
            return ''; // No match found
        }

        return lines.slice(startIndex).join('\n');
    }
}

/**
 * Remove N characters from left of each line
 */
class TrimCommand extends PipeCommand {
    validateArgs() {
        if (this.args.length !== 1) {
            throw new PipeError('trim requires exactly one numeric argument');
        }

        try {
            this.charCount = parseInt(this.args[0], 10);
            if (isNaN(this.charCount) || this.charCount < 0) {
                throw new Error('Invalid number');
            }
        } catch (error) {
            throw new PipeError(`Invalid character count '${this.args[0]}': must be a non-negative integer`);
        }
    }

    process(inputText) {
        const lines = inputText.split('\n');
        const trimmedLines = lines.map(line => {
            return line.length > this.charCount ? line.substring(this.charCount) : '';
        });
        return trimmedLines.join('\n');
    }
}

/**
 * Convert configuration output to set commands (basic mock implementation)
 */
class DisplaySetCommand extends PipeCommand {
    validateArgs() {
        if (this.args.length > 0) {
            throw new PipeError('display set does not accept arguments');
        }
    }

    process(inputText) {
        // Simplified mock implementation
        const lines = inputText.split('\n');
        const setCommands = [];
        const currentPath = [];

        for (const line of lines) {
            const stripped = line.trim();
            if (!stripped || stripped.startsWith('#')) {
                continue;
            }

            // Count leading spaces to determine hierarchy level
            const indentLevel = Math.floor((line.length - line.trimLeft().length) / 4);

            // Adjust current path based on indent level
            currentPath.length = indentLevel;

            if (stripped.endsWith('{')) {
                // Start of new hierarchy level
                const element = stripped.replace(/ *{$/, '');
                currentPath.push(element);
            } else if (stripped === '}') {
                // End of hierarchy level - path already adjusted above
                continue;
            } else if (stripped.endsWith(';')) {
                // Leaf configuration
                const configItem = stripped.replace(/;$/, '');
                const path = [...currentPath, configItem].join(' ');
                setCommands.push(`set ${path}`);
            }
        }

        if (setCommands.length === 0) {
            // Fallback for non-hierarchical config
            for (const line of lines) {
                if (line.trim()) {
                    setCommands.push(`set configuration ${line.trim()}`);
                }
            }
        }

        return setCommands.join('\n');
    }
}

/**
 * Simple shell-style argument parser (simplified version of shlex)
 */
function parseShellArgs(text) {
    const args = [];
    let current = '';
    let inQuotes = false;
    let quoteChar = '';

    for (let i = 0; i < text.length; i++) {
        const char = text[i];

        if ((char === '"' || char === "'") && !inQuotes) {
            inQuotes = true;
            quoteChar = char;
        } else if (char === quoteChar && inQuotes) {
            inQuotes = false;
            quoteChar = '';
        } else if (char === ' ' && !inQuotes) {
            if (current) {
                args.push(current);
                current = '';
            }
        } else {
            current += char;
        }
    }

    if (current) {
        args.push(current);
    }

    if (inQuotes) {
        throw new Error('Unclosed quote in command');
    }

    return args;
}

/**
 * Main pipe processor class
 */
class PipeProcessor {
    constructor() {
        this.disablePaging = false;
        
        // Registry of available pipe commands
        this.pipeCommands = {
            'no-more': NoMoreCommand,
            'save': SaveCommand,
            'count': CountCommand,
            'match': MatchCommand,
            'grep': MatchCommand,  // Hidden alias for match
            'except': ExceptCommand,
            'last': LastCommand,
            'find': FindCommand,
            'trim': TrimCommand,
            'display': {
                'set': DisplaySetCommand
            }
        };
    }

    /**
     * Check if command contains pipe operators
     * @param {string} command - Command string to check
     * @returns {boolean} True if command contains pipes
     */
    hasPipes(command) {
        return command.includes('|');
    }

    /**
     * Parse command with pipes into base command and pipe chain
     * @param {string} command - Full command string with pipes
     * @returns {Object} Object with baseCommand and pipeChain properties
     */
    parseCommand(command) {
        if (!this.hasPipes(command)) {
            return {
                baseCommand: command.trim(),
                pipeChain: []
            };
        }

        // Split on pipe character, being careful with quoted strings
        const parts = [];
        let currentPart = '';
        let inQuotes = false;
        let quoteChar = null;

        for (const char of command) {
            if ((char === '"' || char === "'") && !inQuotes) {
                inQuotes = true;
                quoteChar = char;
                currentPart += char;
            } else if (char === quoteChar && inQuotes) {
                inQuotes = false;
                quoteChar = null;
                currentPart += char;
            } else if (char === '|' && !inQuotes) {
                parts.push(currentPart.trim());
                currentPart = '';
            } else {
                currentPart += char;
            }
        }

        if (currentPart.trim()) {
            parts.push(currentPart.trim());
        }

        if (parts.length < 2) {
            throw new PipeError('Invalid pipe syntax: no pipe commands found');
        }

        const baseCommand = parts[0];
        const pipeChain = [];

        for (let i = 1; i < parts.length; i++) {
            const pipePart = parts[i];
            if (!pipePart) {
                throw new PipeError('Empty pipe command');
            }

            let pipeTokens;
            try {
                pipeTokens = parseShellArgs(pipePart);
            } catch (error) {
                throw new PipeError(`Invalid pipe syntax: ${error.message}`);
            }

            if (pipeTokens.length === 0) {
                throw new PipeError('Empty pipe command');
            }

            const pipeCmd = pipeTokens[0];
            const pipeArgs = pipeTokens.slice(1);

            // Handle display subcommands
            if (pipeCmd === 'display' && pipeArgs.length > 0) {
                const displaySubcmd = pipeArgs[0];
                if (displaySubcmd in this.pipeCommands.display) {
                    pipeChain.push({
                        command: `display ${displaySubcmd}`,
                        args: pipeArgs.slice(1)
                    });
                } else {
                    throw new PipeError(`Unknown display subcommand: ${displaySubcmd}`);
                }
            } else if (pipeCmd in this.pipeCommands) {
                pipeChain.push({
                    command: pipeCmd,
                    args: pipeArgs
                });
            } else {
                throw new PipeError(`Unknown pipe command: ${pipeCmd}`);
            }
        }

        return { baseCommand, pipeChain };
    }

    /**
     * Create pipe command instance
     * @param {string} commandName - Name of pipe command
     * @param {string[]} args - Command arguments
     * @returns {PipeCommand} PipeCommand instance
     */
    createPipeCommand(commandName, args) {
        if (commandName.startsWith('display ')) {
            // Handle display subcommands
            const subcmd = commandName.split(' ', 2)[1];
            if (subcmd in this.pipeCommands.display) {
                const CommandClass = this.pipeCommands.display[subcmd];
                return new CommandClass(args);
            }
        } else if (commandName in this.pipeCommands) {
            const CommandClass = this.pipeCommands[commandName];
            return new CommandClass(args);
        }

        throw new PipeError(`Unknown pipe command: ${commandName}`);
    }

    /**
     * Process output through chain of pipe commands
     * @param {string} output - Initial command output
     * @param {Array} pipeChain - Array of pipe command objects
     * @returns {string} Final processed output
     */
    processPipes(output, pipeChain) {
        let currentOutput = output;
        this.disablePaging = false;

        for (const pipeItem of pipeChain) {
            try {
                const pipeCmd = this.createPipeCommand(pipeItem.command, pipeItem.args);

                // Check for paging control
                if (pipeCmd instanceof NoMoreCommand) {
                    this.disablePaging = true;
                }

                currentOutput = pipeCmd.process(currentOutput);
            } catch (error) {
                if (error instanceof PipeError) {
                    throw error;
                } else {
                    throw new PipeError(`Error in pipe command '${pipeItem.command}': ${error.message}`);
                }
            }
        }

        return currentOutput;
    }

    /**
     * Check if paging should be disabled for current command
     * @returns {boolean} True if paging should be disabled
     */
    shouldDisablePaging() {
        return this.disablePaging;
    }

    /**
     * Get list of available pipe commands
     * @returns {string[]} Array of pipe command names
     */
    getAvailableCommands() {
        const commands = Object.keys(this.pipeCommands);
        // Remove hidden aliases from public command list
        const publicCommands = commands.filter(cmd => cmd !== 'grep');
        
        // Remove display and add display subcommands
        const finalCommands = publicCommands.filter(cmd => cmd !== 'display');
        
        // Add display subcommands
        for (const subcmd of Object.keys(this.pipeCommands.display)) {
            finalCommands.push(`display ${subcmd}`);
        }

        return finalCommands.sort();
    }

    /**
     * Reset processor state
     */
    reset() {
        this.disablePaging = false;
    }
}

// Export for use in other modules (if using modules)
if (typeof module !== 'undefined' && typeof module.exports !== 'undefined') {
    module.exports = { 
        PipeProcessor, 
        PipeError,
        PipeCommand,
        NoMoreCommand,
        SaveCommand,
        CountCommand,
        MatchCommand,
        ExceptCommand,
        LastCommand,
        FindCommand,
        TrimCommand,
        DisplaySetCommand
    };
}