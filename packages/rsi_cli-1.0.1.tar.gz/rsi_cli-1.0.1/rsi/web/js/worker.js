/**
 * Web Worker for background RSI file processing
 * Handles file decompression and parsing without blocking the UI
 */

// Import the RSI parser (this would need to be modified for worker context)
// For now, we'll include a simplified version directly

class RSIParseError extends Error {
    constructor(message) {
        super(message);
        this.name = 'RSIParseError';
    }
}

class RSIParser {
    constructor() {
        this.user = null;
        this.hostname = null;
        this.commands = {};
        this.commandPattern = /^([^@]+)@(.+-RE[0-9])> (.+)$/;
    }

    parseContent(content) {
        if (!content || typeof content !== 'string') {
            throw new RSIParseError('Content is empty or invalid');
        }

        const lines = content.split(/\r?\n/);
        
        if (lines.length === 0) {
            throw new RSIParseError('Content is empty');
        }

        let currentCommand = null;
        let outputLines = [];

        for (let i = 0; i < lines.length; i++) {
            const line = lines[i].replace(/\r$/, '');
            const match = this.commandPattern.exec(line);

            if (match) {
                if (currentCommand !== null) {
                    this.commands[currentCommand] = outputLines.join('\n');
                }

                if (this.user === null) {
                    this.user = match[1];
                    this.hostname = match[2];
                }

                currentCommand = match[3];
                outputLines = [];
            } else {
                if (currentCommand !== null) {
                    outputLines.push(line);
                }
            }
        }

        if (currentCommand !== null) {
            this.commands[currentCommand] = outputLines.join('\n');
        }

        if (Object.keys(this.commands).length === 0) {
            throw new RSIParseError('No valid RSI commands found in content');
        }

        if (this.user === null || this.hostname === null) {
            throw new RSIParseError('Unable to extract user or hostname from content');
        }
    }

    getUser() { return this.user; }
    getHostname() { return this.hostname; }
    getCommands() { return { ...this.commands }; }
}

// Web Worker message handler
self.onmessage = function(e) {
    const { type, data, id } = e.data;

    try {
        switch (type) {
            case 'parseRSI':
                const parser = new RSIParser();
                parser.parseContent(data.content);
                
                self.postMessage({
                    type: 'parseSuccess',
                    id: id,
                    data: {
                        user: parser.getUser(),
                        hostname: parser.getHostname(),
                        commands: parser.getCommands(),
                        stats: {
                            commandCount: Object.keys(parser.getCommands()).length
                        }
                    }
                });
                break;

            case 'decompressGzip':
                // This would require pako to be available in worker context
                // For now, send back to main thread
                self.postMessage({
                    type: 'error',
                    id: id,
                    error: 'Gzip decompression not implemented in worker'
                });
                break;

            case 'decompressZip':
                // This would require JSZip to be available in worker context
                // For now, send back to main thread
                self.postMessage({
                    type: 'error',
                    id: id,
                    error: 'Zip decompression not implemented in worker'
                });
                break;

            default:
                self.postMessage({
                    type: 'error',
                    id: id,
                    error: `Unknown message type: ${type}`
                });
        }
    } catch (error) {
        self.postMessage({
            type: 'error',
            id: id,
            error: error.message
        });
    }
};

// Signal that worker is ready
self.postMessage({
    type: 'ready'
});