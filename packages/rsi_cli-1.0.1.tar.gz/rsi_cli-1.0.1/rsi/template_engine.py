"""Template-based text-to-XML conversion engine.

This module provides a flexible, modular system for converting Junos command
text output to XML format using YAML-based templates.
"""

import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import yaml
from xml.dom import minidom
import pyparsing as pp


class TemplateError(Exception):
    """Exception raised for template-related errors."""
    pass


class TemplateEngine:
    """Core template engine for text-to-XML conversion.
    
    Supports YAML-based templates with inheritance, multiple parsing strategies,
    and flexible XML generation rules.
    """
    
    def __init__(self, template_dir: Optional[Union[str, Path]] = None):
        """Initialize the template engine.
        
        Args:
            template_dir: Directory containing template files
        """
        self.template_dir = Path(template_dir) if template_dir else Path(__file__).parent / "templates"
        self.template_cache: Dict[str, Dict] = {}
        self.base_templates: Dict[str, Dict] = {}
        
        # Initialize base templates
        self._load_base_templates()
    
    def _load_base_templates(self) -> None:
        """Load base templates for inheritance."""
        base_dir = self.template_dir / "base"
        if base_dir.exists():
            for template_file in base_dir.glob("*.yaml"):
                template_name = template_file.stem
                try:
                    with open(template_file, 'r') as f:
                        self.base_templates[template_name] = yaml.safe_load(f)
                except Exception as e:
                    print(f"Warning: Failed to load base template {template_name}: {e}")
    
    def load_template(self, template_path: str) -> Dict[str, Any]:
        """Load and parse a template file with inheritance support.
        
        Args:
            template_path: Path to template file (relative to template_dir)
            
        Returns:
            Parsed template dictionary
            
        Raises:
            TemplateError: If template cannot be loaded or parsed
        """
        if template_path in self.template_cache:
            return self.template_cache[template_path]
        
        full_path = self.template_dir / template_path
        if not full_path.exists():
            raise TemplateError(f"Template not found: {template_path}")
        
        try:
            with open(full_path, 'r') as f:
                template = yaml.safe_load(f)
        except yaml.YAMLError as e:
            raise TemplateError(f"Invalid YAML in template {template_path}: {e}")
        except Exception as e:
            raise TemplateError(f"Failed to load template {template_path}: {e}")
        
        # Handle template inheritance
        if 'inherit_from' in template:
            parent_name = template['inherit_from']
            if parent_name in self.base_templates:
                parent_template = self.base_templates[parent_name].copy()
                # Merge parent template with current template
                template = self._merge_templates(parent_template, template)
            else:
                raise TemplateError(f"Base template not found: {parent_name}")
        
        # Validate template structure
        self._validate_template(template)
        
        # Cache the processed template
        self.template_cache[template_path] = template
        return template
    
    def _merge_templates(self, parent: Dict, child: Dict) -> Dict:
        """Merge child template with parent template.
        
        Args:
            parent: Parent template dictionary
            child: Child template dictionary
            
        Returns:
            Merged template dictionary
        """
        merged = parent.copy()
        
        for key, value in child.items():
            if key == 'inherit_from':
                continue  # Skip inheritance directive
            elif isinstance(value, dict) and key in merged and isinstance(merged[key], dict):
                # Recursively merge nested dictionaries
                merged[key] = self._merge_templates(merged[key], value)
            elif isinstance(value, list) and key in merged and isinstance(merged[key], list):
                # Extend lists from parent
                merged[key] = merged[key] + value
            else:
                # Override parent value
                merged[key] = value
        
        return merged
    
    def _validate_template(self, template: Dict) -> None:
        """Validate template structure.
        
        Args:
            template: Template dictionary to validate
            
        Raises:
            TemplateError: If template structure is invalid
        """
        required_fields = ['name', 'parsing_strategy']
        for field in required_fields:
            if field not in template:
                raise TemplateError(f"Template missing required field: {field}")
        
        # Validate parsing strategy
        valid_strategies = ['table', 'key_value', 'hierarchical', 'mixed', 'custom', 'grammar']
        if template['parsing_strategy'] not in valid_strategies:
            raise TemplateError(f"Invalid parsing strategy: {template['parsing_strategy']}")
    
    def parse_text(self, text: str, template_path: str) -> Dict[str, Any]:
        """Parse text using specified template.
        
        Args:
            text: Input text to parse
            template_path: Path to template file
            
        Returns:
            Structured data dictionary
            
        Raises:
            TemplateError: If parsing fails
        """
        template = self.load_template(template_path)
        
        try:
            strategy = template['parsing_strategy']
            
            if strategy == 'table':
                return self._parse_table(text, template)
            elif strategy == 'key_value':
                return self._parse_key_value(text, template)
            elif strategy == 'hierarchical':
                return self._parse_hierarchical(text, template)
            elif strategy == 'mixed':
                return self._parse_mixed(text, template)
            elif strategy == 'grammar':
                return self._parse_grammar(text, template)
            elif strategy == 'custom':
                return self._parse_custom(text, template)
            else:
                raise TemplateError(f"Unknown parsing strategy: {strategy}")
                
        except Exception as e:
            raise TemplateError(f"Parsing failed for template {template_path}: {e}")
    
    def _parse_table(self, text: str, template: Dict) -> Dict[str, Any]:
        """Parse tabular text data.
        
        Args:
            text: Input text
            template: Template configuration
            
        Returns:
            Parsed data dictionary
        """
        lines = text.strip().split('\n')
        
        # Find header line
        header_pattern = template.get('header_pattern', '')
        header_found = False
        header_line_idx = 0
        
        if header_pattern:
            for i, line in enumerate(lines):
                if re.search(header_pattern, line):
                    header_found = True
                    header_line_idx = i
                    break
        else:
            # Use column definitions to detect header
            columns = template.get('columns', [])
            if columns:
                for i, line in enumerate(lines):
                    # Check if line contains column names
                    found_columns = 0
                    for col in columns:
                        if col['name'].lower() in line.lower():
                            found_columns += 1
                    if found_columns >= len(columns) // 2:  # At least half the columns found
                        header_found = True
                        header_line_idx = i
                        break
        
        if not header_found:
            raise TemplateError("Table header not found")
        
        # Parse data rows
        data_rows = []
        columns = template.get('columns', [])
        
        for line in lines[header_line_idx + 1:]:
            line = line.strip()
            if not line:
                continue
                
            # Skip lines matching ignore patterns
            ignore_patterns = template.get('ignore_patterns', [])
            if any(re.search(pattern, line) for pattern in ignore_patterns):
                continue
            
            # Parse row data
            row_data = {}
            parts = line.split()
            
            for i, col in enumerate(columns):
                if i < len(parts):
                    value = parts[i]
                    
                    # Apply transformations
                    if 'transform' in col:
                        value = self._apply_transform(value, col['transform'])
                    
                    row_data[col['name']] = value
            
            if row_data:  # Only add non-empty rows
                data_rows.append(row_data)
        
        return {'rows': data_rows}
    
    def _parse_key_value(self, text: str, template: Dict) -> Dict[str, Any]:
        """Parse key-value text data.
        
        Args:
            text: Input text
            template: Template configuration
            
        Returns:
            Parsed data dictionary
        """
        lines = text.strip().split('\n')
        result = {}
        
        separator = template.get('separator', ':')
        patterns = template.get('patterns', [])
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            # Try pattern matching first
            for pattern_config in patterns:
                pattern = pattern_config['pattern']
                match = re.search(pattern, line)
                if match:
                    key = pattern_config.get('key', match.group(1) if match.groups() else 'value')
                    value = match.group(pattern_config.get('value_group', 2 if len(match.groups()) > 1 else 1))
                    
                    # Apply transformations
                    if 'transform' in pattern_config:
                        value = self._apply_transform(value, pattern_config['transform'])
                    
                    result[key] = value
                    break
            else:
                # Fallback to simple separator-based parsing
                if separator in line:
                    key, value = line.split(separator, 1)
                    key = key.strip()
                    value = value.strip()
                    if key and value:
                        result[key] = value
        
        return result
    
    def _parse_hierarchical(self, text: str, template: Dict) -> Dict[str, Any]:
        """Parse hierarchical text data based on indentation.
        
        Args:
            text: Input text
            template: Template configuration
            
        Returns:
            Parsed data dictionary
        """
        lines = text.strip().split('\n')
        result = {}
        stack = [result]  # Stack of current context dictionaries
        
        for line in lines:
            if not line.strip():
                continue
            
            # Determine indentation level
            indent = len(line) - len(line.lstrip())
            content = line.strip()
            
            # Adjust stack based on indentation
            target_level = indent // template.get('indent_size', 2)
            while len(stack) > target_level + 1:
                stack.pop()
            
            # Parse content
            separator = template.get('separator', ':')
            if separator in content:
                key, value = content.split(separator, 1)
                key = key.strip()
                value = value.strip()
                
                current_context = stack[-1]
                current_context[key] = value
            else:
                # New section/container
                key = content
                new_section = {}
                
                current_context = stack[-1]
                current_context[key] = new_section
                stack.append(new_section)
        
        return result
    
    def _parse_mixed(self, text: str, template: Dict) -> Dict[str, Any]:
        """Parse mixed format text using multiple strategies.
        
        Args:
            text: Input text
            template: Template configuration
            
        Returns:
            Parsed data dictionary
        """
        sections = template.get('sections', [])
        result = {}
        
        for section_config in sections:
            section_pattern = section_config['pattern']
            section_strategy = section_config['strategy']
            
            # Find section in text
            match = re.search(section_pattern, text, re.MULTILINE | re.DOTALL)
            if match:
                section_text = match.group(1) if match.groups() else match.group(0)
                
                # Parse section with specified strategy
                if section_strategy == 'table':
                    section_result = self._parse_table(section_text, section_config)
                elif section_strategy == 'key_value':
                    section_result = self._parse_key_value(section_text, section_config)
                elif section_strategy == 'hierarchical':
                    section_result = self._parse_hierarchical(section_text, section_config)
                else:
                    section_result = {'content': section_text}
                
                result[section_config['name']] = section_result
        
        return result
    
    def _parse_grammar(self, text: str, template: Dict) -> Dict[str, Any]:
        """Parse text using pyparsing grammar rules.
        
        Args:
            text: Input text
            template: Template configuration with grammar definition
            
        Returns:
            Parsed data dictionary
            
        Raises:
            TemplateError: If grammar parsing fails
        """
        try:
            # Get grammar configuration
            grammar_config = template.get('grammar', {})
            grammar_type = grammar_config.get('type', 'custom')
            
            if grammar_type == 'table':
                return self._parse_grammar_table(text, grammar_config)
            elif grammar_type == 'key_value':
                return self._parse_grammar_key_value(text, grammar_config)
            elif grammar_type == 'interface_status':
                return self._parse_grammar_interface_status(text, grammar_config)
            elif grammar_type == 'custom':
                return self._parse_grammar_custom(text, grammar_config)
            else:
                raise TemplateError(f"Unknown grammar type: {grammar_type}")
                
        except Exception as e:
            raise TemplateError(f"Grammar parsing failed: {e}")
    
    def _parse_grammar_table(self, text: str, config: Dict) -> Dict[str, Any]:
        """Parse table data using pyparsing grammar.
        
        Args:
            text: Input text
            config: Grammar configuration
            
        Returns:
            Parsed table data
        """
        lines = text.strip().split('\n')
        
        # Define grammar elements
        word = pp.Word(pp.alphanums + '-_/.')
        interface_name = pp.Regex(r'[a-zA-Z0-9-]+[/-][\d/]+(?:\.[\d]+)?')
        ip_address = pp.Regex(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(?:/\d{1,2})?')
        status = pp.oneOf(['up', 'down', 'admin-down'])
        
        # Build column parsers based on configuration
        columns = config.get('columns', [])
        if not columns:
            # Default column structure for interface tables
            columns = [
                {'name': 'interface', 'parser': 'interface'},
                {'name': 'admin', 'parser': 'status'}, 
                {'name': 'link', 'parser': 'status'},
                {'name': 'proto', 'parser': 'word'}
            ]
        
        # Create parsers for each column
        column_parsers = []
        for col in columns:
            parser_type = col.get('parser', 'word')
            if parser_type == 'interface':
                column_parsers.append(interface_name)
            elif parser_type == 'status':
                column_parsers.append(status)
            elif parser_type == 'ip':
                column_parsers.append(ip_address)
            else:
                column_parsers.append(word)
        
        # Create row parser
        row_parser = pp.Group(pp.And(column_parsers))
        
        # Parse rows
        rows = []
        for line in lines:
            line = line.strip()
            if not line or line.startswith('#') or any(keyword in line.lower() 
                                                    for keyword in ['interface', 'admin', 'link']):
                continue  # Skip headers and empty lines
                
            try:
                parsed = row_parser.parseString(line, parseAll=False)
                if parsed:
                    row_data = {}
                    for i, col in enumerate(columns):
                        if i < len(parsed[0]):
                            row_data[col['name']] = parsed[0][i]
                    rows.append(row_data)
            except pp.ParseException:
                # If parsing fails, try simple word splitting as fallback
                parts = line.split()
                if len(parts) >= len(columns):
                    row_data = {}
                    for i, col in enumerate(columns):
                        if i < len(parts):
                            row_data[col['name']] = parts[i]
                    rows.append(row_data)
        
        return {'rows': rows}
    
    def _parse_grammar_key_value(self, text: str, config: Dict) -> Dict[str, Any]:
        """Parse key-value data using pyparsing grammar.
        
        Args:
            text: Input text
            config: Grammar configuration
            
        Returns:
            Parsed key-value data
        """
        # Define grammar
        key = pp.Word(pp.alphas + pp.nums + '-_ ')
        separator = pp.Literal(':')
        value = pp.restOfLine
        
        kv_pair = pp.Group(key + separator + value)
        
        result = {}
        lines = text.strip().split('\n')
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
                
            try:
                parsed = kv_pair.parseString(line)
                if parsed:
                    k = parsed[0][0].strip()
                    v = parsed[0][2].strip()
                    if k and v:
                        result[k] = v
            except pp.ParseException:
                # Fallback to simple colon splitting
                if ':' in line:
                    k, v = line.split(':', 1)
                    result[k.strip()] = v.strip()
        
        return result
    
    def _parse_grammar_interface_status(self, text: str, config: Dict) -> Dict[str, Any]:
        """Parse interface status data using specialized grammar.
        
        Args:
            text: Input text  
            config: Grammar configuration
            
        Returns:
            Parsed interface data
        """
        # Define Junos interface grammar
        interface_name = pp.Regex(r'[a-zA-Z-]+\d+[/-][\d/]+(?:\.[\d]+)?')
        admin_status = pp.oneOf(['up', 'down'])
        link_status = pp.oneOf(['up', 'down']) 
        protocol = pp.Word(pp.alphas)
        local_addr = pp.Optional(pp.Regex(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/\d{1,2}'))
        remote_addr = pp.Optional(pp.Regex(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}') | pp.Literal('0/0'))
        
        # Interface line grammar
        interface_line = pp.Group(
            interface_name('interface') +
            admin_status('admin') +
            link_status('link') + 
            protocol('proto') +
            pp.Optional(local_addr('local')) +
            pp.Optional(pp.Literal('-->')) +
            pp.Optional(remote_addr('remote'))
        )
        
        interfaces = []
        lines = text.strip().split('\n')
        
        for line in lines:
            line = line.strip()
            if not line or 'Interface' in line:
                continue
                
            try:
                parsed = interface_line.parseString(line, parseAll=False)
                if parsed:
                    iface_data = parsed[0].asDict()
                    interfaces.append(iface_data)
            except pp.ParseException:
                # Fallback parsing
                parts = line.split()
                if len(parts) >= 4:
                    iface_data = {
                        'interface': parts[0],
                        'admin': parts[1], 
                        'link': parts[2],
                        'proto': parts[3]
                    }
                    if len(parts) > 4:
                        iface_data['local'] = parts[4]
                    interfaces.append(iface_data)
        
        return {'interfaces': interfaces}
    
    def _parse_grammar_custom(self, text: str, config: Dict) -> Dict[str, Any]:
        """Parse using custom pyparsing grammar defined in template.
        
        Args:
            text: Input text
            config: Grammar configuration with custom rules
            
        Returns:
            Parsed data
        """
        # This would allow templates to define custom pyparsing grammars
        # For now, return basic parsing
        grammar_def = config.get('definition', '')
        if not grammar_def:
            return {'content': text}
        
        # In a full implementation, this would:
        # 1. Parse the grammar definition from the template
        # 2. Build pyparsing grammar objects dynamically  
        # 3. Apply the grammar to parse the text
        # 4. Return structured results
        
        # For now, return simple content
        return {'content': text, 'grammar_type': 'custom'}
    
    def _parse_custom(self, text: str, template: Dict) -> Dict[str, Any]:
        """Parse using custom parsing rules.
        
        Args:
            text: Input text
            template: Template configuration
            
        Returns:
            Parsed data dictionary
        """
        # This would be extended with custom parsing logic
        # For now, return the text as-is
        return {'content': text}
    
    def _apply_transform(self, value: str, transform: Dict) -> Any:
        """Apply transformation to a value.
        
        Args:
            value: Input value
            transform: Transformation configuration
            
        Returns:
            Transformed value
        """
        transform_type = transform.get('type')
        
        if transform_type == 'regex':
            pattern = transform['pattern']
            replacement = transform.get('replacement', r'\1')
            return re.sub(pattern, replacement, value)
        elif transform_type == 'strip':
            chars = transform.get('chars', ' ')
            return value.strip(chars)
        elif transform_type == 'split':
            delimiter = transform.get('delimiter', ' ')
            index = transform.get('index', 0)
            parts = value.split(delimiter)
            return parts[index] if 0 <= index < len(parts) else value
        elif transform_type == 'int':
            try:
                return int(value)
            except ValueError:
                return value
        elif transform_type == 'bool':
            return value.lower() in ('true', 'yes', 'on', '1', 'up')
        
        return value
    
    def generate_xml(self, data: Dict[str, Any], template_path: str) -> str:
        """Generate XML from parsed data using template.
        
        Args:
            data: Parsed data dictionary
            template_path: Path to template file
            
        Returns:
            Formatted XML string
            
        Raises:
            TemplateError: If XML generation fails
        """
        template = self.load_template(template_path)
        xml_config = template.get('xml_output', {})
        
        if not xml_config:
            raise TemplateError(f"Template {template_path} has no xml_output configuration")
        
        try:
            # Create root element
            root_name = xml_config.get('root_element', 'command-output')
            root = ET.Element(root_name)
            
            # Build XML structure from data
            self._build_xml_element(root, data, xml_config)
            
            # Format and return XML
            return self._format_xml(root)
            
        except Exception as e:
            raise TemplateError(f"XML generation failed for template {template_path}: {e}")
    
    def _build_xml_element(self, parent: ET.Element, data: Any, config: Dict) -> None:
        """Recursively build XML elements from data.
        
        Args:
            parent: Parent XML element
            data: Data to convert
            config: XML configuration
        """
        if isinstance(data, dict):
            # Get mappings from config
            mappings = config.get('mappings', {})
            
            for key, value in data.items():
                # Use mapping if available, otherwise use key
                mapped_key = mappings.get(key, key)
                
                # Create element for this key
                element_config = config.get('elements', {}).get(key, {})
                element_name = element_config.get('name', mapped_key.replace('_', '-'))
                element = ET.SubElement(parent, element_name)
                
                # Recursively build child elements
                self._build_xml_element(element, value, element_config)
        
        elif isinstance(data, list):
            # Handle list data
            item_config = config.get('item', {})
            item_name = item_config.get('name', 'item')
            
            for item in data:
                item_element = ET.SubElement(parent, item_name)
                self._build_xml_element(item_element, item, item_config)
        
        else:
            # Leaf value
            if data is not None:
                parent.text = str(data)
    
    def _format_xml(self, element: ET.Element) -> str:
        """Format XML element as indented string.
        
        Args:
            element: XML element to format
            
        Returns:
            Formatted XML string
        """
        rough_string = ET.tostring(element, encoding='unicode')
        reparsed = minidom.parseString(rough_string)
        return reparsed.toprettyxml(indent="  ")
    
    def convert_text_to_xml(self, text: str, template_path: str) -> str:
        """Complete text-to-XML conversion using template.
        
        Args:
            text: Input text to convert
            template_path: Path to template file
            
        Returns:
            XML formatted output
            
        Raises:
            TemplateError: If conversion fails
        """
        # Parse text using template
        parsed_data = self.parse_text(text, template_path)
        
        # Generate XML from parsed data
        xml_output = self.generate_xml(parsed_data, template_path)
        
        return xml_output