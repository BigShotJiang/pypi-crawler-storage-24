"""Extended RSI parser with XML conversion capabilities."""

from pathlib import Path
from typing import Dict, List, Optional, Union

from .parser import RSIParser
from .modular_xml_converter import ModularXMLConverter
from .device_client import MCPDeviceClient


class RSIXMLParser(RSIParser):
    """Extended RSI parser with XML conversion capabilities.

    This class extends the base RSIParser to provide XML conversion
    functionality for RSI command outputs.
    """

    def __init__(
        self,
        device_client: Optional[MCPDeviceClient] = None,
        template_dir: Optional[Union[str, Path]] = None,
        cache_dir: Optional[Union[str, Path]] = None,
    ):
        """Initialize RSI XML parser.

        Args:
            device_client: Optional device client for XML reference
            template_dir: Directory containing template files
            cache_dir: Directory for caching XML templates and mappings
        """
        super().__init__()
        self.xml_converter = ModularXMLConverter(device_client, template_dir, cache_dir)
        self._xml_outputs: Dict[str, str] = {}  # command -> XML output

    def build_xml_mappings(self) -> None:
        """Build XML mappings for all commands in the RSI file.

        This should be called after parse_file() to generate XML mappings
        for all discovered commands.
        """
        if not self.commands:
            raise ValueError("No commands found. Call parse_file() first.")

        command_list = list(self.commands.keys())
        self.xml_converter.build_command_mappings(command_list)

    def get_command_xml(self, command: str) -> Optional[str]:
        """Get XML output for a specific command.

        Args:
            command: The command to get XML for

        Returns:
            XML formatted output, or None if command not found or conversion failed
        """
        if command not in self.commands:
            return None

        # Check if we already have cached XML
        if command in self._xml_outputs:
            return self._xml_outputs[command]

        # Convert text output to XML
        text_output = self.commands[command]
        try:
            xml_output = self.xml_converter.convert_command_output(command, text_output)
            self._xml_outputs[command] = xml_output
            return xml_output
        except Exception:
            # Return None if conversion fails
            return None

    def get_all_commands_xml(self) -> Dict[str, str]:
        """Get XML output for all commands.

        Returns:
            Dictionary mapping commands to their XML outputs.
            Commands that fail conversion are omitted.
        """
        xml_commands = {}

        for command in self.commands.keys():
            xml_output = self.get_command_xml(command)
            if xml_output:
                xml_commands[command] = xml_output

        return xml_commands

    def get_xmlrpc_mapping(self, command: str) -> Optional[str]:
        """Get XMLRPC method name for a command.

        Args:
            command: Show command string

        Returns:
            XMLRPC method name or None if not mapped
        """
        return self.xml_converter.get_xmlrpc_name(command)

    def get_all_xmlrpc_mappings(self) -> Dict[str, str]:
        """Get XMLRPC mappings for all commands.

        Returns:
            Dictionary mapping show commands to XMLRPC method names
        """
        mappings = {}

        for command in self.commands.keys():
            xmlrpc_name = self.get_xmlrpc_mapping(command)
            if xmlrpc_name:
                mappings[command] = xmlrpc_name

        return mappings

    def export_xml_files(self, output_dir: Union[str, Path]) -> Dict[str, str]:
        """Export XML outputs to individual files.

        Args:
            output_dir: Directory to save XML files

        Returns:
            Dictionary mapping commands to their output file paths
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        file_mapping = {}

        for command in self.commands.keys():
            xml_output = self.get_command_xml(command)
            if xml_output:
                # Create safe filename from command
                safe_filename = command.replace(" ", "_").replace("/", "_") + ".xml"
                file_path = output_path / safe_filename

                try:
                    with open(file_path, "w", encoding="utf-8") as f:
                        f.write(xml_output)
                    file_mapping[command] = str(file_path)
                except OSError:
                    # Skip files that can't be written
                    pass

        return file_mapping

    def get_conversion_report(self) -> Dict[str, any]:
        """Get a report of conversion success/failure for all commands.

        Returns:
            Dictionary containing conversion statistics and details
        """
        total_commands = len(self.commands)
        successful_conversions = 0
        failed_commands = []
        xmlrpc_mapped = 0
        template_matched = 0

        for command in self.commands.keys():
            # Test XML conversion
            xml_output = self.get_command_xml(command)
            if xml_output:
                successful_conversions += 1
            else:
                failed_commands.append(command)

            # Check XMLRPC mapping
            if self.get_xmlrpc_mapping(command):
                xmlrpc_mapped += 1

            # Check template matching
            template_info = self.xml_converter.get_template_info(command)
            if template_info:
                template_matched += 1

        # Get detailed statistics from converter
        converter_stats = self.xml_converter.get_conversion_statistics()

        return {
            "total_commands": total_commands,
            "successful_conversions": successful_conversions,
            "failed_conversions": len(failed_commands),
            "failed_commands": failed_commands,
            "xmlrpc_mapped": xmlrpc_mapped,
            "template_matched": template_matched,
            "conversion_rate": successful_conversions / total_commands
            if total_commands > 0
            else 0,
            "mapping_rate": xmlrpc_mapped / total_commands if total_commands > 0 else 0,
            "template_match_rate": template_matched / total_commands if total_commands > 0 else 0,
            "converter_details": converter_stats
        }
