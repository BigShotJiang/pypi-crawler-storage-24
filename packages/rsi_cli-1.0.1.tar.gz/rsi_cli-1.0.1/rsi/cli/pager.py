"""Pager utility for handling large CLI outputs with less integration."""

import os
import shutil
import subprocess
import sys
from typing import Optional


class Pager:
    """Smart pager that uses less for large outputs when appropriate."""

    def __init__(
        self,
        enabled: bool = True,
        threshold_ratio: float = 0.8,
        less_options: Optional[str] = None,
    ) -> None:
        """Initialize pager with configuration.

        Args:
            enabled: Whether paging is enabled
            threshold_ratio: Ratio of terminal height to trigger paging (0.0-1.0)
            less_options: Custom options to pass to less command
        """
        self.enabled = enabled and self._is_paging_available()
        self.threshold_ratio = max(0.0, min(1.0, threshold_ratio))
        self.less_options = (
            less_options or "-RFSXE"
        )  # Raw colors, quit if fits, no wrap, no screen clear, quit at EOF
        self._terminal_height = self._get_terminal_height()

    def _is_paging_available(self) -> bool:
        """Check if paging is available and appropriate."""
        # Don't page if not in a TTY (e.g., piped output, redirected)
        if not sys.stdout.isatty():
            return False

        # Check if less is available
        return shutil.which("less") is not None

    def _get_terminal_height(self) -> int:
        """Get current terminal height in lines."""
        try:
            return shutil.get_terminal_size().lines
        except OSError:
            return 24  # Fallback to reasonable default

    def _count_lines(self, text: str) -> int:
        """Count visible lines in text, accounting for ANSI escape sequences."""
        if not text:
            return 0

        lines = text.split("\n")
        return len(lines)

    def _should_page(self, text: str) -> bool:
        """Determine if text should be paged."""
        if not self.enabled:
            return False

        line_count = self._count_lines(text)
        threshold = int(self._terminal_height * self.threshold_ratio)

        return line_count > threshold

    def display(self, text: str) -> None:
        """Display text, using pager if appropriate.

        Args:
            text: Text to display, may contain ANSI escape sequences
        """
        if not text:
            return

        if self._should_page(text):
            self._page_text(text)
        else:
            self._direct_output(text)

    def _page_text(self, text: str) -> None:
        """Page text through less command."""
        try:
            # Set up less environment for better display
            env = os.environ.copy()
            # LESS env var for default options (user can override)
            if "LESS" not in env:
                env["LESS"] = self.less_options

            # Start less process
            process = subprocess.Popen(
                ["less"],
                stdin=subprocess.PIPE,
                stdout=sys.stdout,
                stderr=sys.stderr,
                env=env,
                text=True,
            )

            # Send text to less and handle interrupts
            try:
                process.communicate(input=text, timeout=30)
            except subprocess.TimeoutExpired:
                # Handle timeout - terminate less gracefully
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
                print("\nPager timed out, displaying directly:", file=sys.stderr)
                self._direct_output(text)
            except KeyboardInterrupt:
                # Handle Ctrl+C - terminate less and re-raise
                process.terminate()
                try:
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
                raise

        except (OSError, subprocess.SubprocessError) as e:
            # Fallback to direct output if less fails
            print(f"Pager failed ({e}), displaying directly:", file=sys.stderr)
            self._direct_output(text)

    def _direct_output(self, text: str) -> None:
        """Output text directly to stdout."""
        print(text, end="" if text.endswith("\n") else "\n")

    def is_enabled(self) -> bool:
        """Check if paging is currently enabled."""
        return self.enabled

    def set_enabled(self, enabled: bool) -> None:
        """Enable or disable paging.

        Args:
            enabled: Whether to enable paging
        """
        self.enabled = enabled and self._is_paging_available()

    def update_terminal_size(self) -> None:
        """Update cached terminal size (call after terminal resize)."""
        self._terminal_height = self._get_terminal_height()


# Global pager instance for CLI use
_default_pager: Optional[Pager] = None


def get_default_pager() -> Pager:
    """Get or create the default pager instance."""
    global _default_pager
    if _default_pager is None:
        # Check environment variables for configuration
        enabled = os.environ.get("RSI_PAGER", "1").lower() not in ("0", "false", "off")
        threshold = float(os.environ.get("RSI_PAGER_THRESHOLD", "0.8"))
        less_opts = os.environ.get("RSI_LESS_OPTIONS")

        _default_pager = Pager(
            enabled=enabled, threshold_ratio=threshold, less_options=less_opts
        )

    return _default_pager


def display_text(text: str) -> None:
    """Convenience function to display text using the default pager.

    Args:
        text: Text to display
    """
    get_default_pager().display(text)


def is_paging_enabled() -> bool:
    """Check if paging is enabled on the default pager."""
    return get_default_pager().is_enabled()


def set_paging_enabled(enabled: bool) -> None:
    """Enable or disable paging on the default pager.

    Args:
        enabled: Whether to enable paging
    """
    get_default_pager().set_enabled(enabled)
