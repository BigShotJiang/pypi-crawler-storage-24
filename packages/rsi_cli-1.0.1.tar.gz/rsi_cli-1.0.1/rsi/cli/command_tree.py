from typing import Dict, List, Optional


class CommandNode:
    """Represents a node in the command tree.

    Each node represents a word or component in a command path and can have
    child nodes representing the next possible words in the command sequence.
    """

    def __init__(self, name: str = "") -> None:
        """Initialize command node.

        Args:
            name: The word/component this node represents
        """
        self.name = name
        self.children: Dict[str, CommandNode] = {}
        self.is_complete = False  # True if this is a complete command
        self.full_command: Optional[str] = None  # The full original command

    def add_child(self, name: str) -> "CommandNode":
        """Add a child node and return it.

        Args:
            name: Name of the child node to add

        Returns:
            The child node (new or existing)
        """
        if name not in self.children:
            self.children[name] = CommandNode(name)
        return self.children[name]

    def get_completions(self, prefix: str = "") -> List[str]:
        """Get all possible completions from this node.

        Args:
            prefix: Optional prefix to filter completions

        Returns:
            Sorted list of completion strings
        """
        completions = []
        for child_name, _child_node in self.children.items():
            if child_name.startswith(prefix.lower()):
                completions.append(child_name)
        return sorted(completions)


class CommandTree:
    """Builds and manages a hierarchical command tree from RSI commands.

    The command tree enables efficient command completion and help lookup by
    organizing commands in a hierarchical structure where each level represents
    a word in the command sequence.
    """

    def __init__(self, commands: List[str]) -> None:
        """Initialize command tree with list of commands.

        Args:
            commands: List of command strings to build the tree from
        """
        self.root = CommandNode()
        self._build_tree(commands)

    def _build_tree(self, commands: List[str]) -> None:
        """Build the command tree from a list of commands."""
        for command in commands:
            self._add_command(command)

    def _add_command(self, command: str) -> None:
        """Add a single command to the tree."""
        # Split command into parts (handle quoted strings)
        parts = self._split_command(command)

        current_node = self.root
        for part in parts:
            current_node = current_node.add_child(part.lower())

        # Mark the final node as a complete command
        current_node.is_complete = True
        current_node.full_command = command

    def _split_command(self, command: str) -> List[str]:
        """Split command into parts, handling quoted strings."""
        parts = []
        current_part = ""
        in_quotes = False

        for char in command:
            if char == '"' and not in_quotes:
                in_quotes = True
                current_part += char
            elif char == '"' and in_quotes:
                in_quotes = False
                current_part += char
            elif char == " " and not in_quotes:
                if current_part:
                    parts.append(current_part)
                    current_part = ""
            else:
                current_part += char

        if current_part:
            parts.append(current_part)

        return parts

    def get_completions(self, partial_command: str) -> List[str]:
        """Get possible completions for a partial command."""
        if not partial_command.strip():
            return self.root.get_completions()

        # Check if command ends with space - means we want next level completions
        ends_with_space = partial_command.endswith(" ")
        parts = self._split_command(partial_command.strip())
        current_node = self.root

        if ends_with_space:
            # Navigate through all parts to get to the next level
            for part in parts:
                if part.lower() in current_node.children:
                    current_node = current_node.children[part.lower()]
                else:
                    return []  # Invalid path
            # Return all completions from this level
            return current_node.get_completions()
        else:
            # Navigate to the appropriate node (all but last part)
            for part in parts[:-1]:
                if part.lower() in current_node.children:
                    current_node = current_node.children[part.lower()]
                else:
                    return []  # Invalid path

            # Get completions for the last part
            last_part = parts[-1] if parts else ""
            return current_node.get_completions(last_part)

    def find_command(self, partial_command: str) -> Optional[str]:
        """Find the full command that matches a partial command."""
        parts = self._split_command(partial_command.strip())
        current_node = self.root

        for part in parts:
            if part.lower() in current_node.children:
                current_node = current_node.children[part.lower()]
            else:
                return None

        return current_node.full_command if current_node.is_complete else None

    def get_help(self, partial_command: str) -> List[str]:
        """Get help information for a partial command."""
        if not partial_command.strip():
            completions = self.root.get_completions()
            return [f"  {comp}" for comp in completions[:10]]  # Limit to 10

        # For help, we want to show what comes next rather than complete partial words
        # Add a space to get next-level completions (like in traditional CLI help)
        if not partial_command.endswith(" "):
            # Check if this is a valid complete command path first
            parts = self._split_command(partial_command.strip())
            current_node = self.root
            is_valid_path = True

            for part in parts:
                if part.lower() in current_node.children:
                    current_node = current_node.children[part.lower()]
                else:
                    is_valid_path = False
                    break

            if is_valid_path:
                if current_node.children:
                    # Valid path with children - show subcommands
                    completions = current_node.get_completions()
                else:
                    # Valid complete command with no children
                    return [f"Complete command: {partial_command}"]
            else:
                # Invalid path - get regular completions
                completions = self.get_completions(partial_command)
        else:
            # Already has trailing space, use get_completions directly
            completions = self.get_completions(partial_command)

        if not completions:
            return [f"Unknown command: {partial_command}"]

        help_lines = []
        for comp in completions[:10]:  # Limit to 10
            help_lines.append(f"  {comp}")

        if len(completions) > 10:
            help_lines.append(f"  ... and {len(completions) - 10} more options")

        return help_lines
