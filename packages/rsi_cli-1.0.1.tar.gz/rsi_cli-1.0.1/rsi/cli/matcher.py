import re
from difflib import SequenceMatcher
from typing import TYPE_CHECKING, Dict, List, Optional, Set, Tuple

if TYPE_CHECKING:
    from ..parser import RSIParser


class CommandMatcher:
    """Handles command matching and fuzzy search for RSI commands.

    Provides multiple strategies for matching user input to available commands:
    - Exact matching for precise command lookup
    - Partial matching for command abbreviations
    - Fuzzy matching for typo tolerance and command suggestions
    """

    def __init__(
        self, commands: Dict[str, str], rsi_parser: Optional["RSIParser"] = None
    ) -> None:
        """Initialize matcher with available commands.

        Args:
            commands: Dictionary mapping command strings to their outputs
            rsi_parser: Optional RSI parser for interface filtering functionality
        """
        self.commands = commands
        self.command_list = list(commands.keys())
        self.rsi_parser = rsi_parser

        # Interface command patterns - support both word orders
        # Pattern 1: show interfaces [type] interface (current format)
        self._interface_command_pattern1 = re.compile(
            r"^show\s+interfaces\s+(extensive|terse|queue)?\s*([^\s]+)\s*$",
            re.IGNORECASE,
        )
        # Pattern 2: show interfaces interface [type] (new format)
        self._interface_command_pattern2 = re.compile(
            r"^show\s+interfaces\s+([^\s]+)\s*(extensive|terse|queue)?\s*$",
            re.IGNORECASE,
        )

        # Interface command mapping
        self._interface_command_mapping = {
            "extensive": "show interfaces extensive no-forwarding",
            "terse": "show interfaces terse",
            "queue": "show interfaces queue",
            None: "show interfaces extensive no-forwarding",  # default
        }

    def exact_match(self, command: str) -> Optional[str]:
        """Find exact command match.

        Args:
            command: Command string to match exactly

        Returns:
            Command output if found, None otherwise
        """
        return self.commands.get(command)

    def partial_match(self, partial_command: str) -> List[str]:
        """Find commands that start with the partial command.

        Args:
            partial_command: Partial command string to match

        Returns:
            Sorted list of commands starting with the partial string
        """
        partial_lower = partial_command.lower().strip()
        matches = []

        for cmd in self.command_list:
            if cmd.lower().startswith(partial_lower):
                matches.append(cmd)

        return sorted(matches)

    def fuzzy_match(
        self, command: str, threshold: float = 0.6
    ) -> List[Tuple[str, float]]:
        """Find commands similar to the input using fuzzy matching.

        Args:
            command: Command string to find similar matches for
            threshold: Minimum similarity score (0.0 to 1.0) for matches

        Returns:
            List of (command, similarity_score) tuples sorted by similarity
        """
        command_lower = command.lower().strip()
        matches = []

        for cmd in self.command_list:
            ratio = SequenceMatcher(None, command_lower, cmd.lower()).ratio()
            if ratio >= threshold:
                matches.append((cmd, ratio))

        # Sort by similarity score (descending)
        return sorted(matches, key=lambda x: x[1], reverse=True)

    def find_best_match(self, user_input: str) -> Optional[str]:
        """Find the best matching command for user input."""
        user_input = user_input.strip()

        # Try exact match first
        if user_input in self.commands:
            return user_input

        # Check for RSI commands with literal pipes whose base part
        # exactly matches user input (e.g., "show configuration" resolves
        # to "show configuration | except SECRET-DATA")
        piped_matches = [
            cmd for cmd in self.command_list
            if "|" in cmd and cmd.split("|")[0].strip() == user_input
        ]
        if len(piped_matches) == 1:
            return piped_matches[0]

        # Try partial matches (excluding commands with literal pipes)
        partial_matches = [
            m for m in self.partial_match(user_input) if "|" not in m
        ]
        if len(partial_matches) == 1:
            return partial_matches[0]

        # No fuzzy matching - require exact or partial matches only
        return None

    def get_command_output(self, user_input: str) -> Optional[str]:
        """Get output for the best matching command."""
        # Check if this is an interface-specific command
        interface_output = self._try_interface_command(user_input)
        if interface_output is not None:
            return interface_output

        # Fall back to regular command matching
        best_match = self.find_best_match(user_input)
        if best_match:
            return self.commands[best_match]
        return None

    def suggest_commands(self, user_input: str, max_suggestions: int = 5) -> List[str]:
        """Suggest similar commands for invalid input."""
        # Try partial matches first
        partial_matches = self.partial_match(user_input)
        if partial_matches:
            return partial_matches[:max_suggestions]

        # Fall back to fuzzy matches
        fuzzy_matches = self.fuzzy_match(user_input, threshold=0.4)
        suggestions = [match[0] for match in fuzzy_matches[:max_suggestions]]

        # Add interface suggestions if this looks like an interface command
        if self._looks_like_interface_command(user_input) and self.rsi_parser:
            interface_suggestions = self._suggest_interface_commands(user_input)
            # Merge and deduplicate
            all_suggestions = suggestions + interface_suggestions
            seen = set()
            unique_suggestions = []
            for suggestion in all_suggestions:
                if suggestion not in seen:
                    seen.add(suggestion)
                    unique_suggestions.append(suggestion)
            return unique_suggestions[:max_suggestions]

        return suggestions

    def _try_interface_command(self, user_input: str) -> Optional[str]:
        """Try to handle interface-specific commands.

        Supports both command formats:
        - show interfaces [type] interface (e.g., "show interfaces terse ge-0/0/0")
        - show interfaces interface [type] (e.g., "show interfaces ge-0/0/0 terse")
        - show interfaces interface (defaults to extensive)

        Args:
            user_input: User command input

        Returns:
            Interface-specific output if match found, None otherwise
        """
        if not self.rsi_parser:
            return None

        user_input = user_input.strip()

        # Try pattern 1: show interfaces [type] interface
        match = self._interface_command_pattern1.match(user_input)
        if match:
            command_type = match.group(1)  # extensive, terse, queue, or None
            interface_name = match.group(2)  # interface name
        else:
            # Try pattern 2: show interfaces interface [type]
            match = self._interface_command_pattern2.match(user_input)
            if match:
                interface_name = match.group(1)  # interface name
                command_type = match.group(2)  # extensive, terse, queue, or None
            else:
                return None

        # Map to base command type (default to extensive if not specified)
        base_command_type = command_type.lower() if command_type else "extensive"

        # Get interface output (exact match only for interface commands)
        interface_output = self.rsi_parser.get_interface_output(
            interface_name, base_command_type
        )
        if interface_output:
            return interface_output

        # For interface commands, we require exact matches - no fuzzy matching
        # This prevents confusion where ge-0/0/0 might match xe-0/0/0
        return None

    def _looks_like_interface_command(self, user_input: str) -> bool:
        """Check if user input looks like an interface command."""
        user_input = user_input.strip()
        return bool(self._interface_command_pattern1.match(user_input)) or bool(
            self._interface_command_pattern2.match(user_input)
        )

    def _find_similar_interfaces(
        self, interface_name: str, available_interfaces: Set[str]
    ) -> List[str]:
        """Find interfaces with similar names.

        Args:
            interface_name: Target interface name
            available_interfaces: Set of available interface names

        Returns:
            List of similar interface names, sorted by similarity
        """
        similarities = []
        interface_lower = interface_name.lower()

        for available in available_interfaces:
            ratio = SequenceMatcher(None, interface_lower, available.lower()).ratio()
            if ratio >= 0.6:  # Similarity threshold
                similarities.append((available, ratio))

        # Sort by similarity (descending) and return interface names
        similarities.sort(key=lambda x: x[1], reverse=True)
        return [iface for iface, _ in similarities]

    def _suggest_interface_commands(self, user_input: str) -> List[str]:
        """Suggest interface-specific commands.

        Args:
            user_input: User input that looks like an interface command

        Returns:
            List of suggested interface commands
        """
        if not self.rsi_parser:
            return []

        suggestions = []
        available_interfaces = self.rsi_parser.get_available_interfaces()

        # Extract partial interface name from input - try both patterns
        user_input = user_input.strip()
        command_type = None
        partial_interface = None

        # Try pattern 1: show interfaces [type] interface
        match = self._interface_command_pattern1.match(user_input)
        if match:
            command_type = match.group(1) or "extensive"
            partial_interface = match.group(2)
        else:
            # Try pattern 2: show interfaces interface [type]
            match = self._interface_command_pattern2.match(user_input)
            if match:
                partial_interface = match.group(1)
                command_type = match.group(2) or "extensive"

        if partial_interface:
            # Find interfaces that start with the partial name
            matching_interfaces = [
                iface
                for iface in available_interfaces
                if iface.lower().startswith(partial_interface.lower())
            ]

            # Generate command suggestions in both formats
            for interface in sorted(matching_interfaces)[:3]:  # Limit to 3 suggestions
                # Suggest pattern 1 format (current format)
                suggestion1 = f"show interfaces {command_type} {interface}"
                suggestions.append(suggestion1)
                # Also suggest pattern 2 format (new format)
                if command_type != "extensive":  # Don't suggest redundant default
                    suggestion2 = f"show interfaces {interface} {command_type}"
                    suggestions.append(suggestion2)

        return suggestions
