import sys
from typing import Generator

from prompt_toolkit import prompt
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.history import InMemoryHistory
from prompt_toolkit.shortcuts import print_formatted_text

from ..parser import RSIParseError, RSIParser
from ..rsi_xml_parser import RSIXMLParser
from ..device_client import create_device_client
from .command_tree import CommandTree
from .matcher import CommandMatcher
from .pager import display_text, is_paging_enabled, set_paging_enabled
from .pipe_processor import PipeError, PipeProcessor


class JunosCompleter(Completer):
    """Custom completer for Junos commands.

    Provides intelligent tab completion for Junos CLI commands based on
    the hierarchical command tree built from RSI data.
    """

    def __init__(self, command_tree: CommandTree) -> None:
        """Initialize completer with command tree.

        Args:
            command_tree: Hierarchical tree of available commands
        """
        self.command_tree = command_tree

    def get_completions(
        self, document, complete_event
    ) -> Generator[Completion, None, None]:
        """Get completions for the current input.

        Args:
            document: Current document being edited
            complete_event: Completion event details

        Yields:
            Completion objects for matching commands
        """
        text = document.text_before_cursor

        # Handle special case for '?' - remove the '?' and get completions
        if text.endswith("?"):
            text = text[:-1]

        # Check if we're completing after a pipe
        if "|" in text:
            yield from self._complete_pipe_commands(text, complete_event)
        else:
            # Regular command completion
            completions = self.command_tree.get_completions(text)

            for completion in completions:
                # Calculate how much of the current word to replace
                words = text.split()
                if words and not text.endswith(" "):
                    # There are words and text doesn't end with space
                    current_word = words[-1]
                    start_position = -len(current_word)
                else:
                    # No words or text ends with space - insert at cursor
                    start_position = 0

                yield Completion(completion, start_position=start_position)

    def _complete_pipe_commands(
        self, text: str, complete_event
    ) -> Generator[Completion, None, None]:
        """Complete pipe commands after | character.

        Args:
            text: Text before cursor
            complete_event: Completion event details

        Yields:
            Completion objects for pipe commands
        """
        # Find the last pipe position
        last_pipe_pos = text.rfind("|")
        if last_pipe_pos == -1:
            return

        # Get text after last pipe
        pipe_text = text[last_pipe_pos + 1 :].strip()

        # Get available pipe commands
        from .pipe_processor import PipeProcessor

        processor = PipeProcessor()
        pipe_commands = processor.get_available_commands()

        # Filter commands that match the current input
        if pipe_text:
            matching_commands = [
                cmd for cmd in pipe_commands if cmd.startswith(pipe_text)
            ]
        else:
            matching_commands = pipe_commands

        # Calculate start position for replacement
        if pipe_text:
            start_position = -len(pipe_text)
        else:
            start_position = 0

        for cmd in matching_commands:
            yield Completion(cmd, start_position=start_position)


class JunosCLI:
    """Main CLI interface for Junos simulation.

    Provides an interactive command-line interface that mimics a Juniper device
    CLI using commands and outputs from RSI files. Supports tab completion,
    command history, help system, and fuzzy command matching.
    """

    def __init__(self, rsi_parser: RSIParser) -> None:
        """Initialize CLI with parsed RSI data.

        Args:
            rsi_parser: Initialized RSI parser containing commands and metadata
        """
        self.parser = rsi_parser
        self.command_tree = CommandTree(list(rsi_parser.get_commands().keys()))
        self.matcher = CommandMatcher(rsi_parser.get_commands(), rsi_parser)
        self.completer = JunosCompleter(self.command_tree)
        self.history = InMemoryHistory()
        self.pipe_processor = PipeProcessor()

        # Build prompt
        user = self.parser.get_user() or "user"
        hostname = self.parser.get_hostname() or "device"
        self.prompt_text = f"{user}@{hostname}> "

    def run(self) -> None:
        """Start the interactive CLI session."""
        print_formatted_text(HTML("<ansigreen>Junos CLI Simulator</ansigreen>"))
        print_formatted_text(
            HTML(
                f"<ansiblue>Loaded {len(self.parser.get_commands())} commands from RSI</ansiblue>"
            )
        )
        pager_status = "enabled" if is_paging_enabled() else "disabled"
        print_formatted_text(
            HTML(
                f"<ansibrightblack>Pager is {pager_status} (use 'pager on/off' to control)</ansibrightblack>"
            )
        )
        print_formatted_text("Type 'quit' or 'exit' to leave, '?' for help\n")

        while True:
            try:
                user_input = prompt(
                    self.prompt_text,
                    completer=self.completer,
                    history=self.history,
                    complete_while_typing=True,
                ).strip()

                if not user_input:
                    continue

                # Handle special commands
                if user_input.lower() in ["quit", "exit"]:
                    print_formatted_text("Goodbye!")
                    break

                # Handle pager control commands
                if user_input.lower() in ["set pager on", "pager on"]:
                    set_paging_enabled(True)
                    print_formatted_text("Pager enabled")
                    continue
                elif user_input.lower() in ["set pager off", "pager off"]:
                    set_paging_enabled(False)
                    print_formatted_text("Pager disabled")
                    continue

                # Handle help request
                if user_input.endswith("?"):
                    self._show_help(user_input[:-1].strip())
                    continue

                # Execute command
                self._execute_command(user_input)

            except (KeyboardInterrupt, EOFError):
                print_formatted_text("\nGoodbye!")
                break
            except Exception as e:
                print_formatted_text(HTML(f"<ansired>Error: {e}</ansired>"))

    def _execute_command(self, command: str) -> None:
        """Execute a command and display output."""
        try:
            # Check for pipe commands
            if self.pipe_processor.has_pipes(command):
                self._execute_piped_command(command)
            else:
                self._execute_simple_command(command)
        except PipeError as e:
            print_formatted_text(HTML(f"<ansired>% Pipe error: {e}</ansired>"))

    def _execute_simple_command(self, command: str) -> None:
        """Execute a simple command without pipes."""
        output = self.matcher.get_command_output(command)

        if output is not None:
            # Check if this was handled as an interface command
            is_interface_command = self.matcher._looks_like_interface_command(command)

            if not is_interface_command:
                # For non-interface commands, show execution message if command was fuzzy matched
                best_match = self.matcher.find_best_match(command)
                if best_match and best_match != command:
                    print_formatted_text(
                        HTML(
                            f"<ansibrightblack>% Executing: {best_match}</ansibrightblack>"
                        )
                    )

            if output.strip():
                # Use pager for command output
                self._display_output(output)
            else:
                print_formatted_text(
                    HTML(
                        "<ansibrightblack>% Command completed successfully</ansibrightblack>"
                    )
                )
        else:
            # Command not found
            print_formatted_text(
                HTML(f"<ansired>% Unknown command: {command}</ansired>")
            )

            # Suggest similar commands
            suggestions = self.matcher.suggest_commands(command)
            if suggestions:
                print_formatted_text(
                    HTML("<ansibrightblack>Did you mean:</ansibrightblack>")
                )
                for suggestion in suggestions[:3]:
                    print_formatted_text(
                        HTML(f"<ansibrightblack>  {suggestion}</ansibrightblack>")
                    )

    def _execute_piped_command(self, command: str) -> None:
        """Execute a command with pipe processing."""
        # Parse the command and pipes
        base_command, pipe_chain = self.pipe_processor.parse_command(command)

        # Execute the base command
        base_output = self.matcher.get_command_output(base_command)

        if base_output is None:
            print_formatted_text(
                HTML(f"<ansired>% Unknown command: {base_command}</ansired>")
            )

            # Suggest similar commands
            suggestions = self.matcher.suggest_commands(base_command)
            if suggestions:
                print_formatted_text(
                    HTML("<ansibrightblack>Did you mean:</ansibrightblack>")
                )
                for suggestion in suggestions[:3]:
                    print_formatted_text(
                        HTML(f"<ansibrightblack>  {suggestion}</ansibrightblack>")
                    )
            return

        # Show what command is being executed if it was fuzzy matched
        is_interface_command = self.matcher._looks_like_interface_command(base_command)

        if not is_interface_command:
            best_match = self.matcher.find_best_match(base_command)
            if best_match and best_match != base_command:
                print_formatted_text(
                    HTML(
                        f"<ansibrightblack>% Executing: {best_match}</ansibrightblack>"
                    )
                )

        # Process through pipe chain
        try:
            final_output = self.pipe_processor.process_pipes(base_output, pipe_chain)

            if final_output.strip():
                # Check if paging should be disabled by pipe commands
                disable_paging = self.pipe_processor.should_disable_paging()
                self._display_output(final_output, force_no_paging=disable_paging)
            else:
                print_formatted_text(
                    HTML(
                        "<ansibrightblack>% Command completed successfully</ansibrightblack>"
                    )
                )
        except PipeError as e:
            print_formatted_text(HTML(f"<ansired>% Pipe error: {e}</ansired>"))

    def _display_output(self, output: str, force_no_paging: bool = False) -> None:
        """Display command output using appropriate method (pager or direct).

        Args:
            output: Text to display
            force_no_paging: If True, disable paging for this output
        """
        if is_paging_enabled() and not force_no_paging:
            # Convert HTML formatting to ANSI for pager
            # For now, use the output directly since it's already plain text from RSI
            display_text(output)
        else:
            print_formatted_text(output)

    def _show_help(self, partial_command: str) -> None:
        """Show help for a partial command."""
        help_lines = self.command_tree.get_help(partial_command)

        if help_lines:
            if partial_command:
                print_formatted_text(
                    HTML(
                        f"<ansibrightblack>Available options for '{partial_command}':</ansibrightblack>"
                    )
                )
            else:
                print_formatted_text(
                    HTML("<ansibrightblack>Available commands:</ansibrightblack>")
                )

            for line in help_lines:
                print_formatted_text(line)
        else:
            print_formatted_text(
                HTML(f"<ansired>No help available for: {partial_command}</ansired>")
            )

        # Show pipe commands help if no partial command or if asking about pipes
        if not partial_command or "pipe" in partial_command.lower():
            self._show_pipe_help()

    def _show_pipe_help(self) -> None:
        """Show help for pipe commands."""
        print_formatted_text(
            HTML(
                "<ansibrightblack>\nAvailable pipe commands (use after |):</ansibrightblack>"
            )
        )

        pipe_help = [
            "  no-more          - Disable paging for this command",
            "  save <filename>   - Save output to file",
            "  count            - Count lines in output",
            "  match <pattern>   - Show lines matching pattern (regex)",
            "  except <pattern>  - Show lines NOT matching pattern (regex)",
            "  last <N>         - Show last N lines",
            "  find <pattern>    - Show from first matching line onward",
            "  trim <N>         - Remove N characters from left of each line",
            "  display set      - Convert config to set commands",
            "",
            "Examples:",
            "  show version | no-more",
            "  show config | save backup.conf",
            "  show interfaces | match ge-0/0/0",
            "  show config | display set | save commands.txt",
        ]

        for line in pipe_help:
            print_formatted_text(line)


def main() -> None:
    """Main entry point for CLI."""
    import argparse
    from importlib.metadata import version

    parser_arg = argparse.ArgumentParser(description="RSI CLI Simulator")
    parser_arg.add_argument(
        "--version", action="version", version=f"%(prog)s {version('rsi-device')}"
    )
    parser_arg.add_argument("rsi_file", help="Path to RSI file")
    parser_arg.add_argument(
        "--no-pager", action="store_true", help="Disable pager for output"
    )
    parser_arg.add_argument(
        "--pager-threshold",
        type=float,
        default=0.8,
        help="Paging threshold as ratio of terminal height (0.0-1.0, default: 0.8)",
    )
    parser_arg.add_argument(
        "--xml-output",
        action="store_true",
        help="Enable XML output mode (requires device connectivity)",
    )
    parser_arg.add_argument(
        "--export-xml",
        metavar="DIR",
        help="Export all commands as XML files to specified directory",
    )
    parser_arg.add_argument(
        "--xml-report", action="store_true", help="Generate XML conversion report"
    )
    parser_arg.add_argument(
        "--build-xml-mappings",
        action="store_true",
        help="Build command to XMLRPC mappings using device (requires connectivity)",
    )

    args = parser_arg.parse_args()

    # Configure pager before creating CLI
    if args.no_pager:
        set_paging_enabled(False)

    try:
        # Determine if XML functionality is needed
        needs_xml = (
            args.xml_output
            or args.export_xml
            or args.xml_report
            or args.build_xml_mappings
        )

        if needs_xml:
            # Create device client for XML functionality
            device_client = create_device_client()
            parser = RSIXMLParser(device_client, template_dir=None)
            print_formatted_text(
                HTML("<ansiblue>XML mode enabled - using Modular Template System</ansiblue>")
            )
        else:
            parser = RSIParser()

        parser.parse_file(args.rsi_file)

        # Handle XML-specific operations
        if needs_xml and isinstance(parser, RSIXMLParser):
            if args.build_xml_mappings:
                print_formatted_text(
                    HTML("<ansiblue>Building XML command mappings...</ansiblue>")
                )
                parser.build_xml_mappings()
                print_formatted_text(
                    HTML("<ansigreen>XML mappings built successfully!</ansigreen>")
                )

            if args.export_xml:
                print_formatted_text(
                    HTML(
                        f"<ansiblue>Exporting XML files to {args.export_xml}...</ansiblue>"
                    )
                )
                file_mapping = parser.export_xml_files(args.export_xml)
                print_formatted_text(
                    HTML(
                        f"<ansigreen>Exported {len(file_mapping)} XML files</ansigreen>"
                    )
                )
                for cmd, path in file_mapping.items():
                    print(f"  {cmd} -> {path}")

            if args.xml_report:
                print_formatted_text(
                    HTML("<ansiblue>Generating XML conversion report...</ansiblue>")
                )
                report = parser.get_conversion_report()
                print_formatted_text(
                    HTML("<ansicyan>XML Conversion Report:</ansicyan>")
                )
                print(f"Total commands: {report['total_commands']}")
                print(f"Successful conversions: {report['successful_conversions']}")
                print(f"Failed conversions: {report['failed_conversions']}")
                print(f"XMLRPC mapped: {report['xmlrpc_mapped']}")
                print(f"Conversion rate: {report['conversion_rate']:.1%}")
                print(f"Mapping rate: {report['mapping_rate']:.1%}")

                if report["failed_commands"]:
                    print_formatted_text(HTML("<ansired>Failed commands:</ansired>"))
                    for cmd in report["failed_commands"][:10]:  # Show first 10
                        print(f"  {cmd}")
                    if len(report["failed_commands"]) > 10:
                        print(f"  ... and {len(report['failed_commands']) - 10} more")

                # Exit after report if not in interactive mode
                if not args.xml_output:
                    return

        cli = JunosCLI(parser)
        cli.run()

    except RSIParseError as e:
        print(f"Error parsing RSI file: {e}", file=sys.stderr)
        sys.exit(1)
    except FileNotFoundError:
        print(f"RSI file not found: {args.rsi_file}", file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nGoodbye!")
        sys.exit(0)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
