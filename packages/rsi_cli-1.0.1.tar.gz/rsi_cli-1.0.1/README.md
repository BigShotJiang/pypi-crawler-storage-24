# rsi-explorer

A Juniper RSI (Request Support Information) parser and interactive Junos CLI simulator. Load an RSI file and explore its contents as if you were on the actual device, with tab completion, pipe commands, and contextual help.

<img width="900" alt="RSI CLI Demo" src="https://vhs.charm.sh/vhs-k0hgRT4fjzigLjA4VzKlw.gif">

## Quick Start

```bash
uvx rsi-cli <rsi-file>
```

## Installation

Install as a persistent tool with uv:

```bash
uv tool install rsi-cli
```

Or clone and install from source:

```bash
git clone git@github.hpe.com:michael-tucker1/rsi-device.git
cd rsi-device
uv sync
```

For Junos device integration (optional):

```bash
uv sync --extra junos
```

## Usage

After installing with `uv tool install`:

```bash
rsi-cli <rsi-file>
```

From a cloned source checkout (after `uv sync`):

```bash
uv run rsi-cli <rsi-file>
```

## CLI Features

- **Tab completion** — press TAB to autocomplete commands at any level
- **Contextual help** — append `?` to any command to see available subcommands
- **Command history** — arrow keys to recall previous commands
- **Partial matching** — abbreviate commands (e.g., `sh ver` for `show version`)
- **Flexible argument order** — `show interfaces terse ge-0/0/0` and `show interfaces ge-0/0/0 terse` both work

## Pipe Commands

Chain output through filters using `|`, just like on a Junos device:

```
show interfaces terse | match ge-0
show config | display set | save backup.conf
show interfaces | count
show route | except 0.0.0.0 | last 20
```

Available pipes: `no-more`, `save <file>`, `count`, `match <pattern>`, `except <pattern>`, `last <N>`, `find <pattern>`, `trim <N>`, `display set`

## CLI Options

```
rsi-cli <rsi-file>                      # interactive mode
rsi-cli <rsi-file> --no-pager           # disable paging
```

## Development

```bash
uv sync --dev
uv run pytest
uv run ruff check rsi/
uv run ruff format rsi/
```
