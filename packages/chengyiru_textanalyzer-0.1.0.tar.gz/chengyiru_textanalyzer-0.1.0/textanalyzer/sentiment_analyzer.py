# 导入VADER情感分析库（依赖已在配置文件中声明）
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

def analyze_sentiment(text: str) -> dict:
    """
    分析文本的情感倾向，返回情感得分字典。
    
    参数：
        text: 要分析的文本字符串
        
    返回：
        dict: 包含4个键的字典：
            - neg: 负向情感得分（0-1）
            - neu: 中性情感得分（0-1）
            - pos: 正向情感得分（0-1）
            - compound: 综合情感得分（-1到1，越正越积极）
    """
    # 初始化情感分析器
    analyzer = SentimentIntensityAnalyzer()
    # 计算情感得分
    sentiment_scores = analyzer.polarity_scores(text)
    return sentiment_scores

# 测试代码（可选，方便本地验证）
if __name__ == "__main__":
    test_text = "I love this product! It's amazing and works perfectly."
    result = analyze_sentiment(test_text)
    print("情感分析结果：", result)