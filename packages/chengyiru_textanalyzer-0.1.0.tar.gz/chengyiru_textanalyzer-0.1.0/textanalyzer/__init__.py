# 导出核心函数，方便外部导入
from .sentiment_analyzer import analyze_sentiment

# 声明导出的内容（规范写法）
__all__ = ["analyze_sentiment"]