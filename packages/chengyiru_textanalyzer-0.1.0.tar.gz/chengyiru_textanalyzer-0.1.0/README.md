\# textanalyzer

A simple Python package for text sentiment analysis using VADER.

