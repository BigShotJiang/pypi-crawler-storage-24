# QLeap

QLeap is a new quantum programming language developed by our team. The goal of QLeap is to fill the
role of a quantum programming language which is simple, readable, and easy to use. Our team designed QLeap with the intention that it is both accessible to newcomers and viable for professional and research applications. 

Quantum computers utilize quantum physics to perform operations that are impossible on
classical computers. With new capabilities, they need new programming languages. While several quantum programming languages already exist, such as Qiskit, QLeap focuses on ease of use over performance or synergy with a particular hardware design. QLeap is primarily based on Qiskit, and the backend of QLeap even runs it. However, QLeap is designed to beindependent, and its backend may migrate away from Qiskit in a future version. QLeap is not a standalone language, but packaged as a Python library. The code can be executed in two ways: simulating the result locally, or exporting to compiled code ready to run on a quantum machine.