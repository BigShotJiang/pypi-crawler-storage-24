"""Invisible, layered form protection for Django."""

__version__ = '0.8.0'
