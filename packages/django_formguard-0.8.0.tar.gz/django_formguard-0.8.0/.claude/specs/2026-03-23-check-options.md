# Per-form check options

## Why

Forms need per-check configuration without subclassing. An interstitial page
needs invisible Turnstile with auto-submit callback, while a signup form uses
visible Turnstile with defaults. Both use `TurnstileCheck` but need different
widget parameters.

## Approach

New `guard_check_options` form attribute passes per-check configuration that
overrides global settings. `BaseCheck.get_setting()` gains `self.options` as
the highest-priority lookup layer. No changes needed to individual checks
that already use `get_setting()`.

### Lookup priority

```
self.options[name] -> FORMGUARD_{PREFIX}_{NAME} -> self.defaults[name] -> ImproperlyConfigured
```

### Form API

```python
class InterstitialForm(GuardedFormMixin, forms.Form):
    guard_checks = [
        'formguard.contrib.turnstile.TurnstileCheck',
    ]
    guard_check_options = {
        'formguard.contrib.turnstile.TurnstileCheck': {
            'SIZE': 'invisible',
            'CALLBACK': 'onTurnstileComplete',
        },
    }
```

Option keys are uppercase, matching `get_setting()` names and `defaults` dict
keys (e.g. `SIZE`, not `size`).

### BaseCheck changes

```python
class BaseCheck:
    def __init__(self, options=None):
        self.options = options or {}

    def get_setting(self, name):
        if name in self.options:
            return self.options[name]
        # existing Django settings / defaults fallback
        ...
```

### resolve_checks changes

`resolve_checks()` accepts an optional `check_options` dict. When present,
it passes the matching options dict to each check's constructor:

```python
def resolve_checks(check_paths, check_options=None):
    checks = []
    for path in check_paths:
        cls = import_string(path)
        options = (check_options or {}).get(path, {})
        checks.append(cls(options=options))
    return checks
```

### GuardedFormMixin changes

`__init__` reads `self.guard_check_options` (default `None`) and passes it
through to `resolve_checks()`:

```python
if self.guard_checks is not None:
    self._checks = resolve_checks(self.guard_checks, self.guard_check_options)
else:
    self._checks = get_checks()
```

`guard_check_options` only applies when `guard_checks` is set on the form.
Global checks from settings don't receive per-form options (there's no form
to define them on).

### TurnstileWidget changes

Add `callback` parameter:

```python
class TurnstileWidget(forms.Widget):
    def __init__(self, site_key, theme='auto', size='normal', callback=None, attrs=None):
        self.callback = callback
        ...
```

Template renders `data-callback` only when set.

### TurnstileCheck changes

Add `CALLBACK` to defaults (None), read via `get_setting()`:

```python
defaults = {
    'THEME': 'auto',
    'SIZE': 'normal',
    'IP_HEADER': None,
    'TIMEOUT': 5,
    'CALLBACK': None,
}

def get_fields(self):
    callback = self.get_setting('CALLBACK')
    return {
        'cf-turnstile-response': CharField(
            required=False,
            widget=TurnstileWidget(
                site_key=self.get_setting('SITE_KEY'),
                theme=self.get_setting('THEME'),
                size=self.get_setting('SIZE'),
                callback=callback,
            ),
        ),
    }
```

## Testing

- `BaseCheck.__init__` stores options, defaults to empty dict
- `get_setting()` returns option value when present, falls back to settings
- `get_setting()` option overrides Django setting for the same name
- `resolve_checks()` passes options to check constructors
- `resolve_checks()` works without options (backward compatible)
- `GuardedFormMixin` reads `guard_check_options` and passes to resolve
- `guard_check_options` is None by default (no behavior change)
- `TurnstileWidget` renders data-callback when set, omits when None
- `TurnstileCheck` passes CALLBACK through to widget
- System checks still work (they instantiate checks without options)
- `GuardedFormTestMixin.guard_data()` works with check options
