# contrib/turnstile

Cloudflare Turnstile integration for formguard, shipped as `formguard.contrib.turnstile`.

## Why

The built-in checks are invisible and catch naive bots, but sophisticated bots can
bypass JS challenges and timing checks. Turnstile adds a Cloudflare-backed verification
layer that's hard to fake. It's the most-requested "next step" for forms that need
stronger protection (signups, payments, password resets).

## Approach

Standard `BaseCheck` subclass with a custom widget. No third-party dependencies --
server-side verification uses `urllib`. Implicit Turnstile rendering (Cloudflare's
script auto-discovers the widget div, no custom JS needed).

### File layout

```
formguard/contrib/
    __init__.py
    turnstile/
        __init__.py          # re-exports TurnstileCheck, TurnstileWidget
        checks.py            # TurnstileCheck, verify_token()
        widgets.py           # TurnstileWidget
        templates/formguard/contrib/turnstile/
            widget.html      # <div class="cf-turnstile" ...>
```

Dotted path: `formguard.contrib.turnstile.TurnstileCheck` (short, via __init__ re-export)
or `formguard.contrib.turnstile.checks.TurnstileCheck` (explicit).

## TurnstileCheck

```python
class TurnstileCheck(BaseCheck):
    fail_open = False
    message = _('Please complete the verification.')
    settings_prefix = 'TURNSTILE'
    defaults = {
        'THEME': 'auto',
        'SIZE': 'normal',
        'IP_HEADER': None,
    }
```

- `SITE_KEY` and `SECRET_KEY` have no defaults -- `get_setting()` raises
  `ImproperlyConfigured` if missing. No startup system check; runtime error is
  clear enough.
- `fail_open = False` -- CAPTCHA failure should block submission, not silently pass.

### Settings

| Setting | Default | Purpose |
|---|---|---|
| `FORMGUARD_TURNSTILE_SITE_KEY` | (required) | Cloudflare site key |
| `FORMGUARD_TURNSTILE_SECRET_KEY` | (required) | Cloudflare secret key |
| `FORMGUARD_TURNSTILE_THEME` | `'auto'` | Widget theme: `auto`, `light`, `dark` |
| `FORMGUARD_TURNSTILE_SIZE` | `'normal'` | Widget size: `normal`, `compact` |
| `FORMGUARD_TURNSTILE_IP_HEADER` | `None` | `request.META` key for client IP (e.g. `'HTTP_CF_CONNECTING_IP'`). `None` = don't send IP. If value contains commas, leftmost entry is used. |

### get_fields()

Returns `{'cf-turnstile-response': CharField(required=False, widget=TurnstileWidget(...))}`.

The field is `required=False` because Cloudflare's script populates a hidden input
with this name automatically. If JS doesn't run (bot), the field is empty, and
`check()` catches it.

### get_media()

Returns `Media(js=('https://challenges.cloudflare.com/turnstile/v0/api.js',))`.

External script, loaded via `{{ form.media }}` like any other check.

### check(form)

1. Read `cf-turnstile-response` from `cleaned_data`. If empty, return `'turnstile not completed'`.
2. Build IP value: if `IP_HEADER` is set, read from `form.request.META.get(header, '')`.
   If the value contains commas, take the leftmost (stripped) entry.
3. Call `verify_token(token, secret_key, ip)`.
4. If verification fails, return `'turnstile verification failed'`.
5. Return `False` (passed).

### verify_token(token, secret_key, ip=None)

Standalone function (clean test seam).

- POST to `https://challenges.cloudflare.com/turnstile/v0/siteverify` with
  `secret`, `response`, and optionally `remoteip`.
- Uses `urllib.request.urlopen` + `json.loads`. No third-party deps.
- Returns `bool` (response JSON `success` field).

### Test key bypass

If the secret key matches the Cloudflare test key pattern (starts with `1x-` or
`2x-` or `3x-`), skip the HTTP call and resolve locally:

- `1x-0000000000000000000000000000000AA` (always pass) -> return `True`
- `2x-0000000000000000000000000000000AA` (always fail) -> return `False`
- `3x-0000000000000000000000000000000AA` (force challenge, treated as fail for server-side) -> return `False`

This makes `guard_data()` work in test suites without network access or mocking,
as long as test settings use Cloudflare's published test keys.

### test_data()

Returns `{'cf-turnstile-response': 'test-token'}`. Works with test key bypass.

## TurnstileWidget

Subclass of `django.forms.Widget`. Renders via `formguard/contrib/turnstile/widget.html`.

Constructor receives `site_key`, `theme`, `size` from the check (which reads them
from settings). Template renders:

```html
<div class="cf-turnstile"
     data-sitekey="{{ widget.site_key }}"
     data-theme="{{ widget.theme }}"
     data-size="{{ widget.size }}">
</div>
```

No `<input>` element -- Cloudflare's script creates the hidden input with
name `cf-turnstile-response` automatically inside the div.

The widget's `value_from_datadict` reads `cf-turnstile-response` from POST data
(matching the name Cloudflare uses, not a Django-generated name).

## Error handling

- Missing/empty token: `'turnstile not completed'` (bot didn't run JS)
- Verification fails: `'turnstile verification failed'` (invalid/reused token)
- `urllib` exception: not caught (propagates, `fail_open = False` means `run_checks`
  logs it and returns a failure result with reason `'check error'`)
- Missing settings: `ImproperlyConfigured` at form instantiation time

## Testing strategy

### formguard's own tests

In `formguard/contrib/turnstile/tests/`:

- **Widget rendering** - correct `data-sitekey`, `data-theme`, `data-size` attrs
- **check() with empty token** - returns reason string
- **check() with test key bypass (pass)** - returns `False`
- **check() with test key bypass (fail)** - returns reason string
- **verify_token() real HTTP path** - mock `urllib.request.urlopen`, verify payload,
  test success/failure JSON responses
- **IP header extraction** - `None`, simple value, comma-separated (takes leftmost)
- **Missing settings** - `ImproperlyConfigured` raised
- **test_data() integration** - `guard_data()` produces passing data with test keys
- **get_media()** - includes Cloudflare script URL

### Consumer tests (foxtail etc.)

Configure test settings with Cloudflare test keys. `guard_data()` returns valid
data, the test key bypass skips HTTP, tests run fast and offline.

```python
# test settings
FORMGUARD_TURNSTILE_SITE_KEY = '1x-0000000000000000000000000000000AA'
FORMGUARD_TURNSTILE_SECRET_KEY = '1x-0000000000000000000000000000000AA'
```

No mocking needed in view tests.

## Documentation

- Add `docs/turnstile.md` covering setup (install, settings, registration),
  template rendering, test configuration, async usage, and customization
  (subclassing widget/check).
- Note on async views: `check()` makes a synchronous HTTP call. In async views,
  wrap with `sync_to_async` or use the check in a sync context. Document this
  as a known limitation for v1.
- Update README to mention Turnstile as a contrib check.
- Update `docs/custom-checks.md` to reference the real contrib module instead of
  the example sketch.
