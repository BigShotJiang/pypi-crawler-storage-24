import requests
from pathlib import Path

class DriveEditor:
    DEFAULT_BACKEND_URL = "https://drive-backend-api.onrender.com"

    def __init__(self, backend_url=None):
        self.backend_url = (backend_url or self.DEFAULT_BACKEND_URL).rstrip('/')

    def _request(self, method, endpoint, **kwargs):
        url = f"{self.backend_url}/{endpoint.lstrip('/')}"
        try:
            response = requests.request(method, url, **kwargs)
            response.raise_for_status()
            return response.json() if response.content else {}
        except requests.exceptions.RequestException as e:
            error_msg = str(e)
            if hasattr(e, 'response') and e.response is not None:
                try:
                    error_msg = e.response.json().get('error', error_msg)
                except:
                    pass
            raise Exception(f"Erro na requisição: {error_msg}")

    def _extract_filename(self, content_disposition):
        if not content_disposition:
            return None
        parts = content_disposition.split(';')
        for part in parts:
            part = part.strip()
            if part.startswith('filename='):
                value = part[9:].strip()
                if value.startswith('"') and value.endswith('"'):
                    value = value[1:-1]
                return value
            elif part.startswith('filename*='):
                value = part[10:].strip()
                if value.startswith("UTF-8''"):
                    value = value[7:]
                if value.startswith('"') and value.endswith('"'):
                    value = value[1:-1]
                return value
        return None

    def upload(self, arquivo_local, pasta_link, substituir=False):
        if not pasta_link:
            raise ValueError("❌ É obrigatório fornecer o link da pasta compartilhada.")
        with open(arquivo_local, 'rb') as f:
            files = {'file': (Path(arquivo_local).name, f)}
            data = {
                'pasta_link': pasta_link,
                'substituir': str(substituir).lower()
            }
            return self._request('POST', '/upload', files=files, data=data)

    def listar(self, pasta_link):
        if not pasta_link:
            raise ValueError("❌ É obrigatório fornecer o link da pasta.")
        return self._request('POST', '/list', json={'pasta_link': pasta_link}).get('files', [])

    def excluir(self, arquivo_link):
        if not arquivo_link:
            raise ValueError("❌ É obrigatório fornecer o link do arquivo.")
        self._request('POST', '/delete', json={'file_link': arquivo_link})
        return True

    def mover(self, arquivo_link, pasta_destino_link):
        if not arquivo_link or not pasta_destino_link:
            raise ValueError("❌ É obrigatório fornecer os links do arquivo e da pasta destino.")
        return self._request('POST', '/move', json={
            'file_link': arquivo_link,
            'destino_link': pasta_destino_link
        })

    def renomear(self, arquivo_link, novo_nome):
        if not arquivo_link or not novo_nome:
            raise ValueError("❌ É obrigatório fornecer o link e o novo nome.")
        return self._request('POST', '/rename', json={
            'file_link': arquivo_link,
            'novo_nome': novo_nome
        })

    def criar_pasta(self, nome_pasta, pasta_pai_link):
        """
        Cria uma nova pasta dentro de uma pasta compartilhada.
        O parâmetro pasta_pai_link é OBRIGATÓRIO.
        """
        if not nome_pasta:
            raise ValueError("❌ É obrigatório fornecer um nome para a pasta.")
        if not pasta_pai_link:
            raise ValueError("❌ É obrigatório fornecer o link da pasta onde a nova pasta será criada.")
        return self._request('POST', '/create_folder', json={
            'nome_pasta': nome_pasta,
            'pasta_pai_link': pasta_pai_link
        })

    def criar_arquivo_texto(self, nome_arquivo, conteudo, pasta_pai_link):
        """
        Cria um arquivo de texto dentro de uma pasta compartilhada.
        O parâmetro pasta_pai_link é OBRIGATÓRIO.
        """
        if not nome_arquivo:
            raise ValueError("❌ É obrigatório fornecer um nome para o arquivo.")
        if not pasta_pai_link:
            raise ValueError("❌ É obrigatório fornecer o link da pasta onde o arquivo será criado.")
        return self._request('POST', '/create_text_file', json={
            'nome_arquivo': nome_arquivo,
            'conteudo': conteudo,
            'pasta_pai_link': pasta_pai_link
        })

    def download(self, arquivo_link, destino_local=None):
        if not arquivo_link:
            raise ValueError("❌ É obrigatório fornecer o link do arquivo.")
        url = f"{self.backend_url}/download"
        response = requests.post(url, json={'file_link': arquivo_link}, stream=True)
        response.raise_for_status()

        filename = None
        content_disposition = response.headers.get('Content-Disposition')
        if content_disposition:
            filename = self._extract_filename(content_disposition)

        if not filename:
            content_type = response.headers.get('Content-Type', '')
            if 'application/zip' in content_type:
                filename = 'pasta.zip'
            else:
                filename = 'download.bin'

        if destino_local:
            final_path = destino_local
        else:
            final_path = filename

        with open(final_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        return final_path