"""Custom agent reference application."""
