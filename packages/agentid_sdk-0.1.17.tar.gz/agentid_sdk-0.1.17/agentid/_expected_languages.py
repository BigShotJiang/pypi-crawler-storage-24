from __future__ import annotations

from typing import Any, Optional


def normalize_expected_languages(value: Any) -> Optional[list[str]]:
    if not isinstance(value, list):
        return None

    normalized = list(
        dict.fromkeys(
            entry.strip()
            for entry in value
            if isinstance(entry, str) and entry.strip()
        )
    )
    return normalized or None
