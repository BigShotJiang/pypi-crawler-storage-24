"""
Public package surface for the dual-role CTFSolver project.

This package intentionally exposes a small framework-facing API for challenge
solution scripts:

- ``CTFSolver``
- ``ManagerFile``
- ``ManagerConnections``
- ``ManagerCrypto``

CLI workflows and optional analysis helpers live in their own modules under
``ctfsolver.cli`` and feature-specific packages such as ``ctfsolver.explain``
and ``ctfsolver.forensics``. They are not part of the default solution-script
inheritance surface.
"""

__all__ = [
    "CTFSolver",
    "ManagerConnections",
    "ManagerCrypto",
    "ManagerFile",
]


def __getattr__(name):
    if name == "CTFSolver":
        from .src.ctfsolver import CTFSolver

        return CTFSolver
    if name == "ManagerConnections":
        from ctfsolver.managers.manager_connections import ManagerConnections

        return ManagerConnections
    if name == "ManagerCrypto":
        from ctfsolver.managers.manager_crypto import ManagerCrypto

        return ManagerCrypto
    if name == "ManagerFile":
        from ctfsolver.managers.manager_file import ManagerFile

        return ManagerFile
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
