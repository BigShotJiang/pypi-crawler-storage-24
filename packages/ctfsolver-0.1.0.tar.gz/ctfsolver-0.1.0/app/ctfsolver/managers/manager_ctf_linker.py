from pathlib import Path

from ctfsolver.config.global_config import CONFIG
from ctfsolver.managers.manager_output import ManagerOutput


class ManagerCTFLinker:
    """
    Compare challenge folders against documentation entries and optionally create
    missing challenge folders for writeup-only matches.
    """

    def __init__(
        self,
        manager_file=None,
        workspace_manager=None,
        output_manager=None,
        ctf_path=None,
        documentation_path=None,
        exclude_folders=None,
    ):
        if manager_file is None:
            from ctfsolver.managers.manager_file import ManagerFile

            manager_file = ManagerFile()
        if workspace_manager is None:
            from ctfsolver.managers.manager_workspace import ManagerWorkspace

            workspace_manager = ManagerWorkspace()
        self.manager_file = manager_file
        self.workspace_manager = workspace_manager
        self.output = output_manager or ManagerOutput()
        directories = CONFIG.content.get("directories", {})
        self.ctf_path = self._resolve_path(
            ctf_path if ctf_path is not None else directories.get("ctf_data")
        )
        self.documentation_path = self._resolve_path(
            documentation_path
            if documentation_path is not None
            else directories.get("documentation")
        )
        self.exclude_folders = exclude_folders or directories.get("exclude", [])

    def _resolve_path(self, path_value):
        if path_value is None:
            return None
        path = Path(path_value)
        if path.is_absolute():
            return path
        return Path.home() / path

    def validate_paths(self):
        if self.ctf_path is None:
            raise ValueError("ctf_data directory is not configured.")
        if self.documentation_path is None:
            raise ValueError("documentation directory is not configured.")
        if not self.ctf_path.exists():
            raise FileNotFoundError(f"CTF path does not exist: {self.ctf_path}")
        if not self.documentation_path.exists():
            raise FileNotFoundError(
                f"Documentation path does not exist: {self.documentation_path}"
            )

    def collect_entries(self, path, folder=True):
        entries = {}
        _, categories, _ = self.manager_file.single_folder_search(
            path=path, exclude=self.exclude_folders
        )

        for category in categories:
            category_path = Path(path, category)
            _, sites, _ = self.manager_file.single_folder_search(
                path=category_path, exclude=self.exclude_folders
            )
            entries[category] = {}

            for site in sites:
                site_path = Path(category_path, site)
                _, challenge_dirs, challenge_files = self.manager_file.single_folder_search(
                    path=site_path, exclude=self.exclude_folders
                )
                entries[category][site] = challenge_dirs if folder else challenge_files

        return entries

    def cleanup_writeups(self, writeups, exclude=None):
        exclude = exclude or [
            "Aa_pics",
            "Events",
            "Learning",
            "Notes",
            "Resources",
            "Uncategorized",
            "ctflearn",
            "indexes",
            "youtube",
        ]
        cleaned = {}

        for category, sites in writeups.items():
            if category in exclude:
                continue
            cleaned[category] = {}
            for site, entries in sites.items():
                cleaned[category][site] = []
                for entry in entries:
                    suffix = Path(entry).suffix.lower()
                    if suffix in {".png", ".jpg", ".jpeg", ".gif"}:
                        continue
                    if suffix == ".md":
                        entry = Path(entry).stem
                    if entry != site:
                        cleaned[category][site].append(entry)
        return cleaned

    def _normalized_map(self, items):
        mapping = {}
        for item in items:
            normalized = self.manager_file.normalize_name(item)
            mapping.setdefault(normalized, item)
        return mapping

    def diff_entries(self, challenges, writeups):
        diffs = {}
        categories = set(challenges.keys()).union(writeups.keys())

        for category in categories:
            site_diffs = {}
            sites = set(challenges.get(category, {}).keys()).union(
                writeups.get(category, {}).keys()
            )
            for site in sites:
                challenge_map = self._normalized_map(
                    challenges.get(category, {}).get(site, [])
                )
                writeup_map = self._normalized_map(writeups.get(category, {}).get(site, []))
                current_diffs = []

                for normalized, raw_name in challenge_map.items():
                    if normalized not in writeup_map:
                        current_diffs.append({"name": raw_name, "source": "challenge"})

                for normalized, raw_name in writeup_map.items():
                    if normalized not in challenge_map:
                        current_diffs.append({"name": raw_name, "source": "writeup"})

                if current_diffs:
                    site_diffs[site] = sorted(
                        current_diffs, key=lambda item: (item["source"], item["name"])
                    )

            if site_diffs:
                diffs[category] = site_diffs

        return diffs

    def create_missing_challenge_folders(self, diffs, verbose=False):
        created = []
        for category, sites in diffs.items():
            for site, items in sites.items():
                for item in items:
                    if item["source"] != "writeup":
                        continue
                    self.workspace_manager.create_ctf_structure(
                        category,
                        site,
                        item["name"],
                        verbose=verbose,
                        download=False,
                        checker=False,
                    )
                    created.append(
                        {"category": category, "site": site, "name": item["name"]}
                    )
        return created

    def count_differences(self, diffs):
        """
        Counts the flattened number of linking differences across all categories
        and sites.
        """
        return sum(len(items) for sites in diffs.values() for items in sites.values())

    def build_summary_text(self, result, include_details=False):
        """
        Builds a stable plain-text summary for the linking workflow.

        Args:
            result: Linker result dictionary returned by `link(...)`.
            include_details: When `True`, includes one line per difference.

        Returns:
            Plain-text summary suitable for CLI output or test assertions.
        """
        lines = [
            self.output.format_kv(
                {
                    "Differences": self.count_differences(result["diffs"]),
                    "Created folders": len(result["created"]),
                }
            )
        ]

        if include_details and result["diffs"]:
            detail_rows = []
            for category, sites in sorted(result["diffs"].items()):
                for site, items in sorted(sites.items()):
                    for item in items:
                        detail_rows.append(
                            [category, site, item["name"], item["source"]]
                        )
            lines.append("")
            lines.append(self.output.format_section("Link Differences", [
                self.output.format_table(
                    detail_rows,
                    headers=["Category", "Site", "Name", "Source"],
                )
            ]))

        if result["created"]:
            created_rows = [
                [item["category"], item["site"], item["name"]]
                for item in result["created"]
            ]
            lines.append("")
            lines.append(self.output.format_section("Created Folders", [
                self.output.format_table(
                    created_rows,
                    headers=["Category", "Site", "Name"],
                )
            ]))

        return "\n".join(line for line in lines if line)

    def link(self, create_missing=False, verbose=False):
        self.validate_paths()
        challenges = self.collect_entries(self.ctf_path, folder=True)
        writeups = self.cleanup_writeups(
            self.collect_entries(self.documentation_path, folder=False)
        )
        diffs = self.diff_entries(challenges, writeups)
        created = []
        if create_missing:
            created = self.create_missing_challenge_folders(diffs, verbose=verbose)
        return {"diffs": diffs, "created": created}
