"""
Reusable binary, pwn, and reverse-engineering helpers for the runtime surface.

The helpers in this module intentionally stay generic: they provide binary
triage, ELF/pwntools conveniences, lightweight reverse-oriented scanning, and
optional external-tool wrappers without turning the runtime layer into a
challenge-specific exploit framework.
"""

from __future__ import annotations

import importlib
import re
from pathlib import Path

from ctfsolver.managers.manager_output import ManagerOutput
from ctfsolver.managers.manager_tools import ManagerTools


class ManagerBinary(ManagerTools):
    """
    Provides optional binary-analysis and exploit-building conveniences for
    pwn, binary, and reverse-engineering challenges.

    The manager is runtime-friendly but dependency-gated. It imports pwntools,
    Capstone, and other heavy analysis layers lazily so the base `CTFSolver`
    class still imports cleanly in environments where those packages are
    unavailable.
    """

    SYS_CALL_PATTERNS = {
        "x86_64_syscall": b"\x0f\x05",
        "x86_int80": b"\xcd\x80",
        "arm_svc": b"\x00\x00\x00\xef",
        "aarch64_svc": b"\x01\x00\x00\xd4",
    }

    def __init__(self, *args, **kwargs):
        """
        Initializes the binary helper layer with the shared output manager.
        """
        self.output = kwargs.get("output_manager", None) or ManagerOutput()

    def initializing_all_ancestors(self, *args, **kwargs):
        """
        Placeholder kept for compatibility with the rest of the manager stack.
        """
        return None

    def file_magic(self, path) -> str:
        """
        Detect the broad binary family from the file magic header.

        Args:
            path: Binary path or path-like object.

        Returns:
            A coarse file type such as `ELF`, `PE`, `Mach-O`, or `unknown`.
        """
        blob = self._read_blob(path)[:8]
        if blob.startswith(b"\x7fELF"):
            return "ELF"
        if blob.startswith(b"MZ"):
            return "PE"
        if blob[:4] in (
            b"\xfe\xed\xfa\xce",
            b"\xfe\xed\xfa\xcf",
            b"\xce\xfa\xed\xfe",
            b"\xcf\xfa\xed\xfe",
        ):
            return "Mach-O"
        if blob.startswith(b"#!"):
            return "script"
        return "unknown"

    def detect_arch(self, path) -> str:
        """
        Detect the target architecture using lightweight header parsing.
        """
        blob = self._read_blob(path)
        file_type = self.file_magic(path)
        if file_type == "ELF" and len(blob) >= 20:
            machine = int.from_bytes(blob[18:20], "little")
            return {
                0x03: "x86",
                0x3E: "x86_64",
                0x28: "arm",
                0xB7: "aarch64",
                0x08: "mips",
                0xF3: "riscv",
            }.get(machine, f"elf_machine_{machine}")
        if file_type == "PE" and len(blob) >= 0x40:
            pe_offset = int.from_bytes(blob[0x3C:0x40], "little")
            if len(blob) >= pe_offset + 6:
                machine = int.from_bytes(blob[pe_offset + 4 : pe_offset + 6], "little")
                return {
                    0x14C: "x86",
                    0x8664: "x86_64",
                    0x1C0: "arm",
                    0xAA64: "aarch64",
                }.get(machine, f"pe_machine_{machine}")
        return "unknown"

    def detect_linking(self, path) -> str:
        """
        Best-effort linking classification for a binary.
        """
        file_type = self.file_magic(path)
        blob = self._read_blob(path)
        if file_type != "ELF":
            return file_type.lower()
        if b".interp" in blob or b"ld-linux" in blob or b"libc.so" in blob:
            return "dynamic"
        return "static"

    def binary_info(self, path) -> dict:
        """
        Return stable binary metadata useful during first-pass triage.
        """
        resolved = self._to_path(path)
        return {
            "path": resolved,
            "size": resolved.stat().st_size,
            "sha256": self.sha256_file(resolved),
            "type": self.file_magic(resolved),
            "arch": self.detect_arch(resolved),
            "linking": self.detect_linking(resolved),
        }

    def elf_load(self, path, **kwargs):
        """
        Load an ELF with pwntools.

        Raises:
            ModuleNotFoundError: If pwntools is not installed.
            ValueError: If the target is not an ELF file.
        """
        resolved = self._to_path(path)
        if self.file_magic(resolved) != "ELF":
            raise ValueError(f"Not an ELF binary: {resolved}")
        pwn = self._require_pwn()
        try:
            return pwn.ELF(resolved.as_posix(), **kwargs)
        except TypeError:
            return pwn.ELF(resolved.as_posix())

    def elf_symbols(self, path) -> dict:
        """
        Return the pwntools ELF symbol table as a plain dictionary.
        """
        return dict(self.elf_load(path).symbols)

    def elf_got(self, path) -> dict:
        """
        Return the Global Offset Table entries when pwntools can resolve them.
        """
        return dict(getattr(self.elf_load(path), "got", {}))

    def elf_plt(self, path) -> dict:
        """
        Return the Procedure Linkage Table entries when pwntools can resolve them.
        """
        return dict(getattr(self.elf_load(path), "plt", {}))

    def elf_sections(self, path) -> list[str]:
        """
        Return ELF section names when pwntools exposes them.
        """
        elf = self.elf_load(path)
        sections = getattr(elf, "sections", None)
        if sections is None:
            return []
        output = []
        for section in sections:
            name = getattr(section, "name", None)
            if name is not None:
                output.append(name)
        return output

    def elf_strings(self, path, min_length=4) -> list[str]:
        """
        Alias the generic strings helper under a binary-oriented name.
        """
        return self.strings(path, min_length=min_length)

    def elf_checksec(self, path):
        """
        Return pwntools `checksec` information when available.
        """
        elf = self.elf_load(path)
        checksec = getattr(elf, "checksec", None)
        if callable(checksec):
            return checksec()
        return {}

    def resolve_symbol(self, path, name):
        """
        Resolve a named symbol from an ELF.
        """
        return self.elf_symbols(path).get(name)

    def rop_load(self, path, libc=None):
        """
        Construct a pwntools ROP object from an ELF and optional libc.
        """
        pwn = self._require_pwn()
        binaries = [self.elf_load(path)]
        if libc is not None:
            binaries.append(self.elf_load(libc))
        return pwn.ROP(binaries)

    def rop_find_gadget(self, path, gadgets, libc=None):
        """
        Locate a gadget sequence with pwntools ROP.
        """
        return self.rop_load(path, libc=libc).find_gadget(list(gadgets))

    def cyclic_find_value(self, value, n=4):
        """
        Locate an offset in a cyclic pattern.
        """
        try:
            pwn = self._require_pwn()
            return pwn.cyclic_find(value, n=n)
        except ModuleNotFoundError:
            raise

    def pack_ptr(self, value, bits=64, endian="little") -> bytes:
        """
        Pack an integer pointer-sized value into raw bytes.
        """
        if bits not in (32, 64):
            raise ValueError("bits must be 32 or 64")
        return int(value).to_bytes(bits // 8, endian, signed=False)

    def unpack_ptr(self, data, bits=64, endian="little") -> int:
        """
        Unpack raw pointer-sized bytes into an integer.
        """
        width = bits // 8
        blob = self._to_bytes(data)
        if len(blob) < width:
            raise ValueError("Not enough data to unpack pointer")
        return int.from_bytes(blob[:width], endian, signed=False)

    def leak_to_libc_base(self, leak, symbol_offset) -> int:
        """
        Convert a leaked address to a likely base address by subtracting a known symbol offset.
        """
        return int(leak) - int(symbol_offset)

    def format_write_payload(self, offset, writes, bits=64, **kwargs):
        """
        Build a format-string write payload using pwntools.
        """
        pwn = self._require_pwn()
        return pwn.fmtstr_payload(offset, writes, write_size="short" if bits == 64 else "byte", **kwargs)

    def triage_binary(self, path) -> dict:
        """
        Alias of `binary_recon` kept for challenge-style first-pass workflows.
        """
        return self.binary_recon(path)

    def binary_recon(self, path, string_limit=20) -> dict:
        """
        Run a broad first-pass binary triage pass.
        """
        resolved = self._to_path(path)
        info = self.binary_info(resolved)
        strings_found = self.elf_strings(resolved, min_length=4)
        suspicious = [
            item
            for item in strings_found
            if re.search(r"(flag|win|system|/bin/sh|gets|strcpy|password|secret)", item, re.I)
        ]
        imports = self.list_imports(resolved)
        exports = self.list_exports(resolved)
        return {
            **info,
            "checksec": self._best_effort(self.elf_checksec, resolved, default={}),
            "imports": imports[:25],
            "exports": exports[:25],
            "suspicious_strings": suspicious[:string_limit],
            "main_like_symbols": self._best_effort(
                self.find_main_like_symbols, resolved, default=[]
            ),
            "rwx_segments": self._best_effort(self.find_rwx_segments, resolved, default=[]),
        }

    def build_binary_recon_text(self, recon: dict) -> str:
        """
        Render `binary_recon` output as deterministic plain text.
        """
        sections = [
            self.output.format_kv(
                {
                    "Path": recon.get("path"),
                    "Type": recon.get("type"),
                    "Arch": recon.get("arch"),
                    "Linking": recon.get("linking"),
                    "Size": recon.get("size"),
                    "SHA256": recon.get("sha256"),
                },
                title="Binary Recon",
            ),
            self.output.format_list(recon.get("imports", []), title="Imports"),
            self.output.format_list(recon.get("exports", []), title="Exports"),
            self.output.format_list(
                recon.get("suspicious_strings", []), title="Suspicious Strings"
            ),
            self.output.format_list(
                recon.get("main_like_symbols", []), title="Main-Like Symbols"
            ),
        ]
        if recon.get("checksec"):
            sections.append(
                self.output.format_kv(recon.get("checksec"), title="Checksec")
            )
        return "\n\n".join(sections)

    def list_imports(self, path) -> list[str]:
        """
        Best-effort list of imported symbols.
        """
        try:
            got = self.elf_got(path)
            return sorted(got.keys())
        except Exception:
            return []

    def list_exports(self, path) -> list[str]:
        """
        Best-effort list of exported or known symbols.
        """
        try:
            return sorted(self.elf_symbols(path).keys())
        except Exception:
            return []

    def find_rwx_segments(self, path) -> list[dict]:
        """
        Identify ELF segments that appear readable, writable, and executable.
        """
        elf = self.elf_load(path)
        output = []
        for segment in getattr(elf, "segments", []):
            header = getattr(segment, "header", segment)
            flags = getattr(header, "p_flags", None)
            if flags is None:
                continue
            if flags & 0x1 and flags & 0x2 and flags & 0x4:
                output.append(
                    {
                        "vaddr": getattr(header, "p_vaddr", None),
                        "memsz": getattr(header, "p_memsz", None),
                        "flags": flags,
                    }
                )
        return output

    def disasm_bytes(self, data, arch="x86_64", mode=None, address=0) -> list[dict]:
        """
        Disassemble raw bytes using Capstone when available.
        """
        capstone = self._require_capstone()
        arch_value, mode_value = self._capstone_arch_mode(capstone, arch, mode)
        disassembler = capstone.Cs(arch_value, mode_value)
        output = []
        for instruction in disassembler.disasm(self._to_bytes(data), address):
            output.append(
                {
                    "address": instruction.address,
                    "size": instruction.size,
                    "mnemonic": instruction.mnemonic,
                    "op_str": instruction.op_str,
                    "bytes": bytes(instruction.bytes),
                }
            )
        return output

    def find_opcode_patterns(self, path, patterns) -> list[dict]:
        """
        Search a binary blob for raw opcode or byte-string patterns.
        """
        blob = self._read_blob(path)
        output = []
        for pattern in patterns:
            needle = self._normalize_pattern(pattern)
            start = 0
            offsets = []
            while True:
                index = blob.find(needle, start)
                if index < 0:
                    break
                offsets.append(index)
                start = index + 1
            output.append({"pattern": pattern, "offsets": offsets})
        return output

    def extract_immediates(self, path, width=4, signed=False, limit=None) -> list[dict]:
        """
        Extract fixed-width immediates by sliding across the binary blob.
        """
        blob = self._read_blob(path)
        if width <= 0:
            raise ValueError("width must be positive")
        results = []
        for offset in range(0, max(len(blob) - width + 1, 0)):
            chunk = blob[offset : offset + width]
            value = int.from_bytes(chunk, "little", signed=signed)
            results.append({"offset": offset, "value": value, "bytes": chunk})
            if limit is not None and len(results) >= limit:
                break
        return results

    def extract_xrefs_strings(self, path, strings_only=True, min_length=4, limit=None):
        """
        Return string-offset pairs from a binary as a lightweight reverse helper.

        This is intentionally a low-fidelity replacement for richer xref tooling.
        It exposes string locations that a reverser would often inspect first.
        """
        blob = self._read_blob(path)
        matches = list(re.finditer(rb"[ -~]{%d,}" % min_length, blob))
        records = [
            {
                "offset": match.start(),
                "string": match.group().decode("utf-8", errors="ignore"),
            }
            for match in matches
        ]
        if limit is not None:
            records = records[:limit]
        if strings_only:
            return [record["string"] for record in records]
        return records

    def demangle_symbol(self, name) -> str:
        """
        Best-effort demangling using `c++filt` or `cxxfilt` when available.
        """
        if self.tool_exists("c++filt"):
            result = self.run_cmd(["c++filt", str(name)], capture=True, text=True, check=False)
            if result.returncode == 0 and result.stdout:
                return result.stdout.strip()
        try:
            cxxfilt = importlib.import_module("cxxfilt")
            return cxxfilt.demangle(str(name))
        except ModuleNotFoundError:
            return str(name)

    def find_main_like_symbols(self, path) -> list[str]:
        """
        Return symbol names that look like likely program entrypoints or win paths.
        """
        names = self.list_exports(path)
        pattern = re.compile(r"(?:^main$|_start|win|vuln|entry|init)", re.I)
        return [name for name in names if pattern.search(name)]

    def scan_for_syscalls(self, path) -> list[dict]:
        """
        Search for common syscall opcode sequences in the binary.
        """
        blob = self._read_blob(path)
        output = []
        for name, needle in self.SYS_CALL_PATTERNS.items():
            start = 0
            while True:
                index = blob.find(needle, start)
                if index < 0:
                    break
                output.append({"kind": name, "offset": index})
                start = index + 1
        return output

    def has_gdb(self) -> bool:
        return self.tool_exists("gdb")

    def has_gdb_peda(self, peda_path=None) -> bool:
        """
        Return whether GDB and a plausible PEDA script path are both available.
        """
        return self.has_gdb() and self._resolve_peda_path(peda_path) is not None

    def has_rizin(self) -> bool:
        return self.tool_exists("rizin")

    def has_radare2(self) -> bool:
        return self.tool_exists("radare2") or self.tool_exists("r2")

    def has_objdump(self) -> bool:
        return self.tool_exists("objdump")

    def run_objdump(self, path, args=None):
        """
        Run `objdump` against a binary.
        """
        if not self.has_objdump():
            raise FileNotFoundError("objdump is not installed or not available on PATH.")
        return self.run_cmd(["objdump", *(args or []), self._to_path(path).as_posix()])

    def run_readelf(self, path, args=None):
        """
        Run `readelf` against a binary.
        """
        if not self.tool_exists("readelf"):
            raise FileNotFoundError("readelf is not installed or not available on PATH.")
        return self.run_cmd(["readelf", *(args or []), self._to_path(path).as_posix()])

    def run_rizin(self, path, commands):
        """
        Run `rizin` in quiet scripted mode.
        """
        if not self.has_rizin():
            raise FileNotFoundError("rizin is not installed or not available on PATH.")
        command_text = ";".join(commands)
        return self.run_cmd(["rizin", "-q", "-c", command_text, self._to_path(path).as_posix()])

    def run_gdb_batch(self, path, commands, gdbinit=None):
        """
        Run GDB in batch mode with a command list.
        """
        if not self.has_gdb():
            raise FileNotFoundError("gdb is not installed or not available on PATH.")
        argv = ["gdb", "-q", "-batch"]
        if gdbinit is not None:
            argv.extend(["-x", str(gdbinit)])
        for command in commands:
            argv.extend(["-ex", str(command)])
        argv.append(self._to_path(path).as_posix())
        return self.run_cmd(argv)

    def run_gdb_peda(self, path, commands, peda_path=None):
        """
        Run GDB with PEDA sourced before executing the provided commands.
        """
        resolved_peda = self._resolve_peda_path(peda_path)
        if resolved_peda is None:
            raise FileNotFoundError("Could not find a gdb-peda script path.")
        return self.run_gdb_batch(
            path,
            [f"source {resolved_peda.as_posix()}", *commands],
        )

    def gdb_break_and_run(self, path, breakpoints=None, commands=None, peda=False, peda_path=None):
        """
        Run GDB or GDB-PEDA with breakpoints followed by `run`.
        """
        command_list = [f"break {bp}" for bp in (breakpoints or [])]
        command_list.append("run")
        command_list.extend(commands or [])
        if peda:
            return self.run_gdb_peda(path, command_list, peda_path=peda_path)
        return self.run_gdb_batch(path, command_list)

    def gdb_peda_pattern_offset(self, path, value, peda_path=None):
        """
        Ask GDB-PEDA to resolve a cyclic pattern offset.
        """
        return self.run_gdb_peda(path, [f"pattern_offset {value}"], peda_path=peda_path)

    def gdb_peda_checksec(self, path, peda_path=None):
        """
        Ask GDB-PEDA to run its `checksec` helper.
        """
        return self.run_gdb_peda(path, ["checksec"], peda_path=peda_path)

    def _to_path(self, path) -> Path:
        return Path(path).expanduser().resolve()

    def _read_blob(self, path) -> bytes:
        return self._to_path(path).read_bytes()

    def _to_bytes(self, data) -> bytes:
        if isinstance(data, bytes):
            return data
        if isinstance(data, bytearray):
            return bytes(data)
        if isinstance(data, str):
            return data.encode()
        return bytes(data)

    def _normalize_pattern(self, pattern) -> bytes:
        if isinstance(pattern, bytes):
            return pattern
        if isinstance(pattern, str):
            compact = pattern.replace(" ", "")
            if compact and len(compact) % 2 == 0 and re.fullmatch(r"[0-9a-fA-F]+", compact):
                return bytes.fromhex(compact)
            return pattern.encode()
        raise TypeError("pattern must be bytes or str")

    def _require_pwn(self):
        try:
            return importlib.import_module("pwn")
        except ModuleNotFoundError as exc:
            raise ModuleNotFoundError(
                "pwntools is required for binary exploitation helpers."
            ) from exc

    def _require_capstone(self):
        try:
            return importlib.import_module("capstone")
        except ModuleNotFoundError as exc:
            raise ModuleNotFoundError(
                "capstone is required for disassembly helpers."
            ) from exc

    def _capstone_arch_mode(self, capstone, arch, mode):
        if mode is not None:
            return arch, mode
        mapping = {
            "x86_64": (capstone.CS_ARCH_X86, capstone.CS_MODE_64),
            "x86": (capstone.CS_ARCH_X86, capstone.CS_MODE_32),
            "i386": (capstone.CS_ARCH_X86, capstone.CS_MODE_32),
            "arm": (capstone.CS_ARCH_ARM, capstone.CS_MODE_ARM),
            "aarch64": (capstone.CS_ARCH_ARM64, capstone.CS_MODE_ARM),
        }
        try:
            return mapping[arch]
        except KeyError as exc:
            raise ValueError(f"Unsupported architecture for disassembly: {arch}") from exc

    def _resolve_peda_path(self, peda_path=None):
        candidates = []
        if peda_path is not None:
            candidates.append(Path(peda_path).expanduser())
        candidates.extend(
            [
                Path.home() / "peda" / "peda.py",
                Path.home() / "gdb-peda" / "peda.py",
                Path.home() / ".local" / "share" / "peda" / "peda.py",
            ]
        )
        for candidate in candidates:
            if candidate.exists():
                return candidate.resolve()
        return None

    def _best_effort(self, function, *args, default=None, **kwargs):
        try:
            return function(*args, **kwargs)
        except Exception:
            return default
