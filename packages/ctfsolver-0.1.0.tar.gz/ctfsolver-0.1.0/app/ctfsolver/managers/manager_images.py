"""
Image and stego helpers for the runtime file surface.
"""

from pathlib import Path

try:
    from PIL import Image
except ModuleNotFoundError:
    Image = None


class ManagerImages:
    """
    Provides Pillow-backed image inspection and reconstruction helpers.
    """

    def image_open(self, file):
        """
        Opens an image file through Pillow.

        Raises:
            ModuleNotFoundError: If Pillow is not installed.
        """
        if Image is None:
            raise ModuleNotFoundError(
                "Pillow is required for image helpers. Install PIL or avoid image helpers."
            )
        return Image.open(file)

    def image_dimensions(self, file) -> tuple[int, int]:
        """
        Returns `(width, height)` for an image.
        """
        with self.image_open(file) as image:
            return image.size

    def image_pixels(self, file):
        """
        Returns the pixel data of an image as a plain list.
        """
        with self.image_open(file) as image:
            return list(image.getdata())

    def extract_lsb_bytes(self, file, channels=("r", "g", "b"), bit=0) -> bytes:
        """
        Extracts least-significant-bit data from image channels and returns the
        reconstructed byte stream.

        Raises:
            ValueError: If `bit` is outside the 0-7 range.
        """
        if bit < 0 or bit > 7:
            raise ValueError("bit must be between 0 and 7")

        channel_map = {"r": 0, "g": 1, "b": 2, "a": 3}
        indices = [channel_map[channel.lower()] for channel in channels]
        bits = []

        with self.image_open(file) as image:
            normalized = image.convert("RGBA")
            for pixel in normalized.getdata():
                for index in indices:
                    bits.append((pixel[index] >> bit) & 1)

        output = bytearray()
        for offset in range(0, len(bits) - 7, 8):
            chunk = bits[offset : offset + 8]
            value = 0
            for current_bit in chunk:
                value = (value << 1) | current_bit
            output.append(value)

        return bytes(output)

    def save_rebuilt_image(self, file, pixels, size, mode="RGB"):
        """
        Creates a new image from raw pixel data and writes it to disk.
        """
        if Image is None:
            raise ModuleNotFoundError(
                "Pillow is required for image helpers. Install PIL or avoid image helpers."
            )

        image = Image.new(mode, size)
        image.putdata(list(pixels))
        target = Path(file)
        image.save(target)
        return target
