"""
Shared output and formatting helpers for runtime-adjacent workflows.

The project currently mixes `print(...)`, `typer.echo(...)`, and manual string
assembly. This manager introduces a small, dependency-light output layer that
can be reused by service managers and CLI adapters without forcing the whole
project onto a heavier logging or TUI framework.
"""


class ManagerOutput:
    """
    Centralizes verbosity-aware text emission and plain-text formatting.

    The class is intentionally lightweight. It focuses on deterministic output
    suitable for tests, markdown generation, and CLI summaries, while keeping
    room for future file-backed logging or richer styling if the project grows
    into that need.
    """

    STYLE_PREFIXES = {
        "debug": "[debug] ",
        "info": "",
        "warn": "[warn] ",
        "error": "[error] ",
        "success": "[ok] ",
    }

    def __init__(self, *args, **kwargs):
        """
        Initializes the output manager with a numeric verbosity level.

        Args:
            verbosity: Numeric verbosity level. `0` is quiet, `1` is normal,
                `2` is verbose, and `3` is debug-oriented output.
            sink: Optional callable used to emit strings. Defaults to `print`.
        """
        self.verbosity = int(kwargs.get("verbosity", 1))
        self.sink = kwargs.get("sink", print)

    def set_verbosity(self, level: int):
        """
        Updates the stored verbosity level and returns it for fluent use in
        call sites that configure output behavior dynamically.
        """
        self.verbosity = int(level)
        return self.verbosity

    def is_verbose(self, level=1) -> bool:
        """
        Returns whether the current output configuration should emit a message
        at the requested verbosity level.
        """
        return self.verbosity >= int(level)

    def emit(self, message, level=1, style=None):
        """
        Emits a formatted message if the requested verbosity level is enabled.

        Args:
            message: Text payload to emit.
            level: Minimum verbosity level required for emission.
            style: Optional style key such as `debug`, `warn`, or `success`.

        Returns:
            The rendered message when emitted, otherwise `None`.
        """
        if not self.is_verbose(level):
            return None
        prefix = self.STYLE_PREFIXES.get(style, "")
        rendered = f"{prefix}{message}"
        self.sink(rendered)
        return rendered

    def info(self, message, level=1):
        """
        Emits a normal informational message.
        """
        return self.emit(message, level=level, style="info")

    def debug(self, message, level=3):
        """
        Emits a debug-oriented message gated behind a higher verbosity level.
        """
        return self.emit(message, level=level, style="debug")

    def warn(self, message, level=1):
        """
        Emits a warning-style message.
        """
        return self.emit(message, level=level, style="warn")

    def error(self, message, level=0):
        """
        Emits an error-style message even in quiet mode unless the sink is
        replaced by the caller with custom behavior.
        """
        return self.emit(message, level=level, style="error")

    def success(self, message, level=1):
        """
        Emits a success-style message.
        """
        return self.emit(message, level=level, style="success")

    def format_section(self, title, lines):
        """
        Formats a titled section as a plain-text block.
        """
        normalized = [str(line) for line in lines]
        output = [str(title)]
        if normalized:
            output.append("-" * len(str(title)))
            output.extend(normalized)
        return "\n".join(output)

    def format_list(self, items, title=None, bullet="- "):
        """
        Formats a sequence as a bullet list, optionally prefixed by a title.
        """
        output = []
        if title is not None:
            output.append(str(title))
        values = list(items)
        if values:
            output.extend(f"{bullet}{item}" for item in values)
        else:
            output.append(f"{bullet}None")
        return "\n".join(output)

    def format_kv(self, mapping, title=None):
        """
        Formats a mapping as aligned `key: value` lines.
        """
        output = []
        if title is not None:
            output.append(str(title))
        if not mapping:
            output.append("- None")
            return "\n".join(output)

        width = max(len(str(key)) for key in mapping.keys())
        output.extend(f"- {str(key).ljust(width)} : {value}" for key, value in mapping.items())
        return "\n".join(output)

    def format_table(self, rows, headers=None):
        """
        Formats rows as a deterministic plain-text table.

        Args:
            rows: Iterable of row iterables.
            headers: Optional iterable of header labels.

        Returns:
            A plain-text table string.
        """
        normalized_rows = [list(map(str, row)) for row in rows]
        normalized_headers = list(map(str, headers)) if headers is not None else None

        if normalized_headers is None and not normalized_rows:
            return "(empty)"

        width_source = []
        if normalized_headers is not None:
            width_source.append(normalized_headers)
        width_source.extend(normalized_rows)

        column_count = max(len(row) for row in width_source)
        widths = [0] * column_count
        for row in width_source:
            for index in range(column_count):
                value = row[index] if index < len(row) else ""
                widths[index] = max(widths[index], len(value))

        def render_row(row):
            padded = []
            for index in range(column_count):
                value = row[index] if index < len(row) else ""
                padded.append(value.ljust(widths[index]))
            return " | ".join(padded)

        lines = []
        if normalized_headers is not None:
            lines.append(render_row(normalized_headers))
            lines.append("-+-".join("-" * width for width in widths))

        for row in normalized_rows:
            lines.append(render_row(row))

        return "\n".join(lines) if lines else "(empty)"
