import re
import unicodedata

from pathlib import Path

from ctfsolver.config.global_config import CONFIG
from ctfsolver.managers.manager_output import ManagerOutput


class ManagerCTFCreator:
    """
    Encapsulate challenge creation workflow while keeping the project class-oriented.

    The creator always provisions the challenge folder structure under the
    configured CTF root. Optional writeup-document creation is controlled by
    the ``doc_creation_check`` flag:

    - ``doc_creation_check=False``: create only the challenge folders
    - ``doc_creation_check=True``: create the challenge folders and the markdown document
    """

    def __init__(
        self,
        manager_file=None,
        workspace_manager=None,
        ctf_root=None,
        documentation_root=None,
        output_manager=None,
    ):
        if manager_file is None:
            from ctfsolver.managers.manager_file import ManagerFile

            manager_file = ManagerFile()
        if workspace_manager is None:
            from ctfsolver.managers.manager_workspace import ManagerWorkspace

            workspace_manager = ManagerWorkspace()
        self.manager_file = manager_file
        self.workspace_manager = workspace_manager
        directories = CONFIG.content.get("directories", {})
        self.ctf_root = self._resolve_root(
            ctf_root if ctf_root is not None else directories.get("ctf_data")
        )
        self.documentation_root = self._resolve_root(
            documentation_root
            if documentation_root is not None
            else directories.get("documentation")
        )
        self.output = output_manager or ManagerOutput()

    def create(
        self,
        category,
        site,
        name,
        doc_creation_check=False,
        download=False,
        verbose=False,
    ):
        """
        Create the challenge workspace and optionally its paired document.

        Args:
            category: Challenge category directory.
            site: Event or platform directory inside the category.
            name: User-facing challenge name.
            doc_creation_check: When true, also create the documentation markdown file.
            download: When true, run the download automove workflow after
                creating the folder structure.
            verbose: Forwarded to workspace creation helpers.

        Returns:
            A summary dictionary describing the created workspace and optional
            document path. ``document_path`` is ``None`` when ``doc_creation_check`` is
            disabled.
        """
        folder_name = self.normalize_folder_name(name)
        document_name = self.normalize_document_name(name)
        self.workspace_manager.create_ctf_structure(
            category,
            site,
            folder_name,
            download=download,
            verbose=verbose,
        )
        challenge_path = self.get_challenge_path(category, site, folder_name)
        document_path = None
        if doc_creation_check:
            document_path = self.create_document(category, site, document_name, name)
        return {
            "category": category,
            "site": site,
            "name": name,
            "folder_name": folder_name,
            "document_name": document_name,
            "path": challenge_path,
            "document_path": document_path,
            "download": download,
            "doc_creation_check": doc_creation_check,
        }

    def _resolve_root(self, root_value):
        if root_value is None:
            return None
        root = Path(root_value)
        if root.is_absolute():
            return root
        return Path.home() / root

    def normalize_folder_name(self, name):
        normalized = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode(
            "ascii"
        )
        normalized = normalized.replace(" ", "_")
        normalized = re.sub(r"[^A-Za-z0-9._-]", "", normalized)
        normalized = re.sub(r"_+", "_", normalized)
        normalized = re.sub(r"-+", "-", normalized)
        normalized = normalized.strip("._-")
        if not normalized:
            raise ValueError("Challenge name does not contain usable filesystem characters.")
        return normalized

    def normalize_document_name(self, name):
        normalized = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode(
            "ascii"
        )
        normalized = re.sub(r"[\"'`]", "", normalized)
        normalized = re.sub(r"[^A-Za-z0-9 _\-\(\)\[\]]", "", normalized)
        normalized = re.sub(r"\s+", " ", normalized).strip(" .")
        if not normalized:
            normalized = self.normalize_folder_name(name)
        return normalized

    def get_challenge_path(self, category, site, name):
        if hasattr(self.workspace_manager, "get_ctf_base_path"):
            return self.workspace_manager.get_ctf_base_path(category, site, name)
        return Path.home() / category / site / name

    def get_document_path(self, category, site, document_name):
        if self.documentation_root is None:
            raise ValueError("documentation directory is not configured.")
        return self.documentation_root / category / site / f"{document_name}.md"

    def create_document(self, category, site, document_name, title):
        document_path = self.get_document_path(category, site, document_name)
        document_path.parent.mkdir(parents=True, exist_ok=True)
        if not document_path.exists():
            document_path.write_text(
                f"# {title}\n\n- Category: {category}\n- Site: {site}\n",
                encoding="utf-8",
            )
        return document_path

    def build_summary_text(self, result):
        """
        Format a stable creation summary for CLI output and tests.
        """
        return self.output.format_kv(
            {
                "Category": result["category"],
                "Site": result["site"],
                "Challenge": result["name"],
                "Folder": result["folder_name"],
                "Challenge path": result["path"],
                "Writeup document": result["document_path"] or "Not created",
                "Download automove": result["download"],
                "Document creation check": result["doc_creation_check"],
            }
        )
