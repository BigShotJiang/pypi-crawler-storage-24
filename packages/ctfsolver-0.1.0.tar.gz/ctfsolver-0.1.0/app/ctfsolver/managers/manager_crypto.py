import base64
import binascii

try:
    from Crypto.Cipher import AES
except ModuleNotFoundError:
    AES = None

from ctfsolver.managers.manager_codecs import ManagerCodecs
from ctfsolver.managers.manager_math import ManagerMath
from ctfsolver.managers.manager_parallel import ManagerParallel


class ManagerCrypto(ManagerCodecs, ManagerMath, ManagerParallel):
    """
    ManagerCrypto provides utility methods for common cryptographic operations and flag extraction used in CTF challenges.
    Methods:
        initializing_all_ancestors(*args, **kwargs):
            Initializes all ancestors of the class. (Currently a placeholder.)
        xor(text: str, key: str) -> str:
            XORs the input text with the provided key and returns the result as a string.
        decode_base64(text: str) -> str:
            Decodes a base64-encoded string and returns the decoded text.
        re_match_base64_string(text: str, strict: bool = False) -> list[str]:
            Finds and returns all base64 strings in the input text. If strict is True, matches only strings with padding.
        re_match_flag(text: str, origin: str) -> list[str]:
            Searches for flags in the input text matching the pattern '{origin}{...}' and returns all matches.
        re_match_partial_flag(text: str, origin: str) -> list[str]:
            Searches for partial flags in the input text matching the pattern '{origin}{...}' or '{...}' and returns all matches.

    """

    def __init__(self, *args, **kwargs) -> None:
        pass

    def initializing_all_ancestors(self, *args, **kwargs):
        """
        Description:
            Initializes all the ancestors of the class

        """
        pass

    def pkcs7_pad(self, data, block_size: int) -> bytes:
        """
        Applies PKCS#7 padding.
        """
        data_bytes = self._to_bytes(data)
        if block_size <= 0:
            raise ValueError("block_size must be positive")
        pad_length = block_size - (len(data_bytes) % block_size)
        return data_bytes + bytes([pad_length]) * pad_length

    def pkcs7_unpad(self, data, block_size=None) -> bytes:
        """
        Removes PKCS#7 padding.
        """
        data_bytes = self._to_bytes(data)
        if not data_bytes:
            raise ValueError("Input must not be empty")

        pad_length = data_bytes[-1]
        if pad_length == 0 or pad_length > len(data_bytes):
            raise ValueError("Invalid PKCS#7 padding")
        if block_size is not None and pad_length > block_size:
            raise ValueError("Invalid PKCS#7 padding")
        if data_bytes[-pad_length:] != bytes([pad_length]) * pad_length:
            raise ValueError("Invalid PKCS#7 padding")

        return data_bytes[:-pad_length]

    def aes_cbc_decrypt(
        self,
        ciphertext,
        key,
        iv=None,
        unpad=True,
        input_format="raw",
        output_encoding="utf-8",
        errors="replace",
    ):
        """
        Decrypts AES-CBC data.

        Args:
            ciphertext: Raw, base64, or hex-encoded ciphertext.
            key: AES key.
            iv: Optional IV. If omitted, the helper treats the first block as IV.
            unpad: When `True`, applies PKCS#7 unpadding after decryption.
            input_format: One of `raw`, `base64`, or `hex`.

        Returns:
            Decoded plaintext as text using the selected output encoding.
        """
        if AES is None:
            raise ModuleNotFoundError(
                "pycryptodome is required for AES helpers. Install Crypto or avoid AES helpers."
            )

        cipher_bytes = self._to_bytes(ciphertext)
        if input_format == "base64":
            cipher_bytes = base64.b64decode(cipher_bytes)
        elif input_format == "hex":
            cipher_bytes = binascii.unhexlify(cipher_bytes)
        elif input_format != "raw":
            raise ValueError(f"Unsupported input_format: {input_format}")

        if iv is None:
            iv = cipher_bytes[: AES.block_size]
            cipher_bytes = cipher_bytes[AES.block_size :]
        else:
            iv = self._to_bytes(iv)

        plain = AES.new(self._to_bytes(key), AES.MODE_CBC, iv).decrypt(cipher_bytes)
        if unpad:
            plain = self.pkcs7_unpad(plain, AES.block_size)
        return plain.decode(output_encoding, errors=errors)

    def aes_cbc_encrypt(
        self,
        plaintext,
        key,
        iv,
        pad=True,
        output_format="raw",
    ):
        """
        Encrypts AES-CBC data.

        Args:
            plaintext: Raw plaintext to encrypt.
            key: AES key.
            iv: CBC IV.
            pad: When `True`, applies PKCS#7 padding before encryption.
            output_format: One of `raw`, `base64`, or `hex`.
        """
        if AES is None:
            raise ModuleNotFoundError(
                "pycryptodome is required for AES helpers. Install Crypto or avoid AES helpers."
            )

        data = self._to_bytes(plaintext)
        if pad:
            data = self.pkcs7_pad(data, AES.block_size)

        encrypted = AES.new(self._to_bytes(key), AES.MODE_CBC, self._to_bytes(iv)).encrypt(data)

        if output_format == "raw":
            return encrypted
        if output_format == "base64":
            return base64.b64encode(encrypted).decode("ascii")
        if output_format == "hex":
            return encrypted.hex()
        raise ValueError(f"Unsupported output_format: {output_format}")
