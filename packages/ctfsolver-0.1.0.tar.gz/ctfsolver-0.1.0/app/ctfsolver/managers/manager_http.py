"""
HTTP and SSE helpers for the runtime manager surface.

This module isolates request/streaming workflows from low-level pwntools-style
transport helpers so the connection manager no longer mixes unrelated concerns
in a single file.
"""

import json

try:
    import requests
except ModuleNotFoundError:
    requests = None


class ManagerHTTP:
    """
    Provides reusable HTTP session and SSE convenience helpers.

    The class stores a lazily created `requests.Session` on `self.http` so
    challenge scripts can reuse headers, cookies, and connection pooling across
    multiple requests.
    """

    def __init__(self, *args, **kwargs):
        """
        Initializes the reusable HTTP client slot for the current runtime
        object.
        """
        self.http = getattr(self, "http", None)

    def http_session(self, headers=None, cookies=None):
        """
        Creates and stores a reusable HTTP session.

        Args:
            headers: Optional default headers applied to the session.
            cookies: Optional default cookies applied to the session.

        Returns:
            A configured `requests.Session` instance stored on `self.http`.

        Raises:
            ModuleNotFoundError: If `requests` is not installed.
        """
        if requests is None:
            raise ModuleNotFoundError(
                "requests is required for HTTP helpers. Install requests or avoid HTTP helpers."
            )

        self.http = requests.Session()
        if headers:
            self.http.headers.update(headers)
        if cookies:
            self.http.cookies.update(cookies)
        return self.http

    def _get_http_session(self):
        """
        Returns the stored session or creates one on first use.
        """
        if self.http is not None:
            return self.http
        return self.http_session()

    def http_get(self, url, **kwargs):
        """
        Performs an HTTP GET request through the stored session.
        """
        return self._get_http_session().get(url, **kwargs)

    def http_post(self, url, data=None, json=None, **kwargs):
        """
        Performs an HTTP POST request through the stored session.
        """
        return self._get_http_session().post(url, data=data, json=json, **kwargs)

    def json_post(self, url, payload, **kwargs):
        """
        Convenience wrapper for JSON POST requests.
        """
        return self.http_post(url, json=payload, **kwargs)

    def sse_connect(self, url, **kwargs):
        """
        Opens a streaming HTTP response for SSE-like workflows.
        """
        kwargs.setdefault("stream", True)
        return self.http_get(url, **kwargs)

    def sse_messages(self, response):
        """
        Iterates over decoded `data:` lines from a server-sent-events stream.
        """
        for raw_line in response.iter_lines(decode_unicode=True):
            if not raw_line:
                continue
            if raw_line.startswith("data:"):
                yield raw_line[len("data:") :].strip()

    def sse_json_messages(self, response):
        """
        Iterates over JSON-decoded SSE message payloads and skips malformed
        entries.
        """
        for message in self.sse_messages(response):
            try:
                yield json.loads(message)
            except json.JSONDecodeError:
                continue
