# ctfsolver/managers/__init__.py

import importlib
import inspect
import pkgutil
from pathlib import Path


# Currently unused
def load_managers():
    """
    Dynamically import all 'Manager*' classes from the managers package.
    Returns a list of class objects.
    """
    base_path = Path(__file__).parent
    module_prefix = __name__  # 'ctfsolver.managers'
    manager_classes = []

    for _, module_name, _ in pkgutil.iter_modules([str(base_path)]):
        if not module_name.startswith("manager_"):
            continue

        full_module = f"{module_prefix}.{module_name}"
        print(full_module)
        # try:
        #     mod = importlib.import_module(full_module)
        #     for _, obj in inspect.getmembers(mod, inspect.isclass):
        #         if obj.__name__.startswith("Manager"):
        #             manager_classes.append(obj)
        # except Exception as e:
        #     print(f"[!] Failed to import {full_module}: {e}")

    return manager_classes


__all__ = [
    "load_managers",
    "ManagerFile",
    "ManagerConnections",
    "ManagerCrypto",
    "ManagerHTTP",
    "ManagerBlockchain",
    "ManagerCodecs",
    "ManagerMath",
    "ManagerParallel",
    "ManagerTools",
    "ManagerImages",
    "ManagerBinary",
    "ManagerFlag",
    "ManagerOutput",
]


def __getattr__(name):
    if name == "ManagerFile":
        from .manager_file import ManagerFile

        return ManagerFile
    if name == "ManagerConnections":
        from .manager_connections import ManagerConnections

        return ManagerConnections
    if name == "ManagerCrypto":
        from .manager_crypto import ManagerCrypto

        return ManagerCrypto
    if name == "ManagerHTTP":
        from .manager_http import ManagerHTTP

        return ManagerHTTP
    if name == "ManagerBlockchain":
        from .manager_blockchain import ManagerBlockchain

        return ManagerBlockchain
    if name == "ManagerCodecs":
        from .manager_codecs import ManagerCodecs

        return ManagerCodecs
    if name == "ManagerMath":
        from .manager_math import ManagerMath

        return ManagerMath
    if name == "ManagerParallel":
        from .manager_parallel import ManagerParallel

        return ManagerParallel
    if name == "ManagerTools":
        from .manager_tools import ManagerTools

        return ManagerTools
    if name == "ManagerImages":
        from .manager_images import ManagerImages

        return ManagerImages
    if name == "ManagerBinary":
        from .manager_binary import ManagerBinary

        return ManagerBinary
    if name == "ManagerFlag":
        from .manager_flag import ManagerFlag

        return ManagerFlag
    if name == "ManagerOutput":
        from .manager_output import ManagerOutput

        return ManagerOutput
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
