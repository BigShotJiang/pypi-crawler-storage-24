"""
Process, shell, and lightweight file-triage helpers for the runtime file
surface.
"""

import hashlib
import shutil
import subprocess


class ManagerTools:
    """
    Provides small shell/process wrappers and basic file-triage primitives that
    are useful during challenge solving.
    """

    def run_cmd(
        self,
        argv,
        capture=True,
        text=True,
        check=False,
        cwd=None,
        input=None,
        timeout=None,
        **kwargs,
    ):
        """
        Runs an external command and returns the resulting `CompletedProcess`.
        """
        return subprocess.run(
            argv,
            capture_output=capture,
            text=text,
            check=check,
            cwd=cwd,
            input=input,
            timeout=timeout,
            **kwargs,
        )

    def run_shell(
        self,
        command,
        capture=True,
        text=True,
        check=False,
        cwd=None,
        input=None,
        timeout=None,
        **kwargs,
    ):
        """
        Runs a shell command and returns the resulting `CompletedProcess`.
        """
        return subprocess.run(
            command,
            shell=True,
            capture_output=capture,
            text=text,
            check=check,
            cwd=cwd,
            input=input,
            timeout=timeout,
            **kwargs,
        )

    def tool_exists(self, name: str) -> bool:
        """
        Checks whether a command-line tool is available on `PATH`.
        """
        return shutil.which(name) is not None

    def strings(self, file, min_length=4, encoding="utf-8", errors="ignore") -> list[str]:
        """
        Extracts printable ASCII strings from a binary blob or file.
        """
        path = file if hasattr(file, "read_bytes") else None
        if path is not None:
            data = file.read_bytes()
        else:
            with open(file, "rb") as handle:
                data = handle.read()

        output = []
        current = bytearray()

        for byte in data:
            if 32 <= byte <= 126:
                current.append(byte)
                continue

            if len(current) >= min_length:
                output.append(current.decode(encoding, errors=errors))
            current = bytearray()

        if len(current) >= min_length:
            output.append(current.decode(encoding, errors=errors))

        return output

    def sha256_file(self, file, chunk_size=65536) -> str:
        """
        Computes the SHA-256 digest of a file by streaming it in chunks.
        """
        digest = hashlib.sha256()
        with open(file, "rb") as handle:
            while True:
                chunk = handle.read(chunk_size)
                if not chunk:
                    break
                digest.update(chunk)
        return digest.hexdigest()
