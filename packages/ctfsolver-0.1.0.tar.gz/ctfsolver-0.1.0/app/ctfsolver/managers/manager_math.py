"""
Lightweight number-theory helpers for the runtime crypto surface.
"""

import math


class ManagerMath:
    """
    Provides small, dependency-light number-theory primitives that show up in
    crypto and rev challenges.
    """

    def gcd(self, a: int, b: int) -> int:
        """
        Returns the greatest common divisor of two integers.
        """
        return math.gcd(a, b)

    def modinv(self, a: int, modulus: int) -> int:
        """
        Computes the modular inverse of `a` modulo `modulus`.

        Raises:
            ValueError: If the inverse does not exist.
        """
        a = a % modulus
        t, new_t = 0, 1
        r, new_r = modulus, a

        while new_r != 0:
            quotient = r // new_r
            t, new_t = new_t, t - quotient * new_t
            r, new_r = new_r, r - quotient * new_r

        if r != 1:
            raise ValueError("Modular inverse does not exist")

        if t < 0:
            t += modulus
        return t

    def int_nth_root(self, value: int, n: int) -> tuple[int, bool]:
        """
        Computes the integer `n`-th root of `value`.

        Returns:
            `(root, exact)` where `root` is the floor root and `exact`
            indicates whether `root ** n == value`.
        """
        if n <= 0:
            raise ValueError("n must be positive")
        if value < 0 and n % 2 == 0:
            raise ValueError("even roots of negative values are not supported")
        if value in (0, 1):
            return value, True

        low = 0
        high = max(1, value)

        while low <= high:
            mid = (low + high) // 2
            power = mid**n
            if power == value:
                return mid, True
            if power < value:
                low = mid + 1
            else:
                high = mid - 1

        return high, high**n == value

    def crt_solve(self, residues: list[int], moduli: list[int]) -> tuple[int, int]:
        """
        Solves a Chinese Remainder Theorem system for pairwise-coprime moduli.
        """
        if len(residues) != len(moduli) or not residues:
            raise ValueError("residues and moduli must have the same non-zero length")

        modulus_product = 1
        for modulus in moduli:
            modulus_product *= modulus

        solution = 0
        for residue, modulus in zip(residues, moduli):
            partial = modulus_product // modulus
            inverse = self.modinv(partial, modulus)
            solution += residue * inverse * partial

        return solution % modulus_product, modulus_product

    def factor_small(self, value: int) -> list[int]:
        """
        Returns prime factors using straightforward trial division.
        """
        if value <= 1:
            return [value]

        factors = []
        divisor = 2
        remaining = value

        while divisor * divisor <= remaining:
            while remaining % divisor == 0:
                factors.append(divisor)
                remaining //= divisor
            divisor = 3 if divisor == 2 else divisor + 2

        if remaining > 1:
            factors.append(remaining)

        return factors
