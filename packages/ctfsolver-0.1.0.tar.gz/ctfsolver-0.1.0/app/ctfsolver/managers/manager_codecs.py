"""
Codec, transform, and lightweight byte helpers for the runtime crypto surface.

The goal of this module is to keep repeated data-normalization and decode
workflows together while leaving heavier math and parallel orchestration in
separate focused managers.
"""

import base64
import re
from urllib.parse import unquote
from ctfsolver.managers.manager_output import ManagerOutput


class ManagerCodecs:
    """
    Provides text, bytes, XOR, and regex extraction helpers commonly used in
    challenge solve scripts.
    """

    def __init__(self, *args, **kwargs):
        self.output = kwargs.get("output_manager", None) or ManagerOutput()

    def _to_bytes(self, value, encoding="utf-8"):
        """
        Normalizes supported scalar inputs into raw bytes.

        Args:
            value: Input value as `str`, `bytes`, `bytearray`, or `int`.
            encoding: Encoding used when converting text inputs.

        Returns:
            Raw bytes representing the provided value.

        Raises:
            TypeError: If the value type is not supported by the runtime
                helpers.
        """
        if isinstance(value, bytes):
            return value
        if isinstance(value, bytearray):
            return bytes(value)
        if isinstance(value, str):
            return value.encode(encoding)
        if isinstance(value, int):
            width = max(1, (value.bit_length() + 7) // 8)
            return value.to_bytes(width, "big")
        raise TypeError(f"Unsupported value type: {type(value)!r}")

    def xor(self, text: str, key: str) -> str:
        """
        XORs two strings positionally and returns the decoded string result.
        """
        return "".join(chr(ord(a) ^ ord(b)) for a, b in zip(text, key))

    def decode_hex(self, text, encoding="utf-8", errors="replace"):
        """
        Decodes a hex string into text.
        """
        return bytes.fromhex(text).decode(encoding, errors=errors)

    def encode_hex(self, data) -> str:
        """
        Encodes bytes or text as hexadecimal.
        """
        return self._to_bytes(data).hex()

    def decode_base64(self, text):
        """
        Decodes a Base64 payload into UTF-8 text.

        Returns:
            Decoded text or `None` if decoding fails.
        """
        try:
            return base64.b64decode(text).decode("utf-8")
        except Exception as error:
            self.output.warn(error)
            return None

    def decode_url(self, text: str) -> str:
        """
        Decodes URL-escaped text.
        """
        return unquote(text)

    def decode_binary(self, text: str, byte_size=8, encoding="utf-8", errors="replace"):
        """
        Decodes whitespace-separated or contiguous binary digits into text.
        """
        compact = "".join(text.split())
        if len(compact) % byte_size != 0:
            raise ValueError("Binary text length is not aligned to byte_size")
        chunks = [
            compact[index : index + byte_size]
            for index in range(0, len(compact), byte_size)
        ]
        data = bytes(int(chunk, 2) for chunk in chunks)
        return data.decode(encoding, errors=errors)

    def decode_rot(self, text: str, shift: int) -> str:
        """
        Applies a Caesar-style rotation decode with the provided shift.
        """
        output = []
        for char in text:
            if "a" <= char <= "z":
                output.append(chr((ord(char) - ord("a") - shift) % 26 + ord("a")))
            elif "A" <= char <= "Z":
                output.append(chr((ord(char) - ord("A") - shift) % 26 + ord("A")))
            else:
                output.append(char)
        return "".join(output)

    def decode_rot13(self, text: str) -> str:
        """
        Applies a ROT13 decode.
        """
        return self.decode_rot(text, 13)

    def bytes_to_int(self, data, endian="big", signed=False) -> int:
        """
        Converts bytes-like input to an integer.
        """
        return int.from_bytes(self._to_bytes(data), endian, signed=signed)

    def int_to_bytes(self, value: int, size=None, endian="big", signed=False) -> bytes:
        """
        Converts an integer to bytes, optionally forcing a fixed width.
        """
        if size is None:
            if value == 0:
                size = 1
            else:
                size = (int(value).bit_length() + 7) // 8
        return int(value).to_bytes(size, endian, signed=signed)

    def xor_bytes(self, data, key, repeat=True) -> bytes:
        """
        XORs bytes-like data with a key.

        Args:
            data: Input payload as bytes, string, bytearray, or integer.
            key: XOR key in the same supported formats.
            repeat: When `True`, repeats the key across the full payload. When
                `False`, requires the key to be at least as long as the data.
        """
        data_bytes = self._to_bytes(data)
        key_bytes = self._to_bytes(key)
        if not key_bytes:
            raise ValueError("Key must not be empty")

        if repeat:
            return bytes(
                byte ^ key_bytes[index % len(key_bytes)]
                for index, byte in enumerate(data_bytes)
            )

        if len(key_bytes) < len(data_bytes):
            raise ValueError("Key must be at least as long as data when repeat=False")

        return bytes(byte ^ key_bytes[index] for index, byte in enumerate(data_bytes))

    def xor_single_byte_bruteforce(
        self,
        data,
        scorer="printable",
        min_printable_ratio=0.85,
    ) -> list[dict]:
        """
        Brute-forces all single-byte XOR keys and returns plausible candidates.

        The scoring intentionally favors outputs that are printable and biased
        toward English or flag-like characters.
        """
        data_bytes = self._to_bytes(data)
        candidates = []

        for key in range(256):
            decoded = self.xor_bytes(data_bytes, bytes([key]))
            if scorer == "printable":
                printable = sum(32 <= byte <= 126 or byte in (9, 10, 13) for byte in decoded)
                printable_ratio = printable / max(1, len(decoded))
                if printable_ratio < min_printable_ratio:
                    continue
                common_text = sum(
                    chr(byte).lower() in " etaoinshrdlucmfwypvbgkjqxz{}_-" for byte in decoded
                )
                score = printable_ratio + (common_text / max(1, len(decoded)))
            else:
                score = 0

            candidates.append(
                {
                    "key": key,
                    "key_hex": f"{key:02x}",
                    "decoded_bytes": decoded,
                    "decoded_text": decoded.decode("utf-8", errors="replace"),
                    "score": score,
                }
            )

        return sorted(candidates, key=lambda item: item["score"], reverse=True)

    def apply_decode_chain(self, text, steps):
        """
        Applies a sequence of decode steps to a value.

        Args:
            text: Initial encoded value.
            steps: Sequence of method names or `{name, kwargs}` descriptors.

        Returns:
            The final decoded value after all requested transforms.
        """
        value = text
        for step in steps:
            if isinstance(step, str):
                method = getattr(self, f"decode_{step}")
                value = method(value)
                continue

            if not isinstance(step, dict) or "name" not in step:
                raise ValueError("Each decode step must be a string or a dict with a name")

            method = getattr(self, f"decode_{step['name']}")
            kwargs = step.get("kwargs", {})
            value = method(value, **kwargs)
        return value

    def re_match_base64_string(self, text: str, strict=False) -> list[str]:
        """
        Extracts likely Base64 substrings from text.
        """
        if strict:
            base64_pattern = r"[A-Za-z0-9+/]{4,}={1,2}"
        else:
            base64_pattern = r"[A-Za-z0-9+/]{4,}={0,2}"
        return re.findall(base64_pattern, text)

    def re_match_flag(self, text: str, origin: str) -> list[str]:
        """
        Extracts flags matching the `origin{...}` pattern.
        """
        flag_pattern = rf"{origin}{{[A-Za-z0-9_]+}}"
        return re.findall(flag_pattern, text)

    def re_match_partial_flag(self, text: str, origin: str) -> list[str]:
        """
        Extracts full or partial flag-like substrings for a given origin.
        """
        flag_pattern = rf"({origin}{{[^ ]*|[^ ]*}})"
        return re.findall(flag_pattern, text)
