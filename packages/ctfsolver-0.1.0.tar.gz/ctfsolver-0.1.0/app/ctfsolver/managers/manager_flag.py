"""
Flag extraction and presentation helpers for runtime solve scripts.

This manager centralizes the common end-of-solve workflow of finding likely
flag strings, storing them on the solver instance, printing them through the
shared output layer, and optionally copying them to the clipboard.
"""

from __future__ import annotations

import re

try:
    import pyperclip
except ModuleNotFoundError:
    pyperclip = None

from ctfsolver.managers.manager_output import ManagerOutput


class ManagerFlag:
    """
    Provides lightweight flag detection, storage, and presentation helpers.

    The manager is intentionally text-oriented. It avoids broad secret-scanning
    behavior and instead focuses on the typical `origin{...}` patterns used in
    CTF challenges. The helpers support both stateless extraction from arbitrary
    text and stateful presentation through `self.flag` and `self.flags`.
    """

    DEFAULT_PREFIXES = ("flag", "ctf", "picoCTF", "HTB", "ECSC")

    def __init__(self, *args, **kwargs):
        """
        Initializes the flag manager with shared output and empty stored state.

        Args:
            output_manager: Optional `ManagerOutput` instance used for emitted
                summaries and warnings.
        """
        self.output = kwargs.get("output_manager", None) or ManagerOutput()
        self.flag = kwargs.get("flag", None)
        self.flags = self.normalize_flag_candidates(kwargs.get("flags", []))

    def default_flag_prefixes(self):
        """
        Returns the default ordered list of flag prefixes used for extraction.
        """
        return list(self.DEFAULT_PREFIXES)

    def normalize_flag_candidates(self, flags):
        """
        Deduplicates and normalizes candidate flags while preserving order.

        Args:
            flags: Iterable of flag-like values or a single scalar value.

        Returns:
            List of unique non-empty string candidates.
        """
        if flags is None:
            return []
        if isinstance(flags, (str, bytes, bytearray)):
            flags = [flags]

        normalized = []
        seen = set()
        for item in flags:
            if item is None:
                continue
            if isinstance(item, bytes):
                text = item.decode("utf-8", errors="replace")
            elif isinstance(item, bytearray):
                text = bytes(item).decode("utf-8", errors="replace")
            else:
                text = str(item)
            text = text.strip()
            if not text or text in seen:
                continue
            seen.add(text)
            normalized.append(text)
        return normalized

    def _prefix_patterns(self, prefixes=None, allow_partial=False):
        """
        Builds regex patterns for the requested prefixes.

        Args:
            prefixes: Optional iterable of explicit flag prefixes.
            allow_partial: When `True`, also match truncated flag-like strings.

        Returns:
            Ordered list of regex patterns to apply against candidate text.
        """
        chosen_prefixes = sorted(
            self.normalize_flag_candidates(prefixes or self.default_flag_prefixes()),
            key=len,
            reverse=True,
        )
        patterns = [rf"(?<![A-Za-z0-9_]){re.escape(prefix)}\{{[^}}\n]+\}}" for prefix in chosen_prefixes]
        if allow_partial:
            patterns.extend(
                [rf"(?<![A-Za-z0-9_]){re.escape(prefix)}\{{[^ \n]*" for prefix in chosen_prefixes]
            )
            patterns.append(r"[^ \n]*\}")
        return patterns

    def extract_flags(self, text, prefixes=None, allow_partial=False):
        """
        Extracts matching flag candidates from text.

        Args:
            text: Raw text to inspect.
            prefixes: Optional explicit flag prefixes.
            allow_partial: When `True`, also returns truncated flag-like
                matches that may appear in noisy brute-force or forensic output.

        Returns:
            List of normalized unique candidates in discovery order.
        """
        if text is None:
            return []

        if isinstance(text, bytes):
            haystack = text.decode("utf-8", errors="replace")
        elif isinstance(text, bytearray):
            haystack = bytes(text).decode("utf-8", errors="replace")
        else:
            haystack = str(text)

        found = []
        for pattern in self._prefix_patterns(prefixes=prefixes, allow_partial=allow_partial):
            for match in re.finditer(pattern, haystack, flags=re.IGNORECASE):
                found.append((match.start(), match.group(0)))

        found.sort(key=lambda item: item[0])
        return self.normalize_flag_candidates([value for _, value in found])

    def extract_first_flag(self, text, prefixes=None, allow_partial=False):
        """
        Returns the first extracted flag candidate from text, if any.
        """
        matches = self.extract_flags(text, prefixes=prefixes, allow_partial=allow_partial)
        return matches[0] if matches else None

    def set_flag(self, value):
        """
        Stores one primary flag candidate and keeps `self.flags` in sync.
        """
        normalized = self.normalize_flag_candidates([value])
        self.flag = normalized[0] if normalized else None
        if self.flag is not None:
            self.flags = self.normalize_flag_candidates([self.flag, *self.flags])
        elif not self.flags:
            self.flags = []
        return self.flag

    def set_flags(self, values):
        """
        Stores multiple flag candidates and updates the primary flag.
        """
        self.flags = self.normalize_flag_candidates(values)
        self.flag = self.flags[0] if self.flags else None
        return list(self.flags)

    def copy_flag(self, flag):
        """
        Copies a flag candidate to the clipboard when clipboard support exists.

        Args:
            flag: Flag value to copy.

        Returns:
            `True` when the copy succeeds, otherwise `False`.
        """
        if pyperclip is None:
            return False
        try:
            pyperclip.copy(flag)
            return True
        except Exception as error:
            self.output.warn(f"Clipboard copy failed: {error}", level=2)
            return False

    def build_flag_summary(self, flags):
        """
        Formats extracted flags as a stable plain-text block.
        """
        normalized = self.normalize_flag_candidates(flags)
        if len(normalized) == 1:
            return normalized[0]
        return self.output.format_list(normalized, title="Flags")

    def present_flag(self, flag=None, *, copy=True, emit=True, level=1):
        """
        Presents one flag candidate using the shared output layer.

        Args:
            flag: Explicit flag to present. Falls back to `self.flag`, then the
                first stored item in `self.flags`.
            copy: When `True`, attempts clipboard copy.
            emit: When `True`, emits through `ManagerOutput.success(...)`.
            level: Minimum output verbosity level for emission.

        Returns:
            The presented flag string, or `None` when no flag is available.
        """
        candidate = flag or self.flag or (self.flags[0] if self.flags else None)
        if candidate is None:
            if emit:
                self.output.warn("No flag available to present.", level=level)
            return None

        presented = self.set_flag(candidate)
        if copy:
            self.copy_flag(presented)
        if emit:
            self.output.success(f"Flag: {presented}", level=level)
        return presented

    def present_flags(self, flags=None, *, copy_first=True, emit=True, level=1):
        """
        Presents multiple flag candidates and stores them on the instance.

        Args:
            flags: Explicit iterable of flags. Falls back to stored `self.flags`
                and `self.flag` values when omitted.
            copy_first: When `True`, copies the first normalized candidate.
            emit: When `True`, emits a formatted summary through `ManagerOutput`.
            level: Minimum output verbosity level for emission.

        Returns:
            List of normalized flag candidates.
        """
        if flags is None:
            normalized = self.normalize_flag_candidates(self.flags or [self.flag])
        else:
            normalized = self.set_flags(flags)

        if not normalized:
            if emit:
                self.output.warn("No flags available to present.", level=level)
            return []

        self.set_flags(normalized)
        if copy_first:
            self.copy_flag(normalized[0])
        if emit:
            if len(normalized) == 1:
                self.output.success(f"Flag: {normalized[0]}", level=level)
            else:
                self.output.success("Multiple flags found.", level=level)
                self.output.info(self.build_flag_summary(normalized), level=level)
        return list(normalized)
