"""
Blockchain helpers for the runtime manager surface.

This module separates optional Web3 workflows from the lower-level transport
manager so blockchain dependencies remain isolated and easier to reason about.
"""

try:
    from web3 import Web3
except ModuleNotFoundError:
    Web3 = None


class ManagerBlockchain:
    """
    Provides optional EVM/Web3 convenience helpers.

    The helpers are intentionally light wrappers around common call and
    transaction flows that appear in blockchain CTF challenges.
    """

    def __init__(self, *args, **kwargs):
        """
        Initializes the cached Web3 client slot for the current runtime object.
        """
        self.web3 = getattr(self, "web3", None)

    def web3_connect(self, rpc_url, web3_class=None):
        """
        Connects to an EVM-compatible JSON-RPC endpoint and stores the client.

        Args:
            rpc_url: HTTP RPC endpoint URL.
            web3_class: Optional dependency-injection hook for tests.

        Returns:
            A connected `Web3`-compatible client instance.

        Raises:
            ModuleNotFoundError: If `web3` is not installed.
        """
        web3_class = web3_class or Web3
        if web3_class is None:
            raise ModuleNotFoundError(
                "web3 is required for blockchain helpers. Install web3 or avoid blockchain helpers."
            )

        provider = web3_class.HTTPProvider(rpc_url)
        self.web3 = web3_class(provider)
        return self.web3

    def _get_web3(self):
        """
        Returns the stored Web3 client and fails clearly if it was not
        initialized yet.
        """
        if self.web3 is None:
            raise ValueError("Web3 client is not initialized. Call web3_connect(...) first.")
        return self.web3

    def web3_contract(self, address, abi):
        """
        Creates a contract proxy from the stored Web3 client.
        """
        return self._get_web3().eth.contract(address=address, abi=abi)

    def call_contract(self, contract, fn_name, *args):
        """
        Executes a read-only smart-contract call.
        """
        return getattr(contract.functions, fn_name)(*args).call()

    def send_contract_tx(
        self,
        contract,
        fn_name,
        *args,
        private_key,
        tx_params=None,
    ):
        """
        Builds, signs, and submits a smart-contract transaction.

        Args:
            contract: Web3 contract proxy.
            fn_name: Target contract function name.
            *args: Positional function arguments.
            private_key: Private key used to derive the sending account.
            tx_params: Optional transaction overrides such as `chainId`, `gas`,
                or `gasPrice`.

        Returns:
            The transaction hash object returned by `send_raw_transaction`.
        """
        web3 = self._get_web3()
        account = web3.eth.account.from_key(private_key)
        params = dict(tx_params or {})
        params.setdefault("nonce", web3.eth.get_transaction_count(account.address))

        tx = getattr(contract.functions, fn_name)(*args).build_transaction(params)
        signed = web3.eth.account.sign_transaction(tx, private_key=private_key)

        sender = getattr(web3.eth, "send_raw_transaction", None)
        if sender is None:
            sender = web3.eth.sendRawTransaction
        return sender(signed.rawTransaction)
