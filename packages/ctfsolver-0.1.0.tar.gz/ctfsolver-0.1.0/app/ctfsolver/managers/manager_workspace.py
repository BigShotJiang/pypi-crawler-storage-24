import os

from pathlib import Path

from ctfsolver.config import CONFIG
from ctfsolver.managers.manager_folder import ManagerFolder
from ctfsolver.managers.manager_files_re import ManagerFileRegex

try:
    import pyperclip
except ModuleNotFoundError:
    pyperclip = None


class ManagerWorkspace(ManagerFolder, ManagerFileRegex):
    """
    Workspace-oriented folder helper for CLI challenge management.

    This class owns directory-creation workflows that belong to the challenge
    workspace tooling layer rather than the runtime ``CTFSolver`` inheritance
    surface used by solution scripts.
    """

    def create_parent_folder(self):
        for folder in self.folders.values():
            if not folder.exists():
                folder.mkdir()

    def get_ctf_base_path(self, category, site, name):
        ctf_data_dir = CONFIG["directories"]["ctf_data"]
        return Path(Path.home(), ctf_data_dir, category, site, name)

    def create_ctf_structure(
        self, category, site, name, verbose=False, download=False, **kwargs
    ):
        base_path = self.get_ctf_base_path(category, site, name)
        checker = kwargs.get("checker", False)

        if not base_path.exists():
            base_path.mkdir(parents=True)

        for folder in self.folders_name_list:
            folder_path = Path(base_path, folder)
            if not folder_path.exists():
                folder_path.mkdir()

        if pyperclip is not None:
            pyperclip.copy(str(base_path))
        if download:
            self.download_automove(
                category=category,
                challenge_name=name,
                challenge_path=base_path,
                checker=checker,
                verbose=verbose,
            )
