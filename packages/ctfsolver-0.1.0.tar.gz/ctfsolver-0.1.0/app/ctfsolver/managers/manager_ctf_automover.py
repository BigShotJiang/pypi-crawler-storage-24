from ctfsolver.managers.manager_output import ManagerOutput


class ManagerCTFAutoMover:
    """
    Encapsulate automove context resolution and execution for a CTF challenge.

    This service depends on the folder-oriented runtime surface rather than the
    broader `ManagerFile` composite, because the automove workflow only needs
    challenge-directory context and the current `download_automove(...)`
    implementation that lives on `ManagerFolder`.
    """

    def __init__(self, manager_folder=None, manager_file=None, output_manager=None):
        """
        Initializes the automove service with a folder-capable manager.

        Args:
            manager_folder: Preferred dependency. Must expose the current
                folder-context helpers used by the automove workflow.
            manager_file: Backward-compatible alias for older call sites that
                still pass `manager_file=...`.
        """
        if manager_folder is None:
            manager_folder = manager_file

        if manager_folder is None:
            from ctfsolver.managers.manager_folder import ManagerFolder

            manager_folder = ManagerFolder()
        self.manager_folder = manager_folder
        self.output = output_manager or ManagerOutput()

    def resolve_context(self):
        """
        Resolves category, challenge name, and challenge path from the current
        folder context before dispatching the automove action.
        """
        self.manager_folder.get_current_dir()
        challenge_path = self.get_challenge_path(self.manager_folder.parent)
        return {
            "category": challenge_path.parent.parent.name,
            "challenge_name": challenge_path.name,
            "challenge_path": challenge_path,
        }

    def get_challenge_path(self, current_path):
        """
        Normalizes nested working directories such as `files/` or `payloads/`
        back to the enclosing challenge directory.
        """
        folder_names = set(getattr(self.manager_folder, "folders_name_list", []))
        if current_path.name in folder_names:
            return current_path.parent
        return current_path

    def automove(self, checker=False, verbose=False):
        """
        Executes the folder-based download automove workflow for the resolved
        challenge context and returns the derived metadata.
        """
        context = self.resolve_context()
        self.manager_folder.download_automove(
            category=context["category"],
            challenge_name=context["challenge_name"],
            challenge_path=context["challenge_path"],
            checker=checker,
            verbose=verbose,
        )
        return context

    def build_summary_text(self, context):
        """
        Format a stable automove summary for CLI output and tests.
        """
        return self.output.format_kv(
            {
                "Category": context["category"],
                "Challenge": context["challenge_name"],
                "Challenge path": context["challenge_path"],
            }
        )
