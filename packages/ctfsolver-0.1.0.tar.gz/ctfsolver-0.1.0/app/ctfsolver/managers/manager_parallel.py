"""
Parallel brute-force helpers for the runtime crypto surface.
"""

import concurrent.futures


class ManagerParallel:
    """
    Provides lightweight batching and concurrent candidate-evaluation helpers.
    """

    def chunked(self, iterable, size: int):
        """
        Yields lists of up to `size` items from an iterable.

        Raises:
            ValueError: If `size` is not positive.
        """
        if size <= 0:
            raise ValueError("size must be positive")

        batch = []
        for item in iterable:
            batch.append(item)
            if len(batch) == size:
                yield batch
                batch = []
        if batch:
            yield batch

    def bruteforce_iter(
        self,
        candidates,
        worker,
        processes=None,
        stop_on_first=True,
        executor_class=None,
    ):
        """
        Evaluates candidates in parallel and returns matching worker results.

        Args:
            candidates: Iterable of candidate inputs.
            worker: Callable that returns a successful result or `None`/`False`.
            processes: Maximum number of worker slots.
            stop_on_first: When `True`, returns the first match.
            executor_class: Optional executor implementation for dependency
                injection in tests.
        """
        executor_class = executor_class or concurrent.futures.ThreadPoolExecutor
        max_workers = processes

        with executor_class(max_workers=max_workers) as executor:
            futures = [executor.submit(worker, candidate) for candidate in candidates]
            matches = []

            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                if result is None or result is False:
                    continue

                if stop_on_first:
                    for pending in futures:
                        if pending is not future:
                            pending.cancel()
                    return result

                matches.append(result)

        if stop_on_first:
            return None
        return matches
