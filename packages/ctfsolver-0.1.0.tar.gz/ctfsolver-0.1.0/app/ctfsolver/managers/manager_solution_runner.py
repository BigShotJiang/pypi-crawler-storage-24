import importlib.util
import subprocess
import sys

from pathlib import Path
from ctfsolver.managers.manager_output import ManagerOutput


class ManagerSolutionRunner:
    """
    Encapsulate challenge solution loading and execution.

    This keeps CLI parsing thin while preserving the class-based project style.
    """

    def __init__(self, manager_file=None, process_runner=None, output_manager=None):
        if manager_file is None:
            from ctfsolver.managers.manager_file import ManagerFile

            manager_file = ManagerFile()
        self.manager_file = manager_file
        self.process_runner = process_runner or subprocess.run
        self.output = output_manager or ManagerOutput()

    def get_solution_file(self):
        self.manager_file.get_current_dir()
        solution_file = self.manager_file.get_solution_file(save=True)
        if solution_file is None:
            raise FileNotFoundError("Solution file not found in the payloads folder.")
        return Path(solution_file)

    def resolve_mode(self, local=False, remote=False, file=None, host=None, port=None):
        if local and remote:
            raise ValueError("Cannot use both --local and --remote options simultaneously.")

        if file and not (remote or host or port):
            local = True
        elif host and port is not None and not (local or file):
            remote = True

        if local and not file:
            raise ValueError("File must be specified when using --local option.")
        if remote and (not host or port is None):
            raise ValueError("Host and port must be specified when using --remote option.")

        if remote:
            return "remote"
        if local:
            return "local"
        return None

    def load_solution_class(self, solution_file):
        spec = importlib.util.spec_from_file_location(
            "ctf_solution_module", str(solution_file)
        )
        if spec is None or spec.loader is None:
            raise ImportError(f"Cannot load module spec from {solution_file}")

        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)  # type: ignore[attr-defined]

        solution_class = getattr(module, "Solution", None)
        if solution_class is None:
            raise ImportError(f"No class 'Solution' found in {solution_file}")
        return solution_class

    def run_solution_script(self, solution_file):
        result = self.process_runner([sys.executable, str(solution_file)], check=True)
        return result.returncode

    def run_solution_class(self, solution_file, conn=None, file=None, host=None, port=None):
        solution_class = self.load_solution_class(solution_file)
        solution_instance = solution_class(conn=conn, file=file, url=host, port=port)
        if not hasattr(solution_instance, "try_main"):
            raise AttributeError(
                f"Solution class in {solution_file} does not define try_main"
            )
        solution_instance.try_main(file)

    def build_run_summary(self, solution_file, mode=None, file=None, host=None, port=None):
        """
        Format a stable summary of the selected execution path for CLI output.
        """
        mode_label = "script" if mode is None else mode
        return self.output.format_kv(
            {
                "Mode": mode_label,
                "Solution file": Path(solution_file),
                "Input file": file if file is not None else "-",
                "Host": host if host is not None else "-",
                "Port": port if port is not None else "-",
            }
        )

    def run(self, local=False, remote=False, file=None, host=None, port=None):
        solution_file = self.get_solution_file()
        conn = self.resolve_mode(
            local=local, remote=remote, file=file, host=host, port=port
        )

        if conn is None:
            return self.run_solution_script(solution_file)

        self.run_solution_class(
            solution_file, conn=conn, file=file, host=host, port=port
        )
        return 0
