import tarfile
import zipfile

from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from ctfsolver.config.global_config import CONFIG
from ctfsolver.find_usage.manager_gathering import ManagerGathering
from ctfsolver.managers.manager_output import ManagerOutput


class ManagerInternalChooser:
    """
    Build and query a compact recommendation index derived from historical
    Solution files.
    """

    FILE_FAMILY_HINTS = {
        "image": {
            "types": ("framework_method", "external_workflow"),
            "patterns": ("image", "stego", "exif", "qr", "png", "jpg", "jpeg"),
            "weight": 3,
        },
        "pcap": {
            "types": ("framework_method", "external_workflow"),
            "patterns": ("pcap", "wireshark", "scapy", "tcp", "udp", "http"),
            "weight": 4,
        },
        "binary": {
            "types": ("internal_helper_pattern", "external_workflow"),
            "patterns": ("elf", "gdb", "strings", "binary", "objdump", "disasm"),
            "weight": 3,
        },
        "archive": {
            "types": ("external_workflow", "internal_helper_pattern"),
            "patterns": ("zip", "tar", "archive", "extract"),
            "weight": 2,
        },
        "office": {
            "types": ("external_workflow",),
            "patterns": ("ole", "doc", "xls", "ppt", "office", "macro"),
            "weight": 3,
        },
        "memory_dump": {
            "types": ("external_workflow",),
            "patterns": ("volatility", "memory", "dump", "forensics"),
            "weight": 5,
        },
    }

    EXTENSION_FAMILIES = {
        ".png": "image",
        ".jpg": "image",
        ".jpeg": "image",
        ".gif": "image",
        ".bmp": "image",
        ".svg": "image",
        ".pcap": "pcap",
        ".pcapng": "pcap",
        ".cap": "pcap",
        ".zip": "archive",
        ".7z": "archive",
        ".rar": "archive",
        ".tar": "archive",
        ".gz": "archive",
        ".tgz": "archive",
        ".xz": "archive",
        ".bz2": "archive",
        ".exe": "binary",
        ".dll": "binary",
        ".so": "binary",
        ".bin": "binary",
        ".elf": "binary",
        ".o": "binary",
        ".doc": "office",
        ".docx": "office",
        ".xls": "office",
        ".xlsx": "office",
        ".ppt": "office",
        ".pptx": "office",
        ".odt": "office",
        ".ods": "office",
        ".dmp": "memory_dump",
        ".raw": "memory_dump",
        ".mem": "memory_dump",
        ".lime": "memory_dump",
    }

    CATEGORY_ALIASES = {
        "reverseengineering": "ReverseEngineering",
        "reverse": "ReverseEngineering",
        "rev": "ReverseEngineering",
        "re": "ReverseEngineering",
        "misc": "Miscellaneous",
        "miscellaneous": "Miscellaneous",
        "crypto": "Cryptography",
        "forensics": "Forensics",
        "web": "Web",
        "pwn": "Pwn",
        "osint": "Osint",
        "stego": "Stego",
        "binary": "Binary",
        "fullpwn": "FullPwn",
    }

    def __init__(
        self,
        gather_manager=None,
        config=None,
        output_manager=None,
        ctf_root=None,
        package_root=None,
        framework_file=None,
    ):
        self.output = output_manager or ManagerOutput()
        self.config = config or CONFIG
        self.gather_manager = gather_manager
        self._gather_manager_kwargs = {
            "ctf_root": ctf_root,
            "package_root": package_root,
            "framework_file": framework_file,
            "output_manager": self.output,
        }
        self.ctf_root = getattr(gather_manager, "ctf_root", None)
        self.categories = self.config.content.get("data", {}).get("categories", [])

    def get_gather_manager(self):
        if self.gather_manager is None:
            self.gather_manager = ManagerGathering(**self._gather_manager_kwargs)
            self.ctf_root = self.gather_manager.ctf_root
        return self.gather_manager

    def build_index(self, minimum_usage_count=None):
        minimum_usage_count = int(
            minimum_usage_count
            if minimum_usage_count is not None
            else self.config.get_chooser_data().get("minimum_usage_count", 2)
        )
        gather_manager = self.get_gather_manager()
        corpus = gather_manager.gather_corpus()
        grouped = defaultdict(dict)

        for entry in corpus["entries"]:
            challenge = entry["challenge"]
            category = self.normalize_category(challenge.get("category"))
            if not category:
                continue

            for method_name in entry["framework_methods_used"]:
                self._record_recommendation(
                    grouped,
                    category,
                    name=method_name,
                    recommendation_type="framework_method",
                    challenge=challenge,
                )

            for call_name in entry["external_calls"]:
                self._record_recommendation(
                    grouped,
                    category,
                    name=call_name,
                    recommendation_type="external_workflow",
                    challenge=challenge,
                )

        for duplicate in corpus["duplicates"]:
            for occurrence in duplicate["occurrences"]:
                category = self.normalize_category(occurrence.get("category"))
                if not category:
                    continue
                self._record_recommendation(
                    grouped,
                    category,
                    name=duplicate["name"],
                    recommendation_type="internal_helper_pattern",
                    challenge=occurrence,
                )

        category_function_map = {}
        for category, records in sorted(grouped.items()):
            recommendations = []
            for record in records.values():
                if record["usage_count"] < minimum_usage_count:
                    continue
                recommendations.append(
                    {
                        "name": record["name"],
                        "type": record["type"],
                        "usage_count": record["usage_count"],
                        "example_paths": sorted(record["example_paths"])[:5],
                    }
                )
            recommendations.sort(
                key=lambda item: (-item["usage_count"], item["type"], item["name"])
            )
            if recommendations:
                category_function_map[category] = recommendations

        return {
            "category_function_map": category_function_map,
            "last_updated": datetime.now(timezone.utc).isoformat(),
            "source_root": gather_manager.ctf_root.as_posix(),
            "minimum_usage_count": minimum_usage_count,
        }

    def update_index(self, minimum_usage_count=None):
        chooser_data = self.build_index(minimum_usage_count=minimum_usage_count)
        self.config.set_chooser_data(chooser_data)
        return chooser_data

    def summarize_index(self, chooser_data):
        category_map = chooser_data.get("category_function_map", {})
        recommendation_count = sum(len(items) for items in category_map.values())
        return self.output.format_kv(
            {
                "Source root": chooser_data.get("source_root"),
                "Categories indexed": len(category_map),
                "Recommendations stored": recommendation_count,
                "Minimum usage count": chooser_data.get("minimum_usage_count"),
                "Last updated": chooser_data.get("last_updated"),
            }
        )

    def get_cached_index(self):
        chooser_data = self.config.get_chooser_data()
        category_map = chooser_data.get("category_function_map", {})
        if not category_map:
            raise ValueError("Chooser cache is empty. Run `ctfsolver chooser update` first.")
        return chooser_data

    def infer_category(self, path=None):
        current = Path(path or Path.cwd()).resolve()
        candidates = [current, *current.parents]
        gather_manager = self.get_gather_manager()

        try:
            relative = current.relative_to(gather_manager.ctf_root)
            parts = relative.parts
            if parts:
                inferred = self.normalize_category(parts[0])
                if inferred:
                    return inferred
        except ValueError:
            pass

        for candidate in candidates:
            inferred = self.normalize_category(candidate.name)
            if inferred:
                return inferred
        return None

    def normalize_category(self, category):
        if not category:
            return None
        text = str(category).strip()
        if not text:
            return None

        lookup = {item.lower(): item for item in self.categories}
        normalized = lookup.get(text.lower())
        if normalized:
            return normalized

        compact = text.replace("_", "").replace("-", "").replace(" ", "").lower()
        for existing in self.categories:
            existing_compact = existing.replace("_", "").replace("-", "").replace(" ", "").lower()
            if compact == existing_compact:
                return existing

        alias = self.CATEGORY_ALIASES.get(compact)
        if alias:
            return alias
        return text

    def inspect_files(self, path=None):
        base_path = Path(path or Path.cwd()).resolve()
        files_dir = base_path / "files"
        if not files_dir.exists():
            return {}

        families = defaultdict(
            lambda: {"weight": 0, "files": set(), "archive_members": set()}
        )
        for file_path in sorted(candidate for candidate in files_dir.rglob("*") if candidate.is_file()):
            family = self._family_for_path(file_path)
            if family:
                families[family]["weight"] += self.FILE_FAMILY_HINTS[family]["weight"]
                families[family]["files"].add(file_path.relative_to(files_dir).as_posix())

            for member_family, member_name in self._archive_member_families(file_path):
                families[member_family]["weight"] += self.FILE_FAMILY_HINTS[member_family]["weight"]
                families[member_family]["archive_members"].add(member_name)

        return {
            family: {
                "weight": data["weight"],
                "files": sorted(data["files"]),
                "archive_members": sorted(data["archive_members"])[:10],
            }
            for family, data in sorted(families.items())
        }

    def recommend(self, category=None, path=None, inspect_files=False, limit=10):
        chooser_data = self.get_cached_index()
        resolved_category = self.normalize_category(category) if category else self.infer_category(path=path)
        if not resolved_category:
            raise ValueError("Unable to infer challenge category. Pass `--category`.")

        recommendations = [
            dict(item)
            for item in chooser_data.get("category_function_map", {}).get(resolved_category, [])
        ]
        hints = self.inspect_files(path=path) if inspect_files else {}
        recommendations = self._apply_file_hints(recommendations, hints)
        recommendations.sort(
            key=lambda item: (
                -item.get("score", item["usage_count"]),
                -item["usage_count"],
                item["type"],
                item["name"],
            )
        )
        return {
            "category": resolved_category,
            "used_cached_index": True,
            "source_root": chooser_data.get("source_root"),
            "minimum_usage_count": chooser_data.get("minimum_usage_count"),
            "file_hints": hints,
            "recommendations": recommendations[:limit],
        }

    def build_recommendation_lines(self, result):
        lines = [
            "# Chooser Recommendations",
            "",
            f"- Category: {result['category']}",
            f"- Source root: {result['source_root']}",
            f"- Minimum usage count: {result['minimum_usage_count']}",
            "",
            "## Recommendations",
        ]

        recommendations = result.get("recommendations", [])
        if recommendations:
            for item in recommendations:
                score = item.get("score", item["usage_count"])
                lines.append(
                    f"- {item['name']} [{item['type']}] usage={item['usage_count']} score={score}"
                )
                for path in item.get("example_paths", [])[:3]:
                    lines.append(f"  - example: {path}")
                if item.get("matched_file_families"):
                    lines.append(
                        "  - file hints: " + ", ".join(sorted(item["matched_file_families"]))
                    )
        else:
            lines.append("- None")

        if result.get("file_hints"):
            lines.extend(["", "## File Hints"])
            for family, data in result["file_hints"].items():
                lines.append(f"- {family} (weight={data['weight']})")
                for file_name in data["files"][:3]:
                    lines.append(f"  - file: {file_name}")
                for member_name in data["archive_members"][:3]:
                    lines.append(f"  - archive member: {member_name}")

        return lines

    def _record_recommendation(self, grouped, category, name, recommendation_type, challenge):
        key = (recommendation_type, name)
        record = grouped[category].setdefault(
            key,
            {
                "name": name,
                "type": recommendation_type,
                "usage_count": 0,
                "example_paths": set(),
                "_seen_paths": set(),
            },
        )
        path = challenge.get("path")
        if path not in record["_seen_paths"]:
            record["usage_count"] += 1
            record["_seen_paths"].add(path)
        if path:
            record["example_paths"].add(path)

    def _family_for_path(self, path):
        suffixes = path.suffixes or [path.suffix]
        for suffix in reversed(suffixes):
            family = self.EXTENSION_FAMILIES.get(suffix.lower())
            if family:
                return family
        return None

    def _archive_member_families(self, path):
        family = self._family_for_path(path)
        if family != "archive":
            return []

        members = []
        if zipfile.is_zipfile(path):
            try:
                with zipfile.ZipFile(path) as archive:
                    for name in archive.namelist():
                        member_family = self._family_for_name(name)
                        if member_family:
                            members.append((member_family, name))
            except OSError:
                return []
            return members

        try:
            if tarfile.is_tarfile(path):
                with tarfile.open(path) as archive:
                    for member in archive.getmembers():
                        member_family = self._family_for_name(member.name)
                        if member_family:
                            members.append((member_family, member.name))
        except (tarfile.TarError, OSError):
            return []
        return members

    def _family_for_name(self, name):
        suffixes = Path(name).suffixes
        for suffix in reversed(suffixes):
            family = self.EXTENSION_FAMILIES.get(suffix.lower())
            if family:
                return family
        return None

    def _apply_file_hints(self, recommendations, hints):
        if not recommendations or not hints:
            return recommendations

        enriched = []
        for item in recommendations:
            bonus = 0
            matched_families = set()
            haystack = f"{item['name']} {item['type']}".lower()
            for family, data in hints.items():
                family_hint = self.FILE_FAMILY_HINTS.get(family)
                if family_hint is None:
                    continue
                if item["type"] not in family_hint["types"]:
                    continue
                if any(pattern in haystack for pattern in family_hint["patterns"]):
                    bonus += data["weight"]
                    matched_families.add(family)

            item["score"] = item["usage_count"] + bonus
            if matched_families:
                item["matched_file_families"] = sorted(matched_families)
            enriched.append(item)
        return enriched
