import ast
import warnings

from collections import Counter, defaultdict
from pathlib import Path

from ctfsolver.config.global_config import CONFIG
from ctfsolver.managers.manager_class import ManagerClass


class _CallVisitor(ast.NodeVisitor):
    def __init__(self):
        self.self_calls = []
        self.other_calls = []

    def visit_Call(self, node):
        name = self._call_name(node.func)
        if name:
            if name.startswith("self."):
                self.self_calls.append(name[5:])
            else:
                self.other_calls.append(name)
        self.generic_visit(node)

    def _call_name(self, func):
        if isinstance(func, ast.Name):
            return func.id
        if isinstance(func, ast.Attribute):
            parts = []
            current = func
            while isinstance(current, ast.Attribute):
                parts.append(current.attr)
                current = current.value
            if isinstance(current, ast.Name):
                parts.append(current.id)
            return ".".join(reversed(parts))
        return None


class ManagerUsageScan:
    """
    One-off scan of historical Solution classes under the configured ctf_data root.
    """

    def __init__(self, ctf_root=None, package_root=None, framework_file=None):
        directories = CONFIG.content.get("directories", {})
        self.ctf_root = self._resolve_root(
            ctf_root if ctf_root is not None else directories.get("ctf_data")
        )
        self.package_root = (
            Path(package_root).resolve()
            if package_root is not None
            else Path(__file__).resolve().parents[1]
        )
        self.framework_file = (
            Path(framework_file).resolve()
            if framework_file is not None
            else self.package_root / "src" / "ctfsolver.py"
        )
        self.class_inspector = ManagerClass(search_paths=[self.package_root])

    def _resolve_root(self, root_value):
        if root_value is None:
            raise ValueError("ctf_data directory is not configured.")
        root = Path(root_value)
        if root.is_absolute():
            return root
        return Path.home() / root

    def get_framework_methods(self):
        info = self.class_inspector.inspect(
            self.framework_file, "CTFSolver", include_inherited=True
        )
        return set(info.get("methods", {}).keys())

    def iter_solution_files(self):
        if not self.ctf_root.exists():
            raise FileNotFoundError(f"CTF path does not exist: {self.ctf_root}")
        yield from sorted(self.ctf_root.rglob("solution.py"))

    def scan(self):
        framework_methods = self.get_framework_methods()
        solution_method_defs = Counter()
        internal_self_calls = Counter()
        framework_self_calls = Counter()
        unknown_self_calls = Counter()
        external_calls = Counter()
        files_using_framework_method = defaultdict(set)

        solution_file_count = 0
        solution_class_count = 0

        for path in self.iter_solution_files():
            solution_file_count += 1
            try:
                source = path.read_text(encoding="utf-8")
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore", SyntaxWarning)
                    tree = ast.parse(source, filename=str(path))
            except Exception:
                continue

            solution_node = None
            for node in tree.body:
                if isinstance(node, ast.ClassDef) and node.name == "Solution":
                    solution_node = node
                    break
            if solution_node is None:
                continue

            solution_class_count += 1
            method_names = set()
            for item in solution_node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    method_names.add(item.name)
                    solution_method_defs[item.name] += 1

            visitor = _CallVisitor()
            visitor.visit(solution_node)

            for call in visitor.self_calls:
                if call in method_names:
                    internal_self_calls[call] += 1
                elif call in framework_methods:
                    framework_self_calls[call] += 1
                    files_using_framework_method[call].add(path.as_posix())
                else:
                    unknown_self_calls[call] += 1

            for call in visitor.other_calls:
                external_calls[call] += 1

        return {
            "ctf_root": str(self.ctf_root),
            "solution_file_count": solution_file_count,
            "solution_class_count": solution_class_count,
            "solution_method_defs": solution_method_defs,
            "internal_self_calls": internal_self_calls,
            "framework_self_calls": framework_self_calls,
            "unknown_self_calls": unknown_self_calls,
            "external_calls": external_calls,
            "files_using_framework_method": {
                key: sorted(value) for key, value in files_using_framework_method.items()
            },
        }

    def build_summary_lines(self, analysis, limit=10):
        lines = [
            f"CTF root: {analysis['ctf_root']}",
            f"solution.py files found: {analysis['solution_file_count']}",
            f"files with a Solution class: {analysis['solution_class_count']}",
            "",
            "Top Solution method definitions:",
        ]
        lines.extend(self._format_counter(analysis["solution_method_defs"], limit))
        lines.extend(["", "Top framework self calls:"])
        lines.extend(self._format_counter(analysis["framework_self_calls"], limit, prefix="self."))
        lines.extend(["", "Top internal self calls:"])
        lines.extend(self._format_counter(analysis["internal_self_calls"], limit, prefix="self."))
        lines.extend(["", "Top unresolved self calls:"])
        lines.extend(self._format_counter(analysis["unknown_self_calls"], limit, prefix="self."))
        lines.extend(["", "Top non-self calls:"])
        lines.extend(self._format_counter(analysis["external_calls"], limit))
        lines.extend(["", "Sample files using top framework methods:"])

        if analysis["framework_self_calls"]:
            for name, _ in analysis["framework_self_calls"].most_common(limit):
                lines.append(f"  self.{name}:")
                for sample in analysis["files_using_framework_method"].get(name, [])[:3]:
                    lines.append(f"    - {sample}")
        else:
            lines.append("  None")

        return lines

    def _format_counter(self, counter, limit, prefix=""):
        if not counter:
            return ["  None"]
        return [f"  {prefix}{name}: {count}" for name, count in counter.most_common(limit)]
