import ast
import hashlib
import json
import warnings

from collections import Counter, defaultdict
from pathlib import Path

from ctfsolver.config.global_config import CONFIG
from ctfsolver.managers.manager_class import ManagerClass
from ctfsolver.managers.manager_file import ManagerFile
from ctfsolver.managers.manager_output import ManagerOutput


class _SolutionCallVisitor(ast.NodeVisitor):
    def __init__(self):
        self.self_calls = []
        self.other_calls = []

    def visit_Call(self, node):
        name = self._call_name(node.func)
        if name:
            if name.startswith("self."):
                self.self_calls.append(name[5:])
            else:
                self.other_calls.append(name)
        self.generic_visit(node)

    def _call_name(self, func):
        if isinstance(func, ast.Name):
            return func.id
        if isinstance(func, ast.Attribute):
            parts = []
            current = func
            while isinstance(current, ast.Attribute):
                parts.append(current.attr)
                current = current.value
            if isinstance(current, ast.Name):
                parts.append(current.id)
            return ".".join(reversed(parts))
        return None


class _ImportVisitor(ast.NodeVisitor):
    def __init__(self):
        self.imports = []

    def visit_Import(self, node):
        for alias in node.names:
            self.imports.append(alias.name)
        self.generic_visit(node)

    def visit_ImportFrom(self, node):
        module = node.module or ""
        for alias in node.names:
            self.imports.append(f"{module}.{alias.name}".strip("."))
        self.generic_visit(node)


class ManagerGathering:
    """
    Gather historical and current Solution functions with challenge provenance.
    """

    def __init__(
        self,
        manager_file=None,
        output_manager=None,
        ctf_root=None,
        package_root=None,
        framework_file=None,
    ):
        self.manager_file = manager_file or ManagerFile()
        self.output = output_manager or ManagerOutput()
        directories = CONFIG.content.get("directories", {})
        self.ctf_root = self._resolve_root(
            ctf_root if ctf_root is not None else directories.get("ctf_data")
        )
        self.package_root = (
            Path(package_root).resolve()
            if package_root is not None
            else Path(__file__).resolve().parents[1]
        )
        self.framework_file = (
            Path(framework_file).resolve()
            if framework_file is not None
            else self.package_root / "src" / "ctfsolver.py"
        )
        self.class_inspector = ManagerClass(search_paths=[self.package_root])

    def _resolve_root(self, root_value):
        if root_value is None:
            raise ValueError("ctf_data directory is not configured.")
        root = Path(root_value)
        if root.is_absolute():
            return root
        return Path.home() / root

    def get_framework_methods(self):
        info = self.class_inspector.inspect(
            self.framework_file, "CTFSolver", include_inherited=True
        )
        return set(info.get("methods", {}).keys())

    def iter_solution_files(self):
        if not self.ctf_root.exists():
            raise FileNotFoundError(f"CTF path does not exist: {self.ctf_root}")
        yield from sorted(self.ctf_root.rglob("solution.py"))

    def get_output_dir(self):
        output_dir = Path.cwd() / "docs" / "gather_data"
        output_dir.mkdir(parents=True, exist_ok=True)
        return output_dir

    def get_current_solution_file(self, path=None):
        if path is not None:
            return Path(path).resolve()
        solution_file = self.manager_file.get_solution_file(save=True)
        if solution_file is None:
            raise FileNotFoundError("Solution file not found in the payloads folder.")
        return Path(solution_file).resolve()

    def _safe_parse(self, source, path):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", SyntaxWarning)
            return ast.parse(source, filename=str(path))

    def _parse_metadata(self, solution_file):
        try:
            relative = solution_file.relative_to(self.ctf_root)
            parts = relative.parts
        except ValueError:
            parts = solution_file.parts

        category = parts[0] if len(parts) >= 1 else None
        site = parts[1] if len(parts) >= 2 else None
        challenge = parts[2] if len(parts) >= 3 else solution_file.parent.name

        if challenge in {"payloads", "payload", "src", "solution", "writeup"}:
            challenge = solution_file.parent.parent.name

        return {
            "category": category,
            "site": site,
            "challenge": challenge,
            "path": solution_file.as_posix(),
        }

    def analyze_solution_file(self, solution_file):
        solution_file = Path(solution_file).resolve()
        source = solution_file.read_text(encoding="utf-8")
        tree = self._safe_parse(source, solution_file)

        solution_node = None
        for node in tree.body:
            if isinstance(node, ast.ClassDef) and node.name == "Solution":
                solution_node = node
                break
        if solution_node is None:
            return None

        import_visitor = _ImportVisitor()
        import_visitor.visit(tree)

        visitor = _SolutionCallVisitor()
        visitor.visit(solution_node)

        framework_methods = self.get_framework_methods()
        methods = []
        local_method_names = set()

        for item in solution_node.body:
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                local_method_names.add(item.name)

        for item in solution_node.body:
            if not isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            try:
                source_segment = ast.get_source_segment(source, item) or ast.unparse(item)
            except Exception:
                source_segment = None
            ast_dump = ast.dump(item, annotate_fields=False, include_attributes=False)
            source_hash = hashlib.sha256((source_segment or "").encode("utf-8")).hexdigest()
            ast_hash = hashlib.sha256(ast_dump.encode("utf-8")).hexdigest()

            method_visitor = _SolutionCallVisitor()
            method_visitor.visit(item)
            local_calls = Counter(method_visitor.self_calls)
            framework_calls = Counter()
            unresolved_self_calls = Counter()
            for call_name, count in local_calls.items():
                if call_name in framework_methods:
                    framework_calls[call_name] += count
                elif call_name not in local_method_names:
                    unresolved_self_calls[call_name] += count

            methods.append(
                {
                    "name": item.name,
                    "lineno": getattr(item, "lineno", None),
                    "source": source_segment,
                    "source_hash": source_hash,
                    "ast_hash": ast_hash,
                    "local_self_calls": sorted(
                        call for call in method_visitor.self_calls if call in local_method_names
                    ),
                    "framework_self_calls": sorted(
                        call for call in method_visitor.self_calls if call in framework_methods
                    ),
                    "unresolved_self_calls": sorted(
                        call
                        for call in method_visitor.self_calls
                        if call not in local_method_names and call not in framework_methods
                    ),
                    "external_calls": sorted(set(method_visitor.other_calls)),
                }
            )

        return {
            "challenge": self._parse_metadata(solution_file),
            "imports": sorted(set(import_visitor.imports)),
            "methods": methods,
            "framework_methods_used": sorted(
                {call for call in visitor.self_calls if call in framework_methods}
            ),
            "internal_methods_used": sorted(
                {call for call in visitor.self_calls if call in local_method_names}
            ),
            "unknown_self_calls": sorted(
                {
                    call
                    for call in visitor.self_calls
                    if call not in local_method_names and call not in framework_methods
                }
            ),
            "external_calls": sorted(set(visitor.other_calls)),
        }

    def gather_corpus(self):
        entries = []
        for solution_file in self.iter_solution_files():
            entry = self.analyze_solution_file(solution_file)
            if entry is not None:
                entries.append(entry)
        index = self.build_function_index(entries)
        duplicates = self.build_duplicate_groups(index)
        return {
            "ctf_root": self.ctf_root.as_posix(),
            "entries": entries,
            "index": index,
            "duplicates": duplicates,
            "stats": self.build_corpus_stats(entries, duplicates),
        }

    def build_function_index(self, entries):
        index = {}
        for entry in entries:
            challenge = entry["challenge"]
            for method in entry["methods"]:
                index_key = method["ast_hash"]
                record = index.setdefault(
                    index_key,
                    {
                        "name": method["name"],
                        "ast_hash": method["ast_hash"],
                        "source_hash": method["source_hash"],
                        "source": method["source"],
                        "occurrences": [],
                    },
                )
                record["occurrences"].append(
                    {
                        "category": challenge["category"],
                        "site": challenge["site"],
                        "challenge": challenge["challenge"],
                        "path": challenge["path"],
                        "method": method["name"],
                        "lineno": method["lineno"],
                    }
                )
        return index

    def build_duplicate_groups(self, index):
        groups = []
        for record in index.values():
            provenance = {
                (item["category"], item["site"], item["challenge"], item["method"])
                for item in record["occurrences"]
            }
            if len(provenance) <= 1:
                continue
            groups.append(
                {
                    "name": record["name"],
                    "ast_hash": record["ast_hash"],
                    "source_hash": record["source_hash"],
                    "occurrences": sorted(
                        record["occurrences"],
                        key=lambda item: (
                            item["category"] or "",
                            item["site"] or "",
                            item["challenge"] or "",
                            item["method"],
                        ),
                    ),
                }
            )
        return sorted(groups, key=lambda item: (-len(item["occurrences"]), item["name"]))

    def build_corpus_stats(self, entries, duplicates):
        method_names = Counter()
        framework_usage = Counter()
        external_calls = Counter()
        imports = Counter()

        for entry in entries:
            imports.update(entry["imports"])
            external_calls.update(entry["external_calls"])
            framework_usage.update(entry["framework_methods_used"])
            for method in entry["methods"]:
                method_names[method["name"]] += 1

        return {
            "solution_count": len(entries),
            "method_names": method_names,
            "framework_usage": framework_usage,
            "external_calls": external_calls,
            "imports": imports,
            "duplicate_group_count": len(duplicates),
        }

    def gather_file(self, path=None):
        solution_file = self.get_current_solution_file(path=path)
        file_entry = self.analyze_solution_file(solution_file)
        if file_entry is None:
            raise ValueError(f"No Solution class found in {solution_file}")
        corpus = self.gather_corpus()
        matches = self.match_file_against_corpus(file_entry, corpus["index"])
        return {
            "solution_file": solution_file.as_posix(),
            "entry": file_entry,
            "matches": matches,
        }

    def match_file_against_corpus(self, file_entry, corpus_index):
        exact_matches = []
        name_matches = defaultdict(list)

        current_path = file_entry["challenge"]["path"]
        for method in file_entry["methods"]:
            index_record = corpus_index.get(method["ast_hash"])
            if index_record is not None:
                previous = [
                    item
                    for item in index_record["occurrences"]
                    if item["path"] != current_path
                ]
                if previous:
                    exact_matches.append(
                        {
                            "method": method["name"],
                            "origin_challenges": previous,
                        }
                    )

        for record in corpus_index.values():
            for occurrence in record["occurrences"]:
                if occurrence["path"] == current_path:
                    continue
                name_matches[occurrence["method"]].append(occurrence)

        same_name_matches = []
        for method in file_entry["methods"]:
            previous = name_matches.get(method["name"], [])
            if previous:
                same_name_matches.append(
                    {"method": method["name"], "origin_challenges": previous}
                )

        return {
            "exact_or_structural": exact_matches,
            "same_name": same_name_matches,
        }

    def build_corpus_summary_lines(self, corpus, limit=10):
        stats = corpus["stats"]
        lines = [
            "# Gather Corpus Summary",
            "",
            f"- CTF root: {corpus['ctf_root']}",
            f"- Solutions analyzed: {stats['solution_count']}",
            f"- Duplicate groups: {stats['duplicate_group_count']}",
            "",
            "## Most Common Solution Methods",
        ]
        lines.extend(self._counter_lines(stats["method_names"], limit))
        lines.extend(["", "## Most Used Framework Methods"])
        lines.extend(self._counter_lines(stats["framework_usage"], limit, prefix="self."))
        lines.extend(["", "## Most Common External Calls"])
        lines.extend(self._counter_lines(stats["external_calls"], limit))
        lines.extend(["", "## Most Common Imports"])
        lines.extend(self._counter_lines(stats["imports"], limit))
        lines.extend(["", "## Duplicate Function Groups"])
        if corpus["duplicates"]:
            for group in corpus["duplicates"][:limit]:
                lines.append(f"- {group['name']} ({len(group['occurrences'])} occurrences)")
                for occurrence in group["occurrences"][:5]:
                    lines.append(
                        f"  - {occurrence['category']}/{occurrence['site']}/{occurrence['challenge']} [{occurrence['method']}]"
                    )
        else:
            lines.append("- None")
        return lines

    def build_duplicates_summary_lines(self, corpus, limit=20):
        lines = [
            "# Gather Duplicate Functions",
            "",
            f"- Duplicate groups: {len(corpus['duplicates'])}",
            "",
        ]
        if not corpus["duplicates"]:
            lines.append("- None")
            return lines

        for group in corpus["duplicates"][:limit]:
            lines.append(f"## {group['name']}")
            lines.append(f"- Occurrences: {len(group['occurrences'])}")
            for occurrence in group["occurrences"]:
                lines.append(
                    f"- {occurrence['category']}/{occurrence['site']}/{occurrence['challenge']} :: {occurrence['method']} :: {occurrence['path']}"
                )
            lines.append("")
        return lines

    def build_file_summary_lines(self, gathered_file):
        entry = gathered_file["entry"]
        challenge = entry["challenge"]
        lines = [
            "# Gather File Summary",
            "",
            f"- Solution file: {gathered_file['solution_file']}",
            f"- Category: {challenge['category']}",
            f"- Site: {challenge['site']}",
            f"- Challenge: {challenge['challenge']}",
            "",
            "## Local Functions",
        ]
        for method in entry["methods"]:
            lines.append(f"- {method['name']}")
            lines.append(
                f"  - framework calls: {', '.join(method['framework_self_calls']) or 'None'}"
            )
            lines.append(
                f"  - local calls: {', '.join(method['local_self_calls']) or 'None'}"
            )
            lines.append(
                f"  - external calls: {', '.join(method['external_calls']) or 'None'}"
            )
        if not entry["methods"]:
            lines.append("- None")
        lines.extend(["", "## Historical Matches"])
        if gathered_file["matches"]["exact_or_structural"]:
            for match in gathered_file["matches"]["exact_or_structural"]:
                lines.append(f"- {match['method']}")
                for occurrence in match["origin_challenges"][:5]:
                    lines.append(
                        f"  - {occurrence['category']}/{occurrence['site']}/{occurrence['challenge']}"
                    )
        else:
            lines.append("- None")
        lines.extend(["", "## Same-Name Historical Matches"])
        if gathered_file["matches"]["same_name"]:
            for match in gathered_file["matches"]["same_name"]:
                lines.append(f"- {match['method']}")
                for occurrence in match["origin_challenges"][:5]:
                    lines.append(
                        f"  - {occurrence['category']}/{occurrence['site']}/{occurrence['challenge']}"
                    )
        else:
            lines.append("- None")
        return lines

    def _counter_lines(self, counter, limit, prefix=""):
        if not counter:
            return ["- None"]
        return [f"- {prefix}{name}: {count}" for name, count in counter.most_common(limit)]

    def write_output(self, filename, lines, payload):
        output_dir = self.get_output_dir()
        markdown_path = output_dir / f"{filename}.md"
        json_path = output_dir / f"{filename}.json"
        markdown_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        json_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return output_dir, markdown_path, json_path

    def build_output_summary(self, output_dir, markdown_path, json_path):
        """
        Builds a stable plain-text summary for CLI and service workflows after
        gather data has been written to disk.
        """
        return self.output.format_kv(
            {
                "Output directory": output_dir,
                "Summary": markdown_path,
                "JSON Summary": json_path,
            }
        )
