import shutil
import subprocess
import json
import re

from pathlib import Path

from ctfsolver.managers.manager_output import ManagerOutput


class ManagerVolatilityRunner:
    """
    Optional memory-forensics helper around the Volatility CLI.

    This is intentionally isolated from the core CTFSolver inheritance tree.
    """

    WINDOWS_PLUGINS = [
        "windows.info.Info",
        "windows.pslist.PsList",
        "windows.netscan.NetScan",
        "windows.cmdline.CmdLine",
        "windows.filescan.FileScan",
    ]
    LINUX_PLUGINS = [
        "linux.banner.Banner",
        "linux.pslist.PsList",
        "linux.lsof.Lsof",
        "linux.sockstat.Sockstat",
        "linux.bash.Bash",
    ]
    PROBE_PLUGINS = {
        "windows": "windows.info.Info",
        "linux": "linux.banner.Banner",
    }

    MEMORY_EXTENSIONS = {".mem", ".raw", ".dmp", ".img", ".bin", ".lime"}

    def __init__(
        self,
        manager_file=None,
        executable=None,
        process_runner=None,
        output_manager=None,
    ):
        if manager_file is None:
            from ctfsolver.managers.manager_file import ManagerFile

            manager_file = ManagerFile(init_for_challenge=False)
        self.manager_file = manager_file
        self.executable = executable
        self.process_runner = process_runner or subprocess.run
        self.output = output_manager or ManagerOutput()

    def resolve_executable(self):
        if self.executable:
            return self.executable

        for candidate in ("vol", "volatility3"):
            found = shutil.which(candidate)
            if found:
                self.executable = found
                return found

        raise FileNotFoundError(
            "Volatility executable not found. Install `vol` or `volatility3`, or pass an explicit executable."
        )

    def prepare_context(self, file=None):
        self.manager_file.get_current_dir()
        current_path = Path(self.manager_file.parent)
        folder_names = set(getattr(self.manager_file, "folders_name_list", []))
        if current_path.name in folder_names:
            current_path = current_path.parent

        self.manager_file.parent = current_path
        self.manager_file.setup_named_folders()
        self.manager_file.file = file
        self.manager_file.challenge_file = self.find_memory_file(file=file)
        return self.manager_file.challenge_file

    def find_memory_file(self, file=None):
        if file is not None:
            candidate = Path(file)
            if not candidate.is_absolute():
                candidate = self.manager_file.folder_files / candidate
            if not candidate.exists():
                raise FileNotFoundError(f"Memory image not found: {candidate}")
            return candidate

        files = [path for path in self.manager_file.folder_files.iterdir() if path.is_file()]
        if len(files) == 1:
            return files[0]

        memory_candidates = [
            path for path in files if path.suffix.lower() in self.MEMORY_EXTENSIONS
        ]
        if len(memory_candidates) == 1:
            return memory_candidates[0]

        raise ValueError(
            "Could not determine the memory image automatically. Pass --file with a file from the files directory."
        )

    def create_output_dir(self, base_name="vol_data"):
        self.manager_file.folder_data.mkdir(parents=True, exist_ok=True)
        candidate = self.manager_file.folder_data / base_name
        if not candidate.exists():
            candidate.mkdir()
            return candidate

        index = 1
        while True:
            candidate = self.manager_file.folder_data / f"{base_name}_{index:02d}"
            if not candidate.exists():
                candidate.mkdir()
                return candidate
            index += 1

    def create_symbols_dir(self, output_dir):
        symbols_dir = output_dir / "symbols"
        symbols_dir.mkdir(parents=True, exist_ok=True)
        return symbols_dir

    def build_command(self, plugin, symbols_dir):
        executable = self.resolve_executable()
        return [
            executable,
            "-f",
            str(self.manager_file.challenge_file),
            "-s",
            str(symbols_dir),
            plugin,
        ]

    def sanitize_plugin_name(self, plugin):
        return plugin.replace(".", "_")

    def run_plugin(self, plugin, output_dir, symbols_dir):
        command = self.build_command(plugin, symbols_dir)
        result = self.process_runner(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=False,
        )
        output_file = output_dir / f"{self.sanitize_plugin_name(plugin)}.txt"
        output_file.write_text(result.stdout or "", encoding="utf-8")
        if result.stderr:
            error_file = output_dir / f"{self.sanitize_plugin_name(plugin)}.stderr.txt"
            error_file.write_text(result.stderr, encoding="utf-8")
        return {
            "plugin": plugin,
            "command": command,
            "returncode": result.returncode,
            "output_file": output_file,
            "stderr": result.stderr or "",
        }

    def write_summary(self, output_dir, results):
        summary_path = output_dir / "summary.md"
        lines = [
            "# Volatility Triage",
            "",
            f"- Memory image: {self.manager_file.challenge_file}",
            f"- Output directory: {output_dir}",
            "",
            "## Plugins",
        ]
        for result in results:
            lines.append(
                f"- `{result['plugin']}`: return code {result['returncode']} -> {result['output_file'].name}"
            )
        summary_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return summary_path

    def parse_flag_candidates(self, text):
        patterns = [
            r"flag\{[^}\n]+\}",
            r"ctf\{[^}\n]+\}",
            r"picoctf\{[^}\n]+\}",
        ]
        found = []
        for pattern in patterns:
            found.extend(re.findall(pattern, text, flags=re.IGNORECASE))
        return sorted(set(found))

    def collect_findings(self, results):
        findings = {
            "suspicious_processes": [],
            "network_indicators": [],
            "command_lines": [],
            "file_paths": [],
            "flag_candidates": [],
        }

        process_keywords = ("powershell", "cmd.exe", "rundll32", "wmic", "certutil", "curl", "wget", "nc", "ncat")
        network_keywords = ("ESTABLISHED", "LISTEN", "TCP", "UDP", ":80", ":443", ":1337", ":4444")

        for result in results:
            text = result["output_file"].read_text(encoding="utf-8", errors="ignore")
            lines = [line.strip() for line in text.splitlines() if line.strip()]

            if "pslist" in result["plugin"].lower():
                for line in lines:
                    if any(keyword.lower() in line.lower() for keyword in process_keywords):
                        findings["suspicious_processes"].append(line)

            if any(token in result["plugin"].lower() for token in ("netscan", "netstat", "sockstat")):
                for line in lines:
                    if any(keyword.lower() in line.lower() for keyword in network_keywords):
                        findings["network_indicators"].append(line)

            if any(token in result["plugin"].lower() for token in ("cmdline", "bash")):
                for line in lines:
                    lowered = line.lower()
                    if lowered.startswith(("pid", "volatility", "progress")):
                        continue
                    findings["command_lines"].append(line)

            if any(token in result["plugin"].lower() for token in ("filescan", "lsof")):
                for line in lines:
                    if "\\" in line or "/" in line:
                        findings["file_paths"].append(line)

            findings["flag_candidates"].extend(self.parse_flag_candidates(text))

        for key in findings:
            findings[key] = sorted(set(findings[key]))

        return findings

    def write_findings_summary(self, output_dir, findings, operating_system):
        summary_path = output_dir / "summary.md"
        lines = [
            "# Volatility Autosolve Summary",
            "",
            f"- Memory image: {self.manager_file.challenge_file}",
            f"- Detected OS: {operating_system}",
            f"- Output directory: {output_dir}",
            "",
            "## Suspicious Processes",
        ]
        lines.extend([f"- {item}" for item in findings["suspicious_processes"]] or ["- None"])
        lines.extend(["", "## Network Indicators"])
        lines.extend([f"- {item}" for item in findings["network_indicators"]] or ["- None"])
        lines.extend(["", "## Command Lines"])
        lines.extend([f"- {item}" for item in findings["command_lines"]] or ["- None"])
        lines.extend(["", "## File Paths"])
        lines.extend([f"- {item}" for item in findings["file_paths"]] or ["- None"])
        lines.extend(["", "## Flag Candidates"])
        lines.extend([f"- {item}" for item in findings["flag_candidates"]] or ["- None"])
        summary_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return summary_path

    def write_findings_json(self, output_dir, findings, operating_system):
        summary_json_path = output_dir / "summary.json"
        payload = {
            "memory_image": str(self.manager_file.challenge_file),
            "operating_system": operating_system,
            "findings": findings,
        }
        summary_json_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return summary_json_path

    def detect_operating_system(self, output_dir):
        symbols_dir = self.create_symbols_dir(output_dir)
        for operating_system, plugin in self.PROBE_PLUGINS.items():
            result = self.run_plugin(plugin, output_dir, symbols_dir)
            if result["returncode"] == 0:
                return operating_system, result
        return "unknown", None

    def get_triage_plugins(self, operating_system):
        if operating_system == "windows":
            return list(self.WINDOWS_PLUGINS)
        if operating_system == "linux":
            return list(self.LINUX_PLUGINS)
        return list(self.PROBE_PLUGINS.values())

    def run_plugins(self, plugins, output_dir, symbols_dir):
        return [self.run_plugin(plugin, output_dir, symbols_dir) for plugin in plugins]

    def triage(self, file=None, plugins=None):
        self.prepare_context(file=file)
        output_dir = self.create_output_dir()
        symbols_dir = self.create_symbols_dir(output_dir)
        operating_system = "unknown"
        detection_result = None
        if plugins is None:
            operating_system, detection_result = self.detect_operating_system(output_dir)
            plugins = self.get_triage_plugins(operating_system)
            if detection_result is not None:
                results = [detection_result]
                remaining_plugins = [plugin for plugin in plugins if plugin != detection_result["plugin"]]
                results.extend(self.run_plugins(remaining_plugins, output_dir, symbols_dir))
            else:
                results = self.run_plugins(plugins, output_dir, symbols_dir)
        else:
            results = self.run_plugins(plugins, output_dir, symbols_dir)
        summary_path = self.write_summary(output_dir, results)
        return {
            "challenge_file": self.manager_file.challenge_file,
            "output_dir": output_dir,
            "summary_path": summary_path,
            "operating_system": operating_system,
            "results": results,
        }

    def run(self, file=None, plugins=None):
        if not plugins:
            raise ValueError("At least one plugin must be provided.")
        self.prepare_context(file=file)
        output_dir = self.create_output_dir()
        symbols_dir = self.create_symbols_dir(output_dir)
        results = self.run_plugins(plugins, output_dir, symbols_dir)
        summary_path = self.write_summary(output_dir, results)
        return {
            "challenge_file": self.manager_file.challenge_file,
            "output_dir": output_dir,
            "summary_path": summary_path,
            "results": results,
        }

    def autosolve(self, file=None):
        triage_result = self.triage(file=file)
        findings = self.collect_findings(triage_result["results"])
        summary_path = self.write_findings_summary(
            triage_result["output_dir"], findings, triage_result["operating_system"]
        )
        summary_json_path = self.write_findings_json(
            triage_result["output_dir"], findings, triage_result["operating_system"]
        )
        triage_result["findings"] = findings
        triage_result["summary_path"] = summary_path
        triage_result["summary_json_path"] = summary_json_path
        return triage_result

    def build_cli_summary(self, result, mode, include_details=False):
        """
        Builds a stable plain-text summary for the mem CLI commands.

        Args:
            result: Result dictionary returned by `triage`, `run`, or
                `autosolve`.
            mode: One of `triage`, `run`, or `autosolve`.
            include_details: When `True`, includes plugin or finding counts.

        Returns:
            Plain-text summary formatted through the shared output layer.
        """
        fields = {
            "Memory image": result["challenge_file"],
            "Output directory": result["output_dir"],
        }
        if "operating_system" in result:
            fields["Detected OS"] = result["operating_system"]
        if "summary_path" in result and mode == "autosolve":
            fields["Summary"] = result["summary_path"]
        if "summary_json_path" in result and mode == "autosolve":
            fields["JSON Summary"] = result["summary_json_path"]

        lines = [self.output.format_kv(fields)]

        if include_details and "results" in result:
            plugin_rows = [
                [item["plugin"], item["returncode"], item["output_file"]]
                for item in result["results"]
            ]
            lines.extend(
                [
                    "",
                    self.output.format_section(
                        "Plugins",
                        [
                            self.output.format_table(
                                plugin_rows,
                                headers=["Plugin", "RC", "Output"],
                            )
                        ],
                    ),
                ]
            )

        if include_details and mode == "autosolve" and "findings" in result:
            finding_counts = {
                key: len(values) for key, values in sorted(result["findings"].items())
            }
            lines.extend(
                [
                    "",
                    self.output.format_section(
                        "Finding Counts",
                        [self.output.format_kv(finding_counts)],
                    ),
                ]
            )

        return "\n".join(line for line in lines if line)
