"""
Workflow-oriented PCAP analysis helpers for the CLI and forensics tooling.

This module sits above the low-level Scapy packet helpers and the optional Dash
visualizer. It builds summaries, extracts common CTF-relevant artifacts, and
offers a thin optional bridge to `tshark` without forcing that dependency on
all environments.
"""

from __future__ import annotations

import base64
import re
from collections import Counter
from pathlib import Path
from urllib.parse import unquote

from ctfsolver.managers.manager_flag import ManagerFlag
from ctfsolver.managers.manager_output import ManagerOutput


class ManagerPcapAnalyzer:
    """
    High-level PCAP workflow manager for summary, extraction, graphing, and
    optional `tshark` execution.

    The manager keeps optional dependencies isolated:

    - `scapy` is only required when a capture is actually opened.
    - `dash` and `dash_cytoscape` are only required when the graph workflow is
      requested.
    - `tshark` is treated as a runtime-checked external tool rather than a
      Python dependency.
    """

    TSHARK_PRESETS = {
        "http": [
            "-Y",
            "http",
            "-T",
            "fields",
            "-e",
            "frame.number",
            "-e",
            "ip.src",
            "-e",
            "ip.dst",
            "-e",
            "http.host",
            "-e",
            "http.request.method",
            "-e",
            "http.request.uri",
        ],
        "dns": [
            "-Y",
            "dns",
            "-T",
            "fields",
            "-e",
            "frame.number",
            "-e",
            "ip.src",
            "-e",
            "ip.dst",
            "-e",
            "dns.qry.name",
            "-e",
            "dns.a",
        ],
        "credentials": [
            "-Y",
            "http.authorization || ftp.request.command == USER || ftp.request.command == PASS",
            "-V",
        ],
        "streams": ["-T", "fields", "-e", "tcp.stream"],
        "objects": ["--export-objects", "http,objects"],
        "conversations": ["-q", "-z", "conv,ip"],
    }

    def __init__(self, *args, **kwargs):
        """
        Initializes the analyzer with composable managers.

        Args:
            manager_file: Optional file/tool helper surface. Defaults to a
                `ManagerFile` instance.
            output_manager: Optional shared output layer.
            flag_manager: Optional flag extraction helper.
            dash_manager: Optional graph manager. If omitted, the Dash manager
                is imported lazily only when graphing is requested.
        """
        self.output = kwargs.get("output_manager", None) or ManagerOutput()
        manager_file = kwargs.get("manager_file", None)
        if manager_file is None:
            from ctfsolver.managers.manager_file import ManagerFile

            manager_file = ManagerFile(output_manager=self.output)
        self.manager_file = manager_file
        self.flag_manager = kwargs.get("flag_manager", None) or ManagerFlag(
            output_manager=self.output
        )
        self._dash_manager = kwargs.get("dash_manager", None)
        self.packets = []
        self.capture_file = None

    def load_capture(self, file):
        """
        Opens a PCAP file with the existing `ManagerFilePcap` functionality and
        stores both the resolved path and the packet list on the analyzer.
        """
        path = Path(file).expanduser().resolve()
        self.capture_file = path
        self.packets = self.manager_file.pcap_open(file=path, save=True)
        return self.packets

    def build_capture_summary(self, packets=None) -> dict:
        """
        Builds a structured summary of the packet set.

        Returns a dictionary rather than formatted text so the CLI, tests, and
        future machine-readable outputs can all reuse the same analysis.
        """
        packets = self._resolve_packets(packets)
        protocols = Counter()
        conversations = Counter()
        talkers = Counter()
        ports = Counter()
        timestamps = []

        for packet in packets:
            for protocol in self._packet_protocols(packet):
                protocols[protocol] += 1

            src, dst = self._packet_endpoints(packet)
            if src:
                talkers[src] += 1
            if dst:
                talkers[dst] += 1
            if src and dst:
                conversations[(src, dst)] += 1

            for port in self._packet_ports(packet):
                ports[port] += 1

            timestamp = self._packet_time(packet)
            if timestamp is not None:
                timestamps.append(timestamp)

        return {
            "capture_file": str(self.capture_file) if self.capture_file else None,
            "packet_count": len(packets),
            "protocols": dict(
                sorted(protocols.items(), key=lambda item: (-item[1], item[0]))
            ),
            "conversations": [
                {"src": src, "dst": dst, "count": count}
                for (src, dst), count in sorted(
                    conversations.items(),
                    key=lambda item: (-item[1], item[0][0], item[0][1]),
                )[:10]
            ],
            "top_talkers": [
                {"host": host, "count": count}
                for host, count in sorted(
                    talkers.items(), key=lambda item: (-item[1], item[0])
                )[:10]
            ],
            "ports": [
                {"port": port, "count": count}
                for port, count in sorted(
                    ports.items(), key=lambda item: (-item[1], item[0])
                )[:10]
            ],
            "has_http": "HTTP" in protocols or any(
                port in ports for port in (80, 443, 8080, 8000)
            ),
            "has_dns": "DNS" in protocols or 53 in ports,
            "has_tcp": "TCP" in protocols,
            "has_udp": "UDP" in protocols,
            "first_timestamp": min(timestamps) if timestamps else None,
            "last_timestamp": max(timestamps) if timestamps else None,
        }

    def build_summary_text(self, summary: dict) -> str:
        """
        Renders the structured capture summary into deterministic plain text for
        the CLI and docs.
        """
        header = self.output.format_kv(
            {
                "Capture file": summary.get("capture_file") or "(not stored)",
                "Packets": summary.get("packet_count", 0),
                "HTTP seen": summary.get("has_http", False),
                "DNS seen": summary.get("has_dns", False),
                "TCP seen": summary.get("has_tcp", False),
                "UDP seen": summary.get("has_udp", False),
                "First timestamp": summary.get("first_timestamp"),
                "Last timestamp": summary.get("last_timestamp"),
            },
            title="Capture Summary",
        )

        protocol_rows = [
            [name, count] for name, count in summary.get("protocols", {}).items()
        ]
        conversation_rows = [
            [item["src"], item["dst"], item["count"]]
            for item in summary.get("conversations", [])
        ]
        talker_rows = [
            [item["host"], item["count"]] for item in summary.get("top_talkers", [])
        ]
        port_rows = [
            [item["port"], item["count"]] for item in summary.get("ports", [])
        ]

        sections = [header]
        sections.append(
            self.output.format_section(
                "Protocols",
                [self.output.format_table(protocol_rows, headers=["Protocol", "Count"])],
            )
        )
        sections.append(
            self.output.format_section(
                "Top Talkers",
                [self.output.format_table(talker_rows, headers=["Host", "Count"])],
            )
        )
        sections.append(
            self.output.format_section(
                "Top Conversations",
                [
                    self.output.format_table(
                        conversation_rows, headers=["Source", "Target", "Count"]
                    )
                ],
            )
        )
        sections.append(
            self.output.format_section(
                "Ports",
                [self.output.format_table(port_rows, headers=["Port", "Count"])],
            )
        )
        return "\n\n".join(sections)

    def extract_printable_payloads(
        self, packets=None, min_length=4, limit=None
    ) -> list[str]:
        """
        Extracts printable payload strings from raw packet payloads.
        """
        packets = self._resolve_packets(packets)
        payloads = []

        for packet in packets:
            raw_bytes = self._packet_raw_bytes(packet)
            if not raw_bytes:
                continue
            text = self._to_printable_text(raw_bytes, min_length=min_length)
            if text:
                payloads.append(text)

        if limit is not None:
            return payloads[:limit]
        return payloads

    def extract_http_artifacts(self, packets=None) -> dict:
        """
        Extracts likely HTTP-oriented artifacts from printable packet payloads.

        The output is intentionally heuristic. It reports interesting candidates
        with provenance value for the operator rather than claiming certainty.
        """
        payloads = self.extract_printable_payloads(packets=packets)
        urls = []
        cookies = []
        tokens = []
        credentials = []
        methods = []
        hosts = []
        filenames = []

        for payload in payloads:
            urls.extend(re.findall(r"https?://[^\s\"'>]+", payload))
            methods.extend(
                match.group(1)
                for match in re.finditer(
                    r"\b(GET|POST|PUT|DELETE|HEAD|OPTIONS|PATCH)\b", payload
                )
            )
            hosts.extend(
                match.group(1).strip()
                for match in re.finditer(r"(?im)^Host:\s*([^\r\n]+)", payload)
            )
            cookies.extend(
                match.group(1).strip()
                for match in re.finditer(r"(?im)^Cookie:\s*([^\r\n]+)", payload)
            )
            tokens.extend(
                match.group(1).strip()
                for match in re.finditer(
                    r"(?im)^(?:Authorization:\s*Bearer|Token:\s*|X-Api-Key:\s*|api_key=|token=)([^\s\r\n;&]+)",
                    payload,
                )
            )

            for match in re.finditer(
                r"(?im)^Authorization:\s*Basic\s+([A-Za-z0-9+/=]+)", payload
            ):
                encoded = match.group(1)
                try:
                    decoded = base64.b64decode(encoded).decode(
                        "utf-8", errors="ignore"
                    )
                except Exception:
                    decoded = None
                credentials.append(
                    {
                        "type": "http_basic",
                        "value": decoded or encoded,
                        "encoded": encoded,
                    }
                )

            for match in re.finditer(
                r"(?i)\b(?:password|passwd|pwd|pass|username|user|login)=([^&\s]+)",
                payload,
            ):
                credentials.append(
                    {"type": "parameter", "value": unquote(match.group(1))}
                )

            filenames.extend(
                match.group(1).strip("\"'")
                for match in re.finditer(
                    r'(?im)(?:filename\*?=|name=)([^;\r\n]+)', payload
                )
            )

        if not urls and hosts and methods:
            for host in hosts:
                urls.append(f"http://{host}")

        return {
            "urls": self._unique(urls),
            "hosts": self._unique(hosts),
            "methods": self._unique(methods),
            "cookies": self._unique(cookies),
            "tokens": self._unique(tokens),
            "credentials": credentials,
            "filenames": self._unique(filenames),
        }

    def extract_dns_artifacts(self, packets=None) -> dict:
        """
        Extracts DNS-like indicators from packets by checking DNS layers first
        and falling back to hostname-like string patterns in payloads.
        """
        packets = self._resolve_packets(packets)
        queries = []
        answers = []

        for packet in packets:
            if packet.haslayer("DNS"):
                dns_layer = packet["DNS"]
                qname = getattr(dns_layer, "qname", None)
                rrname = getattr(dns_layer, "rrname", None)
                if qname:
                    queries.append(self._decode_possible_bytes(qname))
                if rrname:
                    answers.append(self._decode_possible_bytes(rrname))

        if not queries and not answers:
            for payload in self.extract_printable_payloads(packets=packets):
                queries.extend(
                    re.findall(r"\b(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}\b", payload)
                )

        return {"queries": self._unique(queries), "answers": self._unique(answers)}

    def extract_flag_candidates(self, packets=None, prefixes=None) -> list[str]:
        """
        Reuses `ManagerFlag` to extract likely flag strings from printable
        packet payloads.
        """
        payloads = self.extract_printable_payloads(packets=packets)
        return self.flag_manager.extract_flags("\n".join(payloads), prefixes=prefixes)

    def extract_file_artifacts(self, packets=None) -> dict:
        """
        Extracts filename and MIME-like hints from packet payloads.
        """
        payloads = self.extract_printable_payloads(packets=packets)
        filenames = []
        mime_types = []

        for payload in payloads:
            filenames.extend(
                match.group(1).strip("\"'")
                for match in re.finditer(
                    r'(?im)(?:filename\*?=|name=)([^;\r\n]+)', payload
                )
            )
            mime_types.extend(
                match.group(1).strip()
                for match in re.finditer(r"(?im)^Content-Type:\s*([^\r\n;]+)", payload)
            )

        return {
            "filenames": self._unique(filenames),
            "mime_types": self._unique(mime_types),
        }

    def extract_artifacts(self, packets=None) -> dict:
        """
        Runs the main practical extraction passes and returns a combined report.
        """
        packets = self._resolve_packets(packets)
        payloads = self.extract_printable_payloads(packets=packets)
        http = self.extract_http_artifacts(packets=packets)
        dns = self.extract_dns_artifacts(packets=packets)
        files = self.extract_file_artifacts(packets=packets)
        flags = self.extract_flag_candidates(packets=packets)

        return {
            "payload_count": len(payloads),
            "payload_samples": payloads[:10],
            "http": http,
            "dns": dns,
            "files": files,
            "flags": flags,
        }

    def build_extraction_text(self, artifacts: dict) -> str:
        """
        Formats the combined extraction report for CLI use.
        """
        credentials = [
            item["value"] if isinstance(item, dict) else item
            for item in artifacts.get("http", {}).get("credentials", [])
        ]

        sections = [
            self.output.format_kv(
                {"Printable payloads": artifacts.get("payload_count", 0)},
                title="Extraction Summary",
            ),
            self.output.format_list(
                artifacts.get("flags", []), title="Flag Candidates"
            ),
            self.output.format_list(
                artifacts.get("http", {}).get("urls", []), title="HTTP URLs"
            ),
            self.output.format_list(credentials, title="Credential Candidates"),
            self.output.format_list(
                artifacts.get("http", {}).get("cookies", []), title="Cookies"
            ),
            self.output.format_list(
                artifacts.get("http", {}).get("tokens", []), title="Tokens"
            ),
            self.output.format_list(
                artifacts.get("dns", {}).get("queries", []), title="DNS Queries"
            ),
            self.output.format_list(
                artifacts.get("files", {}).get("filenames", []), title="File Names"
            ),
            self.output.format_list(
                artifacts.get("payload_samples", []), title="Payload Samples"
            ),
        ]
        return "\n\n".join(sections)

    def has_tshark(self) -> bool:
        """
        Returns whether `tshark` is available on the current system `PATH`.
        """
        return self.manager_file.tool_exists("tshark")

    def list_tshark_presets(self) -> dict:
        """
        Returns the supported preset names and argv fragments for `tshark`.
        """
        return dict(self.TSHARK_PRESETS)

    def run_tshark(self, args, file):
        """
        Runs `tshark` against a capture file and returns the completed process.
        """
        if not self.has_tshark():
            raise FileNotFoundError("tshark is not installed or not available on PATH.")

        path = Path(file).expanduser().resolve()
        command = ["tshark", "-r", path.as_posix(), *list(args)]
        return self.manager_file.run_cmd(command, capture=True, text=True, check=False)

    def run_tshark_preset(self, file, preset):
        """
        Runs a named `tshark` preset against the target capture file.
        """
        try:
            args = self.TSHARK_PRESETS[preset]
        except KeyError as exc:
            raise ValueError(f"Unknown tshark preset: {preset}") from exc
        return self.run_tshark(args=args, file=file)

    def build_tshark_command(self, file, preset=None, args=None) -> str:
        """
        Builds the exact `tshark` command string shown to the user before
        execution.
        """
        path = Path(file).expanduser().resolve()
        extra = self.TSHARK_PRESETS[preset] if preset is not None else list(args or [])
        return " ".join(["tshark", "-r", path.as_posix(), *extra])

    def graph_capture(
        self, file=None, packets=None, mode="hosts", title=None, serve=True
    ):
        """
        Builds a graph from the capture and optionally launches the Dash UI.

        Returns a small metadata dictionary so the CLI can report what it is
        about to show even when the server is suppressed in tests.
        """
        if packets is None:
            if file is not None:
                packets = self.load_capture(file)
            else:
                packets = self._resolve_packets(None)

        dash_manager = self._get_dash_manager()
        if title is not None:
            dash_manager.title = title

        if mode == "hosts":
            elements = dash_manager.pcap_to_element_converter(packets, save=True)
        elif mode == "timeline":
            elements = dash_manager.pcap_to_element_converter_timestamp(
                packets, save=True
            )
        else:
            raise ValueError(f"Unsupported graph mode: {mode}")

        dash_manager.elements = elements
        metadata = {
            "mode": mode,
            "element_count": len(elements),
            "title": dash_manager.title,
        }
        if serve:
            dash_manager.run_dash()
        return metadata

    def _get_dash_manager(self):
        """
        Lazily imports and constructs the Dash manager so normal summary and
        extraction paths do not fail in non-GUI environments.
        """
        if self._dash_manager is not None:
            return self._dash_manager

        try:
            from ctfsolver.forensics.manager_dash import ManagerDash
        except ModuleNotFoundError as exc:
            raise ModuleNotFoundError(
                "Dash graph support requires the optional Dash dependencies."
            ) from exc

        self._dash_manager = ManagerDash(output_manager=self.output)
        return self._dash_manager

    def _resolve_packets(self, packets):
        if packets is not None:
            return packets
        if self.packets:
            return self.packets
        return []

    def _packet_protocols(self, packet):
        protocols = []
        if packet.haslayer("HTTP"):
            protocols.append("HTTP")
        if packet.haslayer("DNS"):
            protocols.append("DNS")
        if packet.haslayer("TCP"):
            protocols.append("TCP")
        if packet.haslayer("UDP"):
            protocols.append("UDP")
        if packet.haslayer("ICMP"):
            protocols.append("ICMP")
        if protocols:
            return protocols
        if packet.haslayer("IP") and hasattr(packet, "sprintf"):
            try:
                return [str(packet.sprintf("%IP.proto%"))]
            except Exception:
                return ["IP"]
        if packet.haslayer("IP"):
            return ["IP"]
        return []

    def _packet_endpoints(self, packet):
        if not packet.haslayer("IP"):
            return (None, None)
        ip_layer = packet["IP"]
        return (getattr(ip_layer, "src", None), getattr(ip_layer, "dst", None))

    def _packet_ports(self, packet):
        ports = []
        for layer_name in ("TCP", "UDP"):
            if packet.haslayer(layer_name):
                layer = packet[layer_name]
                for attr in ("sport", "dport"):
                    value = getattr(layer, attr, None)
                    if value is not None:
                        ports.append(value)
        return ports

    def _packet_time(self, packet):
        return getattr(packet, "time", None)

    def _packet_raw_bytes(self, packet):
        if not packet.haslayer("Raw"):
            return b""
        raw_layer = packet["Raw"]
        return getattr(raw_layer, "load", b"") or b""

    def _to_printable_text(self, raw_bytes, min_length=4):
        if not raw_bytes:
            return None
        text = raw_bytes.decode("utf-8", errors="ignore")
        printable_lines = [
            line.strip() for line in text.splitlines() if len(line.strip()) >= min_length
        ]
        if printable_lines:
            return "\n".join(printable_lines)
        collapsed = "".join(ch for ch in text if 32 <= ord(ch) <= 126)
        return collapsed if len(collapsed) >= min_length else None

    def _decode_possible_bytes(self, value):
        if isinstance(value, bytes):
            return value.decode("utf-8", errors="ignore").rstrip(".")
        return str(value).rstrip(".")

    def _unique(self, values):
        output = []
        seen = set()
        for value in values:
            normalized = value.strip() if isinstance(value, str) else value
            if not normalized or normalized in seen:
                continue
            seen.add(normalized)
            output.append(normalized)
        return output
