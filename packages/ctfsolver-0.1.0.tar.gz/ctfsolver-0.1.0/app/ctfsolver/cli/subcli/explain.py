import typer

from ctfsolver.explain.manager_explain import ManagerExplainRunner
from ctfsolver.managers.manager_output import ManagerOutput

explain_app = typer.Typer(help="Static explanation of the solution code that will run.")
explain_output = ManagerOutput(sink=typer.echo)
explain_runner = ManagerExplainRunner(output_manager=explain_output)


@explain_app.command("solution")
def explain_solution(
    verbose: bool = typer.Option(False, "-v", "--verbose", help="Verbose output"),
    print_only: bool = typer.Option(
        False,
        "--print-only",
        help="Print the explanation without writing docs/explain_data outputs",
    ),
):
    """Explain the current solution file and optionally write docs/explain_data outputs."""
    explain_output.set_verbosity(2 if verbose else 1)
    result = explain_runner.explain(save=not print_only)
    if print_only:
        explain_output.info(result["summary_text"])
    else:
        explain_output.info(
            explain_runner.build_cli_summary(result, include_methods=verbose)
        )
