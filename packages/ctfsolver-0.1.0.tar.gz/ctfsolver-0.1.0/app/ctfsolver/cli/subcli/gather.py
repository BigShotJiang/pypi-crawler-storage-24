import typer

from ctfsolver.find_usage.manager_gathering import ManagerGathering
from ctfsolver.managers.manager_output import ManagerOutput

gather_app = typer.Typer(help="Gather reusable function information from challenge solutions.")
gather_output = ManagerOutput(sink=typer.echo)
gather_manager = ManagerGathering(output_manager=gather_output)


@gather_app.command("corpus")
def gather_corpus(
    limit: int = typer.Option(10, "--limit", min=1, help="Maximum items per section"),
    verbosity: int = typer.Option(1, "--verbosity", min=0, max=3, help="Output verbosity"),
    print_only: bool = typer.Option(
        False, "--print-only", help="Print the summary without writing docs/gather_data"
    ),
):
    """Gather function reuse information across historical solutions in ctf_data."""
    gather_output.set_verbosity(verbosity)
    corpus = gather_manager.gather_corpus()
    lines = gather_manager.build_corpus_summary_lines(corpus, limit=limit)
    if print_only:
        gather_output.info("\n".join(lines))
        return
    output_dir, markdown_path, json_path = gather_manager.write_output(
        "corpus_summary", lines, corpus
    )
    gather_output.success("Gather corpus summary written")
    gather_output.info(gather_manager.build_output_summary(output_dir, markdown_path, json_path))


@gather_app.command("file")
def gather_file(
    path: str = typer.Option(None, "--path", help="Specific solution file to gather"),
    verbosity: int = typer.Option(1, "--verbosity", min=0, max=3, help="Output verbosity"),
    print_only: bool = typer.Option(
        False, "--print-only", help="Print the summary without writing docs/gather_data"
    ),
):
    """Gather functions from one solution file and relate them to historical challenges."""
    gather_output.set_verbosity(verbosity)
    gathered_file = gather_manager.gather_file(path=path)
    lines = gather_manager.build_file_summary_lines(gathered_file)
    if print_only:
        gather_output.info("\n".join(lines))
        return
    output_dir, markdown_path, json_path = gather_manager.write_output(
        "current_solution_gather", lines, gathered_file
    )
    gather_output.success("Gather file summary written")
    gather_output.info(gather_manager.build_output_summary(output_dir, markdown_path, json_path))


@gather_app.command("duplicates")
def gather_duplicates(
    limit: int = typer.Option(20, "--limit", min=1, help="Maximum duplicate groups to show"),
    verbosity: int = typer.Option(1, "--verbosity", min=0, max=3, help="Output verbosity"),
    print_only: bool = typer.Option(
        False, "--print-only", help="Print the summary without writing docs/gather_data"
    ),
):
    """Gather duplicate and structurally repeated functions across historical solutions."""
    gather_output.set_verbosity(verbosity)
    corpus = gather_manager.gather_corpus()
    lines = gather_manager.build_duplicates_summary_lines(corpus, limit=limit)
    if print_only:
        gather_output.info("\n".join(lines))
        return
    output_dir, markdown_path, json_path = gather_manager.write_output(
        "duplicates", lines, corpus["duplicates"]
    )
    gather_output.success("Gather duplicates summary written")
    gather_output.info(gather_manager.build_output_summary(output_dir, markdown_path, json_path))
