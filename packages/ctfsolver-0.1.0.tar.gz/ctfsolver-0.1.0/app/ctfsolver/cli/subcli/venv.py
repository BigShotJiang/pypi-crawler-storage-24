import typer
from pathlib import Path
from ctfsolver.managers.manager_output import ManagerOutput
from ctfsolver.venv.manager_venv import ManagerVenv

venv_app = typer.Typer(help="Virtual environment operations.")
manager = ManagerVenv()
venv_output = ManagerOutput(sink=typer.echo)


@venv_app.command("test", help="Test virtual environment management features.")
def test_venv(
    # directory: str = typer.Option(
    #     ..., "-e", "--eir", help="Directory for the operation"
    # )
):
    """Manage virtual environments (implementation TBD)."""

    manager.testing()


@venv_app.command("look_for", help="Look for virtual environment management features.")
def look_for_venv(
    path: str = typer.Option(
        None, "-p", "--path", help="Directory to search for virtual environments"
    ),
    verbose: bool = typer.Option(False, "-v", "--verbose", help="Verbose output"),
):
    """Manage virtual environments (implementation TBD)."""
    venv_output.set_verbosity(2 if verbose else 1)
    venvs = manager.look_for_venvs(filepath=path)
    venv_output.success("Venv lookup completed.")
    venv_output.info(manager.build_lookup_summary(venvs, search_path=path))


@venv_app.command("activation", help="Show the activation command for a venv or shortcut.")
def activation_command(
    venv: str = typer.Option(None, "--venv", help="Explicit virtual environment path"),
    path: str = typer.Option(None, "-p", "--path", help="Folder containing a shortcut file"),
):
    """Print the shell command needed to activate a venv."""
    target = Path(venv).expanduser() if venv else manager.read_shortcut(path)
    venv_output.info(manager.build_activation_command(target))


@venv_app.command("shortcut", help="Create a shortcut file that points to a venv.")
def create_shortcut(
    venv: str = typer.Option(..., "--venv", help="Virtual environment path"),
    path: str = typer.Option(None, "-p", "--path", help="Folder where the shortcut should be created"),
):
    """Create a venv shortcut file for the current or specified folder."""
    shortcut = manager.create_shortcut(folder=path, venv_path=venv)
    venv_output.success("Venv shortcut created.")
    venv_output.info(manager.build_shortcut_summary(shortcut, manager.resolve_venv_path(venv)))


@venv_app.command("save", help="Export requirements and pipdeptree metadata for a venv.")
def save_venv_dependencies(
    venv: str = typer.Option(..., "--venv", help="Virtual environment path"),
    output_dir: str = typer.Option(None, "--output-dir", help="Directory where dependency files should be written"),
):
    """Save dependency metadata for a virtual environment."""
    metadata = manager.save_dependencies(folder=venv, output_dir=output_dir)
    venv_output.success("Venv dependencies exported.")
    venv_output.info(manager.build_dependency_summary(metadata))


@venv_app.command("move", help="Move a local venv into the configured global venv directory.")
def move_venv(
    venv: str = typer.Option(..., "--venv", help="Virtual environment path"),
):
    """Move a venv to the configured global storage and leave a shortcut behind."""
    result = manager.move_venv(folder=venv)
    venv_output.success("Venv moved.")
    venv_output.info(
        venv_output.format_kv(
            {
                "Source": result["source"],
                "Destination": result["destination"],
                "Shortcut": result["shortcut"],
            }
        )
    )


@venv_app.command("clean", help="Export venv metadata and optionally delete the environment.")
def clean_venv(
    venv: str = typer.Option(..., "--venv", help="Virtual environment path"),
    delete: bool = typer.Option(False, "--delete", help="Delete the venv after exporting metadata"),
):
    """Save venv metadata and optionally delete the environment."""
    result = manager.clean_venv(folder=venv, delete=delete)
    venv_output.success("Venv cleanup metadata saved.")
    venv_output.info(
        venv_output.format_kv(
            {
                "Venv": result["venv_path"],
                "Metadata dir": result["output_dir"],
                "Deleted": result["deleted"],
            }
        )
    )
