import typer
from pathlib import Path
from ctfsolver.managers.manager_file import ManagerFile
from ctfsolver.managers.manager_workspace import ManagerWorkspace
from ctfsolver.managers.manager_ctf_automover import ManagerCTFAutoMover
from ctfsolver.managers.manager_ctf_creator import ManagerCTFCreator
from ctfsolver.managers.manager_ctf_linker import ManagerCTFLinker
from ctfsolver.managers.manager_output import ManagerOutput
from ctfsolver.managers.manager_solution_runner import ManagerSolutionRunner
from ctfsolver.error.manager_error import ManagerError
from ctfsolver.config.challenge_config import ChallengeConfig
from ctfsolver.config.global_config import CONFIG

ctf_app = typer.Typer(help="CTF operations: create, delete, link, etc.")

manager_error = ManagerError()
manager_file = ManagerFile()
manager_folder = manager_file
workspace_manager = ManagerWorkspace()
ctf_automover = ManagerCTFAutoMover(manager_folder=manager_folder)
ctf_creator = ManagerCTFCreator(
    manager_file=manager_file, workspace_manager=workspace_manager
)
ctf_linker = ManagerCTFLinker(
    manager_file=manager_file, workspace_manager=workspace_manager
)
solution_runner = ManagerSolutionRunner(manager_file=manager_file)
challenge_config = ChallengeConfig()
ctf_output = ManagerOutput(sink=typer.echo)


# ╭───────────╮
# │ CTF Stuff │
# ╰───────────╯


@ctf_app.command()
def folders():
    """Create the folder structure as specified by the global configuration."""
    workspace_manager.create_parent_folder()


@ctf_app.command()
def create(
    category: str = typer.Option(
        ..., "-c", "--category", help="Category for the operation"
    ),
    site: str = typer.Option(..., "-s", "--site", help="Site inside the category"),
    name: str = typer.Option(..., "-n", "--name", help="Name of the CTF challenge"),
    doc_creation_check: bool = typer.Option(
        False,
        "-m",
        "--doc-creation-check",
        help="Also create the paired markdown document for the challenge.",
    ),
    download: bool = typer.Option(
        False, "-d", "--download", help="Auto move downloaded files"
    ),
    verbose: bool = typer.Option(False, "-v", "--verbose", help="Verbose output"),
):
    """Create a new CTF challenge structure."""
    ctf_output.set_verbosity(2 if verbose else 1)
    ctf_output.info(f"Creating new CTF: {name} in category {category} at site {site}", level=2)
    result = ctf_creator.create(
        category=category,
        site=site,
        name=name,
        doc_creation_check=doc_creation_check,
        download=download,
        verbose=verbose,
    )
    ctf_output.success("Created challenge structure.")
    ctf_output.info(ctf_creator.build_summary_text(result))


@ctf_app.command()
def automove(
    checker: bool = typer.Option(False, "-y", "--no-check", help="No checking"),
    verbose: bool = typer.Option(False, "-v", "--verbose", help="Verbose output"),
):
    """Automatically move downloaded CTF files to their respective challenge folders."""
    ctf_output.set_verbosity(2 if verbose else 1)
    context = ctf_automover.automove(checker=checker, verbose=verbose)
    ctf_output.success(f"Auto-moved downloads for {context['challenge_name']}.")
    ctf_output.info(ctf_automover.build_summary_text(context))


@ctf_app.command()
def show(
    category: str = typer.Option(
        ..., "-c", "--category", help="Category for the operation"
    ),
    site: str = typer.Option(..., "-s", "--site", help="Site inside the category"),
    verbose: bool = typer.Option(False, "-v", "--verbose", help="Verbose output"),
):
    """Navigate CTF categories/sites and list subdirectories."""
    ctf_output.set_verbosity(2 if verbose else 1)
    CONFIG.get_content()
    ctf_data_dir = CONFIG.content.get("directories").get("ctf_data")
    path_building = Path(Path.home(), ctf_data_dir, category, site)
    if not path_building.exists():
        raise FileNotFoundError(f"Path does not exist: {path_building}")
    _, dirs, _ = workspace_manager.single_folder_search(path=path_building)
    ctf_output.info(
        ctf_output.format_kv(
            {
                "Category": category,
                "Site": site,
                "Path": path_building,
                "Challenges found": len(dirs),
            }
        )
    )
    ctf_output.info(ctf_output.format_list(sorted(dirs), title="Challenges"))


@ctf_app.command()
def link(
    create_missing: bool = typer.Option(
        False,
        "--create-missing",
        help="Create missing challenge folders for writeup-only entries",
    ),
    verbose: bool = typer.Option(False, "-v", "--verbose", help="Verbose output"),
):
    """Compare challenge folders against documentation and optionally create missing folders."""
    ctf_output.set_verbosity(2 if verbose else 1)
    result = ctf_linker.link(create_missing=create_missing, verbose=verbose)
    ctf_output.info(
        ctf_linker.build_summary_text(result, include_details=verbose)
    )


@ctf_app.command()
def find_usage(directory: str = typer.Option(None, help="Directory for the operation")):
    """Find usage of a specific import statement in project files."""
    search_string = "from ctfsolver import CTFSolver"
    exclude_dirs = ["app_venv", ".git"]
    current_directory = None
    if directory:
        current_directory = workspace_manager.check_folder_exists(directory)
    if current_directory is False:
        raise ValueError("Invalid directory specified.")
    if current_directory is None:
        current_directory = "."
    manager_error.try_function(
        function=workspace_manager.search_files,
        directory=current_directory,
        exclude_dirs=exclude_dirs,
        search_string=search_string,
        display=True,
    )


@ctf_app.command()
def run(
    local: bool = typer.Option(False, "-l", "--local", help="Run locally"),
    remote: bool = typer.Option(False, "-r", "--remote", help="Run remotely"),
    verbose: bool = typer.Option(False, "-v", "--verbose", help="Verbose output"),
    file: str = typer.Option(None, "-f", "--file", help="File to run"),
    host: str = typer.Option(None, "-h", "--host", help="Remote host"),
    port: int = typer.Option(None, "-p", "--port", help="Remote port"),
):
    ctf_output.set_verbosity(2 if verbose else 1)
    mode = solution_runner.resolve_mode(
        local=local, remote=remote, file=file, host=host, port=port
    )
    solution_file = solution_runner.get_solution_file()
    ctf_output.info("Running challenge solution.", level=2)
    ctf_output.info(
        solution_runner.build_run_summary(
            solution_file, mode=mode, file=file, host=host, port=port
        )
    )
    exit_code = solution_runner.run(
        local=local, remote=remote, file=file, host=host, port=port
    )
    ctf_output.success("Challenge solution finished.", level=2)
    raise typer.Exit(exit_code)


@ctf_app.command("init", help="Initialize challenge configuration.")
def init_challenge():
    """Initialize challenge configuration in the current directory."""
    challenge_config.get_current_dir()
    challenge_config_path = challenge_config.create_challenge_config()
    ctf_output.success("Challenge configuration created.")
    ctf_output.info(challenge_config.build_summary_text(challenge_config_path))
