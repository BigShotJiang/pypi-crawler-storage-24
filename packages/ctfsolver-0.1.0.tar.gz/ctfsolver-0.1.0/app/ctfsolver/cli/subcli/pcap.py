from pathlib import Path

import typer

from ctfsolver.forensics.manager_pcap_analyzer import ManagerPcapAnalyzer
from ctfsolver.managers.manager_output import ManagerOutput

pcap_app = typer.Typer(help="PCAP analysis, extraction, graphing, and tshark helpers.")

pcap_output = ManagerOutput(sink=typer.echo)
pcap_analyzer = ManagerPcapAnalyzer(output_manager=pcap_output)


@pcap_app.command()
def summary(
    file: Path = typer.Option(
        ..., "-f", "--file", exists=True, readable=True, help="PCAP file to summarize"
    ),
    verbose: bool = typer.Option(False, "-v", "--verbose", help="Verbose output"),
):
    """Summarize a PCAP file with packet, protocol, conversation, and port counts."""
    pcap_output.set_verbosity(2 if verbose else 1)
    packets = pcap_analyzer.load_capture(file)
    summary_data = pcap_analyzer.build_capture_summary(packets=packets)
    pcap_output.success("PCAP summary complete.")
    pcap_output.info(pcap_analyzer.build_summary_text(summary_data))


@pcap_app.command()
def extract(
    file: Path = typer.Option(
        ..., "-f", "--file", exists=True, readable=True, help="PCAP file to inspect"
    ),
    verbose: bool = typer.Option(False, "-v", "--verbose", help="Verbose output"),
):
    """Extract printable payloads, likely credentials, flags, and file hints from a PCAP."""
    pcap_output.set_verbosity(2 if verbose else 1)
    packets = pcap_analyzer.load_capture(file)
    artifacts = pcap_analyzer.extract_artifacts(packets=packets)
    pcap_output.success("PCAP artifact extraction complete.")
    pcap_output.info(pcap_analyzer.build_extraction_text(artifacts))


@pcap_app.command()
def graph(
    file: Path = typer.Option(
        ..., "-f", "--file", exists=True, readable=True, help="PCAP file to visualize"
    ),
    mode: str = typer.Option("hosts", "--mode", help="Graph mode: hosts or timeline"),
    title: str = typer.Option("PCAP Graph", "--title", help="Title for the graph app"),
    serve: bool = typer.Option(
        True,
        "--serve/--no-serve",
        help="Launch the Dash server after building graph elements",
    ),
    verbose: bool = typer.Option(False, "-v", "--verbose", help="Verbose output"),
):
    """Build a packet graph and optionally launch the Dash visualization app."""
    pcap_output.set_verbosity(2 if verbose else 1)
    result = pcap_analyzer.graph_capture(
        file=file, mode=mode, title=title, serve=serve
    )
    pcap_output.success("PCAP graph prepared.")
    pcap_output.info(
        pcap_output.format_kv(
            {
                "Mode": result["mode"],
                "Elements": result["element_count"],
                "Title": result["title"],
                "Serving": serve,
            },
            title="Graph Summary",
        )
    )


@pcap_app.command("tshark")
def tshark_command(
    file: Path = typer.Option(
        ...,
        "-f",
        "--file",
        exists=True,
        readable=True,
        help="PCAP file to inspect with tshark",
    ),
    preset: str = typer.Option(None, "--preset", help="Named tshark preset to run"),
    arg: list[str] = typer.Option(
        None, "--arg", help="Additional raw tshark argument. Repeat for multiple values."
    ),
    verbose: bool = typer.Option(False, "-v", "--verbose", help="Verbose output"),
):
    """Run `tshark` presets or custom arguments against a PCAP if tshark is installed."""
    pcap_output.set_verbosity(2 if verbose else 1)
    args = arg or []
    if preset is None and not args:
        raise typer.BadParameter("Provide either --preset or at least one --arg value.")

    command = pcap_analyzer.build_tshark_command(file=file, preset=preset, args=args)
    pcap_output.info(command, level=2)

    result = (
        pcap_analyzer.run_tshark_preset(file=file, preset=preset)
        if preset is not None
        else pcap_analyzer.run_tshark(file=file, args=args)
    )

    if result.stdout:
        pcap_output.info(result.stdout.rstrip())
    if result.stderr:
        pcap_output.warn(result.stderr.rstrip(), level=2)
    if result.returncode != 0:
        raise typer.Exit(result.returncode)
