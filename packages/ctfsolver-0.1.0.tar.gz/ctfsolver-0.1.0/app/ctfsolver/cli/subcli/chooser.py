import typer

from ctfsolver.find_usage.manager_internal_chooser import ManagerInternalChooser
from ctfsolver.managers.manager_output import ManagerOutput

chooser_app = typer.Typer(help="Recommend useful internal methods and workflows by challenge category.")
chooser_output = ManagerOutput(sink=typer.echo)
chooser_manager = ManagerInternalChooser(output_manager=chooser_output)


@chooser_app.command("update")
def chooser_update(
    minimum_usage_count: int = typer.Option(
        2,
        "--minimum-usage-count",
        min=1,
        help="Minimum historical usage count required to keep a recommendation.",
    ),
):
    """Rebuild and cache chooser recommendations from the historical corpus."""
    chooser_data = chooser_manager.update_index(minimum_usage_count=minimum_usage_count)
    chooser_output.success("Chooser index updated.")
    chooser_output.info(chooser_manager.summarize_index(chooser_data))


@chooser_app.command("show")
def chooser_show(
    category: str = typer.Option(
        None,
        "--category",
        help="Challenge category. If omitted, the chooser tries to infer it from the current path.",
    ),
    inspect_files: bool = typer.Option(
        False,
        "--inspect-files",
        help="Inspect the local files/ directory and archive contents to refine ranking.",
    ),
    limit: int = typer.Option(10, "--limit", min=1, help="Maximum recommendations to print."),
):
    """Show cached recommendations for the current or selected challenge category."""
    result = chooser_manager.recommend(
        category=category,
        inspect_files=inspect_files,
        limit=limit,
    )
    chooser_output.info("\n".join(chooser_manager.build_recommendation_lines(result)))
