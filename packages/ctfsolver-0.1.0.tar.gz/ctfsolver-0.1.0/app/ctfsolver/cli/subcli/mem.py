import typer

from ctfsolver.forensics.manager_volatility import ManagerVolatilityRunner
from ctfsolver.managers.manager_output import ManagerOutput

mem_app = typer.Typer(help="Memory forensics workflows powered by Volatility.")
mem_output = ManagerOutput(sink=typer.echo)
volatility_runner = ManagerVolatilityRunner(output_manager=mem_output)


@mem_app.command("triage")
def triage_memory(
    file: str = typer.Option(None, "-f", "--file", help="Memory image inside files/"),
    verbose: bool = typer.Option(False, "-v", "--verbose", help="Verbose output"),
):
    """Run a default Volatility triage bundle against the challenge memory image."""
    mem_output.set_verbosity(2 if verbose else 1)
    result = volatility_runner.triage(file=file)
    mem_output.info(
        volatility_runner.build_cli_summary(
            result, mode="triage", include_details=verbose
        )
    )


@mem_app.command("run")
def run_memory_plugin(
    plugin: list[str] = typer.Option(
        None,
        "-p",
        "--plugin",
        help="Volatility plugin to run. Repeat the option for multiple plugins.",
    ),
    file: str = typer.Option(None, "-f", "--file", help="Memory image inside files/"),
    verbose: bool = typer.Option(False, "-v", "--verbose", help="Verbose output"),
):
    """Run specific Volatility plugins against the challenge memory image."""
    mem_output.set_verbosity(2 if verbose else 1)
    result = volatility_runner.run(file=file, plugins=plugin)
    mem_output.info(
        volatility_runner.build_cli_summary(
            result, mode="run", include_details=verbose
        )
    )


@mem_app.command("autosolve")
def autosolve_memory(
    file: str = typer.Option(None, "-f", "--file", help="Memory image inside files/"),
    verbose: bool = typer.Option(False, "-v", "--verbose", help="Verbose output"),
):
    """Run memory triage and summarize likely findings."""
    mem_output.set_verbosity(2 if verbose else 1)
    result = volatility_runner.autosolve(file=file)
    mem_output.info(
        volatility_runner.build_cli_summary(
            result, mode="autosolve", include_details=verbose
        )
    )
