# Explain helpers live outside the core solver flow.
