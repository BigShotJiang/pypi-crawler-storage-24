import ast
import json

from pathlib import Path

from ctfsolver.managers.manager_class import ManagerClass
from ctfsolver.managers.manager_output import ManagerOutput


class _ExplainVisitor(ast.NodeVisitor):
    def __init__(self):
        self.imports = []
        self.calls = []
        self.files = []
        self.assignments = []
        self.entrypoints = []
        self.interesting_calls = []

    def visit_Import(self, node):
        for alias in node.names:
            self.imports.append(alias.name)
        self.generic_visit(node)

    def visit_ImportFrom(self, node):
        module = node.module or ""
        for alias in node.names:
            self.imports.append(f"{module}.{alias.name}".strip("."))
        self.generic_visit(node)

    def visit_Assign(self, node):
        target_names = []
        for target in node.targets:
            if isinstance(target, ast.Attribute) and isinstance(target.value, ast.Name):
                target_names.append(f"{target.value.id}.{target.attr}")
            elif isinstance(target, ast.Name):
                target_names.append(target.id)
        if target_names:
            self.assignments.append(
                {
                    "targets": target_names,
                    "value": ast.unparse(node.value) if hasattr(ast, "unparse") else None,
                }
            )
        self.generic_visit(node)

    def visit_Call(self, node):
        name = self._call_name(node.func)
        if name:
            self.calls.append(name)
            if any(
                token in name
                for token in (
                    "open",
                    "Path",
                    "subprocess",
                    "requests",
                    "socket",
                    "remote",
                    "process",
                    "connect",
                    "run",
                )
            ):
                self.interesting_calls.append(name)
        self.generic_visit(node)

    def visit_With(self, node):
        for item in node.items:
            ctx = item.context_expr
            if isinstance(ctx, ast.Call):
                name = self._call_name(ctx.func)
                if name == "open" and ctx.args:
                    try:
                        self.files.append(ast.unparse(ctx.args[0]))
                    except Exception:
                        pass
        self.generic_visit(node)

    def visit_If(self, node):
        try:
            test_src = ast.unparse(node.test)
        except Exception:
            test_src = ""
        if "__name__" in test_src and "__main__" in test_src:
            self.entrypoints.append(test_src)
        self.generic_visit(node)

    def _call_name(self, func):
        if isinstance(func, ast.Name):
            return func.id
        if isinstance(func, ast.Attribute):
            parts = []
            current = func
            while isinstance(current, ast.Attribute):
                parts.append(current.attr)
                current = current.value
            if isinstance(current, ast.Name):
                parts.append(current.id)
            return ".".join(reversed(parts))
        return None


class _MethodCallVisitor(ast.NodeVisitor):
    def __init__(self):
        self.self_calls = []
        self.other_calls = []
        self.attribute_reads = []
        self.attribute_writes = []
        self.side_effects = {
            "file_reads": [],
            "file_writes": [],
            "subprocesses": [],
            "network": [],
            "clipboard": [],
            "crypto": [],
            "process_spawn": [],
        }

    def visit_Assign(self, node):
        for target in node.targets:
            if (
                isinstance(target, ast.Attribute)
                and isinstance(target.value, ast.Name)
                and target.value.id == "self"
            ):
                self.attribute_writes.append(target.attr)
        self.generic_visit(node)

    def visit_Attribute(self, node):
        if (
            isinstance(node.value, ast.Name)
            and node.value.id == "self"
            and isinstance(node.ctx, ast.Load)
        ):
            self.attribute_reads.append(node.attr)
        self.generic_visit(node)

    def visit_Call(self, node):
        call_name = None
        if isinstance(node.func, ast.Attribute):
            if isinstance(node.func.value, ast.Name) and node.func.value.id == "self":
                self.self_calls.append(node.func.attr)
                call_name = f"self.{node.func.attr}"
            else:
                call_name = self._call_name(node.func)
                self.other_calls.append(call_name)
        elif isinstance(node.func, ast.Name):
            call_name = node.func.id
            self.other_calls.append(call_name)
        self._classify_side_effect(call_name, node)
        self.generic_visit(node)

    def _call_name(self, func):
        if isinstance(func, ast.Name):
            return func.id
        if isinstance(func, ast.Attribute):
            parts = []
            current = func
            while isinstance(current, ast.Attribute):
                parts.append(current.attr)
                current = current.value
            if isinstance(current, ast.Name):
                parts.append(current.id)
            return ".".join(reversed(parts))
        return None

    def _classify_side_effect(self, call_name, node):
        if not call_name:
            return

        lowered = call_name.lower()

        if lowered == "open":
            mode = "r"
            if len(node.args) >= 2 and isinstance(node.args[1], ast.Constant):
                mode = str(node.args[1].value)
            for keyword in node.keywords:
                if keyword.arg == "mode" and isinstance(keyword.value, ast.Constant):
                    mode = str(keyword.value.value)
            target = None
            if node.args:
                try:
                    target = ast.unparse(node.args[0])
                except Exception:
                    target = None
            if any(flag in mode for flag in ("w", "a", "+", "x")):
                self.side_effects["file_writes"].append(target or "open(...)")
            else:
                self.side_effects["file_reads"].append(target or "open(...)")

        if any(token in lowered for token in ("subprocess.run", "subprocess.popen", "os.system")):
            self.side_effects["subprocesses"].append(call_name)

        if any(token in lowered for token in ("pwn.process", "process")) and lowered != "subprocess.run":
            self.side_effects["process_spawn"].append(call_name)

        if any(
            token in lowered
            for token in ("requests.", "socket.", "remote", "connect", "recv", "send")
        ):
            self.side_effects["network"].append(call_name)

        if "pyperclip" in lowered or lowered == "copy" or lowered.endswith(".copy"):
            self.side_effects["clipboard"].append(call_name)

        if any(
            token in lowered
            for token in ("base64", "xor", "decode", "decrypt", "encrypt", "hash", "b64")
        ):
            self.side_effects["crypto"].append(call_name)


class ManagerExplainRunner:
    """
    Static explanation helper for the solution file that is about to run.
    """

    def __init__(self, manager_file=None, class_inspector=None, output_manager=None):
        if manager_file is None:
            from ctfsolver.managers.manager_file import ManagerFile

            manager_file = ManagerFile()
        self.manager_file = manager_file
        self.class_inspector = class_inspector or ManagerClass()
        self.output = output_manager or ManagerOutput()

    def prepare_context(self):
        self.manager_file.get_current_dir()
        current_path = Path(self.manager_file.parent)
        folder_names = set(getattr(self.manager_file, "folders_name_list", []))
        if current_path.name in folder_names:
            current_path = current_path.parent
        self.manager_file.parent = current_path
        self.manager_file.setup_named_folders()

    def get_solution_file(self):
        self.prepare_context()
        solution_file = self.manager_file.get_solution_file(save=True)
        if solution_file is None:
            raise FileNotFoundError("Solution file not found in the payloads folder.")
        return Path(solution_file)

    def get_output_dir(self):
        output_dir = self.manager_file.parent / "docs" / "explain_data"
        output_dir.mkdir(parents=True, exist_ok=True)
        return output_dir

    def analyze_module(self, solution_file):
        source = solution_file.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(solution_file))
        visitor = _ExplainVisitor()
        visitor.visit(tree)
        return {
            "imports": sorted(set(visitor.imports)),
            "calls": visitor.calls,
            "interesting_calls": sorted(set(visitor.interesting_calls)),
            "files": sorted(set(visitor.files)),
            "assignments": visitor.assignments,
            "entrypoints": visitor.entrypoints,
        }

    def analyze_solution(self, solution_file):
        module_info = self.analyze_module(solution_file)
        solution_info = self.class_inspector.inspect(
            solution_file, "Solution", include_inherited=True
        )
        call_graph = self.build_call_graph(solution_info)
        execution_flow = self.build_execution_flow(solution_info, call_graph)
        inherited_helpers = self.find_inherited_helpers(solution_info, call_graph)
        attribute_flow = self.build_attribute_flow(call_graph, solution_info)
        method_narratives = self.build_method_narratives(call_graph, solution_info)
        risk_summary = self.build_risk_summary(call_graph)
        return {
            "solution_file": str(solution_file),
            "module": module_info,
            "solution": solution_info,
            "call_graph": call_graph,
            "execution_flow": execution_flow,
            "inherited_helpers": inherited_helpers,
            "attribute_flow": attribute_flow,
            "method_narratives": method_narratives,
            "risk_summary": risk_summary,
        }

    def build_call_graph(self, solution_info):
        call_graph = {}
        for method_name, info in solution_info.get("methods", {}).items():
            source = info.get("source")
            if not source:
                call_graph[method_name] = {
                    "self_calls": [],
                    "other_calls": [],
                    "attribute_reads": [],
                    "attribute_writes": [],
                    "side_effects": {},
                }
                continue
            try:
                tree = ast.parse(source)
            except SyntaxError:
                call_graph[method_name] = {
                    "self_calls": [],
                    "other_calls": [],
                    "attribute_reads": [],
                    "attribute_writes": [],
                    "side_effects": {},
                }
                continue
            visitor = _MethodCallVisitor()
            visitor.visit(tree)
            call_graph[method_name] = {
                "self_calls": sorted(set(visitor.self_calls)),
                "other_calls": sorted(
                    set(call for call in visitor.other_calls if call is not None)
                ),
                "attribute_reads": sorted(set(visitor.attribute_reads)),
                "attribute_writes": sorted(set(visitor.attribute_writes)),
                "side_effects": {
                    key: sorted(set(value))
                    for key, value in visitor.side_effects.items()
                    if value
                },
            }
        return call_graph

    def build_execution_flow(self, solution_info, call_graph):
        flow = ["__main__", "Solution(...)", "try_main", "main"]
        visited = set(flow)
        queue = ["main"]
        method_info = solution_info.get("methods", {})

        while queue:
            current = queue.pop(0)
            for called in call_graph.get(current, {}).get("self_calls", []):
                if called in method_info and called not in visited:
                    flow.append(called)
                    queue.append(called)
                    visited.add(called)

        return flow

    def find_inherited_helpers(self, solution_info, call_graph):
        helpers = []
        methods = solution_info.get("methods", {})
        for method_name, calls in call_graph.items():
            for called in calls.get("self_calls", []):
                method_details = methods.get(called)
                if not method_details:
                    continue
                if method_details.get("inherited"):
                    helpers.append(
                        {
                            "method": called,
                            "used_from": method_name,
                            "defined_in": method_details.get("defined_in"),
                            "file": method_details.get("file"),
                        }
                    )
        unique = []
        seen = set()
        for helper in helpers:
            key = (helper["method"], helper["used_from"], helper["defined_in"])
            if key in seen:
                continue
            seen.add(key)
            unique.append(helper)
        return unique

    def build_attribute_flow(self, call_graph, solution_info):
        method_names = set(solution_info.get("methods", {}).keys())
        attributes = {}
        for method_name, info in call_graph.items():
            for attr in info.get("attribute_writes", []):
                if attr in method_names:
                    continue
                attributes.setdefault(attr, {"written_in": [], "read_in": []})
                attributes[attr]["written_in"].append(method_name)
            for attr in info.get("attribute_reads", []):
                if attr in method_names:
                    continue
                attributes.setdefault(attr, {"written_in": [], "read_in": []})
                attributes[attr]["read_in"].append(method_name)

        for attr, info in attributes.items():
            info["written_in"] = sorted(set(info["written_in"]))
            info["read_in"] = sorted(set(info["read_in"]))
        return attributes

    def build_method_narratives(self, call_graph, solution_info):
        method_names = set(solution_info.get("methods", {}).keys())
        narratives = {}
        for method_name, info in call_graph.items():
            parts = []
            attribute_writes = [item for item in info.get("attribute_writes", []) if item not in method_names]
            attribute_reads = [item for item in info.get("attribute_reads", []) if item not in method_names]
            if attribute_writes:
                parts.append(
                    "writes " + ", ".join(f"self.{item}" for item in attribute_writes)
                )
            if attribute_reads:
                parts.append(
                    "reads " + ", ".join(f"self.{item}" for item in attribute_reads)
                )
            if info.get("self_calls"):
                parts.append("calls " + ", ".join(info["self_calls"]))
            if info.get("other_calls"):
                parts.append("uses " + ", ".join(info["other_calls"]))
            side_effect_labels = []
            for key, values in info.get("side_effects", {}).items():
                if values:
                    side_effect_labels.append(key.replace("_", " "))
            if side_effect_labels:
                parts.append("side effects: " + ", ".join(side_effect_labels))
            narratives[method_name] = (
                "; ".join(parts) if parts else "no notable behavior detected"
            )
        return narratives

    def build_risk_summary(self, call_graph):
        risk_summary = {
            "reads_files": False,
            "writes_files": False,
            "runs_subprocesses": False,
            "opens_network_connections": False,
            "uses_clipboard": False,
            "uses_crypto_helpers": False,
            "spawns_processes": False,
        }

        for info in call_graph.values():
            side_effects = info.get("side_effects", {})
            if side_effects.get("file_reads"):
                risk_summary["reads_files"] = True
            if side_effects.get("file_writes"):
                risk_summary["writes_files"] = True
            if side_effects.get("subprocesses"):
                risk_summary["runs_subprocesses"] = True
            if side_effects.get("network"):
                risk_summary["opens_network_connections"] = True
            if side_effects.get("clipboard"):
                risk_summary["uses_clipboard"] = True
            if side_effects.get("crypto"):
                risk_summary["uses_crypto_helpers"] = True
            if side_effects.get("process_spawn"):
                risk_summary["spawns_processes"] = True

        return risk_summary

    def build_summary_lines(self, analysis):
        solution = analysis["solution"]
        module = analysis["module"]
        method_names = sorted(solution.get("methods", {}).keys())
        instance_attributes = sorted(solution.get("instance_attributes", {}).keys())
        lines = [
            "# Solution Explain Summary",
            "",
            f"- Solution file: {analysis['solution_file']}",
            f"- Class analyzed: {solution['name']}",
            "",
            "## Likely Entry Flow",
            "- Module `__main__` block instantiates `Solution` and then calls `try_main()` if present.",
            "- `try_main()` in `CTFSolver` delegates to `main()` through the error-handling wrapper.",
            f"- Static flow guess: {' -> '.join(analysis['execution_flow'])}",
            "",
            "## Methods",
        ]
        lines.extend([f"- {name}" for name in method_names] or ["- None"])
        lines.extend(["", "## Internal Call Graph"])
        for method_name in method_names:
            calls = analysis["call_graph"].get(method_name, {})
            self_calls = ", ".join(calls.get("self_calls", [])) or "None"
            other_calls = ", ".join(calls.get("other_calls", [])) or "None"
            lines.append(f"- {method_name}: self -> [{self_calls}] | other -> [{other_calls}]")
        lines.extend(["", "## Method Narratives"])
        for method_name in method_names:
            lines.append(f"- {method_name}: {analysis['method_narratives'].get(method_name)}")
        lines.extend(["", "## Inherited Helpers Used"])
        for helper in analysis["inherited_helpers"]:
            lines.append(
                f"- {helper['used_from']} -> {helper['method']} (from {helper['defined_in']})"
            )
        if not analysis["inherited_helpers"]:
            lines.append("- None")
        lines.extend(["", "## Attribute Flow"])
        for attr, info in sorted(analysis["attribute_flow"].items()):
            written = ", ".join(info["written_in"]) or "None"
            read = ", ".join(info["read_in"]) or "None"
            lines.append(f"- self.{attr}: written in [{written}] | read in [{read}]")
        if not analysis["attribute_flow"]:
            lines.append("- None")
        lines.extend(["", "## Risk Summary"])
        for key, value in analysis["risk_summary"].items():
            lines.append(f"- {key}: {'yes' if value else 'no'}")
        lines.extend(["", "## Instance Attributes"])
        lines.extend([f"- {name}" for name in instance_attributes] or ["- None"])
        lines.extend(["", "## Imports"])
        lines.extend([f"- {name}" for name in module["imports"]] or ["- None"])
        lines.extend(["", "## Interesting Calls"])
        lines.extend([f"- {name}" for name in module["interesting_calls"]] or ["- None"])
        lines.extend(["", "## File References"])
        lines.extend([f"- {name}" for name in module["files"]] or ["- None"])
        lines.extend(["", "## Top Assignments"])
        for item in module["assignments"][:10]:
            lines.append(f"- {', '.join(item['targets'])} = {item['value']}")
        if not module["assignments"]:
            lines.append("- None")
        return lines

    def write_outputs(self, output_dir, analysis):
        summary_path = output_dir / "summary.md"
        summary_json_path = output_dir / "summary.json"
        summary_path.write_text(
            "\n".join(self.build_summary_lines(analysis)) + "\n", encoding="utf-8"
        )
        summary_json_path.write_text(json.dumps(analysis, indent=2), encoding="utf-8")
        return summary_path, summary_json_path

    def build_cli_summary(self, result, include_methods=False):
        """
        Builds a stable plain-text summary for the explain CLI.

        Args:
            result: Result dictionary returned by `explain(...)`.
            include_methods: When `True`, includes the discovered method list.

        Returns:
            Plain-text summary routed through the shared output formatter.
        """
        fields = {"Solution file": result["solution_file"]}
        if result.get("output_dir") is not None:
            fields["Output directory"] = result["output_dir"]
            fields["Summary"] = result["summary_path"]
            fields["JSON Summary"] = result["summary_json_path"]

        lines = [self.output.format_kv(fields)]

        if include_methods:
            methods = sorted(result["analysis"]["solution"].get("methods", {}).keys())
            lines.extend(
                [
                    "",
                    self.output.format_section(
                        "Methods",
                        [self.output.format_list(methods).replace("- None", "- None")],
                    ),
                ]
            )

        return "\n".join(line for line in lines if line)

    def explain(self, save=True):
        solution_file = self.get_solution_file()
        analysis = self.analyze_solution(solution_file)
        result = {
            "solution_file": solution_file,
            "analysis": analysis,
        }
        if save:
            output_dir = self.get_output_dir()
            summary_path, summary_json_path = self.write_outputs(output_dir, analysis)
            result["output_dir"] = output_dir
            result["summary_path"] = summary_path
            result["summary_json_path"] = summary_json_path
        else:
            result["output_dir"] = None
            result["summary_path"] = None
            result["summary_json_path"] = None
            result["summary_text"] = "\n".join(self.build_summary_lines(analysis)) + "\n"
        return result
