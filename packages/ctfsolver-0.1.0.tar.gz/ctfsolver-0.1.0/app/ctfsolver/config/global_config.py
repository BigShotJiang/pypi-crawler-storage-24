"""
Global configuration management for the CTFSolverScript package.

This module provides the `GlobalConfig` class, which handles the creation, initialization,
and access of a global configuration file stored in the user's home directory. The configuration
file is used to store persistent settings required by the CTFSolverScript inline tool.

Classes:
    GlobalConfig: Manages the global configuration file, including creation, initialization,
                  reading, and attribute/dictionary-style access to configuration values.

Attributes:
    CONFIG (GlobalConfig): Singleton instance of the GlobalConfig class for global access.

Example:
    >>> from ctfsolver.config.global_config import CONFIG
    >>> from ctfsolver.config import CONFIG
    >>> CONFIG.initializing()  # Initializes the global configuration

Typical usage involves initializing the configuration (creating the file and writing initial
content if necessary) and accessing configuration values via attribute or dictionary-style access.

Raises:
    AttributeError: If an attribute is accessed that does not exist in the configuration.
    KeyError: If a key is accessed that does not exist in the configuration.
"""

import json
from pathlib import Path
from ctfsolver.managers.manager_output import ManagerOutput


class GlobalConfig:
    CHOOSER_FUNCTION_MAP_FILENAME = "chooser_function_map.json"

    def __init__(self, *args, **kwargs):
        """
        Initializes the global configuration for the CTF solver application.
        This constructor sets the path to the global configuration file and loads its content.

        Attributes:
            global_config_file_path (Path): Path to the global configuration JSON file.

        Raises:
            Any exceptions raised by `get_content()` will propagate.
        """

        # Path to the global configuration file in the user's home directory

        self.verbose = kwargs.get("verbose", False)
        self.output = kwargs.get("output_manager", None) or ManagerOutput()
        self.global_config_file_path = Path(
            Path.home(), ".config", "ctfsolver", "global_config.json"
        )
        self.chooser_function_map_file_path = self.global_config_file_path.with_name(
            self.CHOOSER_FUNCTION_MAP_FILENAME
        )
        self.get_content()

    def _load_template_content(self):
        template_path = Path(
            Path(__file__).parent.parent, "data", "config_template.json"
        )
        if not template_path.exists():
            self.output.warn(
                f"Template file {template_path} not found. Using default initial content."
            )
            return template_path, {}
        with open(template_path, "r") as template_file:
            return template_path, json.load(template_file)

    def _write_content(self):
        self.global_config_file_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.global_config_file_path, "w") as config_file:
            json.dump(self.content, config_file, indent=4)
            config_file.write("\n")
        return self.content

    def _read_json_file(self, file_path, default):
        """
        Read a JSON file when present and fall back to a caller-provided default.
        """
        if not file_path.exists() or file_path.stat().st_size == 0:
            return default
        with open(file_path, "r") as json_file:
            return json.load(json_file)

    def _write_json_file(self, file_path, data):
        """
        Persist one small JSON payload to disk using the project's stable formatting.
        """
        file_path.parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, "w") as json_file:
            json.dump(data, json_file, indent=4)
            json_file.write("\n")
        return data

    def _merge_missing_keys(self, current, defaults):
        if not isinstance(current, dict) or not isinstance(defaults, dict):
            return current

        for key, value in defaults.items():
            if key not in current:
                current[key] = value
                continue
            if isinstance(current[key], dict) and isinstance(value, dict):
                self._merge_missing_keys(current[key], value)
        return current

    def initializing(self):
        """
        Initialize global configuration settings.
        This method can be used to set up any necessary global configurations
        required by the inline tool.
        """
        self.creating()
        state = self.initial_content()
        self.output.success("Global configuration initialized.")
        self.output.info(self.build_initialization_summary(state))

    def creating(self):
        """
        Creates a global configuration file in the user's home directory.

        This method ensures that the required directories and configuration file exist,
        creating them if necessary. It is typically called during the initial run of the
        inline tool or when global configuration setup is required.

        Args:
            None

        Returns:
            None

        Raises:
            OSError: If the directory or file cannot be created due to permission issues.
        """

        home_path = Path.home()
        if self.verbose:
            self.output.info(f"Setting up global configuration in {home_path}", level=2)

        # TODO: This should later be initialized in the ctfsolver to be a global attribute

        # Path  of the config file, creates the folders and the file if they don't exist

        self.global_config_file_path.parent.mkdir(parents=True, exist_ok=True)
        self.global_config_file_path.touch(exist_ok=True)

    def initial_content(self):
        """
        Sets the initial content of the global configuration file.

        This method loads a configuration template from 'config_template.json' and writes it to the global
        configuration file if the file is empty or does not exist. If the template file is missing, a default
        initial content is used instead.

        Args:
            None

        Returns:
            None

        Raises:
            FileNotFoundError: If the template file or global configuration file path does not exist.
            json.JSONDecodeError: If the template file contains invalid JSON.

        Side Effects:
            Writes initial configuration content to the global configuration file if it is empty.
            Prints status messages to the console.
        """

        # Load the template content from config_template.json
        # Changed the location of the config_template, to keep all the data files together.
        # template_path = Path(Path(__file__).parent, "config_template.json")
        template_path, initial_content = self._load_template_content()

        # Check if the file is empty or does not exist
        if self.global_config_file_path.stat().st_size == 0:
            with open(self.global_config_file_path, "w") as f:
                json.dump(initial_content, f, indent=4)
            self.output.success(f"Initial content written to {self.global_config_file_path}")
            return {
                "path": self.global_config_file_path,
                "template_path": template_path,
                "status": "written",
            }
        else:
            self.output.info(
                f"{self.global_config_file_path} already contains initial content."
            )
            return {
                "path": self.global_config_file_path,
                "template_path": template_path,
                "status": "existing",
            }

    def get_content(self):
        """
        Get the content of the global configuration file.
        This method reads the global configuration file and returns its content
        as a dictionary.
        If the file does not exist or is empty, it returns an empty dictionary.
        It is intended to be used to retrieve the current global configuration
        settings for use in the inline tool or other parts of the application.


        Returns:
            dict: The content of the global configuration file as a dictionary.
        """
        self.content = {}
        if not self.global_config_file_path.exists():
            return self.content
        if self.global_config_file_path.stat().st_size == 0:
            return self.content
        with open(self.global_config_file_path, "r") as config_file:
            self.content = json.load(config_file)
        return self.content

    def save_content(self):
        """
        Persist the current in-memory configuration to disk.
        """
        return self._write_content()

    def ensure_template_defaults(self):
        """
        Merge any missing keys from the shipped template into the current config.
        """
        _, template_content = self._load_template_content()
        if not isinstance(self.content, dict):
            self.content = {}
        previous = json.dumps(self.content, sort_keys=True)
        self._merge_missing_keys(self.content, template_content)
        if json.dumps(self.content, sort_keys=True) != previous:
            self._write_content()
        return self.content

    def update_section(self, section, value):
        """
        Replace one top-level config section and persist the change.
        """
        if not isinstance(self.content, dict):
            self.content = {}
        self.content[section] = value
        self._write_content()
        return self.content[section]

    def get_section(self, section, default=None):
        """
        Return one top-level config section without raising on missing keys.
        """
        if not isinstance(self.content, dict):
            return default
        return self.content.get(section, default)

    def get_chooser_data(self):
        """
        Return chooser metadata plus the cached category map from its sidecar file.
        """
        self.ensure_template_defaults()
        chooser = self.content.get("chooser", {})
        if not isinstance(chooser, dict):
            chooser = {}
        chooser.setdefault(
            "function_map_file", self.chooser_function_map_file_path.name
        )
        chooser_map_path = self.global_config_file_path.with_name(
            chooser["function_map_file"]
        )

        # Migrate older configs that stored the whole chooser map inline.
        inline_map = chooser.pop("category_function_map", None)
        content_changed = inline_map is not None or self.content.get("chooser") != chooser
        if isinstance(inline_map, dict):
            self._write_json_file(chooser_map_path, inline_map)

        chooser_map = self._read_json_file(chooser_map_path, {})
        if not isinstance(chooser_map, dict):
            chooser_map = {}

        self.content["chooser"] = chooser
        if content_changed:
            self._write_content()
        return {**chooser, "category_function_map": chooser_map}

    def set_chooser_data(self, chooser_data):
        """
        Persist chooser metadata in global config and the function map in a sibling file.
        """
        self.ensure_template_defaults()
        chooser_data = dict(chooser_data or {})
        chooser_map = chooser_data.pop("category_function_map", {})
        chooser = dict(self.content.get("chooser", {}))
        chooser.update(chooser_data)
        chooser["function_map_file"] = chooser.get(
            "function_map_file", self.chooser_function_map_file_path.name
        )
        chooser.pop("category_function_map", None)

        chooser_map_path = self.global_config_file_path.with_name(
            chooser["function_map_file"]
        )
        if not isinstance(chooser_map, dict):
            chooser_map = {}

        self._write_json_file(chooser_map_path, chooser_map)
        self.update_section("chooser", chooser)
        return {**chooser, "category_function_map": chooser_map}

    def __getattr__(self, name):
        """
        Retrieves the value associated with the given attribute name from the internal content dictionary.

        Args:
            name (str): The name of the attribute to retrieve.

        Returns:
            Any: The value associated with the attribute name in the content dictionary.

        Raises:
            AttributeError: If the attribute name does not exist in the content dictionary.
        """
        if name in self.content:
            return self.content[name]
        raise AttributeError(f"'GlobalConfig' object has no attribute '{name}'")

    def __getitem__(self, key):
        """
        Retrieves the value associated with the given key from the content dictionary.

        Args:
            key (str): The key to look up in the content dictionary.

        Returns:
            Any: The value associated with the specified key.

        Raises:
            KeyError: If the key does not exist in the content dictionary.
        """
        if key in self.content:
            return self.content[key]
        raise KeyError(f"'GlobalConfig' object has no key '{key}'")

    def check_config_content(self):
        # !TODO Checks the current config if it exists,
        # and the keys of the template config
        pass

    def build_initialization_summary(self, state):
        """
        Format a deterministic summary of the configuration initialization step.
        """
        return self.output.format_kv(
            {
                "Config path": state["path"],
                "Template path": state["template_path"],
                "Status": state["status"],
            }
        )


# Creates an instance of GlobalConfig to be accessed by all the other files
CONFIG = GlobalConfig()

# Example usage:
if __name__ == "__main__":
    global_config = GlobalConfig()
    global_config.initializing()
