# This is where the challenge info will be added
import json

from pathlib import Path
from ctfsolver.managers.manager_folder import ManagerFolder
from ctfsolver.managers.manager_output import ManagerOutput


class ChallengeConfig(ManagerFolder):
    def __init__(self, *args, **kwargs):
        self.output = kwargs.pop("output_manager", None) or ManagerOutput()
        super().__init__(*args, **{**kwargs, "init_for_challenge": False})
        # So now self.parent is the directory where the command is run
        self.challenge_info_location = Path(
            Path(__file__).parent.parent, "data", "challenge_info_template.json"
        )

    def initialize_challenge(self):
        # Initializes the challenge folder with a config file
        self.get_current_dir()
        self.create_challenge_config()

    def create_challenge_config(self):
        # Creates the challenge config file from the template
        template_data = self.get_template_data()

        template_data = self.update_challenge_info(template_data)

        challenge_config_path = Path(self.parent, "challenge_config.json")
        if challenge_config_path.exists():
            raise FileExistsError("Challenge config already exists in this directory.")
        with open(challenge_config_path, "w") as f:
            json.dump(template_data, f, indent=4)
        return challenge_config_path

    def get_template_data(self):
        if not self.challenge_info_location.exists():
            raise FileNotFoundError("Challenge info template not found.")
        with open(self.challenge_info_location, "r") as f:
            template_data = json.load(f)
        return template_data

    def update_challenge_info(self, data):
        # Update the challenge info with user input
        data["info"]["title"] = self.parent.name
        data["info"]["category"] = self.parent.parent.name
        data["info"]["site"] = self.parent.parent.parent.name
        # data["info"]["description"] = input("Description: ").strip()
        # data["info"]["author"] = input("Author: ").strip()
        return data

    def build_summary_text(self, challenge_config_path):
        """
        Format a deterministic summary for challenge-config creation.
        """
        return self.output.format_kv(
            {
                "Challenge config": Path(challenge_config_path),
                "Challenge": self.parent.name,
                "Category": self.parent.parent.name,
                "Site": self.parent.parent.parent.name,
            }
        )
