import importlib
import os
import sys
import tempfile
import unittest

from ctfsolver.managers.manager_connections import ManagerConnections
from ctfsolver.managers.manager_crypto import AES, ManagerCrypto
from ctfsolver.managers.manager_blockchain import ManagerBlockchain
from ctfsolver.managers.manager_codecs import ManagerCodecs
from ctfsolver.managers.manager_http import ManagerHTTP
from ctfsolver.managers.manager_images import ManagerImages
from ctfsolver.managers.manager_math import ManagerMath
from ctfsolver.managers.manager_parallel import ManagerParallel
from ctfsolver.managers.manager_tools import ManagerTools
from types import ModuleType
from unittest import mock


class DummyConnection:
    def __init__(self):
        self.calls = []

    def sendline(self, data):
        self.calls.append(("sendline", data))

    def send(self, data):
        self.calls.append(("send", data))

    def recvline(self, *args, **kwargs):
        self.calls.append(("recvline", args, kwargs))
        return b"hello\n"

    def recvuntil(self, delim, **kwargs):
        self.calls.append(("recvuntil", delim, kwargs))
        return b"prefix" + delim

    def interactive(self, *args, **kwargs):
        self.calls.append(("interactive", args, kwargs))


class DummyResponse:
    def __init__(self, lines):
        self._lines = lines

    def iter_lines(self, decode_unicode=True):
        return iter(self._lines)


class DummySession:
    def __init__(self):
        self.headers = {}
        self.cookies = {}
        self.calls = []

    def get(self, url, **kwargs):
        self.calls.append(("get", url, kwargs))
        return {"method": "get", "url": url, "kwargs": kwargs}

    def post(self, url, data=None, json=None, **kwargs):
        self.calls.append(("post", url, data, json, kwargs))
        return {
            "method": "post",
            "url": url,
            "data": data,
            "json": json,
            "kwargs": kwargs,
        }


class DummySignedTransaction:
    def __init__(self, raw_transaction):
        self.rawTransaction = raw_transaction


class DummyContractCall:
    def __init__(self, fn_name, args, call_result=None):
        self.fn_name = fn_name
        self.args = args
        self.call_result = call_result or {"fn": fn_name, "args": args}

    def call(self):
        return self.call_result

    def build_transaction(self, params):
        return {"fn": self.fn_name, "args": self.args, "params": params}


class DummyContractFunctions:
    def __getattr__(self, fn_name):
        def wrapper(*args):
            return DummyContractCall(fn_name, args)

        return wrapper


class DummyContract:
    def __init__(self, address, abi):
        self.address = address
        self.abi = abi
        self.functions = DummyContractFunctions()


class DummyAccountAPI:
    def from_key(self, private_key):
        return type("Account", (), {"address": f"addr:{private_key}"})()

    def sign_transaction(self, tx, private_key):
        return DummySignedTransaction((tx, private_key))


class DummyEth:
    def __init__(self):
        self.account = DummyAccountAPI()
        self.sent = []

    def contract(self, address, abi):
        return DummyContract(address, abi)

    def get_transaction_count(self, address):
        return len(address)

    def send_raw_transaction(self, raw):
        self.sent.append(raw)
        return {"tx_hash": raw}


class DummyWeb3:
    def __init__(self, provider):
        self.provider = provider
        self.eth = DummyEth()

    @staticmethod
    def HTTPProvider(url):
        return {"rpc_url": url}


def import_manager_file_class_with_fake_pcap():
    fake_manager_files_pcap_module = ModuleType("ctfsolver.managers.manager_files_pcap")

    class FakeManagerFilePcap:
        def __init__(self, *args, **kwargs):
            pass

    fake_manager_files_pcap_module.ManagerFilePcap = FakeManagerFilePcap

    with mock.patch.dict(
        sys.modules,
        {"ctfsolver.managers.manager_files_pcap": fake_manager_files_pcap_module},
    ):
        sys.modules.pop("ctfsolver.managers.manager_file", None)
        manager_file_module = importlib.import_module("ctfsolver.managers.manager_file")
    return manager_file_module.ManagerFile


class ManagerConnectionsRuntimeHelpersTest(unittest.TestCase):
    def setUp(self):
        self.manager = ManagerConnections()
        self.manager.conn = DummyConnection()
        self.manager.pwn = None

    def test_sendlineafter_waits_then_sends_line(self):
        self.manager.sendlineafter("choice: ", "2")

        self.assertEqual(
            self.manager.conn.calls,
            [
                ("recvuntil", b"choice: ", {}),
                ("sendline", b"2"),
            ],
        )

    def test_sendafter_waits_then_sends_raw_data(self):
        self.manager.sendafter("data: ", b"AAAA", encode=False)

        self.assertEqual(
            self.manager.conn.calls,
            [
                ("recvuntil", b"data: ", {}),
                ("send", b"AAAA"),
            ],
        )

    def test_recvuntil_str_decodes_bytes(self):
        self.assertEqual(self.manager.recvuntil_str("flag: "), "prefixflag: ")

    def test_pack_and_unpack_helpers_fall_back_without_pwntools(self):
        packed = self.manager.pack_u32(0x41424344)

        self.assertEqual(packed, b"DCBA")
        self.assertEqual(self.manager.unpack_u32(packed), 0x41424344)
        self.assertEqual(self.manager.unpack_u64(self.manager.pack_u64(0x1122334455667788)), 0x1122334455667788)

    def test_interactive_delegates_to_connection(self):
        self.manager.interactive()
        self.assertEqual(self.manager.conn.calls, [("interactive", (), {})])

    def test_http_helpers_use_stored_session(self):
        session = DummySession()
        self.manager.http = session

        get_result = self.manager.http_get("https://example.test/api", params={"q": "flag"})
        post_result = self.manager.json_post("https://example.test/post", {"flag": True})

        self.assertEqual(get_result["method"], "get")
        self.assertEqual(post_result["json"], {"flag": True})
        self.assertEqual(
            session.calls,
            [
                ("get", "https://example.test/api", {"params": {"q": "flag"}}),
                ("post", "https://example.test/post", None, {"flag": True}, {}),
            ],
        )

    def test_sse_message_helpers_parse_data_lines(self):
        response = DummyResponse(
            [
                "event: message",
                'data: {"flag": "flag{test}"}',
                "",
                "data: not-json",
                "data: {\"ok\": true}",
            ]
        )

        self.assertEqual(
            list(self.manager.sse_messages(response)),
            ['{"flag": "flag{test}"}', "not-json", '{"ok": true}'],
        )
        self.assertEqual(
            list(self.manager.sse_json_messages(response)),
            [{"flag": "flag{test}"}, {"ok": True}],
        )

    def test_blockchain_helpers_use_web3_client(self):
        web3 = self.manager.web3_connect("http://rpc.local", web3_class=DummyWeb3)
        contract = self.manager.web3_contract("0xabc", [{"name": "flag"}])

        self.assertEqual(web3.provider, {"rpc_url": "http://rpc.local"})
        self.assertEqual(contract.address, "0xabc")
        self.assertEqual(self.manager.call_contract(contract, "flag"), {"fn": "flag", "args": ()})

        tx_hash = self.manager.send_contract_tx(
            contract,
            "solve",
            7,
            private_key="secret",
            tx_params={"chainId": 1},
        )

        self.assertEqual(
            tx_hash,
            {
                "tx_hash": (
                    {
                        "fn": "solve",
                        "args": (7,),
                        "params": {"chainId": 1, "nonce": len("addr:secret")},
                    },
                    "secret",
                )
            },
        )


class ManagerSplitOrganizationTest(unittest.TestCase):
    def test_manager_connections_inherits_http_and_blockchain_helpers(self):
        self.assertTrue(issubclass(ManagerConnections, ManagerHTTP))
        self.assertTrue(issubclass(ManagerConnections, ManagerBlockchain))
        self.assertTrue(hasattr(ManagerConnections, "http_get"))
        self.assertTrue(hasattr(ManagerConnections, "web3_connect"))

    def test_manager_crypto_inherits_codecs_math_and_parallel_helpers(self):
        self.assertTrue(issubclass(ManagerCrypto, ManagerCodecs))
        self.assertTrue(issubclass(ManagerCrypto, ManagerMath))
        self.assertTrue(issubclass(ManagerCrypto, ManagerParallel))
        self.assertTrue(hasattr(ManagerCrypto, "decode_hex"))
        self.assertTrue(hasattr(ManagerCrypto, "gcd"))
        self.assertTrue(hasattr(ManagerCrypto, "bruteforce_iter"))

    def test_manager_file_inherits_tool_and_image_helpers(self):
        manager_file_class = import_manager_file_class_with_fake_pcap()

        self.assertTrue(issubclass(manager_file_class, ManagerTools))
        self.assertTrue(issubclass(manager_file_class, ManagerImages))
        self.assertTrue(hasattr(manager_file_class, "run_cmd"))
        self.assertTrue(hasattr(manager_file_class, "image_dimensions"))


class ManagerCryptoRuntimeHelpersTest(unittest.TestCase):
    def setUp(self):
        self.crypto = ManagerCrypto()

    def test_decode_and_encode_hex(self):
        self.assertEqual(self.crypto.decode_hex("666c6167"), "flag")
        self.assertEqual(self.crypto.encode_hex("flag"), "666c6167")

    def test_decode_binary_and_rot13(self):
        self.assertEqual(self.crypto.decode_binary("01100110 01101100 01100001 01100111"), "flag")
        self.assertEqual(self.crypto.decode_rot13("synt"), "flag")

    def test_bytes_and_int_helpers(self):
        data = self.crypto.int_to_bytes(0x666c6167)
        self.assertEqual(data, b"flag")
        self.assertEqual(self.crypto.bytes_to_int(b"flag"), 0x666c6167)
        self.assertEqual(self.crypto.gcd(54, 24), 6)
        self.assertEqual(self.crypto.modinv(3, 11), 4)

    def test_xor_bytes_and_bruteforce(self):
        ciphertext = self.crypto.xor_bytes(b"flag", b"\x01")
        self.assertEqual(ciphertext, b"gm`f")

        candidates = self.crypto.xor_single_byte_bruteforce(ciphertext)
        self.assertEqual(candidates[0]["decoded_text"], "flag")
        self.assertEqual(candidates[0]["key"], 1)

    def test_apply_decode_chain(self):
        value = self.crypto.apply_decode_chain(
            "666c6167",
            [{"name": "hex"}, {"name": "rot", "kwargs": {"shift": 13}}],
        )
        self.assertEqual(value, "synt")

    def test_pkcs7_pad_and_unpad(self):
        padded = self.crypto.pkcs7_pad(b"flag", 8)
        self.assertEqual(padded, b"flag\x04\x04\x04\x04")
        self.assertEqual(self.crypto.pkcs7_unpad(padded, 8), b"flag")

    def test_number_theory_helpers(self):
        self.assertEqual(self.crypto.int_nth_root(27, 3), (3, True))
        self.assertEqual(self.crypto.int_nth_root(28, 3), (3, False))
        self.assertEqual(self.crypto.crt_solve([2, 3, 2], [3, 5, 7]), (23, 105))
        self.assertEqual(self.crypto.factor_small(84), [2, 2, 3, 7])

    def test_chunked_helper(self):
        self.assertEqual(list(self.crypto.chunked(range(5), 2)), [[0, 1], [2, 3], [4]])

    def test_bruteforce_iter_returns_first_or_all_matches(self):
        first = self.crypto.bruteforce_iter(
            range(10),
            lambda candidate: candidate if candidate == 7 else None,
            processes=2,
        )
        self.assertEqual(first, 7)

        all_matches = self.crypto.bruteforce_iter(
            range(8),
            lambda candidate: candidate if candidate % 3 == 0 else None,
            processes=2,
            stop_on_first=False,
        )
        self.assertEqual(sorted(all_matches), [0, 3, 6])

    @unittest.skipIf(AES is None, "pycryptodome not installed")
    def test_aes_cbc_encrypt_and_decrypt(self):
        key = b"0123456789abcdef"
        iv = b"0123456789abcdef"
        plaintext = "flag{test}"

        encrypted = self.crypto.aes_cbc_encrypt(plaintext, key, iv, output_format="base64")
        decrypted = self.crypto.aes_cbc_decrypt(encrypted, key, iv=iv, input_format="base64")

        self.assertEqual(decrypted, plaintext)


class ManagerFileRuntimeHelpersTest(unittest.TestCase):
    def setUp(self):
        self.manager = import_manager_file_class_with_fake_pcap()()

    def test_run_cmd_captures_output(self):
        result = self.manager.run_cmd([sys.executable, "-c", "print('flag')"])
        self.assertEqual(result.stdout.strip(), "flag")

    def test_run_shell_captures_output(self):
        result = self.manager.run_shell("printf flag")
        self.assertEqual(result.stdout, "flag")

    def test_strings_extracts_printable_sequences(self):
        with tempfile.NamedTemporaryFile("wb", delete=False) as handle:
            handle.write(b"\x00flag\x00ABCD\x01no")
            path = handle.name

        self.assertEqual(
            self.manager.strings(path),
            ["flag", "ABCD"],
        )

    def test_sha256_file_hashes_contents(self):
        with tempfile.NamedTemporaryFile("wb", delete=False) as handle:
            handle.write(b"flag")
            path = handle.name

        self.assertEqual(
            self.manager.sha256_file(path),
            "807d0fbcae7c4b20518d4d85664f6820aafdf936104122c5073e7744c46c4b87",
        )

    def test_tool_exists_checks_path(self):
        self.assertTrue(self.manager.tool_exists("python"))

    def test_image_dimensions_and_pixels_require_pillow(self):
        try:
            from PIL import Image
        except ModuleNotFoundError:
            self.skipTest("Pillow not installed")

        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as handle:
            path = handle.name

        image = Image.new("RGB", (2, 1))
        image.putdata([(255, 0, 0), (0, 255, 0)])
        image.save(path)

        self.assertEqual(self.manager.image_dimensions(path), (2, 1))
        self.assertEqual(self.manager.image_pixels(path), [(255, 0, 0), (0, 255, 0)])

    def test_extract_lsb_bytes_and_rebuild_image_require_pillow(self):
        try:
            from PIL import Image
        except ModuleNotFoundError:
            self.skipTest("Pillow not installed")

        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as handle:
            source_path = handle.name
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as handle:
            rebuilt_path = handle.name

        bits = "01000001"
        pixels = []
        for bit in bits:
            value = 1 if bit == "1" else 0
            pixels.append((value, 0, 0, 255))

        image = Image.new("RGBA", (len(pixels), 1))
        image.putdata(pixels)
        image.save(source_path)

        extracted = self.manager.extract_lsb_bytes(source_path, channels=("r",))
        self.assertEqual(extracted, b"A")

        target = self.manager.save_rebuilt_image(
            rebuilt_path,
            [(10, 20, 30), (40, 50, 60)],
            (2, 1),
        )
        self.assertTrue(os.path.exists(target))


if __name__ == "__main__":
    unittest.main()
