import unittest

from ctfsolver.managers.manager_class import ManagerClass
from ctfsolver.managers.manager_output import ManagerOutput


class ManagerClassOutputTest(unittest.TestCase):
    def test_build_example_output_formats_inspection_summary(self):
        manager = ManagerClass(output_manager=ManagerOutput(sink=lambda _: None))

        rendered = manager.build_example_output(
            {
                "mro": ["Child", "Base"],
                "methods": {
                    "run": {
                        "kind": "instance",
                        "inherited": False,
                        "defined_in": "Child",
                    }
                },
                "class_attributes": {
                    "name": {"inherited": False, "defined_in": "Child"}
                },
                "instance_attributes": {
                    "conn": [{"defined_in": "Child", "method": "__init__"}]
                },
            }
        )

        self.assertIn("MRO (best-effort)", rendered)
        self.assertIn("Methods (incl. inherited)", rendered)
        self.assertIn("Class attributes (incl. inherited)", rendered)
        self.assertIn("Instance attributes", rendered)
        self.assertIn("run", rendered)


if __name__ == "__main__":
    unittest.main()
