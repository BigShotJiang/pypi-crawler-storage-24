import importlib
import os
import sys
import unittest

from pathlib import Path
from tempfile import TemporaryDirectory
from types import ModuleType
from unittest import mock

from typer.testing import CliRunner

from ctfsolver.managers.manager_output import ManagerOutput


def import_gather_components_with_fake_pcap():
    fake_manager_files_pcap_module = ModuleType("ctfsolver.managers.manager_files_pcap")

    class FakeManagerFilePcap:
        def __init__(self, *args, **kwargs):
            pass

    fake_manager_files_pcap_module.ManagerFilePcap = FakeManagerFilePcap

    with mock.patch.dict(
        sys.modules,
        {"ctfsolver.managers.manager_files_pcap": fake_manager_files_pcap_module},
    ):
        sys.modules.pop("ctfsolver.managers.manager_file", None)
        sys.modules.pop("ctfsolver.find_usage.manager_gathering", None)
        sys.modules.pop("ctfsolver.cli.subcli.gather", None)
        gathering_module = importlib.import_module("ctfsolver.find_usage.manager_gathering")
        gather_cli_module = importlib.import_module("ctfsolver.cli.subcli.gather")
    return gathering_module.ManagerGathering, gather_cli_module.gather_app, gather_cli_module


class ManagerOutputTest(unittest.TestCase):
    def test_emit_respects_verbosity(self):
        seen = []
        output = ManagerOutput(verbosity=1, sink=seen.append)

        output.debug("hidden")
        output.info("shown")

        self.assertEqual(seen, ["shown"])

    def test_format_table_and_kv_are_stable_plain_text(self):
        output = ManagerOutput(sink=lambda _: None)

        table = output.format_table([["alpha", "1"], ["beta", "22"]], headers=["name", "count"])
        kv = output.format_kv({"Output directory": "/tmp/out", "Summary": "/tmp/out/a.md"})

        self.assertIn("name", table)
        self.assertIn("alpha", table)
        self.assertIn("Output directory", kv)
        self.assertIn("/tmp/out/a.md", kv)


class ManagerGatheringOutputIntegrationTest(unittest.TestCase):
    def test_build_output_summary_uses_output_formatter(self):
        ManagerGathering, _, _ = import_gather_components_with_fake_pcap()
        output = ManagerOutput(sink=lambda _: None)
        manager = ManagerGathering(ctf_root=Path("/tmp/ctf"), output_manager=output)

        summary = manager.build_output_summary(
            Path("/tmp/docs/gather_data"),
            Path("/tmp/docs/gather_data/corpus_summary.md"),
            Path("/tmp/docs/gather_data/corpus_summary.json"),
        )

        self.assertIn("Output directory", summary)
        self.assertIn("corpus_summary.md", summary)
        self.assertIn("corpus_summary.json", summary)


class GatherCliOutputTest(unittest.TestCase):
    def test_gather_corpus_print_only_uses_output_layer(self):
        _, gather_app, gather_cli_module = import_gather_components_with_fake_pcap()
        runner = CliRunner()

        with mock.patch.object(gather_cli_module.gather_manager, "gather_corpus") as gather_corpus:
            with mock.patch.object(
                gather_cli_module.gather_manager, "build_corpus_summary_lines"
            ) as build_lines:
                gather_corpus.return_value = {"stats": {}, "ctf_root": "/tmp/ctf", "duplicates": []}
                build_lines.return_value = ["# Summary", "", "- item"]

                result = runner.invoke(gather_app, ["corpus", "--print-only"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("# Summary", result.stdout)
        self.assertIn("- item", result.stdout)

    def test_gather_corpus_write_mode_prints_structured_summary(self):
        _, gather_app, gather_cli_module = import_gather_components_with_fake_pcap()
        runner = CliRunner()

        with TemporaryDirectory() as tmp_dir:
            output_dir = Path(tmp_dir, "docs", "gather_data")
            output_dir.mkdir(parents=True)
            markdown_path = output_dir / "corpus_summary.md"
            json_path = output_dir / "corpus_summary.json"
            markdown_path.write_text("# Summary\n", encoding="utf-8")
            json_path.write_text("{}", encoding="utf-8")

            with mock.patch.object(gather_cli_module.gather_manager, "gather_corpus") as gather_corpus:
                with mock.patch.object(
                    gather_cli_module.gather_manager, "build_corpus_summary_lines"
                ) as build_lines:
                    with mock.patch.object(
                        gather_cli_module.gather_manager, "write_output"
                    ) as write_output:
                        gather_corpus.return_value = {
                            "stats": {},
                            "ctf_root": "/tmp/ctf",
                            "duplicates": [],
                        }
                        build_lines.return_value = ["# Summary"]
                        write_output.return_value = (output_dir, markdown_path, json_path)

                        result = runner.invoke(gather_app, ["corpus"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("[ok] Gather corpus summary written", result.stdout)
        self.assertIn("Output directory", result.stdout)
        self.assertIn("corpus_summary.json", result.stdout)


if __name__ == "__main__":
    unittest.main()
