import unittest

from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import mock

from typer.testing import CliRunner

from ctfsolver.managers.manager_output import ManagerOutput
from ctfsolver.venv.manager_venv import ManagerVenv
from ctfsolver.cli.subcli import venv as venv_cli_module


class ManagerVenvOutputTest(unittest.TestCase):
    def test_build_lookup_summary_formats_results(self):
        manager = ManagerVenv.__new__(ManagerVenv)
        manager.output = ManagerOutput(sink=lambda _: None)
        manager.venv_dir = "/tmp/venvs"

        summary = manager.build_lookup_summary(
            [Path("/tmp/venvs/alpha"), Path("/tmp/venvs/beta")],
            search_path="/tmp/venvs",
        )

        self.assertIn("Search path", summary)
        self.assertIn("Virtual environments found", summary)
        self.assertIn("/tmp/venvs/alpha", summary)
        self.assertIn("/tmp/venvs/beta", summary)

    def make_fake_venv(self, root: Path) -> Path:
        venv = Path(root, "demo_venv")
        Path(venv, "bin").mkdir(parents=True)
        Path(venv, "bin", "activate").write_text("activate\n")
        Path(venv, "bin", "python").write_text("python\n")
        Path(venv, "pyvenv.cfg").write_text("home = /usr/bin\n")
        return venv

    def test_create_shortcut_and_read_shortcut_round_trip(self):
        with TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            venv_path = self.make_fake_venv(root)
            challenge = Path(root, "challenge")
            challenge.mkdir()

            manager = ManagerVenv.__new__(ManagerVenv)
            manager.output = ManagerOutput(sink=lambda _: None)
            manager.parent = challenge

            shortcut = manager.create_shortcut(folder=challenge, venv_path=venv_path)
            resolved = manager.read_shortcut(challenge)
            self.assertTrue(shortcut.exists())
            self.assertEqual(resolved, venv_path)

    def test_save_dependencies_writes_requirements_and_tree_files(self):
        with TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            venv_path = self.make_fake_venv(root)
            output_dir = Path(root, "exports")

            manager = ManagerVenv.__new__(ManagerVenv)
            manager.output = ManagerOutput(sink=lambda _: None)
            manager.parent = root
            manager.venv_to_check = None

            with mock.patch.object(
                manager, "get_dependencies", return_value=["requests==2.32.0"]
            ):
                with mock.patch.object(
                    manager,
                    "get_pipdeptree",
                    return_value=[{"package_name": "requests"}],
                ):
                    metadata = manager.save_dependencies(
                        folder=venv_path, output_dir=output_dir
                    )
            self.assertTrue(metadata["requirements_path"].exists())
            self.assertTrue(metadata["pipdeptree_path"].exists())
            self.assertIn("requests==2.32.0", metadata["requirements_path"].read_text())

    def test_move_venv_moves_to_global_dir_and_creates_shortcut(self):
        with TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            venv_path = self.make_fake_venv(root)
            global_store = Path(root, "global_venvs")

            manager = ManagerVenv.__new__(ManagerVenv)
            manager.output = ManagerOutput(sink=lambda _: None)
            manager.parent = root
            manager.venv_dir = global_store
            manager.venv_to_check = None

            with mock.patch.object(
                manager,
                "save_dependencies",
                return_value={
                    "requirements_path": Path(venv_path, "requirements.txt"),
                    "pipdeptree_path": Path(venv_path, "pipdeptree.json"),
                },
            ):
                result = manager.move_venv(folder=venv_path)
            self.assertEqual(result["destination"], Path(global_store, "demo_venv"))
            self.assertTrue(result["destination"].exists())
            self.assertTrue(result["shortcut"].exists())

    def test_clean_venv_can_delete_after_export(self):
        with TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            venv_path = self.make_fake_venv(root)

            manager = ManagerVenv.__new__(ManagerVenv)
            manager.output = ManagerOutput(sink=lambda _: None)
            manager.parent = root
            manager.venv_to_check = None

            with mock.patch.object(
                manager,
                "save_dependencies",
                return_value={
                    "venv_path": venv_path,
                    "output_dir": Path(venv_path, "ctfsolver_venv_metadata"),
                    "requirements_path": Path(venv_path, "ctfsolver_venv_metadata", "requirements.txt"),
                    "pipdeptree_path": Path(venv_path, "ctfsolver_venv_metadata", "pipdeptree.json"),
                    "dependency_count": 1,
                    "pipdeptree_count": 1,
                },
            ):
                result = manager.clean_venv(folder=venv_path, delete=True)
            self.assertTrue(result["deleted"])
            self.assertFalse(venv_path.exists())


class VenvCliOutputTest(unittest.TestCase):
    def test_look_for_venv_uses_output_layer(self):
        runner = CliRunner()

        with mock.patch.object(venv_cli_module.manager, "look_for_venvs") as look_for_venvs:
            with mock.patch.object(
                venv_cli_module.manager, "build_lookup_summary"
            ) as build_lookup_summary:
                look_for_venvs.return_value = [Path("/tmp/venvs/alpha")]
                build_lookup_summary.return_value = (
                    "- Search path              : /tmp/venvs\n"
                    "- Virtual environments found : 1\n\n"
                    "Discovered environments\n"
                    "- /tmp/venvs/alpha"
                )

                result = runner.invoke(venv_cli_module.venv_app, ["look_for"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("[ok] Venv lookup completed.", result.stdout)
        self.assertIn("Discovered environments", result.stdout)
        self.assertIn("/tmp/venvs/alpha", result.stdout)

    def test_activation_command_uses_shortcut_or_explicit_venv(self):
        runner = CliRunner()

        with mock.patch.object(
            venv_cli_module.manager, "build_activation_command", return_value="source /tmp/venv/bin/activate"
        ) as build_activation_command:
            result = runner.invoke(
                venv_cli_module.venv_app,
                ["activation", "--venv", "/tmp/venv"],
            )

        self.assertEqual(result.exit_code, 0)
        self.assertIn("source /tmp/venv/bin/activate", result.stdout)
        self.assertTrue(build_activation_command.called)

    def test_save_command_uses_dependency_summary(self):
        runner = CliRunner()

        with mock.patch.object(
            venv_cli_module.manager,
            "save_dependencies",
            return_value={
                "venv_path": Path("/tmp/venv"),
                "output_dir": Path("/tmp/meta"),
                "requirements_path": Path("/tmp/meta/requirements.txt"),
                "pipdeptree_path": Path("/tmp/meta/pipdeptree.json"),
                "dependency_count": 1,
                "pipdeptree_count": 1,
            },
        ):
            with mock.patch.object(
                venv_cli_module.manager,
                "build_dependency_summary",
                return_value="- Venv path : /tmp/venv",
            ):
                result = runner.invoke(
                    venv_cli_module.venv_app,
                    ["save", "--venv", "/tmp/venv"],
                )

        self.assertEqual(result.exit_code, 0)
        self.assertIn("Venv dependencies exported", result.stdout)
        self.assertIn("/tmp/venv", result.stdout)


if __name__ == "__main__":
    unittest.main()
