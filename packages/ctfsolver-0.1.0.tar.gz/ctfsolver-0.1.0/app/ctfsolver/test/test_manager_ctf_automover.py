import unittest

from pathlib import Path

from ctfsolver.managers.manager_ctf_automover import ManagerCTFAutoMover
from ctfsolver.managers.manager_output import ManagerOutput


class DummyManagerFolder:
    def __init__(self, path):
        self.parent = Path(path)
        self.folders_name_list = ["data", "files", "payloads"]
        self.calls = []
        self.current_dir_calls = 0

    def get_current_dir(self):
        self.current_dir_calls += 1

    def download_automove(
        self, category, challenge_name, challenge_path, checker=False, verbose=False
    ):
        self.calls.append(
            {
                "category": category,
                "challenge_name": challenge_name,
                "challenge_path": Path(challenge_path),
                "checker": checker,
                "verbose": verbose,
            }
        )


class ManagerCTFAutoMoverTest(unittest.TestCase):
    def test_get_challenge_path_uses_parent_for_named_subfolders(self):
        manager_folder = DummyManagerFolder(
            "/tmp/ctf-data/crypto/picoctf/warmup/payloads"
        )
        automover = ManagerCTFAutoMover(manager_folder=manager_folder)

        self.assertEqual(
            automover.get_challenge_path(manager_folder.parent),
            Path("/tmp/ctf-data/crypto/picoctf/warmup"),
        )

    def test_resolve_context_from_challenge_root(self):
        manager_folder = DummyManagerFolder("/tmp/ctf-data/crypto/picoctf/warmup")
        automover = ManagerCTFAutoMover(manager_folder=manager_folder)

        context = automover.resolve_context()

        self.assertEqual(context["category"], "crypto")
        self.assertEqual(context["challenge_name"], "warmup")
        self.assertEqual(context["challenge_path"], Path("/tmp/ctf-data/crypto/picoctf/warmup"))
        self.assertEqual(manager_folder.current_dir_calls, 1)

    def test_automove_delegates_with_resolved_context(self):
        manager_folder = DummyManagerFolder("/tmp/ctf-data/rev/ctftime/vault/files")
        automover = ManagerCTFAutoMover(manager_folder=manager_folder)

        context = automover.automove(checker=True, verbose=True)

        self.assertEqual(context["category"], "rev")
        self.assertEqual(context["challenge_name"], "vault")
        self.assertEqual(
            manager_folder.calls,
            [
                {
                    "category": "rev",
                    "challenge_name": "vault",
                    "challenge_path": Path("/tmp/ctf-data/rev/ctftime/vault"),
                    "checker": True,
                    "verbose": True,
                }
            ],
        )

    def test_manager_file_kwarg_still_maps_to_manager_folder(self):
        manager_folder = DummyManagerFolder("/tmp/ctf-data/rev/ctftime/vault")

        automover = ManagerCTFAutoMover(manager_file=manager_folder)

        self.assertIs(automover.manager_folder, manager_folder)

    def test_build_summary_text_formats_context(self):
        automover = ManagerCTFAutoMover(
            manager_folder=DummyManagerFolder("/tmp/ctf-data/rev/ctftime/vault"),
            output_manager=ManagerOutput(),
        )

        summary = automover.build_summary_text(
            {
                "category": "rev",
                "challenge_name": "vault",
                "challenge_path": Path("/tmp/ctf-data/rev/ctftime/vault"),
            }
        )

        self.assertIn("- Category", summary)
        self.assertIn("rev", summary)
        self.assertIn("vault", summary)
        self.assertIn("/tmp/ctf-data/rev/ctftime/vault", summary)


if __name__ == "__main__":
    unittest.main()
