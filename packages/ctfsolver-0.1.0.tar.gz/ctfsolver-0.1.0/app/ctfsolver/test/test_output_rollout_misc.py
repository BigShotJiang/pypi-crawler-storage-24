import importlib
import unittest

from pathlib import Path
from types import ModuleType
from unittest import mock

from typer.testing import CliRunner

from ctfsolver.config.challenge_config import ChallengeConfig


def import_ctf_cli_with_fake_pcap():
    import sys

    fake_manager_files_pcap_module = ModuleType("ctfsolver.managers.manager_files_pcap")

    class FakeManagerFilePcap:
        def __init__(self, *args, **kwargs):
            pass

    fake_manager_files_pcap_module.ManagerFilePcap = FakeManagerFilePcap

    with mock.patch.dict(
        sys.modules,
        {"ctfsolver.managers.manager_files_pcap": fake_manager_files_pcap_module},
    ):
        sys.modules.pop("ctfsolver.managers.manager_file", None)
        sys.modules.pop("ctfsolver.cli.subcli.ctf", None)
        return importlib.import_module("ctfsolver.cli.subcli.ctf")


class ChallengeConfigOutputTest(unittest.TestCase):
    def test_build_summary_text_formats_challenge_config_context(self):
        config = ChallengeConfig.__new__(ChallengeConfig)
        from ctfsolver.managers.manager_output import ManagerOutput

        config.output = ManagerOutput(sink=lambda _: None)
        config.parent = Path("/tmp/ctf-data/Crypto/picoCTF/WarmUp")

        summary = config.build_summary_text("/tmp/ctf-data/Crypto/picoCTF/WarmUp/challenge_config.json")

        self.assertIn("Challenge config", summary)
        self.assertIn("WarmUp", summary)
        self.assertIn("Crypto", summary)
        self.assertIn("picoCTF", summary)


class CtfCliOutputRolloutTest(unittest.TestCase):
    def test_create_uses_doc_creation_check_option(self):
        ctf_cli_module = import_ctf_cli_with_fake_pcap()
        runner = CliRunner()

        with mock.patch.object(ctf_cli_module.ctf_creator, "create") as create:
            with mock.patch.object(
                ctf_cli_module.ctf_creator, "build_summary_text", return_value="- ok"
            ):
                create.return_value = {
                    "category": "Crypto",
                    "site": "picoCTF",
                    "name": "Warm Up",
                    "folder_name": "Warm_Up",
                    "document_name": "Warm Up",
                    "path": Path("/tmp/ctf/Crypto/picoCTF/Warm_Up"),
                    "document_path": Path("/tmp/docs/Crypto/picoCTF/Warm Up.md"),
                    "download": False,
                    "doc_creation_check": True,
                }

                result = runner.invoke(
                    ctf_cli_module.ctf_app,
                    [
                        "create",
                        "--category",
                        "Crypto",
                        "--site",
                        "picoCTF",
                        "--name",
                        "Warm Up",
                        "-m",
                    ],
                )

        self.assertEqual(result.exit_code, 0)
        create.assert_called_once_with(
            category="Crypto",
            site="picoCTF",
            name="Warm Up",
            doc_creation_check=True,
            download=False,
            verbose=False,
        )
        self.assertIn("[ok] Created challenge structure.", result.stdout)

    def test_show_uses_output_layer_summary(self):
        ctf_cli_module = import_ctf_cli_with_fake_pcap()
        runner = CliRunner()

        with mock.patch.object(ctf_cli_module.CONFIG, "get_content") as get_content:
            with mock.patch.object(
                ctf_cli_module.CONFIG,
                "content",
                {"directories": {"ctf_data": "ctf-data"}},
            ):
                with mock.patch.object(Path, "exists", return_value=True):
                    with mock.patch.object(
                        ctf_cli_module.workspace_manager, "single_folder_search"
                    ) as single_folder_search:
                        single_folder_search.return_value = (
                            "/tmp/ctf-data/Crypto/picoCTF",
                            ["WarmUp", "Vault"],
                            [],
                        )

                        result = runner.invoke(
                            ctf_cli_module.ctf_app,
                            ["show", "--category", "Crypto", "--site", "picoCTF"],
                        )

        self.assertEqual(result.exit_code, 0)
        self.assertIn("Challenges found", result.stdout)
        self.assertIn("WarmUp", result.stdout)
        self.assertIn("Vault", result.stdout)
        self.assertTrue(get_content.called)

    def test_run_uses_output_layer_summary(self):
        ctf_cli_module = import_ctf_cli_with_fake_pcap()
        runner = CliRunner()

        with mock.patch.object(
            ctf_cli_module.solution_runner, "resolve_mode", return_value="local"
        ) as resolve_mode:
            with mock.patch.object(
                ctf_cli_module.solution_runner,
                "get_solution_file",
                return_value=Path("/tmp/payloads/solution.py"),
            ):
                with mock.patch.object(
                    ctf_cli_module.solution_runner,
                    "build_run_summary",
                    return_value="- Mode : local",
                ):
                    with mock.patch.object(
                        ctf_cli_module.solution_runner, "run", return_value=0
                    ) as run_solution:
                        result = runner.invoke(
                            ctf_cli_module.ctf_app,
                            ["run", "--local", "--file", "binary"],
                        )

        self.assertEqual(result.exit_code, 0)
        self.assertIn("Mode", result.stdout)
        self.assertTrue(resolve_mode.called)
        self.assertTrue(run_solution.called)


if __name__ == "__main__":
    unittest.main()
