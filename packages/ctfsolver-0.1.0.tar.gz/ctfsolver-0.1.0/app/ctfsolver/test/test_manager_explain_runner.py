import tempfile
import unittest

from pathlib import Path

from ctfsolver.explain.manager_explain import ManagerExplainRunner
from ctfsolver.managers.manager_output import ManagerOutput


class DummyManagerFile:
    def __init__(self, challenge_root):
        self.parent = Path(challenge_root)
        self.folders_name_list = ["data", "files", "payloads", "docs"]

    def get_current_dir(self):
        return None

    def setup_named_folders(self):
        self.folder_data = self.parent / "data"
        self.folder_files = self.parent / "files"
        self.folder_payloads = self.parent / "payloads"

    def get_solution_file(self, save=True):
        assert save is True
        return self.parent / "payloads" / "solution.py"


class ChildContextDummyManagerFile(DummyManagerFile):
    def __init__(self, challenge_root, child_name):
        super().__init__(challenge_root)
        self.parent = Path(challenge_root) / child_name


class ManagerExplainRunnerTest(unittest.TestCase):
    def test_explain_writes_docs_explain_data_outputs(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            challenge_root = Path(tmp_dir)
            (challenge_root / "payloads").mkdir()
            solution_file = challenge_root / "payloads" / "solution.py"
            solution_file.write_text(
                "\n".join(
                    [
                        "from pathlib import Path",
                        "import subprocess",
                        "",
                        "class Base:",
                        "    def try_main(self):",
                        "        return self.main()",
                        "",
                        "class Solution(Base):",
                        "    def __init__(self):",
                        "        self.target = Path('files/input.txt')",
                        "    def main(self):",
                        "        self.helper()",
                        "        with open(self.target) as handle:",
                        "            data = handle.read()",
                        "        subprocess.run(['echo', data], check=False)",
                        "    def helper(self):",
                        "        return self.try_main()",
                        "",
                        "if __name__ == '__main__':",
                        "    solution = Solution()",
                        "    solution.try_main()",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            runner = ManagerExplainRunner(manager_file=DummyManagerFile(challenge_root))
            result = runner.explain()

            self.assertEqual(result["output_dir"], challenge_root / "docs" / "explain_data")
            self.assertTrue(result["summary_path"].exists())
            self.assertTrue(result["summary_json_path"].exists())
            summary_text = result["summary_path"].read_text(encoding="utf-8")
            self.assertIn("Solution Explain Summary", summary_text)
            self.assertIn("subprocess.run", summary_text)
            self.assertIn("self.target", summary_text)
            self.assertIn("Static flow guess", summary_text)
            self.assertIn("main: self -> [helper]", summary_text)
            self.assertIn("helper -> try_main", summary_text)
            self.assertIn("Method Narratives", summary_text)
            self.assertIn("writes self.target", summary_text)
            self.assertIn("reads self.target", summary_text)
            self.assertIn("side effects: file reads, subprocesses", summary_text)
            self.assertIn("Attribute Flow", summary_text)
            self.assertIn("self.target: written in [__init__] | read in [main]", summary_text)
            self.assertIn("Risk Summary", summary_text)
            self.assertIn("reads_files: yes", summary_text)
            self.assertIn("runs_subprocesses: yes", summary_text)
            self.assertIn("pathlib.Path", result["summary_json_path"].read_text(encoding="utf-8"))

    def test_explain_can_return_summary_without_writing_files(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            challenge_root = Path(tmp_dir)
            (challenge_root / "payloads").mkdir()
            solution_file = challenge_root / "payloads" / "solution.py"
            solution_file.write_text(
                "\n".join(
                    [
                        "class Solution:",
                        "    def main(self):",
                        "        return 1",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            runner = ManagerExplainRunner(manager_file=DummyManagerFile(challenge_root))
            result = runner.explain(save=False)

            self.assertIsNone(result["output_dir"])
            self.assertIsNone(result["summary_path"])
            self.assertIsNone(result["summary_json_path"])
            self.assertIn("Solution Explain Summary", result["summary_text"])
            self.assertFalse((challenge_root / "docs" / "explain_data").exists())

    def test_explain_normalizes_context_when_started_inside_named_folder(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            challenge_root = Path(tmp_dir)
            (challenge_root / "payloads").mkdir()
            solution_file = challenge_root / "payloads" / "solution.py"
            solution_file.write_text(
                "\n".join(
                    [
                        "class Solution:",
                        "    def main(self):",
                        "        return 'ok'",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            manager_file = ChildContextDummyManagerFile(challenge_root, "data")
            runner = ManagerExplainRunner(manager_file=manager_file)
            result = runner.explain(save=False)

            self.assertEqual(result["solution_file"], challenge_root / "payloads" / "solution.py")
            self.assertEqual(manager_file.parent, challenge_root)
            self.assertIn("Class analyzed: Solution", result["summary_text"])

    def test_explain_tracks_richer_side_effects_and_execution_flow(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            challenge_root = Path(tmp_dir)
            (challenge_root / "payloads").mkdir()
            solution_file = challenge_root / "payloads" / "solution.py"
            solution_file.write_text(
                "\n".join(
                    [
                        "from pathlib import Path",
                        "import base64",
                        "import pyperclip",
                        "import requests",
                        "from pwn import process, remote",
                        "",
                        "class FrameworkBase:",
                        "    def decode_base64(self, value):",
                        "        return base64.b64decode(value)",
                        "",
                        "class Solution(FrameworkBase):",
                        "    def __init__(self):",
                        "        self.target = Path('files/in.bin')",
                        "        self.output = Path('data/out.txt')",
                        "        self.conn = None",
                        "",
                        "    def main(self):",
                        "        self.prepare()",
                        "        self.launch()",
                        "        return self.decode_base64(b'ZmxhZ3t0ZXN0fQ==')",
                        "",
                        "    def prepare(self):",
                        "        with open(self.target, 'rb') as handle:",
                        "            blob = handle.read()",
                        "        with open(self.output, 'w', encoding='utf-8') as handle:",
                        "            handle.write(blob.hex())",
                        "        pyperclip.copy(blob.hex())",
                        "        requests.get('https://example.com', timeout=1)",
                        "",
                        "    def launch(self):",
                        "        self.conn = remote('127.0.0.1', 31337)",
                        "        self.conn.sendline(b'ping')",
                        "        process(['echo', 'done'])",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            runner = ManagerExplainRunner(manager_file=DummyManagerFile(challenge_root))
            analysis = runner.analyze_solution(solution_file)
            call_graph = analysis["call_graph"]

            self.assertEqual(
                analysis["execution_flow"],
                [
                    "__main__",
                    "Solution(...)",
                    "try_main",
                    "main",
                    "decode_base64",
                    "launch",
                    "prepare",
                ],
            )
            self.assertEqual(
                analysis["attribute_flow"]["conn"],
                {"written_in": ["__init__", "launch"], "read_in": ["launch"]},
            )
            self.assertEqual(
                analysis["attribute_flow"]["output"],
                {"written_in": ["__init__"], "read_in": ["prepare"]},
            )
            self.assertEqual(
                analysis["attribute_flow"]["target"],
                {"written_in": ["__init__"], "read_in": ["prepare"]},
            )

            self.assertIn(
                {
                    "method": "decode_base64",
                    "used_from": "main",
                    "defined_in": "FrameworkBase",
                    "file": str(solution_file),
                },
                analysis["inherited_helpers"],
            )

            self.assertEqual(call_graph["prepare"]["side_effects"]["file_reads"], ["self.target"])
            self.assertEqual(call_graph["prepare"]["side_effects"]["file_writes"], ["self.output"])
            self.assertEqual(call_graph["prepare"]["side_effects"]["clipboard"], ["pyperclip.copy"])
            self.assertEqual(call_graph["prepare"]["side_effects"]["network"], ["requests.get"])
            self.assertEqual(call_graph["main"]["side_effects"]["crypto"], ["self.decode_base64"])
            self.assertEqual(
                call_graph["launch"]["side_effects"]["network"],
                ["remote", "self.conn.sendline"],
            )
            self.assertEqual(call_graph["launch"]["side_effects"]["process_spawn"], ["process"])

            self.assertEqual(
                analysis["risk_summary"],
                {
                    "reads_files": True,
                    "writes_files": True,
                    "runs_subprocesses": False,
                    "opens_network_connections": True,
                    "uses_clipboard": True,
                    "uses_crypto_helpers": True,
                    "spawns_processes": True,
                },
            )
            self.assertIn("side effects:", analysis["method_narratives"]["prepare"])
            self.assertIn("file reads", analysis["method_narratives"]["prepare"])
            self.assertIn("file writes", analysis["method_narratives"]["prepare"])
            self.assertIn("clipboard", analysis["method_narratives"]["prepare"])
            self.assertIn("network", analysis["method_narratives"]["prepare"])
            self.assertIn("uses ", analysis["method_narratives"]["launch"])
            self.assertIn("remote", analysis["method_narratives"]["launch"])
            self.assertIn("self.conn.sendline", analysis["method_narratives"]["launch"])
            self.assertIn("process", analysis["method_narratives"]["launch"])
            self.assertIn(
                "side effects: crypto",
                analysis["method_narratives"]["main"],
            )
            self.assertIn("requests.get", analysis["module"]["interesting_calls"])
            self.assertIn("remote", analysis["module"]["interesting_calls"])

    def test_build_cli_summary_formats_paths_and_methods(self):
        runner = ManagerExplainRunner(
            manager_file=DummyManagerFile(Path("/tmp/challenge")),
            output_manager=ManagerOutput(sink=lambda _: None),
        )

        result = {
            "solution_file": Path("/tmp/challenge/payloads/solution.py"),
            "output_dir": Path("/tmp/challenge/docs/explain_data"),
            "summary_path": Path("/tmp/challenge/docs/explain_data/summary.md"),
            "summary_json_path": Path("/tmp/challenge/docs/explain_data/summary.json"),
            "analysis": {"solution": {"methods": {"main": {}, "helper": {}}}},
        }

        summary = runner.build_cli_summary(result, include_methods=True)

        self.assertIn("Solution file", summary)
        self.assertIn("Output directory", summary)
        self.assertIn("Methods", summary)
        self.assertIn("main", summary)
        self.assertIn("helper", summary)


if __name__ == "__main__":
    unittest.main()
