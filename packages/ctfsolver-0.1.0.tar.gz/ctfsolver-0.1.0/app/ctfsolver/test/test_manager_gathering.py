import os
import unittest

from pathlib import Path
from tempfile import TemporaryDirectory

from ctfsolver.find_usage.manager_gathering import ManagerGathering


class DummyManagerFile:
    def __init__(self, solution_file):
        self.solution_file = Path(solution_file)

    def get_solution_file(self, save=True):
        assert save is True
        return self.solution_file


class ManagerGatheringTest(unittest.TestCase):
    def test_gather_corpus_indexes_duplicates_and_framework_usage(self):
        with TemporaryDirectory() as tmp_dir:
            ctf_root = Path(tmp_dir, "ctf")
            first = ctf_root / "Crypto" / "siteA" / "challA" / "payloads"
            second = ctf_root / "Crypto" / "siteB" / "challB" / "payloads"
            first.mkdir(parents=True)
            second.mkdir(parents=True)

            shared_helper = [
                "    def helper(self, value):",
                "        return value[::-1]",
            ]

            (first / "solution.py").write_text(
                "\n".join(
                    [
                        "class Solution:",
                        *shared_helper,
                        "    def main(self):",
                        "        self.helper('abc')",
                        "        self.recv_lines()",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            (second / "solution.py").write_text(
                "\n".join(
                    [
                        "class Solution:",
                        *shared_helper,
                        "    def main(self):",
                        "        self.helper('def')",
                        "        self.decode_base64('QQ==')",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            manager = ManagerGathering(ctf_root=ctf_root)
            corpus = manager.gather_corpus()

            self.assertEqual(corpus["stats"]["solution_count"], 2)
            self.assertEqual(corpus["stats"]["framework_usage"]["recv_lines"], 1)
            self.assertEqual(corpus["stats"]["framework_usage"]["decode_base64"], 1)
            self.assertEqual(corpus["stats"]["method_names"]["helper"], 2)
            self.assertEqual(len(corpus["duplicates"]), 1)
            self.assertEqual(corpus["duplicates"][0]["name"], "helper")
            self.assertEqual(len(corpus["duplicates"][0]["occurrences"]), 2)

    def test_gather_file_matches_previous_challenges(self):
        with TemporaryDirectory() as tmp_dir:
            ctf_root = Path(tmp_dir, "ctf")
            old_challenge = ctf_root / "Web" / "siteA" / "old" / "payloads"
            new_challenge = ctf_root / "Web" / "siteA" / "new" / "payloads"
            old_challenge.mkdir(parents=True)
            new_challenge.mkdir(parents=True)

            helper_body = [
                "    def helper(self):",
                "        return 'same'",
            ]

            (old_challenge / "solution.py").write_text(
                "\n".join(
                    [
                        "class Solution:",
                        *helper_body,
                        "    def main(self):",
                        "        self.helper()",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            current_solution = new_challenge / "solution.py"
            current_solution.write_text(
                "\n".join(
                    [
                        "class Solution:",
                        *helper_body,
                        "    def main(self):",
                        "        self.helper()",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            manager = ManagerGathering(
                manager_file=DummyManagerFile(current_solution), ctf_root=ctf_root
            )
            gathered = manager.gather_file()

            self.assertEqual(gathered["entry"]["challenge"]["challenge"], "new")
            self.assertEqual(len(gathered["matches"]["exact_or_structural"]), 2)
            helper_match = next(
                item for item in gathered["matches"]["exact_or_structural"] if item["method"] == "helper"
            )
            self.assertEqual(helper_match["origin_challenges"][0]["challenge"], "old")

    def test_write_output_creates_docs_gather_data_files(self):
        with TemporaryDirectory() as tmp_dir:
            previous_cwd = os.getcwd()
            os.chdir(tmp_dir)
            try:
                manager = ManagerGathering(ctf_root=Path(tmp_dir, "ctf"))
                output_dir, markdown_path, json_path = manager.write_output(
                    "corpus_summary", ["# Test"], {"ok": True}
                )
            finally:
                os.chdir(previous_cwd)

            self.assertEqual(output_dir, Path(tmp_dir, "docs", "gather_data"))
            self.assertTrue(markdown_path.exists())
            self.assertTrue(json_path.exists())
            self.assertIn("# Test", markdown_path.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
