import importlib
import sys
import tempfile
import unittest

from pathlib import Path
from types import ModuleType
from unittest import mock

from typer.testing import CliRunner


def import_pcap_cli_module():
    fake_manager_files_pcap_module = ModuleType("ctfsolver.managers.manager_files_pcap")

    class FakeManagerFilePcap:
        def __init__(self, *args, **kwargs):
            pass

        def pcap_open(self, file=None, save=False):
            return []

    fake_manager_files_pcap_module.ManagerFilePcap = FakeManagerFilePcap

    with mock.patch.dict(
        sys.modules,
        {"ctfsolver.managers.manager_files_pcap": fake_manager_files_pcap_module},
    ):
        sys.modules.pop("ctfsolver.managers.manager_file", None)
        sys.modules.pop("ctfsolver.forensics.manager_pcap_analyzer", None)
        sys.modules.pop("ctfsolver.cli.subcli.pcap", None)
        return importlib.import_module("ctfsolver.cli.subcli.pcap")


class PcapCliTest(unittest.TestCase):
    def setUp(self):
        self.cli_module = import_pcap_cli_module()
        self.runner = CliRunner()
        handle = tempfile.NamedTemporaryFile(suffix=".pcap", delete=False)
        handle.close()
        self.capture = Path(handle.name)
        self.addCleanup(self.capture.unlink)

    def test_summary_command_uses_output_summary(self):
        with mock.patch.object(
            self.cli_module.pcap_analyzer, "load_capture", return_value=["packet"]
        ):
            with mock.patch.object(
                self.cli_module.pcap_analyzer,
                "build_capture_summary",
                return_value={
                    "packet_count": 1,
                    "protocols": {},
                    "conversations": [],
                    "top_talkers": [],
                    "ports": [],
                },
            ):
                with mock.patch.object(
                    self.cli_module.pcap_analyzer,
                    "build_summary_text",
                    return_value="Capture Summary\n- Packets : 1",
                ):
                    result = self.runner.invoke(
                        self.cli_module.pcap_app,
                        ["summary", "--file", self.capture.as_posix()],
                    )

        self.assertEqual(result.exit_code, 0)
        self.assertIn("PCAP summary complete", result.stdout)
        self.assertIn("Capture Summary", result.stdout)

    def test_extract_command_uses_output_summary(self):
        with mock.patch.object(
            self.cli_module.pcap_analyzer, "load_capture", return_value=["packet"]
        ):
            with mock.patch.object(
                self.cli_module.pcap_analyzer,
                "extract_artifacts",
                return_value={"flags": ["flag{demo}"]},
            ):
                with mock.patch.object(
                    self.cli_module.pcap_analyzer,
                    "build_extraction_text",
                    return_value="Flag Candidates\n- flag{demo}",
                ):
                    result = self.runner.invoke(
                        self.cli_module.pcap_app,
                        ["extract", "--file", self.capture.as_posix()],
                    )

        self.assertEqual(result.exit_code, 0)
        self.assertIn("PCAP artifact extraction complete", result.stdout)
        self.assertIn("flag{demo}", result.stdout)

    def test_graph_command_reports_graph_metadata_without_serving(self):
        with mock.patch.object(
            self.cli_module.pcap_analyzer,
            "graph_capture",
            return_value={"mode": "hosts", "element_count": 4, "title": "PCAP Graph"},
        ) as graph_capture:
            result = self.runner.invoke(
                self.cli_module.pcap_app,
                ["graph", "--file", self.capture.as_posix(), "--no-serve"],
            )

        self.assertEqual(result.exit_code, 0)
        self.assertIn("Graph Summary", result.stdout)
        self.assertTrue(graph_capture.called)

    def test_tshark_command_requires_preset_or_args(self):
        result = self.runner.invoke(
            self.cli_module.pcap_app,
            ["tshark", "--file", self.capture.as_posix()],
        )

        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("Provide either --preset", result.output)


if __name__ == "__main__":
    unittest.main()
