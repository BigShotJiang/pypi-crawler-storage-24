import importlib
import sys
import unittest

from types import ModuleType
from unittest import mock

from ctfsolver.managers.manager_codecs import ManagerCodecs
from ctfsolver.managers.manager_connections import ManagerConnections
from ctfsolver.managers.manager_output import ManagerOutput


def import_manager_files_pcap_with_fake_scapy():
    fake_scapy_module = ModuleType("scapy")
    fake_scapy_all_module = ModuleType("scapy.all")

    with mock.patch.dict(
        sys.modules,
        {
            "scapy": fake_scapy_module,
            "scapy.all": fake_scapy_all_module,
        },
    ):
        sys.modules.pop("ctfsolver.managers.manager_files_pcap", None)
        module = importlib.import_module("ctfsolver.managers.manager_files_pcap")
        return module.ManagerFilePcap


class DummyConn:
    def __init__(self, lines=None, recvuntil_error=False):
        self.lines = list(lines or [])
        self.recvuntil_error = recvuntil_error

    def recvline(self, *args, **kwargs):
        return self.lines.pop(0)

    def recvuntil(self, delim, **kwargs):
        if self.recvuntil_error:
            raise EOFError()
        return b"menu> "


class DummyRawLayer:
    def __init__(self, load):
        self.load = load


class DummyPacket:
    def __init__(self, load):
        self.raw = DummyRawLayer(load)

    def haslayer(self, name):
        return name == "Raw"

    def __getitem__(self, key):
        if key != "Raw":
            raise KeyError(key)
        return self.raw

    def show(self, dump=False):
        if dump:
            return "PACKET SHOW"
        return None

    def summary(self):
        return "PACKET SUMMARY"


class ManagerConnectionsOutputTest(unittest.TestCase):
    def test_recv_lines_display_uses_output_sink(self):
        seen = []
        manager = ManagerConnections.__new__(ManagerConnections)
        manager.conn = DummyConn(lines=[b"hello\n"])
        manager.output = ManagerOutput(sink=seen.append)

        result = ManagerConnections.recv_lines(manager, number=1, display=True, save=True)

        self.assertEqual(result, [b"hello\n"])
        self.assertEqual(seen, ["b'hello\\n'"])

    def test_recv_until_eof_uses_output_sink(self):
        seen = []
        manager = ManagerConnections.__new__(ManagerConnections)
        manager.conn = DummyConn(recvuntil_error=True)
        manager.output = ManagerOutput(sink=seen.append)

        result = ManagerConnections.recv_until(manager, "menu>")

        self.assertEqual(result, b"")
        self.assertTrue(any("Connection closed before the request could be satisfied" in line for line in seen))


class ManagerCodecsOutputTest(unittest.TestCase):
    def test_decode_base64_failure_uses_output_sink(self):
        seen = []
        manager = ManagerCodecs(output_manager=ManagerOutput(sink=seen.append))

        result = manager.decode_base64("not base64 !!!")

        self.assertIsNone(result)
        self.assertTrue(seen)


class ManagerFilePcapOutputTest(unittest.TestCase):
    def test_searching_text_in_packets_display_uses_output_sink(self):
        ManagerFilePcap = import_manager_files_pcap_with_fake_scapy()
        seen = []
        manager = ManagerFilePcap(output_manager=ManagerOutput(sink=seen.append))

        result = manager.searching_text_in_packets(
            "flag",
            packets=[DummyPacket(b"flag{demo}")],
            display=True,
        )

        self.assertEqual(result, "flag{demo}")
        self.assertTrue(any("Found flag in packet 0" in line for line in seen))
        self.assertTrue(any("PACKET SHOW" in line for line in seen))
        self.assertTrue(any("PACKET SUMMARY" in line for line in seen))


if __name__ == "__main__":
    unittest.main()
