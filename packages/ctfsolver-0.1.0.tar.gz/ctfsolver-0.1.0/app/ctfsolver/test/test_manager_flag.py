import unittest
import importlib
import sys
from unittest import mock
from types import ModuleType

from ctfsolver.managers.manager_flag import ManagerFlag
from ctfsolver.managers.manager_output import ManagerOutput


class ManagerFlagTest(unittest.TestCase):
    def test_extract_flags_matches_multiple_prefixes_and_deduplicates(self):
        manager = ManagerFlag(output_manager=ManagerOutput(sink=lambda _: None))

        flags = manager.extract_flags("flag{one} noise picoCTF{two} flag{one}")

        self.assertEqual(flags, ["flag{one}", "picoCTF{two}"])

    def test_extract_first_flag_returns_first_candidate(self):
        manager = ManagerFlag(output_manager=ManagerOutput(sink=lambda _: None))

        self.assertEqual(manager.extract_first_flag("noise HTB{first} tail"), "HTB{first}")

    def test_extract_flags_respects_prefix_override(self):
        manager = ManagerFlag(output_manager=ManagerOutput(sink=lambda _: None))

        self.assertEqual(
            manager.extract_flags("flag{one} custom{two}", prefixes=["custom"]),
            ["custom{two}"],
        )

    def test_extract_flags_supports_partial_matches(self):
        manager = ManagerFlag(output_manager=ManagerOutput(sink=lambda _: None))

        flags = manager.extract_flags("prefix picoCTF{partial", allow_partial=True)

        self.assertEqual(flags, ["picoCTF{partial"])

    def test_present_flag_uses_stored_flag_and_emits_success(self):
        seen = []
        manager = ManagerFlag(output_manager=ManagerOutput(sink=seen.append))
        manager.flag = "flag{demo}"

        presented = manager.present_flag(copy=False)

        self.assertEqual(presented, "flag{demo}")
        self.assertTrue(any("Flag: flag{demo}" in line for line in seen))

    def test_present_flags_emits_summary_for_multiple_candidates(self):
        seen = []
        manager = ManagerFlag(output_manager=ManagerOutput(sink=seen.append))

        presented = manager.present_flags(["flag{one}", "flag{two}"], copy_first=False)

        self.assertEqual(presented, ["flag{one}", "flag{two}"])
        self.assertTrue(any("Multiple flags found." in line for line in seen))
        self.assertTrue(any("Flags" in line for line in seen))

    def test_present_flag_warns_when_missing(self):
        seen = []
        manager = ManagerFlag(output_manager=ManagerOutput(sink=seen.append))

        result = manager.present_flag(copy=False)

        self.assertIsNone(result)
        self.assertTrue(any("No flag available to present." in line for line in seen))

    def test_copy_flag_handles_missing_clipboard_gracefully(self):
        manager = ManagerFlag(output_manager=ManagerOutput(sink=lambda _: None))

        with mock.patch("ctfsolver.managers.manager_flag.pyperclip", None):
            self.assertFalse(manager.copy_flag("flag{demo}"))

    def test_copy_flag_handles_clipboard_exceptions(self):
        seen = []
        manager = ManagerFlag(output_manager=ManagerOutput(verbosity=2, sink=seen.append))

        fake_pyperclip = mock.Mock()
        fake_pyperclip.copy.side_effect = RuntimeError("clipboard down")

        with mock.patch("ctfsolver.managers.manager_flag.pyperclip", fake_pyperclip):
            result = manager.copy_flag("flag{demo}")

        self.assertFalse(result)
        self.assertTrue(any("Clipboard copy failed" in line for line in seen))


class CTFSolverFlagIntegrationTest(unittest.TestCase):
    def import_runtime_solver_without_optional_dependencies(self):
        fake_manager_file_module = ModuleType("ctfsolver.managers.manager_file")
        fake_manager_connections_module = ModuleType(
            "ctfsolver.managers.manager_connections"
        )
        fake_manager_crypto_module = ModuleType("ctfsolver.managers.manager_crypto")
        fake_manager_error_module = ModuleType("ctfsolver.error.manager_error")

        with mock.patch.dict(
            sys.modules,
            {
                "ctfsolver.managers.manager_file": fake_manager_file_module,
                "ctfsolver.managers.manager_connections": fake_manager_connections_module,
                "ctfsolver.managers.manager_crypto": fake_manager_crypto_module,
                "ctfsolver.error.manager_error": fake_manager_error_module,
            },
        ):
            class FakeManagerFile:
                def __init__(self, *args, **kwargs):
                    pass

            class FakeManagerConnections:
                def __init__(self, *args, **kwargs):
                    pass

            class FakeManagerCrypto:
                def __init__(self, *args, **kwargs):
                    pass

            class FakeManagerError:
                def __init__(self, *args, **kwargs):
                    pass

                def try_function(self, function):
                    return function()

            fake_manager_file_module.ManagerFile = FakeManagerFile
            fake_manager_connections_module.ManagerConnections = FakeManagerConnections
            fake_manager_crypto_module.ManagerCrypto = FakeManagerCrypto
            fake_manager_error_module.ManagerError = FakeManagerError

            sys.modules.pop("ctfsolver", None)
            sys.modules.pop("ctfsolver.src", None)
            sys.modules.pop("ctfsolver.src.ctfsolver", None)
            runtime_module = importlib.import_module("ctfsolver.src.ctfsolver")
            return runtime_module.CTFSolver

    def test_ctfsolver_exposes_flag_helpers(self):
        solver_class = self.import_runtime_solver_without_optional_dependencies()
        solver = solver_class(output_manager=ManagerOutput(sink=lambda _: None))

        self.assertTrue(hasattr(solver, "extract_flags"))
        self.assertTrue(hasattr(solver, "present_flag"))

    def test_ctfsolver_can_store_and_present_flag(self):
        solver_class = self.import_runtime_solver_without_optional_dependencies()
        seen = []
        solver = solver_class(output_manager=ManagerOutput(sink=seen.append))

        solver.set_flag("flag{runtime}")
        result = solver.present_flag(copy=False)

        self.assertEqual(result, "flag{runtime}")
        self.assertTrue(any("Flag: flag{runtime}" in line for line in seen))


if __name__ == "__main__":
    unittest.main()
