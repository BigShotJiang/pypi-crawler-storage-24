import unittest

from pathlib import Path
from tempfile import TemporaryDirectory

from ctfsolver.managers.manager_ctf_creator import ManagerCTFCreator
from ctfsolver.managers.manager_output import ManagerOutput


class DummyManagerFile:
    pass


class DummyWorkspaceManager:
    def __init__(self, ctf_root=None):
        self.calls = []
        self.ctf_root = Path("/tmp") if ctf_root is None else Path(ctf_root)

    def create_ctf_structure(self, category, site, name, **kwargs):
        self.calls.append((category, site, name, kwargs))

    def get_ctf_base_path(self, category, site, name):
        return self.ctf_root / category / site / name


class ManagerCTFCreatorTest(unittest.TestCase):
    def test_create_with_doc_creation_check_creates_document(self):
        with TemporaryDirectory() as tmp_dir:
            documentation_root = Path(tmp_dir, "docs")
            manager_file = DummyManagerFile()
            workspace_manager = DummyWorkspaceManager(ctf_root=Path(tmp_dir, "ctf"))
            creator = ManagerCTFCreator(
                manager_file=manager_file,
                workspace_manager=workspace_manager,
                ctf_root=Path(tmp_dir, "ctf"),
                documentation_root=documentation_root,
            )

            result = creator.create(
                category="crypto",
                site="picoctf",
                name='Warm Up! "2025"',
                doc_creation_check=True,
                download=True,
                verbose=True,
            )

            self.assertEqual(
                workspace_manager.calls,
                [
                    (
                        "crypto",
                        "picoctf",
                        "Warm_Up_2025",
                        {"download": True, "verbose": True},
                    )
                ],
            )
            self.assertEqual(
                result["path"], Path(tmp_dir, "ctf", "crypto", "picoctf", "Warm_Up_2025")
            )
            self.assertEqual(
                result["document_path"],
                Path(tmp_dir, "docs", "crypto", "picoctf", "Warm Up 2025.md"),
            )
            self.assertEqual(result["folder_name"], "Warm_Up_2025")
            self.assertEqual(result["document_name"], "Warm Up 2025")
            self.assertTrue(result["doc_creation_check"])
            self.assertTrue(result["download"])
            self.assertIn(
                "# Warm Up! \"2025\"",
                result["document_path"].read_text(encoding="utf-8"),
            )

    def test_create_without_doc_creation_check_skips_document_creation(self):
        with TemporaryDirectory() as tmp_dir:
            documentation_root = Path(tmp_dir, "docs")
            manager_file = DummyManagerFile()
            workspace_manager = DummyWorkspaceManager(ctf_root=Path(tmp_dir, "ctf"))
            creator = ManagerCTFCreator(
                manager_file=manager_file,
                workspace_manager=workspace_manager,
                ctf_root=Path(tmp_dir, "ctf"),
                documentation_root=documentation_root,
            )

            result = creator.create(
                category="crypto",
                site="picoctf",
                name="Warm Up 2025",
                doc_creation_check=False,
                download=False,
                verbose=False,
            )

            self.assertEqual(
                workspace_manager.calls,
                [
                    (
                        "crypto",
                        "picoctf",
                        "Warm_Up_2025",
                        {"download": False, "verbose": False},
                    )
                ],
            )
            self.assertIsNone(result["document_path"])
            self.assertFalse(documentation_root.exists())

    def test_get_challenge_path_uses_manager_file_when_available(self):
        manager_file = DummyManagerFile()
        workspace_manager = DummyWorkspaceManager()
        creator = ManagerCTFCreator(
            manager_file=manager_file,
            workspace_manager=workspace_manager,
            ctf_root=Path("/tmp"),
            documentation_root=Path("/tmp/docs"),
        )

        self.assertEqual(
            creator.get_challenge_path("web", "ctftime", "challenge"),
            Path("/tmp/web/ctftime/challenge"),
        )

    def test_normalize_folder_name_sanitizes_for_linux_folders(self):
        creator = ManagerCTFCreator(
            manager_file=DummyManagerFile(),
            workspace_manager=DummyWorkspaceManager(),
            ctf_root=Path("/tmp"),
            documentation_root=Path("/tmp/docs"),
        )

        self.assertEqual(
            creator.normalize_folder_name('A strange / chall: "name"?'),
            "A_strange_chall_name",
        )

    def test_normalize_document_name_keeps_spaces_but_removes_weird_symbols(self):
        creator = ManagerCTFCreator(
            manager_file=DummyManagerFile(),
            workspace_manager=DummyWorkspaceManager(),
            ctf_root=Path("/tmp"),
            documentation_root=Path("/tmp/docs"),
        )

        self.assertEqual(
            creator.normalize_document_name('A strange / chall: "name"?'),
            "A strange chall name",
        )

    def test_build_summary_text_formats_creation_result(self):
        creator = ManagerCTFCreator(
            manager_file=DummyManagerFile(),
            workspace_manager=DummyWorkspaceManager(),
            ctf_root=Path("/tmp"),
            documentation_root=Path("/tmp/docs"),
            output_manager=ManagerOutput(),
        )

        summary = creator.build_summary_text(
            {
                "category": "crypto",
                "site": "picoctf",
                "name": 'Warm Up! "2025"',
                "folder_name": "Warm_Up_2025",
                "document_name": "Warm Up 2025",
                "path": Path("/tmp/ctf/crypto/picoctf/Warm_Up_2025"),
                "document_path": None,
                "download": True,
                "doc_creation_check": False,
            }
        )

        self.assertIn("- Category", summary)
        self.assertIn("crypto", summary)
        self.assertIn("Warm_Up_2025", summary)
        self.assertIn("Not created", summary)


if __name__ == "__main__":
    unittest.main()
