import importlib
import json
import os
import sys
import unittest

from pathlib import Path
from tempfile import TemporaryDirectory
from types import ModuleType
from unittest import mock

from ctfsolver.config.global_config import GlobalConfig


def import_chooser_components_with_fake_pcap():
    fake_manager_files_pcap_module = ModuleType("ctfsolver.managers.manager_files_pcap")

    class FakeManagerFilePcap:
        def __init__(self, *args, **kwargs):
            pass

    fake_manager_files_pcap_module.ManagerFilePcap = FakeManagerFilePcap

    with mock.patch.dict(
        sys.modules,
        {"ctfsolver.managers.manager_files_pcap": fake_manager_files_pcap_module},
    ):
        sys.modules.pop("ctfsolver.managers.manager_file", None)
        sys.modules.pop("ctfsolver.find_usage.manager_gathering", None)
        sys.modules.pop("ctfsolver.find_usage.manager_internal_chooser", None)
        sys.modules.pop("ctfsolver.cli.subcli.chooser", None)
        chooser_module = importlib.import_module("ctfsolver.find_usage.manager_internal_chooser")
        chooser_cli_module = importlib.import_module("ctfsolver.cli.subcli.chooser")
        typer_testing = importlib.import_module("typer.testing")
    return chooser_module.ManagerInternalChooser, chooser_cli_module, typer_testing.CliRunner


class ManagerInternalChooserTest(unittest.TestCase):
    def _write_solution(self, root, category, site, challenge, lines):
        folder = root / category / site / challenge / "payloads"
        folder.mkdir(parents=True)
        (folder / "solution.py").write_text("\n".join(lines) + "\n", encoding="utf-8")
        return folder / "solution.py"

    def test_build_index_groups_framework_internal_and_external_recommendations(self):
        ManagerInternalChooser, _, _ = import_chooser_components_with_fake_pcap()
        with TemporaryDirectory() as tmp_dir:
            ctf_root = Path(tmp_dir, "ctf")
            self._write_solution(
                ctf_root,
                "Crypto",
                "siteA",
                "alpha",
                [
                    "class Solution:",
                    "    def helper(self, value):",
                    "        return value[::-1]",
                    "    def main(self):",
                    "        self.helper('abc')",
                    "        self.decode_base64('QQ==')",
                    "        xor_tool()",
                ],
            )
            self._write_solution(
                ctf_root,
                "Crypto",
                "siteB",
                "beta",
                [
                    "class Solution:",
                    "    def helper(self, value):",
                    "        return value[::-1]",
                    "    def main(self):",
                    "        self.helper('def')",
                    "        self.decode_base64('Qg==')",
                    "        xor_tool()",
                ],
            )

            chooser = ManagerInternalChooser(ctf_root=ctf_root)
            index = chooser.build_index(minimum_usage_count=2)
            recommendations = index["category_function_map"]["Cryptography"]

            decode_base64 = next(item for item in recommendations if item["name"] == "decode_base64")
            helper = next(item for item in recommendations if item["name"] == "helper")
            xor_tool = next(item for item in recommendations if item["name"] == "xor_tool")

            self.assertEqual(decode_base64["type"], "framework_method")
            self.assertEqual(decode_base64["usage_count"], 2)
            self.assertEqual(helper["type"], "internal_helper_pattern")
            self.assertEqual(helper["usage_count"], 2)
            self.assertEqual(xor_tool["type"], "external_workflow")
            self.assertEqual(xor_tool["usage_count"], 2)

    def test_update_index_persists_chooser_data_in_sidecar_file(self):
        ManagerInternalChooser, _, _ = import_chooser_components_with_fake_pcap()
        with TemporaryDirectory() as tmp_dir:
            ctf_root = Path(tmp_dir, "ctf")
            self._write_solution(
                ctf_root,
                "Web",
                "siteA",
                "gamma",
                [
                    "class Solution:",
                    "    def main(self):",
                    "        requests.get('https://example.com')",
                    "        self.recv_lines()",
                ],
            )

            with mock.patch("ctfsolver.config.global_config.Path.home", return_value=Path(tmp_dir)):
                config = GlobalConfig()
                config.initializing()
                chooser = ManagerInternalChooser(ctf_root=ctf_root, config=config)
                chooser.update_index(minimum_usage_count=1)

                chooser_data = config.get_chooser_data()
                raw_config = json.loads(
                    config.global_config_file_path.read_text(encoding="utf-8")
                )
                chooser_map_file = config.global_config_file_path.with_name(
                    raw_config["chooser"]["function_map_file"]
                )
                chooser_map = json.loads(chooser_map_file.read_text(encoding="utf-8"))

                self.assertEqual(chooser_data["minimum_usage_count"], 1)
                self.assertEqual(chooser_data["source_root"], ctf_root.as_posix())
                self.assertIn("Web", chooser_data["category_function_map"])
                self.assertNotIn("category_function_map", raw_config["chooser"])
                self.assertEqual(
                    raw_config["chooser"]["function_map_file"],
                    "chooser_function_map.json",
                )
                self.assertIn("Web", chooser_map)

    def test_get_chooser_data_migrates_legacy_inline_map_to_sidecar_file(self):
        with TemporaryDirectory() as tmp_dir:
            with mock.patch("ctfsolver.config.global_config.Path.home", return_value=Path(tmp_dir)):
                config = GlobalConfig()
                config.initializing()
                legacy_content = json.loads(
                    config.global_config_file_path.read_text(encoding="utf-8")
                )
                legacy_content["chooser"] = {
                    "category_function_map": {"Web": [{"name": "requests.get"}]},
                    "last_updated": "2026-03-12T00:00:00+00:00",
                    "source_root": "/tmp/ctf",
                    "minimum_usage_count": 1,
                }
                config.global_config_file_path.write_text(
                    json.dumps(legacy_content, indent=4) + "\n",
                    encoding="utf-8",
                )
                config.get_content()

                chooser_data = config.get_chooser_data()
                migrated_content = json.loads(
                    config.global_config_file_path.read_text(encoding="utf-8")
                )
                chooser_map_file = config.global_config_file_path.with_name(
                    migrated_content["chooser"]["function_map_file"]
                )
                chooser_map = json.loads(chooser_map_file.read_text(encoding="utf-8"))

                self.assertIn("Web", chooser_data["category_function_map"])
                self.assertNotIn("category_function_map", migrated_content["chooser"])
                self.assertEqual(chooser_map["Web"][0]["name"], "requests.get")

    def test_recommend_infers_category_and_applies_file_hints(self):
        ManagerInternalChooser, _, _ = import_chooser_components_with_fake_pcap()
        with TemporaryDirectory() as tmp_dir:
            ctf_root = Path(tmp_dir, "ctf")
            challenge_dir = ctf_root / "Forensics" / "siteA" / "memory-one"
            self._write_solution(
                ctf_root,
                "Forensics",
                "siteA",
                "memory-one",
                [
                    "class Solution:",
                    "    def helper_memory_dump(self):",
                    "        return 'ok'",
                    "    def main(self):",
                    "        self.helper_memory_dump()",
                    "        volatility_scan()",
                ],
            )
            self._write_solution(
                ctf_root,
                "Forensics",
                "siteB",
                "memory-two",
                [
                    "class Solution:",
                    "    def helper_memory_dump(self):",
                    "        return 'ok'",
                    "    def main(self):",
                    "        self.helper_memory_dump()",
                    "        volatility_scan()",
                ],
            )

            files_dir = challenge_dir / "files"
            files_dir.mkdir(parents=True)
            (files_dir / "memdump.raw").write_text("raw", encoding="utf-8")

            with mock.patch("ctfsolver.config.global_config.Path.home", return_value=Path(tmp_dir)):
                config = GlobalConfig()
                config.initializing()
                chooser = ManagerInternalChooser(ctf_root=ctf_root, config=config)
                chooser.update_index(minimum_usage_count=2)

                previous_cwd = os.getcwd()
                os.chdir(challenge_dir)
                try:
                    result = chooser.recommend(inspect_files=True, limit=5)
                finally:
                    os.chdir(previous_cwd)

            self.assertEqual(result["category"], "Forensics")
            self.assertIn("memory_dump", result["file_hints"])
            self.assertEqual(result["recommendations"][0]["name"], "volatility_scan")
            self.assertIn("memory_dump", result["recommendations"][0]["matched_file_families"])


class ChooserCliOutputTest(unittest.TestCase):
    def test_chooser_update_prints_structured_summary(self):
        _, chooser_cli_module, CliRunner = import_chooser_components_with_fake_pcap()
        runner = CliRunner()

        with mock.patch.object(chooser_cli_module.chooser_manager, "update_index") as update_index:
            with mock.patch.object(chooser_cli_module.chooser_manager, "summarize_index") as summarize_index:
                update_index.return_value = {"category_function_map": {"Web": []}}
                summarize_index.return_value = (
                    "- Source root            : /tmp/ctf\n"
                    "- Categories indexed     : 1"
                )

                result = runner.invoke(chooser_cli_module.chooser_app, ["update"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("[ok] Chooser index updated.", result.stdout)
        self.assertIn("Categories indexed", result.stdout)

    def test_chooser_show_prints_recommendations(self):
        _, chooser_cli_module, CliRunner = import_chooser_components_with_fake_pcap()
        runner = CliRunner()

        with mock.patch.object(chooser_cli_module.chooser_manager, "recommend") as recommend:
            with mock.patch.object(
                chooser_cli_module.chooser_manager, "build_recommendation_lines"
            ) as build_recommendation_lines:
                recommend.return_value = {"category": "Web", "recommendations": []}
                build_recommendation_lines.return_value = [
                    "# Chooser Recommendations",
                    "",
                    "- Category: Web",
                    "",
                    "## Recommendations",
                    "- requests.get [external_workflow] usage=3 score=3",
                ]

                result = runner.invoke(chooser_cli_module.chooser_app, ["show", "--category", "Web"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("# Chooser Recommendations", result.stdout)
        self.assertIn("requests.get", result.stdout)


if __name__ == "__main__":
    unittest.main()
