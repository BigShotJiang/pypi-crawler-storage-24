import tempfile
import unittest

from pathlib import Path

from ctfsolver.forensics.manager_volatility import ManagerVolatilityRunner
from ctfsolver.managers.manager_output import ManagerOutput


class DummyManagerFile:
    def __init__(self, challenge_root):
        self.parent = Path(challenge_root)
        self.folders_name_list = ["data", "files", "payloads", "docs"]
        self.current_dir_calls = 0

    def get_current_dir(self):
        self.current_dir_calls += 1

    def setup_named_folders(self):
        self.folder_data = self.parent / "data"
        self.folder_files = self.parent / "files"
        self.folder_payloads = self.parent / "payloads"


class ManagerVolatilityRunnerTest(unittest.TestCase):
    def test_prepare_context_sets_challenge_file_from_files_dir(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            challenge_root = Path(tmp_dir)
            (challenge_root / "files").mkdir()
            (challenge_root / "data").mkdir()
            (challenge_root / "payloads").mkdir()
            memory_file = challenge_root / "files" / "memory.raw"
            memory_file.write_text("mem", encoding="utf-8")
            manager_file = DummyManagerFile(challenge_root)
            runner = ManagerVolatilityRunner(
                manager_file=manager_file,
                executable="/usr/bin/vol",
            )

            selected = runner.prepare_context()

            self.assertEqual(selected, memory_file)
            self.assertEqual(runner.manager_file.challenge_file, memory_file)

    def test_create_output_dir_creates_incrementing_vol_data_folders(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            challenge_root = Path(tmp_dir)
            (challenge_root / "files").mkdir()
            (challenge_root / "data").mkdir()
            (challenge_root / "payloads").mkdir()
            manager_file = DummyManagerFile(challenge_root)
            runner = ManagerVolatilityRunner(
                manager_file=manager_file,
                executable="/usr/bin/vol",
            )
            runner.manager_file.setup_named_folders()

            first = runner.create_output_dir()
            second = runner.create_output_dir()

            self.assertEqual(first.name, "vol_data")
            self.assertEqual(second.name, "vol_data_01")

    def test_triage_writes_plugin_outputs_and_summary(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            challenge_root = Path(tmp_dir)
            (challenge_root / "files").mkdir()
            (challenge_root / "data").mkdir()
            (challenge_root / "payloads").mkdir()
            memory_file = challenge_root / "files" / "memory.raw"
            memory_file.write_text("mem", encoding="utf-8")

            calls = []

            def fake_runner(cmd, stdout, stderr, text, check):
                calls.append(cmd)

                class Result:
                    returncode = 0
                    stdout = "plugin output\n"
                    stderr = ""

                return Result()

            manager_file = DummyManagerFile(challenge_root)
            runner = ManagerVolatilityRunner(
                manager_file=manager_file,
                executable="/usr/bin/vol",
                process_runner=fake_runner,
            )

            result = runner.triage()

            self.assertEqual(result["challenge_file"], memory_file)
            self.assertEqual(result["operating_system"], "windows")
            self.assertEqual(
                calls,
                [
                    ["/usr/bin/vol", "-f", str(memory_file), "-s", str(result["output_dir"] / "symbols"), "windows.info.Info"],
                    ["/usr/bin/vol", "-f", str(memory_file), "-s", str(result["output_dir"] / "symbols"), "windows.pslist.PsList"],
                    ["/usr/bin/vol", "-f", str(memory_file), "-s", str(result["output_dir"] / "symbols"), "windows.netscan.NetScan"],
                    ["/usr/bin/vol", "-f", str(memory_file), "-s", str(result["output_dir"] / "symbols"), "windows.cmdline.CmdLine"],
                    ["/usr/bin/vol", "-f", str(memory_file), "-s", str(result["output_dir"] / "symbols"), "windows.filescan.FileScan"],
                ],
            )
            self.assertTrue((result["output_dir"] / "windows_info_Info.txt").exists())
            self.assertTrue((result["output_dir"] / "windows_pslist_PsList.txt").exists())
            self.assertIn(
                "windows.info.Info",
                result["summary_path"].read_text(encoding="utf-8"),
            )
            self.assertTrue((result["output_dir"] / "symbols").exists())

    def test_detect_operating_system_prefers_linux_when_windows_probe_fails(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            challenge_root = Path(tmp_dir)
            (challenge_root / "files").mkdir()
            (challenge_root / "data").mkdir()
            (challenge_root / "payloads").mkdir()
            memory_file = challenge_root / "files" / "memory.raw"
            memory_file.write_text("mem", encoding="utf-8")

            def fake_runner(cmd, stdout, stderr, text, check):
                plugin = cmd[-1]

                class Result:
                    stderr = ""

                if plugin == "windows.info.Info":
                    Result.returncode = 1
                    Result.stdout = ""
                else:
                    Result.returncode = 0
                    Result.stdout = "Linux version data\n"
                return Result()

            manager_file = DummyManagerFile(challenge_root)
            runner = ManagerVolatilityRunner(
                manager_file=manager_file,
                executable="/usr/bin/vol",
                process_runner=fake_runner,
            )

            runner.prepare_context()
            output_dir = runner.create_output_dir()
            operating_system, detection_result = runner.detect_operating_system(output_dir)

            self.assertEqual(operating_system, "linux")
            self.assertEqual(detection_result["plugin"], "linux.banner.Banner")

    def test_run_executes_only_requested_plugins(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            challenge_root = Path(tmp_dir)
            (challenge_root / "files").mkdir()
            (challenge_root / "data").mkdir()
            (challenge_root / "payloads").mkdir()
            memory_file = challenge_root / "files" / "memory.raw"
            memory_file.write_text("mem", encoding="utf-8")
            calls = []

            def fake_runner(cmd, stdout, stderr, text, check):
                calls.append(cmd)

                class Result:
                    returncode = 0
                    stdout = "custom output\n"
                    stderr = ""

                return Result()

            manager_file = DummyManagerFile(challenge_root)
            runner = ManagerVolatilityRunner(
                manager_file=manager_file,
                executable="/usr/bin/vol",
                process_runner=fake_runner,
            )

            result = runner.run(plugins=["windows.pslist", "windows.cmdline"])

            self.assertEqual(
                calls,
                [
                    ["/usr/bin/vol", "-f", str(memory_file), "-s", str(result["output_dir"] / "symbols"), "windows.pslist"],
                    ["/usr/bin/vol", "-f", str(memory_file), "-s", str(result["output_dir"] / "symbols"), "windows.cmdline"],
                ],
            )
            self.assertEqual(len(result["results"]), 2)

    def test_autosolve_writes_findings_summary_and_json(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            challenge_root = Path(tmp_dir)
            (challenge_root / "files").mkdir()
            (challenge_root / "data").mkdir()
            (challenge_root / "payloads").mkdir()
            memory_file = challenge_root / "files" / "memory.raw"
            memory_file.write_text("mem", encoding="utf-8")

            outputs = {
                "windows.info.Info": "Windows 10 profile\n",
                "windows.pslist.PsList": "4 System\n1337 powershell.exe\n",
                "windows.netscan.NetScan": "TCP 10.0.0.5:4444 10.0.0.1:80 ESTABLISHED\n",
                "windows.cmdline.CmdLine": "powershell.exe -enc ZmxhZ3t0ZXN0fQ==\n",
                "windows.filescan.FileScan": r"C:\Users\User\Desktop\flag.txt" "\n",
            }

            def fake_runner(cmd, stdout, stderr, text, check):
                plugin = cmd[-1]

                class Result:
                    returncode = 0
                    stdout = outputs.get(plugin, "")
                    stderr = ""

                return Result()

            manager_file = DummyManagerFile(challenge_root)
            runner = ManagerVolatilityRunner(
                manager_file=manager_file,
                executable="/usr/bin/vol",
                process_runner=fake_runner,
            )

            result = runner.autosolve()

            self.assertIn("powershell.exe", "\n".join(result["findings"]["suspicious_processes"]))
            self.assertIn("ESTABLISHED", "\n".join(result["findings"]["network_indicators"]))
            self.assertIn("flag.txt", "\n".join(result["findings"]["file_paths"]))
            self.assertTrue(result["summary_path"].exists())
            self.assertTrue(result["summary_json_path"].exists())
            self.assertIn(
                "Suspicious Processes",
                result["summary_path"].read_text(encoding="utf-8"),
            )

    def test_build_cli_summary_formats_counts_and_plugin_details(self):
        runner = ManagerVolatilityRunner(
            manager_file=DummyManagerFile(Path("/tmp/challenge")),
            executable="/usr/bin/vol",
            output_manager=ManagerOutput(sink=lambda _: None),
        )

        result = {
            "challenge_file": Path("/tmp/challenge/files/memory.raw"),
            "output_dir": Path("/tmp/challenge/data/vol_data"),
            "operating_system": "windows",
            "summary_path": Path("/tmp/challenge/data/vol_data/summary.md"),
            "summary_json_path": Path("/tmp/challenge/data/vol_data/summary.json"),
            "results": [
                {
                    "plugin": "windows.info.Info",
                    "returncode": 0,
                    "output_file": Path("/tmp/challenge/data/vol_data/windows_info_Info.txt"),
                }
            ],
            "findings": {"flag_candidates": ["flag{test}"], "network_indicators": []},
        }

        summary = runner.build_cli_summary(result, mode="autosolve", include_details=True)

        self.assertIn("Memory image", summary)
        self.assertIn("Detected OS", summary)
        self.assertIn("Plugins", summary)
        self.assertIn("windows.info.Info", summary)
        self.assertIn("Finding Counts", summary)


if __name__ == "__main__":
    unittest.main()
