import unittest

from pathlib import Path
from tempfile import TemporaryDirectory

from ctfsolver.find_usage.manager_usage_scan import ManagerUsageScan


class ManagerUsageScanTest(unittest.TestCase):
    def test_scan_counts_framework_and_internal_solution_usage(self):
        with TemporaryDirectory() as tmp_dir:
            ctf_root = Path(tmp_dir, "ctf")
            challenge_a = ctf_root / "Crypto" / "siteA" / "challA" / "payloads"
            challenge_b = ctf_root / "Web" / "siteB" / "challB" / "payloads"
            challenge_a.mkdir(parents=True)
            challenge_b.mkdir(parents=True)

            (challenge_a / "solution.py").write_text(
                "\n".join(
                    [
                        "class Solution:",
                        "    def helper(self):",
                        "        return 7",
                        "    def main(self):",
                        "        self.helper()",
                        "        self.recv_lines()",
                        "        print('ok')",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            (challenge_b / "solution.py").write_text(
                "\n".join(
                    [
                        "class Solution:",
                        "    def main(self):",
                        "        self.decode_base64('QQ==')",
                        "        open('flag.txt')",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            scanner = ManagerUsageScan(ctf_root=ctf_root)
            analysis = scanner.scan()

            self.assertEqual(analysis["solution_file_count"], 2)
            self.assertEqual(analysis["solution_class_count"], 2)
            self.assertEqual(analysis["solution_method_defs"]["main"], 2)
            self.assertEqual(analysis["solution_method_defs"]["helper"], 1)
            self.assertEqual(analysis["internal_self_calls"]["helper"], 1)
            self.assertEqual(analysis["framework_self_calls"]["recv_lines"], 1)
            self.assertEqual(analysis["framework_self_calls"]["decode_base64"], 1)
            self.assertEqual(analysis["external_calls"]["print"], 1)
            self.assertEqual(analysis["external_calls"]["open"], 1)
            self.assertEqual(
                analysis["files_using_framework_method"]["recv_lines"],
                [(challenge_a / "solution.py").as_posix()],
            )

    def test_build_summary_lines_formats_key_sections(self):
        with TemporaryDirectory() as tmp_dir:
            ctf_root = Path(tmp_dir, "ctf")
            challenge = ctf_root / "Misc" / "site" / "chall" / "payloads"
            challenge.mkdir(parents=True)
            (challenge / "solution.py").write_text(
                "\n".join(
                    [
                        "class Solution:",
                        "    def main(self):",
                        "        self.recv_lines()",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            scanner = ManagerUsageScan(ctf_root=ctf_root)
            lines = scanner.build_summary_lines(scanner.scan(), limit=5)
            summary = "\n".join(lines)

            self.assertIn("solution.py files found: 1", summary)
            self.assertIn("Top framework self calls:", summary)
            self.assertIn("self.recv_lines: 1", summary)
            self.assertIn("Sample files using top framework methods:", summary)


if __name__ == "__main__":
    unittest.main()
