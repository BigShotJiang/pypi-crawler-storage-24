import unittest

from pathlib import Path

from ctfsolver.forensics.manager_pcap_analyzer import ManagerPcapAnalyzer
from ctfsolver.managers.manager_output import ManagerOutput


class DummyLayer:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)


class DummyPacket:
    def __init__(
        self,
        src=None,
        dst=None,
        protocol="TCP",
        raw=None,
        time=None,
        sport=None,
        dport=None,
        dns_query=None,
        dns_answer=None,
        include_http=False,
    ):
        self.time = time
        self.protocol = protocol
        self.layers = {}
        if src is not None or dst is not None:
            self.layers["IP"] = DummyLayer(src=src, dst=dst)
        if sport is not None or dport is not None:
            layer_name = "UDP" if protocol == "UDP" else "TCP"
            self.layers[layer_name] = DummyLayer(sport=sport, dport=dport)
        if raw is not None:
            self.layers["Raw"] = DummyLayer(load=raw)
        if dns_query is not None or dns_answer is not None:
            self.layers["DNS"] = DummyLayer(qname=dns_query, rrname=dns_answer)
        if include_http:
            self.layers["HTTP"] = DummyLayer()

    def haslayer(self, name):
        return name in self.layers

    def __getitem__(self, key):
        return self.layers[key]

    def sprintf(self, fmt):
        if fmt == "%IP.proto%":
            return self.protocol
        raise ValueError(fmt)


class DummyManagerFile:
    def __init__(self, packets=None):
        self._packets = list(packets or [])
        self.last_run_cmd = None

    def pcap_open(self, file=None, save=False):
        return list(self._packets)

    def tool_exists(self, name):
        return name == "tshark"

    def run_cmd(self, argv, **kwargs):
        self.last_run_cmd = argv
        return type(
            "CompletedProcess",
            (),
            {"stdout": "line1\nline2\n", "stderr": "", "returncode": 0},
        )()


class MissingToolManagerFile(DummyManagerFile):
    def tool_exists(self, name):
        return False


class DummyDashManager:
    def __init__(self):
        self.title = "Graph"
        self.elements = []
        self.ran = False

    def pcap_to_element_converter(self, packets, save=False):
        return [{"data": {"id": "10.0.0.1", "label": "10.0.0.1"}}]

    def pcap_to_element_converter_timestamp(self, packets, save=False):
        return [{"data": {"id": "1.0", "label": "1.0"}}]

    def run_dash(self):
        self.ran = True


class ManagerPcapAnalyzerTest(unittest.TestCase):
    def setUp(self):
        self.packets = [
            DummyPacket(
                src="10.0.0.1",
                dst="10.0.0.2",
                protocol="TCP",
                raw=(
                    b"GET /login HTTP/1.1\r\n"
                    b"Host: example.test\r\n"
                    b"Authorization: Basic YWRtaW46czNjcmV0\r\n"
                    b"Cookie: session=abc123\r\n"
                    b"\r\n"
                    b"user=admin&password=s3cret&token=deadbeef&filename=flag.txt\r\n"
                    b"flag{pcap_demo}\r\n"
                ),
                time=1.0,
                sport=12345,
                dport=80,
                include_http=True,
            ),
            DummyPacket(
                src="10.0.0.2",
                dst="8.8.8.8",
                protocol="UDP",
                raw=b"example.test",
                time=2.0,
                sport=53000,
                dport=53,
                dns_query=b"example.test.",
            ),
        ]
        self.output = ManagerOutput(sink=lambda _: None)
        self.manager_file = DummyManagerFile(self.packets)
        self.manager = ManagerPcapAnalyzer(
            manager_file=self.manager_file,
            output_manager=self.output,
        )
        self.manager.capture_file = Path("/tmp/demo.pcap")

    def test_build_capture_summary_counts_protocols_conversations_and_ports(self):
        summary = self.manager.build_capture_summary(self.packets)

        self.assertEqual(summary["packet_count"], 2)
        self.assertEqual(summary["protocols"]["TCP"], 1)
        self.assertEqual(summary["protocols"]["DNS"], 1)
        self.assertTrue(summary["has_http"])
        self.assertTrue(summary["has_dns"])
        self.assertEqual(summary["conversations"][0]["src"], "10.0.0.1")
        self.assertIn(80, [item["port"] for item in summary["ports"]])
        self.assertEqual(summary["first_timestamp"], 1.0)
        self.assertEqual(summary["last_timestamp"], 2.0)

    def test_build_summary_text_contains_major_sections(self):
        summary = self.manager.build_capture_summary(self.packets)
        rendered = self.manager.build_summary_text(summary)

        self.assertIn("Capture Summary", rendered)
        self.assertIn("Protocols", rendered)
        self.assertIn("Top Talkers", rendered)
        self.assertIn("Ports", rendered)

    def test_extract_artifacts_collects_flags_credentials_dns_and_files(self):
        artifacts = self.manager.extract_artifacts(self.packets)

        self.assertIn("flag{pcap_demo}", artifacts["flags"])
        self.assertIn("http://example.test", artifacts["http"]["urls"])
        self.assertIn("session=abc123", artifacts["http"]["cookies"])
        self.assertTrue(
            any(
                item["value"] == "admin:s3cret"
                for item in artifacts["http"]["credentials"]
            )
        )
        self.assertIn("example.test", artifacts["dns"]["queries"])
        self.assertIn("flag.txt", artifacts["files"]["filenames"])

    def test_build_extraction_text_contains_key_sections(self):
        rendered = self.manager.build_extraction_text(
            self.manager.extract_artifacts(self.packets)
        )

        self.assertIn("Flag Candidates", rendered)
        self.assertIn("HTTP URLs", rendered)
        self.assertIn("DNS Queries", rendered)

    def test_run_tshark_preset_uses_manager_tools(self):
        result = self.manager.run_tshark_preset("/tmp/demo.pcap", "http")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(self.manager_file.last_run_cmd[0], "tshark")
        self.assertIn("/tmp/demo.pcap", self.manager_file.last_run_cmd)

    def test_run_tshark_raises_when_tool_is_missing(self):
        manager = ManagerPcapAnalyzer(
            manager_file=MissingToolManagerFile(),
            output_manager=self.output,
        )

        with self.assertRaises(FileNotFoundError):
            manager.run_tshark([], "/tmp/demo.pcap")

    def test_graph_capture_returns_metadata_and_can_skip_serving(self):
        dash_manager = DummyDashManager()
        manager = ManagerPcapAnalyzer(
            manager_file=self.manager_file,
            output_manager=self.output,
            dash_manager=dash_manager,
        )

        metadata = manager.graph_capture(
            packets=self.packets,
            mode="timeline",
            title="Timeline Graph",
            serve=False,
        )

        self.assertEqual(metadata["mode"], "timeline")
        self.assertEqual(metadata["element_count"], 1)
        self.assertEqual(metadata["title"], "Timeline Graph")
        self.assertFalse(dash_manager.ran)


if __name__ == "__main__":
    unittest.main()
