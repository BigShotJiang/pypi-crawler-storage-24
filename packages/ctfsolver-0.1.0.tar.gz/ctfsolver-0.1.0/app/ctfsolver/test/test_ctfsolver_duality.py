import importlib
import sys
import unittest

from pathlib import Path
from types import ModuleType
from unittest import mock


class CTFSolverDualityTest(unittest.TestCase):
    def import_runtime_modules_without_optional_dependencies(self):
        fake_manager_file_module = ModuleType("ctfsolver.managers.manager_file")
        fake_manager_connections_module = ModuleType(
            "ctfsolver.managers.manager_connections"
        )
        fake_manager_crypto_module = ModuleType("ctfsolver.managers.manager_crypto")
        fake_manager_binary_module = ModuleType("ctfsolver.managers.manager_binary")
        fake_manager_error_module = ModuleType("ctfsolver.error.manager_error")

        with mock.patch.dict(
            sys.modules,
            {
                "ctfsolver.managers.manager_file": fake_manager_file_module,
                "ctfsolver.managers.manager_connections": fake_manager_connections_module,
                "ctfsolver.managers.manager_crypto": fake_manager_crypto_module,
                "ctfsolver.managers.manager_binary": fake_manager_binary_module,
                "ctfsolver.error.manager_error": fake_manager_error_module,
            },
        ):
            from ctfsolver.managers.manager_folder import ManagerFolder

            class FakeManagerFile(ManagerFolder):
                def search_for_base64_file(self):
                    return None

            class FakeManagerConnections:
                def connect(self):
                    return None

            class FakeManagerCrypto:
                def decode_base64(self):
                    return None

            class FakeManagerBinary:
                def binary_info(self):
                    return None

                def binary_recon(self):
                    return None

                def run_gdb_batch(self):
                    return None

                def gdb_peda_checksec(self):
                    return None

            class FakeManagerError:
                def try_function(self, function):
                    return function()

            fake_manager_file_module.ManagerFile = FakeManagerFile
            fake_manager_connections_module.ManagerConnections = FakeManagerConnections
            fake_manager_crypto_module.ManagerCrypto = FakeManagerCrypto
            fake_manager_binary_module.ManagerBinary = FakeManagerBinary
            fake_manager_error_module.ManagerError = FakeManagerError

            sys.modules.pop("ctfsolver", None)
            sys.modules.pop("ctfsolver.src", None)
            sys.modules.pop("ctfsolver.src.ctfsolver", None)
            sys.modules.pop("ctfsolver.managers", None)
            ctfsolver = importlib.import_module("ctfsolver")
            runtime_module = importlib.import_module("ctfsolver.src.ctfsolver")
            return ctfsolver, runtime_module

    def test_root_package_exports_framework_surface_only(self):
        ctfsolver, _ = self.import_runtime_modules_without_optional_dependencies()

        self.assertEqual(
            ctfsolver.__all__,
            ["CTFSolver", "ManagerConnections", "ManagerCrypto", "ManagerFile"],
        )
        with self.assertRaises(AttributeError):
            getattr(ctfsolver, "ManagerSolutionRunner")

    def test_ctfsolver_runtime_class_does_not_expose_cli_tooling_methods(self):
        _, runtime_module = self.import_runtime_modules_without_optional_dependencies()
        solver_class = runtime_module.CTFSolver

        self.assertTrue(hasattr(solver_class, "main"))
        self.assertTrue(hasattr(solver_class, "try_main"))
        self.assertTrue(hasattr(solver_class, "connect"))
        self.assertTrue(hasattr(solver_class, "decode_base64"))
        self.assertTrue(hasattr(solver_class, "binary_info"))
        self.assertTrue(hasattr(solver_class, "binary_recon"))
        self.assertTrue(hasattr(solver_class, "run_gdb_batch"))
        self.assertTrue(hasattr(solver_class, "gdb_peda_checksec"))
        self.assertTrue(hasattr(solver_class, "extract_flags"))
        self.assertTrue(hasattr(solver_class, "present_flag"))
        self.assertTrue(hasattr(solver_class, "search_for_base64_file"))
        self.assertTrue(hasattr(solver_class, "check_folder_exists"))
        self.assertTrue(hasattr(solver_class, "exec_on_folder"))
        self.assertTrue(hasattr(solver_class, "exec_on_folder_files"))
        self.assertTrue(hasattr(solver_class, "exec_on_files"))
        self.assertTrue(hasattr(solver_class, "search_files"))
        self.assertTrue(hasattr(solver_class, "single_folder_search"))
        self.assertTrue(hasattr(solver_class, "recursive_folder_search"))
        self.assertTrue(hasattr(solver_class, "download_automove"))

        self.assertFalse(hasattr(solver_class, "create"))
        self.assertFalse(hasattr(solver_class, "automove"))
        self.assertFalse(hasattr(solver_class, "link"))
        self.assertFalse(hasattr(solver_class, "explain"))
        self.assertFalse(hasattr(solver_class, "triage"))
        self.assertFalse(hasattr(solver_class, "autosolve"))
        self.assertFalse(hasattr(solver_class, "create_parent_folder"))
        self.assertFalse(hasattr(solver_class, "get_ctf_base_path"))
        self.assertFalse(hasattr(solver_class, "create_ctf_structure"))

    def test_manager_folder_holds_generic_folder_helpers(self):
        from ctfsolver.managers.manager_folder import ManagerFolder

        self.assertTrue(hasattr(ManagerFolder, "check_folder_exists"))
        self.assertTrue(hasattr(ManagerFolder, "exec_on_folder"))
        self.assertTrue(hasattr(ManagerFolder, "exec_on_folder_files"))
        self.assertTrue(hasattr(ManagerFolder, "exec_on_files"))
        self.assertTrue(hasattr(ManagerFolder, "search_files"))
        self.assertTrue(hasattr(ManagerFolder, "single_folder_search"))
        self.assertTrue(hasattr(ManagerFolder, "recursive_folder_search"))
        self.assertTrue(hasattr(ManagerFolder, "download_automove"))

    def test_workspace_manager_holds_workspace_only_helpers(self):
        from ctfsolver.managers.manager_workspace import ManagerWorkspace

        self.assertTrue(hasattr(ManagerWorkspace, "create_parent_folder"))
        self.assertTrue(hasattr(ManagerWorkspace, "get_ctf_base_path"))
        self.assertTrue(hasattr(ManagerWorkspace, "create_ctf_structure"))
        self.assertTrue(hasattr(ManagerWorkspace, "download_automove"))

    def test_solution_template_targets_runtime_surface(self):
        template_path = Path(
            "/home/figaro/Programms/Github_Projects/NikolasProjects/CTFSolverScript/app/ctfsolver/template/solution_template.py"
        )
        template_source = template_path.read_text(encoding="utf-8")

        self.assertIn("from ctfsolver import CTFSolver", template_source)
        self.assertIn("class Solution(CTFSolver):", template_source)
        self.assertNotIn("ctfsolver.cli", template_source)
        self.assertNotIn("ManagerSolutionRunner", template_source)
        self.assertNotIn("ManagerCTFCreator", template_source)


if __name__ == "__main__":
    unittest.main()
