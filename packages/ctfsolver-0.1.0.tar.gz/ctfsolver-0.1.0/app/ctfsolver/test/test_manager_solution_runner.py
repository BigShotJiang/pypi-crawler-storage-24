import sys
import unittest

from pathlib import Path
from tempfile import TemporaryDirectory

from ctfsolver.managers.manager_solution_runner import ManagerSolutionRunner
from ctfsolver.managers.manager_output import ManagerOutput


class DummyManagerFile:
    def __init__(self, solution_file):
        self.solution_file = Path(solution_file)
        self.current_dir_calls = 0

    def get_current_dir(self):
        self.current_dir_calls += 1

    def get_solution_file(self, save=True):
        assert save is True
        return self.solution_file


class ManagerSolutionRunnerTest(unittest.TestCase):
    def test_resolve_mode_infers_local_from_file(self):
        runner = ManagerSolutionRunner(manager_file=DummyManagerFile("solution.py"))

        self.assertEqual(runner.resolve_mode(file="binary"), "local")

    def test_resolve_mode_infers_remote_from_host_and_port(self):
        runner = ManagerSolutionRunner(manager_file=DummyManagerFile("solution.py"))

        self.assertEqual(
            runner.resolve_mode(host="localhost", port=31337), "remote"
        )

    def test_resolve_mode_rejects_conflicting_flags(self):
        runner = ManagerSolutionRunner(manager_file=DummyManagerFile("solution.py"))

        with self.assertRaisesRegex(
            ValueError, "Cannot use both --local and --remote options simultaneously."
        ):
            runner.resolve_mode(local=True, remote=True)

    def test_run_executes_script_when_no_connection_mode_is_selected(self):
        with TemporaryDirectory() as tmp_dir:
            solution_file = Path(tmp_dir, "solution.py")
            solution_file.write_text("print('ok')\n", encoding="utf-8")
            calls = []

            def fake_process_runner(cmd, check):
                calls.append((cmd, check))

                class Result:
                    returncode = 0

                return Result()

            runner = ManagerSolutionRunner(
                manager_file=DummyManagerFile(solution_file),
                process_runner=fake_process_runner,
            )

            self.assertEqual(runner.run(), 0)
            self.assertEqual(calls, [([sys.executable, str(solution_file)], True)])

    def test_run_executes_solution_class_with_inferred_remote_mode(self):
        with TemporaryDirectory() as tmp_dir:
            solution_file = Path(tmp_dir, "solution.py")
            output_file = Path(tmp_dir, "run_output.txt")
            solution_file.write_text(
                "\n".join(
                    [
                        f"OUTPUT_PATH = {str(output_file)!r}",
                        "class Solution:",
                        "    def __init__(self, conn=None, file=None, url=None, port=None):",
                        "        self.conn = conn",
                        "        self.file = file",
                        "        self.url = url",
                        "        self.port = port",
                        "    def try_main(self, file=None):",
                        "        with open(OUTPUT_PATH, 'w', encoding='utf-8') as handle:",
                        "            handle.write('|'.join([str(self.conn), str(self.file), str(self.url), str(self.port), str(file)]))",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            runner = ManagerSolutionRunner(manager_file=DummyManagerFile(solution_file))

            self.assertEqual(runner.run(host="127.0.0.1", port=4444), 0)
            self.assertEqual(
                output_file.read_text(encoding="utf-8"),
                "remote|None|127.0.0.1|4444|None",
            )

    def test_run_requires_try_main_on_solution_class(self):
        with TemporaryDirectory() as tmp_dir:
            solution_file = Path(tmp_dir, "solution.py")
            solution_file.write_text(
                "\n".join(
                    [
                        "class Solution:",
                        "    def __init__(self, conn=None, file=None, url=None, port=None):",
                        "        pass",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            runner = ManagerSolutionRunner(manager_file=DummyManagerFile(solution_file))

            with self.assertRaisesRegex(AttributeError, "try_main"):
                runner.run(local=True, file="binary")

    def test_build_run_summary_formats_selected_execution_path(self):
        runner = ManagerSolutionRunner(
            manager_file=DummyManagerFile("solution.py"),
            output_manager=ManagerOutput(sink=lambda _: None),
        )

        summary = runner.build_run_summary(
            Path("/tmp/payloads/solution.py"),
            mode="remote",
            host="127.0.0.1",
            port=4444,
        )

        self.assertIn("Mode", summary)
        self.assertIn("remote", summary)
        self.assertIn("/tmp/payloads/solution.py", summary)
        self.assertIn("127.0.0.1", summary)


if __name__ == "__main__":
    unittest.main()
