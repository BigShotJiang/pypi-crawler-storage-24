import os
import unittest

from pathlib import Path
from tempfile import TemporaryDirectory

from ctfsolver.managers.manager_ctf_linker import ManagerCTFLinker
from ctfsolver.managers.manager_output import ManagerOutput


class DummyManagerFile:
    def single_folder_search(self, *args, **kwargs):
        path = kwargs["path"]
        exclude = kwargs.get("exclude", [])
        root, dirs, files = next(os.walk(path))
        dirs = [directory for directory in dirs if directory not in exclude]
        return root, dirs, files

    def normalize_name(self, name):
        value = name.lower().replace("_", "").replace("-", "").replace(" ", "")
        return Path(value).stem


class DummyWorkspaceManager:
    def __init__(self):
        self.created = []

    def create_ctf_structure(self, category, site, name, **kwargs):
        self.created.append((category, site, name, kwargs))


class ManagerCTFLinkerTest(unittest.TestCase):
    def test_diff_entries_detects_writeup_only_items(self):
        manager_file = DummyManagerFile()
        linker = ManagerCTFLinker(
            manager_file=manager_file,
            ctf_path=Path("/tmp/ctf"),
            documentation_path=Path("/tmp/docs"),
            exclude_folders=[],
        )

        diffs = linker.diff_entries(
            {"Crypto": {"picoCTF": ["Warm Up"]}},
            {"Crypto": {"picoCTF": ["Warm Up", "New Challenge"]}},
        )

        self.assertEqual(
            diffs,
            {
                "Crypto": {
                    "picoCTF": [{"name": "New Challenge", "source": "writeup"}]
                }
            },
        )

    def test_link_reports_and_creates_missing_challenge_folders(self):
        with TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            ctf_path = root / "ctf"
            docs_path = root / "docs"
            (ctf_path / "Crypto" / "picoCTF" / "Warm Up").mkdir(parents=True)
            (docs_path / "Crypto" / "picoCTF").mkdir(parents=True)
            (docs_path / "Crypto" / "picoCTF" / "Warm Up.md").write_text(
                "# Warm Up\n", encoding="utf-8"
            )
            (docs_path / "Crypto" / "picoCTF" / "New Challenge.md").write_text(
                "# New Challenge\n", encoding="utf-8"
            )

            manager_file = DummyManagerFile()
            workspace_manager = DummyWorkspaceManager()
            linker = ManagerCTFLinker(
                manager_file=manager_file,
                workspace_manager=workspace_manager,
                ctf_path=ctf_path,
                documentation_path=docs_path,
                exclude_folders=[],
            )

            result = linker.link(create_missing=True, verbose=True)

            self.assertEqual(
                result["diffs"]["Crypto"]["picoCTF"],
                [{"name": "New Challenge", "source": "writeup"}],
            )
            self.assertEqual(
                result["created"],
                [
                    {
                        "category": "Crypto",
                        "site": "picoCTF",
                        "name": "New Challenge",
                    }
                ],
            )
            self.assertEqual(
                workspace_manager.created,
                [
                    (
                        "Crypto",
                        "picoCTF",
                        "New Challenge",
                        {"verbose": True, "download": False, "checker": False},
                    )
                ],
            )

    def test_build_summary_text_formats_counts_and_details(self):
        linker = ManagerCTFLinker(
            manager_file=DummyManagerFile(),
            workspace_manager=DummyWorkspaceManager(),
            ctf_path=Path("/tmp/ctf"),
            documentation_path=Path("/tmp/docs"),
            output_manager=ManagerOutput(sink=lambda _: None),
            exclude_folders=[],
        )

        result = {
            "diffs": {
                "Crypto": {
                    "picoCTF": [{"name": "New Challenge", "source": "writeup"}]
                }
            },
            "created": [
                {"category": "Crypto", "site": "picoCTF", "name": "New Challenge"}
            ],
        }

        summary = linker.build_summary_text(result, include_details=True)

        self.assertIn("Differences", summary)
        self.assertIn("Created folders", summary)
        self.assertIn("Link Differences", summary)
        self.assertIn("New Challenge", summary)
        self.assertIn("Created Folders", summary)


if __name__ == "__main__":
    unittest.main()
