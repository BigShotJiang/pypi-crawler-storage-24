import json
import unittest

from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import mock

from ctfsolver.config.global_config import GlobalConfig
from ctfsolver.managers.manager_folder import ManagerFolder
from ctfsolver.managers.manager_output import ManagerOutput


class ManagerFolderOutputTest(unittest.TestCase):
    def test_search_files_display_uses_output_sink(self):
        seen = []
        with TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            target = root / "target.txt"
            target.write_text("flag here", encoding="utf-8")

            manager = ManagerFolder.__new__(ManagerFolder)
            manager.output = ManagerOutput(sink=seen.append)

            matches = ManagerFolder.search_files(
                manager,
                str(root),
                exclude_dirs=[],
                search_string="flag",
                save=True,
                display=True,
            )

        self.assertEqual(matches, [str(target)])
        self.assertTrue(any("target.txt" in line for line in seen))

    def test_download_automove_verbose_uses_output_sink(self):
        seen = []
        with TemporaryDirectory() as tmp_dir:
            tmp_root = Path(tmp_dir)
            matched_file = tmp_root / "warmup.zip"
            matched_file.write_text("zip", encoding="utf-8")

            manager = ManagerFolder.__new__(ManagerFolder)
            manager.output = ManagerOutput(verbosity=2, sink=seen.append)
            manager.verbose = False
            manager.check_name_similarity_in_files = mock.Mock(return_value=[])
            manager.exec_on_folder_files = mock.Mock(return_value=[matched_file])

            with mock.patch(
                "ctfsolver.managers.manager_folder.CONFIG.content",
                {"directories": {"downloads": str(tmp_root)}},
            ):
                with mock.patch("ctfsolver.managers.manager_folder.shutil.move") as move:
                    ManagerFolder.download_automove(
                        manager,
                        category="crypto",
                        challenge_name="warmup",
                        challenge_path=Path("/tmp/ctf/crypto/picoctf/warmup"),
                        verbose=True,
                    )

        move.assert_called_once()
        self.assertTrue(any("Moving file" in line and "warmup.zip" in line for line in seen))


class GlobalConfigOutputTest(unittest.TestCase):
    def test_build_initialization_summary_formats_state(self):
        config = GlobalConfig.__new__(GlobalConfig)
        config.output = ManagerOutput(sink=lambda _: None)

        summary = GlobalConfig.build_initialization_summary(
            config,
            {
                "path": Path("/tmp/global_config.json"),
                "template_path": Path("/tmp/config_template.json"),
                "status": "written",
            },
        )

        self.assertIn("Config path", summary)
        self.assertIn("/tmp/global_config.json", summary)
        self.assertIn("written", summary)

    def test_initial_content_uses_output_manager(self):
        seen = []
        with TemporaryDirectory() as tmp_dir:
            tmp_root = Path(tmp_dir)
            config_path = tmp_root / "global_config.json"
            config_path.write_text("", encoding="utf-8")
            template_dir = tmp_root / "data"
            template_dir.mkdir()
            (template_dir / "config_template.json").write_text(
                json.dumps({"directories": {}}), encoding="utf-8"
            )

            config = GlobalConfig.__new__(GlobalConfig)
            config.output = ManagerOutput(sink=seen.append)
            config.global_config_file_path = config_path
            config.verbose = False

            with mock.patch(
                "ctfsolver.config.global_config.Path",
                wraps=Path,
            ) as patched_path:
                patched_path.home.return_value = tmp_root
                state = GlobalConfig.initial_content(config)

        self.assertEqual(state["status"], "written")
        self.assertTrue(any("Initial content written" in line for line in seen))


if __name__ == "__main__":
    unittest.main()
