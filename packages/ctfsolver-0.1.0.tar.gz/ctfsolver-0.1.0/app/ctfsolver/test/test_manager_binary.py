import importlib
import sys
import tempfile
import unittest

from pathlib import Path
from types import ModuleType
from unittest import mock


def import_manager_binary_module():
    sys.modules.pop("ctfsolver.managers.manager_binary", None)
    return importlib.import_module("ctfsolver.managers.manager_binary")


class FakeELF:
    def __init__(self, path, **kwargs):
        self.path = path
        self.kwargs = kwargs
        self.symbols = {"main": 0x401000, "win": 0x401234}
        self.got = {"puts": 0x404018}
        self.plt = {"puts": 0x401030}
        self.sections = [type("Section", (), {"name": ".text"})(), type("Section", (), {"name": ".got"})()]
        self.segments = [
            type(
                "Segment",
                (),
                {"header": type("Header", (), {"p_flags": 7, "p_vaddr": 0x401000, "p_memsz": 0x1000})()},
            )()
        ]

    def checksec(self):
        return {"NX": True, "PIE": False}


class FakeROP:
    def __init__(self, binaries):
        self.binaries = binaries

    def find_gadget(self, gadgets):
        return {"gadget": gadgets, "address": 0x400123}


class FakePwnModule:
    ELF = FakeELF
    ROP = FakeROP

    @staticmethod
    def cyclic_find(value, n=4):
        return 40 if value else -1

    @staticmethod
    def fmtstr_payload(offset, writes, write_size=None, **kwargs):
        return {
            "offset": offset,
            "writes": writes,
            "write_size": write_size,
            "kwargs": kwargs,
        }


class FakeInstruction:
    def __init__(self, address, size, mnemonic, op_str, bytes_value):
        self.address = address
        self.size = size
        self.mnemonic = mnemonic
        self.op_str = op_str
        self.bytes = bytes_value


class FakeCapstoneDisassembler:
    def __init__(self, arch, mode):
        self.arch = arch
        self.mode = mode

    def disasm(self, data, address):
        return [
            FakeInstruction(address, 1, "nop", "", b"\x90"),
            FakeInstruction(address + 1, 2, "syscall", "", b"\x0f\x05"),
        ]


class FakeCapstoneModule:
    CS_ARCH_X86 = 1
    CS_ARCH_ARM = 2
    CS_ARCH_ARM64 = 3
    CS_MODE_32 = 32
    CS_MODE_64 = 64
    CS_MODE_ARM = 128
    Cs = FakeCapstoneDisassembler


class ManagerBinaryTest(unittest.TestCase):
    def setUp(self):
        self.module = import_manager_binary_module()
        self.ManagerBinary = self.module.ManagerBinary
        handle = tempfile.NamedTemporaryFile(delete=False)
        handle.write(
            b"\x7fELF\x02\x01\x01\x00" + b"\x00" * 10 + b"\x3e\x00" + b"\x00" * 64
            + b".interp"
            + b"ld-linux"
            + b"main win /bin/sh flag"
            + b"\x0f\x05"
        )
        handle.flush()
        handle.close()
        self.binary_path = Path(handle.name)
        self.addCleanup(self.binary_path.unlink)

    def test_binary_info_detects_elf_and_arch(self):
        manager = self.ManagerBinary()

        info = manager.binary_info(self.binary_path)

        self.assertEqual(info["type"], "ELF")
        self.assertEqual(info["arch"], "x86_64")
        self.assertEqual(info["linking"], "dynamic")
        self.assertEqual(info["path"], self.binary_path.resolve())

    def test_pack_unpack_and_pattern_search_helpers(self):
        manager = self.ManagerBinary()

        packed = manager.pack_ptr(0x41424344, bits=32)
        unpacked = manager.unpack_ptr(packed, bits=32)
        patterns = manager.find_opcode_patterns(self.binary_path, ["0f 05", b"/bin/sh"])

        self.assertEqual(unpacked, 0x41424344)
        self.assertTrue(patterns[0]["offsets"])
        self.assertTrue(patterns[1]["offsets"])

    def test_extract_helpers_and_syscall_scan(self):
        manager = self.ManagerBinary()

        strings = manager.extract_xrefs_strings(self.binary_path, strings_only=False)
        immediates = manager.extract_immediates(self.binary_path, width=2, limit=3)
        syscalls = manager.scan_for_syscalls(self.binary_path)

        self.assertTrue(any("main win /bin/sh flag" in item["string"] for item in strings))
        self.assertEqual(len(immediates), 3)
        self.assertTrue(any(item["kind"] == "x86_64_syscall" for item in syscalls))

    def test_pwntools_backed_helpers_work_with_fake_module(self):
        manager = self.ManagerBinary()

        with mock.patch.object(importlib, "import_module", side_effect=self.fake_import_module):
            self.assertEqual(manager.elf_symbols(self.binary_path)["main"], 0x401000)
            self.assertEqual(manager.elf_got(self.binary_path)["puts"], 0x404018)
            self.assertEqual(manager.elf_plt(self.binary_path)["puts"], 0x401030)
            self.assertEqual(manager.elf_sections(self.binary_path), [".text", ".got"])
            self.assertEqual(manager.elf_checksec(self.binary_path)["NX"], True)
            self.assertEqual(manager.resolve_symbol(self.binary_path, "win"), 0x401234)
            self.assertEqual(manager.rop_find_gadget(self.binary_path, ["pop rdi", "ret"])["address"], 0x400123)
            self.assertEqual(manager.cyclic_find_value(b"AAAA"), 40)
            fmt = manager.format_write_payload(6, {0x404040: 0x1337})
            self.assertEqual(fmt["offset"], 6)
            self.assertEqual(manager.find_rwx_segments(self.binary_path)[0]["flags"], 7)
            recon = manager.binary_recon(self.binary_path)
            self.assertIn("main", recon["exports"])

    def test_disasm_and_demangle_helpers(self):
        manager = self.ManagerBinary()

        with mock.patch.object(importlib, "import_module", side_effect=self.fake_import_module):
            instructions = manager.disasm_bytes(b"\x90\x0f\x05")

        self.assertEqual(instructions[0]["mnemonic"], "nop")
        self.assertEqual(instructions[1]["mnemonic"], "syscall")

        with mock.patch.object(manager, "tool_exists", return_value=False):
            with mock.patch.object(importlib, "import_module", side_effect=ModuleNotFoundError):
                self.assertEqual(manager.demangle_symbol("_Z3foov"), "_Z3foov")

    def test_external_tool_wrappers_build_expected_commands(self):
        manager = self.ManagerBinary()
        seen = []

        def fake_run_cmd(argv, **kwargs):
            seen.append(argv)
            return type("Completed", (), {"returncode": 0, "stdout": "", "stderr": ""})()

        with mock.patch.object(manager, "tool_exists", return_value=True):
            with mock.patch.object(manager, "run_cmd", side_effect=fake_run_cmd):
                manager.run_objdump(self.binary_path, args=["-d"])
                manager.run_readelf(self.binary_path, args=["-h"])
                manager.run_rizin(self.binary_path, commands=["aaa", "afl"])
                manager.run_gdb_batch(self.binary_path, ["info functions"])

        self.assertEqual(seen[0][:2], ["objdump", "-d"])
        self.assertEqual(seen[1][:2], ["readelf", "-h"])
        self.assertEqual(seen[2][:3], ["rizin", "-q", "-c"])
        self.assertEqual(seen[3][:3], ["gdb", "-q", "-batch"])

    def test_gdb_peda_helpers_source_peda_script(self):
        manager = self.ManagerBinary()
        seen = []

        def fake_run_cmd(argv, **kwargs):
            seen.append(argv)
            return type("Completed", (), {"returncode": 0, "stdout": "", "stderr": ""})()

        peda = Path("/tmp/peda.py")

        with mock.patch.object(manager, "tool_exists", return_value=True):
            with mock.patch.object(manager, "run_cmd", side_effect=fake_run_cmd):
                with mock.patch.object(manager, "_resolve_peda_path", return_value=peda):
                    manager.gdb_peda_checksec(self.binary_path)
                    manager.gdb_peda_pattern_offset(self.binary_path, "0x41414141")

        self.assertIn("source /tmp/peda.py", seen[0])
        self.assertIn("checksec", seen[0])
        self.assertIn("pattern_offset 0x41414141", seen[1])

    def fake_import_module(self, name):
        if name == "pwn":
            return FakePwnModule
        if name == "capstone":
            return FakeCapstoneModule
        raise ModuleNotFoundError(name)


if __name__ == "__main__":
    unittest.main()
