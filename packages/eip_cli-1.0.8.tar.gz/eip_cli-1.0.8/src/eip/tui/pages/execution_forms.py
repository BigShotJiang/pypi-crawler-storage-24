from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.widgets import Input, Select, Static, Switch

from eip.tui.i18n import I18nCatalog
from eip.tui.widgets.path_input import PathInput


@dataclass(frozen=True)
class FieldSpec:
    field_id: str
    value_key: str
    label_key: str
    help_key: str
    widget_type: str
    placeholder_key: str | None = None
    options: tuple[tuple[str, str], ...] = ()
    value: str = ""
    required_when: str | None = None
    visible_when: str | None = None
    preview_token: str | None = None


COMMAND_FIELD_TEMPLATES: dict[str, tuple[FieldSpec, ...]] = {
    "run": (
        FieldSpec(
            "input-path",
            "input_path",
            "execution.form.field.input",
            "execution.form.help.run_input",
            "path",
            "execution.form.placeholder.input",
            preview_token="<input-file>",
        ),
        FieldSpec(
            "input-dir",
            "input_dir",
            "execution.form.field.input_dir",
            "execution.form.help.run_input_dir",
            "path",
            "execution.form.placeholder.input_dir",
            preview_token="<input-dir>",
        ),
        FieldSpec(
            "seg-mode",
            "seg_mode",
            "execution.form.field.seg_mode",
            "execution.form.help.seg_mode",
            "select",
            options=(
                ("Builtin U-Net", "builtin-unet"),
                ("Custom U-Net", "custom-unet"),
                ("nnU-Net v2", "nnunetv2"),
                ("Existing Segmentation", "existing-seg"),
            ),
            value="builtin-unet",
        ),
        FieldSpec(
            "nnunet-source",
            "nnunet_source",
            "execution.form.field.nnunet_source",
            "execution.form.help.nnunet_source",
            "select",
            options=(("Registry", "registry"), ("Model Directory", "model-dir")),
            value="registry",
            visible_when="seg_mode=nnunetv2",
        ),
        FieldSpec(
            "model-path",
            "model_path",
            "execution.form.field.model_path",
            "execution.form.help.model_path",
            "path",
            "execution.form.placeholder.model_path",
            required_when="seg_mode=custom-unet",
            visible_when="seg_mode=custom-unet",
            preview_token="<model-path>",
        ),
        FieldSpec(
            "seg-input",
            "seg_input",
            "execution.form.field.seg_input",
            "execution.form.help.seg_input",
            "path",
            "execution.form.placeholder.seg_input",
            required_when="seg_mode=existing-seg",
            visible_when="seg_mode=existing-seg",
            preview_token="<seg-input>",
        ),
        FieldSpec(
            "nnunet-dataset",
            "nnunet_dataset",
            "execution.form.field.nnunet_dataset",
            "execution.form.help.nnunet_dataset",
            "input",
            "execution.form.placeholder.nnunet_dataset",
            required_when="seg_mode=nnunetv2,nnunet_source=registry",
            visible_when="seg_mode=nnunetv2,nnunet_source=registry",
            preview_token="<dataset-id>",
        ),
        FieldSpec(
            "nnunet-config",
            "nnunet_config",
            "execution.form.field.nnunet_config",
            "execution.form.help.nnunet_config",
            "input",
            "execution.form.placeholder.nnunet_config",
            required_when="seg_mode=nnunetv2,nnunet_source=registry",
            visible_when="seg_mode=nnunetv2,nnunet_source=registry",
            preview_token="<configuration>",
        ),
        FieldSpec(
            "nnunet-model-dir",
            "nnunet_model_dir",
            "execution.form.field.nnunet_model_dir",
            "execution.form.help.nnunet_model_dir",
            "path",
            "execution.form.placeholder.nnunet_model_dir",
            required_when="seg_mode=nnunetv2,nnunet_source=model-dir",
            visible_when="seg_mode=nnunetv2,nnunet_source=model-dir",
            preview_token="<model-dir>",
        ),
        FieldSpec(
            "nnunet-folds",
            "nnunet_folds",
            "execution.form.field.nnunet_folds",
            "execution.form.help.nnunet_folds",
            "input",
            "execution.form.placeholder.nnunet_folds",
            visible_when="seg_mode=nnunetv2",
        ),
        FieldSpec(
            "nnunet-checkpoint",
            "nnunet_checkpoint",
            "execution.form.field.nnunet_checkpoint",
            "execution.form.help.nnunet_checkpoint",
            "input",
            "execution.form.placeholder.nnunet_checkpoint",
            visible_when="seg_mode=nnunetv2",
        ),
        FieldSpec(
            "axis",
            "axis",
            "execution.form.field.axis",
            "execution.form.help.axis",
            "select",
            options=(("Z (0)", "0"), ("Y (1)", "1"), ("X (2)", "2")),
            value="0",
        ),
        FieldSpec(
            "all",
            "all",
            "execution.form.field.all",
            "execution.form.help.all",
            "switch",
        ),
        FieldSpec(
            "count",
            "count",
            "execution.form.field.count",
            "execution.form.help.count",
            "input",
            visible_when="all=true",
        ),
        FieldSpec(
            "png",
            "png",
            "execution.form.field.png",
            "execution.form.help.png",
            "switch",
        ),
        FieldSpec(
            "ring-width",
            "ring_width",
            "execution.form.field.ring_width",
            "execution.form.help.ring_width",
            "input",
            "execution.form.placeholder.ring_width",
            value="8",
        ),
        FieldSpec(
            "polar-width",
            "polar_width",
            "execution.form.field.polar_width",
            "execution.form.help.polar_width",
            "input",
            "execution.form.placeholder.polar_width",
            value="360",
        ),
        FieldSpec(
            "convex-filter",
            "convex_filter",
            "execution.form.field.convex_filter",
            "execution.form.help.convex_filter",
            "switch",
        ),
        FieldSpec(
            "convex-global-ratio",
            "convex_global_ratio",
            "execution.form.field.convex_global_ratio",
            "execution.form.help.convex_global_ratio",
            "input",
            value="1.35",
            visible_when="convex_filter=true",
        ),
        FieldSpec(
            "convex-local-window",
            "convex_local_window",
            "execution.form.field.convex_local_window",
            "execution.form.help.convex_local_window",
            "input",
            value="5",
            visible_when="convex_filter=true",
        ),
        FieldSpec(
            "convex-local-delta",
            "convex_local_delta",
            "execution.form.field.convex_local_delta",
            "execution.form.help.convex_local_delta",
            "input",
            value="4",
            visible_when="convex_filter=true",
        ),
        FieldSpec(
            "output",
            "output",
            "execution.form.field.output",
            "execution.form.help.output",
            "path",
            "execution.form.placeholder.output",
            preview_token="<output-dir>",
        ),
    ),
    "segment": (
        FieldSpec(
            "input-path",
            "input_path",
            "execution.form.field.input",
            "execution.form.help.input",
            "path",
            "execution.form.placeholder.input",
            preview_token="<input-file>",
        ),
        FieldSpec(
            "input-dir",
            "input_dir",
            "execution.form.field.input_dir",
            "execution.form.help.input_dir",
            "path",
            "execution.form.placeholder.input_dir",
            preview_token="<input-dir>",
        ),
        FieldSpec(
            "seg-mode",
            "seg_mode",
            "execution.form.field.seg_mode",
            "execution.form.help.seg_mode",
            "select",
            options=(
                ("Builtin U-Net", "builtin-unet"),
                ("Custom U-Net", "custom-unet"),
                ("nnU-Net v2", "nnunetv2"),
                ("Existing Segmentation", "existing-seg"),
            ),
            value="builtin-unet",
        ),
        FieldSpec(
            "nnunet-source",
            "nnunet_source",
            "execution.form.field.nnunet_source",
            "execution.form.help.nnunet_source",
            "select",
            options=(("Registry", "registry"), ("Model Directory", "model-dir")),
            value="registry",
            visible_when="seg_mode=nnunetv2",
        ),
        FieldSpec(
            "model-path",
            "model_path",
            "execution.form.field.model_path",
            "execution.form.help.model_path",
            "path",
            "execution.form.placeholder.model_path",
            required_when="seg_mode=custom-unet",
            visible_when="seg_mode=custom-unet",
            preview_token="<model-path>",
        ),
        FieldSpec(
            "seg-input",
            "seg_input",
            "execution.form.field.seg_input",
            "execution.form.help.seg_input",
            "path",
            "execution.form.placeholder.seg_input",
            required_when="seg_mode=existing-seg",
            visible_when="seg_mode=existing-seg",
            preview_token="<seg-input>",
        ),
        FieldSpec(
            "nnunet-dataset",
            "nnunet_dataset",
            "execution.form.field.nnunet_dataset",
            "execution.form.help.nnunet_dataset",
            "input",
            "execution.form.placeholder.nnunet_dataset",
            required_when="seg_mode=nnunetv2,nnunet_source=registry",
            visible_when="seg_mode=nnunetv2,nnunet_source=registry",
            preview_token="<dataset-id>",
        ),
        FieldSpec(
            "nnunet-config",
            "nnunet_config",
            "execution.form.field.nnunet_config",
            "execution.form.help.nnunet_config",
            "input",
            "execution.form.placeholder.nnunet_config",
            required_when="seg_mode=nnunetv2,nnunet_source=registry",
            visible_when="seg_mode=nnunetv2,nnunet_source=registry",
            preview_token="<configuration>",
        ),
        FieldSpec(
            "nnunet-model-dir",
            "nnunet_model_dir",
            "execution.form.field.nnunet_model_dir",
            "execution.form.help.nnunet_model_dir",
            "path",
            "execution.form.placeholder.nnunet_model_dir",
            required_when="seg_mode=nnunetv2,nnunet_source=model-dir",
            visible_when="seg_mode=nnunetv2,nnunet_source=model-dir",
            preview_token="<model-dir>",
        ),
        FieldSpec(
            "nnunet-folds",
            "nnunet_folds",
            "execution.form.field.nnunet_folds",
            "execution.form.help.nnunet_folds",
            "input",
            "execution.form.placeholder.nnunet_folds",
            visible_when="seg_mode=nnunetv2",
        ),
        FieldSpec(
            "nnunet-checkpoint",
            "nnunet_checkpoint",
            "execution.form.field.nnunet_checkpoint",
            "execution.form.help.nnunet_checkpoint",
            "input",
            "execution.form.placeholder.nnunet_checkpoint",
            visible_when="seg_mode=nnunetv2",
        ),
        FieldSpec(
            "output",
            "output",
            "execution.form.field.output",
            "execution.form.help.output",
            "path",
            "execution.form.placeholder.output",
            preview_token="<output-dir>",
        ),
    ),
    "slice": (
        FieldSpec("input-path", "input_path", "execution.form.field.input", "execution.form.help.input", "path", "execution.form.placeholder.input"),
        FieldSpec("input-dir", "input_dir", "execution.form.field.input_dir", "execution.form.help.input_dir", "path", "execution.form.placeholder.input_dir"),
        FieldSpec("output", "output", "execution.form.field.output", "execution.form.help.output", "path", "execution.form.placeholder.output"),
    ),
    "refine": (
        FieldSpec("input-path", "input_path", "execution.form.field.input", "execution.form.help.input", "path", "execution.form.placeholder.input"),
        FieldSpec("input-dir", "input_dir", "execution.form.field.input_dir", "execution.form.help.input_dir", "path", "execution.form.placeholder.input_dir"),
        FieldSpec("output", "output", "execution.form.field.output", "execution.form.help.output", "path", "execution.form.placeholder.output"),
    ),
    "centroid": (
        FieldSpec("input-path", "input_path", "execution.form.field.input", "execution.form.help.input", "path", "execution.form.placeholder.input"),
        FieldSpec("input-dir", "input_dir", "execution.form.field.input_dir", "execution.form.help.input_dir", "path", "execution.form.placeholder.input_dir"),
        FieldSpec("output", "output", "execution.form.field.output", "execution.form.help.output", "path", "execution.form.placeholder.output"),
    ),
    "polar": (
        FieldSpec("input-path", "input_path", "execution.form.field.input", "execution.form.help.input", "path", "execution.form.placeholder.input"),
        FieldSpec("input-dir", "input_dir", "execution.form.field.input_dir", "execution.form.help.input_dir", "path", "execution.form.placeholder.input_dir"),
        FieldSpec("data", "data", "execution.form.field.data", "execution.form.help.data", "path", "execution.form.placeholder.data"),
        FieldSpec("axis", "axis", "execution.form.field.axis", "execution.form.help.axis", "select", options=(("Z (0)", "0"), ("Y (1)", "1"), ("X (2)", "2")), value="0"),
        FieldSpec("all", "all", "execution.form.field.all", "execution.form.help.all", "switch"),
        FieldSpec("count", "count", "execution.form.field.count", "execution.form.help.count", "input", visible_when="all=true"),
        FieldSpec("png", "png", "execution.form.field.png", "execution.form.help.png", "switch"),
        FieldSpec("ring-width", "ring_width", "execution.form.field.ring_width", "execution.form.help.ring_width", "input", "execution.form.placeholder.ring_width", value="8"),
        FieldSpec("polar-width", "polar_width", "execution.form.field.polar_width", "execution.form.help.polar_width", "input", "execution.form.placeholder.polar_width", value="360"),
        FieldSpec("convex-filter", "convex_filter", "execution.form.field.convex_filter", "execution.form.help.convex_filter", "switch"),
        FieldSpec("convex-global-ratio", "convex_global_ratio", "execution.form.field.convex_global_ratio", "execution.form.help.convex_global_ratio", "input", value="1.35", visible_when="convex_filter=true"),
        FieldSpec("convex-local-window", "convex_local_window", "execution.form.field.convex_local_window", "execution.form.help.convex_local_window", "input", value="5", visible_when="convex_filter=true"),
        FieldSpec("convex-local-delta", "convex_local_delta", "execution.form.field.convex_local_delta", "execution.form.help.convex_local_delta", "input", value="4", visible_when="convex_filter=true"),
        FieldSpec("output", "output", "execution.form.field.output", "execution.form.help.output", "path", "execution.form.placeholder.output"),
    ),
}


def make_field_specs(prefix: str, command_key: str, *, values: dict[str, str] | None = None) -> tuple[FieldSpec, ...]:
    resolved_values = values or {}
    fields: list[FieldSpec] = []
    for template in COMMAND_FIELD_TEMPLATES[command_key]:
        fields.append(
            FieldSpec(
                field_id=f"{prefix}-{template.field_id}",
                value_key=template.value_key,
                label_key=template.label_key,
                help_key=template.help_key,
                widget_type=template.widget_type,
                placeholder_key=template.placeholder_key,
                options=template.options,
                value=resolved_values.get(template.value_key, template.value),
                required_when=template.required_when,
                visible_when=template.visible_when,
                preview_token=template.preview_token,
            )
        )
    return tuple(fields)


class CommandDetailForm(Vertical):
    DEFAULT_CSS = """
    CommandDetailForm {
        height: auto;
    }

    CommandDetailForm > Input,
    CommandDetailForm > Select,
    CommandDetailForm > Switch,
    CommandDetailForm > PathInput {
        margin-bottom: 1;
    }
    """

    _fallback_catalog = I18nCatalog.load()

    def __init__(self, title_key: str, subtitle_key: str, fields: tuple[FieldSpec, ...] = (), **kwargs):
        super().__init__(**kwargs)
        self.title_key = title_key
        self.subtitle_key = subtitle_key
        self.fields = fields

    def tr(self, key: str, **kwargs) -> str:
        try:
            return self.app.tr(key, **kwargs)
        except Exception:
            return self._fallback_catalog.text("en_US", key, **kwargs)

    def compose(self) -> ComposeResult:
        yield Static(self.tr(self.title_key), classes="section-title", id=f"{self.id}-title")
        yield Static(self.tr(self.subtitle_key), classes="subtitle", id=f"{self.id}-subtitle")
        for field in self.fields:
            yield Static(self.tr(field.label_key), classes="section-title", id=f"{field.field_id}-label")
            yield Static(self.tr(field.help_key), classes="subtitle", id=f"{field.field_id}-help")
            if field.widget_type == "path":
                yield PathInput(
                    id=field.field_id,
                    base_path=Path.cwd(),
                    placeholder=self.tr(field.placeholder_key) if field.placeholder_key else "",
                    value=field.value,
                )
            elif field.widget_type == "select":
                yield Select(list(field.options), value=field.value, id=field.field_id)
            elif field.widget_type == "switch":
                yield Switch(value=_is_truthy(field.value), id=field.field_id)
            else:
                yield Input(
                    value=field.value,
                    id=field.field_id,
                    placeholder=self.tr(field.placeholder_key) if field.placeholder_key else "",
                )

    def refresh_text(self) -> None:
        self.query_one(f"#{self.id}-title", Static).update(self.tr(self.title_key))
        self.query_one(f"#{self.id}-subtitle", Static).update(self.tr(self.subtitle_key))
        for field in self.fields:
            self.query_one(f"#{field.field_id}-label", Static).update(self.tr(field.label_key))
            self.query_one(f"#{field.field_id}-help", Static).update(self.tr(field.help_key))
            if field.widget_type == "path":
                widget = self.query_one(f"#{field.field_id}", PathInput)
                widget.placeholder = self.tr(field.placeholder_key) if field.placeholder_key else ""
                widget.refresh_text()
            elif field.widget_type == "select":
                widget = self.query_one(f"#{field.field_id}", Select)
                widget.options = list(field.options)
            elif field.widget_type == "switch":
                continue
            else:
                widget = self.query_one(f"#{field.field_id}", Input)
                widget.placeholder = self.tr(field.placeholder_key) if field.placeholder_key else ""

    def current_values(self) -> dict[str, str]:
        values: dict[str, str] = {}
        for field in self.fields:
            widget = self.query_one(f"#{field.field_id}")
            if isinstance(widget, PathInput):
                raw_value = widget.value.strip()
            elif isinstance(widget, Select):
                raw_value = "" if widget.value == Select.BLANK else str(widget.value)
            elif isinstance(widget, Switch):
                raw_value = "true" if widget.value else ""
            else:
                raw_value = getattr(widget, "value", "").strip()
            if raw_value:
                values[field.value_key] = raw_value
        return values

    def visible_fields(self) -> tuple[FieldSpec, ...]:
        values = self.current_values()
        return tuple(field for field in self.fields if self._matches_rule(field.visible_when, values))

    def refresh_visibility(self) -> None:
        values = self.current_values()
        for field in self.fields:
            visible = self._matches_rule(field.visible_when, values)
            display = "block" if visible else "none"
            self.query_one(f"#{field.field_id}-label", Static).styles.display = display
            self.query_one(f"#{field.field_id}-help", Static).styles.display = display
            self.query_one(f"#{field.field_id}").styles.display = display

    def _matches_rule(self, rule: str | None, values: dict[str, str]) -> bool:
        if not rule:
            return True
        for condition in rule.split(","):
            key, _, expected = condition.partition("=")
            if values.get(key.strip()) != expected.strip():
                return False
        return True


class RunForm(CommandDetailForm):
    def __init__(self, **kwargs):
        super().__init__(
            "execution.form.run.title",
            "execution.form.run.subtitle",
            fields=make_field_specs("run", "run"),
            **kwargs,
        )


class SegmentForm(CommandDetailForm):
    def __init__(self, **kwargs):
        super().__init__(
            "execution.form.segment.title",
            "execution.form.segment.subtitle",
            fields=make_field_specs("segment", "segment"),
            **kwargs,
        )


class SliceForm(CommandDetailForm):
    def __init__(self, **kwargs):
        super().__init__(
            "execution.form.slice.title",
            "execution.form.slice.subtitle",
            fields=make_field_specs("slice", "slice"),
            **kwargs,
        )


class RefineForm(CommandDetailForm):
    def __init__(self, **kwargs):
        super().__init__(
            "execution.form.refine.title",
            "execution.form.refine.subtitle",
            fields=make_field_specs("refine", "refine"),
            **kwargs,
        )


class CentroidForm(CommandDetailForm):
    def __init__(self, **kwargs):
        super().__init__(
            "execution.form.centroid.title",
            "execution.form.centroid.subtitle",
            fields=make_field_specs("centroid", "centroid"),
            **kwargs,
        )


class PolarForm(CommandDetailForm):
    def __init__(self, **kwargs):
        super().__init__(
            "execution.form.polar.title",
            "execution.form.polar.subtitle",
            fields=make_field_specs("polar", "polar"),
            **kwargs,
        )


def _is_truthy(value: str) -> bool:
    return value.lower() in {"1", "true", "yes", "on"}
