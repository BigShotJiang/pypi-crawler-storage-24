from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.widgets import Static, TabbedContent, TabPane

from eip.tui.command_help import HELP_COMMAND_ORDER, RUN_SCENARIOS, SIMPLE_SCENARIOS
from eip.tui.layout import EipScreen


class CliHelpScreen(EipScreen):
    page_key = "cli-help"
    page_title_key = "page_cli_help"
    page_subtitle_key = "cli_help.subtitle"
    active_nav = "cli-help"

    def compose_body(self) -> ComposeResult:
        with TabbedContent(initial="cli-help-tab-run", id="cli-help-tabs"):
            for command in HELP_COMMAND_ORDER:
                with TabPane(command, id=f"cli-help-tab-{command}"):
                    with Vertical(id=f"cli-help-pane-{command}", classes="panel"):
                        yield Static(self._render_command_help(command), id=f"cli-help-body-{command}")

    def refresh_text(self) -> None:
        super().refresh_text()
        for command in HELP_COMMAND_ORDER:
            self.query_one(f"#cli-help-body-{command}", Static).update(self._render_command_help(command))

    def _render_command_help(self, command: str) -> str:
        usage_title = self.tr("cli_help.section.usage")
        examples_title = self.tr("cli_help.section.examples")
        errors_title = self.tr("cli_help.section.errors")
        notes_title = self.tr("cli_help.section.notes")
        if command == "run":
            usage = "eip run --input <case.image.nrrd> --seg-mode <mode> [mode options] [--ring-width N] [--convex-filter ...] --output <dir>"
            examples: list[str] = []
            errors: list[str] = []
            notes = (
                "Run performs segmentation, slicing, refinement, centroid export, and polar preview export. "
                "The run input or input-dir is also the polar sample data source for the final export stage. "
                "Convex filtering is optional and only changes the polar-export stage."
            )
            for scenario in RUN_SCENARIOS.values():
                examples.extend(scenario.examples)
                for error, reason, fix in scenario.common_errors:
                    errors.append(f"{error}\nReason: {reason}\nFix: {fix}")
            return self._format_help(usage_title, usage, examples_title, examples, errors_title, errors, notes_title, notes)
        if command == "segment":
            usage = "eip segment --input <case.image.nrrd> --seg-mode <mode> [mode options] --output <dir>"
            examples = []
            errors = []
            notes = "Segment writes a normalized *.seg.nrrd output under cases/<case_id>/segmentation/."
            for key in ("builtin-unet", "custom-unet", "nnunetv2:registry", "nnunetv2:model-dir", "existing-seg"):
                scenario = RUN_SCENARIOS[key]
                examples.extend(example.replace("eip run", "eip segment", 1) for example in scenario.examples)
                for error, reason, fix in scenario.common_errors:
                    errors.append(f"{error}\nReason: {reason}\nFix: {fix}")
            return self._format_help(usage_title, usage, examples_title, examples, errors_title, errors, notes_title, notes)

        if command == "doctor":
            usage = "eip doctor"
            examples = ("eip doctor",)
            errors = ("doctor reports missing executables when dependencies are not on PATH",)
            notes = "Use doctor before nnU-Net execution to confirm runtime availability."
            return self._format_help(usage_title, usage, examples_title, examples, errors_title, errors, notes_title, notes)

        scenario = SIMPLE_SCENARIOS[command]
        usage = f"eip {command} --input <path> --output <dir>"
        errors = [f"{error}\nReason: {reason}\nFix: {fix}" for error, reason, fix in scenario.common_errors]
        notes = self._notes_for_command(command)
        return self._format_help(
            usage_title,
            usage,
            examples_title,
            scenario.examples,
            errors_title,
            errors,
            notes_title,
            notes,
        )

    def _format_help(
        self,
        usage_title: str,
        usage: str,
        examples_title: str,
        examples: list[str] | tuple[str, ...],
        errors_title: str,
        errors: list[str] | tuple[str, ...],
        notes_title: str,
        notes: str,
    ) -> str:
        example_block = "\n".join(f"- {item}" for item in examples) or "- None"
        error_block = "\n\n".join(f"- {item}" for item in errors) or "- None"
        return (
            f"{usage_title}\n{usage}\n\n"
            f"{examples_title}\n{example_block}\n\n"
            f"{errors_title}\n{error_block}\n\n"
            f"{notes_title}\n{notes}"
        )

    def _notes_for_command(self, command: str) -> str:
        if command == "slice":
            return "Slice exports preview PNGs for each slice of the input NRRD volume."
        if command == "refine":
            return "Refine expects a segmentation or label volume and writes a cleaned mask NRRD."
        if command == "centroid":
            return "Centroid expects a segmentation or label volume and writes centroid JSON plus a hotspot PNG."
        if command == "polar":
            return (
                "Polar expects an image or mask input. If a mask is provided, EIP first uses --data when supplied, "
                "then falls back to automatic paired-image lookup. Convex filtering is optional and only affects polar export."
            )
        return ""
