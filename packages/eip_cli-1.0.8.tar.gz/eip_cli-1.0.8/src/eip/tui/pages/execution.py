from __future__ import annotations

import asyncio
from dataclasses import dataclass
from pathlib import Path
import shlex

from rich.text import Text
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.widgets import Button, Input, Select, Static, Switch, TabbedContent, TabPane

from eip.config.models import CommandDefaults, CommandProfile
from eip.config.storage import StorageManager
from eip.tui.layout import EipScreen
from eip.tui.commands import CommandBuilder
from eip.tui.pages.execution_forms import (
    CentroidForm,
    CommandDetailForm,
    PolarForm,
    RefineForm,
    RunForm,
    SegmentForm,
    SliceForm,
)
from eip.tui.process_runner import ProcessRunner
from eip.tui.widgets.path_input import PathInput


@dataclass(frozen=True)
class WorkflowSpec:
    action_key: str
    cli_command: str
    form_factory: type[CommandDetailForm]


WORKFLOW_SPECS: list[WorkflowSpec] = [
    WorkflowSpec(
        action_key="full_run",
        cli_command="run",
        form_factory=RunForm,
    ),
    WorkflowSpec(
        action_key="segment",
        cli_command="segment",
        form_factory=SegmentForm,
    ),
    WorkflowSpec(
        action_key="slice",
        cli_command="slice",
        form_factory=SliceForm,
    ),
    WorkflowSpec(
        action_key="refine",
        cli_command="refine",
        form_factory=RefineForm,
    ),
    WorkflowSpec(
        action_key="centroid",
        cli_command="centroid",
        form_factory=CentroidForm,
    ),
    WorkflowSpec(
        action_key="polar",
        cli_command="polar",
        form_factory=PolarForm,
    ),
]


class ExecutionScreen(EipScreen):
    DEFAULT_CSS = """
    #execution-workflow-tabs {
        height: auto;
        margin-bottom: 1;
    }

    #execution-workflow-tabs > ContentSwitcher {
        height: auto;
    }

    #execution-workflow-tabs TabPane {
        height: auto;
        padding-top: 1;
    }

    .execution-pane {
        height: auto;
    }

    .execution-preview {
        margin-top: 1;
        margin-bottom: 1;
        padding: 1;
        border: round $panel;
        background: $panel;
    }

    .execution-run-button {
        width: 20;
    }

    #execution-output-title {
        margin-top: 1;
    }

    #execution-output-panel {
        height: 16;
        border: round $accent;
        background: $surface-lighten-2;
    }

    #execution-output-viewer {
        height: auto;
        min-height: 14;
        padding: 1;
    }
    """

    page_key = "execution"
    page_title_key = "page_execution"
    page_subtitle_key = "execution.subtitle"
    active_nav = "execution"

    def __init__(self, path_completion_limit: int = 4, **kwargs):
        super().__init__(**kwargs)
        self.path_completion_limit = path_completion_limit
        self._workflow_map = {self._workflow_tab_id(spec.action_key): spec for spec in WORKFLOW_SPECS}
        self._current_spec = WORKFLOW_SPECS[0]
        self._run_status_key = "execution.run.ready"
        self._run_status_kwargs: dict[str, object] = {}
        self._output_text = ""
        self._run_task: asyncio.Task | None = None
        self._process_runner: ProcessRunner | None = None

    def compose_body(self) -> ComposeResult:
        yield Static(self.tr("execution.section.actions"), classes="section-title", id="execution-actions-title")
        with TabbedContent(initial=self._workflow_tab_id(self._current_spec.action_key), id="execution-workflow-tabs"):
            for spec in WORKFLOW_SPECS:
                action_slug = self._workflow_slug(spec.action_key)
                form = spec.form_factory(id=self._form_id(spec))
                resolved = self._resolve_command_for_values(spec, self._default_form_values(form))
                with TabPane(self._workflow_label(spec), id=self._workflow_tab_id(spec.action_key)):
                    with Vertical(id=f"execution-pane-{action_slug}", classes="panel execution-pane"):
                        yield Static(
                            Text(resolved.summary),
                            id=f"execution-detail-{action_slug}",
                            classes="subtitle",
                        )
                        yield Select(
                            self._profile_source_options(spec.cli_command),
                            value="custom",
                            id=f"execution-profile-source-{action_slug}",
                        )
                        yield Input(
                            placeholder=self.tr("execution.profile.name_placeholder"),
                            id=f"execution-profile-name-{action_slug}",
                        )
                        with Horizontal(id=f"execution-profile-actions-{action_slug}", classes="action-row"):
                            yield Button(self.tr("execution.action.load_profile"), id=f"execution-load-profile-{action_slug}")
                            yield Button(self.tr("execution.action.save_profile"), id=f"execution-save-profile-{action_slug}")
                        yield form
                        yield Static(
                            self.tr("execution.panel.command_preview"),
                            id=f"execution-preview-title-{action_slug}",
                            classes="section-title",
                        )
                        yield Static(Text(resolved.preview), id=f"execution-preview-{action_slug}", classes="execution-preview")
                        yield Button(
                            self.tr("execution.action.run"),
                            id=f"execution-run-{action_slug}",
                            classes="execution-run-button",
                            variant="primary",
                            disabled=bool(resolved.missing),
                        )
        yield Static(self.tr("execution.section.quick_input"), classes="section-title", id="execution-quick-input-title")
        yield Static(self.tr("execution.quick_input.help"), id="execution-body", classes="subtitle")
        yield PathInput(
            id="execution-path",
            base_path=Path.cwd(),
            allowed_suffixes=(".nrrd", ".nhdr"),
            max_candidates=self.path_completion_limit,
            placeholder=self.tr("execution.path.placeholder"),
        )
        yield Static(self.tr("execution.section.output"), classes="section-title", id="execution-output-title")
        with VerticalScroll(id="execution-output-panel"):
            yield Static(self._output_text or self.tr("execution.output.placeholder"), id="execution-output-viewer")
        yield Static(self.tr(self._run_status_key, **self._run_status_kwargs), id="execution-run-status", classes="subtitle")

    def on_mount(self) -> None:
        self._sync_runtime_settings_from_app()
        for spec in WORKFLOW_SPECS:
            form = self.query_one(f"#{self._form_id(spec)}", CommandDetailForm)
            form.refresh_visibility()
            self._refresh_profile_options(spec)
            self._refresh_command_state(spec)

    def on_screen_resume(self) -> None:
        self._sync_runtime_settings_from_app()
        for spec in WORKFLOW_SPECS:
            self._refresh_profile_options(spec)
            self._refresh_command_state(spec)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id or ""
        if button_id.startswith("execution-run-"):
            action_key = button_id.removeprefix("execution-run-").replace("-", "_")
            spec = next((item for item in WORKFLOW_SPECS if item.action_key == action_key), None)
            if spec is not None:
                if self._run_task is not None and not self._run_task.done():
                    self._set_run_status("execution.run.already_running")
                    self._refresh_run_widgets()
                    return
                self._run_task = asyncio.create_task(self._execute_workflow(spec))
            return
        if button_id.startswith("execution-load-profile-"):
            action_key = button_id.removeprefix("execution-load-profile-").replace("-", "_")
            spec = next((item for item in WORKFLOW_SPECS if item.action_key == action_key), None)
            if spec is not None:
                self._load_selected_profile(spec)
            return
        if button_id.startswith("execution-save-profile-"):
            action_key = button_id.removeprefix("execution-save-profile-").replace("-", "_")
            spec = next((item for item in WORKFLOW_SPECS if item.action_key == action_key), None)
            if spec is not None:
                self._save_current_as_profile(spec)
            return
        super().on_button_pressed(event)

    def on_tabbed_content_tab_activated(self, event: TabbedContent.TabActivated) -> None:
        if event.tabbed_content.id != "execution-workflow-tabs":
            return
        spec = self._workflow_map.get(event.pane.id or "")
        if spec is None:
            return
        self._current_spec = spec
        form = self.query_one(f"#{self._form_id(spec)}", CommandDetailForm)
        form.refresh_visibility()
        self._refresh_command_state(spec)
        self._log_workflow_selection(spec)

    def on_input_changed(self, event) -> None:
        widget_id = getattr(event.input, "id", "") or ""
        if widget_id == "execution-path":
            self._refresh_command_state(self._current_spec)
            return
        spec = self._spec_for_widget(widget_id)
        if spec is None:
            return
        form = self.query_one(f"#{self._form_id(spec)}", CommandDetailForm)
        form.refresh_visibility()
        self._refresh_command_state(spec)

    def on_path_input_changed(self, event: PathInput.Changed) -> None:
        widget_id = event.path_input.id or ""
        if widget_id == "execution-path":
            self._refresh_command_state(self._current_spec)
            return
        spec = self._spec_for_widget(widget_id)
        if spec is None:
            return
        form = self.query_one(f"#{self._form_id(spec)}", CommandDetailForm)
        form.refresh_visibility()
        self._refresh_command_state(spec)

    def on_select_changed(self, event: Select.Changed) -> None:
        widget_id = event.select.id or ""
        spec = self._spec_for_widget(widget_id)
        if spec is None:
            return
        form = self.query_one(f"#{self._form_id(spec)}", CommandDetailForm)
        form.refresh_visibility()
        self._refresh_command_state(spec)

    def on_switch_changed(self, event: Switch.Changed) -> None:
        widget_id = event.switch.id or ""
        spec = self._spec_for_widget(widget_id)
        if spec is None:
            return
        form = self.query_one(f"#{self._form_id(spec)}", CommandDetailForm)
        form.refresh_visibility()
        self._refresh_command_state(spec)

    def status_text(self) -> str:
        return self.tr("execution.status.help")

    def refresh_text(self) -> None:
        super().refresh_text()
        self.query_one("#execution-quick-input-title", Static).update(self.tr("execution.section.quick_input"))
        self.query_one("#execution-body", Static).update(self.tr("execution.quick_input.help"))
        path_input = self.query_one("#execution-path", PathInput)
        path_input.placeholder = self.tr("execution.path.placeholder")
        path_input.refresh_text()
        self.query_one("#execution-actions-title", Static).update(self.tr("execution.section.actions"))
        self.query_one("#execution-output-title", Static).update(self.tr("execution.section.output"))
        self.query_one("#execution-run-status", Static).update(self.tr(self._run_status_key, **self._run_status_kwargs))
        self.query_one("#execution-output-viewer", Static).update(self._output_text or self.tr("execution.output.placeholder"))
        for spec in WORKFLOW_SPECS:
            action_slug = self._workflow_slug(spec.action_key)
            self.query_one(f"#{self._workflow_tab_id(spec.action_key)}", TabPane).title = self._workflow_label(spec)
            self.query_one(f"#execution-preview-title-{action_slug}", Static).update(self.tr("execution.panel.command_preview"))
            self.query_one(f"#execution-run-{action_slug}", Button).label = self.tr("execution.action.run")
            self.query_one(f"#execution-load-profile-{action_slug}", Button).label = self.tr("execution.action.load_profile")
            self.query_one(f"#execution-save-profile-{action_slug}", Button).label = self.tr("execution.action.save_profile")
            self.query_one(f"#execution-profile-name-{action_slug}", Input).placeholder = self.tr("execution.profile.name_placeholder")
            self.query_one(f"#execution-profile-source-{action_slug}", Select).set_options(
                self._profile_source_options(spec.cli_command)
            )
            form = self.query_one(f"#{self._form_id(spec)}")
            refresher = getattr(form, "refresh_text", None)
            if refresher is not None:
                refresher()
            form.refresh_visibility()
            self._refresh_command_state(spec)

    def _workflow_tab_id(self, action_key: str) -> str:
        return f"execution-tab-{self._workflow_slug(action_key)}"

    def _workflow_slug(self, action_key: str) -> str:
        return action_key.replace("_", "-")

    def _workflow_label(self, spec: WorkflowSpec) -> str:
        return self.tr(f"execution.workflow.{spec.action_key}.label")

    def _workflow_detail(self, spec: WorkflowSpec) -> str:
        return self.tr(f"execution.workflow.{spec.action_key}.detail")

    def _form_id(self, spec: WorkflowSpec) -> str:
        return "run-form" if spec.action_key == "full_run" else f"{spec.action_key}-form"

    def _log_workflow_selection(self, spec: WorkflowSpec) -> None:
        try:
            logger = getattr(self.app, "log_event", None)
        except AttributeError:
            logger = None
        if logger is None:
            return
        logger(
            "info",
            "execution",
            self.tr(f"execution.workflow.{spec.action_key}.status"),
            command=self._resolve_command(spec).preview,
        )

    def _record_feedback(self, action: str, phase: str, message: str, level: str = "info", **metadata) -> None:
        try:
            recorder = getattr(self.app, "record_feedback", None)
        except AttributeError:
            recorder = None
        if recorder is None:
            return
        recorder(
            source="execution",
            action=action,
            phase=phase,
            message=message,
            level=level,
            **metadata,
        )

    async def _execute_workflow(self, spec: WorkflowSpec) -> None:
        resolved = self._resolve_command(spec)
        if resolved.missing:
            self._output_text = "$ " + resolved.preview + "\nCommand not executed.\nReason: Missing " + ", ".join(resolved.missing) + ".\n"
            self._set_run_status("execution.run.failed", error=", ".join(resolved.missing))
            self._refresh_run_widgets()
            self._record_feedback(
                "run",
                "noop",
                self.tr("execution.run.failed", error=", ".join(resolved.missing)),
                level="warn",
                command=resolved.preview,
            )
            return
        argv = resolved.argv
        self._output_text = f"$ {shlex.join(argv)}\n"
        self._set_run_status("execution.run.running", command=spec.cli_command)
        self._refresh_run_widgets()
        self._record_feedback(
            "run",
            "start",
            self.tr("execution.run.running", command=spec.cli_command),
            command=shlex.join(argv),
        )
        try:
            result = await self._runner().run_stream(argv, on_output=self._append_process_output)
        except Exception as exc:
            self._append_process_output("stderr", f"{exc}\n")
            self._set_run_status("execution.run.failed", error=str(exc))
            self._refresh_run_widgets()
            self._record_feedback(
                "run",
                "error",
                self.tr("execution.run.failed", error=str(exc)),
                level="error",
                command=shlex.join(argv),
            )
            return
        self._set_run_status("execution.run.completed", code=result.exit_code)
        self._append_process_output("stdout", f"\n[{self.tr('execution.output.exit_code', code=result.exit_code)}]\n")
        self._refresh_run_widgets()
        self._log_process_completion(result.exit_code, argv)

    def _build_argv(self, spec: WorkflowSpec) -> list[str]:
        return self._resolve_command(spec).argv

    def _collect_form_values(self, spec: WorkflowSpec) -> dict[str, str]:
        form = self.query_one(f"#{self._form_id(spec)}", CommandDetailForm)
        values = form.current_values()
        visible_value_keys = {field.value_key for field in form.visible_fields()}
        return {key: value for key, value in values.items() if key in visible_value_keys or key in {"seg_mode", "nnunet_source"}}

    def _apply_quick_input(self, values: dict[str, str]) -> None:
        if values.get("input_path") or values.get("input_dir"):
            return
        quick_input = self.query_one("#execution-path", PathInput).value.strip()
        if not quick_input:
            return
        quick_path = Path(quick_input).expanduser()
        if quick_path.suffix.lower() in {".nrrd", ".nhdr"}:
            values["input_path"] = quick_input
        else:
            values["input_dir"] = quick_input

    def _append_process_output(self, stream_name: str, text: str) -> None:
        self._output_text += text
        self._refresh_run_widgets()

    def _refresh_run_widgets(self) -> None:
        try:
            self.query_one("#execution-output-viewer", Static).update(
                self._output_text or self.tr("execution.output.placeholder")
            )
            self.query_one("#execution-run-status", Static).update(
                self.tr(self._run_status_key, **self._run_status_kwargs)
            )
            panel = self.query_one("#execution-output-panel", VerticalScroll)
            panel.scroll_end(animate=False)
        except Exception:
            return

    def _set_run_status(self, key: str, **kwargs) -> None:
        self._run_status_key = key
        self._run_status_kwargs = kwargs

    def _runner(self) -> ProcessRunner:
        if self._process_runner is None:
            storage_root = getattr(self.app, "storage_root", Path.home() / ".eip")
            self._process_runner = ProcessRunner(log_dir=Path(storage_root) / "logs", log_store=self.app.log_store)
        return self._process_runner

    def _log_process_completion(self, exit_code: int, argv: list[str]) -> None:
        self._record_feedback(
            "run",
            "success" if exit_code == 0 else "error",
            self.tr("execution.run.completed", code=exit_code),
            level="info" if exit_code == 0 else "error",
            command=shlex.join(argv),
        )

    def _resolve_command(self, spec: WorkflowSpec):
        values = self._collect_form_values(spec)
        self._apply_quick_input(values)
        return self._resolve_command_for_values(spec, values)

    def _resolve_command_for_values(self, spec: WorkflowSpec, values: dict[str, str]):
        executable = getattr(getattr(self.app, "tui_settings", None), "eip_executable", "eip")
        return CommandBuilder(eip_executable=executable).resolve(spec.cli_command, **values)

    def _refresh_command_state(self, spec: WorkflowSpec) -> None:
        form = self.query_one(f"#{self._form_id(spec)}", CommandDetailForm)
        raw_values = form.current_values()
        values = self._collect_form_values(spec)
        self._apply_quick_input(values)
        resolved = self._resolve_command_for_values(spec, values)
        validation_errors = self._validation_errors(spec, values, raw_values)
        action_slug = self._workflow_slug(spec.action_key)
        self.query_one(f"#execution-preview-{action_slug}", Static).update(Text(resolved.preview))
        detail = resolved.summary
        if validation_errors:
            detail = "\n".join(
                [detail, *(self.tr("execution.validation.summary", error=error) for error in validation_errors)]
            )
        self.query_one(f"#execution-detail-{action_slug}", Static).update(Text(detail))
        self.query_one(f"#execution-run-{action_slug}", Button).disabled = bool(resolved.missing or validation_errors)

    def _validation_errors(self, spec: WorkflowSpec, values: dict[str, str], raw_values: dict[str, str]) -> list[str]:
        if spec.cli_command not in {"run", "polar"}:
            return []

        errors: list[str] = []
        raw_count = raw_values.get("count", "").strip()
        all_enabled = raw_values.get("all", "").lower() in {"1", "true", "yes", "on"}
        if raw_count:
            if not all_enabled:
                errors.append(self.tr("execution.validation.count_requires_all"))
            else:
                try:
                    count = int(raw_count)
                except ValueError:
                    errors.append(self.tr("execution.validation.count_integer"))
                else:
                    if count < 1:
                        errors.append(self.tr("execution.validation.count_range"))

        raw = values.get("polar_width", "").strip()
        if raw:
            try:
                width = int(raw)
            except ValueError:
                errors.append(self.tr("execution.validation.polar_width_integer"))
            else:
                if width < 360:
                    errors.append(self.tr("execution.validation.polar_width_range"))

        convex_enabled = raw_values.get("convex_filter", "").lower() in {"1", "true", "yes", "on"}
        if not convex_enabled:
            return errors

        raw_ratio = raw_values.get("convex_global_ratio", "").strip()
        if not raw_ratio:
            errors.append(self.tr("execution.validation.convex_global_ratio_number"))
        else:
            try:
                global_ratio = float(raw_ratio)
            except ValueError:
                errors.append(self.tr("execution.validation.convex_global_ratio_number"))
            else:
                if global_ratio <= 1.0:
                    errors.append(self.tr("execution.validation.convex_global_ratio_range"))

        raw_window = raw_values.get("convex_local_window", "").strip()
        if not raw_window:
            errors.append(self.tr("execution.validation.convex_local_window_integer"))
        else:
            try:
                local_window = int(raw_window)
            except ValueError:
                errors.append(self.tr("execution.validation.convex_local_window_integer"))
            else:
                if local_window < 1:
                    errors.append(self.tr("execution.validation.convex_local_window_range"))

        raw_delta = raw_values.get("convex_local_delta", "").strip()
        if not raw_delta:
            errors.append(self.tr("execution.validation.convex_local_delta_number"))
        else:
            try:
                local_delta = float(raw_delta)
            except ValueError:
                errors.append(self.tr("execution.validation.convex_local_delta_number"))
            else:
                if local_delta <= 0:
                    errors.append(self.tr("execution.validation.convex_local_delta_range"))
        return errors

    def _spec_for_widget(self, widget_id: str) -> WorkflowSpec | None:
        if not widget_id:
            return None
        for spec in WORKFLOW_SPECS:
            form_id = self._form_id(spec)
            action_slug = self._workflow_slug(spec.action_key)
            if widget_id.startswith(form_id.removesuffix("-form")) or widget_id.startswith(action_slug.split("-")[0]):
                return spec
        if widget_id.startswith("run-"):
            return next(item for item in WORKFLOW_SPECS if item.action_key == "full_run")
        return None

    def _default_form_values(self, form: CommandDetailForm) -> dict[str, str]:
        return {field.value_key: field.value for field in form.fields if field.value}

    def refresh_profile_sources(self) -> None:
        for spec in WORKFLOW_SPECS:
            try:
                self._refresh_profile_options(spec)
            except Exception:
                continue

    def _sync_runtime_settings_from_app(self) -> None:
        settings = getattr(self.app, "tui_settings", None)
        if settings is None:
            return
        self.path_completion_limit = settings.path_completion_limit
        for widget in self.query(PathInput):
            widget.dialog_enabled = settings.gui_dialog_enabled
            widget.recursive = settings.path_completion_recursive
            widget.set_max_candidates(settings.path_completion_limit)

    def _storage(self) -> StorageManager:
        storage_root = getattr(self.app, "storage_root", Path.home() / ".eip")
        return StorageManager(root=Path(storage_root), anchor_root=Path(storage_root))

    def _profile_source_options(self, cli_command: str) -> list[tuple[str, str]]:
        state = self._storage().load_profiles_state()
        options: list[tuple[str, str]] = [(self.tr("execution.profile.custom"), "custom")]
        for name in state.workflow_profile_names:
            options.append((f"{self.tr('execution.profile.workflow')} / {name}", f"workflow:{name}"))
        for name in state.command_profile_names:
            profile = state.command_profiles.get(name)
            if profile is None or profile.command != cli_command:
                continue
            options.append((f"{self.tr('execution.profile.command')} / {name}", f"command:{name}"))
        return options

    def _refresh_profile_options(self, spec: WorkflowSpec) -> None:
        action_slug = self._workflow_slug(spec.action_key)
        select = self.query_one(f"#execution-profile-source-{action_slug}", Select)
        options = self._profile_source_options(spec.cli_command)
        current_value = "custom" if select.value == Select.BLANK else str(select.value)
        valid_values = {value for _, value in options}
        select.set_options(options)
        select.value = current_value if current_value in valid_values else "custom"

    def _load_selected_profile(self, spec: WorkflowSpec) -> None:
        action_slug = self._workflow_slug(spec.action_key)
        selected = self.query_one(f"#execution-profile-source-{action_slug}", Select).value
        if selected in {Select.BLANK, "custom"}:
            self._record_feedback(
                "load_profile",
                "noop",
                self.tr("execution.profile.custom"),
                level="warn",
                command=spec.cli_command,
            )
            return
        state = self._storage().load_profiles_state()
        selected_value = str(selected)
        values: dict[str, str] = {}
        if selected_value.startswith("workflow:"):
            name = selected_value.split(":", 1)[1]
            profile = state.workflow_profiles.get(name)
            if profile is not None:
                values = profile.commands.get(spec.cli_command, CommandDefaults()).values
        elif selected_value.startswith("command:"):
            name = selected_value.split(":", 1)[1]
            profile = state.command_profiles.get(name)
            if profile is not None and profile.command == spec.cli_command:
                values = profile.values
        self._apply_values_to_form(spec, values)
        form = self.query_one(f"#{self._form_id(spec)}", CommandDetailForm)
        form.refresh_visibility()
        self._refresh_command_state(spec)
        self._record_feedback(
            "load_profile",
            "success",
            self.tr("execution.action.load_profile"),
            command=spec.cli_command,
            profile=selected_value,
        )

    def _save_current_as_profile(self, spec: WorkflowSpec) -> None:
        action_slug = self._workflow_slug(spec.action_key)
        profile_name = self.query_one(f"#execution-profile-name-{action_slug}", Input).value.strip()
        if not profile_name:
            self._record_feedback(
                "save_profile",
                "noop",
                self.tr("profiles.status.invalid_name"),
                level="warn",
                command=spec.cli_command,
            )
            return
        state = self._storage().load_profiles_state()
        if profile_name not in state.command_profile_names:
            state.command_profile_names.append(profile_name)
        state.command_profiles[profile_name] = CommandProfile(
            name=profile_name,
            command=spec.cli_command,
            values=self._collect_form_values(spec),
        )
        self._storage().save_profiles_state(state)
        self.refresh_profile_sources()
        select = self.query_one(f"#execution-profile-source-{action_slug}", Select)
        if f"command:{profile_name}" in {str(value) for value in select._legal_values}:
            select.value = f"command:{profile_name}"
        self._notify_profiles_screen()
        self._record_feedback(
            "save_profile",
            "success",
            self.tr("execution.action.save_profile"),
            command=spec.cli_command,
            profile=profile_name,
        )

    def _notify_profiles_screen(self) -> None:
        try:
            profiles_screen = self.app.get_screen("profiles")
        except Exception:
            return
        reloader = getattr(profiles_screen, "reload_profiles_state", None)
        if reloader is not None:
            reloader()
        if not getattr(profiles_screen, "is_mounted", False):
            return
        refresher = getattr(profiles_screen, "_refresh_view", None)
        if refresher is not None:
            asyncio.create_task(refresher())

    def _apply_values_to_form(self, spec: WorkflowSpec, values: dict[str, str]) -> None:
        form = self.query_one(f"#{self._form_id(spec)}", CommandDetailForm)
        for field in form.fields:
            widget = self.query_one(f"#{field.field_id}")
            value = values.get(field.value_key, "")
            if isinstance(widget, PathInput):
                widget.value = value
            elif isinstance(widget, Select):
                widget.value = value if value else field.value
            elif isinstance(widget, Switch):
                widget.value = value.lower() in {"1", "true", "yes", "on"}
            else:
                widget.value = value
