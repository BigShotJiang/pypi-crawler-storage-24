from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from shlex import join as shlex_join

from eip.tui.command_help import normalize_missing_fields, scenario_summary

_OPTION_MAP = {
    "input_path": "input",
    "input_dir": "input-dir",
    "seg_input": "seg-input",
}


@dataclass(frozen=True)
class ResolvedCommand:
    argv: list[str]
    preview: str
    missing: tuple[str, ...]
    missing_keys: tuple[str, ...]
    summary: str


class CommandBuilder:
    def __init__(self, eip_executable: str = "eip", python_fallback: str | None = None):
        self.eip_executable = eip_executable
        self.python_fallback = python_fallback

    def resolve(self, command: str, **values: object) -> ResolvedCommand:
        normalized = self._normalize_values(values)
        if self._uses_legacy_alias(command, normalized):
            argv = self._build_legacy(command, normalized)
            return ResolvedCommand(
                argv=argv,
                preview=shlex_join(argv),
                missing=(),
                missing_keys=(),
                summary=scenario_summary(command, normalized, ()),
            )

        if command in {"run", "segment"} and "seg_mode" not in normalized:
            normalized["seg_mode"] = "builtin-unet"

        argv = [self.eip_executable, command]
        preview_tokens = [self.eip_executable, command]
        missing_keys: list[str] = []

        self._append_input_tokens(argv, preview_tokens, normalized, missing_keys)
        if command in {"run", "segment"}:
            self._append_segmentation_tokens(argv, preview_tokens, normalized, missing_keys)
        if command in {"run", "polar"}:
            self._append_optional_value(argv, preview_tokens, normalized, "axis", option_name="axis")
            self._append_flag(argv, preview_tokens, normalized, "all", option_name="all")
            if normalized.get("all", "").lower() in {"1", "true", "yes", "on"}:
                self._append_optional_value(argv, preview_tokens, normalized, "count", option_name="count")
            self._append_flag(argv, preview_tokens, normalized, "png", option_name="png")
            self._append_optional_value(argv, preview_tokens, normalized, "ring_width", option_name="ring-width")
            self._append_optional_value(argv, preview_tokens, normalized, "polar_width", option_name="polar-width")
            self._append_flag(argv, preview_tokens, normalized, "convex_filter", option_name="convex-filter")
            if normalized.get("convex_filter", "").lower() in {"1", "true", "yes", "on"}:
                self._append_optional_value(
                    argv, preview_tokens, normalized, "convex_global_ratio", option_name="convex-global-ratio"
                )
                self._append_optional_value(
                    argv, preview_tokens, normalized, "convex_local_window", option_name="convex-local-window"
                )
                self._append_optional_value(
                    argv, preview_tokens, normalized, "convex_local_delta", option_name="convex-local-delta"
                )
        if command == "polar":
            self._append_optional_value(argv, preview_tokens, normalized, "data", option_name="data", quote=True)
        self._append_output_tokens(argv, preview_tokens, normalized, missing_keys)
        missing = normalize_missing_fields(tuple(missing_keys), normalized)

        return ResolvedCommand(
            argv=argv,
            preview=" ".join(preview_tokens),
            missing=missing,
            missing_keys=tuple(missing_keys),
            summary=scenario_summary(command, normalized, missing),
        )

    def build(self, command: str, **values: object) -> list[str]:
        return self.resolve(command, **values).argv

    def preview(self, command: str, **values: object) -> str:
        return self.resolve(command, **values).preview

    def _build_legacy(self, command: str, values: dict[str, str]) -> list[str]:
        argv = [self.eip_executable, command]
        for option, value in values.items():
            if value is None:
                continue
            option_name = _OPTION_MAP.get(option, option.replace('_', '-'))
            argv.extend([f"--{option_name}", value])
        return argv

    def _normalize_values(self, values: dict[str, object]) -> dict[str, str]:
        normalized_values: dict[str, str] = {}
        for option, value in values.items():
            if value is None:
                continue
            normalized_values[option] = str(Path(value)) if isinstance(value, Path) else str(value)
        return normalized_values

    def _append_input_tokens(
        self,
        argv: list[str],
        preview_tokens: list[str],
        values: dict[str, str],
        missing_keys: list[str],
    ) -> None:
        input_path = values.get("input_path")
        input_dir = values.get("input_dir")
        if input_path:
            argv.extend(["--input", input_path])
            preview_tokens.extend(["--input", self._quote_preview(input_path)])
            return
        if input_dir:
            argv.extend(["--input-dir", input_dir])
            preview_tokens.extend(["--input-dir", self._quote_preview(input_dir)])
            return
        missing_keys.append("input")
        preview_tokens.extend(["--input", "<input-file>"])

    def _append_segmentation_tokens(
        self,
        argv: list[str],
        preview_tokens: list[str],
        values: dict[str, str],
        missing_keys: list[str],
    ) -> None:
        seg_mode = values.get("seg_mode", "builtin-unet")
        argv.extend(["--seg-mode", seg_mode])
        preview_tokens.extend(["--seg-mode", seg_mode])
        if seg_mode == "custom-unet":
            self._append_required_value(
                argv, preview_tokens, values, "model_path", "<model-path>", missing_keys, quote=True
            )
        elif seg_mode == "existing-seg":
            self._append_required_value(
                argv, preview_tokens, values, "seg_input", "<seg-input>", missing_keys, quote=True
            )
        elif seg_mode == "nnunetv2":
            source = values.get("nnunet_source")
            if source:
                argv.extend(["--nnunet-source", source])
                preview_tokens.extend(["--nnunet-source", source])
            else:
                missing_keys.append("nnunet_source")
                preview_tokens.extend(["--nnunet-source", "<nnunet-source>"])
                return
            if source == "registry":
                self._append_required_value(
                    argv,
                    preview_tokens,
                    values,
                    "nnunet_dataset",
                    "<dataset-id>",
                    missing_keys,
                    option_name="nnunet-dataset",
                )
                self._append_required_value(
                    argv,
                    preview_tokens,
                    values,
                    "nnunet_config",
                    "<configuration>",
                    missing_keys,
                    option_name="nnunet-config",
                )
            elif source == "model-dir":
                self._append_required_value(
                    argv,
                    preview_tokens,
                    values,
                    "nnunet_model_dir",
                    "<model-dir>",
                    missing_keys,
                    option_name="nnunet-model-dir",
                    quote=True,
                )
            self._append_optional_value(argv, preview_tokens, values, "nnunet_folds", option_name="nnunet-folds")
            self._append_optional_value(
                argv, preview_tokens, values, "nnunet_checkpoint", option_name="nnunet-checkpoint", quote=True
            )

    def _append_output_tokens(
        self,
        argv: list[str],
        preview_tokens: list[str],
        values: dict[str, str],
        missing_keys: list[str],
    ) -> None:
        output = values.get("output")
        if output:
            argv.extend(["--output", output])
            preview_tokens.extend(["--output", self._quote_preview(output)])
            return
        missing_keys.append("output")
        preview_tokens.extend(["--output", "<output-dir>"])

    def _append_required_value(
        self,
        argv: list[str],
        preview_tokens: list[str],
        values: dict[str, str],
        key: str,
        placeholder: str,
        missing_keys: list[str],
        *,
        option_name: str | None = None,
        quote: bool = False,
    ) -> None:
        value = values.get(key)
        rendered_option = f"--{option_name or _OPTION_MAP.get(key, key.replace('_', '-'))}"
        if value:
            argv.extend([rendered_option, value])
            preview_tokens.extend([rendered_option, self._quote_preview(value) if quote else value])
            return
        missing_keys.append(key)
        preview_tokens.extend([rendered_option, placeholder])

    def _append_optional_value(
        self,
        argv: list[str],
        preview_tokens: list[str],
        values: dict[str, str],
        key: str,
        *,
        option_name: str | None = None,
        quote: bool = False,
    ) -> None:
        value = values.get(key)
        if not value:
            return
        rendered_option = f"--{option_name or _OPTION_MAP.get(key, key.replace('_', '-'))}"
        argv.extend([rendered_option, value])
        preview_tokens.extend([rendered_option, self._quote_preview(value) if quote else value])

    def _append_flag(
        self,
        argv: list[str],
        preview_tokens: list[str],
        values: dict[str, str],
        key: str,
        *,
        option_name: str | None = None,
    ) -> None:
        value = values.get(key, "")
        if value.lower() not in {"1", "true", "yes", "on"}:
            return
        rendered_option = f"--{option_name or _OPTION_MAP.get(key, key.replace('_', '-'))}"
        argv.append(rendered_option)
        preview_tokens.append(rendered_option)

    def _quote_preview(self, value: str) -> str:
        return f'"{value}"'

    def _uses_legacy_alias(self, command: str, values: dict[str, str]) -> bool:
        return command in {"run", "segment"} and "backend" in values and "seg_mode" not in values
