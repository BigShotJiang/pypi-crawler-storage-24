from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from scipy import ndimage as ndi

from eip.core.centroid import compute_mask_centroid


@dataclass(slots=True, frozen=True)
class ConvexFilterOptions:
    enabled: bool = False
    global_ratio: float = 1.35
    local_window: int = 5
    local_delta: float = 4.0


def _cross_structure() -> np.ndarray:
    return np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]], dtype=bool)


def build_ring_mask(mask: np.ndarray, ring_width: int) -> np.ndarray:
    binary = mask > 0
    if not np.any(binary):
        raise ValueError("mask is empty")
    expand_iterations = max(1, ring_width // 2)
    erosion_iterations = max(1, ring_width // 2)
    expanded = ndi.binary_dilation(binary, structure=_cross_structure(), iterations=expand_iterations)
    eroded = ndi.binary_erosion(binary, iterations=erosion_iterations)
    ring = expanded.astype(np.uint8) - eroded.astype(np.uint8)
    return ring > 0


def _max_radius(image: np.ndarray, center_row: int, center_col: int) -> int:
    return min(center_row, center_col, image.shape[0] - center_row - 1, image.shape[1] - center_col - 1)


def _extract_radius_curve(
    ring: np.ndarray,
    *,
    center_row: int,
    center_col: int,
    max_radius: int,
    degrees: int,
) -> np.ndarray:
    radii = np.zeros(degrees, dtype=np.float32)
    for degree in range(degrees):
        theta = math.radians(degree)
        for radius in range(max_radius, 0, -1):
            row = int(round(center_row + radius * math.cos(theta)))
            col = int(round(center_col + radius * math.sin(theta)))
            if 0 <= row < ring.shape[0] and 0 <= col < ring.shape[1] and ring[row, col]:
                radii[degree] = float(radius)
                break
    return radii


def _window_indices(index: int, window: int, size: int) -> list[int]:
    indices: list[int] = []
    for offset in range(-window, window + 1):
        if offset == 0:
            continue
        indices.append((index + offset) % size)
    return indices


def _merge_wraparound_intervals(intervals: list[tuple[int, int]], size: int) -> list[tuple[int, int]]:
    if len(intervals) > 1 and intervals[0][0] == 0 and intervals[-1][1] == size - 1:
        first_start, first_end = intervals.pop(0)
        last_start, _ = intervals.pop(-1)
        intervals.insert(0, (last_start, first_end))
    return intervals


def _find_convex_anomaly_intervals(
    radii: np.ndarray,
    *,
    global_ratio: float,
    local_window: int,
    local_delta: float,
) -> list[tuple[int, int]]:
    if radii.size == 0:
        return []

    mean_radius = float(radii.mean())
    anomaly_indices = np.flatnonzero(radii > mean_radius * global_ratio)
    if anomaly_indices.size == 0:
        return []

    candidate_intervals: list[tuple[int, int]] = []
    start = int(anomaly_indices[0])
    end = start
    for index in anomaly_indices[1:]:
        current = int(index)
        if current == end + 1:
            end = current
            continue
        candidate_intervals.append((start, end))
        start = current
        end = current
    candidate_intervals.append((start, end))
    candidate_intervals = _merge_wraparound_intervals(candidate_intervals, radii.shape[0])

    intervals: list[tuple[int, int]] = []
    size = radii.shape[0]
    for start, end in candidate_intervals:
        segment_indices = _interval_indices(start, end, size)
        if len(segment_indices) >= size:
            continue
        left_indices = [((start - offset) % size) for offset in range(1, local_window + 1)]
        right_indices = [((end + offset) % size) for offset in range(1, local_window + 1)]
        local_values = np.concatenate((radii[left_indices], radii[right_indices]))
        local_median = float(np.median(local_values))
        if float(np.max(radii[segment_indices])) > local_median + local_delta:
            intervals.append((start, end))
    return intervals


def _interval_indices(start: int, end: int, size: int) -> list[int]:
    if start <= end:
        return list(range(start, end + 1))
    return [*range(start, size), *range(0, end + 1)]


def _repair_convex_anomaly_intervals(radii: np.ndarray, intervals: list[tuple[int, int]]) -> np.ndarray:
    if not intervals:
        return radii.copy()

    repaired = radii.astype(np.float32, copy=True)
    size = repaired.shape[0]
    for start, end in intervals:
        indices = _interval_indices(start, end, size)
        if len(indices) >= size:
            return radii.copy()

        left_index = (start - 1) % size
        right_index = (end + 1) % size
        left_value = repaired[left_index]
        right_value = repaired[right_index]
        for offset, index in enumerate(indices, start=1):
            ratio = offset / (len(indices) + 1)
            repaired[index] = left_value + (right_value - left_value) * ratio
    return repaired


def _sample_polar_from_radii(
    image: np.ndarray,
    *,
    center_row: int,
    center_col: int,
    radii: np.ndarray,
    ring_width: int,
) -> np.ndarray:
    polar = np.zeros((ring_width, radii.shape[0]), dtype=image.dtype)
    for degree, radius in enumerate(radii):
        theta = math.radians(degree)
        start_radius = max(0.0, float(radius) - ring_width + 1)
        start_row = int(round(center_row + start_radius * math.cos(theta)))
        start_col = int(round(center_col + start_radius * math.sin(theta)))
        end_row = int(round(center_row + float(radius) * math.cos(theta)))
        end_col = int(round(center_col + float(radius) * math.sin(theta)))
        rows = np.rint(np.linspace(start_row, end_row, ring_width)).astype(int)
        cols = np.rint(np.linspace(start_col, end_col, ring_width)).astype(int)
        rows = np.clip(rows, 0, image.shape[0] - 1)
        cols = np.clip(cols, 0, image.shape[1] - 1)
        polar[:, degree] = image[rows, cols]
    return polar


def render_polar_patch(
    image: np.ndarray,
    mask: np.ndarray,
    ring_width: int,
    degrees: int = 360,
    convex_filter: ConvexFilterOptions | None = None,
) -> np.ndarray:
    ring = build_ring_mask(mask, ring_width)
    center_row, center_col = compute_mask_centroid(ring.astype(np.uint8))
    max_radius = _max_radius(image, center_row, center_col)
    if max_radius <= 0:
        raise ValueError("mask centroid is too close to the image boundary")

    radii = _extract_radius_curve(
        ring,
        center_row=center_row,
        center_col=center_col,
        max_radius=max_radius,
        degrees=degrees,
    )
    resolved_filter = convex_filter or ConvexFilterOptions()
    if resolved_filter.enabled:
        intervals = _find_convex_anomaly_intervals(
            radii,
            global_ratio=resolved_filter.global_ratio,
            local_window=resolved_filter.local_window,
            local_delta=resolved_filter.local_delta,
        )
        radii = _repair_convex_anomaly_intervals(radii, intervals)
    return _sample_polar_from_radii(
        image,
        center_row=center_row,
        center_col=center_col,
        radii=radii,
        ring_width=ring_width,
    )


def pad_polar_width(polar: np.ndarray, target_width: int) -> np.ndarray:
    if target_width < 360:
        raise ValueError("polar-width must be greater than or equal to 360")

    current_width = polar.shape[1]
    if target_width == current_width:
        return polar

    diff = target_width - current_width
    left_pad = diff // 2
    right_pad = diff - left_pad
    padded = np.zeros((polar.shape[0], target_width), dtype=polar.dtype)
    padded[:, left_pad : target_width - right_pad] = polar
    return padded


def to_preview_8bit(image: np.ndarray) -> np.ndarray:
    image = image.astype(np.float32)
    min_value = float(image.min())
    max_value = float(image.max())
    if max_value <= min_value:
        return np.zeros_like(image, dtype=np.uint8)
    scaled = (image - min_value) / (max_value - min_value)
    return np.rint(scaled * 255).astype(np.uint8)
