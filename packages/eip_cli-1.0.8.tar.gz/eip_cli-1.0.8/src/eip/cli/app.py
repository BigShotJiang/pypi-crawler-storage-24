from pathlib import Path

import typer

from eip.cli.doctor import run_doctor
from eip.config.storage import StorageManager
from eip.core.workflow import resolve_segmentation_options, run_pipeline, run_step
from eip.tui.app import EipApp

app = typer.Typer(name="eip", help="Edge Image Process", invoke_without_command=True)


@app.callback()
def main(
    ctx: typer.Context,
    tui: bool = typer.Option(False, "--tui", help="Launch the terminal UI."),
) -> None:
    ctx.obj = StorageManager.default().bootstrap()
    if tui:
        EipApp(storage_root=ctx.obj.root).run()
        raise typer.Exit()
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


def _handle_workflow_error(exc: ValueError) -> None:
    typer.echo(str(exc))
    raise typer.Exit(code=2) from exc


@app.command("run")
def run_command(
    input_path: str | None = typer.Option(None, "--input"),
    input_dir: str | None = typer.Option(None, "--input-dir"),
    seg_input: str | None = typer.Option(None, "--seg-input"),
    backend: str | None = typer.Option(None, "--backend"),
    seg_mode: str | None = typer.Option(None, "--seg-mode"),
    model_path: str | None = typer.Option(None, "--model-path"),
    nnunet_source: str | None = typer.Option(None, "--nnunet-source"),
    nnunet_dataset: str | None = typer.Option(None, "--nnunet-dataset"),
    nnunet_config: str | None = typer.Option(None, "--nnunet-config"),
    nnunet_model_dir: str | None = typer.Option(None, "--nnunet-model-dir"),
    nnunet_folds: str | None = typer.Option(None, "--nnunet-folds"),
    nnunet_checkpoint: str | None = typer.Option(None, "--nnunet-checkpoint"),
    ring_width: int = typer.Option(8, "--ring-width"),
    polar_width: int = typer.Option(360, "--polar-width"),
    axis: str = typer.Option("0", "--axis"),
    export_all: bool = typer.Option(False, "--all"),
    count: int | None = typer.Option(None, "--count"),
    png: bool = typer.Option(False, "--png"),
    convex_filter: bool = typer.Option(False, "--convex-filter"),
    convex_global_ratio: float = typer.Option(1.35, "--convex-global-ratio"),
    convex_local_window: int = typer.Option(5, "--convex-local-window"),
    convex_local_delta: float = typer.Option(4.0, "--convex-local-delta"),
    output: str | None = typer.Option(None, "--output"),
) -> None:
    """Run the full workflow."""
    try:
        segmentation = resolve_segmentation_options(
            seg_mode=seg_mode,
            backend=backend,
            model_path=None if model_path is None else Path(model_path),
            seg_input=None if seg_input is None else Path(seg_input),
            nnunet_source=nnunet_source,
            nnunet_dataset=nnunet_dataset,
            nnunet_config=nnunet_config,
            nnunet_model_dir=None if nnunet_model_dir is None else Path(nnunet_model_dir),
            nnunet_folds=nnunet_folds,
            nnunet_checkpoint=nnunet_checkpoint,
        )
        result = run_pipeline(
            input_path=None if input_path is None else Path(input_path),
            input_dir=None if input_dir is None else Path(input_dir),
            output=None if output is None else Path(output),
            seg_input=segmentation.seg_input,
            backend=backend,
            seg_mode=segmentation.seg_mode,
            model_path=segmentation.model_path,
            nnunet_source=segmentation.nnunet_source,
            nnunet_dataset=segmentation.nnunet_dataset,
            nnunet_config=segmentation.nnunet_config,
            nnunet_model_dir=segmentation.nnunet_model_dir,
            nnunet_folds=segmentation.nnunet_folds,
            nnunet_checkpoint=segmentation.nnunet_checkpoint,
            ring_width=ring_width,
            polar_width=polar_width,
            axis=axis,
            export_all=export_all,
            export_count=count,
            export_png=png,
            convex_filter=convex_filter,
            convex_global_ratio=convex_global_ratio,
            convex_local_window=convex_local_window,
            convex_local_delta=convex_local_delta,
        )
    except ValueError as exc:
        _handle_workflow_error(exc)
    typer.echo(result)

def _run_named_step(
    step: str,
    input_path: str | None,
    input_dir: str | None,
    output: str | None,
    *,
    data: str | None = None,
    seg_input: str | None = None,
    backend: str | None = None,
    seg_mode: str | None = None,
    model_path: str | None = None,
    nnunet_source: str | None = None,
    nnunet_dataset: str | None = None,
    nnunet_config: str | None = None,
    nnunet_model_dir: str | None = None,
    nnunet_folds: str | None = None,
    nnunet_checkpoint: str | None = None,
    ring_width: int = 8,
    polar_width: int = 360,
    axis: str = "0",
    export_all: bool = False,
    export_count: int | None = None,
    export_png: bool = False,
    convex_filter: bool = False,
    convex_global_ratio: float = 1.35,
    convex_local_window: int = 5,
    convex_local_delta: float = 4.0,
) -> None:
    try:
        result = run_step(
            step,
            input_path=None if input_path is None else Path(input_path),
            input_dir=None if input_dir is None else Path(input_dir),
            output=None if output is None else Path(output),
            data_path=None if data is None else Path(data),
            seg_input=None if seg_input is None else Path(seg_input),
            backend=backend,
            seg_mode=seg_mode,
            model_path=None if model_path is None else Path(model_path),
            nnunet_source=nnunet_source,
            nnunet_dataset=nnunet_dataset,
            nnunet_config=nnunet_config,
            nnunet_model_dir=None if nnunet_model_dir is None else Path(nnunet_model_dir),
            nnunet_folds=nnunet_folds,
            nnunet_checkpoint=nnunet_checkpoint,
            ring_width=ring_width,
            polar_width=polar_width,
            axis=axis,
            export_all=export_all,
            export_count=export_count,
            export_png=export_png,
            convex_filter=convex_filter,
            convex_global_ratio=convex_global_ratio,
            convex_local_window=convex_local_window,
            convex_local_delta=convex_local_delta,
        )
    except ValueError as exc:
        _handle_workflow_error(exc)
    typer.echo(result)


@app.command("segment")
def segment_command(
    input_path: str | None = typer.Option(None, "--input"),
    input_dir: str | None = typer.Option(None, "--input-dir"),
    seg_input: str | None = typer.Option(None, "--seg-input"),
    backend: str | None = typer.Option(None, "--backend"),
    seg_mode: str | None = typer.Option(None, "--seg-mode"),
    model_path: str | None = typer.Option(None, "--model-path"),
    nnunet_source: str | None = typer.Option(None, "--nnunet-source"),
    nnunet_dataset: str | None = typer.Option(None, "--nnunet-dataset"),
    nnunet_config: str | None = typer.Option(None, "--nnunet-config"),
    nnunet_model_dir: str | None = typer.Option(None, "--nnunet-model-dir"),
    nnunet_folds: str | None = typer.Option(None, "--nnunet-folds"),
    nnunet_checkpoint: str | None = typer.Option(None, "--nnunet-checkpoint"),
    output: str | None = typer.Option(None, "--output"),
) -> None:
    try:
        resolve_segmentation_options(
            seg_mode=seg_mode,
            backend=backend,
            model_path=None if model_path is None else Path(model_path),
            seg_input=None if seg_input is None else Path(seg_input),
            nnunet_source=nnunet_source,
            nnunet_dataset=nnunet_dataset,
            nnunet_config=nnunet_config,
            nnunet_model_dir=None if nnunet_model_dir is None else Path(nnunet_model_dir),
            nnunet_folds=nnunet_folds,
            nnunet_checkpoint=nnunet_checkpoint,
        )
    except ValueError as exc:
        _handle_workflow_error(exc)
    _run_named_step(
        "segment",
        input_path,
        input_dir,
        output,
        seg_input=seg_input,
        backend=backend,
        seg_mode=seg_mode,
        model_path=model_path,
        nnunet_source=nnunet_source,
        nnunet_dataset=nnunet_dataset,
        nnunet_config=nnunet_config,
        nnunet_model_dir=nnunet_model_dir,
        nnunet_folds=nnunet_folds,
        nnunet_checkpoint=nnunet_checkpoint,
    )


@app.command("slice")
def slice_command(
    input_path: str | None = typer.Option(None, "--input"),
    input_dir: str | None = typer.Option(None, "--input-dir"),
    output: str | None = typer.Option(None, "--output"),
) -> None:
    _run_named_step("slice", input_path, input_dir, output)


@app.command("refine")
def refine_command(
    input_path: str | None = typer.Option(None, "--input"),
    input_dir: str | None = typer.Option(None, "--input-dir"),
    output: str | None = typer.Option(None, "--output"),
) -> None:
    _run_named_step("refine", input_path, input_dir, output)


@app.command("centroid")
def centroid_command(
    input_path: str | None = typer.Option(None, "--input"),
    input_dir: str | None = typer.Option(None, "--input-dir"),
    output: str | None = typer.Option(None, "--output"),
) -> None:
    _run_named_step("centroid", input_path, input_dir, output)


@app.command("polar")
def polar_command(
    input_path: str | None = typer.Option(None, "--input"),
    input_dir: str | None = typer.Option(None, "--input-dir"),
    data: str | None = typer.Option(None, "--data"),
    ring_width: int = typer.Option(8, "--ring-width"),
    polar_width: int = typer.Option(360, "--polar-width"),
    axis: str = typer.Option("0", "--axis"),
    export_all: bool = typer.Option(False, "--all"),
    count: int | None = typer.Option(None, "--count"),
    png: bool = typer.Option(False, "--png"),
    convex_filter: bool = typer.Option(False, "--convex-filter"),
    convex_global_ratio: float = typer.Option(1.35, "--convex-global-ratio"),
    convex_local_window: int = typer.Option(5, "--convex-local-window"),
    convex_local_delta: float = typer.Option(4.0, "--convex-local-delta"),
    output: str | None = typer.Option(None, "--output"),
) -> None:
    _run_named_step(
        "polar",
        input_path,
        input_dir,
        output,
        data=data,
        ring_width=ring_width,
        polar_width=polar_width,
        axis=axis,
        export_all=export_all,
        export_count=count,
        export_png=png,
        convex_filter=convex_filter,
        convex_global_ratio=convex_global_ratio,
        convex_local_window=convex_local_window,
        convex_local_delta=convex_local_delta,
    )


@app.command("config")
def config_command() -> None:
    """Manage configuration."""
    typer.echo("config")


@app.command("logs")
def logs_command() -> None:
    """Inspect logs."""
    typer.echo("logs")


@app.command("doctor")
def doctor_command() -> None:
    """Inspect environment status."""
    typer.echo(run_doctor())
