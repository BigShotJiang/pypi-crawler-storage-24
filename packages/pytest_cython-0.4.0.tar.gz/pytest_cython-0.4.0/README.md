# Overview

[![PyPI Package latest release](https://img.shields.io/pypi/v/pytest-cython.svg?style=flat)](https://pypi.org/project/pytest-cython)
[![PyPI Package monthly downloads](https://img.shields.io/pypi/dm/pytest-cython.svg?style=flat)](https://pypi.org/project/pytest-cython)
[![PyPI Wheel](https://img.shields.io/pypi/wheel/pytest-cython.svg?style=flat)](https://pypi.org/project/pytest-cython)
[![Supported versions](https://img.shields.io/pypi/pyversions/pytest-cython.svg?style=flat)](https://pypi.org/project/pytest-cython)
[![Supported implementations](https://img.shields.io/pypi/implementation/pytest-cython.svg?style=flat)](https://pypi.org/project/pytest-cython)
[![Conda Version](https://img.shields.io/conda/vn/conda-forge/pytest-cython.svg)](https://anaconda.org/conda-forge/pytest-cython)
[![Conda Downloads](https://img.shields.io/conda/dn/conda-forge/pytest-cython.svg)](https://anaconda.org/conda-forge/pytest-cython)

[![CI Lint Status](https://github.com/lgpage/pytest-cython/actions/workflows/lint.yml/badge.svg?branch=main)](https://github.com/lgpage/pytest-cython/actions/workflows/lint.yml?query=branch%3Amain)
[![CI Test Status](https://github.com/lgpage/pytest-cython/actions/workflows/test.yml/badge.svg?branch=main)](https://github.com/lgpage/pytest-cython/actions/workflows/test.yml?query=branch%3Amain)

This [pytest](https://github.com/pytest-dev/pytest) plugin allows for the doctesting of C/C++ extension modules for
Python created through [cython](https://cython.org/).

## Installation

You can install `pytest-cython` via [pip](https://pypi.org/project/pip/) from [PyPI](https://pypi.org):

``` shell
pip install pytest-cython
```

## Usage

Basic usage:

``` shell
pytest --doctest-cython
```

You can also run the doctests for a single `.pyx` file as such:

``` shell
pytest --doctest-cython path/to/module.pyx
```

### Notes

- The pytest option `--import-mode=importlib` is not supported, though we would like it to be.
- When using the pytest option `--import-mode=prepend` with packages that are installed in a
  non-editable fashion, you must set the environment variable `PY_IGNORE_IMPORTMISMATCH=1`.

## Compatibility

The following table describes the versions of Pytest and Cython the each version of the pytest-cython plugin is
compatible with.

| Version | Pytest | Cython  |
| ------- | ------ | ------- |
 | 0.4.x  | 9      | 3       |
| 0.3.x   | 8      | 0.29, 3 |
| 0.2.x   | 6, 7   | 0.29, 3 |

## Issues

If you encounter any problems, please [file an issue](https://github.com/lgpage/pytest-cython/issues) along with a
detailed description.

## Acknowledgements

This [pytest](https://github.com/pytest-dev/pytest) plugin was generated with
[cookiecutter](https://github.com/cookiecutter/cookiecutter) along with [\@hackebrot](https://github.com/hackebrot)'s
[cookiecutter-pytest-plugin](https://github.com/pytest-dev/cookiecutter-pytest-plugin) and
[\@ionelmc](https://github.com/ionelmc)'s [cookiecutter-pylibrary](https://github.com/ionelmc/cookiecutter-pylibrary)
templates.
