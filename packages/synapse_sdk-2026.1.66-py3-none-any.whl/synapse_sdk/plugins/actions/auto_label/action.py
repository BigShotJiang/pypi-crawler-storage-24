"""Auto-label action base class for smart tool plugins."""

from __future__ import annotations

import hashlib
import logging
import os
import time
from abc import abstractmethod
from typing import TYPE_CHECKING, Any, TypeVar
from urllib.parse import urljoin

import requests
from pydantic import BaseModel, Field

from synapse_sdk.plugins.action import BaseAction
from synapse_sdk.plugins.enums import PluginCategory

P = TypeVar('P', bound=BaseModel)

if TYPE_CHECKING:
    from synapse_sdk.clients.agent import AgentClient
    from synapse_sdk.clients.backend import BackendClient

_logger = logging.getLogger(__name__)

_DEPLOY_COOLDOWN = 60  # seconds between duplicate deploy requests


class AutoLabelParams(BaseModel):
    """Base parameters for auto-label actions.

    Provides common fields used by smart tool auto-labeling workflows.
    Extend this class to add plugin-specific parameters.

    Attributes:
        plugin: Neural net plugin code to use for inference.
        version: Neural net plugin version.
        model_id: Model ID to use for inference.

    Example:
        >>> class MyAutoLabelParams(AutoLabelParams):
        ...     confidence_threshold: float = 0.5
    """

    plugin: str = Field(description='Neural net plugin code for inference')
    version: str = Field(description='Neural net plugin version')
    model_id: int | None = Field(default=None, description='Model ID for inference')
    model_config = {'extra': 'allow'}


class AutoLabelResult(BaseModel):
    """Result model for auto-label actions.

    Attributes:
        annotations: List of generated annotations.
        metadata: Optional metadata from the labeling process.
    """

    annotations: list[dict[str, Any]] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class AutoLabelProgressCategories:
    """Standard progress category names for auto-label workflows.

    Use these constants with set_progress() to track multi-phase labeling:
        - INPUT_TRANSFORM: Transforming smart tool input to model format
        - INFERENCE: Running model inference
        - OUTPUT_TRANSFORM: Transforming model output to annotation format

    Example:
        >>> self.set_progress(1, 3, self.progress.INPUT_TRANSFORM)
        >>> self.set_progress(2, 3, self.progress.INFERENCE)
        >>> self.set_progress(3, 3, self.progress.OUTPUT_TRANSFORM)
    """

    INPUT_TRANSFORM: str = 'input_transform'
    INFERENCE: str = 'inference'
    OUTPUT_TRANSFORM: str = 'output_transform'


class BaseAutoLabelAction(BaseAction[P]):
    """Base class for smart tool auto-label actions.

    Provides the handle_input/handle_output pattern for transforming data
    between smart tool format and model format. Automatically handles
    inference invocation via the neural net plugin.

    Plugin developers only need to:
    1. Override handle_input() to transform smart tool input to model input
    2. Override handle_output() to transform model output to annotation format

    The SDK automatically handles:
    - Model inference via the neural net plugin
    - Progress tracking and logging
    - Error handling

    Attributes:
        category: Plugin category (defaults to SMART_TOOL).
        progress: Standard progress category names.

    Example (minimal):
        >>> class MyAutoLabel(BaseAutoLabelAction[MyParams]):
        ...     def handle_input(self, input_data: dict) -> dict:
        ...         # Transform smart tool input to model input
        ...         return {'image': input_data['file_url']}
        ...
        ...     def handle_output(self, output_data: dict) -> dict:
        ...         # Transform model output to annotations
        ...         return {'annotations': output_data['predictions']}

    Example (with custom params):
        >>> class MyAutoLabelParams(AutoLabelParams):
        ...     confidence_threshold: float = 0.5
        ...
        >>> class MyAutoLabel(BaseAutoLabelAction[MyAutoLabelParams]):
        ...     def handle_input(self, input_data: dict) -> dict:
        ...         return {
        ...             'image': input_data['file_url'],
        ...             'threshold': self.params.confidence_threshold,
        ...         }
        ...
        ...     def handle_output(self, output_data: dict) -> dict:
        ...         return {'annotations': output_data['predictions']}
    """

    category = PluginCategory.SMART_TOOL
    progress = AutoLabelProgressCategories()

    @property
    def client(self) -> BackendClient:
        """Backend client from context.

        Returns:
            BackendClient instance.

        Raises:
            RuntimeError: If no client in context.
        """
        if self.ctx.client is None:
            raise RuntimeError(
                'No client in context. Either provide a client via RuntimeContext '
                'or override run_inference() with custom inference logic.'
            )
        return self.ctx.client

    @property
    def agent_client(self) -> AgentClient:
        """Local agent client from context.

        Used for on-agent calls (e.g. inference) to avoid round-tripping
        through the backend.

        Returns:
            AgentClient instance.

        Raises:
            RuntimeError: If no agent client in context.
        """
        if self.ctx.agent_client is None:
            raise RuntimeError(
                'No agent client in context. Ensure SYNAPSE_AGENT_URL and '
                'SYNAPSE_AGENT_TOKEN are set, or override run_inference().'
            )
        return self.ctx.agent_client

    @abstractmethod
    def handle_input(self, input_data: dict[str, Any]) -> dict[str, Any]:
        """Transform smart tool input to model input format.

        Override this method to convert the input data from smart tool
        format to the format expected by your model.

        Args:
            input_data: Input data from smart tool (includes params).

        Returns:
            Transformed data ready for model inference.

        Example:
            >>> def handle_input(self, input_data: dict) -> dict:
            ...     return {
            ...         'image': input_data['file_url'],
            ...         'model_id': input_data.get('model_id'),
            ...     }
        """
        ...

    @abstractmethod
    def handle_output(self, output_data: dict[str, Any]) -> dict[str, Any]:
        """Transform model output to smart tool annotation format.

        Override this method to convert the model output to the
        annotation format expected by the smart tool.

        Args:
            output_data: Output data from model inference.

        Returns:
            Transformed data with annotations for smart tool.

        Example:
            >>> def handle_output(self, output_data: dict) -> dict:
            ...     annotations = []
            ...     for pred in output_data.get('predictions', []):
            ...         annotations.append({
            ...             'type': 'bbox',
            ...             'coordinates': pred['box'],
            ...             'label': pred['class'],
            ...             'confidence': pred['score'],
            ...         })
            ...     return {'annotations': annotations}
        """
        ...

    def run_inference(self, model_input: dict[str, Any]) -> dict[str, Any]:
        """Run inference via direct HTTP call to the deployed Ray Serve endpoint.

        Checks whether the neural net plugin is deployed on Ray Serve,
        then calls the endpoint directly (bypassing the agent) for minimal
        latency.  If the plugin is not deployed, sends a fire-and-forget
        deploy request and raises RuntimeError so the caller can retry.

        Override for custom inference logic (e.g., external API, local model).

        Args:
            model_input: Input data for model inference.  This dict is sent
                as the JSON body of the HTTP POST to Ray Serve.

        Returns:
            Model inference output.

        Raises:
            RuntimeError: If the plugin is not deployed or inference fails.
            ValueError: If required params are missing.
        """
        params = self.params
        plugin_code = getattr(params, 'plugin', None)
        version = getattr(params, 'version', None)

        if not plugin_code or not version:
            raise ValueError(
                'params.plugin and params.version are required for inference. '
                'Set these in your params model or override run_inference().'
            )

        app_name = f'{plugin_code}@{version}'

        # Step 1: Check if the neural net plugin is deployed on Ray Serve
        if not self._is_serve_deployed(app_name):
            _logger.info(
                'Neural net plugin %s is not deployed. Sending deploy request (fire-and-forget)...',
                app_name,
            )
            self._fire_deploy_request(plugin_code, version)
            raise RuntimeError(
                f'Neural net plugin {app_name} is not deployed. '
                'A deployment request has been sent. Please retry shortly.'
            )

        # Step 2: Call Ray Serve directly
        try:
            result = self._call_serve(app_name, model_input)
            _logger.info('run_inference OK for %s (direct serve call)', app_name)
            return result
        except Exception as e:
            if self._is_connection_error(e):
                _logger.info(
                    'Neural net plugin %s serve endpoint unreachable. Sending deploy request (fire-and-forget)...',
                    app_name,
                )
                self._fire_deploy_request(plugin_code, version)
                raise RuntimeError(
                    f'Neural net plugin {app_name} is not deployed. '
                    'A deployment request has been sent. Please retry shortly.'
                )
            raise RuntimeError(
                f'Inference failed for {app_name}: {e}. Override run_inference() to implement custom inference.'
            ) from e

    # -----------------------------------------------------------------
    # Direct Ray Serve call helpers
    # -----------------------------------------------------------------

    def _is_serve_deployed(self, app_name: str) -> bool:
        """Check if a Ray Serve application is deployed by querying routes.

        Calls ``GET {RAY_SERVE_ADDRESS}/-/routes`` and checks if the
        expected route prefix (MD5 hash of app_name) is present.

        Args:
            app_name: Application name in ``plugin@version`` format.

        Returns:
            True if the serve app route is registered.
        """
        checksum = hashlib.md5(app_name.encode('utf-8')).hexdigest()
        route = f'/{checksum}'
        ray_serve_address = os.environ.get('RAY_SERVE_ADDRESS', '')

        if not ray_serve_address:
            _logger.warning('RAY_SERVE_ADDRESS not set, cannot check serve deployment')
            return False

        try:
            resp = requests.get(urljoin(ray_serve_address, '/-/routes'), timeout=5)
            resp.raise_for_status()
            deployed = route in resp.json()
            _logger.debug('_is_serve_deployed(%s): route=%s, deployed=%s', app_name, route, deployed)
            return deployed
        except Exception as e:
            _logger.warning('Failed to check serve routes for %s: %s', app_name, e)
            return False

    def _call_serve(self, app_name: str, model_input: dict[str, Any]) -> dict[str, Any]:
        """Call a Ray Serve endpoint directly via HTTP.

        Replicates the agent's ``run_serve_action()`` pop-based param
        preprocessing: extracts ``model``, ``method``, and ``json`` keys
        from model_input before sending the remainder as the HTTP body.

        Args:
            app_name: Application name in ``plugin@version`` format.
            model_input: Data from handle_input().  May contain ``method``
                (HTTP method), ``json`` (body payload), and ``model``
                (extracted for JWT header, not sent in body).

        Returns:
            Parsed JSON response from the serve endpoint.
        """
        from synapse_sdk.plugins.actions.inference.serve import create_serve_multiplexed_model_id

        checksum = hashlib.md5(app_name.encode('utf-8')).hexdigest()
        ray_serve_address = os.environ.get('RAY_SERVE_ADDRESS', '')
        url = urljoin(ray_serve_address, f'/{checksum}/')

        # Replicate agent's run_serve_action() pop-based preprocessing:
        # 1. Pop 'model' for JWT token (not sent in body)
        # 2. Pop 'method' for HTTP method (default POST)
        # 3. Pop 'json' as body payload, or use remaining params
        params = dict(model_input)
        model_id = params.pop('model', None)
        if model_id is None:
            model_id = getattr(self.params, 'model_id', None) or getattr(self.params, 'model', None)
        http_method = str(params.pop('method', 'post')).lower()
        body = params.pop('json', params)

        # Build model multiplexing header (JWT token)
        headers: dict[str, str] = {}
        if model_id is not None:
            backend_url = os.environ.get('SYNAPSE_PLUGIN_RUN_HOST', '') or os.environ.get('SYNAPSE_HOST', '')
            token = os.environ.get('SYNAPSE_ACCESS_TOKEN', '')
            tenant = os.environ.get('SYNAPSE_PLUGIN_RUN_TENANT')
            headers['serve_multiplexed_model_id'] = create_serve_multiplexed_model_id(
                model_id=model_id,
                token=token,
                backend_url=backend_url,
                tenant=tenant,
            )

        response = requests.request(http_method, url, json=body, headers=headers, timeout=300)
        response.raise_for_status()
        return response.json()

    @staticmethod
    def _is_connection_error(error: Exception) -> bool:
        """Check if the error is a connection-level failure."""
        return isinstance(error, (requests.ConnectionError, requests.Timeout))

    def _fire_deploy_request(self, plugin_code: str, version: str) -> None:
        """Send a deploy request for the neural net plugin (fire-and-forget).

        Uses file-based locking so that concurrent actors don't send duplicate
        deploy requests.  The method returns immediately after sending (or
        skipping) the request — it does NOT wait for deploy completion.

        Args:
            plugin_code: Neural net plugin code (e.g. 'segment-anything-2').
            version: Plugin version (e.g. '2.0.0').
        """
        import fcntl
        import os

        lookup = f'{plugin_code}@{version}'

        # File-based coordination to prevent duplicate deploy requests.
        lock_dir = '/tmp/synapse_auto_deploy'
        os.makedirs(lock_dir, exist_ok=True)
        safe_name = lookup.replace('@', '_').replace('/', '_')
        lock_file = os.path.join(lock_dir, f'{safe_name}.lock')
        deploy_marker = os.path.join(lock_dir, f'{safe_name}.deploying')

        # Cooldown: skip if a deploy request was already sent recently (within 60s).
        should_deploy = False

        with open(lock_file, 'w') as lf:
            fcntl.flock(lf, fcntl.LOCK_EX)

            if os.path.exists(deploy_marker):
                file_age = time.time() - os.path.getmtime(deploy_marker)
                if file_age < _DEPLOY_COOLDOWN:
                    _logger.info(
                        'Deploy request for %s already sent %.0fs ago. Skipping.',
                        lookup,
                        file_age,
                    )
                else:
                    should_deploy = True
            else:
                should_deploy = True

            if should_deploy:
                # Touch the marker BEFORE releasing the lock so other actors
                # see it immediately.
                with open(deploy_marker, 'w') as mf:
                    mf.write(lookup)

            # Lock released when 'with' block exits

        if not should_deploy:
            return

        _logger.info('Sending deploy request for %s (fire-and-forget)', lookup)

        import requests as req

        ac = self.agent_client
        headers = {'Authorization': ac.agent_token}
        if ac.user_token:
            headers['SYNAPSE-User'] = f'Token {ac.user_token}'
        if ac.tenant:
            headers['SYNAPSE-Tenant'] = f'Token {ac.tenant}'

        deploy_url = f'{ac.base_url.rstrip("/")}/plugin_releases/{lookup}/run/'
        deploy_payload = {
            'action': 'deployment',
            'params': {},
        }

        try:
            resp = req.post(
                deploy_url,
                json=deploy_payload,
                headers=headers,
                timeout=(5, 30),
            )
            resp.raise_for_status()
            _logger.info('Deploy request accepted for %s (status=%s)', lookup, resp.status_code)
        except Exception as e:
            # Clean up marker so next request can retry
            try:
                os.unlink(deploy_marker)
            except OSError:
                pass
            _logger.error('Deploy request failed for %s: %s', lookup, e)

    def execute(self) -> dict[str, Any]:
        """Execute the auto-label workflow.

        Orchestrates the handle_input -> inference -> handle_output flow.
        Override for completely custom execution logic.

        Returns:
            Auto-label result with annotations.
        """
        # Get params as dict for input handling
        params_dict = self.params.model_dump() if hasattr(self.params, 'model_dump') else dict(self.params)

        # Step 1: Transform input
        self.set_progress(1, 3, self.progress.INPUT_TRANSFORM)
        model_input = self.handle_input(params_dict)

        if model_input is None:
            model_input = params_dict

        # Step 2: Run inference
        self.set_progress(2, 3, self.progress.INFERENCE)
        model_output = self.run_inference(model_input)

        # Step 3: Transform output
        self.set_progress(3, 3, self.progress.OUTPUT_TRANSFORM)
        result = self.handle_output(model_output)

        if result is None:
            result = model_output

        return result


__all__ = [
    'BaseAutoLabelAction',
    'AutoLabelParams',
    'AutoLabelProgressCategories',
    'AutoLabelResult',
]
