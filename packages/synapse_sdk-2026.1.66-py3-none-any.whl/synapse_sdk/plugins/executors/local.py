from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from synapse_sdk.loggers import ConsoleLogger
from synapse_sdk.plugins.action import NoResult, validate_result
from synapse_sdk.plugins.context import PluginEnvironment, RuntimeContext
from synapse_sdk.plugins.errors import ExecutionError
from synapse_sdk.utils.auth import create_backend_client

if TYPE_CHECKING:
    from synapse_sdk.plugins.action import BaseAction


def _print_result(result: Any) -> None:
    """Print serialized result to stdout for local mode visibility.

    Args:
        result: Action result (dict, BaseModel, or other).
    """
    from pydantic import BaseModel

    if isinstance(result, BaseModel):
        result_data = result.model_dump(mode='json')
    elif isinstance(result, dict):
        result_data = result
    else:
        result_data = {'result': result}

    print(f'Result: {json.dumps(result_data, default=str)}', flush=True)


class LocalExecutor:
    """Execute actions in the current process.

    Best for development and testing. Uses ConsoleLogger by default.

    Example:
        >>> executor = LocalExecutor()
        >>> result = executor.execute(TrainAction, {'epochs': 10})

        >>> # With language setting
        >>> executor = LocalExecutor(language='ko')
        >>> result = executor.execute(TrainAction, {'epochs': 10})
    """

    def __init__(
        self,
        env: PluginEnvironment | dict[str, Any] | None = None,
        job_id: str | None = None,
        language: str | None = None,
    ) -> None:
        """Initialize executor.

        Args:
            env: Environment config. If None, loads from os.environ.
            job_id: Optional job identifier.
            language: Optional language code (ISO 639-1) for log messages.
                If not set, uses SYNAPSE_LANGUAGE env var or defaults to 'en'.
        """
        if env is None:
            self._env = PluginEnvironment.from_environ()
        elif isinstance(env, dict):
            self._env = PluginEnvironment(env)
        else:
            self._env = env
        self._job_id = job_id
        self._language = language
        self._client = create_backend_client()

    def execute(
        self,
        action_cls: type[BaseAction],
        params: dict[str, Any],
        **kwargs: Any,
    ) -> Any:
        """Execute action synchronously in current process.

        Args:
            action_cls: BaseAction subclass to execute.
            params: Parameters dict to validate and pass.
            **kwargs: Ignored (for protocol compatibility).

        Returns:
            Action result from execute().

        Raises:
            ValidationError: If params fail validation.
            ExecutionError: If action raises an exception.
        """
        del kwargs  # Unused, for protocol compatibility

        # Build context
        logger = ConsoleLogger()
        ctx = RuntimeContext(
            logger=logger,
            env=self._env,
            job_id=self._job_id,
            client=self._client,
            language=self._language,
        )

        try:
            result = action_cls.dispatch(params, ctx)
        except Exception as e:
            logger.finish()
            raise ExecutionError(f'Action execution failed: {e}') from e

        # Validate result with warning-only mode
        result_model = getattr(action_cls, 'result_model', NoResult)
        if result_model is not NoResult:
            result = validate_result(result, result_model, logger)

        logger.finish()
        _print_result(result)
        return result


__all__ = ['LocalExecutor']
