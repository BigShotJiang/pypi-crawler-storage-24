"""Video utilities for file validation and processing."""

from __future__ import annotations

from .vfr_check import VideoAnalysisError, VideoFrameRateError, is_variable_frame_rate, validate_constant_frame_rate

__all__ = [
    'is_variable_frame_rate',
    'validate_constant_frame_rate',
    'VideoAnalysisError',
    'VideoFrameRateError',
]
