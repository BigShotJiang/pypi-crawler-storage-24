"""Variable Frame Rate (VFR) detection for video files.

This module provides utilities to detect if a video file uses variable frame rate (VFR)
encoding, which can cause synchronization issues in video processing pipelines.
"""

from __future__ import annotations

import json
import logging
import subprocess
from pathlib import Path
from typing import Union

logger = logging.getLogger(__name__)


class VideoAnalysisError(Exception):
    """Exception raised when video analysis fails (corrupted file, ffprobe failure, etc.).

    This error indicates that the video file could not be analyzed, not that VFR was detected.
    Examples: missing moov atom, corrupted file, ffprobe timeout, insufficient frames.
    """

    pass


class VideoFrameRateError(Exception):
    """Exception raised when variable frame rate (VFR) is detected.

    This error is raised only when VFR is actually detected in a video file,
    not for analysis failures which use VideoAnalysisError instead.
    """

    pass


def is_variable_frame_rate(
    video_path: Union[str, Path],
    sample_frames: int = 200,
    variance_threshold: float = 0.001,
) -> tuple[bool, dict[str, float]]:
    """Check if a video file uses variable frame rate (VFR).

    This function analyzes the presentation timestamps (PTS) of video frames to detect
    if the frame rate varies throughout the video. VFR videos have inconsistent time
    intervals between frames, which can cause issues in video processing pipelines.

    Detection method:
    1. Extract PTS (Presentation TimeStamp) for sample frames using ffprobe
    2. Calculate time deltas between consecutive frames
    3. Compute variance of these deltas
    4. If variance exceeds threshold, classify as VFR

    Args:
        video_path: Path to the video file to check
        sample_frames: Number of frames to sample from the start of the video.
            Default is 200 frames. More frames = more accurate but slower.
        variance_threshold: Maximum allowed variance in frame deltas (in seconds).
            Default is 0.001 (1ms). Lower = stricter detection.

    Returns:
        tuple[bool, dict[str, float]]: A tuple containing:
            - is_vfr: True if video uses variable frame rate, False if constant
            - metadata: Dictionary with detection details:
                - 'variance': Variance of frame time deltas
                - 'mean_delta': Mean time between frames (in seconds)
                - 'fps_estimated': Estimated FPS from mean delta
                - 'frames_analyzed': Number of frames analyzed

    Raises:
        VideoAnalysisError: If ffprobe fails or video cannot be analyzed
            (corrupted file, timeout, insufficient frames, etc.)
        FileNotFoundError: If video file does not exist

    Example:
        >>> is_vfr, metadata = is_variable_frame_rate('video.mp4')
        >>> if is_vfr:
        ...     print(f"VFR detected! Variance: {metadata['variance']:.6f}")
        ... else:
        ...     print(f"CFR video. Estimated FPS: {metadata['fps_estimated']:.2f}")
    """
    video_path = Path(video_path)

    if not video_path.exists():
        raise FileNotFoundError(f'Video file not found: {video_path}')

    try:
        # Use ffprobe to extract frame timestamps
        # -select_streams v:0: Only analyze first video stream
        # -show_entries frame=pkt_pts_time: Get presentation timestamp for each frame
        # -read_intervals %+#N: Read only first N frames for performance
        # -of json: Output as JSON for easy parsing
        cmd = [
            'ffprobe',
            '-v',
            'error',  # Only show errors
            '-select_streams',
            'v:0',  # First video stream
            '-show_entries',
            'frame=pkt_pts_time',  # Get presentation timestamp
            '-read_intervals',
            f'%+#{sample_frames}',  # Read first N frames
            '-of',
            'json',  # JSON output
            str(video_path),
        ]

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            check=True,
            timeout=30,  # 30 second timeout
        )

        # Parse JSON output
        data = json.loads(result.stdout)
        frames = data.get('frames', [])

        if len(frames) < 10:
            raise VideoAnalysisError(
                f'Insufficient frames for analysis. Got {len(frames)} frames, need at least 10. '
                f'Video may be too short or corrupted.'
            )

        # Extract presentation timestamps
        timestamps = []
        for frame in frames:
            pts_time = frame.get('pkt_pts_time')
            if pts_time is not None:
                try:
                    timestamps.append(float(pts_time))
                except (ValueError, TypeError):
                    logger.warning(f'Invalid PTS value: {pts_time}')
                    continue

        if len(timestamps) < 10:
            raise VideoAnalysisError(
                f'Insufficient valid timestamps for analysis. Got {len(timestamps)} timestamps, need at least 10.'
            )

        # Calculate time deltas between consecutive frames
        deltas = [timestamps[i + 1] - timestamps[i] for i in range(len(timestamps) - 1)]

        # Filter out zero or negative deltas (shouldn't happen in valid videos)
        deltas = [d for d in deltas if d > 0]

        if len(deltas) < 5:
            raise VideoAnalysisError(
                f'Insufficient valid frame deltas for analysis. Got {len(deltas)} deltas, need at least 5.'
            )

        # Calculate statistics
        mean_delta = sum(deltas) / len(deltas)
        variance = sum((d - mean_delta) ** 2 for d in deltas) / len(deltas)
        fps_estimated = 1.0 / mean_delta if mean_delta > 0 else 0.0

        metadata = {
            'variance': variance,
            'mean_delta': mean_delta,
            'fps_estimated': fps_estimated,
            'frames_analyzed': len(timestamps),
        }

        # Determine if VFR based on variance threshold
        is_vfr = variance > variance_threshold

        logger.debug(
            f'VFR check for {video_path.name}: is_vfr={is_vfr}, '
            f'variance={variance:.6f}, mean_delta={mean_delta:.6f}s, '
            f'fps={fps_estimated:.2f}, frames={len(timestamps)}'
        )

        return is_vfr, metadata

    except subprocess.CalledProcessError as e:
        stderr = e.stderr if e.stderr else 'No error output'
        raise VideoAnalysisError(f'ffprobe failed to analyze video: {stderr}') from e

    except subprocess.TimeoutExpired as e:
        raise VideoAnalysisError(f'ffprobe timed out after 30 seconds analyzing video: {video_path}') from e

    except json.JSONDecodeError as e:
        raise VideoAnalysisError(f'Failed to parse ffprobe JSON output: {e}') from e

    except Exception as e:
        raise VideoAnalysisError(f'Unexpected error during VFR detection: {e}') from e


def validate_constant_frame_rate(
    video_path: Union[str, Path],
    sample_frames: int = 200,
    variance_threshold: float = 0.001,
) -> None:
    """Validate that a video file uses constant frame rate (CFR).

    Raises an exception if the video uses variable frame rate (VFR).
    This is a convenience function for validation workflows.

    Args:
        video_path: Path to the video file to validate
        sample_frames: Number of frames to sample from the start of the video
        variance_threshold: Maximum allowed variance in frame deltas (in seconds)

    Raises:
        VideoFrameRateError: If video uses VFR (variable frame rate)
        VideoAnalysisError: If video cannot be analyzed (corrupted, timeout, etc.)
        FileNotFoundError: If video file does not exist

    Example:
        >>> try:
        ...     validate_constant_frame_rate('video.mp4')
        ...     print("Video is CFR - OK to upload")
        ... except VideoFrameRateError as e:
        ...     print(f"Video rejected: {e}")
    """
    is_vfr, metadata = is_variable_frame_rate(video_path, sample_frames, variance_threshold)

    if is_vfr:
        raise VideoFrameRateError(
            f'Variable frame rate (VFR) video detected and not allowed. '
            f'Video: {Path(video_path).name}, '
            f'Variance: {metadata["variance"]:.6f}s² (threshold: {variance_threshold}s²), '
            f'Estimated FPS: {metadata["fps_estimated"]:.2f}. '
            f'Please convert to constant frame rate (CFR) before uploading. '
            f'You can use: ffmpeg -i input.mp4 -c:v libx264 -r 30 -vsync cfr output.mp4'
        )


__all__ = [
    'is_variable_frame_rate',
    'validate_constant_frame_rate',
    'VideoAnalysisError',
    'VideoFrameRateError',
]
