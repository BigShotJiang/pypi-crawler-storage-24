# Video Utilities

This module provides utilities for validating and processing video files during upload.

## Variable Frame Rate (VFR) Detection

VFR (Variable Frame Rate) videos are automatically detected and rejected during upload to prevent synchronization issues in video processing pipelines.

### Features

- Automatic VFR detection using FFmpeg probe
- Configurable variance threshold for detection sensitivity
- Configurable frame sampling for performance optimization
- Detailed error messages with conversion suggestions

### Usage

```python
from synapse_sdk.utils.video import validate_constant_frame_rate, is_variable_frame_rate, VideoFrameRateError

# Check if a video uses VFR
is_vfr, metadata = is_variable_frame_rate('video.mp4')
if is_vfr:
    print(f"VFR detected! Variance: {metadata['variance']:.6f}")
    print(f"Estimated FPS: {metadata['fps_estimated']:.2f}")
else:
    print("CFR video - OK for upload")

# Validate video (raises exception if VFR)
try:
    validate_constant_frame_rate('video.mp4')
    print("Video validation passed")
except VideoFrameRateError as e:
    print(f"Validation failed: {e}")
```

### How It Works

1. Extracts presentation timestamps (PTS) from video frames using FFmpeg
2. Calculates time deltas between consecutive frames
3. Computes variance of frame deltas
4. If variance exceeds threshold, classifies as VFR

### Configuration

- `sample_frames`: Number of frames to analyze (default: 200)
  - More frames = more accurate but slower
  - 200 frames is typically sufficient for detection

- `variance_threshold`: Maximum allowed variance in seconds² (default: 0.001)
  - Lower threshold = stricter detection
  - 0.001 (1ms) catches most VFR videos while allowing minor encoding jitter

### Converting VFR to CFR

If you have a VFR video, convert it to CFR using FFmpeg:

```bash
ffmpeg -i input.mp4 -c:v libx264 -r 30 -vsync cfr output.mp4
```

- `-r 30`: Set frame rate to 30fps (adjust as needed)
- `-vsync cfr`: Force constant frame rate
- `-c:v libx264`: Use H.264 codec (widely compatible)

### Integration with Upload Workflow

VFR validation is automatically integrated into the upload workflow via `ValidateFilesStep`:

```python
from synapse_sdk.plugins.actions.upload.steps import ValidateFilesStep

# VFR checking is enabled by default
step = ValidateFilesStep(
    check_vfr=True,  # Enable VFR validation (default)
    vfr_sample_frames=200,  # Frames to sample
    vfr_variance_threshold=0.001,  # Variance threshold
)

# Disable VFR checking if needed
step = ValidateFilesStep(check_vfr=False)
```

### Supported Video Formats

VFR detection is performed on files with these extensions:
- `.mp4`
- `.avi`
- `.mov`
- `.mkv`
- `.webm`
- `.flv`
- `.wmv`

### Error Handling

- `VideoFrameRateError`: Raised when VFR is detected or analysis fails
- `FileNotFoundError`: Raised when video file doesn't exist
- Timeout protection: FFmpeg probe has 30-second timeout

### Performance

- Typical analysis time: 1-3 seconds per video
- Only first N frames are analyzed (configurable)
- No temporary files created
- Low memory footprint

### Requirements

- FFmpeg with `ffprobe` must be installed and available in PATH
- Python 3.10+
