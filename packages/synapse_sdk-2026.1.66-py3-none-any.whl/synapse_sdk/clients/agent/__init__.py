from __future__ import annotations

from typing import TYPE_CHECKING, Any

from synapse_sdk.clients.agent.async_ray import AsyncRayClientMixin
from synapse_sdk.clients.agent.container import ContainerClientMixin
from synapse_sdk.clients.agent.plugin import PluginClientMixin
from synapse_sdk.clients.agent.ray import RayClientMixin
from synapse_sdk.clients.agent.system import SystemClientMixin
from synapse_sdk.clients.base import AsyncBaseClient, BaseClient
from synapse_sdk.exceptions import ClientError, ClientTimeoutError

if TYPE_CHECKING:
    from synapse_sdk.clients.agent.long_poll import LongPollHandler


class AgentClient(ContainerClientMixin, PluginClientMixin, RayClientMixin, SystemClientMixin, BaseClient):
    """Sync client for synapse-agent API."""

    name = 'Agent'

    def __init__(
        self,
        base_url: str | None,
        agent_token: str,
        *,
        user_token: str | None = None,
        tenant: str | None = None,
        timeout: dict[str, int] | None = None,
        long_poll_handler: LongPollHandler | None = None,
    ):
        """Initialize the agent client.

        Args:
            base_url: Agent API base URL. Can be None when using long-poll mode.
            agent_token: Agent authentication token.
            user_token: Optional user token for impersonation.
            tenant: Optional tenant identifier.
            timeout: Request timeout dict with 'connect' and 'read' keys.
            long_poll_handler: Optional handler for long-poll mode. When set,
                all requests are routed through Redis instead of direct HTTP.
        """
        super().__init__(base_url or '', timeout=timeout or {'connect': 3, 'read': 10})
        self.agent_token = agent_token
        self.user_token = user_token
        self.tenant = tenant
        self.long_poll_handler = long_poll_handler

    def _get_headers(self) -> dict[str, str]:
        """Return authentication headers."""
        headers = {'Authorization': self.agent_token}
        if self.user_token:
            headers['SYNAPSE-User'] = f'Token {self.user_token}'
        if self.tenant:
            headers['SYNAPSE-Tenant'] = f'Token {self.tenant}'
        return headers

    def _request(self, method: str, path: str, **kwargs: Any) -> dict | str | None:
        """Route requests through long-poll or direct HTTP."""
        if self.long_poll_handler:
            return self._request_long_poll(method, path, **kwargs)
        return super()._request(method, path, **kwargs)

    def _request_long_poll(self, method: str, path: str, **kwargs: Any) -> dict | str | None:
        """Send request via Redis long-poll instead of direct HTTP."""
        if kwargs.get('files'):
            raise ClientError('File upload is not supported in long-poll mode')

        headers = self._get_headers()
        headers['Content-Type'] = 'application/json'

        request_id = self.long_poll_handler.set_request({
            'method': method,
            'path': path,
            'headers': headers,
            **kwargs,
        })
        try:
            response = self.long_poll_handler.get_response(request_id)
        except TimeoutError:
            raise ClientTimeoutError(f'{self.name} is not responding')

        status = response.get('status', 200)
        if 400 <= status < 600:
            raise ClientError(response.get('reason', f'Agent returned {status}'))

        return response.get('data')

    def health_check(self) -> dict:
        """Check agent health."""
        path = 'health/'
        return self._get(path)


class AsyncAgentClient(AsyncRayClientMixin, AsyncBaseClient):
    """Async client for synapse-agent API.

    Provides async/await interface for all agent operations including
    WebSocket and HTTP streaming for job log tailing.

    Example:
        >>> async with AsyncAgentClient(base_url, agent_token) as client:
        ...     jobs = await client.list_jobs()
        ...     async for line in client.tail_job_logs('job-123'):
        ...         print(line)
    """

    name = 'Agent'

    def __init__(
        self,
        base_url: str,
        agent_token: str,
        *,
        user_token: str | None = None,
        tenant: str | None = None,
        timeout: float | None = None,
    ):
        """Initialize the async agent client.

        Args:
            base_url: Agent API base URL.
            agent_token: Agent authentication token.
            user_token: Optional user token for impersonation.
            tenant: Optional tenant identifier.
            timeout: Request timeout in seconds.
        """
        super().__init__(base_url, timeout=timeout)
        self.agent_token = agent_token
        self.user_token = user_token
        self.tenant = tenant

    def _get_headers(self) -> dict[str, str]:
        """Return authentication headers."""
        headers = {'Authorization': self.agent_token}
        if self.user_token:
            headers['SYNAPSE-User'] = f'Token {self.user_token}'
        if self.tenant:
            headers['SYNAPSE-Tenant'] = f'Token {self.tenant}'
        return headers

    async def health_check(self) -> dict:
        """Check agent health."""
        path = 'health/'
        return await self._get(path)


__all__ = ['AgentClient', 'AsyncAgentClient']
