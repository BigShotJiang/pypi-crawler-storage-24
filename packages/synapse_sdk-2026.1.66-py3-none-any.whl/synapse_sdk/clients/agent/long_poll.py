"""Long-poll handler protocol for agent client."""

from __future__ import annotations

from typing import Any, Protocol


class LongPollHandler(Protocol):
    """Protocol for long-poll handlers.

    Implementations must provide set_request/get_response for enqueuing
    requests and blocking for responses via a message broker (e.g. Redis).
    """

    def set_request(self, request: dict[str, Any]) -> str:
        """Enqueue a request and return its unique ID."""
        ...

    def get_response(self, request_id: str, timeout_seconds: int | None = None) -> dict[str, Any]:
        """Block until a response is available for the given request ID.

        Raises:
            TimeoutError: If no response arrives within the timeout.
        """
        ...
