from __future__ import annotations

from inquirer_textual.InquirerApp import InquirerApp
from inquirer_textual.widgets.InquirerPath import InquirerPath, PathType


def test_snapshot(snap_compare):
    app = InquirerApp()
    app.widget = InquirerPath('Output directory:')

    assert snap_compare(app)


def test_snapshot_with_default_value(snap_compare):
    app = InquirerApp()
    app.widget = InquirerPath('Output directory:', exists=True, path_type=PathType.DIRECTORY, default='/var/log')

    assert snap_compare(app)


def test_validation_failure(snap_compare):
    widget = InquirerPath('Output directory:', exists=True)
    app = InquirerApp()
    app.widget = widget

    async def run_before(pilot) -> None:
        await pilot.press(*[c for c in "/should-not-exist.txt"])
        await pilot.press("enter")

    assert snap_compare(app, run_before=run_before)

async def test_named():
    widget = InquirerPath('Output directory:', name="dir")
    app = InquirerApp()
    app.widget = widget

    async with app.run_test() as pilot:
        await pilot.press(*[c for c in "/should-not-exist.txt"])
        await pilot.press("enter")
    result = app._return_value

    assert result.value == "/should-not-exist.txt"
    assert result.command == 'select'
    assert result.name == 'dir'
