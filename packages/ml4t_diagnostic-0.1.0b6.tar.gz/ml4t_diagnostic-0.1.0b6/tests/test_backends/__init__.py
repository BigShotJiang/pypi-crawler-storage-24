"""Tests for backend adapters."""
