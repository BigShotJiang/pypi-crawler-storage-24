from .domain.base import UXTGModel

__all__ = ["UXTGModel"]
