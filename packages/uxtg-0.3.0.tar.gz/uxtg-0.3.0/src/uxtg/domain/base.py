from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class UXTGModel(BaseModel):
    model_config = ConfigDict(
        validate_assignment=True,
        extra="forbid",
        frozen=False,
        populate_by_name=True,
    )
