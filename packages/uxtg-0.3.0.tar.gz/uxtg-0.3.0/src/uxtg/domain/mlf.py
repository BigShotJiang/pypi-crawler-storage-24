from __future__ import annotations

from pathlib import Path
from typing import Iterator

from .base import UXTGModel
from .models import TextGrid


class MLF(UXTGModel):
    grids: tuple[TextGrid, ...] = ()

    def __iter__(self) -> Iterator[TextGrid]:  # type: ignore[override]
        return iter(self.grids)

    def __len__(self) -> int:
        return len(self.grids)

    def __getitem__(self, index: int) -> TextGrid:
        return self.grids[index]

    @classmethod
    def from_string(
        cls,
        text: str,
        samplerate: float = 10e6,
        round_digits: int = 5,
    ) -> "MLF":
        from ..codecs.mlf import MLFReader

        return MLFReader(samplerate=samplerate, round_digits=round_digits).read_text(text)

    @classmethod
    def from_file(
        cls,
        path: str | Path,
        samplerate: float = 10e6,
        round_digits: int = 5,
    ) -> "MLF":
        from ..codecs.mlf import MLFReader

        return MLFReader(samplerate=samplerate, round_digits=round_digits).read_file(path)

    def write(self, prefix: str | Path = "") -> int:
        from ..codecs.mlf import MLFWriter

        return MLFWriter().write_textgrids(self, prefix)
