from __future__ import annotations

from ..documents.json_document import (
    JsonInterval,
    JsonIntervalTier,
    JsonPoint,
    JsonPointTier,
    TextGridJsonDocument,
)
from ..domain.models import Interval, IntervalTier, Point, PointTier, TextGrid


def textgrid_to_json_document(textgrid: TextGrid) -> TextGridJsonDocument:
    x_min, x_max = textgrid.bounds()
    tiers: list[JsonIntervalTier | JsonPointTier] = []
    for tier_index, tier in enumerate(textgrid, start=1):
        tier_min, tier_max = tier.bounds()
        if isinstance(tier, IntervalTier):
            tiers.append(
                JsonIntervalTier(
                    index=tier_index,
                    name=tier.name,
                    x_min=tier_min,
                    x_max=tier_max,
                    interval_count=len(tier),
                    intervals=tuple(
                        JsonInterval(
                            index=item_index,
                            x_min=interval.min_time,
                            x_max=interval.max_time,
                            text=interval.mark,
                        )
                        for item_index, interval in enumerate(tier, start=1)
                    ),
                )
            )
        else:
            tiers.append(
                JsonPointTier(
                    index=tier_index,
                    name=tier.name,
                    x_min=tier_min,
                    x_max=tier_max,
                    point_count=len(tier),
                    points=tuple(
                        JsonPoint(index=item_index, number=point.time, mark=point.mark)
                        for item_index, point in enumerate(tier, start=1)
                    ),
                )
            )
    return TextGridJsonDocument(
        x_min=x_min,
        x_max=x_max,
        tier_count=len(textgrid),
        tiers=tuple(tiers),
    )


def json_document_to_textgrid(document: TextGridJsonDocument) -> TextGrid:
    tiers: list[IntervalTier | PointTier] = []
    for tier in document.tiers:
        if isinstance(tier, JsonIntervalTier):
            tiers.append(
                IntervalTier(
                    name=tier.name,
                    min_time=tier.x_min,
                    max_time=tier.x_max,
                    intervals=tuple(
                        Interval(
                            min_time=interval.x_min,
                            max_time=interval.x_max,
                            mark=interval.text,
                        )
                        for interval in tier.intervals
                    ),
                )
            )
        else:
            tiers.append(
                PointTier(
                    name=tier.name,
                    min_time=tier.x_min,
                    max_time=tier.x_max,
                    points=tuple(
                        Point(time=point.number, mark=point.mark) for point in tier.points
                    ),
                )
            )
    return TextGrid(
        file_type=document.file_type,
        object_class=document.object_class,
        min_time=document.x_min,
        max_time=document.x_max,
        tiers=tuple(tiers),
    )
