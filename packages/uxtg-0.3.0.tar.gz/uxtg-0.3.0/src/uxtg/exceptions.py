from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


class UXTGError(Exception):
    """Base exception for the uxtg package."""


@dataclass(slots=True)
class ErrorContext:
    format_name: str | None = None
    phase: str | None = None
    line_number: int | None = None
    path: Path | None = None
    snippet: str | None = None


class ParseError(UXTGError):
    def __init__(self, message: str, *, context: ErrorContext | None = None):
        super().__init__(message)
        self.message = message
        self.context = context or ErrorContext()

    def __str__(self) -> str:
        parts = [self.message]
        if self.context.format_name:
            parts.append(f"format={self.context.format_name}")
        if self.context.phase:
            parts.append(f"phase={self.context.phase}")
        if self.context.line_number is not None:
            parts.append(f"line={self.context.line_number}")
        if self.context.path is not None:
            parts.append(f"path={self.context.path}")
        if self.context.snippet:
            parts.append(f"context={self.context.snippet!r}")
        return " | ".join(parts)


class SerializationError(UXTGError):
    pass


class UnsupportedFormatError(UXTGError):
    pass


class DomainValidationError(UXTGError):
    pass


TextGridError = ParseError
