import threading
from pathlib import Path

from wasmtime import Engine, Linker, Module, Store, WasiConfig

_WASM_PATH = Path(__file__).parent / "_vt100.wasm"

_engine = Engine()
_module = Module.from_file(_engine, str(_WASM_PATH))


def _unpack_result(packed: int) -> tuple[int, int]:
    ptr = (packed >> 32) & 0xFFFFFFFF
    length = packed & 0xFFFFFFFF
    return ptr, length


class _Runtime:
    def __init__(self) -> None:
        self._store = Store(_engine)
        config = WasiConfig()
        self._store.set_wasi(config)
        linker = Linker(_engine)
        linker.define_wasi()
        instance = linker.instantiate(self._store, _module)
        exports = instance.exports(self._store)
        self._memory = exports["memory"]
        self._alloc_fn = exports["wasm_alloc"]
        self._dealloc_fn = exports["wasm_dealloc"]
        self._create_fn = exports["create"]
        self._destroy_fn = exports["destroy"]
        self._process_fn = exports["process"]
        self._resize_fn = exports["resize"]
        self._screen_contents_fn = exports["screen_contents"]
        self._screen_contents_formatted_fn = exports["screen_contents_formatted"]
        self._screen_cells_fn = exports["screen_cells"]
        self._screen_cells_diff_fn = exports["screen_cells_diff"]
        self._snapshot_fn = exports["snapshot"]
        self._restore_fn = exports["restore"]

    def _write_bytes(self, data: bytes) -> tuple[int, int]:
        size = len(data)
        if size == 0:
            return 0, 0
        ptr = self._alloc_fn(self._store, size)
        if ptr == 0:
            raise MemoryError(f"WASM allocation failed for {size} bytes")
        self._memory.write(self._store, data, ptr)
        return ptr, size

    def _read_result(self, packed: int) -> bytes:
        ptr, length = _unpack_result(packed)
        if ptr == 0 or length == 0:
            return b""
        result = self._memory.read(self._store, ptr, ptr + length)
        self._dealloc_fn(self._store, ptr, length)
        return bytes(result)

    def create(self, rows: int, cols: int) -> int:
        return self._create_fn(self._store, rows, cols)

    def destroy(self, handle: int) -> None:
        self._destroy_fn(self._store, handle)

    def process(self, handle: int, data: bytes) -> None:
        d_ptr, d_len = self._write_bytes(data)
        self._process_fn(self._store, handle, d_ptr, d_len)
        if d_ptr:
            self._dealloc_fn(self._store, d_ptr, d_len)

    def resize(self, handle: int, rows: int, cols: int) -> None:
        self._resize_fn(self._store, handle, rows, cols)

    def screen_contents(self, handle: int) -> str:
        packed = self._screen_contents_fn(self._store, handle)
        return self._read_result(packed).decode("utf-8")

    def screen_contents_formatted(self, handle: int) -> bytes:
        packed = self._screen_contents_formatted_fn(self._store, handle)
        return self._read_result(packed)

    def screen_cells(self, handle: int) -> bytes:
        packed = self._screen_cells_fn(self._store, handle)
        return self._read_result(packed)

    def screen_cells_diff(self, handle: int) -> bytes:
        packed = self._screen_cells_diff_fn(self._store, handle)
        return self._read_result(packed)

    def snapshot(self, handle: int) -> bytes:
        packed = self._snapshot_fn(self._store, handle)
        return self._read_result(packed)

    def restore(self, data: bytes) -> int:
        d_ptr, d_len = self._write_bytes(data)
        handle = self._restore_fn(self._store, d_ptr, d_len)
        if d_ptr:
            self._dealloc_fn(self._store, d_ptr, d_len)
        return handle


_local = threading.local()


def _get_runtime() -> _Runtime:
    try:
        return _local.runtime
    except AttributeError:
        _local.runtime = _Runtime()
        return _local.runtime


class Screen:
    def __init__(self, rows: int, cols: int):
        if rows <= 0 or cols <= 0:
            raise ValueError(f"rows and cols must be positive, got rows={rows}, cols={cols}")
        self._runtime = _get_runtime()
        self._handle = self._runtime.create(rows, cols)

    def process(self, data: bytes) -> None:
        self._runtime.process(self._handle, data)

    def resize(self, rows: int, cols: int) -> None:
        if rows <= 0 or cols <= 0:
            raise ValueError(f"rows and cols must be positive, got rows={rows}, cols={cols}")
        self._runtime.resize(self._handle, rows, cols)

    def contents(self) -> str:
        return self._runtime.screen_contents(self._handle)

    def contents_formatted(self) -> bytes:
        return self._runtime.screen_contents_formatted(self._handle)

    def cells(self) -> bytes:
        return self._runtime.screen_cells(self._handle)

    def cells_diff(self) -> bytes:
        return self._runtime.screen_cells_diff(self._handle)

    def snapshot(self) -> bytes:
        return self._runtime.snapshot(self._handle)

    @classmethod
    def restore(cls, data: bytes) -> "Screen":
        screen = object.__new__(cls)
        screen._runtime = _get_runtime()
        screen._handle = screen._runtime.restore(data)
        if screen._handle == 0:
            raise ValueError("Invalid snapshot data")
        return screen

    def close(self) -> None:
        if self._handle:
            self._runtime.destroy(self._handle)
            self._handle = 0

    def __del__(self):
        self.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


__all__ = ["Screen"]
