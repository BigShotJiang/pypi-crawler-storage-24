"""
tests/test_cli.py — Unit tests for mcpx CLI logic.
"""
from __future__ import annotations

import json
import shutil
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

sys.path.insert(0, str(Path(__file__).parent.parent))
from mcpx import cli as C


# ── Fixtures ───────────────────────────────────────────────────────────────────

FAKE_PKG = {
    "name": "testpkg",
    "version": "1.0.0",
    "display_name": "Test Package",
    "description": "A test package for unit tests.",
    "author": "tester",
    "homepage": "https://example.com",
    "tags": ["test"],
    "pricing": {"model": "free", "billing": "none"},
    "install": {
        "type": "http",
        "manifest_url": "https://example.com/api/mcp",
        "base_url": "https://example.com",
        "auth": {
            "type": "api_key",
            "header": "X-Test-Key",
            "env_var": "TEST_API_KEY"
        }
    },
    "tools": [
        {
            "name": "get_data",
            "description": "Fetches data from the service.",
            "auth_required": False,
            "method": "GET",
            "path": "/api/data"
        },
        {
            "name": "post_item",
            "description": "Posts an item to the service.",
            "auth_required": True,
            "method": "POST",
            "path": "/api/items"
        }
    ],
    "verified": True,
    "published_at": "2026-03-09",
    "installs": 0
}


# ── Meta / installed.json ──────────────────────────────────────────────────────

class TestMeta:
    def setup_method(self):
        self.tmp = Path(tempfile.mkdtemp())
        self._orig_meta = C.META_FILE
        C.META_FILE = self.tmp / "installed.json"

    def teardown_method(self):
        C.META_FILE = self._orig_meta
        shutil.rmtree(self.tmp)

    def test_load_meta_empty_when_no_file(self):
        assert C._load_meta() == {}

    def test_save_and_load_roundtrip(self):
        data = {"mypkg": {"version": "1.0.0", "display_name": "My Pkg"}}
        C._save_meta(data)
        assert C._load_meta() == data

    def test_save_creates_parent_dirs(self):
        C.META_FILE = self.tmp / "deep" / "nested" / "installed.json"
        C._save_meta({"x": {}})
        assert C.META_FILE.exists()

    def test_save_is_atomic(self):
        """Uses temp file — no partial writes."""
        C._save_meta({"pkg": {"version": "2.0.0"}})
        assert C.META_FILE.exists()
        assert not (self.tmp / "installed.tmp").exists()


# ── Claude settings.json ───────────────────────────────────────────────────────

class TestClaudeSettings:
    def setup_method(self):
        self.tmp = Path(tempfile.mkdtemp())
        self._orig = C.CLAUDE_SETTINGS
        C.CLAUDE_SETTINGS = self.tmp / "settings.json"

    def teardown_method(self):
        C.CLAUDE_SETTINGS = self._orig
        shutil.rmtree(self.tmp)

    def test_add_to_claude_creates_file(self):
        server = self.tmp / "server.py"
        C._add_to_claude("mypkg", server)
        assert C.CLAUDE_SETTINGS.exists()

    def test_add_to_claude_adds_mcp_server(self):
        server = self.tmp / "server.py"
        C._add_to_claude("mypkg", server)
        settings = json.loads(C.CLAUDE_SETTINGS.read_text())
        assert "mypkg" in settings["mcpServers"]
        assert settings["mcpServers"]["mypkg"]["command"] == "python"

    def test_add_to_claude_preserves_existing(self):
        C.CLAUDE_SETTINGS.write_text(json.dumps({
            "mcpServers": {"existing": {"command": "python", "args": ["/old/server.py"]}},
            "other_setting": True
        }))
        C._add_to_claude("newpkg", self.tmp / "new.py")
        settings = json.loads(C.CLAUDE_SETTINGS.read_text())
        assert "existing" in settings["mcpServers"]
        assert "newpkg" in settings["mcpServers"]
        assert settings["other_setting"] is True

    def test_remove_from_claude(self):
        C.CLAUDE_SETTINGS.write_text(json.dumps({
            "mcpServers": {
                "pkg1": {"command": "python"},
                "pkg2": {"command": "python"}
            }
        }))
        C._remove_from_claude("pkg1")
        settings = json.loads(C.CLAUDE_SETTINGS.read_text())
        assert "pkg1" not in settings["mcpServers"]
        assert "pkg2" in settings["mcpServers"]

    def test_remove_nonexistent_does_not_raise(self):
        C._remove_from_claude("doesnotexist")  # should not raise

    def test_add_multiple_packages(self):
        for name in ("alpha", "beta", "gamma"):
            C._add_to_claude(name, self.tmp / f"{name}.py")
        settings = json.loads(C.CLAUDE_SETTINGS.read_text())
        assert set(settings["mcpServers"].keys()) == {"alpha", "beta", "gamma"}


# ── MCP server generation ──────────────────────────────────────────────────────

class TestServerGeneration:
    def setup_method(self):
        self.tmp = Path(tempfile.mkdtemp())

    def teardown_method(self):
        shutil.rmtree(self.tmp)

    def test_generate_server_creates_file(self):
        dest = self.tmp / "testpkg" / "server.py"
        C._generate_server(FAKE_PKG, dest)
        assert dest.exists()

    def test_generated_server_is_valid_python(self):
        dest = self.tmp / "testpkg" / "server.py"
        C._generate_server(FAKE_PKG, dest)
        code = dest.read_text(encoding="utf-8")
        compile(code, str(dest), "exec")  # should not raise

    def test_generated_server_has_package_name(self):
        dest = self.tmp / "testpkg" / "server.py"
        C._generate_server(FAKE_PKG, dest)
        code = dest.read_text(encoding="utf-8")
        assert "testpkg" in code

    def test_generated_server_has_base_url(self):
        dest = self.tmp / "testpkg" / "server.py"
        C._generate_server(FAKE_PKG, dest)
        code = dest.read_text(encoding="utf-8")
        assert "https://example.com" in code

    def test_generated_server_has_auth_header(self):
        dest = self.tmp / "testpkg" / "server.py"
        C._generate_server(FAKE_PKG, dest)
        code = dest.read_text(encoding="utf-8")
        assert "X-Test-Key" in code

    def test_generated_server_has_auth_env_var(self):
        dest = self.tmp / "testpkg" / "server.py"
        C._generate_server(FAKE_PKG, dest)
        code = dest.read_text(encoding="utf-8")
        assert "TEST_API_KEY" in code

    def test_generated_server_has_mcp_tools(self):
        dest = self.tmp / "testpkg" / "server.py"
        C._generate_server(FAKE_PKG, dest)
        code = dest.read_text(encoding="utf-8")
        assert "get_data" in code
        assert "post_item" in code

    def test_generated_server_has_jsonrpc(self):
        dest = self.tmp / "testpkg" / "server.py"
        C._generate_server(FAKE_PKG, dest)
        code = dest.read_text(encoding="utf-8")
        assert "jsonrpc" in code
        assert "tools/list" in code
        assert "tools/call" in code

    def test_generate_server_creates_parent_dirs(self):
        dest = self.tmp / "a" / "b" / "c" / "server.py"
        C._generate_server(FAKE_PKG, dest)
        assert dest.exists()


# ── Dispatch generation ────────────────────────────────────────────────────────

class TestDispatchGeneration:
    def test_get_tool_generates_http_get(self):
        tools = [{"name": "get_data", "method": "GET", "path": "/api/data", "auth_required": False}]
        code = C._generate_dispatch(tools, "https://example.com")
        assert "get_data" in code
        assert "_http_get" in code

    def test_post_tool_generates_http_post(self):
        tools = [{"name": "post_item", "method": "POST", "path": "/api/items", "auth_required": True}]
        code = C._generate_dispatch(tools, "https://example.com")
        assert "post_item" in code
        assert "_http_post" in code
        assert "auth=True" in code

    def test_unauthenticated_post(self):
        tools = [{"name": "free_post", "method": "POST", "path": "/api/free", "auth_required": False}]
        code = C._generate_dispatch(tools, "https://example.com")
        assert "auth=False" in code

    def test_multiple_tools_all_present(self):
        tools = [
            {"name": "tool_a", "method": "GET", "path": "/a", "auth_required": False},
            {"name": "tool_b", "method": "POST", "path": "/b", "auth_required": True},
            {"name": "tool_c", "method": "GET", "path": "/c", "auth_required": False},
        ]
        code = C._generate_dispatch(tools, "https://example.com")
        assert "tool_a" in code
        assert "tool_b" in code
        assert "tool_c" in code

    def test_empty_tools(self):
        code = C._generate_dispatch([], "https://example.com")
        assert code == "    pass"

    def test_default_method_is_get(self):
        """Tools without explicit method should default to GET."""
        tools = [{"name": "mytool", "path": "/api/x", "auth_required": False}]
        code = C._generate_dispatch(tools, "https://example.com")
        assert "_http_get" in code


# ── Live API integration ───────────────────────────────────────────────────────

class TestLiveAPI:
    """Tests against the live mcpx.shop registry. Skip if offline."""

    def _get(self, params: dict | None = None) -> dict:
        try:
            return C._api_get(params)
        except SystemExit:
            import pytest
            pytest.skip("Registry unreachable")

    def test_live_registry_returns_packages(self):
        data = self._get()
        assert "packages" in data
        assert data["total"] >= 2

    def test_live_search_marketing(self):
        data = self._get({"q": "marketing"})
        assert "results" in data
        assert any(p["name"] == "acquire" for p in data["results"])

    def test_live_search_visibility(self):
        data = self._get({"q": "visibility"})
        assert any(p["name"] == "signal" for p in data["results"])

    def test_live_get_acquire(self):
        pkg = self._get({"name": "acquire"})
        assert pkg["name"] == "acquire"
        assert pkg["verified"] is True

    def test_live_get_signal(self):
        pkg = self._get({"name": "signal"})
        assert pkg["name"] == "signal"
        assert pkg["verified"] is True

    def test_live_404_for_unknown(self):
        import urllib.error
        try:
            C._api_get({"name": "doesnotexist999"})
            assert False, "Should have raised SystemExit"
        except SystemExit:
            pass  # expected — 404 triggers sys.exit(1)

    def test_live_registry_version(self):
        data = self._get()
        assert data["version"] == "1.0.0"
