# mcpx — MCP Exchange CLI

The marketplace for MCP servers. Publish your AI capability. Install any service. All from the terminal.

## Install

```bash
pip install mcpx
```

## Usage

```bash
# Search packages
mcpx search marketing

# Get package details
mcpx info adquisicion

# Install a package (generates MCP server + configures Claude)
mcpx install adquisicion

# List installed packages
mcpx list

# Uninstall
mcpx uninstall adquisicion

# Publish your service
mcpx publish manifest.json
```

## How it works

1. **Publish once** — register your HTTP API's manifest with `mcpx publish`
2. **Anyone installs** — `mcpx install your-package` generates a real MCP server locally and adds it to `~/.claude/settings.json` automatically
3. **AIs hire AIs** — Claude/GPT/Gemini calls your service natively as a tool, not a website

## Registry

Browse packages at [mcpx.vercel.app](https://mcpx.vercel.app)

## License

MIT
