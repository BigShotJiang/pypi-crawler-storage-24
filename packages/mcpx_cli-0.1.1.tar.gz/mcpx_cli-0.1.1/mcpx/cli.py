"""
mcpx — MCP Exchange CLI

Commands:
  search <query>       Search packages in the registry
  info <name>          Show package details
  install <name>       Install an MCP package (generates server + configures Claude)
  list                 List installed packages
  publish <manifest>   Submit a package for review
  uninstall <name>     Remove an installed package
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

REGISTRY_URL    = "https://mcpx.shop/api/registry"
INSTALL_DIR     = Path.home() / ".mcpx" / "servers"
META_FILE       = Path.home() / ".mcpx" / "installed.json"
CLAUDE_SETTINGS = Path.home() / ".claude" / "settings.json"

# ── ANSI helpers ───────────────────────────────────────────────────────────────
def _c(code: str, s: str) -> str: return f"\033[{code}m{s}\033[0m"
def _green(s: str)  -> str: return _c("32", s)
def _blue(s: str)   -> str: return _c("34", s)
def _cyan(s: str)   -> str: return _c("36", s)
def _yellow(s: str) -> str: return _c("33", s)
def _red(s: str)    -> str: return _c("31", s)
def _bold(s: str)   -> str: return _c("1",  s)
def _dim(s: str)    -> str: return _c("2",  s)
def _ul(s: str)     -> str: return _c("4",  s)

# ── UI primitives ──────────────────────────────────────────────────────────────
def _hr(width: int = 52) -> None:
    print(_dim("─" * width))

def _step(n: int, total: int, label: str, done: bool = False, note: str = "") -> None:
    """Print a numbered step line."""
    marker = _green("✓") if done else _dim("○")
    num    = _dim(f"[{n}/{total}]")
    suffix = f"  {_dim(note)}" if note else ""
    print(f"  {num} {label:<30}{marker}{suffix}")

def _badge(text: str, color_fn=_dim) -> str:
    return color_fn(f" {text} ")

def _tag_list(tags: list[str], limit: int = 5) -> str:
    shown = tags[:limit]
    rest  = len(tags) - limit
    out   = "  ".join(_dim(f"#{t}") for t in shown)
    if rest > 0:
        out += _dim(f"  +{rest}")
    return out

def _wrap(text: str, width: int = 60, indent: str = "") -> str:
    words  = text.split()
    lines:  list[str] = []
    line   = indent
    for w in words:
        if len(line) + len(w) + 1 > width and line.strip():
            lines.append(line.rstrip())
            line = indent + w + " "
        else:
            line += w + " "
    if line.strip():
        lines.append(line.rstrip())
    return "\n".join(lines)

# ── Registry API ───────────────────────────────────────────────────────────────
def _api_get(params: dict | None = None) -> dict:
    url = REGISTRY_URL
    if params:
        url += "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": "mcpx-cli/0.1.0"})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        body = json.loads(e.read())
        print(_red(f"\n  ✗ Error {e.code}: {body.get('error', str(e))}\n"))
        sys.exit(1)
    except Exception as e:
        print(_red(f"\n  ✗ Cannot reach registry: {e}\n"))
        sys.exit(1)


def _api_post(data: dict) -> dict:
    payload = json.dumps(data).encode()
    req = urllib.request.Request(
        REGISTRY_URL, data=payload,
        headers={"Content-Type": "application/json", "User-Agent": "mcpx-cli/0.1.0"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        body = json.loads(e.read())
        print(_red(f"\n  ✗ Error {e.code}: {body.get('error', str(e))}\n"))
        sys.exit(1)
    except Exception as e:
        print(_red(f"\n  ✗ Cannot reach registry: {e}\n"))
        sys.exit(1)


# ── Installed packages metadata ────────────────────────────────────────────────
def _load_meta() -> dict:
    if META_FILE.exists():
        return json.loads(META_FILE.read_text())
    return {}


def _save_meta(meta: dict) -> None:
    META_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = META_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(meta, indent=2))
    shutil.move(str(tmp), str(META_FILE))


# ── Claude settings.json ───────────────────────────────────────────────────────
def _load_claude_settings() -> dict:
    if CLAUDE_SETTINGS.exists():
        try:
            return json.loads(CLAUDE_SETTINGS.read_text())
        except Exception:
            return {}
    return {}


def _save_claude_settings(settings: dict) -> None:
    CLAUDE_SETTINGS.parent.mkdir(parents=True, exist_ok=True)
    tmp = CLAUDE_SETTINGS.with_suffix(".tmp")
    tmp.write_text(json.dumps(settings, indent=2))
    shutil.move(str(tmp), str(CLAUDE_SETTINGS))


def _add_to_claude(name: str, server_path: Path) -> bool:
    settings = _load_claude_settings()
    if "mcpServers" not in settings:
        settings["mcpServers"] = {}
    settings["mcpServers"][name] = {
        "command": "python",
        "args": [str(server_path)],
    }
    try:
        _save_claude_settings(settings)
        return True
    except Exception as e:
        print(_yellow(f"  ⚠ Could not update Claude settings: {e}"))
        return False


def _remove_from_claude(name: str) -> None:
    settings = _load_claude_settings()
    if "mcpServers" in settings and name in settings["mcpServers"]:
        del settings["mcpServers"][name]
        _save_claude_settings(settings)


# ── MCP server generator ───────────────────────────────────────────────────────
_SERVER_TEMPLATE = '''\
"""
Auto-generated MCP server for {display_name}
Generated by mcpx v0.1.0 — do not edit manually.
"""
from __future__ import annotations

import json
import os
import sys
import urllib.parse
import urllib.request

# Package metadata
PACKAGE_NAME = {name!r}
BASE_URL      = {base_url!r}
MANIFEST_URL  = {manifest_url!r}
AUTH_HEADER   = {auth_header!r}
AUTH_ENV_VAR  = {auth_env_var!r}

def _get_api_key() -> str:
    key = os.environ.get(AUTH_ENV_VAR, "")
    if not key:
        print(f"Warning: {{AUTH_ENV_VAR}} not set. Authenticated tools will fail.", file=sys.stderr)
    return key

def _http_get(path: str, params: dict | None = None) -> dict:
    url = BASE_URL + path
    if params:
        url += "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={{"User-Agent": "mcpx-server/0.1.0"}})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read())

def _http_post(path: str, data: dict, auth: bool = False) -> dict:
    payload = json.dumps(data).encode()
    headers = {{"Content-Type": "application/json", "User-Agent": "mcpx-server/0.1.0"}}
    if auth:
        headers[AUTH_HEADER] = _get_api_key()
    req = urllib.request.Request(BASE_URL + path, data=payload, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read())

# ── MCP protocol (stdio) ───────────────────────────────────────────────────────
TOOLS = {tools_json}

def _handle_call(tool_name: str, args: dict) -> dict:
{tool_dispatch}
    return {{"error": f"Unknown tool: {{tool_name}}"}}

def main() -> None:
    import sys, json
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue

        msg_id = msg.get("id")
        method  = msg.get("method", "")

        if method == "initialize":
            resp = {{
                "jsonrpc": "2.0", "id": msg_id,
                "result": {{
                    "protocolVersion": "2024-11-05",
                    "capabilities": {{"tools": {{}}}},
                    "serverInfo": {{"name": PACKAGE_NAME, "version": "1.0.0"}},
                }}
            }}
        elif method == "tools/list":
            resp = {{"jsonrpc": "2.0", "id": msg_id, "result": {{"tools": TOOLS}}}}
        elif method == "tools/call":
            params    = msg.get("params", {{}})
            tool_name = params.get("name", "")
            tool_args = params.get("arguments", {{}})
            try:
                result = _handle_call(tool_name, tool_args)
                resp = {{
                    "jsonrpc": "2.0", "id": msg_id,
                    "result": {{"content": [{{"type": "text", "text": json.dumps(result, ensure_ascii=False)}}]}}
                }}
            except Exception as e:
                resp = {{
                    "jsonrpc": "2.0", "id": msg_id,
                    "error": {{"code": -32000, "message": str(e)}}
                }}
        elif method == "notifications/initialized":
            continue
        else:
            resp = {{"jsonrpc": "2.0", "id": msg_id, "error": {{"code": -32601, "message": "Method not found"}}}}

        print(json.dumps(resp), flush=True)

if __name__ == "__main__":
    main()
'''


def _generate_dispatch(tools: list[dict], base_url: str) -> str:
    lines = []
    for tool in tools:
        name     = tool["name"]
        auth_req = tool.get("auth_required", False)
        method   = tool.get("method", "GET").upper()
        path     = tool.get("path", f"/api/{name.replace('_', '-')}")
        lines.append(f'    if tool_name == {name!r}:')
        if method == "POST":
            lines.append(f'        return _http_post({path!r}, args, auth={auth_req})')
        else:
            lines.append(f'        return _http_get({path!r}, args or None)')
    return "\n".join(lines) if lines else '    pass'


def _generate_server(pkg: dict, dest: Path) -> None:
    install   = pkg.get("install", {})
    base_url  = install.get("base_url", "")
    manifest  = install.get("manifest_url", "")
    auth      = install.get("auth", {})
    tools_raw = pkg.get("tools", [])

    mcp_tools = []
    for t in tools_raw:
        mcp_tools.append({
            "name":        t["name"],
            "description": t.get("description", ""),
            "inputSchema": {
                "type":       "object",
                "properties": t.get("parameters", {}),
                "required":   t.get("required", []),
            }
        })

    dispatch = _generate_dispatch(tools_raw, base_url)
    code = _SERVER_TEMPLATE.format(
        display_name = pkg.get("display_name", pkg["name"]),
        name         = pkg["name"],
        base_url     = base_url,
        manifest_url = manifest,
        auth_header  = auth.get("header", "Authorization"),
        auth_env_var = auth.get("env_var", "API_KEY"),
        tools_json   = json.dumps(mcp_tools, indent=4),
        tool_dispatch= dispatch,
    )
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(code, encoding="utf-8")


# ── Commands ───────────────────────────────────────────────────────────────────
def cmd_search(args: argparse.Namespace) -> None:
    q    = " ".join(args.query)
    data = _api_get({"q": q})
    results = data.get("results", [])
    total   = data.get("total", 0)

    print()
    if total == 0:
        print(f"  {_dim('No results for')} {_bold(q)}\n")
        return

    print(f"  {_cyan('⬡')} {_bold('mcpx')} · {total} result{'s' if total != 1 else ''} for {_bold(q)}\n")
    _hr()

    for pkg in results:
        verified = f"  {_green('✓')}" if pkg.get("verified") else ""
        pricing  = pkg.get("pricing", {})
        price    = ""
        if pricing.get("price_usd"):
            price = _dim(f"  ${pricing['price_usd']:.0f}/{pricing.get('unit', 'use')}")
        print(f"  {_bold(_blue(pkg['name']))}  {_dim('v' + pkg['version'])}{verified}{price}")
        desc = pkg.get("description", "")[:72]
        if len(pkg.get("description", "")) > 72:
            desc += "…"
        print(f"  {_dim(desc)}")
        print(f"  {_dim('mcpx install ' + pkg['name'])}")
        print()

    _hr()
    print()


def cmd_info(args: argparse.Namespace) -> None:
    pkg  = _api_get({"name": args.name})
    meta = _load_meta()

    installed = _green("installed") if args.name in meta else _dim("not installed")
    verified  = f"  {_green('✓ verified')}" if pkg.get("verified") else ""
    pricing   = pkg.get("pricing", {})
    tools     = pkg.get("tools", [])

    print()
    _hr()
    print(f"  {_bold(pkg['display_name'])}  {_dim('v' + pkg['version'])}  [{installed}]{verified}")
    _hr()
    print()
    print(_wrap(pkg.get("description", ""), width=60, indent="  "))
    print()

    # Details grid
    rows = [
        ("author",  pkg.get("author", "—")),
        ("homepage", pkg.get("homepage", "—")),
    ]
    if pkg.get("tags"):
        rows.append(("tags", "  ".join(_dim(f"#{t}") for t in pkg["tags"][:6])))
    if pricing:
        price_str = ""
        if pricing.get("price_usd"):
            price_str = f"${pricing['price_usd']:.2f}/{pricing.get('unit', 'use')}  "
        price_str += _dim(pricing.get("model", ""))
        if pricing.get("note"):
            price_str += f"  {_dim(pricing['note'])}"
        rows.append(("pricing", price_str))

    for label, value in rows:
        print(f"  {_dim(label):<12}{value}")

    if tools:
        print()
        print(f"  {_dim('tools')}  {_dim(str(len(tools)))}")
        for t in tools:
            lock = f"  {_yellow('[auth]')}" if t.get("auth_required") else ""
            print(f"    {_cyan('●')} {_bold(t['name'])}{lock}")
            if t.get("description"):
                print(f"      {_dim(t['description'][:70])}")

    print()
    print(f"  {_dim('install')}    mcpx install {pkg['name']}")
    print()
    _hr()
    print()


def cmd_install(args: argparse.Namespace) -> None:
    name = args.name
    meta = _load_meta()

    print()
    print(f"  {_cyan('⬡')} {_bold('mcpx install')} {_bold(name)}\n")

    STEPS = 4

    # 1. Fetch manifest
    print(f"  {_dim('[1/' + str(STEPS) + ']')} Fetching manifest…", end=" ", flush=True)
    pkg = _api_get({"name": name})
    print(_green("✓"))

    # Check already installed
    if name in meta:
        print()
        print(f"  {_yellow('⚠')} {name} is already installed  ({_dim('use mcpx uninstall to remove')})")
        print()

    # 2. Generate server
    server_path = INSTALL_DIR / name / "server.py"
    print(f"  {_dim('[2/' + str(STEPS) + ']')} Generating MCP server…", end=" ", flush=True)
    _generate_server(pkg, server_path)
    short = str(server_path).replace(str(Path.home()), "~")
    print(f"{_green('✓')}  {_dim(short)}")

    # 3. Patch Claude settings
    print(f"  {_dim('[3/' + str(STEPS) + ']')} Patching ~/.claude/settings.json…", end=" ", flush=True)
    added = _add_to_claude(name, server_path)
    print(_green("✓") if added else _yellow("skipped"))

    # 4. Save metadata
    print(f"  {_dim('[4/' + str(STEPS) + ']')} Saving metadata…", end=" ", flush=True)
    meta[name] = {
        "version":      pkg.get("version", "unknown"),
        "display_name": pkg.get("display_name", name),
        "server_path":  str(server_path),
        "auth_env_var": pkg.get("install", {}).get("auth", {}).get("env_var", ""),
    }
    _save_meta(meta)
    print(_green("✓"))

    print()
    _hr()
    print(f"  {_green('✓')} {_bold(name)} v{pkg.get('version', '?')} installed  ·  restart Claude to use it")

    # Warn about API key
    auth_env = pkg.get("install", {}).get("auth", {}).get("env_var", "")
    if auth_env and not os.environ.get(auth_env):
        homepage = pkg.get("homepage", "")
        print()
        print(f"  {_yellow('⚠')} Set {_bold(auth_env)} to use authenticated tools")
        if homepage:
            print(f"     Get your key → {_ul(homepage)}")

    _hr()
    print()


def cmd_list(args: argparse.Namespace) -> None:
    meta = _load_meta()
    print()
    if not meta:
        print(f"  {_dim('No packages installed.')}")
        print(f"  {_dim('Try:')}  mcpx search <query>\n")
        return

    print(f"  {_cyan('⬡')} {_bold('mcpx')} · {len(meta)} installed\n")
    _hr()
    col = max(len(n) for n in meta) + 2
    for name, info in meta.items():
        ver  = _dim("v" + info["version"])
        disp = _dim(info["display_name"])
        print(f"  {_bold(_blue(name)):<{col + 10}} {ver:<14} {disp}")
    _hr()
    print()


def cmd_uninstall(args: argparse.Namespace) -> None:
    name = args.name
    meta = _load_meta()

    print()
    if name not in meta:
        print(_red(f"  ✗ {name} is not installed.\n"))
        sys.exit(1)

    print(f"  {_cyan('⬡')} {_bold('mcpx uninstall')} {name}\n")

    server_dir = INSTALL_DIR / name
    if server_dir.exists():
        shutil.rmtree(server_dir)
    print(f"  {_green('✓')} Server files removed")

    _remove_from_claude(name)
    print(f"  {_green('✓')} Removed from Claude settings")

    del meta[name]
    _save_meta(meta)
    print()
    print(f"  {_dim(name)} uninstalled  ·  restart Claude to apply\n")


def cmd_publish(args: argparse.Namespace) -> None:
    manifest_path = Path(args.manifest)
    print()

    if not manifest_path.exists():
        print(_red(f"  ✗ File not found: {manifest_path}\n"))
        sys.exit(1)

    try:
        manifest = json.loads(manifest_path.read_text())
    except json.JSONDecodeError as e:
        print(_red(f"  ✗ Invalid JSON: {e}\n"))
        sys.exit(1)

    required = ["name", "description", "install"]
    missing  = [f for f in required if f not in manifest]
    if missing:
        print(_red(f"  ✗ Missing required fields: {', '.join(missing)}\n"))
        sys.exit(1)

    print(f"  {_green('✓')} Manifest valid")
    print(f"  Submitting {_bold(manifest.get('name', '?'))} to registry…", end=" ", flush=True)
    result = _api_post(manifest)
    print(_green("✓"))
    print()
    print(f"  {_green(result.get('message', 'Submitted.'))}")
    print(f"  {_dim('Review typically takes 24 hours.')}\n")


# ── Entry point ────────────────────────────────────────────────────────────────
def main() -> None:
    if sys.stdout.encoding and sys.stdout.encoding.lower() not in ("utf-8", "utf8"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[union-attr]
        except Exception:
            pass

    parser = argparse.ArgumentParser(
        prog="mcpx",
        description="MCP Exchange — the marketplace for MCP servers.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
examples:
  mcpx search marketing
  mcpx info acquire
  mcpx install acquire
  mcpx list
  mcpx publish manifest.json
""",
    )
    parser.add_argument("--version", action="version", version="mcpx 0.1.0")
    sub = parser.add_subparsers(dest="command", metavar="command")
    sub.required = True

    p_search = sub.add_parser("search", help="Search packages")
    p_search.add_argument("query", nargs="+", help="Search query")
    p_search.set_defaults(func=cmd_search)

    p_info = sub.add_parser("info", help="Show package details")
    p_info.add_argument("name", help="Package name")
    p_info.set_defaults(func=cmd_info)

    p_install = sub.add_parser("install", help="Install a package")
    p_install.add_argument("name", help="Package name")
    p_install.set_defaults(func=cmd_install)

    p_list = sub.add_parser("list", help="List installed packages")
    p_list.set_defaults(func=cmd_list)

    p_un = sub.add_parser("uninstall", help="Uninstall a package")
    p_un.add_argument("name", help="Package name")
    p_un.set_defaults(func=cmd_uninstall)

    p_pub = sub.add_parser("publish", help="Submit a package for review")
    p_pub.add_argument("manifest", help="Path to manifest.json")
    p_pub.set_defaults(func=cmd_publish)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
