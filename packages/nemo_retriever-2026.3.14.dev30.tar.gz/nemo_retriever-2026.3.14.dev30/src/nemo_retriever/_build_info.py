"""Build metadata written by CI before packaging."""

BUILD_GIT_SHA = "b87879a152c2e924452236b352092ec5326e6534"
BUILD_DATE = "2026-03-14T23:43:16Z"
