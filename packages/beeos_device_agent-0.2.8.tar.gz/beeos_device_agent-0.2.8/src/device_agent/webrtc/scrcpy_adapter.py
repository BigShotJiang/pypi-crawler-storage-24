"""scrcpy server adapter — manages scrcpy H.264 stream for WebRTC.

Launches scrcpy-server on the Android device via ADB, reads the H.264 NAL
unit stream from an ADB-forwarded socket, and pushes NAL units into a
``ScrcpyVideoTrack`` for WebRTC streaming.

Protocol notes (scrcpy v3.x with tunnel_forward=true):
  With send_device_meta=false, send_dummy_byte=false, send_codec_meta=false,
  and send_frame_meta=true, the socket stream is:
    [12-byte frame header][N bytes H.264 data] ...
  Frame header = PTS/flags (u64 BE) + size (u32 BE).
  Top 2 bits of PTS: bit63 = config packet, bit62 = key frame.
"""

from __future__ import annotations

import asyncio
import logging
import re
import shutil
import socket
import struct
from typing import TYPE_CHECKING, Any, Awaitable, Callable

if TYPE_CHECKING:
    from .video_source import ScrcpyVideoTrack

OnAudioDataCallback = Callable[[bytes], None]

logger = logging.getLogger(__name__)

_DEFAULT_SERVER_JAR = "/data/local/tmp/scrcpy-server.jar"
_DEFAULT_LOCAL_PORT = 27183
_ADB_MAX_RETRIES = 3

_WATCHDOG_INITIAL_BACKOFF_S = 1.0
_WATCHDOG_MAX_BACKOFF_S = 30.0
_WATCHDOG_MAX_RETRIES = 10

OnStreamErrorCallback = Callable[[str], Awaitable[None]]
OnStreamRecoveredCallback = Callable[[], Awaitable[None]]
OnResolutionChangedCallback = Callable[[int, int], Awaitable[None]]


def _detect_scrcpy_version() -> str:
    scrcpy_bin = shutil.which("scrcpy")
    if scrcpy_bin:
        import subprocess
        try:
            out = subprocess.check_output([scrcpy_bin, "--version"], stderr=subprocess.STDOUT, timeout=5)
            m = re.search(r"scrcpy\s+(\d+\.\d+(?:\.\d+)?)", out.decode(errors="replace"))
            if m:
                return m.group(1)
        except Exception:
            pass
    logger.warning("Could not detect scrcpy version, defaulting to 2.7")
    return "2.7"


_DETECTED_VERSION = _detect_scrcpy_version()


class ScrcpyAdapter:
    """Manages scrcpy server lifecycle and H.264 frame extraction."""

    def __init__(
        self,
        adb_serial: str,
        max_fps: int = 30,
        max_width: int = 1920,
        bitrate: int = 16_000_000,
        adb_host: str = "127.0.0.1",
        adb_port: int = 5037,
        server_jar: str = _DEFAULT_SERVER_JAR,
        scrcpy_version: str = _DETECTED_VERSION,
        local_port: int = _DEFAULT_LOCAL_PORT,
        video_codec: str = "h264",
        on_stream_error: OnStreamErrorCallback | None = None,
        on_stream_recovered: OnStreamRecoveredCallback | None = None,
        on_resolution_changed: OnResolutionChangedCallback | None = None,
        on_audio_data: OnAudioDataCallback | None = None,
    ) -> None:
        self._serial = adb_serial
        self._max_fps = max_fps
        self._max_width = max_width
        self._bitrate = bitrate
        self._adb_host = adb_host
        self._adb_port = adb_port
        self._server_jar = server_jar
        self._scrcpy_version = scrcpy_version
        self._local_port = local_port
        self._video_codec = video_codec
        self._on_stream_error = on_stream_error
        self._on_stream_recovered = on_stream_recovered
        self._on_resolution_changed = on_resolution_changed
        self._on_audio_data = on_audio_data
        self._process: asyncio.subprocess.Process | None = None
        self._reader_task: asyncio.Task[None] | None = None
        self._audio_task: asyncio.Task[None] | None = None
        self._control_task: asyncio.Task[None] | None = None
        self._watchdog_task: asyncio.Task[None] | None = None
        self._video_track: ScrcpyVideoTrack | None = None
        self._running = False
        self._healthy = False
        self._last_config_nal: bytes | None = None
        self._last_keyframe_nal: bytes | None = None
        self._keyframe_interval = 60
        self._video_connected = asyncio.Event()
        self._audio_connected = asyncio.Event()
        self._control_sock: socket.socket | None = None

    @property
    def running(self) -> bool:
        return self._running

    @property
    def healthy(self) -> bool:
        return self._running and self._healthy

    @property
    def video_track(self) -> ScrcpyVideoTrack | None:
        return self._video_track

    async def start(self) -> ScrcpyVideoTrack:
        """Push scrcpy-server, start it, and return a video track."""
        from .video_source import ScrcpyVideoTrack as _Track

        self._video_track = _Track(
            target_fps=self._max_fps,
            on_bulk_discard=self.request_idr,
        )

        await self._push_server()
        await self._setup_forward()
        await self._launch_scrcpy_pipeline()
        self._running = True
        logger.info("scrcpy adapter started (serial=%s, control=true, audio=true)", self._serial)
        return self._video_track

    async def _launch_scrcpy_pipeline(self, *, with_watchdog: bool = True) -> None:
        self._video_connected.clear()
        self._audio_connected.clear()
        if self._video_track:
            self._video_track.flush()
        self._last_config_nal = None
        self._last_keyframe_nal = None
        await self._kill_stale_scrcpy()
        await self._push_server()
        await self._remove_forward()
        await self._setup_forward()
        await self._start_server()
        await asyncio.sleep(0.5)

        # Connection order for tunnel_forward: video → audio → control
        self._reader_task = asyncio.create_task(self._read_loop())
        self._audio_task = asyncio.create_task(self._audio_read_loop())
        self._control_task = asyncio.create_task(self._control_loop())
        if with_watchdog:
            self._watchdog_task = asyncio.create_task(self._watchdog())
        self._healthy = True

    async def _kill_reader_tasks(self) -> None:
        self._healthy = False
        for task_attr in ("_reader_task", "_audio_task", "_control_task"):
            task: asyncio.Task[Any] | None = getattr(self, task_attr)
            if task and not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
                setattr(self, task_attr, None)

        if self._control_sock:
            try:
                self._control_sock.close()
            except OSError:
                pass
            self._control_sock = None

        if self._process:
            try:
                self._process.terminate()
                await asyncio.wait_for(self._process.wait(), timeout=5.0)
            except (asyncio.TimeoutError, ProcessLookupError):
                try:
                    if self._process:
                        self._process.kill()
                except ProcessLookupError:
                    pass
            self._process = None

    async def _kill_pipeline(self) -> None:
        await self._kill_reader_tasks()
        if self._watchdog_task and not self._watchdog_task.done():
            self._watchdog_task.cancel()
            try:
                await self._watchdog_task
            except asyncio.CancelledError:
                pass
            self._watchdog_task = None

    async def stop(self) -> None:
        self._running = False
        await self._kill_pipeline()
        if self._video_track:
            self._video_track.stop()
            self._video_track = None
        await self._remove_forward()
        logger.info("scrcpy adapter stopped")

    # -- Watchdog ---------------------------------------------------------------

    async def _watchdog(self) -> None:
        """Monitor video reader and auto-restart on crash."""
        try:
            while self._running:
                tasks: list[asyncio.Task[None]] = []
                if self._reader_task and not self._reader_task.done():
                    tasks.append(self._reader_task)
                if self._audio_task and not self._audio_task.done():
                    tasks.append(self._audio_task)
                if self._control_task and not self._control_task.done():
                    tasks.append(self._control_task)
                if not tasks:
                    break

                done, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
                if not self._running:
                    return

                video_died = self._reader_task in done
                audio_died = self._audio_task in done
                control_died = self._control_task in done

                if (control_died or audio_died) and not video_died:
                    if control_died:
                        logger.warning("scrcpy control channel exited — non-fatal")
                        self._control_sock = None
                    if audio_died:
                        logger.warning("scrcpy audio channel exited — non-fatal")
                    continue

                logger.warning("scrcpy video reader exited — starting recovery")
                self._healthy = False

                backoff = _WATCHDOG_INITIAL_BACKOFF_S
                attempt = 0
                while self._running:
                    attempt += 1
                    logger.info("scrcpy recovery attempt %d (backoff %.1fs)", attempt, backoff)
                    await asyncio.sleep(backoff)
                    if not self._running:
                        return
                    try:
                        await self._kill_reader_tasks()
                        await self._launch_scrcpy_pipeline(with_watchdog=False)
                        logger.info("scrcpy recovery succeeded on attempt %d", attempt)
                        if self._on_stream_recovered:
                            asyncio.ensure_future(self._on_stream_recovered())
                        break
                    except Exception:
                        logger.exception("scrcpy recovery attempt %d failed", attempt)
                        backoff = min(backoff * 2, _WATCHDOG_MAX_BACKOFF_S)
        except asyncio.CancelledError:
            pass

    # -- ADB helpers -----------------------------------------------------------

    async def _adb_exec(self, *args: str) -> tuple[bytes, bytes, int]:
        base = ["adb", "-H", self._adb_host, "-P", str(self._adb_port), "-s", self._serial]
        cmd = base + list(args)
        for attempt in range(_ADB_MAX_RETRIES):
            try:
                proc = await asyncio.create_subprocess_exec(
                    *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
                )
                stdout, stderr = await proc.communicate()
                if proc.returncode == 0:
                    return stdout, stderr, 0
            except Exception:
                pass
            if attempt < _ADB_MAX_RETRIES - 1:
                await asyncio.sleep(0.5 * (attempt + 1))
        return b"", b"", -1

    async def _push_server(self) -> None:
        stdout, _, rc = await self._adb_exec("shell", f"test -f {self._server_jar} && echo exists")
        if b"exists" in stdout:
            return

        local_jar = self._find_local_server_jar() or self._download_server_jar()
        if local_jar:
            logger.info("Pushing scrcpy-server to %s from %s", self._serial, local_jar)
            _, _, rc = await self._adb_exec("push", local_jar, self._server_jar)
            if rc == 0:
                return

        raise RuntimeError(
            f"scrcpy-server not found on device {self._serial} and auto-push failed. "
            f"Push manually: adb -s {self._serial} push scrcpy-server {self._server_jar}"
        )

    @staticmethod
    def _find_local_server_jar() -> str | None:
        import os, glob
        jar = shutil.which("scrcpy-server")
        if jar and os.path.isfile(jar):
            return jar
        scrcpy_bin = shutil.which("scrcpy")
        if scrcpy_bin:
            real = os.path.realpath(scrcpy_bin)
            cellar_dir = os.path.dirname(os.path.dirname(real))
            candidate = os.path.join(cellar_dir, "share", "scrcpy", "scrcpy-server")
            if os.path.isfile(candidate):
                return candidate
            for g in glob.glob("/opt/homebrew/Cellar/scrcpy/*/share/scrcpy/scrcpy-server"):
                return g
        return None

    def _download_server_jar(self) -> str | None:
        """Download scrcpy-server from GitHub Releases and cache in ~/.beeos/."""
        import os
        import urllib.request

        cache_dir = os.path.join(os.path.expanduser("~"), ".beeos")
        os.makedirs(cache_dir, exist_ok=True)
        cached = os.path.join(cache_dir, f"scrcpy-server-v{self._scrcpy_version}")
        if os.path.isfile(cached):
            logger.info("Using cached scrcpy-server: %s", cached)
            return cached

        url = (
            f"https://github.com/Genymobile/scrcpy/releases/download/"
            f"v{self._scrcpy_version}/scrcpy-server-v{self._scrcpy_version}"
        )
        logger.info("Downloading scrcpy-server v%s from GitHub...", self._scrcpy_version)
        try:
            urllib.request.urlretrieve(url, cached)
            size_kb = os.path.getsize(cached) / 1024
            logger.info("Downloaded scrcpy-server (%.0f KB) -> %s", size_kb, cached)
            return cached
        except Exception:
            logger.warning("Failed to download scrcpy-server from %s", url, exc_info=True)
            if os.path.exists(cached):
                os.remove(cached)
            return None

    async def _setup_forward(self) -> None:
        _, stderr, rc = await self._adb_exec("forward", f"tcp:{self._local_port}", "localabstract:scrcpy")
        if rc != 0:
            raise RuntimeError(f"ADB forward failed: {stderr.decode(errors='replace')}")

    async def _remove_forward(self) -> None:
        await self._adb_exec("forward", "--remove", f"tcp:{self._local_port}")

    async def _kill_stale_scrcpy(self) -> None:
        stdout, _, _ = await self._adb_exec(
            "shell", "ps -A -o PID,ARGS 2>/dev/null || ps -o PID,ARGS 2>/dev/null || ps 2>/dev/null"
        )
        for line in stdout.decode(errors="replace").splitlines():
            if "scrcpy" in line.lower():
                parts = line.split()
                if parts and parts[0].isdigit():
                    await self._adb_exec("shell", f"kill -9 {parts[0]} 2>/dev/null || true")
                    logger.info("Killed stale scrcpy pid=%s", parts[0])
        await asyncio.sleep(0.5)

    async def _start_server(self) -> None:
        logger.info("Starting scrcpy-server %s on %s (jar=%s)", self._scrcpy_version, self._serial, self._server_jar)
        cmd = [
            "adb", "-H", self._adb_host, "-P", str(self._adb_port),
            "-s", self._serial, "shell",
            f"CLASSPATH={self._server_jar}",
            "app_process", "/",
            "com.genymobile.scrcpy.Server",
            self._scrcpy_version,
            f"video_codec={self._video_codec}",
            f"max_fps={self._max_fps}",
            f"max_size={self._max_width}",
            f"video_bit_rate={self._bitrate}",
            "video_codec_options=i-frame-interval=2",
            "tunnel_forward=true",
            "audio=true",
            "audio_codec=opus",
            "control=true",
            "send_frame_meta=true",
            "send_device_meta=false",
            "send_dummy_byte=false",
            "send_codec_meta=false",
        ]
        self._process = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
        )
        asyncio.create_task(self._log_server_output())

    async def _log_server_output(self) -> None:
        if not self._process:
            return
        try:
            if self._process.stderr:
                async for line in self._process.stderr:
                    text = line.decode(errors="replace").rstrip()
                    if text:
                        logger.info("scrcpy-server: %s", text)
        except (asyncio.CancelledError, Exception):
            pass

    # -- Video read loop -------------------------------------------------------

    async def _read_loop(self) -> None:
        """Read H.264 frames from scrcpy v3 tunnel_forward socket.

        Frame header: PTS/flags (u64 BE) + size (u32 BE) = 12 bytes.
        bit63 of PTS = config, bit62 = keyframe.
        """
        loop = asyncio.get_event_loop()
        sock: socket.socket | None = None
        frame_count = 0
        try:
            for attempt in range(15):
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.setblocking(False)
                    await loop.sock_connect(sock, ("127.0.0.1", self._local_port))
                    break
                except (ConnectionRefusedError, OSError):
                    if sock:
                        sock.close()
                        sock = None
                    await asyncio.sleep(0.3 * (attempt + 1))
            else:
                logger.error("Failed to connect to scrcpy socket after 15 attempts")
                return

            logger.info("Connected to scrcpy video socket")
            self._video_connected.set()

            while self._running:
                header = await self._read_exactly(loop, sock, 12)
                if len(header) < 12:
                    logger.warning("scrcpy socket closed (got %d of 12 header bytes)", len(header))
                    break
                pts_raw = struct.unpack(">Q", header[:8])[0]
                pkt_size = struct.unpack(">I", header[8:12])[0]
                is_config = bool(pts_raw & (1 << 63))
                is_keyframe = bool(pts_raw & (1 << 62))
                if pkt_size == 0 or pkt_size > 10 * 1024 * 1024:
                    continue
                nal_data = await self._read_exactly(loop, sock, pkt_size)
                if len(nal_data) < pkt_size:
                    break
                frame_count += 1
                if frame_count <= 3 or frame_count % 300 == 0 or is_keyframe or is_config:
                    logger.info("scrcpy frame #%d: size=%d config=%s keyframe=%s", frame_count, pkt_size, is_config, is_keyframe)
                if is_config:
                    self._check_config_changed(nal_data)
                    self._last_config_nal = nal_data
                elif is_keyframe:
                    self._last_keyframe_nal = nal_data
                if self._video_track:
                    if is_keyframe and not is_config and self._last_config_nal:
                        self._video_track.push_nal(self._last_config_nal, is_config=True)
                    self._video_track.push_nal(nal_data, is_config=is_config)
        except asyncio.CancelledError:
            pass
        except Exception:
            logger.exception("scrcpy read loop error")
        finally:
            logger.info("scrcpy read loop ended (frames=%d)", frame_count)
            if sock:
                sock.close()

    # -- Audio read loop -------------------------------------------------------

    async def _audio_read_loop(self) -> None:
        """Read OPUS audio from scrcpy audio socket (2nd connection).

        Scrcpy OPUS codec sends 12-byte headers + OPUS payload per packet.
        Each OPUS packet is forwarded as-is to ``on_audio_data`` for direct
        DataChannel relay — no decoding or re-encoding involved.
        """
        try:
            await asyncio.wait_for(self._video_connected.wait(), timeout=30.0)
        except asyncio.TimeoutError:
            logger.error("Timed out waiting for video socket — skipping audio")
            self._audio_connected.set()
            return

        loop = asyncio.get_event_loop()
        sock: socket.socket | None = None
        try:
            for attempt in range(15):
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.setblocking(False)
                    await loop.sock_connect(sock, ("127.0.0.1", self._local_port))
                    break
                except (ConnectionRefusedError, OSError):
                    if sock:
                        sock.close()
                        sock = None
                    await asyncio.sleep(0.3 * (attempt + 1))
            else:
                logger.error("Failed to connect to scrcpy audio socket")
                self._audio_connected.set()
                return

            logger.info("Connected to scrcpy audio socket")
            self._audio_connected.set()

            # First 4 bytes: check for disable code (0 = soft disable, 1 = error).
            peek = await self._read_exactly(loop, sock, 4)
            if len(peek) < 4:
                logger.warning("Audio socket closed immediately")
                return
            disable_code = struct.unpack(">I", peek)[0]
            if disable_code <= 1:
                logger.warning("Audio disabled by device (code=%d)", disable_code)
                sock.close()
                return

            rest = await self._read_exactly(loop, sock, 8)
            if len(rest) < 8:
                logger.warning("Audio socket closed during first header")
                return
            header = peek + rest
            frame_count = 0
            data_count = 0

            while self._running:
                pts_raw = struct.unpack(">Q", header[:8])[0]
                pkt_size = struct.unpack(">I", header[8:12])[0]
                is_config = bool(pts_raw & (1 << 63))
                if pkt_size == 0 or pkt_size > 1024 * 1024:
                    header = await self._read_exactly(loop, sock, 12)
                    if len(header) < 12:
                        break
                    continue
                audio_data = await self._read_exactly(loop, sock, pkt_size)
                if len(audio_data) < pkt_size:
                    break
                frame_count += 1

                if is_config:
                    logger.info("Audio OPUS config: %d bytes (frame #%d)", pkt_size, frame_count)
                elif self._on_audio_data:
                    data_count += 1
                    self._on_audio_data(audio_data)
                    if data_count == 1:
                        logger.info("Audio streaming started (OPUS, first data pkt %d bytes)", pkt_size)
                    elif data_count % 500 == 0:
                        logger.info("Audio streaming: %d OPUS packets sent", data_count)

                header = await self._read_exactly(loop, sock, 12)
                if len(header) < 12:
                    break

            logger.info("Audio read loop: streamed %d packets", frame_count)
        except asyncio.CancelledError:
            pass
        except Exception:
            logger.exception("Audio read loop error")
        finally:
            logger.info("Audio read loop ended")
            self._audio_connected.set()
            if sock:
                sock.close()

    # -- Control channel -------------------------------------------------------

    # scrcpy v3.3.4 ControlMessage type constants (from ControlMessage.java)
    _CTRL_TYPE_INJECT_KEYCODE = 0
    _CTRL_TYPE_INJECT_TOUCH = 2
    _CTRL_TYPE_INJECT_SCROLL = 3
    _CTRL_TYPE_BACK_OR_SCREEN_ON = 4
    _CTRL_TYPE_RESET_VIDEO = 17

    _ACTION_DOWN = 0
    _ACTION_UP = 1
    _ACTION_MOVE = 2
    _TOUCH_ACTION_MAP = {"down": 0, "up": 1, "move": 2}

    _AKEY_ACTION_DOWN = 0
    _AKEY_ACTION_UP = 1
    _ANDROID_KEYCODE_MAP: dict[str, int] = {
        "KEYCODE_BACK": 4, "KEYCODE_HOME": 3, "KEYCODE_APP_SWITCH": 187,
        "KEYCODE_ENTER": 66, "KEYCODE_DEL": 67, "KEYCODE_TAB": 61,
        "KEYCODE_SPACE": 62, "KEYCODE_DPAD_UP": 19, "KEYCODE_DPAD_DOWN": 20,
        "KEYCODE_DPAD_LEFT": 21, "KEYCODE_DPAD_RIGHT": 22,
        "KEYCODE_VOLUME_UP": 24, "KEYCODE_VOLUME_DOWN": 25,
        "KEYCODE_POWER": 26, "KEYCODE_MENU": 82,
    }

    @property
    def control_ready(self) -> bool:
        return self._control_sock is not None

    def inject_touch_event(
        self, action: str, x: int, y: int,
        screen_width: int, screen_height: int,
        pointer_id: int = 0, pressure: float = 1.0,
    ) -> bool:
        """Inject touch via scrcpy control socket (32 bytes)."""
        sock = self._control_sock
        if not sock:
            return False
        action_int = self._TOUCH_ACTION_MAP.get(action)
        if action_int is None:
            return False

        pressure_u16 = 0 if action_int == self._ACTION_UP else int(
            max(0.0, min(1.0, pressure)) * 0xFFFF
        )
        msg = struct.pack(
            ">BBqiiHHHii",
            self._CTRL_TYPE_INJECT_TOUCH,
            action_int,
            pointer_id,
            x, y,
            screen_width, screen_height,
            pressure_u16,
            0, 0,  # actionButton, buttons
        )
        try:
            sock.sendall(msg)
            return True
        except OSError:
            return False

    @staticmethod
    def _float_to_i16fp(value: float) -> int:
        value = max(-1.0, min(1.0, value))
        i = int(value * 0x8000)
        return max(-0x8000, min(0x7FFF, i))

    def inject_scroll_event(
        self, x: int, y: int,
        screen_width: int, screen_height: int,
        scroll_x: float = 0, scroll_y: float = 0,
    ) -> bool:
        """Inject scroll via scrcpy control socket (21 bytes)."""
        sock = self._control_sock
        if not sock:
            return False
        hscroll_fp = self._float_to_i16fp(max(-1.0, min(1.0, scroll_x)))
        vscroll_fp = self._float_to_i16fp(max(-1.0, min(1.0, scroll_y)))
        msg = struct.pack(
            ">BiiHHhhI",
            self._CTRL_TYPE_INJECT_SCROLL,
            x, y,
            screen_width, screen_height,
            hscroll_fp, vscroll_fp,
            0,  # buttons
        )
        try:
            sock.sendall(msg)
            return True
        except OSError:
            return False

    def inject_keycode(self, action: str, keycode: int, repeat: int = 0, metastate: int = 0) -> bool:
        """Inject keycode via scrcpy control socket (14 bytes)."""
        sock = self._control_sock
        if not sock:
            return False
        action_int = self._AKEY_ACTION_DOWN if action == "down" else self._AKEY_ACTION_UP
        msg = struct.pack(">BBiii", self._CTRL_TYPE_INJECT_KEYCODE, action_int, keycode, repeat, metastate)
        try:
            sock.sendall(msg)
            return True
        except OSError:
            return False

    def inject_back_or_screen_on(self, action: str) -> bool:
        """Send BACK_OR_SCREEN_ON (2 bytes)."""
        sock = self._control_sock
        if not sock:
            return False
        action_int = self._AKEY_ACTION_DOWN if action == "down" else self._AKEY_ACTION_UP
        msg = struct.pack(">BB", self._CTRL_TYPE_BACK_OR_SCREEN_ON, action_int)
        try:
            sock.sendall(msg)
            return True
        except OSError:
            return False

    async def _control_loop(self) -> None:
        """Open control socket (after video+audio) and send periodic keyframe requests."""
        try:
            await asyncio.wait_for(self._audio_connected.wait(), timeout=30.0)
        except asyncio.TimeoutError:
            logger.error("Timed out waiting for audio socket — skipping control")
            return

        loop = asyncio.get_event_loop()
        sock: socket.socket | None = None
        try:
            for attempt in range(15):
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.setblocking(False)
                    await loop.sock_connect(sock, ("127.0.0.1", self._local_port))
                    break
                except (ConnectionRefusedError, OSError):
                    if sock:
                        sock.close()
                        sock = None
                    await asyncio.sleep(0.3 * (attempt + 1))
            else:
                logger.error("Failed to connect to scrcpy control socket")
                return

            self._control_sock = sock
            logger.info("Connected to scrcpy control socket (keyframe every %ds)", self._keyframe_interval)

            drain_task = asyncio.create_task(self._drain_control(loop, sock))
            try:
                while self._running:
                    await asyncio.sleep(self._keyframe_interval)
                    if not self._running:
                        break
                    self._send_reset_video()
            finally:
                drain_task.cancel()
                try:
                    await drain_task
                except asyncio.CancelledError:
                    pass
        except asyncio.CancelledError:
            pass
        except Exception:
            logger.exception("scrcpy control loop error")
        finally:
            logger.info("scrcpy control loop ended")
            self._control_sock = None
            if sock:
                sock.close()

    def _send_reset_video(self) -> None:
        sock = self._control_sock
        if not sock:
            return
        try:
            sock.sendall(bytes([self._CTRL_TYPE_RESET_VIDEO]))
        except OSError:
            logger.warning("Control socket write failed for TYPE_RESET_VIDEO")

    def request_idr(self) -> None:
        """Request IDR keyframe (called after bulk frame discard)."""
        self._send_reset_video()

    @staticmethod
    async def _drain_control(loop: asyncio.AbstractEventLoop, sock: socket.socket) -> None:
        try:
            while True:
                data = await loop.sock_recv(sock, 4096)
                if not data:
                    break
        except (asyncio.CancelledError, OSError):
            pass

    # -- Resolution detection --------------------------------------------------

    def _check_config_changed(self, new_config: bytes) -> None:
        if (self._last_config_nal is not None
                and new_config != self._last_config_nal
                and self._on_resolution_changed):
            logger.info("Config NAL changed — resolution/rotation change")
            asyncio.ensure_future(self._on_resolution_changed(0, 0))

    # -- Helpers ---------------------------------------------------------------

    @staticmethod
    async def _read_exactly(loop: asyncio.AbstractEventLoop, sock: socket.socket, n: int) -> bytes:
        buf = bytearray()
        while len(buf) < n:
            chunk = await loop.sock_recv(sock, n - len(buf))
            if not chunk:
                break
            buf.extend(chunk)
        return bytes(buf)

    def configure(self, max_fps: int | None = None, max_width: int | None = None,
                  bitrate: int | None = None) -> None:
        if max_fps is not None:
            self._max_fps = max_fps
        if max_width is not None:
            self._max_width = max_width
        if bitrate is not None:
            self._bitrate = bitrate

    def request_keyframe(self) -> None:
        """Re-inject cached config + keyframe NAL for new viewer."""
        if not self._video_track:
            return
        self._video_track.flush()
        if self._last_config_nal:
            self._video_track.push_nal(self._last_config_nal, is_config=True)
        if self._last_keyframe_nal:
            self._video_track.push_nal(self._last_keyframe_nal, is_config=False)

    async def hot_reconfigure(self, bitrate: int, max_fps: int) -> None:
        """Restart scrcpy with new encoding parameters."""
        if not self._running:
            self._bitrate = bitrate
            self._max_fps = max_fps
            return

        logger.info("Hot-reconfiguring scrcpy: bitrate %d->%d fps %d->%d",
                     self._bitrate, bitrate, self._max_fps, max_fps)
        self._bitrate = bitrate
        self._max_fps = max_fps

        saved_video = self._video_track
        await self._kill_pipeline()
        self._video_track = saved_video
        if saved_video:
            saved_video.flush()
        await self._launch_scrcpy_pipeline(with_watchdog=True)
        logger.info("scrcpy hot-reconfigure complete")
