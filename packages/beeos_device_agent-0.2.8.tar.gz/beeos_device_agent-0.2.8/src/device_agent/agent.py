"""DeviceAgent — the main orchestrator tying ACP, MQTT, WebRTC, and AI together.

A DeviceAgent represents a single device (1 device = 1 process = 1 BeeOS Instance).
It manages three independent channels:
  1. ACP (via Bridge) — control plane: AI chat + device management
  2. MQTT (via EMQX)  — signaling + telemetry
  3. WebRTC (P2P/TURN) — on-demand video streaming + DataChannel control
"""

from __future__ import annotations

import asyncio
import json
import logging
import math
from dataclasses import dataclass, field
from typing import Any

from beeos_bridge_client import BridgeClient, BridgeClientOptions, ReconnectConfig

from .acp.device_handler import DeviceHandler
from .acp.message_store import MessageStore
from .acp.router import ACPRouter
from .acp.session_handler import SessionHandler
from .ai.mobile_agent_bridge import AgentStep, MobileAgentBridge
from .ai.task_engine import TaskEngine
from .mqtt.client import MQTTManager
from .mqtt.signaling import SignalingHandler
from .mqtt.stream_lifecycle import StreamLifecycle
from .mqtt.telemetry import TelemetryReporter
from .runtime.base import DeviceRuntime
from .webrtc.peer import WebRTCPeer
from .webrtc.scrcpy_adapter import ScrcpyAdapter

logger = logging.getLogger(__name__)


@dataclass
class DeviceAgentConfig:
    bridge_url: str = ""
    bridge_service: str = "acp"
    standalone: bool = False
    key_file: str | None = None
    private_key: bytes | None = None
    public_key: bytes | None = None

    mqtt_url: str = ""
    mqtt_host: str = ""
    mqtt_port: int = 8883
    mqtt_username: str | None = None
    mqtt_password: str | None = None
    mqtt_use_tls: bool = True

    agent_gateway_url: str = "https://agent-gw.beeos.ai"
    device_id: str = ""

    vlm_api_key: str = ""
    vlm_base_url: str = ""
    vlm_model: str = "openrouter/bytedance/ui-tars-1.5-7b"

    ice_servers: list[dict[str, Any]] = field(default_factory=list)
    cooldown_seconds: float = 30.0
    telemetry_interval: float = 30.0
    scroll_sensitivity: float = 0.15

    http_enabled: bool = False
    http_host: str = "0.0.0.0"
    http_port: int = 9090


class DeviceAgent:
    """Main DeviceAgent orchestrating three channels + AI automation."""

    def __init__(
        self,
        config: DeviceAgentConfig,
        runtime: DeviceRuntime,
    ) -> None:
        self._config = config
        self._runtime = runtime
        self._running = False

        self._bridge: BridgeClient | None = None
        self._mqtt: MQTTManager | None = None
        self._webrtc_peer: WebRTCPeer | None = None
        self._scrcpy: ScrcpyAdapter | None = None

        self._acp_router: ACPRouter | None = None
        self._signaling: SignalingHandler | None = None
        self._stream_lifecycle: StreamLifecycle | None = None
        self._telemetry: TelemetryReporter | None = None
        self._ai_bridge: MobileAgentBridge | None = None
        self._task_engine: TaskEngine | None = None
        self._message_store: MessageStore | None = None
        self._http_api = None
        self._touch_state: dict[int, tuple[int, int]] = {}  # pointerId → (startX, startY)
        self._device_screen_width: int = 0
        self._device_screen_height: int = 0
        self._current_session_id: str = ""

    @property
    def running(self) -> bool:
        return self._running

    async def start(self) -> None:
        """Initialize all channels and start the agent.

        In standalone mode only the device runtime, task engine, and HTTP API
        are started — Bridge (ACP) and MQTT are skipped entirely.
        """
        standalone = self._config.standalone
        logger.info(
            "Starting DeviceAgent%s...", " (standalone)" if standalone else ""
        )

        await self._runtime.connect()
        info = await self._runtime.get_info()
        logger.info("Device: %s (%s, %dx%d)", info.name, info.os, info.width, info.height)

        device_id = self._config.device_id or info.metadata.get("serial", "unknown")

        if not standalone:
            # Channel 1: ACP (Bridge)
            await self._start_acp(device_id)

            # Fetch bootstrap config from Agent Gateway (MQTT topic, JWT, ICE servers)
            bootstrap = await self._fetch_device_bootstrap()

            # Channel 2: MQTT (EMQX) — use bootstrap config for correct topic + auth
            mqtt_device_id = device_id
            if bootstrap.get("deviceTopic"):
                topic_prefix = bootstrap["deviceTopic"]
                mqtt_device_id = topic_prefix.removeprefix("devices/")
                logger.info("Bootstrap deviceTopic: %s (mqtt_device_id=%s)", topic_prefix, mqtt_device_id)

            mqtt_token = bootstrap.get("mqttToken", "")
            mqtt_url = bootstrap.get("mqttUrl") or self._config.mqtt_url
            ice_servers = bootstrap.get("iceServers") or self._config.ice_servers

            if mqtt_url or self._config.mqtt_host:
                await self._start_mqtt(mqtt_device_id, mqtt_url=mqtt_url, mqtt_token=mqtt_token, ice_servers=ice_servers)

            # Auto-fetch VLM config from Agent Gateway (unless manually set)
            if not self._config.vlm_api_key:
                await self._fetch_vlm_config()

        self._task_engine = TaskEngine(
            runtime=self._runtime,
            on_step=self._on_task_step,
            vlm_api_key=self._config.vlm_api_key,
            vlm_base_url=self._config.vlm_base_url,
            vlm_model=self._config.vlm_model,
        )
        await self._task_engine.start()

        # HTTP API — always on in standalone mode, otherwise opt-in
        if self._config.http_enabled or standalone:
            await self._start_http_api()

        self._running = True
        logger.info("DeviceAgent started (device_id=%s)", device_id)

    async def _start_acp(self, device_id: str) -> None:
        """Initialize the ACP channel via Bridge."""
        opts = BridgeClientOptions(
            bridge_url=self._config.bridge_url,
            service=self._config.bridge_service,
            key_file=self._config.key_file,
            private_key=self._config.private_key,
            public_key=self._config.public_key,
            reconnect=ReconnectConfig(enabled=True),
        )
        self._bridge = BridgeClient(opts)

        self._message_store = MessageStore()
        self._message_store.open()

        device_handler = DeviceHandler(self._runtime)
        session_handler = SessionHandler(
            on_prompt=self._on_ai_prompt,
            message_store=self._message_store,
        )
        self._acp_router = ACPRouter(device_handler, session_handler)

        self._bridge.on("message", self._on_acp_message)
        self._bridge.on("connected", self._on_acp_connected)
        self._bridge.on("disconnected", lambda r: logger.warning("ACP channel disconnected: %s", r))

        await self._bridge.connect()

    async def _start_mqtt(
        self,
        device_id: str,
        *,
        mqtt_url: str = "",
        mqtt_token: str = "",
        ice_servers: list[dict[str, Any]] | None = None,
    ) -> None:
        """Initialize the MQTT channel for signaling and telemetry.

        When *mqtt_token* is provided (from bootstrap), it is used as the MQTT
        password with ``"device"`` as username — matching EMQX JWT auth config.
        """
        self._mqtt = MQTTManager(
            device_id=device_id,
            mqtt_url=mqtt_url or self._config.mqtt_url,
            mqtt_host=self._config.mqtt_host,
            mqtt_port=self._config.mqtt_port,
            mqtt_username=self._config.mqtt_username or ("device" if mqtt_token else None),
            mqtt_password=self._config.mqtt_password or mqtt_token or None,
            use_tls=self._config.mqtt_use_tls,
            on_reconnect=self._refresh_mqtt_token,
        )

        self._stream_lifecycle = StreamLifecycle(
            cooldown_seconds=self._config.cooldown_seconds,
            on_start_stream=self._on_start_stream,
            on_stop_stream=self._on_stop_stream,
        )

        self._webrtc_peer = WebRTCPeer(
            ice_servers=ice_servers if ice_servers else self._config.ice_servers,
            on_viewer_connected=self._on_webrtc_viewer_connected,
            on_viewer_disconnected=self._stream_lifecycle.viewer_disconnected,
            on_data_channel_message=self._on_datachannel_message,
            on_prepare_track=self._prepare_video_track,
        )

        self._signaling = SignalingHandler(
            mqtt=self._mqtt,
            on_offer=self._on_webrtc_offer,
            on_ice_candidate=self._on_ice_candidate,
        )

        self._telemetry = TelemetryReporter(
            mqtt=self._mqtt,
            interval=self._config.telemetry_interval,
            get_device_metrics=self._get_device_metrics,
        )

        await self._mqtt.connect()
        await self._telemetry.start()

    def _load_keys(self) -> tuple[bytes | None, bytes | None]:
        """Load Ed25519 key pair from config or key file."""
        private_key = self._config.private_key
        public_key = self._config.public_key
        if (not private_key or not public_key) and self._config.key_file:
            from beeos_bridge_client import load_key_pair
            kp = load_key_pair(self._config.key_file)
            private_key, public_key = kp.private_key, kp.public_key
        return private_key, public_key

    async def _fetch_device_bootstrap(self) -> dict[str, Any]:
        """Fetch MQTT + ICE config from Agent Gateway ``/api/v1/device/bootstrap``."""
        if not self._config.agent_gateway_url:
            return {}
        private_key, public_key = self._load_keys()
        if not private_key or not public_key:
            return {}

        from .agent_gateway_client import fetch_device_bootstrap

        return await fetch_device_bootstrap(
            self._config.agent_gateway_url,
            private_key,
            public_key,
        )

    async def _refresh_mqtt_token(self) -> tuple[str | None, str | None] | None:
        """Called by MQTTManager before reconnect to get fresh credentials."""
        bootstrap = await self._fetch_device_bootstrap()
        token = bootstrap.get("mqttToken")
        if token:
            logger.info("Refreshed MQTT token from bootstrap")
            return ("device", token)
        logger.warning("Failed to refresh MQTT token — bootstrap returned no token")
        return None

    async def _fetch_vlm_config(self) -> None:
        """Fetch VLM configuration (arouter API key) from Agent Gateway."""
        if not self._config.agent_gateway_url:
            return

        private_key, public_key = self._load_keys()
        if not private_key or not public_key:
            return

        from .agent_gateway_client import fetch_agent_config

        cfg = await fetch_agent_config(
            self._config.agent_gateway_url,
            private_key,
            public_key,
        )
        if cfg.get("vlm_api_key"):
            self._config.vlm_api_key = cfg["vlm_api_key"]
            if not self._config.vlm_base_url:
                self._config.vlm_base_url = "https://api.arouter.ai/v1"
            logger.info("VLM API key configured from Agent Gateway")
        if cfg.get("vlm_model") and not self._config.vlm_model:
            self._config.vlm_model = cfg["vlm_model"]

    async def _get_device_metrics(self) -> dict[str, Any]:
        """Collect device battery/CPU metrics via ADB shell for telemetry."""
        metrics: dict[str, Any] = {}
        try:
            battery_raw = await self._runtime.execute_shell("dumpsys battery")
            for line in battery_raw.splitlines():
                line = line.strip()
                if line.startswith("level:"):
                    metrics["battery_level"] = int(line.split(":", 1)[1].strip())
                elif line.startswith("status:"):
                    val = int(line.split(":", 1)[1].strip())
                    metrics["battery_charging"] = val == 2 or val == 5
                elif line.startswith("temperature:"):
                    metrics["battery_temp"] = int(line.split(":", 1)[1].strip()) / 10.0
        except Exception:
            logger.debug("Failed to collect battery metrics", exc_info=True)
        try:
            mem_raw = await self._runtime.execute_shell(
                "cat /proc/meminfo | head -3"
            )
            mem_total = mem_free = 0
            for line in mem_raw.splitlines():
                if line.startswith("MemTotal:"):
                    mem_total = int(line.split()[1])
                elif line.startswith("MemAvailable:"):
                    mem_free = int(line.split()[1])
            if mem_total > 0:
                metrics["memory_total_kb"] = mem_total
                metrics["memory_available_kb"] = mem_free
                metrics["memory_usage_pct"] = round(
                    (1 - mem_free / mem_total) * 100, 1
                )
        except Exception:
            logger.debug("Failed to collect memory metrics", exc_info=True)
        return metrics

    async def _start_http_api(self) -> None:
        from .api import DeviceAgentAPI
        self._http_api = DeviceAgentAPI(
            runtime=self._runtime,
            task_engine=self._task_engine,
            host=self._config.http_host,
            port=self._config.http_port,
        )
        await self._http_api.start()

    async def stop(self) -> None:
        """Gracefully shut down all channels."""
        logger.info("Stopping DeviceAgent...")
        self._running = False

        if self._http_api:
            await self._http_api.stop()

        if self._task_engine:
            await self._task_engine.stop()

        if self._telemetry:
            await self._telemetry.stop()

        if self._stream_lifecycle:
            await self._stream_lifecycle.force_stop()

        if self._webrtc_peer:
            await self._webrtc_peer.close()

        if self._scrcpy and self._scrcpy.running:
            await self._scrcpy.stop()

        if self._mqtt:
            await self._mqtt.disconnect()

        if self._bridge:
            await self._bridge.close()

        if self._message_store:
            self._message_store.close()

        await self._runtime.disconnect()
        logger.info("DeviceAgent stopped")

    # -- ACP connection / device registration --

    async def _on_acp_connected(self) -> None:
        logger.info("ACP channel connected")
        asyncio.get_event_loop().call_soon(
            lambda: asyncio.ensure_future(self._publish_device_info_mqtt())
        )

    async def _on_webrtc_viewer_connected(self) -> None:
        """Called when WebRTC peer connects — forward to lifecycle + send device info via DC."""
        await self._stream_lifecycle.viewer_connected()
        await self._send_device_info_via_datachannel()

    async def _send_device_info_via_datachannel(self) -> None:
        """Push device resolution/info through DataChannel so the viewer uses correct coordinates."""
        if not self._webrtc_peer:
            return
        try:
            info = await self._runtime.get_info()
            await self._webrtc_peer.send_data({
                "type": "device_info",
                "device": {
                    "name": info.name,
                    "os": info.os,
                    "resolution": f"{info.width}x{info.height}",
                },
            })
            logger.info("Sent device_info via DataChannel: %dx%d", info.width, info.height)
        except Exception:
            logger.exception("Failed to send device_info via DataChannel")

    async def _publish_device_info_mqtt(self) -> None:
        """Publish device info to MQTT for backend consumption."""
        if not self._mqtt or not self._mqtt.connected:
            return
        try:
            info = await self._runtime.get_info()
            from dataclasses import asdict
            info_dict = asdict(info)
            info_dict["type"] = info.type.value
            info_dict["capabilities"] = [c.value for c in info.capabilities]
            await self._mqtt.publish("info", info_dict)
            logger.info("Published device info to MQTT")
        except Exception:
            logger.exception("Failed to publish device info to MQTT")

    # -- ACP message handling --

    async def _on_acp_message(self, raw: str | bytes) -> None:
        if isinstance(raw, bytes):
            raw = raw.decode()
        try:
            parsed = json.loads(raw)
            logger.info("ACP recv: method=%s id=%s", parsed.get("method"), parsed.get("id"))
        except Exception:
            pass
        response = await self._acp_router.handle_message(raw)
        if response and self._bridge:
            await self._bridge.send(response)

    # -- ACP session/update notification helper --

    def _send_session_update(self, update: dict[str, Any]) -> None:
        """Send a session/update notification matching beeos-claw ACP protocol."""
        if not self._bridge:
            return
        msg = json.dumps({
            "jsonrpc": "2.0",
            "method": "session/update",
            "params": {
                "sessionId": self._current_session_id,
                "update": update,
            },
        })
        asyncio.ensure_future(self._bridge.send(msg))

    # -- AI prompt handling --

    async def _on_ai_prompt(self, data: dict[str, Any]) -> None:
        """Handle session/prompt — submit to TaskEngine."""
        prompt = data.get("prompt", "")
        if not prompt:
            return

        self._current_session_id = data.get("session_id", self._current_session_id)

        if self._telemetry:
            self._telemetry.agent_status = "running"

        self._send_session_update({
            "sessionUpdate": "agent_status",
            "status": "running",
        })

        if self._task_engine:
            await self._task_engine.submit(prompt)

    async def _on_task_step(self, task_id: str, step: dict[str, Any]) -> None:
        """Stream task step progress via ACP session/update notifications.

        Maps TaskEngine step data to ACP update types that the web
        chat-store understands (agent_message_chunk, tool_call,
        tool_call_update, agent_status).
        Also persists assistant messages to SQLite.
        """
        logger.info("Task step: task=%s step=%s", task_id[:8], step)
        action = step.get("action", "")
        reasoning = step.get("reasoning", "")
        status = step.get("status", "running")
        step_index = step.get("index", 0)
        tool_call_id = f"{task_id}-step-{step_index}"

        if reasoning:
            self._send_session_update({
                "sessionUpdate": "agent_message_chunk",
                "content": {"type": "text", "text": reasoning + "\n"},
            })

        if action and action != "done" and status == "running":
            params_str = json.dumps(step.get("parameters", {}))
            self._send_session_update({
                "sessionUpdate": "tool_call",
                "toolCallId": tool_call_id,
                "title": action,
                "arguments": params_str,
            })
            if self._message_store and self._current_session_id:
                self._message_store.add_message(
                    self._current_session_id, "assistant", action,
                    "tool_call", {"toolCallId": tool_call_id, "parameters": step.get("parameters", {})},
                )

        if action and action != "done" and status in ("completed", "failed"):
            self._send_session_update({
                "sessionUpdate": "tool_call_update",
                "toolCallId": tool_call_id,
                "status": status,
                "output": reasoning or f"{action} {status}",
            })
            if self._message_store and self._current_session_id:
                self._message_store.add_message(
                    self._current_session_id, "assistant",
                    reasoning or f"{action} {status}",
                    "tool_result", {"toolCallId": tool_call_id, "status": status},
                )

        if reasoning and status == "running" and self._message_store and self._current_session_id:
            self._message_store.add_message(
                self._current_session_id, "assistant", reasoning, "text",
            )

        if status in ("completed", "failed"):
            if self._telemetry:
                self._telemetry.agent_status = "idle"
            self._send_session_update({
                "sessionUpdate": "agent_status",
                "status": "idle",
            })
            if self._message_store and self._current_session_id:
                self._message_store.add_message(
                    self._current_session_id, "system",
                    f"Task {status}", "status",
                    {"taskId": task_id, "status": status},
                )

    # -- WebRTC signaling --

    async def _on_webrtc_offer(self, payload: dict[str, Any]) -> dict[str, Any] | None:
        """Handle WebRTC offer from a viewer."""
        if not self._webrtc_peer:
            return None
        return await self._webrtc_peer.handle_offer(payload)

    async def _on_ice_candidate(self, payload: dict[str, Any]) -> None:
        """Handle ICE candidate from a viewer."""
        if self._webrtc_peer:
            await self._webrtc_peer.handle_ice_candidate(payload)

    # -- Stream lifecycle callbacks --

    async def _prepare_video_track(self) -> Any:
        """Start scrcpy and return the video track, called by WebRTCPeer before creating the answer."""
        if self._scrcpy and self._scrcpy.running:
            return self._scrcpy.video_track

        logger.info("Preparing video track (starting scrcpy)...")
        info = await self._runtime.get_info()
        serial = info.metadata.get("serial", "")
        if not serial:
            logger.warning("No ADB serial found, cannot start scrcpy")
            return None

        self._device_screen_width = info.width
        self._device_screen_height = info.height

        self._scrcpy = ScrcpyAdapter(
            adb_serial=serial,
            on_audio_data=self._on_scrcpy_audio,
            on_stream_error=self._on_scrcpy_stream_error,
            on_stream_recovered=self._on_scrcpy_stream_recovered,
        )
        video_track = await self._scrcpy.start()
        if self._webrtc_peer and video_track:
            self._webrtc_peer.set_video_track(video_track)
        if self._stream_lifecycle:
            await self._stream_lifecycle.viewer_connected()
        return video_track

    def _on_scrcpy_audio(self, data: bytes) -> None:
        """Forward OPUS audio packets from scrcpy to the viewer via DataChannel."""
        if self._webrtc_peer:
            self._webrtc_peer.send_binary(data)

    async def _on_scrcpy_stream_error(self, reason: str) -> None:
        """Called if scrcpy watchdog gives up (defensive — current watchdog never gives up)."""
        logger.error("scrcpy stream error: %s", reason)

    async def _on_scrcpy_stream_recovered(self) -> None:
        """Called after scrcpy watchdog successfully recovers the pipeline.

        Notifies the browser via DataChannel so it can tear down the stale
        WebRTC session and reconnect with a fresh MediaRelay + VP8 encoder.
        """
        logger.info("scrcpy stream recovered — notifying viewer to reconnect")
        if self._webrtc_peer:
            await self._webrtc_peer.send_data({"type": "stream_restarted"})

    async def _on_start_stream(self) -> None:
        """Called when transitioning to STREAMING state — starts scrcpy and injects video track."""
        logger.info("Starting screen stream...")
        if self._scrcpy and self._scrcpy.running:
            return
        await self._prepare_video_track()

    async def _on_stop_stream(self) -> None:
        """Called when transitioning to IDLE state."""
        logger.info("Stopping screen stream...")
        if self._scrcpy:
            await self._scrcpy.stop()
            self._scrcpy = None
        if self._webrtc_peer:
            await self._webrtc_peer.close(release_track=True)

    # -- DataChannel control --

    async def _on_datachannel_message(self, msg: dict[str, Any]) -> None:
        """Handle DataChannel control messages (touch, key, etc.).

        Prefers scrcpy control channel injection (low latency), falling
        back to adb shell input when the control channel is unavailable.
        """
        msg_type = msg.get("type", "")

        # Prefer video-stream resolution sent by the frontend (matches what
        # scrcpy's PositionMapper expects).  Fall back to device native res.
        sw = int(msg.get("screenWidth", 0)) or self._device_screen_width
        sh = int(msg.get("screenHeight", 0)) or self._device_screen_height

        if msg_type == "touch":
            action = msg.get("action", "")
            x, y = int(msg.get("x", 0)), int(msg.get("y", 0))
            pointer_id = msg.get("pointerId", 0)
            pressure = msg.get("pressure", 1.0)

            if self._scrcpy and self._scrcpy.control_ready and sw and sh:
                self._scrcpy.inject_touch_event(action, x, y, sw, sh, pointer_id, pressure)
                if action == "down":
                    self._touch_state[pointer_id] = (x, y)
                elif action == "up":
                    self._touch_state.pop(pointer_id, None)
                elif action == "move":
                    self._touch_state[pointer_id] = (x, y)
            else:
                if action == "down":
                    self._touch_state[pointer_id] = (x, y)
                elif action == "move":
                    prev = self._touch_state.get(pointer_id)
                    if prev:
                        px, py = prev
                        if abs(x - px) > 5 or abs(y - py) > 5:
                            await self._runtime.swipe(px, py, x, y, 100)
                            self._touch_state[pointer_id] = (x, y)
                elif action == "up":
                    start = self._touch_state.pop(pointer_id, None)
                    if start:
                        sx, sy = start
                        dist = ((x - sx) ** 2 + (y - sy) ** 2) ** 0.5
                        if dist < 15:
                            await self._runtime.tap(x, y)
                        else:
                            await self._runtime.swipe(sx, sy, x, y, 200)

        elif msg_type == "scroll":
            x, y = int(msg.get("x", 0)), int(msg.get("y", 0))
            dx = msg.get("dx", 0)
            dy = msg.get("dy", 0)
            sens = self._config.scroll_sensitivity
            if self._scrcpy and self._scrcpy.control_ready and sw and sh:
                raw_x = -dx / 120.0
                raw_y = -dy / 120.0
                scroll_x = max(-1.0, min(1.0, math.copysign(abs(raw_x) ** 0.6, raw_x) * sens))
                scroll_y = max(-1.0, min(1.0, math.copysign(abs(raw_y) ** 0.6, raw_y) * sens))
                self._scrcpy.inject_scroll_event(x, y, sw, sh, scroll_x=scroll_x, scroll_y=scroll_y)
            else:
                direction = 1 if dy < 0 else -1
                await self._runtime.swipe(x, y, x, y + direction * 200, 200)

        elif msg_type == "key":
            key_action = msg.get("action", "down")
            keycode_name = msg.get("keycode", "")
            if keycode_name:
                code = ScrcpyAdapter._ANDROID_KEYCODE_MAP.get(keycode_name)
                if self._scrcpy and self._scrcpy.control_ready and code is not None:
                    self._scrcpy.inject_keycode(key_action, code)
                elif key_action == "up":
                    await self._runtime.press_key(keycode_name)

        elif msg_type == "text":
            text = msg.get("content", "")
            if text:
                await self._runtime.type_text(text)

        elif msg_type == "back":
            if not await self._inject_back_via_control():
                await self._runtime.press_key("KEYCODE_BACK")

        elif msg_type == "home":
            if not await self._inject_home_via_control():
                await self._runtime.press_key("KEYCODE_HOME")

        elif msg_type == "configure":
            if self._scrcpy:
                self._scrcpy.configure(
                    max_fps=msg.get("maxFps"),
                    max_width=msg.get("maxWidth"),
                    bitrate=msg.get("bitrate"),
                )

        else:
            logger.debug("Unknown DataChannel message type: %s", msg_type)

    async def _inject_back_via_control(self) -> bool:
        if not self._scrcpy or not self._scrcpy.control_ready:
            return False
        self._scrcpy.inject_back_or_screen_on("down")
        self._scrcpy.inject_back_or_screen_on("up")
        return True

    async def _inject_home_via_control(self) -> bool:
        if not self._scrcpy or not self._scrcpy.control_ready:
            return False
        self._scrcpy.inject_keycode("down", 3)  # KEYCODE_HOME
        self._scrcpy.inject_keycode("up", 3)
        return True
