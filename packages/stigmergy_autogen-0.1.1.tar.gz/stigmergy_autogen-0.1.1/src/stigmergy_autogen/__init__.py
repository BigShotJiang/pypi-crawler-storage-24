"""Stigmergy pressure-field scheduling adapter for AutoGen.

Replaces AutoGen's SelectorGroupChat speaker selection with pressure-based scheduling.
Instead of LLM-based selection, agents are chosen based on accumulated pheromone
signal pressure with dependency resolution.

Usage:
    from autogen_agentchat.agents import AssistantAgent
    from autogen_agentchat.teams import SelectorGroupChat
    from stigmergy_autogen import StigmergySpeakerSelector

    selector = StigmergySpeakerSelector(wake_threshold=0.4)
    selector.register_task("research", agent_name="researcher", priority=0.8)
    selector.register_task("analyze", agent_name="analyst", deps=["research"])

    team = SelectorGroupChat(
        participants=[researcher, analyst],
        model_client=model_client,
        selector_func=selector.select_speaker,
    )
"""

from stigmergy_autogen.adapter import StigmergySpeakerSelector

__all__ = ["StigmergySpeakerSelector"]
