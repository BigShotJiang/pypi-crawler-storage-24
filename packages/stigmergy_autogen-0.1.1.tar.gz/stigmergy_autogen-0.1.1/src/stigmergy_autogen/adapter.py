"""AutoGen adapter: pressure-field speaker selection for SelectorGroupChat.

Uses StigmergyScheduler internally for dependency resolution and pressure
computation. The adapter maps AutoGen's speaker selection contract to the
scheduler's pressure model.

Compatible with AutoGen v0.7+ (autogen-agentchat).
"""

from __future__ import annotations

import asyncio
from typing import Any, Sequence

from stigmergy import StigmergyScheduler, TaskSpec, DispatchResult, SchedulerMetrics

try:
    from autogen_agentchat.messages import BaseAgentEvent, BaseChatMessage
except ImportError as e:
    raise ImportError(
        "autogen-agentchat is required: pip install stigmergy-autogen"
    ) from e


class StigmergySpeakerSelector:
    """Pressure-field speaker selection for AutoGen SelectorGroupChat.

    Replaces the default LLM-based speaker selection with stigmergy
    pressure signals. Tasks are assigned to agents with priorities and
    dependencies. The selector picks the agent with the highest pressure
    whose task dependencies are met.

    Example::

        from autogen_agentchat.agents import AssistantAgent
        from autogen_agentchat.teams import SelectorGroupChat

        selector = StigmergySpeakerSelector(wake_threshold=0.4)
        selector.register_task("research", agent_name="researcher", priority=0.8)
        selector.register_task("review", agent_name="reviewer", deps=["research"])

        team = SelectorGroupChat(
            participants=[researcher, reviewer],
            model_client=model_client,
            selector_func=selector.select_speaker,
        )
    """

    def __init__(
        self,
        wake_threshold: float = 0.4,
        decay_half_life: float = 300.0,
        evaporation_threshold: float = 0.01,
    ):
        self._scheduler = StigmergyScheduler(
            tick_interval=0.01,
            wake_threshold=wake_threshold,
            decay_half_life=decay_half_life,
            evaporation_threshold=evaporation_threshold,
        )
        self._task_agent_map: dict[str, str] = {}
        self._wake_threshold = wake_threshold

    def register_task(
        self,
        task_id: str,
        agent_name: str,
        priority: float = 0.5,
        deps: list[str] | None = None,
        description: str = "",
    ) -> None:
        """Register a task to be scheduled via pressure signals.

        Args:
            task_id: Unique task identifier.
            agent_name: The ``name`` attribute of the AutoGen agent.
            priority: Signal intensity (0.0-1.0).
            deps: Task IDs that must complete first.
            description: Human-readable description.
        """
        self._task_agent_map[task_id] = agent_name
        task = TaskSpec(
            id=task_id,
            description=description or task_id,
            agent_id=agent_name,
            priority=priority,
            dependencies=deps or [],
        )
        self._run_async(self._scheduler.add_task(task))

    def mark_complete(self, task_id: str) -> None:
        """Manually mark a task as completed."""
        if task_id in self._scheduler._tasks:
            self._scheduler._completed.add(task_id)
            self._run_async(self._scheduler.field.deposit(
                agent_id=self._task_agent_map.get(task_id, "system"),
                signal_type="task_complete",
                intensity=0.6,
                metadata={"task_id": task_id},
            ))

    def select_speaker(
        self,
        messages: Sequence[BaseAgentEvent | BaseChatMessage],
    ) -> str | None:
        """Speaker selection function for SelectorGroupChat.

        Pass this method as ``selector_func`` to SelectorGroupChat.
        Returns the agent name with the highest pressure whose task
        dependencies are met, or None to fall back to default selection.
        """
        # Auto-detect completions from message history
        self._detect_completions(messages)

        # Decay signals
        self._run_async(self._scheduler.field.decay())

        # Find available tasks (deps met, not completed)
        available = self._scheduler._available_tasks()
        if not available:
            return None

        # Pick agent with highest pressure
        best_name: str | None = None
        best_pressure = -1.0

        for task in available:
            pressure = self._run_async(
                self._scheduler.field.read_pressure(task.agent_id)
            )
            pressure += task.priority * 0.3

            if pressure >= self._wake_threshold and pressure > best_pressure:
                best_pressure = pressure
                best_name = task.agent_id

        return best_name

    def _detect_completions(
        self,
        messages: Sequence[BaseAgentEvent | BaseChatMessage],
    ) -> None:
        """Infer task completions from message history."""
        if not messages:
            return

        speakers_seen: set[str] = set()
        for msg in messages:
            source = getattr(msg, "source", None)
            if source:
                speakers_seen.add(source)

        for task in self._scheduler._tasks.values():
            if task.id not in self._scheduler._completed and task.agent_id in speakers_seen:
                if all(d in self._scheduler._completed for d in task.dependencies):
                    self.mark_complete(task.id)

    @property
    def is_complete(self) -> bool:
        """True if all registered tasks are completed."""
        return self._scheduler.is_complete()

    @property
    def metrics(self) -> SchedulerMetrics:
        """Current scheduling metrics."""
        return self._scheduler.get_metrics()

    @staticmethod
    def _run_async(coro: Any) -> Any:
        """Run an async coroutine from sync context without breaking existing loops."""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            # Inside an existing async context: run in a thread
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                return pool.submit(lambda: asyncio.run(coro)).result()
        else:
            return asyncio.run(coro)
