"""Tests for AutoGen adapter — mocks autogen-agentchat to test scheduling logic."""

import sys
from types import ModuleType
from dataclasses import dataclass

# Mock autogen_agentchat before importing adapter
_mock_autogen = ModuleType("autogen_agentchat")
_mock_messages = ModuleType("autogen_agentchat.messages")


@dataclass
class BaseChatMessage:
    source: str
    content: str = ""


@dataclass
class BaseAgentEvent:
    source: str
    content: str = ""


_mock_messages.BaseChatMessage = BaseChatMessage
_mock_messages.BaseAgentEvent = BaseAgentEvent

sys.modules["autogen_agentchat"] = _mock_autogen
sys.modules["autogen_agentchat.messages"] = _mock_messages

from stigmergy_autogen import StigmergySpeakerSelector


def test_single_task_selects_agent():
    selector = StigmergySpeakerSelector(wake_threshold=0.3)
    selector.register_task("research", agent_name="researcher", priority=0.8)

    chosen = selector.select_speaker([])
    assert chosen == "researcher"


def test_dependency_blocks_selection():
    selector = StigmergySpeakerSelector(wake_threshold=0.3)
    selector.register_task("research", agent_name="researcher", priority=0.8)
    selector.register_task("write", agent_name="writer", priority=0.6, deps=["research"])

    # Before research completes, only researcher should be available
    chosen = selector.select_speaker([])
    assert chosen == "researcher"


def test_dependency_unblocks_after_completion():
    selector = StigmergySpeakerSelector(wake_threshold=0.3)
    selector.register_task("research", agent_name="researcher", priority=0.8)
    selector.register_task("write", agent_name="writer", priority=0.6, deps=["research"])

    # Simulate researcher speaking (auto-detection)
    messages = [BaseChatMessage(source="researcher", content="done")]
    chosen = selector.select_speaker(messages)

    # research should be auto-completed, writer should now be available
    assert chosen == "writer"


def test_manual_mark_complete():
    selector = StigmergySpeakerSelector(wake_threshold=0.3)
    selector.register_task("t1", agent_name="bot1", priority=0.8)
    selector.register_task("t2", agent_name="bot2", priority=0.6, deps=["t1"])

    selector.mark_complete("t1")
    chosen = selector.select_speaker([])
    assert chosen == "bot2"


def test_is_complete():
    selector = StigmergySpeakerSelector(wake_threshold=0.3)
    selector.register_task("t1", agent_name="bot", priority=0.8)

    assert not selector.is_complete
    selector.mark_complete("t1")
    assert selector.is_complete


def test_all_done_returns_none():
    selector = StigmergySpeakerSelector(wake_threshold=0.3)
    selector.register_task("t1", agent_name="bot", priority=0.8)
    selector.mark_complete("t1")

    chosen = selector.select_speaker([])
    assert chosen is None


def test_metrics():
    selector = StigmergySpeakerSelector(wake_threshold=0.3)
    selector.register_task("t1", agent_name="bot", priority=0.8)

    metrics = selector.metrics
    assert metrics.pending_tasks >= 0


def test_three_agent_chain():
    selector = StigmergySpeakerSelector(wake_threshold=0.3)
    selector.register_task("research", agent_name="researcher", priority=0.8)
    selector.register_task("analyze", agent_name="analyst", priority=0.6, deps=["research"])
    selector.register_task("write", agent_name="writer", priority=0.5, deps=["analyze"])

    # Step 1: only researcher available
    assert selector.select_speaker([]) == "researcher"

    # Step 2: researcher done, analyst available
    msgs = [BaseChatMessage(source="researcher")]
    assert selector.select_speaker(msgs) == "analyst"

    # Step 3: analyst done, writer available
    msgs.append(BaseChatMessage(source="analyst"))
    assert selector.select_speaker(msgs) == "writer"

    # Step 4: all done
    msgs.append(BaseChatMessage(source="writer"))
    assert selector.select_speaker(msgs) is None
    assert selector.is_complete
