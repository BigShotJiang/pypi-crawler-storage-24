# stigmergy-autogen

**Replace AutoGen's LLM-based speaker selection with deterministic pressure signals.** Stop paying for an LLM call every time you need to pick who speaks next. Tasks, priorities, and dependencies drive selection instead.

One-line integration with [AutoGen](https://github.com/microsoft/autogen) v0.7+ `SelectorGroupChat`.

## Install

```bash
pip install stigmergy-autogen
```

## Usage

```python
from autogen_agentchat.agents import AssistantAgent
from autogen_agentchat.teams import SelectorGroupChat
from stigmergy_autogen import StigmergySpeakerSelector

# Create AutoGen agents
researcher = AssistantAgent("researcher", model_client=model_client)
analyst = AssistantAgent("analyst", model_client=model_client)
writer = AssistantAgent("writer", model_client=model_client)

# Create stigmergy selector with tasks and dependencies
selector = StigmergySpeakerSelector(wake_threshold=0.4)
selector.register_task("research", agent_name="researcher", priority=0.8)
selector.register_task("analyze", agent_name="analyst", priority=0.6, deps=["research"])
selector.register_task("write", agent_name="writer", priority=0.5, deps=["analyze"])

# Use as SelectorGroupChat selector_func
team = SelectorGroupChat(
    participants=[researcher, analyst, writer],
    model_client=model_client,
    selector_func=selector.select_speaker,
)

result = await team.run(task="Begin research on AI trends")
```

## How It Works

The `StigmergySpeakerSelector` replaces AutoGen's default speaker selection:
1. Each registered task deposits a pressure signal targeted at its agent
2. On each turn, signals decay and the selector picks the agent with highest pressure
3. Task dependencies are enforced — an agent won't be selected until its deps complete
4. Completion signals propagate pressure to downstream agents

## License

MIT
