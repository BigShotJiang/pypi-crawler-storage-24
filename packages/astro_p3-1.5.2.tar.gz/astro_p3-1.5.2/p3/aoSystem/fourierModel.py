#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Sep  1 16:31:39 2020

@author: omartin
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 16 15:00:44 2018

@author: omartin
"""

import numpy as nnp
from . import gpuEnabled, np, nnp, fft, spc, cpuArray, trapz
import matplotlib as mpl
import matplotlib.pyplot as plt

import time
from distutils.spawn import find_executable

import p3.aoSystem.FourierUtils as FourierUtils
from p3.aoSystem.aoSystem import aoSystem
from p3.aoSystem.atmosphere import atmosphere
from p3.aoSystem.frequencyDomain import frequencyDomain
from p3.aoSystem.airRefraction import MatharAirRefraction

#%% DISPLAY FEATURES
mpl.rcParams['font.size'] = 16

if find_executable('tex'):
    usetex = True
else:
    usetex = False

plt.rcParams.update({
    "text.usetex": usetex,
    "font.family": "serif",
    "font.serif": ["Palatino","DejaVu Sans"],
})

#%%
rad2mas = 3600 * 180 * 1000 / np.pi
rad2arc = rad2mas / 1000
deg2rad = np.pi/180


def besselj__n(n, z):
    if n<0:
        return -1**(-n) * besselj__n(-n, z)
    if n==0:
        return spc.j0(z)
    elif n==1:
        return spc.j1(z)
    elif n>=2:
        return 2*(n-1)*besselj__n(int(n)-1, z)/z - besselj__n(int(n)-2, z)

class fourierModel:
    """
    Fourier class gathering the PSD calculation for PSF reconstruction and
    fast analytic simulations.
    """

    # CONTRUCTOR
    def __init__(self, path_ini, calcPSF=True, verbose=False, display=True,
                 path_root=None, normalizePSD=False, displayContour=False,
                 getPSDatNGSpositions=False, getErrorBreakDown=False, getFWHM=False,
                 getEnsquaredEnergy=False, getEncircledEnergy=False, fftphasor=False,
                 MV=0, nyquistSampling=False, addOtfPixel=False, freq=None, ao=None,
                 computeFocalAnisoCov=True, TiltFilter=False, doComputations=True,
                 psdExpansion=False, reduce_memory=False):

        tstart = time.time()

        # COLLECTING INPUTS
        self.verbose = verbose
        self.path_ini = path_ini
        self.display = display
        self.displayContour = displayContour
        self.getErrorBreakDown = getErrorBreakDown
        self.get_metrics = getFWHM or getEnsquaredEnergy or getEncircledEnergy
        self.calcPSF = calcPSF
        self.tag = 'TIPTOP'
        self.addOtfPixel = addOtfPixel
        self.nyquistSampling = nyquistSampling
        self.computeFocalAnisoCov = computeFocalAnisoCov
        self.MV = MV
        self.TiltFilterP = TiltFilter
        self.normalizePSD = normalizePSD
        self.fftphasor = fftphasor
        self.getFWHM = getFWHM
        self.getEnsquaredEnergy = getEnsquaredEnergy
        self.getEncircledEnergy = getEncircledEnergy
        self.reduce_memory = reduce_memory

        if freq is not None:
            self.freq = freq

        # DEFINING THE NUMBER OF PSF PARAMETERS
        self.tag = "TIPTOP"
        self.param_labels = ['jitterX', 'jitterY', 'jitterXY',
                             'F', 'dx', 'dy', 'bkg', 'stat']
        self.n_param_atm = 0
        self.n_param_dphi = 0

        # GRAB PARAMETERS
        if ao is None:
            self.ao = aoSystem(path_ini, path_root=path_root,
                               getPSDatNGSpositions=getPSDatNGSpositions,
                               psdExpansion=psdExpansion,
                               verbose=verbose)
        else:
            self.ao = ao
        self.dtype = self.ao.dtype
        self.complex_dtype = self.ao.complex_dtype
        self.my_data_map = self.ao.my_data_map

        self.t_initAO = 1000*(time.time() - tstart)

        self.t_init = 0
        self.t_initFreq = 0
        self.t_atmo = 0
        self.t_powerSpectrumDensity = 0
        self.t_reconstructor = 0
        self.t_finalReconstructor = 0
        self.t_tomo = 0
        self.t_opt = 0
        self.t_controller = 0
        self.t_fittingPSD = 0
        self.t_aliasingPSD = 0
        self.t_noisePSD = 0
        self.t_spatioTemporalPSD = 0
        self.t_windShakePSD = 0
        self.t_focalAnisoplanatism = 0
        self.t_errorBreakDown = 0
        self.t_getPsfMetrics = 0
        self.t_displayResults = 0
        self.t_getPSF = 0
        self.t_focalAnisoplanatism = 0
        self.t_mcaoWFsensCone = 0
        self.t_extra = 0
        self.t_extraLo = 0
        self.t_tiltFilter = 0
        self.t_focusFilter = 0
        self.t_errorBreakDown = 0
        self.t_getPsfMetrics = 0
        self.nGs = 0

        if doComputations:
            self.initComputations()

    def set_precision(self, precision):
        """
        Set the dtype and complex_dtype for the model.
        precision: 'single' or 'double'
        """
        if precision == 'single':
            self.dtype = np.float32
            self.complex_dtype = np.complex64
        elif precision == 'double':
            self.dtype = np.float64
            self.complex_dtype = np.complex128
        else:
            raise ValueError("precision must be 'single' or 'double'")

    def initComputations(self):

        tstart = time.time()

        if self.ao.error is False:

            # DEFINING THE FREQUENCY DOMAIN
            self.wvl, self.nwvl = FourierUtils.create_wavelength_vector(self.ao,
                                                                        dtype=self.dtype)
            if not hasattr(self, 'freq'):
                self.freq = frequencyDomain(
                    self.ao,
                    nyquistSampling=self.nyquistSampling,
                    computeFocalAnisoCov=self.computeFocalAnisoCov,
                    dtype=self.dtype
                )
            self.t_initFreq = 1000*(time.time() - tstart)

            # DEFINING THE GUIDE STAR AND THE STRECHING FACTOR
            if self.ao.lgs:
                self.gs = self.ao.lgs
                self.nGs = self.ao.lgs.nSrc
                if self.gs.height[0]!=0:
                    self.strechFactor = 1.0/(1.0 - self.ao.atm.heights/self.gs.height[0])
                else:
                    self.strechFactor = 1.0
            else:
                self.gs = self.ao.ngs
                self.nGs = self.ao.ngs.nSrc
                self.strechFactor = 1.0

            # DEFINING THE REFRACTIVE INDEX OF THE AIR AT THE REFERENCE AND GUIDE STAR WAVELENGTH
            mathar_model = MatharAirRefraction()
            self.n_air_wvlRef = np.asarray(mathar_model.get_refractive_index(self.freq.wvlRef),
                                           dtype=self.dtype)
            self.n_air_gs = np.asarray(mathar_model.get_refractive_index(self.gs.wvl[0]),
                                       dtype=self.dtype)

            # DEFINING THE MODELED ATMOSPHERE
            if (self.ao.dms.nRecLayers!=None) and \
                (self.ao.dms.nRecLayers < len(self.ao.atm.weights)):
                weights_mod,heights_mod = FourierUtils.eqLayers(
                    self.ao.atm.weights,
                    self.ao.atm.heights,
                    self.ao.dms.nRecLayers,
                    dtype=self.dtype
                )
                if self.ao.dms.nRecLayers == 1:
                    heights_mod = [0.0]
                wSpeed_mod = cpuArray(
                    np.linspace(min(self.ao.atm.wSpeed),
                                max(self.ao.atm.wSpeed),
                                num=self.ao.dms.nRecLayers)
                )
                wDir_mod   = cpuArray(
                    np.linspace(min(self.ao.atm.wDir),
                                max(self.ao.atm.wDir),
                                num=self.ao.dms.nRecLayers)
                )
                if self.ao.lgs:
                    # Recalculate stretch factor for modeled atmosphere
                    self.strechFactor_mod = 1.0/(1.0 - heights_mod/self.gs.height[0])
                else:
                    self.strechFactor_mod = 1.0
            else:
                weights_mod    = self.ao.atm.weights
                heights_mod    = self.ao.atm.heights
                wSpeed_mod     = self.ao.atm.wSpeed
                wDir_mod       = self.ao.atm.wDir
                self.strechFactor_mod = self.strechFactor

            self.atm_mod = atmosphere(
                self.ao.atm.wvl,
                self.ao.atm.r0,
                cpuArray(weights_mod),
                cpuArray(heights_mod),
                cpuArray(wSpeed_mod),
                cpuArray(wDir_mod),
                self.ao.atm.L0
            )

            self.t_atmo = 1000*(time.time() - self.t_initFreq/1000 - tstart)

            vv = np.asarray(self.freq.psInMas)
            kc = np.asarray(self.freq.kcInMas)
            if vv.size == 1:
                # Single-wavelength path: vv may be 0-D or length-1 array
                rr = 2.0 * kc / vv
            else:
                # Multi-wavelength case: take the worst requirement
                # for each DM across all wavelengths
                rr = np.max(2.0 * kc[:, None] / vv[None, :], axis=1)
            # FoV check: ensure the worst case across all DMs
            if np.max(rr) > self.freq.nOtf:
                raise ValueError('Error : the PSF field of view is too small'
                                 ' to simulate the AO correction area\n')

            # DEFINING THE NOISE PSD
            if self.ao.wfs.processing.noiseVar == [None]:
                wvl_gs = self.gs.wvl[0]
                self.ao.wfs.processing.noiseVar = self.ao.wfs.computeNoiseVarianceAtWavelength(
                    wvl_science=self.freq.wvlRef,
                    wvl_wfs=wvl_gs,
                    r0_at_500nm=self.ao.atm.r0,
                )

            # Updating the atmosphere wavelength !
            # after noise PSD computation where r0 at 500 nm is needed
            self.ao.atm.wvl  = self.freq.wvlRef
            self.atm_mod.wvl = self.freq.wvlRef

            # DEFINING THE ATMOSPHERE PSD
            self.Wn = np.mean(self.ao.wfs.processing.noiseVar) / (2*self.freq.kcMax_)**2
            self.Wphi = self.ao.atm.spectrum(np.sqrt(self.freq.k2AO_))

            # DEFINE THE RECONSTRUCTOR
            self.spatialReconstructor(MV=self.MV)

            # DEFINE THE CONTROLLER
            self.controller(display=self.display)

            #set tilt filter key before computing the PSD
            self.applyTiltFilter = self.TiltFilterP

            # COMPUTE THE PSD
            if self.normalizePSD == True:
                wfe = self.ao.rtc.holoop['wfe']
            else:
                wfe = None
            self.PSD = self.powerSpectrumDensity(wfe=wfe)

            # COMPUTE THE PSF
            if self.calcPSF:
                # COMPUTE THE PHASE STRUCTURE FUNCTION
                self.SF = self.phaseStructureFunction()
                self.PSF, self.SR = self.point_spread_function(
                    verbose=self.verbose,fftphasor=self.fftphasor,addOtfPixel=self.addOtfPixel
                )

                # GETTING METRICS
                if self.getFWHM == True or self.getEnsquaredEnergy==True \
                  or self.getEncircledEnergy==True:
                    self.getPsfMetrics(getEnsquaredEnergy=self.getEnsquaredEnergy, \
                        getEncircledEnergy=self.getEncircledEnergy,getFWHM=self.getFWHM)

                # DISPLAYING THE PSFS
                if self.display:
                    self.displayResults(displayContour=self.displayContour)

            # COMPUTE THE ERROR BREAKDOWN
            if self.getErrorBreakDown:
                self.errorBreakDown(verbose=self.verbose)

        # DEFINING BOUNDS
        self.bounds = self.define_bounds()

        self.t_init = 1000*(time.time()  - tstart)

        # DISPLAYING EXECUTION TIMES
        if self.verbose:
            self.displayExecutionTime()

    def __repr__(self):
        s = '\t\t\t\t________________________ FOURIER MODEL ________________________\n\n'
        s += self.ao.__repr__() + '\n'
        s += self.freq.__repr__() + '\n'
        s +=  '\n'
        return s

#%% BOUNDS FOR PSF-FITTING
    def define_bounds(self):
        """
            Defines the bounds for the PSF model parameters :
                Cn2/r0, jitterX, jitterY, jitterXY, dx, dy, bg, stat
        """

        # Photometry
        bounds_down = [-nnp.inf,-nnp.inf,-nnp.inf]
        bounds_up = [nnp.inf,nnp.inf,nnp.inf]
        # Photometry
        bounds_down += nnp.zeros(self.ao.src.nSrc).tolist()
        bounds_up += (nnp.inf*nnp.ones(self.ao.src.nSrc)).tolist()
        # Astrometry
        bounds_down += (-self.freq.nPix//2 * np.ones(2*self.ao.src.nSrc,
                                                     dtype=self.dtype)).tolist()
        bounds_up += ( self.freq.nPix//2 * np.ones(2*self.ao.src.nSrc,
                                                   dtype=self.dtype)).tolist()
        # Background
        bounds_down += [-nnp.inf]
        bounds_up += [nnp.inf]

        return (bounds_down,bounds_up)

#%% RECONSTRUCTOR DEFINITION
    def spatialReconstructor(self, MV=0):
        """
        Computes the WFS spatial reconstructor and the tomographic reconstructor
        for tomographic AO systems.
        """

        tstart = time.time()
        if self.nGs<2:
            # SINGLE AO SYSTEM
            self.reconstructionFilter(MV=MV)
        else:
            # TOMOGRAPHIC SYSTEM
            self.Wtomo = self.tomographicReconstructor()
            self.Popt = self.optimalProjector()
            self.W = np.matmul(self.Popt, self.Wtomo)
            if self.reduce_memory:
                self.Popt = None
                self.Wtomo = None

            # Computation of the Pbeta^DM matrix
            k = np.sqrt(self.freq.k2AO_)
            h_dm = self.ao.dms.heights
            nDm = len(h_dm)
            nK = self.freq.resAO
            i = self.complex_dtype(1j)
            nH = self.ao.atm.nL
            Hs = self.ao.atm.heights * self.strechFactor
            #d = self.freq.pitch[0]
            d_sub = [self.ao.wfs.optics[j].dsub for j in range(self.nGs)]   #sub-aperture size
            clock_rate = [self.ao.wfs.detector[j].clock_rate for j in range(self.nGs)]
            sampTime = 1/self.ao.rtc.holoop['rate']

            self.PbetaDM = []
            for s in range(self.ao.src.nSrc):
                fx = self.ao.src.direction[0, s]*self.freq.kxAO_
                fy = self.ao.src.direction[1, s]*self.freq.kyAO_
                PbetaDM = np.zeros([nK, nK, 1, nDm],
                                   dtype=self.complex_dtype)
                for j in range(nDm): #loop on DMs
                    index = k<=self.freq.kc_[j] # note : circular masking
                    PbetaDM[index, 0, j] = np.exp(2*i*np.pi*h_dm[j]*(fx[index] + fy[index]))
                self.PbetaDM.append(PbetaDM)

            # Computation of the Malpha matrix
            wDir_x = nnp.cos(self.ao.atm.wDir*np.pi/180)
            wDir_y = nnp.sin(self.ao.atm.wDir*np.pi/180)
            self.MPalphaL = np.zeros([nK, nK, self.nGs, nH],
                                     dtype=self.complex_dtype)
            for h in range(nH):
                freq_t = wDir_x[h]*self.freq.kxAO_ + wDir_y[h]*self.freq.kyAO_
                for g in range(self.nGs):
                    Alpha = [self.gs.direction[0, g],self.gs.direction[1, g]]
                    fx = Alpha[0]*self.freq.kxAO_
                    fy = Alpha[1]*self.freq.kyAO_
                    www = 2*i*np.pi*k * np.sinc(sampTime*clock_rate[g]*self.ao.atm.wSpeed[h]*freq_t)
                    self.MPalphaL[:, :, g, h] = www*np.sinc(d_sub[g]*self.freq.kxAO_)\
                                                   *np.sinc(d_sub[g]*self.freq.kyAO_)\
                                                   *np.exp(i*2*np.pi*Hs[h]*(fx+fy))
            fx = None
            fy = None
            self.Walpha = np.matmul(self.W,self.MPalphaL)
        if self.reduce_memory:
            self.MPalphaL = None
        self.t_finalReconstructor = 1000*(time.time() - tstart)

    def reconstructionFilter(self, MV=0):
        """
        Reconstructs the WFS spatial filters. If MV = 1, uses the Minimum Variance
        reconstructor by accounting for the noise variance.
        """
        tstart = time.time()
        # reconstructor derivation
        i = self.complex_dtype(1j)
        d = self.ao.wfs.optics[0].dsub

        if self.ao.wfs.optics[0].wfstype.upper()=='SHACK-HARTMANN':
            Sx = 2*i*np.pi*self.freq.kxAO_*d
            Sy = 2*i*np.pi*self.freq.kyAO_*d
            Av = np.sinc(d*self.freq.kxAO_) * np.sinc(d*self.freq.kyAO_)\
                 * np.exp(i*np.pi*d*(self.freq.kxAO_ + self.freq.kyAO_))

        elif self.ao.wfs.optics[0].wfstype.upper()=='PYRAMID':
            # forward pyramid filter (continuous) from Conan
            umod = 1/(2*d)/(self.ao.wfs.optics[0].nL/2)*self.ao.wfs.optics[0].modulation
            Sx = np.zeros((self.freq.resAO,self.freq.resAO),
                          dtype=self.complex_dtype)
            idx = abs(self.freq.kxAO_) > umod
            Sx[idx] = i * np.sign(self.freq.kxAO_[idx])
            idx = abs(self.freq.kxAO_) <= umod
            Sx[idx] = 2*i/np.pi * np.arcsin(self.freq.kxAO_[idx]/umod)
            Av = np.sinc(self.ao.wfs.detector[0].binning*d*self.freq.kxAO_)\
                * np.sinc(self.ao.wfs.detector[0].binning*d*self.freq.kxAO_).T
            Sy = Sx.T
        else:
            raise ValueError("The WFS type is not supported; must be Shack-Hartmann or Pyramid.")
        self.SxAv = (Sx*Av).astype(self.complex_dtype)
        self.SyAv = (Sy*Av).astype(self.complex_dtype)
        Sx = None
        Sy = None
        Av = None

        # Reconstructor
        wvl_gs = self.gs.wvl[0]
        Watm = self.ao.atm.spectrum(np.sqrt(self.freq.k2AO_)) * (self.ao.atm.wvl/wvl_gs)**2
        gPSD = abs(self.SxAv)**2 + abs(self.SyAv)**2 + MV*self.Wn/Watm
        Watm = None
        self.Rx = (np.conj(self.SxAv)/gPSD).astype(self.complex_dtype)
        self.Ry = (np.conj(self.SyAv)/gPSD).astype(self.complex_dtype)
        gPSD = None

        # Set central point (i.e. kx=0,ky=0) to zero
        self.Rx[self.freq.resAO//2, self.freq.resAO//2] = 0
        self.Ry[self.freq.resAO//2, self.freq.resAO//2] = 0

        self.t_reconstructor = 1000*(time.time()  - tstart)

    def tomographicReconstructor(self):
        """
        Computes the tomographic reconstructor based on Neichel+09.
        
        Here we forced single precision for the matrix multiplications to save memory and
        speed up computations, as the tomographic reconstructor is not very sensitive to
        precision.
        """
        tstart = time.time()
        k = np.sqrt(self.freq.k2AO_)
        nK = self.freq.resAO
        nL = len(self.ao.atm.heights)
        h_mod = self.atm_mod.heights*self.strechFactor_mod
        nL_mod = len(h_mod)
        nGs = self.nGs
        i = np.complex64(1j)
        d = [self.ao.wfs.optics[j].dsub for j in range(nGs)]   #sub-aperture size

        # WFS operator and projection matrices
        M = np.zeros([nK, nK, nGs, nGs],
                     dtype=self.complex_dtype)
        P = np.zeros([nK, nK, nGs, nL_mod],
                     dtype=self.complex_dtype)
        for j in range(nGs):
            M[:, :, j, j] = 2*i*np.pi*k * np.sinc(d[j]*self.freq.kxAO_)\
                            * np.sinc(d[j]*self.freq.kyAO_)
            for n in range(nL_mod):
                P[:, :, j, n] = np.exp(i*2*np.pi*h_mod[n]\
                                        *(self.freq.kxAO_*self.gs.direction[0, j]
                                        + self.freq.kyAO_*self.gs.direction[1, j]))
        self.M = M
        MP = np.matmul(self.M,P)
        P = None
        if self.reduce_memory:
            self.M = None

        # Noise covariance matrix
        self.Cb = np.ones((nK,nK,nGs,nGs),
                          dtype=self.dtype)*np.diag(self.ao.wfs.processing.noiseVar)

        # Atmospheric PSD with the true atmosphere
        self.Cphi = np.zeros([nK,nK,nL,nL],
                             dtype=self.complex_dtype)
        cte = (24 * spc.gamma(6/5)/5)**(5/6) \
               * (spc.gamma(11/6)**2. / (2.*np.pi**(11/3))).astype(self.dtype)
        kernel = (self.ao.atm.r0**(-5/3) * cte \
            * (self.freq.k2AO_ + 1/self.ao.atm.L0**2)**(-11/6) \
            * self.freq.pistonFilterAO_).astype(self.dtype)
        self.Cphi = kernel.repeat(nL**2, axis=1)
        self.Cphi = self.Cphi.reshape((nK, nK, nL, nL)) * np.diag(self.ao.atm.weights)

        # Atmospheric PSD with the modelled atmosphere
        if nL_mod == nL:
            self.Cphi_mod = self.Cphi
        else:
            self.Cphi_mod = kernel.repeat(nL_mod**2, axis=1)
            self.Cphi_mod = self.Cphi_mod.reshape((nK, nK, nL_mod, nL_mod)) \
                * np.diag(self.atm_mod.weights)
        kernel = None

        MP_t = np.conj(MP.transpose(0, 1, 3, 2))
        to_inv  = np.matmul(np.matmul(MP, self.Cphi_mod), MP_t) + self.Cb
        rhs = np.matmul(self.Cphi_mod, MP_t)

        # Try using solve (faster), fallback to pinv if fails
        try:
            # Standard solve
            if self.verbose:
                print("Tomography: Using standard solve")
            Wtomo = np.linalg.solve(
                to_inv.astype(np.complex64).transpose(0, 1, 3, 2),
                rhs.astype(np.complex64).transpose(0, 1, 3, 2)
            ).transpose(0, 1, 3, 2)
        except np.linalg.LinAlgError as e:
            # Fallback: Use pinv for singular/ill-conditioned matrices
            if self.verbose:
                print(f"Tomography: Standard solve failed ({e}), using pinv")
            inv = np.linalg.pinv(to_inv.astype(np.complex64),
                                 rcond=np.finfo(np.float32).eps)
            Wtomo = np.matmul(rhs, inv)

        to_inv = None

        return Wtomo

    def optimalProjector(self):
        """
        Computes the projector from layers to DM from Neichel+09.
        
        Here we forced single precision for the matrix multiplications
        to save memory and speed up computations, as the optimal projector
        is not very sensitive to precision.
        """
        tstart = time.time()
        k = np.sqrt(self.freq.k2AO_)
        h_dm = self.ao.dms.heights
        nDm = len(h_dm)
        nDir = len(self.ao.dms.opt_dir[0])
        h_mod = self.atm_mod.heights * cpuArray(self.strechFactor_mod)
        nL = len(h_mod)
        nK = self.freq.resAO
        i = np.complex64(1j)

        mat1 = np.zeros([nK, nK, nDm, nL],
                        dtype=np.complex64)
        to_inv = np.zeros([nK, nK, nDm, nDm],
                          dtype=np.complex64)
        theta_x = self.ao.dms.opt_dir[0]/206264.8 \
                * nnp.cos(self.ao.dms.opt_dir[1]*np.pi/180)
        theta_y = self.ao.dms.opt_dir[0]/206264.8 \
                * nnp.sin(self.ao.dms.opt_dir[1]*np.pi/180)

        Pdm = np.zeros([nK, nK, 1, nDm],
                       dtype=np.complex64)
        Pl = np.zeros([nK, nK, 1, nL],
                      dtype=np.complex64)
        Pdm_t = np.zeros([nK, nK, nDm, 1],
                         dtype=np.complex64)
        for d_o in range(nDir):                 #loop on optimization directions
            Pdm.fill(0)
            Pl.fill(0)
            fx = theta_x[d_o]*self.freq.kxAO_
            fy = theta_y[d_o]*self.freq.kyAO_
            for j in range(nDm):                # loop on DM
                index = k <= self.freq.kc_[j] # note : circular masking here
                Pdm[index, 0, j] = np.exp(i*2*np.pi*h_dm[j]*(fx[index]+fy[index]))
            Pdm_t[:] = np.conj(Pdm.transpose(0, 1, 3, 2))
            for l in range(nL):                 #loop on atmosphere layers
                Pl[:, :, 0, l] = np.exp(i*2*np.pi*h_mod[l]*(fx + fy))
            mat1 += np.matmul(Pdm_t, Pl)*self.ao.dms.opt_weights[d_o]
            to_inv += np.matmul(Pdm_t, Pdm)*self.ao.dms.opt_weights[d_o]
        Pdm = None
        Pl = None
        Pdm_t = None
        fx = None
        fy = None

        # Popt
        if nDir == 1:
            mat2 = np.linalg.pinv(to_inv.astype(np.complex64),
                                  rcond=1/self.ao.dms.opt_cond)
            to_inv = None
        else:
            # Tikhonov: use only the diagonal of to_inv for regularization
            to_inv_t = to_inv.transpose(0, 1, 3, 2)
            lambda_tikhonov = 1/self.ao.dms.opt_cond
            try:
                # Build regularized system
                A = to_inv_t.astype(np.complex64) @ to_inv.astype(np.complex64)
                # Add regularization on diagonal as a fraction of the trace
                lambda_reg = (np.mean(np.diagonal(A, axis1=2, axis2=3)) \
                             * lambda_tikhonov).astype(self.complex_dtype)
                idx = np.arange(nDm)
                A[:, :, idx, idx] += lambda_reg
                b = to_inv_t.astype(np.complex64)
                mat2 = np.linalg.solve(A, b)
                A = None
                b = None
                if self.verbose:
                    print("Optimal projector: Using Tikhonov regularization")
            except np.linalg.LinAlgError as e:
                # Fallback: use pinv on original to_inv
                if self.verbose:
                    print(f"Optimal projector: Tikhonov failed ({e}), using pinv")
                mat2 = np.linalg.pinv(to_inv.astype(np.complex64),
                                    rcond=1/self.ao.dms.opt_cond)

        Popt = np.matmul(mat2, mat1)

        self.t_opt = 1000*(time.time() - tstart)
        return Popt


#%% CONTROLLER DEFINITION
    def controller(self, nTh=1, nF=1000, display=False):
        """
        Define the AO loop controller and compute the spatialized filter thanks
        to the Taylor hypothesis : f = k.v
        """
        tstart  = time.time()

        if self.ao.rtc.holoop['gain']:

            i = self.complex_dtype(1j)
            vx = self.ao.atm.wSpeed*nnp.cos(self.ao.atm.wDir*np.pi/180)
            vy = self.ao.atm.wSpeed*nnp.sin(self.ao.atm.wDir*np.pi/180)
            nPts = self.freq.resAO
            thetaWind = np.linspace(0, 2*np.pi-2*np.pi/nTh, nTh)
            costh = np.cos(thetaWind)
            weights = self.ao.atm.weights
            Ts = 1.0/self.ao.rtc.holoop['rate']#samplingTime
            delay = self.ao.rtc.holoop['delay']#latency
            loopGain = self.ao.rtc.holoop['gain']

            if Ts <= 0:
                raise ValueError('Error : the AO loop rate must be positive\n')

            # Instantiation
            h1 = np.zeros((nPts,nPts),
                          dtype=self.complex_dtype)
            h2 = np.zeros((nPts,nPts),
                          dtype=self.dtype)
            hn = np.zeros((nPts,nPts),
                          dtype=self.dtype)

            # Get the noise propagation factor
            # Start from a small positive frequency to avoid f=0
            f = np.logspace(-3, np.log10(0.5/Ts), nF)
            z = np.exp(-2*i*np.pi*f*Ts)

            # Compute transfer functions with safe division
            # Add small epsilon to denominator to avoid division by zero
            eps = np.finfo(float).eps
            denom = 1.0 - z**(-1.0)
            # Set small values to eps to avoid division by zero
            denom = np.where(np.abs(denom) < eps, eps, denom)

            self.hInt = loopGain / denom

            denom2 = 1.0 + self.hInt * z**(-delay)
            denom2 = np.where(np.abs(denom2) < eps, eps, denom2)
            self.rtfInt = 1.0 / denom2

            self.atfInt = self.hInt * z**(-delay) * self.rtfInt

            if loopGain == 0:
                self.ntfInt = 1
            else:
                self.ntfInt = self.atfInt/z

            self.noiseGain = trapz(abs(self.ntfInt)**2, f)*2*Ts

            # Get transfer functions
            for l in range(self.ao.atm.nL):
                h1buf = np.zeros((nPts, nPts, nTh),
                                 dtype=self.complex_dtype)
                h2buf = np.zeros((nPts, nPts, nTh),
                                 dtype=self.dtype)
                hnbuf = np.zeros((nPts, nPts, nTh),
                                 dtype=self.dtype)
                for iTheta in range(nTh):
                    fi = -vx[l]*self.freq.kxAO_*costh[iTheta] - vy[l]*self.freq.kyAO_*costh[iTheta]
                    z  = np.exp(-2*i*np.pi*fi*Ts)

                    # Safe division for spatially varying transfer functions
                    denom = 1.0 - z**(-1.0)
                    denom = np.where(np.abs(denom) < eps, eps, denom)
                    hInt = loopGain / denom

                    denom2 = 1.0 + hInt * z**(-delay)
                    denom2 = np.where(np.abs(denom2) < eps, eps, denom2)
                    rtfInt = 1.0 / denom2

                    atfInt = hInt * z**(-delay) * rtfInt

                    # AO transfer function
                    h2buf[:, :, iTheta] = abs(atfInt)**2
                    h1buf[:, :, iTheta] = atfInt
                    # noise transfer function
                    if loopGain == 0:
                        ntfInt = 1
                    else:
                        ntfInt = atfInt/z
                    hnbuf[:, :, iTheta] = abs(ntfInt)**2

                h1 += weights[l]*np.sum(h1buf, axis=2)/nTh
                h2 += weights[l]*np.sum(h2buf, axis=2)/nTh
                hn += weights[l]*np.sum(hnbuf, axis=2)/nTh

            self.h1 = h1
            self.h2 = h2
            self.hn = hn

            if display:
                plt.figure()
                plt.semilogx(f, 10*np.log10(abs(self.rtfInt)**2),
                             label='Rejection transfer function')
                plt.semilogx(f, 10*np.log10(abs(self.ntfInt)**2),
                             label='Noise transfer function')
                plt.semilogx(f, 10*np.log10(abs(self.atfInt)**2),
                             label='Aliasing transfer function')
                plt.xlabel('Temporal frequency (Hz)')
                plt.ylabel('Magnitude (dB)')
                plt.grid('on')
                plt.legend()

        self.t_controller = 1000*(time.time() - tstart)

#%% PSD DEFINTIONS
    def powerSpectrumDensity(self,wfe=None):
        """ Total power spectrum density in nm^2.m^2
        """
        tstart  = time.time()

        dk     = 2*self.freq.kcMax_/self.freq.resAO
        rad2nm = self.freq.wvlRef*1e9/2/np.pi

        if self.ao.rtc.holoop['gain']==0:
            # OPEN-LOOP
            k = np.sqrt(self.freq.k2_)
            pf = FourierUtils.pistonFilter(self.ao.tel.D, k, dtype=self.dtype)
            psd = self.ao.atm.spectrum(k) * pf
            psd = psd[:, :, np.newaxis]
        else:
            # CLOSED-LOOP
            psd = np.zeros((self.freq.nOtf,self.freq.nOtf,self.ao.src.nSrc),
                           dtype=self.dtype)

            # AO correction area
            id1 = np.ceil(self.freq.nOtf/2 - self.freq.resAO/2).astype(int)
            id2 = np.ceil(self.freq.nOtf/2 + self.freq.resAO/2).astype(int)
            # Noise
            self.psdNoise = np.real(self.noisePSD())
            if self.nGs == 1:
                psd[id1:id2,id1:id2,:] = self.psdNoise[:, :, np.newaxis]
            else:
                psd[id1:id2,id1:id2,:] = self.psdNoise

            # --- free memory
            if self.reduce_memory and not self.getErrorBreakDown:
                self.psdNoise = None
                self.Cb = None
                self.Cphi_mod = None

            # Aliasing
            self.psdAlias = np.real(self.aliasingPSD())
            psd[id1:id2,id1:id2,:] += self.psdAlias[:, :, np.newaxis]

            # --- free memory
            if self.reduce_memory and not self.getErrorBreakDown:
                self.psdAlias = None

            # Differential refractive anisoplanatism
            self.psdDiffRef = self.differentialRefractionPSD()
            psd[id1:id2,id1:id2,:] = psd[id1:id2,id1:id2,:] + self.psdDiffRef

            # --- free memory
            if self.reduce_memory and not self.getErrorBreakDown:
                self.psdDiffRef = None

            # Chromatism
            self.psdChromatism = self.chromatismPSD()
            psd[id1:id2,id1:id2,:] = psd[id1:id2,id1:id2,:] + self.psdChromatism

            # --- free memory
            if self.reduce_memory and not self.getErrorBreakDown:
                self.psdChromatism = None

            # Add the noise and spatioTemporal PSD
            self.psdSpatioTemporal = np.real(self.spatioTemporalPSD())
            psd[id1:id2,id1:id2,:] += self.psdSpatioTemporal

            # --- free memory
            if self.reduce_memory and not self.getErrorBreakDown:
                self.psdSpatioTemporal = None
                self.Cphi = None

            # Cone effect
            if self.nGs == 1 and self.gs.height[0] != 0:
                if self.verbose:
                    print('SLAO case adding cone effect')
                self.psdCone = self.focalAnisoplanatismPSD()
                psd += self.psdCone[:, :, np.newaxis]

                # --- free memory
                if self.reduce_memory and not self.getErrorBreakDown:
                    self.psdCone = None

            # additional error for MCAO system with laser GS:
            # reduced volume for WF sensing due to the cone effect
            if self.ao.addMcaoWFsensConeError and self.nGs != 1 and self.gs.height[0] != 0:
                if self.verbose:
                    print('MCAO and laser case: adding error due to reduced volume for WF sensing')
                self.psdMcaoWFsensCone = self.mcaoWFsensConePSD(psd)
                psd += self.psdMcaoWFsensCone

                # --- free memory
                if self.reduce_memory and not self.getErrorBreakDown:
                    self.psdMcaoWFsensCone = None

            # NORMALIZATION
            if wfe != None:
                psd *= (dk * rad2nm)**2
                psd *= wfe**2/psd.sum()

            # Fitting
            self.psdFit = np.real(self.fittingPSD())
            psd += self.psdFit[:, :, np.newaxis]

            # --- free memory
            if self.reduce_memory and not self.getErrorBreakDown:
                self.psdFit = None

            # wind shake / vibrations
            if self.applyTiltFilter is False and self.ao.windPsdFile != 0:
                self.psdVib = self.windShakePSD()
                psd[id1:id2,id1:id2,:] += self.psdVib[:, :, np.newaxis]

                # --- free memory
                if self.reduce_memory and not self.getErrorBreakDown:
                    self.psdVib = None

            # Tilt filter
            if self.applyTiltFilter == True:
                tiltFilter = self.TiltFilter()           
                for i in range(self.ao.src.nSrc):
                    psd[:,:,i] *= tiltFilter

            # Extra error
            if self.verbose:
                print('extra error in nm RMS: ',self.ao.tel.extraErrorNm)
                print('extra error spatial frequency exponent: ',self.ao.tel.extraErrorExp)
                print('extra error in nm RMS (LO): ',self.ao.tel.extraErrorLoNm)
                print('extra error spatial frequency exponent (LO): ',self.ao.tel.extraErrorLoExp)
            if self.ao.tel.extraErrorNm > 0:
                self.psdExtra = np.real(self.extraErrorPSD())
            errLOsum = nnp.sum(self.ao.tel.extraErrorLoNm)
            if self.ao.getPSDatNGSpositions and errLOsum >= 0:
                nLO = len(self.ao.azimuthGsLO)
                self.psdExtraLo = self.extraErrorLoPSD()
            else:
                nLO = 0
            for i in range(self.ao.src.nSrc):
                if nLO > 0 and errLOsum >= 0 and self.ao.src.nSrc-i <= nLO:
                    if isinstance(self.psdExtraLo, list):
                        psd[:,:,i] += self.psdExtraLo[i-self.ao.src.nSrc+nLO]
                    else:
                        psd[:,:,i] += self.psdExtraLo
                elif self.ao.tel.extraErrorNm > 0:
                    psd[:,:,i] += self.psdExtra

            # --- free memory
            if self.reduce_memory and not self.getErrorBreakDown:
                self.psdExtra = None
                self.psdExtraLo = None
                self.kx_ = None
                self.ky_ = None
                self.k2_ = None
                self.U_ = None
                self.V_ = None
                self.kxAO_ = None
                self.kyAO_ = None
                self.k2AO_ = None
                self.kc_ = None
                self.kcAO_ = None

        self.t_powerSpectrumDensity = 1000*(time.time() - tstart)

        # Return the 3D PSD array in nm^2
        return psd * (dk * rad2nm)**2

    def fittingPSD(self):
        """ Fitting error power spectrum density """
        tstart  = time.time()
        #Instantiate the function output
        psd = np.zeros((self.freq.nOtf,self.freq.nOtf),
                       dtype=self.dtype)
        psd[self.freq.mskOut_]  = self.ao.atm.spectrum(np.sqrt(self.freq.k2_[self.freq.mskOut_]))
        self.t_fittingPSD = 1000*(time.time() - tstart)
        return psd

    def aliasingPSD(self):
        """
        Aliasing error power spectrum density
        Memory-optimized with GPU-aware vectorized implementation
        TO BE REVIEWED IN THE CASE OF A PYRAMID WFS
        """
        tstart = time.time()
        psd = np.zeros((self.freq.resAO, self.freq.resAO),
                       dtype=self.dtype)
        i = self.complex_dtype(1j)
        d = self.ao.wfs.optics[0].dsub
        clock_rate = np.array([self.ao.wfs.detector[j].clock_rate for j in range(self.nGs)])
        T = np.mean(clock_rate / self.ao.rtc.holoop['rate'])
        td = T * self.ao.rtc.holoop['delay']
        vx = self.ao.atm.wSpeed * nnp.cos(self.ao.atm.wDir * np.pi / 180)
        vy = self.ao.atm.wSpeed * nnp.sin(self.ao.atm.wDir * np.pi / 180)
        weights = self.ao.atm.weights
        w = 2 * i * np.pi * d

        if hasattr(self, 'Rx') == False:
            self.reconstructionFilter()
        Rx = self.Rx * w
        Ry = self.Ry * w

        if self.ao.rtc.holoop['gain'] == 0:
            tf = 1
        else:
            tf = self.h1

        # Create grid of frequency shifts
        mi, ni = np.meshgrid(
            np.arange(-self.freq.nTimes, self.freq.nTimes),
            np.arange(-self.freq.nTimes, self.freq.nTimes),
            indexing="ij"
        )
        # Mask to exclude (0,0) shift
        mask = (mi != 0) | (ni != 0)
        mi = mi[:, :, None]  # Shape (nShifts, nShifts, 1)
        ni = ni[:, :, None]

        # Frequency arrays (flatten to 1D for clean broadcasting)
        kxAO = self.freq.kxAO_.ravel()  # Shape (K,)
        kyAO = self.freq.kyAO_.ravel()

        # Shifted frequencies (broadcasts to: nShifts x nShifts x K)
        km = kxAO[None, None, :] - mi / d
        kn = kyAO[None, None, :] - ni / d

        NN = self.Rx.shape

        # Piston filter
        PR = FourierUtils.pistonFilter(
            self.ao.tel.D,
            np.hypot(km, kn),
            fm=mi[:, :, None] / d,
            fn=ni[:, :, None] / d,
            dtype=self.dtype
        )

        # Atmospheric spectrum
        W_mn = (km**2 + kn**2 + 1 / self.ao.atm.L0**2) ** (-11 / 6)

        # Reconstructor (reshape for broadcasting)
        Rx = Rx.ravel()[None, None, :]  # Shape (1, 1, K)
        Ry = Ry.ravel()[None, None, :]
        # Q factor
        Q = (Rx * km + Ry * kn) * (np.sinc(d * km) * np.sinc(d * kn))

        tf_flat = np.asarray(tf.ravel()[None, None, :])

        # **VECTORIZED CHUNKED PROCESSING**:
        # Process layers in chunks with full vectorization
        chunk_size = min(5, self.ao.atm.nL)  # Adjust chunk size
        avr_sum = np.zeros((mi.shape[0], mi.shape[1], len(kxAO)),
                           dtype=self.complex_dtype)

        # Pre-allocate chunk array ONCE (fixed size, reused across iterations)
        avr_chunk = np.zeros((chunk_size, mi.shape[0], mi.shape[1], len(kxAO)),
                             dtype=self.complex_dtype)

        for chunk_start in range(0, self.ao.atm.nL, chunk_size):
            chunk_end = min(chunk_start + chunk_size, self.ao.atm.nL)
            n_layers_chunk = chunk_end - chunk_start

            # Reset chunk array to zero (reusing allocation)
            avr_chunk.fill(0)

            # **VECTORIZED COMPUTATION FOR ALL LAYERS IN CHUNK**
            # Extract velocity components for this chunk
            vx_chunk = vx[chunk_start:chunk_end]  # Shape: (n_layers_chunk,)
            vy_chunk = vy[chunk_start:chunk_end]

            # Broadcast to (n_layers_chunk, 1, 1, 1) for proper broadcasting
            vx_bc = np.asarray(vx_chunk[:, None, None, None])
            vy_bc = np.asarray(vy_chunk[:, None, None, None])

            # Compute transfer function for all layers in chunk simultaneously
            # Broadcasting: (n_layers_chunk, nShifts, nShifts, K)
            avr_chunk[:n_layers_chunk] = (
                np.sinc(km[None, :, :, :] * vx_bc * T) *
                np.sinc(kn[None, :, :, :] * vy_bc * T) *
                np.exp(2j * np.pi * (km[None, :, :, :] * vx_bc + kn[None, :, :, :] * vy_bc) * td) *
                tf_flat[None, :, :, :]
            )

            # Weighted sum over ONLY the valid layers in this chunk
            # For the last chunk, only sum over the first n_layers_chunk elements
            weights_chunk = np.asarray(weights[chunk_start:chunk_end][:, None, None, None])
            avr_sum += np.sum(weights_chunk * avr_chunk[:n_layers_chunk], axis=0)

        # Free chunk memory
        avr_chunk = None

        # Compute aliasing PSD
        psd = np.sum(PR * W_mn * np.abs(Q * avr_sum) ** 2 * mask[:, :, None], axis=(0, 1))
        psd = np.reshape(psd, NN)

        self.t_aliasingPSD = 1000 * (time.time() - tstart)
        return self.freq.mskInAO_ * psd * self.ao.atm.r0**(-5/3) * 0.0229

    def noisePSD(self):
        """Noise error power spectrum density
        """
        tstart = time.time()
        psd = np.zeros((self.freq.resAO,self.freq.resAO),
                       dtype=self.dtype)
        if self.ao.wfs.processing.noiseVar[0] > 0:
            if self.nGs < 2:
                # SCAO case
                psd = abs(self.Rx**2 + self.Ry**2)
                psd = psd/(2*self.freq.kcMax_)**2
                psd = self.freq.mskInAO_ * psd * self.freq.pistonFilterAO_ \
                      * self.noiseGain * np.mean(self.ao.wfs.processing.noiseVar)
            else:
                psd = np.zeros((self.freq.resAO,self.freq.resAO,self.ao.src.nSrc),
                               dtype=self.dtype)
                # - Noise level is considered in the covariance matrix Cb
                # - Noise gain is considered to be that produced by
                #   an integrator controller with a gain of 0.5.
                #   The linear value ranges from 0.4 to 0.8 for a delay from 0 to 3 frames.
                noise_gain = min(0.8, 0.4 + 0.1333 * self.ao.rtc.holoop['delay']) ** 2
                for j in range(self.ao.src.nSrc):
                    PW = np.matmul(self.PbetaDM[j],self.W)
                    PW_t = np.conj(PW.transpose(0,1,3,2))
                    tmp = np.matmul(PW,np.matmul(self.Cb,PW_t)).real
                    psd[:,:,j] = self.freq.mskInAO_ * tmp[:, :, 0, 0]  \
                        * self.freq.pistonFilterAO_ * noise_gain

        self.t_noisePSD = 1000*(time.time() - tstart)
        # NOTE: the noise variance is the same for all WFS
        return psd

    def reconstructionPSD(self):
        """ Power spectrum density of the wavefront reconstruction error
        """
        tstart = time.time()
        psd = np.zeros((self.freq.resAO,self.freq.resAO),
                       dtype=self.dtype)
        if not hasattr(self, 'Rx'):
            self.reconstructionFilter()

        F = self.Rx*self.SxAv + self.Ry*self.SyAv
        psd = abs(1-F)**2 * self.freq.mskInAO_ * self.Wphi * self.freq.pistonFilterAO_

        self.t_recPSD = 1000*(time.time() - tstart)
        return  psd

    def servoLagPSD(self):
        """ Servo-lag power spectrum density.
        Note : sometimes the sum becomes negative, a further analysis is needed
        """
        tstart = time.time()
        psd = np.zeros((self.freq.resAO,self.freq.resAO),
                       dtype=self.dtype)
        if hasattr(self, 'Rx') == False:
            self.reconstructionFilter()

        F = self.Rx*self.SxAv + self.Ry*self.SyAv
        Watm = self.Wphi * self.freq.pistonFilterAO_
        if self.ao.rtc.holoop['gain'] == 0:
            psd = abs(1-F)**2 * Watm
        else:
            psd = (1.0 + abs(F)**2*self.h2 - 2*np.real(F*self.h1))*Watm

        self.t_servoLagPSD = 1000*(time.time() - tstart)
        return self.freq.mskInAO_ * abs(psd)

    def windShakePSD(self):
        """ wind shake / vibrations power spectrum density.
        """
        tstart  = time.time()    
        psd = np.zeros((self.freq.resAO,self.freq.resAO),
                       dtype=self.dtype)

        Wtilt1 = 1-self.TiltFilter()
        # AO correction area
        id1 = np.ceil(self.freq.nOtf/2 - self.freq.resAO/2).astype(int)
        id2 = np.ceil(self.freq.nOtf/2 + self.freq.resAO/2).astype(int)
        Wtilt1 = Wtilt1[id1:id2,id1:id2] * self.freq.pistonFilterAO_
        Wtilt1 *= 1/np.sum(Wtilt1)

        # wind-shake PSD
        from astropy.io import fits
        hdul = fits.open(self.ao.windPsdFile)
        psd_data = np.asarray(hdul[0].data,
                              dtype=self.dtype)
        hdul.close()
        psd_freq = np.asarray(np.linspace(0.1, 0.5*self.ao.rtc.holoop['rate'],
                                          int(5*self.ao.rtc.holoop['rate'])),
                              dtype=self.dtype)
        psd_tip_wind = np.interp(psd_freq, psd_data[0,:], psd_data[1,:],left=0,right=0)
        psd_tilt_wind = np.interp(psd_freq, psd_data[0,:], psd_data[2,:],left=0,right=0)

        #rejection transfer function
        ic      = self.complex_dtype(1j)
        z       = np.exp(-2*ic*np.pi/self.ao.rtc.holoop['rate']*psd_freq)
        hInt    = self.ao.rtc.holoop['gain']/(1.0 - z**(-1.0))
        rtfInt  = 1.0/(1.0 + hInt * z**(-self.ao.rtc.holoop['delay']))

        plot_debug = False
        if plot_debug:
            fig, _ = plt.subplots()
            plt.loglog(psd_freq,np.abs(rtfInt))
            fig, _ = plt.subplots()
            plt.loglog(psd_freq,psd_tip_wind)
            plt.loglog(psd_freq,np.abs(rtfInt**2*psd_tip_wind))

        power = np.abs(np.sum(rtfInt**2*(psd_tip_wind+psd_tilt_wind))*(psd_freq[1]-psd_freq[0]))
        rad2nm = (2*self.freq.kcMax_/self.freq.resAO) * self.freq.wvlRef*1e9/2/np.pi
        power *= 1/rad2nm**2

        psd[:,:] = power*Wtilt1

        self.t_windShakePSD = 1000*(time.time() - tstart)
        return self.freq.mskInAO_ * abs(psd)

    def spatioTemporalPSD(self):
        """%% Power spectrum density including reconstruction, field variations and temporal effects
        """
        tstart = time.time()
        nK = self.freq.resAO
        psd = np.zeros((nK,nK,self.ao.src.nSrc),
                       dtype=self.dtype)
        i = self.complex_dtype(1j)
        nH = self.ao.atm.nL
        Hs = self.ao.atm.heights * self.strechFactor
        Ws = self.ao.atm.weights
        deltaT = self.ao.rtc.holoop['delay']/self.ao.rtc.holoop['rate']
        wDir_x = nnp.cos(self.ao.atm.wDir*np.pi/180)
        wDir_y = nnp.sin(self.ao.atm.wDir*np.pi/180)
        Watm = self.Wphi * self.freq.pistonFilterAO_
        F = self.Rx*self.SxAv + self.Ry*self.SyAv

        for s in range(self.ao.src.nSrc):
            if self.nGs<2:
                th = self.ao.src.direction[:, s] - self.gs.direction[:, 0]
                if np.any(np.asarray(th)):
                    A = np.zeros((nK, nK),
                                 dtype=self.complex_dtype)
                    for l in range(self.ao.atm.nL):
                        A = A + Ws[l] \
                            * np.exp(2*i*np.pi*Hs[l]*(self.freq.kxAO_*th[1] + self.freq.kyAO_*th[0]))
                else:
                    A = np.ones((self.freq.resAO, self.freq.resAO),
                                dtype=self.complex_dtype)

                if (self.ao.rtc.holoop['gain'] == 0):
                    psd[:, :, s] = abs(1-F)**2 * Watm
                else:
                    psd[:, :, s] = self.freq.mskInAO_ * \
                        (1 + abs(F)**2*self.h2 - 2*np.real(F*self.h1*A)) * Watm
            else:
                # tomographic case
                Beta = [self.ao.src.direction[0,s],self.ao.src.direction[1,s]]
                PbetaL = np.zeros([nK, nK, 1, nH],
                                  dtype=self.complex_dtype)
                fx = Beta[0]*self.freq.kxAO_
                fy = Beta[1]*self.freq.kyAO_
                for j in range(nH):
                    freq_t = wDir_x[j]*self.freq.kxAO_+ wDir_y[j]*self.freq.kyAO_
                    delta_h = Hs[j]*(fx+fy) - deltaT*self.ao.atm.wSpeed[j]*freq_t
                    PbetaL[: , :, 0, j] = np.exp(i*2*np.pi*delta_h)

                proj = PbetaL - np.matmul(self.PbetaDM[s], self.Walpha)
                proj_t = np.conj(proj.transpose(0, 1, 3, 2))
                tmp = np.matmul(proj,np.matmul(self.Cphi, proj_t)).real
                psd[:, :, s] = self.freq.mskInAO_ * tmp[:, :, 0, 0]*self.freq.pistonFilterAO_
        if self.reduce_memory:
            self.Walpha = None
        self.t_spatioTemporalPSD = 1000*(time.time() - tstart)
        return psd

    def anisoplanatismPSD(self):
        """%% Anisoplanatism power spectrum density
        """
        tstart  = time.time()
        psd = np.zeros((self.freq.resAO,self.freq.resAO,self.ao.src.nSrc),
                       dtype=self.dtype)
        Hs = self.ao.atm.heights * self.strechFactor
        Ws = self.ao.atm.weights
        Watm = self.Wphi * self.freq.pistonFilterAO_

        for s in range(self.ao.src.nSrc):
            th  = self.ao.src.direction[:,s] - self.gs.direction[:,0]
            if any(th):
                A = np.zeros((self.freq.resAO,self.freq.resAO),
                               dtype=self.dtype)
                for l in range(self.ao.atm.nL):
                    A = A + 2 * Ws[l] * \
                        (1 - np.cos(2*np.pi*Hs[l]*(self.freq.kxAO_*th[1] + self.freq.kyAO_*th[0])))
                psd[:,:,s] = self.freq.mskInAO_ * A*Watm
        self.t_anisoplanatismPSD = 1000*(time.time() - tstart)
        return np.real(psd)

    def differentialRefractionPSD(self):
        tstart = time.time()
        psd = np.zeros((self.freq.resAO,self.freq.resAO,self.ao.src.nSrc), dtype=self.dtype)

        if self.ao.tel.zenith_angle != 0:
            Hs = self.ao.atm.heights * self.strechFactor
            Ws = self.ao.atm.weights
            Watm = self.Wphi * self.freq.pistonFilterAO_
            k = np.sqrt(self.freq.k2AO_)
            arg_k = np.arctan2(self.freq.kyAO_, self.freq.kxAO_)
            azimuth = self.ao.src.azimuth

            # Uses the pre-calculated values from Mathar
            delta_n = self.n_air_wvlRef - self.n_air_gs
            theta = delta_n * np.tan(self.ao.tel.zenith_angle*np.pi/180)

            for s in range(self.ao.src.nSrc):
                A = 0
                for l in range(self.ao.atm.nL):
                    A = A + 2*Ws[l]*(1 - np.cos(2*np.pi*Hs[l]*k*np.tan(theta)*np.cos(arg_k-azimuth[s])))
                psd[:,:,s] = self.freq.mskInAO_ * A * Watm

        self.t_differentialRefractionPSD = 1000*(time.time() - tstart)
        return psd

    def chromatismPSD(self):
        tstart = time.time()
        Watm = self.Wphi * self.freq.pistonFilterAO_
        psd = np.zeros((self.freq.resAO,self.freq.resAO,self.ao.src.nSrc), dtype=self.dtype)

        # IMPORTANT: We use refractivity (n - 1) instead of the absolute refractive index (n).
        # The Optical Path Difference (OPD) induced by atmospheric turbulence scales directly
        # with (n - 1) according to the Gladstone-Dale relation.
        # The WFS measures OPD_wfs proportional to (n_wfs - 1), and the DM corrects it.
        # The residual chromatic error at the science wavelength is OPD_sci - OPD_wfs.
        # Therefore, the chromatic scaling factor for the variance (PSD) is:
        # [ ( (n_sci - 1) - (n_wfs - 1) ) / (n_wfs - 1) ]^2
        # Note: MatharAirRefraction already returns (n - 1) values.

        n2 = self.n_air_gs
        n1 = self.n_air_wvlRef

        for s in range(self.ao.src.nSrc):
            psd[:,:,s] = ((n2-n1)/n2)**2 * Watm

        self.t_chromatismPSD = 1000*(time.time() - tstart)
        return psd

    def phaseStructureFunction(self):
       '''
           GET THE AO RESIDUAL PHASE STRUCTURE FUNCTION
       '''
       cov = fft.fftshift(fft.fftn(fft.fftshift(self.PSD,axes=(0,1)),axes=(0,1)),axes=(0,1))
       return 2*np.real(cov.max(axis=(0,1)) - cov)


    def focalAnisoplanatismPSD(self):
        """%% Focal Anisoplanatism power spectrum density
        """
        tstart  = time.time()

        #Instantiate the function output
        psd      = np.zeros((self.freq.nOtf,self.freq.nOtf),
                            dtype=self.dtype)
        # atmo PSD
        psd_atmo = self.ao.atm.spectrum(np.sqrt(self.freq.k2_))

        nPoints = 1001
        nPhase = 5 # number of phase shift cases
        x = self.ao.tel.D*np.linspace(-0.5, 0.5, nPoints, endpoint=1)
        h = self.ao.atm.heights
        h_laser = self.gs.height[0]
        ratio = np.array((h_laser-h)/h_laser)
        nCn2 = len(h)
        freqs = self.freq.kx_[int(np.ceil(self.freq.nOtf/2)-1):,0]
        if freqs[0] < 0:
            freqs = freqs[1:]

        # We create grids to avoid explicit loops
        freqs_matrix = freqs[:, np.newaxis]  # len(freqs) x 1 (for broadcasting)
        ratio_matrix = ratio[np.newaxis, :]  # 1 x nCn2       (for broadcasting)

        x4D = x[np.newaxis, np.newaxis, :, np.newaxis]
        freqs_4Dmatrix = (freqs_matrix * (np.ones(nCn2,
                          dtype=self.dtype))[np.newaxis, :])[:, :, np.newaxis, np.newaxis ]
        freqs_ratio_matrix = freqs_matrix * ratio_matrix
        freqs_ratio_4Dmatrix = freqs_ratio_matrix[:, :, np.newaxis, np.newaxis]

        # We vector-initialise sin_ref and sin_temp over all combinations of i, j and k
        k_values = np.arange(nPhase)
        phase_4Dmatrix = (2 * np.pi * k_values / nPhase)[np.newaxis, np.newaxis, np.newaxis, :]

        # Calculation of sinusoids, their std dev and differences for each phase
        sin_ref = np.sin(2 * np.pi * freqs_4Dmatrix * x4D + phase_4Dmatrix)
        sin_temp = np.sin(2 * np.pi * freqs_ratio_4Dmatrix * x4D + phase_4Dmatrix)

        sin_ref_std = np.std(sin_ref, axis=2)
        sin_temp_std = np.std(sin_temp, axis=2)
        std_ratio = sin_ref_std/sin_temp_std
        sin_res = sin_ref - std_ratio[:,:,np.newaxis,:] * sin_temp

        # We calculate the coefficients using the average on the phase
        coeff = np.mean(np.std(sin_res, axis=2) / sin_ref_std, axis=2)

        # Now we calculate where the conditions are not satisfied and we put the coefficients to 0
        condition1 = freqs_matrix * ratio_matrix > self.freq.kc_
        condition2 = freqs_matrix < 1e-5
        non_valid_mask = (condition1 | condition2)
        coeff[non_valid_mask] = 0

        # We calculate 2D coefficients and PSD
        coeff_tot = []
        for j in range(nCn2):
            coeff_tot = np.interp(np.sqrt(self.freq.k2_), freqs, coeff[:,j])**2

            #fig, ax1 = plt.subplots(1,1)
            #im = ax1.plot(coeff[:,j])
            #fig, ax2 = plt.subplots(1,1)
            #im = ax2.imshow(coeff_tot, cmap='hot')
            #ax2.set_title('cone effect filter coefficients', color='black')

            psd += coeff_tot*psd_atmo*self.ao.atm.weights[j]

        self.t_focalAnisoplanatism = 1000*(time.time() - tstart)

        return np.real(psd)

    def mcaoWFsensConePSD(self, psdRes):
        """%% power spectrum density related to the reduced volume sensed
            by the LGS WFS due to cone effect in MCAO systems.
            This effect is related to the cone effect and it depends on
            the LGS geometry and the uncorrected part of the input PSD.
        """
        tstart = time.time()

        # Instantiate the function output
        psd = np.zeros((self.freq.nOtf, self.freq.nOtf, self.ao.src.nSrc),
                       dtype=self.dtype)

        # atmo PSD
        psd_atmo = self.ao.atm.spectrum(np.sqrt(self.freq.k2_))

        # AO correction area
        id1 = np.ceil(self.freq.nOtf/2 - self.freq.resAO/2).astype(int)
        id2 = np.ceil(self.freq.nOtf/2 + self.freq.resAO/2).astype(int)

        # geometry
        lfov = 2 * np.max(self.gs.zenith)

        # effective FoV
        eFoV = (lfov * (1/rad2arc) - self.ao.tel.D * (1/self.gs.height[0])) * rad2arc

        # filter considering the maximum cut off frequency
        k = np.sqrt(self.freq.k2_)
        fs = np.max(k) * 2.
        x = k / (fs/2.) * np.pi
        xc = 1j * x
        z = np.exp(xc)

        # piston filter
        pf = FourierUtils.pistonFilter(self.ao.tel.D,
                                       np.sqrt(self.freq.k2_),
                                       dtype=self.dtype)
        pf = pf[id1:id2, id1:id2]

        # Vectorize source-dependent calculations
        src_zenith = np.array(self.ao.src.zenith, dtype=self.dtype)  # Shape: (nSrc,)
        max_gs_zenith = np.max(self.gs.zenith)

        # Calculate deltaAngleE and deltaAngleL for all sources at once
        if eFoV > 0:
            deltaAngleE = np.minimum(src_zenith, max_gs_zenith) - eFoV/2
        else:
            deltaAngleE = np.minimum(src_zenith, max_gs_zenith) - eFoV

        deltaAngleL = src_zenith - lfov/2
        deltaAngleL = np.maximum(deltaAngleL, 0)  # Equivalent to: deltaAngleL[deltaAngleL < 0] = 0

        # Pre-compute deltaPsd for all sources
        deltaPsd = psd_atmo[id1:id2, id1:id2, np.newaxis] - psdRes[id1:id2, id1:id2, :]  # Shape: (resAO, resAO, nSrc)
        deltaPsd = np.maximum(deltaPsd, 0)  # Equivalent to: deltaPsd[deltaPsd < 0] = 0
        deltaPsdPf = deltaPsd * pf[:, :, np.newaxis]  # Broadcasting piston filter

        # Vectorize layer calculations
        atm_heights = np.array(self.ao.atm.heights)  # Shape: (nCn2,)
        atm_weights = np.array(self.ao.atm.weights)  # Shape: (nCn2,)

        # Create masks for valid layers and sources
        valid_layers = atm_heights > 0  # Shape: (nCn2,)
        valid_sources = deltaAngleE > 0  # Shape: (nSrc,)

        # Only process valid combinations
        if np.any(valid_layers) and np.any(valid_sources):
            # Get indices of valid layers and sources
            valid_layer_idx = np.where(valid_layers)[0]
            valid_source_idx = np.where(valid_sources)[0]

            # Extract valid data
            valid_heights = atm_heights[valid_layer_idx]  # Shape: (nValidLayers,)
            valid_weights = atm_weights[valid_layer_idx]  # Shape: (nValidLayers,)
            valid_deltaAngleE = deltaAngleE[valid_source_idx]  # Shape: (nValidSources,)
            valid_deltaAngleL = deltaAngleL[valid_source_idx]  # Shape: (nValidSources,)

            # Broadcast for vectorized computation
            # Create grids: (nValidLayers, nValidSources)
            heights_grid, deltaAngleE_grid = np.meshgrid(valid_heights, valid_deltaAngleE, indexing='ij')
            weights_grid, deltaAngleL_grid = np.meshgrid(valid_weights, valid_deltaAngleL, indexing='ij')

            # Calculate fCut and eqD for all valid combinations
            fCut = rad2arc / (deltaAngleE_grid * heights_grid)  # Shape: (nValidLayers, nValidSources)
            eqD = self.ao.tel.D - deltaAngleL_grid * heights_grid * (1/rad2arc)  # Shape: (nValidLayers, nValidSources)
            eqD = np.minimum(eqD, self.ao.tel.D)

            # Create mask for valid frequency cuts
            valid_fcut_mask = (fCut < self.freq.kcMax_) & (eqD > 0)  # Shape: (nValidLayers, nValidSources)

            if np.any(valid_fcut_mask):
                # Extract z values for the AO correction area only
                z_ao = z[id1:id2, id1:id2]  # Shape: (resAO, resAO)

                # Process only valid combinations
                for i, layer_idx in enumerate(valid_layer_idx):
                    for j, source_idx in enumerate(valid_source_idx):
                        if valid_fcut_mask[i, j]:
                            fCut_val = fCut[i, j]
                            eqD_val = eqD[i, j]
                            weight_val = weights_grid[i, j]

                            sPole = 2 * np.pi * fCut_val
                            zPole = np.exp(sPole/fs)
                            lpFilter = z_ao * (1 - zPole) / (z_ao - zPole)
                            lpFilter2 = (1 - np.abs(lpFilter)**2) * (eqD_val/self.ao.tel.D)**2
                            lpFilter2 = np.maximum(lpFilter2, 0)  # Equivalent to: lpFilter2[lpFilter2 < 0] = 0

                            psd[id1:id2, id1:id2, source_idx] += weight_val * lpFilter2 * deltaPsdPf[:, :, source_idx]

        self.t_mcaoWFsensCone = 1000 * (time.time() - tstart)

        return np.real(psd)

    def extraErrorPSD(self):
        """%% extra error
        """

        tstart  = time.time()

        k   = np.sqrt(self.freq.k2_)
        psd = k**self.ao.tel.extraErrorExp
        pf  = FourierUtils.pistonFilter(self.ao.tel.D,
                                        k,
                                        dtype=self.dtype)
        psd = psd * pf
        if self.ao.tel.extraErrorMin>0:
            psd[np.where(k<self.ao.tel.extraErrorMin)] = 0
        if self.ao.tel.extraErrorMax>0:
            psd[np.where(k>self.ao.tel.extraErrorMax)] = 0

        psd = psd * self.ao.tel.extraErrorNm**2/np.sum(psd)

        #fig, ax1 = plt.subplots(1,1)
        #im = ax1.imshow(np.log(np.abs(psd)), cmap='hot')
        #ax1.set_title('extra error PSD', color='black')

        # Derives wavefront error
        rad2nm = (2*self.freq.kcMax_/self.freq.resAO) * self.freq.wvlRef*1e9/2/np.pi

        psd = psd * 1/rad2nm**2

        self.t_extra = 1000*(time.time() - tstart)

        return np.real(psd)

    def extraErrorLoPSD(self):
        """%% extra error for LO
        """
        tstart = time.time()

        k = np.sqrt(self.freq.k2_)
        pf = FourierUtils.pistonFilter(self.ao.tel.D,
                                       k,
                                       dtype=self.dtype)
        rad2nm = (2 * self.freq.kcMax_ / self.freq.resAO) * self.freq.wvlRef * 1e9 / (2 * np.pi)

        psd = k**self.ao.tel.extraErrorLoExp * pf
        if self.ao.tel.extraErrorLoMin > 0:
            psd[k < self.ao.tel.extraErrorLoMin] = 0
        if self.ao.tel.extraErrorLoMax > 0:
            psd[k > self.ao.tel.extraErrorLoMax] = 0
        psd *= 1/np.sum(psd)

        # Check if extraErrorLoExp is a list
        if isinstance(self.ao.tel.extraErrorLoNm, list):
            psd_list = []
            for ii, _ in enumerate(self.ao.zenithGsLO):
                x = nnp.array([0,self.ao.TechnicalFoV/2])
                sqrtpower = nnp.interp(self.ao.zenithGsLO[ii], x, nnp.array(self.ao.tel.extraErrorLoNm))

                psdI = psd*sqrtpower**2

                # Derives wavefront error in rad
                psdI *= 1 / rad2nm**2

                psd_list.append(np.real(psdI))

            result = psd_list  # return a list of 2d arrays

        else:
            psd *= self.ao.tel.extraErrorLoNm**2

            #fig, ax1 = plt.subplots(1,1)
            #im = ax1.imshow(np.log(np.abs(psd)), cmap='hot')
            #ax1.set_title('extra error PSD', color='black')

            # Derives wavefront error in rad
            psd *= 1 / rad2nm**2

            result = np.real(psd)  # a single 2d array

        self.t_extraLo = 1000 * (time.time() - tstart)

        return result

    def TiltFilter(self):
        """%% Spatial filter to remove tilt related errors
        """

        tstart  = time.time()

        # from Sasiela 93
        x = 0.5*self.ao.tel.D*2*np.pi*np.sqrt(self.freq.k2_)

        # Origin protection (x -> 0) compatible with Numpy and Cupy
        x_safe = np.where(x < 1e-6, 1.0, x)

        j1_term = 2 * spc.j1(x_safe) / x_safe
        j2_term = 4 * besselj__n(2, x_safe) / x_safe

        # Replace values at the origin with exact analytical limits
        j1_term = np.where(x < 1e-6, 1.0, j1_term)
        j2_term = np.where(x < 1e-6, 0.0, j2_term)

        coeff_tot = 1 - j1_term**2 - j2_term**2

        #fig, ax1 = plt.subplots(1,1)
        #from matplotlib import colors
        #im = ax1.imshow(cpuArray(coeff_tot), cmap='hot', norm=colors.LogNorm())
        #ax1.set_title('tilt filter coefficients', color='black')

        self.t_tiltFilter = 1000*(time.time() - tstart)

        return np.real(coeff_tot)

    def FocusFilter(self):
        """%% Spatial filter to remove focus related errors
        """

        tstart  = time.time()

        # from Sasiela 93
        x = 0.5*self.ao.tel.D*2*np.pi*np.sqrt(self.freq.k2_)

        # Origin protection (x -> 0) compatible with Numpy and Cupy
        x_safe = np.where(x < 1e-6, 1.0, x)

        j3_term = 2 * besselj__n(3, x_safe) / x_safe

        # Analytical limit for x -> 0 is 0.
        j3_term = np.where(x < 1e-6, 0.0, j3_term)

        coeff_tot = 1 - 3 * j3_term**2

        #fig, ax1 = plt.subplots(1,1)
        #from matplotlib import colors
        #im = ax1.imshow(cpuArray(coeff_tot), cmap='hot', norm=colors.LogNorm())
        #ax1.set_title('focus filter coefficients', color='black')

        self.t_focusFilter = 1000*(time.time() - tstart)

        return np.real(coeff_tot)

#%% AO ERROR BREAKDOWN
    def errorBreakDown(self,verbose=True):
        """ AO error breakdown from the PSD integrals
        """
        tstart  = time.time()

        if self.ao.rtc.holoop['gain'] != 0:
            # Derives wavefront error
            rad2nm      = (2*self.freq.kcMax_/self.freq.resAO) * self.freq.wvlRef*1e9/2/np.pi

            if not self.ao.tel.opdMap_on is None:
                self.wfeNCPA= np.std(self.ao.tel.opdMap_on[self.ao.tel.pupil!=0])
            else:
                self.wfeNCPA = 0.0

            self.wfeFit    = np.sqrt(self.psdFit.sum()) * rad2nm
            self.wfeAl     = np.sqrt(self.psdAlias.sum()) * rad2nm
            self.wfeN      = np.sqrt(self.psdNoise.sum(axis=(0,1)))* rad2nm
            self.wfeST     = np.sqrt(self.psdSpatioTemporal.sum(axis=(0,1)))* rad2nm
            self.wfeDiffRef= np.sqrt(self.psdDiffRef.sum(axis=(0,1)))* rad2nm
            self.wfeChrom  = np.sqrt(self.psdChromatism.sum(axis=(0,1)))* rad2nm
            self.wfeJitter = 1e9*self.ao.tel.D*nnp.mean(self.ao.cam.spotFWHM[0][0:2])/rad2mas/4
            if self.ao.addMcaoWFsensConeError:
                self.wfeMcaoCone = np.sqrt(self.psdMcaoWFsensCone[:,:,0].sum())* rad2nm
            else:
                self.wfeMcaoCone = 0
            if self.applyTiltFilter is False and self.ao.windPsdFile != 0:
                self.wfeWindShake = np.sqrt(self.psdVib.sum())* rad2nm
            else:
                self.wfeWindShake = 0
            self.wfeExtra  = self.ao.tel.extraErrorNm

            if self.reduce_memory:
                self.psdAlias = None
                self.psdFit = None
                self.psdNoise = None
                self.psdSpatioTemporal = None
                self.psdDiffRef = None
                self.psdChromatism = None
                self.psdMcaoWFsensCone = None
                self.psdVib = None
                self.psdExtra = None
                self.psdExtraLo = None

            # Total wavefront error
            self.wfeTot = np.sqrt(self.wfeNCPA**2 + self.wfeFit**2 + self.wfeAl**2\
                                  + self.wfeST**2 + self.wfeN**2 + self.wfeDiffRef**2\
                                  + self.wfeChrom**2 + self.wfeJitter**2 + self.wfeMcaoCone**2\
                                  + self.wfeWindShake**2 + self.wfeExtra**2)

            # Maréchal appoximation to get the Strehl-ratio
            self.SRmar  = 100*np.exp(-(self.wfeTot*2*np.pi*1e-9/self.freq.wvlRef)**2)

            # bonus
            self.psdS = self.servoLagPSD()
            self.wfeS = np.sqrt(self.psdS.sum()) * rad2nm
            self.wfeR = np.sqrt(max(0,self.reconstructionPSD().sum()))* rad2nm
            if self.nGs == 1:
                self.psdAni = self.anisoplanatismPSD()
                self.wfeAni = np.sqrt(self.psdAni.sum(axis=(0,1))) * rad2nm
            else:
                self.wfeTomo = np.sqrt(self.wfeST**2 - self.wfeS**2)

            if self.reduce_memory:
                self.psdS = None
                self.psdAni = None

            # Print
            if verbose == True:
                print('\n_____ ERROR BREAKDOWN  ON-AXIS_____')
                print('------------------------------------------')
                idCenter = self.ao.src.zenith.argmin()
                if hasattr(self,'SR'):
                    print('.Image Strehl at %4.2fmicron:\t%4.2f%s'%(self.freq.wvlRef*1e6,self.SR[idCenter,0],'%'))
                print('.Maréchal Strehl at %4.2fmicron:\t%4.2f%s'%(self.ao.atm.wvl*1e6,self.SRmar[idCenter],'%'))
                print('.Residual wavefront error:\t%4.2fnm'%self.wfeTot[idCenter])
                print('.NCPA residual:\t\t\t%4.2fnm'%self.wfeNCPA)
                print('.Fitting error:\t\t\t%4.2fnm'%self.wfeFit)
                print('.Differential refraction:\t%4.2fnm'%self.wfeDiffRef[idCenter])
                print('.Chromatic error:\t\t%4.2fnm'%self.wfeChrom[idCenter])
                print('.Aliasing error:\t\t%4.2fnm'%self.wfeAl)
                if self.nGs == 1:
                    print('.Noise error:\t\t\t%4.2fnm'%self.wfeN)
                else:
                    print('.Noise error:\t\t\t%4.2fnm'%self.wfeN[idCenter])
                print('.Spatio-temporal error:\t\t%4.2fnm'%self.wfeST[idCenter])
                print('.Wind-shake error:\t\t%4.2fnm'%self.wfeWindShake)
                print('.Additionnal jitter:\t\t%4.2fmas / %4.2fnm'%(nnp.mean(self.ao.cam.spotFWHM[0][0:2]),self.wfeJitter))
                if self.ao.addMcaoWFsensConeError:
                    print('.Mcao Cone:\t\t\t%4.2fnm'%self.wfeMcaoCone)
                print('.Extra error:\t\t\t%4.2fnm'%self.wfeExtra)
                print('-------------------------------------------')
                print('.Sole servoLag error:\t\t%4.2fnm'%self.wfeS)
                print('.Sole reconstruction error:\t%4.2fnm'%self.wfeR)
                print('-------------------------------------------')
                if self.nGs == 1:
                    print('.Sole anisoplanatism error:\t%4.2fnm'%self.wfeAni[idCenter])
                else:
                    print('.Sole tomographic error:\t%4.2fnm'%self.wfeTomo[idCenter])
                print('-------------------------------------------')

        self.t_errorBreakDown = 1000*(time.time() - tstart)

  #%% PSF COMPUTATION
    def point_spread_function(self, x0=[], nPix=None, verbose=False,
                            fftphasor=False, addOtfPixel=False):
        """
          Computation of the 4D PSF from the 3D cube of phase structure function
          If x0 kept empty, the residual jitter is included from the values given
          in the .ini file.
        """

        tstart  = time.time()

        # ----------------- GETTING THE PARAMETERS
        Cn2, r0, x0_dphi, x0_jitter, x0_stellar, x0_stat \
            = FourierUtils.sort_params_from_labels(self, x0)

        # ----------------- MANAGING THE PIXEL OTF
        otfPixel=1
        if addOtfPixel:
            otfPixel = np.sinc(self.freq.U_)* np.sinc(self.freq.V_)

        # ----------------- COMPUTING THE PSF
        PSF, SR = FourierUtils.sf_3D_to_psf_4D(self.SF,
                                               self.freq,
                                               self.ao,
                                               x_jitter = x0_jitter,
                                               x_stat = x0_stat,
                                               x_stellar = x0_stellar,
                                               nPix = nPix,
                                               otfPixel = otfPixel)

        self.t_getPSF = 1000*(time.time() - tstart)

        return PSF, SR

    def __call__(self, x0, nPix=None):

        psf,_ = self.point_spread_function(x0 = x0, nPix = nPix,
                                           verbose = False,
                                           fftphasor = True,
                                           addOtfPixel = self.addOtfPixel)
        return psf


  #%% METRICS COMPUTATION
    def getPsfMetrics(self, getEnsquaredEnergy=False, getEncircledEnergy=False, getFWHM=False):
        tstart  = time.time()
        self.FWHM = np.zeros((2,self.ao.src.nSrc,self.freq.nWvl),
                             dtype=self.dtype)

        if getEnsquaredEnergy==True:
            self.EnsqE = np.zeros((int(self.freq.nOtf/2)+1,self.ao.src.nSrc,self.freq.nWvl),
                                  dtype=self.dtype)
        if getEncircledEnergy==True:
            rr, radialprofile = FourierUtils.radial_profile(self.PSF[:,:,0,0])
            self.EncE = np.zeros((len(radialprofile),self.ao.src.nSrc,self.freq.nWvl),
                                   dtype=self.dtype)
        for n in range(self.ao.src.nSrc):
            for j in range(self.freq.nWvl):
                if getFWHM == True:
                    self.FWHM[:,n,j]  = FourierUtils.getFWHM(self.PSF[:,:,n,j],
                                                             self.freq.psInMas[j],
                                                             rebin=1,
                                                             method='contour',
                                                             nargout=2)
                if getEnsquaredEnergy == True:
                    self.EnsqE[:,n,j] = 1e2*FourierUtils.getEnsquaredEnergy(self.PSF[:,:,n,j])
                if getEncircledEnergy == True:
                    self.EncE[:,n,j]  = 1e2*FourierUtils.getEncircledEnergy(self.PSF[:,:,n,j])

        self.t_getPsfMetrics = 1000*(time.time() - tstart)

    def estimate_memory_usage(self, include_peak=True):
        """
        Approximate memory estimation (in MB) for the fourierModel 
        when calcPSF is False.
        
        Updated to reflect chunked aliasing PSD computation.
        
        Parameters
        ----------
        include_peak : bool, optional
            If True, includes peak memory estimate during initComputations (default: True)
        
        Returns
        -------
        dict
            Dictionary with detailed memory estimate per component
        """

        if self.dtype == np.float32:
            dtype_size = 4
        else:
            dtype_size = 8

        # Main dimensions
        if not hasattr(self, 'freq'):
            freq = frequencyDomain(
                self.ao,
                nyquistSampling=self.nyquistSampling,
                computeFocalAnisoCov=self.computeFocalAnisoCov
            )
            n_otf = getattr(freq, 'nOtf', 0)
            res_ao = getattr(freq, 'resAO', 0)
            n_times = freq.nTimes
        else:
            n_otf = getattr(self.freq, 'nOtf', 0)
            res_ao = getattr(self.freq, 'resAO', 0)
            n_times = self.freq.nTimes

        n_gs = getattr(self, 'nGs', 1)
        n_src = getattr(self.ao.src, 'nSrc', n_gs)
        n_wvl = getattr(self, 'nwvl', 1)
        n_atm = getattr(self.ao.atm, 'nL', 1)
        n_dm = len(getattr(self.ao.dms, 'heights', [0]))

        memory_breakdown = {}
        peak_breakdown = {}

        # ============ FINAL MEMORY (persistent arrays) ============

        # Main PSD (3D: nOtf x nOtf x nSrc)
        memory_breakdown['PSD'] = n_otf * n_otf * n_src * dtype_size

        # Structure function
        memory_breakdown['SF'] = n_otf * n_otf * n_src * dtype_size

        # Reconstructor arrays (if gain > 0)
        if self.ao.rtc.holoop['gain'] > 0:
            memory_breakdown['Rx_Ry'] = 2 * res_ao * res_ao * dtype_size * 2  # complex
            memory_breakdown['SxAv_SyAv'] = 2 * res_ao * res_ao * dtype_size * 2
            memory_breakdown['Wphi'] = res_ao * res_ao * dtype_size
            memory_breakdown['h1_h2_hn'] = 3 * res_ao * res_ao * dtype_size

            # Tomography (if nGs > 1 and not reduce_memory)
            if n_gs > 1 and not self.reduce_memory:
                memory_breakdown['Walpha'] = res_ao * res_ao * n_gs * n_atm * dtype_size * 2
                memory_breakdown['PbetaDM'] = res_ao * res_ao * n_src * n_dm * dtype_size * 2
                memory_breakdown['Cb'] = res_ao * res_ao * n_gs * n_gs * dtype_size * 2
                memory_breakdown['Cphi'] = res_ao * res_ao * n_atm * n_atm * dtype_size * 2

        # Partial PSDs (if getErrorBreakDown or not reduce_memory)
        if self.getErrorBreakDown or not self.reduce_memory:
            memory_breakdown['psdFit'] = n_otf * n_otf * dtype_size
            memory_breakdown['psdAlias'] = res_ao * res_ao * dtype_size
            memory_breakdown['psdNoise'] = res_ao * res_ao * (n_src if n_gs > 1 else 1) * dtype_size
            memory_breakdown['psdSpatioTemporal'] = res_ao * res_ao * n_src * dtype_size
            memory_breakdown['psdDiffRef'] = res_ao * res_ao * n_src * dtype_size
            memory_breakdown['psdChromatism'] = res_ao * res_ao * n_src * dtype_size

        # Frequency arrays
        memory_breakdown['freq_arrays'] = 5 * n_otf * n_otf * dtype_size
        memory_breakdown['freq_arrays_AO'] = 5 * res_ao * res_ao * dtype_size

        # Static OTF
        memory_breakdown['otfDL_otfNCPA'] = 2 * n_otf * n_otf * dtype_size * 2  # complex

        # ============ PEAK MEMORY (temporary arrays) ============

        if include_peak and self.ao.rtc.holoop['gain'] > 0:

            # 1. tomographicReconstructor(): memory-intensive for MCAO
            if n_gs > 1:
                peak_breakdown['tomo_Cphi'] = res_ao * res_ao * n_atm * n_atm * dtype_size * 2
                peak_breakdown['tomo_to_inv'] = res_ao * res_ao * n_gs * n_gs * dtype_size * 2
                peak_breakdown['tomo_Wtomo'] = res_ao * res_ao * n_atm * n_gs * dtype_size * 2

            # 2. optimalProjector()
            if n_gs > 1:
                peak_breakdown['opt_mat1'] = res_ao * res_ao * n_dm * n_atm * dtype_size * 2
                peak_breakdown['opt_A'] = res_ao * res_ao * n_dm * n_dm * dtype_size * 2

            # 3. aliasingPSD(): **UPDATED WITH CHUNKING**
            # Now uses fixed-size chunks instead of allocating all layers at once
            n_shifts = (2 * n_times) ** 2
            chunk_size = min(5, n_atm)  # Adjust chunk size

            # Memory for one vectorized chunk (n_layers_chunk, nShifts, nShifts, resAO, resAO)
            # Always allocate chunk_size layers (even if last chunk is smaller)
            peak_breakdown['alias_avr_chunk'] = chunk_size * n_shifts * res_ao * res_ao * dtype_size * 2

            # Accumulator for summing chunks (nShifts, nShifts, resAO, resAO)
            peak_breakdown['alias_avr_sum'] = n_shifts * res_ao * res_ao * dtype_size * 2

            # Intermediate arrays (km, kn, PR, W_mn, Q, etc.)
            peak_breakdown['alias_intermediates'] = 5 * n_shifts * res_ao * res_ao * dtype_size * 2

            # 4. spatioTemporalPSD() - per source
            if n_gs > 1:
                peak_breakdown['ST_proj'] = res_ao * res_ao * n_atm * dtype_size * 2

            # 5. FFT operations
            peak_breakdown['fft_buffer'] = n_otf * n_otf * dtype_size * 2

        # Compute totals
        total_final = sum(memory_breakdown.values())
        total_peak_temp = sum(peak_breakdown.values())
        total_peak = total_final + total_peak_temp

        final_mb = total_final / (1024**2)
        final_gb = total_final / (1024**3)
        peak_mb = total_peak / (1024**2)
        peak_gb = total_peak / (1024**3)

        # Prepare output
        result = {
            'final_MB': final_mb,
            'final_GB': final_gb,
            'peak_MB': peak_mb if include_peak else final_mb,
            'peak_GB': peak_gb if include_peak else final_gb,
            'breakdown_final_MB': {k: v/(1024**2) for k, v in sorted(memory_breakdown.items(), 
                                                                    key=lambda x: x[1],
                                                                    reverse=True)},
            'breakdown_peak_temp_MB': {k: v/(1024**2) for k, v in sorted(peak_breakdown.items(), 
                                                                        key=lambda x: x[1],
                                                                        reverse=True)} \
                                    if include_peak else {},
            'dimensions': {
                'nOtf': n_otf,
                'resAO': res_ao,
                'nSrc': n_src,
                'nGs': n_gs,
                'nAtm': n_atm,
                'nDM': n_dm,
                'nTimes': n_times,
                'nShifts': (2 * n_times) ** 2,
                'chunk_size': 5,
                'n_chunks': (n_atm + 4) // 5  # Ceiling division
            }
        }

        return result

#%% DISPLAY

    def displayResults(self,eeRadiusInMas=75,displayContour=False):
        """
        """
        tstart  = time.time()
        # GEOMETRY
        plt.figure()
        plt.polar(self.ao.src.azimuth*deg2rad,self.ao.src.zenith,'ro',
                  markersize=7,label='PSF evaluation (arcsec)')
        plt.polar(self.gs.azimuth*deg2rad,self.gs.zenith,'bs',
                  markersize=7,label='GS position')
        plt.polar(self.ao.dms.opt_dir[1]*deg2rad,self.ao.dms.opt_dir[0],'kx',
                  markersize=10,label='Optimization directions')
        plt.legend(bbox_to_anchor=(1.05, 1))

        if hasattr(self,'PSF'):
            if self.PSF.ndim == 2:
                plt.figure()
                plt.imshow(np.log10(np.abs(self.PSF)))
            else:
                # PSFs
                if np.any(self.PSF):
                    nmin = self.ao.src.zenith.argmin()
                    nmax = self.ao.src.zenith.argmax()
                    plt.figure()
                    if self.PSF.shape[2] >1 and self.PSF.shape[3] == 1:
                        plt.title(f"PSFs at {self.ao.src.zenith[nmin]:.1f} and"
                                  f" {self.ao.src.zenith[nmax]:.1f} arcsec from center")
                        P = np.concatenate((self.PSF[:,:,nmin,0],self.PSF[:,:,nmax,0]),axis=1)
                    elif self.PSF.shape[2] >1 and self.PSF.shape[3] >1:
                        plt.title(f"PSFs at {self.ao.src.zenith[0]:.0f} and {self.ao.src.zenith[-1]:.0f}"
                                  f" arcsec from center\n - Top: {1e9*self.wvl[0]:.0f}nm -"
                                  f" Bottom:{1e9*self.wvl[-1]:.0f} nm")
                        P1 = np.concatenate((self.PSF[:,:,nmin,0],self.PSF[:,:,nmax,0]),axis=1)
                        P2 = np.concatenate((self.PSF[:,:,nmin,-1],self.PSF[:,:,nmax,-1]),axis=1)
                        P  = np.concatenate((P1,P2),axis=0)
                    else:
                        plt.title('PSF')
                        P = self.PSF[:,:,nmin,0]
                    plt.imshow(np.log10(np.abs(P)))

                if displayContour == True and np.any(self.SR) and self.SR.size > 1:
                    self.displayPsfMetricsContours(eeRadiusInMas=eeRadiusInMas)
                else:
                    # STREHL-RATIO
                    if hasattr(self,'SR') and np.any(self.SR) and self.SR.size > 1:
                        plt.figure()
                        plt.plot(self.ao.src.zenith,self.SR[:,0],'bo',markersize=10)
                        plt.xlabel("Off-axis distance")
                        plt.ylabel(f"Strehl-ratio at {self.freq.wvlRef*1e9:.1f} nm (percents)")
                        plt.show()

                    # FWHM
                    if hasattr(self,'FWHM') and np.any(self.FWHM) and self.FWHM.size > 1:
                        plt.figure()
                        plt.plot(self.ao.src.zenith,0.5*(self.FWHM[0,:,0]+self.FWHM[1,:,0]),
                                 'bo',markersize=10)
                        plt.xlabel("Off-axis distance")
                        plt.ylabel(f"Mean FWHM at {self.freq.wvlRef*1e9:.1f} nm (mas)")
                        plt.show()

                    # Ensquared energy
                    if hasattr(self,'EnsqE') and np.any(self.EnsqE):
                        nntrue      = eeRadiusInMas/self.freq.psInMas[0]
                        nn2         = int(nntrue)
                        EEmin       = self.EnsqE[nn2,:,0]
                        EEmax       = self.EnsqE[nn2+1,:,0]
                        EEtrue      = (nntrue - nn2)*EEmax + (nn2+1-nntrue)*EEmin
                        plt.figure()
                        plt.plot(self.ao.src.zenith,EEtrue,'bo',markersize=10)
                        plt.xlabel("Off-axis distance")
                        plt.ylabel(f"{eeRadiusInMas:.1f}-mas-side Ensquared energy at"
                                   f" {self.freq.wvlRef*1e9:.1f} nm (percents)")
                        plt.show()

                    if hasattr(self,'EncE') and np.any(self.EncE):
                        nntrue      = eeRadiusInMas/self.freq.psInMas[0]
                        nn2         = int(nntrue)
                        EEmin       = self.EncE[nn2,:,0]
                        EEmax       = self.EncE[nn2+1,:,0]
                        EEtrue      = (nntrue - nn2)*EEmax + (nn2+1-nntrue)*EEmin
                        plt.figure()
                        plt.plot(self.ao.src.zenith,EEtrue,'bo',markersize=10)
                        plt.xlabel("Off-axis distance")
                        plt.ylabel(f"{eeRadiusInMas*2:.1f}-mas-diameter Encircled energy at"
                                   f" {self.freq.wvlRef*1e9:.1f} nm (percents)")
                        plt.show()

        self.t_displayResults = 1000*(time.time() - tstart)

    def displayPsfMetricsContours(self,eeRadiusInMas=75,wvlIndex=0):

        tstart  = time.time()
        # Polar to cartesian
        x = self.ao.src.zenith * np.cos(np.pi/180*self.ao.src.azimuth)
        y = self.ao.src.zenith * np.sin(np.pi/180*self.ao.src.azimuth)

        nn = int(np.sqrt(self.SR.shape[0]))

        if nn**2 == self.SR.shape[0]:
            nIntervals  = nn
            X           = np.reshape(x,(nn,nn))
            Y           = np.reshape(y,(nn,nn))

            # Strehl-ratio
            if hasattr(self,'SR') and  np.any(self.SR):
                SR = np.reshape(self.SR[:,wvlIndex],(nn,nn))
                plt.figure()
                contours = plt.contour(X, Y, SR, nIntervals, colors='black')
                plt.clabel(contours, inline=True,fmt='%1.1f')
                plt.contourf(X,Y,SR)
                plt.title(f"Strehl-ratio at {self.freq.wvl[wvlIndex]*1e9:.1f} nm (percents)")
                plt.colorbar()

            # FWHM
            if hasattr(self,'FWHM') and np.any(self.FWHM) and self.FWHM.size > 1:
                FWHM = np.reshape(0.5*(self.FWHM[0,:,wvlIndex] + self.FWHM[1,:,wvlIndex]),(nn,nn))
                plt.figure()
                contours = plt.contour(X, Y, FWHM, nIntervals, colors='black')
                plt.clabel(contours, inline=True,fmt='%1.1f')
                plt.contourf(X,Y,FWHM)
                plt.title(f"Mean FWHM at {self.freq.wvl[wvlIndex]*1e9:.1f} nm (mas)")
                plt.colorbar()

            # Ensquared Enery
            if hasattr(self,'EnsqE') and np.any(self.EnsqE) and self.EnsqE.shape[1] > 1:
                nntrue      = eeRadiusInMas/self.freq.psInMas[0]
                nn2         = int(nntrue)
                EEmin       = self.EnsqE[nn2,:,wvlIndex]
                EEmax       = self.EnsqE[nn2+1,:,wvlIndex]
                EEtrue      = (nntrue - nn2)*EEmax + (nn2+1-nntrue)*EEmin
                EE          = np.reshape(EEtrue,(nn,nn))
                plt.figure()
                contours = plt.contour(X, Y, EE, nIntervals, colors='black')
                plt.clabel(contours, inline=True,fmt='%1.1f')
                plt.contourf(X,Y,EE)
                plt.title(f"{eeRadiusInMas*2:.1f}-mas-side Ensquared energy at"
                          f" {self.freq.wvl[wvlIndex]*1e9:.1f} nm (percents)")
                plt.colorbar()

            # Encircled Enery
            if hasattr(self,'EncE') and np.any(self.EncE) and self.EncE.shape[1] > 1:
                nntrue      = eeRadiusInMas/self.freq.psInMas[wvlIndex]
                nn2         = int(nntrue)
                EEmin       = self.EncE[nn2,:,wvlIndex]
                EEmax       = self.EncE[nn2+1,:,wvlIndex]
                EEtrue      = (nntrue - nn2)*EEmax + (nn2+1-nntrue)*EEmin
                EE          = np.reshape(EEtrue,(nn,nn))
                plt.figure()
                contours = plt.contour(X, Y, EE, nIntervals, colors='black')
                plt.clabel(contours, inline=True,fmt='%1.1f')
                plt.contourf(X,Y,EE)
                plt.title(f"{eeRadiusInMas*2:.1f}-mas-diameter Encircled energy at"
                          f" {self.freq.wvl[wvlIndex]*1e9:.1f} nm (percents)")
                plt.colorbar()
        else:
            print('You must define a square grid for PSF evaluations directions'
                  ' - no contours plots avalaible')

        self.t_displayPsfMetricsContours = 1000*(time.time() - tstart)

    def displayExecutionTime(self):
        """
        Display execution time breakdown for all computation steps
        """

        print("\n" + "="*70)
        print("EXECUTION TIME BREAKDOWN")
        print("="*70)

        # Total time
        if self.t_init > 0:
            print(f"\n{'Total calculation time:':<45} {self.t_init:>8.1f} ms")

        if self.t_initAO > 0:
            print(f"{'AO system model initialization:':<45} {self.t_initAO:>8.1f} ms")

        if self.ao.error == False:
            print("\n--- Initialization ---")

            if self.t_initFreq > 0:
                print(f"{'Frequency domain initialization:':<45} {self.t_initFreq:>8.1f} ms")

            if self.t_atmo > 0:
                print(f"{'Atmosphere model initialization:':<45} {self.t_atmo:>8.1f} ms")

            # Reconstructors
            if self.ao.rtc.holoop['gain'] > 0:
                print("\n--- Reconstructors & Controller ---")

                if self.t_reconstructor > 0:
                    print(f"{'WFS reconstructors initialization:':<45}"
                          f" {self.t_reconstructor:>8.1f} ms")

                if self.nGs > 1:
                    if self.t_finalReconstructor > 0:
                        print(f"{'Final reconstructor calculation:':<45}"
                              f" {self.t_finalReconstructor:>8.1f} ms")

                    if self.t_tomo > 0:
                        print(f"  {'- Tomography:':<43} {self.t_tomo:>8.1f} ms")

                    if self.t_opt > 0:
                        print(f"  {'- Optimal projector:':<43} {self.t_opt:>8.1f} ms")

                if self.t_controller > 0:
                    print(f"{'Controller instantiation:':<45} {self.t_controller:>8.1f} ms")

            # PSD calculations
            if self.ao.rtc.holoop['gain'] > 0:
                print("\n--- PSD Calculations ---")

                if self.t_fittingPSD > 0:
                    print(f"{'Fitting PSD:':<45} {self.t_fittingPSD:>8.1f} ms")

                if self.t_aliasingPSD > 0:
                    print(f"{'Aliasing PSD:':<45} {self.t_aliasingPSD:>8.1f} ms")

                if self.t_noisePSD > 0:
                    print(f"{'Noise PSD:':<45} {self.t_noisePSD:>8.1f} ms")

                if self.t_spatioTemporalPSD > 0:
                    print(f"{'Spatio-temporal PSD:':<45} {self.t_spatioTemporalPSD:>8.1f} ms")

                if self.t_windShakePSD > 0:
                    print(f"{'Wind shake/vibrations PSD:':<45}"
                          f" {self.t_windShakePSD:>8.1f} ms")

                if self.t_focalAnisoplanatism > 0:
                    print(f"{'Focal anisoplanatism PSD:':<45}"
                          f" {self.t_focalAnisoplanatism:>8.1f} ms")

                if self.t_mcaoWFsensCone > 0:
                    print(f"{'MCAO WFS cone effect PSD:':<45} {self.t_mcaoWFsensCone:>8.1f} ms")

                if self.t_extra > 0:
                    print(f"{'Extra error PSD:':<45} {self.t_extra:>8.1f} ms")

                if self.t_extraLo > 0:
                    print(f"{'Extra error PSD (LO):':<45} {self.t_extraLo:>8.1f} ms")

                if self.t_tiltFilter > 0:
                    print(f"{'Tilt filter calculation:':<45} {self.t_tiltFilter:>8.1f} ms")

                if self.t_focusFilter > 0:
                    print(f"{'Focus filter calculation:':<45}"
                          f" {self.t_focusFilter:>8.1f} ms")

                if self.t_powerSpectrumDensity > 0:
                    print(f"\n{'Total PSD calculation:':<45}"
                          f"{self.t_powerSpectrumDensity:>8.1f} ms")

            # Analysis
            print("\n--- Analysis ---")

            if self.t_errorBreakDown > 0:
                print(f"{'Error breakdown calculation:':<45} {self.t_errorBreakDown:>8.1f} ms")

            if self.t_getPsfMetrics > 0:
                print(f"{'PSF metrics calculation:':<45} {self.t_getPsfMetrics:>8.1f} ms")

            # PSF and display
            if self.calcPSF:
                print("\n--- PSF Computation & Display ---")

                if self.t_getPSF > 0:
                    print(f"{'PSF calculation:':<45} {self.t_getPSF:>8.1f} ms")

                if self.display and self.t_displayResults > 0:
                    print(f"{'Display figures:':<45} {self.t_displayResults:>8.1f} ms")

        print("="*70 + "\n")

import pathlib
file_ini0 = str(pathlib.Path(__file__).parent.parent.absolute()) + '/dummy.ini'
faoDummy = fourierModel(path_ini=file_ini0, calcPSF=False, verbose=False, display=False,
                        path_root="", doComputations=True, computeFocalAnisoCov=False,
                        reduce_memory=True)
faoDummy = None
