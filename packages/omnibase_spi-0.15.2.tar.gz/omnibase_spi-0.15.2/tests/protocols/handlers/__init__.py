"""Tests for handler protocols."""
