"""Quick test: can agents discover and use skills with the current system prompt?"""

import asyncio
import sys
from pathlib import Path

# Add parent to path so imports work
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from agents.base import BaseAgent


class TestAgent(BaseAgent):
    allowed_tools = ["Skill", "Read", "Grep", "Glob", "Bash"]
    permission_mode = "bypassPermissions"
    setting_sources = ["user", "project"]


async def main():
    cwd = str(Path(__file__).resolve().parent.parent)
    agent = TestAgent(cwd=cwd, debug="--debug" in sys.argv)
    result = await agent.invoke(
        "List all available skills using the Skill tool. "
        "Just list them and stop — do not invoke any skill."
    )
    print("\n=== Result ===")
    print(result.text)
    print(f"\nTurns: {result.num_turns}")


if __name__ == "__main__":
    asyncio.run(main())
