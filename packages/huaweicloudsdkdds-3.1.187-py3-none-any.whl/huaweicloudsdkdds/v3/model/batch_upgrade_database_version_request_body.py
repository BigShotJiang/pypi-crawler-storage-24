# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class BatchUpgradeDatabaseVersionRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'instance_ids': 'list[str]'
    }

    attribute_map = {
        'instance_ids': 'instance_ids'
    }

    def __init__(self, instance_ids=None):
        r"""BatchUpgradeDatabaseVersionRequestBody

        The model defined in huaweicloud sdk

        :param instance_ids: 指定需要升级数据库补丁版本的实例ID列表。 一次最多可传入10个实例ID。
        :type instance_ids: list[str]
        """
        
        

        self._instance_ids = None
        self.discriminator = None

        self.instance_ids = instance_ids

    @property
    def instance_ids(self):
        r"""Gets the instance_ids of this BatchUpgradeDatabaseVersionRequestBody.

        指定需要升级数据库补丁版本的实例ID列表。 一次最多可传入10个实例ID。

        :return: The instance_ids of this BatchUpgradeDatabaseVersionRequestBody.
        :rtype: list[str]
        """
        return self._instance_ids

    @instance_ids.setter
    def instance_ids(self, instance_ids):
        r"""Sets the instance_ids of this BatchUpgradeDatabaseVersionRequestBody.

        指定需要升级数据库补丁版本的实例ID列表。 一次最多可传入10个实例ID。

        :param instance_ids: The instance_ids of this BatchUpgradeDatabaseVersionRequestBody.
        :type instance_ids: list[str]
        """
        self._instance_ids = instance_ids

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, BatchUpgradeDatabaseVersionRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
