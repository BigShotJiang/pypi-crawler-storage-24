# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DeleteLtsConfigRequestBodyLtsConfigs:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'instance_id': 'str',
        'log_type': 'LtsLogType'
    }

    attribute_map = {
        'instance_id': 'instance_id',
        'log_type': 'log_type'
    }

    def __init__(self, instance_id=None, log_type=None):
        r"""DeleteLtsConfigRequestBodyLtsConfigs

        The model defined in huaweicloud sdk

        :param instance_id: 实例ID。
        :type instance_id: str
        :param log_type: 
        :type log_type: :class:`huaweicloudsdkdds.v3.LtsLogType`
        """
        
        

        self._instance_id = None
        self._log_type = None
        self.discriminator = None

        if instance_id is not None:
            self.instance_id = instance_id
        if log_type is not None:
            self.log_type = log_type

    @property
    def instance_id(self):
        r"""Gets the instance_id of this DeleteLtsConfigRequestBodyLtsConfigs.

        实例ID。

        :return: The instance_id of this DeleteLtsConfigRequestBodyLtsConfigs.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this DeleteLtsConfigRequestBodyLtsConfigs.

        实例ID。

        :param instance_id: The instance_id of this DeleteLtsConfigRequestBodyLtsConfigs.
        :type instance_id: str
        """
        self._instance_id = instance_id

    @property
    def log_type(self):
        r"""Gets the log_type of this DeleteLtsConfigRequestBodyLtsConfigs.

        :return: The log_type of this DeleteLtsConfigRequestBodyLtsConfigs.
        :rtype: :class:`huaweicloudsdkdds.v3.LtsLogType`
        """
        return self._log_type

    @log_type.setter
    def log_type(self, log_type):
        r"""Sets the log_type of this DeleteLtsConfigRequestBodyLtsConfigs.

        :param log_type: The log_type of this DeleteLtsConfigRequestBodyLtsConfigs.
        :type log_type: :class:`huaweicloudsdkdds.v3.LtsLogType`
        """
        self._log_type = log_type

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DeleteLtsConfigRequestBodyLtsConfigs):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
