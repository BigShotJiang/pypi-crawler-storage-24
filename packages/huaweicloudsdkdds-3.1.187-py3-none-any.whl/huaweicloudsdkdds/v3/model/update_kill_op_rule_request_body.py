# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UpdateKillOpRuleRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'ids': 'list[str]',
        'action': 'str'
    }

    attribute_map = {
        'ids': 'ids',
        'action': 'action'
    }

    def __init__(self, ids=None, action=None):
        r"""UpdateKillOpRuleRequestBody

        The model defined in huaweicloud sdk

        :param ids: killOp规则ID列表。
        :type ids: list[str]
        :param action: 启用/禁用 killOp规则。  - enable，启用killOp规则。 - disable，禁用killOp规则。
        :type action: str
        """
        
        

        self._ids = None
        self._action = None
        self.discriminator = None

        self.ids = ids
        self.action = action

    @property
    def ids(self):
        r"""Gets the ids of this UpdateKillOpRuleRequestBody.

        killOp规则ID列表。

        :return: The ids of this UpdateKillOpRuleRequestBody.
        :rtype: list[str]
        """
        return self._ids

    @ids.setter
    def ids(self, ids):
        r"""Sets the ids of this UpdateKillOpRuleRequestBody.

        killOp规则ID列表。

        :param ids: The ids of this UpdateKillOpRuleRequestBody.
        :type ids: list[str]
        """
        self._ids = ids

    @property
    def action(self):
        r"""Gets the action of this UpdateKillOpRuleRequestBody.

        启用/禁用 killOp规则。  - enable，启用killOp规则。 - disable，禁用killOp规则。

        :return: The action of this UpdateKillOpRuleRequestBody.
        :rtype: str
        """
        return self._action

    @action.setter
    def action(self, action):
        r"""Sets the action of this UpdateKillOpRuleRequestBody.

        启用/禁用 killOp规则。  - enable，启用killOp规则。 - disable，禁用killOp规则。

        :param action: The action of this UpdateKillOpRuleRequestBody.
        :type action: str
        """
        self._action = action

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UpdateKillOpRuleRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
