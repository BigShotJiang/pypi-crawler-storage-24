# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateManualBackupRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'backup': 'CreateManualBackupOption'
    }

    attribute_map = {
        'backup': 'backup'
    }

    def __init__(self, backup=None):
        r"""CreateManualBackupRequestBody

        The model defined in huaweicloud sdk

        :param backup: 
        :type backup: :class:`huaweicloudsdkdds.v3.CreateManualBackupOption`
        """
        
        

        self._backup = None
        self.discriminator = None

        self.backup = backup

    @property
    def backup(self):
        r"""Gets the backup of this CreateManualBackupRequestBody.

        :return: The backup of this CreateManualBackupRequestBody.
        :rtype: :class:`huaweicloudsdkdds.v3.CreateManualBackupOption`
        """
        return self._backup

    @backup.setter
    def backup(self, backup):
        r"""Sets the backup of this CreateManualBackupRequestBody.

        :param backup: The backup of this CreateManualBackupRequestBody.
        :type backup: :class:`huaweicloudsdkdds.v3.CreateManualBackupOption`
        """
        self._backup = backup

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateManualBackupRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
