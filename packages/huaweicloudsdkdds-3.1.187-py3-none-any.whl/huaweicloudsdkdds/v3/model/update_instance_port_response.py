# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UpdateInstancePortResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'job_id': 'str',
        'port': 'int'
    }

    attribute_map = {
        'job_id': 'job_id',
        'port': 'port'
    }

    def __init__(self, job_id=None, port=None):
        r"""UpdateInstancePortResponse

        The model defined in huaweicloud sdk

        :param job_id: 任务ID。
        :type job_id: str
        :param port: 实例当前端口号。
        :type port: int
        """
        
        super().__init__()

        self._job_id = None
        self._port = None
        self.discriminator = None

        if job_id is not None:
            self.job_id = job_id
        if port is not None:
            self.port = port

    @property
    def job_id(self):
        r"""Gets the job_id of this UpdateInstancePortResponse.

        任务ID。

        :return: The job_id of this UpdateInstancePortResponse.
        :rtype: str
        """
        return self._job_id

    @job_id.setter
    def job_id(self, job_id):
        r"""Sets the job_id of this UpdateInstancePortResponse.

        任务ID。

        :param job_id: The job_id of this UpdateInstancePortResponse.
        :type job_id: str
        """
        self._job_id = job_id

    @property
    def port(self):
        r"""Gets the port of this UpdateInstancePortResponse.

        实例当前端口号。

        :return: The port of this UpdateInstancePortResponse.
        :rtype: int
        """
        return self._port

    @port.setter
    def port(self, port):
        r"""Sets the port of this UpdateInstancePortResponse.

        实例当前端口号。

        :param port: The port of this UpdateInstancePortResponse.
        :type port: int
        """
        self._port = port

    def to_dict(self):
        import warnings
        warnings.warn("UpdateInstancePortResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UpdateInstancePortResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
