# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UpdateBackupDownloadPolicyRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'str',
        'action': 'str'
    }

    attribute_map = {
        'id': 'id',
        'action': 'action'
    }

    def __init__(self, id=None, action=None):
        r"""UpdateBackupDownloadPolicyRequestBody

        The model defined in huaweicloud sdk

        :param id: 备份下载策略id。
        :type id: str
        :param action: 备份下载开关。open表示打开备份下载开关，允许外网下载。close表示关闭备份下载开关，不允许外网下载。
        :type action: str
        """
        
        

        self._id = None
        self._action = None
        self.discriminator = None

        self.id = id
        self.action = action

    @property
    def id(self):
        r"""Gets the id of this UpdateBackupDownloadPolicyRequestBody.

        备份下载策略id。

        :return: The id of this UpdateBackupDownloadPolicyRequestBody.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this UpdateBackupDownloadPolicyRequestBody.

        备份下载策略id。

        :param id: The id of this UpdateBackupDownloadPolicyRequestBody.
        :type id: str
        """
        self._id = id

    @property
    def action(self):
        r"""Gets the action of this UpdateBackupDownloadPolicyRequestBody.

        备份下载开关。open表示打开备份下载开关，允许外网下载。close表示关闭备份下载开关，不允许外网下载。

        :return: The action of this UpdateBackupDownloadPolicyRequestBody.
        :rtype: str
        """
        return self._action

    @action.setter
    def action(self, action):
        r"""Sets the action of this UpdateBackupDownloadPolicyRequestBody.

        备份下载开关。open表示打开备份下载开关，允许外网下载。close表示关闭备份下载开关，不允许外网下载。

        :param action: The action of this UpdateBackupDownloadPolicyRequestBody.
        :type action: str
        """
        self._action = action

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UpdateBackupDownloadPolicyRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
