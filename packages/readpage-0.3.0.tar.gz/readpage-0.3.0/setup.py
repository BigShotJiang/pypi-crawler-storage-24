from setuptools import setup


setup(
    name="readpage",
    version="0.3.0",
    description="MCP tool server for AI agents.",
    packages=["readpage"],
    include_package_data=True,
    install_requires=["owlvin-tools>=0.2.0"],
    entry_points={
        "console_scripts": [
            "readpage=readpage:main",
        ],
    },
    python_requires=">=3.10",
)
