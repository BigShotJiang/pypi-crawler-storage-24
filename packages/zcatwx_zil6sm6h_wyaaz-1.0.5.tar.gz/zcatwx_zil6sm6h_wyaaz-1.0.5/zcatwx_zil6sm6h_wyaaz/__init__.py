from __future__ import annotations
import json, os
from zcatwx_zil6sm6h_wyaaz._core import (
    JianYingDraft, VideoClip, AudioClip, TextClip,
    StickerClip, EffectClip, FilterClip,
)
from zcatwx_zil6sm6h_wyaaz.protocol import (
    DraftCrypto,
    looks_like_json,
    normalize_input_json,
)
from zcatwx_zil6sm6h_wyaaz.resource_lookup import (
    resolve_audio_effect_resource_id,
    resolve_animation_entries,
    resolve_bubble_resource_id,
    resolve_effect_resource_id,
    resolve_filter_resource_id,
    resolve_font_resource_id,
    resolve_sticker_resource_id,
    resolve_text_effect_resource_id,
)
from zcatwx_zil6sm6h_wyaaz.timing import normalize_time_unit, parse_time_value

def _resolve_font_id(style):
    fid = style.get("font_id")
    if fid: return fid
    fname = style.get("font_name")
    return resolve_font_resource_id(fname) if fname else None

def generate_draft_json(draft_context):
    if isinstance(draft_context, str):
        input_kind, normalized_input, parsed_obj = normalize_input_json(draft_context)
        if input_kind == "final_draft":
            return DraftCrypto.encrypt(normalized_input if looks_like_json(normalized_input) else json.dumps(parsed_obj, ensure_ascii=False))
        if input_kind == "draft_context":
            data = parsed_obj
        else:
            dec = DraftCrypto.decrypt(draft_context)
            data = json.loads(dec)
    else:
        data = draft_context
    proj      = data.get("project_info", {})
    draft_type = data.get("draft_type", 0)
    width     = proj.get("width", 1920)
    height    = proj.get("height", 1080)
    ratio     = proj.get("ratio", "custom")
    save_name = proj.get("save_name", "Coze_Auto_Gen")
    time_unit = normalize_time_unit(data.get("time_unit", "us"))
    draft = JianYingDraft(width=width, height=height, ratio=ratio)
    for ti in data.get("tracks", []):
        tt = ti.get("type", "video")
        ot = {"image": "video", "sticker": "video"}.get(tt, tt)
        trk = draft.add_track(ot)
        for cd in ti.get("clips", []):
            ct  = cd.get("type", "video")
            cid = cd.get("id")
            s   = parse_time_value(cd.get("start"), time_unit=time_unit)
            d   = parse_time_value(cd.get("duration"), time_unit=time_unit)
            obj = None
            if ct in ("video", "image"):
                p = cd.get("path")
                if not p: continue
                obj = VideoClip(
                    p,
                    duration=d,
                    source_start=parse_time_value(cd.get("source_start", 0), time_unit=time_unit),
                    start=s,
                    media_type=ct,
                )
                sp = cd.get("speed")
                if sp:
                    if isinstance(sp, dict): obj.set_speed(sp.get("value",1.0), change_pitch=sp.get("change_pitch",False))
                    else: obj.set_speed(float(sp))
                tr = cd.get("transition")
                if tr: obj.add_transition(resource_id=tr.get("resource_id"), duration=parse_time_value(tr.get("duration", 1_000_000), time_unit=time_unit), overlap=tr.get("overlap",True))
                mk = cd.get("mask")
                if mk: obj.set_mask(mask_type=mk.get("type","rectangle"), center_x=mk.get("center_x",0), center_y=mk.get("center_y",0), rotation=mk.get("rotation",0), size_x=mk.get("size_x"), size_y=mk.get("size_y"), feather=mk.get("feather",0), invert=mk.get("invert",False), round_corner=mk.get("round_corner",0))
                mm = cd.get("mix_mode")
                if mm: obj.set_mix_mode(name=mm if isinstance(mm,str) else mm.get("name","变亮"))
                sc = cd.get("smart_crop")
                if sc: obj.set_smart_crop(ratio=sc.get("ratio","original"), stability=sc.get("stability",2), speed=sc.get("speed",1))
                va = cd.get("video_algorithm")
                if va: obj.set_video_algorithm(denoise=va.get("denoise"), deflicker=va.get("deflicker"), quality_enhance=va.get("quality_enhance"), motion_blur=va.get("motion_blur"), stabilize=va.get("stabilize"))
                if cd.get("audio_volume") is not None: obj.set_volume(cd["audio_volume"])
                af = cd.get("audio_fade")
                if af: obj.set_audio_fade(fade_in=_pt(af.get("in",0)), fade_out=_pt(af.get("out",0)))
                if cd.get("audio_denoise"): obj.set_audio_denoise(True)
                if cd.get("loudness"):      obj.set_loudness(cd["loudness"])
                if cd.get("vocal_separation") is not None: obj.set_vocal_separation(cd["vocal_separation"])
                if cd.get("vocal_beautify")   is not None: obj.set_vocal_beautify(cd["vocal_beautify"])
                if cd.get("tone_effect"):   obj.set_tone_effect(cd["tone_effect"])
                if cd.get("color_curves"):  obj.set_color_curves(True)
            elif ct == "audio":
                p = cd.get("path")
                if not p: continue
                obj = AudioClip(p, start=s, duration=d, source_start=parse_time_value(cd.get("source_start", 0), time_unit=time_unit))
                if cd.get("volume") is not None: obj.set_volume(cd["volume"])
                sp = cd.get("speed")
                if sp:
                    if isinstance(sp, dict): obj.set_speed(sp.get("value",1.0), change_pitch=sp.get("change_pitch",False))
                    else: obj.set_speed(float(sp))
                fa = cd.get("fade")
                if fa: obj.set_fade(fade_in=parse_time_value(fa.get("in", 0), time_unit=time_unit), fade_out=parse_time_value(fa.get("out", 0), time_unit=time_unit))
                if cd.get("denoise"): obj.set_denoise(True)
                if cd.get("loudness"): obj.set_loudness(cd["loudness"])
                if cd.get("vocal_separation") is not None: obj.set_vocal_separation(cd["vocal_separation"])
                if cd.get("vocal_beautify")   is not None: obj.set_vocal_beautify(cd["vocal_beautify"])
                for ve in cd.get("voice_effects", []):
                    ve_type = ve.get("type", "tone")
                    resolved_ve_id = resolve_audio_effect_resource_id(
                        ve.get("id") or ve.get("name"),
                        effect_type=ve_type,
                    )
                    obj.add_voice_effect(resource_id=resolved_ve_id, type=ve_type, adjust_params=ve.get("params"))
                te = cd.get("tone_effect")
                if te and not cd.get("voice_effects"):
                    obj.add_voice_effect(
                        resolve_audio_effect_resource_id(te, effect_type="tone"),
                        type="tone",
                    )
            elif ct == "text":
                obj = TextClip(cd.get("content") or cd.get("text","Text"), start=s, duration=d)
                if "start" in cd and cd.get("start") not in (None, "", "auto"):
                    obj.custom_start_time = s
                st = cd.get("style", {})
                obj.set_style(font_id=_resolve_font_id(st), size=st.get("size"), color=st.get("color"), alpha=st.get("alpha"), bold=st.get("bold"), italic=st.get("italic"), underline=st.get("underline"))
                obj.set_format(align=st.get("align",1), line_spacing=st.get("line_spacing",0), letter_spacing=st.get("letter_spacing",0), line_max_width=st.get("line_max_width",82), typesetting=st.get("typesetting",0))
                bd = st.get("border")
                if bd: obj.set_border(width=bd.get("width",0), color=bd.get("color","#000000"))
                sh = st.get("shadow")
                if sh: obj.set_shadow(alpha=sh.get("alpha",0), color=sh.get("color","#000000"), distance=sh.get("distance",5.0), angle=sh.get("angle",-45.0), diffuse=sh.get("diffuse",15))
                bg = st.get("background")
                if bg: obj.set_background(color=bg.get("color","#000000"), alpha=bg.get("alpha",50), radius=bg.get("radius",50), width=bg.get("width",0), height=bg.get("height",0), off_x=bg.get("off_x",50), off_y=bg.get("off_y",50), style=bg.get("style",1))
                if st.get("curve") is not None: obj.set_curve(angle=st["curve"])
                gi = cd.get("glow_id") or st.get("glow_id")
                if not gi:
                    gi = resolve_text_effect_resource_id(st)
                bi = cd.get("bubble_id") or st.get("bubble_id")
                if not bi:
                    bi = resolve_bubble_resource_id(st.get("bubble_name"))
                if gi or bi: obj.set_effect(glow_id=gi, bubble_id=bi)
                bl = cd.get("bloom") or st.get("bloom")
                if bl: obj.set_bloom(strength=bl.get("strength",50), range_val=bl.get("range",50), dir_x=bl.get("dir_x",0), dir_y=bl.get("dir_y",0), color=bl.get("color",""), bloom_type=bl.get("type","外发光"))
                rs = cd.get("rich_styles")
                if rs:
                    for tag, props in rs.items(): obj.add_rich_style(tag, **props)
            elif ct == "sticker":
                rid = (
                    cd.get("resource_id")
                    or resolve_sticker_resource_id(cd.get("title") or cd.get("name"))
                    or cd.get("path")
                )
                if not rid: continue
                obj = StickerClip(rid, start=s, duration=d)
            elif ct == "effect":
                rid = cd.get("resource_id") or resolve_effect_resource_id(cd.get("effect_title")) or cd.get("effect_title")
                if not rid: continue
                obj = EffectClip(resource_id=rid, start=s, duration=d, name=cd.get("name","effect"), type=cd.get("effect_type","video_effect"), render_index=cd.get("render_index"))
                pm = cd.get("params") or cd.get("adjust_params", [])
                if isinstance(pm, dict):
                    for k,v in pm.items(): obj.set_param(k,v)
                elif isinstance(pm, list):
                    for p in pm: obj.set_param(p.get("name"), p.get("value"))
            elif ct == "filter":
                rid = cd.get("resource_id") or resolve_filter_resource_id(cd.get("name") or cd.get("filter_name"))
                if not rid: continue
                obj = FilterClip(resource_id=rid, start=s, duration=d, intensity=cd.get("intensity",80), name=cd.get("name","filter"))
            if not obj: continue
            tf = cd.get("transform")
            if tf: obj.set_transform(x=tf.get("x",0), y=tf.get("y",0), scale=tf.get("scale",100), rotation=tf.get("rotation",0), alpha=tf.get("alpha",100), uniform_scale=tf.get("uniform_scale",True), scale_x=tf.get("scale_x",100), scale_y=tf.get("scale_y",100))
            animation_target = "text" if ct == "text" else ("sticker" if ct == "sticker" else "video")
            for an in resolve_animation_entries(cd.get("animations", []), target=animation_target) or []:
                if not isinstance(an, dict):
                    continue
                animation_payload = dict(an)
                animation_payload["duration"] = parse_time_value(
                    animation_payload.get("duration", 500_000),
                    time_unit=time_unit,
                )
                if animation_payload.get("start") is not None:
                    animation_payload["start"] = parse_time_value(
                        animation_payload.get("start", 0),
                        time_unit=time_unit,
                    )
                animation_payload.setdefault("target", animation_target)
                obj.add_animation(animation_payload)
            for kg in cd.get("keyframes", []):
                for kp in kg.get("data", []):
                    obj.add_keyframe(kg.get("prop"), parse_time_value(kp.get("time_offset"), time_unit=time_unit), kp.get("value"))
            trk.add(obj)
    from zcatwx_zil6sm6h_wyaaz._core import Track
    track_data = [t.export(draft) for t in draft.tracks]
    et = {t.type for t in draft.tracks}
    for dt in ("video","audio"):
        if dt not in et:
            track_data.insert(0, Track(dt).export(draft))
    dur = max((s.start_time+s.duration for t in draft.tracks for s in t.segments), default=0)
    dc = {"canvas_config":{"width":draft.width,"height":draft.height,"ratio":draft.ratio},"color_space":0,"config":{"adjust_max_index":1,"attachment_info":[],"combination_max_index":1,"export_range":None,"extract_audio_last_index":1,"lyrics_recognition_id":"","lyrics_sync":True,"lyrics_taskinfo":[],"maintrack_adsorb":True,"material_save_mode":0,"multi_language_current":"none","multi_language_list":[],"multi_language_main":"none","multi_language_mode":"none","original_sound_last_index":1,"record_audio_last_index":1,"sticker_max_index":1,"subtitle_keywords_config":None,"subtitle_recognition_id":"","subtitle_sync":True,"subtitle_taskinfo":[],"system_font_list":[],"video_mute":False,"zoom_info_params":None},"cover":None,"create_time":0,"duration":dur,"extra_info":None,"fps":30.0,"free_render_index_mode_on":False,"group_container":None,"id":draft.project_id,"keyframe_graph_list":[],"keyframes":{"adjusts":[],"audios":[],"effects":[],"filters":[],"handwrites":[],"stickers":[],"texts":[],"videos":[]},"materials":draft.materials,"mutable_config":None,"name":save_name,"new_version":"110.0.0","platform":{"app_id":3704,"app_source":"lv","app_version":"5.9.0","device_id":"","hard_disk_id":"","mac_address":"","os":"mac","os_version":"14.0"},"last_modified_platform":{"app_id":3704,"app_source":"lv","app_version":"5.9.0","device_id":"","hard_disk_id":"","mac_address":"","os":"mac","os_version":"14.0"},"relationships":[],"render_index_track_mode_on":True,"retouch_cover":None,"source":"default","static_cover_image_path":"","tracks":track_data,"update_time":0,"version":360000}
    return DraftCrypto.encrypt(json.dumps(dc, ensure_ascii=False))
