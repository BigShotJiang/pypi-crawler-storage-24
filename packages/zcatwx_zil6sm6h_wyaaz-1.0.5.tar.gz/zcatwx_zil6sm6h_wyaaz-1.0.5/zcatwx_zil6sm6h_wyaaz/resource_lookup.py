from __future__ import annotations

import json
import os
import re
import unicodedata
from typing import Any

from zcatwx_zil6sm6h_wyaaz.animation_protocol import (
    animation_target_defaults,
    build_animation_entry,
    default_animation_duration_us,
    normalize_anim_adjust_params,
    normalize_animation_phase,
    normalize_animation_target,
)


def _candidate_index_roots():
    package_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(os.path.dirname(package_dir))
    return [
        os.path.join(package_dir, "resource_index"),
        os.path.join(project_root, "resource_registry", "index"),
    ]


def _load_family_records(family: str) -> list[dict[str, Any]]:
    filename = f"{family}.json"
    for root in _candidate_index_roots():
        path = os.path.join(root, filename)
        try:
            with open(path, "r", encoding="utf-8") as file:
                payload = json.load(file)
            if isinstance(payload, dict) and isinstance(payload.get("records"), list):
                return payload["records"]
        except Exception:
            continue
    return []


_RESOURCE_NAME_ALIASES: dict[str, dict[str, str]] = {
    "audio_effects": {
        "三百六十度环绕音": "360度环绕音",
    },
}


def _normalize_resource_name(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    text = unicodedata.normalize("NFKC", text)
    text = re.sub(r"^[ _]+", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _normalize_resource_name_loose(value: Any) -> str:
    text = _normalize_resource_name(value)
    if not text:
        return ""
    return re.sub(r"[\s_-]+", "", text).casefold()


def _name_candidates(family: str, name: Any) -> list[str]:
    normalized = _normalize_resource_name(name)
    if not normalized:
        return []
    candidates = [normalized]
    alias = _RESOURCE_NAME_ALIASES.get(family, {}).get(normalized)
    if alias:
        candidates.append(_normalize_resource_name(alias))
    if normalized.startswith("_"):
        candidates.append(_normalize_resource_name(normalized.lstrip("_")))
    seen = set()
    ordered = []
    for item in candidates:
        if item and item not in seen:
            seen.add(item)
            ordered.append(item)
    return ordered


def _find_first_by_name(family: str, name: str, *, resource_subtype: str | None = None) -> dict[str, Any] | None:
    target = str(name or "").strip()
    if not target:
        return None
    records = _load_family_records(family)
    for record in records:
        if record.get("name") != target:
            continue
        if resource_subtype and record.get("resource_subtype") != resource_subtype:
            continue
        return record

    candidates = _name_candidates(family, target)
    if not candidates:
        return None

    for candidate in candidates:
        for record in records:
            if resource_subtype and record.get("resource_subtype") != resource_subtype:
                continue
            if _normalize_resource_name(record.get("name")) == candidate:
                return record

    loose_candidates = {_normalize_resource_name_loose(item) for item in candidates if item}
    for record in records:
        if resource_subtype and record.get("resource_subtype") != resource_subtype:
            continue
        if _normalize_resource_name_loose(record.get("name")) in loose_candidates:
            return record
    return None


def _find_first_by_resource_id(
    family: str,
    resource_id: str,
    *,
    resource_subtype: str | None = None,
) -> dict[str, Any] | None:
    target = str(resource_id or "").strip()
    if not target:
        return None
    for record in _load_family_records(family):
        if record.get("resource_id") != target:
            continue
        if resource_subtype and record.get("resource_subtype") != resource_subtype:
            continue
        return record
    return None


def resolve_transition_resource_id(name_or_id):
    value = str(name_or_id or "").strip()
    if not value:
        return value
    record = _find_first_by_name("transitions", value)
    return record["resource_id"] if record else value


def _resolve_family_resource_id(family: str, name_or_id: Any) -> str:
    value = str(name_or_id or "").strip()
    if not value:
        return value
    record = _find_first_by_resource_id(family, value)
    if record is None:
        record = _find_first_by_name(family, value)
    if not record:
        return value
    return record.get("resource_id") or record.get("effect_id") or value


def resolve_animation_resource_id(name_or_id, *, target: str, phase: str):
    value = str(name_or_id or "").strip()
    if not value:
        return value
    normalized_target = normalize_animation_target(target)
    normalized_phase = normalize_animation_phase(phase, target=normalized_target)
    record = _find_first_by_resource_id("animations", value, resource_subtype=normalized_target)
    if record is None:
        record = _find_first_by_name("animations", value, resource_subtype=normalized_target)
    if record:
        attrs = record.get("attributes") or {}
        record_phase = normalize_animation_phase(
            attrs.get("protocol_phase") or attrs.get("phase"),
            target=normalized_target,
        )
        if record_phase == normalized_phase:
            return record["resource_id"]
        if {record_phase, normalized_phase} == {"group", "loop"}:
            return record["resource_id"]
        # 同名动画可能分入场/出场两条记录，第一条 phase 不匹配时继续搜索
        target_name_loose = _normalize_resource_name_loose(value)
        for rec in _load_family_records("animations"):
            if rec.get("resource_subtype") != normalized_target:
                continue
            if _normalize_resource_name_loose(rec.get("name")) != target_name_loose:
                continue
            rec_attrs = rec.get("attributes") or {}
            rec_phase = normalize_animation_phase(
                rec_attrs.get("protocol_phase") or rec_attrs.get("phase"),
                target=normalized_target,
            )
            if rec_phase == normalized_phase or {rec_phase, normalized_phase} == {"group", "loop"}:
                return rec["resource_id"]
    if record and record.get("attributes", {}).get("phase") == phase:
        return record["resource_id"]
    return value


def resolve_transition_payload(transition):
    if not transition:
        return transition
    if isinstance(transition, str):
        return resolve_transition_resource_id(transition)
    if isinstance(transition, dict):
        resolved = dict(transition)
        resource_id = resolved.get("resource_id")
        if resource_id:
            resolved["resource_id"] = resolve_transition_resource_id(resource_id)
        return resolved
    return transition


def resolve_animation_entries(animations, *, target: str):
    if not animations:
        return animations
    normalized_target = normalize_animation_target(target)
    resolved_entries = []
    for entry in animations:
        if not isinstance(entry, dict):
            resolved_entries.append(entry)
            continue
        resolved = dict(entry)
        phase = normalize_animation_phase(resolved.get("type"), target=normalized_target)
        animation_id = resolved.get("id") or resolved.get("resource_id")
        resolved_resource_id = resolve_animation_resource_id(animation_id, target=normalized_target, phase=phase)
        record = _find_first_by_resource_id("animations", resolved_resource_id, resource_subtype=normalized_target)

        defaults = animation_target_defaults(normalized_target)
        attrs = record.get("attributes") or {} if record else {}
        resource_id = record.get("resource_id") if record else str(resolved_resource_id or animation_id or "").strip()
        if not resource_id:
            resolved_entries.append(resolved)
            continue

        category_name = resolved.get("category_name")
        if not category_name and record:
            category_name = ",".join(record.get("category_tags") or [])

        payload = build_animation_entry(
            target=normalized_target,
            phase=attrs.get("protocol_phase") or phase,
            resource_id=resource_id,
            effect_id=resolved.get("effect_id") or (record.get("effect_id") if record else ""),
            duration_us=resolved.get("duration", attrs.get("default_duration_us") or default_animation_duration_us(phase)),
            start_us=resolved.get("start"),
            name=resolved.get("name") or (record.get("name") if record else ""),
            panel=resolved.get("panel") if "panel" in resolved else attrs.get("panel", defaults["panel"]),
            material_type=resolved.get("material_type") or attrs.get("material_type"),
            platform=resolved.get("platform") or attrs.get("platform") or "all",
            path=resolved.get("path"),
            request_id=resolved.get("request_id"),
            category_id=resolved.get("category_id"),
            category_name=category_name,
            anim_adjust_params=normalize_anim_adjust_params(resolved.get("anim_adjust_params")),
        )
        resolved_entries.append(payload)
    return resolved_entries


def resolve_text_effect_resource_id(style):
    if not isinstance(style, dict):
        return None
    raw_value = (
        style.get("glow_id")
        or style.get("text_effect_name")
        or style.get("TextEffect")
        or ""
    )
    value = str(raw_value).strip()
    if not value:
        return None
    resolved = _resolve_family_resource_id("flowers", value)
    return resolved or None


def resolve_bubble_resource_id(name_or_id):
    return _resolve_family_resource_id("bubbles", name_or_id)


def resolve_effect_resource_id(name_or_id):
    return _resolve_family_resource_id("effects", name_or_id)


def resolve_filter_resource_id(name_or_id):
    return _resolve_family_resource_id("filters", name_or_id)


def resolve_style_resource_id(name_or_id):
    return _resolve_family_resource_id("styles", name_or_id)


def resolve_font_resource_id(name_or_id):
    return _resolve_family_resource_id("fonts", name_or_id)


def resolve_sticker_resource_id(name_or_id):
    return _resolve_family_resource_id("stickers", name_or_id)


def resolve_audio_effect_resource_id(name_or_id, *, effect_type: str | None = None):
    value = str(name_or_id or "").strip()
    if not value:
        return value
    subtype_map = {
        "tone": "tone",
        "scene": "scene",
        "sound_effect": "scene",
        "song": "song",
        "speech_to_song": "song",
    }
    resource_subtype = subtype_map.get(str(effect_type or "").strip(), None)
    record = _find_first_by_resource_id("audio_effects", value, resource_subtype=resource_subtype)
    if record is None:
        record = _find_first_by_name("audio_effects", value, resource_subtype=resource_subtype)
    if record is None and resource_subtype == "scene":
        record = _find_first_by_resource_id("audio_effects", value, resource_subtype="tone")
        if record is None:
            record = _find_first_by_name("audio_effects", value, resource_subtype="tone")
    if record is None and resource_subtype:
        record = _find_first_by_resource_id("audio_effects", value)
        if record is None:
            record = _find_first_by_name("audio_effects", value)
    if not record:
        return value
    return record.get("resource_id") or value
