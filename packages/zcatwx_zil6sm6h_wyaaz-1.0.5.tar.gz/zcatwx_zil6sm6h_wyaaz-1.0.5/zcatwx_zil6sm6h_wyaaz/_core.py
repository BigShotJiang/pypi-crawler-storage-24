"""
剪映草稿面向对象封装库 (JianYing Draft OOP Library)
==================================================

本库旨在提供一套 **"所见即所得"** 的 Python 接口来生成剪映草稿。
所有参数设计均直接对应剪映客户端 UI 面板上的数值，无需人工进行复杂的数学转换。

核心类索引 (Class Index)
-----------------------

[1] VideoClip (视频/图片片段)
    对应轨道上的视频或图片素材，支持画面调节、音频调节、动画、特效等全套功能。

[2] TextClip (文本片段)
    对应文本素材，支持基础样式、富文本、气泡、花字、排列布局等。

[3] AudioClip (音频片段)
    对应音频素材，支持音量、淡入淡出、变声、降噪等。
    - 支持多重声音特效叠加 (add_voice_effect):
      - tone (音色): 如萝莉、大叔、机器人
      - scene (场景音): 如回音、录音棚
      - song (声音成曲): 如雷鬼、R&B

[4] EffectClip (特效/调节层) & FilterClip (滤镜)
    对应画面特效和滤镜素材。

[5] JianYingDraft (草稿管理)
    项目入口，负责管理轨道和保存文件。

---

详细方法文档 (Detailed API Documentation)
----------------------------------------

### 1. VideoClip 类 (继承自 Segment)
   用于处理视频 (.mp4, .mov) 和图片 (.jpg, .png)。

   **基础操作**
   - `__init__(file_path, duration=None, source_start=0)`
     - `file_path` (str): 文件绝对路径。
     - `duration` (str/float): 在轨道上的持续时间。如 "3.5s", "100ms", 3.5。
     - `source_start` (str/float): 视频截取开始时间。如 "10s" (从第10秒开始)。

   - `set_transform(x=0, y=0, scale=100, rotation=0, alpha=100, uniform_scale=True, scale_x=100, scale_y=100)`
     - `x`, `y` (float): 位置坐标 (像素)。屏幕中心为 (0,0)，右/上为正。
     - `scale` (float): 缩放比例 (百分比)。100 = 原始大小。
     - `rotation` (float): 旋转角度 (度)。顺时针为正。
     - `alpha` (float): 不透明度 (0-100)。100 = 完全不透明。
     - `uniform_scale` (bool): 是否锁定宽高比缩放。

   - `set_speed(speed, change_pitch=False)`
     - `speed` (float): 播放速度倍率 (0.1 ~ 100.0)。如 2.0 (两倍速), 0.5 (慢动作)。
     - `change_pitch` (bool): 是否变调。False=保持原调(推荐), True=声音变尖/变粗。

   **画面增强 & AI 功能**
   - `set_video_algorithm(denoise=None, deflicker=False, quality_enhance=None, motion_blur=None, stabilize=None)`
     - `denoise` (str/int): 视频降噪。"weak"/0 (弱), "strong"/1 (强), None (关)。
     - `deflicker` (bool/dict): 视频去频闪。
       - 简易模式: `True` (默认推荐配置)。
       - 高级模式: `{"mode": "延时摄影", "level": "较强"}`。
         - mode: "荧光灯"(0), "延时摄影"(1)。
         - level: "较弱"(0), "推荐"(1), "较强"(2)。
     - `quality_enhance` (str/int): 画质增强。"hd"/1 (超清), 0 (高清), None (关)。
     - `motion_blur` (bool): 运动模糊。True=开启。
     - `stabilize` (int/bool): 视频防抖。1 (裁切最少), 2 (推荐), 3 (最稳)。

   - `set_smart_crop(ratio="original", stability=2, speed=1)`
     - `ratio` (str): 裁剪比例。"16:9", "9:16", "1:1", "original" 等。
     - `stability` (int): 稳像程度。1 (灵活), 2 (默认), 3 (稳)。
     - `speed` (int): 运镜速度。0 (更快), 1 (默认), 2 (更慢)。

   **特效与蒙版**
   - `set_mask(mask_type, center_x=0, center_y=0, rotation=0, size_x=None, size_y=None, feather=0, invert=False, round_corner=0)`
     - `mask_type` (str): "linear"(线性), "mirror"(镜面), "circle"(圆), "rectangle"(矩形), "heart", "star"。
     - `center_x`, `center_y` (float): 蒙版中心坐标 (像素)。
     - `size_x`, `size_y` (float): 蒙版宽高/大小 (像素)。线性/镜面模式忽略 size_y。
     - `feather` (float): 羽化程度 (0-100)。
     - `round_corner` (float): 圆角半径 (0-100)。仅矩形有效。

   - `set_mix_mode(name="变亮")`
     - `name`: 模式名称，与剪映 UI 一致:
       "正片叠底", "颜色减淡", "颜色加深", "线性加深",
       "柔光", "强光", "滤色", "叠加", "变亮", "变暗"

   **音频调节 (针对视频原声)**
   - `set_volume(db)`: 音量 (-inf ~ 20 dB)。0 = 原声。
   - `set_audio_fade(fade_in=0, fade_out=0)`: 淡入淡出时长 (如 "1s")。
   - `set_loudness(target=-23.0)`: 响度统一 (LUFS)。
   - `set_audio_denoise(enabled=True)`: 音频降噪开关。
   - `set_vocal_beautify(intensity=75)`: 人声美化强度 (0-100)。
   - `set_vocal_separation(mode=0)`: 人声分离。0=原始, 1=仅伴奏, 2=仅人声。
   - `set_tone_effect(resource_id)`: 变声特效 ID (如 "萝莉音" ID)。

   **动画与转场**
   - `add_animation(anim_type, resource_id, duration=0.5)`
     - `anim_type`: "in"(入场), "out"(出场), "loop"(循环)。
   - `add_transition(resource_id, duration=1.0, overlap=True)`
     - 添加在片段尾部，连接下一个片段。

### 2. TextClip 类 (继承自 Segment)
   
    **文本内容与样式**
    - `__init__(content, start=0, duration="3s")`
      - `content`: 文本字符串。支持 `<tag>text</tag>` 格式富文本。
    
    - `set_style(font_id=None, size=None, color=None, alpha=None, bold=None, italic=None, underline=None)`
      - `font_id` (str): 字体 ID。None 使用系统默认。
      - `size` (int): 字号，与剪映 UI 一致 (默认 15，常用 12~36，过大会占满画面)。
      - `color` (str): Hex 颜色 (如 "#FF0000")。
      - `alpha` (float): 不透明度 (0-100)。
    
    - `set_format(align=1, line_spacing=0, letter_spacing=0, line_max_width=82, typesetting=0)`
      - `align` (int): 对齐。0=左, 1=中, 2=右 (横排模式下)。
      - `line_spacing` (int): 行间距 (-10 ~ 100)。
      - `letter_spacing` (int): 字间距 (-10 ~ 100)。
      - `typesetting` (int): 排版。0=横排, 1=竖排。

    **位置与变换 (继承自 Segment)**
    - `set_transform(x=0, y=0, scale=100, rotation=0, alpha=100, uniform_scale=True, scale_x=100, scale_y=100)`
      - 设置文本在画面上的位置 (x, y)、缩放 (scale) 和旋转 (rotation)。
      - 示例: `text_clip.set_transform(x=0, y=-300)` (上移)

    **装饰效果**
    - `set_border(width=0, color="#000000")`: 描边宽度 (0-100) 和颜色。
    - `set_shadow(alpha=80, color="#000000", distance=5.0, angle=-45.0, diffuse=15)`: 阴影设置。
    - `set_background(color="#000000", alpha=50, radius=50, width=0, height=0, off_x=50, off_y=50, style=1)`: 背景板。
      - `width`/`height`: 0 为自动适应，非 0 为自定义大小 (0-100)。
      - `style`: 1=普通, 2=贴合。
    - `set_curve(angle=0)`: 弯曲角度 (-360 ~ 360)。
    - `set_effect(glow_id=None, bubble_id=None)`: 应用花字或气泡特效 ID。

    - `add_rich_style(tag, **kwargs)`
      - 注册富文本标签。例如: `clip.add_rich_style("red", color="#FF0000")`。

    **动画 (继承自 Segment)**
    - `add_animation(anim_type, resource_id, duration=0.5)`
      - `anim_type`: "in"(入场), "out"(出场), "loop"(循环)。

### 3. AudioClip 类 (继承自 Segment)
   用于处理音频素材 (.mp3, .wav, .m4a 等)。

   **基础操作**
   - `__init__(file_path, start=0, duration=None, source_start=0)`
     - `file_path` (str): 音频文件绝对路径。
     - `start` (str/float): 在轨道上的开始时间。
     - `duration` (str/float): 持续时间 (必填，因音频无法自动探测时长)。
     - `source_start` (str/float): 截取开始时间。

   **音频调节**
   - `set_volume(db)`: 设置音量。
     - `db` (float): 分贝值 (-50 ~ 20)。0 为原声。
   - `set_fade(fade_in=0, fade_out=0)`: 设置淡入淡出。
     - `fade_in`, `fade_out` (str/float): 时长 (如 "1.5s")。

   **AI 增强**
   - `set_denoise(enabled=True)`: 降噪开关 (默认 False)。
   - `set_loudness(target=-23.0)`: 响度统一 (LUFS)。常用 -23.0。
   - `set_vocal_beautify(intensity=75)`: 人声美化强度 (0-100)。
   - `set_vocal_separation(mode=0)`: 人声分离模式。
     - 0: 原始 (人声+背景)
     - 1: 仅背景 (伴奏)
     - 2: 仅人声 (清唱)
   - `set_tone_effect(resource_id)`: [已过时] 设置变声特效 ID。
     - 建议使用 `add_voice_effect(resource_id, type="tone")`。
   - `add_voice_effect(resource_id, type="tone")`: 添加声音特效 (支持叠加)。
     - `resource_id` (str): 特效资源 ID。
     - `type` (str): 特效类型。
       - "tone": 音色 (如萝莉、大叔)。
       - "scene": 场景音 (如回音、录音棚)。
       - "song": 声音成曲 (Speech to Song)。
     - 示例:
       ```python
       # 叠加萝莉音和回音
       clip.add_voice_effect("7020...", type="tone")
           .add_voice_effect("7018...", type="scene")
       ```

### 4. StickerClip 类 (贴纸)
   - `__init__(resource_id, start=0, duration="3s")`
     - `resource_id` (str): 贴纸资源 ID。
     - `duration` (str/float): 持续时长。

### 5. EffectClip 类 (特效/调节层)
   用于添加画面特效 (如"复古", "边框") 或调节层。

   - `__init__(resource_id, start=0, duration="3s", name="effect", type="video_effect", render_index=None)`
     - `resource_id` (str): 特效资源 ID。
     - `name` (str): 特效名称 (仅展示)。
     - `type` (str): "video_effect" (画面特效) 或 "face_effect" (人物特效)。
     - `render_index` (int): 渲染层级。默认 0 (顶层)，调节层通常也为 0。

   - `set_param(key, value)`
     - `key` (str): 参数内部键名 (如 "effects_adjust_speed")。
     - `value` (float): 参数值 (0-100)。对应 UI 滑杆数值。
     
        画面特效片段 (全局/调节层)
        
        通常放置在单独的特效轨道上，作用于其下方的视频层。

        附录：特效参数 Key 与 UI 名称对照表 (参考)
        ------------------------------------------------------------
        | Internal Key                        | UI 名称          |
        | :---                                | :---            |
        | effects_adjust_speed                | 速度            |
        | effects_adjust_filter               | 滤镜            |
        | effects_adjust_intensity            | 强度          |
        | effects_adjust_luminance            | 发光            |
        | effects_adjust_size                 | 大小            |
        | effects_adjust_horizontal_shift     | 水平位移         |
        | effects_adjust_vertical_shift       | 垂直位移         |
        | effects_adjust_color                | 颜色            |
        | effects_adjust_blur                 | 模糊            |
        | effects_adjust_range                | 范围            |
        | effects_adjust_rotate               | 旋转            |
        | effects_adjust_noise                | 噪点            |
        | effects_adjust_texture              | 纹理            |
        | effects_adjust_sharpen              | 锐化            |
        | effects_adjust_number               | 数量            |
        | effects_adjust_background_dimming   | 背景变暗         |
        | effects_adjust_soft                 | 柔光            |
        | effects_adjust_background_animation | 氛围            |
        | effects_adjust_distortion           | 扭曲            |
        | effects_adjust_horizontal_chromatic | 水平色差         |
        | effects_adjust_vertical_chromatic   | 垂直色差         |
        | sticker                             | 贴纸            |
        ------------------------------------------------------------
### 6. FilterClip 类 (滤镜)
   - `__init__(resource_id, start=0, duration="3s", intensity=80)`
     - `resource_id` (str): 滤镜资源 ID。
     - `intensity` (int): 滤镜强度 (0-100)。

### 7. JianYingDraft 类 (项目管理)

   - `add_track(track_type="video")`: 创建新轨道。类型支持 "video", "audio", "text", "effect", "filter"。
   - `add_srt(srt_content, font_style=None, ...)`: 批量解析 SRT 文本并添加到轨道。
   - `save(file_path)`: 将草稿导出为 `draft_info.json`。

### 8. Keyframes (关键帧动画) [New]
   
   所有继承自 `Segment` 的素材 (VideoClip, TextClip, StickerClip, AudioClip) 均支持关键帧。
   
   - `add_keyframe(property_name, time, value)`
     - `property_name` (str): 动画属性名称
       - **位置**: "x", "y" (单位: 像素)
       - **缩放**: "scale" (整体, %), "scale_x", "scale_y" (独立, %)
       - **旋转**: "rotation" (单位: 度)
       - **透明度**: "alpha" 或 "opacity" (0-100)
       - **画面调节**: "saturation"(饱和度), "contrast"(对比度), "brightness"(亮度) (-100 ~ 100)
       - **音量**: "volume" (%, 100=原声)
     - `time` (str): 时间点，如 "0s", "1.5s", "500ms"
     - `value` (float): 对应属性的数值
     
   **示例:**
   ```python
   # 1. 移动动画: 从左移到右
   clip.add_keyframe("x", "0s", -500).add_keyframe("x", "2s", 500)
   
   # 2. 缩放动画: 从 0% 放大到 100%
   clip.add_keyframe("scale", "0s", 0).add_keyframe("scale", "1s", 100)
   
   # 3. 组合动画: 旋转并在中间变透明
   clip.add_keyframe("rotation", "0s", 0).add_keyframe("rotation", "3s", 360)
   clip.add_keyframe("alpha", "0s", 100).add_keyframe("alpha", "1.5s", 50).add_keyframe("alpha", "3s", 100)
   ```

"""
import json
import uuid
import os
import copy
import math
import re
from urllib.parse import urlparse

from zcatwx_zil6sm6h_wyaaz.animation_protocol import (
    build_animation_entry,
    normalize_anim_adjust_params,
    normalize_animation_phase,
    normalize_animation_target,
)
from zcatwx_zil6sm6h_wyaaz.resource_lookup import resolve_animation_resource_id

# ==============================================================================
# 1. 工具函数 (Utils)
# ==============================================================================

def generate_id():
    """生成大写 UUID，用于剪映内部 ID 标识"""
    return str(uuid.uuid4()).upper()

def _get_bloom_path(effect_id="9762443"):
    """
    返回项目内置 bloom effect 素材路径（bundled_effects 目录）。

    save() 调用时会自动把这些文件 copy 到草稿目录，并把 path 更新为草稿内部路径。
    这样草稿完全自包含，不依赖用户设备的 Cache 路径。
    """
    KNOWN_HASHES = {
        "9762443": "0522a4e9dde8572d591ef622ec99fded",  # 外发光（实机缓存验证可用）
        "9762325": "5e73b9655ea23c6ea73a491b59567c8e",  # 轮廓光
    }
    script_dir = os.path.dirname(os.path.abspath(__file__))
    candidate_roots = [
        os.path.join(script_dir, "jyxzs", "src-tauri", "resources", "bundled_effects"),
        os.path.join(os.path.dirname(script_dir), "jyxzs", "src-tauri", "resources", "bundled_effects"),
        os.path.join(script_dir, "bundled_effects"),
        os.path.join(os.path.dirname(script_dir), "bundled_effects"),
        os.path.join(os.path.dirname(os.path.dirname(script_dir)), "bundled_effects"),
    ]
    bundled_root = next((p for p in candidate_roots if os.path.isdir(p)), candidate_roots[0])
    if effect_id in KNOWN_HASHES:
        return os.path.join(bundled_root, effect_id, KNOWN_HASHES[effect_id])
    return ""

def _srt_time_to_us(srt_str: str) -> int:
    """SRT 时间字符串 -> 微秒，仅供 load_srt_captions 内部使用。"""
    try:
        clean = srt_str.replace(',', ':').replace('.', ':')
        h, m, s, ms = clean.split(':')
        return int(h)*3600000000 + int(m)*60000000 + int(s)*1000000 + int(ms)*1000
    except Exception:
        return 0

def hex_to_rgb(hex_str, default_color="#000000"):
    """
    将十六进制颜色转换为 RGB 归一化数组 [r, g, b]
    
    参数:
        hex_str (str): 十六进制颜色，如 "#FF0000"
        default_color (str): 默认颜色
        
    返回:
        list: [1.0, 0.0, 0.0] (范围 0.0 - 1.0)
    """
    if not hex_str: hex_str = default_color
    c_hex = hex_str.lstrip("#")
    if len(c_hex) == 3: c_hex = "".join([c*2 for c in c_hex])
    try:
        return [int(c_hex[i:i+2], 16)/255.0 for i in (0, 2, 4)]
    except:
        return [0.0, 0.0, 0.0]

def _load_font_db():
    """加载字体数据库 {font_id: font_name}，来源于剪映内置字体库（767 种）"""
    db_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "font_db.json")
    try:
        with open(db_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

_FONT_DB = _load_font_db()

def font_name_by_id(font_id):
    """通过字体 ID 查找字体中文名，未找到返回空字符串"""
    return _FONT_DB.get(font_id, "")

def db_to_linear(db_value):
    """
    将 dB 音量转换为线性增益
    
    公式: gain = 10^(dB/20)
    示例: 0dB -> 1.0, -6dB -> 0.5, -infinity -> 0.0
    """
    if db_value == float('-inf') or db_value <= -100: return 0.0
    return 10 ** (db_value / 20)

def utf16_len(s):
    """
    计算字符串的 UTF-16 编码长度 (Code Units)
    
    重要说明:
        剪映内部使用 UTF-16 长度来计算样式应用范围 (range)。
        普通的 len() 在处理 Emoji 时会由误差，导致样式错位。
        此函数确保 Emoji (通常占2个 code unit) 计算正确。
    """
    return len(s.encode('utf-16-le')) // 2

def _extract_media_extension(path_or_url):
    """
    提取素材扩展名。

    对带 query/hash 的 URL，先取 pathname，再判断后缀，
    避免 `.png?x-expires=...` 这种情况误判为视频。
    """
    if not path_or_url:
        return ""
    parsed = urlparse(path_or_url)
    candidate = parsed.path or path_or_url
    return os.path.splitext(candidate)[1].lower()


# 混合模式完整映射表 (从剪映 5.9 APP 内嵌 MixMode.json 逆向提取)
MIXMODE_MAP = {
    "正片叠底": {"effect_id": "871333", "resource_id": "6758325895519277582", "name_id": "multiply_blend_mode"},
    "颜色减淡": {"effect_id": "871334", "resource_id": "6758325800031752712", "name_id": "color_dodge"},
    "颜色加深": {"effect_id": "871335", "resource_id": "6758325724848853518", "name_id": "darken_color"},
    "线性加深": {"effect_id": "871336", "resource_id": "6758325619253056013", "name_id": "linear_deepening"},
    "柔光":     {"effect_id": "871337", "resource_id": "6758325439212556814", "name_id": "soft_light"},
    "强光":     {"effect_id": "871338", "resource_id": "6758325264670790152", "name_id": "glare_pc"},
    "滤色":     {"effect_id": "871339", "resource_id": "6758325170760323597", "name_id": "color_filter"},
    "叠加":     {"effect_id": "871340", "resource_id": "6758324989931295240", "name_id": "over_lay"},
    "变亮":     {"effect_id": "871341", "resource_id": "6758324919789949453", "name_id": "bright_en"},
    "变暗":     {"effect_id": "871342", "resource_id": "6758324839670354445", "name_id": "dark_en"},
}

# ==============================================================================
# 2. 核心基类 (Core Classes)
# ==============================================================================

_EFFECT_META_CACHE = None

def load_effect_meta():
    """
    加载特效元数据缓存
    """
    global _EFFECT_META_CACHE
    if _EFFECT_META_CACHE is not None:
        return _EFFECT_META_CACHE
    
    _EFFECT_META_CACHE = {}
    try:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        candidate_paths = [
            os.path.join(base_dir, "资源", "特效", "jianying_effects_full_data.json"),
            os.path.join(os.path.dirname(base_dir), "资源", "特效", "jianying_effects_full_data.json"),
            os.path.join(os.path.dirname(os.path.dirname(base_dir)), "资源", "特效", "jianying_effects_full_data.json"),
        ]
        json_path = next((path for path in candidate_paths if os.path.exists(path)), "")

        if json_path:
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                # 建立索引: resource_id -> params_dict
                for item in data:
                    rid = item.get("resource_id")
                    params = item.get("adjust_params", [])
                    if rid:
                        p_dict = {}
                        for p in params:
                            k = p.get("effect_key")
                            if k:
                                p_dict[k] = {
                                    "min": p.get("min", 0),
                                    "max": p.get("max", 1),
                                    "default": p.get("default", 0)
                                }
                        _EFFECT_META_CACHE[rid] = {
                            "effect_id": item.get("effect_id", rid), # 默认回退到 resource_id
                            "name": item.get("name", "effect"),
                            "params": p_dict
                        }
            pass
    except Exception as e:
        pass
        
    return _EFFECT_META_CACHE

class DraftObject:
    """所有草稿对象的基类，自动生成唯一 ID"""
    def __init__(self):
        self.id = generate_id()

class Keyframe:
    """内部使用的关键帧对象"""
    def __init__(self, time_offset, value):
        self.id = generate_id()
        self.time_offset = time_offset # 微秒
        self.value = value # 存储 UI 原始值

    def export(self, property_type, draft_width, draft_height):
        final_val = float(self.value)

        # 位置: UI 像素 -> 归一化 (除以画布尺寸)
        _POS_TYPES = {"KFTypePositionX", "KFTypeMaskPostionX"}
        _POS_Y_TYPES = {"KFTypePositionY", "KFTypeMaskPostionY"}
        # 百分比类: UI 0~100 -> 内部 0~1
        _PCT_TYPES = {
            "KFTypeAlpha", "KFTypeScaleX", "KFTypeScaleY", "UNIFORM_SCALE",
            "KFTypeLUT", "KFTypeFilter",
            "KFTypeTemperature", "KFTypeHue", "KFTypeSharpen",
            "KFTypeHightLight", "KFTypeShadow", "KFTypeBlack", "KFTypeWhite",
            "KFTypeFade", "KFTypeVignetting", "KFTypeLightSensatione",
            "KFTypeMaskFeather", "KFTypeMaskRoundCorner",
            "KFTypeMaskSizeX", "KFTypeMaskSizeY",
            "KFTypeTextAlpha", "KFTypeGlobalAlpha", "KFTypeBorderAlpha", "KFTypeBorderWidth",
            "KFTypeShadowAlpha", "KFTypeShadowSmoothing",
            "KFTypeBackgroundAlpha", "KFTypeBackgroundWidth", "KFTypeBackgroundHeight",
            "KFTypeBackgroundOffsetX", "KFTypeBackgroundOffsetY", "KFTypeBackgroundRoundRadius",
            "KFTypeBloomAlpha", "KFTypeBloomRange", "KFTypeBloomStrength",
            "KFTypeChromaIntensity", "KFTypeChromaEdgeSmooth",
            "KFTypeChromaShadow", "KFTypeChromaSpill",
        }
        # 经剪映 UI 实测，亮度/对比度/饱和度关键帧使用更大的内部范围：
        # UI -80 -> 面板应显示 -80，对应内部值需为 -1.6。
        # 其他仍未稳定的关键帧（如 chroma_*）后续还要继续校准。
        _ADJUST_DOUBLE_RANGE_TYPES = {
            "KFTypeSaturation", "KFTypeContrast", "KFTypeBrightness",
        }

        if property_type in _POS_TYPES:
            final_val = final_val / draft_width
        elif property_type in _POS_Y_TYPES:
            final_val = final_val / draft_height
        elif property_type == "KFTypeVolume":
            final_val = db_to_linear(final_val)
        elif property_type in _ADJUST_DOUBLE_RANGE_TYPES:
            final_val = final_val / 50.0
        elif property_type in _PCT_TYPES:
            final_val = final_val / 100.0

        return {
            "id": self.id,
            "time_offset": self.time_offset,
            "values": [final_val],
            "curveType": "Line",
            "left_control": {"x": 0.0, "y": 0.0},
            "right_control": {"x": 0.0, "y": 0.0}
        }

class KeyframeList:
    """关键帧列表 (对应某个属性的一组关键帧)"""
    def __init__(self, property_type):
        self.id = generate_id()
        self.property_type = property_type # e.g., "KFTypePositionX"
        self.keyframes = []

    def add(self, time_offset, value):
        kf = Keyframe(time_offset, value)
        self.keyframes.append(kf)
        # 按时间排序
        self.keyframes.sort(key=lambda k: k.time_offset)

    def export(self, draft_width, draft_height):
        return {
            "id": self.id,
            "property_type": self.property_type,
            "material_id": "", # 导出时通常不需要填
            "keyframe_list": [k.export(self.property_type, draft_width, draft_height) for k in self.keyframes]
        }

class Segment(DraftObject):
    """
    时间轴片段基类 (对应 tracks[].segments 列表中的项)
    
    所有具体的素材片段 (VideoClip, TextClip 等) 都继承自此类，
    拥有通用的位置、缩放、旋转、动画等属性。
    """
    def __init__(self, duration):
        super().__init__()
        self.duration = duration
        self.start_time = 0
        self.source_timerange = None
        self.speed = 1.0
        self.volume = 1.0
        
        # Transform (存储 UI 值 - 像素)
        self.pos_x = 0.0
        self.pos_y = 0.0
        self.scale_x = 100.0  # UI值: 100 代表 100%
        self.scale_y = 100.0  # UI值: 100 代表 100%
        self.rotation = 0.0
        self.alpha = 100.0    # UI值: 100 代表 100% (不透明)
        self.uniform_scale = True
        
        self._animations = []
        self._extra_refs = []
        
        # Keyframes: { "KFTypePositionX": KeyframeListObj, ... }
        self._keyframes = {}

    def set_transform(self, x=0, y=0, scale=100, rotation=0, alpha=100, uniform_scale=True, scale_x=100, scale_y=100):
        """
        设置片段在画面中的变换属性 (位置、大小、旋转、不透明度)
        
        参数:
            x (float): X轴坐标 (像素)，屏幕中心为0，右正左负。默认 0。
            y (float): Y轴坐标 (像素)，屏幕中心为0，上正下负。默认 0。
            scale (float): 缩放比例 (UI百分比)，100 = 100% (原始大小)。仅当 uniform_scale=True 时有效。
            rotation (float): 旋转角度 (度)，顺时针为正。默认 0。
            alpha (float): 不透明度 (UI百分比)，0 (全透) ~ 100 (不透)。默认 100。
            uniform_scale (bool): 是否锁定宽高比缩放。默认 True。
            scale_x (float): X轴缩放比例 (UI百分比)。仅当 uniform_scale=False 时有效。
            scale_y (float): Y轴缩放比例 (UI百分比)。仅当 uniform_scale=False 时有效。
            
        示例:
            # 移到右上角，缩小一半，半透明
            clip.set_transform(x=500, y=300, scale=50, alpha=50)
        """
        self.pos_x = x
        self.pos_y = y
        self.rotation = rotation
        self.alpha = alpha
        self.uniform_scale = uniform_scale
        if uniform_scale:
            self.scale_x = scale
            self.scale_y = scale
        else:
            self.scale_x = scale_x
            self.scale_y = scale_y
        return self

    def add_animation(self, anim_type, resource_id=None, duration=0.5, **kwargs):
        """
        为片段添加动画 (入场/出场/循环)
        
        参数:
            anim_type (str): 动画类型
                - "in": 入场动画 (从片段开始处播放)
                - "out": 出场动画 (从片段结束处倒推播放)
                - "loop": 循环动画 (持续播放)
            resource_id (str): 动画资源 ID (必填)。如 "67243..."
            duration (float/str): 动画持续时长。如 0.5, "0.5s", "500ms"。默认 0.5s。
            
        注意:
            如果是出场动画 (out)，系统会自动根据片段时长计算开始时间点。
        """
        if isinstance(anim_type, dict) and resource_id is None:
            payload = dict(anim_type)
        else:
            payload = {"type": anim_type, "id": resource_id, "duration": duration, **kwargs}

        phase = normalize_animation_phase(payload.get("type"))
        entry = {
            "type": phase,
            "id": str(payload.get("id") or payload.get("resource_id") or resource_id or "").strip(),
            "resource_id": str(payload.get("resource_id") or payload.get("id") or resource_id or "").strip(),
            "effect_id": str(payload.get("effect_id") or "").strip(),
            "duration": payload.get("duration", duration),
            "start": payload.get("start"),
            "name": payload.get("name") or "animation",
            "material_type": str(payload.get("material_type") or "").strip(),
            "panel": payload.get("panel"),
            "platform": payload.get("platform") or "all",
            "path": payload.get("path") or "",
            "request_id": payload.get("request_id") or "",
            "category_id": payload.get("category_id") or "",
            "category_name": payload.get("category_name") or "",
            "anim_adjust_params": normalize_anim_adjust_params(payload.get("anim_adjust_params")),
            "target": normalize_animation_target(payload.get("target") or ""),
        }
        if not entry["resource_id"]:
            return self
        self._animations.append(entry)
        return self

    def add_keyframe(self, property_name, time, value):
        """
        添加关键帧 (所有值使用剪映 UI 面板上的数值)
        
        参数:
            property_name (str): 属性名称，常用:
                基础变换: "x"(像素), "y"(像素), "scale"(0-200%), "rotation"(度), "alpha"(0-100)
                调色: "brightness", "contrast", "saturation", "temperature" 等 (-100~100)
                蒙版: "mask_x"(像素), "mask_y"(像素), "mask_feather"(0-100) 等
                音量: "volume"(dB, -60~20, 0=原始音量)
                其他: "lut"(0-100), "filter"(0-100)
            time (str/float): 时间点 (如 "0.5s", "1s")
            value (float): 关键帧数值 (与剪映 UI 一致)
        """
        # 映射表: UI 名称 -> 内部 KFType
        PROP_MAP = {
            # 基础变换 (UI: 像素/百分比/度)
            "x": "KFTypePositionX", "y": "KFTypePositionY",
            # 【定稿】等比缩放双轨制：对外映射为 UNIFORM_SCALE，但 add_keyframe()
            # 内部会同时写入 KFTypeScaleX，形成两套关键帧，这是剪映面板识别等比
            # 缩放动画的必要条件（2026-03-12 验收确认）。
            "scale": "UNIFORM_SCALE",
            "scale_x": "KFTypeScaleX", "scale_y": "KFTypeScaleY",
            "rotation": "KFTypeRotation",
            "alpha": "KFTypeAlpha", "opacity": "KFTypeAlpha",
            # 音量 (UI: dB, -60~20, 内部存 linear)
            "volume": "KFTypeVolume",
            # 调色 (UI: -100~100)
            "brightness": "KFTypeBrightness", "contrast": "KFTypeContrast",
            "saturation": "KFTypeSaturation", "temperature": "KFTypeTemperature",
            "hue": "KFTypeHue", "sharpen": "KFTypeSharpen",
            "highlight": "KFTypeHightLight", "shadow": "KFTypeShadow",
            "black": "KFTypeBlack", "white": "KFTypeWhite",
            "fade": "KFTypeFade", "vignetting": "KFTypeVignetting",
            "light_sensation": "KFTypeLightSensatione",
            # 滤镜/LUT 强度 (UI: 0-100)
            "lut": "KFTypeLUT", "filter": "KFTypeFilter",
            # 蒙版 (UI: 像素/度/0-100)
            "mask_x": "KFTypeMaskPostionX", "mask_y": "KFTypeMaskPostionY",
            "mask_size_x": "KFTypeMaskSizeX", "mask_size_y": "KFTypeMaskSizeY",
            "mask_rotation": "KFTypeMaskRotation",
            "mask_feather": "KFTypeMaskFeather", "mask_round_corner": "KFTypeMaskRoundCorner",
            # 文字属性 (UI: 0-100/颜色/角度)
            # 手工草稿比对后确认：UI“文字不透明度”实际走的是 global_alpha，
            # 关键帧也应落到 KFTypeGlobalAlpha，而不是字面上的 KFTypeTextAlpha。
            "text_alpha": "KFTypeGlobalAlpha", "global_alpha": "KFTypeGlobalAlpha",
            "text_curve_angle": "KFTypeTextCurveAngle",
            # 描边 (UI: 0-100)
            "border_width": "KFTypeBorderWidth", "border_alpha": "KFTypeBorderAlpha",
            # 阴影 (UI: 0-100/角度)
            "shadow_alpha": "KFTypeShadowAlpha", "shadow_angle": "KFTypeShadowAngle",
            "shadow_distance": "KFTypeShadowDistance", "shadow_smoothing": "KFTypeShadowSmoothing",
            # 背景 (UI: 0-100)
            "bg_alpha": "KFTypeBackgroundAlpha",
            "bg_width": "KFTypeBackgroundWidth", "bg_height": "KFTypeBackgroundHeight",
            "bg_offset_x": "KFTypeBackgroundOffsetX", "bg_offset_y": "KFTypeBackgroundOffsetY",
            "bg_round_radius": "KFTypeBackgroundRoundRadius",
            # 光晕 (UI: 0-100)
            "bloom_alpha": "KFTypeBloomAlpha", "bloom_range": "KFTypeBloomRange",
            "bloom_strength": "KFTypeBloomStrength",
            # 色度抠像 (UI: 0-100)
            "chroma_intensity": "KFTypeChromaIntensity",
            "chroma_edge_smooth": "KFTypeChromaEdgeSmooth",
            "chroma_shadow": "KFTypeChromaShadow",
            "chroma_spill": "KFTypeChromaSpill",
        }
        
        if property_name not in PROP_MAP:
            return self

        kf_type = PROP_MAP[property_name]
        if property_name in {"scale_x", "scale_y"}:
            # 非等比缩放关键帧必须同步关闭片段级 uniform_scale，
            # 否则剪映 UI 仍可能停留在等比缩放，导致 scale_y 面板/效果不点亮。
            self.uniform_scale = False
        elif property_name == "scale":
            self.uniform_scale = True
        time_us = time
        
        if kf_type not in self._keyframes:
            self._keyframes[kf_type] = KeyframeList(kf_type)

        self._keyframes[kf_type].add(time_us, value)

        # 【定稿】等比缩放双轨制（2026-03-12 验收通过）：
        # 等比缩放关键帧必须同时导出 UNIFORM_SCALE 和 KFTypeScaleX 两套关键帧，
        # 并配合 uniform_scale.on = true，才能在剪映面板中正确点亮。
        # 单走 UNIFORM_SCALE 或单走 KFTypeScaleX 均无法让面板识别等比缩放动画。
        if property_name == "scale":
            if "KFTypeScaleX" not in self._keyframes:
                self._keyframes["KFTypeScaleX"] = KeyframeList("KFTypeScaleX")
            self._keyframes["KFTypeScaleX"].add(time_us, value)

        return self

    def _export_common_segment(self, draft, material_id, extra_refs):
        """生成通用的 Segment JSON 结构 (内部使用)"""
        # 保持 extra_refs 的顺序（sticker_animation 必须是第一个），同时去重
        seen = set()
        final_refs = []
        for r in (extra_refs + self._extra_refs):
            if r not in seen:
                seen.add(r)
                final_refs.append(r)
        
        # 导出关键帧列表
        kf_jsons = []
        if self._keyframes:
            for kf_list in self._keyframes.values():
                kf_jsons.append(kf_list.export(draft.width, draft.height))
        
        # 转换 UI 值 -> 内部归一化值
        internal_alpha = self.alpha / 100.0
        internal_scale_x = self.scale_x / 100.0
        internal_scale_y = self.scale_y / 100.0
        
        # 修正: 考虑 speed 对源时长的影响
        # 如果 self.speed != 1.0, 那么在轨道上 duration 不变的情况下，
        # 需要消耗的源视频长度 = duration * speed
        # 例如: 轨道长 2s, 速度 2.0x, 则需要 4s 的源视频内容
        # 注意: 只有当 source_timerange 存在时才处理（VideoClip 有，TextClip/StickerClip 为 None或不敏感）
        final_source_timerange = self.source_timerange
        if final_source_timerange and self.speed != 1.0:
            # 复制一份以防修改原对象
            final_source_timerange = final_source_timerange.copy()
            final_source_timerange["duration"] = int(self.duration * self.speed)
        
        return {
            "caption_info": None,
            "cartoon": False,
            "clip": {
                "alpha": internal_alpha, "rotation": self.rotation,
                "flip": {"horizontal": False, "vertical": False},
                "scale": {"x": internal_scale_x, "y": internal_scale_y},
                "transform": {"x": self.pos_x / draft.width, "y": self.pos_y / draft.height}
            },
            "common_keyframes": kf_jsons,
            "enable_adjust": True,
            "enable_color_correct_adjust": False,
            "enable_color_curves": True,
            "enable_color_match_adjust": False,
            "enable_color_wheels": True,
            "enable_lut": True,
            "enable_smart_color_adjust": False,
            "extra_material_refs": final_refs,
            "group_id": "",
            "hdr_settings": {"intensity": 1, "mode": 1, "nits": 1000},
            "id": self.id,
            "intensifies_audio": False,
            "is_placeholder": False,
            "is_tone_modify": False,
            "keyframe_refs": [],
            "last_nonzero_volume": 1.0,
            "material_id": material_id,
            "render_index": 0,
            "responsive_layout": {
                "enable": False,
                "horizontal_pos_layout": 0,
                "size_layout": 0,
                "target_follow": "",
                "vertical_pos_layout": 0,
            },
            "reverse": False,
            "source_timerange": final_source_timerange,
            "speed": self.speed,
            "target_timerange": {"start": self.start_time, "duration": self.duration},
            "template_id": "",
            "template_scene": "default",
            "track_attribute": 0,
            "track_render_index": 0,
            "uniform_scale": {"on": self.uniform_scale, "value": 1.0},
            "visible": True,
            "volume": self.volume,
        }
        
    def _export_animations_material(self, draft, target="video", force_create=False):
        """导出动画 Material (内部使用)
        
        force_create=True: 即使没有动画也强制创建空的材质引用（文字/贴纸 segment 必须）
        """
        normalized_target = normalize_animation_target(target)
        container_type = "video_animation" if normalized_target == "video" else "sticker_animation"
        anim_data_list = []
        for anim in self._animations:
            entry_target = anim.get("target") or normalized_target
            phase = anim.get("type")
            raw_resource_id = anim.get("resource_id") or anim.get("id")
            resolved_id = resolve_animation_resource_id(
                raw_resource_id, target=entry_target, phase=phase
            )
            anim_data_list.append(
                build_animation_entry(
                    target=entry_target,
                    phase=phase,
                    resource_id=resolved_id,
                    effect_id=anim.get("effect_id"),
                    duration_us=anim.get("duration"),
                    clip_duration_us=self.duration,
                    start_us=anim.get("start"),
                    name=anim.get("name"),
                    panel=anim.get("panel"),
                    material_type=anim.get("material_type"),
                    platform=anim.get("platform"),
                    path=anim.get("path"),
                    request_id=anim.get("request_id"),
                    category_id=anim.get("category_id"),
                    category_name=anim.get("category_name"),
                    anim_adjust_params=anim.get("anim_adjust_params"),
                )
            )
        if anim_data_list or force_create:
            gid = generate_id()
            draft.register_material("material_animations", {
                "id": gid,
                "type": container_type,
                "animations": anim_data_list, "multi_language_current": "none"
            })
            return gid
        return None

# ==============================================================================
# 3. 具体素材类
# ==============================================================================

class VideoClip(Segment):
    """
    视频或图片片段对象
    
    功能:
    - 支持加载视频 (.mp4, .mov) 或图片 (.jpg, .png)
    - 支持设置转场、蒙版、混合模式、智能裁剪
    - 支持视频增强算法 (降噪、防抖、去频闪)
    - 支持基础音频调节 (视频原声)
    """
    def __init__(self, file_path, duration=None, source_start=0, start=None, media_type=None):
        """
        初始化视频片段
        
        参数:
            file_path (str): 素材文件的绝对路径。必须存在。
            duration (float/str): 片段在轨道上的持续时间。
                - 对于图片: 必填 (如 "3s")
                - 对于视频: 选填 (如不填则默认使用原视频长度，当前简化版建议填写)
            source_start (float/str): 视频素材的截取开始点。默认 0 (从头开始)。
                - 示例: source_start="10s" (从第10秒开始截取)
            start (float/str): 在轨道上的绝对开始时间。
                - 如果设置了此值，将忽略轨道的自动排列逻辑，强制放置在此时间点。
                - 适用于画中画、叠加层等非主轨道场景。
        """
        super().__init__(duration)
        self.path = file_path
        self.type = "video"
        
        # 记录用户自定义的开始时间 (用于 Track.export 时覆盖自动排序)
        self.custom_start_time = start
        
        normalized_media_type = (media_type or "").lower()
        ext = _extract_media_extension(file_path)
        if normalized_media_type in ("image", "photo") or ext in ['.jpg', '.png', '.jpeg', '.bmp', '.gif', '.webp']:
            self.type = "photo"
            self.source_timerange = {"start": 0, "duration": self.duration}
        else:
            self.type = "video"
            self.source_timerange = {"start": source_start, "duration": self.duration}
            
        self.transition = None
        self.mask_config = None
        self.mix_mode = None
        self.smart_crop = None
        self.video_algo = {}
        
        self.change_pitch = False
        self.color_curves = False
        
        self.volume_db = 0.0
        self.fade_in = 0
        self.fade_out = 0
        self.vocal_separation = None
        
        # 音频增强 (Video原声)
        self.audio_denoise = False
        self.loudness = 0.0
        self.vocal_beautify = None
        self.tone_effect = None

        self.canvas_config = {"type": "canvas_color", "color": "", "image": ""}
        self.chroma_config = None
        
    def add_transition(self, resource_id, duration=1.0, overlap=True):
        """
        添加转场效果 (Transition)
        
        参数:
            resource_id (str): 转场资源 ID (必填)
            duration (float/str): 转场持续时长，默认 1.0s
            overlap (bool): 是否重叠转场 (默认 True)
            
        说明:
            转场将应用于当前片段的**尾部**，连接下一个片段。
        """
        self.transition = {"resource_id": resource_id, "duration": duration, "is_overlap": overlap}
        return self

    def set_mask(self, mask_type, center_x=0, center_y=0, rotation=0, size_x=None, size_y=None, feather=0, invert=False, round_corner=0):
        """
        设置蒙版 (Mask)
        
        参数:
            mask_type (str): 蒙版类型
                - "linear": 线性
                - "mirror": 镜面
                - "circle": 圆形
                - "rectangle": 矩形
                - "heart": 爱心
                - "star": 星形
            center_x (float): 中心 X 坐标 (像素)
            center_y (float): 中心 Y 坐标 (像素)
            rotation (float): 旋转角度 (度)
            size_x (float): 宽度/大小 (像素)
            size_y (float): 高度 (像素) - 线性/镜面模式下忽略
            feather (float): 羽化程度 (0-100)
            invert (bool): 是否反转 (内部/外部)
            round_corner (float): 圆角 (0-100) - 仅矩形有效
        """
        self.mask_config = {
            "type": mask_type, "center_x": center_x, "center_y": center_y,
            "rotation": rotation, "size_x": size_x, "size_y": size_y,
            "feather": feather, "invert": invert, "round_corner": round_corner
        }
        return self

    def set_mix_mode(self, name="变亮"):
        """
        设置混合模式 (Blending Mode)
        
        参数:
            name (str): 模式名称，与剪映 UI 面板一致:
                "正片叠底", "颜色减淡", "颜色加深", "线性加深",
                "柔光", "强光", "滤色", "叠加", "变亮", "变暗"
        """
        # 当前结论:
        # mix_mode 协议写法已通过专测草稿验证，低版本桌面端不显示更像是版本兼容性问题，
        # 而不是当前字段拼装错误。后续主要关注“最低支持版本”即可。
        if name not in MIXMODE_MAP:
            raise ValueError(f"不支持的混合模式 '{name}'，可选: {', '.join(MIXMODE_MAP.keys())}")
        self.mix_mode = {"name": name}
        return self

    def set_smart_crop(self, ratio="original", stability=2, speed=1):
        """
        设置智能裁剪 (Smart Crop)
        
        参数:
            ratio (str): 裁剪比例
                - "original", "16:9", "4:3", "9:16", "1:1", "2.35:1" 等
            stability (int): 镜头稳定度
                - 1: 灵活
                - 2: 默认
                - 3: 稳
            speed (int): 镜头位移速度
                - 0: 更快
                - 1: 标准
                - 2: 更慢
        """
        self.smart_crop = {"ratio": ratio, "stability": stability, "speed": speed}
        return self

    def set_video_algorithm(self, denoise=None, deflicker=False, quality_enhance=None, motion_blur=None, stabilize=None):
        """
        设置视频增强算法
        
        参数:
            denoise (int/str): 视频降噪
                - 0/"weak": 弱
                - 1/"strong": 强
                - None: 关闭
            deflicker (bool): 去频闪 (True=开启)
            quality_enhance (int/str): 画质增强
                - 1/"hd": 超清
                - None: 关闭
            motion_blur (bool): 运动模糊 (True=开启)
            stabilize (int/bool): 视频防抖
                - 1: 裁切最少
                - 2: 推荐
                - 3: 最稳
                - None: 关闭
        """
        self.video_algo = {
            "denoise": denoise, "deflicker": deflicker,
            "quality_enhance": quality_enhance, "motion_blur": motion_blur,
            "stabilize": stabilize
        }
        return self
        
    def set_color_curves(self, enabled=True):
        """开启曲线调色 (默认 S 曲线)"""
        self.color_curves = enabled
        return self
        
    def set_speed(self, speed, change_pitch=False):
        """
        设置播放速度
        
        参数:
            speed (float): 速度倍率 (0.1 ~ 100.0)
            change_pitch (bool): 是否变速变调 (True=变调, False=保持原调)
        """
        self.speed = speed
        self.change_pitch = change_pitch
        return self
        
    def set_volume(self, db):
        """设置音量 (dB), 范围 -60 ~ 20 (与剪映UI一致，步进0.1，单位dB)"""
        self.volume_db = db
        self.volume = db_to_linear(db)
        return self
        
    def set_audio_fade(self, fade_in=0, fade_out=0):
        """设置视频原声的淡入淡出时长（单位：微秒）"""
        self.fade_in = fade_in
        self.fade_out = fade_out
        return self
        
    def set_vocal_separation(self, mode=0):
        """
        人声分离 (Vocal Separation)
        
        参数:
            mode (int):
                - 0: 原始 (保留人声+背景)
                - 1: 仅保留背景声 (伴奏)
                - 2: 仅保留人声 (清唱)
        """
        self.vocal_separation = mode
        return self

    def set_audio_denoise(self, enabled=True):
        """开启视频原声降噪"""
        self.audio_denoise = enabled
        return self
        
    def set_loudness(self, target=-23.0):
        """设置视频原声响度统一 (LUFS), 常用值 -23.0"""
        self.loudness = target
        return self
        
    def set_vocal_beautify(self, intensity=75):
        """设置视频原声人声美化强度 (0-100)"""
        self.vocal_beautify = intensity
        return self
        
    def set_tone_effect(self, resource_id):
        """设置视频原声变声特效 Resource ID"""
        self.tone_effect = resource_id
        return self

    def set_chroma(self, color="#00FF00", intensity=50, edge_smooth=50, shadow=50, spill=50):
        """
        色度抠像 (Chroma Key / 绿幕抠像)
        
        参数:
            color (str): 抠像目标颜色 Hex，默认绿色 "#00FF00"
            intensity (int): 强度 (0-100)
            edge_smooth (int): 边缘平滑 (0-100)
            shadow (int): 阴影 (0-100)
            spill (int): 溢色抑制 (0-100)
        """
        # 已知待解决:
        # 当前这里只完成了 chroma 协议字段写入，桌面端尚未验证稳定生效。
        # 因此 chroma 本体及其关键帧(chroma_intensity/chroma_shadow 等)暂不视为已稳定支持。
        self.chroma_config = {
            "color": color,
            "intensity": intensity / 100.0,
            "edge_smooth": edge_smooth / 100.0,
            "shadow": shadow / 100.0,
            "spill": spill / 100.0
        }
        return self

    def set_canvas_background(self, mode="color", color="#000000", image_path="", blur=0):
        """
        设置画布背景
        
        参数:
            mode (str): 背景模式
                - "color": 纯色背景 (默认)
                - "image": 图片背景
                - "blur": 模糊背景 (使用视频自身画面模糊)
            color (str): 背景颜色 Hex (mode="color" 时使用)
            image_path (str): 背景图片路径 (mode="image" 时使用)
            blur (int): 模糊程度 (0-100, mode="blur" 时使用)
        """
        if mode == "color":
            self.canvas_config = {"type": "canvas_color", "color": color, "image": ""}
        elif mode == "image":
            self.canvas_config = {"type": "canvas_image", "color": "", "image": image_path}
        elif mode == "blur":
            self.canvas_config = {
                "type": "canvas_blur",
                "color": "",
                "image": "",
                "blur": blur / 100.0
            }
        return self

    def _create_mask_material(self, draft):
        if not self.mask_config: return None
        cfg = self.mask_config
        MASK_RESOURCES = {
            "linear":    {"res_id": "6791652175668843016", "res_type": "line", "name": "线性"},
            "mirror":    {"res_id": "6791699060140020232", "res_type": "mirror", "name": "镜面"},
            "circle":    {"res_id": "6791700663249146381", "res_type": "circle", "name": "圆形"},
            "rectangle": {"res_id": "6791700809454195207", "res_type": "rectangle", "name": "矩形"},
            "heart":     {"res_id": "6794051276482023949", "res_type": "geometric_shape", "name": "爱心"},
            "star":      {"res_id": "6794051169434997255", "res_type": "geometric_shape", "name": "星形"}
        }
        if cfg["type"] not in MASK_RESOURCES: return None
        res = MASK_RESOURCES[cfg["type"]]
        
        width_val = cfg.get("size_x", 0.5 * draft.width)
        height_val = cfg.get("size_y", 0.5 * draft.height)
        final_width = (float(width_val) / draft.width) if width_val else 0.5
        final_height = (float(height_val) / draft.height) if height_val else 0.5
        
        config_obj = {
            "aspectRatio": 1.0, 
            "centerX": (cfg["center_x"] / draft.width) * 2, "centerY": (cfg["center_y"] / draft.height) * 2,
            "feather": cfg["feather"] / 100.0, "height": final_height,
            "invert": cfg["invert"], "rotation": cfg["rotation"],
            "roundCorner": cfg["round_corner"] / 100.0, "width": final_width
        }
        mid = generate_id()
        draft.register_material("masks", {
            "config": config_obj, "id": mid, "name": res["name"],
            "path": f"D:{mid}", "platform": "all",
            "resource_id": res["res_id"], "resource_type": res["res_type"], "type": "mask"
        })
        return mid

    def _create_algo_config(self):
        algo = self.video_algo
        algo_list = []
        nr_conf, df_conf, qe_conf, mb_conf = None, None, None, None
        
        denoise = algo.get("denoise")
        if denoise is not None:
            algo_list.append({"algorithm_id": "", "type": "NoiseReduction"})
            level = 1
            if denoise in [0, "0", "weak"]: level = 0
            nr_conf = {"level": level}
            
        deflicker = algo.get("deflicker")
        if deflicker:
            algo_list.append({"algorithm_id": "", "type": "Deflicker"})
            d_level = 1; d_mode = 0
            if isinstance(deflicker, dict):
                # 智能解析 Mode: 0=荧光灯, 1=延时摄影
                m_val = str(deflicker.get("mode", 0)).lower()
                if m_val in ["timelapse", "1", "延时摄影"]: 
                    d_mode = 1
                else: 
                    d_mode = 0
                
                # 智能解析 Level: 0=较弱, 1=推荐, 2=较强
                l_val = str(deflicker.get("level", 1)).lower()
                if l_val in ["weak", "0", "较弱"]: 
                    d_level = 0
                elif l_val in ["strong", "2", "较强"]: 
                    d_level = 2
                else: 
                    d_level = 1 # 默认为推荐/recommended
            
            df_conf = {"level": d_level, "mode": d_mode}
            
        qe = algo.get("quality_enhance")
        if qe is not None:
            level = 1 # Ultra HD
            if qe in [0, "0"]: level = 0 # HD
            qe_conf = {"level": level}
            
        mb = algo.get("motion_blur")
        if mb:
            algo_list.append({"algorithm_id": "", "type": "MotionBlur"})
            if isinstance(mb, dict): mb_conf = mb
            else: mb_conf = {"blend": 0.16, "blur": 1.0, "blur_frame_type": "bilateral", "multiple_blur": 1}
            
        return {
            "algorithms": algo_list, "deflicker": df_conf, "motion_blur_config": mb_conf,
            "noise_reduction": nr_conf, "quality_enhance": qe_conf,
            "path": f"D:{generate_id()}",
            "time_range": {"duration": self.duration, "start": 0} if (algo_list or qe_conf) else None
        }

    def _create_stable_config(self):
        stabilize = self.video_algo.get("stabilize")
        # Smart crop overrides stabilize
        if self.smart_crop: 
            return {"matrix_path": "", "stable_level": 0, "time_range": {"duration": 0, "start": 0}}
        
        if stabilize:
            level = 1 if stabilize is True else int(stabilize)
            return {"matrix_path": "", "stable_level": level, "time_range": {"duration": self.duration, "start": 0}}
        return {"matrix_path": "", "stable_level": 0, "time_range": {"duration": 0, "start": 0}}

    def export(self, draft):
        video_mat_id = generate_id()
        ext = _extract_media_extension(self.path)
        mat_type = "photo" if (self.type == "photo" or ext in [".jpg", ".jpeg", ".png", ".bmp", ".gif", ".webp"]) else "video"
        
        # Audio Fade (New Logic)
        extra_refs = []
        fade_obj = None
        if self.fade_in > 0 or self.fade_out > 0:
            fade_id = generate_id()
            fade_obj = {
                "id": fade_id, "type": "audio_fade",
                "fade_in_duration": self.fade_in, "fade_out_duration": self.fade_out, "fade_type": 0
            }
            # 同时注册到全局和内嵌引用
            draft.register_material("audio_fades", fade_obj)
            extra_refs.append(fade_id)

        draft.register_material("videos", {
            "id": video_mat_id, "type": mat_type, "path": self.path,
            "duration": self.duration,  # 使用实际片段长度，而非硬编码
            "height": 1080, "width": 1920, "material_name": os.path.basename(self.path),
            "category_name": "local", "check_flag": 63487,
            "video_algorithm": self._create_algo_config(),
            "stable": self._create_stable_config(),
            "audio_fade": fade_obj, # 恢复内嵌: 如果为 None 则 json dump 也是 null，符合逻辑
            "crop": {"lower_left_x": 0.0, "lower_left_y": 1.0, "lower_right_x": 1.0, "lower_right_y": 1.0, "upper_left_x": 0.0, "upper_left_y": 0.0, "upper_right_x": 1.0, "upper_right_y": 0.0},
            "crop_ratio": "free", "crop_scale": 1.0
        })
        
        speed_id = generate_id()
        draft.register_material("speeds", {"id": speed_id, "type": "speed", "speed": self.speed, "mode": 0})
        extra_refs.append(speed_id)
        
        canvas_id = generate_id()
        draft.register_material("canvases", {"id": canvas_id, **self.canvas_config})
        extra_refs.append(canvas_id)
        
        anim_gid = self._export_animations_material(draft, target="video")
        if anim_gid: extra_refs.append(anim_gid)
        
        mask_id = self._create_mask_material(draft)
        if mask_id: extra_refs.append(mask_id)
        
        if self.mix_mode:
            mix_id = generate_id()
            mm = MIXMODE_MAP[self.mix_mode["name"]]
            draft.register_material("effects", {
                "id": mix_id, "type": "mix_mode",
                "resource_id": mm["resource_id"], "effect_id": mm["effect_id"],
                "name": self.mix_mode["name"], "path": f"D:{mix_id}", "platform": "all", "value": 1.0
            })
            extra_refs.append(mix_id)
            
        if self.smart_crop:
            sc_id = generate_id()
            draft.register_material("smart_crops", {
                "id": sc_id, "type": "smart_crop", "crop_ratio": self.smart_crop["ratio"],
                "stability": self.smart_crop["stability"], "track_speed": self.smart_crop["speed"],
                "cache_path": f"D:{sc_id}", "apply_source": 1
            })
            extra_refs.append(sc_id)

        if self.chroma_config:
            cr_id = generate_id()
            r, g, b = hex_to_rgb(self.chroma_config["color"])
            draft.register_material("chromas", {
                "id": cr_id, "type": "chroma",
                "color": [r, g, b],
                "intensity": self.chroma_config["intensity"],
                "edge_smooth": self.chroma_config["edge_smooth"],
                "shadow": self.chroma_config["shadow"],
                "spill": self.chroma_config["spill"],
                "path": f"D:{cr_id}"
            })
            extra_refs.append(cr_id)

        if self.color_curves:
            curve_id = generate_id()
            draft.register_material("color_curves", {
                "id": curve_id, "type": "color_curves", "path": f"D:{curve_id}",
                "resource_id": "7040008114145333791", "panel": "curve-hsl",
                "luma": [{"anchor": {"x": 0.0, "y": 0.0}, "left_control": {"x": 0.0, "y": 0.0}, "right_control": {"x": 0.2, "y": 0.2}}, {"anchor": {"x": 1.0, "y": 1.0}, "left_control": {"x": 0.8, "y": 0.8}, "right_control": {"x": 1.0, "y": 1.0}}],
                "red": [], "green": [], "blue": []
            })
            extra_refs.append(curve_id)
            
        if self.transition:
            trans_id = generate_id()
            draft.register_material("transitions", {
                "id": trans_id, "type": "transition",
                "resource_id": self.transition["resource_id"], "effect_id": self.transition["resource_id"],
                "duration": self.transition["duration"], "is_overlap": self.transition["is_overlap"],
                "category_name": "transition", "path": "", "platform": "all"
            })
            extra_refs.append(trans_id)

        sc_id = generate_id()
        draft.register_material("sound_channel_mappings", {"id": sc_id, "type": "none", "audio_channel_mapping": 0, "is_config_open": False})
        extra_refs.append(sc_id)
        
        vs_id = generate_id()
        choice = self.vocal_separation if self.vocal_separation is not None else 0
        draft.register_material("vocal_separations", {"id": vs_id, "type": "vocal_separation", "choice": choice, "production_path": ""})
        extra_refs.append(vs_id)
        
        loud_id = generate_id()
        if self.loudness:
            draft.register_material("loudnesses", {"id": loud_id, "enable": True, "target_loudness": self.loudness, "time_range": {"duration": self.duration, "start": 0}})
        else:
            draft.register_material("loudnesses", {"id": loud_id, "enable": False, "target_loudness": 0.0, "time_range": None})
        extra_refs.append(loud_id)
        
        if self.audio_denoise:
            dn_id = generate_id()
            draft.register_material("realtime_denoises", {
                "id": dn_id, "is_denoise": True, "denoise_mode": 1.0, "denoise_rate": 0.85, "type": "realtime_denoise", "path": f"D:{dn_id}"
            })
            extra_refs.append(dn_id)
            
        if self.tone_effect:
            te_id = generate_id()
            draft.register_material("audio_effects", {
                "id": te_id, "type": "tone", "resource_id": self.tone_effect, "source_platform": 1, "value": 1.0, "apply_target_type": 0
            })
            extra_refs.append(te_id)
            
        if self.vocal_beautify:
            vb_id = generate_id()
            draft.register_material("vocal_beautifys", {
                "id": vb_id, "enable": True, "ambient_sound_level": int(self.vocal_beautify), "time_range": {"duration": self.duration, "start": 0}, "type": "vocal_beautify"
            })
            extra_refs.append(vb_id)

        seg_json = self._export_common_segment(draft, video_mat_id, extra_refs)
        if self.color_curves: seg_json["enable_color_curves"] = True
        if self.change_pitch: seg_json["is_tone_modify"] = True
        return seg_json


class StickerClip(Segment):
    """
    贴纸片段对象
    
    支持功能:
    - 基础变换 (位置、大小、旋转)
    - 动画 (入场、出场、循环)
    - 支持在线素材 ID 或本地图片路径 (作为自定义贴纸)
    """
    def __init__(self, resource_id, start=0, duration="3s"):
        """
        参数:
            resource_id (str): 贴纸资源 ID 或 本地图片绝对路径。
            start (float/str): 开始时间。
            duration (float/str): 持续时间。
        """
        super().__init__(duration)
        self.resource_id = resource_id
        self.start_time = start
        # 贴纸强制不透明度为 100，因为剪映的贴纸材质似乎不支持 global_alpha 控制显示
        self.alpha = 100.0
        
        self.is_local_file = False
        if os.path.exists(resource_id):
            self.is_local_file = True
            self.file_path = resource_id
        
    def export(self, draft):
        mat_id = generate_id()
        
        if self.is_local_file:
            # 本地图片作为自定义贴纸
            draft.register_material("stickers", {
                "id": mat_id, "type": "sticker",
                "sticker_id": mat_id, 
                "resource_id": mat_id,
                "path": self.file_path, 
                "name": os.path.basename(self.file_path),
                "global_alpha": 1.0,
                "category_name": "local",
                "source_platform": 0
            })
        else:
            # 在线素材库贴纸
            # 补全关键字段，尝试解决“下载失败”问题
            draft.register_material("stickers", {
                "id": mat_id, "type": "sticker",
                "sticker_id": self.resource_id, 
                "resource_id": self.resource_id,
                # path 留空或设为特殊占位符，让剪映识别为在线资源
                # 经验值: 某些版本需要 path 存在但为无效值，配合 category_name="sticker"
                "path": "", 
                "name": "sticker",
                "global_alpha": 1.0,
                "source_platform": 1, # 1 表示官方/在线平台
                "category_name": "sticker", # 标识为贴纸分类
                "check_flag": 1, # 校验位
                "sub_type": 0,
                "aigc_type": "none"
            })
        
        # sticker_animation 必须始终是 extra_material_refs 的第一个引用（即使没有动画）
        anim_gid = self._export_animations_material(draft, target="sticker", force_create=True)
        extra_refs = [anim_gid]
        
        seg_json = self._export_common_segment(draft, mat_id, extra_refs)
        seg_json["source_timerange"] = None
        # 覆盖 alpha，贴纸在 Clip 层也通常保持 1.0
        seg_json["clip"]["alpha"] = 1.0
        return seg_json


class TextClip(Segment):
    """
    文本片段对象
    
    支持功能:
    - 基础样式 (字体、大小、颜色、加粗等)
    - 高级排版 (对齐、行距、字距)
    - 装饰效果 (描边、阴影、背景板、弯曲)
    - 特效引用 (花字、气泡)
    - 富文本标签 (<red>text</red>)
    """
    def __init__(self, content, start=0, duration="3s"):
        """
        初始化文本片段
        
        参数:
            content (str): 文本内容，支持简单的XML标签，如 "Hello <red>World</red>"
            start (float/str): 在轨道上的开始时间。
            duration (float/str): 持续时间。
        """
        super().__init__(duration)
        self.start_time = start
        self.content = content
        
        # 默认样式 (UI值)
        self.font_id = ""
        self.font_path = "/Applications/VideoFusion-macOS.app/Contents/Resources/Font/SystemFont/zh-hans.ttf"
        self.font_size = 15
        self.text_color = "#FFFFFF"
        self.text_alpha = 100.0 # UI值 0-100
        self.is_bold = False
        self.is_italic = False
        self.is_underline = False
        
        self.border_width = 0   # UI值 0-100
        self.border_color = ""
        self.shadow_alpha = 0   # UI值 0-100
        self.shadow_color = ""
        self.shadow_dist = 5.0  # UI值 0-100
        self.shadow_angle = -45.0 # UI值 -180 ~ 180
        self.shadow_diffuse = 0.0 # UI值 0-100 (模糊度)
        
        self.bg_color = ""
        self.bg_alpha = 0       # UI值 0-100
        
        # 高级排版/背景控制 (存储为内部值，set_format 接收 UI 值并转换)
        self.line_spacing = 0.0 # 内部值，QML 默认 lineSpacing=0.0 (ScriptTemplate确认)
        self.letter_spacing = 0.0 # 内部值，QML 默认 letterSpacing=0.0
        self.line_max_width = 0.82 # 内部值 (UI 默认 82%)
        
        self.typesetting = 0 # 0=横排, 1=竖排
        self.alignment = 1 # 居中
        self.bg_config = {} # radius, width, height, offset, style - 全部存储为 UI 值
        self.curve_angle = 0
        
        self.glow_id = ""
        self.bubble_id = ""
        self.bloom_config = None
        self.rich_styles = {} 

    def set_style(self, font_id=None, size=None, color=None, alpha=None, bold=None, italic=None, underline=None):
        """
        设置基础文字外观
        
        参数:
            font_id (str): 字体 Resource ID。若为空则使用系统默认。
            size (int): 字号，默认 15。
            color (str): 字体颜色 Hex，如 "#FFFFFF"。
            alpha (int/float): 字体不透明度 (0-100)。
            bold (bool): 是否加粗。
            italic (bool): 是否斜体。
            underline (bool): 是否下划线。
        """
        if font_id: 
            self.font_id = font_id
        if size is not None: self.font_size = size
        if color: self.text_color = color
        if alpha is not None: self.text_alpha = alpha
        if bold is not None: self.is_bold = bold
        if italic is not None: self.is_italic = italic
        if underline is not None: self.is_underline = underline
        return self

    def set_format(self, align=1, line_spacing=0, letter_spacing=0, line_max_width=82, typesetting=0):
        """
        设置段落排版 (参数为 UI 值)
        
        参数:
            align (int): 对齐方式
                - 横排(typesetting=0): 0=左, 1=中, 2=右
                - 竖排(typesetting=1): 1=中, 3=上, 4=下
            line_spacing (int): 行间距 (UI值 -10 ~ 100)，默认 0。
            letter_spacing (int): 字间距 (UI值 -10 ~ 100)，默认 0。
            line_max_width (int): 最大行宽 (UI值 0 ~ 100)，默认 82。
            typesetting (int): 排版模式 (0=横排, 1=竖排)
        """
        self.alignment = align
        # 转换公式参考 jianying_generator.py
        self.line_spacing = line_spacing / 20.0
        self.letter_spacing = letter_spacing / 20.0
        self.line_max_width = line_max_width / 100.0
        self.typesetting = typesetting
        return self

    def set_border(self, width=0, color="#000000"):
        """
        设置描边
        
        参数:
            width (int): 描边粗细 (0-100)。0 表示关闭。
            color (str): 描边颜色 Hex。
        """
        self.border_width = width
        self.border_color = color
        return self
        
    def set_shadow(self, alpha=80, color="#000000", distance=5.0, angle=-45.0, diffuse=15):
        """
        设置投影 (阴影)
        
        参数:
            alpha (int): 阴影不透明度 (0-100)。0 表示关闭。
            color (str): 阴影颜色 Hex。
            distance (int/float): 阴影距离 (0-100)。默认 5.0。
            angle (int/float): 阴影角度 (-180 ~ 180)。默认 -45.0。
            diffuse (int/float): 阴影模糊度 (0-100)。默认 15。
        """
        self.shadow_alpha = alpha
        self.shadow_color = color
        self.shadow_dist = distance
        self.shadow_angle = angle
        # 转换公式: 内部值 = UI值 / 100 / 6 (近似，根据旧版逻辑调整)
        # 旧版逻辑: internal = UI / 100 / 6 
        # 这里为了保持API传入UI值，我们在export时再转换，或者这里存UI值
        # 策略: 存UI值，export时转换
        self.shadow_diffuse = diffuse 
        return self
        
    def set_background(self, color="#000000", alpha=50, radius=50, width=0, height=0, off_x=50, off_y=50, style=1):
        """
        设置背景板
        
        参数:
            color (str): 背景颜色 Hex。
            alpha (int): 背景不透明度 (0-100)。
            radius (int): 圆角 (0-100)。
            width (int): 背景宽度 (0-100, 0=自动)。
            height (int): 背景高度 (0-100, 0=自动)。
            off_x (int): 左右偏移 (0-100, 50=居中)。
            off_y (int): 上下偏移 (0-100, 50=居中)。
            style (int): 背景样式 (1=普通模式, 2=贴合模式)。
        """
        self.bg_color = color
        self.bg_alpha = alpha
        self.bg_config = {
            "radius": radius, 
            "width": width, 
            "height": height, 
            "offset_x": off_x, 
            "offset_y": off_y, 
            "type": style
        }
        return self
        
    def set_curve(self, angle=0):
        """设置文字弯曲 (角度 -360 ~ 360)"""
        self.curve_angle = int(angle)
        return self
        
    def set_effect(self, glow_id=None, bubble_id=None):
        """
        设置特效引用
        
        参数:
            glow_id (str): 花字特效 Resource ID。
            bubble_id (str): 气泡特效 Resource ID。
        """
        if glow_id: self.glow_id = glow_id
        if bubble_id: self.bubble_id = bubble_id
        return self

    def set_bloom(self, strength=50, range_val=50, dir_x=0, dir_y=0, color="", bloom_type="外发光"):
        """
        设置文字发光效果
        
        参数:
            strength (int):    发光强度 (0-100，与剪映UI一致)
            range_val (int):   发光范围 (0-100，与剪映UI一致)
            dir_x (int):       水平角度 (-50~50，与剪映UI一致，0=居中)
            dir_y (int):       垂直角度 (-50~50，与剪映UI一致，0=居中)
            color (str):       发光颜色 (hex，默认""=白色)
            bloom_type (str):  发光类型。"外发光"（默认，稳定）或 "轮廓光"
        """
        self.bloom_config = {
            "strength": strength / 100.0,
            "range": range_val / 100.0,
            "dir_x": dir_x / 100.0 + 0.5,   # UI(-50~50) -> internal(0~1)
            # 5.9 实机验证：垂直方向与我们之前的直觉相反，这里翻转 Y 轴以对齐 UI 语义。
            "dir_y": 0.5 - dir_y / 100.0,
            "color": color,
            "type": bloom_type,
        }
        return self

    def add_rich_style(self, tag, **kwargs):
        """
        注册富文本标签样式
        
        用法:
            clip.add_rich_style("red", color="#FF0000", size=30)
            clip.content = "普通文字<red>红色大字</red>"
            
        参数:
            tag (str): 标签名，如 "red"
            **kwargs: 支持的样式属性 (color, size, bold, italic, underline, font_id)
        """
        self.rich_styles[tag] = kwargs
        return self

    def _generate_style_item(self, start, end, params):
        color = params.get("color", self.text_color)
        size = float(params.get("size", self.font_size))
        f_id = params.get("font_id", self.font_id)
        f_name = font_name_by_id(f_id) if f_id else ""
        f_path = f"{f_name}.ttf" if f_name else "/../Resources/Font/SystemFont/zh-hans.ttf"
        
        r, g, b = hex_to_rgb(color)
        style = {
            "fill": {
                "content": {
                    "solid": {"color": [r, g, b]},
                }
            },
            "font": {"id": f_id, "path": f_path},
            "range": [start, end],
            "size": size,
        }
        has_custom_color = params.get("color") and params["color"].upper() != self.text_color.upper()
        if params.get("useLetterColor") or has_custom_color:
            style["useLetterColor"] = True
        return style

    def _parse_rich_text(self):
        clean_text = ""
        style_list = []
        
        # 1. 尝试解析富文本
        if not self.rich_styles:
            # 无富文本标签，直接使用全文
            clean_text = self.content
            style_list = [self._generate_style_item(0, utf16_len(self.content), {})]
        else:
            base_params = {}
            style_stack = [base_params]
            char_params = []
            tokens = re.split(r'(<[/]?[a-zA-Z0-9_]+>)', self.content)
            for token in tokens:
                tag_match = re.match(r'<(/)?([a-zA-Z0-9_]+)>', token)
                is_tag = False
                if tag_match:
                    tag_name = tag_match.group(2)
                    if tag_name in self.rich_styles:
                        is_tag = True
                        if tag_match.group(1) == '/':
                            if len(style_stack) > 1: style_stack.pop()
                        else:
                            new_style = style_stack[-1].copy()
                            new_style.update(self.rich_styles[tag_name])
                            style_stack.append(new_style)
                if not is_tag:
                    clean_text += token
                    current = style_stack[-1]
                    for _ in token: char_params.append(current)
            
            if not char_params: 
                # 空内容处理
                return "", []
            
            # 合并相邻相同样式的字符
            current_u16 = 0
            current_start = 0
            current_params = char_params[0]
            for i in range(1, len(char_params)):
                if char_params[i] != current_params:
                    seg_txt = clean_text[current_start:i]
                    u16_len = utf16_len(seg_txt)
                    style_list.append(self._generate_style_item(current_u16, current_u16 + u16_len, current_params))
                    current_u16 += u16_len
                    current_start = i
                    current_params = char_params[i]
            seg_txt = clean_text[current_start:]
            u16_len = utf16_len(seg_txt)
            style_list.append(self._generate_style_item(current_u16, current_u16 + u16_len, current_params))
        
        # 2. 补充花字、描边、阴影到各个 Style Item
        border_w_internal = (self.border_width / 100.0 * 0.2) if self.border_width > 0 else 0.08
        shadow_diff_internal = self.shadow_diffuse / 100.0 / 6.0
        shadow_a_internal = self.shadow_alpha / 100.0

        has_border = (self.border_width > 0)
        has_shadow = (self.shadow_alpha > 0 and self.shadow_color != "")

        if self.glow_id or has_shadow or has_border or self.curve_angle != 0:
            for style in style_list:
                if has_border:
                    use_border_color = self.border_color if self.border_color else "#000000"
                    br, bg, bb = hex_to_rgb(use_border_color)
                    style["strokes"] = [{
                        "alpha": 1,
                        "content": {
                            "render_type": "solid",
                            "solid": {"alpha": 1, "color": [br, bg, bb]},
                        },
                        "width": border_w_internal,
                    }]
                if has_shadow:
                    sr, sg, sb = hex_to_rgb(self.shadow_color)
                    style["shadows"] = [{
                        "diffuse": shadow_diff_internal,
                        "alpha": shadow_a_internal,
                        "distance": self.shadow_dist,
                        "content": {
                            "solid": {"color": [sr, sg, sb]},
                        },
                        "angle": self.shadow_angle,
                    }]
                if self.glow_id:
                    style["effectStyle"] = {"id": self.glow_id, "path": f"C:{self.glow_id}"}
                if self.curve_angle != 0:
                    style["text_curve"] = {"angle": self.curve_angle, "enable": True}

        return clean_text, style_list

    def export(self, draft):
        clean_text, style_list = self._parse_rich_text()
        content_obj = {"text": clean_text, "styles": style_list}
        
        # Check Flag — 只设置实际启用的效果位，避免 UI 面板误亮
        check_flag = 7
        if self.border_width > 0:
            check_flag |= 8
        if self.bg_color:
            check_flag |= 16
        if self.shadow_alpha > 0:
            check_flag |= 32
        if self.glow_id or self.bloom_config:
            check_flag |= 64
        if self.shadow_alpha > 0 or self.curve_angle != 0:
            check_flag |= 128
        
        mat_id = generate_id()
        bloom_effect_ids = []
        if self.bloom_config:
            # 外发光(9762443): Lua 有 nil 保护，可单独使用，稳定
            # 轮廓光(9762325): Lua 无 nil 保护，单独使用崩溃，需与外发光同时存在
            BLOOM_TYPES = {
                "外发光": {
                    "effect_id": "9762443",
                    "name": "外发光",
                    "resource_id": "7202576698775179837",
                },
                "轮廓光": {
                    "effect_id": "9762325",
                    "name": "轮廓光",
                    "resource_id": "7202575978646737469",
                },
            }
            btype = self.bloom_config.get("type", "外发光")
            # 轮廓光在 5.9 中需要外发光一并存在才更稳定，但主类型仍应排在前面，
            # 否则面板容易优先点亮外发光，造成“看起来像同一个素材”的错觉。
            bloom_chain = ["轮廓光", "外发光"] if btype == "轮廓光" else [btype]
            for bloom_name in bloom_chain:
                binfo = BLOOM_TYPES.get(bloom_name, BLOOM_TYPES["外发光"])
                bloom_path = _get_bloom_path(binfo["effect_id"])
                bloom_effect_id = generate_id()
                bloom_effect_ids.append(bloom_effect_id)
                draft.register_material("effects", {
                    "adjust_params": [],
                    "algorithm_artifact_path": "",
                    "apply_target_type": 0,
                    "bloom_params": {
                        "color": self.bloom_config["color"] or "#FFFFFF",
                        "dir_x": self.bloom_config["dir_x"],
                        "dir_y": self.bloom_config["dir_y"],
                        "range": self.bloom_config["range"],
                        "strength": self.bloom_config["strength"],
                    },
                    "category_id": "",
                    "category_name": "local",
                    "color_match_info": None,
                    "effect_id": binfo["effect_id"],
                    "enable_skin_tone_correction": False,
                    "exclusion_group": [],
                    "face_adjust_params": [],
                    "formula_id": "",
                    "id": bloom_effect_id,
                    "intensity_key": "",
                    "multi_language_current": "",
                    "name": binfo["name"],
                    "panel_id": "text_glow",
                    "path": bloom_path,
                    "platform": "all",
                    "request_id": "",
                    "resource_id": binfo["resource_id"],
                    "source_platform": 0,
                    "sub_type": "none",
                    "time_range": None,
                    "type": "bloom",
                    "value": 1.0,
                    "version": "",
                })
        if self.glow_id:
            gid = generate_id()
            draft.register_material("effects", {"id": gid, "type": "text_effect", "resource_id": self.glow_id, "source_platform": 1, "value": 1.0})
        if self.bubble_id:
            bid = generate_id()
            draft.register_material("effects", {"id": bid, "type": "text_shape", "resource_id": self.bubble_id, "apply_target_type": 0, "value": 1.0})

        # 参数转换 (UI -> Internal)
        bg_alpha_internal = self.bg_alpha / 100.0
        bg_color_internal = self.bg_color if self.bg_color else ""
        bg_width_internal = self.bg_config.get("width", 0) / 100.0
        bg_height_internal = self.bg_config.get("height", 0) / 100.0
        bg_radius_internal = self.bg_config.get("radius", 50) / 100.0
        # 偏移公式: (val - 50) / 50.0 (范围 -1.0 ~ 1.0)
        # 验证: UI显示75时内部值为0.5，说明 0.5 * 50 + 50 = 75，即 internal = (UI - 50) / 50
        bg_off_x_internal = (self.bg_config.get("offset_x", 50) - 50) / 50.0
        bg_off_y_internal = (self.bg_config.get("offset_y", 50) - 50) / 50.0
        
        border_width_internal = (self.border_width / 100.0 * 0.2) if self.border_width > 0 else 0.08
        
        shadow_alpha_internal = self.shadow_alpha / 100.0 if self.shadow_alpha > 0 else 0.9
        shadow_smoothing_internal = self.shadow_diffuse / 100.0 / 6.0 if self.shadow_diffuse > 0 else 0.45
        shadow_point = {"x": 0.6363961030678928, "y": -0.6363961030678927}
        
        global_alpha = self.text_alpha / 100.0

        has_shadow = (self.shadow_alpha > 0 and self.shadow_color != "")

        # 5.9 原生文本链更接近相对系统字体路径。
        _SYS_FONT = "/../Resources/Font/SystemFont/zh-hans.ttf"
        _font_name = font_name_by_id(self.font_id) if self.font_id else ""
        _font_file = f"{_font_name}.ttf" if _font_name else ""
        fonts_list = []
        if self.font_id:
            fonts_list = [{
                "effect_id": self.font_id,
                "id": self.font_id,
                "path": _font_file,
                "resource_id": self.font_id,
                "title": _font_name,
            }]

        if self.bg_color:
            bg_r, bg_g, bg_b = hex_to_rgb(self.bg_color)
            canvas_color = [bg_r, bg_g, bg_b, bg_alpha_internal]
        else:
            canvas_color = [0.0, 0.0, 0.0, 0.0]

        if has_shadow:
            sh_r, sh_g, sh_b = hex_to_rgb(self.shadow_color)
            shadow_color_rgba = [sh_r, sh_g, sh_b, shadow_alpha_internal]
            shadow_offset = [shadow_point["x"] / 18.0, shadow_point["y"] / 18.0]
            shadow_diffuse = shadow_smoothing_internal / 18.0
            shadow_alpha_value = shadow_alpha_internal
        else:
            shadow_color_rgba = [0.0, 0.0, 0.0, 0.0]
            shadow_offset = [0.0, 0.0]
            shadow_diffuse = 0.0
            shadow_alpha_value = 0.0

        text_params = {
            "autoAdaptDpiEnabled": False,
            "boldValue": 0.008 if self.is_bold else 0.0,
            "canvas": bool(self.bg_color),
            "canvasColor": canvas_color,
            "canvasCustomized": True,
            "canvasOffsetCustomized": [
                bg_off_x_internal if self.bg_color else 0.0,
                bg_off_y_internal if self.bg_color else 0.0,
            ],
            "canvasRoundCorner": bool(self.bg_color and bg_radius_internal > 0),
            "canvasRoundRadiusScale": bg_radius_internal if self.bg_color else 0.0,
            "canvasSplitPadding": 0.1,
            "canvasSplitThreshold": 1000.0,
            "canvasWHCustomized": [
                bg_width_internal if self.bg_color and bg_width_internal > 0 else 1.0,
                bg_height_internal if self.bg_color and bg_height_internal > 0 else 1.0,
            ],
            "canvasWHFixed": [-1.0, -1.0],
            "canvasWrapped": bool(self.bg_color and self.bg_config.get("type", 0) == 2),
            "decorationOffset": 0.22,
            "decorationWidth": 0.05,
            "fallbackFontPathList": [],
            "globalAlpha": global_alpha,
            "innerPadding": 0.2,
            "italicDegree": 10 if self.is_italic else 0,
            "letterSpacing": self.letter_spacing,
            "lineMaxWidth": self.line_max_width,
            "lineSpacing": self.line_spacing if self.line_spacing != 0.0 else 0.02,
            "oneLineCutOff": False,
            "richText": clean_text,
            "selectedColor": [0.0, 0.8, 0.8, 0.4],
            "sdfTextAlpha": global_alpha,
            "shadowAlpha": shadow_alpha_value,
            "shadowAngle": self.shadow_angle if has_shadow else 0.0,
            "shadowColor": shadow_color_rgba,
            "shadowDiffuse": shadow_diffuse,
            "shadowOffset": shadow_offset,
            "shapeFlipX": False,
            "shapeFlipY": False,
            "shapePath": "",
            "typeSettingAlign": self.alignment,
            "typeSettingKind": self.typesetting,
            "version": "2",
        }

        draft.register_material("texts", {
            "add_type": 0,
            "alignment": self.alignment,
            "background_alpha": bg_alpha_internal if self.bg_color else 0.0,
            "background_color": bg_color_internal,
            "background_height": bg_height_internal if self.bg_color else 0.0,
            "background_horizontal_offset": bg_off_x_internal if self.bg_color else 0,
            "background_round_radius": bg_radius_internal if self.bg_color else 0,
            "background_style": self.bg_config.get("type", 0) if self.bg_color else 0,
            "background_vertical_offset": bg_off_y_internal if self.bg_color else 0,
            "background_width": bg_width_internal if self.bg_color else 0.0,
            "base_content": clean_text,
            "bold_width": 0.0,
            "border_alpha": 1.0 if self.border_width > 0 else 0.0,
            "border_color": self.border_color if self.border_width > 0 else "",
            "border_width": border_width_internal if self.border_width > 0 else 0.0,
            "caption_template_info": {
                "category_id": "", "category_name": "", "effect_id": "",
                "is_new": False, "path": "", "request_id": "",
                "resource_id": "", "resource_name": "", "source_platform": 0,
            },
            "check_flag": check_flag,
            "combo_info": {"text_templates": []},
            "content": json.dumps(content_obj, ensure_ascii=False),
            "fixed_height": -1.0,
            "fixed_width": -1.0,
            "font_category_id": "",
            "font_category_name": "",
            "font_id": self.font_id,
            "font_name": _font_name,
            "font_path": _SYS_FONT,
            "font_resource_id": self.font_id if self.font_id else "",
            "font_size": float(self.font_size),
            "font_source_platform": 0,
            "font_team_id": "",
            "font_title": _font_name or "none",
            "font_url": "",
            "fonts": fonts_list,
            "force_apply_line_max_width": False,
            "global_alpha": global_alpha,
            "group_id": "",
            "has_shadow": has_shadow,
            "id": mat_id,
            "initial_scale": 1.0,
            "inner_padding": -1.0,
            "is_rich_text": False,
            "italic_degree": 10 if self.is_italic else 0,
            "ktv_color": "",
            "language": "",
            "layer_weight": 1,
            "letter_spacing": self.letter_spacing,
            "line_feed": 1,
            "line_max_width": self.line_max_width,
            "line_spacing": self.line_spacing if self.line_spacing != 0.0 else 0.02,
            "multi_language_current": "none",
            "name": "",
            "original_size": [],
            "path": _font_file,
            "preset_category": "",
            "preset_category_id": "",
            "preset_has_set_alignment": False,
            "preset_id": "",
            "preset_index": 0,
            "preset_name": "",
            "recognize_task_id": "",
            "recognize_type": 0,
            "relevance_segment": [],
            "shadow_alpha": shadow_alpha_value,
            "shadow_angle": self.shadow_angle if has_shadow else 0.0,
            "shadow_color": self.shadow_color if has_shadow else "",
            "shadow_distance": self.shadow_dist if has_shadow else 0.0,
            "shadow_point": shadow_point if has_shadow else {"x": 0.0, "y": 0.0},
            "shadow_smoothing": shadow_smoothing_internal if has_shadow else 0.0,
            "shape_clip_x": False,
            "shape_clip_y": False,
            "source_from": "",
            "style_name": "",
            "sub_type": 0,
            "subtitle_keywords": None,
            "subtitle_template_original_fontsize": 0.0,
            "text_alpha": global_alpha,
            "text_color": self.text_color,
            "text_curve": {"angle": self.curve_angle, "enable": True} if self.curve_angle else None,
            "text_preset_resource_id": "",
            "text_size": int(round(self.font_size * 2)),
            "text_to_audio_ids": [],
            "tts_auto_update": False,
            "type": "subtitle",
            "typesetting": self.typesetting,
            "underline": self.is_underline,
            "underline_offset": 0.22,
            "underline_width": 0.05,
            "use_effect_default_color": True,
            "words": {"end_time": [], "start_time": [], "text": []},
        })
        
        # sticker_animation 必须始终是 extra_material_refs 的第一个引用（即使没有动画）
        anim_gid = self._export_animations_material(draft, target="text", force_create=True)
        extra_refs = [anim_gid]
        extra_refs.extend(bloom_effect_ids)
        if self.bubble_id: extra_refs.append(bid)
        if self.glow_id: extra_refs.append(gid)
        
        seg_json = self._export_common_segment(draft, mat_id, extra_refs)
        seg_json["source_timerange"] = None
        seg_json["hdr_settings"] = None
        seg_json["enable_adjust"] = False
        seg_json["enable_lut"] = False
        seg_json["clip"]["alpha"] = 1.0
        seg_json["text_params"] = text_params
        seg_json["render_index"] = 14000 + draft._text_render_index_counter
        draft._text_render_index_counter += 1
        return seg_json


class AudioClip(Segment):
    """
    音频片段对象
    
    支持功能:
    - 基础音量、淡入淡出调节
    - 降噪 (Denoise)
    - 响度统一 (Loudness)
    - 变声 (Tone Effect)
    - 人声美化 (Vocal Beautify)
    - 人声分离 (Vocal Separation)
    """
    def __init__(self, file_path, start=0, duration=None, source_start=0):
        """
        初始化音频片段
        
        参数:
            file_path (str): 音频文件路径。
            start (float/str): 在轨道上的开始时间。
            duration (float/str): 片段持续时间 (必填)。
            source_start (float/str): 源文件截取开始点。
        """
        super().__init__(duration)
        self.path = file_path
        self.start_time = start
        self.source_timerange = {"start": source_start, "duration": self.duration}
        self.fade_in = 0
        self.fade_out = 0
        self.volume_db = 0.0
        
        self.vocal_separation = None
        self.voice_effects = [] # 存储多个声音特效: {id, type}
        self.vocal_beautify = None # 补全：美化
        self.denoise = False
        self.loudness = 0.0 # 补全：响度
        self.change_pitch = False # 补全：变速变调

    def set_speed(self, speed, change_pitch=False):
        """
        设置播放速度
        
        参数:
            speed (float): 速度倍率 (0.1 ~ 100.0)
            change_pitch (bool): 是否变速变调 (True=变调, False=保持原调)
        """
        self.speed = speed
        self.change_pitch = change_pitch
        return self

    def set_volume(self, db):
        """设置音量 (dB), 范围 -60 ~ 20 (与剪映UI一致，步进0.1，单位dB)"""
        self.volume_db = db
        self.volume = db_to_linear(db)
        return self

    def set_fade(self, fade_in=0, fade_out=0):
        """设置淡入淡出时长（单位：微秒）"""
        self.fade_in = fade_in
        self.fade_out = fade_out
        return self
        
    def set_vocal_separation(self, mode=0):
        """0=原始, 1=背景, 2=人声"""
        self.vocal_separation = mode
        return self
        
    def set_denoise(self, enabled=True):
        """开启降噪"""
        self.denoise = enabled
        return self
        
    def set_tone_effect(self, resource_id):
        """
        [已过时] 设置变声特效
        建议使用 add_voice_effect(resource_id, type="tone")
        """
        return self.add_voice_effect(resource_id, "tone")
        
    def add_voice_effect(self, resource_id, type="tone", adjust_params=None):
        """
        添加声音特效 (支持叠加)
        
        参数:
            resource_id (str): 特效资源 ID
            type (str): 特效类型
                - "tone": 音色 (如萝莉、大叔)
                - "scene": 场景音 (如回音、录音棚)
                - "song": 声音成曲 (Speech to Song)
            adjust_params (list, optional): 特效参数调节列表。
                格式: [{"name": "参数名", "value": 50}] (value 范围 0~100，与剪映 UI 一致)
        """
        self.voice_effects.append({
            "id": resource_id, 
            "type": type,
            "params": adjust_params if adjust_params else []
        })
        return self
        
    def set_vocal_beautify(self, intensity=75):
        """设置人声美化强度 (0-100)"""
        self.vocal_beautify = intensity
        return self
        
    def set_loudness(self, target=-23.0):
        """设置响度统一目标 (LUFS), 常用值 -23.0"""
        self.loudness = target
        return self

    def export(self, draft):
        mat_id = generate_id()
        
        # Audio Fade (New Logic)
        extra_refs = []
        if self.fade_in > 0 or self.fade_out > 0:
            fade_id = generate_id()
            fade_obj = {
                "id": fade_id, "type": "audio_fade",
                "fade_in_duration": self.fade_in, "fade_out_duration": self.fade_out, "fade_type": 0
            }
            draft.register_material("audio_fades", fade_obj)
            extra_refs.append(fade_id)

        audio_mat = {
            "id": mat_id, "type": "extract_music", "path": self.path,
            "duration": self.duration // 1000,  # ⚠️ 音频材料的duration单位是毫秒(ms)，不是微秒！
            "name": os.path.basename(self.path), "category_name": "local"
        }
        # 移除内嵌 audio_fade
        draft.register_material("audios", audio_mat)
        
        speed_id = generate_id()
        draft.register_material("speeds", {"id": speed_id, "type": "speed", "speed": self.speed, "mode": 0})
        extra_refs.append(speed_id)
        
        sc_id = generate_id()
        draft.register_material("sound_channel_mappings", {"id": sc_id, "type": "none", "audio_channel_mapping": 0, "is_config_open": False})
        extra_refs.append(sc_id)
        
        vs_id = generate_id()
        choice = self.vocal_separation if self.vocal_separation is not None else 0
        draft.register_material("vocal_separations", {"id": vs_id, "type": "vocal_separation", "choice": choice, "production_path": ""})
        extra_refs.append(vs_id)
        
        if self.denoise:
            dn_id = generate_id()
            draft.register_material("realtime_denoises", {
                "id": dn_id, "is_denoise": True, "denoise_mode": 1.0, "denoise_rate": 0.85, "type": "realtime_denoise", "path": f"D:{dn_id}"
            })
            extra_refs.append(dn_id)
            
        if self.voice_effects:
            # 映射类型到 category_id 和 category_name
            TYPE_MAP = {
                "tone": {"cat_id": "tone", "cat_name": "音色"},
                "scene": {"cat_id": "sound_effect", "cat_name": "场景音"},
                "song": {"cat_id": "speech_to_song", "cat_name": "声音成曲"}
            }
            
            for effect in self.voice_effects:
                eff_id = generate_id()
                eff_type = effect["type"]
                meta = TYPE_MAP.get(eff_type, TYPE_MAP["tone"])
                
                internal_params = []
                for ap in effect["params"]:
                    internal_params.append({
                        "name": ap["name"],
                        "value": ap["value"] / 100.0
                    })
                draft.register_material("audio_effects", {
                    "id": eff_id,
                    "type": "audio_effect",
                    "category_id": meta["cat_id"],
                    "category_name": meta["cat_name"],
                    "resource_id": effect["id"],
                    "source_platform": 1, 
                    "value": 1.0, 
                    "apply_target_type": 0,
                    "audio_adjust_params": internal_params
                })
                extra_refs.append(eff_id)
            
        if self.vocal_beautify:
            vb_id = generate_id()
            draft.register_material("vocal_beautifys", {
                "id": vb_id, "enable": True, "ambient_sound_level": int(self.vocal_beautify), "time_range": {"duration": self.duration, "start": 0}, "type": "vocal_beautify"
            })
            extra_refs.append(vb_id)

        if self.loudness:
            ld_id = generate_id()
            draft.register_material("loudnesses", {
                "id": ld_id, "enable": True, "target_loudness": self.loudness, "time_range": {"duration": self.duration, "start": 0}
            })
            extra_refs.append(ld_id)

        seg_json = self._export_common_segment(draft, mat_id, extra_refs)
        if self.change_pitch: seg_json["is_tone_modify"] = True
        return seg_json


class EffectClip(Segment):
    """
    画面特效片段 (全局/调节层)
    
    通常放置在单独的特效轨道上，作用于其下方的视频层。

    附录：特效参数 Key 与 UI 名称对照表 (参考)
    ------------------------------------------------------------
    | Internal Key                        | UI 名称          |
    | :---                                | :---            |
    | effects_adjust_speed                | 速度            |
    | effects_adjust_filter               | 滤镜            |
    | effects_adjust_intensity            | 强度          |
    | effects_adjust_luminance            | 发光            |
    | effects_adjust_size                 | 大小            |
    | effects_adjust_horizontal_shift     | 水平位移         |
    | effects_adjust_vertical_shift       | 垂直位移         |
    | effects_adjust_color                | 颜色            |
    | effects_adjust_blur                 | 模糊            |
    | effects_adjust_range                | 范围            |
    | effects_adjust_rotate               | 旋转            |
    | effects_adjust_noise                | 噪点            |
    | effects_adjust_texture              | 纹理            |
    | effects_adjust_sharpen              | 锐化            |
    | effects_adjust_number               | 数量            |
    | effects_adjust_background_dimming   | 背景变暗         |
    | effects_adjust_soft                 | 柔光            |
    | effects_adjust_background_animation | 氛围            |
    | effects_adjust_distortion           | 扭曲            |
    | effects_adjust_horizontal_chromatic | 水平色差         |
    | effects_adjust_vertical_chromatic   | 垂直色差         |
    | sticker                             | 贴纸            |
    ------------------------------------------------------------
    """
    def __init__(self, resource_id, start=0, duration="3s", name="effect", type="video_effect", render_index=None):
        """
        参数:
            resource_id (str): 特效资源 ID。
            start (float/str): 开始时间。
            duration (float/str): 持续时间。
            name (str): 特效名称 (展示用)。
            type (str): 特效类型 ("video_effect" / "face_effect")。
            render_index (int): 渲染层级。
                - video_effect 默认 0
                - face_effect 通常也为 0 或 11000
                - 滤镜通常为 10000
        """
        super().__init__(duration)
        self.resource_id = resource_id
        self.start_time = start
        self.name = name
        self.effect_type = type
        self.render_index = render_index if render_index is not None else 0
        self.adjust_params = [] 
        
    def set_param(self, key, value):
        """
        设置特效的具体参数
        
        参数:
            key (str): 参数内部 Key (如 "effects_adjust_speed")。可参考类文档中的对照表。
            value (int/float): 参数值 (UI值 0-100)
        """
        # 注意: 特效参数的转换比较复杂，取决于具体的特效元数据
        # 这里暂时假设外部传入的是已经处理好的值，或者需要在这里做转换
        # 为了简化，我们假设用户传入 UI 值，但这里直接存入 value
        # 实际情况可能需要 _convert_effect_param_ui_to_internal
        # 鉴于 DraftOOP 是简化版，我们这里不做自动转换，让用户传原始值或者后续再完善
        self.adjust_params.append({"name": key, "value": value})
        return self
        
    def export(self, draft):
        mat_id = generate_id()
        
        # 加载元数据以支持精确转换和参数补全
        meta_cache = load_effect_meta()
        # meta_cache 结构: {resource_id: {"effect_id":..., "name":..., "params": {key: {min, max, default}}}}
        effect_info = meta_cache.get(self.resource_id)
        
        final_params = []
        user_param_keys = set()
        
        # 1. 处理用户显式设置的参数
        for p in self.adjust_params:
            key = p["name"]
            ui_value = p["value"]
            user_param_keys.add(key)
            
            internal_val = 0.0
            
            # 查找参数定义
            if effect_info and key in effect_info["params"]:
                pm = effect_info["params"][key]
                min_v = pm["min"]
                max_v = pm["max"]
                # 公式: internal = min + (ui / 100) * (max - min)
                internal_val = min_v + (ui_value / 100.0) * (max_v - min_v)
            else:
                # 回退默认逻辑: 假设是 0-1
                internal_val = ui_value / 100.0
                
            final_params.append({
                "name": key,
                "value": internal_val
            })
            
        # 2. 补全未设置的参数 (使用元数据中的默认值)
        if effect_info:
            for key, pm in effect_info["params"].items():
                if key not in user_param_keys:
                    final_params.append({
                        "name": key,
                        "value": pm["default"] # 使用默认内部值
                    })
        
        # 3. 确定 Effect ID 和 Name
        # 优先使用索引中的 effect_id；拿不到时再回退到 resource_id。
        effect_id = effect_info["effect_id"] if effect_info else self.resource_id
        effect_name = self.name if self.name and self.name != "effect" else (effect_info["name"] if effect_info else self.name)
        
        draft.register_material("video_effects", {
            "id": mat_id, "type": self.effect_type,
            "effect_id": effect_id,
            "resource_id": self.resource_id,
            "path": f"D:{self.resource_id}", 
            "name": effect_name,
            "adjust_params": final_params, 
            "apply_target_type": 2,
            "value": 1.0, 
            "render_index": 11000 if self.render_index == 0 else self.render_index
        })
        seg_json = self._export_common_segment(draft, mat_id, [])
        seg_json["source_timerange"] = None
        seg_json["render_index"] = 11000 if self.render_index == 0 else self.render_index
        return seg_json


class FilterClip(Segment):
    """
    滤镜片段
    
    通常放置在单独的滤镜轨道上。
    """
    def __init__(self, resource_id, start=0, duration="3s", intensity=80, name="filter"):
        """
        参数:
            resource_id (str): 滤镜资源 ID。
            start (float/str): 开始时间。
            duration (float/str): 持续时间。
            intensity (int): 滤镜强度 (0-100)。
        """
        super().__init__(duration)
        self.resource_id = resource_id
        self.start_time = start
        self.intensity = intensity  # UI值 0-100
        self.name = name
        
    def export(self, draft):
        mat_id = generate_id()
        draft.register_material("effects", {
            "id": mat_id, "type": "filter",
            "effect_id": self.resource_id, "resource_id": self.resource_id,
            "name": self.name,
            "adjust_params": [], "apply_target_type": 0,
            "value": self.intensity / 100.0, # 转换 UI 值 -> 内部值
            "category_id": "", "category_name": "",
            "source_platform": 1
        })
        seg_json = self._export_common_segment(draft, mat_id, [])
        seg_json["source_timerange"] = None
        seg_json["render_index"] = 10000
        return seg_json

# ==============================================================================
# 4. 轨道与草稿类
# ==============================================================================

class Track:
    """
    轨道对象 (Track)
    
    管理一组 Segment。
    """
    def __init__(self, track_type="video"):
        """
        参数:
            track_type (str): 轨道类型 ("video", "audio", "text", "effect", "filter")
        """
        self.id = generate_id()
        self.type = track_type
        self.segments = [] 
        
    def add(self, clip: Segment):
        """添加片段到轨道末尾"""
        self.segments.append(clip)
        return clip

    def export(self, draft):
        current_time = 0
        segment_jsons = []
        for seg in self.segments:
            if hasattr(seg, 'custom_start_time') and seg.custom_start_time is not None:
                seg.start_time = seg.custom_start_time
                if self.type == "video":
                    current_time = seg.start_time + seg.duration
            elif self.type == "video":
                # 默认行为：紧接上一个片段
                seg.start_time = current_time
                current_time += seg.duration
            segment_jsons.append(seg.export(draft))
        flag = 1 if self.type == "audio" else 0
        return {
            "attribute": 0, "flag": flag, "id": self.id,
            "segments": segment_jsons, "type": self.type,
        }

class JianYingDraft:
    """
    剪映草稿生成器 (主入口)
    """
    def __init__(self, width=1920, height=1080, ratio="original"):
        """
        参数:
            width (int): 画布宽度
            height (int): 画布高度
            ratio (str): 画布比例，如 "16:9", "9:16", "original"
        """
        self.project_id = generate_id()
        self.width = width
        self.height = height
        self.ratio = ratio
        self.draft_folder = None
        self.tracks = []
        self._text_render_index_counter = 0
        self.materials = {
            "ai_translates": [], "audio_balances": [], "audio_effects": [],
            "audio_fades": [], "audio_track_indexes": [], "audios": [],
            "beats": [], "canvases": [], "chromas": [], "color_curves": [],
            "digital_humans": [], "drafts": [], "effects": [], "flowers": [],
            "green_screens": [], "handwrites": [], "hsl": [], "images": [],
            "log_color_wheels": [], "loudnesses": [], "manual_deformations": [],
            "masks": [], "material_animations": [], "material_colors": [],
            "multi_language_refs": [], "placeholders": [], "plugin_effects": [],
            "primary_color_wheels": [], "realtime_denoises": [], "shapes": [],
            "smart_crops": [], "smart_relights": [], "sound_channel_mappings": [],
            "speeds": [], "stickers": [], "tail_leaders": [], "text_templates": [],
            "texts": [], "time_marks": [], "transitions": [], "video_effects": [],
            "video_trackings": [], "videos": [], "vocal_beautifys": [],
            "vocal_separations": [],
        }
        
    def set_canvas_ratio(self, ratio_mode):
        """
        设置画布比例，并自动调整宽高 (基于 1080p 基准)
        
        参数:
            ratio_mode (str): 与剪映 UI 面板一致
                - "16:9"   (1920x1080) 横屏标准
                - "9:16"   (1080x1920) 竖屏/抖音
                - "1:1"    (1080x1080) 正方形
                - "4:3"    (1440x1080) 传统电视
                - "3:4"    (1080x1440) 竖版 4:3
                - "2:1"    (2160x1080) 超宽屏
                - "2.35:1" (2538x1080) 电影宽银幕
                - "1.85:1" (1998x1080) 电影标准
                - "original" (保持当前宽高)
        """
        RATIO_MAP = {
            "16:9":   (1920, 1080),
            "9:16":   (1080, 1920),
            "1:1":    (1080, 1080),
            "4:3":    (1440, 1080),
            "3:4":    (1080, 1440),
            "2:1":    (2160, 1080),
            "2.35:1": (2538, 1080),
            "1.85:1": (1998, 1080),
        }
        if ratio_mode in RATIO_MAP:
            self.width, self.height = RATIO_MAP[ratio_mode]
        self.ratio = "original"
        return self

    def add_track(self, track_type="video"):
        """创建并添加一条新轨道"""
        t = Track(track_type)
        self.tracks.append(t)
        return t
        
    def register_material(self, type_name, data):
        """(内部使用) 注册素材到全局字典"""
        if type_name not in self.materials: self.materials[type_name] = []
        self.materials[type_name].append(data)
    
    def add_srt(self, srt_content, font_style=None, target_track=None, rich_styles=None):
        """
        导入 SRT 字幕
        
        解析 SRT 内容并批量生成 TextClip。
        
        参数:
            srt_content (str): SRT 格式文本内容
            font_style (dict): 应用到所有字幕的基础样式字典，如 {"size": 20, "color": "#FF0000", "x": 0, "y": -300}
            target_track (Track): [可选] 指定目标轨道对象。如果不填，则自动创建新轨道。
            rich_styles (dict): [可选] 富文本样式表，如 {"red": {"color": "#FF0000"}}
        """
        if not srt_content: return
        t_track = target_track if target_track else self.add_track("text")
        blocks = re.split(r'\n\s*\n', srt_content.strip())
        for block in blocks:
            lines = [l.strip() for l in block.split('\n') if l.strip()]
            if len(lines) < 2: continue
            time_line = ""
            text_lines = []
            for i, line in enumerate(lines):
                if "-->" in line:
                    time_line = line
                    if i + 1 < len(lines): text_lines = lines[i+1:]
                    break
            if time_line and text_lines:
                match = re.search(r'(\d{2}:\d{2}:\d{2}[,.]\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2}[,.]\d{3})', time_line)
                if match:
                    start_us = _srt_time_to_us(match.group(1))
                    end_us = _srt_time_to_us(match.group(2))
                    clip = TextClip("\n".join(text_lines), duration=0)
                    clip.start_time = start_us
                    clip.duration = end_us - start_us
                    
                    # 应用基础样式
                    if font_style:
                        # 提取 transform 属性
                        trans_keys = ["x", "y", "scale", "rotation", "alpha", "uniform_scale", "scale_x", "scale_y"]
                        t_kwargs = {k: font_style[k] for k in trans_keys if k in font_style}
                        if t_kwargs: clip.set_transform(**t_kwargs)
                        
                        # 应用文本样式
                        clip.set_style(**{k:v for k,v in font_style.items() if k not in trans_keys})
                    
                    # 应用富文本样式
                    if rich_styles:
                        for tag, style in rich_styles.items():
                            clip.add_rich_style(tag, **style)
                            
                    t_track.add(clip)

    def save(self, draft_folder, draft_name=None):
        """
        保存草稿到指定文件夹，生成剪映能识别的完整草稿目录结构。
        
        参数:
            draft_folder: 草稿文件夹路径（会自动创建）
            draft_name: 草稿名称（可选，默认用文件夹名）
        
        兼容性:
            如果传入的路径以 .json 结尾，自动取其所在目录作为 draft_folder
        """
        import copy
        import time

        if draft_folder.endswith(".json"):
            draft_folder = os.path.dirname(draft_folder)

        draft_folder = os.path.abspath(draft_folder)
        os.makedirs(draft_folder, exist_ok=True)
        self.draft_folder = draft_folder

        if not draft_name:
            draft_name = os.path.basename(draft_folder) or "Untitled"

        track_data = [t.export(self) for t in self.tracks]
        existing_types = {t.type for t in self.tracks}
        for default_type in ["video", "audio"]:
            if default_type not in existing_types:
                dummy = Track(default_type)
                track_data.insert(0, dummy.export(self))

        duration = 0
        for t in self.tracks:
            if t.segments:
                last = t.segments[-1]
                end = last.start_time + last.duration
                if end > duration: duration = end

        materials_data = copy.deepcopy(self.materials)

        draft_content = {
            "canvas_config": {"width": self.width, "height": self.height, "ratio": self.ratio},
            "color_space": 0,
            "config": {
                "adjust_max_index": 1,
                "attachment_info": [],
                "combination_max_index": 1,
                "export_range": None,
                "extract_audio_last_index": 1,
                "lyrics_recognition_id": "",
                "lyrics_sync": True,
                "lyrics_taskinfo": [],
                "maintrack_adsorb": True,
                "material_save_mode": 0,
                "multi_language_current": "none",
                "multi_language_list": [],
                "multi_language_main": "none",
                "multi_language_mode": "none",
                "original_sound_last_index": 1,
                "record_audio_last_index": 1,
                "sticker_max_index": 1,
                "subtitle_keywords_config": None,
                "subtitle_recognition_id": "",
                "subtitle_sync": True,
                "subtitle_taskinfo": [],
                "system_font_list": [],
                "video_mute": False,
                "zoom_info_params": None,
            },
            "cover": None,
            "create_time": 0,
            "duration": duration,
            "extra_info": None,
            "fps": 30.0,
            "free_render_index_mode_on": False,
            "group_container": None,
            "id": self.project_id,
            "keyframe_graph_list": [],
            "keyframes": {
                "adjusts": [], "audios": [], "effects": [], "filters": [],
                "handwrites": [], "stickers": [], "texts": [], "videos": [],
            },
            "materials": materials_data,
            "mutable_config": None,
            "name": "",
            "new_version": "110.0.0",
            "platform": {
                "app_id": 3704, "app_source": "lv", "app_version": "5.9.0",
                "device_id": "", "hard_disk_id": "", "mac_address": "",
                "os": "mac", "os_version": "14.0",
            },
            "last_modified_platform": {
                "app_id": 3704, "app_source": "lv", "app_version": "5.9.0",
                "device_id": "", "hard_disk_id": "", "mac_address": "",
                "os": "mac", "os_version": "14.0",
            },
            "relationships": [],
            "render_index_track_mode_on": True,
            "retouch_cover": None,
            "source": "default",
            "static_cover_image_path": "",
            "tracks": track_data,
            "update_time": 0,
            "version": 360000,
        }

        content_path = os.path.join(draft_folder, "draft_content.json")
        content_str = json.dumps(draft_content, ensure_ascii=False)
        with open(content_path, "w", encoding="utf-8") as f:
            f.write(content_str)
        with open(os.path.join(draft_folder, "draft_info.json"), "w", encoding="utf-8") as f:
            f.write(content_str)
        content_size = len(content_str.encode("utf-8"))

        template_content = dict(draft_content)
        template_content["tracks"] = []
        template_content["duration"] = 0
        template_path = os.path.join(draft_folder, "template.tmp")
        with open(template_path, "w", encoding="utf-8") as f:
            json.dump(template_content, f, ensure_ascii=False)

        now_us = int(time.time() * 1_000_000)
        draft_root_path = os.path.dirname(draft_folder)

        meta_info = {
            "draft_cloud_last_action_download": False,
            "draft_cloud_purchase_info": "",
            "draft_cloud_template_id": "",
            "draft_cloud_tutorial_info": "",
            "draft_cloud_videocut_purchase_info": "",
            "draft_cover": "",
            "draft_deeplink_url": "",
            "draft_enterprise_info": {
                "draft_enterprise_extra": "",
                "draft_enterprise_id": "",
                "draft_enterprise_name": "",
            },
            "draft_fold_path": draft_folder,
            "draft_id": self.project_id,
            "draft_is_article_video_draft": False,
            "draft_is_from_deeplink": "false",
            "draft_is_invisible": False,
            "draft_materials": [
                {"type": 0, "value": []},
                {"type": 1, "value": []},
                {"type": 2, "value": []},
                {"type": 3, "value": []},
                {"type": 6, "value": []},
                {"type": 7, "value": []},
                {"type": 8, "value": []},
            ],
            "draft_materials_copied_info": [],
            "draft_name": draft_name,
            "draft_removable_storage_device": "",
            "draft_root_path": draft_root_path,
            "draft_segment_extra_info": [],
            "draft_timeline_materials_size_": content_size,
            "tm_draft_cloud_completed": "",
            "tm_draft_cloud_modified": 0,
            "tm_draft_create": now_us,
            "tm_draft_modified": now_us,
            "tm_duration": int(duration),
        }
        meta_path = os.path.join(draft_folder, "draft_meta_info.json")
        with open(meta_path, "w", encoding="utf-8") as f:
            json.dump(meta_info, f, ensure_ascii=False)

        pc_common = {
            "pc_feature_flag": 0,
            "template_item_infos": [],
            "unlock_template_ids": [],
        }
        with open(os.path.join(draft_folder, "attachment_pc_common.json"), "w") as f:
            json.dump(pc_common, f)

        agency_config = {
            "marterials": None,
            "use_converter": False,
            "video_resolution": 720,
        }
        with open(os.path.join(draft_folder, "draft_agency_config.json"), "w") as f:
            json.dump(agency_config, f)

        # ── 打包 bloom effect 素材到草稿目录，并更新 path 为当前草稿内部路径 ──
        # 注意：同一个 Draft 对象可能会被保存到多个目录（沙盒 / 非沙盒），
        # 所以这里必须基于当前 draft_folder 重新计算 path，不能复用上一次保存结果。
        # 同时把 bundled_effects 整包复制进去，避免只带单个 effect 导致依赖缺失。
        import shutil
        script_dir = os.path.dirname(os.path.abspath(__file__))
        candidate_roots = [
            os.path.join(script_dir, "jyxzs", "src-tauri", "resources", "bundled_effects"),
            os.path.join(os.path.dirname(script_dir), "jyxzs", "src-tauri", "resources", "bundled_effects"),
            os.path.join(script_dir, "bundled_effects"),
            os.path.join(os.path.dirname(script_dir), "bundled_effects"),
            os.path.join(os.path.dirname(os.path.dirname(script_dir)), "bundled_effects"),
        ]
        bundled_root = next((p for p in candidate_roots if os.path.isdir(p)), "")
        bloom_effects = [e for e in materials_data.get("effects", []) if e.get("type") == "bloom"]
        if bloom_effects and bundled_root:
            effects_root = os.path.join(draft_folder, "effects")
            os.makedirs(effects_root, exist_ok=True)

            for bundled_entry in os.listdir(bundled_root):
                src_dir = os.path.join(bundled_root, bundled_entry)
                dst_dir = os.path.join(effects_root, bundled_entry)
                if os.path.isdir(src_dir):
                    shutil.copytree(src_dir, dst_dir, dirs_exist_ok=True)

            for effect in bloom_effects:
                effect_id = effect.get("effect_id", "")
                if not effect_id:
                    continue
                current_path = effect.get("path", "")
                hash_name = os.path.basename(current_path.rstrip("/")) if current_path else ""
                bundled_effect_dir = os.path.join(effects_root, effect_id)
                if not hash_name and os.path.isdir(bundled_effect_dir):
                    child_dirs = [
                        name for name in os.listdir(bundled_effect_dir)
                        if os.path.isdir(os.path.join(bundled_effect_dir, name))
                    ]
                    if len(child_dirs) == 1:
                        hash_name = child_dirs[0]
                    else:
                        known_hash = {
                            "9762443": "0522a4e9dde8572d591ef622ec99fded",
                            "9762325": "5e73b9655ea23c6ea73a491b59567c8e",
                        }.get(effect_id, "")
                        if known_hash and known_hash in child_dirs:
                            hash_name = known_hash
                if hash_name:
                    effect["path"] = os.path.join(bundled_effect_dir, hash_name)

            content_str = json.dumps(draft_content, ensure_ascii=False)
            with open(content_path, "w", encoding="utf-8") as f:
                f.write(content_str)
            with open(os.path.join(draft_folder, "draft_info.json"), "w", encoding="utf-8") as f:
                f.write(content_str)

# ==============================================================================
# 5. 快速示例（python3 jianying_draft_oop.py 直接运行）
# ==============================================================================

if __name__ == "__main__":
    import os

    # 自动检测剪映草稿目录（兼容沙盒和非沙盒路径）
    _sandbox = os.path.expanduser(
        "~/Library/Containers/com.lemon.lvpro/Data/Movies/JianyingPro"
        "/User Data/Projects/com.lveditor.draft"
    )
    _normal  = os.path.expanduser(
        "~/Movies/JianyingPro/User Data/Projects/com.lveditor.draft"
    )
    DRAFT_ROOT = _sandbox if os.path.isdir(_sandbox) else _normal

    draft = JianYingDraft(width=1080, height=1920, ratio="9:16")

    # 文字轨道示例
    t_track = draft.add_track("text")

    t1 = TextClip("Hello <red>World</red>", start="0s", duration="3s")
    t1.font_size = 20
    t1.set_style(color="#FFFFFF", bold=True)
    t1.add_rich_style("red", color="#FF4444", size=28)
    t1.set_bloom(strength=80, range_val=60, color="#FF4444", bloom_type="外发光")
    t_track.add(t1)

    out = os.path.join(DRAFT_ROOT, "OOP示例草稿")
    os.makedirs(out, exist_ok=True)
    draft.save(out, "OOP示例草稿")
    print(f"草稿已生成: {out}")
