import base64
import copy
import dataclasses
import json
from collections.abc import AsyncIterator
from typing import Any

import marshmallow_recipe as mr
from google import genai
from google.genai import types as genai_types
from google.oauth2 import service_account

from ..blocks import AssistantBlock, ImageBlock, TextBlock, ThinkingBlock, ToolResultBlock, ToolUseBlock
from ..messages import AssistantMessage, Message, SystemMessage, UserMessage
from ..pricing import google as google_pricing
from ..provider import LLMProvider
from ..request import LLMRequest
from ..response import LLMResponse, StopReason, Usage
from ..schema_formatting import format_output_schema_for_description
from ..stream import ContentComplete, StreamEvent, TextDelta, ThinkingDelta
from ..tools import Tool

__all__ = [
    "GoogleVertexAdditionalConfig",
    "GoogleVertexProvider",
]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class GoogleVertexAdditionalConfig:
    thinking_level: genai_types.ThinkingLevel | None = None
    thinking_budget: int | None = None


class GoogleVertexProvider(LLMProvider):
    __slots__ = ("__client", "__owns_client")

    def __init__(
        self,
        *,
        client: genai.Client | None = None,
        project: str | None = None,
        location: str | None = None,
        credentials: str | None = None,
        owns_client: bool = False,
    ) -> None:
        if client is not None:
            self.__client = client
            self.__owns_client = owns_client
        elif project and location and credentials:
            self.__client = self.__create_client(project=project, location=location, credentials=credentials)
            self.__owns_client = True
        else:
            raise ValueError("Either 'client' or all of 'project', 'location', 'credentials' must be provided")

    async def aclose(self) -> None:
        if self.__owns_client:
            self.__client.close()

    @staticmethod
    def __create_client(*, project: str, location: str, credentials: str) -> genai.Client:
        creds_json = base64.b64decode(credentials.encode()).decode()
        creds_info = json.loads(creds_json)
        google_creds = service_account.Credentials.from_service_account_info(creds_info)
        google_creds = google_creds.with_scopes(["https://www.googleapis.com/auth/cloud-platform"])
        return genai.Client(vertexai=True, project=project, location=location, credentials=google_creds)

    async def call(self, request: LLMRequest) -> LLMResponse:
        return await self.__call_llm(request)

    async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
        config = self.__build_config(request)
        _, messages = self.__extract_system(request.messages)

        contents: list[genai_types.ContentUnion] = []
        for message in messages:
            contents.extend(self.__convert_message(message, request.messages))

        # Accumulate parts for final response assembly
        all_parts: list[genai_types.Part] = []
        has_function_call = False
        last_chunk: genai_types.GenerateContentResponse | None = None

        async for chunk in await self.__client.aio.models.generate_content_stream(
            model=request.model,
            contents=contents,
            config=config,
        ):
            last_chunk = chunk
            if chunk.candidates and chunk.candidates[0].content and chunk.candidates[0].content.parts:
                for part in chunk.candidates[0].content.parts:
                    all_parts.append(part)
                    if part.thought:
                        if part.text:
                            yield ThinkingDelta(text=part.text)
                    elif part.text is not None:
                        yield TextDelta(text=part.text)
                    elif part.function_call:
                        has_function_call = True

        # Assemble final response from accumulated parts
        blocks: list[AssistantBlock] = []
        for part in all_parts:
            extra = self.__extract_thought_signature(part)
            if part.thought:
                if part.text:
                    blocks.append(ThinkingBlock(text=part.text, extra=extra))
                continue
            if part.text is not None:
                blocks.append(TextBlock(text=part.text, extra=extra))
            elif part.function_call:
                fc = part.function_call
                blocks.append(
                    ToolUseBlock(
                        id=f"call_{fc.name}_{id(fc)}",
                        name=fc.name or "",
                        input=dict(fc.args) if fc.args else {},
                        extra=extra,
                    )
                )

        stop_reason = StopReason.TOOL_USE if has_function_call else StopReason.END_TURN
        usage = (
            self.__convert_usage(last_chunk.usage_metadata, request.model)
            if last_chunk is not None and last_chunk.usage_metadata
            else None
        )

        yield ContentComplete(
            response=LLMResponse(
                message=AssistantMessage(blocks=blocks),
                stop_reason=stop_reason,
                usage=usage,
            )
        )

    def __build_config(self, request: LLMRequest) -> genai_types.GenerateContentConfig:
        system_instruction, _ = self.__extract_system(request.messages)

        config_kwargs: dict[str, Any] = {
            "max_output_tokens": request.max_tokens or 4096,
        }

        if system_instruction:
            config_kwargs["system_instruction"] = system_instruction

        if request.temperature is not None:
            config_kwargs["temperature"] = request.temperature

        if request.stop_sequences:
            config_kwargs["stop_sequences"] = request.stop_sequences

        if request.tools:
            config_kwargs["tools"] = [
                genai_types.Tool(function_declarations=[self.__convert_tool(tool) for tool in request.tools])
            ]

        if request.json_schema:
            adapted = self.__adapt_schema_for_gemini(request.json_schema)
            config_kwargs["response_schema"] = adapted
            config_kwargs["response_mime_type"] = "application/json"

        if request.additional_config:
            additional = mr.load(GoogleVertexAdditionalConfig, request.additional_config)
            if additional.thinking_level or additional.thinking_budget is not None:
                thinking_kwargs: dict[str, Any] = {"include_thoughts": True}
                if additional.thinking_level:
                    thinking_kwargs["thinking_level"] = additional.thinking_level
                if additional.thinking_budget is not None:
                    thinking_kwargs["thinking_budget"] = additional.thinking_budget
                config_kwargs["thinking_config"] = genai_types.ThinkingConfig(**thinking_kwargs)

        return genai_types.GenerateContentConfig(**config_kwargs)

    async def __call_llm(self, request: LLMRequest) -> LLMResponse:
        _, messages = self.__extract_system(request.messages)

        contents: list[genai_types.ContentUnion] = []
        for message in messages:
            contents.extend(self.__convert_message(message, request.messages))

        config = self.__build_config(request)

        response = await self.__client.aio.models.generate_content(
            model=request.model,
            contents=contents,
            config=config,
        )
        return self.__convert_response(response, request.stop_sequences, request.model)

    @staticmethod
    def __extract_system(messages: list[Message]) -> tuple[str | None, list[Message]]:
        system_texts: list[str] = []
        rest_start = 0

        for msg in messages:
            if not isinstance(msg, SystemMessage):
                break
            system_texts.extend(b.text for b in msg.blocks)
            rest_start += 1

        if not system_texts:
            return None, messages

        return "\n\n".join(system_texts), messages[rest_start:]

    @classmethod
    def __convert_message(
        cls,
        message: Message,
        all_messages: list[Message],
    ) -> list[genai_types.Content]:
        match message:
            case SystemMessage():
                raise ValueError("SystemMessage must be at the beginning of messages list")

            case UserMessage(blocks=blocks):
                parts: list[genai_types.Part] = []
                for block in blocks:
                    match block:
                        case TextBlock(text=text):
                            parts.append(genai_types.Part(text=text))
                        case ImageBlock(data=data, media_type=media_type):
                            parts.append(
                                genai_types.Part(
                                    inline_data=genai_types.Blob(mime_type=media_type, data=data),
                                )
                            )
                        case ToolResultBlock(tool_use_id=tool_use_id, content=content):
                            tool_name = cls.__find_tool_name(all_messages, tool_use_id)
                            response_data: dict[str, Any] = {"result": content}
                            parts.append(
                                genai_types.Part(
                                    function_response=genai_types.FunctionResponse(
                                        name=tool_name,
                                        response=response_data,
                                    ),
                                )
                            )
                return [genai_types.Content(role="user", parts=parts)]

            case AssistantMessage(blocks=blocks):
                parts = []
                for block in blocks:
                    sig = cls.__decode_thought_signature(block.extra)
                    match block:
                        case ThinkingBlock(text=text):
                            parts.append(genai_types.Part(text=text, thought=True, thought_signature=sig))
                        case TextBlock(text=text):
                            parts.append(genai_types.Part(text=text, thought_signature=sig))
                        case ToolUseBlock(name=name, input=input_):
                            parts.append(
                                genai_types.Part(
                                    function_call=genai_types.FunctionCall(name=name, args=input_),
                                    thought_signature=sig,
                                )
                            )
                return [genai_types.Content(role="model", parts=parts)]

    @staticmethod
    def __extract_thought_signature(part: genai_types.Part) -> dict[str, Any]:
        if part.thought_signature is not None:
            return {"thought_signature": base64.b64encode(part.thought_signature).decode()}
        return {}

    @staticmethod
    def __decode_thought_signature(extra: dict[str, Any]) -> bytes | None:
        sig = extra.get("thought_signature")
        return base64.b64decode(sig) if sig is not None else None

    @staticmethod
    def __find_tool_name(all_messages: list[Message], tool_use_id: str) -> str:
        for msg in all_messages:
            if isinstance(msg, AssistantMessage):
                for block in msg.blocks:
                    if isinstance(block, ToolUseBlock) and block.id == tool_use_id:
                        return block.name
        return "unknown"

    @classmethod
    def __convert_tool(cls, tool: Tool) -> genai_types.FunctionDeclaration:
        description = tool.description
        if tool.output_schema:
            description += format_output_schema_for_description(tool.output_schema)

        params = (
            cls.__adapt_schema_for_gemini(tool.input_schema)
            if tool.input_schema
            else {"type": "object", "properties": {}}
        )
        return genai_types.FunctionDeclaration(
            name=tool.name,
            description=description,
            parameters_json_schema=params,
        )

    @classmethod
    def __convert_response(
        cls,
        response: genai_types.GenerateContentResponse,
        stop_sequences: list[str] | None,
        model: str,
    ) -> LLMResponse:
        blocks: list[AssistantBlock] = []
        has_function_call = False

        if response.candidates:
            candidate = response.candidates[0]
            if candidate.content and candidate.content.parts:
                for part in candidate.content.parts:
                    extra = cls.__extract_thought_signature(part)
                    if part.thought:
                        if part.text:
                            blocks.append(ThinkingBlock(text=part.text, extra=extra))
                        continue
                    if part.text is not None:
                        blocks.append(TextBlock(text=part.text, extra=extra))
                    elif part.function_call:
                        has_function_call = True
                        fc = part.function_call
                        blocks.append(
                            ToolUseBlock(
                                id=f"call_{fc.name}_{id(fc)}",
                                name=fc.name or "",
                                input=dict(fc.args) if fc.args else {},
                                extra=extra,
                            )
                        )

        stop_reason = cls.__convert_stop_reason(response, has_function_call, stop_sequences)
        stop_sequence = cls.__extract_stop_sequence(response, stop_sequences)

        usage = cls.__convert_usage(response.usage_metadata, model) if response.usage_metadata else None

        provider_stop_reason = None
        if response.candidates:
            provider_stop_reason = response.candidates[0].finish_reason

        return LLMResponse(
            message=AssistantMessage(blocks=blocks),
            stop_reason=stop_reason,
            stop_sequence=stop_sequence,
            usage=usage,
            extra={"provider_stop_reason": provider_stop_reason},
        )

    @staticmethod
    def __convert_stop_reason(
        response: genai_types.GenerateContentResponse,
        has_function_call: bool,
        stop_sequences: list[str] | None,
    ) -> StopReason:
        if has_function_call:
            return StopReason.TOOL_USE

        if not response.candidates:
            return StopReason.OTHER

        candidate = response.candidates[0]
        finish_reason = candidate.finish_reason

        match finish_reason:
            case "STOP":
                # Check if stopped due to stop_sequence
                if stop_sequences and candidate.content and candidate.content.parts:
                    text = "".join(p.text for p in candidate.content.parts if p.text)
                    if any(text.endswith(seq) for seq in stop_sequences):
                        return StopReason.STOP_SEQUENCE
                return StopReason.END_TURN
            case "MAX_TOKENS":
                return StopReason.MAX_TOKENS
            case _:
                return StopReason.OTHER

    @staticmethod
    def __extract_stop_sequence(
        response: genai_types.GenerateContentResponse,
        stop_sequences: list[str] | None,
    ) -> str | None:
        if not stop_sequences or not response.candidates:
            return None
        candidate = response.candidates[0]
        if candidate.content and candidate.content.parts:
            text = "".join(p.text for p in candidate.content.parts if p.text)
            for seq in stop_sequences:
                if text.endswith(seq):
                    return seq
        return None

    @staticmethod
    def __convert_usage(um: genai_types.GenerateContentResponseUsageMetadata, model: str) -> Usage:
        cache_read = um.cached_content_token_count or 0
        input_tokens = max(0, (um.prompt_token_count or 0) - cache_read)
        output_tokens = um.candidates_token_count or 0

        extra: dict[str, Any] = {}
        if um.thoughts_token_count:
            extra["thoughts_tokens"] = um.thoughts_token_count

        cost = google_pricing.estimate_cost(
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_read_tokens=cache_read,
        )
        return Usage(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_read_input_tokens=cache_read,
            cost_usd=cost.total if cost is not None else None,
            cost=cost,
            extra=extra,
        )

    @classmethod
    def __adapt_schema_for_gemini(cls, schema: dict[str, Any]) -> dict[str, Any]:
        """Adapt JSON schema for Gemini's native structured output.

        Gemini requires:
        - No $ref/$defs (must be flattened inline)
        - No additionalProperties
        - Type arrays converted to anyOf format
        """
        schema = copy.deepcopy(schema)
        defs = schema.pop("$defs", {})
        if defs:
            schema = cls.__flatten_refs(schema, defs)
        return cls.__process_schema_node(schema)

    @classmethod
    def __flatten_refs(cls, node: Any, defs: dict[str, Any]) -> Any:
        if not isinstance(node, dict):
            return node

        if "$ref" in node:
            ref_path = node["$ref"]
            if ref_path.startswith("#/$defs/"):
                def_name = ref_path.split("/")[-1]
                if def_name in defs:
                    return cls.__flatten_refs(copy.deepcopy(defs[def_name]), defs)
            return node

        result: dict[str, Any] = {}
        for key, value in node.items():
            if isinstance(value, dict):
                result[key] = cls.__flatten_refs(value, defs)
            elif isinstance(value, list):
                result[key] = [cls.__flatten_refs(item, defs) if isinstance(item, dict) else item for item in value]
            else:
                result[key] = value
        return result

    @classmethod
    def __process_schema_node(cls, node: Any) -> Any:
        if not isinstance(node, dict):
            return node

        result: dict[str, Any] = {}
        for key, value in node.items():
            if key == "type" and isinstance(value, list):
                result["anyOf"] = [{"type": t} for t in value]
                continue
            if key in ("additionalProperties", "$schema"):
                continue
            if isinstance(value, dict):
                result[key] = cls.__process_schema_node(value)
            elif isinstance(value, list):
                result[key] = [cls.__process_schema_node(item) if isinstance(item, dict) else item for item in value]
            else:
                result[key] = value
        return result
