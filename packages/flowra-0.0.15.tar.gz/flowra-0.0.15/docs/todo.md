# TODO

## State

- **Lazy fork / copy-on-write scope.** Currently `RuntimeScope.fork()` copies all scalars
  and append-only lists eagerly. For large state this is expensive. Make it lazy: child
  reads from parent until first write, copies only the specific field on `set()`/`append()`.
  User contract stays the same — child sees a snapshot of parent state at spawn time,
  but the implementation avoids upfront copying.
- **Frozen list.** Immutable list in state (like Scalar, but for lists). Can be created
  cheaply from `append_only` (slice without copying) or from another frozen list. Useful
  when a child agent needs a snapshot of the parent's list.


## Hooks

- **Guardrails hooks package.** Ready-made hook set for content filtering and PII protection.
  Input guardrail (`UserMessageEvent`) checks/blocks user messages, output guardrail
  (`ResultMessageEvent`) checks/redacts LLM responses. Hooks support modification —
  e.g. replace `messages` in `UserMessageEvent`, replace `result` in `AfterToolCallEvent`.
  Need integration with a moderation backend (Bedrock Guardrails, OpenAI Moderation API,
  or custom). Two modes: blocking and notify-only (shadow/logging).

- **OpenTelemetry integration.** Subscribe to span-hooks (`AgentSpan`, `StepSpan`,
  `LLMCallSpan`, `ToolCallSpan`) and map them to OTel spans. Span-hooks provide
  guaranteed enter/exit with nesting — a natural fit for OTel's span model.


## Capabilities (dynamic modes)

- **Capability packs — dynamically loadable modes.** A `Capability` bundles a system prompt
  fragment, a set of tools, and optionally an LLM config override. Capabilities can be
  activated/deactivated during the agent's tool loop (by the agent itself via a special tool,
  or programmatically via `ToolLoopAgentContext`). On each iteration, `ToolLoopAgent` assembles
  the active set: merges system prompts from all active capabilities, unions their tool sets,
  applies LLM config overrides. Similar to how Claude Code switches between planning/coding/etc.
  Building blocks already exist (`ConfigValue` callables, `allowed_tools`/`denied_tools`,
  `on_start_iteration`, `ToolLoopAgentContext`), but there's no unified abstraction tying
  them together. A capability could also carry hooks (e.g. a "verbose" capability that adds
  logging hooks when activated). Pairs well with composable hooks.





## Documentation

- **Documentation benchmark suite.** A series of tasks given to a coding agent that has access
  only to documentation (no source code). Each task is a self-contained challenge: write a
  race agent (two LLMs, first wins via WhenAny + timeout), build a fan-out/fan-in pipeline,
  create a tool with service injection, wire up hooks with ExecutionContext, etc. For each task
  we define: the prompt, the documentation provided, and the expected outcome (working code
  that passes a test or matches a reference implementation). Run the suite, compare results
  against reference, identify where the agent struggles — those are doc gaps or API ergonomics
  issues. Fix docs/API, re-run, track improvement. This is a systematic, repeatable way to
  measure documentation quality and API usability from the perspective of a new user.

- **Local LLM usage guide.** Document how to use `OpenAIProvider` with local LLM servers
  (Ollama, LM Studio, vLLM). Show `base_url` configuration, recommend models for tool calling,
  and note any quirks (e.g. some models don't support tools well). A dedicated `OllamaProvider`
  is likely unnecessary — the OpenAI-compatible API covers chat, streaming, and tool calling.


## Voice

- **Voice demo (streaming pipeline).** Example `voice_chat.py` — STT (microphone) → agent →
  `on_text_delta` → TTS (speaker). Leverages existing streaming infrastructure. Start with
  simple pipeline, explore STT options: Google Cloud Speech-to-Text (available in GCP),
  OpenAI Whisper API, or local `faster-whisper` for free experimentation.

- **Smart voice pipeline with context-aware re-recognition.** For domain-specific scenarios
  (e.g. payments in Anna Money): STT produces multiple hypotheses with confidence scores.
  Agent receives all variants as structured input ("user said via voice, variants: ...").
  Agent uses domain context (frequent recipients, recent transactions) to select the best
  variant. If uncertain — requests re-recognition with hints (e.g. "typical recipients:
  Маша, Петя, Сбербанк"), STT re-processes the same audio with boosted vocabulary.
  Ties into capabilities (recognize topic → load relevant capability with context),
  agent-as-tool (STT as a callable sub-agent), and hooks (`on_user_message` enriches
  voice input with domain context).


## Integration

- **A2A (Agent-to-Agent) protocol support.** Add `flowra/a2a/` top-level package with optional
  dependency (`flowra[a2a]`) that exposes any Flowra agent as an A2A-compatible HTTP server.
  Thin adapter: takes an agent, publishes Agent Card, accepts messages over HTTP, supports
  streaming via SSE. Allows Flowra agents to participate in the broader A2A ecosystem
  (interop with Strands, LangChain, and other A2A-compatible frameworks).


## Pricing

- **Accurate cost estimation with full context.** `CostBreakdown` (per-category:
  input, output, cache_read, cache_creation) and `tools/sync_pricing.py` are done.
  Remaining: context length tiers (Anthropic/Google charge 2x input + 1.5x output
  above 200k tokens), per-provider pricing (direct API vs Vertex vs Bedrock vs Azure),
  thinking tokens (billed at output rate), cache creation TTL tiers (Anthropic 5m vs 1h).
  See `docs/research/pricing_complexity.md` and `tools/sync_pricing.py`.


## Internal providers

- **Anna LLM Proxy provider.** Create a separate private repository (`anna-flowra` or similar)
  with `LLMProxyProvider` for Anna's internal LLM Proxy service. Published to Nexus, not PyPI.
  Depends on `flowra` as a public dependency. Keeps the public flowra repo clean of
  internal/proprietary integrations.



## Serialization

- **Custom string tags for serialized types.** Currently the serialization tag is always
  `cls.__qualname__`, which is fragile — renaming or moving a class breaks deserialization of
  persisted state. Should allow explicit string tags, e.g. via a decorator (`@type_tag("my_spec")`)
  or a class attribute (`__type_tag__ = "my_spec"`), falling back to `__qualname__` if not set.
  This also decouples the persistence format from Python naming, making refactoring safer.


