# velixar-llamaindex

Velixar AI memory retriever for LlamaIndex. Gives your LlamaIndex pipelines access to persistent cognitive memory.

## Install

```bash
pip install velixar-llamaindex
```

## Usage

```python
from velixar_llamaindex import VelixarRetriever

retriever = VelixarRetriever(
    api_key="vx_...",
    workspace_id="ws_abc123",
)

# Use standalone
nodes = retriever.retrieve("What does the user prefer?")

# Use in a query engine
from llama_index.core import VectorStoreIndex
index = VectorStoreIndex([])
query_engine = index.as_query_engine(retriever=retriever)
```

## Features

- 4-tier hierarchical memory (pinned, session, semantic, org)
- Automatic salience scoring and memory promotion
- Cross-session persistence
- Encrypted embeddings (AES-256-GCM)

## Links

- [Velixar AI](https://velixarai.com)
- [API Docs](https://docs.velixarai.com)
