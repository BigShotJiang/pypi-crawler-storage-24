"""Velixar retriever for LlamaIndex."""

from typing import List, Optional

import httpx
from llama_index.core.retrievers import BaseRetriever
from llama_index.core.schema import NodeWithScore, QueryBundle, TextNode

from ._http import create_client, request_with_retry


class VelixarRetriever(BaseRetriever):
    """Retrieve memories from Velixar AI for LlamaIndex pipelines.

    Example:
        from velixar_llamaindex import VelixarRetriever

        retriever = VelixarRetriever(
            api_key="vx_...",
            workspace_id="ws_abc123",
        )
        nodes = retriever.retrieve("user preferences")
    """

    def __init__(
        self,
        api_key: str,
        workspace_id: str,
        base_url: str = "https://api.velixarai.com",
        top_k: int = 5,
        include_org: bool = False,
    ):
        super().__init__()
        self._api_key = api_key
        self._workspace_id = workspace_id
        self._top_k = top_k
        self._include_org = include_org
        self._client = create_client(base_url, api_key)

    def _retrieve(self, query_bundle: QueryBundle) -> List[NodeWithScore]:
        resp = request_with_retry(
            self._client, "GET", "/v1/memory/search",
            params={
                "q": query_bundle.query_str,
                "workspace_id": self._workspace_id,
                "limit": self._top_k,
                "include_org": str(self._include_org).lower(),
            },
        )
        resp.raise_for_status()

        nodes = []
        for mem in resp.json().get("memories", []):
            node = TextNode(
                text=mem.get("content", ""),
                id_=mem.get("id", ""),
                metadata={
                    "tier": mem.get("tier", 2),
                    "salience": mem.get("salience", 0),
                    "tags": mem.get("tags", []),
                    "source": "velixar",
                },
            )
            nodes.append(NodeWithScore(node=node, score=mem.get("score", 0.0)))
        return nodes
