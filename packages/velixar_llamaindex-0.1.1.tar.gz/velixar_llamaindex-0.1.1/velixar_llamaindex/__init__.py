"""Velixar AI integration for LlamaIndex — retriever and memory."""

__all__ = ["VelixarRetriever"]
__version__ = "0.1.1"


def __getattr__(name):
    if name == "VelixarRetriever":
        from .retriever import VelixarRetriever
        return VelixarRetriever
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
