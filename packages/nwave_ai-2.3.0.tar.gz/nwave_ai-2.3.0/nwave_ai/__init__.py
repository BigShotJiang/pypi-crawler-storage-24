"""nwave-ai: CLI installer for the nWave methodology framework."""

__version__ = "2.3.0"
