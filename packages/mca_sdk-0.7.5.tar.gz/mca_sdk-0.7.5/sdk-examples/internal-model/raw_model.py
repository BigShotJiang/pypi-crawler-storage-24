"""
Example: Model with External API Calls (Auto-instrumentable)
This file makes HTTP requests which will be automatically instrumented.
"""

import os
import time
import random
import requests

# Disable SSL warnings for demo
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def fetch_patient_features(patient_id: str) -> dict:
    """Fetch patient features from external API (auto-instrumented)."""
    # Disable SSL verification for Workbench environment
    response = requests.get(
        "https://httpbin.org/json",
        timeout=5,
        verify=False  # Disable SSL verification
    )

    time.sleep(0.1)

    return {
        "patient_id": patient_id,
        "age": random.randint(40, 90),
        "conditions": ["diabetes", "hypertension"]
    }

def call_ml_model_api(features: dict) -> dict:
    """Call external ML model API (auto-instrumented)."""
    response = requests.post(
        "https://httpbin.org/post",
        json=features,
        timeout=5,
        verify=False  # Disable SSL verification
    )

    risk_score = random.uniform(0.1, 0.9)

    return {
        "prediction": "high_risk" if risk_score > 0.7 else "low_risk",
        "risk_score": risk_score,
        "confidence": 0.85
    }

def save_prediction_to_db(prediction: dict):
    """Simulate database write (would be auto-instrumented with DB library)."""
    requests.post(
        "https://httpbin.org/post",
        json={"prediction": prediction},
        timeout=5,
        verify=False  # Disable SSL verification
    )
    print("✓ Prediction saved to database")

def main():
    print("Starting auto-instrumented model pipeline...\n")

    try:
        print("1. Fetching patient features...")
        patient_data = fetch_patient_features("patient-001")
        print(f"   ✓ Got features for patient age {patient_data['age']}")

        print("\n2. Calling ML model API...")
        result = call_ml_model_api(patient_data)
        print(f"   ✓ Prediction: {result['prediction']} (score: {result['risk_score']:.2f})")

        print("\n3. Saving prediction...")
        save_prediction_to_db(result)

        print("\n✅ Pipeline completed successfully!")

        # Give telemetry time to flush
        time.sleep(5)

    except Exception as e:
        print(f"\n✗ Error: {e}")
        raise

if __name__ == "__main__":
    main()
