"""
MCA SDK Example: Clinical Prediction Model

Demonstrates core SDK usage with Registry API integration.
"""

import os
import sys
import time
import random

# Add both sdk-examples (for shared.py) and mca-prototype root (for mca_sdk) to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from shared import (
    print_gcp_auth_status,
    print_collector_status,
    COLLECTOR_HTTP_ENDPOINT,
    REGISTRY_URL,
    INTERNAL_MODEL_ID,
)

from mca_sdk import MCAClient
from mca_sdk.registry import RegistryClient


def main():
    print("MCA SDK - Clinical Prediction Model Example\n")

    # Step 1-2: Verify prerequisites
    if not print_gcp_auth_status() or not print_collector_status():
        sys.exit(1)

    # Step 3-5: Registry integration
    print("\n=== Registry Integration ===")
    model_id = os.environ.get("MODEL_ID", INTERNAL_MODEL_ID)

    registry_client = RegistryClient(url=REGISTRY_URL, use_gcp_auth=True, timeout=10.0)

    # Fetch specific model config
    model_config = registry_client.fetch_model_config(model_id)
    print(f"✓ Using: {model_config.service_name} ({model_config.team_name})")
    if model_config.thresholds:
        print(f"✓ Thresholds: {model_config.thresholds}")
    print()

    # Step 6: Initialize SDK
    print("=== SDK Initialization ===")
    client = MCAClient(
        service_name=model_config.service_name,
        model_id=model_id,
        team_name=model_config.team_name,
        collector_endpoint=COLLECTOR_HTTP_ENDPOINT,
        allow_insecure_collector=True,
        registry_url=REGISTRY_URL,
        use_gcp_auth=True,
    )
    print(f"✓ SDK initialized\n")

    try:
        # Step 7: Input/Output Capture
        print("=== Input/Output Capture ===")

        @client.predict(capture_input=True, capture_output=True)
        def predict_readmission(patient_data: dict) -> dict:
            time.sleep(0.05)
            risk_score = random.uniform(0.1, 0.9)
            return {
                "prediction": "high_risk" if risk_score > 0.7 else "low_risk",
                "risk_score": risk_score,
                "confidence": 0.85,
            }

        result = predict_readmission({"patient_id": "sanitized-001", "age": 72})
        print(f"✓ Prediction: {result['prediction']} (score: {result['risk_score']:.2f})\n")

        # Step 8: Manual predictions with threshold checking
        print("=== Manual Predictions with Threshold Checking ===")
        latency_threshold_ms = client.thresholds.get("latency_ms", 1000)

        for i in range(3):
            latency = random.uniform(0.02, 0.15)
            client.record_prediction(
                latency=latency,
                prediction_id=f"pred-{i + 1:03d}",
                risk_score=random.uniform(0.1, 0.9),
                department="cardiology",
            )

            # Check threshold
            if latency * 1000 > latency_threshold_ms:
                print(
                    f"  ⚠️  pred-{i + 1:03d}: High latency {latency * 1000:.0f}ms (threshold: {latency_threshold_ms}ms)"
                )
            else:
                print(f"  ✓ pred-{i + 1:03d}: {latency * 1000:.0f}ms")
        print()

        # Step 9: Custom operation with trace()
        print("=== Custom Operation with trace() ===")
        with client.trace("data_preprocessing") as span:
            time.sleep(0.03)
            span.set_attribute("records_processed", 1000)
            span.set_attribute("features_extracted", 42)
            print("✓ Data preprocessing traced\n")

        # Step 10: Custom metrics
        print("=== Custom Metrics ===")
        client.record_counter("model.cache_hits", 15, cache_type="redis")
        client.record_gauge("model.queue_size", 8, queue_name="predictions")
        client.record_metric("model.confidence", 0.87, metric_type="histogram")
        print("✓ Recorded custom metrics\n")

        # Step 10b: Evaluation metrics
        print("=== Evaluation Metrics ===")
        # For a classification model, we use record_metric with valid ratios
        client.record_metric("model.accuracy_ratio", 0.92, dataset="validation", metric_type="gauge")
        client.record_metric("model.precision_ratio", 0.88, dataset="validation", metric_type="gauge")
        client.record_metric("model.recall_ratio", 0.85, dataset="validation", metric_type="gauge")
        print("✓ Recorded classification metrics (accuracy, precision, recall)\n")

        # Step 11: Error tracking
        print("=== Error Tracking ===")
        try:
            raise ValueError("Missing required feature: prior_admission_count")
        except Exception as e:
            client.record_error(
                error=e,
                error_type="validation_error",
                severity="warning",
                context={
                    "patient_id": "sanitized-001",
                    "missing_features": ["prior_admission_count"],
                },
            )
            print(f"✓ Error recorded: {type(e).__name__}\n")

        # Step 12: Flush
        print("=== Flush Telemetry ===")
        client.shutdown(timeout_millis=5000)
        registry_client.close()
        print("✓ Telemetry sent to collector\n")

        # Step 13: Verification
        print("=== Verify in GCP ===")
        print("Cloud Logging: https://console.cloud.google.com/logs/query")
        print(f'  Filter: logName="projects/bhsf-ai-team-projects/logs/emms-model-telemetry"')
        print(f'          AND labels."service.name"="{model_config.service_name}"')
        print("\nCloud Trace: https://console.cloud.google.com/traces/list")
        print(f'  Search: service.name="{model_config.service_name}"')
        print("  Look for: predict, data_preprocessing spans")

    except Exception as e:
        print(f"\n✗ Error: {e}")
        client.shutdown()
        registry_client.close()
        raise


if __name__ == "__main__":
    main()
