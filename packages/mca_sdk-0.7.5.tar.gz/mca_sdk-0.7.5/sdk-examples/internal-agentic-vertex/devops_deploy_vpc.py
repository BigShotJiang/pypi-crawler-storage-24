from google.cloud import aiplatform

# Initialize the AI Platform SDK
aiplatform.init(project="bhsf-ai-team-projects", location="us-east1")

print("Creating PRIVATE peered Endpoint...")
# 1. Create a PRIVATE peered Endpoint (This is REQUIRED for VPC outbound access to 10.x.x.x)
endpoint = aiplatform.PrivateEndpoint.create(
    display_name="medical-research-vpc-endpoint",
    network="projects/bhsf-prj-dev-net-spoke-0/global/networks/vpc-dev-spoke-0",
)
print(f"Created Private Endpoint: {endpoint.resource_name}")

print("Fetching model...")
# 2. Get the model from the registry
models = aiplatform.Model.list(filter='display_name="medical-research-agent-model"')
if not models:
    raise RuntimeError("Model 'medical-research-agent-model' not found")
my_model = models[0]

print("Deploying model...")
# 3. Deploy model to the private endpoint
endpoint.deploy(
    model=my_model,
    machine_type="n1-standard-4",
    min_replica_count=1,
    max_replica_count=1,
    service_account="sa-dev-aiml-vertex@bhsf-ai-team-projects.iam.gserviceaccount.com"
)
print("Deployment complete! Endpoint is now peered to the VPC.")