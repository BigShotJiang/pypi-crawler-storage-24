from google.cloud import aiplatform
                                                                                                                                                                                             
aiplatform.init(project="bhsf-ai-team-projects", location="us-east1")
                                                                                                                                                                                            
# 1. Create a standard Endpoint (no PrivateEndpoint needed)                                                                                                                              
print("Creating Endpoint...")
endpoint = aiplatform.Endpoint.create(
    display_name="medical-research-endpoint",
)
# 2. Get the model
models = aiplatform.Model.list(filter='display_name="medical-research-agent-model"')
if not models:
    raise RuntimeError("Model 'medical-research-agent-model' not found")
my_model = models[0]
print(f"Found model: {my_model.display_name} ({my_model.resource_name})")
# 3. Deploy it
print("Deploying model to Endpoint...")
endpoint.deploy(
    model=my_model,
    machine_type="n1-standard-4",
    min_replica_count=1,
    max_replica_count=1,
    service_account="sa-dev-aiml-vertex@bhsf-ai-team-projects.iam.gserviceaccount.com",
)
print(f"Done! Endpoint: {endpoint.resource_name}")
# 4. SDK telemetry config — point to OTel Collector Internal LB
print()
print("OTel Collector endpoint for SDK config:")
print("  collector_endpoint = http://10.164.76.55:4318")