import os
import sys
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

# Add necessary paths for imports
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from mca_sdk import MCAClient
from mca_sdk.integrations import MCALiteLLMCallback
from mca_sdk.registry import RegistryClient
import litellm

from shared.config import COLLECTOR_HTTP_ENDPOINT, REGISTRY_URL, AGENTIC_MODEL_ID
from agent_instrumented import MedicalResearchAgent

app = FastAPI()
agent = None
mca_client = None
registry_client = None

@app.on_event("startup")
async def startup_event():
    global agent, mca_client, registry_client
    
    model_id = os.environ.get("MODEL_ID", AGENTIC_MODEL_ID)
    registry_client = RegistryClient(url=REGISTRY_URL, use_gcp_auth=True, timeout=10.0)
    
    # Try to fetch from registry, fallback if testing locally without full mock registry
    try:
        model_config = registry_client.fetch_model_config(model_id)
        service_name = model_config.service_name
        team_name = model_config.team_name
    except Exception as e:
        print(f"Warning: Could not fetch config from registry: {e}")
        service_name = "internal-agentic-service"
        team_name = "ai-research"
    
    mca_client = MCAClient(
        service_name=service_name,
        model_id=model_id,
        model_type="agentic",
        team_name=team_name,
        llm_provider="openai",
        llm_model="gpt-4",
        collector_endpoint=os.environ.get("MCA_COLLECTOR_ENDPOINT", COLLECTOR_HTTP_ENDPOINT),
        allow_insecure_collector=True,
        registry_url=REGISTRY_URL,
        use_gcp_auth=True,
        
        capture_input_data=True,
        capture_output_data=True,
    )
    
    callback = MCALiteLLMCallback(mca_client)
    litellm.callbacks = [callback]
    agent = MedicalResearchAgent(mca_client)

@app.on_event("shutdown")
async def shutdown_event():
    if mca_client:
        mca_client.shutdown(timeout_millis=5000)
    if registry_client:
        registry_client.close()

@app.get("/health")
async def health():
    return {"status": "healthy"}

@app.post("/predict")
async def predict(request: Request):
    """Vertex AI expects data in the format: {"instances": [{"question": "..."}]}"""
    body = await request.json()
    instances = body.get("instances", [])
    
    if not instances:
        return JSONResponse(status_code=400, content={"error": "No instances provided"})
        
    predictions = []
    for instance in instances:
        question = instance.get("question", "")
        if not question:
            predictions.append({"error": "Missing 'question' in instance"})
            continue
            
        try:
            result = agent.research_question(question)
            predictions.append(result)
            mca_client.flush(timeout_millis=2000)
        except Exception as e:
            predictions.append({"error": str(e), "status": "failure"})
        
    return {"predictions": predictions}
