from google.cloud import aiplatform

def deploy_to_vpc():
    print("Initializing AI Platform...")
    aiplatform.init(project="bhsf-ai-team-projects", location="us-east1")

    print("Creating peered Endpoint...")
    # The DevOps team made a tiny typo in their snippet. 
    # In the google-cloud-aiplatform SDK, to attach an endpoint to a VPC, you MUST use PrivateEndpoint.create
    # Endpoint.create literally does not accept a 'network' argument.
    try:
        endpoint = aiplatform.PrivateEndpoint.create(
            display_name="medical-research-vpc-endpoint",
            network="projects/bhsf-prj-dev-net-spoke-0/global/networks/vpc-dev-spoke-0",
        )
        print(f"Endpoint created successfully! ID: {endpoint.name}")
    except Exception as e:
        print(f"Failed to create endpoint: {e}")
        return

    print("Fetching the Model...")
    models = aiplatform.Model.list(filter='display_name="medical-research-agent-model"')
    if not models:
        print("Could not find the model 'medical-research-agent-model' in us-east1.")
        return
        
    my_model = models[0]
    print(f"Found model: {my_model.name}")

    print("Deploying model to Endpoint (This will take ~10-15 minutes)...")
    endpoint.deploy(
        model=my_model,
        machine_type="n1-standard-4",
        min_replica_count=1,
        max_replica_count=1,
        service_account="sa-dev-aiml-vertex@bhsf-ai-team-projects.iam.gserviceaccount.com"
    )

    print("Deployment complete! Endpoint is ready for VPC traffic.")

if __name__ == "__main__":
    deploy_to_vpc()
