# Autolog Demo

This example demonstrates the **autolog** feature for zero-code ML model instrumentation.

## What is Autolog?

The `autolog()` function automatically instruments popular ML frameworks (scikit-learn, XGBoost, LightGBM) to emit OpenTelemetry metrics and traces without requiring manual code changes.

### Before Autolog (Manual Instrumentation)

```python
# Every prediction needs manual wrapping
@client.predict()
def make_prediction(features):
    return model.predict(features)
```

### After Autolog (Zero-Code Instrumentation)

```python
from mca_sdk import MCAClient, autolog

client = MCAClient(...)
autolog()  # One line!

# Now sklearn/xgboost/lightgbm predictions are automatically instrumented
predictions = model.predict(features)  # Automatically tracked!
```

## Features

- **Zero-code instrumentation**: No need to wrap every `.predict()` call
- **Auto-detection**: Automatically detects which frameworks are installed
- **Multiple frameworks**: Supports sklearn, XGBoost, LightGBM
- **Configurable**: Can exclude frameworks or enable input/output capture

## Prerequisites

```bash
# Install dependencies
pip install scikit-learn>=1.0
```

## Running the Example

```bash
# Start OTel Collector (from repo root)
cd mca-prototype
docker-compose up -d otel-collector

# Run the autolog demo
python3 sdk-examples/autolog-demo/sklearn_autolog_example.py
```

## Expected Output

```
=== MCA SDK Autolog Demo (Scikit-learn) ===

Step 1: Initializing MCAClient...
✓ MCAClient initialized

Step 2: Enabling autolog for all ML frameworks...
✓ Autolog enabled (sklearn auto-detected and patched)

Step 3: Training RandomForest model...
✓ Model trained

Step 4: Making predictions (automatically instrumented)...
  Prediction 1: 10 results
  Prediction 2: 10 results
  Prediction 3: 10 results
  Prediction 4: 10 results
  Prediction 5: 10 results

✓ All predictions automatically tracked!
  - Metrics recorded: latency, model_class=RandomForestClassifier, framework=sklearn
  - Traces created: sklearn.RandomForestClassifier.predict spans

Step 5: Shutting down MCAClient...
✓ Shutdown complete

=== Demo Complete ===
Check your OTel Collector logs/metrics to see the telemetry!
```

## Telemetry Generated

### Metrics
- `model.prediction.count`: Counter for prediction calls
- `model.prediction.latency`: Histogram of prediction latencies
- Attributes: `framework=sklearn`, `model_class=RandomForestClassifier`

### Traces
- Span name: `sklearn.RandomForestClassifier.predict`
- Span attributes: framework, model_class, method

## Configuration Options

```python
# Enable autolog for specific frameworks only
autolog(frameworks=["sklearn"])

# Exclude specific frameworks
autolog(exclude=["lightgbm"])

# Capture input/output data with size limits (use with caution - PHI risk)
# Payloads larger than max_payload_size will be truncated to prevent memory bloat
autolog(capture_input=True, capture_output=True, max_payload_size=5000)
```

## Robustness Features

### Payload Size Limiting
Large batch predictions can cause memory bloat and network payload explosion. Autolog automatically truncates captured data to `max_payload_size` bytes (default: 10,000 bytes).

```python
# Configure smaller limit for production
autolog(capture_output=True, max_payload_size=1000)
```

### Graceful Client Handling
If predictions are made before MCAClient is initialized, autolog logs a warning once and predictions execute without telemetry (no crash).

### Error Recording
When predictions fail, autolog:
1. Records the exception in the OpenTelemetry span
2. Marks the span status as ERROR
3. Records failure metrics with error details
4. Re-raises the exception to preserve application behavior

### Parameter Validation
Invalid framework names immediately raise `ValueError`:
```python
# This will raise ValueError: Invalid framework names
autolog(frameworks=["pytorch", "tensorflow"])  # Not yet supported
```

## Important Notes

1. **MCAClient must be initialized BEFORE calling autolog()**
   ```python
   client = MCAClient(...)  # Initialize first
   autolog()                # Then enable autolog
   ```

2. **Framework Detection**: autolog() only patches frameworks that are already imported
   - If you haven't imported sklearn yet, it won't be patched
   - Solution: Import the framework before calling autolog()

3. **PHI Considerations**: Be cautious when using `capture_input=True` or `capture_output=True`
   - Input/output data may contain Protected Health Information (PHI)
   - Sanitize PHI before enabling capture

## Supported Frameworks

| Framework | Methods Instrumented | Status |
|-----------|---------------------|--------|
| **scikit-learn** | `predict()`, `predict_proba()`, `fit()` | ✅ Supported |
| **XGBoost** | `Booster.predict()`, `XGBClassifier.predict()`, `XGBRegressor.predict()` | ✅ Supported |
| **LightGBM** | `Booster.predict()`, `LGBMClassifier.predict()`, `LGBMRegressor.predict()` | ✅ Supported |

## Troubleshooting

### "MCAClient must be initialized" error
**Solution**: Initialize MCAClient before calling autolog()

### No metrics appearing
**Possible causes**:
1. OTel Collector not running (`docker-compose up -d otel-collector`)
2. Wrong collector endpoint (check `collector_endpoint` parameter)
3. Framework not imported before autolog() call

### Double instrumentation
**Solution**: Only call autolog() once per session. The SDK prevents double-patching automatically.

## See Also

- [Internal Model Example](../internal-model/) - Manual instrumentation approach
- [MCA SDK Documentation](../../README.md) - Full SDK documentation
