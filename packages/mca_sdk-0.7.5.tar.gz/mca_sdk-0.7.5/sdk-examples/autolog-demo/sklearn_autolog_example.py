"""Scikit-learn autolog example demonstrating zero-code instrumentation.

This example shows how to enable automatic instrumentation for sklearn models
using the autolog() function. No manual wrapping of predict() calls is needed.
"""

import time
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import make_classification

# Import MCA SDK
from mca_sdk import MCAClient, autolog


def main():
    """Demonstrate sklearn autolog instrumentation."""
    print("=== MCA SDK Autolog Demo (Scikit-learn) ===\n")

    # Step 1: Initialize MCAClient (required before autolog)
    print("Step 1: Initializing MCAClient...")
    client = MCAClient(
        service_name="sklearn-autolog-demo",
        model_id="mdl-rf-autolog-001",
        team_name="data-science",
        model_type="internal",
        collector_endpoint="http://localhost:4318",
    )
    print("✓ MCAClient initialized\n")

    # Step 2: Enable autolog (one line!)
    print("Step 2: Enabling autolog for all ML frameworks...")
    autolog()
    print("✓ Autolog enabled (sklearn auto-detected and patched)\n")

    # Step 3: Use sklearn normally - it's automatically instrumented!
    print("Step 3: Training RandomForest model...")
    X, y = make_classification(n_samples=1000, n_features=20, random_state=42)
    model = RandomForestClassifier(n_estimators=10, random_state=42)
    model.fit(X, y)
    print("✓ Model trained\n")

    # Step 4: Make predictions - automatically instrumented!
    print("Step 4: Making predictions (automatically instrumented)...")
    for i in range(5):
        X_test = np.random.randn(10, 20)
        predictions = model.predict(X_test)
        print(f"  Prediction {i+1}: {len(predictions)} results")
        time.sleep(0.1)

    print("\n✓ All predictions automatically tracked!")
    print("  - Metrics recorded: latency, model_class=RandomForestClassifier, framework=sklearn")
    print("  - Traces created: sklearn.RandomForestClassifier.predict spans")

    # Step 5: Shutdown client
    print("\nStep 5: Shutting down MCAClient...")
    client.shutdown()
    print("✓ Shutdown complete")

    print("\n=== Demo Complete ===")
    print("Check your OTel Collector logs/metrics to see the telemetry!")


if __name__ == "__main__":
    main()
