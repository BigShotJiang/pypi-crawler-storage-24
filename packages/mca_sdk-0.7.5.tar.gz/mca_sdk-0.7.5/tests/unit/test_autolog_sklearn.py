"""Unit tests for scikit-learn autolog functionality."""

import sys
from unittest.mock import MagicMock, patch, call
import pytest


class TestSklearnAutolog:
    """Test autolog for scikit-learn framework."""

    def test_patch_sklearn_predict(self, mocker):
        """Test that sklearn predict() is instrumented."""
        # Mock sklearn import with an actual class that has methods
        sklearn_base = MagicMock()

        class MockBaseEstimator:
            def predict(self, X):
                return [1, 0]

        sklearn_base.BaseEstimator = MockBaseEstimator
        sys.modules["sklearn"] = MagicMock()
        sys.modules["sklearn.base"] = sklearn_base

        # Mock MCAClient singleton
        mock_client = MagicMock()
        mock_client.trace = MagicMock(
            return_value=MagicMock(__enter__=MagicMock(), __exit__=MagicMock())
        )
        mock_client.record_prediction = MagicMock()

        with patch("mca_sdk.core.client.MCAClient.get_instance", return_value=mock_client):
            from mca_sdk.autolog import autolog

            # Apply autolog
            autolog(frameworks=["sklearn"])

            # Verify that BaseEstimator.predict was patched
            assert hasattr(MockBaseEstimator, "predict")

            # Verify instrumentation works
            estimator = MockBaseEstimator()
            estimator.predict([[1, 2]])
            mock_client.record_prediction.assert_called()

    def test_sklearn_instrumentation_records_metrics(self, mocker):
        """Test that sklearn predict() calls record metrics."""
        # Mock sklearn
        sklearn_base = MagicMock()

        class MockEstimator:
            def predict(self, X):
                return [1, 0, 1]

        sklearn_base.BaseEstimator = MockEstimator
        sys.modules["sklearn"] = MagicMock()
        sys.modules["sklearn.base"] = sklearn_base

        # Mock MCAClient
        mock_client = MagicMock()
        mock_client.trace = MagicMock(
            return_value=MagicMock(__enter__=MagicMock(), __exit__=MagicMock())
        )

        with patch("mca_sdk.core.client.MCAClient.get_instance", return_value=mock_client):
            from mca_sdk.autolog._sklearn import patch_sklearn

            # Patch sklearn
            patch_sklearn(capture_input=False, capture_output=False)

            # Make prediction
            estimator = MockEstimator()
            result = estimator.predict([[1, 2, 3]])

            # Verify instrumentation was called
            assert result == [1, 0, 1]
            mock_client.trace.assert_called()
            mock_client.record_prediction.assert_called()

    def test_sklearn_capture_input_output(self, mocker):
        """Test that sklearn autolog captures input/output shapes when requested."""
        # Mock sklearn
        sklearn_base = MagicMock()

        class MockEstimator:
            def predict(self, X):
                return [1, 0, 1]

        sklearn_base.BaseEstimator = MockEstimator
        sys.modules["sklearn"] = MagicMock()
        sys.modules["sklearn.base"] = sklearn_base

        # Mock numpy array with shape
        mock_input = MagicMock()
        mock_input.shape = (100, 10)

        # Mock MCAClient
        mock_client = MagicMock()
        mock_client.trace = MagicMock(
            return_value=MagicMock(__enter__=MagicMock(), __exit__=MagicMock())
        )

        with patch("mca_sdk.core.client.MCAClient.get_instance", return_value=mock_client):
            from mca_sdk.autolog._sklearn import patch_sklearn

            # Patch with capture enabled
            patch_sklearn(capture_input=True, capture_output=True)

            # Make prediction
            estimator = MockEstimator()
            estimator.predict(mock_input)

            # Verify record_prediction was called with shape info
            mock_client.record_prediction.assert_called()
            call_kwargs = mock_client.record_prediction.call_args[1]
            assert "input_shape" in call_kwargs

    def test_sklearn_graceful_fallback_no_client(self, mocker):
        """Test that sklearn autolog gracefully falls back if client not initialized."""
        # Mock sklearn
        sklearn_base = MagicMock()

        class MockEstimator:
            def predict(self, X):
                return [1, 0, 1]

        sklearn_base.BaseEstimator = MockEstimator
        sys.modules["sklearn"] = MagicMock()
        sys.modules["sklearn.base"] = sklearn_base

        # Mock MCAClient.get_instance() to return None
        with patch("mca_sdk.core.client.MCAClient.get_instance", return_value=None):
            from mca_sdk.autolog._sklearn import patch_sklearn

            # Patch sklearn
            patch_sklearn(capture_input=False, capture_output=False)

            # Make prediction (should not raise error)
            estimator = MockEstimator()
            result = estimator.predict([[1, 2, 3]])

            # Should still work without instrumentation
            assert result == [1, 0, 1]

    def test_sklearn_exception_handling(self, mocker):
        """Test that sklearn autolog handles exceptions and re-raises them."""
        # Mock sklearn
        sklearn_base = MagicMock()

        class MockEstimator:
            def predict(self, X):
                raise ValueError("Model error")

        sklearn_base.BaseEstimator = MockEstimator
        sys.modules["sklearn"] = MagicMock()
        sys.modules["sklearn.base"] = sklearn_base

        # Mock MCAClient
        mock_client = MagicMock()
        mock_context = MagicMock()
        mock_client.trace = MagicMock(return_value=mock_context)
        mock_context.__enter__ = MagicMock(return_value=mock_context)
        mock_context.__exit__ = MagicMock(return_value=False)  # Don't suppress exception

        with patch("mca_sdk.core.client.MCAClient.get_instance", return_value=mock_client):
            from mca_sdk.autolog._sklearn import patch_sklearn

            # Patch sklearn
            patch_sklearn(capture_input=False, capture_output=False)

            # Make prediction (should raise error AND record metrics)
            estimator = MockEstimator()
            with pytest.raises(ValueError, match="Model error"):
                estimator.predict([[1, 2, 3]])

            # Verify metrics were still recorded with error info
            mock_client.record_prediction.assert_called()
            call_kwargs = mock_client.record_prediction.call_args[1]
            assert "error" in call_kwargs

    def test_no_double_patching(self, mocker):
        """Test that calling autolog twice doesn't cause double patching."""
        # Mock sklearn
        sklearn_base = MagicMock()

        class MockEstimator:
            def predict(self, X):
                return [1, 0, 1]

        sklearn_base.BaseEstimator = MockEstimator
        sys.modules["sklearn"] = MagicMock()
        sys.modules["sklearn.base"] = sklearn_base

        # Mock MCAClient
        mock_client = MagicMock()
        mock_client.trace = MagicMock(
            return_value=MagicMock(__enter__=MagicMock(), __exit__=MagicMock())
        )

        with patch("mca_sdk.core.client.MCAClient.get_instance", return_value=mock_client):
            from mca_sdk.autolog._sklearn import patch_sklearn

            # Patch twice
            patch_sklearn(capture_input=False, capture_output=False)
            patch_sklearn(capture_input=False, capture_output=False)

            # Make prediction
            estimator = MockEstimator()
            result = estimator.predict([[1, 2, 3]])

            # Should only be instrumented once
            assert result == [1, 0, 1]
            # Note: We can't easily verify single instrumentation without
            # inspecting the method wrapper, but no exception is good enough


class TestAutologEntry:
    """Test the main autolog() entry point."""

    def test_autolog_requires_client(self):
        """Test that autolog raises error if MCAClient not initialized."""
        with patch("mca_sdk.core.client.MCAClient.get_instance", return_value=None):
            from mca_sdk.autolog import autolog

            with pytest.raises(RuntimeError, match="MCAClient must be initialized"):
                autolog()

    def test_autolog_detects_frameworks(self, mocker):
        """Test that autolog auto-detects installed frameworks."""
        # Mock sklearn in sys.modules with actual class
        sklearn_base = MagicMock()

        class MockBaseEstimator:
            def predict(self, X):
                return [1, 0]

        sklearn_base.BaseEstimator = MockBaseEstimator
        sys.modules["sklearn"] = MagicMock()
        sys.modules["sklearn.base"] = sklearn_base

        # Mock MCAClient
        mock_client = MagicMock()
        mock_client.trace = MagicMock(
            return_value=MagicMock(__enter__=MagicMock(), __exit__=MagicMock())
        )

        with patch("mca_sdk.core.client.MCAClient.get_instance", return_value=mock_client):
            from mca_sdk import autolog

            # Should auto-detect and patch sklearn
            autolog()

            # Test that it works
            estimator = MockBaseEstimator()
            estimator.predict([[1, 2]])
            mock_client.record_prediction.assert_called()

    def test_autolog_exclude_framework(self, mocker):
        """Test that autolog respects exclude parameter."""
        # Mock sklearn class
        sklearn_base = MagicMock()

        class MockBaseEstimator:
            def predict(self, X):
                return [1, 0]

        sklearn_base.BaseEstimator = MockBaseEstimator
        sys.modules["sklearn"] = MagicMock()
        sys.modules["sklearn.base"] = sklearn_base

        # Mock xgboost
        xgboost_module = MagicMock()

        class MockBooster:
            def predict(self, dmatrix):
                return [0.8]

        xgboost_module.Booster = MockBooster
        sys.modules["xgboost"] = xgboost_module

        # Mock MCAClient
        mock_client = MagicMock()
        mock_client.trace = MagicMock(
            return_value=MagicMock(__enter__=MagicMock(), __exit__=MagicMock())
        )

        with patch("mca_sdk.core.client.MCAClient.get_instance", return_value=mock_client):
            from mca_sdk import autolog

            # Exclude xgboost
            autolog(exclude=["xgboost"])

            # sklearn should work
            estimator = MockBaseEstimator()
            estimator.predict([[1, 2]])
            assert mock_client.record_prediction.call_count >= 1

            # xgboost should NOT be instrumented
            booster = MockBooster()
            booster.predict(None)
            # Call count should not increase (xgboost not instrumented)
            assert mock_client.record_prediction.call_count == 1

    def test_autolog_specific_frameworks(self, mocker):
        """Test that autolog respects frameworks parameter."""
        # Mock sklearn class
        sklearn_base = MagicMock()

        class MockBaseEstimator:
            def predict(self, X):
                return [1, 0]

        sklearn_base.BaseEstimator = MockBaseEstimator
        sys.modules["sklearn"] = MagicMock()
        sys.modules["sklearn.base"] = sklearn_base

        # Mock MCAClient
        mock_client = MagicMock()
        mock_client.trace = MagicMock(
            return_value=MagicMock(__enter__=MagicMock(), __exit__=MagicMock())
        )

        with patch("mca_sdk.core.client.MCAClient.get_instance", return_value=mock_client):
            from mca_sdk import autolog

            # Request only sklearn
            autolog(frameworks=["sklearn"])

            # Verify it works
            estimator = MockBaseEstimator()
            estimator.predict([[1, 2]])
            mock_client.record_prediction.assert_called_once()
