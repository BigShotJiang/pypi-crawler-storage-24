"""
Tests for SatisfactoEngine._patch_connect_debugging.
Covers: happy path, cache patch when conf.get fails, idempotency.
"""
import pytest
import pyspark.errors.utils as _pu
from unittest.mock import MagicMock, patch
from satisfactoscript.core.core import SatisfactoEngine


def _make_engine(spark=None):
    engine = object.__new__(SatisfactoEngine)
    engine.spark = spark or MagicMock()
    return engine


class TestPatchConnectDebugging:

    def setup_method(self):
        """Reset the PySpark cache before each test."""
        _pu._enable_debugging_cache = None

    def teardown_method(self):
        """Reset the PySpark cache after each test."""
        _pu._enable_debugging_cache = None

    def test_no_patch_when_conf_get_succeeds(self):
        spark = MagicMock()
        spark.conf.get.return_value = "false"
        engine = _make_engine(spark=spark)

        engine._patch_connect_debugging()

        spark.conf.get.assert_called_once_with(
            "spark.python.sql.dataFrameDebugging.enabled", "false"
        )
        # Cache should remain None (PySpark populates it itself on first F.col call)
        assert _pu._enable_debugging_cache is None

    def test_patches_cache_to_false_when_conf_get_fails(self):
        spark = MagicMock()
        spark.conf.get.side_effect = Exception("gRPC: Missing UserContext")
        engine = _make_engine(spark=spark)

        engine._patch_connect_debugging()

        assert _pu._enable_debugging_cache is False

    def test_does_not_overwrite_existing_cache(self):
        """If the cache is already set (e.g. True), do not overwrite it."""
        _pu._enable_debugging_cache = True
        spark = MagicMock()
        spark.conf.get.side_effect = Exception("gRPC error")
        engine = _make_engine(spark=spark)

        engine._patch_connect_debugging()

        assert _pu._enable_debugging_cache is True

    def test_silent_when_pyspark_utils_not_importable(self):
        """Must not raise even if the pyspark internals change."""
        spark = MagicMock()
        spark.conf.get.side_effect = Exception("gRPC error")
        engine = _make_engine(spark=spark)

        with patch.dict("sys.modules", {"pyspark.errors.utils": None}):
            # Should not raise
            engine._patch_connect_debugging()
