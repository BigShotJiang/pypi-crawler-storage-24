"""
Tests for SatisfactoEngine catalog access and environment auto-detection.
Covers: _check_catalog_access and _auto_detect_environment.
"""
import pytest
from unittest.mock import MagicMock, patch
from satisfactoscript.core.core import SatisfactoEngine


def _make_engine(config, spark=None):
    """
    Build a SatisfactoEngine instance without calling __init__,
    allowing isolated testing of individual methods.
    """
    engine = object.__new__(SatisfactoEngine)
    engine.config = config
    engine.spark = spark or MagicMock()
    return engine


CONFIG_TWO_ENVS = {
    "priority_check": ["dev", "prod"],
    "environments": {
        "dev":  {"catalog": "catalog_dev"},
        "prod": {"catalog": "catalog_prd"},
    },
}

CONFIG_WITH_DEFAULT = {
    "priority_check": ["dev", "prod"],
    "default_env": "dev",
    "environments": {
        "dev":  {"catalog": "catalog_dev"},
        "prod": {"catalog": "catalog_prd"},
    },
}

CONFIG_EMPTY = {}


# ──────────────────────────────────────────────────────────────────────────────
# _check_catalog_access
# ──────────────────────────────────────────────────────────────────────────────

class TestCheckCatalogAccess:

    def test_returns_true_when_spark_sql_succeeds(self):
        spark = MagicMock()
        spark.sql.return_value.limit.return_value.collect.return_value = [("row",)]
        engine = _make_engine(CONFIG_TWO_ENVS, spark=spark)

        assert engine._check_catalog_access("catalog_dev") is True
        spark.sql.assert_called_once_with("SHOW SCHEMAS IN `catalog_dev`")

    def test_falls_back_to_sdk_when_spark_sql_fails(self):
        spark = MagicMock()
        spark.sql.side_effect = Exception("gRPC: Missing UserContext")
        engine = _make_engine(CONFIG_TWO_ENVS, spark=spark)

        mock_catalog_info = MagicMock()
        mock_workspace_client = MagicMock()
        mock_workspace_client.catalogs.get.return_value = mock_catalog_info

        with patch.dict("os.environ", {"DATABRICKS_HOST": "https://adb-xxx.azuredatabricks.net", "DATABRICKS_TOKEN": "dapi123"}):
            with patch("satisfactoscript.core.core.WorkspaceClient", return_value=mock_workspace_client, create=True):
                # The SDK import inside the method needs to be patched at the right place
                with patch.dict("sys.modules", {"databricks.sdk": MagicMock(WorkspaceClient=mock_workspace_client.__class__)}):
                    # Patch the import inside the method
                    import sys
                    fake_sdk = MagicMock()
                    fake_sdk.WorkspaceClient.return_value = mock_workspace_client
                    sys.modules["databricks.sdk"] = fake_sdk

                    result = engine._check_catalog_access("catalog_dev")

        mock_workspace_client.catalogs.get.assert_called_once_with("catalog_dev")
        assert result is True

    def test_returns_false_when_both_strategies_fail(self):
        spark = MagicMock()
        spark.sql.side_effect = Exception("SQL error")
        engine = _make_engine(CONFIG_TWO_ENVS, spark=spark)

        with patch.dict("os.environ", {"DATABRICKS_HOST": "https://adb-xxx.azuredatabricks.net", "DATABRICKS_TOKEN": "dapi123"}):
            import sys
            fake_sdk = MagicMock()
            fake_sdk.WorkspaceClient.return_value.catalogs.get.side_effect = Exception("SDK error")
            sys.modules["databricks.sdk"] = fake_sdk

            result = engine._check_catalog_access("catalog_dev")

        assert result is False

    def test_returns_false_when_no_credentials_for_sdk(self):
        spark = MagicMock()
        spark.sql.side_effect = Exception("SQL error")
        engine = _make_engine(CONFIG_TWO_ENVS, spark=spark)

        with patch.dict("os.environ", {}, clear=True):
            result = engine._check_catalog_access("catalog_dev")

        assert result is False


# ──────────────────────────────────────────────────────────────────────────────
# _auto_detect_environment
# ──────────────────────────────────────────────────────────────────────────────

class TestAutoDetectEnvironment:

    def test_detects_first_accessible_env(self):
        engine = _make_engine(CONFIG_TWO_ENVS)
        engine._check_catalog_access = MagicMock(side_effect=lambda c: c == "catalog_dev")

        engine._auto_detect_environment()

        assert engine.env == "DEV"
        assert engine.db == "catalog_dev"

    def test_skips_inaccessible_env_and_detects_next(self):
        engine = _make_engine(CONFIG_TWO_ENVS)
        engine._check_catalog_access = MagicMock(side_effect=lambda c: c == "catalog_prd")

        engine._auto_detect_environment()

        assert engine.env == "PROD"
        assert engine.db == "catalog_prd"

    def test_uses_default_env_when_all_checks_fail(self):
        engine = _make_engine(CONFIG_WITH_DEFAULT)
        engine._check_catalog_access = MagicMock(return_value=False)

        engine._auto_detect_environment()

        assert engine.env == "DEV"
        assert engine.db == "catalog_dev"

    def test_raises_when_all_fail_and_no_default_env(self):
        engine = _make_engine(CONFIG_TWO_ENVS)
        engine._check_catalog_access = MagicMock(return_value=False)

        with pytest.raises(ValueError, match="CRITICAL"):
            engine._auto_detect_environment()

    def test_raises_on_invalid_config(self):
        engine = _make_engine(CONFIG_EMPTY)

        with pytest.raises(ValueError, match="CRITICAL"):
            engine._auto_detect_environment()

    def test_default_env_not_used_when_sql_succeeds(self):
        """default_env must not override a successfully detected environment."""
        engine = _make_engine(CONFIG_WITH_DEFAULT)
        engine._check_catalog_access = MagicMock(side_effect=lambda c: c == "catalog_prd")

        engine._auto_detect_environment()

        assert engine.env == "PROD"
        assert engine.db == "catalog_prd"