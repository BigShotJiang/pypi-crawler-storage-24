"""
Tests for SatisfactoEngine._get_clean_username.
Covers: Spark SQL, Databricks SDK REST API, DBUtils fallback, unknown_user.
"""
import sys
import pytest
from unittest.mock import MagicMock, patch
from satisfactoscript.core.core import SatisfactoEngine


def _make_engine(spark=None, dbutils=None):
    engine = object.__new__(SatisfactoEngine)
    engine.spark = spark or MagicMock()
    engine.dbutils = dbutils or MagicMock()
    return engine


class TestGetCleanUsername:

    def test_returns_username_from_spark_sql(self):
        spark = MagicMock()
        spark.sql.return_value.collect.return_value = [("julien.houba@company.com",)]
        engine = _make_engine(spark=spark)

        assert engine._get_clean_username() == "julien_houba"

    def test_cleans_dots_and_dashes(self):
        spark = MagicMock()
        spark.sql.return_value.collect.return_value = [("jean-pierre.dupont@company.com",)]
        engine = _make_engine(spark=spark)

        assert engine._get_clean_username() == "jean_pierre_dupont"

    def test_falls_back_to_sdk_when_spark_sql_fails(self):
        spark = MagicMock()
        spark.sql.side_effect = Exception("gRPC: Missing UserContext")
        engine = _make_engine(spark=spark)

        mock_me = MagicMock()
        mock_me.user_name = "hqhoujul@company.com"
        mock_wc = MagicMock()
        mock_wc.current_user.me.return_value = mock_me

        fake_sdk = MagicMock()
        fake_sdk.WorkspaceClient.return_value = mock_wc
        sys.modules["databricks.sdk"] = fake_sdk

        with patch.dict("os.environ", {"DATABRICKS_HOST": "https://adb.net", "DATABRICKS_TOKEN": "dapi123"}):
            result = engine._get_clean_username()

        assert result == "hqhoujul"

    def test_falls_back_to_dbutils_when_sql_and_sdk_fail(self):
        spark = MagicMock()
        spark.sql.side_effect = Exception("SQL error")
        engine = _make_engine(spark=spark)

        fake_sdk = MagicMock()
        fake_sdk.WorkspaceClient.side_effect = Exception("SDK error")
        sys.modules["databricks.sdk"] = fake_sdk

        context = MagicMock()
        context.tags.return_value.apply.return_value = "fallback.user@company.com"
        engine.dbutils.notebook.entry_point.getDbutils.return_value.notebook.return_value.getContext.return_value = context

        with patch.dict("os.environ", {"DATABRICKS_HOST": "https://adb.net", "DATABRICKS_TOKEN": "dapi123"}):
            result = engine._get_clean_username()

        assert result == "fallback_user"

    def test_returns_unknown_user_when_all_strategies_fail(self):
        spark = MagicMock()
        spark.sql.side_effect = Exception("SQL error")
        engine = _make_engine(spark=spark)

        fake_sdk = MagicMock()
        fake_sdk.WorkspaceClient.side_effect = Exception("SDK error")
        sys.modules["databricks.sdk"] = fake_sdk

        engine.dbutils.notebook.entry_point.getDbutils.side_effect = Exception("no context")

        with patch.dict("os.environ", {}, clear=True):
            result = engine._get_clean_username()

        assert result == "unknown_user"

    def test_sdk_not_called_when_no_credentials(self):
        spark = MagicMock()
        spark.sql.side_effect = Exception("SQL error")
        engine = _make_engine(spark=spark)

        fake_sdk = MagicMock()
        sys.modules["databricks.sdk"] = fake_sdk

        engine.dbutils.notebook.entry_point.getDbutils.side_effect = Exception("no context")

        with patch.dict("os.environ", {}, clear=True):
            engine._get_clean_username()

        # WorkspaceClient must not be called without credentials
        fake_sdk.WorkspaceClient.assert_not_called()