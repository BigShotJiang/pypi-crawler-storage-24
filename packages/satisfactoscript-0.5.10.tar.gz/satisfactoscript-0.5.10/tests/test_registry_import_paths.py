"""
Tests for RuleRegistry import path compatibility.
All import paths must resolve to the same singleton class.
"""
from satisfactoscript.core.registry import RuleRegistry as RR_core
from satisfactoscript.registry import RuleRegistry as RR_shim
from satisfactoscript import RuleRegistry as RR_top


def test_all_import_paths_resolve_to_same_class():
    """All three import paths must return the exact same class (same singleton)."""
    assert RR_core is RR_shim
    assert RR_core is RR_top


def test_rule_registered_via_shim_is_visible_everywhere():
    """A rule registered using the shim import must be retrievable from all paths."""
    @RR_shim.register_rule(name="__test_shim_rule__")
    def _my_rule(df):
        return df

    assert RR_core.get_rule("__test_shim_rule__") is _my_rule
    assert RR_top.get_rule("__test_shim_rule__") is _my_rule

    # Cleanup
    RR_core._rules.pop("__test_shim_rule__", None)
