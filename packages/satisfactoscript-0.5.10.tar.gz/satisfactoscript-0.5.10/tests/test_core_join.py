"""
Tests for process_schema JOIN logic.
Key invariant: df_to.columns (AnalyzePlan gRPC) must never be called during join planning.
"""
import pytest
from unittest.mock import MagicMock, call, patch
from satisfactoscript.core.core import SatisfactoEngine


def _make_engine():
    engine = object.__new__(SatisfactoEngine)
    engine.spark = MagicMock()
    engine.config = {}
    return engine


def _joined_df():
    """Return a MagicMock DataFrame that also handles chained .drop()."""
    df = MagicMock(name="joined_df")
    df.drop.return_value = df
    return df


class TestProcessSchemaJoin:

    def test_same_keys_uses_list_join(self):
        """on_from == on_to → join(df_to, on=['id'], how='inner'). No .columns call."""
        df_a = MagicMock(name="df_a")
        df_b = MagicMock(name="df_b")
        joined = _joined_df()
        df_a.join.return_value = joined

        schema = {
            "join": [{
                "table_from": "a",
                "table_to": "b",
                "on_from": "id",
                "on_to": "id",
                "type": "inner",
            }]
        }

        engine = _make_engine()
        result = engine.process_schema(schema, dataframes_in={"a": df_a, "b": df_b})

        df_a.join.assert_called_once_with(df_b, on=["id"], how="inner")
        df_b.columns.assert_not_called()  # ← no AnalyzePlan gRPC
        assert result == joined

    def test_same_keys_list_join_default_left(self):
        """Default join type is 'left'."""
        df_a = MagicMock(name="df_a")
        df_b = MagicMock(name="df_b")
        df_a.join.return_value = _joined_df()

        schema = {
            "join": [{"table_from": "a", "table_to": "b", "on_from": "k", "on_to": "k"}]
        }

        engine = _make_engine()
        engine.process_schema(schema, dataframes_in={"a": df_a, "b": df_b})

        df_a.join.assert_called_once_with(df_b, on=["k"], how="left")

    def test_different_keys_uses_expression_join_and_drop(self):
        """on_from != on_to → expression join, then drop right-side keys. No .columns call."""
        df_a = MagicMock(name="df_a")
        df_b = MagicMock(name="df_b")
        joined = _joined_df()
        df_a.join.return_value = joined

        schema = {
            "join": [{
                "table_from": "a",
                "table_to": "b",
                "on_from": "order_id",
                "on_to": "id",
                "type": "left",
            }]
        }

        engine = _make_engine()
        result = engine.process_schema(schema, dataframes_in={"a": df_a, "b": df_b})

        # join must be called with an expression condition (not a list of strings)
        join_args, join_kwargs = df_a.join.call_args
        assert join_args[0] is df_b
        assert join_args[2] == "left"
        assert "on" not in join_kwargs  # expression-based, not list-based

        # drop must be called on joined df with df_b["id"] reference
        joined.drop.assert_called_once_with(df_b["id"])

        df_b.columns.assert_not_called()  # ← no AnalyzePlan gRPC

    def test_multi_key_same_names(self):
        """Multi-column join with same key names uses list-join."""
        df_a = MagicMock(name="df_a")
        df_b = MagicMock(name="df_b")
        df_a.join.return_value = _joined_df()

        schema = {
            "join": [{
                "table_from": "a",
                "table_to": "b",
                "on_from": ["org", "date"],
                "on_to": ["org", "date"],
                "type": "left",
            }]
        }

        engine = _make_engine()
        engine.process_schema(schema, dataframes_in={"a": df_a, "b": df_b})

        df_a.join.assert_called_once_with(df_b, on=["org", "date"], how="left")
        df_b.columns.assert_not_called()

    def test_multi_key_different_names_drops_all_right_keys(self):
        """Multi-column join with different key names drops all right-side keys."""
        df_a = MagicMock(name="df_a")
        df_b = MagicMock(name="df_b")
        joined = _joined_df()
        df_a.join.return_value = joined

        schema = {
            "join": [{
                "table_from": "a",
                "table_to": "b",
                "on_from": ["org_l", "date_l"],
                "on_to": ["org_r", "date_r"],
                "type": "inner",
            }]
        }

        engine = _make_engine()
        engine.process_schema(schema, dataframes_in={"a": df_a, "b": df_b})

        # drop must receive both right-side key refs
        joined.drop.assert_called_once_with(df_b["org_r"], df_b["date_r"])
        df_b.columns.assert_not_called()
