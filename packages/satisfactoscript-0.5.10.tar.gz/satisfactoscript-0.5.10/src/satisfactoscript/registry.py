"""
Compatibility shim — keeps `from satisfactoscript.registry import RuleRegistry` working.
The canonical location is satisfactoscript.core.registry.
"""
from satisfactoscript.core.registry import RuleRegistry

__all__ = ["RuleRegistry"]
