"""
Utility helpers for rule authoring — compatible with Databricks Connect v2.
"""


def safe_columns(df):
    """
    Returns the column names of a DataFrame without triggering a failing AnalyzePlan RPC.

    On native Databricks (cluster / notebook), this delegates to ``df.columns`` as normal.
    On Databricks Connect v2 from local environments (PyCharm / VS Code on Windows), the
    ``AnalyzePlan`` gRPC call that backs ``df.columns`` can fail with
    ``Missing required field 'UserContext'``.  In that case this function returns an empty
    list so that optional-column branches in business rules are silently skipped rather than
    crashing.  Core transformations (withColumn, filter, write …) are unaffected because they
    go through ``ExecutePlan``, not ``AnalyzePlan``.

    Args:
        df: A PySpark DataFrame.

    Returns:
        list[str]: Column names, or ``[]`` when schema inspection fails locally.
    """
    try:
        return df.columns
    except Exception as e:
        if "UserContext" in str(e) or "INVALID_ARGUMENT" in str(e):
            return []
        raise
