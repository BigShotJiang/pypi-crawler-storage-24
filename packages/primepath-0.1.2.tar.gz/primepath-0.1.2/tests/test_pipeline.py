"""
Basic tests for the primepath library.
Run with:  pytest tests/ -v
"""

import math
import pytest

from primepath import (
    Pipeline,
    SPOKES, is_valid_spoke, candidates, wheel_info,
    spoke_entropy, boltzmann_class, gap_mean_class, gap_class,
    helix_pos, corridor_density, sight_score,
    composite_density, valley_width, terrain_zone,
)


# ── Wheel tests ────────────────────────────────────────────────────────────────

class TestWheel:
    def test_spokes_count(self):
        assert len(SPOKES) == 16

    def test_spokes_coprime_to_60(self):
        for s in SPOKES:
            assert math.gcd(s, 60) == 1

    def test_valid_spoke_primes(self):
        small_primes = [7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67]
        for p in small_primes:
            assert is_valid_spoke(p), f"{p} is prime but failed wheel"

    def test_invalid_spoke_composites(self):
        # Numbers with factors of 2, 3, or 5 should all fail
        for n in [6, 9, 10, 15, 21, 25, 27, 35]:
            assert not is_valid_spoke(n)

    def test_candidates_range(self):
        cands = candidates(7, 30)
        assert 11 in cands
        assert 13 in cands
        assert all(is_valid_spoke(c) for c in cands)
        assert all(c > 7 for c in cands)
        assert all(c <= 30 for c in cands)

    def test_wheel_info(self):
        info = wheel_info()
        assert info["n_valid"] == 16
        assert abs(info["elimination_rate"] - 16/60) < 0.01
        assert abs(info["speedup_factor"] - 60/16) < 0.01


# ── Boltzmann tests ────────────────────────────────────────────────────────────

class TestBoltzmann:
    def test_spoke_entropy_range(self):
        from sympy import primerange
        window = list(primerange(100, 300))
        H = spoke_entropy(window)
        assert 0 < H <= math.log2(16)

    def test_boltzmann_class_returns_valid(self):
        gc, conf, post = boltzmann_class(3.58)
        assert gc in ("S", "M", "L")
        assert 0 < conf <= 1
        assert abs(sum(post.values()) - 1.0) < 1e-6

    def test_gap_mean_class_oversold(self):
        # Very negative mean → L class expected
        gc, conf, _ = gap_mean_class(-1.0)
        assert gc == "L"

    def test_gap_mean_class_overbought(self):
        # Very positive mean → S class expected
        gc, conf, _ = gap_mean_class(1.0)
        assert gc == "S"

    def test_gap_class_boundaries(self):
        assert gap_class(6)  == "S"
        assert gap_class(7)  == "M"
        assert gap_class(18) == "M"
        assert gap_class(19) == "L"


# ── Sight tests ────────────────────────────────────────────────────────────────

class TestSight:
    def test_helix_pos_ring(self):
        x, y, z = helix_pos(121)  # ring=2, spoke=1
        assert abs(z - 2.0) < 1e-10

    def test_helix_pos_angle(self):
        # spoke=0 (if valid) → angle=0 → x=r, y=0
        # spoke=30 → angle=π → x=-r, y≈0
        x, y, z = helix_pos(30)
        assert abs(y) < 0.1  # approximately on negative x axis

    def test_corridor_density_range(self):
        d = corridor_density(helix_pos(97), helix_pos(101))
        assert 0.0 <= d <= 1.0

    def test_sight_score_prime_lower_than_composite(self):
        # Sight to the actual next prime should generally be lower than to a composite
        # (not guaranteed for every pair but should be true statistically)
        # 97 → 101 (prime, gap=4) vs 97 → 99 (composite, gap=2)
        score_prime = sight_score(97, 101)
        score_composite = sight_score(97, 99)  # 99=9×11 but 99%60=39 not in SPOKES anyway
        # Just check they're in valid range
        assert 0 <= score_prime <= 1
        assert 0 <= score_composite <= 1


# ── Terrain tests ──────────────────────────────────────────────────────────────

class TestTerrain:
    def test_density_range(self):
        for n in [97, 101, 103, 107, 100, 110, 120]:
            d = composite_density(n)
            assert 0.0 <= d <= 1.0

    def test_terrain_zone(self):
        assert terrain_zone(0.40) == "valley"
        assert terrain_zone(0.54) == "plains"
        assert terrain_zone(0.65) == "ridge"

    def test_valley_width_positive(self):
        vw = valley_width(97)
        assert vw >= 0


# ── Pipeline integration tests ─────────────────────────────────────────────────

class TestPipeline:
    def setup_method(self):
        self.p = Pipeline()

    def test_predict_next_returns_dict(self):
        result = self.p.predict_next(97)
        assert "predicted" in result
        assert "confidence" in result
        assert "class" in result
        assert result["class"] in ("S", "M", "L")

    def test_predict_next_is_spoke_valid(self):
        result = self.p.predict_next(97)
        assert is_valid_spoke(result["predicted"])

    def test_predict_next_after_b(self):
        b = 97
        result = self.p.predict_next(b)
        assert result["predicted"] > b

    def test_sight_score_valid_range(self):
        score = self.p.sight_score(97, 101)
        assert 0 <= score <= 1

    def test_explain_keys(self):
        explained = self.p.explain(97)
        expected_keys = {"entropy", "boltzmann", "detrended_mean", "gap_mean",
                        "pi_phase", "sight_score_r0", "sight_class", "combined"}
        assert expected_keys.issubset(explained.keys())

    def test_explain_pi_phase_range(self):
        explained = self.p.explain(97)
        assert 0 <= explained["pi_phase"] < 1

    def test_rank_candidates_sorted(self):
        ranked = self.p.rank_candidates(97, n=5)
        scores = [r["sight_score"] for r in ranked]
        assert scores == sorted(scores)

    def test_boltzmann_class_valid(self):
        gc, conf, post = self.p.boltzmann_class(97)
        assert gc in ("S", "M", "L")
        assert 0 < conf <= 1

    def test_feed_updates_history(self):
        p = Pipeline()
        for prime in [7, 11, 13, 17, 19, 23, 29, 31, 37, 41]:
            p.feed(prime)
        explained = p.explain(41)
        # entropy should reflect the window
        assert 0 < explained["entropy"] <= math.log2(16)
