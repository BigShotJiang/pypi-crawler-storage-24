"""
PrimePath
─────────
A geometric investigation of prime numbers.

Treats composite numbers as terrain and primes as the path navigating it.
Connects number theory to statistical mechanics, wave physics, and 3D visibility geometry.

Quick start
───────────
>>> from primepath import Pipeline
>>> p = Pipeline()
>>> p.predict_next(499_979)
{'predicted': 499993, 'confidence': 0.54, 'class': 'S', ...}

>>> p.sight_score(499_979, 499_993)
0.06

>>> p.explain(499_979)
{'entropy': 3.582, 'boltzmann': ('M', 0.36, {...}), ...}

Modules
───────
- primepath.wheel      — mod-60 coprime filter (3.75× speedup)
- primepath.terrain    — composite density, valley width, sieve ridges
- primepath.boltzmann  — spoke entropy and gap-mean classifiers
- primepath.sight      — 3D visibility and corridor density
- primepath.pipeline   — combined five-signal predictor

Results
───────
- Theoretical ceiling:           48.94 %
- Five-signal pipeline:          48.99 %  (+21.0 pp over baseline)
- 3D sight alone:                42.36 %  (+14.4 pp)
- Boltzmann entropy alone:       35.16 %  (+7.2 pp)
- Gap mean trend alone:          34.24 %  (+6.5 pp)
- Baseline (first spoke only):   27.7 %

All three primary signals are fully independent (cross-correlations < 0.02).

References
──────────
- GitHub:   https://github.com/viewbuild/primepath
- Website:  https://viewbuild.com/primepath
- Author:   ViewBuild, Tasmania, Australia
"""

from .pipeline import Pipeline
from .wheel    import (
    SPOKES, is_valid_spoke, candidates, candidate_stream, wheel_info
)
from .boltzmann import (
    spoke_entropy, boltzmann_class, gap_mean_class, combined_class,
    gap_class, GAP_CLASS_WINDOWS
)
from .sight import (
    helix_pos, corridor_density, sight_score, frenet_frame, rank_by_sight
)
from .terrain import (
    composite_density, valley_width, terrain_zone, terrain_map, sieve_ridges
)

__version__ = "0.1.0"
__author__  = "ViewBuild"
__all__ = [
    # High-level
    "Pipeline",
    # Wheel
    "SPOKES", "is_valid_spoke", "candidates", "candidate_stream", "wheel_info",
    # Boltzmann
    "spoke_entropy", "boltzmann_class", "gap_mean_class", "combined_class",
    "gap_class", "GAP_CLASS_WINDOWS",
    # Sight
    "helix_pos", "corridor_density", "sight_score", "frenet_frame", "rank_by_sight",
    # Terrain
    "composite_density", "valley_width", "terrain_zone", "terrain_map", "sieve_ridges",
]
