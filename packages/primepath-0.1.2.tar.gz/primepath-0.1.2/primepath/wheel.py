"""
primepath.wheel
───────────────
The mod-60 coprime wheel — the foundation of the pipeline.

Every prime > 5 satisfies n % 60 ∈ SPOKES.  This single check
eliminates 73.3 % of integers before any primality test is needed,
giving a deterministic 3.75× candidate reduction with zero false negatives.
"""

from __future__ import annotations
from typing import Iterator

# The 16 residues coprime to 60 (i.e. gcd(r, 60) == 1)
SPOKES: frozenset[int] = frozenset(
    [1, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 49, 53, 59]
)

# Sieve of Atkin quadratic form for each spoke
ATKIN_FORM: dict[int, str] = {
    s: ("4x²+y²" if s in {1, 13, 17, 29, 37, 41, 49, 53}
        else "3x²-y²" if s in {11, 23, 47, 59}
        else "3x²+y²")
    for s in SPOKES
}


def is_valid_spoke(n: int) -> bool:
    """Return True iff n could be prime (passes the mod-60 wheel filter)."""
    return n % 60 in SPOKES


def candidates(after: int, limit: int) -> list[int]:
    """
    Return all spoke-valid integers in the half-open range (after, limit].

    These are the candidates that need a primality test — everything else
    is provably composite by the mod-60 wheel.

    Parameters
    ----------
    after : int
        Start of search window (exclusive).
    limit : int
        End of search window (inclusive).

    Returns
    -------
    list[int]
        Spoke-valid integers in (after, limit].

    Example
    -------
    >>> candidates(7, 30)
    [11, 13, 17, 19, 23, 29]
    """
    return [n for n in range(after + 1, limit + 1) if n % 60 in SPOKES]


def candidate_stream(after: int) -> Iterator[int]:
    """
    Infinite iterator of spoke-valid integers starting just after `after`.

    Example
    -------
    >>> gen = candidate_stream(7)
    >>> [next(gen) for _ in range(6)]
    [11, 13, 17, 19, 23, 29]
    """
    n = after + 1
    while True:
        if n % 60 in SPOKES:
            yield n
        n += 1


def wheel_info() -> dict:
    """Return a summary of wheel statistics."""
    total = 60
    eliminated = total - len(SPOKES)
    return {
        "period": total,
        "valid_spokes": sorted(SPOKES),
        "n_valid": len(SPOKES),
        "n_eliminated": eliminated,
        "elimination_rate": eliminated / total,
        "speedup_factor": total / len(SPOKES),
    }
