"""
primepath.sight
───────────────
3D visibility — view from the prime.

Each prime p is placed on a 3D helix at position:
    (r·cos θ,  r·sin θ,  r)    where  r = p // 60,  θ = 2π(p % 60)/60

The composite "solid" fills 3D space — each integer n at its helix position
is opaque (composite) or transparent (prime).

Ray casting: from position b toward each candidate c, sample the composite
density along the corridor.  Low density = clear line of sight = c is likely
the next prime.

Key finding: Cohen's d = −6.91 between corridor density when c is prime
vs when c is composite.  This is the strongest single signal in the investigation.

Combined with Boltzmann + gap mean: 48.99% accuracy ≈ theoretical ceiling (48.94%).
"""

from __future__ import annotations
import math
from typing import Sequence

from .wheel import SPOKES, candidates

_SPOKE_LIST = sorted(SPOKES)
_SPOKE_SET  = frozenset(SPOKES)
PI          = math.pi


# ── Coordinate system ─────────────────────────────────────────────────────────

def helix_pos(n: int) -> tuple[float, float, float]:
    """
    3D helix position for integer n.

    Returns (x, y, z) where z = ring = n // 60, and (x, y) are the
    Cartesian coordinates on the corresponding helix ring.

    Parameters
    ----------
    n : int
        Any positive integer.

    Returns
    -------
    tuple[float, float, float]
        (x, y, z) position on the equal-scale helix.

    Example
    -------
    >>> helix_pos(61)      # ring=1, spoke=1
    (0.9952..., 0.0980..., 1.0)
    >>> helix_pos(121)     # ring=2, spoke=1
    (1.9904..., 0.1961..., 2.0)
    """
    r = max(n // 60, 1)
    t = 2 * PI * (n % 60) / 60
    return (r * math.cos(t), r * math.sin(t), float(r))


# ── Sieve helpers ─────────────────────────────────────────────────────────────

_SIEVE: dict[int, list[bool]] = {}


def _get_sieve(limit: int) -> list[bool]:
    if limit not in _SIEVE:
        sv = [True] * (limit + 1)
        sv[0] = sv[1] = False
        for i in range(2, int(limit ** 0.5) + 1):
            if sv[i]:
                for j in range(i * i, limit + 1, i):
                    sv[j] = False
        _SIEVE[limit] = sv
    return _SIEVE[limit]


# ── Ray sampling ──────────────────────────────────────────────────────────────

def corridor_density(
    origin: tuple[float, float, float],
    dest: tuple[float, float, float],
    n_samples: int = 12,
    stop_fraction: float = 0.85,
) -> float:
    """
    Composite density along the 3D corridor from origin toward dest.

    Samples n_samples points along the ray, stopping at stop_fraction of the
    way to dest (so the destination cell itself is excluded — avoiding
    circular reasoning).  At each sample point the 3 nearest spoke-valid
    integers are checked for primality.

    Parameters
    ----------
    origin : (x, y, z)
        Starting position (prime b).
    dest : (x, y, z)
        Target position (candidate c).
    n_samples : int
        Number of sample points along the ray.
    stop_fraction : float
        Fraction of the full ray length to sample (default 0.85).

    Returns
    -------
    float
        Composite density in [0, 1].
        < 0.3  →  clear corridor  →  dest is likely prime
        > 0.4  →  blocked          →  dest is likely composite

    Example
    -------
    >>> b = helix_pos(97)
    >>> c = helix_pos(101)    # next prime after 97
    >>> corridor_density(b, c)
    0.05...  # very clear — 97→101 is a small-gap prime
    """
    ox, oy, oz = origin
    dx, dy, dz = dest[0] - ox, dest[1] - oy, dest[2] - oz
    dn = math.sqrt(dx * dx + dy * dy + dz * dz)
    if dn < 1e-10:
        return 0.5

    ux, uy, uz = dx / dn, dy / dn, dz / dn
    step = dn / n_samples
    limit = (int(dest[2]) + 5) * 60 + 60
    sv = _get_sieve(limit)

    comp = 0; total = 0
    for k in range(1, n_samples + 1):
        t = k * step * stop_fraction
        px = ox + ux * t
        py = oy + uy * t
        pz = oz + uz * t

        ring = max(1, round(pz))
        angle = math.atan2(py, px)
        if angle < 0:
            angle += 2 * PI
        s1 = round(angle / (2 * PI) * 60) % 60

        for s in (s1, (s1 + 1) % 60, (s1 - 1) % 60):
            if s not in _SPOKE_SET:
                continue
            m = ring * 60 + s
            if 7 <= m <= limit:
                if not sv[m]:
                    comp += 1
                total += 1

    return comp / total if total else 0.5


def sight_score(b: int, candidate: int, n_samples: int = 12) -> float:
    """
    3D sight score from prime b toward a candidate integer.

    A convenience wrapper around :func:`corridor_density`.

    Parameters
    ----------
    b : int
        The current prime.
    candidate : int
        An integer candidate to test.
    n_samples : int
        Number of ray samples.

    Returns
    -------
    float
        Corridor density (low = clear = likely prime).

    Example
    -------
    >>> sight_score(97, 101)    # actual next prime: clear
    0.04...
    >>> sight_score(97, 103)    # composite in corridor: blocked
    0.35...
    """
    return corridor_density(helix_pos(b), helix_pos(candidate), n_samples)


def frenet_frame(
    a: int, b: int
) -> tuple[
    tuple[float, float, float],
    tuple[float, float, float],
    tuple[float, float, float],
]:
    """
    Frenet frame (T, N, B) at prime b given previous prime a.

    T = unit tangent (direction of travel a→b)
    B = unit binormal (T × ẑ, normalised)
    N = unit normal (B × T)

    Parameters
    ----------
    a, b : int
        Consecutive primes (a < b).

    Returns
    -------
    tuple of three (x,y,z) unit vectors
        (T, N, B)

    Example
    -------
    >>> T, N, B = frenet_frame(89, 97)
    """
    pa = helix_pos(a)
    pb = helix_pos(b)

    vx, vy, vz = pb[0] - pa[0], pb[1] - pa[1], pb[2] - pa[2]
    vn = math.sqrt(vx*vx + vy*vy + vz*vz) or 1e-10
    T = (vx / vn, vy / vn, vz / vn)

    # B = T × ẑ
    bx, by, bz = T[1] * 1 - T[2] * 0, T[2] * 0 - T[0] * 1, T[0] * 0 - T[1] * 0
    bn = math.sqrt(bx*bx + by*by + bz*bz) or 1e-10
    B = (bx / bn, by / bn, bz / bn)

    # N = B × T
    nx = B[1]*T[2] - B[2]*T[1]
    ny = B[2]*T[0] - B[0]*T[2]
    nz = B[0]*T[1] - B[1]*T[0]
    nn = math.sqrt(nx*nx + ny*ny + nz*nz) or 1e-10
    N = (nx / nn, ny / nn, nz / nn)

    return T, N, B


def rank_by_sight(b: int, limit: int | None = None, n_candidates: int = 15) -> list[dict]:
    """
    Score and rank spoke-valid candidates after b by corridor density.

    Parameters
    ----------
    b : int
        The current prime.
    limit : int, optional
        Search upper bound.  Defaults to b + max(130, ln(b)*9).
    n_candidates : int
        Maximum number of candidates to return.

    Returns
    -------
    list[dict]
        Candidates sorted by sight score (lowest = clearest = most likely prime).
        Each dict: {n, sight_score, gap, is_prime}.

    Example
    -------
    >>> ranked = rank_by_sight(97)
    >>> ranked[0]   # clearest corridor
    {'n': 101, 'sight_score': 0.04, 'gap': 4, 'is_prime': True}
    """
    if limit is None:
        limit = b + max(130, int(math.log(b) * 9))

    cands = candidates(b, limit)[:n_candidates]
    sieve_lim = limit + 60
    sv = _get_sieve(sieve_lim)

    results = []
    for c in cands:
        score = sight_score(b, c)
        results.append({
            "n":           c,
            "sight_score": round(score, 4),
            "gap":         c - b,
            "is_prime":    bool(sv[c]) if c <= sieve_lim else None,
        })

    return sorted(results, key=lambda x: x["sight_score"])
