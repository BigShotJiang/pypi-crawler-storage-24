"""
primepath.terrain
─────────────────
Composite landscape analysis.

Treats the base-60 spiral as a 2D grid of (ring, spoke) cells.
Each cell is either prime (valley floor) or composite (terrain height).
Local composite density measures how open the terrain is around each prime.

Key finding: valley width (adjacent prime density) separates gap classes
with Cohen's d = 0.66 — primes in wide valleys predict small next gaps.
"""

from __future__ import annotations
import math
from typing import Sequence

from .wheel import SPOKES, candidates

_SPOKE_LIST = sorted(SPOKES)
_SPOKE_IDX  = {s: i for i, s in enumerate(_SPOKE_LIST)}


# ── Sieve (local, lazy) ────────────────────────────────────────────────────────

def _small_sieve(limit: int) -> list[bool]:
    """Return a boolean sieve up to limit."""
    sv = [True] * (limit + 1)
    sv[0] = sv[1] = False
    for i in range(2, int(limit ** 0.5) + 1):
        if sv[i]:
            for j in range(i * i, limit + 1, i):
                sv[j] = False
    return sv


_SIEVE_CACHE: dict[int, list[bool]] = {}


def _get_sieve(limit: int) -> list[bool]:
    if limit not in _SIEVE_CACHE:
        _SIEVE_CACHE[limit] = _small_sieve(limit)
    return _SIEVE_CACHE[limit]


# ── Core terrain functions ─────────────────────────────────────────────────────

def composite_density(n: int, ring_radius: int = 5) -> float:
    """
    Composite density at integer n in the (ring, spoke) grid.

    Measures the fraction of nearby cells occupied by composites.
    Low density = valley (prime-rich), high density = ridge (composite barrier).

    Parameters
    ----------
    n : int
        The integer whose terrain to measure.
    ring_radius : int
        Number of rings to include on each side.

    Returns
    -------
    float
        Composite density in [0, 1].  <0.47 = valley, >0.60 = ridge.

    Example
    -------
    >>> composite_density(97)        # prime in a valley
    0.43...
    >>> composite_density(100)       # composite on a ridge
    0.65...
    """
    ring_n = max(n // 60, 1)
    limit  = (ring_n + ring_radius) * 60 + 60
    sv     = _get_sieve(limit)

    comp = 0; total = 0
    for r in range(max(1, ring_n - ring_radius), ring_n + ring_radius + 1):
        for s in _SPOKE_LIST:
            m = r * 60 + s
            if m < 7 or m > limit:
                continue
            total += 1
            if not sv[m]:
                comp += 1

    return comp / total if total else 0.5


def valley_width(n: int, ring_radius: int = 3) -> int:
    """
    Count prime neighbours of n in a ±ring_radius neighbourhood.

    A higher count means n sits in a wide valley; lower means a narrow corridor.
    Wide valley → small next gap (Cohen's d = 0.66 vs gap class S).

    Parameters
    ----------
    n : int
        A prime to measure.
    ring_radius : int
        Ring neighbourhood radius.

    Returns
    -------
    int
        Number of other primes in the neighbourhood.

    Example
    -------
    >>> valley_width(97)
    42
    """
    ring_n = n // 60
    limit  = (ring_n + ring_radius) * 60 + 60
    sv     = _get_sieve(limit)

    count = 0
    for r in range(max(1, ring_n - ring_radius), ring_n + ring_radius + 1):
        for s in _SPOKE_LIST:
            m = r * 60 + s
            if m < 7 or m > limit or m == n:
                continue
            if sv[m]:
                count += 1
    return count


def terrain_zone(density: float) -> str:
    """
    Classify a composite density value into a terrain zone.

    Returns
    -------
    str
        One of 'valley', 'plains', or 'ridge'.

    Example
    -------
    >>> terrain_zone(0.43)
    'valley'
    >>> terrain_zone(0.65)
    'ridge'
    """
    if density < 0.47:
        return "valley"
    if density > 0.60:
        return "ridge"
    return "plains"


def terrain_map(
    n: int,
    ring_radius: int = 5,
    spoke_radius: int = 3,
) -> list[dict]:
    """
    Return a grid of terrain cells around integer n.

    Each cell is a dict with keys: ring, spoke, n, is_prime, density, zone.

    Parameters
    ----------
    n : int
        Centre of the terrain window.
    ring_radius : int
        Rings to show on each side of n's ring.
    spoke_radius : int
        Spokes to show on each side of n's spoke index.

    Returns
    -------
    list[dict]
        One entry per (ring, spoke) cell, row-major order.

    Example
    -------
    >>> cells = terrain_map(97, ring_radius=2, spoke_radius=2)
    >>> cells[0].keys()
    dict_keys(['ring', 'spoke', 'n', 'is_prime', 'density', 'zone'])
    """
    ring_n = max(n // 60, 1)
    si_n   = _SPOKE_IDX.get(n % 60, 0)
    limit  = (ring_n + ring_radius + 1) * 60 + 60
    sv     = _get_sieve(limit)

    cells = []
    for r in range(max(1, ring_n - ring_radius), ring_n + ring_radius + 1):
        for di in range(-spoke_radius, spoke_radius + 1):
            si   = (si_n + di) % 16
            s    = _SPOKE_LIST[si]
            m    = r * 60 + s
            if m < 7 or m > limit:
                continue
            d = composite_density(m, ring_radius=2)
            cells.append({
                "ring":     r,
                "spoke":    s,
                "n":        m,
                "is_prime": bool(sv[m]),
                "density":  round(d, 4),
                "zone":     terrain_zone(d),
            })
    return cells


def sieve_ridges(small_prime: int, max_rings: int = 20) -> list[dict]:
    """
    Return the composite positions created by a single small prime p.

    Each multiple of p that falls on a valid spoke is a 'ridge cell' —
    a composite that blocks the prime path.

    Parameters
    ----------
    small_prime : int
        A prime ≥ 7 whose multiples to trace.
    max_rings : int
        How many rings to scan.

    Returns
    -------
    list[dict]
        One entry per blocked cell: {n, ring, spoke, factor}.

    Example
    -------
    >>> ridges = sieve_ridges(7, max_rings=5)
    >>> ridges[0]
    {'n': 49, 'ring': 0, 'spoke': 49, 'factor': 7}
    """
    p = small_prime
    ridge = []
    limit = max_rings * 60 + 60
    for k in range(p, limit // p + 1):
        m = p * k
        if m % 60 in SPOKES and m >= 7:
            ridge.append({
                "n":      m,
                "ring":   m // 60,
                "spoke":  m % 60,
                "factor": p,
            })
    return ridge
