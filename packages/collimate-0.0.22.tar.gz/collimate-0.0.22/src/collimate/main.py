def run():
    print("collimate!")


if __name__ == "__main__":
    run()
