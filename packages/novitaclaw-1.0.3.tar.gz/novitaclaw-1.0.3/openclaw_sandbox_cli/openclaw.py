"""OpenClaw configuration and service management."""

import json
import os
import time

from .const import API_KEY_PLACEHOLDER
from .output import GatewayError, GatewayTimeoutError
from .sandbox import SandboxManager
from .utils import print_error, print_info, print_success

GATEWAY_PORT = 18789
OPENCLAW_CONFIG_PATH = "/home/user/.openclaw/openclaw.json"


def load_openclaw_config_template() -> dict:
    """Load openclaw.example.json as config template."""
    example_path = os.path.join(os.path.dirname(__file__), "openclaw.example.json")
    with open(example_path) as f:
        return json.load(f)


def generate_openclaw_config(api_key: str, gateway_token: str) -> dict:
    """Generate OpenClaw configuration by injecting API key and gateway token."""
    config = load_openclaw_config_template()

    # Replace placeholder API key in all providers
    for provider in config.get("models", {}).get("providers", {}).values():
        if provider.get("apiKey") == API_KEY_PLACEHOLDER:
            provider["apiKey"] = api_key

    # Set gateway config — use token auth so Control UI can auto-authenticate via URL
    config.setdefault("gateway", {})
    config["gateway"]["mode"] = "local"
    config["gateway"]["auth"] = {"mode": "token", "token": gateway_token}
    # Allow host-header origin fallback and disable device pairing for remote sandbox access
    config["gateway"]["controlUi"] = {
        "dangerouslyAllowHostHeaderOriginFallback": True,
        "dangerouslyDisableDeviceAuth": True,
    }

    return config


def configure_openclaw(manager: SandboxManager, api_key: str, gateway_token: str):
    """Write OpenClaw configuration to the sandbox."""
    config = generate_openclaw_config(api_key, gateway_token)
    config_content = json.dumps(config, indent=2)

    # Ensure config directory exists with secure permissions (700 = owner only).
    # The sandbox base image may use umask 0000, so explicit chmod is required
    # to prevent OpenClaw's security audit from flagging world-writable paths
    # and refusing to load channel plugins (Telegram, Discord, etc.).
    manager.run_command(
        "mkdir -p /home/user/.openclaw && chmod 700 /home/user/.openclaw",
        timeout=10,
    )

    print_info("Writing OpenClaw configuration to sandbox...")
    manager.write_file(OPENCLAW_CONFIG_PATH, config_content)
    manager.run_command("chmod 600 {config}".format(config=OPENCLAW_CONFIG_PATH), timeout=10)
    print_success("OpenClaw configuration written")

    # Export OPENCLAW_CONFIG_PATH globally so all openclaw CLI commands
    # (pairing, doctor, status, etc.) find the config without manual flags.
    _export_env = (
        'grep -q OPENCLAW_CONFIG_PATH /home/user/.bashrc 2>/dev/null'
        ' || echo \'export OPENCLAW_CONFIG_PATH="{config}"\' >> /home/user/.bashrc'
    ).format(config=OPENCLAW_CONFIG_PATH)
    manager.run_command(_export_env, timeout=10)

    # Fix world-writable OpenClaw extensions directory.
    # The sandbox template uses chmod a+w on node_modules so the runtime user
    # can run npm install -g.  This leaves extensions/ at mode 777, which causes
    # OpenClaw to block plugin loading (Telegram, Discord, etc.) for security.
    # We re-copy the directory so it becomes user-owned, then set safe permissions.
    print_info("Fixing OpenClaw extensions permissions...")
    _fix_ext_cmd = (
        "EXT=/usr/local/lib/node_modules/openclaw/extensions"
        " && if [ -d \"$EXT\" ]; then"
        "   cp -r \"$EXT\" /tmp/_oc_ext_fix"
        "   && rm -rf \"$EXT\""
        "   && mv /tmp/_oc_ext_fix \"$EXT\""
        "   && find \"$EXT\" -type d -exec chmod 755 {} +"
        "   && find \"$EXT\" -type f -exec chmod 644 {} +"
        "   && echo ok; fi"
    )
    result = manager.run_command(_fix_ext_cmd, timeout=30)
    if result and result.stdout and "ok" in result.stdout:
        print_success("OpenClaw extensions permissions fixed")
    else:
        print_info("Extensions directory not found or already fixed")

    # Start gateway in background via nohup so process persists
    print_info("Starting OpenClaw Gateway...")
    manager.run_command(
        "nohup bash -c 'OPENCLAW_CONFIG_PATH={config} openclaw gateway --port {port} --bind lan'"
        " > /tmp/gateway.log 2>&1 &".format(config=OPENCLAW_CONFIG_PATH, port=GATEWAY_PORT),
        timeout=10,
    )

    # Wait for gateway to be ready — poll every 1s, up to 120 checks (~120s max).
    max_checks = 120

    for i in range(max_checks):
        result = manager.run_command(
            'curl -s --max-time 2 -o /dev/null -w "%{{http_code}}" http://localhost:{port}/ 2>/dev/null; echo'.format(
                port=GATEWAY_PORT
            ),
            timeout=10,
        )
        if result and result.stdout and result.stdout.strip() == "200":
            print_success("OpenClaw Gateway is listening on port {port}".format(port=GATEWAY_PORT))
            _start_device_auto_approve(manager)
            return
        print_info("  Waiting for Gateway to start ({i}/{total})...".format(
            i=i + 1, total=max_checks,
        ))
        time.sleep(1)

    # Print gateway log on failure for debugging
    log_result = manager.run_command("tail -30 /tmp/gateway.log 2>&1 || true", timeout=5)
    log_text = ""
    if log_result and log_result.stdout and log_result.stdout.strip():
        log_text = log_result.stdout.strip()
        print_error("Gateway log:\n{log}".format(log=log_text))
    raise GatewayTimeoutError(
        "Gateway did not start in time. Check sandbox logs." +
        (f"\n{log_text}" if log_text else "")
    )


_DEVICE_AUTO_APPROVE_TEMPLATE = (
    "#!/bin/bash\n"
    "# Auto-approve device pairing requests for remote sandbox access.\n"
    "# The sandbox is already protected by gateway token auth.\n"
    "export OPENCLAW_CONFIG_PATH=\"{config}\"\n"
    "while true; do\n"
    "  openclaw devices list --json 2>/dev/null"
    " | node -e 'let d=\"\";process.stdin.on(\"data\",c=>d+=c);"
    "process.stdin.on(\"end\",()=>{{try{{JSON.parse(d).pending"
    ".forEach(p=>console.log(p.requestId))}}catch(e){{}}}})'  "
    " | while read -r rid; do\n"
    "    openclaw devices approve \"$rid\" 2>/dev/null\n"
    "  done\n"
    "  sleep 2\n"
    "done\n"
)

DEVICE_AUTO_APPROVE_PATH = "/tmp/device-auto-approve.sh"


def _start_device_auto_approve(manager: SandboxManager):
    """Start a background daemon that auto-approves device pairing requests.

    OpenClaw requires device pairing for remote connections (TUI, new browsers).
    This daemon polls for pending requests and approves them automatically,
    since the sandbox is already protected by gateway token auth.
    """
    script = _DEVICE_AUTO_APPROVE_TEMPLATE.format(config=OPENCLAW_CONFIG_PATH)
    manager.write_file(DEVICE_AUTO_APPROVE_PATH, script)
    manager.run_command(
        "nohup bash {path} > /tmp/device-auto-approve.log 2>&1 &".format(path=DEVICE_AUTO_APPROVE_PATH),
        timeout=10,
    )
    print_success("Device auto-approval daemon started")


def update_openclaw_config(manager: SandboxManager, api_key: str, gateway_token: str = None):
    """Update OpenClaw configuration in-place and signal gateway to reload.

    Reads the existing gateway token if not provided, regenerates the config
    with the new API key, writes it, and sends SIGUSR1 for hot reload.
    """
    if not gateway_token:
        gateway_token = get_gateway_token(manager)
    if not gateway_token:
        raise GatewayError(
            "Cannot determine gateway token. Provide --gateway-token or "
            "ensure the sandbox has a running gateway with a configured token."
        )

    config = generate_openclaw_config(api_key, gateway_token)
    config_content = json.dumps(config, indent=2)

    print_info("Writing updated OpenClaw configuration...")
    manager.write_file(OPENCLAW_CONFIG_PATH, config_content)
    manager.run_command(
        "chmod 600 {config}".format(config=OPENCLAW_CONFIG_PATH), timeout=10,
    )
    print_success("OpenClaw configuration updated")

    # SIGUSR1 triggers graceful in-process reload
    _signal_gateway(manager, "USR1")
    print_success("Gateway reload signal sent (SIGUSR1)")


def restart_gateway(manager: SandboxManager):
    """Kill the running gateway and start a fresh one.

    Use when hot reload is insufficient (e.g. gateway.* field changes).
    """
    print_info("Stopping existing gateway process...")
    result = manager.run_command(
        "pkill -f 'openclaw gateway' 2>/dev/null; sleep 1; "
        "pkill -9 -f 'openclaw gateway' 2>/dev/null; true",
        timeout=15,
    )

    print_info("Starting OpenClaw Gateway...")
    manager.run_command(
        "nohup bash -c 'OPENCLAW_CONFIG_PATH={config} openclaw gateway --port {port} --bind lan'"
        " > /tmp/gateway.log 2>&1 &".format(config=OPENCLAW_CONFIG_PATH, port=GATEWAY_PORT),
        timeout=10,
    )

    max_checks = 60
    for i in range(max_checks):
        result = manager.run_command(
            'curl -s --max-time 2 -o /dev/null -w "%{{http_code}}" '
            'http://localhost:{port}/ 2>/dev/null; echo'.format(port=GATEWAY_PORT),
            timeout=10,
        )
        if result and result.stdout and result.stdout.strip() == "200":
            print_success("Gateway restarted and listening on port {port}".format(port=GATEWAY_PORT))
            _start_device_auto_approve(manager)
            return
        print_info("  Waiting for Gateway to start ({i}/{total})...".format(
            i=i + 1, total=max_checks,
        ))
        time.sleep(1)

    log_result = manager.run_command("tail -30 /tmp/gateway.log 2>&1 || true", timeout=5)
    log_text = ""
    if log_result and log_result.stdout and log_result.stdout.strip():
        log_text = log_result.stdout.strip()
        print_error("Gateway log:\n{log}".format(log=log_text))
    raise GatewayTimeoutError(
        "Gateway did not start after restart. Check sandbox logs." +
        ("\n" + log_text if log_text else "")
    )


def _signal_gateway(manager: SandboxManager, signal: str):
    """Send a signal to the gateway process."""
    result = manager.run_command(
        "pkill -{sig} -f 'openclaw gateway' 2>&1; echo $?".format(sig=signal),
        timeout=10,
    )
    if result and result.stdout and result.stdout.strip().endswith("1"):
        raise GatewayError(
            "No running gateway process found. Use 'gateway restart' to start one."
        )


def get_gateway_token(manager: SandboxManager) -> str:
    """Read the gateway token from the sandbox's OpenClaw config."""
    content = manager.read_file(OPENCLAW_CONFIG_PATH)
    if content:
        try:
            config = json.loads(content)
            return config.get("gateway", {}).get("auth", {}).get("token", "")
        except (json.JSONDecodeError, AttributeError):
            pass
    return ""


def get_public_urls(manager: SandboxManager) -> dict:
    """Get public access URLs for Gateway and Web UI."""
    host = manager.sandbox.get_host(GATEWAY_PORT)
    return {
        "gateway_ws": "wss://{host}".format(host=host),
        "webui": "https://{host}".format(host=host),
    }
