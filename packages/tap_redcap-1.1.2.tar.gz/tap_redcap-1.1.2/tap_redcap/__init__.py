"""Singer tap for streaming RedCAP data."""
