"""Stream type classes for tap-redcap."""

from singer_sdk import Tap
from singer_sdk import typing as th  # JSON Schema typing helpers

from tap_redcap.client import RedCapStream


class RedCapFormStream(RedCapStream):
    """A streaming client of RedCAP survey form results."""

    def __init__(self, tap: Tap, form: str):
        """Initialize for survey form streaming client."""
        super().__init__(tap, f"stream_{form}")
        self.forms = form

    path = ""
    schema = th.PropertiesList(
        th.Property("record", th.StringType, description="The RedCap record ID"),
        th.Property(
            "redcap_event_name", th.StringType, description="RedCap event name"
        ),
        th.Property("field_name", th.StringType, description="RedCap field name"),
        th.Property("value", th.StringType, description="Field value entered by user"),
        th.Property(
            "redcap_repeat_instrument",
            th.StringType,
            description="RedCap repeating instrument name",
        ),
        th.Property(
            "redcap_repeat_instance",
            th.NumberType,
            description="RedCap repeat instance",
        ),
    ).to_dict()


class RedCapEnrollmentStream(RedCapStream):
    """A streaming client of RedCAP enrollment data."""

    def __init__(self, tap: Tap, form: str):
        """Create new instance of RedCAP enrollment streaming client."""
        super().__init__(tap, f"stream_{form}")
        self.forms = form

    path = ""
    schema = th.PropertiesList(
        th.Property("study_id", th.StringType, description="The RedCap record ID"),
        th.Property(
            "redcap_event_name", th.StringType, description="RedCap event name"
        ),
        th.Property(
            "redcap_repeat_instrument",
            th.StringType,
            description="RedCap repeating instrument name",
        ),
        th.Property(
            "redcap_repeat_instance",
            th.NumberType,
            description="RedCap repeat instance",
        ),
        th.Property(
            "redcap_data_access_group",
            th.StringType,
            description="The RedCap Data Access Group",
        ),
        th.Property(
            "subject_consent_date",
            th.StringType,
            description="The Subject Consent Date",
        ),
        th.Property(
            "enrollment_status",
            th.StringType,
            description="The Subject Enrollment Status",
        ),
        th.Property("phi", th.StringType, description="The Subject Enrollment Status"),
        th.Property("first_name", th.StringType, description="The Subject First Name"),
        th.Property("last_name", th.StringType, description="The Subject Last Name"),
        th.Property(
            "autopsy_institution",
            th.StringType,
            description="The institution that performed the autopsy if not the same as the Redcap Data Access Group",  # noqa: E501
        ),
        th.Property(
            "mrn", th.StringType, description="The Subject Medical Record Number"
        ),
        th.Property("dob", th.StringType, description="The Subject Date of Birth"),
        th.Property("cog_id", th.StringType, description="COG-ID"),
        th.Property(
            "enrollment_complete",
            th.StringType,
            description="Completion status of the Enrollment Form",
        ),
    ).to_dict()
