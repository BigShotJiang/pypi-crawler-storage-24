class ValidationError(Exception):
  pass
