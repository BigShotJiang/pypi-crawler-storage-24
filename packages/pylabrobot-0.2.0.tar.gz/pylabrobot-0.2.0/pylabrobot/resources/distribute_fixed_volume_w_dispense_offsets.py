async def distribute_fixed_volume_w_dispense_offsets(
  liquid_handler,
  source_container_name: str,  # a single container
  vol: float,
  destination_plate_name: str,
  destination_wells: List[str],  # List of well names: ["A1", "B2", ...]
  destination_offsets: List[Coordinate],  # List of offsets matching the wells
  use_channels: List[int],
  hlc: HamiltonLiquidClass | None,
  # Defaults
  aspiration_surface_following_distance: float = 4.0,
  dispense_surface_following_distance: float = 0.0,
  aspiration_lld_mode: Literal["cLLD", "pLLD"] = "cLLD",
  tip_safety_margin: float = 0.95,
  verbose: bool = True,
):
  """
  Distribute a fixed volume to multiple destination wells with custom offsets per well.

  Args:
      destination_wells: List of well identifiers (e.g., ["A1", "B2", "C3"])
      destination_offsets: List of Coordinate objects, one per well (must match length of destination_wells)

  Optimization improvements:
  - Separated wells and offsets into two lists for cleaner API
  - Cached repeated calculations (location lookups, constants)
  - Pre-calculate constants outside loops
  - Uses spatial chunking for efficient pipetting patterns
  """

  assert isinstance(use_channels, list) and 1 <= len(use_channels) <= 8, (
    "Number of use_channels must be between 1 and 8."
  )

  assert len(destination_wells) == len(destination_offsets), (
    "destination_wells and destination_offsets must have the same length."
  )

  # Pre-calculate volumes and limits
  asp_volume_per_dispense = hlc.compute_corrected_volume(vol)
  max_tip_volume = (
    min([ch.get_tip().maximal_volume for ch in liquid_handler.head.values() if ch.has_tip])
    * tip_safety_margin
  )
  dispenses_per_cycle = floor(max_tip_volume / asp_volume_per_dispense)
  num_channels = len(use_channels)

  # Get source and destination resources
  source_container = liquid_handler.deck.get_resource(source_container_name)
  dest_plate = liquid_handler.deck.get_resource(destination_plate_name)

  # Cache source container minimum height (computed once, used many times)
  source_min_height = source_container.get_absolute_location(z="cavity_bottom").z

  # Pre-calculate LLD mode (constant lookup moved outside loop)
  lld_mode_dict = {"fixed_z": 0, "cLLD": 1, "pLLD": 2}
  asp_lld_mode = liquid_handler.backend.LLDMode(lld_mode_dict[aspiration_lld_mode])
  disp_lld_mode = liquid_handler.backend.LLDMode(0)

  # Get well objects from plate and create mapping to offsets
  well_objects = dest_plate[destination_wells]
  well_to_offset = {well: offset for well, offset in zip(well_objects, destination_offsets)}

  # Use spatial chunking (groups by x-coordinate proximity, then sorts by y)
  chunked_wells = chunk_resource_list_by_x_then_sort(well_objects, max_chunk_size=num_channels)

  # Rebuild the chunks with their corresponding offsets
  chunked_wells_and_offsets = [
    [(well, well_to_offset[well]) for well in chunk] for chunk in chunked_wells
  ]

  # Group chunks into transfer cycles
  transfer_cycle_pattern = chunk_list(chunked_wells_and_offsets, chunk_size=dispenses_per_cycle)

  for asp_idx, single_cycle_list in enumerate(
    tqdm(transfer_cycle_pattern, desc="Aspiration cycle", disable=not verbose)
  ):
    max_no_channels = max(len(op) for op in single_cycle_list)
    no_dispenses = len(single_cycle_list)
    aspiration_vol = asp_volume_per_dispense * no_dispenses

    # Determine y_offset based on odd/even channels
    y_offset = 5.5 if max_no_channels % 2 != 0 else 0

    await liquid_handler.aspirate(
      resources=[source_container] * max_no_channels,
      vols=[aspiration_vol] * max_no_channels,
      use_channels=use_channels[:max_no_channels],
      hamilton_liquid_classes=[hlc] * max_no_channels,
      offsets=[Coordinate(x=0, y=y_offset, z=0)] * max_no_channels,
      lld_mode=[asp_lld_mode] * max_no_channels,
      immersion_depth_direction=[0] * max_no_channels,
      immersion_depth=[2] * max_no_channels,
      surface_following_distance=[aspiration_surface_following_distance] * max_no_channels,
      minimum_height=[source_min_height] * max_no_channels,
    )

    for disp_idx, wells_and_offsets_list in enumerate(
      tqdm(single_cycle_list, desc="Dispense step", disable=not verbose)
    ):
      # Unpack wells and offsets using zip (more pythonic)
      dest_well_list, dispense_offset_coordinate_list = zip(*wells_and_offsets_list)
      dest_well_list = list(dest_well_list)
      dispense_offset_coordinate_list = list(dispense_offset_coordinate_list)

      no_channels = len(dest_well_list)

      # Cache location lookups (avoid repeated method calls)
      first_well_top_z = dest_well_list[0].get_absolute_location(z="top").z
      first_well_bottom_z = dest_well_list[0].get_absolute_location(z="cavity_bottom").z
      traverse_height = first_well_top_z + 5

      await liquid_handler.dispense(
        resources=dest_well_list,
        vols=[vol] * no_channels,
        use_channels=use_channels[:no_channels],
        hamilton_liquid_classes=[hlc] * no_channels,
        lld_mode=[disp_lld_mode] * no_channels,
        offsets=dispense_offset_coordinate_list,
        surface_following_distance=[dispense_surface_following_distance] * no_channels,
        minimum_height=[first_well_bottom_z] * no_channels,
        minimum_traverse_height_at_beginning_of_a_command=traverse_height,
        min_z_endpos=traverse_height,
      )

      if verbose:
        print(f"{asp_idx=} | {disp_idx=} dispense: {[x.get_identifier() for x in dest_well_list]}")

    await liquid_handler.backend.move_all_channels_in_z_safety()

    empty_z_height = source_container.get_absolute_location(z="top").z - 2

    await liquid_handler.aspirate(
      resources=[source_container] * max_no_channels,
      vols=[0] * max_no_channels,
      use_channels=use_channels[:max_no_channels],
      hamilton_liquid_classes=[hlc] * max_no_channels,
      offsets=[Coordinate(x=0, y=y_offset, z=source_container.get_size_z())] * max_no_channels,
      lld_mode=[liquid_handler.backend.LLDMode(0)] * max_no_channels,
      immersion_depth_direction=[0] * max_no_channels,
      immersion_depth=[0] * max_no_channels,
      surface_following_distance=[0] * max_no_channels,
      pull_out_distance_transport_air=[0] * max_no_channels,
      minimum_height=[empty_z_height] * max_no_channels,
      min_z_endpos=empty_z_height,
    )

    await liquid_handler.backend.empty_channels()

    await liquid_handler.backend.move_all_channels_in_z_safety()
