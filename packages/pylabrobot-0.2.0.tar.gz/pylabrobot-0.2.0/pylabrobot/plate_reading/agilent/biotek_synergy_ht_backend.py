"""Backend for BioTek Synergy HT plate reader.

The Synergy HT uses the same protocol as other BioTek plate readers,
with some commands disabled (e.g., slow mode).
"""

from typing import Optional

from pylabrobot.plate_reading.agilent.biotek_backend import BioTekPlateReaderBackend
from pylabrobot.resources import Plate


class SynergyHTBackend(BioTekPlateReaderBackend):
  """Backend for BioTek Synergy HT plate readers.

  The Synergy HT is compatible with the standard BioTek protocol,
  but does not support slow mode for open/close operations.
  """

  async def open(self, slow: bool = False) -> None:
    """Open the plate reader door / eject plate.

    Note: slow parameter is ignored on Synergy HT (not supported).
    """
    # Synergy HT doesn't support slow mode command (&), so skip it
    return await self.send_command("J")

  async def close(self, plate: Optional[Plate] = None, slow: bool = False) -> None:
    """Close the plate reader door / load plate.

    Note: slow parameter is ignored on Synergy HT (not supported).
    """
    # Synergy HT doesn't support slow mode command (&), so skip it
    self._plate = None
    if plate is not None:
      await self.set_plate(plate)
    return await self.send_command("A")
