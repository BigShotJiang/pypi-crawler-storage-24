"""Build-specific system prompt for the EAISports game builder agent.

Constructs the system prompt used during `eaisports build` sessions.
The prompt gives the agent identity, context about the target game
directory, React/Vite conventions, and optionally injects a skill's
SKILL.md + template listing so the agent can follow a known pattern.

Usage:
    from agent.build_prompt import build_game_prompt, GAME_BUILD_IDENTITY

    prompt = build_game_prompt(slug="trivia-quest", game_dir="/path/to/game")
"""

import logging
import os
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


# =========================================================================
# Constants
# =========================================================================

GAME_BUILD_IDENTITY = (
    "You are EAISports Build Agent, a specialized AI for creating browser-based "
    "games using React and Vite. You write clean, functional React components, "
    "produce polished game UIs, and ensure every game you build is immediately "
    "playable in a browser via `npm run dev`."
)


# =========================================================================
# Skill loader
# =========================================================================

def _load_skill_context(skill_name: str) -> str:
    """Load a skill's SKILL.md and list its template files.

    Returns a formatted string to inject into the system prompt, or an
    empty string if the skill cannot be found.
    """
    eaisports_home = Path(os.getenv("EAISPORTS_HOME", Path.home() / ".eaisports"))
    skill_dir = eaisports_home / "skills" / skill_name

    if not skill_dir.exists():
        logger.warning("Skill directory not found: %s", skill_dir)
        return ""

    parts: list[str] = []

    # Read SKILL.md
    skill_md = skill_dir / "SKILL.md"
    if skill_md.exists():
        try:
            content = skill_md.read_text(encoding="utf-8")
            parts.append(f"## Skill: {skill_name}\n\n{content}")
        except Exception as exc:
            logger.warning("Failed to read %s: %s", skill_md, exc)

    # List template files
    templates_dir = skill_dir / "templates"
    if templates_dir.exists():
        template_files = sorted(
            p.relative_to(templates_dir)
            for p in templates_dir.rglob("*")
            if p.is_file()
        )
        if template_files:
            listing = "\n".join(f"  - {f}" for f in template_files)
            parts.append(f"### Available Templates\n{listing}")

    return "\n\n".join(parts)


# =========================================================================
# Prompt builder
# =========================================================================

def build_game_prompt(
    slug: str,
    game_dir: str,
    skill_name: Optional[str] = None,
) -> str:
    """Build the full system prompt for a game-building session.

    Parameters
    ----------
    slug:
        URL-safe game identifier (e.g. ``"trivia-quest"``).
    game_dir:
        Absolute path to the game's output directory.
    skill_name:
        Optional skill to pre-load (e.g. ``"trivia"``).

    Returns
    -------
    str
        The assembled system prompt string.
    """
    sections: list[str] = []

    # -- Identity
    sections.append(GAME_BUILD_IDENTITY)

    # -- Context
    sections.append(
        f"## Build Context\n"
        f"- Game slug: `{slug}`\n"
        f"- Output directory: `{game_dir}`\n"
        f"- Stack: React 18 + Vite 5 (already scaffolded)\n"
        f"- The project has been scaffolded with a basic React+Vite setup. "
        f"All source files live under `{game_dir}/src/`."
    )

    # -- Instructions
    sections.append(
        "## Instructions\n"
        "1. Write all game code as **functional React components** in the `src/` "
        "directory.\n"
        "2. Use the **file tools** to create and edit files inside the game directory.\n"
        "3. Use the **terminal tool** to run `npm install` and `npm run dev` when "
        "needed.\n"
        "4. Keep styles co-located: use inline styles, CSS modules, or add rules to "
        "`src/styles/index.css`.\n"
        "5. Place reusable components in `src/components/` and data/config files in "
        "`src/data/`.\n"
        "6. Make the game **playable in the browser** at http://localhost:5173 after "
        "`npm run dev`.\n"
        "7. If the user asks for assets (images, sounds), prefer free CDN links or "
        "simple SVG/CSS art over downloading files."
    )

    # -- Output rules
    sections.append(
        "## Output Rules\n"
        f"- ALL files must be written inside `{game_dir}/`.\n"
        "- Use functional React components with hooks (useState, useEffect, etc.).\n"
        "- Export components as default exports.\n"
        "- Keep the entry point at `src/main.jsx` (already created).\n"
        "- The main app component is `src/App.jsx` -- update it to render your game.\n"
        "- Do NOT modify `vite.config.js` or `index.html` unless strictly necessary.\n"
        "- Prefer simple, readable code over clever abstractions."
    )

    # -- Skill context (optional)
    if skill_name:
        skill_ctx = _load_skill_context(skill_name)
        if skill_ctx:
            sections.append(skill_ctx)

    # -- Budget awareness
    sections.append(
        "## Budget\n"
        "You have a limited number of iterations for this build session. "
        "Be efficient: plan your approach before writing code, batch related "
        "file writes, and avoid unnecessary tool calls."
    )

    return "\n\n".join(sections)
