"""Auto-generated example: Plot Type: Surface."""

from typing import Any

import bencher as bch

import math


class SurfaceDemo(bch.ParametrizedSweep):
    """3D surface of a trigonometric function."""

    x = bch.FloatSweep(default=0.5, bounds=[0.0, 1.0])
    y = bch.FloatSweep(default=0.5, bounds=[0.0, 1.0])

    distance = bch.ResultVar("m", doc="Surface height")

    def __call__(self, **kwargs: Any) -> Any:
        self.update_params_from_kwargs(**kwargs)
        self.distance = math.sin(math.pi * self.x) * math.cos(math.pi * self.y)
        return super().__call__()


def example_plot_surface(run_cfg: bch.BenchRunCfg | None = None) -> bch.Bench:
    """Plot Type: Surface."""
    bench = SurfaceDemo().to_bench(run_cfg)
    res = bench.plot_sweep(input_vars=["x", "y"], result_vars=["distance"])
    bench.report.append(res.to_surface())

    return bench


if __name__ == "__main__":
    bch.run(example_plot_surface, level=2)
