from blends.models import (
    NId,
)
from blends.query import (
    match_ast_d,
)
from blends.syntax.builders.variable_declaration import (
    build_variable_declaration_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.utilities.text_nodes import (
    node_to_str,
)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    var_id = graph.nodes[args.n_id]["label_field_name"]
    var_name = node_to_str(graph, var_id)
    var_type_id = match_ast_d(graph, args.n_id, "type_identifier")
    var_type = node_to_str(graph, var_type_id) if var_type_id else None

    return build_variable_declaration_node(args, var_name, var_type, var_id)
