from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from blends.models import NId, SyntaxGraph


class ExportPolicy(ABC):
    @abstractmethod
    def is_scope_exported(
        self,
        graph: SyntaxGraph,
        node_id: NId,
        scope_type: str | None,
        /,
    ) -> bool: ...

    @abstractmethod
    def is_definition_exported(
        self,
        graph: SyntaxGraph,
        node_id: NId,
        parent_scope_id: NId | None,
        /,
    ) -> bool: ...

    def get_visibility_modifier(
        self,
        graph: SyntaxGraph,
        node_id: NId,
    ) -> str | None:
        modifiers = graph.nodes[node_id].get(
            "access_modifiers",
            graph.nodes[node_id].get("access_modifier", ""),
        )
        for modifier in ("public", "private", "protected", "internal"):
            if modifier in modifiers:
                return modifier
        return None
