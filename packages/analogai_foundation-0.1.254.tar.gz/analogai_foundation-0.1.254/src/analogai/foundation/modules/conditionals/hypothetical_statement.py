import uuid
from typing import List, Optional

from analogai.foundation.core.value_objects.cause import Cause
from analogai.foundation.core.value_objects.effect import Effect
from analogai.foundation.common.enums.criterion import Criterion
from analogai.foundation.common.enums.certainty import certainty_from_value


class HypotheticalStatement:
    def __init__(
        self,
        agent_id: str,
        causes: List[Cause],
        effect: Effect,
        probability: float = 1.0,
        validity: float = 1.0,
        effect_belief_id: Optional[str] = None,
        id: Optional[str] = None,
    ):
        self.id = id if id else str(uuid.uuid4())
        self.agent_id = agent_id
        self.causes = list(causes or [])
        self.effect = effect
        certainty_value = None
        if effect is not None and getattr(effect, "criteria", None):
            certainty_value = effect.criteria.get(Criterion.Certainty)
        self.probability = certainty_from_value(certainty_value).to_probability()
        self.validity = validity
        self.effect_belief_id = effect_belief_id