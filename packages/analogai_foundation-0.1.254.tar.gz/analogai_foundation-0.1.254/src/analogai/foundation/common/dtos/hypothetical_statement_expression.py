from dataclasses import dataclass
from typing import Dict, Any, List, Optional

from analogai.foundation.common.enums.criterion import Criterion


@dataclass
class HypotheticalStatementExpression:
    causes: List[Dict[Criterion, Any]]
    effect: Dict[Criterion, Any]
    probability: float
    validity: float
    effect_belief_id: Optional[str] = None

    def __str__(self) -> str:
        from analogai.foundation.common.utils.expressions_serializer import (
            serialize_hypothetical_statement_expression,
        )
        return serialize_hypothetical_statement_expression(self)

    def __repr__(self) -> str:
        return (
            "HypotheticalStatementExpression("
            f"causes={self.causes!r}, effect={self.effect!r}, "
            f"probability={self.probability!r}, validity={self.validity!r}, "
            f"effect_belief_id={self.effect_belief_id!r})"
        )
