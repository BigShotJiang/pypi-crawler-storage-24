from __future__ import annotations

from analogai.foundation.settings import config
from analogai.foundation.infrastructure.embeddings.base import EmbeddingProvider
from analogai.foundation.infrastructure.embeddings.local_provider import LocalSentenceTransformerProvider
from analogai.foundation.infrastructure.embeddings.openai_provider import OpenAIEmbeddingProvider
from analogai.foundation.infrastructure.embeddings.azure_openai_provider import AzureOpenAIEmbeddingProvider
from analogai.foundation.infrastructure.embeddings.azure_foundry_provider import AzureFoundryEmbeddingProvider


DEFAULT_LOCAL_MODEL = "all-MiniLM-L6-v2"


def create_embedding_provider() -> EmbeddingProvider:
    embedding_type = str(config.get("embed.type", "local")).strip().lower()
    embedding_provider = str(config.get("embed.provider", "")).strip().lower()
    embedding_model = config.get("embed.model", "") or ""
    azure_openai_endpoint = config.get("AZURE_OPENAI_ENDPOINT", "") or ""
    azure_openai_api_key = config.get("AZURE_OPENAI_API_KEY", "") or ""
    azure_foundry_endpoint = config.get("AZURE_AI_FOUNDRY_ENDPOINT", "") or ""
    azure_foundry_api_key = config.get("AZURE_AI_FOUNDRY_API_KEY", "") or ""
    openai_api_key = config.get("OPENAI_API_KEY", "") or ""
    azure_openai_version = config.get("azure.openai.version", "2024-02-15-preview")

    if embedding_type == "local":
        model_name = embedding_model or DEFAULT_LOCAL_MODEL
        return LocalSentenceTransformerProvider(model_name=model_name)

    if embedding_provider:
        provider = embedding_provider
        if provider == "azure":
            provider = "azure_openai" if azure_openai_endpoint else "azure_foundry"
        if provider == "azure_openai":
            return AzureOpenAIEmbeddingProvider(
                endpoint=azure_openai_endpoint,
                api_key=azure_openai_api_key,
                deployment_name=embedding_model,
                api_version=azure_openai_version,
            )
        if provider == "azure_foundry":
            return AzureFoundryEmbeddingProvider(
                endpoint=azure_foundry_endpoint,
                api_key=azure_foundry_api_key,
                deployment_name=embedding_model,
                api_version=azure_openai_version,
            )
        if provider == "openai":
            return OpenAIEmbeddingProvider(
                api_key=openai_api_key,
                model_name=embedding_model,
            )
        raise ValueError(
            "Unknown EMBEDDING_PROVIDER value. Use one of: local, openai, azure_openai, azure_foundry."
        )

    if azure_openai_endpoint:
        return AzureOpenAIEmbeddingProvider(
            endpoint=azure_openai_endpoint,
            api_key=azure_openai_api_key,
            deployment_name=embedding_model,
            api_version=azure_openai_version,
        )

    if azure_foundry_endpoint:
        return AzureFoundryEmbeddingProvider(
            endpoint=azure_foundry_endpoint,
            api_key=azure_foundry_api_key,
            deployment_name=embedding_model,
            api_version=azure_openai_version,
        )

    if openai_api_key:
        return OpenAIEmbeddingProvider(
            api_key=openai_api_key,
            model_name=embedding_model,
        )

    raise ValueError(
        "EMBEDDING_TYPE is set to 'api' but no embedding provider credentials were configured."
    )
