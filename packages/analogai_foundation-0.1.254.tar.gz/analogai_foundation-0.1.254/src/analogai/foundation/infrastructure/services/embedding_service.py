from typing import List

from analogai.foundation.common.design_patterns.singleton import Singleton
from analogai.foundation.infrastructure.embeddings.base import EmbeddingProvider
from analogai.foundation.infrastructure.embeddings.provider_factory import create_embedding_provider

class EmbeddingService(metaclass=Singleton):
    def __init__(self):
        self._provider: EmbeddingProvider = create_embedding_provider()

    @property
    def dimension(self) -> int:
        dimension = self._provider.dimension
        if dimension is None:
            raise RuntimeError("Embedding dimension unavailable from provider.")
        return dimension

    def encode(self, text: str) -> List[float]:
        return self._provider.encode(text)

    def encode_batch(self, texts: List[str]) -> List[List[float]]:
        return self._provider.encode_batch(texts)