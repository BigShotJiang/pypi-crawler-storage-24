# akshare-cli

AKShare 命令行金融数据工具。支持调用 [AKShare](https://github.com/akfamily/akshare) 库的 1090+ 个函数，获取股票、基金、期货、债券、外汇、宏观经济等金融数据。

## 安装

```bash
pip install akshare-cli
```

安装后可通过 `akshare-cli` 命令使用。

## 快速开始

```bash
# 获取平安银行历史数据
akshare-cli stock hist 000001 --json

# 查看实时行情
akshare-cli stock spot --market sh --json --limit 10

# 获取中国 GDP 数据
akshare-cli macro gdp --json

# 搜索函数
akshare-cli search news

# 调用任意 akshare 函数
akshare-cli call news_economic_baidu --json

# 进入交互模式
akshare-cli repl
```

---

## 全局输出选项

以下选项可以放在子命令的**前面或后面**，位置灵活：

| 选项 | 缩写 | 说明 |
|------|------|------|
| `--json` | | 以 JSON 格式输出 |
| `--csv` | | 以 CSV 格式输出 |
| `--output FILE` | `-o` | 保存输出到文件 (支持 .csv/.json/.xlsx/.md) |
| `--limit N` | `-n` | 限制输出行数 |
| `--no-header` | | 隐藏表头 |
| `--no-cache` | | 禁用结果缓存，强制从 API 获取最新数据 |
| `--version` | | 显示版本号 |

```bash
# --json 放在前面
akshare-cli --json call stock_zh_a_hist --symbol 000001

# --json 放在后面
akshare-cli call stock_zh_a_hist --symbol 000001 --json

# 两种写法效果相同
```

---

## 命令详解

### `call` — 调用任意函数

通过函数名直接调用 akshare 库的任意函数。参数以 `--key value` 形式传入。

```bash
# 基本用法
akshare-cli call <函数名> [--参数 值 ...]

# 获取股票历史数据
akshare-cli call stock_zh_a_hist --symbol 000001 --json

# 获取经济新闻 (日期参数未指定时自动填充为当天)
akshare-cli call news_economic_baidu --json

# 获取 CCTV 新闻 (指定日期)
akshare-cli call news_cctv --date 20260310 --json

# 获取可转债数据，限制 10 行
akshare-cli call bond_zh_cov --json --limit 10

# 导出到文件
akshare-cli call futures_hist_em --symbol 螺纹主连 --output data.csv
```

#### `--full-help` — 查看函数完整用法

使用 `--full-help` 查看任意函数的参数、类型、默认值和用法示例，无需实际调用 API：

```bash
# 查看函数详细用法
akshare-cli call --full-help stock_zh_a_hist

# JSON 格式输出
akshare-cli call --full-help futures_hist_em --json

# 不带函数名，显示使用指南
akshare-cli call --full-help
```

输出内容：
- 函数名、模块路径、文档说明
- 参数列表（名称、类型、默认值、是否必填）
- 自动生成的用法命令行

日期自动填充：当函数有 `date` 类参数且未指定时，CLI 会自动使用当天日期并提示：
```
Note: --date not specified, using today: 20260311
```

### `search` — 搜索函数

在 1090+ 个函数中模糊搜索，返回包含关键词的所有函数名及简介。

```bash
# 搜索股票相关函数
akshare-cli search stock_zh

# 搜索 ETF 基金函数
akshare-cli search fund_etf --json

# 搜索新闻接口
akshare-cli search news
```

### `list` — 列出函数

不指定域时显示所有域的函数数量概览；指定域时列出该域下所有函数。

```bash
# 查看所有域的概览
akshare-cli list

# 列出股票域的所有函数
akshare-cli list stock

# JSON 格式输出
akshare-cli list fund --json
```

常见域：`stock`(股票) `fund`(基金) `futures`(期货) `bond`(债券) `forex`(外汇) `macro`(宏观) `index`(指数) `option`(期权) `news`(新闻)

### `info` — 查看函数详情

显示函数的参数列表、类型、默认值和文档说明。在调用陌生函数前先用 `info` 查看参数要求。

```bash
# 查看股票历史数据函数的参数
akshare-cli info stock_zh_a_hist

# JSON 格式输出
akshare-cli info news_economic_baidu --json
```

输出内容：
- 函数名和模块
- 参数列表（名称、类型、默认值、是否必填）
- 函数文档说明

### `export` — 导出结果

将最近一次查询返回的数据导出到文件。

```bash
akshare-cli export result.csv    # CSV
akshare-cli export data.xlsx     # Excel
akshare-cli export data.json     # JSON
akshare-cli export report.md     # Markdown 表格
```

注意：需要先运行查询命令，否则无数据可导出。

### `version` — 版本信息

```bash
akshare-cli version
akshare-cli version --json
```

### `cache` — 缓存管理

API 调用结果会自动缓存以加速重复查询。实时行情类接口（如 `stock_zh_a_spot_em`、`forex_spot_em`）不会被缓存。

缓存策略：
| 数据类型 | TTL |
|----------|-----|
| 合约列表、宏观年度数据 | 24 小时 |
| 债券收益率等 | 1 小时 |
| 其他函数 | 30 分钟 |
| 实时行情 | 不缓存 |

```bash
# 查看缓存统计
akshare-cli cache stats

# 清空缓存
akshare-cli cache clear

# 单次禁用缓存
akshare-cli --no-cache call stock_zh_a_hist --symbol 000001 --json
```

---

## 域快捷命令

除了通用的 `call` 命令，常用数据提供了快捷入口：

### `stock` — 股票数据

#### `stock hist <代码>` — 历史 K 线

获取 A 股历史 OHLCV 数据。数据来源：东方财富 (`stock_zh_a_hist`)

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `SYMBOL` | 股票代码 (如 000001, 600519) | 必填 |
| `--period` | 周期: daily/weekly/monthly | daily |
| `--start` | 开始日期 YYYYMMDD | 19700101 |
| `--end` | 结束日期 YYYYMMDD | 20500101 |
| `--adjust` | 复权: qfq(前)/hfq(后)/空串(不复权) | 空串 |

```bash
# 平安银行日线数据
akshare-cli stock hist 000001 --json

# 贵州茅台周线 + 前复权
akshare-cli stock hist 600519 --period weekly --adjust qfq

# 指定日期范围，CSV 输出
akshare-cli stock hist 000001 --start 20260101 --end 20260311 --csv
```

#### `stock spot` — 实时行情

获取各市场股票实时报价。数据来源：东方财富

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `--market` | 市场: all/sh/sz/bj/hk/us | all |

```bash
akshare-cli stock spot --json                   # 全部 A 股
akshare-cli stock spot --market sh --json       # 上海 A 股
akshare-cli stock spot --market hk --json       # 港股
akshare-cli stock spot --market us --limit 20   # 美股前 20 行
```

注意：全市场数据量较大 (5000+ 行)，建议配合 `--limit` 使用。

### `fund` — 基金数据

#### `fund etf [代码]` — ETF 数据

不传代码列出所有 ETF 实时行情；传代码获取单只 ETF 历史数据。

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `[SYMBOL]` | ETF 代码 (可选) | - |
| `--period` | 周期: daily/weekly/monthly | daily |
| `--start` | 开始日期 YYYYMMDD | 19700101 |
| `--end` | 结束日期 YYYYMMDD | 20500101 |
| `--adjust` | 复权: qfq/hfq/空串 | 空串 |

```bash
# 列出所有 ETF
akshare-cli fund etf --json

# 单只 ETF 历史数据
akshare-cli fund etf 159707 --json

# 沪深300 ETF 前复权周线
akshare-cli fund etf 510300 --period weekly --adjust qfq --csv
```

### `futures` — 期货数据

#### `futures hist <合约>` — 历史 K 线

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `SYMBOL` | 期货合约名称 (如 螺纹主连) | 必填 |
| `--period` | 周期: daily/weekly/monthly | daily |
| `--start` | 开始日期 YYYYMMDD | 19900101 |
| `--end` | 结束日期 YYYYMMDD | 20500101 |

```bash
akshare-cli futures hist 螺纹主连 --json
akshare-cli futures hist 热卷主连 --period weekly --csv
```

提示：先用 `futures list` 查看可用合约名称。

#### `futures list` — 可用合约

```bash
akshare-cli futures list --json
```

### `bond` — 债券数据

#### `bond convertible` — 可转债

获取全市场可转债实时数据。数据来源：集思录 (`bond_cb_jsl`)

```bash
akshare-cli bond convertible --json
akshare-cli bond convertible --json --limit 20
```

更多债券函数可通过 `call` 命令调用：
```bash
akshare-cli call bond_china_yield --json          # 中国国债收益率
akshare-cli call bond_zh_us_rate --json           # 中美国债利率
akshare-cli call bond_spot_quote --json           # 做市报价
```

### `macro` — 宏观经济数据

#### `macro gdp` — 中国 GDP

```bash
akshare-cli macro gdp --json
akshare-cli macro gdp --csv --output gdp.csv
```

#### `macro cpi` — 中国 CPI

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `--freq` | 频率: monthly/yearly | monthly |

```bash
akshare-cli macro cpi --json              # 月度 CPI
akshare-cli macro cpi --freq yearly --csv  # 年度 CPI
```

更多宏观数据可通过 `call` 命令调用：
```bash
akshare-cli call macro_china_ppi_yearly --json   # PPI
akshare-cli call macro_china_lpr --json          # LPR 利率
akshare-cli call macro_china_m2_yearly --json    # M2 货币供应
akshare-cli call macro_shipping_bdi --json       # BDI 指数
```

### `forex` — 外汇数据

#### `forex spot` — 实时汇率

```bash
akshare-cli forex spot --json
```

#### `forex hist [货币对]` — 历史汇率

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `[SYMBOL]` | 货币对 | USDCNH |

```bash
akshare-cli forex hist USDCNH --json
akshare-cli forex hist EURUSD --csv
```

### `index` — 指数数据

#### `index spot` — 实时行情

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `--market` | global(全球)/cn(中国) | global |

```bash
akshare-cli index spot --json               # 全球指数
akshare-cli index spot --market cn --json    # 中国指数
```

### `option` — 期权数据

#### `option info` — 合约信息

```bash
akshare-cli option info --json
```

---

## REPL 交互模式

启动交互式会话，可以连续执行多个查询，保留会话状态：

```bash
akshare-cli repl
```

REPL 命令：

| 命令 | 说明 |
|------|------|
| `call <函数> [--参数 值]` | 调用函数 |
| `search <关键词>` | 搜索函数 |
| `list [域]` | 列出函数 |
| `info <函数>` | 查看函数详情 |
| `export <文件路径>` | 导出上次结果 |
| `history` | 查看历史记录 |
| `set <键> <值>` | 设置偏好 |
| `json on/off` | 切换 JSON 输出 |
| `help` | 显示帮助 |
| `quit / exit / q` | 退出 |

示例会话：
```
akshare> call stock_zh_a_hist --symbol 000001 --period daily
akshare> json on
akshare> call stock_zh_a_spot_em
akshare> export result.csv
akshare> search news
akshare> call news_economic_baidu
akshare> history
akshare> quit
```

---

## 高级用法

### 日期自动填充

许多 akshare 函数的 `date` 参数有过期的默认值。CLI 会自动检测并替换为当天日期：

```bash
# 不传 --date，自动使用今天
akshare-cli call news_economic_baidu --json
# 输出: Note: --date not specified, using today: 20260311

# 手动指定日期不受影响
akshare-cli call news_economic_baidu --date 20260310 --json
```

检测条件：参数名含 `date`，默认值为 8 位数字 (YYYYMMDD 格式)，且用户未手动指定。

### 输出格式

**表格** (默认)：人类可读的对齐文本表格
```bash
akshare-cli macro gdp
```

**JSON** (`--json`)：机器可读格式，包含元数据
```json
{
  "total_rows": 100,
  "columns": ["日期", "值"],
  "data": [...]
}
```

**CSV** (`--csv`)：标准 CSV 格式
```bash
akshare-cli macro gdp --csv
```

**文件输出** (`--output`)：根据扩展名自动选择格式
```bash
akshare-cli macro gdp --output gdp.csv
akshare-cli macro gdp --output gdp.xlsx
akshare-cli macro gdp --output gdp.json
```

### 调试模式

设置环境变量查看完整错误栈：
```bash
AKSHARE_CLI_DEBUG=1 akshare-cli call some_function --json
```

---

## 常用股票函数速查

以下函数经过实测验证，稳定可用。统一调用方式：`akshare-cli call <函数名> [--参数 值] --json`

### 个股行情

| 函数名 | 参数 | 说明 | 示例 |
|--------|------|------|------|
| `stock_bid_ask_em` | `--symbol 股票代码` | 个股实时行情：最新价、涨跌幅、五档盘口、成交量、换手率等 | `akshare-cli call stock_bid_ask_em --symbol 600519 --json` |
| `stock_zh_a_hist` | `--symbol 股票代码 --period daily/weekly/monthly [--start_date YYYYMMDD] [--end_date YYYYMMDD] [--adjust qfq/hfq]` | 个股历史 K 线（日线/周线/月线），支持前复权/后复权 | `akshare-cli call stock_zh_a_hist --symbol 600519 --period daily --start_date 20260101 --json` |
| `stock_zh_a_hist_min_em` | `--symbol 股票代码 --period 1/5/15/30/60 [--start_date 起始时间] [--end_date 结束时间]` | 个股历史分钟线 | `akshare-cli call stock_zh_a_hist_min_em --symbol 600519 --period 5 --json --limit 20` |
| `stock_zh_a_hist_pre_min_em` | `--symbol 股票代码` | 个股盘前分钟级数据 | `akshare-cli call stock_zh_a_hist_pre_min_em --symbol 600519 --json` |
| `stock_intraday_em` | `--symbol 股票代码` | 个股当日分时成交明细 | `akshare-cli call stock_intraday_em --symbol 600519 --json --limit 50` |
| `stock_individual_info_em` | `--symbol 股票代码` | 个股基本信息：总市值、流通市值、所属行业、上市日期等 | `akshare-cli call stock_individual_info_em --symbol 600519 --json` |
| `stock_news_em` | `--symbol 股票代码` | 个股相关新闻资讯 | `akshare-cli call stock_news_em --symbol 600519 --json` |

### 市场概览

| 函数名 | 参数 | 说明 | 示例 |
|--------|------|------|------|
| `stock_changes_em` | 无 | 全市场异动提醒（急涨/急跌/大笔买入/大笔卖出等） | `akshare-cli call stock_changes_em --json --limit 30` |
| `stock_hot_rank_em` | 无 | 东方财富人气排名 TOP100 | `akshare-cli call stock_hot_rank_em --json` |
| `stock_comment_em` | 无 | 全市场千股千评（综合评分、主力资金、技术面等） | `akshare-cli call stock_comment_em --json --limit 20` |
| `stock_sse_summary` | 无 | 上交所每日市场概况（成交额、总市值、上市公司数等） | `akshare-cli call stock_sse_summary --json` |
| `stock_market_pe_lg` | `--symbol 上证A股/深证A股/创业板/科创板` | 市场整体 PE 历史走势 | `akshare-cli call stock_market_pe_lg --symbol 上证A股 --json` |

### 涨停跌停

| 函数名 | 参数 | 说明 | 示例 |
|--------|------|------|------|
| `stock_zt_pool_em` | `--date YYYYMMDD` | 涨停股池 | `akshare-cli call stock_zt_pool_em --date 20260313 --json` |
| `stock_zt_pool_strong_em` | `--date YYYYMMDD` | 强势股池（多日连板） | `akshare-cli call stock_zt_pool_strong_em --date 20260313 --json` |
| `stock_zt_pool_sub_new_em` | `--date YYYYMMDD` | 次新股池 | `akshare-cli call stock_zt_pool_sub_new_em --date 20260313 --json` |
| `stock_zt_pool_zbgc_em` | `--date YYYYMMDD` | 炸板股池（曾触涨停后打开） | `akshare-cli call stock_zt_pool_zbgc_em --date 20260313 --json` |
| `stock_zt_pool_dtgc_em` | `--date YYYYMMDD` | 跌停股池 | `akshare-cli call stock_zt_pool_dtgc_em --date 20260313 --json` |

### 板块

| 函数名 | 参数 | 说明 | 示例 |
|--------|------|------|------|
| `stock_board_industry_name_em` | 无 | 行业板块列表（板块名称、涨跌幅、成交额等） | `akshare-cli call stock_board_industry_name_em --json` |
| `stock_board_concept_name_em` | 无 | 概念板块列表 | `akshare-cli call stock_board_concept_name_em --json` |
| `stock_board_concept_cons_em` | `--symbol 概念名称` | 概念板块成分股明细 | `akshare-cli call stock_board_concept_cons_em --symbol 人工智能 --json` |

### 龙虎榜 / 排行

| 函数名 | 参数 | 说明 | 示例 |
|--------|------|------|------|
| `stock_lhb_detail_em` | `--start_date YYYYMMDD --end_date YYYYMMDD` | 龙虎榜详情（上榜个股、买卖营业部等） | `akshare-cli call stock_lhb_detail_em --start_date 20260313 --end_date 20260313 --json` |
| `stock_rank_cxg_ths` | 无 | 创新高排名（同花顺） | `akshare-cli call stock_rank_cxg_ths --json --limit 20` |

### 资金流向

| 函数名 | 参数 | 说明 | 示例 |
|--------|------|------|------|
| `stock_hsgt_hist_em` | `--symbol 沪股通/深股通/北向资金` | 沪深港通历史资金流向 | `akshare-cli call stock_hsgt_hist_em --symbol 沪股通 --json --limit 10` |

> **提示**：所有函数都可以加 `--full-help` 查看完整参数说明，例如：`akshare-cli call --full-help stock_zh_a_hist --json`

---

## 常见问题

**Q: 如何查找函数名？**
```bash
akshare-cli search <关键词>                  # 模糊搜索
akshare-cli list <域名>                      # 按域列出
akshare-cli info <函数名>                    # 查看参数
akshare-cli call --full-help <函数名>        # 查看完整用法
```

**Q: 数据返回空 / 报错 RemoteDisconnected？**

这通常是 akshare 上游 API 不稳定导致的，非 CLI 问题。可以稍后重试，或者换用相同数据的其他数据源函数。

**Q: 输出太多行怎么办？**

使用 `--limit` 限制行数：
```bash
akshare-cli stock spot --json --limit 20
```

**Q: `--json` 放在哪里？**

任意位置都可以：命令前面、后面、参数中间均有效。

---

---

## 函数参考手册

以下是 CLI 直接支持的每个函数的详细文档，数据来源自 [AKShare 官方文档](https://akshare.akfamily.xyz/)。

---

### 股票数据

#### `stock_zh_a_hist` — 沪深京 A 股历史行情

- **数据来源**：东方财富
- **CLI 快捷命令**：`stock hist <代码>`
- **文档**：https://akshare.akfamily.xyz/data/stock/stock.html

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| symbol | str | 必填 | 股票代码 (如 000001, 600519) |
| period | str | daily | 周期: daily/weekly/monthly |
| start_date | str | 19700101 | 开始日期 YYYYMMDD |
| end_date | str | 20500101 | 结束日期 YYYYMMDD |
| adjust | str | '' | 复权: ''(不复权)/qfq(前复权)/hfq(后复权) |

返回列：`日期` `股票代码` `开盘` `收盘` `最高` `最低` `成交量(手)` `成交额(元)` `振幅(%)` `涨跌幅(%)` `涨跌额` `换手率(%)`

```bash
akshare-cli stock hist 000001 --json
akshare-cli stock hist 600519 --period weekly --adjust qfq --csv
akshare-cli call stock_zh_a_hist --symbol 000001 --start_date 20260101 --json
```

#### `stock_zh_a_spot_em` — 沪深京 A 股实时行情

- **数据来源**：东方财富
- **CLI 快捷命令**：`stock spot` 或 `stock spot --market all`
- **参数**：无

返回列：`序号` `代码` `名称` `最新价` `涨跌幅(%)` `涨跌额` `成交量(手)` `成交额(元)` `振幅(%)` `最高` `最低` `今开` `昨收` `量比` `换手率(%)` `市盈率-动态` `市净率` `总市值` `流通市值` `涨速` `5分钟涨跌(%)` `60日涨跌幅(%)` `年初至今涨跌幅(%)`

```bash
akshare-cli stock spot --json --limit 20
```

> 同类函数：`stock_sh_a_spot_em`(沪A) `stock_sz_a_spot_em`(深A) `stock_bj_a_spot_em`(北交所) `stock_hk_spot_em`(港股) `stock_us_spot_em`(美股) — 返回列相同，通过 `stock spot --market sh/sz/bj/hk/us` 调用

#### `stock_sse_summary` — 上海证券交易所数据总貌

- **数据来源**：上海证券交易所
- **参数**：无

返回列：`项目` `股票` `科创板` `主板`

```bash
akshare-cli call stock_sse_summary --json
```

#### `stock_szse_summary` — 深圳证券交易所市场总貌

- **数据来源**：深圳证券交易所

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| date | str | 自动填充今天 | 日期 YYYYMMDD |

返回列：`证券类别` `数量(只)` `成交金额(元)` `总市值` `流通市值`

```bash
akshare-cli call stock_szse_summary --json
akshare-cli call stock_szse_summary --date 20260310 --json
```

#### `stock_individual_info_em` — 个股信息查询

- **数据来源**：东方财富

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| symbol | str | 必填 | 股票代码 |

返回列：`item`(信息项) `value`(值)，包含：股票代码、股票简称、总股本、流通股、总市值、流通市值、行业、上市时间等

```bash
akshare-cli call stock_individual_info_em --symbol 000001 --json
```

#### `stock_bid_ask_em` — 行情报价 (五档盘口)

- **数据来源**：东方财富

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| symbol | str | 必填 | 股票代码 |

返回列：`item`(报价项) `value`(值)，包含：sell_1~sell_5, buy_1~buy_5, 最新、均价、涨幅、涨跌、总手、金额等

```bash
akshare-cli call stock_bid_ask_em --symbol 000001 --json
```

#### `stock_intraday_em` — 日内分时数据

- **数据来源**：东方财富

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| symbol | str | 必填 | 股票代码 |

返回列：`时间` `成交价` `手数` `买卖盘性质`

```bash
akshare-cli call stock_intraday_em --symbol 000001 --json
```

#### `stock_sse_deal_daily` — 上交所每日成交概况

- **数据来源**：上海证券交易所（仅支持 20211227 之后的数据）

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| date | str | 自动填充今天 | 日期 YYYYMMDD |

返回列：`单日情况` `股票` `主板A` `主板B` `科创板` `股票回购`

```bash
akshare-cli call stock_sse_deal_daily --json
```

#### `stock_zh_a_st_em` — 风险警示板 (ST 股票)

- **数据来源**：东方财富
- **参数**：无

返回列：`序号` `代码` `名称` `最新价` `涨跌幅(%)` `涨跌额` `成交量` `成交额` `振幅(%)` `最高` `最低` `今开` `昨收` `量比` `换手率(%)` `市盈率-动态` `市净率`

```bash
akshare-cli call stock_zh_a_st_em --json --limit 20
```

#### `stock_zh_a_new_em` — 新股实时行情

- **数据来源**：东方财富
- **参数**：无
- 返回列同 `stock_zh_a_st_em`

```bash
akshare-cli call stock_zh_a_new_em --json --limit 20
```

#### `stock_zh_b_spot_em` — B 股实时行情

- **数据来源**：东方财富
- **参数**：无
- 返回列同 `stock_zh_a_spot_em`

```bash
akshare-cli call stock_zh_b_spot_em --json
```

---

### 基金数据

#### `fund_etf_spot_em` — ETF 实时行情

- **数据来源**：东方财富
- **CLI 快捷命令**：`fund etf` (不传代码)
- **参数**：无

```bash
akshare-cli fund etf --json --limit 20
```

#### `fund_etf_hist_em` — ETF 历史行情

- **数据来源**：东方财富
- **CLI 快捷命令**：`fund etf <代码>`

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| symbol | str | 必填 | ETF 代码 (如 159707, 510300) |
| period | str | daily | 周期: daily/weekly/monthly |
| start_date | str | 19700101 | 开始日期 YYYYMMDD |
| end_date | str | 20500101 | 结束日期 YYYYMMDD |
| adjust | str | '' | 复权: qfq/hfq/'' |

```bash
akshare-cli fund etf 159707 --json
akshare-cli fund etf 510300 --period weekly --adjust qfq --csv
```

---

### 期货数据

#### `futures_hist_em` — 期货历史行情

- **数据来源**：东方财富
- **CLI 快捷命令**：`futures hist <合约>`
- **文档**：https://akshare.akfamily.xyz/data/futures/futures.html
- **说明**：单次返回指定合约的所有数据；只能获取当期合约

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| symbol | str | 必填 | 合约名称，通过 `futures_hist_table_em()` 获取 |
| period | str | daily | 周期: daily/weekly/monthly |
| start_date | str | 19900101 | 开始日期 YYYYMMDD |
| end_date | str | 20500101 | 结束日期 YYYYMMDD |

返回列：`时间` `开盘` `最高` `最低` `收盘` `涨跌` `涨跌幅(%)` `成交量` `成交额` `持仓量`

```bash
akshare-cli futures hist 螺纹主连 --json
akshare-cli futures hist 热卷主连 --period weekly --csv
```

#### `futures_hist_table_em` — 可用期货合约列表

- **数据来源**：东方财富
- **CLI 快捷命令**：`futures list`
- **参数**：无

```bash
akshare-cli futures list --json
```

#### `futures_fees_info` — 期货交易费用参照表

- **数据来源**：openctp (http://openctp.cn/fees.html)
- **参数**：无

返回列：`交易所` `合约代码` `合约名称` `品种代码` `品种名称` `合约乘数` `最小跳动` `开仓费率` `开仓费用` `平仓费率` `平仓费用` `平今费率` `平今费用` `做多保证金率` `做空保证金率` 等 35 列

```bash
akshare-cli call futures_fees_info --json --limit 20
```

#### `futures_contract_info_gfex` — 广州期货交易所合约信息

- **数据来源**：广州期货交易所
- **参数**：无

返回列：`品种` `合约代码` `交易单位` `最小变动单位` `开始交易日` `最后交易日` `最后交割日`

```bash
akshare-cli call futures_contract_info_gfex --json
```

#### `futures_symbol_mark` — 期货品种标记表

- **参数**：无

返回列：`symbol`

```bash
akshare-cli call futures_symbol_mark --json
```

#### `futures_spot_price` — 现货价格和基差数据

- **数据来源**：生意社
- **说明**：支持 2011 年至今每个交易日数据

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| date | str | 自动填充今天 | 交易日期 YYYYMMDD |

返回列：`symbol` `spot_price` `near_contract` `near_price` `dom_contract` `dom_price` `near_basis` `dom_basis` `near_basis_rate` `dom_basis_rate` `date`

```bash
akshare-cli call futures_spot_price --json
akshare-cli call futures_spot_price --date 20260310 --json
```

---

### 债券数据

#### `bond_cb_jsl` — 可转债实时数据 (集思录)

- **数据来源**：集思录 (https://www.jisilu.cn/data/cbnew/#cb)
- **CLI 快捷命令**：`bond convertible`

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| cookie | str | None | 集思录 cookie，不传只返回前 30 条 |

返回列：`代码` `转债名称` `现价` `涨跌幅(%)` `正股代码` `正股名称` `正股价` `正股涨跌(%)` `正股PB` `转股价` `转股价值` `转股溢价率(%)` `债券评级` `回售触发价` `强赎触发价` `转债占比(%)` `到期时间` `剩余年限` `剩余规模(亿)` `成交额(万)` `换手率(%)` `到期税前收益(%)` `双低`

```bash
akshare-cli bond convertible --json
```

#### `bond_zh_cov` — 可转债数据一览表

- **数据来源**：东方财富 (https://data.eastmoney.com/kzz/default.html)
- **参数**：无

返回列：`债券代码` `债券简称` `申购日期` `申购代码` `申购上限(万)` `正股代码` `正股简称` `正股价` `转股价` `转股价值` `债现价` `转股溢价率(%)` `发行规模(亿)` `中签率(%)` `上市时间` `信用评级` 等

```bash
akshare-cli call bond_zh_cov --json --limit 20
```

#### `bond_cb_redeem_jsl` — 可转债强赎 (集思录)

- **数据来源**：集思录
- **参数**：无

返回列：`代码` `名称` `现价` `正股代码` `正股名称` `规模(亿)` `剩余规模` `转股起始日` `最后交易日` `到期日` `转股价` `强赎触发比(%)` `强赎触发价` `正股价` `强赎天计数` `强赎条款` `强赎状态`

```bash
akshare-cli call bond_cb_redeem_jsl --json
```

#### `bond_china_yield` — 国债收益率曲线

- **数据来源**：中国债券信息网
- **说明**：start_date 到 end_date 需小于一年

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| start_date | str | 必填 | 开始日期 YYYYMMDD |
| end_date | str | 必填 | 结束日期 YYYYMMDD |

返回列：`曲线名称` `日期` `3月` `6月` `1年` `3年` `5年` `7年` `10年` `30年`

```bash
akshare-cli call bond_china_yield --start_date 20260101 --end_date 20260311 --json
```

#### `bond_zh_us_rate` — 中美国债收益率

- **数据来源**：东方财富
- **说明**：数据从 19901219 开始

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| start_date | str | 必填 | 开始日期 YYYYMMDD |

返回列：`日期` `中国国债收益率2年/5年/10年/30年` `中国国债收益率10年-2年` `中国GDP年增率` `美国国债收益率2年/5年/10年/30年` `美国国债收益率10年-2年` `美国GDP年增率`

```bash
akshare-cli call bond_zh_us_rate --start_date 20260101 --json
```

#### `bond_spot_quote` — 现券做市报价

- **数据来源**：中国外汇交易中心
- **参数**：无

返回列：`报价机构` `债券简称` `买入净价(元)` `卖出净价(元)` `买入收益率(%)` `卖出收益率(%)`

```bash
akshare-cli call bond_spot_quote --json --limit 20
```

#### `bond_gb_zh_sina` — 中国国债收益率行情 (新浪)

- **数据来源**：新浪财经
- **说明**：返回最近 1000 个交易日数据

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| symbol | str | 必填 | 可选：中国1/2/3/5/7/10/15/20/30年期国债 |

返回列：`date` `open` `high` `low` `close` `volume`

```bash
akshare-cli call bond_gb_zh_sina --symbol 中国10年期国债 --json
```

#### `bond_gb_us_sina` — 美国国债收益率行情 (新浪)

- **数据来源**：新浪财经
- **说明**：返回最近 1000 个交易日数据

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| symbol | str | 必填 | 可选：美国1月/2月/3月/6月/1/2/3/5/7/10/20/30年期国债 |

返回列：`date` `open` `high` `low` `close` `volume`

```bash
akshare-cli call bond_gb_us_sina --symbol 美国10年期国债 --json
```

---

### 宏观经济数据

> 以下宏观函数均无输入参数，数据来源为金十数据中心或东方财富。
> CLI 快捷命令：`macro gdp`、`macro cpi`

#### `macro_china_gdp_yearly` — 中国 GDP 年率

- **CLI 快捷命令**：`macro gdp`
- **数据起始**：2011-01-20
- 返回列：`商品` `日期` `今值(%)` `预测值(%)` `前值(%)`

```bash
akshare-cli macro gdp --json
```

#### `macro_china_cpi_yearly` — 中国 CPI 年率

- **CLI 快捷命令**：`macro cpi --freq yearly`
- **数据起始**：1986-02-01
- 返回列：`商品` `日期` `今值(%)` `预测值(%)` `前值(%)`

```bash
akshare-cli macro cpi --freq yearly --json
```

#### `macro_china_cpi_monthly` — 中国 CPI 月率

- **CLI 快捷命令**：`macro cpi` 或 `macro cpi --freq monthly`
- **数据起始**：1996-02-01
- 返回列：`商品` `日期` `今值(%)` `预测值(%)` `前值(%)`

```bash
akshare-cli macro cpi --json
```

#### `macro_china_ppi_yearly` — 中国 PPI 年率

- **数据起始**：1995-08-01
- 返回列：`商品` `日期` `今值(%)` `预测值(%)` `前值(%)`

```bash
akshare-cli call macro_china_ppi_yearly --json
```

#### `macro_china_pmi_yearly` — 官方制造业 PMI

- **数据起始**：2005-02-01
- 返回列：`商品` `日期` `今值` `预测值` `前值`

```bash
akshare-cli call macro_china_pmi_yearly --json
```

#### `macro_china_cx_pmi_yearly` — 财新制造业 PMI 终值

- **数据起始**：2012-01-20
- 返回列：`商品` `日期` `今值` `预测值` `前值`

```bash
akshare-cli call macro_china_cx_pmi_yearly --json
```

#### `macro_china_lpr` — LPR 利率

- **数据来源**：东方财富
- **数据起始**：1991-04-21
- 返回列：`TRADE_DATE` `LPR1Y(%)` `LPR5Y(%)` `RATE_1(短期贷款利率%)` `RATE_2(中长期贷款利率%)`

```bash
akshare-cli call macro_china_lpr --json
```

#### `macro_china_m2_yearly` — M2 货币供应年率

- **数据起始**：1998-02-01
- 返回列：`商品` `日期` `今值(%)` `预测值(%)` `前值(%)`

```bash
akshare-cli call macro_china_m2_yearly --json
```

#### `macro_china_exports_yoy` — 以美元计算出口年率

- **数据起始**：1982-02-01
- 返回列：`商品` `日期` `今值(%)` `预测值(%)` `前值(%)`

```bash
akshare-cli call macro_china_exports_yoy --json
```

#### `macro_china_trade_balance` — 以美元计算贸易帐

- **数据起始**：1981-02-01
- 返回列：`商品` `日期` `今值(亿美元)` `预测值(亿美元)` `前值(亿美元)`

```bash
akshare-cli call macro_china_trade_balance --json
```

#### `macro_china_lpi_index` — 物流景气指数

- **数据来源**：东方财富
- **数据起始**：2013-07-01
- 返回列：`日期` `最新值` `涨跌幅(%)` `近3月涨跌幅(%)` `近6月涨跌幅(%)` `近1年涨跌幅(%)` `近2年涨跌幅(%)` `近3年涨跌幅(%)`

```bash
akshare-cli call macro_china_lpi_index --json
```

#### `macro_shipping_bdi` — 波罗的海干散货指数 (BDI)

- **数据来源**：东方财富
- **数据起始**：1988-10-19
- 返回列：`日期` `最新值` `涨跌幅(%)` `近3月涨跌幅(%)` `近6月涨跌幅(%)` `近1年涨跌幅(%)` `近2年涨跌幅(%)` `近3年涨跌幅(%)`

```bash
akshare-cli call macro_shipping_bdi --json
```

#### `macro_china_shrzgm` — 社会融资规模增量

- **数据来源**：商务数据中心
- **数据起始**：2015-01
- 返回列：`月份` `社会融资规模增量(亿)` `人民币贷款(亿)` `外币贷款(亿)` `委托贷款(亿)` `信托贷款(亿)` `未贴现银行承兑汇票(亿)` `企业债券(亿)` `非金融企业境内股票融资(亿)`

```bash
akshare-cli call macro_china_shrzgm --json
```

#### `macro_cnbs` — 中国宏观杠杆率

- **数据来源**：国家金融与发展实验室
- 返回列：`年份` `居民部门` `非金融企业部门` `政府部门` `中央政府` `地方政府` `实体经济部门` `金融部门资产方` `金融部门负债方`

```bash
akshare-cli call macro_cnbs --json
```

#### `macro_china_urban_unemployment` — 城镇调查失业率

- **数据来源**：国家统计局
- 返回列：`date` `item` `value`

```bash
akshare-cli call macro_china_urban_unemployment --json
```

---

### 外汇数据

#### `forex_spot_em` — 外汇实时行情

- **数据来源**：东方财富 (https://quote.eastmoney.com/center/gridlist.html#forex_all)
- **CLI 快捷命令**：`forex spot`
- **参数**：无

```bash
akshare-cli forex spot --json
```

#### `forex_hist_em` — 外汇历史行情

- **数据来源**：东方财富
- **CLI 快捷命令**：`forex hist [货币对]`

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| symbol | str | USDCNH | 货币对代码，通过 `forex_spot_em()` 获取所有可用代码 |

```bash
akshare-cli forex hist USDCNH --json
akshare-cli forex hist EURUSD --csv
```

---

### 指数数据

#### `index_global_spot_em` — 全球指数实时行情

- **数据来源**：东方财富
- **CLI 快捷命令**：`index spot` 或 `index spot --market global`
- **参数**：无

```bash
akshare-cli index spot --json
```

#### `stock_zh_index_spot_em` — 中国指数实时行情

- **数据来源**：东方财富
- **CLI 快捷命令**：`index spot --market cn`

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| symbol | str | 上证系列指数 | 可选：沪深重要指数/上证系列指数/深证系列指数/指数成份/中证系列指数 |

```bash
akshare-cli index spot --market cn --json
```

---

### 新闻数据

#### `news_cctv` — 新闻联播文字稿

- **数据来源**：CCTV (https://tv.cctv.com/lm/xwlb)
- **说明**：支持 20160203 之后的数据

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| date | str | 自动填充今天 | 日期 YYYYMMDD |

```bash
akshare-cli call news_cctv --json
akshare-cli call news_cctv --date 20260310 --json
```

#### `news_economic_baidu` — 百度经济数据日历

- **数据来源**：百度股市通 (https://gushitong.baidu.com/calendar)
- **说明**：支持分页，无 100 条限制，自动获取全部数据

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| date | str | 自动填充今天 | 日期 YYYYMMDD |
| cookie | str | None | 百度 cookie (可选) |

返回列：`日期` `时间` `地区` `事件` `公布` `预期` `前值` `重要性`

```bash
akshare-cli call news_economic_baidu --json
akshare-cli call news_economic_baidu --date 20260310 --json --limit 20
```

#### `stock_news_main_cx` — 财新个股新闻

- **数据来源**：财新数据通 (https://cxdata.caixin.com/pc/)
- **参数**：无
- **限制**：最多返回 100 条 (API 硬编码)

```bash
akshare-cli call stock_news_main_cx --json
```

---

### 期权数据

#### `option_contract_info_ctp` — 期权合约信息

- **数据来源**：openctp (http://openctp.cn/instruments.html)
- **CLI 快捷命令**：`option info`
- **参数**：无

```bash
akshare-cli option info --json
```

---

## 禁用函数

以下函数因上游 API 不可用已被禁用，不会出现在函数列表中：

- `index_news_sentiment_scope` — 远程 API 返回空响应

如需恢复，可编辑 `core/registry.py` 中的 `DISABLED_FUNCTIONS` 集合。

---

## 环境要求

- Python >= 3.9
- akshare
- click
- pandas
- tabulate
