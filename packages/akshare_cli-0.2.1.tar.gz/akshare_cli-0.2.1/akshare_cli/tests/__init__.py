"""Tests package for AKShare CLI harness."""
