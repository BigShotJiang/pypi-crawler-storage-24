"""
Conftest for akshare CLI harness tests.

Ensures the real akshare library is importable even when running
inside the akshare_cli package.
"""

import importlib
import sys


def pytest_configure(config):
    """Ensure 'akshare' resolves to the pip-installed library, not the local namespace."""
    # If 'akshare' in sys.modules points to our local package, remove it
    if "akshare" in sys.modules:
        mod = sys.modules["akshare"]
        mod_file = getattr(mod, "__file__", "") or ""
        if "akshare_cli" in mod_file or "agent-harness" in mod_file:
            del sys.modules["akshare"]

    # Force import of the real akshare
    # First, temporarily remove CWD and agent-harness paths from sys.path
    original_path = sys.path[:]
    sys.path = [
        p for p in sys.path
        if "agent-harness" not in p
        or "site-packages" in p
    ]

    try:
        real_ak = importlib.import_module("akshare")
        if hasattr(real_ak, "__version__"):
            sys.modules["akshare"] = real_ak
    except ImportError:
        pass
    finally:
        sys.path = original_path
