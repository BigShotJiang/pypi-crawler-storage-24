"""Utilities package for AKShare CLI harness."""
