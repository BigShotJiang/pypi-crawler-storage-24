"""Core package for AKShare CLI harness."""
