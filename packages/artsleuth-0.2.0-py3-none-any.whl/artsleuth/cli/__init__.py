"""CLI — point, shoot, attribute."""
