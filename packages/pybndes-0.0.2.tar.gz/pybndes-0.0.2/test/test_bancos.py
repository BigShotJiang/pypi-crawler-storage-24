import unittest
from src.py_bndes.bancos import Bancos
from unittest.mock import patch, MagicMock
from pathlib import Path


class BancosTests(unittest.TestCase):

    def setUp(self):
        self.url = "https://www.bndes.gov.br/wps/portal/site/home/instituicoes-financeiras-credenciadas/rede-credenciada-brasil"
        relative_path = 'mock_data.html'
        dir = Path(__file__).parent
        absolute_path = dir.joinpath(relative_path)
        with open(absolute_path, "r") as file:
            self.html = file.read()
    
    @patch("urllib.request.urlopen")
    def test_get_bancos_credenciados(self, mock_requests):
        mock_response = MagicMock()
        mock_response.status = 200

        mock_response.read.return_value = self.html

        mock_requests.return_value = mock_response

        obj = Bancos()
        bancos = obj.get_bancos_credenciados()
        quantidade_bancos = len(bancos)

        self.assertIsInstance(bancos, list)
        self.assertEqual(quantidade_bancos, 84)

    
    
    if __name__ == '__main__':
        unittest.main(argv=['first-arg-is-ignored'], exit=False)
    