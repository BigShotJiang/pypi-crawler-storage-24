import unittest
from src.py_bndes.cartoes import Cartoes
from unittest.mock import patch, MagicMock
from pathlib import Path


class CartoesTests(unittest.TestCase):

    def setUp(self):
        relative_path = 'mock_data.json'
        dir = Path(__file__).parent
        absolute_path = dir.joinpath(relative_path)
        with open(absolute_path, "r") as file:
            self.json = file.read()
    
    @patch("requests.get")
    def test_get_fornecedores_by_name(self, mock_requests):
        mock_response = MagicMock()
        mock_response.status = 200

        mock_response.json.return_value = self.json

        mock_requests.return_value = mock_response

        obj = Cartoes()
        fornecedores = obj.get_fornecedores_by_name("AGROAVICOLA", 1)
        quantidade_fornecedores = len(fornecedores)

        self.assertIsInstance(fornecedores, list)
        self.assertEqual(quantidade_fornecedores, 2)

    @patch("requests.get")
    def test_get_fornecedores_by_nome_produto(self, mock_requests):
        mock_response = MagicMock()
        mock_response.status = 200

        mock_response.json.return_value = self.json

        mock_requests.return_value = mock_response

        obj = Cartoes()
        fornecedores = obj.get_fornecedores_by_nome_produto("Escada", 1)
        quantidade_fornecedores = len(fornecedores)

        self.assertIsInstance(fornecedores, list)
        self.assertEqual(quantidade_fornecedores, 2)

    @patch("requests.post")
    @patch("requests.get")
    def test_get_produtos_by_name(self, mock_requests, mock_post):
        mock_response = MagicMock()
        mock_response.status = 200

        mock_response.json.return_value = self.json
        mock_response.text = '<html><input name="CSRFToken" value="test_token"/></html>'
        mock_response.cookies.get_dict.return_value = {'Acesso': 'test_session', 'test_session': 'cookie_value'}

        mock_requests.return_value = mock_response

        mock_post_response = MagicMock()
        mock_post_response.text = '<html><table class="Tabela1"><tr><td><table><tr valign="top"><td>Product</td></tr></table></td></tr></table></html>'
        mock_post.return_value = mock_post_response

        obj = Cartoes()
        produtos = obj.get_produtos_by_name("Escada", 1)
        quantidade_produtos = len(produtos)

        self.assertIsInstance(produtos, list)
        self.assertEqual(quantidade_produtos, 0)
    
    
    if __name__ == '__main__':
        unittest.main(argv=['first-arg-is-ignored'], exit=False)
    