import requests
import json
import re
from bs4 import BeautifulSoup

class Cartoes:


    def __init__(self):
        self.key = "Catalogo"
        self.url_post = "https://www.cartaobndes.gov.br/cartaobndes/PaginasCartao/Catalogo.asp?Acao=LP&CTRL="
        self.url_post2 = "https://www.cartaobndes.gov.br/cartaobndes/PaginasCartao/Catalogo.asp?Acao=RBS&CTRL="


    def get_fornecedores_by_name(self, nomeFornecedor: str, pagina = 1) -> list[dict]:
        url = f"https://www.cartaobndes.gov.br/cartaobndes/Servico/Fornecedores.asp?acao=busca&chr_tiposaida=JSON&fornecedor={nomeFornecedor}&pagina={pagina}"
        response = requests.get(url)
        fornecedores = json.loads(response.json())
        return fornecedores[self.key]

    def get_fornecedores_by_nome_produto(self, nomeProduto: str, pagina = 1) -> list[dict]:
        url = f"https://www.cartaobndes.gov.br/cartaobndes/Servico/Fornecedores.asp?acao=busca&chr_tiposaida=JSON&produto={nomeProduto}&pagina={pagina}"
        response = requests.get(url)
        fornecedores = json.loads(response.json())
        return fornecedores[self.key]

    def get_produtos_by_name(self, nomeProduto: str, pagina = 1) -> list[dict]:
        produtos_html = self.__get_html_from_lista_produtos(nomeProduto, pagina)
        soup = BeautifulSoup(produtos_html, 'html.parser')
        produtos = []
        tabela_init = soup.find('table', {'class': 'Tabela1'})
        tabela = tabela_init.find_next('table')
        linhas = tabela.find_all('tr', {'valign': 'top'})#[1:]  # Ignora o cabeçalho da tabela
        for linha in linhas:
            colunas = linha.find_all('td')
            print(f"coluna: {colunas}")
            if len(colunas) < 3:
                print("Colunas insuficientes na linha, pulando...")
                continue


        return produtos

    def __get_quantidade_produtos(self, nomeProduto: str) -> int:
        html = self.__get_html_from_search_result(nomeProduto)
        soup = BeautifulSoup(html, 'html.parser')

        total_span = soup.find('a', {'id': 'qtdeprod_anchor5'})

        # Foram encontradas 760 referência(s)...
        if total_span:
            match = re.search(r'(\d+)', total_span.text)

            total_text = match.group(1) if match else '0'
            try:
                total = int(total_text)
                return total
            except ValueError:
                return 0

        return 0

    def __get_token_from_html(self, html: str) -> str:
        soup = BeautifulSoup(html, 'html.parser')
        token = soup.find('input', {'name': 'CSRFToken'})
        if token:
            return token['value']
        return ''

    def __get_html_from_search_result(self, nomeProduto: str, pagina = 1) -> str:
        url_produtos = "https://www.cartaobndes.gov.br/cartaobndes/PaginasCartao/Catalogo.asp?Acao=RBS&CTRL="
        resp = requests.get(url_produtos)
        html = resp.text
        token = self.__get_token_from_html(html)

        __cookie = resp.cookies.get_dict()
        __session_id = list(__cookie)[1]
        cookie_key = __cookie[__session_id]

        dict_request = {
            "chr_PalavraPesquisadaHidden": "",
            "chr_PalavraPesquisada": nomeProduto,
            "CSRFToken": token
        }
        response = self.__make_request(dict_request, __cookie, __session_id)
        return response

    def __get_html_from_lista_produtos(self, nomeProduto: str, pagina = 1) -> str:
        url_produtos = "https://www.cartaobndes.gov.br/cartaobndes/PaginasCartao/Catalogo.asp?Acao=BS&CTRL="
        resp = requests.get(url_produtos)
        html = resp.text
        token = self.__get_token_from_html(html)

        __cookie = resp.cookies.get_dict()
        __session_id = list(__cookie)[1]
        cookie_key = __cookie[__session_id]
        print(f"Session ID: {__session_id} - CookieKey: {cookie_key}")
        print(f"TESTE => Acesso={__cookie['Acesso']},{__session_id}={__cookie[__session_id]}")

        dict_request = {
            "chr_PalavraPesquisadaHidden": "",
            "chr_PalavraPesquisada": nomeProduto,
            "int_PaginaAtual": pagina.__str__(),
            "CSRFToken": token
        }
        response = self.__make_request(dict_request, __cookie, __session_id)
        return response

    def __make_request(self, dict_request: dict, cookies: dict, session_id: str) -> str:
        response = requests.post(self.url_post, data=dict_request, headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "Host": "www.cartaobndes.gov.br",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome",
            "Origin": "https://www.cartaobndes.gov.br",
            "Referer": "https://www.cartaobndes.gov.br/cartaobndes/PaginasCartao/Catalogo.asp?Acao=BS&CTRL=",
            "Cookie": f"Acesso={cookies['Acesso']},{session_id}={cookies[session_id]}",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Accept-Language": "pt-BR,pt;q=0.9",
            "Cache-Control": "max-age=0",
            "Connection": "keep-alive",
            "Content-Length": str(len(json.dumps(dict_request))),
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "same-origin",
            "Sec-Fetch-User": "?1",
            "Upgrade-Insecure-Requests": "1",
            "sec-ch-ua": '"Google Chrome";v="123", "Not:A-Brand";v="8", "Chromium";v="123"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "Windows"
        })
        soup = BeautifulSoup(response.text, 'html.parser')
        captcha = soup.find('input', {'name': 'bloq'})

        if captcha is not None:
            print("Captcha encontrado!")
            print(captcha['value'])
            if captcha['value'] == 'S':
                raise Exception("reCaptcha foi ativado! Favor tentar novamente!")

        return response.text
