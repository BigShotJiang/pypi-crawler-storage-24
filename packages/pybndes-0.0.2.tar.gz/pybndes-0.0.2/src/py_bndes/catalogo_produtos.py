class CatalogoProdutos:
    def __init__(self):
        self.produtos = []
        self.quantidade_paginas = 0
        self.quantidade_produtos = 0
        self.pagina_atual = 0
        