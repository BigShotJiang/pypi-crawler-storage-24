from bs4 import BeautifulSoup
import urllib.request
import certifi
import ssl
from lxml import etree


class Bancos:


    def __init__(self):
        self.url_get_bancos = "https://www.bndes.gov.br/wps/portal/site/home/instituicoes-financeiras-credenciadas/rede-credenciada-brasil"
        self.css = "clear: both"

    
    def get_bancos_credenciados(self) -> list[dict]:
        """
        Get the HTML content of the BNDES page with accredited banks
        """

        try:

            response = urllib.request.urlopen(self.url_get_bancos, context=ssl.create_default_context(cafile=certifi.where()))
            html_content = response.read()
            soup = BeautifulSoup(html_content, 'lxml')
            table = soup.find("div", {"style": self.css})
            
            bancos_credenciados = []
            if table:
                for row in table.children:
                    if row.name == "h2":
                        bancos_credenciados.append({"Nome": row.get_text(strip=True)})
            else:
                html_content = "No data found"

            print(bancos_credenciados)
        except Exception as e:
            print(f"An error occurred: {e}")
            bancos_credenciados = []

        return bancos_credenciados
