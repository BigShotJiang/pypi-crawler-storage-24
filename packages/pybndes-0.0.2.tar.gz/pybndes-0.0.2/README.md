# PyBNDES

Python client for BNDES (Banco Nacional de Desenvolvimento Econômico e Social) services.

## Installation

```bash
pip install pybndes
```

## Usage

```python
from pybndes import Cartoes, Bancos

# Search for suppliers by name
cartoes = Cartoes()
fornecedores = cartoes.get_fornecedores_by_name("AGROAVICOLA", 1)

# Search for suppliers by product name
fornecedores = cartoes.get_fornecedores_by_nome_produto("Escada", 1)

# Get banks
bancos = Bancos()
bancos_credenciados = bancos.get_bancos_credenciados()
```

## License

MIT
