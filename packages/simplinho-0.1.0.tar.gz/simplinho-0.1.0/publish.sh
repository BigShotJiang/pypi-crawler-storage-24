#!/usr/bin/env bash
set -euo pipefail

PYPROJECT="$(dirname "$0")/pyproject.toml"

# --- Read current version ---
current=$(grep -E '^version\s*=' "$PYPROJECT" | head -1 | sed 's/.*"\(.*\)".*/\1/')
if [[ -z "$current" ]]; then
    echo "ERROR: could not read version from $PYPROJECT" >&2
    exit 1
fi

major=$(echo "$current" | cut -d. -f1)
minor=$(echo "$current" | cut -d. -f2)
patch=$(echo "$current" | cut -d. -f3)

new_minor=$((minor + 1))
new_version="${major}.${new_minor}.0"

echo "Current version : $current"
echo "New version     : $new_version"

# --- Clean previous dist ---
rm -rf dist/

# --- Build wheel + sdist ---
python -m build --wheel --sdist

# --- Check distributions ---
python -m twine check dist/*

# --- Upload to PyPI ---
python -m twine upload dist/*

# --- Bump version in pyproject.toml only after successful upload ---
sed -i "s/^version = \"${current}\"/version = \"${new_version}\"/" "$PYPROJECT"

echo ""
echo "Published simplinho ${new_version} to PyPI."
echo "Version bumped in pyproject.toml."
