"""
Core utilities and shared types for blq CLI commands.

This module contains data classes, configuration, and utility functions
that are shared across multiple commands.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

import duckdb

from blq.config_format import (
    COMMANDS_FILE,
    CONFIG_FILE,
    load_toml,
    save_toml,
)

# Git integration - re-exported for backward compatibility
from blq.git import GitInfo, capture_git_info  # noqa: F401

if TYPE_CHECKING:
    pass

# ============================================================================
# Configuration
# ============================================================================

LQ_DIR = ".lq"
LOGS_DIR = "logs"
RAW_DIR = "raw"
SCHEMA_FILE = "schema.sql"
DB_FILE = "blq.duckdb"
# Re-export from config_format for compatibility
# COMMANDS_FILE = "commands.toml"
# CONFIG_FILE = "config.toml"
GLOBAL_LQ_DIR = Path.home() / ".lq"
PROJECTS_DIR = "projects"
GLOBAL_PROJECTS_PATH = GLOBAL_LQ_DIR / PROJECTS_DIR

# ============================================================================
# Result Types
# ============================================================================


@dataclass
class EventRef:
    """Reference to a specific event or run.

    Supports multiple formats:
    - "5" - run_id only (run reference)
    - "5:3" - run_id:event_id (numeric only)
    - "test:5" - tag:run_id (run reference)
    - "test:5:3" - tag:run_id:event_id (full reference)
    - "+1" - relative: most recent run (any source)
    - "+2" - relative: second most recent run
    - "latest" - alias for +1 (most recent run)
    - "test:+1" - relative: most recent run for tag "test"
    - "test:latest" - alias for test:+1
    - "test:+1:3" - relative: event 3 in most recent "test" run
    - "test:latest:3" - alias for test:+1:3
    """

    run_id: int | None = None  # None for relative refs until resolved
    event_id: int | None = None  # None means "all events in run"
    tag: str | None = None
    relative: int | None = None  # +1 = most recent, +2 = second most recent, etc.

    @property
    def is_run_ref(self) -> bool:
        """True if this is a run reference (no specific event)."""
        return self.event_id is None

    @property
    def is_relative(self) -> bool:
        """True if this is a relative reference (needs resolution)."""
        return self.relative is not None

    @property
    def run_ref(self) -> str:
        """Get the run reference string (without event_id)."""
        if self.is_relative:
            offset_str = f"+{self.relative}"
            if self.tag:
                return f"{self.tag}:{offset_str}"
            return offset_str
        if self.tag:
            return f"{self.tag}:{self.run_id}"
        return str(self.run_id)

    def __str__(self) -> str:
        if self.is_relative:
            offset_str = f"+{self.relative}"
            if self.tag:
                if self.event_id is not None:
                    return f"{self.tag}:{offset_str}:{self.event_id}"
                return f"{self.tag}:{offset_str}"
            if self.event_id is not None:
                return f"{offset_str}:{self.event_id}"
            return offset_str
        if self.tag:
            if self.event_id is not None:
                return f"{self.tag}:{self.run_id}:{self.event_id}"
            return f"{self.tag}:{self.run_id}"
        if self.event_id is not None:
            return f"{self.run_id}:{self.event_id}"
        return str(self.run_id)

    @classmethod
    def parse(cls, ref: str) -> EventRef:
        """Parse a reference string into an EventRef.

        Formats:
        - "5" - run_id only
        - "5:3" - run_id:event_id
        - "test:5" - tag:run_id
        - "test:5:3" - tag:run_id:event_id
        - "+1" - relative: most recent run
        - "+2" - relative: second most recent run
        - "latest" - alias for +1 (most recent run)
        - "test:+1" - relative: most recent run for tag "test"
        - "test:latest" - alias for test:+1
        - "test:+1:3" - relative: event 3 in most recent "test" run
        - "test:latest:3" - alias for test:+1:3
        """
        parts = ref.split(":")

        # Helper to check if a part is a relative offset (+N or "latest")
        def is_relative_offset(s: str) -> bool:
            return s == "latest" or (s.startswith("+") and s[1:].isdigit())

        def parse_relative(s: str) -> int:
            if s == "latest":
                return 1  # latest is equivalent to +1
            return int(s[1:])

        if len(parts) == 1:
            # "+1", "latest", or "5"
            if is_relative_offset(parts[0]):
                return cls(relative=parse_relative(parts[0]))
            return cls(run_id=int(parts[0]))

        elif len(parts) == 2:
            # Could be "+1:3", "latest:3", "5:3", "test:5", "test:+1", or "test:latest"
            if is_relative_offset(parts[0]):
                # "+1:3" or "latest:3" - relative with event_id
                return cls(relative=parse_relative(parts[0]), event_id=int(parts[1]))
            try:
                run_id = int(parts[0])
                event_id = int(parts[1])
                return cls(run_id=run_id, event_id=event_id)
            except ValueError:
                # First part is a tag: "test:5", "test:+1", or "test:latest"
                tag = parts[0]
                if is_relative_offset(parts[1]):
                    return cls(tag=tag, relative=parse_relative(parts[1]))
                run_id = int(parts[1])
                return cls(run_id=run_id, tag=tag)

        elif len(parts) == 3:
            # "tag:run_id:event_id", "tag:+1:event_id", or "tag:latest:event_id"
            tag = parts[0]
            if is_relative_offset(parts[1]):
                return cls(tag=tag, relative=parse_relative(parts[1]), event_id=int(parts[2]))
            run_id = int(parts[1])
            event_id = int(parts[2])
            return cls(run_id=run_id, event_id=event_id, tag=tag)

        else:
            raise ValueError(
                f"Invalid reference: {ref}. "
                "Expected format: run_id, run_id:event_id, tag:run_id, tag:run_id:event_id, "
                "+N (relative), latest, tag:+N, tag:latest, or tag:+N:event_id"
            )


@dataclass
class EventSummary:
    """Summary of a parsed event for structured output.

    Uses BIRD spec column names (ref_file, ref_line, ref_column).
    """

    ref: str
    severity: str | None
    ref_file: str | None
    ref_line: int | None
    ref_column: int | None
    message: str | None
    error_code: str | None = None
    fingerprint: str | None = None
    # For test results
    test_name: str | None = None
    # For log line context (when available)
    log_line_start: int | None = None
    log_line_end: int | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict, stripping null values."""
        return {k: v for k, v in asdict(self).items() if v is not None}

    def to_compact_dict(self) -> dict[str, Any]:
        """Convert to compact dict with only ref and message."""
        d: dict[str, Any] = {"ref": self.ref}
        if self.message:
            d["message"] = self.message
        if self.error_code:
            d["error_code"] = self.error_code
        return d

    def location(self) -> str:
        """Format as file:line:col string."""
        if not self.ref_file:
            return "?"
        loc = self.ref_file
        if self.ref_line is not None:
            loc += f":{self.ref_line}"
            if self.ref_column and self.ref_column > 0:
                loc += f":{self.ref_column}"
        return loc


@dataclass
class RunResult:
    """Structured result from running a command."""

    run_id: int
    command: str
    status: str  # "OK", "FAIL", "WARN"
    exit_code: int
    started_at: str
    completed_at: str
    duration_sec: float
    summary: dict[str, int] = field(default_factory=dict)
    errors: list[EventSummary] = field(default_factory=list)
    warnings: list[EventSummary] = field(default_factory=list)
    infos: list[EventSummary] = field(default_factory=list)
    parquet_path: str | None = None
    output_stats: dict[str, int | list[str]] = field(default_factory=dict)
    source_name: str | None = None  # Tag for run_ref (e.g., "build", "test", "pytest")
    status_reason: str | None = None  # Human-readable explanation for the status

    def to_json(self) -> str:
        """Convert to JSON string."""
        data = {
            "run_id": self.run_id,
            "command": self.command,
            "status": self.status,
            "exit_code": self.exit_code,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "duration_sec": round(self.duration_sec, 3),
            "summary": self.summary,
            "errors": [e.to_dict() for e in self.errors],
        }
        if self.source_name:
            data["source_name"] = self.source_name
        if self.status_reason:
            data["status_reason"] = self.status_reason
        if self.warnings:
            data["warnings"] = [w.to_dict() for w in self.warnings]
        if self.infos:
            data["infos"] = [i.to_compact_dict() for i in self.infos]
        if self.output_stats:
            data["output_stats"] = self.output_stats
        return json.dumps(data, indent=2)

    def to_markdown(self, include_warnings: bool = False) -> str:
        """Convert to markdown summary."""
        badge = {"OK": "✓", "FAIL": "✗", "WARN": "⚠"}.get(self.status, "?")
        lines = [
            f"## {badge} Build Result: {self.status}",
            "",
            f"**Command:** `{self.command}`",
            f"**Duration:** {self.duration_sec:.1f}s | **Exit code:** {self.exit_code} | "
            f"**Run ID:** {self.run_id}",
        ]
        if self.status_reason:
            lines.append(f"**Reason:** {self.status_reason}")
        lines.append("")

        if self.errors:
            lines.append(f"### Errors ({len(self.errors)})")
            lines.append("")
            for e in self.errors[:20]:  # Limit to 20 in markdown
                msg = (e.message or "")[:100]
                lines.append(f"- `{e.location()}` [{e.ref}] - {msg}")
            if len(self.errors) > 20:
                lines.append(f"- ... and {len(self.errors) - 20} more errors")
            lines.append("")

        if include_warnings and self.warnings:
            lines.append(f"### Warnings ({len(self.warnings)})")
            lines.append("")
            for w in self.warnings[:10]:
                msg = (w.message or "")[:100]
                lines.append(f"- `{w.location()}` [{w.ref}] - {msg}")
            if len(self.warnings) > 10:
                lines.append(f"- ... and {len(self.warnings) - 10} more warnings")
            lines.append("")

        if not self.errors and not (include_warnings and self.warnings):
            lines.append("No errors or warnings detected.")
            lines.append("")

        return "\n".join(lines)


# ============================================================================
# Well-known exit codes for common build/test tools
# ============================================================================

WELL_KNOWN_EXIT_CODES: dict[str, dict[int, str]] = {
    "pytest": {
        1: "Tests failed",
        2: "Interrupted",
        3: "Internal error",
        4: "Usage error",
        5: "No tests collected",
    },
    "ruff": {1: "Lint violations found", 2: "Fatal error"},
    "mypy": {1: "Type errors found", 2: "Fatal error"},
    "cargo": {101: "Build/test failed"},
    "make": {2: "Errors encountered"},
    "go": {1: "Build/test failed", 2: "Usage error"},
    "npm": {1: "Generic failure"},
    "tsc": {1: "Type errors found"},
    "eslint": {1: "Lint violations found", 2: "Fatal error"},
    "black": {1: "Files would be reformatted", 123: "Internal error"},
    "flake8": {1: "Violations found"},
    "gcc": {1: "Compilation errors"},
    "rustc": {1: "Compilation errors"},
}


def _get_exit_code_reason(source_name: str, exit_code: int) -> str | None:
    """Look up a human-readable reason for a tool's exit code.

    Tries exact match on source_name, then prefix match (e.g., "pytest-unit"
    matches the "pytest" entry).

    Returns None if no match found.
    """
    # Exact match
    if source_name in WELL_KNOWN_EXIT_CODES:
        return WELL_KNOWN_EXIT_CODES[source_name].get(exit_code)

    # Prefix match (e.g., "pytest-unit" starts with "pytest")
    for tool_name, codes in WELL_KNOWN_EXIT_CODES.items():
        if source_name.startswith(tool_name):
            return codes.get(exit_code)

    return None


# Default environment variables to capture for all runs
DEFAULT_CAPTURE_ENV = [
    # Path and executables
    "PATH",
    "HOME",
    "USER",
    "SHELL",
    # Python
    "PYTHONPATH",
    "VIRTUAL_ENV",
    "CONDA_DEFAULT_ENV",
    "CONDA_PREFIX",
    # C/C++
    "CC",
    "CXX",
    "CFLAGS",
    "CXXFLAGS",
    "LDFLAGS",
    "LD_LIBRARY_PATH",
    # Build tools
    "MAKEFLAGS",
    "CMAKE_PREFIX_PATH",
    # Node.js
    "NODE_PATH",
    "NPM_CONFIG_PREFIX",
    # Rust
    "CARGO_HOME",
    "RUSTUP_HOME",
    # Go
    "GOPATH",
    "GOROOT",
    # Java
    "JAVA_HOME",
    "CLASSPATH",
    # CI/CD
    "CI",
    "GITHUB_ACTIONS",
    "GITLAB_CI",
    "JENKINS_URL",
]


# ============================================================================
# Project Configuration
# ============================================================================


@dataclass
class ProjectInfo:
    """Project identity derived from git remote."""

    namespace: str | None = None  # e.g., "teaguesterling" from github.com/teaguesterling/blq-cli
    project: str | None = None  # e.g., "blq"

    def is_detected(self) -> bool:
        """Return True if project info was successfully detected."""
        return self.namespace is not None and self.project is not None


def _extract_provider_from_host(host: str) -> str:
    """Extract provider name from hostname.

    Args:
        host: Git host (e.g., github.com, gitlab.com, bitbucket.org)

    Returns:
        Provider name (e.g., github, gitlab, bitbucket)
    """
    # Common providers - extract short name
    host_lower = host.lower()
    if "github" in host_lower:
        return "github"
    elif "gitlab" in host_lower:
        return "gitlab"
    elif "bitbucket" in host_lower:
        return "bitbucket"
    elif "codeberg" in host_lower:
        return "codeberg"
    elif "gitea" in host_lower:
        return "gitea"
    elif "sr.ht" in host_lower or "sourcehut" in host_lower:
        return "sourcehut"
    else:
        # Use sanitized hostname for self-hosted instances
        return host.replace(".", "_").replace(":", "_")


def detect_project_info() -> ProjectInfo:
    """Detect project namespace and name from git remote or filesystem path.

    Detection order:
    1. Git remote origin URL (if available)
    2. Fallback to filesystem path (parent dirs as namespace, cwd as project)

    Git remote formats supported:
    - git@github.com:namespace/project.git
    - https://github.com/namespace/project.git
    - ssh://git@github.com/namespace/project.git

    Namespace format includes provider:
    - github__teaguesterling (for github.com/teaguesterling)
    - gitlab__myorg (for gitlab.com/myorg)

    Filesystem fallback:
    - /home/teague/Projects/myapp → namespace=local__home__teague__Projects, project=myapp

    Returns:
        ProjectInfo with namespace and project.
    """
    # Try git remote first
    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            url = result.stdout.strip()

            # Try SSH format: git@host:owner/project.git
            ssh_match = re.match(r"^git@([^:]+):([^/]+)/([^/]+?)(?:\.git)?$", url)
            if ssh_match:
                host = ssh_match.group(1)
                owner = ssh_match.group(2)
                project = ssh_match.group(3)
                provider = _extract_provider_from_host(host)
                return ProjectInfo(
                    namespace=f"{provider}__{owner}",
                    project=project,
                )

            # Try HTTPS/SSH URL format: https://host/owner/project.git
            url_match = re.match(r"^(?:https?|ssh)://([^/]+)/([^/]+)/([^/]+?)(?:\.git)?$", url)
            if url_match:
                host = url_match.group(1)
                owner = url_match.group(2)
                project = url_match.group(3)
                provider = _extract_provider_from_host(host)
                return ProjectInfo(
                    namespace=f"{provider}__{owner}",
                    project=project,
                )

            # Try simple path format: owner/project (assume local/unknown provider)
            path_match = re.match(r"^([^/]+)/([^/]+?)(?:\.git)?$", url)
            if path_match:
                return ProjectInfo(
                    namespace=f"git__{path_match.group(1)}",
                    project=path_match.group(2),
                )

    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass

    # Fallback to filesystem path
    cwd = Path.cwd()
    project = cwd.name
    # Tokenize parent path: /home/teague/Projects → local__home__teague__Projects
    parent = str(cwd.parent).lstrip("/")
    namespace = f"local__{parent.replace('/', '__')}" if parent else "local"

    return ProjectInfo(namespace=namespace, project=project)


# ============================================================================
# Watch Configuration
# ============================================================================


@dataclass
class WatchConfig:
    """Configuration for watch mode."""

    debounce_ms: int = 500
    include: list[str] = field(default_factory=lambda: ["src/**/*", "tests/**/*"])
    exclude: list[str] = field(
        default_factory=lambda: [
            "**/__pycache__/**",
            "**/*.pyc",
            "**/.git/**",
            ".lq/**",
            "**/*.egg-info/**",
            "**/node_modules/**",
            "**/.venv/**",
        ]
    )
    clear_screen: bool = False
    quiet: bool = False


# ============================================================================
# Unified Configuration (BlqConfig)
# ============================================================================


@dataclass
class BlqConfig:
    """Unified configuration for blq.

    This class consolidates path management, settings, and command registry
    into a single configuration object. It provides:

    - Core path management (lq_dir and derived paths)
    - Settings from config.toml (capture_env, namespace, project)
    - Lazy-loaded command registry
    - Factory methods for finding/loading configuration

    Example usage:
        # Find and load config from current directory
        config = BlqConfig.ensure()  # Exits with error if not initialized

        # Access paths
        logs_path = config.logs_dir
        schema_path = config.schema_path

        # Access commands
        if "build" in config.commands:
            cmd = config.commands["build"]
    """

    # Core path (everything derives from this)
    lq_dir: Path

    # Settings from config.toml
    capture_env: list[str] = field(default_factory=lambda: DEFAULT_CAPTURE_ENV.copy())
    namespace: str | None = None
    project: str | None = None

    # Storage mode: "bird" (v2, default) or "parquet" (v1, legacy)
    storage_mode: str = "bird"

    # Lazy-loaded commands (private, access via commands property)
    _commands: dict | None = field(default=None, repr=False)

    # Hooks configuration (private, access via hooks_config property)
    _hooks_config: dict | None = field(default=None, repr=False)

    # Watch configuration (private, access via watch_config property)
    _watch_config: WatchConfig | None = field(default=None, repr=False)

    # MCP configuration (private, access via mcp_config property)
    _mcp_config: dict | None = field(default=None, repr=False)

    # Source lookup configuration (private, access via source_lookup_* properties)
    _source_lookup: dict | None = field(default=None, repr=False)

    # Storage configuration (private, access via storage_* properties)
    _storage_config: dict | None = field(default=None, repr=False)

    # Computed paths
    @property
    def logs_dir(self) -> Path:
        """Path to logs directory (.lq/logs)."""
        return self.lq_dir / LOGS_DIR

    @property
    def raw_dir(self) -> Path:
        """Path to raw logs directory (.lq/raw)."""
        return self.lq_dir / RAW_DIR

    @property
    def schema_path(self) -> Path:
        """Path to schema file (.lq/schema.sql)."""
        return self.lq_dir / SCHEMA_FILE

    @property
    def db_path(self) -> Path:
        """Path to database file (.lq/blq.duckdb)."""
        return self.lq_dir / DB_FILE

    @property
    def config_path(self) -> Path:
        """Path to config file (.lq/config.toml)."""
        return self.lq_dir / CONFIG_FILE

    @property
    def commands_path(self) -> Path:
        """Path to commands file (.lq/commands.toml)."""
        return self.lq_dir / COMMANDS_FILE

    @property
    def use_bird(self) -> bool:
        """Check if BIRD storage mode is enabled."""
        return self.storage_mode == "bird"

    @property
    def commands(self) -> dict[str, RegisteredCommand]:
        """Lazy-load commands from commands.toml.

        Returns:
            Dict mapping command names to RegisteredCommand instances.
        """
        if self._commands is None:
            self._commands = _load_commands_impl(self.lq_dir)
        return self._commands

    def reload_commands(self) -> None:
        """Force reload of commands from disk."""
        self._commands = None

    @property
    def hooks_config(self) -> dict:
        """Get hooks configuration.

        Returns:
            Dict with hooks configuration, or empty dict if not configured.
        """
        if self._hooks_config is None:
            # Load from config.toml
            if self.config_path.exists():
                data = load_toml(self.config_path)
                self._hooks_config = data.get("hooks", {})
            else:
                self._hooks_config = {}
        return self._hooks_config

    @property
    def watch_config(self) -> WatchConfig:
        """Get watch configuration.

        Returns:
            WatchConfig with watch settings.
        """
        if self._watch_config is None:
            # Load from config.toml
            if self.config_path.exists():
                data = load_toml(self.config_path)
                watch_data = data.get("watch", {})
                self._watch_config = WatchConfig(
                    debounce_ms=watch_data.get("debounce_ms", 500),
                    include=watch_data.get("include", ["src/**/*", "tests/**/*"]),
                    exclude=watch_data.get(
                        "exclude",
                        [
                            "**/__pycache__/**",
                            "**/*.pyc",
                            "**/.git/**",
                            ".lq/**",
                            "**/*.egg-info/**",
                            "**/node_modules/**",
                            "**/.venv/**",
                        ],
                    ),
                    clear_screen=watch_data.get("clear_screen", False),
                    quiet=watch_data.get("quiet", False),
                )
            else:
                self._watch_config = WatchConfig()
        return self._watch_config

    @property
    def mcp_config(self) -> dict:
        """Get MCP server configuration.

        Returns:
            Dict with MCP configuration, including:
            - disabled_tools: List of tool names to disable
        """
        if self._mcp_config is None:
            # Load from config.toml
            if self.config_path.exists():
                data = load_toml(self.config_path)
                self._mcp_config = data.get("mcp", {})
            else:
                self._mcp_config = {}
        return self._mcp_config

    @property
    def source_lookup_enabled(self) -> bool:
        """Whether source file lookup is enabled for inspect command.

        Returns:
            True if source lookup is enabled (default: True)
        """
        self._ensure_source_lookup_loaded()
        return bool(self._source_lookup.get("enabled", True))  # type: ignore[union-attr]

    @property
    def ref_root(self) -> Path:
        """Root path for resolving ref_file paths in source lookup.

        Returns:
            Path to root directory (default: current working directory)
        """
        self._ensure_source_lookup_loaded()
        root = self._source_lookup.get("ref_root", ".")  # type: ignore[union-attr]
        return Path(root)

    def _ensure_source_lookup_loaded(self) -> None:
        """Load source_lookup config if not already loaded."""
        if self._source_lookup is None:
            if self.config_path.exists():
                data = load_toml(self.config_path)
                self._source_lookup = data.get("source_lookup", {})
            else:
                self._source_lookup = {}

    @property
    def storage_config(self) -> dict[str, Any]:
        """Get project-level [storage] config as a raw dict.

        This exposes .lq/config.toml's [storage] section for merging
        with user config during autoprune.

        Returns:
            Dict of storage config keys and values
        """
        self._ensure_storage_config_loaded()
        return dict(self._storage_config or {})

    @property
    def keep_raw(self) -> bool:
        """Whether to always keep raw output in BIRD storage.

        When True, raw command output is stored for all runs, enabling
        log context display in inspect/event commands.

        Returns:
            True if keep_raw is enabled (default: False)
        """
        self._ensure_storage_config_loaded()
        return bool(self._storage_config.get("keep_raw", False))  # type: ignore[union-attr]

    def _ensure_storage_config_loaded(self) -> None:
        """Load storage config if not already loaded."""
        if self._storage_config is None:
            if self.config_path.exists():
                data = load_toml(self.config_path)
                self._storage_config = data.get("storage", {})
            else:
                self._storage_config = {}

    @classmethod
    def find(cls, start_dir: Path | None = None) -> BlqConfig | None:
        """Find .lq directory in start_dir or parents and load config.

        Args:
            start_dir: Directory to start searching from (default: cwd)

        Returns:
            BlqConfig if found, None otherwise.
        """
        if start_dir is None:
            start_dir = Path.cwd()

        # Search current directory and parents
        for p in [start_dir, *list(start_dir.parents)]:
            lq_path = p / LQ_DIR
            if lq_path.exists() and lq_path.is_dir():
                return cls.load(lq_path)

        return None

    @classmethod
    def load(cls, lq_dir: Path) -> BlqConfig:
        """Load configuration from an existing .lq directory.

        Merges user-level defaults (from ~/.config/blq/config.toml) with
        project-level config (from .lq/config.toml).

        Args:
            lq_dir: Path to the .lq directory

        Returns:
            BlqConfig loaded from config.toml (or defaults)
        """
        from blq.user_config import UserConfig

        config_path = lq_dir / CONFIG_FILE

        # Load user config for defaults
        user_config = UserConfig.load()

        # Start with defaults + user config additions
        capture_env = DEFAULT_CAPTURE_ENV.copy()
        # Add user-level extra capture env vars
        for var in user_config.extra_capture_env:
            if var not in capture_env:
                capture_env.append(var)

        namespace = None
        project = None
        storage_mode = "bird"  # Default to BIRD mode

        # Load from config.toml if it exists
        if config_path.exists():
            data = load_toml(config_path)

            # Load capture_env (project config overrides defaults completely if set)
            loaded_env = data.get("capture_env")
            if isinstance(loaded_env, list):
                capture_env = loaded_env
                # Still add user-level extras to project config
                for var in user_config.extra_capture_env:
                    if var not in capture_env:
                        capture_env.append(var)

            # Load project info
            project_data = data.get("project", {})
            namespace = project_data.get("namespace")
            project = project_data.get("project")

            # Load storage mode
            storage_data = data.get("storage", {})
            storage_mode = storage_data.get("mode", "bird")

        return cls(
            lq_dir=lq_dir,
            capture_env=capture_env,
            namespace=namespace,
            project=project,
            storage_mode=storage_mode,
        )

    @classmethod
    def ensure(cls, start_dir: Path | None = None, lq_dir: Path | None = None) -> BlqConfig:
        """Find configuration or exit with error.

        This is a convenience method for CLI commands that require
        an initialized project.

        Args:
            start_dir: Directory to start searching from (default: cwd)
            lq_dir: Explicit .lq directory to use (overrides discovery)

        Returns:
            BlqConfig if found

        Raises:
            SystemExit: If .lq directory not found
        """
        # If explicit lq_dir is provided, use it directly
        if lq_dir is not None:
            lq_path = Path(lq_dir).expanduser()
            if not lq_path.exists():
                print(f"Error: .lq directory does not exist: {lq_path}", file=sys.stderr)
                sys.exit(1)
            return cls.load(lq_path)

        config = cls.find(start_dir)
        if config is None:
            print("Error: .lq not initialized. Run 'blq init' first.", file=sys.stderr)
            sys.exit(1)
        return config

    def save(self) -> None:
        """Save configuration to config.toml."""
        data: dict[str, Any] = {"capture_env": self.capture_env}

        # Include storage mode
        if self.storage_mode != "bird":
            data["storage"] = {"mode": self.storage_mode}

        # Include project info if present
        if self.namespace or self.project:
            data["project"] = {}
            if self.namespace:
                data["project"]["namespace"] = self.namespace
            if self.project:
                data["project"]["project"] = self.project

        # Include hooks config if present
        if self._hooks_config:
            data["hooks"] = self._hooks_config

        save_toml(self.config_path, data)

    def save_commands(self) -> None:
        """Save commands to commands.toml."""
        if self._commands is not None:
            _save_commands_impl(self.lq_dir, self._commands)


# ============================================================================
# Command Registry
# ============================================================================

# Command name patterns mapped to format hints
# Keys are substrings/patterns to match in the command, values are format names
COMMAND_FORMAT_HINTS: dict[str, str] = {
    # Python tools
    "pytest": "pytest_text",
    "python -m pytest": "pytest_text",
    "mypy": "mypy_text",
    "ruff": "generic_lint",
    "flake8": "flake8_text",
    "pylint": "pylint_text",
    "black": "black_text",
    "autopep8": "autopep8_text",
    "yapf": "yapf_text",
    "bandit": "bandit_json",
    # Rust tools
    "cargo test": "cargo_test_json",
    "cargo build": "cargo_build",
    "cargo clippy": "clippy_json",
    # JavaScript/TypeScript
    "npm test": "mocha_chai_text",
    "yarn test": "mocha_chai_text",
    "jest": "mocha_chai_text",
    "mocha": "mocha_chai_text",
    "eslint": "eslint_json",
    # Go
    "go test": "gotest_json",
    # Build systems
    "make": "make_error",
    "cmake": "cmake_build",
    "bazel": "bazel_build",
    "gradle": "gradle_build",
    "mvn": "maven_build",
    "maven": "maven_build",
    "msbuild": "msbuild",
    # Other linters
    "shellcheck": "shellcheck_json",
    "hadolint": "hadolint_json",
    "yamllint": "yamllint_json",
    "sqlfluff": "sqlfluff_json",
    "terraform": "terraform_text",
    "tflint": "tflint_json",
    "tfsec": "tfsec_json",
    # CI/tools
    "gh ": "github_cli",
    "ansible": "ansible_text",
    "docker": "node_build",  # Docker build output is similar
    # Ruby
    "rspec": "rspec_text",
    "rubocop": "rubocop_json",
    # Other
    "trivy": "trivy_json",
    "valgrind": "valgrind",
    "gdb": "gdb_lldb",
    "lldb": "gdb_lldb",
}


def detect_format_from_command(cmd: str) -> str:
    """Detect the best format hint based on the command string.

    Analyzes the command to identify known tools and returns the
    appropriate format for parsing their output. Uses duck_hunt's
    pattern matching when available, falls back to built-in hints.

    Args:
        cmd: The command string to analyze

    Returns:
        Format name if a known tool is detected, "auto" otherwise

    Examples:
        >>> detect_format_from_command("python -m pytest tests/")
        'pytest_text'
        >>> detect_format_from_command("mypy src/")
        'mypy_text'
        >>> detect_format_from_command("unknown-tool")
        'auto'
    """
    # Try duck_hunt's pattern matching first (more comprehensive)
    try:
        import duckdb

        conn = duckdb.connect()
        conn.execute("LOAD duck_hunt")
        result = conn.execute(
            "SELECT format FROM duck_hunt_match_command_patterns(?) ORDER BY priority DESC LIMIT 1",
            [cmd],
        ).fetchone()
        if result and result[0]:
            return str(result[0])
    except Exception:
        pass  # Fall through to built-in hints

    # Fall back to built-in hints
    cmd_lower = cmd.lower()

    # Check for specific patterns (longer patterns first for specificity)
    # Sort by length descending to match more specific patterns first
    for pattern in sorted(COMMAND_FORMAT_HINTS.keys(), key=len, reverse=True):
        if pattern in cmd_lower:
            return COMMAND_FORMAT_HINTS[pattern]

    return "auto"


@dataclass
class RegisteredCommand:
    """A registered command in the commands.toml file.

    Commands can be simple (cmd) or parameterized templates (tpl):

    Simple command:
        [commands.lint]
        cmd = "ruff check ."

    Template command:
        [commands.test]
        tpl = "pytest {path} {flags}"
        defaults = { path = "tests/", flags = "-v" }

    Suppress known/expected events by fingerprint:
        [commands.build]
        cmd = "make"
        suppress = ["cmake_configuration_35ff8000c51bc964"]
    """

    name: str
    cmd: str | None = None  # Simple command (no substitution)
    tpl: str | None = None  # Template with {param} placeholders
    defaults: dict[str, str] = field(default_factory=dict)  # Default values for tpl
    description: str = ""
    timeout: int | None = None  # No timeout by default
    format: str = "auto"
    capture: bool = True  # Whether to capture and parse logs (default: True)
    capture_env: list[str] = field(default_factory=list)  # Additional env vars
    suppress: list[str] = field(default_factory=list)  # Fingerprints to suppress in reports
    lines: str | None = None  # Default line selection for run/exec output (e.g., "+20-")

    @property
    def is_template(self) -> bool:
        """Whether this is a parameterized template command."""
        return self.tpl is not None

    @property
    def template(self) -> str:
        """Get the command template (tpl if set, else cmd)."""
        if self.tpl is not None:
            return self.tpl
        return self.cmd or ""

    def required_params(self) -> set[str]:
        """Get parameters without defaults (required)."""
        if not self.is_template or not self.tpl:
            return set()
        # Find all {param} placeholders (simple str.format style)
        all_params = set(re.findall(r"\{(\w+)\}", self.tpl))
        return all_params - set(self.defaults.keys())

    def render(
        self,
        args: dict[str, str],
        extra: list[str] | None = None,
    ) -> str:
        """Render template with provided args + defaults.

        Args:
            args: Named arguments to substitute
            extra: Extra arguments to append

        Returns:
            Expanded command string

        Raises:
            ValueError: If required params missing or unknown args provided
        """
        if not self.is_template or not self.tpl:
            result = self.cmd or ""
            if extra:
                result = result + " " + " ".join(extra)
            return result

        # Find all placeholders
        all_params = set(re.findall(r"\{(\w+)\}", self.tpl))

        # Check for unknown args
        for name in args:
            if name not in all_params:
                valid_args = ", ".join(sorted(all_params))
                raise ValueError(f"Unknown argument '{name}'. Valid arguments: {valid_args}")

        # Merge defaults with provided args
        merged = {**self.defaults, **args}

        # Check for missing required params
        missing = all_params - set(merged.keys())
        if missing:
            raise ValueError(f"Missing required params: {missing}")

        # Use str.format for substitution (handles {{}} escaping)
        result = self.tpl.format(**merged)

        # Append extra args
        if extra:
            result = result + " " + " ".join(extra)

        return result

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        d: dict[str, Any] = {}

        # Use tpl if template, else cmd
        if self.is_template:
            d["tpl"] = self.tpl
            if self.defaults:
                d["defaults"] = self.defaults
        else:
            d["cmd"] = self.cmd

        d["description"] = self.description
        if self.timeout is not None:
            d["timeout"] = self.timeout
        d["format"] = self.format

        if not self.capture:
            d["capture"] = False
        if self.capture_env:
            d["capture_env"] = self.capture_env
        if self.suppress:
            d["suppress"] = self.suppress
        if self.lines is not None:
            d["lines"] = self.lines
        return d


@dataclass
class CommandPlaceholder:
    """A placeholder in a command template.

    Placeholders can be:
    - {name} - keyword-only, required
    - {name=default} - keyword-only, optional
    - {name:} - positional-able, required
    - {name:=default} - positional-able, optional
    """

    name: str
    default: str | None  # None = required
    positional: bool  # Can be filled positionally


# Regex to parse placeholders from command template
# Matches: {name}, {name=default}, {name:}, {name:=default}
_PLACEHOLDER_PATTERN = re.compile(r"\{([a-zA-Z_][a-zA-Z0-9_]*)(:=?([^}]*)?|=([^}]*))?\}")


def parse_placeholders(template: str) -> list[CommandPlaceholder]:
    """Parse placeholders from a command template.

    Args:
        template: Command template string with placeholders

    Returns:
        List of CommandPlaceholder in template order
    """
    placeholders = []
    for match in _PLACEHOLDER_PATTERN.finditer(template):
        name = match.group(1)
        modifier = match.group(2)  # :, :=default, =default, or None

        if modifier is None:
            # {name} - keyword-only, required
            placeholders.append(CommandPlaceholder(name=name, default=None, positional=False))
        elif modifier == ":":
            # {name:} - positional-able, required
            placeholders.append(CommandPlaceholder(name=name, default=None, positional=True))
        elif modifier.startswith(":="):
            # {name:=default} - positional-able, optional
            default = match.group(3) if match.group(3) is not None else ""
            placeholders.append(CommandPlaceholder(name=name, default=default, positional=True))
        elif modifier.startswith("="):
            # {name=default} - keyword-only, optional
            default = match.group(4) if match.group(4) is not None else ""
            placeholders.append(CommandPlaceholder(name=name, default=default, positional=False))

    return placeholders


def expand_command(
    template: str,
    named_args: dict[str, str],
    positional_args: list[str],
    extra_args: list[str] | None = None,
) -> str:
    """Expand a command template with provided arguments.

    Args:
        template: Command template with placeholders
        named_args: Arguments provided as key=value
        positional_args: Arguments provided positionally
        extra_args: Extra arguments to append (passthrough)

    Returns:
        Expanded command string

    Raises:
        ValueError: If required argument is missing
    """
    placeholders = parse_placeholders(template)

    # Build map of placeholder values
    values: dict[str, str] = {}

    # First, fill from named args
    for name, value in named_args.items():
        # Check if this is a valid placeholder name
        placeholder_names = {p.name for p in placeholders}
        if name not in placeholder_names:
            valid_args = ", ".join(sorted(placeholder_names))
            raise ValueError(f"Unknown argument '{name}'. Valid arguments: {valid_args}")
        values[name] = value

    # Second, fill positional-able placeholders from positional args
    positional_placeholders = [p for p in placeholders if p.positional]
    positional_idx = 0
    for placeholder in positional_placeholders:
        if placeholder.name in values:
            # Already filled by named arg
            continue
        if positional_idx < len(positional_args):
            values[placeholder.name] = positional_args[positional_idx]
            positional_idx += 1

    # Remaining positional args become extra args
    remaining_positional = positional_args[positional_idx:]

    # Third, apply defaults and check required
    for placeholder in placeholders:
        if placeholder.name not in values:
            if placeholder.default is not None:
                values[placeholder.name] = placeholder.default
            else:
                raise ValueError(f"Missing required argument '{placeholder.name}'")

    # Substitute placeholders in template
    result = template
    for match in _PLACEHOLDER_PATTERN.finditer(template):
        name = match.group(1)
        result = result.replace(match.group(0), values[name], 1)

    # Append extra args
    all_extra = remaining_positional + (extra_args or [])
    if all_extra:
        result = result + " " + " ".join(all_extra)

    return result


def format_command_help(cmd: RegisteredCommand) -> str:
    """Format help text for a registered command.

    Args:
        cmd: The registered command

    Returns:
        Formatted help string
    """
    template = cmd.template
    lines = [f"{cmd.name}: {template}"]

    if cmd.description:
        lines.append(f"  {cmd.description}")

    # For template commands with tpl, show params from defaults
    if cmd.is_template:
        # Find all {param} placeholders
        all_params = set(re.findall(r"\{(\w+)\}", template))
        if all_params:
            lines.append("")
            lines.append("Arguments:")
            for name in sorted(all_params):
                if name in cmd.defaults:
                    lines.append(f"  {name:<16} default: {cmd.defaults[name]}")
                else:
                    lines.append(f"  {name:<16} required")
    else:
        # For cmd with inline placeholders, use existing parse_placeholders
        placeholders = parse_placeholders(template)
        if placeholders:
            lines.append("")
            lines.append("Arguments:")
            for p in placeholders:
                mode = "positional or keyword" if p.positional else "keyword-only"
                if p.default is not None:
                    lines.append(f"  {p.name:<16} {mode}, default: {p.default}")
                else:
                    lines.append(f"  {p.name:<16} {mode}, required")

    return "\n".join(lines)


def _load_commands_impl(lq_dir: Path) -> dict[str, RegisteredCommand]:
    """Internal implementation of load_commands."""
    commands_path = lq_dir / COMMANDS_FILE
    if not commands_path.exists():
        return {}

    data = load_toml(commands_path)

    commands = {}
    for name, config in data.get("commands", {}).items():
        if isinstance(config, str):
            # Simple format: name = "command"
            commands[name] = RegisteredCommand(name=name, cmd=config)
        else:
            # Full format with options
            capture_env = config.get("capture_env", [])
            if not isinstance(capture_env, list):
                capture_env = []

            # Get defaults dict, ensuring it's a dict
            defaults = config.get("defaults", {})
            if not isinstance(defaults, dict):
                defaults = {}

            # Get suppress list, ensuring it's a list
            suppress = config.get("suppress", [])
            if not isinstance(suppress, list):
                suppress = []

            commands[name] = RegisteredCommand(
                name=name,
                cmd=config.get("cmd"),  # None if not present
                tpl=config.get("tpl"),  # Template if present
                defaults=defaults,
                description=config.get("description", ""),
                timeout=config.get("timeout"),  # None = no timeout
                format=config.get("format", "auto"),
                capture=config.get("capture", True),
                capture_env=capture_env,
                suppress=suppress,
                lines=config.get("lines"),  # Default line selection for output
            )
    return commands


def _save_commands_impl(lq_dir: Path, commands: dict[str, RegisteredCommand]) -> None:
    """Internal implementation of save_commands."""
    commands_path = lq_dir / COMMANDS_FILE
    data = {"commands": {name: cmd.to_dict() for name, cmd in commands.items()}}
    save_toml(commands_path, data)


def get_suppressed_fingerprints(
    config: BlqConfig,
    source_name: str | None = None,
) -> list[str]:
    """Get list of fingerprints to suppress for a given source.

    Suppression is per-command. If source_name is provided, returns fingerprints
    from that command's suppress list. If source_name is None or not found,
    returns an empty list.

    Args:
        config: BlqConfig instance with commands loaded
        source_name: The command/source name to get suppress list for

    Returns:
        List of fingerprint strings to suppress
    """
    if source_name is None:
        return []

    # Check if there's a command with this name
    if source_name in config.commands:
        return config.commands[source_name].suppress

    return []


def get_all_suppressed_fingerprints(config: BlqConfig) -> list[str]:
    """Get all suppressed fingerprints from all commands.

    This is useful when querying across all sources.

    Args:
        config: BlqConfig instance with commands loaded

    Returns:
        Combined list of all fingerprint strings to suppress (deduplicated)
    """
    all_fingerprints: set[str] = set()
    for cmd in config.commands.values():
        all_fingerprints.update(cmd.suppress)
    return list(all_fingerprints)


# ============================================================================
# Database Connection
# ============================================================================


def get_lq_dir() -> Path | None:
    """Find .lq directory in current or parent directories.

    Returns None if no .lq directory is found.
    """
    cwd = Path.cwd()
    for p in [cwd, *list(cwd.parents)]:
        lq_path = p / LQ_DIR
        if lq_path.exists():
            return lq_path
    return None


class ConnectionFactory:
    """Factory for creating properly initialized DuckDB connections.

    Handles:
    - duck_hunt extension loading/installation
    - scalarfs extension for data: URL support
    - Schema loading for stored data queries
    - Future: persistent database support
    """

    _duck_hunt_available: bool | None = None
    _scalarfs_available: bool | None = None

    @classmethod
    def check_duck_hunt(cls, conn: duckdb.DuckDBPyConnection) -> bool:
        """Check if duck_hunt is available (cached)."""
        if cls._duck_hunt_available is None:
            try:
                conn.execute("LOAD duck_hunt")
                cls._duck_hunt_available = True
            except duckdb.Error:
                cls._duck_hunt_available = False
        return cls._duck_hunt_available

    @classmethod
    def check_scalarfs(cls, conn: duckdb.DuckDBPyConnection) -> bool:
        """Check if scalarfs is available (cached)."""
        if cls._scalarfs_available is None:
            try:
                conn.execute("LOAD scalarfs")
                cls._scalarfs_available = True
            except duckdb.Error:
                cls._scalarfs_available = False
        return cls._scalarfs_available

    @classmethod
    def install_duck_hunt(cls, conn: duckdb.DuckDBPyConnection) -> bool:
        """Install duck_hunt extension from community repo.

        Returns True if successful, False otherwise.
        """
        try:
            conn.execute("INSTALL duck_hunt FROM community")
            conn.execute("LOAD duck_hunt")
            cls._duck_hunt_available = True
            return True
        except duckdb.Error:
            cls._duck_hunt_available = False
            return False

    @classmethod
    def install_scalarfs(cls, conn: duckdb.DuckDBPyConnection) -> bool:
        """Install scalarfs extension from community repo.

        Returns True if successful, False otherwise.
        """
        try:
            conn.execute("INSTALL scalarfs FROM community")
            conn.execute("LOAD scalarfs")
            cls._scalarfs_available = True
            return True
        except duckdb.Error:
            cls._scalarfs_available = False
            return False

    @classmethod
    def load_extensions(
        cls,
        conn: duckdb.DuckDBPyConnection,
        install_missing: bool = False,
    ) -> dict[str, bool]:
        """Load all blq extensions (duck_hunt, scalarfs).

        Args:
            conn: DuckDB connection
            install_missing: If True, attempt to install missing extensions

        Returns:
            Dict of extension name -> availability
        """
        results = {}

        # duck_hunt
        if cls.check_duck_hunt(conn):
            results["duck_hunt"] = True
        elif install_missing and cls.install_duck_hunt(conn):
            results["duck_hunt"] = True
        else:
            results["duck_hunt"] = False

        # scalarfs
        if cls.check_scalarfs(conn):
            results["scalarfs"] = True
        elif install_missing and cls.install_scalarfs(conn):
            results["scalarfs"] = True
        else:
            results["scalarfs"] = False

        return results

    @classmethod
    def create(
        cls,
        lq_dir: Path | None = None,
        load_schema: bool = True,
        require_duck_hunt: bool = False,
        install_duck_hunt: bool = False,
    ) -> duckdb.DuckDBPyConnection:
        """Create a properly initialized DuckDB connection.

        Args:
            lq_dir: Path to .lq directory (for schema loading)
            load_schema: Whether to load the schema (for stored data queries)
            require_duck_hunt: If True, raise error if duck_hunt unavailable
            install_duck_hunt: If True, attempt to install duck_hunt if missing

        Returns:
            Initialized DuckDB connection

        Raises:
            duckdb.Error: If require_duck_hunt=True and duck_hunt unavailable
        """
        # Use blq.duckdb if it exists (has schema pre-loaded)
        if lq_dir is not None and load_schema:
            db_path = lq_dir / DB_FILE
            if db_path.exists():
                conn = duckdb.connect(str(db_path))
                # Override blq_base_path with actual absolute path
                logs_path = (lq_dir / LOGS_DIR).resolve()
                conn.execute(f"CREATE OR REPLACE MACRO blq_base_path() AS '{logs_path}'")
                # Handle duck_hunt loading
                try:
                    conn.execute("LOAD duck_hunt")
                    cls._duck_hunt_available = True
                except duckdb.Error:
                    if install_duck_hunt:
                        cls.install_duck_hunt(conn)
                    elif require_duck_hunt:
                        raise duckdb.Error(
                            "duck_hunt extension required but not available. "
                            "Run 'blq init' to install required extensions."
                        )
                return conn

        # Fall back to in-memory connection
        conn = duckdb.connect(":memory:")

        # Handle duck_hunt loading
        duck_hunt_loaded = False
        try:
            conn.execute("LOAD duck_hunt")
            duck_hunt_loaded = True
            cls._duck_hunt_available = True
        except duckdb.Error:
            if install_duck_hunt:
                duck_hunt_loaded = cls.install_duck_hunt(conn)

            if require_duck_hunt and not duck_hunt_loaded:
                raise duckdb.Error(
                    "duck_hunt extension required but not available. "
                    "Run 'blq init' to install required extensions."
                )

        # Load schema if requested and lq_dir provided
        if load_schema and lq_dir is not None:
            cls._load_schema(conn, lq_dir)

        return conn

    @classmethod
    def _load_schema(cls, conn: duckdb.DuckDBPyConnection, lq_dir: Path) -> None:
        """Load schema into connection."""
        # Set up absolute path for blq_base_path before loading schema
        logs_path = (lq_dir / LOGS_DIR).resolve()
        conn.execute(f"CREATE OR REPLACE MACRO blq_base_path() AS '{logs_path}'")

        # Load schema (which will use our blq_base_path)
        schema_path = lq_dir / SCHEMA_FILE
        if schema_path.exists():
            schema_sql = schema_path.read_text()
            # Execute each statement separately
            for stmt in schema_sql.split(";"):
                stmt = stmt.strip()
                if not stmt:
                    continue
                # Skip the blq_base_path definition since we already set it with absolute path
                if (
                    "blq_base_path()" in stmt
                    and "CREATE" in stmt.upper()
                    and "MACRO" in stmt.upper()
                ):
                    continue
                # Skip pure comment blocks
                lines = [
                    line
                    for line in stmt.split("\n")
                    if line.strip() and not line.strip().startswith("--")
                ]
                if not lines:
                    continue
                try:
                    conn.execute(stmt)
                except duckdb.Error:
                    # Ignore schema errors (e.g., views on non-existent parquet files)
                    pass


def get_connection(lq_dir: Path | None = None) -> duckdb.DuckDBPyConnection:
    """Get a DuckDB connection with schema loaded.

    This is a convenience wrapper around ConnectionFactory.create() for
    backward compatibility.
    """
    if lq_dir is None:
        lq_dir = BlqConfig.ensure().lq_dir
    return ConnectionFactory.create(lq_dir=lq_dir, load_schema=True)


def get_lq_dir_from_args(args) -> Path | None:
    """Get the .lq directory path from parsed arguments.

    Handles the --lq-dir flag.

    Args:
        args: Parsed arguments with optional 'lq_dir' attribute

    Returns:
        Path to .lq directory if --lq-dir was specified, None otherwise
    """
    lq_dir = getattr(args, "lq_dir", None)
    if lq_dir:
        return Path(lq_dir).expanduser()
    return None


def get_data_root(args) -> tuple[Path | None, bool]:
    """Get the data root path based on --global or --database flags.

    Args:
        args: Parsed arguments with optional 'global_' and 'database' attributes

    Returns:
        Tuple of (path, is_raw_parquet):
        - path: Path to data root, or None for local .lq
        - is_raw_parquet: True if path is a raw parquet directory (no schema.sql)
    """
    # Check for --database flag first (explicit path)
    database = getattr(args, "database", None)
    if database:
        db_path = Path(database).expanduser()
        # Raw parquet directory (no .lq structure)
        return db_path, True

    # Check for --global flag
    use_global = getattr(args, "global_", False)
    if use_global:
        return GLOBAL_PROJECTS_PATH, True

    # Default: local .lq directory
    return None, False


def get_store_for_args(args):
    """Get a BlqStorage appropriate for the given args.

    Handles --global, --database, and --lq-dir flags.

    Args:
        args: Parsed arguments

    Returns:
        BlqStorage instance configured for the appropriate data source
    """
    from blq.storage import BlqStorage

    # Check for --lq-dir flag first (explicit .lq directory)
    lq_dir = getattr(args, "lq_dir", None)
    if lq_dir:
        lq_path = Path(lq_dir).expanduser()
        if not lq_path.exists():
            print(f"Error: .lq directory does not exist: {lq_path}", file=sys.stderr)
            sys.exit(1)
        return BlqStorage.open(lq_path)

    data_root, is_raw = get_data_root(args)

    if is_raw and data_root is not None:
        # Raw parquet directory - deprecated, use LogStore for backward compat
        import warnings

        from blq.query import LogStore

        warnings.warn(
            "Raw parquet mode is deprecated. Use 'blq migrate --to-bird' to convert.",
            DeprecationWarning,
            stacklevel=2,
        )
        return LogStore.from_parquet_root(data_root)
    else:
        # Standard .lq directory - use BlqStorage
        # Check for --lq-dir override
        lq_dir_override = getattr(args, "lq_dir", None)
        if lq_dir_override:
            lq_path = Path(lq_dir_override).expanduser()
            return BlqStorage.open(lq_path)

        config = BlqConfig.ensure()
        return BlqStorage.open(config.lq_dir)


def get_next_run_id(lq_dir: Path) -> int:
    """Get next run ID by checking BIRD storage or parquet files."""
    max_id = 0

    # First check BIRD storage (primary)
    db_path = lq_dir / DB_FILE
    if db_path.exists():
        try:
            import duckdb

            conn = duckdb.connect(str(db_path), read_only=True)
            # Count from invocations (completed runs) - attempts may still be pending
            # Note: With the live output pattern, we write to both attempts AND
            # invocations with the same ID, so counting only invocations is correct.
            result = conn.execute("""
                SELECT COUNT(*) FROM invocations
            """).fetchone()
            if result and result[0]:
                max_id = max(max_id, result[0])
            conn.close()
        except Exception:
            pass  # Fall through to parquet check

    # Also check parquet files (for backward compatibility)
    logs_dir = lq_dir / LOGS_DIR
    if logs_dir.exists():
        for f in logs_dir.rglob("*.parquet"):
            try:
                run_id = int(f.stem.split("_")[0])
                max_id = max(max_id, run_id)
            except (ValueError, IndexError):
                pass

    return max_id + 1 if max_id > 0 else 1


# ============================================================================
# Parquet Writing
# ============================================================================

# Canonical schema columns - always written in this order for consistency
# Format: (column_name, sql_type) - sql_type used for explicit casting
PARQUET_SCHEMA = [
    # Run metadata
    ("run_id", "BIGINT"),
    ("source_name", "VARCHAR"),
    ("source_type", "VARCHAR"),
    ("tag", "VARCHAR"),  # Logical command name (how user refers to it)
    ("command", "VARCHAR"),
    ("started_at", "VARCHAR"),
    ("completed_at", "VARCHAR"),
    ("exit_code", "BIGINT"),
    # Execution context
    ("cwd", "VARCHAR"),
    ("executable_path", "VARCHAR"),
    ("environment", "MAP(VARCHAR, VARCHAR)"),
    # System context
    ("hostname", "VARCHAR"),
    ("platform", "VARCHAR"),
    ("arch", "VARCHAR"),
    # Git context
    ("git_commit", "VARCHAR"),
    ("git_branch", "VARCHAR"),
    ("git_dirty", "BOOLEAN"),
    # CI context
    ("ci", "MAP(VARCHAR, VARCHAR)"),
    # Session (for watch mode)
    ("session_id", "VARCHAR"),
    # Event identification
    ("event_id", "BIGINT"),
    ("severity", "VARCHAR"),
    # Location (BIRD spec names)
    ("ref_file", "VARCHAR"),
    ("ref_line", "BIGINT"),
    ("ref_column", "BIGINT"),
    # Content
    ("message", "VARCHAR"),
    ("raw_text", "VARCHAR"),
    # Classification
    ("tool_name", "VARCHAR"),
    ("category", "VARCHAR"),
    ("error_code", "VARCHAR"),
    ("fingerprint", "VARCHAR"),
    # Log position
    ("log_line_start", "BIGINT"),
    ("log_line_end", "BIGINT"),
]

# Just the column names for iteration
PARQUET_SCHEMA_COLUMNS = [col for col, _ in PARQUET_SCHEMA]


def write_run_parquet(
    events: list[dict[str, Any]],
    run_meta: dict[str, Any],
    lq_dir: Path,
) -> Path:
    """Write events to a Hive-partitioned parquet file.

    Always writes all schema columns for consistency, even if values are None.
    """
    # Determine partition path
    date_str = datetime.now().strftime("%Y-%m-%d")
    time_str = datetime.now().strftime("%H%M%S")
    source_type = run_meta.get("source_type", "run")
    run_id = run_meta["run_id"]
    name = run_meta.get("source_name", "unknown")
    # Sanitize name for filename
    safe_name = "".join(c if c.isalnum() or c in "-_" else "_" for c in name)[:50]

    partition_dir = lq_dir / LOGS_DIR / f"date={date_str}" / f"source={source_type}"
    partition_dir.mkdir(parents=True, exist_ok=True)

    filename = f"{run_id:03d}_{safe_name}_{time_str}.parquet"
    filepath = partition_dir / filename

    def sql_escape(val: Any, sql_type: str) -> str:
        """Escape a value for SQL VALUES clause with proper type casting."""
        is_map = sql_type.startswith("MAP")

        if val is None:
            # NULL with explicit type for MAPs to ensure consistent schema
            return f"NULL::{sql_type}" if is_map else "NULL"
        if isinstance(val, bool):
            return "TRUE" if val else "FALSE"
        if isinstance(val, (int, float)):
            return str(val)
        if isinstance(val, str):
            # Escape single quotes by doubling them
            return "'" + val.replace("'", "''") + "'"
        if isinstance(val, dict):
            # Convert dict to MAP(keys, values) syntax
            if not val:
                return f"MAP([], [])::{sql_type}"
            keys = ", ".join(sql_escape(str(k), "VARCHAR") for k in val.keys())
            vals = ", ".join(sql_escape(str(v), "VARCHAR") for v in val.values())
            return f"MAP([{keys}], [{vals}])"
        if isinstance(val, list):
            # Lists should have been converted to dicts for MAP columns
            return f"MAP([], [])::{sql_type}" if is_map else "NULL"
        return sql_escape(str(val), "VARCHAR")

    # Build schema lookup for type info
    schema_types = {col: sql_type for col, sql_type in PARQUET_SCHEMA}

    # Build VALUES rows
    value_rows = []
    for event in events or [{}]:
        # Merge run metadata and event data
        merged = {**run_meta, **event}
        # Build row with all columns in schema order
        vals = []
        for col in PARQUET_SCHEMA_COLUMNS:
            val = merged.get(col)
            sql_type = schema_types[col]
            vals.append(sql_escape(val, sql_type))
        value_rows.append("(" + ", ".join(vals) + ")")

    # Build full SQL query with VALUES and projections
    values_clause = ", ".join(value_rows)
    col_names = ", ".join(PARQUET_SCHEMA_COLUMNS)

    # Build projections with explicit casts for type consistency
    projections = []
    for col, sql_type in PARQUET_SCHEMA:
        projections.append(f"{col}::{sql_type} AS {col}")
    proj_clause = ", ".join(projections)

    conn = duckdb.connect(":memory:")
    conn.execute(f"""
        COPY (
            SELECT {proj_clause}
            FROM (VALUES {values_clause}) AS t({col_names})
        ) TO '{filepath}'
        (FORMAT PARQUET, COMPRESSION 'zstd', COMPRESSION_LEVEL 3)
    """)
    conn.close()

    return filepath


# ============================================================================
# Log Parsing
# ============================================================================


def _parse_single_format(
    conn: duckdb.DuckDBPyConnection, content: str, fmt: str
) -> list[dict[str, Any]] | None:
    """Try parsing content with a single format.

    Returns list of events on success, None on failure.
    """
    try:
        result = conn.execute(
            "SELECT * FROM parse_duck_hunt_log($1, $2)", [content, fmt]
        ).fetchall()
        columns = [desc[0] for desc in conn.description]
        return [dict(zip(columns, row)) for row in result]
    except duckdb.Error:
        return None


def parse_log_content(content: str, format_hint: str = "auto") -> list[dict[str, Any]]:
    """Parse log content using duck_hunt extension.

    All log parsing is delegated to duck_hunt. If duck_hunt is not available
    or fails to parse, returns an empty list. Parsing improvements should be
    made upstream in duck_hunt, not in lq.

    Supports comma-separated format hints (e.g. "gcc_text,make_error") — tries
    each format in order, returning events from the first that succeeds. Falls
    back to "auto" if all explicit formats fail.

    Args:
        content: Raw log content to parse
        format_hint: Format hint for duck_hunt (default: "auto").
            Can be comma-separated to try multiple formats.

    Returns:
        List of parsed events with BIRD spec column names:
        - ref_file, ref_line, ref_column (location)
        - severity, message, error_code (content)
        - tool_name, category, fingerprint (metadata)
    """
    import logging

    logger = logging.getLogger("blq-cli")

    conn = duckdb.connect(":memory:")
    try:
        conn.execute("LOAD duck_hunt")
    except duckdb.Error:
        conn.close()
        return []

    try:
        # Handle comma-separated format hints
        formats = [f.strip() for f in format_hint.split(",") if f.strip()]
        if not formats:
            formats = ["auto"]

        if len(formats) == 1:
            # Single format — try it, fall back to "auto" on failure
            fmt = formats[0]
            events = _parse_single_format(conn, content, fmt)
            if events is not None:
                return events
            if fmt != "auto":
                logger.warning("Format '%s' failed to parse, falling back to 'auto'", fmt)
                events = _parse_single_format(conn, content, "auto")
                return events if events is not None else []
            return []

        # Multiple formats — try each in order
        for fmt in formats:
            events = _parse_single_format(conn, content, fmt)
            if events is not None:
                return events

        # All explicit formats failed — fall back to "auto"
        logger.warning(
            "All formats [%s] failed to parse, falling back to 'auto'",
            ", ".join(formats),
        )
        events = _parse_single_format(conn, content, "auto")
        return events if events is not None else []
    finally:
        conn.close()


# ============================================================================
# Execution Context Capture
# ============================================================================


def capture_environment(env_vars: list[str]) -> dict[str, str]:
    """Capture specified environment variables.

    Args:
        env_vars: List of environment variable names to capture

    Returns:
        Dict of captured env vars (only those that exist)
    """
    captured = {}
    for var in env_vars:
        value = os.environ.get(var)
        if value is not None:
            captured[var] = value
    return captured


def find_executable(command: str) -> str | None:
    """Find the full path to the executable for a command.

    Args:
        command: Command string (may include arguments)

    Returns:
        Full path to executable, or None if not found
    """
    # Extract the first word (the executable name)
    parts = command.split()
    if not parts:
        return None

    exe_name = parts[0]

    # If it's already an absolute path, return it
    if os.path.isabs(exe_name) and os.path.exists(exe_name):
        return exe_name

    # Use shutil.which to find in PATH
    return shutil.which(exe_name)


# CI provider detection: env var to check -> (provider name, env vars to capture)
CI_PROVIDERS = {
    "GITHUB_ACTIONS": (
        "github",
        [
            "GITHUB_RUN_ID",
            "GITHUB_RUN_NUMBER",
            "GITHUB_WORKFLOW",
            "GITHUB_JOB",
            "GITHUB_REF",
            "GITHUB_SHA",
            "GITHUB_REPOSITORY",
            "GITHUB_ACTOR",
            "GITHUB_EVENT_NAME",
            "GITHUB_PR_NUMBER",
        ],
    ),
    "GITLAB_CI": (
        "gitlab",
        [
            "CI_JOB_ID",
            "CI_PIPELINE_ID",
            "CI_COMMIT_SHA",
            "CI_COMMIT_REF_NAME",
            "CI_PROJECT_PATH",
            "CI_MERGE_REQUEST_IID",
            "GITLAB_USER_LOGIN",
        ],
    ),
    "JENKINS_URL": (
        "jenkins",
        [
            "BUILD_NUMBER",
            "BUILD_ID",
            "JOB_NAME",
            "BUILD_URL",
            "GIT_COMMIT",
            "GIT_BRANCH",
            "CHANGE_ID",
        ],
    ),
    "CIRCLECI": (
        "circleci",
        [
            "CIRCLE_BUILD_NUM",
            "CIRCLE_WORKFLOW_ID",
            "CIRCLE_JOB",
            "CIRCLE_SHA1",
            "CIRCLE_BRANCH",
            "CIRCLE_PR_NUMBER",
            "CIRCLE_PROJECT_REPONAME",
        ],
    ),
    "TRAVIS": (
        "travis",
        [
            "TRAVIS_BUILD_ID",
            "TRAVIS_BUILD_NUMBER",
            "TRAVIS_JOB_ID",
            "TRAVIS_COMMIT",
            "TRAVIS_BRANCH",
            "TRAVIS_PULL_REQUEST",
            "TRAVIS_REPO_SLUG",
        ],
    ),
    "BUILDKITE": (
        "buildkite",
        [
            "BUILDKITE_BUILD_ID",
            "BUILDKITE_BUILD_NUMBER",
            "BUILDKITE_JOB_ID",
            "BUILDKITE_COMMIT",
            "BUILDKITE_BRANCH",
            "BUILDKITE_PULL_REQUEST",
            "BUILDKITE_PIPELINE_SLUG",
        ],
    ),
    "AZURE_PIPELINES": (
        "azure",
        [
            "BUILD_BUILDID",
            "BUILD_BUILDNUMBER",
            "BUILD_SOURCEVERSION",
            "BUILD_SOURCEBRANCH",
            "SYSTEM_PULLREQUEST_PULLREQUESTID",
            "BUILD_REPOSITORY_NAME",
        ],
    ),
}


def capture_ci_info() -> dict[str, str] | None:
    """Detect CI provider and capture relevant environment variables.

    Returns:
        Dict with 'provider' key and provider-specific env vars, or None if not in CI.
    """
    for detect_var, (provider_name, env_vars) in CI_PROVIDERS.items():
        if os.environ.get(detect_var):
            ci_info = {"provider": provider_name}
            for var in env_vars:
                value = os.environ.get(var)
                if value is not None:
                    # Use short key names (strip common prefixes)
                    short_key = var
                    for prefix in ["GITHUB_", "CI_", "CIRCLE_", "TRAVIS_", "BUILDKITE_", "BUILD_"]:
                        if short_key.startswith(prefix):
                            short_key = short_key[len(prefix) :]
                            break
                    ci_info[short_key.lower()] = value
            return ci_info

    # Check generic CI env var
    if os.environ.get("CI"):
        return {"provider": "unknown", "ci": "true"}

    return None
