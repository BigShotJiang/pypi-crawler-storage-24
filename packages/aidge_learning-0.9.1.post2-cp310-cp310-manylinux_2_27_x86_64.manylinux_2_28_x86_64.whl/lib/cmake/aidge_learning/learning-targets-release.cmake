#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Aidge::learning" for configuration "Release"
set_property(TARGET Aidge::learning APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Aidge::learning PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/lib_aidge_learning.a"
  )

list(APPEND _cmake_import_check_targets Aidge::learning )
list(APPEND _cmake_import_check_files_for_Aidge::learning "${_IMPORT_PREFIX}/lib/lib_aidge_learning.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
