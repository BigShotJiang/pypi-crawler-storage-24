"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

import matplotlib.pyplot as plt
import numpy as np


def log_lr_profile(lr_prof, max_steps, steps_per_epoch, filename):
    fig, ax = plt.subplots()
    plt.plot(lr_prof, label="Learning rate profile")
    ax.set_xlabel("Steps")
    ax.set_ylabel("Learning rate")

    max_epochs = max_steps // steps_per_epoch
    epoch_stride = max(1, max_epochs // 10)

    epoch_numbers = np.arange(0, max_epochs + 1, epoch_stride)

    # Define transform functions
    def steps_to_epochs(x):
        return x / steps_per_epoch

    def epochs_to_steps(x):
        return x * steps_per_epoch

    # Create secondary axis on top
    secax = ax.secondary_xaxis("top", functions=(steps_to_epochs, epochs_to_steps))

    # Set ticks in epoch units
    secax.set_xticks(epoch_numbers)
    secax.set_xlabel("Epochs", color="blue")

    # Make epoch axis blue
    secax.tick_params(axis="x", colors="blue")
    secax.spines["bottom"].set_color("blue")
    plt.savefig(filename)
