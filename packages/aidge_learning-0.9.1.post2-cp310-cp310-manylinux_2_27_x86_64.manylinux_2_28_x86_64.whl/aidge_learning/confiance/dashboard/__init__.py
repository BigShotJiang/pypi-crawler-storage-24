"""
Dashboard generation system for training run visualization.

This package provides a modular system for generating interactive HTML
dashboards from training run data (metrics.csv, config.txt, training_plot.png).
"""

from .generator import DashboardGenerator

__all__ = ["DashboardGenerator"]
__version__ = "0.1.0"
