"""
Generate summary metric cards for dashboard.
"""

import pandas as pd
from typing import Dict
from ..utils.formatters import format_percent, format_number, format_time


def generate_summary_cards(metrics_df: pd.DataFrame, config: Dict[str, str]) -> str:
    """
    Generate HTML for summary metric cards.

    :param metrics_df: DataFrame with training metrics
    :param config: Configuration dictionary

    :return HTML string with metric cards
    """
    # Get final epoch metrics
    final_epoch = metrics_df.iloc[-1]

    # Calculate totals
    total_epochs = len(metrics_df)
    warmup_epochs = len(metrics_df[metrics_df["phase"] == "Warmup"])
    robust_epochs = total_epochs - warmup_epochs
    total_time = (
        metrics_df["time_epoch"].sum() if "time_epoch" in metrics_df.columns else 0
    )

    # Extract key metrics
    final_clean_acc = final_epoch["acc"]
    final_ver_acc = final_epoch["ver_acc"] if "ver_acc" in final_epoch else -1
    final_loss = (
        final_epoch["loss"]
        if "loss" in final_epoch
        else final_epoch.get("clean_loss", 0)
    )
    final_epsilon = final_epoch["epsilon"]
    avg_width = final_epoch.get("avg_bound_width", 0)

    # Calculate verification gap
    ver_gap = final_clean_acc - final_ver_acc if final_ver_acc >= 0 else 0

    cards_html = f"""
    <div class="metrics-cards">
        <div class="metric-card card-primary">
            <div class="card-icon">🎯</div>
            <div class="card-content">
                <div class="card-label">Clean Accuracy</div>
                <div class="card-value">{format_percent(final_clean_acc, 1)}</div>
                <div class="card-subtitle">Final epoch accuracy</div>
            </div>
        </div>

        <div class="metric-card card-success">
            <div class="card-icon">✓</div>
            <div class="card-content">
                <div class="card-label">Verified Accuracy</div>
                <div class="card-value">{format_percent(final_ver_acc, 1) if final_ver_acc >= 0 else 'N/A'}</div>
                <div class="card-subtitle">Provably robust (gap: {format_percent(ver_gap, 1)})</div>
            </div>
        </div>

        <div class="metric-card card-warning">
            <div class="card-icon">📉</div>
            <div class="card-content">
                <div class="card-label">Final Loss</div>
                <div class="card-value">{format_number(final_loss, 3)}</div>
                <div class="card-subtitle">Mixed CE loss</div>
            </div>
        </div>

        <div class="metric-card card-info">
            <div class="card-icon">⏱</div>
            <div class="card-content">
                <div class="card-label">Training Time</div>
                <div class="card-value">{format_time(total_time)}</div>
                <div class="card-subtitle">{total_epochs} epochs ({warmup_epochs}W + {robust_epochs}R)</div>
            </div>
        </div>

        <div class="metric-card card-epsilon">
            <div class="card-icon">ε</div>
            <div class="card-content">
                <div class="card-label">Final Epsilon</div>
                <div class="card-value">{format_number(final_epsilon, 4)}</div>
                <div class="card-subtitle">Target ε = {config.get('target_eps', 'N/A')}</div>
            </div>
        </div>

        <div class="metric-card card-bounds">
            <div class="card-icon">📊</div>
            <div class="card-content">
                <div class="card-label">Avg Bound Width</div>
                <div class="card-value">{format_number(avg_width, 6)}</div>
                <div class="card-subtitle">Interval tightness</div>
            </div>
        </div>
    </div>
    """

    return cards_html
