"""
Generate interactive Plotly training plots.
"""

import pandas as pd
from typing import Dict

try:
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots

    PLOTLY_AVAILABLE = True
except ImportError:
    PLOTLY_AVAILABLE = False


def generate_training_plot(metrics_df: pd.DataFrame, config: Dict[str, str]) -> str:
    """
    Generate interactive Plotly training plot.

    :param metrics_df: DataFrame with training metrics
    :param config: Configuration dictionary

    :return HTML string with embedded Plotly chart
    """
    if not PLOTLY_AVAILABLE:
        return """
        <div class="plot-error">
            <p>⚠️ Plotly not available. Install with: <code>pip install plotly</code></p>
        </div>
        """

    # Create figure with secondary y-axis
    fig = make_subplots(specs=[[{"secondary_y": True}]])

    # Determine phase transition
    warmup_df = metrics_df[metrics_df["phase"] == "Warmup"]
    robust_df = metrics_df[metrics_df["phase"] == "Robust"]
    warmup_end = warmup_df["epoch"].max() if len(warmup_df) > 0 else 0

    # ========================================================================
    # Loss traces (left y-axis)
    # ========================================================================
    fig.add_trace(
        go.Scatter(
            x=metrics_df["epoch"],
            y=metrics_df["loss"],
            mode="lines+markers",
            name="Loss",
            line=dict(color="#e74c3c", width=2.5),
            marker=dict(size=6),
            hovertemplate="<b>Epoch %{x}</b><br>Loss: %{y:.4f}<extra></extra>",
        ),
        secondary_y=False,
    )

    if "clean_loss" in metrics_df.columns:
        fig.add_trace(
            go.Scatter(
                x=metrics_df["epoch"],
                y=metrics_df["clean_loss"],
                mode="lines",
                name="Clean CE Loss",
                line=dict(color="#3498db", width=2, dash="dot"),
                hovertemplate="<b>Epoch %{x}</b><br>Clean Loss: %{y:.4f}<extra></extra>",
            ),
            secondary_y=False,
        )

    if "rob_loss" in metrics_df.columns:
        fig.add_trace(
            go.Scatter(
                x=metrics_df["epoch"],
                y=metrics_df["rob_loss"],
                mode="lines",
                name="Robust CE Loss",
                line=dict(color="#e67e22", width=2, dash="dash"),
                hovertemplate="<b>Epoch %{x}</b><br>Robust Loss: %{y:.4f}<extra></extra>",
            ),
            secondary_y=False,
        )

    # ========================================================================
    # Accuracy traces (right y-axis)
    # ========================================================================
    fig.add_trace(
        go.Scatter(
            x=metrics_df["epoch"],
            y=metrics_df["acc"],
            mode="lines+markers",
            name="Clean Accuracy",
            line=dict(color="#2ecc71", width=2.5),
            marker=dict(size=6, symbol="diamond"),
            hovertemplate="<b>Epoch %{x}</b><br>Clean Acc: %{y:.2f}%<extra></extra>",
        ),
        secondary_y=True,
    )

    if "ver_acc" in metrics_df.columns:
        ver_acc_valid = metrics_df[metrics_df["ver_acc"] >= 0]
        if len(ver_acc_valid) > 0:
            fig.add_trace(
                go.Scatter(
                    x=ver_acc_valid["epoch"],
                    y=ver_acc_valid["ver_acc"],
                    mode="lines+markers",
                    name="Verified Accuracy",
                    line=dict(color="#9b59b6", width=2.5),
                    marker=dict(size=6, symbol="square"),
                    hovertemplate="<b>Epoch %{x}</b><br>Verified Acc: %{y:.2f}%<extra></extra>",
                ),
                secondary_y=True,
            )

    # ========================================================================
    # Epsilon schedule (normalized to right y-axis scale)
    # ========================================================================
    if "epsilon" in metrics_df.columns:
        eps_max = metrics_df["epsilon"].max()
        if eps_max > 0:
            # Normalize epsilon to 0-100 scale to match accuracy
            eps_normalized = (metrics_df["epsilon"] / eps_max) * 100
            fig.add_trace(
                go.Scatter(
                    x=metrics_df["epoch"],
                    y=eps_normalized,
                    mode="lines",
                    name=f"Epsilon (×{eps_max:.4f}/100)",
                    line=dict(color="#f39c12", width=2, dash="dashdot"),
                    fill="tozeroy",
                    fillcolor="rgba(243, 156, 18, 0.1)",
                    hovertemplate="<b>Epoch %{x}</b><br>ε: %{customdata:.6f}<extra></extra>",
                    customdata=metrics_df["epsilon"],
                ),
                secondary_y=True,
            )

    # ========================================================================
    # Phase separator
    # ========================================================================
    if warmup_end > 0:
        fig.add_vline(
            x=warmup_end + 0.5,
            line_dash="solid",
            line_color="rgba(255, 0, 0, 0.5)",
            line_width=2,
            annotation_text="Warmup → Robust",
            annotation_position="top",
            annotation=dict(font_size=11, font_color="red", bgcolor="white"),
        )

        # Shaded regions
        fig.add_vrect(
            x0=metrics_df["epoch"].min() - 0.5,
            x1=warmup_end + 0.5,
            fillcolor="rgba(52, 152, 219, 0.08)",
            layer="below",
            line_width=0,
        )
        fig.add_vrect(
            x0=warmup_end + 0.5,
            x1=metrics_df["epoch"].max() + 0.5,
            fillcolor="rgba(231, 76, 60, 0.08)",
            layer="below",
            line_width=0,
        )

    # ========================================================================
    # Layout configuration
    # ========================================================================
    dataset = config.get("dataset", "DATASET").upper()
    title_text = f"<b>Interval-Based Robust Training - {dataset}</b>"

    fig.update_layout(
        title=dict(text=title_text, x=0.5, xanchor="center", font=dict(size=18)),
        xaxis=dict(
            title="<b>Epoch</b>",
            gridcolor="rgba(200, 200, 200, 0.3)",
            showline=True,
            linecolor="black",
        ),
        yaxis=dict(
            title="<b>Loss</b>",
            gridcolor="rgba(200, 200, 200, 0.3)",
            showline=True,
            linecolor="black",
        ),
        yaxis2=dict(
            title="<b>Accuracy (%) / Normalized Metrics</b>",
            showline=True,
            linecolor="black",
        ),
        hovermode="x unified",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=-0.25,
            xanchor="center",
            x=0.5,
            bgcolor="rgba(255, 255, 255, 0.8)",
            bordercolor="rgba(0, 0, 0, 0.2)",
            borderwidth=1,
        ),
        plot_bgcolor="white",
        paper_bgcolor="white",
        height=600,
        margin=dict(t=80, b=120),
    )

    # Convert to HTML div
    plot_html = fig.to_html(
        include_plotlyjs="cdn",
        div_id="training-plot",
        config={
            "displayModeBar": True,
            "displaylogo": False,
            "modeBarButtonsToRemove": ["lasso2d", "select2d"],
            "toImageButtonOptions": {
                "format": "png",
                "filename": "training_plot",
                "height": 600,
                "width": 1200,
                "scale": 2,
            },
        },
    )

    return plot_html
