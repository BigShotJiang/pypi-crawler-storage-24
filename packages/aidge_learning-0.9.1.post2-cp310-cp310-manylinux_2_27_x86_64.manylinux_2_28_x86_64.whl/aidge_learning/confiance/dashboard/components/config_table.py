"""
Generate configuration display table.
"""

from typing import Dict


def generate_config_table(config: Dict[str, str]) -> str:
    """
    Generate HTML table for configuration display.

    :param config: Configuration dictionary

    :return HTML string with configuration table
    """
    # Group configurations by category
    categories = {
        "Training": ["method", "warm_up", "nb_epochs", "batch_size", "eval_freq"],
        "Robustness": ["target_eps", "epsilon", "epsilon_schedule"],
        "Model": ["model", "input_shape"],
        "Data": ["dataset"],
    }

    config_html = '<div class="config-section">\n'
    config_html += '<h3 class="section-title">⚙️ Configuration</h3>\n'
    config_html += '<div class="config-grid">\n'

    for category, keys in categories.items():
        # Filter keys that exist in config
        available_keys = [k for k in keys if k in config]

        if not available_keys:
            continue

        config_html += f'<div class="config-category">\n'
        config_html += f'<h4 class="category-title">{category}</h4>\n'
        config_html += '<table class="config-table">\n'

        for key in available_keys:
            value = config[key]
            display_key = key.replace("_", " ").title()
            config_html += f'<tr><td class="config-key">{display_key}</td><td class="config-value">{value}</td></tr>\n'

        config_html += "</table>\n"
        config_html += "</div>\n"

    # Add "Other" category for remaining keys
    handled_keys = sum(categories.values(), [])
    other_keys = [k for k in config.keys() if k not in handled_keys]

    if other_keys:
        config_html += '<div class="config-category">\n'
        config_html += '<h4 class="category-title">Other</h4>\n'
        config_html += '<table class="config-table">\n'

        for key in sorted(other_keys):
            value = config[key]
            display_key = key.replace("_", " ").title()
            config_html += f'<tr><td class="config-key">{display_key}</td><td class="config-value">{value}</td></tr>\n'

        config_html += "</table>\n"
        config_html += "</div>\n"

    config_html += "</div>\n"  # Close config-grid
    config_html += "</div>\n"  # Close config-section

    return config_html
