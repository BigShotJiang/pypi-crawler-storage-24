"""
Generate epoch-by-epoch details table.
"""

import pandas as pd
from ..utils.formatters import format_number, format_percent, format_time


def generate_epoch_table(metrics_df: pd.DataFrame) -> str:
    """
    Generate HTML table with epoch-by-epoch details.

    :param metrics_df: DataFrame with training metrics

    :return HTML string with epoch details table
    """
    html = '<div class="epoch-table-section">\n'
    html += '<h3 class="section-title">📈 Epoch-by-Epoch Details</h3>\n'
    html += '<div class="table-container">\n'
    html += '<table class="epoch-table" id="epoch-table">\n'
    html += "<thead>\n"
    html += "<tr>\n"
    html += '<th onclick="sortTable(0)">Epoch ↕</th>\n'
    html += '<th onclick="sortTable(1)">Phase ↕</th>\n'
    html += '<th onclick="sortTable(2)">Epsilon ↕</th>\n'
    html += '<th onclick="sortTable(3)">Clean Acc (%) ↕</th>\n'
    html += '<th onclick="sortTable(4)">Ver Acc (%) ↕</th>\n'
    html += '<th onclick="sortTable(5)">Mixed Loss ↕</th>\n'
    html += '<th onclick="sortTable(6)">Avg Width ↕</th>\n'
    html += '<th onclick="sortTable(7)">Time (s) ↕</th>\n'
    html += "</tr>\n"
    html += "</thead>\n"
    html += "<tbody>\n"

    for _, row in metrics_df.iterrows():
        epoch = int(row["epoch"])
        phase = row["phase"]
        epsilon = row["epsilon"]
        clean_acc = row["acc"]
        ver_acc = row.get("ver_acc", -1)
        mixed_loss = row.get("loss", row.get("clean_loss", 0))
        avg_width = row.get("avg_bound_width", 0)
        time_epoch = row.get("time_epoch", 0)

        # Phase class for styling
        phase_class = "phase-warmup" if phase == "Warmup" else "phase-robust"

        html += f'<tr class="{phase_class}">\n'
        html += f"<td>{epoch}</td>\n"
        html += f'<td><span class="phase-badge phase-badge-{phase.lower()}">{phase}</span></td>\n'
        html += f"<td>{format_number(epsilon, 6)}</td>\n"
        html += f"<td>{format_percent(clean_acc, 2)}</td>\n"
        html += f'<td>{format_percent(ver_acc, 2) if ver_acc >= 0 else "N/A"}</td>\n'
        html += f"<td>{format_number(mixed_loss, 4)}</td>\n"
        html += f"<td>{format_number(avg_width, 6)}</td>\n"
        html += f"<td>{format_number(time_epoch, 2)}</td>\n"
        html += "</tr>\n"

    html += "</tbody>\n"
    html += "</table>\n"
    html += "</div>\n"
    html += "</div>\n"

    return html
