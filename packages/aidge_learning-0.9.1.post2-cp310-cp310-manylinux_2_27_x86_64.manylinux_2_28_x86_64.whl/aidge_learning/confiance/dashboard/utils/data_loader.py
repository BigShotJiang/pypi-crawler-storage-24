"""
Data loading utilities for training run data.

Loads metrics.csv and config.txt from training run directories.
"""

from pathlib import Path
from typing import Dict

import pandas as pd


def load_metrics(run_dir: Path) -> pd.DataFrame:
    """
    Load metrics CSV from a training run directory.

    :param run_dir: Path to the training run directory

    :return DataFrame with training metrics
    """
    metrics_path = run_dir / "metrics.csv"

    if not metrics_path.exists():
        raise FileNotFoundError(f"Metrics file not found: {metrics_path}")

    try:
        df = pd.read_csv(metrics_path)
    except Exception as e:
        raise ValueError(f"Failed to parse metrics CSV: {e}")

    # Validate required columns
    required_cols = ["epoch", "phase", "epsilon", "clean_loss", "acc"]
    missing_cols = [col for col in required_cols if col not in df.columns]

    if missing_cols:
        raise ValueError(f"Missing required columns: {missing_cols}")

    return df


def load_config(run_dir: Path) -> Dict[str, str]:
    """
    Load configuration from config.txt.

    :param run_dir: Path to the training run directory

    :return Dictionary with configuration key-value pairs
    """
    config_path = run_dir / "config.txt"

    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    config = {}

    with open(config_path, "r") as f:
        for line in f:
            line = line.strip()
            if line and ":" in line:
                key, value = line.split(":", 1)
                config[key.strip()] = value.strip()

    return config
