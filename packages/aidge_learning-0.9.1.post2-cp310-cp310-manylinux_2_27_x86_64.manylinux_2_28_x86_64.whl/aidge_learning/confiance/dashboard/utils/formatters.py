"""
Formatting utilities for displaying metrics and values.
"""

from typing import Union


def format_number(value: Union[int, float], decimals: int = 2) -> str:
    """
    Format a number with appropriate precision.

    :param value: Number to format
    :param decimals: Number of decimal places

    :return Formatted string
    """
    if isinstance(value, int):
        return f"{value:,}"

    if abs(value) >= 1000:
        return f"{value:,.{decimals}f}"
    elif abs(value) >= 1:
        return f"{value:.{decimals}f}"
    else:
        # Use more decimals for small values
        return f"{value:.{decimals + 2}f}"


def format_percent(value: float, decimals: int = 1) -> str:
    """
    Format a percentage value.

    :param value: Percentage value (0-100)
    :param decimals: Number of decimal places

    :return Formatted percentage string
    """
    return f"{value:.{decimals}f}%"


def format_time(seconds: float) -> str:
    """
    Format time duration in seconds to human-readable format.

    :param seconds: Time in seconds

    :return Formatted time string (e.g., "1h 23m 45s", "45.2s")
    """
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        minutes = int(seconds // 60)
        secs = seconds % 60
        return f"{minutes}m {secs:.0f}s"
    else:
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = seconds % 60
        return f"{hours}h {minutes}m {secs:.0f}s"


def format_epsilon(value: float) -> str:
    """
    Format epsilon value with Greek letter.

    :param value: Epsilon value

    :return Formatted epsilon string
    """
    return f"ε = {value:.4f}"


def format_delta(current: float, previous: float, is_percentage: bool = False) -> str:
    """
    Format a delta between two values with color indicator.

    :param current: Current value
    :param previous: Previous value
    :param is_percentage: Whether values are percentages

    :return Formatted delta string with sign
    """
    delta = current - previous
    sign = "+" if delta >= 0 else ""

    if is_percentage:
        return f"{sign}{delta:.1f}%"
    else:
        return f"{sign}{delta:.3f}"
