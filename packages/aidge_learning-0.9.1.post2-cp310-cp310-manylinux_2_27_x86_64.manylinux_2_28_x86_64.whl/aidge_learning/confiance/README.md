# Robust training

We provide a set of tools to enable robust training through Interval Bound Propagation (IBP) in Aidge.
Robust training or certified robust training is a method to train a network to try and include formal
guarantees of robustness directly in the training.

Unlike adversarial training, which trains using a sampling of adversarial examples around each point,
robust training relies on intervals to train on the entire area around an input point. This area is modulated
by an intensity parameter $\epsilon$.

Doing this kind of training will make the trained model more robust (to attacks and perturbations) but also
enable an easier formal verification of the model afterward.
Nevertheless, it can lead to a longer training time and slight decrease in accuracy. To mitigate this, specific
training techniques are needed which we detail and implement herE.

Our implementation of Interval Bound Propagation (IBP) robust training based on Gowal et al., "Scalable Verified
Training for Provably Robust Image Classification" and Shi et al., "Fast Certified Robust Training with Short Warm up".

## Requirements
### System Requirements
- **Python 3.10+**

### Aidge Framework Dependencies

**Required** (must be installed separately):
- `aidge-core` - Core computational graph operations
- `aidge-backend-cpu` - CPU execution backend
- `aidge-learning` - Training, optimizers, and loss functions

### Python Package Dependencies

**Core dependencies** (installed via `requirements.txt`):
- `numpy` ≥ 2.0.0 - Numerical operations
- `pandas` ≥ 2.0.0 - Metrics tracking
- `plotly` ≥ 5.0.0 - Interactive HTML dashboards
- `torchvision` ≥ 0.15.0 - MNIST/CIFAR-10 datasets
- `tqdm` ≥ 4.65.0 - Progress bars

See [`requirements.txt`](requirements.txt) for complete dependency list with version constraints.

## Quick Start

### Key concept

We aim to train a network to be **locally robust** around each point of its training dataset.

![robustesse-locale.png](img/robustesse-locale.png)

For any perturbation under a range $\epsilon$, the output of the network should be the same. This means
same classification for a classifier, and can be extended for regression to a small distance between both output
values.
The value of $\epsilon$ is usually link with the dataset and the intensity of the perturbation we allow on it.

The goal of the training is thus to learn that the $\epsilon$-neighbourhood has the same output. For this, we use
intervals arithmetic: instead of using number to train the network we use interval and do all operations of the
network on the interval.

![intervals.png](img/intervals.png)

We can then compute a loss on the output intervals.

### Training techniques

To properly do this kind of training certain techniques are needed and implemented here:
- **Warm up**: First the model must provide correct results with $\epsilon=0$, so we start either from a pretrained
  model or we do a small warm up period to increase the model accuracy
- **Ramp up**: Gradually increase the value of $\epsilon$ used during training from 0 to its max value using a
  scheduler (linear, sinusoïdal, ...)
- **Mixed loss**: As a constant model is always robust, we want to balance the robustness of our model with its
  accuracy, as such we use a mix of a clean loss and robust loss during training
- **IBP initialization**: For training stability we use a specific weight initialization for IBP (σ = √(2π)/fan_in)

## Basic Usage

The `train_interval` function is the main interface for robust training. It trains an Aidge GraphView on the data
provided by a DataProvider. Here we build the dataprovider with a torchvision dataset.


```Python
import torchvision
from torchvision import transforms
from aidge_learning.confiance.training_interval import train_interval_model
from aidge_learning.confiance.training.dataset import AidgeDataset
from aidge_learning.confiance.training.utils import get_model

# Load model
input_shape = [1, 1, 28, 28]
model = get_model("small_fnn", input_shape)

# Load training dataset
transform = transforms.Compose([transforms.ToTensor()])
trainset = torchvision.datasets.MNIST(root="./data", train=True, download=True, transform=transform)
aidge_dataset = AidgeDataset(data=trainset, input_shape=input_shape) # wrapper for the dataset

# Create data provider with batching
batch_size = 256
aidge_dataprovider = aidge_core.DataProvider(aidge_dataset, batch_size=batch_size, shuffle=False, drop_last=True)

# Run training
train_interval_model(aidge_dataprovider, model, input_shape, method="robust", eps=0.01)
```


### Arguments

| Argument           | Type                    | Default   | Description                                                       |
| ------------------ | ----------------------- | --------- | ----------------------------------------------------------------- |
| `dataset`          | aidge_core.DataProvider |           | Dataset to use                                                    |
| `model`            | aidge_core.GraphView    |           | Model                                                             |
| `input_shape`      | tuple                   |           | Input shape                                                       |
| `method`           | str                     | `logits`  | Robust loss method: `logits`, `width`, or `robust`                |
| `init_method`      | str                     | `xavier`  | Weight initialization: `xavier` (standard) or `ibp` (IBP-optimal) |
| `warm_up`          | int                     | `8`       | Number of warm up epochs (ε=0)                                    |
| `nb_epochs`        | int                     | `10`      | Number of robust training epochs (total = warm_up + nb_epochs)    |
| `eps`              | float                   | `0.01`    | Target perturbation radius (L∞)                                   |
| `batch_size`       | int                     | `256`     | Training batch size                                               |
| `epsilon_schedule` | str                     | `linear`  | Epsilon scheduling: `linear`, `sinusoidal`, or `constant`         |
| `log_metrics`      | bool                    | `True`    | Whether to log the metrics to a csv file                          |
| `dataset_name`     | str                     | `unknown` | Optional dataset name for the logging                             |
| `output_dir`       | str                     | `output`  | Path to the directory to save results                             |
| `eval_freq`        | int                     | `5`       | Metric evaluation frequency                                       |

### Method Options

1. **`logits` (Recommended)**:
   - Creates worst-case logits: lower bounds for correct class, upper bounds for wrong classes
   - Loss: `L = CE(pred, label) + CE(robust_pred, label)`
   - Better performance, faster convergence
   - Use for: Classification tasks

2. **`robust` (Native C++ RobustCELoss)**:
   - Uses native `RobustCELoss` function from `aidge_learning`
   - Computes worst-case cross-entropy directly on interval bounds using interval arithmetic
   - Loss: `L = CE(pred, label) + RobustCE(lower, upper, label)`
   - Mathematically equivalent to `logits` method (produces identical loss values)
   - No graph modification needed (simpler architecture)
   - Use for: Research, comparing implementations, or when native C++ performance is preferred

3. **`width` (Alternative)**:
   - Minimizes interval width (upper - lower bounds)
   - Loss: `L = CE(pred, label) + MSE(width, 0)`
   - Tighter bounds, but slower convergence
   - Use for: Research or when analyzing bound tightness

### Weight Initialization Methods

The `init` parameter controls the weight initialization strategy:

- **`xavier`**: Standard Xavier/Glorot initialization
  - σ² = 2/(fan_in + fan_out) - Stabilizes activation variance
  - Good general-purpose initialization
  - Standard in non-robust training

- **`ibp` (Default)**: IBP-optimal initialization (Shi et al., NeurIPS 2021, Section 3.3.1)
  - σ = √(2π) / fan_in - Stabilizes interval bound width
  - Designed specifically for IBP certified robust training
  - Prevents bound explosion during training
  - Recommended for better training convergence

### Epsilon Scheduling

The `epsilon_schedule` parameter controls how the perturbation radius increases:

- **`linear` (Default)**: ε increases linearly from 0 to target over nb_epochs

- **`sinusoidal`**: ε follows sin²(πt/2T) curve
  - Gentler initial increases, accelerates in middle

- **`constant`**: ε jumps immediately to target (vanilla IBP)
  - No gradual ramp, full perturbation from epoch 0
  - Used as baseline for comparing against warm up-based training

## Usage Examples

### Standard MNIST Training

Full training for MNIST with good robustness:
  - Warmup = 2
  - Epochs = 10
  - Epsilon = 0.01
  - Method = "logits"

**Expected Results:**
- Test accuracy: ~98%
- Certified robust accuracy (ε=0.01): ~94%

---

### Higher Robustness

Stronger robustness with larger epsilon:
  - Warmup = 12
  - Epochs = 27
  - Epsilon = 0.1
  - Method = "logits"

**Expected Results:**
- Test accuracy: ~93%
- Certified robust accuracy (ε=0.1): ~65%
- Trade-off: Higher ε → stronger robustness but lower accuracy

---

### CIFAR-10 Training

Training on more complex dataset:
  - Warmup = 10
  - Epochs = 30
  - Epsilon = 0.008
  - Method = "logits"

**Expected Results:**
- CIFAR-10 is harder than MNIST
- Test accuracy: ~60-70%
- Certified robust accuracy (ε=0.008): ~40-50%

---

## Output Files

Training generates several files in the output directory like : `output/interval_logits_20251104_223047/`

### Directory Contents

### 1. `metrics.csv`

CSV file with comprehensive per-epoch training metrics:

```csv
epoch,phase,epsilon,clean_loss,rob_loss,loss,acc,ver_acc,avg_bound_width,ver_margin_avg,ver_margin_worst,time_epoch
1,Warmup,0.000000,0.602230,0.602230,0.602230,81.1331,81.1331,0.000000,0.000000,-20.973040,86.68
2,Warmup,0.000000,0.213040,0.213040,0.213040,93.5764,93.5764,0.000000,0.000000,-15.217312,88.94
3,Robust,0.001000,0.140518,0.275636,0.416153,95.7515,91.9388,1.225712,0.000000,-14.921673,89.38
4,Robust,0.002000,0.105368,0.234876,0.340244,96.8967,93.2726,1.515173,0.000000,-12.624607,89.73
5,Robust,0.003000,0.086121,0.214546,0.300667,97.5194,93.9453,1.767829,0.000000,-12.568377,93.02
```

**Columns:**
- `epoch`: Epoch number (1-indexed)
- `phase`: Training phase (`Warm up` or `Robust`)
- `epsilon`: Current perturbation radius
- `clean_loss`: Clean cross-entropy loss component
- `rob_loss`: Robust loss component (CE_rob for logits, MSE_width for width method)
- `loss`: Total mixed loss (ce_clean + ce_rob weighted by κ)
- `acc`: Training accuracy on clean predictions (%)
- `ver_acc`: Verified robust accuracy (% of samples with certified predictions, logits method only)
- `avg_bound_width`: Average interval width across all outputs (bound tightness)
- `ver_margin_avg`: Mean verification margin (lower[true] - max(upper[wrong]))
- `ver_margin_worst`: Minimum verification margin across batch
- `time_epoch`: Epoch duration (seconds)

### 2. `dashboard.html`

Comprehensive visualization showing all metrics in an html dashboard.

### 3. `config.txt`

Training configuration for reproducibility:

```
method: logits
warm_up: 8
nb_epochs: 10
target_eps: 0.01
lambda_reg: 1.0
epsilon_schedule: linear
batch_size: 256
input_shape: [1, 1, 28, 28]
eval_freq: 5
```

### Model Architectures

Available architectures in `get_model()`:

1. **`small_fnn`**: 3 FC layers (100 neurons each)
   - Best for: Quick testing
   - MNIST: ~98% accuracy

2. **`big_fnn`**: 3 FC layers (512→256→128)
   - Best for: Higher accuracy
   - MNIST: ~99% accuracy

3. **`small_cnn`**: 3 conv blocks + FC
   - Best for: CIFAR-10
   - More parameters, slower training

## Project Structure

This project follows a domain-organized structure:

- `training/`: Reusable library code (interval networks, models, utilities)
- `dashboard/`: Dashboard generation code
- `training_interval.py`: Script to train a model with robust training
