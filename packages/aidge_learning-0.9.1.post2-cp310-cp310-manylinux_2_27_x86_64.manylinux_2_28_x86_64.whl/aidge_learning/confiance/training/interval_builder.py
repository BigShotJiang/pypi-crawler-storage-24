from typing import List

import aidge_core
import numpy as np
from aidge_core import GraphView, Node


def remove(view: GraphView, nodes: List[Node]):
    """Remove a list of nodes from a GraphView."""
    for node in nodes:
        view.replace({node}, set([]))


def add_all(view: GraphView, nodes: List[Node]):
    """Add a list of nodes to a GraphView."""
    for node in nodes:
        view.add(node)


def name_nodes(model: GraphView):
    """Name unnamed nodes in the GraphView."""
    counter = 0
    for node in model.get_nodes():
        if node.name() == "":
            node.set_name(f"unnamed_node_{counter}")
            counter += 1

    return model


def clone_network(model: GraphView):
    """Create a new GraphView from a GraphView containing two additional clones of the GraphView.

    Producers are shared between the three clones."""

    # First be sure there is no unnamed nodes in the GraphView
    model = name_nodes(model)

    model_lower = model.clone()
    model_upper = model.clone()

    # Producers are shared but not the other nodes
    for node in model.get_nodes():
        if node.type() == "Producer":
            model_lower.replace({model_lower.get_node(node.name())}, {node})
            model_upper.replace({model_upper.get_node(node.name())}, {node})
        else:
            model_lower.get_node(node.name()).set_name(node.name() + "_lower")
            model_upper.get_node(node.name()).set_name(node.name() + "_upper")

    add_all(model, [model_lower, model_upper])

    return model


def create_input_interval(model: GraphView):
    """
    Create new inputs of the Interval GraphView with an input and an epsilon.

    :param model: GraphView on which to add the inputs.
    """

    # First we create a graphview for the input interval creation
    input = aidge_core.Identity(f"Input")
    eps_input = aidge_core.Identity(f"Epsilon")

    add = aidge_core.Add("add_epsilon")
    sub = aidge_core.Sub("sub_epsilon")

    input_view: GraphView = GraphView()

    input.add_child(sub)
    eps_input.add_child(sub)

    input.add_child(add)
    eps_input.add_child(add)

    add_all(input_view, [add, sub, eps_input, input])

    # Then we link it to the model
    input_nodes = model.get_input_nodes()
    meta_op_input = input_view
    meta_op_input.add_child([n for n in input_nodes if "_lower" in n.name()][0], sub)
    meta_op_input.add_child([n for n in input_nodes if "_upper" in n.name()][0], add)

    input.add_child(
        [
            n
            for n in input_nodes
            if "_upper" not in n.name() and "_lower" not in n.name()
        ][0]
    )

    model.add(meta_op_input)
    return model


def relu_neg(layer_name: str):
    """
    Create a Neg -> ReLU -> Neg GraphView. Used to keep only the negative part of an input.

    :param layer_name: Layer associated with construct to have a unique identifier.
    """
    meta_graph = GraphView()
    neg = aidge_core.Neg(name=f"neg_{layer_name}")

    new_relu_neg = aidge_core.ReLU(f"weight_neg-{layer_name}")

    output_name = f"neg2_{layer_name}"
    weight_neg = aidge_core.Neg(name=output_name)

    neg.add_child(new_relu_neg)
    new_relu_neg.add_child(weight_neg)
    add_all(meta_graph, [neg, new_relu_neg, weight_neg])

    return meta_graph, output_name


def node_to_interval(node: Node):
    """
    Create an interval node for a given node with two input producers (Weight and Bias).

    Duplicate the node to apply interval arithmetic. Negative and positive weights are separated to compute upper
    and lower bounds.
    Weight separation is done with ReLU and ReLU_neg in order to keep the relation between them.

    :param node: Node to transform.
    """
    layer_name = node.name()

    meta_graph = GraphView()
    w_init = aidge_core.Identity(f"Weight-{layer_name}")
    bias = aidge_core.Identity(f"Bias-{layer_name}")
    X_lower = aidge_core.Identity(f"X_lower-{layer_name}")
    X_upper = aidge_core.Identity(f"X_upper-{layer_name}")

    weight_pos = aidge_core.ReLU(f"weight_pos-{layer_name}")
    weight_neg, output_name = relu_neg(layer_name)

    w_init.add_child(weight_neg)
    w_init.add_child(weight_pos)

    node_1 = node.clone()
    node_1.set_name(f"{layer_name}_1")
    node_2 = node.clone()  # TODO set no bias if possible
    node_2.set_name(f"{layer_name}_2")
    node_3 = node.clone()
    node_3.set_name(f"{layer_name}_3")
    node_4 = node.clone()  # TODO set no bias if possible
    node_4.set_name(f"{layer_name}_4")

    # bias is only added once for lower and once for upper. In the other case we set it to zero by multiplying zero
    # to the bias.
    zeros = aidge_core.Producer(
        aidge_core.Tensor(np.array(0.0, dtype=np.float32)),
        f"zero-{layer_name}",
        constant=True,
    )
    zero_bias = aidge_core.Mul(name=f"mul_zero_{layer_name}")
    zeros.add_child(zero_bias)
    bias.add_child(zero_bias)

    X_lower.add_child(node_1)
    weight_pos.add_child(node_1, 0, 1)
    bias.add_child(node_1, 0, 2)

    X_lower.add_child(node_2)
    weight_neg.add_child(node_2, weight_neg.get_node(output_name), 0, 1)
    zero_bias.add_child(node_2, 0, 2)

    X_upper.add_child(node_3)
    weight_pos.add_child(node_3, 0, 1)
    bias.add_child(node_3, 0, 2)

    X_upper.add_child(node_4)
    weight_neg.add_child(node_4, weight_neg.get_node(output_name), 0, 1)
    zero_bias.add_child(node_4, 0, 2)

    add_lower = aidge_core.Add(f"out_lower-{layer_name}")
    add_upper = aidge_core.Add(f"out_upper-{layer_name}")

    node_1.add_child(add_lower)
    node_4.add_child(add_lower)

    node_2.add_child(add_upper)
    node_3.add_child(add_upper)

    add_all(
        meta_graph,
        [weight_neg, weight_pos, add_lower, add_upper, zeros, w_init, bias, zero_bias],
    )
    add_all(meta_graph, [X_lower, X_upper, node_1, node_2, node_3, node_4])

    return meta_graph


def replace_one_box_op(model: GraphView, node: Node):
    """
    On a GraphView, replace the node by the interval node.

    :param model: Considered GraphView.
    :param node: Node to replace
    """
    w_init: Node = node.input(1)[0]
    bias = node.input(2)[0]

    # Fetch corresponding upper and lower nodes
    node_lower = model.get_node(f"{node.name()}_lower")
    node_upper = model.get_node(f"{node.name()}_upper")
    X_lower, out_lower = node_lower.input(0)
    X_upper, out_upper = node_upper.input(0)
    layer_name = node.name()

    # Get interval node
    box_op = node_to_interval(node)

    # Replace it in the GraphView
    X_lower.add_child(box_op, out_lower, (box_op.get_node(f"X_lower-{layer_name}"), 0))
    X_upper.add_child(box_op, out_upper, (box_op.get_node(f"X_upper-{layer_name}"), 0))
    w_init.add_child(box_op, 0, (box_op.get_node(f"Weight-{layer_name}"), 0))
    bias.add_child(box_op, 0, (box_op.get_node(f"Bias-{layer_name}"), 0))

    for output in node_lower.outputs()[0]:
        box_op.get_node(f"out_lower-{layer_name}").add_child(output[0], 0, output[1])

    for output in node_upper.outputs()[0]:
        box_op.get_node(f"out_upper-{layer_name}").add_child(output[0], 0, output[1])

    add_all(model, [box_op])
    remove(model, [node_lower, node_upper])
    box_op.get_node(f"out_upper-{layer_name}").set_name(f"{layer_name}_upper")
    box_op.get_node(f"out_lower-{layer_name}").set_name(f"{layer_name}_lower")
    return model


def get_interval_network(graph_view: GraphView, method: str = "robust") -> GraphView:
    """
    Return an GraphView with additional interval propagation.

    Only Conv2D and FC are correctly handled. Any other layer involving a multiplication is not handled.
    Layers with no multiplication (or anything that works directly on interval) is ok.

    :param graph_view: Considered GraphView.
    :param method: Three methods for training:
                    - "width" using just interval width
                    - "logits" using logits constructed with upper and lower bounds
                    - "robust" using logits but with interval propagated all through the CELoss
    """
    model = graph_view.clone()

    model = clone_network(model)
    model = create_input_interval(model)

    all_matches = aidge_core.SinglePassGraphMatching(model).match("(FC|Conv2D)")

    for match in list(all_matches):
        node = match.graph.root_node()
        if "lower" not in node.name() and "upper" not in node.name():
            model = replace_one_box_op(model, node)

    # Add method-specific layers to compute robust loss
    if method == "width":
        # "Width" method: Add layers to compute interval width (upper - lower)
        model = add_width_comp(model)
    elif method == "logits":
        # "Logits" method: Add layers to create adversarial logit combinations
        model = add_logits(model)
    elif method != "robust":
        raise ValueError(
            f"Unknown method '{method}'. Must be 'width', 'logits', or 'robust'"
        )

    return model


def get_outputs(model: GraphView, interval_model: GraphView):
    """From a GraphView and its corresponding interval GraphView return the normal output, lower and upper bounds."""
    out_name = model.get_ordered_nodes()[-1].name()

    pred = interval_model.get_node(out_name).get_operator().get_output(0)
    lower = interval_model.get_node(f"{out_name}_lower").get_operator().get_output(0)
    upper = interval_model.get_node(f"{out_name}_upper").get_operator().get_output(0)

    return pred, lower, upper


def extract_model(original_model: GraphView, interval_model: GraphView):
    """Return a normal model from an interval model."""
    new_model = interval_model.clone()
    original_names = [n.name() for n in original_model.get_nodes()]

    for node in new_model.get_nodes():
        if not node.name() in original_names:
            remove(new_model, [node])

    return new_model


def add_width_comp(interval_model: GraphView):
    """Add width computation at the end of the GraphView (upper - lower)."""
    low, up = None, None
    for n, _ in list(interval_model.get_ordered_outputs()):
        if "lower" in n.name():
            low = n
        elif "upper" in n.name():
            up = n

    if low is None or up is None:
        raise ValueError(
            "Model does not seem to have lower and upper bounds. Is it a correct interval model?"
        )

    sub_node = aidge_core.Sub("width")
    up.add_child(sub_node)
    low.add_child(sub_node)

    interval_model.add(sub_node)

    return interval_model


def add_logits(interval_model: GraphView):
    """Add logits computation based on the current label to a GraphView.

    Lower bound is return for the true label and upper bound for the rest of the outputs.
    """
    low, up = None, None
    for node, _ in list(interval_model.get_ordered_outputs()):
        if "lower" in node.name():
            low = node
        elif "upper" in node.name():
            up = node

    if low is None or up is None:
        raise ValueError(
            "Model does not seem to have lower and upper bounds. Is it a correct interval model?"
        )

    label_input = aidge_core.Identity(f"Label")

    one = aidge_core.Producer(
        aidge_core.Tensor(np.array(1.0, dtype=np.float32)), f"one", constant=True
    )
    inv_label = aidge_core.Sub("sub")
    one.add_child(inv_label)
    label_input.add_child(inv_label)

    mul = aidge_core.Mul("mul1")
    low.add_child(mul)
    label_input.add_child(mul)

    mul2 = aidge_core.Mul("mul2")
    up.add_child(mul2)
    inv_label.add_child(mul2)

    add = aidge_core.Add("logits")
    mul.add_child(add)
    mul2.add_child(add)

    add_all(interval_model, [label_input, inv_label, one, mul, mul2, add])
    return interval_model
