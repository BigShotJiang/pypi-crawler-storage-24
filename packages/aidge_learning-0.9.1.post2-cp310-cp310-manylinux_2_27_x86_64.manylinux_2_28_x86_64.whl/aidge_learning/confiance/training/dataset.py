from typing import List, Tuple

import aidge_core

from .utils import one_hot_encoding


class AidgeDataset(aidge_core.Database):
    """
    Aidge-compatible dataset wrapper.
    """

    def __init__(self, data, input_shape: List, nb_cls: int = 10):
        """Initialize the dataset wrapper."""
        aidge_core.Database.__init__(self)
        self.data = data
        self.nb_cls = nb_cls
        self.shape = input_shape

    def get_item(self, idx: int) -> List[Tuple[aidge_core.Tensor, aidge_core.Tensor]]:
        """
        Get a single data sample with one-hot encoded label.

        This method is called by Aidge's DataProvider to fetch samples.

        :param idx: Index of the sample to retrieve
        :return [data_tensor, label_tensor] where:
                - data_tensor: Image tensor (C x H x W)
                - label_tensor: One-hot encoded label vector (10 classes)
        """
        data, label = self.data.__getitem__(idx)
        return [aidge_core.Tensor(data.numpy()), one_hot_encoding(label, self.nb_cls)]

    def len(self) -> int:
        """Get the total number of samples in the dataset."""
        return len(self.data)
