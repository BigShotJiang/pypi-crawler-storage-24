from __future__ import annotations
from typing import List, TYPE_CHECKING

import aidge_core
import numpy as np
from aidge_core import GraphView
from tqdm import tqdm

if TYPE_CHECKING:
    from .dataset import AidgeDataset
from .interval_builder import get_interval_network


def one_hot_encoding(cls: int, nb_cls: int) -> aidge_core.Tensor:
    """
    Convert a class index to a one-hot encoded vector.

    :param cls: Class index (0-based)
    :param nb_cls: Total number of classes

    :return  One-hot encoded tensor of shape (nb_cls,) with 1.0 at position cls and 0.0 elsewhere
    """
    values = np.array([float(0.0)] * nb_cls)
    values[cls] = float(1.0)
    t = aidge_core.Tensor(values)
    t.set_datatype(aidge_core.dtype.float32)
    return t


def evaluate(dataset: AidgeDataset, model: aidge_core.GraphView):
    """
    Evaluate the accuracy of a model on a dataset.

    :param dataset: Aidge DataProvider containing test data
    :param model: The neural network model to evaluate
    """
    model.compile("cpu", aidge_core.dtype.float32, dims=[dataset.shape])
    scheduler = aidge_core.SequentialScheduler(model)

    tot_acc = 0
    tot_samples = 0
    pbar = tqdm(enumerate(dataset), total=len(dataset), desc="Evaluate")

    for i, (data, label) in pbar:
        # Forward pass: compute predictions
        scheduler.forward(data=[data])

        # Extract predictions from output layer
        out_node = model.get_ordered_nodes()[-1]
        pred = out_node.get_operator().get_output(0)

        # Compute batch accuracy
        acc = np.sum(np.argmax(pred, axis=1) == np.argmax(label, axis=1))
        tot_acc += acc
        tot_samples += label.dims[0]

    # Print final accuracy
    avg_acc = tot_acc / tot_samples
    print(f"Tot_acc: {avg_acc * 100}%")
    return avg_acc


def evaluate_rob(
    dataset: aidge_core.DataProvider,
    model: aidge_core.GraphView,
    epsilon: float,
    input_shape: List[int],
):
    """
    Evaluate certified robustness of a model using Interval Bound Propagation (IBP).

    This function computes three metrics:
    1. Standard accuracy: Accuracy on clean (unperturbed) inputs
    2. Certified robust accuracy: Percentage of inputs where the model is provably
       robust against all L∞ perturbations within epsilon
    3. Average interval width: Tightness of the interval bounds

    The certified robust accuracy is computed by checking if the lower bound of the
    correct class logit is greater than the upper bound of all other class logits.
    This provides a mathematical guarantee of robustness.

    :param dataset: Aidge DataProvider containing test data
    :param model: The neural network model to evaluate
    :param input_shape: Input tensor shape, e.g., [1, 1, 28, 28]
    :param epsilon: L∞ perturbation radius for robustness evaluation
    """
    # Convert standard model to interval network for bound propagation
    interval_model = get_interval_network(model, method="robust")
    out_name = model.get_ordered_nodes()[-1].name()

    # Compile with two inputs: [clean_input, epsilon_tensor]
    interval_model.compile(
        "cpu", aidge_core.dtype.float32, dims=[input_shape, input_shape]
    )
    scheduler = aidge_core.SequentialScheduler(interval_model)

    # Metrics
    tot_acc = 0  # Standard accuracy
    tot_width = 0  # Average interval width
    rob_acc = 0  # Certified robust accuracy
    tot_samples = 0  # Total samples processed

    pbar = tqdm(enumerate(dataset), total=len(dataset), desc="Evaluate")

    for i, (data, label) in pbar:
        # Create epsilon tensor: uniform perturbation bound for all input dimensions
        eps_tensor = aidge_core.Tensor(
            np.full(np.array(data).shape, epsilon, dtype=np.float32)
        )

        # Forward pass with interval propagation
        scheduler.forward(data=[data, eps_tensor])

        # Extract outputs: lower bounds, upper bounds, and standard predictions
        low, up, pred = None, None, None
        for out in list(interval_model.get_ordered_outputs()):
            if out_name + "_lower" in out[0].name():
                low = out[0].get_operator().get_output(0)
            elif out_name + "_upper" in out[0].name():
                up = out[0].get_operator().get_output(0)
            elif out_name == out[0].name():
                pred = out[0].get_operator().get_output(0)

        assert low and up and pred, "Output not found"

        # Compute average interval width (tightness metric)
        average_width = up - low

        # Convert to numpy for robustness checking
        low, up = np.array(low), np.array(up)

        # Check certified robustness for each sample in the batch
        for j in range(up.shape[0]):
            # Create mask for all classes except the true class
            mask = np.ones(up.shape[1], bool)
            mask[np.argmax(label, axis=1)[j]] = False

            # Certified robust if: lower_bound[true_class] >= max(upper_bound[wrong_classes])
            # This ensures the prediction is provably correct for all perturbations
            rob_acc += (low[j, np.argmax(label, axis=1)[j]] >= up[j][mask]).all()

        # Compute standard accuracy on clean predictions
        tot_acc += np.sum(np.argmax(pred, axis=1) == np.argmax(label, axis=1))
        tot_samples += label.dims[0]
        tot_width += np.mean(np.array(average_width))

    # Print evaluation results
    print(
        f"Tot_acc: {(tot_acc / tot_samples) * 100:.2f}%, "
        f"Tot_width: {tot_width / (i + 1):.2f}, "
        f"Rob_acc: {rob_acc / tot_samples * 100:.2f}%"
    )
    return tot_acc / tot_samples, tot_width / (i + 1), rob_acc / tot_samples


def init_model_weights(model: aidge_core.GraphView, ibp_init: bool = True):
    """
    Initialize model weights and of the GraphView.

    This function initializes different layer types with appropriate strategies:
        - FC/Conv2D layers: Xavier uniform or IBP initialization for weights, small constant for biases
        - BatchNorm2D layers: Standard initialization (scale=1, shift=0, mean=0, std=1)

    Comparison with standard initializations:
        - Xavier: σ² = 2/(fan_in + fan_out)
        - IBP:    σ² = 2π/fan_in²

    :param model: The neural network model to initialize
    :param ibp_init: Whether to use classical Xavier initialization or IBP initialization following
            Shi et al. "Fast Certified Robust Training with Short Warmup". For robust training IBP initialization is
            recommended.

    """
    for node in model.get_ordered_nodes():
        op = node.get_operator()

        # Initialize fully-connected and convolutional layers
        if node.type() in ("FC", "Conv2D", "PaddedConv2D"):
            if ibp_init:
                # IBP initialization
                # Scaling parameter might be used for large networks with residual connections as discussed in
                # appendix A.3 of Shi et al. "Fast Certified Robust Training with Short Warmup"
                # not implemented at the moment
                aidge_core.ibp_normal_filler(op.get_input(1), scaling=1.0)
            else:
                # Xavier uniform
                aidge_core.xavier_uniform_filler(
                    op.get_input(1)
                )  # Weight initialization
            aidge_core.constant_filler(op.get_input(2), 0.01)  # Bias initialization

        # Initialize batch normalization layers
        if node.type() == "BatchNorm2D":
            aidge_core.constant_filler(op.get_input(1), 1)  # Scale parameter (gamma)
            aidge_core.constant_filler(op.get_input(2), 0)  # Shift parameter (beta)
            aidge_core.constant_filler(op.get_input(3), 0)  # Running mean
            aidge_core.constant_filler(op.get_input(4), 1)  # Running std


def get_model(model_type: str, input_shape: List[int]) -> GraphView:
    """
    Create a neural network model architecture.

    This function provides several predefined architectures for MNIST and CIFAR-10 classification tasks.

    :param model_type: Type of model architecture:
        - "small_fnn": Small fully-connected network (3 hidden layers, 100 neurons each)
        - "big_fnn": Large fully-connected network (3 hidden layers, 512→256→128 neurons)
        - "big_fnn_bn": big_fnn with LayerNorm after each FC layer
        - "small_cnn": Small convolutional network (3 conv blocks + FC layer)
    :param input_shape: Input tensor shape [batch, channels, height, width]
    """
    if model_type == "small_fnn":
        # Small fully-connected network: ~110K parameters for MNIST
        graph_view = aidge_core.sequential(
            [
                aidge_core.FC(
                    in_channels=np.prod(input_shape), out_channels=100, name="0"
                ),
                aidge_core.ReLU(name="1"),
                aidge_core.FC(in_channels=100, out_channels=100, name="2"),
                aidge_core.ReLU(name="3"),
                aidge_core.FC(in_channels=100, out_channels=100, name="4"),
                aidge_core.ReLU(name="5"),
                aidge_core.FC(in_channels=100, out_channels=10, name="6"),
            ]
        )

    elif model_type == "big_fnn":
        # Large fully-connected network: ~600K parameters for MNIST
        graph_view = aidge_core.sequential(
            [
                aidge_core.FC(
                    in_channels=np.prod(input_shape), out_channels=512, name="0"
                ),
                aidge_core.ReLU(name="1"),
                aidge_core.FC(in_channels=512, out_channels=256, name="2"),
                aidge_core.ReLU(name="3"),
                aidge_core.FC(in_channels=256, out_channels=128, name="4"),
                aidge_core.ReLU(name="5"),
                aidge_core.FC(in_channels=128, out_channels=10, name="6"),
            ]
        )

    elif model_type == "big_fnn_bn":
        # BN ablation study: big_fnn with LayerNorm after each FC layer
        # Architecture: FC → LayerNorm → ReLU (repeated for each hidden layer)
        #
        # NOTE: Uses LayerNorm instead of strict BatchNorm for simplicity:
        # - LayerNorm normalizes per-sample across features (axis=-1)
        # - BatchNorm would normalize across batch dimension for each feature
        # - For fully-connected layers, both provide similar regularization benefits
        # - Paper (Zhang et al. 2021) specifically mentions BatchNorm for mitigating
        #   ReLU activation imbalance and improving bound stability
        #
        # FUTURE WORK: Consider implementing proper BatchNorm1D for exact paper conformity
        # - Would require normalizing across batch dimension with running statistics
        # - LayerNorm is used here as a practical approximation available in Aidge
        graph_view = aidge_core.sequential(
            [
                aidge_core.FC(
                    in_channels=np.prod(input_shape), out_channels=512, name="fc1"
                ),
                aidge_core.LayerNorm(nb_features=512, axis=-1, name="ln1"),
                aidge_core.ReLU(name="relu1"),
                aidge_core.FC(in_channels=512, out_channels=256, name="fc2"),
                aidge_core.LayerNorm(nb_features=256, axis=-1, name="ln2"),
                aidge_core.ReLU(name="relu2"),
                aidge_core.FC(in_channels=256, out_channels=128, name="fc3"),
                aidge_core.LayerNorm(nb_features=128, axis=-1, name="ln3"),
                aidge_core.ReLU(name="relu3"),
                aidge_core.FC(in_channels=128, out_channels=10, name="fc_out"),
            ]
        )

    elif model_type == "small_cnn":
        # Small convolutional network for CIFAR-10
        # Architecture: 3 conv blocks with increasing feature maps (16→32→64)
        # Each block: Conv → Conv → ReLU → MaxPool
        # Final FC layer maps flattened features to 10 classes
        graph_view = aidge_core.sequential(
            [
                # Block 1: 16 filters
                aidge_core.Conv2D(in_channels=3, out_channels=16, kernel_dims=[3, 3]),
                aidge_core.Conv2D(in_channels=16, out_channels=16, kernel_dims=[3, 3]),
                aidge_core.ReLU(),
                aidge_core.MaxPooling2D(kernel_dims=[2, 2], stride_dims=[2, 2]),
                # Block 2: 32 filters
                aidge_core.Conv2D(in_channels=16, out_channels=32, kernel_dims=[3, 3]),
                aidge_core.Conv2D(in_channels=32, out_channels=32, kernel_dims=[3, 3]),
                aidge_core.ReLU(),
                aidge_core.MaxPooling2D(kernel_dims=[2, 2]),
                # Block 3: 64 filters
                aidge_core.Conv2D(in_channels=32, out_channels=64, kernel_dims=[3, 3]),
                aidge_core.Conv2D(in_channels=64, out_channels=64, kernel_dims=[3, 3]),
                aidge_core.ReLU(),
                aidge_core.MaxPooling2D(kernel_dims=[2, 2]),
                # Classification head
                aidge_core.FC(in_channels=1024, out_channels=10, name="FC_0"),
                # Note: Softmax is commented out as it's not needed for training with CE loss
                # aidge_core.Softmax(axis=1, name="Softmax_0"),
            ]
        )

    else:
        raise ValueError(f"Unknown model type {model_type}")

    graph_view.set_name(model_type)
    return graph_view
