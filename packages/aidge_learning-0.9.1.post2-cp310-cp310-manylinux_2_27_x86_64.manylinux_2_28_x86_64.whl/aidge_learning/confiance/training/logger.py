import warnings
from datetime import datetime
from pathlib import Path

import time


class Logger:
    """Logging class used to log the configuration, various metrics during training and create the html dashboard."""

    def __init__(self, output_dir, config, log_metrics):
        self.log = log_metrics
        self.config = config
        if log_metrics:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            run_dir = Path(output_dir) / f"interval_{config['method']}_{timestamp}"
            self.run_dir = run_dir
            run_dir.mkdir(parents=True, exist_ok=True)

            # Save configuration
            config_path = run_dir / "config.txt"
            with open(config_path, "w") as f:
                for key in config:
                    if key == "dataset":
                        f.write(f"batch_size: {config[key].batch_size()}\n")
                    elif key == "dataset_name":
                        # TODO get dataset name from DataProvider
                        f.write(f"dataset: {config[key]}\n")
                    elif key == "model":
                        f.write(f"{key}: {config[key].name()}\n")
                    else:
                        f.write(f"{key}: {config[key]}\n")

            # Create metrics CSV
            self.metrics_file = run_dir / "metrics.csv"
            with open(self.metrics_file, "w") as f:
                f.write(
                    "epoch,phase,epsilon,clean_loss,rob_loss,loss,acc,ver_acc,avg_bound_width,time_epoch\n"
                )

        else:
            pass

        self.logged_metrics = [
            "accuracy",
            "loss",
            "clean_loss",
            "rob_loss",
            "ver_acc",
            "width",
            "nb_samples",
        ]
        self.metrics = {}
        self.nan_detected = False

    def init_epoch_metrics(self, epoch_idx, current_eps):
        """Initializes the various metrics at the epoch's start."""
        self.epoch_start = time.perf_counter()
        self.epoch = epoch_idx
        self.phase = "Warmup" if epoch_idx < self.config["warm_up"] else "Robust"
        self.current_eps = current_eps
        self.metrics = {k: 0.0 for k in self.logged_metrics}

    def update_metrics(self, metrics):
        """Updates metrics values in logger."""
        for key in metrics:
            if key in self.metrics:
                self.metrics[key] += metrics[key]

        if metrics["nan_detected"]:
            warnings.warn("NaN or Inf detected, might be overflow in IBP training.")
            self.nan_detected = True

    def get_pbar_dict(self, cur_batch_idx):
        """Updates progress bar with metrics."""
        nb_samples = self.metrics["nb_samples"]
        return {
            key: (
                f"{self.metrics[key] / nb_samples:.4f}"
                if "acc" in key
                else f"{self.metrics[key] / (cur_batch_idx + 1):.2f}"
            )
            for key in self.metrics
            if key != "nb_samples"
        }

    def summarize_epoch(self):
        """Computes and prints the different metrics at the end of the epochs."""

        total_batch = len(self.config["dataset"])
        tot_samples = self.metrics["nb_samples"]

        epoch_time = time.perf_counter() - self.epoch_start
        epoch_loss = self.metrics["loss"] / total_batch
        epoch_clean_loss = self.metrics["clean_loss"] / total_batch
        epoch_rob_loss = self.metrics["rob_loss"] / total_batch
        epoch_width = self.metrics["width"] / total_batch
        epoch_acc = (self.metrics["accuracy"] / tot_samples) * 100
        epoch_ver_acc = (self.metrics["ver_acc"] / tot_samples) * 100

        # Detailed epoch summary (every eval_freq epochs or last epoch)
        total_epoch = self.config["nb_epochs"] + self.config["warm_up"]
        if (self.epoch + 1) % self.config["eval_freq"] == 0 or (
            self.epoch == total_epoch - 1
        ):
            print(f"\n{'='*80}")
            print(f"Epoch {self.epoch+1}/{total_epoch} Summary:")
            print(f"  Phase: {self.phase}")
            print(f"  Training Mode: 'INTERVAL'")
            print(f"  Epsilon: {self.current_eps:.6f}")
            print(f"  Mixed CE Loss: {epoch_loss:.4f}")
            print(f"  Clean Accuracy: {epoch_acc:.2f}%")
            print(f"  Verified Accuracy: {epoch_ver_acc:.2f}%")
            print(f"  Avg Bound Width: {epoch_width:.4f}")
            print(f"  Time: {epoch_time:.2f}s")
            print("=" * 80 + "\n")

        # Log metrics to CSV
        if self.log:
            with open(self.metrics_file, "a") as f:
                f.write(f"{self.epoch + 1},{self.phase},{self.current_eps:.6f},")
                f.write(
                    f"{epoch_clean_loss:.6f},{epoch_rob_loss:.6f},{epoch_loss:.6f},"
                )
                f.write(f"{epoch_acc:.4f},{epoch_ver_acc:.4f},")
                f.write(f"{epoch_width:.6f},")
                f.write(f"{epoch_time:.2f}\n")

    def print_config(self):
        """Prints configuration of the experiment."""
        print("=" * 80)
        print(f"Method: {self.config['method']}")
        print(f"Initialization: {self.config['init_method']}")
        print(f"Warmup epochs: {self.config['warm_up']} (ε=0)")
        print(
            f"Robust epochs: {self.config['nb_epochs']} (ε ramps to {self.config['eps']})"
        )
        print(f"Epsilon schedule: {self.config['epsilon_schedule']}")
        print(f"Total epochs: {self.config['warm_up'] + self.config['nb_epochs']}")
        print(f"Batch size: {self.config['dataset'].batch_size()}")
        print(f"Eval frequency: every {self.config['eval_freq']} epochs")
        if self.log:
            print(f"Logs saved to: {self.run_dir}")
            # Print special marker for test metadata collection
            print(f"TRAINING_OUTPUT_DIR: {self.run_dir}")
        print("=" * 80)

    def save_dashboard(self):
        """Generate interactive HTML dashboard."""
        if self.log:
            try:
                # Import dashboard generator
                from confiance.dashboard.generator import DashboardGenerator

                # Generate dashboard
                run_dir = self.metrics_file.parent
                dashboard_gen = DashboardGenerator(run_dir)
                dashboard_path = dashboard_gen.generate()
                print(f"Dashboard generated: {dashboard_path}")

            except ImportError as e:
                warnings.warn(f"Dashboard generation skipped: {e}")
            except Exception as e:
                warnings.warn(f"Dashboard generation failed: {e}")
