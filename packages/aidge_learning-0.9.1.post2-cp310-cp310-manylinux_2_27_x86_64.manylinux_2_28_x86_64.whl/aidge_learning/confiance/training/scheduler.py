import numpy as np


class Scheduler:
    """
    Abstract base class for scheduling the perturbation radius (epsilon) during training.

    The scheduler controls how the perturbation radius ε increases during the warmup phase,
    allowing the model to gradually adapt to adversarial robustness constraints.
    """

    def get_value(self, epoch: int) -> float:
        """Get the value for a given epoch."""
        raise NotImplementedError


class LinearScheduler(Scheduler):
    def __init__(self, step: float, max_val: float):
        """
        Linear scheduler for gradually increasing the perturbation radius during warmup.

        :param step: Increment per epoch (typically target_eps / num_epochs)
        :param max_val: Maximum epsilon value (target perturbation radius)
        """
        self.step = step
        self.max_val = max_val

    def get_value(self, epoch: int) -> float:
        """Compute value for the given epoch using linear scheduling."""
        if epoch < 0:
            # Warmup phase: no adversarial perturbation yet
            return 0
        else:
            # Linear increase, capped at max_val
            return min(self.step * (epoch + 1), self.max_val)


class SinusoidalScheduler(Scheduler):
    def __init__(self, max_val: float, total_epochs: int):
        """
        Sinusoidal scheduler for smoothly increasing the perturbation radius.

        Follows ε_t = ε_max × sin²(πt/2T).
        The sinusoidal schedule provides gentler initial epsilon increases compared to linear,
        which can help prevent bound explosion at large target epsilon values (e.g., ε=0.3).

        :param total_epochs: Number of epochs to ramp from 0 to max_val
        :param max_val: Target epsilon value
        """
        self.max_val = max_val
        self.total_epochs = total_epochs

    def get_value(self, epoch: int) -> float:
        """Compute value for the given epoch using sinusoidal scheduling."""
        if epoch < 0:
            # Warmup phase: no adversarial perturbation yet
            return 0
        elif epoch >= self.total_epochs:
            # Cap at max value after ramp completes
            return self.max_val
        else:
            # Sinusoidal ramp: ε_t = ε_max × sin²(πt/2T)
            t_normalized = epoch / self.total_epochs
            return self.max_val * (np.sin(np.pi * t_normalized / 2) ** 2)


class ConstantScheduler(Scheduler):

    def __init__(self, max_val: float):
        """
        Constant scheduler for immediate full perturbation.

        :param max_val: Target epsilon value.
        """
        self.max_val = max_val

    def get_value(self, epoch: int) -> float:
        """Compute epsilon value for the given epoch (constant after warmup)."""
        if epoch < 0:
            # Warmup phase: no adversarial perturbation yet
            return 0
        else:
            return self.max_val


def get_eps_scheduler(epsilon_schedule: str, eps: float, nb_epochs: int) -> Scheduler:
    """Create epsilon scheduler based on chosen schedule."""
    if epsilon_schedule == "sinusoidal":
        eps_scheduler = SinusoidalScheduler(max_val=eps, total_epochs=nb_epochs)
    elif epsilon_schedule == "linear":
        eps_scheduler = LinearScheduler(step=eps / nb_epochs, max_val=eps)
    elif epsilon_schedule == "constant":
        eps_scheduler = ConstantScheduler(max_val=eps)
    else:
        raise ValueError(
            f"Unknown epsilon_schedule '{epsilon_schedule}'. Must be 'linear', 'sinusoidal', or 'constant'"
        )

    return eps_scheduler
