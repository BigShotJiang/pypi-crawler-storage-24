"""
Interval-based Robust Training for Neural Networks using Aidge Framework.

This module implements certified robust training using Interval Bound Propagation (IBP).

The approach trains neural networks that are provably robust against adversarial perturbations
by propagating interval bounds (lower and upper bounds) through the network and optimizing
a robust loss function. This propagation is achieved by rewriting the aidge GraphView.

Key concepts:
- Interval Network: A network that computes both lower and upper bounds for all activations
- Epsilon (ε): The maximum L∞ perturbation radius for adversarial robustness
- Warmup: Gradually increasing ε from 0 to the target value during training
- Robust Loss: Combines standard classification loss with interval tightness constraints

References:
    Gowal et al. "On the Effectiveness of Interval Bound Propagation for Training Verifiably Robust Models"
    Shi et al. "Fast Certified Robust Training with Short Warmup", NeurIPS 2021
"""

import os
import warnings
from pathlib import Path

import aidge_backend_cpu
import aidge_core
import numpy as np
import sys
import time
from aidge_learning.aidge_learning import Adam, step_lr
from aidge_learning.aidge_learning.loss import CELoss, MSE, RobustCELoss
from tqdm import tqdm

sys.path.append(os.path.abspath(str(Path(__file__).parent)))
from training.dataset import AidgeDataset
from training.interval_builder import get_interval_network, extract_model
from training.logger import Logger
from training.scheduler import get_eps_scheduler
from training.utils import evaluate_rob, init_model_weights, get_model

# Ensure CPU backend is loaded
assert aidge_backend_cpu

aidge_core.Log.set_console_level(aidge_core.Level.Warn)


def _forward_interval(
    interval_model,
    interval_scheduler,
    interval_opt,
    data,
    label,
    epsilon: float,
    out_name: str,
    method: str,
):
    """
    Perform interval-based forward/backward pass.

    :param interval_model: The interval network with lower/upper bounds
    :param interval_scheduler: Scheduler for the interval model
    :param interval_opt: Optimizer for the interval model
    :param data: Input batch tensor
    :param label: Label batch tensor
    :param epsilon: Current perturbation radius
    :param out_name: Name of the output node (from original model)
    :param method: "width", "logits", or "robust"

    :return (loss, predictions, metrics_dict)
    """
    # Create epsilon tensor
    epsilon_tensor = np.full(np.array(data).shape, epsilon, dtype=np.float32)

    # Forward pass through interval network
    # Note: logits method has 3 inputs (data, epsilon, label) while width/robust methods have 2 (data, epsilon)
    if method == "logits":
        interval_scheduler.forward(
            data=[data, aidge_core.Tensor(epsilon_tensor), label]
        )
    else:  # width or robust method
        interval_scheduler.forward(data=[data, aidge_core.Tensor(epsilon_tensor)])

    # Initialize metrics
    nan_detected, ver_acc = False, 0
    nb_samples = label.dims[0]

    # Get outputs
    pred = interval_model.get_node(out_name).get_operator().get_output(0)
    lower = interval_model.get_node(f"{out_name}_lower").get_operator().get_output(0)
    upper = interval_model.get_node(f"{out_name}_upper").get_operator().get_output(0)
    average_width = upper - lower

    # Compute verified accuracy
    lower_np, upper_np = np.array(lower), np.array(upper)
    for j in range(lower_np.shape[0]):
        true_class = np.argmax(label, axis=1)[j]
        mask = np.ones(lower_np.shape[1], bool)
        mask[true_class] = False

        is_verified = (lower_np[j, true_class] >= upper_np[j][mask]).all()
        ver_acc += int(is_verified)

    # Compute clean CE loss
    clean_ce_loss = CELoss(pred, label)

    # Compute robust loss
    if method in ["logits", "robust"]:
        if method == "robust":
            # Use RobustCELoss directly on interval bounds
            rob_ce_loss = RobustCELoss(lower, upper, label)
        else:
            # Compute robust CE loss
            rob_pred = interval_model.get_node("logits").get_operator().get_output(0)
            rob_ce_loss = CELoss(rob_pred, label)

    elif method == "width":
        width = interval_model.get_node("width").get_operator().get_output(0)

        # Compute width statistics
        target = aidge_core.Tensor(np.zeros(label.dims, dtype=np.float32))
        width_loss = MSE(width, target)

        rob_ce_loss = width_loss  # For metrics consistency
    else:
        raise ValueError

    # Check for NaN/Inf
    if np.any(~np.isfinite(average_width)):
        nan_detected = True

    # Compute accuracy
    acc = np.sum(np.argmax(pred, axis=1) == np.argmax(label, axis=1))

    # Backward pass through interval network
    interval_scheduler.backward()

    # Update interval model parameters
    interval_opt.update()
    interval_opt.reset_grad()

    metrics = {
        "accuracy": acc,
        "clean_loss": float(clean_ce_loss[0]),
        "rob_loss": float(rob_ce_loss[0]),
        "loss": float(rob_ce_loss[0]) + float(clean_ce_loss[0]),
        "width": np.mean(np.array(average_width)),
        "ver_acc": ver_acc,
        "nb_samples": nb_samples,
        "nan_detected": nan_detected,
    }
    return pred, metrics


def train_interval_model(
    dataset: aidge_core.DataProvider,
    model: aidge_core.GraphView,
    input_shape: tuple,
    method: str = "logits",
    warm_up: int = 2,
    nb_epochs: int = 10,
    eps: float = 0.1,
    epsilon_schedule: str = "linear",
    output_dir: str = "output",
    eval_freq: int = 5,
    init_method: str = "ibp",
    dataset_name: str = "unknown",
    log_metrics: bool = True,
):
    """
    Train a neural network with certified robustness using Interval Bound Propagation (IBP).

    The training process involves two phases:
    - Warmup (warm_up epochs): Standard training with ε=0, allowing model to learn basic features
    - Robust training (nb_epochs): Gradually increase ε while optimizing robust loss

    :param dataset: Aidge DataProvider containing training data (images and labels)
    :param model: Standard neural network model to make robust
    :param input_shape: Input tensor shape, e.g., [1, 1, 28, 28] for MNIST
    :param method: Robust loss computation method:
            - "width": Minimize average interval width
            - "logits": Use logit-based robust loss
            - "robust":
    :param init_method: Weight initialization method, "xavier" or "ibp" (default: "ibp").
    :param warm_up: Number of warmup epochs with ε=0 before robust training
    :param nb_epochs: Number of epochs for robust training (with increasing ε)
    :param eval_freq: Frequency of detailed evaluation (in epochs)
    :param eps: Target perturbation radius (L∞ norm), e.g., 0.1 means ±0.1 pixel perturbation
    :param epsilon_schedule: Epsilon scheduling method (default: "linear")
            - "linear": Linear ramp from 0 to eps over nb_epochs
            - "sinusoidal": Sinusoidal (sin²) ramp, gentler initial increases
    :param output_dir: Directory for saving logs and metrics
    :param dataset_name: name of the dataset
    :param log_metrics: Whether to log metrics to CSV file
    :param return_logger: whether to return the metric logger, used for tests.
    """
    print("=" * 80)
    print("Interval-based Certified Robust Training")

    # Create Logger (if log_metrics == False, no log file will be created)
    logger = Logger(output_dir, locals(), log_metrics)
    logger.print_config()

    # Get the name of the output layer for later reference
    out_name = model.get_ordered_nodes()[-1].name()

    print(f"Initializing model weights ({init_method})...")
    model.compile("cpu", aidge_core.dtype.float32, dims=[input_shape])
    init_model_weights(model, ibp_init=init_method == "ibp")

    print("Building interval network...")
    # Cloned from initialized standard_model to share initial weights
    interval_model = get_interval_network(model.clone(), method=method)
    in_shape = [input_shape, input_shape] + (
        [[1, 10]] if method == "logits" else []
    )  # TODO dynamic label shape

    print("Compiling interval network...")
    interval_model.compile("cpu", aidge_core.dtype.float32, dims=in_shape)
    interval_scheduler = aidge_core.SequentialScheduler(interval_model)

    interval_opt = Adam()
    interval_opt.set_learning_rate_scheduler(step_lr(0.001, 10000))
    interval_opt.set_parameters(list(aidge_core.producers(interval_model)))

    print(f"Using {epsilon_schedule} schedule")
    eps_scheduler = get_eps_scheduler(epsilon_schedule, eps, nb_epochs)

    print("\n" + "=" * 80)
    print("Starting training...")
    print("=" * 80 + "\n")
    # Track NaN/Inf detection for warnings
    nan_detected_epochs = set()

    # Main training loop: warmup + robust training
    for epoch in range(nb_epochs + warm_up):
        epoch_start_time = time.perf_counter()
        current_epsilon = eps_scheduler.get_value(epoch - warm_up)

        # Init logger for epoch
        logger.init_epoch_metrics(epoch, current_epsilon)

        # Progress bar for monitoring training
        pbar = tqdm(enumerate(dataset), total=len(dataset), file=sys.stdout)
        phase = "Warmup" if epoch < warm_up else "Robust"
        pbar.set_description(
            f"Epoch {epoch+1}/{nb_epochs + warm_up} [{phase}] (ε={current_epsilon:.6f})"
        )

        # Iterate over batches
        for i, (data, label) in pbar:
            pred, metrics = _forward_interval(
                interval_model,
                interval_scheduler,
                interval_opt,
                data,
                label,
                current_epsilon,
                out_name,
                method,
            )

            # Accumulate metrics
            logger.update_metrics(metrics)

            pbar.set_postfix(logger.get_pbar_dict(i))

        # Compute epoch metrics
        logger.summarize_epoch()
        if logger.nan_detected:
            nan_detected_epochs.add(epoch + 1)

    # Training complete
    print("\n" + "=" * 80)
    print("Training completed!")
    print(
        f"Final clean accuracy: {(100*logger.metrics['accuracy'] / logger.metrics['nb_samples']):.2f}%"
    )

    logger.save_dashboard()

    print("=" * 80 + "\n")
    print("Returning standard model without intervals")
    return interval_model
