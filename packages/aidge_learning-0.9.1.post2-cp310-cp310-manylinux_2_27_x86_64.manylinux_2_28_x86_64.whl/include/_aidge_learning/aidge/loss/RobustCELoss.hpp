/*******************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#pragma once
#include "aidge/data/Tensor.hpp"
#include <aidge/backend/cpu/data/GetCPUPtr.h>
#include <memory>

#include <algorithm>
#include <cmath>
#include <memory>
#include <mutex>
#include <numeric>

#include "aidge/data/Tensor.hpp"
#include "aidge/graph/GraphView.hpp"
#include "aidge/graph/OpArgs.hpp"
#include "aidge/loss/LossList.hpp"
#include "aidge/operator/Add.hpp"
#include "aidge/operator/Div.hpp"
#include "aidge/operator/Exp.hpp"
#include "aidge/operator/Ln.hpp"
#include "aidge/operator/Mul.hpp"
#include "aidge/operator/OperatorTensor.hpp"
#include "aidge/operator/Producer.hpp"
#include "aidge/operator/ReduceMean.hpp"
#include "aidge/operator/ReduceSum.hpp"
#include "aidge/operator/Sub.hpp"
#include "aidge/recipes/GraphViewHelper.hpp"
#include "aidge/scheduler/Scheduler.hpp"
#include "aidge/scheduler/SequentialScheduler.hpp"

namespace Aidge {
namespace loss {

/**
 * @brief Robust Cross-Entropy Loss with formal verification over intervals
 *
 * This function computes a robust version of Cross-Entropy Loss that operates
 * on interval bounds rather than point predictions.
 *
 *
 * @param lower_bounds Lower bounds of prediction logits [BatchSize, NbClasses]
 * @param upper_bounds Upper bounds of prediction logits [BatchSize, NbClasses]
 * @param target Target labels (one-hot encoded) [BatchSize, NbClasses]
 * @return Tensor containing the robust cross-entropy loss (scalar)
 *
 */
Tensor RobustCELoss(std::shared_ptr<Tensor> &lower_bounds,
                    std::shared_ptr<Tensor> &upper_bounds,
                    const std::shared_ptr<Tensor> &target,
                    float scaling);

/**
 * @brief Computes interval bounds for exponential function
 *
 * Helper function that computes exp([a,b]) = [exp(a), exp(b)]
 * since exponential is monotonically increasing.
 *
 * @param lower_bounds Lower bounds of input interval
 * @param upper_bounds Upper bounds of input interval
 * @param exp_lower Output: lower bounds of exp(interval)
 * @param exp_upper Output: upper bounds of exp(interval)
 */
void computeExpInterval(const std::shared_ptr<Tensor> &lower_bounds,
                        const std::shared_ptr<Tensor> &upper_bounds,
                        std::shared_ptr<Tensor> &exp_lower,
                        std::shared_ptr<Tensor> &exp_upper);

/**
 * @brief Computes interval bounds for softmax function
 *
 * Helper function that computes softmax intervals using:
 * softmax_i ∈ [exp(lower_i)/sum_upper, exp(upper_i)/sum_lower]
 *
 * This provides conservative bounds for the softmax function over
 * the input interval.
 *
 * @param lower_bounds Lower bounds of input logits [BatchSize, NbClasses]
 * @param upper_bounds Upper bounds of input logits [BatchSize, NbClasses]
 * @param softmax_lower Output: lower bounds of softmax
 * @param softmax_upper Output: upper bounds of softmax
 */
void computeSoftmaxInterval(const std::shared_ptr<Tensor> &lower_bounds,
                            const std::shared_ptr<Tensor> &upper_bounds,
                            std::shared_ptr<Tensor> &softmax_lower,
                            std::shared_ptr<Tensor> &softmax_upper);

} // namespace loss
} // namespace Aidge
