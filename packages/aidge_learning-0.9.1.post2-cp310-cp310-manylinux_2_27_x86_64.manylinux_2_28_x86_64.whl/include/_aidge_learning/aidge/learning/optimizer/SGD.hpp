/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_CORE_OPTIMIZER_SGD_H_
#define AIDGE_CORE_OPTIMIZER_SGD_H_

#include <functional>
#include <memory>
#include <vector>

#include "aidge/backend/cpu/data/TensorImpl.hpp"
#include "aidge/data/Tensor.hpp"
#include "aidge/learning/optimizer/Optimizer.hpp"
#include "aidge/utils/Registrar.hpp"
#include "aidge/utils/StaticAttributes.hpp"
#include "aidge/utils/TensorUtils.hpp"
#include "aidge/utils/Types.h"

#define LIST_SGD_ATTR(X)  \
    X(Momentum, "momentum", float),  \
    X(Dampening, "dampening", float), \
    X(WeightDecay, "weight_decay", float)

namespace Aidge {
/**
 * @enum SGDAttr
 * @brief Enum class defining the attributes for the SGD optimizer.
 */
enum class SGDAttr { GENERATE_LIST_ATTR_ENUM(LIST_SGD_ATTR) };
} // namespace Aidge

namespace {
template <> struct EnumStrings<Aidge::SGDAttr>
{
    static const char *const data[];
};
constexpr const char *const EnumStrings<Aidge::SGDAttr>::data[] = {
    GENERATE_LIST_ATTR_STR(LIST_SGD_ATTR)};
} // namespace

namespace Aidge {
/**
 * @brief Description of the SGD optimizer.
 */
class SGD : public Optimizer {
  private:
    std::vector<Tensor> mGradientInertia;
    Tensor mLR{std::vector<std::size_t>({1})};
    Tensor mMomentum{std::vector<std::size_t>({1})};
    Tensor mReversedDampening{std::vector<std::size_t>({1})};
    Tensor mWeightDecay{std::vector<std::size_t>({1})};

  public:
    using Attributes_ =
        StaticAttributes<SGDAttr, GENERATE_LIST_ATTR_TYPE(LIST_SGD_ATTR)>;

    template <SGDAttr e> using attr = typename Attributes_::template attr<e>;

    const std::shared_ptr<Attributes_> mAttributes;

    SGD(const float momentum = 0.0f,
        const float dampening = 0.0f,
        const float weightDecay = 0.0f)
        : Optimizer(),
          mAttributes(std::make_shared<Attributes_>(
              attr<SGDAttr::Momentum>(momentum),
              attr<SGDAttr::Dampening>(dampening),
              attr<SGDAttr::WeightDecay>(weightDecay)))
    {
        mMomentum = Tensor(momentum);
        mReversedDampening = Tensor(1.0f - dampening);
        mWeightDecay = Tensor(weightDecay);
    }

    inline std::shared_ptr<Attributes> attributes() const override
    {
        return mAttributes;
    }

    void update() override final
    {
        const auto opTensor0 = std::static_pointer_cast<OperatorTensor>(
            mParameters[0]->getOperator());
        const auto tensor0 = opTensor0->getOutput(0);

        const auto backend = tensor0->backend();
        const auto device = tensor0->device();
        const auto dataType = tensor0->dtype();

        mLR = Tensor(learningRate());
        mLR.toDtype(dataType);
        mLR.toBackend(backend, device);

        mWeightDecay.toDtype(dataType);
        mWeightDecay.toBackend(backend, device);

        mReversedDampening.toDtype(dataType);
        mReversedDampening.toBackend(backend, device);

        mMomentum.toDtype(dataType);
        mMomentum.toBackend(backend, device);

        // update loop

        if (mLRScheduler.step() == 0) {
            for (std::size_t i = 0; i < mParameters.size(); ++i) {
                auto opTensor = std::static_pointer_cast<OperatorTensor>(
                    mParameters[i]->getOperator());
                auto tensor = opTensor->getOutput(0);

                mGradientInertia[i] = tensor->grad()->clone();
                *tensor -= mLR * mGradientInertia[i];
            }
        } else {
            for (std::size_t i = 0; i < mParameters.size(); ++i) {
                auto opTensor = std::static_pointer_cast<OperatorTensor>(
                    mParameters[i]->getOperator());
                auto tensor = opTensor->getOutput(0);

                (*tensor->grad()) += mWeightDecay * (*tensor);
                mGradientInertia[i] = mMomentum * mGradientInertia[i] +
                                      mReversedDampening * (*tensor->grad());
                *tensor -= mLR * mGradientInertia[i];
            }
        }
        mLRScheduler.update();
    }

    void setParameters(
        const std::vector<std::shared_ptr<Node>> &parameters) override final
    {
        Optimizer::setParameters(parameters);
        mGradientInertia = std::vector<Tensor>(parameters.size());
        for (std::size_t i = 0; i < parameters.size(); ++i) {
            const auto opTensor = std::static_pointer_cast<OperatorTensor>(
                parameters[i]->getOperator());
            const auto tensor = opTensor->getOutput(0);

            mGradientInertia[i] = Tensor(tensor->dims());
            mGradientInertia[i].toBackend(tensor->backend(), tensor->device());
            mGradientInertia[i].toDtype(tensor->dtype());
        }
        if (parameters.size() > 0) {
            const auto opTensor = std::static_pointer_cast<OperatorTensor>(
                parameters[0]->getOperator());
            const auto tensor = opTensor->getOutput(0);

            mWeightDecay.toBackend(tensor->backend(), tensor->device());
            mWeightDecay.toDtype(tensor->dtype());
            mReversedDampening.toBackend(tensor->backend(), tensor->device());
            mReversedDampening.toDtype(tensor->dtype());
            mMomentum.toBackend(tensor->backend(), tensor->device());
            mMomentum.toDtype(tensor->dtype());
        }
    }
};

} // namespace Aidge

#endif // AIDGE_CORE_OPTIMIZER_SGD_H_
