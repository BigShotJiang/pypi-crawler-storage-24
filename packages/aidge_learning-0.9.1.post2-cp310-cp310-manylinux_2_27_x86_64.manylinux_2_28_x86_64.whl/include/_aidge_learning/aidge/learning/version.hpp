#ifndef aidge_learning_VERSION_H
#define aidge_learning_VERSION_H

namespace Aidge {
namespace learning {

	struct Version {
		static constexpr int major = 0;
		static constexpr int minor = 9;
		static constexpr int patch = 1;
		static constexpr const char* full = "0.9.1";
		static constexpr const char* git_hash = "78f0f12";
	};
} // namespace learning
} // namespace Aidge

#endif
