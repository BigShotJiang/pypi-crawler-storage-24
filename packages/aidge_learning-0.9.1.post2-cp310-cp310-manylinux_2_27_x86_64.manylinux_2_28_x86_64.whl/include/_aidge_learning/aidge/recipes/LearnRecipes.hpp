/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_LEARNING_LEARNRECIPES_H_
#define AIDGE_LEARNING_LEARNRECIPES_H_

#include "aidge/data/Tensor.hpp"
#include "aidge/graph/GraphView.hpp"

namespace Aidge {
/**
 * @brief Insert a BatchNorm node after every Convolutional node of a GraphView
 * @param graphView The GraphView to process.
 */
void insertBatchNormNodes(std::shared_ptr<GraphView> graphView,
                          bool initialize = true);

void setBatchNormTrainingMode(std::shared_ptr<GraphView> graphView,
                              bool trainingMode = true);
} // namespace Aidge

#endif /* AIDGE_LEARNING_LEARNRECIPES_H_ */
