/*
 * Copyright (c) 2025-2026 Tobias Weber <weber.tobias.md@gmail.com>
 * 
 * This file is part of the BCSV library.
 * 
 * Licensed under the MIT License. See LICENSE file in the project root 
 * for full license information.
 */

#pragma once

#include <string>
#include <istream>
#include <ostream>
#include <cstdint>

#include "definitions.h"
#include "layout.h"

namespace bcsv {
    // Forward declarations
    class Layout;
    template<typename... ColumnTypes>
    class LayoutStatic;

    /**
     * @brief Represents the file header with controlled memory layout for direct I/O
     * 
     * The BCSV file format uses a structured binary layout optimized for efficient parsing
     * and minimal storage overhead. The layout is designed to be platform-independent
     * with explicit byte ordering and fixed-size fields.
     * 
     * @section binary_layout Complete Binary File Layout
     * 
     * The file consists of three main sections:
     * 1. Fixed Header (24 bytes) - Core file metadata
     * 2. Variable Schema (varies) - Column definitions  
     * 3. Data Records (varies) - Actual row data
     * 
     * @subsection fixed_header Fixed Header Section (24 bytes)
     * 
     * ```
     * Offset | Size | Type    | Description
     * -------|------|---------|------------------------------------------
     *   0    |  4   | uint32  | Magic number: 0x56534342 ("BCSV")
     *   4    |  8   | uint64  | Creation time (Unix epoch seconds)
     *  12    |  1   | uint8   | Major version number
     *  13    |  1   | uint8   | Minor version number  
     *  14    |  1   | uint8   | Patch version number
     *  15    |  1   | uint8   | Compression level (0-9, 0=none)
     *  16    |  2   | uint16  | Feature flags (bitfield)
     *  18    |  2   | uint16  | Number of columns (N)
     *  20    |  4   | uint32  | Packet size in bytes
     * ```
     * 
     * @subsection variable_schema Variable Schema Section
     * 
     * This section defines the structure of each column and varies in size based
     * on the number of columns and length of column names.
     * 
     * ```
     * Section              | Size        | Description
     * ---------------------|-------------|----------------------------------------
     * Column Data Types    | N * 1 byte  | Type enum for each column (uint8)
     * Column Name Lengths  | N * 2 bytes | Length of each column name (uint16)
     * Column Names         | Variable    | Concatenated column names (no null terminators)
     * ```
     * 
     * @subsection memory_diagram Memory Layout Diagram
     * 
     * Example with 3 columns: "name" (string), "age" (int64), "salary" (double)
     * 
     * ```
     * Byte    0    1    2    3    4    5    6    7    8    9   10   11
     *      ┌────┬────┬────┬────┬────┬────┬────┬────┬────┬────┬────┬────┐
     *      │    Magic Number   │         Creation Time (uint64)        │
     *      │   0x56534342      │           Unix epoch seconds          │
     *      └────┴────┴────┴────┴────┴────┴────┴────┴────┴────┴────┴────┘
     * 
     * Byte   12   13   14   15   16   17   18   19   20   21   22   23
     *      ┌────┬────┬────┬────┬────┬────┬────┬────┬────┬────┬────┬────┐
     *      │Maj │Min │Pat │Cmp │  Flags  │ Cols=3  │   Packet Size     │
     *      │ 1  │ 0  │ 0  │ 0  │  0x00   │  0x03   │   0x00800000      │
     *      └────┴────┴────┴────┴────┴────┴────┴────┴────┴────┴────┴────┘
     * 
     * Byte   24   25   26   27   28   29   30   31   32
     *      ┌────┬────┬────┬────┬────┬────┬────┬────┬────┐
     *      │str │i64 │dbl │ len=4   │ len=3   │ len=6   │
     *      │0x0B│0x08│0x0A│ 0x04    │ 0x03    │ 0x06    │
     *      └────┴────┴────┴────┴────┴────┴────┴────┴────┘
     * 
     * Byte   33   34   35   36   37   38   39   40   41   42   43   44   45
     *      ┌────┬────┬────┬────┬────┬────┬────┬────┬────┬────┬────┬────┬────┐
     *      │ n  │ a  │ m  │ e  │ a  │ g  │ e  │ s  │ a  │ l  │ a  │ r  │ y  │
     *      │0x6E│0x61│0x6D│0x65│0x61│0x67│0x65│0x73│0x61│0x6C│0x61│0x72│0x79│
     *      └────┴────┴────┴────┴────┴────┴────┴────┴────┴────┴────┴────┴────┘
     * ```
     * 
     * Total header size in this example: 46 bytes
     * 
     * @subsection data_types Column Data Type Encoding
     * 
     * Each column type is encoded as an 8-bit unsigned integer:
     * - 0x00: bool
     * - 0x01: uint8
     * - 0x02: uint16
     * - 0x03: uint32
     * - 0x04: uint64
     * - 0x05: int8
     * - 0x06: int16
     * - 0x07: int32
     * - 0x08: int64
     * - 0x09: float
     * - 0x0A: double
     * - 0x0B: string
     * 
     * @subsection flag_bits Feature Flags (16-bit bitfield)
     * - 0x0001: Zero-Order-Hold compression enabled
     * - Bits 1-15: Reserved for future optional features
     * 
     * @note All multi-byte integers are stored in little-endian format
     * @note Column names are stored without null terminators to save space
     * @note The magic number 0x56534342 spells "BCSV" in ASCII when read as bytes
     */
    class FileHeader {
    public:
        /**
         * @brief Fixed-size header structure with controlled memory layout
         * 
         * This structure represents the first 24 bytes of every BCSV file.
         * The #pragma pack directive ensures no padding is inserted between
         * fields, guaranteeing consistent binary layout across platforms.
         * 
         * @note The structure is exactly 24 bytes as verified by static_assert
         * @note All multi-byte fields use little-endian byte ordering
         */
        #pragma pack(push, 1)
        struct ConstSection {
            uint32_t magic;             ///< Magic number: 0x56534342 ("BCSV" in ASCII)
            uint64_t creation_time;     ///< File creation time (Unix epoch seconds, 0 = unknown)
            uint8_t  version_major;     ///< Major version number (0-255)
            uint8_t  version_minor;     ///< Minor version number (0-255)
            uint8_t  version_patch;     ///< Patch version number (0-255)
            uint8_t  compression_level; ///< Compression level (0=none, 1-9=LZ4 levels)
            uint16_t flags;             ///< Feature flags bitfield
            uint16_t column_count;      ///< Number of columns in the file
            uint32_t packet_size;       ///< Packet size in bytes used for compression
        };
        #pragma pack(pop)
        static_assert(sizeof(ConstSection) == 24, "BinaryHeader must be exactly 24 bytes");

        /**
         * @brief File format constants and limits
         */
        static constexpr size_t FIXED_HEADER_SIZE  = sizeof(ConstSection);  ///< Size of fixed header: 24 bytes
        static constexpr size_t COLUMN_TYPE_SIZE   = sizeof(uint8_t);       ///< Size per column type: 1 byte  
        static constexpr size_t COLUMN_LENGTH_SIZE = sizeof(uint16_t);      ///< Size per name length: 2 bytes
        
        // Constructors
        FileHeader(size_t columnCount = 0, size_t compressionLevel = 9, uint8_t major = static_cast<uint8_t>(version::MAJOR), uint8_t minor = static_cast<uint8_t>(version::MINOR), uint8_t patch = static_cast<uint8_t>(version::PATCH));
        ~FileHeader() = default;

        // Version management
        void        setVersion(uint8_t major, uint8_t minor, uint8_t patch) 
                                                        { const_section_.version_major = major;
                                                          const_section_.version_minor = minor;
                                                          const_section_.version_patch = patch; }
        std::string versionString() const               { return    std::to_string(const_section_.version_major) + "." + 
                                                                    std::to_string(const_section_.version_minor) + "." + 
                                                                    std::to_string(const_section_.version_patch); }
        uint8_t     versionMajor() const                { return const_section_.version_major; }
        uint8_t     versionMinor() const                { return const_section_.version_minor; }
        uint8_t     versionPatch() const                { return const_section_.version_patch; }

        // Creation time management
        void        setCreationTime(uint64_t epochSeconds) { const_section_.creation_time = epochSeconds; }
        uint64_t    getCreationTime() const             { return const_section_.creation_time; }

        // Compression management
        void        setCompressionLevel(size_t level)   { const_section_.compression_level = (level > 9) ? 9 : static_cast<uint8_t>(level); }
        uint8_t     getCompressionLevel() const         { return const_section_.compression_level; }

        // Packet size management
        void        setPacketSize(size_t packetSize)    { const_section_.packet_size = static_cast<uint32_t>(packetSize); }
        uint32_t    getPacketSize() const               { return const_section_.packet_size; }

        // Flags management
        void        clearFlag(FileFlags flag)           { setFlag(flag, false); }
        bool        hasFlag(FileFlags flag) const       { return (getFlags() & flag) != FileFlags::NONE; }
        FileFlags   getFlags() const                    { return static_cast<FileFlags>(const_section_.flags); }
        void        setFlags(FileFlags flags)           { const_section_.flags = static_cast<uint16_t>(flags); }
        void        setFlag(FileFlags flag, bool value);

        // Magic number validation
        bool        isValidMagic() const                { return const_section_.magic == BCSV_MAGIC; }
        uint32_t    getMagic() const                    { return const_section_.magic; }

        /**
         * @brief Binary I/O operations for complete file headers
         * 
         * These methods handle serialization and deserialization of the complete
         * file header including both the fixed-size portion and variable-length
         * column schema information.
         */
        
        /**
         * @brief Calculate total binary size of header including column schema
         * @param columnLayout The column layout to include in size calculation
         * @return Total size in bytes needed for complete header
         */
        template<LayoutConcept LayoutType>
        static size_t getBinarySize(const LayoutType& layout);

        /**
         * @brief Read complete header from binary stream
         * @param stream Input stream to read from
         * @param columnLayout Column layout to populate from stream
         * @throws std::runtime_error on error or invalid data
         */
        void readFromBinary(std::istream& stream, Layout& columnLayout);

        /**
         * @brief Read complete header from binary stream
         * @param stream Input stream to read from
         * @param columnLayout Column layout to validate and populate from stream
         * @throws std::runtime_error on error or invalid data
         */
        template<typename... ColumnTypes>
        void readFromBinary(std::istream& stream, LayoutStatic<ColumnTypes...>& columnLayout);
        
        /**
         * @brief Write complete header to binary stream
         * @param stream Output stream to write to
         * @param columnLayout Column layout to serialize with header
         * @throws std::runtime_error on write error
         */
        template<LayoutConcept LayoutType>
        void writeToBinary(std::ostream& stream, const LayoutType& columnLayout);

        /**
         * @brief Print detailed binary layout information for debugging
         * @param columnLayout Column layout to analyze
         */
        template<LayoutConcept LayoutType>
        void printBinaryLayout(const LayoutType& columnLayout) const;

    private:
        ConstSection const_section_;
    };

} // namespace bcsv
