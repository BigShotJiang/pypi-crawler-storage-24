/*
 * Copyright (c) 2025-2026 Tobias Weber <weber.tobias.md@gmail.com>
 * 
 * This file is part of the BCSV library.
 * 
 * Licensed under the MIT License. See LICENSE file in the project root 
 * for full license information.
 */

#pragma once

/**
 * @file bcsv.h
 * @brief Binary CSV (BCSV) Library - Main Header with Declarations
 * 
 * A C++20 header-only library for reading and writing binary CSV files
 * with type safety, compression support, and efficient I/O operations.
 * 
 * This header includes all BCSV component declarations:
 * - FileHeader: Binary file header management
 * - ColumnLayout: Column definitions and metadata
 * - Row: Individual data rows
 * - Packet: Data packet abstraction
 * - Reader: Template-based file reading
 * - Writer: Template-based file writing
 */

#include <string>

// Core definitions first
#include "definitions.h"

// Core component declarations
#include "file_header.h"
#include "layout.h"
#include "layout_guard.h"
#include "packet_header.h"
#include "reader.h"
#include "row.h"
#include "codec_row/row_codec_flat001.h"        // Flat001 codec
#include "codec_row/row_codec_zoh001.h"         // ZoH001 codec
#include "codec_row/row_codec_delta002.h"       // Delta row codec
#include "codec_row/row_codec_dispatch.h"       // Runtime dispatch
#include "codec_file/file_codec_concept.h"      // FileCodec concept + sentinels
#include "codec_file/file_codec_stream001.h"    // Stream-raw file codec
#include "codec_file/file_codec_stream_lz4_001.h" // Stream-LZ4 file codec
#include "codec_file/file_codec_packet001.h"    // Packet-raw file codec
#include "codec_file/file_codec_packet_lz4_001.h" // Packet-LZ4 file codec
#ifdef BCSV_HAS_BATCH_CODEC
#include "codec_file/file_codec_packet_lz4_batch001.h" // Batch-LZ4 async file codec
#endif
#include "codec_file/file_codec_dispatch.h"     // FileCodec runtime dispatch
#include "row_visitors.h"  // Row visitor pattern concepts and helpers
#include "writer.h"
#include "reader_concept.h"          // ReaderConcept
#include "writer_concept.h"          // WriterConcept
#include "csv_writer.h"              // CsvWriter
#include "csv_reader.h"              // CsvReader

// Include implementations
#include "bcsv.hpp"
#include "column_name_index.hpp"
#include "file_header.hpp"
#include "layout.hpp"
#include "reader.hpp"
#include "row.hpp"
#include "codec_row/row_codec_flat001.hpp"      // Flat001 codec implementation
#include "codec_row/row_codec_zoh001.hpp"       // ZoH001 codec implementation
#include "codec_row/row_codec_delta002.hpp"     // Delta row codec implementation
#include "writer.hpp"
#include "csv_writer.hpp"         // CsvWriter implementation
#include "csv_reader.hpp"         // CsvReader implementation
