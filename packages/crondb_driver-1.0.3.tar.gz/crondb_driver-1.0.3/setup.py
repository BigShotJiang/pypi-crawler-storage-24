from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="crondb-driver", # The name people will pip install
    version="1.0.3",
    author="Michael Tal",
    description="The official Python ORM and connection driver for the CronDB temporal database.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    install_requires=[
        "requests" # Tells pip to auto-install the requests library for the user
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)