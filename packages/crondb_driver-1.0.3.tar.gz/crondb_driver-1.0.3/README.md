# CronDB Python SDK

The official Object-Relational Mapping (ORM) and connection driver for **CronDB**, a high-performance, temporal C++ database engine.

Traditional Python architectures force you to build "split-brain" systems to handle time-based events: storing the data in a standard database while pushing the countdown timers to an external task queue or background worker system. 

**CronDB unifies state and time.** You inject finite-state-machine (FSM) timers directly into your database rows. When a state naturally expires, the C++ engine's asynchronous background threads instantly push a webhook directly to your backend server. 

No polling. No background workers. No external queues. Just one unified temporal engine.

---

## 📦 Installation

```bash
pip install crondb-driver