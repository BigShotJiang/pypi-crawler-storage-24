"""Artifact collection, manifest generation, and tar bundling."""

import json
import tarfile
from datetime import datetime, timezone
from pathlib import Path

RUNS_DIR = Path.home() / ".mlvault" / "runs"


def _collect_files(collect_dir: Path) -> list[Path]:
    """Return all files in collect_dir, excluding hidden files and __pycache__."""
    return [
        p for p in collect_dir.rglob("*")
        if p.is_file()
        and not any(part.startswith(".") for part in p.parts)
        and "__pycache__" not in p.parts
    ]


def build_snapshot(
    run_id: str,
    project: str,
    entrypoint: str,
    collect_dir: Path,
) -> tuple[dict, Path]:
    """
    Collect artifacts, write manifest, create tar.gz.
    Returns (manifest_dict, tar_path).
    """
    run_dir = RUNS_DIR / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    files = _collect_files(collect_dir)
    if not files:
        raise ValueError(f"No artifacts found in {collect_dir}")

    artifacts = [
        {"name": p.name, "path": str(p.relative_to(collect_dir)), "size": p.stat().st_size}
        for p in files
    ]

    manifest = {
        "run_id": run_id,
        "project": project,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "entrypoint": entrypoint,
        "collect_dir": str(collect_dir),
        "artifacts": artifacts,
        "jackal_path": None,  # filled in after upload
    }

    manifest_path = run_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2))

    tar_path = run_dir / f"{run_id}.tar.gz"
    with tarfile.open(tar_path, "w:gz") as tar:
        for f in files:
            tar.add(f, arcname=str(f.relative_to(collect_dir)))

    return manifest, tar_path


def update_manifest_jackal_path(run_id: str, jackal_path: str) -> None:
    manifest_path = RUNS_DIR / run_id / "manifest.json"
    manifest = json.loads(manifest_path.read_text())
    manifest["jackal_path"] = jackal_path
    manifest_path.write_text(json.dumps(manifest, indent=2))


def load_manifest(run_id: str) -> dict:
    manifest_path = RUNS_DIR / run_id / "manifest.json"
    if not manifest_path.exists():
        raise FileNotFoundError(f"No local record for run '{run_id}'")
    return json.loads(manifest_path.read_text())


def list_runs() -> list[dict]:
    if not RUNS_DIR.exists():
        return []
    runs = []
    for run_dir in sorted(RUNS_DIR.iterdir(), reverse=True):
        manifest_path = run_dir / "manifest.json"
        if manifest_path.exists():
            runs.append(json.loads(manifest_path.read_text()))
    return runs
