"""Storage adapter — HTTP to mlvault API, or jackal-helper fallback for dev."""

import base64
import json
import os
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path

_HELPER   = Path(__file__).parent.parent / "jackal-helper" / "index.js"
_ENV_FILE = Path(__file__).parent.parent / ".env"
_CREDENTIALS_FILE = Path.home() / ".mlvault" / "credentials"


def _load_env_file(path: Path) -> None:
    """Load key=value pairs from a file into os.environ (no-overwrite)."""
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            key, _, val = line.partition("=")
            os.environ.setdefault(key.strip(), val.strip().strip("'\""))


# Load credentials first (user config), then .env (dev/internal fallback).
_load_env_file(_CREDENTIALS_FILE)
_load_env_file(_ENV_FILE)


# ---------------------------------------------------------------------------
# API transport (MLVAULT_API_KEY path)
# ---------------------------------------------------------------------------

def _api_url() -> str:
    return os.environ.get("MLVAULT_API_URL", "https://mlvault-api-production.up.railway.app")


def _api_upload(data: bytes, key: str) -> str:
    """POST encrypted bundle to /v1/artifacts/{key}. Returns the key as CID."""
    api_key = os.environ["MLVAULT_API_KEY"]
    url = f"{_api_url()}/v1/artifacts/{key}"
    req = urllib.request.Request(
        url,
        data=data,
        method="POST",
        headers={
            "X-API-Key": api_key,
            "Content-Type": "application/octet-stream",
        },
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        return key


def _api_download(key: str) -> bytes:
    """GET encrypted bundle from /v1/artifacts/{key}. Returns raw bytes."""
    api_key = os.environ["MLVAULT_API_KEY"]
    url = f"{_api_url()}/v1/artifacts/{key}"
    req = urllib.request.Request(
        url,
        headers={"X-API-Key": api_key},
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        return resp.read()


# ---------------------------------------------------------------------------
# Jackal-helper transport (JACKAL_MNEMONIC path — internal dev only)
# ---------------------------------------------------------------------------

def _run_helper(command: str, arg: str, stdin_bytes: bytes | None = None) -> dict:
    mnemonic = os.environ.get("JACKAL_MNEMONIC")
    if not mnemonic:
        raise EnvironmentError(
            "JACKAL_MNEMONIC environment variable is not set."
        )

    result = subprocess.run(
        ["node", str(_HELPER), command, arg],
        input=stdin_bytes,
        capture_output=True,
        env={**os.environ},
    )

    if result.stderr:
        for line in result.stderr.decode(errors="replace").splitlines():
            if line.startswith("[jackal-helper]"):
                sys.stderr.write(line + "\n")

    if result.returncode != 0:
        raise RuntimeError(
            f"jackal-helper exited {result.returncode} for '{command} {arg}'"
        )

    lines = [l for l in result.stdout.decode(errors="replace").splitlines() if l.strip()]
    if not lines:
        raise RuntimeError(f"jackal-helper produced no output for '{command} {arg}'")

    data = json.loads(lines[-1])
    if not data.get("ok"):
        raise RuntimeError(f"jackal-helper error: {data.get('error', 'unknown')}")

    return data


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

def upload(local_path: Path, key: str) -> str:
    """Upload encrypted bundle. Returns a CID/key string."""
    data = local_path.read_bytes()

    if os.environ.get("MLVAULT_API_KEY"):
        return _api_upload(data, key)

    # Dev fallback: jackal-helper
    payload = base64.b64encode(data)
    result = _run_helper("upload", key, stdin_bytes=payload)
    return result["cid"]


def download(cid: str, local_path: Path) -> None:
    """Download by CID/key and write bytes to local_path."""
    if os.environ.get("MLVAULT_API_KEY"):
        raw = _api_download(cid)
        local_path.parent.mkdir(parents=True, exist_ok=True)
        local_path.write_bytes(raw)
        return

    # Dev fallback: jackal-helper
    if not os.environ.get("JACKAL_ADDRESS"):
        raise EnvironmentError(
            "JACKAL_ADDRESS environment variable is not set.\n"
            "Export your jkl1... wallet address before running mlvault restore."
        )
    result = _run_helper("download", cid)
    local_path.parent.mkdir(parents=True, exist_ok=True)
    local_path.write_bytes(base64.b64decode(result["data_b64"]))


def remote_key_for(run_id: str) -> str:
    """The storage key for a run's bundle."""
    return f"{run_id}_bundle.enc"


def remote_cid_for(run_id: str) -> str:
    """The full VFS CID for a run's bundle (jackal-helper path)."""
    return f"Home/mlvault/{remote_key_for(run_id)}"
