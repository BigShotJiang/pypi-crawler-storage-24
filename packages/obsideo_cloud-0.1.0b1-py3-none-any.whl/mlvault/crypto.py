"""AES-256-GCM encryption for run bundles."""

import json
import os
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM


KEYS_DIR = Path.home() / ".mlvault" / "keys"


def encrypt_bundle(tar_path: Path, run_id: str) -> Path:
    """Encrypt tar bundle. Returns path to .bundle.enc file."""
    KEYS_DIR.mkdir(parents=True, exist_ok=True)

    key = os.urandom(32)
    nonce = os.urandom(12)
    aesgcm = AESGCM(key)

    plaintext = tar_path.read_bytes()
    ciphertext = aesgcm.encrypt(nonce, plaintext, None)

    key_file = KEYS_DIR / f"{run_id}.key"
    key_file.write_text(json.dumps({"key": key.hex(), "nonce": nonce.hex()}))
    key_file.chmod(0o600)

    enc_path = tar_path.with_suffix("").with_suffix(".bundle.enc")
    # format: [12-byte nonce][ciphertext+tag]
    enc_path.write_bytes(nonce + ciphertext)
    return enc_path


def decrypt_bundle(enc_path: Path, run_id: str) -> bytes:
    """Decrypt a .bundle.enc file. Returns plaintext bytes."""
    key_file = KEYS_DIR / f"{run_id}.key"
    if not key_file.exists():
        raise FileNotFoundError(f"No key found for run '{run_id}' at {key_file}")

    data = json.loads(key_file.read_text())
    key = bytes.fromhex(data["key"])
    nonce = bytes.fromhex(data["nonce"])

    raw = enc_path.read_bytes()
    stored_nonce, ciphertext = raw[:12], raw[12:]

    if stored_nonce != nonce:
        raise ValueError("Nonce mismatch — key file does not match this bundle.")

    aesgcm = AESGCM(key)
    return aesgcm.decrypt(nonce, ciphertext, None)
