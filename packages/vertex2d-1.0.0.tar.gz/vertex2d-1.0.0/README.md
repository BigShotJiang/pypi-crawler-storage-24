
Это простой фреймворк (или движок) для создания графических приложений (игр) на рендере видеокарты.
установка: pip install Vertex

пример максимальн базового кода (версия 1.0.0):
import Vertex # импортируем библиотеку
vertex = Vertex.Build("базовое окно", 600, 400) #создаем окно
def Main():
    Api = vertex.GetFell() #получаем доступ к библиотеке (его Api)
    Api.NewCanvas((75, 75, 75, 255)) #цвет фона
    Api.AllDraw() #теперь рисует все на окно
vertex.NewScene("Main", main.run) #создаем сцену
vertex.SetScene("Main") #устанавливаем сцену
vertex.run() #запускаем
vertex.Destroy() #уничтожаем
