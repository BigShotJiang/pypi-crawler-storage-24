"""Tests DJ CLI"""

import json
import os
import re
import sys
from io import StringIO
from typing import Callable
from unittest import mock
from unittest.mock import patch

import pytest

from datajunction import DJBuilder
from datajunction.cli import main


# Test helper functions
def run_cli_command(builder_client, args, env_vars=None):
    """
    Helper function to run a CLI command and capture output.

    Args:
        builder_client: The DJBuilder client
        args: List of command arguments (e.g., ["dj", "list", "metrics"])
        env_vars: Optional dict of environment variables

    Returns:
        The captured stdout output as a string
    """
    if env_vars is None:
        env_vars = {
            "DJ_USER": "datajunction",
            "DJ_PWD": "datajunction",
        }

    with patch.dict(os.environ, env_vars, clear=False):
        with patch.object(sys, "argv", args):
            with patch("sys.stdout", new_callable=StringIO) as mock_stdout:
                main(builder_client=builder_client)
    return mock_stdout.getvalue()


def assert_in_output(output, *expected_strings):
    """Assert that all expected strings are in the output."""
    for expected in expected_strings:
        assert expected in output, f"Expected '{expected}' not found in output"


def test_pull(
    tmp_path,
    builder_client: DJBuilder,  # pylint: disable=redefined-outer-name
):
    """
    Test `dj pull <namespace> <dir>`
    """
    test_args = ["dj", "pull", "default", tmp_path.absolute().as_posix()]
    env_vars = {
        "DJ_USER": "datajunction",
        "DJ_PWD": "datajunction",
    }
    with patch.dict(os.environ, env_vars, clear=False):
        with patch.object(sys, "argv", test_args):
            main(builder_client=builder_client)
    assert len(os.listdir(tmp_path)) == 30


def test_push_full(
    tmp_path,
    builder_client: DJBuilder,  # pylint: disable=redefined-outer-name
    change_to_project_dir: Callable,
):
    """
    Test `dj push <dir>`
    """
    env_vars = {
        "DJ_USER": "datajunction",
        "DJ_PWD": "datajunction",
    }
    change_to_project_dir("./")
    test_args = ["dj", "push", "./deploy0"]
    with patch(
        "datajunction.deployment.DeploymentService._detect_git_branch",
        return_value=None,
    ):
        with patch.dict(os.environ, env_vars, clear=False):
            with patch.object(sys, "argv", test_args):
                main(builder_client=builder_client)
    results = builder_client.list_nodes(namespace="deps.deploy0")
    assert len(results) == 6

    test_args = ["dj", "push", "./deploy0", "--namespace", "deps.deploy0.main"]
    with patch(
        "datajunction.deployment.DeploymentService._detect_git_branch",
        return_value=None,
    ):
        with patch.dict(os.environ, env_vars, clear=False):
            with patch.object(sys, "argv", test_args):
                main(builder_client=builder_client)

    results = builder_client.list_nodes(namespace="deps.deploy0.main")
    assert len(results) == 6
    results = builder_client.list_nodes(namespace="deps.deploy0")
    assert len(results) == 12


def test_seed():
    """
    Test `dj seed`
    """
    builder_client = mock.MagicMock()

    test_args = ["dj", "seed"]
    with patch.object(sys, "argv", test_args):
        main(builder_client=builder_client)

    func_names = [mock_call[0] for mock_call in builder_client.mock_calls]
    assert "register_table" in func_names
    assert "create_dimension" in func_names
    assert "create_metric" in func_names
    assert "dimension().link_complex_dimension" in func_names


def test_help(builder_client: DJBuilder):  # pylint: disable=redefined-outer-name
    """
    Test the '--help' output.
    """
    test_args = ["dj", "--help"]
    with patch.object(sys, "argv", test_args):
        with patch("sys.stdout", new_callable=StringIO) as mock_stdout:
            with pytest.raises(SystemExit) as excinfo:
                main(builder_client=builder_client)
            assert excinfo.value.code == 0  # Ensure exit code is 0 (success)
    output = mock_stdout.getvalue()
    assert "usage: dj" in output
    assert "deploy" in output
    assert "pull" in output
    assert "delete-node" in output
    assert "delete-namespace" in output


def test_invalid_command(
    builder_client: DJBuilder,  # pylint: disable=redefined-outer-name
):
    """
    Test behavior for an invalid command.
    """
    test_args = ["dj", "invalid_command"]
    with patch.object(sys, "argv", test_args):
        with pytest.raises(SystemExit):
            main(builder_client=builder_client)


@pytest.mark.parametrize(
    "object_type,expected_in_output",
    [
        # dj list metrics
        ("metrics", ["Metrics:", "Total:"]),
        # dj list dimensions
        ("dimensions", ["Dimensions:", "Total:"]),
        # dj list namespaces
        ("namespaces", ["Namespaces:", "default"]),
        # dj list nodes
        ("nodes", ["Nodes:", "Total:"]),
        # dj list cubes
        ("cubes", ["Cubes:", "Total:"]),
        # dj list sources
        ("sources", ["Sources:", "Total:"]),
        # dj list transforms
        ("transforms", ["Transforms:", "Total:"]),
    ],
)
def test_list_objects(
    builder_client: DJBuilder,
    object_type: str,
    expected_in_output: list,
):
    """
    Test `dj list <type>` for various object types.
    """
    output = run_cli_command(builder_client, ["dj", "list", object_type])
    assert_in_output(output, *expected_in_output)


@pytest.mark.parametrize(
    "object_type,expected_in_output",
    [
        # dj list metrics
        ("metrics", ["ERROR: node namespace `na` does not exist"]),
        # dj list dimensions
        ("dimensions", ["ERROR: node namespace `na` does not exist"]),
        # # dj list namespaces
        ("namespaces", ["No namespaces found in `na`"]),
        # dj list nodes
        ("nodes", ["ERROR: node namespace `na` does not exist"]),
        # dj list cubes
        ("cubes", ["ERROR: node namespace `na` does not exist"]),
        # dj list sources
        ("sources", ["ERROR: node namespace `na` does not exist"]),
        # dj list transforms
        ("transforms", ["ERROR: node namespace `na` does not exist"]),
    ],
)
def test_list_objects_none(
    builder_client: DJBuilder,
    object_type: str,
    expected_in_output: list,
):
    """
    Test `dj list <type>` for various object types.
    """
    output = run_cli_command(
        builder_client,
        ["dj", "list", object_type, "--namespace", "na"],
    )
    assert_in_output(output, *expected_in_output)


def test_list_json(builder_client: DJBuilder):  # pylint: disable=redefined-outer-name
    """
    Test `dj list metrics --format json`
    """
    output = run_cli_command(
        builder_client,
        ["dj", "list", "metrics", "--format", "json"],
    )
    data = json.loads(output)
    assert isinstance(data, list)


@pytest.mark.parametrize(
    "command,node_name,expected_in_output",
    [
        ("sql", "default.num_repair_orders", ["SELECT"]),
        (
            "lineage",
            "default.num_repair_orders",
            ["Lineage for:", "Upstream dependencies", "Downstream dependencies"],
        ),
        ("dimensions", "default.num_repair_orders", ["Available dimensions for:"]),
    ],
)
def test_node_commands(
    builder_client: DJBuilder,
    command: str,
    node_name: str,
    expected_in_output: list,
):  # pylint: disable=redefined-outer-name
    """
    Test various node-specific commands (sql, lineage, dimensions).
    """
    output = run_cli_command(builder_client, ["dj", command, node_name])
    assert_in_output(output, *expected_in_output)


@pytest.mark.parametrize(
    "command,node_name,format_type",
    [
        # dj lineage default.num_repair_orders --format json
        ("lineage", "default.num_repair_orders", "json"),
        # dj dimensions default.num_repair_orders --format json
        ("dimensions", "default.num_repair_orders", "json"),
        # dj describe default.num_repair_orders --format json
        ("describe", "default.num_repair_orders", "json"),
    ],
)
def test_json_output_commands(
    builder_client: DJBuilder,
    command: str,
    node_name: str,
    format_type: str,
):  # pylint: disable=redefined-outer-name
    """
    Test JSON output format for various commands.
    """
    output = run_cli_command(
        builder_client,
        ["dj", command, node_name, "--format", format_type],
    )
    data = json.loads(output)
    assert isinstance(data, (dict, list))


@pytest.mark.parametrize(
    "node_name,expected_in_output",
    [
        (
            "default.repair_orders",
            [
                "Node: default.repair_orders",
                "Type:",
                "Description:",
                "Status:",
                "Mode:",
                "Display Name:",
                "Columns:",
            ],
        ),
        (
            "default.repair_orders_thin",
            [
                "Node: default.repair_orders_thin",
                "Type:",
                "Description:",
                "Status:",
                "Mode:",
                "Display Name:",
                "Columns:",
            ],
        ),
        (
            "default.hard_hat",
            [
                "Node: default.hard_hat",
                "Type:",
                "Description:",
                "Status:",
                "Mode:",
                "Display Name:",
                "Columns:",
                "Primary Key:",
            ],
        ),
        (
            "default.num_repair_orders",
            [
                "Node: default.num_repair_orders",
                "Type:",
                "Description:",
                "Status:",
                "Mode:",
                "Display Name:",
                "Version:",
            ],
        ),
        (
            "default.cube_two",
            [
                "Node: default.cube_two",
                "Type:",
                "Description:",
                "Metrics:",
                "Dimensions:",
            ],
        ),
        ("default.none", ["ERROR: No node with name default.none exists"]),
    ],
)
def test_describe(builder_client: DJBuilder, node_name: str, expected_in_output: list):  # pylint: disable=redefined-outer-name
    """
    Test `dj describe <node-name>` for various node types.
    """
    output = run_cli_command(builder_client, ["dj", "describe", node_name])
    assert_in_output(output, *expected_in_output)


def test_list_metrics(builder_client: DJBuilder):  # pylint: disable=redefined-outer-name
    """
    Test `dj list metrics`
    """
    env_vars = {
        "DJ_USER": "datajunction",
        "DJ_PWD": "datajunction",
    }
    test_args = ["dj", "list", "metrics"]
    with patch.dict(os.environ, env_vars, clear=False):
        with patch.object(sys, "argv", test_args):
            with patch("sys.stdout", new_callable=StringIO) as mock_stdout:
                main(builder_client=builder_client)
    output = mock_stdout.getvalue()
    assert "Metrics:" in output
    assert "Total:" in output


def test_list_namespaces(builder_client: DJBuilder):  # pylint: disable=redefined-outer-name
    """
    Test `dj list namespaces`
    """
    env_vars = {
        "DJ_USER": "datajunction",
        "DJ_PWD": "datajunction",
    }
    test_args = ["dj", "list", "namespaces"]
    with patch.dict(os.environ, env_vars, clear=False):
        with patch.object(sys, "argv", test_args):
            with patch("sys.stdout", new_callable=StringIO) as mock_stdout:
                main(builder_client=builder_client)
    output = mock_stdout.getvalue()
    assert "Namespaces:" in output
    assert "default" in output


def test_sql(builder_client: DJBuilder):  # pylint: disable=redefined-outer-name
    """
    Test `dj sql <node-name>`
    """
    env_vars = {
        "DJ_USER": "datajunction",
        "DJ_PWD": "datajunction",
    }
    test_args = ["dj", "sql", "default.num_repair_orders"]
    with patch.dict(os.environ, env_vars, clear=False):
        with patch.object(sys, "argv", test_args):
            with patch("sys.stdout", new_callable=StringIO) as mock_stdout:
                main(builder_client=builder_client)
    output = mock_stdout.getvalue()
    assert "SELECT" in output.upper()


def test_sql_with_dimensions(builder_client: DJBuilder):  # pylint: disable=redefined-outer-name
    """
    Test `dj sql <node-name> --dimensions dim1,dim2`
    """
    env_vars = {
        "DJ_USER": "datajunction",
        "DJ_PWD": "datajunction",
    }
    test_args = [
        "dj",
        "sql",
        "default.num_repair_orders",
        "--dimensions",
        "default.hard_hat.city",
    ]
    with patch.dict(os.environ, env_vars, clear=False):
        with patch.object(sys, "argv", test_args):
            with patch("sys.stdout", new_callable=StringIO) as mock_stdout:
                main(builder_client=builder_client)
    output = mock_stdout.getvalue()
    assert "SELECT" in output.upper()


def test_sql_with_metrics(builder_client: DJBuilder):  # pylint: disable=redefined-outer-name
    """
    Test `dj sql --metrics m1 m2` using v3 API
    """
    # Use metrics from the same parent node, or add a shared dimension
    output = run_cli_command(
        builder_client,
        [
            "dj",
            "sql",
            "--metrics",
            "default.num_repair_orders",
            "default.avg_repair_price",
            "--dimensions",
            "default.hard_hat.city",
        ],
    )
    assert "SELECT" in output.upper()


def test_sql_with_metrics_and_dimensions(
    builder_client: DJBuilder,
):  # pylint: disable=redefined-outer-name
    """
    Test `dj sql --metrics m1 --dimensions d1` using v3 API
    """
    output = run_cli_command(
        builder_client,
        [
            "dj",
            "sql",
            "--metrics",
            "default.num_repair_orders",
            "--dimensions",
            "default.hard_hat.city",
            "--filters",
            "default.hard_hat.state = 'NY'",
        ],
    )
    assert "SELECT" in output.upper()


def test_sql_no_node_or_metrics(builder_client: DJBuilder):  # pylint: disable=redefined-outer-name
    """
    Test `dj sql` without node_name or --metrics shows error
    """
    output = run_cli_command(builder_client, ["dj", "sql"])
    assert "ERROR" in output


def test_sql_with_error_response(builder_client: DJBuilder, capsys):
    """
    Test `dj sql` handles error responses from API
    """
    error_response = {"message": "Test error message from API"}
    with patch.object(builder_client, "sql", return_value=error_response):
        test_args = ["dj", "sql", "--metrics", "some.metric"]
        with patch.dict(
            os.environ,
            {"DJ_USER": "datajunction", "DJ_PWD": "datajunction"},
            clear=False,
        ):
            with patch.object(sys, "argv", test_args):
                main(builder_client=builder_client)

    captured = capsys.readouterr()
    assert "ERROR" in captured.out
    assert "Test error message from API" in captured.out


def test_lineage(builder_client: DJBuilder):  # pylint: disable=redefined-outer-name
    """
    Test `dj lineage <node-name>`
    """
    output = run_cli_command(
        builder_client,
        ["dj", "lineage", "default.num_repair_orders"],
    )
    assert "Lineage for:" in output
    assert "Upstream dependencies" in output
    assert "Downstream dependencies" in output

    output = run_cli_command(
        builder_client,
        ["dj", "lineage", "default.num_repair_orders", "--direction", "upstream"],
    )
    assert "Lineage for:" in output
    assert "Upstream dependencies" in output

    output = run_cli_command(
        builder_client,
        ["dj", "lineage", "default.num_repair_orders", "--direction", "downstream"],
    )
    assert "Lineage for:" in output
    assert "Downstream dependencies" in output

    # cube nodes will have no downstreams
    output = run_cli_command(
        builder_client,
        ["dj", "lineage", "default.cube_two", "--direction", "downstream"],
    )
    assert "(none)" in output

    # source nodes will have no upstreams
    output = run_cli_command(
        builder_client,
        ["dj", "lineage", "default.repair_orders", "--direction", "upstream"],
    )
    assert "(none)" in output


def test_lineage_upstream(builder_client: DJBuilder):  # pylint: disable=redefined-outer-name
    """
    Test `dj lineage <node-name> --direction upstream`
    """
    env_vars = {
        "DJ_USER": "datajunction",
        "DJ_PWD": "datajunction",
    }
    test_args = [
        "dj",
        "lineage",
        "default.num_repair_orders",
        "--direction",
        "upstream",
    ]
    with patch.dict(os.environ, env_vars, clear=False):
        with patch.object(sys, "argv", test_args):
            with patch("sys.stdout", new_callable=StringIO) as mock_stdout:
                main(builder_client=builder_client)
    output = mock_stdout.getvalue()
    assert "Lineage for:" in output
    assert "Upstream dependencies" in output


def test_lineage_json(builder_client: DJBuilder):  # pylint: disable=redefined-outer-name
    """
    Test `dj lineage <node-name> --format json`
    """
    env_vars = {
        "DJ_USER": "datajunction",
        "DJ_PWD": "datajunction",
    }
    test_args = ["dj", "lineage", "default.num_repair_orders", "--format", "json"]
    with patch.dict(os.environ, env_vars, clear=False):
        with patch.object(sys, "argv", test_args):
            with patch("sys.stdout", new_callable=StringIO) as mock_stdout:
                main(builder_client=builder_client)
    output = mock_stdout.getvalue()
    import json

    data = json.loads(output)
    assert "node" in data
    assert "upstream" in data
    assert "downstream" in data


def test_dimensions(builder_client: DJBuilder):  # pylint: disable=redefined-outer-name
    """
    Test `dj dimensions <node-name>`
    """
    output = run_cli_command(
        builder_client,
        ["dj", "dimensions", "default.num_repair_orders"],
    )
    assert "Available dimensions for:" in output
    output = run_cli_command(builder_client, ["dj", "dimensions", "default.hard_hats"])
    assert "No dimensions available" in output


def test_dimensions_json(builder_client: DJBuilder):  # pylint: disable=redefined-outer-name
    """
    Test `dj dimensions <node-name> --format json`
    """
    output = run_cli_command(
        builder_client,
        ["dj", "dimensions", "default.num_repair_orders", "--format", "json"],
    )
    data = json.loads(output)
    assert isinstance(data, list)


def test_data_with_metrics(builder_client: DJBuilder):  # pylint: disable=redefined-outer-name
    """
    Test `dj data --metrics <metric> --dimensions <dim>`
    """
    output = run_cli_command(
        builder_client,
        [
            "dj",
            "data",
            "--metrics",
            "default.avg_repair_price",
            "--dimensions",
            "default.hard_hat.city",
        ],
    )
    # Should show table output with data
    assert "default.hard_hat.city" in output or "city" in output.lower()
    assert "row" in output.lower()  # Should show row count


def test_data_with_node(builder_client: DJBuilder):  # pylint: disable=redefined-outer-name
    """
    Test `dj data <node-name> --dimensions <dim>`
    """
    output = run_cli_command(
        builder_client,
        [
            "dj",
            "data",
            "default.avg_repair_price",
            "--dimensions",
            "default.hard_hat.city",
        ],
    )
    # Should show table output with data
    assert "row" in output.lower()  # Should show row count


def test_data_json_format(builder_client: DJBuilder):  # pylint: disable=redefined-outer-name
    """
    Test `dj data --metrics <metric> --format json`
    """
    output = run_cli_command(
        builder_client,
        [
            "dj",
            "data",
            "--metrics",
            "default.avg_repair_price",
            "--dimensions",
            "default.hard_hat.city",
            "--format",
            "json",
        ],
    )
    # Strip ANSI escape codes
    ansi_escape = re.compile(r"\x1b\[[0-9;]*[a-zA-Z]|\x1b\][^\x07]*\x07|\r")
    clean_output = ansi_escape.sub("", output)
    # Find the JSON array in the output (may have progress messages before it)
    json_start = clean_output.find("[\n")
    json_end = clean_output.rfind("]") + 1
    json_str = clean_output[json_start:json_end]
    data = json.loads(json_str)
    assert isinstance(data, list)


def test_data_csv_format(builder_client: DJBuilder):  # pylint: disable=redefined-outer-name
    """
    Test `dj data --metrics <metric> --format csv`
    """
    output = run_cli_command(
        builder_client,
        [
            "dj",
            "data",
            "--metrics",
            "default.avg_repair_price",
            "--dimensions",
            "default.hard_hat.city",
            "--format",
            "csv",
        ],
    )
    # Should be CSV format with header
    lines = output.strip().split("\n")
    assert len(lines) >= 2  # Header + at least one data row


def test_data_no_args(builder_client: DJBuilder, capsys):  # pylint: disable=redefined-outer-name
    """
    Test `dj data` with no arguments shows error
    """
    output = run_cli_command(
        builder_client,
        ["dj", "data"],
    )
    assert "ERROR" in output


def test_data_with_error_response(builder_client: DJBuilder, capsys):
    """
    Test `dj data` handles error responses from API (covers lines 805-807)
    """
    error_response = {"message": "Test error message from data API"}
    with patch.object(builder_client, "data", return_value=error_response):
        test_args = ["dj", "data", "--metrics", "some.metric"]
        with patch.dict(
            os.environ,
            {"DJ_USER": "datajunction", "DJ_PWD": "datajunction"},
            clear=False,
        ):
            with patch.object(sys, "argv", test_args):
                main(builder_client=builder_client)

    captured = capsys.readouterr()
    assert "ERROR" in captured.out
    assert "Test error message from data API" in captured.out


def test_data_with_limit(builder_client: DJBuilder):  # pylint: disable=redefined-outer-name
    """
    Test `dj data` with explicit --limit flag (covers effective_limit usage)
    """
    output = run_cli_command(
        builder_client,
        [
            "dj",
            "data",
            "--metrics",
            "default.avg_repair_price",
            "--dimensions",
            "default.hard_hat.city",
            "--limit",
            "5",
        ],
    )
    # Should show results and row count
    assert "row" in output.lower()


def test_data_shows_limit_message_when_results_equal_limit(
    builder_client: DJBuilder,
    capsys,
):
    """
    Test that `dj data` shows limit message when results match the limit (covers lines 828-832)
    """
    # Create a mock DataFrame-like object with exactly 5 rows (matching the limit)
    mock_df = mock.MagicMock()
    mock_df.columns = ["metric", "dimension"]
    mock_df.__len__ = mock.MagicMock(return_value=5)
    mock_df.iterrows = mock.MagicMock(
        return_value=iter(
            [
                (0, mock.MagicMock(values=[1, "a"])),
                (1, mock.MagicMock(values=[2, "b"])),
                (2, mock.MagicMock(values=[3, "c"])),
                (3, mock.MagicMock(values=[4, "d"])),
                (4, mock.MagicMock(values=[5, "e"])),
            ],
        ),
    )

    with patch.object(builder_client, "data", return_value=mock_df):
        test_args = [
            "dj",
            "data",
            "--metrics",
            "some.metric",
            "--dimensions",
            "some.dimension",
            "--limit",
            "5",
        ]
        with patch.dict(
            os.environ,
            {"DJ_USER": "datajunction", "DJ_PWD": "datajunction"},
            clear=False,
        ):
            with patch.object(sys, "argv", test_args):
                main(builder_client=builder_client)

    captured = capsys.readouterr()
    # Should show the limit message since results == limit
    assert "limit: 5" in captured.out


def test_data_with_default_limit():
    """
    Test that `dj data` uses default limit of 1000 when not specified
    """
    mock_builder = mock.MagicMock()
    mock_builder.data = mock.MagicMock(return_value={"message": "test"})

    test_args = [
        "dj",
        "data",
        "--metrics",
        "some.metric",
    ]
    with patch.dict(
        os.environ,
        {"DJ_USER": "datajunction", "DJ_PWD": "datajunction"},
        clear=False,
    ):
        with patch.object(sys, "argv", test_args):
            main(builder_client=mock_builder)

    # Verify data was called with limit=1000 (the default)
    mock_builder.data.assert_called_once()
    call_kwargs = mock_builder.data.call_args[1]
    assert call_kwargs.get("limit") == 1000


def test_delete_node(
    builder_client: DJBuilder,  # pylint: disable=redefined-outer-name
):
    """
    Test `dj delete-node <node_name>`
    """
    env_vars = {
        "DJ_USER": "datajunction",
        "DJ_PWD": "datajunction",
    }

    # Mock the delete_node method
    with patch.object(builder_client, "delete_node") as mock_delete:
        test_args = ["dj", "delete-node", "default.repair_orders"]
        with patch.dict(os.environ, env_vars, clear=False):
            with patch.object(sys, "argv", test_args):
                main(builder_client=builder_client)

        # Verify the node was called with soft delete
        mock_delete.assert_called_once_with("default.repair_orders", hard=False)


def test_delete_node_hard(
    builder_client: DJBuilder,  # pylint: disable=redefined-outer-name
):
    """
    Test `dj delete-node <node_name> --hard`
    """
    env_vars = {
        "DJ_USER": "datajunction",
        "DJ_PWD": "datajunction",
    }

    # Mock the delete_node method
    with patch.object(builder_client, "delete_node") as mock_delete:
        test_args = ["dj", "delete-node", "default.repair_orders", "--hard"]
        with patch.dict(os.environ, env_vars, clear=False):
            with patch.object(sys, "argv", test_args):
                main(builder_client=builder_client)

        # Verify the node was called with hard delete
        mock_delete.assert_called_once_with("default.repair_orders", hard=True)


def test_delete_namespace(
    builder_client: DJBuilder,  # pylint: disable=redefined-outer-name
):
    """
    Test `dj delete-namespace <namespace>`
    """
    env_vars = {
        "DJ_USER": "datajunction",
        "DJ_PWD": "datajunction",
    }

    # Mock the delete_namespace method
    with patch.object(builder_client, "delete_namespace") as mock_delete:
        test_args = ["dj", "delete-namespace", "test_namespace"]
        with patch.dict(os.environ, env_vars, clear=False):
            with patch.object(sys, "argv", test_args):
                main(builder_client=builder_client)

        # Verify the namespace was called with correct parameters
        mock_delete.assert_called_once_with(
            "test_namespace",
            cascade=False,
            hard=False,
        )


def test_delete_namespace_cascade(
    builder_client: DJBuilder,  # pylint: disable=redefined-outer-name
):
    """
    Test `dj delete-namespace <namespace> --cascade`
    """
    env_vars = {
        "DJ_USER": "datajunction",
        "DJ_PWD": "datajunction",
    }

    # Mock the delete_namespace method
    with patch.object(builder_client, "delete_namespace") as mock_delete:
        test_args = ["dj", "delete-namespace", "test_namespace", "--cascade"]
        with patch.dict(os.environ, env_vars, clear=False):
            with patch.object(sys, "argv", test_args):
                main(builder_client=builder_client)

        # Verify the namespace was called with cascade
        mock_delete.assert_called_once_with(
            "test_namespace",
            cascade=True,
            hard=False,
        )


def test_delete_namespace_hard(
    builder_client: DJBuilder,  # pylint: disable=redefined-outer-name
):
    """
    Test `dj delete-namespace <namespace> --hard`
    """
    env_vars = {
        "DJ_USER": "datajunction",
        "DJ_PWD": "datajunction",
    }

    # Mock the delete_namespace method
    with patch.object(builder_client, "delete_namespace") as mock_delete:
        test_args = ["dj", "delete-namespace", "test_namespace", "--hard"]
        with patch.dict(os.environ, env_vars, clear=False):
            with patch.object(sys, "argv", test_args):
                main(builder_client=builder_client)

        # Verify the namespace was called with hard delete
        mock_delete.assert_called_once_with(
            "test_namespace",
            cascade=False,
            hard=True,
        )


def test_delete_namespace_cascade_hard(
    builder_client: DJBuilder,  # pylint: disable=redefined-outer-name
):
    """
    Test `dj delete-namespace <namespace> --cascade --hard`
    """
    env_vars = {
        "DJ_USER": "datajunction",
        "DJ_PWD": "datajunction",
    }

    # Mock the delete_namespace method
    with patch.object(builder_client, "delete_namespace") as mock_delete:
        test_args = ["dj", "delete-namespace", "test_namespace", "--cascade", "--hard"]
        with patch.dict(os.environ, env_vars, clear=False):
            with patch.object(sys, "argv", test_args):
                main(builder_client=builder_client)

        # Verify the namespace was called with both cascade and hard delete
        mock_delete.assert_called_once_with(
            "test_namespace",
            cascade=True,
            hard=True,
        )


class TestPushDeploymentSourceFlags:
    """Tests for the deployment source CLI flags on push command."""

    def test_push_help_shows_source_flags(self, builder_client: DJBuilder):
        """Test that --help shows the new deployment source flags."""
        test_args = ["dj", "push", "--help"]
        with patch.object(sys, "argv", test_args):
            with patch("sys.stdout", new_callable=StringIO) as mock_stdout:
                with pytest.raises(SystemExit) as excinfo:
                    main(builder_client=builder_client)
                assert excinfo.value.code == 0
        output = mock_stdout.getvalue()
        assert "--repo" in output
        assert "--branch" in output
        assert "--commit" in output
        assert "--ci-system" in output
        assert "--ci-run-url" in output

    def test_push_with_repo_flag_sets_env_var(
        self,
        builder_client: DJBuilder,
        change_to_project_dir,
    ):
        """Test that --repo flag sets DJ_DEPLOY_REPO env var."""
        change_to_project_dir("./")

        env_vars = {
            "DJ_USER": "datajunction",
            "DJ_PWD": "datajunction",
        }
        test_args = [
            "dj",
            "push",
            "./deploy0",
            "--repo",
            "github.com/test/repo",
        ]

        with patch.dict(os.environ, env_vars, clear=False):
            with patch.object(sys, "argv", test_args):
                main(builder_client=builder_client)
            # Verify env var was set (check inside the patch.dict context)
            assert os.environ.get("DJ_DEPLOY_REPO") == "github.com/test/repo"

    def test_push_with_all_source_flags_sets_env_vars(
        self,
        builder_client: DJBuilder,
        change_to_project_dir,
    ):
        """Test that all source flags set corresponding env vars."""
        change_to_project_dir("./")

        env_vars = {
            "DJ_USER": "datajunction",
            "DJ_PWD": "datajunction",
        }
        test_args = [
            "dj",
            "push",
            "./deploy0",
            "--namespace",
            "source_flags_test",
            "--repo",
            "github.com/org/repo",
            "--branch",
            "main",
            "--commit",
            "abc123def",
            "--ci-system",
            "jenkins",
            "--ci-run-url",
            "https://jenkins.example.com/job/123",
        ]

        with patch.dict(os.environ, env_vars, clear=False):
            with patch.object(sys, "argv", test_args):
                main(builder_client=builder_client)
            # Verify all env vars were set (check inside the patch.dict context)
            assert os.environ.get("DJ_DEPLOY_REPO") == "github.com/org/repo"
            assert os.environ.get("DJ_DEPLOY_BRANCH") == "main"
            assert os.environ.get("DJ_DEPLOY_COMMIT") == "abc123def"
            assert os.environ.get("DJ_DEPLOY_CI_SYSTEM") == "jenkins"
            assert (
                os.environ.get("DJ_DEPLOY_CI_RUN_URL")
                == "https://jenkins.example.com/job/123"
            )

    def test_push_flags_override_existing_env_vars(
        self,
        builder_client: DJBuilder,
        change_to_project_dir,
    ):
        """Test that CLI flags override existing env vars."""
        change_to_project_dir("./")

        env_vars = {
            "DJ_USER": "datajunction",
            "DJ_PWD": "datajunction",
            "DJ_DEPLOY_REPO": "old-repo",
            "DJ_DEPLOY_BRANCH": "old-branch",
        }
        test_args = [
            "dj",
            "push",
            "./deploy0",
            "--namespace",
            "override_test",
            "--repo",
            "new-repo",
            "--branch",
            "new-branch",
        ]

        with patch.dict(os.environ, env_vars, clear=False):
            with patch.object(sys, "argv", test_args):
                main(builder_client=builder_client)
            # CLI flags should override (check inside the patch.dict context)
            assert os.environ.get("DJ_DEPLOY_REPO") == "new-repo"
            assert os.environ.get("DJ_DEPLOY_BRANCH") == "new-branch"

    def test_push_without_flags_uses_existing_env_vars(
        self,
        builder_client: DJBuilder,
        change_to_project_dir,
    ):
        """Test that push without flags respects existing env vars."""
        change_to_project_dir("./")

        env_vars = {
            "DJ_USER": "datajunction",
            "DJ_PWD": "datajunction",
            "DJ_DEPLOY_REPO": "existing-repo",
            "DJ_DEPLOY_BRANCH": "existing-branch",
        }
        test_args = ["dj", "push", "./deploy0", "--namespace", "existing_env_test"]

        with patch.dict(os.environ, env_vars, clear=False):
            with patch.object(sys, "argv", test_args):
                main(builder_client=builder_client)
            # Existing env vars should remain unchanged (check inside the patch.dict context)
            assert os.environ.get("DJ_DEPLOY_REPO") == "existing-repo"
            assert os.environ.get("DJ_DEPLOY_BRANCH") == "existing-branch"


class TestImpactAnalysis:
    """Tests for deployment impact analysis (dryrun)."""

    def test_deploy_dryrun_shows_impact(
        self,
        builder_client: DJBuilder,
        change_to_project_dir,
        capsys,
    ):
        """Test that deploy --dryrun shows impact analysis."""
        change_to_project_dir("./")

        # Use a unique namespace for this test
        test_args = ["dj", "deploy", "./deploy0", "--dryrun"]

        with patch.dict(
            os.environ,
            {"DJ_USER": "datajunction", "DJ_PWD": "datajunction"},
            clear=False,
        ):
            with patch.object(sys, "argv", test_args):
                main(builder_client=builder_client)

        # Check output contains impact analysis elements
        captured = capsys.readouterr()
        assert "Impact Analysis" in captured.out
        assert "Direct Changes" in captured.out

    def test_deploy_dryrun_json_format(
        self,
        builder_client: DJBuilder,
        change_to_project_dir,
        capsys,
    ):
        """Test that deploy --dryrun --format json outputs JSON."""
        change_to_project_dir("./")

        test_args = ["dj", "deploy", "./deploy0", "--dryrun", "--format", "json"]

        with patch.dict(
            os.environ,
            {"DJ_USER": "datajunction", "DJ_PWD": "datajunction"},
            clear=False,
        ):
            with patch.object(sys, "argv", test_args):
                main(builder_client=builder_client)

        captured = capsys.readouterr()
        # Should be valid JSON
        import json as json_module

        impact_data = json_module.loads(captured.out)
        assert "namespace" in impact_data
        assert "changes" in impact_data
        assert "create_count" in impact_data

    def test_push_dryrun_shows_impact(
        self,
        builder_client: DJBuilder,
        change_to_project_dir,
        capsys,
    ):
        """Test that push --dryrun shows impact analysis."""
        change_to_project_dir("./")

        # Use push command with --dryrun flag
        test_args = ["dj", "push", "./deploy0", "--dryrun"]

        with patch.dict(
            os.environ,
            {"DJ_USER": "datajunction", "DJ_PWD": "datajunction"},
            clear=False,
        ):
            with patch.object(sys, "argv", test_args):
                main(builder_client=builder_client)

        # Check output contains impact analysis elements
        captured = capsys.readouterr()
        assert "Impact Analysis" in captured.out
        assert "Direct Changes" in captured.out

    def test_push_dryrun_json_format(
        self,
        builder_client: DJBuilder,
        change_to_project_dir,
        capsys,
    ):
        """Test that push --dryrun --format json outputs JSON."""
        change_to_project_dir("./")

        test_args = ["dj", "push", "./deploy0", "--dryrun", "--format", "json"]

        with patch.dict(
            os.environ,
            {"DJ_USER": "datajunction", "DJ_PWD": "datajunction"},
            clear=False,
        ):
            with patch.object(sys, "argv", test_args):
                main(builder_client=builder_client)

        captured = capsys.readouterr()
        # Should be valid JSON
        import json as json_module

        impact_data = json_module.loads(captured.out)
        assert "namespace" in impact_data
        assert "changes" in impact_data
        assert "create_count" in impact_data

    def test_push_dryrun_with_namespace(
        self,
        builder_client: DJBuilder,
        change_to_project_dir,
        capsys,
    ):
        """Test that push --dryrun --namespace passes namespace to dryrun."""
        change_to_project_dir("./")

        # Use push command with --dryrun and --namespace flags
        test_args = [
            "dj",
            "push",
            "./deploy0",
            "--dryrun",
            "--namespace",
            "custom.namespace",
        ]

        with patch.dict(
            os.environ,
            {"DJ_USER": "datajunction", "DJ_PWD": "datajunction"},
            clear=False,
        ):
            with patch.object(sys, "argv", test_args):
                main(builder_client=builder_client)

        # Check output contains impact analysis (namespace is passed through)
        captured = capsys.readouterr()
        assert "Impact Analysis" in captured.out

    def test_display_impact_analysis_with_changes(self, capsys):
        """Test display_impact_analysis function with various changes."""
        from datajunction.cli import display_impact_analysis
        from rich.console import Console

        console = Console(force_terminal=True, no_color=True)

        impact = {
            "namespace": "test.namespace",
            "changes": [
                {
                    "name": "test.namespace.new_metric",
                    "operation": "create",
                    "node_type": "metric",
                    "changed_fields": [],
                },
                {
                    "name": "test.namespace.updated_transform",
                    "operation": "update",
                    "node_type": "transform",
                    "changed_fields": ["query", "description"],
                },
                {
                    "name": "test.namespace.unchanged_source",
                    "operation": "noop",
                    "node_type": "source",
                    "changed_fields": [],
                },
            ],
            "create_count": 1,
            "update_count": 1,
            "delete_count": 0,
            "skip_count": 1,
            "downstream_impacts": [
                {
                    "name": "other.namespace.downstream_node",
                    "node_type": "metric",
                    "current_status": "valid",
                    "predicted_status": "valid",
                    "impact_type": "may_affect",
                    "impact_reason": "Depends on test.namespace.updated_transform",
                    "depth": 1,
                    "caused_by": ["test.namespace.updated_transform"],
                },
            ],
            "will_invalidate_count": 0,
            "may_affect_count": 1,
            "warnings": [],
        }

        display_impact_analysis(impact, console=console)

        captured = capsys.readouterr()
        assert "test.namespace" in captured.out
        assert "Create" in captured.out
        assert "Update" in captured.out
        assert "Skip" in captured.out
        assert "May Affect" in captured.out
        assert "Ready to deploy" in captured.out

    def test_display_impact_analysis_with_warnings(self, capsys):
        """Test display_impact_analysis shows warnings."""
        from datajunction.cli import display_impact_analysis
        from rich.console import Console

        console = Console(force_terminal=True, no_color=True)

        impact = {
            "namespace": "test.namespace",
            "changes": [
                {
                    "name": "test.namespace.source_with_column_change",
                    "operation": "update",
                    "node_type": "source",
                    "changed_fields": ["columns"],
                    "column_changes": [
                        {
                            "column": "old_col",
                            "change_type": "removed",
                        },
                    ],
                },
            ],
            "create_count": 0,
            "update_count": 1,
            "delete_count": 0,
            "skip_count": 0,
            "downstream_impacts": [
                {
                    "name": "other.downstream",
                    "node_type": "transform",
                    "current_status": "valid",
                    "predicted_status": "invalid",
                    "impact_type": "will_invalidate",
                    "impact_reason": "Uses removed column 'old_col'",
                    "depth": 1,
                    "caused_by": ["test.namespace.source_with_column_change"],
                },
            ],
            "will_invalidate_count": 1,
            "may_affect_count": 0,
            "warnings": [
                "Breaking change: Column 'old_col' removed from test.namespace.source_with_column_change",
            ],
        }

        display_impact_analysis(impact, console=console)

        captured = capsys.readouterr()
        assert "Column Changes" in captured.out
        assert "Removed" in captured.out
        assert "Will Invalidate" in captured.out
        assert "Breaking change" in captured.out
        assert "Review the warnings" in captured.out

    def test_display_impact_analysis_no_changes(self, capsys):
        """Test display_impact_analysis with empty deployment."""
        from datajunction.cli import display_impact_analysis
        from rich.console import Console

        console = Console(force_terminal=True, no_color=True)

        impact = {
            "namespace": "empty.namespace",
            "changes": [],
            "create_count": 0,
            "update_count": 0,
            "delete_count": 0,
            "skip_count": 0,
            "downstream_impacts": [],
            "will_invalidate_count": 0,
            "may_affect_count": 0,
            "warnings": [],
        }

        display_impact_analysis(impact, console=console)

        captured = capsys.readouterr()
        assert "empty.namespace" in captured.out
        assert "No downstream impact" in captured.out
        assert "No warnings" in captured.out
        assert "Ready to deploy" in captured.out

    def test_display_impact_analysis_with_delete_count(self, capsys):
        """Test display_impact_analysis shows delete count in summary (covers line 92)."""
        from datajunction.cli import display_impact_analysis
        from rich.console import Console
        import re

        console = Console(force_terminal=True, no_color=True)

        impact = {
            "namespace": "test.namespace",
            "changes": [
                {
                    "name": "test.namespace.deleted_node",
                    "operation": "delete",
                    "node_type": "transform",
                    "changed_fields": [],
                },
            ],
            "create_count": 0,
            "update_count": 0,
            "delete_count": 1,
            "skip_count": 0,
            "downstream_impacts": [],
            "will_invalidate_count": 0,
            "may_affect_count": 0,
            "warnings": [],
        }

        display_impact_analysis(impact, console=console)

        captured = capsys.readouterr()
        # Strip ANSI codes for assertion
        ansi_escape = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")
        clean_output = ansi_escape.sub("", captured.out)
        assert "1 delete" in clean_output

    def test_display_impact_analysis_with_type_changed_column(self, capsys):
        """Test display_impact_analysis shows type_changed column details (covers line 138)."""
        from datajunction.cli import display_impact_analysis
        from rich.console import Console
        import re

        console = Console(force_terminal=True, no_color=True)

        impact = {
            "namespace": "test.namespace",
            "changes": [
                {
                    "name": "test.namespace.source_node",
                    "operation": "update",
                    "node_type": "source",
                    "changed_fields": ["columns"],
                    "column_changes": [
                        {
                            "column": "user_id",
                            "change_type": "type_changed",
                            "old_type": "INT",
                            "new_type": "BIGINT",
                        },
                    ],
                },
            ],
            "create_count": 0,
            "update_count": 1,
            "delete_count": 0,
            "skip_count": 0,
            "downstream_impacts": [],
            "will_invalidate_count": 0,
            "may_affect_count": 0,
            "warnings": [],
        }

        display_impact_analysis(impact, console=console)

        captured = capsys.readouterr()
        # Strip ANSI codes for assertion
        ansi_escape = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")
        clean_output = ansi_escape.sub("", captured.out)
        assert "Column Changes" in clean_output
        # "Type Changed" may be split across lines in the table, check for both parts
        assert "Type" in clean_output
        assert "Changed" in clean_output
        assert "user_id" in clean_output
        assert "INT" in clean_output
        assert "BIGINT" in clean_output

    def test_display_impact_analysis_with_added_column(self, capsys):
        """Test display_impact_analysis shows added column details (covers line 142)."""
        from datajunction.cli import display_impact_analysis
        from rich.console import Console
        import re

        console = Console(force_terminal=True, no_color=True)

        impact = {
            "namespace": "test.namespace",
            "changes": [
                {
                    "name": "test.namespace.source_node",
                    "operation": "update",
                    "node_type": "source",
                    "changed_fields": ["columns"],
                    "column_changes": [
                        {
                            "column": "new_column",
                            "change_type": "added",
                        },
                    ],
                },
            ],
            "create_count": 0,
            "update_count": 1,
            "delete_count": 0,
            "skip_count": 0,
            "downstream_impacts": [],
            "will_invalidate_count": 0,
            "may_affect_count": 0,
            "warnings": [],
        }

        display_impact_analysis(impact, console=console)

        captured = capsys.readouterr()
        # Strip ANSI codes for assertion
        ansi_escape = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")
        clean_output = ansi_escape.sub("", captured.out)
        assert "Column Changes" in clean_output
        assert "Added" in clean_output
        assert "new_column" in clean_output

    def test_display_impact_analysis_with_downstream_but_no_impact_summary(
        self,
        capsys,
    ):
        """Test when downstream_impacts exists but no will_invalidate or may_affect (covers line 197->207)."""
        from datajunction.cli import display_impact_analysis
        from rich.console import Console
        import re

        console = Console(force_terminal=True, no_color=True)

        # This tests the case where downstream_impacts is non-empty but
        # will_invalidate_count and may_affect_count are both 0
        impact = {
            "namespace": "test.namespace",
            "changes": [
                {
                    "name": "test.namespace.node",
                    "operation": "update",
                    "node_type": "transform",
                    "changed_fields": ["description"],
                },
            ],
            "create_count": 0,
            "update_count": 1,
            "delete_count": 0,
            "skip_count": 0,
            "downstream_impacts": [
                {
                    "name": "other.downstream",
                    "node_type": "metric",
                    "current_status": "valid",
                    "predicted_status": "valid",
                    "impact_type": "no_impact",
                    "impact_reason": "No functional change",
                    "depth": 1,
                    "caused_by": ["test.namespace.node"],
                },
            ],
            "will_invalidate_count": 0,
            "may_affect_count": 0,
            "warnings": [],
        }

        display_impact_analysis(impact, console=console)

        captured = capsys.readouterr()
        # Strip ANSI codes for assertion
        ansi_escape = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")
        clean_output = ansi_escape.sub("", captured.out)
        # Should NOT show "No downstream impact" since there are downstream_impacts
        # But should NOT show any summary items since counts are 0
        assert "Downstream Impact" in clean_output
        # The downstream summary line should not appear when both counts are 0
        assert "will invalidate" not in clean_output.lower()
        assert "may be affected" not in clean_output.lower()

    def test_dryrun_with_exception(self, capsys):
        """Test dryrun handles DJClientException properly (covers lines 276-286)."""
        from unittest.mock import MagicMock
        from datajunction.cli import DJCLI
        from datajunction.exceptions import DJClientException

        mock_client = MagicMock()
        cli = DJCLI(builder_client=mock_client)

        # Mock deployment_service.get_impact to raise exception
        cli.deployment_service.get_impact = MagicMock(
            side_effect=DJClientException({"message": "Test error message"}),
        )

        cli.dryrun("/fake/directory", format="text")

        captured = capsys.readouterr()
        assert "ERROR" in captured.out
        assert "Test error message" in captured.out

    def test_dryrun_with_exception_json_format(self, capsys):
        """Test dryrun handles DJClientException with JSON format (covers lines 276-286)."""
        from unittest.mock import MagicMock
        from datajunction.cli import DJCLI
        from datajunction.exceptions import DJClientException

        mock_client = MagicMock()
        cli = DJCLI(builder_client=mock_client)

        # Mock deployment_service.get_impact to raise exception
        cli.deployment_service.get_impact = MagicMock(
            side_effect=DJClientException({"message": "JSON error message"}),
        )

        cli.dryrun("/fake/directory", format="json")

        captured = capsys.readouterr()
        import json as json_module

        result = json_module.loads(captured.out)
        assert "error" in result
        assert result["error"] == "JSON error message"

    def test_dryrun_with_exception_string_error(self, capsys):
        """Test dryrun handles DJClientException with string error."""
        from unittest.mock import MagicMock
        from datajunction.cli import DJCLI
        from datajunction.exceptions import DJClientException

        mock_client = MagicMock()
        cli = DJCLI(builder_client=mock_client)

        # Mock deployment_service.get_impact to raise exception with string
        cli.deployment_service.get_impact = MagicMock(
            side_effect=DJClientException("Simple string error"),
        )

        cli.dryrun("/fake/directory", format="text")

        captured = capsys.readouterr()
        assert "ERROR" in captured.out
        assert "Simple string error" in captured.out

    def test_deploy_without_dryrun(
        self,
        builder_client,
        change_to_project_dir,
    ):
        """Test deploy command without --dryrun flag (covers line 814)."""
        change_to_project_dir("./")

        # deploy command without --dryrun should call push
        test_args = ["dj", "deploy", "./deploy0"]

        with patch(
            "datajunction.deployment.DeploymentService._detect_git_branch",
            return_value=None,
        ):
            with patch.dict(
                os.environ,
                {"DJ_USER": "datajunction", "DJ_PWD": "datajunction"},
                clear=False,
            ):
                with patch.object(sys, "argv", test_args):
                    main(builder_client=builder_client)

        # Verify nodes were deployed (push was called)
        results = builder_client.list_nodes(namespace="deps.deploy0")
        # deploy0 has 6 nodes, they should be deployed
        assert len(results) >= 6

    def test_push_force_flag_passed_to_service(self, tmp_path):
        """--force on `dj push` must propagate force=True to DeploymentService.push."""
        from datajunction.cli import DJCLI

        cli = DJCLI(builder_client=mock.MagicMock())
        with patch.object(cli.deployment_service, "push") as mock_push:
            mock_push.return_value = None
            with patch.object(sys, "argv", ["dj", "push", str(tmp_path), "--force"]):
                cli.run()

        mock_push.assert_called_once()
        _, kwargs = mock_push.call_args
        assert kwargs.get("force") is True

    def test_deploy_force_flag_passed_to_service(self, tmp_path):
        """--force on `dj deploy` must propagate force=True to DeploymentService.push."""
        from datajunction.cli import DJCLI

        cli = DJCLI(builder_client=mock.MagicMock())
        with patch.object(cli.deployment_service, "push") as mock_push:
            mock_push.return_value = None
            with patch.object(sys, "argv", ["dj", "deploy", str(tmp_path), "--force"]):
                cli.run()

        mock_push.assert_called_once()
        _, kwargs = mock_push.call_args
        assert kwargs.get("force") is True

    def test_push_without_force_flag_defaults_false(self, tmp_path):
        """Omitting --force on `dj push` must pass force=False."""
        from datajunction.cli import DJCLI

        cli = DJCLI(builder_client=mock.MagicMock())
        with patch.object(cli.deployment_service, "push") as mock_push:
            mock_push.return_value = None
            with patch.object(sys, "argv", ["dj", "push", str(tmp_path)]):
                cli.run()

        _, kwargs = mock_push.call_args
        assert kwargs.get("force") is False


class TestDJCLIClientCreation:
    """Tests for DJCLI client creation from environment variables."""

    def test_djcli_creates_client_from_dj_url_env_var(self, monkeypatch):
        """Test DJCLI creates client from DJ_URL env var when builder_client is None (covers lines 245-246)."""
        from datajunction.cli import DJCLI

        # Set DJ_URL environment variable
        monkeypatch.setenv("DJ_URL", "http://test-server:9000")

        # Create DJCLI without passing builder_client
        cli = DJCLI(builder_client=None)

        # Verify the client was created with the correct URL
        assert cli.builder_client is not None
        assert cli.builder_client.uri == "http://test-server:9000"

    def test_djcli_uses_default_url_when_env_not_set(self, monkeypatch):
        """Test DJCLI uses localhost:8000 when DJ_URL is not set."""
        from datajunction.cli import DJCLI

        # Ensure DJ_URL is not set
        monkeypatch.delenv("DJ_URL", raising=False)

        # Create DJCLI without passing builder_client
        cli = DJCLI(builder_client=None)

        # Verify the client was created with the default URL
        assert cli.builder_client is not None
        assert cli.builder_client.uri == "http://localhost:8000"


class TestPlanCommand:
    """Tests for the plan command."""

    @pytest.fixture
    def sample_plan(self):
        """Sample plan response for testing."""
        return {
            "dialect": "spark",
            "requested_dimensions": ["default.hard_hat.city", "default.hard_hat.state"],
            "grain_groups": [
                {
                    "parent_name": "default.repair_order_details",
                    "grain": ["default.hard_hat.city", "default.hard_hat.state"],
                    "aggregability": "full",
                    "metrics": [
                        "default.num_repair_orders",
                        "default.total_repair_cost",
                    ],
                    "components": [
                        {
                            "name": "default.num_repair_orders_count",
                            "expression": "COUNT(DISTINCT repair_order_id)",
                            "aggregation": "COUNT",
                            "merge": "SUM",
                        },
                        {
                            "name": "default.total_repair_cost_sum",
                            "expression": "SUM(cost)",
                            "aggregation": "SUM",
                            "merge": "SUM",
                        },
                    ],
                    "sql": "SELECT city, state, COUNT(DISTINCT repair_order_id) AS num_repair_orders_count\nFROM repair_orders\nGROUP BY city, state",
                },
            ],
            "metric_formulas": [
                {
                    "name": "default.num_repair_orders",
                    "combiner": "SUM(num_repair_orders_count)",
                    "components": ["default.num_repair_orders_count"],
                    "is_derived": False,
                },
                {
                    "name": "default.total_repair_cost",
                    "combiner": "SUM(total_repair_cost_sum)",
                    "components": ["default.total_repair_cost_sum"],
                    "is_derived": False,
                },
            ],
        }

    def test_plan_text_output(self, builder_client, sample_plan, capsys):
        """Test `dj plan --metrics <metric>` with text output."""
        with patch.object(builder_client, "plan", return_value=sample_plan):
            test_args = [
                "dj",
                "plan",
                "--metrics",
                "default.num_repair_orders",
                "default.total_repair_cost",
                "--dimensions",
                "default.hard_hat.city",
                "default.hard_hat.state",
            ]
            with patch.dict(
                os.environ,
                {"DJ_USER": "datajunction", "DJ_PWD": "datajunction"},
                clear=False,
            ):
                with patch.object(sys, "argv", test_args):
                    main(builder_client=builder_client)

        captured = capsys.readouterr()
        assert "Query Execution Plan" in captured.out
        assert "Grain Groups" in captured.out
        assert "Metric Formulas" in captured.out
        assert "default.num_repair_orders" in captured.out

    def test_plan_json_output(self, builder_client, sample_plan, capsys):
        """Test `dj plan --metrics <metric> --format json` with JSON output."""
        with patch.object(builder_client, "plan", return_value=sample_plan):
            test_args = [
                "dj",
                "plan",
                "--metrics",
                "default.num_repair_orders",
                "--format",
                "json",
            ]
            with patch.dict(
                os.environ,
                {"DJ_USER": "datajunction", "DJ_PWD": "datajunction"},
                clear=False,
            ):
                with patch.object(sys, "argv", test_args):
                    main(builder_client=builder_client)

        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert "dialect" in data
        assert "grain_groups" in data
        assert "metric_formulas" in data
        assert data["dialect"] == "spark"

    def test_plan_with_filters(self, builder_client, sample_plan, capsys):
        """Test `dj plan` with filters argument."""
        with patch.object(
            builder_client,
            "plan",
            return_value=sample_plan,
        ) as mock_plan:
            test_args = [
                "dj",
                "plan",
                "--metrics",
                "default.num_repair_orders",
                "--filters",
                "default.hard_hat.city = 'NYC'",
            ]
            with patch.dict(
                os.environ,
                {"DJ_USER": "datajunction", "DJ_PWD": "datajunction"},
                clear=False,
            ):
                with patch.object(sys, "argv", test_args):
                    main(builder_client=builder_client)

        # Verify plan was called with filters
        mock_plan.assert_called_once_with(
            metrics=["default.num_repair_orders"],
            dimensions=[],
            filters=["default.hard_hat.city = 'NYC'"],
            dialect=None,
        )

    def test_plan_with_dialect(self, builder_client, sample_plan, capsys):
        """Test `dj plan` with dialect argument."""
        with patch.object(
            builder_client,
            "plan",
            return_value=sample_plan,
        ) as mock_plan:
            test_args = [
                "dj",
                "plan",
                "--metrics",
                "default.num_repair_orders",
                "--dialect",
                "trino",
            ]
            with patch.dict(
                os.environ,
                {"DJ_USER": "datajunction", "DJ_PWD": "datajunction"},
                clear=False,
            ):
                with patch.object(sys, "argv", test_args):
                    main(builder_client=builder_client)

        # Verify plan was called with dialect
        mock_plan.assert_called_once_with(
            metrics=["default.num_repair_orders"],
            dimensions=[],
            filters=[],
            dialect="trino",
        )

    def test_plan_help(self, builder_client):
        """Test `dj plan --help` shows expected options."""
        test_args = ["dj", "plan", "--help"]
        with patch.object(sys, "argv", test_args):
            with patch("sys.stdout", new_callable=StringIO) as mock_stdout:
                with pytest.raises(SystemExit) as excinfo:
                    main(builder_client=builder_client)
                assert excinfo.value.code == 0
        output = mock_stdout.getvalue()
        assert "--metrics" in output
        assert "--dimensions" in output
        assert "--filters" in output
        assert "--dialect" in output
        assert "--format" in output

    def test_print_plan_text_with_empty_grain_groups(self, capsys):
        """Test _print_plan_text with empty grain groups."""
        from datajunction.cli import DJCLI

        mock_client = mock.MagicMock()
        cli = DJCLI(builder_client=mock_client)

        plan = {
            "dialect": "spark",
            "requested_dimensions": [],
            "grain_groups": [],
            "metric_formulas": [],
        }

        cli._print_plan_text(plan)

        captured = capsys.readouterr()
        assert "Query Execution Plan" in captured.out
        assert "Grain Groups (0)" in captured.out
        assert "Metric Formulas (0)" in captured.out

    def test_print_plan_text_with_no_sql(self, capsys):
        """Test _print_plan_text when grain group has no SQL."""
        from datajunction.cli import DJCLI

        mock_client = mock.MagicMock()
        cli = DJCLI(builder_client=mock_client)

        plan = {
            "dialect": "spark",
            "requested_dimensions": ["dim1"],
            "grain_groups": [
                {
                    "parent_name": "test.parent",
                    "grain": ["dim1"],
                    "aggregability": "full",
                    "metrics": ["metric1"],
                    "components": [],
                    "sql": "",  # Empty SQL
                },
            ],
            "metric_formulas": [
                {
                    "name": "metric1",
                    "combiner": "SUM(comp1)",
                    "components": ["comp1"],
                    "is_derived": False,
                },
            ],
        }

        cli._print_plan_text(plan)

        captured = capsys.readouterr()
        assert "Group 1: test.parent" in captured.out
        # SQL panel should not appear for empty SQL

    def test_print_plan_text_with_derived_metric(self, capsys):
        """Test _print_plan_text shows derived metric formula."""
        from datajunction.cli import DJCLI

        mock_client = mock.MagicMock()
        cli = DJCLI(builder_client=mock_client)

        plan = {
            "dialect": "spark",
            "requested_dimensions": [],
            "grain_groups": [],
            "metric_formulas": [
                {
                    "name": "derived_metric",
                    "combiner": "metric1 / metric2",
                    "components": ["metric1", "metric2"],
                    "is_derived": True,
                },
            ],
        }

        cli._print_plan_text(plan)

        captured = capsys.readouterr()
        assert "derived_metric" in captured.out
        assert "metric1" in captured.out
        assert "metric2" in captured.out

    def test_print_plan_text_with_component_no_merge(self, capsys):
        """Test _print_plan_text when component has no merge function."""
        from datajunction.cli import DJCLI

        mock_client = mock.MagicMock()
        cli = DJCLI(builder_client=mock_client)

        plan = {
            "dialect": "spark",
            "requested_dimensions": [],
            "grain_groups": [
                {
                    "parent_name": "test.parent",
                    "grain": [],
                    "aggregability": "full",
                    "metrics": ["metric1"],
                    "components": [
                        {
                            "name": "comp1",
                            "expression": "COUNT(*)",
                            "aggregation": "COUNT",
                            "merge": None,
                        },
                    ],
                    "sql": "SELECT COUNT(*) FROM t",
                },
            ],
            "metric_formulas": [],
        }

        cli._print_plan_text(plan)

        captured = capsys.readouterr()
        assert "comp1" in captured.out
        assert "COUNT(*)" in captured.out


# ============================================================================
# setup-claude Tests
# ============================================================================


def test_setup_claude_full_install(tmp_path, monkeypatch):
    """Test setup-claude with both skills and MCP (default behavior)"""
    # Setup temp directories
    claude_dir = tmp_path / ".claude"
    skills_dir = claude_dir / "skills" / "datajunction"
    claude_dir.mkdir()

    monkeypatch.setenv("HOME", str(tmp_path))

    with (
        patch("pathlib.Path.home", return_value=tmp_path),
        patch.object(sys, "argv", ["dj", "setup-claude"]),
        patch("sys.stdout", new_callable=StringIO) as mock_stdout,
    ):
        from datajunction import cli as dj_cli

        dj_cli.main()

    output = mock_stdout.getvalue()

    # Verify skill was installed
    skill_file = skills_dir / "SKILL.md"
    assert skill_file.exists(), "SKILL.md should be created"
    assert skill_file.read_text().startswith("---\nname: datajunction")

    # Verify metadata file was created
    metadata_file = skills_dir / "metadata.json"
    assert metadata_file.exists(), "metadata.json should be created"
    metadata = json.loads(metadata_file.read_text())
    assert metadata["name"] == "datajunction"
    assert "version" in metadata

    # Verify MCP config was created
    mcp_config_file = tmp_path / ".claude.json"
    assert mcp_config_file.exists(), "MCP config should be created"
    mcp_config = json.loads(mcp_config_file.read_text())
    assert "mcpServers" in mcp_config
    assert "datajunction" in mcp_config["mcpServers"]
    assert "dj-mcp" in mcp_config["mcpServers"]["datajunction"]["command"]
    assert "DJ_API_URL" in mcp_config["mcpServers"]["datajunction"]["env"]

    # Verify success message
    assert "Skill installed" in output
    assert "DJ MCP server configured" in output or "MCP server" in output
    assert "Restart Claude" in output


def test_setup_claude_skills_only(tmp_path, monkeypatch):
    """Test setup-claude --no-mcp (skills only)"""
    claude_dir = tmp_path / ".claude"
    skills_dir = claude_dir / "skills" / "datajunction"
    claude_dir.mkdir()

    monkeypatch.setenv("HOME", str(tmp_path))

    with (
        patch("pathlib.Path.home", return_value=tmp_path),
        patch.object(sys, "argv", ["dj", "setup-claude", "--no-mcp"]),
        patch("sys.stdout", new_callable=StringIO) as mock_stdout,
    ):
        from datajunction import cli as dj_cli

        dj_cli.main()

    output = mock_stdout.getvalue()

    # Verify skill was installed
    skill_file = skills_dir / "SKILL.md"
    assert skill_file.exists(), "SKILL.md should be created"

    # Verify MCP config was NOT created
    mcp_config_file = tmp_path / ".claude.json"
    assert not mcp_config_file.exists(), (
        "MCP config should NOT be created with --no-mcp"
    )

    # Verify success message only for skills / subagent (not MCP)
    assert "Skill installed" in output or "skill" in output.lower()
    assert "MCP server" not in output


def test_setup_claude_mcp_only(tmp_path, monkeypatch):
    """Test setup-claude --no-skills (MCP only)"""
    claude_dir = tmp_path / ".claude"
    claude_dir.mkdir()

    monkeypatch.setenv("HOME", str(tmp_path))

    with (
        patch("pathlib.Path.home", return_value=tmp_path),
        patch.object(sys, "argv", ["dj", "setup-claude", "--no-skills"]),
        patch("sys.stdout", new_callable=StringIO) as mock_stdout,
    ):
        from datajunction import cli as dj_cli

        dj_cli.main()

    output = mock_stdout.getvalue()

    # Verify skill was NOT installed
    skills_dir = claude_dir / "skills" / "datajunction"
    assert not skills_dir.exists(), (
        "Skills directory should NOT be created with --no-skills"
    )

    # Verify MCP config was created
    mcp_config_file = tmp_path / ".claude.json"
    assert mcp_config_file.exists(), "MCP config should be created"

    # Verify success message only for MCP
    assert "DJ MCP server configured" in output or "MCP server configured" in output
    assert "Restart Claude" in output
    assert "Skill installed" not in output


def test_setup_claude_bundled_skill_loading(tmp_path, monkeypatch):
    """Test that bundled skill is correctly loaded via importlib.resources"""
    claude_dir = tmp_path / ".claude"
    skills_dir = claude_dir / "skills" / "datajunction"
    claude_dir.mkdir()

    monkeypatch.setenv("HOME", str(tmp_path))

    with (
        patch("pathlib.Path.home", return_value=tmp_path),
        patch.object(sys, "argv", ["dj", "setup-claude", "--no-mcp"]),
        patch("sys.stdout", new_callable=StringIO),
    ):
        from datajunction import cli as dj_cli

        dj_cli.main()

    # Verify the skill content was loaded from bundled file
    skill_file = skills_dir / "SKILL.md"
    content = skill_file.read_text()

    # Check for key sections that should be in the bundled skill
    assert "---\nname: datajunction" in content
    assert "DataJunction" in content
    assert "semantic layer" in content
    assert "dimension link" in content or "dimension links" in content
    assert "Practical Notes" in content or "Node Types" in content


def test_setup_claude_overwrite_existing(tmp_path, monkeypatch):
    """Test setup-claude overwrites existing skill (force behavior)"""
    claude_dir = tmp_path / ".claude"
    skills_dir = claude_dir / "skills" / "datajunction"
    skills_dir.mkdir(parents=True)

    # Create existing skill with old content
    skill_file = skills_dir / "SKILL.md"
    skill_file.write_text("OLD SKILL CONTENT")

    monkeypatch.setenv("HOME", str(tmp_path))

    with (
        patch("pathlib.Path.home", return_value=tmp_path),
        patch.object(sys, "argv", ["dj", "setup-claude", "--no-mcp"]),
        patch("sys.stdout", new_callable=StringIO) as mock_stdout,
    ):
        from datajunction import cli as dj_cli

        dj_cli.main()

    # Verify skill was overwritten
    new_content = skill_file.read_text()
    assert "OLD SKILL CONTENT" not in new_content
    assert "---\nname: datajunction" in new_content

    output = mock_stdout.getvalue()
    assert "Skill installed" in output


def test_setup_claude_custom_dj_url(tmp_path, monkeypatch):
    """Test setup-claude with custom DJ_URL environment variable"""
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("DJ_URL", "http://custom-dj-server:9000")

    with (
        patch("pathlib.Path.home", return_value=tmp_path),
        patch.object(sys, "argv", ["dj", "setup-claude", "--no-skills"]),
        patch("sys.stdout", new_callable=StringIO),
    ):
        from datajunction import cli as dj_cli

        dj_cli.main()

    # Verify MCP config uses custom URL
    mcp_config_file = tmp_path / ".claude.json"
    mcp_config = json.loads(mcp_config_file.read_text())
    assert (
        mcp_config["mcpServers"]["datajunction"]["env"]["DJ_API_URL"]
        == "http://custom-dj-server:9000"
    )


def test_setup_claude_mcp_config_merge(tmp_path, monkeypatch):
    """Test setup-claude merges with existing MCP config"""
    # Create existing MCP config with other servers
    existing_config = {
        "mcpServers": {
            "other-server": {"command": "other-command", "env": {}},
        },
    }
    mcp_config_file = tmp_path / ".claude.json"
    mcp_config_file.write_text(json.dumps(existing_config))

    monkeypatch.setenv("HOME", str(tmp_path))

    with (
        patch("pathlib.Path.home", return_value=tmp_path),
        patch.object(sys, "argv", ["dj", "setup-claude", "--no-skills"]),
        patch("sys.stdout", new_callable=StringIO),
    ):
        from datajunction import cli as dj_cli

        dj_cli.main()

    # Verify both servers are in config
    mcp_config = json.loads(mcp_config_file.read_text())
    assert "other-server" in mcp_config["mcpServers"]
    assert "datajunction" in mcp_config["mcpServers"]
    assert mcp_config["mcpServers"]["other-server"]["command"] == "other-command"


def test_setup_claude_skill_content_verification(tmp_path, monkeypatch):
    """Test that the installed skill has correct content"""
    claude_dir = tmp_path / ".claude"
    skills_dir = claude_dir / "skills" / "datajunction"
    claude_dir.mkdir()

    monkeypatch.setenv("HOME", str(tmp_path))

    with (
        patch("pathlib.Path.home", return_value=tmp_path),
        patch.object(sys, "argv", ["dj", "setup-claude", "--no-mcp"]),
        patch("sys.stdout", new_callable=StringIO),
    ):
        from datajunction import cli as dj_cli

        dj_cli.main()

    # Verify skill content includes key sections
    skill_file = skills_dir / "SKILL.md"
    content = skill_file.read_text()

    # Check for essential sections
    assert "DataJunction" in content
    assert "semantic layer" in content
    assert "dimension link" in content
    assert "Temporal Partitions" in content  # Verify our recent additions
    assert "owners:" in content  # Verify ownership section
    assert "Git Repository" in content  # Verify git info documentation


def test_setup_claude_no_config_path(tmp_path, monkeypatch):
    """Test MCP setup when no Claude config path can be found"""
    # Create a temp home that doesn't have any of the expected paths.
    # Use --no-agents so the subagent installer doesn't create the home dir first.
    fake_home = tmp_path / "nonexistent"
    # Don't create fake_home or any parent directories

    monkeypatch.setenv("HOME", str(fake_home))

    with (
        patch("pathlib.Path.home", return_value=fake_home),
        patch.object(sys, "argv", ["dj", "setup-claude", "--no-skills", "--no-agents"]),
        patch("sys.stdout", new_callable=StringIO) as mock_stdout,
    ):
        from datajunction import cli as dj_cli

        dj_cli.main()

        output = mock_stdout.getvalue()
        # Should show warning about not finding config directory
        assert "Could not find Claude config directory" in output
        assert "Skipping MCP setup" in output


def test_setup_claude_dj_mcp_not_found(tmp_path, monkeypatch):
    """Test MCP setup when dj-mcp command is not in PATH"""
    claude_dir = tmp_path / ".claude"
    claude_dir.mkdir()

    monkeypatch.setenv("HOME", str(tmp_path))

    with (
        patch("pathlib.Path.home", return_value=tmp_path),
        patch("shutil.which", return_value=None),  # Simulate dj-mcp not found
        patch.object(sys, "argv", ["dj", "setup-claude", "--no-skills"]),
        patch("sys.stdout", new_callable=StringIO) as mock_stdout,
    ):
        from datajunction import cli as dj_cli

        dj_cli.main()

        output = mock_stdout.getvalue()
        # Should show warning about dj-mcp not found
        assert "dj-mcp command not found" in output
        assert "pip install 'datajunction[mcp]'" in output


def test_setup_claude_invalid_json_config(tmp_path, monkeypatch):
    """Test MCP setup when existing Claude config has invalid JSON"""
    claude_dir = tmp_path / ".claude"
    claude_dir.mkdir()
    config_file = tmp_path / ".claude.json"

    # Write invalid JSON to config file
    config_file.write_text("{ invalid json content }")

    monkeypatch.setenv("HOME", str(tmp_path))

    with (
        patch("pathlib.Path.home", return_value=tmp_path),
        patch("shutil.which", return_value="/usr/bin/dj-mcp"),
        patch.object(sys, "argv", ["dj", "setup-claude", "--no-skills"]),
        patch("sys.stdout", new_callable=StringIO) as mock_stdout,
    ):
        from datajunction import cli as dj_cli

        dj_cli.main()

        output = mock_stdout.getvalue()
        # Should show warning about invalid JSON and backup
        assert "Invalid JSON in Claude config" in output
        assert "Backup saved to" in output

        # Verify backup was created
        backup_file = tmp_path / ".claude.json.backup"
        assert backup_file.exists()
        assert backup_file.read_text() == "{ invalid json content }"

        # Verify new valid config was written
        assert config_file.exists()
        new_config = json.loads(config_file.read_text())
        assert "mcpServers" in new_config
        assert "datajunction" in new_config["mcpServers"]


def test_setup_claude_full_install_includes_subagent(tmp_path, monkeypatch):
    """Test setup-claude (default) installs skills, MCP, and the subagent"""
    claude_dir = tmp_path / ".claude"
    claude_dir.mkdir()

    monkeypatch.setenv("HOME", str(tmp_path))

    with (
        patch("pathlib.Path.home", return_value=tmp_path),
        patch.object(sys, "argv", ["dj", "setup-claude"]),
        patch("sys.stdout", new_callable=StringIO) as mock_stdout,
    ):
        from datajunction import cli as dj_cli

        dj_cli.main()

    output = mock_stdout.getvalue()

    # Verify subagent was installed
    agent_file = claude_dir / "agents" / "dj.md"
    assert agent_file.exists(), "dj.md subagent should be created"
    content = agent_file.read_text()
    assert "name: dj" in content
    assert "skills:" in content
    assert "datajunction" in content

    # Verify success output mentions subagent
    assert "subagent" in output.lower() or "Installed subagent" in output


def test_setup_claude_no_agents(tmp_path, monkeypatch):
    """Test setup-claude --no-agents skips subagent installation"""
    claude_dir = tmp_path / ".claude"
    claude_dir.mkdir()

    monkeypatch.setenv("HOME", str(tmp_path))

    with (
        patch("pathlib.Path.home", return_value=tmp_path),
        patch.object(sys, "argv", ["dj", "setup-claude", "--no-agents", "--no-mcp"]),
        patch("sys.stdout", new_callable=StringIO),
    ):
        from datajunction import cli as dj_cli

        dj_cli.main()

    # Subagent file should NOT exist
    agent_file = claude_dir / "agents" / "dj.md"
    assert not agent_file.exists(), "dj.md should NOT be created with --no-agents"


def test_setup_claude_agents_only(tmp_path, monkeypatch):
    """Test setup-claude --no-skills --no-mcp installs only the subagent"""
    claude_dir = tmp_path / ".claude"
    claude_dir.mkdir()

    monkeypatch.setenv("HOME", str(tmp_path))

    with (
        patch("pathlib.Path.home", return_value=tmp_path),
        patch.object(sys, "argv", ["dj", "setup-claude", "--no-skills", "--no-mcp"]),
        patch("sys.stdout", new_callable=StringIO) as mock_stdout,
    ):
        from datajunction import cli as dj_cli

        dj_cli.main()

    output = mock_stdout.getvalue()

    # Subagent should be installed
    agent_file = claude_dir / "agents" / "dj.md"
    assert agent_file.exists(), "dj.md subagent should be created"

    # Skill should NOT be installed
    skills_dir = claude_dir / "skills" / "datajunction"
    assert not skills_dir.exists(), "Skills should NOT be installed with --no-skills"

    # MCP config should NOT be created
    mcp_config_file = tmp_path / ".claude.json"
    assert not mcp_config_file.exists(), (
        "MCP config should NOT be created with --no-mcp"
    )

    assert "subagent" in output.lower() or "Installed subagent" in output


def test_setup_claude_subagent_content(tmp_path, monkeypatch):
    """Test the installed subagent has the correct frontmatter content"""
    claude_dir = tmp_path / ".claude"
    claude_dir.mkdir()

    monkeypatch.setenv("HOME", str(tmp_path))

    with (
        patch("pathlib.Path.home", return_value=tmp_path),
        patch.object(sys, "argv", ["dj", "setup-claude", "--no-skills", "--no-mcp"]),
        patch("sys.stdout", new_callable=StringIO),
    ):
        from datajunction import cli as dj_cli

        dj_cli.main()

    agent_file = claude_dir / "agents" / "dj.md"
    content = agent_file.read_text()

    assert content.startswith("---")
    assert "name: dj" in content
    assert "description:" in content
    assert "DataJunction" in content
    assert "skills:" in content
    assert "- datajunction" in content
    assert "model: inherit" in content


def test_setup_claude_subagent_overwrites_existing(tmp_path, monkeypatch):
    """Test setup-claude overwrites an existing subagent file"""
    claude_dir = tmp_path / ".claude"
    agents_dir = claude_dir / "agents"
    agents_dir.mkdir(parents=True)
    agent_file = agents_dir / "dj.md"
    agent_file.write_text("OLD CONTENT")

    monkeypatch.setenv("HOME", str(tmp_path))

    with (
        patch("pathlib.Path.home", return_value=tmp_path),
        patch.object(sys, "argv", ["dj", "setup-claude", "--no-skills", "--no-mcp"]),
        patch("sys.stdout", new_callable=StringIO),
    ):
        from datajunction import cli as dj_cli

        dj_cli.main()

    new_content = agent_file.read_text()
    assert "OLD CONTENT" not in new_content
    assert "name: dj" in new_content


class TestDeploymentFailureExitsWithCode1:
    """push and deploy commands must exit with code 1 when DJDeploymentFailure is raised."""

    def _make_failure(self):
        from datajunction.exceptions import DJDeploymentFailure

        return DJDeploymentFailure(
            project_name="my.ns",
            errors=[{"name": "my.ns.node", "message": "something broke"}],
        )

    def test_push_exits_1_on_deployment_failure(self, tmp_path):
        from datajunction.cli import DJCLI

        cli = DJCLI(builder_client=mock.MagicMock())
        with patch.object(cli, "push", side_effect=self._make_failure()):
            with patch.object(sys, "argv", ["dj", "push", str(tmp_path)]):
                with pytest.raises(SystemExit) as exc_info:
                    cli.run()
                assert exc_info.value.code == 1

    def test_deploy_exits_1_on_deployment_failure(self, tmp_path):
        from datajunction.cli import DJCLI

        cli = DJCLI(builder_client=mock.MagicMock())
        with patch.object(cli, "push", side_effect=self._make_failure()):
            with patch.object(sys, "argv", ["dj", "deploy", str(tmp_path)]):
                with pytest.raises(SystemExit) as exc_info:
                    cli.run()
                assert exc_info.value.code == 1
