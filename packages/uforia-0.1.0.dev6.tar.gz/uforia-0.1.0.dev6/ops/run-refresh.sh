#!/bin/zsh
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"

export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"
export UFORIA_DATA_ROOT="${UFORIA_DATA_ROOT:-$REPO_ROOT/data}"
export UFORIA_DB_ENABLED="${UFORIA_DB_ENABLED:-true}"
export UFORIA_DB_DSN="${UFORIA_DB_DSN:-postgresql:///uforia?user=$USER}"
export UFORIA_DB_READ_MODE="${UFORIA_DB_READ_MODE:-db}"
export UFORIA_DB_WRITE_MODE="${UFORIA_DB_WRITE_MODE:-db}"
UFORIA_BIN="${UFORIA_BIN:-uforia}"

START=$(python3 - <<'PY'
from datetime import datetime, timedelta, timezone
end = datetime.now(timezone.utc).replace(minute=0, second=0, microsecond=0)
start = end - timedelta(days=3)
print(start.strftime("%Y-%m-%dT%H:00:00Z"))
PY
)

END=$(python3 - <<'PY'
from datetime import datetime, timezone
end = datetime.now(timezone.utc).replace(minute=0, second=0, microsecond=0)
print(end.strftime("%Y-%m-%dT%H:00:00Z"))
PY
)

TS=$(python3 - <<'PY'
from datetime import datetime, timedelta, timezone
ts = datetime.now(timezone.utc).replace(minute=0, second=0, microsecond=0) - timedelta(hours=1)
print(ts.strftime("%Y-%m-%dT%H:00:00Z"))
PY
)

START_DATE=$(python3 - <<'PY'
from datetime import datetime, timedelta, timezone
end = datetime.now(timezone.utc).replace(minute=0, second=0, microsecond=0)
start = end - timedelta(days=3)
print(start.date().isoformat())
PY
)

END_DATE=$(python3 - <<'PY'
from datetime import datetime, timezone
print(datetime.now(timezone.utc).date().isoformat())
PY
)

for UNDERLYING in BTC ETH; do
  LOWER_UNDERLYING=$(printf '%s' "$UNDERLYING" | tr '[:upper:]' '[:lower:]')
  "$UFORIA_BIN" ingest deribit-dvol --underlying "$UNDERLYING" --start "$START" --end "$END"
  "$UFORIA_BIN" ingest deribit-funding --underlying "$UNDERLYING" --start "$START" --end "$END"
  "$UFORIA_BIN" build vol-index --underlying "$UNDERLYING" --source dvol --start "$START" --end "$END"
  "$UFORIA_BIN" build rvvix --underlying "$UNDERLYING" --source dvol --start "$START" --end "$END"

  "$UFORIA_BIN" build surface-features --underlying "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build qvvix --underlying "$UNDERLYING" --source dvol --ts "$TS" || true
  "$UFORIA_BIN" build razor --underlying "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build options-surface --underlying "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build options-carry --underlying "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build options-skew --underlying "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build options-dislocations --underlying "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build options-positioning --underlying "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build vol-cone --underlying "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build term-structure-momentum --underlying "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build gamma-exposure --underlying "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build funding-context --underlying "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build straddle-breakeven --underlying "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build surface-factor-rv --underlying "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build ml-carry-toxicity --underlying "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build expiry-flow-map --underlying "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build adaptive-hedging --underlying "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build sessionality-clocks --underlying "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build funding-basis-skew --underlying "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build options-signals --underlying "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build vol-regime-transitions --underlying "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build perps-signals --asset "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build perps-composites --asset "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build perps-transitions --asset "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build composite --asset "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build composite-components --asset "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" build composite-transitions --asset "$UNDERLYING" --start "$START" --end "$END" || true
  "$UFORIA_BIN" validate vol-suite --underlying "$UNDERLYING" --start "$START" --end "$END" > "$REPO_ROOT/data/validation-${LOWER_UNDERLYING}-latest.json" || true
  "$UFORIA_BIN" validate options-family --underlying "$UNDERLYING" --start "$START" --end "$END" > "$REPO_ROOT/data/options-validation-${LOWER_UNDERLYING}-latest.json" || true
done

"$UFORIA_BIN" build options-rv --start "$START" --end "$END" || true
"$UFORIA_BIN" build btc-eth-dispersion --start "$START" --end "$END" || true

for DATASET in microstructure_raw_event microstructure_book_state microstructure_bar dvol_snapshot funding_rate_snapshot vol_index_series vvix_series surface_features razor_series options_surface_snapshot options_carry_series options_skew_series options_dislocation_series options_relative_value_series options_positioning_series options_signal_series vol_cone_series term_structure_momentum_series gamma_exposure_series funding_context_series straddle_breakeven_series vol_regime_transition_series perps_signal_series perps_composite_series perps_transition_series composite_signal_series composite_component_series composite_transition_series; do
  "$UFORIA_BIN" maintenance compact --dataset "$DATASET" --start-date "$START_DATE" --end-date "$END_DATE" || true
done
