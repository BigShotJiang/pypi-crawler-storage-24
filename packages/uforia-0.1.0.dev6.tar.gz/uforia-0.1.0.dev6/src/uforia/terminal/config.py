from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import os


class OutputMode(str, Enum):
    RICH = "rich"
    JSON = "json"
    NDJSON = "ndjson"


@dataclass(frozen=True)
class TerminalConfig:
    api_base_url: str
    timeout_seconds: float
    output_mode: OutputMode
    compact: bool

    @classmethod
    def from_values(
        cls,
        api_base_url: str | None,
        timeout_seconds: float | None,
        output: str | None,
        compact: bool,
    ) -> "TerminalConfig":
        base_url = api_base_url or os.getenv("UFORIA_API_BASE_URL") or "https://uforia.polynomial.fi"
        timeout = timeout_seconds or float(os.getenv("UFORIA_TIMEOUT_SECONDS", "8"))
        output_name = output or os.getenv("UFORIA_OUTPUT") or OutputMode.RICH.value
        return cls(
            api_base_url=base_url.rstrip("/"),
            timeout_seconds=timeout,
            output_mode=OutputMode(output_name),
            compact=compact,
        )
