mod metrics;
mod request_trace;

pub use metrics::{MetricKind, MetricSeriesSnapshot, MetricSnapshot};
pub use request_trace::{
    RequestFeatures, RequestMetricsFactory, RequestMetricsRequest, RequestMetricsSnapshot,
    RequestMetricsTotalsSnapshot,
};

#[doc(hidden)]
pub mod __private {
    pub use crate::metrics::{
        DistributionMetricHandle, MetricLabels, PerformanceMetricsRegistry, RateMetricHandle,
        RatioMetricHandle,
    };
    pub use crate::request_trace::{
        RequestLogEntry, RequestMetricsOptions, RequestTrace, RequestTraceFactory,
        RequestTraceOptions, S3SinkConfig,
    };
}
