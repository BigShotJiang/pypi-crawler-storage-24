from __future__ import annotations

import statistics
import time

from llm_runtime_metrics import RequestMetricsFactory


def _p95(values: list[float]) -> float:
    ordered = sorted(values)
    idx = int(0.95 * (len(ordered) - 1))
    return ordered[idx]


def test_new_request_latency_smoke() -> None:
    factory = RequestMetricsFactory(request_log_enabled=False)
    input_ids = list(range(128))

    latencies_ms: list[float] = []
    for _ in range(400):
        start = time.perf_counter()
        req = factory.new_request(input_ids)
        latencies_ms.append((time.perf_counter() - start) * 1000.0)
        req.cancel()

    assert statistics.mean(latencies_ms) < 0.20
    assert _p95(latencies_ms) < 0.50


def test_record_tokens_latency_smoke() -> None:
    factory = RequestMetricsFactory(request_log_enabled=False)
    req = factory.new_request(list(range(128)))
    diff = [128, 129, 130, 131]

    latencies_ms: list[float] = []
    for _ in range(800):
        start = time.perf_counter()
        req.record_tokens(diff, cached_tokens=64, is_diff=True)
        latencies_ms.append((time.perf_counter() - start) * 1000.0)

    req.success()

    assert statistics.mean(latencies_ms) < 0.05
    assert _p95(latencies_ms) < 0.20
