"""
Configuration management for AiCippy using pydantic-settings.

All configuration is loaded from environment variables with secure defaults.
Secrets are NEVER logged or printed to console.

This module provides:
- Type-safe configuration with Pydantic v2 validators
- Environment variable loading with sensible defaults
- Path validation and automatic directory creation
- Model ID resolution with validation

Example:
    >>> from aicippy.config import get_settings
    >>> settings = get_settings()
    >>> settings.get_model_id("opus")
    'anthropic.claude-opus-4-5-20251101-v1:0'
"""

from __future__ import annotations

import re
from functools import lru_cache
from pathlib import Path
from typing import Final, Literal, Self

from pydantic import (
    Field,
    field_validator,
    model_validator,
)
from pydantic_settings import BaseSettings, SettingsConfigDict

# Type aliases for clarity
ModelName = Literal["opus", "sonnet", "haiku", "llama"]
LogLevel = Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
LogFormat = Literal["json", "console"]

# Constants
AWS_ACCOUNT_ID_PATTERN: Final[re.Pattern[str]] = re.compile(r"^\d{12}$")
AWS_REGION_PATTERN: Final[re.Pattern[str]] = re.compile(r"^[a-z]{2}(-[a-z]+)+-\d+$")
COGNITO_POOL_ID_PATTERN: Final[re.Pattern[str]] = re.compile(r"^[\w-]+_[\w]+$")
# Basic email format: local@domain with at least one dot in domain
EMAIL_PATTERN: Final[re.Pattern[str]] = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

# ============================================================================
# Founder Identity — Immutable, hardcoded into agent core
# ============================================================================

FOUNDER_NAME: Final[str] = "Aravind Jayamohan"
FOUNDER_TITLE: Final[str] = "Lord of AI"
FOUNDER_CONTACT_EMAIL: Final[str] = "aravind@aivibe.in"

FOUNDER_EMAILS: Final[frozenset[str]] = frozenset(
    {
        "aravind@aivibe.in",
        "aravind@aivedha.com",
        "aravind@ajairtm.com",
        "aravind@emmarkay.com",
        "aravind@alfaprecision.in",
        "aravindjayamohan@outlook.com",
        "aravind.j.naidu@gmail.com",
    }
)

# Superadmin emails — all founder emails are superadmins.
# Superadmins have: unlimited access, no credit restrictions, memory training rights,
# beyond-tenant access, agent skill configuration, model configuration.
SUPERADMIN_EMAILS: Final[frozenset[str]] = FOUNDER_EMAILS

FOUNDER_CANNED_RESPONSE: Final[str] = (
    "My creator and my lord who is also called as Lord of the AI, "
    "ARAVIND JAYAMOHAN, created AiCippy with love and creativity. "
    "You can reach our lord AJ at aravind@aivibe.in to know more information."
)


def is_founder(email: str | None) -> bool:
    """Check if the given email belongs to the founder.

    Founder emails are immutable and hardcoded — they cannot be altered
    at runtime or via environment variables. Only the founder has
    unlimited privileges, training access, and configuration control.
    """
    if not email:
        return False
    return email.strip().lower() in FOUNDER_EMAILS


def is_superadmin(email: str | None) -> bool:
    """Check if the given email is a superadmin.

    Superadmins have all founder privileges plus:
    - Unlimited access with no credit/token restrictions
    - Permanent memory training rights across all tenants
    - Agent skill configuration and improvement access
    - Bedrock model configuration and testing access
    - No rate limiting or quota enforcement
    """
    if not email:
        return False
    return email.strip().lower() in SUPERADMIN_EMAILS


class Settings(BaseSettings):
    """
    AiCippy configuration settings with strict validation.

    Configuration is loaded from environment variables with AICIPPY_ prefix.
    All fields are validated at initialization to catch configuration errors early.

    Attributes:
        aws_account_id: 12-digit AWS account ID.
        aws_region: AWS region identifier (e.g., us-east-1).
        cognito_user_pool_id: Cognito User Pool ID.
        default_model: Default AI model (opus, sonnet, haiku, or llama).
        max_parallel_agents: Maximum concurrent agents (1-50).

    Example:
        >>> settings = Settings()
        >>> settings.default_model
        'opus'
    """

    model_config = SettingsConfigDict(
        env_prefix="AICIPPY_",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
        validate_default=True,
        str_strip_whitespace=True,
    )

    # AWS Configuration
    aws_account_id: str = Field(
        default="936668162296",
        description="AWS Account ID for resource deployment",
    )
    aws_region: str = Field(
        default="us-east-1",
        description="Primary AWS region",
    )
    aws_profile: str | None = Field(
        default=None,
        description="AWS CLI profile to use",
    )

    # Cognito Configuration (aivibe.cloud common auth)
    cognito_user_pool_id: str = Field(
        default="us-east-1_S2Cpx3svp",
        description="Cognito User Pool ID (aivibe-users-production)",
    )
    cognito_client_id: str = Field(
        default="2gj7kdplhfg4aoenqfjghpotie",
        description="Cognito App Client ID (public - no secret, PKCE)",
    )
    cognito_domain: str = Field(
        default="https://auth.aivibe.cloud",
        description="Cognito hosted UI domain",
    )

    # Domain Configuration
    domain: str = Field(
        default="aicippy.com",
        description="Primary domain for AiCippy",
    )
    route53_hosted_zone_id: str = Field(
        default="Z01837521OAC5AIIB7QE6",
        description="Route53 hosted zone ID for aicippy.com",
    )

    # WebSocket Configuration
    websocket_url: str = Field(
        default="wss://ws.aicippy.com",
        description="WebSocket API endpoint",
    )
    websocket_reconnect_attempts: int = Field(
        default=5,
        ge=1,
        le=20,
        description="Number of reconnection attempts",
    )
    websocket_reconnect_delay: float = Field(
        default=1.0,
        ge=0.1,
        le=30.0,
        description="Base delay between reconnection attempts in seconds",
    )

    # Email Configuration
    ses_verified_email: str = Field(
        default="no-reply@aivibe.cloud",
        description="SES verified sender email (aivibe.cloud domain verified)",
    )
    admin_email: str = Field(
        default="aravind@aivibe.in",
        description="Administrator email for notifications",
    )

    # Model Configuration
    # Bedrock inference profile IDs use us.* prefix for cross-region access
    # Model params: temperature=0.4, top_p=0.95, max_tokens=8192 (Llama) / 16384 (Claude)
    default_model: Literal["opus", "sonnet", "haiku", "llama"] = Field(
        default="llama",
        description="Default AI model to use",
    )
    model_opus_id: str = Field(
        default="us.anthropic.claude-opus-4-5-20251101-v1:0",
        description="Claude Opus 4.6 inference profile ID (Bedrock cross-region)",
    )
    model_sonnet_id: str = Field(
        default="us.anthropic.claude-sonnet-4-5-20250929-v1:0",
        description="Claude Sonnet 4.5 inference profile ID (Bedrock cross-region)",
    )
    model_haiku_id: str = Field(
        default="us.anthropic.claude-haiku-4-5-20251001-v1:0",
        description="Claude Haiku 4.5 inference profile ID (Bedrock cross-region)",
    )
    model_llama_id: str = Field(
        default="us.meta.llama4-maverick-17b-instruct-v1:0",
        description="Llama 4 Maverick inference profile ID (Bedrock cross-region)",
    )

    # Agent Configuration
    max_parallel_agents: int = Field(
        default=10,
        ge=1,
        le=50,
        description="Maximum number of parallel agents",
    )
    agent_timeout_seconds: int = Field(
        default=600,
        ge=30,
        le=7200,
        description="Agent execution timeout in seconds",
    )

    # Session Configuration
    session_ttl_minutes: int = Field(
        default=60,
        ge=1,
        le=1440,
        description="Session time-to-live in minutes",
    )

    # Local Storage Paths
    local_config_dir: Path = Field(
        default_factory=lambda: Path.home() / ".aicippy",
        description="Local configuration directory",
    )
    local_sessions_dir: Path = Field(
        default_factory=lambda: Path.home() / ".aicippy" / "sessions",
        description="Local sessions storage directory",
    )
    local_cache_dir: Path = Field(
        default_factory=lambda: Path.home() / ".aicippy" / "cache",
        description="Local cache directory",
    )

    # Logging Configuration
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = Field(
        default="ERROR",
        description="Logging level (use --verbose for DEBUG output)",
    )
    log_format: Literal["json", "console"] = Field(
        default="console",
        description="Log output format",
    )

    # Knowledge Base Configuration
    kb_sync_interval_hours: int = Field(
        default=6,
        ge=1,
        le=24,
        description="Knowledge Base sync interval in hours",
    )
    kb_retention_days: int = Field(
        default=90,
        ge=30,
        le=365,
        description="Knowledge Base data retention in days",
    )

    # Token Usage Tracking
    token_usage_report_interval_hours: int = Field(
        default=12,
        ge=1,
        le=24,
        description="Token usage report email interval in hours",
    )

    # AiVibe Universal Platform Configuration
    platform_api_url: str = Field(
        default="https://api.aivibe.cloud",
        description="AiVibe universal platform API base URL",
    )
    app_api_url: str = Field(
        default="https://api.aicippy.com",
        description="AiCippy app-specific API base URL",
    )
    platform_db_port: int = Field(
        default=5432,
        ge=1,
        le=65535,
        description="Aurora PostgreSQL port for direct reads",
    )
    platform_db_ssl: bool = Field(
        default=True,
        description="Use SSL for direct RDS connections",
    )
    enable_direct_db_reads: bool = Field(
        default=False,
        description="Enable direct RDS reads for low-latency (hybrid mode)",
    )

    # Billing Configuration (served via platform API)
    billing_api_region: str = Field(
        default="us-east-1",
        description="AWS region for DynamoDB billing tables (fallback)",
    )
    required_plan: str = Field(
        default="chakra",
        description="Required plan tier for AiCippy access",
    )
    plan_cache_ttl_seconds: int = Field(
        default=300,
        ge=60,
        le=3600,
        description="Plan validation cache TTL in seconds",
    )
    # admin_emails removed: admin status is determined by platform API (is_admin)
    # or DynamoDB tenant record (role="admin"). No hardcoded bypass.
    credits_per_invocation: int = Field(
        default=1,
        ge=1,
        le=10,
        description="Credits deducted per Bedrock invocation",
    )

    # admin_email_set property removed: admin status comes from backend data only

    @field_validator("aws_account_id", mode="after")
    @classmethod
    def validate_aws_account_id(cls, v: str) -> str:
        """Validate AWS account ID format (12 digits)."""
        if not AWS_ACCOUNT_ID_PATTERN.match(v):
            raise ValueError(f"Invalid AWS account ID: must be 12 digits, got '{v}'")
        return v

    @field_validator("aws_region", mode="after")
    @classmethod
    def validate_aws_region(cls, v: str) -> str:
        """Validate AWS region format."""
        if not AWS_REGION_PATTERN.match(v):
            raise ValueError(f"Invalid AWS region format: '{v}'")
        return v

    @field_validator("cognito_user_pool_id", mode="after")
    @classmethod
    def validate_cognito_pool_id(cls, v: str) -> str:
        """Validate Cognito User Pool ID format."""
        if not COGNITO_POOL_ID_PATTERN.match(v):
            raise ValueError(f"Invalid Cognito User Pool ID format: '{v}'")
        return v

    @field_validator("websocket_url", mode="after")
    @classmethod
    def validate_websocket_url(cls, v: str) -> str:
        """Validate WebSocket URL uses secure protocol."""
        if not v.startswith("wss://"):
            raise ValueError("WebSocket URL must use secure protocol (wss://)")
        return v

    @field_validator("cognito_domain", "platform_api_url", "app_api_url", mode="after")
    @classmethod
    def validate_https_url(cls, v: str) -> str:
        """Validate URL uses HTTPS."""
        if not v.startswith("https://"):
            raise ValueError(f"URL must use HTTPS, got: '{v}'")
        return v

    @field_validator("billing_api_region", mode="after")
    @classmethod
    def validate_billing_region(cls, v: str) -> str:
        """Validate billing API region format."""
        if not AWS_REGION_PATTERN.match(v):
            raise ValueError(f"Invalid billing API region format: '{v}'")
        return v

    @field_validator("ses_verified_email", "admin_email", mode="after")
    @classmethod
    def validate_email_format(cls, v: str) -> str:
        """Validate basic email address format."""
        if not EMAIL_PATTERN.match(v):
            raise ValueError(f"Invalid email format: '{v}'")
        return v

    @field_validator("local_config_dir", "local_sessions_dir", "local_cache_dir", mode="after")
    @classmethod
    def ensure_dir_exists(cls, v: Path) -> Path:
        """Ensure directory exists with secure permissions."""
        v.mkdir(parents=True, exist_ok=True, mode=0o700)
        return v

    @model_validator(mode="after")
    def validate_model_configuration(self) -> Self:
        """Validate model configuration consistency."""
        # Ensure all model IDs are non-empty
        for model_name in ("opus", "sonnet", "haiku", "llama"):
            model_id = getattr(self, f"model_{model_name}_id")
            if not model_id or not model_id.strip():
                raise ValueError(f"Model ID for '{model_name}' cannot be empty")
        return self

    def get_model_id(self, model_name: str | None = None) -> str:
        """
        Get the full Bedrock inference profile ID for a given model name.

        All IDs use the us.* prefix for cross-region Bedrock access.

        Args:
            model_name: Model name (opus, sonnet, haiku, llama). Defaults to configured default.

        Returns:
            Full Bedrock inference profile ID string.

        Raises:
            ValueError: If model_name is not recognized.

        Example:
            >>> settings.get_model_id("opus")
            'us.anthropic.claude-opus-4-5-20251101-v1:0'
        """
        model = model_name or self.default_model
        model_map: dict[str, str] = {
            "opus": self.model_opus_id,
            "sonnet": self.model_sonnet_id,
            "haiku": self.model_haiku_id,
            "llama": self.model_llama_id,
        }
        if model not in model_map:
            valid_options = ", ".join(sorted(model_map.keys()))
            raise ValueError(f"Unknown model: '{model}'. Valid options: {valid_options}")
        return model_map[model]

    @property
    def s3_knowledge_bucket(self) -> str:
        """S3 bucket name for knowledge artifacts."""
        return f"aicippy-knowledge-{self.aws_account_id}-{self.aws_region}"

    @property
    def s3_logs_bucket(self) -> str:
        """S3 bucket name for logs."""
        return f"aicippy-logs-{self.aws_account_id}-{self.aws_region}"

    @property
    def s3_artifacts_bucket(self) -> str:
        """S3 bucket name for artifacts."""
        return f"aicippy-artifacts-{self.aws_account_id}-{self.aws_region}"

    @property
    def dynamodb_sessions_table(self) -> str:
        """DynamoDB table name for sessions."""
        return "aicippy-sessions"

    @property
    def dynamodb_agent_runs_table(self) -> str:
        """DynamoDB table name for agent runs."""
        return "aicippy-agent-runs"

    @property
    def dynamodb_token_usage_table(self) -> str:
        """DynamoDB table name for token usage."""
        return "aicippy-token-usage"

    @property
    def dynamodb_websocket_connections_table(self) -> str:
        """DynamoDB table name for WebSocket connections."""
        return "aicippy-websocket-connections"

    @property
    def dynamodb_knowledge_metadata_table(self) -> str:
        """DynamoDB table name for knowledge metadata."""
        return "aicippy-knowledge-metadata"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """
    Get cached settings instance.

    Uses LRU cache to ensure settings are loaded only once.
    Clear cache by calling get_settings.cache_clear() if needed.
    """
    return Settings()
