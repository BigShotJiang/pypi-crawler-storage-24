import unittest

from bot.keyboard import main_menu_keyboard, settings_keyboard


class KeyboardTests(unittest.TestCase):
    def test_main_menu_keeps_settings_only_for_config_area(self):
        markup = main_menu_keyboard()
        callbacks = [
            button.callback_data
            for row in markup.inline_keyboard
            for button in row
            if button.callback_data
        ]
        self.assertIn("cmd:config", callbacks)
        self.assertIn("cmd:mode_current", callbacks)
        self.assertIn("cmd:mode_quick_toggle", callbacks)
        self.assertNotIn("cmd:features", callbacks)
        self.assertNotIn("cmd:apps", callbacks)

    def test_main_menu_splits_current_mode_and_toggle_labels(self):
        markup = main_menu_keyboard("build")
        texts = [button.text for row in markup.inline_keyboard for button in row]
        self.assertIn("🧭 BUILD", texts)
        self.assertIn("🔁 PLAN", texts)
        self.assertNotIn("🧭 Mode: BUILD → PLAN", texts)

        markup = main_menu_keyboard("plan")
        texts = [button.text for row in markup.inline_keyboard for button in row]
        self.assertIn("🧭 PLAN", texts)
        self.assertIn("🔁 BUILD", texts)
        self.assertNotIn("🧭 Mode: PLAN → BUILD", texts)

    def test_settings_menu_exposes_all_settings_commands(self):
        markup = settings_keyboard()
        callbacks = [
            button.callback_data
            for row in markup.inline_keyboard
            for button in row
            if button.callback_data
        ]
        for expected in (
            "cmd:features",
            "cmd:apps",
            "cmd:projects",
            "cmd:models",
            "cmd:mcp",
            "cmd:config_view",
            "cmd:menu",
        ):
            self.assertIn(expected, callbacks)
        self.assertNotIn("cmd:modes", callbacks)
        self.assertNotIn("cmd:mode_plan", callbacks)
        self.assertNotIn("cmd:mode_toggle", callbacks)
        self.assertNotIn("cmd:mode_quick_toggle", callbacks)
        self.assertNotIn("cmd:guardian_settings", callbacks)
        self.assertNotIn("cmd:reviewer_settings", callbacks)


if __name__ == "__main__":
    unittest.main()
