import json
from unittest.mock import MagicMock

import pytest
from requests import Response, Session

from sharepoint import SharePointFile, SharePointFolder

# Base URLs for SharePoint API endpoints
FOLDER_URL = "https://example.com/_api/Web/GetFolderByServerRelativeUrl('/sites/demo/Shared Documents')"
FILES_URL = f"{FOLDER_URL}/Files"
FOLDERS_URL = f"{FOLDER_URL}/Folders"


def _mock_response(
    data: dict | None = None, status_code: int = 200, headers: dict | None = None
) -> Response:
    """Create a realistic ``requests.Response`` object with JSON data."""
    if headers is None:
        headers = {"Content-Type": "application/json;odata=verbose"}

    mock_resp = MagicMock(spec=Response)
    mock_resp.status_code = status_code
    mock_resp.headers = headers or {}
    mock_resp.ok = 200 <= status_code < 400
    mock_resp.json.return_value = data or {}
    mock_resp.text = json.dumps(data) if data else ""
    mock_resp.request = MagicMock()
    mock_resp.request.url = FOLDER_URL
    return mock_resp


@pytest.fixture
def mock_session():
    """Provide a mocked ``requests.Session``."""
    return MagicMock(spec=Session)


@pytest.fixture
def folder_metadata():
    """Typical folder metadata payload returned by SharePoint."""
    return {
        "d": {
            "__metadata": {"id": FOLDER_URL, "uri": FOLDER_URL, "type": "SP.Folder"},
            "Name": "Shared Documents",
            "UniqueId": "folder-guid",
            "ServerRelativeUrl": "/sites/demo/Shared Documents",
            "TimeCreated": "2023-04-01T12:00:00Z",
            "TimeLastModified": "2023-04-02T14:30:00Z",
            "Files": {"__deferred": {"uri": FILES_URL}},
            "Folders": {"__deferred": {"uri": FOLDERS_URL}},
        }
    }


def test_folder_properties(mock_session, folder_metadata):
    """Validate basic property access on ``SharePointFolder``."""
    mock_session.get.return_value = _mock_response(folder_metadata)

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    # Simple string properties
    assert folder.name == "Shared Documents"
    assert folder.id == "folder-guid"
    assert folder.relative_url == "/sites/demo/Shared Documents"


def test_get_files_returns_sharepointfile_instances(mock_session, folder_metadata):
    """``get_files`` should return a list of ``SharePointFile`` objects."""
    # First call – folder metadata
    mock_session.get.side_effect = [
        _mock_response(folder_metadata),  # metadata for the folder
        _mock_response(
            {
                "d": {
                    "results": [
                        {
                            "__metadata": {
                                "uri": "https://example.com/_api/Web/GetFileByServerRelativeUrl('/sites/demo/Shared Documents/file1.docx')"
                            },
                            "Name": "file1.docx",
                        },
                        {
                            "__metadata": {
                                "uri": "https://example.com/_api/Web/GetFileByServerRelativeUrl('/sites/demo/Shared Documents/file2.xlsx')"
                            },
                            "Name": "file2.xlsx",
                        },
                    ]
                }
            }
        ),  # response for the Files endpoint
    ]

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    files = folder.get_files()
    assert isinstance(files, list)
    assert len(files) == 2
    assert all(isinstance(sp_file, SharePointFile) for sp_file in files)

    # Verify that the underlying URLs are correctly passed to the ``SharePointFile`` ctor
    assert (
        files[0]._url
        == "https://example.com/_api/Web/GetFileByServerRelativeUrl('/sites/demo/Shared Documents/file1.docx')"
    )
    assert (
        files[1]._url
        == "https://example.com/_api/Web/GetFileByServerRelativeUrl('/sites/demo/Shared Documents/file2.xlsx')"
    )


def test_get_files_with_filters(mock_session, folder_metadata):
    """``get_files`` should respect filters parameter."""
    # Setup folder metadata and file response
    mock_session.get.side_effect = [
        _mock_response(folder_metadata),  # metadata for the folder
        _mock_response({"d": {"results": []}}),
    ]

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    # Call get_files with a filter
    filters = "Name eq 'test.docx'"
    folder.get_files(filters=filters)

    # Verify the correct URL was built with the filter
    expected_base_url = FILES_URL
    expected_filter_param = "$filter=Name eq 'test.docx'"

    # Check that a request was made with the filtered URL
    called_urls = [call[0][0] for call in mock_session.get.call_args_list]
    assert any(
        expected_base_url in url and expected_filter_param in url for url in called_urls
    )


def test_get_files_with_select_fields(mock_session, folder_metadata):
    """``get_files`` should respect select_fields parameter."""
    # Setup folder metadata and file response
    mock_session.get.side_effect = [
        _mock_response(folder_metadata),  # metadata for the folder
        _mock_response({"d": {"results": []}}),
    ]

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    # Call get_files with select_fields
    select_fields = ["Name", "Length"]
    folder.get_files(select_fields=select_fields)

    # Verify the correct URL was built with the select fields
    expected_base_url = FILES_URL

    # Check that a request was made with the select fields in URL
    called_urls = [call[0][0] for call in mock_session.get.call_args_list]
    assert any(expected_base_url in url for url in called_urls)
    # We won't check the exact select param since it's handled by build_query_url


def test_get_files_with_top_parameter(mock_session, folder_metadata):
    """``get_files`` should respect top parameter."""
    # Setup folder metadata and file response
    mock_session.get.side_effect = [
        _mock_response(folder_metadata),  # metadata for the folder
        _mock_response({"d": {"results": []}}),
    ]

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    # Call get_files with top parameter
    top = 5
    folder.get_files(top=top)

    # Verify the correct URL was built with the top parameter
    expected_base_url = FILES_URL
    expected_top_param = "$top=5"

    # Check that a request was made with the top parameter in URL
    called_urls = [call[0][0] for call in mock_session.get.call_args_list]
    assert any(
        expected_base_url in url and expected_top_param in url for url in called_urls
    )


def test_get_files_handles_empty_results(mock_session, folder_metadata):
    """``get_files`` should handle empty results gracefully."""
    # Setup folder metadata and empty file response
    mock_session.get.side_effect = [
        _mock_response(folder_metadata),  # metadata for the folder
        _mock_response({"d": {"results": []}}),
    ]

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    # Should not raise an exception and return an empty list
    files = folder.get_files()
    assert isinstance(files, list)
    assert len(files) == 0


def test_get_files_with_all_parameters(mock_session, folder_metadata):
    """``get_files`` should work correctly with all parameters combined."""
    # Setup folder metadata and file response
    mock_session.get.side_effect = [
        _mock_response(folder_metadata),  # metadata for the folder
        _mock_response(
            {
                "d": {
                    "results": [
                        {
                            "__metadata": {
                                "uri": "https://example.com/_api/Web/GetFileByServerRelativeUrl('/sites/demo/Shared Documents/file1.docx')"
                            },
                            "Name": "file1.docx",
                            "Length": 1024,
                        }
                    ]
                }
            }
        ),
    ]

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    # Call get_files with all parameters
    filters = "Length gt 0"
    select_fields = ["Name", "Length"]
    top = 10

    files = folder.get_files(filters=filters, select_fields=select_fields, top=top)

    # Verify the correct URL was built - check that the base URL was called
    expected_base_url = FILES_URL

    # Check that a request was made with the base URL
    called_urls = [call[0][0] for call in mock_session.get.call_args_list]
    assert any(expected_base_url in url for url in called_urls)

    # Should return properly constructed SharePointFile instances
    assert len(files) == 1
    assert isinstance(files[0], SharePointFile)
    assert (
        files[0]._url
        == "https://example.com/_api/Web/GetFileByServerRelativeUrl('/sites/demo/Shared Documents/file1.docx')"
    )


def test_get_file_validates_filename(mock_session, folder_metadata):
    """``get_file`` should validate that file_name is provided."""
    mock_session.get.return_value = _mock_response(folder_metadata)

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    # Should raise ValueError when file_name is not provided
    with pytest.raises(ValueError, match="`file_name` must be provided"):
        folder.get_file("")  # type: ignore


def test_get_file_returns_sharepointfile_instance(mock_session, folder_metadata):
    """``get_file`` should return a ``SharePointFile`` with the correct endpoint."""
    mock_session.get.return_value = _mock_response(folder_metadata)

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    file = folder.get_file(file_name="document.docx")
    expected_url = "https://example.com/_api/Web/GetFolderByServerRelativeUrl('/sites/demo/Shared Documents')/Files('document.docx')"
    assert isinstance(file, SharePointFile)
    assert file._url == expected_url


def test_add_file_text_content(mock_session, folder_metadata):
    """``add_file`` should upload text content correctly."""
    mock_session.get.return_value = _mock_response(folder_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock add file response
    add_file_response = MagicMock()
    add_file_response.json.return_value = {
        "d": {
            "__metadata": {
                "uri": "https://example.com/_api/Web/GetFileByServerRelativeUrl('/sites/demo/Shared Documents/newfile.txt')"
            }
        }
    }

    # Set up the side effect to return context info first, then add file response
    mock_session.post.side_effect = [context_info_mock, add_file_response]

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    content = "This is text content"
    file = folder.add_file("newfile.txt", content)

    assert isinstance(file, SharePointFile)
    assert (
        file._url
        == "https://example.com/_api/Web/GetFileByServerRelativeUrl('/sites/demo/Shared Documents/newfile.txt')"
    )


def test_add_file_binary_content(mock_session, folder_metadata):
    """``add_file`` should upload binary content correctly."""
    mock_session.get.return_value = _mock_response(folder_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock add file response
    add_file_response = MagicMock()
    add_file_response.json.return_value = {
        "d": {
            "__metadata": {
                "uri": "https://example.com/_api/Web/GetFileByServerRelativeUrl('/sites/demo/Shared Documents/newfile.bin')"
            }
        }
    }

    # Set up the side effect to return context info first, then add file response
    mock_session.post.side_effect = [context_info_mock, add_file_response]

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    content = b"This is binary content"
    file = folder.add_file("newfile.bin", content)

    assert isinstance(file, SharePointFile)
    assert (
        file._url
        == "https://example.com/_api/Web/GetFileByServerRelativeUrl('/sites/demo/Shared Documents/newfile.bin')"
    )


def test_add_file_with_overwrite_true(mock_session, folder_metadata):
    """``add_file`` should handle overwrite=True correctly."""
    mock_session.get.return_value = _mock_response(folder_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock add file response
    add_file_response = MagicMock()
    add_file_response.json.return_value = {
        "d": {
            "__metadata": {
                "uri": "https://example.com/_api/Web/GetFileByServerRelativeUrl('/sites/demo/Shared Documents/newfile.txt')"
            }
        }
    }

    # Set up the side effect to return context info first, then add file response
    mock_session.post.side_effect = [context_info_mock, add_file_response]

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    content = "This is text content"
    file = folder.add_file("newfile.txt", content, overwrite=True)

    assert isinstance(file, SharePointFile)


def test_add_file_with_overwrite_false(mock_session, folder_metadata):
    """``add_file`` should handle overwrite=False correctly."""
    mock_session.get.return_value = _mock_response(folder_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock add file response
    add_file_response = MagicMock()
    add_file_response.json.return_value = {
        "d": {
            "__metadata": {
                "uri": "https://example.com/_api/Web/GetFileByServerRelativeUrl('/sites/demo/Shared Documents/newfile.txt')"
            }
        }
    }

    # Set up the side effect to return context info first, then add file response
    mock_session.post.side_effect = [context_info_mock, add_file_response]

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    content = "This is text content"
    file = folder.add_file("newfile.txt", content, overwrite=False)

    assert isinstance(file, SharePointFile)


def test_base_url_property(mock_session, folder_metadata):
    """Test base URL property derivation."""
    mock_session.get.return_value = _mock_response(folder_metadata)

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    # The base URL should be derived from the folder URL
    expected_base_url = "https://example.com/"
    assert folder.base_url == expected_base_url


def test_form_digest_value_property(mock_session, folder_metadata):
    """Test form digest value property."""
    mock_session.get.return_value = _mock_response(folder_metadata)

    # Mock context info response
    context_response = MagicMock()
    context_response.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "test-form-digest-value"}}
    }
    mock_session.post.return_value = context_response

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    # Access the property to trigger the call
    digest_value = folder._form_digestive_value
    assert digest_value == "test-form-digest-value"

    # Verify the context info endpoint was called (allowing for other parameters)
    mock_session.post.assert_called()
    # Just check that it was called, not the exact parameters since SharePointAPI adds headers


# -----------------------------------------------------------------
# Tests for create_subfolder method
# -----------------------------------------------------------------


def test_create_subfolder_validates_folder_name(mock_session, folder_metadata):
    """``create_subfolder`` should validate that folder_name is provided."""
    mock_session.get.return_value = _mock_response(folder_metadata)

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    # Should raise ValueError when folder_name is not provided
    with pytest.raises(ValueError, match="`folder_name` must be provided"):
        folder.create_subfolder("")  # type: ignore


def test_create_subfolder_calls_correct_endpoint_and_payload(mock_session, folder_metadata):
    """``create_subfolder`` should call the correct endpoint and send proper payload."""
    mock_session.get.return_value = _mock_response(folder_metadata)

    # Mock form digest value
    context_response = MagicMock()
    context_response.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "test-form-digest-value"}}
    }

    # Mock subfolder creation response
    subfolder_response = _mock_response({
        "d": {
            "__metadata": {
                "uri": "https://example.com/_api/Web/GetFolderByServerRelativeUrl('/sites/demo/Shared Documents/subfolder')"
            },
            "Name": "subfolder",
            "ServerRelativeUrl": "/sites/demo/Shared Documents/subfolder"
        }
    })

    # Set up side effects for sequential calls
    mock_session.post.side_effect = [context_response, subfolder_response]

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    # Call create_subfolder
    folder.create_subfolder("subfolder")

    # Check that we called the right endpoint with the correct data and headers
    called = False
    for call_args in mock_session.post.call_args_list:
        args, kwargs = call_args
        url = args[0] if args else None
        # Check if this is the subfolder creation call (not the context info call)
        if url and url.endswith("/Folders"):
            # Check that the payload includes the right ServerRelativeUrl
            post_data = kwargs.get("json")
            assert post_data is not None
            assert post_data.get("ServerRelativeUrl") == "/sites/demo/Shared Documents/subfolder"

            # Check that the headers include the form digest
            headers = kwargs.get("headers", {})
            assert headers.get("X-RequestDigest") == "test-form-digest-value"
            called = True
            break

    assert called, "Expected subfolder creation call was not found"


def test_create_subfolder_returns_sharepointfolder_instance(mock_session, folder_metadata):
    """``create_subfolder`` should return a ``SharePointFolder`` instance."""
    mock_session.get.return_value = _mock_response(folder_metadata)

    # Mock form digest value
    context_response = MagicMock()
    context_response.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "test-form-digest-value"}}
    }

    # Mock subfolder creation response with proper metadata
    subfolder_response = _mock_response({
        "d": {
            "__metadata": {
                "uri": "https://example.com/_api/Web/GetFolderByServerRelativeUrl('/sites/demo/Shared Documents/subfolder')",
                "type": "SP.Folder"
            },
            "Name": "subfolder",
            "UniqueId": "subfolder-guid",
            "ServerRelativeUrl": "/sites/demo/Shared Documents/subfolder",
            "TimeCreated": "2023-04-01T12:00:00Z",
            "TimeLastModified": "2023-04-02T14:30:00Z"
        }
    })

    # Set up side effects for sequential calls
    mock_session.post.side_effect = [context_response, subfolder_response]

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    # Call create_subfolder
    result = folder.create_subfolder("subfolder")

    # Should return a SharePointFolder instance
    assert isinstance(result, SharePointFolder)

    # The relative_url property needs to fetch the metadata, so let's make sure
    # the mock session returns the right data when get is called on the new folder
    mock_session.get.return_value = subfolder_response

    assert result.relative_url == "/sites/demo/Shared Documents/subfolder"


def test_create_subfolder_handles_failure_gracefully(mock_session, folder_metadata):
    """``create_subfolder`` should handle API failures gracefully."""
    mock_session.get.return_value = _mock_response(folder_metadata)

    # Mock form digest value
    context_response = MagicMock()
    context_response.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "test-form-digest-value"}}
    }

    # Mock API failure
    mock_session.post.side_effect = [context_response, Exception("API Error")]

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    # Should still handle gracefully even though our method doesn't explicitly catch exceptions here
    # (since our implementation lets the SharePointAPI handle error responses)
    with pytest.raises(Exception):
        folder.create_subfolder("subfolder")


# -----------------------------------------------------------------
# Tests for delete method
# -----------------------------------------------------------------


def test_delete_calls_correct_endpoint_with_delete_header(mock_session, folder_metadata):
    """``delete`` should call the correct endpoint with X-HTTP-Method header."""
    mock_session.get.return_value = _mock_response(folder_metadata)

    # Mock form digest value
    context_response = MagicMock()
    context_response.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "test-form-digest-value"}}
    }

    # Mock successful deletion response
    delete_response = MagicMock()
    delete_response.ok = True
    delete_response.status_code = 200

    # Set up side effects for sequential calls
    mock_session.post.side_effect = [context_response, delete_response]

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    # Call delete method
    result = folder.delete()

    # Verify success
    assert result is True

    # Check that we called the right endpoint with DELETE header
    called = False
    for call_args in mock_session.post.call_args_list:
        args, kwargs = call_args
        url = args[0] if args else None
        # Check if this is the delete call (not the context info call)
        if url == FOLDER_URL:
            # Check that the headers include the DELETE method and form digest
            headers = kwargs.get("headers", {})
            assert headers.get("X-HTTP-Method") == "DELETE"
            assert headers.get("X-RequestDigest") == "test-form-digest-value"
            called = True
            break

    assert called, "Expected delete call was not found"


def test_delete_returns_false_on_api_error(mock_session, folder_metadata):
    """``delete`` should return False when API returns an error."""
    mock_session.get.return_value = _mock_response(folder_metadata)

    # Mock form digest value
    context_response = MagicMock()
    context_response.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "test-form-digest-value"}}
    }

    # Mock API failure
    delete_response = MagicMock()
    delete_response.ok = False
    delete_response.status_code = 403  # Forbidden

    # Set up side effects for sequential calls
    mock_session.post.side_effect = [context_response, delete_response]

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    # Call delete method
    result = folder.delete()

    # Should return False for API error
    assert result is False


def test_delete_handles_exception_during_request(mock_session, folder_metadata):
    """``delete`` should return False when exception occurs during request."""
    mock_session.get.return_value = _mock_response(folder_metadata)

    # Mock form digest value
    context_response = MagicMock()
    context_response.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "test-form-digest-value"}}
    }

    # Set up side effects to raise exception on delete call
    def side_effect(*args, **kwargs):
        if mock_session.post.call_count == 1:
            return context_response
        else:
            raise Exception("Network error")

    mock_session.post.side_effect = side_effect

    folder = SharePointFolder(
        url=FOLDER_URL,
        session=mock_session,
    )

    # Call delete method
    result = folder.delete()

    # Should return False for exceptions
    assert result is False
