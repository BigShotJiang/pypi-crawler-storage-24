from __future__ import annotations

from datetime import datetime
from typing import Optional
from urllib.parse import urljoin

from ._base import SharePointBase


class SharePointListItemVersion(SharePointBase):
    """
    Represents a generic version of a SharePoint list item.
    """

    _base_url = None

    @property
    def base_url(self) -> str:
        """Base URL of the SharePoint site (without the '_api' part)."""
        if not self._base_url:
            self._base_url = self._url.split("_api")[0]
        return self._base_url

    @property
    def _form_digestive_value(self) -> str:
        """Form digest value required for POST/PUT/MERGE operations."""
        context_info_url = urljoin(self.base_url.rstrip("/") + "/", "_api/contextinfo")
        r = self._api.post(context_info_url, {})

        return r.json()["d"]["GetContextWebInformation"]["FormDigestValue"]

    @property
    def id(self) -> Optional[str]:
        """The unique version id"""
        return self.get("VersionId")

    @property
    def version_label(self) -> Optional[str]:
        """The version label."""
        return self.get("VersionLabel")

    @property
    def title(self) -> Optional[str]:
        """Title of the list item."""
        return self.get("Title")

    @property
    def modified(self) -> Optional[datetime]:
        """Timestamp when the item was last modified."""
        return self.get_datetime("Modified")
