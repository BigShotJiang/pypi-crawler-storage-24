## Typing stubs for paramiko

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`paramiko`](https://github.com/paramiko/paramiko) package. It can be used by type checkers
to check code that uses `paramiko`. This version of
`types-paramiko` aims to provide accurate annotations for
`paramiko==4.0.*`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/paramiko`](https://github.com/python/typeshed/tree/main/stubs/paramiko)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 1.19.1
* [pyright](https://github.com/microsoft/pyright) 1.1.408

It was generated from typeshed commit
[`282b1a838a565f10a4b2e9139adc26ab828b2e9d`](https://github.com/python/typeshed/commit/282b1a838a565f10a4b2e9139adc26ab828b2e9d).