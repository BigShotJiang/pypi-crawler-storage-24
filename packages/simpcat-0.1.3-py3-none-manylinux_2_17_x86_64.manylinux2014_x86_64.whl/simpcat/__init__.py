"""simpcat — drop-in replacement for wandb."""

from __future__ import annotations

import os
import subprocess
from importlib.metadata import version as _meta_version, PackageNotFoundError
from typing import Any

try:
    __version__ = _meta_version("simpcat")
except PackageNotFoundError:
    __version__ = "0.0.0"

from simpcat.experiment import Run, NoOpRun, Summary
from simpcat.histogram import Histogram
from simpcat.media import Audio, Image
from simpcat.api import Api, ApiError

__all__ = ["init", "log", "finish", "define_metric", "login",
           "Run", "NoOpRun", "Summary", "Audio", "Image", "Histogram",
           "Api", "ApiError"]

try:
    from simpcat.logger import SimpCatLogger
    __all__.append("SimpCatLogger")
except ImportError:
    pass

_active_run: Run | NoOpRun | None = None


def init(
    project: str | None = None,
    name: str | None = None,
    config: dict[str, Any] | None = None,
    mode: str | None = None,
    scratch: bool = False,
    tags: dict[str, str] | None = None,
    notes: str | None = None,
    group: str | None = None,
    job_type: str | None = None,
    system_metrics: bool = True,
    system_metrics_interval: float = 15.0,
    capture_output: bool = False,
    resume: str | bool | None = None,
    id: str | None = None,
    fork_from: str | None = None,
    fork_step: int | None = None,
    **kwargs: Any,
) -> Run | NoOpRun:
    """Initialize a new run. Matches wandb.init() interface.

    Auto-finishes any previously active run. Returns a NoOpRun when
    mode="disabled".

    After calling init(), the active run is also accessible via module-level
    attributes: ``simpcat.run``, ``simpcat.config``, ``simpcat.summary``,
    and ``simpcat.dir``.

    Args:
        project: Project name. Defaults to "default".
        name: Run display name. Auto-generated if not provided.
        config: Initial hyperparameter dict, accessible as run.config.
        mode: Set to "disabled" to return a NoOpRun that discards all data.
        scratch: If True, the run is hidden from the default run list.
        tags: Dict of key-value tags for filtering runs.
        notes: Free-text description of the run.
        group: Group name for organizing related runs.
        job_type: Job type label (e.g. "train", "eval").
        system_metrics: Collect CPU/memory/GPU metrics in background. Default True.
        system_metrics_interval: Seconds between system metric samples. Default 15.0.
        capture_output: Capture stdout/stderr to files/output.log. Default False.
        resume: Resume mode — True/"allow" (try resume, create if missing),
            "must" (fail if missing), "never" (fail if exists), "auto" (read
            resume.json for saved run ID), or False/None (fresh run).
            Env var: SIMPCAT_RESUME.
        id: Explicit run ID. Auto-generated (8 hex chars) if not provided.
            Env var: SIMPCAT_RUN_ID.
        fork_from: Run ID to fork from. Must be paired with fork_step.
        fork_step: Step to fork from. The new run's step counter starts here.
    """
    global _active_run

    # Auto-finish previous run
    if _active_run is not None:
        _active_run.finish()
        _active_run = None

    # Env var defaults
    if resume is None and os.environ.get("SIMPCAT_RESUME"):
        env_resume = os.environ["SIMPCAT_RESUME"].lower()
        if env_resume in ("true", "1"):
            resume = True
        elif env_resume in ("false", "0"):
            resume = False
        else:
            resume = env_resume
    if id is None and os.environ.get("SIMPCAT_RUN_ID"):
        id = os.environ["SIMPCAT_RUN_ID"]

    if mode == "disabled":
        _active_run = NoOpRun()
        return _active_run

    _active_run = Run(
        project=project or "default",
        name=name,
        config=config,
        scratch=scratch,
        tags=tags,
        notes=notes,
        group=group,
        job_type=job_type,
        system_metrics=system_metrics,
        system_metrics_interval=system_metrics_interval,
        capture_output=capture_output,
        resume=resume,
        id=id,
        fork_from=fork_from,
        fork_step=fork_step,
        **kwargs,
    )
    return _active_run


def log(data: dict[str, Any], step: int | None = None, commit: bool | None = None) -> None:
    """Log metrics to the active run. Matches wandb.log().

    Args:
        data: Dict of metric names to values (scalars, Audio, Image, or lists of media).
        step: Explicit step. If None, uses the auto-incrementing counter.
        commit: Controls when metrics are flushed. None (default) means True when
            step is None, False when step is provided. True flushes all buffered
            and current metrics and advances the step counter. False buffers scalars
            until the next commit=True call.

    Raises:
        RuntimeError: If no run is active (call simpcat.init() first).
    """
    if _active_run is None:
        raise RuntimeError("Call simpcat.init() before simpcat.log()")
    _active_run.log(data, step=step, commit=commit)


def finish(status: str = "finished") -> None:
    """Finish the active run. Matches wandb.finish().

    Stops system metrics collection, flushes remaining data, and shuts down
    the daemon. No-op if no run is active. Runs are also auto-finished via
    atexit on process exit.

    Args:
        status: Final run status — "finished" (default) or "failed".
    """
    global _active_run
    if _active_run is not None:
        _active_run.finish(status)
        _active_run = None


def define_metric(name: str, step_metric: str | None = None, summary: str | None = None, **kwargs: Any) -> None:
    """Define metric metadata (custom x-axis, summary aggregation).

    No-op if both step_metric and summary are None.

    Args:
        name: The metric name (e.g. "val/loss").
        step_metric: Another metric to use as x-axis (e.g. "epoch").
        summary: Aggregation type for the run summary table —
            "min", "max", "last", "mean", or "best" (resolves to min/max based on goal).

    Raises:
        RuntimeError: If no run is active (call simpcat.init() first).
    """
    if _active_run is None:
        raise RuntimeError("Call simpcat.init() before simpcat.define_metric()")
    _active_run.define_metric(name, step_metric=step_metric, summary=summary, **kwargs)


def login(key: str | None = None, host: str | None = None, **_kwargs: Any) -> bool:
    """Programmatic login. Matches wandb.login() interface.

    Shells out to the ``simpcat login`` CLI binary to verify the key and
    store credentials in ~/.simpcat/config.toml.

    Args:
        key: API key. If None, prompts interactively.
        host: Server host. Defaults to simpcat.ai (or SIMPCAT_HOST env var).

    Returns:
        True if login succeeded, False otherwise.

    Raises:
        RuntimeError: If the simpcat binary is not found.
    """
    from simpcat.daemon import _find_daemon_binary
    binary = _find_daemon_binary()
    if binary is None:
        raise RuntimeError(
            "simpcat: 'simpcat' binary not found. "
            "Install it or set SIMPCAT_CLI_PATH=/path/to/simpcat."
        )

    cmd = [binary, "login"]
    if key is not None:
        cmd.extend(["--key", key])
    if host is not None:
        cmd.extend(["--host", host])

    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.returncode == 0


def __getattr__(name: str) -> Any:
    if name == "run":
        return _active_run
    if name == "config":
        return _active_run.config if _active_run is not None else None
    if name == "summary":
        return _active_run.summary if _active_run is not None else None
    if name == "dir":
        if _active_run is not None and hasattr(_active_run, "_run_dir"):
            return str(_active_run._run_dir)
        return None
    raise AttributeError(f"module 'simpcat' has no attribute {name!r}")
