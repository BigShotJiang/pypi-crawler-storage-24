"""SimpCatLogger — PyTorch Lightning Logger implementation."""

from __future__ import annotations

import os
from argparse import Namespace
from typing import Any, Mapping

try:
    from lightning.pytorch.loggers import Logger
    from lightning.pytorch.utilities import rank_zero_only
except ImportError:
    raise ImportError(
        "lightning is required for SimpCatLogger. "
        "Install it with: pip install lightning"
    )

from simpcat.experiment import Run, NoOpRun


def _is_rank_zero() -> bool:
    """Check if current process is rank 0."""
    rank = os.environ.get("LOCAL_RANK", os.environ.get("RANK", "0"))
    return rank == "0"


class SimpCatLogger(Logger):
    """Lightning Logger that sends metrics to the simpcat daemon.

    Drop-in replacement for WandbLogger with compatible API surface.
    Accepts a pre-created Run via ``run=`` to share with simpcat.init().
    """

    def __init__(
        self,
        project: str | None = None,
        name: str | None = None,
        save_dir: str | None = None,
        mode: str | None = None,
        scratch: bool = False,
        run: Run | NoOpRun | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__()
        self._project = project
        self._name = name
        self._save_dir = save_dir or "."
        self._scratch = scratch
        self._mode = mode or os.environ.get("SIMPCAT_MODE")
        self._run = run

    @property
    def name(self) -> str:
        return self._project or "default"

    @property
    def version(self) -> str:
        return self.experiment.id

    @property
    def experiment(self) -> Run | NoOpRun:
        if self._run is None:
            if self._mode == "disabled" or not _is_rank_zero():
                self._run = NoOpRun()
            else:
                self._run = Run(
                    project=self._project or "default",
                    name=self._name,
                    scratch=self._scratch,
                )
        return self._run

    @rank_zero_only
    def log_hyperparams(self, params: dict[str, Any] | Namespace) -> None:
        if isinstance(params, Namespace):
            params = vars(params)
        self.experiment.config.update(params)

    @rank_zero_only
    def log_metrics(self, metrics: Mapping[str, float], step: int | None = None) -> None:
        self.experiment.log(dict(metrics), step=step, commit=True)

    @rank_zero_only
    def finalize(self, status: str) -> None:
        if self._run is not None:
            mapped = "finished" if status == "success" else "failed"
            self._run.finish(mapped)
