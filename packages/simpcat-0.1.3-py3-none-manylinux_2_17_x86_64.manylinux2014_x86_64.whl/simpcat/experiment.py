"""Run — wandb-compatible run interface wrapping MetricsClient."""

from __future__ import annotations

import atexit
import datetime
import getpass
import json
import os
import platform
import secrets
import sys
import threading
import time
from pathlib import Path
from typing import Any

from simpcat.client import MetricsClient
from simpcat.histogram import Histogram
from simpcat.media import Audio, Image
from simpcat.sysmetrics import SystemMetricsCollector


def _find_simpcat_dir() -> Path:
    """Find or create the .simpcat/ directory.

    Checks SIMPCAT_DIR env var first, else creates in CWD.
    """
    env_dir = os.environ.get("SIMPCAT_DIR")
    if env_dir:
        p = Path(env_dir)
        p.mkdir(parents=True, exist_ok=True)
        return p

    simpcat_dir = Path.cwd() / ".simpcat"
    simpcat_dir.mkdir(exist_ok=True)
    return simpcat_dir


def _create_run_dir(run_id: str) -> Path:
    """Create the run directory structure inside .simpcat/."""
    simpcat_dir = _find_simpcat_dir()
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = simpcat_dir / f"run-{timestamp}-{run_id}"

    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "files").mkdir(exist_ok=True)
    (run_dir / "logs").mkdir(exist_ok=True)
    (run_dir / "media").mkdir(exist_ok=True)

    return run_dir


def _update_symlinks(simpcat_dir: Path, run_dir: Path) -> None:
    """Update latest-run and debug.log symlinks atomically."""
    latest_link = simpcat_dir / "latest-run"
    tmp_link = simpcat_dir / f".tmp-latest-{os.getpid()}"
    try:
        tmp_link.symlink_to(run_dir)
        os.replace(str(tmp_link), str(latest_link))
    except OSError:
        pass

    debug_link = simpcat_dir / "debug.log"
    tmp_debug = simpcat_dir / f".tmp-debug-{os.getpid()}"
    try:
        tmp_debug.symlink_to(latest_link / "logs" / "debug.log")
        os.replace(str(tmp_debug), str(debug_link))
    except OSError:
        pass


def _collect_sys_info() -> dict[str, Any]:
    """Collect system metadata (hostname, OS, GPU, CPU, program, args)."""
    info: dict[str, Any] = {
        "hostname": platform.node(),
        "os": platform.platform(),
        "python": platform.python_version(),
        "cpu_count": os.cpu_count(),
        "program": sys.argv[0] if sys.argv else "",
        "args": sys.argv[1:] if len(sys.argv) > 1 else [],
    }

    try:
        info["username"] = getpass.getuser()
    except Exception:
        pass

    try:
        import subprocess
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0:
            gpus = result.stdout.strip().split("\n")
            info["gpu"] = gpus[0] if gpus else None
            info["gpu_count"] = len(gpus)
    except Exception:
        pass

    return info


def _write_metadata(
    run_dir: Path,
    run_id: str,
    run_name: str,
    project: str,
    daemon_pid: int,
) -> dict[str, Any]:
    """Write simpcat-metadata.json with system and git info. Returns sys info."""
    sys_info = _collect_sys_info()
    metadata: dict[str, Any] = {
        "run_id": run_id,
        "run_name": run_name,
        "project": project,
        "daemon_pid": daemon_pid,
        "started_at": datetime.datetime.now().isoformat(),
        **sys_info,
    }

    try:
        from simpcat.git_info import get_git_info
        git_info = get_git_info()
        if git_info:
            metadata["git"] = git_info
    except Exception:
        pass

    (run_dir / "files" / "simpcat-metadata.json").write_text(
        json.dumps(metadata, indent=2)
    )
    return sys_info


def _write_git_diff(run_dir: Path) -> None:
    """Write git diff to files/diff.patch."""
    try:
        import subprocess
        result = subprocess.run(
            ["git", "diff", "HEAD"], capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0 and result.stdout.strip():
            (run_dir / "files" / "diff.patch").write_text(result.stdout)
    except Exception:
        pass


class Config:
    """Dict-like config object that syncs updates to the daemon immediately.

    Supports both dict-style (config["lr"]) and attribute-style (config.lr)
    access for wandb compatibility. Every write immediately sends the full
    config to the daemon and writes config.json to the run directory.
    """

    def __init__(self, run: Run) -> None:
        object.__setattr__(self, "_run", run)
        object.__setattr__(self, "_data", {})

    def update(self, data: dict[str, Any]) -> None:
        self._data.update(data)
        if self._run._client is not None:
            self._run._client.send_config(self._data)
        self._run._write_config_file()

    def setdefaults(self, data: dict[str, Any]) -> None:
        """Set default values without overwriting existing keys. Matches wandb.config.setdefaults()."""
        changed = False
        for k, v in data.items():
            if k not in self._data:
                self._data[k] = v
                changed = True
        if changed:
            if self._run._client is not None:
                self._run._client.send_config(self._data)
            self._run._write_config_file()

    def keys(self) -> Any:
        """Return config keys."""
        return self._data.keys()

    def items(self) -> Any:
        """Return config key-value pairs."""
        return self._data.items()

    def get(self, key: str, default: Any = None) -> Any:
        """Get a value by key with an optional default."""
        return self._data.get(key, default)

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self._data[key] = value
        if self._run._client is not None:
            self._run._client.send_config(self._data)
        self._run._write_config_file()

    def __getattr__(self, key: str) -> Any:
        try:
            return self._data[key]
        except KeyError:
            raise AttributeError(f"Config has no attribute {key!r}")

    def __setattr__(self, key: str, value: Any) -> None:
        self._data[key] = value
        if self._run._client is not None:
            self._run._client.send_config(self._data)
        self._run._write_config_file()

    def __contains__(self, key: str) -> bool:
        return key in self._data

    def to_dict(self) -> dict[str, Any]:
        return dict(self._data)


class Summary:
    """Dict-like run summary object that syncs to the daemon.

    Tracks per-run aggregate values (e.g., best_val_loss). Matches wandb.summary.
    Accessible as run.summary or simpcat.summary. Supports both dict-style
    and attribute-style access, including deletion.
    """

    def __init__(self, run: Run) -> None:
        object.__setattr__(self, "_run", run)
        object.__setattr__(self, "_data", {})

    def update(self, data: dict[str, Any]) -> None:
        """Merge a dict into the summary."""
        self._data.update(data)
        if self._run._client is not None:
            self._run._client.send_summary(self._data)

    def keys(self) -> Any:
        """Return summary keys."""
        return self._data.keys()

    def items(self) -> Any:
        """Return summary key-value pairs."""
        return self._data.items()

    def get(self, key: str, default: Any = None) -> Any:
        """Get a value by key with an optional default."""
        return self._data.get(key, default)

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self._data[key] = value
        if self._run._client is not None:
            self._run._client.send_summary(self._data)

    def __getattr__(self, key: str) -> Any:
        try:
            return self._data[key]
        except KeyError:
            raise AttributeError(f"Summary has no attribute {key!r}")

    def __setattr__(self, key: str, value: Any) -> None:
        self._data[key] = value
        if self._run._client is not None:
            self._run._client.send_summary(self._data)

    def __delitem__(self, key: str) -> None:
        del self._data[key]
        if self._run._client is not None:
            self._run._client.send_summary(self._data)

    def __delattr__(self, key: str) -> None:
        try:
            del self._data[key]
        except KeyError:
            raise AttributeError(f"Summary has no attribute {key!r}")
        if self._run._client is not None:
            self._run._client.send_summary(self._data)

    def __contains__(self, key: str) -> bool:
        return key in self._data

    def to_dict(self) -> dict[str, Any]:
        return dict(self._data)


class Run:
    """Manages a single training run's connection to the simpcat daemon.

    Matches wandb.Run interface: log(), finish(), config, summary, context manager.
    """

    def __init__(
        self,
        project: str,
        name: str | None = None,
        config: dict[str, Any] | None = None,
        scratch: bool = False,
        tags: dict[str, str] | None = None,
        notes: str | None = None,
        group: str | None = None,
        job_type: str | None = None,
        system_metrics: bool = True,
        system_metrics_interval: float = 15.0,
        capture_output: bool = False,
        resume: str | bool | None = None,
        id: str | None = None,
        fork_from: str | None = None,
        fork_step: int | None = None,
        **_kwargs: Any,
    ) -> None:
        self._project = project
        self._name = name or f"run-{secrets.token_hex(4)}"
        self._scratch = scratch
        self._tags = tags or {}
        if "user" not in self._tags:
            try:
                self._tags["user"] = getpass.getuser()
            except Exception:
                pass
        self._notes = notes
        self._group = group
        self._job_type = job_type

        # Normalize resume mode: bool → string, validate
        if resume is True:
            self._resume: str | None = "allow"
        elif resume is False or resume is None:
            self._resume = None
        elif isinstance(resume, str):
            valid_modes = ("must", "allow", "never", "auto")
            if resume not in valid_modes:
                raise ValueError(
                    f"Invalid resume mode {resume!r}. Must be one of: {', '.join(valid_modes)}"
                )
            self._resume = resume
        else:
            raise ValueError(f"Invalid resume type: {type(resume)}")

        self._run_id = id if id is not None else secrets.token_hex(4)

        # Auto-resume: read .simpcat/resume.json for saved run ID
        if self._resume == "auto":
            resume_file = _find_simpcat_dir() / "resume.json"
            if resume_file.exists():
                try:
                    saved = json.loads(resume_file.read_text())
                    saved_id = saved.get("run_id")
                    if saved_id and id is None:
                        self._run_id = saved_id
                        self._resume = "allow"
                except (json.JSONDecodeError, OSError):
                    pass
            if self._resume == "auto":
                # No saved run found — fall through to fresh run
                self._resume = None

        # Explicit modes require an ID
        if self._resume in ("must", "allow", "never") and id is None and self._resume != "allow":
            # "allow" can work without an explicit id (uses generated one)
            # "must" and "never" need a specific run to check
            pass  # We still let it through — server will 404 for "must"

        self._resumed = False
        self._server_config: dict[str, Any] | None = None

        # Fork validation
        if fork_from is not None and fork_step is None:
            raise ValueError("fork_step is required when fork_from is set")
        if fork_step is not None and fork_from is None:
            raise ValueError("fork_from is required when fork_step is set")
        if fork_from is not None and self._resume is not None:
            raise ValueError("Cannot combine fork_from with resume=True")
        if fork_step is not None and fork_step < 0:
            raise ValueError("fork_step must be >= 0")

        self._fork_from = fork_from
        self._fork_step = fork_step

        self._client: MetricsClient | None = None
        self._step = fork_step if fork_step is not None else 0
        self._uncommitted: dict[str, Any] = {}
        self._metric_definitions: dict[str, dict[str, Any]] = {}
        self._lock = threading.Lock()
        self._finish_lock = threading.Lock()
        self._finished = False
        self._daemon_proc: Any = None
        self.config = Config(self)
        self.summary = Summary(self)

        # Create run directory structure
        self._run_dir = _create_run_dir(self._run_id)
        self._staging_dir = str(self._run_dir / "media")

        # Update symlinks
        _update_symlinks(self._run_dir.parent, self._run_dir)

        # Spawn per-run daemon
        from simpcat.daemon import spawn_run_daemon
        self._daemon_proc, self._socket_path = spawn_run_daemon(
            self._run_dir, self._run_id
        )

        # Write metadata (needs daemon_pid)
        self._sys_info = _write_metadata(
            self._run_dir, self._run_id, self._name,
            self._project, self._daemon_proc.pid,
        )

        # Write git diff
        _write_git_diff(self._run_dir)

        # Connect client (eagerly — dynamic metric extension means no lazy init)
        self._client = MetricsClient(
            project=self._project,
            name=self._name,
            daemon_socket_path=self._socket_path,
            scratch=self._scratch,
            tags=self._tags,
            notes=self._notes,
            group=self._group,
            job_type=self._job_type,
            resume=self._resume,
            config=config,
            fork_from=self._fork_from,
            fork_step=self._fork_step,
        )

        # Wait for daemon to confirm init succeeded
        self._wait_for_init()

        # Start error log watcher thread
        self._error_watch_stop = threading.Event()
        self._error_watcher = threading.Thread(
            target=self._tail_error_log,
            daemon=True,
            name="simpcat-error-watcher",
        )
        self._error_watcher.start()

        # Build merged config: server config (resume base) → git → sys → user
        if self._server_config:
            self.config._data.update(self._server_config)

        # Auto-capture git provenance into config
        try:
            from simpcat.git_info import get_git_info
            git_info = get_git_info()
            if git_info:
                self.config._data.update({"git": git_info})
        except Exception:
            pass

        # Inject system metadata into config
        if self._sys_info:
            self.config._data["sys"] = self._sys_info

        if config:
            self.config._data.update(config)

        # Send a single merged config POST (init already bundled the user's
        # config atomically, but git info was added after init so we need
        # one POST with the full merged config).
        if self.config._data and self._client is not None:
            self._client.send_config(self.config._data)
            self._write_config_file()

        # Write resume.json so future resume="auto" can find this run
        if self._resume is not None:
            try:
                resume_file = _find_simpcat_dir() / "resume.json"
                resume_file.write_text(json.dumps({"run_id": self._run_id}))
            except OSError:
                pass

        # Start system metrics collection
        self._sysmetrics: SystemMetricsCollector | None = None
        if system_metrics:
            self._sysmetrics = SystemMetricsCollector(self, interval=system_metrics_interval)

        # Console output capture
        self._capture: Any = None
        if capture_output:
            try:
                from simpcat.capture import OutputCapture
                self._capture = OutputCapture(
                    self._run_dir / "files" / "output.log",
                )
                self._capture.start()
            except Exception:
                pass

        # Print run URL for quick access (wandb-compatible)
        if not scratch:
            print(f"simpcat: Run {self._name} - {self.url}")

        atexit.register(self.finish)

    @property
    def id(self) -> str:
        """Run ID (8 hex chars)."""
        return self._run_id

    @property
    def name(self) -> str:
        """Display name. Writable — setting it updates the server."""
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        self._name = value
        if self._client is not None:
            self._client.send_update({"name": value})

    @property
    def tags(self) -> dict[str, str]:
        """Tags dict. Writable — assign a dict to update."""
        return dict(self._tags)

    @tags.setter
    def tags(self, value: dict[str, str]) -> None:
        self._tags = dict(value)
        if self._client is not None:
            self._client.send_update({"tags": self._tags})

    @property
    def notes(self) -> str | None:
        """Free-text notes. Writable."""
        return self._notes

    @notes.setter
    def notes(self, value: str | None) -> None:
        self._notes = value
        if self._client is not None:
            self._client.send_update({"notes": value})

    @property
    def project(self) -> str:
        """Project name."""
        return self._project

    @property
    def group(self) -> str | None:
        """Group name."""
        return self._group

    @property
    def job_type(self) -> str | None:
        """Job type label."""
        return self._job_type

    @property
    def step(self) -> int:
        """Current global step counter."""
        return self._step

    @property
    def dir(self) -> str:
        """Path to the run directory."""
        return str(self._run_dir)

    @property
    def resumed(self) -> bool:
        """Whether this run was resumed from a previous run."""
        return self._resumed

    @property
    def url(self) -> str | None:
        """URL to the run page on the web UI."""
        host = os.environ.get("SIMPCAT_HOST", "simpcat.ai")
        if host.startswith("http://") or host.startswith("https://"):
            base = host.rstrip("/")
        elif host.startswith("localhost") or host.startswith("127.0.0.1") or host.startswith("[::1]"):
            base = f"http://{host}"
        else:
            base = f"https://{host}"
        return f"{base}/run/{self._run_id}"

    def _wait_for_init(self, timeout: float = 10.0) -> None:
        """Poll for daemon init status file. Raises on failure or timeout."""
        status_file = self._run_dir / "init.status"
        env_timeout = os.environ.get("SIMPCAT_INIT_TIMEOUT")
        if env_timeout is not None:
            timeout = float(env_timeout)

        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if status_file.exists():
                try:
                    result = json.loads(status_file.read_text())
                    if result.get("ok"):
                        # Restore state from resume data if present
                        if result.get("resumed"):
                            self._resumed = True
                            if "currentStep" in result:
                                self._step = int(result["currentStep"])
                            if "metricNames" in result and result["metricNames"] and self._client is not None:
                                names = result["metricNames"]
                                self._client._metric_names = list(names)
                                self._client._name_to_idx = {n: i for i, n in enumerate(names)}
                            if "metricDefinitions" in result and result["metricDefinitions"]:
                                self._metric_definitions = result["metricDefinitions"]
                            if "config" in result and result["config"]:
                                self._server_config = result["config"]
                            if "summary" in result and result["summary"]:
                                for key, val in result["summary"].items():
                                    if isinstance(val, dict) and "last" in val:
                                        self.summary._data[key] = val["last"]
                                    elif isinstance(val, (int, float)):
                                        self.summary._data[key] = val
                        return
                    error = result.get("error", "unknown error")
                    raise RuntimeError(
                        f"simpcat: daemon failed to initialize run: {error}"
                    )
                except json.JSONDecodeError:
                    pass
            time.sleep(0.1)

        raise RuntimeError(
            f"simpcat: daemon did not confirm init within {timeout}s — "
            f"check {self._run_dir / 'logs' / 'debug.log'}"
        )

    def _tail_error_log(self) -> None:
        """Background thread that tails errors.log and emits warnings."""
        import warnings
        errors_path = self._run_dir / "logs" / "errors.log"
        pos = 0
        while not self._error_watch_stop.wait(timeout=1.0):
            try:
                if errors_path.exists():
                    with open(errors_path) as f:
                        f.seek(pos)
                        for line in f:
                            line = line.strip()
                            if line:
                                # Extract message after tab-separated timestamp
                                parts = line.split("\t", 1)
                                msg = parts[1] if len(parts) > 1 else line
                                warnings.warn(f"simpcat daemon: {msg}", stacklevel=1)
                        pos = f.tell()
            except Exception:
                pass

    def _write_config_file(self) -> None:
        """Write config.json to run dir."""
        try:
            config_path = self._run_dir / "files" / "config.json"
            config_path.write_text(json.dumps(self.config._data, indent=2, default=str))
        except Exception:
            pass

    def log(self, data: dict[str, Any], step: int | None = None, commit: bool | None = None) -> None:
        """Log metrics and/or media. Matches wandb.log() interface.

        Args:
            data: Dict of metric names to values (scalars, Audio, Image,
                or lists of media objects).
            step: Explicit step. If None, uses auto-incrementing counter.
            commit: Controls when metrics are flushed. None (default) means
                True when step is None, False when step is provided.
                True flushes all buffered and current metrics and advances
                the step counter. False buffers scalars until the next
                commit=True call. Media is sent immediately regardless.
        """
        if commit is None:
            commit = step is None
        with self._lock:
            if not commit:
                for key, value in data.items():
                    if isinstance(value, (int, float)):
                        self._uncommitted[key] = value
                    elif isinstance(value, Histogram):
                        effective_step = step if step is not None else self._step
                        if self._client is not None:
                            self._client.send_histogram(effective_step, key, value)
                    elif isinstance(value, (Audio, Image)):
                        effective_step = step if step is not None else self._step
                        media_file = self._stage_media(effective_step, key, value)
                        if self._client is not None:
                            self._client.send_media(effective_step, [media_file])
                    elif isinstance(value, list):
                        effective_step = step if step is not None else self._step
                        media_files = []
                        for i, item in enumerate(value):
                            item_key = f"{key}/{i}" if len(value) > 1 else key
                            if isinstance(item, (Audio, Image)):
                                media_files.append(self._stage_media(effective_step, item_key, item))
                        if media_files and self._client is not None:
                            self._client.send_media(effective_step, media_files)
                return

            # commit=True: merge buffered data with current data
            merged = {**self._uncommitted, **data}
            self._uncommitted = {}

            scalars: dict[str, float] = {}
            media_files: list[dict[str, Any]] = []
            effective_step = step if step is not None else self._step

            for key, value in merged.items():
                if isinstance(value, (int, float)):
                    scalars[key] = float(value)
                elif isinstance(value, Histogram):
                    if self._client is not None:
                        self._client.send_histogram(effective_step, key, value)
                elif isinstance(value, Audio):
                    media_files.append(self._stage_media(effective_step, key, value))
                elif isinstance(value, Image):
                    media_files.append(self._stage_media(effective_step, key, value))
                elif isinstance(value, list):
                    for i, item in enumerate(value):
                        item_key = f"{key}/{i}" if len(value) > 1 else key
                        if isinstance(item, (Audio, Image)):
                            media_files.append(self._stage_media(effective_step, item_key, item))

            if scalars and self._client is not None:
                self._client.log_dict(effective_step, scalars)

            if media_files and self._client is not None:
                self._client.send_media(effective_step, media_files)

            if step is None:
                self._step += 1

    def define_metric(self, name: str, step_metric: str | None = None, summary: str | None = None, **kwargs: Any) -> None:
        """Define metric metadata (custom x-axis, summary aggregation).

        Args:
            name: The metric name (e.g., "val_loss").
            step_metric: Another metric to use as x-axis (e.g., "epoch").
            summary: Aggregation type for run summary: "min", "max", "last", "mean", or "best" (resolves to min/max based on goal).
        """
        definition: dict[str, Any] = {}
        if step_metric is not None:
            definition["step_metric"] = step_metric
        if summary is not None:
            definition["summary"] = summary
        if not definition:
            return
        self._metric_definitions[name] = definition
        if self._client is not None:
            self._client.send_define_metric(name, definition)

    def _stage_media(self, step: int, key: str, media: Audio | Image) -> dict[str, Any]:
        """Write media to staging dir and return file descriptor dict."""
        safe_key = key.replace("/", "__")
        if isinstance(media, Audio):
            filename = f"{step}_{safe_key}.wav"
            path = os.path.join(self._staging_dir, filename)
            media.save(path)
            return {
                "path": path,
                "key": key,
                "media_type": "audio",
                "caption": media.caption,
                "sample_rate": media.sample_rate,
            }
        else:
            filename = f"{step}_{safe_key}.png"
            path = os.path.join(self._staging_dir, filename)
            media.save(path)
            return {
                "path": path,
                "key": key,
                "media_type": "image",
                "caption": media.caption,
            }

    def finish(self, status: str = "finished") -> None:
        """Finish the run, flush remaining data, and shut down the daemon.

        Safe to call multiple times. Also registered with atexit so it runs
        automatically on process exit.

        Args:
            status: Final run status — "finished" (default) or "failed".
        """
        with self._finish_lock:
            if self._finished:
                return
            self._finished = True
        atexit.unregister(self.finish)

        # Stop error watcher
        if hasattr(self, '_error_watch_stop'):
            self._error_watch_stop.set()

        # Clean up resume.json on successful finish (keep on failure for auto-resume)
        if status == "finished":
            try:
                resume_file = _find_simpcat_dir() / "resume.json"
                if resume_file.exists():
                    saved = json.loads(resume_file.read_text())
                    if saved.get("run_id") == self._run_id:
                        resume_file.unlink()
            except (json.JSONDecodeError, OSError):
                pass
        if self._sysmetrics is not None:
            self._sysmetrics.stop()
            self._sysmetrics = None
        if self._capture is not None:
            self._capture.stop()
            self._capture = None
        with self._lock:
            client = self._client
            self._client = None
        if client is not None:
            if self._uncommitted:
                client.log_dict(self._step, self._uncommitted)
                self._uncommitted = {}
                self._step += 1
            client.send_finish(status)
            client.close()
        # Close daemon stdin pipe to signal shutdown, then wait for clean exit
        if self._daemon_proc is not None:
            try:
                if self._daemon_proc.stdin:
                    self._daemon_proc.stdin.close()
                self._daemon_proc.wait(timeout=10)
            except Exception:
                pass

    def __enter__(self) -> Run:
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        status = "failed" if exc_type is not None else "finished"
        self.finish(status)


class NoOpRun:
    """Drop-in replacement that does nothing. Used when mode='disabled'."""

    def __init__(self) -> None:
        self.config = _NoOpConfig()
        self.summary = _NoOpConfig()
        self._run_id = "noop"
        self._name = "noop"
        self._tags: dict[str, str] = {}
        self._notes: str | None = None
        self._step = 0
        self._resumed = False

    @property
    def id(self) -> str:
        return self._run_id

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        self._name = value

    @property
    def tags(self) -> dict[str, str]:
        return dict(self._tags)

    @tags.setter
    def tags(self, value: dict[str, str]) -> None:
        self._tags = dict(value)

    @property
    def notes(self) -> str | None:
        return self._notes

    @notes.setter
    def notes(self, value: str | None) -> None:
        self._notes = value

    @property
    def step(self) -> int:
        return self._step

    @property
    def resumed(self) -> bool:
        return self._resumed

    @property
    def project(self) -> str:
        return ""

    @property
    def url(self) -> str | None:
        return None

    def log(self, data: dict[str, Any], step: int | None = None, commit: bool | None = None) -> None:
        pass

    def define_metric(self, name: str, step_metric: str | None = None, **kwargs: Any) -> None:
        pass

    def finish(self, status: str = "finished") -> None:
        pass

    def __enter__(self) -> NoOpRun:
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        pass


class _NoOpConfig:
    def update(self, data: dict[str, Any]) -> None:
        pass

    def __getitem__(self, key: str) -> Any:
        return None

    def __setitem__(self, key: str, value: Any) -> None:
        pass

    def __getattr__(self, key: str) -> Any:
        return None

    def __setattr__(self, key: str, value: Any) -> None:
        pass

    def __contains__(self, key: str) -> bool:
        return False

    def to_dict(self) -> dict[str, Any]:
        return {}
