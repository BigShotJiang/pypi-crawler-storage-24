"""MetricsClient — Unix stream socket IPC to simpcat daemon."""

from __future__ import annotations

import os
import socket
import struct
import threading
import time
import warnings
from typing import Any

import msgpack

_SLOW_SEND_THRESHOLD_S = 0.1  # 100ms
_DEBUG = os.environ.get("SIMPCAT_DEBUG") is not None


class MetricsClient:
    """Sends length-prefixed msgpack messages to the simpcat daemon over a Unix stream socket.

    Methods never raise on the hot path and avoid blocking in practice (the daemon
    drains the socket continuously), but sendall() may block briefly under extreme
    backpressure.  If the daemon is unreachable, messages are silently dropped with
    periodic warnings.

    Wire format: 4-byte big-endian u32 length prefix + msgpack payload (same framing as WAL).

    Note: run_id is NOT included in messages — the per-run daemon knows its own run_id.
    """

    def __init__(
        self,
        project: str,
        name: str,
        daemon_socket_path: str,
        scratch: bool = False,
        metric_names: list[str] | None = None,
        tags: dict[str, str] | None = None,
        notes: str | None = None,
        group: str | None = None,
        job_type: str | None = None,
        resume: str | None = None,
        config: dict[str, Any] | None = None,
        fork_from: str | None = None,
        fork_step: int | None = None,
    ) -> None:
        self._addr = daemon_socket_path
        self._metric_names: list[str] = list(metric_names or [])
        self._name_to_idx: dict[str, int] = {n: i for i, n in enumerate(self._metric_names)}
        self._metrics_lock = threading.Lock()
        self._send_lock = threading.Lock()
        self._drop_count = 0
        self._dead = False

        self._sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self._sock.setblocking(True)
        try:
            self._sock.connect(self._addr)
        except OSError as e:
            self._dead = True
            warnings.warn(
                f"simpcat: failed to connect to daemon at {self._addr}: {e}",
                stacklevel=2,
            )

        init_msg: dict[str, Any] = {
            "type": "init",
            "version": 1,
            "project": project,
            "name": name,
            "scratch": scratch,
            "metric_names": self._metric_names,
        }
        if tags:
            init_msg["tags"] = tags
        if notes:
            init_msg["notes"] = notes
        if group:
            init_msg["group"] = group
        if job_type:
            init_msg["job_type"] = job_type
        if resume:
            init_msg["resume"] = resume
        if config:
            init_msg["config"] = config
        if fork_from:
            init_msg["fork_from"] = fork_from
        if fork_step is not None:
            init_msg["fork_step"] = fork_step
        self._send(init_msg)

    def log_dict(self, step: int, metrics: dict[str, float]) -> None:
        """Send a compact metric vector for one training step."""
        updated_names: list[str] | None = None

        with self._metrics_lock:
            new_keys = [k for k in metrics if k not in self._name_to_idx]
            if new_keys:
                for k in new_keys:
                    self._name_to_idx[k] = len(self._metric_names)
                    self._metric_names.append(k)
                updated_names = list(self._metric_names)

            values = [float('nan')] * len(self._metric_names)
            for name, val in metrics.items():
                values[self._name_to_idx[name]] = float(val)

        if updated_names is not None:
            self._send({
                "type": "metric_names",
                "metric_names": updated_names,
            })

        self._send({
            "type": "m",
            "s": step,
            "t": time.time(),
            "v": values,
        })

    def send_config(self, data: dict[str, Any]) -> None:
        """Send hyperparameter config to daemon."""
        self._send({
            "type": "config",
            "data": data,
        })

    def send_finish(self, status: str = "finished") -> None:
        """Notify daemon that this run is complete."""
        self._send({
            "type": "finish",
            "status": status,
        })

    def send_media(self, step: int, files: list[dict[str, Any]]) -> None:
        """Notify daemon about staged media files."""
        self._send({
            "type": "media",
            "step": step,
            "files": files,
        })

    def send_define_metric(self, name: str, definition: dict[str, Any]) -> None:
        """Send a metric definition to daemon."""
        self._send({
            "type": "define_metric",
            "name": name,
            "definition": definition,
        })

    def send_histogram(self, step: int, name: str, histogram: Any) -> None:
        """Send histogram data to daemon."""
        self._send({
            "type": "histogram",
            "s": step,
            "t": time.time(),
            "n": name,
            "bin_edges": histogram.bin_edges,
            "counts": histogram.counts,
        })

    def send_update(self, fields: dict[str, Any]) -> None:
        """Send a run metadata update (name, tags, notes) to daemon."""
        self._send({
            "type": "update",
            "fields": fields,
        })

    def send_summary(self, data: dict[str, Any]) -> None:
        """Send run summary values to daemon."""
        self._send({
            "type": "summary",
            "data": data,
        })

    def _send(self, msg: dict[str, Any]) -> None:
        if self._dead:
            return
        payload = msgpack.packb(msg, use_bin_type=True)
        frame = struct.pack(">I", len(payload)) + payload
        with self._send_lock:
            try:
                t0 = time.monotonic()
                self._sock.sendall(frame)
                elapsed = time.monotonic() - t0
                if elapsed > _SLOW_SEND_THRESHOLD_S:
                    warnings.warn(
                        f"simpcat: slow send ({elapsed * 1000:.0f}ms) — daemon may be overloaded",
                        stacklevel=3,
                    )
                if _DEBUG:
                    warnings.warn(
                        f"simpcat debug: send {len(payload)} bytes in {elapsed * 1000:.1f}ms",
                        stacklevel=3,
                    )
            except (BrokenPipeError, ConnectionResetError):
                self._dead = True
                warnings.warn(
                    "simpcat: daemon connection lost — run data may be incomplete",
                    stacklevel=3,
                )
            except OSError:
                self._drop_count += 1
                if self._drop_count == 1:
                    warnings.warn(
                        f"simpcat: send error to daemon at {self._addr}. "
                        "Messages will be dropped silently.",
                        stacklevel=3,
                    )
                elif self._drop_count % 1000 == 0:
                    warnings.warn(
                        f"simpcat: dropped {self._drop_count} messages",
                        stacklevel=3,
                    )

    def close(self) -> None:
        try:
            self._sock.close()
        except OSError:
            pass
