"""Question-specific context retrieval for chat and agent workflows."""

from __future__ import annotations

import asyncio
import re
from typing import Any

from pydantic import BaseModel, Field

from services.auth import UserContext
from services.knowledge import KnowledgeItem, KnowledgeListFilters, list_knowledge_items
from services.quick_metrics import list_quick_metrics


class ContextBrief(BaseModel):
    """Bounded context assembled for a specific question."""

    relevant_metrics: list[dict[str, Any]] = Field(default_factory=list)
    relevant_dimensions: list[dict[str, Any]] = Field(default_factory=list)
    relevant_quick_metrics: list[dict[str, Any]] = Field(default_factory=list)
    knowledge_items: list[KnowledgeItem] = Field(default_factory=list)
    caveats: list[str] = Field(default_factory=list)
    suggested_filters: list[str] = Field(default_factory=list)
    unresolved_gaps: list[str] = Field(default_factory=list)


def _normalize(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", text.lower().replace("_", " ")).strip()


def _tokenize(text: str) -> set[str]:
    return {token for token in _normalize(text).split() if len(token) > 1}


def _score_text(normalized_question: str, question_tokens: set[str], *texts: str) -> int:
    score = 0

    for text in texts:
        normalized = _normalize(text)
        if not normalized:
            continue
        if normalized in normalized_question:
            score += 20
        tokens = _tokenize(text)
        overlap = len(question_tokens & tokens)
        score += overlap * 3

    return score


def _metric_payload(metric: Any) -> dict[str, Any]:
    # metric.type is either an enum (has .value) or a class instance
    metric_type = getattr(metric.type, "value", None) or type(metric.type).__name__
    return {
        "name": metric.name,
        "description": metric.description or "",
        "type": metric_type,
    }


def _dimension_payload(dimension: Any) -> dict[str, Any]:
    dim_type = getattr(dimension.type, "value", None) or str(dimension.type)
    return {
        "name": dimension.name,
        "description": getattr(dimension, "description", "") or "",
        "type": dim_type,
    }


def _dashboard_context_lines(dashboard_context: Any | None) -> list[str]:
    if not dashboard_context:
        return []
    lines = []
    controls = getattr(dashboard_context, "controls", None)
    if controls:
        date_range = getattr(controls, "date_range", {})
        lines.append(
            f"- Dashboard controls: {date_range.get('from', 'n/a')} to {date_range.get('to', 'n/a')} at {controls.grain} grain"
        )
    pages = getattr(dashboard_context, "pages", [])
    if pages:
        page_titles = ", ".join(page.title for page in pages[:4])
        lines.append(f"- Dashboard pages: {page_titles}")
    return lines


async def retrieve_context_brief(
    user: UserContext,
    manifest: Any,
    question: str,
    *,
    business_context: str | None = None,
    dashboard_context: Any | None = None,
) -> ContextBrief:
    """Build a question-specific context brief from manifest and org knowledge."""
    del business_context  # Included later by render_context_brief when present.

    # Pre-compute question tokens once for all scoring calls.
    normalized_question = _normalize(question)
    question_tokens = _tokenize(question)

    metrics = [_metric_payload(metric) for metric in getattr(manifest, "metrics", [])]
    metric_candidates = []
    for metric in metrics:
        score = _score_text(normalized_question, question_tokens, metric["name"], metric["description"])
        if score > 0:
            metric_candidates.append((score, metric))
    metric_candidates.sort(key=lambda item: (-item[0], item[1]["name"]))
    relevant_metrics = [payload for _, payload in metric_candidates[:6]]

    dimensions_seen: set[str] = set()
    dimension_candidates = []
    for model in getattr(manifest, "semantic_models", []):
        for dimension in getattr(model, "dimensions", []) or []:
            payload = _dimension_payload(dimension)
            if payload["name"] in dimensions_seen:
                continue
            dimensions_seen.add(payload["name"])
            score = _score_text(normalized_question, question_tokens, payload["name"], payload["description"])
            if score > 0:
                dimension_candidates.append((score, payload))
    dimension_candidates.sort(key=lambda item: (-item[0], item[1]["name"]))
    relevant_dimensions = [payload for _, payload in dimension_candidates[:8]]

    # Fetch quick metrics and knowledge items concurrently.
    quick_metrics_result, knowledge_items_raw = await asyncio.gather(
        list_quick_metrics(user),
        list_knowledge_items(user, KnowledgeListFilters(limit=100)),
    )

    quick_metric_candidates = []
    for quick_metric in quick_metrics_result:
        description = quick_metric.description or ""
        score = _score_text(normalized_question, question_tokens, quick_metric.name, description, quick_metric.expression)
        if score > 0:
            quick_metric_candidates.append((
                score,
                {
                    "name": f"qm:{quick_metric.name}",
                    "description": description,
                    "expression": quick_metric.expression,
                },
            ))
    quick_metric_candidates.sort(key=lambda item: (-item[0], item[1]["name"]))
    relevant_quick_metrics = [payload for _, payload in quick_metric_candidates[:5]]

    # NOTE: Fetches up to 100 items and scores in Python. Rejected items
    # are excluded by the scoring filter below (status penalty + explicit check).
    # If an org accumulates 200+ active items, consider server-side
    # filtering by applies_to_metrics or a vector search index.
    knowledge_candidates = []
    top_metric_names = [metric["name"] for metric in relevant_metrics[:3]]
    top_dimension_names = [dimension["name"] for dimension in relevant_dimensions[:3]]

    for item in knowledge_items_raw:
        text_score = _score_text(normalized_question, question_tokens, item.title, item.content, *item.subjects)
        metric_overlap = len(set(top_metric_names) & set(item.applies_to_metrics))
        dimension_overlap = len(set(top_dimension_names) & set(item.applies_to_dimensions))
        score = text_score + metric_overlap * 6 + dimension_overlap * 4
        score += {
            "reviewed": 12,
            "proposed": 2,
            "superseded": -4,
            "rejected": -10,
        }.get(item.status, 0)
        if (text_score > 0 or metric_overlap > 0 or dimension_overlap > 0) and score > 0 and item.status != "rejected":
            knowledge_candidates.append((score, item))

    knowledge_candidates.sort(key=lambda item: (-item[0], item[1].title.lower()))
    selected_knowledge = [item for _, item in knowledge_candidates[:6]]

    caveats = []
    suggested_filters = []
    for item in selected_knowledge:
        if item.type in {"data_quirk", "join_rule"}:
            caveats.append(f"{item.title}: {item.content}")
        if item.type == "filter_rule":
            suggested_filters.append(f"{item.title}: {item.content}")

    unresolved_gaps = []
    if not relevant_metrics and not relevant_quick_metrics:
        unresolved_gaps.append("No strongly matching metrics found in the manifest or quick metrics.")
    if any(word in question.lower() for word in ("by ", "per ", "top ", "breakdown", "segment")) and not relevant_dimensions:
        unresolved_gaps.append("The question suggests a breakdown, but no strong dimension match was retrieved.")

    # Fold dashboard context into the gap/caveat surface without bloating the core brief.
    caveats.extend(_dashboard_context_lines(dashboard_context))

    return ContextBrief(
        relevant_metrics=relevant_metrics,
        relevant_dimensions=relevant_dimensions,
        relevant_quick_metrics=relevant_quick_metrics,
        knowledge_items=selected_knowledge,
        caveats=caveats,
        suggested_filters=suggested_filters,
        unresolved_gaps=unresolved_gaps,
    )


def render_context_brief(
    brief: ContextBrief,
    *,
    business_context: str | None = None,
) -> str:
    """Render a context brief into prompt-friendly markdown."""
    sections: list[str] = ["## Question-Specific Context"]

    if brief.relevant_metrics:
        metric_lines = [
            f"- {metric['name']}: {metric['description'] or metric['type']}"
            for metric in brief.relevant_metrics
        ]
        sections.append("### Relevant Metrics\n" + "\n".join(metric_lines))

    if brief.relevant_dimensions:
        dimension_lines = [
            f"- {dimension['name']}: {dimension['description'] or dimension['type']}"
            for dimension in brief.relevant_dimensions
        ]
        sections.append("### Relevant Dimensions\n" + "\n".join(dimension_lines))

    if brief.relevant_quick_metrics:
        quick_metric_lines = [
            f"- {metric['name']}: {metric['description'] or metric['expression']}"
            for metric in brief.relevant_quick_metrics
        ]
        sections.append("### Relevant Quick Metrics\n" + "\n".join(quick_metric_lines))

    if brief.knowledge_items:
        knowledge_lines = [
            f"- [{item.status} {item.type}] {item.title}: {item.content}"
            for item in brief.knowledge_items
        ]
        sections.append("### Retrieved Org Knowledge\n" + "\n".join(knowledge_lines))

    if brief.caveats:
        sections.append("### Caveats\n" + "\n".join(f"- {caveat}" for caveat in brief.caveats))

    if brief.suggested_filters:
        sections.append(
            "### Suggested Filters\n" + "\n".join(f"- {item}" for item in brief.suggested_filters)
        )

    if brief.unresolved_gaps:
        sections.append(
            "### Unresolved Gaps\n" + "\n".join(f"- {gap}" for gap in brief.unresolved_gaps)
        )

    if business_context:
        trimmed = business_context.strip()
        if trimmed:
            sections.append("### Business Context\n" + trimmed[:1200])

    return "\n\n".join(sections)
