"""User context accumulation for agent personalization.

Stores and retrieves user-specific presentation preferences.
Data is stored per-user in Firestore at users/{uid}/preferences/context.

This enables agents to:
- Remember user formatting preferences (currency, decimals, grain)
- Track favorite metrics for quick access
- Apply chart preferences to future interactions
"""

# Migration note (2026-03): Removed `notes` and `custom_instructions` fields.
# Existing Firestore documents may still contain these fields; they are
# silently ignored by Pydantic and cleared on the next full save.

from typing import Any

from pydantic import BaseModel, Field

import storage


ALLOWED_PREFERENCE_FIELDS = {
    "default_currency",
    "default_grain",
    "decimal_places",
    "favorite_metrics",
    "preferred_chart_type",
}


class UserPreferences(BaseModel):
    """Accumulated context for a user - read/updated by agents."""

    # Format preferences
    default_currency: str | None = None
    default_grain: str | None = None
    decimal_places: int | None = None

    # Behavioral preferences
    favorite_metrics: list[str] = Field(default_factory=list)
    preferred_chart_type: str | None = None

    # Timestamp
    updated_at: str | None = None


async def get_user_preferences(user_id: str) -> UserPreferences:
    """Get accumulated context for a user.

    Returns empty UserPreferences if none exists.

    Args:
        user_id: User's UID

    Returns:
        UserPreferences instance
    """
    data = storage.get_user_preferences(user_id)
    if data is None:
        return UserPreferences()
    return UserPreferences.model_validate(data)


async def update_user_preferences(
    user_id: str,
    updates: dict[str, Any],
) -> UserPreferences:
    """Update user preferences (merge, not replace).

    Only provided fields are updated; others remain unchanged.

    Args:
        user_id: User's UID
        updates: Fields to update (merged with existing)

    Returns:
        Updated UserPreferences
    """
    invalid_keys = sorted(set(updates) - ALLOWED_PREFERENCE_FIELDS)
    if invalid_keys:
        raise ValueError(
            f"Unsupported preference fields: {', '.join(invalid_keys)}"
        )

    current = await get_user_preferences(user_id)
    current_dict = current.model_dump(exclude_none=True)

    for key, value in updates.items():
        current_dict[key] = value

    validated = UserPreferences.model_validate(current_dict)

    saved = storage.save_user_preferences(
        user_id, validated.model_dump(exclude_none=True)
    )
    return UserPreferences.model_validate(saved)


async def add_favorite(user_id: str, metric_name: str) -> UserPreferences:
    """Add a metric to favorites.

    Args:
        user_id: User's UID
        metric_name: Name of the metric to add

    Returns:
        Updated UserPreferences
    """
    current = await get_user_preferences(user_id)
    favorites = list(current.favorite_metrics)
    if metric_name not in favorites:
        favorites.append(metric_name)
    return await update_user_preferences(user_id, {"favorite_metrics": favorites})


async def remove_favorite(user_id: str, metric_name: str) -> UserPreferences:
    """Remove a metric from favorites.

    Args:
        user_id: User's UID
        metric_name: Name of the metric to remove

    Returns:
        Updated UserPreferences
    """
    current = await get_user_preferences(user_id)
    favorites = [m for m in current.favorite_metrics if m != metric_name]
    return await update_user_preferences(user_id, {"favorite_metrics": favorites})
