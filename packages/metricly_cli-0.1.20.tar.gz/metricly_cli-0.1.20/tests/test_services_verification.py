"""Tests for answer verification heuristics."""

from services.retrieval import ContextBrief
from services.verification import verify_answer


def test_quant_question_without_query_needs_retry():
    result = verify_answer("What is total revenue this month?", query_history=[])
    assert result.needs_retry is True
    assert result.gaps


def test_breakdown_without_dimension_needs_retry():
    brief = ContextBrief(relevant_metrics=[{"name": "total_revenue"}], relevant_dimensions=[{"name": "region"}])
    result = verify_answer(
        "Show total revenue by region",
        query_history=[
            {
                "params": {"metrics": ["total_revenue"], "dimensions": [], "grain": None},
                "row_count": 1,
                "columns": ["total_revenue"],
                "error": None,
            }
        ],
        brief=brief,
    )
    assert result.needs_retry is True
    assert any("no dimensions" in gap.lower() for gap in result.gaps)


def test_matching_query_stays_high_confidence():
    brief = ContextBrief(
        relevant_metrics=[{"name": "total_revenue"}],
        relevant_dimensions=[{"name": "region"}],
    )
    result = verify_answer(
        "Show total revenue by region",
        query_history=[
            {
                "params": {
                    "metrics": ["total_revenue"],
                    "dimensions": ["region"],
                    "grain": None,
                    "start_date": "2026-03-01",
                    "end_date": "2026-03-31",
                },
                "row_count": 5,
                "columns": ["region", "total_revenue"],
                "error": None,
            }
        ],
        brief=brief,
    )
    assert result.needs_retry is False
    assert result.confidence > 0.8


def test_non_analytical_question_without_query_is_fine():
    """Conversational questions shouldn't demand a metric query."""
    result = verify_answer("Can you show me how the dashboard works?", query_history=[])
    assert result.needs_retry is False
    assert result.confidence > 0.7


def test_greeting_without_query_is_fine():
    result = verify_answer("Hello, what can you help me with?", query_history=[])
    assert result.needs_retry is False


def test_zero_rows_adds_warning():
    result = verify_answer(
        "Show revenue by region",
        query_history=[
            {
                "params": {"metrics": ["total_revenue"], "dimensions": ["region"], "grain": None},
                "row_count": 0,
                "columns": ["region", "total_revenue"],
                "error": None,
            }
        ],
    )
    assert any("zero rows" in w.lower() for w in result.warnings)


def test_grain_mismatch_detected():
    from services.retrieval import ContextBrief

    result = verify_answer(
        "Show monthly revenue",
        query_history=[
            {
                "params": {"metrics": ["total_revenue"], "dimensions": [], "grain": "day"},
                "row_count": 30,
                "columns": ["metric_time__day", "total_revenue"],
                "error": None,
            }
        ],
        brief=ContextBrief(relevant_metrics=[{"name": "total_revenue"}]),
    )
    assert result.needs_retry is True
    assert any("grain" in gap.lower() for gap in result.gaps)


def test_time_reference_without_date_range_warns():
    result = verify_answer(
        "What was revenue last month?",
        query_history=[
            {
                "params": {"metrics": ["total_revenue"], "dimensions": [], "grain": "month"},
                "row_count": 1,
                "columns": ["total_revenue"],
                "error": None,
            }
        ],
    )
    assert any("time window" in w.lower() or "date range" in w.lower() for w in result.warnings)


def test_only_failed_queries_retries():
    result = verify_answer(
        "What is total revenue?",
        query_history=[
            {
                "params": {"metrics": ["total_revenue"]},
                "row_count": 0,
                "columns": [],
                "error": "Metric not found",
            }
        ],
    )
    assert result.needs_retry is True
    assert result.confidence < 0.3
