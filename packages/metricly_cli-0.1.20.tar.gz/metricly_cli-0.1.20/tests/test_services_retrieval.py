"""Tests for retrieval-based context briefs."""

from types import SimpleNamespace
from unittest.mock import patch

import pytest

from services.auth import UserContext
from services.knowledge import KnowledgeItem
from services.retrieval import render_context_brief, retrieve_context_brief


def make_user() -> UserContext:
    return UserContext(
        uid="user-123",
        email="user@example.com",
        org_id="org-123",
        org_name="Metricly",
        role="admin",
    )


def make_manifest():
    revenue_metric = SimpleNamespace(name="total_revenue", description="Revenue after discounts", type=SimpleNamespace(value="simple"))
    orders_metric = SimpleNamespace(name="order_count", description="Number of orders", type=SimpleNamespace(value="simple"))
    region_dimension = SimpleNamespace(name="region", description="Customer region", type=SimpleNamespace(value="categorical"))
    segment_dimension = SimpleNamespace(name="customer_segment", description="Customer segment", type=SimpleNamespace(value="categorical"))
    model = SimpleNamespace(dimensions=[region_dimension, segment_dimension])
    return SimpleNamespace(metrics=[revenue_metric, orders_metric], semantic_models=[model])


@pytest.mark.asyncio
async def test_reviewed_knowledge_ranks_above_proposed():
    knowledge_items = [
        KnowledgeItem(
            id="k1",
            org_id="org-123",
            type="data_quirk",
            title="Revenue excludes refunds",
            content="Exclude refunded orders from revenue comparisons.",
            status="reviewed",
            confidence=0.9,
            source="admin_authored",
            created_by="user-123",
            created_at="2026-03-09T08:00:00Z",
            updated_at="2026-03-09T08:00:00Z",
        ),
        KnowledgeItem(
            id="k2",
            org_id="org-123",
            type="data_quirk",
            title="Revenue import lag",
            content="Revenue can lag by two days after month end.",
            status="proposed",
            confidence=0.5,
            source="agent_learned",
            created_by="user-123",
            created_at="2026-03-09T08:00:00Z",
            updated_at="2026-03-09T08:00:00Z",
        ),
    ]

    with (
        patch("services.retrieval.list_quick_metrics", return_value=[]),
        patch("services.retrieval.list_knowledge_items", return_value=knowledge_items),
    ):
        brief = await retrieve_context_brief(
            make_user(),
            make_manifest(),
            "Show total revenue by region",
        )

    assert brief.relevant_metrics[0]["name"] == "total_revenue"
    assert brief.relevant_dimensions[0]["name"] == "region"
    assert brief.knowledge_items[0].status == "reviewed"


@pytest.mark.asyncio
async def test_irrelevant_knowledge_is_excluded():
    unrelated = KnowledgeItem(
        id="k3",
        org_id="org-123",
        type="business_term",
        title="Marketing MQL definition",
        content="MQLs are sourced from campaign handoffs.",
        status="reviewed",
        confidence=0.9,
        source="admin_authored",
        created_by="user-123",
        created_at="2026-03-09T08:00:00Z",
        updated_at="2026-03-09T08:00:00Z",
    )

    with (
        patch("services.retrieval.list_quick_metrics", return_value=[]),
        patch("services.retrieval.list_knowledge_items", return_value=[unrelated]),
    ):
        brief = await retrieve_context_brief(
            make_user(),
            make_manifest(),
            "What is total revenue by region?",
        )

    assert brief.knowledge_items == []


@pytest.mark.asyncio
async def test_render_context_brief_includes_business_context():
    with (
        patch("services.retrieval.list_quick_metrics", return_value=[]),
        patch("services.retrieval.list_knowledge_items", return_value=[]),
    ):
        brief = await retrieve_context_brief(
            make_user(),
            make_manifest(),
            "Show total revenue",
        )

    rendered = render_context_brief(brief, business_context="Finance uses net revenue as the north-star KPI.")
    assert "Relevant Metrics" in rendered
    assert "Business Context" in rendered
