"""
Cerberus MCP Server

A FastMCP subclass that instruments tool, resource, and prompt calls
for Cerberus monitoring. Wraps handlers to capture timing, errors,
and arguments, then sends events via WebSocket to the Cerberus pipeline.
"""

import asyncio
import functools
import logging
import os
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Optional
from weakref import WeakKeyDictionary

from mcp.server.fastmcp import FastMCP

from .structs import MCPEventData
from .transport import init_client, queue_event
from .utils import sanitize_arguments, summarize_result

logger = logging.getLogger(__name__)

DEBUG_ENABLED = os.getenv('CERBERUS_DEBUG', 'false').lower() in ('true', '1', 'yes')

USER_AGENT = "cerberus-mcp/0.1.0"

# Method names for event types
METHOD_TOOL_CALL = "mcp_tool_call"
METHOD_RESOURCE_READ = "mcp_resource_read"
METHOD_PROMPT_GET = "mcp_prompt_get"


class CerberusMCP(FastMCP):
    """FastMCP subclass that instruments MCP handlers for Cerberus monitoring.

    Wraps tool(), resource(), and prompt() decorator registrations to capture
    timing, errors, and arguments from each call. Events are sent to the
    Cerberus event_ingest backend using the same payload format as the
    cerberus_django middleware.

    Usage:
        from cerberus_mcp import CerberusMCP

        mcp = CerberusMCP(
            "my-server",
            cerberus_config={
                "token": "your-api-key",
                "client_id": "your-client-id",
                "ws_url": "ws://localhost:8765",
            }
        )

        @mcp.tool()
        def my_tool(query: str) -> str:
            return "result"
    """

    def __init__(self, name: str = "mcp", cerberus_config: Optional[Dict] = None, **kwargs):
        """Initialize CerberusMCP server.

        Args:
            name: Server name (used in endpoint paths)
            cerberus_config: Cerberus configuration dict with keys:
                - token: API key for authentication (required)
                - client_id: Client identifier (required)
                - ws_url: WebSocket URL for event_ingest (required)
                - server_name: Override server name in events (optional)
            **kwargs: Additional arguments passed to FastMCP
        """
        super().__init__(name, **kwargs)

        self._cerberus_config = cerberus_config or {}
        self._server_name = self._cerberus_config.get('server_name', name)
        self._session_ids: WeakKeyDictionary = WeakKeyDictionary()

        # Initialize transport if config is complete
        token = self._cerberus_config.get('token')
        client_id = self._cerberus_config.get('client_id')
        ws_url = self._cerberus_config.get('ws_url')

        if token and client_id and ws_url:
            init_client(ws_url, token, client_id)
            if DEBUG_ENABLED:
                logger.info(f"[CerberusMCP] Server '{self._server_name}' initialized with monitoring")
        else:
            logger.warning(
                "[CerberusMCP] Monitoring disabled. Missing token, client_id, or ws_url "
                "in cerberus_config"
            )

    def _get_session_id(self, session) -> str:
        """Get or create a UUID session ID for a ServerSession.

        Uses WeakKeyDictionary so session IDs are automatically cleaned up
        when the ServerSession is garbage collected.

        Args:
            session: MCP ServerSession object

        Returns:
            UUID string for this session
        """
        if session is None:
            return "no-session"
        if session not in self._session_ids:
            self._session_ids[session] = str(uuid.uuid4())
        return self._session_ids[session]

    def _extract_context_info(self, args, kwargs):
        """Extract identity info from Context argument and filter it from args.

        Looks for a Context object in the arguments, extracts session/client
        metadata from it, and returns cleaned args without the Context object.

        Args:
            args: Positional arguments tuple
            kwargs: Keyword arguments dict

        Returns:
            Tuple of (cleaned_kwargs, context_info_dict)
        """
        context_info = {}
        cleaned_kwargs = dict(kwargs)

        # Check kwargs for Context object
        ctx = None
        for key, value in kwargs.items():
            if _is_mcp_context(value):
                ctx = value
                cleaned_kwargs.pop(key, None)
                break

        # Also check positional args for Context
        if ctx is None:
            for arg in args:
                if _is_mcp_context(arg):
                    ctx = arg
                    break

        if ctx is not None:
            # Extract session info
            try:
                session = getattr(ctx, 'session', None)
                if session is not None:
                    context_info['session_id'] = self._get_session_id(session)
                    client_params = getattr(session, 'client_params', None)
                    if client_params is not None:
                        client_info = getattr(client_params, 'clientInfo', None)
                        if client_info is not None:
                            context_info['client_name'] = getattr(client_info, 'name', None)
                            context_info['client_version'] = getattr(client_info, 'version', None)
            except Exception:
                pass

            # Extract request_id and client_id
            try:
                context_info['request_id'] = getattr(ctx, 'request_id', None)
                context_info['mcp_client_id'] = getattr(ctx, 'client_id', None)
            except Exception:
                pass

        return cleaned_kwargs, context_info

    def _emit_event(
        self,
        handler_name: str,
        event_type: str,
        method: str,
        duration_ms: float,
        arguments: Optional[Dict],
        result: Any,
        error: Optional[str],
        context_info: Dict,
    ):
        """Create and queue an MCPEventData event.

        Args:
            handler_name: Name of the tool/resource/prompt
            event_type: One of tool_call, resource_read, prompt_get
            method: Event method (mcp_tool_call, mcp_resource_read, mcp_prompt_get)
            duration_ms: Call duration in milliseconds
            arguments: Sanitized arguments dict
            result: Raw result (will be summarized)
            error: Error message string or None
            context_info: Dict with session_id, client_name, etc.
        """
        token = self._cerberus_config.get('token', '')

        custom_data = {
            'mcp_server': self._server_name,
            'handler_name': handler_name,
            'event_type': event_type,
            'duration_ms': round(duration_ms, 2),
            'arguments': arguments,
            'error': error,
            'result_summary': summarize_result(result) if error is None else None,
            'session_id': context_info.get('session_id'),
            'client_name': context_info.get('client_name'),
            'client_version': context_info.get('client_version'),
            'request_id': context_info.get('request_id'),
            'mcp_client_id': context_info.get('mcp_client_id'),
        }

        event = MCPEventData(
            token=token,
            source_ip=context_info.get('mcp_client_id') or "mcp-local",
            endpoint=f"mcp://{self._server_name}/{handler_name}",
            scheme=True,
            method=method,
            timestamp=datetime.now(timezone.utc).isoformat(),
            custom_data=custom_data,
            headers=None,
            query_params=None,
            body=arguments,
            user_agent=USER_AGENT,
            user_id=context_info.get('mcp_client_id'),
        )

        queue_event(event)

    def _wrap_handler(self, handler: Callable, handler_name: str, event_type: str, method: str) -> Callable:
        """Wrap an MCP handler to capture timing, errors, and arguments.

        Handles both sync and async handlers transparently.

        Args:
            handler: The original handler function
            handler_name: Name of the tool/resource/prompt
            event_type: One of tool_call, resource_read, prompt_get
            method: Event method string

        Returns:
            Wrapped handler function
        """
        if asyncio.iscoroutinefunction(handler):
            @functools.wraps(handler)
            async def async_wrapper(*args, **kwargs):
                cleaned_kwargs, context_info = self._extract_context_info(args, kwargs)
                sanitized_args = sanitize_arguments(cleaned_kwargs)

                start = time.perf_counter()
                error_msg = None
                result = None
                try:
                    result = await handler(*args, **kwargs)
                    return result
                except Exception as e:
                    error_msg = f"{type(e).__name__}: {e}"
                    raise
                finally:
                    duration_ms = (time.perf_counter() - start) * 1000
                    self._emit_event(
                        handler_name=handler_name,
                        event_type=event_type,
                        method=method,
                        duration_ms=duration_ms,
                        arguments=sanitized_args,
                        result=result,
                        error=error_msg,
                        context_info=context_info,
                    )
            return async_wrapper
        else:
            @functools.wraps(handler)
            def sync_wrapper(*args, **kwargs):
                cleaned_kwargs, context_info = self._extract_context_info(args, kwargs)
                sanitized_args = sanitize_arguments(cleaned_kwargs)

                start = time.perf_counter()
                error_msg = None
                result = None
                try:
                    result = handler(*args, **kwargs)
                    return result
                except Exception as e:
                    error_msg = f"{type(e).__name__}: {e}"
                    raise
                finally:
                    duration_ms = (time.perf_counter() - start) * 1000
                    self._emit_event(
                        handler_name=handler_name,
                        event_type=event_type,
                        method=method,
                        duration_ms=duration_ms,
                        arguments=sanitized_args,
                        result=result,
                        error=error_msg,
                        context_info=context_info,
                    )
            return sync_wrapper

    def tool(self, name=None, **kwargs):
        """Register a tool with Cerberus monitoring instrumentation.

        Overrides FastMCP.tool() to wrap the handler with timing/error capture.

        Args:
            name: Optional tool name override
            **kwargs: Additional arguments passed to FastMCP.tool()

        Returns:
            Decorator function
        """
        parent_decorator = super().tool(name, **kwargs)

        def decorator(func):
            tool_name = name or func.__name__
            wrapped = self._wrap_handler(func, tool_name, "tool_call", METHOD_TOOL_CALL)
            return parent_decorator(wrapped)

        return decorator

    def resource(self, uri, **kwargs):
        """Register a resource with Cerberus monitoring instrumentation.

        Overrides FastMCP.resource() to wrap the handler with timing/error capture.

        Args:
            uri: Resource URI pattern
            **kwargs: Additional arguments passed to FastMCP.resource()

        Returns:
            Decorator function
        """
        parent_decorator = super().resource(uri, **kwargs)

        def decorator(func):
            resource_name = func.__name__
            wrapped = self._wrap_handler(func, resource_name, "resource_read", METHOD_RESOURCE_READ)
            return parent_decorator(wrapped)

        return decorator

    def prompt(self, name=None, **kwargs):
        """Register a prompt with Cerberus monitoring instrumentation.

        Overrides FastMCP.prompt() to wrap the handler with timing/error capture.

        Args:
            name: Optional prompt name override
            **kwargs: Additional arguments passed to FastMCP.prompt()

        Returns:
            Decorator function
        """
        parent_decorator = super().prompt(name, **kwargs)

        def decorator(func):
            prompt_name = name or func.__name__
            wrapped = self._wrap_handler(func, prompt_name, "prompt_get", METHOD_PROMPT_GET)
            return parent_decorator(wrapped)

        return decorator


def _is_mcp_context(obj) -> bool:
    """Check if an object is an MCP Context without importing it.

    Uses duck typing to avoid hard dependency on specific MCP Context class.

    Args:
        obj: Object to check

    Returns:
        True if the object looks like an MCP Context
    """
    type_name = type(obj).__name__
    if 'Context' not in type_name:
        return False
    # Verify it has expected attributes
    return hasattr(obj, 'session') or hasattr(obj, 'request_id')
