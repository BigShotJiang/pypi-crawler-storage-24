import datetime
import re
from celery import shared_task
from django.db import transaction
from .models.charmail import CharMailParse
from django.utils import timezone
from allianceauth.services.hooks import get_extension_logger
from .services.evemail import EveMailService
from .services.battlereports import BattleReportsService
from .utils.evetools import BrEvetools
from allianceauth.eveonline.models import EveCharacter
from .models.settings import Settings
from .models.battlereport import BattleReport

logger = get_extension_logger(__name__)

# Конфигурация
MAX_RETRIES = 3
BATCH_SIZE = 5
BACKOFF_SCHEDULE = [1, 5, 15]  # Минуты для экспоненциального бэк-оффа
PROCESSING_TIMEOUT = 300  # 5 минут на обработку 

@shared_task(bind=True)
def process_queued_links(self):
    """
    Обрабатывает отложенные ссылки из очереди.
    Использует блокировку записей для предотвращения обработки одной ссылки несколькими воркерами.
    """
    logger.info('Запускается обработка новых ссылок...')
    start_time = timezone.now()
    logger.info('Поиск новых ссылок...')
    reports = BattleReport.objects.exclude(status = BattleReport.PROCESS_COMPLETE).all()
    logger.info(f'Количество ссылок для обработки: {len(reports)}.')
    processed_count = 0
    failed_count = 0
    
    try:
        with transaction.atomic():
            # Блокируем записи для обработки (используем select_for_update)
            # Фильтруем записи со статусом PENDING, у которых время следующей попытки уже наступило
            start_time = timezone.now()
            queue_items = reports.select_for_update(skip_locked=True)[
                    :BATCH_SIZE  # Ограничиваем количество обрабатываемых за раз
                ] 
            while len(queue_items) > 0:
                for item in queue_items:
                    try:
                        logger.info(f'Обработка ссыли: {item}')
                        killmails = BattleReportsService.process(item)
                        count = len(killmails) if killmails is not None else 0
                        logger.info(f'Количество найденных киллмэйлов: {count}.')
                        
                        if not count or count == None:
                            count = 0
                        if count > 0:
                            # Успех - помечаем как завершенную
                            processed_count += 1
                        else:
                            # Нет целевых киллов, но данные получены
                            logger.info(f"No targeted kills found in {item.link}")
                        
                        logger.info('Помечаем ссылку как обработанную.')
                        item.status = BattleReport.PROCESS_COMPLETE
                        item.save() 
                    except Exception as e:
                        logger.error(f'При обработке отчета произошла ошибка {e}',e)
                        item.status = BattleReport.PROCESS_FAILED
                        item.save()
                        
                    # Прерываем обработку, если превышено время выполнения
                    if (timezone.now() - start_time).total_seconds() > PROCESSING_TIMEOUT:
                        logger.info("Processing timeout reached, stopping batch")
                        break
                logger.info('Завершена обработка очереди')
                reports = BattleReport.objects.exclude(status = BattleReport.PROCESS_COMPLETE).all()
                queue_items = reports.select_for_update(skip_locked=True)[
                        :BATCH_SIZE  # Ограничиваем количество обрабатываемых за раз
                    ] 
            
    except Exception as e:
        logger.exception("Error in process_queued_links task")
        raise e
        
    return {
        "status": "completed",
        "processed_count": processed_count,
        "failed_count": failed_count,
        "duration": (timezone.now() - start_time).total_seconds()
    }

@shared_task
def load_battle_reports():
    logger.info('Начинаем сбор репортов из evetools.org')
    try:
        settings = Settings.objects.first()
        last_updated = settings.last_evetools_update if settings is not None else None
        links = BrEvetools.get_latest_brs_links(last_updated)
        counter = 0
        for reportlink in links:
            if  BattleReport.objects.filter(link = reportlink).exists():
                logger.info(f'Отчет о бое {reportlink} уже есть в базе. Пропускаем.')
            else:
                BattleReport(
                    link = reportlink,
                    comment = 'Автоматически загружен с br.evetools.org',
                    report_type = BattleReport.BATTLEREPORT,
                    status = BattleReport.PROCESS_NEW
                ).save()
                counter = counter + 1
                logger.info(f'Добавлена запись для репорта {reportlink}.')
        
        logger.info(f'Добавлено {counter} ссылок на репорты')
        last_updated = datetime.datetime.now(tz=timezone.utc)
        if settings is None:
            Settings(last_evetools_update = last_updated).save()
        else:
            settings.last_evetools_update = last_updated
            settings.save()
        
    except Exception as e:
        logger.error(e)
        return

@shared_task(bind=True)
def fetch_characters_mails(self):
    """Фоновая задача для получения писем персонажа"""
    counter = 0
    start_time = datetime.datetime.now(tz=timezone.utc)
    
    for character in CharMailParse.objects.all():
        try:
            if not EveCharacter.objects.filter(character_id=character.character_id).exists():
                logger.info(f'Персонаж {character.character_id} не найден. Пропускаем обработку почты.')
                continue

            mailboxCharacter = EveCharacter.objects.get(character_id=character.character_id)
            
            # Получаем письма персонажа
            mails = EveMailService.get_character_mails(
                character_id=character.character_id,
                limit=10,
                unread_only=False,
                last_mail_id=character.lastmail_id
            )
            
            logger.info(f"Получено {len(mails)} писем для персонажа {mailboxCharacter.character_name}")
            killIDs = []
            
            if len(mails) > 0:
                for mail in mails:
                    logger.debug(mail)
                    pattern = r'<a\s+[^>]*href="([^"]*)"[^>]*>'
                    matches = re.findall(pattern, mail.get('body'))
                    if matches:
                        for match in matches:
                            parts = match.split(':')
                            if parts[0] == 'killReport':
                                killIDs.append(match.split(':')[1])
                                kill = match.split(':')[1]
                                try: 
                                    if not BattleReport.objects.filter(link = f'https://zkillboard.com/kill/{kill}/').exists():
                                        kill = BattleReport(
                                            link = f'https://zkillboard.com/kill/{kill}/',
                                            comment = f'Автоматически загружен из почтового ящика {mailboxCharacter.character_name}',
                                            status = BattleReport.PROCESS_NEW,
                                            report_type = BattleReport.KILLMAIL,
                                        )
                                        kill.save()
                                        logger.info(f'Киллмэйл {kill} из почтового ящика персонажа {mailboxCharacter.character_name} добавлен на обработку')
                                        continue
                                    else:
                                        logger.info(f'Киллмэйл {kill} из почтового ящика персонажа {mailboxCharacter.character_name} не добавлен так как уже есть в базе данных')
                                except Exception as e:
                                    logger.error(e)
                    #Если прислали ссылку на zkillboard, просто сохраняем ее
                    matches = re.compile(r"^https?://(?:www\.)?zkillboard\.com/kill/(.*)/", re.IGNORECASE).findall(mail.get('body'))
                    if matches:
                        try: 
                            for match in matches:
                                url = f'https://www.zkillboard.com/kill/{match}/'
                                if not BattleReport.objects.filter(link = url).exists():
                                    kill = BattleReport(
                                        link = url,
                                        comment = f'Автоматически загружен из почтового ящика {mailboxCharacter.character_name}',
                                        status = BattleReport.PROCESS_NEW,
                                        report_type = BattleReport.KILLMAIL
                                    )
                                    kill.save()
                                    logger.info(f'Киллмэйл {kill} из почтового ящика персонажа {mailboxCharacter.character_name} добавлен на обработку')
                                    continue
                                else:
                                    logger.info(f'Киллмэйл {kill} из почтового ящика персонажа {mailboxCharacter.character_name} не добавлен так как уже есть в базе данных')
                        except Exception as e:
                            logger.error(e)
           
            character.updated_at = datetime.datetime.now()     
            
            if len(mails) > 0:
                character.lastmail_id = mails[0]['mail_id']
                
            character.save()
            counter += len(mails)
            
        except Exception as e:
            logger.error(f"Ошибка при получении писем: {e}")
            raise
        
    return {
        "success": True,
        "mails_count": counter
    }


@shared_task(bind=True, autoretry_for=(Exception,), retry_backoff=True, retry_backoff_max=300, max_retries=3)
def process_mass_action(self, action: str, killmail_ids: list, user_pk: int):
    """
    Массовая обработка киллмэйлов
    action: 'approve', 'reject', 'delete', 'restore'
    """
    from .models.killmails import KillCompensation
    from .utils.mailtools import IngameMail
    from allianceauth.eveonline.models import EveCharacter
    from django.conf import settings
    
    logger.info(f'Starting mass action: {action} for {len(killmail_ids)} items by user {user_pk}')
    
    try:
        # Получаем пользователя
        user = None
        try:
            from django.contrib.auth import get_user_model
            User = get_user_model()
            user = User.objects.get(pk=user_pk)
        except Exception as e:
            logger.warning(f'Could not get user {user_pk}: {e}')
        
        # Получаем текущего персонажа пользователя
        current_character = None
        if user:
            try:
                current_character = get_main_character_from_user(user)
            except Exception as e:
                logger.warning(f'Could not get main character for user {user_pk}: {e}')
        
        # Получаем киллмэйлы
        kills = KillCompensation.objects.filter(killmail_id__in=killmail_ids)
        total_count = kills.count()
        updated_count = 0
        deleted_count = 0
        failed_count = 0
        
        logger.info(f'Found {total_count} killmails to process')
        
        # Обрабатываем каждый киллмэйл
        for index, kill in enumerate(kills, 1):
            try:
                # Обновляем прогресс
                progress = (index / total_count) * 100
                self.update_state(
                    state='PROGRESS',
                    meta={
                        'current': index,
                        'total': total_count,
                        'progress': progress,
                        'action': action
                    }
                )
                
                if action == 'approve':
                    # Одобрить компенсацию
                    if kill.status == KillCompensation.STATUS_NEW:
                        kill.status = KillCompensation.STATUS_COMPLETE
                        kill.comment = f'Массовое одобрение администратором'
                        
                        # Отправляем письмо, если есть текущий персонаж
                        if current_character:
                            try:
                                IngameMail.create_mail(
                                    sender=current_character,
                                    to=[kill.character_id],
                                    subject=("[TEST] " if settings.DEBUG else "") + "КОМПЕНСАЦИЯ БОЕВЫХ ВЫЛЕТОВ",
                                    body=f"""Уважаемый, <a href="showinfo:1377//{kill.character_id}">{kill.character_name}</a>.

Вам будет выплачена компенсация <a href="killReport:{kill.killmail_id}:{kill.hash}">потери корабля</a> от {kill.timestamp.strftime("%d.%m.%Y, %H:%M")}!
Компенсация будет выслана в виде ISK по оценке ZKB за вычетом страховки и некоторых предметов в карго по типу бустеров.
Если вам не нужна выданная компенсация, либо же она пришла повторно, вы всегда можете отослать иски на <a href="showinfo:2//98698983">Scan Stakan</a>!

С уважением,
<a href="showinfo:1377//{current_character.character_id}">{current_character.character_name}</a>"""
                                )
                            except Exception as mail_error:
                                logger.error(f'Failed to send mail for kill {kill.killmail_id}: {mail_error}')
                        
                        kill.save()
                        updated_count += 1
                        logger.debug(f'Approved killmail {kill.killmail_id}')
                
                elif action == 'reject':
                    # Отклонить компенсацию
                    if kill.status == KillCompensation.STATUS_NEW:
                        kill.status = KillCompensation.STATUS_REJECT
                        kill.comment = f'Массовое отклонение администратором'
                        
                        # Отправляем письмо, если есть текущий персонаж
                        if current_character:
                            try:
                                IngameMail.create_mail(
                                    sender=current_character,
                                    to=[kill.character_id],
                                    subject=("[TEST] " if settings.DEBUG else "") + "ОТКАЗ В КОМПЕНСАЦИИ",
                                    body=f"""Уважаемый, <a href="showinfo:1377//{kill.character_id}">{kill.character_name}</a>.

<a href="killReport:{kill.killmail_id}:{kill.hash}">Потерянный вами корабль</a> от {kill.timestamp.strftime("%d.%m.%Y, %H:%M")} не подпадает под программу компенсации!
В соответствии с правилами компенсации боевых потерь ваш корабль не будет компенсирован.
Если вы не согласны с данным решением, обратитесь к ответственному за компенсации или офицеру альянса.

С уважением,
<a href="showinfo:1377//{current_character.character_id}">{current_character.character_name}</a>"""
                                )
                            except Exception as mail_error:
                                logger.error(f'Failed to send mail for kill {kill.killmail_id}: {mail_error}')
                        
                        kill.save()
                        updated_count += 1
                        logger.debug(f'Rejected killmail {kill.killmail_id}')
                
                elif action == 'delete':
                    # Удалить киллмэйл
                    kill_id = kill.killmail_id
                    kill.delete()
                    deleted_count += 1
                    logger.debug(f'Deleted killmail {kill_id}')
                
                elif action == 'restore':
                    # Восстановить киллмэйл
                    if kill.status in [KillCompensation.STATUS_COMPLETE, KillCompensation.STATUS_REJECT]:
                        kill.status = KillCompensation.STATUS_NEW
                        kill.comment = f'Восстановлено администратором'
                        kill.save()
                        updated_count += 1
                        logger.debug(f'Restored killmail {kill.killmail_id}')
                
                else:
                    logger.warning(f'Unknown action: {action}')
                    failed_count += 1
                    
            except Exception as e:
                logger.error(f'Error processing killmail {kill.killmail_id}: {e}')
                failed_count += 1
        
        logger.info(f'Mass action completed: {action}. Updated: {updated_count}, Deleted: {deleted_count}, Failed: {failed_count}')
        
        return {
            'status': 'completed',
            'action': action,
            'updated': updated_count,
            'deleted': deleted_count,
            'failed': failed_count,
            'total': total_count
        }
        
    except Exception as e:
        logger.error(f'Mass action failed: {e}')
        raise