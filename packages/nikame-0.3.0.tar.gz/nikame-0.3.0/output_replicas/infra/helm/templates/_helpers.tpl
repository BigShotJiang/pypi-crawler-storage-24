{/* Common labels */}
{{- define "test-replicas.labels" -}}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
nikame.project: test-replicas
{{- end }}
