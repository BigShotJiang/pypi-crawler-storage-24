{/* Common labels */}
{{- define "test-mlops.labels" -}}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
nikame.project: test-mlops
{{- end }}
