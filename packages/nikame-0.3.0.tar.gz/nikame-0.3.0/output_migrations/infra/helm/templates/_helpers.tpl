{/* Common labels */}
{{- define "test-migrations.labels" -}}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
nikame.project: test-migrations
{{- end }}
