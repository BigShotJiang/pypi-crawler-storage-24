import json
from collections.abc import Sequence
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Union

import tabulate

from h2o_mlops import h2o_mlops_autogen, options, types


class Table(Sequence):
    """Table that lazy loads."""

    def __init__(  # noqa: S107
        self,
        data: List[Dict[str, Any]],
        keys: List[str],
        get_method: Optional[Callable],
        list_method: Optional[Callable] = None,
        list_args: Optional[Dict[str, Any]] = None,
        next_page_token: str = "",
        count_method: Optional[Callable] = None,
        count_args: Optional[Dict[str, Any]] = None,
        **filters: Any,
    ):
        self.__data: List[Dict[str, Any]]
        self._keys = keys
        self._get = get_method

        self._list = list_method
        self._list_args = list_args
        self._next_page_token = next_page_token
        self._first_page_data = data
        self._current_index = 0
        self._page_num = 1

        self._count = count_method
        self._count_args = count_args

        self._filters = filters
        self._data = data

    @property
    def _data(self) -> List[Dict[str, Any]]:
        return self.__data

    @_data.setter
    def _data(self, data: List[Dict[str, Any]]) -> None:
        if f := self._filters:
            self.__data = [d for d in data if all([d[k] == v for k, v in f.items()])]
        else:
            self.__data = data

    def show(self, n: int) -> None:
        print(self._show(n))

    def __getitem__(self, index: Union[int, slice]) -> Any:
        if isinstance(index, slice):
            raise TypeError(f"Index must be an integer, not {type(index)}")
        index = len(self) + index if index < 0 else index
        for i, item in enumerate(self):
            if i == index:
                return item
        raise IndexError("Index out of range")

    def __iter__(self) -> "Table":
        self._current_index = 0
        if self._page_num != 1:
            self._data = []
            self._next_page_token = None
            self._page_num = 0
        return self

    def __next__(self) -> Any:
        if self._current_index < len(self._data):
            item = self._data[self._current_index]
            self._current_index += 1
            return self._get(item) if self._get else item

        if self._next_page_token != "":  # noqa: S105
            next_table: Table = self._list(
                page_token=self._next_page_token, **self._list_args
            )
            self._data = next_table._data
            self._next_page_token = next_table._next_page_token
            self._current_index = 0
            self._page_num += 1
            return self.__next__()

        raise StopIteration

    def __len__(self) -> int:
        if self._count:
            try:
                return self._count(**self._count_args)
            except Exception as e:
                if (
                    'HTTP response body: {"code":5, "message":"Not Found", "details":[]}'  # noqa: E501
                    not in str(e)
                ):
                    raise e
        return sum(1 for _ in self)

    def __bool__(self) -> bool:
        for _ in self:
            return True
        return False

    def __repr__(self) -> str:
        return self._show(n=50)

    def _show(self, n: int) -> str:
        get_method, self._get = self._get, None
        table: List[List[Any]] = []
        for i, item in enumerate(self):
            if i == n:
                break
            row = [i] + [item[key] for key in self._keys]
            table.append(row)
        self._get = get_method
        headers = [""] + self._keys
        return tabulate.tabulate(table, headers=headers, tablefmt="presto")


def _convert_metadata(metadata: Any) -> Any:
    """Converts extracted metadata into Storage compatible value objects."""
    values = {}
    for k, v in metadata.values.items():
        o = h2o_mlops_autogen.StorageValue(
            bool_value=v.bool_value,
            double_value=v.double_value,
            duration_value=v.duration_value,
            int64_value=v.int64_value,
            string_value=v.string_value,
            json_value=v.json_value,
            timestamp_value=v.timestamp_value,
        )
        values[k] = o

    return h2o_mlops_autogen.StorageMetadata(values=values)


def _convert_to_storage_value(
    value: Union[str, int, float, bool, datetime, Dict, List[Dict]],
    is_id_value: bool = False,
) -> h2o_mlops_autogen.StorageValue:
    """Convert Python value into Storage compatible value object."""
    if is_id_value:
        return h2o_mlops_autogen.StorageValue(
            id_value=value,
        )
    if isinstance(value, float):
        return h2o_mlops_autogen.StorageValue(
            double_value=value,
        )
    if isinstance(value, str):
        return h2o_mlops_autogen.StorageValue(
            string_value=value,
        )
    if isinstance(value, int):
        return h2o_mlops_autogen.StorageValue(
            int64_value=str(value),
        )
    if isinstance(value, bool):
        return h2o_mlops_autogen.StorageValue(
            bool_value=value,
        )
    if isinstance(value, (dict, list)):
        return h2o_mlops_autogen.StorageValue(
            json_value=json.dumps(value),
        )
    if isinstance(value, datetime):
        return h2o_mlops_autogen.StorageValue(
            timestamp_value=value,
        )
    raise TypeError(f"Unsupported value type: {type(value)}")


def _convert_from_storage_value(
    storage_value: Union[
        h2o_mlops_autogen.StorageValue,
        h2o_mlops_autogen.IngestMetadataValue,
        Dict[str, Any],
    ],
) -> Optional[Union[str, int, float, bool, datetime, Dict, List[Dict]]]:
    """Convert Storage compatible value object into Python value."""
    if not isinstance(storage_value, dict):
        storage_value = storage_value.model_dump()

    for value_type, value in storage_value.items():
        if value is not None:
            return (
                int(value)
                if "int64" in value_type
                else json.loads(value) if "json" in value_type else value
            )
    return None


def _convert_raw_metadata_to_table(
    raw_metadata: Optional[
        Union[h2o_mlops_autogen.StorageMetadata, h2o_mlops_autogen.IngestMetadata]
    ],
    **selectors: Any,
) -> Table:
    """Convert Storage/Ingest compatible metadata object into _utils.Table."""
    data, metadata = [], {}
    if raw_metadata and raw_metadata.values:
        for key, storage_value in raw_metadata.values.items():
            metadata[key] = _convert_from_storage_value(storage_value)
        data = [
            {"key": k, "value": f"{str(v)[:40]}..." if len(str(v)) > 40 else str(v)}
            for k, v in metadata.items()
        ]
    return Table(
        data=data,
        keys=["key", "value"],
        get_method=lambda x: {x["key"]: metadata[x["key"]]},
        **selectors,
    )


def _convert_resource_name_to_uid(resource_name: str) -> str:
    return resource_name.split("/")[-1]


def _convert_list_opts_to_api_args(
    opts: Optional[options.ListOptions], field_name_mapping: Dict[str, str]
) -> Dict[str, Any]:
    """Convert ListOptions to backend API arguments."""
    return opts._to_raw_info_args(field_name_mapping=field_name_mapping) if opts else {}


def _convert_filter_expression_to_string(
    filter_expression: Optional[options.FilterExpression],
    field_name_mapping: Dict[str, str],
) -> Optional[str]:
    """Convert FilterExpression to backend API filter string."""
    return (
        filter_expression._to_string(
            field_name_mapping=field_name_mapping,
        )
        if filter_expression
        else None
    )


def _merge_selectors_with_filter(
    filter_expression: Optional[options.FilterExpression],
    field_operator_mapping: Optional[Dict[str, types.OperatorType]] = None,
    **selectors: Any,
) -> Optional[options.FilterExpression]:
    """Merge keyword selectors with existing FilterExpression."""
    field_operator_mapping = field_operator_mapping or {}
    if selectors:
        return options.FilterExpression(
            filters=[
                options.FilterOptions(
                    field=f,
                    value=v,
                    operator=field_operator_mapping.get(f, types.OperatorType.EQ),
                )
                for f, v in selectors.items()
            ]
            + ([filter_expression] if filter_expression else [])
        )
    return filter_expression
