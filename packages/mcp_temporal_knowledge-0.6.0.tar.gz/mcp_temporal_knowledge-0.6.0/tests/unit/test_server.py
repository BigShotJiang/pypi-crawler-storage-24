import pytest
from unittest.mock import Mock, AsyncMock
from pydantic import ValidationError

from mcp_temporal_knowledge.server import create_mcp_server
from mcp_temporal_knowledge.utils import format_namespace
from mcp_temporal_knowledge.substrate import (
    TemporalKnowledgeSubstrate, KnowledgeEntity, KnowledgeType,
    KNOWLEDGE_TYPE_DESCRIPTIONS, PROCESS_TYPES,
    Connection, ConnectionType, CONNECTION_TYPE_DESCRIPTIONS,
    PROCESS_EDGES, DomainKnowledge,
)


async def _tool_names(server):
    """Helper: get a set of tool names from a FastMCP server."""
    tools = await server.list_tools()
    return {t.name for t in tools}


async def _get_tool(server, name):
    """Helper: get a tool by name from a FastMCP server."""
    return await server.get_tool(name)


class TestFormatNamespace:
    """Test the format_namespace function behavior."""

    def test_format_namespace_empty_string(self):
        assert format_namespace("") == ""

    def test_format_namespace_no_hyphen(self):
        assert format_namespace("myapp") == "myapp-"

    def test_format_namespace_with_hyphen(self):
        assert format_namespace("myapp-") == "myapp-"

    def test_format_namespace_complex_name(self):
        assert format_namespace("company.product") == "company.product-"
        assert format_namespace("app_v2") == "app_v2-"


class TestNamespacing:
    """Test namespacing functionality."""

    @pytest.fixture
    def mock_substrate(self):
        """Create a mock TemporalKnowledgeSubstrate for testing."""
        substrate = Mock(spec=TemporalKnowledgeSubstrate)
        domain_knowledge = DomainKnowledge(entities=[], connections=[])
        substrate.list_domains = AsyncMock(return_value=[])
        substrate.create_domain = AsyncMock(return_value={"name": "test", "description": "", "t_created": None})
        substrate.begin_session = AsyncMock(return_value={"run_id": "test-123", "domain": "test", "timestamp": None, "domain_state": {}})
        substrate.end_session = AsyncMock(return_value={"run_id": "test-123", "domain": "test", "timestamp": None, "purpose": "", "summary": "done", "status": "complete", "entities_discovered": 0})
        substrate.create_knowledge = AsyncMock(return_value=[])
        substrate.evolve_knowledge = AsyncMock(return_value={"name": "test", "label": "System", "domain": "test", "new_description": "evolved", "evolved": True})
        substrate.update_knowledge = AsyncMock(return_value={"name": "test", "type": "System", "domain": "test", "description": "updated", "updated": True})
        substrate.retype_knowledge = AsyncMock(return_value={"name": "test", "old_type": "Person", "new_type": "Organization", "domain": "test", "description": "test", "retyped": True})
        substrate.merge_knowledge = AsyncMock(return_value={"name": "test", "domain": "test", "label": "Person", "duplicates_removed": 3, "edges_redirected": 5, "absorbed_descriptions": [], "merged": True})
        substrate.confirm_knowledge = AsyncMock(return_value=[{"name": "test", "type": "System", "domain": "test", "description": "test", "confirmed": True}])
        substrate.create_connections = AsyncMock(return_value=[])
        substrate.search_knowledge = AsyncMock(return_value=domain_knowledge)
        substrate.get_domain_state = AsyncMock(return_value=domain_knowledge)
        substrate.get_run_history = AsyncMock(return_value=[])
        substrate.driver = AsyncMock()
        substrate.driver.execute_query = AsyncMock(return_value=Mock(records=[]))
        return substrate

    @pytest.mark.asyncio
    async def test_namespace_tool_prefixes(self, mock_substrate):
        """Test that tools are correctly prefixed with namespace."""
        namespaced_names = await _tool_names(create_mcp_server(mock_substrate, namespace="test-ns"))

        expected_tools = [
            "test-ns-list_domains", "test-ns-create_domain",
            "test-ns-begin_session", "test-ns-end_session",
            "test-ns-create_knowledge", "test-ns-evolve_knowledge",
            "test-ns-update_knowledge", "test-ns-retype_knowledge",
            "test-ns-merge_knowledge",
            "test-ns-confirm_knowledge", "test-ns-create_connections",
            "test-ns-search_knowledge", "test-ns-get_domain_state",
            "test-ns-get_run_history", "test-ns-read_cypher",
            "test-ns-list_knowledge_types", "test-ns-list_connection_types",
            "test-ns-gds_create_projection", "test-ns-gds_drop_projection",
            "test-ns-gds_pagerank", "test-ns-gds_betweenness",
            "test-ns-gds_louvain", "test-ns-gds_wcc",
        ]

        for expected_tool in expected_tools:
            assert expected_tool in namespaced_names, f"Tool {expected_tool} not found in tools"

        # Test without namespace (default tools)
        default_names = await _tool_names(create_mcp_server(mock_substrate))

        expected_default_tools = [
            "list_domains", "create_domain", "begin_session", "end_session",
            "create_knowledge", "evolve_knowledge", "update_knowledge",
            "retype_knowledge", "merge_knowledge",
            "confirm_knowledge", "create_connections",
            "search_knowledge", "get_domain_state", "get_run_history", "read_cypher",
            "list_knowledge_types", "list_connection_types",
            "gds_create_projection", "gds_drop_projection",
            "gds_pagerank", "gds_betweenness", "gds_louvain", "gds_wcc",
        ]

        for expected_tool in expected_default_tools:
            assert expected_tool in default_names, f"Default tool {expected_tool} not found"

    @pytest.mark.asyncio
    async def test_namespace_tool_functionality(self, mock_substrate):
        """Test that namespaced tools function correctly."""
        server = create_mcp_server(mock_substrate, namespace="test")
        tool = await _get_tool(server, "test-search_knowledge")
        assert tool is not None

        result = await tool.fn(query="test", limit=10)
        mock_substrate.search_knowledge.assert_called_once()

    @pytest.mark.asyncio
    async def test_multiple_namespace_isolation(self, mock_substrate):
        """Test that different namespaces create isolated tool sets."""
        names_a = await _tool_names(create_mcp_server(mock_substrate, namespace="app-a"))
        names_b = await _tool_names(create_mcp_server(mock_substrate, namespace="app-b"))

        assert "app-a-search_knowledge" in names_a
        assert "app-a-search_knowledge" not in names_b
        assert "app-b-search_knowledge" in names_b
        assert "app-b-search_knowledge" not in names_a
        assert len(names_a) == len(names_b)

    @pytest.mark.asyncio
    async def test_namespace_hyphen_handling(self, mock_substrate):
        """Test namespace hyphen handling edge cases."""
        names_with = await _tool_names(create_mcp_server(mock_substrate, namespace="myapp-"))
        names_without = await _tool_names(create_mcp_server(mock_substrate, namespace="myapp"))

        assert "myapp-search_knowledge" in names_with
        assert "myapp-search_knowledge" in names_without
        assert names_with == names_without

    @pytest.mark.asyncio
    async def test_complex_namespace_names(self, mock_substrate):
        """Test complex namespace naming scenarios."""
        for namespace in ["company.product", "app_v2", "client-123", "test.env.staging"]:
            names = await _tool_names(create_mcp_server(mock_substrate, namespace=namespace))
            expected = f"{namespace}-search_knowledge"
            assert expected in names, f"Tool {expected} not found for namespace '{namespace}'"

    @pytest.mark.asyncio
    async def test_namespace_tool_count_consistency(self, mock_substrate):
        """Test that namespaced and default servers have the same number of tools."""
        default_names = await _tool_names(create_mcp_server(mock_substrate))
        namespaced_names = await _tool_names(create_mcp_server(mock_substrate, namespace="test"))

        assert len(default_names) == len(namespaced_names)

        # 23 tools: 4 process + 7 knowledge + 4 query + 2 taxonomy + 6 GDS
        assert len(default_names) == 23
        assert len(namespaced_names) == 23


class TestKnowledgeTypeValidation:
    """Test that the KnowledgeType enum properly constrains entity types."""

    def test_valid_knowledge_type_accepted(self):
        entity = KnowledgeEntity(
            name="Test Entity",
            type="System",
            description="This is a test",
        )
        assert entity.type == KnowledgeType.SYSTEM
        assert entity.type.value == "System"

    def test_invalid_knowledge_type_rejected(self):
        with pytest.raises(ValidationError) as exc_info:
            KnowledgeEntity(
                name="Bad Entity",
                type="FakeType",
                description="Should fail",
            )
        assert "type" in str(exc_info.value)

    def test_all_enum_values_accepted(self):
        for kt in KnowledgeType:
            entity = KnowledgeEntity(
                name=f"Test {kt.value}",
                type=kt.value,
                description="Testing",
            )
            assert entity.type == kt

    def test_knowledge_type_enum_has_11_members(self):
        assert len(KnowledgeType) == 11

    def test_case_sensitive_rejection(self):
        with pytest.raises(ValidationError):
            KnowledgeEntity(
                name="Case Test",
                type="system",
                description="Should fail",
            )

    def test_entity_description_defaults_empty(self):
        entity = KnowledgeEntity(name="Test", type="System")
        assert entity.description == ""

    def test_entity_domain_defaults_empty(self):
        entity = KnowledgeEntity(name="Test", type="System")
        assert entity.domain == ""


class TestConnectionTypeValidation:
    """Test that the ConnectionType enum properly constrains connection types."""

    def test_valid_connection_type_accepted(self):
        connection = Connection(
            source="Node A",
            target="Node B",
            type="INFORMING",
        )
        assert connection.type == ConnectionType.INFORMING
        assert connection.type.value == "INFORMING"

    def test_invalid_connection_type_rejected(self):
        with pytest.raises(ValidationError) as exc_info:
            Connection(
                source="Node A",
                target="Node B",
                type="WORKS_AT",
            )
        assert "type" in str(exc_info.value)

    def test_all_enum_values_accepted(self):
        for ct in ConnectionType:
            connection = Connection(
                source=f"Source {ct.value}",
                target=f"Target {ct.value}",
                type=ct.value,
            )
            assert connection.type == ct

    def test_connection_type_enum_has_7_members(self):
        assert len(ConnectionType) == 7

    def test_case_sensitive_rejection(self):
        with pytest.raises(ValidationError):
            Connection(
                source="Node A",
                target="Node B",
                type="informing",
            )


class TestProcessTypeGuards:
    """Test that process types and edges are properly defined for guards."""

    def test_process_types_set(self):
        assert PROCESS_TYPES == {"Domain", "Run"}
        assert len(PROCESS_TYPES) == 2

    def test_process_edges_set(self):
        assert PROCESS_EDGES == {"HAS_RUN", "NEXT_RUN", "DISCOVERED", "CONFIRMED"}
        assert len(PROCESS_EDGES) == 4

    def test_knowledge_types_not_in_process_types(self):
        """Verify no KnowledgeType value collides with PROCESS_TYPES."""
        for kt in KnowledgeType:
            assert kt.value not in PROCESS_TYPES, f"{kt.value} is in PROCESS_TYPES but shouldn't be"

    def test_connection_types_not_in_process_edges(self):
        """Verify no ConnectionType value collides with PROCESS_EDGES."""
        for ct in ConnectionType:
            assert ct.value not in PROCESS_EDGES, f"{ct.value} is in PROCESS_EDGES but shouldn't be"


class TestListKnowledgeTypes:
    """Test the list_knowledge_types tool."""

    @pytest.fixture
    def mock_substrate(self):
        substrate = Mock(spec=TemporalKnowledgeSubstrate)
        substrate.driver = AsyncMock()
        substrate.driver.execute_query = AsyncMock(return_value=Mock(records=[]))
        return substrate

    @pytest.mark.asyncio
    async def test_list_knowledge_types_returns_all_types(self, mock_substrate):
        server = create_mcp_server(mock_substrate)
        tool = await _get_tool(server, "list_knowledge_types")
        assert tool is not None

        result = await tool.fn()
        import json
        data = json.loads(result.content[0].text)

        assert data["total_types"] == 11

        all_types = set(data["knowledge_types"]["types"].keys())
        assert len(all_types) == 11

        for kt in KnowledgeType:
            assert kt.value in all_types, f"{kt.value} missing from list_knowledge_types"

    @pytest.mark.asyncio
    async def test_list_knowledge_types_has_descriptions(self, mock_substrate):
        server = create_mcp_server(mock_substrate)
        tool = await _get_tool(server, "list_knowledge_types")

        result = await tool.fn()
        import json
        data = json.loads(result.content[0].text)

        for type_name, description in data["knowledge_types"]["types"].items():
            assert isinstance(description, str) and len(description) > 0, \
                f"Type {type_name} has empty or missing description"

    @pytest.mark.asyncio
    async def test_list_knowledge_types_includes_process_types(self, mock_substrate):
        """Test that process types are listed separately for reference."""
        server = create_mcp_server(mock_substrate)
        tool = await _get_tool(server, "list_knowledge_types")

        result = await tool.fn()
        import json
        data = json.loads(result.content[0].text)

        assert "process_types" in data
        assert "Domain" in data["process_types"]["types"]
        assert "Run" in data["process_types"]["types"]


class TestListConnectionTypes:
    """Test the list_connection_types tool."""

    @pytest.fixture
    def mock_substrate(self):
        substrate = Mock(spec=TemporalKnowledgeSubstrate)
        substrate.driver = AsyncMock()
        substrate.driver.execute_query = AsyncMock(return_value=Mock(records=[]))
        return substrate

    @pytest.mark.asyncio
    async def test_list_connection_types_returns_all_types(self, mock_substrate):
        server = create_mcp_server(mock_substrate)
        tool = await _get_tool(server, "list_connection_types")
        assert tool is not None

        result = await tool.fn()
        import json
        data = json.loads(result.content[0].text)

        # 7 knowledge + 4 process = 11
        assert data["total_types"] == 11

        all_types = set()
        all_types.update(data["layers"]["process"]["types"].keys())
        all_types.update(data["layers"]["knowledge"]["types"].keys())
        assert len(all_types) == 11

        for ct in ConnectionType:
            assert ct.value in all_types, f"{ct.value} missing from list_connection_types"

    @pytest.mark.asyncio
    async def test_list_connection_types_has_descriptions(self, mock_substrate):
        server = create_mcp_server(mock_substrate)
        tool = await _get_tool(server, "list_connection_types")

        result = await tool.fn()
        import json
        data = json.loads(result.content[0].text)

        for type_name, description in data["layers"]["process"]["types"].items():
            assert isinstance(description, str) and len(description) > 0, \
                f"Connection type {type_name} has empty or missing description"

        for type_name, description in data["layers"]["knowledge"]["types"].items():
            assert isinstance(description, str) and len(description) > 0, \
                f"Connection type {type_name} has empty or missing description"

    @pytest.mark.asyncio
    async def test_list_connection_types_layers(self, mock_substrate):
        server = create_mcp_server(mock_substrate)
        tool = await _get_tool(server, "list_connection_types")

        result = await tool.fn()
        import json
        data = json.loads(result.content[0].text)

        assert set(data["layers"].keys()) == {"process", "knowledge"}
        assert len(data["layers"]["process"]["types"]) == 4
        assert len(data["layers"]["knowledge"]["types"]) == 7


class TestKnowledgeEntityModel:
    """Test KnowledgeEntity model optional fields."""

    def test_optional_confidence(self):
        entity = KnowledgeEntity(name="Test", type="System", confidence=0.8)
        assert entity.confidence == 0.8

    def test_confidence_defaults_none(self):
        entity = KnowledgeEntity(name="Test", type="System")
        assert entity.confidence is None

    def test_confidence_bounds(self):
        with pytest.raises(ValidationError):
            KnowledgeEntity(name="Test", type="System", confidence=1.5)
        with pytest.raises(ValidationError):
            KnowledgeEntity(name="Test", type="System", confidence=-0.1)

    def test_optional_sources(self):
        entity = KnowledgeEntity(name="Test", type="System", sources=["doc.pdf", "interview"])
        assert entity.sources == ["doc.pdf", "interview"]

    def test_sources_defaults_none(self):
        entity = KnowledgeEntity(name="Test", type="System")
        assert entity.sources is None

    def test_optional_t_valid(self):
        entity = KnowledgeEntity(name="Test", type="Rationale", t_valid="2026-01-15T12:00:00Z")
        assert entity.t_valid == "2026-01-15T12:00:00Z"

    def test_temporal_fields_default_none(self):
        entity = KnowledgeEntity(name="Test", type="System")
        assert entity.t_created is None
        assert entity.t_valid is None

    def test_optional_score(self):
        entity = KnowledgeEntity(name="Test", type="System", score=0.95)
        assert entity.score == 0.95

    def test_score_defaults_none(self):
        entity = KnowledgeEntity(name="Test", type="System")
        assert entity.score is None


class TestConnectionModel:
    """Test Connection model validation."""

    def test_connection_requires_source_and_target(self):
        with pytest.raises(ValidationError):
            Connection(source="", target="B", type="INFORMING")
        with pytest.raises(ValidationError):
            Connection(source="A", target="", type="INFORMING")

    def test_connection_t_created_optional(self):
        connection = Connection(source="A", target="B", type="INFORMING")
        assert connection.t_created is None

    def test_connection_with_t_created(self):
        connection = Connection(source="A", target="B", type="INFORMING", t_created="2026-03-13T10:00:00Z")
        assert connection.t_created == "2026-03-13T10:00:00Z"

    def test_domain_knowledge_model(self):
        dk = DomainKnowledge()
        assert dk.entities == []
        assert dk.connections == []

    def test_domain_knowledge_with_data(self):
        dk = DomainKnowledge(
            entities=[KnowledgeEntity(name="Test", type="System", description="A system")],
            connections=[Connection(source="A", target="B", type="ENABLING")],
        )
        assert len(dk.entities) == 1
        assert len(dk.connections) == 1
