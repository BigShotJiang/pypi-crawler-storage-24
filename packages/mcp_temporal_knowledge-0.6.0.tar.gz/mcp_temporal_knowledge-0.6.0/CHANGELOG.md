# Changelog

## v0.2.0 — Confirmation & t_valid Semantics

Driven by feedback from the first migration run (llmkt → temporal knowledge substrate). The migrating agent observed that "I looked at this and it hasn't changed" is a phenomenologically real observation in any knowledge journey — not just TIP. Currently that observation vanished. And `t_valid` existed in the schema but its meaning wasn't pinned down.

### Confirmation as a first-class operation

- New `confirm_knowledge` tool — creates `(Run)-[:CONFIRMED]->(entity)` edges for head-of-chain entities reviewed and found unchanged during a session
- `CONFIRMED` added as 4th process edge type alongside HAS_RUN, NEXT_RUN, DISCOVERED
- No new nodes, no mutations to existing entities — the Run's provenance trail records the observation
- Idempotent (MERGE on the edge)
- `end_session` and `get_run_history` now report `entities_confirmed` alongside `entities_discovered`
- `domain_state` filters out CONFIRMED edges (process edge, not knowledge edge)
- 20 tools total (was 19): 4 process, 4 knowledge, 4 query, 2 taxonomy, 6 GDS

### t_valid semantics pinned down

- `t_valid` means "externally valid until this date" — a forward-looking claim about the entity's shelf life in the real world
- Not "when was this recorded" (that's `t_created`) and not "when did we last look at it" (that's what CONFIRMED edges capture)
- Natural for: deprecation deadlines, contract expirations, certification renewals, temporary configurations
- When `t_valid` passes, the entity isn't deleted — it signals the next session should evolve or re-confirm

### Design rationale

The migration run also validated the substrate's generality: domain-specific vocabulary like `state = 'IN_PROGRESS'` and `risk_level = 'HIGH'` belongs in entity descriptions and consumer-side rendering logic, not as schema properties. The evolution chain *is* the state machine — each version's description captures reality at that moment. Consumers who need structured fields can parse conventions from descriptions (e.g., `State: X. Risk: Y.`). That's derivative customization, not substrate design.

## v0.1.0 — Initial Release

- Two-layer architecture: process layer (Domain, Run) + knowledge layer (10 types)
- 19 MCP tools: 4 process, 3 knowledge, 4 query, 2 taxonomy, 6 GDS
- Tool-enforced structural invariants (no raw Cypher writes)
- Domain-scoped knowledge with evolution chains
- NEXT_RUN direction enforcement (older → newer)
- Fulltext search across knowledge entities
