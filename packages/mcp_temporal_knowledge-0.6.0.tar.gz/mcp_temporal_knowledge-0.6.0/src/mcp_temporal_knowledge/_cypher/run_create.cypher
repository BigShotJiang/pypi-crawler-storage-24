CREATE (r:Run {
  run_id: $run_id, domain: $domain, user: $user,
  timestamp: datetime(), purpose: $purpose,
  summary: '', status: 'active'
})
WITH r
MATCH (d:Domain {name: $domain})
CREATE (d)-[:HAS_RUN]->(r)
WITH r
OPTIONAL MATCH (prev:Run {domain: $domain})
WHERE prev.run_id <> $run_id
WITH r, prev ORDER BY prev.timestamp DESC LIMIT 1
FOREACH (_ IN CASE WHEN prev IS NOT NULL THEN [1] ELSE [] END |
    CREATE (prev)-[:NEXT_RUN]->(r)
)
RETURN r.run_id AS run_id, r.timestamp AS timestamp
