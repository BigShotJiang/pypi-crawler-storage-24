MATCH (e {name: $name, domain: $domain})
WHERE NOT (e)<-[:EVOLVED_FROM]-()
  AND NOT e:Domain AND NOT e:Run
WITH e
MATCH (r:Run {run_id: $run_id})
MERGE (r)-[c:CONFIRMED]->(e)
ON CREATE SET c.t_created = datetime()
RETURN e.name AS name, labels(e)[0] AS type, e.domain AS domain,
       e.description AS description
