MATCH (d:Domain {name: $domain})-[:HAS_RUN]->(r:Run)
WITH r ORDER BY r.timestamp ASC
LIMIT $limit
OPTIONAL MATCH (r)-[:DISCOVERED]->(e)
WITH r, count(e) AS entities_discovered
OPTIONAL MATCH (r)-[:CONFIRMED]->(c)
WITH r, entities_discovered, count(c) AS entities_confirmed
RETURN r.run_id AS run_id, r.user AS user,
       r.timestamp AS timestamp, r.purpose AS purpose,
       r.summary AS summary, r.status AS status,
       entities_discovered, entities_confirmed
ORDER BY r.timestamp ASC
