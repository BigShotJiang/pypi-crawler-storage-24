MATCH (e)
WHERE e.name IN $names
  AND ($domain IS NULL OR e.domain = $domain)
WITH e
LIMIT $limit
RETURN e.name AS name,
       labels(e)[0] AS type,
       e.domain AS domain,
       e.description AS description,
       e.t_created AS t_created,
       e.t_valid AS t_valid
