MATCH (e:`__label__` {name: $name, domain: $domain})
WHERE NOT (e)<-[:EVOLVED_FROM]-()
SET e.description = $description
__t_valid_clause__
WITH e
MATCH (r:Run {run_id: $run_id})
MERGE (r)-[:DISCOVERED]->(e)
RETURN e.name AS name, labels(e)[0] AS type, e.domain AS domain,
       e.description AS description
