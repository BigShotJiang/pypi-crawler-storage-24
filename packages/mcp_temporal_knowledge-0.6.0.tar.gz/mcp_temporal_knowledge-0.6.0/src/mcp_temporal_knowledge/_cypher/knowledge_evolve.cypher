MATCH (old:`__label__` {name: $name, domain: $domain})
WHERE NOT (old)<-[:EVOLVED_FROM]-()
CREATE (new:`__label__` {
    name: old.name, domain: old.domain,
    description: $new_description,
    t_created: datetime()
})
CREATE (new)-[:EVOLVED_FROM]->(old)
WITH new
MATCH (r:Run {run_id: $run_id})
CREATE (r)-[:DISCOVERED]->(new)
RETURN new.name AS name
