MERGE (e:`__label__` {name: $name, domain: $domain})
ON CREATE SET e.t_created = datetime(),
              e.description = $description
__confidence_clause__
__sources_clause__
__t_valid_clause__
WITH e
MATCH (r:Run {run_id: $run_id})
MERGE (r)-[:DISCOVERED]->(e)
RETURN e.name AS name, labels(e)[0] AS type
