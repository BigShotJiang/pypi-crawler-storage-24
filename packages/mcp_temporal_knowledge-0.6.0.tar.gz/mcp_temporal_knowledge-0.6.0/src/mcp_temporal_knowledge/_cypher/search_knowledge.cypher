CALL db.index.fulltext.queryNodes('knowledge_index', $query) YIELD node, score
WHERE ($domain IS NULL OR node.domain = $domain)
  AND NOT (node)<-[:EVOLVED_FROM]-()
WITH node, score
ORDER BY score DESC
LIMIT $limit
RETURN node.name AS name, labels(node)[0] AS type,
       node.domain AS domain, node.description AS description,
       score, node.t_created AS t_created
