"""CostGuard CLI — shift-left cost governance for CI/CD pipelines."""

__version__ = "1.0.1"
