"""CI platform detection and PR/MR comment posting.

Supports GitLab, GitHub, and Azure DevOps. Each platform handler reads
its required configuration from environment variables set by the CI runner.
"""

import os
import re
import sys
from typing import Callable, Optional

import requests


def detect_ci_platform() -> Optional[str]:
    """Detect the current CI platform from environment variables."""
    if os.environ.get("GITLAB_CI"):
        return "gitlab"
    if os.environ.get("GITHUB_ACTIONS"):
        return "github"
    if os.environ.get("BUILD_REPOSITORY_URI"):
        return "azure_devops"
    return None


def post_gitlab_comment(formatted_output: str) -> None:
    """Post a comment to a GitLab merge request."""
    project_id = os.environ.get("CI_PROJECT_ID")
    mr_iid = os.environ.get("CI_MERGE_REQUEST_IID")
    token = os.environ.get("GITLAB_TOKEN") or os.environ.get("CI_JOB_TOKEN")
    gitlab_url = os.environ.get("CI_SERVER_URL", "https://gitlab.com")

    if not all([project_id, mr_iid, token]):
        print(
            "[CostGuard] WARNING: Missing GitLab env vars for comment posting "
            "(CI_PROJECT_ID, CI_MERGE_REQUEST_IID, GITLAB_TOKEN/CI_JOB_TOKEN).",
            file=sys.stderr,
        )
        return

    url = f"{gitlab_url}/api/v4/projects/{project_id}/merge_requests/{mr_iid}/notes"
    headers = {"PRIVATE-TOKEN": token}
    payload = {"body": formatted_output}

    resp = requests.post(url, headers=headers, json=payload, timeout=30)
    if resp.ok:
        print("[CostGuard] Comment posted to GitLab MR.", file=sys.stderr)
    else:
        print(
            f"[CostGuard] Failed to post GitLab comment: {resp.status_code} {resp.text[:300]}",
            file=sys.stderr,
        )


def post_github_comment(formatted_output: str) -> None:
    """Post a comment to a GitHub pull request."""
    token = os.environ.get("GITHUB_TOKEN")
    repository = os.environ.get("GITHUB_REPOSITORY")
    github_ref = os.environ.get("GITHUB_REF", "")

    pr_match = re.search(r"refs/pull/(\d+)/", github_ref)
    pr_number = pr_match.group(1) if pr_match else None

    if not all([token, repository, pr_number]):
        print(
            "[CostGuard] WARNING: Missing GitHub env vars for comment posting "
            "(GITHUB_TOKEN, GITHUB_REPOSITORY, GITHUB_REF with PR number).",
            file=sys.stderr,
        )
        return

    url = f"https://api.github.com/repos/{repository}/issues/{pr_number}/comments"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
    }
    payload = {"body": formatted_output}

    resp = requests.post(url, headers=headers, json=payload, timeout=30)
    if resp.ok:
        print("[CostGuard] Comment posted to GitHub PR.", file=sys.stderr)
    else:
        print(
            f"[CostGuard] Failed to post GitHub comment: {resp.status_code} {resp.text[:300]}",
            file=sys.stderr,
        )


def post_azure_devops_comment(formatted_output: str) -> None:
    """Post a comment to an Azure DevOps pull request."""
    token = os.environ.get("SYSTEM_ACCESSTOKEN")
    pr_id = os.environ.get("SYSTEM_PULLREQUEST_PULLREQUESTID")
    collection_uri = os.environ.get("SYSTEM_TEAMFOUNDATIONCOLLECTIONURI", "").rstrip("/")
    project = os.environ.get("SYSTEM_TEAMPROJECT")
    repo_id = os.environ.get("BUILD_REPOSITORY_ID")

    if not all([token, pr_id, collection_uri, project, repo_id]):
        print(
            "[CostGuard] WARNING: Missing Azure DevOps env vars for comment posting "
            "(SYSTEM_ACCESSTOKEN, SYSTEM_PULLREQUEST_PULLREQUESTID, "
            "SYSTEM_TEAMFOUNDATIONCOLLECTIONURI, SYSTEM_TEAMPROJECT, BUILD_REPOSITORY_ID).",
            file=sys.stderr,
        )
        return

    url = (
        f"{collection_uri}/{project}/_apis/git/repositories/{repo_id}"
        f"/pullRequests/{pr_id}/threads?api-version=7.0"
    )
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    payload = {
        "comments": [
            {
                "parentCommentId": 0,
                "content": formatted_output,
                "commentType": 1,
            }
        ],
        "status": 1,
    }

    resp = requests.post(url, headers=headers, json=payload, timeout=30)
    if resp.ok:
        print("[CostGuard] Comment posted to Azure DevOps PR.", file=sys.stderr)
    else:
        print(
            f"[CostGuard] Failed to post Azure DevOps comment: {resp.status_code} {resp.text[:300]}",
            file=sys.stderr,
        )


_HANDLERS: dict[str, Callable[[str], None]] = {
    "gitlab": post_gitlab_comment,
    "github": post_github_comment,
    "azure_devops": post_azure_devops_comment,
}


def post_ci_comment(formatted_output: str) -> None:
    """Detect CI platform and post the formatted output as a comment."""
    platform = detect_ci_platform()
    if platform is None:
        print(
            "[CostGuard] No supported CI platform detected. Skipping comment posting.",
            file=sys.stderr,
        )
        return

    handler = _HANDLERS[platform]
    try:
        handler(formatted_output)
    except Exception as exc:
        print(f"[CostGuard] Error posting comment to {platform}: {exc}", file=sys.stderr)
