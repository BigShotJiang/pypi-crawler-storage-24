"""Re-export for backward compatibility.

Prefer: from openfisca_survey_manager.policy import ...
or from openfisca_survey_manager.policy.simulations import ...
"""

import warnings

from openfisca_survey_manager.policy.simulations import (
    SecretViolationError,
    Simulation,
    adaptative_calculate_variable,
    assert_variables_in_same_entity,
    compute_aggregate,
    compute_pivot_table,
    compute_quantiles,
    compute_winners_losers,
    create_data_frame_by_entity,
    get_words,
    inflate,
    init_entity_data,
    init_simulation,
    init_variable_in_entity,
    new_from_tax_benefit_system,
    print_memory_usage,
    set_weight_variable_by_entity,
    summarize_variable,
)

warnings.warn(
    "openfisca_survey_manager.simulations is deprecated and will be removed in a future version. "
    "Prefer: from openfisca_survey_manager.policy import ... "
    "or from openfisca_survey_manager.policy.simulations import ...",
    DeprecationWarning,
    stacklevel=2,
)

__all__ = [
    "SecretViolationError",
    "Simulation",
    "adaptative_calculate_variable",
    "assert_variables_in_same_entity",
    "compute_aggregate",
    "compute_pivot_table",
    "compute_quantiles",
    "compute_winners_losers",
    "create_data_frame_by_entity",
    "get_words",
    "inflate",
    "init_entity_data",
    "init_simulation",
    "init_variable_in_entity",
    "new_from_tax_benefit_system",
    "print_memory_usage",
    "set_weight_variable_by_entity",
    "summarize_variable",
]
