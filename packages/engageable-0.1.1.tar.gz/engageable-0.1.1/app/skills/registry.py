from __future__ import annotations

import importlib
import inspect
import logging
import pkgutil
from typing import Any

from app.skills.base import BaseSkill

logger = logging.getLogger(__name__)


class SkillRegistry:
    """Discovers, registers, and provides access to skills."""

    def __init__(self) -> None:
        self._skills: dict[str, BaseSkill] = {}

    def register(self, skill: BaseSkill) -> None:
        if skill.name in self._skills:
            logger.warning("Skill %s already registered, overwriting", skill.name)
        self._skills[skill.name] = skill
        logger.info("Registered skill: %s (%s)", skill.name, skill.category)

    def get_skill(self, name: str) -> BaseSkill | None:
        return self._skills.get(name)

    def list_skills(self) -> list[BaseSkill]:
        return list(self._skills.values())

    def tool_definitions(self) -> list[dict[str, Any]]:
        """Return LLM tool definitions for all registered skills."""
        return [s.to_tool_definition() for s in self._skills.values()]

    def mcp_skills(self) -> list[BaseSkill]:
        """Return only skills marked as MCP-visible."""
        return [s for s in self._skills.values() if s.mcp_visible]

    def mcp_tool_definitions(self) -> list[dict[str, Any]]:
        """Return LLM tool definitions for MCP-visible skills only."""
        return [s.to_tool_definition() for s in self.mcp_skills()]

    def auto_discover(self) -> None:
        """Walk the connectors/ and analysis/ sub-packages and register any
        BaseSkill subclass found."""
        for package_name in (
            "app.skills.connectors",
            "app.skills.analysis",
            "app.skills.discovery",
            "app.skills.composite",
        ):
            try:
                package = importlib.import_module(package_name)
            except ModuleNotFoundError:
                logger.debug("Package %s not found, skipping", package_name)
                continue

            if not hasattr(package, "__path__"):
                continue

            for _importer, module_name, _ispkg in pkgutil.iter_modules(
                package.__path__, prefix=f"{package_name}."
            ):
                try:
                    module = importlib.import_module(module_name)
                except Exception:
                    logger.exception("Failed to import skill module %s", module_name)
                    continue

                for _attr_name, obj in inspect.getmembers(module, inspect.isclass):
                    if (
                        issubclass(obj, BaseSkill)
                        and obj is not BaseSkill
                        and hasattr(obj, "name")
                        and obj.name  # skip classes with empty name
                    ):
                        try:
                            instance = obj()
                            self.register(instance)
                        except Exception:
                            logger.exception(
                                "Failed to instantiate skill %s", obj.__name__
                            )


_registry: SkillRegistry | None = None


def get_registry() -> SkillRegistry:
    global _registry
    if _registry is None:
        _registry = SkillRegistry()
        _registry.auto_discover()
    return _registry
