"""Website discovery skill — scan a URL for analytics tags."""

from __future__ import annotations

import logging
import re
import time
from typing import Any
from urllib.parse import urlparse

import httpx

from app.skills.base import BaseSkill
from app.skills.types import SkillResult

logger = logging.getLogger(__name__)

# Patterns to detect analytics providers in page source
# Each entry: (provider_key, display_name, list of regex patterns, confidence_if_found)
ANALYTICS_PATTERNS: list[tuple[str, str, list[str], str]] = [
    (
        "ga4",
        "Google Analytics 4",
        [
            r"gtag\s*\(\s*['\"]config['\"]",        # gtag('config', 'G-...')
            r"G-[A-Z0-9]{6,12}",                     # GA4 measurement ID
            r"googletagmanager\.com/gtag",            # gtag.js loader
            r"google-analytics\.com/g/collect",       # GA4 collection endpoint
        ],
        "high",
    ),
    (
        "gtm",
        "Google Tag Manager",
        [
            r"googletagmanager\.com/gtm\.js",
            r"GTM-[A-Z0-9]{6,8}",
        ],
        "high",
    ),
    (
        "segment",
        "Segment",
        [
            r"cdn\.segment\.com",
            r"analytics\.js",
            r"analytics\.load\(",
        ],
        "medium",
    ),
    (
        "mixpanel",
        "Mixpanel",
        [
            r"cdn\.mxpnl\.com",
            r"mixpanel\.com/libs",
            r"mixpanel\.init\(",
        ],
        "high",
    ),
    (
        "amplitude",
        "Amplitude",
        [
            r"cdn\.amplitude\.com",
            r"amplitude\.getInstance\(",
            r"amplitude\.init\(",
        ],
        "high",
    ),
    (
        "posthog",
        "PostHog",
        [
            r"posthog\.com",
            r"posthog-js",
            r"posthog\.init\(",
        ],
        "high",
    ),
    (
        "hotjar",
        "Hotjar",
        [
            r"static\.hotjar\.com",
            r"hj\s*\(\s*['\"]identify['\"]",
        ],
        "high",
    ),
    (
        "plausible",
        "Plausible Analytics",
        [
            r"plausible\.io/js",
        ],
        "high",
    ),
    (
        "fathom",
        "Fathom Analytics",
        [
            r"cdn\.usefathom\.com",
        ],
        "high",
    ),
    (
        "heap",
        "Heap Analytics",
        [
            r"cdn\.heapanalytics\.com",
            r"heap\.load\(",
        ],
        "high",
    ),
    (
        "facebook_pixel",
        "Facebook Pixel",
        [
            r"connect\.facebook\.net.*fbevents\.js",
            r"fbq\s*\(\s*['\"]init['\"]",
        ],
        "high",
    ),
]


def _normalise_url(raw: str) -> str:
    """Ensure the URL has a scheme so httpx can fetch it."""
    raw = raw.strip()
    if not raw.startswith(("http://", "https://")):
        raw = f"https://{raw}"
    return raw


def _scan_html(html: str) -> list[dict[str, Any]]:
    """Scan HTML source for known analytics patterns.

    Returns detected providers with evidence: which patterns matched
    and a short snippet of the surrounding HTML for verification.
    """
    detected: list[dict[str, Any]] = []
    seen: set[str] = set()

    for key, display_name, patterns, confidence in ANALYTICS_PATTERNS:
        matches: list[dict[str, str]] = []
        for pattern in patterns:
            match = re.search(pattern, html, re.IGNORECASE)
            if match:
                # Extract a snippet around the match for evidence
                start = max(0, match.start() - 40)
                end = min(len(html), match.end() + 40)
                snippet = html[start:end].replace("\n", " ").strip()
                matches.append({
                    "pattern": pattern,
                    "snippet": snippet,
                })

        if matches and key not in seen:
            seen.add(key)
            entry: dict[str, Any] = {
                "provider": key,
                "name": display_name,
                "confidence": confidence,
                "evidence": matches,
            }
            if confidence != "high":
                entry["note"] = f"Possible match ({confidence} confidence) — may be a similar script"
            detected.append(entry)

    return detected


class WebsiteDiscoverSkill(BaseSkill):
    name = "website_discover"
    description = (
        "Scan a website URL to detect which analytics and tracking tools are installed. "
        "Use this FIRST when a user mentions their website, asks about their analytics setup, "
        "or wants to know what tracking they have. Also use this when the user asks about "
        "statistics or data from a website but no data sources are connected yet — scanning "
        "the site reveals which providers to connect. "
        "Returns detected providers (GA4, Mixpanel, PostHog, Segment, Amplitude, etc.) "
        "with evidence. After scanning, suggest connecting any detected sources using "
        "configure_source."
    )
    category = "connector"
    mcp_visible = True
    input_schema = {
        "type": "object",
        "properties": {
            "url": {
                "type": "string",
                "description": "The website URL to scan (e.g. 'example.com' or 'https://example.com')",
            },
        },
        "required": ["url"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "url": {"type": "string"},
            "detected": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "provider": {"type": "string"},
                        "name": {"type": "string"},
                        "note": {"type": "string", "description": "Only present if match is uncertain"},
                    },
                },
            },
            "page_title": {"type": "string"},
        },
    }
    guide = (
        "Use this during onboarding when the user mentions their website URL. "
        "It scans the page for analytics tags and tells you what's installed. "
        "Entries without a 'note' field are definite matches. Entries with a 'note' "
        "are uncertain — mention them casually (e.g. 'looks like you might also have Segment'). "
        "After discovery, propose connecting any detected sources."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()
        raw_url = params["url"]
        url = _normalise_url(raw_url)

        try:
            async with httpx.AsyncClient(
                follow_redirects=True,
                timeout=15.0,
                headers={
                    "User-Agent": "Mozilla/5.0 (compatible; Engageable/1.0; analytics-discovery)",
                },
            ) as client:
                resp = await client.get(url)
                resp.raise_for_status()

            html = resp.text
            detected = _scan_html(html)

            # Extract page title
            title_match = re.search(r"<title[^>]*>(.*?)</title>", html, re.IGNORECASE | re.DOTALL)
            page_title = title_match.group(1).strip() if title_match else ""

            elapsed = int((time.monotonic() - t0) * 1000)

            return SkillResult(
                success=True,
                data={
                    "url": url,
                    "detected": detected,
                    "page_title": page_title,
                    "scan_time_ms": elapsed,
                },
                execution_time_ms=elapsed,
            )

        except httpx.HTTPStatusError as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=False,
                error=f"Failed to fetch {url}: HTTP {exc.response.status_code}",
                execution_time_ms=elapsed,
            )
        except Exception as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=False,
                error=f"Failed to scan {url}: {exc}",
                execution_time_ms=elapsed,
            )
