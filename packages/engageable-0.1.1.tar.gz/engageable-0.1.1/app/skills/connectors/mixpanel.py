from __future__ import annotations

import base64
import logging
import time
from datetime import date, timedelta
from typing import Any

import httpx

from app.skills.base import BaseSkill
from app.skills.types import SkillResult

logger = logging.getLogger(__name__)

DEFAULT_BASE_URL = "https://mixpanel.com"


def _base_url(credentials: dict) -> str:
    """Return the Mixpanel API base URL, stripping any trailing slash."""
    url = credentials.get("base_url", DEFAULT_BASE_URL)
    return url.rstrip("/")


def _auth_headers(credentials: dict) -> dict[str, str]:
    """Build Basic auth headers from service account credentials."""
    username = credentials.get("service_account_username")
    secret = credentials.get("service_account_secret")
    if not username or not secret:
        raise ValueError(
            "Missing service_account_username or service_account_secret "
            "in Mixpanel credentials — is the data source connected?"
        )
    token = base64.b64encode(f"{username}:{secret}".encode()).decode()
    return {
        "Authorization": f"Basic {token}",
        "Accept": "application/json",
    }


class MixpanelQuerySkill(BaseSkill):
    """Query Mixpanel via the Insights API."""

    name = "mixpanel_query"
    description = (
        "Query Mixpanel using the Insights API for event data, trends, and breakdowns. "
        "Returns tabular results (columns + rows) for the specified event and date range."
    )
    category = "connector"
    input_schema = {
        "type": "object",
        "properties": {
            "project_id": {
                "type": "string",
                "description": "Mixpanel project ID",
            },
            "event": {
                "type": "string",
                "description": "Event name to query (e.g. 'Signup', 'Page View')",
            },
            "from_date": {
                "type": "string",
                "description": "Start date in YYYY-MM-DD format",
            },
            "to_date": {
                "type": "string",
                "description": "End date in YYYY-MM-DD format",
            },
            "type": {
                "type": "string",
                "description": "Query type: 'general', 'unique', or 'average'. Default: 'general'",
            },
            "unit": {
                "type": "string",
                "description": "Time granularity: 'minute', 'hour', 'day', 'week', 'month'. Default: 'day'",
            },
            "credentials": {
                "type": "object",
                "description": "Auto-injected from connected data source. Do NOT provide this.",
            },
        },
        "required": ["project_id", "event", "from_date", "to_date"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "columns": {"type": "array", "items": {"type": "string"}},
            "rows": {"type": "array", "items": {"type": "array"}},
            "metadata": {"type": "object"},
        },
    }
    guide = (
        "Use this skill to fetch event data from Mixpanel using the Insights API. "
        "The project_id and credentials are auto-injected from the connected data source "
        "— just provide the event name and date range. "
        "Use mixpanel_get_metadata to discover available event names and properties first. "
        "Use mixpanel_probe to verify the project has data. "
        "Dates must be in YYYY-MM-DD format."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()
        try:
            project_id = params["project_id"]
            event = params["event"]
            from_date = params["from_date"]
            to_date = params["to_date"]
            query_type = params.get("type", "general")
            unit = params.get("unit", "day")
            creds = params["credentials"]

            base = _base_url(creds)
            hdrs = _auth_headers(creds)

            url = f"{base}/api/2.0/insights"
            query_params = {
                "project_id": project_id,
                "event": f'["{event}"]',
                "from_date": from_date,
                "to_date": to_date,
                "type": query_type,
                "unit": unit,
            }

            async with httpx.AsyncClient(timeout=60) as client:
                resp = await client.get(url, headers=hdrs, params=query_params)
                resp.raise_for_status()
                data = resp.json()

            # Parse the Insights response into columns + rows
            # The response is typically: {"series": [...], "data": {"values": {...}, "series": [...]}}
            columns, rows = self._parse_insights_response(data, event)

            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=True,
                data={
                    "columns": columns,
                    "rows": rows,
                    "metadata": {
                        "source": "mixpanel",
                        "project_id": project_id,
                        "event": event,
                        "date_range": f"{from_date} to {to_date}",
                        "type": query_type,
                        "unit": unit,
                        "row_count": len(rows),
                        "query_time_ms": elapsed,
                    },
                },
                execution_time_ms=elapsed,
            )

        except Exception as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            logger.warning("Mixpanel query failed: %s", exc)
            return SkillResult(
                success=False,
                error=str(exc),
                execution_time_ms=elapsed,
            )

    @staticmethod
    def _parse_insights_response(data: dict, event: str) -> tuple[list[str], list[list]]:
        """Parse Mixpanel Insights API response into (columns, rows) format.

        The Insights API can return data in different shapes. This method handles
        the most common: {"series": [...dates...], "data": {"values": {event: {date: count}}}}.
        """
        columns = ["date", "count"]
        rows: list[list] = []

        # Common format: data.values.{event_name}.{date} = count
        values = (data.get("data") or {}).get("values") or {}
        series = data.get("series") or (data.get("data") or {}).get("series") or []

        if values:
            # values is {event_name: {date_string: count, ...}, ...}
            event_values = values.get(event) or {}
            if not event_values and values:
                # If event name doesn't match exactly, take the first key
                first_key = next(iter(values), None)
                if first_key:
                    event_values = values[first_key]

            if series:
                for date_str in series:
                    count = event_values.get(date_str, 0)
                    rows.append([date_str, count])
            else:
                for date_str, count in sorted(event_values.items()):
                    rows.append([date_str, count])
        elif "results" in data:
            # Alternative format: flat results list
            results = data["results"]
            if results and isinstance(results, list):
                if isinstance(results[0], dict):
                    columns = list(results[0].keys())
                    for item in results:
                        rows.append([item.get(col) for col in columns])
                else:
                    rows = results

        return columns, rows


class MixpanelProbeSkill(BaseSkill):
    """Quick health check — does this Mixpanel project have data?"""

    name = "mixpanel_probe"
    description = (
        "Run a quick health check on a Mixpanel project. Queries total event count "
        "for the last 30 days to verify the project has data."
    )
    category = "connector"
    input_schema = {
        "type": "object",
        "properties": {
            "project_id": {
                "type": "string",
                "description": "Mixpanel project ID",
            },
            "credentials": {
                "type": "object",
                "description": "Auto-injected from connected data source. Do NOT provide this.",
            },
        },
        "required": ["project_id"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "has_data": {"type": "boolean"},
            "event_count_30d": {"type": "integer"},
        },
    }
    guide = (
        "Use this after the user connects Mixpanel to check if the project has data. "
        "If has_data is false, the project may be a test project or newly set up. "
        "Credentials and project_id are auto-injected."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()
        try:
            project_id = params["project_id"]
            creds = params["credentials"]

            base = _base_url(creds)
            hdrs = _auth_headers(creds)

            # Query total event count for last 30 days using the Insights API
            today = date.today()
            from_date = (today - timedelta(days=30)).isoformat()
            to_date = today.isoformat()

            url = f"{base}/api/2.0/insights"
            query_params = {
                "project_id": project_id,
                "from_date": from_date,
                "to_date": to_date,
                "type": "general",
                "unit": "day",
            }

            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.get(url, headers=hdrs, params=query_params)
                resp.raise_for_status()
                data = resp.json()

            # Sum up total events from the response
            event_count = 0
            values = (data.get("data") or {}).get("values") or {}
            for event_name, date_counts in values.items():
                if isinstance(date_counts, dict):
                    event_count += sum(
                        v for v in date_counts.values() if isinstance(v, (int, float))
                    )

            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=True,
                data={
                    "has_data": event_count > 0,
                    "event_count_30d": event_count,
                    "project_id": project_id,
                    "date_range": f"{from_date} to {to_date}",
                },
                execution_time_ms=elapsed,
            )

        except Exception as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            logger.warning("Mixpanel probe failed: %s", exc)
            return SkillResult(
                success=False,
                error=str(exc),
                execution_time_ms=elapsed,
            )


class MixpanelGetMetadataSkill(BaseSkill):
    """Discover available event names and properties for a Mixpanel project."""

    name = "mixpanel_get_metadata"
    description = (
        "Discover what event names and event properties are available in a Mixpanel project. "
        "Returns event names and common event properties."
    )
    category = "connector"
    input_schema = {
        "type": "object",
        "properties": {
            "project_id": {
                "type": "string",
                "description": "Mixpanel project ID",
            },
            "credentials": {
                "type": "object",
                "description": "Auto-injected from connected data source. Do NOT provide this.",
            },
        },
        "required": ["project_id"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "event_names": {"type": "array", "items": {"type": "string"}},
            "event_properties": {"type": "array", "items": {"type": "string"}},
        },
    }
    guide = (
        "Use this to discover what events and properties are available in a Mixpanel project. "
        "Call this during exploration to learn the data schema. "
        "Event names and properties vary per project — always discover, don't guess. "
        "Credentials and project_id are auto-injected."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()
        try:
            project_id = params["project_id"]
            creds = params["credentials"]

            base = _base_url(creds)
            hdrs = _auth_headers(creds)

            event_names: list[str] = []
            event_properties: list[str] = []

            async with httpx.AsyncClient(timeout=30) as client:
                # Fetch event names
                resp = await client.get(
                    f"{base}/api/2.0/events/names",
                    headers=hdrs,
                    params={"project_id": project_id, "limit": 500},
                )
                resp.raise_for_status()
                names_data = resp.json()

                # Response is typically a list of event name strings
                if isinstance(names_data, list):
                    event_names = [n for n in names_data if isinstance(n, str)]
                elif isinstance(names_data, dict):
                    # Some API versions wrap in {"results": [...]}
                    event_names = names_data.get("results", [])

                # Fetch event properties (top properties)
                resp = await client.get(
                    f"{base}/api/2.0/events/properties",
                    headers=hdrs,
                    params={"project_id": project_id, "limit": 500},
                )
                resp.raise_for_status()
                props_data = resp.json()

                if isinstance(props_data, list):
                    event_properties = [p for p in props_data if isinstance(p, str)]
                elif isinstance(props_data, dict):
                    # Could be {"results": [...]} or {prop_name: {...}, ...}
                    if "results" in props_data:
                        event_properties = props_data["results"]
                    else:
                        event_properties = list(props_data.keys())

            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=True,
                data={
                    "project_id": project_id,
                    "event_names": sorted(event_names),
                    "event_properties": sorted(event_properties),
                    "total_events": len(event_names),
                    "total_event_properties": len(event_properties),
                },
                execution_time_ms=elapsed,
            )

        except Exception as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            logger.warning("Mixpanel get_metadata failed: %s", exc)
            return SkillResult(
                success=False,
                error=str(exc),
                execution_time_ms=elapsed,
            )
