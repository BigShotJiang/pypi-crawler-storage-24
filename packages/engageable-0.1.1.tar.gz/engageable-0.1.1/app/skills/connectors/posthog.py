from __future__ import annotations

import logging
import time
from datetime import date, timedelta
from typing import Any

import httpx

from app.skills.base import BaseSkill
from app.skills.types import SkillResult

logger = logging.getLogger(__name__)

DEFAULT_BASE_URL = "https://app.posthog.com"


def _base_url(credentials: dict) -> str:
    """Return the PostHog instance base URL, stripping any trailing slash."""
    url = credentials.get("base_url", DEFAULT_BASE_URL)
    return url.rstrip("/")


def _headers(credentials: dict) -> dict[str, str]:
    api_key = credentials.get("api_key")
    if not api_key:
        raise ValueError("No api_key in PostHog credentials — is the data source connected?")
    return {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }


class PostHogQuerySkill(BaseSkill):
    name = "posthog_query"
    description = (
        "Query PostHog using HogQL (SQL-like syntax) for events, persons, and properties. "
        "Falls back to the Insights Trends API for simpler aggregation queries."
    )
    category = "connector"
    input_schema = {
        "type": "object",
        "properties": {
            "project_id": {
                "type": "integer",
                "description": "PostHog project ID (numeric)",
            },
            "query": {
                "type": "string",
                "description": "HogQL query string (SQL-like syntax)",
            },
            "date_from": {
                "type": "string",
                "description": "Start date in YYYY-MM-DD format, or relative like '-7d', '-30d'",
            },
            "date_to": {
                "type": "string",
                "description": "End date in YYYY-MM-DD format, or relative like '-1d'. Defaults to today.",
            },
            "credentials": {
                "type": "object",
                "description": "Auto-injected from connected data source. Do NOT provide this.",
            },
        },
        "required": ["project_id", "query", "date_from"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "columns": {"type": "array", "items": {"type": "string"}},
            "rows": {"type": "array", "items": {"type": "array"}},
            "metadata": {"type": "object"},
        },
    }
    guide = (
        "Use this skill to fetch data from PostHog using HogQL queries. "
        "The project_id and credentials are auto-injected from the connected "
        "data source — just provide the query and date range. "
        "Use posthog_get_metadata to discover available events and properties first. "
        "Use posthog_probe to verify the project has data."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()
        try:
            project_id = params["project_id"]
            query = params["query"]
            date_from = params["date_from"]
            date_to = params.get("date_to")
            creds = params["credentials"]

            base = _base_url(creds)
            hdrs = _headers(creds)

            # Try HogQL query endpoint first
            url = f"{base}/api/projects/{project_id}/query"
            payload: dict[str, Any] = {
                "query": {
                    "kind": "HogQLQuery",
                    "query": query,
                },
            }
            if date_from:
                payload["query"]["filters"] = {"dateRange": {"date_from": date_from}}
                if date_to:
                    payload["query"]["filters"]["dateRange"]["date_to"] = date_to

            async with httpx.AsyncClient(timeout=60) as client:
                resp = await client.post(url, json=payload, headers=hdrs)

                if resp.status_code == 400:
                    # HogQL may not support the query — fall back to Trends
                    logger.info("HogQL query returned 400, falling back to Trends API")
                    return await self._fallback_trends(
                        client, base, hdrs, project_id, date_from, date_to, t0,
                    )

                resp.raise_for_status()
                data = resp.json()

            columns = data.get("columns", [])
            results = data.get("results", [])

            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=True,
                data={
                    "columns": columns,
                    "rows": results,
                    "metadata": {
                        "source": "posthog",
                        "project_id": project_id,
                        "date_range": f"{date_from} to {date_to or 'now'}",
                        "row_count": len(results),
                        "query_time_ms": elapsed,
                    },
                },
                execution_time_ms=elapsed,
            )

        except Exception as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            logger.warning("PostHog query failed: %s", exc)
            return SkillResult(
                success=False,
                error=str(exc),
                execution_time_ms=elapsed,
            )

    async def _fallback_trends(
        self,
        client: httpx.AsyncClient,
        base: str,
        hdrs: dict[str, str],
        project_id: int,
        date_from: str,
        date_to: str | None,
        t0: float,
    ) -> SkillResult:
        """Fall back to the Insights Trends API for simpler queries."""
        url = f"{base}/api/projects/{project_id}/insights/trend"
        payload: dict[str, Any] = {
            "events": [{"id": "$pageview", "type": "events", "math": "total"}],
            "date_from": date_from,
        }
        if date_to:
            payload["date_to"] = date_to

        resp = await client.post(url, json=payload, headers=hdrs)
        resp.raise_for_status()
        data = resp.json()

        result = data.get("result", [])
        columns = ["label", "count", "data"]
        rows = []
        for series in result:
            rows.append([
                series.get("label", ""),
                series.get("count", 0),
                series.get("data", []),
            ])

        elapsed = int((time.monotonic() - t0) * 1000)
        return SkillResult(
            success=True,
            data={
                "columns": columns,
                "rows": rows,
                "metadata": {
                    "source": "posthog",
                    "project_id": project_id,
                    "date_range": f"{date_from} to {date_to or 'now'}",
                    "row_count": len(rows),
                    "query_time_ms": elapsed,
                    "fallback": "trends_api",
                },
            },
            execution_time_ms=elapsed,
        )


class PostHogListProjectsSkill(BaseSkill):
    """List PostHog projects accessible by the API key."""

    name = "posthog_list_projects"
    description = (
        "List all PostHog projects the API key has access to. "
        "Returns project IDs, names, and timezones."
    )
    category = "connector"
    input_schema = {
        "type": "object",
        "properties": {
            "credentials": {
                "type": "object",
                "description": "Auto-injected from connected data source. Do NOT provide this.",
            },
        },
        "required": [],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "projects": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "integer"},
                        "name": {"type": "string"},
                        "timezone": {"type": "string"},
                    },
                },
            },
        },
    }
    guide = (
        "Use this right after PostHog is connected to see what projects the API key "
        "has access to. If there's only one, confirm it with the user. If multiple, "
        "ask which one to use. Credentials are auto-injected."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()
        try:
            creds = params["credentials"]
            base = _base_url(creds)
            hdrs = _headers(creds)

            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.get(f"{base}/api/projects/", headers=hdrs)
                resp.raise_for_status()
                data = resp.json()

            # The API returns either a list or a paginated response with "results"
            raw_projects = data if isinstance(data, list) else data.get("results", [])

            projects = []
            for proj in raw_projects:
                projects.append({
                    "id": proj.get("id"),
                    "name": proj.get("name", f"Project {proj.get('id')}"),
                    "timezone": proj.get("timezone", "UTC"),
                })

            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=True,
                data={
                    "projects": projects,
                    "count": len(projects),
                },
                execution_time_ms=elapsed,
            )
        except Exception as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            logger.warning("PostHog list_projects failed: %s", exc)
            return SkillResult(
                success=False,
                error=str(exc),
                execution_time_ms=elapsed,
            )


class PostHogProbeSkill(BaseSkill):
    """Quick health check — does this PostHog project have data?"""

    name = "posthog_probe"
    description = (
        "Run a quick health check on a PostHog project. Queries event count "
        "and distinct persons for the last 30 days to verify the project has data."
    )
    category = "connector"
    input_schema = {
        "type": "object",
        "properties": {
            "project_id": {
                "type": "integer",
                "description": "PostHog project ID (numeric)",
            },
            "credentials": {
                "type": "object",
                "description": "Auto-injected from connected data source. Do NOT provide this.",
            },
        },
        "required": ["project_id"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "has_data": {"type": "boolean"},
            "event_count_30d": {"type": "integer"},
            "distinct_persons_30d": {"type": "integer"},
        },
    }
    guide = (
        "Use this after the user selects a PostHog project to check if it has data. "
        "If has_data is false, the project may be a test project or newly set up. "
        "Credentials and project_id are auto-injected."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()
        try:
            project_id = params["project_id"]
            creds = params["credentials"]
            base = _base_url(creds)
            hdrs = _headers(creds)

            url = f"{base}/api/projects/{project_id}/query"

            # Query event count for last 30 days
            event_count_query = {
                "query": {
                    "kind": "HogQLQuery",
                    "query": "SELECT count() AS event_count FROM events",
                    "filters": {
                        "dateRange": {"date_from": "-30d"},
                    },
                },
            }

            # Query distinct persons for last 30 days
            persons_query = {
                "query": {
                    "kind": "HogQLQuery",
                    "query": "SELECT count(DISTINCT person_id) AS distinct_persons FROM events",
                    "filters": {
                        "dateRange": {"date_from": "-30d"},
                    },
                },
            }

            event_count = 0
            distinct_persons = 0

            async with httpx.AsyncClient(timeout=30) as client:
                # Run both queries
                resp1 = await client.post(url, json=event_count_query, headers=hdrs)
                resp1.raise_for_status()
                data1 = resp1.json()
                results1 = data1.get("results", [])
                if results1 and len(results1) > 0 and len(results1[0]) > 0:
                    event_count = int(results1[0][0])

                resp2 = await client.post(url, json=persons_query, headers=hdrs)
                resp2.raise_for_status()
                data2 = resp2.json()
                results2 = data2.get("results", [])
                if results2 and len(results2) > 0 and len(results2[0]) > 0:
                    distinct_persons = int(results2[0][0])

            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=True,
                data={
                    "has_data": event_count > 0,
                    "event_count_30d": event_count,
                    "distinct_persons_30d": distinct_persons,
                    "project_id": project_id,
                    "date_range": "last 30 days",
                },
                execution_time_ms=elapsed,
            )
        except Exception as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            logger.warning("PostHog probe failed: %s", exc)
            return SkillResult(
                success=False,
                error=str(exc),
                execution_time_ms=elapsed,
            )


class PostHogGetMetadataSkill(BaseSkill):
    """Discover available event names and properties for a PostHog project."""

    name = "posthog_get_metadata"
    description = (
        "Discover what event names and properties are available in a PostHog project. "
        "Returns event definitions, person properties, and event properties."
    )
    category = "connector"
    input_schema = {
        "type": "object",
        "properties": {
            "project_id": {
                "type": "integer",
                "description": "PostHog project ID (numeric)",
            },
            "credentials": {
                "type": "object",
                "description": "Auto-injected from connected data source. Do NOT provide this.",
            },
        },
        "required": ["project_id"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "event_names": {"type": "array", "items": {"type": "string"}},
            "person_properties": {"type": "array", "items": {"type": "string"}},
            "event_properties": {"type": "array", "items": {"type": "string"}},
        },
    }
    guide = (
        "Use this to discover what events and properties are available in a PostHog project. "
        "Call this during exploration to learn the data schema. "
        "Event names and properties vary per project — always discover, don't guess. "
        "Credentials and project_id are auto-injected."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()
        try:
            project_id = params["project_id"]
            creds = params["credentials"]
            base = _base_url(creds)
            hdrs = _headers(creds)

            event_names: list[str] = []
            person_properties: list[str] = []
            event_properties: list[str] = []

            async with httpx.AsyncClient(timeout=30) as client:
                # Fetch event definitions
                resp = await client.get(
                    f"{base}/api/projects/{project_id}/event_definitions",
                    headers=hdrs,
                    params={"limit": 500},
                )
                resp.raise_for_status()
                events_data = resp.json()
                raw_events = events_data if isinstance(events_data, list) else events_data.get("results", [])
                for ev in raw_events:
                    name = ev.get("name")
                    if name:
                        event_names.append(name)

                # Fetch property definitions — type=person
                resp = await client.get(
                    f"{base}/api/projects/{project_id}/property_definitions",
                    headers=hdrs,
                    params={"limit": 500, "type": "person"},
                )
                resp.raise_for_status()
                person_data = resp.json()
                raw_person = person_data if isinstance(person_data, list) else person_data.get("results", [])
                for prop in raw_person:
                    name = prop.get("name")
                    if name:
                        person_properties.append(name)

                # Fetch property definitions — type=event
                resp = await client.get(
                    f"{base}/api/projects/{project_id}/property_definitions",
                    headers=hdrs,
                    params={"limit": 500, "type": "event"},
                )
                resp.raise_for_status()
                event_prop_data = resp.json()
                raw_event_props = event_prop_data if isinstance(event_prop_data, list) else event_prop_data.get("results", [])
                for prop in raw_event_props:
                    name = prop.get("name")
                    if name:
                        event_properties.append(name)

            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=True,
                data={
                    "project_id": project_id,
                    "event_names": sorted(event_names),
                    "person_properties": sorted(person_properties),
                    "event_properties": sorted(event_properties),
                    "total_events": len(event_names),
                    "total_person_properties": len(person_properties),
                    "total_event_properties": len(event_properties),
                },
                execution_time_ms=elapsed,
            )
        except Exception as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            logger.warning("PostHog get_metadata failed: %s", exc)
            return SkillResult(
                success=False,
                error=str(exc),
                execution_time_ms=elapsed,
            )
