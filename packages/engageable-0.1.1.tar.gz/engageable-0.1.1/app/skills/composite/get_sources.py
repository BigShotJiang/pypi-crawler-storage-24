"""MCP tool: get-sources — list connected analytics data sources.

Returns connected sources and their capabilities. When nothing is connected,
includes the full provider catalog so the LLM can guide the user through
setup in a single round-trip (no follow-up call to configure_source help).
"""

from __future__ import annotations

import time
from typing import Any

from app.skills.base import BaseSkill
from app.skills.types import SkillResult

# Shared provider catalog — capabilities when connected, requirements when not.
PROVIDER_CATALOG: dict[str, dict[str, Any]] = {
    "ga4": {
        "display_name": "Google Analytics 4",
        "capabilities": [
            "metrics & dimensions queries",
            "date range analysis",
            "custom events",
            "property discovery",
        ],
        "credentials_needed": {
            "client_email": "Service account email (required)",
            "private_key": "Service account private key, PEM format (required)",
        },
        "config_needed": {
            "property_id": "GA4 property ID, numeric e.g. '123456789' (required)",
        },
    },
    "mixpanel": {
        "display_name": "Mixpanel",
        "capabilities": [
            "event queries",
            "trend analysis",
            "breakdown by properties",
            "event discovery",
        ],
        "credentials_needed": {
            "service_account_username": "Mixpanel service account username (required)",
            "service_account_secret": "Mixpanel service account secret (required)",
        },
        "config_needed": {
            "project_id": "Mixpanel project ID (required)",
        },
    },
    "posthog": {
        "display_name": "PostHog",
        "capabilities": [
            "HogQL queries",
            "event analysis",
            "person properties",
            "event discovery",
        ],
        "credentials_needed": {
            "api_key": "PostHog personal API key, starts with phc_ (required)",
        },
        "config_needed": {
            "project_id": "PostHog project ID, numeric (required)",
        },
    },
}


class GetSourcesSkill(BaseSkill):
    """List connected data sources and their available capabilities.

    This is an MCP-facing tool that tells the agent what data sources are
    configured and ready to query. When nothing is connected, the response
    includes the full provider catalog so the agent can guide the user
    without a follow-up tool call.
    """

    name = "get_sources"
    description = (
        "List connected analytics data sources and their capabilities. "
        "Call this BEFORE running any analysis to check what's available. "
        "If no sources are connected and the user wants analytics data, suggest either: "
        "(1) scanning their website with website_discover to detect installed providers, or "
        "(2) connecting a source directly with configure_source. "
        "Returns provider names, connection status, and available query types."
    )
    category = "connector"
    mcp_visible = True
    input_schema = {
        "type": "object",
        "properties": {},
        "required": [],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "sources": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "provider": {"type": "string"},
                        "status": {"type": "string"},
                        "capabilities": {"type": "array", "items": {"type": "string"}},
                    },
                },
            },
        },
    }

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()

        from app.mcp.credentials import CredentialProvider, EnvCredentialProvider

        cred_provider: CredentialProvider = params.get(
            "_credential_provider", EnvCredentialProvider()
        )

        sources = []
        for provider_key in cred_provider.list_providers():
            info = PROVIDER_CATALOG.get(provider_key, {})
            config = cred_provider.get_config(provider_key)
            sources.append({
                "provider": provider_key,
                "display_name": info.get("display_name", provider_key),
                "status": "connected",
                "capabilities": info.get("capabilities", []),
                "config": {k: v for k, v in config.items() if v},
            })

        elapsed = int((time.monotonic() - t0) * 1000)

        # When nothing is connected, include the full catalog so the LLM
        # can guide the user through setup without a follow-up tool call.
        if sources:
            return SkillResult(
                success=True,
                data={
                    "sources": sources,
                    "count": len(sources),
                    "summary": (
                        f"{len(sources)} source(s) connected: "
                        + ", ".join(s["display_name"] for s in sources)
                    ),
                },
                execution_time_ms=elapsed,
            )

        available = [
            {
                "provider": key,
                "display_name": info["display_name"],
                "credentials_needed": info["credentials_needed"],
                "config_needed": info["config_needed"],
            }
            for key, info in PROVIDER_CATALOG.items()
        ]

        return SkillResult(
            success=True,
            data={
                "sources": [],
                "count": 0,
                "available_providers": available,
                "summary": (
                    "No data sources connected yet. "
                    "To connect one, use configure_source with the provider name, "
                    "credentials, and config shown in available_providers above. "
                    "Or use website_discover to scan a URL and detect which providers are installed."
                ),
            },
            execution_time_ms=elapsed,
        )
