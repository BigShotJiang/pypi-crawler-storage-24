"""MCP tool: detect_anomalies — find spikes, drops, and unusual patterns."""

from __future__ import annotations

import logging
import time
from typing import Any

from app.skills.base import BaseSkill
from app.skills.types import SkillResult

logger = logging.getLogger(__name__)


class DetectAnomaliesSkill(BaseSkill):
    """Spot anomalies in a metric — unexpected spikes, drops, or trend changes."""

    name = "detect_anomalies"
    description = (
        "Automatic anomaly detection on a metric. Spots unexpected spikes, drops, "
        "and trend changes. Use when the user asks 'what changed?', 'why did X drop?', "
        "'are there any unusual patterns?', or wants monitoring/alerting insights. "
        "Returns flagged anomalies with dates, values, and severity. "
        "Example queries: 'Any anomalies in sessions this month?', "
        "'Did anything unusual happen to signups last week?'. "
        "Do NOT use for comparing two groups (use compare_segments) or retention (use analyze_retention)."
    )
    category = "analysis"
    mcp_visible = True
    input_schema = {
        "type": "object",
        "properties": {
            "metric": {
                "type": "string",
                "description": "The metric to check for anomalies.",
            },
            "date_range": {
                "type": "string",
                "description": "Date range: 'last7days', 'last30days', 'last90days', or 'YYYY-MM-DD:YYYY-MM-DD'.",
            },
            "source": {
                "type": "string",
                "description": "Data source: 'ga4', 'mixpanel', or 'posthog'. Auto-selects if omitted.",
            },
            "sensitivity": {
                "type": "string",
                "enum": ["low", "medium", "high"],
                "description": "Anomaly sensitivity: 'low' (only extreme outliers), 'medium' (default), 'high' (flag more).",
            },
        },
        "required": ["metric", "date_range"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "anomalies": {"type": "array"},
            "change_points": {"type": "array"},
            "summary": {"type": "string"},
            "metadata": {"type": "object"},
        },
    }

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()

        from app.skills.composite.helpers import (
            fetch_time_series, get_cred_provider, resolve_source,
        )
        from app.skills.registry import get_registry

        cred_provider = get_cred_provider(params)
        registry = get_registry()
        source = resolve_source(params, cred_provider)

        if not source:
            return SkillResult(
                success=False,
                error="No data sources configured.",
                execution_time_ms=int((time.monotonic() - t0) * 1000),
            )

        # Fetch data
        fetch_result = await fetch_time_series(
            registry, cred_provider, source,
            params["metric"], params["date_range"],
        )
        if not fetch_result.success:
            return fetch_result

        rows = (fetch_result.data or {}).get("rows", [])
        if len(rows) < 14:
            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=True,
                data={
                    "anomalies": [],
                    "change_points": [],
                    "summary": f"Only {len(rows)} data points — need 14+ for anomaly detection.",
                    "metadata": fetch_result.data.get("metadata", {}),
                },
                execution_time_ms=elapsed,
            )

        # Map sensitivity to MAD threshold
        threshold = {"low": 3.5, "medium": 2.5, "high": 1.5}.get(
            params.get("sensitivity", "medium"), 2.5
        )

        # Run trend detection (which includes anomaly detection)
        trend_skill = registry.get_skill("stats_trend_detection")
        if trend_skill is None:
            return SkillResult(
                success=False,
                error="stats_trend_detection skill not available",
                execution_time_ms=int((time.monotonic() - t0) * 1000),
            )

        trend_result = await trend_skill.execute({
            "data": fetch_result.data,
            "period": 7,
        })

        elapsed = int((time.monotonic() - t0) * 1000)

        if not trend_result.success:
            return SkillResult(
                success=False,
                error=f"Anomaly detection failed: {trend_result.error}",
                execution_time_ms=elapsed,
            )

        trend_data = trend_result.data or {}
        anomalies = trend_data.get("anomaly_indices", [])
        change_points = trend_data.get("change_points", [])

        # Filter anomalies by custom threshold if different from default
        # The trend_detection skill uses threshold=2.5 by default.
        # For low/high sensitivity, we re-run the anomaly detection.
        if params.get("sensitivity") and params["sensitivity"] != "medium":
            import numpy as np
            decomp = trend_data.get("decomposition", {})
            residuals = decomp.get("residual", [])
            dates = decomp.get("dates", [])
            observed = decomp.get("observed", [])

            if residuals:
                residuals_arr = np.array(residuals)
                median = np.median(residuals_arr)
                mad = np.median(np.abs(residuals_arr - median))
                if mad == 0:
                    mad = np.std(residuals_arr)
                if mad > 0:
                    z_scores = np.abs(residuals_arr - median) / mad
                    anomalies = [
                        {
                            "index": int(i),
                            "date": dates[i] if i < len(dates) else None,
                            "value": observed[i] if i < len(observed) else None,
                        }
                        for i in range(len(z_scores))
                        if z_scores[i] > threshold
                    ]

        # Build summary
        parts = []
        if anomalies:
            parts.append(f"{len(anomalies)} anomalies detected.")
            for a in anomalies[:3]:
                parts.append(f"  - {a.get('date', '?')}: {a.get('value', '?')}")
        else:
            parts.append("No anomalies detected.")

        if change_points:
            cp_dates = [cp.get("date", "?") for cp in change_points]
            parts.append(f"Trend change points at: {', '.join(cp_dates)}.")

        direction = trend_data.get("trend_direction", "flat")
        slope_pct = trend_data.get("trend_slope_pct", 0)
        parts.append(f"Overall trend: {direction} ({slope_pct:+.1f}% per period).")

        return SkillResult(
            success=True,
            data={
                "anomalies": anomalies,
                "change_points": change_points,
                "trend_direction": direction,
                "trend_slope_pct": slope_pct,
                "summary": " ".join(parts),
                "metadata": {
                    **fetch_result.data.get("metadata", {}),
                    "sensitivity": params.get("sensitivity", "medium"),
                    "threshold": threshold,
                    "total_time_ms": elapsed,
                },
            },
            execution_time_ms=elapsed,
        )
