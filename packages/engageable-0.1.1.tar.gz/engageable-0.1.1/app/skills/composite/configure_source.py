"""MCP tool: configure_source — add or update a data source connection."""

from __future__ import annotations

import logging
import time
from typing import Any

from app.skills.base import BaseSkill
from app.skills.types import SkillResult

logger = logging.getLogger(__name__)

# What credentials each provider needs
PROVIDER_SCHEMAS: dict[str, dict[str, Any]] = {
    "posthog": {
        "display_name": "PostHog",
        "credentials_fields": {
            "api_key": "PostHog personal API key (starts with phc_)",
            "base_url": "PostHog instance URL (default: https://us.posthog.com)",
        },
        "config_fields": {
            "project_id": "PostHog project ID (numeric)",
        },
        "required_credentials": ["api_key"],
        "required_config": ["project_id"],
    },
    "mixpanel": {
        "display_name": "Mixpanel",
        "credentials_fields": {
            "service_account_username": "Mixpanel service account username",
            "service_account_secret": "Mixpanel service account secret",
            "base_url": "Mixpanel API URL (default: https://mixpanel.com)",
        },
        "config_fields": {
            "project_id": "Mixpanel project ID",
        },
        "required_credentials": ["service_account_username", "service_account_secret"],
        "required_config": ["project_id"],
    },
    "ga4": {
        "display_name": "Google Analytics 4",
        "credentials_fields": {
            "client_email": "Service account email",
            "private_key": "Service account private key (PEM format)",
            "type": "Should be 'service_account'",
        },
        "config_fields": {
            "property_id": "GA4 property ID (numeric, e.g. '123456789')",
        },
        "required_credentials": ["client_email", "private_key"],
        "required_config": ["property_id"],
    },
}


class ConfigureSourceSkill(BaseSkill):
    """Add or update a data source connection."""

    name = "configure_source"
    description = (
        "Connect an analytics data source so Engageable can query it. "
        "Use this when a user wants to view analytics data from a provider that isn't "
        "connected yet — for example, if they ask about GA4 statistics but GA4 isn't "
        "configured, guide them through connecting it with this tool. "
        "Also use after website_discover detects providers on a user's site. "
        "Supports: posthog, mixpanel, ga4. "
        "Call with provider='help' to see what credentials each provider needs. "
        "Saves credentials to ~/.engageable/credentials.json."
    )
    category = "connector"
    mcp_visible = True
    input_schema = {
        "type": "object",
        "properties": {
            "provider": {
                "type": "string",
                "enum": ["posthog", "mixpanel", "ga4", "help"],
                "description": "The analytics provider to configure, or 'help' to see requirements.",
            },
            "credentials": {
                "type": "object",
                "description": (
                    "Provider credentials. PostHog: {api_key}. "
                    "Mixpanel: {service_account_username, service_account_secret}. "
                    "GA4: {client_email, private_key, type: 'service_account'}."
                ),
            },
            "config": {
                "type": "object",
                "description": (
                    "Provider config. PostHog: {project_id}. "
                    "Mixpanel: {project_id}. GA4: {property_id}."
                ),
            },
        },
        "required": ["provider"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "message": {"type": "string"},
        },
    }

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()

        from app.mcp.credentials import CREDENTIALS_FILE, EnvCredentialProvider

        provider = params["provider"]

        # Help mode — show what's needed for each provider
        if provider == "help":
            help_text = ["Supported data sources:\n"]
            for name, schema in PROVIDER_SCHEMAS.items():
                help_text.append(f"## {schema['display_name']} (provider: '{name}')")
                help_text.append("Credentials needed:")
                for field, desc in schema["credentials_fields"].items():
                    req = " (required)" if field in schema["required_credentials"] else " (optional)"
                    help_text.append(f"  - {field}: {desc}{req}")
                help_text.append("Config needed:")
                for field, desc in schema["config_fields"].items():
                    req = " (required)" if field in schema["required_config"] else " (optional)"
                    help_text.append(f"  - {field}: {desc}{req}")
                help_text.append("")

            return SkillResult(
                success=True,
                data={"providers": PROVIDER_SCHEMAS, "help": "\n".join(help_text)},
                execution_time_ms=int((time.monotonic() - t0) * 1000),
            )

        # Validate provider
        schema = PROVIDER_SCHEMAS.get(provider)
        if schema is None:
            return SkillResult(
                success=False,
                error=f"Unknown provider: {provider}. Supported: {', '.join(PROVIDER_SCHEMAS.keys())}",
                execution_time_ms=int((time.monotonic() - t0) * 1000),
            )

        credentials = params.get("credentials", {})
        config = params.get("config", {})

        # Validate required fields
        missing_creds = [
            f for f in schema["required_credentials"]
            if not credentials.get(f)
        ]
        missing_config = [
            f for f in schema["required_config"]
            if not config.get(f)
        ]

        if missing_creds or missing_config:
            parts = []
            if missing_creds:
                parts.append(f"Missing credentials: {', '.join(missing_creds)}")
            if missing_config:
                parts.append(f"Missing config: {', '.join(missing_config)}")
            return SkillResult(
                success=False,
                error=". ".join(parts) + f". Call with provider='help' to see all fields for {provider}.",
                execution_time_ms=int((time.monotonic() - t0) * 1000),
            )

        # Apply defaults
        if provider == "posthog" and "base_url" not in credentials:
            credentials["base_url"] = "https://us.posthog.com"
        if provider == "mixpanel" and "base_url" not in credentials:
            credentials["base_url"] = "https://mixpanel.com"

        # Save
        cred_provider = params.get("_credential_provider", EnvCredentialProvider())
        cred_provider.save_source(provider, credentials, config)

        elapsed = int((time.monotonic() - t0) * 1000)
        return SkillResult(
            success=True,
            data={
                "status": "configured",
                "provider": provider,
                "display_name": schema["display_name"],
                "credentials_file": str(CREDENTIALS_FILE),
                "message": (
                    f"{schema['display_name']} configured successfully. "
                    f"Credentials saved to {CREDENTIALS_FILE}. "
                    f"You can now use analyze_trends, compare_segments, and other tools with this source."
                ),
            },
            execution_time_ms=elapsed,
        )
