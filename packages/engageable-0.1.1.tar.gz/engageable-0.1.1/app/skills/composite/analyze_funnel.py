"""MCP tool: analyze_funnel — multi-step conversion funnel analysis."""

from __future__ import annotations

import logging
import time
from typing import Any

from app.skills.base import BaseSkill
from app.skills.types import SkillResult

logger = logging.getLogger(__name__)


class AnalyzeFunnelSkill(BaseSkill):
    """Analyze conversion through a multi-step funnel."""

    name = "analyze_funnel"
    description = (
        "Conversion funnel analysis with step-by-step drop-off rates. "
        "Define a sequence of events/steps and see how many users progress through each. "
        "Works with GA4, PostHog, and Mixpanel data. "
        "Example queries: 'Show me the signup funnel: page view → sign up → first action', "
        "'What's the conversion rate from cart to purchase?', "
        "'Where do users drop off in onboarding?'. "
        "Do NOT use for time-series (use analyze_trends) or retention (use analyze_retention)."
    )
    category = "analysis"
    mcp_visible = True
    input_schema = {
        "type": "object",
        "properties": {
            "steps": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "event": {"type": "string", "description": "Event name for this step."},
                        "label": {"type": "string", "description": "Human-readable label (optional)."},
                    },
                    "required": ["event"],
                },
                "description": "Ordered list of funnel steps. Each step is an event name.",
            },
            "date_range": {
                "type": "string",
                "description": "Date range: 'last7days', 'last30days', or 'YYYY-MM-DD:YYYY-MM-DD'.",
            },
            "source": {
                "type": "string",
                "description": "Data source: 'ga4', 'mixpanel', or 'posthog'. Auto-selects if omitted.",
            },
        },
        "required": ["steps", "date_range"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "funnel": {"type": "array"},
            "overall_conversion": {"type": "number"},
            "summary": {"type": "string"},
            "metadata": {"type": "object"},
        },
    }

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()

        from app.skills.composite.helpers import (
            get_cred_provider, resolve_date_range, resolve_source,
        )
        from app.skills.registry import get_registry

        cred_provider = get_cred_provider(params)
        registry = get_registry()
        source = resolve_source(params, cred_provider)

        if not source:
            return SkillResult(
                success=False,
                error="No data sources configured.",
                execution_time_ms=int((time.monotonic() - t0) * 1000),
            )

        steps = params["steps"]
        if len(steps) < 2:
            return SkillResult(
                success=False,
                error="Funnel requires at least 2 steps.",
                execution_time_ms=int((time.monotonic() - t0) * 1000),
            )

        creds = cred_provider.get_credentials(source)
        if creds is None:
            return SkillResult(
                success=False,
                error=f"No credentials for {source}.",
                execution_time_ms=int((time.monotonic() - t0) * 1000),
            )
        config = cred_provider.get_config(source)
        from_date, to_date = resolve_date_range(params["date_range"])

        # Fetch event counts for each step
        if source == "posthog":
            funnel_data = await self._posthog_funnel(
                registry, creds, config, steps, from_date, to_date,
            )
        elif source == "ga4":
            funnel_data = await self._ga4_funnel(
                registry, creds, config, steps, params["date_range"],
            )
        elif source == "mixpanel":
            funnel_data = await self._mixpanel_funnel(
                registry, creds, config, steps, from_date, to_date,
            )
        else:
            return SkillResult(success=False, error=f"Unknown source: {source}")

        if not funnel_data.success:
            return funnel_data

        step_counts = (funnel_data.data or {}).get("step_counts", [])

        # Build funnel with drop-off analysis
        funnel_steps = []
        for i, step in enumerate(steps):
            count = step_counts[i] if i < len(step_counts) else 0
            label = step.get("label", step["event"])

            entry: dict[str, Any] = {
                "step": i + 1,
                "label": label,
                "event": step["event"],
                "count": count,
            }

            if i == 0:
                entry["conversion_rate"] = 1.0
                entry["drop_off_rate"] = 0.0
            else:
                prev_count = step_counts[i - 1] if i - 1 < len(step_counts) else 0
                entry["conversion_rate"] = round(count / prev_count, 4) if prev_count > 0 else 0.0
                entry["drop_off_rate"] = round(1 - entry["conversion_rate"], 4)
                entry["dropped"] = prev_count - count

            funnel_steps.append(entry)

        # Overall conversion
        first_count = step_counts[0] if step_counts else 0
        last_count = step_counts[-1] if step_counts else 0
        overall = round(last_count / first_count, 4) if first_count > 0 else 0.0

        # Find worst drop-off
        worst_step = None
        worst_drop = 0.0
        for step_info in funnel_steps[1:]:
            if step_info["drop_off_rate"] > worst_drop:
                worst_drop = step_info["drop_off_rate"]
                worst_step = step_info

        elapsed = int((time.monotonic() - t0) * 1000)

        summary_parts = [
            f"Funnel: {' → '.join(s.get('label', s['event']) for s in steps)}.",
            f"Overall conversion: {overall:.1%} ({first_count:,} → {last_count:,}).",
        ]
        if worst_step:
            summary_parts.append(
                f"Biggest drop-off: step {worst_step['step']} ({worst_step['label']}) "
                f"loses {worst_step['drop_off_rate']:.1%} of users."
            )

        return SkillResult(
            success=True,
            data={
                "funnel": funnel_steps,
                "overall_conversion": overall,
                "total_entered": first_count,
                "total_completed": last_count,
                "summary": " ".join(summary_parts),
                "metadata": {
                    "source": source,
                    "date_range": f"{from_date} to {to_date}",
                    "num_steps": len(steps),
                    "total_time_ms": elapsed,
                },
            },
            execution_time_ms=elapsed,
        )

    async def _posthog_funnel(
        self, registry: Any, creds: dict, config: dict,
        steps: list[dict], from_date: str, to_date: str,
    ) -> SkillResult:
        """Query PostHog for per-step unique user counts."""
        skill = registry.get_skill("posthog_query")
        if skill is None:
            return SkillResult(success=False, error="posthog_query skill not available")

        step_counts = []
        for step in steps:
            result = await skill.execute({
                "project_id": config.get("project_id", ""),
                "query": (
                    f"SELECT count(DISTINCT distinct_id) AS users "
                    f"FROM events WHERE event = '{step['event']}'"
                ),
                "date_from": from_date,
                "date_to": to_date,
                "credentials": creds,
            })
            if result.success:
                rows = (result.data or {}).get("rows", [])
                count = int(rows[0][0]) if rows and rows[0] else 0
                step_counts.append(count)
            else:
                step_counts.append(0)

        return SkillResult(success=True, data={"step_counts": step_counts})

    async def _ga4_funnel(
        self, registry: Any, creds: dict, config: dict,
        steps: list[dict], date_range: str,
    ) -> SkillResult:
        """Query GA4 for per-step event counts (using activeUsers metric)."""
        skill = registry.get_skill("ga4_query")
        if skill is None:
            return SkillResult(success=False, error="ga4_query skill not available")

        step_counts = []
        for step in steps:
            # GA4 doesn't have a native funnel API via the Data API,
            # so we query unique users per event as an approximation
            result = await skill.execute({
                "property_id": config.get("property_id", ""),
                "metrics": ["activeUsers"],
                "dimensions": ["eventName"],
                "date_range": date_range,
                "credentials": creds,
            })
            if result.success:
                rows = (result.data or {}).get("rows", [])
                # Find the row matching this event
                count = 0
                for row in rows:
                    if len(row) >= 2 and str(row[0]) == step["event"]:
                        count = int(row[1])
                        break
                step_counts.append(count)
            else:
                step_counts.append(0)

        return SkillResult(success=True, data={"step_counts": step_counts})

    async def _mixpanel_funnel(
        self, registry: Any, creds: dict, config: dict,
        steps: list[dict], from_date: str, to_date: str,
    ) -> SkillResult:
        """Query Mixpanel for per-step event counts."""
        skill = registry.get_skill("mixpanel_query")
        if skill is None:
            return SkillResult(success=False, error="mixpanel_query skill not available")

        step_counts = []
        for step in steps:
            result = await skill.execute({
                "project_id": config.get("project_id", ""),
                "event": step["event"],
                "from_date": from_date,
                "to_date": to_date,
                "type": "unique",
                "credentials": creds,
            })
            if result.success:
                rows = (result.data or {}).get("rows", [])
                total = sum(r[-1] for r in rows if r and isinstance(r[-1], (int, float)))
                step_counts.append(int(total))
            else:
                step_counts.append(0)

        return SkillResult(success=True, data={"step_counts": step_counts})
