"""MCP tool: compare_segments — compare a metric across segments or time periods."""

from __future__ import annotations

import logging
import time
from typing import Any

from app.skills.base import BaseSkill
from app.skills.types import SkillResult

logger = logging.getLogger(__name__)


class CompareSegmentsSkill(BaseSkill):
    """Compare a metric across two groups — A/B tests, before/after, segment breakdowns."""

    name = "compare_segments"
    description = (
        "Statistical comparison of a metric across two groups or time periods. "
        "Use for A/B test analysis, before/after comparisons, or segment breakdowns. "
        "Returns significance test results (p-value, effect size, confidence interval), "
        "per-segment changes, and contribution analysis. "
        "Example queries: 'Did the new checkout flow improve conversions?', "
        "'Compare signups this week vs last week by country', "
        "'Which segments drove the traffic drop?'. "
        "Do NOT use for time-series trends (use analyze_trends) or retention (use analyze_retention)."
    )
    category = "analysis"
    mcp_visible = True
    input_schema = {
        "type": "object",
        "properties": {
            "metric": {
                "type": "string",
                "description": "The metric to compare (e.g. 'sessions', 'Signup', '$pageview').",
            },
            "current_period": {
                "type": "string",
                "description": "Current/test period: 'last7days', 'last14days', or 'YYYY-MM-DD:YYYY-MM-DD'.",
            },
            "baseline_period": {
                "type": "string",
                "description": "Baseline/control period in the same format.",
            },
            "dimension": {
                "type": "string",
                "description": (
                    "Optional dimension to break down by (e.g. 'country', 'deviceCategory'). "
                    "If provided, shows which segments drove the change."
                ),
            },
            "source": {
                "type": "string",
                "description": "Data source: 'ga4', 'mixpanel', or 'posthog'. Auto-selects if omitted.",
            },
        },
        "required": ["metric", "current_period", "baseline_period"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "comparison": {"type": "object"},
            "summary": {"type": "string"},
            "metadata": {"type": "object"},
        },
    }

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()

        from app.skills.composite.helpers import (
            fetch_metric_for_period, get_cred_provider, resolve_source,
        )
        from app.skills.registry import get_registry

        cred_provider = get_cred_provider(params)
        registry = get_registry()
        source = resolve_source(params, cred_provider)

        if not source:
            return SkillResult(
                success=False,
                error="No data sources configured.",
                execution_time_ms=int((time.monotonic() - t0) * 1000),
            )

        dimension = params.get("dimension")

        # Fetch both periods
        current_result = await fetch_metric_for_period(
            registry, cred_provider, source,
            params["metric"], params["current_period"], dimension,
        )
        if not current_result.success:
            return current_result

        baseline_result = await fetch_metric_for_period(
            registry, cred_provider, source,
            params["metric"], params["baseline_period"], dimension,
        )
        if not baseline_result.success:
            return baseline_result

        elapsed = int((time.monotonic() - t0) * 1000)

        # If we have a dimension, use segment_comparison skill
        if dimension:
            seg_skill = registry.get_skill("stats_segment_comparison")
            if seg_skill is None:
                return SkillResult(
                    success=False,
                    error="stats_segment_comparison skill not available",
                    execution_time_ms=elapsed,
                )

            # Determine the metric column name from the data
            current_cols = (current_result.data or {}).get("columns", [])
            metric_col = None
            for col in current_cols:
                if col != dimension and col.lower() != "date":
                    metric_col = col
                    break
            if not metric_col:
                metric_col = current_cols[-1] if current_cols else params["metric"]

            seg_result = await seg_skill.execute({
                "current_data": current_result.data,
                "baseline_data": baseline_result.data,
                "dimension_col": dimension,
                "metric_col": metric_col,
            })

            elapsed = int((time.monotonic() - t0) * 1000)
            if seg_result.success:
                return SkillResult(
                    success=True,
                    data={
                        "comparison": seg_result.data,
                        "summary": (seg_result.data or {}).get("summary", ""),
                        "metadata": {
                            "source": source,
                            "metric": params["metric"],
                            "dimension": dimension,
                            "current_period": params["current_period"],
                            "baseline_period": params["baseline_period"],
                            "total_time_ms": elapsed,
                        },
                    },
                    execution_time_ms=elapsed,
                )
            return seg_result

        # No dimension — simple overall comparison with significance test
        current_rows = (current_result.data or {}).get("rows", [])
        baseline_rows = (baseline_result.data or {}).get("rows", [])

        # Extract numeric values from both periods
        current_values = _extract_values(current_rows)
        baseline_values = _extract_values(baseline_rows)

        if not current_values or not baseline_values:
            return SkillResult(
                success=True,
                data={
                    "comparison": {
                        "current_total": sum(current_values) if current_values else 0,
                        "baseline_total": sum(baseline_values) if baseline_values else 0,
                        "note": "Insufficient data for statistical test.",
                    },
                    "summary": "Data fetched but insufficient for statistical comparison.",
                    "metadata": {"source": source, "total_time_ms": elapsed},
                },
                execution_time_ms=elapsed,
            )

        # Run significance test
        sig_skill = registry.get_skill("stats_significance_test")
        if sig_skill and len(current_values) >= 2 and len(baseline_values) >= 2:
            sig_result = await sig_skill.execute({
                "control_values": baseline_values,
                "variant_values": current_values,
            })
            elapsed = int((time.monotonic() - t0) * 1000)

            if sig_result.success:
                sig_data = sig_result.data or {}
                return SkillResult(
                    success=True,
                    data={
                        "comparison": {
                            "baseline_mean": sig_data.get("control_mean"),
                            "current_mean": sig_data.get("variant_mean"),
                            "percent_change": sig_data.get("percent_change"),
                            "significant": sig_data.get("significant"),
                            "p_value": sig_data.get("p_value"),
                            "confidence_interval": sig_data.get("confidence_interval"),
                            "effect_size": sig_data.get("effect_size"),
                            "method": sig_data.get("method_used"),
                        },
                        "summary": sig_data.get("interpretation_template", ""),
                        "metadata": {
                            "source": source,
                            "metric": params["metric"],
                            "current_period": params["current_period"],
                            "baseline_period": params["baseline_period"],
                            "total_time_ms": elapsed,
                        },
                    },
                    execution_time_ms=elapsed,
                )

        # Fallback: simple comparison without significance test
        current_total = sum(current_values)
        baseline_total = sum(baseline_values)
        change = current_total - baseline_total
        change_pct = (change / baseline_total * 100) if baseline_total else 0

        return SkillResult(
            success=True,
            data={
                "comparison": {
                    "baseline_total": round(baseline_total, 2),
                    "current_total": round(current_total, 2),
                    "absolute_change": round(change, 2),
                    "percent_change": round(change_pct, 2),
                },
                "summary": (
                    f"{params['metric']} changed {change_pct:+.1f}% "
                    f"({baseline_total:,.0f} → {current_total:,.0f})."
                ),
                "metadata": {"source": source, "total_time_ms": elapsed},
            },
            execution_time_ms=elapsed,
        )


def _extract_values(rows: list) -> list[float]:
    """Extract numeric values from row data (last column assumed to be the metric)."""
    values = []
    for row in rows:
        if isinstance(row, (list, tuple)) and row:
            val = row[-1]
        elif isinstance(row, dict):
            val = next((v for v in reversed(row.values()) if isinstance(v, (int, float))), None)
        else:
            val = row
        if isinstance(val, (int, float)):
            values.append(float(val))
        elif isinstance(val, str):
            try:
                values.append(float(val))
            except ValueError:
                pass
    return values
