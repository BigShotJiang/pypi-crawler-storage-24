"""MCP tool: analyze_trends — time-series analysis across any connected source."""

from __future__ import annotations

import logging
import time
from typing import Any

from app.skills.base import BaseSkill
from app.skills.types import SkillResult

logger = logging.getLogger(__name__)


class AnalyzeTrendsSkill(BaseSkill):
    """Fetch time-series data from a connected source and run trend analysis."""

    name = "analyze_trends"
    description = (
        "Analyze how a metric changes over time. Use this when the user asks "
        "about trends, time-series, or 'how is X doing over the last N days/weeks/months.' "
        "Returns time-series data with trend direction, growth rates, change points, "
        "and anomaly flags. Works across all connected analytics sources (GA4, Mixpanel, "
        "PostHog) — specify a source or let Engageable auto-detect. "
        "Example queries: 'Show daily signups for the last 30 days', "
        "'Plot weekly active users by country for Q1 2026'. "
        "Do NOT use for funnel analysis (use analyze_funnel), retention curves "
        "(use analyze_retention), or statistical comparisons (use compare_segments)."
    )
    category = "analysis"
    mcp_visible = True
    input_schema = {
        "type": "object",
        "properties": {
            "metric": {
                "type": "string",
                "description": (
                    "The metric to analyze. For GA4: activeUsers, sessions, screenPageViews, "
                    "conversions, etc. For Mixpanel: an event name like 'Signup'. "
                    "For PostHog: an event name like '$pageview'."
                ),
            },
            "date_range": {
                "type": "string",
                "description": (
                    "Date range: 'last7days', 'last14days', 'last30days', "
                    "'last90days', 'yesterday', or 'YYYY-MM-DD:YYYY-MM-DD'."
                ),
            },
            "source": {
                "type": "string",
                "description": "Data source: 'ga4', 'mixpanel', or 'posthog'. Auto-selects if omitted.",
            },
            "dimensions": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Optional breakdown dimensions (GA4 only). E.g. ['country'].",
            },
            "granularity": {
                "type": "string",
                "description": "Time granularity: 'day' (default), 'week', or 'month'.",
            },
        },
        "required": ["metric", "date_range"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "data": {"type": "object"},
            "trend": {"type": "object"},
            "summary": {"type": "string"},
            "metadata": {"type": "object"},
        },
    }

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()

        from app.skills.composite.helpers import (
            fetch_time_series, get_cred_provider, resolve_source,
        )
        from app.skills.registry import get_registry

        cred_provider = get_cred_provider(params)
        registry = get_registry()
        source = resolve_source(params, cred_provider)
        granularity = params.get("granularity", "day")

        if not source:
            return SkillResult(
                success=False,
                error="No data sources configured. Set environment variables for GA4, Mixpanel, or PostHog.",
                execution_time_ms=int((time.monotonic() - t0) * 1000),
            )

        fetch_result = await fetch_time_series(
            registry, cred_provider, source,
            params["metric"], params["date_range"],
            params.get("dimensions"), granularity,
        )
        if not fetch_result.success:
            return fetch_result

        # Run trend detection
        trend_skill = registry.get_skill("stats_trend_detection")
        rows = (fetch_result.data or {}).get("rows", [])

        if trend_skill is None or len(rows) < 14:
            elapsed = int((time.monotonic() - t0) * 1000)
            note = (
                f"Only {len(rows)} data points — need 14+ for trend analysis."
                if len(rows) < 14
                else "Trend analysis skill not available."
            )
            return SkillResult(
                success=True,
                data={
                    "data": fetch_result.data,
                    "trend": {"note": note},
                    "summary": f"Fetched {len(rows)} rows from {source}. {note}",
                    "metadata": fetch_result.data.get("metadata", {}),
                },
                execution_time_ms=elapsed,
            )

        period = {"day": 7, "week": 4, "month": 12}.get(granularity, 7)
        trend_result = await trend_skill.execute({"data": fetch_result.data, "period": period})

        elapsed = int((time.monotonic() - t0) * 1000)
        trend_data = trend_result.data or {}

        if not trend_result.success:
            return SkillResult(
                success=True,
                data={
                    "data": fetch_result.data,
                    "trend": {"error": trend_result.error},
                    "summary": f"Data fetched from {source}. Trend analysis failed: {trend_result.error}",
                    "metadata": fetch_result.data.get("metadata", {}),
                },
                execution_time_ms=elapsed,
            )

        return SkillResult(
            success=True,
            data={
                "data": fetch_result.data,
                "trend": {
                    "direction": trend_data.get("trend_direction"),
                    "slope_pct": trend_data.get("trend_slope_pct"),
                    "p_value": trend_data.get("trend_p_value"),
                    "change_points": trend_data.get("change_points", []),
                    "anomalies": trend_data.get("anomaly_indices", []),
                },
                "summary": (
                    f"{trend_data.get('summary', '')} "
                    f"Source: {source}. {len(rows)} data points, {granularity} granularity."
                ),
                "metadata": {
                    **fetch_result.data.get("metadata", {}),
                    "trend_analysis_ms": trend_result.execution_time_ms,
                    "total_time_ms": elapsed,
                },
            },
            execution_time_ms=elapsed,
        )
