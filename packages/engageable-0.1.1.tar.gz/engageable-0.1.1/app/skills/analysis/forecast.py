"""Forecast skill — time series projections with confidence intervals."""

from __future__ import annotations

import time
from typing import Any

import numpy as np
import pandas as pd
from statsmodels.tsa.holtwinters import ExponentialSmoothing

from app.skills.base import BaseSkill
from app.skills.types import SkillResult
from app.skills.analysis.utils import (
    to_dataframe,
    ensure_date_column,
    extract_metric_column,
    validate_min_rows,
    coerce_numeric,
)


class ForecastSkill(BaseSkill):
    name = "stats_forecast"
    description = (
        "Generate time series forecasts using exponential smoothing (Holt-Winters). "
        "Produces predicted values with confidence intervals."
    )
    category = "analysis"
    input_schema = {
        "type": "object",
        "properties": {
            "data": {
                "type": "object",
                "description": "Time series data as {columns: [...], rows: [[...]]}",
            },
            "date_col": {
                "type": "string",
                "description": "Name of the date column (auto-detected if omitted)",
            },
            "metric_col": {
                "type": "string",
                "description": "Name of the metric column (auto-detected if omitted)",
            },
            "horizon": {
                "type": "integer",
                "description": "Number of periods to forecast (default: 14)",
            },
            "seasonal_periods": {
                "type": "integer",
                "description": "Seasonal period length (default: 7 for daily data)",
            },
            "confidence_level": {
                "type": "number",
                "description": "Confidence level for intervals (default: 0.95)",
            },
        },
        "required": ["data"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "forecast": {"type": "array"},
            "model_type": {"type": "string"},
            "diagnostics": {"type": "object"},
            "summary": {"type": "string"},
        },
    }
    guide = (
        "Use this skill when the user asks for projections, predictions, or 'what will happen'. "
        "Needs at least 14 data points (28+ recommended). Produces point forecasts plus "
        "upper/lower confidence bounds. Set horizon to control how far out to project."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()

        df = to_dataframe(params["data"])
        df = coerce_numeric(df)
        df, date_col = ensure_date_column(df, params.get("date_col"))
        metric_col = extract_metric_column(df, params.get("metric_col"), date_col)
        validate_min_rows(df, 14, "forecasting")

        values = df[metric_col].values.astype(float)
        dates = pd.to_datetime(df[date_col])

        horizon = params.get("horizon", 14)
        seasonal_periods = params.get("seasonal_periods", 7)
        confidence = params.get("confidence_level", 0.95)

        # Infer frequency for forecasted dates
        freq = pd.infer_freq(dates)
        if freq is None:
            # Assume daily if can't infer
            freq = "D"

        # Determine model configuration
        use_seasonal = len(values) >= seasonal_periods * 2

        model, model_type = self._fit_best_model(values, seasonal_periods, use_seasonal)

        # Forecast
        forecast_result = model.forecast(horizon)
        forecast_values = forecast_result.values if hasattr(forecast_result, 'values') else np.array(forecast_result)

        # Simulate prediction intervals via residual bootstrapping
        residuals = model.resid
        residual_std = float(np.std(residuals))
        from scipy import stats as scipy_stats
        z = scipy_stats.norm.ppf((1 + confidence) / 2)

        lower = forecast_values - z * residual_std
        upper = forecast_values + z * residual_std

        # Generate forecast dates
        last_date = dates.iloc[-1]
        forecast_dates = pd.date_range(start=last_date, periods=horizon + 1, freq=freq)[1:]

        forecast_list = []
        for i in range(len(forecast_values)):
            forecast_list.append({
                "date": forecast_dates[i].strftime("%Y-%m-%d") if i < len(forecast_dates) else None,
                "value": round(float(forecast_values[i]), 2),
                "lower": round(float(lower[i]), 2),
                "upper": round(float(upper[i]), 2),
            })

        # Model diagnostics
        aic = float(model.aic) if hasattr(model, "aic") else None
        mape = float(np.mean(np.abs(residuals / values) * 100)) if np.all(values != 0) else None

        summary = (
            f"Forecast: {horizon} periods using {model_type}. "
            f"Projected {metric_col} for period {horizon}: "
            f"{forecast_values[-1]:,.0f} ({confidence:.0%} CI: {lower[-1]:,.0f}–{upper[-1]:,.0f})."
        )
        if mape is not None:
            summary += f" Model MAPE: {mape:.1f}%."

        elapsed = int((time.monotonic() - t0) * 1000)
        return SkillResult(
            success=True,
            data={
                "forecast": forecast_list,
                "model_type": model_type,
                "historical": {
                    "dates": dates.dt.strftime("%Y-%m-%d").tolist(),
                    "values": [round(float(v), 2) for v in values],
                },
                "diagnostics": {
                    "aic": round(aic, 2) if aic is not None else None,
                    "mape": round(mape, 2) if mape is not None else None,
                    "residual_std": round(residual_std, 2),
                    "n_observations": len(values),
                },
                "confidence_level": confidence,
                "summary": summary,
            },
            execution_time_ms=elapsed,
        )

    def _fit_best_model(self, values: np.ndarray, seasonal_periods: int, use_seasonal: bool):
        """Try multiple model configs and return the best fit."""
        candidates = []

        # 1. Try Holt-Winters with seasonality
        if use_seasonal:
            for trend in ["add", "mul"]:
                for seasonal in ["add", "mul"]:
                    try:
                        model = ExponentialSmoothing(
                            values,
                            trend=trend,
                            seasonal=seasonal,
                            seasonal_periods=seasonal_periods,
                        ).fit(optimized=True)
                        candidates.append((
                            model,
                            f"Holt-Winters ({trend} trend, {seasonal} seasonal)",
                        ))
                    except Exception:
                        continue

        # 2. Try without seasonality
        for trend in ["add", "mul"]:
            try:
                model = ExponentialSmoothing(
                    values,
                    trend=trend,
                    seasonal=None,
                ).fit(optimized=True)
                candidates.append((model, f"Exponential smoothing ({trend} trend)"))
            except Exception:
                continue

        # 3. Simple exponential smoothing (fallback)
        try:
            model = ExponentialSmoothing(
                values,
                trend=None,
                seasonal=None,
            ).fit(optimized=True)
            candidates.append((model, "Simple exponential smoothing"))
        except Exception:
            pass

        if not candidates:
            raise RuntimeError("All model fits failed. Check your data for NaN or constant values.")

        # Pick by AIC
        best = min(candidates, key=lambda c: c[0].aic if hasattr(c[0], "aic") else float("inf"))
        return best
