"""Shared utilities for analysis skills.

Parses the {columns, rows} format from connector skills into pandas
DataFrames, extracts date columns, and validates input shapes.
"""

from __future__ import annotations

import logging
from typing import Any

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)

# Common date column names (case-insensitive match)
DATE_COLUMN_NAMES = {"date", "day", "week", "month", "year", "cohort_date", "event_date"}


def to_dataframe(data: dict[str, Any]) -> pd.DataFrame:
    """Convert a {columns, rows} dict into a pandas DataFrame.

    Accepts either:
      - {"columns": [...], "rows": [[...], ...]}  (connector output)
      - A plain dict of column→values
      - A pandas DataFrame (returned as-is)
    """
    if isinstance(data, pd.DataFrame):
        return data

    columns = data.get("columns")
    rows = data.get("rows")

    if columns is not None and rows is not None:
        df = pd.DataFrame(rows, columns=columns)
    elif isinstance(data, dict) and not columns:
        # Try treating it as {col: [values]}
        df = pd.DataFrame(data)
    else:
        raise ValueError(
            "Expected {columns: [...], rows: [[...]]} or a dict of arrays. "
            f"Got keys: {list(data.keys()) if isinstance(data, dict) else type(data)}"
        )

    return df


def find_date_column(df: pd.DataFrame) -> str | None:
    """Find the most likely date column in a DataFrame.

    Checks column names first, then tries to parse columns as dates.
    Returns the column name or None.
    """
    # 1. Check by name
    for col in df.columns:
        if col.lower().strip() in DATE_COLUMN_NAMES:
            return col

    # 2. Try to parse string columns as dates
    for col in df.columns:
        if df[col].dtype == object or str(df[col].dtype).startswith("datetime"):
            try:
                pd.to_datetime(df[col].head(5))
                return col
            except (ValueError, TypeError):
                continue

    return None


def ensure_date_column(df: pd.DataFrame, date_col: str | None = None) -> tuple[pd.DataFrame, str]:
    """Find or validate a date column and convert it to datetime.

    Returns (df_with_parsed_dates, date_column_name).
    Raises ValueError if no date column can be found.
    """
    if date_col is None:
        date_col = find_date_column(df)
    if date_col is None:
        raise ValueError(
            f"No date column found. Columns: {list(df.columns)}. "
            "Expected a column named 'date', 'day', 'week', 'month', etc."
        )
    if date_col not in df.columns:
        raise ValueError(f"Column '{date_col}' not found. Available: {list(df.columns)}")

    df = df.copy()
    df[date_col] = pd.to_datetime(df[date_col], errors="coerce")

    # Drop rows where date parsing failed
    n_before = len(df)
    df = df.dropna(subset=[date_col])
    if len(df) < n_before:
        logger.warning("Dropped %d rows with unparseable dates", n_before - len(df))

    df = df.sort_values(date_col).reset_index(drop=True)
    return df, date_col


def extract_metric_column(
    df: pd.DataFrame,
    metric_col: str | None = None,
    date_col: str | None = None,
) -> str:
    """Identify the numeric metric column in a DataFrame.

    If metric_col is specified, validates it exists and is numeric.
    Otherwise picks the first numeric column that isn't the date column.
    """
    if metric_col:
        if metric_col not in df.columns:
            raise ValueError(f"Metric column '{metric_col}' not found. Available: {list(df.columns)}")
        if not np.issubdtype(df[metric_col].dtype, np.number):
            # Try to convert
            try:
                df[metric_col] = pd.to_numeric(df[metric_col], errors="raise")
            except (ValueError, TypeError):
                raise ValueError(f"Column '{metric_col}' is not numeric")
        return metric_col

    # Auto-detect: first numeric column that isn't the date
    date_col_name = date_col or find_date_column(df)
    for col in df.columns:
        if col == date_col_name:
            continue
        if np.issubdtype(df[col].dtype, np.number):
            return col

    raise ValueError(
        f"No numeric metric column found. Columns: {list(df.columns)}. "
        "Provide a metric_col parameter."
    )


def validate_min_rows(df: pd.DataFrame, min_rows: int, context: str = "analysis") -> None:
    """Raise ValueError if the DataFrame has fewer than min_rows rows."""
    if len(df) < min_rows:
        raise ValueError(
            f"Not enough data for {context}: got {len(df)} rows, need at least {min_rows}."
        )


def coerce_numeric(df: pd.DataFrame, columns: list[str] | None = None) -> pd.DataFrame:
    """Convert specified columns (or all non-date columns) to numeric.

    Non-convertible values become NaN.
    """
    df = df.copy()
    if columns is None:
        date_col = find_date_column(df)
        columns = [c for c in df.columns if c != date_col]

    for col in columns:
        if col not in df.columns:
            continue
        try:
            is_numeric = np.issubdtype(df[col].dtype, np.number)
        except TypeError:
            # pandas extension dtypes (e.g. StringDtype) are not understood
            # by np.issubdtype — treat them as non-numeric.
            is_numeric = False
        if not is_numeric:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    return df
