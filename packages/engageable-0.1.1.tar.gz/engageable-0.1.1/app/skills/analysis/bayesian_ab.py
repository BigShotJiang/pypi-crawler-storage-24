from __future__ import annotations

import time
from typing import Any

import numpy as np
from scipy import stats

from app.skills.base import BaseSkill
from app.skills.types import SkillResult


class BayesianABSkill(BaseSkill):
    name = "stats_bayesian_ab"
    description = "Run a Bayesian A/B test analysis — reports probability that variant beats control."
    category = "analysis"
    input_schema = {
        "type": "object",
        "properties": {
            "control_successes": {
                "type": "integer",
                "description": "Number of conversions in the control group",
            },
            "control_trials": {
                "type": "integer",
                "description": "Total visitors/trials in the control group",
            },
            "variant_successes": {
                "type": "integer",
                "description": "Number of conversions in the variant group",
            },
            "variant_trials": {
                "type": "integer",
                "description": "Total visitors/trials in the variant group",
            },
            "prior_alpha": {
                "type": "number",
                "description": "Beta prior alpha parameter (default 1 = uninformative)",
            },
            "prior_beta": {
                "type": "number",
                "description": "Beta prior beta parameter (default 1 = uninformative)",
            },
            "num_samples": {
                "type": "integer",
                "description": "Monte Carlo samples for estimation (default 100000)",
            },
        },
        "required": ["control_successes", "control_trials", "variant_successes", "variant_trials"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "probability_variant_better": {"type": "number"},
            "expected_lift": {"type": "number"},
            "credible_interval_95": {"type": "array", "items": {"type": "number"}},
            "risk": {"type": "number"},
            "interpretation_template": {"type": "string"},
        },
    }
    guide = (
        "Use this skill when the user asks about A/B test results and wants a probability-based "
        "answer rather than a p-value. Reports '94% probability variant B is better' style results. "
        "Best for: ongoing experiments (doesn't require fixed sample size), small samples, "
        "or when the user wants intuitive probability statements. "
        "Requires conversion counts and trial counts for both groups. "
        "Related skills: stats_significance_test (frequentist alternative), "
        "stats_power_analysis (for test planning before running)."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()
        try:
            c_succ = params["control_successes"]
            c_trials = params["control_trials"]
            v_succ = params["variant_successes"]
            v_trials = params["variant_trials"]
            prior_a = params.get("prior_alpha", 1)
            prior_b = params.get("prior_beta", 1)
            n_samples = params.get("num_samples", 100_000)

            if c_trials <= 0 or v_trials <= 0:
                return SkillResult(
                    success=False,
                    error="Trial counts must be positive",
                    execution_time_ms=int((time.monotonic() - t0) * 1000),
                )

            if c_succ > c_trials or v_succ > v_trials:
                return SkillResult(
                    success=False,
                    error="Successes cannot exceed trials",
                    execution_time_ms=int((time.monotonic() - t0) * 1000),
                )

            # Posterior distributions: Beta(alpha + successes, beta + failures)
            control_post = stats.beta(
                prior_a + c_succ,
                prior_b + (c_trials - c_succ),
            )
            variant_post = stats.beta(
                prior_a + v_succ,
                prior_b + (v_trials - v_succ),
            )

            # Monte Carlo sampling
            rng = np.random.default_rng(42)
            control_samples = control_post.rvs(n_samples, random_state=rng)
            variant_samples = variant_post.rvs(n_samples, random_state=rng)

            # Probability variant is better
            prob_variant_better = float(np.mean(variant_samples > control_samples))

            # Expected lift (relative)
            lift_samples = (variant_samples - control_samples) / control_samples
            expected_lift = float(np.mean(lift_samples))

            # 95% credible interval on the lift
            ci_lower = float(np.percentile(lift_samples, 2.5))
            ci_upper = float(np.percentile(lift_samples, 97.5))

            # Expected loss (risk) — how much we lose if we pick variant but it's worse
            loss_samples = np.maximum(control_samples - variant_samples, 0)
            risk = float(np.mean(loss_samples))

            # Observed rates
            control_rate = c_succ / c_trials
            variant_rate = v_succ / v_trials
            observed_lift = (variant_rate - control_rate) / control_rate if control_rate > 0 else 0

            interpretation = (
                f"There is a {prob_variant_better * 100:.1f}% probability that the variant "
                f"is better than control. "
                f"Observed rates: control {control_rate * 100:.2f}%, variant {variant_rate * 100:.2f}% "
                f"({observed_lift * 100:+.1f}% lift). "
                f"Expected lift: {expected_lift * 100:+.1f}% "
                f"(95% credible interval: {ci_lower * 100:+.1f}% to {ci_upper * 100:+.1f}%). "
                f"Expected loss if variant is chosen: {risk * 100:.3f}%."
            )

            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=True,
                data={
                    "probability_variant_better": round(prob_variant_better, 4),
                    "expected_lift": round(expected_lift, 4),
                    "credible_interval_95": [round(ci_lower, 4), round(ci_upper, 4)],
                    "risk": round(risk, 6),
                    "control_rate": round(control_rate, 6),
                    "variant_rate": round(variant_rate, 6),
                    "observed_lift": round(observed_lift, 4),
                    "interpretation_template": interpretation,
                },
                execution_time_ms=elapsed,
            )

        except Exception as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=False,
                error=str(exc),
                execution_time_ms=elapsed,
            )
