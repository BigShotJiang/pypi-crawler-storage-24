"""Cohort retention skill — retention triangle from cohort or raw event data."""

from __future__ import annotations

import time
from typing import Any

import numpy as np
import pandas as pd

from app.skills.base import BaseSkill
from app.skills.types import SkillResult
from app.skills.analysis.utils import to_dataframe, coerce_numeric


class CohortRetentionSkill(BaseSkill):
    name = "stats_cohort_retention"
    description = (
        "Build a retention triangle from cohort data. Accepts either pre-aggregated "
        "cohort data (cohort_date, period, user_count) or raw event data "
        "(user_id, event_date). Returns retention rates per cohort and period."
    )
    category = "analysis"
    input_schema = {
        "type": "object",
        "properties": {
            "data": {
                "type": "object",
                "description": "Data as {columns: [...], rows: [[...]]}",
            },
            "cohort_col": {
                "type": "string",
                "description": "Column with the cohort date (default: auto-detect 'cohort_date' or 'cohortNthDay')",
            },
            "period_col": {
                "type": "string",
                "description": "Column with the period index (e.g. 0, 1, 2...). For raw events, omit this.",
            },
            "user_count_col": {
                "type": "string",
                "description": "Column with the user count per cohort-period. For raw events, omit this.",
            },
            "user_id_col": {
                "type": "string",
                "description": "Column with user IDs (for raw event data mode)",
            },
            "event_date_col": {
                "type": "string",
                "description": "Column with event dates (for raw event data mode)",
            },
            "period_unit": {
                "type": "string",
                "enum": ["day", "week", "month"],
                "description": "Granularity for period bucketing (default: week)",
            },
            "max_periods": {
                "type": "integer",
                "description": "Max number of periods to include (default: 12)",
            },
        },
        "required": ["data"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "retention_matrix": {"type": "object"},
            "cohort_sizes": {"type": "object"},
            "average_retention": {"type": "array"},
            "summary": {"type": "string"},
        },
    }
    guide = (
        "Use this skill when the user asks about retention, churn, or cohort analysis. "
        "It builds a retention triangle showing what percentage of users from each "
        "cohort are still active in subsequent periods. Works with pre-aggregated "
        "GA4 cohort data or raw user-level event data."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()

        df = to_dataframe(params["data"])
        max_periods = params.get("max_periods", 12)

        # Determine mode: pre-aggregated vs raw events
        user_id_col = params.get("user_id_col")
        event_date_col = params.get("event_date_col")

        if user_id_col and event_date_col:
            retention_df, cohort_sizes = self._from_raw_events(
                df, user_id_col, event_date_col,
                params.get("period_unit", "week"),
                max_periods,
            )
        else:
            retention_df, cohort_sizes = self._from_aggregated(
                df, params, max_periods,
            )

        # Calculate average retention per period
        avg_retention = {}
        for col in retention_df.columns:
            values = retention_df[col].dropna()
            if len(values) > 0:
                avg_retention[str(col)] = round(float(values.mean()), 4)

        # Build summary
        if 0 in avg_retention:
            p0 = avg_retention.get("0", avg_retention.get(0, 1.0))
        else:
            first_key = next(iter(avg_retention), None)
            p0 = avg_retention.get(first_key, 1.0) if first_key else 1.0

        periods = sorted(avg_retention.keys(), key=lambda x: int(x))
        if len(periods) >= 2:
            last_period = periods[-1]
            last_rate = avg_retention[last_period]
            summary = (
                f"Retention analysis across {len(cohort_sizes)} cohorts, "
                f"{len(periods)} periods. "
                f"Average period-{last_period} retention: {last_rate:.1%}."
            )
        else:
            summary = f"Retention analysis across {len(cohort_sizes)} cohorts."

        elapsed = int((time.monotonic() - t0) * 1000)
        return SkillResult(
            success=True,
            data={
                "retention_matrix": {
                    str(cohort): {str(p): round(float(v), 4) for p, v in row.items() if pd.notna(v)}
                    for cohort, row in retention_df.iterrows()
                },
                "cohort_sizes": {str(k): int(v) for k, v in cohort_sizes.items()},
                "average_retention": {str(k): v for k, v in avg_retention.items()},
                "num_cohorts": len(cohort_sizes),
                "num_periods": len(periods) if periods else 0,
                "summary": summary,
            },
            execution_time_ms=elapsed,
        )

    def _from_raw_events(
        self,
        df: pd.DataFrame,
        user_id_col: str,
        event_date_col: str,
        period_unit: str,
        max_periods: int,
    ) -> tuple[pd.DataFrame, dict]:
        """Build retention from raw (user_id, event_date) data."""
        df = df.copy()
        df[event_date_col] = pd.to_datetime(df[event_date_col], errors="coerce")
        df = df.dropna(subset=[event_date_col])

        # Determine cohort: first event date per user
        cohort_dates = df.groupby(user_id_col)[event_date_col].min().reset_index()
        cohort_dates.columns = [user_id_col, "_cohort_date"]

        df = df.merge(cohort_dates, on=user_id_col)

        # Calculate period offset
        if period_unit == "day":
            df["_period"] = (df[event_date_col] - df["_cohort_date"]).dt.days
        elif period_unit == "month":
            df["_period"] = (
                (df[event_date_col].dt.year - df["_cohort_date"].dt.year) * 12
                + (df[event_date_col].dt.month - df["_cohort_date"].dt.month)
            )
        else:  # week
            df["_period"] = (df[event_date_col] - df["_cohort_date"]).dt.days // 7

        df = df[df["_period"] <= max_periods]

        # Truncate cohort dates to period_unit for grouping
        if period_unit == "month":
            df["_cohort"] = df["_cohort_date"].dt.to_period("M").astype(str)
        elif period_unit == "week":
            df["_cohort"] = df["_cohort_date"].dt.to_period("W").astype(str)
        else:
            df["_cohort"] = df["_cohort_date"].dt.strftime("%Y-%m-%d")

        # Count unique users per cohort-period
        user_counts = (
            df.groupby(["_cohort", "_period"])[user_id_col]
            .nunique()
            .reset_index()
        )
        user_counts.columns = ["cohort", "period", "users"]

        # Pivot to matrix
        pivot = user_counts.pivot(index="cohort", columns="period", values="users")

        # Cohort sizes (period 0)
        cohort_sizes = {}
        for cohort in pivot.index:
            cohort_sizes[cohort] = int(pivot.loc[cohort, 0]) if 0 in pivot.columns else 0

        # Convert to retention rates (cast to float first to avoid int64 assignment errors)
        retention = pivot.astype(float)
        for cohort in retention.index:
            base = cohort_sizes.get(cohort, 1)
            if base > 0:
                retention.loc[cohort] = retention.loc[cohort] / base

        return retention, cohort_sizes

    def _from_aggregated(
        self,
        df: pd.DataFrame,
        params: dict[str, Any],
        max_periods: int,
    ) -> tuple[pd.DataFrame, dict]:
        """Build retention from pre-aggregated (cohort_date, period, user_count) data."""
        # Find columns first, then coerce only the numeric ones
        cohort_col = params.get("cohort_col")
        period_col = params.get("period_col")
        count_col = params.get("user_count_col")

        if not cohort_col:
            for c in df.columns:
                if c.lower() in {"cohort_date", "cohort", "cohortnthday", "cohort_group"}:
                    cohort_col = c
                    break
        if not period_col:
            for c in df.columns:
                if c.lower() in {"period", "nth_day", "nthday", "cohort_period", "day_offset", "week_offset"}:
                    period_col = c
                    break
        if not count_col:
            for c in df.columns:
                if c.lower() in {"user_count", "users", "active_users", "activeusers", "cohortactiveusers"}:
                    count_col = c
                    break

        if not cohort_col or not period_col or not count_col:
            raise ValueError(
                f"Could not identify cohort/period/count columns. "
                f"Available: {list(df.columns)}. Specify cohort_col, period_col, user_count_col."
            )

        df[period_col] = pd.to_numeric(df[period_col], errors="coerce")
        df[count_col] = pd.to_numeric(df[count_col], errors="coerce")
        df = df.dropna(subset=[period_col, count_col])
        df = df[df[period_col] <= max_periods]

        # Pivot
        pivot = df.pivot_table(
            index=cohort_col, columns=period_col, values=count_col, aggfunc="sum"
        )

        # Cohort sizes
        min_period = pivot.columns.min() if len(pivot.columns) > 0 else 0
        cohort_sizes = {}
        for cohort in pivot.index:
            cohort_sizes[str(cohort)] = int(pivot.loc[cohort, min_period]) if min_period in pivot.columns else 0

        # Retention rates (cast to float first to avoid int64 assignment errors)
        retention = pivot.astype(float)
        for cohort in retention.index:
            base = cohort_sizes.get(str(cohort), 1)
            if base > 0:
                retention.loc[cohort] = retention.loc[cohort] / base

        retention.index = retention.index.astype(str)
        retention.columns = retention.columns.astype(int)

        return retention, cohort_sizes
