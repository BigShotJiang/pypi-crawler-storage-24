"""Allow running the MCP server as: python -m app.mcp"""

from app.mcp.server import main

main()
