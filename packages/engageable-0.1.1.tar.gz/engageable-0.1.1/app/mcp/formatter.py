"""Token-efficient response formatting for MCP tool results.

Converts tabular data to CSV (50% fewer tokens than JSON), enforces a cell
budget, and puts the summary first so agents get the answer immediately.
"""

from __future__ import annotations

import csv
import io
import json
from typing import Any

# Max cells (rows x columns) before truncation
CELL_BUDGET = 1000


def format_skill_result(data: dict[str, Any] | None) -> str:
    """Format a SkillResult.data dict into a token-efficient string.

    Structure:
      1. Summary (plain English — agent can relay directly)
      2. Data (CSV if tabular, compact JSON otherwise)
      3. Metadata (source, timing, etc.)
    """
    if not data:
        return "OK (no data returned)"

    parts: list[str] = []

    # 1. Summary first — this is what the agent cares about most
    summary = data.get("summary")
    if summary:
        parts.append(summary)

    # 2. Data — detect tabular vs structured
    tabular = _extract_tabular(data)
    if tabular:
        columns, rows = tabular
        csv_str, truncated = _to_csv(columns, rows)
        parts.append(csv_str)
        if truncated:
            parts.append(f"(Showing {CELL_BUDGET // len(columns)} of {len(rows)} rows — truncated to {CELL_BUDGET} cells)")
    else:
        # Non-tabular data: compact JSON, skip keys already shown
        display_data = {
            k: v for k, v in data.items()
            if k not in ("summary", "metadata")
        }
        if display_data:
            parts.append(json.dumps(display_data, indent=2, default=str))

    # 3. Metadata last
    metadata = data.get("metadata")
    if metadata:
        # Compact single-line metadata
        meta_parts = []
        for k, v in metadata.items():
            if v is not None and v != "":
                meta_parts.append(f"{k}={v}")
        if meta_parts:
            parts.append(f"[{', '.join(meta_parts)}]")

    return "\n\n".join(parts)


def _extract_tabular(data: dict[str, Any]) -> tuple[list[str], list[list]] | None:
    """Try to find tabular data (columns + rows) in the result.

    Looks for the common pattern used by connector skills:
      {"columns": [...], "rows": [[...], ...]}
    Also checks nested under "data" key (used by composite skills).
    """
    # Direct columns + rows
    if "columns" in data and "rows" in data:
        cols = data["columns"]
        rows = data["rows"]
        if isinstance(cols, list) and isinstance(rows, list) and cols:
            return cols, rows

    # Nested under "data"
    inner = data.get("data")
    if isinstance(inner, dict) and "columns" in inner and "rows" in inner:
        cols = inner["columns"]
        rows = inner["rows"]
        if isinstance(cols, list) and isinstance(rows, list) and cols:
            return cols, rows

    return None


def _to_csv(columns: list[str], rows: list[list], budget: int = CELL_BUDGET) -> tuple[str, bool]:
    """Convert columns + rows to CSV string, respecting the cell budget.

    Returns (csv_string, was_truncated).
    """
    num_cols = len(columns)
    max_rows = budget // num_cols if num_cols > 0 else len(rows)
    truncated = len(rows) > max_rows
    display_rows = rows[:max_rows]

    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(columns)
    for row in display_rows:
        # Ensure row length matches columns
        padded = list(row) + [""] * (num_cols - len(row)) if len(row) < num_cols else list(row)[:num_cols]
        writer.writerow(padded)

    return buf.getvalue().strip(), truncated
