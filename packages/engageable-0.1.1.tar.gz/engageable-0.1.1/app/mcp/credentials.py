"""Credential provider abstraction for MCP server.

Decouples connector skills from Supabase — credentials can come from
~/.engageable/credentials.json (file-based) or environment variables.

Lookup order per provider:
  1. Environment variables (always win if set — standard 12-factor style)
  2. ~/.engageable/credentials.json (persistent, writable by configure_source tool)
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

logger = logging.getLogger(__name__)

CREDENTIALS_DIR = Path.home() / ".engageable"
CREDENTIALS_FILE = CREDENTIALS_DIR / "credentials.json"


@runtime_checkable
class CredentialProvider(Protocol):
    """Retrieves credentials and config for data source connectors."""

    def get_credentials(self, provider: str) -> dict[str, Any] | None:
        """Return credentials dict for a provider, or None if not configured."""
        ...

    def get_config(self, provider: str) -> dict[str, Any]:
        """Return provider-specific config (property_id, project_id, etc.)."""
        ...

    def persist_credentials(
        self, provider: str, credentials: dict[str, Any]
    ) -> None:
        """Update credentials after token refresh. No-op for env-based providers."""
        ...

    def save_source(
        self, provider: str, credentials: dict[str, Any], config: dict[str, Any]
    ) -> None:
        """Save a new data source configuration."""
        ...

    def remove_source(self, provider: str) -> None:
        """Remove a data source configuration."""
        ...

    def list_providers(self) -> list[str]:
        """Return list of configured provider names."""
        ...


def _read_credentials_file() -> dict[str, Any]:
    """Read ~/.engageable/credentials.json, returning {} if missing."""
    if not CREDENTIALS_FILE.is_file():
        return {}
    try:
        return json.loads(CREDENTIALS_FILE.read_text())
    except (json.JSONDecodeError, OSError) as exc:
        logger.warning("Failed to read %s: %s", CREDENTIALS_FILE, exc)
        return {}


def _write_credentials_file(data: dict[str, Any]) -> None:
    """Write ~/.engageable/credentials.json, creating the directory if needed."""
    CREDENTIALS_DIR.mkdir(parents=True, exist_ok=True)
    CREDENTIALS_FILE.write_text(json.dumps(data, indent=2) + "\n")
    # Restrict permissions — credentials file shouldn't be world-readable
    CREDENTIALS_FILE.chmod(0o600)


class EnvCredentialProvider:
    """Reads credentials from env vars and ~/.engageable/credentials.json.

    Env vars take priority. The file is writable via save_source() so the
    configure_source MCP tool can persist credentials from the agent.

    Environment variables per provider:

    GA4 (service account):
        GA4_CREDENTIALS_JSON  — path to service account JSON file OR inline JSON
        GA4_PROPERTY_ID       — GA4 property ID (e.g. "123456789")

    Mixpanel:
        MIXPANEL_SERVICE_ACCOUNT_USERNAME
        MIXPANEL_SERVICE_ACCOUNT_SECRET
        MIXPANEL_PROJECT_ID

    PostHog:
        POSTHOG_API_KEY
        POSTHOG_PROJECT_ID
        POSTHOG_BASE_URL  (default: https://us.posthog.com)
    """

    def get_credentials(self, provider: str) -> dict[str, Any] | None:
        # 1. Try env vars first
        env_creds = self._env_credentials(provider)
        if env_creds is not None:
            return env_creds

        # 2. Fall back to credentials file
        file_data = _read_credentials_file()
        source = file_data.get(provider)
        if source and source.get("credentials"):
            return source["credentials"]

        return None

    def get_config(self, provider: str) -> dict[str, Any]:
        # 1. Try env vars first
        env_config = self._env_config(provider)
        if env_config:
            return env_config

        # 2. Fall back to credentials file
        file_data = _read_credentials_file()
        source = file_data.get(provider)
        if source and source.get("config"):
            return source["config"]

        return {}

    def persist_credentials(
        self, provider: str, credentials: dict[str, Any]
    ) -> None:
        # Update credentials in the file (e.g. after OAuth token refresh)
        file_data = _read_credentials_file()
        if provider in file_data:
            file_data[provider]["credentials"] = credentials
            _write_credentials_file(file_data)
            logger.debug("Persisted refreshed credentials for %s", provider)
        else:
            logger.debug(
                "persist_credentials called for %s but not in file (no-op)", provider
            )

    def save_source(
        self, provider: str, credentials: dict[str, Any], config: dict[str, Any]
    ) -> None:
        """Save a data source to ~/.engageable/credentials.json."""
        file_data = _read_credentials_file()
        file_data[provider] = {
            "credentials": credentials,
            "config": config,
        }
        _write_credentials_file(file_data)
        logger.info("Saved %s credentials to %s", provider, CREDENTIALS_FILE)

    def remove_source(self, provider: str) -> None:
        """Remove a data source from ~/.engageable/credentials.json."""
        file_data = _read_credentials_file()
        if provider in file_data:
            del file_data[provider]
            _write_credentials_file(file_data)
            logger.info("Removed %s from %s", provider, CREDENTIALS_FILE)

    def list_providers(self) -> list[str]:
        providers = set()

        # From env vars
        if self._env_credentials("ga4") is not None:
            providers.add("ga4")
        if self._env_credentials("mixpanel") is not None:
            providers.add("mixpanel")
        if self._env_credentials("posthog") is not None:
            providers.add("posthog")

        # From credentials file
        file_data = _read_credentials_file()
        for provider, source in file_data.items():
            if isinstance(source, dict) and source.get("credentials"):
                providers.add(provider)

        return sorted(providers)

    # ---- env var readers ----

    def _env_credentials(self, provider: str) -> dict[str, Any] | None:
        handler = {
            "ga4": self._env_ga4_credentials,
            "mixpanel": self._env_mixpanel_credentials,
            "posthog": self._env_posthog_credentials,
        }.get(provider)
        return handler() if handler else None

    def _env_config(self, provider: str) -> dict[str, Any]:
        if provider == "ga4":
            prop_id = os.environ.get("GA4_PROPERTY_ID", "")
            return {"property_id": prop_id} if prop_id else {}
        if provider == "mixpanel":
            project_id = os.environ.get("MIXPANEL_PROJECT_ID", "")
            return {"project_id": project_id} if project_id else {}
        if provider == "posthog":
            project_id = os.environ.get("POSTHOG_PROJECT_ID", "")
            return {"project_id": project_id} if project_id else {}
        return {}

    def _env_ga4_credentials(self) -> dict[str, Any] | None:
        raw = os.environ.get("GA4_CREDENTIALS_JSON", "")
        if not raw:
            return None
        if raw.strip().startswith("{"):
            return json.loads(raw)
        try:
            with open(raw) as f:
                return json.load(f)
        except (OSError, json.JSONDecodeError) as exc:
            logger.error("Failed to load GA4 credentials from %s: %s", raw, exc)
            raise

    def _env_mixpanel_credentials(self) -> dict[str, Any] | None:
        username = os.environ.get("MIXPANEL_SERVICE_ACCOUNT_USERNAME", "")
        secret = os.environ.get("MIXPANEL_SERVICE_ACCOUNT_SECRET", "")
        if not username or not secret:
            return None
        return {
            "service_account_username": username,
            "service_account_secret": secret,
            "base_url": os.environ.get("MIXPANEL_BASE_URL", "https://mixpanel.com"),
        }

    def _env_posthog_credentials(self) -> dict[str, Any] | None:
        api_key = os.environ.get("POSTHOG_API_KEY", "")
        if not api_key:
            return None
        return {
            "api_key": api_key,
            "base_url": os.environ.get("POSTHOG_BASE_URL", "https://us.posthog.com"),
        }
