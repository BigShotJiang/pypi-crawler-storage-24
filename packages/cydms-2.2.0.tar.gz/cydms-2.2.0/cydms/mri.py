"""
cydms.mri
---------
MRI processing — skull stripping, mesh generation, cortical thickness

CHANGES v2:
- cortical thickness คำนวณด้วย distance_transform_edt จริง (mm) แทนการนับ % voxel
- เพิ่ม lobe_centroids (RAS mm) สำหรับ nearest-centroid lobe classification ใน source.py
- เพิ่ม mri_path ใน return สำหรับ moment-based coregistration ใน source.py
"""
import numpy as np
import nibabel as nib
import gc
from scipy import ndimage
from scipy.ndimage import label, distance_transform_edt
from skimage import measure


def process_mri(mri_path):
    img    = nib.load(mri_path)
    m_data = img.get_fdata().astype(np.float32)
    affine = img.affine.astype(np.float32)

    voxel_size = np.abs(img.header.get_zooms()[:3])
    min_vox    = float(np.min(voxel_size))
    lo_pct     = 76 if min_vox >= 0.9 else 50
    lo_thresh  = np.percentile(m_data[m_data > 0], lo_pct)
    hi_thresh  = np.percentile(m_data[m_data > 0], 98)

    # ── Skull stripping ──
    brain_mask = (m_data > lo_thresh) & (m_data < hi_thresh)
    brain_mask = ndimage.binary_fill_holes(brain_mask)
    brain_mask = ndimage.binary_erosion(brain_mask, iterations=5)
    brain_mask = ndimage.binary_dilation(brain_mask, iterations=2)
    brain_mask = ndimage.binary_fill_holes(brain_mask)

    labeled, n = label(brain_mask)
    if n > 0:
        sizes      = [np.sum(labeled == i) for i in range(1, n + 1)]
        brain_mask = labeled == (np.argmax(sizes) + 1)
    del labeled; gc.collect()

    m_clean  = m_data * brain_mask.astype(np.float32)
    nonzero  = m_clean[m_clean > 0]
    if len(nonzero) == 0:
        raise ValueError("ไม่พบ brain voxel หลัง masking — ลองปรับ threshold หรือตรวจสอบไฟล์ NIfTI")

    # ── Mesh generation ──
    verts, all_faces, _, _ = measure.marching_cubes(m_clean, level=np.percentile(nonzero, 40))
    del m_clean; gc.collect()

    verts_h   = np.hstack([verts, np.ones((len(verts), 1), dtype=np.float32)])
    verts_ras = (affine @ verts_h.T).T[:, :3]
    v_center  = (verts_ras.min(axis=0) + verts_ras.max(axis=0)) / 2
    verts_final = verts_ras - v_center

    # ── Downsample 4x สำหรับ thickness + centroid ──
    mri_ds     = m_data[::4, ::4, ::4]
    mask_ds    = brain_mask[::4, ::4, ::4]
    del m_data, brain_mask; gc.collect()

    affine_ds          = affine.copy()
    affine_ds[:3, :3] *= 4

    # แปลง voxel index → RAS mm
    mask_coords = np.array(np.where(mask_ds)).T.astype(np.float32)
    mask_h      = np.hstack([mask_coords, np.ones((len(mask_coords), 1), dtype=np.float32)])
    mask_ras    = (affine_ds @ mask_h.T).T[:, :3]

    # ── Lobe masks (ใช้ RAS mm จริง) ──
    x = mask_ras[:, 0]
    y = mask_ras[:, 1]
    z = mask_ras[:, 2]

    frontal_m   = y > 20
    occipital_m = y < -70
    temporal_m  = (~frontal_m) & (~occipital_m) & (z < -5) & (np.abs(x) > 20)
    parietal_m  = (~frontal_m) & (~occipital_m) & (~temporal_m)

    lobe_masks = {
        'frontal':   frontal_m,
        'occipital': occipital_m,
        'temporal':  temporal_m,
        'parietal':  parietal_m,
    }

    # ── รอบ 1: Lobe centroids จาก threshold หยาบๆ (RAS mm) ──
    _FALLBACK_CENTROIDS = {
        'frontal':   np.array([0.0,   45.0,  30.0], dtype=np.float32),
        'occipital': np.array([0.0,  -85.0,  10.0], dtype=np.float32),
        'temporal':  np.array([50.0, -15.0, -20.0], dtype=np.float32),
        'parietal':  np.array([0.0,  -50.0,  50.0], dtype=np.float32),
    }
    lobe_centroids_r1 = {}
    for lobe, mask in lobe_masks.items():
        if np.sum(mask) > 0:
            lobe_centroids_r1[lobe] = mask_ras[mask].mean(axis=0)
        else:
            lobe_centroids_r1[lobe] = _FALLBACK_CENTROIDS[lobe]

    # ── รอบ 2: nearest-centroid reclassify → lobe masks แม่นขึ้น ──
    # สำหรับแต่ละ voxel หา lobe ที่ centroid ใกล้สุด
    # ใช้ broadcasting: mask_ras (N,3) vs centroids (4,3)
    lobe_keys    = list(lobe_centroids_r1.keys())
    centroids_arr = np.array([lobe_centroids_r1[k] for k in lobe_keys], dtype=np.float32)  # (4,3)

    # distance squared ของทุก voxel ต่อทุก centroid → (N,4)
    diff          = mask_ras[:, None, :] - centroids_arr[None, :, :]  # (N,4,3)
    dist_sq       = np.sum(diff ** 2, axis=2)                          # (N,4)
    nearest_lobe  = np.argmin(dist_sq, axis=1)                         # (N,) index
    del diff, dist_sq; gc.collect()

    lobe_masks_r2 = {lobe: (nearest_lobe == i) for i, lobe in enumerate(lobe_keys)}

    # ── อัปเดต centroids จาก reclassified masks (ผลลัพธ์สุดท้าย) ──
    lobe_centroids = {}
    for lobe, mask in lobe_masks_r2.items():
        if np.sum(mask) > 0:
            lobe_centroids[lobe] = mask_ras[mask].mean(axis=0).tolist()
        else:
            lobe_centroids[lobe] = lobe_centroids_r1[lobe].tolist()

    # ── Cortical thickness ด้วย distance_transform_edt (mm จริง) ──
    vox_spacing = tuple(float(np.abs(affine_ds[i, i])) for i in range(3))  # (dx, dy, dz) mm
    edt_full    = distance_transform_edt(mask_ds, sampling=vox_spacing)     # mm
    edt_vals    = edt_full[mask_ds]   # (N,) mm — ลำดับตรงกับ mask_ras / nearest_lobe

    thickness = {}
    for lobe, mask in lobe_masks_r2.items():
        if np.sum(mask) > 0:
            # cortical voxels = EDT < 6mm (ใกล้ขอบ)
            cortical = mask & (edt_vals < 6.0)
            if np.sum(cortical) > 10:
                thickness[lobe] = float(np.mean(edt_vals[cortical]))
            else:
                thickness[lobe] = float(np.mean(edt_vals[mask]))
        else:
            thickness[lobe] = 0.0

    del edt_full, edt_vals, nearest_lobe, mri_ds, mask_ds, mask_ras; gc.collect()

    asymmetry_val = abs(np.sum(x < 0) - np.sum(x >= 0)) / max(len(x), 1)
    del x, y, z; gc.collect()

    mri_extent = float(np.max(np.abs(verts_final)))

    return {
        'verts':          verts_final.tolist(),
        'faces':          all_faces.tolist(),
        'thickness':      thickness,
        'asymmetry':      round(float(asymmetry_val) * 100, 2),
        'voxel_size':     min_vox,
        'threshold_pct':  lo_pct,
        'mri_extent':     mri_extent,
        'ras_center':     v_center.tolist(),
        'lobe_centroids': lobe_centroids,   # NEW: ส่งต่อให้ source.py
        'mri_path':       mri_path,         # NEW: ส่งต่อให้ source.py coregister
    }
