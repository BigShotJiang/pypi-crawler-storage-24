"""
The Sapiens-SDK is a software development kit that provides all the algorithms from Sapiens Technology®️
necessary for the development, training, fine-tuning, inference, and testing of the company's Artificial Intelligence models.
The module also includes tools and utility resources that facilitate the architecture and engineering of AI systems and distributed programs.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from setuptools import setup, find_packages
package_name = 'sapiens_sdk'
version = '1.0.3'
setup(
    name=package_name,
    version=version,
    author='SAPIENS TECHNOLOGY',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'dotenv==0.9.9',
        'pillow==10.3.0',
        'huggingface-hub==0.28.1',
        'utilities-nlp',
        'SUBMODELS',
        'FRANKENSTEIN-MODEL==5.3.7',
        'SAPI-ARCHITECTURE==1.0.5',
        'sapiens-bench==1.0.7',
        'sapiens-dataset==4.0.4',
        'sapiens-stack==1.0.2',
        'tqdm'
    ],
    url='https://github.com/sapiens-technology/SapiensSDK',
    license='Proprietary Software'
)
"""
The Sapiens-SDK is a software development kit that provides all the algorithms from Sapiens Technology®️
necessary for the development, training, fine-tuning, inference, and testing of the company's Artificial Intelligence models.
The module also includes tools and utility resources that facilitate the architecture and engineering of AI systems and distributed programs.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
