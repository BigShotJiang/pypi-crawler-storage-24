import sqlite3

import pytest

from db_test_helpers.core._errors import UnsupportedError
from db_test_helpers.sqlite import SqliteAdapter
from db_test_helpers.sqlite._adapter import _quote_identifier


class TestQuoteIdentifier:
    def test_normal_identifier(self):
        assert _quote_identifier("users") == '"users"'

    def test_identifier_with_double_quote(self):
        assert _quote_identifier('my"table') == '"my""table"'

    def test_empty_string_raises(self):
        with pytest.raises(ValueError):
            _quote_identifier("")


class TestDocumentIdGuard:
    def test_rejects_document_id(self, conn: sqlite3.Connection):
        adapter = SqliteAdapter(conn)
        with pytest.raises(UnsupportedError, match="SqliteAdapter does not support __document_id__"):
            adapter.write_record("t", "", {"__document_id__": "abc", "name": "Alice"})


class TestParentPathGuard:
    def test_clear_group_rejects_non_empty_parent_path(self, conn: sqlite3.Connection):
        adapter = SqliteAdapter(conn)
        with pytest.raises(UnsupportedError):
            adapter.clear_group("t", "some/path")

    def test_write_record_rejects_non_empty_parent_path(self, conn: sqlite3.Connection):
        adapter = SqliteAdapter(conn)
        with pytest.raises(UnsupportedError):
            adapter.write_record("t", "some/path", {"x": 1})

    def test_read_records_rejects_non_empty_parent_path(self, conn: sqlite3.Connection):
        adapter = SqliteAdapter(conn)
        with pytest.raises(UnsupportedError):
            adapter.read_records("t", "some/path")


class TestWriteRecord:
    def test_basic(self, conn: sqlite3.Connection):
        adapter = SqliteAdapter(conn)
        result = adapter.write_record("users", "", {"name": "Alice", "age": 30})
        assert result == {"name": "Alice", "age": 30}

    def test_multiple_fields(self, conn: sqlite3.Connection):
        adapter = SqliteAdapter(conn)
        data = {"a": 1, "b": "two", "c": 3.0, "d": True, "e": None}
        result = adapter.write_record("t", "", data)
        assert result == {"a": 1, "b": "two", "c": 3.0, "d": True, "e": None}

    def test_none_value(self, conn: sqlite3.Connection):
        adapter = SqliteAdapter(conn)
        result = adapter.write_record("t", "", {"x": None})
        assert result == {"x": None}

    def test_nested_dict_and_list(self, conn: sqlite3.Connection):
        adapter = SqliteAdapter(conn)
        data = {"nested": {"a": 1}, "items": [1, "two", True]}
        result = adapter.write_record("t", "", data)
        assert result == {"nested": {"a": 1}, "items": [1, "two", True]}

    def test_bool_preserved(self, conn: sqlite3.Connection):
        adapter = SqliteAdapter(conn)
        adapter.write_record("t", "", {"flag": True, "other": False})
        records = adapter.read_records("t", "")
        assert records[0]["flag"] is True
        assert records[0]["other"] is False

    def test_table_name_with_double_quote(self, conn: sqlite3.Connection):
        adapter = SqliteAdapter(conn)
        adapter.write_record('my"table', "", {"x": 1})
        records = adapter.read_records('my"table', "")
        assert records == [{"x": 1}]

    def test_table_name_with_sql_keyword(self, conn: sqlite3.Connection):
        adapter = SqliteAdapter(conn)
        adapter.write_record("select", "", {"x": 1})
        records = adapter.read_records("select", "")
        assert records == [{"x": 1}]

    def test_does_not_mutate_input(self, conn: sqlite3.Connection):
        adapter = SqliteAdapter(conn)
        data = {"name": "Alice"}
        adapter.write_record("t", "", data)
        assert data == {"name": "Alice"}


class TestReadRecords:
    def test_empty_table(self, conn: sqlite3.Connection):
        adapter = SqliteAdapter(conn)
        conn.execute('CREATE TABLE "t" (_data TEXT NOT NULL)')
        assert adapter.read_records("t", "") == []

    def test_multiple_records(self, conn: sqlite3.Connection):
        adapter = SqliteAdapter(conn)
        adapter.write_record("t", "", {"x": 1})
        adapter.write_record("t", "", {"x": 2})
        records = adapter.read_records("t", "")
        assert len(records) == 2
        assert {"x": 1} in records
        assert {"x": 2} in records

    def test_table_not_exists_returns_empty(self, conn: sqlite3.Connection):
        adapter = SqliteAdapter(conn)
        assert adapter.read_records("nonexistent", "") == []

    def test_type_roundtrip(self, conn: sqlite3.Connection):
        adapter = SqliteAdapter(conn)
        data = {
            "int_val": 42,
            "float_val": 3.14,
            "bool_val": True,
            "none_val": None,
            "dict_val": {"nested": "yes"},
            "list_val": [1, 2, 3],
        }
        adapter.write_record("t", "", data)
        records = adapter.read_records("t", "")
        assert len(records) == 1
        record = records[0]
        assert record["int_val"] == 42
        assert isinstance(record["int_val"], int)
        assert record["float_val"] == 3.14
        assert isinstance(record["float_val"], float)
        assert record["bool_val"] is True
        assert record["none_val"] is None
        assert record["dict_val"] == {"nested": "yes"}
        assert record["list_val"] == [1, 2, 3]


class TestClearGroup:
    def test_drops_table(self, conn: sqlite3.Connection):
        adapter = SqliteAdapter(conn)
        adapter.write_record("t", "", {"x": 1})
        adapter.clear_group("t", "")
        assert adapter.read_records("t", "") == []

    def test_nonexistent_table_no_error(self, conn: sqlite3.Connection):
        adapter = SqliteAdapter(conn)
        adapter.clear_group("nonexistent", "")

    def test_clear_does_not_affect_other_tables(self, conn: sqlite3.Connection):
        adapter = SqliteAdapter(conn)
        adapter.write_record("a", "", {"x": 1})
        adapter.write_record("b", "", {"x": 2})
        adapter.clear_group("a", "")
        assert adapter.read_records("a", "") == []
        assert adapter.read_records("b", "") == [{"x": 2}]

    def test_table_name_with_double_quote(self, conn: sqlite3.Connection):
        adapter = SqliteAdapter(conn)
        adapter.write_record('my"table', "", {"x": 1})
        adapter.clear_group('my"table', "")
        assert adapter.read_records('my"table', "") == []
