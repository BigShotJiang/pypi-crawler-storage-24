"""E2E tests: set_db_data + verify_db_data with SQLite."""

from __future__ import annotations

import sqlite3

import pytest

from db_test_helpers.core import Config, UnsupportedError, set_db_data, verify_db_data
from db_test_helpers.sqlite import SqliteAdapter


class TestE2eBasic:
    def test_set_and_verify(self, conn: sqlite3.Connection, tmp_path):
        seed = tmp_path / "seed.yaml"
        seed.write_text(
            """\
users:
  - name: "Alice"
    age: 30
  - name: "Bob"
    age: 25
"""
        )
        expected = tmp_path / "expected.yaml"
        expected.write_text(
            """\
users:
  - name: "Bob"
    age: 25
  - name: "Alice"
    age: 30
"""
        )
        adapter = SqliteAdapter(conn)
        set_db_data(adapter, str(seed))
        verify_db_data(adapter, str(expected))

    def test_set_replaces_existing(self, conn: sqlite3.Connection, tmp_path):
        adapter = SqliteAdapter(conn)

        adapter.write_record("users", "", {"name": "OldUser"})

        seed = tmp_path / "seed.yaml"
        seed.write_text(
            """\
users:
  - name: "Alice"
"""
        )
        set_db_data(adapter, str(seed))

        records = adapter.read_records("users", "")
        assert len(records) == 1
        assert records[0]["name"] == "Alice"


class TestE2eDsl:
    def test_var_and_any(self, conn: sqlite3.Connection, tmp_path):
        seed = tmp_path / "seed.yaml"
        seed.write_text(
            """\
users:
  - name: "$var(user_name)"
    role: "admin"
  - name: "Bob"
    role: "member"
"""
        )
        expected = tmp_path / "expected.yaml"
        expected.write_text(
            """\
users:
  - name: "$var(user_name)"
    role: "admin"
  - name: "$any()"
    role: "member"
"""
        )
        adapter = SqliteAdapter(conn)
        config = Config(variables={"user_name": "Alice"})

        set_db_data(adapter, str(seed), config)
        verify_db_data(adapter, str(expected), config)

    def test_matchers_in_verify(self, conn: sqlite3.Connection, tmp_path):
        seed = tmp_path / "seed.yaml"
        seed.write_text(
            """\
users:
  - name: "Alice"
    age: 30
"""
        )
        expected = tmp_path / "expected.yaml"
        expected.write_text(
            """\
users:
  - name: "$eq(Alice)"
    age: "$and($gt(0),$lt(100))"
"""
        )
        adapter = SqliteAdapter(conn)
        set_db_data(adapter, str(seed))
        verify_db_data(adapter, str(expected))

    def test_verify_failure(self, conn: sqlite3.Connection, tmp_path):
        seed = tmp_path / "seed.yaml"
        seed.write_text(
            """\
users:
  - name: "Alice"
"""
        )
        expected = tmp_path / "expected.yaml"
        expected.write_text(
            """\
users:
  - name: "Bob"
"""
        )
        adapter = SqliteAdapter(conn)
        set_db_data(adapter, str(seed))
        with pytest.raises(AssertionError):
            verify_db_data(adapter, str(expected))


class TestE2eChildren:
    def test_children_raises_not_implemented(self, conn: sqlite3.Connection, tmp_path):
        seed = tmp_path / "seed.yaml"
        seed.write_text(
            """\
users:
  - name: "Alice"
    __children__:
      posts:
        - title: "Hello"
"""
        )
        adapter = SqliteAdapter(conn)
        with pytest.raises(UnsupportedError):
            set_db_data(adapter, str(seed))
