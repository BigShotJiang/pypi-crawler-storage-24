"""SQLite adapter for db-test-helpers."""

from __future__ import annotations

import json
import sqlite3
from typing import Any

from db_test_helpers.core._errors import UnsupportedError


def _quote_identifier(name: str) -> str:
    if not name:
        raise ValueError("identifier must not be empty")
    return '"' + name.replace('"', '""') + '"'


def _check_parent_path(parent_path: str) -> None:
    if parent_path:
        raise UnsupportedError("SqliteAdapter does not support parent_path")


class SqliteAdapter:
    """DatabaseAdapter for SQLite via the standard library sqlite3 module.

    Args:
        conn: An open ``sqlite3.Connection``.
    """

    def __init__(self, conn: sqlite3.Connection) -> None:
        self._conn = conn

    def clear_group(self, group: str, parent_path: str) -> None:
        _check_parent_path(parent_path)
        self._conn.execute(f"DROP TABLE IF EXISTS {_quote_identifier(group)}")
        self._conn.commit()

    def write_record(self, group: str, parent_path: str, data: dict[str, Any]) -> dict[str, Any]:
        _check_parent_path(parent_path)
        if "__document_id__" in data:
            raise UnsupportedError("SqliteAdapter does not support __document_id__")
        table = _quote_identifier(group)
        self._conn.execute(f"CREATE TABLE IF NOT EXISTS {table} (_data TEXT NOT NULL)")
        self._conn.execute(f"INSERT INTO {table} (_data) VALUES (?)", (json.dumps(data),))
        self._conn.commit()
        return dict(data)

    def read_records(self, group: str, parent_path: str) -> list[dict[str, Any]]:
        _check_parent_path(parent_path)
        try:
            cursor = self._conn.execute(f"SELECT _data FROM {_quote_identifier(group)}")
        except sqlite3.OperationalError as e:
            if "no such table" in str(e):
                return []
            raise
        return [json.loads(row[0]) for row in cursor.fetchall()]
