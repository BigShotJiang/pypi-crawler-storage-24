import re


def delete_spaces_and_new_lines(text):
    text = re.sub(r"\n+", ". ", text)
    text = re.sub(r" +", " ", text)
    text = re.sub(r"\.{2,}", ".", text)
    text = text.strip()
    return text


def transform_to_chunks(text: str, chunk_size, overlap):
    sentences = (i.strip() for i in re.split(r"[.!?]\s+", text))
    chunks = []
    current_chunk = None
    for sentence in sentences:
        if not current_chunk:
            current_chunk = sentence
        elif len(current_chunk) + len(sentence) <= chunk_size:
            current_chunk += ". " + sentence
        else:
            if current_chunk:
                chunks.append(current_chunk.strip())
            if overlap > 0 and chunks:
                prev_chunk = chunks[-1]
                if len(prev_chunk) <= overlap:
                    overlap_text = prev_chunk
                else:
                    last_part = prev_chunk[-overlap:]
                    first_dot = last_part.find(". ")
                    if first_dot != -1:
                        overlap_text = last_part[first_dot + 1:].strip()
                    else:
                        overlap_text = None
                if overlap_text:
                    current_chunk = overlap_text + ". " + sentence
                else:
                    current_chunk = sentence
            else:
                current_chunk = sentence + ". "
    if current_chunk:
        chunks.append(current_chunk.strip())
    return chunks
