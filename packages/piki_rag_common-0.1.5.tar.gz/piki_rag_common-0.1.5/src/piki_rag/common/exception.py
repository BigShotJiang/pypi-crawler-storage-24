class PikiBaseException(Exception):
    pass


class LLMProviderException(PikiBaseException):
    def __init__(self, status_code: int = None, message: str = None):
        self.status_code = status_code
        self.message = message
        super().__init__(f"{status_code}: {message}")


class WebScrappingException(PikiBaseException):
    def __init__(self, message: str = None):
        self.message = message
        super().__init__(message)


class FileNotFoundException(PikiBaseException):
    def __init__(self, message=None):
        self.message = message
        super().__init__(message)
