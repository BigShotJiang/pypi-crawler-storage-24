from enum import Enum


class HeaterMode(Enum):
    """Heater operating mode."""

    SUMMER = "Summer"  # In summer mode only water is heated
    WINTER = "Winter"  # In winter mode both water and radiators are heated
    OFF = "Off"  # The heater is off


class ManualMode(Enum):
    """Manual mode."""

    ENABLED = "Manual mode"  # Manual mode is enabled
    DISABLED = "Auto mode"  # Manual mode is disabled


class PartyMode(Enum):
    """Party mode."""

    ENABLED = "Party mode"  # Party mode is enabled
    DISABLED = "Auto mode"  # Party mode is disabled


class VacationMode(Enum):
    """Vacation mode."""

    ENABLED = "Vacation mode"  # Vacation mode is enabled
    DISABLED = "Auto mode"  # Vacation mode is disabled


class WaterHeaterEnabled(Enum):
    """Water heater enabled."""

    ENABLED = "Water heater enabled"  # Water heater is enabled
    DISABLED = "Water heater disabled"  # Water heater is disabled


class ValvePosition(Enum):
    """Valve position."""

    DHW = "DHW"  # Domestic Hot Water
    CO = "CO"  # Central Heating


class PumpStatus(Enum):
    """Pump status."""

    RUNNING = "Running"
    IDLE = "Idle"


# Registry for resolving enum paths from YAML (e.g. "ManualMode.ENABLED" -> ManualMode.ENABLED)
ENUM_REGISTRY: dict[str, type[Enum]] = {
    "HeaterMode": HeaterMode,
    "ManualMode": ManualMode,
    "PartyMode": PartyMode,
    "VacationMode": VacationMode,
    "WaterHeaterEnabled": WaterHeaterEnabled,
    "ValvePosition": ValvePosition,
    "PumpStatus": PumpStatus,
}
