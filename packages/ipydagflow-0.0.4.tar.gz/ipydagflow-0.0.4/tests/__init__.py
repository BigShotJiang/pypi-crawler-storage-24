"""Tests for ipydagflow package."""
