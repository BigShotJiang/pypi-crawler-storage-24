# Changelog

All notable changes to this project will be documented in this file.

This project adheres to [Semantic Versioning](https://semver.org/).

## [0.1.0] — 2026-03-24

### Added

- Core conversion engine with intelligent DOM pre-processing and Playwright rendering.
- DOM analyzer: structure analysis, content density metrics, pattern detection (tables, lists, code blocks, images).
- Pre-processor pipeline: page break injection, font normalization, margin optimization, CSS sanitization.
- Browser pool for efficient Chromium instance reuse across batch conversions.
- Public API: `convert()`, `async_convert()`, `convert_file()`, `convert_batch()`, `async_convert_batch()`, `PDFConfig`.
- CLI interface (Click): single file, batch, stdin, and URL conversion with `--strategy`, `--format`, `--margin` options.
- REST API (FastAPI): five endpoints (`/convert/html`, `/convert/url`, `/convert/file`, `/health`, `/config/defaults`), rate limiting, request ID, and error handling middleware.
- 122 unit tests, 69 integration tests, 10 visual regression tests (201 total).
- GitHub Actions CI/CD pipeline: lint, unit, integration, and visual test stages.
- Full type hints and docstrings on all public API surfaces.
