"""Fixtures and configuration for visual regression tests."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

VISUAL_DIR = Path(__file__).parent
FIXTURES_DIR = VISUAL_DIR / "fixtures"
BASELINES_DIR = VISUAL_DIR / "baselines"


# ---------------------------------------------------------------------------
# Pytest hooks and options
# ---------------------------------------------------------------------------

def pytest_addoption(parser: pytest.Parser) -> None:
    """Add custom pytest options for visual testing."""
    parser.addoption(
        "--update-baselines",
        action="store_true",
        default=False,
        help="Update baseline screenshots with current test outputs",
    )


def pytest_configure(config: pytest.Config) -> None:
    """Register custom markers."""
    config.addinivalue_line(
        "markers", "visual: mark test as a visual regression test"
    )


# ---------------------------------------------------------------------------
# Fixtures: HTML content
# ---------------------------------------------------------------------------

@pytest.fixture
def simple_html() -> str:
    """Load simple.html fixture."""
    return (FIXTURES_DIR / "simple.html").read_text(encoding="utf-8")


@pytest.fixture
def tables_html() -> str:
    """Load tables.html fixture."""
    return (FIXTURES_DIR / "tables.html").read_text(encoding="utf-8")


@pytest.fixture
def long_document_html() -> str:
    """Load long-document.html fixture."""
    return (FIXTURES_DIR / "long-document.html").read_text(encoding="utf-8")


@pytest.fixture
def code_blocks_html() -> str:
    """Load code-blocks.html fixture."""
    return (FIXTURES_DIR / "code-blocks.html").read_text(encoding="utf-8")


@pytest.fixture
def images_html() -> str:
    """Load images.html fixture."""
    return (FIXTURES_DIR / "images.html").read_text(encoding="utf-8")


@pytest.fixture
def complex_layout_html() -> str:
    """Load complex-layout.html fixture."""
    return (FIXTURES_DIR / "complex-layout.html").read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# Fixtures: Baseline management
# ---------------------------------------------------------------------------

@pytest.fixture
def update_baselines(request: pytest.FixtureRequest) -> bool:
    """Check if --update-baselines flag is set."""
    return request.config.getoption("--update-baselines")


@pytest.fixture
def baseline_dir() -> Path:
    """Get the baselines directory path."""
    return BASELINES_DIR


def save_baseline(
    test_name: str,
    pdf_bytes: bytes,
    metadata: dict | None = None,
) -> None:
    """Save a PDF baseline and optional metadata.

    Args:
        test_name: Name of the test (used for filename).
        pdf_bytes: PDF content to save.
        metadata: Optional dict with info about the PDF (size, pages, etc.).
    """
    BASELINES_DIR.mkdir(parents=True, exist_ok=True)

    # Save PDF
    pdf_path = BASELINES_DIR / f"{test_name}.pdf"
    pdf_path.write_bytes(pdf_bytes)

    # Save metadata
    if metadata:
        meta_path = BASELINES_DIR / f"{test_name}.json"
        meta_path.write_text(json.dumps(metadata, indent=2))


def load_baseline(test_name: str) -> tuple[bytes | None, dict | None]:
    """Load a PDF baseline and optional metadata.

    Args:
        test_name: Name of the test.

    Returns:
        Tuple of (pdf_bytes or None, metadata_dict or None).
    """
    pdf_path = BASELINES_DIR / f"{test_name}.pdf"
    if not pdf_path.exists():
        return None, None

    pdf_bytes = pdf_path.read_bytes()

    meta_path = BASELINES_DIR / f"{test_name}.json"
    metadata = None
    if meta_path.exists():
        metadata = json.loads(meta_path.read_text())

    return pdf_bytes, metadata


@pytest.fixture
def baseline_manager():
    """Provide baseline save/load functions to tests."""
    return {
        "save": save_baseline,
        "load": load_baseline,
        "dir": BASELINES_DIR,
    }
