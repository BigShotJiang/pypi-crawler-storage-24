"""Visual regression tests for html2pdf."""
