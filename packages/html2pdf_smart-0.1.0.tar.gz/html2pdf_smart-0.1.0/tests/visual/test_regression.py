"""Visual regression tests for html2pdf.

These tests convert reference HTML documents to PDF and verify:
1. PDFs are valid and non-empty
2. PDFs have reasonable file sizes for their content type
3. Baseline comparisons (infrastructure scaffolded for future pixel-level testing)

NOTE: These tests can be skipped if Playwright or the conversion engine is unavailable.
      Use @pytest.mark.visual to identify visual regression tests.
      Use --update-baselines to save current outputs as new baseline references.
"""

from __future__ import annotations

from pathlib import Path

import pytest

# Try to import the main conversion function
try:
    import html2pdf
    CONVERSION_AVAILABLE = True
except ImportError:
    CONVERSION_AVAILABLE = False


# ---------------------------------------------------------------------------
# Markers and skip conditions
# ---------------------------------------------------------------------------

pytestmark = pytest.mark.visual


def pytest_runtest_setup(item: pytest.Item) -> None:
    """Skip visual tests if conversion not available."""
    if "visual" in item.keywords and not CONVERSION_AVAILABLE:
        pytest.skip("html2pdf conversion not available")


# ---------------------------------------------------------------------------
# Baseline metadata helpers
# ---------------------------------------------------------------------------

def get_pdf_metadata(pdf_bytes: bytes) -> dict:
    """Extract basic metadata from PDF bytes.

    Args:
        pdf_bytes: Raw PDF file contents.

    Returns:
        Dictionary with 'size_kb' and 'valid' keys.
    """
    size_kb = len(pdf_bytes) / 1024.0
    valid = pdf_bytes.startswith(b"%PDF")
    return {
        "size_kb": round(size_kb, 2),
        "valid": valid,
        "num_bytes": len(pdf_bytes),
    }


def assert_valid_pdf(pdf_bytes: bytes, min_size: int = 500) -> None:
    """Assert that pdf_bytes is a valid PDF of reasonable size.

    Args:
        pdf_bytes: Raw PDF file contents.
        min_size: Minimum expected PDF size in bytes.

    Raises:
        AssertionError: If PDF is invalid or too small.
    """
    assert pdf_bytes, "PDF bytes are empty"
    assert pdf_bytes.startswith(b"%PDF"), "PDF does not start with %PDF header"
    assert len(pdf_bytes) >= min_size, (
        f"PDF size ({len(pdf_bytes)} bytes) is below minimum ({min_size} bytes)"
    )


# ---------------------------------------------------------------------------
# Test: Simple HTML
# ---------------------------------------------------------------------------

def test_simple_html(
    simple_html: str,
    update_baselines: bool,
    baseline_manager: dict,
) -> None:
    """Test conversion of simple.html (basic headings, paragraphs, lists).

    Verifies:
    - Conversion produces a valid PDF
    - PDF size is reasonable (>1 KB)
    - Baseline metadata is saved or compared
    """
    pdf_bytes = html2pdf.convert(simple_html)
    assert_valid_pdf(pdf_bytes, min_size=1000)

    metadata = get_pdf_metadata(pdf_bytes)

    if update_baselines:
        baseline_manager["save"]("simple_html", pdf_bytes, metadata)
    else:
        baseline_bytes, baseline_meta = baseline_manager["load"]("simple_html")
        if baseline_bytes is not None:
            assert len(pdf_bytes) > 0, "Converted PDF is empty"
            if baseline_meta:
                assert metadata["size_kb"] > 0, "PDF size should be positive"


# ---------------------------------------------------------------------------
# Test: Tables
# ---------------------------------------------------------------------------

def test_tables_html(
    tables_html: str,
    update_baselines: bool,
    baseline_manager: dict,
) -> None:
    """Test conversion of tables.html (data table with 12 rows).

    Verifies:
    - Conversion produces a valid PDF
    - PDF size is reasonable (>2 KB for table content)
    - Baseline metadata is saved or compared
    """
    pdf_bytes = html2pdf.convert(tables_html)
    assert_valid_pdf(pdf_bytes, min_size=2000)

    metadata = get_pdf_metadata(pdf_bytes)

    if update_baselines:
        baseline_manager["save"]("tables_html", pdf_bytes, metadata)
    else:
        baseline_bytes, baseline_meta = baseline_manager["load"]("tables_html")
        if baseline_bytes is not None:
            assert len(pdf_bytes) > 0, "Converted PDF is empty"


# ---------------------------------------------------------------------------
# Test: Long Document
# ---------------------------------------------------------------------------

def test_long_document_html(
    long_document_html: str,
    update_baselines: bool,
    baseline_manager: dict,
) -> None:
    """Test conversion of long-document.html (multi-page content).

    Verifies:
    - Conversion produces a valid multi-page PDF
    - PDF size is larger due to multiple pages (>3 KB)
    - Baseline metadata is saved or compared
    """
    pdf_bytes = html2pdf.convert(long_document_html)
    assert_valid_pdf(pdf_bytes, min_size=3000)

    metadata = get_pdf_metadata(pdf_bytes)
    assert metadata["size_kb"] >= 3.0, "Long document PDF should be at least 3 KB"

    if update_baselines:
        baseline_manager["save"]("long_document_html", pdf_bytes, metadata)
    else:
        baseline_bytes, baseline_meta = baseline_manager["load"]("long_document_html")
        if baseline_bytes is not None:
            assert len(pdf_bytes) > 0, "Converted PDF is empty"


# ---------------------------------------------------------------------------
# Test: Code Blocks
# ---------------------------------------------------------------------------

def test_code_blocks_html(
    code_blocks_html: str,
    update_baselines: bool,
    baseline_manager: dict,
) -> None:
    """Test conversion of code-blocks.html (pre/code elements).

    Verifies:
    - Conversion produces a valid PDF
    - PDF size is reasonable (>1.5 KB for code content)
    - Baseline metadata is saved or compared
    """
    pdf_bytes = html2pdf.convert(code_blocks_html)
    assert_valid_pdf(pdf_bytes, min_size=1500)

    metadata = get_pdf_metadata(pdf_bytes)

    if update_baselines:
        baseline_manager["save"]("code_blocks_html", pdf_bytes, metadata)
    else:
        baseline_bytes, baseline_meta = baseline_manager["load"]("code_blocks_html")
        if baseline_bytes is not None:
            assert len(pdf_bytes) > 0, "Converted PDF is empty"


# ---------------------------------------------------------------------------
# Test: Images
# ---------------------------------------------------------------------------

def test_images_html(
    images_html: str,
    update_baselines: bool,
    baseline_manager: dict,
) -> None:
    """Test conversion of images.html (inline SVG data URIs).

    Verifies:
    - Conversion produces a valid PDF with embedded images
    - PDF size is reasonable (>2 KB for image content)
    - Baseline metadata is saved or compared
    """
    pdf_bytes = html2pdf.convert(images_html)
    assert_valid_pdf(pdf_bytes, min_size=2000)

    metadata = get_pdf_metadata(pdf_bytes)

    if update_baselines:
        baseline_manager["save"]("images_html", pdf_bytes, metadata)
    else:
        baseline_bytes, baseline_meta = baseline_manager["load"]("images_html")
        if baseline_bytes is not None:
            assert len(pdf_bytes) > 0, "Converted PDF is empty"


# ---------------------------------------------------------------------------
# Test: Complex Layout
# ---------------------------------------------------------------------------

def test_complex_layout_html(
    complex_layout_html: str,
    update_baselines: bool,
    baseline_manager: dict,
) -> None:
    """Test conversion of complex-layout.html (mixed content).

    Verifies:
    - Conversion produces a valid PDF with multiple content types
    - PDF size is reasonable (>3 KB for complex content)
    - Baseline metadata is saved or compared

    This test exercises:
    - Multiple heading levels
    - Tables
    - Code blocks
    - Inline SVG images
    - Styled divs
    - Lists
    - Text formatting
    """
    pdf_bytes = html2pdf.convert(complex_layout_html)
    assert_valid_pdf(pdf_bytes, min_size=3000)

    metadata = get_pdf_metadata(pdf_bytes)
    assert metadata["size_kb"] >= 3.0, "Complex layout PDF should be at least 3 KB"

    if update_baselines:
        baseline_manager["save"]("complex_layout_html", pdf_bytes, metadata)
    else:
        baseline_bytes, baseline_meta = baseline_manager["load"]("complex_layout_html")
        if baseline_bytes is not None:
            assert len(pdf_bytes) > 0, "Converted PDF is empty"


# ---------------------------------------------------------------------------
# Test: Baseline infrastructure
# ---------------------------------------------------------------------------

def test_baseline_infrastructure(baseline_dir: Path) -> None:
    """Verify that the baseline directory structure is in place.

    This test ensures the infrastructure for baseline comparison is ready.
    """
    assert baseline_dir.exists(), "Baselines directory does not exist"
    assert baseline_dir.is_dir(), "Baselines is not a directory"

    gitkeep = baseline_dir / ".gitkeep"
    assert gitkeep.exists(), "Missing .gitkeep file in baselines directory"


# ---------------------------------------------------------------------------
# Test: Conversion consistency
# ---------------------------------------------------------------------------

def test_conversion_consistency(simple_html: str) -> None:
    """Test that multiple conversions of the same HTML produce consistent results.

    NOTE: This test assumes PDF generation is deterministic for the same input.
          If timestamps or random elements are included, this test may fail.
    """
    pdf1 = html2pdf.convert(simple_html)
    pdf2 = html2pdf.convert(simple_html)

    assert_valid_pdf(pdf1)
    assert_valid_pdf(pdf2)

    # PDFs should be same size (exact byte equality fails due to Playwright timestamps)
    assert len(pdf1) == len(pdf2), "PDF conversion is not consistent in size"


# ---------------------------------------------------------------------------
# Test: Error handling
# ---------------------------------------------------------------------------

def test_invalid_html_handling() -> None:
    """Test that invalid HTML is handled gracefully.

    The converter should still produce output or raise a meaningful error.
    """
    invalid_html = "<div>unclosed div<div>"

    try:
        pdf_bytes = html2pdf.convert(invalid_html)
        # If conversion succeeds, PDF should still be valid
        assert_valid_pdf(pdf_bytes, min_size=500)
    except Exception as e:
        # If conversion fails, error should be informative
        assert str(e), "Error message should not be empty"


def test_empty_html_handling() -> None:
    """Test that empty HTML is handled gracefully."""
    empty_html = ""

    try:
        pdf_bytes = html2pdf.convert(empty_html)
        # If conversion succeeds, PDF should be minimal
        if pdf_bytes:
            assert pdf_bytes.startswith(b"%PDF"), "Invalid PDF format"
    except Exception as e:
        # If it raises, error should be informative
        assert str(e), "Error message should not be empty"
