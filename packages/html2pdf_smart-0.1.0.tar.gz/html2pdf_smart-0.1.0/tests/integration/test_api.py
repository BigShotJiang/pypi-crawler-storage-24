"""Integration tests for the html2pdf FastAPI REST API.

These tests use the FastAPI TestClient to invoke actual API endpoints with
a real Playwright browser. Tests are skipped automatically if Chromium is
not available.
"""

import json
from collections.abc import Generator

import pytest
from fastapi.testclient import TestClient

from html2pdf.api.app import create_app

pytestmark = pytest.mark.integration


@pytest.fixture
def client() -> Generator[TestClient, None, None]:
    """Create a FastAPI TestClient with lifespan events for the html2pdf API."""
    app = create_app()
    with TestClient(app) as c:
        yield c


class TestConvertEndpoint:
    """Test the POST /convert endpoint."""

    def test_convert_simple_html(self, skip_if_no_browser, client, simple_html):
        """Test POST /convert returns real PDF."""
        response = client.post(
            "/convert",
            json={"html": simple_html},
        )

        assert response.status_code == 200
        assert response.headers["content-type"] == "application/pdf"

        pdf_bytes = response.content
        assert pdf_bytes.startswith(b"%PDF")
        assert len(pdf_bytes) > 0

    def test_convert_with_config(self, skip_if_no_browser, client, simple_html):
        """Test POST /convert with config overrides."""
        response = client.post(
            "/convert",
            json={
                "html": simple_html,
                "config": {
                    "page_size": "Letter",
                    "landscape": True,
                },
            },
        )

        assert response.status_code == 200
        pdf_bytes = response.content
        assert pdf_bytes.startswith(b"%PDF")

    def test_convert_table_html(self, skip_if_no_browser, client, table_html):
        """Test POST /convert with table content."""
        response = client.post(
            "/convert",
            json={"html": table_html},
        )

        assert response.status_code == 200
        pdf_bytes = response.content
        assert pdf_bytes.startswith(b"%PDF")
        assert len(pdf_bytes) > 500

    def test_convert_empty_html(self, skip_if_no_browser, client):
        """Test POST /convert handles empty HTML."""
        response = client.post(
            "/convert",
            json={"html": ""},
        )

        # Should handle gracefully - may succeed or fail
        # The API should at least not crash
        assert response.status_code in [200, 400, 422]

    def test_convert_invalid_config(self, skip_if_no_browser, client, simple_html):
        """Test POST /convert with invalid config fails gracefully."""
        response = client.post(
            "/convert",
            json={
                "html": simple_html,
                "config": {
                    "page_size": "InvalidSize",
                },
            },
        )

        assert response.status_code == 400
        data = response.json()
        assert "error" in data
        assert data["error"] == "config_error"

    def test_convert_content_disposition(self, skip_if_no_browser, client, simple_html):
        """Test POST /convert returns proper Content-Disposition header."""
        response = client.post(
            "/convert",
            json={"html": simple_html},
        )

        assert response.status_code == 200
        assert "Content-Disposition" in response.headers
        assert "attachment" in response.headers["Content-Disposition"]

    def test_convert_multiple_requests(self, skip_if_no_browser, client, simple_html, table_html):
        """Test POST /convert handles multiple sequential requests."""
        response1 = client.post("/convert", json={"html": simple_html})
        response2 = client.post("/convert", json={"html": table_html})

        assert response1.status_code == 200
        assert response2.status_code == 200

        # Results should be different
        assert response1.content != response2.content


class TestConvertFileEndpoint:
    """Test the POST /convert/file endpoint."""

    def test_convert_file_upload(self, skip_if_no_browser, client, temp_html_file):
        """Test POST /convert/file with file upload returns real PDF."""
        with open(temp_html_file, "rb") as f:
            response = client.post(
                "/convert/file",
                files={"file": f},
            )

        assert response.status_code == 200
        assert response.headers["content-type"] == "application/pdf"

        pdf_bytes = response.content
        assert pdf_bytes.startswith(b"%PDF")

    def test_convert_file_with_config(self, skip_if_no_browser, client, temp_html_file):
        """Test POST /convert/file with config overrides."""
        config = {
            "page_size": "A3",
            "landscape": True,
        }

        with open(temp_html_file, "rb") as f:
            response = client.post(
                "/convert/file",
                files={"file": f},
                data={"config": json.dumps(config)},
            )

        assert response.status_code == 200
        pdf_bytes = response.content
        assert pdf_bytes.startswith(b"%PDF")

    def test_convert_file_filename_preservation(self, skip_if_no_browser, client, temp_html_file):
        """Test POST /convert/file preserves filename in response."""
        with open(temp_html_file, "rb") as f:
            response = client.post(
                "/convert/file",
                files={"file": (temp_html_file.name, f)},
            )

        assert response.status_code == 200
        disposition = response.headers["Content-Disposition"]
        assert "test.pdf" in disposition or ".pdf" in disposition

    def test_convert_file_invalid_config(self, skip_if_no_browser, client, temp_html_file):
        """Test POST /convert/file with invalid config JSON fails."""
        with open(temp_html_file, "rb") as f:
            response = client.post(
                "/convert/file",
                files={"file": f},
                data={"config": "not valid json"},
            )

        assert response.status_code == 400
        data = response.json()
        assert "error" in data

    def test_convert_file_missing_file(self, skip_if_no_browser, client):
        """Test POST /convert/file without file field fails."""
        response = client.post("/convert/file")

        assert response.status_code == 422  # Unprocessable Entity


class TestHealthEndpoint:
    """Test the GET /health endpoint."""

    def test_health_check(self, skip_if_no_browser, client):
        """Test GET /health reports healthy."""
        response = client.get("/health")

        assert response.status_code == 200
        data = response.json()

        assert "status" in data
        assert data["status"] == "healthy"
        assert "browser_ready" in data
        assert data["browser_ready"] is True
        assert "version" in data
        assert "uptime_seconds" in data
        assert data["uptime_seconds"] >= 0
        assert "pool_size" in data
        assert data["pool_size"] > 0

    def test_health_includes_version(self, skip_if_no_browser, client):
        """Test GET /health includes version."""
        from html2pdf import __version__

        response = client.get("/health")
        data = response.json()

        assert data["version"] == __version__

    def test_health_multiple_calls(self, skip_if_no_browser, client):
        """Test GET /health can be called multiple times."""
        response1 = client.get("/health")
        response2 = client.get("/health")

        assert response1.status_code == 200
        assert response2.status_code == 200

        data1 = response1.json()
        data2 = response2.json()

        # Both should be healthy
        assert data1["status"] == "healthy"
        assert data2["status"] == "healthy"

        # Uptime should increase
        assert data2["uptime_seconds"] >= data1["uptime_seconds"]


class TestConfigDefaultsEndpoint:
    """Test the GET /config/defaults endpoint."""

    def test_config_defaults(self, skip_if_no_browser, client):
        """Test GET /config/defaults returns valid config."""
        response = client.get("/config/defaults")

        assert response.status_code == 200
        data = response.json()

        # Check expected config fields
        assert "page_size" in data
        assert "margin_top" in data
        assert "margin_bottom" in data
        assert "margin_left" in data
        assert "margin_right" in data
        assert "break_strategy" in data
        assert "font_adjustment" in data
        assert "print_background" in data
        assert "scale" in data
        assert "landscape" in data

    def test_config_defaults_values(self, skip_if_no_browser, client):
        """Test GET /config/defaults returns reasonable values."""
        from html2pdf.core.config import PDFConfig

        response = client.get("/config/defaults")
        data = response.json()

        defaults = PDFConfig()

        # Values should match defaults
        assert data["page_size"] == defaults.page_size
        assert data["landscape"] == defaults.landscape
        assert data["scale"] == defaults.scale
        assert data["print_background"] == defaults.print_background

    def test_config_defaults_multiple_calls(self, skip_if_no_browser, client):
        """Test GET /config/defaults returns consistent results."""
        response1 = client.get("/config/defaults")
        response2 = client.get("/config/defaults")

        assert response1.status_code == 200
        assert response2.status_code == 200

        # Results should be identical
        assert response1.json() == response2.json()


class TestAPIErrorHandling:
    """Test API error handling and edge cases."""

    def test_convert_very_large_html(self, skip_if_no_browser, client, long_html):
        """Test POST /convert with large HTML document."""
        response = client.post(
            "/convert",
            json={"html": long_html},
        )

        # Should either succeed or fail gracefully
        assert response.status_code in [200, 400, 500]

    def test_convert_with_special_characters(self, skip_if_no_browser, client):
        """Test POST /convert with special characters in HTML."""
        html = """<html><body>
        <h1>Special Chars: €£¥©®™</h1>
        <p>Unicode: 你好世界 🌍</p>
        </body></html>"""

        response = client.post(
            "/convert",
            json={"html": html},
        )

        assert response.status_code == 200
        pdf_bytes = response.content
        assert pdf_bytes.startswith(b"%PDF")

    def test_convert_with_html_entities(self, skip_if_no_browser, client):
        """Test POST /convert with HTML entities."""
        html = """<html><body>
        <p>&lt;tag&gt; &amp; &quot;quoted&quot;</p>
        </body></html>"""

        response = client.post(
            "/convert",
            json={"html": html},
        )

        assert response.status_code == 200
        pdf_bytes = response.content
        assert pdf_bytes.startswith(b"%PDF")

    def test_endpoints_accept_json_only(self, skip_if_no_browser, client, simple_html):
        """Test POST /convert requires JSON content type."""
        response = client.post(
            "/convert",
            data={"html": simple_html},  # form data, not JSON
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )

        # Should fail or use default values
        assert response.status_code in [422, 400]

    def test_multiple_simultaneous_conversions(
        self, skip_if_no_browser, client, simple_html, table_html,
    ):
        """Test API can handle multiple conversions efficiently.

        Note: This is a simple sequential test. Real concurrency testing
        would require more sophisticated test infrastructure.
        """
        for _ in range(3):
            response = client.post("/convert", json={"html": simple_html})
            assert response.status_code == 200

        for _ in range(3):
            response = client.post("/convert", json={"html": table_html})
            assert response.status_code == 200
