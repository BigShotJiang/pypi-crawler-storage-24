"""Shared fixtures for html2pdf integration tests."""

import subprocess
import tempfile
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Browser availability fixture
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session")
def browser_available() -> bool:
    """Check if Playwright Chromium is installed and available.

    Returns:
        True if Chromium is available, False otherwise.
    """
    try:
        result = subprocess.run(
            [
                "python3", "-c",
                "from playwright.sync_api import sync_playwright; "
                "p = sync_playwright().start(); p.chromium; p.stop()",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.returncode == 0
    except Exception:
        return False


@pytest.fixture
def skip_if_no_browser(browser_available):
    """Pytest marker fixture to skip tests if browser is not available.

    Use this in test functions that require a real browser.
    """
    if not browser_available:
        pytest.skip("Playwright Chromium not available")


# ---------------------------------------------------------------------------
# Sample HTML content fixtures
# ---------------------------------------------------------------------------

SIMPLE_HTML = "<html><head></head><body><h1>Hello</h1><p>World</p></body></html>"

TABLE_HTML = """<html><head></head><body>
<h1>Table Test</h1>
<table>
  <thead><tr><th>Name</th><th>Value</th></tr></thead>
  <tbody>
    <tr><td>Alpha</td><td>1</td></tr>
    <tr><td>Beta</td><td>2</td></tr>
    <tr><td>Gamma</td><td>3</td></tr>
  </tbody>
</table>
</body></html>"""

CODE_BLOCK_HTML = """<html><head></head><body>
<h2>Code Example</h2>
<pre><code>def hello():
    print("hello world")
</code></pre>
</body></html>"""

LONG_HTML = "<html><head></head><body>" + "".join(
    f"<h2>Section {i}</h2><p>{'Lorem ipsum dolor sit amet. ' * 20}</p>"
    for i in range(10)
) + "</body></html>"

COMPLEX_HTML = """<html><head><title>Complex Document</title></head><body>
<h1>Main Title</h1>
<p>Introduction paragraph with some content.</p>
<h2>Data Table</h2>
<table>
  <thead><tr><th>Col A</th><th>Col B</th></tr></thead>
  <tbody>
    <tr><td>Row 1</td><td>Val 1</td></tr>
    <tr><td>Row 2</td><td>Val 2</td></tr>
  </tbody>
</table>
<h2>Code</h2>
<pre><code>x = 1
y = 2
print(x + y)</code></pre>
<p>Final paragraph.</p>
</body></html>"""

INVALID_HTML = "<html><body><invalid syntax here</body></html>"

EMPTY_HTML = ""


@pytest.fixture
def simple_html() -> str:
    """Simple HTML document."""
    return SIMPLE_HTML


@pytest.fixture
def table_html() -> str:
    """HTML with table."""
    return TABLE_HTML


@pytest.fixture
def code_html() -> str:
    """HTML with code block."""
    return CODE_BLOCK_HTML


@pytest.fixture
def long_html() -> str:
    """Long multi-page HTML document."""
    return LONG_HTML


@pytest.fixture
def complex_html() -> str:
    """Complex HTML with multiple elements."""
    return COMPLEX_HTML


@pytest.fixture
def invalid_html() -> str:
    """Malformed HTML."""
    return INVALID_HTML


@pytest.fixture
def empty_html() -> str:
    """Empty HTML string."""
    return EMPTY_HTML


# ---------------------------------------------------------------------------
# Temporary directory fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def temp_dir():
    """Create a temporary directory for test files.

    Yields:
        Path to the temporary directory. Cleaned up after the test.
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def temp_html_file(temp_dir, simple_html) -> Path:
    """Create a temporary HTML file.

    Args:
        temp_dir: Temporary directory fixture.
        simple_html: Simple HTML content fixture.

    Returns:
        Path to the created HTML file.
    """
    html_file = temp_dir / "test.html"
    html_file.write_text(simple_html, encoding="utf-8")
    return html_file


@pytest.fixture
def temp_html_dir(temp_dir) -> Path:
    """Create a temporary directory with multiple HTML files.

    Args:
        temp_dir: Temporary directory fixture.

    Returns:
        Path to the directory containing HTML files.
    """
    files = [
        ("page1.html", SIMPLE_HTML),
        ("page2.html", TABLE_HTML),
        ("page3.html", CODE_BLOCK_HTML),
    ]

    for filename, content in files:
        (temp_dir / filename).write_text(content, encoding="utf-8")

    return temp_dir
