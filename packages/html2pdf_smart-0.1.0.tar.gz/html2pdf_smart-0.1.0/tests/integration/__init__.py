"""Integration tests for html2pdf."""
