"""Integration tests for the html2pdf CLI.

These tests use the Click CliRunner to invoke actual CLI commands with
a real Playwright browser. Tests are skipped automatically if Chromium
is not available.
"""


import pytest
from click.testing import CliRunner

from html2pdf import __version__
from html2pdf.cli.main import cli

pytestmark = pytest.mark.integration


class TestConvertCommand:
    """Test the 'html2pdf convert' command."""

    def test_convert_file_input(self, skip_if_no_browser, temp_html_file):
        """Test 'html2pdf convert' with a real HTML file."""
        runner = CliRunner()
        output_path = temp_html_file.parent / "output.pdf"

        result = runner.invoke(cli, [
            "convert",
            str(temp_html_file),
            "-o", str(output_path),
        ])

        assert result.exit_code == 0
        assert output_path.exists()

        pdf_bytes = output_path.read_bytes()
        assert pdf_bytes.startswith(b"%PDF")

    def test_convert_default_output(self, skip_if_no_browser, temp_html_file):
        """Test 'html2pdf convert' writes to default output path."""
        runner = CliRunner()
        expected_output = temp_html_file.with_suffix(".pdf")

        result = runner.invoke(cli, [
            "convert",
            str(temp_html_file),
        ])

        assert result.exit_code == 0
        assert expected_output.exists()

        pdf_bytes = expected_output.read_bytes()
        assert pdf_bytes.startswith(b"%PDF")

    def test_convert_with_landscape(self, skip_if_no_browser, temp_html_file):
        """Test 'html2pdf convert' with --landscape flag."""
        runner = CliRunner()
        output_path = temp_html_file.parent / "landscape.pdf"

        result = runner.invoke(cli, [
            "convert",
            str(temp_html_file),
            "-o", str(output_path),
            "--landscape",
        ])

        assert result.exit_code == 0
        assert output_path.exists()

        pdf_bytes = output_path.read_bytes()
        assert pdf_bytes.startswith(b"%PDF")

    def test_convert_with_page_size(self, skip_if_no_browser, temp_html_file):
        """Test 'html2pdf convert' with --page-size option."""
        runner = CliRunner()
        output_path = temp_html_file.parent / "letter.pdf"

        result = runner.invoke(cli, [
            "convert",
            str(temp_html_file),
            "-o", str(output_path),
            "--page-size", "Letter",
        ])

        assert result.exit_code == 0
        assert output_path.exists()

    def test_convert_with_margins(self, skip_if_no_browser, temp_html_file):
        """Test 'html2pdf convert' with margin options."""
        runner = CliRunner()
        output_path = temp_html_file.parent / "margins.pdf"

        result = runner.invoke(cli, [
            "convert",
            str(temp_html_file),
            "-o", str(output_path),
            "--margin-top", "30mm",
            "--margin-bottom", "30mm",
            "--margin-left", "25mm",
            "--margin-right", "25mm",
        ])

        assert result.exit_code == 0
        assert output_path.exists()

    def test_convert_with_scale(self, skip_if_no_browser, temp_html_file):
        """Test 'html2pdf convert' with --scale option."""
        runner = CliRunner()
        output_path = temp_html_file.parent / "scaled.pdf"

        result = runner.invoke(cli, [
            "convert",
            str(temp_html_file),
            "-o", str(output_path),
            "--scale", "1.5",
        ])

        assert result.exit_code == 0
        assert output_path.exists()

    def test_convert_missing_file(self, skip_if_no_browser, temp_dir):
        """Test 'html2pdf convert' fails for missing input file."""
        runner = CliRunner()
        nonexistent = temp_dir / "nonexistent.html"

        result = runner.invoke(cli, [
            "convert",
            str(nonexistent),
        ])

        assert result.exit_code != 0
        assert "not found" in result.output.lower()

    def test_convert_missing_output_for_stdin(self, skip_if_no_browser):
        """Test 'html2pdf convert' requires -o for stdin input."""
        runner = CliRunner()

        result = runner.invoke(cli, [
            "convert",
            "-",
        ], input="<html><body>test</body></html>")

        assert result.exit_code != 0
        assert "output" in result.output.lower() or "-o" in result.output


class TestBatchCommand:
    """Test the 'html2pdf batch' command."""

    def test_batch_convert_directory(self, skip_if_no_browser, temp_html_dir):
        """Test 'html2pdf batch' converts directory of HTML files."""
        runner = CliRunner()
        output_dir = temp_html_dir.parent / "output"

        result = runner.invoke(cli, [
            "batch",
            str(temp_html_dir),
            "-o", str(output_dir),
        ])

        assert result.exit_code == 0
        assert output_dir.exists()

        # Check PDFs were created
        pdfs = list(output_dir.glob("*.pdf"))
        assert len(pdfs) == 3

        for pdf_path in pdfs:
            pdf_bytes = pdf_path.read_bytes()
            assert pdf_bytes.startswith(b"%PDF")

    def test_batch_default_output(self, skip_if_no_browser, temp_html_dir):
        """Test 'html2pdf batch' writes to input directory by default."""
        runner = CliRunner()

        result = runner.invoke(cli, [
            "batch",
            str(temp_html_dir),
        ])

        assert result.exit_code == 0

        # PDFs should be in the same directory
        pdfs = list(temp_html_dir.glob("*.pdf"))
        assert len(pdfs) == 3

    def test_batch_with_pattern(self, skip_if_no_browser, temp_dir):
        """Test 'html2pdf batch' with custom file pattern."""
        # Create files with different extensions
        (temp_dir / "page1.html").write_text("<html><body>HTML 1</body></html>")
        (temp_dir / "page2.htm").write_text("<html><body>HTML 2</body></html>")

        runner = CliRunner()
        output_dir = temp_dir / "output"

        result = runner.invoke(cli, [
            "batch",
            str(temp_dir),
            "-o", str(output_dir),
            "--pattern", "*.html",
        ])

        assert result.exit_code == 0

        # Only .html files should be converted
        pdfs = list(output_dir.glob("*.pdf"))
        assert len(pdfs) == 1
        assert pdfs[0].name == "page1.pdf"

    def test_batch_with_landscape(self, skip_if_no_browser, temp_html_dir):
        """Test 'html2pdf batch' with --landscape flag."""
        runner = CliRunner()
        output_dir = temp_html_dir.parent / "output"

        result = runner.invoke(cli, [
            "batch",
            str(temp_html_dir),
            "-o", str(output_dir),
            "--landscape",
        ])

        assert result.exit_code == 0
        assert output_dir.exists()

        pdfs = list(output_dir.glob("*.pdf"))
        assert len(pdfs) == 3

    def test_batch_missing_directory(self, skip_if_no_browser, temp_dir):
        """Test 'html2pdf batch' fails for missing input directory."""
        runner = CliRunner()
        nonexistent = temp_dir / "nonexistent"

        result = runner.invoke(cli, [
            "batch",
            str(nonexistent),
        ])

        assert result.exit_code != 0

    def test_batch_no_matching_files(self, skip_if_no_browser, temp_dir):
        """Test 'html2pdf batch' fails when no files match pattern."""
        runner = CliRunner()

        result = runner.invoke(cli, [
            "batch",
            str(temp_dir),
            "--pattern", "*.xyz",
        ])

        assert result.exit_code != 0


class TestVersionCommand:
    """Test the 'html2pdf version' command."""

    def test_version_command(self):
        """Test 'html2pdf version' returns version."""
        runner = CliRunner()

        result = runner.invoke(cli, ["version"])

        assert result.exit_code == 0
        assert __version__ in result.output

    def test_version_flag(self):
        """Test 'html2pdf --version' returns version."""
        runner = CliRunner()

        result = runner.invoke(cli, ["--version"])

        assert result.exit_code == 0
        assert __version__ in result.output


class TestInfoCommand:
    """Test the 'html2pdf info' command."""

    def test_info_command(self):
        """Test 'html2pdf info' shows runtime information."""
        runner = CliRunner()

        result = runner.invoke(cli, ["info"])

        assert result.exit_code == 0
        assert __version__ in result.output
        # Should show config and browser info
        assert "Config file" in result.output or "config" in result.output.lower()

    def test_info_shows_defaults(self):
        """Test 'html2pdf info' shows default configuration."""
        runner = CliRunner()

        result = runner.invoke(cli, ["info"])

        assert result.exit_code == 0
        # Should show some default config values
        assert "Default config" in result.output or "default" in result.output.lower()
