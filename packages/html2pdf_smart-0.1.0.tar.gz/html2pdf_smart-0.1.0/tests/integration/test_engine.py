"""Integration tests for the html2pdf conversion engine.

These tests exercise the full HTML-to-PDF pipeline with a real Playwright
browser. Tests are skipped automatically if Chromium is not available.
"""

import pytest

from html2pdf import (
    async_convert,
    convert,
    convert_batch,
    convert_file,
)

pytestmark = pytest.mark.integration


class TestBasicConversion:
    """Test basic HTML to PDF conversion."""

    def test_convert_simple_html(self, skip_if_no_browser, simple_html):
        """Test basic conversion produces valid PDF."""
        pdf_bytes = convert(simple_html)

        assert pdf_bytes is not None
        assert len(pdf_bytes) > 0
        assert pdf_bytes.startswith(b"%PDF")

    def test_convert_table_html(self, skip_if_no_browser, table_html):
        """Test conversion of HTML with table."""
        pdf_bytes = convert(table_html)

        assert pdf_bytes.startswith(b"%PDF")
        assert len(pdf_bytes) > 100

    def test_convert_code_block_html(self, skip_if_no_browser, code_html):
        """Test conversion of HTML with code block."""
        pdf_bytes = convert(code_html)

        assert pdf_bytes.startswith(b"%PDF")

    def test_convert_complex_html(self, skip_if_no_browser, complex_html):
        """Test conversion of complex HTML document."""
        pdf_bytes = convert(complex_html)

        assert pdf_bytes.startswith(b"%PDF")
        assert len(pdf_bytes) > 1000

    def test_convert_long_html(self, skip_if_no_browser, long_html):
        """Test conversion of long multi-page HTML."""
        pdf_bytes = convert(long_html)

        assert pdf_bytes.startswith(b"%PDF")
        # Long document should produce larger PDF
        assert len(pdf_bytes) > 5000


class TestConfigOverrides:
    """Test conversion with PDFConfig overrides."""

    def test_convert_with_landscape(self, skip_if_no_browser, simple_html):
        """Test conversion with landscape orientation."""
        pdf_bytes = convert(simple_html, landscape=True)

        assert pdf_bytes.startswith(b"%PDF")
        assert len(pdf_bytes) > 0

    def test_convert_with_letter_size(self, skip_if_no_browser, simple_html):
        """Test conversion with Letter page size."""
        pdf_bytes = convert(simple_html, page_size="Letter")

        assert pdf_bytes.startswith(b"%PDF")

    def test_convert_with_a3_size(self, skip_if_no_browser, simple_html):
        """Test conversion with A3 page size."""
        pdf_bytes = convert(simple_html, page_size="A3")

        assert pdf_bytes.startswith(b"%PDF")

    def test_convert_with_margins(self, skip_if_no_browser, simple_html):
        """Test conversion with custom margins."""
        pdf_bytes = convert(
            simple_html,
            margin_top="30mm",
            margin_bottom="30mm",
            margin_left="25mm",
            margin_right="25mm",
        )

        assert pdf_bytes.startswith(b"%PDF")

    def test_convert_with_scale(self, skip_if_no_browser, simple_html):
        """Test conversion with custom scale."""
        pdf_bytes = convert(simple_html, scale=1.5)

        assert pdf_bytes.startswith(b"%PDF")

    def test_convert_with_no_background(self, skip_if_no_browser, simple_html):
        """Test conversion without background graphics."""
        pdf_bytes = convert(simple_html, print_background=False)

        assert pdf_bytes.startswith(b"%PDF")

    def test_convert_with_break_strategy(self, skip_if_no_browser, long_html):
        """Test conversion with page break strategy."""
        pdf_bytes = convert(long_html, break_strategy="css-only")

        assert pdf_bytes.startswith(b"%PDF")


class TestFileConversion:
    """Test file-based conversion."""

    def test_convert_file_writes_pdf(self, skip_if_no_browser, temp_html_file):
        """Test convert_file() writes PDF to disk."""
        output_path = temp_html_file.parent / "output.pdf"

        result = convert_file(temp_html_file, output=output_path)

        assert result == output_path
        assert output_path.exists()
        assert output_path.is_file()

        pdf_bytes = output_path.read_bytes()
        assert pdf_bytes.startswith(b"%PDF")

    def test_convert_file_default_output(self, skip_if_no_browser, temp_html_file):
        """Test convert_file() with default output path."""
        expected_output = temp_html_file.with_suffix(".pdf")

        result = convert_file(temp_html_file)

        assert result == expected_output
        assert expected_output.exists()

        pdf_bytes = expected_output.read_bytes()
        assert pdf_bytes.startswith(b"%PDF")

    def test_convert_file_with_config(self, skip_if_no_browser, temp_html_file):
        """Test convert_file() with config overrides."""
        output_path = temp_html_file.parent / "output.pdf"

        result = convert_file(
            temp_html_file,
            output=output_path,
            page_size="Letter",
            landscape=True,
        )

        assert result == output_path
        assert output_path.exists()

        pdf_bytes = output_path.read_bytes()
        assert pdf_bytes.startswith(b"%PDF")


class TestBatchConversion:
    """Test batch conversion."""

    def test_convert_batch_multiple_files(self, skip_if_no_browser, temp_html_dir):
        """Test convert_batch() processes multiple HTML strings."""
        from pathlib import Path

        # Read HTML files
        items = [
            (Path(temp_html_dir / "page1.html").read_text(), "page1"),
            (Path(temp_html_dir / "page2.html").read_text(), "page2"),
            (Path(temp_html_dir / "page3.html").read_text(), "page3"),
        ]

        results = convert_batch(items)

        assert len(results) == 3

        # Check all conversions succeeded
        for result_label, pdf_bytes, error in results:
            assert error is None
            assert pdf_bytes is not None
            assert pdf_bytes.startswith(b"%PDF")
            assert result_label in ["page1", "page2", "page3"]

    def test_convert_batch_with_config(self, skip_if_no_browser, table_html, code_html):
        """Test convert_batch() with config overrides."""
        items = [
            (table_html, "table"),
            (code_html, "code"),
        ]

        results = convert_batch(items, page_size="Letter", landscape=True)

        assert len(results) == 2

        for _label, pdf_bytes, error in results:
            assert error is None
            assert pdf_bytes is not None
            assert pdf_bytes.startswith(b"%PDF")

    def test_convert_batch_partial_failure(self, skip_if_no_browser, simple_html):
        """Test convert_batch() handles partial failures gracefully."""
        items = [
            (simple_html, "valid"),
            ("<html><body>missing close tag", "invalid"),
            (simple_html, "valid2"),
        ]

        results = convert_batch(items)

        assert len(results) == 3

        # First should succeed
        label, pdf_bytes, error = results[0]
        assert label == "valid"
        assert pdf_bytes is not None
        assert pdf_bytes.startswith(b"%PDF")
        assert error is None

        # Third should succeed
        label, pdf_bytes, error = results[2]
        assert label == "valid2"
        assert pdf_bytes is not None
        assert pdf_bytes.startswith(b"%PDF")
        assert error is None


class TestAsyncConversion:
    """Test asynchronous conversion."""

    @pytest.mark.asyncio
    async def test_async_convert_simple_html(self, skip_if_no_browser, simple_html):
        """Test async_convert() produces valid PDF."""
        pdf_bytes = await async_convert(simple_html)

        assert pdf_bytes.startswith(b"%PDF")
        assert len(pdf_bytes) > 0

    @pytest.mark.asyncio
    async def test_async_convert_with_config(self, skip_if_no_browser, simple_html):
        """Test async_convert() with config overrides."""
        pdf_bytes = await async_convert(
            simple_html,
            page_size="Letter",
            landscape=True,
        )

        assert pdf_bytes.startswith(b"%PDF")


class TestErrorHandling:
    """Test error handling in conversion."""

    def test_convert_malformed_html(self, skip_if_no_browser, invalid_html):
        """Test conversion handles malformed HTML gracefully.

        Note: Modern HTML parsers are lenient, so this may still produce a PDF.
        """
        try:
            pdf_bytes = convert(invalid_html)
            # If it succeeds, verify it's a valid PDF
            assert pdf_bytes.startswith(b"%PDF")
        except Exception as e:
            # If it fails, that's also acceptable
            assert "html" in str(e).lower() or "parse" in str(e).lower()

    def test_convert_file_not_found(self, skip_if_no_browser, temp_dir):
        """Test convert_file() raises error for missing file."""
        nonexistent = temp_dir / "nonexistent.html"

        with pytest.raises(FileNotFoundError):
            convert_file(nonexistent)

    def test_convert_invalid_page_size(self, skip_if_no_browser, simple_html):
        """Test conversion with invalid page size fails gracefully."""
        from html2pdf.core.exceptions import ConfigError

        with pytest.raises(ConfigError):
            convert(simple_html, page_size="InvalidSize")

    def test_convert_invalid_margin(self, skip_if_no_browser, simple_html):
        """Test conversion with invalid margin fails gracefully."""
        from html2pdf.core.exceptions import HTML2PDFError

        with pytest.raises(HTML2PDFError):
            convert(simple_html, margin_top="invalid")


class TestPDFValidation:
    """Test the validity of generated PDFs."""

    def test_pdf_has_valid_structure(self, skip_if_no_browser, simple_html):
        """Test generated PDF has valid structure."""
        pdf_bytes = convert(simple_html)

        # Check PDF header
        assert pdf_bytes.startswith(b"%PDF")

        # Check for EOF trailer
        assert b"%%EOF" in pdf_bytes

    def test_pdf_contains_content(self, skip_if_no_browser, simple_html):
        """Test generated PDF contains content stream."""
        pdf_bytes = convert(simple_html)

        # PDFs should contain stream objects with content
        assert b"stream" in pdf_bytes
        assert b"endstream" in pdf_bytes

    def test_multiple_conversions_differ(self, skip_if_no_browser, simple_html, table_html):
        """Test different inputs produce different PDFs."""
        pdf1 = convert(simple_html)
        pdf2 = convert(table_html)

        # Different content should produce different PDFs
        assert pdf1 != pdf2
        assert pdf1.startswith(b"%PDF")
        assert pdf2.startswith(b"%PDF")

    def test_same_input_produces_consistent_output(self, skip_if_no_browser, simple_html):
        """Test same input produces consistent size output."""
        pdf1 = convert(simple_html)
        pdf2 = convert(simple_html)

        # Same input with same config should produce same-sized output
        # (exact byte equality fails because Playwright embeds timestamps)
        assert pdf1.startswith(b"%PDF")
        assert pdf2.startswith(b"%PDF")
        assert len(pdf1) == len(pdf2)
