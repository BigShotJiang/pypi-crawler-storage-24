"""Unit tests for convert_batch() and async_convert_batch().

Tests that the batch API calls through to ConversionEngine correctly,
reusing a single engine instance. No Playwright launches — all rendering
is mocked.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from html2pdf import async_convert_batch, convert_batch

# --------------------------------------------------------------------------- #
# Fixtures
# --------------------------------------------------------------------------- #

@pytest.fixture
def mock_engine():
    """Provide a mocked ConversionEngine that returns fake PDF bytes."""
    engine = AsyncMock()
    engine.convert = AsyncMock(return_value=b"%PDF-1.4 fake")
    engine.__aenter__ = AsyncMock(return_value=engine)
    engine.__aexit__ = AsyncMock(return_value=False)
    return engine


# --------------------------------------------------------------------------- #
# async_convert_batch tests
# --------------------------------------------------------------------------- #

class TestAsyncConvertBatch:
    """Tests for async_convert_batch()."""

    @pytest.mark.asyncio
    async def test_empty_items(self, mock_engine: AsyncMock) -> None:
        """Empty input list should return empty results."""
        with patch("html2pdf.core.engine.ConversionEngine", return_value=mock_engine):
            results = await async_convert_batch([])
        assert results == []

    @pytest.mark.asyncio
    async def test_single_item_success(self, mock_engine: AsyncMock) -> None:
        """Single item should succeed and return PDF bytes."""
        with patch("html2pdf.core.engine.ConversionEngine", return_value=mock_engine):
            results = await async_convert_batch([("<html></html>", "test.html")])
        assert len(results) == 1
        label, pdf_bytes, error = results[0]
        assert label == "test.html"
        assert pdf_bytes == b"%PDF-1.4 fake"
        assert error is None

    @pytest.mark.asyncio
    async def test_multiple_items_single_engine(self, mock_engine: AsyncMock) -> None:
        """Multiple items should all use the same engine instance."""
        items = [
            (f"<html><body>Page {i}</body></html>", f"page{i}.html")
            for i in range(5)
        ]
        with patch("html2pdf.core.engine.ConversionEngine", return_value=mock_engine):
            results = await async_convert_batch(items)

        assert len(results) == 5
        # Engine was entered and exited exactly once (single browser session)
        mock_engine.__aenter__.assert_awaited_once()
        mock_engine.__aexit__.assert_awaited_once()
        # convert() was called once per item
        assert mock_engine.convert.await_count == 5

    @pytest.mark.asyncio
    async def test_partial_failure(self, mock_engine: AsyncMock) -> None:
        """If one conversion fails, others still succeed."""
        call_count = 0

        async def convert_side_effect(html, **kwargs):  # noqa: ANN001, ANN003
            nonlocal call_count
            call_count += 1
            if call_count == 2:
                raise RuntimeError("Boom")
            return b"%PDF-1.4 ok"

        mock_engine.convert = AsyncMock(side_effect=convert_side_effect)

        items = [("<html></html>", f"p{i}.html") for i in range(3)]
        with patch("html2pdf.core.engine.ConversionEngine", return_value=mock_engine):
            results = await async_convert_batch(items)

        assert len(results) == 3
        assert results[0][1] == b"%PDF-1.4 ok"
        assert results[0][2] is None
        assert results[1][1] is None
        assert "Boom" in results[1][2]
        assert results[2][1] == b"%PDF-1.4 ok"
        assert results[2][2] is None

    @pytest.mark.asyncio
    async def test_kwargs_forwarded(self, mock_engine: AsyncMock) -> None:
        """Config overrides should be passed through to engine.convert()."""
        with patch("html2pdf.core.engine.ConversionEngine", return_value=mock_engine):
            await async_convert_batch(
                [("<html></html>", "t.html")],
                page_size="Letter",
                landscape=True,
            )

        mock_engine.convert.assert_awaited_once()
        _, kwargs = mock_engine.convert.call_args
        assert kwargs["page_size"] == "Letter"
        assert kwargs["landscape"] is True

    @pytest.mark.asyncio
    async def test_none_label(self, mock_engine: AsyncMock) -> None:
        """None as label should be preserved in results."""
        with patch("html2pdf.core.engine.ConversionEngine", return_value=mock_engine):
            results = await async_convert_batch([("<html></html>", None)])
        assert results[0][0] is None


# --------------------------------------------------------------------------- #
# convert_batch (sync wrapper) tests
# --------------------------------------------------------------------------- #

class TestConvertBatch:
    """Tests for the synchronous convert_batch() wrapper."""

    def test_sync_wrapper_delegates_to_async(self, mock_engine: AsyncMock) -> None:
        """convert_batch() should produce the same results as async version."""
        items = [("<html></html>", "a.html"), ("<html></html>", "b.html")]
        with patch("html2pdf.core.engine.ConversionEngine", return_value=mock_engine):
            results = convert_batch(items)
        assert len(results) == 2
        for _label, pdf_bytes, error in results:
            assert pdf_bytes == b"%PDF-1.4 fake"
            assert error is None

    def test_sync_wrapper_with_overrides(self, mock_engine: AsyncMock) -> None:
        """Config kwargs should propagate through the sync wrapper."""
        with patch("html2pdf.core.engine.ConversionEngine", return_value=mock_engine):
            convert_batch([("<html></html>", "t.html")], scale=0.5)
        _, kwargs = mock_engine.convert.call_args
        assert kwargs["scale"] == 0.5
