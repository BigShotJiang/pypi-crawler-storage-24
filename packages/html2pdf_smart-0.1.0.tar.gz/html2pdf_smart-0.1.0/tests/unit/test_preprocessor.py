"""Tests for pre-processor pipeline — breaks, fonts, margins, sanitizer."""

from bs4 import BeautifulSoup

from html2pdf.analyzer.dom import DOMAnalyzer
from html2pdf.core.config import PDFConfig
from html2pdf.preprocessor.breaks import BreakInjector
from html2pdf.preprocessor.fonts import FontNormalizer
from html2pdf.preprocessor.margins import MarginOptimizer
from html2pdf.preprocessor.pipeline import PreProcessorPipeline
from html2pdf.preprocessor.sanitizer import CSSSanitizer
from tests.conftest import CODE_BLOCK_HTML, LONG_HTML, SIMPLE_HTML, TABLE_HTML

# ---------------------------------------------------------------------------
# Sanitizer tests
# ---------------------------------------------------------------------------


class TestCSSSanitizer:
    """CSS injection validation — whitelist only, block dangerous patterns."""

    def setup_method(self):
        self.sanitizer = CSSSanitizer()

    def test_allows_page_break_properties(self):
        assert self.sanitizer.validate_property("page-break-before", "always")
        assert self.sanitizer.validate_property("page-break-after", "avoid")
        assert self.sanitizer.validate_property("page-break-inside", "avoid")

    def test_allows_font_properties(self):
        assert self.sanitizer.validate_property("font-family", "sans-serif")
        assert self.sanitizer.validate_property("font-size", "12pt")
        assert self.sanitizer.validate_property("line-height", "1.5")

    def test_allows_margin_properties(self):
        assert self.sanitizer.validate_property("margin-top", "1em")
        assert self.sanitizer.validate_property("padding-bottom", "0.5em")

    def test_blocks_position_fixed(self):
        assert not self.sanitizer.validate_property("position", "fixed")

    def test_blocks_position_absolute(self):
        assert not self.sanitizer.validate_property("position", "absolute")

    def test_blocks_z_index(self):
        assert not self.sanitizer.validate_property("z-index", "9999")

    def test_blocks_javascript_url(self):
        text = "background: url(javascript:alert(1))"
        sanitized = self.sanitizer.sanitize_style_block(text)
        assert "javascript" not in sanitized

    def test_blocks_expression(self):
        text = "width: expression(document.body.clientWidth)"
        sanitized = self.sanitizer.sanitize_style_block(text)
        assert "expression" not in sanitized

    def test_wrap_style_tag(self):
        css = "p { margin: 0; }"
        tag = self.sanitizer.wrap_style_tag(css)
        assert 'data-html2pdf="preprocessor"' in tag
        assert css in tag


# ---------------------------------------------------------------------------
# Break injector tests
# ---------------------------------------------------------------------------


class TestBreakInjector:
    """Page break injection across all three strategies."""

    def _make_injector(self, strategy: str, html: str):
        config = PDFConfig(break_strategy=strategy)
        soup = BeautifulSoup(html, "lxml")
        analysis = DOMAnalyzer.analyze(soup)
        injector = BreakInjector(config, analysis)
        return injector, soup

    def test_smart_injects_styles(self):
        injector, soup = self._make_injector("smart", SIMPLE_HTML)
        result = injector.apply(soup)
        output = str(result)
        # Smart strategy should inject at least some CSS
        assert "data-html2pdf" in output or "page-break" in output or "orphans" in output

    def test_css_only_no_injection(self):
        injector, soup = self._make_injector("css-only", SIMPLE_HTML)
        original = str(soup)
        result = injector.apply(soup)
        # css-only should not add data-html2pdf style blocks
        assert "data-html2pdf" not in str(result) or str(result) == original

    def test_none_strips_breaks(self):
        # Start with HTML that has page-break CSS
        html_with_breaks = (
            '<html><head></head><body>'
            '<p style="page-break-before: always;">Text</p>'
            '</body></html>'
        )
        injector, soup = self._make_injector("none", html_with_breaks)
        result = injector.apply(soup)
        output = str(result)
        # "none" strategy should strip page-break from inline styles
        assert "page-break-before" not in output or "page-break-before: always" not in output

    def test_table_row_protection(self):
        injector, soup = self._make_injector("smart", TABLE_HTML)
        result = injector.apply(soup)
        output = str(result)
        # Table rows should get page-break-inside: avoid
        assert "avoid" in output

    def test_code_block_protection(self):
        injector, soup = self._make_injector("smart", CODE_BLOCK_HTML)
        result = injector.apply(soup)
        output = str(result)
        assert "avoid" in output


# ---------------------------------------------------------------------------
# Font normalizer tests
# ---------------------------------------------------------------------------


class TestFontNormalizer:

    def test_injects_font_css_when_enabled(self):
        config = PDFConfig(font_adjustment=True)
        normalizer = FontNormalizer(config)
        soup = BeautifulSoup(SIMPLE_HTML, "lxml")
        result = normalizer.apply(soup)
        output = str(result)
        assert "font-family" in output

    def test_no_injection_when_disabled(self):
        config = PDFConfig(font_adjustment=False)
        normalizer = FontNormalizer(config)
        soup = BeautifulSoup(SIMPLE_HTML, "lxml")
        result = normalizer.apply(soup)
        output = str(result)
        assert 'data-html2pdf="fonts"' not in output


# ---------------------------------------------------------------------------
# Margin optimizer tests
# ---------------------------------------------------------------------------


class TestMarginOptimizer:

    def test_injects_margin_css(self):
        config = PDFConfig()
        optimizer = MarginOptimizer(config)
        soup = BeautifulSoup(SIMPLE_HTML, "lxml")
        result = optimizer.apply(soup)
        output = str(result)
        assert "margin" in output


# ---------------------------------------------------------------------------
# Full pipeline tests
# ---------------------------------------------------------------------------


class TestPreProcessorPipeline:
    """End-to-end pipeline: all steps run in order, output is valid HTML."""

    def _run_pipeline(self, html: str, **config_kwargs) -> str:
        config = PDFConfig(**config_kwargs)
        soup = BeautifulSoup(html, "lxml")
        analysis = DOMAnalyzer.analyze(soup)
        pipeline = PreProcessorPipeline(config, analysis)
        result = pipeline.process(soup)
        return str(result)

    def test_simple_html_roundtrip(self):
        output = self._run_pipeline(SIMPLE_HTML)
        # Output should still contain original elements (may have inline styles added)
        assert "h1" in output
        assert "Hello" in output
        assert "World" in output

    def test_table_html_roundtrip(self):
        output = self._run_pipeline(TABLE_HTML)
        assert "table" in output
        assert "<td>" in output

    def test_code_block_roundtrip(self):
        output = self._run_pipeline(CODE_BLOCK_HTML)
        assert "pre" in output

    def test_long_html_roundtrip(self):
        output = self._run_pipeline(LONG_HTML)
        assert "Section 0" in output
        assert "Section 19" in output

    def test_preserves_content(self):
        """Pipeline adds CSS but never removes original content."""
        output = self._run_pipeline(SIMPLE_HTML)
        assert "Hello" in output
        assert "World" in output
        # Should have injected preprocessor style blocks
        assert "data-html2pdf" in output

    def test_none_strategy_minimal_changes(self):
        """'none' strategy should not inject page break CSS."""
        output = self._run_pipeline(SIMPLE_HTML, break_strategy="none")
        # Should still have font/margin CSS but no break CSS
        assert 'data-html2pdf="breaks"' not in output
