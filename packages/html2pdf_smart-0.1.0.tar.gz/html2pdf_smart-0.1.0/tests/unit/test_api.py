"""Unit tests for the html2pdf REST API.

Tests use FastAPI's TestClient with the ConversionEngine mocked —
no Playwright browser is launched. Tests that require Playwright
belong in tests/integration/.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi.testclient import TestClient

from html2pdf.api.app import create_app
from html2pdf.api.models import PDFConfigOverrides
from html2pdf.core.exceptions import (
    BrowserPoolError,
    ConfigError,
    HTML2PDFError,
    RenderError,
)

# --------------------------------------------------------------------------- #
# Fixtures
# --------------------------------------------------------------------------- #

@pytest.fixture
def mock_engine() -> AsyncMock:
    """A mocked ConversionEngine that returns fake PDF bytes."""
    engine = AsyncMock()
    engine.convert = AsyncMock(return_value=b"%PDF-1.4 fake pdf")
    engine.close = AsyncMock()
    return engine


@pytest.fixture
def client(mock_engine: AsyncMock):
    """TestClient with mocked ConversionEngine (no Playwright).

    The patch must remain active through TestClient's lifespan so the
    engine created during startup is the mock, not the real thing.
    """
    with patch("html2pdf.api.app.ConversionEngine", return_value=mock_engine):
        app = create_app()
        with TestClient(app) as c:
            yield c


# --------------------------------------------------------------------------- #
# GET /health
# --------------------------------------------------------------------------- #

class TestHealthEndpoint:
    """Tests for GET /health."""

    def test_health_returns_200(self, client: TestClient) -> None:
        resp = client.get("/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "healthy"
        assert data["browser_ready"] is True
        assert data["version"] == "0.1.0"
        assert data["pool_size"] == 3
        assert data["uptime_seconds"] >= 0

    def test_health_contains_request_id(self, client: TestClient) -> None:
        resp = client.get("/health")
        assert "x-request-id" in resp.headers

    def test_health_preserves_client_request_id(self, client: TestClient) -> None:
        resp = client.get("/health", headers={"X-Request-ID": "my-trace-123"})
        assert resp.headers["x-request-id"] == "my-trace-123"


# --------------------------------------------------------------------------- #
# GET /config/defaults
# --------------------------------------------------------------------------- #

class TestConfigDefaultsEndpoint:
    """Tests for GET /config/defaults."""

    def test_returns_defaults(self, client: TestClient) -> None:
        resp = client.get("/config/defaults")
        assert resp.status_code == 200
        data = resp.json()
        assert data["page_size"] == "A4"
        assert data["margin_top"] == "20mm"
        assert data["break_strategy"] == "smart"
        assert data["scale"] == 1.0
        assert data["landscape"] is False
        assert data["print_background"] is True


# --------------------------------------------------------------------------- #
# POST /convert
# --------------------------------------------------------------------------- #

class TestConvertEndpoint:
    """Tests for POST /convert."""

    def test_convert_returns_pdf(
        self, client: TestClient, mock_engine: AsyncMock
    ) -> None:
        resp = client.post("/convert", json={"html": "<h1>Hello</h1>"})
        assert resp.status_code == 200
        assert resp.headers["content-type"] == "application/pdf"
        assert resp.content == b"%PDF-1.4 fake pdf"
        mock_engine.convert.assert_awaited_once()

    def test_convert_with_config_overrides(
        self, client: TestClient, mock_engine: AsyncMock
    ) -> None:
        resp = client.post(
            "/convert",
            json={
                "html": "<p>Test</p>",
                "config": {"page_size": "Letter", "landscape": True},
            },
        )
        assert resp.status_code == 200
        _, kwargs = mock_engine.convert.call_args
        assert kwargs["page_size"] == "Letter"
        assert kwargs["landscape"] is True

    def test_convert_empty_html_rejected(self, client: TestClient) -> None:
        resp = client.post("/convert", json={"html": ""})
        assert resp.status_code == 422  # Pydantic validation (min_length=1)

    def test_convert_missing_html_rejected(self, client: TestClient) -> None:
        resp = client.post("/convert", json={})
        assert resp.status_code == 422

    def test_convert_config_error_returns_400(
        self, client: TestClient, mock_engine: AsyncMock
    ) -> None:
        mock_engine.convert.side_effect = ConfigError("bad config")
        resp = client.post("/convert", json={"html": "<p>X</p>"})
        assert resp.status_code == 400
        data = resp.json()
        assert data["error"] == "config_error"

    def test_convert_render_error_returns_503(
        self, client: TestClient, mock_engine: AsyncMock
    ) -> None:
        mock_engine.convert.side_effect = RenderError("browser crash")
        resp = client.post("/convert", json={"html": "<p>X</p>"})
        assert resp.status_code == 503
        data = resp.json()
        assert data["error"] == "renderer_error"

    def test_convert_browser_pool_error_returns_503(
        self, client: TestClient, mock_engine: AsyncMock
    ) -> None:
        mock_engine.convert.side_effect = BrowserPoolError("pool exhausted")
        resp = client.post("/convert", json={"html": "<p>X</p>"})
        assert resp.status_code == 503

    def test_convert_generic_error_returns_500(
        self, client: TestClient, mock_engine: AsyncMock
    ) -> None:
        mock_engine.convert.side_effect = HTML2PDFError("something broke")
        resp = client.post("/convert", json={"html": "<p>X</p>"})
        assert resp.status_code == 500
        data = resp.json()
        assert data["error"] == "conversion_error"

    def test_convert_content_disposition_header(self, client: TestClient) -> None:
        resp = client.post("/convert", json={"html": "<p>X</p>"})
        assert "content-disposition" in resp.headers
        assert "output.pdf" in resp.headers["content-disposition"]


# --------------------------------------------------------------------------- #
# POST /convert/file
# --------------------------------------------------------------------------- #

class TestConvertFileEndpoint:
    """Tests for POST /convert/file."""

    def test_upload_html_file(
        self, client: TestClient, mock_engine: AsyncMock
    ) -> None:
        resp = client.post(
            "/convert/file",
            files={"file": ("page.html", b"<h1>Hello</h1>", "text/html")},
        )
        assert resp.status_code == 200
        assert resp.content == b"%PDF-1.4 fake pdf"
        assert "page.pdf" in resp.headers.get("content-disposition", "")

    def test_upload_empty_file(self, client: TestClient) -> None:
        resp = client.post(
            "/convert/file",
            files={"file": ("empty.html", b"", "text/html")},
        )
        assert resp.status_code == 400
        assert resp.json()["error"] == "empty_file"

    def test_upload_with_config(
        self, client: TestClient, mock_engine: AsyncMock
    ) -> None:
        import json

        mock_engine.convert.reset_mock()
        config_json = json.dumps({"page_size": "Letter"})
        resp = client.post(
            "/convert/file",
            files={"file": ("doc.html", b"<p>Test</p>", "text/html")},
            data={"config": config_json},
        )
        assert resp.status_code == 200
        mock_engine.convert.assert_awaited_once()
        _, kwargs = mock_engine.convert.call_args
        assert kwargs["page_size"] == "Letter"

    def test_upload_non_utf8_file(self, client: TestClient) -> None:
        resp = client.post(
            "/convert/file",
            files={"file": ("bad.html", b"\xff\xfe\x00\x01", "text/html")},
        )
        assert resp.status_code == 400
        assert resp.json()["error"] == "invalid_file"


# --------------------------------------------------------------------------- #
# POST /convert/url
# --------------------------------------------------------------------------- #

class TestConvertURLEndpoint:
    """Tests for POST /convert/url."""

    def test_invalid_url_scheme(self, client: TestClient) -> None:
        resp = client.post("/convert/url", json={"url": "ftp://example.com"})
        assert resp.status_code == 400
        assert resp.json()["error"] == "invalid_url"

    def test_successful_url_convert(
        self, client: TestClient, mock_engine: AsyncMock
    ) -> None:
        # Mock httpx at the point of import inside the route function
        mock_response = MagicMock()
        mock_response.text = "<html><body>Fetched</body></html>"
        mock_response.raise_for_status = MagicMock()

        mock_client_instance = AsyncMock()
        mock_client_instance.get = AsyncMock(return_value=mock_response)
        mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
        mock_client_instance.__aexit__ = AsyncMock(return_value=False)

        mock_httpx = MagicMock()
        mock_httpx.AsyncClient = MagicMock(return_value=mock_client_instance)
        mock_httpx.HTTPStatusError = Exception
        mock_httpx.RequestError = Exception

        with patch.dict("sys.modules", {"httpx": mock_httpx}):
            resp = client.post(
                "/convert/url", json={"url": "https://example.com"}
            )
        assert resp.status_code == 200
        assert resp.content == b"%PDF-1.4 fake pdf"


# --------------------------------------------------------------------------- #
# Middleware tests
# --------------------------------------------------------------------------- #

class TestRateLimitMiddleware:
    """Tests for rate limiting."""

    def test_rate_limit_rejects_excess(self) -> None:
        """After max_requests, subsequent requests get 429."""
        import os

        mock_eng = AsyncMock()
        mock_eng.convert = AsyncMock(return_value=b"%PDF-1.4")
        mock_eng.close = AsyncMock()

        os.environ["HTML2PDF_API_RATE_LIMIT"] = "3"
        try:
            with patch("html2pdf.api.app.ConversionEngine", return_value=mock_eng):
                tight_app = create_app()
                with TestClient(tight_app) as c:
                    # First 3 should pass
                    for _ in range(3):
                        resp = c.get("/health")
                        assert resp.status_code == 200

                    # 4th should be rate limited
                    resp = c.get("/health")
                    assert resp.status_code == 429
                    assert resp.json()["error"] == "rate_limit_exceeded"
        finally:
            del os.environ["HTML2PDF_API_RATE_LIMIT"]


class TestRequestSizeLimit:
    """Tests for request size limiting."""

    def test_oversized_request_rejected(self) -> None:
        """Request with Content-Length > max should get 413."""
        mock_eng = AsyncMock()
        mock_eng.convert = AsyncMock(return_value=b"%PDF-1.4")
        mock_eng.close = AsyncMock()

        with patch("html2pdf.api.app.ConversionEngine", return_value=mock_eng):
            app = create_app()
            with TestClient(app) as c:
                resp = c.post(
                    "/convert",
                    json={"html": "<p>X</p>"},
                    headers={"Content-Length": str(20 * 1024 * 1024)},
                )
                assert resp.status_code == 413
                assert resp.json()["error"] == "request_too_large"


# --------------------------------------------------------------------------- #
# OpenAPI docs
# --------------------------------------------------------------------------- #

class TestOpenAPIDocs:
    """Tests that OpenAPI docs render."""

    def test_openapi_json(self, client: TestClient) -> None:
        resp = client.get("/openapi.json")
        assert resp.status_code == 200
        data = resp.json()
        assert data["info"]["title"] == "html2pdf API"
        assert "/convert" in data["paths"]
        assert "/health" in data["paths"]

    def test_docs_page(self, client: TestClient) -> None:
        resp = client.get("/docs")
        assert resp.status_code == 200


# --------------------------------------------------------------------------- #
# Pydantic model tests
# --------------------------------------------------------------------------- #

class TestPDFConfigOverrides:
    """Tests for the PDFConfigOverrides model."""

    def test_to_kwargs_excludes_none(self) -> None:
        overrides = PDFConfigOverrides(page_size="Letter")
        kwargs = overrides.to_kwargs()
        assert kwargs == {"page_size": "Letter"}
        assert "landscape" not in kwargs

    def test_to_kwargs_all_set(self) -> None:
        overrides = PDFConfigOverrides(
            page_size="A3",
            margin_top="1in",
            landscape=True,
            scale=0.8,
        )
        kwargs = overrides.to_kwargs()
        assert kwargs["page_size"] == "A3"
        assert kwargs["margin_top"] == "1in"
        assert kwargs["landscape"] is True
        assert kwargs["scale"] == 0.8

    def test_to_kwargs_empty(self) -> None:
        overrides = PDFConfigOverrides()
        assert overrides.to_kwargs() == {}

    def test_scale_validation(self) -> None:
        """Scale must be between 0.1 and 2.0."""
        from pydantic import ValidationError

        with pytest.raises(ValidationError):
            PDFConfigOverrides(scale=0.05)
        with pytest.raises(ValidationError):
            PDFConfigOverrides(scale=3.0)
