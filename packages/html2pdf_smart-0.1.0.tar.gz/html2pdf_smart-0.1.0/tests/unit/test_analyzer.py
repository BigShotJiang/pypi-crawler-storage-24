"""Tests for DOM analyzer — structure detection, metrics, pattern detection."""

from bs4 import BeautifulSoup

from html2pdf.analyzer.detector import DetectionResult, PatternDetector
from html2pdf.analyzer.dom import DOMAnalysis, DOMAnalyzer, DOMNode
from html2pdf.analyzer.metrics import estimate_element_height, estimate_page_count

# ---------------------------------------------------------------------------
# DOMAnalyzer tests
# ---------------------------------------------------------------------------


class TestDOMAnalyzer:
    """Core DOM analysis produces correct structural metadata."""

    def test_simple_html_nodes(self, simple_soup):
        analysis = DOMAnalyzer.analyze(simple_soup)
        assert isinstance(analysis, DOMAnalysis)
        assert len(analysis.nodes) > 0

    def test_heading_detection(self, simple_soup):
        analysis = DOMAnalyzer.analyze(simple_soup)
        assert len(analysis.heading_positions) == 1
        heading_node = analysis.nodes[analysis.heading_positions[0]]
        assert heading_node.tag == "h1"

    def test_table_detection(self, table_soup):
        analysis = DOMAnalyzer.analyze(table_soup)
        assert len(analysis.table_positions) >= 1
        table_node = analysis.nodes[analysis.table_positions[0]]
        assert table_node.tag == "table"

    def test_code_block_detection(self, code_soup):
        analysis = DOMAnalyzer.analyze(code_soup)
        assert len(analysis.code_block_positions) >= 1

    def test_image_detection(self):
        html = '<html><body><img src="test.png"/></body></html>'
        soup = BeautifulSoup(html, "lxml")
        analysis = DOMAnalyzer.analyze(soup)
        assert len(analysis.image_positions) >= 1

    def test_max_depth(self, simple_soup):
        analysis = DOMAnalyzer.analyze(simple_soup)
        assert analysis.max_depth >= 1  # body > h1

    def test_total_text_length(self, simple_soup):
        analysis = DOMAnalyzer.analyze(simple_soup)
        assert analysis.total_text_length > 0

    def test_estimated_pages_positive(self, simple_soup):
        analysis = DOMAnalyzer.analyze(simple_soup)
        assert analysis.estimated_pages >= 1.0

    def test_long_document_multiple_pages(self, long_soup):
        analysis = DOMAnalyzer.analyze(long_soup)
        assert analysis.estimated_pages > 1.0

    def test_complex_html_all_types(self, complex_soup):
        analysis = DOMAnalyzer.analyze(complex_soup)
        assert len(analysis.heading_positions) >= 1
        assert len(analysis.table_positions) >= 1
        assert len(analysis.code_block_positions) >= 1
        assert len(analysis.image_positions) >= 1

    def test_deterministic(self, complex_soup):
        """Same input produces same output. Always."""
        a1 = DOMAnalyzer.analyze(complex_soup)
        a2 = DOMAnalyzer.analyze(complex_soup)
        assert len(a1.nodes) == len(a2.nodes)
        assert a1.heading_positions == a2.heading_positions
        assert a1.table_positions == a2.table_positions
        assert a1.estimated_pages == a2.estimated_pages

    def test_dom_node_fields(self, simple_soup):
        analysis = DOMAnalyzer.analyze(simple_soup)
        node = analysis.nodes[0]
        assert isinstance(node, DOMNode)
        assert isinstance(node.tag, str)
        assert isinstance(node.depth, int)
        assert isinstance(node.text_length, int)
        assert isinstance(node.estimated_height_mm, float)


# ---------------------------------------------------------------------------
# Metrics tests
# ---------------------------------------------------------------------------


class TestMetrics:
    """estimate_element_height takes (tag, text_length, child_count)."""

    def test_heading_height_positive(self):
        height = estimate_element_height("h1", text_length=5, child_count=0)
        assert height > 0

    def test_paragraph_height_scales_with_text(self):
        h_short = estimate_element_height("p", text_length=10, child_count=0)
        h_long = estimate_element_height("p", text_length=2500, child_count=0)
        assert h_long > h_short

    def test_table_height_scales_with_rows(self):
        h_small = estimate_element_height("table", text_length=0, child_count=1)
        h_big = estimate_element_height("table", text_length=0, child_count=20)
        assert h_big > h_small

    def test_image_height_positive(self):
        height = estimate_element_height("img", text_length=0, child_count=0)
        assert height > 0

    def test_page_count_at_least_one(self):
        assert estimate_page_count(total_text_length=10) >= 1.0

    def test_page_count_scales(self):
        short = estimate_page_count(total_text_length=100)
        long_ = estimate_page_count(total_text_length=30000)
        assert long_ > short


# ---------------------------------------------------------------------------
# Pattern detector tests
# ---------------------------------------------------------------------------


class TestPatternDetector:
    """PatternDetector is instance-based: PatternDetector(analysis).detect()."""

    def test_keep_together_heading_paragraph(self, simple_soup):
        analysis = DOMAnalyzer.analyze(simple_soup)
        detector = PatternDetector(analysis)
        result = detector.detect()
        assert isinstance(result, DetectionResult)
        # h1 + p should be a keep-together pair
        assert len(result.keep_together_pairs) >= 1

    def test_large_table_detection(self):
        big_table = "<html><body><table>" + "<tr><td>x</td></tr>" * 100 + "</table></body></html>"
        soup = BeautifulSoup(big_table, "lxml")
        analysis = DOMAnalyzer.analyze(soup)
        detector = PatternDetector(analysis)
        result = detector.detect()
        assert len(result.large_tables) >= 1

    def test_protected_code_block(self, code_soup):
        analysis = DOMAnalyzer.analyze(code_soup)
        detector = PatternDetector(analysis)
        result = detector.detect()
        assert len(result.protected_blocks) >= 1

    def test_detection_result_fields(self, complex_soup):
        analysis = DOMAnalyzer.analyze(complex_soup)
        detector = PatternDetector(analysis)
        result = detector.detect()
        assert hasattr(result, "keep_together_pairs")
        assert hasattr(result, "large_tables")
        assert hasattr(result, "orphan_candidates")
        assert hasattr(result, "widow_candidates")
        assert hasattr(result, "protected_blocks")
