"""Tests for PDFConfig — defaults, validation, overrides, resolution."""

import pytest

from html2pdf.core.config import PDFConfig
from html2pdf.core.exceptions import ConfigError


class TestPDFConfigDefaults:
    """Frozen defaults are correct and immutable."""

    def test_default_values(self):
        cfg = PDFConfig()
        assert cfg.page_size == "A4"
        assert cfg.margin_top == "20mm"
        assert cfg.margin_bottom == "20mm"
        assert cfg.margin_left == "15mm"
        assert cfg.margin_right == "15mm"
        assert cfg.break_strategy == "smart"
        assert cfg.font_adjustment is True
        assert cfg.header_template is None
        assert cfg.footer_template is None
        assert cfg.print_background is True
        assert cfg.scale == 1.0
        assert cfg.landscape is False

    def test_frozen_immutability(self):
        cfg = PDFConfig()
        with pytest.raises(AttributeError):
            cfg.page_size = "Letter"  # type: ignore[misc]


class TestPDFConfigValidation:
    """Validation rejects bad inputs at construction time."""

    def test_invalid_page_size(self):
        with pytest.raises((ValueError, ConfigError)):
            PDFConfig(page_size="Poster")

    def test_invalid_break_strategy(self):
        with pytest.raises((ValueError, ConfigError)):
            PDFConfig(break_strategy="aggressive")

    def test_scale_too_low(self):
        with pytest.raises((ValueError, ConfigError)):
            PDFConfig(scale=0.0)

    def test_scale_too_high(self):
        with pytest.raises((ValueError, ConfigError)):
            PDFConfig(scale=3.0)

    def test_valid_page_sizes(self):
        for size in ("A4", "A3", "Letter", "Legal"):
            cfg = PDFConfig(page_size=size)
            assert cfg.page_size == size

    def test_valid_break_strategies(self):
        for strat in ("smart", "css-only", "none"):
            cfg = PDFConfig(break_strategy=strat)
            assert cfg.break_strategy == strat

    def test_valid_scale_bounds(self):
        low = PDFConfig(scale=0.1)
        high = PDFConfig(scale=2.0)
        assert low.scale == 0.1
        assert high.scale == 2.0


class TestPDFConfigOverrides:
    """Config override via replace() works correctly."""

    def test_replace_single_field(self):
        cfg = PDFConfig()
        new = cfg.replace(page_size="Letter")
        assert new.page_size == "Letter"
        assert cfg.page_size == "A4"  # original unchanged

    def test_replace_multiple_fields(self):
        cfg = PDFConfig()
        new = cfg.replace(landscape=True, scale=0.8, margin_top="30mm")
        assert new.landscape is True
        assert new.scale == 0.8
        assert new.margin_top == "30mm"
        # Unchanged fields
        assert new.page_size == "A4"
        assert new.break_strategy == "smart"


class TestPDFConfigEnvVars:
    """Environment variable resolution — from_env() returns a dict."""

    def test_from_env_page_size(self, monkeypatch):
        monkeypatch.setenv("HTML2PDF_PAGE_SIZE", "Letter")
        overrides = PDFConfig.from_env()
        assert overrides["page_size"] == "Letter"
        cfg = PDFConfig(**overrides)
        assert cfg.page_size == "Letter"

    def test_from_env_bool(self, monkeypatch):
        monkeypatch.setenv("HTML2PDF_LANDSCAPE", "true")
        overrides = PDFConfig.from_env()
        assert overrides["landscape"] is True

    def test_from_env_float(self, monkeypatch):
        monkeypatch.setenv("HTML2PDF_SCALE", "0.75")
        overrides = PDFConfig.from_env()
        assert overrides["scale"] == 0.75


class TestResolveConfig:
    """Full config resolution via replace()."""

    def test_kwargs_override_defaults(self):
        cfg = PDFConfig().replace(page_size="Letter", landscape=True)
        assert cfg.page_size == "Letter"
        assert cfg.landscape is True

    def test_no_overrides_returns_equal(self):
        cfg = PDFConfig().replace()
        assert cfg == PDFConfig()
