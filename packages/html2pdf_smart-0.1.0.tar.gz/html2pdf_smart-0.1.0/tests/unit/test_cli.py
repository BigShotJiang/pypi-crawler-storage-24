"""Unit tests for html2pdf CLI.

Tests the Click commands via CliRunner (no actual browser launches).
Tests that require Playwright are in tests/integration/.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from html2pdf.cli.main import (
    EXIT_CONVERSION,
    _build_config_kwargs,
    _read_html_from_input,
    cli,
)

# --------------------------------------------------------------------------- #
# Fixtures
# --------------------------------------------------------------------------- #

@pytest.fixture
def runner() -> CliRunner:
    """Click CLI test runner."""
    return CliRunner()


@pytest.fixture
def sample_html(tmp_path: Path) -> Path:
    """Create a minimal HTML file for testing."""
    f = tmp_path / "test.html"
    f.write_text("<html><body><h1>Test</h1></body></html>", encoding="utf-8")
    return f


@pytest.fixture
def sample_html_dir(tmp_path: Path) -> Path:
    """Create a directory with 3 HTML files for batch testing."""
    d = tmp_path / "html_files"
    d.mkdir()
    for i in range(1, 4):
        (d / f"page{i}.html").write_text(
            f"<html><body><h1>Page {i}</h1></body></html>",
            encoding="utf-8",
        )
    return d


# --------------------------------------------------------------------------- #
# CLI group tests
# --------------------------------------------------------------------------- #

class TestCLIGroup:
    """Tests for the top-level CLI group."""

    def test_help(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "html2pdf" in result.output
        assert "convert" in result.output
        assert "batch" in result.output
        assert "version" in result.output
        assert "info" in result.output

    def test_version_flag(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "0.1.0" in result.output


# --------------------------------------------------------------------------- #
# version command
# --------------------------------------------------------------------------- #

class TestVersionCommand:
    """Tests for the 'version' subcommand."""

    def test_version_output(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["version"])
        assert result.exit_code == 0
        assert "html2pdf 0.1.0" in result.output


# --------------------------------------------------------------------------- #
# info command
# --------------------------------------------------------------------------- #

class TestInfoCommand:
    """Tests for the 'info' subcommand."""

    def test_info_shows_defaults(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["info"])
        assert result.exit_code == 0
        assert "page_size" in result.output
        assert "A4" in result.output
        assert "Default config:" in result.output

    def test_info_shows_config_status(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["info"])
        assert result.exit_code == 0
        assert "Config file:" in result.output


# --------------------------------------------------------------------------- #
# convert command
# --------------------------------------------------------------------------- #

class TestConvertCommand:
    """Tests for the 'convert' subcommand."""

    def test_help(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["convert", "--help"])
        assert result.exit_code == 0
        assert "INPUT" in result.output
        assert "--output" in result.output
        assert "--page-size" in result.output
        assert "--landscape" in result.output
        assert "--break-strategy" in result.output

    def test_missing_input(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["convert"])
        assert result.exit_code != 0
        assert "Missing argument" in result.output

    def test_nonexistent_file(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["convert", "/nonexistent/file.html"])
        assert result.exit_code != 0
        assert "not found" in result.output.lower()

    @patch("html2pdf.cli.main.PDFConfig.resolve")
    @patch("html2pdf.convert")
    def test_successful_convert(
        self,
        mock_convert: MagicMock,
        mock_resolve: MagicMock,
        runner: CliRunner,
        sample_html: Path,
        tmp_path: Path,
    ) -> None:
        mock_resolve.return_value = MagicMock(
            __dataclass_fields__={},
        )
        mock_convert.return_value = b"%PDF-1.4 fake pdf content"

        out = tmp_path / "out.pdf"
        result = runner.invoke(cli, [
            "convert", str(sample_html), "-o", str(out),
        ])
        assert result.exit_code == 0
        assert "bytes" in result.output
        assert out.exists()
        assert out.read_bytes() == b"%PDF-1.4 fake pdf content"

    def test_stdin_requires_output(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["convert", "-"], input="<html></html>")
        assert result.exit_code != 0
        assert "required" in result.output.lower()

    @patch("html2pdf.cli.main.PDFConfig.resolve")
    @patch("html2pdf.convert")
    def test_stdin_with_output(
        self,
        mock_convert: MagicMock,
        mock_resolve: MagicMock,
        runner: CliRunner,
        tmp_path: Path,
    ) -> None:
        mock_resolve.return_value = MagicMock(__dataclass_fields__={})
        mock_convert.return_value = b"%PDF-1.4 stdin pdf"

        out = tmp_path / "stdin.pdf"
        result = runner.invoke(
            cli,
            ["convert", "-", "-o", str(out)],
            input="<html><body>Hello</body></html>",
        )
        assert result.exit_code == 0
        assert out.exists()

    def test_config_error_exits_cleanly(self, runner: CliRunner, sample_html: Path) -> None:
        """ConfigError should produce user-friendly message, not traceback."""
        result = runner.invoke(cli, [
            "convert", str(sample_html),
            "--config", "/nonexistent/config.toml",
        ])
        assert result.exit_code != 0
        # Should not contain Python traceback
        assert "Traceback" not in result.output

    def test_page_size_validation(self, runner: CliRunner, sample_html: Path) -> None:
        """Invalid page size should be caught by Click's Choice type."""
        result = runner.invoke(cli, [
            "convert", str(sample_html), "--page-size", "Bogus",
        ])
        assert result.exit_code != 0

    def test_break_strategy_validation(self, runner: CliRunner, sample_html: Path) -> None:
        """Invalid break strategy should be caught by Click's Choice type."""
        result = runner.invoke(cli, [
            "convert", str(sample_html), "--break-strategy", "yolo",
        ])
        assert result.exit_code != 0


# --------------------------------------------------------------------------- #
# batch command
# --------------------------------------------------------------------------- #

class TestBatchCommand:
    """Tests for the 'batch' subcommand."""

    def test_help(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["batch", "--help"])
        assert result.exit_code == 0
        assert "INPUT_DIR" in result.output
        assert "--pattern" in result.output

    def test_nonexistent_dir(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["batch", "/nonexistent/dir"])
        assert result.exit_code != 0

    def test_empty_dir(self, runner: CliRunner, tmp_path: Path) -> None:
        empty = tmp_path / "empty"
        empty.mkdir()
        result = runner.invoke(cli, ["batch", str(empty)])
        assert result.exit_code != 0
        assert "No files matching" in result.output

    @patch("html2pdf.cli.main.PDFConfig.resolve")
    @patch("html2pdf.convert_batch")
    def test_successful_batch(
        self,
        mock_batch: MagicMock,
        mock_resolve: MagicMock,
        runner: CliRunner,
        sample_html_dir: Path,
        tmp_path: Path,
    ) -> None:
        mock_resolve.return_value = MagicMock(__dataclass_fields__={})

        def batch_side_effect(items, **kwargs):  # noqa: ANN001, ANN003, ANN202
            return [(label, b"%PDF-1.4 batch pdf", None) for _, label in items]

        mock_batch.side_effect = batch_side_effect

        out = tmp_path / "batch_out"
        result = runner.invoke(cli, [
            "batch", str(sample_html_dir), "-o", str(out),
        ])
        assert result.exit_code == 0
        assert "3 converted" in result.output
        assert "0 failed" in result.output
        assert len(list(out.glob("*.pdf"))) == 3

    @patch("html2pdf.cli.main.PDFConfig.resolve")
    @patch("html2pdf.convert_batch")
    def test_batch_with_failures(
        self,
        mock_batch: MagicMock,
        mock_resolve: MagicMock,
        runner: CliRunner,
        sample_html_dir: Path,
        tmp_path: Path,
    ) -> None:
        mock_resolve.return_value = MagicMock(__dataclass_fields__={})

        def batch_side_effect(items, **kwargs):  # noqa: ANN001, ANN003, ANN202
            results = []
            for i, (_html, label) in enumerate(items):
                if i == 1:
                    results.append((label, None, "Simulated failure"))
                else:
                    results.append((label, b"%PDF-1.4 ok", None))
            return results

        mock_batch.side_effect = batch_side_effect

        out = tmp_path / "batch_fail_out"
        result = runner.invoke(cli, [
            "batch", str(sample_html_dir), "-o", str(out),
        ])
        assert result.exit_code == EXIT_CONVERSION
        assert "2 converted" in result.output
        assert "1 failed" in result.output

    def test_custom_pattern(self, runner: CliRunner, tmp_path: Path) -> None:
        d = tmp_path / "mixed"
        d.mkdir()
        (d / "a.htm").write_text("<html></html>")
        (d / "b.html").write_text("<html></html>")

        result = runner.invoke(cli, [
            "batch", str(d), "--pattern", "*.htm",
        ])
        # Should find only 1 file matching *.htm
        # (will fail on convert since we're not mocking, but it should find the file)
        assert "No files matching" not in result.output


# --------------------------------------------------------------------------- #
# Helper function tests
# --------------------------------------------------------------------------- #

class TestHelpers:
    """Tests for CLI helper functions."""

    def test_build_config_kwargs_defaults(self) -> None:
        """With all defaults, should return empty dict."""
        result = _build_config_kwargs(
            page_size=None, landscape=False, margin_top=None,
            margin_bottom=None, margin_left=None, margin_right=None,
            break_strategy=None, no_background=False, scale=None, config=None,
        )
        assert result == {}

    def test_build_config_kwargs_with_values(self) -> None:
        result = _build_config_kwargs(
            page_size="Letter", landscape=True, margin_top="1in",
            margin_bottom=None, margin_left=None, margin_right=None,
            break_strategy="css-only", no_background=True, scale=0.8, config=None,
        )
        assert result == {
            "page_size": "Letter",
            "landscape": True,
            "margin_top": "1in",
            "break_strategy": "css-only",
            "print_background": False,
            "scale": 0.8,
        }

    def test_read_html_from_file(self, sample_html: Path) -> None:
        content = _read_html_from_input(str(sample_html))
        assert "<h1>Test</h1>" in content

    def test_read_html_from_nonexistent_file(self) -> None:
        with pytest.raises(Exception, match="not found"):
            _read_html_from_input("/nonexistent/path.html")

    def test_read_html_from_stdin_empty(self, monkeypatch: pytest.MonkeyPatch) -> None:
        import io
        monkeypatch.setattr("sys.stdin", io.StringIO(""))
        with pytest.raises(Exception, match="No input"):
            _read_html_from_input("-")

    def test_read_html_from_stdin(self, monkeypatch: pytest.MonkeyPatch) -> None:
        import io
        monkeypatch.setattr("sys.stdin", io.StringIO("<html>hello</html>"))
        result = _read_html_from_input("-")
        assert "<html>hello</html>" in result
