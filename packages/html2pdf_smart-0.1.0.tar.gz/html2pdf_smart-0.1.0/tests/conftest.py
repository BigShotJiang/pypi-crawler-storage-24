"""Shared fixtures for html2pdf tests."""

import pytest
from bs4 import BeautifulSoup

from html2pdf.core.config import PDFConfig

# ---------------------------------------------------------------------------
# Sample HTML fixtures
# ---------------------------------------------------------------------------

SIMPLE_HTML = "<html><head></head><body><h1>Hello</h1><p>World</p></body></html>"

TABLE_HTML = """<html><head></head><body>
<table>
  <thead><tr><th>Name</th><th>Value</th></tr></thead>
  <tbody>
    <tr><td>Alpha</td><td>1</td></tr>
    <tr><td>Beta</td><td>2</td></tr>
    <tr><td>Gamma</td><td>3</td></tr>
  </tbody>
</table>
</body></html>"""

CODE_BLOCK_HTML = """<html><head></head><body>
<h2>Code Example</h2>
<pre><code>def hello():
    print("hello world")
</code></pre>
</body></html>"""

LONG_HTML = "<html><head></head><body>" + "".join(
    f"<h2>Section {i}</h2><p>{'Lorem ipsum dolor sit amet. ' * 40}</p>"
    for i in range(20)
) + "</body></html>"

COMPLEX_HTML = """<html><head></head><body>
<h1>Main Title</h1>
<p>Introduction paragraph with some content.</p>
<h2>Data Table</h2>
<table>
  <thead><tr><th>Col A</th><th>Col B</th></tr></thead>
  <tbody>
    <tr><td>Row 1</td><td>Val 1</td></tr>
    <tr><td>Row 2</td><td>Val 2</td></tr>
  </tbody>
</table>
<h2>Code</h2>
<pre><code>x = 1
y = 2
print(x + y)</code></pre>
<h2>Images</h2>
<img src="test.png" width="200" height="100" />
<p>Final paragraph.</p>
</body></html>"""


@pytest.fixture
def default_config() -> PDFConfig:
    return PDFConfig()


@pytest.fixture
def simple_soup() -> BeautifulSoup:
    return BeautifulSoup(SIMPLE_HTML, "lxml")


@pytest.fixture
def table_soup() -> BeautifulSoup:
    return BeautifulSoup(TABLE_HTML, "lxml")


@pytest.fixture
def code_soup() -> BeautifulSoup:
    return BeautifulSoup(CODE_BLOCK_HTML, "lxml")


@pytest.fixture
def long_soup() -> BeautifulSoup:
    return BeautifulSoup(LONG_HTML, "lxml")


@pytest.fixture
def complex_soup() -> BeautifulSoup:
    return BeautifulSoup(COMPLEX_HTML, "lxml")
