# ADR-001: Hybrid Architecture — DOM Pre-Processing + Playwright Renderer

**Date:** 2026-03-23
**Status:** Accepted
**Decision Makers:** Wes

---

## Context

We need a Python HTML-to-PDF library that produces high-quality, print-ready PDFs from arbitrary HTML. Existing solutions fall into two camps: pure-Python renderers (weasyprint, xhtml2pdf) that struggle with modern CSS and complex layouts, and headless browser wrappers (pyppeteer, playwright-based) that delegate everything to Chromium but offer limited control over page break logic, layout optimization, and print-specific adjustments.

Neither camp alone solves the problem. Pure-Python renderers lack rendering fidelity. Browser-only wrappers lack pre-processing intelligence. We need both.

## Decision

**Adopt a hybrid architecture:** a custom DOM analysis and pre-processing layer that sits in front of Playwright's Chromium renderer.

The pipeline is:

```
HTML Input → Parser (BeautifulSoup4) → DOM Analyzer → Layout Pre-Processor → Modified HTML → Playwright (Chromium) → PDF Output
```

### Key Architectural Choices

**1. Playwright over Puppeteer/Selenium**

Playwright provides a first-class async Python API (`playwright-python`), supports multiple browser contexts for concurrency, has built-in PDF generation with fine-grained control (`page.pdf()`), and is actively maintained by Microsoft. It bundles its own Chromium, eliminating version drift.

Rejected alternatives:

- **Puppeteer (via pyppeteer):** Pyppeteer is unmaintained. Node.js Puppeteer requires a JS bridge.
- **Selenium:** Heavyweight, no native PDF support, requires separate ChromeDriver management.
- **WeasyPrint as renderer:** Cannot handle modern CSS Grid/Flexbox reliably.

**2. BeautifulSoup4 for DOM Analysis (not lxml alone)**

BS4 provides a forgiving parser that handles malformed HTML gracefully — critical for real-world input. It works with multiple parser backends (html.parser, lxml, html5lib) so we can offer speed vs. correctness tradeoffs.

**3. Custom Pre-Processing Layer (not CSS Paged Media alone)**

CSS Paged Media (`@page`, `break-before`, `break-after`) is powerful but insufficient. Real-world HTML rarely includes these directives. Our pre-processor injects them intelligently by analyzing DOM structure — detecting heading/content proximity, table row splitting, orphaned elements, and content density per estimated page.

**4. Three Interfaces from One Core**

```
                    ┌──────────────┐
                    │  Core Engine  │  ← html2pdf.core
                    └──────┬───────┘
           ┌───────────────┼───────────────┐
      ┌────▼────┐    ┌────▼────┐    ┌─────▼─────┐
      │ Library │    │   CLI   │    │  REST API  │
      │  API    │    │  (Click)│    │  (FastAPI) │
      └─────────┘    └─────────┘    └───────────┘
```

The core engine is a pure Python module. CLI wraps it with Click. REST API wraps it with FastAPI. No interface layer contains business logic.

**5. Configuration: Defaults with User Overrides**

Frozen dataclass defaults. User config overlays via `dict` merge. Priority: function args > config file > env vars > defaults.

```python
@dataclass(frozen=True)
class PDFConfig:
    page_size: str = "A4"
    margin_top: str = "20mm"
    margin_bottom: str = "20mm"
    margin_left: str = "15mm"
    margin_right: str = "15mm"
    enable_page_breaks: bool = True
    break_strategy: str = "smart"  # "smart" | "css-only" | "none"
    font_adjustment: bool = True
    header_template: str | None = None
    footer_template: str | None = None
    print_background: bool = True
    scale: float = 1.0
    landscape: bool = False
```

**6. Async-First with Sync Wrapper**

Playwright's Python API is async-native. The core engine is async. The library exposes both `async def convert()` and a sync `convert()` wrapper using `asyncio.run()`. The CLI uses the sync API. FastAPI uses the async API natively.

## Consequences

**Positive:**

- High rendering fidelity (Chromium) with intelligent layout control (pre-processor)
- Single codebase serves all three interfaces
- Async-first means the REST API handles concurrent requests efficiently
- Frozen config prevents mutation bugs

**Negative:**

- Chromium dependency is heavy (~200MB). Users must install Playwright browsers.
- Two-stage pipeline adds complexity vs. a simple `page.pdf()` wrapper
- DOM analysis heuristics will need tuning for edge cases over time
- Async-first adds complexity for users who only want sync usage

**Risks:**

- Playwright Chromium updates may change PDF rendering behavior. Mitigation: pin Playwright version, visual regression tests.
- DOM pre-processing may conflict with existing CSS in the source HTML. Mitigation: pre-processor only adds directives, never removes. User can disable with `break_strategy="none"`.

## References

- Playwright Python: https://playwright.dev/python/
- CSS Paged Media spec: https://www.w3.org/TR/css-page-3/
- BeautifulSoup4: https://www.crummy.com/software/BeautifulSoup/
