# html2pdf — Implementation Plan

> **Version:** 1.0 | **Date:** 2026-03-23 | **Owner:** Wes
> **Architecture:** See `ADR-001-ARCHITECTURE.md`
> **Python:** 3.10+ | **Package:** PyPI | **API Framework:** FastAPI

---

## Overview

Five phases, each with clear entry/exit criteria. Phases are sequential — each builds on the prior. Phase closes when all exit criteria are met and Wes approves the phase review.

```
Phase 1: Core Engine + DOM Analysis     ← Library API
Phase 2: CLI Interface                  ← Click wrapper
Phase 3: REST API                       ← FastAPI wrapper
Phase 4: Testing + CI/CD               ← Quality infrastructure
Phase 5: Packaging + PyPI Release       ← Distribution
```

---

## Package Structure (Target State)

```
src/html2pdf/
├── __init__.py              # Public API: convert(), async_convert(), PDFConfig
├── core/
│   ├── __init__.py
│   ├── engine.py            # Orchestrator — ties analyzer + preprocessor + renderer
│   ├── config.py            # PDFConfig frozen dataclass, config resolution
│   └── exceptions.py        # Custom exception hierarchy
├── analyzer/
│   ├── __init__.py
│   ├── dom.py               # DOM tree analysis — structure, depth, content density
│   ├── metrics.py           # Page estimation, element sizing heuristics
│   └── detector.py          # Pattern detection — tables, lists, code blocks, images
├── preprocessor/
│   ├── __init__.py
│   ├── breaks.py            # Page break injection engine
│   ├── fonts.py             # Font normalization and adjustment
│   ├── margins.py           # Margin and spacing optimization
│   ├── sanitizer.py         # CSS injection validation
│   └── pipeline.py          # Pre-processing pipeline orchestrator
├── renderer/
│   ├── __init__.py
│   ├── playwright_backend.py # Playwright Chromium PDF generation
│   └── browser_pool.py      # Browser instance management and pooling
├── cli/
│   ├── __init__.py
│   └── main.py              # Click CLI entry point
├── api/
│   ├── __init__.py
│   ├── app.py               # FastAPI application factory
│   ├── routes.py            # API endpoints
│   ├── models.py            # Pydantic request/response models
│   └── middleware.py         # Rate limiting, CORS, error handling
└── py.typed                  # PEP 561 marker
```

---

## Phase 1: Core Engine + DOM Analysis

**Goal:** Working library API that converts HTML to PDF with intelligent page breaks.

### 1.1 — Project Initialization

**Files to create:**

- `pyproject.toml` — Build config (hatchling backend), dependencies, metadata
- `src/html2pdf/__init__.py` — Public API surface
- `src/html2pdf/core/config.py` — `PDFConfig` frozen dataclass

**Dependencies (core):**

```
playwright>=1.40
beautifulsoup4>=4.12
lxml>=5.0
```

**pyproject.toml key sections:**

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "html2pdf-smart"
version = "0.1.0"
requires-python = ">=3.10"
dependencies = [
    "playwright>=1.40,<1.50",
    "beautifulsoup4>=4.12",
    "lxml>=5.0",
]

[project.optional-dependencies]
cli = ["click>=8.1"]
api = ["fastapi>=0.104", "uvicorn[standard]>=0.24"]
dev = ["pytest>=7.4", "pytest-asyncio>=0.23", "ruff>=0.1", "mypy>=1.7"]
all = ["html2pdf-smart[cli,api,dev]"]

[project.scripts]
html2pdf = "html2pdf.cli.main:cli"
```

**Config resolution order (implemented in `config.py`):**

```
function kwargs → config file → env vars (HTML2PDF_*) → frozen defaults
```

**Config file locations (checked in order, first found wins):**

1. Path passed explicitly (`--config path/to/file.toml` in CLI, or `config_path=` in library)
2. `./html2pdf.toml` in current working directory
3. `pyproject.toml` section `[tool.html2pdf]` in current working directory
4. `~/.config/html2pdf/config.toml` (user-level defaults)

Both standalone `html2pdf.toml` and `pyproject.toml [tool.html2pdf]` use the same TOML schema. The CLI `--config` flag accepts either format.

**Exit criteria:**

- `pip install -e .` succeeds
- `python -c "from html2pdf import PDFConfig; print(PDFConfig())"` prints defaults
- `playwright install chromium` completes

### 1.2 — DOM Analyzer

**Files:** `analyzer/dom.py`, `analyzer/metrics.py`, `analyzer/detector.py`

**`dom.py` — DOM Tree Analysis:**

```python
@dataclass
class DOMNode:
    tag: str
    depth: int
    text_length: int
    child_count: int
    has_block_children: bool
    estimated_height_mm: float  # heuristic
    classes: list[str]
    element: Tag  # BS4 reference

@dataclass
class DOMAnalysis:
    nodes: list[DOMNode]
    total_text_length: int
    estimated_pages: float
    heading_positions: list[int]  # indices into nodes
    table_positions: list[int]
    image_positions: list[int]
    code_block_positions: list[int]
    max_depth: int
```

The analyzer walks the DOM tree once, producing a flat list of `DOMNode` objects with structural metadata. This is the input to the pre-processor.

**`metrics.py` — Page Estimation:**

Heuristics for estimating content height without rendering:

- Text: `chars * avg_char_width / content_width * line_height`
- Images: respect explicit `width`/`height` attrs; default to 150mm if missing
- Tables: `rows * estimated_row_height`
- Headings: fixed height per heading level + margin

**`detector.py` — Pattern Detection:**

Identifies structural patterns the pre-processor needs to handle:

- Tables that span more than estimated page height → mark for careful break handling
- Heading immediately followed by short content → keep-together candidate
- Orphan detection: last element of a section with < 2 lines
- Widow detection: first element of a section with < 2 lines
- Code blocks: never break mid-block if under threshold height

**Exit criteria:**

- Unit tests for analyzer on 5+ representative HTML structures
- `DOMAnalysis` correctly identifies headings, tables, images, code blocks
- Page estimation within 20% of actual for test documents

### 1.3 — Pre-Processor Pipeline

**Files:** `preprocessor/breaks.py`, `preprocessor/fonts.py`, `preprocessor/margins.py`, `preprocessor/sanitizer.py`, `preprocessor/pipeline.py`

**`breaks.py` — Page Break Injection:**

Three strategies (set via `PDFConfig.break_strategy`):

- `"smart"` (default): Full heuristic analysis. Injects `page-break-before`, `page-break-after`, `page-break-inside: avoid` based on DOM analysis.
- `"css-only"`: Respects existing CSS paged media directives only. Adds nothing.
- `"none"`: Strips all page break CSS. Let Chromium decide everything.

Smart break rules:

1. Never break inside a heading + first-paragraph pair
2. Never break inside a table row (inject `page-break-inside: avoid` on `<tr>`)
3. Prefer breaks before `<h1>`–`<h3>` when they're not at page top
4. Avoid orphans (< 2 lines at bottom of page) and widows (< 2 lines at top)
5. Never break inside `<pre>` / `<code>` blocks under 40 lines
6. For tables taller than one page: allow breaks between rows, inject repeated `<thead>`

**`fonts.py` — Font Normalization:**

- Detect system font fallbacks that render differently across platforms
- Inject `@font-face` declarations for specified web-safe fonts
- Adjust `font-size` and `line-height` if user config requests it
- Handle `em`/`rem` normalization relative to configured base size

**`margins.py` — Margin/Spacing Optimization:**

- Collapse excessive margins between elements (configurable threshold)
- Add page-aware padding near estimated break points
- Ensure content doesn't start in the margin zone of a new page

**`sanitizer.py` — CSS Injection Validation:**

- All CSS the pre-processor injects goes through sanitization
- Whitelist of allowed properties (page-break-*, font-*, margin-*, padding-*)
- No `position: fixed/absolute`, no `z-index` injection, no script injection
- Produces a clean `<style>` block prepended to `<head>`

**`pipeline.py` — Orchestrator:**

```python
class PreProcessorPipeline:
    def __init__(self, config: PDFConfig, analysis: DOMAnalysis):
        self.steps = [
            FontNormalizer(config),
            MarginOptimizer(config),
            BreakInjector(config, analysis),
            CSSSanitizer(),
        ]

    def process(self, soup: BeautifulSoup) -> BeautifulSoup:
        for step in self.steps:
            soup = step.apply(soup)
        return soup
```

**Exit criteria:**

- Smart breaks prevent heading/content separation on 3+ test documents
- Table rows never split mid-row
- `"none"` strategy produces identical HTML to input (minus sanitization wrapper)
- Pre-processor is idempotent — running twice produces same output as once

### 1.4 — Playwright Renderer

**Files:** `renderer/playwright_backend.py`, `renderer/browser_pool.py`

**`playwright_backend.py`:**

```python
class PlaywrightRenderer:
    async def render(self, html: str, config: PDFConfig) -> bytes:
        """Render pre-processed HTML to PDF bytes."""
        async with self._get_page() as page:
            await page.set_content(html, wait_until="networkidle")
            return await page.pdf(
                format=config.page_size,
                margin={
                    "top": config.margin_top,
                    "bottom": config.margin_bottom,
                    "left": config.margin_left,
                    "right": config.margin_right,
                },
                print_background=config.print_background,
                scale=config.scale,
                landscape=config.landscape,
                display_header_footer=bool(config.header_template or config.footer_template),
                header_template=config.header_template or "",
                footer_template=config.footer_template or "",
            )
```

**`browser_pool.py`:**

- Lazy browser launch — don't start Chromium until first conversion
- Browser context reuse — new contexts per conversion, shared browser instance
- Configurable pool size for concurrent conversions (default: 1 for library, configurable for API)
- Graceful shutdown — close all contexts and browser on `__aexit__`

**Exit criteria:**

- `async_convert("<h1>Hello</h1>")` produces a valid PDF
- Sync wrapper `convert()` works from a non-async context
- Browser pool handles 3 concurrent conversions without deadlock
- PDF file size is reasonable (< 100KB for simple single-page HTML)

### 1.5 — Engine Orchestrator + Public API

**Files:** `core/engine.py`, `__init__.py`

**`engine.py`:**

```python
class ConversionEngine:
    def __init__(self, config: PDFConfig | None = None):
        self.config = config or PDFConfig()
        self._renderer = PlaywrightRenderer()

    async def convert(self, html: str, **overrides) -> bytes:
        config = self._resolve_config(overrides)
        soup = BeautifulSoup(html, "lxml")
        analysis = DOMAnalyzer.analyze(soup)
        pipeline = PreProcessorPipeline(config, analysis)
        processed = pipeline.process(soup)
        return await self._renderer.render(str(processed), config)
```

**`__init__.py` — Public API:**

```python
from html2pdf.core.config import PDFConfig
from html2pdf.core.engine import ConversionEngine

async def async_convert(html: str, **kwargs) -> bytes: ...
def convert(html: str, **kwargs) -> bytes: ...  # sync wrapper
def convert_file(path: str | Path, output: str | Path | None = None, **kwargs) -> Path: ...
```

**Exit criteria:**

- `html2pdf.convert("<p>Test</p>")` returns valid PDF bytes
- `html2pdf.convert_file("input.html", "output.pdf")` writes a PDF
- Config overrides work: `convert(html, page_size="Letter", landscape=True)`
- Exception hierarchy is clean: `HTML2PDFError` → `AnalysisError`, `RenderError`, `ConfigError`

---

## Phase 2: CLI Interface

**Goal:** Full-featured CLI wrapping the core engine.

**Files:** `cli/main.py`

**Framework:** Click 8.1+

**Commands:**

```bash
# Basic conversion
html2pdf convert input.html -o output.pdf

# With options
html2pdf convert input.html -o output.pdf \
    --page-size Letter \
    --landscape \
    --margin-top 25mm \
    --break-strategy smart \
    --no-background

# From stdin
cat page.html | html2pdf convert - -o output.pdf

# From URL (fetch + convert)
html2pdf convert https://example.com -o output.pdf

# Batch conversion
html2pdf batch ./html-files/ -o ./pdf-output/ --pattern "*.html"

# Config file
html2pdf convert input.html -o output.pdf --config html2pdf.toml

# Version / info
html2pdf version
html2pdf info  # shows Chromium version, installed fonts, config path
```

**Implementation details:**

- Click group with `convert`, `batch`, `version`, `info` subcommands
- Progress bar via `click.progressbar` for batch mode
- URL detection: if input starts with `http://` or `https://`, fetch first via `httpx`
- Stdin support: `-` as input reads from `sys.stdin`
- Exit codes: 0 success, 1 conversion error, 2 config error, 3 browser error

**Exit criteria:**

- `html2pdf convert test.html -o test.pdf` produces a PDF
- Batch mode converts a directory of 5 HTML files
- `--help` output is clean and complete for every command
- Stdin piping works
- Error messages are user-friendly (no raw tracebacks)

---

## Phase 3: REST API (FastAPI)

**Goal:** HTTP API for HTML-to-PDF conversion, suitable for microservice deployment.

**Files:** `api/app.py`, `api/routes.py`, `api/models.py`, `api/middleware.py`

**Endpoints:**

```
POST /convert              — Convert HTML string to PDF
POST /convert/file         — Upload HTML file, return PDF
POST /convert/url          — Fetch URL, convert to PDF
GET  /health               — Health check (browser status)
GET  /config/defaults      — Return default config values
```

**Request/Response models (Pydantic v2):**

```python
class ConvertRequest(BaseModel):
    html: str
    config: PDFConfigOverrides | None = None

class ConvertFileResponse:
    # Returns PDF as streaming file response
    media_type = "application/pdf"

class HealthResponse(BaseModel):
    status: str  # "healthy" | "degraded" | "unhealthy"
    browser_ready: bool
    version: str
    uptime_seconds: float
```

**Middleware:**

- CORS (configurable origins)
- Rate limiting (configurable, default 60 req/min)
- Request size limit (default 10MB)
- Request ID header injection
- Error handler that returns structured JSON errors

**Browser lifecycle:**

- Browser pool initialized on startup via `@app.on_event("startup")`
- Configurable pool size via `HTML2PDF_API_POOL_SIZE` env var (default: 3)
- Health endpoint reports browser readiness
- Graceful shutdown closes pool

**Deployment config (goes in `dist/`):**

```yaml
# docker-compose.yml
services:
  html2pdf:
    build: .
    ports: ["8000:8000"]
    environment:
      HTML2PDF_API_POOL_SIZE: "5"
      HTML2PDF_API_RATE_LIMIT: "120"
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
```

**Exit criteria:**

- `POST /convert` with HTML body returns PDF bytes
- `GET /health` returns 200 with browser status
- Rate limiter rejects excess requests with 429
- Concurrent requests (5 simultaneous) don't deadlock
- OpenAPI docs render at `/docs`

---

## Phase 4: Testing + CI/CD

**Goal:** Comprehensive test suite and automated quality pipeline.

### Test Architecture

```
tests/
├── conftest.py              # Shared fixtures (sample HTML, temp dirs, browser)
├── unit/
│   ├── test_config.py       # Config resolution, frozen dataclass
│   ├── test_analyzer.py     # DOM analysis, metrics, detection
│   ├── test_preprocessor.py # Each pre-processor step
│   ├── test_sanitizer.py    # CSS injection validation
│   └── test_pipeline.py     # Pipeline orchestration
├── integration/
│   ├── test_engine.py       # Full HTML→PDF pipeline
│   ├── test_cli.py          # Click CLI via CliRunner
│   ├── test_api.py          # FastAPI via TestClient
│   └── test_browser_pool.py # Concurrent browser management
├── visual/
│   ├── test_regression.py   # PDF screenshot comparison
│   ├── baselines/           # Known-good reference images
│   └── fixtures/            # Test HTML documents
│       ├── simple.html
│       ├── tables.html
│       ├── long-document.html
│       ├── code-blocks.html
│       ├── images.html
│       └── complex-layout.html
└── performance/
    └── test_benchmarks.py   # Conversion time, memory usage
```

### Testing Strategy

**Unit tests (no browser):**

- Config: default values, override merging, env var reading, validation
- Analyzer: DOM walking, metric calculation, pattern detection
- Pre-processor: each step in isolation against known HTML → expected output
- Sanitizer: injection attempts blocked, valid CSS allowed

**Integration tests (browser required):**

- End-to-end conversion: HTML in → valid PDF out
- CLI: CliRunner tests for all commands and flag combinations
- API: TestClient tests for all endpoints, error cases, concurrent requests
- Browser pool: lifecycle, concurrent use, error recovery

**Visual regression tests:**

- Convert reference HTML documents to PDF
- Extract page images via `pdf2image` or similar
- Compare against stored baselines with configurable tolerance
- Fail on pixel diff above threshold (suggestion: 0.5%)

**Performance benchmarks (OPTIONAL — not blocking for Phase 4 exit):**

- Track conversion time for reference documents
- Track peak memory during conversion
- Track browser pool throughput under concurrent load
- Informational only, stored for trend analysis. Phase 4 exits when unit, integration, and visual tests pass. Benchmarks can be added post-release.

### CI/CD Pipeline (GitHub Actions)

```yaml
# .github/workflows/ci.yml
name: CI
on: [push, pull_request]
jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: pip install ruff mypy
      - run: ruff check src/ tests/
      - run: mypy src/html2pdf/

  test-unit:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: pip install -e ".[dev]"
      - run: pytest tests/unit/ -v --tb=short

  test-integration:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: pip install -e ".[all]"
      - run: playwright install chromium --with-deps
      - run: pytest tests/integration/ -v --tb=short

  test-visual:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: pip install -e ".[all]"
      - run: playwright install chromium --with-deps
      - run: pytest tests/visual/ -v --tb=short
```

**Exit criteria:**

- Unit test coverage > 90% for analyzer and pre-processor
- Integration tests pass for all three interfaces
- Visual regression baselines established for 6 reference documents
- CI pipeline runs green on push and PR
- `ruff` and `mypy` pass with zero errors

---

## Phase 5: Packaging + PyPI Release

**Goal:** Published, installable package with documentation.

### Package Metadata

```toml
[project]
name = "html2pdf-smart"
version = "0.1.0"
description = "Intelligent HTML-to-PDF conversion with layout pre-processing"
readme = "README.md"
license = {text = "MIT"}
authors = [{name = "Stonebridge Systems"}]
keywords = ["html", "pdf", "converter", "playwright", "layout"]
classifiers = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Topic :: Text Processing :: Markup :: HTML",
]
```

### Release Checklist

1. Version bump in `pyproject.toml`
2. Changelog update
3. All CI checks green
4. `python -m build` produces wheel and sdist
5. `twine check dist/*` passes
6. Tag the release in git
7. `twine upload dist/*` to PyPI
8. Verify install from PyPI: `pip install html2pdf-smart`

### Post-Install Script

Playwright requires a browser install step. Handle this gracefully:

```python
# On first import, check if Chromium is installed
# If not, print a helpful message:
# "Run 'playwright install chromium' to complete setup"
```

### Documentation (docs/ in repo, not Stonebridge docs/)

- README.md with quickstart (library, CLI, API)
- API reference (auto-generated from docstrings via `pdoc` or `mkdocs`)
- Configuration reference (all PDFConfig fields with examples)
- Architecture overview (simplified ADR)

**Exit criteria:**

- `pip install html2pdf-smart` installs from PyPI
- `html2pdf convert test.html -o test.pdf` works after install
- `python -c "import html2pdf; print(html2pdf.__version__)"` prints version
- All three interfaces work from a clean install
- README quickstart examples are copy-paste functional

---

## Phase Gate Criteria

| Phase | Entry Condition                | Exit Condition                                  |
| ----- | ------------------------------ | ----------------------------------------------- |
| 1     | ADR approved, skeleton created | Library API converts HTML→PDF with smart breaks |
| 2     | Phase 1 complete               | CLI converts files, batches, stdin, URLs        |
| 3     | Phase 2 complete               | REST API serves conversions, health check works |
| 4     | Phase 3 complete               | CI green, tests pass, visual baselines set      |
| 5     | Phase 4 complete               | Package on PyPI, clean install works            |

---

## Risk Register

| Risk                                            | Impact | Likelihood | Mitigation                                               |
| ----------------------------------------------- | ------ | ---------- | -------------------------------------------------------- |
| Playwright Chromium update changes rendering    | High   | Medium     | Pin version, visual regression tests                     |
| DOM heuristics produce bad breaks on edge cases | Medium | High       | Strategy override (`css-only`, `none`), user can disable |
| Browser pool deadlock under load                | High   | Low        | Timeout on context acquisition, pool health check        |
| Package name collision on PyPI                  | Low    | Low        | Check availability early, `html2pdf-smart` is available  |
| Large HTML files cause memory issues            | Medium | Medium     | Streaming mode in Phase 2+, configurable size limits     |

---

## Dependency Map

```
Phase 1 ──┬── Phase 2 (CLI)
           ├── Phase 3 (API)
           └── Phase 4 (Testing spans all phases — starts Phase 1, completes Phase 4)
                  └── Phase 5 (Packaging)
```

Testing work begins in Phase 1 (unit tests for analyzer/preprocessor) and accumulates through each phase. Phase 4 is when the full test infrastructure — CI/CD, visual regression, benchmarks — is formalized and hardened.
