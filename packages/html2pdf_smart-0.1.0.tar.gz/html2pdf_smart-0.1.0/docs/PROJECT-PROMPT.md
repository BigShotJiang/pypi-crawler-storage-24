# html2pdf — Project Prompt

> **Load this at the start of every session.** It is the single document that orients any agent or collaborator on what this project is, how to work on it, and what to do before writing a single line of code.
>
> **Last updated:** 2026-03-23 | **Owner:** Wes

---

## Identity

**Project:** html2pdf
**Location:** `/home/dev/cmd/stone/002-dev/html2pdf/`
**Subsidiary:** 002-dev (Stonebridge Systems)
**Registry:** Listed in `stone/WORKSPACE.md`

A Python HTML-to-PDF library with intelligent layout pre-processing. Hybrid architecture — a custom DOM analysis layer handles page break logic, font/margin adjustment, and layout optimization before handing off to Playwright (Chromium) for rendering. Three interfaces: Python library, CLI (Click), REST API (FastAPI). Sensible defaults with layered user overrides via frozen dataclass config.

---

## Session Boot Sequence

Every session — no exceptions — follows this sequence before any implementation work begins.

### Step 1: Read the governance layer

```
1. stone/WORKSPACE.md                         → Know where you are in the org
2. 002-dev/html2pdf/README.md                 → Project identity card, hard rules
3. 002-dev/html2pdf/docs/ADR-001-ARCHITECTURE.md → Architectural decisions in force
4. 002-dev/html2pdf/docs/IMPLEMENTATION-PLAN.md  → Phase specs, exit criteria, package structure
```

### Step 2: Read the most recent handoff

```
5. 002-dev/html2pdf/handoffs/HANDOFF-HTML2PDF-[latest].md → Ground truth for current state
```

The most recent handoff by date is the source of truth for where the project stands. Read it completely. Pay attention to REMAINING WORK — that's your starting point.

### Step 3: Run entry gates

Execute every entry gate in the handoff. All must pass. If any gate fails, resolve it before doing anything else. Do not skip gates because "they probably pass."

### Step 4: Confirm scope with Wes

Before writing code, state:
- What phase you're working in
- Which specific tasks from the implementation plan you intend to tackle this session
- Any ambiguities or decisions that need input

Wait for confirmation. Do not assume scope from the handoff alone — Wes may want to adjust priorities.

---

## Architectural Guardrails

These are non-negotiable constraints. Violating any of them means stopping and asking.

1. **Hybrid pipeline is the architecture.** HTML → BS4 Parser → DOM Analyzer → Pre-Processor → Modified HTML → Playwright → PDF. Do not collapse layers, skip the pre-processor, or bypass the analyzer.

2. **Three interfaces, one core.** CLI and API are thin wrappers around the core engine. No business logic in the interface layers. If you're tempted to add conversion logic to a route handler or CLI command, it belongs in `core/` or `preprocessor/`.

3. **Async-first, sync-wrapped.** The core engine is async (Playwright is async-native). The sync `convert()` function uses `asyncio.run()`. The CLI calls the sync wrapper. The FastAPI API calls the async core directly.

4. **Frozen config, layered overrides.** `PDFConfig` is a frozen dataclass. User overrides create a new instance — they never mutate defaults. Resolution order: function kwargs → config file → env vars → frozen defaults.

5. **Pre-processor only adds, never removes.** The DOM pre-processor injects CSS directives (page breaks, font adjustments). It never strips existing CSS from the source HTML. Users can disable the pre-processor entirely with `break_strategy="none"`.

6. **Deterministic analysis.** Same HTML input must always produce the same `DOMAnalysis` and the same pre-processed output. No randomness, no time-dependent behavior, no external state.

7. **Sanitize all injected CSS.** Every style the pre-processor generates passes through `sanitizer.py`. Whitelist only — no arbitrary property injection.

---

## Phase Map

| Phase | Scope | Depends On | Key Deliverable |
|-------|-------|------------|-----------------|
| 0 | Planning & Architecture | — | ADR, implementation plan, skeleton ✅ |
| 1 | Core Engine + DOM Analysis | Phase 0 | `convert()` produces PDF with smart breaks |
| 2 | CLI Interface | Phase 1 | `html2pdf convert input.html -o output.pdf` works |
| 3 | REST API (FastAPI) | Phase 2 | `POST /convert` returns PDF, `/health` reports status |
| 4 | Testing + CI/CD | Phase 3 | CI green, unit/integration/visual tests pass |
| 5 | Packaging + PyPI Release | Phase 4 | `pip install html2pdf-smart` works from PyPI |

Unit tests are written alongside implementation starting in Phase 1. Phase 4 is when the full test infrastructure (CI/CD, visual regression, comprehensive coverage) gets formalized and hardened.

---

## Mandatory Phase Review Protocol

**Every phase ends with a structured review before the next phase begins.** This is not optional. The review serves three purposes: validate the work, brainstorm improvements, and decide whether the plan for the next phase needs adjustment.

### When a phase review triggers

A phase review triggers when **all exit criteria for that phase** (as defined in `IMPLEMENTATION-PLAN.md`) are met. The agent does not proceed to the next phase — it stops and initiates the review.

### Phase Review Format

The review is a conversation with Wes, structured in three blocks:

#### Block 1 — Validation (Agent-Led)

The agent presents:

1. **Exit criteria checklist** — each criterion from the implementation plan, marked pass/fail with evidence (command output, test results, file paths).
2. **Deviation report** — anything that was built differently from the plan, and why. If the plan said X and you did Y, explain the reasoning here.
3. **Known issues** — bugs, edge cases, or limitations discovered during implementation that aren't in the plan's risk register. Severity-tagged (CRITICAL / IMPORTANT / MINOR).
4. **Technical debt incurred** — shortcuts taken, TODOs left in code, hardcoded values that need config, anything that will need attention later.

#### Block 2 — Brainstorm (Collaborative)

Wes and the agent discuss:

1. **What worked well?** — Patterns, approaches, or tools that should carry forward.
2. **What surprised us?** — Unexpected complexity, things that were easier than expected, assumptions that proved wrong.
3. **Additives** — features, improvements, or capabilities not in the original plan that should be considered. These might include:
   - New pre-processor steps (e.g., image optimization, accessibility injection)
   - Additional CLI commands or flags discovered during use
   - API middleware or endpoints that became obvious needs
   - Config options that users would expect but we didn't spec
   - Integration points (e.g., webhooks, S3 output, template systems)
4. **Subtractions** — anything in the plan for later phases that no longer makes sense or should be deprioritized.
5. **Architecture stress test** — given what we now know, does the architecture hold? Any cracks forming? Would we make the same decisions in the ADR?

#### Block 3 — Decision (Wes-Led)

Wes decides:

1. **Phase approved?** Yes / Yes with conditions / No (rework needed)
2. **Plan amendments** — specific changes to the implementation plan for upcoming phases based on the brainstorm. These get written into `IMPLEMENTATION-PLAN.md` as versioned amendments (never silently edit — add an amendment section with date and rationale).
3. **ADR updates** — if the architecture needs adjustment, a new ADR is drafted (ADR-002, etc.) or the existing one is amended with a dated addendum.
4. **Priority shifts** — if brainstormed additives are adopted, where they slot into the phase plan.
5. **Green light** — explicit "proceed to Phase N" before any work begins on the next phase.

### Phase Review Output

Every phase review produces a document: `docs/PHASE-REVIEW-[N]-[YYYYMMDD].md`

```markdown
# Phase [N] Review — [Phase Name]

**Date:** YYYY-MM-DD
**Participants:** Wes, [agent/session ID]
**Phase duration:** [start date] → [end date]
**Sessions:** [count]

## Validation
[Exit criteria checklist with pass/fail evidence]

## Deviations
[What changed from the plan and why]

## Known Issues
[Severity-tagged list]

## Technical Debt
[Items to address in future phases]

## Brainstorm Notes
### Additives Considered
[Each item with disposition: ADOPTED / DEFERRED / REJECTED + rationale]

### Subtractions
[Items removed or deprioritized]

### Architecture Assessment
[Holds / Needs minor adjustment / Needs major revision]

## Decisions
- Phase approved: [Yes/No/Conditional]
- Plan amendments: [list with IMPLEMENTATION-PLAN.md section references]
- ADR updates: [None / ADR-00N drafted]
- Next phase green light: [Yes — proceed to Phase N / No — rework items X, Y, Z first]
```

---

## File Discipline

All files follow the Stonebridge universal skeleton:

| What | Where | Never Here |
|------|-------|------------|
| Specs, ADRs, plans, phase reviews | `docs/` | Project root |
| Session handoffs | `handoffs/HANDOFF-HTML2PDF-[YYYYMMDD].md` | Anywhere else |
| Python source code | `src/` | Project root, docs/ |
| Build outputs, wheels, Docker configs | `dist/` | Project root, src/ |
| Superseded files | `archive/` | Deleted |
| Project identity card | `README.md` (project root) | — |
| This prompt | `docs/PROJECT-PROMPT.md` | — |

Nothing else goes at the project root. If you're unsure where a file belongs, ask.

---

## Handoff Discipline

Every session ends with a handoff written to `handoffs/HANDOFF-HTML2PDF-[YYYYMMDD].md` following the template in `001-docs/04-templates/HANDOFF-TEMPLATE.md`.

A handoff that is missing any of these four things is incomplete:

1. **What was completed** — specific files created or modified, tasks closed, decisions made
2. **What was NOT done and why** — blockers hit, things explicitly deferred, reasons a direction was abandoned
3. **Exact next action** — specific enough that the next agent can start immediately without asking a single clarifying question
4. **Relevant file paths** — exact paths to every file touched or created this session

---

## Communication Protocol

**When to ask Wes (stop and wait):**
- Any architectural change that contradicts the ADR
- Adding a new dependency not in the implementation plan
- Changing the public API surface (`__init__.py` exports)
- Any file that would go outside the project skeleton
- Launching Playwright / Chromium for the first time in a session
- Phase review initiation

**When to proceed without asking:**
- Implementing tasks exactly as specified in the plan
- Writing unit tests for code you just wrote
- Fixing linting or type-checking errors
- Creating files within the established package structure
- Refactoring internals that don't change the public API

**When to flag but keep working:**
- Minor deviations from the plan (e.g., splitting a file that got too large)
- Discovering an edge case the plan didn't anticipate
- Finding a better library or approach for a subtask (note it for the phase review)

---

## Quick Reference

```
Working directory:    /home/dev/cmd/stone/002-dev/html2pdf/
Architecture:         docs/ADR-001-ARCHITECTURE.md
Implementation plan:  docs/IMPLEMENTATION-PLAN.md
Latest handoff:       handoffs/HANDOFF-HTML2PDF-[latest by date].md
Phase reviews:        docs/PHASE-REVIEW-[N]-[YYYYMMDD].md
Handoff template:     /home/dev/stonebridge-systems/001-docs/04-templates/HANDOFF-TEMPLATE.md
Governance:           ~/STONEBRIDGE-WORKSPACE-FRAMEWORK.md
Workspace map:        /home/dev/cmd/stone/WORKSPACE.md
```

**Pipeline:**
```
HTML → BS4 → DOMAnalyzer → PreProcessor → Modified HTML → Playwright (Chromium) → PDF
```

**Config priority:**
```
function kwargs → config file → env vars (HTML2PDF_*) → frozen defaults
```

**Package name:** `html2pdf-smart`
**Python floor:** 3.10+
**Key deps:** playwright (pinned <1.50), beautifulsoup4, lxml, click (CLI), fastapi (API)
