"""Margin and spacing optimization.

Collapses excessive margins between elements and ensures content
doesn't start in the margin zone of a new page.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from bs4 import BeautifulSoup

if TYPE_CHECKING:
    from html2pdf.core.config import PDFConfig

# Maximum margin between elements before we consider it excessive
MAX_MARGIN_BETWEEN_ELEMENTS_MM = 15


class MarginOptimizer:
    """Optimizes margin and spacing for PDF output.

    Collapses excessive margins and adds page-aware padding
    near estimated break points.

    Args:
        config: PDFConfig instance.
    """

    def __init__(self, config: PDFConfig) -> None:
        self.config = config

    def apply(self, soup: BeautifulSoup) -> BeautifulSoup:
        """Apply margin optimizations to the document.

        Args:
            soup: The parsed HTML document.

        Returns:
            The document with margin optimization CSS injected.
        """
        css_rules: list[str] = []

        # Collapse excessive margins on common elements
        css_rules.append(self._margin_collapse_css())

        # Ensure first child in body doesn't have top margin
        css_rules.append(self._first_last_margin_css())

        if css_rules:
            css_text = "\n".join(css_rules)
            self._inject_css(soup, css_text)

        return soup

    def _margin_collapse_css(self) -> str:
        """Generate CSS to collapse excessive inter-element margins."""
        return (
            "/* Normalize excessive margins for PDF */\n"
            "h1, h2, h3, h4, h5, h6 {\n"
            "  margin-top: 1.2em;\n"
            "  margin-bottom: 0.4em;\n"
            "}\n"
            "p {\n"
            "  margin-top: 0;\n"
            "  margin-bottom: 0.8em;\n"
            "}\n"
            "ul, ol {\n"
            "  margin-top: 0;\n"
            "  margin-bottom: 0.8em;\n"
            "}\n"
            "table {\n"
            "  margin-top: 0.5em;\n"
            "  margin-bottom: 1em;\n"
            "}"
        )

    def _first_last_margin_css(self) -> str:
        """Remove top margin from first body child, bottom from last."""
        return (
            "body > *:first-child {\n"
            "  margin-top: 0;\n"
            "}\n"
            "body > *:last-child {\n"
            "  margin-bottom: 0;\n"
            "}"
        )

    def _inject_css(self, soup: BeautifulSoup, css_text: str) -> None:
        """Inject CSS into the document's <head>."""
        head = soup.find("head")
        if head is None:
            head = soup.new_tag("head")
            if soup.html:
                soup.html.insert(0, head)
            else:
                soup.insert(0, head)

        style_tag = soup.new_tag("style", attrs={"data-html2pdf": "margins"})
        style_tag.string = css_text
        head.append(style_tag)
