"""Font normalization and adjustment.

Detects system font fallbacks, injects @font-face declarations for
web-safe fonts, and adjusts font-size/line-height based on configuration.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from bs4 import BeautifulSoup

from html2pdf.preprocessor.sanitizer import CSSSanitizer

if TYPE_CHECKING:
    from html2pdf.core.config import PDFConfig

# Default base font size in pt
DEFAULT_BASE_FONT_SIZE_PT = 12
DEFAULT_LINE_HEIGHT_RATIO = 1.5

# Common system font stacks for cross-platform consistency
SAFE_FONT_STACKS = {
    "sans-serif": (
        '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, '
        '"Helvetica Neue", Arial, sans-serif'
    ),
    "serif": 'Georgia, "Times New Roman", Times, serif',
    "monospace": (
        'ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, '
        '"Liberation Mono", monospace'
    ),
}


class FontNormalizer:
    """Normalizes fonts for consistent cross-platform PDF rendering.

    Args:
        config: PDFConfig instance for font adjustment settings.
    """

    def __init__(self, config: PDFConfig) -> None:
        self.config = config
        self._sanitizer = CSSSanitizer()

    def apply(self, soup: BeautifulSoup) -> BeautifulSoup:
        """Apply font normalization to the document.

        If font_adjustment is disabled in config, returns the soup unchanged.

        Args:
            soup: The parsed HTML document.

        Returns:
            The document with font normalization CSS injected.
        """
        if not self.config.font_adjustment:
            return soup

        css_rules: list[str] = []

        # Inject base font normalization
        css_rules.append(self._base_font_css())

        # Inject monospace normalization for code blocks
        css_rules.append(self._code_font_css())

        if css_rules:
            css_text = "\n".join(css_rules)
            self._inject_css(soup, css_text)

        return soup

    def _base_font_css(self) -> str:
        """Generate base body font CSS."""
        return (
            "body {\n"
            f"  font-family: {SAFE_FONT_STACKS['sans-serif']};\n"
            f"  font-size: {DEFAULT_BASE_FONT_SIZE_PT}pt;\n"
            f"  line-height: {DEFAULT_LINE_HEIGHT_RATIO};\n"
            "}"
        )

    def _code_font_css(self) -> str:
        """Generate code/pre font CSS."""
        return (
            "pre, code, kbd, samp {\n"
            f"  font-family: {SAFE_FONT_STACKS['monospace']};\n"
            "}"
        )

    def _inject_css(self, soup: BeautifulSoup, css_text: str) -> None:
        """Inject CSS into the document's <head>."""
        head = soup.find("head")
        if head is None:
            head = soup.new_tag("head")
            if soup.html:
                soup.html.insert(0, head)
            else:
                soup.insert(0, head)

        style_tag = soup.new_tag("style", attrs={"data-html2pdf": "fonts"})
        style_tag.string = css_text
        head.append(style_tag)
