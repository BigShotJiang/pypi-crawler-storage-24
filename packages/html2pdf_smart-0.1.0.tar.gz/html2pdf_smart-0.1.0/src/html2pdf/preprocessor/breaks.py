"""Page break injection engine.

Three strategies:
    - "smart" (default): Full heuristic analysis, injects page break
      directives based on DOM analysis and pattern detection.
    - "css-only": Respects existing CSS paged media directives only.
    - "none": Strips all page break CSS. Let Chromium decide everything.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from bs4 import BeautifulSoup, Tag

from html2pdf.analyzer.detector import PatternDetector
from html2pdf.preprocessor.sanitizer import CSSSanitizer

if TYPE_CHECKING:
    from html2pdf.analyzer.dom import DOMAnalysis
    from html2pdf.core.config import PDFConfig


class BreakInjector:
    """Injects page break CSS directives based on DOM analysis.

    Args:
        config: PDFConfig instance with break_strategy setting.
        analysis: DOMAnalysis result from the analyzer.
    """

    def __init__(self, config: PDFConfig, analysis: DOMAnalysis) -> None:
        self.config = config
        self.analysis = analysis
        self._sanitizer = CSSSanitizer()

    def apply(self, soup: BeautifulSoup) -> BeautifulSoup:
        """Apply page break strategy to the document.

        Args:
            soup: The parsed HTML document.

        Returns:
            The document with page break CSS injected (if strategy is "smart").
        """
        strategy = self.config.break_strategy

        if strategy == "none":
            self._strip_break_css(soup)
            return soup

        if strategy == "css-only":
            # Don't touch anything — respect existing CSS only
            return soup

        # "smart" strategy
        return self._apply_smart_breaks(soup)

    def _apply_smart_breaks(self, soup: BeautifulSoup) -> BeautifulSoup:
        """Apply intelligent page break rules based on pattern detection."""
        detector = PatternDetector(self.analysis)
        patterns = detector.detect()
        nodes = self.analysis.nodes
        css_rules: list[str] = []

        # Rule 1: Keep heading + first-paragraph pairs together
        for pair in patterns.keep_together_pairs:
            if pair.heading_index < len(nodes):
                heading_el = nodes[pair.heading_index].element
                self._add_inline_style(heading_el, "page-break-after: avoid")
            if pair.content_index < len(nodes):
                content_el = nodes[pair.content_index].element
                self._add_inline_style(content_el, "page-break-before: avoid")

        # Rule 2: Never break inside table rows
        css_rules.append(
            "tr {\n"
            "  page-break-inside: avoid;\n"
            "}"
        )

        # Rule 3: Prefer breaks before h1-h3 (not at page top)
        css_rules.append(
            "h1, h2, h3 {\n"
            "  page-break-after: avoid;\n"
            "}"
        )

        # Rule 4: Handle orphans and widows via CSS
        css_rules.append(
            "p, li, dd {\n"
            "  orphans: 2;\n"
            "  widows: 2;\n"
            "}"
        )

        # Rule 5: Protect code blocks from breaking
        for block in patterns.protected_blocks:
            if block.node_index < len(nodes):
                code_el = nodes[block.node_index].element
                self._add_inline_style(code_el, "page-break-inside: avoid")

        # Rule 6: For large tables, allow breaks between rows but repeat thead
        for table in patterns.large_tables:
            if table.node_index < len(nodes):
                table_el = nodes[table.node_index].element
                thead = table_el.find("thead")
                if thead and isinstance(thead, Tag):
                    self._add_inline_style(thead, "display: table-header-group")

        # Inject collected CSS rules
        if css_rules:
            css_text = "\n".join(css_rules)
            self._inject_css(soup, css_text)

        return soup

    def _strip_break_css(self, soup: BeautifulSoup) -> None:
        """Remove all page break CSS from the document (for 'none' strategy)."""
        # Remove page-break-* from inline styles
        for tag in soup.find_all(True):
            if not isinstance(tag, Tag):
                continue
            style = tag.get("style", "")
            if isinstance(style, str) and "page-break" in style:
                # Strip page-break declarations from inline style
                cleaned = ";".join(
                    decl
                    for decl in style.split(";")
                    if "page-break" not in decl and "break-" not in decl
                )
                if cleaned.strip():
                    tag["style"] = cleaned
                elif "style" in tag.attrs:
                    del tag["style"]

    def _add_inline_style(self, element: Tag, declaration: str) -> None:
        """Append a CSS declaration to an element's inline style.

        Args:
            element: The BS4 Tag to modify.
            declaration: CSS declaration (e.g., "page-break-after: avoid").
        """
        # Validate through sanitizer
        prop, _, value = declaration.partition(":")
        if not self._sanitizer.validate_property(prop.strip(), value.strip()):
            return

        existing = element.get("style", "")
        if isinstance(existing, list):
            existing = ";".join(existing)
        if existing and not existing.rstrip().endswith(";"):
            existing += "; "
        element["style"] = existing + declaration

    def _inject_css(self, soup: BeautifulSoup, css_text: str) -> None:
        """Inject CSS into the document's <head>."""
        head = soup.find("head")
        if head is None:
            head = soup.new_tag("head")
            if soup.html:
                soup.html.insert(0, head)
            else:
                soup.insert(0, head)

        style_tag = soup.new_tag("style", attrs={"data-html2pdf": "breaks"})
        style_tag.string = css_text
        head.append(style_tag)
