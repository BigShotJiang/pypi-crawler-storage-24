"""Pre-processing pipeline orchestrator.

Runs all pre-processing steps in the correct order:
    1. FontNormalizer — normalize fonts for cross-platform consistency
    2. MarginOptimizer — collapse excessive margins
    3. BreakInjector — inject intelligent page breaks
    4. CSSSanitizer — validate all injected CSS (final pass)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol

from bs4 import BeautifulSoup

from html2pdf.preprocessor.breaks import BreakInjector
from html2pdf.preprocessor.fonts import FontNormalizer
from html2pdf.preprocessor.margins import MarginOptimizer

if TYPE_CHECKING:
    from html2pdf.analyzer.dom import DOMAnalysis
    from html2pdf.core.config import PDFConfig


class PreProcessorStep(Protocol):
    """Protocol for pre-processor pipeline steps."""

    def apply(self, soup: BeautifulSoup) -> BeautifulSoup:
        """Apply this pre-processing step to the document."""
        ...


class PreProcessorPipeline:
    """Orchestrates the pre-processing pipeline.

    Runs each step in sequence on the parsed HTML document.
    The pipeline is deterministic: same input + same config = same output.

    Args:
        config: PDFConfig for the conversion.
        analysis: DOMAnalysis from the analyzer stage.
    """

    def __init__(self, config: PDFConfig, analysis: DOMAnalysis) -> None:
        self.config = config
        self.analysis = analysis
        self.steps: list[PreProcessorStep] = [
            FontNormalizer(config),
            MarginOptimizer(config),
            BreakInjector(config, analysis),
        ]

    def process(self, soup: BeautifulSoup) -> BeautifulSoup:
        """Run all pre-processing steps on the document.

        Args:
            soup: The parsed HTML document.

        Returns:
            The pre-processed document ready for rendering.
        """
        for step in self.steps:
            soup = step.apply(soup)
        return soup
