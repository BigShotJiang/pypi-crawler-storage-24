"""Browser instance management and pooling.

Manages Playwright browser instances for concurrent PDF conversions.
Lazy browser launch — Chromium is only started on the first conversion.
"""

from __future__ import annotations

import asyncio
import contextlib
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from html2pdf.core.exceptions import BrowserPoolError, RenderError

try:
    from playwright.async_api import (
        Browser,
        BrowserContext,
        Page,
        Playwright,
        async_playwright,
    )
except ImportError as e:
    raise ImportError(
        "Playwright is required for html2pdf rendering. "
        "Install it with: pip install playwright && playwright install chromium"
    ) from e


class BrowserPool:
    """Manages a pool of Playwright browser contexts for PDF rendering.

    The pool lazily launches a single Chromium browser instance and
    creates isolated browser contexts for each conversion. A semaphore
    limits concurrent conversions.

    Args:
        pool_size: Maximum concurrent browser contexts (default: 3).
    """

    def __init__(self, pool_size: int = 3) -> None:
        self._pool_size = pool_size
        self._semaphore = asyncio.Semaphore(pool_size)
        self._playwright: Playwright | None = None
        self._browser: Browser | None = None
        self._lock = asyncio.Lock()

    async def _ensure_browser(self) -> Browser:
        """Lazily launch the browser on first use.

        Returns:
            The shared Browser instance.

        Raises:
            RenderError: If browser launch fails.
        """
        if self._browser is not None and self._browser.is_connected():
            return self._browser

        async with self._lock:
            # Double-check after acquiring lock
            if self._browser is not None and self._browser.is_connected():
                return self._browser

            try:
                self._playwright = await async_playwright().start()
                self._browser = await self._playwright.chromium.launch(
                    headless=True,
                    args=[
                        "--disable-gpu",
                        "--disable-dev-shm-usage",
                        "--no-sandbox",
                    ],
                )
                return self._browser
            except Exception as e:
                raise RenderError(
                    f"Failed to launch Chromium browser: {e}. "
                    "Ensure Chromium is installed: playwright install chromium"
                ) from e

    @asynccontextmanager
    async def acquire_page(self) -> AsyncIterator[Page]:
        """Acquire a browser page from the pool.

        Uses a semaphore to limit concurrent contexts. Each caller
        gets a fresh browser context and page, which are automatically
        cleaned up on exit.

        Yields:
            A fresh Playwright Page ready for use.

        Raises:
            BrowserPoolError: If context/page acquisition times out.
        """
        try:
            await asyncio.wait_for(self._semaphore.acquire(), timeout=30.0)
        except asyncio.TimeoutError as e:
            raise BrowserPoolError(
                f"Timed out waiting for browser context "
                f"(pool size: {self._pool_size})"
            ) from e

        context: BrowserContext | None = None
        try:
            browser = await self._ensure_browser()
            context = await browser.new_context()
            page = await context.new_page()
            yield page
        except (RenderError, BrowserPoolError):
            raise
        except Exception as e:
            raise RenderError(f"Browser context error: {e}") from e
        finally:
            if context is not None:
                with contextlib.suppress(Exception):
                    await context.close()
            self._semaphore.release()

    async def close(self) -> None:
        """Shut down the browser and Playwright.

        Safe to call multiple times. Closes all contexts and the
        browser instance, then stops Playwright.
        """
        if self._browser is not None:
            with contextlib.suppress(Exception):
                await self._browser.close()
            self._browser = None

        if self._playwright is not None:
            with contextlib.suppress(Exception):
                await self._playwright.stop()
            self._playwright = None

    @property
    def is_ready(self) -> bool:
        """Check if the browser is launched and connected."""
        return self._browser is not None and self._browser.is_connected()

    async def __aenter__(self) -> BrowserPool:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
