"""Playwright Chromium PDF generation backend.

Renders pre-processed HTML to PDF bytes using Playwright's page.pdf() API.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from html2pdf.core.exceptions import RenderError
from html2pdf.renderer.browser_pool import BrowserPool

if TYPE_CHECKING:
    from html2pdf.core.config import PDFConfig


class PlaywrightRenderer:
    """Renders HTML to PDF using Playwright's Chromium browser.

    Manages a BrowserPool for concurrent rendering. The browser is
    lazily launched on the first render() call.

    Args:
        pool_size: Maximum concurrent conversions (default: 1 for library use).
    """

    def __init__(self, pool_size: int = 1) -> None:
        self._pool = BrowserPool(pool_size=pool_size)

    async def render(self, html: str, config: PDFConfig) -> bytes:
        """Render pre-processed HTML to PDF bytes.

        Args:
            html: The pre-processed HTML string.
            config: PDFConfig with rendering parameters.

        Returns:
            PDF file contents as bytes.

        Raises:
            RenderError: If PDF generation fails.
        """
        try:
            async with self._pool.acquire_page() as page:
                await page.set_content(html, wait_until="networkidle")
                pdf_bytes = await page.pdf(
                    format=config.page_size,
                    margin={
                        "top": config.margin_top,
                        "bottom": config.margin_bottom,
                        "left": config.margin_left,
                        "right": config.margin_right,
                    },
                    print_background=config.print_background,
                    scale=config.scale,
                    landscape=config.landscape,
                    display_header_footer=bool(
                        config.header_template or config.footer_template
                    ),
                    header_template=config.header_template or "",
                    footer_template=config.footer_template or "",
                )
                return pdf_bytes
        except RenderError:
            raise
        except Exception as e:
            raise RenderError(f"PDF rendering failed: {e}") from e

    async def close(self) -> None:
        """Shut down the renderer and release browser resources."""
        await self._pool.close()

    async def __aenter__(self) -> PlaywrightRenderer:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
