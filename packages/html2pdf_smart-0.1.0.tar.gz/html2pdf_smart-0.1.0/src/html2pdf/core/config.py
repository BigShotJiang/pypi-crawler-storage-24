"""PDFConfig — frozen dataclass for conversion configuration.

Config resolution order:
    function kwargs → config file → env vars (HTML2PDF_*) → frozen defaults

Config file locations (checked in order, first found wins):
    1. Path passed explicitly (--config or config_path=)
    2. ./html2pdf.toml in current working directory
    3. pyproject.toml section [tool.html2pdf] in cwd
    4. ~/.config/html2pdf/config.toml (user-level defaults)
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import Any

from html2pdf.core.exceptions import ConfigError

# Break strategy literals
BREAK_STRATEGIES = frozenset({"smart", "css-only", "none"})

# Page size literals supported by Playwright
PAGE_SIZES = frozenset({
    "A0", "A1", "A2", "A3", "A4", "A5", "A6",
    "Letter", "Legal", "Tabloid", "Ledger",
})


@dataclass(frozen=True)
class PDFConfig:
    """Immutable configuration for HTML-to-PDF conversion.

    All fields have sensible defaults. Override via kwargs, config files,
    or HTML2PDF_* environment variables.
    """

    page_size: str = "A4"
    margin_top: str = "20mm"
    margin_bottom: str = "20mm"
    margin_left: str = "15mm"
    margin_right: str = "15mm"
    break_strategy: str = "smart"
    font_adjustment: bool = True
    header_template: str | None = None
    footer_template: str | None = None
    print_background: bool = True
    scale: float = 1.0
    landscape: bool = False
    config_path: str | None = field(default=None, repr=False)

    def __post_init__(self) -> None:
        """Validate field values after initialization."""
        if self.page_size not in PAGE_SIZES:
            raise ConfigError(
                f"Invalid page_size '{self.page_size}'. "
                f"Must be one of: {', '.join(sorted(PAGE_SIZES))}"
            )
        if self.break_strategy not in BREAK_STRATEGIES:
            raise ConfigError(
                f"Invalid break_strategy '{self.break_strategy}'. "
                f"Must be one of: {', '.join(sorted(BREAK_STRATEGIES))}"
            )
        if not (0.1 <= self.scale <= 2.0):
            raise ConfigError(
                f"Invalid scale {self.scale}. Must be between 0.1 and 2.0."
            )

    def replace(self, **overrides: Any) -> PDFConfig:
        """Return a new PDFConfig with the given fields replaced.

        Args:
            **overrides: Field names and their new values.

        Returns:
            A new PDFConfig instance with the overrides applied.

        Raises:
            ConfigError: If an override key is not a valid PDFConfig field.
        """
        valid_fields = {f.name for f in fields(self)}
        invalid_keys = set(overrides.keys()) - valid_fields
        if invalid_keys:
            raise ConfigError(
                f"Unknown config fields: {', '.join(sorted(invalid_keys))}"
            )
        current = {f.name: getattr(self, f.name) for f in fields(self)}
        current.update(overrides)
        return PDFConfig(**current)

    @classmethod
    def from_env(cls) -> dict[str, Any]:
        """Read configuration overrides from HTML2PDF_* environment variables.

        Returns:
            Dict of field name → value for any HTML2PDF_* env vars that map
            to PDFConfig fields.
        """
        prefix = "HTML2PDF_"
        valid_fields = {f.name: f for f in fields(cls)}
        overrides: dict[str, Any] = {}

        for key, value in os.environ.items():
            if not key.startswith(prefix):
                continue
            field_name = key[len(prefix):].lower()
            if field_name not in valid_fields:
                continue

            f = valid_fields[field_name]
            overrides[field_name] = _coerce_env_value(value, f.type)

        return overrides

    @classmethod
    def from_file(cls, path: Path) -> dict[str, Any]:
        """Read configuration overrides from a TOML file.

        Supports both standalone html2pdf.toml and pyproject.toml
        with a [tool.html2pdf] section.

        Args:
            path: Path to the TOML configuration file.

        Returns:
            Dict of field name → value.

        Raises:
            ConfigError: If the file cannot be read or parsed.
        """
        try:
            import tomllib
        except ModuleNotFoundError:
            try:
                import tomli as tomllib
            except ModuleNotFoundError as e:
                raise ConfigError(
                    "TOML support requires Python 3.11+ or the 'tomli' package."
                ) from e

        try:
            with open(path, "rb") as f:
                data = tomllib.load(f)
        except FileNotFoundError as e:
            raise ConfigError(f"Config file not found: {path}") from e
        except Exception as e:
            raise ConfigError(f"Failed to parse config file {path}: {e}") from e

        # If it's a pyproject.toml, extract [tool.html2pdf]
        if path.name == "pyproject.toml":
            data = data.get("tool", {}).get("html2pdf", {})

        # Filter to valid fields only
        valid_fields = {f.name for f in fields(cls)}
        return {k: v for k, v in data.items() if k in valid_fields}

    @classmethod
    def resolve(cls, config_path: str | None = None, **kwargs: Any) -> PDFConfig:
        """Build a PDFConfig by merging all config sources.

        Resolution order (later wins):
            frozen defaults → env vars → config file → kwargs

        Args:
            config_path: Explicit path to a config file.
            **kwargs: Direct field overrides (highest priority).

        Returns:
            A fully resolved PDFConfig instance.
        """
        # Start with env vars
        merged: dict[str, Any] = cls.from_env()

        # Layer config file on top
        file_path = _find_config_file(config_path)
        if file_path is not None:
            file_overrides = cls.from_file(file_path)
            merged.update(file_overrides)

        # Layer explicit kwargs on top (highest priority)
        # Filter out None values so callers can pass optional params
        explicit = {k: v for k, v in kwargs.items() if v is not None}
        merged.update(explicit)

        return cls(**merged)


def _coerce_env_value(value: str, type_hint: Any) -> Any:
    """Coerce a string environment variable to the appropriate Python type."""
    type_str = str(type_hint)
    if "bool" in type_str:
        return value.lower() in ("true", "1", "yes")
    if "float" in type_str:
        return float(value)
    if "int" in type_str:
        return int(value)
    return value


def _find_config_file(explicit_path: str | None = None) -> Path | None:
    """Locate the first available config file.

    Search order:
        1. Explicit path (if provided)
        2. ./html2pdf.toml
        3. ./pyproject.toml (only if it contains [tool.html2pdf])
        4. ~/.config/html2pdf/config.toml
    """
    if explicit_path is not None:
        p = Path(explicit_path)
        if p.exists():
            return p
        raise ConfigError(f"Specified config file not found: {explicit_path}")

    # CWD candidates
    cwd = Path.cwd()
    local_toml = cwd / "html2pdf.toml"
    if local_toml.exists():
        return local_toml

    pyproject = cwd / "pyproject.toml"
    if pyproject.exists():
        # Only use if it actually has our section
        try:
            import tomllib
        except ModuleNotFoundError:
            try:
                import tomli as tomllib
            except ModuleNotFoundError:
                return None
        try:
            with open(pyproject, "rb") as f:
                data = tomllib.load(f)
            if "html2pdf" in data.get("tool", {}):
                return pyproject
        except Exception:
            pass

    # User-level config
    user_config = Path.home() / ".config" / "html2pdf" / "config.toml"
    if user_config.exists():
        return user_config

    return None
