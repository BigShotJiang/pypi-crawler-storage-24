"""Custom exception hierarchy for html2pdf.

All public exceptions inherit from HTML2PDFError so callers can
catch the base class for broad error handling or specific subclasses
for targeted recovery.
"""


class HTML2PDFError(Exception):
    """Base exception for all html2pdf errors."""


class ConfigError(HTML2PDFError):
    """Raised when configuration is invalid or cannot be resolved."""


class AnalysisError(HTML2PDFError):
    """Raised when DOM analysis fails on the input HTML."""


class PreProcessorError(HTML2PDFError):
    """Raised when the pre-processing pipeline encounters an error."""


class RenderError(HTML2PDFError):
    """Raised when Playwright PDF rendering fails."""


class BrowserPoolError(RenderError):
    """Raised when the browser pool cannot acquire a context."""
