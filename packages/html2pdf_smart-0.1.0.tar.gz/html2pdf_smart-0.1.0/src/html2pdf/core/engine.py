"""Conversion engine — ties analyzer + preprocessor + renderer.

The ConversionEngine is the core orchestrator. It takes raw HTML,
runs it through analysis and pre-processing, then renders to PDF
via Playwright.
"""

from __future__ import annotations

from typing import Any

from bs4 import BeautifulSoup

from html2pdf.analyzer.dom import DOMAnalyzer
from html2pdf.core.config import PDFConfig
from html2pdf.core.exceptions import HTML2PDFError
from html2pdf.preprocessor.pipeline import PreProcessorPipeline
from html2pdf.renderer.playwright_backend import PlaywrightRenderer


class ConversionEngine:
    """Orchestrates the full HTML → PDF conversion pipeline.

    Pipeline:
        HTML string → BS4 parse → DOM analysis → pre-processing → Playwright render → PDF bytes

    Args:
        config: Base PDFConfig. Per-conversion overrides can be passed to convert().
        pool_size: Browser pool size for concurrent rendering.
    """

    def __init__(
        self,
        config: PDFConfig | None = None,
        pool_size: int = 1,
    ) -> None:
        self.config = config or PDFConfig()
        self._renderer = PlaywrightRenderer(pool_size=pool_size)

    async def convert(self, html: str, **overrides: Any) -> bytes:
        """Convert an HTML string to PDF bytes.

        Args:
            html: Raw HTML content.
            **overrides: PDFConfig field overrides for this conversion.

        Returns:
            PDF file contents as bytes.

        Raises:
            HTML2PDFError: If any stage of conversion fails.
        """
        try:
            # Resolve config with any per-call overrides
            config = self._resolve_config(overrides)

            # Parse HTML
            soup = BeautifulSoup(html, "lxml")

            # Analyze DOM structure
            analysis = DOMAnalyzer.analyze(soup)

            # Pre-process for optimal page breaks
            pipeline = PreProcessorPipeline(config, analysis)
            processed = pipeline.process(soup)

            # Render to PDF via Playwright
            return await self._renderer.render(str(processed), config)
        except HTML2PDFError:
            raise
        except Exception as e:
            raise HTML2PDFError(f"Conversion failed: {e}") from e

    def _resolve_config(self, overrides: dict[str, Any]) -> PDFConfig:
        """Merge per-call overrides into the base config.

        Args:
            overrides: Field overrides from convert() kwargs.

        Returns:
            A new PDFConfig with overrides applied.
        """
        if not overrides:
            return self.config
        # Filter out None values
        explicit = {k: v for k, v in overrides.items() if v is not None}
        if not explicit:
            return self.config
        return self.config.replace(**explicit)

    async def close(self) -> None:
        """Shut down the renderer and release resources."""
        await self._renderer.close()

    async def __aenter__(self) -> ConversionEngine:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
