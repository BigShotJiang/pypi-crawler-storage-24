"""html2pdf — Intelligent HTML-to-PDF conversion with layout pre-processing.

Public API:
    convert(html, **kwargs) -> bytes       Synchronous conversion
    async_convert(html, **kwargs) -> bytes  Async conversion
    convert_file(path, output, **kwargs) -> Path  File-based conversion
    async_convert_batch(items, **kwargs) -> list[tuple]  Async batch (single browser)
    convert_batch(items, **kwargs) -> list[tuple]        Sync batch (single browser)
    PDFConfig                              Configuration dataclass
"""

from __future__ import annotations

import warnings
from pathlib import Path

__version__ = "0.1.0"


def _check_playwright_browser() -> None:
    """Emit a one-time warning if Playwright's Chromium browser is not installed."""
    try:
        from playwright._impl._driver import compute_driver_executable  # type: ignore[import-untyped]

        driver = compute_driver_executable()
        # If the driver exists, Playwright is at least installed.
        # The actual chromium check happens at launch time — this is a
        # best-effort early hint so users don't hit a cryptic error later.
        if not Path(driver).exists():
            raise FileNotFoundError
    except Exception:
        warnings.warn(
            "Playwright Chromium browser not detected. "
            "Run 'playwright install chromium' to complete html2pdf-smart setup.",
            stacklevel=2,
        )


_check_playwright_browser()

from html2pdf.core.config import PDFConfig
from html2pdf.core.exceptions import (
    AnalysisError,
    BrowserPoolError,
    ConfigError,
    HTML2PDFError,
    PreProcessorError,
    RenderError,
)

__all__ = [
    "__version__",
    "PDFConfig",
    "HTML2PDFError",
    "ConfigError",
    "AnalysisError",
    "PreProcessorError",
    "RenderError",
    "BrowserPoolError",
    "convert",
    "async_convert",
    "convert_file",
    "async_convert_batch",
    "convert_batch",
]


async def async_convert(html: str, **kwargs: object) -> bytes:
    """Convert an HTML string to PDF bytes asynchronously.

    Args:
        html: The HTML content to convert.
        **kwargs: PDFConfig field overrides.

    Returns:
        PDF file contents as bytes.
    """
    from html2pdf.core.engine import ConversionEngine

    engine = ConversionEngine()
    return await engine.convert(html, **kwargs)


def convert(html: str, **kwargs: object) -> bytes:
    """Convert an HTML string to PDF bytes (synchronous wrapper).

    Args:
        html: The HTML content to convert.
        **kwargs: PDFConfig field overrides.

    Returns:
        PDF file contents as bytes.
    """
    import asyncio

    return asyncio.run(async_convert(html, **kwargs))


def convert_file(
    path: str | Path,
    output: str | Path | None = None,
    **kwargs: object,
) -> Path:
    """Convert an HTML file to PDF.

    Args:
        path: Path to the input HTML file.
        output: Path for the output PDF. Defaults to input path with .pdf extension.
        **kwargs: PDFConfig field overrides.

    Returns:
        Path to the generated PDF file.
    """
    input_path = Path(path) if not isinstance(path, Path) else path
    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {path}")

    html = input_path.read_text(encoding="utf-8")
    pdf_bytes = convert(html, **kwargs)

    if output is None:
        output_path = input_path.with_suffix(".pdf")
    else:
        output_path = Path(output) if not isinstance(output, Path) else output

    output_path.write_bytes(pdf_bytes)
    return output_path


async def async_convert_batch(
    items: list[tuple[str, str | Path | None]],
    **kwargs: object,
) -> list[tuple[str | Path | None, bytes | None, str | None]]:
    """Convert multiple HTML strings to PDF using a single browser instance.

    This avoids launching a new Chromium process for each conversion,
    which is significantly faster for batch workloads.

    Args:
        items: List of (html_content, output_path_or_label) tuples.
            The second element is used only for labeling results; it
            can be a Path, a string label, or None.
        **kwargs: PDFConfig field overrides applied to every conversion.

    Returns:
        List of (label, pdf_bytes_or_None, error_message_or_None) tuples.
        On success: (label, bytes, None). On failure: (label, None, error_str).
    """
    from html2pdf.core.engine import ConversionEngine

    results: list[tuple[str | Path | None, bytes | None, str | None]] = []

    async with ConversionEngine() as engine:
        for html, label in items:
            try:
                pdf_bytes = await engine.convert(html, **kwargs)
                results.append((label, pdf_bytes, None))
            except Exception as e:
                results.append((label, None, str(e)))

    return results


def convert_batch(
    items: list[tuple[str, str | Path | None]],
    **kwargs: object,
) -> list[tuple[str | Path | None, bytes | None, str | None]]:
    """Convert multiple HTML strings to PDF using a single browser instance (sync).

    Synchronous wrapper around async_convert_batch(). Launches Chromium
    once for the entire batch instead of once per file.

    Args:
        items: List of (html_content, output_path_or_label) tuples.
        **kwargs: PDFConfig field overrides applied to every conversion.

    Returns:
        List of (label, pdf_bytes_or_None, error_message_or_None) tuples.
    """
    import asyncio

    return asyncio.run(async_convert_batch(items, **kwargs))
