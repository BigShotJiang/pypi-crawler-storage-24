"""Pattern detection — tables, lists, code blocks, images.

Identifies structural patterns that the pre-processor needs to
handle specially for intelligent page break injection.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from html2pdf.analyzer.dom import DOMAnalysis

# Thresholds
ORPHAN_THRESHOLD_CHARS = 80  # < 80 chars ≈ < 2 lines
WIDOW_THRESHOLD_CHARS = 80
CODE_BLOCK_MAX_LINES_NO_BREAK = 40  # don't break code blocks under 40 lines
DEFAULT_PAGE_HEIGHT_MM = 257.0  # A4 content area height


@dataclass
class KeepTogetherPair:
    """A heading and its following content that should not be separated."""

    heading_index: int
    content_index: int


@dataclass
class LargeTable:
    """A table that spans more than one estimated page."""

    node_index: int
    estimated_height_mm: float


@dataclass
class OrphanCandidate:
    """An element at the end of a section with very little content."""

    node_index: int
    text_length: int


@dataclass
class WidowCandidate:
    """An element at the start of a section with very little content."""

    node_index: int
    text_length: int


@dataclass
class ProtectedBlock:
    """A code block or similar element that should not be broken."""

    node_index: int
    estimated_height_mm: float


@dataclass
class DetectionResult:
    """All detected patterns in the document.

    The pre-processor consumes these to decide where and how to
    inject page break CSS directives.
    """

    keep_together_pairs: list[KeepTogetherPair] = field(default_factory=list)
    large_tables: list[LargeTable] = field(default_factory=list)
    orphan_candidates: list[OrphanCandidate] = field(default_factory=list)
    widow_candidates: list[WidowCandidate] = field(default_factory=list)
    protected_blocks: list[ProtectedBlock] = field(default_factory=list)


class PatternDetector:
    """Detects structural patterns that need special page break handling.

    Args:
        analysis: The DOMAnalysis result from DOMAnalyzer.
        page_height_mm: Content area height per page for size comparisons.
    """

    def __init__(
        self,
        analysis: DOMAnalysis,
        page_height_mm: float = DEFAULT_PAGE_HEIGHT_MM,
    ) -> None:
        self.analysis = analysis
        self.page_height_mm = page_height_mm

    def detect(self) -> DetectionResult:
        """Run all pattern detections and return the combined result.

        Returns:
            DetectionResult with all detected patterns.
        """
        return DetectionResult(
            keep_together_pairs=self._detect_keep_together(),
            large_tables=self._detect_large_tables(),
            orphan_candidates=self._detect_orphans(),
            widow_candidates=self._detect_widows(),
            protected_blocks=self._detect_protected_blocks(),
        )

    def _detect_keep_together(self) -> list[KeepTogetherPair]:
        """Find heading + first-content pairs that should stay together.

        A heading immediately followed by a short content element
        (paragraph, list, etc.) should not be separated by a page break.
        """
        pairs: list[KeepTogetherPair] = []
        nodes = self.analysis.nodes

        for heading_idx in self.analysis.heading_positions:
            # Look for the next sibling node (same or lower depth)
            heading_node = nodes[heading_idx]
            for i in range(heading_idx + 1, len(nodes)):
                candidate = nodes[i]
                # Skip deeper-nested children of the heading itself
                if candidate.depth > heading_node.depth + 1:
                    continue
                # If we've gone back to a shallower depth, stop looking
                if candidate.depth <= heading_node.depth and candidate.tag in (
                    "h1", "h2", "h3", "h4", "h5", "h6",
                ):
                    break
                # Found the first content element after the heading
                if candidate.depth >= heading_node.depth:
                    pairs.append(KeepTogetherPair(
                        heading_index=heading_idx,
                        content_index=candidate.index,
                    ))
                    break

        return pairs

    def _detect_large_tables(self) -> list[LargeTable]:
        """Find tables whose estimated height exceeds the page height."""
        large: list[LargeTable] = []
        nodes = self.analysis.nodes

        for table_idx in self.analysis.table_positions:
            table_node = nodes[table_idx]
            if table_node.estimated_height_mm > self.page_height_mm:
                large.append(LargeTable(
                    node_index=table_idx,
                    estimated_height_mm=table_node.estimated_height_mm,
                ))

        return large

    def _detect_orphans(self) -> list[OrphanCandidate]:
        """Find elements at the end of a section with very little content.

        An orphan is the last element of a section that has fewer than
        ~2 lines of text, which would look awkward at the bottom of a page.
        """
        orphans: list[OrphanCandidate] = []
        nodes = self.analysis.nodes

        for i, node in enumerate(nodes):
            # Check if this is the last element before a heading or end of doc
            is_last_before_heading = (
                i + 1 < len(nodes)
                and nodes[i + 1].tag in ("h1", "h2", "h3", "h4", "h5", "h6")
            )
            is_last_in_doc = i == len(nodes) - 1

            if (
                (is_last_before_heading or is_last_in_doc)
                and node.text_length > 0
                and node.text_length < ORPHAN_THRESHOLD_CHARS
            ):
                    orphans.append(OrphanCandidate(
                        node_index=i,
                        text_length=node.text_length,
                    ))

        return orphans

    def _detect_widows(self) -> list[WidowCandidate]:
        """Find elements at the start of a section with very little content.

        A widow is the first element after a heading that has fewer than
        ~2 lines of text, which would look awkward at the top of a page.
        """
        widows: list[WidowCandidate] = []
        nodes = self.analysis.nodes

        for heading_idx in self.analysis.heading_positions:
            # Look at the element right after the heading
            if heading_idx + 1 < len(nodes):
                candidate = nodes[heading_idx + 1]
                if (
                    candidate.tag not in ("h1", "h2", "h3", "h4", "h5", "h6")
                    and 0 < candidate.text_length < WIDOW_THRESHOLD_CHARS
                ):
                    widows.append(WidowCandidate(
                        node_index=candidate.index,
                        text_length=candidate.text_length,
                    ))

        return widows

    def _detect_protected_blocks(self) -> list[ProtectedBlock]:
        """Find code blocks that should not be broken.

        Code blocks (<pre>) shorter than CODE_BLOCK_MAX_LINES_NO_BREAK
        lines should never be split across pages.
        """
        protected: list[ProtectedBlock] = []
        nodes = self.analysis.nodes

        for code_idx in self.analysis.code_block_positions:
            code_node = nodes[code_idx]
            # Estimate line count from text length (avg 60 chars/line in code)
            estimated_lines = max(1, code_node.text_length / 60)
            if estimated_lines <= CODE_BLOCK_MAX_LINES_NO_BREAK:
                protected.append(ProtectedBlock(
                    node_index=code_idx,
                    estimated_height_mm=code_node.estimated_height_mm,
                ))

        return protected
