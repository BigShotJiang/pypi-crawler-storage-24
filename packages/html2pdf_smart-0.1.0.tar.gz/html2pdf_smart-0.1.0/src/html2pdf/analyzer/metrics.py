"""Page estimation and element sizing heuristics.

These heuristics estimate content height without rendering, enabling
the pre-processor to make intelligent page break decisions before
Playwright processes the document.

All measurements are in millimeters to match PDF page dimensions.
"""

from __future__ import annotations

# Typography constants (approximate for standard sans-serif at 12pt)
AVG_CHAR_WIDTH_MM: float = 2.1  # ~2.1mm per character at 12pt
DEFAULT_LINE_HEIGHT_MM: float = 5.0  # ~5mm line height at 12pt
DEFAULT_CONTENT_WIDTH_MM: float = 180.0  # A4 minus default margins

# Element-specific height estimates
HEADING_HEIGHTS_MM: dict[str, float] = {
    "h1": 18.0,  # large heading + margin
    "h2": 14.0,
    "h3": 11.0,
    "h4": 9.0,
    "h5": 7.5,
    "h6": 6.5,
}

DEFAULT_IMAGE_HEIGHT_MM: float = 150.0  # fallback when dimensions unknown
DEFAULT_TABLE_ROW_HEIGHT_MM: float = 8.0  # estimated row height
DEFAULT_HR_HEIGHT_MM: float = 5.0  # horizontal rule + margins
DEFAULT_PARAGRAPH_MARGIN_MM: float = 4.0  # margin between paragraphs


def estimate_element_height(
    tag: str,
    text_length: int,
    child_count: int,
    content_width_mm: float = DEFAULT_CONTENT_WIDTH_MM,
) -> float:
    """Estimate the rendered height of an element in millimeters.

    Args:
        tag: HTML tag name (lowercase).
        text_length: Number of characters of direct text content.
        child_count: Number of direct child elements.
        content_width_mm: Available content width in mm.

    Returns:
        Estimated height in millimeters.
    """
    # Headings: fixed height per level
    if tag in HEADING_HEIGHTS_MM:
        return HEADING_HEIGHTS_MM[tag]

    # Images: default height (could be refined with width/height attrs)
    if tag == "img":
        return DEFAULT_IMAGE_HEIGHT_MM

    # Horizontal rules
    if tag == "hr":
        return DEFAULT_HR_HEIGHT_MM

    # Tables: estimate based on child count (rows)
    if tag == "table":
        # child_count here approximates row count (tbody/thead/tr)
        row_estimate = max(child_count, 1)
        return row_estimate * DEFAULT_TABLE_ROW_HEIGHT_MM

    # Table rows
    if tag == "tr":
        return DEFAULT_TABLE_ROW_HEIGHT_MM

    # Text-bearing elements: estimate from character count
    if text_length > 0:
        chars_per_line = max(1, content_width_mm / AVG_CHAR_WIDTH_MM)
        line_count = max(1, text_length / chars_per_line)
        height = line_count * DEFAULT_LINE_HEIGHT_MM

        # Add paragraph margin for block elements
        if tag in ("p", "div", "li", "dd", "dt", "blockquote"):
            height += DEFAULT_PARAGRAPH_MARGIN_MM

        return height

    # Container elements with no direct text: minimal height
    # (children will contribute their own height)
    return 0.0


def estimate_page_count(
    total_text_length: int,
    table_count: int = 0,
    image_count: int = 0,
    heading_count: int = 0,
    content_height_mm: float = 257.0,
) -> float:
    """Estimate the total number of pages for a document.

    This is a coarse estimate used for progress reporting and
    strategy selection, not for precise break placement.

    Args:
        total_text_length: Total characters in the document.
        table_count: Number of tables.
        image_count: Number of images.
        heading_count: Number of headings.
        content_height_mm: Available content height per page in mm.

    Returns:
        Estimated page count (minimum 1.0).
    """
    # Estimate text height
    chars_per_line = DEFAULT_CONTENT_WIDTH_MM / AVG_CHAR_WIDTH_MM
    total_lines = total_text_length / chars_per_line
    text_height = total_lines * DEFAULT_LINE_HEIGHT_MM

    # Add estimates for non-text elements
    table_height = table_count * (5 * DEFAULT_TABLE_ROW_HEIGHT_MM)  # avg 5 rows
    image_height = image_count * DEFAULT_IMAGE_HEIGHT_MM
    heading_height = heading_count * 12.0  # average heading height

    total_height = text_height + table_height + image_height + heading_height
    pages = total_height / content_height_mm

    return max(1.0, pages)
