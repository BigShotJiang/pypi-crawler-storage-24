"""DOM tree analysis — structure, depth, content density.

Walks the parsed HTML tree once to produce a flat list of DOMNode
objects with structural metadata. This is the primary input to the
pre-processor pipeline.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from bs4 import BeautifulSoup, Tag

from html2pdf.core.exceptions import AnalysisError

# Block-level elements for structure detection
BLOCK_ELEMENTS = frozenset({
    "address", "article", "aside", "blockquote", "details", "dialog",
    "dd", "div", "dl", "dt", "fieldset", "figcaption", "figure",
    "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "header",
    "hgroup", "hr", "li", "main", "nav", "ol", "p", "pre", "section",
    "table", "ul",
})

HEADING_TAGS = frozenset({"h1", "h2", "h3", "h4", "h5", "h6"})


@dataclass
class DOMNode:
    """Represents an analyzed DOM element with structural metadata."""

    tag: str
    depth: int
    text_length: int
    child_count: int
    has_block_children: bool
    estimated_height_mm: float
    classes: list[str]
    element: Tag
    index: int = 0  # position in the flat node list


@dataclass
class DOMAnalysis:
    """Result of analyzing a complete DOM tree.

    Provides the flat node list plus indices into it for key structural
    elements that the pre-processor needs to handle specially.
    """

    nodes: list[DOMNode]
    total_text_length: int = 0
    estimated_pages: float = 0.0
    heading_positions: list[int] = field(default_factory=list)
    table_positions: list[int] = field(default_factory=list)
    image_positions: list[int] = field(default_factory=list)
    code_block_positions: list[int] = field(default_factory=list)
    max_depth: int = 0


class DOMAnalyzer:
    """Analyzes a BeautifulSoup DOM tree to produce structural metadata.

    The analyzer is stateless — call analyze() as a classmethod.
    """

    # Default A4 content area: 210mm - 15mm left - 15mm right = 180mm
    DEFAULT_CONTENT_WIDTH_MM: float = 180.0
    # Default A4 content height: 297mm - 20mm top - 20mm bottom = 257mm
    DEFAULT_CONTENT_HEIGHT_MM: float = 257.0

    @classmethod
    def analyze(cls, soup: BeautifulSoup) -> DOMAnalysis:
        """Analyze a parsed HTML document.

        Args:
            soup: A BeautifulSoup-parsed document.

        Returns:
            A DOMAnalysis with structural metadata.

        Raises:
            AnalysisError: If the document cannot be analyzed.
        """
        try:
            body = soup.find("body")
            root: Tag = body if isinstance(body, Tag) else soup
        except Exception as e:
            raise AnalysisError(f"Failed to locate document root: {e}") from e

        nodes: list[DOMNode] = []
        heading_positions: list[int] = []
        table_positions: list[int] = []
        image_positions: list[int] = []
        code_block_positions: list[int] = []
        total_text_length = 0
        max_depth = 0

        try:
            cls._walk(
                element=root,
                depth=0,
                nodes=nodes,
                heading_positions=heading_positions,
                table_positions=table_positions,
                image_positions=image_positions,
                code_block_positions=code_block_positions,
            )
        except AnalysisError:
            raise
        except Exception as e:
            raise AnalysisError(f"DOM walk failed: {e}") from e

        for node in nodes:
            total_text_length += node.text_length
            if node.depth > max_depth:
                max_depth = node.depth

        estimated_pages = total_text_length / 3000.0 if total_text_length > 0 else 1.0

        return DOMAnalysis(
            nodes=nodes,
            total_text_length=total_text_length,
            estimated_pages=max(1.0, estimated_pages),
            heading_positions=heading_positions,
            table_positions=table_positions,
            image_positions=image_positions,
            code_block_positions=code_block_positions,
            max_depth=max_depth,
        )

    @classmethod
    def _walk(
        cls,
        element: Tag,
        depth: int,
        nodes: list[DOMNode],
        heading_positions: list[int],
        table_positions: list[int],
        image_positions: list[int],
        code_block_positions: list[int],
    ) -> None:
        """Recursively walk the DOM tree, building the flat node list."""
        if not isinstance(element, Tag):
            return

        tag_name = element.name.lower() if element.name else ""

        # Skip non-content tags
        if tag_name in ("script", "style", "meta", "link", "head"):
            return

        # Count direct children
        children = [c for c in element.children if isinstance(c, Tag)]
        child_count = len(children)
        has_block_children = any(
            c.name and c.name.lower() in BLOCK_ELEMENTS for c in children
        )

        # Text length (direct text only, not nested)
        direct_text = element.find_all(string=True, recursive=False)
        text_length = sum(len(t.strip()) for t in direct_text)

        # Classes
        classes = element.get("class", [])
        if isinstance(classes, str):
            classes = classes.split()

        from html2pdf.analyzer.metrics import estimate_element_height

        estimated_height = estimate_element_height(tag_name, text_length, child_count)

        index = len(nodes)
        node = DOMNode(
            tag=tag_name,
            depth=depth,
            text_length=text_length,
            child_count=child_count,
            has_block_children=has_block_children,
            estimated_height_mm=estimated_height,
            classes=list(classes),
            element=element,
            index=index,
        )
        nodes.append(node)

        # Track positions of structural elements
        if tag_name in HEADING_TAGS:
            heading_positions.append(index)
        elif tag_name == "table":
            table_positions.append(index)
        elif tag_name == "img":
            image_positions.append(index)
        elif tag_name in ("pre", "code"):
            # Only track top-level code blocks, not <code> inside <pre>
            parent = element.parent
            if not (tag_name == "code" and parent and parent.name == "pre"):
                code_block_positions.append(index)

        # Recurse into children
        for child in children:
            cls._walk(
                element=child,
                depth=depth + 1,
                nodes=nodes,
                heading_positions=heading_positions,
                table_positions=table_positions,
                image_positions=image_positions,
                code_block_positions=code_block_positions,
            )
