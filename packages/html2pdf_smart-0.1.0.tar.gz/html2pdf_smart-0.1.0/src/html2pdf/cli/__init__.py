"""CLI interface for html2pdf — Click-based command group."""
