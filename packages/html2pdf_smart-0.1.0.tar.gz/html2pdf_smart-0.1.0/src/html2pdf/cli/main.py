"""html2pdf CLI — Click-based command interface.

Commands:
    convert  — Convert a single HTML file, URL, or stdin to PDF
    batch    — Convert a directory of HTML files to PDFs
    version  — Show html2pdf version
    info     — Show runtime information (Chromium version, config path, etc.)

Exit codes:
    0 — Success
    1 — Conversion error
    2 — Configuration error
    3 — Browser/renderer error
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import click

from html2pdf import __version__
from html2pdf.core.config import BREAK_STRATEGIES, PAGE_SIZES, PDFConfig
from html2pdf.core.exceptions import (
    BrowserPoolError,
    ConfigError,
    HTML2PDFError,
    RenderError,
)

# --------------------------------------------------------------------------- #
# Exit codes
# --------------------------------------------------------------------------- #

EXIT_OK = 0
EXIT_CONVERSION = 1
EXIT_CONFIG = 2
EXIT_BROWSER = 3


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #

def _resolve_exit_code(exc: Exception) -> int:
    """Map an exception to the appropriate CLI exit code."""
    if isinstance(exc, ConfigError):
        return EXIT_CONFIG
    if isinstance(exc, (BrowserPoolError, RenderError)):
        return EXIT_BROWSER
    if isinstance(exc, HTML2PDFError):
        return EXIT_CONVERSION
    return EXIT_CONVERSION


def _read_html_from_input(source: str) -> str:
    """Read HTML content from a file path, URL, or stdin placeholder.

    Args:
        source: File path, URL (http:// or https://), or '-' for stdin.

    Returns:
        HTML string.

    Raises:
        click.ClickException: If the source cannot be read.
    """
    # Stdin
    if source == "-":
        content = sys.stdin.read()
        if not content.strip():
            raise click.ClickException("No input received from stdin.")
        return content

    # URL
    if source.startswith(("http://", "https://")):
        return _fetch_url(source)

    # File path
    path = Path(source)
    if not path.exists():
        raise click.ClickException(f"Input file not found: {source}")
    if not path.is_file():
        raise click.ClickException(f"Input is not a file: {source}")
    try:
        return path.read_text(encoding="utf-8")
    except OSError as e:
        raise click.ClickException(f"Cannot read file '{source}': {e}") from e


def _fetch_url(url: str) -> str:
    """Fetch HTML content from a URL via httpx.

    Args:
        url: The URL to fetch.

    Returns:
        HTML string from the response body.

    Raises:
        click.ClickException: If httpx is not installed or the fetch fails.
    """
    try:
        import httpx
    except ImportError as e:
        raise click.ClickException(
            "URL fetching requires httpx. Install with: pip install httpx"
        ) from e

    try:
        resp = httpx.get(url, follow_redirects=True, timeout=30.0)
        resp.raise_for_status()
        return resp.text
    except httpx.HTTPStatusError as e:
        raise click.ClickException(
            f"HTTP {e.response.status_code} fetching '{url}'."
        ) from e
    except httpx.RequestError as e:
        raise click.ClickException(f"Failed to fetch '{url}': {e}") from e


def _build_config_kwargs(
    page_size: str | None,
    landscape: bool,
    margin_top: str | None,
    margin_bottom: str | None,
    margin_left: str | None,
    margin_right: str | None,
    break_strategy: str | None,
    no_background: bool,
    scale: float | None,
    config: str | None,
) -> dict[str, object]:
    """Build kwargs dict for PDFConfig.resolve() from CLI options.

    Only includes options that were explicitly set by the user.
    """
    kwargs: dict[str, object] = {}
    if page_size is not None:
        kwargs["page_size"] = page_size
    if landscape:
        kwargs["landscape"] = True
    if margin_top is not None:
        kwargs["margin_top"] = margin_top
    if margin_bottom is not None:
        kwargs["margin_bottom"] = margin_bottom
    if margin_left is not None:
        kwargs["margin_left"] = margin_left
    if margin_right is not None:
        kwargs["margin_right"] = margin_right
    if break_strategy is not None:
        kwargs["break_strategy"] = break_strategy
    if no_background:
        kwargs["print_background"] = False
    if scale is not None:
        kwargs["scale"] = scale
    return kwargs


# --------------------------------------------------------------------------- #
# Shared click options for PDF configuration
# --------------------------------------------------------------------------- #

def _pdf_options(fn: Any) -> Any:  # noqa: ANN401
    """Decorator that adds common PDF config options to a click command."""
    fn = click.option(
        "--page-size", type=click.Choice(sorted(PAGE_SIZES), case_sensitive=True),
        default=None, help="Page size (default: A4).",
    )(fn)
    fn = click.option(
        "--landscape", is_flag=True, default=False,
        help="Use landscape orientation.",
    )(fn)
    fn = click.option(
        "--margin-top", default=None,
        help="Top margin (e.g., 20mm, 1in). Default: 20mm.",
    )(fn)
    fn = click.option(
        "--margin-bottom", default=None,
        help="Bottom margin. Default: 20mm.",
    )(fn)
    fn = click.option(
        "--margin-left", default=None,
        help="Left margin. Default: 15mm.",
    )(fn)
    fn = click.option(
        "--margin-right", default=None,
        help="Right margin. Default: 15mm.",
    )(fn)
    fn = click.option(
        "--break-strategy",
        type=click.Choice(sorted(BREAK_STRATEGIES), case_sensitive=True),
        default=None, help="Page break strategy (default: smart).",
    )(fn)
    fn = click.option(
        "--no-background", is_flag=True, default=False,
        help="Disable background graphics in the PDF.",
    )(fn)
    fn = click.option(
        "--scale", type=float, default=None,
        help="Scale of the webpage rendering (0.1–2.0). Default: 1.0.",
    )(fn)
    fn = click.option(
        "--config", "config_file", default=None,
        type=click.Path(exists=True, dir_okay=False),
        help="Path to a TOML config file.",
    )(fn)
    return fn


# --------------------------------------------------------------------------- #
# CLI group
# --------------------------------------------------------------------------- #

@click.group()
@click.version_option(__version__, prog_name="html2pdf")
def cli() -> None:
    """html2pdf — Intelligent HTML-to-PDF conversion."""


# --------------------------------------------------------------------------- #
# convert command
# --------------------------------------------------------------------------- #

@cli.command()
@click.argument("input", required=True)
@click.option(
    "-o", "--output", default=None, type=click.Path(dir_okay=False),
    help="Output PDF path. Defaults to <input>.pdf.",
)
@_pdf_options
def convert(
    input: str,
    output: str | None,
    page_size: str | None,
    landscape: bool,
    margin_top: str | None,
    margin_bottom: str | None,
    margin_left: str | None,
    margin_right: str | None,
    break_strategy: str | None,
    no_background: bool,
    scale: float | None,
    config_file: str | None,
) -> None:
    """Convert HTML to PDF.

    INPUT can be a file path, a URL (http:// or https://), or '-' for stdin.

    \b
    Examples:
        html2pdf convert page.html -o page.pdf
        html2pdf convert page.html --page-size Letter --landscape
        html2pdf convert https://example.com -o example.pdf
        cat page.html | html2pdf convert - -o page.pdf
    """
    try:
        html = _read_html_from_input(input)

        config_kwargs = _build_config_kwargs(
            page_size, landscape, margin_top, margin_bottom,
            margin_left, margin_right, break_strategy,
            no_background, scale, config_file,
        )
        cfg = PDFConfig.resolve(config_path=config_file, **config_kwargs)

        from html2pdf import convert as do_convert

        pdf_bytes = do_convert(html, **{
            f.name: getattr(cfg, f.name)
            for f in cfg.__dataclass_fields__.values()
            if f.name != "config_path"
        })

        # Resolve output path
        if output is None:
            if input == "-" or input.startswith(("http://", "https://")):
                raise click.ClickException(
                    "Output path (-o) is required for stdin/URL input."
                )
            output_path = Path(input).with_suffix(".pdf")
        else:
            output_path = Path(output)

        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_bytes(pdf_bytes)

        click.echo(f"Wrote {len(pdf_bytes):,} bytes → {output_path}")

    except click.ClickException:
        raise
    except ConfigError as e:
        raise click.ClickException(str(e)) from e
    except (BrowserPoolError, RenderError) as e:
        click.echo(f"Error: {e}", err=True)
        raise SystemExit(EXIT_BROWSER) from e
    except HTML2PDFError as e:
        click.echo(f"Error: {e}", err=True)
        raise SystemExit(EXIT_CONVERSION) from e
    except Exception as e:
        click.echo(f"Unexpected error: {e}", err=True)
        raise SystemExit(EXIT_CONVERSION) from e


# --------------------------------------------------------------------------- #
# batch command
# --------------------------------------------------------------------------- #

@cli.command()
@click.argument("input_dir", type=click.Path(exists=True, file_okay=False))
@click.option(
    "-o", "--output-dir", default=None, type=click.Path(file_okay=False),
    help="Output directory for PDFs. Defaults to INPUT_DIR.",
)
@click.option(
    "--pattern", default="*.html",
    help="Glob pattern for input files (default: *.html).",
)
@_pdf_options
def batch(
    input_dir: str,
    output_dir: str | None,
    pattern: str,
    page_size: str | None,
    landscape: bool,
    margin_top: str | None,
    margin_bottom: str | None,
    margin_left: str | None,
    margin_right: str | None,
    break_strategy: str | None,
    no_background: bool,
    scale: float | None,
    config_file: str | None,
) -> None:
    """Batch convert a directory of HTML files to PDFs.

    \b
    Examples:
        html2pdf batch ./pages/ -o ./pdfs/
        html2pdf batch ./pages/ --pattern "*.htm" --page-size Letter
    """
    in_path = Path(input_dir)
    out_path = Path(output_dir) if output_dir else in_path
    out_path.mkdir(parents=True, exist_ok=True)

    files = sorted(in_path.glob(pattern))
    if not files:
        raise click.ClickException(
            f"No files matching '{pattern}' found in {input_dir}."
        )

    config_kwargs = _build_config_kwargs(
        page_size, landscape, margin_top, margin_bottom,
        margin_left, margin_right, break_strategy,
        no_background, scale, config_file,
    )

    try:
        cfg = PDFConfig.resolve(config_path=config_file, **config_kwargs)
    except ConfigError as e:
        raise click.ClickException(str(e)) from e

    from html2pdf import convert_batch as do_batch

    config_dict = {
        f.name: getattr(cfg, f.name)
        for f in cfg.__dataclass_fields__.values()
        if f.name != "config_path"
    }

    # Read all HTML up-front so we can convert in a single engine session
    items: list[tuple[str, str | Path | None]] = []
    for html_file in files:
        try:
            html = html_file.read_text(encoding="utf-8")
            items.append((html, html_file))
        except OSError as e:
            click.echo(f"  Skipped (read error): {html_file.name} — {e}", err=True)

    if not items:
        raise click.ClickException("No files could be read.")

    click.echo(f"Converting {len(items)} file(s) (single browser session)...")
    results = do_batch(items, **config_dict)

    succeeded = 0
    failed = 0
    for label, pdf_bytes, error in results:
        result_file = Path(str(label))
        pdf_path = out_path / result_file.with_suffix(".pdf").name
        if pdf_bytes is not None:
            pdf_path.write_bytes(pdf_bytes)
            succeeded += 1
        else:
            click.echo(f"\n  Failed: {result_file.name} — {error}", err=True)
            failed += 1

    click.echo(f"\nDone: {succeeded} converted, {failed} failed.")
    if failed > 0:
        raise SystemExit(EXIT_CONVERSION)


# --------------------------------------------------------------------------- #
# version command
# --------------------------------------------------------------------------- #

@cli.command()
def version() -> None:
    """Show html2pdf version."""
    click.echo(f"html2pdf {__version__}")


# --------------------------------------------------------------------------- #
# info command
# --------------------------------------------------------------------------- #

@cli.command()
def info() -> None:
    """Show runtime information — Chromium status, config path, defaults."""
    click.echo(f"html2pdf {__version__}")
    click.echo()

    # Config resolution info
    from html2pdf.core.config import _find_config_file

    config_file = _find_config_file()
    if config_file:
        click.echo(f"Config file:    {config_file}")
    else:
        click.echo("Config file:    (none found)")

    # Env var overrides
    env_overrides = PDFConfig.from_env()
    if env_overrides:
        click.echo(f"Env overrides:  {', '.join(sorted(env_overrides.keys()))}")
    else:
        click.echo("Env overrides:  (none)")

    # Chromium status
    click.echo()
    try:
        import subprocess

        result = subprocess.run(
            [
                "python3", "-c",
                "from playwright.sync_api import sync_playwright; "
                "p = sync_playwright().start(); b = p.chromium; "
                "print(b.name, b.executable_path); p.stop()",
            ],
            capture_output=True,
            text=True,
            timeout=15,
        )
        if result.returncode == 0:
            parts = result.stdout.strip().split(" ", 1)
            click.echo(f"Browser:        {parts[0] if parts else 'chromium'}")
            if len(parts) > 1:
                click.echo(f"Executable:     {parts[1]}")
        else:
            click.echo("Browser:        not available (run: playwright install chromium)")
    except Exception:
        click.echo("Browser:        not available (run: playwright install chromium)")

    # Default config
    click.echo()
    click.echo("Default config:")
    defaults = PDFConfig()
    for f_name in [
        "page_size", "margin_top", "margin_bottom", "margin_left",
        "margin_right", "break_strategy", "font_adjustment",
        "print_background", "scale", "landscape",
    ]:
        click.echo(f"  {f_name:20s} {getattr(defaults, f_name)}")
