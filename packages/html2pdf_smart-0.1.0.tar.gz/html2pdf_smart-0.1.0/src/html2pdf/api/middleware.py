"""Middleware for the html2pdf REST API.

Provides:
    - Request ID injection (X-Request-ID header)
    - Rate limiting (token-bucket per client IP)
    - Request size limiting
    - Structured error handling
"""

from __future__ import annotations

import time
import uuid
from collections import defaultdict
from collections.abc import Callable

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

# --------------------------------------------------------------------------- #
# Request ID middleware
# --------------------------------------------------------------------------- #

class RequestIDMiddleware(BaseHTTPMiddleware):
    """Injects a unique X-Request-ID header into every response.

    If the client sends an X-Request-ID, it is preserved. Otherwise a
    new UUID4 is generated.
    """

    async def dispatch(self, request: Request, call_next: Callable) -> Response:  # type: ignore[type-arg]
        """Process request and inject request ID."""
        request_id = request.headers.get("x-request-id") or str(uuid.uuid4())
        request.state.request_id = request_id
        response: Response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response


# --------------------------------------------------------------------------- #
# Rate limiting middleware
# --------------------------------------------------------------------------- #

class RateLimitMiddleware(BaseHTTPMiddleware):
    """Simple token-bucket rate limiter keyed by client IP.

    Args:
        app: The ASGI application.
        max_requests: Maximum requests per window (default: 60).
        window_seconds: Window duration in seconds (default: 60).
    """

    def __init__(self, app: object, max_requests: int = 60, window_seconds: int = 60) -> None:
        super().__init__(app)  # type: ignore[arg-type]
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self._buckets: dict[str, list[float]] = defaultdict(list)

    def _clean_bucket(self, key: str, now: float) -> None:
        """Remove expired timestamps from a bucket."""
        cutoff = now - self.window_seconds
        self._buckets[key] = [t for t in self._buckets[key] if t > cutoff]

    async def dispatch(self, request: Request, call_next: Callable) -> Response:  # type: ignore[type-arg]
        """Check rate limit before forwarding request."""
        client_ip = request.client.host if request.client else "unknown"
        now = time.monotonic()

        self._clean_bucket(client_ip, now)

        if len(self._buckets[client_ip]) >= self.max_requests:
            return JSONResponse(
                status_code=429,
                content={
                    "error": "rate_limit_exceeded",
                    "detail": (
                        f"Rate limit exceeded: {self.max_requests} requests "
                        f"per {self.window_seconds}s. Try again later."
                    ),
                    "request_id": getattr(request.state, "request_id", None),
                },
            )

        self._buckets[client_ip].append(now)
        result: Response = await call_next(request)
        return result


# --------------------------------------------------------------------------- #
# Request size limiting middleware
# --------------------------------------------------------------------------- #

class RequestSizeLimitMiddleware(BaseHTTPMiddleware):
    """Rejects requests with Content-Length exceeding a configurable limit.

    Args:
        app: The ASGI application.
        max_bytes: Maximum request body size in bytes (default: 10MB).
    """

    def __init__(self, app: object, max_bytes: int = 10 * 1024 * 1024) -> None:
        super().__init__(app)  # type: ignore[arg-type]
        self.max_bytes = max_bytes

    async def dispatch(self, request: Request, call_next: Callable) -> Response:  # type: ignore[type-arg]
        """Check request size before forwarding."""
        content_length = request.headers.get("content-length")
        if content_length and int(content_length) > self.max_bytes:
            return JSONResponse(
                status_code=413,
                content={
                    "error": "request_too_large",
                    "detail": (
                        f"Request body exceeds maximum size of "
                        f"{self.max_bytes // (1024 * 1024)}MB."
                    ),
                    "request_id": getattr(request.state, "request_id", None),
                },
            )
        result: Response = await call_next(request)
        return result
