"""html2pdf REST API — FastAPI-based HTTP interface for HTML-to-PDF conversion."""
