"""Pydantic request/response models for the html2pdf REST API.

All models use Pydantic v2 (BaseModel from fastapi/pydantic).
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from html2pdf.core.config import BREAK_STRATEGIES, PAGE_SIZES

# --------------------------------------------------------------------------- #
# Shared config overrides
# --------------------------------------------------------------------------- #

class PDFConfigOverrides(BaseModel):
    """Optional PDF configuration overrides sent with conversion requests.

    All fields are optional — only provided fields override the defaults.
    """

    page_size: str | None = Field(
        default=None,
        description=f"Page size. One of: {', '.join(sorted(PAGE_SIZES))}",
    )
    margin_top: str | None = Field(default=None, description="Top margin (e.g. '20mm', '1in').")
    margin_bottom: str | None = Field(default=None, description="Bottom margin.")
    margin_left: str | None = Field(default=None, description="Left margin.")
    margin_right: str | None = Field(default=None, description="Right margin.")
    break_strategy: str | None = Field(
        default=None,
        description=f"Break strategy. One of: {', '.join(sorted(BREAK_STRATEGIES))}",
    )
    print_background: bool | None = Field(default=None, description="Print background graphics.")
    scale: float | None = Field(default=None, ge=0.1, le=2.0, description="Scale (0.1–2.0).")
    landscape: bool | None = Field(default=None, description="Landscape orientation.")

    def to_kwargs(self) -> dict[str, object]:
        """Convert to kwargs dict, excluding None values.

        Returns:
            Dict of only the explicitly set config overrides.
        """
        return {k: v for k, v in self.model_dump().items() if v is not None}


# --------------------------------------------------------------------------- #
# Request models
# --------------------------------------------------------------------------- #

class ConvertRequest(BaseModel):
    """Request body for POST /convert — convert an HTML string to PDF."""

    html: str = Field(..., min_length=1, description="HTML content to convert.")
    config: PDFConfigOverrides | None = Field(
        default=None,
        description="Optional PDF configuration overrides.",
    )


class ConvertURLRequest(BaseModel):
    """Request body for POST /convert/url — fetch a URL and convert to PDF."""

    url: str = Field(..., min_length=1, description="URL to fetch and convert.")
    config: PDFConfigOverrides | None = Field(
        default=None,
        description="Optional PDF configuration overrides.",
    )


# --------------------------------------------------------------------------- #
# Response models
# --------------------------------------------------------------------------- #

class HealthResponse(BaseModel):
    """Response for GET /health."""

    status: str = Field(description="Service status: 'healthy', 'degraded', or 'unhealthy'.")
    browser_ready: bool = Field(description="Whether the Playwright browser pool is available.")
    version: str = Field(description="html2pdf version string.")
    uptime_seconds: float = Field(description="Seconds since the API started.")
    pool_size: int = Field(description="Configured browser pool size.")


class ConfigDefaultsResponse(BaseModel):
    """Response for GET /config/defaults."""

    page_size: str
    margin_top: str
    margin_bottom: str
    margin_left: str
    margin_right: str
    break_strategy: str
    font_adjustment: bool
    print_background: bool
    scale: float
    landscape: bool


class ErrorResponse(BaseModel):
    """Structured error response body."""

    error: str = Field(description="Error type.")
    detail: str = Field(description="Human-readable error description.")
    request_id: str | None = Field(default=None, description="Request ID for tracing.")
