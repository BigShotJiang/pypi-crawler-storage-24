"""FastAPI application factory for the html2pdf REST API.

Usage:
    # As a module:
    from html2pdf.api.app import create_app
    app = create_app()

    # With uvicorn:
    uvicorn html2pdf.api.app:app --host 0.0.0.0 --port 8000

Environment variables:
    HTML2PDF_API_POOL_SIZE   — Browser pool size (default: 3)
    HTML2PDF_API_RATE_LIMIT  — Max requests per minute (default: 60)
    HTML2PDF_API_MAX_BODY    — Max request body in MB (default: 10)
    HTML2PDF_API_CORS_ORIGINS — Comma-separated allowed CORS origins (default: *)
"""

from __future__ import annotations

import os
import time
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from html2pdf import __version__
from html2pdf.api.middleware import (
    RateLimitMiddleware,
    RequestIDMiddleware,
    RequestSizeLimitMiddleware,
)
from html2pdf.api.routes import router
from html2pdf.core.engine import ConversionEngine


def _env_int(key: str, default: int) -> int:
    """Read an integer from an environment variable with a fallback.

    Args:
        key: Environment variable name.
        default: Default value if not set or invalid.

    Returns:
        Parsed integer or the default.
    """
    val = os.environ.get(key)
    if val is None:
        return default
    try:
        return int(val)
    except ValueError:
        return default


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Manage application lifecycle — start/stop the browser pool.

    The ConversionEngine (and its Playwright browser pool) is created on
    startup and closed on shutdown. This ensures a single browser instance
    is shared across all API requests.
    """
    pool_size = app.state.pool_size
    engine = ConversionEngine(pool_size=pool_size)
    app.state.engine = engine
    app.state.start_time = time.monotonic()
    try:
        yield
    finally:
        await engine.close()


def create_app() -> FastAPI:
    """Create and configure the FastAPI application.

    Returns:
        Configured FastAPI app ready to serve.
    """
    pool_size = _env_int("HTML2PDF_API_POOL_SIZE", 3)
    rate_limit = _env_int("HTML2PDF_API_RATE_LIMIT", 60)
    max_body_mb = _env_int("HTML2PDF_API_MAX_BODY", 10)
    cors_origins_str = os.environ.get("HTML2PDF_API_CORS_ORIGINS", "*")
    cors_origins = [o.strip() for o in cors_origins_str.split(",")]

    app = FastAPI(
        title="html2pdf API",
        description="Intelligent HTML-to-PDF conversion with layout pre-processing.",
        version=__version__,
        lifespan=lifespan,
    )

    # Store config in app state for use by lifespan and routes
    app.state.pool_size = pool_size

    # --- Middleware (applied in reverse order — first added = outermost) ---

    # Request ID goes outermost so all middleware/routes can see it
    app.add_middleware(RequestIDMiddleware)

    # Rate limiting
    app.add_middleware(RateLimitMiddleware, max_requests=rate_limit, window_seconds=60)

    # Request size limiting
    app.add_middleware(RequestSizeLimitMiddleware, max_bytes=max_body_mb * 1024 * 1024)

    # CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # --- Routes ---
    app.include_router(router)

    return app


# Module-level app for `uvicorn html2pdf.api.app:app`
app = create_app()
