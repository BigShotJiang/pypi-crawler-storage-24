"""API route definitions for the html2pdf REST API.

Endpoints:
    POST /convert          — Convert HTML string to PDF
    POST /convert/file     — Upload HTML file, return PDF
    POST /convert/url      — Fetch URL, convert to PDF
    GET  /health           — Health check (browser status)
    GET  /config/defaults  — Return default config values
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

from fastapi import APIRouter, File, Form, Request, UploadFile
from fastapi.responses import JSONResponse, Response

from html2pdf import __version__
from html2pdf.api.models import (
    ConfigDefaultsResponse,
    ConvertRequest,
    ConvertURLRequest,
    ErrorResponse,
    HealthResponse,
    PDFConfigOverrides,
)
from html2pdf.core.config import PDFConfig
from html2pdf.core.exceptions import (
    BrowserPoolError,
    ConfigError,
    HTML2PDFError,
    RenderError,
)

if TYPE_CHECKING:
    from html2pdf.core.engine import ConversionEngine

router = APIRouter()


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #

def _get_engine(request: Request) -> ConversionEngine:
    """Retrieve the shared ConversionEngine from app state.

    Args:
        request: The incoming request (carries app state).

    Returns:
        The shared ConversionEngine instance.
    """
    return request.app.state.engine  # type: ignore[no-any-return]


def _get_request_id(request: Request) -> str | None:
    """Retrieve the request ID set by middleware.

    Args:
        request: The incoming request.

    Returns:
        Request ID string or None.
    """
    return getattr(request.state, "request_id", None)


def _error_response(
    status_code: int,
    error: str,
    detail: str,
    request_id: str | None = None,
) -> JSONResponse:
    """Build a structured JSON error response.

    Args:
        status_code: HTTP status code.
        error: Error type identifier.
        detail: Human-readable description.
        request_id: Optional request ID for tracing.

    Returns:
        JSONResponse with structured error body.
    """
    return JSONResponse(
        status_code=status_code,
        content=ErrorResponse(
            error=error,
            detail=detail,
            request_id=request_id,
        ).model_dump(),
    )


def _map_exception(exc: Exception, request_id: str | None = None) -> JSONResponse:
    """Map an html2pdf exception to an HTTP error response.

    Args:
        exc: The caught exception.
        request_id: Optional request ID for tracing.

    Returns:
        Appropriate JSONResponse.
    """
    if isinstance(exc, ConfigError):
        return _error_response(400, "config_error", str(exc), request_id)
    if isinstance(exc, (BrowserPoolError, RenderError)):
        return _error_response(503, "renderer_error", str(exc), request_id)
    if isinstance(exc, HTML2PDFError):
        return _error_response(500, "conversion_error", str(exc), request_id)
    return _error_response(500, "internal_error", str(exc), request_id)


# --------------------------------------------------------------------------- #
# POST /convert
# --------------------------------------------------------------------------- #

@router.post(
    "/convert",
    response_class=Response,
    responses={
        200: {"content": {"application/pdf": {}}, "description": "PDF file bytes"},
        400: {"model": ErrorResponse, "description": "Invalid config or empty HTML"},
        503: {"model": ErrorResponse, "description": "Browser/renderer unavailable"},
    },
    summary="Convert HTML string to PDF",
    description="Accepts an HTML string and optional config overrides. Returns PDF bytes.",
)
async def convert_html(body: ConvertRequest, request: Request) -> Response:
    """Convert an HTML string to PDF bytes."""
    engine = _get_engine(request)
    request_id = _get_request_id(request)

    config_kwargs = body.config.to_kwargs() if body.config else {}

    try:
        pdf_bytes = await engine.convert(body.html, **config_kwargs)
    except Exception as exc:
        return _map_exception(exc, request_id)

    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": "attachment; filename=output.pdf",
            "Content-Length": str(len(pdf_bytes)),
        },
    )


# --------------------------------------------------------------------------- #
# POST /convert/file
# --------------------------------------------------------------------------- #

@router.post(
    "/convert/file",
    response_class=Response,
    responses={
        200: {"content": {"application/pdf": {}}, "description": "PDF file bytes"},
        400: {"model": ErrorResponse, "description": "Invalid file or config"},
        503: {"model": ErrorResponse, "description": "Browser/renderer unavailable"},
    },
    summary="Upload HTML file, return PDF",
    description="Upload an HTML file as multipart form data. Returns PDF bytes.",
)
async def convert_file(
    request: Request,
    file: UploadFile = File(..., description="HTML file to convert"),  # noqa: B008
    config: str | None = Form(default=None, description="Optional JSON config overrides"),  # noqa: B008
) -> Response:
    """Convert an uploaded HTML file to PDF."""
    engine = _get_engine(request)
    request_id = _get_request_id(request)

    # Read uploaded file
    try:
        content = await file.read()
        html = content.decode("utf-8")
    except UnicodeDecodeError:
        return _error_response(400, "invalid_file", "File is not valid UTF-8 HTML.", request_id)

    if not html.strip():
        return _error_response(400, "empty_file", "Uploaded file is empty.", request_id)

    # Parse optional config JSON from form field
    config_kwargs: dict[str, object] = {}
    if config:
        try:

            overrides = PDFConfigOverrides.model_validate_json(config)
            config_kwargs = overrides.to_kwargs()
        except Exception as exc:
            return _error_response(
                400,
                "invalid_config",
                f"Invalid config JSON: {exc}",
                request_id,
            )

    try:
        pdf_bytes = await engine.convert(html, **config_kwargs)
    except Exception as exc:
        return _map_exception(exc, request_id)

    # Use the original filename with .pdf extension
    filename = file.filename or "output.html"
    if filename.endswith((".html", ".htm")):
        filename = filename.rsplit(".", 1)[0] + ".pdf"
    else:
        filename += ".pdf"

    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Content-Length": str(len(pdf_bytes)),
        },
    )


# --------------------------------------------------------------------------- #
# POST /convert/url
# --------------------------------------------------------------------------- #

@router.post(
    "/convert/url",
    response_class=Response,
    responses={
        200: {"content": {"application/pdf": {}}, "description": "PDF file bytes"},
        400: {"model": ErrorResponse, "description": "Invalid URL or config"},
        502: {"model": ErrorResponse, "description": "Failed to fetch URL"},
        503: {"model": ErrorResponse, "description": "Browser/renderer unavailable"},
    },
    summary="Fetch URL and convert to PDF",
    description="Fetches the given URL, then converts the HTML response to PDF.",
)
async def convert_url(body: ConvertURLRequest, request: Request) -> Response:
    """Fetch a URL and convert the HTML content to PDF."""
    engine = _get_engine(request)
    request_id = _get_request_id(request)

    # Validate URL format
    if not body.url.startswith(("http://", "https://")):
        return _error_response(
            400, "invalid_url", "URL must start with http:// or https://.", request_id
        )

    # Fetch URL
    try:
        import httpx

        async with httpx.AsyncClient(follow_redirects=True, timeout=30.0) as client:
            resp = await client.get(body.url)
            resp.raise_for_status()
            html = resp.text
    except ImportError:
        return _error_response(
            500,
            "missing_dependency",
            "URL fetching requires httpx. Install with: pip install httpx",
            request_id,
        )
    except httpx.HTTPStatusError as exc:
        return _error_response(
            502,
            "fetch_error",
            f"HTTP {exc.response.status_code} fetching '{body.url}'.",
            request_id,
        )
    except httpx.RequestError as exc:
        return _error_response(
            502, "fetch_error", f"Failed to fetch '{body.url}': {exc}", request_id
        )

    config_kwargs = body.config.to_kwargs() if body.config else {}

    try:
        pdf_bytes = await engine.convert(html, **config_kwargs)
    except Exception as exc:
        return _map_exception(exc, request_id)

    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": "attachment; filename=output.pdf",
            "Content-Length": str(len(pdf_bytes)),
        },
    )


# --------------------------------------------------------------------------- #
# GET /health
# --------------------------------------------------------------------------- #

@router.get(
    "/health",
    response_model=HealthResponse,
    summary="Health check",
    description="Returns service health, browser readiness, and uptime.",
)
async def health(request: Request) -> HealthResponse:
    """Return health status including browser pool readiness."""
    start_time: float = request.app.state.start_time
    pool_size: int = request.app.state.pool_size
    uptime = time.monotonic() - start_time

    # Check if engine exists and is usable
    engine = getattr(request.app.state, "engine", None)
    browser_ready = engine is not None

    status = "healthy" if browser_ready else "unhealthy"

    return HealthResponse(
        status=status,
        browser_ready=browser_ready,
        version=__version__,
        uptime_seconds=round(uptime, 2),
        pool_size=pool_size,
    )


# --------------------------------------------------------------------------- #
# GET /config/defaults
# --------------------------------------------------------------------------- #

@router.get(
    "/config/defaults",
    response_model=ConfigDefaultsResponse,
    summary="Default configuration",
    description="Returns the default PDFConfig values.",
)
async def config_defaults() -> ConfigDefaultsResponse:
    """Return default configuration values."""
    defaults = PDFConfig()
    return ConfigDefaultsResponse(
        page_size=defaults.page_size,
        margin_top=defaults.margin_top,
        margin_bottom=defaults.margin_bottom,
        margin_left=defaults.margin_left,
        margin_right=defaults.margin_right,
        break_strategy=defaults.break_strategy,
        font_adjustment=defaults.font_adjustment,
        print_background=defaults.print_background,
        scale=defaults.scale,
        landscape=defaults.landscape,
    )
