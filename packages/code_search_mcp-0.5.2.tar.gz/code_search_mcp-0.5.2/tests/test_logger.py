"""日志系统测试"""
import os
import tempfile
from datetime import datetime, timedelta


class TestLogger:
    """日志模块测试"""

    def test_log_entry_creation(self, temp_logger):
        """测试日志条目创建"""
        entry = temp_logger.log(
            tool_name="test_tool",
            duration_ms=100.5,
            result_count=10,
            query="test query",
            success=True
        )

        assert entry.tool_name == "test_tool"
        assert entry.duration_ms == 100.5
        assert entry.result_count == 10
        assert entry.query == "test query"
        assert entry.success is True
        assert entry.level == "INFO"

    def test_log_error_entry(self, temp_logger):
        """测试错误日志"""
        entry = temp_logger.log(
            tool_name="test_tool",
            duration_ms=50.0,
            result_count=0,
            query="test",
            success=False,
            error_message="Something went wrong"
        )

        assert entry.success is False
        assert entry.level == "ERROR"
        assert entry.error_message == "Something went wrong"

    def test_log_long_query_truncation(self, temp_logger):
        """测试长查询截断"""
        long_query = "a" * 1000
        entry = temp_logger.log(
            tool_name="test_tool",
            duration_ms=50.0,
            query=long_query
        )

        assert len(entry.query) == 500

    def test_get_logs(self, temp_logger):
        """测试查询日志"""
        # 创建多条日志
        for i in range(5):
            temp_logger.log(
                tool_name=f"tool_{i}",
                duration_ms=100.0 + i,
                result_count=i,
                query=f"query_{i}"
            )

        logs = temp_logger.get_logs(limit=10)
        assert len(logs) == 5

    def test_get_logs_by_tool_name(self, temp_logger):
        """测试按工具名过滤"""
        temp_logger.log(tool_name="find_files", duration_ms=100.0)
        temp_logger.log(tool_name="find_symbols", duration_ms=200.0)
        temp_logger.log(tool_name="find_files", duration_ms=150.0)

        logs = temp_logger.get_logs(tool_name="find_files")
        assert len(logs) == 2

    def test_get_logs_by_time_range(self, temp_logger):
        """测试按时间范围过滤"""
        now = datetime.now()
        past_day = (now - timedelta(days=1)).isoformat()

        # 创建旧日志
        temp_logger.log(tool_name="old_tool", duration_ms=100.0)

        # 注意：由于时间戳是创建时生成的，这里我们测试数据库中的记录
        logs = temp_logger.get_logs(start_time=past_day)
        assert len(logs) >= 1

    def test_get_logs_by_success(self, temp_logger):
        """测试按成功状态过滤"""
        temp_logger.log(tool_name="tool1", duration_ms=100.0, success=True)
        temp_logger.log(tool_name="tool2", duration_ms=100.0, success=False)

        success_logs = temp_logger.get_logs(success=True)
        error_logs = temp_logger.get_logs(success=False)

        assert len(success_logs) == 1
        assert len(error_logs) == 1

    def test_get_stats(self, temp_logger):
        """测试统计信息"""
        temp_logger.log(tool_name="find_files", duration_ms=100.0, result_count=5, success=True)
        temp_logger.log(tool_name="find_files", duration_ms=200.0, result_count=10, success=True)
        temp_logger.log(tool_name="find_symbols", duration_ms=150.0, result_count=3, success=True)
        temp_logger.log(tool_name="find_content", duration_ms=100.0, result_count=0, success=False)

        stats = temp_logger.get_stats()

        assert stats["total_calls"] == 4
        assert stats["success_count"] == 3
        assert stats["error_count"] == 1
        assert stats["success_rate"] == 75.0
        assert len(stats["by_tool"]) == 3

    def test_get_stats_by_tool(self, temp_logger):
        """测试按工具统计"""
        for _ in range(3):
            temp_logger.log(tool_name="find_files", duration_ms=100.0)

        temp_logger.log(tool_name="find_symbols", duration_ms=200.0)

        stats = temp_logger.get_stats()
        find_files_stats = next(t for t in stats["by_tool"] if t["tool_name"] == "find_files")

        assert find_files_stats["count"] == 3
        assert find_files_stats["total_results"] == 0

    def test_memory_buffer(self, temp_logger):
        """测试内存缓冲"""
        # 创建一个小的内存限制的 logger
        from code_search_mcp.logger import Logger
        with tempfile.TemporaryDirectory() as tmpdir:
            logger_path = os.path.join(tmpdir, "buffer_test.db")
            logger = Logger(logger_path, memory_limit=5)

            for i in range(10):
                logger.log(tool_name=f"tool_{i}", duration_ms=100.0)

            # 内存缓冲应该只保留最新的 5 条
            recent = logger.get_recent_logs(limit=10)
            assert len(recent) == 5

    def test_clear_old_logs(self, temp_logger):
        """测试清理旧日志"""
        # 创建一些日志
        temp_logger.log(tool_name="old_tool", duration_ms=100.0)

        # 清理 0 天前的日志（应该删除所有）
        temp_logger.clear_old_logs(days=0)

        logs = temp_logger.get_logs()
        assert len(logs) == 0


class TestLogLevel:
    """日志级别测试"""

    def test_warning_level_for_slow_calls(self, temp_logger):
        """测试慢调用自动标记为 WARNING"""
        # 超过 5 秒的调用应该标记为 WARNING
        entry = temp_logger.log(
            tool_name="slow_tool",
            duration_ms=6000.0,
            success=True
        )

        assert entry.level == "WARNING"

    def test_error_level_for_failed_calls(self, temp_logger):
        """测试失败调用自动标记为 ERROR"""
        entry = temp_logger.log(
            tool_name="failed_tool",
            duration_ms=100.0,
            success=False
        )

        assert entry.level == "ERROR"

    def test_error_takes_precedence(self, temp_logger):
        """测试错误优先于警告"""
        # 即使慢，如果失败了也是 ERROR
        entry = temp_logger.log(
            tool_name="slow_failed_tool",
            duration_ms=6000.0,
            success=False
        )

        assert entry.level == "ERROR"
