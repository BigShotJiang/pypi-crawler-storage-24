"""Sourcegraph 竞品对比测试

此模块用于对比 Code Search MCP 与 Sourcegraph 的搜索能力。

使用方式：
1. 设置 SOURCEGRAPH_URL 环境变量（Sourcegraph 实例地址）
2. 设置 SOURCEGRAPH_API_KEY 环境变量（API Key，可选）
3. 或确保 src CLI 已安装并配置

示例：
    export SOURCEGRAPH_URL="https://sourcegraph.com"
    export SOURCEGRAPH_API_KEY="your-api-key"
    pytest tests/test_sourcegraph_comparison.py -v
"""
import os
import time
from dataclasses import dataclass

import pytest


@dataclass
class SearchResult:
    """搜索结果"""
    file_path: str
    line_number: int
    content: str
    score: float = 1.0


@dataclass
class ComparisonReport:
    """对比报告"""
    query: str
    code_index_results: list[SearchResult]
    sourcegraph_results: list[SearchResult]
    code_index_time_ms: float
    sourcegraph_time_ms: float
    overlap_ratio: float  # 重叠率


class SourcegraphClient:
    """Sourcegraph API 客户端"""

    def __init__(self, url: str | None = None, api_key: str | None = None):
        """初始化 Sourcegraph 客户端

        Args:
            url: Sourcegraph 实例地址
            api_key: Sourcegraph API Key
        """
        self.url = url or os.environ.get("SOURCEGRAPH_URL", "https://sourcegraph.com")
        self.api_key = api_key or os.environ.get("SOURCEGRAPH_API_KEY")
        self._cli_available = None

    def _check_cli(self) -> bool:
        """检查 src CLI 是否可用"""
        if self._cli_available is not None:
            return self._cli_available

        import shutil
        self._cli_available = shutil.which("src") is not None
        return self._cli_available

    def search(self, query: str, repo: str | None = None) -> tuple[list[SearchResult], float]:
        """执行搜索

        Args:
            query: 搜索查询
            repo: 仓库路径（可选）

        Returns:
            (结果列表, 耗时毫秒)
        """
        start_time = time.time()

        # 优先使用 src CLI
        if self._check_cli():
            results = self._search_cli(query, repo)
        else:
            # 回退到 API
            results = self._search_api(query, repo)

        duration_ms = (time.time() - start_time) * 1000
        return results, duration_ms

    def _search_cli(self, query: str, repo: str | None = None) -> list[SearchResult]:
        """使用 src CLI 搜索"""
        import subprocess

        cmd = ["src", "search", "-q", query, "-json"]
        if repo:
            cmd.extend(["-repo", repo])

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30
            )

            if result.returncode != 0:
                return []

            # 解析 JSON 输出
            import json
            data = json.loads(result.stdout)
            return [
                SearchResult(
                    file_path=r.get("path", ""),
                    line_number=r.get("lineNumber", 0),
                    content=r.get("content", "")
                )
                for r in data
            ]
        except Exception:
            return []

    def _search_api(self, query: str, repo: str | None = None) -> list[SearchResult]:
        """使用 API 搜索"""
        if not self.api_key:
            return []

        # GraphQL API 查询
        graphql_query = """
        query Search($query: String!) {
            search(query: $query, version: V3) {
                results {
                    results {
                        ... on FileMatch {
                            file {
                                path
                            }
                            matches {
                                lineNumber
                                content
                            }
                        }
                    }
                }
            }
        }
        """

        import requests
        try:
            response = requests.post(
                f"{self.url}/.api/graphql",
                json={"query": graphql_query, "variables": {"query": query}},
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=30
            )

            if response.status_code != 200:
                return []

            data = response.json()
            results = []
            for match in data.get("data", {}).get("search", {}).get("results", {}).get("results", []):
                for m in match.get("matches", []):
                    results.append(SearchResult(
                        file_path=match["file"]["path"],
                        line_number=m.get("lineNumber", 0),
                        content=m.get("content", "")
                    ))

            return results
        except Exception:
            return []


class CodeIndexClient:
    """Code Search MCP 客户端（用于测试）"""

    def __init__(self, db_path: str | None = None):
        """初始化客户端"""
        from code_search_mcp.database import Database
        self.db = Database(db_path)

    def search_content(self, query: str, limit: int = 50) -> tuple[list[SearchResult], float]:
        """搜索内容

        Args:
            query: 搜索查询
            limit: 返回数量限制

        Returns:
            (结果列表, 耗时毫秒)
        """
        start_time = time.time()

        matches = self.db.find_content(query, regex=False, limit=limit)

        results = [
            SearchResult(
                file_path=m["file_path"],
                line_number=m["line_number"],
                content=m["content"]
            )
            for m in matches
        ]

        duration_ms = (time.time() - start_time) * 1000
        return results, duration_ms

    def search_symbols(self, query: str, limit: int = 50) -> tuple[list[SearchResult], float]:
        """搜索符号

        Args:
            query: 符号名称
            limit: 返回数量限制

        Returns:
            (结果列表, 耗时毫秒)
        """
        start_time = time.time()

        symbols = self.db.find_symbols(query=query, limit=limit)

        results = [
            SearchResult(
                file_path=s["file_path"],
                line_number=s["line_start"],
                content=s.get("signature", "")
            )
            for s in symbols
        ]

        duration_ms = (time.time() - start_time) * 1000
        return results, duration_ms


def calculate_overlap(results1: list[SearchResult], results2: list[SearchResult]) -> float:
    """计算两个结果集的重叠率

    Args:
        results1: 结果集1
        results2: 结果集2

    Returns:
        重叠率 (0.0 - 1.0)
    """
    if not results1 or not results2:
        return 0.0

    # 使用 (file_path, line_number) 作为唯一标识
    set1 = {(r.file_path, r.line_number) for r in results1}
    set2 = {(r.file_path, r.line_number) for r in results2}

    overlap = len(set1 & set2)
    return overlap / min(len(set1), len(set2))


class TestSourcegraphComparison:
    """Sourcegraph 对比测试"""

    @pytest.fixture
    def sourcegraph_client(self):
        """Sourcegraph 客户端"""
        return SourcegraphClient()

    @pytest.fixture
    def code_index_client(self, temp_db):
        """Code Search 客户端"""
        return CodeIndexClient(temp_db.db_path)

    def test_cli_available(self, sourcegraph_client):
        """测试 src CLI 是否可用"""
        # 这是一个信息性测试
        available = sourcegraph_client._check_cli()
        if not available:
            pytest.skip("src CLI not available, skipping comparison tests")

    def test_compare_content_search(self, sourcegraph_client, code_index_client, test_repo_path):
        """对比内容搜索

        测试场景：使用相同的查询词在两个系统中搜索
        """
        # 首先索引测试仓库
        from code_search_mcp.indexer import Indexer
        indexer = Indexer(code_index_client.db)
        indexer.index_repository(test_repo_path)

        # 测试查询
        test_queries = [
            "def ",
            "class ",
            "import ",
        ]

        for query in test_queries:
            # Code Search 搜索
            code_results, code_time = code_index_client.search_content(query)

            # Sourcegraph 搜索（如果有 CLI）
            if sourcegraph_client._check_cli():
                sg_results, sg_time = sourcegraph_client.search(query)

                # 计算重叠率
                overlap = calculate_overlap(code_results, sg_results)

                print(f"\nQuery: '{query}'")
                print(f"  Code Search: {len(code_results)} results in {code_time:.2f}ms")
                print(f"  Sourcegraph: {len(sg_results)} results in {sg_time:.2f}ms")
                print(f"  Overlap: {overlap:.2%}")

                # 记录对比结果
                assert len(code_results) >= 0  # Code Search 应该有结果

    def test_compare_symbol_search(self, sourcegraph_client, code_index_client, test_repo_path):
        """对比符号搜索"""
        # 索引测试仓库
        from code_search_mcp.indexer import Indexer
        indexer = Indexer(code_index_client.db)
        indexer.index_repository(test_repo_path)

        # 测试符号查询
        test_queries = ["test", "Test", "main"]

        for query in test_queries:
            code_results, code_time = code_index_client.search_symbols(query)

            print(f"\nSymbol Query: '{query}'")
            print(f"  Code Search: {len(code_results)} results in {code_time:.2f}ms")

            assert len(code_results) >= 0

    def test_response_time_comparison(self, sourcegraph_client, code_index_client, test_repo_path):
        """对比响应时间

        测量两个系统的端到端延迟
        """
        from code_search_mcp.indexer import Indexer
        indexer = Indexer(code_index_client.db)
        indexer.index_repository(test_repo_path)

        query = "def "

        # Code Search 响应时间
        code_results, code_time = code_index_client.search_content(query)

        print(f"\nResponse Time Comparison for query '{query}':")
        print(f"  Code Search: {code_time:.2f}ms")

        if sourcegraph_client._check_cli():
            sg_results, sg_time = sourcegraph_client.search(query)
            print(f"  Sourcegraph: {sg_time:.2f}ms")

        # Code Search 应该能在合理时间内返回（< 1秒）
        assert code_time < 1000, f"Code Search took too long: {code_time}ms"


class TestSymbolRecognition:
    """符号识别能力测试"""

    @pytest.fixture
    def code_index_client(self, temp_db):
        return CodeIndexClient(temp_db.db_path)

    def test_function_recognition(self, code_index_client, test_repo_path):
        """测试函数识别"""
        from code_search_mcp.indexer import Indexer
        indexer = Indexer(code_index_client.db)
        indexer.index_repository(test_repo_path)

        # 搜索函数
        functions, _ = code_index_client.search_symbols("test")

        print(f"\nFound {len(functions)} function symbols")
        assert len(functions) >= 0

    def test_class_recognition(self, code_index_client, test_repo_path):
        """测试类识别"""
        from code_search_mcp.indexer import Indexer
        indexer = Indexer(code_index_client.db)
        indexer.index_repository(test_repo_path)

        # 搜索类
        symbols = code_index_client.db.find_symbols(kind="class", limit=50)

        print(f"\nFound {len(symbols)} class symbols")
        assert len(symbols) >= 0


# 便捷函数：生成对比报告
def generate_comparison_report(
    code_index: CodeIndexClient,
    sourcegraph: SourcegraphClient,
    queries: list[str]
) -> list[ComparisonReport]:
    """生成对比报告

    Args:
        code_index: Code Search 客户端
        sourcegraph: Sourcegraph 客户端
        queries: 测试查询列表

    Returns:
        对比报告列表
    """
    reports = []

    for query in queries:
        code_results, code_time = code_index.search_content(query)
        sg_results, sg_time = sourcegraph.search(query)

        overlap = calculate_overlap(code_results, sg_results)

        report = ComparisonReport(
            query=query,
            code_index_results=code_results,
            sourcegraph_results=sg_results,
            code_index_time_ms=code_time,
            sourcegraph_time_ms=sg_time,
            overlap_ratio=overlap
        )
        reports.append(report)

    return reports
