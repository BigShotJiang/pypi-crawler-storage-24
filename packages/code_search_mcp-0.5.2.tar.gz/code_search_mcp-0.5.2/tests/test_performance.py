"""性能测试"""
import os
import tempfile
import time

from code_search_mcp.database import Database
from code_search_mcp.indexer import Indexer


class TestPerformance:
    """性能测试"""

    def test_index_performance_small_repo(self, clean_db):
        """测试小规模代码库索引性能"""
        # 使用测试代码库（3个文件）
        test_repo_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "fixtures",
            "test_repo"
        )

        indexer = Indexer(clean_db)

        start_time = time.time()
        result = indexer.index_repository(test_repo_path, force_rebuild=True)
        elapsed = time.time() - start_time

        # 3个文件应该在1秒内完成
        assert elapsed < 1.0
        assert result["stats"]["files_indexed"] == 3

    def test_search_response_time(self, clean_db):
        """测试搜索响应时间"""
        # 索引测试代码库
        test_repo_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "fixtures",
            "test_repo"
        )

        indexer = Indexer(clean_db)
        indexer.index_repository(test_repo_path, force_rebuild=True)

        # 测试文件搜索响应时间
        start_time = time.time()
        files = clean_db.find_files(query="test", limit=20)
        elapsed_files = time.time() - start_time

        # 搜索应在 100ms 内完成
        assert elapsed_files < 0.1
        assert len(files) > 0

        # 测试符号搜索响应时间
        start_time = time.time()
        symbols = clean_db.find_symbols(query="calculate", limit=20)
        elapsed_symbols = time.time() - start_time

        assert elapsed_symbols < 0.1
        assert len(symbols) >= 0

        # 测试内容搜索响应时间
        start_time = time.time()
        content = clean_db.find_content("return", limit=20)
        elapsed_content = time.time() - start_time

        assert elapsed_content < 0.1
        assert len(content) > 0

    def test_incremental_index_performance(self, clean_db):
        """测试增量索引性能"""
        test_repo_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "fixtures",
            "test_repo"
        )

        indexer = Indexer(clean_db)

        # 第一次索引
        start_time = time.time()
        indexer.index_repository(test_repo_path, force_rebuild=True)
        elapsed_first = time.time() - start_time

        # 第二次增量索引（应该更快）
        start_time = time.time()
        indexer.index_repository(test_repo_path, force_rebuild=False)
        elapsed_second = time.time() - start_time

        # 增量索引应该更快
        assert elapsed_second <= elapsed_first

    def test_stats_performance(self, clean_db):
        """测试统计查询性能"""
        test_repo_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "fixtures",
            "test_repo"
        )

        indexer = Indexer(clean_db)
        indexer.index_repository(test_repo_path, force_rebuild=True)

        # 测试统计查询
        start_time = time.time()
        stats = clean_db.get_stats()
        elapsed = time.time() - start_time

        assert elapsed < 0.1
        assert stats["files"] == 3
        assert stats["symbols"] > 0
        assert stats["content_blocks"] > 0


class TestLargeScalePerformance:
    """大规模性能测试"""

    def test_index_100_files(self):
        """测试索引 100 个文件的性能"""
        # 创建临时目录和 100 个测试文件
        with tempfile.TemporaryDirectory() as tmpdir:
            # 创建测试文件
            for i in range(100):
                file_path = os.path.join(tmpdir, f"test_{i}.py")
                with open(file_path, 'w') as f:
                    f.write(f"""
def function_{i}(x):
    return x * {i}

class Class_{i}:
    def method_{i}(self):
        return {i}
""")

            # 创建数据库并索引
            db_path = os.path.join(tmpdir, "test.db")
            db = Database(db_path)
            indexer = Indexer(db)

            start_time = time.time()
            result = indexer.index_repository(tmpdir, force_rebuild=True)
            elapsed = time.time() - start_time

            # 100 个文件应该在 5 秒内完成
            assert elapsed < 5.0
            assert result["stats"]["files_indexed"] == 100

    def test_search_performance_large_repo(self):
        """测试大规模代码库的搜索性能"""
        with tempfile.TemporaryDirectory() as tmpdir:
            # 创建测试文件
            for i in range(100):
                file_path = os.path.join(tmpdir, f"test_{i}.py")
                with open(file_path, 'w') as f:
                    f.write(f"""
def function_{i}(x):
    return x * {i}

class Class_{i}:
    def method_{i}(self):
        return {i}
""")

            # 创建数据库并索引
            db_path = os.path.join(tmpdir, "test.db")
            db = Database(db_path)
            indexer = Indexer(db)
            indexer.index_repository(tmpdir, force_rebuild=True)

            # 搜索测试
            start_time = time.time()
            for _ in range(10):
                db.find_files(query="test", limit=20)
                db.find_symbols(query="function", limit=20)
                db.find_content("return", limit=20)
            elapsed = time.time() - start_time

            # 30 次搜索应该在 1 秒内完成
            assert elapsed < 1.0
