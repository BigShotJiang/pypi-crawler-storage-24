"""效率对比测试 - 对比使用 MCP 和不使用 MCP 的搜索效率

这个测试帮助你了解 MCP 的实际价值。
"""
import glob
import os
import sys
import tempfile
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from code_search_mcp.database import Database
from code_search_mcp.indexer import Indexer


def search_without_mcp(repo_path: str, query: str) -> tuple[list, float]:
    """不使用 MCP 的搜索（直接遍历文件）"""
    results = []
    start = time.time()

    extensions = ['.py', '.js', '.ts', '.go', '.rs', '.java']

    for ext in extensions:
        pattern = os.path.join(repo_path, '**', f'*{ext}')
        files = glob.glob(pattern, recursive=True)

        for file_path in files:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    for line_num, line in enumerate(f, 1):
                        if query in line:
                            results.append({
                                'file': file_path,
                                'line': line_num,
                                'content': line.strip()[:100]
                            })
            except Exception:
                pass

    duration = (time.time() - start) * 1000
    return results, duration


def search_with_mcp(repo_path: str, query: str) -> tuple[list, float]:
    """使用 MCP 的搜索"""
    with tempfile.TemporaryDirectory() as tmpdir:
        db = Database(os.path.join(tmpdir, 'test.db'))
        indexer = Indexer(db)

        # 索引时间
        index_start = time.time()
        indexer.index_repository(repo_path, force_rebuild=True)
        index_time = (time.time() - index_start) * 1000

        # 搜索时间
        search_start = time.time()
        results = db.find_content(query, limit=100)
        search_time = (time.time() - search_start) * 1000

        total_time = index_time + search_time

        # 格式化结果
        formatted = []
        for r in results:
            formatted.append({
                'file': r['file_path'],
                'line': r['line_number'],
                'content': r['content'][:100]
            })

        return formatted, total_time


def benchmark(repo_path: str, queries: list[str]):
    """运行基准测试"""
    print(f"仓库: {repo_path}")
    print("=" * 60)

    for query in queries:
        print(f"\n查询: '{query}'")
        print("-" * 40)

        # 不使用 MCP
        results_no_mcp, time_no_mcp = search_without_mcp(repo_path, query)
        print(f"  无 MCP:   {len(results_no_mcp)} 结果, {time_no_mcp:.2f}ms")

        # 使用 MCP
        results_mcp, time_mcp = search_with_mcp(repo_path, query)
        print(f"  有 MCP:   {len(results_mcp)} 结果, {time_mcp:.2f}ms")

        # 效率对比
        if time_no_mcp > 0:
            speedup = time_no_mcp / time_mcp
            print(f"  加速比:   {speedup:.1f}x")


def count_files(repo_path: str) -> int:
    """统计文件数"""
    count = 0
    for ext in ['.py', '.js', '.ts', '.go', '.rs', '.java']:
        pattern = os.path.join(repo_path, '**', f'*{ext}')
        count += len(glob.glob(pattern, recursive=True))
    return count


if __name__ == "__main__":
    import glob

    # 测试当前项目
    project_root = os.path.dirname(os.path.dirname(__file__))
    test_repo = os.path.join(project_root, 'code_search_mcp')

    # 统计
    file_count = count_files(test_repo)
    print(f"测试仓库文件数: {file_count}")

    # 基准测试
    queries = ['def', 'class', 'test', 'return']
    benchmark(test_repo, queries)
