"""索引功能测试"""
import os

import pytest

from code_search_mcp.indexer import Indexer


class TestIndexer:
    """索引器测试"""

    def test_index_repository(self, clean_db, test_repo_path):
        """测试索引测试代码库"""
        indexer = Indexer(clean_db)

        result = indexer.index_repository(test_repo_path, force_rebuild=True)

        assert result["success"] is True
        assert result["stats"]["files_indexed"] == 3  # test.js, test.ts, test.py
        assert result["stats"]["symbols"] > 0

    def test_index_repository_incremental(self, clean_db, test_repo_path):
        """测试增量索引（跳过未修改文件）"""
        indexer = Indexer(clean_db)

        # 第一次索引
        indexer.index_repository(test_repo_path, force_rebuild=False)

        # 第二次索引（不强制重建）
        result2 = indexer.index_repository(test_repo_path, force_rebuild=False)
        files2 = result2["stats"]["files_indexed"]

        # 第二次应该跳过所有文件（无修改）
        assert files2 == 0

    def test_index_repository_force_rebuild(self, clean_db, test_repo_path):
        """测试强制重建索引"""
        indexer = Indexer(clean_db)

        # 第一次索引
        indexer.index_repository(test_repo_path, force_rebuild=False)

        # 强制重建
        result = indexer.index_repository(test_repo_path, force_rebuild=True)

        assert result["success"] is True
        assert result["stats"]["files_indexed"] == 3

    def test_get_file_structure(self, clean_db, test_repo_path):
        """测试获取文件结构"""
        indexer = Indexer(clean_db)

        # 先索引文件
        indexer.index_repository(test_repo_path, force_rebuild=True)

        # 获取 JS 文件结构
        js_path = os.path.join(test_repo_path, "test.js")
        structure = indexer.get_file_structure(js_path)

        assert structure["path"] == js_path
        assert structure["language"] == "JavaScript"
        assert len(structure["symbols"]) > 0

    def test_get_file_structure_not_indexed(self, clean_db, test_repo_path):
        """测试获取未索引文件的结构"""
        indexer = Indexer(clean_db)

        js_path = os.path.join(test_repo_path, "test.js")

        # 不手动索引，直接获取结构（会自动索引）
        structure = indexer.get_file_structure(js_path)

        assert structure["path"] == js_path
        assert len(structure["symbols"]) > 0

    def test_index_invalid_path(self, clean_db):
        """测试索引不存在的路径"""
        indexer = Indexer(clean_db)

        with pytest.raises(ValueError, match="路径不存在"):
            indexer.index_repository("/nonexistent/path")
