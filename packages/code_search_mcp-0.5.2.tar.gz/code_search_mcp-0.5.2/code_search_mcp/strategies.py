"""语言策略 - 使用策略模式支持不同编程语言"""
import os
import re
from abc import ABC, abstractmethod
from typing import NamedTuple


class Symbol(NamedTuple):
    """符号定义"""
    name: str
    kind: str  # function, class, variable, method
    signature: str | None
    line_start: int
    line_end: int


class Dependency(NamedTuple):
    """依赖关系定义"""
    import_statement: str  # 完整的 import 语句
    import_line: int       # 行号
    dependency_type: str   # import, require, from
    target_module: str     # 目标模块名


class LanguageStrategy(ABC):
    """语言策略抽象基类"""

    @abstractmethod
    def extract_symbols(self, file_path: str) -> list[Symbol]:
        """提取文件中的符号"""
        pass

    @abstractmethod
    def extract_summary(self, file_path: str) -> str | None:
        """提取文件的语义摘要"""
        pass


class JavaScriptStrategy(LanguageStrategy):
    """JavaScript/TypeScript 策略"""

    # Import 正则
    IMPORT_PATTERN = re.compile(
        r"^import\s+(?:\{[^}]*\}|\*\s+as\s+\w+|\w+)?\s*from\s+['\"]([^'\"]+)['\"]",
        re.MULTILINE
    )
    # Require 正则
    REQUIRE_PATTERN = re.compile(
        r"^const\s+(\w+)\s*=\s*require\s*\(\s*['\"]([^'\"]+)['\"]\s*\)",
        re.MULTILINE
    )
    # ES6 dynamic import
    DYNAMIC_IMPORT_PATTERN = re.compile(
        r"import\s*\(\s*['\"]([^'\"]+)['\"]\s*\)",
        re.MULTILINE
    )

    # 函数/方法正则
    FUNC_PATTERN = re.compile(
        r'^(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*\(([^)]*)\)',
        re.MULTILINE
    )
    # 箭头函数
    ARROW_PATTERN = re.compile(
        r'^(?:export\s+)?(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?\(([^)]*)\)\s*=>',
        re.MULTILINE
    )
    # 类
    CLASS_PATTERN = re.compile(
        r'^(?:export\s+)?class\s+(\w+)(?:\s+extends\s+\w+)?(?:\s+implements\s+[\w,\s]+)?',
        re.MULTILINE
    )
    # 方法
    METHOD_PATTERN = re.compile(
        r'^\s*(?:async\s+)?(\w+)\s*\(([^)]*)\)\s*\{',
        re.MULTILINE
    )
    # TypeScript 类型
    INTERFACE_PATTERN = re.compile(
        r'^(?:export\s+)?interface\s+(\w+)',
        re.MULTILINE
    )
    TYPE_PATTERN = re.compile(
        r'^(?:export\s+)?type\s+(\w+)',
        re.MULTILINE
    )

    def extract_symbols(self, file_path: str) -> list[Symbol]:
        """提取 JS/TS 符号"""
        symbols = []
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # 提取函数
            for match in self.FUNC_PATTERN.finditer(content):
                name = match.group(1)
                params = match.group(2)
                line_num = content[:match.start()].count('\n') + 1
                symbols.append(Symbol(
                    name=name,
                    kind='function',
                    signature=f"function {name}({params})",
                    line_start=line_num,
                    line_end=line_num
                ))

            # 提取箭头函数
            for match in self.ARROW_PATTERN.finditer(content):
                name = match.group(1)
                params = match.group(2)
                line_num = content[:match.start()].count('\n') + 1
                symbols.append(Symbol(
                    name=name,
                    kind='function',
                    signature=f"const {name} = ({params}) => ...",
                    line_start=line_num,
                    line_end=line_num
                ))

            # 提取类
            for match in self.CLASS_PATTERN.finditer(content):
                name = match.group(1)
                line_num = content[:match.start()].count('\n') + 1
                symbols.append(Symbol(
                    name=name,
                    kind='class',
                    signature=f"class {name}",
                    line_start=line_num,
                    line_end=line_num
                ))

            # 提取接口
            for match in self.INTERFACE_PATTERN.finditer(content):
                name = match.group(1)
                line_num = content[:match.start()].count('\n') + 1
                symbols.append(Symbol(
                    name=name,
                    kind='interface',
                    signature=f"interface {name}",
                    line_start=line_num,
                    line_end=line_num
                ))

            # 提取类型
            for match in self.TYPE_PATTERN.finditer(content):
                name = match.group(1)
                line_num = content[:match.start()].count('\n') + 1
                symbols.append(Symbol(
                    name=name,
                    kind='type',
                    signature=f"type {name}",
                    line_start=line_num,
                    line_end=line_num
                ))

        except Exception:
            pass
        return symbols

    def extract_summary(self, file_path: str) -> str | None:
        """提取 JS/TS 智能摘要"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            parts = []

            # 1. 基于文件名的推断
            file_name = os.path.basename(file_path)
            name_without_ext = os.path.splitext(file_name)[0]

            # 文件名模式推断
            if name_without_ext == 'index':
                parts.append("入口文件")
            elif name_without_ext == 'config':
                parts.append("配置文件")
            elif name_without_ext == 'utils' or name_without_ext.endswith('util'):
                parts.append("工具模块")
            elif name_without_ext.endswith('test') or name_without_ext.endswith('spec'):
                parts.append("测试文件")
            elif name_without_ext.endswith('handler'):
                parts.append("处理器")
            elif name_without_ext.endswith('controller'):
                parts.append("控制器")
            elif name_without_ext.endswith('service'):
                parts.append("服务层")
            elif name_without_ext.endswith('model'):
                parts.append("数据模型")
            elif name_without_ext.endswith('view') or name_without_ext.endswith('component'):
                parts.append("视图组件")

            # 2. 提取 import 语句
            imports = re.findall(r'^import\s+.*?from\s+[\'"](.+?)[\'"]', content, re.MULTILINE)
            if imports:
                # 分类导入
                external = [i for i in imports if not i.startswith('.')]
                local = [i for i in imports if i.startswith('.')]
                if external:
                    parts.append(f"依赖: {', '.join(external[:3])}")
                if local:
                    parts.append(f"本地: {len(local)} 个模块")

            # 3. 提取导出
            exports = re.findall(r'^export\s+(?:default\s+)?(?:const|let|var|function|class|interface|type)\s+(\w+)', content, re.MULTILINE)
            if exports:
                parts.append(f"导出: {', '.join(exports[:5])}")

            # 4. 统计函数和类
            functions = re.findall(r'^(?:export\s+)?(?:async\s+)?function\s+(\w+)', content, re.MULTILINE)
            classes = re.findall(r'^(?:export\s+)?class\s+(\w+)', content, re.MULTILINE)
            if functions or classes:
                stats = []
                if classes:
                    stats.append(f"{len(classes)} 类")
                if functions:
                    stats.append(f"{len(functions)} 函数")
                parts.append(" | ".join(stats))

            return " | ".join(parts) if parts else None
        except Exception:
            return None

    def extract_dependencies(self, file_path: str) -> list[Dependency]:
        """提取 JS/TS 依赖关系"""
        dependencies = []
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # 提取 import ... from 语句
            for match in self.IMPORT_PATTERN.finditer(content):
                import_statement = match.group(0)
                target_module = match.group(1)
                line_num = content[:match.start()].count('\n') + 1
                dependencies.append(Dependency(
                    import_statement=import_statement,
                    import_line=line_num,
                    dependency_type='import',
                    target_module=target_module
                ))

            # 提取 const xxx = require(...) 语句
            for match in self.REQUIRE_PATTERN.finditer(content):
                import_statement = match.group(0)
                target_module = match.group(2)
                line_num = content[:match.start()].count('\n') + 1
                dependencies.append(Dependency(
                    import_statement=import_statement,
                    import_line=line_num,
                    dependency_type='require',
                    target_module=target_module
                ))

            # 提取动态 import
            for match in self.DYNAMIC_IMPORT_PATTERN.finditer(content):
                import_statement = match.group(0)
                target_module = match.group(1)
                line_num = content[:match.start()].count('\n') + 1
                dependencies.append(Dependency(
                    import_statement=import_statement,
                    import_line=line_num,
                    dependency_type='dynamic_import',
                    target_module=target_module
                ))

        except Exception:
            pass
        return dependencies


class PythonStrategy(LanguageStrategy):
    """Python 策略"""

    # 函数
    FUNC_PATTERN = re.compile(
        r'^(?:async\s+)?def\s+(\w+)\s*\(([^)]*)\):',
        re.MULTILINE
    )
    # 类
    CLASS_PATTERN = re.compile(
        r'^class\s+(\w+)(?:\(([^)]+)\))?:',
        re.MULTILINE
    )
    # 装饰器函数
    DECORATOR_FUNC_PATTERN = re.compile(
        r'^@(\w+)\s*\n(?:async\s+)?def\s+(\w+)\s*\(([^)]*)\):',
        re.MULTILINE
    )

    def extract_symbols(self, file_path: str) -> list[Symbol]:
        """提取 Python 符号"""
        symbols = []
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # 提取函数
            for match in self.FUNC_PATTERN.finditer(content):
                name = match.group(1)
                params = match.group(2)
                line_num = content[:match.start()].count('\n') + 1
                symbols.append(Symbol(
                    name=name,
                    kind='function',
                    signature=f"def {name}({params})",
                    line_start=line_num,
                    line_end=line_num
                ))

            # 提取类
            for match in self.CLASS_PATTERN.finditer(content):
                name = match.group(1)
                base = match.group(2)
                line_num = content[:match.start()].count('\n') + 1
                signature = f"class {name}"
                if base:
                    signature += f"({base})"
                symbols.append(Symbol(
                    name=name,
                    kind='class',
                    signature=signature,
                    line_start=line_num,
                    line_end=line_num
                ))

        except Exception:
            pass
        return symbols

    def extract_summary(self, file_path: str) -> str | None:
        """提取 Python 智能摘要"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            parts = []

            # 1. 基于文件名的推断
            file_name = os.path.basename(file_path)
            name_without_ext = os.path.splitext(file_name)[0]

            # 文件名模式推断
            if name_without_ext == '__init__':
                parts.append("包初始化文件")
            elif name_without_ext == 'setup' or name_without_ext == 'install':
                parts.append("安装配置")
            elif name_without_ext == 'config':
                parts.append("配置文件")
            elif name_without_ext.endswith('test') or name_without_ext.endswith('_test'):
                parts.append("测试文件")
            elif name_without_ext.endswith('utils') or name_without_ext.endswith('helpers'):
                parts.append("工具模块")
            elif name_without_ext.endswith('models'):
                parts.append("数据模型")
            elif name_without_ext.endswith('views'):
                parts.append("视图层")
            elif name_without_ext.endswith('controllers'):
                parts.append("控制器")
            elif name_without_ext.endswith('services'):
                parts.append("服务层")

            # 2. 提取 import
            imports = re.findall(r'^import\s+([\w.]+)', content, re.MULTILINE)
            from_imports = re.findall(r'^from\s+([\w.]+)\s+import', content, re.MULTILINE)

            all_imports = list(set(imports + from_imports))
            if all_imports:
                # 分类导入
                stdlib = ['os', 'sys', 're', 'json', 'time', 'datetime', 'collections',
                         'itertools', 'functools', 'typing', 'pathlib', 'argparse']
                external = [i for i in all_imports if i not in stdlib]
                std_imports = [i for i in all_imports if i in stdlib]

                if external:
                    parts.append(f"依赖: {', '.join(external[:3])}")
                if std_imports and len(std_imports) <= 3:
                    parts.append(f"标准库: {', '.join(std_imports)}")

            # 3. 提取 class 和 def
            classes = re.findall(r'^class\s+(\w+)', content, re.MULTILINE)
            functions = re.findall(r'^def\s+(\w+)', content, re.MULTILINE)
            async_functions = re.findall(r'^async def\s+(\w+)', content, re.MULTILINE)

            if classes or functions or async_functions:
                stats = []
                if classes:
                    stats.append(f"{len(classes)} 类")
                if functions:
                    stats.append(f"{len(functions)} 函数")
                if async_functions:
                    stats.append(f"{len(async_functions)} 异步函数")
                parts.append(" | ".join(stats))

            # 4. 主要导出（类/函数）
            if classes:
                parts.append(f"导出类: {classes[0]}")
            elif functions:
                parts.append(f"导出函数: {functions[0]}")

            return " | ".join(parts) if parts else None
        except Exception:
            return None

    # Python import 正则
    IMPORT_PATTERN = re.compile(
        r'^import\s+([\w.]+)',
        re.MULTILINE
    )
    FROM_IMPORT_PATTERN = re.compile(
        r'^from\s+([\w.]+)\s+import',
        re.MULTILINE
    )

    def extract_dependencies(self, file_path: str) -> list[Dependency]:
        """提取 Python 依赖关系"""
        dependencies = []
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # 提取 import xxx
            for match in self.IMPORT_PATTERN.finditer(content):
                import_statement = match.group(0)
                target_module = match.group(1)
                line_num = content[:match.start()].count('\n') + 1
                dependencies.append(Dependency(
                    import_statement=import_statement,
                    import_line=line_num,
                    dependency_type='import',
                    target_module=target_module
                ))

            # 提取 from xxx import
            for match in self.FROM_IMPORT_PATTERN.finditer(content):
                import_statement = match.group(0)
                target_module = match.group(1)
                line_num = content[:match.start()].count('\n') + 1
                dependencies.append(Dependency(
                    import_statement=import_statement,
                    import_line=line_num,
                    dependency_type='from_import',
                    target_module=target_module
                ))

        except Exception:
            pass
        return dependencies


class IndexEngine:
    """索引引擎 - 管理语言策略"""

    # 扩展名到策略的映射
    STRATEGIES = {
        '.js': JavaScriptStrategy(),
        '.jsx': JavaScriptStrategy(),
        '.ts': JavaScriptStrategy(),
        '.tsx': JavaScriptStrategy(),
        '.mjs': JavaScriptStrategy(),
        '.cjs': JavaScriptStrategy(),
        '.py': PythonStrategy(),
    }

    # 扩展名到语言的映射
    EXT_TO_LANG = {
        '.js': 'JavaScript',
        '.jsx': 'JavaScript',
        '.ts': 'TypeScript',
        '.tsx': 'TypeScript',
        '.mjs': 'JavaScript',
        '.cjs': 'JavaScript',
        '.py': 'Python',
    }

    @classmethod
    def get_strategy(cls, extension: str) -> LanguageStrategy | None:
        """获取语言策略"""
        return cls.STRATEGIES.get(extension.lower())

    @classmethod
    def get_language(cls, extension: str) -> str | None:
        """获取语言名称"""
        return cls.EXT_TO_LANG.get(extension.lower())

    @classmethod
    def extract_symbols(cls, file_path: str) -> list[Symbol]:
        """提取符号"""
        ext = os.path.splitext(file_path)[1]
        strategy = cls.get_strategy(ext)
        if strategy:
            return strategy.extract_symbols(file_path)
        return []

    @classmethod
    def extract_summary(cls, file_path: str) -> str | None:
        """提取摘要"""
        ext = os.path.splitext(file_path)[1]
        strategy = cls.get_strategy(ext)
        if strategy:
            return strategy.extract_summary(file_path)
        return None

    @classmethod
    def extract_dependencies(cls, file_path: str) -> list[Dependency]:
        """提取依赖关系"""
        ext = os.path.splitext(file_path)[1]
        strategy = cls.get_strategy(ext)
        if strategy:
            return strategy.extract_dependencies(file_path)
        return []
