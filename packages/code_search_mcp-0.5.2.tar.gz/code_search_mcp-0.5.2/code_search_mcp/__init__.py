"""Code Search MCP - 将本地代码库转换为SQLite索引，提供高效的混合搜索能力"""

from code_search_mcp.server import CodeIndexServer

__all__ = ["CodeIndexServer"]
