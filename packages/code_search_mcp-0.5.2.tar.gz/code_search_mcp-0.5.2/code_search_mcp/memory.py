"""会话上下文记忆模块 - 记住看过的文件和结论"""
import threading
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class FileMemory:
    """文件记忆条目"""
    path: str
    summary: str
    symbols: list[dict] = field(default_factory=list)
    viewed_at: datetime = field(default_factory=datetime.now)
    conclusions: list[str] = field(default_factory=list)


@dataclass
class SearchHistory:
    """搜索历史条目"""
    query: str
    results_count: int
    timestamp: datetime = field(default_factory=datetime.now)


class SessionMemory:
    """会话上下文记忆 - 内存缓存"""

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        """单例模式 - 确保全局只有一个内存实例"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return

        self.viewed_files: dict[str, FileMemory] = {}
        self.file_summaries: dict[str, str] = {}
        self.analysis_conclusions: list[dict] = []
        self.search_history: list[SearchHistory] = []
        self._initialized = True

    def remember_file(self, path: str, summary: str = "", symbols: list[dict] = None,
                     conclusions: list[str] = None):
        """记住看过的文件

        Args:
            path: 文件路径
            summary: 文件摘要
            symbols: 文件中的符号列表
            conclusions: 分析结论
        """
        if symbols is None:
            symbols = []
        if conclusions is None:
            conclusions = []

        self.viewed_files[path] = FileMemory(
            path=path,
            summary=summary,
            symbols=symbols,
            conclusions=conclusions
        )
        self.file_summaries[path] = summary

    def has_viewed(self, path: str) -> bool:
        """检查是否已经看过此文件"""
        return path in self.viewed_files

    def get_file_memory(self, path: str) -> FileMemory | None:
        """获取文件记忆"""
        return self.viewed_files.get(path)

    def add_conclusion(self, conclusion: dict):
        """添加分析结论

        Args:
            conclusion: 结论字典，包含 type, content 等
        """
        conclusion["timestamp"] = datetime.now().isoformat()
        self.analysis_conclusions.append(conclusion)

    def add_search(self, query: str, results_count: int):
        """记录搜索历史"""
        self.search_history.append(SearchHistory(
            query=query,
            results_count=results_count
        ))

    def get_memory(self) -> dict:
        """获取当前会话记忆"""
        return {
            "viewed_files": [
                {
                    "path": fm.path,
                    "summary": fm.summary,
                    "symbols_count": len(fm.symbols),
                    "viewed_at": fm.viewed_at.isoformat(),
                    "conclusions": fm.conclusions
                }
                for fm in self.viewed_files.values()
            ],
            "file_count": len(self.viewed_files),
            "conclusions_count": len(self.analysis_conclusions),
            "search_history": [
                {
                    "query": sh.query,
                    "results_count": sh.results_count,
                    "timestamp": sh.timestamp.isoformat()
                }
                for sh in self.search_history[-20:]  # 只返回最近20条
            ]
        }

    def clear(self):
        """清除所有会话记忆"""
        self.viewed_files.clear()
        self.file_summaries.clear()
        self.analysis_conclusions.clear()
        self.search_history.clear()


# 全局实例
_session_memory: SessionMemory | None = None


def get_session_memory() -> SessionMemory:
    """获取会话记忆全局实例"""
    global _session_memory
    if _session_memory is None:
        _session_memory = SessionMemory()
    return _session_memory
