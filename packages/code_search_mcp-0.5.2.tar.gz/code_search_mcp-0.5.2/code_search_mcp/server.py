"""MCP 服务器 - 提供代码索引和搜索工具"""
import json
import os
import time
from typing import Any

from mcp.server import InitializationOptions, Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from .database import Database
from .indexer import Indexer
from .logger import get_logger
from .memory import get_session_memory


class CodeIndexServer:
    """Code Search MCP 服务器"""

    def __init__(self):
        """初始化服务器"""
        self.db = Database()
        self.indexer = Indexer(self.db)
        self.logger = get_logger()
        self.session_memory = get_session_memory()
        self.server = Server("code-search-mcp")

        self._register_handlers()

    def _register_handlers(self):
        """注册工具处理器"""

        @self.server.list_tools()
        async def list_tools() -> list[Tool]:
            """列出所有可用工具"""
            return [
                Tool(
                    name="index_repository",
                    description="索引整个代码库到SQLite数据库",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "repo_path": {
                                "type": "string",
                                "description": "代码库路径"
                            },
                            "force_rebuild": {
                                "type": "boolean",
                                "description": "是否强制重建索引",
                                "default": False
                            }
                        },
                        "required": ["repo_path"]
                    }
                ),
                Tool(
                    name="find_files",
                    description="按文件名或路径搜索文件",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "query": {
                                "type": "string",
                                "description": "搜索关键词"
                            },
                            "extensions": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "文件扩展名过滤",
                                "default": []
                            },
                            "limit": {
                                "type": "number",
                                "description": "返回结果数量",
                                "default": 20
                            },
                            "min_score": {
                                "type": "number",
                                "description": "最低置信度过滤 (0-100)",
                                "default": 0
                            }
                        }
                    }
                ),
                Tool(
                    name="find_symbols",
                    description="搜索代码符号（函数、类、变量等）",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "query": {
                                "type": "string",
                                "description": "符号名称"
                            },
                            "kind": {
                                "type": "string",
                                "enum": ["function", "class", "variable", "method", "all"],
                                "description": "符号类型",
                                "default": "all"
                            },
                            "file": {
                                "type": "string",
                                "description": "限定文件范围"
                            },
                            "limit": {
                                "type": "number",
                                "description": "返回数量",
                                "default": 20
                            },
                            "min_score": {
                                "type": "number",
                                "description": "最低置信度过滤 (0-100)",
                                "default": 0
                            }
                        }
                    }
                ),
                Tool(
                    name="find_content",
                    description="按代码内容搜索",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "query": {
                                "type": "string",
                                "description": "搜索内容"
                            },
                            "regex": {
                                "type": "boolean",
                                "description": "是否使用正则",
                                "default": False
                            },
                            "file_pattern": {
                                "type": "string",
                                "description": "文件过滤"
                            },
                            "context_lines": {
                                "type": "number",
                                "description": "上下文行数",
                                "default": 3
                            },
                            "limit": {
                                "type": "number",
                                "description": "返回数量",
                                "default": 20
                            }
                        },
                        "required": ["query"]
                    }
                ),
                Tool(
                    name="get_structure",
                    description="获取文件的代码结构",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "file_path": {
                                "type": "string",
                                "description": "文件路径"
                            }
                        },
                        "required": ["file_path"]
                    }
                ),
                Tool(
                    name="get_stats",
                    description="获取索引统计信息",
                    inputSchema={
                        "type": "object",
                        "properties": {}
                    }
                ),
                Tool(
                    name="get_logs",
                    description="查询工具调用日志",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "tool_name": {
                                "type": "string",
                                "description": "工具名称过滤"
                            },
                            "start_time": {
                                "type": "string",
                                "description": "开始时间 (ISO格式)"
                            },
                            "end_time": {
                                "type": "string",
                                "description": "结束时间 (ISO格式)"
                            },
                            "success": {
                                "type": "boolean",
                                "description": "是否成功"
                            },
                            "limit": {
                                "type": "number",
                                "description": "返回数量限制",
                                "default": 100
                            }
                        }
                    }
                ),
                Tool(
                    name="get_call_stats",
                    description="获取工具调用统计信息",
                    inputSchema={
                        "type": "object",
                        "properties": {}
                    }
                ),
                Tool(
                    name="get_suggestions",
                    description="获取智能搜索建议。基于代码模式关联和符号分析，提供相关搜索建议",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "query": {
                                "type": "string",
                                "description": "当前搜索词"
                            },
                            "limit": {
                                "type": "integer",
                                "description": "返回建议数量",
                                "default": 10
                            }
                        },
                        "required": ["query"]
                    }
                ),
                Tool(
                    name="get_dependencies",
                    description="获取文件的依赖关系（此文件导入的模块）",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "file_path": {
                                "type": "string",
                                "description": "文件路径"
                            }
                        },
                        "required": ["file_path"]
                    }
                ),
                Tool(
                    name="get_dependents",
                    description="获取依赖此文件的文件（反向依赖 - 哪些文件导入此文件）",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "file_path": {
                                "type": "string",
                                "description": "文件路径"
                            }
                        },
                        "required": ["file_path"]
                    }
                ),
                Tool(
                    name="get_memory",
                    description="获取当前会话记忆 - 已查看的文件和结论",
                    inputSchema={
                        "type": "object",
                        "properties": {}
                    }
                ),
                Tool(
                    name="clear_memory",
                    description="清除会话记忆 - 清空所有已记住的文件和结论",
                    inputSchema={
                        "type": "object",
                        "properties": {}
                    }
                ),
                Tool(
                    name="remember_file",
                    description="记住文件分析结果 - 将文件分析结论存入记忆",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "file_path": {
                                "type": "string",
                                "description": "文件路径"
                            },
                            "summary": {
                                "type": "string",
                                "description": "文件摘要"
                            },
                            "conclusions": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "分析结论列表"
                            }
                        },
                        "required": ["file_path"]
                    }
                )
            ]

        @self.server.call_tool()
        async def call_tool(name: str, arguments: dict | None) -> list[TextContent]:
            """调用工具"""
            if arguments is None:
                arguments = {}

            # 记录开始时间
            start_time = time.time()
            tool_name = name
            query_str = json.dumps(arguments)[:500] if arguments else ""

            try:
                result = await self._handle_tool(name, arguments)

                # 计算执行时间
                duration_ms = (time.time() - start_time) * 1000

                # 获取结果数量
                result_count = 0
                if isinstance(result, dict):
                    if "files" in result:
                        result_count = len(result.get("files", []))
                    elif "symbols" in result:
                        result_count = len(result.get("symbols", []))
                    elif "matches" in result:
                        result_count = len(result.get("matches", []))
                    elif "structure" in result:
                        result_count = len(result.get("structure", []))
                    elif "stats" in result:
                        result_count = 1

                # 记录日志
                self.logger.log(
                    tool_name=tool_name,
                    duration_ms=duration_ms,
                    result_count=result_count,
                    query=query_str,
                    success=True
                )

                return [TextContent(type="text", text=str(result))]
            except Exception as e:
                # 计算执行时间
                duration_ms = (time.time() - start_time) * 1000

                # 记录错误日志
                self.logger.log(
                    tool_name=tool_name,
                    duration_ms=duration_ms,
                    result_count=0,
                    query=query_str,
                    success=False,
                    error_message=str(e)
                )

                return [TextContent(type="text", text=f"错误: {str(e)}")]

    async def _handle_tool(self, name: str, arguments: dict) -> Any:
        """处理工具调用"""
        if name == "index_repository":
            return await self._index_repository(arguments)
        elif name == "find_files":
            return await self._find_files(arguments)
        elif name == "find_symbols":
            return await self._find_symbols(arguments)
        elif name == "find_content":
            return await self._find_content(arguments)
        elif name == "get_structure":
            return await self._get_structure(arguments)
        elif name == "get_stats":
            return await self._get_stats(arguments)
        elif name == "get_logs":
            return await self._get_logs(arguments)
        elif name == "get_call_stats":
            return await self._get_call_stats(arguments)
        elif name == "get_suggestions":
            return await self._get_suggestions(arguments)
        elif name == "get_dependencies":
            return await self._get_dependencies(arguments)
        elif name == "get_dependents":
            return await self._get_dependents(arguments)
        elif name == "get_memory":
            return await self._get_memory(arguments)
        elif name == "clear_memory":
            return await self._clear_memory(arguments)
        elif name == "remember_file":
            return await self._remember_file(arguments)
        else:
            raise ValueError(f"未知工具: {name}")

    async def _index_repository(self, args: dict) -> dict:
        """索引代码库"""
        repo_path = args["repo_path"]
        force_rebuild = args.get("force_rebuild", False)

        if not os.path.isabs(repo_path):
            repo_path = os.path.abspath(repo_path)

        result = self.indexer.index_repository(repo_path, force_rebuild)
        return result

    async def _find_files(self, args: dict) -> dict:
        """搜索文件"""
        query = args.get("query")
        extensions = args.get("extensions")
        limit = args.get("limit", 20)
        min_score = args.get("min_score", 0)

        files = self.db.find_files(query, extensions, limit, min_score)

        return {
            "files": [
                {
                    "path": f["path"],
                    "name": f["name"],
                    "type": f["type"],
                    "size": f["size"],
                    "modified": f["modified"],
                    "confidence": f.get("confidence", 50)
                }
                for f in files
            ]
        }

    async def _find_symbols(self, args: dict) -> dict:
        """搜索符号"""
        query = args.get("query")
        kind = args.get("kind", "all")
        file_path = args.get("file")
        limit = args.get("limit", 20)
        min_score = args.get("min_score", 0)

        file_id = None
        if file_path:
            file_record = self.db.get_file_by_path(file_path)
            if file_record:
                file_id = file_record.id

        # 处理 kind 参数
        kind_filter = None if kind == "all" else kind

        symbols = self.db.find_symbols(query, kind_filter, file_id, limit, min_score)

        return {
            "symbols": [
                {
                    "name": s["name"],
                    "kind": s["kind"],
                    "file": s["file_path"],
                    "line": s["line_start"],
                    "signature": s["signature"],
                    "confidence": s.get("confidence", 50)
                }
                for s in symbols
            ]
        }

    async def _find_content(self, args: dict) -> dict:
        """搜索内容"""
        query = args["query"]
        regex = args.get("regex", False)
        file_pattern = args.get("file_pattern")
        limit = args.get("limit", 20)

        matches = self.db.find_content(query, regex, file_pattern, limit)

        return {
            "matches": [
                {
                    "file": m["file_path"],
                    "line": m["line_number"],
                    "content": m["content"]
                }
                for m in matches
            ]
        }

    async def _get_structure(self, args: dict) -> dict:
        """获取文件结构"""
        file_path = args["file_path"]

        if not os.path.isabs(file_path):
            file_path = os.path.abspath(file_path)

        structure = self.indexer.get_file_structure(file_path)
        return {
            "structure": structure
        }

    async def _get_stats(self, args: dict) -> dict:
        """获取统计信息"""
        stats = self.db.get_stats()
        return {"stats": stats}

    async def _get_logs(self, args: dict) -> dict:
        """查询日志"""
        tool_name = args.get("tool_name")
        start_time = args.get("start_time")
        end_time = args.get("end_time")
        success = args.get("success")
        limit = args.get("limit", 100)

        logs = self.logger.get_logs(
            tool_name=tool_name,
            start_time=start_time,
            end_time=end_time,
            success=success,
            limit=limit
        )
        return {"logs": logs}

    async def _get_call_stats(self, args: dict) -> dict:
        """获取调用统计"""
        stats = self.logger.get_stats()
        return {"call_stats": stats}

    async def _get_suggestions(self, args: dict) -> dict:
        """获取智能搜索建议"""
        query = args.get("query", "")
        limit = args.get("limit", 10)

        suggestions = self.db.get_suggestions(query, limit)
        return {"suggestions": suggestions}

    async def _get_dependencies(self, args: dict) -> dict:
        """获取文件的依赖关系"""
        file_path = args["file_path"]

        if not os.path.isabs(file_path):
            file_path = os.path.abspath(file_path)

        dependencies = self.db.get_dependencies(file_path)

        return {
            "dependencies": [
                {
                    "import_statement": d["import_statement"],
                    "line": d["import_line"],
                    "type": d["dependency_type"],
                    "target": d.get("target_path") or d.get("target_name") or d["import_statement"].split()[-1].strip("'\""),
                    "is_indexed": d["target_file_id"] is not None
                }
                for d in dependencies
            ]
        }

    async def _get_dependents(self, args: dict) -> dict:
        """获取依赖此文件的文件（反向依赖）"""
        file_path = args["file_path"]

        if not os.path.isabs(file_path):
            file_path = os.path.abspath(file_path)

        dependents = self.db.get_dependents(file_path)

        return {
            "dependents": [
                {
                    "file": d.get("source_path"),
                    "import_statement": d["import_statement"],
                    "line": d["import_line"],
                    "type": d["dependency_type"]
                }
                for d in dependents
            ]
        }

    async def _get_memory(self, args: dict) -> dict:
        """获取会话记忆"""
        memory = self.session_memory.get_memory()
        return {"memory": memory}

    async def _clear_memory(self, args: dict) -> dict:
        """清除会话记忆"""
        self.session_memory.clear()
        return {"success": True, "message": "会话记忆已清除"}

    async def _remember_file(self, args: dict) -> dict:
        """记住文件分析结果"""
        file_path = args.get("file_path")
        summary = args.get("summary", "")
        conclusions = args.get("conclusions", [])

        if not file_path:
            return {"error": "file_path is required"}

        if not os.path.isabs(file_path):
            file_path = os.path.abspath(file_path)

        # 获取文件符号
        symbols = []
        file_record = self.db.get_file_by_path(file_path)
        if file_record:
            symbols_data = self.db.find_symbols(file_id=file_record.id, limit=100)
            symbols = [
                {
                    "name": s["name"],
                    "kind": s["kind"],
                    "line": s["line_start"]
                }
                for s in symbols_data
            ]

        self.session_memory.remember_file(
            path=file_path,
            summary=summary,
            symbols=symbols,
            conclusions=conclusions
        )

        return {
            "success": True,
            "message": f"已记住文件: {file_path}",
            "file_count": self.session_memory.get_memory()["file_count"]
        }

    async def run(self):
        """运行服务器"""
        async with stdio_server() as (read_stream, write_stream):
            await self.server.run(
                read_stream,
                write_stream,
                InitializationOptions(
                    server_name="code-search-mcp",
                    server_version="0.1.0",
                    capabilities={}
                )
            )


async def main():
    """主入口"""
    server = CodeIndexServer()
    await server.run()


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
