"""日志系统 - 用于监控索引和搜索调用的日志"""
import sqlite3
from collections import deque
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from datetime import datetime
from enum import Enum


class LogLevel(Enum):
    """日志级别"""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"


@dataclass
class LogEntry:
    """日志条目"""
    id: int | None = None
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    tool_name: str = ""
    duration_ms: float = 0
    result_count: int = 0
    query: str = ""
    success: bool = True
    error_message: str = ""
    level: str = "INFO"


class Logger:
    """日志系统 - 同时使用内存缓冲和SQLite存储"""

    SCHEMA = """
    CREATE TABLE IF NOT EXISTS logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL,
        tool_name TEXT NOT NULL,
        duration_ms REAL,
        result_count INTEGER DEFAULT 0,
        query TEXT,
        success INTEGER DEFAULT 1,
        error_message TEXT,
        level TEXT DEFAULT 'INFO'
    );

    CREATE INDEX IF NOT EXISTS idx_logs_tool_name ON logs(tool_name);
    CREATE INDEX IF NOT EXISTS idx_logs_timestamp ON logs(timestamp);
    CREATE INDEX IF NOT EXISTS idx_logs_success ON logs(success);
    """

    def __init__(self, db_path: str | None = None, memory_limit: int = 1000):
        """初始化日志系统

        Args:
            db_path: SQLite数据库路径，默认为 ~/.code-index/logs.db
            memory_limit: 内存缓冲的最大日志数
        """
        if db_path is None:
            import os
            home = os.path.expanduser("~")
            index_dir = os.path.join(home, ".code-index")
            os.makedirs(index_dir, exist_ok=True)
            db_path = os.path.join(index_dir, "logs.db")

        self.db_path = db_path
        self._memory_buffer: deque[LogEntry] = deque(maxlen=memory_limit)
        self._init_db()

    def _init_db(self):
        """初始化数据库schema"""
        with self.get_connection() as conn:
            conn.executescript(self.SCHEMA)

    @contextmanager
    def get_connection(self):
        """获取数据库连接"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def log(self, tool_name: str, duration_ms: float, result_count: int = 0,
            query: str = "", success: bool = True, error_message: str = "",
            level: str = "INFO") -> LogEntry:
        """记录日志

        Args:
            tool_name: 工具名称
            duration_ms: 执行时间（毫秒）
            result_count: 结果数量
            query: 查询内容
            success: 是否成功
            error_message: 错误信息
            level: 日志级别

        Returns:
            创建的日志条目
        """
        # 确定日志级别
        if not success:
            log_level = "ERROR"
        elif duration_ms > 5000:
            log_level = "WARNING"
        else:
            log_level = level

        entry = LogEntry(
            timestamp=datetime.now().isoformat(),
            tool_name=tool_name,
            duration_ms=duration_ms,
            result_count=result_count,
            query=query[:500] if query else "",  # 截断过长的查询
            success=success,
            error_message=error_message[:500] if error_message else "",  # 截断过长的错误
            level=log_level
        )

        # 存入内存缓冲
        self._memory_buffer.append(entry)

        # 持久化到数据库
        self._persist_entry(entry)

        return entry

    def _persist_entry(self, entry: LogEntry):
        """持久化日志到数据库"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO logs (timestamp, tool_name, duration_ms, result_count, query, success, error_message, level)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                entry.timestamp,
                entry.tool_name,
                entry.duration_ms,
                entry.result_count,
                entry.query,
                1 if entry.success else 0,
                entry.error_message,
                entry.level
            ))

    def get_logs(self, tool_name: str | None = None,
                 start_time: str | None = None,
                 end_time: str | None = None,
                 success: bool | None = None,
                 limit: int = 100) -> list[dict]:
        """查询日志

        Args:
            tool_name: 工具名称过滤
            start_time: 开始时间 (ISO格式)
            end_time: 结束时间 (ISO格式)
            success: 成功/失败过滤
            limit: 返回数量限制

        Returns:
            日志列表
        """
        sql = "SELECT * FROM logs WHERE 1=1"
        params = []

        if tool_name:
            sql += " AND tool_name = ?"
            params.append(tool_name)

        if start_time:
            sql += " AND timestamp >= ?"
            params.append(start_time)

        if end_time:
            sql += " AND timestamp <= ?"
            params.append(end_time)

        if success is not None:
            sql += " AND success = ?"
            params.append(1 if success else 0)

        sql += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        with self.get_connection() as conn:
            rows = conn.execute(sql, params).fetchall()
            return [dict(row) for row in rows]

    def get_stats(self) -> dict:
        """获取调用统计

        Returns:
            统计信息
        """
        with self.get_connection() as conn:
            # 总调用数
            total = conn.execute("SELECT COUNT(*) FROM logs").fetchone()[0]

            # 成功/失败数
            success_count = conn.execute("SELECT COUNT(*) FROM logs WHERE success = 1").fetchone()[0]
            error_count = conn.execute("SELECT COUNT(*) FROM logs WHERE success = 0").fetchone()[0]

            # 按工具统计
            tool_stats = conn.execute("""
                SELECT tool_name, COUNT(*) as count,
                       AVG(duration_ms) as avg_duration,
                       MAX(duration_ms) as max_duration,
                       SUM(result_count) as total_results
                FROM logs
                GROUP BY tool_name
            """).fetchall()

            # 平均响应时间
            avg_duration = conn.execute("SELECT AVG(duration_ms) FROM logs").fetchone()[0] or 0

            return {
                "total_calls": total,
                "success_count": success_count,
                "error_count": error_count,
                "success_rate": round(success_count / total * 100, 2) if total > 0 else 0,
                "avg_duration_ms": round(avg_duration, 2),
                "by_tool": [dict(row) for row in tool_stats]
            }

    def clear_old_logs(self, days: int = 7):
        """清理旧日志

        Args:
            days: 保留天数
        """
        from datetime import timedelta
        cutoff = (datetime.now() - timedelta(days=days)).isoformat()

        with self.get_connection() as conn:
            conn.execute("DELETE FROM logs WHERE timestamp < ?", (cutoff,))

    def get_recent_logs(self, limit: int = 50) -> list[dict]:
        """获取最近的日志（从内存缓冲）

        Args:
            limit: 返回数量

        Returns:
            最近的日志列表
        """
        # 从内存缓冲获取最新日志
        buffer_list = list(self._memory_buffer)[-limit:]
        return [asdict(entry) for entry in buffer_list]


# 全局日志实例
_logger: Logger | None = None


def get_logger() -> Logger:
    """获取全局日志实例"""
    global _logger
    if _logger is None:
        _logger = Logger()
    return _logger
