"""Code Search MCP 服务器入口"""
import asyncio

from .server import main


def run():
    """运行服务器"""
    asyncio.run(main())


if __name__ == "__main__":
    run()
