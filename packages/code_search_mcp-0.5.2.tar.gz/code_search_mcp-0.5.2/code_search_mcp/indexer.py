"""索引引擎 - 整合 shell 工具和语言策略进行代码索引"""
import os
import time
from typing import Generator

from .database import Database
from .strategies import IndexEngine


class Indexer:
    """索引引擎"""

    # 需要索引的文件扩展名
    INDEXED_EXTENSIONS = {
        '.js', '.jsx', '.ts', '.tsx', '.mjs', '.cjs',
        '.py', '.go', '.rs', '.java', '.c', '.cpp', '.h', '.hpp',
        '.rb', '.php', '.swift', '.kt', '.scala', '.vue', '.svelte'
    }

    # 忽略的目录
    IGNORED_DIRS = {
        'node_modules', '.git', '__pycache__', '.venv', 'venv',
        'dist', 'build', '.next', '.nuxt', 'target', 'coverage',
        '.pytest_cache', '.mypy_cache', '.tox', '.eggs', '*.egg-info'
    }

    def __init__(self, db: Database):
        """初始化索引引擎

        Args:
            db: 数据库实例
        """
        self.db = db

    def index_repository(self, repo_path: str, force_rebuild: bool = False,
                        verbose: bool = True) -> dict:
        """索引整个代码库

        Args:
            repo_path: 代码库路径
            force_rebuild: 是否强制重建索引
            verbose: 是否显示详细输出

        Returns:
            索引统计
        """
        repo_path = os.path.abspath(repo_path)

        if not os.path.isdir(repo_path):
            raise ValueError(f"路径不存在: {repo_path}")

        # 如果强制重建，先清空数据
        if force_rebuild:
            if verbose:
                print("强制重建索引...")
            self.db.clear_all()
            indexed_files = {}
        else:
            # 增量索引：获取已索引的文件
            indexed_files = self.db.get_all_indexed_files(repo_path)
            if verbose:
                print(f"已有索引文件: {len(indexed_files)}")

        start_time = time.time()
        files_indexed = 0
        files_skipped = 0
        symbols_indexed = 0
        content_blocks = 0

        # 收集当前仓库中的所有文件
        current_files = set()
        all_files = list(self._iterate_files(repo_path))

        if verbose:
            print(f"需要检查的文件: {len(all_files)}")

        # 遍历所有文件
        for i, file_path in enumerate(all_files):
            try:
                # 检查文件修改时间
                stat = os.stat(file_path)
                modified_time = int(stat.st_mtime)

                current_files.add(file_path)

                # 检查是否需要重新索引
                existing = indexed_files.get(file_path)
                if existing:
                    if existing.modified_time == modified_time:
                        # 文件未变更，跳过
                        files_skipped += 1
                        continue

                # 索引文件
                result = self._index_file(file_path)
                if result:
                    files_indexed += 1
                    symbols_indexed += result['symbols']
                    content_blocks += result['content_blocks']

                if verbose and (i + 1) % 100 == 0:
                    print(f"  已处理 {i + 1}/{len(all_files)} 文件...")

            except Exception as e:
                if verbose:
                    print(f"索引文件失败 {file_path}: {e}")

        # 清理已删除的文件
        deleted_files = set(indexed_files.keys()) - current_files
        files_deleted = 0
        for file_path in deleted_files:
            existing = indexed_files[file_path]
            if existing and existing.id:
                self.db.delete_file(existing.id)
                files_deleted += 1

        elapsed = time.time() - start_time

        stats = {
            "files_indexed": files_indexed,
            "files_skipped": files_skipped,
            "files_deleted": files_deleted,
            "symbols": symbols_indexed,
            "content_blocks": content_blocks,
            "elapsed_seconds": round(elapsed, 2)
        }

        if verbose:
            print("\n索引完成:")
            print(f"  新增/更新: {files_indexed}")
            print(f"  跳过(未变更): {files_skipped}")
            print(f"  删除: {files_deleted}")
            print(f"  耗时: {elapsed:.2f}s")

        return {
            "success": True,
            "stats": stats,
            "is_incremental": not force_rebuild and len(indexed_files) > 0
        }

    def _iterate_files(self, root_path: str) -> Generator[str, None, None]:
        """遍历需要索引的文件"""
        for dirpath, dirnames, filenames in os.walk(root_path):
            # 过滤忽略的目录
            dirnames[:] = [d for d in dirnames if d not in self.IGNORED_DIRS]

            for filename in filenames:
                file_path = os.path.join(dirpath, filename)
                ext = os.path.splitext(filename)[1].lower()

                if ext in self.INDEXED_EXTENSIONS:
                    yield file_path

    def _index_file(self, file_path: str) -> dict | None:
        """索引单个文件

        Returns:
            索引结果统计
        """
        # 获取文件信息
        stat = os.stat(file_path)
        size = stat.st_size
        modified_time = int(stat.st_mtime)

        ext = os.path.splitext(file_path)[1].lower()
        name = os.path.basename(file_path)
        language = IndexEngine.get_language(ext)

        # 检查文件是否已存在
        existing = self.db.get_file_by_path(file_path)

        if existing:
            # 如果文件未修改，跳过
            if existing.modified_time == modified_time:
                return None
            # 否则删除旧记录
            self.db.delete_file(existing.id)

        # 插入文件记录
        file_id = self.db.insert_file(
            path=file_path,
            name=name,
            extension=ext,
            language=language,
            size=size,
            modified_time=modified_time
        )

        # 提取符号
        symbols = IndexEngine.extract_symbols(file_path)
        symbols_count = 0
        for symbol in symbols:
            self.db.insert_symbol(
                file_id=file_id,
                name=symbol.name,
                kind=symbol.kind,
                signature=symbol.signature,
                line_start=symbol.line_start,
                line_end=symbol.line_end
            )
            symbols_count += 1

        # 提取内容
        content_count = 0
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()

            # 批量插入内容
            content_records = []
            for line_num, line in enumerate(lines, start=1):
                content_records.append((file_id, line_num, line.rstrip('\n')))

            if content_records:
                self.db.insert_content_batch(content_records)
                content_count = len(content_records)
        except Exception:
            pass

        # 提取摘要
        summary = IndexEngine.extract_summary(file_path)
        if summary:
            self.db.insert_summary(file_id=file_id, summary=summary)

        # 提取依赖关系
        self._index_dependencies(file_path, file_id)

        return {
            "symbols": symbols_count,
            "content_blocks": content_count
        }

    def _index_dependencies(self, file_path: str, file_id: int):
        """索引文件依赖关系

        Args:
            file_path: 文件路径
            file_id: 文件ID
        """
        import os
        # 先删除旧的依赖关系
        self.db.delete_dependencies_by_file(file_id)

        # 提取依赖
        dependencies = IndexEngine.extract_dependencies(file_path)
        if not dependencies:
            return

        # 获取文件所在目录，用于解析相对路径
        file_dir = os.path.dirname(file_path)

        # 准备批量插入
        records = []
        for dep in dependencies:
            target_module = dep.target_module
            target_file_id = None

            # 尝试解析相对路径为文件ID
            if target_module.startswith('.'):
                # 相对导入，尝试解析为实际文件
                target_path = self._resolve_relative_import(file_dir, target_module)
                if target_path and os.path.exists(target_path):
                    target_record = self.db.get_file_by_path(target_path)
                    if target_record:
                        target_file_id = target_record.id

            records.append((
                file_id,
                target_file_id,
                dep.import_statement,
                dep.import_line,
                dep.dependency_type
            ))

        if records:
            self.db.insert_dependencies_batch(records)

    def _resolve_relative_import(self, from_dir: str, target_module: str) -> str | None:
        """解析相对导入路径

        Args:
            from_dir: 导入文件所在目录
            target_module: 目标模块（如 ./utils, ../models）

        Returns:
            解析后的文件路径
        """
        import os

        # 移除开头的 . 或 ..
        module = target_module.lstrip('.')

        # 处理 ../
        dots = len(target_module) - len(target_module.lstrip('.'))
        if dots >= 2:
            # 计算需要向上多少级
            up_levels = dots // 2
            parts = from_dir.split(os.sep)
            if len(parts) > up_levels:
                from_dir = os.sep.join(parts[:-up_levels])
            else:
                return None

        # 拼接模块路径
        if module.startswith('/'):
            module = module[1:]

        # 尝试添加各种扩展名
        for ext in ['', '.js', '.ts', '.jsx', '.tsx', '.py', '/__init__.py']:
            test_path = os.path.join(from_dir, module + ext)
            if os.path.exists(test_path):
                return os.path.abspath(test_path)

            # 尝试作为目录的 index 文件
            index_path = os.path.join(from_dir, module, '__init__.py')
            if os.path.exists(index_path):
                return index_path

        return None

    def get_file_structure(self, file_path: str) -> dict:
        """获取文件的代码结构

        Args:
            file_path: 文件路径

        Returns:
            文件结构信息
        """
        if not os.path.exists(file_path):
            raise ValueError(f"文件不存在: {file_path}")

        ext = os.path.splitext(file_path)[1].lower()
        language = IndexEngine.get_language(ext)

        # 从数据库获取符号
        file_record = self.db.get_file_by_path(file_path)
        if not file_record:
            # 如果没有索引，先索引该文件
            self._index_file(file_path)
            file_record = self.db.get_file_by_path(file_path)

        symbols = []
        if file_record:
            symbols_data = self.db.find_symbols(file_id=file_record.id, limit=100)
            for s in symbols_data:
                symbols.append({
                    "name": s['name'],
                    "kind": s['kind'],
                    "line": s['line_start'],
                    "signature": s['signature']
                })

        return {
            "path": file_path,
            "language": language,
            "symbols": symbols
        }
