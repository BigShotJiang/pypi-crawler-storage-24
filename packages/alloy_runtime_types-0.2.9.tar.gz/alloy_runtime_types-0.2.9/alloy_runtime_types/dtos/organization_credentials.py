"""DTOs for organization credential operations."""

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, Field, field_validator, model_validator

from alloy_runtime_types.enums.provider import Provider
from alloy_runtime_types.enums.tool_service import ToolService


class CreateOrganizationCredentialRequest(BaseModel):
    """Request to create an organization credential (BYOK).

    Organizations can bring their own API keys for AI providers or tools.
    Exactly one of provider_key or tool_id should be provided for typed credentials,
    or both can be null for generic credentials.
    """

    credential_type_id: str = Field(
        ...,
        description="Credential type: 'org_provider' or 'org_tool'",
    )
    name: str = Field(
        ...,
        min_length=1,
        max_length=255,
        description="Human-readable credential identifier",
    )
    plaintext_value: str = Field(
        ...,
        description="The API key value (will be encrypted at rest)",
    )
    description: str | None = Field(
        default=None,
        max_length=1000,
        description="Optional description of the credential",
    )
    expires_at: datetime | None = Field(
        default=None,
        description="Optional expiration timestamp",
    )
    configuration: dict[str, Any] | None = Field(
        default=None,
        description="Type-specific configuration (e.g., QuickBooks realm_id)",
    )
    provider_key: Provider | None = Field(
        default=None,
        description="AI provider key (mutually exclusive with tool_id)",
    )
    service_key: ToolService | None = Field(
        default=None,
        description="Service key for infrastructure or service-backed org credentials",
    )
    tool_id: str | None = Field(
        default=None,
        description="Tool identifier (mutually exclusive with provider_key/service_key)",
    )

    @field_validator("plaintext_value")
    @classmethod
    def validate_plaintext_value(cls, v: str) -> str:
        """Reject empty strings for plaintext_value."""
        if not v or not v.strip():
            raise ValueError("plaintext_value cannot be empty or whitespace")
        return v

    @model_validator(mode="after")
    def validate_provider_xor_tool(self) -> "CreateOrganizationCredentialRequest":
        has_provider = self.provider_key is not None
        has_service = self.service_key is not None
        has_tool = self.tool_id is not None
        association_count = sum((has_provider, has_service, has_tool))

        if association_count != 1:
            raise ValueError(
                "Exactly one credential association must be provided: provider_key, service_key, or tool_id"
            )

        if self.credential_type_id == "org_provider" and not has_provider:
            raise ValueError("org_provider credentials require provider_key")

        if self.credential_type_id == "org_infrastructure" and not has_service:
            raise ValueError("org_infrastructure credentials require service_key")

        if self.credential_type_id == "org_tool" and has_provider:
            raise ValueError("org_tool credentials must use service_key or tool_id")

        return self


class OrganizationCredentialResponse(BaseModel):
    """Response for organization credential data (excludes encrypted_value)."""

    # From core.credentials
    id: UUID
    credential_type_id: str
    name: str
    description: str | None
    value_prefix: str | None
    is_active: bool
    expires_at: datetime | None
    last_used_at: datetime | None
    configuration: dict[str, Any] | None
    created_at: datetime
    updated_at: datetime

    # From core.organization_credentials
    organization_id: UUID
    provider_key: Provider | None
    service_key: ToolService | None
    tool_id: str | None
