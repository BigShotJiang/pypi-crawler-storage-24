# -*- coding: utf-8 -*-
from __future__ import annotations

__all__ = ["__version__"]

__version__ = "0.0.3.20260327082441"
