# Pytola Core

Core utilities and essential components for Pytola applications.

## Features

- **Advanced Logging**: Colored console output with file rotation
- **High DPI Support**: Automatic scaling for Qt applications
- **Security Utilities**: Input validation and sanitization
- **Theme Management**: Flexible theme system with inheritance
- **Environment Helpers**: PySide environment configuration

## Installation

```bash
pip install pytola-core
```

## Usage

```python
from pytola_core import logger, enable_highdpi_scaling

# Enable high DPI scaling
enable_highdpi_scaling()

# Use the logger
logger.info("Application started")
```

## Modules

- `logger`: Advanced logging system
- `highdpi`: High DPI scaling support
- `security`: Input validation utilities
- `themes`: Theme management system
- `env`: Environment configuration helpers
