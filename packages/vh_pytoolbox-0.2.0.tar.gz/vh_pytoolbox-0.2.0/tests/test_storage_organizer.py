"""Tests for the storage_organizer module."""

import csv
from datetime import datetime
from pathlib import Path
from tempfile import TemporaryDirectory
import pytest

from vh_pytoolbox.iohandler.storage_organizer import (
    StorageOrganizer,
    FileMetadata,
    PlannedAction,
    ExecutionResult,
)


@pytest.fixture
def temp_dir():
    """Create a temporary directory for testing."""
    with TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def storage_organizer():
    """Create a StorageOrganizer instance."""
    return StorageOrganizer(exclude_system_folders=True)


@pytest.fixture
def sample_files(temp_dir):
    """Create sample files for testing."""
    # Create various file types
    files = {
        "photo": temp_dir / "test_photo.jpg",
        "powerpoint": temp_dir / "presentation.pptx",
        "word": temp_dir / "document.docx",
        "excel": temp_dir / "spreadsheet.xlsx",
        "pdf": temp_dir / "report.pdf",
        "text": temp_dir / "notes.txt",
        "other": temp_dir / "data.dat",
    }

    for file_path in files.values():
        file_path.write_text("test content")

    return files


class TestFileClassification:
    """Tests for file classification."""

    def test_classify_photo_extensions(self, storage_organizer):
        """Test photo file classification."""
        photo_files = [
            Path("test.jpg"),
            Path("test.jpeg"),
            Path("test.png"),
            Path("test.heic"),
            Path("test.webp"),
            Path("test.tiff"),
        ]
        for photo in photo_files:
            assert storage_organizer._classify_file(photo) == "photo"

    def test_classify_powerpoint(self, storage_organizer):
        """Test PowerPoint file classification."""
        assert storage_organizer._classify_file(Path("test.ppt")) == "powerpoint"
        assert storage_organizer._classify_file(Path("test.pptx")) == "powerpoint"

    def test_classify_word(self, storage_organizer):
        """Test Word file classification."""
        assert storage_organizer._classify_file(Path("test.doc")) == "word"
        assert storage_organizer._classify_file(Path("test.docx")) == "word"

    def test_classify_excel(self, storage_organizer):
        """Test Excel file classification."""
        excel_files = [
            Path("test.xls"),
            Path("test.xlsx"),
            Path("test.xlsm"),
            Path("data.csv"),
        ]
        for excel in excel_files:
            assert storage_organizer._classify_file(excel) == "excel"

    def test_classify_document(self, storage_organizer):
        """Test document file classification."""
        assert storage_organizer._classify_file(Path("test.pdf")) == "document"
        assert storage_organizer._classify_file(Path("test.txt")) == "document"
        assert storage_organizer._classify_file(Path("test.rtf")) == "document"

    def test_classify_other(self, storage_organizer):
        """Test other file types."""
        assert storage_organizer._classify_file(Path("test.dat")) == "other"
        assert storage_organizer._classify_file(Path("test.log")) == "other"

    def test_case_insensitive_classification(self, storage_organizer):
        """Test that classification is case-insensitive."""
        assert storage_organizer._classify_file(Path("TEST.JPG")) == "photo"
        assert storage_organizer._classify_file(Path("TEST.DOCX")) == "word"


class TestSystemFolderExclusion:
    """Tests for system folder exclusion logic."""

    def test_should_skip_windows_folder(self, storage_organizer):
        """Test skipping Windows system folder."""
        root = Path("C:/")
        windows_folder = Path("C:/Windows/System32")
        assert storage_organizer._should_skip_folder(windows_folder, root) is True

    def test_should_skip_program_files(self, storage_organizer):
        """Test skipping Program Files."""
        root = Path("C:/")
        pf_folder = Path("C:/Program Files/App")
        assert storage_organizer._should_skip_folder(pf_folder, root) is True

    def test_should_not_skip_user_folder(self, storage_organizer):
        """Test not skipping user folders."""
        root = Path("C:/")
        user_folder = Path("C:/Users/test/Documents")
        assert storage_organizer._should_skip_folder(user_folder, root) is False

    def test_exclusion_disabled(self):
        """Test with exclusion disabled."""
        organizer = StorageOrganizer(exclude_system_folders=False)
        root = Path("C:/")
        windows_folder = Path("C:/Windows")
        assert organizer._should_skip_folder(windows_folder, root) is False


class TestFileMetadata:
    """Tests for FileMetadata dataclass."""

    def test_normalized_name_basic(self, temp_dir):
        """Test basic name normalization."""
        file_path = temp_dir / "My Document.txt"
        file_path.write_text("test")

        metadata = FileMetadata(
            absolute_path=file_path,
            category="document",
            extension=".txt",
            created_timestamp=datetime.now(),
            modified_timestamp=datetime.now(),
            size_bytes=100,
        )

        assert metadata.normalized_name == "My Document"

    def test_normalized_name_special_chars(self, temp_dir):
        """Test name normalization with special characters."""
        file_path = temp_dir / "My@Doc#ument!.txt"
        file_path.write_text("test")

        metadata = FileMetadata(
            absolute_path=file_path,
            category="document",
            extension=".txt",
            created_timestamp=datetime.now(),
            modified_timestamp=datetime.now(),
            size_bytes=100,
        )

        # Special chars should be replaced with underscores
        assert "_" in metadata.normalized_name
        assert "@" not in metadata.normalized_name

    def test_normalized_name_empty(self, temp_dir):
        """Test name normalization with only special characters."""
        file_path = temp_dir / "@#$.txt"
        file_path.write_text("test")

        metadata = FileMetadata(
            absolute_path=file_path,
            category="document",
            extension=".txt",
            created_timestamp=datetime.now(),
            modified_timestamp=datetime.now(),
            size_bytes=100,
        )

        # Should fall back to "unnamed"
        assert metadata.normalized_name == "unnamed"


class TestScanMetadata:
    """Tests for scanning file metadata."""

    def test_scan_single_root(self, storage_organizer, sample_files, temp_dir):
        """Test scanning a single root directory."""
        results = storage_organizer.scan_metadata([temp_dir])

        assert len(results) == len(sample_files)
        assert all(isinstance(r, FileMetadata) for r in results)

    def test_scan_nonexistent_root(self, storage_organizer, capsys):
        """Test scanning a nonexistent directory."""
        fake_root = Path("/nonexistent/path")
        results = storage_organizer.scan_metadata([fake_root])

        assert len(results) == 0
        captured = capsys.readouterr()
        assert "Warning" in captured.out

    def test_scan_file_not_directory(self, storage_organizer, temp_dir, capsys):
        """Test scanning a file instead of directory."""
        test_file = temp_dir / "test.txt"
        test_file.write_text("test")

        results = storage_organizer.scan_metadata([test_file])

        assert len(results) == 0
        captured = capsys.readouterr()
        assert "not a directory" in captured.out

    def test_metadata_attributes(self, storage_organizer, sample_files, temp_dir):
        """Test that metadata has all required attributes."""
        results = storage_organizer.scan_metadata([temp_dir])

        for metadata in results:
            assert metadata.absolute_path.exists()
            assert metadata.category in [
                "photo",
                "powerpoint",
                "word",
                "excel",
                "document",
                "other",
            ]
            assert metadata.extension.startswith(".")
            assert isinstance(metadata.created_timestamp, datetime)
            assert isinstance(metadata.modified_timestamp, datetime)
            assert metadata.size_bytes >= 0


class TestTargetPathGeneration:
    """Tests for target path generation."""

    def test_photo_path_generation(self, storage_organizer, temp_dir):
        """Test photo target path generation."""
        photo_date = datetime(2024, 3, 15, 10, 30, 0)
        metadata = FileMetadata(
            absolute_path=temp_dir / "photo.jpg",
            category="photo",
            extension=".jpg",
            created_timestamp=photo_date,
            modified_timestamp=photo_date,
            size_bytes=1000,
        )

        target_root = Path("/organized")
        target = storage_organizer._generate_target_path(metadata, target_root)

        # Use OS-agnostic path comparison
        assert target.parts[-5:] == ("Photos", "2024", "03", "15", "photo.jpg")

    def test_photo_with_capture_date(self, storage_organizer, temp_dir):
        """Test photo with EXIF capture date."""
        capture_date = datetime(2024, 1, 1, 12, 0, 0)
        modified_date = datetime(2024, 3, 15, 10, 30, 0)

        metadata = FileMetadata(
            absolute_path=temp_dir / "photo.jpg",
            category="photo",
            extension=".jpg",
            created_timestamp=modified_date,
            modified_timestamp=modified_date,
            size_bytes=1000,
            capture_date=capture_date,
        )

        target_root = Path("/organized")
        target = storage_organizer._generate_target_path(metadata, target_root)

        # Should use capture date, not modified date - check path parts
        assert target.parts[-4:-1] == ("2024", "01", "01")

    def test_word_document_path(self, storage_organizer, temp_dir):
        """Test Word document path generation."""
        created_date = datetime(2024, 3, 15, 10, 30, 0)
        file_path = temp_dir / "My Report.docx"
        file_path.write_text("test")

        metadata = FileMetadata(
            absolute_path=file_path,
            category="word",
            extension=".docx",
            created_timestamp=created_date,
            modified_timestamp=created_date,
            size_bytes=1000,
        )

        target_root = Path("/organized")
        target = storage_organizer._generate_target_path(metadata, target_root)

        assert "Word" in str(target)
        assert "My Report" in str(target)
        assert "2024-03-15" in str(target)

    def test_excel_document_path(self, storage_organizer, temp_dir):
        """Test Excel document path generation."""
        created_date = datetime(2024, 3, 15, 10, 30, 0)
        metadata = FileMetadata(
            absolute_path=temp_dir / "budget.xlsx",
            category="excel",
            extension=".xlsx",
            created_timestamp=created_date,
            modified_timestamp=created_date,
            size_bytes=1000,
        )

        target_root = Path("/organized")
        target = storage_organizer._generate_target_path(metadata, target_root)

        assert "Excel" in str(target)
        assert "budget" in str(target)

    def test_powerpoint_document_path(self, storage_organizer, temp_dir):
        """Test PowerPoint document path generation."""
        created_date = datetime(2024, 3, 15, 10, 30, 0)
        metadata = FileMetadata(
            absolute_path=temp_dir / "slides.pptx",
            category="powerpoint",
            extension=".pptx",
            created_timestamp=created_date,
            modified_timestamp=created_date,
            size_bytes=1000,
        )

        target_root = Path("/organized")
        target = storage_organizer._generate_target_path(metadata, target_root)

        assert "PowerPoint" in str(target)

    def test_generic_document_path(self, storage_organizer, temp_dir):
        """Test generic document path generation."""
        created_date = datetime(2024, 3, 15, 10, 30, 0)
        metadata = FileMetadata(
            absolute_path=temp_dir / "notes.pdf",
            category="document",
            extension=".pdf",
            created_timestamp=created_date,
            modified_timestamp=created_date,
            size_bytes=1000,
        )

        target_root = Path("/organized")
        target = storage_organizer._generate_target_path(metadata, target_root)

        assert "Documents" in str(target)


class TestCollisionResolution:
    """Tests for filename collision resolution."""

    def test_no_collision(self, storage_organizer, temp_dir):
        """Test when there's no collision."""
        target = temp_dir / "test.txt"
        resolved = storage_organizer._resolve_collision(target)

        assert resolved == target

    def test_single_collision(self, storage_organizer, temp_dir):
        """Test resolving a single collision."""
        target = temp_dir / "test.txt"
        target.write_text("existing")

        resolved = storage_organizer._resolve_collision(target)

        assert resolved != target
        assert resolved.stem == "test_1"
        assert resolved.suffix == ".txt"

    def test_multiple_collisions(self, storage_organizer, temp_dir):
        """Test resolving multiple collisions."""
        # Create existing files
        (temp_dir / "test.txt").write_text("1")
        (temp_dir / "test_1.txt").write_text("2")
        (temp_dir / "test_2.txt").write_text("3")

        target = temp_dir / "test.txt"
        resolved = storage_organizer._resolve_collision(target)

        assert resolved.stem == "test_3"


class TestOrganizationPlan:
    """Tests for building organization plans."""

    def test_build_plan_basic(self, storage_organizer, temp_dir):
        """Test building a basic organization plan."""
        created_date = datetime(2024, 3, 15, 10, 30, 0)
        metadata = [
            FileMetadata(
                absolute_path=temp_dir / "photo.jpg",
                category="photo",
                extension=".jpg",
                created_timestamp=created_date,
                modified_timestamp=created_date,
                size_bytes=1000,
            ),
            FileMetadata(
                absolute_path=temp_dir / "doc.docx",
                category="word",
                extension=".docx",
                created_timestamp=created_date,
                modified_timestamp=created_date,
                size_bytes=2000,
            ),
        ]

        target_root = temp_dir / "organized"
        plan = storage_organizer.build_organization_plan(metadata, target_root)

        assert len(plan) == 2
        assert all(isinstance(action, PlannedAction) for action in plan)
        assert plan[0].operation == "copy"  # Default operation

    def test_build_plan_with_move(self, storage_organizer, temp_dir):
        """Test building plan with move operation."""
        created_date = datetime(2024, 3, 15, 10, 30, 0)
        metadata = [
            FileMetadata(
                absolute_path=temp_dir / "photo.jpg",
                category="photo",
                extension=".jpg",
                created_timestamp=created_date,
                modified_timestamp=created_date,
                size_bytes=1000,
            ),
        ]

        target_root = temp_dir / "organized"
        plan = storage_organizer.build_organization_plan(
            metadata, target_root, operation="move"
        )

        assert plan[0].operation == "move"


class TestPlanExecution:
    """Tests for executing organization plans."""

    def test_dry_run_execution(self, storage_organizer, capsys):
        """Test dry run doesn't modify files."""
        source = Path("/source/test.jpg")
        target = Path("/target/test.jpg")

        plan = [
            PlannedAction(
                source=source,
                target=target,
                operation="copy",
                category="photo",
                size_bytes=1000,
            )
        ]

        result = storage_organizer.execute_plan(plan, mode="copy", dry_run=True)

        assert result.total_operations == 1
        assert result.successful == 1
        assert result.failed == 0

        captured = capsys.readouterr()
        assert "DRY RUN" in captured.out

    def test_actual_copy_execution(self, storage_organizer, temp_dir):
        """Test actual file copying."""
        source = temp_dir / "source.txt"
        source.write_text("test content")

        target_dir = temp_dir / "target"
        target = target_dir / "source.txt"

        plan = [
            PlannedAction(
                source=source,
                target=target,
                operation="copy",
                category="document",
                size_bytes=100,
            )
        ]

        result = storage_organizer.execute_plan(plan, mode="copy", dry_run=False)

        assert result.successful == 1
        assert result.failed == 0
        assert target.exists()
        assert source.exists()  # Original should still exist
        assert target.read_text() == "test content"

    def test_actual_move_execution(self, storage_organizer, temp_dir):
        """Test actual file moving."""
        source = temp_dir / "source.txt"
        source.write_text("test content")

        target_dir = temp_dir / "target"
        target = target_dir / "source.txt"

        plan = [
            PlannedAction(
                source=source,
                target=target,
                operation="move",
                category="document",
                size_bytes=100,
            )
        ]

        result = storage_organizer.execute_plan(plan, mode="move", dry_run=False)

        assert result.successful == 1
        assert result.failed == 0
        assert target.exists()
        assert not source.exists()  # Original should be gone
        assert target.read_text() == "test content"

    def test_execution_with_errors(self, storage_organizer, temp_dir, capsys):
        """Test execution with failing operations."""
        source = temp_dir / "nonexistent.txt"
        target = temp_dir / "target.txt"

        plan = [
            PlannedAction(
                source=source,
                target=target,
                operation="copy",
                category="document",
                size_bytes=100,
            )
        ]

        result = storage_organizer.execute_plan(plan, mode="copy", dry_run=False)

        assert result.successful == 0
        assert result.failed == 1
        assert len(result.errors) == 1


class TestConvenienceMethods:
    """Tests for convenience methods."""

    def test_organize_photos(self, storage_organizer, sample_files, temp_dir):
        """Test organize_photos convenience method."""
        target_root = temp_dir / "organized"

        result = storage_organizer.organize_photos(
            [temp_dir],
            target_root,
            mode="copy",
            dry_run=True,
        )

        # Should find the photo file
        assert result.total_operations >= 1
        assert result.successful >= 1

    def test_organize_documents(self, storage_organizer, sample_files, temp_dir):
        """Test organize_documents convenience method."""
        target_root = temp_dir / "organized"

        result = storage_organizer.organize_documents(
            [temp_dir],
            target_root,
            mode="copy",
            dry_run=True,
        )

        # Should find document files (word, excel, powerpoint, pdf, etc.)
        assert result.total_operations >= 4


class TestCSVExport:
    """Tests for CSV export functionality."""

    def test_export_plan_csv(self, storage_organizer, temp_dir):
        """Test exporting plan to CSV."""
        plan = [
            PlannedAction(
                source=Path("/source/test.jpg"),
                target=Path("/target/test.jpg"),
                operation="copy",
                category="photo",
                size_bytes=1000,
            ),
            PlannedAction(
                source=Path("/source/doc.docx"),
                target=Path("/target/doc.docx"),
                operation="move",
                category="word",
                size_bytes=2000,
            ),
        ]

        output_path = temp_dir / "plan.csv"
        storage_organizer.export_plan_csv(plan, output_path)

        assert output_path.exists()

        # Read and verify CSV content
        with open(output_path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            rows = list(reader)

        assert len(rows) == 2
        assert rows[0]["Category"] == "photo"
        assert rows[1]["Category"] == "word"
        assert rows[0]["Operation"] == "copy"
        assert rows[1]["Operation"] == "move"


class TestSummary:
    """Tests for summary statistics."""

    def test_get_summary(self, storage_organizer, temp_dir):
        """Test getting summary statistics."""
        created_date = datetime(2024, 3, 15, 10, 30, 0)
        metadata = [
            FileMetadata(
                absolute_path=temp_dir / "photo1.jpg",
                category="photo",
                extension=".jpg",
                created_timestamp=created_date,
                modified_timestamp=created_date,
                size_bytes=1000,
            ),
            FileMetadata(
                absolute_path=temp_dir / "photo2.jpg",
                category="photo",
                extension=".jpg",
                created_timestamp=created_date,
                modified_timestamp=created_date,
                size_bytes=1000,
            ),
            FileMetadata(
                absolute_path=temp_dir / "doc.docx",
                category="word",
                extension=".docx",
                created_timestamp=created_date,
                modified_timestamp=created_date,
                size_bytes=2000,
            ),
        ]

        summary = storage_organizer.get_summary(metadata)

        assert summary["photo"] == 2
        assert summary["word"] == 1
        assert len(summary) == 2


class TestExecutionResult:
    """Tests for ExecutionResult dataclass."""

    def test_execution_result_summary(self):
        """Test ExecutionResult summary property."""
        result = ExecutionResult(
            total_operations=10,
            successful=8,
            failed=1,
            skipped=1,
        )

        summary = result.summary

        assert "8 successful" in summary
        assert "1 failed" in summary
        assert "1 skipped" in summary
        assert "10 total" in summary
