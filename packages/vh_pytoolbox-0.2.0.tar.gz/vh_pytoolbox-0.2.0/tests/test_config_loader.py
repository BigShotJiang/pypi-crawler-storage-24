import yaml
from vh_pytoolbox.utils.config_loader import load_yaml_config


def test_load_empty_file(tmp_path):
    # create an empty yaml file
    path = tmp_path / "cfg.yaml"
    path.write_text("")
    data = load_yaml_config(str(path))
    assert isinstance(data, dict)
    assert data == {}


def test_load_values(tmp_path):
    contents = {"a": 1, "b": [2, 3]}
    path = tmp_path / "cfg.yaml"
    path.write_text(yaml.dump(contents))
    data = load_yaml_config(str(path))
    assert data == contents
