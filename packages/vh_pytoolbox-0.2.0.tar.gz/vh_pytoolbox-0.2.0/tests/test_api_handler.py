"""
Tests for API handler classes.
Note: These tests require valid Azure credentials and may be integration tests.
"""

import pytest
from unittest.mock import Mock, patch

from vh_pytoolbox.api_handler import MSGraphApi, PowerBIAdminApi


class TestMSGraphApi:
    """Test MSGraphApi class."""

    @patch("vh_pytoolbox.api_handler.msal.ConfidentialClientApplication")
    def test_init(self, mock_app_class):
        mock_app = Mock()
        mock_app_class.return_value = mock_app

        api = MSGraphApi("tenant", "client", "secret")

        mock_app_class.assert_called_once()
        assert api.tenant_id == "tenant"
        assert api.client_id == "client"
        assert api.app == mock_app

    @patch("vh_pytoolbox.api_handler.requests.Session")
    @patch("vh_pytoolbox.api_handler.msal.ConfidentialClientApplication")
    def test_get_all_pages_single_page(self, mock_app_class, mock_session_class):
        # Setup mocks
        mock_app = Mock()
        mock_app.acquire_token_for_client.return_value = {"access_token": "token"}
        mock_app_class.return_value = mock_app

        mock_session = Mock()
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "value": [{"item": 1}],
            "@odata.nextLink": None,
        }
        mock_session.get.return_value = mock_response
        mock_session_class.return_value = mock_session

        api = MSGraphApi("tenant", "client", "secret")
        result = api.get_all_pages("https://graph.microsoft.com/test")

        assert result["value"] == [{"item": 1}]
        assert result["delta_link"] is None
        mock_session.get.assert_called_once()


class TestPowerBIAdminApi:
    """Test PowerBIAdminApi class."""

    @patch("vh_pytoolbox.api_handler.ClientSecretCredential")
    def test_init(self, mock_cred_class):
        mock_cred = Mock()
        mock_cred_class.return_value = mock_cred

        api = PowerBIAdminApi("tenant", "client", "secret")

        mock_cred_class.assert_called_once_with(
            tenant_id="tenant", client_id="client", client_secret="secret"
        )
        assert api.credential == mock_cred

    @patch("vh_pytoolbox.api_handler.requests.get")
    @patch("vh_pytoolbox.api_handler.ClientSecretCredential")
    def test_get_response_success(self, mock_cred_class, mock_get):
        mock_cred = Mock()
        mock_cred.get_token.return_value = Mock(token="token")
        mock_cred_class.return_value = mock_cred

        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"data": "test"}
        mock_get.return_value = mock_response

        api = PowerBIAdminApi("tenant", "client", "secret")
        result = api.get_response("https://api.powerbi.com/test")

        assert result == {"data": "test"}
        mock_get.assert_called_once()

    @patch("vh_pytoolbox.api_handler.requests.get")
    @patch("vh_pytoolbox.api_handler.ClientSecretCredential")
    def test_get_response_error(self, mock_cred_class, mock_get):
        mock_cred = Mock()
        mock_cred.get_token.return_value = Mock(token="token")
        mock_cred_class.return_value = mock_cred

        mock_response = Mock()
        mock_response.status_code = 404
        mock_response.text = "Not found"
        mock_get.return_value = mock_response

        api = PowerBIAdminApi("tenant", "client", "secret")

        with pytest.raises(Exception, match="Not found"):
            api.get_response("https://api.powerbi.com/test")
