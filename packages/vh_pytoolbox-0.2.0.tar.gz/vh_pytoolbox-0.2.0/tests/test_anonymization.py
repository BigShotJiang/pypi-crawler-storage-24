import pandas as pd
import logging

from vh_pytoolbox.data_transformations import anonymization


def make_df():
    return pd.DataFrame({"colA": [1, 2], "colB": ["x", "y"]})


def test_anonymize_columns(tmp_path, caplog):
    raw = tmp_path / "raw"
    out = tmp_path / "out"
    raw.mkdir()
    out.mkdir()
    # write a simple csv
    df = make_df()
    path = raw / "test.csv"
    df.to_csv(path, index=False, sep=";")

    config = {
        "TEXT_MAPPING_COLUMNS": {"colA": "alpha"},
        "TEXT_MAPPING_FILE_NAME": {"test": "tst"},
        "COLUMNS_TO_DROP": {},
        "EXCLUDED_COLUMNS": [],
        "BIG_FILES": [],
    }

    caplog.set_level("INFO")
    file_meta, col_meta = anonymization.anonymize_source_files(
        raw_folder=str(raw),
        anonymized_folder=str(out),
        config=config,
        logger=logging.getLogger(),
    )

    # check output file exists
    out_path = out / "tst.csv"
    assert out_path.exists()
    df2 = pd.read_csv(out_path, sep=";")
    assert "alpha" in df2.columns

    assert file_meta.get("test") == "tst"
    assert "test.csv" in col_meta
