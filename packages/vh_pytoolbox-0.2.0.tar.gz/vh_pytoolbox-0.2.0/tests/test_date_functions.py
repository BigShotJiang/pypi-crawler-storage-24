import pytest
from datetime import datetime
from zoneinfo import ZoneInfo

from vh_pytoolbox.utils.date_functions import (
    get_current_timestamp_str,
    get_current_date_str,
    get_previous_date_str,
    get_next_date_str,
    get_formatted_timestamp,
    extract_timestamp_from_string,
    get_archive_file_path,
)


class TestDateFunctions:
    """Test cases for date utility functions."""

    def test_get_current_timestamp_str(self):
        """Test getting current timestamp string."""
        result = get_current_timestamp_str()
        assert isinstance(result, str)
        assert len(result) == 17  # YYYY_MM_DD_HHMMSS format
        assert result.count("_") == 3

    def test_get_current_date_str(self):
        """Test getting current date string."""
        result = get_current_date_str()
        assert isinstance(result, str)
        assert len(result) == 10  # YYYY-MM-DD format
        assert result.count("-") == 2

    def test_get_previous_date_str(self):
        """Test getting previous date string."""
        result = get_previous_date_str(days=1)
        assert isinstance(result, str)
        assert len(result) == 10
        assert result.count("-") == 2

        # Test with different days
        result_7 = get_previous_date_str(days=7)
        assert isinstance(result_7, str)

    def test_get_next_date_str(self):
        """Test getting next date string."""
        result = get_next_date_str(days=1)
        assert isinstance(result, str)
        assert len(result) == 10
        assert result.count("-") == 2

        # Test with different days
        result_5 = get_next_date_str(days=5)
        assert isinstance(result_5, str)

    def test_get_formatted_timestamp(self):
        """Test getting formatted timestamp."""
        format_str = "%Y-%m-%d %H:%M:%S"
        result = get_formatted_timestamp(format_str)
        assert isinstance(result, str)
        # Should match the format
        datetime.strptime(result, format_str)

    def test_extract_timestamp_from_string(self):
        """Test extracting timestamp from string."""
        # Valid input
        input_str = "some_text_2025_01_19_123045_more_text"
        result = extract_timestamp_from_string(input_str)
        assert result == 20250119123045

        # Invalid input
        result_none = extract_timestamp_from_string("no_timestamp_here")
        assert result_none is None

        # None input
        result_none2 = extract_timestamp_from_string(None)
        assert result_none2 is None

    def test_get_archive_file_path(self):
        """Test getting archive file path."""
        input_path = "A/B/file.csv"
        result = get_archive_file_path(input_path)
        assert isinstance(result, str)
        # Normalize path separators for cross-platform compatibility
        normalized_result = result.replace("\\", "/")
        assert "Files/archive/A/B/" in normalized_result
        assert result.endswith("file.csv")
        # Should contain date directory
        parts = result.replace("\\", "/").split("/")
        assert len(parts) >= 5  # Files/archive/A/B/date/file.csv
