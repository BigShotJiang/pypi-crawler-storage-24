# vh-pytoolbox

My own re-usable Python packages.

## Description

This package provides various utilities for handling file I/O, string processing, CSV manipulation, and logging setup. It is designed to streamline common tasks in data processing and analysis.

## Features

- **Path Initialization**: Functions to initialize and manage project paths.
- **File I/O**: Utilities for saving and loading JSON metadata.
- **String Processing**: Functions to convert strings to snake_case and translate text based on mappings.
- **CSV Handling**: Functions to remove columns from CSV files and transform text columns.
- **Logging Setup**: Easy setup for logging configuration.

## Installation

You can install the package using pip:

```sh
pip install git+https://github.com/vinay/vh-repo-python-package.git
