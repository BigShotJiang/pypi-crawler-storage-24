import hashlib
import os
import re
import shutil
from logging import Logger
from pathlib import Path
from typing import Any

import pandas as pd

from ..utils.csv_handler import remove_csv_columns
from ..iohandler.file_io import read_csv, write_csv
from ..utils.string_functions import convert_to_snake_case, translate_text_string


def hash_column_values(column: pd.Series) -> pd.Series:
    """
    Hashes the values of a DataFrame column using SHA-256.

    Parameters:
    column (pd.Series): The column to hash.

    Returns:
    pd.Series: The hashed column.
    """
    return column.apply(lambda x: hashlib.sha256(str(x).encode()).hexdigest())


def replace_sensitive_data(
    df: pd.DataFrame, column_name: str, replacement: str = "***"
) -> pd.DataFrame:
    """
    Replaces sensitive data in the specified column with a replacement string.

    Parameters:
    df (pd.DataFrame): The DataFrame to modify.
    column_name (str): The name of the column to replace.
    replacement (str): The replacement string.

    Returns:
    pd.DataFrame: The modified DataFrame.
    """
    df[column_name] = replacement
    return df


def anonymize_company_names(df: pd.DataFrame, column_name: str) -> pd.DataFrame:
    """
    Replaces company names in the specified column with anonymized values.
    Example anonymization: Replace "Company XYZ" with "Company ***".

    Parameters:
    df (pd.DataFrame): The DataFrame to modify.
    column_name (str): The name of the column containing company names.

    Returns:
    pd.DataFrame: The modified DataFrame.
    """
    df[column_name] = (
        df[column_name]
        .astype(str)
        .apply(lambda x: re.sub(r"Company\s+\w+", "Company ***", x))
    )
    return df


def anonymize_source_files(
    raw_folder: str,
    anonymized_folder: str,
    config: dict[str, Any],
    logger: Logger,
) -> tuple[dict[str, str], dict[str, dict[str, list[str]]]]:
    """
    Process all CSV files in ``raw_folder`` using parameters supplied by
    a configuration dictionary and write them to ``anonymized_folder``.

    The ``config`` dictionary is expected to contain at least the
    following keys:

    ``TEXT_MAPPING_COLUMNS`` (dict): column‑name mappings
    ``TEXT_MAPPING_FILE_NAME`` (dict): file‑name mappings
    ``COLUMNS_TO_DROP`` (dict): per‑file lists of columns to remove
    ``EXCLUDED_COLUMNS`` (list): columns to skip during value
        translations
    ``BIG_FILES`` (list): files that should be copied rather than
        transformed

    All keys are optional; missing entries will be treated as empty
    containers.

    Returns:
        Two dicts, ``file_metadata`` and ``column_metadata`` as before.
    """
    # Initialize metadata dictionaries
    file_metadata = {}
    column_metadata = {}

    # Process all CSV files in the raw folder while retaining the directory structure.
    raw_path = Path(raw_folder)
    anon_path = Path(anonymized_folder)
    for root, dirs, files in os.walk(raw_path):
        root_path = Path(root)
        # Determine the relative path from the raw folder
        relative_path = root_path.relative_to(raw_path)

        # Define the corresponding output folder in the anonymized folder
        target_folder = anon_path / relative_path
        target_folder.mkdir(parents=True, exist_ok=True)

        for file in files:
            if not file.lower().endswith(".csv"):
                continue

            # Full path to the input file
            file_path = root_path / file

            # if file is marked big, just copy and continue
            if file in config.get("BIG_FILES", []):
                target = target_folder / file
                logger.info(f"Copying big file {file_path} to {target}")
                try:
                    shutil.copy(file_path, target)
                except Exception as e:
                    logger.error(f"Failed to copy {file_path}: {e}")
                continue

            logger.info(f"Processing file: {file_path}")

            org_table_name = file[:-4]
            file_map = config.get("TEXT_MAPPING_FILE_NAME", {})
            new_table_name = convert_to_snake_case(
                translate_text_string(org_table_name, file_map)
            )
            # Update metadata
            file_metadata[org_table_name] = new_table_name

            # Define the output file path
            output_file_path = target_folder / f"{new_table_name}.csv"

            try:
                df = read_csv(file_path)
                # Store original column names
                original_columns = df.columns.tolist()
                # remove unnecessary columns
                df = remove_csv_columns(
                    file_name=file,
                    df=df,
                    columns_to_drop=config.get("COLUMNS_TO_DROP", {}),
                )

                # Translate column names
                col_map = config.get("TEXT_MAPPING_COLUMNS", {})
                translated_columns = [
                    translate_text_string(col, col_map) for col in df.columns
                ]

                # Convert to snake case
                new_columns = [convert_to_snake_case(col) for col in translated_columns]
                df.columns = new_columns

                # value‑level substitutions if provided
                value_map = config.get("TEXT_VALUE_MAPPING", {})
                excluded = set(config.get("EXCLUDED_COLUMNS", []))
                if value_map:
                    from src.utils.csv_handler import transform_csv_text_column

                    df = transform_csv_text_column(
                        df=df, exclude_columns=list(excluded), text_mapping=value_map
                    )

                # Update metadata
                column_metadata[file] = {
                    "old_columns": original_columns,
                    "new_columns": new_columns,
                }

                # Save the transformed DataFrame
                write_csv(df=df, file_path=output_file_path, quote_char='"')

            except (OSError, ValueError, KeyError):
                logger.exception("Error processing file %s", file_path)
            finally:
                logger.info("File saved to: %s", output_file_path)

    return file_metadata, column_metadata
