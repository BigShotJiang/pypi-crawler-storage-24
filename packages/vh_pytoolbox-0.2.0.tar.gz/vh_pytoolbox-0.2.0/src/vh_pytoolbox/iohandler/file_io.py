import csv  # Import csv module for quoting options
import json
from pathlib import Path

import pandas as pd


def read_csv(
    file_path: str, separator: str = ";", dec_point: str = ",", quote_char: str = '"'
) -> pd.DataFrame:
    """
    Reads a CSV file from the given file path with customizable options.
    """
    return pd.read_csv(
        file_path,
        sep=separator,  # CSV separator
        decimal=dec_point,  # Specify that the decimal point is a comma
        quotechar=quote_char,  # Specify that text columns are enclosed in double quotes
        low_memory=False,
    )


def write_csv(
    df: pd.DataFrame,
    file_path: str,
    separator: str = ";",
    dec_point: str = ",",
    quote_char: str = '"',
    quoting: int = csv.QUOTE_NONNUMERIC,
) -> None:
    """
    Writes a DataFrame to a CSV file with customizable options, including quoting.
    """
    df.to_csv(
        file_path,
        index=False,  # Do not write the DataFrame index
        sep=separator,  # Use the same separator as in read_csv
        decimal=dec_point,  # Use the same decimal point as in read_csv
        quotechar=quote_char,  # Specify the quote character
        quoting=quoting,  # Specify quoting style
    )


def update_metadata(metadata_file: str, file_name: str, columns: list):
    """
    Update the metadata file with new metadata for a given file.

    Parameters:
    metadata_file (str): Path to the metadata file.
    file_name (str): Name of the file to update metadata for.
    columns (list): List of columns to add to the metadata.
    """
    metadata = {}

    # Load existing metadata if the file exists
    try:
        with Path(metadata_file).open() as file:
            metadata = json.load(file)
    except FileNotFoundError:
        pass  # File doesn't exist; we'll create it

    # Add new metadata
    metadata[file_name] = columns

    # Save updated metadata
    with Path(metadata_file).open("w") as file:
        json.dump(metadata, file, indent=4)


def save_metadata_to_json(
    file_metadata: dict,
    column_metadata: dict,
    file_path_metadata: str,
    column_path_metadata: str,
):
    """
    Save metadata dictionaries to JSON files.

    Parameters:
    output_folder (str): The folder where the metadata files will be saved.
    file_metadata (dict): The metadata dictionary for files.
    column_metadata (dict): The metadata dictionary for columns.
    """
    with Path(file_path_metadata).open("w") as f:
        json.dump(file_metadata, f, indent=4)

    with Path(column_path_metadata).open("w") as f:
        json.dump(column_metadata, f, indent=4)


def load_json(metadata_path: str, encoding="utf-8") -> dict:
    """
    Load a JSON file and return its contents as a dictionary.

    Parameters:
    metadata_path (str): The path to the JSON file to be loaded.

    Returns:
    dict: The contents of the JSON file.
    """
    with Path(metadata_path).open(encoding=encoding) as f:
        return json.load(f)
