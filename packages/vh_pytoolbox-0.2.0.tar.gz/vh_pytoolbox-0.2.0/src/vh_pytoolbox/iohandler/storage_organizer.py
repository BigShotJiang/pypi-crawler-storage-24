"""Storage organizer utility for scanning and organizing files on Windows local storage.

Supports scanning C: drive and local synced folders (Google Drive, Dropbox) and organizing
files into date-based hierarchies for photos and name/date structures for documents.
"""

import csv
import os
import shutil
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Literal


@dataclass
class FileMetadata:
    """Metadata for a scanned file."""

    absolute_path: Path
    category: Literal["photo", "powerpoint", "word", "excel", "document", "other"]
    extension: str
    created_timestamp: datetime
    modified_timestamp: datetime
    size_bytes: int
    target_path: Path | None = None
    capture_date: datetime | None = None  # For photos with EXIF data

    @property
    def normalized_name(self) -> str:
        """Return sanitized base name without extension."""
        name = self.absolute_path.stem
        # Replace invalid characters
        sanitized = "".join(
            c if c.isalnum() or c in (" ", "-", "_") else "_" for c in name
        )
        # Collapse multiple spaces/underscores
        sanitized = " ".join(sanitized.split())
        # Remove trailing/leading underscores
        sanitized = sanitized.strip("_ ")
        return (
            sanitized
            if sanitized and sanitized.replace("_", "").strip() != ""
            else "unnamed"
        )


@dataclass
class PlannedAction:
    """A planned file move or copy operation."""

    source: Path
    target: Path
    operation: Literal["move", "copy"]
    category: str
    size_bytes: int
    reason: str = ""  # Optional explanation for logging


@dataclass
class ExecutionResult:
    """Result of executing a plan."""

    total_operations: int
    successful: int
    failed: int
    skipped: int
    errors: list[tuple[Path, str]] = field(default_factory=list)

    @property
    def summary(self) -> str:
        """Return a human-readable summary."""
        return (
            f"Execution Result: {self.successful} successful, "
            f"{self.failed} failed, {self.skipped} skipped out of {self.total_operations} total"
        )


class StorageOrganizer:
    """Reusable utility for scanning and organizing local storage files."""

    # File category mappings
    PHOTO_EXTENSIONS = {".jpg", ".jpeg", ".png", ".heic", ".webp", ".tiff", ".tif"}
    POWERPOINT_EXTENSIONS = {".ppt", ".pptx"}
    WORD_EXTENSIONS = {".doc", ".docx"}
    EXCEL_EXTENSIONS = {".xls", ".xlsx", ".xlsm", ".csv"}
    DOCUMENT_EXTENSIONS = {".pdf", ".txt", ".rtf"}

    # System folders to exclude from C: scans
    SYSTEM_EXCLUSIONS = {
        "Windows",
        "Program Files",
        "Program Files (x86)",
        "ProgramData",
        "$Recycle.Bin",
        "System Volume Information",
        "Recovery",
        "Perflogs",
    }

    def __init__(self, exclude_system_folders: bool = True):
        """Initialize the storage organizer.

        Args:
            exclude_system_folders: If True, skip common Windows system folders during C: scans
        """
        self.exclude_system_folders = exclude_system_folders

    def _classify_file(self, path: Path) -> str:
        """Classify a file by extension.

        Args:
            path: File path to classify

        Returns:
            Category string
        """
        ext = path.suffix.lower()

        if ext in self.PHOTO_EXTENSIONS:
            return "photo"
        if ext in self.POWERPOINT_EXTENSIONS:
            return "powerpoint"
        if ext in self.WORD_EXTENSIONS:
            return "word"
        if ext in self.EXCEL_EXTENSIONS:
            return "excel"
        if ext in self.DOCUMENT_EXTENSIONS:
            return "document"
        return "other"

    def _should_skip_folder(self, folder_path: Path, root: Path) -> bool:
        """Check if a folder should be skipped during scanning.

        Args:
            folder_path: The folder being checked
            root: The root folder being scanned

        Returns:
            True if folder should be skipped
        """
        if not self.exclude_system_folders:
            return False

        # Check if this is a direct child of C: root and in exclusion list
        if root == Path("C:/") or root == Path("C:\\"):
            relative = folder_path.relative_to(root)
            first_part = str(relative).split(os.sep)[0] if relative != Path() else ""
            return first_part in self.SYSTEM_EXCLUSIONS

        return False

    def _get_photo_capture_date(self, path: Path) -> datetime | None:
        """Attempt to extract EXIF capture date from photo.

        Args:
            path: Path to photo file

        Returns:
            Capture datetime if available, None otherwise
        """
        try:
            from PIL import Image
            from PIL.ExifTags import TAGS

            with Image.open(path) as img:
                exif = img._getexif()
                if exif:
                    for tag_id, value in exif.items():
                        tag = TAGS.get(tag_id, tag_id)
                        if tag == "DateTimeOriginal":
                            return datetime.strptime(value, "%Y:%m:%d %H:%M:%S")
        except (ImportError, Exception):
            # PIL not available or EXIF reading failed, fall back to file dates
            pass

        return None

    def scan_metadata(self, roots: list[Path]) -> list[FileMetadata]:
        """Scan one or more root folders and collect file metadata.

        Args:
            roots: List of root paths to scan (e.g., [Path("C:/"), Path("D:/GoogleDrive")])

        Returns:
            List of FileMetadata objects for all scanned files
        """
        results = []

        for root in roots:
            if not root.exists():
                print(f"Warning: Root path does not exist: {root}")
                continue

            if not root.is_dir():
                print(f"Warning: Root path is not a directory: {root}")
                continue

            try:
                for entry in root.rglob("*"):
                    # Skip directories
                    if not entry.is_file():
                        continue

                    # Check if parent folder should be skipped
                    if self._should_skip_folder(entry.parent, root):
                        continue

                    try:
                        stat = entry.stat()
                        category = self._classify_file(entry)

                        # Get timestamps
                        created = datetime.fromtimestamp(stat.st_ctime)
                        modified = datetime.fromtimestamp(stat.st_mtime)

                        # For photos, try to get capture date
                        capture_date = None
                        if category == "photo":
                            capture_date = self._get_photo_capture_date(entry)

                        metadata = FileMetadata(
                            absolute_path=entry,
                            category=category,
                            extension=entry.suffix.lower(),
                            created_timestamp=created,
                            modified_timestamp=modified,
                            size_bytes=stat.st_size,
                            capture_date=capture_date,
                        )

                        results.append(metadata)

                    except (PermissionError, OSError) as e:
                        print(f"Warning: Cannot access file {entry}: {e}")
                        continue

            except (PermissionError, OSError) as e:
                print(f"Warning: Cannot scan root {root}: {e}")
                continue

        return results

    def _generate_target_path(self, metadata: FileMetadata, target_root: Path) -> Path:
        """Generate target path based on file category and metadata.

        Args:
            metadata: File metadata
            target_root: Root directory for organized files

        Returns:
            Target path for the file
        """
        if metadata.category == "photo":
            # Use capture date if available, otherwise modified date
            date = metadata.capture_date or metadata.modified_timestamp
            date_path = date.strftime("%Y/%m/%d")
            return target_root / "Photos" / date_path / metadata.absolute_path.name
        # Documents organized by name and creation date
        sanitized_name = metadata.normalized_name
        date_folder = metadata.created_timestamp.strftime("%Y-%m-%d")

        # Choose category folder
        if metadata.category == "powerpoint":
            category_folder = "PowerPoint"
        elif metadata.category == "word":
            category_folder = "Word"
        elif metadata.category == "excel":
            category_folder = "Excel"
        else:
            category_folder = "Documents"

        return (
            target_root
            / category_folder
            / sanitized_name
            / date_folder
            / metadata.absolute_path.name
        )

    def _resolve_collision(self, target: Path) -> Path:
        """Resolve filename collision by adding numeric suffix.

        Args:
            target: Proposed target path

        Returns:
            Available target path with suffix if needed
        """
        if not target.exists():
            return target

        stem = target.stem
        suffix = target.suffix
        parent = target.parent
        counter = 1

        while True:
            new_name = f"{stem}_{counter}{suffix}"
            new_target = parent / new_name
            if not new_target.exists():
                return new_target
            counter += 1

    def build_organization_plan(
        self,
        items: list[FileMetadata],
        target_root: Path,
        operation: Literal["move", "copy"] = "copy",
    ) -> list[PlannedAction]:
        """Build a plan for organizing files.

        Args:
            items: List of file metadata to organize
            target_root: Root directory for organized files
            operation: Operation type (move or copy)

        Returns:
            List of planned actions
        """
        plan = []

        for item in items:
            target = self._generate_target_path(item, target_root)
            target = self._resolve_collision(target)

            action = PlannedAction(
                source=item.absolute_path,
                target=target,
                operation=operation,
                category=item.category,
                size_bytes=item.size_bytes,
            )

            plan.append(action)

        return plan

    def execute_plan(
        self,
        plan: list[PlannedAction],
        mode: Literal["move", "copy"] = "copy",
        dry_run: bool = True,
    ) -> ExecutionResult:
        """Execute a file organization plan.

        Args:
            plan: List of planned actions
            mode: Operation mode (move or copy)
            dry_run: If True, only simulate execution without changing files

        Returns:
            Execution result summary
        """
        result = ExecutionResult(
            total_operations=len(plan), successful=0, failed=0, skipped=0
        )

        if dry_run:
            print(f"DRY RUN: Would perform {len(plan)} operations")
            result.successful = len(plan)
            return result

        for action in plan:
            try:
                # Ensure target directory exists
                action.target.parent.mkdir(parents=True, exist_ok=True)

                # Perform operation
                if mode == "copy":
                    shutil.copy2(action.source, action.target)
                elif mode == "move":
                    shutil.move(str(action.source), str(action.target))
                else:
                    raise ValueError(f"Unknown operation mode: {mode}")

                result.successful += 1

            except Exception as e:
                result.failed += 1
                result.errors.append((action.source, str(e)))
                print(f"Error processing {action.source}: {e}")

        return result

    def organize_photos(
        self,
        roots: list[Path],
        target_root: Path,
        mode: Literal["move", "copy"] = "copy",
        dry_run: bool = True,
    ) -> ExecutionResult:
        """Convenience method to scan and organize photos.

        Args:
            roots: Roots to scan for photos
            target_root: Target directory for organized photos
            mode: Operation mode
            dry_run: Dry run flag

        Returns:
            Execution result
        """
        all_items = self.scan_metadata(roots)
        photos = [item for item in all_items if item.category == "photo"]
        plan = self.build_organization_plan(photos, target_root, mode)
        return self.execute_plan(plan, mode, dry_run)

    def organize_documents(
        self,
        roots: list[Path],
        target_root: Path,
        mode: Literal["move", "copy"] = "copy",
        dry_run: bool = True,
    ) -> ExecutionResult:
        """Convenience method to scan and organize documents.

        Args:
            roots: Roots to scan for documents
            target_root: Target directory for organized documents
            mode: Operation mode
            dry_run: Dry run flag

        Returns:
            Execution result
        """
        all_items = self.scan_metadata(roots)
        documents = [
            item
            for item in all_items
            if item.category in ("powerpoint", "word", "excel", "document")
        ]
        plan = self.build_organization_plan(documents, target_root, mode)
        return self.execute_plan(plan, mode, dry_run)

    def export_plan_csv(self, plan: list[PlannedAction], output_path: Path) -> None:
        """Export organization plan to CSV for inspection.

        Args:
            plan: List of planned actions
            output_path: Path for output CSV file
        """
        with open(output_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(
                ["Source", "Target", "Operation", "Category", "Size (bytes)"]
            )

            for action in plan:
                writer.writerow(
                    [
                        str(action.source),
                        str(action.target),
                        action.operation,
                        action.category,
                        action.size_bytes,
                    ]
                )

    def get_summary(self, items: list[FileMetadata]) -> dict[str, int]:
        """Get summary statistics by category.

        Args:
            items: List of file metadata

        Returns:
            Dictionary with counts by category
        """
        summary = defaultdict(int)
        for item in items:
            summary[item.category] += 1

        return dict(summary)
