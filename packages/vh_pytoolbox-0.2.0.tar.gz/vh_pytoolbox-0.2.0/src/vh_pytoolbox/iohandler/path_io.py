import sys
from pathlib import Path


def initialize_paths() -> None:
    """
    Initializes the project paths by adding the project root directory to sys.path.
    """
    # Get the project root directory
    project_root = Path.cwd().parent.resolve()
    # Add the project root to sys.path if not already added
    if str(project_root) not in sys.path:
        sys.path.append(str(project_root))


def get_absolute_path(folder_name: str) -> str:
    """
    Returns the absolute path to the specified folder relative to the project root.

    Parameters:
    folder_name (str): The name of the folder for which the absolute path is required.

    Returns:
    str: The absolute path to the specified folder.
    """
    project_root = Path.cwd().parent.resolve()
    return str(project_root.parent.parent / folder_name)
