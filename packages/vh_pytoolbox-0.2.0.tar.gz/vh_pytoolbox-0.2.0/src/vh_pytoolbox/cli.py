"""Simple command-line entry point for dataset anonymization."""

import argparse
from pathlib import Path

from .data_transformations import anonymization
from .iohandler.file_io import save_metadata_to_json
from .utils.config_loader import load_yaml_config
from .utils.logging_setup import setup_logger


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Anonymize CSV datasets according to a YAML configuration."
    )
    parser.add_argument(
        "--config", "-c", required=True, help="Path to the YAML config file."
    )
    parser.add_argument(
        "--raw", "-r", required=True, help="Path to raw data folder to process."
    )
    parser.add_argument(
        "--out", "-o", default=None, help="Path to output (anonymized) folder."
    )
    parser.add_argument("--log", help="Path to log file (default: console).")

    args = parser.parse_args()

    logger = setup_logger(log_file=args.log)

    try:
        config = load_yaml_config(args.config)
    except Exception as e:
        logger.error(f"Failed to load config from {args.config}: {e}")
        return

    raw_folder = Path(args.raw)
    if args.out:
        anonymized_folder = Path(args.out)
    else:
        anonymized_folder = raw_folder.parent / "anonymized"

    anonymized_folder.mkdir(parents=True, exist_ok=True)

    logger.info(f"Starting anonymization. raw={raw_folder} out={anonymized_folder}")
    try:
        file_meta, col_meta = anonymization.anonymize_source_files(
            raw_folder=str(raw_folder),
            anonymized_folder=str(anonymized_folder),
            config=config,
            logger=logger,
        )

        # Save metadata
        file_meta_path = anonymized_folder / "file_metadata.json"
        col_meta_path = anonymized_folder / "column_metadata.json"
        save_metadata_to_json(
            file_meta, col_meta, str(file_meta_path), str(col_meta_path)
        )
        logger.info("Finished anonymization.")
    except Exception as e:
        logger.error(f"Anonymization failed: {e}")


if __name__ == "__main__":
    main()
