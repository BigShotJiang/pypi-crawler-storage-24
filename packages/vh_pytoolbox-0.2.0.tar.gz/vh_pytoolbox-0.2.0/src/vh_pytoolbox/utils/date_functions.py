import logging
import re
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

logger = logging.getLogger(__name__)


def get_current_timestamp_str() -> str:
    """
    Get the current timestamp as a formatted string in Europe/Amsterdam timezone.

    Returns:
    str: Current timestamp in format "YYYY_MM_DD_HHMMSS".
    """
    return datetime.now(tz=ZoneInfo("Europe/Amsterdam")).strftime("%Y_%m_%d_%H%M%S")


def get_current_date_str() -> str:
    """
    Get the current date as a formatted string in Europe/Amsterdam timezone.

    Returns:
    str: Current date in format "YYYY-MM-DD".
    """
    return datetime.now(tz=ZoneInfo("Europe/Amsterdam")).strftime("%Y-%m-%d")


def get_previous_date_str(days: int = 1) -> str:
    """
    Get the date from a specified number of days ago as a formatted string.

    Parameters:
    days (int): Number of days to go back. Defaults to 1.

    Returns:
    str: Previous date in format "YYYY-MM-DD".
    """
    return (
        datetime.now(tz=ZoneInfo("Europe/Amsterdam")) - timedelta(days=days)
    ).strftime("%Y-%m-%d")


def get_next_date_str(days: int = 1) -> str:
    """
    Get the date from a specified number of days in the future as a formatted string.

    Parameters:
    days (int): Number of days to go forward. Defaults to 1.

    Returns:
    str: Next date in format "YYYY-MM-DD".
    """
    return (
        datetime.now(tz=ZoneInfo("Europe/Amsterdam")) + timedelta(days=days)
    ).strftime("%Y-%m-%d")


def get_formatted_timestamp(format_str: str) -> str:
    """
    Get the current timestamp formatted according to the provided format string.

    Parameters:
    format_str (str): Format string for datetime.strftime().

    Returns:
    str: Formatted timestamp string.
    """
    return datetime.now(tz=ZoneInfo("Europe/Amsterdam")).strftime(format_str)


def extract_timestamp_from_string(source: str) -> int | None:
    """
    Extracts a timestamp in format YYYY_MM_DD_HHMMSS from a source string
    and returns it as an integer YYYYMMDDHHMMSS.

    Parameters:
    source (str): The source string containing the timestamp.

    Returns:
    int | None: The extracted timestamp as integer, or None if not found.

    Example:
        input:  "2025_01_19_123045"
        output: 20250119123045
    """
    if source is None:
        return None

    pattern = r"(\d{4})_(\d{2})_(\d{2})_(\d{6})"
    match = re.search(pattern, source)

    if not match:
        return None

    # Remove underscores and convert to int
    return int(match.group(0).replace("_", ""))


def get_archive_file_path(file_path: str) -> str:
    """
    Given a file path relative to the 'Files/' root, this function
    constructs the corresponding archive file path under 'archive/' while
    preserving the directory structure and adding the current date.

    Parameters:
    file_path (str): The relative file path from the Files/ root.

    Returns:
    str: The archive file path including date directory.

    Example:
        file_path = "A/B/file.csv"
        Returns: "Files/archive/A/B/2024_01_15/file.csv"
    """
    # Convert file string into Path object
    file_path_obj = Path(file_path)
    relative_dir_path = file_path_obj.parent

    # Get run date in Europe/Amsterdam timezone
    run_date = datetime.now(tz=ZoneInfo("Europe/Amsterdam")).strftime("%Y_%m_%d")

    # Build archive directory: Files/archive/A/B/<run_date>
    archive_dir = Path("Files") / "archive" / relative_dir_path / run_date
    archive_file_path = archive_dir / file_path_obj.name

    return str(archive_file_path)
