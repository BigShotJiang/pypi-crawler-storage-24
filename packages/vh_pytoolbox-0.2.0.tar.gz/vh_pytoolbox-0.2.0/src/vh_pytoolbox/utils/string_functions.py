import re

import pandas as pd


def convert_to_snake_case(input_text: str) -> str:
    """
    Converts a given string to snake_case.

    Parameters:
    input_text (str): The input string to be converted.

    Returns:
    str: The converted snake_case string.
    """
    input_text = (
        input_text.replace(" ", "_").replace("-", "_").replace("[", "").replace("]", "")
    )
    input_text = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", input_text)
    input_text = re.sub("__([A-Z])", r"_\1", input_text)
    input_text = re.sub("([a-z0-9])([A-Z])", r"\1_\2", input_text)
    return input_text.lower()


def translate_text_string(input_text: str, text_mapping: dict[str, str]) -> str:
    """
    Translates the text according to a predefined mapping dictionary.

    Parameters:
    input_text (str): The text to be translated.
    text_mapping (dict): The dictionary containing text mappings.

    Returns:
    str: The translated text after applying the mapping.
    """
    for old_text, new_text in text_mapping.items():
        input_text = input_text.replace(old_text, new_text)
    return input_text


def translate_column_values(
    column: pd.Series, text_mapping: dict[str, str]
) -> pd.Series:
    """
    Translates the text in a column based on the predefined mapping (case-insensitively)
    using vectorized Pandas operations.

    Parameters:
    column (pd.Series): The Pandas Series to be transformed.
    text_mapping (dict): The dictionary containing text mappings.

    Returns:
    pd.Series: The transformed Pandas Series with translated text.
    """
    for old_text, new_text in text_mapping.items():
        column = column.str.replace(old_text, new_text, case=False, regex=True)
    return column
