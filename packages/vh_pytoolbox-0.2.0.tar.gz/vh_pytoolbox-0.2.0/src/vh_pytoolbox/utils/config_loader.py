from pathlib import Path
from typing import Any

import yaml


def load_yaml_config(config_path: str) -> dict[str, Any]:
    """
    Load a YAML configuration file and return its contents as a dictionary.

    Parameters:
    config_path (str): Path to the YAML file.

    Returns:
    Dict[str, Any]: Configuration data. Empty dict if file not found or invalid.

    Raises:
    FileNotFoundError: If the config file does not exist.
    yaml.YAMLError: If the YAML is malformed.
    """
    with Path(config_path).open(encoding="utf-8") as file:
        return yaml.safe_load(file) or {}
