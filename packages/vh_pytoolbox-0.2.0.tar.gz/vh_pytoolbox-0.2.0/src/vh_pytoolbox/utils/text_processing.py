from typing import Any
from pathlib import Path


def create_replacement_list_from_json(
    json_metadata: dict[str, Any], metadata_type: str = "File"
) -> dict[str, str]:
    """
    Creates a mapping of old column names to new column names based on the column_metadata.

    Parameters:
    json_metadata (dict): The metadata dictionary that contains the column mappings.
    metadata_type (str): The type of metadata, either "File" or "Columns". Default is "File".

    Returns:
    dict: A dictionary where the keys are old column names and values are new column names.
    """
    dict_text_replacement = {}

    # Loop through the column metadata and create the replacement dictionary
    for key, value in json_metadata.items():
        if metadata_type == "File":
            dict_text_replacement[key] = value
        elif metadata_type == "Columns":
            old_columns = value["old_columns"]
            new_columns = value["new_columns"]

            for old_col, new_col in zip(old_columns, new_columns):
                dict_text_replacement[old_col] = new_col

    return dict_text_replacement


def replace_text_in_json(json_text: str, replacement_dict: dict[str, str]) -> str:
    """
    Replace occurrences of keys in the JSON text based on the provided replacement dictionary.

    Parameters:
    json_text (str): The original JSON text (string) to modify.
    replacement_dict (dict): A dictionary mapping old values to new values.

    Returns:
    str: The modified JSON text with replacements applied.
    """
    for old_text, new_text in replacement_dict.items():
        json_text = json_text.replace(old_text, new_text)
    return json_text


def update_json_file(
    file_path: str,
    column_replacement_dict: dict[str, str] | None = None,
    file_replacement_dict: dict[str, str] | None = None,
) -> None:
    """
    Update a JSON file by replacing text based on provided replacement dictionaries.

    Parameters:
    file_path (str): The path to the JSON file to be updated.
    column_replacement_dict (dict, optional): A dictionary for column name replacements. Default is None.
    file_replacement_dict (dict, optional): A dictionary for file name replacements. Default is None.

    Returns:
    None
    """
    with Path(file_path).open(encoding="utf-8") as file:
        json_text = file.read()

    if column_replacement_dict:
        json_text = replace_text_in_json(json_text, column_replacement_dict)

    if file_replacement_dict:
        json_text = replace_text_in_json(json_text, file_replacement_dict)

    with Path(file_path).open("w", encoding="utf-8") as file:
        file.write(json_text)


def sort_replacement_dict(replacement_dict: dict[str, str]) -> dict[str, str]:
    """
    Sorts a dictionary by the length of its keys in descending order.

    Args:
        replacement_dict (dict): Dictionary with replacement keys and values.

    Returns:
        dict: Sorted dictionary by key length (longest to shortest).
    """
    return dict(
        sorted(replacement_dict.items(), key=lambda item: len(item[0]), reverse=True)
    )
