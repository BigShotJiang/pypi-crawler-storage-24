import pandas as pd

from .string_functions import translate_column_values


def remove_csv_columns(
    file_name: str, df: pd.DataFrame, columns_to_drop: dict[str, list[str]]
) -> pd.DataFrame:
    """
    Remove unnecessary columns from the DataFrame as per the provided definitions.

    Parameters:
    file_name (str): The name of the file being processed.
    df (pd.DataFrame): The DataFrame from which columns will be removed.
    columns_to_drop (dict): Dict mapping file names to lists of columns to drop.

    Returns:
    pd.DataFrame: The DataFrame with the specified columns removed.
    """
    if file_name in columns_to_drop:
        columns_to_remove = columns_to_drop[file_name]
        df.drop(
            columns=columns_to_remove, inplace=True, errors="ignore"
        )  # handle missing columns
    return df


def transform_csv_text_column(
    df: pd.DataFrame, exclude_columns: list[str], text_mapping: dict[str, str]
) -> pd.DataFrame:
    """
    Transform text columns in the DataFrame by translating text per a predefined mapping.

    Parameters:
    df (pd.DataFrame): The DataFrame to be transformed.
    exclude_columns (list): List of columns to exclude from transformation.
    text_mapping (dict): The dictionary containing text mappings.

    Returns:
    pd.DataFrame: The transformed DataFrame with translated text columns.
    """
    # Iterate over each column and apply transformation only to object (text) columns
    for column in df.select_dtypes(include=["object"]).columns:
        # Skip columns in the exclusion list
        if column not in exclude_columns:
            df[column] = translate_column_values(df[column], text_mapping)

    # Return the transformed DataFrame
    return df
