"""
API handling utilities for Microsoft Graph and Power BI Admin APIs.
"""

import time
from collections import defaultdict
from typing import Any, Dict, Optional

import msal
import requests
from azure.identity import ClientSecretCredential

from .utils.logging_setup import setup_logger


class MSGraphApi:
    """
    A helper class to handle Microsoft Graph API
    using client credential authentication and automatic pagination.
    """

    SCOPE = ["https://graph.microsoft.com/.default"]
    AUTH_URL = "https://login.microsoftonline.com"

    def __init__(
        self,
        tenant_id: str,
        client_id: str,
        client_secret: str,
        logger: Optional[Any] = None,
    ) -> None:
        self.tenant_id = tenant_id
        self.client_id = client_id
        self.client_secret = client_secret

        self.app = msal.ConfidentialClientApplication(
            client_id=self.client_id,
            client_credential=self.client_secret,
            authority=f"{self.AUTH_URL}/{self.tenant_id}",
        )

        self.logger = logger or setup_logger()
        if self.logger:
            self.logger.info("MS GraphApi initialized.")

    def _build_headers(self) -> Dict[str, str]:
        token = self.app.acquire_token_for_client(scopes=self.SCOPE)["access_token"]
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "ConsistencyLevel": "eventual",
        }

    def get_all_pages(self, url: str) -> Dict[str, Any]:
        """
        Standard pagination using @odata.nextLink.
        """
        headers = self._build_headers()
        session = requests.Session()
        session.headers.update(headers)

        aggregated_items: list = []
        retryable = {429, 500, 502, 503, 504}
        next_url = url
        attempts = 0

        while next_url:
            response = session.get(next_url)

            if response.status_code in retryable:
                retry_after = response.headers.get("Retry-After")
                delay = (
                    int(retry_after)
                    if retry_after and retry_after.isdigit()
                    else min(2**attempts, 60)
                )
                if self.logger:
                    self.logger.warning(
                        f"{response.status_code} retrying in {delay}s ..."
                    )
                time.sleep(delay)
                attempts += 1
                if attempts > 5:
                    raise Exception(f"Too many retries for URL: {next_url}")
                continue

            if response.status_code != 200:
                msg = f"GET failed ({response.status_code}): {response.text}"
                if self.logger:
                    self.logger.error(msg)
                raise Exception(msg)

            attempts = 0
            data = response.json()

            # Append only 'value' items if present and is a list
            page_items = data.get("value", [])
            if isinstance(page_items, list) and page_items:
                aggregated_items.extend(page_items)

            # Track last @odata.nextLink
            delta_link = data.get("@odata.deltaLink", None)
            next_url = data.get("@odata.nextLink")

        if self.logger:
            self.logger.info(
                f"All pages retrieved successfully. Total items: "
                f"{len(aggregated_items)}"
            )

        return {"value": aggregated_items, "delta_link": delta_link}


class PowerBIAdminApi:
    """
    A helper class for interacting with the Microsoft Power BI Admin APIs
    using a client credential (service principal) authentication flow.
    """

    # Class-level constants
    SCOPE: str = "https://analysis.windows.net/powerbi/api/.default"
    BASE_URL: str = "https://api.powerbi.com/v1.0/myorg"

    def __init__(
        self,
        tenant_id: str,
        client_id: str,
        client_secret: str,
        logger: Optional[Any] = None,
    ) -> None:
        """
        Initialize PowerBI admin helper class.

        :param tenant_id: Azure AD tenant ID
        :param client_id: Service principal client ID
        :param client_secret: Service principal client secret
        :param logger: Optional logger instance
        """
        self.credential = ClientSecretCredential(
            tenant_id=tenant_id, client_id=client_id, client_secret=client_secret
        )

        self.logger = logger or setup_logger()
        self.logger.info("PowerBIAdminApi initialized.")

    # ------------------------------------------------------
    # SINGLE: BUILD HEADERS (GETS TOKEN + FORMS HEADERS)
    # ------------------------------------------------------
    def _build_headers(self) -> Dict[str, str]:
        """
        Build HTTP request headers with a fresh OAuth2 bearer token.

        :return: A dictionary with Authorization and Content-Type headers.
        """
        token = self.credential.get_token(self.SCOPE).token
        return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    # ------------------------------------------------------
    # GET REQUEST
    # ------------------------------------------------------
    def get_response(self, url: str) -> Dict[str, Any]:
        """
        Send a GET request with full pagination and retry handling.
        Returns a merged JSON response containing all pages.

        :param url: Full request URL
        :return: JSON response as dict
        """
        headers = self._build_headers()
        resp = requests.get(url, headers=headers)

        if resp.status_code != 200:
            self.logger.error(f"GET failed ({resp.status_code}): {resp.text}")
            raise Exception(resp.text)

        data = resp.json()
        return data

    # ------------------------------------------------------
    # GET REQUEST - Paginated
    # ------------------------------------------------------
    def get_paginated_response(self, url: str) -> Dict[str, Any]:
        """
        GET request with full pagination + retry handling.
        Supports only Power BI REST API pagination via continuationUri.
        """

        headers = self._build_headers()
        session = requests.Session()
        session.headers.update(headers)

        next_url = url
        attempt = 0

        aggregated = defaultdict(list)
        retryable = {429, 500, 502, 503, 504}

        while next_url:
            response = session.get(next_url)

            # Retry for transient errors (429, 5xx)
            if response.status_code in retryable:
                retry_after = response.headers.get("Retry-After")
                delay = (
                    int(retry_after)
                    if retry_after and retry_after.isdigit()
                    else min(2**attempts, 60)
                )

                self.logger.warning(
                    f"{response.status_code} received. Retrying in {delay}s… "
                    f"({attempt+1}/5)"
                )
                time.sleep(delay)

                attempt += 1
                if attempt > 5:
                    raise Exception(f"Too many retries for URL: {next_url}")
                continue

            # Hard failure
            if response.status_code != 200:
                self.logger.error(
                    f"GET failed ({response.status_code}): {response.text}"
                )
                raise Exception(response.text)

            # Success
            attempt = 0
            data = response.json()

            # Merge keys (list keys extended, non-list keys stored last)
            for key, value in data.items():
                if isinstance(value, list):
                    aggregated[key].extend(value)
                else:
                    aggregated[key] = value

            # Pagination handling
            if data.get("continuationUri", None):
                next_url = data.get("continuationUri")
            else:
                next_url = None  # No more pages

        self.logger.info("✅ All pages collected successfully.")
        return dict(aggregated)

    # ------------------------------------------------------
    # POST REQUEST – START WORKSPACE SCAN
    # ------------------------------------------------------
    def post_request(self, url: str, body: Dict[str, Any]) -> str:
        """
        Send a POST request and extract scanId from response.

        :param url: POST URL
        :param body: JSON request body
        :return: scanId value
        """
        headers = self._build_headers()
        resp = requests.post(url, json=body, headers=headers)

        if resp.status_code not in (200, 202):
            self.logger.error(f"POST failed ({resp.status_code}): {resp.text}")
            raise Exception(resp.text)

        data = resp.json()
        scan_id = data.get("id") or data.get("scanId")

        if not scan_id:
            self.logger.error("scanId missing from response.")
            raise Exception("scanId missing")

        self.logger.info(f"Scan started. scanId={scan_id}")
        return scan_id

    # ------------------------------------------------------
    # POLL STATUS
    # ------------------------------------------------------
    def poll_scan_status(self, url: str, scan_id: str) -> Dict[str, Any]:
        """
        Poll the scan status until completion.

        :param url: Scan status URL
        :param scan_id: Scan identifier
        :return: JSON response with final status
        """
        poll_interval = 10
        max_attempts = 60
        headers = self._build_headers()
        self.logger.info(f"Polling status for scanId={scan_id}")

        url = f"{url}/{scan_id}"
        for attempt in range(1, max_attempts + 1):
            resp = requests.get(url, headers=headers)

            if resp.status_code != 200:
                self.logger.error(f"Polling failed ({resp.status_code}): {resp.text}")
                raise Exception(resp.text)

            data = resp.json()
            status = data.get("status")
            self.logger.info(f"Attempt {attempt}: status={status}")

            if status in ("Succeeded", "Failed", "Unknown"):
                return data

            time.sleep(poll_interval)

        raise TimeoutError("Scan polling timed out.")

    # ------------------------------------------------------
    # GET SCAN RESULT
    # ------------------------------------------------------
    def get_scan_result(self, url: str, scan_id: str) -> Dict[str, Any]:
        """
        Retrieve the final scan result.

        :param url: Scan result URL
        :param scan_id: Scan identifier
        :return: JSON scan result
        """
        headers = self._build_headers()
        self.logger.info(f"Fetching scanResult for scanId={scan_id}")
        url = f"{url}/{scan_id}"
        resp = requests.get(url, headers=headers)

        if resp.status_code != 200:
            self.logger.error(f"Result fetch failed ({resp.status_code}): {resp.text}")
            raise Exception(resp.text)

        data = resp.json()
        self.logger.info("Scan result retrieved successfully.")
        return data
