# Prompt SDK - 提示词管理 SDK

[![PyPI version](https://badge.fury.io/py/huace-aigc-prompt-client.svg)](https://badge.fury.io/py/huace-aigc-prompt-client)
[![Python](https://img.shields.io/pypi/pyversions/huace-aigc-prompt-client)](https://pypi.org/project/huace-aigc-prompt-client/)

## 核心特性

### 1. 轻量级客户端
专注于提示词（Prompt）的管理，提供简洁的 API 接口：

- `set` - 新增/更新提示词（自动版本管理）
- `get` - 获取提示词最新版本
- `get_histories` - 获取提示词历史版本
- `delete` - 删除提示词（软删除）

### 2. 统一异常体系
针对不同错误类型设计对应的异常类：

- `AuthenticationError` - 认证/鉴权失败（401/403）
- `NotFoundError` - 资源未找到（404）
- `RateLimitError` - 限流（429）
- `ConflictError` - 冲突（409）
- `ValidationError` - 参数校验失败（400）
- `ServerError` - 服务端错误（5xx）

### 3. 自动链路追踪
基于 `huace-aigc-auth-client` 自动注入 trace_id，便于问题排查。

### 4. 请求重试机制
对幂等读操作（get、get_histories）自动重试，提高可用性。

## 安装

```bash
pip install huace-aigc-prompt-client
```

## 快速开始

```python
from huace_aigc_prompt_client import PromptSDK

# 初始化
sdk = PromptSDK(
    api_key="your_api_key",
    base_url="http://localhost:7805"
)

# 新增提示词
result = sdk.set(
    prompt_type="system",
    key="chat_template",
    custom_prompt="You are a helpful AI assistant."
)

# 获取提示词
prompt = sdk.get(prompt_type="system", key="chat_template")
print(prompt["custom_prompt"])
```

## License

MIT License
