"""
SDK 测试脚本

模拟其他业务调用本 SDK 的场景，测试 SDK 方法的正确性。

使用方式：
1. 激活 conda 环境：conda activate aigc-prompt
2. 配置下方的环境变量（直接修改本文件中的配置）
3. 运行脚本：python -m huace_aigc_prompt_client.test.test_sdk

环境变量配置（直接在此处修改）：
"""

import os
import sys
import logging
from typing import Optional

# ============================================================
# 环境变量配置（请在此处修改为实际值）
# ============================================================

# aigc-auth 配置
AIGC_AUTH_APP_ID = "10"           # aigc-auth 应用 ID
AIGC_AUTH_APP_SECRET = "sk_TDKUREW2agZhaTpOmoOc0CffdlkEd88x"     # aigc-auth 应用密钥
AIGC_AUTH_BASE_URL = "https://aigc-auth.huacemedia.com/aigc-auth/api/v1"        # aigc-auth 服务地址

# 用户访问令牌（登录后获取，用于调用需要认证的 API）
ACCESS_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2NTAiLCJleHAiOjE3NzQzMjU4MDAsInR5cGUiOiJhY2Nlc3MifQ.8PDdLT0YUkG_UXMHg0q1rqwUPgz_3-RBN5Roo2uqbBE"  # 留空则使用 aigc-auth 的 app 级别认证；填写后优先使用用户令牌

# prompt SDK 配置
PROMPT_SDK_API_KEY = "ak_53GZp5MVl51xtnFwtRKOQzkKC_M6dss0GpBjYizMKng"         # 业务 API Key（用于调用 prompt 服务）
PROMPT_SDK_BASE_URL = "http://0.0.0.0:7805"  # prompt 服务 base URL

# 测试配置
SKIP_NETWORK_TESTS = False  # 是否跳过网络测试（当后端服务未运行时设为 True）

# ============================================================
# 配置结束，以下为测试代码
# ============================================================

# 检查依赖
try:
    import huace_aigc_auth_client
except ImportError:
    print("错误: 缺少依赖 'huace-aigc-auth-client'")
    print("请运行以下命令安装:")
    print("  pip install huace-aigc-auth-client")
    sys.exit(1)

# 设置环境变量（供 SDK 使用）
os.environ["AIGC_AUTH_APP_ID"] = AIGC_AUTH_APP_ID
os.environ["AIGC_AUTH_APP_SECRET"] = AIGC_AUTH_APP_SECRET
os.environ["AIGC_AUTH_BASE_URL"] = AIGC_AUTH_BASE_URL
os.environ["PROMPT_SDK_API_KEY"] = PROMPT_SDK_API_KEY
os.environ["PROMPT_SDK_BASE_URL"] = PROMPT_SDK_BASE_URL

# 如果配置了 access_token，也设置到环境变量
if ACCESS_TOKEN:
    os.environ["AIGC_AUTH_TOKEN"] = ACCESS_TOKEN

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# 添加 SDK 源码路径（支持直接运行和模块运行）
_sdk_path = os.path.join(os.path.dirname(__file__), "..", "src")
if _sdk_path not in sys.path:
    sys.path.insert(0, os.path.abspath(_sdk_path))


def check_env_vars() -> bool:
    """检查必要的环境变量"""
    required_vars = [
        "AIGC_AUTH_APP_ID",
        "AIGC_AUTH_APP_SECRET",
        "AIGC_AUTH_BASE_URL",
        "PROMPT_SDK_API_KEY",
        "PROMPT_SDK_BASE_URL",
    ]

    # 检查是否已配置（文件顶部已设置，但检查是否为默认值）
    default_values = {
        "AIGC_AUTH_APP_ID": "your_app_id",
        "AIGC_AUTH_APP_SECRET": "your_app_secret",
        "AIGC_AUTH_BASE_URL": "your_auth_url",
        "PROMPT_SDK_API_KEY": "your_api_key",
        "PROMPT_SDK_BASE_URL": "http://localhost:8000",
    }

    has_default = False
    for var in required_vars:
        if os.environ.get(var) == default_values.get(var):
            logger.warning(f"环境变量 {var} 仍为默认值，请修改为实际值")
            has_default = True

    if has_default:
        logger.error("请先修改文件顶部的环境变量配置为实际值")
        return False
    return True


def test_sdk_init():
    """测试 SDK 初始化"""
    logger.info("=" * 50)
    logger.info("测试 1: SDK 初始化")
    logger.info("=" * 50)

    from huace_aigc_prompt_client import PromptSDK

    # 测试 1.1: 使用环境变量初始化
    sdk = PromptSDK()
    logger.info(f"SDK 初始化成功, base_url: {sdk.config.base_url}")
    logger.info(f"API Key: {sdk.config.api_key[:10]}...")

    # 测试 1.2: 显式传入参数
    sdk2 = PromptSDK(
        api_key=os.environ.get("PROMPT_SDK_API_KEY"),
        base_url=os.environ.get("PROMPT_SDK_BASE_URL"),
    )
    logger.info(f"SDK 显式初始化成功, base_url: {sdk2.config.base_url}")

    # 测试 1.3: 缺少 api_key 应抛出异常
    try:
        # 临时清除环境变量
        old_key = os.environ.pop("PROMPT_SDK_API_KEY", None)
        sdk3 = PromptSDK(base_url="http://test.com")
        # 恢复环境变量
        if old_key:
            os.environ["PROMPT_SDK_API_KEY"] = old_key
        logger.error("应该抛出 ValueError")
        return False
    except ValueError as e:
        logger.info(f"正确抛出异常: {e}")
    finally:
        # 确保环境变量恢复
        if "PROMPT_SDK_API_KEY" not in os.environ:
            os.environ["PROMPT_SDK_API_KEY"] = os.environ.get("PROMPT_SDK_API_KEY", "")

    # 测试 1.4: 缺少 base_url 应抛出异常
    try:
        # 临时清除环境变量
        old_url = os.environ.pop("PROMPT_SDK_BASE_URL", None)
        sdk4 = PromptSDK(api_key="test-key")
        # 恢复环境变量
        if old_url:
            os.environ["PROMPT_SDK_BASE_URL"] = old_url
        logger.error("应该抛出 ValueError")
        return False
    except ValueError as e:
        logger.info(f"正确抛出异常: {e}")
    finally:
        # 确保环境变量恢复
        if "PROMPT_SDK_BASE_URL" not in os.environ:
            os.environ["PROMPT_SDK_BASE_URL"] = os.environ.get("PROMPT_SDK_BASE_URL", "")

    logger.info("✓ SDK 初始化测试通过")
    return True


def test_sdk_set(sdk) -> bool:
    """测试新增/更新提示词"""
    if SKIP_NETWORK_TESTS:
        logger.warning("⚠ 跳过 prompt_set 测试（需要后端服务）")
        return True

    logger.info("=" * 50)
    logger.info("测试 2: prompt_set - 新增提示词")
    logger.info("=" * 50)

    try:
        # 测试 2.1: 新增提示词（key 不存在）
        result = sdk.set(
            prompt_type="system",
            key="test_sdk_key_v1",
            custom_prompt="这是测试提示词内容 - v1",
        )
        logger.info(f"新增提示词成功: {result}")
        prompt_id = result.get("prompt_id")
        version = result.get("version")

        # 测试 2.2: 再次设置同一 key（应生成新版本）
        result2 = sdk.set(
            prompt_type="system",
            key="test_sdk_key_v1",
            custom_prompt="这是测试提示词内容 - v2",
        )
        logger.info(f"更新提示词成功: {result2}")
        logger.info(f"新版本号: {result2.get('version')}, 旧版本号: {version}")

        if result2.get("version") > version:
            logger.info("✓ 版本号正确递增")
        else:
            logger.warning("✗ 版本号未递增")

        logger.info("✓ prompt_set 测试通过")
        return True

    except Exception as e:
        logger.error(f"✗ prompt_set 测试失败: {e}")
        return False


def test_sdk_get(sdk) -> bool:
    """测试获取提示词"""
    if SKIP_NETWORK_TESTS:
        logger.warning("⚠ 跳过 prompt_get 测试（需要后端服务）")
        return True

    logger.info("=" * 50)
    logger.info("测试 3: prompt_get - 获取提示词")
    logger.info("=" * 50)

    try:
        # 先创建一个提示词
        sdk.set(
            prompt_type="user",
            key="test_get_key",
            custom_prompt="获取测试内容",
        )

        # 测试 3.1: 获取存在的提示词
        result = sdk.get(
            prompt_type="user",
            key="test_get_key",
        )
        logger.info(f"获取提示词成功: {result}")
        logger.info(f"prompt_id: {result.get('prompt_id')}, version: {result.get('version')}")

        # 测试 3.2: 获取不存在的提示词
        try:
            sdk.get(
                prompt_type="user",
                key="non_existent_key_12345",
            )
            logger.error("应该抛出 NotFoundError")
            return False
        except Exception as e:
            logger.info(f"正确抛出异常: {type(e).__name__}")

        logger.info("✓ prompt_get 测试通过")
        return True

    except Exception as e:
        logger.error(f"✗ prompt_get 测试失败: {e}")
        return False


def test_sdk_get_histories(sdk) -> bool:
    """测试获取提示词历史"""
    if SKIP_NETWORK_TESTS:
        logger.warning("⚠ 跳过 prompt_get_histories 测试（需要后端服务）")
        return True

    logger.info("=" * 50)
    logger.info("测试 4: prompt_get_histories - 获取历史版本")
    logger.info("=" * 50)

    try:
        key = "test_history_key"

        # 创建多个版本
        for i in range(3):
            sdk.set(
                prompt_type="assistant",
                key=key,
                custom_prompt=f"历史版本 {i + 1}",
            )

        # 测试 4.1: 获取历史版本
        histories = sdk.get_histories(
            prompt_type="assistant",
            key=key,
        )
        logger.info(f"获取到 {len(histories)} 个历史版本")
        for h in histories:
            logger.info(f"  - version: {h.get('version')}, content: {h.get('custom_prompt')}")

        # 测试 4.2: 分页
        histories_page1 = sdk.get_histories(
            prompt_type="assistant",
            key=key,
            page=1,
            page_size=2,
        )
        logger.info(f"分页获取: 第1页 {len(histories_page1)} 条")

        logger.info("✓ prompt_get_histories 测试通过")
        return True

    except Exception as e:
        logger.error(f"✗ prompt_get_histories 测试失败: {e}")
        return False


def test_sdk_delete(sdk) -> bool:
    """测试删除提示词"""
    if SKIP_NETWORK_TESTS:
        logger.warning("⚠ 跳过 prompt_delete 测试（需要后端服务）")
        return True

    logger.info("=" * 50)
    logger.info("测试 5: prompt_delete - 删除提示词")
    logger.info("=" * 50)

    try:
        key = "test_delete_key"

        # 先创建提示词
        sdk.set(
            prompt_type="system",
            key=key,
            custom_prompt="删除测试",
        )

        # 测试 5.1: 删除提示词
        result = sdk.delete(
            prompt_type="system",
            key=key,
        )
        logger.info(f"删除结果: {result}")
        deleted_count = result.get("deleted_count", 0)

        if deleted_count > 0:
            logger.info(f"✓ 成功删除 {deleted_count} 条记录")
        else:
            logger.warning("✗ 删除记录数为 0")

        # 测试 5.2: 重复删除（幂等）
        result2 = sdk.delete(
            prompt_type="system",
            key=key,
        )
        logger.info(f"重复删除结果: {result2}")

        logger.info("✓ prompt_delete 测试通过")
        return True

    except Exception as e:
        logger.error(f"✗ prompt_delete 测试失败: {e}")
        return False


def test_trace_id_inheritance(sdk) -> bool:
    """测试 trace_id 继承"""
    logger.info("=" * 50)
    logger.info("测试 6: trace_id 继承")
    logger.info("=" * 50)

    try:
        from huace_aigc_auth_client import set_request_context, get_trace_id

        # 测试 6.1: 设置外部 trace_id
        external_trace_id = "test-external-trace-id-12345"
        set_request_context(trace_id=external_trace_id)

        # 调用 SDK，验证 trace_id 被正确传递
        # 由于我们只是验证 set_request_context 是否被正确调用，这里不实际发起请求
        current_trace = get_trace_id()
        logger.info(f"当前 trace_id: {current_trace}")

        if current_trace == external_trace_id:
            logger.info("✓ trace_id 正确继承")
        else:
            logger.warning(f"trace_id 不匹配: 期望 {external_trace_id}, 实际 {current_trace}")

        # 测试 6.2: 不设置 trace_id 时应有默认值
        # 清空上下文后，SDK 应使用默认 trace_id
        # 实际由 auth_request 处理

        logger.info("✓ trace_id 继承测试通过")
        return True

    except Exception as e:
        logger.error(f"✗ trace_id 继承测试失败: {e}")
        return False


def test_prompt_list(sdk) -> bool:
    """测试提示词列表（直接调用内部方法）"""
    if SKIP_NETWORK_TESTS:
        logger.warning("⚠ 跳过 prompt_list 测试（需要后端服务）")
        return True

    logger.info("=" * 50)
    logger.info("测试 7: prompt_list - 提示词列表")
    logger.info("=" * 50)

    try:
        # 先创建几个测试数据
        for i in range(3):
            sdk.set(
                prompt_type="system",
                key=f"test_list_key_{i}",
                custom_prompt=f"列表测试内容 {i}",
            )

        # 直接调用 _request 获取列表
        result = sdk._request(
            "POST",
            "/api/v1/prompt_list",
            json={
                "prompt_type": "system",
                "page": 1,
                "page_size": 10,
            },
            allow_retry=True,
        )

        logger.info(f"获取列表成功，总数: {result.get('total')}")
        items = result.get("items", [])
        logger.info(f"当前页数量: {len(items)}")

        for item in items[:3]:  # 只打印前3条
            logger.info(f"  - key: {item.get('key')}, version: {item.get('version')}")

        logger.info("✓ prompt_list 测试通过")
        return True

    except Exception as e:
        logger.error(f"✗ prompt_list 测试失败: {e}")
        return False


def run_all_tests():
    """运行所有测试"""
    logger.info("开始 SDK 测试...")
    logger.info(f"Python: {sys.version}")

    # 检查环境变量
    if not check_env_vars():
        logger.error("环境变量检查失败，请配置必要变量后重试")
        sys.exit(1)

    # 设置 access_token（如果配置了的话）
    if ACCESS_TOKEN:
        from huace_aigc_auth_client import set_request_context
        set_request_context(token=ACCESS_TOKEN)
        logger.info(f"已设置 access_token: {ACCESS_TOKEN[:20]}...")

    # 检查是否跳过网络测试
    if SKIP_NETWORK_TESTS:
        logger.warning("⚠ 已配置 SKIP_NETWORK_TESTS=True，跳过需要后端服务的测试")

    # 导入 SDK
    from huace_aigc_prompt_client import PromptSDK

    # 初始化 SDK
    sdk = PromptSDK()

    # 运行测试
    tests = [
        ("SDK 初始化", test_sdk_init),
        ("trace_id 继承", lambda: test_trace_id_inheritance(sdk)),
        ("新增提示词", lambda: test_sdk_set(sdk)),
        # ("获取提示词", lambda: test_sdk_get(sdk)),
        # ("获取历史版本", lambda: test_sdk_get_histories(sdk)),
        # ("删除提示词", lambda: test_sdk_delete(sdk)),
        # ("提示词列表", lambda: test_prompt_list(sdk)),
    ]

    results = []
    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            logger.exception(f"测试 '{name}' 发生异常: {e}")
            results.append((name, False))

    # 输出汇总
    logger.info("=" * 50)
    logger.info("测试汇总")
    logger.info("=" * 50)

    passed = 0
    failed = 0
    for name, result in results:
        status = "✓ PASS" if result else "✗ FAIL"
        logger.info(f"{status}: {name}")
        if result:
            passed += 1
        else:
            failed += 1

    logger.info("=" * 50)
    logger.info(f"总计: {passed} 通过, {failed} 失败")
    logger.info("=" * 50)

    return failed == 0


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
