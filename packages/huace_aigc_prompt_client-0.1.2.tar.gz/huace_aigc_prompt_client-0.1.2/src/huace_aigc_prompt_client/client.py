"""
Prompt SDK Python - Main SDK Implementation

A lightweight SDK for managing prompts via API.
"""

from __future__ import annotations

import os
import time
import logging
from dataclasses import dataclass
from typing import Optional, Any

# 尝试导入 get_current_username，如果失败则提供空实现
try:
    from huace_aigc_auth_client.user_context import get_current_username
except ImportError:
    def get_current_username():
        """当 huace_aigc_auth_client 未正确安装时的空实现"""
        return None

from huace_aigc_auth_client import (
    auth_request,
    set_request_context,
    add_to_request_context,
    get_trace_id,
    get_request_context,
    AigcAuthError,
)


# ============================================================
# 配置
# ============================================================


@dataclass(frozen=True)
class SDKConfig:
    """SDK 配置"""
    base_url: str
    api_key: str
    timeout: float = 10.0
    max_retries: int = 2


# ============================================================
# 异常体系
# ============================================================


class PromptSDKError(Exception):
    """SDK 基类异常"""

    def __init__(
        self,
        message: str,
        error_reason: Optional[str] = None,
        status_code: Optional[int] = None,
        trace_id: Optional[str] = None,
    ):
        super().__init__(message)
        self.message = message
        self.error_reason = error_reason
        self.status_code = status_code
        self.trace_id = trace_id


class AuthenticationError(PromptSDKError):
    """认证/鉴权失败（401/403 或 AUTH_* 错误码）"""
    pass


class NotFoundError(PromptSDKError):
    """资源未找到（404 或 NOT_FOUND 错误码）"""
    pass


class RateLimitError(PromptSDKError):
    """限流（429 或 RATE_LIMIT 错误码）"""
    pass


class ConflictError(PromptSDKError):
    """冲突（409 或 CONFLICT 错误码）"""
    pass


class ValidationError(PromptSDKError):
    """参数校验失败（400 或 VALIDATION_ERROR）"""
    pass


class ServerError(PromptSDKError):
    """服务端错误（5xx 或 SERVER_ERROR）"""
    pass


# ============================================================
# SDK 核心类
# ============================================================


class PromptSDK:
    """Prompt SDK 主类"""

    USER_AGENT = "prompt-sdk-python/0.1.0"

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 10.0,
        max_retries: int = 2,
        logger: Optional[logging.Logger] = None,
    ):
        """
        初始化 SDK

        使用 aigc-auth SDK 的 auth_request 作为底层 HTTP 请求封装：
        - 通过 auth_request 统一注入 trace/统计/链路追踪头
        - 通过 X-API-Key header 传递业务 API Key 进行鉴权

        Args:
            api_key: 业务 API Key（未传则从 PROMPT_SDK_API_KEY 环境变量读取）
            base_url: 基础 URL（未传则从 PROMPT_SDK_BASE_URL 读取）
            timeout: 请求超时（秒）
            max_retries: 最大重试次数（仅对幂等读接口生效）
            logger: 自定义 logger
        """
        api_key = api_key or os.environ.get("PROMPT_SDK_API_KEY")
        base_url = base_url or os.environ.get("PROMPT_SDK_BASE_URL")

        if not api_key:
            raise ValueError("missing api_key (param or env PROMPT_SDK_API_KEY)")
        if not base_url:
            raise ValueError("missing base_url (param or env PROMPT_SDK_BASE_URL)")

        # 去除末尾斜杠
        base_url = base_url.rstrip("/")

        self._config = SDKConfig(
            base_url=base_url,
            api_key=api_key,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._logger = logger or logging.getLogger(__name__)

    @property
    def config(self) -> SDKConfig:
        return self._config

    # ============================================================
    # 请求封装
    # ============================================================

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: Optional[dict] = None,
        params: Optional[dict] = None,
        allow_retry: bool = False,
    ) -> dict:
        """
        统一请求封装（基于 aigc-auth SDK 的 auth_request）

        使用 huace-aigc-auth-client 的 auth_request：
        - 通过 auth_request 统一注入 trace/统计/链路追踪头
        - 追加本服务需要的业务头：api_key（不得在日志中输出明文）
        - trace_id 从调用方继承（如调用方未设置，则由 auth_request 自动生成）

        Args:
            method: HTTP 方法
            path: 请求路径
            json: JSON 请求体
            params: URL 查询参数
            allow_retry: 是否允许重试（仅对幂等读接口）

        Returns:
            解析后的响应数据
        """
        url = f"{self._config.base_url}{path}"

        # 从请求上下文获取 trace_id（由调用方设置），如未设置则由 auth_request 自动生成
        # 注意：get_trace_id() 在未设置时可能返回 "N/A" 或 None
        raw_trace_id = get_trace_id()
        trace_id = raw_trace_id if raw_trace_id and raw_trace_id != "N/A" else "unknown"

        # 添加到请求上下文（保留已有字段如 token，只追加 trace_id）
        add_to_request_context(trace_id=trace_id)

        # 构建业务头
        business_headers = {
            "X-API-Key": self._config.api_key,
        }

        # 从 request_context 获取 token 并添加 Authorization header
        request_context = get_request_context()
        if request_context and request_context.get("token"):
            business_headers["Authorization"] = f"Bearer {request_context['token']}"

        # 脱敏日志：只记录 method 和 path，不记录 api_key
        self._logger.info(
            f"[{trace_id}] {method} {path}",
            extra={
                "trace_id": trace_id,
                "method": method,
                "path": path,
            },
        )

        start_time = time.time()
        last_error: Optional[Exception] = None

        # 重试逻辑
        retries = self._config.max_retries if allow_retry else 0

        for attempt in range(retries + 1):
            try:
                # 使用 aigc-auth SDK 的 auth_request
                response = auth_request(
                    method=method,
                    url=url,
                    json=json,
                    params=params,
                    headers=business_headers,
                    timeout=self._config.timeout,
                )
                break
            except AigcAuthError as e:
                last_error = e
                if attempt < retries:
                    self._logger.warning(
                        f"[{trace_id}] Request failed, retrying ({attempt + 1}/{retries}): {e}"
                    )
                    continue
                raise PromptSDKError(
                    message=f"Request failed: {e.message}",
                    error_reason=e.code,
                )
            except Exception as e:
                last_error = e
                if attempt < retries:
                    self._logger.warning(
                        f"[{trace_id}] Request failed, retrying ({attempt + 1}/{retries})"
                    )
                    continue
                raise

        latency_ms = int((time.time() - start_time) * 1000)

        # 处理响应
        return self._handle_response(response, trace_id, latency_ms)

    def _handle_response(
        self,
        response: Any,
        trace_id: str,
        latency_ms: int,
    ) -> dict:
        """处理响应，解析统一结构或抛出异常"""

        # 兼容 httpx.Response (auth_request) 和 requests.Response
        status_code = getattr(response, "status_code", 0)
        text_content = getattr(response, "text", "")

        # 记录日志
        self._logger.info(
            f"[{trace_id}] Response {status_code} ({latency_ms}ms)",
            extra={
                "trace_id": trace_id,
                "status_code": status_code,
                "latency_ms": latency_ms,
            },
        )

        # HTTP 层面错误
        if status_code == 401:
            raise AuthenticationError(
                message="Authentication failed (401)",
                status_code=401,
                trace_id=trace_id,
            )
        if status_code == 403:
            raise AuthenticationError(
                message="Permission denied (403)",
                status_code=403,
                trace_id=trace_id,
            )
        if status_code == 429:
            raise RateLimitError(
                message="Rate limit exceeded (429)",
                status_code=429,
                trace_id=trace_id,
            )
        if status_code >= 500:
            raise ServerError(
                message=f"Server error ({status_code})",
                status_code=status_code,
                trace_id=trace_id,
            )

        # 解析 JSON
        try:
            # httpx.Response 使用 .json() 方法
            if hasattr(response, "json"):
                data = response.json()
            else:
                import json
                data = json.loads(text_content)
        except Exception:
            raise PromptSDKError(
                message=f"Invalid JSON response: {text_content[:200]}",
                status_code=status_code,
                trace_id=trace_id,
            )

        # 统一响应结构
        if isinstance(data, dict):
            if not data.get("success", True):
                error_reason = data.get("error_reason", "UNKNOWN")
                message = data.get("message", "Unknown error")

                # 错误码映射
                if error_reason.startswith("AUTH_"):
                    raise AuthenticationError(
                        message=message,
                        error_reason=error_reason,
                        status_code=status_code,
                        trace_id=trace_id,
                    )
                elif error_reason == "NOT_FOUND":
                    raise NotFoundError(
                        message=message,
                        error_reason=error_reason,
                        status_code=status_code,
                        trace_id=trace_id,
                    )
                elif error_reason == "RATE_LIMIT":
                    raise RateLimitError(
                        message=message,
                        error_reason=error_reason,
                        status_code=status_code,
                        trace_id=trace_id,
                    )
                elif error_reason == "CONFLICT":
                    raise ConflictError(
                        message=message,
                        error_reason=error_reason,
                        status_code=status_code,
                        trace_id=trace_id,
                    )
                elif error_reason == "VALIDATION_ERROR":
                    raise ValidationError(
                        message=message,
                        error_reason=error_reason,
                        status_code=status_code,
                        trace_id=trace_id,
                    )
                else:
                    raise PromptSDKError(
                        message=message,
                        error_reason=error_reason,
                        status_code=status_code,
                        trace_id=trace_id,
                    )

            # 返回 data 字段
            return data.get("data", {})

        return data

    # ============================================================
    # 业务方法
    # ============================================================

    def set(
        self,
        prompt_type: str,
        key: str,
        custom_prompt: str,
        operator: Optional[str] = None,
    ) -> dict:
        """
        新增或更新提示词（生成新版本）

        对应 POST /api/v1/prompt_add

        Args:
            prompt_type: 提示词类型
            key: 提示词 key
            custom_prompt: 提示词内容
            operator: 操作者标识（可选，默认自动获取aigc-auth用户名，未登录则使用 "api_key_user"）

        Returns:
            {"prompt_id": int, "version": int, ...}
        """
        # 如果未传入 operator，自动获取 aigc-auth 当前用户名
        if operator is None:
            username = get_current_username()
            operator = username if username else "api_key_user"

        json_data = {
            "prompt_type": prompt_type,
            "key": key,
            "custom_prompt": custom_prompt,
            "operator": operator,
        }

        result = self._request(
            "POST",
            "/api/v1/prompt_add",
            json=json_data,
            allow_retry=False,  # 写操作不重试
        )

        # 脱敏日志
        self._logger.info(
            f"[set] prompt_type={prompt_type}, key={key}, version={result.get('version')}",
        )

        return result

    def get(
        self,
        prompt_type: str,
        key: str,
    ) -> dict:
        """
        获取提示词最新版本

        对应 POST /api/v1/prompt_list

        Args:
            prompt_type: 提示词类型
            key: 提示词 key

        Returns:
            提示词详情 {"prompt_id": int, "version": int, "custom_prompt": str, ...}

        Raises:
            NotFoundError: 提示词不存在
        """
        result = self._request(
            "POST",
            "/api/v1/prompt_list",
            json={
                "prompt_type": prompt_type,
                "key": key,
                "page": 1,
                "page_size": 1,
            },
            allow_retry=True,  # 读操作可重试
        )

        items = result.get("items", [])
        if not items:
            raise NotFoundError(
                message=f"Prompt not found: type={prompt_type}, key={key}",
                error_reason="NOT_FOUND",
            )

        return items[0]

    def get_histories(
        self,
        prompt_type: str,
        key: str,
        page: int = 1,
        page_size: int = 50,
    ) -> list[dict]:
        """
        获取提示词历史版本

        对应 POST /api/v1/prompt_history

        Args:
            prompt_type: 提示词类型（必填）
            key: 提示词 key（必填）
            page: 页码
            page_size: 每页数量

        Returns:
            [{"prompt_id": int, "version": int, ...}, ...]
        """
        json_data = {
            "prompt_type": prompt_type,
            "key": key,
            "page": page,
            "page_size": page_size,
        }

        result = self._request(
            "POST",
            "/api/v1/prompt_history",
            json=json_data,
            allow_retry=True,  # 读操作可重试
        )
        return result.get("items", [])

    def delete(
        self,
        prompt_type: str,
        key: str,
        operator: Optional[str] = None,
    ) -> dict:
        """
        删除提示词（按 prompt_type + key 维度删除所有版本，软删除）

        对应 POST /api/v1/prompt_delete

        Args:
            prompt_type: 提示词类型
            key: 提示词 key
            operator: 操作者标识（可选，默认自动获取aigc-auth用户名，未登录则使用 "api_key_user"）

        Returns:
            {"key": str, "prompt_type": str, "deleted_count": int}
        """
        # 如果未传入 operator，自动获取 aigc-auth 当前用户名
        if operator is None:
            username = get_current_username()
            operator = username if username else "api_key_user"

        json_data = {
            "prompt_type": prompt_type,
            "key": key,
            "operator": operator,
        }

        return self._request(
            "POST",
            "/api/v1/prompt_delete",
            json=json_data,
            allow_retry=False,  # 写操作不重试
        )
