"""
Prompt SDK Python

A lightweight SDK for managing prompts via API.

华策AIGC Prompt Client - 提供提示词管理等功能
"""

from huace_aigc_prompt_client.client import PromptSDK
from huace_aigc_prompt_client.client import (
    PromptSDKError,
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ConflictError,
    ValidationError,
    ServerError,
)

__version__ = "0.1.2"
__author__ = "Huace"
__email__ = "support@huace.com"

__all__ = [
    "PromptSDK",
    "PromptSDKError",
    "AuthenticationError",
    "NotFoundError",
    "RateLimitError",
    "ConflictError",
    "ValidationError",
    "ServerError",
]
