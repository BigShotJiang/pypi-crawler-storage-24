# Prompt SDK - 提示词管理 SDK

[![PyPI version](https://badge.fury.io/py/huace-aigc-prompt-client.svg)](https://badge.fury.io/py/huace-aigc-prompt-client)
[![Python](https://img.shields.io/pypi/pyversions/huace-aigc-prompt-client)](https://pypi.org/project/huace-aigc-prompt-client/)

## 核心特性

### 1. 轻量级客户端
专注于提示词（Prompt）的管理，提供简洁的 API 接口：

- ✅ **set** - 新增/更新提示词（自动版本管理）
- ✅ **get** - 获取提示词最新版本
- ✅ **get_histories** - 获取提示词历史版本
- ✅ **delete** - 删除提示词（软删除）

### 2. 统一异常体系
针对不同错误类型设计对应的异常类：

- `AuthenticationError` - 认证/鉴权失败（401/403）
- `NotFoundError` - 资源未找到（404）
- `RateLimitError` - 限流（429）
- `ConflictError` - 冲突（409）
- `ValidationError` - 参数校验失败（400）
- `ServerError` - 服务端错误（5xx）

### 3. 自动链路追踪
基于 `huace-aigc-auth-client` 自动注入 trace_id，便于问题排查。

### 4. 请求重试机制
对幂等读操作（get、get_histories）自动重试，提高可用性。

---

## 安装

```bash
pip install huace-aigc-prompt-client
```

或从源码安装：

```bash
cd sdk
pip install -e .
```

**依赖：**
- `huace-aigc-auth-client` - 认证和链路追踪

---

## 环境配置

### 环境变量

| 环境变量 | 说明 | 必填 | 默认值 | 示例 |
|---------|------|:---:|--------|------|
| `PROMPT_SDK_API_KEY` | 业务 API Key | ✅ | - | `ak_53GZp5MVl51xtn...` |
| `PROMPT_SDK_BASE_URL` | 服务端 base URL | ✅ | - | `http://localhost:7805` |
| `PROMPT_SDK_TIMEOUT` | 请求超时时间（秒） | - | `10.0` | `30.0` |
| `PROMPT_SDK_MAX_RETRIES` | 最大重试次数 | - | `2` | `3` |

### .env 文件配置（推荐）

```bash
# .env
PROMPT_SDK_API_KEY=ak_53GZp5MVl51xtnFwtRKOQzkKC_M6dss0GpBjYizMKng
PROMPT_SDK_BASE_URL=http://localhost:7805
PROMPT_SDK_TIMEOUT=30.0
PROMPT_SDK_MAX_RETRIES=3
```

---

## 快速开始

### 初始化 SDK

```python
from huace_aigc_prompt_client import PromptSDK

# 方式1：环境变量（推荐）
# 设置环境变量或在 .env 文件中配置
import os
os.environ["PROMPT_SDK_API_KEY"] = "ak_53GZp5MVl51xtn..."
os.environ["PROMPT_SDK_BASE_URL"] = "http://localhost:7805"

sdk = PromptSDK()

# 方式2：直接传入参数
sdk = PromptSDK(
    api_key="ak_53GZp5MVl51xtn...",
    base_url="http://localhost:7805",
)

# 方式3：完整配置
sdk = PromptSDK(
    api_key="ak_53GZp5MVl51xtn...",
    base_url="http://localhost:7805",
    timeout=30.0,      # 请求超时 30 秒
    max_retries=3,     # 读操作重试 3 次
)
```

### 新增/更新提示词

```python
# 新增提示词（自动生成版本号 v1）
result = sdk.set(
    prompt_type="system",
    key="chat_template",
    custom_prompt="You are a helpful AI assistant.",
)

print(f"prompt_id: {result['prompt_id']}, version: {result['version']}")
# 输出: prompt_id: 1, version: 1
```

```python
# 更新提示词（自动生成新版本 v2）
result = sdk.set(
    prompt_type="system",
    key="chat_template",
    custom_prompt="You are a helpful and intelligent AI assistant.",
)

print(f"prompt_id: {result['prompt_id']}, version: {result['version']}")
# 输出: prompt_id: 2, version: 2
```

### 获取提示词

```python
# 获取最新版本
prompt = sdk.get(
    prompt_type="system",
    key="chat_template",
)

print(f"内容: {prompt['custom_prompt']}")
print(f"版本: {prompt['version']}")
print(f"prompt_id: {prompt['prompt_id']}")
```

### 获取历史版本

```python
# 获取历史版本列表
histories = sdk.get_histories(
    prompt_type="system",
    key="chat_template",
    page=1,
    page_size=10,
)

for h in histories:
    print(f"version: {h['version']}, created_at: {h.get('created_at')}")
```

### 删除提示词

```python
# 软删除（按 prompt_type + key 维度删除所有版本）
result = sdk.delete(
    prompt_type="system",
    key="chat_template",
)

print(f"已删除 {result['deleted_count']} 个版本")
```

---

## API 参考

### PromptSDK 类

```python
from huace_aigc_prompt_client import PromptSDK

PromptSDK(
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: float = 10.0,
    max_retries: int = 2,
    logger: Optional[logging.Logger] = None,
)
```

#### 构造函数参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|-----|------|:---:|--------|------|
| `api_key` | str | ✅ | - | 业务 API Key，从环境变量 `PROMPT_SDK_API_KEY` 读取或直接传入 |
| `base_url` | str | ✅ | - | 服务端 base URL，从环境变量 `PROMPT_SDK_BASE_URL` 读取或直接传入 |
| `timeout` | float | - | `10.0` | 请求超时时间（秒） |
| `max_retries` | int | - | `2` | 最大重试次数（仅对幂等读操作生效） |
| `logger` | Logger | - | `None` | 自定义 logger，默认使用 `huace_aigc_prompt_client` |

#### 属性

| 属性 | 类型 | 说明 |
|-----|------|------|
| `config` | SDKConfig | SDK 配置对象，包含 base_url、api_key、timeout、max_retries |

---

### SDK 方法

#### set(prompt_type, key, custom_prompt, operator=None) -> dict

新增或更新提示词，自动生成新版本。

**功能说明：**
- 如果 key 不存在，则创建 v1 版本
- 如果 key 已存在，则生成新版本（version +1）
- 如果 key 已被删除（所有版本 is_deleted=1），重新创建时会继续累加版本号
- 已删除的版本保持已删除状态，新版本继续累加
- operator 字段用于记录操作者，默认自动获取 aigc-auth 用户名，未登录则使用 "api_key_user"

**参数：**

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|-----|------|:---:|-------|------|
| `prompt_type` | str | ✅ | - | 提示词类型，如：`system`、`user`、`assistant` |
| `key` | str | ✅ | - | 提示词唯一标识，相同 key + prompt_type 视为同一提示词 |
| `custom_prompt` | str | ✅ | - | 提示词内容 |
| `operator` | str | - | 自动获取 | 操作者标识，未传则自动获取 aigc-auth 用户名，未登录则使用 "api_key_user" |

**返回：**

```python
{
    "prompt_id": int,       # 提示词ID（每次新增/更新都会生成新ID）
    "version": int,        # 版本号，从1开始递增
    "prompt_type": str,    # 提示词类型
    "key": str,            # 提示词 key
    "custom_prompt": str,  # 提示词内容
    "created_at": str,     # 创建时间 ISO格式
}
```

**示例：**

```python
result = sdk.set(
    prompt_type="system",
    key="chat_template",
    custom_prompt="You are a helpful AI.",
)
# 返回: {'prompt_id': 1, 'version': 1, 'prompt_type': 'system', 'key': 'chat_template', ...}
```

**异常：**
- `ValidationError` - 参数校验失败
- `AuthenticationError` - 认证失败
- `ServerError` - 服务端错误

---

#### get(prompt_type, key) -> dict

获取提示词最新版本（未删除的）。

**功能说明：**
- 根据 prompt_type + key 查询最新版本的提示词
- 自动过滤已删除的版本（is_deleted=1）
- 读操作，支持重试

**参数：**

| 参数 | 类型 | 必填 | 说明 |
|-----|------|:---:|------|
| `prompt_type` | str | ✅ | 提示词类型 |
| `key` | str | ✅ | 提示词 key |

**返回：**

```python
{
    "prompt_id": int,       # 提示词ID
    "version": int,         # 版本号
    "prompt_type": str,    # 提示词类型
    "key": str,            # 提示词 key
    "custom_prompt": str,  # 提示词内容
    "created_at": str,     # 创建时间 ISO格式
    "updated_at": str,     # 更新时间 ISO格式
    "is_deleted": int,     # 是否删除，0=未删除
}
```

**示例：**

```python
prompt = sdk.get(
    prompt_type="system",
    key="chat_template",
)
print(prompt['custom_prompt'])
print(prompt['version'])
```

**异常：**
- `NotFoundError` - 提示词不存在
- `AuthenticationError` - 认证失败
- `ServerError` - 服务端错误

---

#### get_histories(prompt_type, key, page=1, page_size=50) -> list[dict]

获取提示词历史版本列表。

**功能说明：**
- 审计视图，固定包含已删除版本
- 按 prompt_type + key 查询（必填）
- 返回所有历史版本（包括已删除的），按版本号倒序
- 读操作，支持重试

**参数：**

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|-----|------|:---:|:---:|------|
| `prompt_type` | str | ✅ | - | 提示词类型 |
| `key` | str | ✅ | - | 提示词 key |
| `page` | int | - | `1` | 页码 |
| `page_size` | int | - | `50` | 每页数量 |

**返回：**

```python
[
    {
        "prompt_id": int,       # 提示词ID
        "version": int,         # 版本号
        "prompt_type": str,    # 提示词类型
        "key": str,            # 提示词 key
        "custom_prompt": str,  # 提示词内容
        "is_deleted": int,     # 是否删除，0=未删除，1=已删除
        "created_at": str,     # 创建时间 ISO格式
        "updated_at": str,     # 更新时间 ISO格式
    },
    ...
]
```

**示例：**

```python
histories = sdk.get_histories(
    prompt_type="system",
    key="chat_template",
    page=1,
    page_size=10,
)

for h in histories:
    print(f"v{h['version']} - {'已删除' if h['is_deleted'] else '活跃'} - {h['created_at']}")
```

**异常：**
- `AuthenticationError` - 认证失败
- `ServerError` - 服务端错误

---

#### delete(prompt_type, key, operator=None) -> dict

删除提示词（软删除，按 prompt_type + key 维度删除所有版本）。

**功能说明：**
- 软删除（is_deleted=1）
- 删除该 (prompt_type, key) 下所有版本
- 重复删除幂等（不会报错）
- operator 字段用于记录操作者，默认自动获取 aigc-auth 用户名，未登录则使用 "api_key_user"

**参数：**

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|-----|------|:---:|-------|------|
| `prompt_type` | str | ✅ | - | 提示词类型 |
| `key` | str | ✅ | - | 提示词 key |
| `operator` | str | - | 自动获取 | 操作者标识，未传则自动获取 aigc-auth 用户名，未登录则使用 "api_key_user" |

**返回：**

```python
{
    "key": str,              # 提示词 key
    "prompt_type": str,      # 提示词类型
    "deleted_count": int,    # 删除的版本数量
}
```

**示例：**

```python
result = sdk.delete(
    prompt_type="system",
    key="chat_template",
)

print(f"已删除 {result['deleted_count']} 个版本")
# 输出: 已删除 3 个版本
```

**异常：**
- `AuthenticationError` - 认证失败
- `ServerError` - 服务端错误

---

## 错误处理

```python
from huace_aigc_prompt_client import (
    PromptSDK,
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ConflictError,
    ValidationError,
    ServerError,
    PromptSDKError,
)

sdk = PromptSDK(
    api_key="your_api_key",
    base_url="http://localhost:7805",
)

try:
    prompt = sdk.get("system", "chat_template")
except NotFoundError as e:
    print(f"提示词不存在: {e.message}")
    print(f"错误码: {e.error_reason}")
except AuthenticationError as e:
    print(f"认证失败: {e.message}")
    print(f"状态码: {e.status_code}")
    print(f"TraceID: {e.trace_id}")
except RateLimitError as e:
    print(f"限流了: {e.message}")
except ConflictError as e:
    print(f"冲突: {e.message}")
except ValidationError as e:
    print(f"参数错误: {e.message}")
except ServerError as e:
    print(f"服务端错误: {e.message}")
except PromptSDKError as e:
    print(f"其他错误: {e.message}")
    print(f"错误码: {e.error_reason}")
```

### 异常属性

所有异常继承自 `PromptSDKError`，包含以下属性：

| 属性 | 类型 | 说明 |
|-----|------|------|
| `message` | str | 错误消息 |
| `error_reason` | str | 错误码，如 `NOT_FOUND`、`AUTH_INVALID_API_KEY` |
| `status_code` | int | HTTP 状态码 |
| `trace_id` | str | 请求追踪ID，用于日志排查 |

---

## 完整示例

```python
import os
from huace_aigc_prompt_client import PromptSDK, NotFoundError

# 配置
os.environ["PROMPT_SDK_API_KEY"] = "ak_53GZp5MVl51xtn..."
os.environ["PROMPT_SDK_BASE_URL"] = "http://localhost:7805"

# 初始化
sdk = PromptSDK()

# ========== 新增提示词 ==========
result = sdk.set(
    prompt_type="system",
    key="assistant_prompt",
    custom_prompt="You are a helpful coding assistant.",
)
print(f"新增成功: prompt_id={result['prompt_id']}, version={result['version']}")
# 输出: 新增成功: prompt_id=1, version=1

# ========== 获取提示词 ==========
try:
    prompt = sdk.get(prompt_type="system", key="assistant_prompt")
    print(f"当前版本: {prompt['version']}")
    print(f"内容: {prompt['custom_prompt']}")
except NotFoundError:
    print("提示词不存在")

# ========== 更新提示词（自动生成新版本） ==========
result = sdk.set(
    prompt_type="system",
    key="assistant_prompt",
    custom_prompt="You are a helpful and smart coding assistant.",
)
print(f"更新成功: prompt_id={result['prompt_id']}, version={result['version']}")
# 输出: 更新成功: prompt_id=2, version=2

# ========== 获取历史版本 ==========
histories = sdk.get_histories(prompt_type="system", key="assistant_prompt")
print(f"历史版本数: {len(histories)}")
# 输出: 历史版本数: 2

for h in histories:
    status = "已删除" if h['is_deleted'] else "活跃"
    print(f"  v{h['version']} ({status}) - {h['created_at']}")
# 输出:
#   v2 (活跃) - 2026-03-16T12:00:00
#   v1 (活跃) - 2026-03-16T11:00:00

# ========== 删除提示词 ==========
result = sdk.delete(prompt_type="system", key="assistant_prompt")
print(f"已删除 {result['deleted_count']} 个版本")
# 输出: 已删除 2 个版本

# ========== 验证删除 ==========
try:
    prompt = sdk.get(prompt_type="system", key="assistant_prompt")
except NotFoundError:
    print("提示词已删除")
# 输出: 提示词已删除

# ========== 删除后重新创建（版本号继续累加） ==========
result = sdk.set(
    prompt_type="system",
    key="assistant_prompt",
    custom_prompt="You are a helpful coding assistant. v3",
)
print(f"重新创建: prompt_id={result['prompt_id']}, version={result['version']}")
# 输出: 重新创建: prompt_id=3, version=3

# ========== 再次查看历史 ==========
histories = sdk.get_histories(prompt_type="system", key="assistant_prompt")
for h in histories:
    status = "已删除" if h['is_deleted'] else "活跃"
    print(f"  v{h['version']} ({status})")
# 输出:
#   v3 (活跃)
#   v2 (已删除)
#   v1 (已删除)
```

---

## 最佳实践

### 1. 使用环境变量管理配置

```python
# .env 文件
PROMPT_SDK_API_KEY=ak_53GZp5MVl51xtnFwtRKOQzkKC_M6dss0GpBjYizMKng
PROMPT_SDK_BASE_URL=http://localhost:7805
```

```python
from dotenv import load_dotenv
load_dotenv()

from huace_aigc_prompt_client import PromptSDK
sdk = PromptSDK()
```

### 2. 合理设置超时和重试

```python
sdk = PromptSDK(
    api_key="your_api_key",
    base_url="http://localhost:7805",
    timeout=30.0,      # 读操作超时 30 秒
    max_retries=3,     # 读操作重试 3 次
)
```

### 3. 使用自定义 Logger

```python
import logging

# 配置自己的 logger
my_logger = logging.getLogger("my_app")
my_logger.setLevel(logging.DEBUG)
handler = logging.StreamHandler()
handler.setFormatter(logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s"))
my_logger.addHandler(handler)

sdk = PromptSDK(
    api_key="your_api_key",
    base_url="http://localhost:7805",
    logger=my_logger,
)
```

### 4. 链路追踪集成

```python
from huace_aigc_auth_client import set_trace_id
from huace_aigc_prompt_client import PromptSDK

# 设置 trace_id，用于链路追踪
set_trace_id("my-custom-trace-id-12345")

sdk = PromptSDK(
    api_key="your_api_key",
    base_url="http://localhost:7805",
)

# 后续请求都会携带该 trace_id
prompt = sdk.get("system", "chat_template")
```

---

## 认证说明

### API Key 鉴权

SDK 使用 `X-API-Key` Header 进行认证：

```python
# SDK 自动添加该 Header
headers = {
    "X-API-Key": "ak_53GZp5MVl51xtn..."
}
```

### 获取 API Key

API Key 需要在管理后台创建，步骤：
1. 登录管理后台
2. 进入「应用管理」
3. 创建/选择应用
4. 在「API Key」页面创建 Key

---

## 更新日志

### v0.1.0 (2026-03-16)
- ✨ 初始版本
- ✨ 支持 `set` / `get` / `get_histories` / `delete` 方法
- ✨ 基于 `huace-aigc-auth-client` 实现链路追踪
- ✨ 统一的异常体系
- ✨ 请求重试机制（幂等读操作）
- ✨ 支持 `operator` 参数记录操作者
- ✨ 支持删除后重新创建，版本号继续累加

---

## 相关链接

- 📖 [后端 API 文档](./docs/api.md)
- 📦 [PyPI 主页](https://pypi.org/project/huace-aigc-prompt-client/)
- 🐛 [问题反馈](https://github.com/huace-aigc/huace-aigc-prompt-client/issues)

---

## License

MIT License
