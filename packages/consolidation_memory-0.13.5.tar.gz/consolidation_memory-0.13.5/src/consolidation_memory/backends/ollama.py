"""Ollama backend — embeddings and LLM via Ollama's API.

Embedding default: nomic-embed-text (768-dim).
LLM: Any chat model served by Ollama.
"""

import logging

import httpx
import numpy as np

from consolidation_memory.backends import retry_with_backoff
from consolidation_memory.backends.base import normalize_l2

logger = logging.getLogger(__name__)

_TRANSIENT = (httpx.HTTPError, httpx.TimeoutException, ConnectionError, TimeoutError, OSError)


class OllamaEmbeddingBackend:
    def __init__(self, api_base: str, model_name: str, dimension: int):
        # Strip trailing /v1 or /v1/ if present (common misconfiguration from LM Studio defaults)
        base = api_base.rstrip("/")
        if base.endswith("/v1"):
            base = base[:-3]
        self._api_base = base
        self._model_name = model_name
        self._dim = dimension

    @property
    def _is_nomic(self) -> bool:
        return "nomic" in self._model_name.lower()

    def _embed_inputs(self, inputs: list[str]) -> np.ndarray:
        def _do():
            response = httpx.post(
                f"{self._api_base}/api/embed",
                json={"model": self._model_name, "input": inputs},
                timeout=60.0,
            )
            response.raise_for_status()
            return response.json()

        data = retry_with_backoff(
            _do, transient_exceptions=_TRANSIENT, context="Ollama embedding",
        )
        vecs = np.array(data["embeddings"], dtype=np.float32)
        if self._dim == 0:
            self._dim = vecs.shape[1]
        return normalize_l2(vecs)

    def encode_documents(self, texts: list[str]) -> np.ndarray:
        # nomic models require task-specific prefixes for best quality
        prefixed = [f"search_document: {t}" for t in texts] if self._is_nomic else texts
        return self._embed_inputs(prefixed)

    def encode_query(self, text: str) -> np.ndarray:
        prefixed = f"search_query: {text}" if self._is_nomic else text
        return self._embed_inputs([prefixed])

    @property
    def dimension(self) -> int:
        return self._dim


class OllamaLLMBackend:
    def __init__(
        self,
        api_base: str = "http://localhost:11434",
        model: str = "qwen2.5:7b",
        max_tokens: int = 2048,
        temperature: float = 0.3,
    ):
        base = api_base.rstrip("/")
        if base.endswith("/v1"):
            base = base[:-3]
        self._api_base = base
        self._model = model
        self._max_tokens = max_tokens
        self._temperature = temperature

    def generate(self, system_prompt: str, user_prompt: str) -> str:
        def _do():
            response = httpx.post(
                f"{self._api_base}/api/chat",
                json={
                    "model": self._model,
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt},
                    ],
                    "stream": False,
                    "options": {
                        "num_predict": self._max_tokens,
                        "temperature": self._temperature,
                        "top_p": 1.0,
                        "top_k": 0,
                        "repeat_penalty": 1.0,
                    },
                },
                timeout=120.0,
            )
            response.raise_for_status()
            return response.json()["message"]["content"]

        result: str = retry_with_backoff(
            _do, transient_exceptions=_TRANSIENT, context="Ollama LLM",
        )
        return result

    def generate_json(
        self,
        system_prompt: str,
        user_prompt: str,
        json_schema: dict,
    ) -> str:
        # Ollama's chat endpoint may not enforce JSON schema; rely on prompt + validation.
        return self.generate(system_prompt, user_prompt)
