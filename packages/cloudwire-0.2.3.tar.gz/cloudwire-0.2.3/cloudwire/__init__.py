"""CloudWire — scan and visualize your AWS infrastructure."""

__version__ = "0.2.3"
