# The Script And The Library For Odai - @K33Kz -- @K33Ka
# السكربت و المكتبة لعدي @K33Kz - @K33Ka
import requests,re,json,time;from uuid import uuid4
class basic:
    @staticmethod
    def login(email, password, proxies=None):
        r = requests.get("https://www.facebook.com/?_rd")
        m = re.search(r'privacy_mutation_token\s*["\']?\s*[:=]\s*["\']?([A-Za-z0-9_\-:.]+)', r.text)
        token = m.group(1) if m else None
        cok = r.cookies
        fr = cok.get('fr', '')
        session = requests.Session()
        session.cookies.update(cookies_dict)
        headers = {"user-agent": "Mozilla/5.0"}
        url = "https://accountscenter.facebook.com/"
        res = session.get(url, headers=headers).text
        lsd_match = re.search(r'"LSD",\[\],{"token":"(.*?)"}', res)
        lsd = lsd_match.group(1) if lsd_match else None
        cookies = {'datr': '1uBDaYSNCnmSWNXK148RNXci','sb': '1uBDaSJj0uSvPcQFj-09YEP-','ps_l': '1','ps_n': '1','dpr': '2.8035895824432373','m_pixel_ratio': '2.549999952316284','fr': fr,'wd': '891x815'}
        headers = {'authority': 'www.facebook.com','accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','accept-language': 'ar-AE,ar;q=0.9,en-US;q=0.8,en;q=0.7','cache-control': 'max-age=0','content-type': 'application/x-www-form-urlencoded','dpr': '2.549999952316284','origin': 'https://www.facebook.com','referer': 'https://www.facebook.com/?_rdr','sec-ch-prefers-color-scheme': 'dark','sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"','sec-ch-ua-full-version-list': '"Chromium";v="139.0.7339.0", "Not;A=Brand";v="99.0.0.0"','sec-ch-ua-mobile': '?0','sec-ch-ua-model': '""','sec-ch-ua-platform': '"Linux"','sec-ch-ua-platform-version': '""','sec-fetch-dest': 'document','sec-fetch-mode': 'navigate','sec-fetch-site': 'same-origin','sec-fetch-user': '?1','upgrade-insecure-requests': '1','user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36','viewport-width': '980'}
        data = {'jazoest': '21013','lsd': lsd,'user': email,'login_source': 'comet_headerless_login','next': '','encpass': f'PWD_BROWSER:0:{int(time.time())}:{password}'}
        try:   
            response = requests.post(f'https://www.facebook.com/login/?privacy_mutation_token={token}&next',cookies=cookies,headers=headers,data=data,proxies=proxies).text
            account_id = re.search(r'ACCOUNT_ID["\']?\s*[:=]\s*["\']?(\d+)', response)
            user_id = re.search(r'USER_ID["\']?\s*[:=]\s*["\']?(\d+)', response)
            username = re.search(r'USERNAME["\']?\s*[:=]\s*["\']?([a-zA-Z0-9_.]+)', response)
            if (account_id and account_id.group(1) != "0" and 
                user_id and user_id.group(1) != "0" and 
                username and username.group(1) != "0"):
                return json.dumps({"status": "success","account_id": account_id.group(1),"username": username.group(1),"user": email,"password": password,"Dev": "Odai - @K33Kz - @K33Ka"
                })
            elif ('Please complete the security check to log in.' in response or 'two_step_verification' in response or '2fa' in response.lower()):return json.dumps({"status": "checkpoint","account_id": account_id.group(1),"username": username.group(1),"user": email,"password": password,"Dev": "Odai @K33Kz - @K33Ka"})
            elif ('كلمة السر التي أدخلتها غير صحيحة.' in response or 
                  'هل نسيت كلمة السر؟' in response):return json.dumps({"status": "bad password","user": email,"password": password,"Dev": "Odai @K33Kz - @K33Ka"})
            elif 'البريد الإلكتروني أو رقم الهاتف المحمول الذي أدخلته غير مرتبط بحساب.' in response:return json.dumps({"status": "user not found","user": email,"password": password,"msg": "check your account info","Dev": "Odai @K33Kz - @K33Ka"})
            else:
                return json.dumps({"status": "unknown response","user": email,"password": password,"msg": "check your account info","Dev": "Odai @K33Kz - @K33Ka"})
        except Exception as e:result = {"status": " error","error": e,"Dev": "Odai @K33Kz - @K33Ka"}
class auth:
    @staticmethod
    def login(email, password,proxies=None):
        data = {"locale": "en_GB","format": "json","user": email,"password": password,"access_token": "200424423651082|2a9918c6bcd75b94cefcbb5635c6ad16","generate_session_cookies": 1}
        headers = {'user-agent': 'Mozilla/5.0','Host': 'graph.facebook.com','Content-Type': 'application/json;charset=utf-8'}
        try:
            response = requests.post("https://b-graph.facebook.com/auth/login",data=data,headers=headers,proxies=proxies)
            result = response.json()
            text = response.text
            if 'access_token' in result or 'session_key' in result:
                uid = result.get('uid', '')
                cookies = ';'.join(i['name'] + '=' + i['value'] for i in result.get('session_cookies', []))
                return {"status": "success","uid": uid,"cookies": cookies,"user": email,"password": password,"Dev": "Odai @K33Kz - @K33Ka"}
            elif ('www.facebook.com' in result.get('error', {}).get('message', '') or 'Please complete the security check to log in.' in text or 'two_step_verification' in text):return {"status": "checkpoint","user": email,"password": password,"Dev": "Odai @K33Kz - @K33Ka"}
            else:return {"status": "unknown response","user": email,"password": password,"msg": "check your account info","Dev": "Odai @K33Kz - @K33Ka"}
        except Exception as e:result = {"status": " error","error": e,"Dev": "Odai @K33Kz - @K33Ka"}
def extract_cookies(text):
    for _ in range(5):text = text.replace('\\"', '"').replace('\\\\', '\\')
    start_match = re.search(r'"session_cookies"\s*:\s*\[', text)
    if not start_match:return None
    start_idx = start_match.end() - 1
    i = start_idx
    bracket_count = 0
    in_string = False
    escape = False
    while i < len(text):
        ch = text[i]
        if escape:escape = False
        elif ch == '\\':escape = True
        elif ch == '"':in_string = not in_string
        elif not in_string:
            if ch == '[':bracket_count += 1
            elif ch == ']':
                bracket_count -= 1
                if bracket_count == 0:
                    end_idx = i
                    break
        i += 1
    else:return None
    array_content = text[start_idx+1:end_idx]
    cookie_pairs = re.findall(r'"name"\s*:\s*"([^"]+)"\s*,\s*"value"\s*:\s*"([^"]+)"',array_content)
    if not cookie_pairs:return None
    cookie_dict = {name: value for name, value in cookie_pairs}
    order = ["c_user", "xs", "fr", "datr"]
    parts = []
    for name in order:
        if name in cookie_dict:parts.append(f"{name}={cookie_dict[name]}")
    return "; ".join(parts)
class mobile:
    @staticmethod
    def login(email, password, proxies=None):
        payload = {'method': "post", 'pretty': "false", 'format': "json", 'server_timestamps': "true", 'locale': "en_EN", 'purpose': "fetch", 'fb_api_req_friendly_name': "FbBloksActionRootQuery-com.bloks.www.bloks.caa.login.async.send_login_request", 'fb_api_caller_class': "graphservice", 'client_doc_id': "11994080425074657009809260413", 'fb_api_client_context': json.dumps({"is_background": False}), 'variables': json.dumps({"params": {"params": json.dumps({"params": json.dumps({"client_input_params": {"sim_phones": [], "aymh_accounts": [{"profiles": {"id": {"is_derived": 0, "credentials": [], "account_center_id": "", "profile_picture_url": "", "small_profile_picture_url": None, "notification_count": 0, "token": "", "last_access_time": 0, "has_smartlock": 0, "credential_type": "none", "password": "", "from_accurate_privacy_result": 0, "dbln_validated": 0, "user_id": "", "name": "", "nta_eligibility_reason": None, "username": "", "account_source": ""}}, "id": ""}], "secure_family_device_id": str(uuid4()), "attestation_result": {}, "has_granted_read_contacts_permissions": 0, "auth_secure_device_id": "null", "has_whatsapp_installed": 1, "password": f"#PWD_FB4A:0:{str(int(time.time()))}:{password}", "sso_token_map_json_string": "", "block_store_machine_id": None, "cloud_trust_token": None, "event_flow": "login_manual", "password_contains_non_ascii": "false", "sim_serials": [], "client_known_key_hash": "", "encrypted_msisdn": "", "has_granted_read_phone_permissions": 0, "app_manager_id": str(uuid4()), "should_show_nested_nta_from_aymh": 1, "device_id": str(uuid4()), "zero_balance_state": "data", "login_attempt_count": 1, "flash_call_permission_status": {"READ_PHONE_STATE": "DENIED", "READ_CALL_LOG": "DENIED", "ANSWER_PHONE_CALLS": "DENIED"}, "accounts_list": [], "family_device_id": str(uuid4()), "fb_ig_device_id": [], "device_emails": [], "try_num": 3, "lois_settings": {"lois_token": ""}, "event_step": "home_page", "headers_infra_flow_id": str(uuid4()), "openid_tokens": {}, "contact_point": email}, "server_params": {"should_trigger_override_login_2fa_action": 0, "is_vanilla_password_page_empty_password": 0, "is_from_logged_out": 0, "should_trigger_override_login_success_action": 0, "login_credential_type": "none", "server_login_source": "login", "waterfall_id": str(uuid4()), "two_step_login_type": "one_step_login", "login_source": "Login", "is_platform_login": 0, "pw_encryption_try_count": 1, "INTERNAL__latency_qpl_marker_id": 36707139, "is_from_aymh": 0, "offline_experiment_group": None, "is_from_landing_page": 0, "password_text_input_id": None, "is_from_empty_password": 0, "is_from_msplit_fallback": 0, "ar_event_source": "login_home_page", "username_text_input_id": None, "layered_homepage_experiment_group": None, "device_id": str(uuid4()), "INTERNAL__latency_qpl_instance_id": 1.06996309100672e14, "reg_flow_source": "login_home_native_integration_point", "is_caa_perf_enabled": 1, "credential_type": "password", "is_from_password_entry_page": 0, "caller": "gslr", "family_device_id": str(uuid4()), "is_from_assistive_id": 0, "access_flow_version": "pre_mt_behavior", "is_from_logged_in_switcher": 0}})}), "bloks_versioning_id": "c42a4bd8f99cb2bd57ea74ca2b690710be5a50faa60a68bb9bcc524fe6c63e7a", "app_id": "com.bloks.www.bloks.caa.login.async.send_login_request"}, "scale": "3", "nt_context": {"using_white_navbar": True, "styles_id": "3b115a54b620c39392b96bdca4c5237f", "pixel_ratio": 3, "is_push_on": True, "debug_tooling_metadata_token": None, "is_flipper_enabled": False, "theme_params": [{"value": [], "design_system_name": "FDS"}], "bloks_version": "c42a4bd8f99cb2bd57ea74ca2b690710be5a50faa60a68bb9bcc524fe6c63e7a"}}), 'fb_api_analytics_tags': json.dumps(["GraphServices"]), 'client_trace_id': "a5bba4f8-b87f-4b73-8d9a-44226255a84c"}
        headers = {'User-Agent': "[FBAN/FB4A;FBAV/536.0.0.46.77;FBBV/810163229;FBDM/{density=2.75,width=1080,height=2220};FBLC/en_EN;FBRV/0;FBCR/Yemen Mobile;FBMF/Xiaomi;FBBD/Redmi;FBPN/com.facebook.katana;FBDV/Redmi Note 10 Pro;FBSV/11;FBOP/1;FBCA/arm64-v8a:;]",'x-fb-friendly-name': "FbBloksActionRootQuery-com.bloks.www.bloks.caa.login.async.send_login_request",'authorization': "OAuth 350685531728|62f8ce9f74b12f84c123cc23437a4a32"}
        try:
            response = requests.post("https://graph-fallback.facebook.com/graphql",data=payload,headers=headers,proxies=proxies)
            response_text = response.text
            if re.search(r'"access_token":"(.*?)"', response_text.replace("/", "").replace("\\", "")):
                token_match = re.search(r'"access_token":"(.*?)"', response_text.replace("/", "").replace("\\", ""))
                cookies = extract_cookies(response.text)
                return {"status": "success","access_token": token_match.group(1),"cookies": cookies,"user": email,"password": password,"Dev": "Odai @K33Kz - @K33Ka"}
            elif "Invalid username or password" in response_text or 'override_login_2fa_action' in response_text:return {"status": "bad credentials","user": email,"password": password,"msg": "check your account info","Dev": "Odai @K33Kz - @K33Ka"}
            else:return {"status": "unknown response","user": email,"password": password,"msg": "check your account info","Dev": "Odai @K33Kz - @K33Ka"}
        except Exception as e:result = {"status": " error","error": e,"Dev": "Odai @K33Kz - @K33Ka"}
class apps:
    @staticmethod
    def get_linked_apps(cookies_input):
        session = requests.Session()
        if isinstance(cookies_input, dict):coki = cookies_input
        elif isinstance(cookies_input, str):
            coki = {}
            cleaned = ';'.join([p.strip() for p in cookies_input.split(';') if p.strip()])
            for part in cleaned.split(';'):
                if '=' not in part:
                    continue
                key, val = part.split('=', 1)
                coki[key.strip()] = val.strip()
        else:return {"status": "false","msg": "error in cookies format", "Dev": "Odai @K33Kz - @K33Ka"}
        ua = 'NokiaX2-01/5.0 (08.35) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 (Linux; Android 9; SH-03J) AppleWebKit/537.36 (KHTML, like Gecko) Safari/420+'
        headers = {'user-agent': ua}
        try:rr1 = session.get('https://m.facebook.com/settings/apps/tabbed/?tab=active', cookies=coki, headers=headers, timeout=12).text
        except:rr1 = ""
        try:rr2 = session.get('https://m.facebook.com/settings/apps/tabbed/?tab=inactive', cookies=coki, headers=headers, timeout=12).text
        except:rr2 = ""
        output = []
        if 'tidak memiliki aplikasi' in rr1.lower() or 'no active apps' in rr1.lower():output.append("No active apps")
        else:
            apps_active = re.findall(r'data-testid="app_info_text">([^<]+)</span>', rr1)
            dates_active = re.findall(r'(?:تمت الإضافة في|Added on|Ditambahkan pada|Ajouté le|Dodano dnia)\s*([^<]+)</p>', rr1)
            if not apps_active:output.append("No active apps found")
            else:
                for i, app in enumerate(apps_active):
                    app_clean = app.strip()
                    try:date_clean = dates_active[i].strip()
                    except IndexError:date_clean = "غير معروف"
                    output.append(f"[{i+1}] {app_clean} - {date_clean}")
        lower_rr2 = rr2.lower()
        if 'kedaluwarsa' in lower_rr2 and 'tidak memiliki' in lower_rr2:output.append("No inactive/expired apps")
        else:
            apps_inactive = re.findall(r'data-testid="app_info_text">([^<]+)</span>', rr2)
            dates_raw = re.findall(r'<p[^>]*>(?:Kedaluwarsa pada|انتهت الصلاحية في|منتهية الصلاحية في|Expired on)[^<]*</p>', rr2)
            dates_inactive = [re.sub(r'<[^>]+>', '', d).strip() for d in dates_raw]
            if not apps_inactive:output.append("No inactive/expired apps found")
            else:
                for i, app in enumerate(apps_inactive):
                    app_clean = app.strip()
                    try:date_clean = dates_inactive[i].strip()
                    except IndexError:date_clean = "غير معروف"
                    output.append(f"[{i+1}] {app_clean} - {date_clean}")
        if not output:output.append("لا توجد بيانات متاحة")
        return output
class account_info:
    @staticmethod
    def get_info(cookies_input):
        if isinstance(cookies_input, str):
            cookies_dict = {}
            for item in cookies_input.split(";"):
                if "=" in item:
                    key, value = item.split("=", 1)
                    cookies_dict[key.strip()] = value.strip()
        elif isinstance(cookies_input, dict):cookies_dict = cookies_input.copy()
        else:
            print("Invalid cookies format")
            return
        datr = cookies_dict.get("datr")
        sb = cookies_dict.get("sb")
        ps_l = cookies_dict.get("ps_l")
        ps_n = cookies_dict.get("ps_n")
        wd = cookies_dict.get("wd")
        c_user = cookies_dict.get("c_user")
        xs = cookies_dict.get("xs")
        session = requests.Session()
        session.cookies.update(cookies_dict)
        headers = {"user-agent": "Mozilla/5.0"}
        url = "https://accountscenter.facebook.com/"
        res = session.get(url, headers=headers).text
        fb_dtsg_match = re.search(r'"DTSGInitialData",\[\],{"token":"(.*?)"}', res)
        lsd_match = re.search(r'"LSD",\[\],{"token":"(.*?)"}', res)
        fb_dtsg = fb_dtsg_match.group(1) if fb_dtsg_match else None
        lsd = lsd_match.group(1) if lsd_match else None
        cookies = {'datr': datr, 'ps_l': '1', 'ps_n': '1', 'sb': sb, 'dpr': '1.25', 'wd': '656x838', 'c_user': c_user, 'fr': '1iq1a4QIVodVmxG7I.AWeuwjn9SyIbptY2XAYrBLfXgmkYwZPSmF6Hr2yGo9V2aRU-ysY.Bptqbr..AAA.0.0.Bptqbr.AWekh9RBJfyu_fQVOsBrC3euJAk', 'xs': xs, 'presence': 'C%7B%22t3%22%3A%5B%5D%2C%22utc3%22%3A1773578123492%2C%22v%22%3A1%7D'}
        headers = {'accept': '*/*', 'accept-language': 'en-US,en;q=0.9,ar;q=0.8', 'content-type': 'application/x-www-form-urlencoded', 'origin': 'https://accountscenter.facebook.com', 'priority': 'u=1, i', 'referer': 'https://accountscenter.facebook.com/profiles', 'sec-ch-prefers-color-scheme': 'dark', 'sec-ch-ua': '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"', 'sec-ch-ua-full-version-list': '"Not:A-Brand";v="99.0.0.0", "Google Chrome";v="145.0.7632.160", "Chromium";v="145.0.7632.160"', 'sec-ch-ua-mobile': '?0', 'sec-ch-ua-model': '""', 'sec-ch-ua-platform': '"Windows"', 'sec-ch-ua-platform-version': '"19.0.0"', 'sec-fetch-dest': 'empty', 'sec-fetch-mode': 'cors', 'sec-fetch-site': 'same-origin', 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 'x-asbd-id': '359341', 'x-fb-friendly-name': 'FXAccountsCenterPersonalCentralIdentityDialogV2Query', 'x-fb-lsd': lsd}
        data = {'av': c_user, '__user': c_user, '__a': '1', '__req': 'l', '__hs': '20527.HYP:accounts_center_pkg.2.1...0', 'dpr': '1', '__ccg': 'GOOD', '__rev': '1035205964', '__s': 'txvfss:84i8p9:hr7nlk', '__hsi': '7617460095362994183', '__sjsp': 'gpRi1F1v96gbIfMugGMEY4s0KUgx4aBIEUk0oSbyU1n8', '__comet_req': '5', 'fb_dtsg': fb_dtsg, 'jazoest': '25453', 'lsd': lsd, '__spin_r': '1035205964', '__spin_b': 'trunk', '__spin_t': '1773578137', 'fb_api_caller_class': 'RelayModern', 'fb_api_req_friendly_name': 'FXAccountsCenterPersonalCentralIdentityDialogV2Query', 'server_timestamps': 'true', 'variables': '{"identity_id":"'+c_user+'","interface":"FB_WEB","platform":"FACEBOOK","scale":1}', 'doc_id': '26102210629377215'}
        response = requests.post('https://accountscenter.facebook.com/api/graphql/',cookies=cookies,headers=headers,data=data).text
        if 'Log in to continue' in response:return {"status": "invaild", "msg": "You Need To Login, Check Your Cookies" , "Dev": "Odai @K33Kz - @K33Ka"}
        response = response.replace("for (;;);", "")
        js = json.loads(response)
        result = {"facebook_name": js["data"]["fxim_identity_for_id"]["full_name"],"instagram_accounts": []}
        identities = js["data"]["fx_identity_management"]["identities_and_central_identities"]["linked_identities_to_pci"]
        for acc in identities:
            if acc["detailed_identity_type"] == "IG_PERSONAL":
                ig_id = acc["canonical_id"]
                data["'variables"] = json.dumps({"identity_id": ig_id,"interface": "FB_WEB","platform": "INSTAGRAM","scale": 1})
                try:
                    ig_response = requests.post('https://accountscenter.facebook.com/api/graphql/',cookies=cookies,headers=headers,data=data).text
                    ig_response = ig_response.replace("for (;;);", "")
                    ig_json = json.loads(ig_response)
                    ig_data = ig_json["data"]["fxim_identity_for_id"]
                    if ig_id and ig_data:result["instagram_accounts"].append({"id": ig_id,"username": ig_data["username"],"full_name": ig_data["full_name"],"profile_picture": ig_data["profile_picture_info"]["profile_picture_url"],"Dev": "Odai @K33Kz - @K33Ka"})
                    else:result = {"status": "false","msg": "No data","Dev": "Odai @K33Kz - @K33Ka"}
                except Exception as e:result = {"status": " error","error": e,"Dev": "Odai @K33Kz - @K33Ka"}
            return result
class account_info_contact:
    @staticmethod
    def get_contact(cookies_input):
        if isinstance(cookies_input, str):
            cookies_dict = {}
            for item in cookies_input.split(";"):
                if "=" in item:
                    key, value = item.split("=", 1)
                    cookies_dict[key.strip()] = value.strip()
        elif isinstance(cookies_input, dict):cookies_dict = cookies_input.copy()
        else:
            print("Invalid cookies format")
            return
        datr = cookies_dict.get("datr")
        sb = cookies_dict.get("sb")
        wd = cookies_dict.get("wd")
        c_user = cookies_dict.get("c_user")
        xs = cookies_dict.get("xs")
        session = requests.Session()
        session.cookies.update(cookies_dict)
        headers = {"user-agent": "Mozilla/5.0"}
        url = "https://accountscenter.facebook.com/"
        res = session.get(url, headers=headers).text
        fb_dtsg_match = re.search(r'"DTSGInitialData",\[\],{"token":"(.*?)"}', res)
        lsd_match = re.search(r'"LSD",\[\],{"token":"(.*?)"}', res)
        fb_dtsg = fb_dtsg_match.group(1) if fb_dtsg_match else None
        lsd = lsd_match.group(1) if lsd_match else None

        cookies = {'datr': datr, 'ps_l': '1', 'ps_n': '1', 'sb': sb, 'dpr': '1.25', 'wd': wd, 'c_user': c_user, 'fr': '1iq1a4QIVodVmxG7I.AWeuwjn9SyIbptY2XAYrBLfXgmkYwZPSmF6Hr2yGo9V2aRU-ysY.Bptqbr..AAA.0.0.Bptqbr.AWekh9RBJfyu_fQVOsBrC3euJAk', 'xs': xs, 'presence': 'C%7B%22t3%22%3A%5B%5D%2C%22utc3%22%3A1773578123492%2C%22v%22%3A1%7D'}
        headers = {'accept': '*/*', 'accept-language': 'en-US,en;q=0.9,ar;q=0.8', 'content-type': 'application/x-www-form-urlencoded', 'origin': 'https://accountscenter.facebook.com', 'priority': 'u=1, i', 'referer': 'https://accountscenter.facebook.com/profiles', 'sec-ch-prefers-color-scheme': 'dark', 'sec-ch-ua': '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"', 'sec-ch-ua-full-version-list': '"Not:A-Brand";v="99.0.0.0", "Google Chrome";v="145.0.7632.160", "Chromium";v="145.0.7632.160"', 'sec-ch-ua-mobile': '?0', 'sec-ch-ua-model': '""', 'sec-ch-ua-platform': '"Windows"', 'sec-ch-ua-platform-version': '"19.0.0"', 'sec-fetch-dest': 'empty', 'sec-fetch-mode': 'cors', 'sec-fetch-site': 'same-origin', 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 'x-asbd-id': '359341', 'x-fb-friendly-name': 'FXAccountsCenterPersonalCentralIdentityDialogV2Query', 'x-fb-lsd': lsd}
        data = {'av': c_user, '__user': c_user, '__a': '1', '__req': 'l', '__hs': '20527.HYP:accounts_center_pkg.2.1...0', 'dpr': '1', '__ccg': 'GOOD', '__rev': '1035205964', '__s': 'txvfss:84i8p9:hr7nlk', '__hsi': '7617460095362994183', '__sjsp': 'gpRi1F1v96gbIfMugGMEY4s0KUgx4aBIEUk0oSbyU1n8', '__comet_req': '5', 'fb_dtsg': fb_dtsg, 'jazoest': '25453', 'lsd': lsd, '__spin_r': '1035205964', '__spin_b': 'trunk', '__spin_t': '1773578137', 'fb_api_caller_class': 'RelayModern', 'fb_api_req_friendly_name': 'FXAccountsCenterPersonalCentralIdentityDialogV2Query', 'server_timestamps': 'true', 'variables': '{"identity_id":"'+c_user+'","interface":"FB_WEB","platform":"FACEBOOK","scale":1}', 'doc_id': '24467941749567966'}
        response = requests.post('https://accountscenter.facebook.com/api/graphql/',cookies=cookies,headers=headers,data=data).text
        if 'Log in to continue' in response:return {"status": "invaild", "msg": "You Need To Login, Check Your Cookies" , "Dev": "Odai @K33Kz - @K33Ka"}
        js = json.loads(response.replace("for (;;);",""))
        node = js["data"]["fxcal_settings"]["node"]
        contacts = node["all_contact_points"]
        if contacts: 
            result = {"emails": [],"phones": [], "Dev": "Odai @K33Kz - @K33Ka"}
            for c in contacts:
                if c["contact_point_type"] == "EMAIL":result["emails"].append(c["normalized_contact_point"])
                if c["contact_point_type"] == "PHONE_NUMBER":result["phones"].append(c["normalized_contact_point"])
        else:result = {"status": "false","msg": "No data","Dev": "Odai @K33Kz - @K33Ka"}
        return result
class account_info_birthday:
    @staticmethod
    def get_birthday(cookies_input):
        if isinstance(cookies_input, str):
            cookies_dict = {}
            for item in cookies_input.split(";"):
                if "=" in item:
                    key, value = item.split("=", 1)
                    cookies_dict[key.strip()] = value.strip()
        elif isinstance(cookies_input, dict):cookies_dict = cookies_input.copy()
        else:
            print("Invalid cookies format")
            return
        datr = cookies_dict.get("datr")
        sb = cookies_dict.get("sb")
        wd = cookies_dict.get("wd")
        c_user = cookies_dict.get("c_user")
        xs = cookies_dict.get("xs")
        session = requests.Session()
        session.cookies.update(cookies_dict)
        headers = {"user-agent": "Mozilla/5.0"}
        url = "https://accountscenter.facebook.com/"
        res = session.get(url, headers=headers).text
        fb_dtsg_match = re.search(r'"DTSGInitialData",\[\],{"token":"(.*?)"}', res)
        lsd_match = re.search(r'"LSD",\[\],{"token":"(.*?)"}', res)
        fb_dtsg = fb_dtsg_match.group(1) if fb_dtsg_match else None
        lsd = lsd_match.group(1) if lsd_match else None
        cookies = {'datr': datr, 'ps_l': '1', 'ps_n': '1', 'sb': sb, 'dpr': '1.25', 'wd': wd, 'c_user': c_user, 'fr': '1iq1a4QIVodVmxG7I.AWeuwjn9SyIbptY2XAYrBLfXgmkYwZPSmF6Hr2yGo9V2aRU-ysY.Bptqbr..AAA.0.0.Bptqbr.AWekh9RBJfyu_fQVOsBrC3euJAk', 'xs': xs, 'presence': 'C%7B%22t3%22%3A%5B%5D%2C%22utc3%22%3A1773578123492%2C%22v%22%3A1%7D'}
        headers = {'accept': '*/*', 'accept-language': 'en-US,en;q=0.9,ar;q=0.8', 'content-type': 'application/x-www-form-urlencoded', 'origin': 'https://accountscenter.facebook.com', 'priority': 'u=1, i', 'referer': 'https://accountscenter.facebook.com/profiles', 'sec-ch-prefers-color-scheme': 'dark', 'sec-ch-ua': '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"', 'sec-ch-ua-full-version-list': '"Not:A-Brand";v="99.0.0.0", "Google Chrome";v="145.0.7632.160", "Chromium";v="145.0.7632.160"', 'sec-ch-ua-mobile': '?0', 'sec-ch-ua-model': '""', 'sec-ch-ua-platform': '"Windows"', 'sec-ch-ua-platform-version': '"19.0.0"', 'sec-fetch-dest': 'empty', 'sec-fetch-mode': 'cors', 'sec-fetch-site': 'same-origin', 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 'x-asbd-id': '359341', 'x-fb-friendly-name': 'FXAccountsCenterBirthdayRootQuery', 'x-fb-lsd': lsd}
        data = {'av': c_user, '__user': c_user, '__a': '1', '__req': 'l', '__hs': '20527.HYP:accounts_center_pkg.2.1...0', 'dpr': '1', '__ccg': 'GOOD', '__rev': '1035205964', '__s': 'txvfss:84i8p9:hr7nlk', '__hsi': '7617460095362994183', '__sjsp': 'gpRi1F1v96gbIfMugGMEY4s0KUgx4aBIEUk0oSbyU1n8', '__comet_req': '5', 'fb_dtsg': fb_dtsg, 'jazoest': '25453', 'lsd': lsd, '__spin_r': '1035205964', '__spin_b': 'trunk', '__spin_t': '1773578137', 'fb_api_caller_class': 'RelayModern', 'fb_api_req_friendly_name': 'FXAccountsCenterBirthdayRootQuery', 'server_timestamps': 'true', 'variables': '{"interface":"FB_WEB","node":"BIRTHDAY"}', 'doc_id': '26426848043589913'}
        response = requests.post('https://accountscenter.facebook.com/api/graphql/',cookies=cookies,headers=headers,data=data).text
        if 'Log in to continue' in response:return {"status": "invaild", "msg": "You Need To Login, Check Your Cookies" , "Dev": "Odai @K33Kz - @K33Ka"}
        response = response.replace("for (;;);","")
        js = json.loads(response)
        birthday = js["data"]["fxcal_settings"]["node"]["birthday"]
        if birthday:return {"status": "true","birthday": birthday,"Dev": "Odai @K33Kz - @K33Ka"}
        else:return {"status": "invaild", "msg": "Can't Extract The Birthday, Check Your Cookies or Account" , "Dev": "Odai @K33Kz - @K33Ka"}