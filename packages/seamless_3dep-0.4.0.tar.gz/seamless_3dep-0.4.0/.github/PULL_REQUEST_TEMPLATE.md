<!-- Feel free to remove check-list items aren't relevant to your changes -->

- [ ] Closes #xxxx
- [ ] Passes `pixi r lint` and `pixi r typecheck`.
- [ ] Tests added and `pixi r test` passes.
- [ ] Changes and the contributor name are documented in `CHANGELOG.md`.
