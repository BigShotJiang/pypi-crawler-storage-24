from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import tomllib

from python_checkup.models import Category

DEFAULT_WEIGHTS: dict[str, int] = {
    "quality": 20,
    "types": 20,
    "security": 20,
    "complexity": 10,
    "dead_code": 10,
    "dependencies": 10,
    "performance": 10,
}

DEFAULT_THRESHOLDS: dict[str, int] = {
    "healthy": 75,
    "needs_work": 50,
}

# Map config weight keys to Category enum
WEIGHT_KEY_TO_CATEGORY: dict[str, Category] = {
    "quality": Category.QUALITY,
    "types": Category.TYPE_SAFETY,
    "security": Category.SECURITY,
    "complexity": Category.COMPLEXITY,
    "dead_code": Category.DEAD_CODE,
    "dependencies": Category.DEPENDENCIES,
    "performance": Category.PERFORMANCE,
}


@dataclass
class CheckupConfig:
    """Resolved configuration for a python-checkup run."""

    weights: dict[str, int] = field(default_factory=lambda: dict(DEFAULT_WEIGHTS))
    thresholds: dict[str, int] = field(default_factory=lambda: dict(DEFAULT_THRESHOLDS))
    ignore_rules: list[str] = field(default_factory=list)
    ignore_files: list[str] = field(default_factory=list)
    ignore_dirs: list[str] = field(default_factory=list)  # directory names to skip
    ignore_patterns: list[str] = field(
        default_factory=list
    )  # mixed glob + regex: prefix
    focus: list[str] = field(default_factory=list)  # restrict analysis to these paths
    timeout: int = 60  # seconds, per analyzer
    min_confidence: int = 80  # Vulture confidence threshold
    # Framework detection overrides (Phase 6)
    frameworks: list[str] | None = None  # None = auto-detect; list = force
    frameworks_disabled: bool = False  # True = skip framework detection entirely
    disabled_framework_rules: list[str] = field(
        default_factory=list
    )  # e.g. ["FW-DJ-004"]
    requirements_file: str | None = None  # override for dependency file path


def load_config(project_root: Path) -> CheckupConfig:
    """Load configuration from python-checkup.yaml or pyproject.toml, with defaults.

    Discovery order:
    1. python-checkup.yaml / .python-checkup.yaml in project_root (no walk-up).
    2. [tool.python-checkup] in pyproject.toml, walking up parent directories.
    """
    yaml_data = _load_yaml_config(project_root)
    if yaml_data is not None:
        return _parse_config_dict(yaml_data)

    config_path = _find_pyproject(project_root)
    if config_path is None:
        return CheckupConfig()

    try:
        with open(config_path, "rb") as f:
            data = tomllib.load(f)
    except (OSError, tomllib.TOMLDecodeError):
        return CheckupConfig()

    user_config = data.get("tool", {}).get("python-checkup", {})
    if not user_config:
        return CheckupConfig()

    return _parse_config_dict(user_config)


def _parse_config_dict(d: dict[str, object]) -> CheckupConfig:
    """Build a CheckupConfig from a raw config dict (TOML or YAML)."""
    ignore_section = d.get("ignore", {})
    if not isinstance(ignore_section, dict):
        ignore_section = {}

    fw_config = d.get("framework-checks", {})
    disabled_fw_rules: list[str] = (
        fw_config.get("disable", []) if isinstance(fw_config, dict) else []
    )

    raw_frameworks = d.get("frameworks")
    frameworks: list[str] | None = None
    frameworks_disabled = False
    if raw_frameworks is False:
        frameworks_disabled = True
    elif isinstance(raw_frameworks, list):
        frameworks = [str(f) for f in raw_frameworks]

    raw_focus = d.get("focus")
    if isinstance(raw_focus, list):
        focus: list[str] = [str(f) for f in raw_focus if f]
    elif raw_focus:
        focus = [str(raw_focus)]
    else:
        focus = []

    weights = d.get("weights", dict(DEFAULT_WEIGHTS))
    thresholds = d.get("thresholds", dict(DEFAULT_THRESHOLDS))
    timeout = d.get("timeout", 60)
    min_confidence = d.get("min_confidence", 80)
    return CheckupConfig(
        weights=weights if isinstance(weights, dict) else dict(DEFAULT_WEIGHTS),
        thresholds=(
            thresholds if isinstance(thresholds, dict) else dict(DEFAULT_THRESHOLDS)
        ),
        ignore_rules=ignore_section.get("rules", []),
        ignore_files=ignore_section.get("files", []),
        ignore_dirs=ignore_section.get("dirs", []),
        ignore_patterns=ignore_section.get("patterns", []),
        focus=focus,
        timeout=int(timeout) if isinstance(timeout, (int, float)) else 60,
        min_confidence=(
            int(min_confidence) if isinstance(min_confidence, (int, float)) else 80
        ),
        frameworks=frameworks,
        frameworks_disabled=frameworks_disabled,
        disabled_framework_rules=disabled_fw_rules,
        requirements_file=(
            str(d["requirements_file"]) if d.get("requirements_file") else None
        ),
    )


def _load_yaml_config(project_root: Path) -> dict[str, object] | None:
    """Load python-checkup.yaml from project_root (no walk-up).

    Returns None if the file doesn't exist or PyYAML is not installed.
    """
    import importlib.util

    if importlib.util.find_spec("yaml") is None:
        return None

    for name in ("python-checkup.yaml", ".python-checkup.yaml"):
        candidate = project_root / name
        if candidate.is_file():
            import yaml  # type: ignore[import-untyped]

            try:
                with open(candidate) as f:
                    data = yaml.safe_load(f)
                return data if isinstance(data, dict) else {}
            except Exception:
                return None

    return None


def _find_pyproject(start: Path) -> Path | None:
    """Walk up from start directory to find pyproject.toml."""
    current = start.resolve()
    while True:
        candidate = current / "pyproject.toml"
        if candidate.is_file():
            return candidate
        parent = current.parent
        if parent == current:
            return None
        current = parent
