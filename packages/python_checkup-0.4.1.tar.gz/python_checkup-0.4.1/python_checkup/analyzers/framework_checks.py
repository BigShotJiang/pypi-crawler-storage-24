"""Framework-specific security and best-practice checks.

This analyzer runs only when a framework is detected.  It performs
configuration-file analysis and code-pattern scanning using pure AST
inspection — no framework imports required, always available.

Rule ID convention: FW-<FW>-NNN
  FW-DJ-*   Django
  FW-FA-*   FastAPI
  FW-FL-*   Flask
  FW-CL-*   Celery
  FW-SA-*   SQLAlchemy
"""

from __future__ import annotations

import ast
import logging
from pathlib import Path
from typing import TYPE_CHECKING

from python_checkup.analyzers.ast_helpers import (
    extract_assignments,
    get_keyword_value,
    get_list_string_values,
    get_string_value,
    has_keyword_true,
    is_call_to,
    is_string_constant,
    is_truthy_constant,
    parse_file,
)
from python_checkup.analyzers.django_checks import check_django as _check_django
from python_checkup.models import Category, Diagnostic, Severity

if TYPE_CHECKING:
    from python_checkup.analysis_request import AnalysisRequest
    from python_checkup.detection import FrameworkInfo

logger = logging.getLogger("python_checkup")


class FrameworkCheckAnalyzer:
    """Framework-specific configuration and code pattern checks."""

    @property
    def name(self) -> str:
        return "framework-checks"

    @property
    def category(self) -> Category:
        return Category.SECURITY

    async def is_available(self) -> bool:
        return True  # Pure Python, always available

    async def analyze(self, request: AnalysisRequest) -> list[Diagnostic]:
        if not request.framework_stack or not request.framework_stack.all_frameworks:
            return []

        diagnostics: list[Diagnostic] = []
        for fw in request.framework_stack.all_frameworks:
            checker = _FRAMEWORK_CHECKERS.get(fw.name)
            if checker:
                diagnostics.extend(checker(request.project_root, request.files, fw))

        return diagnostics


# ---------------------------------------------------------------------------
# Django checks (delegated to django_checks.py)
# ---------------------------------------------------------------------------


def _check_fastapi(
    root: Path,
    files: list[Path],
    fw: FrameworkInfo,
) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    for f in files:
        diags.extend(_check_fastapi_file(f))
    return diags


def _fastapi_cors_diags(f: Path, tree: ast.AST) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    saw_fastapi_app = False
    saw_cors = False
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and is_call_to(node, "FastAPI"):
            saw_fastapi_app = True
        if isinstance(node, ast.Call) and is_call_to(
            node, "CORSMiddleware", "add_middleware"
        ):
            saw_cors = True
            origins = get_keyword_value(node, "allow_origins")
            if origins and "*" in get_list_string_values(origins):
                diags.append(
                    Diagnostic(
                        file_path=f,
                        line=node.lineno,
                        column=node.col_offset,
                        severity=Severity.WARNING,
                        rule_id="FW-FA-002",
                        tool="framework-checks",
                        category=Category.SECURITY,
                        message=(
                            "CORS allow_origins=['*'] permits requests from "
                            "any origin. Restrict to known domains."
                        ),
                        fix=(
                            "Set allow_origins=['https://yourdomain.com'] or use "
                            "CORS_ALLOWED_ORIGINS environment variable"
                        ),
                    )
                )
    if saw_fastapi_app and not saw_cors:
        diags.append(
            Diagnostic(
                file_path=f,
                line=0,
                column=0,
                severity=Severity.WARNING,
                rule_id="FW-FA-001",
                tool="framework-checks",
                category=Category.SECURITY,
                message="FastAPI app has no CORS middleware configured.",
                fix=(
                    "Add CORSMiddleware with explicit allow_origins"
                    " for browser clients"
                ),
            )
        )
    return diags


def _fastapi_sync_endpoint_diags(f: Path, tree: ast.AST) -> list[Diagnostic]:
    diags: list[Diagnostic] = [
        Diagnostic(
            file_path=f,
            line=node.lineno,
            column=node.col_offset,
            severity=Severity.WARNING,
            rule_id="FW-FA-003",
            tool="framework-checks",
            category=Category.QUALITY,
            message=(
                f"Route handler '{node.name}' is a sync def inside a FastAPI app."
                " FastAPI runs sync endpoints in a thread pool, adding overhead."
            ),
            fix="Convert to async def if the handler does only async-safe work",
        )
        for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and _is_fastapi_route_handler(node)
    ]
    return diags


def _fastapi_route_diags(
    f: Path,
    node: ast.FunctionDef | ast.AsyncFunctionDef,
    route_decorators: list[ast.Call],
) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    if not any(get_keyword_value(dec, "response_model") for dec in route_decorators):
        diags.append(
            Diagnostic(
                file_path=f,
                line=node.lineno,
                column=node.col_offset,
                severity=Severity.INFO,
                rule_id="FW-FA-003",
                tool="framework-checks",
                category=Category.QUALITY,
                message=f"Endpoint '{node.name}' has no response_model.",
                fix="Add response_model=MyModel to the route decorator",
            )
        )
    if any(_is_mutating_fastapi_route(dec) for dec in route_decorators) and not any(
        get_keyword_value(dec, "status_code") for dec in route_decorators
    ):
        diags.append(
            Diagnostic(
                file_path=f,
                line=node.lineno,
                column=node.col_offset,
                severity=Severity.INFO,
                rule_id="FW-FA-005",
                tool="framework-checks",
                category=Category.QUALITY,
                message=f"Mutating endpoint '{node.name}' has no explicit status_code.",
                fix="Add status_code=201/202/204 to the route decorator as appropriate",
            )
        )
    if len(node.args.args) > 5:
        diags.append(
            Diagnostic(
                file_path=f,
                line=node.lineno,
                column=node.col_offset,
                severity=Severity.INFO,
                rule_id="FW-FA-052",
                tool="framework-checks",
                category=Category.QUALITY,
                message=(
                    f"Endpoint '{node.name}' has many parameters."
                    " Consider a Pydantic model."
                ),
                fix="Group related parameters into a request model or dependency",
            )
        )
    return diags


def _fastapi_lifecycle_diags(f: Path, tree: ast.AST) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        diags.extend(
            Diagnostic(
                file_path=f,
                line=node.lineno,
                column=node.col_offset,
                severity=Severity.INFO,
                rule_id="FW-FA-050",
                tool="framework-checks",
                category=Category.QUALITY,
                message=(
                    "@app.on_event is deprecated in FastAPI >= 0.93."
                    " Use lifespan context managers instead."
                ),
                fix=(
                    "Replace @app.on_event('startup'/'shutdown') with"
                    " a lifespan async context manager"
                ),
            )
            for dec in node.decorator_list
            if (
                isinstance(dec, ast.Call)
                and isinstance(dec.func, ast.Attribute)
                and dec.func.attr == "on_event"
            )
        )
    return diags


def _fastapi_dependency_diags(f: Path, tree: ast.AST) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if (
            _is_fastapi_dependency(node)
            and _raises_http_exception(node)
            and not _has_finally(node)
        ):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.WARNING,
                    rule_id="FW-FA-051",
                    tool="framework-checks",
                    category=Category.QUALITY,
                    message=(
                        f"Dependency '{node.name}' raises HTTPException"
                        " without cleanup handling."
                    ),
                    fix=(
                        "Wrap cleanup-sensitive dependency logic"
                        " in try/finally or a yield dependency"
                    ),
                )
            )
    return diags


def _check_fastapi_file(f: Path) -> list[Diagnostic]:
    tree = parse_file(f)
    if tree is None:
        return []

    diags: list[Diagnostic] = []
    diags.extend(_fastapi_cors_diags(f, tree))
    diags.extend(_fastapi_sync_endpoint_diags(f, tree))

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        route_decorators = _fastapi_route_decorators(node)
        if route_decorators:
            diags.extend(_fastapi_route_diags(f, node, route_decorators))

    diags.extend(_fastapi_lifecycle_diags(f, tree))
    diags.extend(_fastapi_dependency_diags(f, tree))
    return diags


def _is_fastapi_route_handler(node: object) -> bool:
    """Return True if node is a sync def decorated with an HTTP method decorator."""
    import ast as _ast

    if not isinstance(node, _ast.FunctionDef):
        return False
    http_methods = {
        "get",
        "post",
        "put",
        "delete",
        "patch",
        "head",
        "options",
        "websocket",
    }
    for dec in node.decorator_list:
        name: str | None = None
        if isinstance(dec, _ast.Call):
            fn = dec.func
            if isinstance(fn, _ast.Attribute):
                name = fn.attr
        elif isinstance(dec, _ast.Attribute):
            name = dec.attr
        if name and name.lower() in http_methods:
            return True
    return False


# ---------------------------------------------------------------------------
# Flask checks
# ---------------------------------------------------------------------------


def _check_flask(
    root: Path,
    files: list[Path],
    fw: FrameworkInfo,
) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    for f in files:
        diags.extend(_check_flask_file(f))
    return diags


def _flask_run_call_diags(f: Path, node: ast.Call) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    if not isinstance(node.func, ast.Attribute) or node.func.attr != "run":
        return diags
    if has_keyword_true(node, "debug"):
        diags.append(
            Diagnostic(
                file_path=f,
                line=node.lineno,
                column=node.col_offset,
                severity=Severity.ERROR,
                rule_id="FW-FL-001",
                tool="framework-checks",
                category=Category.SECURITY,
                message=(
                    "app.run(debug=True) enables the interactive debugger."
                    " Never run with debug=True in production."
                ),
                fix=(
                    "Use debug=os.environ.get('FLASK_DEBUG', 'false')"
                    ".lower() == 'true'"
                ),
            )
        )
    host = get_keyword_value(node, "host")
    if get_string_value(host) == "0.0.0.0":  # noqa: S104  # nosec B104
        diags.append(
            Diagnostic(
                file_path=f,
                line=node.lineno,
                column=node.col_offset,
                severity=Severity.WARNING,
                rule_id="FW-FL-003",
                tool="framework-checks",
                category=Category.SECURITY,
                message=(
                    "app.run(host='0.0.0.0') exposes the dev"
                    " server on all interfaces."
                ),
                fix=(
                    "Guard this with an explicit dev/prod check"
                    " or use a production WSGI server"
                ),
            )
        )
    return diags


def _flask_assign_diags(f: Path, node: ast.Assign) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    if _assigns_flask_config(node, "SECRET_KEY") and is_string_constant(node.value):
        diags.append(
            Diagnostic(
                file_path=f,
                line=node.lineno,
                column=node.col_offset,
                severity=Severity.ERROR,
                rule_id="FW-FL-002",
                tool="framework-checks",
                category=Category.SECURITY,
                message="SECRET_KEY is hardcoded. Session cookies can be forged.",
                fix="Load SECRET_KEY from the environment or secure config",
            )
        )
    return diags


def _flask_security_summary_diags(
    f: Path,
    tree: ast.AST,
    saw_flask_app: bool,
    has_csp: bool,
    has_factory: bool,
    route_count: int,
) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    assignments = extract_assignments(tree) if isinstance(tree, ast.Module) else {}
    secret = assignments.get("SECRET_KEY")
    if secret and is_string_constant(secret.node):
        diags.append(
            Diagnostic(
                file_path=f,
                line=secret.line,
                column=0,
                severity=Severity.ERROR,
                rule_id="FW-FL-002",
                tool="framework-checks",
                category=Category.SECURITY,
                message="SECRET_KEY is hardcoded. Session cookies can be forged.",
                fix="SECRET_KEY = os.environ['SECRET_KEY']",
            )
        )
    if (
        saw_flask_app
        and not (secret and is_string_constant(secret.node))
        and "SECRET_KEY" not in assignments
    ):
        diags.append(
            Diagnostic(
                file_path=f,
                line=0,
                column=0,
                severity=Severity.ERROR,
                rule_id="FW-FL-002",
                tool="framework-checks",
                category=Category.SECURITY,
                message="SECRET_KEY is not configured.",
                fix="Configure SECRET_KEY from the environment or instance config",
            )
        )
    if saw_flask_app and not _has_flask_config_true(tree, "SESSION_COOKIE_SECURE"):
        diags.append(
            Diagnostic(
                file_path=f,
                line=0,
                column=0,
                severity=Severity.WARNING,
                rule_id="FW-FL-004",
                tool="framework-checks",
                category=Category.SECURITY,
                message="SESSION_COOKIE_SECURE is not enabled.",
                fix="Set SESSION_COOKIE_SECURE = True in production config",
            )
        )
    if saw_flask_app and not _has_flask_config_true(tree, "SESSION_COOKIE_HTTPONLY"):
        diags.append(
            Diagnostic(
                file_path=f,
                line=0,
                column=0,
                severity=Severity.WARNING,
                rule_id="FW-FL-005",
                tool="framework-checks",
                category=Category.SECURITY,
                message="SESSION_COOKIE_HTTPONLY is not enabled.",
                fix="Set SESSION_COOKIE_HTTPONLY = True in production config",
            )
        )
    if saw_flask_app and not has_csp and not _uses_flask_talisman(tree):
        diags.append(
            Diagnostic(
                file_path=f,
                line=0,
                column=0,
                severity=Severity.INFO,
                rule_id="FW-FL-006",
                tool="framework-checks",
                category=Category.SECURITY,
                message="No CSP headers configured for the Flask app.",
                fix=(
                    "Configure Content-Security-Policy headers" " or use flask-talisman"
                ),
            )
        )
    if saw_flask_app and not has_factory:
        diags.append(
            Diagnostic(
                file_path=f,
                line=0,
                column=0,
                severity=Severity.INFO,
                rule_id="FW-FL-050",
                tool="framework-checks",
                category=Category.QUALITY,
                message="Application factory pattern not found.",
                fix=(
                    "Prefer a create_app() factory for testing"
                    " and configuration isolation"
                ),
            )
        )
    if route_count > 10:
        diags.append(
            Diagnostic(
                file_path=f,
                line=0,
                column=0,
                severity=Severity.INFO,
                rule_id="FW-FL-052",
                tool="framework-checks",
                category=Category.QUALITY,
                message=(
                    "Large Flask module with many routes detected."
                    " Consider Blueprints."
                ),
                fix="Split routes across Blueprints or feature modules",
            )
        )
    return diags


def _check_flask_file(f: Path) -> list[Diagnostic]:
    tree = parse_file(f)
    if tree is None:
        return []

    diags: list[Diagnostic] = []
    saw_flask_app = False
    route_count = 0
    has_factory = False
    has_csp = False

    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            if is_call_to(node, "Flask"):
                saw_flask_app = True
            diags.extend(_flask_run_call_diags(f, node))
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            route_decs = [
                d for d in node.decorator_list if _decorator_name(d) == "route"
            ]
            route_count += len(route_decs)
            if node.name == "create_app":
                has_factory = True
            if route_decs and _has_mutable_default_arg(node):
                diags.append(
                    Diagnostic(
                        file_path=f,
                        line=node.lineno,
                        column=node.col_offset,
                        severity=Severity.WARNING,
                        rule_id="FW-FL-051",
                        tool="framework-checks",
                        category=Category.QUALITY,
                        message=(
                            f"Route handler '{node.name}' uses a"
                            " mutable default argument."
                        ),
                        fix=(
                            "Use None as the default and create the"
                            " mutable value inside the function"
                        ),
                    )
                )
        if isinstance(node, ast.Assign):
            diags.extend(_flask_assign_diags(f, node))
            if _assigns_flask_config(node, "CONTENT_SECURITY_POLICY"):
                has_csp = True
            if _assigns_flask_config(
                node, "SESSION_COOKIE_SECURE"
            ) or _assigns_flask_config(node, "SESSION_COOKIE_HTTPONLY"):
                saw_flask_app = True

    diags.extend(
        _flask_security_summary_diags(
            f, tree, saw_flask_app, has_csp, has_factory, route_count
        )
    )

    return diags


# ---------------------------------------------------------------------------
# Celery checks
# ---------------------------------------------------------------------------


def _check_celery(
    root: Path,
    files: list[Path],
    fw: FrameworkInfo,
) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    for f in files:
        if "celery" in f.name.lower() or "tasks" in f.name.lower():
            diags.extend(_check_celery_file(f))
    return diags


def _check_celery_file(f: Path) -> list[Diagnostic]:
    tree = parse_file(f)
    if tree is None:
        return []

    diags: list[Diagnostic] = []
    assignments = extract_assignments(tree)

    # FW-CL-001: task_always_eager = True (should only be used in tests)
    eager = assignments.get("task_always_eager") or assignments.get(
        "CELERY_ALWAYS_EAGER"
    )
    if eager and is_truthy_constant(eager.node):
        diags.append(
            Diagnostic(
                file_path=f,
                line=eager.line,
                column=0,
                severity=Severity.WARNING,
                rule_id="FW-CL-001",
                tool="framework-checks",
                category=Category.QUALITY,
                message=(
                    "task_always_eager=True skips the broker — tasks run"
                    " synchronously. This should only be used in test environments."
                ),
                fix=(
                    "Set task_always_eager only in test settings,"
                    " not production config"
                ),
            )
        )

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        task_decorator = _find_decorator_call(node, "task", "shared_task")
        if task_decorator is None:
            continue
        if get_keyword_value(task_decorator, "max_retries") is None:
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.WARNING,
                    rule_id="FW-CL-002",
                    tool="framework-checks",
                    category=Category.QUALITY,
                    message=f"Celery task '{node.name}' has no max_retries configured.",
                    fix="Add max_retries=... to the task decorator",
                )
            )
        if get_keyword_value(task_decorator, "acks_late") is None:
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.WARNING,
                    rule_id="FW-CL-003",
                    tool="framework-checks",
                    category=Category.QUALITY,
                    message=f"Celery task '{node.name}' has no acks_late setting.",
                    fix="Add acks_late=True for idempotent tasks where appropriate",
                )
            )
        if len(node.args.args) > 5:
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.INFO,
                    rule_id="FW-CL-004",
                    tool="framework-checks",
                    category=Category.QUALITY,
                    message=f"Celery task '{node.name}' takes many arguments.",
                    fix=(
                        "Pass compact identifiers or payload objects"
                        " instead of many primitive arguments"
                    ),
                )
            )

    for name in ("task_serializer", "result_serializer", "CELERY_TASK_SERIALIZER"):
        serializer = assignments.get(name)
        if serializer and get_string_value(serializer.node) == "pickle":
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=serializer.line,
                    column=0,
                    severity=Severity.WARNING,
                    rule_id="FW-CL-005",
                    tool="framework-checks",
                    category=Category.SECURITY,
                    message=(
                        "Celery pickle serializer enabled."
                        " Deserializing pickle is unsafe."
                    ),
                    fix=(
                        "Use json serializer instead of pickle"
                        " for Celery tasks/results"
                    ),
                )
            )

    return diags


# ---------------------------------------------------------------------------
# SQLAlchemy checks
# ---------------------------------------------------------------------------


def _check_sqlalchemy(
    root: Path,
    files: list[Path],
    fw: FrameworkInfo,
) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    for f in files:
        diags.extend(_check_sqlalchemy_file(f))
    return diags


def _check_sqlalchemy_file(f: Path) -> list[Diagnostic]:
    tree = parse_file(f)
    if tree is None:
        return []

    diags: list[Diagnostic] = []
    parents = _build_parent_map(tree)

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue

        # FW-SA-001: Raw SQL text() without parameterisation
        if is_call_to(node, "text", "execute"):
            for arg in node.args:
                if is_string_constant(arg):
                    sql = get_string_value(arg) or ""
                    if "%" in sql or "{" in sql:
                        diags.append(
                            Diagnostic(
                                file_path=f,
                                line=node.lineno,
                                column=node.col_offset,
                                severity=Severity.ERROR,
                                rule_id="FW-SA-001",
                                tool="framework-checks",
                                category=Category.SECURITY,
                                message="Raw SQL with string interpolation. "
                                "SQL injection risk.",
                                fix="Use sqlalchemy.text() with bound parameters: "
                                "text('SELECT * FROM t WHERE id = :id')",
                            )
                        )

        # FW-SA-002: create_engine with echo=True
        if is_call_to(
            node, "create_engine", "create_async_engine"
        ) and has_keyword_true(node, "echo"):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.WARNING,
                    rule_id="FW-SA-002",
                    tool="framework-checks",
                    category=Category.QUALITY,
                    message="create_engine(echo=True) logs all SQL to stdout. "
                    "Remove or guard with an environment check.",
                    fix="echo=os.environ.get('DB_ECHO', 'false').lower() == 'true'",
                )
            )

        if _is_session_call(node) and not _is_inside_with(node, parents):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.WARNING,
                    rule_id="FW-SA-004",
                    tool="framework-checks",
                    category=Category.QUALITY,
                    message="Session used without a context manager.",
                    fix=(
                        "Use 'with Session(...) as session:'"
                        " or ensure explicit close() handling"
                    ),
                )
            )

    for node in ast.walk(tree):
        if (
            isinstance(node, ast.ClassDef)
            and _is_sqlalchemy_model(node)
            and not any(
                isinstance(child, ast.FunctionDef) and child.name == "__repr__"
                for child in node.body
            )
        ):
            diags.append(  # noqa: PERF401
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.INFO,
                    rule_id="FW-SA-003",
                    tool="framework-checks",
                    category=Category.QUALITY,
                    message=(
                        f"SQLAlchemy model '{node.name}'"
                        " has no __repr__ implementation."
                    ),
                    fix="Add a concise __repr__ to improve debugging and logging",
                )
            )

    return diags


def _build_parent_map(tree: ast.AST) -> dict[ast.AST, ast.AST]:
    parents: dict[ast.AST, ast.AST] = {}
    for parent in ast.walk(tree):
        for child in ast.iter_child_nodes(parent):
            parents[child] = parent
    return parents


def _decorator_name(node: ast.expr) -> str | None:
    match node:
        case ast.Name():
            return node.id
        case ast.Attribute():
            return node.attr
        case ast.Call():
            return _decorator_name(node.func)
        case _:
            return None


def _fastapi_route_decorators(
    node: ast.FunctionDef | ast.AsyncFunctionDef,
) -> list[ast.Call]:
    decorators: list[ast.Call] = []
    decorators.extend(
        dec
        for dec in node.decorator_list
        if (
            isinstance(dec, ast.Call)
            and isinstance(dec.func, ast.Attribute)
            and dec.func.attr.lower()
            in {"get", "post", "put", "delete", "patch", "head", "options"}
        )
    )
    return decorators


def _is_mutating_fastapi_route(node: ast.Call) -> bool:
    return isinstance(node.func, ast.Attribute) and node.func.attr.lower() in {
        "post",
        "put",
        "delete",
        "patch",
    }


def _is_fastapi_dependency(node: ast.AST) -> bool:
    if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        return False
    for arg in node.args.args:
        annotation = arg.annotation
        if (
            isinstance(annotation, ast.Call)
            and _decorator_name(annotation) == "Depends"
        ):
            return True
    for default in node.args.defaults:
        if isinstance(default, ast.Call) and _decorator_name(default) == "Depends":
            return True
    return False


def _raises_http_exception(node: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    for child in ast.walk(node):
        if (
            isinstance(child, ast.Raise)
            and isinstance(child.exc, ast.Call)
            and _decorator_name(child.exc.func) == "HTTPException"
        ):
            return True
    return False


def _has_finally(node: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    return any(
        isinstance(child, ast.Try) and child.finalbody for child in ast.walk(node)
    )


def _has_mutable_default_arg(node: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    return any(
        isinstance(default, (ast.List, ast.Dict, ast.Set))
        for default in node.args.defaults
    )


def _assigns_flask_config(node: ast.Assign, key: str) -> bool:
    for target in node.targets:
        if isinstance(target, ast.Name) and target.id == key:
            return True
        if (
            isinstance(target, ast.Subscript)
            and isinstance(target.value, ast.Attribute)
            and target.value.attr == "config"
            and _subscript_key(target) == key
        ):
            return True
    return False


def _subscript_key(node: ast.Subscript) -> str | None:
    slice_node = node.slice
    if isinstance(slice_node, ast.Constant) and isinstance(slice_node.value, str):
        return slice_node.value
    return None


def _has_flask_config_true(tree: ast.AST, key: str) -> bool:
    for child in ast.walk(tree):
        if (
            isinstance(child, ast.Assign)
            and _assigns_flask_config(child, key)
            and is_truthy_constant(child.value)
        ):
            return True
    return False


def _uses_flask_talisman(tree: ast.AST) -> bool:
    for child in ast.walk(tree):
        if isinstance(child, ast.Call) and is_call_to(child, "Talisman"):
            return True
    return False


def _find_decorator_call(
    node: ast.FunctionDef | ast.AsyncFunctionDef,
    *names: str,
) -> ast.Call | None:
    for dec in node.decorator_list:
        if isinstance(dec, ast.Call) and _decorator_name(dec) in names:
            return dec
    return None


def _is_session_call(node: ast.Call) -> bool:
    return _decorator_name(node.func) == "Session"


def _is_inside_with(node: ast.AST, parents: dict[ast.AST, ast.AST]) -> bool:
    current = parents.get(node)
    while current is not None:
        if isinstance(current, ast.With):
            return True
        current = parents.get(current)
    return False


def _is_sqlalchemy_model(node: ast.ClassDef) -> bool:
    if any(
        (isinstance(base, ast.Name) and base.id == "Base")
        or (isinstance(base, ast.Attribute) and base.attr == "Base")
        for base in node.bases
    ):
        return True
    return any(
        isinstance(child, ast.Assign)
        and any(
            isinstance(target, ast.Name) and target.id.startswith("__") is False
            for target in child.targets
        )
        and isinstance(child.value, ast.Call)
        and is_call_to(child.value, "Column", "mapped_column")
        for child in node.body
    )


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------

_FRAMEWORK_CHECKERS = {
    "django": _check_django,
    "drf": _check_django,  # DRF shares Django checker
    "fastapi": _check_fastapi,
    "flask": _check_flask,
    "celery": _check_celery,
    "sqlalchemy": _check_sqlalchemy,
}
