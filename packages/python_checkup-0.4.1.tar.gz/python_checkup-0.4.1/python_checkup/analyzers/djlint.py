from __future__ import annotations

import asyncio
import logging
import re
import shutil
from pathlib import Path

from python_checkup.analysis_request import AnalysisRequest
from python_checkup.models import Category, Diagnostic, Severity

logger = logging.getLogger("python_checkup")

# djlint rule prefixes and their severity mapping
_DJLINT_SEVERITY: dict[str, Severity] = {
    "E": Severity.ERROR,  # Error rules
    "W": Severity.WARNING,  # Warning rules
    "H": Severity.INFO,  # HTML best-practice rules
    "D": Severity.INFO,  # Django-specific rules
    "J": Severity.INFO,  # Jinja rules
    "T": Severity.INFO,  # Template rules
}

# Pattern: filename:line:col: CODE message
_OUTPUT_RE = re.compile(
    r"^(?P<file>.+?):(?P<line>\d+):(?P<col>\d+):\s+"
    r"(?P<code>[A-Z]\d+)\s+(?P<message>.+)$",
)

_SKIP_DIRS: frozenset[str] = frozenset(
    {".venv", "venv", "site-packages", "node_modules", "dist", "build"}
)


class DjlintAnalyzer:
    """Django/Jinja template linting via djlint."""

    @property
    def name(self) -> str:
        return "djlint"

    @property
    def category(self) -> Category:
        return Category.QUALITY

    async def is_available(self) -> bool:
        """Check if djlint is on PATH."""
        return shutil.which("djlint") is not None

    async def analyze(
        self,
        request: AnalysisRequest,
    ) -> list[Diagnostic]:
        # Only run when Django is detected
        if not request.framework_stack or not any(
            fw.name == "django" for fw in request.framework_stack.all_frameworks
        ):
            return []

        template_dirs = _find_template_dirs(request.project_root)
        if not template_dirs:
            return []

        template_files = _collect_template_files(template_dirs)
        if not template_files:
            return []

        timeout: int = request.config.timeout

        cmd = [
            "djlint",
            "--lint",
            "--quiet",
            "--linter-output-format",
            "{filename}:{line}:{col}: {code} {message}",
            *[str(f) for f in template_files],
        ]

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            logger.warning("djlint timed out")
            return []
        except FileNotFoundError:
            logger.warning("djlint binary not found")
            return []

        # djlint exits 0 when clean, 1 when issues found
        if proc.returncode not in (0, 1):
            logger.error("djlint error: %s", stderr.decode())
            return []

        output = stdout.decode()
        if not output.strip():
            return []

        return _parse_djlint_output(output)


def _find_template_dirs(root: Path) -> list[Path]:
    """Find ``templates/`` directories in the project."""
    dirs: list[Path] = []
    for d in root.rglob("templates"):
        if not d.is_dir():
            continue
        if any(p in _SKIP_DIRS for p in d.parts):
            continue
        dirs.append(d)
    return dirs


def _collect_template_files(
    template_dirs: list[Path],
) -> list[Path]:
    """Collect .html files from template directories."""
    files: list[Path] = []
    for tdir in template_dirs:
        files.extend(tdir.rglob("*.html"))
    return files


def _parse_djlint_output(output: str) -> list[Diagnostic]:
    """Parse djlint linter output into Diagnostic objects."""
    diagnostics: list[Diagnostic] = []
    for line in output.splitlines():
        line = line.strip()
        if not line:
            continue
        match = _OUTPUT_RE.match(line)
        if not match:
            continue

        code = match.group("code")
        severity = _DJLINT_SEVERITY.get(code[0], Severity.INFO)

        diagnostics.append(
            Diagnostic(
                file_path=Path(match.group("file")),
                line=int(match.group("line")),
                column=int(match.group("col")),
                severity=severity,
                rule_id=code,
                tool="djlint",
                category=Category.QUALITY,
                message=match.group("message").strip(),
                fix=None,
            )
        )

    return diagnostics
