from __future__ import annotations

import ast
import re
from pathlib import Path
from typing import TYPE_CHECKING

from python_checkup.analyzers.ast_helpers import (
    AssignmentInfo,
    extract_assignments,
    get_keyword_value,
    get_list_string_values,
    get_string_value,
    is_call_to,
    is_falsy_constant,
    is_string_constant,
    is_truthy_constant,
    parse_file,
)
from python_checkup.models import Category, Diagnostic, Severity

if TYPE_CHECKING:
    from python_checkup.detection import FrameworkInfo


def check_django(
    root: Path,
    files: list[Path],
    fw: FrameworkInfo,
) -> list[Diagnostic]:
    """Run all Django checks and return diagnostics."""
    diags: list[Diagnostic] = []

    # Find settings files
    for settings_path in _find_django_settings(root, files):
        diags.extend(_check_django_settings(settings_path))

    # Code-pattern checks
    django_version = _parse_django_version(fw.version)
    for f in files:
        diags.extend(_check_django_code(f))
        diags.extend(_check_django_code_deprecated(f, django_version))
        diags.extend(_check_django_urls(f))

    # Migration linting
    diags.extend(_check_django_migrations(root, files))

    return diags


def _find_django_settings(root: Path, files: list[Path]) -> list[Path]:
    """Locate Django settings files."""
    # Explicit settings files first
    results: list[Path] = [
        f
        for f in files
        if f.name == "settings.py" or (f.stem == "settings" and f.suffix == ".py")
    ]
    if not results:
        # Fallback: search project root
        results.extend(
            match
            for match in root.rglob("settings.py")
            if not any(
                part in (".venv", "venv", "site-packages", "dist", "build")
                for part in match.parts
            )
        )
    return results


_DJANGO_HTTPS_SETTINGS: list[tuple[str, str, str]] = [
    (
        "CSRF_COOKIE_SECURE",
        "FW-DJ-004",
        "CSRF cookies are sent over HTTP, exposing them to interception",
    ),
    (
        "SESSION_COOKIE_SECURE",
        "FW-DJ-005",
        "Session cookies are sent over HTTP, enabling session hijacking",
    ),
    (
        "SECURE_SSL_REDIRECT",
        "FW-DJ-006",
        "HTTP requests are not redirected to HTTPS",
    ),
    (
        "SECURE_HSTS_SECONDS",
        "FW-DJ-007",
        "HSTS is not configured; browsers won't enforce HTTPS",
    ),
]


def _dj_settings_basic_diags(
    settings_path: Path, assignments: dict[str, AssignmentInfo]
) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    debug = assignments.get("DEBUG")
    if debug and is_truthy_constant(debug.node):
        diags.append(
            Diagnostic(
                file_path=settings_path,
                line=debug.line,
                column=0,
                severity=Severity.ERROR,
                rule_id="FW-DJ-001",
                tool="framework-checks",
                category=Category.SECURITY,
                message=(
                    "DEBUG = True: disables Django security checks and exposes "
                    "tracebacks to end users. Never run with DEBUG=True in production."
                ),
                fix="Set DEBUG = os.environ.get('DEBUG', 'False') == 'True'",
            )
        )
    hosts = assignments.get("ALLOWED_HOSTS")
    if hosts:
        values = get_list_string_values(hosts.node)
        if "*" in values:
            diags.append(
                Diagnostic(
                    file_path=settings_path,
                    line=hosts.line,
                    column=0,
                    severity=Severity.ERROR,
                    rule_id="FW-DJ-002",
                    tool="framework-checks",
                    category=Category.SECURITY,
                    message=(
                        "ALLOWED_HOSTS = ['*'] allows any host header. "
                        "Vulnerable to host-header injection."
                    ),
                    fix=(
                        "Set ALLOWED_HOSTS to your specific domain(s): "
                        "['example.com', 'www.example.com']"
                    ),
                )
            )
        elif not values:
            diags.append(
                Diagnostic(
                    file_path=settings_path,
                    line=hosts.line,
                    column=0,
                    severity=Severity.ERROR,
                    rule_id="FW-DJ-002",
                    tool="framework-checks",
                    category=Category.SECURITY,
                    message=(
                        "ALLOWED_HOSTS is empty. Django will reject all requests "
                        "when DEBUG=False."
                    ),
                    fix="Add your domain(s): ALLOWED_HOSTS = ['example.com']",
                )
            )
    return diags


def _dj_settings_secret_diags(
    settings_path: Path, assignments: dict[str, AssignmentInfo]
) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    secret = assignments.get("SECRET_KEY")
    if not secret:
        return diags
    val = get_string_value(secret.node)
    if val is None:
        return diags
    if val.startswith("django-insecure-"):
        diags.append(
            Diagnostic(
                file_path=settings_path,
                line=secret.line,
                column=0,
                severity=Severity.WARNING,
                rule_id="FW-DJ-011",
                tool="framework-checks",
                category=Category.SECURITY,
                message=(
                    "Using the default insecure SECRET_KEY generated by "
                    "startproject. Rotate before deploying."
                ),
                fix=(
                    'Generate a new key: python -c "from django.core.management'
                    ".utils import get_random_secret_key; "
                    'print(get_random_secret_key())"'
                ),
            )
        )
    else:
        diags.append(
            Diagnostic(
                file_path=settings_path,
                line=secret.line,
                column=0,
                severity=Severity.ERROR,
                rule_id="FW-DJ-003",
                tool="framework-checks",
                category=Category.SECURITY,
                message=(
                    "SECRET_KEY is hardcoded. Anyone with source access "
                    "can forge session cookies."
                ),
                fix="SECRET_KEY = os.environ['SECRET_KEY']",
            )
        )
    return diags


def _dj_settings_middleware_diags(
    settings_path: Path, assignments: dict[str, AssignmentInfo]
) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    middleware = assignments.get("MIDDLEWARE")
    if not middleware:
        return diags
    mw_list = get_list_string_values(middleware.node)
    if not mw_list:
        return diags
    if "django.middleware.csrf.CsrfViewMiddleware" not in mw_list:
        diags.append(
            Diagnostic(
                file_path=settings_path,
                line=middleware.line,
                column=0,
                severity=Severity.ERROR,
                rule_id="FW-DJ-008",
                tool="framework-checks",
                category=Category.SECURITY,
                message=(
                    "CsrfViewMiddleware is missing from MIDDLEWARE. "
                    "All state-changing views are vulnerable to CSRF."
                ),
                fix=("Add 'django.middleware.csrf.CsrfViewMiddleware' to MIDDLEWARE"),
            )
        )
    if "django.middleware.security.SecurityMiddleware" not in mw_list:
        diags.append(
            Diagnostic(
                file_path=settings_path,
                line=middleware.line,
                column=0,
                severity=Severity.WARNING,
                rule_id="FW-DJ-009",
                tool="framework-checks",
                category=Category.SECURITY,
                message=(
                    "SecurityMiddleware is missing from MIDDLEWARE. "
                    "HTTPS enforcement and security headers will not be set."
                ),
                fix=(
                    "Add 'django.middleware.security.SecurityMiddleware'"
                    " to MIDDLEWARE (should be first)"
                ),
            )
        )
    return diags


def _dj_settings_https_diags(
    settings_path: Path, assignments: dict[str, AssignmentInfo]
) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    for setting_name, rule_id, msg in _DJANGO_HTTPS_SETTINGS:
        setting = assignments.get(setting_name)
        insecure = False
        if setting is None:
            insecure = True
        elif setting_name == "SECURE_HSTS_SECONDS":
            node = setting.node
            if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
                insecure = int(node.value) <= 0
        else:
            insecure = is_falsy_constant(setting.node)
        if insecure:
            diags.append(
                Diagnostic(
                    file_path=settings_path,
                    line=setting.line if setting is not None else 0,
                    column=0,
                    severity=Severity.WARNING,
                    rule_id=rule_id,
                    tool="framework-checks",
                    category=Category.SECURITY,
                    message=f"{setting_name} not configured: {msg}",
                    fix=f"Add {setting_name} = True to your production settings",
                )
            )
    return diags


def _dj_settings_validators_diags(
    settings_path: Path, assignments: dict[str, AssignmentInfo]
) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    validators = assignments.get("AUTH_PASSWORD_VALIDATORS")
    if validators is None:
        diags.append(
            Diagnostic(
                file_path=settings_path,
                line=0,
                column=0,
                severity=Severity.WARNING,
                rule_id="FW-DJ-010",
                tool="framework-checks",
                category=Category.SECURITY,
                message=(
                    "AUTH_PASSWORD_VALIDATORS is not configured. "
                    "Weak passwords will be accepted."
                ),
                fix=(
                    "Add Django's built-in password validators"
                    " to AUTH_PASSWORD_VALIDATORS"
                ),
            )
        )
    else:
        node = validators.node
        if isinstance(node, (ast.List, ast.Tuple)) and not node.elts:
            diags.append(
                Diagnostic(
                    file_path=settings_path,
                    line=validators.line,
                    column=0,
                    severity=Severity.WARNING,
                    rule_id="FW-DJ-010",
                    tool="framework-checks",
                    category=Category.SECURITY,
                    message=(
                        "AUTH_PASSWORD_VALIDATORS is empty. "
                        "All passwords, including empty ones, will be accepted."
                    ),
                    fix="Add Django's built-in password validators",
                )
            )
    return diags


def _check_django_settings(settings_path: Path) -> list[Diagnostic]:
    tree = parse_file(settings_path)
    if tree is None:
        return []

    assignments = extract_assignments(tree)
    diags: list[Diagnostic] = []
    diags.extend(_dj_settings_basic_diags(settings_path, assignments))
    diags.extend(_dj_settings_secret_diags(settings_path, assignments))
    diags.extend(_dj_settings_middleware_diags(settings_path, assignments))
    diags.extend(_dj_settings_https_diags(settings_path, assignments))
    diags.extend(_dj_settings_validators_diags(settings_path, assignments))

    # FW-DJ-050: DEFAULT_AUTO_FIELD missing (Django 3.2+)
    if "DEFAULT_AUTO_FIELD" not in assignments:
        diags.append(
            Diagnostic(
                file_path=settings_path,
                line=0,
                column=0,
                severity=Severity.INFO,
                rule_id="FW-DJ-050",
                tool="framework-checks",
                category=Category.QUALITY,
                message=(
                    "DEFAULT_AUTO_FIELD not set. Django will warn on startup "
                    "and use BigAutoField by default."
                ),
                fix="Add DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'",
            )
        )

    return diags


def _build_parent_map(tree: ast.AST) -> dict[ast.AST, ast.AST]:
    parents: dict[ast.AST, ast.AST] = {}
    for parent in ast.walk(tree):
        for child in ast.iter_child_nodes(parent):
            parents[child] = parent
    return parents


def _is_unparameterized_sql_call(node: ast.Call) -> bool:
    if not node.args:
        return False
    first = node.args[0]
    if isinstance(first, ast.JoinedStr | ast.BinOp):
        return True
    if is_string_constant(first):
        sql = (get_string_value(first) or "").upper()
        if any(keyword in sql for keyword in ("SELECT", "INSERT", "UPDATE", "DELETE")):
            return len(node.args) == 1 and not any(
                kw.arg == "params" for kw in node.keywords
            )
    return False


def _is_queryset_get_call(node: ast.AST) -> bool:
    return (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "get"
        and isinstance(node.func.value, ast.Attribute)
        and node.func.value.attr == "objects"
    )


def _is_inside_try(node: ast.AST, parents: dict[ast.AST, ast.AST]) -> bool:
    current = parents.get(node)
    while current is not None:
        if isinstance(current, ast.Try):
            return True
        current = parents.get(current)
    return False


def _decorator_name(node: ast.expr) -> str | None:
    match node:
        case ast.Name():
            return node.id
        case ast.Attribute():
            return node.attr
        case ast.Call():
            return _decorator_name(node.func)
        case _:
            return None


def _is_django_class_based_view(node: ast.ClassDef) -> bool:
    return any(
        (isinstance(base, ast.Name) and base.id.endswith("View"))
        or (isinstance(base, ast.Attribute) and base.attr.endswith("View"))
        for base in node.bases
    )


def _looks_like_queryset_iteration(node: ast.AST) -> bool:
    return (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr
        in {
            "all",
            "filter",
            "exclude",
            "order_by",
        }
    )


def _query_uses_prefetching(node: ast.AST) -> bool:
    for child in ast.walk(node):
        if (
            isinstance(child, ast.Call)
            and isinstance(child.func, ast.Attribute)
            and child.func.attr in {"select_related", "prefetch_related"}
        ):
            return True
    return False


def _accesses_related_attribute(body: list[ast.stmt], loop_var: str) -> bool:
    # Collect nodes used as the func of a Call (e.g. item.name.upper()).
    # Those are method calls on scalar fields, not FK traversals — exclude them
    # to avoid false positives on patterns like `item.title.lower()`.
    call_funcs: set[int] = set()
    for stmt in body:
        for node in ast.walk(stmt):
            if isinstance(node, ast.Call):
                call_funcs.add(id(node.func))

    for stmt in body:
        for child in ast.walk(stmt):
            if (
                isinstance(child, ast.Attribute)
                and id(child) not in call_funcs  # not a method being called
                and isinstance(child.value, ast.Attribute)
                and isinstance(child.value.value, ast.Name)
                and child.value.value.id == loop_var
            ):
                return True
    return False


def _dj_code_call_diags(
    f: Path, tree: ast.AST, parents: dict[ast.AST, ast.AST]
) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        # FW-DJ-051: ForeignKey without on_delete
        if (
            is_call_to(node, "ForeignKey")
            and get_keyword_value(node, "on_delete") is None
        ):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.INFO,
                    rule_id="FW-DJ-051",
                    tool="framework-checks",
                    category=Category.QUALITY,
                    message=(
                        "ForeignKey declared without on_delete. Explicit deletion "
                        "behavior is recommended."
                    ),
                    fix="Add on_delete=models.CASCADE (or the correct explicit policy)",
                )
            )
        # FW-DJ-052: raw SQL via cursor.execute without parameterisation
        if (
            isinstance(node.func, ast.Attribute)
            and node.func.attr == "execute"
            and _is_unparameterized_sql_call(node)
        ):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.WARNING,
                    rule_id="FW-DJ-052",
                    tool="framework-checks",
                    category=Category.SECURITY,
                    message=(
                        "Raw SQL query appears unparameterized."
                        " Risk of SQL injection."
                    ),
                    fix=(
                        "Use parameterised queries:"
                        " cursor.execute(sql, [param1, param2])"
                    ),
                )
            )
        if (
            isinstance(node.func, ast.Attribute)
            and node.func.attr == "raw"
            and _is_unparameterized_sql_call(node)
        ):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.WARNING,
                    rule_id="FW-DJ-052",
                    tool="framework-checks",
                    category=Category.SECURITY,
                    message=(
                        "Model.raw() appears unparameterized." " Risk of SQL injection."
                    ),
                    fix=(
                        "Use parameter placeholders and separate"
                        " parameters when calling raw()"
                    ),
                )
            )
        # FW-DJ-054: objects.get() without try/except DoesNotExist
        if _is_queryset_get_call(node) and not _is_inside_try(node, parents):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.WARNING,
                    rule_id="FW-DJ-054",
                    tool="framework-checks",
                    category=Category.QUALITY,
                    message=(
                        "objects.get() used without surrounding"
                        " try/except DoesNotExist."
                    ),
                    fix=(
                        "Wrap the get() call in try/except Model.DoesNotExist"
                        " or use get_object_or_404"
                    ),
                )
            )
    return diags


def _dj_code_class_and_loop_diags(f: Path, tree: ast.AST) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    for node in ast.walk(tree):
        # FW-DJ-053: @login_required on class-based view
        if (
            isinstance(node, ast.ClassDef)
            and _is_django_class_based_view(node)
            and any(
                _decorator_name(dec) == "login_required" for dec in node.decorator_list
            )
        ):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.INFO,
                    rule_id="FW-DJ-053",
                    tool="framework-checks",
                    category=Category.QUALITY,
                    message=(
                        "@login_required applied to a class-based view."
                        " Prefer LoginRequiredMixin."
                    ),
                    fix=(
                        "Use LoginRequiredMixin in the class bases"
                        " instead of @login_required"
                    ),
                )
            )
        # FW-DJ-055: possible N+1 related-field access in queryset loop
        if isinstance(node, ast.For) and _looks_like_queryset_iteration(node.iter):
            loop_var = node.target.id if isinstance(node.target, ast.Name) else None
            if (
                loop_var
                and _accesses_related_attribute(node.body, loop_var)
                and not _query_uses_prefetching(node.iter)
            ):
                diags.append(
                    Diagnostic(
                        file_path=f,
                        line=node.lineno,
                        column=node.col_offset,
                        severity=Severity.INFO,
                        rule_id="FW-DJ-055",
                        tool="framework-checks",
                        category=Category.QUALITY,
                        message=(
                            "Loop over queryset accesses related fields"
                            " without select_related/prefetch_related."
                        ),
                        fix=(
                            "Use select_related() or prefetch_related()"
                            " before iterating the queryset"
                        ),
                    )
                )
    return diags


def _check_django_code(f: Path) -> list[Diagnostic]:
    """Check Django code patterns in a single file."""
    tree = parse_file(f)
    if tree is None:
        return []
    parents = _build_parent_map(tree)
    diags: list[Diagnostic] = []
    diags.extend(_dj_code_call_diags(f, tree, parents))
    diags.extend(_dj_code_class_and_loop_diags(f, tree))
    return diags


_SKIP_MIGRATION_DIRS: frozenset[str] = frozenset(
    {".venv", "venv", "site-packages", "dist", "build", "node_modules"}
)


def _find_migration_files(root: Path, files: list[Path]) -> list[Path]:
    """Return migration files from the provided file list."""
    results: list[Path] = []
    for f in files:
        parts = f.parts
        if any(p in _SKIP_MIGRATION_DIRS for p in parts):
            continue
        if "migrations" in parts and f.name.startswith("0") and f.suffix == ".py":
            results.append(f)
    if not results:
        results.extend(
            f
            for f in root.rglob("migrations/0*.py")
            if not any(p in _SKIP_MIGRATION_DIRS for p in f.parts)
        )
    return results


def _extract_migration_operations(tree: ast.Module) -> list[ast.Call]:
    """Extract Call nodes from the ``operations`` list of a Migration class."""
    ops: list[ast.Call] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.ClassDef) or node.name != "Migration":
            continue
        for child in node.body:
            if not isinstance(child, ast.Assign):
                continue
            if not any(
                isinstance(t, ast.Name) and t.id == "operations" for t in child.targets
            ):
                continue
            if isinstance(child.value, (ast.List, ast.Tuple)):
                ops.extend(elt for elt in child.value.elts if isinstance(elt, ast.Call))
    return ops


def _op_name(call: ast.Call) -> str | None:
    """Return the operation name, e.g. 'AddField', 'RunPython'."""
    if isinstance(call.func, ast.Attribute):
        return call.func.attr
    if isinstance(call.func, ast.Name):
        return call.func.id
    return None


def _has_kw(call: ast.Call, name: str) -> bool:
    """Check if a keyword argument is present."""
    return any(kw.arg == name for kw in call.keywords)


def _kw_is_none(call: ast.Call, name: str) -> bool:
    """Check if a keyword argument is explicitly None."""
    for kw in call.keywords:
        if kw.arg == name:
            return isinstance(kw.value, ast.Constant) and kw.value.value is None
    return False


def _field_is_non_nullable_without_default(call: ast.Call) -> bool:
    """Check if a field operation adds a non-nullable field without a default.

    In AddField/AlterField the ``field`` keyword holds the field constructor
    call, e.g. ``field=models.CharField(max_length=100)``.  We inspect
    *that* inner call for ``null=True`` and ``default=...``.
    """
    field_kw = None
    for kw in call.keywords:
        if kw.arg == "field":
            field_kw = kw.value
            break
    if field_kw is None or not isinstance(field_kw, ast.Call):
        return False
    has_null_true = False
    has_default = False
    for kw in field_kw.keywords:
        if (
            kw.arg == "null"
            and isinstance(kw.value, ast.Constant)
            and kw.value.value is True
        ):
            has_null_true = True
        if kw.arg == "default":
            has_default = True
    # If field allows null or has a default, it's safe
    if has_null_true or has_default:
        return False
    # BooleanField has an implicit default of False — skip it
    field_name = _op_name(field_kw)
    return field_name not in ("BooleanField", "NullBooleanField")


def _field_adds_unique(call: ast.Call) -> bool:
    """Check if a field operation adds unique=True or a UniqueConstraint."""
    field_kw = None
    for kw in call.keywords:
        if kw.arg == "field":
            field_kw = kw.value
            break
    if field_kw is None or not isinstance(field_kw, ast.Call):
        return False
    for kw in field_kw.keywords:
        if (
            kw.arg == "unique"
            and isinstance(kw.value, ast.Constant)
            and kw.value.value is True
        ):
            return True
    return False


def _check_django_migration_file(f: Path) -> list[Diagnostic]:
    """Lint a single Django migration file for dangerous operations."""
    tree = parse_file(f)
    if tree is None:
        return []

    ops = _extract_migration_operations(tree)
    diags: list[Diagnostic] = []

    for op in ops:
        name = _op_name(op)
        if name is None:
            continue

        # FW-DJ-MIG-001: AddField with non-nullable field without default
        if name == "AddField" and _field_is_non_nullable_without_default(op):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=op.lineno,
                    column=op.col_offset,
                    severity=Severity.WARNING,
                    rule_id="FW-DJ-MIG-001",
                    tool="framework-checks",
                    category=Category.QUALITY,
                    message=(
                        "AddField with non-nullable field and no default. "
                        "This will fail on tables with existing rows."
                    ),
                    fix=(
                        "Add a default value, or make the field nullable "
                        "with null=True and add a data migration"
                    ),
                )
            )

        # FW-DJ-MIG-002: AlterField changing to non-nullable without default
        if name == "AlterField" and _field_is_non_nullable_without_default(op):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=op.lineno,
                    column=op.col_offset,
                    severity=Severity.WARNING,
                    rule_id="FW-DJ-MIG-002",
                    tool="framework-checks",
                    category=Category.QUALITY,
                    message=(
                        "AlterField to non-nullable without default. "
                        "Existing NULL rows will cause IntegrityError."
                    ),
                    fix=(
                        "First add a data migration to populate existing rows, "
                        "then alter the field"
                    ),
                )
            )

        # FW-DJ-MIG-003: RunPython without reverse_code
        if name == "RunPython" and (
            not _has_kw(op, "reverse_code") or _kw_is_none(op, "reverse_code")
        ):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=op.lineno,
                    column=op.col_offset,
                    severity=Severity.INFO,
                    rule_id="FW-DJ-MIG-003",
                    tool="framework-checks",
                    category=Category.QUALITY,
                    message=(
                        "RunPython without reverse_code. "
                        "This migration cannot be reversed."
                    ),
                    fix=(
                        "Add reverse_code=migrations.RunPython.noop "
                        "or a proper reverse function"
                    ),
                )
            )

        # FW-DJ-MIG-004: RunSQL without reverse_sql
        if name == "RunSQL" and (
            not _has_kw(op, "reverse_sql") or _kw_is_none(op, "reverse_sql")
        ):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=op.lineno,
                    column=op.col_offset,
                    severity=Severity.INFO,
                    rule_id="FW-DJ-MIG-004",
                    tool="framework-checks",
                    category=Category.QUALITY,
                    message=(
                        "RunSQL without reverse_sql. "
                        "This migration cannot be reversed."
                    ),
                    fix="Add reverse_sql= with the SQL to undo this operation",
                )
            )

        # FW-DJ-MIG-005: RemoveField / DeleteModel — data loss risk
        if name in ("RemoveField", "DeleteModel"):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=op.lineno,
                    column=op.col_offset,
                    severity=Severity.WARNING,
                    rule_id="FW-DJ-MIG-005",
                    tool="framework-checks",
                    category=Category.QUALITY,
                    message=(
                        f"{name} is a destructive operation that "
                        "causes data loss. Ensure this is intentional "
                        "and data has been backed up or migrated."
                    ),
                    fix=(
                        "Consider a two-step deployment: first stop using the "
                        "field/model, then remove it in a later release"
                    ),
                )
            )

        # FW-DJ-MIG-006: RenameField / RenameModel — coordination needed
        if name in ("RenameField", "RenameModel"):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=op.lineno,
                    column=op.col_offset,
                    severity=Severity.INFO,
                    rule_id="FW-DJ-MIG-006",
                    tool="framework-checks",
                    category=Category.QUALITY,
                    message=(
                        f"{name} requires careful deployment "
                        "coordination. Old code referencing the "
                        "previous name will break."
                    ),
                    fix=(
                        "Deploy in stages: add the new name, migrate code, "
                        "then remove the old name"
                    ),
                )
            )

        # FW-DJ-MIG-007: Adding unique constraint on existing field
        if name in ("AddField", "AlterField") and _field_adds_unique(op):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=op.lineno,
                    column=op.col_offset,
                    severity=Severity.WARNING,
                    rule_id="FW-DJ-MIG-007",
                    tool="framework-checks",
                    category=Category.QUALITY,
                    message=(
                        "Adding unique=True constraint. "
                        "This will fail if duplicate values already exist."
                    ),
                    fix=(
                        "Add a data migration first to deduplicate existing rows, "
                        "then add the unique constraint"
                    ),
                )
            )

    return diags


def _check_django_migrations(root: Path, files: list[Path]) -> list[Diagnostic]:
    """Lint all Django migration files in the project."""
    diags: list[Diagnostic] = []
    for mig_file in _find_migration_files(root, files):
        diags.extend(_check_django_migration_file(mig_file))
    return diags


# Each entry: (module, names_to_check, since_version, rule_id, message, fix)
_DJANGO_DEPRECATED_IMPORTS: list[
    tuple[str, tuple[str, ...], tuple[int, int], str, str, str]
] = [
    (
        "django.conf.urls",
        ("url",),
        (2, 0),
        "FW-DJ-DEP-001",
        "django.conf.urls.url() is deprecated since Django 2.0",
        "Use path() or re_path() from django.urls instead",
    ),
    (
        "django.utils.encoding",
        ("smart_text", "force_text"),
        (3, 0),
        "FW-DJ-DEP-002",
        "{name} is deprecated since Django 3.0",
        "Use smart_str/force_str from django.utils.encoding instead",
    ),
    (
        "django.utils.translation",
        ("ugettext", "ugettext_lazy", "ugettext_noop", "ungettext", "ungettext_lazy"),
        (3, 0),
        "FW-DJ-DEP-003",
        "{name} is deprecated since Django 3.0",
        "Use gettext/gettext_lazy/ngettext/ngettext_lazy instead",
    ),
    (
        "django.contrib.postgres.fields",
        ("JSONField",),
        (4, 0),
        "FW-DJ-DEP-007",
        "JSONField from django.contrib.postgres.fields is deprecated since Django 4.0",
        "Use django.db.models.JSONField instead (available since Django 3.1)",
    ),
    (
        "django.utils.timezone",
        ("utc",),
        (4, 1),
        "FW-DJ-DEP-008",
        "django.utils.timezone.utc is deprecated since Django 4.1",
        "Use datetime.timezone.utc from the standard library instead",
    ),
]


def _parse_django_version(version_str: str | None) -> tuple[int, int] | None:
    """Parse a Django version string like '4.2.7' into (4, 2)."""
    if not version_str:
        return None
    parts = version_str.split(".")
    try:
        return (int(parts[0]), int(parts[1])) if len(parts) >= 2 else None
    except (ValueError, IndexError):
        return None


def _check_django_deprecated_imports(
    f: Path, tree: ast.Module, django_version: tuple[int, int] | None
) -> list[Diagnostic]:
    """Check for deprecated Django imports based on detected version."""
    diags: list[Diagnostic] = []

    for node in ast.walk(tree):
        if not isinstance(node, ast.ImportFrom) or node.module is None:
            continue
        for entry in _DJANGO_DEPRECATED_IMPORTS:
            module, names, since, rule_id, msg_template, fix = entry
            # Skip if we know the Django version and it's older than when
            # the deprecation was introduced
            if django_version and django_version < since:
                continue
            if node.module != module:
                continue
            for alias in node.names:
                if alias.name in names:
                    msg = msg_template.format(name=alias.name)
                    diags.append(
                        Diagnostic(
                            file_path=f,
                            line=node.lineno,
                            column=node.col_offset,
                            severity=Severity.WARNING,
                            rule_id=rule_id,
                            tool="framework-checks",
                            category=Category.QUALITY,
                            message=msg,
                            fix=fix,
                        )
                    )
    return diags


def _check_django_code_deprecated(
    f: Path, django_version: tuple[int, int] | None
) -> list[Diagnostic]:
    """Check a single Django file for deprecated patterns and URL issues."""
    tree = parse_file(f)
    if tree is None:
        return []
    diags: list[Diagnostic] = []
    diags.extend(_check_django_deprecated_imports(f, tree, django_version))
    return diags


def _is_url_file(f: Path) -> bool:
    """Check if a file is likely a Django URL configuration file."""
    return f.name == "urls.py" or f.stem.endswith("_urls") or f.stem.endswith("urls")


def _check_django_urls(f: Path) -> list[Diagnostic]:
    """Check Django URL configuration patterns."""
    if not _is_url_file(f):
        return []
    tree = parse_file(f)
    if tree is None:
        return []

    diags: list[Diagnostic] = []
    assignments = extract_assignments(tree)

    # FW-DJ-URL-003: empty urlpatterns
    urlpatterns = assignments.get("urlpatterns")
    if urlpatterns is not None:
        up_node = urlpatterns.node
        if isinstance(up_node, (ast.List, ast.Tuple)) and not up_node.elts:
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=urlpatterns.line,
                    column=0,
                    severity=Severity.WARNING,
                    rule_id="FW-DJ-URL-003",
                    tool="framework-checks",
                    category=Category.QUALITY,
                    message=(
                        "urlpatterns is empty. " "This URL configuration has no routes."
                    ),
                    fix="Add URL patterns or remove this urls.py if unused",
                )
            )

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue

        call_name = _op_name(node)

        # FW-DJ-URL-002: url() usage (deprecated)
        if call_name == "url":
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.INFO,
                    rule_id="FW-DJ-URL-002",
                    tool="framework-checks",
                    category=Category.QUALITY,
                    message=(
                        "url() is deprecated. "
                        "Use path() for simple routes or re_path() for regex."
                    ),
                    fix="Replace url() with path() or re_path() from django.urls",
                )
            )

        # FW-DJ-URL-004: re_path with simple pattern that could be path()
        if call_name == "re_path" and node.args:
            first_arg = node.args[0]
            pattern = get_string_value(first_arg)
            if pattern and _regex_is_simple_path(pattern):
                diags.append(
                    Diagnostic(
                        file_path=f,
                        line=node.lineno,
                        column=node.col_offset,
                        severity=Severity.INFO,
                        rule_id="FW-DJ-URL-004",
                        tool="framework-checks",
                        category=Category.QUALITY,
                        message=(
                            f"re_path(r'{pattern}') uses a simple pattern "
                            "that could be expressed with path()."
                        ),
                        fix="Use path() instead of re_path() for simple URL patterns",
                    )
                )

    return diags


def _regex_is_simple_path(pattern: str) -> bool:
    """Check if a regex URL pattern is simple enough for path().

    Simple patterns only contain literal path segments, optional leading ^
    and trailing $, with no regex metacharacters.
    """
    cleaned = pattern.strip()
    if cleaned.startswith("^"):
        cleaned = cleaned[1:]
    if cleaned.endswith("$"):
        cleaned = cleaned[:-1]
    # If the remaining pattern has no regex special chars, it's simple
    if not cleaned:
        return False
    return bool(re.fullmatch(r"[a-zA-Z0-9/_-]+/?", cleaned))
