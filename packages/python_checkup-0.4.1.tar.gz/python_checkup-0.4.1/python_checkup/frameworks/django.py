from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from python_checkup.analyzers.vulture_whitelists import DJANGO_WHITELIST, WhitelistEntry
from python_checkup.detection import (
    DetectionContext,
    FrameworkCategory,
    FrameworkInfo,
    _detect_django,
)
from python_checkup.frameworks import StubsInfo

if TYPE_CHECKING:
    from python_checkup.models import Diagnostic


class DjangoPlugin:
    """Built-in Django framework support."""

    @property
    def name(self) -> str:
        return "django"

    @property
    def category(self) -> FrameworkCategory:
        return FrameworkCategory.WEB

    def detect(self, context: DetectionContext) -> tuple[float, str | None]:
        return _detect_django(context)

    def get_vulture_whitelist(self) -> list[WhitelistEntry]:
        return list(DJANGO_WHITELIST)

    def get_ruff_rules(self) -> list[str]:
        return ["DJ", "S610", "S611"]

    def get_implicit_dependencies(self) -> set[str]:
        from python_checkup.analyzers.deptry import _FRAMEWORK_IMPLICIT_DEPS

        return set(_FRAMEWORK_IMPLICIT_DEPS.get("django", set()))

    def check(
        self,
        root: Path,
        files: list[Path],
        framework: FrameworkInfo,
    ) -> list[Diagnostic]:
        from python_checkup.analyzers.django_checks import check_django

        return check_django(root, files, framework)

    def get_stubs_info(self) -> StubsInfo:
        return StubsInfo(
            stubs_package="django-stubs",
            mypy_plugin="mypy_django_plugin.main",
            config_keys={"django_settings_module": "myproject.settings"},
        )
