from __future__ import annotations

import asyncio
import dataclasses
import json
import logging
import re
import secrets
import shutil
import subprocess
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import TYPE_CHECKING, Any
from urllib.parse import parse_qs, urlparse

from rich.console import Console

if TYPE_CHECKING:
    from python_checkup.config import CheckupConfig
    from python_checkup.models import HealthReport
    from python_checkup.plan import ScanPlan

err_console = Console(stderr=True)

logger = logging.getLogger("python_checkup.web")

_SENTINEL = object()  # sentinel for "key not present in JSON body"


@dataclasses.dataclass
class RunContext:
    """Everything needed to re-run analysis from the web UI."""

    project_root: Path
    config: CheckupConfig
    files: list[Path]
    plan: ScanPlan
    no_cache: bool = False
    diff_base: str | None = None
    pr_number: int | None = None


def _serialize_report(report: HealthReport) -> str:
    """Convert a HealthReport to JSON, handling Path and Enum values."""

    def _default(obj: object) -> object:
        from enum import Enum
        from pathlib import Path as _Path

        if isinstance(obj, _Path):
            return str(obj)
        if isinstance(obj, Enum):
            return obj.value
        raise TypeError(f"Object of type {type(obj)} is not JSON serializable")

    return json.dumps(dataclasses.asdict(report), default=_default)


class ReportServer:
    """Local HTTP server that serves the interactive HTML report."""

    def __init__(
        self,
        report: HealthReport | None = None,
        port: int = 8765,
        run_context: RunContext | None = None,
    ):
        self.report = report
        self.port = port
        self.token = secrets.token_urlsafe(32)
        self.run_context = run_context
        self._server: HTTPServer | None = None
        self._lock = threading.Lock()

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.port}?token={self.token}"

    def start(self, open_browser: bool = True) -> None:
        """Start the server and optionally open a browser."""
        handler = _make_handler(self)
        self._server = HTTPServer(("127.0.0.1", self.port), handler)

        if open_browser:
            import webbrowser

            threading.Timer(0.5, webbrowser.open, args=[self.url]).start()

        err_console.print(
            f"\n[bold green]Report server running at:[/bold green] {self.url}"
        )
        err_console.print("[dim]Press Ctrl+C to stop.[/dim]\n")

        try:
            self._server.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            self._server.server_close()
            err_console.print("\n[dim]Server stopped.[/dim]")

    def rerun_analysis(
        self,
        analyzer_names: list[str],
        diff_base: str | None = None,
        pr_files: list[Path] | None = None,
    ) -> tuple[HealthReport, str | None]:
        """Re-run analysis; return (report, effective_diff_base)."""
        if self.run_context is None:
            msg = "No run context available for re-run"
            raise RuntimeError(msg)

        from python_checkup.analyzer_catalog import ANALYZER_CATALOG
        from python_checkup.models import Category
        from python_checkup.plan import build_scan_plan
        from python_checkup.runner import run_analysis

        ctx = self.run_context

        # Caller-supplied diff_base overrides RunContext value.
        # Passing None from the UI means "full scan" (clear diff mode).
        effective_diff_base = diff_base  # already resolved by the handler

        requested = set(analyzer_names)
        skip_analyzers = set(ANALYZER_CATALOG.keys()) - requested

        # Derive categories from selected analyzers
        selected_categories: set[Category] = set()
        for name in requested:
            if name in ANALYZER_CATALOG:
                selected_categories.update(ANALYZER_CATALOG[name].categories)

        plan = build_scan_plan(
            profile=ctx.plan.profile,
            only_categories=frozenset(selected_categories),
            skip_categories=frozenset(),
            include_optional=True,
            apply_fixes=ctx.plan.apply_fixes,
            show_fix_suggestions=ctx.plan.show_fix_suggestions,
            diff_mode=effective_diff_base is not None,
            type_backend=ctx.plan.type_backend,
        )

        # For PR reruns, use the pre-resolved file list.
        # For diff reruns, discover only changed files; otherwise use full file list.
        if pr_files is not None:
            rerun_files = pr_files
        elif effective_diff_base is not None:
            from python_checkup.diff import get_changed_files

            rerun_files = get_changed_files(ctx.project_root, base=effective_diff_base)
        else:
            rerun_files = ctx.files

        report = asyncio.run(
            run_analysis(
                project_root=ctx.project_root,
                config=ctx.config,
                files=rerun_files,
                skip_analyzers=skip_analyzers,
                quiet=True,
                no_cache=ctx.no_cache,
                plan=plan,
                diff_base=effective_diff_base,
            )
        )

        with self._lock:
            self.report = report

        return report, effective_diff_base


def _make_handler(server: ReportServer) -> type[BaseHTTPRequestHandler]:
    """Create a request handler class bound to the server instance."""

    # Build analyzer catalog info for the UI
    from python_checkup.analyzer_catalog import ANALYZER_CATALOG

    catalog_info = {
        name: {
            "name": name,
            "categories": [c.value for c in info.categories],
            "optional": info.optional,
        }
        for name, info in ANALYZER_CATALOG.items()
    }

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format: str, *args: object) -> None:  # noqa: A002
            pass

        def _check_token(self) -> bool:
            token = self.headers.get("X-Session-Token")
            if token != server.token:
                self._json_error(403, "Invalid or missing session token")
                return False
            return True

        def _json_response(self, data: dict[str, Any], status: int = 200) -> None:
            body = json.dumps(data, default=str).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _json_error(self, status: int, message: str) -> None:
            self._json_response({"error": message}, status)

        def _read_json_body(self) -> dict[str, Any] | None:
            length = int(self.headers.get("Content-Length", 0))
            if length == 0:
                self._json_error(400, "Empty request body")
                return None
            try:
                result: dict[str, Any] = json.loads(self.rfile.read(length))
                return result
            except json.JSONDecodeError:
                self._json_error(400, "Invalid JSON")
                return None

        def do_GET(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)

            if parsed.path in ("/", ""):
                query = parse_qs(parsed.query)
                url_token = query.get("token", [None])[0]
                if url_token != server.token:
                    self.send_response(403)
                    self.send_header("Content-Type", "text/plain")
                    self.end_headers()
                    self.wfile.write(b"Invalid session token")
                    return

                from python_checkup.web.template import render_report_html

                report_json = (
                    _serialize_report(server.report)
                    if server.report is not None
                    else "null"
                )
                can_rerun = server.run_context is not None
                initial_diff_base = (
                    server.run_context.diff_base
                    if server.run_context is not None
                    else None
                )
                initial_pr_number = (
                    server.run_context.pr_number
                    if server.run_context is not None
                    else None
                )
                html = render_report_html(
                    report_json,
                    server.token,
                    catalog_json=json.dumps(catalog_info),
                    can_rerun=can_rerun,
                    diff_base=initial_diff_base,
                    pr_number=initial_pr_number,
                )
                body = html.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            elif parsed.path == "/api/config":
                if not self._check_token():
                    return
                if server.run_context is None:
                    self._json_error(400, "No run context available")
                    return
                cfg = server.run_context.config
                self._json_response(
                    {
                        "ignore_dirs": cfg.ignore_dirs,
                        "ignore_files": cfg.ignore_files,
                        "ignore_patterns": cfg.ignore_patterns,
                        "focus": cfg.focus,
                        "requirements_file": cfg.requirements_file,
                    }
                )
            elif parsed.path == "/api/dirs":
                if not self._check_token():
                    return
                if server.run_context is None:
                    self._json_error(400, "No run context available")
                    return
                root = server.run_context.project_root
                dirs: list[str] = []
                # Prefer git ls-tree so .gitignore is respected
                _git = shutil.which("git")
                try:
                    if not _git:
                        raise RuntimeError("git not found")
                    result = subprocess.run(  # noqa: S603  # nosec B603 B607
                        [
                            _git,
                            "ls-tree",
                            "-r",
                            "--name-only",
                            "-d",
                            "HEAD",
                        ],
                        cwd=root,
                        capture_output=True,
                        text=True,
                        timeout=5,
                    )
                    if result.returncode == 0:
                        dirs = sorted(
                            {
                                line.strip()
                                for line in result.stdout.splitlines()
                                if line.strip()
                            }
                        )
                    else:
                        raise RuntimeError("not a git repo")
                except Exception:
                    _skip = {
                        "__pycache__",
                        "node_modules",
                        ".git",
                        ".venv",
                        "venv",
                        ".tox",
                        ".mypy_cache",
                        ".ruff_cache",
                    }
                    for child in sorted(root.rglob("*")):
                        if child.is_dir() and not any(
                            p.startswith(".") or p in _skip
                            for p in child.relative_to(root).parts
                        ):
                            dirs.append(str(child.relative_to(root)))
                    dirs = sorted(dirs)
                self._json_response({"dirs": dirs})
            elif parsed.path == "/api/branches":
                if not self._check_token():
                    return
                if server.run_context is None:
                    self._json_error(400, "No run context available")
                    return
                root = server.run_context.project_root
                branches: list[str] = []
                _git = shutil.which("git")
                if _git:
                    try:
                        result = subprocess.run(  # noqa: S603  # nosec B603 B607
                            [_git, "branch", "-a", "--format=%(refname:short)"],
                            cwd=root,
                            capture_output=True,
                            text=True,
                            timeout=5,
                        )
                        if result.returncode == 0:
                            seen: set[str] = set()
                            for line in result.stdout.splitlines():
                                b = line.strip()
                                if not b or b.startswith("origin/HEAD"):
                                    continue
                                # Strip origin/ prefix for remote branches
                                short = b.removeprefix("origin/")
                                if short not in seen:
                                    seen.add(short)
                                    branches.append(short)
                            branches.sort()
                    except Exception as exc:
                        logger.debug("Failed to list git branches: %s", exc)
                self._json_response({"branches": branches})
            else:
                self.send_response(404)
                self.send_header("Content-Type", "text/plain")
                self.end_headers()
                self.wfile.write(b"Not found")

        def do_POST(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)

            if not self._check_token():
                return

            if parsed.path == "/api/config/update":
                if server.run_context is None:
                    self._json_error(400, "No run context available")
                    return
                body = self._read_json_body()
                if body is None:
                    return

                cfg = server.run_context.config

                raw_dirs = body.get("ignore_dirs", _SENTINEL)
                if raw_dirs is not _SENTINEL:
                    if not isinstance(raw_dirs, list):
                        self._json_error(400, "ignore_dirs must be a list")
                        return
                    cfg.ignore_dirs = [str(x) for x in raw_dirs]

                raw_files = body.get("ignore_files", _SENTINEL)
                if raw_files is not _SENTINEL:
                    if not isinstance(raw_files, list):
                        self._json_error(400, "ignore_files must be a list")
                        return
                    cfg.ignore_files = [str(x) for x in raw_files]

                raw_patterns = body.get("ignore_patterns", _SENTINEL)
                if raw_patterns is not _SENTINEL:
                    if not isinstance(raw_patterns, list):
                        self._json_error(400, "ignore_patterns must be a list")
                        return
                    cfg.ignore_patterns = [str(x) for x in raw_patterns]

                raw_focus = body.get("focus", _SENTINEL)
                if raw_focus is not _SENTINEL:
                    if isinstance(raw_focus, list):
                        cfg.focus = [str(x).strip() for x in raw_focus if x]
                    elif raw_focus:
                        cfg.focus = [str(raw_focus).strip()]
                    else:
                        cfg.focus = []

                raw_req_file = body.get("requirements_file", _SENTINEL)
                if raw_req_file is not _SENTINEL:
                    if raw_req_file and isinstance(raw_req_file, str):
                        cfg.requirements_file = raw_req_file.strip()
                    else:
                        cfg.requirements_file = None

                # Re-discover files with updated config
                from python_checkup.discovery import discover_python_files

                ctx = server.run_context
                new_files = discover_python_files(
                    ctx.project_root,
                    ignore_patterns=cfg.ignore_files,
                    ignore_dirs=cfg.ignore_dirs,
                    ignore_extra_patterns=cfg.ignore_patterns,
                    focus=cfg.focus,
                )
                ctx.files = new_files

                self._json_response(
                    {
                        "ignore_dirs": cfg.ignore_dirs,
                        "ignore_files": cfg.ignore_files,
                        "ignore_patterns": cfg.ignore_patterns,
                        "focus": cfg.focus,
                        "requirements_file": cfg.requirements_file,
                        "file_count": len(new_files),
                    }
                )

            elif parsed.path == "/api/rerun":
                if server.run_context is None:
                    self._json_error(400, "Re-run not available")
                    return

                body = self._read_json_body()
                if body is None:
                    return

                analyzers = body.get("analyzers", [])
                if not analyzers or not isinstance(analyzers, list):
                    self._json_error(400, "Provide a non-empty 'analyzers' list")
                    return

                # Optional pr_number for PR-based analysis
                raw_pr = body.get("pr_number")
                pr_files: list[Path] | None = None
                pr_base: str | None = None
                if raw_pr is not None:
                    if not isinstance(raw_pr, int) or raw_pr <= 0:
                        self._json_error(400, "pr_number must be a positive integer")
                        return
                    from python_checkup.diff import GitError, get_pr_changed_files

                    try:
                        pr_files, pr_base = get_pr_changed_files(
                            server.run_context.project_root,
                            pr_number=raw_pr,
                        )
                    except GitError as e:
                        self._json_error(400, f"Failed to fetch PR #{raw_pr}: {e}")
                        return

                # Optional diff_base override from the UI
                raw_diff_base = body.get("diff_base", _SENTINEL)
                if pr_files is not None:
                    # PR mode — use the detected base
                    diff_base_override = pr_base
                elif raw_diff_base is _SENTINEL:
                    # Key absent — inherit RunContext diff_base
                    diff_base_override = server.run_context.diff_base
                elif raw_diff_base is None:
                    # Explicit null — full scan
                    diff_base_override = None
                elif isinstance(raw_diff_base, str):
                    if not re.fullmatch(r"[\w./~-]{1,200}", raw_diff_base):
                        self._json_error(400, "Invalid diff_base value")
                        return
                    diff_base_override = raw_diff_base
                else:
                    self._json_error(400, "diff_base must be a string or null")
                    return

                known = set(catalog_info.keys())
                unknown = set(analyzers) - known
                if unknown:
                    self._json_error(
                        400,
                        f"Unknown analyzer(s): {', '.join(sorted(unknown))}",
                    )
                    return

                try:
                    if pr_files is not None:
                        diff_label = f"PR #{raw_pr} (base: {pr_base})"
                    else:
                        diff_label = diff_base_override or "(none)"
                    err_console.print(
                        f"[bold]Re-running with:[/bold] {', '.join(analyzers)}"
                        f" | diff={diff_label}"
                    )
                    report, effective_diff_base = server.rerun_analysis(
                        analyzers,
                        diff_base=diff_base_override,
                        pr_files=pr_files,
                    )
                    report_json = _serialize_report(report)
                    resp_data: dict[str, Any] = {
                        "report": json.loads(report_json),
                        "diff_base": effective_diff_base,
                        "diff_mode": effective_diff_base is not None,
                    }
                    if pr_files is not None:
                        resp_data["pr_number"] = raw_pr
                        resp_data["pr_file_count"] = len(pr_files)
                    self._json_response(resp_data)
                except Exception as e:
                    self._json_error(500, f"Analysis failed: {e}")
            else:
                self._json_error(404, "Not found")

    return Handler


def serve_report(
    report: HealthReport | None = None,
    port: int = 8765,
    run_context: RunContext | None = None,
) -> None:
    """Serve the interactive HTML report and open it in the browser."""
    server = ReportServer(report, port=port, run_context=run_context)
    server.start(open_browser=True)
