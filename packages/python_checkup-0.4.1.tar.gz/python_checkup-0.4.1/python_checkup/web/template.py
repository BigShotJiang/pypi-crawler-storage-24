from __future__ import annotations

from pathlib import Path

_STATIC_DIR = Path(__file__).parent / "static"
_TEMPLATE_CACHE: str | None = None


def render_report_html(
    report_json: str,
    session_token: str,
    catalog_json: str = "{}",
    can_rerun: bool = False,
    diff_base: str | None = None,
    pr_number: int | None = None,
) -> str:
    """Return the complete HTML page with report data and session token embedded."""
    global _TEMPLATE_CACHE  # noqa: PLW0603
    if _TEMPLATE_CACHE is None:
        template_path = _STATIC_DIR / "index.html"
        _TEMPLATE_CACHE = template_path.read_text(encoding="utf-8")

    return (
        _TEMPLATE_CACHE.replace("{{ REPORT_DATA }}", report_json)
        .replace("{{SESSION_TOKEN}}", session_token)
        .replace("{{ ANALYZER_CATALOG }}", catalog_json)
        .replace("{{ CAN_RERUN }}", "true" if can_rerun else "false")
        .replace("{{DIFF_BASE}}", diff_base or "")
        .replace("{{PR_NUMBER}}", str(pr_number) if pr_number else "")
    )
