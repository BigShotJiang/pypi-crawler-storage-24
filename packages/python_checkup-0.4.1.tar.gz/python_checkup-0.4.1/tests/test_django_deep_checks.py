"""Tests for Django deep analysis.

Covers migration linting, deprecated patterns, URL checks, djlint.
"""

from __future__ import annotations

import asyncio
from collections.abc import Generator
from pathlib import Path
from unittest.mock import patch

import pytest

from python_checkup.analysis_request import AnalysisRequest
from python_checkup.analyzers.framework_checks import FrameworkCheckAnalyzer
from python_checkup.config import CheckupConfig
from python_checkup.detection import FrameworkCategory, FrameworkInfo, FrameworkStack
from python_checkup.models import Category, Severity


def _make_django_request(
    tmp_path: Path,
    files: list[Path] | None = None,
    django_version: str | None = None,
) -> AnalysisRequest:
    fw = FrameworkInfo(
        name="django",
        version=django_version,
        confidence=0.9,
        category=FrameworkCategory.WEB,
    )
    stack = FrameworkStack(
        primary=fw,
        companions=[],
        all_frameworks=[fw],
    )
    return AnalysisRequest(
        project_root=tmp_path,
        files=files or list(tmp_path.rglob("*.py")),
        config=CheckupConfig(),
        categories={Category.SECURITY, Category.QUALITY},
        profile="default",
        framework="django",
        framework_stack=stack,
        no_cache=True,
    )


@pytest.fixture
def analyzer() -> FrameworkCheckAnalyzer:
    return FrameworkCheckAnalyzer()


@pytest.fixture
def event_loop() -> Generator[asyncio.AbstractEventLoop, None, None]:
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


# ---------------------------------------------------------------------------
# Migration linting
# ---------------------------------------------------------------------------


class TestMigrationLinting:
    @pytest.mark.asyncio
    async def test_mig_001_add_field_non_nullable_no_default(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        mig_dir = tmp_path / "myapp" / "migrations"
        mig_dir.mkdir(parents=True)
        (mig_dir / "__init__.py").write_text("")
        (mig_dir / "0001_initial.py").write_text(
            "from django.db import migrations, models\n\n"
            "class Migration(migrations.Migration):\n"
            "    operations = [\n"
            "        migrations.AddField(\n"
            "            model_name='mymodel',\n"
            "            name='title',\n"
            "            field=models.CharField(max_length=200),\n"
            "        ),\n"
            "    ]\n"
        )
        request = _make_django_request(tmp_path)
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-MIG-001" in rule_ids

    @pytest.mark.asyncio
    async def test_mig_001_not_triggered_with_default(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        mig_dir = tmp_path / "myapp" / "migrations"
        mig_dir.mkdir(parents=True)
        (mig_dir / "__init__.py").write_text("")
        (mig_dir / "0001_initial.py").write_text(
            "from django.db import migrations, models\n\n"
            "class Migration(migrations.Migration):\n"
            "    operations = [\n"
            "        migrations.AddField(\n"
            "            model_name='mymodel',\n"
            "            name='title',\n"
            "            field=models.CharField("
            "max_length=200, default=''),\n"
            "        ),\n"
            "    ]\n"
        )
        request = _make_django_request(tmp_path)
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-MIG-001" not in rule_ids

    @pytest.mark.asyncio
    async def test_mig_001_not_triggered_with_null_true(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        mig_dir = tmp_path / "myapp" / "migrations"
        mig_dir.mkdir(parents=True)
        (mig_dir / "__init__.py").write_text("")
        (mig_dir / "0001_initial.py").write_text(
            "from django.db import migrations, models\n\n"
            "class Migration(migrations.Migration):\n"
            "    operations = [\n"
            "        migrations.AddField(\n"
            "            model_name='mymodel',\n"
            "            name='title',\n"
            "            field=models.CharField("
            "max_length=200, null=True),\n"
            "        ),\n"
            "    ]\n"
        )
        request = _make_django_request(tmp_path)
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-MIG-001" not in rule_ids

    @pytest.mark.asyncio
    async def test_mig_001_not_triggered_for_boolean_field(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        mig_dir = tmp_path / "myapp" / "migrations"
        mig_dir.mkdir(parents=True)
        (mig_dir / "__init__.py").write_text("")
        (mig_dir / "0001_initial.py").write_text(
            "from django.db import migrations, models\n\n"
            "class Migration(migrations.Migration):\n"
            "    operations = [\n"
            "        migrations.AddField(\n"
            "            model_name='mymodel',\n"
            "            name='is_active',\n"
            "            field=models.BooleanField(),\n"
            "        ),\n"
            "    ]\n"
        )
        request = _make_django_request(tmp_path)
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-MIG-001" not in rule_ids

    @pytest.mark.asyncio
    async def test_mig_002_alter_field_to_non_nullable(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        mig_dir = tmp_path / "myapp" / "migrations"
        mig_dir.mkdir(parents=True)
        (mig_dir / "__init__.py").write_text("")
        (mig_dir / "0002_alter.py").write_text(
            "from django.db import migrations, models\n\n"
            "class Migration(migrations.Migration):\n"
            "    operations = [\n"
            "        migrations.AlterField(\n"
            "            model_name='mymodel',\n"
            "            name='title',\n"
            "            field=models.CharField(max_length=200),\n"
            "        ),\n"
            "    ]\n"
        )
        request = _make_django_request(tmp_path)
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-MIG-002" in rule_ids

    @pytest.mark.asyncio
    async def test_mig_003_run_python_no_reverse(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        mig_dir = tmp_path / "myapp" / "migrations"
        mig_dir.mkdir(parents=True)
        (mig_dir / "__init__.py").write_text("")
        (mig_dir / "0003_data.py").write_text(
            "from django.db import migrations\n\n"
            "def forwards(apps, schema_editor):\n"
            "    pass\n\n"
            "class Migration(migrations.Migration):\n"
            "    operations = [\n"
            "        migrations.RunPython(forwards),\n"
            "    ]\n"
        )
        request = _make_django_request(tmp_path)
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-MIG-003" in rule_ids

    @pytest.mark.asyncio
    async def test_mig_003_not_triggered_with_reverse(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        mig_dir = tmp_path / "myapp" / "migrations"
        mig_dir.mkdir(parents=True)
        (mig_dir / "__init__.py").write_text("")
        (mig_dir / "0003_data.py").write_text(
            "from django.db import migrations\n\n"
            "def forwards(apps, schema_editor):\n"
            "    pass\n\n"
            "def backwards(apps, schema_editor):\n"
            "    pass\n\n"
            "class Migration(migrations.Migration):\n"
            "    operations = [\n"
            "        migrations.RunPython("
            "forwards, reverse_code=backwards),\n"
            "    ]\n"
        )
        request = _make_django_request(tmp_path)
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-MIG-003" not in rule_ids

    @pytest.mark.asyncio
    async def test_mig_004_run_sql_no_reverse(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        mig_dir = tmp_path / "myapp" / "migrations"
        mig_dir.mkdir(parents=True)
        (mig_dir / "__init__.py").write_text("")
        (mig_dir / "0004_sql.py").write_text(
            "from django.db import migrations\n\n"
            "class Migration(migrations.Migration):\n"
            "    operations = [\n"
            "        migrations.RunSQL('CREATE INDEX ...'),\n"
            "    ]\n"
        )
        request = _make_django_request(tmp_path)
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-MIG-004" in rule_ids

    @pytest.mark.asyncio
    async def test_mig_005_remove_field(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        mig_dir = tmp_path / "myapp" / "migrations"
        mig_dir.mkdir(parents=True)
        (mig_dir / "__init__.py").write_text("")
        (mig_dir / "0005_remove.py").write_text(
            "from django.db import migrations\n\n"
            "class Migration(migrations.Migration):\n"
            "    operations = [\n"
            "        migrations.RemoveField(\n"
            "            model_name='mymodel',\n"
            "            name='old_field',\n"
            "        ),\n"
            "    ]\n"
        )
        request = _make_django_request(tmp_path)
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-MIG-005" in rule_ids

    @pytest.mark.asyncio
    async def test_mig_005_delete_model(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        mig_dir = tmp_path / "myapp" / "migrations"
        mig_dir.mkdir(parents=True)
        (mig_dir / "__init__.py").write_text("")
        (mig_dir / "0005_delete.py").write_text(
            "from django.db import migrations\n\n"
            "class Migration(migrations.Migration):\n"
            "    operations = [\n"
            "        migrations.DeleteModel(\n"
            "            name='OldModel',\n"
            "        ),\n"
            "    ]\n"
        )
        request = _make_django_request(tmp_path)
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-MIG-005" in rule_ids

    @pytest.mark.asyncio
    async def test_mig_006_rename_field(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        mig_dir = tmp_path / "myapp" / "migrations"
        mig_dir.mkdir(parents=True)
        (mig_dir / "__init__.py").write_text("")
        (mig_dir / "0006_rename.py").write_text(
            "from django.db import migrations\n\n"
            "class Migration(migrations.Migration):\n"
            "    operations = [\n"
            "        migrations.RenameField(\n"
            "            model_name='mymodel',\n"
            "            old_name='title',\n"
            "            new_name='name',\n"
            "        ),\n"
            "    ]\n"
        )
        request = _make_django_request(tmp_path)
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-MIG-006" in rule_ids

    @pytest.mark.asyncio
    async def test_mig_007_add_unique_constraint(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        mig_dir = tmp_path / "myapp" / "migrations"
        mig_dir.mkdir(parents=True)
        (mig_dir / "__init__.py").write_text("")
        (mig_dir / "0007_unique.py").write_text(
            "from django.db import migrations, models\n\n"
            "class Migration(migrations.Migration):\n"
            "    operations = [\n"
            "        migrations.AlterField(\n"
            "            model_name='mymodel',\n"
            "            name='email',\n"
            "            field=models.CharField("
            "max_length=200, unique=True),\n"
            "        ),\n"
            "    ]\n"
        )
        request = _make_django_request(tmp_path)
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-MIG-007" in rule_ids


# ---------------------------------------------------------------------------
# Deprecated pattern detection
# ---------------------------------------------------------------------------


class TestDeprecatedPatterns:
    @pytest.mark.asyncio
    async def test_dep_001_url_import(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "urls.py").write_text(
            "from django.conf.urls import url\n" "urlpatterns = [url(r'^$', home)]\n"
        )
        request = _make_django_request(tmp_path, django_version="4.2.0")
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-DEP-001" in rule_ids

    @pytest.mark.asyncio
    async def test_dep_001_not_fired_on_old_django(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "urls.py").write_text(
            "from django.conf.urls import url\n" "urlpatterns = [url(r'^$', home)]\n"
        )
        request = _make_django_request(tmp_path, django_version="1.11.0")
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-DEP-001" not in rule_ids

    @pytest.mark.asyncio
    async def test_dep_001_fired_when_version_unknown(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "views.py").write_text("from django.conf.urls import url\n")
        request = _make_django_request(tmp_path)
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-DEP-001" in rule_ids

    @pytest.mark.asyncio
    async def test_dep_002_smart_text(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "utils.py").write_text(
            "from django.utils.encoding import smart_text\n"
        )
        request = _make_django_request(tmp_path, django_version="4.0.0")
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-DEP-002" in rule_ids

    @pytest.mark.asyncio
    async def test_dep_003_ugettext_lazy(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "models.py").write_text(
            "from django.utils.translation import ugettext_lazy\n"
        )
        request = _make_django_request(tmp_path, django_version="3.2.0")
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-DEP-003" in rule_ids

    @pytest.mark.asyncio
    async def test_dep_007_postgres_jsonfield(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "models.py").write_text(
            "from django.contrib.postgres.fields import JSONField\n"
        )
        request = _make_django_request(tmp_path, django_version="4.0.0")
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-DEP-007" in rule_ids

    @pytest.mark.asyncio
    async def test_dep_008_timezone_utc(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "utils.py").write_text("from django.utils.timezone import utc\n")
        request = _make_django_request(tmp_path, django_version="4.2.0")
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-DEP-008" in rule_ids

    @pytest.mark.asyncio
    async def test_dep_008_not_fired_on_old_version(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "utils.py").write_text("from django.utils.timezone import utc\n")
        request = _make_django_request(tmp_path, django_version="4.0.0")
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-DEP-008" not in rule_ids


# ---------------------------------------------------------------------------
# URL configuration checks
# ---------------------------------------------------------------------------


class TestURLChecks:
    @pytest.mark.asyncio
    async def test_url_002_deprecated_url_call(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "urls.py").write_text(
            "from django.conf.urls import url\n"
            "urlpatterns = [\n"
            "    url(r'^home/$', home_view),\n"
            "]\n"
        )
        request = _make_django_request(tmp_path)
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-URL-002" in rule_ids

    @pytest.mark.asyncio
    async def test_url_003_empty_urlpatterns(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "urls.py").write_text("urlpatterns = []\n")
        request = _make_django_request(tmp_path)
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-URL-003" in rule_ids

    @pytest.mark.asyncio
    async def test_url_003_not_triggered_with_routes(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "urls.py").write_text(
            "from django.urls import path\n"
            "urlpatterns = [\n"
            "    path('home/', home_view),\n"
            "]\n"
        )
        request = _make_django_request(tmp_path)
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-URL-003" not in rule_ids

    @pytest.mark.asyncio
    async def test_url_004_simple_re_path(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "urls.py").write_text(
            "from django.urls import re_path\n"
            "urlpatterns = [\n"
            "    re_path(r'^articles/$', articles_view),\n"
            "]\n"
        )
        request = _make_django_request(tmp_path)
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-URL-004" in rule_ids

    @pytest.mark.asyncio
    async def test_url_004_not_triggered_for_complex_regex(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "urls.py").write_text(
            "from django.urls import re_path\n"
            "urlpatterns = [\n"
            "    re_path(r'^articles/(?P<pk>\\d+)/$', "
            "article_detail),\n"
            "]\n"
        )
        request = _make_django_request(tmp_path)
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-URL-004" not in rule_ids

    @pytest.mark.asyncio
    async def test_url_checks_only_on_url_files(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "views.py").write_text("urlpatterns = []\n")
        request = _make_django_request(tmp_path)
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-URL-003" not in rule_ids


# ---------------------------------------------------------------------------
# djlint analyzer (mocked subprocess)
# ---------------------------------------------------------------------------


class TestDjlintAnalyzer:
    @pytest.mark.asyncio
    async def test_parse_djlint_output(self) -> None:
        from python_checkup.analyzers.djlint import _parse_djlint_output

        output = (
            "templates/base.html:10:0: H006 "
            "Img tag should have height and width attributes.\n"
            "templates/base.html:15:4: D004 "
            "(Django) Static urls should follow {%% static path/to/file %%} pattern.\n"
            "templates/form.html:3:0: T001 "
            "Variables should be wrapped in a single whitespace.\n"
        )
        diags = _parse_djlint_output(output)
        assert len(diags) == 3
        assert diags[0].rule_id == "H006"
        assert diags[0].severity == Severity.INFO
        assert diags[0].tool == "djlint"
        assert diags[0].line == 10
        assert diags[1].rule_id == "D004"
        assert diags[2].rule_id == "T001"

    @pytest.mark.asyncio
    async def test_djlint_not_available_returns_empty(self) -> None:
        from python_checkup.analyzers.djlint import DjlintAnalyzer

        analyzer = DjlintAnalyzer()
        with patch("shutil.which", return_value=None):
            assert await analyzer.is_available() is False

    @pytest.mark.asyncio
    async def test_djlint_skips_non_django_projects(self, tmp_path: Path) -> None:
        from python_checkup.analyzers.djlint import DjlintAnalyzer

        analyzer = DjlintAnalyzer()
        fw = FrameworkInfo(
            name="flask",
            version=None,
            confidence=0.9,
            category=FrameworkCategory.WEB,
        )
        stack = FrameworkStack(primary=fw, companions=[], all_frameworks=[fw])
        request = AnalysisRequest(
            project_root=tmp_path,
            files=[],
            config=CheckupConfig(),
            categories={Category.QUALITY},
            profile="default",
            framework="flask",
            framework_stack=stack,
            no_cache=True,
        )
        diags = await analyzer.analyze(request)
        assert diags == []

    @pytest.mark.asyncio
    async def test_parse_empty_output(self) -> None:
        from python_checkup.analyzers.djlint import _parse_djlint_output

        assert _parse_djlint_output("") == []
        assert _parse_djlint_output("\n\n") == []

    @pytest.mark.asyncio
    async def test_parse_error_severity(self) -> None:
        from python_checkup.analyzers.djlint import _parse_djlint_output

        output = "t.html:1:0: E001 some error\n"
        diags = _parse_djlint_output(output)
        assert len(diags) == 1
        assert diags[0].severity == Severity.ERROR

    @pytest.mark.asyncio
    async def test_parse_warning_severity(self) -> None:
        from python_checkup.analyzers.djlint import _parse_djlint_output

        output = "t.html:1:0: W001 some warning\n"
        diags = _parse_djlint_output(output)
        assert len(diags) == 1
        assert diags[0].severity == Severity.WARNING


# ---------------------------------------------------------------------------
# Version parsing
# ---------------------------------------------------------------------------


class TestVersionParsing:
    def test_parse_valid_version(self) -> None:
        from python_checkup.analyzers.django_checks import (
            _parse_django_version,
        )

        assert _parse_django_version("4.2.7") == (4, 2)
        assert _parse_django_version("3.0.0") == (3, 0)
        assert _parse_django_version("5.1.0") == (5, 1)

    def test_parse_none(self) -> None:
        from python_checkup.analyzers.django_checks import (
            _parse_django_version,
        )

        assert _parse_django_version(None) is None

    def test_parse_empty(self) -> None:
        from python_checkup.analyzers.django_checks import (
            _parse_django_version,
        )

        assert _parse_django_version("") is None

    def test_parse_invalid(self) -> None:
        from python_checkup.analyzers.django_checks import (
            _parse_django_version,
        )

        assert _parse_django_version("abc") is None
