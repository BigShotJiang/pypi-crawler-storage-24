from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, patch

from python_checkup.analysis_request import AnalysisRequest
from python_checkup.analyzers.deptry import (
    DeptryAnalyzer,
    _detect_dep_file_label,
    _detect_first_party_modules,
    _fix_suggestion,
)
from python_checkup.config import CheckupConfig
from python_checkup.detection import FrameworkCategory, FrameworkInfo, FrameworkStack
from python_checkup.models import Category, Severity


def _request(project_root: Path, files: list[Path]) -> AnalysisRequest:
    return AnalysisRequest(
        project_root=project_root,
        files=files,
        config=CheckupConfig(),
        categories={Category.DEPENDENCIES},
        profile="default",
    )


def _django_stack() -> FrameworkStack:
    django = FrameworkInfo(
        name="django",
        version=None,
        confidence=1.0,
        category=FrameworkCategory.WEB,
    )
    return FrameworkStack(primary=django, companions=[], all_frameworks=[django])


MOCK_DEPTRY_OUTPUT = json.dumps(
    [
        {
            "error": {"code": "DEP001", "message": "Missing dependency"},
            "module": "matplotlib",
            "location": {"file": "src/plot.py", "line": 2, "column": 0},
        },
        {
            "error": {"code": "DEP002", "message": "Unused dependency"},
            "module": "pandas",
            "location": {"file": "pyproject.toml", "line": None, "column": None},
        },
    ]
)


class TestDeptryAnalyzer:
    def test_name_and_category(self) -> None:
        analyzer = DeptryAnalyzer()
        assert analyzer.name == "deptry"
        assert analyzer.category == Category.DEPENDENCIES

    @patch("shutil.which", return_value="/usr/bin/deptry")
    async def test_is_available_true(self, mock_which: AsyncMock) -> None:
        analyzer = DeptryAnalyzer()
        assert await analyzer.is_available() is True

    @patch("shutil.which", return_value=None)
    async def test_is_available_false(self, mock_which: AsyncMock) -> None:
        analyzer = DeptryAnalyzer()
        assert await analyzer.is_available() is False

    @patch("asyncio.create_subprocess_exec")
    async def test_finds_issues(self, mock_exec: AsyncMock) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (MOCK_DEPTRY_OUTPUT.encode(), b"")
        mock_proc.returncode = 1
        mock_exec.return_value = mock_proc

        analyzer = DeptryAnalyzer()
        results = await analyzer.analyze(_request(Path("."), [Path("src/plot.py")]))

        assert len(results) == 2

        # DEP001: missing dependency
        assert results[0].rule_id == "DEP001"
        assert results[0].severity == Severity.ERROR
        assert results[0].category == Category.DEPENDENCIES
        assert results[0].tool == "deptry"
        assert "matplotlib" in results[0].message
        assert results[0].line == 2
        assert results[0].file_path == Path("src/plot.py")

        # DEP002: unused dependency
        assert results[1].rule_id == "DEP002"
        assert results[1].severity == Severity.WARNING
        assert "pandas" in results[1].message
        assert results[1].line == 0  # None -> 0

    @patch("asyncio.create_subprocess_exec")
    async def test_clean_project(self, mock_exec: AsyncMock) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"[]", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = DeptryAnalyzer()
        results = await analyzer.analyze(_request(Path("."), [Path(".")]))
        assert results == []

    @patch("asyncio.create_subprocess_exec")
    async def test_empty_output(self, mock_exec: AsyncMock) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = DeptryAnalyzer()
        results = await analyzer.analyze(_request(Path("."), [Path(".")]))
        assert results == []

    @patch("asyncio.create_subprocess_exec")
    async def test_invalid_json(self, mock_exec: AsyncMock) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"not json{", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = DeptryAnalyzer()
        results = await analyzer.analyze(_request(Path("."), [Path(".")]))
        assert results == []

    @patch("asyncio.create_subprocess_exec")
    async def test_timeout_handling(self, mock_exec: AsyncMock) -> None:
        mock_exec.side_effect = FileNotFoundError("deptry")

        analyzer = DeptryAnalyzer()
        results = await analyzer.analyze(_request(Path("."), [Path(".")]))
        assert results == []

    @patch("asyncio.create_subprocess_exec")
    async def test_transitive_and_misplaced(self, mock_exec: AsyncMock) -> None:
        output = json.dumps(
            [
                {
                    "error": {"code": "DEP003", "message": "Transitive dependency"},
                    "module": "six",
                    "location": {
                        "file": "src/app.py",
                        "line": 3,
                        "column": 0,
                    },
                },
                {
                    "error": {"code": "DEP004", "message": "Misplaced dev dep"},
                    "module": "pytest",
                    "location": {
                        "file": "src/main.py",
                        "line": 1,
                        "column": 0,
                    },
                },
            ]
        )
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (output.encode(), b"")
        mock_proc.returncode = 1
        mock_exec.return_value = mock_proc

        analyzer = DeptryAnalyzer()
        results = await analyzer.analyze(_request(Path("."), [Path("src/app.py")]))

        assert len(results) == 2
        assert results[0].rule_id == "DEP003"
        assert results[0].severity == Severity.WARNING
        assert results[1].rule_id == "DEP004"
        assert results[1].severity == Severity.WARNING

    @patch("asyncio.create_subprocess_exec")
    async def test_project_root_from_pyproject(
        self, mock_exec: AsyncMock, tmp_path: Path
    ) -> None:
        """Verify deptry walks up to find pyproject.toml."""
        (tmp_path / "pyproject.toml").write_text("[project]")
        src = tmp_path / "src"
        src.mkdir()
        app = src / "app.py"
        app.write_text("x = 1")

        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"[]", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = DeptryAnalyzer()
        await analyzer.analyze(_request(tmp_path, [app]))

        # Verify deptry was called with cwd=project_root and '.' as ROOT
        call_args = mock_exec.call_args[0]
        call_kwargs = mock_exec.call_args[1]
        assert "." in call_args
        assert call_kwargs.get("cwd") == str(tmp_path)

    @patch("asyncio.create_subprocess_exec")
    async def test_django_installed_apps_suppresses_dep002(
        self, mock_exec: AsyncMock, tmp_path: Path
    ) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]")
        (tmp_path / "settings.py").write_text(
            "INSTALLED_APPS = [\n" "    'corsheaders',\n" "    'debug_toolbar',\n" "]\n"
        )
        output = json.dumps(
            [
                {
                    "error": {"code": "DEP002", "message": "Unused dependency"},
                    "module": "corsheaders",
                    "location": {"file": "pyproject.toml", "line": 4, "column": 0},
                },
                {
                    "error": {"code": "DEP002", "message": "Unused dependency"},
                    "module": "debug-toolbar",
                    "location": {"file": "pyproject.toml", "line": 5, "column": 0},
                },
                {
                    "error": {"code": "DEP002", "message": "Unused dependency"},
                    "module": "requests",
                    "location": {"file": "pyproject.toml", "line": 6, "column": 0},
                },
            ]
        )
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (output.encode(), b"")
        mock_proc.returncode = 1
        mock_exec.return_value = mock_proc

        analyzer = DeptryAnalyzer()
        request = _request(tmp_path, [tmp_path / "settings.py"])
        request.framework_stack = _django_stack()
        results = await analyzer.analyze(request)

        assert len(results) == 1
        assert results[0].rule_id == "DEP002"
        assert "requests" in results[0].message


class TestFixSuggestion:
    def test_dep001(self) -> None:
        result = _fix_suggestion("DEP001", "numpy")
        assert "Add" in result
        assert "numpy" in result

    def test_dep002(self) -> None:
        result = _fix_suggestion("DEP002", "pandas")
        assert "Remove" in result
        assert "pandas" in result

    def test_dep003(self) -> None:
        result = _fix_suggestion("DEP003", "six")
        assert "direct dependency" in result
        assert "six" in result

    def test_dep004(self) -> None:
        result = _fix_suggestion("DEP004", "pytest")
        assert "Move" in result
        assert "pytest" in result

    def test_unknown_code(self) -> None:
        result = _fix_suggestion("DEP999", "unknown")
        assert "Review" in result
        assert "unknown" in result

    def test_dep001_with_requirements_txt(self) -> None:
        result = _fix_suggestion("DEP001", "numpy", dep_file="requirements.txt")
        assert "requirements.txt" in result
        assert "numpy" in result

    def test_dep001_with_pipfile(self) -> None:
        result = _fix_suggestion("DEP001", "flask", dep_file="Pipfile")
        assert "Pipfile" in result
        assert "flask" in result

    def test_dep001_default_pyproject(self) -> None:
        result = _fix_suggestion("DEP001", "numpy")
        assert "pyproject.toml" in result


class TestDetectFirstPartyModules:
    def test_finds_packages_with_init(self, tmp_path: Path) -> None:
        pkg = tmp_path / "myapp"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")
        result = _detect_first_party_modules(tmp_path)
        assert "myapp" in result

    def test_finds_top_level_py_files(self, tmp_path: Path) -> None:
        (tmp_path / "utils.py").write_text("x = 1")
        result = _detect_first_party_modules(tmp_path)
        assert "utils" in result

    def test_skips_setup_py(self, tmp_path: Path) -> None:
        (tmp_path / "setup.py").write_text("")
        result = _detect_first_party_modules(tmp_path)
        assert "setup" not in result

    def test_skips_venv(self, tmp_path: Path) -> None:
        venv = tmp_path / "venv"
        venv.mkdir()
        (venv / "__init__.py").write_text("")
        result = _detect_first_party_modules(tmp_path)
        assert "venv" not in result

    def test_skips_hidden_dirs(self, tmp_path: Path) -> None:
        hidden = tmp_path / ".hidden"
        hidden.mkdir()
        (hidden / "__init__.py").write_text("")
        result = _detect_first_party_modules(tmp_path)
        assert ".hidden" not in result

    def test_skips_underscore_dirs(self, tmp_path: Path) -> None:
        pycache = tmp_path / "__pycache__"
        pycache.mkdir()
        result = _detect_first_party_modules(tmp_path)
        assert "__pycache__" not in result

    def test_finds_src_layout_packages(self, tmp_path: Path) -> None:
        src = tmp_path / "src"
        src.mkdir()
        pkg = src / "mylib"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")
        result = _detect_first_party_modules(tmp_path)
        assert "mylib" in result

    def test_skips_migrations_and_static(self, tmp_path: Path) -> None:
        for name in ("migrations", "static", "templates"):
            d = tmp_path / name
            d.mkdir()
            (d / "__init__.py").write_text("")
        result = _detect_first_party_modules(tmp_path)
        assert "migrations" not in result
        assert "static" not in result
        assert "templates" not in result


class TestDetectDepFileLabel:
    def test_pyproject_with_project_section(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\nname = 'foo'\n")
        assert _detect_dep_file_label(tmp_path) == "pyproject.toml"

    def test_pyproject_with_poetry(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[tool.poetry]\nname = 'foo'\n")
        assert _detect_dep_file_label(tmp_path) == "pyproject.toml"

    def test_requirements_txt(self, tmp_path: Path) -> None:
        (tmp_path / "requirements.txt").write_text("flask==2.0\n")
        assert _detect_dep_file_label(tmp_path) == "requirements.txt"

    def test_pipfile(self, tmp_path: Path) -> None:
        (tmp_path / "Pipfile").write_text("[packages]\nflask = '*'\n")
        assert _detect_dep_file_label(tmp_path) == "Pipfile"

    def test_requirements_subdir(self, tmp_path: Path) -> None:
        req_dir = tmp_path / "requirements"
        req_dir.mkdir()
        (req_dir / "base.txt").write_text("flask==2.0\n")
        assert _detect_dep_file_label(tmp_path) == "requirements/base.txt"

    def test_pyproject_without_project_section_falls_through(
        self, tmp_path: Path
    ) -> None:
        (tmp_path / "pyproject.toml").write_text("[build-system]\n")
        (tmp_path / "requirements.txt").write_text("flask==2.0\n")
        assert _detect_dep_file_label(tmp_path) == "requirements.txt"

    def test_no_dep_file(self, tmp_path: Path) -> None:
        assert _detect_dep_file_label(tmp_path) == "your project dependencies"


class TestUserRequirementsFileOverride:
    """Test that user-specified requirements_file is passed to deptry."""

    @patch("asyncio.create_subprocess_exec")
    async def test_user_override_passed_to_cmd(
        self, mock_exec: AsyncMock, tmp_path: Path
    ) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"[]", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        config = CheckupConfig(requirements_file="reqs/prod.txt")
        request = AnalysisRequest(
            project_root=tmp_path,
            files=[tmp_path / "app.py"],
            config=config,
            categories={Category.DEPENDENCIES},
            profile="default",
        )
        analyzer = DeptryAnalyzer()
        await analyzer.analyze(request)

        call_args = mock_exec.call_args[0]
        assert "--requirements-files" in call_args
        idx = call_args.index("--requirements-files")
        assert call_args[idx + 1] == "reqs/prod.txt"


class TestDependencyFileDetection:
    """deptry runs with auto-detected dependency files."""

    @patch("asyncio.create_subprocess_exec")
    async def test_runs_without_pyproject(
        self, mock_exec: AsyncMock, tmp_path: Path
    ) -> None:
        """No pyproject.toml and no requirements -> deptry still runs."""
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"[]", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = DeptryAnalyzer()
        await analyzer.analyze(_request(tmp_path, [tmp_path / "app.py"]))
        mock_exec.assert_called_once()

    @patch("asyncio.create_subprocess_exec")
    async def test_auto_detects_requirements_txt(
        self, mock_exec: AsyncMock, tmp_path: Path
    ) -> None:
        """requirements.txt is auto-detected and passed to deptry."""
        (tmp_path / "requirements.txt").write_text("django==4.2\n")
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"[]", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = DeptryAnalyzer()
        await analyzer.analyze(_request(tmp_path, [tmp_path / "app.py"]))
        mock_exec.assert_called_once()
        call_args = mock_exec.call_args[0]
        assert "--requirements-files" in call_args
        idx = call_args.index("--requirements-files")
        assert "requirements.txt" in call_args[idx + 1]

    @patch("asyncio.create_subprocess_exec")
    async def test_auto_detects_dev_requirements(
        self, mock_exec: AsyncMock, tmp_path: Path
    ) -> None:
        """requirements-dev.txt is auto-detected and passed as dev file."""
        (tmp_path / "requirements.txt").write_text("django==4.2\n")
        (tmp_path / "requirements-dev.txt").write_text("pytest\n")
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"[]", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = DeptryAnalyzer()
        await analyzer.analyze(_request(tmp_path, [tmp_path / "app.py"]))
        call_args = mock_exec.call_args[0]
        assert "--requirements-files-dev" in call_args
        idx = call_args.index("--requirements-files-dev")
        assert "requirements-dev.txt" in call_args[idx + 1]

    @patch("asyncio.create_subprocess_exec")
    async def test_runs_with_pyproject(
        self, mock_exec: AsyncMock, tmp_path: Path
    ) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]")
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"[]", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = DeptryAnalyzer()
        await analyzer.analyze(_request(tmp_path, [tmp_path / "app.py"]))
        mock_exec.assert_called_once()

    @patch("asyncio.create_subprocess_exec")
    async def test_runs_with_requirements_file_override(
        self, mock_exec: AsyncMock, tmp_path: Path
    ) -> None:
        """No pyproject.toml but user provides --requirements-file -> runs."""
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"[]", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        config = CheckupConfig(requirements_file="requirements.txt")
        request = AnalysisRequest(
            project_root=tmp_path,
            files=[tmp_path / "app.py"],
            config=config,
            categories={Category.DEPENDENCIES},
            profile="default",
        )
        analyzer = DeptryAnalyzer()
        await analyzer.analyze(request)
        mock_exec.assert_called_once()


class TestDeptryRunsCwdProjectRoot:
    """Verify deptry runs with cwd=project_root."""

    @patch("asyncio.create_subprocess_exec")
    async def test_cwd_is_project_root(
        self, mock_exec: AsyncMock, tmp_path: Path
    ) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]")
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"[]", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = DeptryAnalyzer()
        await analyzer.analyze(_request(tmp_path, [tmp_path / "app.py"]))

        call_kwargs = mock_exec.call_args[1]
        assert call_kwargs["cwd"] == str(tmp_path)

    @patch("asyncio.create_subprocess_exec")
    async def test_dot_used_as_root_arg(
        self, mock_exec: AsyncMock, tmp_path: Path
    ) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]")
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"[]", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = DeptryAnalyzer()
        await analyzer.analyze(_request(tmp_path, [tmp_path / "app.py"]))

        call_args = mock_exec.call_args[0]
        assert call_args[0] == "deptry"
        assert call_args[1] == "."
