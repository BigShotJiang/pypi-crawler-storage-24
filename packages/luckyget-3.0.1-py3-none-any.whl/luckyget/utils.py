"""Shared utilities, colors, formatters."""
import sys, time, threading

# ANSI
R   = "\033[0m";  B   = "\033[1m";  DIM = "\033[2m"
RED = "\033[91m"; GRN = "\033[92m"; YLW = "\033[93m"
BLU = "\033[94m"; MAG = "\033[95m"; CYN = "\033[96m"; WHT = "\033[97m"

def c(color, text): return f"{color}{text}{R}"

def section(title):
    print(f"\n{c(B+CYN,'  '+title)}")
    print(f"  {c(DIM, chr(8212)*50)}")

def status_color(code):
    if code < 300: return GRN
    if code < 400: return YLW
    if code < 500: return RED
    return MAG

def format_size(n):
    for unit in ['B','KB','MB','GB']:
        if n < 1024: return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"

def format_ms(ms):
    if ms < 1000: return f"{ms:.0f}ms"
    return f"{ms/1000:.2f}s"

def fmt_age(s):
    if s < 60:    return f"{int(s)}s ago"
    if s < 3600:  return f"{int(s//60)}m ago"
    if s < 86400: return f"{int(s//3600)}h ago"
    return f"{int(s//86400)}d ago"

def fmt_json(data):
    import json, re
    pretty = json.dumps(data, indent=2, ensure_ascii=False)
    pretty = re.sub(r'"[^"]*"(?=\s*:)',  lambda m: f"{BLU}{B}{m.group(0)}{R}", pretty)
    pretty = re.sub(r'(?<=:\s)"[^"]*"',  lambda m: f"{GRN}{m.group(0)}{R}", pretty)
    pretty = re.sub(r'\b(true|false|null)\b', lambda m: f"{YLW}{m.group(0)}{R}", pretty)
    pretty = re.sub(r'(?<!["\w])-?\d+\.?\d*(?!["\w])', lambda m: f"{CYN}{m.group(0)}{R}", pretty)
    return pretty

class Spinner:
    def __init__(self, msg=""):
        self.msg = msg; self._stop = False; self._t = None
    def _spin(self):
        frames = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
        i = 0
        while not self._stop:
            print(f"\r  {c(CYN, frames[i%len(frames)])} {c(DIM, self.msg)}", end='', flush=True)
            time.sleep(0.08); i += 1
        print('\r' + ' '*(len(self.msg)+6) + '\r', end='', flush=True)
    def start(self):
        self._t = threading.Thread(target=self._spin, daemon=True); self._t.start()
    def stop(self):
        self._stop = True
        if self._t: self._t.join()
