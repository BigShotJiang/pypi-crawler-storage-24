"""SQLite tools: query, tables, schema, export."""
import os, json
from .utils import *

def _connect(path):
    import sqlite3
    return sqlite3.connect(os.path.expanduser(path))

def cmd_sqlite(args):
    path  = args.db
    query = getattr(args,'query',None)
    table = getattr(args,'table',None)
    schema= getattr(args,'schema',False)
    export= getattr(args,'export',None)

    if not os.path.exists(os.path.expanduser(path)):
        print(f"\n  {c(RED,'✗')} File not found: {path}\n"); return

    try:
        import sqlite3
        conn = sqlite3.connect(os.path.expanduser(path))
        conn.row_factory = sqlite3.Row
        cur  = conn.cursor()
    except Exception as e:
        print(f"\n  {c(RED,'✗')} {e}\n"); return

    section(f'SQLite: {os.path.basename(path)}')

    if schema or (not query and not table):
        # Show all tables
        cur.execute("SELECT name, type FROM sqlite_master WHERE type IN ('table','view') ORDER BY name")
        rows = cur.fetchall()
        print(f"\n  {c(B,'Tables & Views:')}\n")
        for row in rows:
            tname, ttype = row['name'], row['type']
            cur.execute(f"SELECT COUNT(*) FROM [{tname}]")
            cnt = cur.fetchone()[0]
            print(f"  {c(CYN+B, tname):<32} {c(DIM, ttype):<10} {c(YLW, str(cnt)+' rows')}")
        print()
        if schema:
            print(f"  {c(B,'Schema:')}\n")
            cur.execute("SELECT sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY type DESC")
            for row in cur.fetchall():
                sql = row[0]
                # Colorize
                sql = sql.replace('CREATE TABLE', c(BLU+B,'CREATE TABLE'))
                sql = sql.replace('CREATE VIEW',  c(MAG+B,'CREATE VIEW'))
                sql = sql.replace('INTEGER', c(YLW,'INTEGER')).replace('TEXT', c(GRN,'TEXT'))
                sql = sql.replace('REAL', c(CYN,'REAL')).replace('BLOB', c(RED,'BLOB'))
                sql = sql.replace('PRIMARY KEY', c(RED+B,'PRIMARY KEY'))
                sql = sql.replace('NOT NULL', c(YLW,'NOT NULL'))
                print(f"  {sql}\n")
        conn.close(); return

    if table:
        query = f"SELECT * FROM [{table}] LIMIT {getattr(args,'limit',None) or 50}"

    if query:
        try:
            cur.execute(query)
            rows = cur.fetchall()
            if not rows:
                print(f"\n  {c(DIM,'Query returned 0 rows')}\n"); conn.close(); return
            cols = [description[0] for description in cur.description]
            # Column widths
            widths = [max(len(str(col)), max((len(str(row[col] if hasattr(row,'keys') else row[i])) for row in rows), default=0)) for i, col in enumerate(cols)]
            widths = [min(w, 30) for w in widths]
            # Header
            print()
            header = '  ' + '  '.join(c(B+BLU, str(col).ljust(widths[i])) for i,col in enumerate(cols))
            sep    = '  ' + '  '.join(c(DIM, '─'*widths[i]) for i in range(len(cols)))
            print(header); print(sep)
            for row in rows:
                vals = [str(row[i] if not hasattr(row,'keys') else row[col]) for i,col in enumerate(cols)]
                line = '  ' + '  '.join(c(WHT, v[:widths[i]].ljust(widths[i])) for i,v in enumerate(vals))
                print(line)
            print(f"\n  {c(DIM, str(len(rows))+' row(s)')}")
            if export:
                if export.endswith('.json'):
                    data = [{cols[i]: (row[i] if not hasattr(row,'keys') else row[col]) for i,col in enumerate(cols)} for row in rows]
                    open(export,'w').write(json.dumps(data,indent=2))
                    print(f"  {c(GRN,'✓ Exported to '+export)}")
                elif export.endswith('.csv'):
                    import csv
                    with open(export,'w',newline='') as f:
                        w=csv.writer(f); w.writerow(cols)
                        for row in rows: w.writerow([row[i] if not hasattr(row,'keys') else row[col] for i,col in enumerate(cols)])
                    print(f"  {c(GRN,'✓ Exported to '+export)}")
        except Exception as e:
            print(f"\n  {c(RED,'✗')} {e}")
    print()
    conn.close()
