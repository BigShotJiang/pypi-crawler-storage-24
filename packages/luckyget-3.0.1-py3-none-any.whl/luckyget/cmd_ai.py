"""AI commands: ai (one-shot), chat (interactive with memory), commit, readme, translate."""
import os, json, sys
import urllib.request, urllib.error
from .utils import *

UA = 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36'

PROVIDERS = {
    'claude':     {'env':'ANTHROPIC_API_KEY',  'free':False, 'label':'Anthropic Claude'},
    'openai':     {'env':'OPENAI_API_KEY',     'free':False, 'label':'OpenAI GPT-4o-mini'},
    'gemini':     {'env':'GEMINI_API_KEY',     'free':True,  'label':'Google Gemini 1.5 Flash'},
    'groq':       {'env':'GROQ_API_KEY',       'free':True,  'label':'Groq Llama 3.3 70B'},
    'mistral':    {'env':'MISTRAL_API_KEY',    'free':False, 'label':'Mistral Small'},
    'openrouter': {'env':'OPENROUTER_API_KEY', 'free':True,  'label':'OpenRouter (free Llama)'},
}

def _detect_provider(key_override=None):
    # Prefer free providers first
    for p in ['groq','gemini','openrouter','mistral','openai','claude']:
        if p in PROVIDERS and os.environ.get(PROVIDERS[p]['env']): return p
    return 'groq'

def _get_key(provider, key_override=None):
    return key_override or os.environ.get(PROVIDERS[provider]['env'], '')

def ai_call(provider, api_key, messages, system=None, max_tokens=2000):
    """Low-level call. messages = [{'role':'user','content':'...'}]"""
    if provider == 'claude':
        payload = {'model':'claude-sonnet-4-20250514','max_tokens':max_tokens,'messages':messages}
        if system: payload['system'] = system
        data = json.dumps(payload).encode()
        req  = urllib.request.Request("https://api.anthropic.com/v1/messages", data=data,
                   headers={"Content-Type":"application/json","x-api-key":api_key,
                             "anthropic-version":"2023-06-01"}, method="POST")
        with urllib.request.urlopen(req, timeout=60) as r:
            d = json.loads(r.read()); u = d.get('usage',{})
            return d['content'][0]['text'], u.get('input_tokens',0), u.get('output_tokens',0)

    elif provider == 'gemini':
        contents = []
        if system: contents.append({'role':'user','parts':[{'text':system}]})
        for m in messages:
            role = 'user' if m['role']=='user' else 'model'
            contents.append({'role':role,'parts':[{'text':m['content']}]})
        payload = json.dumps({'contents':contents,'generationConfig':{'maxOutputTokens':max_tokens}}).encode()
        req = urllib.request.Request(
            f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={api_key}",
            data=payload, headers={"Content-Type":"application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=60) as r:
            d = json.loads(r.read()); u = d.get('usageMetadata',{})
            return d['candidates'][0]['content']['parts'][0]['text'], u.get('promptTokenCount',0), u.get('candidatesTokenCount',0)

    else:
        urls   = {'openai':'https://api.openai.com/v1/chat/completions',
                  'groq':'https://api.groq.com/openai/v1/chat/completions',
                  'mistral':'https://api.mistral.ai/v1/chat/completions',
                  'openrouter':'https://openrouter.ai/api/v1/chat/completions'}
        models = {'openai':'gpt-4o-mini','groq':'llama-3.3-70b-versatile',
                  'mistral':'mistral-small-latest','openrouter':'meta-llama/llama-3.3-70b-instruct:free'}
        msgs = []
        if system: msgs.append({'role':'system','content':system})
        msgs.extend(messages)
        payload = json.dumps({'model':models[provider],'max_tokens':max_tokens,'messages':msgs}).encode()
        hdrs = {"Content-Type":"application/json","Authorization":f"Bearer {api_key}","User-Agent":UA}
        if provider=='openrouter': hdrs['HTTP-Referer']='https://github.com/luckyget'; hdrs['X-Title']='luckyget'
        req = urllib.request.Request(urls[provider], data=payload, headers=hdrs, method="POST")
        with urllib.request.urlopen(req, timeout=60) as r:
            d = json.loads(r.read()); u = d.get('usage',{})
            return d['choices'][0]['message']['content'], u.get('prompt_tokens',0), u.get('completion_tokens',0)

def _show_providers():
    section('AI Providers'); print()
    for p, info in PROVIDERS.items():
        has  = c(GRN+B,'✓ KEY SET') if os.environ.get(info['env']) else c(DIM,'  no key ')
        free = c(GRN,'FREE') if info['free'] else c(YLW,'paid')
        print(f"  {c(B+CYN, p):<22} {free:<14} {has}  {c(DIM, info['env'])}")
    print(f"""
{c(B,'Get free keys:')}
  Groq (fastest):    {c(GRN,'console.groq.com')}        export GROQ_API_KEY='gsk_...'
  Gemini:            {c(GRN,'aistudio.google.com')}      export GEMINI_API_KEY='AIza...'
  OpenRouter:        {c(GRN,'openrouter.ai')}            export OPENROUTER_API_KEY='sk-or-...'
""")

def _build_prompt(args):
    prompt = getattr(args,'prompt','') or ''
    if getattr(args,'file',None):
        try:
            with open(os.path.expanduser(args.file),'r',encoding='utf-8') as f:
                fc = f.read()
            fname = os.path.basename(args.file)
            print(f"  {c(DIM,'File:')} {fname} ({c(YLW,str(len(fc)))} chars, {fc.count(chr(10))} lines)\n")
            prompt = (prompt + '\n\n' if prompt else '') + f"File: {fname}\n```\n{fc}\n```"
        except Exception as e:
            print(f"{c(RED,'✗ Cannot read file:')} {e}"); return None
    return prompt or None

MODE_PROMPTS = {
    'code':    lambda lang: f"Expert programmer. Write clean, working {lang} code with brief inline comments. Start with a one-line description then the code.",
    'explain': lambda _: "Senior developer. Explain the code clearly with bullet points. Be concise and practical.",
    'fix':     lambda _: "Expert debugger. Identify bugs and fix the code. Show the corrected version and briefly explain each fix.",
    'review':  lambda _: "Code reviewer. Give structured feedback with sections: ✓ Good, ✗ Bugs/Issues, ⚡ Improvements, 🔒 Security.",
    'chat':    lambda _: "Helpful programming assistant. Answer concisely. Respond in the user's language.",
}

def cmd_ai(args):
    provider = getattr(args,'provider',None) or _detect_provider()
    if not provider: _show_providers(); return
    api_key = _get_key(provider, getattr(args,'key',None))
    if not api_key:
        print(f"\n{c(RED,f'✗ No key for {provider}!')}  export {PROVIDERS[provider]['env']}='...'\n"); return
    mode = getattr(args,'mode',None) or 'chat'
    lang = getattr(args,'lang',None) or 'auto'
    prompt = _build_prompt(args)
    if not prompt: return
    sys_prompt = MODE_PROMPTS.get(mode, MODE_PROMPTS['chat'])(lang)
    print(f"\n{c(DIM,'Asking')} {c(CYN+B, provider)}{c(DIM,'...')}\n")
    try:
        text, tok_in, tok_out = ai_call(provider, api_key, [{'role':'user','content':prompt}], system=sys_prompt)
        print(f"{c(CYN+B, '══ '+provider.upper()+' '+'═'*45)}")
        print(text)
        print(f"{c(CYN+B, '═'*50)}")
        if tok_in or tok_out: print(f"\n{DIM}Tokens: {tok_in} in / {tok_out} out{R}\n")
    except urllib.error.HTTPError as e:
        err = e.read().decode()
        try: msg = json.loads(err).get('error',{}).get('message', err[:300])
        except: msg = err[:300]
        print(f"{c(RED, f'✗ {provider} {e.code}:')} {msg}\n")
    except Exception as e:
        print(f"{c(RED,'✗ AI failed:')} {e}\n")

def cmd_chat(args):
    provider = getattr(args,'provider',None) or _detect_provider()
    if not provider: print(f"\n{c(RED,'✗')} No AI key found. Run {c(CYN,'luckyget ai')} to see providers.\n"); return
    api_key  = _get_key(provider, getattr(args,'key',None))
    if not api_key: print(f"\n{c(RED,'✗ No key!')} export {PROVIDERS[provider]['env']}='...'\n"); return
    sys_prompt = getattr(args,'system',None) or "You are a helpful programming assistant. Answer concisely. Respond in the same language as the user."
    history = []
    print(f"\n{c(CYN+B,'  ╔══ Interactive Chat ══╗')}")
    print(f"  {c(DIM,'Provider:')} {c(CYN+B, provider)}  {c(DIM, PROVIDERS[provider]['label'])}")
    print(f"  {c(DIM,'Commands: /exit  /clear  /history  /system <text>  /save <file>')}")
    print(f"  {c(DIM, chr(8212)*50)}\n")
    while True:
        try:
            user_input = input(f"{c(GRN+B,'You')} › ").strip()
        except (EOFError, KeyboardInterrupt):
            print(f"\n{c(DIM,'Bye!')}\n"); break
        if not user_input: continue
        # Slash commands
        if user_input == '/exit': print(f"\n{c(DIM,'Bye!')}\n"); break
        if user_input == '/clear': history = []; print(f"  {c(DIM,'History cleared.')}\n"); continue
        if user_input == '/history':
            if not history: print(f"  {c(DIM,'No history yet.')}\n"); continue
            for h in history:
                who = c(GRN,'You') if h['role']=='user' else c(CYN,provider)
                print(f"  {who}: {h['content'][:80]}")
            print(); continue
        if user_input.startswith('/system '):
            sys_prompt = user_input[8:]
            print(f"  {c(DIM,'System prompt updated.')}\n"); continue
        if user_input.startswith('/save '):
            fname = user_input[6:].strip()
            try:
                with open(fname,'w') as f:
                    for h in history: f.write(f"{h['role'].upper()}: {h['content']}\n\n")
                print(f"  {c(GRN,'✓ Saved to '+fname)}\n")
            except Exception as e: print(f"  {c(RED,'✗')} {e}\n")
            continue
        history.append({'role':'user','content':user_input})
        print(f"{c(CYN+B, provider)} › ", end='', flush=True)
        try:
            reply, _, _ = ai_call(provider, api_key, history, system=sys_prompt, max_tokens=1500)
            print(reply + "\n")
            history.append({'role':'assistant','content':reply})
            if len(history) > 40: history = history[-40:]
        except urllib.error.HTTPError as e:
            err = e.read().decode()
            try: msg = json.loads(err).get('error',{}).get('message',err[:200])
            except: msg = err[:200]
            print(f"{c(RED, f'✗ {e.code}:')} {msg}\n")
            history.pop()
        except Exception as e:
            print(f"{c(RED,'✗')} {e}\n"); history.pop()

def cmd_commit(args):
    """Generate AI commit message from git diff."""
    import subprocess
    provider = getattr(args,'provider',None) or _detect_provider()
    if not provider: print(f"\n{c(RED,'✗')} No AI key. Run {c(CYN,'luckyget ai')}\n"); return
    api_key = _get_key(provider, getattr(args,'key',None))
    if not api_key: print(f"\n{c(RED,'✗ No key!')} export {PROVIDERS[provider]['env']}='...'\n"); return
    try:
        result = subprocess.run(['git','diff','--staged'], capture_output=True, text=True)
        diff   = result.stdout
        if not diff:
            result = subprocess.run(['git','diff'], capture_output=True, text=True)
            diff   = result.stdout
        if not diff:
            print(f"\n  {c(YLW,'No changes to commit')}\n"); return
    except FileNotFoundError:
        print(f"\n  {c(RED,'✗')} git not installed\n"); return
    diff_snippet = diff[:3000]
    sys_p = ("You are an expert at writing git commit messages. "
             "Follow Conventional Commits format: type(scope): description. "
             "Types: feat, fix, docs, style, refactor, test, chore. "
             "Output ONLY the commit message, no explanation. Be concise (max 72 chars for subject).")
    user_p = f"Write a commit message for this diff:\n\n```diff\n{diff_snippet}\n```"
    section(f'AI Commit Message ({provider})'); print()
    try:
        text, _, _ = ai_call(provider, api_key, [{'role':'user','content':user_p}], system=sys_p, max_tokens=200)
        text = text.strip().strip('`').strip()
        print(f"  {c(GRN+B, text)}\n")
        # Offer to copy
        if getattr(args,'apply',False):
            import subprocess
            subprocess.run(['git','commit','-m',text])
            print(f"  {c(GRN,'✓ Committed!')}\n")
        else:
            print(f"  {c(DIM,'Run with --apply to commit automatically')}\n")
    except Exception as e:
        print(f"  {c(RED,'✗')} {e}\n")

def cmd_readme(args):
    """Generate README from code file(s)."""
    provider = getattr(args,'provider',None) or _detect_provider()
    if not provider: print(f"\n{c(RED,'✗')} No AI key.\n"); return
    api_key = _get_key(provider, getattr(args,'key',None))
    if not api_key: print(f"\n{c(RED,'✗ No key!')}\n"); return
    file_path = getattr(args,'file',None)
    if not file_path: print(f"\n{c(RED,'✗')} Provide --file <path>\n"); return
    try:
        with open(os.path.expanduser(file_path),'r') as f: code = f.read()
    except Exception as e: print(f"\n{c(RED,'✗')} {e}\n"); return
    fname  = os.path.basename(file_path)
    sys_p  = ("You are a technical writer. Generate a clean, professional README.md "
              "for the given code. Include: title, description, features, installation, usage, examples. "
              "Use markdown formatting. Be practical and developer-friendly.")
    user_p = f"Generate a README.md for this file ({fname}):\n\n```\n{code[:4000]}\n```"
    section(f'README Generator ({provider})'); print()
    try:
        text, tok_in, tok_out = ai_call(provider, api_key, [{'role':'user','content':user_p}], system=sys_p, max_tokens=2000)
        output = getattr(args,'output',None) or 'README.md'
        if getattr(args,'print',False):
            print(text); print()
        else:
            with open(output,'w') as f: f.write(text)
            print(f"  {c(GRN+B,'✓ README generated:')} {output}")
            print(f"  {c(DIM,f'Tokens: {tok_in} in / {tok_out} out')}\n")
    except Exception as e:
        print(f"  {c(RED,'✗')} {e}\n")

def cmd_translate_code(args):
    """Translate code from one language to another."""
    provider = getattr(args,'provider',None) or _detect_provider()
    if not provider: print(f"\n{c(RED,'✗')} No AI key.\n"); return
    api_key  = _get_key(provider, getattr(args,'key',None))
    if not api_key: print(f"\n{c(RED,'✗ No key!')}\n"); return
    to_lang  = args.to
    from_lang= getattr(args,'from_lang',None) or 'auto'
    file_path= getattr(args,'file',None)
    code_arg = getattr(args,'code',None)
    if file_path:
        try:
            with open(os.path.expanduser(file_path),'r') as f: code = f.read()
            print(f"  {c(DIM,'File:')} {os.path.basename(file_path)}\n")
        except Exception as e: print(f"\n{c(RED,'✗')} {e}\n"); return
    elif code_arg:
        code = code_arg
    else:
        print(f"\n{c(RED,'✗')} Provide --file or code argument\n"); return
    sys_p  = (f"You are an expert polyglot programmer. Translate the given code to {to_lang}. "
              f"Keep the same logic and structure. Add brief comments where the translation isn't obvious. "
              f"Output ONLY the translated code, no explanation.")
    user_p = f"Translate this code{' from '+from_lang if from_lang!='auto' else ''} to {to_lang}:\n\n```\n{code[:4000]}\n```"
    section(f'Code Translator → {to_lang} ({provider})'); print()
    try:
        text, tok_in, tok_out = ai_call(provider, api_key, [{'role':'user','content':user_p}], system=sys_p)
        print(text)
        print(f"\n{DIM}Tokens: {tok_in} in / {tok_out} out{R}\n")
        out_file = getattr(args,'output',None)
        if out_file:
            with open(out_file,'w') as f: f.write(text)
            print(f"  {c(GRN,'✓ Saved to '+out_file)}\n")
    except Exception as e:
        print(f"  {c(RED,'✗')} {e}\n")
