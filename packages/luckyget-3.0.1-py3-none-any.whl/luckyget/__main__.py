#!/usr/bin/env python3
"""luckyget v3.0 — The all-in-one dev CLI tool."""
import sys, argparse

def banner():
    from .utils import c, B, CYN, YLW, DIM, R
    print(f"""{CYN}{B}
  ██╗     ██╗   ██╗ ██████╗██╗  ██╗██╗   ██╗ ██████╗ ███████╗████████╗
  ██║     ██║   ██║██╔════╝██║ ██╔╝╚██╗ ██╔╝██╔════╝ ██╔════╝╚══██╔══╝
  ██║     ██║   ██║██║     █████╔╝  ╚████╔╝ ██║  ███╗█████╗     ██║
  ██║     ██║   ██║██║     ██╔═██╗   ╚██╔╝  ██║   ██║██╔══╝     ██║
  ███████╗╚██████╔╝╚██████╗██║  ██╗   ██║   ╚██████╔╝███████╗   ██║
  ╚══════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝   ╚═╝    ╚═════╝ ╚══════╝   ╚═╝
{R}  {c(DIM,'The all-in-one dev CLI tool')}  {c(YLW+B,'v3.0')}{R}
""")

def print_help():
    from .utils import c, B, CYN, YLW, DIM, WHT, GRN, R
    banner()
    print(f"""{c(B+WHT,'── HTTP ──────────────────────────────────────────────────────────────')}
  {c(CYN+B,'get/post/put/delete')} {c(DIM,'<url> [-H hdr] [-d body] [-j] [-b token] [-v]')}
  {c(CYN+B,'status')}  {c(DIM,'<url> [url...]')}       Check sites in parallel
  {c(CYN+B,'ping')}    {c(DIM,'<url> [-n N]')}         HTTP latency chart
  {c(CYN+B,'headers')} {c(DIM,'<url>')}                Response headers
  {c(CYN+B,'mock')}    {c(DIM,'[-p port] [-b body] [-c code] [--delay ms]')}   Mock server

{c(B+WHT,'── NETWORK & SECURITY ────────────────────────────────────────────────')}
  {c(CYN+B,'dns')}     {c(DIM,'<host>')}               DNS + reverse lookup
  {c(CYN+B,'ports')}   {c(DIM,'<host> [-p 80,443,...]')}  Port scanner
  {c(CYN+B,'ip')}      {c(DIM,'[host]')}               IP geolocation
  {c(CYN+B,'ssl')}     {c(DIM,'<host>')}               SSL certificate info
  {c(CYN+B,'whois')}   {c(DIM,'<domain>')}             Domain WHOIS via RDAP
  {c(CYN+B,'tech')}    {c(DIM,'<url>')}                Detect tech stack

{c(B+WHT,'── DEV TOOLS ─────────────────────────────────────────────────────────')}
  {c(CYN+B,'json')}    {c(DIM,'[-i <json>]')}          Format & validate JSON
  {c(CYN+B,'jwt')}     {c(DIM,'<token>')}              Decode JWT (expiry check)
  {c(CYN+B,'uuid')}    {c(DIM,'[-n N] [--upper]')}     Generate UUIDs
  {c(CYN+B,'ts')}      {c(DIM,'[unix_timestamp]')}     Timestamp converter
  {c(CYN+B,'regex')}   {c(DIM,'<pattern> <text>')}     Test regex with highlights
  {c(CYN+B,'url')}     {c(DIM,'<url>')}                Parse URL components
  {c(CYN+B,'encode')}  {c(DIM,'<text>')}               Base64 / URL / MD5 / SHA hashes
  {c(CYN+B,'hash')}    {c(DIM,'<file> [--verify sha]')}  Hash a file
  {c(CYN+B,'diff')}    {c(DIM,'<file1> <file2>')}      Colored file diff
  {c(CYN+B,'httpcode')}{c(DIM,' [code]')}              HTTP status codes reference
  {c(CYN+B,'cron')}    {c(DIM,'"* * * * *"')}         Explain cron expression
  {c(CYN+B,'color')}   {c(DIM,'<#hex|rgb()|hsl()>')}  Color converter
  {c(CYN+B,'lorem')}   {c(DIM,'[-n N]')}               Lorem ipsum generator

{c(B+WHT,'── GIT ───────────────────────────────────────────────────────────────')}
  {c(CYN+B,'git-log')}     {c(DIM,'[-n N] [--all]')}     Beautiful git log
  {c(CYN+B,'git-status')}                          Colored status + last commit
  {c(CYN+B,'git-branches')}                        List all branches sorted
  {c(CYN+B,'git-diff')}    {c(DIM,'[--staged]')}         Diff stat with bar chart
  {c(CYN+B,'git-stash')}                           List stash entries

{c(B+WHT,'── FILES ─────────────────────────────────────────────────────────────')}
  {c(CYN+B,'tree')}   {c(DIM,'[path] [-d depth] [-s]')}   Directory tree
  {c(CYN+B,'find')}   {c(DIM,'[path] <pattern> [-e ext]')} Find files
  {c(CYN+B,'wc')}     {c(DIM,'<file>')}                    Word/line count
  {c(CYN+B,'size')}   {c(DIM,'[path]')}                    Disk usage bar chart
  {c(CYN+B,'watch')}  {c(DIM,'"<command>" [-i sec]')}      Watch command output

{c(B+WHT,'── DATABASE ──────────────────────────────────────────────────────────')}
  {c(CYN+B,'sqlite')} {c(DIM,'<db> [-q query] [-t table] [--schema] [--export file.csv]')}

{c(B+WHT,'── TELEGRAM ──────────────────────────────────────────────────────────')}
  {c(CYN+B,'tg')}     {c(DIM,'[--updates] [--chat ID --msg text] [--webhook]')}

{c(B+WHT,'── AI ────────────────────────────────────────────────────────────────')}
  {c(CYN+B,'ai')}         {c(DIM,'[prompt] [--file F] [--mode M] [--provider P]')}
  {c(CYN+B,'chat')}       {c(DIM,'[--provider P] [--system prompt]')}   {c(GRN,'← has memory!')}
  {c(CYN+B,'commit')}     {c(DIM,'[--apply]')}              AI commit message from git diff
  {c(CYN+B,'readme')}     {c(DIM,'--file F [--output F]')}  Generate README.md
  {c(CYN+B,'translate')}  {c(DIM,'--to lang [--file F]')}   Translate code to another language

{c(B+WHT,'── AI OPTIONS ────────────────────────────────────────────────────────')}
  --provider  claude · openai · gemini · groq · mistral · openrouter
  --mode      code · explain · fix · review · chat
  --lang      python · bash · js · go · rust · ...
  --file      <path>        analyze / use a file
  --key       <api_key>     inline key

{c(GRN,'FREE AI KEYS:')}
  export GROQ_API_KEY='...'        {c(DIM,'console.groq.com')}
  export GEMINI_API_KEY='...'      {c(DIM,'aistudio.google.com')}
  export OPENROUTER_API_KEY='...'  {c(DIM,'openrouter.ai')}

{c(DIM,'v3.0 | zero dependencies | pure Python stdlib | multi-file arch')}
""")

def _p(*flags, **kw):
    """Helper: argparse with add_help=False."""
    p = argparse.ArgumentParser(add_help=False)
    for args in flags:
        if isinstance(args, tuple):
            p.add_argument(*args[0], **args[1])
        else:
            p.add_argument(args)
    for k,v in kw.items():
        pass
    return p

def main():
    if len(sys.argv) < 2 or sys.argv[1] in ('-h','--help','help'):
        print_help(); return

    cmd  = sys.argv[1].lower()
    rest = sys.argv[2:]

    # ── Lazy imports ──────────────────────────────────────────────────────────
    if cmd in ('get','post','put','delete','patch','head'):
        from .cmd_http import cmd_get
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('url')
        p.add_argument('-H','--header', action='append', dest='header')
        p.add_argument('-d','--data')
        p.add_argument('-j','--json',    action='store_true')
        p.add_argument('-b','--bearer')
        p.add_argument('-X','--method')
        p.add_argument('-v','--verbose', action='store_true')
        p.add_argument('--full',         action='store_true')
        p.add_argument('-t','--timeout', type=int)
        args = p.parse_args(rest)
        if not args.method: args.method = cmd.upper()
        cmd_get(args)

    elif cmd == 'status':
        from .cmd_http import cmd_status
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('urls', nargs='+')
        p.add_argument('-t','--timeout', type=int)
        cmd_status(p.parse_args(rest))

    elif cmd == 'ping':
        from .cmd_http import cmd_ping
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('url')
        p.add_argument('-n','--count', type=int)
        cmd_ping(p.parse_args(rest))

    elif cmd == 'headers':
        from .cmd_http import cmd_headers
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('url')
        cmd_headers(p.parse_args(rest))

    elif cmd == 'mock':
        from .cmd_http import cmd_mock
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('-p','--port',  type=int)
        p.add_argument('-b','--body')
        p.add_argument('-c','--code',  type=int)
        p.add_argument('--ct')
        p.add_argument('--delay',      type=int)
        cmd_mock(p.parse_args(rest))

    elif cmd == 'dns':
        from .cmd_network import cmd_dns
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('host')
        cmd_dns(p.parse_args(rest))

    elif cmd == 'ports':
        from .cmd_network import cmd_ports
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('host')
        p.add_argument('-p','--ports')
        p.add_argument('-t','--timeout', type=float)
        args = p.parse_args(rest)
        if args.ports: args.ports = [int(x) for x in args.ports.split(',')]
        cmd_ports(args)

    elif cmd == 'ip':
        from .cmd_network import cmd_ip
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('host', nargs='?', default='')
        cmd_ip(p.parse_args(rest))

    elif cmd == 'ssl':
        from .cmd_network import cmd_ssl
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('host')
        p.add_argument('-p','--port', type=int)
        cmd_ssl(p.parse_args(rest))

    elif cmd == 'whois':
        from .cmd_network import cmd_whois
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('domain')
        cmd_whois(p.parse_args(rest))

    elif cmd == 'tech':
        from .cmd_network import cmd_tech
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('url')
        cmd_tech(p.parse_args(rest))

    elif cmd == 'json':
        from .cmd_dev import cmd_json
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('-i','--input', dest='input')
        cmd_json(p.parse_args(rest))

    elif cmd == 'jwt':
        from .cmd_dev import cmd_jwt
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('token')
        cmd_jwt(p.parse_args(rest))

    elif cmd == 'uuid':
        from .cmd_dev import cmd_uuid
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('-n','--count', type=int)
        p.add_argument('--upper',      action='store_true')
        p.add_argument('--ver',        type=int, choices=[1,4], default=4)
        cmd_uuid(p.parse_args(rest))

    elif cmd in ('ts','timestamp'):
        from .cmd_dev import cmd_ts
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('input', nargs='?')
        cmd_ts(p.parse_args(rest))

    elif cmd == 'regex':
        from .cmd_dev import cmd_regex
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('pattern')
        p.add_argument('text')
        p.add_argument('-i','--ignore-case', action='store_true')
        cmd_regex(p.parse_args(rest))

    elif cmd == 'url':
        from .cmd_dev import cmd_url
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('url')
        cmd_url(p.parse_args(rest))

    elif cmd == 'encode':
        from .cmd_dev import cmd_encode
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('text')
        cmd_encode(p.parse_args(rest))

    elif cmd == 'hash':
        from .cmd_dev import cmd_hash
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('file')
        p.add_argument('--verify')
        cmd_hash(p.parse_args(rest))

    elif cmd == 'diff':
        from .cmd_dev import cmd_diff
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('file1')
        p.add_argument('file2')
        cmd_diff(p.parse_args(rest))

    elif cmd == 'httpcode':
        from .cmd_dev import cmd_httpcode
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('code', nargs='?')
        cmd_httpcode(p.parse_args(rest))

    elif cmd == 'cron':
        from .cmd_dev import cmd_cron
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('expr', nargs='+')
        args = p.parse_args(rest); args.expr = ' '.join(args.expr)
        cmd_cron(args)

    elif cmd == 'color':
        from .cmd_dev import cmd_color
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('value')
        cmd_color(p.parse_args(rest))

    elif cmd == 'lorem':
        from .cmd_dev import cmd_lorem
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('-n','--count', type=int)
        cmd_lorem(p.parse_args(rest))

    elif cmd == 'git-log':
        from .cmd_git import cmd_git_log
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('-n','--count', type=int)
        p.add_argument('--all',        action='store_true')
        cmd_git_log(p.parse_args(rest))

    elif cmd == 'git-status':
        from .cmd_git import cmd_git_status
        cmd_git_status(argparse.Namespace())

    elif cmd == 'git-branches':
        from .cmd_git import cmd_git_branches
        cmd_git_branches(argparse.Namespace())

    elif cmd == 'git-diff':
        from .cmd_git import cmd_git_diff
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('--staged', action='store_true')
        cmd_git_diff(p.parse_args(rest))

    elif cmd == 'git-stash':
        from .cmd_git import cmd_git_stash
        cmd_git_stash(argparse.Namespace())

    elif cmd == 'tree':
        from .cmd_files import cmd_tree
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('path',    nargs='?')
        p.add_argument('-d','--depth', type=int)
        p.add_argument('-s','--size',  action='store_true')
        p.add_argument('-a','--hidden',action='store_true')
        cmd_tree(p.parse_args(rest))

    elif cmd == 'find':
        from .cmd_files import cmd_find
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('pattern', nargs='?', default='*')
        p.add_argument('path',    nargs='?')
        p.add_argument('-e','--ext')
        p.add_argument('--bigger', type=int, help='Min size in KB')
        cmd_find(p.parse_args(rest))

    elif cmd == 'wc':
        from .cmd_files import cmd_wc
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('file')
        cmd_wc(p.parse_args(rest))

    elif cmd == 'size':
        from .cmd_files import cmd_size
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('path', nargs='?')
        cmd_size(p.parse_args(rest))

    elif cmd == 'watch':
        from .cmd_files import cmd_watch
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('command')
        p.add_argument('-i','--interval', type=float)
        cmd_watch(p.parse_args(rest))

    elif cmd == 'sqlite':
        from .cmd_db import cmd_sqlite
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('db')
        p.add_argument('-q','--query')
        p.add_argument('-t','--table')
        p.add_argument('--schema',  action='store_true')
        p.add_argument('--export')
        p.add_argument('--limit',   type=int)
        cmd_sqlite(p.parse_args(rest))

    elif cmd == 'tg':
        from .cmd_tg import cmd_tg
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('--token')
        p.add_argument('--updates', action='store_true')
        p.add_argument('--chat')
        p.add_argument('--msg')
        p.add_argument('--webhook', action='store_true')
        cmd_tg(p.parse_args(rest))

    elif cmd == 'ai':
        from .cmd_ai import cmd_ai, PROVIDERS
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('prompt',     nargs='?', default='')
        p.add_argument('--file','-f')
        p.add_argument('--provider', choices=list(PROVIDERS.keys()))
        p.add_argument('--mode',     choices=['code','explain','fix','review','chat'])
        p.add_argument('--lang')
        p.add_argument('--key')
        cmd_ai(p.parse_args(rest))

    elif cmd == 'chat':
        from .cmd_ai import cmd_chat, PROVIDERS
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('--provider', choices=list(PROVIDERS.keys()))
        p.add_argument('--key')
        p.add_argument('--system')
        cmd_chat(p.parse_args(rest))

    elif cmd == 'commit':
        from .cmd_ai import cmd_commit, PROVIDERS
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('--provider', choices=list(PROVIDERS.keys()))
        p.add_argument('--key')
        p.add_argument('--apply', action='store_true')
        cmd_commit(p.parse_args(rest))

    elif cmd == 'readme':
        from .cmd_ai import cmd_readme, PROVIDERS
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('--file','-f')
        p.add_argument('--output','-o')
        p.add_argument('--provider', choices=list(PROVIDERS.keys()))
        p.add_argument('--key')
        p.add_argument('--print',    action='store_true')
        cmd_readme(p.parse_args(rest))

    elif cmd in ('translate','tr'):
        from .cmd_ai import cmd_translate_code, PROVIDERS
        p = argparse.ArgumentParser(add_help=False)
        p.add_argument('--to',       required=True)
        p.add_argument('--from',     dest='from_lang')
        p.add_argument('--file','-f')
        p.add_argument('code',       nargs='?')
        p.add_argument('--output','-o')
        p.add_argument('--provider', choices=list(PROVIDERS.keys()))
        p.add_argument('--key')
        cmd_translate_code(p.parse_args(rest))

    else:
        from .utils import c, RED, CYN
        print(f"\n{c(RED,'✗ Unknown command:')} {cmd}")
        print(f"  Run {c(CYN,'luckyget help')} to see all commands.\n")

if __name__ == '__main__':
    main()
