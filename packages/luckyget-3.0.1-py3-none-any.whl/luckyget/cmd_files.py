"""File system tools: tree, find, watch, wc, size."""
import os, time, subprocess, re, stat
from .utils import *

def cmd_tree(args):
    root     = os.path.expanduser(getattr(args,'path',None) or '.')
    max_depth = getattr(args,'depth',None) or 3
    show_hidden = getattr(args,'hidden',False)
    show_size   = getattr(args,'size',False)
    # file type colors
    EXT_COL = {
        '.py':CYN, '.js':YLW, '.ts':BLU, '.jsx':CYN, '.tsx':BLU,
        '.json':YLW, '.yaml':YLW, '.yml':YLW, '.toml':YLW,
        '.md':WHT, '.txt':WHT, '.rst':WHT,
        '.sh':GRN, '.bash':GRN, '.zsh':GRN,
        '.html':RED, '.css':MAG, '.scss':MAG,
        '.sql':BLU, '.db':BLU, '.sqlite':BLU,
        '.jpg':MAG, '.jpeg':MAG, '.png':MAG, '.gif':MAG, '.svg':MAG,
        '.zip':YLW, '.tar':YLW, '.gz':YLW, '.whl':YLW,
        '.env':RED, '.gitignore':DIM, '.dockerignore':DIM,
    }
    section(f'Tree: {root}'); print()
    dirs=0; files=0
    def walk(path, prefix='', depth=0):
        nonlocal dirs, files
        if depth > max_depth: return
        try: entries = sorted(os.listdir(path))
        except PermissionError: return
        entries = [e for e in entries if show_hidden or not e.startswith('.')]
        # dirs first
        entries = sorted(entries, key=lambda e: (0 if os.path.isdir(os.path.join(path,e)) else 1, e.lower()))
        for i, entry in enumerate(entries):
            full = os.path.join(path, entry)
            is_last = (i == len(entries)-1)
            conn  = '└── ' if is_last else '├── '
            child = '    ' if is_last else '│   '
            if os.path.isdir(full):
                dirs += 1
                print(f"  {prefix}{c(DIM,conn)}{c(B+BLU,entry)}/")
                walk(full, prefix+child, depth+1)
            else:
                files += 1
                ext  = os.path.splitext(entry)[1].lower()
                col  = EXT_COL.get(ext, WHT)
                size_str = ''
                if show_size:
                    try: size_str = f"  {c(DIM, format_size(os.path.getsize(full)))}"
                    except: pass
                print(f"  {prefix}{c(DIM,conn)}{c(col,entry)}{size_str}")
    walk(root)
    print(f"\n  {c(DIM, f'{dirs} directories, {files} files')}\n")

def cmd_find(args):
    root    = os.path.expanduser(getattr(args,'path',None) or '.')
    pattern = getattr(args,'pattern',None) or '*'
    ext     = getattr(args,'ext',None)
    size_gt = getattr(args,'bigger',None)
    name_re = re.compile(pattern.replace('*','.*').replace('?','.'), re.I)
    section(f'Find: {pattern} in {root}'); print()
    found = 0
    for dirpath, dirnames, filenames in os.walk(root):
        # Skip hidden dirs
        dirnames[:] = [d for d in dirnames if not d.startswith('.') and d not in ('node_modules','__pycache__','.git','venv','.venv')]
        for fname in filenames:
            if fname.startswith('.'): continue
            if ext and not fname.endswith(('.'+ext.lstrip('.'))):
                continue
            if not name_re.search(fname): continue
            full = os.path.join(dirpath, fname)
            try:
                sz = os.path.getsize(full)
                if size_gt and sz < size_gt*1024: continue
                rel = os.path.relpath(full, root)
                sz_str = format_size(sz)
                mtime = os.path.getmtime(full)
                age = fmt_age(time.time()-mtime)
                print(f"  {c(CYN, rel):<50} {c(DIM, sz_str):<10} {c(DIM, age)}")
                found += 1
            except: pass
    print(f"\n  {c(GRN if found else DIM, str(found)+' file(s) found')}\n")

def cmd_wc(args):
    path = os.path.expanduser(args.file)
    section(f'Word Count: {os.path.basename(path)}'); print()
    try:
        with open(path,'r',encoding='utf-8',errors='replace') as f:
            content = f.read()
        lines = content.count('\n') + (1 if content and not content.endswith('\n') else 0)
        words = len(content.split())
        chars = len(content)
        bytes_ = os.path.getsize(path)
        # Blank / comment lines (basic)
        blank   = sum(1 for l in content.split('\n') if not l.strip())
        comment = sum(1 for l in content.split('\n') if l.strip().startswith(('#','//','/*','*','--','<!--')))
        print(f"  {c(B,'Lines:  ')}  {c(GRN, str(lines))}")
        print(f"  {c(B,'Words:  ')}  {c(CYN, str(words))}")
        print(f"  {c(B,'Chars:  ')}  {c(YLW, str(chars))}")
        print(f"  {c(B,'Size:   ')}  {c(DIM, format_size(bytes_))}")
        print(f"  {c(DIM,'Blank lines:  ')} {blank}")
        print(f"  {c(DIM,'Comment lines:')} {comment}")
    except Exception as e:
        print(f"  {c(RED,'✗')} {e}")
    print()

def cmd_watch(args):
    cmd_str = args.command
    interval = getattr(args,'interval',None) or 2
    print(f"\n{c(CYN+B,'  Watch:')} {c(WHT, cmd_str)}")
    print(f"  {c(DIM, f'Every {interval}s — Ctrl+C to stop')}\n")
    try:
        while True:
            result = subprocess.run(cmd_str, shell=True, capture_output=True, text=True)
            # Clear screen
            print('\033[2J\033[H', end='')
            t = time.strftime('%H:%M:%S')
            print(f"\n{c(CYN+B,'  Watch')} {c(DIM,t)}: {c(WHT,cmd_str)}\n")
            if result.stdout: print(result.stdout)
            if result.stderr: print(c(RED, result.stderr[:200]))
            time.sleep(interval)
    except KeyboardInterrupt:
        print(f"\n{c(DIM,'Stopped.')}\n")

def cmd_size(args):
    """Show disk usage of a directory."""
    path = os.path.expanduser(getattr(args,'path',None) or '.')
    section(f'Disk Size: {path}'); print()
    entries = []
    try:
        for entry in sorted(os.listdir(path)):
            full = os.path.join(path, entry)
            if entry.startswith('.'): continue
            total = 0
            if os.path.isfile(full):
                total = os.path.getsize(full)
            elif os.path.isdir(full):
                for r,ds,fs in os.walk(full):
                    for f in fs:
                        try: total += os.path.getsize(os.path.join(r,f))
                        except: pass
            entries.append((total, entry, os.path.isdir(full)))
    except Exception as e:
        print(f"  {c(RED,'✗')} {e}\n"); return
    entries.sort(reverse=True)
    max_size = entries[0][0] if entries else 1
    for size, name, is_dir in entries[:30]:
        bar_len = int((size/max_size)*30) if max_size else 0
        bar     = c(CYN,'█')*bar_len + c(DIM,'░')*(30-bar_len)
        col     = BLU+B if is_dir else WHT
        suffix  = '/' if is_dir else ''
        print(f"  {c(col, name+suffix):<35} {bar} {c(YLW, format_size(size))}")
    print()
