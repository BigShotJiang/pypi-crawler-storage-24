"""Developer tools: json, jwt, uuid, ts, regex, url, encode, hash, diff, cron, color, lorem, httpcode."""
import json, re, hashlib, base64, uuid, time, datetime, os
import urllib.parse
from .utils import *

def cmd_json(args):
    raw = getattr(args,'input',None)
    if not raw:
        print(f"{DIM}Paste JSON (Ctrl+D to submit):{R}")
        raw = __import__('sys').stdin.read()
    try:
        parsed = json.loads(raw)
        kind   = 'object' if isinstance(parsed,dict) else 'array' if isinstance(parsed,list) else type(parsed).__name__
        count  = len(parsed) if hasattr(parsed,'__len__') else 1
        print(f"\n{c(GRN,'✓ Valid JSON')} {c(DIM,f'({kind}, {count} items, {format_size(len(raw))})')}\n")
        print(fmt_json(parsed)); print()
    except json.JSONDecodeError as e:
        print(f"\n{c(RED,'✗ Invalid JSON:')} {e}\n")

def cmd_jwt(args):
    token = args.token; section('JWT Decoder'); print()
    try:
        parts = token.split('.')
        if len(parts) != 3: raise ValueError("Not a valid JWT (need 3 parts separated by '.')")
        def decode_part(p):
            p += '=' * (4 - len(p)%4)
            return json.loads(base64.urlsafe_b64decode(p))
        header  = decode_part(parts[0])
        payload = decode_part(parts[1])
        print(f"  {c(B+BLU,'─ Header ─────────────────────────')}")
        print(fmt_json(header))
        print(f"\n  {c(B+GRN,'─ Payload ────────────────────────')}")
        print(fmt_json(payload))
        if 'exp' in payload:
            exp = datetime.datetime.fromtimestamp(payload['exp'])
            now = datetime.datetime.now()
            if exp < now:
                print(f"\n  {c(RED+B,'✗ EXPIRED')} {c(DIM,'at')} {exp.strftime('%Y-%m-%d %H:%M:%S')}")
            else:
                delta = int((exp-now).total_seconds())
                h, m = divmod(delta, 3600); m //= 60
                print(f"\n  {c(GRN+B,'✓ VALID')} {c(DIM,'until')} {exp.strftime('%Y-%m-%d %H:%M:%S')} {c(DIM,f'({h}h {m}m left)')}")
        if 'iat' in payload:
            iat = datetime.datetime.fromtimestamp(payload['iat'])
            print(f"  {c(DIM,'Issued at:')} {iat.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"\n  {c(DIM,'Alg: '+header.get('alg','?')+'  | Signature: [not verified]')}\n")
    except Exception as e:
        print(f"  {c(RED,'✗')} {e}\n")

def cmd_uuid(args):
    count  = getattr(args,'count',None) or 1
    upper  = getattr(args,'upper',False)
    ver    = getattr(args,'ver',None) or 4
    section(f'UUID v{ver} Generator ({count}x)'); print()
    gen = uuid.uuid4 if ver==4 else uuid.uuid1
    uuids = [str(gen()) for _ in range(count)]
    for u in uuids:
        s = u.upper() if upper else u
        print(f"  {c(GRN, s)}")
    if count == 1:
        u = uuids[0]
        print(f"\n  {c(DIM,'No dashes:')}  {c(CYN, u.replace('-',''))}")
        print(f"  {c(DIM,'Base64:   ')}  {c(YLW, base64.b64encode(bytes.fromhex(u.replace('-',''))).decode())}\n")
    else:
        print()

def cmd_ts(args):
    section('Timestamp Converter'); print()
    now = time.time()
    if getattr(args,'input',None):
        try:
            ts = float(args.input)
            if ts > 1e12: ts /= 1000
            dt     = datetime.datetime.fromtimestamp(ts)
            dt_utc = datetime.datetime.utcfromtimestamp(ts)
            print(f"  {c(B,'Unix:   ')}  {c(CYN,  str(int(ts)))}")
            print(f"  {c(B,'Unix ms:')}  {c(CYN,  str(int(ts*1000)))}")
            print(f"  {c(B,'Local:  ')}  {c(GRN,  dt.strftime('%Y-%m-%d %H:%M:%S'))}")
            print(f"  {c(B,'UTC:    ')}  {c(YLW,  dt_utc.strftime('%Y-%m-%d %H:%M:%S'))}")
            print(f"  {c(B,'ISO:    ')}  {c(WHT,  dt.isoformat())}")
            age = now - ts
            if age > 0: print(f"  {c(B,'Age:    ')}  {c(DIM, fmt_age(age))}")
        except: print(f"  {c(RED,'✗')} Invalid timestamp")
    else:
        dt     = datetime.datetime.now()
        dt_utc = datetime.datetime.utcnow()
        print(f"  {c(B,'Unix:   ')}  {c(CYN,  str(int(now)))}")
        print(f"  {c(B,'Unix ms:')}  {c(CYN,  str(int(now*1000)))}")
        print(f"  {c(B,'Local:  ')}  {c(GRN,  dt.strftime('%Y-%m-%d %H:%M:%S'))}")
        print(f"  {c(B,'UTC:    ')}  {c(YLW,  dt_utc.strftime('%Y-%m-%d %H:%M:%S'))}")
        print(f"  {c(B,'ISO:    ')}  {c(WHT,  dt.isoformat())}")
        print(f"  {c(B,'RFC2822:')}  {c(DIM,  dt.strftime('%a, %d %b %Y %H:%M:%S %z'))}")
    print()

def cmd_regex(args):
    pattern = args.pattern; text = args.text
    section('Regex Tester'); print()
    try:
        flags = re.IGNORECASE if getattr(args,'ignore_case',False) else 0
        r     = re.compile(pattern, flags)
        matches = list(r.finditer(text))
        if not matches:
            print(f"  {c(RED,'No matches')}\n"); return
        print(f"  {c(GRN, str(len(matches))+' match(es) found')}\n")
        for i, m in enumerate(matches):
            print(f"  {c(B+CYN,f'Match {i+1}:')} {c(GRN, repr(m.group()))}")
            print(f"           {c(DIM,'span:')} {m.start()}-{m.end()}")
            if m.groups():
                for j, g in enumerate(m.groups()):
                    print(f"           {c(DIM,f'group {j+1}:')} {c(YLW, repr(g))}")
            print()
        # Highlighted text
        result = text; offset = 0
        for m in matches:
            s = m.start()+offset; e = m.end()+offset
            hl = GRN+B+result[s:e]+R
            result = result[:s]+hl+result[e:]
            offset += len(GRN+B+R)
        print(f"  {c(B,'Preview:')} {result}\n")
    except re.error as e:
        print(f"  {c(RED,'✗ Invalid regex:')} {e}\n")

def cmd_url(args):
    url = args.url; section('URL Parser'); print()
    try:
        p  = urllib.parse.urlparse(url)
        qs = urllib.parse.parse_qs(p.query)
        print(f"  {c(B,'Scheme:  ')}  {c(CYN,  p.scheme or '(none)')}")
        print(f"  {c(B,'Host:    ')}  {c(GRN,  p.netloc or '(none)')}")
        print(f"  {c(B,'Path:    ')}  {c(YLW,  p.path or '/')}")
        if p.port:     print(f"  {c(B,'Port:    ')}  {c(CYN,  str(p.port))}")
        if p.username: print(f"  {c(B,'User:    ')}  {c(YLW,  p.username)}")
        if p.password: print(f"  {c(B,'Pass:    ')}  {c(DIM,  '***')}")
        if qs:
            print(f"\n  {c(B,'Query Params:')}")
            for k,v in qs.items():
                print(f"    {c(BLU,k)}: {c(WHT, ', '.join(v))}")
        if p.fragment: print(f"\n  {c(B,'Fragment:')}  {c(MAG, p.fragment)}")
        enc = urllib.parse.quote(url, safe=':/?#[]@!$&\'()*+,;=')
        print(f"\n  {c(B,'URL-encoded:')} {c(DIM, enc[:80])}")
        dec = urllib.parse.unquote(url)
        if dec != url: print(f"  {c(B,'URL-decoded:')} {c(DIM, dec[:80])}")
    except Exception as e:
        print(f"  {c(RED,'✗')} {e}")
    print()

def cmd_encode(args):
    text = args.text; section('Encode / Decode / Hash'); print()
    b = text.encode('utf-8')
    b64e = base64.b64encode(b).decode()
    print(f"  {c(B+BLU,'Base64 encode:')}  {c(GRN, b64e)}")
    try:
        b64d = base64.b64decode(text).decode('utf-8')
        print(f"  {c(B+BLU,'Base64 decode:')}  {c(YLW, b64d)}")
    except:
        print(f"  {c(B+BLU,'Base64 decode:')}  {c(DIM, '(not valid base64)')}")
    print(f"\n  {c(B+MAG,'URL encode:')}     {c(GRN, urllib.parse.quote(text))}")
    print(f"  {c(B+MAG,'URL decode:')}     {c(YLW, urllib.parse.unquote(text))}")
    # HTML entities
    html_e = text.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('"','&quot;')
    print(f"  {c(B+MAG,'HTML encode:')}    {c(GRN, html_e)}")
    print(f"\n  {c(B+CYN,'MD5:   ')}  {c(GRN, hashlib.md5(b).hexdigest())}")
    print(f"  {c(B+CYN,'SHA1:  ')}  {c(GRN, hashlib.sha1(b).hexdigest())}")
    print(f"  {c(B+CYN,'SHA256:')}  {c(GRN, hashlib.sha256(b).hexdigest())}")
    print(f"  {c(B+CYN,'SHA512:')}  {c(GRN, hashlib.sha512(b).hexdigest()[:64]+'...')}")
    print()

def cmd_hash(args):
    path = os.path.expanduser(args.file)
    section(f'File Hash: {os.path.basename(path)}'); print()
    try:
        data = open(path,'rb').read()
        print(f"  {c(B,'Size:  ')}  {c(YLW, format_size(len(data)))}")
        print(f"  {c(B,'MD5:   ')}  {c(GRN, hashlib.md5(data).hexdigest())}")
        print(f"  {c(B,'SHA1:  ')}  {c(GRN, hashlib.sha1(data).hexdigest())}")
        print(f"  {c(B,'SHA256:')}  {c(GRN, hashlib.sha256(data).hexdigest())}")
        print(f"  {c(B,'SHA512:')}  {c(GRN, hashlib.sha512(data).hexdigest())}")
        # verify against provided hash
        if getattr(args,'verify',None):
            expected = args.verify.strip().lower()
            actual   = hashlib.sha256(data).hexdigest()
            if actual == expected: print(f"\n  {c(GRN+B,'✓ Hash matches!')}")
            else:                  print(f"\n  {c(RED+B,'✗ Hash MISMATCH!')}")
    except Exception as e:
        print(f"  {c(RED,'✗')} {e}")
    print()

def cmd_diff(args):
    import difflib
    try:
        a = open(os.path.expanduser(args.file1)).readlines()
        b = open(os.path.expanduser(args.file2)).readlines()
    except Exception as e:
        print(f"\n{c(RED,'✗')} {e}\n"); return
    section(f'Diff: {os.path.basename(args.file1)} vs {os.path.basename(args.file2)}'); print()
    diff = list(difflib.unified_diff(a, b, fromfile=args.file1, tofile=args.file2, lineterm=''))
    if not diff:
        print(f"  {c(GRN,'Files are identical')}\n"); return
    adds = sum(1 for l in diff if l.startswith('+') and not l.startswith('+++'))
    dels = sum(1 for l in diff if l.startswith('-') and not l.startswith('---'))
    print(f"  {c(GRN, f'+{adds} additions')}  {c(RED, f'-{dels} deletions')}\n")
    for line in diff:
        if line.startswith('+'): print(c(GRN, line))
        elif line.startswith('-'): print(c(RED, line))
        elif line.startswith('@@'): print(c(CYN, line))
        else: print(c(DIM, line))
    print()

def cmd_httpcode(args):
    codes = {
        100:'Continue', 101:'Switching Protocols',
        200:'OK', 201:'Created', 202:'Accepted', 204:'No Content', 206:'Partial Content',
        301:'Moved Permanently', 302:'Found', 304:'Not Modified',
        307:'Temporary Redirect', 308:'Permanent Redirect',
        400:'Bad Request', 401:'Unauthorized', 403:'Forbidden', 404:'Not Found',
        405:'Method Not Allowed', 408:'Request Timeout', 409:'Conflict', 410:'Gone',
        413:'Payload Too Large', 418:"I'm a teapot", 422:'Unprocessable Entity',
        429:'Too Many Requests', 451:'Unavailable For Legal Reasons',
        500:'Internal Server Error', 501:'Not Implemented', 502:'Bad Gateway',
        503:'Service Unavailable', 504:'Gateway Timeout', 508:'Loop Detected',
    }
    desc = {
        200:'Standard success response.',
        201:'New resource created (POST/PUT).',
        204:'Success but no content to return.',
        301:'Permanent redirect — update bookmarks/links.',
        302:'Temporary redirect — keep original URL.',
        400:'Malformed request — check syntax/params.',
        401:'Not authenticated — need login/token.',
        403:'Authenticated but not authorized.',
        404:'Resource does not exist on this server.',
        405:'HTTP method not allowed for this endpoint.',
        408:'Server timed out waiting for the request.',
        409:'Request conflicts with current server state.',
        413:'Request body too large.',
        418:"Server refuses to brew coffee (RFC 2324).",
        422:'Well-formed but semantically invalid.',
        429:'Rate limited — slow down requests.',
        500:'Server-side error — not your fault.',
        502:'Reverse proxy received bad upstream response.',
        503:'Server unavailable — overloaded or maintenance.',
        504:'Gateway upstream timeout.',
    }
    code_input = getattr(args,'code',None)
    if code_input:
        code = int(code_input); sc = status_color(code)
        section(f'HTTP {code}'); print()
        print(f"  {c(sc+B, str(code))} {c(sc, codes.get(code,'Unknown'))}")
        if code in desc: print(f"\n  {c(DIM, desc[code])}")
    else:
        section('HTTP Status Codes'); print()
        groups = {
            '1xx Informational': [100,101],
            '2xx Success':       [200,201,202,204,206],
            '3xx Redirect':      [301,302,304,307,308],
            '4xx Client Error':  [400,401,403,404,405,408,409,410,413,418,422,429,451],
            '5xx Server Error':  [500,501,502,503,504,508],
        }
        for group, clist in groups.items():
            print(f"  {c(B+WHT, group)}")
            for cd in clist:
                sc = status_color(cd)
                print(f"    {c(sc, str(cd)):<14} {codes.get(cd,'')}")
            print()

def cmd_cron(args):
    expr = args.expr; section(f'Cron: {expr}'); print()
    parts = expr.split()
    if len(parts) not in (5, 6):
        print(f"  {c(RED,'✗')} Need 5 or 6 fields: [sec] min hour day month weekday\n"); return
    offset = 0 if len(parts)==5 else 1
    names  = ['Second','Minute','Hour','Day','Month','Weekday']
    month_n = {1:'Jan',2:'Feb',3:'Mar',4:'Apr',5:'May',6:'Jun',7:'Jul',8:'Aug',9:'Sep',10:'Oct',11:'Nov',12:'Dec'}
    dow_n   = {0:'Sun',1:'Mon',2:'Tue',3:'Wed',4:'Thu',5:'Fri',6:'Sat',7:'Sun'}
    def explain(val, name, mn=None):
        if val=='*': return f"every {name.lower()}"
        if val.startswith('*/'): return f"every {val[2:]} {name.lower()}(s)"
        if '-' in val: a,b=val.split('-',1); return f"{name} {a} through {b}"
        if ',' in val: items=val.split(','); return f"{name}s: {', '.join(items)}"
        if mn and val.isdigit(): return mn.get(int(val), val)
        return f"{name} {val}"
    field_names = names[offset:]
    mn_list     = [None,None,None,month_n,dow_n][offset:]
    for part, name, mn in zip(parts, field_names, mn_list):
        print(f"  {c(B, name+':'):<22} {c(CYN, part):<8} {c(DIM, explain(part,name,mn))}")
    common = {
        '0 * * * *':    'Every hour on the hour',
        '*/5 * * * *':  'Every 5 minutes',
        '0 0 * * *':    'Daily at midnight',
        '0 9 * * 1-5':  'Weekdays at 9am',
        '0 0 * * 0':    'Every Sunday at midnight',
        '0 0 1 * *':    'First of every month',
        '0 0 1 1 *':    'Once a year (Jan 1st)',
    }
    if expr in common: print(f"\n  {c(GRN, '→ '+common[expr])}")
    print()

def cmd_color(args):
    val = args.value; section(f'Color: {val}'); print()
    try:
        if val.startswith('#'):
            h = val.lstrip('#')
            if len(h)==3: h=''.join(cc*2 for cc in h)
            r,g,b = int(h[0:2],16), int(h[2:4],16), int(h[4:6],16)
        elif val.startswith('rgb'):
            nums = re.findall(r'\d+', val); r,g,b=int(nums[0]),int(nums[1]),int(nums[2])
        elif val.startswith('hsl'):
            nums = re.findall(r'[\d.]+', val)
            H,S,L = float(nums[0])/360, float(nums[1])/100, float(nums[2])/100
            def hue(p,q,t):
                if t<0: t+=1
                if t>1: t-=1
                if t<1/6: return p+(q-p)*6*t
                if t<1/2: return q
                if t<2/3: return p+(q-p)*(2/3-t)*6
                return p
            if S==0: r=g=b=int(L*255)
            else:
                q=L*(1+S) if L<0.5 else L+S-L*S; p=2*L-q
                r,g,b=int(hue(p,q,H+1/3)*255),int(hue(p,q,H)*255),int(hue(p,q,H-1/3)*255)
        else:
            raise ValueError("Use #hex, rgb(r,g,b), or hsl(h,s%,l%)")
        hex_val = f"#{r:02x}{g:02x}{b:02x}"
        # HSL
        r_,g_,b_ = r/255,g/255,b/255
        cmax,cmin = max(r_,g_,b_), min(r_,g_,b_); delta=cmax-cmin
        L2=(cmax+cmin)/2
        S2=0 if delta==0 else delta/(1-abs(2*L2-1))
        if delta==0: H2=0
        elif cmax==r_: H2=60*((g_-b_)/delta%6)
        elif cmax==g_: H2=60*((b_-r_)/delta+2)
        else:          H2=60*((r_-g_)/delta+4)
        preview = f"\033[48;2;{r};{g};{b}m        \033[0m"
        text_col = WHT if L2<0.5 else "\033[30m"
        print(f"\n  {preview}\n")
        print(f"  {c(B,'HEX:')}    {c(GRN, hex_val.upper())}")
        print(f"  {c(B,'RGB:')}    {c(YLW, f'rgb({r}, {g}, {b})')}")
        print(f"  {c(B,'HSL:')}    {c(CYN, f'hsl({H2:.0f}, {S2*100:.0f}%, {L2*100:.0f}%)')}")
        print(f"  {c(B,'ANSI fg:')} \\033[38;2;{r};{g};{b}m")
        print(f"  {c(B,'ANSI bg:')} \\033[48;2;{r};{g};{b}m")
        print(f"  {c(B,'CSS var:')} --color: {hex_val};")
    except Exception as e:
        print(f"  {c(RED,'✗')} {e}")
    print()

def cmd_lorem(args):
    words = ("lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor "
             "incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud "
             "exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat duis aute irure "
             "dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur "
             "excepteur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt "
             "mollit anim id est laborum").split()
    import random; random.seed()
    count = getattr(args,'count',None) or 1
    fmt   = getattr(args,'format',None) or 'para'
    section(f'Lorem Ipsum'); print()
    for _ in range(count):
        n = random.randint(50, 90)
        ws = random.choices(words, k=n)
        ws[0] = ws[0].capitalize()
        # Add sentence breaks
        para = ''; i = 0
        while i < len(ws):
            s_len = random.randint(8,16); chunk=ws[i:i+s_len]; i+=s_len
            chunk[-1] = chunk[-1].rstrip('.') + '.'
            chunk[0]  = chunk[0].capitalize()
            para += ' '.join(chunk) + ' '
        print(f"  {para.strip()}\n")
