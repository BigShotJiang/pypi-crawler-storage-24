"""Network & security recon commands: dns, ports, ip, ssl, whois, tech."""
import socket, time, threading, json, ssl as ssl_mod, datetime
import urllib.request, urllib.error
from .utils import *

UA = 'luckyget/3.0'

def cmd_dns(args):
    host = args.host; section(f'DNS Lookup -> {host}'); print()
    try:
        ips = socket.getaddrinfo(host, None); seen = set()
        for r in ips:
            ip = r[4][0]; fam = 'IPv6' if r[0].name=='AF_INET6' else 'IPv4'
            if ip not in seen:
                seen.add(ip)
                print(f"  {c(BLU, fam):<20} {c(GRN, ip)}")
        try:
            rev = socket.gethostbyaddr(list(seen)[0])[0]
            print(f"\n  {c(B,'Reverse:')}  {c(YLW, rev)}")
        except: pass
    except Exception as e:
        print(f"  {c(RED,'X')} {e}")
    print()

def cmd_ports(args):
    host = args.host
    common = {
        21:'FTP', 22:'SSH', 23:'Telnet', 25:'SMTP', 53:'DNS',
        80:'HTTP', 110:'POP3', 143:'IMAP', 443:'HTTPS', 445:'SMB',
        3000:'Node.js', 3306:'MySQL', 5432:'PostgreSQL', 5900:'VNC',
        6379:'Redis', 8000:'Django', 8080:'HTTP-alt', 8443:'HTTPS-alt',
        8888:'Jupyter', 9200:'Elasticsearch', 27017:'MongoDB',
        4200:'Angular', 3001:'React-dev', 5000:'Flask', 5173:'Vite',
        4000:'Phoenix', 9000:'PHP-FPM', 11211:'Memcached',
        2181:'Zookeeper', 9092:'Kafka', 5672:'RabbitMQ',
        1433:'MSSQL', 1521:'Oracle', 6443:'Kubernetes',
    }
    ports = getattr(args,'ports',None) or list(common.keys())
    try: ip = socket.gethostbyname(host)
    except: ip = host
    timeout = getattr(args,'timeout',None) or 0.8
    section(f'Port Scanner -> {host} ({ip})')
    print(f"  Scanning {c(YLW, str(len(ports)))} ports...\n")
    open_ports = []; lock = threading.Lock()
    def scan(port):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(timeout); result = s.connect_ex((ip,port)); s.close()
            if result == 0:
                svc = common.get(port, 'unknown')
                with lock:
                    open_ports.append((port,svc))
                    print(f"  {c(GRN,'OPEN'):<14} {c(B, str(port)):<10} {c(DIM, svc)}")
        except: pass
    threads = [threading.Thread(target=scan, args=(p,)) for p in ports]
    for t in threads: t.start()
    for t in threads: t.join()
    if not open_ports: print(f"  {c(DIM,'No open ports found')}")
    print(f"\n  {c(B,'Open:')} {c(GRN if open_ports else RED, str(len(open_ports)))} / {len(ports)} scanned\n")

def cmd_ip(args):
    section('IP Info'); print()
    target = getattr(args,'host',None) or ''
    try:
        req = urllib.request.Request(
            f"https://ipinfo.io/{target}/json",
            headers={'User-Agent': UA, 'Accept': 'application/json'}
        )
        with urllib.request.urlopen(req, timeout=8) as r:
            data = json.loads(r.read())
        fields = ['ip','city','region','country','org','timezone','loc']
        labels = {'ip':'IP','city':'City','region':'Region','country':'Country',
                  'org':'Org','timezone':'Timezone','loc':'Coords'}
        for f in fields:
            if f in data:
                print(f"  {c(B, labels.get(f,f)+':'):<18} {c(GRN if f=='ip' else WHT, data[f])}")
    except Exception as e:
        print(f"  {c(RED,'X')} {e}")
    print()

def cmd_ssl(args):
    host = args.host.replace('https://','').replace('http://','').split('/')[0]
    port = getattr(args,'port',None) or 443
    section(f'SSL Certificate -> {host}:{port}'); print()
    try:
        ctx = ssl_mod.create_default_context()
        with ctx.wrap_socket(socket.socket(), server_hostname=host) as s:
            s.settimeout(10); s.connect((host, port))
            cert = s.getpeercert()
        subject = dict(x[0] for x in cert.get('subject',[]))
        issuer  = dict(x[0] for x in cert.get('issuer',[]))
        not_before = cert.get('notBefore','')
        not_after  = cert.get('notAfter','')
        # Parse expiry
        try:
            exp = datetime.datetime.strptime(not_after, '%b %d %H:%M:%S %Y %Z')
            now = datetime.datetime.utcnow()
            days_left = (exp - now).days
            exp_col = GRN if days_left > 30 else (YLW if days_left > 7 else RED)
            exp_str = f"{exp.strftime('%Y-%m-%d')} {c(exp_col, f'({days_left}d left)')}"
        except:
            exp_str = not_after
        print(f"  {c(B,'Common Name:  ')} {c(GRN, subject.get('commonName','?'))}")
        print(f"  {c(B,'Organization: ')} {subject.get('organizationName','?')}")
        print(f"  {c(B,'Issuer:       ')} {issuer.get('organizationName','?')}")
        print(f"  {c(B,'Valid From:   ')} {not_before}")
        print(f"  {c(B,'Expires:      ')} {exp_str}")
        sans = cert.get('subjectAltName',[])
        if sans:
            print(f"  {c(B,'SANs:         ')} {c(DIM, ', '.join(v for _,v in sans[:6]))}")
        version = cert.get('version',0)
        print(f"  {c(B,'Version:      ')} {version}")
    except ssl_mod.SSLCertVerificationError as e:
        print(f"  {c(RED,'X SSL Error:')} {e}")
    except Exception as e:
        print(f"  {c(RED,'X')} {e}")
    print()

def cmd_tech(args):
    """Detect tech stack of a website."""
    url = args.url
    if not url.startswith('http'): url = 'https://' + url
    section(f'Tech Stack -> {url}'); print()
    try:
        req = urllib.request.Request(url, headers={'User-Agent': UA})
        with urllib.request.urlopen(req, timeout=10) as r:
            headers = dict(r.headers)
            body = r.read().decode('utf-8', errors='replace')[:10000]
            status = r.status
    except urllib.error.HTTPError as e:
        headers = dict(e.headers); body = ''; status = e.code
    except Exception as e:
        print(f"  {c(RED,'X')} {e}\n"); return

    detections = []

    # Server / language headers
    for hdr in ['server','x-powered-by','x-aspnet-version','x-generator']:
        val = headers.get(hdr,'') or headers.get(hdr.title(),'')
        if val: detections.append((hdr.title(), val, WHT))

    # Body fingerprints
    sigs = [
        ('React',           r'react\.js|react-dom|__NEXT_DATA__',           CYN),
        ('Next.js',         r'__NEXT_DATA__|/_next/static',                  CYN),
        ('Vue.js',          r'vue\.js|vue\.min\.js|__VUE__',                 GRN),
        ('Angular',         r'ng-version|angular\.js|angular\.min',          RED),
        ('jQuery',          r'jquery\.js|jquery\.min\.js',                   BLU),
        ('Bootstrap',       r'bootstrap\.css|bootstrap\.min\.css',           MAG),
        ('Tailwind',        r'tailwind\.css|tw-',                            CYN),
        ('WordPress',       r'wp-content|wp-includes|wordpress',             BLU),
        ('Shopify',         r'cdn\.shopify\.com|shopify\.com/s/',            GRN),
        ('Laravel',         r'laravel_session|laravel',                      RED),
        ('Django',          r'csrftoken|django',                             GRN),
        ('Flask',           r'werkzeug|flask',                               YLW),
        ('Rails',           r'rails|ruby on rails|_rails_',                  RED),
        ('Express',         r'express',                                      YLW),
        ('FastAPI',         r'fastapi',                                      GRN),
        ('GraphQL',         r'graphql|__schema',                             MAG),
        ('Google Analytics',r'google-analytics|gtag\(',                      YLW),
        ('Cloudflare',      r'cloudflare|__cf_bm',                          YLW),
    ]
    import re
    for name, pattern, col in sigs:
        if re.search(pattern, body, re.I):
            detections.append(('Framework/Lib', f"{c(col,name)}", ''))

    # Cookies
    cookies = headers.get('Set-Cookie','') or headers.get('set-cookie','')
    cookie_sigs = {'PHPSESSID':'PHP','JSESSIONID':'Java','ASP.NET_SessionId':'ASP.NET',
                   'laravel_session':'Laravel','django':'Django'}
    for k,v in cookie_sigs.items():
        if k.lower() in cookies.lower(): detections.append(('Cookie hint', v, YLW))

    if detections:
        for label, val, col in detections:
            print(f"  {c(B, label+':'):<22} {val}")
    else:
        print(f"  {c(DIM,'No known tech detected')}")
    print()

def cmd_whois(args):
    """Basic WHOIS via RDAP (no external libs needed)."""
    domain = args.domain.replace('https://','').replace('http://','').split('/')[0]
    section(f'WHOIS -> {domain}'); print()
    try:
        # Try RDAP first (JSON, easy to parse)
        req = urllib.request.Request(
            f"https://rdap.org/domain/{domain}",
            headers={'User-Agent': UA, 'Accept': 'application/json'}
        )
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read())
        # Events (created, expires, updated)
        for ev in data.get('events',[]):
            action = ev.get('eventAction','')
            date   = ev.get('eventDate','')[:10]
            col = {'registration':GRN,'expiration':RED,'last changed':YLW}.get(action,DIM)
            print(f"  {c(B, action.title()+':'):<22} {c(col, date)}")
        # Status
        status = data.get('status',[])
        if status: print(f"  {c(B,'Status:'):<22} {c(GRN, ', '.join(status[:3]))}")
        # Nameservers
        ns = [n.get('ldhName','') for n in data.get('nameservers',[])]
        if ns: print(f"  {c(B,'Nameservers:'):<22} {c(DIM, ', '.join(ns[:4]))}")
        # Registrar
        for entity in data.get('entities',[]):
            roles = entity.get('roles',[])
            if 'registrar' in roles:
                vcard = entity.get('vcardArray',[None,None])[1] or []
                for field in vcard:
                    if field[0] == 'fn':
                        print(f"  {c(B,'Registrar:'):<22} {field[3]}")
    except urllib.error.HTTPError as e:
        print(f"  {c(RED,'X')} RDAP returned {e.code} — domain may not exist or unsupported TLD")
    except Exception as e:
        print(f"  {c(RED,'X')} {e}")
    print()
