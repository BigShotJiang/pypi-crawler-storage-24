"""Git helper commands: log, status, branch, stash, commits."""
import subprocess, os, re
from .utils import *

def _git(args, cwd=None):
    try:
        result = subprocess.run(
            ['git'] + args,
            capture_output=True, text=True,
            cwd=cwd or os.getcwd()
        )
        return result.stdout, result.returncode
    except FileNotFoundError:
        return None, -1

def _check_git():
    out, code = _git(['rev-parse','--is-inside-work-tree'])
    if code != 0:
        print(f"\n  {c(RED,'✗')} Not a git repository (or git not installed)\n")
        return False
    return True

def cmd_git_log(args):
    if not _check_git(): return
    count  = getattr(args,'count',None) or 20
    all_b  = getattr(args,'all',False)
    section('Git Log'); print()
    extra = ['--all'] if all_b else []
    out, _ = _git(['log', f'--max-count={count}',
                   '--pretty=format:%H|%an|%ae|%ar|%s|%D',
                   '--date=relative'] + extra)
    if not out: print(f"  {c(DIM,'No commits found')}\n"); return
    for line in out.strip().split('\n'):
        parts = line.split('|', 5)
        if len(parts) < 5: continue
        sha, author, email, when, msg, refs = (parts+[''])[:6]
        sha_short = sha[:7]
        # Color by message prefix
        msg_col = WHT
        if re.match(r'^(fix|bug)', msg, re.I):    msg_col = RED
        elif re.match(r'^(feat|add)', msg, re.I): msg_col = GRN
        elif re.match(r'^(refactor|clean)', msg, re.I): msg_col = BLU
        elif re.match(r'^(docs|readme)', msg, re.I): msg_col = YLW
        elif re.match(r'^(chore|ci|build)', msg, re.I): msg_col = DIM
        ref_str = ''
        if refs.strip():
            ref_parts = [r.strip() for r in refs.split(',') if r.strip()]
            ref_str = '  ' + ' '.join(
                c(YLW+B, f'[{r}]') if 'HEAD' in r else c(GRN, f'({r})')
                for r in ref_parts[:3]
            )
        print(f"  {c(CYN, sha_short)} {c(msg_col, msg[:55])}{ref_str}")
        print(f"           {c(DIM, author)} · {c(DIM, when)}")
    print()

def cmd_git_status(args):
    if not _check_git(): return
    section('Git Status'); print()
    # Branch
    branch_out, _ = _git(['branch','--show-current'])
    branch = branch_out.strip()
    ahead_out, _ = _git(['rev-list','--count',f'HEAD...@{{u}}'])
    ahead = ahead_out.strip() if ahead_out else '0'
    print(f"  {c(B,'Branch:')} {c(GRN+B, branch)} {c(DIM,'ahead by '+ahead) if ahead!='0' else ''}")
    # Last commit
    last_out, _ = _git(['log','-1','--pretty=format:%h %ar — %s'])
    if last_out: print(f"  {c(B,'Last:  ')} {c(DIM, last_out.strip())}")
    print()
    out, _ = _git(['status','--porcelain'])
    if not out: print(f"  {c(GRN,'✓ Clean working tree')}\n"); return
    staged = []; modified = []; untracked = []; deleted = []
    for line in out.strip().split('\n'):
        if len(line) < 3: continue
        xy = line[:2]; fname = line[3:]
        if xy[0] in 'MADRC': staged.append((xy[0], fname))
        if xy[1] == 'M': modified.append(fname)
        if xy[1] == 'D': deleted.append(fname)
        if xy == '??': untracked.append(fname)
    if staged:
        print(f"  {c(GRN+B,'Staged:')}")
        for s, f in staged:
            sym = {'M':'Modified','A':'Added','D':'Deleted','R':'Renamed','C':'Copied'}.get(s,s)
            print(f"    {c(GRN,'+')} {c(GRN, sym):<12} {f}")
    if modified:
        print(f"\n  {c(YLW+B,'Modified:')}")
        for f in modified: print(f"    {c(YLW,'~')} {f}")
    if deleted:
        print(f"\n  {c(RED+B,'Deleted:')}")
        for f in deleted: print(f"    {c(RED,'-')} {f}")
    if untracked:
        print(f"\n  {c(DIM,'Untracked:')} ({len(untracked)} files)")
        for f in untracked[:5]: print(f"    {c(DIM,'?')} {f}")
        if len(untracked)>5: print(f"    {c(DIM,f'... and {len(untracked)-5} more')}")
    print()

def cmd_git_branches(args):
    if not _check_git(): return
    section('Git Branches'); print()
    out, _ = _git(['branch','-vv','--sort=-committerdate'])
    current_out, _ = _git(['branch','--show-current'])
    current = current_out.strip()
    if not out: print(f"  {c(DIM,'No branches')}\n"); return
    for line in out.strip().split('\n'):
        line = line.strip()
        is_cur = line.startswith('*')
        line   = line.lstrip('* ').strip()
        parts  = line.split(None, 2)
        bname  = parts[0] if parts else line
        sha    = parts[1] if len(parts)>1 else ''
        msg    = parts[2] if len(parts)>2 else ''
        col    = GRN+B if is_cur else WHT
        cur_sym = c(GRN,'*') if is_cur else ' '
        print(f"  {cur_sym} {c(col, bname):<30} {c(CYN, sha[:7]):<10} {c(DIM, msg[:40])}")
    print()

def cmd_git_diff(args):
    if not _check_git(): return
    staged = getattr(args,'staged',False)
    section('Git Diff'); print()
    extra = ['--staged'] if staged else []
    out, _ = _git(['diff','--stat'] + extra)
    if not out: print(f"  {c(DIM,'No changes' if not staged else 'No staged changes')}\n"); return
    lines = out.strip().split('\n')
    for line in lines[:-1]:
        parts = line.split('|')
        if len(parts)==2:
            fname, changes = parts
            changes = changes.strip()
            adds = changes.count('+'); dels = changes.count('-')
            print(f"  {fname.strip():<40} {c(GRN, '+'*min(adds,20))}{c(RED, '-'*min(dels,20))}")
    print(f"\n  {c(DIM, lines[-1].strip())}\n")

def cmd_git_stash(args):
    if not _check_git(): return
    section('Git Stash List'); print()
    out, _ = _git(['stash','list','--pretty=format:%gd|%ar|%s'])
    if not out: print(f"  {c(DIM,'Stash is empty')}\n"); return
    for line in out.strip().split('\n'):
        parts = line.split('|',2)
        name, when, msg = (parts+['','',''])[:3]
        print(f"  {c(CYN, name):<16} {c(DIM, when):<20} {c(WHT, msg)}")
    print()
