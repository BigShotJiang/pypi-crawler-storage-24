"""Telegram bot tester."""
import os, json
import urllib.request
from .utils import *

def cmd_tg(args):
    token = getattr(args,'token',None) or os.environ.get('TELEGRAM_BOT_TOKEN')
    if not token:
        print(f"\n{c(RED,'✗ No token!')}  export TELEGRAM_BOT_TOKEN='...'\n"
              f"  or: luckyget tg --token <token>\n")
        return
    base = f"https://api.telegram.org/bot{token}"

    def tg_call(endpoint, data=None):
        url     = f"{base}/{endpoint}"
        payload = json.dumps(data).encode() if data else None
        req     = urllib.request.Request(url, data=payload,
                      headers={'Content-Type':'application/json'} if payload else {})
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.loads(r.read())

    section('Telegram Bot Tester'); print()
    try:
        me = tg_call('getMe')['result']
        print(f"  {c(GRN+B,'✓')} {c(B, me.get('first_name','?'))} {c(DIM,'@'+me.get('username','?'))}")
        print(f"  {c(DIM,'ID:')} {me.get('id')}  "
              f"{c(DIM,'Bot:')} {me.get('is_bot')}  "
              f"{c(DIM,'Inline:')} {me.get('supports_inline_queries',False)}")
    except Exception as e:
        print(f"  {c(RED,'✗')} {e}"); return

    if getattr(args,'updates',False):
        try:
            upd = tg_call('getUpdates?limit=10&offset=-10')['result']
            if not upd:
                print(f"\n  {c(DIM,'No recent updates')}")
            else:
                print(f"\n  {c(B,'Recent Updates:')}")
                for u in upd[-10:]:
                    msg  = u.get('message') or u.get('channel_post') or {}
                    fr   = msg.get('from') or msg.get('sender_chat') or {}
                    txt  = msg.get('text') or msg.get('caption') or '[no text]'
                    chat = msg.get('chat',{})
                    uname= fr.get('first_name') or fr.get('title') or '?'
                    cid  = chat.get('id','?')
                    print(f"  {c(YLW, str(uname)):<20} {c(DIM,'chat:'+str(cid)):<20} {c(WHT,txt[:50])}")
        except Exception as e:
            print(f"\n  {c(RED,'✗')} {e}")

    chat_id = getattr(args,'chat',None)
    msg_txt = getattr(args,'msg',None)
    if chat_id and msg_txt:
        try:
            result = tg_call('sendMessage', {
                'chat_id': chat_id,
                'text': msg_txt,
                'parse_mode': 'HTML'
            })
            mid = result.get('result',{}).get('message_id','?')
            print(f"\n  {c(GRN+B,'✓ Sent!')} message_id={mid} to chat {chat_id}")
        except Exception as e:
            print(f"\n  {c(RED,'✗')} {e}")

    if getattr(args,'webhook',False):
        try:
            info = tg_call('getWebhookInfo')['result']
            print(f"\n  {c(B,'Webhook:')}")
            print(f"  URL:           {c(CYN, info.get('url','(not set)'))}")
            print(f"  Pending:       {info.get('pending_update_count',0)}")
            print(f"  Last error:    {c(RED, info.get('last_error_message','none'))}")
        except Exception as e:
            print(f"\n  {c(RED,'✗')} {e}")
    print()
