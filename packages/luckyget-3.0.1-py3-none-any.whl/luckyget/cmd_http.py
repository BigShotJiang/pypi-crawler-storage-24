"""HTTP commands: get, post, put, delete, patch, head, status, ping, headers, mock."""
import time, json, threading, datetime
import urllib.request, urllib.error, urllib.parse
from .utils import *

UA = 'luckyget/3.0'

def _request(url, method='GET', headers=None, body=None, timeout=10):
    h = {'User-Agent': UA}
    if headers: h.update(headers)
    req = urllib.request.Request(url, data=body, headers=h, method=method)
    return urllib.request.urlopen(req, timeout=timeout)

def cmd_get(args):
    url = args.url
    if not url.startswith('http'): url = 'https://' + url
    method = (getattr(args,'method',None) or 'GET').upper()
    headers = {}
    body = None
    if getattr(args,'json',False): headers.update({'Content-Type':'application/json','Accept':'application/json'})
    if getattr(args,'header',None):
        for h in args.header:
            if ':' in h: k,v=h.split(':',1); headers[k.strip()]=v.strip()
    if getattr(args,'bearer',None): headers['Authorization'] = f'Bearer {args.bearer}'
    if getattr(args,'data',None): body = args.data.encode()
    timeout = getattr(args,'timeout',None) or 10

    print(f"\n{DIM}-> {method} {url}{R}\n{DIM}{'-'*52}{R}")
    t0 = time.time()
    try:
        req = urllib.request.Request(url, data=body, headers={'User-Agent':UA,**headers}, method=method)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            elapsed = (time.time()-t0)*1000
            raw = resp.read(); code = resp.status
            rh = dict(resp.headers); sc = status_color(code)
            print(f"  {c(B,'Status:')}  {c(sc, str(code)+' '+resp.reason)}")
            print(f"  {c(B,'Time:  ')}  {c(CYN, format_ms(elapsed))}")
            print(f"  {c(B,'Size:  ')}  {c(YLW, format_size(len(raw)))}")
            if getattr(args,'verbose',False):
                print(f"\n{c(B,'Headers:')}")
                for k,v in rh.items(): print(f"  {c(DIM,k+':')} {v}")
            print(f"\n{c(B,'Body:')}\n{DIM}{'-'*52}{R}")
            try:
                decoded = raw.decode('utf-8')
                ct = rh.get('Content-Type','')
                if 'json' in ct or getattr(args,'json',False):
                    print(fmt_json(json.loads(decoded)))
                elif len(decoded) > 3000 and not getattr(args,'full',False):
                    print(decoded[:3000])
                    print(f"\n{c(DIM,'... truncated. Use --full to see all')}")
                else:
                    print(decoded)
            except:
                print(f"{YLW}[binary {format_size(len(raw))}]{R}")
    except urllib.error.HTTPError as e:
        sc = status_color(e.code)
        print(f"  {c(B,'Status:')}  {c(sc, str(e.code)+' '+e.reason)}")
        try:
            bd = e.read().decode()
            try: print(fmt_json(json.loads(bd)))
            except: print(bd[:800])
        except: pass
    except Exception as e:
        print(f"\n{c(RED,'X')} {e}")
    print()

def cmd_status(args):
    section('Site Status Check')
    print(f"  {'URL':<38} {'STATUS':<12} {'TIME':<10} SIZE")
    print(f"  {c(DIM,'-'*62)}")
    lock = threading.Lock()
    def check(url):
        u = url if url.startswith('http') else 'https://'+url
        t0 = time.time()
        try:
            req = urllib.request.Request(u, headers={'User-Agent':UA})
            with urllib.request.urlopen(req, timeout=getattr(args,'timeout',None) or 8) as r:
                ms=(time.time()-t0)*1000; raw=r.read(); sc=status_color(r.status)
                short=u.replace('https://','').replace('http://','')[:36]
                with lock: print(f"  {short:<38} {c(sc,str(r.status)+' OK'):<20} {c(CYN,format_ms(ms)):<18} {c(YLW,format_size(len(raw)))}")
        except urllib.error.HTTPError as e:
            ms=(time.time()-t0)*1000; sc=status_color(e.code)
            short=u.replace('https://','').replace('http://','')[:36]
            with lock: print(f"  {short:<38} {c(sc,str(e.code)+' ERR'):<20} {c(CYN,format_ms(ms)):<18} {c(DIM,'-')}")
        except:
            short=u.replace('https://','').replace('http://','')[:36]
            with lock: print(f"  {short:<38} {c(RED,'TIMEOUT'):<20} {c(DIM,'-'):<18} {c(DIM,'-')}")
    threads=[threading.Thread(target=check,args=(u,)) for u in args.urls]
    for t in threads: t.start()
    for t in threads: t.join()
    print()

def cmd_ping(args):
    url = args.url
    if not url.startswith('http'): url = 'https://'+url
    count = getattr(args,'count',None) or 4
    section(f'HTTP Ping -> {url}')
    print(f"  {c(DIM,f'({count} requests)')}\n")
    times = []
    for i in range(count):
        t0 = time.time()
        try:
            req = urllib.request.Request(url, headers={'User-Agent':UA}, method='HEAD')
            with urllib.request.urlopen(req, timeout=10) as r:
                ms=(time.time()-t0)*1000; times.append(ms)
                bar=c(CYN,'|')*min(int(ms/15),40); sc=status_color(r.status)
                print(f"  [{i+1}] {c(sc,str(r.status))}  {c(CYN,f'{ms:>7.1f}ms')}  {bar}")
        except Exception as e:
            print(f"  [{i+1}] {c(RED,'FAIL')}  {c(DIM,str(e)[:40])}")
        time.sleep(0.4)
    if times:
        avg = sum(times)/len(times)
        print(f"\n  {c(B,'Min:')} {c(GRN,format_ms(min(times)))}  {c(B,'Avg:')} {c(YLW,format_ms(avg))}  {c(B,'Max:')} {c(RED,format_ms(max(times)))}\n")

def cmd_headers(args):
    url = args.url
    if not url.startswith('http'): url = 'https://'+url
    section(f'Headers -> {url}'); print()
    try:
        req = urllib.request.Request(url, headers={'User-Agent':UA}, method='HEAD')
        with urllib.request.urlopen(req, timeout=10) as r:
            sc = status_color(r.status)
            print(f"  {c(B,'HTTP')} {c(sc, str(r.status)+' '+r.reason)}\n")
            hl = {'content-type','server','x-powered-by','cache-control','strict-transport-security',
                  'x-frame-options','content-security-policy','x-content-type-options'}
            for k,v in r.headers.items():
                col = BLU if k.lower() in hl else DIM
                print(f"  {c(col+B, k+':'):<35} {v}")
    except Exception as e:
        print(f"  {c(RED,'X')} {e}")
    print()

def cmd_mock(args):
    import http.server
    port      = getattr(args,'port',None)  or 8888
    resp_body = getattr(args,'body',None)  or '{"status":"ok","mock":true}'
    resp_code = getattr(args,'code',None)  or 200
    resp_ct   = getattr(args,'ct',None)    or 'application/json'
    delay_ms  = getattr(args,'delay',None) or 0

    class MockHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self): self._r()
        def do_POST(self): self._r()
        def do_PUT(self): self._r()
        def do_DELETE(self): self._r()
        def do_PATCH(self): self._r()
        def do_OPTIONS(self): self._r()
        def _r(self):
            bb = resp_body.encode()
            t  = datetime.datetime.now().strftime('%H:%M:%S')
            cl = self.headers.get('Content-Length','0'); rb=''
            if cl and int(cl)>0: rb=self.rfile.read(int(cl)).decode()
            method_col = {
                'GET':c(GRN,'GET'),'POST':c(YLW,'POST'),'PUT':c(BLU,'PUT'),
                'DELETE':c(RED,'DELETE'),'PATCH':c(MAG,'PATCH'),'OPTIONS':c(DIM,'OPTIONS'),
            }.get(self.command, self.command)
            print(f"  {c(DIM,t)} {method_col:<20} {c(CYN,self.path)}")
            if rb: print(f"    {c(DIM,'body:')} {rb[:120]}")
            if delay_ms: time.sleep(delay_ms/1000)
            self.send_response(resp_code)
            self.send_header('Content-Type', resp_ct)
            self.send_header('Content-Length', str(len(bb)))
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Access-Control-Allow-Methods', '*')
            self.send_header('Access-Control-Allow-Headers', '*')
            self.end_headers(); self.wfile.write(bb)
        def log_message(self, *a): pass

    section(f'Mock Server -> :{port}')
    print(f"\n  {c(B,'Status:')}  {c(GRN if resp_code<300 else YLW, str(resp_code))}")
    print(f"  {c(B,'Body:  ')}  {resp_body[:60]}")
    print(f"  {c(B,'URL:   ')}  {c(CYN, f'http://localhost:{port}')}")
    if delay_ms: print(f"  {c(B,'Delay: ')}  {c(YLW, str(delay_ms)+'ms')}")
    print(f"\n  {c(DIM,'Ctrl+C to stop')}\n")
    server = http.server.HTTPServer(('', port), MockHandler)
    try: server.serve_forever()
    except KeyboardInterrupt: print(f"\n  {c(YLW,'Stopped.')}\n")
