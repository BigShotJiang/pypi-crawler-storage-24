"""Inference module."""

from .predictor import Predictor

__all__ = ["Predictor"]
