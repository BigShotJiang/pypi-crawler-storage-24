"""CLI entry points for COMBO."""
