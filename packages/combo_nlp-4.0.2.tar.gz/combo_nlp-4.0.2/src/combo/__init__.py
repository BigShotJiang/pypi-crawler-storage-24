"""COMBO — Universal Dependencies parser with composable NLP pipelines."""

__version__ = "4.0.2"

from .api import COMBO
from .data.conllu_reader import Document, Sentence, Token
from .languages import Language
from .pipeline import Pipeline

__all__ = [
    "COMBO",
    "Language",
    "Pipeline",
    "Document",
    "Sentence",
    "Token",
]
