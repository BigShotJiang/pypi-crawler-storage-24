"""CoNLL-U format writer."""

from pathlib import Path

from .conllu_reader import Sentence


class CoNLLUWriter:
    """Writer for CoNLL-U format files."""

    @staticmethod
    def write(sentences: list[Sentence], file_path: Path) -> None:
        """Write sentences to a CoNLL-U file.

        Args:
            sentences: List of sentences.
            file_path: Output file path.
        """
        file_path.parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, "w", encoding="utf-8") as f:
            for sent in sentences:
                f.write(sent.to_conllu() + "\n")

    @staticmethod
    def to_string(sentences: list[Sentence]) -> str:
        """Convert sentences to CoNLL-U format string.

        Args:
            sentences: List of sentences.

        Returns:
            CoNLL-U formatted string.
        """
        result = "\n".join(sent.to_conllu() for sent in sentences)
        if result and not result.endswith("\n\n"):
            result += "\n"
        return result
