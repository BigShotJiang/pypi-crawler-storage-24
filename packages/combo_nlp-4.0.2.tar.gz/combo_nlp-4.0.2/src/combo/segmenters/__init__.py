"""Text segmentation components for the COMBO pipeline."""

from .base import BaseSegmenter

__all__ = [
    "BaseSegmenter",
]

# Lazy import for optional dependency
def __getattr__(name: str):
    if name == "LamboSegmenter":
        from .lambo import LamboSegmenter
        return LamboSegmenter
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
