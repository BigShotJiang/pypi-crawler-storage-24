"""Base segmenter implementations."""

from abc import ABC, abstractmethod

from ..data.conllu_reader import Document
from ..pipeline import ComponentMixin


class BaseSegmenter(ComponentMixin, ABC):
    """Abstract base class for text segmenters.

    A segmenter takes a Document with raw text (and no sentences) and
    produces a Document with sentences and tokens populated.

    Supports the ``|`` operator for building pipelines::

        nlp = LamboSegmenter("pl") | COMBO.from_pretrained("...")
    """

    role = "segmenter"

    @abstractmethod
    def __call__(self, doc: Document) -> Document:
        """Segment the document's text into sentences and tokens.

        Args:
            doc: Document with .text set but .sentences empty.

        Returns:
            Document with .sentences populated.
        """
        ...
