# Copyright 2026 ResQ
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Drone feed domain package."""

from __future__ import annotations

from resq_mcp.drone.models import (
    DeploymentRequest,
    DeploymentStatus,
    NetworkStatus,
    SectorAnalysis,
    SectorStatusSummary,
    SwarmStatus,
)
from resq_mcp.drone.service import (
    get_all_sectors_status,
    get_drone_swarm_status,
    request_drone_deployment,
    scan_current_sector,
)

__all__ = [
    "DeploymentRequest",
    "DeploymentStatus",
    "NetworkStatus",
    "SectorAnalysis",
    "SectorStatusSummary",
    "SwarmStatus",
    "get_all_sectors_status",
    "get_drone_swarm_status",
    "request_drone_deployment",
    "scan_current_sector",
]
