"""异步浏览器管理器（v4.1.0 Session 复用版本）

提供浏览器实例的创建、配置和管理
基于 Playwright 异步 API 实现，支持多种浏览器

v4.1.0: Browser Session 复用 + Context/Page 隔离
- AsyncBrowserManager：管理 playwright + browser（session 级别）
- new_context()：每个测试创建独立的 BrowserContext
- 对齐 Playwright 官方最佳实践（pytest-playwright 插件模式）

v4.0.0: 异步优先
- AsyncBrowserManager：完全异步实现（推荐）
- 性能提升 2-3 倍
- 基于 playwright.async_api
"""

from typing import Any

try:
    from playwright.async_api import (
        Browser,
        BrowserContext,
        Page,
        Playwright,
        async_playwright,
    )

    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False
    Browser = Any
    BrowserContext = Any
    Page = Any
    Playwright = Any

    # 为测试 mock 提供占位符
    def async_playwright():
        raise ImportError("Playwright未安装")


from .browser import BrowserType


class AsyncBrowserManager:
    """
    异步浏览器管理器（v4.1.0 Session 复用版本）

    基于 Playwright 异步 API 实现，管理 playwright 进程和 browser 实例。
    Context 和 Page 由 fixture 层管理，实现每测试隔离。

    v4.1.0 架构变更（对齐 Playwright 官方最佳实践）:
    - start() 只创建 playwright + browser（session 级别复用）
    - new_context() 创建隔离的 BrowserContext（function 级别）
    - Context/Page 不再由 AsyncBrowserManager 持有

    使用示例:
        >>> manager = AsyncBrowserManager(config=web_config, runtime=runtime)
        >>> await manager.start()
        >>>
        >>> ctx = await manager.new_context(storage_state="auth.json")
        >>> page = await ctx.new_page()
        >>> await page.goto("https://example.com")
        >>> await page.close()
        >>> await ctx.close()
        >>>
        >>> await manager.stop()
    """

    def __init__(
        self,
        config: Any | None = None,
        runtime: Any | None = None,
        **overrides: Any,
    ):
        """
        初始化异步浏览器管理器

        Args:
            config: WebConfig 配置对象
            runtime: RuntimeContext 实例 - 用于事件发布
            **overrides: 配置覆盖（browser_type, headless, timeout 等）

        Raises:
            ImportError: 如果未安装 Playwright
        """
        if not PLAYWRIGHT_AVAILABLE:
            raise ImportError(
                "Playwright未安装。请运行: pip install 'playwright>=1.40.0' && playwright install"
            )

        # 从 config 读取配置，overrides 优先
        def get_config(key: str, default: Any) -> Any:
            if key in overrides and overrides[key] is not None:
                return overrides[key]
            if config and hasattr(config, key):
                return getattr(config, key)
            return default

        # 浏览器类型需要特殊处理（字符串转枚举）
        browser_type_value = get_config("browser_type", "chromium")
        if isinstance(browser_type_value, str):
            browser_type_value = BrowserType(browser_type_value)

        self.base_url = get_config("base_url", None)
        self.browser_type = browser_type_value
        self.headless = get_config("headless", True)
        self.slow_mo = get_config("slow_mo", 0)
        self.timeout = get_config("timeout", 30000)
        self.viewport = get_config("viewport", {"width": 1280, "height": 720})

        # 标准化 record_video 值（布尔值转字符串）
        record_video_value = get_config("record_video", "off")
        if isinstance(record_video_value, bool):
            self.record_video = "on" if record_video_value else "off"
        else:
            self.record_video = record_video_value

        self.video_dir = get_config("video_dir", "reports/videos")
        self.video_size = get_config("video_size", None)

        # 合并 browser_options
        config_options = getattr(config, "browser_options", {}) if config else {}
        override_options = overrides.get("browser_options", {})
        self.browser_options = {**config_options, **override_options}

        # 保存 runtime 引用，用于获取 event_bus
        self.runtime = runtime

        self._playwright: Playwright | None = None
        self._browser: Browser | None = None

    async def start(self) -> Browser:
        """
        启动 Playwright 进程和浏览器实例（异步）

        v4.1.0: 只创建 playwright + browser，不再创建 context/page

        Returns:
            Browser: 浏览器实例

        Raises:
            RuntimeError: 如果浏览器已经启动

        Example:
            >>> manager = AsyncBrowserManager()
            >>> browser = await manager.start()
            >>> ctx = await manager.new_context()
            >>> page = await ctx.new_page()
        """
        if self._browser is not None:
            raise RuntimeError("浏览器已经启动，请先调用 stop() 关闭")

        # 启动 Playwright（异步）
        self._playwright = await async_playwright().start()

        # 获取浏览器启动器
        if self.browser_type == BrowserType.CHROMIUM:
            launcher = self._playwright.chromium
        elif self.browser_type == BrowserType.FIREFOX:
            launcher = self._playwright.firefox
        elif self.browser_type == BrowserType.WEBKIT:
            launcher = self._playwright.webkit
        else:
            raise ValueError(f"不支持的浏览器类型: {self.browser_type}")

        # 启动浏览器（异步）
        self._browser = await launcher.launch(
            headless=self.headless,
            slow_mo=self.slow_mo,
            **self.browser_options,
        )

        return self._browser

    async def new_context(
        self,
        storage_state: str | None = None,
        **extra_options: Any,
    ) -> BrowserContext:
        """
        创建浏览器上下文（每测试隔离）

        v4.1.0 新增：将 context 创建从 start() 分离，支持 function-scoped 隔离。

        Args:
            storage_state: 认证状态路径（覆盖实例配置）
            **extra_options: 额外的 context 选项

        Returns:
            BrowserContext: 配置好的浏览器上下文

        Raises:
            RuntimeError: 如果浏览器未启动
        """
        if self._browser is None:
            raise RuntimeError("浏览器未启动，请先调用 start()")

        context_options: dict[str, Any] = {"viewport": self.viewport}

        # storageState 认证状态注入（参数优先，回退到实例配置）
        effective_storage_state = storage_state
        if effective_storage_state:
            context_options["storage_state"] = effective_storage_state

        # 支持完整的 record_video 选项
        if self.record_video and self.record_video != "off":
            from pathlib import Path

            Path(self.video_dir).mkdir(parents=True, exist_ok=True)
            context_options["record_video_dir"] = self.video_dir
            if self.video_size:
                context_options["record_video_size"] = self.video_size

        # 合并额外选项
        context_options.update(extra_options)

        ctx = await self._browser.new_context(**context_options)

        # 设置默认超时
        ctx.set_default_timeout(self.timeout)

        return ctx

    async def stop(self) -> None:
        """
        关闭浏览器并清理资源（异步）

        v4.1.0: 只关闭 browser + playwright（context/page 由 fixture 管理）

        Example:
            >>> await manager.stop()
        """
        if self._browser:
            await self._browser.close()
            self._browser = None

        if self._playwright:
            await self._playwright.stop()
            self._playwright = None

    async def __aenter__(self):
        """异步上下文管理器入口"""
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """异步上下文管理器退出"""
        await self.stop()
        return False

    @property
    def browser(self) -> Browser:
        """获取浏览器实例"""
        if self._browser is None:
            raise RuntimeError("浏览器未启动，请先调用 start()")
        return self._browser

    def _setup_event_listeners(self, page: Page, runtime: Any | None = None) -> None:
        """
        设置页面事件监听器

        Args:
            page: Playwright Page 对象
            runtime: RuntimeContext 实例（优先使用，回退到 self.runtime）

        Note:
            此方法由 page fixture 调用，传入 test_runtime 实现事件隔离
        """
        effective_runtime = runtime or self.runtime
        if not effective_runtime or not hasattr(effective_runtime, "event_bus"):
            return

        event_bus = effective_runtime.event_bus

        # 页面加载事件
        def on_load(page_obj):
            try:
                event_bus.publish(
                    "ui.page_load",
                    {
                        "url": page_obj.url,
                        # 注意：page.title() 是异步方法，不能在同步回调中调用
                        # "title": page_obj.title(),
                    },
                )
            except Exception:
                pass  # 静默失败，不影响测试

        # 页面导航事件
        def on_framenavigated(frame):
            if frame == page.main_frame:
                try:
                    event_bus.publish(
                        "ui.page_navigate",
                        {
                            "url": frame.url,
                        },
                    )
                except Exception:
                    pass

        # 控制台消息事件
        def on_console(msg):
            try:
                event_bus.publish(
                    "ui.console",
                    {
                        "type": msg.type,
                        "text": msg.text,
                        "location": msg.location,
                    },
                )
            except Exception:
                pass

        # 页面错误事件
        def on_pageerror(error):
            try:
                event_bus.publish(
                    "ui.page_error",
                    {
                        "error": str(error),
                    },
                )
            except Exception:
                pass

        # 注册监听器
        page.on("load", on_load)
        page.on("framenavigated", on_framenavigated)
        page.on("console", on_console)
        page.on("pageerror", on_pageerror)


__all__ = ["AsyncBrowserManager"]
