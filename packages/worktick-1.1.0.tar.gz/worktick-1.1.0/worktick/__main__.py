from worktick.cli import main

main()
