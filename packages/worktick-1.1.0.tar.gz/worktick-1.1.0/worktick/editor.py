from __future__ import annotations

import os
import shlex
import shutil
import subprocess
import tempfile

from worktick.models import DATA_DIR


class EditorError(Exception):
    pass


def _find_editor() -> str:
    for env_var in ("VISUAL", "EDITOR"):
        value = os.environ.get(env_var)
        if value:
            return value
    for name in ("vi", "vim", "nano"):
        if shutil.which(name):
            return name
    raise EditorError(
        "No editor found. Set $EDITOR or $VISUAL, or install vi/vim/nano."
    )


def edit_text(content: str, suffix: str = ".md") -> str:
    editor = _find_editor()
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(dir=DATA_DIR, prefix="wt-edit-", suffix=suffix)
    try:
        with os.fdopen(fd, "w") as f:
            f.write(content)
        cmd = shlex.split(editor) + [tmp_path]
        result = subprocess.run(cmd)
        if result.returncode != 0:
            raise EditorError(f"Editor exited with code {result.returncode}")
        with open(tmp_path) as f:
            return f.read()
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
