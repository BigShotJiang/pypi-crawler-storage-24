from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Optional

from worktick.models import TaskEntry, TaskStore, load_store, save_store
from worktick.git_utils import get_git_author, get_git_root, is_valid_git_repo, scan_commits


def format_duration(seconds: int) -> str:
    if seconds < 0:
        seconds = 0
    h, remainder = divmod(seconds, 3600)
    m, s = divmod(remainder, 60)
    if h > 0:
        return f"{h}h {m:02d}m"
    if m > 0:
        return f"{m}m {s:02d}s"
    return f"{s}s"


class TaskTracker:
    def __init__(self) -> None:
        self.store: TaskStore = load_store()

    def _save(self) -> None:
        save_store(self.store)

    def _register_cwd_repo(self, task: TaskEntry) -> tuple[bool, Optional[str]]:
        """Detect git root from cwd and append to task.git_repos if new.

        Returns (was_new, repo_path).
        """
        cwd = os.getcwd()
        git_root = get_git_root(cwd)
        if not git_root:
            return False, None
        if git_root not in task.git_repos:
            task.git_repos.append(git_root)
            return True, git_root
        return False, git_root

    def start(self, title: str, card_url: str = "") -> str:
        if self.store.current:
            current = self.store.current_task()
            if current:
                if current.is_paused():
                    raise RuntimeError(
                        f'Task paused: "{current.title}" '
                        f"({format_duration(current.elapsed_seconds())}). "
                        "Resume or stop it first."
                    )
                raise RuntimeError(
                    f'Task already running: "{current.title}" '
                    f"({format_duration(current.elapsed_seconds())}). "
                    "Stop it first with: wt stop"
                )

        task = TaskEntry.new(title, card_url)
        was_new, git_root = self._register_cwd_repo(task)

        self.store.tasks.append(task)
        self.store.current = task.id
        self._save()

        lines = [
            f'Started: "{task.title}"',
            f"  Time: {task.started_at}",
        ]
        if task.card_url:
            lines.append(f"  Card: {task.card_url}")
        if git_root:
            lines.append(f"  Git:  {git_root}")
        else:
            lines.append("  Warning: Not in a git repo. Commits won't be tracked unless you switch to one.")
        return "\n".join(lines)

    def stop(self, at_time: Optional[str] = None) -> str:
        task = self.store.current_task()
        if not task:
            raise RuntimeError("No task is currently running.")

        stop_dt: Optional[datetime] = None
        if at_time:
            try:
                hh, mm = at_time.split(":")
                now = datetime.now(timezone.utc).astimezone()
                stop_dt = now.replace(
                    hour=int(hh), minute=int(mm), second=0, microsecond=0,
                )
            except (ValueError, TypeError):
                raise RuntimeError(f"Invalid time format: {at_time}. Use HH:MM.")

        # Register cwd repo before scanning (catches: started outside git, stopped inside)
        self._register_cwd_repo(task)

        task.stop(stop_dt)

        # Scan git commits, validating each repo first
        warnings = []
        if task.git_repos:
            author = get_git_author()
            for repo in task.git_repos:
                if not is_valid_git_repo(repo):
                    warnings.append(f"  Warning: Skipping invalid repo: {repo}")
                    continue
                commits = scan_commits(
                    repo_path=repo,
                    after=task.started_at,
                    before=task.stopped_at,
                    author=author,
                )
                task.commits.extend(commits)

        self.store.current = None
        self._save()

        lines = [
            f'Stopped: "{task.title}"',
            f"  Duration: {format_duration(task.duration_seconds)}",
        ]
        if task.commits:
            lines.append(f"  Commits:  {len(task.commits)}")
        if task.notes:
            lines.append(f"  Notes:    {len(task.notes)}")
        lines.extend(warnings)
        return "\n".join(lines)

    def pause(self) -> str:
        task = self.store.current_task()
        if not task:
            raise RuntimeError("No task is currently running.")
        if task.is_paused():
            raise RuntimeError(f'Task already paused: "{task.title}"')
        task.pause()
        self._save()
        elapsed = format_duration(task.elapsed_seconds())
        return f'Paused: "{task.title}" ({elapsed} active)'

    def resume(self) -> str:
        task = self.store.current_task()
        if not task:
            raise RuntimeError("No task is currently running.")
        if not task.is_paused():
            raise RuntimeError(f'Task is not paused: "{task.title}"')
        task.resume()
        self._save()
        elapsed = format_duration(task.elapsed_seconds())
        return f'Resumed: "{task.title}" ({elapsed} active)'

    def status(self) -> str:
        task = self.store.current_task()
        if not task:
            return "No task is currently running."

        was_new, _ = self._register_cwd_repo(task)
        if was_new:
            self._save()

        elapsed = format_duration(task.elapsed_seconds())
        if task.is_paused():
            last_pause = datetime.fromisoformat(task.pauses[-1]["paused_at"])
            now = datetime.now(timezone.utc).astimezone()
            pause_dur = format_duration(int((now - last_pause).total_seconds()))
            lines = [
                f'Paused: "{task.title}" ({elapsed} active, paused for {pause_dur})',
                f"  Started: {task.started_at}",
            ]
        else:
            lines = [
                f'Running: "{task.title}" ({elapsed})',
                f"  Started: {task.started_at}",
            ]
        if task.card_url:
            lines.append(f"  Card:    {task.card_url}")
        if task.notes:
            lines.append(f"  Notes:   {len(task.notes)}")
        if task.git_repos:
            for repo in task.git_repos:
                lines.append(f"  Git:     {repo}")
        return "\n".join(lines)

    def note(self, text: str) -> str:
        task = self.store.current_task()
        if not task:
            raise RuntimeError("No task is currently running. Start one first.")

        was_new, git_root = self._register_cwd_repo(task)
        task.notes.append(text)
        self._save()

        result = f'Note added to "{task.title}": {text}'
        if was_new:
            result += f"\n  Git repo registered: {git_root}"
        return result

    def repo_add(self, path: str) -> str:
        """Register git repo(s) at path. If path is a plain dir, scan children."""
        task = self.store.current_task()
        if not task:
            raise RuntimeError("No task is currently running. Start one first.")

        path = os.path.abspath(os.path.expanduser(path))
        if not os.path.isdir(path):
            raise RuntimeError(f"Not a directory: {path}")

        added = []
        if is_valid_git_repo(path):
            git_root = get_git_root(path)
            if git_root and git_root not in task.git_repos:
                task.git_repos.append(git_root)
                added.append(os.path.basename(git_root))
        else:
            # Scan immediate children for git repos
            for entry in sorted(os.listdir(path)):
                child = os.path.join(path, entry)
                if os.path.isdir(child) and is_valid_git_repo(child):
                    git_root = get_git_root(child)
                    if git_root and git_root not in task.git_repos:
                        task.git_repos.append(git_root)
                        added.append(os.path.basename(git_root))

        if not added:
            return "No new git repos found to register."

        self._save()
        if len(added) == 1:
            return f"Git repo registered: {added[0]}"
        return f"Registered {len(added)} git repos: {', '.join(added)}"

    def cancel(self) -> str:
        task = self.store.current_task()
        if not task:
            raise RuntimeError("No task is currently running.")
        title = task.title
        self.store.tasks.remove(task)
        self.store.current = None
        self._save()
        return f'Cancelled: "{title}"'

    def list_tasks(self, days: int = 7) -> str:
        now = datetime.now(timezone.utc).astimezone()
        cutoff_seconds = days * 86400
        recent = []
        for t in reversed(self.store.tasks):
            started = datetime.fromisoformat(t.started_at)
            if (now - started).total_seconds() <= cutoff_seconds:
                recent.append(t)

        if not recent:
            return f"No tasks in the last {days} day(s)."

        lines = []
        for t in recent:
            dur = format_duration(t.elapsed_seconds())
            if t.id == self.store.current:
                status = " (paused)" if t.is_paused() else " (running)"
            else:
                status = ""
            line = f"  {t.id}  {dur:>8}  {t.title}{status}"
            if t.card_url:
                line += f"  [{t.card_url}]"
            lines.append(line)

        header = f"Tasks (last {days} day{'s' if days != 1 else ''}):"
        return header + "\n" + "\n".join(lines)

    def edit(self, task_id: str, title: Optional[str] = None, card_url: Optional[str] = None) -> str:
        task = self.store.find(task_id)
        if not task:
            # Try prefix match
            matches = [t for t in self.store.tasks if t.id.startswith(task_id)]
            if len(matches) == 1:
                task = matches[0]
            elif len(matches) > 1:
                raise RuntimeError(f"Ambiguous ID '{task_id}' — matches: {', '.join(m.id for m in matches)}")
            else:
                raise RuntimeError(f"Task not found: {task_id}")

        changes = []
        if title is not None:
            task.title = title
            changes.append(f"title → {title}")
        if card_url is not None:
            task.card_url = card_url
            changes.append(f"card → {card_url}")

        if not changes:
            return "Nothing to update."

        self._save()
        return f"Updated {task.id}: {', '.join(changes)}"
