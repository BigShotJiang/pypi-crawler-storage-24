from __future__ import annotations

import json
import os
import tempfile
import uuid
from datetime import datetime, timezone

from pydantic import BaseModel, Field

from worktick.models import DATA_DIR

MEETINGS_FILE = DATA_DIR / "meetings.json"


class MeetingEntry(BaseModel):
    id: str
    timestamp: str
    source: str              # "recording", "file", "stdin"
    source_file: str = ""    # original file path
    audio_file: str = ""     # audio path (empty if text input)
    status: str = "pending"  # "completed", "failed"
    transcript: str = ""
    minutes: str = ""
    model: str = "gemma3"
    error: str = ""

    @staticmethod
    def new(source: str, source_file: str = "", audio_file: str = "") -> MeetingEntry:
        now = datetime.now(timezone.utc).astimezone()
        return MeetingEntry(
            id=uuid.uuid4().hex[:12],
            timestamp=now.isoformat(),
            source=source,
            source_file=source_file,
            audio_file=audio_file,
        )

    def audio_exists(self) -> bool:
        return bool(self.audio_file) and os.path.isfile(self.audio_file)

    def short_time(self) -> str:
        dt = datetime.fromisoformat(self.timestamp)
        return dt.strftime("%d %b %H:%M")


class MeetingStore(BaseModel):
    meetings: list[MeetingEntry] = Field(default_factory=list)

    def find(self, meeting_id: str) -> MeetingEntry | None:
        for m in self.meetings:
            if m.id == meeting_id:
                return m
        # Prefix match
        matches = [m for m in self.meetings if m.id.startswith(meeting_id)]
        if len(matches) == 1:
            return matches[0]
        return None


def load_meetings() -> MeetingStore:
    if not MEETINGS_FILE.exists():
        return MeetingStore()
    try:
        data = json.loads(MEETINGS_FILE.read_text())
        meetings = [MeetingEntry(**m) for m in data.get("meetings", [])]
        return MeetingStore(meetings=meetings)
    except (json.JSONDecodeError, OSError, TypeError):
        return MeetingStore()


def save_meetings(store: MeetingStore) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    data = {"meetings": [m.model_dump() for m in store.meetings]}
    fd, tmp_path = tempfile.mkstemp(dir=DATA_DIR, suffix=".tmp")
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp_path, MEETINGS_FILE)
    except BaseException:
        os.unlink(tmp_path)
        raise
