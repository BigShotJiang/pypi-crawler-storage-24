from __future__ import annotations

import httpx

OLLAMA_BASE = "http://localhost:11434"


class OllamaError(Exception):
    """Raised when Ollama is unavailable or returns an error."""


def check_ollama_available() -> bool:
    try:
        httpx.get(f"{OLLAMA_BASE}/api/tags", timeout=5)
        return True
    except (httpx.ConnectError, httpx.TimeoutException, OSError):
        return False


def generate(prompt: str, model: str = "gemma3") -> str:
    try:
        resp = httpx.post(
            f"{OLLAMA_BASE}/api/generate",
            json={"model": model, "prompt": prompt, "stream": False},
            timeout=300,
        )
        resp.raise_for_status()
        return resp.json().get("response", "").strip()
    except httpx.TimeoutException:
        raise OllamaError(
            "Ollama request timed out (5 min). "
            "The model may be too large for your system. "
            "Try a smaller model: wt mom --model gemma3:1b"
        )
    except httpx.HTTPStatusError as e:
        raise OllamaError(f"Ollama returned HTTP {e.response.status_code}: {e.response.text}")
    except (httpx.ConnectError, OSError):
        raise OllamaError(
            "Cannot connect to Ollama. Make sure it's running:\n"
            "  ollama serve\n"
            "  ollama pull gemma3"
        )
