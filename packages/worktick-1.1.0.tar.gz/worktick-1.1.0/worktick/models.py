from __future__ import annotations

import json
import os
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from pydantic import BaseModel, Field

DATA_DIR = Path.home() / ".worktick"
_OLD_DATA_DIR = Path.home() / ".task-tracker"
DATA_FILE = DATA_DIR / "tasks.json"

CURRENT_VERSION = 1


def _migrate_data_dir() -> None:
    """One-time migration from ~/.task-tracker to ~/.worktick."""
    if _OLD_DATA_DIR.exists() and not DATA_DIR.exists():
        _OLD_DATA_DIR.rename(DATA_DIR)


_migrate_data_dir()


class Commit(BaseModel):
    hash: str
    short_hash: str
    message: str
    repo: str
    timestamp: str


class TaskEntry(BaseModel):
    id: str
    title: str
    started_at: str
    card_url: str = ""
    stopped_at: str = ""
    duration_seconds: int = 0
    git_repos: list[str] = Field(default_factory=list)
    commits: list[dict] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    pauses: list[dict] = Field(default_factory=list)

    @staticmethod
    def new(title: str, card_url: str = "") -> TaskEntry:
        now = datetime.now(timezone.utc).astimezone()
        return TaskEntry(
            id=uuid.uuid4().hex[:12],
            title=title,
            started_at=now.isoformat(),
            card_url=card_url,
        )

    def is_paused(self) -> bool:
        return bool(self.pauses) and not self.pauses[-1].get("resumed_at")

    def total_paused_seconds(self) -> int:
        total = 0
        now = datetime.now(timezone.utc).astimezone()
        for p in self.pauses:
            paused_at = datetime.fromisoformat(p["paused_at"])
            if p.get("resumed_at"):
                resumed_at = datetime.fromisoformat(p["resumed_at"])
            else:
                resumed_at = now
            total += int((resumed_at - paused_at).total_seconds())
        return total

    def pause(self) -> None:
        now = datetime.now(timezone.utc).astimezone()
        self.pauses.append({"paused_at": now.isoformat(), "resumed_at": ""})

    def resume(self) -> None:
        now = datetime.now(timezone.utc).astimezone()
        self.pauses[-1]["resumed_at"] = now.isoformat()

    def stop(self, at: Optional[datetime] = None) -> None:
        if self.is_paused():
            self.resume()
        stop_time = at or datetime.now(timezone.utc).astimezone()
        self.stopped_at = stop_time.isoformat()
        start = datetime.fromisoformat(self.started_at)
        self.duration_seconds = int(
            (stop_time - start).total_seconds() - self.total_paused_seconds()
        )

    def elapsed_seconds(self) -> int:
        if self.stopped_at:
            return self.duration_seconds
        start = datetime.fromisoformat(self.started_at)
        now = datetime.now(timezone.utc).astimezone()
        return int((now - start).total_seconds() - self.total_paused_seconds())


class TaskStore(BaseModel):
    version: int = CURRENT_VERSION
    current: Optional[str] = None
    tasks: list[TaskEntry] = Field(default_factory=list)

    def find(self, task_id: str) -> Optional[TaskEntry]:
        for t in self.tasks:
            if t.id == task_id:
                return t
        return None

    def current_task(self) -> Optional[TaskEntry]:
        if self.current:
            return self.find(self.current)
        return None


def load_store() -> TaskStore:
    if not DATA_FILE.exists():
        return TaskStore()
    data = json.loads(DATA_FILE.read_text())
    tasks = [TaskEntry(**t) for t in data.get("tasks", [])]
    return TaskStore(
        version=data.get("version", CURRENT_VERSION),
        current=data.get("current"),
        tasks=tasks,
    )


def save_store(store: TaskStore) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    data = {
        "version": store.version,
        "current": store.current,
        "tasks": [t.model_dump() for t in store.tasks],
    }
    # Atomic write: temp file → os.replace()
    fd, tmp_path = tempfile.mkstemp(dir=DATA_DIR, suffix=".tmp")
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp_path, DATA_FILE)
    except BaseException:
        os.unlink(tmp_path)
        raise
