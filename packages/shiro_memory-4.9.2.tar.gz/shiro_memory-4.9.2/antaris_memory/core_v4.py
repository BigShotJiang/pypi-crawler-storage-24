"""
MemorySystem — Production-ready memory system with BM25 search and concurrency safety.
shiro-memory fork: sharding, MCP, and Supabase collection stripped per Shiro's spec.

Features:
- BM25-inspired search with TF-IDF scoring and 11-layer pipeline
- File locking and optimistic conflict detection
- Fast indexes (full-text, tags, dates)
- Schema migration with backward compatibility
- LLM enrichment hooks (v4.6.5)
- Graph intelligence: entity extraction + knowledge graph (v4.8/v4.9)
- Tiered storage: hot/warm/cold (v4.7)
- Co-occurrence / PPMI semantic expansion (v4.x)
- Input gating P0-P3 priority classification
- Recovery presets for cold-spawn context restoration

Usage:
    from antaris_memory import MemorySystem

    mem = MemorySystem(workspace="./workspace", agent_name="shiro")
    mem.load()
    mem.ingest("Key decision", source="meeting", category="strategic")
    results = mem.search("decision")
    mem.save()
"""

import json
import os
import re
import time
from collections import defaultdict
import copy
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

from .entry import MemoryEntry
from .decay import DecayEngine
from .sentiment import SentimentTagger
from .temporal import TemporalEngine
from .confidence import ConfidenceEngine
from .compression import CompressionEngine
from .forgetting import ForgettingEngine
from .consolidation import ConsolidationEngine
from .gating import InputGate
from .synthesis import KnowledgeSynthesizer
from .migration import MigrationManager
from .indexing import IndexManager
from .search import SearchEngine, SearchResult
from .context_packet import ContextPacket, ContextPacketBuilder
from .namespace import NamespaceManager
from .memory_types import (
    MEMORY_TYPE_CONFIGS, DEFAULT_TYPE, get_type_config,
    format_mistake_content, SEVERITY_LEVELS,
)
from .utils import atomic_write_json
from .performance import ReadCache, WALManager, PerformanceMonitor, AccessTracker
from .shared import SharedMemoryPool
from .category_tagger import CategoryTagger
from .wal import WALWriter, WALReader

# Module-level CategoryTagger singleton — shared across all ingest paths
_ct = CategoryTagger()

# Default tags to auto-extract
_DEFAULT_TAG_TERMS = [
    "web3", "ethereum", "postgresql", "optimization", "cost",
    "revenue", "security", "deployment", "production", "testing",
]

# v4.6.6 — Pre-ingest metadata junk filter
_METADATA_LINE_RE = re.compile(
    r'^\d*\.?\s*"(?:conversation_label|sender_id|sender|message_id|group_subject|group_channel|'
    r'group_space|was_mentioned|has_reply_context|has_forwarded_context|has_thread_starter|'
    r'history_count|chat_id|channel|provider|surface|chat_type|schema|flags)"'
    r'|^HEARTBEAT_OK$|^NO_REPLY$'
    r'|^[{\[\]},]$'
    r'|^\s*"[a-z_]{2,40}"\s*:\s*'
    r'|^<!--.*-->$'
    r'|^\s*```[a-z]*\s*$'
    r'|^\s*\*\(from:\s*[\w:]+\)\*\s*$'
    r'|^Packet built \d{4}-\d{2}-\d{2}'
    r'|^\[Queued messages while agent was busy\]\s*$'
    r'|^Queued #\d+\s*$'
    r'|^\s*-{3,}\s*$'
    r'|^\[System Message\]'
    r'|^Reasoning:\s*$',
    re.IGNORECASE
)

# v4.9.9 — Credential detection for security filtering
_CREDENTIAL_RE = re.compile(
    r'sk-ant-api\d{2}-\w{20,}'
    r'|sk-proj-\w{20,}'
    r'|hf_\w{20,}'
    r'|eyJ[A-Za-z0-9_-]{50,}'
    r'|ghp_\w{20,}'
    r'|ghu_\w{20,}'
    r'|MTQ\w{20,}\.\w{5,}\.\w{20,}'
    r'|Bearer\s+\w{20,}'
    r'|token[=:]\s*\w{30,}'
    r'|password[=:]\s*\S{8,}'
    r'|PRIVATE.KEY'
)

# v5.0.2 — Conversation noise filter
_CONVERSATION_NOISE_RE = re.compile(
    r'^(?:OUTPUT:\s*)?(?:'
    r'(?:Understood|Got it|On it|Sure|OK|Ready|Done|Noted|Will do|Perfect|'
    r'Sounds good|Absolutely|Alright|Acknowledged|Affirmative|Roger|Copy that|'
    r'No problem|Of course|Certainly|Definitely|Right away|'
    r'Let me (?:check|look|see|think|work)|'
    r'I\'ll (?:check|look|handle|work|take|get)|'
    r'Looking (?:into|at)|Checking (?:now|that)|Starting (?:now|on)|'
    r'Working on (?:it|that|this)|Running (?:now|that))\b'
    r'|^(?:Turn:\s*)?<@\d+>\s*.{0,15}$'
    r'|^\[\[reply_to_current\]\]'
    r'|^HEARTBEAT_OK$'
    r'|^NO_REPLY$'
    r')',
    re.IGNORECASE
)

# v5.0.2 — Turn/INPUT/OUTPUT prefix stripping
_TURN_PREFIX_RE = re.compile(r'^(?:Turn|INPUT|OUTPUT|System):\s*')


class SemanticExpander:
    """Query expansion using a domain-specific word embedding lookup.

    Loads ``antaris_memory/data/word_expansion.json`` at init (zero runtime
    dependency). Falls back silently to no-op if the file is missing.

    Example::

        expander = SemanticExpander()
        expander.expand("memory recall degraded")
        # → "memory recall degraded memories retrieval search queries"
    """

    _MAX_EXTRA_TOKENS = 5
    _MIN_SIM = 0.87
    _MIN_TOKEN_LEN = 4

    def __init__(self, index_path: Optional[str] = None) -> None:
        if index_path is None:
            index_path = os.path.join(
                os.path.dirname(__file__), "data", "word_expansion.json"
            )
        self._index: dict = {}
        try:
            if os.path.exists(index_path):
                with open(index_path, encoding="utf-8") as f:
                    raw = json.load(f)
                expansions = raw.get("expansions", raw)
                for word, neighbours in expansions.items():
                    if not neighbours:
                        continue
                    sample = neighbours[0]
                    if isinstance(sample, (list, tuple)) and len(sample) == 2:
                        filtered = [(n, s) for n, s in neighbours if s >= self._MIN_SIM]
                    else:
                        filtered = [(n, 1.0) for n in neighbours]
                    if filtered:
                        self._index[word] = filtered
        except Exception as e:
            import sys as _sys
            print(f"[shiro-memory] WARNING: word_expansion.json load failed: {e}", file=_sys.stderr)

    def expand(self, query: str) -> str:
        """Return query augmented with semantically related terms."""
        if not self._index:
            return query
        tokens = re.findall(r"[a-zA-Z][a-zA-Z0-9_'-]{%d,}" % (self._MIN_TOKEN_LEN - 1),
                            query.lower())
        extras: list = []
        seen = set(query.lower().split())
        for tok in tokens:
            for neighbour, _score in self._index.get(tok, []):
                if neighbour not in seen and len(extras) < self._MAX_EXTRA_TOKENS:
                    extras.append(neighbour)
                    seen.add(neighbour)
        if extras:
            return query + " " + " ".join(extras)
        return query

    def __bool__(self) -> bool:
        return bool(self._index)

    def __len__(self) -> int:
        return len(self._index)


class MemorySystemV4(NamespaceManager):
    """Production-ready memory system with BM25 search and 11-layer pipeline.

    shiro-memory fork: sharding, MCP, and Supabase collection stripped.

    Parameters
    ----------
    workspace : str
        Root directory. Memory files are stored here.
    agent_name : str
        REQUIRED. Agent scoping — each agent gets a separate memory namespace.
        Without it, memories from different agents blend together.
    half_life : float
        Decay half-life in days (default 7).
    tag_terms : list[str] | None
        Custom terms to auto-tag. Merged with built-in defaults.
    use_indexing : bool
        Whether to build search indexes (default True).
    enricher : Callable[[str], dict] | None
        LLM enrichment callable. Receives memory content, returns dict with
        optional keys: tags, summary, keywords, search_queries.
    tiered_storage : bool
        Enable hot/warm/cold tier management (default True).
    graph_intelligence : bool
        Enable entity extraction + knowledge graph (default True).
    semantic_expansion : bool
        Enable PPMI co-occurrence query expansion (default True).
    quality_routing : bool
        Enable follow-up pattern detection (default True).
    """

    def __init__(
        self,
        workspace: str = ".",
        agent_name: Optional[str] = None,
        half_life: float = 7.0,
        tag_terms: List[str] = None,
        use_indexing: bool = True,
        enable_read_cache: bool = True,
        cache_max_entries: int = 1000,
        enricher: Optional[Callable[[str], dict]] = None,
        tiered_storage: bool = True,
        graph_intelligence: bool = True,
        semantic_expansion: bool = True,
        quality_routing: bool = True,
        use_sharding: bool = False,  # accepted but ignored — sharding stripped from shiro-memory
    ):
        import warnings

        if agent_name is None:
            warnings.warn(
                "MemorySystem created without agent_name — memories from different agents "
                "may blend together. Pass agent_name='<your-agent>' to scope the store.",
                UserWarning,
                stacklevel=2,
            )

        self.workspace = os.path.abspath(workspace)
        self.agent_name: Optional[str] = agent_name
        self.use_sharding = False  # Sharding stripped from shiro-memory
        self.use_indexing = use_indexing

        # Backward compatibility paths
        self.legacy_metadata_path = os.path.join(self.workspace, "memory_metadata.json")
        self.audit_path = os.path.join(self.workspace, "memory_audit.json")

        # v0.4 managers
        self.migration_manager = MigrationManager(workspace)
        self.shard_manager = None  # Sharding stripped from shiro-memory
        self.index_manager = IndexManager(workspace) if use_indexing else None

        # Engines
        self.decay = DecayEngine(half_life=half_life)
        self.sentiment = SentimentTagger()
        self.temporal = TemporalEngine()
        self.confidence = ConfidenceEngine()
        self.compression = CompressionEngine()
        self.forgetting = ForgettingEngine()
        self.consolidation = ConsolidationEngine(decay=self.decay)
        self.gating = InputGate()
        self.synthesis = KnowledgeSynthesizer()
        self.search_engine = SearchEngine()

        # Tag terms
        self._tag_terms = list(set(_DEFAULT_TAG_TERMS + (tag_terms or [])))

        # Memory store (in-memory cache)
        self.memories: List[MemoryEntry] = []
        self._hashes: set = set()

        # Sprint 11 — performance subsystem
        self._read_cache: Optional[ReadCache] = (
            ReadCache(cache_max_entries) if enable_read_cache else None
        )
        self._enable_read_cache = enable_read_cache
        self._wal = WALManager(self.workspace)
        self._perf = PerformanceMonitor()
        self._access_tracker = AccessTracker(self.workspace)

        # Sprint 3 — pluggable embedding for hybrid semantic search
        self._embedding_fn: Optional[Callable[[str], List[float]]] = None
        self._embedding_cache: Dict[str, List[float]] = {}

        # v3.2 — Instrumentation
        from .instrumentation import SearchContext
        self._instrumentation_log_path = os.path.join(self.workspace, ".instrumentation_log.jsonl")
        self._usage_signals_path = os.path.join(self.workspace, ".usage_signals.jsonl")
        self.opt_in_to_aggregation: bool = False
        self._shared_pool: Optional["SharedMemoryPool"] = None
        self._shared_agent_id: Optional[str] = None

        # v4.6.5 — LLM enrichment hook
        self._enricher: Optional[Callable[[str], dict]] = enricher
        self._enrichment_count: int = 0

        # v4.7 — Tiered storage (hot/warm/cold)
        self._tiered_storage: bool = tiered_storage
        self._tier_manager = None
        if tiered_storage:
            try:
                from .tiers import TierManager
                self._tier_manager = TierManager(self.workspace)
            except Exception:
                self._tier_manager = None

        # v4.8 — Graph intelligence
        self._graph_intelligence: bool = graph_intelligence
        self._graph = None
        if graph_intelligence:
            try:
                from .graph import MemoryGraph
                self._graph = MemoryGraph()
            except Exception:
                self._graph = None

        # v4.x — Semantic expansion (PPMI co-occurrence)
        self._semantic_expansion: bool = semantic_expansion
        self._cooccurrence = None
        if semantic_expansion:
            try:
                from .cooccurrence import CooccurrenceIndex
                self._cooccurrence = CooccurrenceIndex(self.workspace)
            except Exception:
                self._cooccurrence = None

        # v4.x — SemanticExpander (word_expansion.json)
        self._semantic_expander: SemanticExpander = SemanticExpander()

        # v4.9 — Quality routing
        self._quality_routing: bool = quality_routing
        self._quality_router = None
        if quality_routing:
            try:
                from .quality_router import QualityRouter
                self._quality_router = QualityRouter()
            except Exception:
                self._quality_router = None

        # Initialize system
        self._initialize()

    def _initialize(self):
        """Initialize the memory system, handling migrations if needed."""
        import logging  # Bug fix: moved to top of method — was inside success branch only
        _log = logging.getLogger("antaris_memory")
        # Check if migration is needed
        if self.migration_manager.needs_migration():
            migration_result = self.migration_manager.migrate()
            if migration_result["status"] == "success":
                _log.info(
                    f"Migrated from {migration_result['from_version']} to {migration_result['to_version']}")
            elif migration_result["status"] == "error":
                _log.error(
                    f"Migration failed: {migration_result['message']}")
                # Fall back to legacy format
                self.use_sharding = False
                self.use_indexing = False

        # Sprint 8 — namespace manager
        self._init_namespace_manager()

        # Load existing data
        self.load()

    # ── persistence ─────────────────────────────────────────────────────

    def save(self) -> str:
        """Save memory state to disk using the appropriate format."""
        if self.use_sharding and self.shard_manager:
            return self._save_sharded()
        else:
            return self._save_legacy()
    
    def _save_sharded(self) -> str:
        """Save using v0.4 sharded format."""
        if not self.shard_manager:
            return self._save_legacy()
        
        # Group memories by shard
        shard_groups = self.shard_manager.shard_memories(self.memories)
        
        # Save each shard
        for shard_key, shard_memories in shard_groups.items():
            self.shard_manager.save_shard(shard_key, shard_memories)
            self.shard_manager.index.add_shard(shard_key, shard_memories)
        
        # Save shard index
        self.shard_manager.index.save_index()
        
        # Update search indexes
        if self.use_indexing and self.index_manager:
            self.index_manager.rebuild_indexes(self.memories)
            self.index_manager.save_all_indexes()
        
        shard_dir = os.path.join(self.workspace, "shards")
        return shard_dir
    
    def _save_legacy(self) -> str:
        """Save using v0.2/v0.3 legacy single-file format."""
        from . import __version__ as _pkg_version  # Bug fix: distinguish format vs pkg version
        data = {
            "version": "0.4.0",           # storage schema version (used by migration logic)
            "package_version": _pkg_version,  # antaris-memory package version
            "saved_at": datetime.now(timezone.utc).isoformat(),
            "count": len(self.memories),
            "format": "legacy",
            "memories": [m.to_dict() for m in self.memories],
        }
        atomic_write_json(self.legacy_metadata_path, data)

        # v4.x — persist co-occurrence index alongside memories
        if self._cooccurrence is not None:
            try:
                self._cooccurrence.save()
            except Exception:
                pass

        return self.legacy_metadata_path

    # ── WAL flush / close ─────────────────────────────────────────────────

    def flush(self) -> Dict:
        """Compact the WAL into permanent shard/legacy storage.

        Called automatically after ``WALManager.flush_interval`` writes or
        when the WAL exceeds 1 MB.  Also called by ``close()``.

        Returns:
            ``{"flushed_entries": N, "wal_cleared": True}``
        """
        pending_before = self._wal.pending_count()

        # Persist current in-memory state (includes WAL-replayed entries)
        self.save()

        # Persist access counts alongside the flush
        self._access_tracker.save()

        # WAL has been safely persisted — clear it
        self._wal.clear()

        # Invalidate read-cache (data on disk changed)
        if self._read_cache is not None:
            self._read_cache.invalidate()

        self._perf.record_compaction()

        return {"flushed_entries": pending_before, "wal_cleared": True}

    def close(self) -> None:
        """Flush WAL and release resources.  Call before process exit."""
        self.flush()

    def load(self) -> int:
        """Load memory state from disk, auto-detecting format.

        Sprint 11: after loading from shards/legacy, replays any pending WAL
        entries so that a crash between ingest and flush loses no data.
        """
        if self.use_sharding and self.shard_manager:
            count = self._load_sharded()
            if count > 0:
                self._replay_wal()
                return len(self.memories)

        # Fall back to legacy format
        result = self._load_legacy()
        self._replay_wal()

        # v4.x — load persisted co-occurrence index if available
        if self._cooccurrence is not None:
            try:
                self._cooccurrence.load()
            except Exception:
                pass

        return len(self.memories)

    def _replay_wal(self) -> int:
        """Replay pending WAL entries that were not yet compacted to shards.

        This is called automatically on ``load()`` and is safe to call even
        when the WAL is empty or doesn't exist.

        Returns:
            Number of entries replayed.
        """
        pending = self._wal.load_pending()
        if not pending:
            return 0

        replayed = 0
        for entry_dict in pending:
            try:
                entry = MemoryEntry.from_dict(entry_dict)
            except Exception:
                continue   # corrupted entry — skip

            if entry.hash in self._hashes:
                continue   # already in memory (e.g. flushed before crash)

            self.memories.append(entry)
            self._hashes.add(entry.hash)
            replayed += 1

        if replayed:
            self.search_engine.mark_dirty()

        return replayed

    def _load_sharded(self) -> int:
        """Load from v0.4 sharded format."""
        if not self.shard_manager:
            return 0

        # Load all memories from shards (careful with memory usage)
        _LOAD_LIMIT = 10000
        self.memories = self.shard_manager.get_all_memories(limit=_LOAD_LIMIT)
        # Bug fix: warn when the safety limit is hit so users know data was truncated
        if len(self.memories) >= _LOAD_LIMIT:
            import warnings
            warnings.warn(
                f"antaris-memory: loaded {_LOAD_LIMIT} memories (safety limit). "
                "Some older memories may not be in the active set. "
                "Consider calling forget() or archiving old shards.",
                UserWarning,
                stacklevel=3,
            )
        self._hashes = {m.hash for m in self.memories}
        if self.memories:
            self.search_engine.build_index(self.memories)
        return len(self.memories)

    def _load_legacy(self) -> int:
        """Load from v0.2/v0.3 legacy single-file format."""
        if not os.path.exists(self.legacy_metadata_path):
            return 0

        with open(self.legacy_metadata_path) as f:
            data = json.load(f)

        self.memories = [MemoryEntry.from_dict(d) for d in data.get("memories", [])]
        self._hashes = {m.hash for m in self.memories}
        if self.memories:
            self.search_engine.build_index(self.memories)
        return len(self.memories)

    # ── Sprint 3: embedding interface ────────────────────────────────────

    def set_embedding_fn(self, fn: Callable[[str], List[float]]) -> None:
        """Set a custom embedding function for semantic search.

        When set, search() uses hybrid BM25 + cosine similarity scoring.
        When not set, pure BM25 is used (default, zero-dependency behavior).

        Example::

            import openai
            client = openai.Client()
            def embed(text):
                return client.embeddings.create(
                    input=text, model="text-embedding-3-small"
                ).data[0].embedding
            mem.set_embedding_fn(embed)
        """
        self._embedding_fn = fn
        self._embedding_cache.clear()  # invalidate embedding cache on fn change
        if self._read_cache is not None:
            self._read_cache.invalidate()  # invalidate search result cache

    def _get_embedding(self, text: str) -> Optional[List[float]]:
        """Get embedding with caching. Returns None if no embedding fn set."""
        if self._embedding_fn is None:
            return None
        key = text[:200]  # cache key
        if key not in self._embedding_cache:
            if len(self._embedding_cache) >= 1000:
                # Evict oldest (first inserted key in Python 3.7+ dict)
                del self._embedding_cache[next(iter(self._embedding_cache))]
            try:
                self._embedding_cache[key] = self._embedding_fn(text)
            except Exception:
                return None
        return self._embedding_cache.get(key)

    # ── search with indexing ───────────────────────────────────────────

    def search(
        self,
        query: str,
        limit: int = 20,
        tags: Optional[List[str]] = None,
        tag_mode: str = "any",
        date_range: Optional[Tuple[str, str]] = None,
        use_decay: bool = True,
        category: str = None,
        min_confidence: float = 0.0,
        sentiment_filter: str = None,
        memory_type: Optional[str] = None,    # Sprint 2
        explain: bool = False,
        session_id: str = "*",               # v4.1: session isolation; "*" = all sessions
    ) -> list:
        """Search memories using BM25-inspired ranking with optional fast indexes.

        Sprint 11: results are served from the LRU read-cache when the query
        signature matches a previously seen search.  On a cache miss the full
        BM25 pipeline runs and the result-set is cached for future calls.
        Access counts are incremented for every returned entry so that hot
        memories receive a relevance boost in future searches.

        Bug fix: BM25 IDF is always computed over the full corpus (self.memories)
        so that type/sentiment filters do not corrupt IDF weights.  Filters are
        applied AFTER scoring.

        Feature: recall_priority from MEMORY_TYPE_CONFIGS is applied to each
        scored entry so that e.g. mistake memories (recall_priority=1.0) float
        to the top.

        Args:
            query: Search query string.
            limit: Maximum results.
            memory_type: Optional filter — only return entries of this type.
            explain: If True, return SearchResult objects with score explanations.
        """
        _t0 = time.monotonic()

        # ── cache key ───────────────────────────────────────────────────
        # v4.1: include session_id in cache key so sessions don't share results
        cache_key = json.dumps(
            [query, limit, tags, tag_mode, date_range, use_decay,
             category, min_confidence, sentiment_filter, memory_type, explain,
             session_id],
            sort_keys=True, default=str,
        )

        if self._read_cache is not None:
            cached = self._read_cache.get(cache_key)
            if cached is not None:
                self._perf.record_search((time.monotonic() - _t0) * 1000)
                return cached

        # ── full search pipeline ─────────────────────────────────────────
        # Bug fix (Bug 2): always build the BM25 index from the FULL corpus
        # so that IDF weights are never corrupted by a filtered subset.
        if self.search_engine._doc_count != len(self.memories):
            self.search_engine.build_index(self.memories)

        # v4.x — Semantic query expansion via SemanticExpander
        if self._semantic_expander:
            query = self._semantic_expander.expand(query)

        decay_fn = self.decay.score if use_decay else None

        # Fetch a generous pool from the full corpus, then filter & trim.
        # Using limit * 10 (min 200) ensures filters don't starve results.
        fetch_limit = max(limit * 10, 200)
        search_results = self.search_engine.search(
            query=query,
            memories=self.memories,
            limit=fetch_limit,
            category=category,
            min_score=min_confidence,
            decay_fn=decay_fn,
            session_id=session_id,
        )

        # ── post-scoring filters (Bug 2 fix: applied AFTER BM25 scoring) ──
        if sentiment_filter:
            search_results = [
                r for r in search_results
                if hasattr(r.entry, "sentiment")
                and r.entry.sentiment
                and sentiment_filter in r.entry.sentiment
            ]
        if memory_type is not None:
            search_results = [
                r for r in search_results
                if getattr(r.entry, "memory_type", "episodic") == memory_type
            ]

        # ── Sprint 3: hybrid BM25 + semantic scoring ──────────────────────
        if self._embedding_fn is not None:
            query_vec = self._get_embedding(query)
            if query_vec is not None:
                from .utils import cosine_similarity
                bm25_weight = 0.4
                semantic_weight = 0.6
                hybrid_results = []
                for result in search_results:
                    entry_vec = self._get_embedding(result.entry.content[:500])
                    if entry_vec is not None:
                        sem_score = cosine_similarity(query_vec, entry_vec)
                        hybrid_score = bm25_weight * result.relevance + semantic_weight * sem_score
                        hybrid_results.append(SearchResult(
                            entry=result.entry,
                            score=hybrid_score,
                            relevance=hybrid_score,
                            matched_terms=result.matched_terms,
                            explanation=result.explanation + f" [hybrid: bm25={result.relevance:.3f} sem={sem_score:.3f}]",
                        ))
                    else:
                        hybrid_results.append(result)
                search_results = sorted(hybrid_results, key=lambda r: r.score, reverse=True)

        # ── Feature 1: recall_priority boost ─────────────────────────────
        for r in search_results:
            priority = MEMORY_TYPE_CONFIGS.get(
                getattr(r.entry, "memory_type", "episodic"), {}
            ).get("recall_priority", 1.0)
            r.score *= priority

        # Re-sort after recall_priority adjustment
        search_results.sort(key=lambda r: r.score, reverse=True)
        search_results = search_results[:limit]

        # Reinforce accessed memories & record access counts
        for r in search_results:
            self.decay.reinforce(r.entry)
            self._record_access(r.entry.hash)   # Sprint 11 access tracking

        # Apply access-count boost and re-sort (Sprint 11)
        if search_results:
            boosted = []
            for r in search_results:
                boost = self._access_tracker.boost_score(r.entry.hash)
                boosted.append((r, r.score * boost))
            boosted.sort(key=lambda x: x[1], reverse=True)
            search_results = [r for r, _ in boosted]

        if explain:
            self._perf.record_search((time.monotonic() - _t0) * 1000)
            if self._read_cache is not None:
                self._read_cache.put(cache_key, search_results)
            return search_results

        # Backward compat: return MemoryEntry with search-time confidence
        # Uses copy to avoid mutating the canonical entry in the index
        entries = []
        for r in search_results:
            entry_copy = copy.copy(r.entry)
            entry_copy.confidence = r.relevance
            entries.append(entry_copy)

        elapsed_ms = (time.monotonic() - _t0) * 1000
        self._perf.record_search(elapsed_ms)
        if self._read_cache is not None:
            self._read_cache.put(cache_key, entries)
        return entries
    
    def _search_indexed(self, 
                       query: str,
                       limit: int,
                       tags: Optional[List[str]],
                       tag_mode: str,
                       date_range: Optional[Tuple[str, str]],
                       use_decay: bool) -> List[MemoryEntry]:
        """Fast search using indexes."""
        
        # Get results from indexes
        indexed_results = self.index_manager.search(
            query=query,
            tags=tags,
            tag_mode=tag_mode,
            date_range=date_range,
            limit=limit * 2  # Get more for decay scoring
        )
        
        if not indexed_results:
            return []
        
        # Convert hash results to memory objects
        hash_to_memory = {m.hash: m for m in self.memories}
        results = []
        
        for memory_hash, base_score in indexed_results:
            if memory_hash in hash_to_memory:
                memory = hash_to_memory[memory_hash]
                
                # Apply decay scoring if requested
                if use_decay:
                    decay_score = self.decay.score(memory)
                    final_score = base_score * (0.5 + decay_score)
                    # Reinforce memory (simulate access)
                    self.decay.reinforce(memory)
                else:
                    final_score = base_score
                
                results.append((memory, final_score))
        
        # Sort by final score and return
        results.sort(key=lambda x: x[1], reverse=True)
        return [memory for memory, score in results[:limit]]
    
    def _search_legacy(self, query: str, limit: int, use_decay: bool) -> List[MemoryEntry]:
        """Fallback to legacy search method."""
        import re
        
        query_lower = query.lower()
        results = []
        
        for memory in self.memories:
            content_lower = memory.content.lower()
            
            # Simple text matching
            if query_lower in content_lower:
                if use_decay:
                    decay_score = self.decay.score(memory)
                    self.decay.reinforce(memory)
                    score = decay_score
                else:
                    score = 1.0
                
                results.append((memory, score))
        
        # Sort by score
        results.sort(key=lambda x: x[1], reverse=True)
        return [memory for memory, score in results[:limit]]

    # ── ingestion ───────────────────────────────────────────────────────

    def ingest(
        self,
        content: str,
        source: str = "inline",
        category: str = "general",
        memory_type: str = DEFAULT_TYPE,
        type_config: Optional[Dict] = None,
        tags: Optional[List[str]] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        channel_id: Optional[str] = None,
    ) -> int:
        """Ingest raw text. Returns count of new memories added.

        Sprint 2: accepts optional *memory_type* and *type_config* to attach
        structured type information to each entry.  Backward-compatible —
        existing callers that don't pass these get episodic defaults.

        v4.6.5: Runs LLM enrichment hook if configured (enricher= param).
        v4.6.6: Filters metadata junk lines and credentials before storing.

        Args:
            content: Raw text to ingest (multi-line supported).
            source: Source label (file path, "inline", etc.).
            category: Category label (general, strategic, etc.).
            memory_type: One of the canonical types or a custom string.
                Defaults to "episodic".
            type_config: For custom types, a dict with optional keys
                decay_multiplier, importance_boost, recall_priority.
            tags: Optional explicit tags to merge with auto-extracted tags.
            agent_id: Override agent scoping (default: self.agent_name).
            session_id: Tag by session.
            channel_id: Tag by channel.
        """
        cfg = get_type_config(memory_type, type_config)
        count = 0
        effective_agent = agent_id or self.agent_name

        for i, line in enumerate(content.split("\n")):
            stripped = line.strip()
            if len(stripped) < 15 or stripped.startswith("```") or stripped == "---":
                continue

            # v4.6.6 — Filter metadata junk and credentials
            if _METADATA_LINE_RE.search(stripped):
                continue
            if _CREDENTIAL_RE.search(stripped):
                continue

            entry = MemoryEntry(stripped, source, i + 1, category,
                                memory_type=memory_type)
            if entry.hash in self._hashes:
                continue

            # Process through gating system
            gate_priority = self.gating.classify(stripped)
            if gate_priority == "P3":  # Skip noise
                continue

            entry.tags = self._extract_tags(stripped)
            # Merge caller-supplied tags with auto-extracted tags (Bug fix #12)
            if tags:
                entry.tags = sorted(set(entry.tags) | set(tags))
            entry.sentiment = self.sentiment.analyze(stripped)

            # Apply type importance boost
            boost = cfg.get("importance_boost", 1.0)
            if boost != 1.0:
                entry.importance = min(entry.importance * boost, self.decay.max_score)

            # Store type_config for custom types
            if type_config:
                entry.type_metadata["_type_config"] = type_config

            # v4.6.5 — agent/session/channel scoping
            if effective_agent:
                entry.agent_id = effective_agent
            if session_id:
                entry.session_id = session_id
            if channel_id:
                entry.channel_id = channel_id

            self.memories.append(entry)
            self._hashes.add(entry.hash)
            self.search_engine.mark_dirty()

            if self.use_indexing and self.index_manager:
                self.index_manager.add_memory(entry)

            # Sprint 11 — WAL append
            self._wal.append(entry.to_dict())

            # v4.6.5 — LLM enrichment
            if self._enricher is not None:
                enrichment = self._run_enrichment(stripped)
                if enrichment:
                    self._apply_enrichment_to_entry(entry, enrichment)
                    self._feed_cooccurrence_from_enrichment(stripped, enrichment)

            # v4.x — Co-occurrence update
            self._update_cooccurrence(stripped)

            count += 1

        # Invalidate read-cache on write
        if count and self._read_cache is not None:
            self._read_cache.invalidate()

        # Auto-flush if WAL threshold is reached
        if self._wal.should_flush():
            self.flush()

        return count

    def ingest_file(self, file_path: str, category: str = "tactical") -> int:
        """Ingest a single file."""
        if not os.path.exists(file_path):
            return 0
        
        try:
            with open(file_path, encoding="utf-8") as f:
                content = f.read()
            return self.ingest(content, source=file_path, category=category)
        except (OSError, UnicodeDecodeError):
            return 0

    def ingest_directory(self, dir_path: str, category: str = "tactical",
                        pattern: str = "*.md") -> int:
        """Ingest all matching files in a directory."""
        if not os.path.exists(dir_path):
            return 0
        
        total = 0
        for path in Path(dir_path).glob(pattern):
            if path.is_file():
                total += self.ingest_file(str(path), category)
        return total

    # ── Sprint 2: typed ingest methods ──────────────────────────────────

    def ingest_mistake(
        self,
        what_happened: str,
        correction: str,
        root_cause: Optional[str] = None,
        severity: str = "medium",
        tags: Optional[List[str]] = None,
        source: str = "mistake",
    ) -> Optional[MemoryEntry]:
        """Ingest a structured mistake memory.

        Mistakes receive 2× importance, 10× half-life, and are surfaced
        proactively in context packets via the "Known Pitfalls" section.

        Args:
            what_happened: Brief description of what went wrong.
            correction: What should be done instead.
            root_cause: Why it happened (optional but strongly recommended).
            severity: "high", "medium", or "low" (default "medium").
            tags: Extra tags to attach.
            source: Source label (default "mistake").

        Returns:
            The created MemoryEntry, or None if duplicate.
        """
        if severity not in SEVERITY_LEVELS:
            severity = "medium"

        content = format_mistake_content(what_happened, correction, root_cause, severity)
        cfg = MEMORY_TYPE_CONFIGS["mistake"]

        entry = MemoryEntry(content, source, 0, "mistake", memory_type="mistake")
        if entry.hash in self._hashes:
            return None

        entry.importance = min(1.0 * cfg["importance_boost"], self.decay.max_score)
        entry.tags = list(set(["mistake", f"severity:{severity}"] + (tags or [])))
        entry.sentiment = self.sentiment.analyze(content)
        entry.type_metadata = {
            "what_happened": what_happened,
            "correction": correction,
            "root_cause": root_cause,
            "severity": severity,
        }

        self.memories.append(entry)
        self._hashes.add(entry.hash)
        self.search_engine.mark_dirty()

        if self.use_indexing and self.index_manager:
            self.index_manager.add_memory(entry)

        # Sprint 11 — WAL
        self._wal.append(entry.to_dict())
        if self._read_cache is not None:
            self._read_cache.invalidate()
        if self._wal.should_flush():
            self.flush()

        return entry

    def ingest_fact(
        self,
        content: str,
        source: str = "fact",
        tags: Optional[List[str]] = None,
        category: str = "general",
    ) -> int:
        """Ingest a fact-type memory (normal decay, high recall priority)."""
        return self._ingest_typed(
            content, source, category, "fact", tags=tags
        )

    def ingest_preference(
        self,
        content: str,
        source: str = "preference",
        tags: Optional[List[str]] = None,
        category: str = "general",
    ) -> int:
        """Ingest a preference-type memory (3× slower decay, high context-matched recall)."""
        return self._ingest_typed(
            content, source, category, "preference", tags=tags
        )

    def ingest_procedure(
        self,
        content: str,
        source: str = "procedure",
        tags: Optional[List[str]] = None,
        category: str = "general",
    ) -> int:
        """Ingest a procedure-type memory (3× slower decay, high task-matched recall)."""
        return self._ingest_typed(
            content, source, category, "procedure", tags=tags
        )

    def _ingest_typed(
        self,
        content: str,
        source: str,
        category: str,
        memory_type: str,
        tags: Optional[List[str]] = None,
    ) -> int:
        """Helper: ingest one or more lines with a specific memory type.

        Feature 2 fix: applies the same P0-P3 input gating that ``ingest()``
        uses so that P3 (ephemeral) content is never silently stored via the
        typed-ingest helpers.
        """
        cfg = get_type_config(memory_type)
        count = 0
        for i, line in enumerate(content.split("\n")):
            stripped = line.strip()
            if len(stripped) < 15 or stripped.startswith("```") or stripped == "---":
                continue

            # Feature 2: apply gating — drop P3 noise
            if not self.gating.should_store(stripped):
                continue

            entry = MemoryEntry(stripped, source, i + 1, category,
                                memory_type=memory_type)
            if entry.hash in self._hashes:
                continue

            entry.importance = min(1.0 * cfg.get("importance_boost", 1.0),
                                   self.decay.max_score)
            entry.tags = list(set([memory_type] + self._extract_tags(stripped) + (tags or [])))
            entry.sentiment = self.sentiment.analyze(stripped)

            self.memories.append(entry)
            self._hashes.add(entry.hash)
            self.search_engine.mark_dirty()

            if self.use_indexing and self.index_manager:
                self.index_manager.add_memory(entry)

            # Sprint 11 — WAL
            self._wal.append(entry.to_dict())
            count += 1

        if count:
            if self._read_cache is not None:
                self._read_cache.invalidate()
            if self._wal.should_flush():
                self.flush()

        return count

    # ── analysis & synthesis ────────────────────────────────────────────

    def analyze(self, query: str, limit: int = 10) -> Dict:
        """Analyze memories related to a query."""
        memories = self.search(query, limit=limit)
        if not memories:
            return {"status": "no_results", "query": query}
        
        # Basic analysis (can be enhanced)
        categories = defaultdict(int)
        sentiment_scores = []
        date_range = []
        
        for memory in memories:
            if memory.category:
                categories[memory.category] += 1
            if memory.sentiment and 'compound' in memory.sentiment:
                sentiment_scores.append(memory.sentiment['compound'])
            date_range.append(memory.created[:10])
        
        return {
            "status": "success",
            "query": query,
            "total_memories": len(memories),
            "categories": dict(categories),
            "avg_sentiment": sum(sentiment_scores) / len(sentiment_scores) if sentiment_scores else 0,
            "date_range": [min(date_range), max(date_range)] if date_range else [],
            "sample_memories": [m.content[:100] for m in memories[:3]]
        }

    def synthesize_knowledge(self, topic: str, limit: int = 20) -> Optional[str]:
        """Generate knowledge synthesis using the KnowledgeSynthesizer."""
        memories = self.search(topic, limit=limit)
        if not memories:
            return None
        
        memory_texts = [m.content for m in memories]
        return self.synthesis.synthesize(memory_texts, topic)

    # ── context packets ──────────────────────────────────────────────────

    def build_context_packet(
        self,
        task: str,
        tags: Optional[List[str]] = None,
        category: str = None,
        environment: Optional[Dict[str, str]] = None,
        instructions: Optional[List[str]] = None,
        max_memories: int = 15,
        max_tokens: int = 4000,
        min_relevance: float = 0.1,
        include_mistakes: bool = True,     # Sprint 2
        max_pitfalls: int = 5,             # Sprint 2
    ) -> "ContextPacket":
        """Build a context packet for sub-agent spawning.

        Searches the memory store for relevant context and packages it
        into a structured ContextPacket that can be injected into a
        sub-agent's prompt at spawn time.

        Solves the "cold spawn" problem: sub-agents start with zero
        context, leading to confident mistakes based on incomplete
        information. A context packet gives them relevant onboarding.

        Args:
            task: Description of the sub-agent's task (used as search query).
            tags: Optional tag filters to narrow search.
            category: Optional category filter.
            environment: Key-value pairs (e.g. {"venv": "venv-svi", "python": "3.11"}).
            instructions: Explicit constraints for the sub-agent.
            max_memories: Maximum memories to include (default 15).
            max_tokens: Token budget for rendered output (default 4000).
            min_relevance: Minimum relevance score (default 0.1).

        Returns:
            ContextPacket with .render(), .to_dict(), .trim() methods.

        Example::

            packet = mem.build_context_packet(
                task="Verify antaris-guard installation",
                environment={"venv": "venv-svi"},
                instructions=["Check the venv, not global pip"],
            )
            prompt = f"{packet.render()}\\n\\nYOUR TASK: verify installation"
        """
        builder = ContextPacketBuilder(self)
        return builder.build(
            task=task,
            tags=tags,
            category=category,
            environment=environment,
            instructions=instructions,
            max_memories=max_memories,
            max_tokens=max_tokens,
            min_relevance=min_relevance,
            include_mistakes=include_mistakes,
            max_pitfalls=max_pitfalls,
        )

    def build_context_packet_multi(
        self,
        task: str,
        queries: List[str],
        environment: Optional[Dict[str, str]] = None,
        instructions: Optional[List[str]] = None,
        max_memories: int = 15,
        max_tokens: int = 4000,
        min_relevance: float = 0.1,
    ) -> "ContextPacket":
        """Build a context packet from multiple search queries.

        Useful when a task spans multiple topics. Deduplicates results
        across queries and merges into a single packet.

        Args:
            task: Overall task description.
            queries: List of search queries to run.
            environment: Optional environment context.
            instructions: Optional constraints.
            max_memories: Max total memories.
            max_tokens: Token budget.
            min_relevance: Minimum relevance threshold.

        Returns:
            Merged ContextPacket with deduplicated results.
        """
        builder = ContextPacketBuilder(self)
        return builder.build_multi(
            task=task,
            queries=queries,
            environment=environment,
            instructions=instructions,
            max_memories=max_memories,
            max_tokens=max_tokens,
            min_relevance=min_relevance,
        )

    # ── utility methods ─────────────────────────────────────────────────

    # ── Sprint 11: access pattern learning ──────────────────────────────

    def _record_access(self, entry_id: str) -> None:
        """Increment the access count for a memory entry.

        Called automatically by ``search()`` for every returned result.
        Persisted to ``access_counts.json`` on the next ``flush()``.
        """
        self._access_tracker.record_access(entry_id)

    def get_hot_entries(self, top_n: int = 10) -> List[MemoryEntry]:
        """Return the *top_n* most frequently accessed memory entries.

        Useful for pre-loading important context into packets.

        Args:
            top_n: Number of hot entries to return.

        Returns:
            List of MemoryEntry objects, ordered by access count descending.
        """
        top_ids = self._access_tracker.get_top(top_n)
        hash_to_entry = {m.hash: m for m in self.memories}
        result = []
        for entry_id, _count in top_ids:
            if entry_id in hash_to_entry:
                result.append(hash_to_entry[entry_id])
        return result

    def _extract_tags(self, content: str) -> List[str]:
        """Extract tags from content."""
        tags = []
        content_lower = content.lower()
        
        # Extract explicit tags (@tag format)
        explicit_tags = re.findall(r'@([a-zA-Z][a-zA-Z0-9_-]*)', content)
        tags.extend(explicit_tags)
        
        # Auto-tag based on terms
        for term in self._tag_terms:
            if term.lower() in content_lower:
                tags.append(term)
        
        return list(set(tags))  # Remove duplicates

    def compact(self) -> Dict:
        """Compact memory storage: remove duplicates, expire stale entries, save.

        Sprint 11: returns a richer result dict with shard counts and timing.

        Returns::

            {
                "shards_before": int,
                "shards_after": int,
                "entries_before": int,
                "entries_after": int,
                "space_freed_mb": float,
                "duration_ms": float,
                # backward-compat keys still present:
                "original_count": int,
                "final_count": int,
                "removed_count": int,
            }
        """
        _t0 = time.monotonic()

        # Snapshot shard count and disk usage before compaction
        shards_before = 0
        disk_before = 0.0
        if self.use_sharding and self.shard_manager:
            shards_dir = os.path.join(self.workspace, "shards")
            if os.path.isdir(shards_dir):
                shards_before = len([
                    f for f in os.listdir(shards_dir) if f.endswith(".json")
                ])
                disk_before = sum(
                    os.path.getsize(os.path.join(shards_dir, f))
                    for f in os.listdir(shards_dir) if f.endswith(".json")
                ) / (1024 * 1024)

        entries_before = len(self.memories)

        # Remove exact duplicates (by hash)
        seen_hashes: set = set()
        unique_memories = []
        for memory in self.memories:
            if memory.hash not in seen_hashes:
                unique_memories.append(memory)
                seen_hashes.add(memory.hash)

        # Apply decay-based forgetting: drop entries whose decay score is 0
        # (effectively dead entries that will never be recalled)
        retained_memories = [
            m for m in unique_memories
            if self.decay.score(m) > 0.0
        ]

        # Use consolidation to detect near-duplicate pairs; keep the
        # higher-confidence entry from each pair.
        dup_pairs = self.consolidation.find_duplicates(retained_memories)
        hashes_to_drop: set = set()
        for mem_a, mem_b in dup_pairs:
            # Drop whichever has lower confidence (or the second if tied)
            loser = mem_b if mem_a.confidence >= mem_b.confidence else mem_a
            hashes_to_drop.add(loser.hash)
        consolidated_memories = [
            m for m in retained_memories if m.hash not in hashes_to_drop
        ]

        self.memories = consolidated_memories
        self._hashes = {m.hash for m in self.memories}
        self.search_engine.mark_dirty()

        # Invalidate cache — data has changed
        if self._read_cache is not None:
            self._read_cache.invalidate()

        # Rebuild indexes after compaction
        if self.use_indexing and self.index_manager:
            self.index_manager.rebuild_indexes(self.memories)

        # Flush to disk so shards reflect compacted state
        self.save()
        self._wal.clear()   # WAL is also stale now
        self._perf.record_compaction()

        # Snapshot shard count and disk usage after compaction
        shards_after = 0
        disk_after = 0.0
        if self.use_sharding and self.shard_manager:
            shards_dir = os.path.join(self.workspace, "shards")
            if os.path.isdir(shards_dir):
                shards_after = len([
                    f for f in os.listdir(shards_dir) if f.endswith(".json")
                ])
                disk_after = sum(
                    os.path.getsize(os.path.join(shards_dir, f))
                    for f in os.listdir(shards_dir) if f.endswith(".json")
                ) / (1024 * 1024)

        entries_after = len(self.memories)
        duration_ms = round((time.monotonic() - _t0) * 1000, 1)

        return {
            # Sprint 11 spec keys
            "shards_before": shards_before,
            "shards_after": shards_after,
            "entries_before": entries_before,
            "entries_after": entries_after,
            "space_freed_mb": round(max(disk_before - disk_after, 0.0), 3),
            "duration_ms": duration_ms,
            # Backward-compatible keys
            "original_count": entries_before,
            "final_count": entries_after,
            "removed_count": entries_before - entries_after,
        }

    # ── system management ───────────────────────────────────────────────

    def get_stats(self) -> Dict:
        """Get comprehensive system statistics."""
        from . import __version__ as _pkg_version
        from datetime import datetime, timezone as _tz

        def _entry_age_days(m):
            """Return age in days; fall back to 0 on parse error."""
            try:
                created = getattr(m, "created", None) or getattr(m, "created_at", None)
                if created is None:
                    return 0.0
                if isinstance(created, (int, float)):
                    return (time.time() - float(created)) / 86400
                dt = datetime.fromisoformat(str(created).replace("Z", "+00:00"))
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=_tz.utc)
                return (time.time() - dt.timestamp()) / 86400
            except Exception:
                return 0.0

        # Tier distribution
        hot_entries = sum(1 for m in self.memories if _entry_age_days(m) < 3)
        warm_entries = sum(1 for m in self.memories if 3 <= _entry_age_days(m) < 14)
        cold_entries = sum(1 for m in self.memories if _entry_age_days(m) >= 14)

        # Enrichment stats
        enriched = sum(1 for m in self.memories if getattr(m, "enriched_summary", None))

        # Graph stats
        graph_nodes = 0
        graph_edges = 0
        if self._graph is not None:
            try:
                gs = self._graph.stats()
                graph_nodes = gs.get("nodes", 0)
                graph_edges = gs.get("edges", 0)
            except Exception:
                pass

        # Co-occurrence pairs
        cooccurrence_pairs = 0
        if self._cooccurrence is not None:
            try:
                if hasattr(self._cooccurrence, "total_pairs"):
                    cooccurrence_pairs = self._cooccurrence.total_pairs()
                elif hasattr(self._cooccurrence, "pair_count"):
                    cooccurrence_pairs = self._cooccurrence.pair_count()
            except Exception:
                pass

        # Disk usage
        disk_mb = 0.0
        try:
            for root, _, files in os.walk(self.workspace):
                for fn in files:
                    try:
                        disk_mb += os.path.getsize(os.path.join(root, fn))
                    except OSError:
                        pass
            disk_mb /= (1024 * 1024)
        except Exception:
            pass

        # memory_usage_mb (approximate in-process size)
        import sys as _sys
        try:
            mem_mb = _sys.getsizeof(self.memories) / (1024 * 1024)
        except Exception:
            mem_mb = 0.0

        # search_count from perf monitor
        search_count = getattr(getattr(self, "_perf", None), "search_count", 0)

        stats = {
            "version": _pkg_version,
            "schema_version": "0.4.0",
            "workspace": self.workspace,
            "agent_name": self.agent_name,
            # Primary keys (v5.0.1)
            "total_entries": len(self.memories),
            "hot_entries": hot_entries,
            "warm_entries": warm_entries,
            "cold_entries": cold_entries,
            "wal_size": self._wal.size() if hasattr(self._wal, "size") else 0,
            "enrichment_count": self._enrichment_count,
            "enriched_entries": enriched,
            "enrichment_cost_usd": round(self._enrichment_count * 0.0003, 4),
            "graph_enabled": self._graph is not None,
            "graph_nodes": graph_nodes,
            "graph_edges": graph_edges,
            "cooccurrence_pairs": cooccurrence_pairs,
            "tiered_storage": self._tiered_storage,
            "semantic_expansion": self._semantic_expansion,
            "disk_usage_mb": round(disk_mb, 2),
            "memory_usage_mb": round(mem_mb, 2),
            "search_count": search_count,
            # Backward-compat keys (v4.x tests)
            "total_memories": len(self.memories),
            "total_shards": 0,  # sharding stripped
            "features": {
                "sharding": False,  # stripped from shiro-memory
                "indexing": self.use_indexing,
                "enrichment": self._enricher is not None,
                "graph": self._graph is not None,
            }
        }

        if self.use_indexing and self.index_manager:
            stats["indexing"] = self.index_manager.get_combined_stats()

        # Memory distribution by category
        categories = defaultdict(int)
        for memory in self.memories:
            categories[memory.category or "uncategorized"] += 1
        stats["categories"] = dict(categories)

        return stats

    def stats(self) -> Dict:
        """Alias for get_stats()."""
        return self.get_stats()

    def migrate_to_v4(self) -> Dict:
        """Manually trigger migration to v0.4 format."""
        return self.migration_manager.migrate("0.4.0")
    
    def rollback_migration(self) -> Dict:
        """Rollback the most recent migration."""
        return self.migration_manager.rollback()
    
    def validate_data(self) -> Dict:
        """Validate the current data schema."""
        return self.migration_manager.validate_schema()
    
    def rebuild_indexes(self):
        """Rebuild all search indexes from current memories."""
        if self.use_indexing and self.index_manager:
            self.index_manager.rebuild_indexes(self.memories)
            self.index_manager.save_all_indexes()
    
    def get_migration_history(self) -> List[Dict]:
        """Get history of applied migrations."""
        return self.migration_manager.get_migration_history()

    # ── Backward-compatible methods from v0.3 ──────────────────────

    def stats(self) -> Dict:
        """System statistics including Sprint 11 performance metrics.

        Backward-compatible — all v0.3/v0.4 keys are preserved.  New Sprint 11
        keys are added under their own names.

        Returns::

            {
                # v0.3 compat keys
                "total": int,
                "avg_score": float,
                "archive_candidates": int,
                "sentiments": dict,
                "avg_confidence": float,
                "categories": dict,
                # Sprint 11 performance keys
                "total_entries": int,
                "total_shards": int,
                "search_count": int,
                "avg_search_time_ms": float,
                "cache_hit_rate": float,
                "wal_pending_entries": int,
                "last_compaction": str | None,
                "disk_usage_mb": float,
                "memory_usage_mb": float,
            }
        """
        s = self.get_stats()
        now = datetime.now(timezone.utc)
        scores = [self.decay.score(m, now) for m in self.memories]
        sentiments: Dict[str, int] = defaultdict(int)
        for m in self.memories:
            dom = self.sentiment.dominant(m.sentiment)
            if dom:
                sentiments[dom] += 1
        # v0.3 compat
        s["total"] = len(self.memories)
        s["avg_score"] = round(sum(scores) / max(len(scores), 1), 4)
        s["archive_candidates"] = sum(1 for sc in scores if sc < self.decay.archive_threshold)
        s["sentiments"] = dict(sentiments)
        s["avg_confidence"] = round(
            sum(m.confidence for m in self.memories) / max(len(self.memories), 1), 4
        )

        # Sprint 11 performance metrics
        shards_count = 0
        disk_mb = 0.0
        if self.use_sharding and self.shard_manager:
            shards_dir = os.path.join(self.workspace, "shards")
            if os.path.isdir(shards_dir):
                shard_files = [
                    os.path.join(shards_dir, f)
                    for f in os.listdir(shards_dir) if f.endswith(".json")
                ]
                shards_count = len(shard_files)
                disk_mb = sum(os.path.getsize(p) for p in shard_files) / (1024 * 1024)

        import sys
        mem_mb = sys.getsizeof(self.memories) / (1024 * 1024)

        s["total_entries"] = len(self.memories)
        s["total_shards"] = shards_count
        s["search_count"] = self._perf.search_count
        s["avg_search_time_ms"] = self._perf.avg_search_time_ms
        s["cache_hit_rate"] = (
            round(self._read_cache.hit_rate, 4) if self._read_cache is not None else 0.0
        )
        s["wal_pending_entries"] = self._wal.pending_count()
        s["last_compaction"] = self._perf.last_compaction
        s["disk_usage_mb"] = round(disk_mb, 3)
        s["memory_usage_mb"] = round(mem_mb, 3)
        return s

    def ingest_with_gating(self, content: str, source: str = "inline",
                           context: Dict = None) -> int:
        """Ingest with P0-P3 input classification. P3 content is dropped.
        
        Multi-line content is split and each line classified independently.
        """
        count = 0
        for i, line in enumerate(content.split("\n")):
            stripped = line.strip()
            # Bug fix: align minimum length with ingest() (was 5, now 15)
            if len(stripped) < 15:
                continue
            gate_context = context or {}
            gate_context.update({"source": source, "line": i + 1})
            routing = self.gating.route(stripped, gate_context)
            if not routing["store"]:
                continue
            category = routing.get("category", "tactical")
            count += self.ingest(stripped, source=source, category=category)
        return count

    def on_date(self, date: str) -> List[MemoryEntry]:
        """Get memories from a specific date."""
        return self.temporal.on_date(self.memories, date)

    def between(self, start: str, end: str) -> List[MemoryEntry]:
        """Get memories between two dates."""
        return self.temporal.between(self.memories, start, end)

    def narrative(self, topic: str = None) -> str:
        """Build a narrative from memories, optionally filtered by topic."""
        return self.temporal.narrative(self.memories, topic=topic)

    def forget(self, topic: str = None, entity: str = None,
               before_date: str = None) -> Dict:
        """Selectively forget memories with audit trail.

        Bug fix (Bug 1): ForgettingEngine has no ``forget()`` method; instead
        it exposes ``forget_topic()``, ``forget_entity()``, and
        ``forget_before()``.  This method now delegates correctly and supports
        combining multiple criteria (applied in sequence).

        Args:
            topic: Remove all memories containing this topic string.
            entity: Remove all memories mentioning this entity.
            before_date: Remove all memories created before this date (YYYY-MM-DD).

        Returns:
            Dict with keys ``removed`` (list[MemoryEntry]) and ``audit`` (dict).
        """
        if topic is None and entity is None and before_date is None:
            return {"removed": [], "audit": self.forgetting.audit_log([])}

        current = list(self.memories)
        all_forgotten: List = []

        if topic is not None:
            current, forgotten = self.forgetting.forget_topic(current, topic)
            all_forgotten.extend(forgotten)

        if entity is not None:
            current, forgotten = self.forgetting.forget_entity(current, entity)
            all_forgotten.extend(forgotten)

        if before_date is not None:
            current, forgotten = self.forgetting.forget_before(current, before_date)
            all_forgotten.extend(forgotten)

        # Deduplicate (a memory might match multiple criteria)
        seen: set = set()
        unique_forgotten = []
        for m in all_forgotten:
            if m.hash not in seen:
                unique_forgotten.append(m)
                seen.add(m.hash)

        result = {
            "removed": unique_forgotten,
            "audit": self.forgetting.audit_log(unique_forgotten),
        }

        if unique_forgotten:
            removed_set = {m.hash for m in unique_forgotten}
            # Bug fix: `current` is already the post-forget filtered list from
            # forget_topic/forget_entity/forget_before — no need to re-filter.
            self.memories = current
            self._hashes -= removed_set
            self.search_engine.mark_dirty()
            if self._read_cache is not None:
                self._read_cache.invalidate()
            # Log to audit
            for m in unique_forgotten:
                self._append_audit({"action": "forget", "hash": m.hash,
                                    "content_preview": m.content[:50],
                                    "timestamp": datetime.now(timezone.utc).isoformat()})

        return result

    def reindex(self) -> None:
        """Force a full search index rebuild."""
        self.search_engine.reindex(self.memories)

    def consolidate(self) -> Dict:
        """Run consolidation: dedup, clustering, contradiction detection."""
        return self.consolidation.run(self.memories)

    def compress_old(self, days: int = 7) -> list:
        """Compress memories older than N days."""
        mem_dir = os.path.join(self.workspace, "memory")
        return self.compression.compress_old_files(mem_dir, days)

    def synthesize(self, research_results: Dict = None) -> Dict:
        """Integrate research findings into memory."""
        report = self.synthesis.run_cycle(self.memories, research_results=research_results)
        # Add synthesized entries to memory store
        if report.get("synthesized_entries", 0) > 0 and "new_entries" in report:
            for entry_dict in report["new_entries"]:
                entry = MemoryEntry.from_dict(entry_dict)
                if "synthesis" not in entry.tags:
                    entry.tags.append("synthesis")
                self.memories.append(entry)
                if self.use_indexing and self.index_manager:
                    self.index_manager.add_memory(entry)
        return report

    def research_suggestions(self, limit: int = 5) -> List[Dict]:
        """Get suggestions for knowledge gaps."""
        return self.synthesis.suggest_research_topics(self.memories, limit=limit)

    # ── Feature 3: Export / Import API ─────────────────────────────────

    def export(self, output_path: str, include_metadata: bool = True) -> int:
        """Export all memories to a JSON file.

        Args:
            output_path: Destination file path.
            include_metadata: Include enrichment data, scores, graph entities (default True).

        Returns:
            Number of entries exported.
        """
        entries = []
        for entry in self.memories:
            d = entry.to_dict()
            if not include_metadata:
                for k in ("enriched_summary", "tags", "keywords", "search_queries",
                          "graph_entities", "score"):
                    d.pop(k, None)
            entries.append(d)
        data = {
            "version": "5.0.1",
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "workspace": self.workspace,
            "agent_name": self.agent_name,
            "entries": entries,
        }
        atomic_write_json(output_path, data)
        return len(entries)

    def import_from(self, input_path: str, merge: bool = True) -> int:
        """Import memories from a JSON file exported by :meth:`export`.

        Args:
            input_path: Path to the JSON file.
            merge: If True, merge with existing memories. If False, replace.

        Returns:
            Number of new entries added.
        """
        with open(input_path, encoding="utf-8") as fh:
            data = json.load(fh)

        # Support both old array format and new dict format
        if isinstance(data, list):
            entries_data = data
        else:
            entries_data = data.get("entries", [])

        if not merge:
            self.memories = []
            self._hashes = set()

        count = 0
        for entry_dict in entries_data:
            try:
                entry = MemoryEntry.from_dict(entry_dict)
            except Exception:
                continue
            if entry.hash in self._hashes:
                continue
            self.memories.append(entry)
            self._hashes.add(entry.hash)
            count += 1

        if count:
            self.search_engine.mark_dirty()
            if self._read_cache is not None:
                self._read_cache.invalidate()
            self.save()

        return count

    def import_memories(self, path: str) -> int:
        """Import memories from a previously exported JSON file (alias for import_from)."""
        return self.import_from(path, merge=True)

    # ── shared pool integration ──────────────────────────────────────────

    def enable_shared_pool(
        self,
        pool_dir: str,
        pool_name: str = "default",
        agent_id: str = None,
        role: str = "write",
        load_existing: bool = True,
    ) -> "SharedMemoryPool":
        """Attach a SharedMemoryPool to this MemorySystem instance.

        Enables multi-agent memory sharing. The pool is created (or loaded)
        at pool_dir. This agent is registered with the given role.

        Args:
            pool_dir: Directory for the shared pool files.
            pool_name: Pool identifier (default "default").
            agent_id: This agent's ID in the pool. Defaults to the workspace basename.
            role: Access role — "read", "write", or "admin" (default "write").
            load_existing: If True, load an existing pool from disk (default True).

        Returns:
            The attached SharedMemoryPool instance.
        """
        if agent_id is None:
            agent_id = os.path.basename(self.workspace.rstrip("/"))

        pool = SharedMemoryPool(pool_dir, pool_name)
        if load_existing:
            pool.load()

        # Register if not already registered
        if agent_id not in pool.permissions:
            pool.register_agent(agent_id, role)

        self._shared_pool = pool
        self._shared_agent_id = agent_id
        return pool

    def get_shared_pool(self) -> Optional["SharedMemoryPool"]:
        """Return the attached SharedMemoryPool, or None if not enabled."""
        return self._shared_pool

    def shared_write(
        self,
        content: str,
        namespace: str = "shared",
        category: str = "general",
        metadata: dict = None,
    ) -> Optional[object]:
        """Write a memory to the attached shared pool.

        Raises RuntimeError if no shared pool is attached (call enable_shared_pool first).
        """
        if self._shared_pool is None:
            raise RuntimeError("No shared pool attached. Call enable_shared_pool() first.")
        return self._shared_pool.write(
            self._shared_agent_id, content, namespace, category, metadata
        )

    def shared_search(
        self,
        query: str,
        namespace: str = None,
        limit: int = 20,
        instrumentation_context=None,
    ) -> list:
        """Search the attached shared pool.

        If instrumentation_context is provided (a SearchContext), populates
        retrieved_memory_ids for later mark_used() calls.

        Raises RuntimeError if no shared pool is attached.
        """
        if self._shared_pool is None:
            raise RuntimeError("No shared pool attached. Call enable_shared_pool() first.")

        if hasattr(self._shared_pool, 'search_with_context') and instrumentation_context is not None:
            results, _ = self._shared_pool.search_with_context(
                self._shared_agent_id, query, instrumentation_context, limit, namespace
            )
        else:
            results = self._shared_pool.read(
                self._shared_agent_id, query, namespace, limit
            )
        return results

    def shared_mark_used(
        self,
        memory_ids: list,
        boost_factor: float = 1.3,
    ) -> int:
        """Signal that retrieved shared memories were used in a response.

        Triggers cross-agent relevance boosting for memories written by other agents.

        Returns:
            Number of memories boosted.
        """
        if self._shared_pool is None:
            raise RuntimeError("No shared pool attached.")
        return self._shared_pool.mark_used_batch(
            self._shared_agent_id, memory_ids, boost_factor
        )

    def _append_audit(self, entry: Dict) -> None:
        """Append an entry to the audit log."""
        audit = []
        if os.path.exists(self.audit_path):
            with open(self.audit_path) as f:
                audit = json.load(f)
        audit.append(entry)
        atomic_write_json(self.audit_path, audit)

    # ── v3.2 Instrumentation ──────────────────────────────────────────────────

    def mark_retrieved(self, memory_ids: List[str], context) -> None:
        """Record that a set of memories were retrieved for a query.

        Called automatically when instrumentation_context is passed to search().
        Logs the retrieval event to the instrumentation log for later analysis.

        Args:
            memory_ids: List of memory hashes that were retrieved.
            context: SearchContext object for this search request.
        """
        context.retrieved_memory_ids = list(memory_ids)
        event = {
            "event": "retrieved",
            "request_id": context.request_id,
            "query": context.query,
            "memory_ids": memory_ids,
            "count": len(memory_ids),
            "timestamp": context.timestamp,
            "context_id": context.context_id,
        }
        try:
            with open(self._instrumentation_log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(event) + "\n")
        except OSError:
            pass  # Instrumentation failures are non-fatal

    def mark_used(self, memory_ids: List[str], context=None) -> int:
        """Signal that specific memories were used in the agent's response.

        Boosts the relevance of used memories and resets their decay age.
        Optionally logs a usage signal if opt_in_to_aggregation is True.

        Args:
            memory_ids: List of memory hashes that appeared in the response.
            context: Optional SearchContext for linking to the retrieval event.

        Returns:
            Number of memories successfully boosted.
        """
        if context is not None:
            context.used_memory_ids = list(memory_ids)

        boosted = 0
        for memory_id in memory_ids:
            if self.boost_relevance(memory_id):
                boosted += 1

        # Log usage event
        event = {
            "event": "used",
            "memory_ids": memory_ids,
            "count": len(memory_ids),
            "timestamp": time.time(),
            "request_id": context.request_id if context else None,
        }
        try:
            with open(self._instrumentation_log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(event) + "\n")
        except OSError:
            pass

        # Log to audit logger if available
        if context is not None and hasattr(context, 'audit_logger') and context.audit_logger is not None:
            try:
                for memory_id in memory_ids:
                    context.audit_logger.log("recall", {
                        "memory_id": memory_id,
                        "context_id": context.context_id,
                        "request_id": context.request_id,
                        "session_id": context.session_id,
                    })
            except Exception:
                # Audit logging failures are non-fatal
                pass

        # Report anonymized signal if user opted in
        if self.opt_in_to_aggregation and context is not None:
            from .instrumentation import build_usage_signal
            self.report_usage_signal(build_usage_signal(context))

        # Invalidate cache so boosted memories rank higher on next search
        if boosted and self._read_cache is not None:
            self._read_cache.invalidate()

        return boosted

    def boost_relevance(self, memory_id: str, multiplier: float = 1.5) -> bool:
        """Boost the importance/relevance of a memory by ID.

        Increases the memory's importance score and resets its decay age,
        making it surface higher in future searches.

        Args:
            memory_id: The memory hash to boost.
            multiplier: Importance multiplier (default 1.5 = 50% boost).

        Returns:
            True if the memory was found and boosted, False otherwise.
        """
        for entry in self.memories:
            if entry.hash == memory_id:
                entry.importance = min(entry.importance * multiplier, 10.0)
                # Reset decay: freshen the memory as if it was just accessed
                entry.last_accessed = datetime.now(timezone.utc).isoformat()
                entry.access_count += 1
                self.search_engine.mark_dirty()
                return True
        return False

    def report_usage_signal(self, data: Dict) -> None:
        """Append an anonymized usage signal for crowdsourced PPMI training.

        Only writes when opt_in_to_aggregation is True. Data contains only
        statistical information — never actual memory content.

        Args:
            data: Anonymized signal dict from build_usage_signal().
        """
        if not self.opt_in_to_aggregation:
            return
        try:
            with open(self._usage_signals_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(data) + "\n")
        except OSError:
            pass

    # ── v3.2 Co-occurrence Semantic Boost (v5.0.1 upgrade) ─────────────────────

    def search_with_context(
        self,
        query: str,
        limit: int = 20,
        instrumentation_context=None,
        cooccurrence_boost: bool = False,
        **kwargs,
    ) -> tuple:
        """Search memories with optional instrumentation and co-occurrence boost.

        Args:
            query: Search query string.
            limit: Maximum results to return.
            instrumentation_context: Optional pre-built SearchContext.
            cooccurrence_boost: Apply PPMI co-occurrence query expansion.
            **kwargs: Additional args forwarded to search().

        Returns:
            Tuple of (results, SearchContext).
        """
        from .instrumentation import SearchContext

        ctx = instrumentation_context or SearchContext(query=query)

        expanded_query = query
        if cooccurrence_boost and self._cooccurrence is not None:
            try:
                # CooccurrenceIndex uses similar_words(); build expansion manually
                tokens = query.lower().split()
                extras = []
                seen = set(tokens)
                for tok in tokens[:3]:  # expand top 3 query terms
                    for word, _score in self._cooccurrence.similar_words(tok, top_k=2):
                        if word not in seen:
                            extras.append(word)
                            seen.add(word)
                if extras:
                    expanded_query = query + " " + " ".join(extras)
                if hasattr(ctx, "expanded_query"):
                    ctx.expanded_query = expanded_query
            except Exception:
                pass
        elif self._semantic_expander:
            expanded_query = self._semantic_expander.expand(query)
            if hasattr(ctx, "expanded_query"):
                ctx.expanded_query = expanded_query

        results = self.search(expanded_query, limit=limit, explain=True, **kwargs)

        retrieved_ids = [r.entry.hash for r in results]
        self.mark_retrieved(retrieved_ids, ctx)

        if kwargs.get("explain"):
            return results, ctx

        entries = []
        for r in results:
            entry_copy = copy.copy(r.entry)
            entry_copy.confidence = r.relevance
            entries.append(entry_copy)
        return entries, ctx

    # ── v4.6.5 LLM Enrichment ──────────────────────────────────────────────────

    def _run_enrichment(self, content: str) -> dict:
        """Run the enricher callable and return the result dict (or {})."""
        if self._enricher is None:
            return {}
        try:
            result = self._enricher(content)
            if isinstance(result, dict):
                self._enrichment_count += 1
                return result
        except Exception:
            pass
        return {}

    def _apply_enrichment_to_entry(self, entry, enrichment: dict) -> None:
        """Write enrichment fields onto a MemoryEntry in-place."""
        if enrichment.get("summary"):
            entry.enriched_summary = enrichment["summary"]
        if enrichment.get("tags"):
            existing = set(entry.tags or [])
            existing.update(enrichment["tags"])
            entry.tags = list(existing)
        if enrichment.get("keywords"):
            entry.keywords = enrichment.get("keywords", [])
        if enrichment.get("search_queries"):
            entry.search_queries = enrichment.get("search_queries", [])

    def _update_cooccurrence(self, content: str) -> None:
        """Feed a content string into the co-occurrence index."""
        if self._cooccurrence is not None:
            try:
                # CooccurrenceIndex uses update_from_memory()
                if hasattr(self._cooccurrence, "update_from_memory"):
                    self._cooccurrence.update_from_memory(content)
                elif hasattr(self._cooccurrence, "update"):
                    self._cooccurrence.update(content)
            except Exception:
                pass

    def _feed_cooccurrence_from_enrichment(self, original: str, enrichment: dict) -> None:
        """Feed enrichment metadata into co-occurrence index as virtual sentences."""
        if self._cooccurrence is None:
            return
        parts = []
        if enrichment.get("keywords"):
            parts.extend(enrichment["keywords"])
        if enrichment.get("tags"):
            parts.extend(enrichment["tags"])
        if parts:
            virtual = original + " " + " ".join(parts)
            try:
                if hasattr(self._cooccurrence, "update_from_memory"):
                    self._cooccurrence.update_from_memory(virtual)
                elif hasattr(self._cooccurrence, "update"):
                    self._cooccurrence.update(virtual)
            except Exception:
                pass

    def get_enrichment_count(self, reset: bool = False) -> int:
        """Return number of LLM enrichment calls made this session.

        Args:
            reset: If True, reset the counter to 0 after reading.
        """
        count = self._enrichment_count
        if reset:
            self._enrichment_count = 0
        return count

    def re_enrich(
        self,
        batch_size: int = 50,
        progress_fn=None,
        overwrite: bool = False,
    ) -> int:
        """Batch-enrich existing memories that lack enrichment data.

        Args:
            batch_size: Number of entries per save batch.
            progress_fn: Optional callable(current, total) for progress.
            overwrite: If True, re-enrich already-enriched entries.

        Returns:
            Number of entries enriched.
        """
        if self._enricher is None:
            return 0

        to_enrich = [
            e for e in self.memories
            if overwrite or not getattr(e, "enriched_summary", None)
        ]
        total = len(to_enrich)
        count = 0

        for i, entry in enumerate(to_enrich):
            if progress_fn:
                progress_fn(i + 1, total)
            enrichment = self._run_enrichment(entry.content)
            if enrichment:
                self._apply_enrichment_to_entry(entry, enrichment)
                self._feed_cooccurrence_from_enrichment(entry.content, enrichment)
                count += 1
            if count % batch_size == 0 and count > 0:
                self.save()

        if count > 0:
            self.search_engine.mark_dirty()
            self.save()

        return count

    # ── v4.7 Tiered Storage ────────────────────────────────────────────────────

    def get_hot_entries(self, top_n: int = 10) -> list:
        """Return the most-accessed hot-tier entries.

        Args:
            top_n: Number of entries to return.
        """
        if self._tier_manager is None:
            return sorted(self.memories, key=lambda e: e.created_at, reverse=True)[:top_n]
        try:
            return self._tier_manager.get_hot(self.memories, top_n=top_n)
        except Exception:
            return self.memories[:top_n]

    # ── v4.8 Graph Intelligence ────────────────────────────────────────────────

    def graph_search(
        self,
        subject=None,
        relation=None,
        obj=None,
    ) -> list:
        """Search relationship triples in the knowledge graph."""
        if self._graph is None:
            return []
        try:
            return self._graph.search(subject=subject, relation=relation, obj=obj)
        except Exception:
            return []

    def entity_path(self, source: str, target: str, max_hops: int = 3) -> list:
        """Find shortest entity path between two entities in the knowledge graph."""
        if self._graph is None:
            return []
        try:
            return self._graph.shortest_path(source, target, max_hops=max_hops)
        except Exception:
            return []

    def get_entity(self, canonical: str) -> dict:
        """Get full entity info from the knowledge graph."""
        if self._graph is None:
            return {}
        try:
            return self._graph.get_entity(canonical)
        except Exception:
            return {}

    def get_graph_stats(self) -> dict:
        """Return knowledge graph statistics."""
        if self._graph is None:
            return {"nodes": 0, "edges": 0, "density": 0.0, "enabled": False}
        try:
            return self._graph.stats()
        except Exception:
            return {"nodes": 0, "edges": 0, "density": 0.0, "enabled": True}

    def rebuild_graph(self) -> int:
        """Rebuild the knowledge graph from all current entries.

        Returns:
            Number of nodes in the rebuilt graph.
        """
        if self._graph is None:
            return 0
        try:
            from .entity_extractor import EntityExtractor
            extractor = EntityExtractor()
            self._graph.clear()
            for entry in self.memories:
                entities = extractor.extract(entry.content)
                for entity in entities:
                    self._graph.add_entity(entity)
                if len(entities) >= 2:
                    for i in range(len(entities) - 1):
                        self._graph.add_edge(
                            entities[i].canonical,
                            "co_occurs_with",
                            entities[i + 1].canonical,
                        )
            return self._graph.node_count()
        except Exception:
            return 0

    def rebuild_clusters(self) -> int:
        """Rebuild topic clusters from all current entries.

        Returns:
            Number of clusters built.
        """
        try:
            from .clustering import MemoryClusterer
            engine = MemoryClusterer()
            engine.build_clusters(self.memories)
            stats = engine.stats()
            return stats.get("cluster_count", 0)
        except Exception:
            return 0

    # ── v4.x Web & Structured Ingestion ───────────────────────────────────────

    def ingest_url(self, url: str, depth: int = 1, incremental: bool = True) -> dict:
        """Ingest content from a URL into the memory system."""
        try:
            from .ingest_web import WebCrawler
            from .ingest_manifest import IngestManifest
            manifest = IngestManifest(self.workspace)
            crawler = WebCrawler(manifest=manifest if incremental else None)
            chunks = crawler.crawl(url, depth=depth)
            ingested = 0
            skipped = 0
            for chunk in chunks:
                entry_id = self.ingest(
                    chunk["content"],
                    source=chunk.get("url", url),
                    category=chunk.get("category", "web"),
                )
                if entry_id:
                    ingested += 1
                else:
                    skipped += 1
            return {"ingested": ingested, "skipped_duplicates": skipped, "source_url": url}
        except Exception as e:
            return {"ingested": 0, "skipped_duplicates": 0, "source_url": url, "error": str(e)}

    def ingest_data_file(self, path: str, format: str = "auto", **kwargs) -> dict:
        """Ingest structured data from a file (CSV, JSON, SQLite)."""
        try:
            from .ingest_structured import StructuredIngester
            from .ingest_manifest import IngestManifest
            manifest = IngestManifest(self.workspace)
            ingester = StructuredIngester(manifest=manifest)
            chunks = ingester.ingest_file(path, format=format, **kwargs)
            count = 0
            for chunk in chunks:
                if self.ingest(chunk["content"], source=chunk.get("source", path)):
                    count += 1
            return {"ingested": count, "source": path, "format": format}
        except Exception as e:
            return {"ingested": 0, "source": path, "format": format, "error": str(e)}

    def ingest_sql(self, db_path: str, query: str) -> dict:
        """Ingest data from a SQLite query."""
        try:
            from .ingest_structured import StructuredIngester
            ingester = StructuredIngester()
            chunks = ingester.ingest_sql(db_path, query)
            count = sum(1 for chunk in chunks if self.ingest(chunk["content"], source=db_path))
            return {"ingested": count, "source": db_path}
        except Exception as e:
            return {"ingested": 0, "source": db_path, "error": str(e)}

    def delete_source(self, source_url: str) -> dict:
        """Remove all memories originating from a specific source URL."""
        before = len(self.memories)
        self.memories = [m for m in self.memories if m.source != source_url]
        self._hashes = {m.hash for m in self.memories}
        deleted = before - len(self.memories)
        if deleted:
            self.search_engine.mark_dirty()
            self.save()
        return {"deleted": deleted, "source_url": source_url}

    # ── v4.9 Health & Graph Stats ──────────────────────────────────────────────

    def get_health(self) -> dict:
        """Return health check status.

        Returns:
            Dict with keys: status ("ok" or "degraded"), checks (dict of bool).
        """
        checks = {}
        try:
            checks["workspace_accessible"] = os.path.isdir(self.workspace)
        except Exception:
            checks["workspace_accessible"] = False

        checks["memories_loaded"] = len(self.memories) >= 0

        try:
            checks["search_ok"] = self.search_engine is not None
        except Exception:
            checks["search_ok"] = False

        checks["graph_ok"] = self._graph is not None or not self._graph_intelligence

        status = "ok" if all(checks.values()) else "degraded"
        return {"status": status, "checks": checks}


# Backward compatibility alias
MemorySystem = MemorySystemV4