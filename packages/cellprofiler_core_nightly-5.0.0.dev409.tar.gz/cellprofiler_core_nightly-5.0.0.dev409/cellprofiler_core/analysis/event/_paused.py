class Paused:
    pass
