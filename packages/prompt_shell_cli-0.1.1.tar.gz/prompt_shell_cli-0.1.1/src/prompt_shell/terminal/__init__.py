"""Terminal monitoring subpackage."""
