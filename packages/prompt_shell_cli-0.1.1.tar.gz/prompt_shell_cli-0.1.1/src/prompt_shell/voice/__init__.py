"""Voice capture subpackage."""
