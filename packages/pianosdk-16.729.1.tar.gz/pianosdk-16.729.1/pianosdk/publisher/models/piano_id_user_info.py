from datetime import date, datetime
from pydantic.main import BaseModel
from typing import Optional


class PianoIdUserInfo(BaseModel):
    aud: Optional[str] = None
    email: Optional[str] = None
    uid: Optional[str] = None
    sub: Optional[str] = None


PianoIdUserInfo.model_rebuild()
