from datetime import date, datetime
from pydantic.main import BaseModel
from typing import Optional
from pianosdk.publisher.models.checkout_config_currency_model import CheckoutConfigCurrencyModel
from pianosdk.publisher.models.checkout_config_preview_authorization_details import CheckoutConfigPreviewAuthorizationDetails
from typing import List


class CheckoutConfigurationCheckoutFlowModel(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    checkout_flow_id: Optional[str] = None
    checkout_configuration_id: Optional[str] = None
    is_default: Optional[bool] = None
    auth_details: Optional['CheckoutConfigPreviewAuthorizationDetails'] = None
    available_currencies: Optional['List[CheckoutConfigCurrencyModel]'] = None


CheckoutConfigurationCheckoutFlowModel.model_rebuild()
