from datetime import date, datetime
from pydantic.main import BaseModel
from typing import Optional
from pianosdk.publisher.models.piano_id_auth_provider_info import PianoIdAuthProviderInfo
from pianosdk.publisher.models.piano_id_user_info import PianoIdUserInfo


class CheckoutConfigPreviewAuthorizationDetails(BaseModel):
    actor_id: Optional[str] = None
    jwt: Optional[str] = None
    error_message: Optional[str] = None
    auth_provider: Optional['PianoIdAuthProviderInfo'] = None
    user: Optional['PianoIdUserInfo'] = None


CheckoutConfigPreviewAuthorizationDetails.model_rebuild()
