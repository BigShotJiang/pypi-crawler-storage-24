import argparse
import os
import pickle
import rp
from backscatter_packaged_trigger import *

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--backscatter_buffer_size", type=int)
    parser.add_argument("--am_env_buffer_size", type=int)
    parser.add_argument("--file_name_backscatter", type=str)
    parser.add_argument("--file_name_am_env", type=str)
    parser.add_argument("--chunk_size", type=int)

    args = parser.parse_args()

    print("\n--- Received Parameters in transfer_backscatter_data.py ---")
    for k, v in vars(args).items():
        print(f"{k}: {v}")
    print("--------------------------------------------------------\n")

    initializeInterface()
    g_adc_axi_start, g_adc_axi_size = getMemoryRegion()
    print(f"DDR Start Address: {hex(g_adc_axi_start)}")
    print(f"DDR Size: {hex(g_adc_axi_size)}")

    setBufferSamples(
        channel_backscatter=rp.RP_T_CH_1,
        channel_am_env=rp.RP_T_CH_2,
        start_address_backscatter=g_adc_axi_start,
        start_address_am_env=int(g_adc_axi_start + args.backscatter_buffer_size * 2),
        buffer_size_am_env=args.am_env_buffer_size,
        buffer_size_backscatter=args.backscatter_buffer_size
    )

    enableDMA(
        channel_backscatter=rp.RP_T_CH_1,
        channel_am_env=rp.RP_T_CH_2,
        enable=True
    )

    file_path = "posPointers.pkl"
    if not os.path.exists(file_path):
        raise RuntimeError("Pointer file not found!")
    with open(file_path, "rb") as f:
        posChA, posChB = pickle.load(f)

    print(f"posChA: {posChA}, posChB: {posChB}")

    transferCapturedData(
        buffer_size_backscatter=args.backscatter_buffer_size,
        file_name_backscatter=args.file_name_backscatter,
        file_name_am_env=args.file_name_am_env,
        CHUNK=args.chunk_size,
        buffer_size_am_env=args.am_env_buffer_size,
        posChA=posChA,
        posChB=posChB
    )