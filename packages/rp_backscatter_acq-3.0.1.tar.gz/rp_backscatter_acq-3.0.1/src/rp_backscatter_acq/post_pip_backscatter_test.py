import rp_backscatter
import numpy as np
import matplotlib.pyplot as plt
from rp_backscatter import ssh_connection
from pathlib import Path
import rp
import backscatter_packaged_trigger
from backscatter_packaged_trigger import *


RP_IP = "169.254.188.142"
USERNAME = "root"
PASSWORD = "root"
REMOTE_DMA_BACKSCATTER_PATH = "/root/dma_backscatter.bin"
REMOTE_DMA_AM_ENV_PATH = "/root/dma_am_env.bin"
LOCAL_DMA_BACKSCATTER_PATH = "C:/Users/kings/OneDrive/Desktop/red_pitaya_backscatter/dma_backscatter.bin"
LOCAL_DMA_AM_ENV_PATH = "C:/Users/kings/OneDrive/Desktop/red_pitaya_backscatter/dma_am_env.bin"

pd_initialization = {'buffer_size': 114294784, 'decimation': 1, 'trig_level': 0.1, 
        'acquisition_time': 1, 'file_name': 'dma.bin', 'chunk_size': 20000000, 'source': 'rp.RP_TRIG_SRC_CHA_PE'}

n = 100000
ADC_bit_to_voltage_factor = 8192
channel_name = 'Channel 1'
PKL_FILE_DIRECTORY_PATH = Path(r"C:\Users\kings\OneDrive\Desktop\Research\INSITE2_gui\ssh_log.pkl")
ssh_key = rp_backscatter.ssh_connection.setup_ssh_connection(RP_IP, USERNAME, PASSWORD, PKL_FILE_DIRECTORY_PATH)
print(ssh_key)
decimation_backscatter = 1
decimation_am_env = 16

#run test to see if it works when you split it into two separate scripts
pd_acq = {'decimation_backscatter': 1, 'decimation_am_env': 16, 'file_name_backscatter': 'dma_backscatter.bin', 'file_name_am_env': 'dma_am_env.bin', 
        'trig_level': 0.1, 'chunk_size': 20000000, 'backscatter_buffer_size': int((1024*1024*218/2) / decimation_backscatter), 'am_env_buffer_size': int((1024*1024*218/2) / decimation_am_env)}

pd_transfer = {'file_name_backscatter': 'dma_backscatter.bin', 'file_name_am_env': 'dma_am_env.bin', 'chunk_size': 20000000, 'backscatter_buffer_size': int((1024*1024*218/2) / decimation_backscatter), 'am_env_buffer_size': int((1024*1024*218/2) / decimation_am_env)}
pd_acq = {'decimation_backscatter': 1, 'decimation_am_env': 16, 'trig_level': 0.1, 'chunk_size': 20000000, 'backscatter_buffer_size': int((1024*1024*218/2) / decimation_backscatter), 'am_env_buffer_size': int((1024*1024*218/2) / decimation_am_env)}
#rp_backscatter.ssh_connection.execute_remote_command_initialization(ssh_key, pd_initialization)
rp_backscatter.ssh_connection.run_SSH_rp_backscatter_pipeline(pd_acq, ssh_key)
backscatter_data, am_env_data = rp_backscatter.ssh_connection.run_SSH_transfer_pipeline(pd_transfer, REMOTE_DMA_BACKSCATTER_PATH, LOCAL_DMA_BACKSCATTER_PATH, REMOTE_DMA_AM_ENV_PATH, LOCAL_DMA_AM_ENV_PATH, ADC_bit_to_voltage_factor, ssh_key)

print("Backscatter Data:", backscatter_data)
print("AM Envelope Data:", am_env_data)

rp_backscatter.ssh_connection.plot_first_n_samples(backscatter_data, n, "Backscatter Channel")
rp_backscatter.ssh_connection.plot_first_n_samples(am_env_data, n, "AM Envelope Channel")

