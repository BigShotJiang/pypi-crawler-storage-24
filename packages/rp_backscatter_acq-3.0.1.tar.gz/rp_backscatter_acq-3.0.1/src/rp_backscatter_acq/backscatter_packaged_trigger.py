from matplotlib import lines
import numpy as np
import rp
import time
import argparse
import os
import pickle

def createBuffer(bufferSize):
    return np.zeros(int(bufferSize), dtype=np.int16)

def getMemoryRegion():
    memoryRegion = rp.rp_AcqAxiGetMemoryRegion()
    g_adc_axi_start = memoryRegion[1]
    g_adc_axi_size = memoryRegion[2] 
    return g_adc_axi_start, g_adc_axi_size 

def initializeInterface():
    rp.rp_Init()
    rp.rp_AcqReset()
    print("Acquisition Reset\n")

def setDecimationFactors(dec_backscatter, dec_am_env):
    rp.rp_AcqAxiSetDecimationFactorCh(rp.RP_CH_1, dec_backscatter)
    rp.rp_AcqAxiSetDecimationFactorCh(rp.RP_CH_2, dec_am_env)

def setTriggerDelay(channel_backscatter, channel_am_env, backscatter_buffer_size, am_env_buffer_size):
    rp.rp_AcqAxiSetTriggerDelay(channel_backscatter, int(backscatter_buffer_size))   
    rp.rp_AcqAxiSetTriggerDelay(channel_am_env, int(am_env_buffer_size))

def setBufferSamples(channel_backscatter, channel_am_env, start_address_backscatter, start_address_am_env,
                     buffer_size_backscatter, buffer_size_am_env):
    rp.rp_AcqAxiSetBufferSamples(channel_backscatter, start_address_backscatter, int(buffer_size_backscatter))  
    rp.rp_AcqAxiSetBufferSamples(channel_am_env, start_address_am_env, int(buffer_size_am_env))

def enableDMA(channel_backscatter, channel_am_env, enable):
    rp.rp_AcqAxiEnable(channel_backscatter, enable)
    rp.rp_AcqAxiEnable(channel_am_env, enable)

def rp_AcqSetTriggerLevelandSource(trigger_channel, trig_level, FPGA_trigger_source):
    rp.rp_AcqSetTriggerLevel(trigger_channel, trig_level)
    rp.rp_AcqSetTriggerSrc(FPGA_trigger_source)

def startAcquisition():
    rp.rp_AcqStart()

def stopAcquisition():
    rp.rp_AcqStop()
    print("Stop DMA acq\n")

def startDataAcquisition():
    startAcquisition()
    print("ACQ Started\n")
    while 1:
        state = rp.rp_AcqGetTriggerState()[1]
        if state == rp.RP_TRIG_STATE_TRIGGERED:
            print("Triggered")
            break

def checkFillState():
    fillState = False
    while not fillState:
        fillState = rp.rp_AcqAxiGetBufferFillState(rp.RP_CH_1)[1]
    print("DMA buffer full")
    return fillState

def getWritePointerAtTrig(channel_backscatter, channel_am_env):
    posChA = rp.rp_AcqAxiGetWritePointerAtTrig(channel_backscatter)[1]
    posChB = rp.rp_AcqAxiGetWritePointerAtTrig(channel_am_env)[1]
    return posChA, posChB

def transferCapturedData(buffer_size_backscatter, buffer_size_am_env, posChA, posChB, file_name_backscatter, file_name_am_env, CHUNK):
    start_time_backscatter_transfer = time.perf_counter()
    with open(file_name_backscatter, "wb") as f:
        for offset in range(0, int(buffer_size_backscatter), CHUNK):
            this_chunk = min(CHUNK, int(buffer_size_backscatter) - offset)
            buf = np.zeros(this_chunk, dtype=np.int16)
            # ---- Start timing DMA read ----
            t0 = time.perf_counter()
            rp.rp_AcqAxiGetDataRawNP(rp.RP_CH_1, posChA + offset, buf)
            t1 = time.perf_counter()
            dma_read_time = t1 - t0
            # ---- End timing DMA read ----
            f.write(buf.tobytes())
            print("Sent data to PC")
            print(f"Chunk {offset//CHUNK + 1} | {this_chunk} samples | DMA read time: {dma_read_time:.6f} s")
    end_time_backscatter_transfer = time.perf_counter()

    start_time_am_env_transfer = time.perf_counter()
    with open(file_name_am_env, "wb") as f:
        for offset in range(0, int(buffer_size_am_env), CHUNK):
            this_chunk_am_env = min(CHUNK, int(buffer_size_am_env) - offset)
            am_env_buff = np.zeros(this_chunk_am_env, dtype=np.int16)
            t0_am_env = time.perf_counter()
            rp.rp_AcqAxiGetDataRawNP(rp.RP_CH_2, posChB + offset, am_env_buff)
            t1_am_env = time.perf_counter()
            dma_read_time_am_env = t1_am_env - t0_am_env
            f.write(am_env_buff.tobytes())
            print("Sent AM Envelope data to PC")
            print(f"Chunk {offset//CHUNK + 1} | {this_chunk_am_env} samples | DMA read time: {dma_read_time_am_env:.6f} s")
    end_time_am_env_transfer = time.perf_counter()
    elapsed_backscatter_transfer = end_time_backscatter_transfer - start_time_backscatter_transfer
    elapsed_am_env_transfer = end_time_am_env_transfer - start_time_am_env_transfer 

    total_elapsed = elapsed_backscatter_transfer + elapsed_am_env_transfer
    print(f"DMA save complete.")
    print(f"Total time: {total_elapsed:.2f} seconds")
    print(f"File size: ~{(buffer_size_backscatter + buffer_size_am_env)*2/1024/1024:.1f} MB")
    print(f"Backscatter transfer time: {elapsed_backscatter_transfer:.2f} seconds")
    print(f"AM Envelope transfer time: {elapsed_am_env_transfer:.2f} seconds")
    print(f'Backscatter transfer speed: {buffer_size_backscatter*2/1e6/elapsed_backscatter_transfer:.1f} MB/s')
    print(f'AM Envelope transfer speed: {buffer_size_am_env*2/1e6/elapsed_am_env_transfer:.1f} MB/s')
    print(f"Total Transfer Speed: {(buffer_size_backscatter + buffer_size_am_env)*2/1e6/total_elapsed:.1f} MB/s")


def disableAxiChannel(channel_backscatter, channel_am_env):
    rp.rp_AcqAxiEnable(channel_backscatter, False)
    rp.rp_AcqAxiEnable(channel_am_env, False)

def releaseResources():
    print("\nReleasing resources\n")
    rp.rp_Release()

def runRedPitayaBackscatterPipeline(decimation_backscatter, decimation_am_env, backscatter_buffer_size, am_env_buffer_size, trig_lvl):
     
     initializeInterface()
     file_path = "/root/posPointers.txt"

     if os.path.exists(file_path):
        os.remove(file_path)
     g_adc_axi_start, g_adc_axi_size = getMemoryRegion()
     print(f"Reserved memory Start: {g_adc_axi_start:x} Size: {g_adc_axi_size:x}\n")
     setDecimationFactors(decimation_backscatter, decimation_am_env)
     setTriggerDelay(channel_backscatter=rp.RP_T_CH_1, channel_am_env=rp.RP_T_CH_2, backscatter_buffer_size=backscatter_buffer_size, am_env_buffer_size=am_env_buffer_size)
     setBufferSamples(channel_backscatter=rp.RP_T_CH_1, channel_am_env=rp.RP_T_CH_2, start_address_backscatter=g_adc_axi_start, start_address_am_env=int(g_adc_axi_start + int(backscatter_buffer_size)*2), buffer_size_am_env=am_env_buffer_size, buffer_size_backscatter=backscatter_buffer_size)
     enableDMA(channel_backscatter=rp.RP_T_CH_1, channel_am_env=rp.RP_T_CH_2, enable=True)
     rp_AcqSetTriggerLevelandSource(trigger_channel=rp.RP_T_CH_1, trig_level=trig_lvl, FPGA_trigger_source=rp.RP_TRIG_SRC_EXT_PE)
     startDataAcquisition()
     checkFillState()
     stopAcquisition()
     posChA, posChB = getWritePointerAtTrig(channel_backscatter=rp.RP_T_CH_1, channel_am_env=rp.RP_T_CH_2)
     print(f"posChA: {posChA}, posChB: {posChB}")
     file_path = "posPointers.pkl"

     with open(file_path, "wb") as f:
        print("saving...")
        pickle.dump((posChA, posChB), f)
        print("saved pos pointers to file")
     

def transferRedPitayaBackscatter(backscatter_buffer_size, am_env_buffer_size, file_name_backscatter, file_name_am_env, chunk_size, posChA, posChB):
    #positive channel A and positive channel B write pointers
    enableDMA(channel_backscatter=rp.RP_T_CH_1, channel_am_env=rp.RP_T_CH_2, enable=True)
    file_path = "posPointers.pkl"
    if os.path.exists(file_path):
        print("File exists, proceeding with data transfer") 
    with open(file_path, "rb") as f:
        posChA, posChB = pickle.load(f)
    print(f"posChA: {posChA}, posChB: {posChB}")
    transferCapturedData(backscatter_buffer_size, am_env_buffer_size, posChA, posChB, file_name_backscatter, file_name_am_env, chunk_size)
    

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--decimation_backscatter", type=int)
    parser.add_argument("--decimation_am_env", type=int)
    parser.add_argument("--trig_level", type=float)
    parser.add_argument("--backscatter_buffer_size", type=int)
    parser.add_argument("--am_env_buffer_size", type=int)
    args = parser.parse_args()

    print("\n--- Received Parameters in backscatter_packaged_trigger.py ---")
    for k, v in vars(args).items():
        print(f"{k}: {v}")
    print("--------------------------------------------------------\n")

    runRedPitayaBackscatterPipeline(
        decimation_backscatter=args.decimation_backscatter,
        decimation_am_env=args.decimation_am_env,
        trig_lvl=args.trig_level,
        backscatter_buffer_size=args.backscatter_buffer_size,
        am_env_buffer_size=args.am_env_buffer_size
    )

