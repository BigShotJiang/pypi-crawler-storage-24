import numpy as np
import matplotlib.pyplot as plt
from paramiko import SSHClient, AutoAddPolicy
from scp import SCPClient
import pickle
import time

def setup_ssh_connection(RP_IP, USERNAME, PASSWORD, pkl_file_path):
    ssh = SSHClient()
    ssh.set_missing_host_key_policy(AutoAddPolicy())
    ssh_str_time = "created_at_" + time.strftime("%Y%m%d-%H%M%S")
    with pkl_file_path.open("wb") as f:
        pickle.dump(ssh_str_time, f)
    print("[PC] Connecting to Red Pitaya...")
    ssh.connect(RP_IP, username=USERNAME, password=PASSWORD)
    print("[PC] Connected.\n")
    return ssh


def execute_remote_command_backscatter(ssh, pd_acquisition, detected_python="/usr/bin/python"):
    cmd = (
        f"bash -lc '{detected_python} -u /root/backscatter_packaged_trigger.py "
        f"--decimation_backscatter {pd_acquisition['decimation_backscatter']} "
        f"--decimation_am_env {pd_acquisition['decimation_am_env']} "
        f"--trig_level {pd_acquisition['trig_level']} "
        f"--backscatter_buffer_size {pd_acquisition['backscatter_buffer_size']} "
        f"--am_env_buffer_size {pd_acquisition['am_env_buffer_size']}'"
    )
    stdin, stdout, stderr = ssh.exec_command(cmd)
    print("[PC] Running DMA acquisition on RP...")
    for line in stdout:
        print("[RP]", line.strip())
    err = stderr.read().decode()

    print("Checking errors from STDERR...")
    if err:
        print("[RP STDERR]", err)
    exit_code = stdout.channel.recv_exit_status()
    print(f"[PC] Acquisition script exited with code {exit_code}\n")
    return exit_code

def execute_remote_command_transfer(ssh, pd_transfer, detected_python="/usr/bin/python"):
    cmd = (
        f"bash -lc '{detected_python} -u /root/transfer_backscatter_data.py "
        f"--file_name_backscatter {pd_transfer['file_name_backscatter']} "
        f"--file_name_am_env {pd_transfer['file_name_am_env']} "
        f"--chunk_size {pd_transfer['chunk_size']} "     
        f"--backscatter_buffer_size {pd_transfer['backscatter_buffer_size']} "
        f"--am_env_buffer_size {pd_transfer['am_env_buffer_size']}'"
    )
    stdin, stdout, stderr = ssh.exec_command(cmd)
    print("[PC] Running DMA acquisition on RP...")
    for line in stdout:
        print("[RP]", line.strip())
    err = stderr.read().decode()

    print("Checking errors from STDERR...")
    if err:
        print("[RP STDERR]", err)
    exit_code = stdout.channel.recv_exit_status()
    print(f"[PC] Acquisition script exited with code {exit_code}\n")
    return exit_code

def transfer_from_ssh_to_local(ssh, remote_dma_backscatter_path, local_dma_backscatter_path, 
                               remote_dma_am_env_path, local_dma_am_env_path):
    print("[PC] Transferring dma.bin from RP...")
    with SCPClient(ssh.get_transport()) as scp:
        scp.get(remote_dma_backscatter_path, local_dma_backscatter_path)
        scp.get(remote_dma_am_env_path, local_dma_am_env_path)
    print("[PC] File transferred.\n")

def load_samples(local_backscatter_dma_path, local_am_env_dma_path):
    backscatter_samples = np.fromfile(local_backscatter_dma_path, dtype=np.int16)
    am_env_samples = np.fromfile(local_am_env_dma_path, dtype=np.int16)
    return backscatter_samples, am_env_samples

def close_ssh_connection(ssh):
    ssh.close()
    print("[PC] SSH connection closed.")

def plot_first_n_samples(samples, n, channel_name):
    plt.figure(figsize=(10,5))
    plt.plot(samples[:n], label=channel_name)
    plt.grid(True)
    plt.title(f"Red Pitaya DMA Sample Data - First {n} Samples")
    plt.legend()
    plt.show()

def run_SSH_rp_backscatter_pipeline(pd, ssh):
    print("Running remote backscatter command")
    execute_remote_command_backscatter(ssh, pd)
    print("Finished running remote backscatter command")
    
def run_SSH_transfer_pipeline(pd_transfer, remote_dma_backscatter_path, local_dma_backscatter_path, 
                              remote_dma_am_env_path, local_dma_am_env_path, ADC_bit_to_voltage_factor, ssh):
    execute_remote_command_transfer(ssh, pd_transfer)
    transfer_from_ssh_to_local(ssh, remote_dma_backscatter_path, local_dma_backscatter_path,
                               remote_dma_am_env_path, local_dma_am_env_path)
    print("Finished file transfer")
    print("Loading samples")
    backscatter_samples, am_env_samples = load_samples(local_dma_backscatter_path, local_dma_am_env_path)
    backscatter_samples_adjusted = backscatter_samples / ADC_bit_to_voltage_factor  
    am_env_samples_adjusted = (am_env_samples * 20) / ADC_bit_to_voltage_factor                 
    print("Finished loading samples")
    return backscatter_samples_adjusted, am_env_samples_adjusted

    