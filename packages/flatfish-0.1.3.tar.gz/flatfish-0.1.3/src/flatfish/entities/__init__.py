"""Entity extraction module."""
