"""Summary generation module."""
