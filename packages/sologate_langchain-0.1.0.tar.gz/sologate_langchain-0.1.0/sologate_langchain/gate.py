"""
sologate_langchain.gate
Core gate logic — pauses agent execution until a human approves in the Sologate dashboard.
"""

from __future__ import annotations

import json
import time
from typing import Any

import requests
import websocket


class GateRejectedError(Exception):
    """Raised when a human reviewer rejects the gated action."""
    def __init__(self, unit_id: str):
        super().__init__(f"Gate rejected: unit {unit_id} was rejected by the approver.")
        self.unit_id = unit_id


class GateTimeoutError(Exception):
    """Raised when no decision is received within the timeout window."""
    def __init__(self, unit_id: str, timeout_ms: int):
        super().__init__(f"Gate timed out: no decision for unit {unit_id} after {timeout_ms}ms.")
        self.unit_id = unit_id


def gate(
    action: str,
    *,
    sologate_url: str,
    api_key: str,
    context: str = "",
    payload: dict[str, Any] | None = None,
    unit_id: str | None = None,
    timeout_ms: int = 48 * 60 * 60 * 1000,
) -> None:
    """
    Pause execution until a human approves or rejects in the Sologate dashboard.

    Args:
        action:        Short label for the action (e.g. "send_bulk_email")
        sologate_url:  Base URL of your Sologate backend
        api_key:       Your Sologate agent API key
        context:       Human-readable description shown in the dashboard
        payload:       Extra metadata attached to the approval request
        unit_id:       Existing unit ID to gate (optional — auto-created if omitted)
        timeout_ms:    How long to wait for a decision (default 48 h)

    Raises:
        GateRejectedError:  Human rejected the action.
        GateTimeoutError:   No decision received within timeout_ms.
    """
    base = sologate_url.rstrip("/")
    headers = {
        "Content-Type": "application/json",
        "x-atlas-agent-key": api_key,
    }

    # 1) Request approval
    body: dict[str, Any] = {
        "action": action,
        "note": context,
        "payload": {**(payload or {}), "action": action, "context": context},
    }
    if unit_id:
        body["unitId"] = unit_id

    resp = requests.post(
        f"{base}/api/agent/request-approval",
        headers=headers,
        json=body,
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()

    if not data.get("ok"):
        raise RuntimeError(f"sologate-gate: request-approval failed — {data.get('error')}")

    gated_unit_id = (
        (data.get("unit") or {}).get("id")
        or data.get("unitId")
        or unit_id
    )
    if not gated_unit_id:
        raise RuntimeError("sologate-gate: server did not return a unitId")

    # 2) Wait for decision — WebSocket push with polling fallback
    try:
        ws_base = base.replace("https://", "wss://").replace("http://", "ws://")
        decision = _wait_ws(
            f"{ws_base}/ws/agent/decisions?unitId={gated_unit_id}",
            gated_unit_id,
            api_key,
            timeout_ms,
        )
    except Exception:
        decision = _poll(base, headers, gated_unit_id, timeout_ms)

    if decision == "rejected":
        raise GateRejectedError(gated_unit_id)
    # "approved" — return normally, agent continues


def _wait_ws(ws_url: str, unit_id: str, api_key: str, timeout_ms: int) -> str:
    result: list[str] = []
    error: list[Exception] = []

    def on_message(ws, message):
        try:
            msg = json.loads(message)
            if msg.get("type") == "decision" and msg.get("unitId") == unit_id:
                result.append(msg["decision"])
                ws.close()
        except Exception:
            pass

    def on_error(ws, err):
        error.append(err)
        ws.close()

    ws = websocket.WebSocketApp(
        ws_url,
        header={"x-atlas-agent-key": api_key},
        on_message=on_message,
        on_error=on_error,
    )
    ws.run_forever(ping_interval=30, ping_timeout=10)

    if error:
        raise error[0]
    if not result:
        raise GateTimeoutError(unit_id, timeout_ms)
    return result[0]


def _poll(base: str, headers: dict, unit_id: str, timeout_ms: int) -> str:
    deadline = time.monotonic() + timeout_ms / 1000
    while time.monotonic() < deadline:
        try:
            r = requests.get(
                f"{base}/api/agent/approval/{unit_id}",
                headers=headers,
                timeout=10,
            ).json()
            if r.get("ok") and r.get("decision") in ("approved", "rejected"):
                return r["decision"]
        except Exception:
            pass
        time.sleep(2.5)
    raise GateTimeoutError(unit_id, timeout_ms)
