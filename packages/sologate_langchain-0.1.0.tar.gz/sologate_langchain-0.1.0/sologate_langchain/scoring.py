"""
sologate_langchain.scoring
Risk scoring for LangChain tool calls — mirrors the JS scoreToolCall() logic.
Returns score 0-100, tier, reason, and flags.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any


@dataclass
class RiskScore:
    score: int
    tier: str  # "LOW" | "MEDIUM" | "HIGH"
    reason: str
    flags: list[str] = field(default_factory=list)


_SHELL_TOOLS = {"execute_bash", "bash", "shell", "run_command", "exec", "system.run", "system_run", "terminal"}
_DELETE_TOOLS = {"delete_file", "remove_file", "unlink", "rmdir"}
_EMAIL_TOOLS = {"send_email", "send_message", "post_message", "send_slack", "send_sms"}
_HTTP_TOOLS = {"http_request", "api_call", "fetch_url", "make_request"}
_WRITE_TOOLS = {"write_file", "create_file", "overwrite_file", "append_file"}
_READ_TOOLS = {"read_file", "list_files", "list_directory", "search", "web_search", "grep", "find"}


def score_tool_call(tool_name: str, tool_input: Any) -> RiskScore:
    name = (tool_name or "").lower()
    input_str = json.dumps(tool_input or {}).lower()
    flags: list[str] = []

    # Irreversible file deletion
    if any(t in name for t in _DELETE_TOOLS):
        flags.append("irreversible file deletion")
        return RiskScore(92, "HIGH", "Irreversible file deletion", flags)

    # Shell / bash
    if any(t in name for t in _SHELL_TOOLS):
        if re.search(r"rm\s+(-rf?|-fr?)(\s|$)|rmdir\s", input_str):
            flags.append("rm -rf detected")
            return RiskScore(97, "HIGH", "Shell command contains rm -rf (irreversible bulk deletion)", flags)
        if re.search(r"drop\s+table|truncate\s+table|delete\s+from", input_str):
            flags.append("destructive SQL")
            return RiskScore(94, "HIGH", "Destructive database command (DROP / TRUNCATE)", flags)
        if re.search(r"curl[^|]+\|\s*(ba)?sh|wget[^|]+\|\s*(ba)?sh", input_str):
            flags.append("remote code execution")
            return RiskScore(96, "HIGH", "Remote code execution pattern (curl | sh)", flags)
        if re.search(r"sudo\s", input_str):
            flags.append("sudo — elevated privileges")
            return RiskScore(82, "HIGH", "Command runs with elevated privileges (sudo)", flags)
        if re.search(r"--force|-f\s|--no-verify", input_str):
            flags.append("--force flag bypasses safety checks")
            return RiskScore(76, "HIGH", "Command uses --force flag (bypasses safety checks)", flags)
        if re.search(r"git\s+(push|reset\s+--hard|branch\s+-[dD])", input_str):
            flags.append("destructive git operation")
            return RiskScore(68, "MEDIUM", "Destructive git operation", flags)
        return RiskScore(45, "MEDIUM", "Shell command execution", flags)

    # Outbound email / messaging
    if any(t in name for t in _EMAIL_TOOLS):
        recipient_count = input_str.count("@")
        if recipient_count > 5 or re.search(r"bulk|campaign|broadcast|mass", input_str):
            flags.append(f"bulk outbound — {recipient_count} recipients")
            return RiskScore(78, "HIGH", f"Bulk outbound message to {recipient_count} recipients", flags)
        if re.search(r"external|@(?!internal)", input_str):
            flags.append("external recipient")
            return RiskScore(55, "MEDIUM", "Outbound message to external recipient", flags)
        return RiskScore(30, "MEDIUM", "Outbound message", flags)

    # HTTP / API calls
    if any(t in name for t in _HTTP_TOOLS):
        if re.search(r'"method"\s*:\s*"delete"', input_str, re.I):
            flags.append("HTTP DELETE")
            return RiskScore(65, "MEDIUM", "HTTP DELETE request to external API", flags)
        if re.search(r'"method"\s*:\s*"(post|put|patch)"', input_str, re.I):
            return RiskScore(30, "MEDIUM", "HTTP write request", flags)
        return RiskScore(8, "LOW", "HTTP read request", flags)

    # File writes
    if any(t in name for t in _WRITE_TOOLS):
        if re.search(r"\.env|credentials|secrets?|password|private.key", input_str):
            flags.append("writing to sensitive credential file")
            return RiskScore(85, "HIGH", "Writing to sensitive credential / config file", flags)
        return RiskScore(28, "MEDIUM", "File write", flags)

    # Package installs
    if re.search(r"npm\s+install|pip\s+install|brew\s+install", input_str):
        return RiskScore(40, "MEDIUM", "Installing packages — verify source before execution", flags)

    # Read-only
    if any(t in name for t in _READ_TOOLS):
        return RiskScore(5, "LOW", "Read-only operation", flags)

    return RiskScore(20, "LOW", "Tool execution", flags)
