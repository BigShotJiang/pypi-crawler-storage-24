"""
sologate-langchain
Human-in-the-loop approval gates for LangChain agents.

Quick start::

    from sologate_langchain import SologateCallbackHandler

    handler = SologateCallbackHandler(
        sologate_url="https://www.sologate.app",
        api_key="at_...",
    )
    agent_executor = AgentExecutor(agent=agent, tools=tools, callbacks=[handler])
"""

from .callback import SologateCallbackHandler
from .gate import GateRejectedError, GateTimeoutError, gate
from .scoring import RiskScore, score_tool_call

__all__ = [
    "SologateCallbackHandler",
    "gate",
    "GateRejectedError",
    "GateTimeoutError",
    "score_tool_call",
    "RiskScore",
]
__version__ = "0.1.0"
