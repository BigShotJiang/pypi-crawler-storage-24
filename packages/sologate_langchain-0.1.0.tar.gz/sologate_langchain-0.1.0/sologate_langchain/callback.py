"""
sologate_langchain.callback
LangChain callback handler — intercepts tool calls, scores them, and gates
high-risk actions through the Sologate Decision Center.
"""

from __future__ import annotations

import json
import os
from typing import Any

from .gate import GateRejectedError, GateTimeoutError, gate
from .scoring import score_tool_call

try:
    from langchain_core.callbacks.base import BaseCallbackHandler
    from langchain_core.outputs import LLMResult
except ImportError:  # graceful degradation without langchain installed
    BaseCallbackHandler = object  # type: ignore
    LLMResult = None  # type: ignore


class SologateCallbackHandler(BaseCallbackHandler):
    """
    Drop-in LangChain callback that gates high-risk tool calls through Sologate.

    Usage::

        from sologate_langchain import SologateCallbackHandler

        handler = SologateCallbackHandler(
            sologate_url="https://www.sologate.app",
            api_key="at_...",
            threshold=60,          # risk score 0-100 above which gate fires
        )

        agent = create_react_agent(llm, tools, prompt)
        agent_executor = AgentExecutor(agent=agent, tools=tools, callbacks=[handler])
    """

    raise_on_rejected: bool = True

    def __init__(
        self,
        sologate_url: str | None = None,
        api_key: str | None = None,
        threshold: int = 60,
        raise_on_rejected: bool = True,
    ):
        self.sologate_url = sologate_url or os.environ.get("SOLOGATE_URL", "")
        self.api_key = api_key or os.environ.get("SOLOGATE_KEY", "")
        self.threshold = threshold
        self.raise_on_rejected = raise_on_rejected
        self._blocked_tools: set[str] = set()

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        tool_name = serialized.get("name", "unknown_tool")

        # Parse input — LangChain passes it as a string sometimes
        try:
            tool_input = json.loads(input_str) if isinstance(input_str, str) else input_str
        except Exception:
            tool_input = {"input": input_str}

        risk = score_tool_call(tool_name, tool_input)

        if not self.sologate_url or not self.api_key:
            print(f"[sologate] ⚠  SOLOGATE_URL or SOLOGATE_KEY not set — running without gates")
            return

        if risk.score < self.threshold:
            print(f"[sologate] ✓ {tool_name} — score {risk.score} AUTO-APPROVED")
            return

        flags_str = "  ".join(f"• {f}" for f in risk.flags) if risk.flags else ""
        print(f"\n[sologate] 🔴 Gating: {tool_name} (score {risk.score}/100 — {risk.tier})")
        print(f"[sologate] Reason: {risk.reason}")
        if flags_str:
            print(f"[sologate] Flags:  {flags_str}")
        print(f"[sologate] Waiting for human decision at {self.sologate_url}/decisions...\n")

        context_parts = [
            risk.reason,
            f"\nFlags:\n{chr(10).join(f'• {f}' for f in risk.flags)}" if risk.flags else "",
            f"\nTool: {tool_name}",
            f"Risk score: {risk.score}/100 ({risk.tier})",
            f"\nInput:\n{json.dumps(tool_input, indent=2)[:800]}",
        ]

        try:
            gate(
                tool_name,
                sologate_url=self.sologate_url,
                api_key=self.api_key,
                context="\n".join(p for p in context_parts if p),
                payload={
                    "tool": tool_name,
                    "input": tool_input,
                    "riskScore": risk.score,
                    "riskTier": risk.tier,
                    "reason": risk.reason,
                    "flags": risk.flags,
                },
            )
            print(f"[sologate] ✅ Approved — resuming {tool_name}")

        except GateRejectedError:
            print(f"[sologate] ❌ Rejected — blocking {tool_name}")
            self._blocked_tools.add(str(run_id))
            if self.raise_on_rejected:
                raise

        except GateTimeoutError:
            print(f"[sologate] ⏱  Timeout — blocking {tool_name} as fail-safe")
            self._blocked_tools.add(str(run_id))
            if self.raise_on_rejected:
                raise
