# Tencent Cloud TKE MCP Server

A Model Context Protocol (MCP) server for Tencent Kubernetes Engine (TKE), providing standardized interfaces for TKE cluster management.

## Features
- **Cluster Lifecycle Management**: Create, delete, modify attributes, and query clusters
- **Dynamic Tool Loading**: Auto-generate MCP tools from McpAPI YAML definitions
- **Mock Mode**: Simulated responses when Tencent Cloud credentials are unavailable
- **Parameter Validation**: Strict input validation and error handling

## Tools

### Static Tools
| Tool Name | Description |
|---|---|
| `CreateCluster` | Create a TKE cluster |

### Dynamic Tools (Auto-generated from McpAPI files)

#### API Version 2018-05-25
| Tool Name | Description |
|---|---|
| `DescribeClusters` | List clusters |
| `DescribeClusterStatus` | List cluster statuses |
| `DescribeClusterKubeconfig` | Get cluster kubeconfig |
| `DeleteCluster` | Delete a cluster |
| `ModifyClusterAttribute` | Modify cluster attributes |
| `CreateClusterEndpoint` | Create cluster access endpoint |
| `DeleteClusterEndpoint` | Delete cluster access endpoint |
| `DescribeClusterEndpoints` | Query cluster access endpoints |
| `DescribeClusterEndpointStatus` | Query cluster endpoint status |
| `EnableClusterDeletionProtection` | Enable cluster deletion protection |
| `DisableClusterDeletionProtection` | Disable cluster deletion protection |

#### API Version 2022-05-01
| Tool Name | Description |
|---|---|
| `DescribeNodePools` | List node pools |

## Quick Start

### 1. Obtain Tencent Cloud Credentials
- Log in to the [Tencent Cloud Console](https://console.cloud.tencent.com/), navigate to **CAM** > **API Keys** to get your `SecretId` and `SecretKey`

### 2. Set Environment Variables
```bash
export TENCENTCLOUD_SECRET_ID=your_secret_id
export TENCENTCLOUD_SECRET_KEY=your_secret_key
```

### 3. Install
```bash
# Install from PyPI
pip install mcp-server-tke

# Or install from source
pip install .
```

### 4. Start the Server
```bash
# Run directly
uv run mcp-server-tke

# Or via Python module
python -m mcp_server_tke
```

### 5. Claude Desktop Configuration
Edit `claude_desktop_config.json` (macOS default: `~/Library/Application Support/Claude/claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "tencent-tke": {
      "command": "uv",
      "args": ["run", "mcp-server-tke"],
      "env": {
        "TENCENTCLOUD_SECRET_ID": "your_secret_id",
        "TENCENTCLOUD_SECRET_KEY": "your_secret_key"
      }
    }
  }
}
```

## Development

### Install Dev Tools
```bash
npm install -g --registry=https://mirrors.tencent.com/npm @tencent/codebuddy-cli
```

### Project Structure
```
tke-mcp/
├── src/mcp_server_tke/          # Main source directory
│   ├── __init__.py             # Module entry point
│   ├── server.py               # MCP server main logic
│   ├── tool_tke.py             # TKE static tool implementation
│   ├── client.py               # Tencent Cloud client wrapper
│   ├── mcpapi_loader.py        # McpAPI YAML file loader
│   ├── dynamic_tool_handler.py # Dynamic tool handler
│   └── mcpapi/                 # Dynamic tool definitions
├── openapi/                    # OpenAPI source files from Cloud API
├── tests/                      # Unit tests
├── docs/                       # Documentation
└── pyproject.toml              # Python project configuration
```

### Adding New Tools

There are two ways to add new tools:

#### 1. Static Tools (Implemented in code)
1. Add a new function in `tool_tke.py`
2. Register the tool in `handle_list_tools()` in `server.py`
3. Add call routing in `handle_call_tool()`

#### 2. Dynamic Tools (Via YAML files)
Use the CodeBuddy CLI `/yunapi` command to convert a Cloud API definition to an MCP tool:
```
/yunapi openapi/tke_2018-05-25_DescribeClusterKubeconfig.json
```

### Testing
```bash
# Run all tests
python -m unittest discover tests/

# Run specific tests
python -m unittest tests/test_tool_tke.py
python -m unittest tests/test_mcp_integration.py
```

### Build
```bash
# Build with hatch
hatch build
```

## License
MIT License - see the LICENSE file for details.
