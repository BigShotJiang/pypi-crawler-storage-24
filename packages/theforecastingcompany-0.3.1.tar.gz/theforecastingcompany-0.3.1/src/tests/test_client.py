import numpy as np
import pandas as pd
import pytest

from theforecastingcompany import TFCClient
from theforecastingcompany.utils import TFCModels


def generate_fake_timeseries(start_date, end_date, seed=None):
    """
    Generate a fake daily time series between start_date and end_date.

    Parameters:
        start_date (str): Start date in 'YYYY-MM-DD' format.
        end_date (str): End date in 'YYYY-MM-DD' format.
        seed (int, optional): Random seed for reproducibility.

    Returns:
        pd.DataFrame: DataFrame with columns 'date' and 'value'.
    """
    if seed is not None:
        np.random.seed(seed)

    dates = pd.date_range(start=start_date, end=end_date, freq="D")
    values = np.random.normal(loc=0, scale=1, size=len(dates)).cumsum()

    df = pd.DataFrame({"ds": dates, "target": values})
    return df


@pytest.fixture
def train_df(request):
    same_end_date: bool = request.param
    df1 = generate_fake_timeseries("2023-11-01", "2023-12-19").assign(unique_id="series_1", static1="A", static2="X")
    df2 = generate_fake_timeseries("2023-12-02", "2023-12-19" if same_end_date else "2023-12-20").assign(
        unique_id="series_2", static1="B", static2="X"
    )
    return pd.concat([df1, df2], ignore_index=True)


@pytest.fixture
def future_df():
    df1 = generate_fake_timeseries("2024-01-01", "2024-01-12").assign(unique_id="series_1", static1="A", static2="X")
    df2 = generate_fake_timeseries("2024-01-06", "2024-01-17").assign(unique_id="series_2", static1="B", static2="X")
    return pd.concat([df1, df2], ignore_index=True)


@pytest.fixture
def future_df_new_products(future_df):
    return future_df.assign(unique_id=lambda df: df["unique_id"].map({"series_1": "series_3", "series_2": "series_4"}))


@pytest.mark.parametrize("train_df", [True], indirect=True)
def test_forecast_wrong_future_df(train_df, future_df):
    # This generates error cause there are gaps in the tie series being forecasted.
    client = TFCClient(api_key="test")
    with pytest.raises(ValueError, match="Missing unique_id x ds combinations in future_df"):
        client.forecast(
            train_df,
            model=TFCModels.TFCGlobal,
            horizon=12,
            freq="D",
            static_variables=["unique_id", "static1", "static2"],
            add_holidays=True,
            add_events=True,
            country_isocode="US",
            future_df=future_df,
        )

    with pytest.raises(ValueError, match="Missing unique_id x ds combinations in future_df"):
        # Same test as above, but without static_variables.
        client.forecast(
            train_df,
            model=TFCModels.TFCGlobal,
            horizon=12,
            freq="D",
            add_holidays=True,
            add_events=True,
            country_isocode="US",
            future_df=future_df,
        )


@pytest.mark.parametrize("train_df", [True], indirect=True)
def test_forecast_new_products(train_df, future_df_new_products):
    client = TFCClient(api_key="test")
    with pytest.raises(ValueError, match="Some items in future_df are not in train_df"):
        client.forecast(
            train_df,
            model=TFCModels.TabPFN_TS,
            horizon=12,
            freq="D",
            static_variables=["unique_id", "static1", "static2"],
            add_holidays=True,
            add_events=True,
            country_isocode="US",
            future_df=future_df_new_products,
        )


class TestStringCovariates:
    """Tests for string covariate validation.

    Models that accept future_variables but NOT string covariates:
    - Moirai, MoiraiMoe, Moirai2, Chronos_2, Chronos_2_multivariate

    Models that accept string covariates:
    - TabPFN_TS, TFCGlobal
    """

    @pytest.fixture
    def train_df_with_string_covariate(self):
        """Training data with a string future variable."""
        return pd.DataFrame(
            {
                "unique_id": ["A"] * 10,
                "ds": pd.date_range("2023-01-01", periods=10, freq="D"),
                "target": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0],
                "category": ["red", "blue", "red", "blue", "red", "blue", "red", "blue", "red", "blue"],
            }
        )

    @pytest.fixture
    def future_df_with_string_covariate(self):
        """Future data with a string future variable."""
        return pd.DataFrame(
            {
                "unique_id": ["A"] * 5,
                "ds": pd.date_range("2023-01-11", periods=5, freq="D"),
                "category": ["green", "red", "blue", "green", "red"],
            }
        )

    @pytest.mark.parametrize(
        "model",
        [
            TFCModels.Moirai,
            TFCModels.MoiraiMoe,
            TFCModels.Moirai2,
            TFCModels.Chronos_2,
            TFCModels.Chronos_2_multivariate,
        ],
    )
    def test_string_future_variables_rejected(
        self, model, train_df_with_string_covariate, future_df_with_string_covariate
    ):
        """Test that models other than tabpfn-ts and tfc-global reject string future_variables."""
        client = TFCClient(api_key="test")

        with pytest.raises(ValueError, match="does not support string covariates"):
            client.forecast(
                train_df_with_string_covariate,
                model=model,
                horizon=5,
                freq="D",
                future_df=future_df_with_string_covariate,
                future_variables=["category"],
            )

    @pytest.mark.parametrize(
        "model",
        [
            TFCModels.TabPFN_TS,
            TFCModels.TFCGlobal,
        ],
    )
    def test_string_future_variables_accepted(
        self, model, train_df_with_string_covariate, future_df_with_string_covariate
    ):
        """Test that tabpfn-ts and tfc-global accept string future_variables.

        Note: This test only validates that the string covariate check passes.
        It may fail later due to API issues (no real API key), but the point is
        that it does NOT fail with the 'does not support string future_variables' error.
        """
        client = TFCClient(api_key="test")

        # Should NOT raise "does not support string future_variables"
        # May raise other errors (API, validation, etc.) but not the string covariate error
        with pytest.raises(Exception) as exc_info:
            client.forecast(
                train_df_with_string_covariate,
                model=model,
                horizon=5,
                freq="D",
                future_df=future_df_with_string_covariate,
                future_variables=["category"],
            )
        # Verify it's NOT the string covariate error
        assert "does not support string covariates" not in str(exc_info.value)

    def test_error_message_includes_column_names(self, train_df_with_string_covariate, future_df_with_string_covariate):
        """Test that the error message includes the column names that contain strings."""
        client = TFCClient(api_key="test")

        with pytest.raises(ValueError, match=r"category") as exc_info:
            client.forecast(
                train_df_with_string_covariate,
                model=TFCModels.Moirai,
                horizon=5,
                freq="D",
                future_df=future_df_with_string_covariate,
                future_variables=["category"],
            )
        # Verify the error message mentions the column
        assert "category" in str(exc_info.value)
        assert "tabpfn-ts" in str(exc_info.value)
        assert "tfc-global" in str(exc_info.value)
