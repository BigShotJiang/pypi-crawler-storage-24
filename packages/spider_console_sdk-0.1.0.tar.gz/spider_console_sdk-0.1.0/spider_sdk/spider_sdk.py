# ============================================================
# Spider SDK
# ============================================================
# 作用：统一把爬虫运行状态/指标/错误 上报到管理平台（HTTP）
#
# 核心功能：
# - 任务型爬虫（job）：start/heartbeat/success/fail 生命周期上报
# - 服务型爬虫（service）：service_up/service_heartbeat/service_down 状态上报
# - 错误事件：report_error 上报过程错误（支持限量+截断）
# - 装饰器模式：@report_job / @report_service 一键集成
# - 上下文管理器：with SpiderReportContext(...) 自动上报
#
# 可靠性特性：
# - 上报失败不影响爬虫主流程（短超时、有限重试、吞异常）
# - 幂等设计：idempotency_key 防重复创建 run
# - 可追踪：run_id 贯穿整个生命周期
# - 心跳保护：最小间隔限制，避免频繁上报
# - 错误限量：单次 run 最多 error_event_max 条错误事件
# - 详情截断：error_detail 超长自动截断，防止 payload 过大
#
# 配置来源（优先级从低到高）：
# - spider_sdk.ini 项目配置文件
# - 装饰器/构造器参数
# - 运行时显式覆盖
#
# 技术特点：
# - 无外部依赖：纯 urllib 实现，无需 requests
# - 线程安全：心跳线程独立运行
# ============================================================

from __future__ import annotations

import json
import logging
import inspect
import os
import socket
import sys
import threading
import time
import traceback
import uuid
import warnings
import configparser
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from functools import wraps
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple
from urllib import request as urllib_request
from urllib.error import URLError, HTTPError


# ---------------------------
# Defaults / Config keys
# ---------------------------

ENV_PLATFORM_URL = "SPIDER_PLATFORM_URL"         # (平台地址)
ENV_PLATFORM_KEY = "SPIDER_PLATFORM_KEY"          # (平台提供的上报密钥)
ENV_TOKEN = "SPIDER_TOKEN"                        # (兼容字段：历史鉴权token；建议改用 SPIDER_PLATFORM_KEY)
ENV_SPIDER_NAME = "SPIDER_NAME"                   # (爬虫名称)
ENV_SPIDER_TYPE = "SPIDER_TYPE"                   # (爬虫类型)
ENV_SPIDER_MODE = "SPIDER_MODE"                   # (运行模式job/service)
ENV_SPIDER_ENV = "SPIDER_ENV"                     # (环境dev/staging/prod)
ENV_SPIDER_TAGS = "SPIDER_TAGS"                   # (标签逗号分隔)
ENV_SPIDER_VERSION = "SPIDER_VERSION"             # (爬虫版本)
ENV_SPIDER_DATA_SOURCE = "SPIDER_DATA_SOURCE"     # (数据来源：站点 URL/名称)
ENV_SPIDER_SOURCE_CATEGORY = "SPIDER_SOURCE_CATEGORY"  # (来源类别：社交媒体/新闻网站等)
ENV_SPIDER_HOST = "SPIDER_HOST"                   # (主机名)
ENV_TIMEOUT_SEC = "SPIDER_TIMEOUT_SEC"            # (上报超时秒)
ENV_RETRY_MAX = "SPIDER_RETRY_MAX"                # (最大重试次数)
ENV_HEARTBEAT_MIN_SEC = "SPIDER_HEARTBEAT_MIN_SEC"  # (最小心跳间隔秒)
ENV_ERROR_DETAIL_MAX = "SPIDER_ERROR_DETAIL_MAX"  # (错误详情最大长度)
ENV_ERROR_EVENT_MAX = "SPIDER_ERROR_EVENT_MAX"    # (单次Run最多错误事件条数)

DEFAULT_TIMEOUT_SEC = 2.0                         # (默认超时秒)
DEFAULT_RETRY_MAX = 2                             # (默认重试次数)
DEFAULT_HEARTBEAT_MIN_SEC = 10.0                  # (默认最小心跳间隔)
DEFAULT_ERROR_DETAIL_MAX = 8192                   # (默认错误详情截断长度)
DEFAULT_ERROR_EVENT_MAX = 200                     # (默认单次run错误事件上限)

SDK_VERSION = "A-0.1.0"                           # (SDK版本)

# Platform endpoints (可按你平台实际路径调整)
DEFAULT_ENDPOINT_RUN_START = "/api/v1/report/run/start"
DEFAULT_ENDPOINT_RUN_HEARTBEAT = "/api/v1/report/run/heartbeat"
DEFAULT_ENDPOINT_RUN_END = "/api/v1/report/run/end"
DEFAULT_ENDPOINT_ERROR = "/api/v1/report/error"
DEFAULT_INI_FILENAME = "spider_sdk.ini"
DEFAULT_INI_SECTION = "spider_sdk"

DEPRECATION_LINK = "请迁移到 report_job/report_job_from_env/report_service。"


# ---------------------------
# Logging
# ---------------------------

_logger = logging.getLogger("spider_sdk")
if not _logger.handlers:
    handler = logging.StreamHandler(sys.stdout)
    fmt = logging.Formatter("[spider_sdk] %(levelname)s %(message)s")
    handler.setFormatter(fmt)
    _logger.addHandler(handler)
_logger.setLevel(logging.INFO)


# ---------------------------
# Utilities
# ---------------------------

BJ_TZ = timezone(timedelta(hours=8))


def _bj_now_iso() -> str:
    """(事件时间ISO8601，北京时间+08:00)"""
    return datetime.now(BJ_TZ).replace(microsecond=0).isoformat()


def _safe_int(v: Any, default: int) -> int:
    try:
        return int(v)
    except Exception:
        return default


def _safe_float(v: Any, default: float) -> float:
    try:
        return float(v)
    except Exception:
        return default


def _safe_bool(v: Any, default: bool) -> bool:
    if isinstance(v, bool):
        return v
    if isinstance(v, str):
        value = v.strip().lower()
        if value in {"1", "true", "yes", "on"}:
            return True
        if value in {"0", "false", "no", "off"}:
            return False
    return default


def find_project_ini(filename: str = DEFAULT_INI_FILENAME) -> Optional[Path]:
    """从当前工作目录向上查找 spider_sdk.ini。"""
    cwd = Path.cwd().resolve()
    for base in (cwd, *cwd.parents):
        candidate = base / filename
        if candidate.is_file():
            return candidate
    return None


def load_ini_config(path: Optional[Path], section: str = DEFAULT_INI_SECTION) -> Dict[str, Any]:
    """读取 INI 配置，找不到文件或节时返回空字典。"""
    if path is None:
        return {}
    parser = configparser.ConfigParser()
    parser.read(path, encoding="utf-8")
    if not parser.has_section(section):
        return {}
    raw = dict(parser.items(section))
    cfg: Dict[str, Any] = {}
    for k, v in raw.items():
        cfg[k.strip()] = v.strip() if isinstance(v, str) else v
    return cfg


def _get_host() -> str:
    """(主机名)"""
    try:
        return socket.gethostname()
    except Exception:
        return "unknown-host"


def _get_ip() -> Optional[str]:
    """(IP 可选)"""
    try:
        host = _get_host()
        return socket.gethostbyname(host)
    except Exception:
        return None


def _get_pid() -> int:
    """(进程ID)"""
    try:
        return os.getpid()
    except Exception:
        return -1


def _truncate(s: Optional[str], max_len: int) -> Optional[str]:
    """(截断保护)"""
    if s is None:
        return None
    if len(s) <= max_len:
        return s
    return s[: max_len - 3] + "..."


def _normalize_tags(tags: Any) -> List[str]:
    """(标签列表)"""
    if tags is None:
        return []
    if isinstance(tags, list):
        return [str(x).strip() for x in tags if str(x).strip()]
    if isinstance(tags, str):
        parts = [p.strip() for p in tags.split(",")]
        return [p for p in parts if p]
    return []


def _gen_idempotency_key(host: str, pid: int, start_ts: int) -> str:
    """(幂等键：防重复start)"""
    return f"{host}-{pid}-{start_ts}"


def _json_dumps(obj: Any) -> str:
    """Compact JSON"""
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))


# ---------------------------
# HTTP Client (urllib-based, no external deps)
# ---------------------------

@dataclass
class HttpClientConfig:
    platform_url: str                          # (平台地址)
    platform_key: str                          # (平台密钥)
    timeout_sec: float = DEFAULT_TIMEOUT_SEC   # (超时秒)
    max_retries: int = DEFAULT_RETRY_MAX       # (最大重试次数)
    backoff_schedule: Tuple[float, ...] = (0.2, 0.5, 1.0)  # (退避时间序列)


class HttpClient:
    def __init__(self, cfg: HttpClientConfig) -> None:
        self.cfg = cfg

    def post_json(self, path: str, payload: Dict[str, Any]) -> Tuple[bool, Optional[Dict[str, Any]]]:
        """
        发送 JSON 到平台。任何异常都吞掉（只返回 success=False）。
        返回：(是否成功, 解析后的json或None)
        """
        url = self._join_url(self.cfg.platform_url, path)
        body = _json_dumps(payload).encode("utf-8")

        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "X-Spider-Key": self.cfg.platform_key,
            "User-Agent": f"spider-sdk/{SDK_VERSION}",
        }

        # 重试：最多 max_retries 次（含第一次）
        attempts = max(1, int(self.cfg.max_retries) + 1)
        for i in range(attempts):
            try:
                req = urllib_request.Request(url, data=body, headers=headers, method="POST")
                with urllib_request.urlopen(req, timeout=self.cfg.timeout_sec) as resp:
                    raw = resp.read()
                    if not raw:
                        return True, None
                    try:
                        return True, json.loads(raw.decode("utf-8"))
                    except Exception:
                        # 平台可能不返回 JSON，也算成功
                        return True, None
            except HTTPError as e:
                # 4xx/5xx：部分场景重试无意义，但这里保持简单策略：5xx重试，4xx不重试
                status = getattr(e, "code", None)
                if status and 400 <= status < 500:
                    self._warn(f"POST {path} failed HTTP {status} (no retry): {self._safe_err(e)}")
                    return False, None
                self._warn(f"POST {path} failed HTTP {status}, attempt {i+1}/{attempts}: {self._safe_err(e)}")
            except URLError as e:
                self._warn(f"POST {path} failed URLError, attempt {i+1}/{attempts}: {self._safe_err(e)}")
            except Exception as e:
                self._warn(f"POST {path} failed Exception, attempt {i+1}/{attempts}: {self._safe_err(e)}")

            # backoff
            if i < attempts - 1:
                delay = self.cfg.backoff_schedule[min(i, len(self.cfg.backoff_schedule) - 1)]
                time.sleep(delay)

        return False, None

    @staticmethod
    def _join_url(base: str, path: str) -> str:
        base = base.rstrip("/")
        if not path.startswith("/"):
            path = "/" + path
        return base + path

    @staticmethod
    def _safe_err(e: Exception) -> str:
        msg = str(e)
        return msg if msg else e.__class__.__name__

    @staticmethod
    def _warn(msg: str) -> None:
        # 不要抛异常，最多打日志
        _logger.warning(msg)


# ---------------------------
# Data structures (internal)
# ---------------------------

@dataclass
class SpiderIdentity:
    spider_name: str                      # (爬虫名称)
    spider_type: str                      # (爬虫类型)
    mode: str                             # (运行模式 job/service)
    env: str                              # (环境 dev/staging/prod)
    tags: List[str] = field(default_factory=list)  # (标签列表)
    version: Optional[str] = None         # (爬虫版本可选)
    data_source: Optional[str] = None     # (数据来源：站点URL/名称，可选)
    source_category: Optional[str] = None # (来源类别：社交媒体/新闻网站等，可选)
    extra: Dict[str, Any] = field(default_factory=dict)  # (额外信息JSON)

@dataclass
class RuntimeInfo:
    host: str                             # (主机名)
    ip: Optional[str]                     # (IP可选)
    pid: int                              # (进程ID)
    sdk_version: str = SDK_VERSION        # (SDK版本)


# ---------------------------
# Main Reporter
# ---------------------------

class SpiderReporter:
    """
    SpiderReporter：对外唯一入口
    - mode=job：start/heartbeat/success/fail/report_error
    - mode=service：service_up/service_heartbeat/service_down/report_error
    """

    def __init__(
        self,
        platform_url: Optional[str] = None,   # (平台地址)
        platform_key: Optional[str] = None,   # (平台提供的上报密钥)
        token: Optional[str] = None,          # (兼容参数：历史 token)
        spider_name: Optional[str] = None,    # (爬虫名称)
        spider_type: Optional[str] = None,    # (爬虫类型)
        mode: Optional[str] = None,           # (运行模式 job/service)
        env: Optional[str] = None,            # (环境 dev/staging/prod)
        tags: Any = None,                     # (标签列表或逗号字符串)
        version: Optional[str] = None,        # (爬虫版本可选)
        data_source: Optional[str] = None,    # (数据来源：站点 URL/名称)
        source_category: Optional[str] = None,  # (来源类别：社交媒体/新闻网站等)
        extra: Optional[Dict[str, Any]] = None,  # (额外信息JSON)
        # endpoint overrides (可选)
        endpoint_run_start: str = DEFAULT_ENDPOINT_RUN_START,
        endpoint_run_heartbeat: str = DEFAULT_ENDPOINT_RUN_HEARTBEAT,
        endpoint_run_end: str = DEFAULT_ENDPOINT_RUN_END,
        endpoint_error: str = DEFAULT_ENDPOINT_ERROR,
        # reliability controls (可选覆盖)
        timeout_sec: Optional[float] = None,  # (上报超时秒)
        max_retries: Optional[int] = None,    # (最大重试次数)
        heartbeat_min_sec: Optional[float] = None,  # (最小心跳间隔秒)
        error_detail_max: Optional[int] = None,      # (错误详情最大长度)
        error_event_max: Optional[int] = None,       # (单次Run最多错误事件条数)
        enable_ip: bool = True,               # (是否上报IP，可选)
        logger: Optional[logging.Logger] = None,
        _deprecation_enabled: bool = True,
    ) -> None:
        self.logger = logger or _logger
        self._deprecation_enabled = _deprecation_enabled

        # 仅使用合并后的配置参数（不再读取系统环境变量）
        self.platform_url = (platform_url or "").strip()
        self.platform_key = ((platform_key or "").strip() or (token or "").strip())

        self.identity = SpiderIdentity(
            spider_name=(spider_name or "").strip(),
            spider_type=(spider_type or "").strip(),
            mode=(mode or "job").strip() or "job",
            env=(env or "prod").strip() or "prod",
            tags=_normalize_tags(tags),
            version=(version or "").strip() or None,
            data_source=(data_source or "").strip() or None,
            source_category=(source_category or "").strip() or None,
            extra=extra or {},
        )

        self.runtime = RuntimeInfo(
            host=(str((extra or {}).get("host", "")).strip() or _get_host()),
            ip=_get_ip() if enable_ip else None,
            pid=_get_pid(),
        )

        # controls
        self.timeout_sec = _safe_float(timeout_sec, DEFAULT_TIMEOUT_SEC)
        self.max_retries = _safe_int(max_retries, DEFAULT_RETRY_MAX)
        self.heartbeat_min_sec = _safe_float(heartbeat_min_sec, DEFAULT_HEARTBEAT_MIN_SEC)
        self.error_detail_max = _safe_int(error_detail_max, DEFAULT_ERROR_DETAIL_MAX)
        self.error_event_max = _safe_int(error_event_max, DEFAULT_ERROR_EVENT_MAX)

        # endpoints
        self.endpoint_run_start = endpoint_run_start
        self.endpoint_run_heartbeat = endpoint_run_heartbeat
        self.endpoint_run_end = endpoint_run_end
        self.endpoint_error = endpoint_error

        # internal state
        self._client = HttpClient(
            HttpClientConfig(
                platform_url=self.platform_url,
                platform_key=self.platform_key,
                timeout_sec=self.timeout_sec,
                max_retries=self.max_retries,
            )
        )
        self._lock = threading.Lock()                     # 保护下方共享状态（BUG1+2）
        self._last_heartbeat_at: Dict[str, float] = {}   # run_id -> last send time (epoch)
        self._error_event_count: Dict[str, int] = {}     # run_id -> count
        self._active_run_ids: set = set()                 # for context manager（BUG6：改为集合，支持多 run）

        # Validate minimal requirements (but do NOT raise)
        if not self.platform_url:
            self.logger.warning("platform_url is empty; 请检查 spider_sdk.ini 或装饰器参数。")
        if not self.platform_key:
            self.logger.warning("platform_key is empty; 请检查 spider_sdk.ini 或装饰器参数。")
        if not self.identity.spider_name:
            self.logger.warning("spider_name is empty; 请在装饰器参数中设置。")
        if not self.identity.spider_type:
            self.logger.warning("spider_type is empty; 请在装饰器参数中设置。")
        if self._deprecation_enabled:
            self._warn_deprecated("SpiderReporter")

    def _warn_deprecated(self, api_name: str) -> None:
        if not self._deprecation_enabled:
            return
        warnings.warn(
            f"`{api_name}` 已废弃（兼容期 1 个主版本）。{DEPRECATION_LINK}",
            DeprecationWarning,
            stacklevel=3,
        )

    def _build_spider_payload(self) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "spider_name": self.identity.spider_name,
            "spider_type": self.identity.spider_type,
            "mode": self.identity.mode,
            "env": self.identity.env,
            "tags": self.identity.tags,
            "version": self.identity.version,
            "extra": self.identity.extra or {},
        }
        if self.identity.data_source is not None:
            payload["data_source"] = self.identity.data_source
        if self.identity.source_category is not None:
            payload["source_category"] = self.identity.source_category
        return payload

    def _build_runtime_payload(self) -> Dict[str, Any]:
        return {
            "host": self.runtime.host,
            "ip": self.runtime.ip,
            "pid": self.runtime.pid,
            "sdk_version": self.runtime.sdk_version,
        }

    # ---------------------------
    # Context manager (job mode)
    # ---------------------------

    def __enter__(self) -> "SpiderReporter":
        # Context manager doesn't auto-start to avoid surprising behavior.
        # Use: with r: run_id = r.start(...)
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        # If user started any runs and exception happens, auto fail all active. (BUG6: set 迁移)
        if exc is not None and self._active_run_ids:
            detail = "".join(traceback.format_exception(exc_type, exc, tb)) if tb else None
            for run_id in list(self._active_run_ids):
                try:
                    self.fail(
                        run_id,
                        error_type="UnknownError",
                        error_message=str(exc) or exc.__class__.__name__,
                        error_detail=detail,
                        stage="other",
                        _deprecated_call=False,
                    )
                except Exception:
                    # never raise
                    pass
        # Do not suppress exception
        return False

    # ---------------------------
    # Job mode APIs
    # ---------------------------

    def start(
        self,
        run_name: Optional[str] = None,                # (本次运行名可选)
        trigger: str = "schedule",                     # (触发方式 schedule/manual/api)
        schedule_time: Optional[str] = None,           # (计划执行时间ISO8601可选)
        timeout_sec: Optional[int] = None,             # (超时阈值秒可选)
        idempotency_key: Optional[str] = None,         # (幂等键可选)
        context: Optional[Dict[str, Any]] = None,      # (上下文JSON可选)
        _deprecated_call: bool = True,
    ) -> str:
        """
        上报 run_start，并返回 run_id(运行ID)。
        说明：
        - 若平台不可用，会本地生成 run_id 并返回，保证业务不中断。
        - start 重试依赖 idempotency_key(幂等键) 避免重复创建run。
        """
        if _deprecated_call:
            self._warn_deprecated("SpiderReporter.start")
        start_ts = int(time.time())
        now_iso = _bj_now_iso()                            # (BUG4: 统一捕获一次，event_time == start_time)
        idem = idempotency_key or _gen_idempotency_key(self.runtime.host, self.runtime.pid, start_ts)

        payload = {
            "event_type": "run_start",                     # (事件类型)
            "event_time": now_iso,                         # (事件时间ISO8601)
            "spider": self._build_spider_payload(),
            "run": {
                "run_id": "",                              # (运行ID 平台或SDK生成)
                "run_name": run_name,                      # (本次运行名可选)
                "trigger": trigger,                        # (触发方式)
                "schedule_time": schedule_time,            # (计划时间可选)
                "start_time": now_iso,                    # (开始时间，与event_time一致)
                "timeout_sec": timeout_sec,                # (超时阈值秒可选)
                "idempotency_key": idem,                   # (幂等键)
                "context": context or {},                  # (上下文JSON可选)
            },
            "runtime": self._build_runtime_payload(),
        }

        run_id = self._gen_local_run_id()  # default local
        ok, resp = self._post(self.endpoint_run_start, payload)
        if ok and isinstance(resp, dict):
            rid = resp.get("run_id")
            if isinstance(rid, str) and rid.strip():
                run_id = rid.strip()

        # mark active for context manager (BUG6: 改为 set，支持多 run 追踪)
        self._active_run_ids.add(run_id)
        return run_id

    def heartbeat(
        self,
        run_id: str,                                  # (运行ID)
        message: Optional[str] = None,                # (一句话状态可选)
        progress_current: Optional[int] = None,       # (当前进度可选)
        progress_total: Optional[int] = None,         # (总进度可选)
        metrics: Optional[Dict[str, Any]] = None,     # (指标字典可选)
        last_error_type: Optional[str] = None,        # (最近错误类型可选)
        last_error_message: Optional[str] = None,     # (最近错误摘要可选)
        _deprecated_call: bool = True,
    ) -> None:
        """
        上报 run_heartbeat（心跳/进度）。
        - 含最小间隔保护：小于 heartbeat_min_sec 的心跳直接丢弃。
        """
        if _deprecated_call:
            self._warn_deprecated("SpiderReporter.heartbeat")
        if not run_id:
            return

        with self._lock:
            now = time.time()
            last = self._last_heartbeat_at.get(run_id, 0.0)
            if (now - last) < self.heartbeat_min_sec:
                return
            self._last_heartbeat_at[run_id] = now

        payload = {
            "event_type": "run_heartbeat",             # (事件类型)
            "event_time": _bj_now_iso(),              # (事件时间)
            "spider": self._build_spider_payload(),
            "runtime": self._build_runtime_payload(),
            "run_id": run_id,                          # (运行ID)
            "status": "running",                       # (状态 固定running)
            "message": message,                        # (一句话状态可选)
            "progress": {
                "current": progress_current,           # (当前进度可选)
                "total": progress_total,               # (总进度可选)
            },
            "metrics": metrics or {},                  # (指标字典可选)
            "last_error": {
                "error_type": last_error_type,         # (最近错误类型可选)
                "error_message": last_error_message,   # (最近错误摘要可选)
            } if (last_error_type or last_error_message) else None,
        }

        if progress_current is not None and progress_total:
            try:
                percent = (float(progress_current) / float(progress_total)) * 100.0
                payload["progress"]["percent"] = round(percent, 2)
            except Exception:
                pass
        self._post(self.endpoint_run_heartbeat, payload)

    def success(
        self,
        run_id: str,                                  # (运行ID)
        metrics: Optional[Dict[str, Any]] = None,     # (汇总指标可选)
        message: Optional[str] = None,                # (结束说明可选)
        _deprecated_call: bool = True,
    ) -> None:
        """
        上报 run_end（成功）。
        """
        if _deprecated_call:
            self._warn_deprecated("SpiderReporter.success")
        self._end(run_id, status="success", metrics=metrics, message=message)

    def fail(
        self,
        run_id: str,                                  # (运行ID)
        error_type: str,                              # (错误类型)
        error_message: str,                           # (错误摘要)
        error_detail: Optional[str] = None,           # (错误详情/堆栈可选)
        stage: Optional[str] = None,                  # (阶段 fetch/parse/store/hook/other可选)
        metrics: Optional[Dict[str, Any]] = None,     # (汇总指标可选)
        _deprecated_call: bool = True,
    ) -> None:
        """
        上报 run_end（失败）。
        """
        if _deprecated_call:
            self._warn_deprecated("SpiderReporter.fail")
        self._end(
            run_id,
            status="failed",
            metrics=metrics,
            message=None,
            error={
                "error_type": error_type,                                   # (错误类型)
                "error_message": error_message,                             # (错误摘要)
                "error_detail": _truncate(error_detail, self.error_detail_max),  # (错误详情截断)
                "stage": stage,                                             # (阶段可选)
            },
        )

    def report_error(
        self,
        run_id: Optional[str] = None,                 # (运行ID可选)
        error_type: str = "UnknownError",            # (错误类型)
        error_message: str = "",                     # (错误摘要)
        error_detail: Optional[str] = None,          # (错误详情可选)
        stage: Optional[str] = None,                 # (阶段可选)
        item_url: Optional[str] = None,              # (对象URL可选)
        item_id: Optional[str] = None,               # (对象ID可选)
        count: int = 1,                              # (次数默认1)
        _deprecated_call: bool = True,
    ) -> None:
        """
        上报 error_event（过程错误事件）。
        - 单次 run 错误事件限量：超过 error_event_max 后不再上报明细（只建议业务侧在 metrics 里累加 fail_count）。
        """
        if _deprecated_call:
            self._warn_deprecated("SpiderReporter.report_error")
        key = run_id or "__service__"
        with self._lock:
            cur = self._error_event_count.get(key, 0)
            if cur >= self.error_event_max:
                return
            self._error_event_count[key] = cur + 1

        payload = {
            "event_type": "error_event",             # (事件类型)
            "event_time": _bj_now_iso(),            # (事件时间)
            "run_id": run_id,                        # (运行ID可选)
            "error_type": error_type,                # (错误类型)
            "error_message": error_message,          # (错误摘要)
            "error_detail": _truncate(error_detail, self.error_detail_max),  # (错误详情截断)
            "stage": stage,                          # (阶段可选)
            "item": {
                "url": item_url,                     # (对象URL可选)
                "id": item_id,                       # (对象ID可选)
            } if (item_url or item_id) else None,
            "count": int(count) if count and count > 0 else 1,  # (次数)
            "spider": self._build_spider_payload(),
            "runtime": self._build_runtime_payload(),
        }

        self._post(self.endpoint_error, payload)

    # ---------------------------
    # Service mode APIs
    # ---------------------------

    def service_up(
        self,
        message: Optional[str] = None,                # (上线说明可选)
        metrics: Optional[Dict[str, Any]] = None,     # (服务初始指标可选)
        _deprecated_call: bool = True,
    ) -> bool:
        """
        服务型上线上报：用 run_start 语义，但不返回 run_id（服务通常无 run_id）。
        返回 True 表示平台已收到上线事件，False 表示上报失败（BUG7: 供调用方决定是否发 service_down）。
        """
        if _deprecated_call:
            self._warn_deprecated("SpiderReporter.service_up")
        payload = {
            "event_type": "service_up",               # (事件类型)
            "event_time": _bj_now_iso(),             # (事件时间)
            "spider": self._build_spider_payload(),
            "runtime": self._build_runtime_payload(),
            "message": message,                            # (上线说明)
            "metrics": metrics or {},                      # (服务指标)
        }
        ok, _ = self._post(self.endpoint_run_start, payload)
        return ok

    def service_heartbeat(
        self,
        message: Optional[str] = None,                # (服务状态可选)
        metrics: Optional[Dict[str, Any]] = None,     # (服务指标可选)
        _deprecated_call: bool = True,
    ) -> None:
        """
        服务型心跳上报：无 run_id，平台按 spider 维度更新在线状态。
        """
        if _deprecated_call:
            self._warn_deprecated("SpiderReporter.service_heartbeat")
        payload = {
            "event_type": "service_heartbeat",         # (事件类型)
            "event_time": _bj_now_iso(),              # (事件时间)
            "spider": self._build_spider_payload(),
            "runtime": self._build_runtime_payload(),
            "message": message,                            # (服务状态)
            "metrics": metrics or {},                      # (服务指标)
        }
        self._post(self.endpoint_run_heartbeat, payload)

    def service_down(
        self,
        reason: Optional[str] = None,                 # (下线原因可选)
        _deprecated_call: bool = True,
    ) -> None:
        """
        服务型下线上报：可选，但建议做（便于平台准确显示）。
        """
        if _deprecated_call:
            self._warn_deprecated("SpiderReporter.service_down")
        payload = {
            "event_type": "service_down",              # (事件类型)
            "event_time": _bj_now_iso(),              # (事件时间)
            "spider": self._build_spider_payload(),
            "runtime": self._build_runtime_payload(),
            "reason": reason,                              # (下线原因)
        }
        self._post(self.endpoint_run_end, payload)

    # ---------------------------
    # Internals
    # ---------------------------

    def _end(
        self,
        run_id: str,
        status: str,                                  # (success/failed/canceled)
        metrics: Optional[Dict[str, Any]] = None,
        message: Optional[str] = None,
        error: Optional[Dict[str, Any]] = None,
    ) -> None:
        if not run_id:
            return

        payload = {
            "event_type": "run_end",                   # (事件类型)
            "event_time": _bj_now_iso(),              # (事件时间)
            "spider": self._build_spider_payload(),
            "runtime": self._build_runtime_payload(),
            "run_id": run_id,                          # (运行ID)
            "status": status,                          # (结果)
            "end_time": _bj_now_iso(),                # (结束时间)
            "message": message,                        # (结束说明可选)
            "metrics": metrics or {},                  # (汇总指标可选)
            "error": error,                            # (失败信息failed才填)
        }
        self._post(self.endpoint_run_end, payload)

        # cleanup
        self._last_heartbeat_at.pop(run_id, None)
        self._active_run_ids.discard(run_id)  # (BUG6: 从 set 中移除，不影响其他 run)

    def _post(self, path: str, payload: Dict[str, Any]) -> Tuple[bool, Optional[Dict[str, Any]]]:
        """
        统一出口：平台URL为空则直接丢弃；永不抛异常。
        """
        if not self.platform_url:
            return False, None
        try:
            return self._client.post_json(path, payload)
        except Exception as e:
            # 理论上 HttpClient 已吞掉，这里再兜底一次
            self.logger.warning(f"SDK internal post failed (swallowed): {e}")
            return False, None

    @staticmethod
    def _gen_local_run_id() -> str:
        """本地兜底 run_id(运行ID)"""
        return uuid.uuid4().hex

    # ---------------------------
    # Convenience helpers for error_detail
    # ---------------------------

    def fail_with_exception(
        self,
        run_id: str,
        error_type: str,
        exc: BaseException,
        stage: Optional[str] = None,
        metrics: Optional[Dict[str, Any]] = None,
        _deprecated_call: bool = True,
    ) -> None:
        """把异常堆栈自动格式化上报 fail（可选辅助方法）"""
        if _deprecated_call:
            self._warn_deprecated("SpiderReporter.fail_with_exception")
        detail = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        self.fail(
            run_id,
            error_type=error_type,
            error_message=str(exc) or exc.__class__.__name__,
            error_detail=detail,
            stage=stage,
            metrics=metrics,
            _deprecated_call=False,
        )


# ---------------------------
# Lightweight integration helpers
# ---------------------------


class ReporterRuntimeContext:
    """装饰器运行态上下文：用于可选注入 heartbeat/error_event 能力。"""

    def __init__(self, reporter: SpiderReporter, run_id: Optional[str]) -> None:
        self.reporter = reporter
        self.run_id = run_id

    def heartbeat(
        self,
        message: Optional[str] = None,
        progress_current: Optional[int] = None,
        progress_total: Optional[int] = None,
        metrics: Optional[Dict[str, Any]] = None,
        last_error_type: Optional[str] = None,
        last_error_message: Optional[str] = None,
    ) -> None:
        if self.run_id:
            self.reporter.heartbeat(
                self.run_id,
                message=message,
                progress_current=progress_current,
                progress_total=progress_total,
                metrics=metrics,
                last_error_type=last_error_type,
                last_error_message=last_error_message,
            )

    def report_error(
        self,
        *,
        error_type: str = "UnknownError",
        error_message: str = "",
        error_detail: Optional[str] = None,
        stage: Optional[str] = None,
        item_url: Optional[str] = None,
        item_id: Optional[str] = None,
        count: int = 1,
    ) -> None:
        self.reporter.report_error(
            run_id=self.run_id,
            error_type=error_type,
            error_message=error_message,
            error_detail=error_detail,
            stage=stage,
            item_url=item_url,
            item_id=item_id,
            count=count,
        )


def _inject_ctx_if_needed(
    func: Callable[..., Any],
    kwargs: Dict[str, Any],
    *,
    inject_ctx: bool,
    ctx_arg_name: str,
    ctx: ReporterRuntimeContext,
) -> Dict[str, Any]:
    if not inject_ctx:
        return kwargs
    try:
        sig = inspect.signature(func)
        has_var_kw = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values())
        if ctx_arg_name in sig.parameters or has_var_kw:
            enriched = dict(kwargs)
            enriched[ctx_arg_name] = ctx
            return enriched
        _logger.warning(f"{func.__name__} 未声明 `{ctx_arg_name}` 且无 **kwargs，跳过 ctx 注入。")
        return kwargs
    except Exception:
        enriched = dict(kwargs)
        enriched[ctx_arg_name] = ctx
        return enriched

_REPORTER_INIT_KEYS = {
    "platform_url",
    "platform_key",
    "token",
    "spider_name",
    "spider_type",
    "mode",
    "env",
    "tags",
    "version",
    "data_source",
    "source_category",
    "extra",
    "endpoint_run_start",
    "endpoint_run_heartbeat",
    "endpoint_run_end",
    "endpoint_error",
    "timeout_sec",
    "max_retries",
    "heartbeat_min_sec",
    "error_detail_max",
    "error_event_max",
    "enable_ip",
    "logger",
    "_deprecation_enabled",
}

_DEFAULT_RUNTIME_OVERRIDE_KEYS = (
    "spider_name",
    "spider_type",
    "mode",
    "env",
    "tags",
    "version",
    "data_source",
    "source_category",
    "extra",
)

_INI_ALLOWED_KEYS = {
    "platform_url",
    "platform_key",
    "timeout_sec",
    "max_retries",
    "heartbeat_min_sec",
    "error_detail_max",
    "error_event_max",
    "enable_ip",
}


def _filter_reporter_kwargs(raw: Dict[str, Any]) -> Dict[str, Any]:
    filtered: Dict[str, Any] = {}
    for key, value in raw.items():
        if key in _REPORTER_INIT_KEYS and value is not None:
            filtered[key] = value
    return filtered


def _filter_ini_config(raw: Dict[str, Any]) -> Dict[str, Any]:
    filtered: Dict[str, Any] = {}
    for key, value in raw.items():
        if key in _INI_ALLOWED_KEYS and value is not None:
            filtered[key] = value
    return filtered


def _extract_runtime_overrides(
    call_kwargs: Dict[str, Any],
    runtime_override_keys: Optional[Iterable[str]],
) -> Dict[str, Any]:
    if not runtime_override_keys:
        return {}
    overrides: Dict[str, Any] = {}
    for key in runtime_override_keys:
        if key in call_kwargs and call_kwargs[key] is not None:
            overrides[key] = call_kwargs[key]
    return overrides


def _coerce_ini_values(raw: Dict[str, Any]) -> Dict[str, Any]:
    if not raw:
        return {}
    out: Dict[str, Any] = {}
    for key, value in raw.items():
        if key in {"max_retries", "error_detail_max", "error_event_max"}:
            out[key] = _safe_int(value, 0)
        elif key in {"timeout_sec", "heartbeat_min_sec"}:
            out[key] = _safe_float(value, 0.0)
        elif key in {"enable_ip"}:
            out[key] = _safe_bool(value, True)
        elif key in {"tags"}:
            out[key] = _normalize_tags(value)
        else:
            out[key] = value
    return out


def create_reporter(
    runtime_overrides: Optional[Dict[str, Any]] = None,
    **kwargs: Any,
) -> SpiderReporter:
    """
    统一构造器：
    - 读取 spider_sdk.ini（仅固定字段）作为项目默认配置；
    - kwargs 作为“装饰器/调用层默认值”；
    - runtime_overrides 作为“运行时显式覆盖”（优先级最高）。
    """
    ini_path = find_project_ini(DEFAULT_INI_FILENAME)
    ini_raw = load_ini_config(ini_path, DEFAULT_INI_SECTION)
    ini_cfg = _filter_ini_config(_coerce_ini_values(ini_raw))

    merged = dict(ini_cfg)
    merged.update(_filter_reporter_kwargs(dict(kwargs)))
    overrides = _filter_reporter_kwargs(runtime_overrides or {})
    merged.update(overrides)
    merged.setdefault("_deprecation_enabled", False)
    return SpiderReporter(**merged)


def report_job(
    *,
    reporter_kwargs: Optional[Dict[str, Any]] = None,
    run_name: Optional[str] = None,
    trigger: str = "schedule",
    schedule_time: Optional[str] = None,
    timeout_sec: Optional[int] = None,
    idempotency_key: Optional[str] = None,
    context: Optional[Dict[str, Any]] = None,
    success_message: Optional[str] = None,
    success_metrics: Optional[Dict[str, Any]] = None,
    result_to_metrics: Optional[Callable[[Any], Optional[Dict[str, Any]]]] = None,
    runtime_override_keys: Optional[Iterable[str]] = _DEFAULT_RUNTIME_OVERRIDE_KEYS,
    runtime_resolver: Optional[Callable[..., Optional[Dict[str, Any]]]] = None,
    inject_ctx: bool = False,
    ctx_arg_name: str = "reporter_ctx",
    fail_error_type: str = "UnknownError",
    fail_stage: Optional[str] = "other",
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """
    Job 装饰器：
    - 自动 start/success/fail；
    - 支持 kwargs/runtime_resolver 动态覆盖 spider 身份字段；
    - 保持异常继续上抛，不改变业务主流程控制。
    """
    base_kwargs = dict(reporter_kwargs or {})
    base_kwargs.setdefault("mode", "job")

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            runtime_overrides = _extract_runtime_overrides(kwargs, runtime_override_keys)
            if runtime_resolver is not None:
                try:
                    resolved = runtime_resolver(*args, **kwargs) or {}
                    runtime_overrides.update(_filter_reporter_kwargs(resolved))
                except Exception as exc:
                    _logger.warning(f"runtime_resolver failed (swallowed): {exc}")

            reporter = create_reporter(runtime_overrides=runtime_overrides, **base_kwargs)
            run_id = reporter.start(
                run_name=run_name,
                trigger=trigger,
                schedule_time=schedule_time,
                timeout_sec=timeout_sec,
                idempotency_key=idempotency_key,
                context=context,
            )
            reporter_ctx = ReporterRuntimeContext(reporter, run_id)
            call_kwargs = _inject_ctx_if_needed(
                func,
                kwargs,
                inject_ctx=inject_ctx,
                ctx_arg_name=ctx_arg_name,
                ctx=reporter_ctx,
            )

            try:
                result = func(*args, **call_kwargs)
            except Exception as exc:
                error_type = fail_error_type or exc.__class__.__name__
                reporter.fail_with_exception(
                    run_id,
                    error_type=error_type,
                    exc=exc,
                    stage=fail_stage,
                )
                raise

            metrics = success_metrics
            if result_to_metrics is not None:
                try:
                    metrics = result_to_metrics(result)
                except Exception as exc:
                    reporter.logger.warning(f"result_to_metrics failed (swallowed): {exc}")
            elif metrics is None and isinstance(result, dict):
                maybe_metrics = result.get("metrics")
                if isinstance(maybe_metrics, dict):
                    metrics = maybe_metrics

            reporter.success(
                run_id,
                metrics=metrics,
                message=success_message,
            )
            return result

        return wrapper

    return decorator


def report_job_from_env(
    *,
    run_name: Optional[str] = None,
    trigger: str = "schedule",
    schedule_time: Optional[str] = None,
    timeout_sec: Optional[int] = None,
    idempotency_key: Optional[str] = None,
    context: Optional[Dict[str, Any]] = None,
    success_message: Optional[str] = None,
    success_metrics: Optional[Dict[str, Any]] = None,
    result_to_metrics: Optional[Callable[[Any], Optional[Dict[str, Any]]]] = None,
    runtime_override_keys: Optional[Iterable[str]] = _DEFAULT_RUNTIME_OVERRIDE_KEYS,
    runtime_resolver: Optional[Callable[..., Optional[Dict[str, Any]]]] = None,
    inject_ctx: bool = False,
    ctx_arg_name: str = "reporter_ctx",
    fail_error_type: str = "UnknownError",
    fail_stage: Optional[str] = "other",
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """
    项目配置版 Job 装饰器（兼容旧函数名）：
    - 仅约束 mode=job；
    - 其余配置由 spider_sdk.ini 或运行时覆盖提供。
    """
    return report_job(
        reporter_kwargs={"mode": "job"},
        run_name=run_name,
        trigger=trigger,
        schedule_time=schedule_time,
        timeout_sec=timeout_sec,
        idempotency_key=idempotency_key,
        context=context,
        success_message=success_message,
        success_metrics=success_metrics,
        result_to_metrics=result_to_metrics,
        runtime_override_keys=runtime_override_keys,
        runtime_resolver=runtime_resolver,
        inject_ctx=inject_ctx,
        ctx_arg_name=ctx_arg_name,
        fail_error_type=fail_error_type,
        fail_stage=fail_stage,
    )


def report_service(
    *,
    reporter_kwargs: Optional[Dict[str, Any]] = None,
    up_message: Optional[str] = "service started",
    heartbeat_message: Optional[str] = "service heartbeat",
    heartbeat_interval_sec: float = 30.0,
    heartbeat_metrics: Optional[Dict[str, Any]] = None,
    heartbeat_metrics_provider: Optional[Callable[..., Optional[Dict[str, Any]]]] = None,
    down_reason: Optional[str] = "shutdown",
    runtime_override_keys: Optional[Iterable[str]] = _DEFAULT_RUNTIME_OVERRIDE_KEYS,
    runtime_resolver: Optional[Callable[..., Optional[Dict[str, Any]]]] = None,
    inject_ctx: bool = False,
    ctx_arg_name: str = "reporter_ctx",
    error_type: str = "ServiceError",
    error_stage: Optional[str] = "other",
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Service 装饰器：自动 up/heartbeat/down，并在异常时自动上报 error_event。"""
    base_kwargs = dict(reporter_kwargs or {})
    base_kwargs.setdefault("mode", "service")

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            runtime_overrides = _extract_runtime_overrides(kwargs, runtime_override_keys)
            if runtime_resolver is not None:
                try:
                    resolved = runtime_resolver(*args, **kwargs) or {}
                    runtime_overrides.update(_filter_reporter_kwargs(resolved))
                except Exception as exc:
                    _logger.warning(f"runtime_resolver failed (swallowed): {exc}")

            reporter = create_reporter(runtime_overrides=runtime_overrides, **base_kwargs)
            reporter_ctx = ReporterRuntimeContext(reporter, None)
            call_kwargs = _inject_ctx_if_needed(
                func,
                kwargs,
                inject_ctx=inject_ctx,
                ctx_arg_name=ctx_arg_name,
                ctx=reporter_ctx,
            )

            stop_event = threading.Event()

            def _heartbeat_loop() -> None:
                interval = max(0.01, float(heartbeat_interval_sec))
                while not stop_event.wait(interval):
                    metrics = heartbeat_metrics
                    if heartbeat_metrics_provider is not None:
                        try:
                            metrics = heartbeat_metrics_provider(*args, **kwargs)  # (BUG5: 用原始kwargs，避免注入的reporter_ctx污染provider签名)
                        except Exception as exc:
                            reporter.logger.warning(f"heartbeat_metrics_provider failed (swallowed): {exc}")
                    reporter.service_heartbeat(
                        message=heartbeat_message,
                        metrics=metrics,
                    )

            service_up_ok = reporter.service_up(message=up_message)  # (BUG7: 记录上线是否成功)
            heartbeat_thread = threading.Thread(target=_heartbeat_loop, daemon=True)
            heartbeat_thread.start()

            try:
                return func(*args, **call_kwargs)
            except Exception as exc:
                reporter.report_error(
                    error_type=error_type or exc.__class__.__name__,
                    error_message=str(exc) or exc.__class__.__name__,
                    error_detail="".join(traceback.format_exception(type(exc), exc, exc.__traceback__)),
                    stage=error_stage,
                )
                raise
            finally:
                stop_event.set()
                heartbeat_thread.join(timeout=1.0)
                if service_up_ok:                          # (BUG7: 只有上线成功过，才发下线事件)
                    reporter.service_down(reason=down_reason)

        return wrapper

    return decorator


class SpiderReportContext:
    """
    with 方式上报：
    - __enter__ 自动 start；
    - __exit__ 无异常 success；有异常 fail_with_exception 并继续抛出。
    """

    def __init__(
        self,
        *,
        reporter_kwargs: Optional[Dict[str, Any]] = None,
        runtime_overrides: Optional[Dict[str, Any]] = None,
        run_name: Optional[str] = None,
        trigger: str = "schedule",
        schedule_time: Optional[str] = None,
        timeout_sec: Optional[int] = None,
        idempotency_key: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
        success_message: Optional[str] = None,
        success_metrics: Optional[Dict[str, Any]] = None,
        fail_error_type: str = "UnknownError",
        fail_stage: Optional[str] = "other",
    ) -> None:
        base_kwargs = dict(reporter_kwargs or {})
        base_kwargs.setdefault("mode", "job")
        self.reporter = create_reporter(runtime_overrides=runtime_overrides, **base_kwargs)
        self.run_name = run_name
        self.trigger = trigger
        self.schedule_time = schedule_time
        self.timeout_sec = timeout_sec
        self.idempotency_key = idempotency_key
        self.context = context
        self.success_message = success_message
        self.success_metrics = success_metrics
        self.fail_error_type = fail_error_type
        self.fail_stage = fail_stage
        self.run_id: Optional[str] = None

    def __enter__(self) -> "SpiderReportContext":
        self.run_id = self.reporter.start(
            run_name=self.run_name,
            trigger=self.trigger,
            schedule_time=self.schedule_time,
            timeout_sec=self.timeout_sec,
            idempotency_key=self.idempotency_key,
            context=self.context,
        )
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        if self.run_id:
            if exc is None:
                self.reporter.success(
                    self.run_id,
                    metrics=self.success_metrics,
                    message=self.success_message,
                )
            else:
                error_type = self.fail_error_type or exc.__class__.__name__
                self.reporter.fail_with_exception(
                    self.run_id,
                    error_type=error_type,
                    exc=exc,
                    stage=self.fail_stage,
                )
        return False

    def heartbeat(
        self,
        *,
        message: Optional[str] = None,
        progress_current: Optional[int] = None,
        progress_total: Optional[int] = None,
        metrics: Optional[Dict[str, Any]] = None,
        last_error_type: Optional[str] = None,
        last_error_message: Optional[str] = None,
    ) -> None:
        if self.run_id:
            self.reporter.heartbeat(
                self.run_id,
                message=message,
                progress_current=progress_current,
                progress_total=progress_total,
                metrics=metrics,
                last_error_type=last_error_type,
                last_error_message=last_error_message,
            )

    def report_error(
        self,
        *,
        error_type: str = "UnknownError",
        error_message: str = "",
        error_detail: Optional[str] = None,
        stage: Optional[str] = None,
        item_url: Optional[str] = None,
        item_id: Optional[str] = None,
        count: int = 1,
    ) -> None:
        self.reporter.report_error(
            run_id=self.run_id,
            error_type=error_type,
            error_message=error_message,
            error_detail=error_detail,
            stage=stage,
            item_url=item_url,
            item_id=item_id,
            count=count,
        )


# ============================================================
# Minimal usage examples (for copy/paste)
# ============================================================
if __name__ == "__main__":
    @report_job(
        reporter_kwargs={"spider_name": "demo_script", "spider_type": "script", "env": "dev"},
        run_name="demo_run",
        inject_ctx=True,
    )
    def _demo_job(reporter_ctx=None):
        ok = 0
        fail = 0
        total = 10
        for i in range(1, total + 1):
            try:
                time.sleep(0.1)
                if i == 7:
                    raise ValueError("simulated error at i=7")
                ok += 1
            except Exception as exc:
                fail += 1
                reporter_ctx.report_error(
                    error_type="ParseError",
                    error_message=str(exc),
                    stage="parse",
                    item_id=str(i),
                )
            reporter_ctx.heartbeat(
                progress_current=i,
                progress_total=total,
                metrics={"items": ok, "success_count": ok, "fail_count": fail},
                message="working",
            )
        return {"metrics": {"items": ok, "success_count": ok, "fail_count": fail}}

    _demo_job()
