# TODO — jcodemunch-mcp

## CLA Outreach Campaign (HIGH PRIORITY)
<!-- Added 2026-03-10 -->

### Send GitHub issue comments to 18 contributors
Create a dedicated issue (e.g. "CLA outreach — contributor sign-off requested") or post
on issue #87. Tag each contributor with their personalized message. All messages are
drafted and ready to paste.

Contributors to contact via GitHub (tag @username):
1. @paperlinguist (Abigail Green) — context providers + SQL, ~2,800 lines
2. @snafu4 (Neil Greisman) — --version flag, early hardening
3. @josh-stephens (Josh) — file summaries, incremental indexing
4. @Cobdog (Aoi) — Dart support, ANTHROPIC_BASE_URL
5. @JeffreyVdb (Jeffrey Vandenborne) — Elixir support
6. @Wes2000ley (Wesley Atwell) — C++ hardening
7. @gebeer — diagnostic logging, get_file_outline fix
8. @zrk02 — concurrent batch summarization
9. @typeofgraphic (PB) — Verse/UEFN language support
10. @MariusAdrian88 (Marius Stanciu) — Windsurf compatibility
11. @levonbragg (Levon Bragg) — C language support
12. @JohnnyD1776 — Swift parsing improvements
13. @ivanmilov (Ivan Milov) — C++ language support (original)
14. @eresende (Eusebio Resende) — local LLM summarization
15. @Mharbulous (Brahm) — arrow function support for JS/TS
16. @phuzzled (Andrew Power) — Claude Code installation docs
17. @allenguarnes (Allen Guarnes) — configurable indexing file cap
18. briepace — folder indexing speedup (unclear GitHub status, check contributors API)

### Send Shane McCarron's message via email (HIGH PRIORITY — sensitive)
- GitHub handle: @halindrome / @shanemccarron-maker
- Email: halindrome@gmail.com
- Contribution: Perl support + security fix (~1,900 lines)
- Already expressed displeasure about MIT -> dual-license change
- Do NOT use GitHub for this — use email only
- Message is drafted: vulnerable in tone, not asking him to return, just to sign so
  existing work can stay legally. Do NOT offer rollback.

---

## Documentation (MEDIUM PRIORITY)
<!-- Added 2026-03-10 -->
- Add LICENSING FAQ to README covering gray areas:
  - Internal tooling
  - Freelancers billing clients
  - Nonprofits
  - Academic / research use
- Consider adding a closing note to issue #87 to publicly close the loop on the
  dual-license transition and CLA process

---

## Completed (2026-03-10)
- [x] Merged PR #89 (paperlinguist — extensible context provider framework + dbt provider)
- [x] Published v1.2.11 to PyPI and GitHub releases
- [x] CLA Assistant configured and linked (cla-assistant.io)
- [x] CLA document drafted (plain English, contributor retains copyright)
- [x] CONTRIBUTING.md created and pushed to both repos
- [x] Contributing section added to both READMEs pointing to CLA Assistant
- [x] All 19 outreach messages drafted and personalized
- [x] jdocmunch-mcp GitHub releases caught up (v1.2.0 and v1.2.1 created)
