"""CubeXpress: Earth Engine data cube downloader with optimal parallelization."""

from __future__ import annotations

import logging


def _silence_external() -> None:
    for lib in ("rasterio", "rasterio._env", "fiona"):
        logging.getLogger(lib).setLevel(logging.ERROR)


_silence_external()

from cubexpress._core import RasterTransform, Request, RequestSet
from cubexpress.catalog import (
    clear_cache,
    geo2utm,
    get_batch_scene_info,
    get_cache_size,
    get_scene_info,
    lonlat2rt,
    mss_table,
    requestset_from_ids,
    s2_table,
    sensor_table,
    table_to_requestset,
)
from cubexpress.download import get_cube, get_geotiff, get_image, get_images, get_numpy_cube
from cubexpress.esa import download_esa_file, extract_esa_bands
from cubexpress.formats import EEFileFormat, ExportFormat, Formats, VisPresets
from cubexpress.sensors import SENSORS

__all__ = [
    # Core types
    "Request",
    "RequestSet",
    "RasterTransform",
    # Sensors
    "SENSORS",
    # Metadata tables
    "sensor_table",
    "s2_table",
    "mss_table",
    # Cache
    "clear_cache",
    "get_cache_size",
    # Scene info
    "get_scene_info",
    "get_batch_scene_info",
    # Request builders
    "requestset_from_ids",
    "table_to_requestset",
    # Download
    "get_cube",
    "get_geotiff",
    "get_numpy_cube",
    "get_image",
    "get_images",
    # Formats
    "Formats",
    "VisPresets",
    "ExportFormat",
    "EEFileFormat",
    # Geometry
    "lonlat2rt",
    "geo2utm",
    # ESA
    "download_esa_file",
    "extract_esa_bands",
]

try:
    from importlib.metadata import version

    __version__ = version("cubexpress")
except Exception:
    __version__ = "0.0.0-dev"
