import time
import os
import json
import contextlib
from concurrent.futures import ThreadPoolExecutor, as_completed

import psutil
import torch
from torch import nn, optim
from expressivity.space import ArchitecturalSpace
from expressivity.monitor import HardwareMonitor
import matplotlib.pyplot as plt
from rich.console import Console
from rich.progress import (
    Progress,
    SpinnerColumn,
    BarColumn,
    TextColumn,
    TimeElapsedColumn,
)


console = Console()


class ArchitectureComparator:
    def __init__(
        self,
        A_space: ArchitecturalSpace,
        B_space: ArchitecturalSpace,
        base_space: ArchitecturalSpace = None,
        criterion=nn.MSELoss(),
        law=torch.distributions.Normal(0, 1),
    ) -> None:
        """
        Initialize the ArchitectureComparator.

        Parameters:
        - A_space (ArchitecturalSpace): The first architectural space.
        - B_space (ArchitecturalSpace): The second architectural space.
        - base_space (ArchitecturalSpace, optional): The base architectural space used for comparison.
        - criterion (nn.Module): Loss function used for training (default: nn.MSELoss).
        - law (torch.distributions.Distribution): Data distribution for sampling (default: Normal(0, 1)).
        """
        self.A_space = A_space
        self.B_space = B_space
        self.base_space = base_space
        self.criterion = criterion
        self.law = law

        assert (
            A_space.input_size == B_space.input_size
        ), "The input size of the two models must be the same"

        self.input_size = A_space.input_size

        assert len(A_space.parameters) == len(
            B_space.parameters
        ), "The number of architectures must be the same in space A and B"
        self.count = len(A_space.parameters)

        assert (
            A_space.automatic_mesurement_mode == B_space.automatic_mesurement_mode
            or A_space.automatic_mesurement_mode is None
            or B_space.automatic_mesurement_mode is None
        ), "The automatic mesurement mode must be the same in space A and B"

        if A_space.mesurement != B_space.mesurement:
            console.print(
                "[yellow]Warning:[/yellow] The mesurements of space A and B are different, you may not compare both model on an equal footing"
            )

        try:
            test_tensor = torch.zeros((1, *self.input_size))
            A_output_size = self._create_model(A_space, 0)(test_tensor).shape
            B_output_size = self._create_model(B_space, 0)(test_tensor).shape

            assert (
                A_output_size == B_output_size
            ), "The output size of the two models must be the same"

            self.output_size = A_output_size[1:]

            if base_space is not None:
                assert (
                    self.input_size == base_space.input_size
                ), "The input size of the two models must be the same"
                base_output_size = self._create_model(base_space, 0)(
                    test_tensor
                ).shape
                assert (
                    self.output_size == base_output_size[1:]
                ), "The output size of the two models must be the same"
                assert len(base_space.parameters) == self.count

        except Exception as e:
            console.print(f"[red]The input size is not correct:[/red] {e}")

    def compare(
        self,
        max_iterations: int = 10,
        sub_iterations: int = 1,
        variance_threashold: float | None = None,
        plot_mode: str | None = None,
        save_path: str | None = os.path.join(os.getcwd(), "results"),
        monitor: bool = False,
    ) -> tuple[list[float]]:
        """
        Compare architectures by fitting one to the other and evaluating performance.

        Parameters:
        - max_iterations (int): Maximum number of gradient descent iterations.
        - sub_iterations (int): Number of attempts of the source architecture to minimize error at each iteration.
        - variance_threashold (float, optional): Threshold to stop iterations based on variance.
        - plot_mode (str, optional): Plot comparison results; "min" or "mean".
        - save_path (str | None): Directory to save results (images + data). Defaults to <cwd>/results/. Set to None to disable saving.
        - monitor (bool): If True, display a live hardware monitor (CPU, RAM, GPU, VRAM, temp, power).

        Returns:
        - tuple[list[float]]: Minimum and mean losses for architectures A and B.
        """

        self.max_iterations = max_iterations
        self.sub_iterations = sub_iterations
        if variance_threashold is None:
            self.variance_threashold = 0
        else:
            self.variance_threashold = variance_threashold

        self.min_A_fit = [None for _ in range(self.count)]
        self.mean_A_fit = [None for _ in range(self.count)]
        self.min_B_fit = [None for _ in range(self.count)]
        self.mean_B_fit = [None for _ in range(self.count)]
        self.time_A = [None for _ in range(self.count)]
        self.time_B = [None for _ in range(self.count)]

        fits_per_model = 2
        total_steps = self.count * fits_per_model * max_iterations * sub_iterations

        hw_monitor = None
        if monitor:
            hw_monitor = HardwareMonitor(interval=0.5)
            hw_monitor.start(console)

        with Progress(
            SpinnerColumn(),
            TextColumn("[bold blue]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=console,
        ) as progress:
            global_task = progress.add_task("Overall", total=total_steps)

            for i in range(self.count):
                console.print(f"\n[bold]Model {i+1}/{self.count}[/bold]")

                if self.base_space is None:
                    source_A, target_A = self.A_space, self.B_space
                    source_B, target_B = self.B_space, self.A_space
                else:
                    source_A, target_A = self.A_space, self.base_space
                    source_B, target_B = self.B_space, self.base_space

                console.print(
                    f"  [cyan]{source_A.name}[/cyan] fits [magenta]{target_A.name}[/magenta]"
                )
                t0 = time.time()
                self.min_A_fit[i], self.mean_A_fit[i] = self._fit_source_to_target(
                    source_A, target_A, i, progress, global_task
                )
                self.time_A[i] = time.time() - t0

                console.print(
                    f"  [cyan]{source_B.name}[/cyan] fits [magenta]{target_B.name}[/magenta]"
                )
                t0 = time.time()
                self.min_B_fit[i], self.mean_B_fit[i] = self._fit_source_to_target(
                    source_B, target_B, i, progress, global_task
                )
                self.time_B[i] = time.time() - t0

                if self.min_B_fit[i] > self.min_A_fit[i]:
                    self.winnner = "A"
                    console.print(
                        f"  [bold green]Winner (min): {self.A_space.name}[/bold green]"
                    )
                else:
                    self.winnner = "B"
                    console.print(
                        f"  [bold green]Winner (min): {self.B_space.name}[/bold green]"
                    )

                if self.mean_B_fit[i] > self.mean_A_fit[i]:
                    if self.winnner == "A":
                        console.print(
                            f"  [bold green]{self.A_space.name} wins by all metrics[/bold green]"
                        )
                    else:
                        console.print(
                            f"  [yellow]However, {self.A_space.name} shows better mean convergence[/yellow]"
                        )
                else:
                    if self.winnner == "B":
                        console.print(
                            f"  [bold green]{self.B_space.name} wins by all metrics[/bold green]"
                        )
                    else:
                        console.print(
                            f"  [yellow]However, {self.B_space.name} shows better mean convergence[/yellow]"
                        )

        if hw_monitor is not None:
            hw_monitor.stop()
            hw_monitor.print_summary(console)

        if save_path is not None:
            os.makedirs(save_path, exist_ok=True)
            self._save_data(save_path)
            self._save_plots(save_path)
            console.print(f"\n[bold green]Results saved to {save_path}[/bold green]")

        if plot_mode is not None:
            self.plot(plot_mode)

        return self.min_A_fit, self.mean_A_fit, self.min_B_fit, self.mean_B_fit

    def _create_model(self, space: ArchitecturalSpace, index: int) -> nn.Module:
        return space.architecture(**space.parameters[index])

    # ------------------------------------------------------------------ #
    #  Memory estimation & adaptive parallelism                           #
    # ------------------------------------------------------------------ #

    def _estimate_model_memory(
        self, space: ArchitecturalSpace, model_index: int
    ) -> int:
        model = self._create_model(space, model_index)
        param_bytes = sum(p.numel() * p.element_size() for p in model.parameters())
        del model
        # params + grads + optimizer state (adam: 2x) + activation headroom
        return param_bytes * 6

    def _compute_max_parallel(
        self, source_space: ArchitecturalSpace, model_index: int
    ) -> int:
        total_runs = self.max_iterations * self.sub_iterations
        model_mem = self._estimate_model_memory(source_space, model_index)
        if model_mem == 0:
            return total_runs
        if torch.cuda.is_available():
            free_mem = torch.cuda.mem_get_info()[0]
        else:
            free_mem = psutil.virtual_memory().available
        max_p = int(free_mem * 0.7 / model_mem)
        return max(1, min(max_p, total_runs))

    @staticmethod
    def _get_device():
        return "cuda" if torch.cuda.is_available() else "cpu"

    # ------------------------------------------------------------------ #
    #  GPU batch auto-scaling                                              #
    # ------------------------------------------------------------------ #

    def _auto_scale_batch_gpu(
        self,
        source_space: ArchitecturalSpace,
        target_space: ArchitecturalSpace,
        model_index: int,
        current_batch_size: int,
    ) -> tuple[int, int, int]:
        """
        Scale batch so each forward pass saturates the GPU (target: ≥1ms).
        Returns (new_batch_size, max_parallel, mem_per_model_bytes).
        """
        # Warmup a throwaway model to initialize CUDA context, cublas handles, etc.
        warmup_model = self._create_model(source_space, model_index).cuda()
        warmup_X = self.law.sample((current_batch_size, *self.input_size)).cuda()
        for _ in range(3):
            warmup_model(warmup_X)
        torch.cuda.synchronize()
        del warmup_model, warmup_X
        torch.cuda.empty_cache()

        # Now measure the DELTA memory for one model's train step
        torch.cuda.reset_peak_memory_stats()
        mem_before = torch.cuda.memory_allocated()

        model = self._create_model(source_space, model_index).cuda()
        model.train()
        X = self.law.sample((current_batch_size, *self.input_size)).cuda()

        # Measure forward pass time
        t0 = torch.cuda.Event(enable_timing=True)
        t1 = torch.cuda.Event(enable_timing=True)
        t0.record()
        model(X)
        t1.record()
        torch.cuda.synchronize()
        fwd_ms = t0.elapsed_time(t1)

        # Full train step to measure peak memory delta
        optimizer = source_space.optimizer(
            model.parameters(), source_space.lr[model_index]
        )
        optimizer.zero_grad()
        out = model(X)
        loss = out.sum()
        loss.backward()
        optimizer.step()
        torch.cuda.synchronize()

        mem_peak = torch.cuda.max_memory_allocated()
        mem_per_model = mem_peak - mem_before

        del model, optimizer, X, out, loss
        torch.cuda.empty_cache()

        # Compute scale factor so forward ≥ 1ms
        target_ms = 1.0
        if fwd_ms >= target_ms:
            desired_scale = 1
        else:
            desired_scale = max(1, int(target_ms / max(fwd_ms, 0.001)))

        # Memory constraints
        free_mem = torch.cuda.mem_get_info()[0]
        total_runs = self.max_iterations * self.sub_iterations
        input_el = 1
        for s in self.input_size:
            input_el *= s
        output_el = 1
        for s in self.output_size:
            output_el *= s
        bytes_per_sample = (input_el + output_el) * 4  # float32

        # Data storage: max_iterations * batch_size * bytes_per_sample
        # Model storage: max_parallel * mem_per_model * scale
        # Solve for scale with budget = free_mem * 0.7
        cost_per_scale = (
            mem_per_model
            + self.max_iterations * current_batch_size * bytes_per_sample
        )
        max_scale_from_mem = max(1, int(free_mem * 0.7 / max(cost_per_scale, 1)))
        scale = min(desired_scale, max_scale_from_mem)

        new_batch = current_batch_size * scale
        new_mem_per_model = mem_per_model * scale  # rough: activations dominate

        # Recalculate max_parallel with new memory profile
        data_mem = self.max_iterations * new_batch * bytes_per_sample
        available_for_models = free_mem * 0.7 - data_mem
        max_parallel = max(
            1, min(int(available_for_models / max(new_mem_per_model, 1)), total_runs)
        )

        console.print(
            f"    [dim]Profiling: fwd={fwd_ms:.3f}ms, mem/model={mem_per_model/1024:.0f}KB, "
            f"scale={scale}x, batch={new_batch}, max_parallel={max_parallel}[/dim]"
        )

        return new_batch, max_parallel, new_mem_per_model

    # ------------------------------------------------------------------ #
    #  Dispatcher                                                         #
    # ------------------------------------------------------------------ #

    def _fit_source_to_target(
        self,
        source_space: ArchitecturalSpace,
        target_space: ArchitecturalSpace,
        model_index: int,
        progress: Progress = None,
        global_task=None,
    ) -> tuple[float]:
        device = self._get_device()
        total_runs = self.max_iterations * self.sub_iterations

        if device == "cuda":
            mini_batch_count = (
                target_space.batch_size[model_index]
                // source_space.mini_batch_size[model_index]
            )
            mini_batch_size = source_space.mini_batch_size[model_index]
            original_batch = mini_batch_count * mini_batch_size

            batch_size, max_parallel, _ = self._auto_scale_batch_gpu(
                source_space, target_space, model_index, original_batch
            )
            if batch_size > original_batch:
                console.print(
                    f"    [dim]GPU auto-scaled batch: {original_batch} → {batch_size} "
                    f"(×{batch_size // original_batch})[/dim]"
                )
        else:
            max_parallel = self._compute_max_parallel(source_space, model_index)

        n_chunks = (total_runs + max_parallel - 1) // max_parallel

        if max_parallel > 1:
            backend = "CUDA streams" if device == "cuda" else "threads"
            if n_chunks == 1:
                console.print(
                    f"    [bold green]⚡ Parallel mode ({backend})[/bold green] — "
                    f"{total_runs} runs ({self.max_iterations} iter × {self.sub_iterations} sub) "
                    f"in a single batch on [bold]{device.upper()}[/bold]"
                )
            else:
                console.print(
                    f"    [bold green]⚡ Parallel mode ({backend})[/bold green] — "
                    f"{total_runs} runs ({self.max_iterations} iter × {self.sub_iterations} sub) "
                    f"in {n_chunks} chunks of ≤{max_parallel} on [bold]{device.upper()}[/bold]"
                )
            if device == "cuda":
                return self._parallel_fit_gpu(
                    source_space, target_space, model_index,
                    max_parallel, batch_size, progress, global_task,
                )
            else:
                return self._parallel_fit_cpu_dispatch(
                    source_space, target_space, model_index,
                    max_parallel, progress, global_task,
                )

        console.print(
            f"    [dim]Sequential mode — 1 run at a time on {device.upper()}[/dim]"
        )
        return self._sequential_fit(
            source_space, target_space, model_index, device, progress, global_task
        )

    # ------------------------------------------------------------------ #
    #  GPU parallel fit — auto-scaled flat batches + CUDA streams          #
    # ------------------------------------------------------------------ #

    def _parallel_fit_gpu(
        self,
        source_space: ArchitecturalSpace,
        target_space: ArchitecturalSpace,
        model_index: int,
        max_parallel: int,
        batch_size: int,
        progress: Progress = None,
        global_task=None,
    ) -> tuple[float]:

        total_runs = self.max_iterations * self.sub_iterations
        epochs = source_space.epoch[model_index]
        grad_clamp = source_space.grad_clamp[model_index]
        lr = source_space.lr[model_index]
        criterion = self.criterion

        # -------------------------------------------------------------- #
        # 1) Pre-generate ALL data — flat tensors (batch_size, *dims)     #
        # -------------------------------------------------------------- #
        console.print("    [dim]Generating targets...[/dim]")
        all_X = []
        all_targets = []
        for i in range(self.max_iterations):
            X = self.law.sample((batch_size, *self.input_size)).cuda()
            target_model = self._create_model(target_space, model_index).cuda()
            target_model.eval()
            with torch.no_grad():
                t_out = target_model(X)
            all_X.append(X)
            all_targets.append(t_out)
            del target_model
        torch.cuda.empty_cache()

        iter_for_run = [r // self.sub_iterations for r in range(total_runs)]

        # -------------------------------------------------------------- #
        # 2) Process runs in chunks — CUDA Graphs with streams fallback   #
        # -------------------------------------------------------------- #
        all_losses = [0.0] * total_runs
        run_idx = 0
        last_printed_iter = -1
        use_graphs = True  # will flip to False if capture fails

        while run_idx < total_runs:
            chunk_end = min(run_idx + max_parallel, total_runs)
            chunk_size = chunk_end - run_idx

            console.print(
                f"    [dim]Chunk: runs {run_idx + 1}..{chunk_end}/{total_runs} "
                f"({chunk_size} models in parallel)[/dim]"
            )

            # -- Create models + optimizers --
            models = []
            optimizers = []
            for i in range(chunk_size):
                m = self._create_model(source_space, model_index).cuda()
                o = source_space.optimizer(m.parameters(), lr)
                models.append(m)
                optimizers.append(o)

            # -- Assign data --
            run_X = [all_X[iter_for_run[run_idx + i]] for i in range(chunk_size)]
            run_targets = [
                all_targets[iter_for_run[run_idx + i]] for i in range(chunk_size)
            ]

            # -- Try CUDA Graphs, fall back to CUDA streams ---------------
            if use_graphs:
                try:
                    self._train_chunk_cuda_graph(
                        models, optimizers, run_X, run_targets,
                        epochs, grad_clamp, criterion, chunk_size,
                    )
                    if run_idx == 0:
                        console.print("    [dim]Using CUDA Graphs[/dim]")
                except Exception as e:
                    use_graphs = False
                    console.print(
                        f"    [yellow]CUDA Graph capture failed ({e}), "
                        f"falling back to CUDA streams[/yellow]"
                    )
                    # Re-create models (graph capture may have corrupted state)
                    del models, optimizers
                    torch.cuda.empty_cache()
                    models = []
                    optimizers = []
                    for i in range(chunk_size):
                        m = self._create_model(source_space, model_index).cuda()
                        o = source_space.optimizer(m.parameters(), lr)
                        models.append(m)
                        optimizers.append(o)
                    self._train_chunk_streams(
                        models, optimizers, run_X, run_targets,
                        epochs, grad_clamp, criterion, chunk_size,
                    )
                    if run_idx == 0:
                        console.print("    [dim]Using CUDA streams[/dim]")

            if not use_graphs:
                self._train_chunk_streams(
                    models, optimizers, run_X, run_targets,
                    epochs, grad_clamp, criterion, chunk_size,
                )

            # -- Eval --
            torch.cuda.synchronize()
            eval_losses = torch.zeros(chunk_size, device="cuda")
            for i in range(chunk_size):
                models[i].eval()
                with torch.no_grad():
                    output = models[i](run_X[i])
                    eval_losses[i] = criterion(output, run_targets[i])

            torch.cuda.synchronize()
            eval_cpu = eval_losses.cpu().tolist()
            for i in range(chunk_size):
                all_losses[run_idx + i] = eval_cpu[i]

            if progress is not None:
                progress.advance(global_task, chunk_size)

            # Print running averages for newly completed iterations
            completed_up_to = chunk_end // self.sub_iterations
            for it in range(last_printed_iter + 1, completed_up_to):
                start = it * self.sub_iterations
                end = start + self.sub_iterations
                it_losses = all_losses[start:end]
                it_min = min(it_losses)
                it_mean = sum(it_losses) / len(it_losses)
                all_completed = all_losses[:end]
                losses_so_far = torch.tensor(all_completed).view(it + 1, self.sub_iterations)
                running_min = losses_so_far.min(dim=1).values.mean().item()
                running_mean = losses_so_far.mean(dim=1).mean().item()
                console.print(
                    f"      Iter {it + 1}/{self.max_iterations}: "
                    f"min={it_min:.6f}, mean={it_mean:.6f} | "
                    f"Running avg — min: {running_min:.6f}, mean: {running_mean:.6f}"
                )
                last_printed_iter = it

            del models, optimizers
            torch.cuda.empty_cache()
            run_idx = chunk_end

        del all_X, all_targets

        losses_t = torch.tensor(all_losses).view(
            self.max_iterations, self.sub_iterations
        )
        minimum = losses_t.min(dim=1).values
        mean_vals = losses_t.mean(dim=1)

        return minimum.mean().item(), mean_vals.mean().item()

    # ------------------------------------------------------------------ #
    #  GPU training backends                                               #
    # ------------------------------------------------------------------ #

    def _train_chunk_cuda_graph(
        self, models, optimizers, run_X, run_targets,
        epochs, grad_clamp, criterion, chunk_size,
    ):
        """Train a chunk using CUDA Graph capture + replay."""
        # Pre-allocate static buffers (graph needs fixed memory addresses)
        static_X = [torch.empty_like(run_X[i]) for i in range(chunk_size)]
        static_targets = [torch.empty_like(run_targets[i]) for i in range(chunk_size)]
        for i in range(chunk_size):
            static_X[i].copy_(run_X[i])
            static_targets[i].copy_(run_targets[i])

        # Warmup pass (allocates all internal CUDA buffers)
        for i in range(chunk_size):
            optimizers[i].zero_grad()
            output = models[i](static_X[i])
            loss = criterion(output, static_targets[i])
            loss.backward()
            torch.nn.utils.clip_grad_value_(models[i].parameters(), grad_clamp)
            optimizers[i].step()
        torch.cuda.synchronize()

        # Re-init models for fresh training (reset parameters in-place)
        for i in range(chunk_size):
            for p in models[i].parameters():
                if p.dim() >= 2:
                    nn.init.kaiming_uniform_(p)
                elif p.dim() == 1:
                    nn.init.zeros_(p)
            optimizers[i] = type(optimizers[i])(
                models[i].parameters(), lr=optimizers[i].defaults["lr"]
            )

        # Capture
        torch.cuda.synchronize()
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            for i in range(chunk_size):
                optimizers[i].zero_grad()
                output = models[i](static_X[i])
                loss = criterion(output, static_targets[i])
                loss.backward()
                torch.nn.utils.clip_grad_value_(
                    models[i].parameters(), grad_clamp
                )
                optimizers[i].step()

        # Replay
        for epoch in range(epochs):
            graph.replay()
        torch.cuda.synchronize()

    def _train_chunk_streams(
        self, models, optimizers, run_X, run_targets,
        epochs, grad_clamp, criterion, chunk_size,
    ):
        """Train a chunk using CUDA streams for parallelism."""
        n_streams = min(chunk_size, 32)
        streams = [torch.cuda.Stream() for _ in range(n_streams)]
        ev = torch.cuda.Event()
        ev.record()
        for s in streams:
            s.wait_event(ev)

        for epoch in range(epochs):
            for i in range(chunk_size):
                with torch.cuda.stream(streams[i % n_streams]):
                    optimizers[i].zero_grad()
                    output = models[i](run_X[i])
                    loss = criterion(output, run_targets[i])
                    loss.backward()
                    torch.nn.utils.clip_grad_value_(
                        models[i].parameters(), grad_clamp
                    )
                    optimizers[i].step()

        torch.cuda.synchronize()

    # ------------------------------------------------------------------ #
    #  CPU parallel fit dispatch                                           #
    # ------------------------------------------------------------------ #

    def _parallel_fit_cpu_dispatch(
        self,
        source_space: ArchitecturalSpace,
        target_space: ArchitecturalSpace,
        model_index: int,
        max_parallel: int,
        progress: Progress = None,
        global_task=None,
    ) -> tuple[float]:

        total_runs = self.max_iterations * self.sub_iterations
        epochs = source_space.epoch[model_index]
        grad_clamp = source_space.grad_clamp[model_index]
        lr = source_space.lr[model_index]
        criterion = self.criterion

        mini_batch_count = (
            target_space.batch_size[model_index]
            // source_space.mini_batch_size[model_index]
        )
        mini_batch_size = source_space.mini_batch_size[model_index]
        shape = (mini_batch_count, mini_batch_size, *self.input_size)

        console.print("    [dim]Generating targets...[/dim]")
        all_X = []
        all_targets = []
        for i in range(self.max_iterations):
            X = self.law.sample(shape)
            target_model = self._create_model(target_space, model_index)
            target_model.eval()
            with torch.no_grad():
                t_out = target_model(
                    X.view(mini_batch_count * mini_batch_size, *self.input_size)
                )
                t_out = t_out.view(
                    mini_batch_count, mini_batch_size, *self.output_size
                )
            all_X.append(X)
            all_targets.append(t_out)
            del target_model

        iter_for_run = [r // self.sub_iterations for r in range(total_runs)]

        all_losses = [0.0] * total_runs
        run_idx = 0
        last_printed_iter = -1

        while run_idx < total_runs:
            chunk_end = min(run_idx + max_parallel, total_runs)
            chunk_size = chunk_end - run_idx

            run_X = [all_X[iter_for_run[run_idx + i]] for i in range(chunk_size)]
            run_targets = [
                all_targets[iter_for_run[run_idx + i]] for i in range(chunk_size)
            ]

            models = []
            optimizers = []
            for i in range(chunk_size):
                m = self._create_model(source_space, model_index)
                o = source_space.optimizer(m.parameters(), lr)
                models.append(m)
                optimizers.append(o)

            self._parallel_fit_cpu(
                models, optimizers, run_X, run_targets,
                epochs, mini_batch_count, grad_clamp, criterion,
                all_losses, run_idx, chunk_size,
                progress, global_task,
            )

            # Print running averages for newly completed iterations
            completed_up_to = chunk_end // self.sub_iterations
            if chunk_end % self.sub_iterations != 0:
                completed_up_to = completed_up_to  # partial iter not yet done
            for it in range(last_printed_iter + 1, completed_up_to):
                start = it * self.sub_iterations
                end = start + self.sub_iterations
                if end > chunk_end:
                    break
                it_losses = all_losses[start:end]
                it_min = min(it_losses)
                it_mean = sum(it_losses) / len(it_losses)
                # Running average over all completed iterations so far
                all_completed = all_losses[: end]
                losses_t = torch.tensor(all_completed).view(it + 1, self.sub_iterations)
                running_min = losses_t.min(dim=1).values.mean().item()
                running_mean = losses_t.mean(dim=1).mean().item()
                console.print(
                    f"      Iter {it + 1}/{self.max_iterations}: "
                    f"min={it_min:.6f}, mean={it_mean:.6f} | "
                    f"Running avg — min: {running_min:.6f}, mean: {running_mean:.6f}"
                )
                last_printed_iter = it

            del models, optimizers
            run_idx = chunk_end

        del all_X, all_targets

        losses_t = torch.tensor(all_losses).view(
            self.max_iterations, self.sub_iterations
        )
        minimum = losses_t.min(dim=1).values
        mean_vals = losses_t.mean(dim=1)

        return minimum.mean().item(), mean_vals.mean().item()

    # ------------------------------------------------------------------ #
    #  CPU backend: ThreadPoolExecutor                                     #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _train_single_run(
        model, optimizer, X, targets,
        epochs, mini_batch_count, grad_clamp, criterion,
        intra_threads,
    ) -> float:
        """Train a single model and return its eval loss. Runs in a worker thread."""
        torch.set_num_threads(intra_threads)
        model.train()
        for epoch in range(epochs):
            for mb_idx in range(mini_batch_count):
                optimizer.zero_grad()
                output = model(X[mb_idx])
                loss = criterion(output, targets[mb_idx])
                loss.backward()
                torch.nn.utils.clip_grad_value_(model.parameters(), grad_clamp)
                optimizer.step()

        model.eval()
        eval_loss = 0.0
        with torch.no_grad():
            for mb_idx in range(mini_batch_count):
                output = model(X[mb_idx])
                eval_loss += criterion(output, targets[mb_idx]).item()
        return eval_loss / mini_batch_count

    def _parallel_fit_cpu(
        self, models, optimizers, run_X, run_targets,
        epochs, mini_batch_count, grad_clamp, criterion,
        all_losses, run_idx, chunk_size,
        progress=None, global_task=None,
    ):
        total_cores = os.cpu_count() or 4
        n_workers = min(chunk_size, total_cores)
        intra_threads = max(1, total_cores // n_workers)

        original_threads = torch.get_num_threads()

        with ThreadPoolExecutor(max_workers=n_workers) as pool:
            futures = {}
            for i in range(chunk_size):
                fut = pool.submit(
                    self._train_single_run,
                    models[i], optimizers[i],
                    run_X[i], run_targets[i],
                    epochs, mini_batch_count, grad_clamp, criterion,
                    intra_threads,
                )
                futures[fut] = i

            for fut in as_completed(futures):
                i = futures[fut]
                all_losses[run_idx + i] = fut.result()
                if progress is not None:
                    progress.advance(global_task)

        torch.set_num_threads(original_threads)

    # ------------------------------------------------------------------ #
    #  Sequential fit (fallback / CPU)                                    #
    # ------------------------------------------------------------------ #

    def _sequential_fit(
        self,
        source_space: ArchitecturalSpace,
        target_space: ArchitecturalSpace,
        model_index: int,
        device: str,
        progress: Progress = None,
        global_task=None,
    ) -> tuple[float]:

        minimum = torch.tensor([torch.inf] * self.max_iterations)
        mean = torch.zeros(self.max_iterations)

        epochs = source_space.epoch[model_index]
        grad_clamp = source_space.grad_clamp[model_index]
        criterion = self.criterion

        mini_batch_count = (
            target_space.batch_size[model_index]
            // source_space.mini_batch_size[model_index]
        )
        mini_batch_size = source_space.mini_batch_size[model_index]
        shape = (mini_batch_count, mini_batch_size, *self.input_size)

        for i in range(self.max_iterations):
            console.print(f"    [dim]Iteration {i+1}/{self.max_iterations}[/dim]")

            X = self.law.sample(shape).to(device)

            target_model = self._create_model(target_space, model_index).to(device)
            target_model.eval()
            with torch.no_grad():
                target_output = target_model(
                    X.view(mini_batch_count * mini_batch_size, *self.input_size)
                )
                target_output = target_output.view(
                    mini_batch_count, mini_batch_size, *self.output_size
                )
            del target_model

            for j in range(self.sub_iterations):
                console.print(
                    f"      [dim]Sub-iteration {j+1}/{self.sub_iterations}[/dim]"
                )
                source_model = self._create_model(source_space, model_index).to(device)
                optimizer = source_space.optimizer(
                    source_model.parameters(), source_space.lr[model_index]
                )

                # Train
                source_model.train()
                for epoch in range(epochs):
                    for mini_batch, target in zip(X, target_output):
                        optimizer.zero_grad()
                        output = source_model(mini_batch)
                        loss = criterion(output, target)
                        loss.backward()
                        torch.nn.utils.clip_grad_value_(
                            source_model.parameters(), grad_clamp
                        )
                        optimizer.step()
                    console.print(
                        f"        Epoch {epoch + 1}/{epochs}, Loss: {loss.item():.6f}"
                    )

                # Eval
                source_model.eval()
                eval_loss = 0
                with torch.no_grad():
                    for mini_batch, target in zip(X, target_output):
                        output = source_model(mini_batch)
                        eval_loss += criterion(output, target)
                eval_loss /= X.shape[0]
                loss_val = eval_loss.item()
                console.print(f"        [bold]Final loss: {loss_val:.6f}[/bold]")

                minimum[i] = min(minimum[i], loss_val)
                mean[i] += loss_val
                del source_model, optimizer

                if progress is not None:
                    progress.advance(global_task)

            mean[i] /= self.sub_iterations

            # Running average over completed iterations
            completed = i + 1
            running_min = minimum[:completed].mean().item()
            running_mean = mean[:completed].mean().item()
            console.print(
                f"      Iter {completed}/{self.max_iterations}: "
                f"min={minimum[i].item():.6f}, mean={mean[i].item():.6f} | "
                f"Running avg — min: {running_min:.6f}, mean: {running_mean:.6f}"
            )

            min_var = torch.var(minimum[:completed], unbiased=True)
            mean_var = torch.var(mean[:completed], unbiased=True)
            if max(min_var, mean_var) < self.variance_threashold:
                break

        return minimum.mean().item(), mean.mean().item()

    # ------------------------------------------------------------------ #
    #  Saving results                                                     #
    # ------------------------------------------------------------------ #

    def _save_data(self, save_path: str) -> None:
        data = {
            "A_space": self.A_space.name,
            "B_space": self.B_space.name,
            "mesurement_mode": self.A_space.automatic_mesurement_mode
            or self.B_space.automatic_mesurement_mode,
            "mesurements_A": self.A_space.mesurement,
            "mesurements_B": self.B_space.mesurement,
            "min_A_fit": self.min_A_fit,
            "mean_A_fit": self.mean_A_fit,
            "min_B_fit": self.min_B_fit,
            "mean_B_fit": self.mean_B_fit,
            "time_A": self.time_A,
            "time_B": self.time_B,
            "max_iterations": self.max_iterations,
            "sub_iterations": self.sub_iterations,
        }
        with open(os.path.join(save_path, "results.json"), "w") as f:
            json.dump(data, f, indent=2)

    def _save_plots(self, save_path: str) -> None:
        for mode in ["min", "mean"]:
            if mode == "min":
                values_A = self.min_A_fit
                values_B = self.min_B_fit
            else:
                values_A = self.mean_A_fit
                values_B = self.mean_B_fit

            if any(v is None for v in values_A + values_B):
                continue

            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

            ax1.plot(
                self.A_space.mesurement,
                values_A,
                label=f"{self.A_space.name} ({mode})",
                marker="o",
            )
            ax1.plot(
                self.B_space.mesurement,
                values_B,
                label=f"{self.B_space.name} ({mode})",
                marker="o",
            )
            ax1.set_xlabel("Number of Parameters")
            ax1.set_ylabel(f"{mode.capitalize()} Loss")
            ax1.set_title(f"{mode.capitalize()} Loss vs Parameters")
            ax1.legend()
            ax1.grid(True)

            ax2.plot(
                self.time_A,
                values_A,
                label=f"{self.A_space.name} ({mode})",
                marker="o",
            )
            ax2.plot(
                self.time_B,
                values_B,
                label=f"{self.B_space.name} ({mode})",
                marker="o",
            )
            ax2.set_xlabel("Time (s)")
            ax2.set_ylabel(f"{mode.capitalize()} Loss")
            ax2.set_title(f"{mode.capitalize()} Loss vs Time")
            ax2.legend()
            ax2.grid(True)

            plt.tight_layout()
            fig.savefig(os.path.join(save_path, f"{mode}_comparison.png"), dpi=150)
            plt.close(fig)

    # ------------------------------------------------------------------ #
    #  Plotting                                                           #
    # ------------------------------------------------------------------ #

    def plot(self, mode: str) -> None:
        if mode not in ["min", "mean"]:
            raise ValueError("Mode must be 'min' or 'mean'")

        if mode == "min":
            values_A = self.min_A_fit
            values_B = self.min_B_fit
        elif mode == "mean":
            values_A = self.mean_A_fit
            values_B = self.mean_B_fit

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

        # Plot 1: Performance vs number of parameters
        ax1.plot(
            self.A_space.mesurement,
            values_A,
            label=f"{self.A_space.name} ({mode})",
            marker="o",
        )
        ax1.plot(
            self.B_space.mesurement,
            values_B,
            label=f"{self.B_space.name} ({mode})",
            marker="o",
        )
        ax1.set_xlabel("Number of Parameters")
        ax1.set_ylabel(f"{mode.capitalize()} Loss")
        ax1.set_title(f"{mode.capitalize()} Loss vs Parameters")
        ax1.legend()
        ax1.grid(True)

        # Plot 2: Performance vs time
        ax2.plot(
            self.time_A,
            values_A,
            label=f"{self.A_space.name} ({mode})",
            marker="o",
        )
        ax2.plot(
            self.time_B,
            values_B,
            label=f"{self.B_space.name} ({mode})",
            marker="o",
        )
        ax2.set_xlabel("Time (s)")
        ax2.set_ylabel(f"{mode.capitalize()} Loss")
        ax2.set_title(f"{mode.capitalize()} Loss vs Time")
        ax2.legend()
        ax2.grid(True)

        plt.tight_layout()
        plt.show()

    def get_densities(self):
        """
        Compute and return the density of the comparison.

        Returns:
        - To be implemented if mathematically cool.
        """
        pass
