from mariadb import Cursor

class UserModel:
    @staticmethod
    def get_all(cur: Cursor, id: int) -> list | None:
        cur.execute("SELECT * FROM Users")

        rows = cur.fetchall()

        if not rows: return None

        return [{"id": row[0], "name": row[1]} for row in rows]

    @staticmethod
    def get_by_id(cur: Cursor, id: int) -> dict | None:
        cur.execute("SELECT * FROM Users WHERE id = ?", (id,))

        row = cur.fetchone()

        if not row: return None

        return {"id": row[0], "name": row[1]}
