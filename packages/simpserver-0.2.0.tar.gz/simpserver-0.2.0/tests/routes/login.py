from http import HTTPMethod
from mariadb import Cursor
import string
import random

from simpserver.router import route, ensure_body_keys
from simpserver.exceptions import CredentialsError

from models import UserModel

logins: dict[int, str] = {}

token_characters = string.ascii_letters + string.digits + string.punctuation

@route("/login", HTTPMethod.POST)
@ensure_body_keys({"name": str, "password": str})
def login(cur: Cursor, body: dict) -> dict:
    cur.execute("SELECT * FROM Users WHERE name = ? AND password = ?", (body["name"], body["password"]))

    row = cur.fetchone()

    if not row: raise CredentialsError()

    token = "".join(random.choices(token_character, k=2))

    logins[row[0]] = token

    return {"token": token}


@ensure_body_keys({"token": str})
def login_check(**kwargs) -> bool:
    body = kwargs["body"]

    return body["token"] in logins.values()


def get_user_info(cur: Cursor, body: dict) -> dict | None:
    if "token" not in body.keys(): return None

    passed_token = body["token"]

    for id, token in logins.items():
        if passed_token == token:
            return UserModel.get_by_id(cur, id)

    return None
