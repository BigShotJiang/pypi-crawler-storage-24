from http import HTTPMethod
from mariadb import Cursor, Connection

from simpserver.router import route, ensure_header_keys


@route("/teste1", HTTPMethod.GET)
def test(header: dict) -> str:
    return header
