from routes.login import login_check, get_user_info

DB_CONFIG = {
    "host": "127.0.0.1",
    "port": 3306,
    "user": "root",
    "password": "pass",
    "database": "teste"
}

static_path = "./static/"

login_check_func = login_check
get_user_info_func = get_user_info
