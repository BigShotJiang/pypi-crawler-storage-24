# stdout-err
Run a command. Make sure that errors are propagated to stdout.

This is unreviewed AI-generated code. But I am running it on my machine.

## Motivation
I am using a kde panel to run a command. Irritatingy, if the command fails there is no indication. I do not want to understanding how kde panel widgets work, nor debug them. So instead, I shall make a wrapper.

## Alternatives and prior work
Create a between widget that detects errots. You could do this with a bash one-line: `bash -c "command || echo failure". I like to standardize my scripts and share them wit hthe internet where they can't get removed.

## Installation
pipx install stdout-err

## Usage
stdout-err false

