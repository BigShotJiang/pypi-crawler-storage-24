#!/usr/bin/env python3
"""
stdout-err - Run a command and propagate errors to stdout.
Usage: stdout-err <command> [args...]
"""
import subprocess
import sys


def main():
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help"):
        print("Usage: stdout-err <command> [args...]")
        print("Run a command. If it fails, print stderr to stdout and exit 1.")
        sys.exit(0)

    command = sys.argv[1:]

    try:
        result = subprocess.run(command, capture_output=True, text=True)
        if result.stdout:
            print(result.stdout, end="")
        if result.returncode != 0:
            err = result.stderr.strip() or f"exited with code {result.returncode}"
            print(f"❌ {command[0]}: {err}")
            sys.exit(result.returncode)
    except FileNotFoundError:
        print(f"❌ {command[0]}: command not found")
        sys.exit(1)
    except Exception as e:
        print(f"❌ {command[0]}: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()