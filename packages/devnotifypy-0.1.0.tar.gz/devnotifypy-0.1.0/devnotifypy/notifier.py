import random
import string
import platform
import os
import psutil

# Optional Firebase
try:
    import firebase_admin
    from firebase_admin import credentials, messaging
    FIREBASE_AVAILABLE = True
except ImportError:
    FIREBASE_AVAILABLE = False

def generate_password(length=12):
    """Generate random password with letters, digits, symbols."""
    chars = string.ascii_letters + string.digits + string.punctuation
    return ''.join(random.choice(chars) for _ in range(length))

def get_system_info():
    """Return system info tuple (platform, release, version, cpu_count, memory_mb)."""
    return (
        platform.system(),
        platform.release(),
        platform.version(),
        os.cpu_count(),
        round(psutil.virtual_memory().total / 1024 / 1024)
    )

def send_firebase_notification(title="Test", body="This is a test!", service_key_path="service_account.json"):
    """Send Firebase notification if firebase-admin installed and key exists."""
    if not FIREBASE_AVAILABLE:
        print("Firebase Notifications (firebase-admin not installed)")
        return False

    if not os.path.exists(service_key_path):
        print(f"Firebase Notifications skipped. '{service_key_path}' not found.")
        return False

    try:
        cred = credentials.Certificate(service_key_path)
        firebase_admin.initialize_app(cred)
        message = messaging.Message(
            notification=messaging.Notification(title=title, body=body),
            topic="general"
        )
        response = messaging.send(message)
        print("Firebase Notifications sent. Response:", response)
        return True
    except Exception as e:
        print("Firebase Notifications failed:", e)
        return False

if __name__ == "__main__":
    print("Vid Testing Developer Utilities D")
    print("Random password:", generate_password())
    sys_info = get_system_info()
    print(f"System info: ('platform': '{sys_info[0]}', 'platform_release': '{sys_info[1]}', 'platform version': '{sys_info[2]}', 'cpu count': {sys_info[3]}, memory,total: {sys_info[4]})")
    print("Desktop Testing")
    send_firebase_notification()
    print("Downloads")
    print("Library tests complete!")
    print("Documents")