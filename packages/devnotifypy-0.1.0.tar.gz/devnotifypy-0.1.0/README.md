# DevNotifyPy


![Python](https://img.shields.io/badge/Python-3.8+-blue)
![Library](https://img.shields.io/badge/Library-DevNotifyPy-purple)
![License](https://img.shields.io/badge/License-MIT-green)
![Status](https://img.shields.io/badge/Status-Active-success)
![Maintained](https://img.shields.io/badge/Maintained-Yes-orange)

---

DevNotifyPy is a Python library that provides developer utilities and optional Firebase notification support.

## Installation

Install the library using pip:

```bash
pip install devnotifypy
---

DevNotifyPy is a Python library that provides developer utilities and optional Firebase notification support.


## Installation

Install the library using pip:

```bash
  pip install devnotifypy
```
## Install optional dependencies for Firebase notifications:
``` bash
  pip install firebase-admin psutil
```
### Usage Examples

```python
from devnotifypy import generate_password, get_system_info, send_firebase_notification

# ------------------ Developer Utilities ------------------
print("Random password:", generate_password(12))
print("System info:", get_system_info())

# ------------------ Firebase Notifications (Optional) ------------------
send_firebase_notification(
    title="Hello!", 
    body="This is a test!", 
    service_key_path="service_account.json"
)
```
## Features
- Generate random passwords
- Get system information
- Send Firebase push notifications
- Useful for testing Firebase integration
## Demo Screenshot


![Output Screenshot](demo/output.png)


## Requirements

- Python 3.8

- psutil for system info

- firebase-admin for Firebase notifications (optional)

## Use Cases

- Learning Python utilities
- Testing Firebase push notifications
- Building demo applications
- Simulating social media notifications

## ⚠️ Disclaimer
This project is for learning and testing purposes only.
## Author
M Thamarai Priya


## License
MIT License