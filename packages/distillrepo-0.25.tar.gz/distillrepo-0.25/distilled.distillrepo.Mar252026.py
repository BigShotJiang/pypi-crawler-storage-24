# Distillrepo Review Bundle
# Package: distillrepo
# Analysis kind: application
# Roots analyzed: 3
# Root summary: distillrepo [package_root]=11, distillrepo.cli [cli_entrypoint]=12, distillrepo.api [module_root]=10
# Entry point: cli.py:main
# Review mode: full
# Files analyzed: 13
# Reached from root set / not reached: 12 / 1
# Lines / SLOC: 2480 / 2172
# Original repo size (est tokens): 25087
# Bundle size (est tokens): 25088
# Compression: 1.0x

# Review Guidance
# This bundle is a static-analysis-derived review artifact optimized for LLM review and agent navigation.
# Treat file paths, source spans, signatures, imports, and directly extracted symbol relationships as high-confidence facts.
# Treat hotspots, importance scores, not-reached-from-roots results, and unused-code candidates as heuristics.
# Not reached from roots does not mean dead code; dynamic imports, lazy exports, plugin registration, and reflection may be underrepresented.
# Analysis roots were selected for application review and consolidated across 3 roots.
# Compressed or omitted files may still matter; verify critical conclusions against the original source when needed.

# Module Inventory
- 1 | models.py | cc=0 | depth=1 | root_count=3 | mode=full
- 2 | ir.py | cc=14 | depth=1 | root_count=3 | mode=full
- 3 | ranking.py | cc=20 | depth=1 | root_count=3 | mode=full
- 4 | graphs.py | cc=14 | depth=1 | root_count=3 | mode=full
- 5 | resolution.py | cc=16 | depth=1 | root_count=3 | mode=full
- 6 | enrich.py | cc=15 | depth=1 | root_count=3 | mode=full
- 7 | analysis.py | cc=7 | depth=1 | root_count=3 | mode=full
- 8 | render.py | cc=17 | depth=1 | root_count=3 | mode=full
- 9 | discovery.py | cc=10 | depth=1 | root_count=3 | mode=full
- 10 | api.py | cc=16 | depth=0 | root_count=3 | mode=full
- 11 | __init__.py | cc=0 | depth=0 | root_count=2 | mode=full
- 12 | cli.py | cc=19 | depth=0 | root_count=1 | mode=full
- 13 | __main__.py | cc=0 | depth=unreachable | root_count=0 | mode=full

# Import Dependency Tree
- distillrepo.cli [sloc=364, max_cc=19]
  - distillrepo [sloc=8, max_cc=0]
    - distillrepo.api [sloc=153, max_cc=16]
      - distillrepo.analysis [sloc=226, max_cc=7]
        - distillrepo.models [sloc=139, max_cc=0]
      - distillrepo.discovery [sloc=32, max_cc=10]
        - distillrepo.models (see above) [sloc=139, max_cc=0]
      - distillrepo.enrich [sloc=98, max_cc=15]
        - distillrepo.models (see above) [sloc=139, max_cc=0]
      - distillrepo.graphs [sloc=186, max_cc=14]
        - distillrepo.models (see above) [sloc=139, max_cc=0]
      - distillrepo.ir [sloc=377, max_cc=14]
        - distillrepo.models (see above) [sloc=139, max_cc=0]
      - distillrepo.models (see above) [sloc=139, max_cc=0]
      - distillrepo.ranking [sloc=150, max_cc=20]
        - distillrepo.models (see above) [sloc=139, max_cc=0]
      - distillrepo.render [sloc=308, max_cc=17]
        - distillrepo.analysis (see above) [sloc=226, max_cc=7]
        - distillrepo.models (see above) [sloc=139, max_cc=0]
      - distillrepo.resolution [sloc=128, max_cc=16]
        - distillrepo.models (see above) [sloc=139, max_cc=0]
  - distillrepo.api (see above) [sloc=153, max_cc=16]
  - distillrepo.models (see above) [sloc=139, max_cc=0]

# Call Graph
- distillrepo.cli:main
- distillrepo.cli:main -> warnings.filterwarnings (unresolved)
- distillrepo.cli:main -> distillrepo.cli:distillrepo.cli.build_parser
- distillrepo.cli:main -> distillrepo.cli:distillrepo.cli.main.parser
- distillrepo.cli:main -> distillrepo.cli:distillrepo.cli.main.args
- distillrepo.cli:main -> distillrepo.cli:distillrepo.cli._find_project_root
- distillrepo.cli:main -> distillrepo.cli:distillrepo.cli._load_pyproject
- distillrepo.cli:main -> distillrepo.cli:distillrepo.cli.main.pyproject
- distillrepo.cli:main -> distillrepo.cli:distillrepo.cli._infer_script_target
- distillrepo.cli:main -> distillrepo.cli:distillrepo.cli._infer_package_root
- distillrepo.cli:main -> distillrepo.cli:distillrepo.cli._infer_entry_point_module
- distillrepo.cli:main -> distillrepo.cli:distillrepo.cli._infer_entry_point_function
- distillrepo.cli:main -> distillrepo.cli:distillrepo.cli._date_label
- distillrepo.cli:main -> distillrepo.models:distillrepo.models.Config
- distillrepo.cli:main -> distillrepo.api:distillrepo.api.write_outputs
- distillrepo.cli:main -> distillrepo.cli:distillrepo.cli._print_summary
- distillrepo.cli:main -> distillrepo.cli:distillrepo.cli.main.bundle_path

# Complexity Hotspots
- distillrepo.api:derive_root_modules | score=18.1 | cc=16
- distillrepo.api:analyze | score=16.2 | cc=10
- distillrepo.cli:_infer_package_root | score=16.0 | cc=19
- distillrepo.cli:main | score=14.3 | cc=13
- distillrepo.resolution:resolve_calls | score=13.9 | cc=16
- distillrepo.ranking:_mode_for_rank | score=12.8 | cc=20
- distillrepo.graphs:compute_reachability | score=12.3 | cc=14
- distillrepo.render:_summary_lines | score=12.2 | cc=17
- distillrepo.enrich:apply_radon_metrics | score=12.2 | cc=15
- distillrepo.api:write_outputs | score=12.2 | cc=4
- distillrepo.api:classify_root_modules | score=12.2 | cc=6
- distillrepo.render:render_bundle | score=12.1 | cc=11

# Circular Dependencies
- none

# Key Observations
- Highest fan-in module: distillrepo.models (10).
- Highest complexity module: distillrepo.ranking (20 in _mode_for_rank).
- Lowest maintainability module: distillrepo.render (12.7).
- Not reached from root set: distillrepo.__main__.
- Top hotspot: distillrepo.api:derive_root_modules (score=18.1, cc=16).

# Source Material
# FILE: models.py
# MODE: full
# WHY IMPORTANT: called from entry, high fan-in, reachable from entry, review root coverage, shared across roots

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass(slots=True)
class CallSite:
    raw_name: str
    lineno: int
    col_offset: int
    end_lineno: int | None = None
    end_col_offset: int | None = None
    expr_text: str | None = None


@dataclass(slots=True)
class ResolvedCall:
    source_raw_name: str
    target_module_path: str | None
    target_qualified_name: str | None
    resolution_kind: str
    confidence: float


@dataclass(slots=True)
class FunctionInfo:
    name: str
    qualified_name: str
    file_path: Path
    module_path: str
    lineno: int
    end_lineno: int
    is_method: bool
    class_name: str | None
    docstring: str | None
    decorators: list[str] = field(default_factory=list)
    is_async: bool = False
    raw_calls: list[str] = field(default_factory=list)
    call_sites: list[CallSite] = field(default_factory=list)
    resolved_calls: list[ResolvedCall] = field(default_factory=list)
    cyclomatic_complexity: int = 1
    hotspot_score: float = 0.0
    signature_text: str | None = None


@dataclass(slots=True)
class UnusedCandidate:
    name: str
    typ: str
    path: str
    first_lineno: int
    last_lineno: int | None
    size: int | None
    confidence: int | None
    message: str | None
    module_path: str | None = None
    qualified_name: str | None = None
    symbol_id: str | None = None


@dataclass(slots=True)
class FileInfo:
    path: Path
    relative_path: str
    module_path: str
    source: str
    cleaned_source: str
    lines: int
    sloc: int
    module_docstring: str | None
    classes: list[str] = field(default_factory=list)
    functions: dict[str, FunctionInfo] = field(default_factory=dict)
    imports: list[str] = field(default_factory=list)
    imported_by: list[str] = field(default_factory=list)
    import_bindings: dict[str, str] = field(default_factory=dict)
    class_bases: dict[str, list[str]] = field(default_factory=dict)
    avg_complexity: float = 0.0
    max_complexity: int = 0
    max_complexity_func: str = ""
    maintainability_index: float = 100.0
    fan_in: int = 0
    fan_out: int = 0
    depth_from_entry: int = -1
    reached_by_roots: list[str] = field(default_factory=list)
    importance_score: float = 0.0
    inclusion_mode: str = "full"
    estimated_tokens: int = 0
    why_important: list[str] = field(default_factory=list)
    parse_error: str | None = None


@dataclass(slots=True)
class Config:
    package_root: Path
    package_name: str
    entry_point_module: str
    entry_point_function: str | None
    output_path: Path | None = None
    write_ir: bool = True
    review_mode: str = "review"
    call_graph_depth: int = 4
    complexity_hotspot_threshold: int = 10
    use_jedi: bool = True
    use_radon: bool = True
    use_vulture: bool = True
    exclude_dirs: set[str] = field(
        default_factory=lambda: {
            "__pycache__",
            ".git",
            ".venv",
            "venv",
            "build",
            "dist",
            ".distillrepo",
            ".mypy_cache",
            ".pytest_cache",
        }
    )
    exclude_globs: list[str] = field(default_factory=list)
    exclude_regexes: list[str] = field(default_factory=list)
    include_tests: bool = False
    max_tokens: int | None = None
    max_chars: int | None = None
    max_lines: int | None = None
    max_files: int | None = None
    include_unreachable: bool = True
    output_format: str = "py"
    header_strip_pattern: str = r"^\s*#\s*=+\s*FILE:.*$"
    analysis_kind: str = "application"


@dataclass(slots=True)
class AnalysisResult:
    config: Config
    files: dict[str, FileInfo]
    import_graph: dict[str, list[str]]
    call_graph_lines: list[str]
    import_tree_lines: list[str]
    cycles: list[list[str]]
    ordered_modules: list[str]
    root_modules: list[str]
    root_kinds: dict[str, str]
    root_reachability: dict[str, int]
    hotspots: list[FunctionInfo]
    observations: list[str]
    total_lines: int
    total_sloc: int
    reachable_count: int
    unreachable_count: int
    warnings: list[str] = field(default_factory=list)
    original_tokens: int = 0
    bundle_tokens: int = 0
    unused_candidates: list[UnusedCandidate] = field(default_factory=list)

# FILE: ir.py
# MODE: full
# WHY IMPORTANT: complexity hotspot, reachable from entry, review root coverage, shared across roots

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from .models import AnalysisResult, FileInfo, FunctionInfo


def write_ir_bundle(result: AnalysisResult, bundle_path: Path, ir_dir: Path) -> dict[str, Path]:
    ir_dir.mkdir(parents=True, exist_ok=True)
    original_tokens = result.original_tokens
    bundle_tokens = result.bundle_tokens
    saved_tokens = max(0, original_tokens - bundle_tokens)
    saved_percent = (saved_tokens / original_tokens * 100.0) if original_tokens else 0.0
    retained_percent = (bundle_tokens / original_tokens * 100.0) if original_tokens else 0.0
    compression_ratio = (original_tokens / bundle_tokens) if bundle_tokens else 0.0
    artifacts = {
        "summary": ir_dir / "repo_summary.md",
        "modules": ir_dir / "modules.json",
        "symbols": ir_dir / "symbols.json",
        "relationships": ir_dir / "relationships.json",
        "entrypoints": ir_dir / "entrypoints.json",
        "chunks": ir_dir / "chunks.json",
        "hotspots": ir_dir / "hotspots.json",
        "unused_candidates": ir_dir / "unused_candidates.json",
    }

    _write_json(artifacts["modules"], _modules_payload(result))
    _write_json(artifacts["symbols"], _symbols_payload(result))
    _write_json(artifacts["relationships"], _relationships_payload(result))
    _write_json(artifacts["entrypoints"], _entrypoints_payload(result))
    _write_json(artifacts["chunks"], _chunks_payload(result))
    _write_json(artifacts["hotspots"], _hotspots_payload(result))
    _write_json(artifacts["unused_candidates"], _unused_candidates_payload(result))
    artifacts["summary"].write_text(_repo_summary_markdown(result), encoding="utf-8")

    manifest_path = ir_dir / "manifest.json"
    manifest = {
        "format_version": "0.1",
        "repo_name": result.config.package_name,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "languages": ["python"],
        "entrypoints": ["entrypoints.json"],
        "bundle": bundle_path.name,
        "artifacts": {key: path.name for key, path in artifacts.items()},
        "stats": {
            "files_analyzed": len(result.files),
            "symbols": sum(len(file_info.functions) for file_info in result.files.values()),
            "modules": len(result.files),
            "reached_from_roots": result.reachable_count,
            "not_reached_from_roots": result.unreachable_count,
            "cycles": len(result.cycles),
            "unused_candidates": len(result.unused_candidates),
            "original_tokens_estimate": original_tokens,
            "bundle_tokens_estimate": bundle_tokens,
            "saved_tokens_estimate": saved_tokens,
            "saved_percent_estimate": round(saved_percent, 1),
            "retained_percent_estimate": round(retained_percent, 1),
            "compression_ratio_estimate": round(compression_ratio, 1) if compression_ratio else 0.0,
        },
        "analysis": {
            "analysis_kind": result.config.analysis_kind,
            "root_modules": result.root_modules,
            "root_kinds": result.root_kinds,
            "root_reachability": result.root_reachability,
            "entry_point_module": result.config.entry_point_module,
            "entry_point_function": result.config.entry_point_function,
            "review_mode": result.config.review_mode,
            "enabled_enrichers": {
                "jedi": result.config.use_jedi,
                "radon": result.config.use_radon,
                "vulture": result.config.use_vulture,
            },
            "heuristic_outputs": [
                "hotspots",
                "importance_score",
                "not_reached_from_roots",
                "unused_candidates",
            ],
            "known_limits": [
                "dynamic imports may be underrepresented",
                "lazy exports may be underrepresented",
                "plugin registration may be underrepresented",
                "runtime-only behavior is not executed",
                "token counts are heuristic estimates based on text length, not model-specific tokenization",
            ],
        },
    }
    _write_json(manifest_path, manifest)
    artifacts["manifest"] = manifest_path
    return artifacts


def _repo_summary_markdown(result: AnalysisResult) -> str:
    original_tokens = result.original_tokens
    bundle_tokens = result.bundle_tokens
    saved_tokens = max(0, original_tokens - bundle_tokens)
    saved_percent = (saved_tokens / original_tokens * 100.0) if original_tokens else 0.0
    retained_percent = (bundle_tokens / original_tokens * 100.0) if original_tokens else 0.0
    compression_ratio = (original_tokens / bundle_tokens) if bundle_tokens else 0.0
    lines = [
        "# Repository Summary",
        "",
        "## Purpose",
        f"{result.config.package_name} analyzed by distillrepo.",
        "",
        "## Review Guidance",
        "- Static-analysis-derived artifact optimized for review and navigation.",
        "- Treat signatures, paths, spans, and extracted relationships as high-confidence facts.",
        "- Treat hotspots, not-reached-from-roots, and unused candidates as heuristics.",
        "- Dynamic imports, lazy exports, and plugin registration may be underrepresented.",
        "- Token counts are heuristic estimates based on text length, not model-specific tokenization.",
        "",
        "## Run Summary",
        f"- Files analyzed: {len(result.files)}",
        f"- Symbols discovered: {sum(len(file_info.functions) for file_info in result.files.values())}",
        f"- Modules analyzed: {len(result.files)}",
        f"- Reached from roots / not reached: {result.reachable_count} / {result.unreachable_count}",
        f"- Import cycles: {len(result.cycles)}",
        f"- Possible unused symbols: {len(result.unused_candidates)}",
        f"- Original size (estimated tokens): {original_tokens:,}",
        f"- Distilled size (estimated tokens): {bundle_tokens:,}",
        f"- Saved (estimated tokens): {saved_tokens:,} ({saved_percent:.1f}%)",
        f"- Retained estimated tokens: {retained_percent:.1f}%",
        f"- Compression ratio: {compression_ratio:.1f}x" if compression_ratio else "- Compression ratio: n/a",
    ]
    lines.extend([
        "",
        "## Analysis mode",
        f"- `{result.config.analysis_kind}`",
        "",
        "## Root modules",
    ])
    for root in result.root_modules[:10]:
        kind = result.root_kinds.get(root, "root")
        coverage = result.root_reachability.get(root, 0)
        lines.append(f"- `{root}` ({kind}, reaches {coverage} modules)")
    if result.config.entry_point_function:
        lines.extend(
            [
                "",
                "## Key entrypoint",
                f"- `{result.config.package_name}.{_module_stem(result.config.entry_point_module)}:{result.config.entry_point_function}`",
            ]
        )
    lines.extend(["", "## Main modules"])
    for file_info in _top_modules(result, limit=6):
        lines.append(
            f"- `{file_info.module_path}`: score={file_info.importance_score:.2f}, "
            f"fan-in={file_info.fan_in}, max_cc={file_info.max_complexity}"
        )
    lines.extend(
        [
            "",
            "## High-complexity areas",
        ]
    )
    for hotspot in result.hotspots[:5]:
        lines.append(f"- `{hotspot.module_path}:{hotspot.qualified_name}` (cc={hotspot.cyclomatic_complexity})")
    if result.observations:
        lines.extend(["", "## Observations"])
        for observation in result.observations[:6]:
            lines.append(f"- {observation}")
    if result.unused_candidates:
        lines.extend(["", "## Possible Unused Symbols"])
        for candidate in result.unused_candidates[:6]:
            location = f"{Path(candidate.path).name}:{candidate.first_lineno}"
            lines.append(f"- `{candidate.name}` ({candidate.typ}, confidence={candidate.confidence}) at {location}")
    return "\n".join(lines).rstrip() + "\n"


def _modules_payload(result: AnalysisResult) -> list[dict]:
    payload = []
    for module_path in result.ordered_modules:
        file_info = result.files[module_path]
        payload.append(
            {
                "id": f"module:{module_path}",
                "path": file_info.relative_path,
                "kind": "module",
                "exports": sorted(_exported_symbols(file_info)),
                "imports": sorted(f"module:{item}" for item in file_info.imports),
                "tags": _module_tags(file_info, result),
                "loc": file_info.lines,
                "sloc": file_info.sloc,
                "complexity": file_info.max_complexity,
                "fan_in": file_info.fan_in,
                "fan_out": file_info.fan_out,
                "depth": file_info.depth_from_entry,
                "reached_by_roots": file_info.reached_by_roots,
                "root_count": len(file_info.reached_by_roots),
                "importance_score": file_info.importance_score,
                "inclusion_mode": file_info.inclusion_mode,
            }
        )
    return payload


def _symbols_payload(result: AnalysisResult) -> list[dict]:
    unused_ids = {candidate.symbol_id for candidate in result.unused_candidates if candidate.symbol_id}
    called_by_index = _build_called_by_index(result)
    payload: list[dict] = []
    for module_path in result.ordered_modules:
        file_info = result.files[module_path]
        for function in sorted(file_info.functions.values(), key=lambda item: (item.lineno, item.qualified_name)):
            symbol_id = _symbol_id(function)
            payload.append(
                {
                    "id": symbol_id,
                    "qualified_name": f"{function.module_path}.{function.qualified_name}",
                    "kind": "method" if function.is_method else "function",
                    "path": file_info.relative_path,
                    "span": {"start": function.lineno, "end": function.end_lineno},
                    "signature": function.signature_text,
                    "doc": _short_text(function.docstring),
                    "tags": _function_tags(function, result, symbol_id in unused_ids),
                    "root_count": len(file_info.reached_by_roots),
                    "reached_by_roots": file_info.reached_by_roots,
                    "calls": [
                        _resolved_symbol_ref(resolved.target_module_path, resolved.target_qualified_name)
                        for resolved in function.resolved_calls
                        if resolved.target_module_path and resolved.target_qualified_name
                    ],
                    "called_by": sorted(called_by_index.get(symbol_id, [])),
                }
            )
    return payload


def _relationships_payload(result: AnalysisResult) -> dict[str, list[dict]]:
    edges: list[dict] = []
    for module_path, file_info in result.files.items():
        for dep in file_info.imports:
            edges.append({"type": "imports", "from": f"module:{module_path}", "to": f"module:{dep}"})
        for function in file_info.functions.values():
            edges.append({"type": "defines", "from": f"module:{module_path}", "to": _symbol_id(function)})
            for resolved in function.resolved_calls:
                if resolved.target_module_path and resolved.target_qualified_name:
                    edges.append(
                        {
                            "type": "calls",
                            "from": _symbol_id(function),
                            "to": _resolved_symbol_ref(resolved.target_module_path, resolved.target_qualified_name),
                            "resolution_kind": resolved.resolution_kind,
                            "confidence": resolved.confidence,
                        }
                    )
    return {"edges": edges}


def _entrypoints_payload(result: AnalysisResult) -> list[dict]:
    if not result.config.entry_point_function:
        return [
            {
                "id": f"module:{root}",
                "kind": result.root_kinds.get(root, "library_root"),
                "reason": "Derived from review root set",
                "module_path": root,
                "coverage": result.root_reachability.get(root, 0),
                "coverage_ratio": round(result.root_reachability.get(root, 0) / max(1, len(result.files)), 3),
            }
            for root in result.root_modules
        ]
    return [
        {
            "id": f"symbol:{result.config.package_name}.{_module_stem(result.config.entry_point_module)}.{result.config.entry_point_function}",
            "kind": result.root_kinds.get(result.root_modules[0], "cli_entrypoint"),
            "reason": "Configured or inferred entrypoint within review root set",
            "module_path": result.config.entry_point_module,
            "function": result.config.entry_point_function,
            "coverage": result.root_reachability.get(result.root_modules[0], 0) if result.root_modules else 0,
            "coverage_ratio": round(
                (result.root_reachability.get(result.root_modules[0], 0) if result.root_modules else 0)
                / max(1, len(result.files)),
                3,
            ),
        }
    ]


def _chunks_payload(result: AnalysisResult) -> list[dict]:
    chunks: list[dict] = []
    for index, file_info in enumerate(_top_modules(result, limit=8), start=1):
        members = [_symbol_id(function) for function in _top_functions(file_info, limit=6)]
        chunks.append(
            {
                "chunk_id": f"chunk:{file_info.module_path}",
                "kind": "module_summary",
                "tokens_estimate": file_info.estimated_tokens,
                "members": members,
                "summary": _chunk_summary(file_info),
                "rank": index,
            }
        )
    return chunks


def _hotspots_payload(result: AnalysisResult) -> list[dict]:
    payload = []
    for hotspot in result.hotspots[:20]:
        payload.append(
            {
                "target": _symbol_id(hotspot),
                "score": round(min(1.0, hotspot.cyclomatic_complexity / max(1, result.config.complexity_hotspot_threshold * 2)), 2),
                "reasons": ["high complexity"],
                "complexity": hotspot.cyclomatic_complexity,
                "path": next(file_info.relative_path for file_info in result.files.values() if file_info.module_path == hotspot.module_path),
            }
        )
    return payload


def _unused_candidates_payload(result: AnalysisResult) -> list[dict]:
    return [
        {
            "name": candidate.name,
            "type": candidate.typ,
            "path": candidate.path,
            "first_lineno": candidate.first_lineno,
            "last_lineno": candidate.last_lineno,
            "size": candidate.size,
            "confidence": candidate.confidence,
            "message": candidate.message,
            "module_path": candidate.module_path,
            "qualified_name": candidate.qualified_name,
            "symbol_id": candidate.symbol_id,
        }
        for candidate in result.unused_candidates
    ]


def _write_json(path: Path, payload: object) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _module_tags(file_info: FileInfo, result: AnalysisResult) -> list[str]:
    tags: list[str] = []
    if file_info.module_path in result.root_modules:
        tags.append("entrypoint")
    if file_info.depth_from_entry >= 0:
        tags.append("reachable")
    if file_info.fan_in >= 3:
        tags.append("dependency_hub")
    if file_info.max_complexity >= result.config.complexity_hotspot_threshold:
        tags.append("hotspot")
    return tags


def _function_tags(function: FunctionInfo, result: AnalysisResult, possibly_unused: bool) -> list[str]:
    tags: list[str] = []
    if result.config.entry_point_function and function.module_path == f"{result.config.package_name}.{_module_stem(result.config.entry_point_module)}" and (
        function.qualified_name == result.config.entry_point_function or function.name == result.config.entry_point_function
    ):
        tags.append("entrypoint")
    if function.cyclomatic_complexity >= result.config.complexity_hotspot_threshold:
        tags.append("hotspot")
    if not function.is_method:
        tags.append("module_api")
    if possibly_unused:
        tags.append("unused_candidate")
    return tags


def _build_called_by_index(result: AnalysisResult) -> dict[str, list[str]]:
    """Build reverse call index for IR payloads.

    This avoids an O(symbols^2) scan when populating `called_by`.
    """
    index: dict[str, set[str]] = {}
    for file_info in result.files.values():
        for function in file_info.functions.values():
            caller_id = _symbol_id(function)
            for resolved in function.resolved_calls:
                if not (resolved.target_module_path and resolved.target_qualified_name):
                    continue
                target_id = _resolved_symbol_ref(resolved.target_module_path, resolved.target_qualified_name)
                index.setdefault(target_id, set()).add(caller_id)
    return {target_id: sorted(callers) for target_id, callers in index.items()}


def _resolved_symbol_ref(module_path: str, qualified_name: str) -> str:
    return f"symbol:{module_path}.{qualified_name}"


def _symbol_id(function: FunctionInfo) -> str:
    return f"symbol:{function.module_path}.{function.qualified_name}"


def _exported_symbols(file_info: FileInfo) -> list[str]:
    return [f"{file_info.module_path}.{function.qualified_name}" for function in file_info.functions.values() if not function.name.startswith("_")]


def _top_modules(result: AnalysisResult, limit: int) -> list[FileInfo]:
    modules = [result.files[module_path] for module_path in result.ordered_modules]
    return sorted(modules, key=lambda item: (-item.importance_score, item.module_path))[:limit]


def _top_functions(file_info: FileInfo, limit: int) -> list[FunctionInfo]:
    return sorted(
        file_info.functions.values(),
        key=lambda item: (-item.cyclomatic_complexity, item.lineno, item.qualified_name),
    )[:limit]


def _chunk_summary(file_info: FileInfo) -> str:
    return (
        f"{file_info.module_path} with fan-in {file_info.fan_in}, "
        f"fan-out {file_info.fan_out}, max complexity {file_info.max_complexity}."
    )


def _module_stem(relative_module_path: str) -> str:
    path = Path(relative_module_path)
    return "__init__" if path.name == "__init__.py" else path.stem


def _short_text(text: str | None, limit: int = 160) -> str | None:
    if not text:
        return None
    single_line = " ".join(text.strip().splitlines())
    if len(single_line) <= limit:
        return single_line
    return single_line[: limit - 3].rstrip() + "..."

# FILE: ranking.py
# MODE: full
# WHY IMPORTANT: complexity hotspot, reachable from entry, review root coverage, shared across roots

from __future__ import annotations

from .models import Config, FileInfo, FunctionInfo


def score_files(files: dict[str, FileInfo], cycles: list[list[str]], entry_module: str, entry_function: str | None) -> None:
    cycle_members = {member for cycle in cycles for member in cycle}
    entry_targets = _entry_call_targets(files, entry_module, entry_function)
    for module_path, file_info in files.items():
        score = 0.0
        reasons: list[str] = []
        if module_path == entry_module:
            score += 8
            reasons.append("entry module")
        if file_info.depth_from_entry >= 0:
            score += 5
            if file_info.depth_from_entry == 0:
                reasons.append("entry path")
            else:
                score += max(0.0, 3.5 - file_info.depth_from_entry)
                reasons.append("reachable from entry")
        if module_path in cycle_members:
            score += 2.5
            reasons.append("participates in cycle")
        if module_path in entry_targets:
            score += 4
            reasons.append("called from entry")
        root_count = len(file_info.reached_by_roots)
        if root_count:
            score += min(root_count * 1.8, 7)
            reasons.append("review root coverage")
        if root_count >= 2:
            score += min((root_count - 1) * 1.4, 4)
            reasons.append("shared across roots")
        score += min(file_info.fan_in * 1.5, 8)
        score += min(file_info.max_complexity * 0.7, 10)
        score += min(file_info.sloc / 120, 4)
        score += max(0.0, (70 - file_info.maintainability_index) / 12)
        if file_info.fan_in >= 3:
            reasons.append("high fan-in")
        if file_info.max_complexity >= 10:
            reasons.append("complexity hotspot")
        file_info.importance_score = round(score, 2)
        file_info.why_important = sorted(dict.fromkeys(reasons))


def collect_hotspots(files: dict[str, FileInfo], threshold: int) -> list[FunctionInfo]:
    hotspots: list[FunctionInfo] = []
    for file_info in files.values():
        for function in file_info.functions.values():
            function.hotspot_score = _hotspot_score(file_info, function)
            if function.hotspot_score >= threshold:
                hotspots.append(function)
    hotspots.sort(key=lambda item: (-item.hotspot_score, -item.cyclomatic_complexity, item.module_path, item.qualified_name))
    return hotspots


def assign_inclusion_modes(files: dict[str, FileInfo], ordered_modules: list[str], config: Config) -> None:
    for index, module_path in enumerate(ordered_modules):
        file_info = files[module_path]
        if not config.include_unreachable and file_info.depth_from_entry < 0:
            file_info.inclusion_mode = "excluded"
            continue
        file_info.inclusion_mode = _mode_for_rank(index, file_info, config)


def _mode_for_rank(index: int, file_info: FileInfo, config: Config) -> str:
    if config.review_mode in {"concat", "plain_concat"}:
        return "full"
    if config.review_mode == "review":
        if file_info.depth_from_entry < 0:
            return "signature"
        if index < 2 or (len(file_info.reached_by_roots) >= 2 and index < 3):
            return "full"
        if index < 5:
            return "summary"
        if index < 10:
            return "signature"
        return "excluded"
    if config.review_mode == "architecture":
        return "summary" if index < 5 else "signature"
    if config.review_mode == "hotspots":
        return "full" if _file_has_hotspot(file_info, config.complexity_hotspot_threshold) else "summary"
    if config.review_mode == "entrypath":
        if file_info.depth_from_entry < 0:
            return "signature"
        return "full" if file_info.depth_from_entry <= 1 else "summary"
    if config.review_mode == "budgeted":
        if file_info.depth_from_entry < 0:
            return "excluded"
        if index < 2:
            return "summary"
        if index < 6:
            return "signature"
        return "excluded"
    return "full"


def generate_observations(files: dict[str, FileInfo], cycles: list[list[str]], hotspots: list[FunctionInfo]) -> list[str]:
    observations: list[str] = []
    if not files:
        return observations
    most_imported = max(files.values(), key=lambda item: (item.fan_in, item.module_path))
    observations.append(f"Highest fan-in module: {most_imported.module_path} ({most_imported.fan_in}).")
    most_complex = max(files.values(), key=lambda item: (item.max_complexity, item.module_path))
    observations.append(
        f"Highest complexity module: {most_complex.module_path} ({most_complex.max_complexity} in {most_complex.max_complexity_func or 'n/a'})."
    )
    lowest_mi = min(files.values(), key=lambda item: (item.maintainability_index, item.module_path))
    observations.append(f"Lowest maintainability module: {lowest_mi.module_path} ({lowest_mi.maintainability_index:.1f}).")
    unreachable = sorted(file_info.module_path for file_info in files.values() if file_info.depth_from_entry < 0)
    if unreachable:
        observations.append(f"Not reached from root set: {', '.join(unreachable[:6])}.")
    if cycles:
        observations.append(f"Import cycles detected: {len(cycles)}.")
    if hotspots:
        top = hotspots[0]
        observations.append(
            f"Top hotspot: {top.module_path}:{top.qualified_name} "
            f"(score={top.hotspot_score:.1f}, cc={top.cyclomatic_complexity})."
        )
    return observations


def _entry_call_targets(files: dict[str, FileInfo], entry_module: str, entry_function: str | None) -> set[str]:
    if not entry_function:
        return set()
    file_info = files.get(entry_module)
    if file_info is None:
        return set()
    entry = file_info.functions.get(entry_function)
    if entry is None:
        for function in file_info.functions.values():
            if function.name == entry_function:
                entry = function
                break
    if entry is None:
        return set()
    return {resolved.target_module_path for resolved in entry.resolved_calls if resolved.target_module_path is not None}


def _hotspot_score(file_info: FileInfo, function: FunctionInfo) -> float:
    score = 0.0
    score += function.cyclomatic_complexity * 0.45
    score += min(file_info.fan_in, 8) * 0.9
    score += min(file_info.fan_out, 8) * 0.35
    score += min(len(function.resolved_calls), 10) * 0.25
    score += max(0, 3 - max(file_info.depth_from_entry, 0)) * 1.0 if file_info.depth_from_entry >= 0 else 0.0
    score += 1.0 if not function.name.startswith("_") else 0.0
    score += 0.6 if function.docstring else 0.0
    if _is_parser_boilerplate(function):
        score *= 0.45
    if function.name in {"__init__", "__repr__", "__str__"}:
        score *= 0.65
    return round(score, 2)


def _is_parser_boilerplate(function: FunctionInfo) -> bool:
    lowered_name = function.name.lower()
    parserish_names = {"parse_args", "parse_common_args", "build_parser", "get_parser", "cli_parser"}
    if lowered_name in parserish_names:
        return True
    raw_calls = " ".join(function.raw_calls).lower()
    parserish_markers = ("add_argument", "add_parser", "set_defaults", "argumentparser", "parse_args")
    return sum(marker in raw_calls for marker in parserish_markers) >= 2


def _file_has_hotspot(file_info: FileInfo, threshold: int) -> bool:
    return any(function.hotspot_score >= threshold for function in file_info.functions.values())

# FILE: graphs.py
# MODE: full
# WHY IMPORTANT: complexity hotspot, reachable from entry, review root coverage, shared across roots

from __future__ import annotations

from collections import deque

from .models import FileInfo, FunctionInfo


def build_import_graph(files: dict[str, FileInfo]) -> dict[str, list[str]]:
    graph: dict[str, list[str]] = {}
    for module_path, file_info in files.items():
        graph[module_path] = sorted(dict.fromkeys(file_info.imports))
    for module_path, deps in graph.items():
        for dep in deps:
            if dep in files:
                files[dep].imported_by.append(module_path)
    for file_info in files.values():
        file_info.imported_by.sort()
        file_info.fan_in = len(file_info.imported_by)
        file_info.fan_out = len(file_info.imports)
    return graph


def detect_cycles(graph: dict[str, list[str]]) -> list[list[str]]:
    index = 0
    stack: list[str] = []
    on_stack: set[str] = set()
    indices: dict[str, int] = {}
    lowlinks: dict[str, int] = {}
    cycles: list[list[str]] = []

    def strong_connect(node: str) -> None:
        nonlocal index
        indices[node] = index
        lowlinks[node] = index
        index += 1
        stack.append(node)
        on_stack.add(node)
        for neighbor in graph.get(node, []):
            if neighbor not in indices:
                strong_connect(neighbor)
                lowlinks[node] = min(lowlinks[node], lowlinks[neighbor])
            elif neighbor in on_stack:
                lowlinks[node] = min(lowlinks[node], indices[neighbor])
        if lowlinks[node] == indices[node]:
            component: list[str] = []
            while stack:
                popped = stack.pop()
                on_stack.remove(popped)
                component.append(popped)
                if popped == node:
                    break
            component.sort()
            if len(component) > 1:
                cycles.append(component)

    for node in sorted(graph):
        if node not in indices:
            strong_connect(node)
    cycles.sort()
    return cycles


def compute_reachability(
    files: dict[str, FileInfo], graph: dict[str, list[str]], root_modules: list[str]
) -> tuple[int, int, dict[str, int]]:
    for file_info in files.values():
        file_info.depth_from_entry = -1
        file_info.reached_by_roots = []
    roots = [module for module in root_modules if module in files]
    if not roots:
        return 0, len(files), {}
    root_reachability: dict[str, int] = {}
    visited_any: set[str] = set()
    for root in roots:
        queue: deque[tuple[str, int]] = deque([(root, 0)])
        visited = {root}
        root_reachability[root] = 0
        while queue:
            node, depth = queue.popleft()
            file_info = files[node]
            if root not in file_info.reached_by_roots:
                file_info.reached_by_roots.append(root)
            if file_info.depth_from_entry < 0 or depth < file_info.depth_from_entry:
                file_info.depth_from_entry = depth
            if node not in visited_any:
                visited_any.add(node)
            root_reachability[root] += 1
            for neighbor in graph.get(node, []):
                if neighbor in visited:
                    continue
                visited.add(neighbor)
                queue.append((neighbor, depth + 1))
    for file_info in files.values():
        file_info.reached_by_roots.sort()
    reachable = len(visited_any)
    return reachable, len(files) - reachable, root_reachability


def order_modules(files: dict[str, FileInfo], graph: dict[str, list[str]]) -> list[str]:
    reverse: dict[str, set[str]] = {node: set() for node in graph}
    indegree: dict[str, int] = {node: 0 for node in graph}
    for node, deps in graph.items():
        for dep in deps:
            reverse.setdefault(dep, set()).add(node)
            indegree[node] += 1
    ready = sorted((node for node, count in indegree.items() if count == 0), key=lambda item: (-files[item].importance_score, item))
    ordered: list[str] = []
    while ready:
        node = ready.pop(0)
        ordered.append(node)
        for dependent in sorted(reverse.get(node, [])):
            indegree[dependent] -= 1
            if indegree[dependent] == 0:
                ready.append(dependent)
        ready.sort(key=lambda item: (-files[item].importance_score, item))
    remainder = sorted((node for node in graph if node not in ordered), key=lambda item: (-files[item].importance_score, item))
    ordered.extend(remainder)
    return ordered


def render_import_tree(graph: dict[str, list[str]], files: dict[str, FileInfo], entry_module: str) -> list[str]:
    if entry_module not in graph:
        return [f"- missing entry module: {entry_module}"]
    lines: list[str] = []
    visited: set[str] = set()

    def walk(node: str, depth: int, path: set[str]) -> None:
        file_info = files[node]
        prefix = "  " * depth
        suffix = f" [sloc={file_info.sloc}, max_cc={file_info.max_complexity}]"
        if node in path:
            lines.append(f"{prefix}- {node} (cycle)")
            return
        if node in visited and depth > 0:
            lines.append(f"{prefix}- {node} (see above){suffix}")
            return
        visited.add(node)
        lines.append(f"{prefix}- {node}{suffix}")
        next_path = set(path)
        next_path.add(node)
        for child in graph.get(node, []):
            walk(child, depth + 1, next_path)

    walk(entry_module, 0, set())
    return lines


def render_import_forest(graph: dict[str, list[str]], files: dict[str, FileInfo], root_modules: list[str]) -> list[str]:
    roots = [module for module in root_modules if module in files]
    if not roots:
        return ["- missing root modules"]
    lines: list[str] = []
    for index, root in enumerate(sorted(dict.fromkeys(roots))):
        if index:
            lines.append("")
        lines.extend(render_import_tree(graph, files, root))
    return lines


def render_call_graph(files: dict[str, FileInfo], entry_module: str, entry_function: str, max_depth: int) -> list[str]:
    if entry_module not in files:
        return [f"- missing entry module: {entry_module}"]
    entry = _locate_entry_function(files[entry_module], entry_function)
    if entry is None:
        return [f"- missing entry function: {entry_function} in {entry_module}"]

    lines: list[str] = []

    def walk(
        module_path: str,
        qualified_name: str,
        depth: int,
        path_set: set[tuple[str, str]],
        chain: list[str],
    ) -> None:
        marker = f"{module_path}:{qualified_name}"
        chain_text = " -> ".join([*chain, marker])
        if (module_path, qualified_name) in path_set:
            lines.append(f"- {chain_text} (cycle)")
            return
        lines.append(f"- {chain_text}")
        if depth >= max_depth:
            return
        function = files[module_path].functions.get(qualified_name)
        if function is None:
            return
        next_path_set = set(path_set)
        next_path_set.add((module_path, qualified_name))
        next_chain = [*chain, marker]
        for resolved in function.resolved_calls:
            if resolved.target_module_path and resolved.target_module_path in files and resolved.target_qualified_name:
                walk(
                    resolved.target_module_path,
                    resolved.target_qualified_name,
                    depth + 1,
                    next_path_set,
                    next_chain,
                )
            else:
                lines.append(f"- {' -> '.join([*next_chain, f'{resolved.source_raw_name} ({resolved.resolution_kind})'])}")

    walk(entry.module_path, entry.qualified_name, 0, set(), [])
    return lines


def _locate_entry_function(file_info: FileInfo, entry_function: str) -> FunctionInfo | None:
    if entry_function in file_info.functions:
        return file_info.functions[entry_function]
    matches = [function for function in file_info.functions.values() if function.name == entry_function]
    matches.sort(key=lambda item: item.qualified_name)
    return matches[0] if matches else None

# FILE: resolution.py
# MODE: full
# WHY IMPORTANT: complexity hotspot, reachable from entry, review root coverage, shared across roots

from __future__ import annotations

from .models import Config, FileInfo, ResolvedCall


def resolve_calls(files: dict[str, FileInfo], config: Config) -> list[str]:
    warnings: list[str] = []
    jedi = _load_jedi(config)
    project = None
    script_by_path: dict[str, object] = {}
    if jedi is not None:
        try:
            project = jedi.Project(path=str(config.package_root.parent))
        except Exception as exc:
            project = None
            warnings.append(f"Jedi project initialization failed; using heuristic call resolution only ({exc.__class__.__name__}).")
    for file_info in files.values():
        script = None
        if jedi is not None and project is not None:
            cache_key = str(file_info.path)
            script = script_by_path.get(cache_key)
            if script is None:
                try:
                    script = jedi.Script(code=file_info.source, path=cache_key, project=project)
                except Exception:
                    script = None
                if script is not None:
                    script_by_path[cache_key] = script
        for function in file_info.functions.values():
            resolved: list[ResolvedCall] = []
            seen: set[tuple[str | None, str | None, str]] = set()
            for call_site in function.call_sites:
                result = None
                if script is not None:
                    result = _resolve_with_jedi(script, call_site.lineno, call_site.col_offset, config)
                if result is None:
                    result = _resolve_heuristic(files, file_info, function.class_name, call_site.raw_name)
                key = (result.target_module_path, result.target_qualified_name, result.resolution_kind)
                if key in seen:
                    continue
                seen.add(key)
                resolved.append(result)
            function.resolved_calls = resolved
    if config.use_jedi and jedi is None:
        warnings.append("Jedi unavailable; using heuristic call resolution only.")
    return warnings


def _load_jedi(config: Config):
    if not config.use_jedi:
        return None
    try:
        import jedi  # type: ignore
    except ImportError:
        return None
    return jedi


def _resolve_with_jedi(script: object, lineno: int, col_offset: int, config: Config) -> ResolvedCall | None:
    try:
        goto = getattr(script, "goto", None)
        if goto is None:
            return None
        names = goto(line=lineno, column=col_offset, follow_imports=True)
    except Exception:
        return None
    for name in names:
        module_path = getattr(name, "module_name", None)
        if not module_path or not module_path.startswith(config.package_name):
            continue
        qualified_name = getattr(name, "full_name", None) or getattr(name, "name", None)
        return ResolvedCall(
            source_raw_name=name.name,
            target_module_path=module_path,
            target_qualified_name=qualified_name,
            resolution_kind="jedi",
            confidence=0.95,
        )
    return None


def _resolve_heuristic(
    files: dict[str, FileInfo], file_info: FileInfo, class_name: str | None, raw_name: str
) -> ResolvedCall:
    if raw_name.startswith("self.") and class_name:
        method_name = raw_name.split(".", 1)[1]
        target_qname = f"{class_name}.{method_name}"
        if target_qname in file_info.functions:
            return ResolvedCall(raw_name, file_info.module_path, target_qname, "self-method", 0.8)

    if "." in raw_name:
        left, right = raw_name.split(".", 1)
        bound = file_info.import_bindings.get(left)
        if bound:
            target_module = _closest_module(files, bound)
            if target_module:
                resolved_qname = _find_target_qualified_name(files, target_module, right)
                return ResolvedCall(raw_name, target_module, resolved_qname or right, "import-binding", 0.72)

    bound = file_info.import_bindings.get(raw_name)
    if bound:
        target_module = _closest_module(files, bound)
        if target_module:
            target_name = bound.rsplit(".", 1)[-1]
            resolved_qname = _find_target_qualified_name(files, target_module, target_name)
            return ResolvedCall(raw_name, target_module, resolved_qname or target_name, "import-binding", 0.7)

    if raw_name in file_info.functions:
        return ResolvedCall(raw_name, file_info.module_path, raw_name, "same-module", 0.68)

    candidate = _find_function_by_simple_name(files, raw_name)
    if candidate is not None:
        return ResolvedCall(raw_name, candidate.module_path, candidate.qualified_name, "same-name-heuristic", 0.42)

    return ResolvedCall(raw_name, None, None, "unresolved", 0.0)


def _closest_module(files: dict[str, FileInfo], target: str) -> str | None:
    candidate = target
    while candidate:
        if candidate in files:
            return candidate
        if "." not in candidate:
            break
        candidate = candidate.rsplit(".", 1)[0]
    return None


def _find_target_qualified_name(files: dict[str, FileInfo], module_path: str, simple_name: str) -> str | None:
    file_info = files.get(module_path)
    if file_info is None:
        return None
    if simple_name in file_info.functions:
        return simple_name
    for qualified_name, function in file_info.functions.items():
        if function.name == simple_name or qualified_name.endswith(f".{simple_name}"):
            return qualified_name
    return None


def _find_function_by_simple_name(files: dict[str, FileInfo], simple_name: str):
    candidates = []
    for file_info in files.values():
        for function in file_info.functions.values():
            if function.name == simple_name:
                candidates.append(function)
    candidates.sort(key=lambda item: (item.module_path, item.qualified_name))
    return candidates[0] if candidates else None

# FILE: enrich.py
# MODE: full
# WHY IMPORTANT: complexity hotspot, reachable from entry, review root coverage, shared across roots

from __future__ import annotations

from pathlib import Path

from .models import Config, FileInfo, UnusedCandidate


def apply_radon_metrics(files: dict[str, FileInfo], config: Config) -> list[str]:
    if not config.use_radon:
        return []
    try:
        from radon.complexity import cc_visit
        from radon.metrics import mi_visit
    except ImportError:
        return ["Radon unavailable; using internal complexity heuristic."]

    for file_info in files.values():
        if file_info.parse_error:
            continue
        try:
            blocks = cc_visit(file_info.source)
        except Exception:
            continue
        complexity_by_name: dict[str, int] = {}
        for block in blocks:
            if getattr(block, "classname", None):
                qualified_name = f"{block.classname}.{block.name}"
            else:
                qualified_name = block.name
            complexity_by_name[qualified_name] = int(block.complexity)
        for qualified_name, function in file_info.functions.items():
            if qualified_name in complexity_by_name:
                function.cyclomatic_complexity = complexity_by_name[qualified_name]
            else:
                fallback = next(
                    (
                        complexity
                        for name, complexity in complexity_by_name.items()
                        if name.endswith(f".{function.name}") or name == function.name
                    ),
                    None,
                )
                if fallback is not None:
                    function.cyclomatic_complexity = fallback
        try:
            file_info.maintainability_index = round(float(mi_visit(file_info.source, multi=True)), 1)
        except Exception:
            pass
        _recompute_file_metrics(file_info)
    return []


def detect_unused_candidates(files: dict[str, FileInfo], config: Config) -> tuple[list[UnusedCandidate], list[str]]:
    if not getattr(config, "use_vulture", True):
        return [], []
    try:
        from vulture import Vulture
    except ImportError:
        return [], ["Vulture unavailable; skipping unused-code candidates."]

    vulture = Vulture(verbose=False)
    try:
        vulture.scavenge([str(file_info.path) for file_info in files.values()])
        raw_items = vulture.get_unused_code()
    except Exception:
        return [], ["Vulture failed; skipping unused-code candidates."]

    path_to_module = {str(file_info.path): file_info.module_path for file_info in files.values()}
    results: list[UnusedCandidate] = []
    for item in raw_items:
        path = str(getattr(item, "filename", ""))
        candidate = UnusedCandidate(
            name=getattr(item, "name", ""),
            typ=getattr(item, "typ", ""),
            path=path,
            first_lineno=int(getattr(item, "first_lineno", 0) or 0),
            last_lineno=getattr(item, "last_lineno", None),
            size=getattr(item, "size", None),
            confidence=getattr(item, "confidence", None),
            message=getattr(item, "message", None),
            module_path=path_to_module.get(path),
        )
        if candidate.module_path and candidate.typ in {"function", "method"}:
            candidate.qualified_name, candidate.symbol_id = _match_symbol(files[candidate.module_path], candidate.name, candidate.first_lineno)
        if _keep_unused_candidate(candidate):
            results.append(candidate)
    results.sort(key=lambda item: (-(item.confidence or 0), item.path, item.first_lineno, item.name))
    return results, []


def _recompute_file_metrics(file_info: FileInfo) -> None:
    complexities = [function.cyclomatic_complexity for function in file_info.functions.values()]
    if complexities:
        file_info.avg_complexity = sum(complexities) / len(complexities)
        file_info.max_complexity = max(complexities)
        for function in sorted(file_info.functions.values(), key=lambda item: (item.lineno, item.qualified_name)):
            if function.cyclomatic_complexity == file_info.max_complexity:
                file_info.max_complexity_func = function.qualified_name
                break


def _match_symbol(file_info: FileInfo, name: str, lineno: int) -> tuple[str | None, str | None]:
    for function in sorted(file_info.functions.values(), key=lambda item: abs(item.lineno - lineno)):
        if function.name == name or function.qualified_name.endswith(f".{name}"):
            qualified_name = function.qualified_name
            return qualified_name, f"symbol:{function.module_path}.{qualified_name}"
    return None, None


def _keep_unused_candidate(candidate: UnusedCandidate) -> bool:
    if candidate.typ not in {"function", "method", "class", "property"}:
        return False
    return (candidate.confidence or 0) >= 60

# FILE: analysis.py
# MODE: full
# WHY IMPORTANT: reachable from entry, review root coverage, shared across roots

from __future__ import annotations

import ast
import importlib.util
import re
from pathlib import Path

from .models import CallSite, Config, FileInfo, FunctionInfo


def analyze_files(paths: list[Path], config: Config) -> dict[str, FileInfo]:
    files: dict[str, FileInfo] = {}
    for path in paths:
        file_info = _analyze_file(path, config)
        files[file_info.module_path] = file_info

    known_modules = set(files)
    for file_info in files.values():
        normalized: set[str] = set()
        for target in file_info.imports:
            module = _normalize_to_known_module(target, known_modules)
            if module is not None:
                normalized.add(module)
        file_info.imports = sorted(normalized)
    return files


def _analyze_file(path: Path, config: Config) -> FileInfo:
    source = path.read_text(encoding="utf-8")
    cleaned_source = clean_source(source, config.header_strip_pattern)
    rel = path.resolve().relative_to(config.package_root.resolve())
    module_path = module_path_for_file(rel, config.package_name)
    file_info = FileInfo(
        path=path.resolve(),
        relative_path=rel.as_posix(),
        module_path=module_path,
        source=source,
        cleaned_source=cleaned_source,
        lines=len(source.splitlines()),
        sloc=count_sloc(source),
        module_docstring=None,
    )

    try:
        tree = ast.parse(source, filename=str(path))
    except SyntaxError as error:
        file_info.parse_error = str(error)
        file_info.estimated_tokens = estimate_tokens(cleaned_source)
        file_info.maintainability_index = 0.0
        return file_info

    file_info.module_docstring = ast.get_docstring(tree)
    visitor = ModuleAnalyzer(file_info)
    visitor.visit(tree)
    compute_basic_metrics(file_info)
    file_info.estimated_tokens = estimate_tokens(cleaned_source)
    return file_info


class ModuleAnalyzer(ast.NodeVisitor):
    def __init__(self, file_info: FileInfo) -> None:
        self.file_info = file_info
        self.module_path = file_info.module_path
        self.class_stack: list[str] = []

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            target = alias.name
            self.file_info.imports.append(target)
            local_name = alias.asname or alias.name.split(".")[0]
            self.file_info.import_bindings[local_name] = target

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        base_module = resolve_import_from(self.module_path, node.level, node.module)
        if base_module:
            self.file_info.imports.append(base_module)
        for alias in node.names:
            if alias.name == "*":
                continue
            if base_module:
                symbol_target = f"{base_module}.{alias.name}"
                self.file_info.import_bindings[alias.asname or alias.name] = symbol_target
                self.file_info.imports.append(symbol_target)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self.file_info.classes.append(node.name)
        self.file_info.class_bases[node.name] = [safe_unparse(base) for base in node.bases]
        self.class_stack.append(node.name)
        for child in node.body:
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                self.visit(child)
        self.class_stack.pop()

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._record_function(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._record_function(node)

    def _record_function(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        class_name = self.class_stack[-1] if self.class_stack else None
        qualified_name = f"{class_name}.{node.name}" if class_name else node.name
        function = FunctionInfo(
            name=node.name,
            qualified_name=qualified_name,
            file_path=self.file_info.path,
            module_path=self.module_path,
            lineno=node.lineno,
            end_lineno=getattr(node, "end_lineno", node.lineno),
            is_method=class_name is not None,
            class_name=class_name,
            docstring=ast.get_docstring(node),
            decorators=[safe_unparse(item) for item in node.decorator_list],
            is_async=isinstance(node, ast.AsyncFunctionDef),
            signature_text=render_signature(node, class_name),
        )
        collector = FunctionCallCollector()
        for child in node.body:
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            collector.visit(child)
        function.call_sites = collector.calls
        function.raw_calls = [call.raw_name for call in collector.calls]
        function.cyclomatic_complexity = estimate_complexity(node)
        self.file_info.functions[qualified_name] = function


class FunctionCallCollector(ast.NodeVisitor):
    def __init__(self) -> None:
        self.calls: list[CallSite] = []

    def visit_Call(self, node: ast.Call) -> None:
        expr = node.func
        self.calls.append(
            CallSite(
                raw_name=call_name(expr),
                lineno=getattr(expr, "lineno", node.lineno),
                col_offset=getattr(expr, "col_offset", node.col_offset),
                end_lineno=getattr(expr, "end_lineno", getattr(node, "end_lineno", None)),
                end_col_offset=getattr(expr, "end_col_offset", getattr(node, "end_col_offset", None)),
                expr_text=safe_unparse(expr),
            )
        )
        self.generic_visit(node)


def module_path_for_file(relative_path: Path, package_name: str) -> str:
    parts = list(relative_path.parts)
    if parts[-1] == "__init__.py":
        module_parts = parts[:-1]
    else:
        module_parts = parts[:-1] + [relative_path.stem]
    return ".".join([package_name, *module_parts]).rstrip(".")


def clean_source(source: str, header_pattern: str) -> str:
    pattern = re.compile(header_pattern)
    lines = source.splitlines()
    index = 0
    while index < len(lines) and pattern.match(lines[index]):
        index += 1
    while index < len(lines) and not lines[index].strip():
        index += 1
    return "\n".join(lines[index:]).strip() + ("\n" if lines[index:] else "")


def count_sloc(source: str) -> int:
    total = 0
    for line in source.splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith("#"):
            total += 1
    return total


def resolve_import_from(module_path: str, level: int, module: str | None) -> str | None:
    if level == 0:
        return module
    package_context = module_path if module_path.endswith("__init__") else module_path.rsplit(".", 1)[0]
    suffix = module or ""
    relative_name = "." * level + suffix
    try:
        return importlib.util.resolve_name(relative_name, package_context)
    except (ImportError, ValueError):
        return None


def _normalize_to_known_module(target: str, known_modules: set[str]) -> str | None:
    candidate = target
    while candidate:
        if candidate in known_modules:
            return candidate
        if "." not in candidate:
            break
        candidate = candidate.rsplit(".", 1)[0]
    return None


def call_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return f"{call_name(node.value)}.{node.attr}"
    return safe_unparse(node)


def safe_unparse(node: ast.AST | None) -> str:
    if node is None:
        return ""
    try:
        return ast.unparse(node)
    except Exception:
        return node.__class__.__name__


def render_signature(node: ast.FunctionDef | ast.AsyncFunctionDef, class_name: str | None) -> str:
    prefix = "async def" if isinstance(node, ast.AsyncFunctionDef) else "def"
    try:
        args_text = ast.unparse(node.args)
    except Exception:
        args_text = "..."
    return_annotation = ""
    if node.returns is not None:
        return_annotation = f" -> {safe_unparse(node.returns)}"
    name = node.name if class_name is None else f"{class_name}.{node.name}"
    return f"{prefix} {name}({args_text}){return_annotation}"


def estimate_complexity(node: ast.AST) -> int:
    complexity = 1
    branch_nodes = (
        ast.If,
        ast.For,
        ast.AsyncFor,
        ast.While,
        ast.With,
        ast.AsyncWith,
        ast.Try,
        ast.ExceptHandler,
        ast.BoolOp,
        ast.IfExp,
        ast.Match,
        ast.comprehension,
    )
    for child in ast.walk(node):
        if isinstance(child, branch_nodes):
            complexity += 1
    return complexity


def compute_basic_metrics(file_info: FileInfo) -> None:
    complexities = [function.cyclomatic_complexity for function in file_info.functions.values()]
    if complexities:
        file_info.avg_complexity = sum(complexities) / len(complexities)
        file_info.max_complexity = max(complexities)
        for function in file_info.functions.values():
            if function.cyclomatic_complexity == file_info.max_complexity:
                file_info.max_complexity_func = function.qualified_name
                break
    size_penalty = min(file_info.sloc / 300, 35)
    complexity_penalty = min(file_info.max_complexity * 2.5, 45)
    file_info.maintainability_index = max(0.0, round(100 - size_penalty - complexity_penalty, 1))


def estimate_tokens(text: str) -> int:
    if not text:
        return 0
    return max(1, len(text) // 4)

# FILE: render.py
# MODE: full
# WHY IMPORTANT: complexity hotspot, reachable from entry, review root coverage, shared across roots

from __future__ import annotations

from .analysis import estimate_tokens
from .models import AnalysisResult, FileInfo, FunctionInfo


def render_bundle(result: AnalysisResult) -> str:
    if result.config.review_mode == "concat":
        rendered = _render_concat_bundle(result)
        result.original_tokens = sum(file_info.estimated_tokens for file_info in result.files.values())
        result.bundle_tokens = estimate_tokens(rendered)
        return rendered
    if result.config.review_mode == "plain_concat":
        rendered = _render_plain_concat_bundle(result)
        result.original_tokens = sum(file_info.estimated_tokens for file_info in result.files.values())
        result.bundle_tokens = estimate_tokens(rendered)
        return rendered
    ordered_files = _apply_budgets(result)
    lines: list[str] = []
    lines.extend(_header_lines(result, ordered_files))
    lines.append("")
    lines.extend(_guidance_lines(result))
    lines.append("")
    lines.extend(_module_inventory_lines(ordered_files))
    lines.append("")
    lines.append("# Import Dependency Tree")
    lines.extend(result.import_tree_lines)
    lines.append("")
    lines.append("# Call Graph")
    lines.extend(result.call_graph_lines)
    lines.append("")
    lines.append("# Complexity Hotspots")
    lines.extend(_hotspot_lines(result.hotspots))
    lines.append("")
    lines.append("# Circular Dependencies")
    lines.extend(_cycle_lines(result.cycles))
    lines.append("")
    lines.append("# Key Observations")
    for observation in result.observations:
        lines.append(f"- {observation}")
    if result.warnings:
        lines.append("")
        lines.append("# Warnings")
        for warning in result.warnings:
            lines.append(f"- {warning}")
    lines.append("")
    lines.append("# Source Material")
    for file_info in ordered_files:
        if file_info.inclusion_mode == "excluded":
            continue
        lines.extend(_file_block(file_info))
        lines.append("")
    rendered = "\n".join(lines).rstrip() + "\n"
    result.original_tokens = sum(file_info.estimated_tokens for file_info in result.files.values())
    result.bundle_tokens = estimate_tokens(rendered)
    return rendered


def _render_concat_bundle(result: AnalysisResult) -> str:
    ordered_files = [result.files[module_path] for module_path in result.ordered_modules]
    lines = [
        "# Distillrepo Concat Bundle",
        f"# Package: {result.config.package_name}",
        "# Mode: concat",
        "# Contents: cleaned source files concatenated after discovery/exclusion rules.",
        "# Notes: lightweight file headers are added; leading generated headers are stripped; blank lines are removed.",
        "",
    ]
    included = 0
    for file_info in ordered_files:
        if file_info.inclusion_mode == "excluded":
            continue
        compact_source = _concat_source(file_info.cleaned_source)
        if not compact_source:
            continue
        included += 1
        lines.append(f"# FILE: {file_info.relative_path}")
        lines.extend(compact_source)
        lines.append("")
    if included == 0:
        lines.append("# No files included.")
    return "\n".join(lines).rstrip() + "\n"


def _render_plain_concat_bundle(result: AnalysisResult) -> str:
    ordered_files = [result.files[module_path] for module_path in result.ordered_modules]
    chunks: list[str] = []
    for file_info in ordered_files:
        if file_info.inclusion_mode == "excluded":
            continue
        compact_source = "\n".join(_concat_source(file_info.cleaned_source)).strip()
        if compact_source:
            chunks.append(compact_source)
    if not chunks:
        return ""
    return "\n".join(chunks).rstrip() + "\n"


def _apply_budgets(result: AnalysisResult) -> list[FileInfo]:
    ordered = [result.files[module_path] for module_path in result.ordered_modules]
    remaining_chars = result.config.max_chars
    remaining_lines = result.config.max_lines
    remaining_tokens = result.config.max_tokens
    remaining_files = result.config.max_files
    for file_info in ordered:
        if file_info.inclusion_mode == "excluded":
            continue
        candidate = _render_file_body(file_info)
        body_text = "\n".join(candidate)
        current_tokens = estimate_tokens(body_text)
        current_lines = len(candidate)
        current_chars = len(body_text)
        while file_info.inclusion_mode in {"full", "summary"} and _exceeds(
            remaining_chars, current_chars, remaining_lines, current_lines, remaining_tokens, current_tokens, remaining_files
        ):
            file_info.inclusion_mode = "summary" if file_info.inclusion_mode == "full" else "signature"
            candidate = _render_file_body(file_info)
            body_text = "\n".join(candidate)
            current_tokens = estimate_tokens(body_text)
            current_lines = len(candidate)
            current_chars = len(body_text)
        if _exceeds(remaining_chars, current_chars, remaining_lines, current_lines, remaining_tokens, current_tokens, remaining_files):
            file_info.inclusion_mode = "excluded"
            continue
        if remaining_chars is not None:
            remaining_chars -= current_chars
        if remaining_lines is not None:
            remaining_lines -= current_lines
        if remaining_tokens is not None:
            remaining_tokens -= current_tokens
        if remaining_files is not None:
            remaining_files -= 1
    return ordered


def _exceeds(
    remaining_chars: int | None,
    current_chars: int,
    remaining_lines: int | None,
    current_lines: int,
    remaining_tokens: int | None,
    current_tokens: int,
    remaining_files: int | None,
) -> bool:
    if remaining_chars is not None and current_chars > remaining_chars:
        return True
    if remaining_lines is not None and current_lines > remaining_lines:
        return True
    if remaining_tokens is not None and current_tokens > remaining_tokens:
        return True
    if remaining_files is not None and remaining_files <= 0:
        return True
    return False


def _header_lines(result: AnalysisResult, ordered_files: list[FileInfo]) -> list[str]:
    original_tokens = sum(file_info.estimated_tokens for file_info in result.files.values())
    bundled_tokens = estimate_tokens(
        "".join("\n".join(_render_file_body(file_info)) for file_info in ordered_files if file_info.inclusion_mode != "excluded")
    )
    compression = f"{(original_tokens / bundled_tokens):.1f}x" if bundled_tokens else "n/a"
    return [
        "# Distillrepo Review Bundle",
        f"# Package: {result.config.package_name}",
        f"# Analysis kind: {result.config.analysis_kind}",
        f"# Roots analyzed: {len(result.root_modules)}",
        f"# Root summary: {_root_coverage_text(result)}",
        f"# Entry point: {_entrypoint_label(result)}",
        f"# Review mode: {result.config.review_mode}",
        f"# Files analyzed: {len(result.files)}",
        f"# Reached from root set / not reached: {result.reachable_count} / {result.unreachable_count}",
        f"# Lines / SLOC: {result.total_lines} / {result.total_sloc}",
        f"# Original repo size (est tokens): {original_tokens}",
        f"# Bundle size (est tokens): {bundled_tokens}",
        f"# Compression: {compression}",
    ]


def _entrypoint_label(result: AnalysisResult) -> str:
    if result.config.entry_point_function:
        return f"{result.config.entry_point_module}:{result.config.entry_point_function}"
    return "n/a (library mode)"


def _guidance_lines(result: AnalysisResult) -> list[str]:
    return [
        "# Review Guidance",
        "# This bundle is a static-analysis-derived review artifact optimized for LLM review and agent navigation.",
        "# Treat file paths, source spans, signatures, imports, and directly extracted symbol relationships as high-confidence facts.",
        "# Treat hotspots, importance scores, not-reached-from-roots results, and unused-code candidates as heuristics.",
        "# Not reached from roots does not mean dead code; dynamic imports, lazy exports, plugin registration, and reflection may be underrepresented.",
        f"# Analysis roots were selected for {result.config.analysis_kind} review and consolidated across {len(result.root_modules)} roots.",
        "# Compressed or omitted files may still matter; verify critical conclusions against the original source when needed.",
    ]


def _root_coverage_text(result: AnalysisResult) -> str:
    parts = []
    for root in result.root_modules[:4]:
        kind = result.root_kinds.get(root, "root")
        coverage = result.root_reachability.get(root, 0)
        parts.append(f"{root} [{kind}]={coverage}")
    if len(result.root_modules) > 4:
        parts.append(f"... {len(result.root_modules) - 4} more")
    return ", ".join(parts)


def _module_inventory_lines(ordered_files: list[FileInfo]) -> list[str]:
    lines = ["# Module Inventory"]
    displayed = ordered_files[:20]
    for index, file_info in enumerate(displayed, start=1):
        lines.append(
            "- "
            + " | ".join(
                [
                    str(index),
                    file_info.relative_path,
                    f"cc={file_info.max_complexity}",
                    f"depth={file_info.depth_from_entry if file_info.depth_from_entry >= 0 else 'unreachable'}",
                    f"root_count={len(file_info.reached_by_roots)}",
                    f"mode={file_info.inclusion_mode}",
                ]
            )
        )
    omitted = len(ordered_files) - len(displayed)
    if omitted > 0:
        lines.append(f"- ... {omitted} more modules")
    return lines


def _hotspot_lines(hotspots: list[FunctionInfo]) -> list[str]:
    if not hotspots:
        return ["- none"]
    return [
        f"- {item.module_path}:{item.qualified_name} | score={item.hotspot_score:.1f} | cc={item.cyclomatic_complexity}"
        for item in hotspots[:12]
    ]


def _cycle_lines(cycles: list[list[str]]) -> list[str]:
    if not cycles:
        return ["- none"]
    rendered = [f"- {' -> '.join(cycle)}" for cycle in cycles[:5]]
    if len(cycles) > 5:
        rendered.append(f"- ... {len(cycles) - 5} more cycles")
    return rendered


def _file_block(file_info: FileInfo) -> list[str]:
    body = _render_file_body(file_info)
    header = [
        f"# FILE: {file_info.relative_path}",
        f"# MODE: {file_info.inclusion_mode}",
        f"# WHY IMPORTANT: {', '.join(file_info.why_important) if file_info.why_important else 'n/a'}",
    ]
    if file_info.inclusion_mode != "full":
        header.append(f"# KEY FUNCTIONS: {_function_preview(file_info)}")
    return header + [""] + body


def _render_file_body(file_info: FileInfo) -> list[str]:
    if file_info.inclusion_mode == "full":
        return file_info.cleaned_source.splitlines() or [""]
    if file_info.inclusion_mode == "summary":
        return _summary_lines(file_info)
    return _signature_lines(file_info)


def _summary_lines(file_info: FileInfo) -> list[str]:
    lines = ["# Summary"]
    if file_info.module_docstring:
        lines.append(f'"""{_short_doc(file_info.module_docstring, limit=90, max_lines=2)}"""')
    if file_info.imports:
        lines.append(f"# Internal imports: {', '.join(file_info.imports[:4])}")
    class_count = 0
    method_count = 0
    for class_name in file_info.classes[:6]:
        bases = ", ".join(file_info.class_bases.get(class_name, [])) or "object"
        lines.append(f"class {class_name}({bases}): ...")
        class_count += 1
        for function in sorted(file_info.functions.values(), key=lambda item: (item.class_name or "", item.lineno)):
            if function.class_name == class_name and method_count < 10:
                lines.append(f"    {function.signature_text}: ...")
                if function.docstring:
                    lines.append(f'    """{_short_doc(function.docstring, limit=72, max_lines=1)}"""')
                method_count += 1
    standalone_count = 0
    for function in sorted(file_info.functions.values(), key=lambda item: item.lineno):
        if function.class_name is None and standalone_count < 12:
            lines.append(f"{function.signature_text}: ...")
            if function.docstring:
                lines.append(f'    """{_short_doc(function.docstring, limit=72, max_lines=1)}"""')
            standalone_count += 1
    omitted = len(file_info.classes) - class_count + sum(
        1 for function in file_info.functions.values() if function.class_name is None
    ) - standalone_count
    if omitted > 0:
        lines.append(f"# ... {omitted} more symbols omitted")
    return lines


def _signature_lines(file_info: FileInfo) -> list[str]:
    lines = ["# Signatures"]
    if file_info.module_docstring:
        lines.append(f'"""{_short_doc(file_info.module_docstring, limit=70, max_lines=1)}"""')
    shown = 0
    for class_name in file_info.classes[:8]:
        bases = ", ".join(file_info.class_bases.get(class_name, [])) or "object"
        lines.append(f"class {class_name}({bases}): ...")
        shown += 1
    for function in sorted(file_info.functions.values(), key=lambda item: item.lineno)[:20]:
        lines.append(f"{function.signature_text}: ...")
        shown += 1
    total_symbols = len(file_info.classes) + len(file_info.functions)
    if total_symbols > shown:
        lines.append(f"# ... {total_symbols - shown} more symbols omitted")
    return lines


def _function_preview(file_info: FileInfo) -> str:
    names = sorted(file_info.functions)[:5]
    if not names:
        return "none"
    if len(file_info.functions) > len(names):
        names.append(f"... {len(file_info.functions) - len(names)} more")
    return ", ".join(names)


def _short_doc(docstring: str, limit: int = 120, max_lines: int = 1) -> str:
    kept_lines: list[str] = []
    for line in docstring.strip().splitlines():
        stripped = line.strip()
        if not stripped:
            if kept_lines:
                break
            continue
        kept_lines.append(stripped)
        if len(kept_lines) >= max_lines:
            break
    text = " ".join(kept_lines)
    if len(text) <= limit:
        return text
    return text[: limit - 3].rstrip() + "..."


def _concat_source(source: str) -> list[str]:
    return [line.rstrip() for line in source.splitlines() if line.strip()]

# FILE: discovery.py
# MODE: full
# WHY IMPORTANT: complexity hotspot, reachable from entry, review root coverage, shared across roots

from __future__ import annotations

import re
from fnmatch import fnmatch
from pathlib import Path

from .models import Config


def discover_python_files(config: Config) -> list[Path]:
    files: list[Path] = []
    root = config.package_root.resolve()
    regexes = [re.compile(pattern) for pattern in config.exclude_regexes]
    excluded_dirs = set(config.exclude_dirs)
    for path in sorted(root.rglob("*.py")):
        rel = path.relative_to(root)
        rel_posix = rel.as_posix()
        parts = set(rel.parts)
        if parts & excluded_dirs:
            continue
        if any(fnmatch(rel_posix, pattern) for pattern in config.exclude_globs):
            continue
        if any(pattern.search(rel_posix) for pattern in regexes):
            continue
        if not config.include_tests and _looks_like_test(rel):
            continue
        files.append(path)
    return files


def _looks_like_test(path: Path) -> bool:
    parts = {part.lower() for part in path.parts}
    if "tests" in parts or "test" in parts:
        return True
    name = path.name.lower()
    if name.startswith("distilled.") and name.endswith(".py"):
        return True
    return name.startswith("test_") or name.endswith("_test.py")

# FILE: api.py
# MODE: full
# WHY IMPORTANT: called from entry, complexity hotspot, entry path, review root coverage, shared across roots

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from .analysis import analyze_files, module_path_for_file
from .discovery import discover_python_files
from .enrich import apply_radon_metrics, detect_unused_candidates
from .graphs import build_import_graph, compute_reachability, detect_cycles, order_modules, render_call_graph, render_import_forest, render_import_tree
from .ir import write_ir_bundle
from .models import AnalysisResult, Config, FileInfo
from .ranking import assign_inclusion_modes, collect_hotspots, generate_observations, score_files
from .render import render_bundle
from .resolution import resolve_calls


def analyze(config: Config) -> AnalysisResult:
    """Analyze a package and return the canonical structured review result.

    The returned object mixes directly extracted facts with heuristic judgments.

    High-confidence fields are based on static parsing and graph extraction:
    module paths, symbols, signatures, imports, source spans, and extracted
    relationships.

    Heuristic fields include root selection, pooled reachability, hotspot
    scores, importance ranking, unused-code candidates, and source inclusion
    choices for the derived review bundle.
    """
    paths = discover_python_files(config)
    files = analyze_files(paths, config)
    warnings = apply_radon_metrics(files, config)
    entry_relative = Path(config.entry_point_module)
    entry_module = module_path_for_file(entry_relative, config.package_name)
    if entry_module not in files:
        raise ValueError(f"Entry module not found: {config.entry_point_module}")

    root_modules = derive_root_modules(files, config, entry_module)
    root_kinds = classify_root_modules(files, config, entry_module, root_modules)
    if config.entry_point_function:
        entry_file = files[entry_module]
        if not any(
            function.qualified_name == config.entry_point_function or function.name == config.entry_point_function
            for function in entry_file.functions.values()
        ):
            raise ValueError(f"Entry function not found: {config.entry_point_function} in {config.entry_point_module}")

    warnings.extend(resolve_calls(files, config))
    import_graph = build_import_graph(files)
    cycles = detect_cycles(import_graph)
    reachable_count, unreachable_count, root_reachability = compute_reachability(files, import_graph, root_modules)
    score_files(files, cycles, entry_module, config.entry_point_function)
    hotspots = collect_hotspots(files, config.complexity_hotspot_threshold)
    ordered_modules = order_modules(files, import_graph)
    assign_inclusion_modes(files, ordered_modules, config)
    observations = generate_observations(files, cycles, hotspots)
    total_lines = sum(file_info.lines for file_info in files.values())
    total_sloc = sum(file_info.sloc for file_info in files.values())
    unused_candidates, vulture_warnings = detect_unused_candidates(files, config)
    warnings.extend(vulture_warnings)
    import_tree_lines = (
        render_import_tree(import_graph, files, entry_module)
        if config.analysis_kind == "application"
        else render_import_forest(import_graph, files, root_modules)
    )
    call_graph_lines = (
        render_call_graph(files, entry_module, config.entry_point_function, config.call_graph_depth)
        if config.entry_point_function
        else ["- n/a (library mode: no single function entrypoint)"]
    )
    return AnalysisResult(
        config=config,
        files=files,
        import_graph=import_graph,
        call_graph_lines=call_graph_lines,
        import_tree_lines=import_tree_lines,
        cycles=cycles,
        ordered_modules=ordered_modules,
        root_modules=root_modules,
        root_kinds=root_kinds,
        root_reachability=root_reachability,
        hotspots=hotspots,
        observations=observations,
        total_lines=total_lines,
        total_sloc=total_sloc,
        reachable_count=reachable_count,
        unreachable_count=unreachable_count,
        warnings=warnings,
        unused_candidates=unused_candidates,
    )


def bundle(config: Config) -> str:
    """Render the single-file LLM review bundle from the canonical analysis IR.

    This artifact is optimized for quick review, not as the source of truth.
    The underlying IR remains the authoritative structured output for agents and
    for auditing the tool's heuristic choices.
    """
    return render_bundle(analyze(config))


def write_outputs(config: Config) -> dict[str, object]:
    """Write the default bundle and, optionally, the `.distillrepo/` IR.

    The single-file bundle is a compressed, review-oriented view.
    When enabled, the `.distillrepo/` directory contains the fuller machine-readable
    representation, including pooled multi-root metadata and other analysis
    artifacts that may be too verbose for direct LLM consumption.
    """
    result = analyze(config)
    bundle_text = render_bundle(result)
    date_label = datetime.now().strftime("%b%d%Y")
    bundle_path = config.output_path or (config.package_root / f"distilled.{config.package_name}.{date_label}.py")
    bundle_path.write_text(bundle_text, encoding="utf-8")
    ir_dir = config.package_root / ".distillrepo" if config.write_ir else None
    artifacts = write_ir_bundle(result, bundle_path, ir_dir) if ir_dir is not None else []
    return {
        "result": result,
        "bundle_path": bundle_path,
        "ir_dir": ir_dir,
        "artifacts": artifacts,
    }


def derive_root_modules(files: dict[str, FileInfo], config: Config, entry_module: str) -> list[str]:
    """Choose a small root set for pooled review analysis.

    The policy is intentionally conservative: enough roots to cover likely
    public or runnable surfaces, but not so many that every module becomes
    equally "important" and the review bundle stops compressing usefully.
    """
    roots: list[str] = []
    package_root_module = f"{config.package_name}"
    if package_root_module in files:
        roots.append(package_root_module)
    if entry_module in files:
        roots.append(entry_module)

    package_init = files.get(package_root_module)
    if package_init is not None:
        roots.extend(package_init.imports[:4] if config.analysis_kind == "library" else package_init.imports[:2])

    direct_children = []
    for module_path, file_info in files.items():
        if not file_info.relative_path.endswith("__init__.py"):
            continue
        if module_path == package_root_module:
            continue
        suffix = module_path.removeprefix(f"{config.package_name}.")
        if suffix and "." not in suffix:
            direct_children.append(module_path)
    roots.extend(sorted(direct_children)[:4 if config.analysis_kind == "library" else 2])

    roots = [module for module in roots if module in files]
    ordered_roots = []
    for module in roots:
        if module not in ordered_roots:
            ordered_roots.append(module)
    return ordered_roots[:8 if config.analysis_kind == "library" else 4]


def classify_root_modules(files: dict[str, FileInfo], config: Config, entry_module: str, root_modules: list[str]) -> dict[str, str]:
    """Label inferred roots so users can inspect why each root was included."""
    root_kinds: dict[str, str] = {}
    package_root_module = config.package_name
    for module in root_modules:
        if config.entry_point_function and module == entry_module:
            root_kinds[module] = "cli_entrypoint"
        elif module == package_root_module:
            root_kinds[module] = "package_root"
        elif files[module].relative_path.endswith("__init__.py"):
            root_kinds[module] = "subpackage_root"
        else:
            root_kinds[module] = "module_root"
    return root_kinds

# FILE: __init__.py
# MODE: full
# WHY IMPORTANT: entry path, review root coverage, shared across roots

"""distillrepo package."""

from importlib.metadata import PackageNotFoundError, version

from .api import analyze, bundle

try:
    __version__ = version("distillrepo")
except PackageNotFoundError:
    # Running from source (not installed as a distribution).
    __version__ = "0.25"

__all__ = ["__version__", "analyze", "bundle"]

# FILE: cli.py
# MODE: full
# WHY IMPORTANT: called from entry, complexity hotspot, entry module, entry path, review root coverage

"""CLI for distillrepo.

The CLI is intentionally explicit about trust boundaries:
- extracted facts such as symbols, signatures, paths, and static imports are
  higher confidence
- hotspots, root coverage, unused-code candidates, and compression choices are
  heuristic and should be treated as review guidance rather than truth
"""

from __future__ import annotations

import argparse
import ast
import sys
import warnings
from pathlib import Path

try:
    import tomllib
except ImportError:
    import tomli as tomllib  # type: ignore[no-redef]

from . import __version__
from .api import write_outputs
from .models import Config


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="distillrepo",
        description=(
            "Distill a repository into a compact LLM review bundle and a "
            "structured .distillrepo Intermediate Representation (IR). "
            "When package_root is omitted, the current directory is used."
        ),
        epilog=(
            "Trust directly extracted facts more than heuristic judgments. "
            "Hotspots, root coverage, not-reached conclusions, unused-code "
            "candidates, and compression choices are guidance. "
            "Use --entry-point-module, --entry-point-function, exclusions, and "
            "--review-mode to override defaults when needed."
        ),
    )
    parser.add_argument("package_root", nargs="?", type=Path, help="Path to the package root to analyze.")
    parser.add_argument(
        "--entry-point-module",
        help="Override the inferred entry module path relative to the package root.",
    )
    parser.add_argument(
        "--entry-point-function",
        help="Override the inferred entry function or method name.",
    )
    parser.add_argument("--output", type=Path, help="Write the single-file LLM bundle to this path.")
    parser.add_argument("--stdout", action="store_true", help="Also print the generated LLM bundle to stdout.")
    parser.add_argument(
        "--no-ir",
        action="store_true",
        help="Skip writing the `.distillrepo/` intermediate representation directory.",
    )
    parser.add_argument(
        "--review-mode",
        default="review",
        choices=["review", "architecture", "hotspots", "entrypath", "budgeted", "concat", "plain_concat", "full"],
        help=(
            "LLM bundle strategy. "
            "review=recommended balanced mix of analysis, selected full source, summaries, and signatures; "
            "architecture=compact structure-first map with lighter source detail; "
            "hotspots=prioritize complex or risky areas; "
            "entrypath=prioritize code closest to inferred roots; "
            "budgeted=more aggressive compression with less source retention; "
            "concat=cleaned source concat with lightweight static-analysis headers; "
            "plain_concat=cleaned source concat only, no added headers; "
            "full=largest review bundle with analysis sections plus broad full-source inclusion."
        ),
    )
    parser.add_argument("--call-graph-depth", type=int, default=4, help="Maximum call graph depth.")
    parser.add_argument(
        "--complexity-threshold",
        type=int,
        default=10,
        help="Threshold used by the hotspot heuristic; lower values surface more candidates.",
    )
    parser.add_argument("--max-tokens", type=int, help="Cap estimated tokens for LLM bundle source material.")
    parser.add_argument("--max-chars", type=int, help="Cap characters for LLM bundle source material.")
    parser.add_argument("--max-lines", type=int, help="Cap lines for LLM bundle source material.")
    parser.add_argument("--max-files", type=int, help="Cap included files in the LLM bundle source material.")
    parser.add_argument("--exclude-dir", action="append", default=[], help="Directory name to exclude.")
    parser.add_argument("--exclude-glob", action="append", default=[], help="Glob pattern to exclude.")
    parser.add_argument("--exclude-regex", action="append", default=[], help="Regex pattern to exclude.")
    parser.add_argument("--include-tests", action="store_true", help="Include tests in discovery.")
    parser.add_argument(
        "--no-jedi",
        action="store_true",
        help="Disable Jedi-based call resolution enrichment.",
    )
    parser.add_argument(
        "--no-radon",
        action="store_true",
        help="Disable Radon-based complexity and maintainability enrichment.",
    )
    parser.add_argument(
        "--no-vulture",
        action="store_true",
        help="Disable Vulture-based unused-code candidate detection.",
    )
    parser.add_argument(
        "--exclude-unreachable",
        action="store_true",
        help="Force exclusion of modules not reached from the inferred root set, including in full and concat-style modes.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    return parser


def main() -> int:
    warnings.filterwarnings("ignore", message=r"Tried to save a file to .*", module=r"parso\.cache")
    parser = build_parser()
    no_arg_invocation = len(sys.argv) == 1
    args = parser.parse_args()

    if args.package_root is None:
        args.package_root = Path(".")

    if no_arg_invocation:
        args.review_mode = "full"
        args.no_ir = True

    try:
        project_input = args.package_root.resolve()
        invocation_cwd = Path.cwd().resolve()
        project_root = _find_project_root(project_input)
        pyproject = _load_pyproject(project_root) if project_root is not None else {}
        raw_project_name = pyproject.get("project", {}).get("name") or project_input.name
        normalized_project_name = str(raw_project_name).replace("-", "_")
        script_target = _infer_script_target(pyproject, normalized_project_name)
        package_root = _infer_package_root(project_input, project_root, pyproject, script_target)
        package_name = package_root.name
        analysis_kind = "application" if script_target is not None else "library"
        entry_point_module = args.entry_point_module or _infer_entry_point_module(
            package_root, package_name, pyproject, script_target, analysis_kind
        )
        entry_point_function = args.entry_point_function or _infer_entry_point_function(
            package_root / entry_point_module, script_target, analysis_kind
        )

        if args.output:
            output_path = args.output.resolve()
        elif no_arg_invocation:
            output_path = invocation_cwd / f"distilled.{package_name}.{_date_label()}.py"
        else:
            output_path = None

        default_excludes = Config.__dataclass_fields__["exclude_dirs"].default_factory()
        config = Config(
            package_root=package_root,
            package_name=package_name,
            entry_point_module=entry_point_module,
            entry_point_function=entry_point_function,
            output_path=output_path,
            write_ir=not args.no_ir,
            review_mode=args.review_mode,
            call_graph_depth=args.call_graph_depth,
            complexity_hotspot_threshold=args.complexity_threshold,
            use_jedi=not args.no_jedi,
            use_radon=not args.no_radon,
            use_vulture=not args.no_vulture,
            exclude_dirs=default_excludes | set(args.exclude_dir),
            exclude_globs=list(args.exclude_glob),
            exclude_regexes=list(args.exclude_regex),
            include_tests=args.include_tests,
            max_tokens=args.max_tokens,
            max_chars=args.max_chars,
            max_lines=args.max_lines,
            max_files=args.max_files,
            include_unreachable=(
                False if args.exclude_unreachable else args.review_mode in {"full", "concat", "plain_concat"}
            ),
            analysis_kind=analysis_kind,
        )
        outputs = write_outputs(config)
    except ValueError as exc:
        parser.exit(2, f"distillrepo: error: {exc}\n")

    result = outputs["result"]
    bundle_path = outputs["bundle_path"]
    ir_dir = outputs["ir_dir"]
    _print_summary(result, bundle_path, ir_dir)
    if args.stdout:
        print("")
        print(bundle_path.read_text(encoding="utf-8"), end="")
    return 0


def _find_project_root(path: Path) -> Path | None:
    current = path if path.is_dir() else path.parent
    for candidate in [current, *current.parents]:
        if (candidate / "pyproject.toml").is_file():
            return candidate
    return None


def _load_pyproject(project_root: Path) -> dict:
    return tomllib.loads((project_root / "pyproject.toml").read_text(encoding="utf-8"))


def _infer_package_root(project_input: Path, project_root: Path | None, pyproject: dict, script_target: str | None) -> Path:
    search_root = project_root or project_input
    if (project_input / "__init__.py").is_file():
        return project_input

    if script_target:
        module_name, _, _ = script_target.partition(":")
        match = _find_module_file(search_root, module_name)
        if match is not None:
            return _package_root_from_module_file(match, module_name)

    for candidate in _hatch_package_candidates(search_root, pyproject):
        if (candidate / "__init__.py").is_file():
            return candidate

    candidates: list[Path] = []
    project_name = pyproject.get("project", {}).get("name")
    if isinstance(project_name, str):
        normalized = project_name.replace("-", "_")
        candidates.append(search_root / normalized)
        candidates.append(search_root / "src" / normalized)
    candidates.append(search_root / project_input.name.replace("-", "_"))
    candidates.append(search_root / "src" / project_input.name.replace("-", "_"))

    for candidate in candidates:
        if (candidate / "__init__.py").is_file():
            return candidate

    package_children = sorted(
        child for child in search_root.iterdir() if child.is_dir() and (child / "__init__.py").is_file()
    )
    if len(package_children) == 1:
        return package_children[0]

    src_root = search_root / "src"
    if src_root.is_dir():
        src_children = sorted(
            child for child in src_root.iterdir() if child.is_dir() and (child / "__init__.py").is_file()
        )
        if len(src_children) == 1:
            return src_children[0]

    return project_input


def _infer_entry_point_module(
    package_root: Path, package_name: str, pyproject: dict, script_target: str | None, analysis_kind: str
) -> str:
    if script_target is not None:
        module_name, _, _ = script_target.partition(":")
        for module_path in _module_name_candidates(module_name, package_name):
            if (package_root / module_path).is_file():
                return module_path
    if analysis_kind == "library" and (package_root / "__init__.py").is_file():
        return "__init__.py"

    for candidate in ("cli.py", "__main__.py", "__init__.py"):
        if (package_root / candidate).is_file():
            return candidate
    python_files = sorted(path.relative_to(package_root).as_posix() for path in package_root.rglob("*.py"))
    if python_files:
        return python_files[0]
    raise ValueError(f"No Python files found under package root: {package_root}")


def _infer_entry_point_function(entry_module_path: Path, script_target: str | None, analysis_kind: str) -> str | None:
    if analysis_kind == "library" and script_target is None:
        return None
    if not entry_module_path.is_file():
        raise ValueError(f"Entry module not found: {entry_module_path}")
    if script_target and ":" in script_target:
        _, _, callable_path = script_target.partition(":")
        callable_name = callable_path.split(".")[-1]
        if callable_name:
            return callable_name
    source = entry_module_path.read_text(encoding="utf-8")
    tree = ast.parse(source, filename=str(entry_module_path))
    top_level_names = []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            top_level_names.append(node.name)
    for candidate in ("main", "run", "cli"):
        if candidate in top_level_names:
            return candidate
    if top_level_names:
        return top_level_names[0]
    raise ValueError(f"No top-level functions found in inferred entry module: {entry_module_path}")


def _infer_script_target(pyproject: dict, package_name: str) -> str | None:
    project = pyproject.get("project", {})
    scripts = project.get("scripts")
    if not isinstance(scripts, dict) or not scripts:
        return None
    normalized_package_name = package_name.replace("-", "_")
    if normalized_package_name in scripts and isinstance(scripts[normalized_package_name], str):
        return scripts[normalized_package_name]
    for _, target in scripts.items():
        if isinstance(target, str) and target.startswith(f"{normalized_package_name}."):
            return target
    for _, target in scripts.items():
        if isinstance(target, str):
            return target
    return None


def _module_name_candidates(module_name: str, package_name: str) -> list[str]:
    normalized_package_name = package_name.replace("-", "_")
    if module_name == normalized_package_name:
        return ["__init__.py"]
    prefix = f"{normalized_package_name}."
    if not module_name.startswith(prefix):
        return []
    suffix = module_name[len(prefix) :]
    rel = suffix.replace(".", "/")
    return [f"{rel}.py", f"{rel}/__init__.py"]


def _find_module_file(project_root: Path, module_name: str) -> Path | None:
    module_parts = module_name.split(".")
    suffixes = [
        Path(*module_parts).with_suffix(".py"),
        Path(*module_parts) / "__init__.py",
    ]
    matches: list[Path] = []
    for path in project_root.rglob("*.py"):
        rel = path.relative_to(project_root)
        for suffix in suffixes:
            if len(rel.parts) >= len(suffix.parts) and rel.parts[-len(suffix.parts) :] == suffix.parts:
                matches.append(path)
                break
    matches = sorted(dict.fromkeys(matches))
    if len(matches) == 1:
        return matches[0]
    return None


def _hatch_package_candidates(project_root: Path, pyproject: dict) -> list[Path]:
    tool = pyproject.get("tool", {})
    hatch = tool.get("hatch", {}) if isinstance(tool, dict) else {}
    build = hatch.get("build", {}) if isinstance(hatch, dict) else {}
    targets = build.get("targets", {}) if isinstance(build, dict) else {}
    wheel = targets.get("wheel", {}) if isinstance(targets, dict) else {}
    packages = wheel.get("packages") if isinstance(wheel, dict) else None
    if not isinstance(packages, list):
        return []
    candidates: list[Path] = []
    for package in packages:
        if isinstance(package, str):
            candidates.append((project_root / package).resolve())
    return candidates


def _package_root_from_module_file(module_file: Path, module_name: str) -> Path:
    top_package = module_name.split(".")[0]
    current = module_file.parent if module_file.name != "__init__.py" else module_file.parent
    while current.name != top_package and current.parent != current:
        current = current.parent
    return current


def _date_label() -> str:
    from datetime import datetime

    return datetime.now().strftime("%b%d%Y")


def _print_summary(result, bundle_path: Path, ir_dir: Path | None) -> None:
    original_tokens = result.original_tokens
    bundle_tokens = result.bundle_tokens
    saved_tokens = max(0, original_tokens - bundle_tokens)
    saved_percent = (saved_tokens / original_tokens * 100.0) if original_tokens else 0.0
    retained_percent = (bundle_tokens / original_tokens * 100.0) if original_tokens else 0.0
    compression = (original_tokens / bundle_tokens) if bundle_tokens else 0.0
    print(
        f"Analyzed: {len(result.files)} files, "
        f"{sum(len(file_info.functions) for file_info in result.files.values())} symbols, "
        f"{len(result.files)} modules"
    )
    print(f"Analysis kind: {result.config.analysis_kind}")
    print(f"Roots analyzed: {len(result.root_modules)}")
    print(f"Reached from roots: {result.reachable_count}, not reached: {result.unreachable_count}")
    print(f"Cycles: {len(result.cycles)}")
    if result.unused_candidates:
        print(f"Possible unused symbols: {len(result.unused_candidates)}")
    if result.hotspots:
        top = result.hotspots[0]
        print(
            f"Top hotspot: {top.module_path}:{top.qualified_name} "
            f"(score={top.hotspot_score:.1f}, cc={top.cyclomatic_complexity})"
        )
    print("")
    print(f"Original size: {original_tokens:,} tokens")
    print(f"Distilled size: {bundle_tokens:,} tokens")
    print(f"Saved: {saved_tokens:,} tokens ({saved_percent:.1f}%)")
    print(f"Retained: {retained_percent:.1f}% of estimated original tokens")
    if compression:
        print(f"Compression: {compression:.1f}x")
    print("")
    print(f"LLM bundle: {bundle_path}")
    print(f"IR: {ir_dir if ir_dir is not None else 'skipped (--no-ir)'}")


if __name__ == "__main__":
    raise SystemExit(main())

# FILE: __main__.py
# MODE: full
# WHY IMPORTANT: n/a

from .cli import main


if __name__ == "__main__":
    raise SystemExit(main())
