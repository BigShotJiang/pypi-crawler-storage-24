# pCloudy CLI

Remote ADB bridge and device management CLI for pCloudy.

## Installation

```bash
pip install pcloudy
```

If `pcloudy` is not found after install, add Python's bin directory to your PATH:
```bash
pip show pcloudy   # find the install location
```

## Quick Start

### 1. Login with your API key

```bash
pcloudy login --email you@company.com --access-key YOUR_ACCESS_KEY
```

Your token is saved locally in `~/.pcloudy/config.json`.

### 2. Connect to a device session

```bash
pcloudy connect --device 0tM9
```

### 3. Use ADB commands

```bash
pcloudy adb shell
pcloudy adb install app.apk
pcloudy adb logcat
```

### 4. Disconnect when done

```bash
pcloudy disconnect -d 0tM9
```

> ⚠️ **Always disconnect** when done. Failing to disconnect may cause your IP to be temporarily blocked.

## Commands

| Command                     | Description                          |
| --------------------------- | ------------------------------------ |
| `pcloudy login -e -k`      | Authenticate with email & access key |
| `pcloudy logout`            | Clear stored credentials             |
| `pcloudy connect -d <id>`  | Connect ADB to remote device         |
| `pcloudy disconnect -d <id>` | Disconnect from device             |
| `pcloudy adb <args>`       | Proxy ADB commands                   |
| `pcloudy status`           | Show auth & connection status        |

## Custom Base URL

For private cloud or on-prem deployments:

```bash
pcloudy login -e you@co.com -k KEY --base-url https://your-instance.pcloudy.com
```

## Development

```bash
git clone https://github.com/nickvergara/pcloudy.git
cd pcloudy
pip install -e .     # editable install for development
```

## Build & Publish

```bash
pip install build twine
python -m build
twine upload dist/*
```
