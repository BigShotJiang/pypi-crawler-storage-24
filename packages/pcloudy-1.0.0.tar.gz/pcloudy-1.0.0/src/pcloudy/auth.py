"""Authentication module - handles login via pCloudy API."""

import requests
from rich.console import Console

from pcloudy.config import save_config, get_base_url

console = Console()


class AuthError(Exception):
    """Raised when authentication fails."""
    pass


def login(email: str, access_key: str, base_url: str | None = None) -> dict:
    """
    Authenticate with pCloudy API.

    Calls {{baseUrl}}/api/access with email and accessKey.
    Returns dict with token and cloud_name on success.

    Args:
        email: pCloudy account email.
        access_key: pCloudy access key.
        base_url: Optional base URL override.

    Returns:
        dict with 'token' and 'cloud_name' keys.

    Raises:
        AuthError: If authentication fails.
    """
    url = base_url or get_base_url()
    endpoint = f"{url.rstrip('/')}/api/access"

    try:
        response = requests.get(
            endpoint,
            params={
                "email": email,
                "accessKey": access_key,
            },
            timeout=30,
        )
        response.raise_for_status()
        data = response.json()

    except requests.ConnectionError:
        raise AuthError(f"Could not connect to {url}. Check your network or base URL.")
    except requests.Timeout:
        raise AuthError("Request timed out. Try again later.")
    except requests.HTTPError as e:
        raise AuthError(f"HTTP error {e.response.status_code}: {e.response.text}")
    except ValueError:
        raise AuthError("Invalid JSON response from server.")

    # Extract token from response
    # Adjust these keys based on actual API response structure
    token = data.get("result", {}).get("token") or data.get("token")
    cloud_name = data.get("result", {}).get("cloudName") or data.get("cloudName")

    if not token:
        raise AuthError(f"No token in response. Full response: {data}")

    # Save credentials locally
    config_data = {
        "access_key": access_key,
        "email": email,
        "base_url": url,
    }
    if cloud_name:
        config_data["cloud_name"] = cloud_name

    save_config(config_data)

    return {
        "token": token,
        "cloud_name": cloud_name,
    }
