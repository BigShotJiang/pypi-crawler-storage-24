"""Configuration management - stores auth tokens and settings locally."""

import json
import os
from pathlib import Path

CONFIG_DIR = Path.home() / ".pcloudy"
CONFIG_FILE = CONFIG_DIR / "config.json"


def _ensure_config_dir():
    """Create config directory if it doesn't exist."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def save_config(data: dict):
    """Save config data to ~/.pcloudy/config.json."""
    _ensure_config_dir()
    existing = load_config()
    existing.update(data)
    CONFIG_FILE.write_text(json.dumps(existing, indent=2))
    # Restrict permissions to owner only
    os.chmod(CONFIG_FILE, 0o600)


def load_config() -> dict:
    """Load config from ~/.pcloudy/config.json."""
    if not CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(CONFIG_FILE.read_text())
    except (json.JSONDecodeError, IOError):
        return {}


def get_token() -> str | None:
    """Get the stored auth token."""
    return load_config().get("token")


def get_cloud_name() -> str | None:
    """Get the stored cloud name."""
    return load_config().get("cloud_name")


def get_base_url() -> str:
    """Get the base URL for the pCloudy API."""
    return load_config().get("base_url", "https://device.pcloudy.com")


def clear_config():
    """Remove stored config."""
    if CONFIG_FILE.exists():
        CONFIG_FILE.unlink()
