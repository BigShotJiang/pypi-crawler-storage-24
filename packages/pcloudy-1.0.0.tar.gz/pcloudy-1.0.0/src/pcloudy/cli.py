"""pCloudy CLI - main entry point."""

import sys
import click
from rich.console import Console
from rich.panel import Panel

from pcloudy import __version__

console = Console()


@click.group()
@click.version_option(version=__version__, prog_name="pcloudy")
def main():
    """pCloudy CLI - Remote ADB bridge and device management."""
    pass


# ---------------------------------------------------------------------------
# login
# ---------------------------------------------------------------------------
@main.command()
@click.option("--email", "-e", required=True, help="pCloudy account email.")
@click.option("--access-key", "-k", required=True, help="pCloudy access key.")
@click.option(
    "--base-url", "-u",
    default=None,
    help="Base URL for pCloudy API (default: https://device.pcloudy.com).",
)
def login(email: str, access_key: str, base_url: str | None):
    """Authenticate with your pCloudy credentials.

    Example:
        pcloudy login --email user@company.com --access-key YOUR_KEY
    """
    from pcloudy.auth import login as do_login, AuthError

    console.print(f"[dim]Authenticating as {email}...[/dim]")

    try:
        result = do_login(email, access_key, base_url)
        console.print(
            Panel.fit(
                f"[green]✔ Logged in successfully![/green]\n"
                f"  Token : {result['token'][:12]}...\n"
                f"  Cloud : {result.get('cloud_name', 'N/A')}",
                title="pCloudy Auth",
            )
        )
    except AuthError as e:
        console.print(f"[red]✘ Login failed:[/red] {e}")
        sys.exit(1)


# ---------------------------------------------------------------------------
# logout
# ---------------------------------------------------------------------------
@main.command()
def logout():
    """Clear stored credentials."""
    from pcloudy.config import clear_config

    clear_config()
    console.print("[green]✔ Logged out. Credentials removed.[/green]")


# ---------------------------------------------------------------------------
# connect
# ---------------------------------------------------------------------------
@main.command()
@click.option("--device", "-d", required=True, help="Device/session ID to connect to.")
def connect(device: str):
    """Connect your local ADB to a remote device session.

    Example:
        pcloudy connect --device 0tM9
    """
    from pcloudy.connection import connect as do_connect, ConnectionError

    console.print(f"[dim]Connecting to device {device}...[/dim]")

    try:
        result = do_connect(device)
        console.print(f"[green]✔ Connected to device {device}[/green]")
        console.print(f"[dim]{result}[/dim]")
    except ConnectionError as e:
        console.print(f"[red]✘ Connection failed:[/red] {e}")
        sys.exit(1)


# ---------------------------------------------------------------------------
# disconnect
# ---------------------------------------------------------------------------
@main.command()
@click.option("--device", "-d", required=True, help="Device/session ID to disconnect from.")
def disconnect(device: str):
    """Disconnect from a remote device session.

    Always disconnect when done to avoid IP blocking.

    Example:
        pcloudy disconnect -d 0tM9
    """
    from pcloudy.connection import disconnect as do_disconnect, ConnectionError

    try:
        do_disconnect(device)
        console.print(f"[green]✔ Disconnected from device {device}[/green]")
    except ConnectionError as e:
        console.print(f"[red]✘ Disconnect failed:[/red] {e}")
        sys.exit(1)


# ---------------------------------------------------------------------------
# adb (proxy)
# ---------------------------------------------------------------------------
@main.command(
    context_settings=dict(
        ignore_unknown_options=True,
        allow_extra_args=True,
    ),
)
@click.argument("args", nargs=-1, type=click.UNPROCESSED)
def adb(args):
    """Proxy ADB commands to the connected remote device.

    Examples:
        pcloudy adb shell
        pcloudy adb install app.apk
        pcloudy adb logcat
    """
    from pcloudy.adb import run_adb_command

    exit_code = run_adb_command(args)
    sys.exit(exit_code)


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------
@main.command()
def status():
    """Show current authentication and connection status."""
    from pcloudy.config import load_config

    config = load_config()

    if not config.get("token"):
        console.print("[yellow]Not authenticated. Run 'pcloudy login' first.[/yellow]")
        return

    console.print(
        Panel.fit(
            f"  Email    : {config.get('email', 'N/A')}\n"
            f"  Cloud    : {config.get('cloud_name', 'N/A')}\n"
            f"  Base URL : {config.get('base_url', 'N/A')}\n"
            f"  Token    : {config['token'][:12]}...",
            title="pCloudy Status",
        )
    )


if __name__ == "__main__":
    main()
