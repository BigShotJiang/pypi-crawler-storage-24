"""Connection module - manages ADB connections to remote devices."""

import requests
from rich.console import Console

from pcloudy.config import get_token, get_base_url, get_cloud_name

console = Console()


class ConnectionError(Exception):
    """Raised when connection operations fail."""
    pass


def _require_auth() -> str:
    """Ensure user is authenticated and return token."""
    token = get_token()
    if not token:
        raise ConnectionError(
            "Not authenticated. Run 'pcloudy login' first."
        )
    return token


def connect(device_id: str) -> dict:
    """
    Connect local ADB to a remote device session.

    Args:
        device_id: The device/session ID to connect to.

    Returns:
        dict with connection details.
    """
    token = _require_auth()
    base_url = get_base_url()

    # TODO: Replace with actual pCloudy ADB connect endpoint
    endpoint = f"{base_url.rstrip('/')}/api/devices/connect"

    try:
        response = requests.post(
            endpoint,
            json={
                "token": token,
                "deviceId": device_id,
            },
            timeout=30,
        )
        response.raise_for_status()
        data = response.json()
    except requests.RequestException as e:
        raise ConnectionError(f"Connection failed: {e}")

    return data


def disconnect(device_id: str) -> dict:
    """
    Disconnect from a remote device session.
    Important: Always disconnect to avoid IP blocking.

    Args:
        device_id: The device/session ID to disconnect from.

    Returns:
        dict with disconnection status.
    """
    token = _require_auth()
    base_url = get_base_url()

    # TODO: Replace with actual pCloudy ADB disconnect endpoint
    endpoint = f"{base_url.rstrip('/')}/api/devices/disconnect"

    try:
        response = requests.post(
            endpoint,
            json={
                "token": token,
                "deviceId": device_id,
            },
            timeout=30,
        )
        response.raise_for_status()
        data = response.json()
    except requests.RequestException as e:
        raise ConnectionError(f"Disconnect failed: {e}")

    return data
