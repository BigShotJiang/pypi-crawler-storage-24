"""ADB module - proxy ADB commands to remote devices."""

import subprocess
import shutil
from rich.console import Console

from pcloudy.config import get_token

console = Console()


def run_adb_command(args: tuple) -> int:
    """
    Run an ADB command proxied through the pCloudy connection.

    Args:
        args: Tuple of ADB command arguments (e.g., ("shell", "ls")).

    Returns:
        Exit code of the ADB process.
    """
    token = get_token()
    if not token:
        console.print("[red]Not authenticated. Run 'pcloudy login' first.[/red]")
        return 1

    adb_path = shutil.which("adb")
    if not adb_path:
        console.print("[red]ADB not found in PATH. Install Android SDK platform-tools.[/red]")
        return 1

    cmd = [adb_path] + list(args)
    console.print(f"[dim]Running: {' '.join(cmd)}[/dim]")

    try:
        result = subprocess.run(cmd, check=False)
        return result.returncode
    except FileNotFoundError:
        console.print("[red]ADB executable not found.[/red]")
        return 1
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted.[/yellow]")
        return 130
