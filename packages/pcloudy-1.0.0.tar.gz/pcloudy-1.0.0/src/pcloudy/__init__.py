"""pCloudy CLI - Remote ADB bridge and device management."""

__version__ = "1.0.0"
