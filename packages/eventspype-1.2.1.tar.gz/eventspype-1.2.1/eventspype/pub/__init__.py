"""
Publisher module for eventspype.
"""
