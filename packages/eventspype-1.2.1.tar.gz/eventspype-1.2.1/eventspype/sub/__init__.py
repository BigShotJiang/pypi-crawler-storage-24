"""
Subscriber module for eventspype.
"""
