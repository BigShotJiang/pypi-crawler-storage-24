// Vite configuration for the Quodeq web UI.
// Dev server proxies /api to the local Node.js server (VITE_API_TARGET).
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

const DEFAULT_API_TARGET = 'http://localhost:4173';

export default defineConfig({
  plugins: [react()],
  build: {
    outDir: process.env.QUODEQ_BUILD_OUTDIR || '../static',
    emptyOutDir: true,
  },
  server: {
    port: Number(process.env.VITE_PORT) || 5173,
    proxy: {
      '/api': {
        target: process.env.VITE_API_TARGET || DEFAULT_API_TARGET,
        changeOrigin: true
      }
    }
  }
});
