"""Shared fixtures for the test suite."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest

from zesty_bakewell.llm import LLMClient
from zesty_bakewell.telegram import TelegramClient


@pytest.fixture
def mock_telegram() -> MagicMock:
    m = MagicMock(spec=TelegramClient)
    m.get_updates.return_value = []
    return m


@pytest.fixture
def mock_llm() -> MagicMock:
    m = MagicMock(spec=LLMClient)
    m.reply.return_value = "Hey! How's it going?"
    m.generate.return_value = "# 2026-03-15\n\nA quiet day."
    return m


@pytest.fixture
def settings(tmp_path: Path):  # type: ignore[no-untyped-def]
    """Settings wired to a temp directory so tests never touch the real repo."""
    from zesty_bakewell.bot import Settings

    return Settings(
        telegram_bot_token="test-token",
        telegram_chat_id=99999,
        gemini_api_key="test-key",
        repo_root=tmp_path,
    )
