"""Tests for the Telegram API client."""

from __future__ import annotations

import pytest
from pytest_httpx import HTTPXMock

from zesty_bakewell.telegram import TelegramClient, TelegramError

TOKEN = "test-token"
CHAT_ID = 12345
BASE = f"https://api.telegram.org/bot{TOKEN}"


@pytest.fixture
def client() -> TelegramClient:
    return TelegramClient(token=TOKEN, chat_id=CHAT_ID)


def test_get_updates_returns_messages(httpx_mock: HTTPXMock, client: TelegramClient) -> None:
    # Given a Telegram update containing a text message from our chat
    httpx_mock.add_response(
        url=f"{BASE}/getUpdates?offset=0&timeout=0",
        json={
            "ok": True,
            "result": [
                {
                    "update_id": 1,
                    "message": {
                        "message_id": 10,
                        "date": 1710000000,
                        "chat": {"id": CHAT_ID},
                        "text": "Hello!",
                    },
                }
            ],
        },
    )

    # When we fetch updates
    msgs = client.get_updates()

    # Then the message is returned with the correct content
    assert len(msgs) == 1
    assert msgs[0].text == "Hello!"
    assert msgs[0].update_id == 1


def test_get_updates_filters_other_chats(httpx_mock: HTTPXMock, client: TelegramClient) -> None:
    # Given an update from a different chat ID
    httpx_mock.add_response(
        url=f"{BASE}/getUpdates?offset=0&timeout=0",
        json={
            "ok": True,
            "result": [
                {
                    "update_id": 2,
                    "message": {
                        "message_id": 11,
                        "date": 1710000001,
                        "chat": {"id": 99999},
                        "text": "Not for us.",
                    },
                }
            ],
        },
    )

    # When we fetch updates
    msgs = client.get_updates()

    # Then no messages are returned
    assert msgs == []


def test_get_updates_skips_non_text(httpx_mock: HTTPXMock, client: TelegramClient) -> None:
    # Given an update with no text field (e.g. a photo)
    httpx_mock.add_response(
        url=f"{BASE}/getUpdates?offset=0&timeout=0",
        json={
            "ok": True,
            "result": [
                {
                    "update_id": 3,
                    "message": {
                        "message_id": 12,
                        "date": 1710000002,
                        "chat": {"id": CHAT_ID},
                    },
                }
            ],
        },
    )

    # When we fetch updates
    msgs = client.get_updates()

    # Then no messages are returned
    assert msgs == []


def test_get_updates_empty(httpx_mock: HTTPXMock, client: TelegramClient) -> None:
    # Given no pending updates
    httpx_mock.add_response(
        url=f"{BASE}/getUpdates?offset=0&timeout=0",
        json={"ok": True, "result": []},
    )

    # When we fetch updates
    msgs = client.get_updates()

    # Then an empty list is returned
    assert msgs == []


def test_get_updates_passes_offset(httpx_mock: HTTPXMock, client: TelegramClient) -> None:
    # Given an offset of 42
    httpx_mock.add_response(
        url=f"{BASE}/getUpdates?offset=42&timeout=0",
        json={"ok": True, "result": []},
    )

    # When we fetch updates with that offset
    # Then no error is raised (the correct URL was called, verified by httpx_mock)
    client.get_updates(offset=42)


def test_get_updates_raises_on_error(httpx_mock: HTTPXMock, client: TelegramClient) -> None:
    # Given a 401 response from Telegram
    httpx_mock.add_response(url=f"{BASE}/getUpdates?offset=0&timeout=0", status_code=401)

    # When we fetch updates
    # Then a TelegramError is raised
    with pytest.raises(TelegramError):
        client.get_updates()


def test_send_message_succeeds(httpx_mock: HTTPXMock, client: TelegramClient) -> None:
    # Given a successful response from Telegram
    httpx_mock.add_response(
        url=f"{BASE}/sendMessage",
        json={"ok": True, "result": {}},
    )

    # When we send a message
    # Then no error is raised
    client.send_message("Hi there!")


def test_send_message_raises_on_error(httpx_mock: HTTPXMock, client: TelegramClient) -> None:
    # Given a 400 response from Telegram
    httpx_mock.add_response(url=f"{BASE}/sendMessage", status_code=400, text="Bad request")

    # When we send a message
    # Then a TelegramError is raised
    with pytest.raises(TelegramError):
        client.send_message("Hi")
