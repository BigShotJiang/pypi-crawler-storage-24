"""Tests for core bot logic: state, storage, and orchestration."""

from __future__ import annotations

import json
from datetime import UTC, date, datetime
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from zesty_bakewell.bot import (
    PollState,
    Settings,
    _coalesce,
    _in_period,
    _period_label,
    append_raw,
    diary_path,
    load_state,
    raw_path,
    read_raw,
    read_recent_diary,
    run_nightly,
    run_poll,
    run_summarize,
    save_state,
    summary_path,
    write_diary,
)
from zesty_bakewell.telegram import Message

# ── State ─────────────────────────────────────────────────────────────────────

REPO_ROOT = Path(__file__).parent.parent


def test_committed_state_file_has_no_stale_fields() -> None:
    # Given the committed state file
    state_file = REPO_ROOT / "state" / "poll_state.json"

    # When we read its keys
    keys = set(json.loads(state_file.read_text()).keys())
    from dataclasses import fields as dc_fields

    known = {f.name for f in dc_fields(PollState)}

    # Then all keys are recognised fields (catches renames that weren't reflected in the file)
    assert keys <= known, f"Stale fields in state/poll_state.json: {keys - known}"


def test_load_state_returns_defaults_when_file_missing(settings: Settings) -> None:
    # Given no state file exists

    # When we load state
    state = load_state(settings)

    # Then default values are returned
    assert state.last_update_id == 0
    assert state.last_morning_sent is None


def test_save_and_load_state_round_trips(settings: Settings) -> None:
    # Given a state object
    state = PollState(last_update_id=42, last_morning_sent="2026-03-15")

    # When we save and reload it
    save_state(state, settings)
    loaded = load_state(settings)

    # Then the values are preserved
    assert loaded.last_update_id == 42
    assert loaded.last_morning_sent == "2026-03-15"


def test_load_state_ignores_unknown_fields(settings: Settings, tmp_path: Path) -> None:
    # Given a state file with an unrecognised field (simulating a future schema)
    p = tmp_path / "state" / "poll_state.json"
    p.parent.mkdir(parents=True)
    p.write_text(
        json.dumps(
            {
                "last_update_id": 5,
                "last_morning_sent": None,
                "last_evening_sent": None,
                "last_midday_sent": None,  # stale field from a previous schema version
            }
        )
    )

    # When we load the state
    state = load_state(settings)

    # Then known fields are read without error
    assert state.last_update_id == 5


# ── Storage paths ─────────────────────────────────────────────────────────────


def test_raw_path_structure(settings: Settings) -> None:
    # Given a date
    d = date(2026, 3, 15)

    # When we compute the raw path
    p = raw_path(d, settings)

    # Then it follows the year/month/date.jsonl structure
    assert p == settings.repo_root / "raw" / "2026" / "03" / "2026-03-15.jsonl"


def test_diary_path_structure(settings: Settings) -> None:
    # Given a date
    d = date(2026, 3, 15)

    # When we compute the diary path
    p = diary_path(d, settings)

    # Then it follows the year/month/date-weekday.md structure
    assert p == settings.repo_root / "diary" / "2026" / "03" / "2026-03-15-Sunday.md"


def test_summary_path_weekly(settings: Settings) -> None:
    # Given a date
    # When we compute the weekly summary path
    p = summary_path("weekly", date(2026, 3, 15), settings)
    # Then it is scoped to the ISO week
    assert p == settings.repo_root / "diary" / "2026" / "W11.md"


def test_summary_path_monthly(settings: Settings) -> None:
    # Given a date
    # When we compute the monthly summary path
    p = summary_path("monthly", date(2026, 3, 15), settings)
    # Then it is scoped to the month
    assert p == settings.repo_root / "diary" / "2026" / "03.md"


def test_summary_path_quarterly(settings: Settings) -> None:
    # Given a date
    # When we compute the quarterly summary path
    p = summary_path("quarterly", date(2026, 3, 15), settings)
    # Then it is scoped to the quarter
    assert p == settings.repo_root / "diary" / "2026" / "Q1.md"


def test_summary_path_yearly(settings: Settings) -> None:
    # Given a date
    # When we compute the yearly summary path
    p = summary_path("yearly", date(2026, 3, 15), settings)
    # Then it is scoped to the year
    assert p == settings.repo_root / "diary" / "2026.md"


# ── Raw I/O ───────────────────────────────────────────────────────────────────


def test_raw_messages_are_stored_and_retrievable(settings: Settings) -> None:
    # Given two messages appended to the raw log
    d = date(2026, 3, 15)
    ts = datetime(2026, 3, 15, 12, 0, tzinfo=UTC)
    append_raw(d, "in", "Hello", ts, settings)
    append_raw(d, "out", "Hi back", ts, settings)

    # When we read the raw log
    entries = read_raw(d, settings)

    # Then both messages are returned with correct direction and content
    assert len(entries) == 2
    assert entries[0] == {"ts": ts.isoformat(), "direction": "in", "text": "Hello"}
    assert entries[1]["direction"] == "out"


def test_read_raw_returns_empty_when_no_messages(settings: Settings) -> None:
    # Given no messages have been written for this date

    # When we read the raw log
    result = read_raw(date(2026, 1, 1), settings)

    # Then an empty list is returned
    assert result == []


def test_append_raw_creates_missing_directories(settings: Settings) -> None:
    # Given a date whose directory path does not yet exist
    d = date(2026, 6, 1)
    ts = datetime(2026, 6, 1, 10, 0, tzinfo=UTC)

    # When we append a message
    p = append_raw(d, "in", "test", ts, settings)

    # Then the file exists
    assert p.exists()


# ── Diary I/O ─────────────────────────────────────────────────────────────────


def test_write_diary_creates_file(settings: Settings) -> None:
    # Given a diary entry
    d = date(2026, 3, 15)

    # When we write it
    p = write_diary(d, "# 2026-03-15\n\nA good day.", settings)

    # Then the file exists with mdformat-normalised content
    assert p.exists()
    assert p.read_text() == "# 2026-03-15\n\nA good day.\n"


def test_write_diary_overwrites_existing_entry(settings: Settings) -> None:
    # Given a diary entry that was already written
    d = date(2026, 3, 15)
    write_diary(d, "First version.", settings)

    # When we write a new version for the same date
    write_diary(d, "Second version.", settings)

    # Then the file contains only the new version
    assert diary_path(d, settings).read_text() == "Second version.\n"


def test_read_recent_diary_returns_empty_when_no_entries(settings: Settings) -> None:
    # Given no diary entries exist

    # When we read recent entries
    result = read_recent_diary(settings)

    # Then an empty list is returned
    assert result == []


def test_read_recent_diary_returns_entries_oldest_first(settings: Settings) -> None:
    # Given entries written out of order
    for d in [date(2026, 3, 13), date(2026, 3, 15), date(2026, 3, 14)]:
        write_diary(d, f"Entry for {d}", settings)

    # When we read recent entries
    entries = read_recent_diary(settings, n=3)

    # Then they are returned in chronological order
    assert "2026-03-13" in entries[0]
    assert "2026-03-15" in entries[2]


def test_read_recent_diary_limits_results_to_n(settings: Settings) -> None:
    # Given 7 diary entries
    for day in range(1, 8):
        write_diary(date(2026, 3, day), f"Day {day}", settings)

    # When we request only 3
    entries = read_recent_diary(settings, n=3)

    # Then only the 3 most recent are returned
    assert len(entries) == 3


# ── Helpers ───────────────────────────────────────────────────────────────────


def test_coalesce_joins_consecutive_messages_from_same_role() -> None:
    # Given two consecutive user messages followed by a model message
    turns = [
        {"role": "user", "text": "Hello"},
        {"role": "user", "text": "Are you there?"},
        {"role": "model", "text": "Yes!"},
    ]

    # When we coalesce the turns
    result = _coalesce(turns)

    # Then the consecutive user messages are merged into one
    assert len(result) == 2
    assert result[0]["text"] == "Hello\nAre you there?"
    assert result[1]["role"] == "model"


def test_coalesce_leaves_alternating_turns_unchanged() -> None:
    # Given turns that already alternate between roles
    turns = [
        {"role": "user", "text": "Hi"},
        {"role": "model", "text": "Hello"},
        {"role": "user", "text": "How are you?"},
    ]

    # When we coalesce
    result = _coalesce(turns)

    # Then nothing is changed
    assert result == turns


@pytest.mark.parametrize(
    "period,ref,candidate,expected",
    [
        ("weekly", date(2026, 3, 15), date(2026, 3, 12), True),  # same ISO week
        ("weekly", date(2026, 3, 15), date(2026, 3, 16), False),  # different week
        ("monthly", date(2026, 3, 15), date(2026, 3, 1), True),
        ("monthly", date(2026, 3, 15), date(2026, 2, 28), False),
        ("quarterly", date(2026, 3, 15), date(2026, 1, 1), True),  # both Q1
        ("quarterly", date(2026, 3, 15), date(2026, 4, 1), False),  # Q2
        ("yearly", date(2026, 3, 15), date(2026, 12, 31), True),
        ("yearly", date(2026, 3, 15), date(2025, 12, 31), False),
    ],
)
def test_date_membership_in_period(period: str, ref: date, candidate: date, expected: bool) -> None:
    # Given a period, a reference date, and a candidate date
    # When we check if the candidate falls within the period
    result = _in_period(candidate, period, ref)
    # Then the result matches the expected membership
    assert result == expected


@pytest.mark.parametrize(
    "period,ref,expected",
    [
        ("weekly", date(2026, 3, 15), "2026-W11"),
        ("monthly", date(2026, 3, 15), "2026-03 (March 2026)"),
        ("quarterly", date(2026, 3, 15), "2026 Q1"),
        ("yearly", date(2026, 3, 15), "2026"),
    ],
)
def test_period_label_format(period: str, ref: date, expected: str) -> None:
    # Given a period and reference date
    # When we generate the label
    label = _period_label(period, ref)
    # Then it matches the expected human-readable format
    assert label == expected


# ── run_poll ──────────────────────────────────────────────────────────────────


def _make_message(text: str = "Hello!", update_id: int = 1) -> Message:
    return Message(
        update_id=update_id,
        message_id=update_id,
        text=text,
        timestamp=datetime(2026, 3, 15, 14, 0, tzinfo=UTC),
    )


@patch("zesty_bakewell.bot.git_commit_push")
def test_poll_sends_proactive_message_at_midday(
    mock_git: MagicMock,
    settings: Settings,
    mock_telegram: MagicMock,
    mock_llm: MagicMock,
) -> None:
    # Given it is midday and no midday message has been sent today
    now = datetime(2026, 3, 15, 12, 5, tzinfo=UTC)
    mock_telegram.get_updates.return_value = []

    # When the poll runs
    run_poll(settings, mock_telegram, mock_llm, now=now)

    # Then a check-in message is sent to the user
    mock_telegram.send_message.assert_called_once()
    assert "day" in mock_telegram.send_message.call_args[0][0].lower()


@patch("zesty_bakewell.bot.git_commit_push")
def test_poll_records_midday_message_as_sent(
    mock_git: MagicMock,
    settings: Settings,
    mock_telegram: MagicMock,
    mock_llm: MagicMock,
) -> None:
    # Given it is midday and no midday message has been sent today
    now = datetime(2026, 3, 15, 12, 5, tzinfo=UTC)
    mock_telegram.get_updates.return_value = []

    # When the poll runs
    run_poll(settings, mock_telegram, mock_llm, now=now)

    # Then today's date is recorded as midday-sent in state
    state = load_state(settings)
    assert state.last_morning_sent == "2026-03-15"


@patch("zesty_bakewell.bot.git_commit_push")
def test_poll_skips_morning_opener_if_conversation_already_started(
    mock_git: MagicMock,
    settings: Settings,
    mock_telegram: MagicMock,
    mock_llm: MagicMock,
) -> None:
    # Given the user already messaged today with no unanswered bot message yesterday
    now = datetime(2026, 3, 15, 12, 5, tzinfo=UTC)
    mock_telegram.get_updates.return_value = []
    append_raw(
        date(2026, 3, 15), "in", "Morning!", datetime(2026, 3, 15, 9, 0, tzinfo=UTC), settings
    )

    # When the poll runs
    run_poll(settings, mock_telegram, mock_llm, now=now)

    # Then the morning opener is not sent
    mock_telegram.send_message.assert_not_called()


@patch("zesty_bakewell.bot.git_commit_push")
def test_poll_sends_morning_opener_if_todays_message_is_reply_to_yesterday(
    mock_git: MagicMock,
    settings: Settings,
    mock_telegram: MagicMock,
    mock_llm: MagicMock,
) -> None:
    # Given yesterday ended with an unanswered bot message, and the user replied today
    now = datetime(2026, 3, 15, 12, 5, tzinfo=UTC)
    mock_telegram.get_updates.return_value = []
    append_raw(
        date(2026, 3, 14),
        "out",
        "How's your evening?",
        datetime(2026, 3, 14, 19, 0, tzinfo=UTC),
        settings,
    )
    append_raw(
        date(2026, 3, 15),
        "in",
        "Was good thanks",
        datetime(2026, 3, 15, 8, 0, tzinfo=UTC),
        settings,
    )

    # When the poll runs
    run_poll(settings, mock_telegram, mock_llm, now=now)

    # Then the morning opener is still sent
    mock_telegram.send_message.assert_called_once()
    assert "day" in mock_telegram.send_message.call_args[0][0].lower()


@patch("zesty_bakewell.bot.git_commit_push")
def test_poll_sends_evening_opener_if_user_replied_today(
    mock_git: MagicMock,
    settings: Settings,
    mock_telegram: MagicMock,
    mock_llm: MagicMock,
) -> None:
    # Given the user has already replied to the morning opener
    now = datetime(2026, 3, 15, 20, 0, tzinfo=UTC)
    mock_telegram.get_updates.return_value = []
    append_raw(
        date(2026, 3, 15),
        "in",
        "Good day so far",
        datetime(2026, 3, 15, 12, 0, tzinfo=UTC),
        settings,
    )

    # When the poll runs
    run_poll(settings, mock_telegram, mock_llm, now=now)

    # Then the evening opener is sent
    mock_telegram.send_message.assert_called_once()
    assert "day" in mock_telegram.send_message.call_args[0][0].lower()


@patch("zesty_bakewell.bot.git_commit_push")
def test_poll_skips_evening_opener_if_user_has_not_replied_today(
    mock_git: MagicMock,
    settings: Settings,
    mock_telegram: MagicMock,
    mock_llm: MagicMock,
) -> None:
    # Given the morning opener was sent but the user never replied
    now = datetime(2026, 3, 15, 20, 0, tzinfo=UTC)
    mock_telegram.get_updates.return_value = []
    save_state(PollState(last_morning_sent="2026-03-15"), settings)

    # When the poll runs
    run_poll(settings, mock_telegram, mock_llm, now=now)

    # Then the evening opener is not sent
    mock_telegram.send_message.assert_not_called()


@patch("zesty_bakewell.bot.git_commit_push")
def test_poll_does_not_reply_when_model_returns_no_reply(
    mock_git: MagicMock,
    settings: Settings,
    mock_telegram: MagicMock,
    mock_llm: MagicMock,
) -> None:
    # Given the model judges no reply is needed
    now = datetime(2026, 3, 15, 9, 0, tzinfo=UTC)
    mock_llm.reply.return_value = "NO_REPLY"
    mock_telegram.get_updates.return_value = [_make_message("👍")]

    # When the poll runs
    run_poll(settings, mock_telegram, mock_llm, now=now)

    # Then no message is sent to the user
    mock_telegram.send_message.assert_not_called()


@patch("zesty_bakewell.bot.git_commit_push")
def test_poll_does_not_send_midday_message_twice(
    mock_git: MagicMock,
    settings: Settings,
    mock_telegram: MagicMock,
    mock_llm: MagicMock,
) -> None:
    # Given midday has already been sent today
    now = datetime(2026, 3, 15, 12, 5, tzinfo=UTC)
    mock_telegram.get_updates.return_value = []
    save_state(PollState(last_morning_sent="2026-03-15"), settings)

    # When the poll runs
    run_poll(settings, mock_telegram, mock_llm, now=now)

    # Then no message is sent
    mock_telegram.send_message.assert_not_called()


@patch("zesty_bakewell.bot.git_commit_push")
def test_poll_sends_ai_reply_to_incoming_message(
    mock_git: MagicMock,
    settings: Settings,
    mock_telegram: MagicMock,
    mock_llm: MagicMock,
) -> None:
    # Given an incoming message from the user
    now = datetime(2026, 3, 15, 9, 0, tzinfo=UTC)
    mock_telegram.get_updates.return_value = [_make_message("How are you?")]

    # When the poll runs
    run_poll(settings, mock_telegram, mock_llm, now=now)

    # Then the AI-generated reply is sent back to the user
    mock_telegram.send_message.assert_called_once_with(mock_llm.reply.return_value)


@patch("zesty_bakewell.bot.git_commit_push")
def test_poll_saves_inbound_message_to_raw_transcript(
    mock_git: MagicMock,
    settings: Settings,
    mock_telegram: MagicMock,
    mock_llm: MagicMock,
) -> None:
    # Given an incoming message
    now = datetime(2026, 3, 15, 9, 0, tzinfo=UTC)
    mock_telegram.get_updates.return_value = [_make_message("Good morning")]

    # When the poll runs
    run_poll(settings, mock_telegram, mock_llm, now=now)

    # Then the inbound message is saved to the raw transcript
    raw = read_raw(date(2026, 3, 15), settings)
    assert any(e["direction"] == "in" and e["text"] == "Good morning" for e in raw)


@patch("zesty_bakewell.bot.git_commit_push")
def test_poll_saves_outbound_reply_to_raw_transcript(
    mock_git: MagicMock,
    settings: Settings,
    mock_telegram: MagicMock,
    mock_llm: MagicMock,
) -> None:
    # Given an incoming message
    now = datetime(2026, 3, 15, 9, 0, tzinfo=UTC)
    mock_telegram.get_updates.return_value = [_make_message("Good morning")]

    # When the poll runs
    run_poll(settings, mock_telegram, mock_llm, now=now)

    # Then the bot's reply is also saved to the raw transcript
    raw = read_raw(date(2026, 3, 15), settings)
    assert any(e["direction"] == "out" for e in raw)


@patch("zesty_bakewell.bot.git_commit_push")
def test_poll_advances_update_id_after_processing_message(
    mock_git: MagicMock,
    settings: Settings,
    mock_telegram: MagicMock,
    mock_llm: MagicMock,
) -> None:
    # Given an incoming message with a known update_id
    now = datetime(2026, 3, 15, 9, 0, tzinfo=UTC)
    mock_telegram.get_updates.return_value = [_make_message(update_id=77)]

    # When the poll runs
    run_poll(settings, mock_telegram, mock_llm, now=now)

    # Then the state records the processed update_id
    state = load_state(settings)
    assert state.last_update_id == 77


@patch("zesty_bakewell.bot.git_commit_push")
def test_poll_does_not_commit_when_nothing_happened(
    mock_git: MagicMock,
    settings: Settings,
    mock_telegram: MagicMock,
    mock_llm: MagicMock,
) -> None:
    # Given no new messages and no proactive window
    now = datetime(2026, 3, 15, 9, 0, tzinfo=UTC)
    mock_telegram.get_updates.return_value = []

    # When the poll runs
    run_poll(settings, mock_telegram, mock_llm, now=now)

    # Then nothing is committed to git
    mock_git.assert_not_called()


# ── run_nightly ───────────────────────────────────────────────────────────────


@patch("zesty_bakewell.bot.git_commit_push")
def test_nightly_writes_diary_file(
    mock_git: MagicMock, settings: Settings, mock_llm: MagicMock
) -> None:
    # Given messages exist for the target date
    d = date(2026, 3, 15)
    append_raw(d, "in", "Had a great day", datetime(2026, 3, 15, 14, 0, tzinfo=UTC), settings)

    # When the nightly job runs
    run_nightly(settings, mock_llm, d)

    # Then a diary file is created
    assert diary_path(d, settings).exists()


@patch("zesty_bakewell.bot.git_commit_push")
def test_nightly_commits_diary_to_git(
    mock_git: MagicMock, settings: Settings, mock_llm: MagicMock
) -> None:
    # Given messages exist for the target date
    d = date(2026, 3, 15)
    append_raw(d, "in", "Had a great day", datetime(2026, 3, 15, 14, 0, tzinfo=UTC), settings)

    # When the nightly job runs
    run_nightly(settings, mock_llm, d)

    # Then the diary file is committed
    mock_git.assert_called_once()


@patch("zesty_bakewell.bot.git_commit_push")
def test_nightly_skips_when_no_messages(
    mock_git: MagicMock, settings: Settings, mock_llm: MagicMock
) -> None:
    # Given no messages exist for the target date

    # When the nightly job runs
    run_nightly(settings, mock_llm, date(2026, 3, 15))

    # Then no diary is generated and nothing is committed
    mock_llm.generate.assert_not_called()
    mock_git.assert_not_called()


@patch("zesty_bakewell.bot.git_commit_push")
def test_nightly_includes_recent_diary_entries_in_prompt(
    mock_git: MagicMock, settings: Settings, mock_llm: MagicMock
) -> None:
    # Given a message for today and a diary entry from yesterday
    d = date(2026, 3, 15)
    append_raw(d, "in", "Today's message", datetime(2026, 3, 15, 14, 0, tzinfo=UTC), settings)
    write_diary(date(2026, 3, 14), "# 2026-03-14\n\nYesterday was good.", settings)

    # When the nightly job runs
    run_nightly(settings, mock_llm, d)

    # Then yesterday's diary content is included in the generation prompt
    prompt = mock_llm.generate.call_args[0][0]
    assert "Yesterday was good" in prompt


# ── run_summarize ─────────────────────────────────────────────────────────────


@patch("zesty_bakewell.bot.git_commit_push")
def test_summarize_writes_summary_file(
    mock_git: MagicMock, settings: Settings, mock_llm: MagicMock
) -> None:
    # Given diary entries exist within the target week
    for d in [date(2026, 3, 10), date(2026, 3, 11), date(2026, 3, 12)]:
        write_diary(d, f"# {d}\n\nEntry.", settings)

    # When the weekly summary runs
    run_summarize(settings, mock_llm, "weekly", date(2026, 3, 12))

    # Then a summary file is created at the correct path
    assert summary_path("weekly", date(2026, 3, 12), settings).exists()


@patch("zesty_bakewell.bot.git_commit_push")
def test_summarize_commits_summary_to_git(
    mock_git: MagicMock, settings: Settings, mock_llm: MagicMock
) -> None:
    # Given diary entries exist within the target week
    for d in [date(2026, 3, 10), date(2026, 3, 11), date(2026, 3, 12)]:
        write_diary(d, f"# {d}\n\nEntry.", settings)

    # When the weekly summary runs
    run_summarize(settings, mock_llm, "weekly", date(2026, 3, 12))

    # Then the summary is committed
    mock_git.assert_called_once()


@patch("zesty_bakewell.bot.git_commit_push")
def test_summarize_skips_when_no_diary_entries(
    mock_git: MagicMock, settings: Settings, mock_llm: MagicMock
) -> None:
    # Given no diary entries exist for the period

    # When the summary runs
    run_summarize(settings, mock_llm, "weekly", date(2026, 3, 15))

    # Then no summary is generated and nothing is committed
    mock_llm.generate.assert_not_called()
    mock_git.assert_not_called()
