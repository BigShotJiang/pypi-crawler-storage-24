"""CLI entry point for vibe-journal."""

from __future__ import annotations

from datetime import datetime

import click

from .bot import Settings, run_nightly, run_poll, run_summarize
from .gemini import GeminiAdapter
from .telegram import TelegramClient


@click.group()
def cli() -> None:
    """vibe-journal: your AI journaling companion."""


@cli.command()
def poll() -> None:
    """Poll Telegram for new messages and respond. Run on a cron every 10 minutes."""
    settings = Settings()
    with TelegramClient(settings.telegram_bot_token, settings.telegram_chat_id) as tg:
        llm = GeminiAdapter(api_key=settings.gemini_api_key, model=settings.gemini_model)
        run_poll(settings, tg, llm)


@cli.command()
@click.option(
    "--date",
    "target_date",
    type=click.DateTime(formats=["%Y-%m-%d"]),
    default=None,
    help="Date to generate diary for (default: yesterday).",
)
def nightly(target_date: datetime | None) -> None:
    """Generate the diary entry for yesterday (or a given date)."""
    settings = Settings()
    llm = GeminiAdapter(api_key=settings.gemini_api_key, model=settings.gemini_model)
    run_nightly(settings, llm, target_date.date() if target_date else None)


@cli.command()
@click.argument("period", type=click.Choice(["weekly", "monthly", "quarterly", "yearly"]))
@click.option(
    "--date",
    "ref_date",
    type=click.DateTime(formats=["%Y-%m-%d"]),
    default=None,
    help="Reference date within the period (default: yesterday).",
)
def summarize(period: str, ref_date: datetime | None) -> None:
    """Generate a summary for the given period (weekly, monthly, quarterly, yearly)."""
    settings = Settings()
    llm = GeminiAdapter(api_key=settings.gemini_api_key, model=settings.gemini_model)
    run_summarize(settings, llm, period, ref_date.date() if ref_date else None)
