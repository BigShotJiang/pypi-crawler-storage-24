"""Thin wrapper around the Telegram Bot API."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime

import httpx


class TelegramError(Exception):
    pass


@dataclass
class Message:
    update_id: int
    message_id: int
    text: str
    timestamp: datetime


class TelegramClient:
    def __init__(self, token: str, chat_id: int) -> None:
        self._chat_id = chat_id
        self._http = httpx.Client(
            base_url=f"https://api.telegram.org/bot{token}",
            timeout=30,
        )

    def get_updates(self, offset: int = 0) -> list[Message]:
        """Fetch updates from Telegram, filtered to the configured chat."""
        resp = self._http.get("/getUpdates", params={"offset": offset, "timeout": 0})
        _raise_for_status(resp)

        messages = []
        for update in resp.json().get("result", []):
            msg = update.get("message", {})
            if not msg:
                continue
            if msg.get("chat", {}).get("id") != self._chat_id:
                continue
            text = msg.get("text", "")
            if not text:
                continue
            messages.append(
                Message(
                    update_id=update["update_id"],
                    message_id=msg["message_id"],
                    text=text,
                    timestamp=datetime.fromtimestamp(msg["date"], tz=UTC),
                )
            )
        return messages

    def send_message(self, text: str) -> None:
        resp = self._http.post(
            "/sendMessage",
            json={"chat_id": self._chat_id, "text": text, "parse_mode": "Markdown"},
        )
        _raise_for_status(resp)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> TelegramClient:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


def _raise_for_status(resp: httpx.Response) -> None:
    if not resp.is_success:
        raise TelegramError(f"Telegram API {resp.status_code}: {resp.text}")
