"""Core business logic: settings, state, storage, git, prompts, and orchestration."""

from __future__ import annotations

import json
import subprocess
from dataclasses import asdict, dataclass, fields
from datetime import UTC, date, datetime, timedelta
from pathlib import Path
from typing import Literal

import mdformat
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from .llm import LLMClient, Turn
from .telegram import TelegramClient

MDFORMAT_OPTIONS: dict[str, int] = {"wrap": 80}

# ── Settings ──────────────────────────────────────────────────────────────────


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    telegram_bot_token: str = ""
    telegram_chat_id: int = 0
    gemini_api_key: str = ""
    gemini_model: str = "gemini-3-flash-preview"

    git_author_name: str = "vibe-journal bot"
    git_author_email: str = "bot@vibe-journal.local"

    # UTC hour (0–23) at which the bot sends a proactive check-in
    morning_hour_utc: int = 11
    evening_hour_utc: int = 19

    # How many recent diary entries to include as context for generation
    diary_context_days: int = 7

    # Repo root — override in tests via tmp_path
    repo_root: Path = Field(default_factory=Path.cwd)


# ── Poll state ────────────────────────────────────────────────────────────────


@dataclass
class PollState:
    last_update_id: int = 0
    last_morning_sent: str | None = None  # ISO date, e.g. "2026-03-15"
    last_evening_sent: str | None = None  # ISO date


def _state_path(settings: Settings) -> Path:
    return settings.repo_root / "state" / "poll_state.json"


def load_state(settings: Settings) -> PollState:
    p = _state_path(settings)
    if not p.exists():
        return PollState()
    known = {f.name for f in fields(PollState)}
    data = {k: v for k, v in json.loads(p.read_text()).items() if k in known}
    return PollState(**data)


def save_state(state: PollState, settings: Settings) -> None:
    p = _state_path(settings)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(asdict(state), indent=2))


# ── Storage paths ─────────────────────────────────────────────────────────────


def raw_path(d: date, settings: Settings) -> Path:
    return settings.repo_root / "raw" / str(d.year) / f"{d.month:02d}" / f"{d.isoformat()}.jsonl"


def diary_path(d: date, settings: Settings) -> Path:
    return (
        settings.repo_root
        / "diary"
        / str(d.year)
        / f"{d.month:02d}"
        / f"{d.isoformat()}-{d.strftime('%A')}.md"
    )


def summary_path(period: str, ref: date, settings: Settings) -> Path:
    root = settings.repo_root / "diary"
    match period:
        case "weekly":
            _, week, _ = ref.isocalendar()
            return root / str(ref.year) / f"W{week:02d}.md"
        case "monthly":
            return root / str(ref.year) / f"{ref.month:02d}.md"
        case "quarterly":
            q = (ref.month - 1) // 3 + 1
            return root / str(ref.year) / f"Q{q}.md"
        case "yearly":
            return root / f"{ref.year}.md"
        case _:
            raise ValueError(f"Unknown period: {period!r}")


# ── Raw transcript I/O ────────────────────────────────────────────────────────


def append_raw(
    d: date,
    direction: Literal["in", "out"],
    text: str,
    timestamp: datetime,
    settings: Settings,
) -> Path:
    p = raw_path(d, settings)
    p.parent.mkdir(parents=True, exist_ok=True)
    entry = json.dumps({"ts": timestamp.isoformat(), "direction": direction, "text": text})
    with p.open("a") as f:
        f.write(entry + "\n")
    return p


def read_raw(d: date, settings: Settings) -> list[dict[str, str]]:
    p = raw_path(d, settings)
    if not p.exists():
        return []
    return [json.loads(line) for line in p.read_text().splitlines() if line.strip()]


# ── Diary I/O ─────────────────────────────────────────────────────────────────


def write_diary(d: date, content: str, settings: Settings) -> Path:
    p = diary_path(d, settings)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(mdformat.text(content, options=MDFORMAT_OPTIONS))
    return p


def read_recent_diary(settings: Settings, n: int | None = None) -> list[str]:
    """Return the n most recent daily diary entries, oldest first."""
    n = n or settings.diary_context_days
    diary_dir = settings.repo_root / "diary"
    if not diary_dir.exists():
        return []
    # Match only daily files (YYYY-MM-DD-Weekday.md), not summaries
    paths = sorted(diary_dir.rglob("????-??-??-*.md"))
    return [p.read_text() for p in paths[-n:]]


def write_summary(period: str, ref: date, content: str, settings: Settings) -> Path:
    p = summary_path(period, ref, settings)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(mdformat.text(content, options=MDFORMAT_OPTIONS))
    return p


# ── Git ops ───────────────────────────────────────────────────────────────────


class GitError(Exception):
    pass


def git_commit_push(paths: list[Path], message: str, settings: Settings) -> None:
    def run(cmd: list[str]) -> None:
        result = subprocess.run(cmd, cwd=settings.repo_root, capture_output=True, text=True)
        if result.returncode != 0:
            raise GitError(f"{' '.join(cmd)}\n{result.stderr.strip()}")

    for p in paths:
        run(["git", "add", str(p)])
    run(
        [
            "git",
            "-c",
            f"user.name={settings.git_author_name}",
            "-c",
            f"user.email={settings.git_author_email}",
            "commit",
            "-m",
            message,
        ]
    )
    run(["git", "push"])


# ── Prompts ───────────────────────────────────────────────────────────────────

NO_REPLY = "NO_REPLY"

CHAT_SYSTEM_PROMPT = """\
You are a journaling companion checking in over text. Be brief and natural.
- One or two sentences per reply at most.
- Only ask a follow-up question if it flows naturally from what was said. Never force one.
- No filler, no enthusiasm padding ("That sounds amazing!", "How exciting!").
- Don't mirror back what was just said.
- Plain, direct language.
- If the message is a natural conversation ender or needs no response (e.g. "ok", "thanks", "bye", \
a reaction emoji), reply with exactly the word: NO_REPLY\
"""

MORNING_OPENER = "Hey! How's your day going so far?"
EVENING_OPENER = "Hey, how did the rest of your day go? Anything on your mind tonight?"

DIARY_PROMPT = """\
Write a diary entry for {date} based on the conversation below.

<conversation>
{transcript}
</conversation>
{context_block}
Rules:
- First person, markdown, heading: # {date}
- Match the length to the content. A quiet day with little to report should be a short entry.
- No filler phrases ("Today was a day of...", "It was a reminder that..."). Just say what happened.
- Plain, direct language. No flowery prose.\
"""

SUMMARY_PROMPT = """\
Write a {period} summary covering {label}.

<entries>
{entries}
</entries>

Rules:
- First person, markdown, heading: # {label}
- Only include what actually stands out. If it was a routine period, say so briefly.
- No padding. Length should reflect how much actually happened.
- Plain language. No flowery prose.\
"""


# ── Helpers ───────────────────────────────────────────────────────────────────


def _fresh_conversation_today(today: date, settings: Settings) -> bool:
    """True if the user started a fresh conversation today, not continuing yesterday's thread."""
    today_entries = read_raw(today, settings)
    if not any(e["direction"] == "in" for e in today_entries):
        return False
    # If yesterday ended with an unanswered bot message, today's messages are a continuation
    yesterday_entries = read_raw(today - timedelta(days=1), settings)
    return not (yesterday_entries and yesterday_entries[-1]["direction"] == "out")


def _user_has_replied_today(today: date, settings: Settings) -> bool:
    """True if the user has sent at least one message today."""
    return any(e["direction"] == "in" for e in read_raw(today, settings))


def _proactive_message(state: PollState, now: datetime, settings: Settings) -> str | None:
    """Return a proactive opener if we're in the right time window and haven't sent one today."""
    today = now.date()
    today_iso = today.isoformat()
    if (
        now.hour >= settings.morning_hour_utc
        and state.last_morning_sent != today_iso
        and not _fresh_conversation_today(today, settings)
    ):
        return MORNING_OPENER
    if (
        now.hour >= settings.evening_hour_utc
        and state.last_evening_sent != today_iso
        and _user_has_replied_today(today, settings)
    ):
        return EVENING_OPENER
    return None


def _coalesce(turns: list[Turn]) -> list[Turn]:
    """Merge consecutive turns with the same role (handles rapid multi-message sends)."""
    result: list[Turn] = []
    for turn in turns:
        if result and result[-1]["role"] == turn["role"]:
            result[-1] = {
                "role": turn["role"],
                "text": result[-1]["text"] + "\n" + turn["text"],
            }
        else:
            result.append(dict(turn))
    return result


def _transcript(entries: list[dict[str, str]]) -> str:
    lines = []
    for e in entries:
        speaker = "Me" if e["direction"] == "in" else "Bot"
        lines.append(f"[{e['ts']}] {speaker}: {e['text']}")
    return "\n".join(lines)


def _period_label(period: str, ref: date) -> str:
    match period:
        case "weekly":
            _, week, _ = ref.isocalendar()
            return f"{ref.year}-W{week:02d}"
        case "monthly":
            return ref.strftime("%Y-%m (%B %Y)")
        case "quarterly":
            q = (ref.month - 1) // 3 + 1
            return f"{ref.year} Q{q}"
        case "yearly":
            return str(ref.year)
        case _:
            raise ValueError(f"Unknown period: {period!r}")


def _entries_for_period(period: str, ref: date, settings: Settings) -> list[str]:
    diary_dir = settings.repo_root / "diary"
    if not diary_dir.exists():
        return []
    result = []
    for p in sorted(diary_dir.rglob("????-??-??-*.md")):
        try:
            d = date.fromisoformat(p.stem[:10])
        except ValueError:
            continue
        if _in_period(d, period, ref):
            result.append(p.read_text())
    return result


def _in_period(d: date, period: str, ref: date) -> bool:
    match period:
        case "weekly":
            return d.isocalendar()[:2] == ref.isocalendar()[:2]
        case "monthly":
            return d.year == ref.year and d.month == ref.month
        case "quarterly":
            return d.year == ref.year and (d.month - 1) // 3 == (ref.month - 1) // 3
        case "yearly":
            return d.year == ref.year
        case _:
            return False


# ── Orchestration ─────────────────────────────────────────────────────────────


def run_poll(
    settings: Settings,
    telegram: TelegramClient,
    gemini: LLMClient,
    now: datetime | None = None,
) -> None:
    now = now or datetime.now(tz=UTC)
    today = now.date()
    state = load_state(settings)
    changed: list[Path] = []

    # 1. Send proactive opener if in the right time window
    opener = _proactive_message(state, now, settings)
    if opener:
        telegram.send_message(opener)
        changed.append(append_raw(today, "out", opener, now, settings))
        if opener == MORNING_OPENER:
            state.last_morning_sent = today.isoformat()
        else:
            state.last_evening_sent = today.isoformat()

    # 2. Fetch new messages
    messages = telegram.get_updates(offset=state.last_update_id + 1)
    for msg in messages:
        p = append_raw(today, "in", msg.text, msg.timestamp, settings)
        if p not in changed:
            changed.append(p)
        state.last_update_id = msg.update_id

    # 3. Reply to new messages
    if messages:
        raw = read_raw(today, settings)
        turns = _coalesce(
            [
                {
                    "role": "user" if e["direction"] == "in" else "model",
                    "text": e["text"],
                }
                for e in raw
            ]
        )
        # Last turn should be the user's; pass preceding turns as history
        if turns and turns[-1]["role"] == "user":
            user_msg = turns[-1]["text"]
            history = turns[:-1]
        else:
            user_msg = messages[-1].text
            history = turns

        reply_text = gemini.reply(CHAT_SYSTEM_PROMPT, history, user_msg)
        if reply_text.strip() != NO_REPLY:
            telegram.send_message(reply_text)
            p = append_raw(today, "out", reply_text, datetime.now(tz=UTC), settings)
            if p not in changed:
                changed.append(p)

    # 4. Commit if anything changed
    if changed:
        save_state(state, settings)
        changed.append(_state_path(settings))
        git_commit_push(changed, f"journal: {today.isoformat()}", settings)


def run_nightly(
    settings: Settings,
    gemini: LLMClient,
    target_date: date | None = None,
) -> None:
    """Generate and commit the diary entry for yesterday (or a specified date)."""
    target_date = target_date or date.today() - timedelta(days=1)
    raw = read_raw(target_date, settings)
    if not raw:
        print(f"No messages for {target_date}, skipping.")
        return

    transcript = _transcript(raw)
    recent = read_recent_diary(settings)
    context_block = ""
    if recent:
        joined = "\n---\n".join(recent[-3:])
        context_block = (
            f"\n\n<recent_entries>\n{joined}\n</recent_entries>\n\n"
            "Use these for context but focus on today.\n"
        )

    prompt = DIARY_PROMPT.format(
        date=target_date.isoformat(),
        transcript=transcript,
        context_block=context_block,
    )
    content = gemini.generate(prompt)
    p = write_diary(target_date, content, settings)
    git_commit_push([p], f"diary: {target_date.isoformat()}", settings)
    print(f"Diary entry written: {p}")


def run_summarize(
    settings: Settings,
    gemini: LLMClient,
    period: str,
    ref_date: date | None = None,
) -> None:
    """Generate and commit a summary for the given period."""
    ref_date = ref_date or date.today() - timedelta(days=1)
    entries = _entries_for_period(period, ref_date, settings)
    if not entries:
        print(f"No diary entries for {period} ending {ref_date}, skipping.")
        return

    label = _period_label(period, ref_date)
    prompt = SUMMARY_PROMPT.format(
        period=period,
        label=label,
        entries="\n---\n".join(entries),
    )
    content = gemini.generate(prompt)
    p = write_summary(period, ref_date, content, settings)
    git_commit_push([p], f"summary: {label}", settings)
    print(f"Summary written: {p}")
