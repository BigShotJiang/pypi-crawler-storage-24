"""LLMClient — the port through which the application talks to a language model."""

from __future__ import annotations

from abc import ABC, abstractmethod

# Conversation turn: role is "user" or "model" (Gemini's terminology)
type Turn = dict[str, str]  # {"role": ..., "text": ...}


class LLMClient(ABC):
    """Abstract base class defining the interface for language model backends."""

    @abstractmethod
    def reply(self, system_prompt: str, history: list[Turn], user_message: str) -> str:
        """Generate a conversational reply given history and a new user message."""
        ...

    @abstractmethod
    def generate(self, prompt: str) -> str:
        """One-shot text generation (used for diary entries and summaries)."""
        ...
