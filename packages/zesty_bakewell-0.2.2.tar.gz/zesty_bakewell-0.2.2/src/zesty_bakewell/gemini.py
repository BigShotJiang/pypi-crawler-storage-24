"""GeminiAdapter — implements LLMClient using the Google Gemini API."""

from __future__ import annotations

from google import genai
from google.genai import types

from .llm import LLMClient, Turn


class GeminiAdapter(LLMClient):
    def __init__(self, api_key: str, model: str) -> None:
        self._client = genai.Client(api_key=api_key)
        self._model = model

    def reply(self, system_prompt: str, history: list[Turn], user_message: str) -> str:
        contents: list[types.Content] = [
            types.Content(role=turn["role"], parts=[types.Part(text=turn["text"])])
            for turn in history
        ]
        contents.append(types.Content(role="user", parts=[types.Part(text=user_message)]))
        response = self._client.models.generate_content(
            model=self._model,
            config=types.GenerateContentConfig(system_instruction=system_prompt),
            contents=contents,
        )
        return str(response.text)

    def generate(self, prompt: str) -> str:
        response = self._client.models.generate_content(
            model=self._model,
            contents=prompt,
        )
        return str(response.text)
