# Changelog

## [0.2.2](https://github.com/Michael-JB/zesty-bakewell/compare/v0.2.1...v0.2.2) (2026-03-21)


### Documentation

* desc ([c854dbb](https://github.com/Michael-JB/zesty-bakewell/commit/c854dbb222fc12743a9dba68e1ccbfd0265da438))

## [0.2.1](https://github.com/Michael-JB/zesty-bakewell/compare/v0.2.0...v0.2.1) (2026-03-21)


### Bug Fixes

* add contents: read permission to publish job ([4f2351d](https://github.com/Michael-JB/zesty-bakewell/commit/4f2351dbccd93ccd746024fb78db48005860ffc9))

## [0.2.0](https://github.com/Michael-JB/zesty-bakewell/compare/v0.1.0...v0.2.0) (2026-03-21)


### Features

* initial release ([b745a21](https://github.com/Michael-JB/zesty-bakewell/commit/b745a21b11dfc6f20c99c4d58d60792704dafbee))
