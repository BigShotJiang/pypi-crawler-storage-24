#!/usr/bin/env bash

set -euo pipefail

echo "Running tests..."
uv run pytest

echo "All tests passed!"
