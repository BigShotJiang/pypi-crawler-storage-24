#!/usr/bin/env bash

set -euo pipefail

echo "Linting and formatting..."
format_args=(--diff)
check_args=()
if [ "${1-}" == "--fix" ]; then
  format_args=()
  check_args=(--fix --unsafe-fixes --show-fixes)
fi
uv run ruff format . "${format_args[@]+"${format_args[@]}"}"
uv run ruff check . "${check_args[@]+"${check_args[@]}"}"

echo "Checking types..."
uv run mypy .

echo "Checking shell scripts..."
git ls-files | grep '.*\.sh$' | xargs uv run shellcheck -x

echo "Checking for trailing whitespace..."
# -I skips binary files
if [ "${1-}" == "--fix" ]; then
  git grep --files-with-matches -I '[[:space:]]$' | xargs sed -i '' 's/[[:space:]]*$//' || true
else
  git grep --line-number -I '[[:space:]]$' && exit 1
fi

echo "All checks passed!"
