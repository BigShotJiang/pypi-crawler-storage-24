"""cwatcher CLI entry point."""

from __future__ import annotations

import sys
from pathlib import Path

import click

from cwatcher.api import CWatcherClient
from cwatcher.discover import FRAMEWORK_FILES, discover_files


@click.command()
@click.option(
    "--api-key", "-k",
    envvar="CWATCHER_API_KEY",
    required=True,
    help="API key (env: CWATCHER_API_KEY).",
)
@click.option(
    "--server", "-s",
    envvar="CWATCHER_SERVER",
    default="http://localhost:1954",
    show_default=True,
    help="ComplianceWatcher server URL (env: CWATCHER_SERVER).",
)
@click.option(
    "--project-id", "-p",
    type=int,
    default=None,
    help="Project ID to scan. If omitted, an interactive list is shown.",
)
@click.option(
    "--directory", "-d",
    type=click.Path(exists=True, file_okay=False, path_type=Path),
    default=None,
    help="Directory to search for dependency files (default: current directory).",
)
@click.option(
    "--no-wait",
    is_flag=True,
    default=False,
    help="Submit scans and exit immediately without polling for results.",
)
@click.version_option(package_name="cwatcher")
def main(
    api_key: str,
    server: str,
    project_id: int | None,
    directory: Path | None,
    no_wait: bool,
) -> None:
    """ComplianceWatcher CLI — submit dependency scans via API key."""

    client = CWatcherClient(server=server, api_key=api_key)
    root   = directory or Path.cwd()

    try:
        me = client.verify()
    except Exception as exc:
        click.echo(f"Authentication failed: {exc}", err=True)
        sys.exit(1)

    click.echo(f"Authenticated as {me['username']} ({me['projects_count']} project(s))")

    try:
        projects = client.list_projects()
    except Exception as exc:
        click.echo(f"Failed to fetch projects: {exc}", err=True)
        sys.exit(1)

    if not projects:
        click.echo("No projects found. Create one via the web UI first.", err=True)
        sys.exit(1)

    if project_id is not None:
        project = next((p for p in projects if p["id"] == project_id), None)
        if project is None:
            click.echo(f"Project {project_id} not found or not owned by you.", err=True)
            sys.exit(1)
    else:
        project = _pick_project_interactive(projects)

    framework = project["framework"]
    click.echo(f"Project: [{project['id']}] {project['name']} — framework: {framework}")

    all_found = discover_files(framework, root=root)
    if not all_found:
        expected = ", ".join(FRAMEWORK_FILES.get(framework, []))
        click.echo(
            f"No dependency files found for framework '{framework}' under {root}.\n"
            f"Expected files: {expected}",
            err=True,
        )
        sys.exit(1)

    if project_id is not None:
        selected = all_found
    else:
        selected = _pick_files_interactive(all_found, root)

    if not selected:
        click.echo("No files selected. Exiting.")
        sys.exit(0)

    click.echo(f"\nUploading {len(selected)} file(s):")
    for f in selected:
        try:
            rel = f.relative_to(root)
        except ValueError:
            rel = f
        click.echo(f"  {rel}")

    try:
        result = client.submit_scans(project["id"], selected)
    except Exception as exc:
        click.echo(f"Upload failed: {exc}", err=True)
        sys.exit(1)

    for w in result.get("warnings", []):
        click.echo(f"Warning: {w}")

    scan_ids: list[int] = result.get("scan_ids", [])
    batch_url: str | None = result.get("batch_url")

    click.echo(f"Scans started: {scan_ids}")
    if batch_url:
        click.echo(f"View all results: {batch_url}")

    if no_wait:
        click.echo("Exiting (--no-wait). Check results in the web UI.")
        return

    for scan_id in scan_ids:
        click.echo(f"\nPolling scan {scan_id}...")
        try:
            _poll_with_progress(client, scan_id)
        except TimeoutError as exc:
            click.echo(f"  Timeout: {exc}", err=True)
        except Exception as exc:
            click.echo(f"  Error: {exc}", err=True)



def _pick_project_interactive(projects: list[dict]) -> dict:
    click.echo("\nAvailable projects:")
    for i, p in enumerate(projects, 1):
        click.echo(f"  [{i}] {p['name']}  (id={p['id']}, framework={p['framework']})")
    while True:
        raw = click.prompt("Select project number", type=str)
        try:
            idx = int(raw) - 1
            if 0 <= idx < len(projects):
                return projects[idx]
        except ValueError:
            pass
        click.echo(f"Enter a number between 1 and {len(projects)}.")


def _pick_files_interactive(found: list[Path], root: Path) -> list[Path]:
    click.echo("\nFound dependency files:")
    for i, f in enumerate(found, 1):
        try:
            rel = f.relative_to(root)
        except ValueError:
            rel = f
        click.echo(f"  [{i}] {rel}")
    raw = click.prompt(
        "Files to upload (comma/space-separated numbers, or 'all')",
        default="all",
    )
    if raw.strip().lower() == "all":
        return found
    selected = []
    for token in raw.replace(",", " ").split():
        try:
            idx = int(token) - 1
            if 0 <= idx < len(found):
                selected.append(found[idx])
        except ValueError:
            pass
    return selected


def _poll_with_progress(client: CWatcherClient, scan_id: int) -> None:
    last_pct = -1

    def on_poll(data: dict) -> None:
        nonlocal last_pct
        pct = data.get("progress_pct", 0)
        if pct != last_pct:
            last_pct = pct
            status = data.get("status", "?")
            scanned = data.get("scanned_packages", 0)
            total   = data.get("total_packages", 0)
            click.echo(f"  [{status}] {pct}%  ({scanned}/{total} packages)")

    final = client.poll_scan(scan_id, callback=on_poll, timeout=300)
    status = final["status"]

    if status == "COMPLETED":
        vuln_count = final.get("vulnerable_count", 0)
        total      = final.get("total_packages", 0)
        duration   = final.get("duration_seconds") or 0
        click.echo(
            f"  Done in {duration:.1f}s — "
            f"{vuln_count} vulnerabilities across {total} packages."
        )
        if vuln_count > 0:
            click.echo("  Review details in the web UI.")
    elif status == "FAILED":
        click.echo(f"  Scan FAILED: {final.get('error_message', 'unknown error')}", err=True)
