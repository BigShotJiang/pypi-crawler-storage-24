"""File discovery: walk a directory tree for known dependency files."""

import os
from pathlib import Path

FRAMEWORK_FILES: dict[str, list[str]] = {
    "WEB_DEV":    ["package.json", "package-lock.json", "composer.json", "composer.lock"],
    "MOBILE_DEV": ["pubspec.yaml", "pubspec.lock"],
    "PYTHON":     ["requirements.txt", "Pipfile.lock"],
    "GO":         ["go.sum"],
    "RUST":       ["Cargo.lock"],
    "RUBY":       ["Gemfile.lock"],
}

_SKIP_DIRS: set[str] = {
    ".git", "node_modules", "vendor", ".venv", "venv", "env",
    "__pycache__", ".mypy_cache", ".pytest_cache", ".tox",
    "dist", "build", "target", ".cargo",
}


def discover_files(framework: str, root: Path | None = None) -> list[Path]:
    """Return all matching dependency files under *root* for the given framework.

    Walks recursively, skipping common non-source directories.
    """
    root = root or Path.cwd()
    targets = set(FRAMEWORK_FILES.get(framework, []))
    if not targets:
        return []

    found: list[Path] = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS]
        for name in filenames:
            if name in targets:
                found.append(Path(dirpath) / name)

    return sorted(found)
