"""HTTP client for the ComplianceWatcher API v1."""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any, Callable

import requests


class CWatcherClient:
    """Thin wrapper around requests for /api/v1/ endpoints."""

    DEFAULT_TIMEOUT = 30
    POLL_INTERVAL   = 3

    def __init__(self, server: str, api_key: str) -> None:
        self.base = server.rstrip("/") + "/api/v1"
        self._session = requests.Session()
        self._session.headers.update({
            "X-API-Key": api_key,
            "Accept":    "application/json",
        })

    def verify(self) -> dict[str, Any]:
        """Raise on auth failure; return {user_id, username, projects_count}."""
        resp = self._session.get(f"{self.base}/auth/verify", timeout=self.DEFAULT_TIMEOUT)
        resp.raise_for_status()
        return resp.json()

    def list_projects(self) -> list[dict[str, Any]]:
        """Return list of user's projects."""
        resp = self._session.get(f"{self.base}/projects", timeout=self.DEFAULT_TIMEOUT)
        resp.raise_for_status()
        return resp.json()

    def submit_scans(self, project_id: int, file_paths: list[Path]) -> dict[str, Any]:
        """Upload one or more files as multipart/form-data.

        Returns {scan_ids, warnings}.
        """
        files = [
            ("files", (p.name, p.read_bytes(), "application/octet-stream"))
            for p in file_paths
        ]
        resp = self._session.post(
            f"{self.base}/projects/{project_id}/scans",
            files=files,
            timeout=60,
        )
        resp.raise_for_status()
        return resp.json()

    def get_scan(self, scan_id: int) -> dict[str, Any]:
        """Return current scan state."""
        resp = self._session.get(f"{self.base}/scans/{scan_id}", timeout=self.DEFAULT_TIMEOUT)
        resp.raise_for_status()
        return resp.json()

    def poll_scan(
        self,
        scan_id: int,
        callback: Callable[[dict[str, Any]], None] | None = None,
        timeout: int = 300,
    ) -> dict[str, Any]:
        """Poll until scan reaches COMPLETED or FAILED (or *timeout* seconds elapsed).

        *callback* is called with each poll result if provided.
        Returns the final scan dict.
        """
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            data = self.get_scan(scan_id)
            if callback:
                callback(data)
            if data["status"] in ("COMPLETED", "FAILED"):
                return data
            time.sleep(self.POLL_INTERVAL)
        raise TimeoutError(f"Scan {scan_id} did not finish within {timeout}s")
