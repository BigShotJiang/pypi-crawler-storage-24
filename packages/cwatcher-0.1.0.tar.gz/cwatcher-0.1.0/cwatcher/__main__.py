from cwatcher.cli import main

main()
