"""cwatcher — ComplianceWatcher CLI client."""

__version__ = "0.1.0"
