export const HEATMAP_WEEKS = 52;
export const CELL_SIZE = 13;
export const CELL_GAP = 3;
export const LABEL_WIDTH = 28;
export const HEADER_HEIGHT = 20;
export const TOOLTIP_OFFSET = 12;
export const TOOLTIP_MARGIN = 16;
export const PEAK_HOUR_BINS = 12;

export const DAY_LABELS = ["Mon", "", "Wed", "", "Fri", "", ""];

export const MONTH_NAMES = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
];

export const HEATMAP_COLORS = [
  "rgba(34,211,238,0.06)",
  "rgba(34,211,238,0.25)",
  "rgba(34,211,238,0.45)",
  "rgba(34,211,238,0.65)",
  "rgba(34,211,238,0.85)",
];

export const MODEL_COLORS = [
  "bg-blue-500",
  "bg-amber-400",
  "bg-rose-500",
  "bg-emerald-500",
  "bg-violet-500",
  "bg-orange-500",
  "bg-cyan-400",
  "bg-fuchsia-500",
];

export const TOOL_COLORS = [
  "bg-cyan-500",
  "bg-teal-400",
  "bg-sky-500",
  "bg-indigo-400",
  "bg-emerald-500",
  "bg-amber-400",
  "bg-violet-500",
  "bg-rose-400",
  "bg-orange-400",
  "bg-lime-400",
  "bg-pink-400",
  "bg-blue-400",
];
