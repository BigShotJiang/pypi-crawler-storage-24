# Graft CLI

Command line tools for creating and managing projects built with the **Graft game engine**.

Graft CLI helps you create new projects, run them locally, install specific engine versions, and work with project templates.

This tool is designed to stay lightweight and simple while the Graft ecosystem grows.

---

## Installation

### Install with pip

```bash
pip install graft-cli
```

Or install locally from source:

```bash
pip install .
```

---

## Basic Usage

Running the CLI with no arguments will display available commands:

```bash
graft
```

Output:

```
Graft CLI
Usage:
     graft new [name] [--engine VERSION]
     graft run
     graft clone <repo>
     graft doctor
     graft engines
     graft version
```

---

# Commands

## Create a New Project

Create a new Graft project:

```bash
graft new MyGame
```

Create using a specific engine version:

```bash
graft new MyGame --engine 0.0.6
```

Initialize a project in the current directory:

```bash
graft new .
```

---

## Run a Project

Run the current project:

```bash
graft run
```

The CLI will automatically:

* locate the project root
* read the entry point from `project.graft`
* run the Graft engine

Older engine versions are automatically supported.

---

## Clone a Template

Clone a project template:

```bash
graft clone https://github.com/user/template
```

Templates should include a `project.graft` file.

---

## List Engine Versions

View available Graft engine versions:

```bash
graft engines
```

Example output:

```
Available Graft Versions:

0.0.1
0.0.2
0.0.3
0.0.4
0.0.5
0.0.6

Latest: 0.0.6
```

---

## Environment Diagnostics

Check your development environment:

```bash
graft doctor
```

This verifies tools required by Graft such as:

* Python
* Git
* Rust
* Cargo

---

## CLI Version

Display the installed CLI version:

```bash
graft version
```

---

# Project Structure

A typical Graft project looks like:

```
MyGame/
├ engine/
├ scripts/
│  └ main.lua
├ assets/
└ project.graft
```

Example `project.graft`:

```
name = "MyGame"
entry = "scripts/main.lua"
```

---

# Engine Versions

The CLI installs engine versions directly from the official repository:

https://github.com/phaedalus/graft

Projects can target specific engine releases for stability.

---

# Philosophy

Graft is designed with a simple philosophy:

* **Rust for performance**
* **Lua for gameplay scripting**
* **Minimal core**
* **Fork-per-project engine architecture**

The CLI reflects this philosophy by staying small and predictable.

---

# License

MIT License
