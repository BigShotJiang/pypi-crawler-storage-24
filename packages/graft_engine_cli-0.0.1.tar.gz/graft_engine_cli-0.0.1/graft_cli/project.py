import os
import stat
import subprocess
import shutil
from packaging.version import Version

GRAFT_REPO = "https://github.com/phaedalus/graft"


def remove_readonly(func, path, excinfo):
    os.chmod(path, stat.S_IWRITE)
    func(path)


def inside_existing_project():

    current = os.getcwd()

    while True:
        if os.path.exists(os.path.join(current, "project.graft")):
            return True

        parent = os.path.dirname(current)

        if parent == current:
            return False

        current = parent


def get_latest_tag():

    result = subprocess.run(
        ["git", "ls-remote", "--tags", GRAFT_REPO],
        capture_output=True,
        text=True,
        check=True
    )

    versions = []

    for line in result.stdout.splitlines():

        tag = line.split("/")[-1]

        try:
            versions.append(Version(tag))
        except:
            continue

    versions.sort()

    return str(versions[-1])


def clone_engine(target_dir, version=None):

    if version is None or version == "latest":
        print("Fetching latest Graft version...")
        version = get_latest_tag()

    print(f"Installing Graft {version}")

    subprocess.run(
        ["git", "clone", "--quiet", "--depth", "1", "--branch", version, GRAFT_REPO, target_dir],
        check=True
    )

    git_dir = os.path.join(target_dir, ".git")

    if os.path.exists(git_dir):
        shutil.rmtree(git_dir, onerror=remove_readonly)

    print("Engine installed.")


def create_project_files(project_dir):

    scripts = os.path.join(project_dir, "scripts")
    assets = os.path.join(project_dir, "assets")

    os.makedirs(scripts, exist_ok=True)
    os.makedirs(assets, exist_ok=True)

    main_lua = os.path.join(scripts, "main.lua")

    if not os.path.exists(main_lua):
        with open(main_lua, "w") as f:
            f.write(
"""function update(dt)
    -- Logic
end

function draw()
    -- Rendering
end
"""
            )

    project_file = os.path.join(project_dir, "project.graft")

    if not os.path.exists(project_file):

        name = os.path.basename(project_dir)

        with open(project_file, "w") as f:
            f.write(
f"""name = "{name}"
entry = "scripts/main.lua"
"""
            )


def read_project_name(project_dir):

    project_file = os.path.join(project_dir, "project.graft")

    if not os.path.exists(project_file):
        return os.path.basename(project_dir)

    with open(project_file, "r", encoding="utf-8") as f:
        for line in f:
            if line.startswith("name"):
                return line.split("=")[1].strip().strip('"')

    return os.path.basename(project_dir)


def wire_engine(project_dir):

    engine_dir = os.path.join(project_dir, "engine")
    scripts_dir = os.path.join(project_dir, "scripts")

    engine_main = os.path.join(engine_dir, "main.lua")
    api_file = os.path.join(engine_dir, "graft_api.lua")

    if os.path.exists(engine_main):
        os.remove(engine_main)

    if os.path.exists(api_file):
        os.rename(api_file, os.path.join(scripts_dir, "graft_api.lua"))

    project_name = read_project_name(project_dir)

    main_rs = os.path.join(engine_dir, "src", "main.rs")

    if os.path.exists(main_rs):

        with open(main_rs, "r", encoding="utf-8") as f:
            content = f.read()

        target = 'title: "Graft Game".to_string(),'

        if target in content:

            content = content.replace(
                target,
                f'title: "{project_name}".to_string(),'
            )

            with open(main_rs, "w", encoding="utf-8") as f:
                f.write(content)

            print("Engine title updated.")

        else:
            print("Engine version does not support window titles, skipping.")


def new_project(name=None, engine_version=None):

    if inside_existing_project():
        print("Error: Cannot create a Graft project inside another Graft project.")
        return

    if name is None or name == ".":
        project_dir = os.getcwd()
    else:

        project_dir = os.path.join(os.getcwd(), name)

        if os.path.exists(project_dir):
            print("Project folder already exists")
            return

        os.makedirs(project_dir)

    engine_dir = os.path.join(project_dir, "engine")

    if not os.path.exists(engine_dir):
        clone_engine(engine_dir, engine_version)

    create_project_files(project_dir)

    wire_engine(project_dir)

    print("Graft project ready.")


def list_engine_versions():

    result = subprocess.run(
        ["git", "ls-remote", "--tags", GRAFT_REPO],
        capture_output=True,
        text=True,
        check=True
    )

    versions = []

    for line in result.stdout.splitlines():

        tag = line.split("/")[-1]

        try:
            versions.append(Version(tag))
        except:
            continue

    versions.sort()

    print("Available Graft Versions:\n")

    for v in versions:
        print(v)

    print("\nLatest:", versions[-1])