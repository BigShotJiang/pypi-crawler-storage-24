import os
import shutil
import subprocess


def find_project_root():

    current = os.getcwd()

    while True:
        if os.path.exists(os.path.join(current, "project.graft")):
            return current

        parent = os.path.dirname(current)

        if parent == current:
            print("Error: Not inside a Graft project.")
            return None

        current = parent


def get_entry(project_dir):

    graft_file = os.path.join(project_dir, "project.graft")
    entry = "scripts/main.lua"

    if os.path.exists(graft_file):
        with open(graft_file) as f:
            for line in f:
                if line.startswith("entry"):
                    entry = line.split("=")[1].strip().strip('"')

    return entry


def engine_supports_entry_arg(engine_dir):

    main_rs = os.path.join(engine_dir, "src", "main.rs")

    if not os.path.exists(main_rs):
        return False

    with open(main_rs, "r", encoding="utf-8") as f:
        content = f.read()

    # crude but effective detection
    return "env::args" in content


def run_project():

    project_dir = find_project_root()

    if project_dir is None:
        return

    engine_dir = os.path.join(project_dir, "engine")

    if not os.path.exists(engine_dir):
        print("Error: Engine folder missing.")
        return

    entry = get_entry(project_dir)

    source_entry = os.path.join(project_dir, entry)

    if not os.path.exists(source_entry):
        print(f"Error: Entry file not found: {entry}")
        return

    print(f"Running project using entry: {entry}")

    if engine_supports_entry_arg(engine_dir):

        subprocess.run(
            ["cargo", "run", "--", entry],
            cwd=engine_dir
        )

    else:

        engine_entry = os.path.join(engine_dir, "main.lua")

        shutil.copy(source_entry, engine_entry)

        subprocess.run(
            ["cargo", "run"],
            cwd=engine_dir
        )