import subprocess
import os


def clone_template(repo):

    print("Cloning repository...")

    subprocess.run(["git", "clone", repo], check=True)

    repo_name = repo.rstrip("/").split("/")[-1]

    if repo_name.endswith(".git"):
        repo_name = repo_name[:-4]

    project_dir = os.path.join(os.getcwd(), repo_name)

    project_file = os.path.join(project_dir, "project.graft")

    if not os.path.exists(project_file):
        print("Warning: This repository is missing a project.graft file.")
        print("It may not be a valid Graft project template.")

    print("Repository cloned.")