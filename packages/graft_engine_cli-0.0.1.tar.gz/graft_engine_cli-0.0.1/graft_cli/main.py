import sys
from graft_cli.project import new_project, list_engine_versions
from graft_cli.run import run_project
from graft_cli.git_tools import clone_template
from graft_cli.doctor import run_doctor

def main():

    if len(sys.argv) < 2:
        print("Graft CLI")
        print("Usage:")
        print("     graft new [name] [--engine VERSION]")
        print("     graft run")
        print("     graft clone <repo>")
        print("     graft doctor")
        print("     graft engines")
        print("     graft version")
        return
    
    command = sys.argv[1]

    if command == "new":

        name = None
        engine_version = None

        args = sys.argv[2:]

        i = 0
        while i < len(args):

            arg = args[i]

            if arg == "--engine":
                if i + 1 >= len(args):
                    print("Error: --engine requires a version.")
                    return

                engine_version = args[i + 1]
                i += 2
                continue

            if name is None:
                name = arg

            i += 1

        new_project(name, engine_version)
    
    elif command == "run":
        run_project()
    
    elif command == "clone":
        if len(sys.argv) < 3:
            print("Usage: graft clone <repo>")
            return
        
        repo = sys.argv[2]
        clone_template(repo)
    
    elif command == "doctor":
        run_doctor()
    
    elif command == "engines":
        list_engine_versions()

    elif command == "version":
        print("graft-cli 0.0.1")
    
    else:
        print(f"Unknown command: {command}")
        print("Run 'graft' for usage.")

if __name__ == "__main__":
    main()