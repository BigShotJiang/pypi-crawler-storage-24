import shutil
import subprocess
import sys

def check_command(cmd):
    if shutil.which(cmd) is None:
        return False
    return True

def check_rust():
    try:
        subprocess.run(["rustc", "--version"], capture_output=True, check=True)
        return True
    except:
        return False

def check_cargo():
    try:
        subprocess.run(["cargo", "--version"], capture_output=True, check=True)
        return True
    except:
        return False

def run_doctor():

    print("Graft Enviroment Doctor")
    print("-----------------------")

    py_version = sys.version.split()[0]
    print(f"Python: {py_version}")

    if check_command("git"):
        print("Git: OK")
    else:
        print("Git: MISSING")
    
    if check_rust():
        print("Rust: OK")
    else:
        print("Rust: MISSING")
    
    if check_cargo():
        print("Cargo: OK")
    else:
        print("Cargo: MISSING")
    
    print("-----------------------")