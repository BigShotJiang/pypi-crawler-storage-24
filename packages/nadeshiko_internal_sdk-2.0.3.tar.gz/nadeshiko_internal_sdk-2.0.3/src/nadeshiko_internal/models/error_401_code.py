from enum import Enum


class Error401Code(str, Enum):
    AUTH_CREDENTIALS_EXPIRED = "AUTH_CREDENTIALS_EXPIRED"
    AUTH_CREDENTIALS_INVALID = "AUTH_CREDENTIALS_INVALID"
    AUTH_CREDENTIALS_REQUIRED = "AUTH_CREDENTIALS_REQUIRED"

    def __str__(self) -> str:
        return str(self.value)
