# ============================================================
#  task_parser.py — Langage libre → Task.md structuré
#  rolax1212 v1.0 by Roland
# ============================================================

from datetime import datetime
from pathlib  import Path
from .ui  import console, ok, info, warn, code, confirmer, separateur
from .llm import demander


PROMPT_GENERER_TASK = """Tu es un expert en développement logiciel.
L'utilisateur t'a décrit son projet en langage libre (français mélangé, notes rapides, etc.).

Description du projet :
\"\"\"
{description}
\"\"\"

Contexte du projet existant (si disponible) :
{contexte}

Génère un fichier Task.md structuré et complet.

RÈGLES :
1. Chaque tâche doit commencer par "- [ ] Créer", "- [ ] Ajouter", "- [ ] Implémenter", etc.
2. Les tâches doivent être ordonnées logiquement (config en premier, UI en dernier)
3. Chaque tâche doit être précise et actionnable (1 fichier ou 1 fonctionnalité par tâche)
4. Déduis le langage/framework depuis la description (PHP, Python, Java, etc.)
5. Si non précisé, utilise PHP + MySQL par défaut
6. Maximum 15 tâches

FORMAT EXACT à retourner :
```markdown
# [Nom du projet déduit] — Plan généré par rolax1212 v1.0

## Contexte
[Résumé en 1-2 phrases de ce que fait le projet]

## Stack technique
[Langage, framework, base de données déduits]

## Tâches
- [ ] Tâche 1
- [ ] Tâche 2
...

## Généré le
{date}
```
"""


def generer_task_md(description, modele, fichiers_existants=None, path_projet=None):
    """
    Prend une description en langage libre et génère un Task.md.
    Retourne le contenu du Task.md généré.
    """
    from .projet import construire_contexte

    contexte = ""
    if fichiers_existants:
        contexte = construire_contexte(fichiers_existants)

    prompt = PROMPT_GENERER_TASK.format(
        description=description,
        contexte=contexte or "Aucun fichier existant — nouveau projet.",
        date=datetime.now().strftime("%Y-%m-%d %H:%M")
    )

    info("Génération du Task.md...")
    messages = [{"role": "user", "content": prompt}]
    reponse  = demander(messages, modele, stream=True, timeout=120)

    if not reponse:
        warn("Impossible de générer le Task.md.")
        return None

    # Extrait le contenu markdown du bloc ```markdown ... ```
    contenu = _extraire_markdown(reponse)
    return contenu


def _extraire_markdown(reponse):
    """Extrait le contenu du bloc ```markdown ... ``` ou retourne la réponse brute."""
    import re
    match = re.search(r"```markdown\n(.*?)```", reponse, re.DOTALL)
    if match:
        return match.group(1).strip()
    # Fallback : cherche directement le # titre
    match2 = re.search(r"(# .+)", reponse, re.DOTALL)
    if match2:
        return match2.group(1).strip()
    return reponse.strip()


def afficher_et_valider(contenu_task, path_projet):
    """
    Affiche le Task.md généré et demande validation.
    Retourne True si validé, False sinon.
    """
    separateur()
    console.print("\n[bold cyan]Task.md généré :[/bold cyan]\n")
    code(contenu_task, "markdown")
    separateur()

    valide = confirmer("\nValider et sauvegarder ce Task.md ?", defaut=True)

    if valide:
        chemin = Path(path_projet) / "Task.md"
        chemin.write_text(contenu_task, encoding="utf-8")
        ok(f"Task.md sauvegardé dans {chemin}")
        return True
    else:
        warn("Task.md non sauvegardé. Tu peux relancer 'plan' pour modifier.")
        return False


def lire_description_fichier(chemin):
    """Lit un fichier .txt de description libre."""
    try:
        return Path(chemin).read_text(encoding="utf-8")
    except Exception as e:
        return None
