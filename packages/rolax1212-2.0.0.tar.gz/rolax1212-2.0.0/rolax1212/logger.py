# ============================================================
#  logger.py — Log de continuité
#  rolax1212 v2.0 by Roland
# ============================================================

import json
from datetime import datetime
from pathlib  import Path
from .ui import console, ok, info, warn, confirmer, separateur

LOG_FILE = "rolax1212.log"


class Logger:
    def __init__(self, path_projet):
        self.path    = Path(path_projet) / LOG_FILE
        self.session = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.entrees = []
        self._charger()

    def _charger(self):
        if self.path.exists():
            try:
                with open(self.path, encoding="utf-8") as f:
                    self.entrees = json.load(f)
            except Exception:
                self.entrees = []

    def _sauvegarder(self):
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(self.entrees, f, ensure_ascii=False, indent=2)

    def log(self, type_, message, details=None):
        entree = {
            "time":    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "type":    type_,
            "message": message,
        }
        if details:
            entree["details"] = details
        self.entrees.append(entree)
        self._sauvegarder()

    def tache_debut(self, numero, total, tache):
        self.log("TACHE_DEBUT", f"Tâche {numero}/{total} — EN COURS", {"tache": tache, "numero": numero, "total": total})

    def tache_fin(self, numero, total, tache, fichiers_crees=None):
        self.log("TACHE_FIN", f"Tâche {numero}/{total} — DONE", {"tache": tache, "fichiers": fichiers_crees or []})

    def fichier_cree(self, chemin):
        self.log("FICHIER", f"Créé : {chemin}")

    def session_fin(self):
        self.log("SESSION_FIN", "Session terminée proprement")

    def derniere_tache_incomplete(self):
        """Retourne la dernière tâche interrompue si elle existe."""
        debut = None
        fins  = set()

        for e in self.entrees:
            if e["type"] == "SESSION_FIN":
                debut = None
                fins  = set()
            elif e["type"] == "TACHE_DEBUT":
                debut = e
            elif e["type"] == "TACHE_FIN":
                if debut:
                    fins.add(debut["details"].get("numero"))
                    debut = None

        if debut and debut["details"].get("numero") not in fins:
            return debut
        return None

    def taches_restantes(self, toutes_les_taches):
        """Retourne les tâches pas encore complétées."""
        terminees = set()
        for e in self.entrees:
            if e["type"] == "TACHE_FIN":
                t = e.get("details", {}).get("tache", "")
                if t:
                    terminees.add(t)
        return [t for t in toutes_les_taches if t not in terminees]

    def afficher_resume(self):
        """Affiche un résumé du log."""
        if not self.entrees:
            return

        nb_taches   = sum(1 for e in self.entrees if e["type"] == "TACHE_FIN")
        nb_fichiers = sum(1 for e in self.entrees if e["type"] == "FICHIER")
        derniere    = next((e for e in reversed(self.entrees) if e["type"] in ["TACHE_DEBUT", "TACHE_FIN"]), None)

        console.print(f"\n[dim]Log : {nb_taches} tâche(s) complétée(s), {nb_fichiers} fichier(s) créé(s)[/dim]")
        if derniere:
            console.print(f"[dim]Dernière action : {derniere['message']} à {derniere['time']}[/dim]")


def verifier_reprise(path_projet):
    """
    Vérifie si une session précédente a été interrompue.
    Retourne (logger, tache_incomplete) ou (logger, None).
    """
    logger  = Logger(path_projet)
    incomplete = logger.derniere_tache_incomplete()

    if not incomplete:
        return logger, None

    tache   = incomplete["details"].get("tache", "?")
    numero  = incomplete["details"].get("numero", "?")
    total   = incomplete["details"].get("total", "?")
    time    = incomplete.get("time", "?")

    separateur()
    console.print(f"\n[bold yellow]Session précédente détectée ![/bold yellow]")
    console.print(f"  Arrêtée à : Tâche [bold]{numero}/{total}[/bold] — {tache}")
    console.print(f"  Le : [dim]{time}[/dim]")

    if confirmer("Reprendre depuis cet endroit ?", defaut=True):
        ok("Reprise de la session précédente")
        return logger, incomplete
    else:
        info("Nouvelle session — log réinitialisé")
        logger.entrees = []
        logger._sauvegarder()
        return logger, None
