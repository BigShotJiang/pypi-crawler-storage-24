# ============================================================
#  ui.py — Affichage terminal (rich)
#  rolax1212 v1.0 by Roland
# ============================================================

from rich.console import Console
from rich.panel   import Panel
from rich.table   import Table
from rich.syntax  import Syntax
from rich.prompt  import Prompt, Confirm
from rich.markdown import Markdown

console = Console()

VERSION = "1.0"
AUTEUR  = "Roland"

# ============================================================
#  COULEURS
# ============================================================
def ok(texte):
    console.print(f"[bold green][OK][/bold green] {texte}")

def info(texte):
    console.print(f"[cyan][>>][/cyan] {texte}")

def warn(texte):
    console.print(f"[bold yellow][!][/bold yellow] {texte}")

def err(texte):
    console.print(f"[bold red][ERR][/bold red] {texte}")

def titre(texte):
    console.print(f"\n[bold cyan]{texte}[/bold cyan]")

def separateur():
    console.print("[dim]" + "─" * 62 + "[/dim]")

def code(contenu, langage="text", lignes=True):
    console.print(Syntax(contenu, langage, theme="monokai", line_numbers=lignes))

def demander(question, defaut=None):
    return Prompt.ask(f"[cyan]{question}[/cyan]", default=defaut)

def confirmer(question, defaut=True):
    return Confirm.ask(f"[cyan]{question}[/cyan]", default=defaut)

# ============================================================
#  BANNIERE
# ============================================================
def banniere():
    console.print(Panel(
        f"[bold cyan]ROLAX1212[/bold cyan]  —  Agent de développement local\n"
        f"[dim]Version {VERSION}  •  by {AUTEUR}  •  Powered by Ollama[/dim]",
        title="[bold cyan][ ROLAX1212 ][/bold cyan]",
        style="cyan"
    ))

def banniere_session(modele, path_projet):
    console.print(Panel(
        f"[bold cyan]ROLAX1212[/bold cyan]  —  Agent de développement local\n"
        f"[dim]Modèle  :[/dim] [yellow]{modele}[/yellow]\n"
        f"[dim]Projet  :[/dim] [white]{path_projet}[/white]\n"
        f"[dim]Commandes :[/dim] "
        f"[cyan]plan[/cyan] • [cyan]task[/cyan] • [cyan]audit[/cyan] • "
        f"[cyan]structure[/cyan] • [cyan]aide[/cyan] • [cyan]exit[/cyan]",
        title="[bold cyan][ ROLAX1212 v1.0 ][/bold cyan]",
        style="cyan"
    ))

# ============================================================
#  AIDE
# ============================================================
def afficher_aide():
    console.print(Markdown("""
## Commandes disponibles

| Commande | Description |
|---|---|
| `plan [texte libre]` | Décris ton projet en français → génère Task.md |
| `task` | Exécute les tâches du Task.md |
| `audit` | Rapport complet C/U/F du projet |
| `structure` | Affiche l'arborescence du projet |
| `lis [fichier]` | Affiche un fichier avec coloration syntaxique |
| `exec [fichier]` | Exécute un fichier (Python, PHP, JS, Bash) |
| `aide` | Affiche cette aide |
| `exit` | Quitte rolax1212 |

## Exemples de commandes naturelles

- `crée un fichier UserController.php avec login et register`
- `génère une classe Java User avec getters et setters`
- `ajoute une connexion PDO MySQL dans config.php`
- `implémente une API REST avec Flask`

## Format Task.md libre

Tu peux écrire n'importe quoi :
```
je veux un site pour gérer les élèves
faut un login pour le directeur  
les profs voient leurs classes
export PDF des bulletins
```
Tape `plan` suivi de ton texte, ou crée un fichier `idea.txt` et tape `plan idea.txt`
"""))

# ============================================================
#  RAPPORT AUDIT C/U/F
# ============================================================
def afficher_audit(rapport):
    """
    rapport = {
        "check":  [{"fichier": "...", "probleme": "...", "corrige": True/False}],
        "update": ["amélioration 1", ...],
        "future": ["suggestion 1", ...]
    }
    """
    checks  = rapport.get("check",  [])
    updates = rapport.get("update", [])
    futures = rapport.get("future", [])

    nb_c = len(checks)
    nb_u = len(updates)
    nb_f = len(futures)

    console.print()
    console.print(Panel(
        f"[bold green][C] CHECK[/bold green]  {nb_c} bug(s)  •  "
        f"[bold yellow][U] UPDATE[/bold yellow]  {nb_u} amélioration(s)  •  "
        f"[bold cyan][F] FUTURE[/bold cyan]  {nb_f} suggestion(s)",
        title="[bold white]AUDIT DU PROJET[/bold white]",
        style="white"
    ))

    # CHECK
    if checks:
        console.print(f"\n[bold green][ C ] CHECK — Bugs détectés[/bold green]")
        separateur()
        for item in checks:
            statut = "[green]corrigé[/green]" if item.get("corrige") else "[red]manuel requis[/red]"
            console.print(
                f"  [white]{item.get('fichier','?')}[/white]  "
                f"[dim]{item.get('probleme','?')}[/dim]  → {statut}"
            )
    else:
        console.print(f"\n[bold green][ C ] CHECK[/bold green] — [green]Aucun bug détecté[/green]")

    # UPDATE
    console.print(f"\n[bold yellow][ U ] UPDATE — Améliorations possibles[/bold yellow]")
    separateur()
    if updates:
        for u in updates:
            console.print(f"  [yellow]•[/yellow] {u}")
    else:
        console.print("  Aucune amélioration suggérée.")

    # FUTURE
    console.print(f"\n[bold cyan][ F ] FUTURE — Fonctionnalités à ajouter[/bold cyan]")
    separateur()
    if futures:
        for f in futures:
            console.print(f"  [cyan]→[/cyan] {f}")
    else:
        console.print("  Aucune suggestion.")

    console.print()

# ============================================================
#  PROJET TERMINE
# ============================================================
def projet_termine(fichiers_crees):
    noms = [str(f) for f in fichiers_crees]
    console.print(Panel(
        f"[bold green]PROJET TERMINE[/bold green]\n"
        + "\n".join(f"  [green]✓[/green] {n}" for n in noms),
        title="[bold green][ OK ][/bold green]",
        style="green"
    ))

def projet_termine_avertissement(fichiers_crees):
    noms = [str(f) for f in fichiers_crees]
    console.print(Panel(
        f"[bold yellow]PROJET TERMINE AVEC AVERTISSEMENTS[/bold yellow]\n"
        + "\n".join(f"  [yellow]•[/yellow] {n}" for n in noms)
        + "\n[dim]Vérification manuelle recommandée.[/dim]",
        title="[bold yellow][ ! ][/bold yellow]",
        style="yellow"
    ))
