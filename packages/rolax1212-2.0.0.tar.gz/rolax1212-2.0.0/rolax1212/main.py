# ============================================================
#  main.py — Point d'entrée rolax1212
#  rolax1212 v1.0 by Roland
# ============================================================

import sys
from pathlib import Path
from .ui    import console, banniere, separateur, err
from .llm   import choisir_modele
from .agent import lancer


def main():
    """Point d'entrée principal — appelé par `rolax1212` dans le terminal."""

    banniere()
    separateur()

    # Choix du modèle
    try:
        modele = choisir_modele()
    except SystemExit:
        sys.exit(1)

    separateur()

    # Chemin du projet
    if len(sys.argv) > 1:
        path_projet = " ".join(sys.argv[1:])
    else:
        path_projet = console.input(
            f"\n[cyan]Chemin du projet[/cyan] "
            f"[dim](Entrée = dossier actuel)[/dim] : "
        ).strip() or str(Path.cwd())

    separateur()
    lancer(modele, path_projet)


if __name__ == "__main__":
    main()
