"""Entry point for ``python -m ux`` when the package is installed.

Use this if a stale ``connect4`` console script points at an old entry point
(see README troubleshooting).
"""

from __future__ import annotations

from ux.view import run_cli

if __name__ == "__main__":
    run_cli()
