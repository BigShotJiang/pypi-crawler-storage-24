# docflow

`docflow` is a document-native DAG runner for preprocessing files into structured evidence artifacts, plain text exports, and downstream indexes.

It supports these input types:

- `pdf`
- `docx`
- `doc`
- `xlsx`
- `xls`
- `msg`

Core capabilities:

- flow execution from `*.flow.dag.yaml`
- document parsing into evidence atoms
- metadata enrichment
- evidence-graph construction
- semantic, structural, and spatial indexes
- plain-text and structured output artifacts

Example install for local development:

```bash
cd packages/docflow
python3 -m pip install -e '.[dev]'
```

Example CLI usage:

```bash
docflow run ../../docflow/examples/document_preprocess.flow.dag.yaml --source-dir /path/to/documents --output-dir /tmp/docflow_run --trace
```
