## v7.3.0a3 (2026-03-16)

### Feat

- add generic type parameters to block and field stubs

## v7.3.0a2 (2026-03-16)

### Fix

- allow publish.sh to run from wagtail-* branches
- add _default_manager to Page stub for reverse manager resolution

## v7.3.0a1 (2026-03-16)

### Feat

- update stubs for wagtail 7.3 support
- add BlockGroup class for StructBlock form layouts
- add StructBlock.Meta.form_layout and get_form_layout() method
- add ModelViewSet.pk_path_converter attribute
- add CreateView/EditView.is_valid() and produced_error_message
## v7.2.0a3 (2026-03-16)

### Feat

- add generic type parameters to block and field stubs

## v7.2.0a2 (2026-03-16)

### Fix

- allow publish.sh to run from wagtail-* branches
- add _default_manager to Page stub for reverse manager resolution

## v7.2.0a1 (2026-03-16)

### Feat

- update stubs for wagtail 7.2 support
- add ModelViewSet.sort_order_field attribute
- add Task.lock_class class attribute
- add BaseSearchBackend.refresh_indexes() method
## v7.1.0a3 (2026-03-16)

### Feat

- add generic type parameters to block and field stubs

## v7.1.0a2 (2026-03-16)

### Fix

- allow publish.sh to run from wagtail-* branches
- add _default_manager to Page stub for reverse manager resolution

## v7.1.0a1 (2026-03-16)

### Feat

- update stubs for wagtail 7.1 support
- add wagtail.admin.telepath module (relocated from wagtail.telepath)
- add wagtail.admin.telepath.widgets module (relocated from wagtail.widget_adapters)
- add StructBlock.Meta.collapsed option
- add init_new_page signal to wagtail.signals

## v7.0.0a6 (2026-03-16)

### Feat

- add generic type parameters to block and field stubs

## v7.0.0a5 (2026-03-16)

### Fix

- allow publish.sh to run from wagtail-* branches
- add _default_manager to Page stub for reverse manager resolution

## v7.0.0a4 (2026-03-16)

### Fix

- lint

## v7.0.0a3 (2026-03-16)

### Feat

- initial wagtail-stubs package

### Fix

- improve stubs accuracy based on integration testing
- treebeard version
- version
- **ci**: remove TOX_SKIP_ENV matrix that skips all envs
- add LICENSE
- replace Any/object with concrete types where possible
- comprehensive type stub audit and improvement
