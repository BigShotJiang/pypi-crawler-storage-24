from django import template
from wagtail.images.models import Filter as Filter
from wagtail.images.models import Picture as Picture
from wagtail.images.models import ResponsiveImage as ResponsiveImage
from wagtail.images.shortcuts import (
    get_rendition_or_not_found as get_rendition_or_not_found,
)
from wagtail.images.shortcuts import (
    get_renditions_or_not_found as get_renditions_or_not_found,
)
from wagtail.images.views.serve import generate_image_url as generate_image_url

register: template.Library

def image(parser, token): ...

class ImageNode(template.Node):
    image_expr: template.base.FilterExpression
    output_var_name: str | None
    attrs: dict[str, template.base.FilterExpression]
    filter_specs: list[str]
    def __init__(self, image_expr, filter_specs, output_var_name=None, attrs=None) -> None: ...
    def get_filter(self): ...
    def validate_image(self, context): ...
    def render(self, context): ...

class SrcsetImageNode(ImageNode):
    def get_filters(self): ...
    def render(self, context): ...

class PictureNode(SrcsetImageNode):
    def render(self, context): ...

def image_url(image, filter_spec, viewname: str = "wagtailimages_serve"): ...
