from wagtail.admin import messages as messages
from wagtail.admin.action_menu import PageActionMenu as PageActionMenu
from wagtail.admin.auth import (
    user_has_any_page_permission as user_has_any_page_permission,
)
from wagtail.admin.auth import (
    user_passes_test as user_passes_test,
)
from wagtail.admin.views.generic.models import (
    RevisionsCompareView as RevisionsCompareView,
)
from wagtail.admin.views.generic.models import (
    RevisionsUnscheduleView as RevisionsUnscheduleView,
)
from wagtail.admin.views.generic.preview import PreviewRevision as PreviewRevision
from wagtail.admin.views.pages.edit import EditView as EditView
from wagtail.admin.views.pages.utils import GenericPageBreadcrumbsMixin as GenericPageBreadcrumbsMixin
from wagtail.models import Page as Page
from wagtail.utils.timestamps import render_timestamp as render_timestamp

def revisions_index(request, page_id): ...

class RevisionsRevertView(EditView):
    revisions_revert_url_name: str
    def get_action_menu(self): ...
    def get(self, request, *args, **kwargs): ...
    def get_object(self): ...
    def get_revisions_revert_url(self): ...
    def get_warning_message(self): ...
    def get_context_data(self, **kwargs): ...

class RevisionsView(PreviewRevision):
    model = Page
    def setup(self, request, page_id, revision_id, *args, **kwargs): ...
    def get_object(self): ...

class RevisionsCompare(GenericPageBreadcrumbsMixin, RevisionsCompareView):
    history_url_name: str
    edit_url_name: str
    header_icon: str
    breadcrumbs_items_to_take: int
    def dispatch(self, request, *args, **kwargs): ...
    def get_object(self, queryset=None): ...
    def get_edit_handler(self): ...
    def get_page_subtitle(self): ...

class RevisionsUnschedule(RevisionsUnscheduleView):
    model = Page
    edit_url_name: str
    history_url_name: str
    revisions_unschedule_url_name: str
    header_icon: str
    def setup(self, request, page_id, revision_id, *args, **kwargs): ...
    def get_object(self, queryset=None): ...
    def get_object_display_title(self): ...
