from collections.abc import Callable
from datetime import datetime
from typing import Any

from django.contrib.contenttypes.models import ContentType
from django.http import HttpRequest, HttpResponse, HttpResponseBase
from django.utils.functional import cached_property as cached_property
from django.views.generic.base import View
from wagtail.actions.publish_page_revision import PublishPageRevisionAction as PublishPageRevisionAction
from wagtail.admin import messages as messages
from wagtail.admin.action_menu import PageActionMenu as PageActionMenu
from wagtail.admin.forms.pages import WagtailAdminPageForm
from wagtail.admin.mail import send_notification as send_notification
from wagtail.admin.models import EditingSession as EditingSession
from wagtail.admin.panels.base import Panel
from wagtail.admin.ui.components import MediaContainer as MediaContainer
from wagtail.admin.ui.editing_sessions import EditingSessionsModule as EditingSessionsModule
from wagtail.admin.ui.side_panels import (
    ChecksSidePanel as ChecksSidePanel,
)
from wagtail.admin.ui.side_panels import (
    CommentsSidePanel as CommentsSidePanel,
)
from wagtail.admin.ui.side_panels import (
    PageStatusSidePanel as PageStatusSidePanel,
)
from wagtail.admin.ui.side_panels import (
    PreviewSidePanel as PreviewSidePanel,
)
from wagtail.admin.utils import get_valid_next_url_from_request as get_valid_next_url_from_request
from wagtail.admin.views.generic import HookResponseMixin as HookResponseMixin
from wagtail.admin.views.generic.base import WagtailAdminTemplateMixin as WagtailAdminTemplateMixin
from wagtail.exceptions import PageClassNotFoundError as PageClassNotFoundError
from wagtail.locks import (
    BaseLock,
)
from wagtail.locks import (
    BasicLock as BasicLock,
)
from wagtail.locks import (
    ScheduledForPublishLock as ScheduledForPublishLock,
)
from wagtail.locks import (
    WorkflowLock as WorkflowLock,
)
from wagtail.models import (
    COMMENTS_RELATION_NAME as COMMENTS_RELATION_NAME,
)
from wagtail.models import (
    Comment as Comment,
)
from wagtail.models import (
    CommentReply as CommentReply,
)
from wagtail.models import (
    Locale,
    Task,
)
from wagtail.models import (
    Page as Page,
)
from wagtail.models import (
    PageSubscription as PageSubscription,
)
from wagtail.models import (
    Revision as Revision,
)
from wagtail.models import (
    WorkflowState as WorkflowState,
)
from wagtail.models import (
    get_default_page_content_type as get_default_page_content_type,
)
from wagtail.models.pages import PagePermissionTester
from wagtail.utils.timestamps import render_timestamp as render_timestamp

class EditView(WagtailAdminTemplateMixin, HookResponseMixin, View):
    partials_template_name: str
    def get_page_title(self) -> str: ...
    def get_page_subtitle(self) -> str: ...
    def get_template_names(self) -> list[str]: ...
    def add_save_confirmation_message(self) -> None: ...
    def get_commenting_changes(self) -> dict[str, list[Comment | tuple[Comment, list[CommentReply]]]]: ...
    def send_commenting_notifications(
        self, changes: dict[str, list[Comment | tuple[Comment, list[CommentReply]]]]
    ) -> None: ...
    def log_commenting_changes(
        self, changes: dict[str, list[Comment | tuple[Comment, list[CommentReply]]]], revision: Revision
    ) -> None: ...
    def get_edit_message_button(self) -> messages.button: ...
    def get_view_draft_message_button(self) -> messages.button: ...
    def get_view_live_message_button(self) -> messages.button: ...
    def get_compare_with_live_message_button(self) -> messages.button: ...
    def get_page_for_status(self) -> Page: ...
    def get_object(self) -> Page: ...
    def get_edit_url(self) -> str: ...
    real_page_record: Page
    latest_revision: Revision | None
    scheduled_revision: Revision | None
    page_content_type: ContentType
    page_class: type[Page] | None
    revision_id: str | None
    is_reverting: bool
    previous_revision: Revision | None
    page: Page
    parent: Page
    scheduled_page: Page | None
    page_perms: PagePermissionTester
    lock: BaseLock | None
    locked_for_user: bool
    next_url: str | None
    edit_handler: Panel
    form_class: type[WagtailAdminPageForm]
    workflow_state: WorkflowState | None
    locale: Locale | None
    translations: list[dict[str, Any]]
    workflow_tasks: list[Task]
    has_unsaved_changes: bool
    errors_debug: str | None
    def dispatch(self, request: HttpRequest, page_id: int, **kwargs: Any) -> HttpResponseBase: ...
    form: WagtailAdminPageForm
    def get(self, request: HttpRequest, *args: Any, **kwargs: Any) -> HttpResponse: ...
    def add_cancel_workflow_confirmation_message(self) -> None: ...
    @cached_property
    def is_cancelling_workflow(self) -> bool: ...
    @cached_property
    def hydrate_create_view(self) -> bool: ...
    @cached_property
    def latest_revision_created_at(self) -> datetime | None: ...
    @cached_property
    def is_out_of_date(self) -> bool: ...
    def post(self, request: HttpRequest, *args: Any, **kwargs: Any) -> HttpResponse: ...
    workflow_action: str
    def workflow_action_is_valid(self) -> bool: ...
    @cached_property
    def action_name_and_method(self) -> tuple[str, Callable[[], HttpResponseBase | None]]: ...
    @property
    def action_name(self) -> str: ...
    @property
    def action_method(self) -> Callable[[], HttpResponseBase | None]: ...
    has_content_changes: bool
    def form_valid(self, form: WagtailAdminPageForm) -> HttpResponseBase | None: ...
    def save_action(self) -> HttpResponseBase | None: ...
    def publish_action(self) -> HttpResponseBase | None: ...
    def submit_action(self) -> HttpResponseBase | None: ...
    def restart_workflow_action(self) -> HttpResponseBase | None: ...
    def perform_workflow_action(self) -> HttpResponseBase | None: ...
    def cancel_workflow_action(self) -> HttpResponseBase | None: ...
    def redirect_away(self) -> HttpResponseBase: ...
    def redirect_and_remain(self) -> HttpResponseBase: ...
    def form_invalid(self, form: WagtailAdminPageForm) -> HttpResponse: ...
    def get_preview_url(self) -> str: ...
    def get_history_url(self) -> str | None: ...
    def get_side_panels(self) -> MediaContainer: ...
    def get_editing_sessions(self) -> EditingSessionsModule: ...
    def get_action_menu(self) -> PageActionMenu: ...
    def get_context_data(self, **kwargs: Any) -> dict[str, Any]: ...
    def get_translations(self) -> list[dict[str, Any]]: ...
