﻿"""Context builder for system, human, and AI prompts."""

from operator_use.messages.service import BaseMessage, SystemMessage, HumanMessage,AIMessage
from platform import machine, system, python_version
from operator_use.agent.skills import Skills
from datetime import datetime
from getpass import getuser
from pathlib import Path
import operator_use

BOOTSTRAP_FILENAMES = ["SOUL.md", "USER.md", "CODE.md", "AGENTS.md"]

class Context:
    """Builder for conversation context: system prompt, AI messages, human messages."""
    def __init__(self, workspace: Path):
        self.workspace = workspace
        self.codebase = Path(operator_use.__file__).resolve().parent.parent
        self.skills = Skills(self.workspace)

    def _build_runtime_context(self) -> str:
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        _sys = system()
        os_name = "MacOS" if _sys == "Darwin" else _sys
        runtime = f"{os_name} {machine()} Python {python_version()}"
        username = getuser()
        home = Path.home()

        lines = []
        lines.append(f"## Today's Date: {now}")
        lines.append(f"## Username: {username}")
        lines.append(f"## Runtime: {runtime}")
        lines.append(f"## Home: {home.as_posix()}")
        lines.append(f"## Downloads: {(home / 'Downloads').as_posix()}")
        lines.append(f"## Desktop: {(home / 'Desktop').as_posix()}")
        lines.append(f"## Documents: {(home / 'Documents').as_posix()}")
        if _sys == "Windows":
            lines.append("## Shell: Windows CMD / PowerShell. Use `dir` not `ls`, `del` not `rm`. Pass commands as plain strings without surrounding quotes.")
        elif _sys == "Darwin":
            lines.append("## Shell: macOS bash/zsh.")
        else:
            lines.append("## Shell: Linux bash.")
        return "\n".join(lines)

    def _build_codebase_context(self) -> str:
        codebase_path = self.codebase.expanduser().resolve().as_posix()
        workspace_path = self.workspace.expanduser().resolve().as_posix()
        return f"""## Codebase: {codebase_path}
You have access to your CODEBASE of implementation.

- Codebase (Summary of your codebase): {workspace_path}/CODE.md

Use the CODE.md file to update your codebase to improve your capabilities on demand.
"""

    def _build_workspace_context(self) -> str:
        workspace_path = self.workspace.expanduser().resolve().as_posix()
        return f"""## Workspace: {workspace_path}
Where you store your memory, skills and notes.

 - Agent Instructions: {workspace_path}/AGENTS.md
 - Soul (Your personality and goals): {workspace_path}/SOUL.md
 - User (User Profile and preferences): {workspace_path}/USER.md
 - Memory (Long Term Memory): {workspace_path}/memory/MEMORY.md
 - Daily notes: {workspace_path}/memory/YYYY-MM-DD.md
 - Heartbeat tasks (periodic tasks you need to perform): {workspace_path}/HEARTBEAT.md
 - Custom Skills (Skills you can use to enhance your capabilities): {workspace_path}/skills/{{skill-name}}/SKILL.md

When you need to remember something, write to {workspace_path}/memory/MEMORY.md
"""

    def _load_bootstrap_files(self) -> list[str]:
        """Load bootstrap files."""
        parts=[]
        for filename in BOOTSTRAP_FILENAMES:
            path = self.workspace / filename
            if path.exists():
                content=path.read_text(encoding="utf-8")
                if not content:
                    continue
                parts.append(f"""### {filename}\n\n{content}""")
        return parts

    def get_respond_behavior(self, is_voice: bool = False) -> str:
        parts = ["## Respond Behavior"]
        base = """
- Be direct, concise, and use the send_message tool only for intermediate updates and don't use it for the final response.
- Don't give lengthy explanations, caveats, or preamble unless the task requires it.
- Respond like a human would—brief and to the point if required use Markdown for formatting.
"""
        voice = """
- Your response will be spoken via TTS. Keep it short, conversational, and natural for speech.
- Use plain text only. Markdown is not allowed in voice replies.
- NEVER include message IDs like [bot_msg_id:N] or [msg_id:N] in your response. These are for your reference only.
"""
        parts.append(voice if is_voice else base + "\n- NEVER include message IDs like [bot_msg_id:N] or [msg_id:N] in your response. These are for your reference only.")
        return "\n".join(parts)

    def build_system_prompt(self, is_voice: bool = False) -> str:
        """Build a system prompt."""
        parts=[]
        identity=self.get_identity()
        parts.append(identity)
        if bootstrap_parts:=self._load_bootstrap_files():
            parts.extend(bootstrap_parts)
        
        skills_summary=self.skills.build_skills_summary() or "(No skills available)"
        parts.append(f'''## Skills

You have access to the following skills to enhance your capabilities, to use a skill, read the SKILL.md file for the skill.

Available Skills:
{skills_summary}
''')
        respond_behavior = self.get_respond_behavior(is_voice=is_voice)
        parts.append(respond_behavior)
        return "\n".join(parts)

    def get_identity(self) -> str:
        """Get the identity of the agent."""
        runtime_context = self._build_runtime_context()
        codebase_context = self._build_codebase_context()
        workspace_context = self._build_workspace_context()
        return f'''
You are operator-use created by CursorTouch.

You are a helpful personal assistant.

{runtime_context}

{workspace_context}

{codebase_context}
'''

    def _hydrate_history(self, history: list[BaseMessage]) -> list[BaseMessage]:
        """Inject channel metadata into message content so the LLM can see IDs for reactions/references."""
        hydrated = []
        for msg in history:
            if isinstance(msg, HumanMessage) and msg.metadata:
                msg_id = msg.metadata.get("message_id")
                if msg_id is not None:
                    annotated = HumanMessage(
                        content=f"[msg_id:{msg_id}] {msg.content}",
                        metadata=msg.metadata,
                    )
                    hydrated.append(annotated)
                    continue
            elif isinstance(msg, AIMessage) and msg.metadata.get("message_id") is not None:
                bot_msg_id = msg.metadata["message_id"]
                annotated = AIMessage(
                    content=f"[bot_msg_id:{bot_msg_id}] {msg.content or ''}",
                    thinking=msg.thinking,
                    thinking_signature=msg.thinking_signature,
                    usage=msg.usage,
                    metadata=msg.metadata,
                )
                hydrated.append(annotated)
                continue
            hydrated.append(msg)
        return hydrated

    def build_messages(
        self,
        history: list[BaseMessage],
        is_voice: bool = False,
    ) -> list[BaseMessage]:
        """Build messages: [System, hydrated history]. History contains full conversation."""
        messages = []
        system_prompt = self.build_system_prompt(is_voice=is_voice)
        messages.append(SystemMessage(content=system_prompt))
        messages.extend(self._hydrate_history(history))
        return messages
