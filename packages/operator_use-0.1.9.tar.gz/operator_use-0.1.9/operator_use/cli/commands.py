﻿import os

import asyncio
import json
import time
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table
from rich import box

console = Console()

from operator_use.paths import get_userdata_dir
USERDATA_DIR = get_userdata_dir()

app = typer.Typer(
    name="Operator",
    help="Operator CLI",
    invoke_without_command=True,
    no_args_is_help=False,
)

@app.callback()
def default(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        run()

@app.command("help")
def help_cmd(ctx: typer.Context):
    """Show available commands and usage."""
    console.print("\n[bold]Operator[/bold] — your personal AI agent\n")
    table = Table(box=box.SIMPLE, show_header=False, padding=(0, 1))
    table.add_column("Command", style="bold cyan", no_wrap=True)
    table.add_column("Description")
    table.add_row("operator", "Start the agent (default)")
    table.add_row("operator run", "Start the agent")
    table.add_row("operator onboard", "Interactive setup wizard")
    table.add_row("operator status", "Show config and agent status")
    table.add_row("operator sessions", "List conversation sessions")
    table.add_row("operator logs", "Show agent logs  [dim](--follow / -f to tail)[/dim]")
    table.add_row("operator channels", "Show configured channel accounts")
    table.add_row("operator channel add", "Add a new channel interactively")
    table.add_row("operator auth antigravity", "Login with Google Cloud Code Assist OAuth")
    table.add_row("operator auth claude-code", "Login with Claude Code OAuth")
    table.add_row("operator auth codex", "Login with OpenAI Codex (ChatGPT) OAuth")
    table.add_row("operator auth github-copilot", "Login with GitHub Copilot OAuth")
    table.add_row("operator computer-use enable", "Enable desktop computer use")
    table.add_row("operator computer-use disable", "Disable desktop computer use")
    table.add_row("operator models", "Show model providers and active LLM/STT/TTS")
    table.add_row("operator config list", "List all config values")
    table.add_row("operator config get <key>", "Get a config value  [dim](e.g. agent.llm.model)[/dim]")
    table.add_row("operator config set <key> <val>", "Set a config value")
    table.add_row("operator config unset <key>", "Remove a config key")
    table.add_row("operator cron list", "List scheduled cron jobs")
    table.add_row("operator cron add", "Add a cron job")
    table.add_row("operator cron remove <id>", "Remove a cron job")
    table.add_row("operator cron enable <id>", "Enable a cron job")
    table.add_row("operator cron disable <id>", "Disable a cron job")
    console.print(table)
    console.print("[dim]Use [bold]operator <command> --help[/bold] for details on any command.[/dim]\n")

@app.command("onboard")
def onboard():
    """Launch the interactive configuration wizard."""
    try:
        from operator_use.cli import setup
        setup.run_initial_setup()
    except ImportError as e:
        print(f"Error: Unable to start configuration UI. Missing dependencies? ({e})")

@app.command("run")
def run():
    """Start the agent (auto-onboards on first run if no config exists)."""
    if not (USERDATA_DIR / "config.json").exists():
        console.print("[bold]Welcome to Operator![/bold] No config found — launching setup wizard...\n")
        from operator_use.cli import setup
        setup.run_initial_setup()
    from operator_use.cli.runner import main
    asyncio.run(main())

@app.command("status")
def status():
    """Show agent configuration and status."""
    config_path = USERDATA_DIR / "config.json"
    if not config_path.exists():
        console.print("[red]No config found.[/red] Run [bold]operator onboard[/bold] first.")
        raise typer.Exit(1)

    config = json.loads(config_path.read_text(encoding="utf-8"))
    agent = config.get("agent", {})
    llm = agent.get("llm", {})
    channels = config.get("channels", {})
    crons_path = USERDATA_DIR / "crons.json"
    sessions_dir = USERDATA_DIR / "workspace" / "sessions"
    log_file = USERDATA_DIR / "operator.log"

    # LLM
    table = Table(box=box.ROUNDED, show_header=False, padding=(0, 1))
    table.add_column("Key", style="bold cyan")
    table.add_column("Value")
    table.add_row("Provider", llm.get("provider") or "-")
    table.add_row("Model", llm.get("model") or "-")

    # Channels
    active = [
        name for name, cfg in channels.items()
        if isinstance(cfg, dict) and (cfg.get("token") or cfg.get("botToken") or cfg.get("bot_token"))
    ]
    table.add_row("Channels", ", ".join(active) if active else "[dim]none configured[/dim]")

    # Sessions
    session_count = len(list(sessions_dir.glob("*.jsonl"))) if sessions_dir.exists() else 0
    table.add_row("Sessions", str(session_count))

    # Crons
    cron_count = 0
    if crons_path.exists():
        try:
            crons = json.loads(crons_path.read_text(encoding="utf-8"))
            cron_count = len(crons) if isinstance(crons, list) else 0
        except json.JSONDecodeError:
            pass
    table.add_row("Cron jobs", str(cron_count))

    # Log file
    table.add_row("Log file", str(log_file) if log_file.exists() else "[dim]not yet created[/dim]")

    console.print("\n[bold]Operator Status[/bold]")
    console.print(table)

@app.command("sessions")
def sessions(limit: int = typer.Option(20, "--limit", "-n", help="Max sessions to show.")):
    """List stored conversation sessions."""
    sessions_dir = USERDATA_DIR / "workspace" / "sessions"
    if not sessions_dir.exists():
        console.print("[dim]No sessions found.[/dim]")
        return

    files = sorted(sessions_dir.glob("*.jsonl"), key=lambda f: f.stat().st_mtime, reverse=True)
    if not files:
        console.print("[dim]No sessions found.[/dim]")
        return

    table = Table(box=box.ROUNDED, show_header=True, padding=(0, 1))
    table.add_column("Session ID", style="cyan")
    table.add_column("Messages", justify="right")
    table.add_column("Created")
    table.add_column("Updated")

    for f in files[:limit]:
        created, updated, msg_count = "-", "-", 0
        try:
            with open(f, encoding="utf-8") as fp:
                for line in fp:
                    line = line.strip()
                    if not line:
                        continue
                    obj = json.loads(line)
                    if obj.get("type") == "metadata":
                        created = obj.get("created_at", "-")[:19].replace("T", " ")
                        updated = obj.get("updated_at", "-")[:19].replace("T", " ")
                    elif "role" in obj:
                        msg_count += 1
        except (json.JSONDecodeError, OSError):
            pass
        table.add_row(f.stem, str(msg_count), created, updated)

    console.print(f"\n[bold]Sessions[/bold] ({min(len(files), limit)} of {len(files)})")
    console.print(table)

import time as _time


cu_app = typer.Typer(name="computer-use", help="Enable or disable computer use.", invoke_without_command=True, no_args_is_help=True)
app.add_typer(cu_app)


def _set_computer_use(enabled: bool):
    import json as _json
    config_path = USERDATA_DIR / "config.json"
    if not config_path.exists():
        console.print("[red]No config found.[/red] Run [bold]operator onboard[/bold] first.")
        raise typer.Exit(1)
    data = _json.loads(config_path.read_text(encoding="utf-8"))
    data.setdefault("agent", {})["computerUse"] = enabled
    config_path.write_text(_json.dumps(data, indent=4, ensure_ascii=False), encoding="utf-8")
    state = "[green]enabled[/green]" if enabled else "[dim]disabled[/dim]"
    console.print(f"Computer use {state}. Restart [bold]operator run[/bold] to apply.")


@cu_app.command("enable")
def cu_enable():
    """Enable computer use (desktop control)."""
    _set_computer_use(True)


@cu_app.command("disable")
def cu_disable():
    """Disable computer use."""
    _set_computer_use(False)


channel_app = typer.Typer(name="channel", help="Manage connected channels.", invoke_without_command=True, no_args_is_help=True)
app.add_typer(channel_app)


@channel_app.command("add")
def channel_add():
    """Add a new channel to your existing config."""
    config_path = USERDATA_DIR / "config.json"
    if not config_path.exists():
        console.print("[red]No config found.[/red] Run [bold]operator onboard[/bold] first.")
        raise typer.Exit(1)

    import json as _json
    from operator_use.cli.setup import configure_channel
    from operator_use.config import ChannelsConfig

    data = _json.loads(config_path.read_text(encoding="utf-8"))
    existing = ChannelsConfig(**data.get("channels", {}))
    updated = configure_channel(existing)

    data.setdefault("channels", {})
    data["channels"].update(updated.model_dump(by_alias=True, exclude_none=True))
    config_path.write_text(_json.dumps(data, indent=4, ensure_ascii=False), encoding="utf-8")
    console.print("[green]Channel added.[/green] Run [bold]operator run[/bold] to start.")


cron_app = typer.Typer(name="cron", help="Manage scheduled cron jobs.", invoke_without_command=True, no_args_is_help=True)
app.add_typer(cron_app)


def _load_cron():
    from operator_use.crons.service import Cron
    return Cron(store_path=USERDATA_DIR / "crons.json")


def _ms_to_str(ms: int | None) -> str:
    if ms is None:
        return "[dim]-[/dim]"
    from datetime import datetime
    return datetime.fromtimestamp(ms / 1000).strftime("%Y-%m-%d %H:%M:%S")


@cron_app.command("list")
def cron_list():
    """List all cron jobs."""
    cron = _load_cron()
    jobs = cron.list_jobs()
    if not jobs:
        console.print("[dim]No cron jobs found.[/dim]")
        return
    table = Table(box=box.ROUNDED, show_header=True, padding=(0, 1))
    table.add_column("ID", style="dim", no_wrap=True)
    table.add_column("Name", style="bold")
    table.add_column("Schedule")
    table.add_column("Status")
    table.add_column("Last Run")
    table.add_column("Next Run")
    for j in jobs:
        sched = j.schedule.expr or f"every {j.schedule.interval_ms}ms"
        enabled = "[green]enabled[/green]" if j.enabled else "[dim]disabled[/dim]"
        last_status = j.state.last_status or "-"
        if last_status == "failure":
            last_status = f"[red]{last_status}[/red]"
        elif last_status == "success":
            last_status = f"[green]{last_status}[/green]"
        row_status = f"{enabled}  {last_status}"
        table.add_row(j.id[:8], j.name, sched, row_status, _ms_to_str(j.state.last_run_at_ms), _ms_to_str(j.state.next_run_at_ms))
    console.print(f"\n[bold]Cron Jobs[/bold] ({len(jobs)})")
    console.print(table)


@cron_app.command("add")
def cron_add(
    name: str = typer.Argument(..., help="Job name"),
    expr: str = typer.Argument(..., help='Cron expression, e.g. "*/5 * * * *"'),
    message: str = typer.Argument(..., help="Message to send when job fires"),
    channel: str = typer.Option(..., "--channel", "-c", help="Channel name (telegram, discord, slack)"),
    chat_id: str = typer.Option(..., "--chat-id", "-i", help="Chat/user ID to send to"),
    deliver: bool = typer.Option(False, "--deliver", help="Deliver directly (skip agent)"),
    tz: str = typer.Option("UTC", "--tz", help="Timezone, e.g. Asia/Kolkata"),
):
    """Add a new cron job."""
    from operator_use.crons.views import CronSchedule, CronPayload
    cron = _load_cron()
    schedule = CronSchedule(mode="cron", expr=expr, tz=tz)
    payload = CronPayload(message=message, deliver=deliver, channel=channel, chat_id=chat_id)
    job = cron.add_job(name=name, schedule=schedule, payload=payload)
    console.print(f"[green]Added[/green] job [bold]{job.name}[/bold] ({job.id[:8]})  next run: {_ms_to_str(job.state.next_run_at_ms)}")


@cron_app.command("remove")
def cron_remove(job_id: str = typer.Argument(..., help="Job ID (or prefix)")):
    """Remove a cron job."""
    cron = _load_cron()
    jobs = [j for j in cron.list_jobs() if j.id.startswith(job_id)]
    if not jobs:
        console.print(f"[yellow]No job found matching:[/yellow] {job_id}")
        raise typer.Exit(1)
    if len(jobs) > 1:
        console.print(f"[yellow]Ambiguous ID — {len(jobs)} matches. Use more characters.[/yellow]")
        raise typer.Exit(1)
    cron.remove_job(jobs[0].id)
    console.print(f"[green]Removed[/green] job [bold]{jobs[0].name}[/bold]")


@cron_app.command("enable")
def cron_enable(job_id: str = typer.Argument(..., help="Job ID (or prefix)")):
    """Enable a cron job."""
    cron = _load_cron()
    jobs = [j for j in cron.list_jobs() if j.id.startswith(job_id)]
    if not jobs:
        console.print(f"[yellow]No job found matching:[/yellow] {job_id}")
        raise typer.Exit(1)
    cron.update_job(jobs[0].id, enabled=True)
    console.print(f"[green]Enabled[/green] job [bold]{jobs[0].name}[/bold]")


@cron_app.command("disable")
def cron_disable(job_id: str = typer.Argument(..., help="Job ID (or prefix)")):
    """Disable a cron job."""
    cron = _load_cron()
    jobs = [j for j in cron.list_jobs() if j.id.startswith(job_id)]
    if not jobs:
        console.print(f"[yellow]No job found matching:[/yellow] {job_id}")
        raise typer.Exit(1)
    cron.update_job(jobs[0].id, enabled=False)
    console.print(f"[dim]Disabled[/dim] job [bold]{jobs[0].name}[/bold]")


config_app = typer.Typer(name="config", help="Get, set, or unset config values.", invoke_without_command=True, no_args_is_help=True)
app.add_typer(config_app)


def _load_config_json() -> tuple[dict, Path]:
    config_path = USERDATA_DIR / "config.json"
    if not config_path.exists():
        console.print("[red]No config found.[/red] Run [bold]operator onboard[/bold] first.")
        raise typer.Exit(1)
    return json.loads(config_path.read_text(encoding="utf-8")), config_path


def _save_config_json(data: dict, path: Path) -> None:
    path.write_text(json.dumps(data, indent=4, ensure_ascii=False), encoding="utf-8")


def _get_nested(data: dict, keys: list[str]):
    for k in keys:
        if not isinstance(data, dict) or k not in data:
            return None
        data = data[k]
    return data


def _set_nested(data: dict, keys: list[str], value) -> None:
    for k in keys[:-1]:
        data = data.setdefault(k, {})
    data[keys[-1]] = value


def _unset_nested(data: dict, keys: list[str]) -> bool:
    for k in keys[:-1]:
        if not isinstance(data, dict) or k not in data:
            return False
        data = data[k]
    if keys[-1] in data:
        del data[keys[-1]]
        return True
    return False


def _coerce(value: str):
    if value.lower() == "true":
        return True
    if value.lower() == "false":
        return False
    try:
        return int(value)
    except ValueError:
        pass
    try:
        return float(value)
    except ValueError:
        pass
    return value


def _flatten(data: dict, prefix: str = "") -> list[tuple[str, str]]:
    rows = []
    for k, v in data.items():
        full_key = f"{prefix}.{k}" if prefix else k
        if isinstance(v, dict):
            rows.extend(_flatten(v, full_key))
        else:
            rows.append((full_key, str(v)))
    return rows


@config_app.command("list")
def config_list():
    """List all config values."""
    data, _ = _load_config_json()
    table = Table(box=box.ROUNDED, show_header=True, padding=(0, 1))
    table.add_column("Key", style="cyan")
    table.add_column("Value")
    for key, val in _flatten(data):
        # mask secrets
        if any(s in key for s in ("token", "api_key", "apiKey", "secret", "password")):
            val = f"{val[:16]}...{val[-8:]}" if len(val) > 24 else val
        table.add_row(key, val)
    console.print(table)


@config_app.command("get")
def config_get(key: str = typer.Argument(..., help="Dot-separated key, e.g. agent.llm.provider")):
    """Get a config value."""
    data, _ = _load_config_json()
    value = _get_nested(data, key.split("."))
    if value is None:
        console.print(f"[yellow]Key not found:[/yellow] {key}")
        raise typer.Exit(1)
    console.print(value)


@config_app.command("set")
def config_set(
    key: str = typer.Argument(..., help="Dot-separated key, e.g. agent.llm.model"),
    value: str = typer.Argument(..., help="Value to set"),
):
    """Set a config value."""
    data, path = _load_config_json()
    _set_nested(data, key.split("."), _coerce(value))
    _save_config_json(data, path)
    console.print(f"[green]Set[/green] {key} = {value}")


@config_app.command("unset")
def config_unset(key: str = typer.Argument(..., help="Dot-separated key to remove")):
    """Remove a config key."""
    data, path = _load_config_json()
    if _unset_nested(data, key.split(".")):
        _save_config_json(data, path)
        console.print(f"[green]Unset[/green] {key}")
    else:
        console.print(f"[yellow]Key not found:[/yellow] {key}")
        raise typer.Exit(1)


@app.command("channels")
def channels():
    """Show configured channel accounts and their status."""
    config_path = USERDATA_DIR / "config.json"
    if not config_path.exists():
        console.print("[red]No config found.[/red] Run [bold]operator onboard[/bold] first.")
        raise typer.Exit(1)

    config = json.loads(config_path.read_text(encoding="utf-8"))
    ch = config.get("channels", {})

    CHANNEL_DEFS = [
        ("Telegram",  ch.get("telegram", {}),  ["token"]),
        ("Discord",   ch.get("discord", {}),   ["token"]),
        ("Slack",     ch.get("slack", {}),      ["botToken", "bot_token"]),
    ]

    table = Table(box=box.ROUNDED, show_header=True, padding=(0, 1))
    table.add_column("Channel", style="bold")
    table.add_column("Status")
    table.add_column("Token")
    table.add_column("Allow From")

    for name, cfg, token_keys in CHANNEL_DEFS:
        token = next((cfg.get(k, "") for k in token_keys if cfg.get(k)), "")
        configured = bool(token)
        status = "[green]active[/green]" if configured else "[dim]not configured[/dim]"
        masked = f"{token[:16]}...{token[-8:]}" if len(token) > 24 else ("[dim]-[/dim]" if not token else token)
        allow = ", ".join(cfg.get("allowFrom", cfg.get("allow_from", []))) or "[dim]all[/dim]"
        table.add_row(name, status, masked, allow)

    console.print("\n[bold]Channels[/bold]")
    console.print(table)


@app.command("models")
def models():
    """Show configured model providers and active LLM/STT/TTS settings."""
    config_path = USERDATA_DIR / "config.json"
    if not config_path.exists():
        console.print("[red]No config found.[/red] Run [bold]operator onboard[/bold] first.")
        raise typer.Exit(1)

    config = json.loads(config_path.read_text(encoding="utf-8"))
    agent = config.get("agent", {})
    llm = agent.get("llm", {})
    stt = agent.get("stt", {})
    tts = agent.get("tts", {})
    providers = config.get("providers", {})

    # Active models panel
    active_table = Table(box=box.ROUNDED, show_header=False, padding=(0, 1))
    active_table.add_column("Key", style="bold cyan")
    active_table.add_column("Value")
    active_table.add_row("LLM", f"{llm.get('provider', '-')}  /  {llm.get('model', '-')}")
    if stt.get("enabled"):
        active_table.add_row("STT", f"{stt.get('provider', '-')}  /  {stt.get('model', '-')}")
    if tts.get("enabled"):
        active_table.add_row("TTS", f"{tts.get('provider', '-')}  /  {tts.get('model', '-')}  (voice: {tts.get('voice', '-')})")

    console.print("\n[bold]Active Models[/bold]")
    console.print(active_table)

    # Providers table
    prov_table = Table(box=box.ROUNDED, show_header=True, padding=(0, 1))
    prov_table.add_column("Provider", style="bold")
    prov_table.add_column("API Key")
    prov_table.add_column("Base URL")

    for name, cfg in providers.items():
        if not isinstance(cfg, dict):
            continue
        key = cfg.get("apiKey", cfg.get("api_key", ""))
        base = cfg.get("apiBase", cfg.get("api_base", "")) or "[dim]-[/dim]"
        masked_key = f"{key[:16]}...{key[-8:]}" if len(key) > 24 else ("[dim]not set[/dim]" if not key else key)
        active_marker = " [green]*[/green]" if name == llm.get("provider") else ""
        prov_table.add_row(name.replace("_", " ").title() + active_marker, masked_key, base)

    console.print("\n[bold]Providers[/bold]  [dim]([green]*[/green] = active LLM)[/dim]")
    console.print(prov_table)


auth_app = typer.Typer(name="auth", help="Authenticate with OAuth-based providers.", invoke_without_command=True, no_args_is_help=True)
app.add_typer(auth_app)


@auth_app.command("antigravity")
def auth_antigravity():
    """Login with Google Cloud Code Assist (Antigravity) OAuth."""
    from operator_use.providers.antigravity.auth import login, load_auth
    existing = load_auth()
    if existing and existing.get("access_token"):
        import time as _t
        expires_at = existing.get("expires_at", 0)
        if expires_at > _t.time() + 60:
            console.print(f"[green]Already authenticated![/green] Project: {existing.get('project_id', '-')}")
            return
    console.print("[bold]Authenticating with Antigravity (Google Cloud Code Assist)...[/bold]")
    try:
        result = login()
        console.print(f"[green]Logged in![/green] Project: {result.get('project_id', '-')}")
    except Exception as e:
        console.print(f"[red]Auth failed:[/red] {e}")
        raise typer.Exit(1)


@auth_app.command("claude-code")
def auth_claude_code():
    """Login with Claude Code OAuth (token auto-discovered from Claude CLI)."""
    import subprocess
    from operator_use.providers.claude_code.llm import load_claude_code_token
    token = load_claude_code_token()
    if token:
        console.print(f"[green]Already authenticated![/green] Token: {token[:20]}...")
        return
    console.print("[bold]Authenticating with Claude Code...[/bold]")
    console.print("Launching [bold]claude[/bold] login flow...")
    try:
        subprocess.run(["claude", "login"], check=True)
    except FileNotFoundError:
        console.print("[red]claude CLI not found.[/red] Install it with:")
        console.print("  npm install -g @anthropic-ai/claude-code")
        raise typer.Exit(1)
    except subprocess.CalledProcessError as e:
        console.print(f"[red]Auth failed:[/red] {e}")
        raise typer.Exit(1)
    token = load_claude_code_token()
    if token:
        console.print(f"[green]Logged in![/green] Token: {token[:20]}...")
    else:
        console.print("[yellow]Token will be auto-discovered from ~/.claude/.credentials.json on next run.[/yellow]")


@auth_app.command("github-copilot")
def auth_github_copilot():
    """Login with GitHub Copilot OAuth (GitHub Device Flow)."""
    from operator_use.providers.github_copilot.auth import load_auth, get_copilot_token
    auth = load_auth()
    if auth and auth.get("github_token"):
        import time as _t
        if auth.get("copilot_expires_at", 0) > _t.time() + 60:
            console.print("[green]Already authenticated![/green] GitHub Copilot token is valid.")
            return
        # Try refreshing the copilot token with existing github token
        try:
            get_copilot_token(auth)
            console.print("[green]Already authenticated![/green] Copilot token refreshed.")
            return
        except Exception:
            pass  # Fall through to re-login

    console.print("[bold]Authenticating with GitHub Copilot...[/bold]")
    try:
        from operator_use.providers.github_copilot.auth import login
        result = login()
        console.print("[green]Logged in![/green] GitHub Copilot credentials saved.")
    except Exception as e:
        console.print(f"[red]Auth failed:[/red] {e}")
        raise typer.Exit(1)


@auth_app.command("codex")
def auth_codex():
    """Login with OpenAI Codex (ChatGPT subscription) OAuth."""
    import subprocess
    from operator_use.providers.codex.llm import _load_auth
    auth = _load_auth()
    if auth and auth.get("access"):
        console.print(f"[green]Already authenticated![/green] Account: {auth.get('account_id', '-')}")
        return
    console.print("[bold]Authenticating with Codex (ChatGPT subscription)...[/bold]")
    console.print("Launching [bold]codex login[/bold]...")
    try:
        subprocess.run(["codex", "login"], check=True)
    except FileNotFoundError:
        console.print("[red]codex CLI not found.[/red] Install it with:")
        console.print("  npm install -g @openai/codex")
        raise typer.Exit(1)
    except subprocess.CalledProcessError as e:
        console.print(f"[red]Auth failed:[/red] {e}")
        raise typer.Exit(1)
    auth = _load_auth()
    if auth and auth.get("access"):
        console.print(f"[green]Logged in![/green] Account: {auth.get('account_id', '-')}")
    else:
        console.print("[yellow]Token will be auto-discovered from ~/.codex/auth.json on next run.[/yellow]")


@app.command("logs")
def logs(
    lines: int = typer.Option(50, "--lines", "-n", help="Number of lines to show."),
    follow: bool = typer.Option(False, "--follow", "-f", help="Follow log output in real time."),
):
    """Show agent logs."""
    log_file = USERDATA_DIR / "operator.log"
    if not log_file.exists():
        console.print("[dim]No log file found. Start the agent first with [bold]operator run[/bold].[/dim]")
        raise typer.Exit(1)

    # Show last N lines
    with open(log_file, encoding="utf-8") as f:
        all_lines = f.readlines()
    for line in all_lines[-lines:]:
        console.print(line.rstrip())

    if follow:
        console.print("[dim]--- following (Ctrl+C to stop) ---[/dim]")
        with open(log_file, encoding="utf-8") as f:
            f.seek(0, 2)  # seek to end
            try:
                while True:
                    line = f.readline()
                    if line:
                        console.print(line.rstrip())
                    else:
                        time.sleep(0.3)
            except KeyboardInterrupt:
                pass
