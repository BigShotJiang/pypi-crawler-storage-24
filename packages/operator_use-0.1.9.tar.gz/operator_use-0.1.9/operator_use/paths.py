from pathlib import Path

_DIR = Path.home() / ".operator-use"


def get_userdata_dir() -> Path:
    """Return the user data directory: ~/.operator-use"""
    return _DIR
