﻿"""Centralized configuration schema for Operator, inspired by nanobot."""

from pathlib import Path
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel
from pydantic_settings import BaseSettings, SettingsConfigDict


class Base(BaseModel):
    """Base model that accepts both camelCase and snake_case keys."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)


class TelegramConfig(Base):
    """Telegram channel configuration."""

    enabled: bool = False
    token: str = ""  # Bot token from @BotFather
    allow_from: List[str] = Field(default_factory=list)  # Allowed user IDs or usernames
    use_webhook: bool = False
    webhook_url: str = ""
    webhook_path: str = "/telegram"
    webhook_port: int = 8080
    proxy: Optional[str] = None  # HTTP/SOCKS5 proxy URL
    reply_to_message: bool = True  # If true, bot replies quote the original message
    media_dir: Optional[str] = None


class DiscordConfig(Base):
    """Discord channel configuration."""

    enabled: bool = False
    token: str = ""  # Bot token from Discord Developer Portal
    allow_from: List[str] = Field(default_factory=list)  # Allowed user IDs
    reply_to_message: bool = True  # If true, bot replies quote the original message
    use_webhook: bool = False  # Use webhook mode instead of WebSocket
    webhook_url: str = ""  # Webhook URL for receiving events
    webhook_path: str = "/discord"  # Webhook path
    webhook_port: int = 8080  # Webhook server port
    media_dir: Optional[str] = None


class SlackConfig(Base):
    """Slack channel configuration (DM mode)."""

    enabled: bool = False
    bot_token: str = ""  # Bot User OAuth Token (xoxb-...)
    app_token: str = ""  # App-Level Token (xapp-..., for Socket Mode)
    use_webhook: bool = False  # Use webhook mode instead of Socket Mode
    webhook_url: str = ""  # Public URL for Slack Request URL
    webhook_path: str = "/slack"  # Webhook path
    webhook_port: int = 8080  # Webhook server port
    signing_secret: str = ""  # Slack signing secret for request verification
    reply_to_message: bool = True  # If true, bot replies to the original message


class ChannelsConfig(Base):
    """Configuration for chat channels."""

    telegram: TelegramConfig = Field(default_factory=TelegramConfig)
    discord: DiscordConfig = Field(default_factory=DiscordConfig)
    slack: SlackConfig = Field(default_factory=SlackConfig)


class LLMConfig(Base):
    """LLM configuration (part of AgentConfig)."""

    provider: str = "openai"
    model: str = "gpt-4o"


class STTConfig(Base):
    """Speech-to-Text configuration."""

    enabled: bool = False
    provider: Optional[str] = None
    model: Optional[str] = None


class TTSConfig(Base):
    """Text-to-Speech configuration."""

    enabled: bool = False
    provider: Optional[str] = None
    model: Optional[str] = None
    voice: Optional[str] = None


class AgentConfig(Base):
    """Unified agent and workspace configuration."""

    workspace: str = ".operator_use/workspace"
    llm: LLMConfig = Field(default_factory=LLMConfig)
    stt: STTConfig = Field(default_factory=STTConfig)
    tts: TTSConfig = Field(default_factory=TTSConfig)
    max_tool_iterations: int = 40
    memory_window: int = 100
    streaming: bool = True
    computer_use: bool = False


class ProviderConfig(Base):
    """LLM provider configuration (keys, bases)."""

    api_key: str = ""
    api_base: Optional[str] = None


class ProvidersConfig(Base):
    """Configuration for all LLM providers (to store keys centrally)."""

    openai: ProviderConfig = Field(default_factory=ProviderConfig)
    anthropic: ProviderConfig = Field(default_factory=ProviderConfig)
    google: ProviderConfig = Field(default_factory=ProviderConfig)
    groq: ProviderConfig = Field(default_factory=ProviderConfig)
    mistral: ProviderConfig = Field(default_factory=ProviderConfig)
    nvidia: ProviderConfig = Field(default_factory=ProviderConfig)
    ollama: ProviderConfig = Field(default_factory=ProviderConfig)
    cerebras: ProviderConfig = Field(default_factory=ProviderConfig)
    open_router: ProviderConfig = Field(default_factory=ProviderConfig)
    azure_openai: ProviderConfig = Field(default_factory=ProviderConfig)
    deepseek: ProviderConfig = Field(default_factory=ProviderConfig)
    sarvam: ProviderConfig = Field(default_factory=ProviderConfig)
    codex: ProviderConfig = Field(default_factory=ProviderConfig)
    claude_code: ProviderConfig = Field(default_factory=ProviderConfig)
    antigravity: ProviderConfig = Field(default_factory=ProviderConfig)
    github_copilot: ProviderConfig = Field(default_factory=ProviderConfig)


class Config(BaseSettings):
    """Root configuration for Operator, merging file and environment."""

    agent: AgentConfig = Field(default_factory=AgentConfig)
    channels: ChannelsConfig = Field(default_factory=ChannelsConfig)
    providers: ProvidersConfig = Field(default_factory=ProvidersConfig)

    model_config = SettingsConfigDict(
        env_prefix="OPERATOR_",
        env_nested_delimiter="__",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    @property
    def workspace_path(self) -> Path:
        return Path(self.agent.workspace).expanduser().resolve()


def load_config(user_data_dir: Path) -> Config:
    """Load configuration from .operator_use/config.json and environment."""
    import json

    path = user_data_dir / "config.json"
    data = {}
    if path.exists():
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            print(f"Warning: Failed to load config from {path}: {e}")

    # Initialize Config (Pydantic merges JSON data + actual environment variables)
    return Config(**data)
