from .WkLog import *
from .WkLog_new import *

__version__ = "1.1.2"
