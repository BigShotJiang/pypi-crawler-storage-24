# capcat scripts sub-package
