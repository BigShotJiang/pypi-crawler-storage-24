# causalor-python

Rust-backed Python bindings and API client helpers for Causalor.

## Install

Published package flow:

```bash
pip install causalor
```

Local development flow:

```bash
pip install maturin
maturin develop
```

## Build

```bash
maturin build --release
```

Python `3.8` through `3.13` are supported directly. Python `3.14+` requires `PYO3_USE_ABI3_FORWARD_COMPATIBILITY=1`.

## Usage

```python
import json
import causalor

schema = {
    "version": "1.0.0",
    "metadata": {"name": "SDK Demo"},
    "time": {"type": "discrete", "horizon": 4},
    "resources": {
        "money": {"initial": 1000.0, "min": 0.0, "max": 10000.0}
    },
    "variables": {
        "x": {
            "type": "float",
            "initial": 0.0,
            "min": 0.0,
            "max": 10.0,
            "discretization": 1.0
        }
    },
    "actions": [
        {
            "name": "increment",
            "cost": {"money": 10.0},
            "effects": {"x": {"op": "add", "value": 1.0}},
            "preconditions": []
        }
    ],
    "transitions": [],
    "constraints": [],
    "goal": {
        "type": "threshold",
        "conditions": [{"variable": "x", "operator": "gte", "value": 3.0}]
    }
}

session = causalor.CausalorSession(
    json.dumps(schema),
    api_key="your_api_key_here",
    base_url="https://api.causalorlabs.com"
)

remote_result = json.loads(session.evaluate())
local_result = json.loads(session.simulate_local())
```

## Functions

- `simulate(schema_json, budget=None, api_key=None, base_url=None)` - one-off remote evaluation
- `simulate_local(schema_json, budget=None)` - one-off local engine execution
- `CausalorSession.evaluate(budget=None)` - remote evaluation with timeout and single retry
- `CausalorSession.simulate_local(budget=None)` - capped local execution

## Runtime Notes

- Remote calls send `X-Causalor-Version` matching the SDK build version.
- Retry attempts preserve `X-Causalor-Key`.
- Local execution is capped to `<= 5` variables and horizon `<= 12`.
- The production hosted API is expected at `https://api.causalorlabs.com`.
