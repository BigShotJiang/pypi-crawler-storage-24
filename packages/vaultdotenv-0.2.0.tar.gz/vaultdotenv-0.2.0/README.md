# vaultdotenv

Drop-in `python-dotenv` replacement. One master key locally, everything else encrypted remotely.

## Install

```bash
pip install vaultdotenv
```

## Quick Start

Replace `python-dotenv` with one line:

```python
# Before
from dotenv import load_dotenv
load_dotenv()

# After
from vaultdotenv import load_vault
load_vault()
```

If a `VAULT_KEY` is found in your `.env` file, secrets are pulled from the vault server and injected into `os.environ`. If no `VAULT_KEY` is present, it behaves exactly like `python-dotenv`.

## CLI

The package includes a full CLI (`vde` or `vaultdotenv`):

```bash
vde init                        # Initialize a new vault project
vde push                        # Push .env secrets to vault
vde pull                        # Pull secrets from vault
vde set KEY "value"             # Set a single secret
vde get KEY                     # Get a secret (masked)
vde versions                    # List secret versions
vde rollback --version 3        # Rollback to a version
vde login                       # Link CLI to dashboard
```

## API

```python
from vaultdotenv import load_vault, load_vault_sync, pull_secrets, push_secrets, watch

# Async load (pulls from server, falls back to cache)
secrets = load_vault()

# Sync load (cache only, no network)
secrets = load_vault_sync()

# Direct pull/push
result = pull_secrets(vault_key, environment="production")
push_secrets(vault_key, {"DB_URL": "postgres://..."}, environment="production")

# Hot reload (polls every 30s)
watch(on_change=lambda changed, all: print("Updated:", list(changed.keys())))
```

## Links

- [Documentation](https://vaultdotenv.io)
- [Dashboard](https://app.vaultdotenv.io)
- [GitHub](https://github.com/vaultdotenv/vaultdotenv)
