"""
Compliance Scorer

Calculates compliance scores based on legal risk, not UX impact.
Different from ux_scorer which uses impact-weighted scoring.
"""

from typing import Dict, List
from .check_interface import ComplianceCheckResult
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class ComplianceScorer:
    """Calculates compliance scores with legal risk weighting."""

    # Severity weights (legal risk)
    SEVERITY_WEIGHTS = {
        "critical": 10.0,   # Could result in major fines/lawsuits
        "high": 5.0,        # Serious violation, moderate fines
        "medium": 2.0,      # Minor violation, warnings
        "low": 0.5          # Best practice, not legally required
    }

    # Regulation priority multipliers (based on fine amounts)
    REGULATION_PRIORITIES = {
        "GDPR": 1.5,        # €20M or 4% revenue (highest globally)
        "CCPA": 1.3,        # $7,500 per violation per consumer
        "DPDP_2023": 1.4,   # ₹250 crore (~$30M), new strict enforcement
        "WCAG_2_2": 1.2,    # Frequent lawsuits, $5K-500K settlements
        "LGPD": 1.1,        # R$50M (~$10M), moderate enforcement
        "UK_GDPR": 1.4,     # Similar to GDPR
        "PRIVACY_ACT": 1.1, # AU$50M, emerging enforcement
        "PIPL": 1.2,        # Growing enforcement in China
    }

    def __init__(self, compliance_criteria_path: str = None):
        """
        Initialize the compliance scorer.

        Args:
            compliance_criteria_path: Path to compliance-criteria.json
                                     (not yet implemented, for future use)
        """
        self.compliance_criteria_path = compliance_criteria_path

    def calculate_compliance_score(
        self,
        test_results: List[ComplianceCheckResult]
    ) -> Dict:
        """
        Calculate compliance score from test results.

        Args:
            test_results: List of ComplianceCheckResults

        Returns:
            Dictionary with compliance score, grade, violations, and recommendations
        """
        total_risk_score = 0
        max_possible_risk = 0
        violations = []
        passed_checks = 0

        for result in test_results:
            # Skip errors and skipped checks
            if result.status in ["error", "skipped"]:
                continue

            # Calculate risk weight for this check
            severity_weight = self.SEVERITY_WEIGHTS.get(result.severity, 2.0)
            regulation_priority = self.REGULATION_PRIORITIES.get(
                result.regulation_id,
                1.0
            )
            risk_weight = severity_weight * regulation_priority

            max_possible_risk += risk_weight

            if result.status == "failed":
                total_risk_score += risk_weight
                violations.append({
                    'requirement_id': result.requirement_id,
                    'regulation': result.regulation_id,
                    'severity': result.severity,
                    'risk_weight': risk_weight,
                    'evidence': result.evidence,
                    'legal_risk': result.legal_risk or 'Unknown',
                    'screenshot': result.screenshot_path
                })
            elif result.status == "passed":
                passed_checks += 1

        # Calculate compliance percentage (inverse of risk)
        compliance_percentage = (
            100 * (1 - (total_risk_score / max_possible_risk))
            if max_possible_risk > 0 else 100
        )

        # Letter grade
        grade = self._calculate_grade(compliance_percentage)

        # Financial risk estimate
        estimated_fine = self._estimate_potential_fine(violations)

        # Group violations by regulation
        regulations_affected = list(set(v['regulation'] for v in violations))

        # Critical violations (must fix immediately)
        critical_violations = [v for v in violations if v['severity'] == 'critical']

        return {
            'compliance_percentage': round(compliance_percentage, 1),
            'grade': grade,
            'total_risk_score': round(total_risk_score, 2),
            'max_possible_risk': round(max_possible_risk, 2),
            'total_checks': len(test_results),
            'passed_checks': passed_checks,
            'violations_count': len(violations),
            'violations': sorted(violations, key=lambda x: x['risk_weight'], reverse=True),
            'estimated_fine_range': estimated_fine,
            'critical_violations': critical_violations,
            'regulations_affected': regulations_affected,
            'recommendation': self._get_recommendation(grade, violations),
            'timestamp': datetime.now().isoformat()
        }

    def _calculate_grade(self, percentage: float) -> str:
        """
        Convert compliance percentage to letter grade.

        Args:
            percentage: Compliance percentage (0-100)

        Returns:
            Letter grade with description
        """
        if percentage >= 95:
            return "A+ (Fully Compliant)"
        elif percentage >= 85:
            return "A (Mostly Compliant)"
        elif percentage >= 75:
            return "B (Minor Issues)"
        elif percentage >= 60:
            return "C (Significant Gaps)"
        elif percentage >= 40:
            return "D (Major Violations)"
        else:
            return "F (Critical Non-Compliance)"

    def _estimate_potential_fine(self, violations: List[Dict]) -> Dict:
        """
        Estimate potential financial exposure from violations.

        Args:
            violations: List of violation dictionaries

        Returns:
            Dictionary with min/max fine estimates
        """
        min_fine = 0
        max_fine = 0

        # Count violations by regulation
        gdpr_violations = [v for v in violations if 'GDPR' in v['regulation']]
        ccpa_violations = [v for v in violations if 'CCPA' in v['regulation']]
        dpdp_violations = [v for v in violations if 'DPDP' in v['regulation']]
        wcag_violations = [v for v in violations if 'WCAG' in v['regulation']]
        lgpd_violations = [v for v in violations if 'LGPD' in v['regulation']]

        # GDPR: €20M or 4% revenue (using conservative estimate)
        if gdpr_violations:
            critical_count = len([v for v in gdpr_violations if v['severity'] == 'critical'])
            if critical_count > 0:
                min_fine += 50000  # Minimum realistic fine
                max_fine += 20000000  # Maximum statutory
            else:
                min_fine += 10000
                max_fine += 500000

        # CCPA: $7,500 per violation per consumer (estimate 1000 consumers affected)
        if ccpa_violations:
            violations_count = len(ccpa_violations)
            min_fine += 7500 * violations_count
            max_fine += 7500 * violations_count * 1000

        # DPDP India: Up to ₹250 crore (~$30M)
        if dpdp_violations:
            critical_count = len([v for v in dpdp_violations if v['severity'] == 'critical'])
            if critical_count > 0:
                min_fine += 100000
                max_fine += 30000000
            else:
                min_fine += 10000
                max_fine += 1000000

        # WCAG/ADA: Lawsuit settlements $5K-500K
        if wcag_violations:
            min_fine += 5000
            max_fine += 500000

        # Brazil LGPD: Up to R$50M (~$10M)
        if lgpd_violations:
            min_fine += 10000
            max_fine += 10000000

        return {
            "currency": "USD",
            "min": int(min_fine),
            "max": int(max_fine),
            "note": "Estimate only - actual penalties vary significantly based on revenue, intent, and prior violations"
        }

    def _get_recommendation(self, grade: str, violations: List[Dict]) -> str:
        """
        Generate recommendation based on score and violations.

        Args:
            grade: Letter grade
            violations: List of violations

        Returns:
            Recommendation text
        """
        if not violations:
            return (
                "✅ Excellent! No compliance violations detected. "
                "Continue monitoring for regulation changes."
            )

        critical_count = len([v for v in violations if v['severity'] == 'critical'])
        high_count = len([v for v in violations if v['severity'] == 'high'])

        if critical_count > 0:
            return (
                f"🔴 URGENT: {critical_count} critical violation(s) detected. "
                f"Fix immediately before launch to avoid major fines. "
                f"Focus on {', '.join(set(v['regulation'] for v in violations if v['severity'] == 'critical'))}."
            )
        elif high_count > 0:
            return (
                f"⚠️ WARNING: {high_count} high-severity violation(s) detected. "
                f"Address these issues before production deployment."
            )
        else:
            return (
                f"⚡ {len(violations)} minor issue(s) detected. "
                f"Address when convenient to achieve full compliance."
            )
