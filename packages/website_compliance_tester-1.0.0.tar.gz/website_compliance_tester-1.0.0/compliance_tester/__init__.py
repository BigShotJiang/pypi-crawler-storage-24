"""
Website Compliance Tester

Automated regulatory compliance testing for e-commerce websites.
Tests against GDPR, DPDP (India), CCPA (US), WCAG 2.2, and other regulations.

Usage:
    from compliance_tester import ComplianceScorer, generate_compliance_report
    from compliance_tester.cli import run_compliance_checks

    # Run checks against a URL
    results = await run_compliance_checks("https://example.com")

    # Calculate compliance score
    scorer = ComplianceScorer()
    score = scorer.calculate_compliance_score(results)

    # Generate report
    report = generate_compliance_report(score, results)
    print(report)
"""

from .check_interface import ComplianceCheck, ComplianceCheckResult
from .check_registry import compliance_registry, register_compliance_check
from .compliance_scorer import ComplianceScorer
from .compliance_reporter import generate_compliance_report

# Import all checks to register them (decorators run on import)
# GDPR checks
from .checks.gdpr import (
    cookie_consent_banner,
    cookie_consent,
    one_click_rejection,
    consent_prominence,
    consent_withdrawal,
    data_portability,
    privacy_policy_link,
    privacy_policy_content
)

# DPDP checks
from .checks.dpdp import (
    consent_before_collection,
    purpose_limitation,
    parental_consent,
    data_deletion
)

# CCPA checks
from .checks.ccpa import (
    do_not_sell_link,
    opt_out_honored
)

# WCAG checks
from .checks.wcag import (
    keyboard_navigation,
    color_contrast,
    form_labels,
    form_input_purpose,
    focus_visible,
    focus_order,
    touch_target_size,
    text_spacing,
    reflow,
    no_keyboard_trap
)

__all__ = [
    'ComplianceCheck',
    'ComplianceCheckResult',
    'compliance_registry',
    'register_compliance_check',
    'ComplianceScorer',
    'generate_compliance_report',
]

__version__ = '1.0.0'
