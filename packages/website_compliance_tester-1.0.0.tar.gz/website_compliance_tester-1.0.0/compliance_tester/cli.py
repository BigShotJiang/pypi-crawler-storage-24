#!/usr/bin/env python3
"""
CLI for website compliance testing.

Test websites for GDPR, CCPA, DPDP, and WCAG compliance.
"""
import asyncio
import argparse
import sys
from pathlib import Path
from typing import List, Optional

from playwright.async_api import async_playwright, Page

from .check_interface import ComplianceCheckResult
from .check_registry import compliance_registry
from .compliance_scorer import ComplianceScorer
from .compliance_reporter import generate_compliance_report


async def run_compliance_checks(
    url: str,
    regulations: Optional[List[str]] = None,
    headless: bool = True,
    verbose: bool = False
) -> List[ComplianceCheckResult]:
    """
    Run compliance checks against a live URL.

    Args:
        url: URL to test
        regulations: List of regulation IDs to test (e.g., ["GDPR", "CCPA"])
        headless: Run browser in headless mode
        verbose: Print detailed output

    Returns:
        List of check results
    """
    results = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=headless)
        context = await browser.new_context(
            viewport={'width': 1920, 'height': 1080},
            user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        )
        page = await context.new_page()

        try:
            if verbose:
                print(f"🌐 Loading {url}...")

            await page.goto(url, wait_until='networkidle', timeout=30000)

            if verbose:
                print(f"✅ Page loaded successfully")

            # Get all registered checks
            all_checks = compliance_registry.list_all()

            # Filter by regulation if specified
            if regulations:
                checks_to_run = {
                    key: check_class for key, check_class in all_checks.items()
                    if check_class.regulation_id in regulations
                }
            else:
                checks_to_run = all_checks

            if verbose:
                print(f"\n🔍 Running {len(checks_to_run)} compliance checks...\n")

            # Run each check
            for check_key, check_class in checks_to_run.items():
                try:
                    # Instantiate check
                    check_instance = check_class(
                        regulation_id=check_class.regulation_id,
                        requirement_id=check_class.requirement_id
                    )

                    if verbose:
                        print(f"  • {check_class.requirement_id}: {check_class.__name__}...")

                    # Execute check
                    result = await check_instance.execute(page, url)
                    results.append(result)

                    if verbose:
                        status_icon = "✅" if result.status == "passed" else "❌"
                        print(f"    {status_icon} {result.status.upper()}")

                except Exception as e:
                    if verbose:
                        print(f"    ⚠️  ERROR: {str(e)}")

                    # Create error result
                    results.append(ComplianceCheckResult(
                        regulation_id=check_class.regulation_id,
                        requirement_id=check_class.requirement_id,
                        status="error",
                        severity="unknown",
                        evidence=f"Check failed: {str(e)}",
                        metadata={"error": str(e)}
                    ))

        except Exception as e:
            print(f"❌ Error loading page: {e}")
            sys.exit(1)
        finally:
            await browser.close()

    return results


def main():
    """
    Main CLI entry point.

    Usage:
        website-compliance https://example.com
        website-compliance https://example.com --regulations GDPR CCPA
        website-compliance https://example.com --verbose
        website-compliance --list-checks
    """
    parser = argparse.ArgumentParser(
        description="Test websites for GDPR, CCPA, DPDP, and WCAG compliance",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  website-compliance https://example.com
  website-compliance https://example.com --regulations GDPR CCPA
  website-compliance https://example.com --format json --output report.json
  website-compliance --list-checks
        """
    )

    parser.add_argument(
        "url",
        nargs="?",
        help="URL to test for compliance"
    )

    parser.add_argument(
        "--regulations",
        nargs="+",
        help="Specific regulations to test (e.g., GDPR CCPA DPDP WCAG_2_2)"
    )

    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Show detailed output"
    )

    parser.add_argument(
        "--headless",
        action="store_true",
        default=True,
        help="Run browser in headless mode (default: True)"
    )

    parser.add_argument(
        "--headed",
        action="store_true",
        help="Run browser in headed mode (show browser window)"
    )

    parser.add_argument(
        "--format",
        choices=["text", "json", "html"],
        default="text",
        help="Output format (default: text)"
    )

    parser.add_argument(
        "--output", "-o",
        type=Path,
        help="Output file path (default: stdout)"
    )

    parser.add_argument(
        "--list-checks",
        action="store_true",
        help="List all available compliance checks"
    )

    args = parser.parse_args()

    # List checks
    if args.list_checks:
        all_checks = compliance_registry.list_all()

        print(f"\n📋 Available Compliance Checks ({len(all_checks)} total)\n")
        print("=" * 80)

        # Group by regulation
        by_regulation = {}
        for check_key, check_class in all_checks.items():
            reg_id = check_class.regulation_id
            if reg_id not in by_regulation:
                by_regulation[reg_id] = []
            by_regulation[reg_id].append(check_class)

        for reg_id in sorted(by_regulation.keys()):
            checks = by_regulation[reg_id]
            print(f"\n{reg_id} ({len(checks)} checks):")
            print("-" * 80)
            for check_class in sorted(checks, key=lambda c: c.requirement_id):
                print(f"  {check_class.requirement_id:15s} {check_class.__name__}")

        print("\n" + "=" * 80)
        print(f"\nUse: website-compliance <url> --regulations {' '.join(sorted(by_regulation.keys()))}")
        print()
        return

    # Validate URL
    if not args.url:
        parser.print_help()
        print("\n❌ Error: URL is required")
        sys.exit(1)

    # Determine headless mode
    headless = not args.headed

    # Run checks
    print(f"\n🔍 Website Compliance Tester v1.0.0")
    print(f"=" * 80)

    results = asyncio.run(run_compliance_checks(
        url=args.url,
        regulations=args.regulations,
        headless=headless,
        verbose=args.verbose
    ))

    # Calculate score
    scorer = ComplianceScorer()
    score = scorer.calculate_compliance_score(results)

    # Generate report
    report = generate_compliance_report(score, results, verbose=args.verbose)

    # Output report
    if args.output:
        args.output.write_text(report)
        print(f"\n✅ Report saved to {args.output}")
    else:
        print("\n" + "=" * 80)
        print(report)

    # Exit with appropriate code
    if score['critical_violations']:
        sys.exit(1)
    else:
        sys.exit(0)


if __name__ == '__main__':
    main()
