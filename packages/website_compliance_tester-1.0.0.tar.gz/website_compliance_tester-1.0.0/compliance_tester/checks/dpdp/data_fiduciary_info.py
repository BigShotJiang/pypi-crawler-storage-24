"""
DPDP Data Fiduciary Information Check

Tests that websites clearly identify the Data Fiduciary (company) with registered
address and contact details, as required by India's Digital Personal Data Protection Act, 2023.

DPDP Act 2023, Section 5: Obligation to give notice
DPDP Act 2023, Section 3: Definitions (Data Fiduciary)
DPDP Act 2023, Section 11: General obligations of Data Fiduciaries

Regulation: DPDP Act 2023 (India)
Requirement: DPDP_007 - Data Fiduciary Information
Severity: Medium
Automation: 90% automated (manual verification of address completeness)
"""

from playwright.async_api import Page, Locator
from typing import Optional, Dict, List
import logging
import re

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="DPDP_2023", requirement_id="DPDP_007")
class DataFiduciaryInfoCheck(ComplianceCheck):
    """
    DPDP_007: Privacy policy must identify the Data Fiduciary with contact details.

    This check verifies that websites clearly identify the Data Fiduciary (company),
    including registered address and contact information, as required by DPDP Act Section 5.

    Methodology:
    1. Navigate to privacy policy
    2. Search for "Data Fiduciary" identification
    3. Check for company name and legal entity
    4. Verify registered address is provided
    5. Check for Indian business address (if serving Indian users)
    6. Verify contact details are present

    Common violations:
    - No "Data Fiduciary" label/identification
    - Missing company registered address
    - Only foreign address (no Indian presence for Indian users)
    - No contact information
    - Generic "we" without legal entity name

    Legal risk: Up to ₹50 crore (~$6M USD) under DPDP Act Section 33
    Section 5 mandates clear identification of Data Fiduciary
    """

    automation_level = "automated"
    severity = "medium"

    # Privacy policy patterns
    PRIVACY_POLICY_PATTERNS = [
        "privacy policy",
        "privacy notice",
        "data privacy",
        "data protection",
        "गोपनीयता नीति",  # Hindi
    ]

    # Data Fiduciary identification patterns
    DATA_FIDUCIARY_PATTERNS = [
        "data fiduciary",
        "we are the data fiduciary",
        "acts as data fiduciary",
        "in our capacity as data fiduciary",
        "as the data fiduciary",

        # Hindi
        "डेटा फिड्यूशरी",  # data fiduciary
    ]

    # Company identification patterns
    COMPANY_PATTERNS = [
        "company",
        "corporation",
        "limited",
        "ltd",
        "llc",
        "inc",
        "pvt",
        "private limited",
        "incorporated",
        "registered",
        "legal entity",
    ]

    # Address indicators
    ADDRESS_KEYWORDS = [
        "address",
        "registered address",
        "registered office",
        "office address",
        "business address",
        "corporate address",
        "principal place of business",
        "located at",
        "headquarters",
    ]

    # Indian location indicators
    INDIAN_LOCATION_KEYWORDS = [
        "india",
        "भारत",  # Hindi: Bharat/India
        "mumbai",
        "delhi",
        "bangalore",
        "bengaluru",
        "chennai",
        "hyderabad",
        "pune",
        "kolkata",
        "ahmedabad",
        "gurgaon",
        "gurugram",
        "noida",
    ]

    # Indian postal/state patterns
    INDIAN_POSTAL_PATTERNS = [
        r'\b[1-9][0-9]{5}\b',  # Indian PIN code (6 digits, doesn't start with 0)
        "karnataka",
        "maharashtra",
        "tamil nadu",
        "delhi",
        "haryana",
        "uttar pradesh",
        "west bengal",
        "gujarat",
        "telangana",
    ]

    # Contact information patterns
    CONTACT_PATTERNS = [
        "email",
        "e-mail",
        "phone",
        "telephone",
        "contact",
        "reach us",
        "@",  # Email symbol
        "+91",  # Indian phone code
    ]

    def __init__(self, regulation_id: str = "DPDP_2023", requirement_id: str = "DPDP_007"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.privacy_policy_url = None

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the Data Fiduciary information check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting DPDP_007 check for {url}")

            # Navigate to page if needed
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            await page.wait_for_timeout(2000)

            # Step 1: Find privacy policy
            privacy_link = await self._find_privacy_policy_link(page)

            if not privacy_link:
                return await self._create_violation_result(
                    page=page,
                    reason="no_privacy_policy",
                    details={}
                )

            self.privacy_policy_url = await privacy_link.get_attribute("href")

            # Step 2: Navigate to privacy policy
            try:
                await privacy_link.click()
                await page.wait_for_load_state("networkidle", timeout=10000)
            except Exception as e:
                logger.debug(f"Failed to navigate to privacy policy: {e}")
                return await self._create_violation_result(
                    page=page,
                    reason="privacy_policy_inaccessible",
                    details={'error': str(e)}
                )

            # Step 3: Extract and analyze privacy policy content
            policy_content = await page.inner_text("body")
            analysis = self._analyze_fiduciary_disclosure(policy_content)

            # Step 4: Determine compliance
            if analysis['has_violations']:
                return await self._create_violation_result(
                    page=page,
                    reason="insufficient_fiduciary_disclosure",
                    details=analysis
                )
            else:
                return await self._create_compliant_result(analysis)

        except Exception as e:
            logger.error(f"Error in DPDP_007 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="DPDP_2023",
                requirement_id="DPDP_007",
                status="error",
                severity="medium",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _find_privacy_policy_link(self, page: Page) -> Optional[Locator]:
        """Find privacy policy link on the page."""
        for pattern in self.PRIVACY_POLICY_PATTERNS:
            try:
                link = page.get_by_role("link", name=re.compile(pattern, re.IGNORECASE)).first
                if await link.count() > 0:
                    return link
            except Exception as e:
                logger.debug(f"Error searching for {pattern}: {e}")

        return None

    def _analyze_fiduciary_disclosure(self, content: str) -> Dict:
        """
        Analyze privacy policy for Data Fiduciary disclosure.

        Args:
            content: Privacy policy text

        Returns:
            Analysis dictionary
        """
        content_lower = content.lower()

        # Check for "Data Fiduciary" term
        fiduciary_term_found = []
        for pattern in self.DATA_FIDUCIARY_PATTERNS:
            if pattern in content_lower:
                fiduciary_term_found.append(pattern)

        # Check for company identification
        company_found = []
        for pattern in self.COMPANY_PATTERNS:
            if pattern in content_lower:
                company_found.append(pattern)

        # Check for address disclosure
        address_found = []
        for keyword in self.ADDRESS_KEYWORDS:
            if keyword in content_lower:
                address_found.append(keyword)

        # Check for Indian location
        indian_location_found = []
        for location in self.INDIAN_LOCATION_KEYWORDS:
            if location in content_lower:
                indian_location_found.append(location)

        # Check for Indian postal patterns
        indian_postal_found = []
        for pattern in self.INDIAN_POSTAL_PATTERNS:
            if re.search(pattern, content_lower):
                indian_postal_found.append(pattern)

        # Check for contact information
        contact_found = []
        for pattern in self.CONTACT_PATTERNS:
            if pattern in content_lower:
                contact_found.append(pattern)

        # Find email addresses
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        emails = re.findall(email_pattern, content)

        # Determine compliance
        has_fiduciary_term = len(fiduciary_term_found) > 0
        has_company_id = len(company_found) > 0
        has_address = len(address_found) > 0
        has_indian_presence = len(indian_location_found) > 0 or len(indian_postal_found) > 0
        has_contact = len(contact_found) >= 2 or len(emails) > 0

        # Determine violations
        violations = []
        has_violations = False

        # Violation 1: No "Data Fiduciary" term (DPDP-specific requirement)
        if not has_fiduciary_term:
            has_violations = True
            violations.append(
                "Privacy policy does not identify the entity as 'Data Fiduciary' (DPDP Act specific term)"
            )

        # Violation 2: No company identification
        if not has_company_id:
            has_violations = True
            violations.append(
                "No clear company/legal entity identification found"
            )

        # Violation 3: No registered address
        if not has_address:
            has_violations = True
            violations.append(
                "No registered address or business address disclosed"
            )

        # Violation 4: No Indian presence (for sites serving Indian users)
        if not has_indian_presence and has_address:
            # Only flag this if they have an address but it's not Indian
            has_violations = True
            violations.append(
                "No Indian business address found (required for serving Indian users)"
            )

        # Violation 5: No contact information
        if not has_contact:
            has_violations = True
            violations.append(
                "Insufficient contact information for Data Fiduciary"
            )

        return {
            'has_violations': has_violations,
            'violations': violations,
            'has_fiduciary_term': has_fiduciary_term,
            'fiduciary_patterns': fiduciary_term_found[:5],
            'has_company_id': has_company_id,
            'company_patterns': company_found[:5],
            'has_address': has_address,
            'address_keywords': address_found[:5],
            'has_indian_presence': has_indian_presence,
            'indian_locations': indian_location_found[:5],
            'indian_postal_patterns': indian_postal_found[:3],
            'has_contact': has_contact,
            'contact_patterns': contact_found[:5],
            'emails_found': len(emails),
            'policy_length': len(content),
        }

    async def _create_violation_result(
        self,
        page: Page,
        reason: str,
        details: Dict
    ) -> ComplianceCheckResult:
        """Create violation result with evidence."""

        evidence_map = {
            "no_privacy_policy": (
                "No privacy policy found. DPDP Act Section 5 requires Data Fiduciaries to identify themselves "
                "and provide contact details in an easily accessible manner."
            ),
            "privacy_policy_inaccessible": (
                f"Privacy policy not accessible. Error: {details.get('error', 'Unknown')}. "
                "Data Fiduciary information must be easily accessible."
            ),
            "insufficient_fiduciary_disclosure": (
                "Privacy policy found but Data Fiduciary disclosure is insufficient.\n\n"
                "Violations found:\n"
                + "\n".join(f"  - {v}" for v in details.get('violations', []))
                + "\n\nDPDP Act Section 5 requires:\n"
                "  - Clear identification as 'Data Fiduciary'\n"
                "  - Legal entity name and registration details\n"
                "  - Registered office address (in India for Indian users)\n"
                "  - Contact information for Data Principals to reach the Fiduciary"
            ),
        }

        evidence = evidence_map.get(reason, f"Data Fiduciary disclosure violation: {reason}")

        screenshot_path = await self.take_screenshot(page, "dpdp_007_fiduciary_violation")

        metadata = {
            'privacy_policy_url': self.privacy_policy_url,
            'violation_reason': reason,
        }

        if reason == "insufficient_fiduciary_disclosure":
            metadata.update({
                'has_fiduciary_term': details.get('has_fiduciary_term', False),
                'has_company_id': details.get('has_company_id', False),
                'has_address': details.get('has_address', False),
                'has_indian_presence': details.get('has_indian_presence', False),
                'has_contact': details.get('has_contact', False),
                'violations': details.get('violations', []),
            })

        return ComplianceCheckResult(
            regulation_id="DPDP_2023",
            requirement_id="DPDP_007",
            status="failed",
            severity="medium",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata=metadata,
            legal_risk=(
                "Medium-severity DPDP Act 2023 violation (Section 5: Obligation to give notice). "
                "Data Fiduciary must clearly identify itself to Data Principals with complete contact details. "
                "Privacy policy must state the name and contact details of the Data Fiduciary. "
                "For businesses serving Indian users, Indian registered address is required. "
                "Penalties: Up to ₹50 crore (~$6 million USD) under Section 33. "
                "Transparency about Data Fiduciary identity is a foundational DPDP Act requirement."
            )
        )

    async def _create_compliant_result(self, analysis: Dict) -> ComplianceCheckResult:
        """Create compliant result."""

        evidence = (
            f"Privacy policy contains adequate Data Fiduciary identification.\n"
            f"  - 'Data Fiduciary' term used: {'Yes' if analysis['has_fiduciary_term'] else 'No'}\n"
            f"  - Fiduciary patterns: {', '.join(analysis['fiduciary_patterns'][:2]) if analysis['fiduciary_patterns'] else 'None'}\n"
            f"  - Company identification: {'Yes' if analysis['has_company_id'] else 'No'}\n"
            f"  - Address disclosed: {'Yes' if analysis['has_address'] else 'No'}\n"
            f"  - Indian presence indicated: {'Yes' if analysis['has_indian_presence'] else 'No'}\n"
            f"  - Indian locations found: {', '.join(analysis['indian_locations'][:3]) if analysis['indian_locations'] else 'None'}\n"
            f"  - Contact information: {'Yes' if analysis['has_contact'] else 'No'}\n"
            f"  - Emails found: {analysis['emails_found']}\n\n"
            f"Note: Manual verification recommended to confirm:\n"
            f"  - Registered address is complete and accurate\n"
            f"  - Contact details are functional\n"
            f"  - Legal entity name matches official registration"
        )

        return ComplianceCheckResult(
            regulation_id="DPDP_2023",
            requirement_id="DPDP_007",
            status="passed",
            severity="medium",
            evidence=evidence,
            metadata={
                'privacy_policy_url': self.privacy_policy_url,
                'has_fiduciary_term': analysis['has_fiduciary_term'],
                'fiduciary_patterns': analysis['fiduciary_patterns'],
                'has_company_id': analysis['has_company_id'],
                'has_address': analysis['has_address'],
                'has_indian_presence': analysis['has_indian_presence'],
                'indian_locations': analysis['indian_locations'],
                'has_contact': analysis['has_contact'],
                'emails_found': analysis['emails_found'],
            }
        )
