"""
DPDP Data Retention Disclosure Check

Tests that websites clearly disclose data retention periods and deletion policies,
as required by India's Digital Personal Data Protection Act, 2023.

DPDP Act 2023, Section 8: Retention and erasure of personal data
DPDP Act 2023, Section 5: Obligation to give notice
DPDP Act 2023, Section 12: Duties of Data Fiduciary

Regulation: DPDP Act 2023 (India)
Requirement: DPDP_005 - Data Retention Disclosure
Severity: High
Automation: 75% automated (requires manual review of retention period reasonableness)
"""

from playwright.async_api import Page, Locator
from typing import Optional, Dict, List, Set
import logging
import re

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="DPDP_2023", requirement_id="DPDP_005")
class DataRetentionCheck(ComplianceCheck):
    """
    DPDP_005: Data retention periods must be disclosed and reasonable.

    This check verifies that websites clearly disclose how long they retain
    personal data and their deletion policies, as required by DPDP Act Section 8.

    Methodology:
    1. Find and navigate to privacy policy
    2. Search for retention period disclosures
    3. Check for data deletion procedures
    4. Verify retention is tied to purpose
    5. Look for DPDP-specific retention language

    Common violations:
    - No retention period specified
    - Vague retention statements ("as long as needed")
    - No deletion policy mentioned
    - Indefinite retention without justification
    - No mention of data subject deletion rights

    Legal risk: Up to ₹50 crore (~$6M USD) under DPDP Act Section 33
    Section 8 is a core data minimization requirement
    """

    automation_level = "semi_automated"
    severity = "high"

    # Privacy policy link patterns
    PRIVACY_POLICY_PATTERNS = [
        "privacy policy",
        "privacy notice",
        "data privacy",
        "data protection",
        "privacy statement",
        "गोपनीयता नीति",  # Hindi: privacy policy
    ]

    # Retention period indicators (good - shows disclosure)
    RETENTION_KEYWORDS = [
        # Explicit retention periods
        "retention period",
        "retain data",
        "storage duration",
        "storage period",
        "data retention",
        "retention policy",
        "how long we keep",
        "how long we store",
        "how long we retain",
        "data will be kept",
        "data will be stored",
        "data will be retained",

        # Time-based indicators
        "for [0-9]+ (day|month|year)s?",
        "until you delete",
        "until account closure",
        "until termination",
        "during the term",

        # DPDP-specific
        "retention schedule",
        "data lifecycle",
        "purpose completion",
    ]

    # Deletion/erasure indicators (good - shows deletion policy)
    DELETION_KEYWORDS = [
        "delete",
        "deletion",
        "erase",
        "erasure",
        "remove",
        "removal",
        "right to delete",
        "right to erasure",
        "data deletion",
        "delete after",
        "automatically delete",
        "permanently delete",
        "purge",
        "expunge",
    ]

    # Vague retention statements (bad - non-compliant)
    VAGUE_RETENTION_PATTERNS = [
        "as long as necessary",
        "as long as needed",
        "as long as required",
        "for as long as",
        "indefinitely",
        "permanently",
        "until further notice",
        "at our discretion",
        "as we deem appropriate",
    ]

    # DPDP-specific requirements
    DPDP_RETENTION_KEYWORDS = [
        "purpose fulfilled",
        "purpose completed",
        "no longer necessary",
        "retention necessary",
        "legal obligation",
        "data fiduciary",
        "data principal",
    ]

    def __init__(self, regulation_id: str = "DPDP_2023", requirement_id: str = "DPDP_005"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.privacy_policy_found = False
        self.privacy_policy_url = None

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the data retention disclosure check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting DPDP_005 check for {url}")

            # Navigate to page if needed
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            await page.wait_for_timeout(2000)

            # Step 1: Find privacy policy
            privacy_link = await self._find_privacy_policy_link(page)

            if not privacy_link:
                return await self._create_violation_result(
                    page=page,
                    reason="no_privacy_policy",
                    details={}
                )

            self.privacy_policy_found = True
            self.privacy_policy_url = await privacy_link.get_attribute("href")

            # Step 2: Navigate to privacy policy
            try:
                await privacy_link.click()
                await page.wait_for_load_state("networkidle", timeout=10000)
            except Exception as e:
                logger.debug(f"Failed to navigate to privacy policy: {e}")
                return await self._create_violation_result(
                    page=page,
                    reason="privacy_policy_inaccessible",
                    details={'error': str(e)}
                )

            # Step 3: Extract and analyze privacy policy content
            policy_content = await page.inner_text("body")
            analysis = self._analyze_retention_disclosure(policy_content)

            # Step 4: Determine compliance
            if analysis['has_violations']:
                return await self._create_violation_result(
                    page=page,
                    reason="insufficient_retention_disclosure",
                    details=analysis
                )
            else:
                return await self._create_compliant_result(analysis)

        except Exception as e:
            logger.error(f"Error in DPDP_005 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="DPDP_2023",
                requirement_id="DPDP_005",
                status="error",
                severity="high",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _find_privacy_policy_link(self, page: Page) -> Optional[Locator]:
        """Find privacy policy link on the page."""
        for pattern in self.PRIVACY_POLICY_PATTERNS:
            try:
                link = page.get_by_role("link", name=re.compile(pattern, re.IGNORECASE)).first
                if await link.count() > 0:
                    logger.debug(f"Found privacy policy link: {pattern}")
                    return link
            except Exception as e:
                logger.debug(f"Error searching for pattern {pattern}: {e}")

        # Fallback search
        try:
            all_links = await page.get_by_role("link").all()
            for link in all_links:
                text = await link.inner_text()
                if any(p.lower() in text.lower() for p in self.PRIVACY_POLICY_PATTERNS):
                    return link
        except Exception as e:
            logger.debug(f"Error in fallback search: {e}")

        return None

    def _analyze_retention_disclosure(self, content: str) -> Dict:
        """
        Analyze privacy policy for retention disclosures.

        Args:
            content: Privacy policy text

        Returns:
            Analysis dictionary
        """
        content_lower = content.lower()

        # Count retention keywords
        retention_found = []
        for keyword in self.RETENTION_KEYWORDS:
            # Use regex for patterns with numbers
            if '[0-9]' in keyword:
                if re.search(keyword, content_lower):
                    retention_found.append(keyword)
            else:
                if keyword in content_lower:
                    retention_found.append(keyword)

        # Count deletion keywords
        deletion_found = []
        for keyword in self.DELETION_KEYWORDS:
            if keyword in content_lower:
                deletion_found.append(keyword)

        # Count vague patterns
        vague_found = []
        for pattern in self.VAGUE_RETENTION_PATTERNS:
            if pattern in content_lower:
                vague_found.append(pattern)

        # Count DPDP-specific keywords
        dpdp_retention_found = []
        for keyword in self.DPDP_RETENTION_KEYWORDS:
            if keyword in content_lower:
                dpdp_retention_found.append(keyword)

        # Determine violations
        violations = []
        has_violations = False

        # Violation 1: No retention disclosure
        if len(retention_found) == 0:
            has_violations = True
            violations.append(
                "No data retention period disclosure found in privacy policy"
            )

        # Violation 2: No deletion policy
        if len(deletion_found) < 2:
            has_violations = True
            violations.append(
                f"Insufficient deletion policy disclosure (found {len(deletion_found)} keywords)"
            )

        # Violation 3: Too many vague statements
        if len(vague_found) > 2:
            has_violations = True
            violations.append(
                f"Privacy policy contains {len(vague_found)} vague retention statements: {', '.join(vague_found[:3])}"
            )

        # Violation 4: Missing DPDP-specific language
        if len(dpdp_retention_found) < 2:
            has_violations = True
            violations.append(
                f"Missing DPDP Act specific retention language (found {len(dpdp_retention_found)} keywords)"
            )

        # Violation 5: Policy too short (likely incomplete)
        if len(content) < 500:
            has_violations = True
            violations.append(
                f"Privacy policy too short ({len(content)} characters) - likely incomplete"
            )

        return {
            'has_violations': has_violations,
            'violations': violations,
            'retention_keywords_count': len(retention_found),
            'retention_keywords': retention_found[:10],
            'deletion_keywords_count': len(deletion_found),
            'deletion_keywords': deletion_found[:10],
            'vague_patterns_count': len(vague_found),
            'vague_patterns': vague_found[:10],
            'dpdp_keywords_count': len(dpdp_retention_found),
            'dpdp_keywords': dpdp_retention_found[:10],
            'policy_length': len(content),
        }

    async def _create_violation_result(
        self,
        page: Page,
        reason: str,
        details: Dict
    ) -> ComplianceCheckResult:
        """Create violation result with evidence."""

        evidence_map = {
            "no_privacy_policy": (
                "No privacy policy found. DPDP Act Section 8 requires disclosure of data retention periods. "
                "Privacy policy must be easily accessible and include retention information."
            ),
            "privacy_policy_inaccessible": (
                f"Privacy policy link found but not accessible. Error: {details.get('error', 'Unknown')}. "
                "Retention disclosure must be easily accessible to users."
            ),
            "insufficient_retention_disclosure": (
                "Privacy policy found but data retention disclosure is insufficient.\n\n"
                "Violations found:\n"
                + "\n".join(f"  - {v}" for v in details.get('violations', []))
                + "\n\nDPDP Act Section 8 requires:\n"
                "  - Specific retention periods tied to purpose\n"
                "  - Data deletion after purpose is fulfilled\n"
                "  - Clear retention and deletion policies"
            ),
        }

        evidence = evidence_map.get(reason, f"Data retention disclosure violation: {reason}")

        screenshot_path = await self.take_screenshot(page, "dpdp_005_retention_violation")

        metadata = {
            'privacy_policy_found': self.privacy_policy_found,
            'privacy_policy_url': self.privacy_policy_url,
            'violation_reason': reason,
        }

        if reason == "insufficient_retention_disclosure":
            metadata.update({
                'retention_keywords_count': details.get('retention_keywords_count', 0),
                'deletion_keywords_count': details.get('deletion_keywords_count', 0),
                'vague_patterns_count': details.get('vague_patterns_count', 0),
                'dpdp_keywords_count': details.get('dpdp_keywords_count', 0),
                'violations': details.get('violations', []),
            })

        return ComplianceCheckResult(
            regulation_id="DPDP_2023",
            requirement_id="DPDP_005",
            status="failed",
            severity="high",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata=metadata,
            legal_risk=(
                "High-severity DPDP Act 2023 violation (Section 8: Retention and erasure of personal data). "
                "Data Fiduciaries must not retain personal data beyond the period necessary for the purpose. "
                "Must disclose retention periods and deletion procedures to Data Principals. "
                "Penalties: Up to ₹50 crore (~$6 million USD) under Section 33. "
                "Failure to properly disclose and implement retention policies violates data minimization principles."
            )
        )

    async def _create_compliant_result(self, analysis: Dict) -> ComplianceCheckResult:
        """Create compliant result."""

        evidence = (
            f"Privacy policy contains adequate data retention disclosure.\n"
            f"  - Retention keywords found: {analysis['retention_keywords_count']}\n"
            f"  - Deletion keywords found: {analysis['deletion_keywords_count']}\n"
            f"  - Vague patterns: {analysis['vague_patterns_count']}\n"
            f"  - DPDP-specific keywords: {analysis['dpdp_keywords_count']}\n"
            f"  - Policy length: {analysis['policy_length']} characters\n\n"
            f"Note: Manual review recommended to verify retention periods are reasonable "
            f"and tied to specific purposes."
        )

        return ComplianceCheckResult(
            regulation_id="DPDP_2023",
            requirement_id="DPDP_005",
            status="passed",
            severity="high",
            evidence=evidence,
            metadata={
                'privacy_policy_found': self.privacy_policy_found,
                'privacy_policy_url': self.privacy_policy_url,
                'retention_keywords_count': analysis['retention_keywords_count'],
                'deletion_keywords_count': analysis['deletion_keywords_count'],
                'vague_patterns_count': analysis['vague_patterns_count'],
                'dpdp_keywords_count': analysis['dpdp_keywords_count'],
                'policy_length': analysis['policy_length'],
            }
        )
