"""
DPDP Act 2023 (India) Compliance Checks

Digital Personal Data Protection Act, 2023 (DPDP Act)
Jurisdiction: India
Enforcement: 2024 onwards

Checks implemented:
- DPDP_001: Consent Before Data Collection
- DPDP_002: Purpose Limitation Disclosure
- DPDP_003: Parental Consent for Minors
- DPDP_004: Data Deletion Request Option
- DPDP_005: Data Retention Disclosure
- DPDP_006: Grievance Redressal Mechanism
- DPDP_007: Data Fiduciary Information
"""

# Import all checks to ensure they're registered
from .consent_before_collection import ConsentBeforeCollectionCheck
from .purpose_limitation import PurposeLimitationCheck
from .parental_consent import ParentalConsentCheck
from .data_deletion import DataDeletionCheck
from .data_retention import DataRetentionCheck
from .grievance_redressal import GrievanceRedressalCheck
from .data_fiduciary_info import DataFiduciaryInfoCheck

__all__ = [
    'ConsentBeforeCollectionCheck',
    'PurposeLimitationCheck',
    'ParentalConsentCheck',
    'DataDeletionCheck',
    'DataRetentionCheck',
    'GrievanceRedressalCheck',
    'DataFiduciaryInfoCheck',
]
