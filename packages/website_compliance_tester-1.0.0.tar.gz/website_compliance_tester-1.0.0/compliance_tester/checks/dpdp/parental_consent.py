"""
DPDP Parental Consent for Minors Check

Tests that parental consent is obtained for users under 18 years of age,
as required by India's Digital Personal Data Protection Act, 2023.

DPDP Act 2023, Section 9: Additional obligations for children
Section 9(1): Verifiable parental consent required for processing children's data
Section 9(2): No tracking, behavioral monitoring, or targeted advertising to children

Regulation: DPDP Act 2023 (India)
Requirement: DPDP_003 - Parental Consent for Minors
Severity: Critical
Automation: 70% automated (some visual verification needed)
"""

from playwright.async_api import Page, Locator
from typing import Optional, Dict, List, Set
import logging
import re

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="DPDP_2023", requirement_id="DPDP_003")
class ParentalConsentCheck(ComplianceCheck):
    """
    DPDP_003: Parental consent required for users under 18 years.

    This check verifies that websites obtain verifiable parental consent
    before collecting/processing personal data of children (under 18 years),
    as required by DPDP Act Section 9.

    Methodology:
    1. Look for registration/signup forms
    2. Check for age verification fields (date of birth, age gate)
    3. Look for parental consent mechanisms
    4. Check if age < 18 triggers special handling
    5. Verify parental consent flow exists

    Common violations:
    - No age verification during registration
    - Allowing children (under 18) to register without parental consent
    - No mechanism to verify parental consent
    - Missing age gate before data collection
    - No special handling for minor users

    Legal risk: Up to ₹200 crore (~$24M USD) under DPDP Act Section 33
    Note: Children's data is considered highly sensitive under DPDP Act
    """

    automation_level = "semi_automated"
    severity = "critical"

    # Age verification field patterns (English + Hindi)
    AGE_VERIFICATION_PATTERNS = [
        # English
        "date of birth",
        "birth date",
        "dob",
        "age",
        "year of birth",
        "birth year",
        "are you 18",
        "are you above 18",
        "are you over 18",
        "confirm your age",
        "verify your age",
        "age verification",

        # Hindi
        "जन्म तिथि",      # janma tithi (date of birth)
        "उम्र",           # umr (age)
        "आयु",            # aayu (age)
    ]

    # Parental consent indicators (English + Hindi)
    PARENTAL_CONSENT_PATTERNS = [
        # English
        "parental consent",
        "parent consent",
        "parent's consent",
        "guardian consent",
        "parent or guardian",
        "parent's permission",
        "parental permission",
        "guardian's permission",
        "parent authorization",
        "consent from parent",
        "if you are under 18",
        "users under 18",
        "below 18 years",
        "minors must",
        "for children",
        "child's account",

        # Hindi
        "माता-पिता की सहमति",  # mata-pita ki sahamati (parental consent)
        "अभिभावक की सहमति",    # abhibhavak ki sahamati (guardian consent)
    ]

    # Form field names that indicate age collection
    AGE_FIELD_NAMES = [
        "dob",
        "dateofbirth",
        "date_of_birth",
        "birthdate",
        "birth_date",
        "age",
        "year",
        "birth_year",
        "birthyear",
        "day",
        "month",
        "year_of_birth",
    ]

    # India's age of consent is 18 (stricter than EU's 16)
    AGE_OF_CONSENT = 18

    def __init__(self, regulation_id: str = "DPDP_2023", requirement_id: str = "DPDP_003"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.age_verification_found = False
        self.parental_consent_mechanism_found = False

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the parental consent check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting DPDP_003 check for {url}")

            # Navigate to page if needed
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            # Wait for page to settle
            await page.wait_for_timeout(2000)

            # Step 1: Look for signup/registration links
            signup_link = await self._find_signup_link(page)

            if not signup_link:
                # No registration flow visible - check page content for age/parental consent mentions
                page_content = await page.inner_text("body")
                has_age_mentions = await self._check_for_age_verification_in_content(page_content)
                has_parental_mentions = await self._check_for_parental_consent_in_content(page_content)

                if not has_age_mentions and not has_parental_mentions:
                    # Can't determine compliance - site may not collect user data
                    return ComplianceCheckResult(
                        regulation_id="DPDP_2023",
                        requirement_id="DPDP_003",
                        status="neutral",
                        severity="critical",
                        evidence="No registration/signup form found. Cannot verify parental consent mechanism. Check may not be applicable if site doesn't collect personal data.",
                        metadata={
                            'signup_form_found': False,
                            'age_verification_found': False,
                            'parental_consent_found': False
                        }
                    )

            # Step 2: Navigate to signup page
            if signup_link:
                try:
                    await signup_link.click()
                    await page.wait_for_load_state("networkidle", timeout=10000)
                except Exception as e:
                    logger.debug(f"Could not navigate to signup: {e}")

            # Step 3: Check for age verification fields
            age_verification = await self._check_age_verification_fields(page)

            # Step 4: Check for parental consent mechanism
            parental_consent = await self._check_parental_consent_mechanism(page)

            # Step 5: Analyze results
            return await self._analyze_compliance(
                page=page,
                age_verification=age_verification,
                parental_consent=parental_consent
            )

        except Exception as e:
            logger.error(f"Error in DPDP_003 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="DPDP_2023",
                requirement_id="DPDP_003",
                status="error",
                severity="critical",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _find_signup_link(self, page: Page) -> Optional[Locator]:
        """
        Find signup/registration link on the page.

        Args:
            page: Playwright page object

        Returns:
            Locator for signup link, or None if not found
        """
        signup_patterns = [
            "sign up", "signup", "register", "create account",
            "join", "join now", "get started",
            "साइन अप",  # Hindi: sign up
            "रजिस्टर",   # Hindi: register
        ]

        for pattern in signup_patterns:
            try:
                # Try to find as button
                button = page.get_by_role("button", name=re.compile(pattern, re.IGNORECASE)).first
                if await button.count() > 0:
                    logger.debug(f"Found signup button: {pattern}")
                    return button

                # Try to find as link
                link = page.get_by_role("link", name=re.compile(pattern, re.IGNORECASE)).first
                if await link.count() > 0:
                    logger.debug(f"Found signup link: {pattern}")
                    return link
            except Exception as e:
                logger.debug(f"Error searching for {pattern}: {e}")

        return None

    async def _check_age_verification_fields(self, page: Page) -> Dict:
        """
        Check for age verification input fields.

        Args:
            page: Playwright page object

        Returns:
            Dictionary with age verification details
        """
        age_fields_found = []

        # Check for input fields with age-related names
        try:
            all_inputs = await page.query_selector_all("input")
            for input_elem in all_inputs:
                # Get field name/id
                name = await input_elem.get_attribute("name") or ""
                id_attr = await input_elem.get_attribute("id") or ""
                placeholder = await input_elem.get_attribute("placeholder") or ""
                label_text = ""

                # Try to find associated label
                try:
                    label = await input_elem.evaluate('''
                        el => {
                            const label = document.querySelector(`label[for="${el.id}"]`);
                            return label ? label.innerText : "";
                        }
                    ''')
                    label_text = label or ""
                except Exception:
                    pass

                # Check if any attribute matches age field patterns
                all_text = f"{name} {id_attr} {placeholder} {label_text}".lower()

                if any(pattern.lower() in all_text for pattern in self.AGE_FIELD_NAMES):
                    age_fields_found.append({
                        'name': name,
                        'id': id_attr,
                        'placeholder': placeholder,
                        'label': label_text
                    })
                    self.age_verification_found = True

        except Exception as e:
            logger.debug(f"Error checking age fields: {e}")

        # Check for age verification text on page
        try:
            page_text = await page.inner_text("body")
            has_age_text = any(pattern.lower() in page_text.lower()
                             for pattern in self.AGE_VERIFICATION_PATTERNS)
        except Exception:
            has_age_text = False

        return {
            'age_fields_found': len(age_fields_found) > 0,
            'age_field_count': len(age_fields_found),
            'age_fields': age_fields_found[:5],  # Limit metadata
            'age_text_present': has_age_text
        }

    async def _check_parental_consent_mechanism(self, page: Page) -> Dict:
        """
        Check for parental consent mechanism.

        Args:
            page: Playwright page object

        Returns:
            Dictionary with parental consent details
        """
        try:
            page_text = await page.inner_text("body")
            page_text_lower = page_text.lower()

            # Check for parental consent mentions
            parental_consent_mentions = []
            for pattern in self.PARENTAL_CONSENT_PATTERNS:
                if pattern.lower() in page_text_lower:
                    parental_consent_mentions.append(pattern)
                    self.parental_consent_mechanism_found = True

            # Look for checkboxes related to parental consent
            parental_consent_checkbox = False
            try:
                checkboxes = await page.query_selector_all('input[type="checkbox"]')
                for checkbox in checkboxes:
                    label = await checkbox.evaluate('''
                        el => {
                            const label = document.querySelector(`label[for="${el.id}"]`);
                            return label ? label.innerText : "";
                        }
                    ''')
                    if label and any(pattern.lower() in label.lower()
                                   for pattern in self.PARENTAL_CONSENT_PATTERNS):
                        parental_consent_checkbox = True
                        break
            except Exception as e:
                logger.debug(f"Error checking checkboxes: {e}")

            return {
                'parental_consent_found': len(parental_consent_mentions) > 0,
                'parental_consent_mentions': parental_consent_mentions[:5],
                'parental_consent_checkbox': parental_consent_checkbox
            }

        except Exception as e:
            logger.debug(f"Error checking parental consent: {e}")
            return {
                'parental_consent_found': False,
                'parental_consent_mentions': [],
                'parental_consent_checkbox': False
            }

    async def _check_for_age_verification_in_content(self, content: str) -> bool:
        """Check if page content mentions age verification."""
        content_lower = content.lower()
        return any(pattern.lower() in content_lower for pattern in self.AGE_VERIFICATION_PATTERNS)

    async def _check_for_parental_consent_in_content(self, content: str) -> bool:
        """Check if page content mentions parental consent."""
        content_lower = content.lower()
        return any(pattern.lower() in content_lower for pattern in self.PARENTAL_CONSENT_PATTERNS)

    async def _analyze_compliance(
        self,
        page: Page,
        age_verification: Dict,
        parental_consent: Dict
    ) -> ComplianceCheckResult:
        """
        Analyze compliance based on findings.

        Args:
            page: Playwright page object
            age_verification: Age verification findings
            parental_consent: Parental consent findings

        Returns:
            ComplianceCheckResult
        """
        # Determine compliance
        has_age_verification = age_verification['age_fields_found'] or age_verification['age_text_present']
        has_parental_consent = parental_consent['parental_consent_found']

        # Build metadata
        metadata = {
            'age_verification_found': has_age_verification,
            'age_field_count': age_verification['age_field_count'],
            'age_text_present': age_verification['age_text_present'],
            'parental_consent_found': has_parental_consent,
            'parental_consent_mentions': parental_consent['parental_consent_mentions'],
            'parental_consent_checkbox': parental_consent['parental_consent_checkbox'],
        }

        # Case 1: Has both age verification AND parental consent mechanism (COMPLIANT)
        if has_age_verification and has_parental_consent:
            evidence = (
                f"Age verification mechanism found with parental consent provisions.\n"
                f"  - Age verification: {'Yes (fields found)' if age_verification['age_fields_found'] else 'Yes (text mentions)'}\n"
                f"  - Parental consent mentions: {len(parental_consent['parental_consent_mentions'])}\n"
                f"  - Parental consent checkbox: {parental_consent['parental_consent_checkbox']}\n\n"
                f"Note: Manual verification recommended to ensure parental consent is actually enforced for users under 18."
            )

            return ComplianceCheckResult(
                regulation_id="DPDP_2023",
                requirement_id="DPDP_003",
                status="passed",
                severity="critical",
                evidence=evidence,
                metadata=metadata
            )

        # Case 2: Has age verification but NO parental consent mechanism (VIOLATION)
        elif has_age_verification and not has_parental_consent:
            screenshot_path = await self.take_screenshot(page, "dpdp_003_no_parental_consent")

            evidence = (
                "Age verification found but no parental consent mechanism detected.\n"
                "DPDP Act Section 9 requires verifiable parental consent for users under 18.\n\n"
                "Found:\n"
                f"  - Age verification fields: {age_verification['age_field_count']}\n"
                f"  - Parental consent mentions: 0\n\n"
                "Missing: Mechanism to obtain and verify parental consent for minors."
            )

            return ComplianceCheckResult(
                regulation_id="DPDP_2023",
                requirement_id="DPDP_003",
                status="failed",
                severity="critical",
                evidence=evidence,
                screenshot_path=screenshot_path,
                metadata=metadata,
                legal_risk=(
                    "Critical DPDP Act 2023 violation (Section 9: Additional obligations for children). "
                    "Processing children's personal data without verifiable parental consent. "
                    "Penalties: Up to ₹200 crore (~$24 million USD) under Section 33. "
                    "Children's data is highly sensitive under DPDP Act. "
                    "Section 9(2) prohibits tracking, behavioral monitoring, or targeted advertising to children."
                )
            )

        # Case 3: No age verification at all (VIOLATION)
        else:
            screenshot_path = await self.take_screenshot(page, "dpdp_003_no_age_verification")

            evidence = (
                "No age verification mechanism found during registration.\n"
                "DPDP Act Section 9 requires verifiable parental consent for users under 18.\n"
                "Cannot comply without first collecting age information.\n\n"
                "Missing:\n"
                "  - Age verification fields (date of birth, age gate)\n"
                "  - Parental consent mechanism\n\n"
                "Recommendation: Add age verification during signup and implement parental consent for users under 18."
            )

            return ComplianceCheckResult(
                regulation_id="DPDP_2023",
                requirement_id="DPDP_003",
                status="failed",
                severity="critical",
                evidence=evidence,
                screenshot_path=screenshot_path,
                metadata=metadata,
                legal_risk=(
                    "Critical DPDP Act 2023 violation (Section 9: Additional obligations for children). "
                    "No mechanism to verify user age or obtain parental consent for minors. "
                    "Penalties: Up to ₹200 crore (~$24 million USD) under Section 33. "
                    "Sites collecting personal data must verify age and obtain parental consent for users under 18."
                )
            )
