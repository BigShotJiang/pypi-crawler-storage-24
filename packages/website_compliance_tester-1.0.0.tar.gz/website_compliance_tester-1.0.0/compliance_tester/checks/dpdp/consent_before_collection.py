"""
DPDP Consent Before Data Collection Check

Tests that personal data is not collected or processed before obtaining user consent,
as required by India's Digital Personal Data Protection Act, 2023.

DPDP Act 2023, Section 6: Notice and consent
DPDP Act 2023, Section 5: Obligation to give notice
Section 11: General obligations of Data Fiduciaries

Regulation: DPDP Act 2023 (India)
Requirement: DPDP_001 - Consent Before Data Collection
Severity: Critical
Automation: 100% automated
"""

from playwright.async_api import Page, Request
from typing import Optional, Dict, List, Set
import logging
import re

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="DPDP_2023", requirement_id="DPDP_001")
class ConsentBeforeCollectionCheck(ComplianceCheck):
    """
    DPDP_001: Consent must be obtained before collecting personal data.

    This check verifies that websites do not load tracking scripts or collect
    personal data before obtaining user consent, as required by India's DPDP Act 2023.

    Methodology:
    1. Intercept all network requests before page load
    2. Navigate to the URL
    3. Analyze requests for tracking/analytics domains
    4. Check localStorage/sessionStorage for tracking keys
    5. Report violations if data collection detected before consent

    Common violations:
    - Loading Google Analytics before consent banner
    - Setting tracking cookies immediately on page load
    - Calling analytics APIs before user interaction
    - Collecting device fingerprints without consent

    Legal risk: Up to ₹250 crore (~$30M USD) under DPDP Act Section 33
    Recent enforcement: Act came into force in 2024, enforcement ramping up
    """

    automation_level = "automated"
    severity = "critical"

    # India-specific tracking domains (in addition to global ones)
    TRACKING_DOMAINS = [
        # Global analytics (commonly used in India)
        'google-analytics.com',
        'googletagmanager.com',
        'doubleclick.net',
        'google.com/analytics',
        'google.co.in/analytics',
        'facebook.com',
        'facebook.net',
        'connect.facebook.net',

        # India-specific analytics platforms
        'clevertap.com',
        'wizrocket.com',  # Clevertap CDN
        'moengage.com',
        'webengage.com',
        'netcoresmartech.com',  # Netcore (formerly Hansel)
        'netcore.co.in',

        # Mobile attribution platforms (popular in India)
        'appsflyer.com',
        'branch.io',
        'adjust.com',
        'kochava.com',

        # Session replay & heatmaps
        'hotjar.com',
        'mouseflow.com',
        'smartlook.com',
        'inspectlet.com',

        # General analytics
        'segment.com',
        'mixpanel.com',
        'amplitude.com',
        'heap.io',
        'fullstory.com',

        # Advertising networks
        'criteo.com',
        'pubmatic.com',
        'taboola.com',
        'outbrain.com',
        'adnxs.com',  # AppNexus
        'rubiconproject.com',
        'openx.net',

        # Social media tracking
        'twitter.com/i/adsct',
        'linkedin.com/li/track',
        'snapchat.com/tr',

        # India-specific ad networks
        'inmobi.com',
        'glance.com',
        'vserv.com',
    ]

    # Storage keys that indicate tracking
    TRACKING_STORAGE_PATTERNS = [
        # Google Analytics
        '_ga', '_gid', '_gat', 'gtm',

        # Facebook
        '_fbp', '_fbc', 'fbssls',

        # India-specific platforms
        'ct_', 'wzrk',  # Clevertap
        'moe_', 'Moengage',  # MoEngage
        'we_', 'webengage',  # WebEngage

        # General tracking
        '_hjid',  # Hotjar
        'ajs_',  # Segment
        'mp_',  # Mixpanel
        'amplitude',
        '__qca',  # Quantcast
        'optimizelyEndUserId',

        # Session/user IDs (may indicate tracking)
        'visitor_id', 'user_id', 'session_id',
        'device_id', 'uuid',
    ]

    def __init__(self, regulation_id: str = "DPDP_2023", requirement_id: str = "DPDP_001"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.tracking_requests: List[Dict] = []
        self.all_requests: List[Dict] = []

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the consent before collection check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting DPDP_001 check for {url}")

            # Reset tracking lists
            self.tracking_requests = []
            self.all_requests = []

            # Set up request interception
            page.on("request", self._track_request)

            # Navigate to page
            await page.goto(url, wait_until="networkidle", timeout=30000)

            # Wait a bit for any delayed tracking
            await page.wait_for_timeout(3000)

            # Check for tracking in storage
            storage_violations = await self._check_storage_tracking(page)

            # Analyze results
            if self.tracking_requests or storage_violations:
                return await self._create_violation_result(
                    page=page,
                    storage_violations=storage_violations
                )
            else:
                return await self._create_compliant_result()

        except Exception as e:
            logger.error(f"Error in DPDP_001 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="DPDP_2023",
                requirement_id="DPDP_001",
                status="error",
                severity="critical",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    def _track_request(self, request: Request):
        """
        Track network requests to detect tracking before consent.

        Args:
            request: Playwright request object
        """
        try:
            url = request.url
            resource_type = request.resource_type

            # Record all requests
            self.all_requests.append({
                'url': url,
                'type': resource_type,
                'method': request.method
            })

            # Check if this is a tracking request
            domain = self._extract_domain(url)

            if any(tracking_domain in domain for tracking_domain in self.TRACKING_DOMAINS):
                logger.debug(f"Detected tracking request: {domain} ({resource_type})")
                self.tracking_requests.append({
                    'url': url,
                    'domain': domain,
                    'type': resource_type,
                    'method': request.method
                })

        except Exception as e:
            logger.debug(f"Error tracking request: {e}")

    def _extract_domain(self, url: str) -> str:
        """
        Extract domain from URL.

        Args:
            url: Full URL

        Returns:
            Domain name
        """
        try:
            # Remove protocol
            domain = re.sub(r'^https?://', '', url)
            # Remove path and query
            domain = domain.split('/')[0]
            # Remove port
            domain = domain.split(':')[0]
            return domain.lower()
        except Exception:
            return url

    async def _check_storage_tracking(self, page: Page) -> List[str]:
        """
        Check localStorage and sessionStorage for tracking keys.

        Args:
            page: Playwright page object

        Returns:
            List of tracking keys found
        """
        violations = []

        try:
            # Check localStorage
            local_storage = await page.evaluate('''
                () => {
                    const items = {};
                    for (let i = 0; i < localStorage.length; i++) {
                        const key = localStorage.key(i);
                        items[key] = localStorage.getItem(key);
                    }
                    return items;
                }
            ''')

            # Check sessionStorage
            session_storage = await page.evaluate('''
                () => {
                    const items = {};
                    for (let i = 0; i < sessionStorage.length; i++) {
                        const key = sessionStorage.key(i);
                        items[key] = sessionStorage.getItem(key);
                    }
                    return items;
                }
            ''')

            # Check for tracking patterns in storage keys
            all_storage = {**local_storage, **session_storage}

            for key in all_storage.keys():
                if any(pattern in key.lower() for pattern in self.TRACKING_STORAGE_PATTERNS):
                    violations.append(key)
                    logger.debug(f"Found tracking storage key: {key}")

        except Exception as e:
            logger.debug(f"Error checking storage: {e}")

        return violations

    async def _create_violation_result(
        self,
        page: Page,
        storage_violations: List[str]
    ) -> ComplianceCheckResult:
        """
        Create a violation result with detailed evidence.

        Args:
            page: Playwright page object
            storage_violations: List of tracking storage keys found

        Returns:
            ComplianceCheckResult with failed status
        """
        # Build evidence
        evidence_parts = []

        if self.tracking_requests:
            evidence_parts.append(
                f"Detected {len(self.tracking_requests)} tracking request(s) before consent:"
            )

            # Group by domain for cleaner output
            domains_seen = set()
            for req in self.tracking_requests[:10]:  # Limit to first 10
                if req['domain'] not in domains_seen:
                    evidence_parts.append(f"  - {req['domain']} ({req['type']})")
                    domains_seen.add(req['domain'])

            if len(self.tracking_requests) > 10:
                evidence_parts.append(f"  ... and {len(self.tracking_requests) - 10} more")

        if storage_violations:
            evidence_parts.append(
                f"\nDetected {len(storage_violations)} tracking storage key(s):"
            )
            for key in storage_violations[:10]:
                evidence_parts.append(f"  - {key}")

            if len(storage_violations) > 10:
                evidence_parts.append(f"  ... and {len(storage_violations) - 10} more")

        evidence = "\n".join(evidence_parts)

        # Take screenshot
        screenshot_path = await self.take_screenshot(page, "dpdp_001_tracking_violation")

        # Extract unique tracking domains
        tracking_domains = list(set(req['domain'] for req in self.tracking_requests))

        return ComplianceCheckResult(
            regulation_id="DPDP_2023",
            requirement_id="DPDP_001",
            status="failed",
            severity="critical",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata={
                'total_requests': len(self.all_requests),
                'tracking_requests_count': len(self.tracking_requests),
                'tracking_domains': tracking_domains[:20],  # Limit metadata size
                'storage_violations': storage_violations[:20],
                'has_tracking_requests': len(self.tracking_requests) > 0,
                'has_storage_violations': len(storage_violations) > 0,
            },
            legal_risk=(
                "Critical DPDP Act 2023 violation (Section 6: Notice and consent). "
                "Personal data collected before obtaining user consent. "
                "Penalties: Up to ₹250 crore (~$30 million USD) under Section 33. "
                "The Data Fiduciary must obtain valid consent before collecting or processing "
                "any personal data. Enforcement by Data Protection Board of India has commenced."
            )
        )

    async def _create_compliant_result(self) -> ComplianceCheckResult:
        """
        Create a compliant result.

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            f"No tracking detected before consent. "
            f"Analyzed {len(self.all_requests)} requests, found 0 tracking requests. "
            f"No tracking-related storage keys detected."
        )

        return ComplianceCheckResult(
            regulation_id="DPDP_2023",
            requirement_id="DPDP_001",
            status="passed",
            severity="critical",
            evidence=evidence,
            metadata={
                'total_requests': len(self.all_requests),
                'tracking_requests_count': 0,
                'tracking_domains': [],
                'storage_violations': [],
                'has_tracking_requests': False,
                'has_storage_violations': False,
            }
        )
