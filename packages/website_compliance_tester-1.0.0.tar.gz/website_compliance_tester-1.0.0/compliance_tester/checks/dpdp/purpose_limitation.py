"""
DPDP Purpose Limitation Disclosure Check

Tests that data collection purposes are clearly disclosed before or at the time
of data collection, as required by India's Digital Personal Data Protection Act, 2023.

DPDP Act 2023, Section 5: Obligation to give notice
DPDP Act 2023, Section 6(2): Purpose specification in consent
DPDP Act 2023, Section 4: Lawfulness of processing

Regulation: DPDP Act 2023 (India)
Requirement: DPDP_002 - Purpose Limitation Disclosure
Severity: High
Automation: 80% automated (some manual review needed for purpose clarity)
"""

from playwright.async_api import Page, Locator
from typing import Optional, Dict, List, Set
import logging
import re

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="DPDP_2023", requirement_id="DPDP_002")
class PurposeLimitationCheck(ComplianceCheck):
    """
    DPDP_002: Data collection purposes must be clearly disclosed.

    This check verifies that websites clearly state the purpose(s) for which
    personal data is collected, as required by DPDP Act Section 5.

    Methodology:
    1. Look for privacy policy/notice links
    2. Check if privacy policy is easily accessible
    3. Navigate to privacy policy page
    4. Scan for purpose statements
    5. Analyze if purposes are specific vs vague
    6. Check for required DPDP Act disclosures

    Common violations:
    - No privacy policy link visible
    - Privacy policy buried in footer
    - Vague purposes ("business purposes", "legitimate interests")
    - No mention of specific data uses
    - Missing required DPDP Act disclosures

    Legal risk: Up to ₹50 crore (~$6M USD) under DPDP Act Section 33
    Note: Less severe than consent violations but still significant
    """

    automation_level = "semi_automated"
    severity = "high"

    # Privacy policy link text patterns (English + Hindi)
    PRIVACY_POLICY_PATTERNS = [
        # English
        "privacy policy",
        "privacy notice",
        "data privacy",
        "data protection",
        "privacy statement",
        "privacy terms",

        # Hindi (Devanagari)
        "गोपनीयता नीति",  # gōpanīyatā nīti (privacy policy)
        "निजता नीति",     # nijatā nīti (privacy policy)
        "डेटा सुरक्षा",   # ḍēṭā surakṣā (data protection)
    ]

    # Required purpose categories under DPDP Act
    REQUIRED_PURPOSE_CATEGORIES = [
        "collection",      # What data is collected
        "use",            # How data will be used
        "storage",        # How long data is stored
        "sharing",        # Who data is shared with
        "security",       # How data is protected
    ]

    # Specific purpose indicators (good - compliant)
    SPECIFIC_PURPOSE_INDICATORS = [
        # Transaction/service delivery
        "to process your order",
        "to deliver products",
        "to provide customer support",
        "to send order confirmation",
        "to process payment",

        # Account management
        "to create and manage your account",
        "to authenticate your identity",
        "to verify your email",

        # Communication
        "to send transactional emails",
        "to respond to your inquiries",
        "to provide customer service",

        # Analytics (if specific)
        "to analyze website usage",
        "to improve user experience",
        "to track product performance",

        # Marketing (if clear)
        "to send promotional emails",
        "to show personalized ads",
        "to recommend products",

        # Legal compliance
        "to comply with legal obligations",
        "to prevent fraud",
        "to enforce our terms",
    ]

    # Vague purpose indicators (bad - likely violation)
    VAGUE_PURPOSE_INDICATORS = [
        "business purposes",
        "legitimate interests",
        "operational purposes",
        "internal purposes",
        "other purposes",
        "various purposes",
        "as needed",
        "as required",
        "for any purpose",
        "all purposes",
        "necessary purposes",
    ]

    # DPDP Act specific disclosure requirements
    DPDP_DISCLOSURE_KEYWORDS = [
        "personal data",
        "consent",
        "data fiduciary",
        "data processor",
        "data principal",
        "grievance",
        "data protection board",
        "withdrawal",
        "erasure",
        "correction",
    ]

    def __init__(self, regulation_id: str = "DPDP_2023", requirement_id: str = "DPDP_002"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.privacy_policy_found = False
        self.privacy_policy_accessible = False
        self.privacy_policy_url = None

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the purpose limitation disclosure check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting DPDP_002 check for {url}")

            # Navigate to page if needed
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            # Wait for page to settle
            await page.wait_for_timeout(2000)

            # Step 1: Look for privacy policy link
            privacy_link = await self._find_privacy_policy_link(page)

            if not privacy_link:
                return await self._create_violation_result(
                    page=page,
                    reason="no_privacy_policy_link",
                    evidence_details={}
                )

            self.privacy_policy_found = True

            # Get privacy policy URL
            self.privacy_policy_url = await privacy_link.get_attribute("href")
            logger.debug(f"Found privacy policy link: {self.privacy_policy_url}")

            # Step 2: Check if privacy policy is accessible
            try:
                # Click privacy policy link
                await privacy_link.click()
                await page.wait_for_load_state("networkidle", timeout=10000)
                self.privacy_policy_accessible = True
            except Exception as e:
                logger.debug(f"Privacy policy not accessible: {e}")
                return await self._create_violation_result(
                    page=page,
                    reason="privacy_policy_not_accessible",
                    evidence_details={'error': str(e)}
                )

            # Step 3: Scan privacy policy content
            policy_content = await page.inner_text("body")

            # Step 4: Analyze purposes
            analysis = self._analyze_privacy_policy(policy_content)

            # Step 5: Determine compliance
            if analysis['has_violations']:
                return await self._create_violation_result(
                    page=page,
                    reason="insufficient_purpose_disclosure",
                    evidence_details=analysis
                )
            else:
                return await self._create_compliant_result(analysis)

        except Exception as e:
            logger.error(f"Error in DPDP_002 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="DPDP_2023",
                requirement_id="DPDP_002",
                status="error",
                severity="high",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _find_privacy_policy_link(self, page: Page) -> Optional[Locator]:
        """
        Find privacy policy link on the page.

        Args:
            page: Playwright page object

        Returns:
            Locator for privacy policy link, or None if not found
        """
        # Try to find links with privacy policy text
        for pattern in self.PRIVACY_POLICY_PATTERNS:
            try:
                # Case-insensitive search
                link = page.get_by_role("link", name=re.compile(pattern, re.IGNORECASE)).first
                if await link.count() > 0:
                    logger.debug(f"Found privacy policy link with pattern: {pattern}")
                    return link
            except Exception as e:
                logger.debug(f"Error searching for pattern {pattern}: {e}")

        # Fallback: search all links for privacy policy text
        try:
            all_links = await page.get_by_role("link").all()
            for link in all_links:
                text = await link.inner_text()
                text_lower = text.lower().strip()

                if any(pattern.lower() in text_lower for pattern in self.PRIVACY_POLICY_PATTERNS):
                    logger.debug(f"Found privacy policy link in all links: {text}")
                    return link
        except Exception as e:
            logger.debug(f"Error in fallback search: {e}")

        return None

    def _analyze_privacy_policy(self, content: str) -> Dict:
        """
        Analyze privacy policy content for purpose disclosure.

        Args:
            content: Privacy policy text content

        Returns:
            Dictionary with analysis results
        """
        content_lower = content.lower()

        # Check for specific purpose statements
        specific_purposes_found = []
        for indicator in self.SPECIFIC_PURPOSE_INDICATORS:
            if indicator in content_lower:
                specific_purposes_found.append(indicator)

        # Check for vague purpose statements
        vague_purposes_found = []
        for indicator in self.VAGUE_PURPOSE_INDICATORS:
            if indicator in content_lower:
                vague_purposes_found.append(indicator)

        # Check for DPDP Act specific keywords
        dpdp_keywords_found = []
        for keyword in self.DPDP_DISCLOSURE_KEYWORDS:
            if keyword in content_lower:
                dpdp_keywords_found.append(keyword)

        # Check for required purpose categories
        missing_categories = []
        for category in self.REQUIRED_PURPOSE_CATEGORIES:
            # Check if category is mentioned
            category_indicators = {
                "collection": ["collect", "gathering", "obtain"],
                "use": ["use", "process", "utilize", "employ"],
                "storage": ["store", "retain", "keep", "maintain"],
                "sharing": ["share", "disclose", "transfer", "provide to"],
                "security": ["security", "protect", "safeguard", "secure"],
            }

            indicators = category_indicators.get(category, [category])
            if not any(ind in content_lower for ind in indicators):
                missing_categories.append(category)

        # Determine violations
        has_violations = False
        violations = []

        # Violation 1: Too many vague purposes, not enough specific
        if len(vague_purposes_found) > 2 and len(specific_purposes_found) < 3:
            has_violations = True
            violations.append(
                f"Privacy policy contains {len(vague_purposes_found)} vague purpose statements "
                f"but only {len(specific_purposes_found)} specific purposes"
            )

        # Violation 2: Missing required purpose categories
        if len(missing_categories) > 2:
            has_violations = True
            violations.append(
                f"Privacy policy missing {len(missing_categories)} required purpose categories: "
                f"{', '.join(missing_categories)}"
            )

        # Violation 3: No DPDP Act specific disclosures
        if len(dpdp_keywords_found) < 3:
            has_violations = True
            violations.append(
                f"Privacy policy lacks DPDP Act specific disclosures "
                f"(found only {len(dpdp_keywords_found)} keywords)"
            )

        # Violation 4: Policy is too short (likely incomplete)
        if len(content) < 500:
            has_violations = True
            violations.append(
                f"Privacy policy is too short ({len(content)} characters) - likely incomplete"
            )

        return {
            'has_violations': has_violations,
            'violations': violations,
            'specific_purposes_count': len(specific_purposes_found),
            'specific_purposes': specific_purposes_found[:10],  # Limit for metadata
            'vague_purposes_count': len(vague_purposes_found),
            'vague_purposes': vague_purposes_found[:10],
            'dpdp_keywords_count': len(dpdp_keywords_found),
            'dpdp_keywords': dpdp_keywords_found[:10],
            'missing_categories': missing_categories,
            'policy_length': len(content),
        }

    async def _create_violation_result(
        self,
        page: Page,
        reason: str,
        evidence_details: Dict
    ) -> ComplianceCheckResult:
        """
        Create a violation result with detailed evidence.

        Args:
            page: Playwright page object
            reason: Violation reason code
            evidence_details: Additional evidence details

        Returns:
            ComplianceCheckResult with failed status
        """
        # Build evidence based on reason
        evidence_map = {
            "no_privacy_policy_link": (
                "No privacy policy link found on the page. "
                "DPDP Act Section 5 requires Data Fiduciaries to provide notice of data collection purposes. "
                "Privacy policy should be easily accessible."
            ),
            "privacy_policy_not_accessible": (
                "Privacy policy link found but page is not accessible. "
                f"Error: {evidence_details.get('error', 'Unknown error')}. "
                "Users must be able to easily access purpose disclosures."
            ),
            "insufficient_purpose_disclosure": (
                "Privacy policy found but purpose disclosure is insufficient.\n\n"
                + "\n".join(f"  - {v}" for v in evidence_details.get('violations', []))
            ),
        }

        evidence = evidence_map.get(reason, f"Purpose limitation disclosure violation (reason: {reason})")

        # Take screenshot
        screenshot_path = await self.take_screenshot(page, "dpdp_002_purpose_violation")

        # Build metadata
        metadata = {
            'privacy_policy_found': self.privacy_policy_found,
            'privacy_policy_accessible': self.privacy_policy_accessible,
            'privacy_policy_url': self.privacy_policy_url,
            'violation_reason': reason,
        }

        # Add analysis details if available
        if reason == "insufficient_purpose_disclosure":
            metadata.update({
                'specific_purposes_count': evidence_details.get('specific_purposes_count', 0),
                'vague_purposes_count': evidence_details.get('vague_purposes_count', 0),
                'dpdp_keywords_count': evidence_details.get('dpdp_keywords_count', 0),
                'missing_categories': evidence_details.get('missing_categories', []),
                'policy_length': evidence_details.get('policy_length', 0),
                'violations': evidence_details.get('violations', []),
            })

        return ComplianceCheckResult(
            regulation_id="DPDP_2023",
            requirement_id="DPDP_002",
            status="failed",
            severity="high",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata=metadata,
            legal_risk=(
                "High-severity DPDP Act 2023 violation (Section 5: Obligation to give notice). "
                "Data Fiduciary must inform Data Principal of the purpose of processing before or at the time of collection. "
                "Penalties: Up to ₹50 crore (~$6 million USD) under Section 33. "
                "Purpose disclosure is a foundational requirement for lawful data processing."
            )
        )

    async def _create_compliant_result(self, analysis: Dict) -> ComplianceCheckResult:
        """
        Create a compliant result.

        Args:
            analysis: Privacy policy analysis results

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            f"Privacy policy accessible with adequate purpose disclosure.\n"
            f"  - Specific purposes found: {analysis['specific_purposes_count']}\n"
            f"  - Vague purposes: {analysis['vague_purposes_count']}\n"
            f"  - DPDP Act keywords: {analysis['dpdp_keywords_count']}\n"
            f"  - Policy length: {analysis['policy_length']} characters\n"
            f"  - Missing categories: {len(analysis['missing_categories'])}"
        )

        return ComplianceCheckResult(
            regulation_id="DPDP_2023",
            requirement_id="DPDP_002",
            status="passed",
            severity="high",
            evidence=evidence,
            metadata={
                'privacy_policy_found': self.privacy_policy_found,
                'privacy_policy_accessible': self.privacy_policy_accessible,
                'privacy_policy_url': self.privacy_policy_url,
                'specific_purposes_count': analysis['specific_purposes_count'],
                'vague_purposes_count': analysis['vague_purposes_count'],
                'dpdp_keywords_count': analysis['dpdp_keywords_count'],
                'missing_categories': analysis['missing_categories'],
                'policy_length': analysis['policy_length'],
            }
        )
