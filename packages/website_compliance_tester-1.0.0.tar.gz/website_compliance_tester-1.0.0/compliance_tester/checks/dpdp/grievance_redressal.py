"""
DPDP Grievance Redressal Mechanism Check

Tests that websites provide an easily accessible grievance redressal mechanism
with Data Protection Officer or Grievance Officer contact details,
as required by India's Digital Personal Data Protection Act, 2023.

DPDP Act 2023, Section 9: Grievance redressal by Data Fiduciary
DPDP Act 2023, Section 5: Obligation to give notice
DPDP Act 2023, Section 32: Significant Data Fiduciary obligations

Regulation: DPDP Act 2023 (India)
Requirement: DPDP_006 - Grievance Redressal Mechanism
Severity: High
Automation: 95% automated (manual verification of response time claims)
"""

from playwright.async_api import Page, Locator
from typing import Optional, Dict, List
import logging
import re

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="DPDP_2023", requirement_id="DPDP_006")
class GrievanceRedressalCheck(ComplianceCheck):
    """
    DPDP_006: Grievance redressal mechanism must be provided.

    This check verifies that websites provide an easily accessible grievance
    mechanism with appropriate officer contact details and response timeframes,
    as required by DPDP Act Section 9.

    Methodology:
    1. Search for grievance officer mentions on main page
    2. Navigate to privacy policy and search for grievance contact
    3. Check for Data Protection Officer (DPO) details
    4. Verify contact information is provided (email/phone/address)
    5. Check for 30-day response timeframe disclosure

    Common violations:
    - No grievance officer mentioned
    - No contact information provided
    - Generic "contact us" instead of specific officer
    - No response timeframe mentioned
    - Grievance mechanism buried or inaccessible

    Legal risk: Up to ₹200 crore (~$24M USD) under DPDP Act Section 33
    Section 9 is mandatory for all Data Fiduciaries
    """

    automation_level = "automated"
    severity = "high"

    # Privacy policy patterns
    PRIVACY_POLICY_PATTERNS = [
        "privacy policy",
        "privacy notice",
        "data privacy",
        "data protection",
        "गोपनीयता नीति",  # Hindi
    ]

    # Grievance officer title patterns
    GRIEVANCE_OFFICER_PATTERNS = [
        # DPDP-specific terms
        "grievance officer",
        "grievance redressal officer",
        "data protection officer",
        "dpo",
        "data privacy officer",
        "chief privacy officer",

        # Indian legal terms
        "nodal officer",
        "designated officer",
        "compliance officer",

        # Hindi variants
        "शिकायत निवारण अधिकारी",  # grievance redressal officer
    ]

    # Contact information indicators
    CONTACT_KEYWORDS = [
        "email",
        "e-mail",
        "contact",
        "phone",
        "telephone",
        "address",
        "write to",
        "reach us",
        "contact us at",
        "@",  # Email symbol
    ]

    # Response timeframe indicators
    RESPONSE_TIME_KEYWORDS = [
        "30 days",
        "thirty days",
        "within 30",
        "response time",
        "respond within",
        "will respond",
        "timeline",
        "timeframe",
        "time frame",
    ]

    # Complaint/grievance mechanism keywords
    COMPLAINT_KEYWORDS = [
        "complaint",
        "grievance",
        "concern",
        "dispute",
        "issue",
        "redressal",
        "redress",
        "resolution",
        "escalation",
        "lodge a complaint",
        "file a complaint",
        "raise a concern",
    ]

    def __init__(self, regulation_id: str = "DPDP_2023", requirement_id: str = "DPDP_006"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.privacy_policy_url = None
        self.grievance_officer_found = False
        self.contact_info_found = False

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the grievance redressal mechanism check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting DPDP_006 check for {url}")

            # Navigate to page if needed
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            await page.wait_for_timeout(2000)

            # Step 1: Check homepage for grievance officer mention
            homepage_content = await page.inner_text("body")
            homepage_analysis = self._analyze_grievance_disclosure(homepage_content)

            # If found on homepage, check if sufficient
            if homepage_analysis['has_officer'] and homepage_analysis['has_contact']:
                return await self._create_compliant_result(homepage_analysis, "homepage")

            # Step 2: Navigate to privacy policy
            privacy_link = await self._find_privacy_policy_link(page)

            if not privacy_link:
                # No privacy policy and not found on homepage
                if homepage_analysis['has_officer']:
                    return await self._create_violation_result(
                        page=page,
                        reason="officer_no_contact",
                        details=homepage_analysis
                    )
                else:
                    return await self._create_violation_result(
                        page=page,
                        reason="no_grievance_mechanism",
                        details={}
                    )

            self.privacy_policy_url = await privacy_link.get_attribute("href")

            # Navigate to privacy policy
            try:
                await privacy_link.click()
                await page.wait_for_load_state("networkidle", timeout=10000)
            except Exception as e:
                logger.debug(f"Failed to navigate to privacy policy: {e}")
                return await self._create_violation_result(
                    page=page,
                    reason="privacy_policy_inaccessible",
                    details={'error': str(e)}
                )

            # Step 3: Analyze privacy policy content
            policy_content = await page.inner_text("body")
            policy_analysis = self._analyze_grievance_disclosure(policy_content)

            # Step 4: Determine compliance
            if policy_analysis['has_officer'] and policy_analysis['has_contact']:
                return await self._create_compliant_result(policy_analysis, "privacy_policy")
            elif policy_analysis['has_officer']:
                return await self._create_violation_result(
                    page=page,
                    reason="officer_no_contact",
                    details=policy_analysis
                )
            else:
                return await self._create_violation_result(
                    page=page,
                    reason="no_grievance_officer",
                    details=policy_analysis
                )

        except Exception as e:
            logger.error(f"Error in DPDP_006 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="DPDP_2023",
                requirement_id="DPDP_006",
                status="error",
                severity="high",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _find_privacy_policy_link(self, page: Page) -> Optional[Locator]:
        """Find privacy policy link on the page."""
        for pattern in self.PRIVACY_POLICY_PATTERNS:
            try:
                link = page.get_by_role("link", name=re.compile(pattern, re.IGNORECASE)).first
                if await link.count() > 0:
                    return link
            except Exception as e:
                logger.debug(f"Error searching for {pattern}: {e}")

        return None

    def _analyze_grievance_disclosure(self, content: str) -> Dict:
        """
        Analyze content for grievance redressal mechanism disclosure.

        Args:
            content: Page or policy content

        Returns:
            Analysis dictionary
        """
        content_lower = content.lower()

        # Check for grievance officer
        officer_found = []
        for pattern in self.GRIEVANCE_OFFICER_PATTERNS:
            if pattern in content_lower:
                officer_found.append(pattern)

        # Check for contact information
        contact_found = []
        for keyword in self.CONTACT_KEYWORDS:
            if keyword in content_lower:
                contact_found.append(keyword)

        # Look for email addresses (pattern matching)
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        emails = re.findall(email_pattern, content)

        # Check for response timeframe
        response_time_found = []
        for keyword in self.RESPONSE_TIME_KEYWORDS:
            if keyword in content_lower:
                response_time_found.append(keyword)

        # Check for complaint mechanism keywords
        complaint_mechanism_found = []
        for keyword in self.COMPLAINT_KEYWORDS:
            if keyword in content_lower:
                complaint_mechanism_found.append(keyword)

        # Determine if requirements are met
        has_officer = len(officer_found) > 0
        has_contact = len(contact_found) >= 2 or len(emails) > 0
        has_response_time = len(response_time_found) > 0
        has_complaint_process = len(complaint_mechanism_found) >= 2

        return {
            'has_officer': has_officer,
            'officer_patterns': officer_found[:5],
            'has_contact': has_contact,
            'contact_keywords': contact_found[:5],
            'emails_found': len(emails),
            'has_response_time': has_response_time,
            'response_time_keywords': response_time_found[:3],
            'has_complaint_process': has_complaint_process,
            'complaint_keywords': complaint_mechanism_found[:5],
            'content_length': len(content),
        }

    async def _create_violation_result(
        self,
        page: Page,
        reason: str,
        details: Dict
    ) -> ComplianceCheckResult:
        """Create violation result with evidence."""

        evidence_map = {
            "no_grievance_mechanism": (
                "No grievance redressal mechanism found. DPDP Act Section 9 requires Data Fiduciaries "
                "to establish an effective grievance redressal mechanism with a designated Grievance Officer. "
                "Must be easily accessible to Data Principals."
            ),
            "no_grievance_officer": (
                "No Grievance Officer or Data Protection Officer mentioned. "
                "DPDP Act Section 9 requires designation of a Grievance Officer who can be contacted "
                "for complaints and concerns regarding personal data processing."
            ),
            "officer_no_contact": (
                "Grievance Officer mentioned but no contact information provided.\n"
                f"Officer patterns found: {', '.join(details.get('officer_patterns', []))}\n\n"
                "DPDP Act requires easily accessible contact details (email, phone, or address) "
                "for the Grievance Officer."
            ),
            "privacy_policy_inaccessible": (
                f"Privacy policy not accessible. Error: {details.get('error', 'Unknown')}. "
                "Grievance redressal information must be easily accessible."
            ),
        }

        evidence = evidence_map.get(reason, f"Grievance redressal violation: {reason}")

        # Add detailed findings if available
        if details:
            evidence += "\n\nFindings:"
            if details.get('has_complaint_process'):
                evidence += f"\n  - Complaint mechanism keywords found: {details.get('has_complaint_process')}"
            if details.get('has_response_time'):
                evidence += f"\n  - Response timeframe mentioned: Yes"
            else:
                evidence += f"\n  - Response timeframe mentioned: No (required: 30 days)"

        screenshot_path = await self.take_screenshot(page, "dpdp_006_grievance_violation")

        metadata = {
            'privacy_policy_url': self.privacy_policy_url,
            'violation_reason': reason,
            'has_officer': details.get('has_officer', False),
            'has_contact': details.get('has_contact', False),
            'has_response_time': details.get('has_response_time', False),
        }

        return ComplianceCheckResult(
            regulation_id="DPDP_2023",
            requirement_id="DPDP_006",
            status="failed",
            severity="high",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata=metadata,
            legal_risk=(
                "High-severity DPDP Act 2023 violation (Section 9: Grievance redressal by Data Fiduciary). "
                "Every Data Fiduciary must establish an effective grievance redressal mechanism "
                "and designate a Grievance Officer who is responsible for redressing grievances. "
                "The Grievance Officer must respond within 30 days of receipt of complaint. "
                "Penalties: Up to ₹200 crore (~$24 million USD) under Section 33. "
                "Significant Data Fiduciaries face additional obligations under Section 32."
            )
        )

    async def _create_compliant_result(self, analysis: Dict, location: str) -> ComplianceCheckResult:
        """Create compliant result."""

        evidence = (
            f"Grievance redressal mechanism found ({location}).\n"
            f"  - Grievance Officer mentioned: Yes\n"
            f"  - Officer patterns: {', '.join(analysis['officer_patterns'][:3])}\n"
            f"  - Contact information provided: Yes\n"
            f"  - Emails found: {analysis['emails_found']}\n"
            f"  - Response timeframe disclosed: {'Yes' if analysis['has_response_time'] else 'No'}\n"
            f"  - Complaint process described: {'Yes' if analysis['has_complaint_process'] else 'No'}\n\n"
            f"Note: Manual verification recommended to confirm:\n"
            f"  - Grievance Officer contact details are accurate\n"
            f"  - 30-day response commitment is stated\n"
            f"  - Mechanism is actually functional"
        )

        return ComplianceCheckResult(
            regulation_id="DPDP_2023",
            requirement_id="DPDP_006",
            status="passed",
            severity="high",
            evidence=evidence,
            metadata={
                'privacy_policy_url': self.privacy_policy_url,
                'location': location,
                'has_officer': analysis['has_officer'],
                'officer_patterns': analysis['officer_patterns'],
                'has_contact': analysis['has_contact'],
                'emails_found': analysis['emails_found'],
                'has_response_time': analysis['has_response_time'],
                'has_complaint_process': analysis['has_complaint_process'],
            }
        )
