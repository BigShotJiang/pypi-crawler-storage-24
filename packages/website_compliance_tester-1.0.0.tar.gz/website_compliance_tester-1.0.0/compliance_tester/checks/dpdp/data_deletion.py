"""
DPDP Data Deletion Request Option Check

Tests that users can easily request deletion of their personal data,
as required by India's Digital Personal Data Protection Act, 2023.

DPDP Act 2023, Section 12: Right to erasure of personal data
Section 6(6): Right to withdraw consent
Section 11(3): Obligation to erase data upon withdrawal of consent

Regulation: DPDP Act 2023 (India)
Requirement: DPDP_004 - Data Deletion Request Option
Severity: High
Automation: 100% automated
"""

from playwright.async_api import Page, Locator
from typing import Optional, Dict, List, Set
import logging
import re

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="DPDP_2023", requirement_id="DPDP_004")
class DataDeletionCheck(ComplianceCheck):
    """
    DPDP_004: Users must be able to request data deletion.

    This check verifies that websites provide an easily accessible option
    for users to request deletion of their personal data, as required by
    DPDP Act Section 12 (Right to erasure).

    Methodology:
    1. Look for login/account links
    2. Check for data deletion mentions on main page
    3. Look for account settings/privacy settings pages
    4. Search for "Delete My Data", "Right to Erasure" options
    5. Check help/support pages for deletion procedures
    6. Verify option is not buried (accessible within 2-3 clicks)

    Common violations:
    - No data deletion option available
    - Deletion option buried in deep menus
    - Only contact form (no self-service option)
    - Deletion not mentioned anywhere
    - Complex multi-step process without clear guidance

    Legal risk: Up to ₹50 crore (~$6M USD) under DPDP Act Section 33
    Note: Right to erasure is fundamental under DPDP Act
    """

    automation_level = "automated"
    severity = "high"

    # Data deletion/erasure patterns (English + Hindi)
    DATA_DELETION_PATTERNS = [
        # English - Direct deletion
        "delete my data",
        "delete my account",
        "delete account",
        "erase my data",
        "erase my account",
        "remove my data",
        "remove my account",
        "close my account",
        "deactivate account",

        # English - Right to erasure
        "right to erasure",
        "right to deletion",
        "data deletion",
        "data erasure",
        "data removal",
        "delete personal data",
        "erase personal data",
        "request deletion",
        "request erasure",

        # English - DPDP Act specific
        "withdraw consent",
        "withdrawal of consent",
        "revoke consent",

        # Hindi
        "डेटा हटाएं",           # data hataaen (delete data)
        "खाता हटाएं",          # khaata hataaen (delete account)
        "डेटा मिटाएं",          # data mitaaen (erase data)
        "व्यक्तिगत डेटा हटाएं", # vyaktigat data hataaen (delete personal data)
    ]

    # Account/settings link patterns
    ACCOUNT_LINK_PATTERNS = [
        "my account",
        "account",
        "profile",
        "settings",
        "account settings",
        "privacy settings",
        "manage account",
        "user settings",
        # Hindi
        "मेरा खाता",    # mera khaata (my account)
        "सेटिंग्स",     # settings
    ]

    # Help/support link patterns
    HELP_LINK_PATTERNS = [
        "help",
        "support",
        "faq",
        "contact",
        "contact us",
        "customer support",
        "help center",
        # Hindi
        "मदद",         # madad (help)
        "सहायता",      # sahayta (support)
    ]

    def __init__(self, regulation_id: str = "DPDP_2023", requirement_id: str = "DPDP_004"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.deletion_option_found = False
        self.deletion_option_location = None

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the data deletion request option check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting DPDP_004 check for {url}")

            # Navigate to page if needed
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            # Wait for page to settle
            await page.wait_for_timeout(2000)

            # Step 1: Check main page for deletion mentions
            main_page_check = await self._check_page_for_deletion_option(page, "main page")

            if main_page_check['found']:
                self.deletion_option_found = True
                self.deletion_option_location = "main page"
                return await self._create_compliant_result(main_page_check)

            # Step 2: Look for account settings link
            account_link = await self._find_account_link(page)

            if account_link:
                try:
                    # Navigate to account settings
                    await account_link.click()
                    await page.wait_for_load_state("networkidle", timeout=10000)

                    # Check account settings page
                    settings_check = await self._check_page_for_deletion_option(page, "account settings")

                    if settings_check['found']:
                        self.deletion_option_found = True
                        self.deletion_option_location = "account settings"
                        return await self._create_compliant_result(settings_check)

                except Exception as e:
                    logger.debug(f"Could not navigate to account settings: {e}")

            # Step 3: Look for help/support pages
            help_link = await self._find_help_link(page)

            if help_link:
                try:
                    # Navigate back to main page first
                    await page.goto(url)
                    await page.wait_for_timeout(1000)

                    # Find help link again
                    help_link = await self._find_help_link(page)
                    if help_link:
                        await help_link.click()
                        await page.wait_for_load_state("networkidle", timeout=10000)

                        # Check help page
                        help_check = await self._check_page_for_deletion_option(page, "help/support")

                        if help_check['found']:
                            self.deletion_option_found = True
                            self.deletion_option_location = "help/support page"
                            return await self._create_compliant_result(help_check)

                except Exception as e:
                    logger.debug(f"Could not check help page: {e}")

            # Step 4: No deletion option found
            return await self._create_violation_result(page)

        except Exception as e:
            logger.error(f"Error in DPDP_004 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="DPDP_2023",
                requirement_id="DPDP_004",
                status="error",
                severity="high",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _check_page_for_deletion_option(self, page: Page, location: str) -> Dict:
        """
        Check if current page contains data deletion option.

        Args:
            page: Playwright page object
            location: Description of current page location

        Returns:
            Dictionary with findings
        """
        try:
            page_text = await page.inner_text("body")
            page_text_lower = page_text.lower()

            # Check for deletion patterns
            found_patterns = []
            for pattern in self.DATA_DELETION_PATTERNS:
                if pattern.lower() in page_text_lower:
                    found_patterns.append(pattern)

            # Look for deletion-related links/buttons
            deletion_elements = []

            # Check buttons
            try:
                buttons = await page.query_selector_all("button, a")
                for button in buttons[:50]:  # Limit to avoid performance issues
                    text = await button.inner_text()
                    text_lower = text.lower().strip()

                    if any(pattern.lower() in text_lower for pattern in self.DATA_DELETION_PATTERNS):
                        deletion_elements.append({
                            'type': 'button/link',
                            'text': text.strip()[:100]  # Limit length
                        })
                        if len(deletion_elements) >= 5:  # Limit findings
                            break
            except Exception as e:
                logger.debug(f"Error checking buttons: {e}")

            return {
                'found': len(found_patterns) > 0 or len(deletion_elements) > 0,
                'location': location,
                'patterns_found': found_patterns[:10],
                'elements_found': deletion_elements[:5]
            }

        except Exception as e:
            logger.debug(f"Error checking page for deletion option: {e}")
            return {
                'found': False,
                'location': location,
                'patterns_found': [],
                'elements_found': []
            }

    async def _find_account_link(self, page: Page) -> Optional[Locator]:
        """
        Find account/settings link on the page.

        Args:
            page: Playwright page object

        Returns:
            Locator for account link, or None if not found
        """
        for pattern in self.ACCOUNT_LINK_PATTERNS:
            try:
                # Try as link
                link = page.get_by_role("link", name=re.compile(pattern, re.IGNORECASE)).first
                if await link.count() > 0:
                    logger.debug(f"Found account link: {pattern}")
                    return link

                # Try as button
                button = page.get_by_role("button", name=re.compile(pattern, re.IGNORECASE)).first
                if await button.count() > 0:
                    logger.debug(f"Found account button: {pattern}")
                    return button
            except Exception as e:
                logger.debug(f"Error searching for {pattern}: {e}")

        return None

    async def _find_help_link(self, page: Page) -> Optional[Locator]:
        """
        Find help/support link on the page.

        Args:
            page: Playwright page object

        Returns:
            Locator for help link, or None if not found
        """
        for pattern in self.HELP_LINK_PATTERNS:
            try:
                # Try as link
                link = page.get_by_role("link", name=re.compile(pattern, re.IGNORECASE)).first
                if await link.count() > 0:
                    logger.debug(f"Found help link: {pattern}")
                    return link

                # Try as button
                button = page.get_by_role("button", name=re.compile(pattern, re.IGNORECASE)).first
                if await button.count() > 0:
                    logger.debug(f"Found help button: {pattern}")
                    return button
            except Exception as e:
                logger.debug(f"Error searching for {pattern}: {e}")

        return None

    async def _create_compliant_result(self, check_results: Dict) -> ComplianceCheckResult:
        """
        Create a compliant result.

        Args:
            check_results: Results from deletion option check

        Returns:
            ComplianceCheckResult with passed status
        """
        patterns_found = check_results.get('patterns_found', [])
        elements_found = check_results.get('elements_found', [])
        location = check_results.get('location', 'page')

        evidence_parts = [
            f"Data deletion option found in {location}."
        ]

        if patterns_found:
            evidence_parts.append(f"  - Deletion mentions: {len(patterns_found)}")
            evidence_parts.append(f"  - Examples: {', '.join(patterns_found[:3])}")

        if elements_found:
            evidence_parts.append(f"  - Interactive elements: {len(elements_found)}")
            for elem in elements_found[:3]:
                evidence_parts.append(f"    • {elem['text']}")

        evidence_parts.append("\nNote: Manual verification recommended to ensure deletion process is functional.")

        evidence = "\n".join(evidence_parts)

        return ComplianceCheckResult(
            regulation_id="DPDP_2023",
            requirement_id="DPDP_004",
            status="passed",
            severity="high",
            evidence=evidence,
            metadata={
                'deletion_option_found': True,
                'deletion_option_location': location,
                'patterns_found_count': len(patterns_found),
                'patterns_found': patterns_found[:10],
                'elements_found_count': len(elements_found),
                'elements_found': [e['text'][:50] for e in elements_found[:5]]
            }
        )

    async def _create_violation_result(self, page: Page) -> ComplianceCheckResult:
        """
        Create a violation result.

        Args:
            page: Playwright page object

        Returns:
            ComplianceCheckResult with failed status
        """
        screenshot_path = await self.take_screenshot(page, "dpdp_004_no_deletion_option")

        evidence = (
            "No data deletion option found.\n"
            "DPDP Act Section 12 requires Data Fiduciaries to provide users with "
            "the right to request erasure of personal data.\n\n"
            "Checked locations:\n"
            "  - Main page\n"
            "  - Account settings (if accessible)\n"
            "  - Help/support pages (if accessible)\n\n"
            "Missing:\n"
            "  - 'Delete My Data' option\n"
            "  - 'Right to Erasure' information\n"
            "  - Data deletion request mechanism\n\n"
            "Recommendation: Add a visible data deletion option in account settings "
            "or provide clear instructions in help/privacy pages."
        )

        return ComplianceCheckResult(
            regulation_id="DPDP_2023",
            requirement_id="DPDP_004",
            status="failed",
            severity="high",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata={
                'deletion_option_found': False,
                'deletion_option_location': None,
                'patterns_found_count': 0,
                'elements_found_count': 0
            },
            legal_risk=(
                "High-severity DPDP Act 2023 violation (Section 12: Right to erasure of personal data). "
                "Data Principal must be able to request deletion of personal data. "
                "Penalties: Up to ₹50 crore (~$6 million USD) under Section 33. "
                "Right to erasure is a fundamental user right under DPDP Act. "
                "Section 11(3) requires Data Fiduciary to erase data upon withdrawal of consent."
            )
        )
