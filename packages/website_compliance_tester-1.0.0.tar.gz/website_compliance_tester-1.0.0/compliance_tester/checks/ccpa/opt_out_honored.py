"""
CCPA Opt-Out Honored Check

Tests that websites actually honor the "Do Not Sell" opt-out request by not
tracking users after they opt-out, as required by California Consumer Privacy Act.

CCPA Section 1798.135(a)(4): Opt-out must be honored for at least 12 months
CCPA Section 1798.120: Right to opt-out of sale
CPRA: Enhanced enforcement and verification requirements

Regulation: CCPA/CPRA (California)
Requirement: CCPA_002 - Opt-Out Honored
Severity: Critical
Automation: 100% automated
"""

from playwright.async_api import Page, Request
from typing import Optional, Dict, List
import logging
import re

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="CCPA", requirement_id="CCPA_002")
class OptOutHonoredCheck(ComplianceCheck):
    """
    CCPA_002: Opt-out requests must be honored (no tracking after opt-out).

    This check verifies that after a user opts out of sale via the
    "Do Not Sell" mechanism, the website actually honors that request
    by not loading tracking/advertising scripts.

    Methodology:
    1. Set opt-out cookie/signal (simulate user opt-out)
    2. Navigate to page with opt-out active
    3. Monitor network requests for tracking/advertising
    4. Check for tracking cookies/storage
    5. Verify no data collection to third parties

    Common violations:
    - Opt-out cookie set but tracking still occurs
    - Advertising scripts still loaded after opt-out
    - Third-party tracking continues despite opt-out
    - Opt-out only partially honored (some trackers disabled, others not)
    - Opt-out not persistent across sessions

    Legal risk: Up to $7,500 per intentional violation (CCPA Section 1798.155)
    CPRA: Additional penalties for failure to honor opt-out
    """

    automation_level = "automated"
    severity = "critical"

    # Common CCPA opt-out cookie names
    OPT_OUT_COOKIE_NAMES = [
        "OptanonAlertBoxClosed",
        "OptanonConsent",
        "ccpa-opt-out",
        "us_privacy",
        "usprivacy",
        "privacy_optout",
        "do_not_sell",
        "dns",  # Do Not Sell
    ]

    # Tracking/advertising domains (should NOT load after opt-out)
    TRACKING_DOMAINS = [
        # Advertising networks
        'doubleclick.net',
        'googleadservices.com',
        'googlesyndication.com',
        'adnxs.com',  # AppNexus
        'adsafeprotected.com',
        'advertising.com',
        'criteo.com',
        'taboola.com',
        'outbrain.com',
        'pubmatic.com',
        'rubiconproject.com',
        'openx.net',

        # Analytics (may be allowed for functional purposes, but watch for sale)
        'google-analytics.com',
        'googletagmanager.com',

        # Social media tracking
        'connect.facebook.net',
        'facebook.com/tr',
        'twitter.com/i/adsct',
        'linkedin.com/px',
        'snapchat.com/tr',

        # Data brokers / aggregators
        'bluekai.com',
        'krxd.net',
        'rlcdn.com',
        'exelator.com',
    ]

    # Tracking storage keys
    TRACKING_STORAGE_PATTERNS = [
        '_ga', '_gid', '_gat',  # Google Analytics
        '_fbp', '_fbc',  # Facebook
        'anj',  # AppNexus
        'criteo',
        'taboola',
    ]

    def __init__(self, regulation_id: str = "CCPA", requirement_id: str = "CCPA_002"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.tracking_requests: List[Dict] = []
        self.all_requests: List[Dict] = []

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the opt-out honored check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting CCPA_002 check for {url}")

            # Reset tracking lists
            self.tracking_requests = []
            self.all_requests = []

            # Step 1: Set opt-out signals
            await self._set_opt_out_signals(page, url)

            # Step 2: Set up request interception
            page.on("request", self._track_request)

            # Step 3: Navigate to page with opt-out active
            await page.goto(url, wait_until="networkidle", timeout=30000)
            await page.wait_for_timeout(3000)

            # Step 4: Check for tracking in storage
            storage_violations = await self._check_storage_tracking(page)

            # Step 5: Analyze results
            if self.tracking_requests or storage_violations:
                return await self._create_violation_result(
                    page=page,
                    storage_violations=storage_violations
                )
            else:
                return await self._create_compliant_result()

        except Exception as e:
            logger.error(f"Error in CCPA_002 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="CCPA",
                requirement_id="CCPA_002",
                status="error",
                severity="critical",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _set_opt_out_signals(self, page: Page, url: str):
        """
        Set opt-out cookies and signals to simulate user opt-out.

        Args:
            page: Playwright page object
            url: URL being tested
        """
        try:
            # Extract domain from URL
            from urllib.parse import urlparse
            parsed = urlparse(url)
            domain = parsed.netloc or parsed.path.split('/')[0]

            # Set common opt-out cookies
            context = page.context

            # us_privacy string (IAB CCPA Compliance Framework)
            # 1YNN = Version 1, Yes explicit notice, No opt-out, No LSPA
            # 1YYN = Version 1, Yes explicit notice, Yes opt-out, No LSPA
            await context.add_cookies([
                {
                    'name': 'us_privacy',
                    'value': '1YYN',  # Opted out
                    'domain': domain if not domain.startswith('file://') else 'localhost',
                    'path': '/'
                }
            ])

            # OneTrust opt-out
            await context.add_cookies([
                {
                    'name': 'OptanonConsent',
                    'value': 'isIABGlobal=false&datestamp=&version=6.17.0&hosts=&consentId=&interactionCount=0&landingPath=NotLandingPage&groups=C0001:1,C0002:0,C0003:0,C0004:0',
                    'domain': domain if not domain.startswith('file://') else 'localhost',
                    'path': '/'
                }
            ])

            # Generic do-not-sell cookie
            await context.add_cookies([
                {
                    'name': 'ccpa-opt-out',
                    'value': 'true',
                    'domain': domain if not domain.startswith('file://') else 'localhost',
                    'path': '/'
                }
            ])

            # Set DNT (Do Not Track) header
            await context.set_extra_http_headers({'DNT': '1'})

            logger.debug("Set opt-out cookies and signals")

        except Exception as e:
            logger.debug(f"Error setting opt-out signals: {e}")

    def _track_request(self, request: Request):
        """
        Track network requests to detect tracking after opt-out.

        Args:
            request: Playwright request object
        """
        try:
            url = request.url
            resource_type = request.resource_type

            # Record all requests
            self.all_requests.append({
                'url': url,
                'type': resource_type,
                'method': request.method
            })

            # Check if this is a tracking request
            domain = self._extract_domain(url)

            if any(tracking_domain in domain for tracking_domain in self.TRACKING_DOMAINS):
                logger.debug(f"Detected tracking request after opt-out: {domain} ({resource_type})")
                self.tracking_requests.append({
                    'url': url,
                    'domain': domain,
                    'type': resource_type,
                    'method': request.method
                })

        except Exception as e:
            logger.debug(f"Error tracking request: {e}")

    def _extract_domain(self, url: str) -> str:
        """
        Extract domain from URL.

        Args:
            url: Full URL

        Returns:
            Domain name
        """
        try:
            domain = re.sub(r'^https?://', '', url)
            domain = domain.split('/')[0]
            domain = domain.split(':')[0]
            return domain.lower()
        except Exception:
            return url

    async def _check_storage_tracking(self, page: Page) -> List[str]:
        """
        Check localStorage and sessionStorage for tracking keys.

        Args:
            page: Playwright page object

        Returns:
            List of tracking keys found
        """
        violations = []

        try:
            # Check localStorage
            local_storage = await page.evaluate('''
                () => {
                    const items = {};
                    for (let i = 0; i < localStorage.length; i++) {
                        const key = localStorage.key(i);
                        items[key] = localStorage.getItem(key);
                    }
                    return items;
                }
            ''')

            # Check sessionStorage
            session_storage = await page.evaluate('''
                () => {
                    const items = {};
                    for (let i = 0; i < sessionStorage.length; i++) {
                        const key = sessionStorage.key(i);
                        items[key] = sessionStorage.getItem(key);
                    }
                    return items;
                }
            ''')

            all_storage = {**local_storage, **session_storage}

            for key in all_storage.keys():
                if any(pattern in key.lower() for pattern in self.TRACKING_STORAGE_PATTERNS):
                    violations.append(key)
                    logger.debug(f"Found tracking storage key after opt-out: {key}")

        except Exception as e:
            logger.debug(f"Error checking storage: {e}")

        return violations

    async def _create_violation_result(
        self,
        page: Page,
        storage_violations: List[str]
    ) -> ComplianceCheckResult:
        """
        Create a violation result.

        Args:
            page: Playwright page object
            storage_violations: List of tracking storage keys found

        Returns:
            ComplianceCheckResult with failed status
        """
        evidence_parts = []

        evidence_parts.append(
            "Opt-out NOT honored: Tracking detected after user opted out of sale.\n"
        )

        if self.tracking_requests:
            evidence_parts.append(
                f"Detected {len(self.tracking_requests)} tracking request(s) after opt-out:"
            )

            domains_seen = set()
            for req in self.tracking_requests[:10]:
                if req['domain'] not in domains_seen:
                    evidence_parts.append(f"  - {req['domain']} ({req['type']})")
                    domains_seen.add(req['domain'])

            if len(self.tracking_requests) > 10:
                evidence_parts.append(f"  ... and {len(self.tracking_requests) - 10} more")

        if storage_violations:
            evidence_parts.append(
                f"\nDetected {len(storage_violations)} tracking storage key(s) after opt-out:"
            )
            for key in storage_violations[:10]:
                evidence_parts.append(f"  - {key}")

        evidence_parts.append(
            "\nCCPA requires websites to honor opt-out requests and not sell personal information "
            "after a consumer opts out."
        )

        evidence = "\n".join(evidence_parts)

        screenshot_path = await self.take_screenshot(page, "ccpa_002_opt_out_not_honored")

        tracking_domains = list(set(req['domain'] for req in self.tracking_requests))

        return ComplianceCheckResult(
            regulation_id="CCPA",
            requirement_id="CCPA_002",
            status="failed",
            severity="critical",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata={
                'total_requests': len(self.all_requests),
                'tracking_requests_count': len(self.tracking_requests),
                'tracking_domains': tracking_domains[:20],
                'storage_violations': storage_violations[:20],
                'opt_out_honored': False
            },
            legal_risk=(
                "Critical CCPA violation (Section 1798.135(a)(4): Businesses must honor opt-out). "
                "After a consumer opts out, the business must not sell their personal information. "
                "Penalties: Up to $2,500 per violation, $7,500 per intentional violation. "
                "CPRA (2023): Enhanced enforcement by California Privacy Protection Agency. "
                "Continuing to sell data after opt-out can result in regulatory action and consumer lawsuits."
            )
        )

    async def _create_compliant_result(self) -> ComplianceCheckResult:
        """
        Create a compliant result.

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            f"Opt-out honored: No tracking detected after user opted out of sale.\n"
            f"  - Total requests analyzed: {len(self.all_requests)}\n"
            f"  - Tracking requests found: 0\n"
            f"  - Storage violations: 0\n\n"
            f"The website appears to honor the CCPA opt-out request.\n"
            f"Note: Manual verification recommended to ensure full compliance over time."
        )

        return ComplianceCheckResult(
            regulation_id="CCPA",
            requirement_id="CCPA_002",
            status="passed",
            severity="critical",
            evidence=evidence,
            metadata={
                'total_requests': len(self.all_requests),
                'tracking_requests_count': 0,
                'tracking_domains': [],
                'storage_violations': [],
                'opt_out_honored': True
            }
        )
