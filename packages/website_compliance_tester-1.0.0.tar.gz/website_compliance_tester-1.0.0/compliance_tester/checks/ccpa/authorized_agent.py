"""
CCPA Authorized Agent Support Check

Tests that websites accept and process consumer rights requests from authorized
agents acting on behalf of consumers, as required by California Consumer Privacy Act.

California Civil Code § 1798.135(b): Authorized agent submissions
California Civil Code § 1798.130(a)(2): Method for submitting requests
California Regulations § 999.326: Authorized agents

Regulation: CCPA/CPRA (California)
Requirement: CCPA_004 - Authorized Agent Support
Severity: Medium
Automation: 85% automated (manual verification of actual process recommended)
"""

from playwright.async_api import Page, Locator
from typing import Optional, Dict, List
import logging
import re

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="CCPA", requirement_id="CCPA_004")
class AuthorizedAgentCheck(ComplianceCheck):
    """
    CCPA_004: Businesses must accept requests from authorized agents.

    This check verifies that websites acknowledge and provide a process for
    authorized agents to submit consumer rights requests on behalf of consumers,
    as required by California Civil Code § 1798.135(b).

    Methodology:
    1. Navigate to privacy policy
    2. Search for "authorized agent" mentions
    3. Check for agent verification process description
    4. Verify businesses cannot deny requests solely because from agent
    5. Look for specific instructions for agent submissions

    Common violations:
    - No mention of authorized agents
    - No process described for agent submissions
    - Policy suggests agent requests will be denied
    - No verification requirements specified
    - Missing from privacy policy and request forms

    Legal risk: Up to $7,500 per intentional violation (California Civil Code § 1798.155)
    Regulation § 999.326 provides detailed authorized agent requirements
    """

    automation_level = "automated"
    severity = "medium"

    # Privacy policy patterns
    PRIVACY_POLICY_PATTERNS = [
        "privacy policy",
        "privacy notice",
        "california privacy",
        "consumer privacy",
        "privacy statement",
    ]

    # Authorized agent keywords
    AUTHORIZED_AGENT_KEYWORDS = [
        "authorized agent",
        "authorised agent",  # UK spelling variant
        "designated agent",
        "agent on behalf",
        "agent to submit",
        "representative",
        "power of attorney",
        "legal representative",
        "submit on behalf",
        "on your behalf",
    ]

    # Agent verification/process keywords
    AGENT_PROCESS_KEYWORDS = [
        "agent verification",
        "verify the agent",
        "agent authorization",
        "proof of authorization",
        "written permission",
        "signed permission",
        "consumer authorization",
        "power of attorney",
        "agent registration",
        "registered agent",
        "agent must provide",
        "agent submission",
    ]

    # Agent acceptance indicators (positive)
    AGENT_ACCEPTANCE_KEYWORDS = [
        "accept requests from agents",
        "agents may submit",
        "through an authorized agent",
        "via an authorized agent",
        "agent can submit",
        "allow agents",
        "permit agents",
    ]

    # Agent rejection indicators (negative - violation)
    AGENT_REJECTION_KEYWORDS = [
        "do not accept agent",
        "will not accept agent",
        "cannot use an agent",
        "must submit yourself",
        "only accept requests from the consumer",
        "directly from the consumer",
        "no third party",
        "no third-party",
    ]

    # Consumer rights request keywords
    RIGHTS_REQUEST_KEYWORDS = [
        "request to know",
        "request to delete",
        "request to opt-out",
        "exercise your rights",
        "submit a request",
        "consumer request",
        "rights request",
    ]

    def __init__(self, regulation_id: str = "CCPA", requirement_id: str = "CCPA_004"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.privacy_policy_url = None

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the authorized agent support check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting CCPA_004 check for {url}")

            # Navigate to page if needed
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            await page.wait_for_timeout(2000)

            # Step 1: Find privacy policy
            privacy_link = await self._find_privacy_policy_link(page)

            if not privacy_link:
                return await self._create_violation_result(
                    page=page,
                    reason="no_privacy_policy",
                    details={}
                )

            self.privacy_policy_url = await privacy_link.get_attribute("href")

            # Step 2: Navigate to privacy policy
            try:
                await privacy_link.click()
                await page.wait_for_load_state("networkidle", timeout=10000)
            except Exception as e:
                logger.debug(f"Failed to navigate to privacy policy: {e}")
                return await self._create_violation_result(
                    page=page,
                    reason="privacy_policy_inaccessible",
                    details={'error': str(e)}
                )

            # Step 3: Analyze privacy policy for authorized agent support
            policy_content = await page.inner_text("body")
            analysis = self._analyze_authorized_agent_support(policy_content)

            # Step 4: Determine compliance
            if analysis['has_violations']:
                return await self._create_violation_result(
                    page=page,
                    reason="insufficient_agent_support",
                    details=analysis
                )
            else:
                return await self._create_compliant_result(analysis)

        except Exception as e:
            logger.error(f"Error in CCPA_004 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="CCPA",
                requirement_id="CCPA_004",
                status="error",
                severity="medium",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _find_privacy_policy_link(self, page: Page) -> Optional[Locator]:
        """Find privacy policy link on the page."""
        for pattern in self.PRIVACY_POLICY_PATTERNS:
            try:
                link = page.get_by_role("link", name=re.compile(pattern, re.IGNORECASE)).first
                if await link.count() > 0:
                    return link
            except Exception as e:
                logger.debug(f"Error searching for {pattern}: {e}")

        return None

    def _analyze_authorized_agent_support(self, content: str) -> Dict:
        """
        Analyze privacy policy for authorized agent support.

        Args:
            content: Privacy policy text

        Returns:
            Analysis dictionary
        """
        content_lower = content.lower()

        # Check for authorized agent mentions
        agent_mentions = []
        for keyword in self.AUTHORIZED_AGENT_KEYWORDS:
            if keyword in content_lower:
                agent_mentions.append(keyword)

        # Check for agent process/verification
        agent_process_found = []
        for keyword in self.AGENT_PROCESS_KEYWORDS:
            if keyword in content_lower:
                agent_process_found.append(keyword)

        # Check for agent acceptance indicators
        agent_acceptance = []
        for keyword in self.AGENT_ACCEPTANCE_KEYWORDS:
            if keyword in content_lower:
                agent_acceptance.append(keyword)

        # Check for agent rejection indicators (red flags)
        agent_rejection = []
        for keyword in self.AGENT_REJECTION_KEYWORDS:
            if keyword in content_lower:
                agent_rejection.append(keyword)

        # Check for rights request context
        rights_requests_found = []
        for keyword in self.RIGHTS_REQUEST_KEYWORDS:
            if keyword in content_lower:
                rights_requests_found.append(keyword)

        # Determine compliance
        has_agent_mention = len(agent_mentions) > 0
        has_agent_process = len(agent_process_found) >= 1
        has_acceptance = len(agent_acceptance) > 0
        has_rejection = len(agent_rejection) > 0
        has_rights_context = len(rights_requests_found) >= 2

        # Determine violations
        violations = []
        has_violations = False

        # Violation 1: No mention of authorized agents at all
        if not has_agent_mention:
            has_violations = True
            violations.append(
                "No mention of authorized agents in privacy policy"
            )

        # Violation 2: Explicit rejection of agent requests
        if has_rejection:
            has_violations = True
            violations.append(
                f"Privacy policy suggests agent requests may be rejected: {', '.join(agent_rejection[:2])}"
            )

        # Violation 3: Agent mentioned but no process described
        if has_agent_mention and not has_agent_process and not has_acceptance:
            has_violations = True
            violations.append(
                "Authorized agent mentioned but no verification process or acceptance statement provided"
            )

        # Violation 4: Missing context about consumer rights requests
        if has_agent_mention and not has_rights_context:
            has_violations = True
            violations.append(
                "Authorized agent mentioned but insufficient context about which rights requests agents can submit"
            )

        # Note: If policy is too short, it's likely incomplete
        if len(content) < 1000:
            has_violations = True
            violations.append(
                f"Privacy policy too short ({len(content)} characters) - likely incomplete for CCPA compliance"
            )

        return {
            'has_violations': has_violations,
            'violations': violations,
            'has_agent_mention': has_agent_mention,
            'agent_mentions_count': len(agent_mentions),
            'agent_mentions': agent_mentions[:5],
            'has_agent_process': has_agent_process,
            'agent_process_count': len(agent_process_found),
            'agent_process': agent_process_found[:5],
            'has_acceptance': has_acceptance,
            'agent_acceptance': agent_acceptance[:3],
            'has_rejection': has_rejection,
            'agent_rejection': agent_rejection[:3],
            'has_rights_context': has_rights_context,
            'rights_requests_count': len(rights_requests_found),
            'policy_length': len(content),
        }

    async def _create_violation_result(
        self,
        page: Page,
        reason: str,
        details: Dict
    ) -> ComplianceCheckResult:
        """Create violation result with evidence."""

        evidence_map = {
            "no_privacy_policy": (
                "No privacy policy found. California Civil Code § 1798.135(b) requires businesses "
                "to accept and process consumer rights requests from authorized agents. "
                "This must be disclosed in the privacy policy."
            ),
            "privacy_policy_inaccessible": (
                f"Privacy policy not accessible. Error: {details.get('error', 'Unknown')}. "
                "Authorized agent support information must be easily accessible."
            ),
            "insufficient_agent_support": (
                "Privacy policy does not adequately address authorized agent support.\n\n"
                "Violations found:\n"
                + "\n".join(f"  - {v}" for v in details.get('violations', []))
                + "\n\nCalifornia Civil Code § 1798.135(b) requires:\n"
                "  - Businesses must accept requests from authorized agents\n"
                "  - Cannot deny a request solely because it comes from an agent\n"
                "  - May require verification of agent's authorization\n"
                "  - Process must be described in privacy policy"
            ),
        }

        evidence = evidence_map.get(reason, f"Authorized agent support violation: {reason}")

        # Add findings if available
        if details and reason == "insufficient_agent_support":
            if details.get('has_rejection'):
                evidence += f"\n\nWarning: Policy contains agent rejection language: {', '.join(details.get('agent_rejection', [])[:2])}"

        screenshot_path = await self.take_screenshot(page, "ccpa_004_agent_violation")

        metadata = {
            'privacy_policy_url': self.privacy_policy_url,
            'violation_reason': reason,
        }

        if reason == "insufficient_agent_support":
            metadata.update({
                'has_agent_mention': details.get('has_agent_mention', False),
                'has_agent_process': details.get('has_agent_process', False),
                'has_acceptance': details.get('has_acceptance', False),
                'has_rejection': details.get('has_rejection', False),
                'violations': details.get('violations', []),
            })

        return ComplianceCheckResult(
            regulation_id="CCPA",
            requirement_id="CCPA_004",
            status="failed",
            severity="medium",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata=metadata,
            legal_risk=(
                "Medium-severity CCPA violation (California Civil Code § 1798.135(b): Authorized Agent Submissions). "
                "Businesses must allow California consumers to designate an authorized agent to make requests "
                "on their behalf to know, delete, or opt-out of sale of personal information. "
                "A business cannot deny a verifiable consumer request from an authorized agent solely because "
                "the request was submitted by an agent (California Regulations § 999.326). "
                "Penalties: Up to $2,500 per violation, $7,500 per intentional violation. "
                "Failure to accept authorized agent requests may result in regulatory complaints and enforcement action."
            )
        )

    async def _create_compliant_result(self, analysis: Dict) -> ComplianceCheckResult:
        """Create compliant result."""

        evidence = (
            f"Privacy policy addresses authorized agent support.\n"
            f"  - Authorized agent mentioned: {'Yes' if analysis['has_agent_mention'] else 'No'}\n"
            f"  - Agent mentions: {analysis['agent_mentions_count']}\n"
            f"  - Example terms: {', '.join(analysis['agent_mentions'][:3]) if analysis['agent_mentions'] else 'None'}\n"
            f"  - Agent process described: {'Yes' if analysis['has_agent_process'] else 'No'}\n"
            f"  - Process keywords: {analysis['agent_process_count']}\n"
            f"  - Acceptance statement: {'Yes' if analysis['has_acceptance'] else 'No'}\n"
            f"  - Rejection language: {'Yes (CONCERN)' if analysis['has_rejection'] else 'No'}\n"
            f"  - Rights request context: {'Yes' if analysis['has_rights_context'] else 'No'}\n"
            f"  - Policy length: {analysis['policy_length']} characters\n\n"
            f"Note: Manual verification recommended to confirm:\n"
            f"  - Agent verification process is reasonable\n"
            f"  - Business does not unduly burden agent requests\n"
            f"  - Process is actually implemented in practice\n"
            f"  - Contact forms/portals accept agent submissions"
        )

        return ComplianceCheckResult(
            regulation_id="CCPA",
            requirement_id="CCPA_004",
            status="passed",
            severity="medium",
            evidence=evidence,
            metadata={
                'privacy_policy_url': self.privacy_policy_url,
                'has_agent_mention': analysis['has_agent_mention'],
                'agent_mentions_count': analysis['agent_mentions_count'],
                'agent_mentions': analysis['agent_mentions'],
                'has_agent_process': analysis['has_agent_process'],
                'agent_process_count': analysis['agent_process_count'],
                'has_acceptance': analysis['has_acceptance'],
                'has_rejection': analysis['has_rejection'],
                'has_rights_context': analysis['has_rights_context'],
            }
        )
