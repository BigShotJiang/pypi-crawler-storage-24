"""
CCPA Privacy Policy Disclosures Check

Tests that privacy policies include required CCPA disclosures including categories
of personal information collected, business purposes, third-party sharing, and consumer rights.

California Civil Code § 1798.100: Notice at collection
California Civil Code § 1798.110: Right to know categories
California Civil Code § 1798.130(a)(5): Privacy policy requirements
CPRA (2023): Enhanced disclosure requirements

Regulation: CCPA/CPRA (California)
Requirement: CCPA_003 - Privacy Policy Disclosures
Severity: High
Automation: 80% automated (manual review of disclosure completeness recommended)
"""

from playwright.async_api import Page, Locator
from typing import Optional, Dict, List
import logging
import re

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="CCPA", requirement_id="CCPA_003")
class PrivacyPolicyDisclosuresCheck(ComplianceCheck):
    """
    CCPA_003: Privacy policy must include required CCPA disclosures.

    This check verifies that privacy policies contain the required CCPA disclosures
    about data collection, use, sharing, and consumer rights per § 1798.130(a)(5).

    Methodology:
    1. Navigate to privacy policy
    2. Check for categories of personal information collected
    3. Verify business/commercial purposes are disclosed
    4. Check for third-party sharing disclosures
    5. Verify California consumer rights are listed
    6. Look for CCPA-specific terminology

    Common violations:
    - No privacy policy or not accessible
    - Missing categories of personal information
    - Vague business purposes ("various purposes")
    - No third-party sharing disclosure
    - California consumer rights not listed
    - No CCPA-specific sections

    Legal risk: Up to $7,500 per intentional violation (California Civil Code § 1798.155)
    CPRA: Additional enforcement by California Privacy Protection Agency
    """

    automation_level = "semi_automated"
    severity = "high"

    # Privacy policy patterns
    PRIVACY_POLICY_PATTERNS = [
        "privacy policy",
        "privacy notice",
        "privacy statement",
        "california privacy",
        "consumer privacy",
    ]

    # CCPA-specific section indicators
    CCPA_SECTION_PATTERNS = [
        "california residents",
        "california consumers",
        "ccpa",
        "california privacy rights",
        "california consumer privacy act",
        "cpra",
        "your california privacy rights",
        "notice to california residents",
    ]

    # Categories of personal information (CCPA § 1798.140)
    PERSONAL_INFO_CATEGORIES = [
        "categories of personal information",
        "types of personal information",
        "personal information we collect",
        "information collected",
        "data collected",
        "identifiers",
        "commercial information",
        "biometric information",
        "internet activity",
        "geolocation data",
        "sensory data",
        "professional information",
        "education information",
        "inferences",
    ]

    # Business/commercial purpose indicators
    BUSINESS_PURPOSE_KEYWORDS = [
        "business purpose",
        "commercial purpose",
        "purpose for collecting",
        "why we collect",
        "how we use",
        "use of information",
        "purposes of processing",
        "we use your information",
    ]

    # Third-party sharing indicators
    THIRD_PARTY_KEYWORDS = [
        "third party",
        "third parties",
        "share with",
        "disclose to",
        "sell to",
        "sale of personal information",
        "sharing personal information",
        "categories of third parties",
        "service providers",
        "vendors",
    ]

    # California consumer rights (CCPA § 1798.100-1798.120)
    CONSUMER_RIGHTS_KEYWORDS = [
        "right to know",
        "right to delete",
        "right to opt-out",
        "right to non-discrimination",
        "right to correct",  # CPRA addition
        "right to limit",    # CPRA addition
        "consumer rights",
        "your rights",
        "california rights",
        "access your information",
        "deletion request",
        "opt out of sale",
        "do not sell",
    ]

    # Required disclosure elements
    REQUIRED_DISCLOSURES = [
        "categories",      # Categories of PI collected
        "purposes",        # Business purposes
        "third parties",   # Third-party sharing
        "rights",          # Consumer rights
    ]

    def __init__(self, regulation_id: str = "CCPA", requirement_id: str = "CCPA_003"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.privacy_policy_url = None

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the privacy policy disclosures check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting CCPA_003 check for {url}")

            # Navigate to page if needed
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            await page.wait_for_timeout(2000)

            # Step 1: Find privacy policy
            privacy_link = await self._find_privacy_policy_link(page)

            if not privacy_link:
                return await self._create_violation_result(
                    page=page,
                    reason="no_privacy_policy",
                    details={}
                )

            self.privacy_policy_url = await privacy_link.get_attribute("href")

            # Step 2: Navigate to privacy policy
            try:
                await privacy_link.click()
                await page.wait_for_load_state("networkidle", timeout=10000)
            except Exception as e:
                logger.debug(f"Failed to navigate to privacy policy: {e}")
                return await self._create_violation_result(
                    page=page,
                    reason="privacy_policy_inaccessible",
                    details={'error': str(e)}
                )

            # Step 3: Analyze privacy policy content
            policy_content = await page.inner_text("body")
            analysis = self._analyze_ccpa_disclosures(policy_content)

            # Step 4: Determine compliance
            if analysis['has_violations']:
                return await self._create_violation_result(
                    page=page,
                    reason="insufficient_ccpa_disclosures",
                    details=analysis
                )
            else:
                return await self._create_compliant_result(analysis)

        except Exception as e:
            logger.error(f"Error in CCPA_003 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="CCPA",
                requirement_id="CCPA_003",
                status="error",
                severity="high",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _find_privacy_policy_link(self, page: Page) -> Optional[Locator]:
        """Find privacy policy link on the page."""
        for pattern in self.PRIVACY_POLICY_PATTERNS:
            try:
                link = page.get_by_role("link", name=re.compile(pattern, re.IGNORECASE)).first
                if await link.count() > 0:
                    return link
            except Exception as e:
                logger.debug(f"Error searching for {pattern}: {e}")

        return None

    def _analyze_ccpa_disclosures(self, content: str) -> Dict:
        """
        Analyze privacy policy for CCPA-required disclosures.

        Args:
            content: Privacy policy text

        Returns:
            Analysis dictionary
        """
        content_lower = content.lower()

        # Check for CCPA-specific sections
        ccpa_sections_found = []
        for pattern in self.CCPA_SECTION_PATTERNS:
            if pattern in content_lower:
                ccpa_sections_found.append(pattern)

        # Check for categories of personal information
        categories_found = []
        for category in self.PERSONAL_INFO_CATEGORIES:
            if category in content_lower:
                categories_found.append(category)

        # Check for business purposes
        business_purposes_found = []
        for keyword in self.BUSINESS_PURPOSE_KEYWORDS:
            if keyword in content_lower:
                business_purposes_found.append(keyword)

        # Check for third-party disclosures
        third_party_found = []
        for keyword in self.THIRD_PARTY_KEYWORDS:
            if keyword in content_lower:
                third_party_found.append(keyword)

        # Check for consumer rights
        consumer_rights_found = []
        for right in self.CONSUMER_RIGHTS_KEYWORDS:
            if right in content_lower:
                consumer_rights_found.append(right)

        # Check for specific required rights
        has_right_to_know = any('right to know' in r for r in consumer_rights_found)
        has_right_to_delete = any('right to delete' in r or 'deletion' in r for r in consumer_rights_found)
        has_right_to_opt_out = any('opt out' in r or 'opt-out' in r for r in consumer_rights_found)

        # Determine compliance
        has_ccpa_section = len(ccpa_sections_found) > 0
        has_categories = len(categories_found) >= 2
        has_purposes = len(business_purposes_found) >= 2
        has_third_party = len(third_party_found) >= 2
        has_consumer_rights = len(consumer_rights_found) >= 3

        # Determine violations
        violations = []
        has_violations = False

        # Violation 1: No CCPA-specific section
        if not has_ccpa_section:
            has_violations = True
            violations.append(
                "No CCPA-specific section or California consumer notice found"
            )

        # Violation 2: Missing categories of personal information
        if not has_categories:
            has_violations = True
            violations.append(
                f"Insufficient disclosure of personal information categories (found {len(categories_found)} keywords, need at least 2)"
            )

        # Violation 3: Missing business purposes
        if not has_purposes:
            has_violations = True
            violations.append(
                f"Insufficient business/commercial purpose disclosure (found {len(business_purposes_found)} keywords, need at least 2)"
            )

        # Violation 4: Missing third-party sharing disclosure
        if not has_third_party:
            has_violations = True
            violations.append(
                f"Insufficient third-party sharing disclosure (found {len(third_party_found)} keywords, need at least 2)"
            )

        # Violation 5: Missing consumer rights
        if not has_consumer_rights:
            has_violations = True
            violations.append(
                f"Insufficient California consumer rights disclosure (found {len(consumer_rights_found)} keywords, need at least 3)"
            )

        # Violation 6: Missing specific required rights
        missing_rights = []
        if not has_right_to_know:
            missing_rights.append("Right to Know")
        if not has_right_to_delete:
            missing_rights.append("Right to Delete")
        if not has_right_to_opt_out:
            missing_rights.append("Right to Opt-Out")

        if missing_rights:
            has_violations = True
            violations.append(
                f"Missing required consumer rights: {', '.join(missing_rights)}"
            )

        # Violation 7: Policy too short (likely incomplete)
        if len(content) < 1000:
            has_violations = True
            violations.append(
                f"Privacy policy too short ({len(content)} characters) - likely incomplete for CCPA compliance"
            )

        return {
            'has_violations': has_violations,
            'violations': violations,
            'has_ccpa_section': has_ccpa_section,
            'ccpa_sections_count': len(ccpa_sections_found),
            'ccpa_sections': ccpa_sections_found[:5],
            'has_categories': has_categories,
            'categories_count': len(categories_found),
            'categories': categories_found[:10],
            'has_purposes': has_purposes,
            'purposes_count': len(business_purposes_found),
            'purposes': business_purposes_found[:5],
            'has_third_party': has_third_party,
            'third_party_count': len(third_party_found),
            'third_party': third_party_found[:5],
            'has_consumer_rights': has_consumer_rights,
            'consumer_rights_count': len(consumer_rights_found),
            'consumer_rights': consumer_rights_found[:10],
            'has_right_to_know': has_right_to_know,
            'has_right_to_delete': has_right_to_delete,
            'has_right_to_opt_out': has_right_to_opt_out,
            'policy_length': len(content),
        }

    async def _create_violation_result(
        self,
        page: Page,
        reason: str,
        details: Dict
    ) -> ComplianceCheckResult:
        """Create violation result with evidence."""

        evidence_map = {
            "no_privacy_policy": (
                "No privacy policy found. California Civil Code § 1798.130(a)(5) requires businesses "
                "to include specific disclosures in their privacy policy for California consumers."
            ),
            "privacy_policy_inaccessible": (
                f"Privacy policy not accessible. Error: {details.get('error', 'Unknown')}. "
                "CCPA disclosures must be easily accessible to California consumers."
            ),
            "insufficient_ccpa_disclosures": (
                "Privacy policy found but CCPA-required disclosures are insufficient.\n\n"
                "Violations found:\n"
                + "\n".join(f"  - {v}" for v in details.get('violations', []))
                + "\n\nCalifornia Civil Code § 1798.130(a)(5) requires:\n"
                "  - Categories of personal information collected\n"
                "  - Business or commercial purposes for collection\n"
                "  - Categories of third parties with whom information is shared\n"
                "  - California consumer rights (Know, Delete, Opt-Out, Non-Discrimination)\n"
                "  - How to exercise these rights"
            ),
        }

        evidence = evidence_map.get(reason, f"CCPA privacy policy disclosure violation: {reason}")

        screenshot_path = await self.take_screenshot(page, "ccpa_003_disclosure_violation")

        metadata = {
            'privacy_policy_url': self.privacy_policy_url,
            'violation_reason': reason,
        }

        if reason == "insufficient_ccpa_disclosures":
            metadata.update({
                'has_ccpa_section': details.get('has_ccpa_section', False),
                'has_categories': details.get('has_categories', False),
                'has_purposes': details.get('has_purposes', False),
                'has_third_party': details.get('has_third_party', False),
                'has_consumer_rights': details.get('has_consumer_rights', False),
                'violations': details.get('violations', []),
            })

        return ComplianceCheckResult(
            regulation_id="CCPA",
            requirement_id="CCPA_003",
            status="failed",
            severity="high",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata=metadata,
            legal_risk=(
                "High-severity CCPA violation (California Civil Code § 1798.130(a)(5): Privacy Policy Requirements). "
                "Businesses must provide specific disclosures about data collection, use, and sharing practices. "
                "Privacy policy must inform California consumers of their rights under CCPA/CPRA. "
                "Penalties: Up to $2,500 per violation, $7,500 per intentional violation. "
                "CPRA (2023): Enhanced enforcement by California Privacy Protection Agency. "
                "Inadequate privacy policy disclosures may result in regulatory action and consumer complaints."
            )
        )

    async def _create_compliant_result(self, analysis: Dict) -> ComplianceCheckResult:
        """Create compliant result."""

        evidence = (
            f"Privacy policy contains adequate CCPA disclosures.\n"
            f"  - CCPA-specific section: {'Yes' if analysis['has_ccpa_section'] else 'No'}\n"
            f"  - CCPA sections found: {analysis['ccpa_sections_count']}\n"
            f"  - Categories of personal information: {'Yes' if analysis['has_categories'] else 'No'} ({analysis['categories_count']} keywords)\n"
            f"  - Business purposes disclosed: {'Yes' if analysis['has_purposes'] else 'No'} ({analysis['purposes_count']} keywords)\n"
            f"  - Third-party sharing disclosed: {'Yes' if analysis['has_third_party'] else 'No'} ({analysis['third_party_count']} keywords)\n"
            f"  - Consumer rights disclosed: {'Yes' if analysis['has_consumer_rights'] else 'No'} ({analysis['consumer_rights_count']} keywords)\n"
            f"  - Right to Know: {'Yes' if analysis['has_right_to_know'] else 'No'}\n"
            f"  - Right to Delete: {'Yes' if analysis['has_right_to_delete'] else 'No'}\n"
            f"  - Right to Opt-Out: {'Yes' if analysis['has_right_to_opt_out'] else 'No'}\n"
            f"  - Policy length: {analysis['policy_length']} characters\n\n"
            f"Note: Manual review recommended to verify:\n"
            f"  - All categories of PI actually collected are listed\n"
            f"  - Business purposes are specific (not vague)\n"
            f"  - Third-party categories are complete\n"
            f"  - Rights descriptions include how to exercise them"
        )

        return ComplianceCheckResult(
            regulation_id="CCPA",
            requirement_id="CCPA_003",
            status="passed",
            severity="high",
            evidence=evidence,
            metadata={
                'privacy_policy_url': self.privacy_policy_url,
                'has_ccpa_section': analysis['has_ccpa_section'],
                'ccpa_sections_count': analysis['ccpa_sections_count'],
                'has_categories': analysis['has_categories'],
                'categories_count': analysis['categories_count'],
                'has_purposes': analysis['has_purposes'],
                'purposes_count': analysis['purposes_count'],
                'has_third_party': analysis['has_third_party'],
                'third_party_count': analysis['third_party_count'],
                'has_consumer_rights': analysis['has_consumer_rights'],
                'consumer_rights_count': analysis['consumer_rights_count'],
                'has_right_to_know': analysis['has_right_to_know'],
                'has_right_to_delete': analysis['has_right_to_delete'],
                'has_right_to_opt_out': analysis['has_right_to_opt_out'],
            }
        )
