"""
CCPA Do Not Sell My Personal Information Link Check

Tests that websites provide a clear "Do Not Sell My Personal Information" link,
as required by California Consumer Privacy Act (CCPA).

CCPA Section 1798.135: Right to opt-out of sale of personal information
CCPA Section 1798.120: Consumers' right to opt-out
CPRA (2023): Enhanced enforcement and penalties

Regulation: CCPA/CPRA (California)
Requirement: CCPA_001 - Do Not Sell My Personal Information Link
Severity: Critical
Automation: 100% automated
"""

from playwright.async_api import Page, Locator
from typing import Optional, Dict, List
import logging
import re

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="CCPA", requirement_id="CCPA_001")
class DoNotSellLinkCheck(ComplianceCheck):
    """
    CCPA_001: "Do Not Sell My Personal Information" link must be provided.

    This check verifies that websites provide a clear, conspicuous link for
    California consumers to opt-out of the sale of their personal information,
    as required by CCPA Section 1798.135.

    Methodology:
    1. Search for "Do Not Sell" link on main page
    2. Check homepage, footer, header, privacy sections
    3. Verify link is visible and accessible
    4. Check for CCPA-compliant terminology
    5. Verify link is not buried (easily accessible)

    Common violations:
    - No "Do Not Sell" link present
    - Link buried in privacy policy (not on homepage)
    - Incorrect terminology (e.g., "opt out" without "sell")
    - Link not visible or hidden
    - Link only appears for California IPs (geofencing)

    Legal risk: Up to $7,500 per intentional violation (CCPA Section 1798.155)
    CPRA (2023): Enforcement by California Privacy Protection Agency
    """

    automation_level = "automated"
    severity = "critical"

    # CCPA-compliant "Do Not Sell" link patterns
    DO_NOT_SELL_PATTERNS = [
        # Standard CCPA terminology
        "do not sell my personal information",
        "do not sell my info",
        "do not sell my data",
        "do not sell or share my personal information",  # CPRA update
        "do not sell or share my info",

        # Acceptable variations
        "do not sell",
        "don't sell my personal information",
        "don't sell my info",
        "opt out of sale",
        "opt-out of sale",

        # With "my" variations
        "do not sell personal information",
        "your privacy choices",  # Common alternative with CCPA compliance
    ]

    # Common locations to search
    SEARCH_LOCATIONS = [
        "footer",
        "header",
        "navigation",
        "nav",
        "privacy",
    ]

    def __init__(self, regulation_id: str = "CCPA", requirement_id: str = "CCPA_001"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.do_not_sell_link_found = False
        self.link_text = None
        self.link_location = None

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the Do Not Sell link check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting CCPA_001 check for {url}")

            # Navigate to page if needed
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            # Wait for page to settle
            await page.wait_for_timeout(2000)

            # Step 1: Search for "Do Not Sell" link
            link_result = await self._find_do_not_sell_link(page)

            if link_result['found']:
                self.do_not_sell_link_found = True
                self.link_text = link_result['text']
                self.link_location = link_result['location']
                return await self._create_compliant_result(link_result)
            else:
                return await self._create_violation_result(page)

        except Exception as e:
            logger.error(f"Error in CCPA_001 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="CCPA",
                requirement_id="CCPA_001",
                status="error",
                severity="critical",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _find_do_not_sell_link(self, page: Page) -> Dict:
        """
        Find "Do Not Sell" link on the page.

        Args:
            page: Playwright page object

        Returns:
            Dictionary with findings
        """
        # Try to find link using role-based selectors
        for pattern in self.DO_NOT_SELL_PATTERNS:
            try:
                # Try as link
                link = page.get_by_role("link", name=re.compile(pattern, re.IGNORECASE)).first
                if await link.count() > 0:
                    is_visible = await link.is_visible()
                    if is_visible:
                        text = await link.inner_text()
                        logger.debug(f"Found Do Not Sell link: {text}")

                        # Try to determine location
                        location = await self._determine_link_location(link)

                        return {
                            'found': True,
                            'text': text.strip(),
                            'pattern_matched': pattern,
                            'location': location,
                            'visible': True
                        }

                # Try as button
                button = page.get_by_role("button", name=re.compile(pattern, re.IGNORECASE)).first
                if await button.count() > 0:
                    is_visible = await button.is_visible()
                    if is_visible:
                        text = await button.inner_text()
                        logger.debug(f"Found Do Not Sell button: {text}")

                        location = await self._determine_link_location(button)

                        return {
                            'found': True,
                            'text': text.strip(),
                            'pattern_matched': pattern,
                            'location': location,
                            'visible': True
                        }

            except Exception as e:
                logger.debug(f"Error searching for pattern '{pattern}': {e}")

        # Fallback: Search all links for "do not sell" text
        try:
            all_links = await page.query_selector_all("a, button")
            for link_elem in all_links:
                try:
                    text = await link_elem.inner_text()
                    text_lower = text.lower().strip()

                    if any(pattern.lower() in text_lower for pattern in self.DO_NOT_SELL_PATTERNS):
                        is_visible = await link_elem.is_visible()
                        if is_visible:
                            logger.debug(f"Found Do Not Sell link in fallback: {text}")

                            # Create a locator for this element
                            locator = page.locator(f"text={text}").first
                            location = await self._determine_link_location(locator)

                            return {
                                'found': True,
                                'text': text.strip(),
                                'pattern_matched': 'fallback search',
                                'location': location,
                                'visible': True
                            }
                except Exception as e:
                    logger.debug(f"Error checking link element: {e}")
                    continue

        except Exception as e:
            logger.debug(f"Error in fallback search: {e}")

        return {
            'found': False,
            'text': None,
            'pattern_matched': None,
            'location': None,
            'visible': False
        }

    async def _determine_link_location(self, link: Locator) -> str:
        """
        Determine where the link is located (footer, header, etc.).

        Args:
            link: Playwright locator

        Returns:
            Location description
        """
        try:
            # Get parent elements
            parent_html = await link.evaluate('''
                el => {
                    let current = el;
                    let parents = [];
                    for (let i = 0; i < 5; i++) {
                        if (current.parentElement) {
                            current = current.parentElement;
                            const tagName = current.tagName.toLowerCase();
                            const className = current.className || '';
                            const id = current.id || '';
                            parents.push({tag: tagName, class: className, id: id});
                        }
                    }
                    return parents;
                }
            ''')

            # Check parents for common location indicators
            for parent in parent_html:
                tag = parent.get('tag', '').lower()
                class_name = parent.get('class', '').lower()
                id_attr = parent.get('id', '').lower()

                all_text = f"{tag} {class_name} {id_attr}"

                if 'footer' in all_text:
                    return "footer"
                elif 'header' in all_text:
                    return "header"
                elif 'nav' in all_text:
                    return "navigation"
                elif 'privacy' in all_text:
                    return "privacy section"

            return "page body"

        except Exception as e:
            logger.debug(f"Error determining link location: {e}")
            return "unknown location"

    async def _create_compliant_result(self, link_result: Dict) -> ComplianceCheckResult:
        """
        Create a compliant result.

        Args:
            link_result: Results from link search

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            f"'Do Not Sell My Personal Information' link found.\n"
            f"  - Link text: '{link_result['text']}'\n"
            f"  - Location: {link_result['location']}\n"
            f"  - Visible: {link_result['visible']}\n\n"
            f"Note: Manual verification recommended to ensure link is functional and leads to opt-out mechanism."
        )

        return ComplianceCheckResult(
            regulation_id="CCPA",
            requirement_id="CCPA_001",
            status="passed",
            severity="critical",
            evidence=evidence,
            metadata={
                'do_not_sell_link_found': True,
                'link_text': link_result['text'],
                'link_location': link_result['location'],
                'pattern_matched': link_result['pattern_matched'],
                'link_visible': link_result['visible']
            }
        )

    async def _create_violation_result(self, page: Page) -> ComplianceCheckResult:
        """
        Create a violation result.

        Args:
            page: Playwright page object

        Returns:
            ComplianceCheckResult with failed status
        """
        screenshot_path = await self.take_screenshot(page, "ccpa_001_no_do_not_sell_link")

        evidence = (
            "No 'Do Not Sell My Personal Information' link found.\n"
            "CCPA Section 1798.135 requires websites to provide a clear link titled "
            "'Do Not Sell My Personal Information' on their homepage.\n\n"
            "Checked locations:\n"
            "  - Homepage\n"
            "  - Footer\n"
            "  - Header\n"
            "  - Navigation\n\n"
            "Missing:\n"
            "  - 'Do Not Sell My Personal Information' link\n"
            "  - 'Do Not Sell or Share My Personal Information' (CPRA)\n\n"
            "Recommendation: Add a visible 'Do Not Sell My Personal Information' link "
            "in the footer or homepage that allows California consumers to opt-out."
        )

        return ComplianceCheckResult(
            regulation_id="CCPA",
            requirement_id="CCPA_001",
            status="failed",
            severity="critical",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata={
                'do_not_sell_link_found': False,
                'link_text': None,
                'link_location': None,
                'link_visible': False
            },
            legal_risk=(
                "Critical CCPA violation (Section 1798.135: Right to opt-out of sale). "
                "Businesses must provide a clear and conspicuous link titled "
                "'Do Not Sell My Personal Information' on their homepage. "
                "Penalties: Up to $2,500 per violation, $7,500 per intentional violation. "
                "CPRA (2023): Additional enforcement by California Privacy Protection Agency. "
                "Failure to provide opt-out can result in regulatory action and consumer lawsuits."
            )
        )
