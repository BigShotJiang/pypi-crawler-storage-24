"""
CCPA/CPRA (California) Compliance Checks

California Consumer Privacy Act (CCPA) / California Privacy Rights Act (CPRA)
Jurisdiction: California, United States
Enforcement: 2020 onwards (CCPA), 2023 onwards (CPRA)

Checks implemented:
- CCPA_001: Do Not Sell My Personal Information Link
- CCPA_002: Opt-Out Honored
- CCPA_003: Privacy Policy Disclosures
- CCPA_004: Authorized Agent Support
"""

# Import all checks to ensure they're registered
from .do_not_sell_link import DoNotSellLinkCheck
from .opt_out_honored import OptOutHonoredCheck
from .privacy_policy_disclosures import PrivacyPolicyDisclosuresCheck
from .authorized_agent import AuthorizedAgentCheck

__all__ = [
    'DoNotSellLinkCheck',
    'OptOutHonoredCheck',
    'PrivacyPolicyDisclosuresCheck',
    'AuthorizedAgentCheck',
]
