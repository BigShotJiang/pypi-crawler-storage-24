"""
GDPR Cookie Consent Banner Check

Tests that websites display a cookie consent banner before setting non-essential cookies,
as required by GDPR Article 6 (Lawfulness of processing) and Article 7 (Conditions for consent).

GDPR Article 7: Consent must be freely given, specific, informed, and unambiguous
ePrivacy Directive (Cookie Law): Consent required before storing cookies
CJEU Planet49 ruling: Pre-ticked boxes are not valid consent

Regulation: GDPR (EU), ePrivacy Directive
Requirement: GDPR_001 - Cookie Consent Banner
Severity: Critical
Automation: 95% automated (5% requires manual verification of cookie categories)
"""

from playwright.async_api import Page
from typing import Optional, Dict, List
import logging
import re
from bs4 import BeautifulSoup

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="GDPR", requirement_id="GDPR_001")
class CookieConsentBannerCheck(ComplianceCheck):
    """
    GDPR_001: Cookie consent banner must be displayed before non-essential cookies.

    This check verifies that websites display a cookie consent banner and obtain
    user consent before setting non-essential cookies (analytics, advertising, etc.).

    Methodology:
    1. Load page and check for consent banner
    2. Verify banner is visible before user interaction
    3. Check for clear consent options (accept/reject)
    4. Monitor cookies set before consent
    5. Verify banner contains required information

    Common violations:
    - No cookie consent banner
    - Banner appears after cookies are already set
    - Only "Accept" button, no reject/customize option
    - Pre-checked consent boxes
    - Cookies set before user gives consent
    - Unclear or buried reject option

    Legal risk: Up to €20 million or 4% of global turnover (GDPR Article 83)
    Recent enforcement: Google/Facebook fined for invalid consent mechanisms
    """

    automation_level = "automated"
    severity = "critical"

    # Common cookie consent banner patterns
    CONSENT_BANNER_PATTERNS = [
        # Direct cookie consent keywords
        r'cookie\s+consent',
        r'cookie\s+banner',
        r'cookie\s+notice',
        r'cookie\s+policy',
        r'cookie\s+settings',
        r'cookie\s+preferences',
        r'manage\s+cookies',

        # Privacy/consent keywords
        r'privacy\s+consent',
        r'consent\s+management',
        r'privacy\s+settings',
        r'privacy\s+preferences',

        # Common phrases
        r'we\s+use\s+cookies',
        r'this\s+site\s+uses\s+cookies',
        r'accept\s+cookies',
        r'cookie\s+choices',
    ]

    # Common cookie consent tool class/id patterns
    CONSENT_TOOL_SELECTORS = [
        # OneTrust
        '#onetrust-banner-sdk',
        '#onetrust-consent-sdk',
        '.onetrust-banner',

        # Cookiebot
        '#CybotCookiebotDialog',
        '#CookiebotWidget',

        # Cookie Consent (by Silktide)
        '.cc-window',
        '.cc-banner',

        # GDPR Cookie Consent
        '.gdpr-cookie-notice',
        '.gdpr-banner',

        # Osano
        '.osano-cm-window',

        # Termly
        '#termly-code-snippet-support',

        # TrustArc
        '#truste-consent-track',

        # Didomi
        '#didomi-notice',

        # Quantcast
        '#qc-cmp2-ui',

        # Generic patterns
        '[class*="cookie-consent"]',
        '[class*="cookie-banner"]',
        '[id*="cookie-consent"]',
        '[id*="cookie-banner"]',
    ]

    # Non-essential cookie patterns (should NOT be set before consent)
    NON_ESSENTIAL_COOKIE_PATTERNS = [
        '_ga', '_gid', '_gat',  # Google Analytics
        '_fbp', '_fbc',  # Facebook
        'IDE', 'test_cookie',  # DoubleClick
        'fr',  # Facebook tracking
        'anj',  # AppNexus
    ]

    def __init__(self, regulation_id: str = "GDPR", requirement_id: str = "GDPR_001"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.banner_found = False
        self.banner_text = None
        self.banner_selector = None
        self.initial_cookies: List[Dict] = []
        self.non_essential_cookies_before_consent: List[str] = []

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the cookie consent banner check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting GDPR_001 check for {url}")

            # Step 1: Navigate to page
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)

            # Wait briefly for banner to appear
            await page.wait_for_timeout(2000)

            # Step 2: Check for cookie consent banner
            banner_result = await self._find_consent_banner(page)

            # Step 3: Check cookies set before consent
            await self._check_cookies_before_consent(page)

            # Step 4: Analyze results
            violations = []

            if not banner_result['found']:
                violations.append('no_banner')

            if self.non_essential_cookies_before_consent:
                violations.append('cookies_before_consent')

            if violations:
                return await self._create_violation_result(page, violations, banner_result)
            else:
                return await self._create_compliant_result(banner_result)

        except Exception as e:
            logger.error(f"Error in GDPR_001 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="GDPR",
                requirement_id="GDPR_001",
                status="error",
                severity="critical",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _find_consent_banner(self, page: Page) -> Dict:
        """
        Find cookie consent banner on the page.

        Args:
            page: Playwright page object

        Returns:
            Dictionary with banner findings
        """
        # Try common consent tool selectors first
        for selector in self.CONSENT_TOOL_SELECTORS:
            try:
                element = page.locator(selector).first
                if await element.count() > 0:
                    is_visible = await element.is_visible()
                    if is_visible:
                        text = await element.inner_text()
                        logger.debug(f"Found consent banner via selector: {selector}")

                        self.banner_found = True
                        self.banner_text = text[:200]
                        self.banner_selector = selector

                        return {
                            'found': True,
                            'selector': selector,
                            'text': text[:200],
                            'visible': True
                        }
            except Exception as e:
                logger.debug(f"Error checking selector {selector}: {e}")

        # Try finding banner by text content
        try:
            for pattern in self.CONSENT_BANNER_PATTERNS:
                try:
                    # Search for elements containing the pattern
                    elements = await page.get_by_text(re.compile(pattern, re.IGNORECASE)).all()

                    for elem in elements:
                        try:
                            is_visible = await elem.is_visible()
                            if is_visible:
                                text = await elem.inner_text()

                                # Verify it's likely a banner (has some length)
                                if len(text) > 20:
                                    logger.debug(f"Found consent banner via pattern: {pattern}")

                                    self.banner_found = True
                                    self.banner_text = text[:200]
                                    self.banner_selector = f"text pattern: {pattern}"

                                    return {
                                        'found': True,
                                        'selector': f"text:{pattern}",
                                        'text': text[:200],
                                        'visible': True
                                    }
                        except Exception as e:
                            logger.debug(f"Error checking element: {e}")
                            continue

                except Exception as e:
                    logger.debug(f"Error searching for pattern {pattern}: {e}")

        except Exception as e:
            logger.debug(f"Error in text-based banner search: {e}")

        return {
            'found': False,
            'selector': None,
            'text': None,
            'visible': False
        }

    async def _check_cookies_before_consent(self, page: Page):
        """
        Check if non-essential cookies are set before user consent.

        Args:
            page: Playwright page object
        """
        try:
            # Get all cookies
            cookies = await page.context.cookies()
            self.initial_cookies = cookies

            # Check for non-essential cookies
            for cookie in cookies:
                cookie_name = cookie['name']

                # Check if cookie matches non-essential patterns
                for pattern in self.NON_ESSENTIAL_COOKIE_PATTERNS:
                    if pattern.lower() in cookie_name.lower():
                        self.non_essential_cookies_before_consent.append(cookie_name)
                        logger.debug(f"Non-essential cookie found before consent: {cookie_name}")
                        break

        except Exception as e:
            logger.debug(f"Error checking cookies: {e}")

    async def _create_compliant_result(self, banner_result: Dict) -> ComplianceCheckResult:
        """
        Create a compliant result.

        Args:
            banner_result: Results from banner search

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            f"Cookie consent banner detected.\n"
            f"  - Banner found: Yes\n"
            f"  - Banner visible: {banner_result['visible']}\n"
            f"  - Detection method: {banner_result['selector']}\n"
            f"  - Banner preview: \"{banner_result['text'][:100]}...\"\n\n"
            f"  - Total cookies on page load: {len(self.initial_cookies)}\n"
            f"  - Non-essential cookies before consent: {len(self.non_essential_cookies_before_consent)}\n\n"
            f"The site appears to display a cookie consent banner.\n"
            f"Note: Manual verification recommended to ensure:\n"
            f"  - Reject/decline option is available and clear\n"
            f"  - No pre-ticked consent boxes\n"
            f"  - Banner appears BEFORE non-essential cookies are set\n"
            f"  - Cookie categories are properly explained"
        )

        return ComplianceCheckResult(
            regulation_id="GDPR",
            requirement_id="GDPR_001",
            status="passed",
            severity="critical",
            evidence=evidence,
            metadata={
                'banner_found': True,
                'banner_selector': banner_result['selector'],
                'banner_visible': banner_result['visible'],
                'total_cookies': len(self.initial_cookies),
                'non_essential_cookies_before_consent': len(self.non_essential_cookies_before_consent)
            }
        )

    async def _create_violation_result(
        self,
        page: Page,
        violations: List[str],
        banner_result: Dict
    ) -> ComplianceCheckResult:
        """
        Create a violation result.

        Args:
            page: Playwright page object
            violations: List of violation types
            banner_result: Results from banner search

        Returns:
            ComplianceCheckResult with failed status
        """
        evidence_parts = []

        evidence_parts.append("Cookie consent violations detected.\n")

        if 'no_banner' in violations:
            evidence_parts.append(
                "\n❌ No cookie consent banner found.\n"
                "GDPR requires websites to obtain consent before setting non-essential cookies.\n"
                "A clear, visible cookie consent banner must be displayed to users."
            )

        if 'cookies_before_consent' in violations:
            evidence_parts.append(
                f"\n❌ Non-essential cookies set before consent: {len(self.non_essential_cookies_before_consent)}\n"
                f"The following tracking cookies were detected before user gave consent:"
            )
            for cookie_name in self.non_essential_cookies_before_consent[:10]:
                evidence_parts.append(f"  - {cookie_name}")

            if len(self.non_essential_cookies_before_consent) > 10:
                evidence_parts.append(f"  ... and {len(self.non_essential_cookies_before_consent) - 10} more")

        evidence_parts.append(
            "\n\nGDPR Article 7 requirements for valid consent:\n"
            "  ✓ Freely given (no pre-ticked boxes)\n"
            "  ✓ Specific (clear about what user consents to)\n"
            "  ✓ Informed (explains what cookies are used for)\n"
            "  ✓ Unambiguous (clear affirmative action required)\n\n"
            "ePrivacy Directive (Cookie Law):\n"
            "  ✓ Consent must be obtained BEFORE storing cookies\n"
            "  ✓ Essential cookies only exception (session, security)\n\n"
            "Recommendation:\n"
            "  - Display cookie consent banner on first page load\n"
            "  - Provide clear Accept and Reject options\n"
            "  - Do NOT set non-essential cookies until user consents\n"
            "  - Use cookie consent management platform (OneTrust, Cookiebot, etc.)\n"
            "  - Ensure reject option is equally prominent as accept"
        )

        evidence = "\n".join(evidence_parts)

        screenshot_path = await self.take_screenshot(page, "gdpr_001_cookie_consent_violation")

        return ComplianceCheckResult(
            regulation_id="GDPR",
            requirement_id="GDPR_001",
            status="failed",
            severity="critical",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata={
                'banner_found': banner_result['found'],
                'banner_selector': banner_result.get('selector'),
                'banner_visible': banner_result.get('visible', False),
                'total_cookies': len(self.initial_cookies),
                'non_essential_cookies_before_consent': len(self.non_essential_cookies_before_consent),
                'non_essential_cookie_names': self.non_essential_cookies_before_consent[:20],
                'violations': violations
            },
            legal_risk=(
                "Critical GDPR violation (Article 6: Lawfulness of processing, Article 7: Conditions for consent). "
                "The ePrivacy Directive (Cookie Law) requires consent before storing non-essential cookies. "
                "CJEU Planet49 ruling: Pre-ticked consent boxes are invalid. "
                "Penalties: Up to €20 million or 4% of global annual turnover, whichever is higher (Article 83). "
                "Recent enforcement: Google fined €90M (France, 2020), Amazon fined €746M (Luxembourg, 2021) "
                "for invalid consent mechanisms. "
                "Failure to obtain valid consent before setting cookies can result in significant fines, "
                "regulatory action, and reputational damage."
            )
        )

    async def execute_from_journey(self, step, journey_loader) -> ComplianceCheckResult:
        """
        Execute cookie consent banner check from journey files (HTML-based).

        This method analyzes pre-recorded HTML instead of loading a live page,
        enabling offline compliance analysis.

        Note: This method can only check for the presence of the banner in HTML.
        It cannot check if cookies were set before consent (requires live browser).

        Args:
            step: JourneyStep with HTML and screenshot data
            journey_loader: JourneyLoader for accessing related steps

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            # Load HTML from journey
            html = step.load_html()
            url = step.url
            soup = BeautifulSoup(html, 'html.parser')

            logger.info(f"Starting GDPR_001 journey-based check for {url}")

            # Check for cookie consent banner in HTML
            banner_result = self._find_consent_banner_html(soup)

            if banner_result['found']:
                # Banner found in HTML
                evidence = (
                    f"Cookie consent banner detected in HTML.\n"
                    f"  - Banner found: Yes\n"
                    f"  - Detection method: {banner_result['selector']}\n"
                    f"  - Banner preview: \"{banner_result['text'][:100]}...\"\n\n"
                    f"The site appears to display a cookie consent banner.\n\n"
                    f"Note: Journey-based check limitations:\n"
                    f"  - Cannot verify banner visibility (requires live page)\n"
                    f"  - Cannot check cookies set before consent (requires live browser)\n"
                    f"  - Manual verification recommended for full compliance\n\n"
                    f"Recommended manual checks:\n"
                    f"  - Reject/decline option is available and clear\n"
                    f"  - No pre-ticked consent boxes\n"
                    f"  - Banner appears BEFORE non-essential cookies are set\n"
                    f"  - Cookie categories are properly explained"
                )

                return ComplianceCheckResult(
                    regulation_id="GDPR",
                    requirement_id="GDPR_001",
                    status="passed",
                    severity="critical",
                    evidence=evidence,
                    metadata={
                        'banner_found': True,
                        'banner_selector': banner_result['selector'],
                        'banner_text_preview': banner_result['text'][:200],
                        'source': 'journey_file',
                        'limitations': 'Cannot verify cookies or banner visibility'
                    }
                )
            else:
                # No banner found in HTML
                evidence = (
                    "❌ No cookie consent banner found in HTML.\n\n"
                    "GDPR requires websites to obtain consent before setting non-essential cookies.\n"
                    "A clear, visible cookie consent banner must be displayed to users.\n\n"
                    "Note: Journey-based check limitations:\n"
                    f"  - Banner may be loaded dynamically via JavaScript after page load\n"
                    f"  - Recommend live page test for definitive result\n\n"
                    "GDPR Article 7 requirements for valid consent:\n"
                    "  ✓ Freely given (no pre-ticked boxes)\n"
                    "  ✓ Specific (clear about what user consents to)\n"
                    "  ✓ Informed (explains what cookies are used for)\n"
                    "  ✓ Unambiguous (clear affirmative action required)\n\n"
                    "ePrivacy Directive (Cookie Law):\n"
                    "  ✓ Consent must be obtained BEFORE storing cookies\n"
                    "  ✓ Essential cookies only exception (session, security)\n\n"
                    "Recommendation:\n"
                    "  - Display cookie consent banner on first page load\n"
                    "  - Provide clear Accept and Reject options\n"
                    "  - Do NOT set non-essential cookies until user consents\n"
                    "  - Use cookie consent management platform (OneTrust, Cookiebot, etc.)\n"
                    "  - Ensure reject option is equally prominent as accept"
                )

                return ComplianceCheckResult(
                    regulation_id="GDPR",
                    requirement_id="GDPR_001",
                    status="failed",
                    severity="critical",
                    evidence=evidence,
                    screenshot_path=str(step.screenshot_path) if step.screenshot_path.exists() else None,
                    metadata={
                        'banner_found': False,
                        'source': 'journey_file',
                        'limitations': 'Cannot verify cookies or dynamic content'
                    },
                    legal_risk=(
                        "Critical GDPR violation (Article 6: Lawfulness of processing, Article 7: Conditions for consent). "
                        "The ePrivacy Directive (Cookie Law) requires consent before storing non-essential cookies. "
                        "Penalties: Up to €20 million or 4% of global annual turnover, whichever is higher (Article 83)."
                    )
                )

        except Exception as e:
            logger.error(f"Error in GDPR_001 journey-based check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="GDPR",
                requirement_id="GDPR_001",
                status="error",
                severity="critical",
                error_message=str(e),
                evidence=f"Journey-based check execution failed: {e}"
            )

    def _find_consent_banner_html(self, soup: BeautifulSoup) -> Dict:
        """
        Find cookie consent banner in HTML (BeautifulSoup-based).

        Args:
            soup: BeautifulSoup parsed HTML

        Returns:
            Dictionary with banner findings
        """
        # Try common consent tool selectors first
        for selector in self.CONSENT_TOOL_SELECTORS:
            try:
                # Convert Playwright selector to BeautifulSoup
                if selector.startswith('#'):
                    # ID selector
                    element = soup.find(id=selector[1:])
                elif selector.startswith('.'):
                    # Class selector
                    class_name = selector[1:]
                    element = soup.find(class_=class_name)
                elif selector.startswith('['):
                    # Attribute selector like [class*="cookie-consent"]
                    if 'class*=' in selector:
                        # Extract pattern from [class*="pattern"]
                        pattern = selector.split('"')[1]
                        element = soup.find(lambda tag: tag.get('class') and any(pattern in str(c) for c in tag.get('class', [])))
                    elif 'id*=' in selector:
                        pattern = selector.split('"')[1]
                        element = soup.find(lambda tag: tag.get('id') and pattern in tag.get('id', ''))
                    else:
                        element = None
                else:
                    element = None

                if element:
                    text = element.get_text()
                    if text and len(text) > 20:
                        logger.debug(f"Found consent banner via selector: {selector}")
                        return {
                            'found': True,
                            'selector': selector,
                            'text': text[:200],
                            'visible': True  # Assume visible if in HTML
                        }

            except Exception as e:
                logger.debug(f"Error checking selector {selector}: {e}")

        # Try finding banner by text content
        for pattern in self.CONSENT_BANNER_PATTERNS:
            try:
                # Search for elements containing the pattern
                regex = re.compile(pattern, re.IGNORECASE)
                elements = soup.find_all(string=regex)

                for elem in elements:
                    parent = elem.parent
                    if parent:
                        text = parent.get_text()
                        # Verify it's likely a banner (has some length)
                        if len(text) > 20:
                            logger.debug(f"Found consent banner via pattern: {pattern}")
                            return {
                                'found': True,
                                'selector': f"text pattern: {pattern}",
                                'text': text[:200],
                                'visible': True
                            }

            except Exception as e:
                logger.debug(f"Error searching for pattern {pattern}: {e}")

        return {
            'found': False,
            'selector': None,
            'text': None,
            'visible': False
        }
