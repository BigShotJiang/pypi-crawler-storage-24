"""
GDPR Consent Withdrawal Check

Tests that users can withdraw consent as easily as they gave it, and that withdrawal
options are clearly available without requiring account deletion.

GDPR Article 7(3): The data subject shall have the right to withdraw his or her consent at any time.
The withdrawal of consent shall not affect the lawfulness of processing based on consent before its withdrawal.
It shall be as easy to withdraw consent as to give consent.

Regulation: GDPR (EU General Data Protection Regulation)
Requirement: GDPR_006 - Consent Withdrawal Mechanism
Severity: Critical
Automation: 85% automated (can detect withdrawal options, manual verification needed for full flow)
"""

from playwright.async_api import Page, Locator
from typing import Optional, Dict, List
import logging
import re

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="GDPR", requirement_id="GDPR_006")
class ConsentWithdrawalCheck(ComplianceCheck):
    """
    GDPR_006: Consent withdrawal must be as easy as giving consent.

    This check verifies that websites provide clear, accessible mechanisms for users
    to withdraw consent, and that withdrawal is as easy as the initial consent grant.

    Methodology:
    1. Check for cookie consent withdrawal options (cookie settings, preferences)
    2. Verify withdrawal doesn't require account deletion
    3. Check for withdrawal options in privacy center or account settings
    4. Verify withdrawal is accessible with similar effort to consent grant
    5. Check for clear "Manage Cookies" or similar links

    Common violations:
    - No way to withdraw cookie consent after accepting
    - Withdrawal requires account deletion
    - Withdrawal buried in complex menus
    - Withdrawal requires more clicks than giving consent
    - No cookie preference center
    - Must contact company to withdraw consent

    Legal risk: Up to €20 million or 4% of global turnover (GDPR Article 83)
    Recent enforcement: €10M fine (Italy, 2023) for making consent withdrawal difficult
    """

    automation_level = "semi-automated"
    severity = "critical"

    # Cookie settings/withdrawal link patterns
    WITHDRAWAL_LINK_PATTERNS = [
        # Cookie management
        r'cookie\s+(settings|preferences|choices)',
        r'manage\s+cookies',
        r'cookie\s+consent\s+settings',
        r'update\s+cookie\s+preferences',
        r'change\s+cookie\s+settings',

        # Privacy settings
        r'privacy\s+(settings|preferences|center|centre)',
        r'manage\s+privacy',
        r'consent\s+(management|settings|preferences)',
        r'data\s+preferences',

        # Withdrawal language
        r'withdraw\s+consent',
        r'opt.?out',
        r'revoke\s+consent',
    ]

    # Footer and common locations to search
    FOOTER_SELECTORS = [
        'footer',
        '[role="contentinfo"]',
        '#footer',
        '.footer',
    ]

    # Account deletion patterns (should NOT be required for withdrawal)
    ACCOUNT_DELETION_PATTERNS = [
        r'delete\s+(your\s+)?account',
        r'close\s+(your\s+)?account',
        r'remove\s+account',
        r'deactivate\s+account',
    ]

    def __init__(self, regulation_id: str = "GDPR", requirement_id: str = "GDPR_006"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.withdrawal_options_found = []
        self.withdrawal_in_footer = False
        self.requires_account_deletion = False

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the consent withdrawal check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting GDPR_006 check for {url}")

            # Navigate if not already on page
            if page.url != url:
                await page.goto(url, wait_until="domcontentloaded", timeout=30000)

            # Wait for page to load
            await page.wait_for_timeout(2000)

            # Check for withdrawal/preference management options
            await self._check_withdrawal_options(page)

            # Check if cookie banner is present (to see if there's manage/settings button)
            cookie_banner_options = await self._check_cookie_banner_for_settings(page)

            # Analyze results
            if not self.withdrawal_options_found and not cookie_banner_options:
                return await self._create_violation_result(
                    page=page,
                    reason="no_withdrawal_mechanism",
                    details=None
                )

            # Check for problematic patterns (requiring account deletion)
            if self.requires_account_deletion:
                return await self._create_violation_result(
                    page=page,
                    reason="requires_account_deletion",
                    details={'withdrawal_options': self.withdrawal_options_found}
                )

            # Success - withdrawal mechanism available
            return await self._create_compliant_result(cookie_banner_options)

        except Exception as e:
            logger.error(f"Error in GDPR_006 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="GDPR",
                requirement_id="GDPR_006",
                status="error",
                severity="critical",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _check_withdrawal_options(self, page: Page):
        """
        Check for consent withdrawal/cookie management options on the page.

        Args:
            page: Playwright page object
        """
        # Check footer for withdrawal links
        for footer_selector in self.FOOTER_SELECTORS:
            try:
                footer = page.locator(footer_selector).first
                if await footer.count() > 0:
                    footer_text = await footer.inner_text()
                    footer_links = await footer.locator('a').all()

                    for link in footer_links:
                        try:
                            link_text = await link.inner_text()
                            link_text_lower = link_text.lower().strip()
                            href = await link.get_attribute('href')

                            # Check if link matches withdrawal patterns
                            for pattern in self.WITHDRAWAL_LINK_PATTERNS:
                                if re.search(pattern, link_text_lower, re.IGNORECASE):
                                    self.withdrawal_options_found.append({
                                        'text': link_text,
                                        'href': href,
                                        'location': 'footer'
                                    })
                                    self.withdrawal_in_footer = True
                                    logger.debug(f"Found withdrawal link in footer: {link_text}")
                                    break

                        except Exception as e:
                            logger.debug(f"Error checking footer link: {e}")

            except Exception as e:
                logger.debug(f"Error checking footer selector {footer_selector}: {e}")

        # Check entire page for withdrawal links
        try:
            for pattern in self.WITHDRAWAL_LINK_PATTERNS:
                links = await page.get_by_role('link', name=re.compile(pattern, re.IGNORECASE)).all()

                for link in links:
                    try:
                        link_text = await link.inner_text()
                        href = await link.get_attribute('href')

                        # Avoid duplicates
                        if not any(opt['text'] == link_text for opt in self.withdrawal_options_found):
                            self.withdrawal_options_found.append({
                                'text': link_text,
                                'href': href,
                                'location': 'page'
                            })
                            logger.debug(f"Found withdrawal link on page: {link_text}")

                    except Exception as e:
                        logger.debug(f"Error checking link: {e}")

        except Exception as e:
            logger.debug(f"Error searching page for withdrawal links: {e}")

        # Check for account deletion requirement (violation)
        page_text = await page.inner_text('body')
        page_text_lower = page_text.lower()

        for pattern in self.ACCOUNT_DELETION_PATTERNS:
            if re.search(pattern, page_text_lower):
                # Check if this is mentioned in context of consent withdrawal
                if 'consent' in page_text_lower or 'cookie' in page_text_lower:
                    self.requires_account_deletion = True
                    logger.debug("Detected potential account deletion requirement")
                    break

    async def _check_cookie_banner_for_settings(self, page: Page) -> Dict:
        """
        Check if cookie banner has a settings/manage button.

        Args:
            page: Playwright page object

        Returns:
            Dictionary with banner settings findings
        """
        result = {
            'has_settings_button': False,
            'button_text': None
        }

        # Common cookie banner selectors
        banner_selectors = [
            '[role="dialog"]',
            '[role="alertdialog"]',
            '[class*="cookie"]',
            '[id*="cookie"]',
            '[class*="consent"]',
            '[id*="consent"]',
        ]

        for selector in banner_selectors:
            try:
                elements = await page.query_selector_all(selector)
                for element in elements:
                    is_visible = await element.is_visible()
                    if is_visible:
                        text = await element.inner_text()
                        if any(keyword in text.lower() for keyword in ['cookie', 'consent']):
                            # Check for settings/manage button
                            buttons = await element.query_selector_all('button, a[role="button"]')

                            for button in buttons:
                                button_text = await button.inner_text()
                                button_text_lower = button_text.lower().strip()

                                # Check for settings/manage/preferences
                                if any(keyword in button_text_lower for keyword in [
                                    'settings', 'manage', 'preferences', 'customize',
                                    'cookie settings', 'manage cookies', 'cookie preferences'
                                ]):
                                    result['has_settings_button'] = True
                                    result['button_text'] = button_text
                                    logger.debug(f"Found settings button in banner: {button_text}")
                                    return result

            except Exception as e:
                logger.debug(f"Error checking banner selector {selector}: {e}")

        return result

    async def _create_compliant_result(self, cookie_banner_options: Dict) -> ComplianceCheckResult:
        """
        Create a compliant result.

        Args:
            cookie_banner_options: Results from cookie banner check

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = "Consent withdrawal mechanism available.\n\n"

        if self.withdrawal_options_found:
            evidence += f"✓ Withdrawal/preference links found: {len(self.withdrawal_options_found)}\n"
            for option in self.withdrawal_options_found:
                evidence += f"  - \"{option['text']}\" ({option['location']})\n"
            evidence += "\n"

        if cookie_banner_options['has_settings_button']:
            evidence += (
                f"✓ Cookie banner has settings/manage button: \"{cookie_banner_options['button_text']}\"\n\n"
            )

        evidence += (
            f"✓ Withdrawal in footer: {self.withdrawal_in_footer}\n"
            f"✓ Requires account deletion: No\n\n"
            "The site provides mechanisms to withdraw consent or manage cookie preferences.\n\n"
            "Note: Manual verification recommended to ensure:\n"
            "  - Withdrawal process is as easy as giving consent\n"
            "  - Settings are functional and actually update preferences\n"
            "  - Withdrawal is effective immediately\n"
            "  - No dark patterns that discourage withdrawal\n"
            "  - Cookie preferences persist after withdrawal"
        )

        return ComplianceCheckResult(
            regulation_id="GDPR",
            requirement_id="GDPR_006",
            status="passed",
            severity="critical",
            evidence=evidence,
            metadata={
                'withdrawal_options_count': len(self.withdrawal_options_found),
                'withdrawal_options': self.withdrawal_options_found,
                'withdrawal_in_footer': self.withdrawal_in_footer,
                'cookie_banner_has_settings': cookie_banner_options['has_settings_button'],
                'requires_account_deletion': False
            }
        )

    async def _create_violation_result(
        self,
        page: Page,
        reason: str,
        details: Optional[Dict]
    ) -> ComplianceCheckResult:
        """
        Create a violation result.

        Args:
            page: Playwright page object
            reason: Violation reason code
            details: Additional violation details

        Returns:
            ComplianceCheckResult with failed status
        """
        evidence_map = {
            "no_withdrawal_mechanism": (
                "❌ No consent withdrawal mechanism found.\n"
                "GDPR Article 7(3) requires that users can withdraw consent at any time.\n"
                "The site must provide clear options to manage cookie preferences or withdraw consent.\n\n"
                "Expected:\n"
                "  - 'Cookie Settings' or 'Manage Cookies' link in footer\n"
                "  - Settings/Preferences button in cookie banner\n"
                "  - Privacy Center with consent management\n"
                "  - Account settings with privacy/cookie preferences\n\n"
                "None of these options were detected."
            ),
            "requires_account_deletion": (
                "❌ Consent withdrawal appears to require account deletion.\n"
                "GDPR Article 7(3) requires withdrawal to be as easy as giving consent.\n"
                "Users must be able to withdraw cookie consent WITHOUT deleting their account.\n\n"
                f"Found withdrawal options: {len(details['withdrawal_options']) if details else 0}\n"
                "However, evidence suggests account deletion may be required for full withdrawal."
            ),
        }

        evidence = evidence_map.get(
            reason,
            f"Consent withdrawal violation ({reason})"
        )

        evidence += (
            "\n\nGDPR Article 7(3) requirements:\n"
            "  ✓ Users can withdraw consent at any time\n"
            "  ✓ Withdrawal must be as easy as giving consent\n"
            "  ✓ Withdrawal must not affect lawfulness of prior processing\n"
            "  ✓ Users must be informed of right to withdraw\n\n"
            "Best practices:\n"
            "  - Provide 'Cookie Settings' link in footer on all pages\n"
            "  - Include 'Manage Preferences' button in cookie banner\n"
            "  - Allow granular control (accept some cookies, reject others)\n"
            "  - Make withdrawal process symmetric to consent grant\n"
            "  - Do NOT require account deletion to withdraw cookie consent\n"
            "  - Persist user preferences across sessions\n"
            "  - Provide clear UI to review and change consent status\n\n"
            "Recommendation:\n"
            "  - Add 'Cookie Settings' or 'Privacy Preferences' link to footer\n"
            "  - Implement cookie consent management platform (OneTrust, Cookiebot, etc.)\n"
            "  - Ensure withdrawal is one-click from footer link\n"
            "  - Allow users to change consent without re-accepting all cookies"
        )

        screenshot_path = await self.take_screenshot(page, "gdpr_006_consent_withdrawal_violation")

        metadata = {
            'withdrawal_options_count': len(self.withdrawal_options_found),
            'withdrawal_options': self.withdrawal_options_found,
            'withdrawal_in_footer': self.withdrawal_in_footer,
            'requires_account_deletion': self.requires_account_deletion,
            'violation_reason': reason
        }

        if details:
            metadata['details'] = details

        return ComplianceCheckResult(
            regulation_id="GDPR",
            requirement_id="GDPR_006",
            status="failed",
            severity="critical",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata=metadata,
            legal_risk=(
                "Critical GDPR violation (Article 7(3): Right to withdraw consent). "
                "Withdrawal of consent must be as easy as giving it. "
                "Penalties: Up to €20 million or 4% of global annual turnover (Article 83). "
                "Recent enforcement: Italian DPA fined company €10M (2023) for making consent withdrawal difficult. "
                "Failure to provide easy consent withdrawal mechanisms can result in significant fines, "
                "regulatory scrutiny, and user complaints."
            )
        )
