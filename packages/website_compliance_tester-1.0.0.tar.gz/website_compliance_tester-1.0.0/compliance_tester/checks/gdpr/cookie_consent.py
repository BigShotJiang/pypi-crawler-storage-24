"""
GDPR Cookie Consent Check

Tests that no tracking cookies or scripts load before user explicitly consents.

GDPR Article 5(1)(a): Processing shall be lawful, fair and transparent.
GDPR Recital 32: Consent requires affirmative action.

Regulation: GDPR (EU General Data Protection Regulation)
Requirement: GDPR_001 - Cookie Consent Before Tracking
Severity: Critical
Automation: 100% automated
"""

from playwright.async_api import Page, Route, Request
from typing import List, Dict
import logging

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="GDPR", requirement_id="GDPR_001")
class PreConsentTrackingCheck(ComplianceCheck):
    """
    GDPR_001: No tracking cookies/scripts before user consent.

    This check verifies that third-party tracking scripts (Google Analytics,
    Facebook Pixel, etc.) do not load before the user explicitly consents
    via a cookie banner.

    Methodology:
    1. Intercept all network requests before page loads
    2. Navigate to page and wait for modal (but don't interact)
    3. Analyze requests for tracking domains
    4. Check localStorage/sessionStorage for tracking data
    5. Report violation if any tracking detected

    Common violations:
    - Google Analytics loading immediately
    - Facebook Pixel auto-firing
    - Marketing cookies set before consent
    - Third-party ad networks loading

    Legal risk: Up to €20M or 4% of global revenue (GDPR Article 83)
    """

    automation_level = "automated"
    severity = "critical"

    # Known tracking domains and patterns
    TRACKING_DOMAINS = [
        # Google
        'google-analytics.com',
        'googletagmanager.com',
        'doubleclick.net',
        'googlesyndication.com',
        'googleadservices.com',

        # Facebook/Meta
        'facebook.com',
        'facebook.net',
        'connect.facebook.net',

        # Other major trackers
        'hotjar.com',
        'segment.com',
        'segment.io',
        'mixpanel.com',
        'amplitude.com',
        'quantserve.com',
        'scorecardresearch.com',
        'criteo.com',
        'taboola.com',
        'outbrain.com',

        # Ad networks
        'adnxs.com',  # AppNexus
        'pubmatic.com',
        'rubiconproject.com',
        'openx.net',
    ]

    # Storage keys that indicate tracking
    TRACKING_STORAGE_PATTERNS = [
        '_ga',      # Google Analytics
        '_gid',     # Google Analytics
        '_gat',     # Google Analytics
        'gtm',      # Google Tag Manager
        '_fbp',     # Facebook Pixel
        '_fbc',     # Facebook Click ID
        '_hjid',    # Hotjar
        'ajs_',     # Segment
        'mp_',      # Mixpanel
        'amplitude',
        '__qca',    # Quantcast
    ]

    def __init__(self, regulation_id="GDPR", requirement_id="GDPR_001"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.pre_consent_requests: List[Dict] = []
        self.tracking_requests: List[Dict] = []

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the pre-consent tracking check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting GDPR_001 check for {url}")

            # Reset state
            self.pre_consent_requests = []
            self.tracking_requests = []

            # Set up request interception
            await page.route("**/*", self._intercept_request)

            # Navigate to page (this triggers requests)
            logger.debug("Navigating to page...")
            await page.goto(url, wait_until="networkidle", timeout=30000)

            # Wait for cookie banner to appear (but don't interact)
            logger.debug("Waiting for page to settle...")
            await page.wait_for_timeout(2000)

            # Stop intercepting
            await page.unroute("**/*")

            # Analyze intercepted requests for tracking domains
            logger.debug(f"Analyzing {len(self.pre_consent_requests)} requests...")
            self.tracking_requests = [
                req for req in self.pre_consent_requests
                if self._is_tracking_request(req['url'])
            ]

            # Check localStorage and sessionStorage for tracking data
            storage_violations = await self._check_storage(page)

            # Determine result
            if self.tracking_requests or storage_violations:
                return await self._create_failure_result(
                    page=page,
                    tracking_requests=self.tracking_requests,
                    storage_violations=storage_violations
                )
            else:
                return self._create_success_result()

        except Exception as e:
            logger.error(f"Error in GDPR_001 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="GDPR",
                requirement_id="GDPR_001",
                status="error",
                severity="critical",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _intercept_request(self, route: Route):
        """
        Intercept and log all network requests.

        Args:
            route: Playwright route object
        """
        request = route.request

        # Log the request
        self.pre_consent_requests.append({
            'url': request.url,
            'method': request.method,
            'resource_type': request.resource_type,
            'post_data': request.post_data if request.method == 'POST' else None
        })

        # Continue the request (don't block)
        await route.continue_()

    def _is_tracking_request(self, url: str) -> bool:
        """
        Check if a URL is a tracking request.

        Args:
            url: Request URL

        Returns:
            True if URL matches known tracking domains
        """
        url_lower = url.lower()
        return any(domain in url_lower for domain in self.TRACKING_DOMAINS)

    async def _check_storage(self, page: Page) -> List[str]:
        """
        Check localStorage and sessionStorage for tracking data.

        Args:
            page: Playwright page object

        Returns:
            List of storage keys that indicate tracking
        """
        try:
            # Get all storage keys
            local_storage = await page.evaluate("() => Object.keys(localStorage)")
            session_storage = await page.evaluate("() => Object.keys(sessionStorage)")

            all_keys = local_storage + session_storage

            # Find tracking-related keys
            violations = [
                key for key in all_keys
                if any(pattern in key.lower() for pattern in self.TRACKING_STORAGE_PATTERNS)
            ]

            return violations

        except Exception as e:
            logger.warning(f"Could not check storage: {e}")
            return []

    async def _create_failure_result(
        self,
        page: Page,
        tracking_requests: List[Dict],
        storage_violations: List[str]
    ) -> ComplianceCheckResult:
        """
        Create a failure result with detailed evidence.

        Args:
            page: Playwright page object
            tracking_requests: List of tracking requests found
            storage_violations: List of tracking storage keys found

        Returns:
            ComplianceCheckResult with failed status
        """
        # Build evidence text
        evidence_parts = []

        if tracking_requests:
            evidence_parts.append(
                f"Detected {len(tracking_requests)} tracking request(s) before consent:"
            )
            # Show first 5 tracking requests
            for req in tracking_requests[:5]:
                domain = self._extract_domain(req['url'])
                evidence_parts.append(f"  - {domain} ({req['resource_type']})")

            if len(tracking_requests) > 5:
                evidence_parts.append(f"  ... and {len(tracking_requests) - 5} more")

        if storage_violations:
            evidence_parts.append(
                f"\nDetected {len(storage_violations)} tracking storage key(s):"
            )
            for key in storage_violations[:5]:
                evidence_parts.append(f"  - {key}")

        evidence = "\n".join(evidence_parts)

        # Take screenshot for evidence
        screenshot_path = await self.take_screenshot(page, "gdpr_001_tracking_violation")

        # Build metadata
        metadata = {
            'total_requests': len(self.pre_consent_requests),
            'tracking_requests_count': len(tracking_requests),
            'tracking_domains': list(set(
                self._extract_domain(req['url']) for req in tracking_requests
            )),
            'storage_violations': storage_violations,
            'tracking_request_details': [
                {
                    'url': req['url'][:100],  # Truncate long URLs
                    'type': req['resource_type']
                }
                for req in tracking_requests[:10]  # First 10 only
            ]
        }

        return ComplianceCheckResult(
            regulation_id="GDPR",
            requirement_id="GDPR_001",
            status="failed",
            severity="critical",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata=metadata,
            legal_risk=(
                "Critical GDPR violation (Article 5(1)(a), Recital 32). "
                "Fines up to €20 million or 4% of global annual revenue, "
                "whichever is higher. Recent example: Google fined €150M "
                "for similar cookie consent violations."
            )
        )

    def _create_success_result(self) -> ComplianceCheckResult:
        """
        Create a success result.

        Returns:
            ComplianceCheckResult with passed status
        """
        return ComplianceCheckResult(
            regulation_id="GDPR",
            requirement_id="GDPR_001",
            status="passed",
            severity="critical",
            evidence=(
                f"No tracking detected before consent. "
                f"Analyzed {len(self.pre_consent_requests)} requests, "
                f"found 0 tracking requests."
            ),
            metadata={
                'total_requests': len(self.pre_consent_requests),
                'tracking_requests_count': 0,
                'storage_violations': []
            }
        )

    def _extract_domain(self, url: str) -> str:
        """
        Extract domain from URL for reporting.

        Args:
            url: Full URL

        Returns:
            Domain portion of URL
        """
        try:
            from urllib.parse import urlparse
            parsed = urlparse(url)
            return parsed.netloc
        except Exception:
            # Fallback: return first 50 chars
            return url[:50] + "..." if len(url) > 50 else url
