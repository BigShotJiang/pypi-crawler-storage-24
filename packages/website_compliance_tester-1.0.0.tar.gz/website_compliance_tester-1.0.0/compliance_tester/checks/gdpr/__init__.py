"""
GDPR (General Data Protection Regulation) Compliance Checks

General Data Protection Regulation (EU)
Jurisdiction: European Union
Enforcement: May 2018 onwards

Checks implemented:
- GDPR_001: Cookie Consent Banner
- GDPR_002: One-Click Rejection
- GDPR_003: Equal Prominence
- GDPR_004: Privacy Policy Accessibility
- GDPR_005: Privacy Policy Content
- GDPR_006: Consent Withdrawal
- GDPR_007: Data Portability
"""

# Import all checks to ensure they're registered
from .cookie_consent_banner import CookieConsentBannerCheck
from .one_click_rejection import OneClickRejectionCheck
from .consent_prominence import ConsentProminenceCheck
from .privacy_policy_link import PrivacyPolicyLinkCheck
from .privacy_policy_content import PrivacyPolicyContentCheck
from .consent_withdrawal import ConsentWithdrawalCheck
from .data_portability import DataPortabilityCheck

__all__ = [
    'CookieConsentBannerCheck',
    'OneClickRejectionCheck',
    'ConsentProminenceCheck',
    'PrivacyPolicyLinkCheck',
    'PrivacyPolicyContentCheck',
    'ConsentWithdrawalCheck',
    'DataPortabilityCheck',
]
