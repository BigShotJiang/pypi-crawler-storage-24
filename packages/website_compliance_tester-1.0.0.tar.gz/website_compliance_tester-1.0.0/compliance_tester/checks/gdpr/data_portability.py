"""
GDPR Data Portability Check

Tests that users can download their personal data in a machine-readable format
as required by GDPR Article 20 (Right to data portability).

GDPR Article 20: The data subject shall have the right to receive the personal data concerning
him or her in a structured, commonly used and machine-readable format and have the right to
transmit those data to another controller.

Regulation: GDPR (EU General Data Protection Regulation)
Requirement: GDPR_007 - Data Portability
Severity: Medium
Automation: 90% automated (can detect download options, manual verification of format)
"""

from playwright.async_api import Page, Locator
from typing import Optional, Dict, List
import logging
import re

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="GDPR", requirement_id="GDPR_007")
class DataPortabilityCheck(ComplianceCheck):
    """
    GDPR_007: Users must be able to download personal data in machine-readable format.

    This check verifies that websites provide mechanisms for users to download their
    personal data in structured, machine-readable formats (JSON, CSV, XML) as required
    by GDPR Article 20.

    Methodology:
    1. Search for data export/download options in common locations:
       - Account settings/preferences
       - Privacy center/dashboard
       - Profile settings
    2. Check for data portability language
    3. Verify mentions of machine-readable formats (JSON, CSV, XML)
    4. Check for "Download My Data", "Export Data", etc.

    Common violations:
    - No data export option available
    - Export only available via email request (not self-service)
    - Export in non-machine-readable format (PDF only)
    - Export buried in hard-to-find locations
    - No mention of data portability rights
    - Export not available in account settings

    Legal risk: Up to €20 million or 4% of global turnover (GDPR Article 83)
    Recent enforcement: €28M fine (Amazon, 2021) for data portability issues
    """

    automation_level = "automated"
    severity = "medium"

    # Data portability/export link patterns
    DATA_EXPORT_PATTERNS = [
        # Export/download language
        r'download\s+(my\s+|your\s+)?data',
        r'export\s+(my\s+|your\s+)?data',
        r'data\s+(export|download)',
        r'download\s+(my\s+|your\s+)?information',
        r'export\s+(my\s+|your\s+)?information',

        # Portability language
        r'data\s+portability',
        r'right\s+to\s+data\s+portability',
        r'transfer\s+(my\s+|your\s+)?data',
        r'take\s+your\s+data',

        # Generic download/export
        r'download\s+account\s+data',
        r'export\s+account',
        r'get\s+(a\s+)?copy\s+of\s+(my\s+|your\s+)?data',
    ]

    # Machine-readable format keywords
    MACHINE_READABLE_FORMATS = [
        r'\bjson\b',
        r'\bcsv\b',
        r'\bxml\b',
        r'machine.?readable',
        r'structured\s+format',
    ]

    # Settings/account page patterns
    SETTINGS_URL_PATTERNS = [
        r'settings',
        r'account',
        r'profile',
        r'privacy',
        r'preferences',
        r'dashboard',
    ]

    def __init__(self, regulation_id: str = "GDPR", requirement_id: str = "GDPR_007"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.export_options_found = []
        self.mentions_machine_readable = False
        self.in_settings_area = False

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the data portability check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting GDPR_007 check for {url}")

            # Navigate if not already on page
            if page.url != url:
                await page.goto(url, wait_until="domcontentloaded", timeout=30000)

            # Wait for page to load
            await page.wait_for_timeout(2000)

            # Check current page URL to see if we're in settings area
            self.in_settings_area = self._is_settings_page(page.url)

            # Check for data export options
            await self._check_data_export_options(page)

            # Check for machine-readable format mentions
            await self._check_machine_readable_mentions(page)

            # Analyze results
            if not self.export_options_found:
                # Try to navigate to settings/account page if not already there
                if not self.in_settings_area:
                    settings_found = await self._try_navigate_to_settings(page)

                    if settings_found:
                        # Recheck for export options
                        await self._check_data_export_options(page)
                        await self._check_machine_readable_mentions(page)

            # Determine compliance
            if not self.export_options_found:
                return await self._create_violation_result(
                    page=page,
                    reason="no_export_option",
                    details=None
                )

            # Export option found - check if machine-readable format mentioned
            if not self.mentions_machine_readable:
                # Still pass, but note in evidence
                return await self._create_compliant_result(
                    warning="Machine-readable format not explicitly mentioned"
                )

            # Full compliance
            return await self._create_compliant_result()

        except Exception as e:
            logger.error(f"Error in GDPR_007 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="GDPR",
                requirement_id="GDPR_007",
                status="error",
                severity="medium",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    def _is_settings_page(self, url: str) -> bool:
        """Check if current page appears to be settings/account page."""
        url_lower = url.lower()
        return any(re.search(pattern, url_lower) for pattern in self.SETTINGS_URL_PATTERNS)

    async def _check_data_export_options(self, page: Page):
        """
        Check for data export/download options on the page.

        Args:
            page: Playwright page object
        """
        # Search for links/buttons matching export patterns
        for pattern in self.DATA_EXPORT_PATTERNS:
            try:
                # Check links
                links = await page.get_by_role('link', name=re.compile(pattern, re.IGNORECASE)).all()
                for link in links:
                    try:
                        text = await link.inner_text()
                        href = await link.get_attribute('href')

                        # Avoid duplicates
                        if not any(opt['text'] == text for opt in self.export_options_found):
                            self.export_options_found.append({
                                'type': 'link',
                                'text': text.strip(),
                                'href': href
                            })
                            logger.debug(f"Found data export link: {text}")

                    except Exception as e:
                        logger.debug(f"Error checking link: {e}")

                # Check buttons
                buttons = await page.get_by_role('button', name=re.compile(pattern, re.IGNORECASE)).all()
                for button in buttons:
                    try:
                        text = await button.inner_text()

                        # Avoid duplicates
                        if not any(opt['text'] == text for opt in self.export_options_found):
                            self.export_options_found.append({
                                'type': 'button',
                                'text': text.strip(),
                                'href': None
                            })
                            logger.debug(f"Found data export button: {text}")

                    except Exception as e:
                        logger.debug(f"Error checking button: {e}")

            except Exception as e:
                logger.debug(f"Error searching for pattern {pattern}: {e}")

    async def _check_machine_readable_mentions(self, page: Page):
        """
        Check if page mentions machine-readable formats.

        Args:
            page: Playwright page object
        """
        try:
            page_text = await page.inner_text('body')
            page_text_lower = page_text.lower()

            for pattern in self.MACHINE_READABLE_FORMATS:
                if re.search(pattern, page_text_lower, re.IGNORECASE):
                    self.mentions_machine_readable = True
                    logger.debug(f"Found machine-readable format mention: {pattern}")
                    break

        except Exception as e:
            logger.debug(f"Error checking for machine-readable mentions: {e}")

    async def _try_navigate_to_settings(self, page: Page) -> bool:
        """
        Try to find and navigate to settings/account page.

        Args:
            page: Playwright page object

        Returns:
            True if settings page found and navigated to
        """
        # Look for settings/account links
        settings_link_patterns = [
            r'account\s+settings',
            r'settings',
            r'my\s+account',
            r'profile\s+settings',
            r'privacy\s+(settings|center)',
        ]

        for pattern in settings_link_patterns:
            try:
                links = await page.get_by_role('link', name=re.compile(pattern, re.IGNORECASE)).all()

                if links:
                    link = links[0]
                    href = await link.get_attribute('href')

                    if href and not href.startswith('#'):
                        logger.debug(f"Navigating to settings page: {href}")
                        await page.goto(href, wait_until="domcontentloaded", timeout=10000)
                        await page.wait_for_timeout(2000)
                        self.in_settings_area = True
                        return True

            except Exception as e:
                logger.debug(f"Error navigating to settings: {e}")

        return False

    async def _create_compliant_result(
        self,
        warning: Optional[str] = None
    ) -> ComplianceCheckResult:
        """
        Create a compliant result.

        Args:
            warning: Optional warning message

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = "Data portability mechanism available.\n\n"

        evidence += f"✓ Data export options found: {len(self.export_options_found)}\n"
        for option in self.export_options_found:
            evidence += f"  - {option['type'].title()}: \"{option['text']}\""
            if option['href']:
                evidence += f" ({option['href']})"
            evidence += "\n"

        evidence += f"\n✓ Mentions machine-readable format: {self.mentions_machine_readable}\n"
        evidence += f"✓ Found in settings/account area: {self.in_settings_area}\n\n"

        if warning:
            evidence += f"⚠️  {warning}\n\n"

        evidence += (
            "The site provides mechanisms for users to export/download their data.\n\n"
            "Note: Manual verification recommended to ensure:\n"
            "  - Export actually works and provides data\n"
            "  - Format is truly machine-readable (JSON, CSV, XML)\n"
            "  - Export includes all personal data user has provided\n"
            "  - Export is available to all users without barriers\n"
            "  - Export process is straightforward and self-service\n"
            "  - Data is complete and accurate"
        )

        return ComplianceCheckResult(
            regulation_id="GDPR",
            requirement_id="GDPR_007",
            status="passed",
            severity="medium",
            evidence=evidence,
            metadata={
                'export_options_count': len(self.export_options_found),
                'export_options': self.export_options_found,
                'mentions_machine_readable': self.mentions_machine_readable,
                'in_settings_area': self.in_settings_area
            }
        )

    async def _create_violation_result(
        self,
        page: Page,
        reason: str,
        details: Optional[Dict]
    ) -> ComplianceCheckResult:
        """
        Create a violation result.

        Args:
            page: Playwright page object
            reason: Violation reason code
            details: Additional violation details

        Returns:
            ComplianceCheckResult with failed status
        """
        evidence_map = {
            "no_export_option": (
                "❌ No data export/download option found.\n"
                "GDPR Article 20 grants users the right to receive their personal data\n"
                "in a structured, commonly used, and machine-readable format.\n\n"
                f"Checked locations:\n"
                f"  - Current page (Settings area: {self.in_settings_area})\n"
                f"  - Common settings/account pages\n"
                f"  - Privacy center\n\n"
                "No self-service data export option was detected."
            ),
        }

        evidence = evidence_map.get(
            reason,
            f"Data portability violation ({reason})"
        )

        evidence += (
            "\n\nGDPR Article 20 requirements:\n"
            "  ✓ Right to receive personal data in structured, machine-readable format\n"
            "  ✓ Right to transmit data to another controller\n"
            "  ✓ Format must be commonly used (JSON, CSV, XML)\n"
            "  ✓ Must include data provided by user or generated by their activity\n\n"
            "Best practices:\n"
            "  - Provide self-service data export in account settings\n"
            "  - Use common formats: JSON (preferred), CSV, or XML\n"
            "  - Include all personal data: profile, preferences, activity, content\n"
            "  - Make export easily discoverable in settings/privacy section\n"
            "  - Process export request automatically (not manual review)\n"
            "  - Provide clear instructions for data portability\n\n"
            "Common implementations:\n"
            "  - 'Download My Data' button in account settings\n"
            "  - 'Export Data' option in privacy center\n"
            "  - 'Data Portability' section with download link\n"
            "  - Automated export generation (email link when ready)\n\n"
            "Recommendation:\n"
            "  - Add 'Download My Data' or 'Export Data' to account settings\n"
            "  - Provide JSON or CSV format export\n"
            "  - Make process self-service (no manual approval needed)\n"
            "  - Include all user-provided personal data in export\n"
            "  - Document data portability rights in privacy policy"
        )

        screenshot_path = await self.take_screenshot(page, "gdpr_007_data_portability_violation")

        metadata = {
            'export_options_count': len(self.export_options_found),
            'mentions_machine_readable': self.mentions_machine_readable,
            'in_settings_area': self.in_settings_area,
            'violation_reason': reason
        }

        if details:
            metadata['details'] = details

        return ComplianceCheckResult(
            regulation_id="GDPR",
            requirement_id="GDPR_007",
            status="failed",
            severity="medium",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata=metadata,
            legal_risk=(
                "Medium GDPR violation (Article 20: Right to data portability). "
                "Users must be able to receive their personal data in machine-readable format. "
                "Penalties: Up to €20 million or 4% of global annual turnover (Article 83). "
                "Recent enforcement: Amazon fined €28M (Luxembourg, 2021) for data portability issues. "
                "Failure to provide data portability can result in regulatory complaints, "
                "fines, and inability to demonstrate full GDPR compliance."
            )
        )
