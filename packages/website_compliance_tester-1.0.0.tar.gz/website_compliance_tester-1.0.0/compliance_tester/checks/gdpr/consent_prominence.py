"""
GDPR Equal Prominence Check

Tests that Accept and Reject consent buttons have equal visual prominence,
preventing dark patterns that make rejection harder than acceptance.

GDPR Article 7(3): Withdrawal of consent shall be as easy as giving consent.
CJEU C-673/17 (Planet49): Consent must be freely given, not nudged.
2026 Enforcement: Equal visual prominence required (size, color, position).

Regulation: GDPR (EU General Data Protection Regulation)
Requirement: GDPR_003 - Equal Prominence for Consent Buttons
Severity: Critical
Automation: 80% automated (some visual judgment required)
"""

from playwright.async_api import Page, Locator
from typing import Optional, Dict, Tuple, List
import logging
import re

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="GDPR", requirement_id="GDPR_003")
class ConsentProminenceCheck(ComplianceCheck):
    """
    GDPR_003: Accept and Reject buttons must have equal visual prominence.

    This check verifies that cookie consent banners don't use dark patterns
    to make accepting easier than rejecting. Buttons should have similar:
    - Size (width, height, padding)
    - Visual weight (color contrast, boldness)
    - Position (equal hierarchy in layout)

    Methodology:
    1. Detect cookie consent banner/modal
    2. Find Accept and Reject buttons
    3. Compare button dimensions (width, height)
    4. Compare color contrast ratios
    5. Compare font sizes and weights
    6. Check positioning (side-by-side vs prominence)
    7. Calculate overall prominence score

    Common violations:
    - Large "Accept" vs tiny "Reject" button
    - Bright "Accept" vs gray/faded "Reject"
    - "Accept" as button, "Reject" as small text link
    - "Accept" prominently placed, "Reject" hidden in footer

    Legal risk: Up to €20M or 4% of global revenue (GDPR Article 83)
    Recent enforcement: €375K fine (TikTok, 2026) for dark pattern consent
    """

    automation_level = "semi_automated"  # 80% automated
    severity = "critical"

    # Accept button patterns
    ACCEPT_BUTTON_PATTERNS = [
        "accept all",
        "accept all cookies",
        "accept cookies",
        "agree",
        "i agree",
        "ok",
        "continue",
        "allow all",
        "got it",
        # French
        "tout accepter",
        "accepter tout",
        "j'accepte",
        # German
        "alle akzeptieren",
        "akzeptieren",
        # Spanish
        "aceptar todo",
        "aceptar",
        # Italian
        "accetta tutto",
        "accetto",
    ]

    # Reject button patterns (from GDPR_002)
    REJECT_BUTTON_PATTERNS = [
        "reject all",
        "reject all cookies",
        "decline all",
        "refuse all",
        "deny all",
        "no thanks",
        "opt out of all",
        # French
        "tout refuser",
        "refuser tout",
        # German
        "alle ablehnen",
        "ablehnen",
        # Spanish
        "rechazar todo",
        # Italian
        "rifiuta tutto",
        # Dutch
        "alles weigeren",
    ]

    # Thresholds for prominence comparison
    SIZE_DIFFERENCE_THRESHOLD = 1.5  # Accept button can't be >1.5x larger
    CONTRAST_DIFFERENCE_THRESHOLD = 1.3  # Contrast ratio difference limit
    FONT_SIZE_DIFFERENCE_THRESHOLD = 1.3  # Font size difference limit

    def __init__(self, regulation_id: str = "GDPR", requirement_id: str = "GDPR_003"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.banner_found = False
        self.accept_button_found = False
        self.reject_button_found = False

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the equal prominence check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting GDPR_003 check for {url}")

            # Navigate if not already on page
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            # Wait for page to settle and cookie banner to appear
            await page.wait_for_timeout(2000)

            # Look for cookie consent banner
            banner = await self._find_cookie_banner(page)

            if not banner:
                return ComplianceCheckResult(
                    regulation_id="GDPR",
                    requirement_id="GDPR_003",
                    status="neutral",
                    severity="critical",
                    evidence="No cookie consent banner detected. Check may not be applicable.",
                    metadata={'banner_found': False}
                )

            self.banner_found = True
            logger.debug("Cookie banner detected")

            # Find Accept and Reject buttons
            accept_button = await self._find_accept_button(page, banner)
            reject_button = await self._find_reject_button(page, banner)

            if not accept_button:
                return ComplianceCheckResult(
                    regulation_id="GDPR",
                    requirement_id="GDPR_003",
                    status="neutral",
                    severity="critical",
                    evidence="No 'Accept' button found. Cannot compare prominence.",
                    metadata={
                        'banner_found': True,
                        'accept_button_found': False
                    }
                )

            self.accept_button_found = True

            if not reject_button:
                return ComplianceCheckResult(
                    regulation_id="GDPR",
                    requirement_id="GDPR_003",
                    status="neutral",
                    severity="critical",
                    evidence="No 'Reject' button found. This is a GDPR_002 violation, not GDPR_003.",
                    metadata={
                        'banner_found': True,
                        'accept_button_found': True,
                        'reject_button_found': False
                    }
                )

            self.reject_button_found = True

            # Compare button prominence
            result = await self._compare_button_prominence(
                page,
                accept_button,
                reject_button
            )

            return result

        except Exception as e:
            logger.error(f"Error in GDPR_003 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="GDPR",
                requirement_id="GDPR_003",
                status="error",
                severity="critical",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _find_cookie_banner(self, page: Page) -> Optional[Locator]:
        """
        Find the cookie consent banner on the page.

        Args:
            page: Playwright page object

        Returns:
            Locator for the banner, or None if not found
        """
        banner_selectors = [
            '[role="dialog"]',
            '[role="alertdialog"]',
            '#cookie-banner',
            '#cookie-consent',
            '.cookie-banner',
            '.cookie-consent',
            '.cookie-notice',
            '[id*="cookie"]',
            '[class*="cookie"]',
            '[id*="consent"]',
            '[class*="consent"]',
        ]

        for selector in banner_selectors:
            try:
                elements = await page.query_selector_all(selector)
                for element in elements:
                    is_visible = await element.is_visible()
                    if is_visible:
                        text = await element.inner_text()
                        if any(keyword in text.lower() for keyword in ['cookie', 'consent', 'privacy', 'data']):
                            logger.debug(f"Found cookie banner with selector: {selector}")
                            return element
            except Exception as e:
                logger.debug(f"Error checking selector {selector}: {e}")
                continue

        return None

    async def _find_accept_button(self, page: Page, banner: Locator) -> Optional[Locator]:
        """
        Find the Accept button within the banner.

        Args:
            page: Playwright page object
            banner: Cookie banner locator

        Returns:
            Locator for accept button, or None if not found
        """
        try:
            buttons = await banner.locator('button, a[role="button"], [role="button"]').all()

            for button in buttons:
                text = await button.inner_text()
                text_lower = text.lower().strip()

                if any(pattern in text_lower for pattern in self.ACCEPT_BUTTON_PATTERNS):
                    logger.debug(f"Found accept button with text: {text}")
                    return button

        except Exception as e:
            logger.debug(f"Error searching accept button: {e}")

        # Fallback: search entire page
        try:
            for pattern in self.ACCEPT_BUTTON_PATTERNS:
                button = page.get_by_text(pattern, exact=False).first
                if await button.count() > 0:
                    logger.debug(f"Found accept button on page with pattern: {pattern}")
                    return button
        except Exception as e:
            logger.debug(f"Error in fallback search: {e}")

        return None

    async def _find_reject_button(self, page: Page, banner: Locator) -> Optional[Locator]:
        """
        Find the Reject button within the banner.

        Args:
            page: Playwright page object
            banner: Cookie banner locator

        Returns:
            Locator for reject button, or None if not found
        """
        try:
            buttons = await banner.locator('button, a[role="button"], [role="button"]').all()

            for button in buttons:
                text = await button.inner_text()
                text_lower = text.lower().strip()

                if any(pattern in text_lower for pattern in self.REJECT_BUTTON_PATTERNS):
                    logger.debug(f"Found reject button with text: {text}")
                    return button

        except Exception as e:
            logger.debug(f"Error searching reject button: {e}")

        # Fallback: search entire page
        try:
            for pattern in self.REJECT_BUTTON_PATTERNS:
                button = page.get_by_text(pattern, exact=False).first
                if await button.count() > 0:
                    logger.debug(f"Found reject button on page with pattern: {pattern}")
                    return button
        except Exception as e:
            logger.debug(f"Error in fallback search: {e}")

        return None

    async def _compare_button_prominence(
        self,
        page: Page,
        accept_button: Locator,
        reject_button: Locator
    ) -> ComplianceCheckResult:
        """
        Compare visual prominence of Accept vs Reject buttons.

        Args:
            page: Playwright page object
            accept_button: Accept button locator
            reject_button: Reject button locator

        Returns:
            ComplianceCheckResult with comparison details
        """
        try:
            # Get button text for evidence
            accept_text = await accept_button.inner_text()
            reject_text = await reject_button.inner_text()

            # Get button dimensions
            accept_box = await accept_button.bounding_box()
            reject_box = await reject_button.bounding_box()

            if not accept_box or not reject_box:
                return ComplianceCheckResult(
                    regulation_id="GDPR",
                    requirement_id="GDPR_003",
                    status="error",
                    severity="critical",
                    evidence="Could not get button dimensions for comparison."
                )

            # Calculate button areas
            accept_area = accept_box['width'] * accept_box['height']
            reject_area = reject_box['width'] * reject_box['height']

            # Size ratio (larger / smaller)
            size_ratio = max(accept_area, reject_area) / min(accept_area, reject_area)

            # Get computed styles
            accept_styles = await self._get_button_styles(accept_button)
            reject_styles = await self._get_button_styles(reject_button)

            # Compare font sizes
            accept_font_size = self._parse_px_value(accept_styles.get('fontSize', '16px'))
            reject_font_size = self._parse_px_value(reject_styles.get('fontSize', '16px'))
            font_size_ratio = max(accept_font_size, reject_font_size) / min(accept_font_size, reject_font_size)

            # Compare font weights
            accept_font_weight = self._parse_font_weight(accept_styles.get('fontWeight', '400'))
            reject_font_weight = self._parse_font_weight(reject_styles.get('fontWeight', '400'))

            # Calculate color contrast (relative luminance)
            accept_contrast = self._calculate_contrast_score(accept_styles)
            reject_contrast = self._calculate_contrast_score(reject_styles)

            # Check for dark patterns
            violations = []

            # 1. Size disparity
            if accept_area > reject_area * self.SIZE_DIFFERENCE_THRESHOLD:
                violations.append(
                    f"Accept button is {size_ratio:.1f}x larger than Reject button "
                    f"({accept_area:.0f}px² vs {reject_area:.0f}px²)"
                )

            # 2. Font size disparity
            if accept_font_size > reject_font_size * self.FONT_SIZE_DIFFERENCE_THRESHOLD:
                violations.append(
                    f"Accept button font is {font_size_ratio:.1f}x larger "
                    f"({accept_font_size}px vs {reject_font_size}px)"
                )

            # 3. Font weight disparity (Accept bold, Reject normal)
            if accept_font_weight >= 600 and reject_font_weight < 600:
                violations.append(
                    f"Accept button is bold ({accept_font_weight}) while Reject is normal ({reject_font_weight})"
                )

            # 4. Contrast disparity
            contrast_ratio = max(accept_contrast, reject_contrast) / max(min(accept_contrast, reject_contrast), 0.1)
            if contrast_ratio > self.CONTRAST_DIFFERENCE_THRESHOLD:
                violations.append(
                    f"Significant contrast difference: Accept has {contrast_ratio:.1f}x more visual prominence"
                )

            # 5. Accept is button, Reject is link
            accept_tag = await accept_button.evaluate('el => el.tagName.toLowerCase()')
            reject_tag = await reject_button.evaluate('el => el.tagName.toLowerCase()')

            if accept_tag == 'button' and reject_tag == 'a':
                violations.append(
                    "Accept is a <button> while Reject is only a link <a>"
                )

            # Build metadata
            metadata = {
                'banner_found': True,
                'accept_button_found': True,
                'reject_button_found': True,
                'accept_button_text': accept_text,
                'reject_button_text': reject_text,
                'accept_area_px': round(accept_area, 1),
                'reject_area_px': round(reject_area, 1),
                'size_ratio': round(size_ratio, 2),
                'accept_font_size': accept_font_size,
                'reject_font_size': reject_font_size,
                'font_size_ratio': round(font_size_ratio, 2),
                'accept_font_weight': accept_font_weight,
                'reject_font_weight': reject_font_weight,
                'accept_contrast_score': round(accept_contrast, 2),
                'reject_contrast_score': round(reject_contrast, 2),
                'violations_found': len(violations),
                'violations': violations
            }

            # Determine result
            if violations:
                # Take screenshot
                screenshot_path = await self.take_screenshot(page, "gdpr_003_prominence_violation")

                evidence = (
                    f"Dark pattern detected: Accept and Reject buttons have unequal prominence.\n\n"
                    f"Violations found:\n" +
                    "\n".join(f"  - {v}" for v in violations) +
                    f"\n\nButtons: Accept='{accept_text}', Reject='{reject_text}'"
                )

                return ComplianceCheckResult(
                    regulation_id="GDPR",
                    requirement_id="GDPR_003",
                    status="failed",
                    severity="critical",
                    evidence=evidence,
                    screenshot_path=screenshot_path,
                    metadata=metadata,
                    legal_risk=(
                        "Critical GDPR violation (Article 7(3), 2026 enforcement update). "
                        "Consent must be freely given without dark patterns. "
                        "Fines up to €20 million or 4% of global revenue. "
                        "Recent enforcement: TikTok fined €375K for manipulative consent interface."
                    )
                )
            else:
                # Passed - buttons have equal prominence
                evidence = (
                    f"Accept and Reject buttons have equal visual prominence.\n"
                    f"  - Accept: '{accept_text}' ({accept_area:.0f}px², {accept_font_size}px font)\n"
                    f"  - Reject: '{reject_text}' ({reject_area:.0f}px², {reject_font_size}px font)\n"
                    f"  - Size ratio: {size_ratio:.2f}x (threshold: {self.SIZE_DIFFERENCE_THRESHOLD}x)\n"
                    f"  - Font size ratio: {font_size_ratio:.2f}x (threshold: {self.FONT_SIZE_DIFFERENCE_THRESHOLD}x)"
                )

                return ComplianceCheckResult(
                    regulation_id="GDPR",
                    requirement_id="GDPR_003",
                    status="passed",
                    severity="critical",
                    evidence=evidence,
                    metadata=metadata
                )

        except Exception as e:
            logger.error(f"Error comparing button prominence: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="GDPR",
                requirement_id="GDPR_003",
                status="error",
                severity="critical",
                error_message=str(e),
                evidence=f"Error comparing button prominence: {e}"
            )

    async def _get_button_styles(self, button: Locator) -> Dict[str, str]:
        """
        Get computed styles for a button.

        Args:
            button: Button locator

        Returns:
            Dictionary of CSS property values
        """
        try:
            styles = await button.evaluate('''
                el => {
                    const computed = window.getComputedStyle(el);
                    return {
                        fontSize: computed.fontSize,
                        fontWeight: computed.fontWeight,
                        color: computed.color,
                        backgroundColor: computed.backgroundColor,
                        borderColor: computed.borderColor,
                        borderWidth: computed.borderWidth,
                        padding: computed.padding,
                    };
                }
            ''')
            return styles
        except Exception as e:
            logger.debug(f"Error getting button styles: {e}")
            return {}

    def _parse_px_value(self, value: str) -> float:
        """
        Parse pixel value from CSS string.

        Args:
            value: CSS value like "16px"

        Returns:
            Numeric pixel value
        """
        try:
            match = re.search(r'([\d.]+)', value)
            if match:
                return float(match.group(1))
        except Exception:
            pass
        return 16.0  # Default

    def _parse_font_weight(self, value: str) -> int:
        """
        Parse font weight value.

        Args:
            value: Font weight like "400", "bold", "normal"

        Returns:
            Numeric weight value
        """
        weight_map = {
            'normal': 400,
            'bold': 700,
            'lighter': 300,
            'bolder': 600,
        }

        try:
            # Try numeric value first
            return int(value)
        except ValueError:
            # Try keyword
            return weight_map.get(value.lower(), 400)

    def _calculate_contrast_score(self, styles: Dict[str, str]) -> float:
        """
        Calculate a simple contrast score based on color properties.

        This is a simplified version that estimates visual prominence.
        A full WCAG contrast ratio calculation would be more complex.

        Args:
            styles: CSS computed styles

        Returns:
            Contrast score (higher = more prominent)
        """
        try:
            # Parse background and text colors
            bg_color = styles.get('backgroundColor', 'rgb(255, 255, 255)')
            text_color = styles.get('color', 'rgb(0, 0, 0)')

            # Simple luminance estimation from RGB
            bg_luminance = self._estimate_luminance(bg_color)
            text_luminance = self._estimate_luminance(text_color)

            # Contrast score (absolute difference)
            contrast = abs(bg_luminance - text_luminance)

            # Factor in border if present
            border_width = self._parse_px_value(styles.get('borderWidth', '0px'))
            if border_width > 0:
                contrast += 0.2  # Border adds visual prominence

            return contrast

        except Exception as e:
            logger.debug(f"Error calculating contrast: {e}")
            return 0.5  # Neutral default

    def _estimate_luminance(self, rgb_string: str) -> float:
        """
        Estimate relative luminance from RGB color string.

        Args:
            rgb_string: CSS color like "rgb(255, 255, 255)"

        Returns:
            Luminance value 0-1
        """
        try:
            # Extract RGB values
            match = re.search(r'rgb\((\d+),\s*(\d+),\s*(\d+)\)', rgb_string)
            if not match:
                return 0.5

            r, g, b = int(match.group(1)), int(match.group(2)), int(match.group(3))

            # Simple luminance formula (0.299*R + 0.587*G + 0.114*B)
            luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0

            return luminance

        except Exception as e:
            logger.debug(f"Error estimating luminance from {rgb_string}: {e}")
            return 0.5
