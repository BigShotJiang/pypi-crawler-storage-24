"""
GDPR Privacy Policy Accessibility Check

Tests that the Privacy Policy link is accessible in the footer without requiring login,
as required by GDPR Article 13 (Information to be provided) and Article 12 (Transparent information).

GDPR Article 12: Information shall be provided in a concise, transparent, intelligible and easily accessible form.
GDPR Article 13: Data controller must provide information about data processing at the time of collection.

Regulation: GDPR (EU General Data Protection Regulation)
Requirement: GDPR_004 - Privacy Policy Accessibility
Severity: High
Automation: 100% automated
"""

from playwright.async_api import Page, Locator
from typing import Optional, Dict, List
import logging
import re
from bs4 import BeautifulSoup

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="GDPR", requirement_id="GDPR_004")
class PrivacyPolicyLinkCheck(ComplianceCheck):
    """
    GDPR_004: Privacy Policy link must be accessible in footer.

    This check verifies that websites provide clear, accessible links to their
    Privacy Policy in the footer, and that the policy loads without requiring login.

    Methodology:
    1. Check for Privacy Policy link in footer
    2. Verify link text is clear ("Privacy Policy", "Privacy Notice", etc.)
    3. Follow the link and verify it loads successfully
    4. Verify no login required to access policy
    5. Verify policy page loads with content

    Common violations:
    - No Privacy Policy link in footer
    - Link buried in hard-to-find locations
    - Unclear link text ("Legal", "Info", etc.)
    - Policy requires login to access
    - Broken/404 policy links
    - Policy link only in post-login areas

    Legal risk: Up to €20 million or 4% of global turnover (GDPR Article 83)
    Recent enforcement: €50K fine (Austria, 2023) for inaccessible privacy policy
    """

    automation_level = "automated"
    severity = "high"

    # Common privacy policy link text patterns
    PRIVACY_LINK_PATTERNS = [
        # English
        r'privacy\s+policy',
        r'privacy\s+notice',
        r'data\s+privacy',
        r'privacy\s+statement',
        r'privacy',

        # French
        r'politique\s+de\s+confidentialit[eé]',
        r'confidentialit[eé]',

        # German
        r'datenschutz',
        r'datenschutzerklärung',

        # Spanish
        r'pol[íi]tica\s+de\s+privacidad',
        r'privacidad',

        # Italian
        r'informativa\s+sulla\s+privacy',
        r'privacy',

        # Dutch
        r'privacybeleid',
        r'privacyverklaring',
    ]

    # Footer selectors
    FOOTER_SELECTORS = [
        'footer',
        '[role="contentinfo"]',
        '#footer',
        '.footer',
        '[class*="footer"]',
        '[id*="footer"]',
    ]

    def __init__(self, regulation_id: str = "GDPR", requirement_id: str = "GDPR_004"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.footer_found = False
        self.privacy_link_found = False
        self.privacy_link_text = None
        self.privacy_link_url = None
        self.policy_accessible = False

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the privacy policy accessibility check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting GDPR_004 check for {url}")

            # Navigate if not already on page
            if page.url != url:
                await page.goto(url, wait_until="domcontentloaded", timeout=30000)

            # Wait for page to load
            await page.wait_for_timeout(2000)

            # Step 1: Find footer
            footer = await self._find_footer(page)

            if not footer:
                return await self._create_violation_result(
                    page=page,
                    reason="no_footer",
                    details=None
                )

            self.footer_found = True
            logger.debug("Footer found")

            # Step 2: Find Privacy Policy link in footer
            privacy_link = await self._find_privacy_link(page, footer)

            if not privacy_link:
                return await self._create_violation_result(
                    page=page,
                    reason="no_privacy_link",
                    details=None
                )

            self.privacy_link_found = True
            logger.debug(f"Privacy Policy link found: {self.privacy_link_text}")

            # Step 3: Test accessibility of privacy policy
            accessibility_result = await self._test_privacy_policy_accessibility(page, privacy_link)

            if not accessibility_result['accessible']:
                return await self._create_violation_result(
                    page=page,
                    reason="policy_not_accessible",
                    details=accessibility_result
                )

            self.policy_accessible = True

            # Success
            return await self._create_compliant_result(accessibility_result)

        except Exception as e:
            logger.error(f"Error in GDPR_004 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="GDPR",
                requirement_id="GDPR_004",
                status="error",
                severity="high",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _find_footer(self, page: Page) -> Optional[Locator]:
        """
        Find the footer element on the page.

        Args:
            page: Playwright page object

        Returns:
            Locator for footer, or None if not found
        """
        for selector in self.FOOTER_SELECTORS:
            try:
                element = page.locator(selector).first
                if await element.count() > 0:
                    is_visible = await element.is_visible()
                    if is_visible:
                        logger.debug(f"Found footer with selector: {selector}")
                        return element
            except Exception as e:
                logger.debug(f"Error checking footer selector {selector}: {e}")

        return None

    async def _find_privacy_link(self, page: Page, footer: Locator) -> Optional[Locator]:
        """
        Find Privacy Policy link in footer.

        Args:
            page: Playwright page object
            footer: Footer locator

        Returns:
            Locator for privacy link, or None if not found
        """
        # Search for links in footer
        try:
            links = await footer.locator('a').all()

            for link in links:
                try:
                    text = await link.inner_text()
                    text_lower = text.lower().strip()

                    # Check if link text matches privacy policy patterns
                    for pattern in self.PRIVACY_LINK_PATTERNS:
                        if re.search(pattern, text_lower, re.IGNORECASE):
                            # Get href
                            href = await link.get_attribute('href')

                            self.privacy_link_text = text.strip()
                            self.privacy_link_url = href

                            logger.debug(f"Found privacy link: {text} -> {href}")
                            return link

                except Exception as e:
                    logger.debug(f"Error checking link: {e}")

        except Exception as e:
            logger.debug(f"Error searching footer links: {e}")

        # Fallback: search entire page for privacy links
        try:
            for pattern in self.PRIVACY_LINK_PATTERNS:
                # Use regex pattern matching
                links = await page.get_by_role('link', name=re.compile(pattern, re.IGNORECASE)).all()

                for link in links:
                    try:
                        text = await link.inner_text()
                        href = await link.get_attribute('href')

                        self.privacy_link_text = text.strip()
                        self.privacy_link_url = href

                        logger.debug(f"Found privacy link on page: {text} -> {href}")
                        return link

                    except Exception as e:
                        logger.debug(f"Error checking fallback link: {e}")

        except Exception as e:
            logger.debug(f"Error in fallback search: {e}")

        return None

    async def _test_privacy_policy_accessibility(
        self,
        page: Page,
        privacy_link: Locator
    ) -> Dict:
        """
        Test if privacy policy is accessible without login.

        Args:
            page: Playwright page object
            privacy_link: Privacy policy link locator

        Returns:
            Dictionary with accessibility test results
        """
        result = {
            'accessible': False,
            'status_code': None,
            'requires_login': False,
            'content_loaded': False,
            'error': None
        }

        try:
            # Get the href
            href = await privacy_link.get_attribute('href')

            if not href:
                result['error'] = "Link has no href attribute"
                return result

            # Click the link (opens in same context)
            logger.debug(f"Navigating to privacy policy: {href}")

            # Use page.goto for more control
            response = await page.goto(href, wait_until="domcontentloaded", timeout=15000)

            if response:
                result['status_code'] = response.status

                # Check if redirected to login
                current_url = page.url.lower()
                if any(keyword in current_url for keyword in ['login', 'signin', 'sign-in', 'authenticate']):
                    result['requires_login'] = True
                    return result

                # Check for login indicators on page
                page_text = await page.inner_text('body')
                page_text_lower = page_text.lower()

                if any(keyword in page_text_lower for keyword in ['please log in', 'please sign in', 'login required', 'sign in to view']):
                    result['requires_login'] = True
                    return result

                # Check if content loaded (page has substantial text)
                if len(page_text.strip()) > 200:
                    result['content_loaded'] = True
                    result['accessible'] = True
                else:
                    result['error'] = "Policy page loaded but has minimal content"

            else:
                result['error'] = "No response from policy page"

        except Exception as e:
            logger.debug(f"Error testing privacy policy accessibility: {e}")
            result['error'] = str(e)

        return result

    async def _create_compliant_result(self, accessibility_result: Dict) -> ComplianceCheckResult:
        """
        Create a compliant result.

        Args:
            accessibility_result: Results from accessibility test

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            f"Privacy Policy link found and accessible.\n"
            f"  ✓ Footer found: Yes\n"
            f"  ✓ Privacy Policy link found: Yes\n"
            f"  ✓ Link text: \"{self.privacy_link_text}\"\n"
            f"  ✓ Link URL: {self.privacy_link_url}\n"
            f"  ✓ Policy accessible without login: Yes\n"
            f"  ✓ Status code: {accessibility_result.get('status_code', 'N/A')}\n"
            f"  ✓ Content loaded: {accessibility_result.get('content_loaded', False)}\n\n"
            f"The site provides a clear, accessible Privacy Policy link in the footer.\n"
            f"Users can access the privacy information without logging in."
        )

        return ComplianceCheckResult(
            regulation_id="GDPR",
            requirement_id="GDPR_004",
            status="passed",
            severity="high",
            evidence=evidence,
            metadata={
                'footer_found': True,
                'privacy_link_found': True,
                'privacy_link_text': self.privacy_link_text,
                'privacy_link_url': self.privacy_link_url,
                'policy_accessible': True,
                'requires_login': False,
                'status_code': accessibility_result.get('status_code')
            }
        )

    async def _create_violation_result(
        self,
        page: Page,
        reason: str,
        details: Optional[Dict]
    ) -> ComplianceCheckResult:
        """
        Create a violation result.

        Args:
            page: Playwright page object
            reason: Violation reason code
            details: Additional details about the violation

        Returns:
            ComplianceCheckResult with failed status
        """
        evidence_map = {
            "no_footer": (
                "❌ No footer element found on the page.\n"
                "GDPR Article 12 requires privacy information to be easily accessible.\n"
                "Privacy Policy links should be prominently placed in the page footer."
            ),
            "no_privacy_link": (
                "❌ No Privacy Policy link found in footer or on page.\n"
                "GDPR Article 13 requires websites to provide clear information about data processing.\n"
                "A clearly labeled Privacy Policy link must be accessible to all users."
            ),
            "policy_not_accessible": (
                f"❌ Privacy Policy link found but not accessible.\n"
                f"  - Link text: \"{self.privacy_link_text}\"\n"
                f"  - Link URL: {self.privacy_link_url}\n"
                + (f"  - Requires login: {details.get('requires_login', 'Unknown')}\n" if details else "")
                + (f"  - Status code: {details.get('status_code', 'N/A')}\n" if details else "")
                + (f"  - Error: {details.get('error')}\n" if details and details.get('error') else "")
                + "\nGDPR requires privacy information to be accessible without login or barriers."
            )
        }

        evidence = evidence_map.get(reason, f"Privacy Policy accessibility violation ({reason})")

        evidence += (
            "\n\nGDPR Article 12 requirements:\n"
            "  ✓ Information must be provided in an easily accessible form\n"
            "  ✓ Must be concise, transparent, and intelligible\n"
            "  ✓ Must be easily accessible to the data subject\n\n"
            "GDPR Article 13 requirements:\n"
            "  ✓ Information must be provided at the time of data collection\n"
            "  ✓ Data controller identity and contact details must be provided\n"
            "  ✓ Purposes and legal basis of processing must be explained\n\n"
            "Recommendation:\n"
            "  - Place Privacy Policy link in footer on all pages\n"
            "  - Use clear, recognizable link text ('Privacy Policy' or 'Privacy Notice')\n"
            "  - Make policy accessible without login or registration\n"
            "  - Ensure link is visible and easy to find\n"
            "  - Avoid burying link in multi-level navigation"
        )

        screenshot_path = await self.take_screenshot(page, "gdpr_004_privacy_policy_violation")

        metadata = {
            'footer_found': self.footer_found,
            'privacy_link_found': self.privacy_link_found,
            'policy_accessible': self.policy_accessible,
            'violation_reason': reason
        }

        if self.privacy_link_text:
            metadata['privacy_link_text'] = self.privacy_link_text
        if self.privacy_link_url:
            metadata['privacy_link_url'] = self.privacy_link_url
        if details:
            metadata['details'] = details

        return ComplianceCheckResult(
            regulation_id="GDPR",
            requirement_id="GDPR_004",
            status="failed",
            severity="high",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata=metadata,
            legal_risk=(
                "High GDPR violation (Article 12: Transparent information, Article 13: Information to be provided). "
                "Privacy policies must be easily accessible to all users without barriers. "
                "Penalties: Up to €20 million or 4% of global annual turnover (Article 83). "
                "Recent enforcement: Austrian DPA fined company €50K (2023) for inaccessible privacy policy. "
                "Failure to provide accessible privacy information can result in regulatory action, "
                "fines, and loss of user trust."
            )
        )

    async def execute_from_journey(self, step, journey_loader) -> ComplianceCheckResult:
        """
        Execute privacy policy link check from journey files (HTML-based).

        Can detect presence of privacy policy link in footer from HTML,
        but cannot verify the link is clickable or loads properly.

        Args:
            step: JourneyStep with HTML data
            journey_loader: JourneyLoader for accessing related steps

        Returns:
            ComplianceCheckResult with status
        """
        try:
            # Load HTML from journey
            html = step.load_html()
            soup = BeautifulSoup(html, 'html.parser')

            logger.info(f"Starting GDPR_004 journey-based check for {step.url}")

            # Step 1: Find footer
            footer = None
            for selector in ['footer', '[role="contentinfo"]', '#footer', '.footer']:
                if selector.startswith('['):
                    # Attribute selector
                    if 'role=' in selector:
                        footer = soup.find(attrs={'role': 'contentinfo'})
                    break
                elif selector.startswith('#'):
                    footer = soup.find(id=selector[1:])
                elif selector.startswith('.'):
                    footer = soup.find(class_=selector[1:])
                else:
                    footer = soup.find(selector)

                if footer:
                    break

            # Also try finding by class containing 'footer'
            if not footer:
                footer = soup.find(lambda tag: tag.get('class') and any('footer' in str(c).lower() for c in tag.get('class', [])))

            if not footer:
                return ComplianceCheckResult(
                    regulation_id="GDPR",
                    requirement_id="GDPR_004",
                    status="failed",
                    severity="high",
                    evidence=(
                        "❌ No footer element found in HTML.\n"
                        "GDPR Article 12 requires privacy information to be easily accessible.\n"
                        "Privacy Policy links should be prominently placed in the page footer.\n\n"
                        "Note: Journey-based check limitations:\n"
                        "  - Footer may be loaded dynamically via JavaScript\n"
                        "  - Recommend live page test for definitive result"
                    ),
                    metadata={
                        'footer_found': False,
                        'source': 'journey_file',
                        'limitations': 'May miss dynamically loaded footers'
                    },
                    legal_risk=(
                        "High GDPR violation (Article 12: Transparent information, Article 13: Information to be provided)."
                    )
                )

            # Step 2: Find privacy policy link in footer
            privacy_link = None
            link_text = None
            link_href = None

            # Search all links in footer
            for link in footer.find_all('a', href=True):
                text = link.get_text().strip().lower()

                # Check against patterns
                for pattern in self.PRIVACY_LINK_PATTERNS:
                    if re.search(pattern, text, re.IGNORECASE):
                        privacy_link = link
                        link_text = link.get_text().strip()
                        link_href = link.get('href')
                        logger.debug(f"Found privacy link: {link_text} -> {link_href}")
                        break

                if privacy_link:
                    break

            if not privacy_link:
                # Fallback: search entire page
                for link in soup.find_all('a', href=True):
                    text = link.get_text().strip().lower()

                    for pattern in self.PRIVACY_LINK_PATTERNS:
                        if re.search(pattern, text, re.IGNORECASE):
                            privacy_link = link
                            link_text = link.get_text().strip()
                            link_href = link.get('href')
                            logger.debug(f"Found privacy link on page: {link_text} -> {link_href}")
                            break

                    if privacy_link:
                        break

            if not privacy_link:
                return ComplianceCheckResult(
                    regulation_id="GDPR",
                    requirement_id="GDPR_004",
                    status="failed",
                    severity="high",
                    evidence=(
                        "❌ No Privacy Policy link found in footer or on page.\n"
                        "GDPR Article 13 requires websites to provide clear information about data processing.\n"
                        "A clearly labeled Privacy Policy link must be accessible to all users.\n\n"
                        "Note: Journey-based check limitations:\n"
                        "  - Links may be dynamically loaded via JavaScript\n"
                        "  - Searched for common patterns: 'Privacy Policy', 'Privacy Notice', etc.\n"
                        "  - Recommend live page test for definitive result"
                    ),
                    metadata={
                        'footer_found': True,
                        'privacy_link_found': False,
                        'source': 'journey_file',
                        'limitations': 'May miss dynamically loaded links'
                    },
                    legal_risk=(
                        "High GDPR violation (Article 12: Transparent information, Article 13: Information to be provided)."
                    )
                )

            # Success - link found
            return ComplianceCheckResult(
                regulation_id="GDPR",
                requirement_id="GDPR_004",
                status="passed",
                severity="high",
                evidence=(
                    f"Privacy Policy link found in HTML.\n"
                    f"  ✓ Footer found: Yes\n"
                    f"  ✓ Privacy Policy link found: Yes\n"
                    f"  ✓ Link text: \"{link_text}\"\n"
                    f"  ✓ Link URL: {link_href}\n\n"
                    f"Note: Journey-based check limitations:\n"
                    f"  - Cannot verify link is clickable (requires live page)\n"
                    f"  - Cannot verify policy loads without login (requires browser)\n"
                    f"  - Cannot check HTTP status code\n"
                    f"  - Cannot verify policy content quality\n\n"
                    f"Recommendation: Run live page test to verify:\n"
                    f"  - Link is visible and clickable\n"
                    f"  - Policy loads without requiring login\n"
                    f"  - Policy page has substantial content"
                ),
                metadata={
                    'footer_found': True,
                    'privacy_link_found': True,
                    'privacy_link_text': link_text,
                    'privacy_link_url': link_href,
                    'source': 'journey_file',
                    'limitations': 'Cannot verify link accessibility or policy content'
                }
            )

        except Exception as e:
            logger.error(f"Error in GDPR_004 journey-based check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="GDPR",
                requirement_id="GDPR_004",
                status="error",
                severity="high",
                error_message=str(e),
                evidence=f"Journey-based check execution failed: {e}"
            )
