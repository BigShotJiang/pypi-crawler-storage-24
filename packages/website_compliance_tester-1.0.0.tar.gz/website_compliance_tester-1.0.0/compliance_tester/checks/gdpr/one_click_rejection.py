"""
GDPR One-Click Rejection Check

Tests that users can reject all non-essential cookies with a single click,
as required by 2026 GDPR enforcement updates.

GDPR Article 7(3): Withdrawal of consent shall be as easy as giving consent.
CJEU C-673/17 (Planet49): Pre-ticked boxes prohibited, consent must be active.
2026 Enforcement: Reject must be as easy as Accept (one-click requirement).

Regulation: GDPR (EU General Data Protection Regulation)
Requirement: GDPR_002 - One-Click Rejection Required
Severity: Critical
Automation: 100% automated
"""

from playwright.async_api import Page, Locator
from typing import Optional, Dict, List
import logging

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="GDPR", requirement_id="GDPR_002")
class OneClickRejectionCheck(ComplianceCheck):
    """
    GDPR_002: One-click rejection of non-essential cookies must be available.

    This check verifies that cookie consent banners provide a clear, single-click
    option to reject all non-essential cookies, as required by 2026 GDPR enforcement.

    Methodology:
    1. Detect cookie consent banner/modal
    2. Search for "Reject All" or equivalent button
    3. Verify button is visible and clickable (not hidden)
    4. Click the reject button
    5. Verify modal closes
    6. Verify no tracking after rejection (optional validation)

    Common violations:
    - No "Reject All" button (only "Manage Preferences")
    - Reject button hidden in multi-step flow
    - Reject requires multiple clicks
    - Reject button is visually de-emphasized

    Legal risk: Up to €20M or 4% of global revenue (GDPR Article 83)
    Recent enforcement: €632K fine (Honda, 2026) for asymmetric cookie consent
    """

    automation_level = "automated"
    severity = "critical"

    # Common text patterns for reject buttons
    REJECT_BUTTON_PATTERNS = [
        # English
        "reject all",
        "reject all cookies",
        "decline all",
        "decline all cookies",
        "refuse all",
        "refuse all cookies",
        "deny all",
        "no thanks",
        "opt out of all",

        # French (common in EU)
        "tout refuser",
        "refuser tout",
        "refuser tous",

        # German
        "alle ablehnen",
        "ablehnen",

        # Spanish
        "rechazar todo",
        "rechazar todas",

        # Italian
        "rifiuta tutto",
        "rifiuta tutti",

        # Dutch
        "alles weigeren",
        "weiger alles",
    ]

    # Patterns that indicate multi-step flow (violation)
    MULTI_STEP_PATTERNS = [
        "manage preferences",
        "customize",
        "cookie settings",
        "preferences",
        "settings",
        "manage cookies",
        "cookie options",
    ]

    def __init__(self, regulation_id: str = "GDPR", requirement_id: str = "GDPR_002"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.banner_found = False
        self.reject_button_found = False
        self.reject_button_visible = False

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the one-click rejection check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting GDPR_002 check for {url}")

            # Navigate if not already on page
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            # Wait for page to settle and cookie banner to appear
            await page.wait_for_timeout(2000)

            # Look for cookie consent banner
            banner = await self._find_cookie_banner(page)

            if not banner:
                return ComplianceCheckResult(
                    regulation_id="GDPR",
                    requirement_id="GDPR_002",
                    status="neutral",
                    severity="critical",
                    evidence="No cookie consent banner detected. Check may not be applicable.",
                    metadata={'banner_found': False}
                )

            self.banner_found = True
            logger.debug("Cookie banner detected")

            # Search for "Reject All" button
            reject_button = await self._find_reject_button(page, banner)

            if not reject_button:
                # Check if only multi-step options available
                has_multi_step = await self._has_only_multi_step_rejection(page, banner)

                return await self._create_failure_result(
                    page=page,
                    reason="no_reject_button",
                    has_multi_step=has_multi_step
                )

            self.reject_button_found = True
            logger.debug("Reject button found")

            # Verify button is visible (not hidden)
            is_visible = await reject_button.is_visible()

            if not is_visible:
                return await self._create_failure_result(
                    page=page,
                    reason="reject_button_hidden",
                    has_multi_step=False
                )

            self.reject_button_visible = True

            # Test the reject button functionality
            result = await self._test_reject_button(page, reject_button, banner)

            return result

        except Exception as e:
            logger.error(f"Error in GDPR_002 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="GDPR",
                requirement_id="GDPR_002",
                status="error",
                severity="critical",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _find_cookie_banner(self, page: Page) -> Optional[Locator]:
        """
        Find the cookie consent banner on the page.

        Args:
            page: Playwright page object

        Returns:
            Locator for the banner, or None if not found
        """
        # Common selectors for cookie banners
        banner_selectors = [
            '[role="dialog"]',
            '[role="alertdialog"]',
            '#cookie-banner',
            '#cookie-consent',
            '.cookie-banner',
            '.cookie-consent',
            '.cookie-notice',
            '[id*="cookie"]',
            '[class*="cookie"]',
            '[id*="consent"]',
            '[class*="consent"]',
        ]

        for selector in banner_selectors:
            try:
                elements = await page.query_selector_all(selector)
                for element in elements:
                    # Check if element is visible and contains cookie-related text
                    is_visible = await element.is_visible()
                    if is_visible:
                        text = await element.inner_text()
                        if any(keyword in text.lower() for keyword in ['cookie', 'consent', 'privacy', 'data']):
                            logger.debug(f"Found cookie banner with selector: {selector}")
                            return element
            except Exception as e:
                logger.debug(f"Error checking selector {selector}: {e}")
                continue

        return None

    async def _find_reject_button(self, page: Page, banner: Locator) -> Optional[Locator]:
        """
        Find the "Reject All" button within the banner.

        Args:
            page: Playwright page object
            banner: Cookie banner locator

        Returns:
            Locator for reject button, or None if not found
        """
        # Try to find buttons within the banner first
        try:
            buttons = await banner.locator('button, a[role="button"], [role="button"]').all()

            for button in buttons:
                text = await button.inner_text()
                text_lower = text.lower().strip()

                # Check if button text matches any reject pattern
                if any(pattern in text_lower for pattern in self.REJECT_BUTTON_PATTERNS):
                    logger.debug(f"Found reject button with text: {text}")
                    return button

        except Exception as e:
            logger.debug(f"Error searching buttons in banner: {e}")

        # Fallback: search entire page
        try:
            for pattern in self.REJECT_BUTTON_PATTERNS:
                # Try exact text match
                button = page.get_by_text(pattern, exact=False).first
                if await button.count() > 0:
                    logger.debug(f"Found reject button on page with pattern: {pattern}")
                    return button

        except Exception as e:
            logger.debug(f"Error in fallback search: {e}")

        return None

    async def _has_only_multi_step_rejection(self, page: Page, banner: Locator) -> bool:
        """
        Check if only multi-step rejection options are available.

        Args:
            page: Playwright page object
            banner: Cookie banner locator

        Returns:
            True if only multi-step options found (violation)
        """
        try:
            buttons = await banner.locator('button, a[role="button"], [role="button"]').all()

            for button in buttons:
                text = await button.inner_text()
                text_lower = text.lower().strip()

                # Check if button matches multi-step patterns
                if any(pattern in text_lower for pattern in self.MULTI_STEP_PATTERNS):
                    logger.debug(f"Found multi-step button: {text}")
                    return True

        except Exception as e:
            logger.debug(f"Error checking for multi-step options: {e}")

        return False

    async def _test_reject_button(
        self,
        page: Page,
        reject_button: Locator,
        banner: Locator
    ) -> ComplianceCheckResult:
        """
        Test that clicking reject button closes the modal in one click.

        Args:
            page: Playwright page object
            reject_button: Reject button locator
            banner: Cookie banner locator

        Returns:
            ComplianceCheckResult
        """
        try:
            # Get button text for evidence
            button_text = await reject_button.inner_text()

            # Click the reject button
            logger.debug("Clicking reject button...")
            await reject_button.click()

            # Wait for modal to close
            await page.wait_for_timeout(1000)

            # Check if banner is still visible
            banner_still_visible = await banner.is_visible()

            if banner_still_visible:
                # Banner didn't close - might require multiple clicks
                return await self._create_failure_result(
                    page=page,
                    reason="reject_requires_multiple_clicks",
                    button_text=button_text
                )

            # Success - banner closed with one click
            return ComplianceCheckResult(
                regulation_id="GDPR",
                requirement_id="GDPR_002",
                status="passed",
                severity="critical",
                evidence=f"One-click rejection available. Button found: '{button_text}'. Modal closed successfully.",
                metadata={
                    'banner_found': True,
                    'reject_button_found': True,
                    'reject_button_visible': True,
                    'reject_button_text': button_text,
                    'modal_closed': True
                }
            )

        except Exception as e:
            logger.error(f"Error testing reject button: {e}")
            return ComplianceCheckResult(
                regulation_id="GDPR",
                requirement_id="GDPR_002",
                status="error",
                severity="critical",
                error_message=str(e),
                evidence=f"Error testing reject button functionality: {e}"
            )

    async def _create_failure_result(
        self,
        page: Page,
        reason: str,
        has_multi_step: bool = False,
        button_text: Optional[str] = None
    ) -> ComplianceCheckResult:
        """
        Create a failure result with detailed evidence.

        Args:
            page: Playwright page object
            reason: Failure reason code
            has_multi_step: Whether multi-step rejection is available
            button_text: Text of reject button (if found but didn't work)

        Returns:
            ComplianceCheckResult with failed status
        """
        # Build evidence based on reason
        evidence_map = {
            "no_reject_button": (
                "No 'Reject All' button found. "
                + ("Only multi-step rejection available (requires navigating to settings)." if has_multi_step else "")
                + " GDPR requires one-click rejection equal to acceptance."
            ),
            "reject_button_hidden": (
                "Reject button exists but is hidden or not visible. "
                "Users cannot easily find the rejection option."
            ),
            "reject_requires_multiple_clicks": (
                f"Reject button ('{button_text}') found but modal did not close with one click. "
                "May require multi-step process or additional confirmation."
            ),
        }

        evidence = evidence_map.get(
            reason,
            f"One-click rejection not available (reason: {reason})"
        )

        # Take screenshot
        screenshot_path = await self.take_screenshot(page, "gdpr_002_rejection_violation")

        # Build metadata
        metadata = {
            'banner_found': self.banner_found,
            'reject_button_found': self.reject_button_found,
            'reject_button_visible': self.reject_button_visible,
            'has_multi_step_rejection': has_multi_step,
            'failure_reason': reason,
        }

        if button_text:
            metadata['reject_button_text'] = button_text

        return ComplianceCheckResult(
            regulation_id="GDPR",
            requirement_id="GDPR_002",
            status="failed",
            severity="critical",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata=metadata,
            legal_risk=(
                "Critical GDPR violation (Article 7(3), 2026 enforcement update). "
                "Withdrawal of consent must be as easy as giving it. "
                "Fines up to €20 million or 4% of global revenue. "
                "Recent enforcement: Honda fined €632K for asymmetric cookie consent buttons."
            )
        )
