"""
GDPR Privacy Policy Content Check

Tests that the Privacy Policy contains required GDPR disclosures including data controller
identity, processing purposes, legal basis, retention periods, and data subject rights.

GDPR Article 13: Information to be provided where personal data are collected from data subject
GDPR Article 14: Information to be provided where personal data have not been obtained from data subject
GDPR Article 15-22: Data subject rights that must be disclosed

Regulation: GDPR (EU General Data Protection Regulation)
Requirement: GDPR_005 - Privacy Policy Content
Severity: High
Automation: 80% automated (keyword detection, manual review for completeness)
"""

from playwright.async_api import Page
from typing import Dict, List, Set
import logging
import re

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="GDPR", requirement_id="GDPR_005")
class PrivacyPolicyContentCheck(ComplianceCheck):
    """
    GDPR_005: Privacy Policy must contain required GDPR disclosures.

    This check verifies that Privacy Policy pages include all mandatory information
    required by GDPR Articles 13 and 14, including data controller identity, processing
    purposes, legal basis, retention periods, and data subject rights.

    Methodology:
    1. Navigate to Privacy Policy page
    2. Extract full text content
    3. Check for required elements using keyword detection:
       - Data controller identity and contact information
       - Purpose of data processing
       - Legal basis for processing
       - Data retention periods
       - Data subject rights (access, rectification, erasure, etc.)
       - Right to withdraw consent
       - Right to lodge complaint with supervisory authority
    4. Calculate completeness score

    Common violations:
    - No data controller identity or contact info
    - Missing legal basis for processing
    - No retention period information
    - Data subject rights not listed
    - No mention of right to withdraw consent
    - No information about complaint rights

    Legal risk: Up to €20 million or 4% of global turnover (GDPR Article 83)
    Recent enforcement: €225K fine (Norway, 2023) for incomplete privacy policy
    """

    automation_level = "semi-automated"
    severity = "high"

    # Required GDPR disclosures with keyword patterns
    REQUIRED_DISCLOSURES = {
        'data_controller': {
            'keywords': [
                r'data\s+controller',
                r'controller\s+identity',
                r'company\s+name',
                r'registered\s+office',
                r'contact\s+(details|information)',
                r'controller.*contact',
            ],
            'article': 'Article 13(1)(a)',
            'description': 'Data controller identity and contact details'
        },
        'processing_purposes': {
            'keywords': [
                r'purpose(s)?\s+of\s+(the\s+)?processing',
                r'why\s+we\s+(collect|process|use)',
                r'purpose(s)?\s+for\s+which',
                r'we\s+(use|process)\s+your\s+(data|information)\s+(for|to)',
                r'purposes?\s+of\s+(data\s+)?collection',
            ],
            'article': 'Article 13(1)(c)',
            'description': 'Purposes of data processing'
        },
        'legal_basis': {
            'keywords': [
                r'legal\s+(basis|ground)',
                r'lawful\s+basis',
                r'legitimate\s+interest',
                r'(consent|contract|legal\s+obligation).*basis',
                r'legal\s+justification',
            ],
            'article': 'Article 13(1)(c)',
            'description': 'Legal basis for processing'
        },
        'retention_period': {
            'keywords': [
                r'retention\s+period',
                r'how\s+long\s+we\s+(keep|store|retain)',
                r'(data|information)\s+retention',
                r'period\s+for\s+which.*stored',
                r'retention\s+schedule',
                r'(storage|retention)\s+duration',
            ],
            'article': 'Article 13(2)(a)',
            'description': 'Data retention periods'
        },
        'right_to_access': {
            'keywords': [
                r'right\s+to\s+access',
                r'access\s+your\s+(data|information)',
                r'data\s+subject\s+access',
                r'request\s+(a\s+)?copy',
            ],
            'article': 'Article 15',
            'description': 'Right to access personal data'
        },
        'right_to_rectification': {
            'keywords': [
                r'right\s+to\s+(rectification|correct)',
                r'correct\s+your\s+(data|information)',
                r'update\s+(your\s+)?(data|information)',
                r'rectify.*inaccurate',
            ],
            'article': 'Article 16',
            'description': 'Right to rectification'
        },
        'right_to_erasure': {
            'keywords': [
                r'right\s+to\s+(erasure|deletion|be\s+forgotten)',
                r'delete\s+your\s+(data|information)',
                r'right\s+to\s+be\s+forgotten',
                r'erase.*personal\s+data',
            ],
            'article': 'Article 17',
            'description': 'Right to erasure (right to be forgotten)'
        },
        'right_to_data_portability': {
            'keywords': [
                r'(right\s+to\s+)?data\s+portability',
                r'transfer\s+your\s+(data|information)',
                r'receive.*machine.?readable',
                r'export\s+your\s+(data|information)',
            ],
            'article': 'Article 20',
            'description': 'Right to data portability'
        },
        'right_to_withdraw_consent': {
            'keywords': [
                r'(right\s+to\s+)?withdraw\s+consent',
                r'withdraw.*consent.*any\s+time',
                r'revoke.*consent',
                r'opt.?out',
            ],
            'article': 'Article 7(3)',
            'description': 'Right to withdraw consent'
        },
        'right_to_object': {
            'keywords': [
                r'right\s+to\s+object',
                r'object\s+to\s+(the\s+)?processing',
                r'object.*legitimate\s+interest',
            ],
            'article': 'Article 21',
            'description': 'Right to object to processing'
        },
        'right_to_lodge_complaint': {
            'keywords': [
                r'(right\s+to\s+)?lodge.*complaint',
                r'complain\s+to.*(supervisory\s+authority|regulator|DPA)',
                r'file.*complaint.*data\s+protection',
                r'supervisory\s+authority',
                r'data\s+protection\s+authority',
            ],
            'article': 'Article 77',
            'description': 'Right to lodge complaint with supervisory authority'
        }
    }

    # Minimum required disclosures for compliance
    MINIMUM_REQUIRED = [
        'data_controller',
        'processing_purposes',
        'legal_basis',
        'retention_period',
        'right_to_access',
        'right_to_erasure',
        'right_to_withdraw_consent',
        'right_to_lodge_complaint'
    ]

    def __init__(self, regulation_id: str = "GDPR", requirement_id: str = "GDPR_005"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.policy_text = ""
        self.found_disclosures: Set[str] = set()
        self.missing_disclosures: Set[str] = set()

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the privacy policy content check.

        Args:
            page: Playwright page object
            url: URL to test (should be privacy policy page)

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting GDPR_005 check for {url}")

            # Navigate to privacy policy page
            # Assume URL is the privacy policy page, or try to find it
            if not self._is_privacy_policy_url(url):
                # Try to find and navigate to privacy policy
                policy_url = await self._find_privacy_policy_link(page)
                if policy_url:
                    await page.goto(policy_url, wait_until="domcontentloaded", timeout=15000)
                else:
                    return ComplianceCheckResult(
                        regulation_id="GDPR",
                        requirement_id="GDPR_005",
                        status="neutral",
                        severity="high",
                        evidence="Cannot locate Privacy Policy page to analyze content."
                    )
            else:
                # Already on privacy policy page
                if page.url != url:
                    await page.goto(url, wait_until="domcontentloaded", timeout=15000)

            # Wait for content to load
            await page.wait_for_timeout(2000)

            # Extract privacy policy text
            self.policy_text = await self._extract_policy_text(page)

            if len(self.policy_text) < 500:
                return ComplianceCheckResult(
                    regulation_id="GDPR",
                    requirement_id="GDPR_005",
                    status="failed",
                    severity="high",
                    evidence="Privacy Policy page found but contains insufficient content (< 500 characters).",
                    metadata={'policy_text_length': len(self.policy_text)}
                )

            # Check for required disclosures
            await self._check_disclosures()

            # Determine compliance
            missing_required = [
                disclosure for disclosure in self.MINIMUM_REQUIRED
                if disclosure not in self.found_disclosures
            ]

            if missing_required:
                return await self._create_violation_result(page, missing_required)
            else:
                return await self._create_compliant_result()

        except Exception as e:
            logger.error(f"Error in GDPR_005 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="GDPR",
                requirement_id="GDPR_005",
                status="error",
                severity="high",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    def _is_privacy_policy_url(self, url: str) -> bool:
        """Check if URL appears to be a privacy policy page."""
        url_lower = url.lower()
        return any(keyword in url_lower for keyword in [
            'privacy', 'datenschutz', 'confidentialit', 'privacidad'
        ])

    async def _find_privacy_policy_link(self, page: Page) -> str:
        """Try to find privacy policy link on current page."""
        try:
            # Look for privacy policy links
            privacy_patterns = [
                r'privacy\s+policy',
                r'privacy\s+notice',
                r'datenschutz',
            ]

            for pattern in privacy_patterns:
                links = await page.get_by_role('link', name=re.compile(pattern, re.IGNORECASE)).all()
                if links:
                    href = await links[0].get_attribute('href')
                    if href:
                        return href

        except Exception as e:
            logger.debug(f"Error finding privacy policy link: {e}")

        return None

    async def _extract_policy_text(self, page: Page) -> str:
        """Extract text content from privacy policy page."""
        try:
            # Try to find main content area first
            main_selectors = ['main', 'article', '[role="main"]', '#content', '.content']

            for selector in main_selectors:
                try:
                    element = page.locator(selector).first
                    if await element.count() > 0:
                        text = await element.inner_text()
                        if len(text) > 200:
                            return text
                except Exception:
                    continue

            # Fallback to body
            return await page.inner_text('body')

        except Exception as e:
            logger.error(f"Error extracting policy text: {e}")
            return ""

    async def _check_disclosures(self):
        """Check for required disclosures using keyword detection."""
        policy_text_lower = self.policy_text.lower()

        for disclosure_id, disclosure_info in self.REQUIRED_DISCLOSURES.items():
            found = False

            for pattern in disclosure_info['keywords']:
                if re.search(pattern, policy_text_lower, re.IGNORECASE):
                    found = True
                    logger.debug(f"Found disclosure: {disclosure_id} (pattern: {pattern})")
                    break

            if found:
                self.found_disclosures.add(disclosure_id)
            else:
                self.missing_disclosures.add(disclosure_id)

    async def _create_compliant_result(self) -> ComplianceCheckResult:
        """Create a compliant result."""
        total_disclosures = len(self.REQUIRED_DISCLOSURES)
        found_count = len(self.found_disclosures)
        completeness = (found_count / total_disclosures) * 100

        evidence = (
            f"Privacy Policy contains required GDPR disclosures.\n"
            f"  ✓ Completeness: {completeness:.0f}% ({found_count}/{total_disclosures} disclosures found)\n"
            f"  ✓ Policy text length: {len(self.policy_text)} characters\n\n"
            f"Found disclosures:\n"
        )

        for disclosure_id in sorted(self.found_disclosures):
            disclosure_info = self.REQUIRED_DISCLOSURES[disclosure_id]
            evidence += f"  ✓ {disclosure_info['description']} ({disclosure_info['article']})\n"

        if self.missing_disclosures:
            evidence += "\n⚠️  Missing (recommended but not critical):\n"
            for disclosure_id in sorted(self.missing_disclosures):
                disclosure_info = self.REQUIRED_DISCLOSURES[disclosure_id]
                evidence += f"  - {disclosure_info['description']} ({disclosure_info['article']})\n"

        evidence += (
            "\nNote: This is an automated keyword-based check (80% automated).\n"
            "Manual review recommended to verify:\n"
            "  - Completeness and accuracy of each disclosure\n"
            "  - Clear and plain language used\n"
            "  - Contact information is current and valid\n"
            "  - Specific retention periods (not just vague statements)"
        )

        return ComplianceCheckResult(
            regulation_id="GDPR",
            requirement_id="GDPR_005",
            status="passed",
            severity="high",
            evidence=evidence,
            metadata={
                'policy_text_length': len(self.policy_text),
                'total_disclosures': total_disclosures,
                'found_disclosures': list(self.found_disclosures),
                'missing_disclosures': list(self.missing_disclosures),
                'completeness_percentage': completeness
            }
        )

    async def _create_violation_result(
        self,
        page: Page,
        missing_required: List[str]
    ) -> ComplianceCheckResult:
        """Create a violation result."""
        total_disclosures = len(self.REQUIRED_DISCLOSURES)
        found_count = len(self.found_disclosures)
        completeness = (found_count / total_disclosures) * 100

        evidence = (
            f"❌ Privacy Policy missing required GDPR disclosures.\n"
            f"  - Completeness: {completeness:.0f}% ({found_count}/{total_disclosures} disclosures found)\n"
            f"  - Policy text length: {len(self.policy_text)} characters\n\n"
            f"Missing REQUIRED disclosures:\n"
        )

        for disclosure_id in missing_required:
            disclosure_info = self.REQUIRED_DISCLOSURES[disclosure_id]
            evidence += f"  ❌ {disclosure_info['description']} ({disclosure_info['article']})\n"

        if self.found_disclosures:
            evidence += "\n✓ Found disclosures:\n"
            for disclosure_id in sorted(self.found_disclosures):
                disclosure_info = self.REQUIRED_DISCLOSURES[disclosure_id]
                evidence += f"  ✓ {disclosure_info['description']} ({disclosure_info['article']})\n"

        evidence += (
            "\n\nGDPR Article 13 requirements:\n"
            "  ✓ Data controller identity and contact details\n"
            "  ✓ Purposes and legal basis of processing\n"
            "  ✓ Legitimate interests (if applicable)\n"
            "  ✓ Recipients or categories of recipients\n"
            "  ✓ Retention period or criteria\n"
            "  ✓ Data subject rights (access, rectification, erasure, etc.)\n"
            "  ✓ Right to withdraw consent\n"
            "  ✓ Right to lodge complaint with supervisory authority\n\n"
            "Recommendation:\n"
            "  - Include all required disclosures listed above\n"
            "  - Use clear, plain language accessible to all users\n"
            "  - Provide specific retention periods (not 'as long as necessary')\n"
            "  - Include complete contact information for data controller\n"
            "  - List all data subject rights with instructions to exercise them\n"
            "  - Consider using a GDPR privacy policy template\n"
            "  - Review and update policy regularly"
        )

        screenshot_path = await self.take_screenshot(page, "gdpr_005_privacy_policy_content_violation")

        return ComplianceCheckResult(
            regulation_id="GDPR",
            requirement_id="GDPR_005",
            status="failed",
            severity="high",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata={
                'policy_text_length': len(self.policy_text),
                'total_disclosures': total_disclosures,
                'found_disclosures': list(self.found_disclosures),
                'missing_disclosures': list(self.missing_disclosures),
                'missing_required': missing_required,
                'completeness_percentage': completeness
            },
            legal_risk=(
                "High GDPR violation (Article 13: Information to be provided, Article 14: Information requirements). "
                "Privacy policies must contain all required disclosures about data processing. "
                "Penalties: Up to €20 million or 4% of global annual turnover (Article 83). "
                "Recent enforcement: Norwegian DPA fined company €225K (2023) for incomplete privacy policy. "
                "Missing required disclosures can result in regulatory action, fines, "
                "and inability to demonstrate GDPR compliance."
            )
        )
