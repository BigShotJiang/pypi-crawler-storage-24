"""
WCAG Form Labels Check

Tests that all form inputs have associated labels,
as required by WCAG 2.1 Level A (3.3.2 Labels or Instructions).

WCAG 3.3.2 (Level A): Labels or instructions are provided when content requires user input

Regulation: WCAG 2.1 (International W3C Standard)
Requirement: WCAG_003 - Form Labels
Severity: Critical
Automation: 100% automated
"""

from playwright.async_api import Page
from typing import Dict, List
import logging
from bs4 import BeautifulSoup

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="WCAG", requirement_id="WCAG_003")
class FormLabelsCheck(ComplianceCheck):
    """
    WCAG_003: All form inputs must have associated labels.

    This check verifies that users can understand what information
    is expected in form fields, as required by WCAG 2.1 Level A.

    Methodology:
    1. Identify all form inputs (input, select, textarea)
    2. Check for associated <label> element (via for/id)
    3. Check for aria-label or aria-labelledby attributes
    4. Verify placeholder alone is not used as label
    5. Report unlabeled inputs

    Common violations:
    - Input without label or aria-label
    - Label without for attribute matching input id
    - aria-labelledby referencing non-existent element
    - Placeholder text used as only label (insufficient)
    - Hidden inputs counted (should be excluded)

    Legal risk: ADA lawsuits, Section 508 compliance failures
    European Accessibility Act (EAA): Mandatory from June 2025
    """

    automation_level = "automated"
    severity = "critical"

    # Form input selectors
    FORM_INPUT_SELECTORS = [
        'input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="reset"])',
        'select',
        'textarea',
    ]

    def __init__(self, regulation_id: str = "WCAG", requirement_id: str = "WCAG_003"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.form_inputs: List[Dict] = []
        self.labeled_count = 0
        self.unlabeled_count = 0
        self.placeholder_only_count = 0

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the form labels check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting WCAG_003 check for {url}")

            # Navigate to page if needed
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            # Wait for page to settle
            await page.wait_for_timeout(2000)

            # Step 1: Find all form inputs
            await self._find_form_inputs(page)

            if not self.form_inputs:
                # No form inputs found - pass (nothing to check)
                return await self._create_no_inputs_result()

            # Step 2: Check for labels
            await self._check_input_labels(page)

            # Step 3: Analyze results
            violations_found = (
                self.unlabeled_count > 0 or
                self.placeholder_only_count > 0
            )

            if violations_found:
                return await self._create_violation_result(page)
            else:
                return await self._create_compliant_result()

        except Exception as e:
            logger.error(f"Error in WCAG_003 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="WCAG",
                requirement_id="WCAG_003",
                status="error",
                severity="critical",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _find_form_inputs(self, page: Page):
        """
        Find all form input elements on the page.

        Args:
            page: Playwright page object
        """
        try:
            # Query all form inputs
            selector = ', '.join(self.FORM_INPUT_SELECTORS)
            elements = await page.query_selector_all(selector)

            logger.debug(f"Found {len(elements)} potential form inputs")

            for elem in elements:
                try:
                    # Check if element is visible
                    is_visible = await elem.is_visible()
                    if not is_visible:
                        continue

                    # Get element info
                    elem_info = await elem.evaluate('''
                        el => {
                            return {
                                tag: el.tagName.toLowerCase(),
                                type: el.type || "",
                                id: el.id || "",
                                name: el.name || "",
                                placeholder: el.placeholder || "",
                                ariaLabel: el.getAttribute("aria-label") || "",
                                ariaLabelledby: el.getAttribute("aria-labelledby") || "",
                                title: el.title || ""
                            };
                        }
                    ''')

                    elem_info['element'] = elem
                    elem_info['label_text'] = ""
                    elem_info['has_label'] = False
                    elem_info['label_method'] = None

                    self.form_inputs.append(elem_info)

                except Exception as e:
                    logger.debug(f"Error inspecting form input: {e}")
                    continue

            logger.info(f"Found {len(self.form_inputs)} visible form inputs")

        except Exception as e:
            logger.error(f"Error finding form inputs: {e}", exc_info=True)

    async def _check_input_labels(self, page: Page):
        """
        Check if each form input has an associated label.

        Args:
            page: Playwright page object
        """
        for input_info in self.form_inputs:
            try:
                has_label = False
                label_method = None
                label_text = ""

                # Method 1: Check for aria-label
                if input_info['ariaLabel']:
                    has_label = True
                    label_method = "aria-label"
                    label_text = input_info['ariaLabel']

                # Method 2: Check for aria-labelledby
                elif input_info['ariaLabelledby']:
                    # Verify the referenced element exists
                    labelledby_id = input_info['ariaLabelledby']
                    labelledby_elem = await page.query_selector(f"#{labelledby_id}")
                    if labelledby_elem:
                        label_text = await labelledby_elem.text_content()
                        has_label = True
                        label_method = "aria-labelledby"
                    else:
                        # Invalid aria-labelledby reference
                        label_method = "aria-labelledby (invalid)"

                # Method 3: Check for associated <label> element
                elif input_info['id']:
                    # Look for label with for attribute matching this input's id
                    label_elem = await page.query_selector(f"label[for='{input_info['id']}']")
                    if label_elem:
                        label_text = await label_elem.text_content()
                        label_text = label_text.strip()
                        if label_text:
                            has_label = True
                            label_method = "label[for]"

                # Method 4: Check if input is wrapped by label
                if not has_label:
                    elem = input_info['element']
                    parent_label = await elem.evaluate('''
                        el => {
                            let parent = el.parentElement;
                            while (parent) {
                                if (parent.tagName.toLowerCase() === 'label') {
                                    return parent.textContent;
                                }
                                parent = parent.parentElement;
                            }
                            return null;
                        }
                    ''')
                    if parent_label:
                        label_text = parent_label.strip()
                        if label_text:
                            has_label = True
                            label_method = "label (wrapping)"

                # Method 5: Check for title attribute (not ideal but acceptable)
                if not has_label and input_info['title']:
                    has_label = True
                    label_method = "title"
                    label_text = input_info['title']

                # Check if only placeholder is present (violation)
                if not has_label and input_info['placeholder']:
                    self.placeholder_only_count += 1
                    label_method = "placeholder only (violation)"
                    label_text = input_info['placeholder']

                # Update input info
                input_info['has_label'] = has_label
                input_info['label_method'] = label_method
                input_info['label_text'] = label_text

                if has_label:
                    self.labeled_count += 1
                    logger.debug(f"Labeled input via {label_method}: {label_text[:40]}")
                else:
                    self.unlabeled_count += 1
                    identifier = input_info['id'] or input_info['name'] or input_info['type']
                    logger.debug(f"Unlabeled input: {input_info['tag']} ({identifier})")

            except Exception as e:
                self.unlabeled_count += 1
                logger.debug(f"Error checking input label: {e}")

    async def _create_no_inputs_result(self) -> ComplianceCheckResult:
        """
        Create result when no form inputs found.

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            "No form inputs found on page.\n"
            "Form label requirement is not applicable for this page.\n\n"
            "Note: If the page should have form inputs, this may indicate a rendering issue."
        )

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_003",
            status="passed",
            severity="critical",
            evidence=evidence,
            metadata={
                'form_inputs_count': 0,
                'labeled_count': 0,
                'unlabeled_count': 0,
                'placeholder_only_count': 0
            }
        )

    async def _create_compliant_result(self) -> ComplianceCheckResult:
        """
        Create a compliant result.

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            f"Form labels: All form inputs have associated labels.\n"
            f"  - Total form inputs: {len(self.form_inputs)}\n"
            f"  - Properly labeled: {self.labeled_count}\n"
            f"  - Unlabeled: {self.unlabeled_count}\n\n"
            f"All form inputs have accessible labels via <label>, aria-label, or aria-labelledby.\n"
            f"Users can understand what information is expected in each form field."
        )

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_003",
            status="passed",
            severity="critical",
            evidence=evidence,
            metadata={
                'form_inputs_count': len(self.form_inputs),
                'labeled_count': self.labeled_count,
                'unlabeled_count': self.unlabeled_count,
                'placeholder_only_count': self.placeholder_only_count
            }
        )

    async def _create_violation_result(self, page: Page) -> ComplianceCheckResult:
        """
        Create a violation result.

        Args:
            page: Playwright page object

        Returns:
            ComplianceCheckResult with failed status
        """
        evidence_parts = []

        evidence_parts.append(
            "Form label violations detected.\n"
        )

        if self.unlabeled_count > 0:
            evidence_parts.append(
                f"\nUnlabeled form inputs: {self.unlabeled_count}\n"
                f"The following inputs have no accessible label:"
            )

            unlabeled = [i for i in self.form_inputs if not i['has_label']]
            for input_info in unlabeled[:10]:
                identifier = input_info['id'] or input_info['name'] or input_info['type']
                evidence_parts.append(
                    f"  - {input_info['tag']} type={input_info['type']} ({identifier})"
                )

            if len(unlabeled) > 10:
                evidence_parts.append(f"  ... and {len(unlabeled) - 10} more")

        if self.placeholder_only_count > 0:
            evidence_parts.append(
                f"\nInputs with placeholder only (insufficient): {self.placeholder_only_count}\n"
                f"Placeholder text alone is not sufficient - requires proper label:"
            )

            placeholder_only = [i for i in self.form_inputs
                               if i.get('label_method') == "placeholder only (violation)"]
            for input_info in placeholder_only[:10]:
                evidence_parts.append(
                    f"  - {input_info['tag']} placeholder=\"{input_info['placeholder'][:40]}\""
                )

            if len(placeholder_only) > 10:
                evidence_parts.append(f"  ... and {len(placeholder_only) - 10} more")

        evidence_parts.append(
            "\nWCAG 2.1 Level A requires labels or instructions for user input (3.3.2).\n\n"
            "Recommendation:\n"
            "  - Add <label> elements with for attribute matching input id\n"
            "  - Use aria-label attribute for inputs that can't have visible labels\n"
            "  - Use aria-labelledby to reference existing text as label\n"
            "  - Do not rely on placeholder text alone - it's not accessible"
        )

        evidence = "\n".join(evidence_parts)

        screenshot_path = await self.take_screenshot(page, "wcag_003_form_labels_violation")

        # Get sample unlabeled inputs
        unlabeled_samples = [
            {
                'tag': i['tag'],
                'type': i['type'],
                'id': i['id'],
                'name': i['name'],
                'label_method': i.get('label_method', 'none')
            }
            for i in self.form_inputs[:20]
            if not i['has_label']
        ]

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_003",
            status="failed",
            severity="critical",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata={
                'form_inputs_count': len(self.form_inputs),
                'labeled_count': self.labeled_count,
                'unlabeled_count': self.unlabeled_count,
                'placeholder_only_count': self.placeholder_only_count,
                'unlabeled_samples': unlabeled_samples[:10]
            },
            legal_risk=(
                "Critical WCAG 2.1 Level A violation (3.3.2 Labels or Instructions). "
                "Form inputs without labels prevent users with screen readers from understanding "
                "what information is expected. This creates barriers for blind and visually impaired users. "
                "Legal risks: ADA Title III lawsuits in the US, accessibility discrimination claims. "
                "European Accessibility Act (EAA): Mandatory compliance from June 2025. "
                "Section 508: Required for US federal websites and vendors. "
                "Failure to provide form labels can result in lawsuits, settlements, and reputational damage."
            )
        )

    async def execute_from_journey(self, step, journey_loader) -> ComplianceCheckResult:
        """
        Execute form labels check from journey files (HTML-based).

        All label detection methods work from static HTML.

        Args:
            step: JourneyStep with HTML data
            journey_loader: JourneyLoader for accessing related steps

        Returns:
            ComplianceCheckResult with status
        """
        try:
            # Load HTML from journey
            html = step.load_html()
            soup = BeautifulSoup(html, 'html.parser')

            logger.info(f"Starting WCAG_003 journey-based check for {step.url}")

            # Find all form inputs (exclude hidden, submit, button, reset)
            form_inputs = []
            for input_elem in soup.find_all('input'):
                input_type = input_elem.get('type', '').lower()
                if input_type not in ['hidden', 'submit', 'button', 'reset']:
                    form_inputs.append(input_elem)

            # Add select and textarea
            form_inputs.extend(soup.find_all('select'))
            form_inputs.extend(soup.find_all('textarea'))

            if not form_inputs:
                # No form inputs - pass
                return ComplianceCheckResult(
                    regulation_id="WCAG",
                    requirement_id="WCAG_003",
                    status="passed",
                    severity="critical",
                    evidence=(
                        "No form inputs found in HTML.\n"
                        "Form label requirement is not applicable for this page.\n\n"
                        "Note: If page should have forms, they may be loaded dynamically"
                    ),
                    metadata={
                        'form_inputs_count': 0,
                        'labeled_count': 0,
                        'unlabeled_count': 0,
                        'source': 'journey_file'
                    }
                )

            # Check each input for labels
            labeled_count = 0
            unlabeled_count = 0
            placeholder_only_count = 0
            unlabeled_samples = []

            for input_elem in form_inputs:
                has_label = False
                label_method = None
                label_text = ""

                input_tag = input_elem.name
                input_type = input_elem.get('type', '')
                input_id = input_elem.get('id', '')
                input_name = input_elem.get('name', '')
                placeholder = input_elem.get('placeholder', '')
                aria_label = input_elem.get('aria-label', '')
                aria_labelledby = input_elem.get('aria-labelledby', '')
                title = input_elem.get('title', '')

                # Method 1: aria-label
                if aria_label:
                    has_label = True
                    label_method = "aria-label"
                    label_text = aria_label

                # Method 2: aria-labelledby
                elif aria_labelledby:
                    # Check if referenced element exists
                    labelledby_elem = soup.find(id=aria_labelledby)
                    if labelledby_elem:
                        label_text = labelledby_elem.get_text().strip()
                        has_label = True
                        label_method = "aria-labelledby"
                    else:
                        label_method = "aria-labelledby (invalid)"

                # Method 3: label[for] matching input id
                elif input_id:
                    label_elem = soup.find('label', attrs={'for': input_id})
                    if label_elem:
                        label_text = label_elem.get_text().strip()
                        if label_text:
                            has_label = True
                            label_method = "label[for]"

                # Method 4: Label wrapping input
                if not has_label:
                    parent = input_elem.parent
                    while parent:
                        if parent.name == 'label':
                            label_text = parent.get_text().strip()
                            if label_text:
                                has_label = True
                                label_method = "label (wrapping)"
                            break
                        parent = parent.parent if hasattr(parent, 'parent') else None

                # Method 5: title attribute
                if not has_label and title:
                    has_label = True
                    label_method = "title"
                    label_text = title

                # Check for placeholder only (violation)
                if not has_label and placeholder:
                    placeholder_only_count += 1
                    label_method = "placeholder only (violation)"
                    label_text = placeholder

                # Count
                if has_label:
                    labeled_count += 1
                else:
                    unlabeled_count += 1
                    if len(unlabeled_samples) < 10:
                        unlabeled_samples.append({
                            'tag': input_tag,
                            'type': input_type,
                            'id': input_id,
                            'name': input_name,
                            'label_method': label_method or 'none'
                        })

            # Analyze results
            violations_found = unlabeled_count > 0 or placeholder_only_count > 0

            if not violations_found:
                # All labeled
                return ComplianceCheckResult(
                    regulation_id="WCAG",
                    requirement_id="WCAG_003",
                    status="passed",
                    severity="critical",
                    evidence=(
                        f"All {labeled_count} form inputs have proper labels.\n\n"
                        f"WCAG 2.1 Level A requirement satisfied (3.3.2 Labels or Instructions).\n\n"
                        f"Note: Journey-based check verified:\n"
                        f"  ✓ All inputs have labels\n"
                        f"  ✓ Label methods: aria-label, label[for], or wrapping labels\n\n"
                        f"Limitation: Cannot verify label visibility (requires live page)"
                    ),
                    metadata={
                        'form_inputs_count': len(form_inputs),
                        'labeled_count': labeled_count,
                        'unlabeled_count': unlabeled_count,
                        'placeholder_only_count': placeholder_only_count,
                        'source': 'journey_file',
                        'limitations': 'Cannot verify visibility'
                    }
                )
            else:
                # Violations found
                evidence_parts = []
                evidence_parts.append(
                    f"❌ Form accessibility violation: {unlabeled_count} of {len(form_inputs)} inputs lack proper labels.\n"
                )

                if unlabeled_count > 0:
                    evidence_parts.append(f"\nUnlabeled inputs: {unlabeled_count}")
                    if unlabeled_samples:
                        evidence_parts.append("\nSamples of unlabeled inputs:")
                        for sample in unlabeled_samples[:5]:
                            identifier = sample['id'] or sample['name'] or sample['type']
                            evidence_parts.append(f"  - <{sample['tag']} type=\"{sample['type']}\" id=\"{identifier}\">")

                if placeholder_only_count > 0:
                    evidence_parts.append(
                        f"\n❌ Inputs relying on placeholder only: {placeholder_only_count}\n"
                        "Placeholder text is not accessible to screen readers and should not be used as the only label."
                    )

                evidence_parts.append(
                    "\nWCAG 2.1 Level A requires labels or instructions for user input (3.3.2).\n\n"
                    "Recommendation:\n"
                    "  - Add <label> elements with for attribute matching input id\n"
                    "  - Use aria-label attribute for inputs that can't have visible labels\n"
                    "  - Use aria-labelledby to reference existing text as label\n"
                    "  - Do not rely on placeholder text alone - it's not accessible"
                )

                return ComplianceCheckResult(
                    regulation_id="WCAG",
                    requirement_id="WCAG_003",
                    status="failed",
                    severity="critical",
                    evidence="\n".join(evidence_parts),
                    screenshot_path=str(step.screenshot_path) if step.screenshot_path.exists() else None,
                    metadata={
                        'form_inputs_count': len(form_inputs),
                        'labeled_count': labeled_count,
                        'unlabeled_count': unlabeled_count,
                        'placeholder_only_count': placeholder_only_count,
                        'unlabeled_samples': unlabeled_samples,
                        'source': 'journey_file'
                    },
                    legal_risk=(
                        "Critical WCAG 2.1 Level A violation (3.3.2 Labels or Instructions). "
                        "Form inputs without labels prevent users with screen readers from understanding "
                        "what information is expected. Legal risks: ADA lawsuits, Section 508 compliance failures."
                    )
                )

        except Exception as e:
            logger.error(f"Error in WCAG_003 journey-based check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="WCAG",
                requirement_id="WCAG_003",
                status="error",
                severity="critical",
                error_message=str(e),
                evidence=f"Journey-based check execution failed: {e}"
            )
