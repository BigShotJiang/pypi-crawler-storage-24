"""
WCAG Color Contrast Check

Tests that text has sufficient color contrast against its background,
as required by WCAG 2.1 Level AA (1.4.3 Contrast - Minimum).

WCAG 1.4.3 (Level AA): Minimum contrast ratio of 4.5:1 for normal text, 3:1 for large text
WCAG 1.4.6 (Level AAA): Enhanced contrast ratio of 7:1 for normal text, 4.5:1 for large text

Regulation: WCAG 2.1 (International W3C Standard)
Requirement: WCAG_002 - Color Contrast
Severity: Critical
Automation: 100% automated
"""

from playwright.async_api import Page
from typing import Optional, Dict, List, Tuple
import logging
import re
import math

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="WCAG", requirement_id="WCAG_002")
class ColorContrastCheck(ComplianceCheck):
    """
    WCAG_002: Text must have sufficient color contrast against background.

    This check verifies that all text content has adequate color contrast
    ratios to ensure readability for users with visual impairments.

    Methodology:
    1. Identify all text elements on the page
    2. Extract foreground (text) color
    3. Extract background color (including parent backgrounds)
    4. Calculate contrast ratio using WCAG formula
    5. Compare against WCAG AA thresholds:
       - Normal text: 4.5:1 minimum
       - Large text (18pt+ or 14pt+ bold): 3:1 minimum
    6. Report violations

    Common violations:
    - Light gray text on white background
    - Low contrast brand colors
    - Links that don't meet contrast requirements
    - Placeholder text with insufficient contrast
    - Disabled form elements (may be exempt)

    Legal risk: ADA lawsuits, accessibility discrimination claims
    European Accessibility Act (EAA): Mandatory from June 2025
    """

    automation_level = "automated"
    severity = "critical"

    # WCAG AA contrast thresholds
    CONTRAST_NORMAL_AA = 4.5  # Normal text
    CONTRAST_LARGE_AA = 3.0   # Large text (18pt+ or 14pt+ bold)

    # WCAG AAA contrast thresholds
    CONTRAST_NORMAL_AAA = 7.0
    CONTRAST_LARGE_AAA = 4.5

    # Large text size thresholds
    LARGE_TEXT_SIZE_PX = 18.0 * 1.333  # 18pt = ~24px
    LARGE_TEXT_BOLD_SIZE_PX = 14.0 * 1.333  # 14pt bold = ~18.67px

    def __init__(self, regulation_id: str = "WCAG", requirement_id: str = "WCAG_002"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.text_elements: List[Dict] = []
        self.violations_count = 0
        self.compliant_count = 0

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the color contrast check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting WCAG_002 check for {url}")

            # Navigate to page if needed
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            # Wait for page to settle
            await page.wait_for_timeout(2000)

            # Step 1: Find all text elements
            await self._find_text_elements(page)

            if not self.text_elements:
                return await self._create_no_text_elements_result()

            # Step 2: Check contrast for each element
            await self._check_contrast_ratios(page)

            # Step 3: Analyze results
            if self.violations_count > 0:
                return await self._create_violation_result(page)
            else:
                return await self._create_compliant_result()

        except Exception as e:
            logger.error(f"Error in WCAG_002 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="WCAG",
                requirement_id="WCAG_002",
                status="error",
                severity="critical",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _find_text_elements(self, page: Page):
        """
        Find all text elements on the page.

        Args:
            page: Playwright page object
        """
        try:
            # Query common text elements
            text_selectors = [
                'p', 'span', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
                'a', 'button', 'label', 'li', 'td', 'th', 'blockquote'
            ]

            for selector in text_selectors:
                try:
                    elements = await page.query_selector_all(selector)

                    for elem in elements:
                        try:
                            # Check if element has visible text
                            is_visible = await elem.is_visible()
                            if not is_visible:
                                continue

                            text_content = await elem.evaluate('el => el.textContent || ""')
                            text_content = text_content.strip()

                            # Skip empty or very short text
                            if not text_content or len(text_content) < 2:
                                continue

                            # Limit number of elements checked for performance
                            if len(self.text_elements) >= 100:
                                break

                            self.text_elements.append({
                                'element': elem,
                                'text': text_content[:50],  # Truncate for reporting
                                'selector': selector
                            })

                        except Exception as e:
                            logger.debug(f"Error inspecting element: {e}")
                            continue

                    # Stop if we have enough samples
                    if len(self.text_elements) >= 100:
                        break

                except Exception as e:
                    logger.debug(f"Error querying selector {selector}: {e}")

            logger.info(f"Found {len(self.text_elements)} text elements to check")

        except Exception as e:
            logger.error(f"Error finding text elements: {e}", exc_info=True)

    async def _check_contrast_ratios(self, page: Page):
        """
        Check contrast ratios for all text elements.

        Args:
            page: Playwright page object
        """
        for elem_info in self.text_elements:
            try:
                elem = elem_info['element']

                # Get computed styles and colors
                contrast_data = await elem.evaluate('''
                    el => {
                        const styles = window.getComputedStyle(el);

                        // Get text color
                        const color = styles.color;

                        // Get background color (may need to check parents)
                        let bgColor = styles.backgroundColor;
                        let currentEl = el;

                        // Walk up DOM tree to find non-transparent background
                        while ((!bgColor || bgColor === 'rgba(0, 0, 0, 0)' || bgColor === 'transparent')
                               && currentEl.parentElement) {
                            currentEl = currentEl.parentElement;
                            const parentStyles = window.getComputedStyle(currentEl);
                            bgColor = parentStyles.backgroundColor;
                        }

                        // Default to white if no background found
                        if (!bgColor || bgColor === 'rgba(0, 0, 0, 0)' || bgColor === 'transparent') {
                            bgColor = 'rgb(255, 255, 255)';
                        }

                        // Get font size and weight
                        const fontSize = parseFloat(styles.fontSize);
                        const fontWeight = styles.fontWeight;

                        return {
                            color: color,
                            backgroundColor: bgColor,
                            fontSize: fontSize,
                            fontWeight: fontWeight
                        };
                    }
                ''')

                # Parse colors
                fg_color = self._parse_color(contrast_data['color'])
                bg_color = self._parse_color(contrast_data['backgroundColor'])

                if fg_color and bg_color:
                    # Calculate contrast ratio
                    ratio = self._calculate_contrast_ratio(fg_color, bg_color)

                    # Determine if text is "large"
                    is_large = self._is_large_text(
                        contrast_data['fontSize'],
                        contrast_data['fontWeight']
                    )

                    # Determine required ratio (WCAG AA)
                    required_ratio = self.CONTRAST_LARGE_AA if is_large else self.CONTRAST_NORMAL_AA

                    # Check if compliant
                    is_compliant = ratio >= required_ratio

                    # Store results
                    elem_info['contrast_ratio'] = ratio
                    elem_info['required_ratio'] = required_ratio
                    elem_info['is_large_text'] = is_large
                    elem_info['is_compliant'] = is_compliant
                    elem_info['foreground'] = contrast_data['color']
                    elem_info['background'] = contrast_data['backgroundColor']

                    if is_compliant:
                        self.compliant_count += 1
                    else:
                        self.violations_count += 1
                        logger.debug(
                            f"Contrast violation: {elem_info['text'][:30]} - "
                            f"Ratio: {ratio:.2f} (Required: {required_ratio})"
                        )

            except Exception as e:
                logger.debug(f"Error checking contrast for element: {e}")
                elem_info['is_compliant'] = None

    def _parse_color(self, color_string: str) -> Optional[Tuple[int, int, int]]:
        """
        Parse CSS color string to RGB tuple.

        Args:
            color_string: CSS color (rgb(), rgba(), hex, or named)

        Returns:
            (r, g, b) tuple or None
        """
        try:
            # Handle rgb() and rgba()
            rgb_match = re.match(r'rgba?\((\d+),\s*(\d+),\s*(\d+)', color_string)
            if rgb_match:
                return (
                    int(rgb_match.group(1)),
                    int(rgb_match.group(2)),
                    int(rgb_match.group(3))
                )

            # Handle hex colors
            hex_match = re.match(r'#([0-9a-fA-F]{6})', color_string)
            if hex_match:
                hex_str = hex_match.group(1)
                return (
                    int(hex_str[0:2], 16),
                    int(hex_str[2:4], 16),
                    int(hex_str[4:6], 16)
                )

            # Handle 3-digit hex
            hex_match = re.match(r'#([0-9a-fA-F]{3})$', color_string)
            if hex_match:
                hex_str = hex_match.group(1)
                return (
                    int(hex_str[0] * 2, 16),
                    int(hex_str[1] * 2, 16),
                    int(hex_str[2] * 2, 16)
                )

            return None

        except Exception as e:
            logger.debug(f"Error parsing color {color_string}: {e}")
            return None

    def _calculate_contrast_ratio(
        self,
        fg_rgb: Tuple[int, int, int],
        bg_rgb: Tuple[int, int, int]
    ) -> float:
        """
        Calculate WCAG contrast ratio between foreground and background colors.

        Args:
            fg_rgb: Foreground RGB tuple
            bg_rgb: Background RGB tuple

        Returns:
            Contrast ratio (1.0 to 21.0)
        """
        # Calculate relative luminance for each color
        fg_luminance = self._get_relative_luminance(fg_rgb)
        bg_luminance = self._get_relative_luminance(bg_rgb)

        # Calculate contrast ratio (WCAG formula)
        lighter = max(fg_luminance, bg_luminance)
        darker = min(fg_luminance, bg_luminance)

        ratio = (lighter + 0.05) / (darker + 0.05)
        return ratio

    def _get_relative_luminance(self, rgb: Tuple[int, int, int]) -> float:
        """
        Calculate relative luminance of a color (WCAG formula).

        Args:
            rgb: RGB tuple (0-255)

        Returns:
            Relative luminance (0.0 to 1.0)
        """
        # Convert to 0-1 range
        r, g, b = [c / 255.0 for c in rgb]

        # Apply gamma correction
        def gamma_correct(channel):
            if channel <= 0.03928:
                return channel / 12.92
            else:
                return math.pow((channel + 0.055) / 1.055, 2.4)

        r_linear = gamma_correct(r)
        g_linear = gamma_correct(g)
        b_linear = gamma_correct(b)

        # Calculate luminance using WCAG formula
        luminance = 0.2126 * r_linear + 0.7152 * g_linear + 0.0722 * b_linear
        return luminance

    def _is_large_text(self, font_size_px: float, font_weight: str) -> bool:
        """
        Determine if text qualifies as "large" per WCAG.

        Args:
            font_size_px: Font size in pixels
            font_weight: Font weight (e.g., "400", "bold")

        Returns:
            True if text is large, False otherwise
        """
        # Convert font weight to numeric
        try:
            if font_weight == 'bold' or font_weight == 'bolder':
                weight_numeric = 700
            elif font_weight == 'normal':
                weight_numeric = 400
            else:
                weight_numeric = int(font_weight)
        except (ValueError, TypeError):
            weight_numeric = 400

        # Check if large text
        # 18pt+ (24px+) regardless of weight
        if font_size_px >= self.LARGE_TEXT_SIZE_PX:
            return True

        # 14pt+ (18.67px+) if bold (700+)
        if font_size_px >= self.LARGE_TEXT_BOLD_SIZE_PX and weight_numeric >= 700:
            return True

        return False

    async def _create_no_text_elements_result(self) -> ComplianceCheckResult:
        """
        Create result when no text elements found.

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            "No text elements found on page.\n"
            "Color contrast requirement is not applicable for this page.\n\n"
            "Note: If the page should have text, this may indicate a rendering issue."
        )

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_002",
            status="passed",
            severity="critical",
            evidence=evidence,
            metadata={
                'text_elements_count': 0,
                'violations_count': 0,
                'compliant_count': 0
            }
        )

    async def _create_compliant_result(self) -> ComplianceCheckResult:
        """
        Create a compliant result.

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            f"Color contrast: All text elements meet WCAG AA standards.\n"
            f"  - Total text elements checked: {len(self.text_elements)}\n"
            f"  - Compliant elements: {self.compliant_count}\n"
            f"  - Violations: {self.violations_count}\n\n"
            f"All text has sufficient contrast (4.5:1 for normal, 3:1 for large text).\n"
            f"Note: This is a sample of {len(self.text_elements)} elements. "
            f"Manual verification recommended for comprehensive coverage."
        )

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_002",
            status="passed",
            severity="critical",
            evidence=evidence,
            metadata={
                'text_elements_count': len(self.text_elements),
                'violations_count': self.violations_count,
                'compliant_count': self.compliant_count
            }
        )

    async def _create_violation_result(self, page: Page) -> ComplianceCheckResult:
        """
        Create a violation result.

        Args:
            page: Playwright page object

        Returns:
            ComplianceCheckResult with failed status
        """
        evidence_parts = []

        evidence_parts.append(
            f"Color contrast violations detected.\n"
            f"  - Total elements checked: {len(self.text_elements)}\n"
            f"  - Violations: {self.violations_count}\n"
            f"  - Compliant: {self.compliant_count}\n"
        )

        # Show sample violations
        violations = [e for e in self.text_elements if e.get('is_compliant') == False]

        if violations:
            evidence_parts.append(
                f"\nSample contrast violations (showing up to 10):"
            )

            for elem_info in violations[:10]:
                ratio = elem_info.get('contrast_ratio', 0)
                required = elem_info.get('required_ratio', 0)
                text_type = "large" if elem_info.get('is_large_text') else "normal"

                evidence_parts.append(
                    f"  - \"{elem_info['text'][:40]}\" ({text_type} text)\n"
                    f"    Contrast: {ratio:.2f}:1 (Required: {required}:1)\n"
                    f"    Colors: {elem_info.get('foreground', 'unknown')} on "
                    f"{elem_info.get('background', 'unknown')}"
                )

            if len(violations) > 10:
                evidence_parts.append(f"\n  ... and {len(violations) - 10} more violations")

        evidence_parts.append(
            "\n\nWCAG 2.1 Level AA requires:\n"
            "  - Normal text: 4.5:1 contrast ratio minimum\n"
            "  - Large text (18pt+ or 14pt+ bold): 3:1 contrast ratio minimum\n\n"
            "Recommendation:\n"
            "  - Increase contrast between text and background colors\n"
            "  - Use darker text on light backgrounds or lighter text on dark backgrounds\n"
            "  - Test with online contrast checkers (e.g., WebAIM Contrast Checker)\n"
            "  - Avoid light gray text (#999, #AAA) on white backgrounds"
        )

        evidence = "\n".join(evidence_parts)

        screenshot_path = await self.take_screenshot(page, "wcag_002_color_contrast_violation")

        # Sample violations for metadata
        violation_samples = [
            {
                'text': e['text'][:40],
                'contrast_ratio': round(e.get('contrast_ratio', 0), 2),
                'required_ratio': e.get('required_ratio', 0),
                'is_large_text': e.get('is_large_text', False)
            }
            for e in violations[:10]
        ]

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_002",
            status="failed",
            severity="critical",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata={
                'text_elements_count': len(self.text_elements),
                'violations_count': self.violations_count,
                'compliant_count': self.compliant_count,
                'violation_samples': violation_samples
            },
            legal_risk=(
                "Critical WCAG 2.1 Level AA violation (1.4.3 Contrast - Minimum). "
                "Insufficient color contrast makes text difficult or impossible to read "
                "for users with visual impairments, including low vision, color blindness, and age-related vision loss. "
                "Legal risks: ADA Title III lawsuits in the US, accessibility discrimination claims. "
                "European Accessibility Act (EAA): Mandatory compliance from June 2025. "
                "Section 508: Required for US federal websites and vendors. "
                "Failure to provide adequate contrast can result in lawsuits, settlements, and reputational damage."
            )
        )
