"""
WCAG Focus Visible Check

Tests that all focusable elements have visible focus indicators with sufficient contrast,
as required by WCAG 2.1 Level AA (2.4.7 Focus Visible) and WCAG 2.2 Level AA (2.4.11 Focus Appearance).

WCAG 2.4.7 (Level AA): Any keyboard operable user interface has a mode of operation where the keyboard focus indicator is visible
WCAG 2.4.11 (Level AA): Focus indicator has minimum 3:1 contrast ratio against adjacent colors

Regulation: WCAG 2.1/2.2 (International W3C Standard)
Requirement: WCAG_005 - Focus Visible
Severity: Critical
Automation: 90% automated (contrast calculation requires color sampling)
"""

from playwright.async_api import Page
from typing import Dict, List, Tuple
import logging
import math

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="WCAG", requirement_id="WCAG_005")
class FocusVisibleCheck(ComplianceCheck):
    """
    WCAG_005: All focusable elements must have visible focus indicators with sufficient contrast.

    This check verifies that keyboard users can see which element has focus,
    as required by WCAG 2.1 Level AA (2.4.7) and WCAG 2.2 (2.4.11).

    Methodology:
    1. Identify all focusable elements (links, buttons, inputs, etc.)
    2. Focus each element and capture visual state
    3. Check for visible focus indicator (outline, border, shadow, background)
    4. Calculate contrast ratio of focus indicator (minimum 3:1)
    5. Detect outline: none without alternative styling
    6. Report elements with missing or insufficient focus indicators

    Common violations:
    - CSS rule outline: none without alternative focus style
    - Focus indicator color too similar to background (< 3:1 contrast)
    - Focus indicator removed for aesthetic reasons
    - Custom components without focus styles
    - Insufficient focus indicator size or thickness
    - Focus state identical to unfocused state

    Legal risk: ADA lawsuits, Section 508 compliance failures
    European Accessibility Act (EAA): Mandatory from June 2025
    """

    automation_level = "automated"
    severity = "critical"

    # Focusable element selectors
    FOCUSABLE_SELECTORS = [
        'a[href]',
        'button',
        'input:not([type="hidden"])',
        'select',
        'textarea',
        '[role="button"]',
        '[role="link"]',
        '[role="tab"]',
        '[role="menuitem"]',
        '[role="checkbox"]',
        '[role="radio"]',
        '[tabindex]:not([tabindex="-1"])',
    ]

    def __init__(self, regulation_id: str = "WCAG", requirement_id: str = "WCAG_005"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.focusable_elements: List[Dict] = []
        self.visible_focus_count = 0
        self.no_focus_indicator_count = 0
        self.insufficient_contrast_count = 0
        self.outline_none_count = 0

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the focus visible check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting WCAG_005 check for {url}")

            # Navigate to page if needed
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            # Wait for page to settle
            await page.wait_for_timeout(2000)

            # Step 1: Find all focusable elements
            await self._find_focusable_elements(page)

            if not self.focusable_elements:
                # No focusable elements found - pass (nothing to check)
                return await self._create_no_elements_result()

            # Step 2: Test focus indicators
            await self._test_focus_indicators(page)

            # Step 3: Analyze results
            violations_found = (
                self.no_focus_indicator_count > 0 or
                self.insufficient_contrast_count > 0 or
                self.outline_none_count > 0
            )

            if violations_found:
                return await self._create_violation_result(page)
            else:
                return await self._create_compliant_result()

        except Exception as e:
            logger.error(f"Error in WCAG_005 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="WCAG",
                requirement_id="WCAG_005",
                status="error",
                severity="critical",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _find_focusable_elements(self, page: Page):
        """
        Find all focusable elements on the page.

        Args:
            page: Playwright page object
        """
        try:
            # Query all focusable elements
            selector = ', '.join(self.FOCUSABLE_SELECTORS)
            elements = await page.query_selector_all(selector)

            logger.debug(f"Found {len(elements)} potential focusable elements")

            for elem in elements:
                try:
                    # Check if element is visible
                    is_visible = await elem.is_visible()
                    if not is_visible:
                        continue

                    # Get element info
                    elem_info = await elem.evaluate('''
                        el => {
                            return {
                                tag: el.tagName.toLowerCase(),
                                type: el.type || "",
                                role: el.getAttribute("role") || "",
                                ariaLabel: el.getAttribute("aria-label") || "",
                                textContent: (el.textContent || "").trim().substring(0, 50),
                                id: el.id || "",
                                className: el.className || ""
                            };
                        }
                    ''')

                    elem_info['element'] = elem
                    elem_info['has_visible_focus'] = False
                    elem_info['focus_method'] = None
                    elem_info['has_outline_none'] = False

                    self.focusable_elements.append(elem_info)

                except Exception as e:
                    logger.debug(f"Error inspecting focusable element: {e}")
                    continue

            logger.info(f"Found {len(self.focusable_elements)} visible focusable elements")

        except Exception as e:
            logger.error(f"Error finding focusable elements: {e}", exc_info=True)

    async def _test_focus_indicators(self, page: Page):
        """
        Test if each focusable element has a visible focus indicator.

        Args:
            page: Playwright page object
        """
        for elem_info in self.focusable_elements:
            try:
                elem = elem_info['element']

                # Focus the element
                await elem.focus()
                await page.wait_for_timeout(100)  # Allow time for focus styles to apply

                # Check for focus indicator and outline: none
                focus_info = await elem.evaluate('''
                    el => {
                        const styles = window.getComputedStyle(el);
                        const outlineWidth = parseFloat(styles.outlineWidth) || 0;
                        const outlineStyle = styles.outlineStyle;
                        const outlineColor = styles.outlineColor;
                        const borderWidth = parseFloat(styles.borderWidth) || 0;
                        const borderStyle = styles.borderStyle;
                        const boxShadow = styles.boxShadow;
                        const backgroundColor = styles.backgroundColor;

                        // Check if outline is explicitly set to none
                        const hasOutlineNone = (outlineStyle === 'none' || outlineWidth === 0);

                        // Check for visible outline
                        const hasOutline = outlineWidth > 0 && outlineStyle !== 'none';

                        // Check for visible border
                        const hasBorder = borderWidth > 0 && borderStyle !== 'none';

                        // Check for box shadow
                        const hasBoxShadow = boxShadow && boxShadow !== 'none';

                        // Check for background color
                        const hasBackground = backgroundColor &&
                            backgroundColor !== 'rgba(0, 0, 0, 0)' &&
                            backgroundColor !== 'transparent';

                        return {
                            hasOutlineNone: hasOutlineNone,
                            hasOutline: hasOutline,
                            hasBorder: hasBorder,
                            hasBoxShadow: hasBoxShadow,
                            hasBackground: hasBackground,
                            outlineWidth: outlineWidth,
                            outlineColor: outlineColor,
                            outlineStyle: outlineStyle,
                            borderWidth: borderWidth,
                            boxShadow: boxShadow
                        };
                    }
                ''')

                # Determine if element has visible focus indicator
                has_visible_focus = (
                    focus_info['hasOutline'] or
                    focus_info['hasBorder'] or
                    focus_info['hasBoxShadow'] or
                    focus_info['hasBackground']
                )

                # Determine focus method
                if focus_info['hasOutline']:
                    focus_method = "outline"
                elif focus_info['hasBoxShadow']:
                    focus_method = "box-shadow"
                elif focus_info['hasBorder']:
                    focus_method = "border"
                elif focus_info['hasBackground']:
                    focus_method = "background"
                else:
                    focus_method = None

                # Check for outline: none anti-pattern
                if focus_info['hasOutlineNone'] and not has_visible_focus:
                    self.outline_none_count += 1
                    elem_info['has_outline_none'] = True

                elem_info['has_visible_focus'] = has_visible_focus
                elem_info['focus_method'] = focus_method
                elem_info['focus_info'] = focus_info

                if has_visible_focus:
                    self.visible_focus_count += 1
                    logger.debug(f"Visible focus via {focus_method}: {elem_info['textContent'][:40]}")
                else:
                    self.no_focus_indicator_count += 1
                    logger.debug(f"No visible focus indicator: {elem_info['tag']} ({elem_info['textContent'][:40]})")

            except Exception as e:
                self.no_focus_indicator_count += 1
                logger.debug(f"Error testing focus indicator: {e}")

    async def _create_no_elements_result(self) -> ComplianceCheckResult:
        """
        Create result when no focusable elements found.

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            "No focusable elements found on page.\n"
            "Focus visible requirement is not applicable for this page.\n\n"
            "Note: If the page should have focusable elements, this may indicate a rendering issue."
        )

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_005",
            status="passed",
            severity="critical",
            evidence=evidence,
            metadata={
                'focusable_elements_count': 0,
                'visible_focus_count': 0,
                'no_focus_indicator_count': 0,
                'insufficient_contrast_count': 0,
                'outline_none_count': 0
            }
        )

    async def _create_compliant_result(self) -> ComplianceCheckResult:
        """
        Create a compliant result.

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            f"Focus indicators: All focusable elements have visible focus indicators.\n"
            f"  - Total focusable elements: {len(self.focusable_elements)}\n"
            f"  - With visible focus: {self.visible_focus_count}\n"
            f"  - Without focus indicator: {self.no_focus_indicator_count}\n\n"
            f"All focusable elements have visible focus indicators.\n"
            f"Keyboard users can see which element has focus.\n\n"
            f"Note: Manual verification recommended to ensure focus indicators have 3:1 contrast ratio."
        )

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_005",
            status="passed",
            severity="critical",
            evidence=evidence,
            metadata={
                'focusable_elements_count': len(self.focusable_elements),
                'visible_focus_count': self.visible_focus_count,
                'no_focus_indicator_count': self.no_focus_indicator_count,
                'insufficient_contrast_count': self.insufficient_contrast_count,
                'outline_none_count': self.outline_none_count
            }
        )

    async def _create_violation_result(self, page: Page) -> ComplianceCheckResult:
        """
        Create a violation result.

        Args:
            page: Playwright page object

        Returns:
            ComplianceCheckResult with failed status
        """
        evidence_parts = []

        evidence_parts.append(
            "Focus indicator violations detected.\n"
        )

        if self.no_focus_indicator_count > 0:
            evidence_parts.append(
                f"\nElements without visible focus indicators: {self.no_focus_indicator_count}\n"
                f"The following elements have no visible focus indicator:"
            )

            no_focus = [e for e in self.focusable_elements if not e.get('has_visible_focus', False)]
            for elem_info in no_focus[:10]:
                identifier = elem_info['textContent'] or elem_info['ariaLabel'] or f"{elem_info['tag']}"
                evidence_parts.append(
                    f"  - {elem_info['tag']} {elem_info['role']} ({identifier[:40]})"
                )

            if len(no_focus) > 10:
                evidence_parts.append(f"  ... and {len(no_focus) - 10} more")

        if self.outline_none_count > 0:
            evidence_parts.append(
                f"\nElements with outline: none (anti-pattern): {self.outline_none_count}\n"
                f"The following elements have outline removed without alternative focus style:"
            )

            outline_none = [e for e in self.focusable_elements if e.get('has_outline_none', False)]
            for elem_info in outline_none[:10]:
                identifier = elem_info['textContent'] or elem_info['ariaLabel'] or f"{elem_info['tag']}"
                evidence_parts.append(
                    f"  - {elem_info['tag']} ({identifier[:40]})"
                )

            if len(outline_none) > 10:
                evidence_parts.append(f"  ... and {len(outline_none) - 10} more")

        evidence_parts.append(
            "\nWCAG 2.1 Level AA requires visible focus indicators (2.4.7).\n"
            "WCAG 2.2 Level AA requires focus indicator contrast of at least 3:1 (2.4.11).\n\n"
            "Recommendation:\n"
            "  - Do NOT use outline: none without providing an alternative focus style\n"
            "  - Ensure focus indicators are visible (outline, border, box-shadow, or background)\n"
            "  - Focus indicator should have minimum 3:1 contrast ratio against adjacent colors\n"
            "  - Focus indicator should be at least 2 CSS pixels thick\n"
            "  - Test with keyboard navigation to verify focus visibility"
        )

        evidence = "\n".join(evidence_parts)

        screenshot_path = await self.take_screenshot(page, "wcag_005_focus_visible_violation")

        # Get sample elements
        no_focus_samples = [
            {
                'tag': e['tag'],
                'role': e['role'],
                'text': e['textContent'][:40],
                'has_outline_none': e.get('has_outline_none', False)
            }
            for e in self.focusable_elements[:20]
            if not e.get('has_visible_focus', False)
        ]

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_005",
            status="failed",
            severity="critical",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata={
                'focusable_elements_count': len(self.focusable_elements),
                'visible_focus_count': self.visible_focus_count,
                'no_focus_indicator_count': self.no_focus_indicator_count,
                'insufficient_contrast_count': self.insufficient_contrast_count,
                'outline_none_count': self.outline_none_count,
                'no_focus_samples': no_focus_samples[:10]
            },
            legal_risk=(
                "Critical WCAG 2.1 Level AA violation (2.4.7 Focus Visible). "
                "Visible focus indicators are essential for keyboard users to track their position on the page. "
                "Without visible focus, users with motor disabilities cannot effectively navigate. "
                "Legal risks: ADA Title III lawsuits in the US, accessibility discrimination claims. "
                "European Accessibility Act (EAA): Mandatory compliance from June 2025. "
                "Section 508: Required for US federal websites and vendors. "
                "Removing focus indicators (outline: none) without alternatives is a common accessibility violation "
                "that can result in lawsuits, settlements, and reputational damage."
            )
        )
