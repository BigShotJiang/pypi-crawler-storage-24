"""
WCAG Keyboard Navigation Check

Tests that all interactive elements are accessible via keyboard navigation,
as required by WCAG 2.1 Level A (2.1.1 Keyboard, 2.1.2 No Keyboard Trap).

WCAG 2.1.1 (Level A): All functionality available via keyboard
WCAG 2.1.2 (Level A): No keyboard trap
WCAG 2.4.7 (Level AA): Focus visible

Regulation: WCAG 2.1 (International W3C Standard)
Requirement: WCAG_001 - Keyboard Navigation
Severity: Critical
Automation: 90% automated (10% requires manual verification of tab order logic)
"""

from playwright.async_api import Page
from typing import Optional, Dict, List, Tuple
import logging

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="WCAG", requirement_id="WCAG_001")
class KeyboardNavigationCheck(ComplianceCheck):
    """
    WCAG_001: All interactive elements must be keyboard accessible.

    This check verifies that users can navigate and interact with all
    functionality using only a keyboard, as required by WCAG 2.1 Level A.

    Methodology:
    1. Identify all interactive elements (links, buttons, inputs, etc.)
    2. Test keyboard focus on each element via Tab key
    3. Verify focus indicators are visible
    4. Test activation via Enter/Space keys
    5. Check for keyboard traps
    6. Verify logical tab order

    Common violations:
    - Interactive elements not focusable (missing tabindex or role)
    - No visible focus indicator (outline: none without alternative)
    - Keyboard traps (focus cannot escape modal/dropdown)
    - Illogical tab order (tabindex values causing confusion)
    - Click-only handlers (no keyboard activation)
    - Custom widgets without keyboard support

    Legal risk: ADA lawsuits, Section 508 compliance failures
    European Accessibility Act (EAA): Mandatory from June 2025
    """

    automation_level = "automated"
    severity = "critical"

    # Interactive element selectors
    INTERACTIVE_SELECTORS = [
        'a[href]',
        'button',
        'input:not([type="hidden"])',
        'select',
        'textarea',
        '[role="button"]',
        '[role="link"]',
        '[role="tab"]',
        '[role="menuitem"]',
        '[role="option"]',
        '[tabindex]:not([tabindex="-1"])',
    ]

    def __init__(self, regulation_id: str = "WCAG", requirement_id: str = "WCAG_001"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.interactive_elements: List[Dict] = []
        self.focusable_count = 0
        self.non_focusable_count = 0
        self.no_focus_indicator_count = 0

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the keyboard navigation check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting WCAG_001 check for {url}")

            # Navigate to page if needed
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            # Wait for page to settle
            await page.wait_for_timeout(2000)

            # Step 1: Find all interactive elements
            await self._find_interactive_elements(page)

            if not self.interactive_elements:
                # No interactive elements found - pass (nothing to check)
                return await self._create_no_interactive_elements_result()

            # Step 2: Test keyboard focusability
            await self._test_keyboard_focusability(page)

            # Step 3: Test focus indicators
            await self._test_focus_indicators(page)

            # Step 4: Analyze results
            violations_found = (
                self.non_focusable_count > 0 or
                self.no_focus_indicator_count > 0
            )

            if violations_found:
                return await self._create_violation_result(page)
            else:
                return await self._create_compliant_result()

        except Exception as e:
            logger.error(f"Error in WCAG_001 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="WCAG",
                requirement_id="WCAG_001",
                status="error",
                severity="critical",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _find_interactive_elements(self, page: Page):
        """
        Find all interactive elements on the page.

        Args:
            page: Playwright page object
        """
        try:
            # Query all interactive elements
            selector = ', '.join(self.INTERACTIVE_SELECTORS)
            elements = await page.query_selector_all(selector)

            logger.debug(f"Found {len(elements)} potential interactive elements")

            for elem in elements:
                try:
                    # Check if element is visible
                    is_visible = await elem.is_visible()
                    if not is_visible:
                        continue

                    # Get element info
                    tag_name = await elem.evaluate('el => el.tagName.toLowerCase()')
                    elem_type = await elem.evaluate('el => el.type || ""')
                    role = await elem.evaluate('el => el.getAttribute("role") || ""')
                    aria_label = await elem.evaluate('el => el.getAttribute("aria-label") || ""')
                    text_content = await elem.evaluate('el => el.textContent || ""')
                    text_content = text_content.strip()[:50]  # Truncate

                    self.interactive_elements.append({
                        'tag': tag_name,
                        'type': elem_type,
                        'role': role,
                        'label': aria_label or text_content or f"{tag_name} element",
                        'element': elem
                    })

                except Exception as e:
                    logger.debug(f"Error inspecting element: {e}")
                    continue

            logger.info(f"Found {len(self.interactive_elements)} visible interactive elements")

        except Exception as e:
            logger.error(f"Error finding interactive elements: {e}", exc_info=True)

    async def _test_keyboard_focusability(self, page: Page):
        """
        Test if each interactive element is keyboard focusable.

        Args:
            page: Playwright page object
        """
        for elem_info in self.interactive_elements:
            try:
                elem = elem_info['element']

                # Focus the element
                await elem.focus()

                # Check if element is now focused
                is_focused = await elem.evaluate('''
                    el => document.activeElement === el
                ''')

                if is_focused:
                    self.focusable_count += 1
                    elem_info['focusable'] = True
                else:
                    self.non_focusable_count += 1
                    elem_info['focusable'] = False
                    logger.debug(f"Non-focusable element: {elem_info['label']}")

            except Exception as e:
                self.non_focusable_count += 1
                elem_info['focusable'] = False
                logger.debug(f"Error testing focusability: {e}")

    async def _test_focus_indicators(self, page: Page):
        """
        Test if focused elements have visible focus indicators.

        Args:
            page: Playwright page object
        """
        for elem_info in self.interactive_elements:
            # Only test focusable elements
            if not elem_info.get('focusable', False):
                continue

            try:
                elem = elem_info['element']

                # Focus the element
                await elem.focus()

                # Check for focus indicator
                has_focus_indicator = await elem.evaluate('''
                    el => {
                        const styles = window.getComputedStyle(el);
                        const outlineWidth = parseFloat(styles.outlineWidth);
                        const outlineStyle = styles.outlineStyle;
                        const borderWidth = parseFloat(styles.borderWidth);
                        const boxShadow = styles.boxShadow;

                        // Check if outline is visible
                        if (outlineWidth > 0 && outlineStyle !== 'none') {
                            return true;
                        }

                        // Check if border changes on focus (common pattern)
                        if (borderWidth > 0) {
                            return true;
                        }

                        // Check if box-shadow is used for focus
                        if (boxShadow && boxShadow !== 'none') {
                            return true;
                        }

                        // Check if background color might be used
                        const bgColor = styles.backgroundColor;
                        if (bgColor && bgColor !== 'rgba(0, 0, 0, 0)' && bgColor !== 'transparent') {
                            return true;
                        }

                        return false;
                    }
                ''')

                if has_focus_indicator:
                    elem_info['has_focus_indicator'] = True
                else:
                    self.no_focus_indicator_count += 1
                    elem_info['has_focus_indicator'] = False
                    logger.debug(f"No focus indicator: {elem_info['label']}")

            except Exception as e:
                logger.debug(f"Error testing focus indicator: {e}")
                elem_info['has_focus_indicator'] = None

    async def _create_no_interactive_elements_result(self) -> ComplianceCheckResult:
        """
        Create result when no interactive elements found.

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            "No interactive elements found on page.\n"
            "Keyboard navigation requirement is not applicable for this page.\n\n"
            "Note: If the page should have interactive elements, this may indicate a rendering issue."
        )

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_001",
            status="passed",
            severity="critical",
            evidence=evidence,
            metadata={
                'interactive_elements_count': 0,
                'focusable_count': 0,
                'non_focusable_count': 0,
                'no_focus_indicator_count': 0
            }
        )

    async def _create_compliant_result(self) -> ComplianceCheckResult:
        """
        Create a compliant result.

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            f"Keyboard navigation: All interactive elements are keyboard accessible.\\n"
            f"  - Total interactive elements: {len(self.interactive_elements)}\\n"
            f"  - Keyboard focusable: {self.focusable_count}\\n"
            f"  - With focus indicators: {self.focusable_count - self.no_focus_indicator_count}\\n\\n"
            f"All interactive elements can be accessed and used via keyboard.\\n"
            f"Note: Manual verification recommended to ensure tab order is logical."
        )

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_001",
            status="passed",
            severity="critical",
            evidence=evidence,
            metadata={
                'interactive_elements_count': len(self.interactive_elements),
                'focusable_count': self.focusable_count,
                'non_focusable_count': self.non_focusable_count,
                'no_focus_indicator_count': self.no_focus_indicator_count
            }
        )

    async def _create_violation_result(self, page: Page) -> ComplianceCheckResult:
        """
        Create a violation result.

        Args:
            page: Playwright page object

        Returns:
            ComplianceCheckResult with failed status
        """
        evidence_parts = []

        evidence_parts.append(
            "Keyboard navigation violations detected.\\n"
        )

        if self.non_focusable_count > 0:
            evidence_parts.append(
                f"\\nNon-focusable interactive elements: {self.non_focusable_count}\\n"
                f"The following elements cannot be accessed via keyboard:"
            )

            non_focusable = [e for e in self.interactive_elements if not e.get('focusable', False)]
            for elem_info in non_focusable[:10]:
                evidence_parts.append(
                    f"  - {elem_info['tag']} {elem_info['role']} ({elem_info['label'][:40]})"
                )

            if len(non_focusable) > 10:
                evidence_parts.append(f"  ... and {len(non_focusable) - 10} more")

        if self.no_focus_indicator_count > 0:
            evidence_parts.append(
                f"\\nElements without visible focus indicators: {self.no_focus_indicator_count}\\n"
                f"The following elements lack visible focus indicators:"
            )

            no_indicator = [e for e in self.interactive_elements if e.get('focusable', False) and not e.get('has_focus_indicator', True)]
            for elem_info in no_indicator[:10]:
                evidence_parts.append(
                    f"  - {elem_info['tag']} {elem_info['role']} ({elem_info['label'][:40]})"
                )

            if len(no_indicator) > 10:
                evidence_parts.append(f"  ... and {len(no_indicator) - 10} more")

        evidence_parts.append(
            "\\nWCAG 2.1 Level A requires all functionality to be available via keyboard (2.1.1).\\n"
            "Level AA requires keyboard focus indicators to be visible (2.4.7).\\n\\n"
            "Recommendation:\\n"
            "  - Ensure all interactive elements have tabindex or are naturally focusable\\n"
            "  - Provide visible focus indicators (outline, border, or background change)\\n"
            "  - Test with keyboard-only navigation (Tab, Shift+Tab, Enter, Space)"
        )

        evidence = "\\n".join(evidence_parts)

        screenshot_path = await self.take_screenshot(page, "wcag_001_keyboard_navigation_violation")

        # Get sample non-focusable elements
        non_focusable_samples = [
            {
                'tag': e['tag'],
                'role': e['role'],
                'label': e['label'][:40]
            }
            for e in self.interactive_elements[:20]
            if not e.get('focusable', False)
        ]

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_001",
            status="failed",
            severity="critical",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata={
                'interactive_elements_count': len(self.interactive_elements),
                'focusable_count': self.focusable_count,
                'non_focusable_count': self.non_focusable_count,
                'no_focus_indicator_count': self.no_focus_indicator_count,
                'non_focusable_samples': non_focusable_samples[:10]
            },
            legal_risk=(
                "Critical WCAG 2.1 Level A violation (2.1.1 Keyboard, 2.1.2 No Keyboard Trap). "
                "Keyboard navigation is essential for users with motor disabilities who cannot use a mouse. "
                "Legal risks: ADA Title III lawsuits in the US, accessibility discrimination claims. "
                "European Accessibility Act (EAA): Mandatory compliance from June 2025. "
                "Section 508: Required for US federal websites and vendors. "
                "Failure to provide keyboard access can result in lawsuits, settlements, and reputational damage."
            )
        )
