"""
WCAG Text Spacing Check

Tests that content does not break or lose functionality when text spacing is adjusted,
as required by WCAG 2.1 Level AA (1.4.12 Text Spacing).

WCAG 1.4.12 (Level AA): Content can be presented without loss of information or functionality
when the following text spacing adjustments are applied:
- Line height (line spacing) at least 1.5 times the font size
- Spacing following paragraphs at least 2 times the font size
- Letter spacing (tracking) at least 0.12 times the font size
- Word spacing at least 0.16 times the font size

Regulation: WCAG 2.1 (International W3C Standard)
Requirement: WCAG_008 - Text Spacing
Severity: Medium
Automation: 85% automated (15% requires manual verification of content meaning)
"""

from playwright.async_api import Page
from typing import Dict, List, Optional
import logging

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="WCAG", requirement_id="WCAG_008")
class TextSpacingCheck(ComplianceCheck):
    """
    WCAG_008: Content must not break when text spacing is adjusted.

    This check verifies that content remains readable and functional when users
    adjust text spacing for better readability, as required by WCAG 2.1 Level AA.

    Methodology:
    1. Take baseline screenshot of page
    2. Inject CSS to apply WCAG text spacing requirements:
       - line-height: 1.5em
       - letter-spacing: 0.12em
       - word-spacing: 0.16em
       - paragraph spacing: 2em (via margin-bottom)
    3. Wait for layout to settle
    4. Check for common breakage patterns:
       - Text overflow/clipping
       - Overlapping elements
       - Hidden content
       - Broken layouts
    5. Take screenshot with adjusted spacing
    6. Report any detected issues

    Common violations:
    - Fixed height containers that clip text
    - Absolute positioning causing overlaps
    - Truncated text in buttons or navigation
    - Content hidden by overflow: hidden
    - Fixed width containers breaking layout
    - Line-height set with !important
    - CSS preventing user stylesheet overrides

    Legal risk: ADA lawsuits, accessibility for users with dyslexia
    European Accessibility Act (EAA): Mandatory from June 2025
    """

    automation_level = "automated"
    severity = "medium"

    # WCAG 1.4.12 required text spacing
    TEXT_SPACING_CSS = '''
        * {
            line-height: 1.5 !important;
            letter-spacing: 0.12em !important;
            word-spacing: 0.16em !important;
        }
        p {
            margin-bottom: 2em !important;
        }
    '''

    def __init__(self, regulation_id: str = "WCAG", requirement_id: str = "WCAG_008"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.baseline_height = 0
        self.adjusted_height = 0
        self.overflow_elements = []
        self.clipped_elements = []

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the text spacing check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting WCAG_008 check for {url}")

            # Navigate to page if needed
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            # Wait for page to settle
            await page.wait_for_timeout(2000)

            # Step 1: Capture baseline state
            await self._capture_baseline(page)

            # Step 2: Apply text spacing adjustments
            await self._apply_text_spacing(page)

            # Step 3: Check for breakage
            await self._check_for_breakage(page)

            # Step 4: Analyze results
            violations_found = (
                len(self.overflow_elements) > 0 or
                len(self.clipped_elements) > 0
            )

            if violations_found:
                return await self._create_violation_result(page)
            else:
                return await self._create_compliant_result(page)

        except Exception as e:
            logger.error(f"Error in WCAG_008 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="WCAG",
                requirement_id="WCAG_008",
                status="error",
                severity="medium",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _capture_baseline(self, page: Page):
        """
        Capture baseline page state before applying text spacing.

        Args:
            page: Playwright page object
        """
        try:
            # Get baseline page height
            self.baseline_height = await page.evaluate('document.body.scrollHeight')
            logger.debug(f"Baseline page height: {self.baseline_height}px")

        except Exception as e:
            logger.error(f"Error capturing baseline: {e}", exc_info=True)

    async def _apply_text_spacing(self, page: Page):
        """
        Apply WCAG text spacing requirements via injected CSS.

        Args:
            page: Playwright page object
        """
        try:
            # Inject text spacing CSS
            await page.add_style_tag(content=self.TEXT_SPACING_CSS)

            # Wait for layout to settle
            await page.wait_for_timeout(1000)

            # Get adjusted page height
            self.adjusted_height = await page.evaluate('document.body.scrollHeight')
            logger.debug(f"Adjusted page height: {self.adjusted_height}px")

            height_increase = self.adjusted_height - self.baseline_height
            height_increase_pct = (height_increase / self.baseline_height * 100) if self.baseline_height > 0 else 0
            logger.info(f"Page height increased by {height_increase}px ({height_increase_pct:.1f}%)")

        except Exception as e:
            logger.error(f"Error applying text spacing: {e}", exc_info=True)

    async def _check_for_breakage(self, page: Page):
        """
        Check for common breakage patterns after text spacing adjustment.

        Args:
            page: Playwright page object
        """
        try:
            # Check for overflow and clipping issues
            breakage_info = await page.evaluate('''
                () => {
                    const overflowElements = [];
                    const clippedElements = [];

                    // Check all visible elements for overflow/clipping
                    const allElements = document.querySelectorAll('*');

                    for (const el of allElements) {
                        // Skip hidden elements
                        const styles = window.getComputedStyle(el);
                        if (styles.display === 'none' || styles.visibility === 'hidden') {
                            continue;
                        }

                        // Check for overflow: hidden which might clip content
                        if (styles.overflow === 'hidden' || styles.overflowY === 'hidden') {
                            // Check if content is actually clipped
                            if (el.scrollHeight > el.clientHeight + 5) {
                                clippedElements.push({
                                    tag: el.tagName.toLowerCase(),
                                    className: el.className || '',
                                    id: el.id || '',
                                    textContent: (el.textContent || '').trim().substring(0, 50),
                                    scrollHeight: el.scrollHeight,
                                    clientHeight: el.clientHeight,
                                    clippedBy: el.scrollHeight - el.clientHeight
                                });
                            }
                        }

                        // Check for text-overflow: ellipsis
                        if (styles.textOverflow === 'ellipsis') {
                            if (el.scrollWidth > el.clientWidth + 5) {
                                overflowElements.push({
                                    tag: el.tagName.toLowerCase(),
                                    className: el.className || '',
                                    id: el.id || '',
                                    textContent: (el.textContent || '').trim().substring(0, 50)
                                });
                            }
                        }
                    }

                    return {
                        overflowElements: overflowElements.slice(0, 20),
                        clippedElements: clippedElements.slice(0, 20)
                    };
                }
            ''')

            self.overflow_elements = breakage_info['overflowElements']
            self.clipped_elements = breakage_info['clippedElements']

            logger.info(f"Found {len(self.overflow_elements)} overflow elements")
            logger.info(f"Found {len(self.clipped_elements)} clipped elements")

        except Exception as e:
            logger.error(f"Error checking for breakage: {e}", exc_info=True)

    async def _create_compliant_result(self, page: Page) -> ComplianceCheckResult:
        """
        Create a compliant result.

        Args:
            page: Playwright page object

        Returns:
            ComplianceCheckResult with passed status
        """
        screenshot_path = await self.take_screenshot(page, "wcag_008_text_spacing_adjusted")

        height_increase = self.adjusted_height - self.baseline_height
        height_increase_pct = (height_increase / self.baseline_height * 100) if self.baseline_height > 0 else 0

        evidence = (
            f"Text spacing: Content adapts to adjusted text spacing without breakage.\n"
            f"  - Baseline page height: {self.baseline_height}px\n"
            f"  - Adjusted page height: {self.adjusted_height}px\n"
            f"  - Height increase: {height_increase}px ({height_increase_pct:.1f}%)\n"
            f"  - Clipped elements: {len(self.clipped_elements)}\n"
            f"  - Overflow elements: {len(self.overflow_elements)}\n\n"
            f"Content remains readable and functional with WCAG text spacing applied:\n"
            f"  - Line height: 1.5em\n"
            f"  - Letter spacing: 0.12em\n"
            f"  - Word spacing: 0.16em\n"
            f"  - Paragraph spacing: 2em\n\n"
            f"Users with dyslexia and low vision can adjust text spacing for better readability.\n\n"
            f"Note: Manual verification recommended to ensure content meaning is preserved."
        )

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_008",
            status="passed",
            severity="medium",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata={
                'baseline_height': self.baseline_height,
                'adjusted_height': self.adjusted_height,
                'height_increase': height_increase,
                'height_increase_pct': round(height_increase_pct, 1),
                'clipped_count': len(self.clipped_elements),
                'overflow_count': len(self.overflow_elements)
            }
        )

    async def _create_violation_result(self, page: Page) -> ComplianceCheckResult:
        """
        Create a violation result.

        Args:
            page: Playwright page object

        Returns:
            ComplianceCheckResult with failed status
        """
        evidence_parts = []

        evidence_parts.append(
            "Text spacing violations detected.\n"
            "Content breaks or loses functionality when text spacing is adjusted.\n"
        )

        if len(self.clipped_elements) > 0:
            evidence_parts.append(
                f"\nElements with clipped content: {len(self.clipped_elements)}\n"
                f"The following elements have content clipped by overflow: hidden:"
            )

            for elem_info in self.clipped_elements[:10]:
                identifier = elem_info['textContent'] or elem_info['id'] or elem_info['className']
                clipped_by = elem_info.get('clippedBy', 0)
                evidence_parts.append(
                    f"  - {elem_info['tag']} ({identifier[:40]}) - clipped by {clipped_by}px"
                )

            if len(self.clipped_elements) > 10:
                evidence_parts.append(f"  ... and {len(self.clipped_elements) - 10} more")

        if len(self.overflow_elements) > 0:
            evidence_parts.append(
                f"\nElements with text overflow: {len(self.overflow_elements)}\n"
                f"The following elements have text truncated with ellipsis:"
            )

            for elem_info in self.overflow_elements[:10]:
                identifier = elem_info['textContent'] or elem_info['id'] or elem_info['className']
                evidence_parts.append(
                    f"  - {elem_info['tag']} ({identifier[:40]})"
                )

            if len(self.overflow_elements) > 10:
                evidence_parts.append(f"  ... and {len(self.overflow_elements) - 10} more")

        evidence_parts.append(
            "\nWCAG 2.1 Level AA requires content to adapt to text spacing adjustments (1.4.12).\n\n"
            "Required text spacing support:\n"
            "  - Line height: at least 1.5 times font size\n"
            "  - Letter spacing: at least 0.12 times font size\n"
            "  - Word spacing: at least 0.16 times font size\n"
            "  - Paragraph spacing: at least 2 times font size\n\n"
            "Recommendation:\n"
            "  - Avoid fixed heights on text containers - use min-height instead\n"
            "  - Avoid overflow: hidden on containers with text content\n"
            "  - Do not use !important on line-height, letter-spacing, word-spacing\n"
            "  - Allow containers to expand when text spacing increases\n"
            "  - Test with browser extensions that adjust text spacing\n"
            "  - Ensure critical content is not clipped or hidden"
        )

        evidence = "\n".join(evidence_parts)

        screenshot_path = await self.take_screenshot(page, "wcag_008_text_spacing_violation")

        height_increase = self.adjusted_height - self.baseline_height
        height_increase_pct = (height_increase / self.baseline_height * 100) if self.baseline_height > 0 else 0

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_008",
            status="failed",
            severity="medium",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata={
                'baseline_height': self.baseline_height,
                'adjusted_height': self.adjusted_height,
                'height_increase': height_increase,
                'height_increase_pct': round(height_increase_pct, 1),
                'clipped_count': len(self.clipped_elements),
                'overflow_count': len(self.overflow_elements),
                'clipped_elements': self.clipped_elements[:10],
                'overflow_elements': self.overflow_elements[:10]
            },
            legal_risk=(
                "Medium WCAG 2.1 Level AA violation (1.4.12 Text Spacing). "
                "Users with dyslexia, low vision, and other reading difficulties rely on adjusting text spacing "
                "to improve readability. When content breaks or becomes clipped with adjusted spacing, "
                "these users cannot access the information. This particularly affects users who need "
                "increased line spacing and letter spacing to read comfortably. "
                "Legal risks: ADA Title III lawsuits in the US, accessibility discrimination claims. "
                "European Accessibility Act (EAA): Mandatory compliance from June 2025. "
                "Section 508: Required for US federal websites and vendors. "
                "Fixed heights and overflow: hidden are common causes of text spacing violations."
            )
        )
