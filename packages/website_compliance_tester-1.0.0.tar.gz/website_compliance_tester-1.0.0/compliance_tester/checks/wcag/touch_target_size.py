"""
WCAG Touch Target Size Check

Tests that interactive elements meet minimum touch target size requirements,
as required by WCAG 2.1 Level AAA (2.5.5) and WCAG 2.2 Level AA (2.5.8).

WCAG 2.5.5 (Level AAA - WCAG 2.1): Target size is at least 44x44 CSS pixels
WCAG 2.5.8 (Level AA - WCAG 2.2): Target size is at least 24x24 CSS pixels

Regulation: WCAG 2.1/2.2 (International W3C Standard)
Requirement: WCAG_007 - Touch Target Size
Severity: High (becoming Critical with EAA compliance)
Automation: 100% automated
"""

from playwright.async_api import Page
from typing import Dict, List, Tuple
import logging

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="WCAG", requirement_id="WCAG_007")
class TouchTargetSizeCheck(ComplianceCheck):
    """
    WCAG_007: Interactive elements must meet minimum touch target size.

    This check verifies that touch targets are large enough for users with
    motor disabilities, as required by WCAG 2.2 Level AA (2.5.8).

    Methodology:
    1. Identify all interactive elements (links, buttons, inputs, etc.)
    2. Measure bounding box dimensions (width × height)
    3. Check for minimum 24×24 CSS pixels (WCAG 2.2 AA)
    4. Optionally check for 44×44 CSS pixels (WCAG 2.1 AAA / mobile best practice)
    5. Report elements that are too small
    6. Check for adequate spacing between small targets

    Common violations:
    - Icon buttons smaller than 24×24px
    - Text links with small font sizes
    - Close buttons (×) that are too small
    - Pagination links with insufficient size
    - Social media icons too small
    - Mobile hamburger menu icons undersized
    - Checkbox/radio labels not clickable

    Legal risk: ADA lawsuits, mobile accessibility failures
    European Accessibility Act (EAA): Mandatory from June 2025
    Mobile users with motor disabilities significantly affected
    """

    automation_level = "automated"
    severity = "high"

    # Minimum sizes (CSS pixels)
    MIN_SIZE_AA = 24  # WCAG 2.2 Level AA
    MIN_SIZE_AAA = 44  # WCAG 2.1 Level AAA / mobile best practice

    # Interactive element selectors
    INTERACTIVE_SELECTORS = [
        'a[href]',
        'button',
        'input[type="button"]',
        'input[type="submit"]',
        'input[type="reset"]',
        'input[type="checkbox"]',
        'input[type="radio"]',
        '[role="button"]',
        '[role="link"]',
        '[role="tab"]',
        '[role="menuitem"]',
        '[role="option"]',
        '[onclick]',
    ]

    def __init__(self, regulation_id: str = "WCAG", requirement_id: str = "WCAG_007"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.interactive_elements: List[Dict] = []
        self.compliant_count = 0
        self.too_small_aa_count = 0
        self.too_small_aaa_count = 0
        self.total_interactive = 0

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the touch target size check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting WCAG_007 check for {url}")

            # Navigate to page if needed
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            # Wait for page to settle
            await page.wait_for_timeout(2000)

            # Step 1: Find all interactive elements
            await self._find_interactive_elements(page)

            if not self.interactive_elements:
                # No interactive elements found - pass (nothing to check)
                return await self._create_no_elements_result()

            # Step 2: Measure touch target sizes
            await self._measure_target_sizes(page)

            # Step 3: Analyze results
            violations_found = self.too_small_aa_count > 0

            if violations_found:
                return await self._create_violation_result(page)
            else:
                return await self._create_compliant_result()

        except Exception as e:
            logger.error(f"Error in WCAG_007 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="WCAG",
                requirement_id="WCAG_007",
                status="error",
                severity="high",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _find_interactive_elements(self, page: Page):
        """
        Find all interactive elements on the page.

        Args:
            page: Playwright page object
        """
        try:
            # Query all interactive elements
            selector = ', '.join(self.INTERACTIVE_SELECTORS)
            elements = await page.query_selector_all(selector)

            logger.debug(f"Found {len(elements)} potential interactive elements")

            for elem in elements:
                try:
                    # Check if element is visible
                    is_visible = await elem.is_visible()
                    if not is_visible:
                        continue

                    # Get element info
                    elem_info = await elem.evaluate('''
                        el => {
                            return {
                                tag: el.tagName.toLowerCase(),
                                type: el.type || "",
                                role: el.getAttribute("role") || "",
                                ariaLabel: el.getAttribute("aria-label") || "",
                                textContent: (el.textContent || "").trim().substring(0, 50),
                                id: el.id || "",
                                className: el.className || ""
                            };
                        }
                    ''')

                    elem_info['element'] = elem
                    self.interactive_elements.append(elem_info)

                except Exception as e:
                    logger.debug(f"Error inspecting interactive element: {e}")
                    continue

            self.total_interactive = len(self.interactive_elements)
            logger.info(f"Found {self.total_interactive} visible interactive elements")

        except Exception as e:
            logger.error(f"Error finding interactive elements: {e}", exc_info=True)

    async def _measure_target_sizes(self, page: Page):
        """
        Measure the touch target size of each interactive element.

        Args:
            page: Playwright page object
        """
        for elem_info in self.interactive_elements:
            try:
                elem = elem_info['element']

                # Get bounding box
                box = await elem.bounding_box()

                if not box:
                    logger.debug(f"Could not get bounding box for element: {elem_info['textContent'][:40]}")
                    continue

                width = box['width']
                height = box['height']

                # Store dimensions
                elem_info['width'] = width
                elem_info['height'] = height

                # Check against AA standard (24×24)
                meets_aa = width >= self.MIN_SIZE_AA and height >= self.MIN_SIZE_AA

                # Check against AAA standard (44×44)
                meets_aaa = width >= self.MIN_SIZE_AAA and height >= self.MIN_SIZE_AAA

                elem_info['meets_aa'] = meets_aa
                elem_info['meets_aaa'] = meets_aaa

                if meets_aa:
                    self.compliant_count += 1
                    logger.debug(f"Compliant size {width:.1f}×{height:.1f}: {elem_info['textContent'][:40]}")
                else:
                    self.too_small_aa_count += 1
                    logger.debug(f"Too small {width:.1f}×{height:.1f} (need 24×24): {elem_info['textContent'][:40]}")

                if not meets_aaa:
                    self.too_small_aaa_count += 1

            except Exception as e:
                logger.debug(f"Error measuring target size: {e}")

    async def _create_no_elements_result(self) -> ComplianceCheckResult:
        """
        Create result when no interactive elements found.

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            "No interactive elements found on page.\n"
            "Touch target size requirement is not applicable for this page.\n\n"
            "Note: If the page should have interactive elements, this may indicate a rendering issue."
        )

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_007",
            status="passed",
            severity="high",
            evidence=evidence,
            metadata={
                'total_interactive': 0,
                'compliant_count': 0,
                'too_small_aa_count': 0,
                'too_small_aaa_count': 0
            }
        )

    async def _create_compliant_result(self) -> ComplianceCheckResult:
        """
        Create a compliant result.

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            f"Touch target sizes: All interactive elements meet minimum size requirements.\n"
            f"  - Total interactive elements: {self.total_interactive}\n"
            f"  - Meeting AA standard (24×24px): {self.compliant_count}\n"
            f"  - Meeting AAA standard (44×44px): {self.total_interactive - self.too_small_aaa_count}\n"
            f"  - Too small for AA (<24×24px): {self.too_small_aa_count}\n\n"
            f"All interactive elements meet WCAG 2.2 Level AA minimum size (24×24 CSS pixels).\n"
            f"Users with motor disabilities can accurately tap/click targets."
        )

        if self.too_small_aaa_count > 0:
            evidence += (
                f"\n\nNote: {self.too_small_aaa_count} elements are smaller than the AAA standard (44×44px).\n"
                f"Consider increasing touch target sizes to 44×44px for better mobile accessibility."
            )

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_007",
            status="passed",
            severity="high",
            evidence=evidence,
            metadata={
                'total_interactive': self.total_interactive,
                'compliant_count': self.compliant_count,
                'too_small_aa_count': self.too_small_aa_count,
                'too_small_aaa_count': self.too_small_aaa_count,
                'min_size_aa': self.MIN_SIZE_AA,
                'min_size_aaa': self.MIN_SIZE_AAA
            }
        )

    async def _create_violation_result(self, page: Page) -> ComplianceCheckResult:
        """
        Create a violation result.

        Args:
            page: Playwright page object

        Returns:
            ComplianceCheckResult with failed status
        """
        evidence_parts = []

        evidence_parts.append(
            "Touch target size violations detected.\n"
        )

        if self.too_small_aa_count > 0:
            evidence_parts.append(
                f"\nInteractive elements smaller than 24×24px: {self.too_small_aa_count}\n"
                f"The following elements are too small for WCAG 2.2 Level AA:"
            )

            too_small = [e for e in self.interactive_elements if not e.get('meets_aa', True)]
            for elem_info in too_small[:15]:
                identifier = elem_info['textContent'] or elem_info['ariaLabel'] or f"{elem_info['tag']}"
                width = elem_info.get('width', 0)
                height = elem_info.get('height', 0)
                evidence_parts.append(
                    f"  - {elem_info['tag']} {elem_info['role']} "
                    f"({width:.1f}×{height:.1f}px) - {identifier[:40]}"
                )

            if len(too_small) > 15:
                evidence_parts.append(f"  ... and {len(too_small) - 15} more")

        evidence_parts.append(
            f"\nWCAG 2.2 Level AA requires touch targets to be at least 24×24 CSS pixels (2.5.8).\n"
            f"WCAG 2.1 Level AAA recommends 44×44 CSS pixels (2.5.5).\n\n"
            f"Recommendation:\n"
            f"  - Increase touch target size to minimum 24×24 CSS pixels\n"
            f"  - For mobile-first design, aim for 44×44 CSS pixels\n"
            f"  - Add padding around small icons to increase clickable area\n"
            f"  - Ensure adequate spacing between adjacent targets\n"
            f"  - Make entire labels clickable for checkboxes and radio buttons\n"
            f"  - Test on mobile devices with actual fingers, not mouse clicks"
        )

        evidence = "\n".join(evidence_parts)

        screenshot_path = await self.take_screenshot(page, "wcag_007_touch_target_size_violation")

        # Get sample elements that are too small
        too_small_samples = [
            {
                'tag': e['tag'],
                'role': e['role'],
                'text': e['textContent'][:40],
                'width': e.get('width', 0),
                'height': e.get('height', 0)
            }
            for e in self.interactive_elements[:20]
            if not e.get('meets_aa', True)
        ]

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_007",
            status="failed",
            severity="high",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata={
                'total_interactive': self.total_interactive,
                'compliant_count': self.compliant_count,
                'too_small_aa_count': self.too_small_aa_count,
                'too_small_aaa_count': self.too_small_aaa_count,
                'min_size_aa': self.MIN_SIZE_AA,
                'min_size_aaa': self.MIN_SIZE_AAA,
                'too_small_samples': too_small_samples[:10]
            },
            legal_risk=(
                "High WCAG 2.2 Level AA violation (2.5.8 Target Size). "
                "Small touch targets prevent users with motor disabilities from accurately activating controls. "
                "This particularly affects mobile users, elderly users, and those with tremors or limited dexterity. "
                "Users may accidentally tap wrong elements or be unable to tap small targets at all. "
                "Legal risks: ADA Title III lawsuits in the US, accessibility discrimination claims. "
                "European Accessibility Act (EAA): Mandatory compliance from June 2025 - touch target size is critical for mobile. "
                "Section 508: Required for US federal websites and vendors. "
                "Mobile accessibility is increasingly scrutinized in legal cases. "
                "Minimum 24×24 CSS pixels required for AA compliance; 44×44 recommended for mobile."
            )
        )
