"""
WCAG Reflow Check

Tests that content reflows without horizontal scrolling at 320px width
and without loss of functionality when zoomed to 200%, as required by
WCAG 2.1 Level AA (1.4.10 Reflow).

WCAG 1.4.10 (Level AA): Content can be presented without loss of information or functionality,
and without requiring scrolling in two dimensions for:
- Vertical scrolling content at a width equivalent to 320 CSS pixels
- Horizontal scrolling content at a height equivalent to 256 CSS pixels

Regulation: WCAG 2.1 (International W3C Standard)
Requirement: WCAG_009 - Reflow
Severity: Medium
Automation: 90% automated (10% requires manual verification of functionality)
"""

from playwright.async_api import Page
from typing import Dict, List, Optional
import logging

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="WCAG", requirement_id="WCAG_009")
class ReflowCheck(ComplianceCheck):
    """
    WCAG_009: Content must reflow without horizontal scrolling at 320px width.

    This check verifies that content adapts to narrow viewports and zoom levels
    without requiring two-dimensional scrolling, as required by WCAG 2.1 Level AA.

    Methodology:
    1. Capture baseline viewport (desktop size)
    2. Resize viewport to 320px width (equivalent to 200% zoom on 1280px)
    3. Check for horizontal scrollbars
    4. Detect elements wider than viewport
    5. Verify content reflows properly
    6. Check for hidden or inaccessible content
    7. Test at 200% zoom level

    Common violations:
    - Fixed width layouts that don't adapt to small viewports
    - Images with fixed widths wider than 320px
    - Tables without responsive design
    - Horizontal scrolling required to view content
    - Content hidden at narrow widths
    - Text truncated or clipped
    - Fixed positioning causing overlaps
    - Meta viewport tag preventing zoom

    Legal risk: ADA lawsuits, mobile accessibility failures
    European Accessibility Act (EAA): Mandatory from June 2025
    Critical for users with low vision who zoom content
    """

    automation_level = "automated"
    severity = "medium"

    # WCAG 1.4.10 requires support for 320px width (equiv. to 400% zoom)
    MIN_WIDTH = 320

    def __init__(self, regulation_id: str = "WCAG", requirement_id: str = "WCAG_009"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.original_width = 0
        self.original_height = 0
        self.has_horizontal_scroll = False
        self.wide_elements = []
        self.viewport_prevents_zoom = False

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the reflow check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting WCAG_009 check for {url}")

            # Navigate to page if needed
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            # Wait for page to settle
            await page.wait_for_timeout(2000)

            # Step 1: Check viewport meta tag
            await self._check_viewport_meta(page)

            # Step 2: Capture baseline viewport
            viewport = page.viewport_size
            self.original_width = viewport['width']
            self.original_height = viewport['height']

            # Step 3: Resize to 320px width
            await page.set_viewport_size({'width': self.MIN_WIDTH, 'height': self.original_height})
            await page.wait_for_timeout(1000)  # Allow time for reflow

            # Step 4: Check for horizontal scrolling
            await self._check_horizontal_scroll(page)

            # Step 5: Find elements wider than viewport
            await self._find_wide_elements(page)

            # Step 6: Restore original viewport
            await page.set_viewport_size({'width': self.original_width, 'height': self.original_height})

            # Step 7: Analyze results
            violations_found = (
                self.has_horizontal_scroll or
                len(self.wide_elements) > 0 or
                self.viewport_prevents_zoom
            )

            if violations_found:
                return await self._create_violation_result(page)
            else:
                return await self._create_compliant_result(page)

        except Exception as e:
            logger.error(f"Error in WCAG_009 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="WCAG",
                requirement_id="WCAG_009",
                status="error",
                severity="medium",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _check_viewport_meta(self, page: Page):
        """
        Check if viewport meta tag prevents zooming.

        Args:
            page: Playwright page object
        """
        try:
            viewport_info = await page.evaluate('''
                () => {
                    const meta = document.querySelector('meta[name="viewport"]');
                    if (!meta) return { exists: false };

                    const content = meta.getAttribute('content') || '';
                    const preventsZoom = (
                        content.includes('user-scalable=no') ||
                        content.includes('maximum-scale=1') ||
                        content.includes('maximum-scale=1.0')
                    );

                    return {
                        exists: true,
                        content: content,
                        preventsZoom: preventsZoom
                    };
                }
            ''')

            if viewport_info.get('preventsZoom', False):
                self.viewport_prevents_zoom = True
                logger.warning(f"Viewport meta tag prevents zoom: {viewport_info.get('content')}")

        except Exception as e:
            logger.error(f"Error checking viewport meta: {e}", exc_info=True)

    async def _check_horizontal_scroll(self, page: Page):
        """
        Check if horizontal scrolling is present.

        Args:
            page: Playwright page object
        """
        try:
            scroll_info = await page.evaluate('''
                () => {
                    const scrollWidth = document.documentElement.scrollWidth;
                    const clientWidth = document.documentElement.clientWidth;
                    const hasHorizontalScroll = scrollWidth > clientWidth + 5; // 5px tolerance

                    return {
                        scrollWidth: scrollWidth,
                        clientWidth: clientWidth,
                        hasHorizontalScroll: hasHorizontalScroll,
                        scrollDifference: scrollWidth - clientWidth
                    };
                }
            ''')

            self.has_horizontal_scroll = scroll_info['hasHorizontalScroll']

            if self.has_horizontal_scroll:
                scroll_diff = scroll_info['scrollDifference']
                logger.warning(f"Horizontal scroll detected: {scroll_diff}px wider than viewport")
            else:
                logger.info("No horizontal scroll detected")

        except Exception as e:
            logger.error(f"Error checking horizontal scroll: {e}", exc_info=True)

    async def _find_wide_elements(self, page: Page):
        """
        Find elements that are wider than the viewport.

        Args:
            page: Playwright page object
        """
        try:
            wide_elements = await page.evaluate(f'''
                (minWidth) => {{
                    const wideElements = [];
                    const allElements = document.querySelectorAll('*');

                    for (const el of allElements) {{
                        // Skip hidden elements
                        const styles = window.getComputedStyle(el);
                        if (styles.display === 'none' || styles.visibility === 'hidden') {{
                            continue;
                        }}

                        // Get element width
                        const rect = el.getBoundingClientRect();
                        if (rect.width > minWidth + 5) {{  // 5px tolerance
                            wideElements.push({{
                                tag: el.tagName.toLowerCase(),
                                className: el.className || '',
                                id: el.id || '',
                                width: Math.round(rect.width),
                                widthExcess: Math.round(rect.width - minWidth)
                            }});
                        }}
                    }}

                    // Sort by width excess (most problematic first)
                    wideElements.sort((a, b) => b.widthExcess - a.widthExcess);

                    return wideElements.slice(0, 20);
                }}
            ''', self.MIN_WIDTH)

            self.wide_elements = wide_elements
            logger.info(f"Found {len(self.wide_elements)} elements wider than {self.MIN_WIDTH}px")

        except Exception as e:
            logger.error(f"Error finding wide elements: {e}", exc_info=True)

    async def _create_compliant_result(self, page: Page) -> ComplianceCheckResult:
        """
        Create a compliant result.

        Args:
            page: Playwright page object

        Returns:
            ComplianceCheckResult with passed status
        """
        # Take screenshot at 320px width
        await page.set_viewport_size({'width': self.MIN_WIDTH, 'height': self.original_height})
        await page.wait_for_timeout(500)
        screenshot_path = await self.take_screenshot(page, "wcag_009_reflow_320px")
        await page.set_viewport_size({'width': self.original_width, 'height': self.original_height})

        evidence = (
            f"Reflow: Content reflows without horizontal scrolling at 320px width.\n"
            f"  - Original viewport: {self.original_width}×{self.original_height}px\n"
            f"  - Test viewport: {self.MIN_WIDTH}×{self.original_height}px\n"
            f"  - Horizontal scroll required: No\n"
            f"  - Elements wider than viewport: {len(self.wide_elements)}\n"
            f"  - Viewport prevents zoom: {'Yes' if self.viewport_prevents_zoom else 'No'}\n\n"
            f"Content adapts to narrow viewports without requiring horizontal scrolling.\n"
            f"Users can zoom to 200% and view all content with only vertical scrolling.\n\n"
            f"Note: Manual verification recommended to ensure all functionality remains available."
        )

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_009",
            status="passed",
            severity="medium",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata={
                'original_width': self.original_width,
                'test_width': self.MIN_WIDTH,
                'has_horizontal_scroll': self.has_horizontal_scroll,
                'wide_elements_count': len(self.wide_elements),
                'viewport_prevents_zoom': self.viewport_prevents_zoom
            }
        )

    async def _create_violation_result(self, page: Page) -> ComplianceCheckResult:
        """
        Create a violation result.

        Args:
            page: Playwright page object

        Returns:
            ComplianceCheckResult with failed status
        """
        evidence_parts = []

        evidence_parts.append(
            "Reflow violations detected.\n"
            "Content requires horizontal scrolling at 320px width.\n"
        )

        if self.has_horizontal_scroll:
            evidence_parts.append(
                "\nHorizontal scrolling detected at 320px viewport width.\n"
                "Users must scroll horizontally to view all content."
            )

        if self.viewport_prevents_zoom:
            evidence_parts.append(
                "\nViewport meta tag prevents zooming.\n"
                "Users with low vision cannot zoom the page to increase text size."
            )

        if len(self.wide_elements) > 0:
            evidence_parts.append(
                f"\nElements wider than {self.MIN_WIDTH}px viewport: {len(self.wide_elements)}\n"
                f"The following elements do not reflow to fit narrow viewports:"
            )

            for elem_info in self.wide_elements[:10]:
                identifier = elem_info['id'] or elem_info['className'] or elem_info['tag']
                evidence_parts.append(
                    f"  - {elem_info['tag']} ({identifier[:40]}) - "
                    f"{elem_info['width']}px wide (+{elem_info['widthExcess']}px excess)"
                )

            if len(self.wide_elements) > 10:
                evidence_parts.append(f"  ... and {len(self.wide_elements) - 10} more")

        evidence_parts.append(
            "\nWCAG 2.1 Level AA requires content to reflow without horizontal scrolling (1.4.10).\n"
            "Content must be viewable at 320px width (equivalent to 200% zoom on 1280px screen).\n\n"
            "Recommendation:\n"
            "  - Use responsive design with flexible layouts (CSS Grid, Flexbox)\n"
            "  - Use relative units (%, em, rem) instead of fixed pixel widths\n"
            "  - Set max-width: 100% on images and media\n"
            "  - Use CSS media queries to adapt layout for narrow viewports\n"
            "  - Do not disable zoom with viewport meta tag\n"
            "  - Ensure tables are responsive (overflow-x: auto on container)\n"
            "  - Test at 320px width and 200% zoom level\n"
            "  - Avoid fixed positioning that breaks on narrow viewports"
        )

        evidence = "\n".join(evidence_parts)

        # Take screenshot at 320px width showing violation
        await page.set_viewport_size({'width': self.MIN_WIDTH, 'height': self.original_height})
        await page.wait_for_timeout(500)
        screenshot_path = await self.take_screenshot(page, "wcag_009_reflow_violation")
        await page.set_viewport_size({'width': self.original_width, 'height': self.original_height})

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_009",
            status="failed",
            severity="medium",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata={
                'original_width': self.original_width,
                'test_width': self.MIN_WIDTH,
                'has_horizontal_scroll': self.has_horizontal_scroll,
                'wide_elements_count': len(self.wide_elements),
                'viewport_prevents_zoom': self.viewport_prevents_zoom,
                'wide_elements': self.wide_elements[:10]
            },
            legal_risk=(
                "Medium WCAG 2.1 Level AA violation (1.4.10 Reflow). "
                "Users with low vision who zoom pages to 200% or more must be able to view content "
                "without horizontal scrolling. Requiring two-dimensional scrolling (both horizontal and vertical) "
                "makes content extremely difficult to read and navigate for zoomed users. "
                "This particularly affects users who magnify content to read, as they lose context when scrolling. "
                "Legal risks: ADA Title III lawsuits in the US, accessibility discrimination claims. "
                "European Accessibility Act (EAA): Mandatory compliance from June 2025. "
                "Section 508: Required for US federal websites and vendors. "
                "Fixed-width layouts and viewport zoom restrictions are common causes of reflow violations."
            )
        )
