"""
WCAG Form Input Purpose Check

Tests that common form inputs have appropriate autocomplete attributes,
as required by WCAG 2.1 Level AA (1.3.5 Identify Input Purpose).

WCAG 1.3.5 (Level AA): The purpose of input fields can be programmatically determined

Regulation: WCAG 2.1 (International W3C Standard)
Requirement: WCAG_004 - Form Input Purpose
Severity: High
Automation: 95% automated
"""

from playwright.async_api import Page
from typing import Dict, List
import logging
import re

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="WCAG", requirement_id="WCAG_004")
class FormInputPurposeCheck(ComplianceCheck):
    """
    WCAG_004: Form inputs should have autocomplete attributes.

    This check verifies that common input fields have autocomplete attributes
    to enable browser autofill, as required by WCAG 2.1 Level AA.

    Methodology:
    1. Identify form inputs that should have autocomplete
    2. Check for autocomplete attribute
    3. Verify autocomplete tokens are appropriate
    4. Report inputs missing autocomplete

    Common violations:
    - Email input without autocomplete="email"
    - Name fields without autocomplete="name", "given-name", "family-name"
    - Address fields without appropriate autocomplete tokens
    - Phone fields without autocomplete="tel"
    - Payment fields without autocomplete tokens

    Legal risk: WCAG Level AA violation, affects user experience
    European Accessibility Act (EAA): Mandatory from June 2025
    """

    automation_level = "automated"
    severity = "high"

    # Mapping of input types/names to expected autocomplete tokens
    AUTOCOMPLETE_PATTERNS = {
        'email': {
            'patterns': [r'email', r'e-mail', r'mail'],
            'tokens': ['email'],
            'description': 'Email address'
        },
        'name': {
            'patterns': [r'^name$', r'fullname', r'full.name', r'user.?name'],
            'tokens': ['name'],
            'description': 'Full name'
        },
        'given-name': {
            'patterns': [r'first.?name', r'given.?name', r'fname'],
            'tokens': ['given-name'],
            'description': 'First/given name'
        },
        'family-name': {
            'patterns': [r'last.?name', r'family.?name', r'surname', r'lname'],
            'tokens': ['family-name'],
            'description': 'Last/family name'
        },
        'tel': {
            'patterns': [r'phone', r'telephone', r'tel', r'mobile'],
            'tokens': ['tel', 'tel-national'],
            'description': 'Phone number'
        },
        'street-address': {
            'patterns': [r'address', r'street', r'addr'],
            'tokens': ['street-address', 'address-line1', 'address-line2'],
            'description': 'Street address'
        },
        'postal-code': {
            'patterns': [r'zip', r'postal', r'postcode', r'post.?code'],
            'tokens': ['postal-code'],
            'description': 'Postal/ZIP code'
        },
        'country': {
            'patterns': [r'country'],
            'tokens': ['country', 'country-name'],
            'description': 'Country'
        },
        'cc-number': {
            'patterns': [r'card.?number', r'cc.?number', r'credit.?card'],
            'tokens': ['cc-number'],
            'description': 'Credit card number'
        },
        'cc-exp': {
            'patterns': [r'exp', r'expir', r'card.?exp'],
            'tokens': ['cc-exp', 'cc-exp-month', 'cc-exp-year'],
            'description': 'Credit card expiration'
        },
        'current-password': {
            'patterns': [r'^password$', r'pass$', r'pwd'],
            'tokens': ['current-password'],
            'description': 'Current password'
        },
        'new-password': {
            'patterns': [r'new.?password', r'confirm.?password'],
            'tokens': ['new-password'],
            'description': 'New password'
        }
    }

    def __init__(self, regulation_id: str = "WCAG", requirement_id: str = "WCAG_004"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.form_inputs: List[Dict] = []
        self.inputs_needing_autocomplete = 0
        self.inputs_with_autocomplete = 0
        self.inputs_missing_autocomplete = 0

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the form input purpose check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting WCAG_004 check for {url}")

            # Navigate to page if needed
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            # Wait for page to settle
            await page.wait_for_timeout(2000)

            # Step 1: Find all form inputs
            await self._find_form_inputs(page)

            if not self.form_inputs:
                # No form inputs found - pass (nothing to check)
                return await self._create_no_inputs_result()

            # Step 2: Check autocomplete attributes
            await self._check_autocomplete(page)

            # Step 3: Analyze results
            if self.inputs_missing_autocomplete > 0:
                return await self._create_violation_result(page)
            else:
                return await self._create_compliant_result()

        except Exception as e:
            logger.error(f"Error in WCAG_004 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="WCAG",
                requirement_id="WCAG_004",
                status="error",
                severity="high",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _find_form_inputs(self, page: Page):
        """
        Find all form input elements on the page.

        Args:
            page: Playwright page object
        """
        try:
            # Query form inputs (excluding hidden, submit, button, reset)
            selector = 'input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="reset"]), select, textarea'
            elements = await page.query_selector_all(selector)

            logger.debug(f"Found {len(elements)} potential form inputs")

            for elem in elements:
                try:
                    # Check if element is visible
                    is_visible = await elem.is_visible()
                    if not is_visible:
                        continue

                    # Get element info
                    elem_info = await elem.evaluate('''
                        el => {
                            return {
                                tag: el.tagName.toLowerCase(),
                                type: el.type || "",
                                id: el.id || "",
                                name: el.name || "",
                                autocomplete: el.getAttribute("autocomplete") || "",
                                placeholder: el.placeholder || ""
                            };
                        }
                    ''')

                    elem_info['element'] = elem
                    elem_info['needs_autocomplete'] = False
                    elem_info['expected_autocomplete'] = None
                    elem_info['has_autocomplete'] = bool(elem_info['autocomplete'])

                    self.form_inputs.append(elem_info)

                except Exception as e:
                    logger.debug(f"Error inspecting form input: {e}")
                    continue

            logger.info(f"Found {len(self.form_inputs)} visible form inputs")

        except Exception as e:
            logger.error(f"Error finding form inputs: {e}", exc_info=True)

    async def _check_autocomplete(self, page: Page):
        """
        Check if form inputs have appropriate autocomplete attributes.

        Args:
            page: Playwright page object
        """
        for input_info in self.form_inputs:
            try:
                # Determine if this input should have autocomplete
                expected_purpose = self._determine_input_purpose(input_info)

                if expected_purpose:
                    input_info['needs_autocomplete'] = True
                    input_info['expected_autocomplete'] = expected_purpose
                    self.inputs_needing_autocomplete += 1

                    # Check if autocomplete is present
                    if input_info['autocomplete']:
                        # Verify it's one of the expected tokens
                        autocomplete_value = input_info['autocomplete'].lower().strip()
                        expected_tokens = self.AUTOCOMPLETE_PATTERNS[expected_purpose]['tokens']

                        if autocomplete_value in expected_tokens or autocomplete_value == 'on':
                            self.inputs_with_autocomplete += 1
                            input_info['autocomplete_valid'] = True
                            logger.debug(f"Valid autocomplete: {autocomplete_value} for {expected_purpose}")
                        else:
                            # Has autocomplete but wrong value
                            self.inputs_missing_autocomplete += 1
                            input_info['autocomplete_valid'] = False
                            logger.debug(f"Invalid autocomplete: {autocomplete_value} (expected: {expected_tokens})")
                    else:
                        # No autocomplete attribute
                        self.inputs_missing_autocomplete += 1
                        input_info['autocomplete_valid'] = False
                        logger.debug(f"Missing autocomplete for {expected_purpose} field")

            except Exception as e:
                logger.debug(f"Error checking autocomplete: {e}")

    def _determine_input_purpose(self, input_info: Dict) -> str:
        """
        Determine the expected purpose of an input based on its attributes.

        Args:
            input_info: Input element information

        Returns:
            Expected autocomplete purpose key, or None if not applicable
        """
        # Check input type first
        input_type = input_info['type'].lower()

        if input_type == 'email':
            return 'email'
        elif input_type == 'password':
            # Check if it's a new password or current password field
            name_lower = input_info['name'].lower()
            if 'new' in name_lower or 'confirm' in name_lower:
                return 'new-password'
            else:
                return 'current-password'
        elif input_type == 'tel':
            return 'tel'

        # Check name and id attributes for common patterns
        name = input_info['name'].lower()
        id_attr = input_info['id'].lower()
        placeholder = input_info['placeholder'].lower()

        search_text = f"{name} {id_attr} {placeholder}"

        for purpose, pattern_info in self.AUTOCOMPLETE_PATTERNS.items():
            for pattern in pattern_info['patterns']:
                if re.search(pattern, search_text, re.IGNORECASE):
                    return purpose

        return None

    async def _create_no_inputs_result(self) -> ComplianceCheckResult:
        """
        Create result when no form inputs found.

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            "No form inputs found on page.\n"
            "Autocomplete requirement is not applicable for this page."
        )

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_004",
            status="passed",
            severity="high",
            evidence=evidence,
            metadata={
                'form_inputs_count': 0,
                'inputs_needing_autocomplete': 0,
                'inputs_with_autocomplete': 0,
                'inputs_missing_autocomplete': 0
            }
        )

    async def _create_compliant_result(self) -> ComplianceCheckResult:
        """
        Create a compliant result.

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            f"Form input purpose: All applicable inputs have autocomplete attributes.\n"
            f"  - Total form inputs: {len(self.form_inputs)}\n"
            f"  - Inputs needing autocomplete: {self.inputs_needing_autocomplete}\n"
            f"  - With valid autocomplete: {self.inputs_with_autocomplete}\n"
            f"  - Missing autocomplete: {self.inputs_missing_autocomplete}\n\n"
            f"Common input fields have appropriate autocomplete attributes to enable browser autofill.\n"
            f"This improves usability for all users, especially those with motor or cognitive disabilities."
        )

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_004",
            status="passed",
            severity="high",
            evidence=evidence,
            metadata={
                'form_inputs_count': len(self.form_inputs),
                'inputs_needing_autocomplete': self.inputs_needing_autocomplete,
                'inputs_with_autocomplete': self.inputs_with_autocomplete,
                'inputs_missing_autocomplete': self.inputs_missing_autocomplete
            }
        )

    async def _create_violation_result(self, page: Page) -> ComplianceCheckResult:
        """
        Create a violation result.

        Args:
            page: Playwright page object

        Returns:
            ComplianceCheckResult with failed status
        """
        evidence_parts = []

        evidence_parts.append(
            "Form input purpose violations detected.\n"
        )

        evidence_parts.append(
            f"\nInputs missing autocomplete attributes: {self.inputs_missing_autocomplete}\n"
            f"The following inputs should have autocomplete to enable autofill:"
        )

        missing = [i for i in self.form_inputs
                   if i.get('needs_autocomplete') and not i.get('autocomplete_valid')]

        for input_info in missing[:15]:
            identifier = input_info['id'] or input_info['name'] or input_info['type']
            expected = input_info.get('expected_autocomplete', 'unknown')
            expected_tokens = self.AUTOCOMPLETE_PATTERNS.get(expected, {}).get('tokens', ['unknown'])
            current = input_info['autocomplete'] or '(none)'

            evidence_parts.append(
                f"  - {input_info['tag']} type={input_info['type']} ({identifier})"
            )
            evidence_parts.append(
                f"    Expected: autocomplete=\"{expected_tokens[0]}\" | Current: \"{current}\""
            )

        if len(missing) > 15:
            evidence_parts.append(f"  ... and {len(missing) - 15} more")

        evidence_parts.append(
            "\nWCAG 2.1 Level AA requires input purpose to be programmatically determinable (1.3.5).\n\n"
            "Recommendation:\n"
            "  - Add autocomplete attributes to email, name, address, phone, and payment fields\n"
            "  - Use standard autocomplete tokens: email, name, tel, street-address, etc.\n"
            "  - See: https://www.w3.org/TR/WCAG21/#input-purposes\n"
            "  - Enables browser autofill, benefiting users with motor or cognitive disabilities"
        )

        evidence = "\n".join(evidence_parts)

        screenshot_path = await self.take_screenshot(page, "wcag_004_form_input_purpose_violation")

        # Get sample missing inputs
        missing_samples = [
            {
                'tag': i['tag'],
                'type': i['type'],
                'id': i['id'],
                'name': i['name'],
                'expected': i.get('expected_autocomplete'),
                'current': i['autocomplete']
            }
            for i in missing[:10]
        ]

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_004",
            status="failed",
            severity="high",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata={
                'form_inputs_count': len(self.form_inputs),
                'inputs_needing_autocomplete': self.inputs_needing_autocomplete,
                'inputs_with_autocomplete': self.inputs_with_autocomplete,
                'inputs_missing_autocomplete': self.inputs_missing_autocomplete,
                'missing_samples': missing_samples
            },
            legal_risk=(
                "WCAG 2.1 Level AA violation (1.3.5 Identify Input Purpose). "
                "Missing autocomplete attributes prevents browser autofill, creating barriers for users "
                "with motor disabilities who cannot easily type, and users with cognitive disabilities "
                "who benefit from autofill assistance. "
                "Legal risks: Accessibility discrimination claims, European Accessibility Act (EAA) "
                "non-compliance from June 2025. While not as critical as Level A violations, Level AA "
                "requirements are increasingly expected for public-facing websites and may be required "
                "by procurement policies and accessibility standards."
            )
        )
