"""
WCAG Focus Order Check

Tests that keyboard focus order follows logical reading order and does not use
problematic positive tabindex values, as required by WCAG 2.1 Level A (2.4.3 Focus Order).

WCAG 2.4.3 (Level A): If a page can be navigated sequentially, focusable components receive focus
in an order that preserves meaning and operability

Regulation: WCAG 2.1 (International W3C Standard)
Requirement: WCAG_006 - Focus Order
Severity: High
Automation: 75% automated (25% requires manual verification of logical order)
"""

from playwright.async_api import Page
from typing import Dict, List, Optional
import logging

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="WCAG", requirement_id="WCAG_006")
class FocusOrderCheck(ComplianceCheck):
    """
    WCAG_006: Tab order must follow logical reading order.

    This check verifies that the keyboard focus order is logical and predictable,
    as required by WCAG 2.1 Level A (2.4.3).

    Methodology:
    1. Identify all focusable elements in DOM order
    2. Check for positive tabindex values (anti-pattern)
    3. Verify tabindex sequences are logical
    4. Detect elements with very high tabindex (> 100)
    5. Check for tabindex="0" mixed with positive values
    6. Analyze visual vs. DOM order mismatches (heuristic)

    Common violations:
    - Positive tabindex values (1, 2, 3...) creating maintenance issues
    - Very high tabindex values (9999) as workaround
    - tabindex="0" mixed with positive values causing confusion
    - CSS positioning causing visual order to differ from DOM order
    - Modal dialogs not managing focus properly
    - Dynamic content insertion disrupting tab order

    Legal risk: ADA lawsuits, Section 508 compliance failures
    European Accessibility Act (EAA): Mandatory from June 2025
    """

    automation_level = "automated"
    severity = "high"

    # Focusable element selectors
    FOCUSABLE_SELECTORS = [
        'a[href]',
        'button',
        'input:not([type="hidden"])',
        'select',
        'textarea',
        '[tabindex]',
        '[role="button"]',
        '[role="link"]',
        '[role="tab"]',
        '[role="menuitem"]',
    ]

    def __init__(self, regulation_id: str = "WCAG", requirement_id: str = "WCAG_006"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.focusable_elements: List[Dict] = []
        self.positive_tabindex_count = 0
        self.high_tabindex_count = 0
        self.mixed_tabindex_count = 0
        self.total_focusable = 0

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the focus order check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting WCAG_006 check for {url}")

            # Navigate to page if needed
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            # Wait for page to settle
            await page.wait_for_timeout(2000)

            # Step 1: Find all focusable elements
            await self._find_focusable_elements(page)

            if not self.focusable_elements:
                # No focusable elements found - pass (nothing to check)
                return await self._create_no_elements_result()

            # Step 2: Analyze tabindex usage
            await self._analyze_tabindex_usage()

            # Step 3: Analyze results
            violations_found = (
                self.positive_tabindex_count > 0 or
                self.high_tabindex_count > 0 or
                self.mixed_tabindex_count > 0
            )

            if violations_found:
                return await self._create_violation_result(page)
            else:
                return await self._create_compliant_result()

        except Exception as e:
            logger.error(f"Error in WCAG_006 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="WCAG",
                requirement_id="WCAG_006",
                status="error",
                severity="high",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _find_focusable_elements(self, page: Page):
        """
        Find all focusable elements on the page in DOM order.

        Args:
            page: Playwright page object
        """
        try:
            # Query all focusable elements
            selector = ', '.join(self.FOCUSABLE_SELECTORS)
            elements = await page.query_selector_all(selector)

            logger.debug(f"Found {len(elements)} potential focusable elements")

            for idx, elem in enumerate(elements):
                try:
                    # Check if element is visible
                    is_visible = await elem.is_visible()
                    if not is_visible:
                        continue

                    # Get element info including tabindex
                    elem_info = await elem.evaluate('''
                        el => {
                            const tabindex = el.getAttribute("tabindex");
                            return {
                                tag: el.tagName.toLowerCase(),
                                type: el.type || "",
                                role: el.getAttribute("role") || "",
                                ariaLabel: el.getAttribute("aria-label") || "",
                                textContent: (el.textContent || "").trim().substring(0, 50),
                                id: el.id || "",
                                tabindex: tabindex,
                                tabindexValue: tabindex ? parseInt(tabindex, 10) : null,
                                className: el.className || ""
                            };
                        }
                    ''')

                    elem_info['element'] = elem
                    elem_info['dom_order'] = idx

                    self.focusable_elements.append(elem_info)

                except Exception as e:
                    logger.debug(f"Error inspecting focusable element: {e}")
                    continue

            self.total_focusable = len(self.focusable_elements)
            logger.info(f"Found {self.total_focusable} visible focusable elements")

        except Exception as e:
            logger.error(f"Error finding focusable elements: {e}", exc_info=True)

    async def _analyze_tabindex_usage(self):
        """
        Analyze tabindex usage patterns for violations.
        """
        has_positive = False
        has_zero = False
        has_natural = False

        for elem_info in self.focusable_elements:
            tabindex_value = elem_info.get('tabindexValue')

            if tabindex_value is not None:
                if tabindex_value > 0:
                    has_positive = True
                    self.positive_tabindex_count += 1

                    # Check for very high tabindex (likely a workaround)
                    if tabindex_value > 100:
                        self.high_tabindex_count += 1

                    elem_info['has_positive_tabindex'] = True
                    logger.debug(f"Positive tabindex={tabindex_value}: {elem_info['textContent'][:40]}")

                elif tabindex_value == 0:
                    has_zero = True
                    elem_info['has_zero_tabindex'] = True

                # Note: tabindex="-1" is valid (programmatic focus only)
            else:
                # Naturally focusable element (no tabindex attribute)
                has_natural = True

        # Check for mixed usage (anti-pattern)
        if has_positive and (has_zero or has_natural):
            self.mixed_tabindex_count = self.positive_tabindex_count
            logger.debug("Mixed tabindex usage detected (positive with zero/natural)")

    async def _create_no_elements_result(self) -> ComplianceCheckResult:
        """
        Create result when no focusable elements found.

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            "No focusable elements found on page.\n"
            "Focus order requirement is not applicable for this page.\n\n"
            "Note: If the page should have focusable elements, this may indicate a rendering issue."
        )

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_006",
            status="passed",
            severity="high",
            evidence=evidence,
            metadata={
                'total_focusable': 0,
                'positive_tabindex_count': 0,
                'high_tabindex_count': 0,
                'mixed_tabindex_count': 0
            }
        )

    async def _create_compliant_result(self) -> ComplianceCheckResult:
        """
        Create a compliant result.

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            f"Focus order: No problematic tabindex usage detected.\n"
            f"  - Total focusable elements: {self.total_focusable}\n"
            f"  - Elements with positive tabindex: {self.positive_tabindex_count}\n"
            f"  - Elements with high tabindex (>100): {self.high_tabindex_count}\n\n"
            f"Tab order appears to follow DOM order without positive tabindex manipulation.\n\n"
            f"Note: Manual verification recommended to ensure tab order is logical for page content.\n"
            f"Verify that focus moves through the page in a meaningful sequence."
        )

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_006",
            status="passed",
            severity="high",
            evidence=evidence,
            metadata={
                'total_focusable': self.total_focusable,
                'positive_tabindex_count': self.positive_tabindex_count,
                'high_tabindex_count': self.high_tabindex_count,
                'mixed_tabindex_count': self.mixed_tabindex_count
            }
        )

    async def _create_violation_result(self, page: Page) -> ComplianceCheckResult:
        """
        Create a violation result.

        Args:
            page: Playwright page object

        Returns:
            ComplianceCheckResult with failed status
        """
        evidence_parts = []

        evidence_parts.append(
            "Focus order violations detected.\n"
        )

        if self.positive_tabindex_count > 0:
            evidence_parts.append(
                f"\nElements with positive tabindex: {self.positive_tabindex_count}\n"
                f"Positive tabindex values are an anti-pattern that creates maintenance issues:"
            )

            positive_tabindex = [e for e in self.focusable_elements if e.get('has_positive_tabindex', False)]
            for elem_info in positive_tabindex[:10]:
                identifier = elem_info['textContent'] or elem_info['ariaLabel'] or f"{elem_info['tag']}"
                evidence_parts.append(
                    f"  - {elem_info['tag']} tabindex=\"{elem_info['tabindexValue']}\" ({identifier[:40]})"
                )

            if len(positive_tabindex) > 10:
                evidence_parts.append(f"  ... and {len(positive_tabindex) - 10} more")

        if self.high_tabindex_count > 0:
            evidence_parts.append(
                f"\nElements with very high tabindex (>100): {self.high_tabindex_count}\n"
                f"High tabindex values are often used as workarounds and indicate poor focus management:"
            )

            high_tabindex = [e for e in self.focusable_elements
                            if e.get('tabindexValue') and e['tabindexValue'] > 100]
            for elem_info in high_tabindex[:10]:
                identifier = elem_info['textContent'] or elem_info['ariaLabel'] or f"{elem_info['tag']}"
                evidence_parts.append(
                    f"  - {elem_info['tag']} tabindex=\"{elem_info['tabindexValue']}\" ({identifier[:40]})"
                )

            if len(high_tabindex) > 10:
                evidence_parts.append(f"  ... and {len(high_tabindex) - 10} more")

        if self.mixed_tabindex_count > 0:
            evidence_parts.append(
                f"\nMixed tabindex usage detected (positive values mixed with natural/zero).\n"
                f"This creates unpredictable tab order and confusion for keyboard users."
            )

        evidence_parts.append(
            "\nWCAG 2.1 Level A requires focus order to preserve meaning and operability (2.4.3).\n\n"
            "Recommendation:\n"
            "  - Remove all positive tabindex values (use only tabindex=\"0\" or tabindex=\"-1\")\n"
            "  - Let DOM order determine tab order - rearrange HTML if needed\n"
            "  - Use tabindex=\"0\" to add elements to natural tab order\n"
            "  - Use tabindex=\"-1\" for programmatic focus only (not in tab order)\n"
            "  - Ensure tab order is logical and matches visual reading order\n"
            "  - Test with keyboard navigation to verify focus flow makes sense"
        )

        evidence = "\n".join(evidence_parts)

        screenshot_path = await self.take_screenshot(page, "wcag_006_focus_order_violation")

        # Get sample elements with positive tabindex
        positive_samples = [
            {
                'tag': e['tag'],
                'role': e['role'],
                'text': e['textContent'][:40],
                'tabindex': e['tabindexValue']
            }
            for e in self.focusable_elements[:20]
            if e.get('has_positive_tabindex', False)
        ]

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_006",
            status="failed",
            severity="high",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata={
                'total_focusable': self.total_focusable,
                'positive_tabindex_count': self.positive_tabindex_count,
                'high_tabindex_count': self.high_tabindex_count,
                'mixed_tabindex_count': self.mixed_tabindex_count,
                'positive_samples': positive_samples[:10]
            },
            legal_risk=(
                "High WCAG 2.1 Level A violation (2.4.3 Focus Order). "
                "Positive tabindex values create unpredictable tab order that confuses keyboard users. "
                "Users with motor disabilities rely on logical, predictable tab order to navigate efficiently. "
                "Illogical focus order forces users to tab through elements multiple times or lose their position. "
                "Legal risks: ADA Title III lawsuits in the US, accessibility discrimination claims. "
                "European Accessibility Act (EAA): Mandatory compliance from June 2025. "
                "Section 508: Required for US federal websites and vendors. "
                "Positive tabindex is considered an anti-pattern and should be avoided in favor of proper DOM structure."
            )
        )
