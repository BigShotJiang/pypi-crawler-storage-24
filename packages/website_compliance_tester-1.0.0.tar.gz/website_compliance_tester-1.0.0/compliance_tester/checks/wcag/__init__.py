"""
WCAG (Web Content Accessibility Guidelines) Compliance Checks

Web Content Accessibility Guidelines 2.1/2.2
Jurisdiction: International (W3C Standard)
Enforcement: Various national laws (ADA, Section 508, EAA, etc.)

Checks implemented:
- WCAG_001: Keyboard Navigation
- WCAG_002: Color Contrast
- WCAG_003: Form Labels
- WCAG_004: Form Input Purpose
- WCAG_005: Focus Visible
- WCAG_006: Focus Order
- WCAG_007: Touch Target Size
- WCAG_008: Text Spacing
- WCAG_009: Reflow
- WCAG_010: No Keyboard Trap
"""

# Import all checks to ensure they're registered
from .keyboard_navigation import KeyboardNavigationCheck
from .color_contrast import ColorContrastCheck
from .form_labels import FormLabelsCheck
from .form_input_purpose import FormInputPurposeCheck
from .focus_visible import FocusVisibleCheck
from .focus_order import FocusOrderCheck
from .touch_target_size import TouchTargetSizeCheck
from .text_spacing import TextSpacingCheck
from .reflow import ReflowCheck
from .no_keyboard_trap import NoKeyboardTrapCheck

__all__ = [
    'KeyboardNavigationCheck',
    'ColorContrastCheck',
    'FormLabelsCheck',
    'FormInputPurposeCheck',
    'FocusVisibleCheck',
    'FocusOrderCheck',
    'TouchTargetSizeCheck',
    'TextSpacingCheck',
    'ReflowCheck',
    'NoKeyboardTrapCheck',
]
