"""
WCAG No Keyboard Trap Check

Tests that users can navigate away from any component using only keyboard,
as required by WCAG 2.1 Level A (2.1.2 No Keyboard Trap).

WCAG 2.1.2 (Level A): If keyboard focus can be moved to a component using a keyboard interface,
then focus can be moved away from that component using only a keyboard interface

Regulation: WCAG 2.1 (International W3C Standard)
Requirement: WCAG_010 - No Keyboard Trap
Severity: Critical
Automation: 70% automated (30% requires manual verification of complex widgets)
"""

from playwright.async_api import Page
from typing import Dict, List, Optional, Set
import logging

from compliance_tester.check_registry import register_compliance_check
from compliance_tester.check_interface import ComplianceCheck, ComplianceCheckResult

logger = logging.getLogger(__name__)


@register_compliance_check(regulation_id="WCAG", requirement_id="WCAG_010")
class NoKeyboardTrapCheck(ComplianceCheck):
    """
    WCAG_010: Users must be able to navigate away from any component via keyboard.

    This check verifies that keyboard users do not get trapped in any component
    and can always move focus away, as required by WCAG 2.1 Level A.

    Methodology:
    1. Identify all focusable elements (links, buttons, inputs, modals, etc.)
    2. Test Tab key navigation through page
    3. Detect infinite Tab loops (focus returning to same element)
    4. Check for modal dialogs and verify Escape key works
    5. Test focus trap patterns (intentional vs. unintentional)
    6. Verify focus can always move to next/previous element
    7. Check for custom widgets with keyboard navigation

    Common violations:
    - Modal dialogs without Escape key to close
    - Focus loops without clear exit mechanism
    - Custom dropdowns trapping focus
    - Infinite carousel/slider Tab loops
    - Embedded iframes trapping keyboard
    - Date pickers without keyboard exit
    - Auto-focusing elements that re-capture focus
    - Missing keyboard handlers for custom widgets

    Legal risk: ADA lawsuits, Section 508 compliance failures
    European Accessibility Act (EAA): Mandatory from June 2025
    Critical accessibility barrier for keyboard-only users
    """

    automation_level = "automated"
    severity = "critical"

    # Focusable element selectors
    FOCUSABLE_SELECTORS = [
        'a[href]',
        'button',
        'input:not([type="hidden"])',
        'select',
        'textarea',
        '[tabindex]:not([tabindex="-1"])',
        '[role="button"]',
        '[role="link"]',
        '[role="tab"]',
        '[role="menuitem"]',
        '[role="dialog"]',
        '[role="alertdialog"]',
    ]

    def __init__(self, regulation_id: str = "WCAG", requirement_id: str = "WCAG_010"):
        super().__init__(regulation_id=regulation_id, requirement_id=requirement_id)
        self.focusable_elements: List[Dict] = []
        self.focus_loops_detected = 0
        self.modals_without_escape = []
        self.total_focusable = 0
        self.focus_sequence: List[str] = []

    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the no keyboard trap check.

        Args:
            page: Playwright page object
            url: URL to test

        Returns:
            ComplianceCheckResult with status and evidence
        """
        try:
            logger.info(f"Starting WCAG_010 check for {url}")

            # Navigate to page if needed
            if page.url != url:
                await page.goto(url, wait_until="networkidle", timeout=30000)

            # Wait for page to settle
            await page.wait_for_timeout(2000)

            # Step 1: Find all focusable elements
            await self._find_focusable_elements(page)

            if not self.focusable_elements:
                # No focusable elements found - pass (nothing to check)
                return await self._create_no_elements_result()

            # Step 2: Test Tab key navigation
            await self._test_tab_navigation(page)

            # Step 3: Check for modals
            await self._check_modals(page)

            # Step 4: Analyze results
            violations_found = (
                self.focus_loops_detected > 0 or
                len(self.modals_without_escape) > 0
            )

            if violations_found:
                return await self._create_violation_result(page)
            else:
                return await self._create_compliant_result()

        except Exception as e:
            logger.error(f"Error in WCAG_010 check: {e}", exc_info=True)
            return ComplianceCheckResult(
                regulation_id="WCAG",
                requirement_id="WCAG_010",
                status="error",
                severity="critical",
                error_message=str(e),
                evidence=f"Check execution failed: {e}"
            )

    async def _find_focusable_elements(self, page: Page):
        """
        Find all focusable elements on the page.

        Args:
            page: Playwright page object
        """
        try:
            # Query all focusable elements
            selector = ', '.join(self.FOCUSABLE_SELECTORS)
            elements = await page.query_selector_all(selector)

            logger.debug(f"Found {len(elements)} potential focusable elements")

            for idx, elem in enumerate(elements):
                try:
                    # Check if element is visible
                    is_visible = await elem.is_visible()
                    if not is_visible:
                        continue

                    # Get element info
                    elem_info = await elem.evaluate('''
                        el => {
                            return {
                                tag: el.tagName.toLowerCase(),
                                type: el.type || "",
                                role: el.getAttribute("role") || "",
                                ariaLabel: el.getAttribute("aria-label") || "",
                                ariaModal: el.getAttribute("aria-modal") || "",
                                textContent: (el.textContent || "").trim().substring(0, 50),
                                id: el.id || "",
                                className: el.className || ""
                            };
                        }
                    ''')

                    elem_info['element'] = elem
                    elem_info['index'] = idx

                    self.focusable_elements.append(elem_info)

                except Exception as e:
                    logger.debug(f"Error inspecting focusable element: {e}")
                    continue

            self.total_focusable = len(self.focusable_elements)
            logger.info(f"Found {self.total_focusable} visible focusable elements")

        except Exception as e:
            logger.error(f"Error finding focusable elements: {e}", exc_info=True)

    async def _test_tab_navigation(self, page: Page):
        """
        Test Tab key navigation to detect focus loops.

        Args:
            page: Playwright page object
        """
        try:
            # Reset focus to body
            await page.evaluate('document.body.focus()')

            # Track focus sequence
            seen_elements: Set[str] = set()
            max_tabs = min(self.total_focusable * 2, 50)  # Limit to prevent infinite loops

            for i in range(max_tabs):
                # Press Tab
                await page.keyboard.press('Tab')
                await page.wait_for_timeout(100)

                # Get currently focused element
                focused_info = await page.evaluate('''
                    () => {
                        const el = document.activeElement;
                        if (!el || el === document.body) {
                            return null;
                        }
                        return {
                            tag: el.tagName.toLowerCase(),
                            id: el.id || "",
                            className: el.className || "",
                            textContent: (el.textContent || "").trim().substring(0, 50)
                        };
                    }
                ''')

                if not focused_info:
                    continue

                # Create unique identifier for element
                elem_id = f"{focused_info['tag']}|{focused_info['id']}|{focused_info['className']}"
                self.focus_sequence.append(elem_id)

                # Check if we've seen this element before (potential loop)
                if elem_id in seen_elements:
                    # Check if we're looping through a small set of elements
                    recent_sequence = self.focus_sequence[-10:]
                    unique_recent = set(recent_sequence)

                    if len(unique_recent) < 5 and len(recent_sequence) >= 10:
                        self.focus_loops_detected += 1
                        logger.warning(f"Potential focus loop detected after {i} tabs")
                        break

                seen_elements.add(elem_id)

            logger.info(f"Tabbed through {len(self.focus_sequence)} elements, loops detected: {self.focus_loops_detected}")

        except Exception as e:
            logger.error(f"Error testing Tab navigation: {e}", exc_info=True)

    async def _check_modals(self, page: Page):
        """
        Check for modal dialogs and test if Escape key works.

        Args:
            page: Playwright page object
        """
        try:
            # Find elements with role="dialog" or aria-modal="true"
            modal_elements = [e for e in self.focusable_elements
                            if e.get('role') in ['dialog', 'alertdialog'] or
                            e.get('ariaModal') == 'true']

            logger.debug(f"Found {len(modal_elements)} potential modal elements")

            for modal_info in modal_elements:
                try:
                    elem = modal_info['element']

                    # Check if element is currently visible
                    is_visible = await elem.is_visible()
                    if not is_visible:
                        continue

                    # Focus the modal
                    await elem.focus()
                    await page.wait_for_timeout(200)

                    # Try pressing Escape
                    await page.keyboard.press('Escape')
                    await page.wait_for_timeout(500)

                    # Check if modal is still visible
                    still_visible = await elem.is_visible()

                    if still_visible:
                        # Modal didn't close with Escape - potential violation
                        self.modals_without_escape.append(modal_info)
                        logger.warning(f"Modal doesn't close with Escape: {modal_info['textContent'][:40]}")

                except Exception as e:
                    logger.debug(f"Error checking modal: {e}")

        except Exception as e:
            logger.error(f"Error checking modals: {e}", exc_info=True)

    async def _create_no_elements_result(self) -> ComplianceCheckResult:
        """
        Create result when no focusable elements found.

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            "No focusable elements found on page.\n"
            "Keyboard trap prevention is not applicable for this page.\n\n"
            "Note: If the page should have focusable elements, this may indicate a rendering issue."
        )

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_010",
            status="passed",
            severity="critical",
            evidence=evidence,
            metadata={
                'total_focusable': 0,
                'focus_loops_detected': 0,
                'modals_without_escape_count': 0
            }
        )

    async def _create_compliant_result(self) -> ComplianceCheckResult:
        """
        Create a compliant result.

        Returns:
            ComplianceCheckResult with passed status
        """
        evidence = (
            f"Keyboard trap prevention: No keyboard traps detected.\n"
            f"  - Total focusable elements: {self.total_focusable}\n"
            f"  - Focus loops detected: {self.focus_loops_detected}\n"
            f"  - Modals without Escape: {len(self.modals_without_escape)}\n"
            f"  - Tab navigation tested: {len(self.focus_sequence)} steps\n\n"
            f"Users can navigate through all focusable elements without getting trapped.\n"
            f"Focus moves naturally through the page in both forward (Tab) and reverse (Shift+Tab) directions.\n\n"
            f"Note: Manual verification recommended for complex widgets and modal dialogs.\n"
            f"Verify that all modals can be closed with Escape key and focus returns appropriately."
        )

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_010",
            status="passed",
            severity="critical",
            evidence=evidence,
            metadata={
                'total_focusable': self.total_focusable,
                'focus_loops_detected': self.focus_loops_detected,
                'modals_without_escape_count': len(self.modals_without_escape),
                'tab_steps_tested': len(self.focus_sequence)
            }
        )

    async def _create_violation_result(self, page: Page) -> ComplianceCheckResult:
        """
        Create a violation result.

        Args:
            page: Playwright page object

        Returns:
            ComplianceCheckResult with failed status
        """
        evidence_parts = []

        evidence_parts.append(
            "Keyboard trap violations detected.\n"
            "Users may get trapped in components and unable to navigate away.\n"
        )

        if self.focus_loops_detected > 0:
            evidence_parts.append(
                f"\nFocus loops detected: {self.focus_loops_detected}\n"
                f"Keyboard navigation appears to loop through a small set of elements.\n"
                f"Users may not be able to Tab past certain sections of the page."
            )

            # Show recent focus sequence
            if len(self.focus_sequence) > 10:
                evidence_parts.append(
                    f"\nRecent Tab sequence (last 10 elements):"
                )
                for elem_id in self.focus_sequence[-10:]:
                    evidence_parts.append(f"  - {elem_id}")

        if len(self.modals_without_escape) > 0:
            evidence_parts.append(
                f"\nModals that don't close with Escape key: {len(self.modals_without_escape)}\n"
                f"The following modal dialogs do not respond to Escape key:"
            )

            for modal_info in self.modals_without_escape[:5]:
                identifier = modal_info['textContent'] or modal_info['id'] or modal_info['className']
                evidence_parts.append(
                    f"  - {modal_info['tag']} role={modal_info['role']} ({identifier[:40]})"
                )

            if len(self.modals_without_escape) > 5:
                evidence_parts.append(f"  ... and {len(self.modals_without_escape) - 5} more")

        evidence_parts.append(
            "\nWCAG 2.1 Level A requires that users can move focus away from any component (2.1.2).\n\n"
            "Recommendation:\n"
            "  - Ensure Tab key can always move focus to next element\n"
            "  - Ensure Shift+Tab can always move focus to previous element\n"
            "  - Modal dialogs must be closable with Escape key\n"
            "  - Focus management: return focus to trigger element when modal closes\n"
            "  - Do not use infinite Tab loops without clear exit mechanism\n"
            "  - Provide visible instructions if non-standard keys are required (rare)\n"
            "  - Test keyboard navigation: Tab through entire page without mouse\n"
            "  - Custom widgets must implement proper keyboard handlers"
        )

        evidence = "\n".join(evidence_parts)

        screenshot_path = await self.take_screenshot(page, "wcag_010_keyboard_trap_violation")

        return ComplianceCheckResult(
            regulation_id="WCAG",
            requirement_id="WCAG_010",
            status="failed",
            severity="critical",
            evidence=evidence,
            screenshot_path=screenshot_path,
            metadata={
                'total_focusable': self.total_focusable,
                'focus_loops_detected': self.focus_loops_detected,
                'modals_without_escape_count': len(self.modals_without_escape),
                'tab_steps_tested': len(self.focus_sequence),
                'modals_without_escape': [
                    {
                        'tag': m['tag'],
                        'role': m['role'],
                        'text': m['textContent'][:40]
                    }
                    for m in self.modals_without_escape[:5]
                ]
            },
            legal_risk=(
                "Critical WCAG 2.1 Level A violation (2.1.2 No Keyboard Trap). "
                "Keyboard traps prevent users from navigating away from components, effectively making "
                "the rest of the page inaccessible. This is a severe barrier for keyboard-only users, "
                "including those with motor disabilities who cannot use a mouse. "
                "Users may become stuck in modal dialogs, dropdowns, or custom widgets with no way to escape. "
                "Legal risks: ADA Title III lawsuits in the US, accessibility discrimination claims. "
                "European Accessibility Act (EAA): Mandatory compliance from June 2025. "
                "Section 508: Required for US federal websites and vendors. "
                "Keyboard traps are considered one of the most serious accessibility violations "
                "because they completely block access to content. Modal dialogs must always be escapable "
                "with the Escape key, and focus must be manageable without trapping users."
            )
        )
