#!/usr/bin/env python3
"""
CLI for journey-based compliance testing.

Runs compliance checks against pre-recorded journey files instead of loading live pages.
"""
import asyncio
import argparse
import json
import sys
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from ux_tester.journey_loader import JourneyLoader

from .journey_execution_engine import JourneyComplianceExecutionEngine
from .check_registry import ComplianceCheckRegistry


def main():
    """
    Main entry point for journey-based compliance testing CLI.

    Usage:
        python -m compliance_tester.cli_journey /path/to/journey.json
        python -m compliance_tester.cli_journey /path/to/journey.json --regulation GDPR
        python -m compliance_tester.cli_journey /path/to/journey.json --requirement GDPR_001
    """
    parser = argparse.ArgumentParser(
        description="Run compliance checks against journey files (offline analysis)"
    )

    parser.add_argument(
        "journey_path",
        type=Path,
        help="Path to journey.json file"
    )

    parser.add_argument(
        "--regulation",
        type=str,
        help="Specific regulation to test (e.g., GDPR, CCPA, WCAG_2_2)"
    )

    parser.add_argument(
        "--requirement",
        type=str,
        help="Specific requirement ID to test (e.g., GDPR_001)"
    )

    parser.add_argument(
        "--jurisdiction",
        type=str,
        help="Filter by jurisdiction (e.g., EU, US, IN)"
    )

    parser.add_argument(
        "--output",
        type=Path,
        help="Output file for results (JSON format, optional)"
    )

    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Verbose output"
    )

    args = parser.parse_args()

    # Validate journey path
    if not args.journey_path.exists():
        print(f"Error: Journey file not found: {args.journey_path}", file=sys.stderr)
        sys.exit(1)

    # Run journey-based compliance tests
    asyncio.run(run_journey_compliance_tests(args))


async def run_journey_compliance_tests(args):
    """
    Execute journey-based compliance tests.

    Args:
        args: Parsed command-line arguments
    """
    print(f"Loading journey from: {args.journey_path}")

    # Load journey
    try:
        loader = JourneyLoader(args.journey_path)
        metadata = loader.get_metadata()

        print(f"Journey loaded: {metadata['total_steps']} steps")
        print(f"Start URL: {metadata['start_url']}")
        print()

    except Exception as e:
        print(f"Error loading journey: {e}", file=sys.stderr)
        sys.exit(1)

    # Initialize check registry and execution engine
    check_registry = ComplianceCheckRegistry()

    engine = JourneyComplianceExecutionEngine(
        check_registry=check_registry
    )

    # Prepare filters
    regulation_ids = [args.regulation] if args.regulation else None
    requirement_ids = [args.requirement] if args.requirement else None
    jurisdictions = [args.jurisdiction] if args.jurisdiction else None

    print("Executing compliance checks...")
    print()

    # Execute tests
    try:
        result = await engine.execute_journey(
            journey_path=args.journey_path,
            regulation_ids=regulation_ids,
            requirement_ids=requirement_ids,
            jurisdictions=jurisdictions,
            skip_unsupported=True  # Skip checks without journey support
        )

    except Exception as e:
        print(f"Error executing tests: {e}", file=sys.stderr)
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)

    # Display results
    print("=" * 60)
    print("COMPLIANCE TEST RESULTS")
    print("=" * 60)
    print()
    print(f"Checks Executed: {result.checks_executed}")
    print(f"  Passed: {result.checks_passed}")
    print(f"  Failed: {result.checks_failed}")
    print(f"  Neutral: {result.checks_neutral}")
    print(f"  Skipped: {result.checks_skipped}")
    print(f"  Errors: {result.checks_error}")
    print()
    print(f"Compliance Rate: {result.compliance_rate * 100:.1f}%")
    print()
    print(f"⚠️  Critical Violations: {result.critical_violations}")
    print(f"⚠️  High Severity Violations: {result.high_violations}")
    print()

    # Display individual results
    if args.verbose or result.checks_failed > 0:
        print("=" * 60)
        print("DETAILED RESULTS")
        print("=" * 60)
        print()

        for check_result in result.all_results:
            status_symbol = {
                "passed": "✓",
                "failed": "✗",
                "neutral": "○",
                "skipped": "⊘",
                "error": "⚠"
            }.get(check_result.status, "?")

            severity_symbol = {
                "critical": "🔴",
                "high": "🟠",
                "medium": "🟡",
                "low": "🟢"
            }.get(check_result.severity, "")

            print(f"{status_symbol} {severity_symbol} {check_result.requirement_id}: {check_result.status}")
            if check_result.evidence and args.verbose:
                # Print first 200 chars of evidence
                evidence_preview = check_result.evidence[:200]
                if len(check_result.evidence) > 200:
                    evidence_preview += "..."
                print(f"    {evidence_preview}")
            if check_result.legal_risk and check_result.status == "failed":
                print(f"    Legal Risk: {check_result.legal_risk[:150]}...")

            print()

    # Save to file if requested
    if args.output:
        output_data = {
            "journey_path": str(args.journey_path),
            "summary": {
                "checks_executed": result.checks_executed,
                "checks_passed": result.checks_passed,
                "checks_failed": result.checks_failed,
                "checks_neutral": result.checks_neutral,
                "checks_skipped": result.checks_skipped,
                "checks_error": result.checks_error,
                "compliance_rate": result.compliance_rate,
                "critical_violations": result.critical_violations,
                "high_violations": result.high_violations
            },
            "results": [
                {
                    "regulation_id": r.regulation_id,
                    "requirement_id": r.requirement_id,
                    "status": r.status,
                    "severity": r.severity,
                    "evidence": r.evidence,
                    "legal_risk": r.legal_risk,
                    "metadata": r.metadata,
                    "error_message": r.error_message
                }
                for r in result.all_results
            ]
        }

        with open(args.output, 'w') as f:
            json.dump(output_data, f, indent=2)

        print(f"Results saved to: {args.output}")

    # Exit with appropriate code
    if result.critical_violations > 0:
        sys.exit(3)  # Critical violations
    elif result.checks_error > 0:
        sys.exit(2)  # Errors occurred
    elif result.checks_failed > 0:
        sys.exit(1)  # Tests failed
    else:
        sys.exit(0)  # All tests passed


if __name__ == "__main__":
    main()
