"""
CLI entry point for BayMAAR Compliance Testing Module.

Usage:
    python -m compliance_tester <url> [options]

Examples:
    # Run all automated checks
    python -m compliance_tester https://example.com

    # Run specific regulation
    python -m compliance_tester https://example.com --regulations GDPR CCPA

    # Generate HTML report
    python -m compliance_tester https://example.com --format html --output report.html

    # Verbose output with all details
    python -m compliance_tester https://example.com --verbose
"""

import sys
import asyncio
from compliance_tester.cli import main

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n❌ Interrupted by user")
        sys.exit(130)
    except Exception as e:
        print(f"\n\n❌ Fatal error: {e}")
        sys.exit(1)
