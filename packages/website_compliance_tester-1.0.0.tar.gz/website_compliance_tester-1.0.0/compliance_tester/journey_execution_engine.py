"""
Journey-based execution engine for compliance testing.

Executes compliance checks against pre-recorded journey files instead of live pages.
"""
from pathlib import Path
from typing import List, Dict, Optional
import asyncio
from dataclasses import dataclass, field

# Import journey loader from ux_tester (shared infrastructure)
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from ux_tester.journey_loader import JourneyLoader, JourneyStep

from .check_interface import ComplianceCheckResult
from .check_registry import ComplianceComplianceCheckRegistry


@dataclass
class JourneyComplianceTestResult:
    """
    Results from testing a complete journey for compliance.

    Attributes:
        journey_path: Path to journey.json file
        total_steps: Number of steps in journey
        checks_executed: Number of checks executed
        checks_passed: Number of checks that passed
        checks_failed: Number of checks that failed
        checks_neutral: Number of neutral results
        checks_skipped: Number of skipped checks
        checks_error: Number of checks with errors
        critical_violations: Number of critical failures
        high_violations: Number of high severity failures
        step_results: Results grouped by step number
        all_results: Flat list of all check results
    """
    journey_path: Path
    total_steps: int
    checks_executed: int = 0
    checks_passed: int = 0
    checks_failed: int = 0
    checks_neutral: int = 0
    checks_skipped: int = 0
    checks_error: int = 0
    critical_violations: int = 0
    high_violations: int = 0
    step_results: Dict[int, List[ComplianceCheckResult]] = field(default_factory=dict)
    all_results: List[ComplianceCheckResult] = field(default_factory=list)

    @property
    def compliance_rate(self) -> float:
        """Calculate compliance rate (passed / (passed + failed))."""
        total = self.checks_passed + self.checks_failed
        if total == 0:
            return 0.0
        return self.checks_passed / total

    @property
    def has_critical_violations(self) -> bool:
        """Check if there are any critical violations."""
        return self.critical_violations > 0


class JourneyComplianceExecutionEngine:
    """
    Execute compliance checks against journey files.

    This engine loads pre-recorded journey data and executes compliance
    checks without loading live pages, enabling:
    - Offline compliance analysis
    - Faster re-testing
    - No bot detection issues
    - Reproducible results

    Usage:
        engine = JourneyComplianceExecutionEngine(check_registry)
        result = await engine.execute_journey("./data/journey.json")

        print(f"Executed {result.checks_executed} checks")
        print(f"Passed: {result.checks_passed}, Failed: {result.checks_failed}")
        print(f"Critical violations: {result.critical_violations}")
    """

    def __init__(self, check_registry: ComplianceCheckRegistry):
        """
        Initialize journey compliance execution engine.

        Args:
            check_registry: Registry of available compliance checks
        """
        self.check_registry = check_registry

    async def execute_journey(
        self,
        journey_path: Path,
        regulation_ids: Optional[List[str]] = None,
        requirement_ids: Optional[List[str]] = None,
        jurisdictions: Optional[List[str]] = None,
        skip_unsupported: bool = True
    ) -> JourneyComplianceTestResult:
        """
        Execute compliance checks against a journey file.

        Args:
            journey_path: Path to journey.json file
            regulation_ids: Optional list of regulation IDs to filter (e.g., ["GDPR", "CCPA"])
            requirement_ids: Optional list of requirement IDs to filter (e.g., ["GDPR_001"])
            jurisdictions: Optional list of jurisdictions to filter (e.g., ["EU", "US"])
            skip_unsupported: Skip checks without journey support (default True)

        Returns:
            JourneyComplianceTestResult with all check results

        Raises:
            FileNotFoundError: If journey file doesn't exist
            ValueError: If journey file is invalid
        """
        # Load journey
        loader = JourneyLoader(journey_path)
        steps = loader.get_steps()

        # Initialize result
        result = JourneyComplianceTestResult(
            journey_path=journey_path,
            total_steps=len(steps)
        )

        # Get checks to run
        checks = self._get_checks_to_run(regulation_ids, requirement_ids, jurisdictions)

        # Execute checks for each step (most compliance checks only need first step)
        # For now, just run on first step to demonstrate
        if steps:
            step = steps[0]
            step_checks = await self._execute_step(
                step,
                loader,
                checks,
                skip_unsupported
            )

            # Collect results
            result.step_results[step.step_number] = step_checks
            result.all_results.extend(step_checks)

            # Update counters
            for check_result in step_checks:
                result.checks_executed += 1
                if check_result.status == "passed":
                    result.checks_passed += 1
                elif check_result.status == "failed":
                    result.checks_failed += 1
                    # Track severity
                    if check_result.severity == "critical":
                        result.critical_violations += 1
                    elif check_result.severity == "high":
                        result.high_violations += 1
                elif check_result.status == "neutral":
                    result.checks_neutral += 1
                elif check_result.status == "skipped":
                    result.checks_skipped += 1
                elif check_result.status == "error":
                    result.checks_error += 1

        return result

    async def _execute_step(
        self,
        step: JourneyStep,
        loader: JourneyLoader,
        checks: List[object],
        skip_unsupported: bool
    ) -> List[ComplianceCheckResult]:
        """
        Execute compliance checks for a single step.

        Args:
            step: Journey step to analyze
            loader: Journey loader
            checks: List of check instances
            skip_unsupported: Skip checks without journey support

        Returns:
            List of compliance check results for this step
        """
        results = []

        # Execute each check
        for check in checks:
            try:
                # Execute check from journey
                check_result = await check.execute_from_journey(step, loader)
                results.append(check_result)

            except NotImplementedError:
                # Check doesn't support journey-based execution
                if skip_unsupported:
                    # Skip silently
                    continue
                else:
                    # Record as skipped
                    results.append(ComplianceCheckResult(
                        regulation_id=check.regulation_id,
                        requirement_id=check.requirement_id,
                        status="skipped",
                        severity=check.severity,
                        evidence=f"Check does not support journey-based execution"
                    ))

            except Exception as e:
                # Check execution error
                results.append(ComplianceCheckResult(
                    regulation_id=check.regulation_id,
                    requirement_id=check.requirement_id,
                    status="error",
                    severity=check.severity,
                    error_message=str(e),
                    evidence=f"Error executing check: {str(e)}"
                ))

        return results

    def _get_checks_to_run(
        self,
        regulation_ids: Optional[List[str]],
        requirement_ids: Optional[List[str]],
        jurisdictions: Optional[List[str]]
    ) -> List[object]:
        """
        Get list of compliance checks to run based on filters.

        Args:
            regulation_ids: Optional regulation IDs (e.g., ["GDPR"])
            requirement_ids: Optional requirement IDs (e.g., ["GDPR_001"])
            jurisdictions: Optional jurisdictions (e.g., ["EU"])

        Returns:
            List of check instances
        """
        all_checks = self.check_registry.get_all_checks()

        # Filter by regulation IDs
        if regulation_ids:
            all_checks = [c for c in all_checks if c.regulation_id in regulation_ids]

        # Filter by requirement IDs
        if requirement_ids:
            all_checks = [c for c in all_checks if c.requirement_id in requirement_ids]

        # Filter by jurisdictions
        if jurisdictions:
            filtered = []
            for check in all_checks:
                check_jurisdictions = check.jurisdictions
                # Include if check applies globally (*) or matches requested jurisdictions
                if "*" in check_jurisdictions:
                    filtered.append(check)
                elif any(j in check_jurisdictions for j in jurisdictions):
                    filtered.append(check)
            all_checks = filtered

        return all_checks

    async def execute_single_check(
        self,
        requirement_id: str,
        journey_path: Path,
        step_number: int = 1
    ) -> ComplianceCheckResult:
        """
        Execute a single compliance check against journey.

        Args:
            requirement_id: Requirement identifier (e.g., "GDPR_001")
            journey_path: Path to journey.json
            step_number: Step number to test (default: 1)

        Returns:
            ComplianceCheckResult

        Raises:
            ValueError: If check not found or step not found
        """
        # Get check
        check = self.check_registry.get_check_by_requirement(requirement_id)
        if not check:
            raise ValueError(f"Check not found: {requirement_id}")

        # Load journey
        loader = JourneyLoader(journey_path)
        step = loader.get_step(step_number)
        if not step:
            raise ValueError(f"Step {step_number} not found in journey")

        # Execute check
        try:
            result = await check.execute_from_journey(step, loader)
            return result
        except NotImplementedError:
            return ComplianceCheckResult(
                regulation_id=check.regulation_id,
                requirement_id=check.requirement_id,
                status="skipped",
                severity=check.severity,
                evidence="Check does not support journey-based execution"
            )
        except Exception as e:
            return ComplianceCheckResult(
                regulation_id=check.regulation_id,
                requirement_id=check.requirement_id,
                status="error",
                severity=check.severity,
                error_message=str(e)
            )
