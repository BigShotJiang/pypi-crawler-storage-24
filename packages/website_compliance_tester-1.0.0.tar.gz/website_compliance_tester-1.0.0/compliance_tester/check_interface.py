"""
Compliance Check Interface

Base classes and data structures for compliance checks.
Similar to ux_tester.check_interface but focused on legal compliance.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, Optional, Literal, List, TYPE_CHECKING
from playwright.async_api import Page

if TYPE_CHECKING:
    from ux_tester.journey_loader import JourneyStep, JourneyLoader


@dataclass
class ComplianceCheckResult:
    """Result of a single compliance check execution."""

    regulation_id: str  # e.g., "GDPR", "DPDP_2023", "WCAG_2_2"
    requirement_id: str  # e.g., "GDPR_001", "DPDP_003"
    status: Literal["passed", "failed", "neutral", "skipped", "error"]
    severity: Literal["critical", "high", "medium", "low"] = "medium"
    evidence: Optional[str] = None  # Human-readable description
    screenshot_path: Optional[str] = None
    metadata: Dict = field(default_factory=dict)  # Additional structured data
    error_message: Optional[str] = None  # If status == "error"
    legal_risk: Optional[str] = None  # Description of legal risk if failed

    def __post_init__(self):
        """Validate the result."""
        valid_statuses = ["passed", "failed", "neutral", "skipped", "error"]
        if self.status not in valid_statuses:
            raise ValueError(f"Invalid status: {self.status}. Must be one of {valid_statuses}")

        valid_severities = ["critical", "high", "medium", "low"]
        if self.severity not in valid_severities:
            raise ValueError(f"Invalid severity: {self.severity}. Must be one of {valid_severities}")


class ComplianceCheck(ABC):
    """Base class for all compliance checks."""

    def __init__(self, regulation_id: str, requirement_id: str):
        self.regulation_id = regulation_id
        self.requirement_id = requirement_id

    @abstractmethod
    async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
        """
        Execute the compliance check against a live page (legacy method).

        Args:
            page: Playwright page object
            url: URL being tested

        Returns:
            ComplianceCheckResult with status and evidence
        """
        pass

    async def execute_from_journey(
        self,
        step: "JourneyStep",
        journey_loader: "JourneyLoader"
    ) -> ComplianceCheckResult:
        """
        Execute the compliance check from journey files (preferred method).

        This method analyzes a page from pre-recorded journey data,
        allowing offline compliance analysis without re-loading pages.

        Args:
            step: Journey step containing page data and screenshot
            journey_loader: Journey loader for accessing related steps

        Returns:
            ComplianceCheckResult with status and evidence

        Raises:
            NotImplementedError: If check doesn't support journey-based execution
            Exception: Check execution errors are caught by framework

        Notes:
            - Checks should implement this method for journey-based testing
            - Can access HTML via step.load_html()
            - Can access screenshot via step.load_screenshot()
            - Can access forms, links, meta tags via step methods
            - Default implementation raises NotImplementedError
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not yet support journey-based execution. "
            f"Implement execute_from_journey() method or use live page testing."
        )

    @property
    @abstractmethod
    def automation_level(self) -> Literal["automated", "semi-automated", "manual"]:
        """Classification of how automated this check is."""
        pass

    @property
    @abstractmethod
    def severity(self) -> Literal["critical", "high", "medium", "low"]:
        """Legal severity of this requirement."""
        pass

    @property
    def description(self) -> str:
        """Human-readable description of what this check tests."""
        return f"Compliance check for {self.regulation_id} requirement {self.requirement_id}"

    @property
    def jurisdictions(self) -> List[str]:
        """
        Jurisdictions this check applies to.
        Returns list of country codes (e.g., ["IN", "EU", "US"])
        """
        # Map regulation IDs to jurisdictions
        jurisdiction_map = {
            "GDPR": ["EU"],
            "DPDP_2023": ["IN"],
            "CCPA": ["US"],
            "WCAG_2_2": ["*"],  # Global (US ADA, EU EN 301 549, etc.)
            "UK_GDPR": ["UK"],
            "LGPD": ["BR"],
            "PRIVACY_ACT": ["AU"],
            "PIPL": ["CN"],
        }
        return jurisdiction_map.get(self.regulation_id, ["*"])

    async def take_screenshot(self, page: Page, name: str) -> str:
        """
        Helper method to take and save screenshot.

        Args:
            page: Playwright page
            name: Screenshot name (without extension)

        Returns:
            Path to saved screenshot
        """
        import os
        from pathlib import Path
        from datetime import datetime

        # Create screenshots directory if not exists
        screenshots_dir = Path("compliance_screenshots")
        screenshots_dir.mkdir(exist_ok=True)

        # Generate filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{name}_{timestamp}.png"
        filepath = screenshots_dir / filename

        # Take screenshot
        await page.screenshot(path=str(filepath), full_page=True)

        return str(filepath)
