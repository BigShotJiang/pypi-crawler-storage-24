"""
Compliance Check Registry

Central registry for automatic compliance check discovery.
Similar to ux_tester.check_registry but for compliance checks.
"""

from typing import Dict, List, Type, Optional
from .check_interface import ComplianceCheck
import logging

logger = logging.getLogger(__name__)


class ComplianceCheckRegistry:
    """Registry of all compliance checks."""

    def __init__(self):
        self._checks: Dict[str, Type[ComplianceCheck]] = {}
        self._by_regulation: Dict[str, List[Type[ComplianceCheck]]] = {}
        self._by_jurisdiction: Dict[str, List[Type[ComplianceCheck]]] = {}

    def register(self, check_class: Type[ComplianceCheck]):
        """
        Register a compliance check class.

        Args:
            check_class: The check class to register
        """
        # Create unique key
        key = f"{check_class.regulation_id}:{check_class.requirement_id}"

        # Check for duplicates
        if key in self._checks:
            logger.warning(
                f"Duplicate check registration: {key}. "
                f"Overwriting {self._checks[key].__name__} with {check_class.__name__}"
            )

        # Register
        self._checks[key] = check_class

        # Index by regulation
        if check_class.regulation_id not in self._by_regulation:
            self._by_regulation[check_class.regulation_id] = []
        self._by_regulation[check_class.regulation_id].append(check_class)

        # Index by jurisdiction
        instance = check_class(
            regulation_id=check_class.regulation_id,
            requirement_id=check_class.requirement_id
        )
        for jurisdiction in instance.jurisdictions:
            if jurisdiction not in self._by_jurisdiction:
                self._by_jurisdiction[jurisdiction] = []
            self._by_jurisdiction[jurisdiction].append(check_class)

        logger.debug(f"Registered compliance check: {key} ({check_class.__name__})")

    def get_check(self, regulation_id: str, requirement_id: str) -> Optional[Type[ComplianceCheck]]:
        """
        Get a specific check class.

        Args:
            regulation_id: The regulation ID (e.g., "GDPR")
            requirement_id: The requirement ID (e.g., "GDPR_001")

        Returns:
            The check class if found, None otherwise
        """
        key = f"{regulation_id}:{requirement_id}"
        return self._checks.get(key)

    def get_checks_for_regulation(self, regulation_id: str) -> List[Type[ComplianceCheck]]:
        """
        Get all checks for a specific regulation.

        Args:
            regulation_id: The regulation ID (e.g., "GDPR")

        Returns:
            List of check classes for this regulation
        """
        return self._by_regulation.get(regulation_id, [])

    def get_checks_for_jurisdiction(self, jurisdiction: str) -> List[Type[ComplianceCheck]]:
        """
        Get all checks applicable to a jurisdiction.

        Args:
            jurisdiction: Country code (e.g., "IN", "EU", "US") or "*" for global

        Returns:
            List of check classes for this jurisdiction
        """
        checks = self._by_jurisdiction.get(jurisdiction, [])
        # Always include global checks (jurisdiction "*")
        if jurisdiction != "*":
            checks.extend(self._by_jurisdiction.get("*", []))
        return checks

    def get_all_automated(self) -> List[Type[ComplianceCheck]]:
        """
        Get all fully automated checks.

        Returns:
            List of automated check classes
        """
        return [
            check for check in self._checks.values()
            if check.automation_level == "automated"
        ]

    def get_critical_checks(self) -> List[Type[ComplianceCheck]]:
        """
        Get all checks with critical severity.

        Returns:
            List of critical check classes
        """
        return [
            check for check in self._checks.values()
            if check.severity == "critical"
        ]

    def list_all(self) -> Dict[str, Type[ComplianceCheck]]:
        """
        Get all registered checks.

        Returns:
            Dictionary mapping check keys to check classes
        """
        return self._checks.copy()

    def get_stats(self) -> Dict:
        """
        Get registry statistics.

        Returns:
            Dictionary with registry stats
        """
        total_checks = len(self._checks)
        by_automation = {}
        by_severity = {}

        for check_class in self._checks.values():
            # Count by automation level
            automation = check_class.automation_level
            by_automation[automation] = by_automation.get(automation, 0) + 1

            # Count by severity
            severity = check_class.severity
            by_severity[severity] = by_severity.get(severity, 0) + 1

        return {
            'total_checks': total_checks,
            'regulations': len(self._by_regulation),
            'jurisdictions': len(self._by_jurisdiction),
            'by_automation': by_automation,
            'by_severity': by_severity,
        }


# Global registry instance
compliance_registry = ComplianceCheckRegistry()


def register_compliance_check(regulation_id: str, requirement_id: str):
    """
    Decorator to register a compliance check.

    Args:
        regulation_id: The regulation ID (e.g., "GDPR")
        requirement_id: The requirement ID (e.g., "GDPR_001")

    Example:
        @register_compliance_check(regulation_id="GDPR", requirement_id="GDPR_001")
        class CookieConsentCheck(ComplianceCheck):
            automation_level = "automated"
            severity = "critical"

            async def execute(self, page: Page, url: str) -> ComplianceCheckResult:
                # Implementation
                ...
    """
    def decorator(cls):
        # Set class attributes
        cls.regulation_id = regulation_id
        cls.requirement_id = requirement_id

        # Register the check
        compliance_registry.register(cls)

        return cls

    return decorator


def get_registered_checks() -> Dict[str, Type[ComplianceCheck]]:
    """
    Get all registered compliance checks.

    Returns:
        Dictionary mapping check keys to check classes
    """
    return compliance_registry.list_all()
