# CI/CD Integration Guide - Compliance Testing Module

## Overview

This guide shows how to integrate BayMAAR's compliance testing into automated CI/CD pipelines to catch regulatory violations before production deployment.

**Benefits**:
- ✅ Catch GDPR/CCPA/DPDP violations before launch
- ✅ Block deployments with critical compliance issues
- ✅ Automated compliance reporting to stakeholders
- ✅ Audit trail of compliance over time
- ✅ Reduce legal risk and avoid €20M+ fines

---

## Table of Contents

1. [GitHub Actions](#github-actions)
2. [GitLab CI](#gitlab-ci)
3. [Jenkins Pipeline](#jenkins-pipeline)
4. [CircleCI](#circleci)
5. [Pre-deployment Validation](#pre-deployment-validation)
6. [Automated Reporting](#automated-reporting)
7. [Environment-Specific Configs](#environment-specific-configs)
8. [Troubleshooting](#troubleshooting)

---

## GitHub Actions

### Basic Compliance Check (Pull Requests)

Create `.github/workflows/compliance-check.yml`:

```yaml
name: Compliance Check

on:
  pull_request:
    branches: [main, develop]
  push:
    branches: [main, develop]

jobs:
  compliance:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout code
        uses: actions/checkout@v3

      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.10'

      - name: Install dependencies
        run: |
          cd research/baymaar-guidelines
          pip install playwright pytest pytest-asyncio
          playwright install chromium

      - name: Run compliance checks on staging
        id: compliance
        run: |
          cd research/baymaar-guidelines
          python3 -m compliance_tester.cli https://staging.example.com \
            --format json \
            --output compliance-report.json
        continue-on-error: true

      - name: Parse compliance results
        id: parse
        run: |
          cd research/baymaar-guidelines
          CRITICAL=$(jq '.critical_violations | length' compliance-report.json)
          HIGH=$(jq '.high_violations | length' compliance-report.json)
          SCORE=$(jq '.compliance_score' compliance-report.json)
          GRADE=$(jq -r '.grade' compliance-report.json)

          echo "critical=$CRITICAL" >> $GITHUB_OUTPUT
          echo "high=$HIGH" >> $GITHUB_OUTPUT
          echo "score=$SCORE" >> $GITHUB_OUTPUT
          echo "grade=$GRADE" >> $GITHUB_OUTPUT

      - name: Comment PR with results
        uses: actions/github-script@v6
        if: github.event_name == 'pull_request'
        with:
          script: |
            const critical = '${{ steps.parse.outputs.critical }}';
            const high = '${{ steps.parse.outputs.high }}';
            const score = '${{ steps.parse.outputs.score }}';
            const grade = '${{ steps.parse.outputs.grade }}';

            const body = `## 🔍 Compliance Check Results

            **Grade**: ${grade}
            **Score**: ${score}%

            **Violations**:
            - 🔴 Critical: ${critical}
            - 🟠 High: ${high}

            ${critical > 0 ? '⚠️ **BLOCKED**: Critical compliance violations detected!' : '✅ **PASSED**: No critical violations'}

            <details>
            <summary>View detailed report</summary>

            See artifacts for full compliance report.
            </details>`;

            github.rest.issues.createComment({
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: body
            });

      - name: Upload compliance report
        uses: actions/upload-artifact@v3
        with:
          name: compliance-report
          path: research/baymaar-guidelines/compliance-report.json

      - name: Block merge if critical violations
        if: steps.parse.outputs.critical > 0
        run: |
          echo "❌ BLOCKED: ${{ steps.parse.outputs.critical }} critical compliance violations"
          exit 1
```

### Advanced: Multi-Environment Testing

```yaml
name: Multi-Environment Compliance

on:
  schedule:
    - cron: '0 2 * * *'  # Daily at 2 AM
  workflow_dispatch:

jobs:
  compliance-matrix:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        environment:
          - name: staging
            url: https://staging.example.com
            fail-on-critical: true
          - name: production
            url: https://www.example.com
            fail-on-critical: false

    steps:
      - name: Checkout code
        uses: actions/checkout@v3

      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.10'

      - name: Install dependencies
        run: |
          cd research/baymaar-guidelines
          pip install playwright pytest pytest-asyncio
          playwright install chromium

      - name: Run compliance checks - ${{ matrix.environment.name }}
        run: |
          cd research/baymaar-guidelines
          python3 -m compliance_tester.cli ${{ matrix.environment.url }} \
            --format html \
            --output compliance-${{ matrix.environment.name }}.html

      - name: Upload report
        uses: actions/upload-artifact@v3
        with:
          name: compliance-${{ matrix.environment.name }}
          path: research/baymaar-guidelines/compliance-${{ matrix.environment.name }}.html

      - name: Send Slack notification
        uses: slackapi/slack-github-action@v1
        if: always()
        with:
          payload: |
            {
              "text": "Compliance check completed for ${{ matrix.environment.name }}",
              "blocks": [
                {
                  "type": "section",
                  "text": {
                    "type": "mrkdwn",
                    "text": "*Compliance Report - ${{ matrix.environment.name }}*\n${{ matrix.environment.url }}"
                  }
                }
              ]
            }
        env:
          SLACK_WEBHOOK_URL: ${{ secrets.SLACK_WEBHOOK_URL }}
```

### Pre-deployment Gate

```yaml
name: Pre-Deployment Compliance Gate

on:
  deployment:

jobs:
  compliance-gate:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout code
        uses: actions/checkout@v3

      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.10'

      - name: Install dependencies
        run: |
          cd research/baymaar-guidelines
          pip install playwright pytest pytest-asyncio
          playwright install chromium

      - name: Run compliance checks
        id: compliance
        run: |
          cd research/baymaar-guidelines
          python3 -m compliance_tester.cli ${{ github.event.deployment.environment.url }} \
            --format json \
            --output compliance-gate.json

      - name: Evaluate compliance score
        run: |
          CRITICAL=$(jq '.critical_violations | length' compliance-gate.json)
          SCORE=$(jq '.compliance_score' compliance-gate.json)

          if [ "$CRITICAL" -gt 0 ]; then
            echo "❌ DEPLOYMENT BLOCKED: $CRITICAL critical violations"
            exit 1
          fi

          if (( $(echo "$SCORE < 80" | bc -l) )); then
            echo "⚠️ WARNING: Compliance score below 80% ($SCORE%)"
            echo "Proceeding with warning..."
          fi

          echo "✅ Compliance gate passed"
```

---

## GitLab CI

### Basic Setup

Create `.gitlab-ci.yml`:

```yaml
stages:
  - test
  - compliance
  - deploy

variables:
  STAGING_URL: "https://staging.example.com"
  PROD_URL: "https://www.example.com"

compliance_check:
  stage: compliance
  image: mcr.microsoft.com/playwright/python:v1.40.0-focal

  before_script:
    - cd research/baymaar-guidelines
    - pip install playwright pytest pytest-asyncio

  script:
    - |
      python3 -m compliance_tester.cli $STAGING_URL \
        --format json \
        --output compliance-report.json

    - CRITICAL=$(jq '.critical_violations | length' compliance-report.json)
    - HIGH=$(jq '.high_violations | length' compliance-report.json)
    - SCORE=$(jq '.compliance_score' compliance-report.json)

    - echo "Compliance Score: $SCORE%"
    - echo "Critical Violations: $CRITICAL"
    - echo "High Violations: $HIGH"

    - |
      if [ "$CRITICAL" -gt 0 ]; then
        echo "❌ FAILED: Critical compliance violations detected"
        exit 1
      fi

  artifacts:
    when: always
    paths:
      - research/baymaar-guidelines/compliance-report.json
      - research/baymaar-guidelines/compliance_screenshots/
    expire_in: 30 days

  only:
    - merge_requests
    - main

compliance_scheduled:
  stage: compliance
  extends: compliance_check

  script:
    - |
      python3 -m compliance_tester.cli $PROD_URL \
        --format html \
        --output compliance-production.html

  artifacts:
    paths:
      - research/baymaar-guidelines/compliance-production.html
    expire_in: 90 days

  only:
    - schedules
```

### With Email Notifications

```yaml
compliance_with_notifications:
  stage: compliance
  image: mcr.microsoft.com/playwright/python:v1.40.0-focal

  script:
    - cd research/baymaar-guidelines
    - pip install playwright pytest pytest-asyncio
    - |
      python3 -m compliance_tester.cli $STAGING_URL \
        --format text \
        --output compliance-report.txt

  after_script:
    - |
      if [ -f "compliance-report.txt" ]; then
        # Send email via GitLab CI variables
        curl -X POST \
          -H "Content-Type: application/json" \
          -d "{
            \"to\": \"$COMPLIANCE_EMAIL\",
            \"subject\": \"Compliance Report - $CI_COMMIT_BRANCH\",
            \"body\": \"$(cat compliance-report.txt)\"
          }" \
          $EMAIL_WEBHOOK_URL
      fi

  artifacts:
    when: always
    paths:
      - research/baymaar-guidelines/compliance-report.txt
```

---

## Jenkins Pipeline

### Declarative Pipeline

Create `Jenkinsfile`:

```groovy
pipeline {
    agent any

    environment {
        STAGING_URL = 'https://staging.example.com'
        PROD_URL = 'https://www.example.com'
    }

    stages {
        stage('Setup') {
            steps {
                sh '''
                    cd research/baymaar-guidelines
                    pip3 install playwright pytest pytest-asyncio
                    playwright install chromium
                '''
            }
        }

        stage('Compliance Check') {
            steps {
                script {
                    sh '''
                        cd research/baymaar-guidelines
                        python3 -m compliance_tester.cli ${STAGING_URL} \
                            --format json \
                            --output compliance-report.json
                    '''

                    def report = readJSON file: 'research/baymaar-guidelines/compliance-report.json'
                    def critical = report.critical_violations.size()
                    def score = report.compliance_score
                    def grade = report.grade

                    echo "Compliance Score: ${score}%"
                    echo "Grade: ${grade}"
                    echo "Critical Violations: ${critical}"

                    if (critical > 0) {
                        error("❌ FAILED: ${critical} critical compliance violations")
                    }
                }
            }
        }

        stage('Archive Results') {
            steps {
                archiveArtifacts artifacts: 'research/baymaar-guidelines/compliance-report.json', fingerprint: true
                archiveArtifacts artifacts: 'research/baymaar-guidelines/compliance_screenshots/**', allowEmptyArchive: true
            }
        }

        stage('Publish Report') {
            steps {
                publishHTML([
                    allowMissing: false,
                    alwaysLinkToLastBuild: true,
                    keepAll: true,
                    reportDir: 'research/baymaar-guidelines',
                    reportFiles: 'compliance-report.html',
                    reportName: 'Compliance Report'
                ])
            }
        }
    }

    post {
        always {
            script {
                if (fileExists('research/baymaar-guidelines/compliance-report.json')) {
                    def report = readJSON file: 'research/baymaar-guidelines/compliance-report.json'
                    def summary = """
                    Compliance Check Results
                    ========================
                    Grade: ${report.grade}
                    Score: ${report.compliance_score}%
                    Critical: ${report.critical_violations.size()}
                    High: ${report.high_violations.size()}
                    """

                    echo summary
                }
            }
        }

        failure {
            emailext(
                subject: "❌ Compliance Check Failed - ${env.JOB_NAME} #${env.BUILD_NUMBER}",
                body: "Compliance check failed. See attached report.",
                to: "${env.COMPLIANCE_EMAIL}",
                attachmentsPattern: '**/compliance-report.json'
            )
        }

        success {
            emailext(
                subject: "✅ Compliance Check Passed - ${env.JOB_NAME} #${env.BUILD_NUMBER}",
                body: "All compliance checks passed.",
                to: "${env.COMPLIANCE_EMAIL}"
            )
        }
    }
}
```

### Multi-Branch Pipeline

```groovy
pipeline {
    agent any

    parameters {
        choice(
            name: 'ENVIRONMENT',
            choices: ['staging', 'production'],
            description: 'Environment to test'
        )
        booleanParam(
            name: 'BLOCK_ON_CRITICAL',
            defaultValue: true,
            description: 'Block build if critical violations found'
        )
    }

    stages {
        stage('Compliance Check') {
            steps {
                script {
                    def url = params.ENVIRONMENT == 'staging' ? env.STAGING_URL : env.PROD_URL

                    sh """
                        cd research/baymaar-guidelines
                        python3 -m compliance_tester.cli ${url} \
                            --format json \
                            --output compliance-${params.ENVIRONMENT}.json
                    """

                    def report = readJSON file: "research/baymaar-guidelines/compliance-${params.ENVIRONMENT}.json"
                    def critical = report.critical_violations.size()

                    currentBuild.description = "Score: ${report.compliance_score}% | Grade: ${report.grade}"

                    if (critical > 0 && params.BLOCK_ON_CRITICAL) {
                        error("Critical violations detected")
                    }
                }
            }
        }
    }
}
```

---

## CircleCI

Create `.circleci/config.yml`:

```yaml
version: 2.1

orbs:
  python: circleci/python@2.1.1

jobs:
  compliance-check:
    docker:
      - image: mcr.microsoft.com/playwright/python:v1.40.0-focal

    steps:
      - checkout

      - run:
          name: Install dependencies
          command: |
            cd research/baymaar-guidelines
            pip install playwright pytest pytest-asyncio

      - run:
          name: Run compliance checks
          command: |
            cd research/baymaar-guidelines
            python3 -m compliance_tester.cli https://staging.example.com \
              --format json \
              --output compliance-report.json

      - run:
          name: Evaluate results
          command: |
            cd research/baymaar-guidelines
            CRITICAL=$(jq '.critical_violations | length' compliance-report.json)

            if [ "$CRITICAL" -gt 0 ]; then
              echo "❌ FAILED: $CRITICAL critical violations"
              exit 1
            fi

      - store_artifacts:
          path: research/baymaar-guidelines/compliance-report.json
          destination: compliance-report

      - store_artifacts:
          path: research/baymaar-guidelines/compliance_screenshots
          destination: screenshots

workflows:
  compliance:
    jobs:
      - compliance-check:
          filters:
            branches:
              only:
                - main
                - develop
```

---

## Pre-deployment Validation

### Standalone Pre-deployment Script

Create `scripts/pre-deploy-compliance.sh`:

```bash
#!/bin/bash

# Pre-deployment compliance validation script
# Usage: ./scripts/pre-deploy-compliance.sh <environment> <url>

set -e

ENVIRONMENT=$1
URL=$2

if [ -z "$ENVIRONMENT" ] || [ -z "$URL" ]; then
    echo "Usage: $0 <environment> <url>"
    echo "Example: $0 production https://www.example.com"
    exit 1
fi

echo "🔍 Running compliance checks for $ENVIRONMENT..."
echo "URL: $URL"
echo ""

cd research/baymaar-guidelines

# Run compliance checks
python3 -m compliance_tester.cli "$URL" \
    --format json \
    --output "compliance-$ENVIRONMENT.json"

# Parse results
CRITICAL=$(jq '.critical_violations | length' "compliance-$ENVIRONMENT.json")
HIGH=$(jq '.high_violations | length' "compliance-$ENVIRONMENT.json")
SCORE=$(jq '.compliance_score' "compliance-$ENVIRONMENT.json")
GRADE=$(jq -r '.grade' "compliance-$ENVIRONMENT.json")

echo ""
echo "=========================="
echo "Compliance Results"
echo "=========================="
echo "Grade: $GRADE"
echo "Score: $SCORE%"
echo "Critical: $CRITICAL"
echo "High: $HIGH"
echo "=========================="
echo ""

# Deployment decision logic
if [ "$CRITICAL" -gt 0 ]; then
    echo "❌ DEPLOYMENT BLOCKED: $CRITICAL critical compliance violations"
    echo ""
    echo "Critical violations must be fixed before deployment:"
    jq -r '.critical_violations[] | "  - [\(.requirement_id)] \(.evidence)"' "compliance-$ENVIRONMENT.json"
    exit 1
fi

if [ "$ENVIRONMENT" == "production" ]; then
    # Stricter requirements for production
    if (( $(echo "$SCORE < 90" | bc -l) )); then
        echo "⚠️  WARNING: Production compliance score is below 90% ($SCORE%)"
        echo "Consider fixing high-severity violations before deploying."

        read -p "Continue with deployment? (yes/no): " CONFIRM
        if [ "$CONFIRM" != "yes" ]; then
            echo "Deployment cancelled"
            exit 1
        fi
    fi
fi

echo "✅ Compliance gate passed - deployment approved"
exit 0
```

### Make it executable:

```bash
chmod +x scripts/pre-deploy-compliance.sh
```

### Usage in deployment scripts:

```bash
# In your deploy.sh
./scripts/pre-deploy-compliance.sh production https://www.example.com

if [ $? -eq 0 ]; then
    echo "Proceeding with deployment..."
    # Your deployment commands here
else
    echo "Deployment cancelled due to compliance issues"
    exit 1
fi
```

---

## Automated Reporting

### Daily Compliance Report (Cron)

Create `scripts/daily-compliance-report.sh`:

```bash
#!/bin/bash

# Daily compliance monitoring script
# Add to crontab: 0 2 * * * /path/to/daily-compliance-report.sh

ENVIRONMENTS=("staging:https://staging.example.com" "production:https://www.example.com")
REPORT_DATE=$(date +%Y-%m-%d)
REPORT_DIR="compliance-reports/$REPORT_DATE"

mkdir -p "$REPORT_DIR"

cd research/baymaar-guidelines

for ENV in "${ENVIRONMENTS[@]}"; do
    NAME="${ENV%%:*}"
    URL="${ENV##*:}"

    echo "Running compliance check for $NAME..."

    python3 -m compliance_tester.cli "$URL" \
        --format html \
        --output "$REPORT_DIR/compliance-$NAME.html"

    python3 -m compliance_tester.cli "$URL" \
        --format json \
        --output "$REPORT_DIR/compliance-$NAME.json"
done

# Generate summary email
cat > "$REPORT_DIR/summary.txt" << EOF
BayMAAR Compliance Daily Report - $REPORT_DATE
===============================================

Reports generated for:
$(for ENV in "${ENVIRONMENTS[@]}"; do echo "  - ${ENV%%:*}"; done)

View detailed reports in: $REPORT_DIR/

To view HTML reports:
$(for ENV in "${ENVIRONMENTS[@]}"; do
    NAME="${ENV%%:*}"
    echo "  - $NAME: file://$PWD/$REPORT_DIR/compliance-$NAME.html"
done)

Automated by BayMAAR Compliance Testing Module
EOF

# Send email (configure your email command)
# mail -s "Compliance Report - $REPORT_DATE" compliance@example.com < "$REPORT_DIR/summary.txt"

echo "Reports saved to: $REPORT_DIR"
```

### Slack Notification Script

Create `scripts/send-compliance-slack.sh`:

```bash
#!/bin/bash

# Send compliance results to Slack
# Usage: ./send-compliance-slack.sh <json-report-path>

REPORT_PATH=$1
SLACK_WEBHOOK_URL="${SLACK_WEBHOOK_URL:-$2}"

if [ -z "$REPORT_PATH" ] || [ ! -f "$REPORT_PATH" ]; then
    echo "Usage: $0 <json-report-path> [slack-webhook-url]"
    exit 1
fi

if [ -z "$SLACK_WEBHOOK_URL" ]; then
    echo "Error: SLACK_WEBHOOK_URL not set"
    exit 1
fi

# Parse report
GRADE=$(jq -r '.grade' "$REPORT_PATH")
SCORE=$(jq '.compliance_score' "$REPORT_PATH")
CRITICAL=$(jq '.critical_violations | length' "$REPORT_PATH")
HIGH=$(jq '.high_violations | length' "$REPORT_PATH")
URL=$(jq -r '.url // "N/A"' "$REPORT_PATH")

# Determine status emoji
if [ "$CRITICAL" -gt 0 ]; then
    STATUS="🔴"
    COLOR="danger"
elif [ "$HIGH" -gt 0 ]; then
    STATUS="🟡"
    COLOR="warning"
else
    STATUS="🟢"
    COLOR="good"
fi

# Send to Slack
curl -X POST "$SLACK_WEBHOOK_URL" \
    -H 'Content-Type: application/json' \
    -d @- << EOF
{
    "text": "$STATUS Compliance Report",
    "attachments": [
        {
            "color": "$COLOR",
            "title": "Compliance Check Results",
            "fields": [
                {
                    "title": "URL",
                    "value": "$URL",
                    "short": false
                },
                {
                    "title": "Grade",
                    "value": "$GRADE",
                    "short": true
                },
                {
                    "title": "Score",
                    "value": "${SCORE}%",
                    "short": true
                },
                {
                    "title": "Critical Violations",
                    "value": "$CRITICAL",
                    "short": true
                },
                {
                    "title": "High Violations",
                    "value": "$HIGH",
                    "short": true
                }
            ],
            "footer": "BayMAAR Compliance Testing",
            "ts": $(date +%s)
        }
    ]
}
EOF

echo "Slack notification sent"
```

---

## Environment-Specific Configs

### Config File Approach

Create `compliance-config.yaml`:

```yaml
environments:
  development:
    url: http://localhost:3000
    regulations:
      - WCAG
    fail_on_critical: false
    report_format: text

  staging:
    url: https://staging.example.com
    regulations:
      - GDPR
      - CCPA
      - DPDP_2023
      - WCAG
    fail_on_critical: true
    report_format: json
    notify:
      - slack
      - email

  production:
    url: https://www.example.com
    regulations:
      - GDPR
      - CCPA
      - DPDP_2023
      - WCAG
    fail_on_critical: true
    min_score: 90
    report_format: html
    notify:
      - slack
      - email
      - jira

notification:
  slack:
    webhook_url: ${SLACK_WEBHOOK_URL}

  email:
    to: compliance@example.com
    smtp_server: smtp.example.com

  jira:
    project: COMPLIANCE
    issue_type: Bug
```

### Python script to use config

Create `scripts/run-compliance-with-config.py`:

```python
#!/usr/bin/env python3
"""
Run compliance checks using environment configuration.
Usage: python3 run-compliance-with-config.py <environment>
"""

import sys
import yaml
import subprocess
import json
import os

def load_config(config_path='compliance-config.yaml'):
    with open(config_path) as f:
        return yaml.safe_load(f)

def run_compliance(env_name):
    config = load_config()

    if env_name not in config['environments']:
        print(f"Error: Environment '{env_name}' not found in config")
        sys.exit(1)

    env_config = config['environments'][env_name]

    # Build command
    cmd = [
        'python3', '-m', 'compliance_tester.cli',
        env_config['url'],
        '--format', env_config.get('report_format', 'text'),
        '--output', f'compliance-{env_name}.{env_config.get("report_format", "txt")}'
    ]

    if 'regulations' in env_config:
        cmd.extend(['--regulations'] + env_config['regulations'])

    print(f"Running compliance check for {env_name}...")
    print(f"URL: {env_config['url']}")
    print(f"Command: {' '.join(cmd)}")
    print()

    # Run compliance check
    result = subprocess.run(cmd, capture_output=True, text=True)

    print(result.stdout)
    if result.stderr:
        print(result.stderr, file=sys.stderr)

    # Evaluate results
    if env_config.get('report_format') == 'json':
        report_file = f'compliance-{env_name}.json'
        if os.path.exists(report_file):
            with open(report_file) as f:
                report = json.load(f)

            critical = len(report.get('critical_violations', []))
            score = report.get('compliance_score', 0)

            print(f"\nResults: Grade={report.get('grade')}, Score={score}%, Critical={critical}")

            # Check thresholds
            if env_config.get('fail_on_critical') and critical > 0:
                print(f"❌ FAILED: {critical} critical violations")
                sys.exit(1)

            if 'min_score' in env_config and score < env_config['min_score']:
                print(f"⚠️  WARNING: Score {score}% below minimum {env_config['min_score']}%")

    print("✅ Compliance check passed")
    return 0

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python3 run-compliance-with-config.py <environment>")
        sys.exit(1)

    sys.exit(run_compliance(sys.argv[1]))
```

---

## Troubleshooting

### Common Issues

#### 1. Playwright Installation

**Problem**: `playwright: command not found`

**Solution**:
```bash
pip install playwright
playwright install chromium
```

#### 2. Module Not Found

**Problem**: `ModuleNotFoundError: No module named 'compliance_tester'`

**Solution**: Run from correct directory
```bash
cd research/baymaar-guidelines
python3 -m compliance_tester.cli <url>
```

#### 3. Timeout Issues

**Problem**: Tests timeout on large sites

**Solution**: Increase timeout in CLI or use journey-based testing
```bash
python3 -m compliance_tester.cli <url> --timeout 60000
```

#### 4. Bot Detection

**Problem**: Major sites (Amazon, Target) block automated testing

**Solution**:
- Use staging/test environments
- Use journey-based testing (scrape first, then analyze)
- Configure residential proxies

#### 5. Permission Denied

**Problem**: Cannot write reports

**Solution**:
```bash
chmod +w research/baymaar-guidelines/
```

### Debugging

Enable verbose logging:
```bash
python3 -m compliance_tester.cli <url> --verbose
```

Check registered checks:
```bash
python3 -m compliance_tester.cli --list-checks
```

---

## Best Practices

### 1. Environment Strategy

- **Development**: Run only critical checks, don't block
- **Staging**: Run all checks, block on critical violations
- **Production**: Monitor only, alert on violations

### 2. Notification Strategy

- **Critical violations**: Immediate Slack/email to legal team
- **High violations**: Daily digest
- **Medium/Low**: Weekly report

### 3. Deployment Gates

```
Pull Request → Compliance Check → Code Review → Merge
                     ↓
              Block if critical

Deploy to Staging → Pre-deployment Check → Deploy to Production
                           ↓
                    Block if critical or score < 90%
```

### 4. Monitoring

- **Daily**: Automated compliance checks on production
- **Weekly**: Compliance trend reports
- **Monthly**: Executive compliance summary

### 5. Archiving

Keep compliance reports for audit trail:
```bash
# Archive reports for 2 years
find compliance-reports/ -name "*.json" -mtime +730 -delete
```

---

## Example: Complete GitHub Actions Workflow

Here's a comprehensive example combining multiple features:

```yaml
name: Complete Compliance Pipeline

on:
  pull_request:
  push:
    branches: [main]
  schedule:
    - cron: '0 2 * * *'  # Daily at 2 AM

env:
  STAGING_URL: https://staging.example.com
  PROD_URL: https://www.example.com

jobs:
  pr-compliance-check:
    if: github.event_name == 'pull_request'
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v3

      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.10'

      - name: Install dependencies
        run: |
          cd research/baymaar-guidelines
          pip install playwright pytest pytest-asyncio
          playwright install chromium

      - name: Run compliance checks
        run: |
          cd research/baymaar-guidelines
          python3 -m compliance_tester.cli ${{ env.STAGING_URL }} \
            --format json \
            --output pr-compliance.json

      - name: Comment PR
        uses: actions/github-script@v6
        with:
          script: |
            const fs = require('fs');
            const report = JSON.parse(fs.readFileSync('research/baymaar-guidelines/pr-compliance.json'));

            const critical = report.critical_violations.length;
            const high = report.high_violations.length;
            const score = report.compliance_score;
            const grade = report.grade;

            const status = critical > 0 ? '❌ BLOCKED' : '✅ PASSED';

            const body = `## ${status} Compliance Check

            **Grade**: ${grade} | **Score**: ${score}%

            | Severity | Count |
            |----------|-------|
            | 🔴 Critical | ${critical} |
            | 🟠 High | ${high} |

            ${critical > 0 ? '⚠️ **This PR is blocked due to critical compliance violations.**' : ''}

            [View full report](${process.env.GITHUB_SERVER_URL}/${process.env.GITHUB_REPOSITORY}/actions/runs/${process.env.GITHUB_RUN_ID})`;

            github.rest.issues.createComment({
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: body
            });

      - name: Block if critical
        run: |
          CRITICAL=$(jq '.critical_violations | length' research/baymaar-guidelines/pr-compliance.json)
          if [ "$CRITICAL" -gt 0 ]; then
            exit 1
          fi

  daily-monitoring:
    if: github.event_name == 'schedule'
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v3

      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.10'

      - name: Install dependencies
        run: |
          cd research/baymaar-guidelines
          pip install playwright pytest pytest-asyncio
          playwright install chromium

      - name: Check production compliance
        run: |
          cd research/baymaar-guidelines
          python3 -m compliance_tester.cli ${{ env.PROD_URL }} \
            --format html \
            --output daily-compliance.html

      - name: Upload report
        uses: actions/upload-artifact@v3
        with:
          name: daily-compliance-report
          path: research/baymaar-guidelines/daily-compliance.html
          retention-days: 90

      - name: Send Slack notification
        uses: slackapi/slack-github-action@v1
        with:
          payload: |
            {
              "text": "Daily compliance report generated",
              "blocks": [
                {
                  "type": "section",
                  "text": {
                    "type": "mrkdwn",
                    "text": "*Daily Compliance Report*\n:link: [View Report](${{ github.server_url }}/${{ github.repository }}/actions/runs/${{ github.run_id }})"
                  }
                }
              ]
            }
        env:
          SLACK_WEBHOOK_URL: ${{ secrets.SLACK_WEBHOOK_URL }}
```

---

## Summary

This guide provides production-ready CI/CD integration examples for:

✅ **GitHub Actions** - PR checks, multi-environment, deployment gates
✅ **GitLab CI** - Pipeline stages, scheduled runs, notifications
✅ **Jenkins** - Declarative and scripted pipelines
✅ **CircleCI** - Docker-based workflows
✅ **Pre-deployment** - Validation scripts and gates
✅ **Automated Reporting** - Daily monitoring, Slack/email notifications
✅ **Configuration Management** - Environment-specific configs

**Next Steps**:
1. Choose your CI/CD platform
2. Copy the relevant example
3. Customize for your environment
4. Test on staging first
5. Roll out to production

For questions or support, see the main [README.md](README.md) or [CLI_USAGE.md](CLI_USAGE.md).
