# Compliance Tester CLI Usage Guide

Complete guide for using the BayMAAR Compliance Testing CLI.

---

## Quick Start

```bash
# Run all automated checks on a website
python -m compliance_tester https://example.com

# Run specific regulations
python -m compliance_tester https://example.com --regulations GDPR CCPA

# Generate HTML report
python -m compliance_tester https://example.com --format html --output report.html
```

---

## Installation

No additional installation needed - uses existing BayMAAR dependencies.

**Requirements:**
- Python 3.9+
- Playwright (already installed with BayMAAR)

---

## Basic Commands

### 1. Run All Automated Checks

```bash
python -m compliance_tester https://example.com
```

**Output:**
```
╔══════════════════════════════════════════════════════════════╗
║        BayMAAR Compliance Testing Module v1.0.0              ║
║        Automated Regulatory Compliance Validation            ║
╚══════════════════════════════════════════════════════════════╝

ℹ Testing URL: https://example.com
ℹ Regulations: ALL

Running compliance checks...

════════════════════════════════════════════════════════════════
COMPLIANCE TEST SUMMARY
════════════════════════════════════════════════════════════════

Overall Grade: A
Compliance Score: 85.2%
Total Checks: 11

✓ Passed: 9
✗ Failed: 2
! Errors: 0

⚠ CRITICAL VIOLATIONS:
  • GDPR_001: Cookie Consent Banner
    Risk: Up to €20M or 4% of global turnover...

────────────────────────────────────────────────────────────────
✗ NOT PRODUCTION READY
  Fix 1 critical violation(s) before launch.
────────────────────────────────────────────────────────────────
```

### 2. List Available Checks

```bash
python -m compliance_tester --list-checks
```

Shows all 11 implemented checks grouped by regulation.

### 3. Run Specific Regulations

```bash
# GDPR only (EU privacy)
python -m compliance_tester https://example.com --regulations GDPR

# CCPA only (California privacy)
python -m compliance_tester https://example.com --regulations CCPA

# Multiple regulations
python -m compliance_tester https://example.com --regulations GDPR CCPA WCAG
```

**Available Regulations:**
- `GDPR` - EU General Data Protection Regulation (3 checks)
- `DPDP` - India Digital Personal Data Protection Act (4 checks)
- `CCPA` - California Consumer Privacy Act (2 checks)
- `WCAG` - Web Content Accessibility Guidelines (2 checks)
- `ALL` - Run all regulations (default)

---

## Output Formats

### Text Output (Default)

```bash
python -m compliance_tester https://example.com
```

Human-readable terminal output with:
- Color-coded results
- Summary statistics
- Critical violations highlighted
- Production readiness assessment

### HTML Report

```bash
python -m compliance_tester https://example.com \
  --format html \
  --output compliance-report.html
```

Generates a comprehensive HTML report with:
- Visual compliance dashboard
- Detailed evidence for each check
- Screenshots of violations
- Prioritized fix recommendations
- Legal risk assessments

### JSON Export

```bash
python -m compliance_tester https://example.com \
  --format json \
  --output results.json
```

Machine-readable JSON for:
- CI/CD integration
- Custom reporting tools
- Data analysis
- API consumption

---

## Advanced Options

### Verbose Output

```bash
python -m compliance_tester https://example.com --verbose
```

Shows detailed evidence for each check:
- Full violation descriptions
- Detection methodology
- Legal citations
- Remediation guidance

### Filter by Severity

```bash
# Critical checks only (blocks production)
python -m compliance_tester https://example.com --severity critical

# High and critical
python -m compliance_tester https://example.com --severity high

# All severity levels
python -m compliance_tester https://example.com --severity all
```

**Severity Levels:**
- `critical` - Major fines, lawsuits (€20M GDPR, $7,500 CCPA)
- `high` - Serious violations, moderate fines
- `medium` - Minor violations, warnings
- `low` - Best practices, not legally required
- `all` - Include all levels (default)

### Filter by Automation Level

```bash
# Fully automated checks only (default)
python -m compliance_tester https://example.com --automation automated

# Include semi-automated checks
python -m compliance_tester https://example.com --automation semi-automated

# All checks including manual
python -m compliance_tester https://example.com --automation all
```

### Debugging Options

```bash
# Show browser (headful mode)
python -m compliance_tester https://example.com --headful

# Enable debug logging
python -m compliance_tester https://example.com --debug

# Increase page load timeout
python -m compliance_tester https://example.com --timeout 60000
```

### Quiet Mode

```bash
# Suppress progress, show only results
python -m compliance_tester https://example.com --quiet
```

### No Color Output

```bash
# Disable ANSI colors (for CI/CD)
python -m compliance_tester https://example.com --no-color
```

---

## Complete Examples

### 1. Pre-Launch Validation

```bash
# Check if site is production-ready
python -m compliance_tester https://staging.mystore.com \
  --regulations GDPR CCPA WCAG \
  --severity critical \
  --verbose \
  --output pre-launch-report.html \
  --format html
```

**Use case:** Final compliance check before deploying to production.

### 2. GDPR Audit

```bash
# Comprehensive GDPR compliance audit
python -m compliance_tester https://example.com \
  --regulations GDPR \
  --severity all \
  --verbose \
  --format html \
  --output gdpr-audit.html
```

**Use case:** Quarterly GDPR compliance review.

### 3. Accessibility Check

```bash
# WCAG accessibility validation
python -m compliance_tester https://example.com \
  --regulations WCAG \
  --verbose
```

**Use case:** ADA/Section 508 compliance verification.

### 4. CI/CD Integration

```bash
# Automated compliance testing in pipeline
python -m compliance_tester https://preview.example.com \
  --regulations ALL \
  --severity critical \
  --format json \
  --output compliance-results.json \
  --no-color \
  --quiet

# Check exit code
if [ $? -eq 0 ]; then
  echo "✓ Compliance checks passed"
else
  echo "✗ Compliance violations detected"
  exit 1
fi
```

**Use case:** Block deployment if critical violations detected.

### 5. Multi-Jurisdiction Testing

```bash
# Test for EU, India, and California markets
python -m compliance_tester https://global.example.com \
  --regulations GDPR DPDP CCPA \
  --format html \
  --output multi-region-compliance.html
```

**Use case:** Global e-commerce site serving multiple markets.

---

## Exit Codes

The CLI returns different exit codes based on results:

- **0** - All checks passed, production-ready
- **1** - Compliance violations detected (critical or non-critical)
- **2** - Errors during execution (network, timeout, etc.)

**Example usage in scripts:**

```bash
python -m compliance_tester https://example.com
EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]; then
  echo "✓ Ready for production"
elif [ $EXIT_CODE -eq 1 ]; then
  echo "✗ Compliance violations - fix before launch"
else
  echo "⚠ Execution errors - check logs"
fi
```

---

## Tips & Best Practices

### 1. Start with Critical Checks

```bash
# Focus on must-fix issues first
python -m compliance_tester https://example.com --severity critical
```

### 2. Test Staging Before Production

Always run compliance tests on staging/preview environments before deploying to production.

### 3. Regular Audits

Schedule periodic compliance checks:
```bash
# Weekly automated audit
0 2 * * 1 python -m compliance_tester https://example.com \
  --format html --output /reports/weekly-$(date +%Y%m%d).html
```

### 4. Save Reports

Always save HTML reports for audit trails:
```bash
python -m compliance_tester https://example.com \
  --format html \
  --output reports/compliance-$(date +%Y%m%d).html
```

### 5. Combine with UX Testing

```bash
# Run both UX and compliance tests
python -m ux_tester https://example.com --output ux-report.html
python -m compliance_tester https://example.com --output compliance-report.html
```

---

## Troubleshooting

### Issue: "Module not found" error

**Solution:**
```bash
# Run from correct directory
cd research/baymaar-guidelines
python -m compliance_tester https://example.com
```

### Issue: Browser timeout

**Solution:**
```bash
# Increase timeout for slow sites
python -m compliance_tester https://example.com --timeout 60000
```

### Issue: Connection errors

**Solution:**
```bash
# Check URL is accessible
curl -I https://example.com

# Run in headful mode to debug
python -m compliance_tester https://example.com --headful --debug
```

### Issue: No checks found

**Solution:**
```bash
# Verify checks are registered
python -m compliance_tester --list-checks

# Should show 11 checks (GDPR: 3, DPDP: 4, CCPA: 2, WCAG: 2)
```

---

## Interpreting Results

### Grades

- **A+ (95-100%)** - Fully compliant, excellent
- **A (85-94%)** - Mostly compliant, minor issues
- **B (75-84%)** - Acceptable, some gaps
- **C (60-74%)** - Significant issues
- **D (40-59%)** - Major violations
- **F (<40%)** - Critical non-compliance

### Production Readiness

✓ **PRODUCTION READY**
- No critical violations
- All checks passed or non-critical issues only
- Safe to launch

✗ **NOT PRODUCTION READY**
- Critical violations present
- Must fix before launch
- Legal risk exposure

⚠ **LAUNCH WITH CAUTION**
- Non-critical issues found
- Review and fix recommended
- Not blocking but should address

---

## Support

For issues or questions:
1. Check `README.md` for general documentation
2. Review `compliance-criteria.json` for requirement details
3. Run with `--debug` flag for detailed logs
4. Consult legal team for compliance interpretation

---

**Version:** 1.0.0
**Last Updated:** 2026-03-21
**Module:** BayMAAR Compliance Testing
