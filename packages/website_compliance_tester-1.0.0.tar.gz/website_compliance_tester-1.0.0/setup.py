#!/usr/bin/env python3
"""
Website Compliance Tester - Automated regulatory compliance testing.

Catch GDPR, CCPA, DPDP, and WCAG violations before launch.
"""
from setuptools import setup, find_packages
from pathlib import Path

# Read README for long description
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

setup(
    name="website-compliance-tester",
    version="1.0.0",
    author="Rishabh Patel",
    author_email="rp87704@gmail.com",
    description="Automated GDPR, CCPA, DPDP, and WCAG compliance testing for e-commerce websites",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/resabh/website-compliance-tester",
    packages=find_packages(exclude=["tests", "tests.*", "compliance_screenshots"]),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: Legal Industry",
        "Topic :: Software Development :: Testing",
        "Topic :: Software Development :: Quality Assurance",
        "Topic :: Office/Business :: Financial :: Accounting",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[
        "playwright>=1.40.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "website-compliance=compliance_tester.cli:main",
        ],
    },
    include_package_data=True,
    package_data={
        "compliance_tester": ["compliance-criteria.json"],
    },
    keywords=[
        "compliance", "gdpr", "ccpa", "dpdp", "wcag",
        "accessibility", "privacy", "testing", "automation",
        "e-commerce", "legal", "regulatory", "audit", "website"
    ],
    project_urls={
        "Bug Reports": "https://github.com/resabh/website-compliance-tester/issues",
        "Source": "https://github.com/resabh/website-compliance-tester",
        "Documentation": "https://github.com/resabh/website-compliance-tester/blob/main/README.md",
        "CI/CD Guide": "https://github.com/resabh/website-compliance-tester/blob/main/CI_CD_INTEGRATION_GUIDE.md",
    },
    zip_safe=False,
)
