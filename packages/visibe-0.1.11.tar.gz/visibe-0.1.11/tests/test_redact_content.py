"""
Unit tests for redact_content feature.

Covers: init() parameter handling, env var fallback, deprecation warning,
        client enforcement (create_trace, send_span, queue_span, complete_trace),
        session _end(), SpanBatcher defense-in-depth, and field preservation.

Tests are added incrementally per implementation task.
"""
import warnings

import pytest

import visibe
import visibe as _mod
from visibe.client import Visibe


# ---------------------------------------------------------------------------
# Fixture: reset global state around every test
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def reset_visibe_globals():
    """Ensure clean global state before and after each test."""
    _mod._global_client = None
    _mod._auto_patched_frameworks.clear()
    yield
    _mod._global_client = None
    _mod._auto_patched_frameworks.clear()


# ---------------------------------------------------------------------------
# Task 1: init() — redact_content parameter
# ---------------------------------------------------------------------------

def test_init_redact_content_true():
    """init(redact_content=True) stores True on the client."""
    client = visibe.init(
        api_key="sk_live_test", api_url="http://localhost:3000",
        frameworks=[], redact_content=True,
    )
    assert client.redact_content is True


def test_init_redact_content_default_false():
    """init() without the flag defaults to False."""
    client = visibe.init(
        api_key="sk_live_test", api_url="http://localhost:3000",
        frameworks=[],
    )
    assert client.redact_content is False


def test_init_redact_content_explicit_false():
    """init(redact_content=False) stores False."""
    client = visibe.init(
        api_key="sk_live_test", api_url="http://localhost:3000",
        frameworks=[], redact_content=False,
    )
    assert client.redact_content is False


def test_init_redact_content_env_var_true(monkeypatch):
    """VISIBE_REDACT_CONTENT=1 sets flag when code param not provided."""
    monkeypatch.setenv("VISIBE_REDACT_CONTENT", "1")
    client = visibe.init(
        api_key="sk_live_test", api_url="http://localhost:3000",
        frameworks=[],
    )
    assert client.redact_content is True


def test_init_redact_content_env_var_true_word(monkeypatch):
    """VISIBE_REDACT_CONTENT=true sets flag."""
    monkeypatch.setenv("VISIBE_REDACT_CONTENT", "true")
    client = visibe.init(
        api_key="sk_live_test", api_url="http://localhost:3000",
        frameworks=[],
    )
    assert client.redact_content is True


def test_init_redact_content_env_var_yes(monkeypatch):
    """VISIBE_REDACT_CONTENT=yes sets flag."""
    monkeypatch.setenv("VISIBE_REDACT_CONTENT", "yes")
    client = visibe.init(
        api_key="sk_live_test", api_url="http://localhost:3000",
        frameworks=[],
    )
    assert client.redact_content is True


def test_init_redact_content_env_var_false(monkeypatch):
    """VISIBE_REDACT_CONTENT=0 does not set flag."""
    monkeypatch.setenv("VISIBE_REDACT_CONTENT", "0")
    client = visibe.init(
        api_key="sk_live_test", api_url="http://localhost:3000",
        frameworks=[],
    )
    assert client.redact_content is False


def test_init_redact_content_env_var_garbage(monkeypatch):
    """VISIBE_REDACT_CONTENT=garbage defaults to False."""
    monkeypatch.setenv("VISIBE_REDACT_CONTENT", "garbage")
    client = visibe.init(
        api_key="sk_live_test", api_url="http://localhost:3000",
        frameworks=[],
    )
    assert client.redact_content is False


def test_init_redact_content_code_overrides_env(monkeypatch):
    """Code parameter takes precedence over env var."""
    monkeypatch.setenv("VISIBE_REDACT_CONTENT", "1")
    client = visibe.init(
        api_key="sk_live_test", api_url="http://localhost:3000",
        frameworks=[], redact_content=False,
    )
    assert client.redact_content is False


def test_init_redact_content_code_true_overrides_env_false(monkeypatch):
    """Code parameter True wins even when env says 0."""
    monkeypatch.setenv("VISIBE_REDACT_CONTENT", "0")
    client = visibe.init(
        api_key="sk_live_test", api_url="http://localhost:3000",
        frameworks=[], redact_content=True,
    )
    assert client.redact_content is True


def test_content_limit_deprecation_warning():
    """init(content_limit=500) emits DeprecationWarning."""
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        visibe.init(
            api_key="sk_live_test", api_url="http://localhost:3000",
            frameworks=[], content_limit=500,
        )
    dep_warnings = [x for x in w if issubclass(x.category, DeprecationWarning)]
    assert len(dep_warnings) == 1
    assert "content_limit is deprecated" in str(dep_warnings[0].message)
    assert "redact_content=True" in str(dep_warnings[0].message)


def test_content_limit_zero_deprecation_warning():
    """init(content_limit=0) also emits DeprecationWarning."""
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        visibe.init(
            api_key="sk_live_test", api_url="http://localhost:3000",
            frameworks=[], content_limit=0,
        )
    dep_warnings = [x for x in w if issubclass(x.category, DeprecationWarning)]
    assert len(dep_warnings) == 1


def test_no_deprecation_warning_without_content_limit():
    """init() without content_limit does NOT emit DeprecationWarning."""
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        visibe.init(
            api_key="sk_live_test", api_url="http://localhost:3000",
            frameworks=[],
        )
    dep_warnings = [x for x in w if issubclass(x.category, DeprecationWarning)]
    assert len(dep_warnings) == 0


# ---------------------------------------------------------------------------
# Helper: create a Visibe client with mocked API
# ---------------------------------------------------------------------------

def _make_obs(monkeypatch, *, redact_content=False):
    """Create a Visibe client with stubbed API methods."""
    obs = Visibe(
        api_key="sk_live_test", api_url="http://localhost:3000",
        redact_content=redact_content,
    )
    monkeypatch.setattr(obs.api_client, "create_trace", lambda data: True)
    monkeypatch.setattr(obs.api_client, "send_span", lambda tid, data: True)
    monkeypatch.setattr(obs.api_client, "complete_trace", lambda tid, data: True)
    monkeypatch.setattr(obs._batcher, "flush", lambda: None)
    return obs


# ---------------------------------------------------------------------------
# Task 2: Client enforcement — create_trace
# ---------------------------------------------------------------------------

def test_create_trace_adds_content_redacted_flag(monkeypatch):
    """create_trace() adds content_redacted: True when redacting."""
    obs = Visibe(
        api_key="sk_live_test", api_url="http://localhost:3000",
        redact_content=True,
    )
    captured = {}
    monkeypatch.setattr(obs.api_client, "create_trace", lambda data: captured.update(data) or True)

    obs.create_trace({"trace_id": "t1", "name": "test"})
    assert captured.get("content_redacted") is True


def test_create_trace_no_flag_when_not_redacting(monkeypatch):
    """create_trace() does NOT include content_redacted when False."""
    obs = Visibe(
        api_key="sk_live_test", api_url="http://localhost:3000",
        redact_content=False,
    )
    captured = {}
    monkeypatch.setattr(obs.api_client, "create_trace", lambda data: captured.update(data) or True)

    obs.create_trace({"trace_id": "t1", "name": "test"})
    assert "content_redacted" not in captured


# ---------------------------------------------------------------------------
# Task 2: Client enforcement — send_span
# ---------------------------------------------------------------------------

def test_send_span_strips_text_when_redacting(monkeypatch):
    """send_span() removes input_text and output_text from span data."""
    obs = Visibe(
        api_key="sk_live_test", api_url="http://localhost:3000",
        redact_content=True,
    )
    captured = {}
    monkeypatch.setattr(obs.api_client, "send_span", lambda tid, data: captured.update(data) or True)

    obs.send_span("t1", {
        "span_id": "s1", "type": "llm_call",
        "input_text": "secret prompt", "output_text": "secret response",
        "model": "gpt-4o", "input_tokens": 10, "output_tokens": 20,
    })
    assert "input_text" not in captured
    assert "output_text" not in captured
    assert captured["model"] == "gpt-4o"
    assert captured["input_tokens"] == 10


def test_send_span_keeps_text_when_not_redacting(monkeypatch):
    """send_span() preserves all fields when redact_content=False."""
    obs = Visibe(
        api_key="sk_live_test", api_url="http://localhost:3000",
        redact_content=False,
    )
    captured = {}
    monkeypatch.setattr(obs.api_client, "send_span", lambda tid, data: captured.update(data) or True)

    obs.send_span("t1", {
        "span_id": "s1", "type": "llm_call",
        "input_text": "my prompt", "output_text": "my response",
        "model": "gpt-4o",
    })
    assert captured["input_text"] == "my prompt"
    assert captured["output_text"] == "my response"


def test_send_span_keeps_error_message_when_redacting(monkeypatch):
    """send_span() intentionally keeps error_message for debugging."""
    obs = Visibe(
        api_key="sk_live_test", api_url="http://localhost:3000",
        redact_content=True,
    )
    captured = {}
    monkeypatch.setattr(obs.api_client, "send_span", lambda tid, data: captured.update(data) or True)

    obs.send_span("t1", {
        "span_id": "s1", "type": "error",
        "input_text": "prompt that caused error",
        "error_message": "Rate limit exceeded",
        "error_type": "RateLimitError",
    })
    assert "input_text" not in captured
    assert captured["error_message"] == "Rate limit exceeded"
    assert captured["error_type"] == "RateLimitError"


# ---------------------------------------------------------------------------
# Task 2: Client enforcement — queue_span
# ---------------------------------------------------------------------------

def test_queue_span_strips_text_when_redacting(monkeypatch):
    """queue_span() removes input_text and output_text from span data."""
    obs = Visibe(
        api_key="sk_live_test", api_url="http://localhost:3000",
        redact_content=True,
    )
    captured = {}
    monkeypatch.setattr(obs._batcher, "add", lambda tid, data: captured.update(data))

    obs.queue_span("t1", {
        "span_id": "s1", "type": "llm_call",
        "input_text": "secret prompt", "output_text": "secret response",
        "model": "gpt-4o", "cost": 0.002,
    })
    assert "input_text" not in captured
    assert "output_text" not in captured
    assert captured["model"] == "gpt-4o"
    assert captured["cost"] == 0.002


def test_queue_span_keeps_text_when_not_redacting(monkeypatch):
    """queue_span() preserves all fields when redact_content=False."""
    obs = Visibe(
        api_key="sk_live_test", api_url="http://localhost:3000",
        redact_content=False,
    )
    captured = {}
    monkeypatch.setattr(obs._batcher, "add", lambda tid, data: captured.update(data))

    obs.queue_span("t1", {
        "span_id": "s1", "type": "llm_call",
        "input_text": "my prompt", "output_text": "my response",
    })
    assert captured["input_text"] == "my prompt"
    assert captured["output_text"] == "my response"


# ---------------------------------------------------------------------------
# Task 2: Client enforcement — complete_trace
# ---------------------------------------------------------------------------

def test_complete_trace_omits_prompt_when_redacting(monkeypatch):
    """complete_trace() strips prompt from summary when redacting."""
    obs = Visibe(
        api_key="sk_live_test", api_url="http://localhost:3000",
        redact_content=True,
    )
    captured = {}
    monkeypatch.setattr(obs.api_client, "complete_trace", lambda tid, data: captured.update(data) or True)
    monkeypatch.setattr(obs._batcher, "flush", lambda: None)

    obs.complete_trace("t1", {
        "status": "completed", "prompt": "Tell me a joke",
        "total_cost": 0.005, "llm_call_count": 1,
    })
    assert "prompt" not in captured
    assert captured["status"] == "completed"
    assert captured["total_cost"] == 0.005


def test_complete_trace_keeps_prompt_when_not_redacting(monkeypatch):
    """complete_trace() preserves prompt when not redacting."""
    obs = Visibe(
        api_key="sk_live_test", api_url="http://localhost:3000",
        redact_content=False,
    )
    captured = {}
    monkeypatch.setattr(obs.api_client, "complete_trace", lambda tid, data: captured.update(data) or True)
    monkeypatch.setattr(obs._batcher, "flush", lambda: None)

    obs.complete_trace("t1", {
        "status": "completed", "prompt": "Tell me a joke",
        "total_cost": 0.005,
    })
    assert captured["prompt"] == "Tell me a joke"


# ---------------------------------------------------------------------------
# Task 2: Client enforcement — structural fields preserved
# ---------------------------------------------------------------------------

def test_structural_fields_preserved_when_redacting(monkeypatch):
    """Model, tokens, cost, duration_ms, tool_name, error_type all preserved."""
    obs = Visibe(
        api_key="sk_live_test", api_url="http://localhost:3000",
        redact_content=True,
    )
    captured = {}
    monkeypatch.setattr(obs.api_client, "send_span", lambda tid, data: captured.update(data) or True)

    obs.send_span("t1", {
        "span_id": "s1", "type": "llm_call",
        "model": "gpt-4o", "provider": "openai",
        "input_tokens": 100, "output_tokens": 200,
        "cost": 0.005, "duration_ms": 1234,
        "status": "completed", "agent_name": "my-agent",
        "input_text": "secret", "output_text": "also secret",
    })
    assert captured["model"] == "gpt-4o"
    assert captured["provider"] == "openai"
    assert captured["input_tokens"] == 100
    assert captured["output_tokens"] == 200
    assert captured["cost"] == 0.005
    assert captured["duration_ms"] == 1234
    assert captured["status"] == "completed"
    assert captured["agent_name"] == "my-agent"
    assert "input_text" not in captured
    assert "output_text" not in captured


# ---------------------------------------------------------------------------
# Task 2: Session _end() — prompt omission
# ---------------------------------------------------------------------------

def test_session_end_omits_prompt_when_redacting(monkeypatch):
    """Session _end() does not include prompt in completion dict when redacting."""
    obs = Visibe(
        api_key="sk_live_test", api_url="http://localhost:3000",
        redact_content=True,
    )
    monkeypatch.setattr(obs.api_client, "create_trace", lambda data: True)
    monkeypatch.setattr(obs.api_client, "send_span", lambda tid, data: True)
    monkeypatch.setattr(obs._batcher, "flush", lambda: None)

    captured_summary = {}
    monkeypatch.setattr(obs.api_client, "complete_trace", lambda tid, data: captured_summary.update(data) or True)

    with obs.session("test-session"):
        obs.create_trace({'trace_id': 'sub-1', 'framework': 'openai', 'name': 'x'})
        obs.complete_trace('sub-1', {
            'model': 'gpt-4o', 'prompt': 'Tell me a joke',
            'total_cost': 0.002, 'total_input_tokens': 20,
            'total_output_tokens': 10, 'llm_call_count': 1,
        })

    assert 'prompt' not in captured_summary
    assert captured_summary.get('model') == 'gpt-4o'
    assert captured_summary.get('total_input_tokens') == 20


def test_session_end_keeps_prompt_when_not_redacting(monkeypatch):
    """Session _end() includes prompt when not redacting."""
    obs = Visibe(
        api_key="sk_live_test", api_url="http://localhost:3000",
        redact_content=False,
    )
    monkeypatch.setattr(obs.api_client, "create_trace", lambda data: True)
    monkeypatch.setattr(obs.api_client, "send_span", lambda tid, data: True)
    monkeypatch.setattr(obs._batcher, "flush", lambda: None)

    captured_summary = {}
    monkeypatch.setattr(obs.api_client, "complete_trace", lambda tid, data: captured_summary.update(data) or True)

    with obs.session("test-session"):
        obs.create_trace({'trace_id': 'sub-1', 'framework': 'openai', 'name': 'x'})
        obs.complete_trace('sub-1', {
            'model': 'gpt-4o', 'prompt': 'Tell me a joke',
            'total_cost': 0.002, 'total_input_tokens': 20,
            'total_output_tokens': 10, 'llm_call_count': 1,
        })

    assert captured_summary.get('prompt') == 'Tell me a joke'


# ---------------------------------------------------------------------------
# Task 3: SpanBatcher defense-in-depth
# ---------------------------------------------------------------------------

def test_batcher_strips_text_defense_in_depth():
    """SpanBatcher.add() strips text fields as backstop when redacting."""
    from visibe.api import APIClient, SpanBatcher

    api_client = APIClient("http://localhost:3000", "sk_live_test", 10)
    batcher = SpanBatcher(api_client, redact_content=True)

    span_data = {
        "span_id": "s1", "type": "llm_call",
        "input_text": "secret prompt", "output_text": "secret response",
        "model": "gpt-4o", "input_tokens": 10,
    }
    batcher.add("t1", span_data)

    # Check the buffer directly — span should have text fields removed
    assert len(batcher._buffer) == 1
    _, buffered_span = batcher._buffer[0]
    assert "input_text" not in buffered_span
    assert "output_text" not in buffered_span
    assert buffered_span["model"] == "gpt-4o"
    assert buffered_span["input_tokens"] == 10

    batcher.shutdown()


def test_batcher_keeps_text_when_not_redacting():
    """SpanBatcher.add() preserves text fields when not redacting."""
    from visibe.api import APIClient, SpanBatcher

    api_client = APIClient("http://localhost:3000", "sk_live_test", 10)
    batcher = SpanBatcher(api_client, redact_content=False)

    span_data = {
        "span_id": "s1", "type": "llm_call",
        "input_text": "my prompt", "output_text": "my response",
        "model": "gpt-4o",
    }
    batcher.add("t1", span_data)

    assert len(batcher._buffer) == 1
    _, buffered_span = batcher._buffer[0]
    assert buffered_span["input_text"] == "my prompt"
    assert buffered_span["output_text"] == "my response"

    batcher.shutdown()


def test_batcher_default_no_redaction():
    """SpanBatcher without explicit redact_content defaults to no redaction."""
    from visibe.api import APIClient, SpanBatcher

    api_client = APIClient("http://localhost:3000", "sk_live_test", 10)
    batcher = SpanBatcher(api_client)

    span_data = {
        "span_id": "s1", "type": "llm_call",
        "input_text": "my prompt", "output_text": "my response",
    }
    batcher.add("t1", span_data)

    _, buffered_span = batcher._buffer[0]
    assert buffered_span["input_text"] == "my prompt"

    batcher.shutdown()
