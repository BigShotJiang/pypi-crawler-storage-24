"""
Unit tests for visibe/client.py — type detection functions and Visibe client.
No framework dependencies required.
"""
import types
import pytest

from visibe.client import (
    _is_openai_client,
    _is_langchain_runnable,
    _is_crewai_crew,
    _is_autogen_model_client,
    _is_bedrock_client,
    _is_anthropic_client,
    Visibe,
)


# ------------------------------------------------------------------
# Helper: minimal mock objects with just the right attributes
# ------------------------------------------------------------------

def openai_like():
    return types.SimpleNamespace(
        chat=types.SimpleNamespace(
            completions=types.SimpleNamespace(create=lambda: None)
        )
    )


def langchain_like():
    return types.SimpleNamespace(invoke=lambda x: x, get_graph=lambda: None)


def crewai_like():
    return types.SimpleNamespace(kickoff=lambda: None, agents=[], tasks=[])


def autogen_like():
    return types.SimpleNamespace(
        create=lambda: None,
        create_stream=lambda: None,
        model_info={"family": "gpt-4o"},
    )


def bedrock_like_via_metadata():
    service_model = types.SimpleNamespace(service_name="bedrock-runtime")
    meta = types.SimpleNamespace(service_model=service_model)
    return types.SimpleNamespace(meta=meta)


def bedrock_like_via_duck():
    return types.SimpleNamespace(
        converse=lambda: None,
        converse_stream=lambda: None,
        invoke_model=lambda: None,
        meta=types.SimpleNamespace(),
    )


# ------------------------------------------------------------------
# _is_openai_client
# ------------------------------------------------------------------

def test_is_openai_client_positive():
    assert _is_openai_client(openai_like()) is True


def test_is_openai_client_rejects_string():
    assert _is_openai_client("not a client") is False


def test_is_openai_client_rejects_none():
    assert _is_openai_client(None) is False


def test_is_openai_client_rejects_bedrock():
    assert _is_openai_client(bedrock_like_via_duck()) is False


def test_is_openai_client_rejects_missing_completions():
    obj = types.SimpleNamespace(chat=types.SimpleNamespace())  # no .completions
    assert _is_openai_client(obj) is False


# ------------------------------------------------------------------
# _is_langchain_runnable
# ------------------------------------------------------------------

def test_is_langchain_runnable_positive():
    assert _is_langchain_runnable(langchain_like()) is True


def test_is_langchain_runnable_rejects_string():
    assert _is_langchain_runnable("chain") is False


def test_is_langchain_runnable_rejects_invoke_only():
    obj = types.SimpleNamespace(invoke=lambda x: x)  # missing get_graph
    assert _is_langchain_runnable(obj) is False


def test_is_langchain_runnable_rejects_none():
    assert _is_langchain_runnable(None) is False


# ------------------------------------------------------------------
# _is_crewai_crew
# ------------------------------------------------------------------

def test_is_crewai_crew_positive():
    assert _is_crewai_crew(crewai_like()) is True


def test_is_crewai_crew_rejects_missing_tasks():
    obj = types.SimpleNamespace(kickoff=lambda: None, agents=[])
    assert _is_crewai_crew(obj) is False


def test_is_crewai_crew_rejects_none():
    assert _is_crewai_crew(None) is False


def test_is_crewai_crew_rejects_openai():
    assert _is_crewai_crew(openai_like()) is False


# ------------------------------------------------------------------
# _is_autogen_model_client
# ------------------------------------------------------------------

def test_is_autogen_model_client_positive():
    assert _is_autogen_model_client(autogen_like()) is True


def test_is_autogen_model_client_rejects_missing_model_info():
    obj = types.SimpleNamespace(create=lambda: None, create_stream=lambda: None)
    assert _is_autogen_model_client(obj) is False


def test_is_autogen_model_client_rejects_none():
    assert _is_autogen_model_client(None) is False


# ------------------------------------------------------------------
# _is_bedrock_client
# ------------------------------------------------------------------

def test_is_bedrock_client_via_service_metadata():
    assert _is_bedrock_client(bedrock_like_via_metadata()) is True


def test_is_bedrock_client_wrong_service_name():
    service_model = types.SimpleNamespace(service_name="s3")
    meta = types.SimpleNamespace(service_model=service_model)
    obj = types.SimpleNamespace(meta=meta)
    assert _is_bedrock_client(obj) is False


def test_is_bedrock_client_via_duck_typing():
    assert _is_bedrock_client(bedrock_like_via_duck()) is True


def test_is_bedrock_client_rejects_string():
    assert _is_bedrock_client("bedrock") is False


def test_is_bedrock_client_rejects_none():
    assert _is_bedrock_client(None) is False


def test_is_bedrock_client_rejects_openai():
    assert _is_bedrock_client(openai_like()) is False


# ------------------------------------------------------------------
# _is_anthropic_client
# ------------------------------------------------------------------

def anthropic_like():
    return types.SimpleNamespace(
        messages=types.SimpleNamespace(create=lambda: None, stream=lambda: None)
    )


def test_is_anthropic_client_positive():
    assert _is_anthropic_client(anthropic_like()) is True


def test_is_anthropic_client_rejects_openai():
    # OpenAI client has .chat — must not be detected as Anthropic
    assert _is_anthropic_client(openai_like()) is False


def test_is_anthropic_client_rejects_string():
    assert _is_anthropic_client("anthropic") is False


def test_is_anthropic_client_rejects_none():
    assert _is_anthropic_client(None) is False


def test_is_anthropic_client_rejects_missing_create():
    obj = types.SimpleNamespace(messages=types.SimpleNamespace())  # no .create
    assert _is_anthropic_client(obj) is False


# ------------------------------------------------------------------
# Visibe client — init validation
# ------------------------------------------------------------------

def test_visibe_invalid_timeout_raises():
    with pytest.raises(ValueError, match="timeout"):
        Visibe(api_key="sk_live_test", timeout=0)


def test_visibe_negative_timeout_raises():
    with pytest.raises(ValueError, match="timeout"):
        Visibe(api_key="sk_live_test", timeout=-1)


def test_visibe_invalid_api_url_raises():
    with pytest.raises(ValueError, match="http"):
        Visibe(api_key="sk_live_test", api_url="localhost:3000")


def test_visibe_trailing_slash_stripped():
    obs = Visibe(api_key="sk_live_abc", api_url="http://localhost:3000/")
    assert not obs.api_url.endswith("/")


def test_visibe_session_id_stored():
    obs = Visibe(api_key="sk_live_abc", api_url="http://localhost:3000", session_id="user-42")
    assert obs.session_id == "user-42"


def test_visibe_api_key_stored():
    obs = Visibe(api_key="sk_live_abc123", api_url="http://localhost:3000")
    assert obs.api_key == "sk_live_abc123"


# ------------------------------------------------------------------
# Visibe.create_trace — session_id injection
# ------------------------------------------------------------------

def test_create_trace_injects_session_id(monkeypatch):
    obs = Visibe(api_key="sk_live_abc", api_url="http://localhost:3000", session_id="sess-99")

    captured = {}
    monkeypatch.setattr(obs.api_client, "create_trace", lambda data: captured.update(data) or True)

    obs.create_trace({"trace_id": "t1", "name": "test"})
    assert captured.get("session_id") == "sess-99"


def test_create_trace_does_not_inject_session_id_if_already_set(monkeypatch):
    obs = Visibe(api_key="sk_live_abc", api_url="http://localhost:3000", session_id="sess-99")

    captured = {}
    monkeypatch.setattr(obs.api_client, "create_trace", lambda data: captured.update(data) or True)

    obs.create_trace({"trace_id": "t1", "session_id": "custom-session"})
    assert captured["session_id"] == "custom-session"


def test_create_trace_no_session_id_when_not_set(monkeypatch):
    obs = Visibe(api_key="sk_live_abc", api_url="http://localhost:3000")

    captured = {}
    monkeypatch.setattr(obs.api_client, "create_trace", lambda data: captured.update(data) or True)

    obs.create_trace({"trace_id": "t1"})
    assert "session_id" not in captured


# ------------------------------------------------------------------
# Visibe.instrument — unsupported type raises TypeError
# ------------------------------------------------------------------

def test_instrument_unsupported_type_raises():
    obs = Visibe(api_key="sk_live_abc", api_url="http://localhost:3000")
    with pytest.raises(TypeError, match="Unsupported"):
        obs.instrument("not a valid client")


def test_track_none_client_raises():
    obs = Visibe(api_key="sk_live_abc", api_url="http://localhost:3000")
    with pytest.raises(TypeError):
        obs.track(None)


def test_track_unsupported_type_raises():
    obs = Visibe(api_key="sk_live_abc", api_url="http://localhost:3000")
    with pytest.raises(TypeError, match="Unsupported"):
        obs.track("not a client")


# ------------------------------------------------------------------
# Session context — first_framework / first_model / first_prompt
# ------------------------------------------------------------------

from visibe.context import _SessionContext, _active_session


def _make_obs(monkeypatch):
    """Visibe instance with create_trace / complete_trace / batcher stubbed out."""
    obs = Visibe(api_key="sk_live_abc", api_url="http://localhost:3000")
    monkeypatch.setattr(obs.api_client, "create_trace", lambda data: True)
    monkeypatch.setattr(obs.api_client, "complete_trace", lambda tid, data: True)
    monkeypatch.setattr(obs._batcher, "flush", lambda: None)
    return obs


def test_create_trace_captures_first_framework(monkeypatch):
    obs = _make_obs(monkeypatch)
    sc = _SessionContext(trace_id="t1")
    token = _active_session.set(sc)
    try:
        obs.create_trace({'trace_id': 'sub-1', 'framework': 'openai', 'name': 'x'})
        assert sc.first_framework == 'openai'
    finally:
        _active_session.reset(token)


def test_create_trace_does_not_overwrite_first_framework(monkeypatch):
    obs = _make_obs(monkeypatch)
    sc = _SessionContext(trace_id="t1")
    token = _active_session.set(sc)
    try:
        obs.create_trace({'trace_id': 'sub-1', 'framework': 'openai', 'name': 'x'})
        obs.create_trace({'trace_id': 'sub-2', 'framework': 'bedrock', 'name': 'y'})
        assert sc.first_framework == 'openai'  # second call must not overwrite
    finally:
        _active_session.reset(token)


def test_complete_trace_captures_first_model_and_prompt(monkeypatch):
    obs = _make_obs(monkeypatch)
    sc = _SessionContext(trace_id="t1")
    token = _active_session.set(sc)
    try:
        obs.complete_trace('sub-1', {
            'model': 'gpt-4o',
            'prompt': 'Hello world',
            'total_cost': 0.01,
            'total_input_tokens': 10,
            'total_output_tokens': 5,
            'llm_call_count': 1,
        })
        assert sc.first_model == 'gpt-4o'
        assert sc.first_prompt == 'Hello world'
    finally:
        _active_session.reset(token)


def test_complete_trace_does_not_overwrite_first_model(monkeypatch):
    obs = _make_obs(monkeypatch)
    sc = _SessionContext(trace_id="t1")
    token = _active_session.set(sc)
    try:
        obs.complete_trace('sub-1', {
            'model': 'gpt-4o', 'prompt': 'First prompt',
            'total_cost': 0.01, 'total_input_tokens': 10,
            'total_output_tokens': 5, 'llm_call_count': 1,
        })
        obs.complete_trace('sub-2', {
            'model': 'claude-3-haiku', 'prompt': 'Second prompt',
            'total_cost': 0.005, 'total_input_tokens': 8,
            'total_output_tokens': 4, 'llm_call_count': 1,
        })
        assert sc.first_model == 'gpt-4o'
        assert sc.first_prompt == 'First prompt'
    finally:
        _active_session.reset(token)


def test_complete_trace_accumulates_tokens_and_cost(monkeypatch):
    obs = _make_obs(monkeypatch)
    sc = _SessionContext(trace_id="t1")
    token = _active_session.set(sc)
    try:
        obs.complete_trace('sub-1', {
            'model': 'gpt-4o', 'prompt': 'p1',
            'total_cost': 0.01, 'total_input_tokens': 100,
            'total_output_tokens': 50, 'llm_call_count': 2,
        })
        obs.complete_trace('sub-2', {
            'model': 'gpt-4o', 'prompt': 'p2',
            'total_cost': 0.005, 'total_input_tokens': 80,
            'total_output_tokens': 40, 'llm_call_count': 1,
        })
        assert sc.total_input == 180
        assert sc.total_output == 90
        assert round(sc.total_cost, 6) == 0.015
        assert sc.llm_call_count == 3
    finally:
        _active_session.reset(token)


def test_session_end_forwards_first_fields_to_complete_trace(monkeypatch):
    """_end() must include first_framework/model/prompt in the PATCH payload."""
    obs = _make_obs(monkeypatch)

    captured_summary = {}

    def fake_complete(tid, data):
        captured_summary.update(data)
        return True

    monkeypatch.setattr(obs.api_client, "complete_trace", fake_complete)

    ctx_mgr = obs.session("test-session")

    with ctx_mgr as sc:
        # Simulate an integration calling create_trace then complete_trace
        obs.create_trace({'trace_id': 'sub-1', 'framework': 'openai', 'name': 'x'})
        obs.complete_trace('sub-1', {
            'model': 'gpt-4o', 'prompt': 'Tell me a joke',
            'total_cost': 0.002, 'total_input_tokens': 20,
            'total_output_tokens': 10, 'llm_call_count': 1,
        })

    assert captured_summary.get('framework') == 'openai'
    assert captured_summary.get('model') == 'gpt-4o'
    assert captured_summary.get('prompt') == 'Tell me a joke'
    assert captured_summary.get('total_input_tokens') == 20
    assert captured_summary.get('total_output_tokens') == 10


def test_session_end_omits_fields_when_no_llm_calls(monkeypatch):
    """If no integrations fired, first_* fields should NOT appear in the payload."""
    obs = _make_obs(monkeypatch)

    captured_summary = {}

    def fake_complete(tid, data):
        captured_summary.update(data)
        return True

    monkeypatch.setattr(obs.api_client, "complete_trace", fake_complete)

    with obs.session("empty-session"):
        pass  # no LLM calls

    assert 'framework' not in captured_summary
    assert 'model' not in captured_summary
    assert 'prompt' not in captured_summary
