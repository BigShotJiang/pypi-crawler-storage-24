# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from .._models import BaseModel

__all__ = ["AgentValidateResponse", "RequestMetadata"]


class RequestMetadata(BaseModel):
    """Response metadata including timestamp and request ID."""

    request_id: Optional[str] = None
    """Unique request identifier for tracing and support."""


class AgentValidateResponse(BaseModel):
    message: str
    """Detailed message about the validation outcome."""

    status: str
    """The result status of the validation."""

    request_metadata: Optional[RequestMetadata] = None
    """Response metadata including timestamp and request ID."""

    suggestion: Optional[str] = None
    """Optional suggestion if any errors were found."""
