import asyncio
import base64
import gzip
import json

import pytest

import llmops_observability.trace_manager as trace_manager
from llmops_observability.trace_manager import (
    TraceManager,
    SpanData,
    SDKTraceData,
    serialize_value,
    safe_locals,
    track_function,
)


@pytest.fixture(autouse=True)
def _configure_trace_manager_env(monkeypatch):
    """
    Ensure TraceManager sees a valid SQS configuration and a stable
    project/environment so start_trace() actually activates traces in tests.
    """
    # Provide minimal SQS configuration via environment
    monkeypatch.setenv("AWS_SQS_URL", "https://example.com/test-queue")
    monkeypatch.setenv("PROJECT_ID", "test_project")
    monkeypatch.setenv("ENV", "test")

    # Reset TraceManager active state between tests to avoid cross-test bleed
    TraceManager._active["trace_id"] = None
    TraceManager._active["trace_config"] = None
    TraceManager._active["start_time"] = None
    TraceManager._active["spans"] = []
    TraceManager._active["stack"] = []
    TraceManager._active["finalized_trace_id"] = None
    TraceManager._active["finalized_timestamp"] = None


def test_serialize_value_preserves_large_payload_by_default():
    large = "x" * (250 * 1024)
    out = serialize_value({"data": large})
    assert isinstance(out, dict)
    assert out["data"] == large
    assert "_truncated" not in out


def test_serialize_value_passes_small_payload():
    payload = {"a": 1, "b": "ok"}
    assert serialize_value(payload) == payload


def test_safe_locals_filters_private():
    data = {"ok": 1, "_private": 2}
    safe = safe_locals(data)
    assert "ok" in safe
    assert "_private" not in safe


def test_start_trace_sets_active():
    trace_id = TraceManager.start_trace(name="op_test")
    assert TraceManager.has_active_trace()
    assert TraceManager._active["trace_id"] == trace_id
    assert TraceManager._active["trace_config"]["project_id"] == "test_project"
    assert TraceManager._active["trace_config"]["environment"] == "test"
    assert TraceManager._active["start_time"] is not None


def test_span_stack_helpers():
    TraceManager.push_span_context("span-1")
    assert TraceManager.get_current_parent_span_id() == "span-1"
    popped = TraceManager.pop_span_context()
    assert popped == "span-1"
    assert TraceManager.get_current_parent_span_id() is None


def test_pop_span_context_empty():
    assert TraceManager.pop_span_context() is None


def test_add_span_injects_metadata():
    TraceManager.start_trace(name="trace_with_span")
    span = SpanData(span_id="s1", span_name="work", span_type="span")
    TraceManager.add_span(span)
    assert TraceManager._active["spans"]
    assert span.metadata["environment"] == "test"
    assert span.metadata["project_id"] == "test_project"


def test_add_span_without_active_trace_noop():
    span = SpanData(span_id="s1", span_name="work", span_type="span")
    TraceManager.add_span(span)
    assert TraceManager._active["spans"] == []


def test_finalize_and_send_without_active_trace():
    assert TraceManager.finalize_and_send() is False


def test_finalize_and_send_start_time_missing(monkeypatch):
    TraceManager._active["trace_id"] = "t1"
    TraceManager._active["trace_config"] = {"name": "n"}
    TraceManager._active["start_time"] = None
    assert TraceManager.finalize_and_send() is False


def test_finalize_and_send_sqs_disabled(monkeypatch):
    TraceManager.start_trace(name="trace")
    monkeypatch.setattr(trace_manager, "is_sqs_enabled", lambda: False)
    assert TraceManager.finalize_and_send() is False


def test_finalize_and_send_sqs_enabled(monkeypatch):
    sent = []

    def _send(payload):
        sent.append(payload)
        return True

    TraceManager.start_trace(name="trace")
    monkeypatch.setattr(trace_manager, "is_sqs_enabled", lambda: True)
    monkeypatch.setattr(trace_manager, "send_to_sqs_immediate", _send)

    assert TraceManager.finalize_and_send(trace_name="done") is True
    assert sent


def test_finalize_and_send_send_failure(monkeypatch):
    def _send(_payload):
        raise RuntimeError("boom")

    TraceManager.start_trace(name="trace")
    monkeypatch.setattr(trace_manager, "is_sqs_enabled", lambda: True)
    monkeypatch.setattr(trace_manager, "send_to_sqs_immediate", _send)
    assert TraceManager.finalize_and_send(trace_name="done") is False


def test_late_span_submission(monkeypatch):
    sent = []

    def _send(payload):
        sent.append(payload)
        return True

    TraceManager.start_trace(name="trace")
    monkeypatch.setattr(trace_manager, "is_sqs_enabled", lambda: True)
    monkeypatch.setattr(trace_manager, "send_to_sqs_immediate", _send)
    assert TraceManager.finalize_and_send(trace_name="done") is True

    late_span = SpanData(span_id="late", span_name="late_span", span_type="span")
    TraceManager.add_span(late_span)

    assert len(sent) >= 2
    payload = json.loads(sent[-1])
    assert payload["type"] == "late_span_update"


def test_submit_late_span_handles_send_error(monkeypatch):
    def _send(_payload):
        raise RuntimeError("boom")

    monkeypatch.setattr(trace_manager, "send_to_sqs_immediate", _send)
    span = SpanData(span_id="s1", span_name="late", span_type="span")
    TraceManager._submit_late_span_async(span, "trace-id")


def test_prepare_for_sqs_returns_compressed_payload():
    span = SpanData(span_id="s1", span_name="span", span_type="span", input_data={"a": 1})
    trace = SDKTraceData(
        trace_id="t1",
        trace_name="trace",
        project_id="p",
        environment="dev",
        user_id="u",
        session_id="s",
        start_time=0.0,
        end_time=1.0,
        duration_ms=1000,
        spans=[span],
        total_spans=1,
        total_generations=0,
    )

    payload = trace.prepare_for_sqs()
    decoded = json.loads(payload)

    # New implementation only compresses when the payload exceeds
    # COMPRESSION_THRESHOLD. For small traces we now send plain JSON.
    if decoded.get("compressed"):
        data = gzip.decompress(base64.b64decode(decoded["data"])).decode("utf-8")
        body = json.loads(data)
    else:
        body = decoded

    assert body["trace_id"] == "t1"
    assert body["spans"][0]["span_name"] == "span"


def test_prepare_for_sqs_uses_s3_reference_when_over_sqs_limit(monkeypatch):
    monkeypatch.setattr(trace_manager, "COMPRESSION_THRESHOLD", 1)
    monkeypatch.setattr(trace_manager, "MAX_SQS_SIZE", 100)

    import llmops_observability.s3_extended_client as s3_extended_client

    class DummyS3Client:
        def is_enabled(self):
            return True

        def store_in_s3(self, payload_dict, trace_id):
            assert payload_dict["trace_id"] == trace_id
            assert "spans" in payload_dict
            return True, "LLMOps/backup_traces/compressed_traces/2026-03-03/t1.json.gz", None

        def create_sqs_reference(self, s3_key):
            return {
                "__S3_EXTENDED_PAYLOAD__": True,
                "s3_bucket": "unit-test-bucket",
                "s3_key": s3_key,
                "timestamp": "2026-03-03T00:00:00+00:00",
            }

    monkeypatch.setattr(s3_extended_client, "get_s3_extended_client", lambda: DummyS3Client())

    noisy_text = "".join(chr(33 + (i % 90)) for i in range(120_000))
    span = SpanData(span_id="s1", span_name="span", span_type="span", output_data={"blob": noisy_text})
    trace = SDKTraceData(
        trace_id="t1",
        trace_name="trace",
        project_id="p",
        environment="dev",
        user_id="u",
        session_id="s",
        start_time=0.0,
        end_time=1.0,
        duration_ms=1000,
        spans=[span],
        total_spans=1,
        total_generations=0,
    )

    payload = trace.prepare_for_sqs()
    decoded = json.loads(payload)

    assert decoded["__S3_EXTENDED_PAYLOAD__"] is True
    assert decoded["s3_bucket"] == "unit-test-bucket"
    assert decoded["s3_key"].endswith("t1.json.gz")


def test_ensure_json_object_preserves_large_string_when_unbounded():
    large = "y" * (300 * 1024)
    wrapped = trace_manager.ensure_json_object(large, max_size=None, key="payload")
    assert wrapped == {"payload": large}


def test_ensure_json_object_truncates_when_limit_is_explicit():
    large = "z" * 5000
    wrapped = trace_manager.ensure_json_object(large, max_size=256, key="payload")
    assert wrapped["payload"]["_truncated"] is True
    assert wrapped["payload"]["_original_size_bytes"] > 256


def test_track_function_without_trace_returns_result():
    @track_function()
    def add(x, y):
        return x + y

    assert add(2, 3) == 5
    assert TraceManager._active["spans"] == []


def test_track_function_with_active_trace_sync():
    TraceManager.start_trace(name="sync_trace")

    @track_function(metadata={"k": "v"})
    def mul(a, b):
        return a * b

    result = mul(3, 4)
    assert result == 12
    assert len(TraceManager._active["spans"]) == 1
    span = TraceManager._active["spans"][0]
    assert span.span_name == "mul"
    assert span.status == "success"


def test_track_function_error_records_span():
    TraceManager.start_trace(name="sync_trace")

    @track_function()
    def bad():
        raise ValueError("boom")

    try:
        bad()
    except ValueError:
        pass

    span = TraceManager._active["spans"][0]
    assert span.status == "error"


def test_track_function_with_active_trace_async():
    async def _runner():
        TraceManager.start_trace(name="async_trace")

        @track_function()
        async def async_func(value):
            await asyncio.sleep(0)
            return value * 2

        result = await async_func(5)
        assert result == 10
        assert len(TraceManager._active["spans"]) == 1
        assert TraceManager._active["spans"][0].span_name == "async_func"

    asyncio.run(_runner())


def test_track_function_async_without_trace():
    async def _runner():
        @track_function()
        async def async_func(value):
            return value

        result = await async_func(5)
        assert result == 5
        assert TraceManager._active["spans"] == []

    asyncio.run(_runner())


def test_build_function_input_data_capture_locals_list():
    local_vars = {"value": 10, "extra": "skip"}
    data = trace_manager._build_function_input_data(
        args=(),
        kwargs={},
        local_vars=local_vars,
        capture_locals_spec=["value"],
    )
    assert data["locals"] == {"value": 10}


def test_end_trace_returns_trace_id():
    trace_id = TraceManager.start_trace(name="trace")
    assert TraceManager.end_trace() == trace_id


def test_now_format():
    now = TraceManager._now()
    assert "T" in now


# ============================================================
# Additional tests for improved coverage
# ============================================================

def test_serialize_value_exception_fallback():
    """serialize_value returns str(value) on serialization exception."""
    class BadObj:
        def __str__(self):
            return "bad_obj_str"
    
    # This might serialize, let's try something that definitely won't
    result = serialize_value(BadObj())
    assert isinstance(result, (dict, str))


def test_can_track_span_with_finalized_trace():
    """can_track_span returns True when trace was finalized."""
    TraceManager._active["trace_id"] = None
    TraceManager._active["finalized_trace_id"] = "finalized-123"
    
    assert TraceManager.can_track_span() is True
    
    # Clean up
    TraceManager._active["finalized_trace_id"] = None


def test_can_track_span_no_trace():
    """can_track_span returns False when no active or finalized trace."""
    TraceManager._active["trace_id"] = None
    TraceManager._active["finalized_trace_id"] = None
    
    assert TraceManager.can_track_span() is False


def test_increment_pending_no_active_trace():
    """_increment_pending_if_active returns False when no active trace."""
    TraceManager._active["trace_id"] = None
    
    result = TraceManager._increment_pending_if_active()
    assert result is False


def test_decrement_pending_when_zero():
    """_decrement_pending handles zero count gracefully."""
    TraceManager._pending_count = 0
    TraceManager._decrement_pending()
    assert TraceManager._pending_count == 0


def test_wait_for_pending_immediate():
    """_wait_for_pending returns immediately when count is zero."""
    TraceManager._pending_count = 0
    TraceManager._wait_for_pending()  # Should not block


def test_build_function_input_data_capture_self():
    """_build_function_input_data captures self when requested."""
    class MyClass:
        def __init__(self):
            self.value = 42
    
    obj = MyClass()
    data = trace_manager._build_function_input_data(
        args=(obj, "arg1"),
        kwargs={"key": "value"},
        local_vars={},
        capture_self_flag=True,
    )
    
    assert "self" in data


def test_build_function_input_data_capture_self_no_dict():
    """_build_function_input_data handles self without __dict__."""
    data = trace_manager._build_function_input_data(
        args=(42,),  # Not an object with __dict__
        kwargs={},
        local_vars={},
        capture_self_flag=True,
    )
    
    assert "self" not in data


def test_build_function_input_data_capture_locals_true():
    """_build_function_input_data captures all locals when True."""
    data = trace_manager._build_function_input_data(
        args=(),
        kwargs={},
        local_vars={"var1": 1, "var2": "two", "_private": "skip"},
        capture_locals_spec=True,
    )
    
    assert "locals" in data
    assert "var1" in data["locals"]
    assert "var2" in data["locals"]


def test_build_function_input_data_uses_signature_binding():
    """_build_function_input_data prefers bound args when func provided."""
    def sample(a, b=2, *, c=3):
        return a + b + c

    data = trace_manager._build_function_input_data(
        args=(1,),
        kwargs={"c": 4},
        local_vars=None,
        capture_locals_spec=False,
        capture_self_flag=False,
        func=sample,
    )

    assert data == {"a": 1, "b": 2, "c": 4}


def test_resolve_custom_value_handles_callables_and_locals():
    """_resolve_custom_value resolves callables and locals safely."""
    def two_arg(args, kwargs):
        return "ok"

    def three_arg(args, kwargs, result):
        return f"{result}-ok"

    def bad_callable(args, kwargs):
        raise RuntimeError("boom")

    assert trace_manager._resolve_custom_value(two_arg, (), {}) == "ok"
    assert trace_manager._resolve_custom_value(three_arg, (), {}, result="res") == "res-ok"
    assert trace_manager._resolve_custom_value(bad_callable, (), {}) is None
    assert trace_manager._resolve_custom_value("val", (), {}, local_vars={"val": "x"}) == "x"
    assert trace_manager._resolve_custom_value("literal", (), {}) == "literal"


def test_track_function_with_capture_locals():
    """track_function captures local variables when requested."""
    TraceManager.start_trace(name="capture_locals_trace")

    @track_function(capture_locals=True)
    def func_with_locals(x):
        local_var = x * 2
        return local_var

    result = func_with_locals(5)
    assert result == 10
    
    span = TraceManager._active["spans"][-1]
    # The locals should be captured in input_data
    assert span.input_data is not None


def test_track_function_with_capture_self():
    """track_function captures self for methods."""
    TraceManager.start_trace(name="capture_self_trace")

    class MyService:
        def __init__(self, name):
            self.name = name

        @track_function(capture_self=True)
        def process(self, data):
            return f"{self.name}: {data}"

    svc = MyService("test_service")
    result = svc.process("hello")
    
    assert "test_service" in result
    span = TraceManager._active["spans"][-1]
    # input_data includes function args; capture_self may not be available
    assert span.input_data is not None
    assert "data" in span.input_data


def test_track_function_async_error():
    """track_function handles async function errors."""
    async def _runner():
        TraceManager.start_trace(name="async_error_trace")

        @track_function()
        async def async_error():
            await asyncio.sleep(0)
            raise RuntimeError("async boom")

        try:
            await async_error()
        except RuntimeError:
            pass

        span = TraceManager._active["spans"][-1]
        assert span.status == "error"
        assert "async boom" in span.status_message

    asyncio.run(_runner())


def test_track_function_async_with_capture_locals():
    """track_function async captures locals when requested."""
    async def _runner():
        TraceManager.start_trace(name="async_capture_locals")

        @track_function(capture_locals=["local_val"])
        async def async_with_locals(x):
            local_val = x + 10
            await asyncio.sleep(0)
            return local_val

        result = await async_with_locals(5)
        assert result == 15

    asyncio.run(_runner())


def test_prepare_for_sqs_falls_back_to_compressed_payload_when_s3_unavailable(monkeypatch):
    monkeypatch.setattr(trace_manager, "COMPRESSION_THRESHOLD", 1)
    monkeypatch.setattr(trace_manager, "MAX_SQS_SIZE", 100)

    import llmops_observability.s3_extended_client as s3_extended_client

    monkeypatch.setattr(s3_extended_client, "get_s3_extended_client", lambda: None)

    big_output = "A" * 200_000
    trace = SDKTraceData(
        trace_id="fallback-trace",
        trace_name="trace",
        project_id="p",
        environment="dev",
        user_id="u",
        session_id="s",
        start_time=0.0,
        end_time=1.0,
        duration_ms=1000,
        spans=[SpanData(span_id="s1", span_name="span", span_type="span", output_data={"text": big_output})],
        total_spans=1,
        total_generations=0,
    )

    payload = json.loads(trace.prepare_for_sqs())
    assert payload["compressed"] is True
    assert payload["trace_id"] == "fallback-trace"

    decompressed = gzip.decompress(base64.b64decode(payload["data"])).decode("utf-8")
    decoded_trace = json.loads(decompressed)
    assert decoded_trace["spans"][0]["output_data"]["text"] == big_output


def test_finalize_clears_and_sets_finalized():
    """finalize_and_send sets finalized_trace_id for late span support."""
    sent = []

    def _send(payload):
        sent.append(payload)
        return True

    trace_id = TraceManager.start_trace(name="finalize_test")
    
    import llmops_observability.trace_manager as tm
    original_is_enabled = tm.is_sqs_enabled
    original_send = tm.send_to_sqs_immediate
    
    tm.is_sqs_enabled = lambda: True
    tm.send_to_sqs_immediate = _send
    
    TraceManager.finalize_and_send()
    
    # Restore
    tm.is_sqs_enabled = original_is_enabled
    tm.send_to_sqs_immediate = original_send
    
    # Verify finalized_trace_id was set
    assert TraceManager._active["finalized_trace_id"] == trace_id


def test_track_function_uses_finalized_trace():
    """track_function uses finalized trace for late spans."""
    sent = []

    def _send(payload):
        sent.append(payload)
        return True

    trace_id = TraceManager.start_trace(name="late_span_trace")
    
    import llmops_observability.trace_manager as tm
    original_is_enabled = tm.is_sqs_enabled
    original_send = tm.send_to_sqs_immediate
    
    tm.is_sqs_enabled = lambda: True
    tm.send_to_sqs_immediate = _send
    
    # Finalize the trace
    TraceManager.finalize_and_send()
    
    # Now call a tracked function - should create late span
    @track_function()
    def late_func():
        return "late"
    
    late_func()
    
    # Restore
    tm.is_sqs_enabled = original_is_enabled
    tm.send_to_sqs_immediate = original_send
    
    # Should have sent the main trace AND a late span update
    assert len(sent) >= 2


def test_sdk_trace_data_attributes():
    """SDKTraceData stores all provided attributes."""
    span = SpanData(span_id="s1", span_name="test", span_type="span")
    trace = SDKTraceData(
        trace_id="t1",
        trace_name="test_trace",
        project_id="proj",
        environment="dev",
        user_id="user1",
        session_id="sess1",
        start_time=1000.0,
        end_time=2000.0,
        duration_ms=1000,
        spans=[span],
        total_spans=1,
        total_generations=0,
    )
    
    assert trace.trace_id == "t1"
    assert trace.trace_name == "test_trace"
    assert trace.project_id == "proj"
    assert trace.spans[0].span_name == "test"


def test_span_data_all_fields():
    """SpanData stores all provided fields."""
    span = SpanData(
        span_id="s1",
        span_name="test_span",
        span_type="generation",
        parent_span_id="parent1",
        start_time=100.0,
        end_time=200.0,
        duration_ms=100,
        input_data={"key": "value"},
        output_data={"result": "ok"},
        error="some error",
        model_id="model123",
        metadata={"meta": "data"},
        tags=["tag1", "tag2"],
        usage={"input_tokens": 10, "output_tokens": 20},
        prompt="test prompt",
        response="test response",
        status="success",
        status_message="completed",
        level="DEBUG",
    )
    
    assert span.span_id == "s1"
    assert span.model_id == "model123"
    assert span.usage == {"input_tokens": 10, "output_tokens": 20}
    assert span.level == "DEBUG"


def test_serialize_value_handles_bedrock_response_with_streaming_body():
    """serialize_value cleans Bedrock response with StreamingBody."""
    class MockStreamingBody:
        pass

    bedrock_response = {
        "body": MockStreamingBody(),
        "ResponseMetadata": {"HTTPStatusCode": 200},
    }

    result = serialize_value(bedrock_response)
    assert isinstance(result, dict)
    assert "<MockStreamingBody" in result["body"]
    assert result["ResponseMetadata"]["HTTPStatusCode"] == 200


def test_serialize_value_handles_non_serializable_nested_containers():
    """serialize_value cleans nested non-serializable containers."""
    class CustomObj:
        def __str__(self):
            return "custom_obj"

    nested = {
        "level1": {
            "level2": [CustomObj(), {"key": CustomObj()}],
        },
    }

    result = serialize_value(nested)
    assert isinstance(result, dict)
    assert "level1" in result


def test_serialize_value_exception_returns_str():
    """serialize_value returns str(value) on JSON serialization error."""
    class BadEncoder:
        def __init__(self):
            self.value = float('inf')  # JSON can't encode infinity

    result = serialize_value(BadEncoder())
    assert isinstance(result, str)


def test_sdk_trace_data_version_fallback_on_package_not_found(monkeypatch):
    """SDKTraceData falls back to '0.0.0' when package version not found."""
    from importlib.metadata import PackageNotFoundError

    def mock_version(name):
        raise PackageNotFoundError()

    monkeypatch.setattr(trace_manager, "version", mock_version)

    trace = SDKTraceData(
        trace_id="t1",
        trace_name="test",
        project_id="p",
        environment="dev",
    )

    assert trace.sdk_version == "0.0.0"


def test_start_trace_shows_config_warning_once(monkeypatch, caplog):
    """start_trace warns about missing config only once."""
    import llmops_observability.config as config
    import logging

    def mock_get_sqs_config():
        return {"aws_sqs_url": None}

    monkeypatch.setattr(config, "get_sqs_config", mock_get_sqs_config)
    TraceManager._config_warning_shown = False

    with caplog.at_level(logging.WARNING):
        result1 = TraceManager.start_trace(name="test1")
        assert result1 is None
        assert "No SQS URL configured" in caplog.text

        caplog.clear()
        result2 = TraceManager.start_trace(name="test2")
        assert result2 is None
        # Second call should not log warning again
        assert "No SQS URL configured" not in caplog.text

