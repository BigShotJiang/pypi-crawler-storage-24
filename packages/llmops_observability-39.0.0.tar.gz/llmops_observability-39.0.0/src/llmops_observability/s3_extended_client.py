"""
S3 Extended Client for Large SQS Payloads
Handles payloads exceeding SQS limits by storing in S3 and sending references
"""

import json
import logging
import uuid
import gzip
import os
import hashlib
from typing import Dict, Any, Optional, Tuple
from datetime import datetime, timezone

from .config import S3_PREFIX

try:
    import boto3
except ImportError:
    boto3 = None

logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('[llmops_observability] %(levelname)s: %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)


class S3ExtendedClient:
    """
    Manages large payload storage in S3 with automatic spillover from SQS.
    
    When a payload exceeds SQS size limits:
    1. Compress the payload with gzip
    2. Store in S3 with metadata
    3. Send only reference pointer via SQS
    4. Receiver automatically retrieves and decompresses
    
    Features:
    - Automatic compression (gzip) to reduce storage
    - Metadata tracking (size, compression, timestamp)
    - Unique S3 key generation per payload
    - S3 lifecycle policies for cleanup
    - Fallback handling for S3 failures
    """
    
    # S3 payload size threshold (bytes) - if message > this, store in S3
    PAYLOAD_SIZE_THRESHOLD = int(os.getenv("LLMOPS_S3_THRESHOLD", 50_000))  # 50 KB default
    
    # Reference marker to identify S3-stored payloads in SQS messages
    S3_REFERENCE_MARKER = "__S3_EXTENDED_PAYLOAD__"
    
    def __init__(
        self,
        bucket_name: str,
        region: str = "us-east-1",
        prefix: str = S3_PREFIX
    ):
        """
        Initialize S3 Extended Client.
        
        Args:
            bucket_name: S3 bucket for payload storage
            region: AWS region (default: us-east-1)
            prefix: S3 key prefix for all stored payloads
        """
        self.bucket_name = bucket_name
        self.region = region
        self.prefix = prefix
        self.s3_client = None
        self._initialized = False
        
        # Attempt lazy initialization
        try:
            if boto3:
                self.s3_client = boto3.client('s3', region_name=region)
                self._initialized = True
                logger.info(f"S3ExtendedClient initialized: bucket={bucket_name}, region={region}")
            else:
                logger.warning("boto3 not available - S3ExtendedClient disabled")
        except Exception as e:
            logger.error(f"S3ExtendedClient initialization failed: {str(e)}")
    
    def is_enabled(self) -> bool:
        """Check if S3 storage is available."""
        return self._initialized and self.s3_client is not None
    
    def _compress_payload(self, payload: str | bytes) -> bytes:
        """Compress payload with gzip."""
        if isinstance(payload, str):
            payload = payload.encode('utf-8')
        return gzip.compress(payload)
    
    def _decompress_payload(self, compressed: bytes) -> str:
        """Decompress gzip payload."""
        return gzip.decompress(compressed).decode('utf-8')
    
    def _generate_s3_key(self, trace_id: str) -> str:
        """Generate S3 key for payload storage: prefix/YYYY-MM-DD/trace_id.json.gz"""
        date_folder = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        return f"{self.prefix}/{date_folder}/{trace_id}.json.gz"
    
    def _calculate_payload_hash(self, payload: bytes) -> str:
        """Calculate SHA256 hash of payload for integrity checking."""
        return hashlib.sha256(payload).hexdigest()
    
    def store_in_s3(
        self,
        payload_dict: Dict[str, Any],
        trace_id: str
    ) -> Tuple[bool, Optional[str], Optional[str]]:
        """
        Store large payload in S3 and return reference pointer.
        
        Args:
            payload_dict: Dictionary to store in S3
            trace_id: Trace ID for S3 key generation
            
        Returns:
            Tuple of (success, s3_key, error_message)
        """
        if not self.is_enabled():
            return False, None, "S3ExtendedClient not initialized"
        
        if self.s3_client is None:
            return False, None, "S3ExtendedClient not initialized"
        
        try:
            # Serialize to JSON
            payload_json = json.dumps(payload_dict)
            
            # Compress
            compressed = self._compress_payload(payload_json)
            
            # Generate S3 key
            s3_key = self._generate_s3_key(trace_id)
            
            # Calculate hash for integrity
            payload_hash = self._calculate_payload_hash(compressed)
            
            # Create metadata
            metadata = {
                'original-size': str(len(payload_json)),
                'compressed-size': str(len(compressed)),
                'compression-ratio': f"{(1 - len(compressed) / len(payload_json)) * 100:.1f}%",
                'hash': payload_hash,
                'timestamp': datetime.now(timezone.utc).isoformat(),
                'trace-id': trace_id
            }
            
            # Upload to S3
            self.s3_client.put_object(
                Bucket=self.bucket_name,
                Key=s3_key,
                Body=compressed,
                ContentType='application/gzip',
                Metadata=metadata
            )
            
            logger.info(
                f"S3 store: {s3_key} "
                f"(original: {len(payload_json)} bytes, "
                f"compressed: {len(compressed)} bytes)"
            )
            
            return True, s3_key, None
            
        except Exception as e:
            error_msg = f"S3 storage failed: {str(e)}"
            logger.error(error_msg)
            return False, None, error_msg
    
    def retrieve_from_s3(self, s3_key: str) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """
        Retrieve and decompress payload from S3.
        
        Args:
            s3_key: S3 object key
            
        Returns:
            Tuple of (success, payload_dict, error_message)
        """
        if not self.is_enabled():
            return False, None, "S3ExtendedClient not initialized"
        
        if self.s3_client is None:
            return False, None, "S3ExtendedClient not initialized"
        
        try:
            response = self.s3_client.get_object(
                Bucket=self.bucket_name,
                Key=s3_key
            )
            
            # Read compressed data
            compressed = response['Body'].read()
            
            # Decompress
            payload_json = self._decompress_payload(compressed)
            
            # Parse JSON
            payload_dict = json.loads(payload_json)
            
            logger.info(f"S3 retrieve: {s3_key} ({len(compressed)} bytes compressed)")
            
            return True, payload_dict, None
            
        except Exception as e:
            error_msg = f"S3 retrieval failed for {s3_key}: {str(e)}"
            logger.error(error_msg)
            return False, None, error_msg
    
    def create_sqs_reference(self, s3_key: str) -> Dict[str, Any]:
        """
        Create a lightweight SQS message that references S3 payload.
        
        Args:
            s3_key: S3 object key where payload is stored
            
        Returns:
            Dictionary suitable for SQS MessageBody
        """
        return {
            self.S3_REFERENCE_MARKER: True,
            "s3_bucket": self.bucket_name,
            "s3_key": s3_key,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
    
    def is_s3_reference(self, message_dict: Dict[str, Any]) -> bool:
        """Check if a message is an S3 reference pointer."""
        return isinstance(message_dict, dict) and self.S3_REFERENCE_MARKER in message_dict
    
    def extract_s3_key(self, message_dict: Dict[str, Any]) -> Optional[str]:
        """Extract S3 key from reference message."""
        if self.is_s3_reference(message_dict):
            return message_dict.get("s3_key")
        return None


# Singleton instance - initialized when needed
_s3_extended_client: Optional[S3ExtendedClient] = None


def get_s3_extended_client(bucket_name: Optional[str] = None, region: str = "us-east-1") -> Optional[S3ExtendedClient]:
    """
    Get or initialize S3 Extended Client singleton.
    
    Args:
        bucket_name: S3 bucket name (from env if not provided)
        region: AWS region (default: us-east-1)
        
    Returns:
        S3ExtendedClient instance or None if not configured
    """
    global _s3_extended_client
    
    if _s3_extended_client is None:
        if bucket_name is None:
            # Try programmatic config first, then env var
            try:
                from .config import get_config_value
                bucket_name = get_config_value("s3_bucket")
            except Exception:
                bucket_name = os.getenv("LLMOPS_S3_BUCKET")
        
        # If still no bucket name, try importing from config (with hardcoded defaults)
        if not bucket_name:
            try:
                from .config import S3_BUCKET, S3_REGION
                bucket_name = S3_BUCKET
                region = S3_REGION
            except Exception:
                pass
        
        if bucket_name:
            _s3_extended_client = S3ExtendedClient(
                bucket_name=bucket_name,
                region=region
            )
    
    return _s3_extended_client


def should_use_s3_storage(payload_size: int, threshold: Optional[int] = None) -> bool:
    """
    Determine if payload should be stored in S3.
    
    Args:
        payload_size: Size of payload in bytes
        threshold: Size threshold (uses default if not provided)
        
    Returns:
        True if payload exceeds threshold and S3 is available
    """
    if threshold is None:
        threshold = S3ExtendedClient.PAYLOAD_SIZE_THRESHOLD
    
    if payload_size > threshold:
        client = get_s3_extended_client()
        return client is not None and client.is_enabled()
    
    return False
