"""
Airline route coverage — maps each connector to the countries it serves.

Used by the provider to skip connectors that cannot possibly serve a route.
For example, SpiceJet (India domestic + regional) will never have flights
from Paris to Barcelona, so we skip it entirely for European routes.

The mapping uses 2-letter ISO country codes. An airport IATA code is resolved
to its country, and we check if the airline operates in that country.

Design:
- "countries" = set of ISO country codes where the airline operates
- If BOTH origin and destination country are outside the airline's countries,
  the connector is skipped (saves a browser launch / API call)
- If EITHER endpoint is in the airline's network, we run the connector
  (the airline might connect them)
- Airlines with very broad networks (e.g. Kiwi aggregator) are marked global

This data is intentionally conservative — we'd rather run an unnecessary
connector than miss a valid route. Over time, agents can tighten the coverage
based on actual results.
"""

from __future__ import annotations

# ── IATA airport code → ISO country code ──────────────────────────────────
# This is a curated subset covering airports in our connector test routes
# plus major hubs. For unknown airports, the filter falls back to "run it".
AIRPORT_COUNTRY: dict[str, str] = {
    # Europe
    "LHR": "GB", "LGW": "GB", "STN": "GB", "LTN": "GB", "MAN": "GB", "EDI": "GB",
    "BHX": "GB", "BRS": "GB", "EMA": "GB", "GLA": "GB", "LPL": "GB", "NCL": "GB",
    "BFS": "GB", "ABZ": "GB", "EXT": "GB", "SOU": "GB", "CWL": "GB", "PIK": "GB",
    "CDG": "FR", "ORY": "FR", "NCE": "FR", "LYS": "FR", "MRS": "FR", "TLS": "FR",
    "BOD": "FR", "NTE": "FR", "BIQ": "FR",
    "FRA": "DE", "MUC": "DE", "TXL": "DE", "SXF": "DE", "BER": "DE", "HAM": "DE",
    "CGN": "DE", "DUS": "DE", "STR": "DE", "NUE": "DE", "HAJ": "DE", "DTM": "DE",
    "LEJ": "DE",
    "FCO": "IT", "MXP": "IT", "BGY": "IT", "VCE": "IT", "NAP": "IT", "BLQ": "IT",
    "PSA": "IT", "CTA": "IT", "PMO": "IT", "BRI": "IT", "CAG": "IT", "TRN": "IT",
    "BCN": "ES", "MAD": "ES", "PMI": "ES", "AGP": "ES", "ALC": "ES", "VLC": "ES",
    "SVQ": "ES", "IBZ": "ES", "TFS": "ES", "ACE": "ES", "LPA": "ES", "FUE": "ES",
    "SCQ": "ES", "BIO": "ES", "GRO": "ES", "REU": "ES", "XRY": "ES",
    "AMS": "NL", "EIN": "NL", "RTM": "NL",
    "BRU": "BE", "CRL": "BE",
    "ZRH": "CH", "GVA": "CH", "BSL": "CH",
    "VIE": "AT", "SZG": "AT", "INN": "AT", "GRZ": "AT", "LNZ": "AT",
    "LIS": "PT", "OPO": "PT", "FAO": "PT", "FNC": "PT",
    "DUB": "IE", "SNN": "IE", "ORK": "IE", "KNO": "IE",
    "ATH": "GR", "SKG": "GR", "HER": "GR", "RHO": "GR", "CFU": "GR",
    "JMK": "GR", "JTR": "GR", "CHQ": "GR", "ZTH": "GR", "KGS": "GR",
    "WAW": "PL", "KRK": "PL", "GDN": "PL", "WRO": "PL", "KTW": "PL",
    "POZ": "PL", "RZE": "PL", "SZZ": "PL", "BZG": "PL", "LUZ": "PL",
    "PRG": "CZ", "BRQ": "CZ", "OSR": "CZ",
    "BUD": "HU", "DEB": "HU",
    "OTP": "RO", "CLJ": "RO", "TSR": "RO", "IAS": "RO", "SBZ": "RO",
    "SOF": "BG", "BOJ": "BG", "VAR": "BG",
    "BEG": "RS", "INI": "RS",
    "ZAG": "HR", "SPU": "HR", "DBV": "HR", "PUY": "HR", "ZAD": "HR",
    "LJU": "SI",
    "SKP": "MK",
    "TIA": "AL",
    "HEL": "FI", "TMP": "FI", "OUL": "FI", "TKU": "FI",
    "ARN": "SE", "GOT": "SE", "MMX": "SE",
    "OSL": "NO", "BGO": "NO", "TRD": "NO", "SVG": "NO", "TOS": "NO",
    "CPH": "DK", "BLL": "DK", "AAL": "DK",
    "KEF": "IS", "RKV": "IS",
    "RIX": "LV", "VNO": "LT", "TLL": "EE",
    "KIV": "MD",
    "IEV": "UA", "KBP": "UA", "LWO": "UA", "ODS": "UA",
    "MSQ": "BY",
    "IST": "TR", "SAW": "TR", "AYT": "TR", "ADB": "TR", "ESB": "TR",
    "DLM": "TR", "BJV": "TR", "GZT": "TR", "TZX": "TR",
    "TIV": "ME", "TGD": "ME",
    "SJJ": "BA",
    # Middle East
    "DXB": "AE", "AUH": "AE", "SHJ": "AE",
    "DOH": "QA",
    "BAH": "BH",
    "KWI": "KW",
    "MCT": "OM",
    "RUH": "SA", "JED": "SA", "DMM": "SA", "MED": "SA",
    "AMM": "JO",
    "BEY": "LB",
    "TLV": "IL",
    "CAI": "EG", "HRG": "EG", "SSH": "EG", "LXR": "EG",
    # South Asia
    "DEL": "IN", "BOM": "IN", "BLR": "IN", "MAA": "IN", "HYD": "IN",
    "CCU": "IN", "GOI": "IN", "COK": "IN", "PNQ": "IN", "AMD": "IN",
    "JAI": "IN", "GAU": "IN", "IXC": "IN", "SXR": "IN", "ATQ": "IN",
    "LKO": "IN", "PAT": "IN", "BBI": "IN", "IXR": "IN", "CCJ": "IN",
    "TRV": "IN", "IXE": "IN", "VTZ": "IN", "IXB": "IN", "IMF": "IN",
    "CMB": "LK", "MLE": "MV", "KTM": "NP",
    "DAC": "BD", "CGP": "BD", "ZYL": "BD", "RJH": "BD", "SPD": "BD", "BZL": "BD",
    "ISB": "PK", "LHE": "PK", "KHI": "PK",
    # Southeast Asia
    "SIN": "SG",
    "KUL": "MY", "PEN": "MY", "LGK": "MY", "BKI": "MY", "KCH": "MY",
    "BKK": "TH", "DMK": "TH", "CNX": "TH", "HKT": "TH", "USM": "TH",
    "HDY": "TH", "CEI": "TH",
    "SGN": "VN", "HAN": "VN", "DAD": "VN", "CXR": "VN", "PQC": "VN",
    "CGK": "ID", "DPS": "ID", "SUB": "ID", "JOG": "ID", "UPG": "ID",
    "MNL": "PH", "CEB": "PH", "DVO": "PH", "ILO": "PH", "CRK": "PH",
    "RGN": "MM", "MDL": "MM",
    "PNH": "KH", "REP": "KH",
    "VTE": "LA", "LPQ": "LA",
    # East Asia
    "NRT": "JP", "HND": "JP", "KIX": "JP", "FUK": "JP", "CTS": "JP",
    "NGO": "JP", "OKA": "JP", "ITM": "JP",
    "ICN": "KR", "GMP": "KR", "CJU": "KR", "PUS": "KR", "TAE": "KR",
    "PEK": "CN", "PVG": "CN", "CAN": "CN", "SZX": "CN", "CTU": "CN",
    "KMG": "CN", "NKG": "CN", "HGH": "CN", "WUH": "CN", "XIY": "CN",
    "TSN": "CN", "CGO": "CN", "TAO": "CN", "DLC": "CN",
    "HKG": "HK", "MFM": "MO",
    "TPE": "TW", "KHH": "TW",
    # Oceania
    "SYD": "AU", "MEL": "AU", "BNE": "AU", "PER": "AU", "ADL": "AU",
    "OOL": "AU", "CBR": "AU", "CNS": "AU", "HBA": "AU", "DRW": "AU",
    "AKL": "NZ", "WLG": "NZ", "CHC": "NZ", "ZQN": "NZ",
    # North America
    "JFK": "US", "LAX": "US", "ORD": "US", "ATL": "US", "DFW": "US",
    "DEN": "US", "SFO": "US", "SEA": "US", "MIA": "US", "BOS": "US",
    "EWR": "US", "IAD": "US", "PHX": "US", "IAH": "US", "MCO": "US",
    "MSP": "US", "DTW": "US", "FLL": "US", "CLT": "US", "LAS": "US",
    "SLC": "US", "SAN": "US", "TPA": "US", "PDX": "US", "STL": "US",
    "BNA": "US", "AUS": "US", "RDU": "US", "MKE": "US", "IND": "US",
    "PIT": "US", "CMH": "US", "SAT": "US", "OAK": "US", "SJC": "US",
    "SMF": "US", "RSW": "US", "PBI": "US", "BUR": "US", "OGG": "US",
    "HNL": "US", "ANC": "US", "ABQ": "US", "ELP": "US",
    "YYZ": "CA", "YVR": "CA", "YUL": "CA", "YOW": "CA", "YYC": "CA",
    "YEG": "CA", "YHZ": "CA", "YWG": "CA", "YTZ": "CA", "YQB": "CA",
    # Mexico & Central America
    "MEX": "MX", "CUN": "MX", "GDL": "MX", "MTY": "MX", "TIJ": "MX",
    "SJD": "MX", "PVR": "MX", "MID": "MX", "BJX": "MX",
    "PTY": "PA", "SJO": "CR", "SAL": "SV", "GUA": "GT", "TGU": "HN",
    "MGA": "NI", "BZE": "BZ",
    # Caribbean
    "SXM": "SX", "PUJ": "DO", "SDQ": "DO", "STI": "DO",
    "HAV": "CU", "VRA": "CU",
    "KIN": "JM", "MBJ": "JM",
    "NAS": "BS",
    "AUA": "AW", "CUR": "CW", "BON": "BQ",
    "SJU": "PR", "BGI": "BB", "POS": "TT",
    # South America
    "GRU": "BR", "GIG": "BR", "BSB": "BR", "CNF": "BR", "SSA": "BR",
    "REC": "BR", "CWB": "BR", "POA": "BR", "FOR": "BR", "BEL": "BR",
    "VCP": "BR", "SDU": "BR", "FLN": "BR", "NAT": "BR", "MCZ": "BR",
    "EZE": "AR", "AEP": "AR", "COR": "AR", "MDZ": "AR", "IGR": "AR",
    "BRC": "AR", "SLA": "AR", "TUC": "AR", "NQN": "AR", "USH": "AR",
    "BUE": "AR",  # Buenos Aires city code
    "SCL": "CL", "IQQ": "CL", "ANF": "CL", "CCP": "CL", "PMC": "CL",
    "ZCO": "CL", "PUQ": "CL",
    "LIM": "PE", "CUZ": "PE", "AQP": "PE",
    "BOG": "CO", "MDE": "CO", "CLO": "CO", "CTG": "CO", "BAQ": "CO",
    "UIO": "EC", "GYE": "EC",
    "CCS": "VE",
    "ASU": "PY", "MVD": "UY",
    "VVI": "BO", "LPB": "BO",
    # Africa
    "JNB": "ZA", "CPT": "ZA", "DUR": "ZA", "PLZ": "ZA",
    "LOS": "NG", "ABV": "NG", "PHC": "NG",
    "NBO": "KE", "MBA": "KE",
    "ADD": "ET",
    "ACC": "GH",
    "DSS": "SN",
    "CMN": "MA", "RAK": "MA", "FEZ": "MA", "AGA": "MA", "TNG": "MA",
    "ALG": "DZ", "ORN": "DZ",
    "TUN": "TN", "NBE": "TN", "DJE": "TN",
    # Additional Africa / Indian Ocean
    "DAR": "TZ", "ZNZ": "TZ", "JRO": "TZ",
    "EBB": "UG", "KGL": "RW", "JIB": "DJ", "KRT": "SD",
    "LUN": "ZM", "HRE": "ZW", "MPM": "MZ", "GBE": "BW", "WDH": "NA",
    "ABJ": "CI", "DKR": "SN", "DLA": "CM", "LBV": "GA", "BZV": "CG",
    "FIH": "CD", "LLW": "MW", "MRU": "MU", "SEZ": "SC", "TNR": "MG",
    "LAD": "AO", "MPM": "MZ",
    # Pacific
    "NAN": "FJ", "SUV": "FJ", "NOU": "NC", "PPT": "PF",
    "TBU": "TO", "APW": "WS", "RAR": "CK",
}

# City codes that map to multiple airports in a country
CITY_COUNTRY: dict[str, str] = {
    "LON": "GB", "PAR": "FR", "ROM": "IT", "MIL": "IT", "BUE": "AR",
    "NYC": "US", "WAS": "US", "CHI": "US", "TYO": "JP", "OSA": "JP",
    "SEL": "KR", "BJS": "CN", "SHA": "CN", "BKK": "TH", "KUL": "MY",
    "REK": "IS", "MOW": "RU", "STO": "SE",
}

# ── Multi-airport city groups ────────────────────────────────────────────
# Maps a city code (or any airport in the group) to all airports in that city.
# Used to expand searches: GDN→STN also searches GDN→LHR, GDN→LGW, etc.
CITY_AIRPORTS: dict[str, list[str]] = {
    # United Kingdom
    "LON": ["LHR", "LGW", "STN", "LTN", "SEN"],
    # France
    "PAR": ["CDG", "ORY", "BVA"],
    # Italy
    "ROM": ["FCO", "CIA"],
    "MIL": ["MXP", "LIN", "BGY"],
    # United States
    "NYC": ["JFK", "EWR", "LGA"],
    "WAS": ["IAD", "DCA", "BWI"],
    "CHI": ["ORD", "MDW"],
    "LAX": ["LAX", "SNA", "BUR", "LGB", "ONT"],
    "SFO": ["SFO", "OAK", "SJC"],
    "MIA": ["MIA", "FLL", "PBI"],
    "HOU": ["IAH", "HOU"],
    "DFW": ["DFW", "DAL"],
    # Japan
    "TYO": ["NRT", "HND"],
    "OSA": ["KIX", "ITM"],
    # South Korea
    "SEL": ["ICN", "GMP"],
    # China
    "BJS": ["PEK", "PKX"],
    "SHA": ["PVG", "SHA"],
    # Turkey
    "IST": ["IST", "SAW"],
    # Germany
    "BER": ["BER", "SXF"],
    # Sweden
    "STO": ["ARN", "BMA", "NYO"],
    # Russia
    "MOW": ["SVO", "DME", "VKO"],
    # Argentina
    "BUE": ["EZE", "AEP"],
    # Brazil
    "SAO": ["GRU", "CGH", "VCP"],
    "RIO": ["GIG", "SDU"],
    # UAE
    "DXB": ["DXB", "DWC"],
    # Thailand
    "BKK": ["BKK", "DMK"],
    # Malaysia
    "KUL": ["KUL", "SZB"],
    # Indonesia
    "JKT": ["CGK", "HLP"],
    # Iceland
    "REK": ["KEF", "RKV"],
    # Ireland
    "DUB": ["DUB"],
}

# Build reverse lookup: airport → city code
_AIRPORT_TO_CITY: dict[str, str] = {}
for _city, _airports in CITY_AIRPORTS.items():
    for _apt in _airports:
        _AIRPORT_TO_CITY[_apt] = _city


def get_city_airports(iata: str) -> list[str]:
    """Return all airports in the same city as *iata*.

    If *iata* is a city code (LON, NYC), returns its airports.
    If *iata* is an airport in a multi-airport city, returns all sibling airports.
    Otherwise returns [iata] (single-airport city).
    """
    iata = iata.upper().strip()
    if iata in CITY_AIRPORTS:
        return CITY_AIRPORTS[iata]
    city = _AIRPORT_TO_CITY.get(iata)
    if city:
        return CITY_AIRPORTS[city]
    return [iata]


def get_country(iata: str) -> str | None:
    """Resolve an IATA airport or city code to its ISO country code."""
    iata = iata.upper().strip()
    return AIRPORT_COUNTRY.get(iata) or CITY_COUNTRY.get(iata)


# ── Airline → operating countries ─────────────────────────────────────────
# Each airline maps to the set of countries where it operates flights.
# The key must match the source name prefix in _DIRECT_AIRLINE_connectorS
# (e.g. "easyjet_direct" → key "easyjet").
#
# If an airline is not listed here, it will always be queried (safe default).
# If EITHER the origin or destination country is in the set, we query it.

AIRLINE_COUNTRIES: dict[str, set[str]] = {
    # ── Europe ──
    "easyjet": {
        "GB", "FR", "DE", "IT", "ES", "NL", "CH", "AT", "PT", "IE",
        "GR", "DK", "SE", "NO", "FI", "PL", "CZ", "HU", "HR", "BG",
        "RO", "RS", "ME", "MK", "IL", "EG", "MA", "TN", "TR", "IS",
    },
    "ryanair": {
        "GB", "IE", "FR", "DE", "IT", "ES", "PT", "NL", "BE", "AT",
        "CH", "PL", "CZ", "HU", "RO", "BG", "HR", "GR", "CY", "MT",
        "DK", "SE", "NO", "FI", "LT", "LV", "EE", "SK", "SI",
        "MA", "IL", "JO", "TR",
    },
    "norwegian": {
        "NO", "SE", "DK", "FI", "GB", "IE", "FR", "ES", "IT", "GR",
        "PT", "HR", "CY", "US", "TH",
    },
    "vueling": {
        "ES", "FR", "IT", "GB", "NL", "BE", "DE", "AT", "CH", "PT",
        "IE", "GR", "HR", "MA", "DZ", "IL", "SE", "NO", "DK", "PL",
        "RO", "BG", "RS", "AL", "BA",
    },
    "eurowings": {
        "DE", "AT", "CH", "ES", "IT", "GR", "HR", "PT", "FR", "GB",
        "SE", "NO", "DK", "BG", "TR", "EG", "TN", "MA",
    },
    "transavia": {
        "NL", "FR", "ES", "IT", "PT", "GR", "HR", "MA", "TN", "EG",
        "TR", "IL", "AT", "DE",
    },
    "condor": {
        "DE", "AT", "CH", "ES", "PT", "GR", "IT", "HR", "TR", "EG",
        "TN", "MA", "US", "CA", "MX", "DO", "CU", "JM", "BB", "CR",
        "KE", "TZ", "MV", "TH",
    },
    "smartwings": {
        "CZ", "ES", "IT", "GR", "FR", "PT", "TR", "EG", "TN", "BG",
        "HR", "GB", "IL", "AE", "CV",
    },
    "volotea": {
        "ES", "IT", "FR", "GR", "HR", "DE", "AT",
    },
    "play": {
        "IS", "GB", "IE", "FR", "DE", "DK", "NO", "SE", "ES", "PT",
        "NL", "BE", "PL", "US", "CA",
    },
    "sunexpress": {
        "TR", "DE", "AT", "CH", "GB", "NL", "BE", "DK", "SE", "NO",
        "FI",
    },
    "pegasus": {
        "TR", "DE", "AT", "CH", "FR", "GB", "NL", "BE", "DK", "SE",
        "NO", "IT", "ES", "GR", "BG", "RO", "UA", "GE", "AZ", "KZ",
        "AE", "BH", "KW", "QA", "SA", "EG", "TN", "MA", "IL", "LB",
        "JO", "IQ",
    },
    "jet2": {
        "GB", "ES", "PT", "GR", "TR", "IT", "FR", "HR", "CY", "MT",
        "BG", "HU", "CZ", "AT", "CH",
    },
    "wizz": {
        "PL", "HU", "RO", "BG", "GB", "IT", "DE", "AT", "FR", "NL",
        "BE", "ES", "PT", "GR", "HR", "RS", "MK", "AL", "BA", "ME",
        "MD", "UA", "GE", "AE", "SA", "BH", "KW", "QA", "OM", "JO",
        "AM", "NO", "SE", "DK", "FI", "IS", "CY", "MT", "IL", "EG",
        "MA",
    },

    # ── Americas ──
    "southwest": {"US", "MX", "PR", "JM", "BS", "DO", "CU", "AW", "CR", "BZ", "TT"},
    "spirit": {"US", "PR", "CO", "MX", "JM", "DO", "GT", "SV", "HN", "CR", "PA", "PE", "EC"},
    "frontier": {"US", "MX", "DO", "JM", "PR", "GT", "CR"},
    "allegiant": {"US", "MX", "PR", "DO"},
    "jetblue": {"US", "PR", "DO", "JM", "BS", "MX", "CR", "CO", "EC", "PE", "GB", "FR", "NL"},
    "avelo": {"US"},
    "breeze": {"US"},
    "alaska": {"US", "MX", "CA", "CR", "BZ", "GT"},
    "hawaiian": {"US", "JP", "KR", "AU", "NZ", "AS", "WS"},
    "american": {
        "US", "CA", "MX", "GB", "IE", "FR", "DE", "ES", "IT", "NL",
        "CH", "GR", "CZ", "PT", "IS", "DK", "SE", "NO", "FI", "PL",
        "HU", "HR", "JP", "KR", "CN", "HK", "IN", "AU", "NZ",
        "BR", "AR", "CL", "CO", "PE", "EC",
        "DO", "JM", "BS", "PR", "CU", "HT", "TT", "BB", "AW", "CW",
        "CR", "PA", "GT", "SV", "HN", "NI", "BZ", "GY",
        "IL", "JO", "AE", "QA", "BH",
    },
    "united": {
        "US", "CA", "MX", "GB", "IE", "FR", "DE", "ES", "IT", "NL",
        "BE", "CH", "AT", "GR", "CZ", "PT", "IS", "DK", "SE", "NO",
        "PL", "HU", "HR", "JP", "KR", "CN", "HK", "TW", "SG", "TH",
        "IN", "AU", "NZ", "PH",
        "BR", "AR", "CL", "CO", "PE", "EC",
        "DO", "JM", "BS", "PR", "CU", "HT", "TT", "AW", "CW",
        "CR", "PA", "GT", "SV", "HN", "NI", "BZ",
        "IL", "JO", "AE", "QA",
        "GU", "MH", "PW", "FM", "MP",
    },
    "delta": {
        "US", "CA", "MX", "GB", "IE", "FR", "DE", "ES", "IT", "NL",
        "BE", "CH", "AT", "GR", "CZ", "PT", "IS", "DK", "SE", "NO",
        "FI", "PL", "HU", "HR", "JP", "KR", "CN", "HK", "TW", "SG",
        "IN", "AU", "NZ", "GH", "ZA", "SN",
        "BR", "AR", "CL", "CO", "PE", "EC",
        "DO", "JM", "BS", "PR", "CU", "HT", "TT", "BB", "AW", "CW",
        "CR", "PA", "GT", "SV", "HN", "NI", "BZ",
        "IL", "AE", "QA",
        "GU", "AS",
    },
    "volaris": {"US", "MX", "GT", "SV", "HN", "CR", "NI"},
    "vivaaerobus": {"US", "MX", "CO", "CU", "DO", "PE"},
    "jetsmart": {"CL", "AR", "PE", "CO", "BR"},
    "flybondi": {"AR", "BR", "CL", "PY", "UY", "CO", "PE"},
    "flair": {"CA", "US", "MX"},
    "porter": {"CA", "US", "MX", "JM", "BS", "DO", "CU", "CR", "BB", "TT"},
    "gol": {"BR", "AR", "CL", "UY", "PY", "CO", "PE", "EC", "VE", "DO", "MX", "US"},
    "azul": {"BR", "AR", "CL", "UY", "PY", "US", "PT", "FR"},

    # ── Asia-Pacific ──
    "airasia": {
        "MY", "TH", "ID", "PH", "SG", "VN", "KH", "MM", "LA", "IN",
        "LK", "BD", "NP", "CN", "JP", "KR", "TW", "HK", "AU", "NZ",
        "SA", "AE", "TR", "EG", "KE",
    },
    "vietjet": {"VN", "TH", "KR", "JP", "TW", "IN", "SG", "MY", "ID", "PH", "KH", "AU"},
    "cebupacific": {"PH", "SG", "MY", "TH", "VN", "KR", "JP", "TW", "CN", "HK", "AU", "AE"},
    "scoot": {"SG", "TH", "MY", "ID", "VN", "PH", "KR", "JP", "TW", "CN", "HK", "IN", "AU", "GR", "DE", "GB", "FI", "SA"},
    "nokair": {"TH", "CN", "JP", "KR", "VN", "MM", "IN", "SG"},
    "jetstar": {"AU", "NZ", "JP", "SG", "VN", "ID", "TH", "MY", "PH"},
    "peach": {"JP", "KR", "TW", "CN", "HK", "TH"},
    "zipair": {"JP", "KR", "TH", "SG", "US", "CA"},
    "spring": {"CN", "JP", "KR", "TH", "KH", "MY"},
    "luckyair": {"CN", "TH", "MM", "LA", "KH", "VN", "BD"},
    "9air": {"CN"},
    "jejuair": {"KR", "JP", "TW", "PH", "VN", "TH", "SG", "MY", "GU"},
    "twayair": {"KR", "JP", "TW", "VN", "TH", "PH", "SG", "GU"},
    "batikair": {"ID", "MY", "SG", "TH", "AU"},
    "thai": {
        "TH", "JP", "KR", "CN", "HK", "TW", "SG", "MY", "ID", "VN",
        "KH", "LA", "MM", "PH", "IN", "LK", "BD", "NP", "PK", "AU",
        "GB", "DE", "FR", "IT", "CH", "AT", "DK", "SE", "NO", "BE",
        "TR",
    },
    "korean": {
        "KR", "JP", "CN", "HK", "TW", "SG", "TH", "VN", "KH", "PH",
        "MY", "ID", "IN", "LK", "BD", "NP", "MN", "UZ", "KZ", "AU",
        "US", "CA", "GB", "FR", "DE", "IT", "NL", "CH", "AT", "CZ",
        "HU", "PL", "HR", "SE", "DK", "FI", "ES", "TR", "IL", "AE",
        "RU", "NZ",
    },

    # ── Middle East / Africa / India ──
    "flydubai": {
        "AE", "SA", "BH", "KW", "QA", "OM", "IN", "PK", "LK", "BD",
        "NP", "EG", "JO", "LB", "IQ", "IR", "GE", "AM", "AZ", "KZ",
        "UZ", "TJ", "KG", "RS", "BG", "RO", "HR", "GR", "IT", "CZ",
        "PL", "AT", "TR", "TH", "LK", "ET", "KE", "TZ",
    },
    "airarabia": {
        "AE", "AF", "AM", "AT", "AZ", "BA", "BD", "BE", "BH", "CH",
        "CN", "CZ", "DE", "DZ", "EG", "ES", "ET", "FR", "GB", "GE",
        "GR", "HR", "IN", "IQ", "IR", "IT", "JO", "KE", "KG", "KH",
        "KW", "KZ", "LB", "LK", "MA", "MV", "MY", "NL", "NP", "OM",
        "PK", "PL", "QA", "RU", "SA", "SD", "SO", "SY", "TH", "TN",
        "TR", "UG", "UZ",
    },
    "flynas": {
        "SA", "AE", "BH", "KW", "QA", "OM", "EG", "JO", "LB", "IQ",
        "TR", "IN", "PK", "BD", "LK", "GE", "AZ", "MA", "TN", "ET",
        "SD", "BA", "RS", "ME", "AL",
    },
    "spicejet": {
        "IN", "AE", "SA", "OM", "TH", "HK", "BD", "BH", "KW", "LK",
        "MM", "MV", "NP", "QA",
    },
    "indigo": {
        "IN", "AE", "SA", "QA", "KW", "OM", "BH", "SG", "TH", "MY",
        "VN", "HK", "ID", "LK", "MV", "NP", "BD", "MM", "GE", "UZ",
        "KE", "TZ", "TR", "GB",
    },
    "akasa": {"IN", "SA", "QA", "KW", "BH"},
    "salamair": {
        "OM", "AE", "SA", "BH", "KW", "QA", "IN", "BD", "PK", "LK",
        "NP", "EG", "IR", "IQ", "SD", "KE", "TZ", "ET", "TH", "MY",
        "GE", "TR", "GB", "AT", "CZ", "BA", "RS",
    },
    "airindiaexpress": {"IN", "AE", "SA", "QA", "KW", "OM", "BH", "MY", "SG", "TH"},
    "usbangla": {
        "BD", "AE", "OM", "QA", "SA", "IN", "MY", "SG", "TH", "CN",
        "MV", "NP", "DE", "GB", "US",
    },
    "flysafair": {"ZA"},
    "airpeace": {"NG", "GH", "ZA", "KE", "AE", "GB"},
    "biman": {
        "BD", "AE", "SA", "QA", "KW", "OM", "IN", "NP", "TH", "MY",
        "SG", "HK", "CN", "IT", "GB", "CA", "PK",
    },
    "etihad": {
        "AE", "SA", "QA", "KW", "BH", "OM", "EG", "JO", "LB", "IQ",
        "PK", "IN", "LK", "BD", "NP", "TH", "MY", "SG", "ID", "PH",
        "CN", "JP", "KR", "AU", "GB", "IE", "FR", "DE", "IT", "ES",
        "CH", "NL", "GR", "TR", "US", "CA", "KE", "TZ", "ZA", "NG",
        "ET", "BR", "MV", "SC", "KZ", "RU",
    },
    "turkish": {
        "TR", "DE", "GB", "FR", "IT", "ES", "NL", "BE", "CH", "AT",
        "SE", "NO", "DK", "FI", "PL", "CZ", "HU", "RO", "BG", "HR",
        "RS", "BA", "ME", "MK", "AL", "GR", "CY", "PT", "IE", "IS",
        "LV", "LT", "EE", "SK", "SI", "MT", "LU", "UA", "MD", "GE",
        "AM", "AZ", "RU", "KZ", "UZ", "TM", "KG", "TJ",
        "US", "CA", "BR", "AR", "CO", "MX", "PA", "CU", "DO",
        "AE", "SA", "QA", "KW", "BH", "OM", "JO", "LB", "IQ", "IR",
        "IL", "EG", "LY", "TN", "DZ", "MA",
        "IN", "PK", "BD", "LK", "MV", "NP",
        "TH", "MY", "SG", "ID", "VN", "PH", "KH", "MM",
        "CN", "HK", "JP", "KR", "TW",
        "AU", "NZ",
        "ZA", "KE", "ET", "NG", "GH", "SN", "CI", "TZ", "MZ", "MU",
        "CM", "GA", "CG", "CD", "SD", "DJ", "SO", "MG", "RW", "UG",
    },
    "nh": {
        "JP", "US", "CA", "MX",
        "GB", "FR", "DE", "IT", "BE", "AT", "SE",
        "CN", "HK", "TW", "KR",
        "TH", "MY", "SG", "ID", "VN", "PH", "KH", "MM", "IN",
        "AU",
    },
    "emirates": {
        "AE", "SA", "QA", "KW", "BH", "OM", "EG", "JO", "LB", "IQ", "IR",
        "PK", "IN", "LK", "BD", "NP", "MV",
        "TH", "MY", "SG", "ID", "PH", "VN", "KH", "MM",
        "CN", "HK", "JP", "KR", "TW", "AU", "NZ",
        "GB", "IE", "FR", "DE", "IT", "ES", "PT", "CH", "NL", "BE",
        "AT", "SE", "NO", "DK", "FI", "PL", "CZ", "HU", "RO", "BG",
        "GR", "CY", "TR", "RU",
        "US", "CA", "MX", "BR", "AR", "CL", "CO",
        "KE", "TZ", "ZA", "NG", "ET", "GH", "UG", "MU", "SC",
        "KZ", "UZ", "AZ",
    },
    "malaysia": {
        "MY", "SG", "TH", "ID", "VN", "KH", "MM", "PH", "BN", "LA",
        "IN", "LK", "BD", "NP", "MV",
        "CN", "HK", "TW", "JP", "KR",
        "AU", "NZ",
        "AE", "SA", "QA", "BH", "OM",
        "GB", "NL", "FR", "DE", "TR",
        "US",
        "KE", "ZA",
    },
    "cathay": {
        "HK", "CN", "TW", "JP", "KR",
        "SG", "TH", "MY", "ID", "PH", "VN", "KH", "MM", "IN", "LK", "MV", "NP", "BD",
        "AU", "NZ",
        "GB", "FR", "DE", "IT", "ES", "NL", "BE",
        "US", "CA",
        "AE", "QA", "SA",
        "ZA", "KE", "SN",
    },
    "singapore": {
        "SG", "MY", "TH", "ID", "VN", "PH", "KH", "MM", "BN", "LA",
        "IN", "LK", "BD", "NP", "MV",
        "CN", "HK", "TW", "JP", "KR",
        "AU", "NZ",
        "AE", "SA", "BH", "IL",
        "GB", "FR", "DE", "IT", "ES", "NL", "CH", "DK", "SE", "TR",
        "US",
        "ZA", "KE",
    },
    "suncountry": {"US", "MX", "JM", "BZ", "CR", "DO"},
    "qatar": {
        "QA", "AE", "SA", "KW", "BH", "OM", "EG", "JO", "LB", "IQ", "IR",
        "PK", "IN", "LK", "BD", "NP", "MV",
        "TH", "MY", "SG", "ID", "PH", "VN", "KH", "MM",
        "CN", "HK", "JP", "KR", "TW", "AU", "NZ",
        "GB", "IE", "FR", "DE", "IT", "ES", "PT", "CH", "NL", "BE",
        "AT", "SE", "NO", "DK", "FI", "PL", "CZ", "HU", "RO", "BG",
        "GR", "CY", "TR", "RU",
        "US", "CA", "BR", "AR", "CL", "MX",
        "KE", "TZ", "ZA", "NG", "ET", "GH", "UG", "MU", "SC",
        "KZ", "UZ", "AZ", "GE",
    },
    "westjet": {
        "CA", "US", "MX", "GB", "IE", "FR", "DE", "IT", "ES",
        "JM", "CU", "DO", "BB", "TC", "BS", "HT", "LC", "GD",
        "CR", "BZ", "HN", "PA",
        "JP",
    },
    "latam": {
        "CL", "BR", "AR", "PE", "CO", "EC", "UY", "PY", "BO",
        "US", "MX", "DO", "CU",
        "GB", "FR", "DE", "IT", "ES", "NL",
        "AU", "NZ",
    },
    "copa": {
        "PA", "US", "CO", "BR", "AR", "CL", "PE", "EC", "MX",
        "CR", "GT", "SV", "HN", "NI", "BZ",
        "DO", "JM", "CU", "CW", "AW", "TT", "BB",
        "VE", "GY", "SR", "PY", "UY", "BO",
    },
    "avianca": {
        "CO", "SV", "GT", "CR", "EC", "PE", "HN", "NI",
        "US", "MX", "BR", "AR", "CL", "DO", "CU",
        "ES", "GB", "DE", "IT", "FR",
    },
    "lot": {
        "PL", "GB", "DE", "FR", "IT", "ES", "NL", "BE", "CH", "AT",
        "SE", "NO", "DK", "FI", "CZ", "HU", "RO", "BG", "HR", "RS",
        "UA", "GR", "CY", "PT", "IE", "IS", "LT", "LV", "EE",
        "US", "CA",
        "TR", "IL", "EG", "AE", "SA", "KZ", "UZ", "GE",
        "CN", "JP", "KR", "IN", "LK", "TH", "SG",
    },

    # ── New airline connectors ──
    "aegean": {
        "GR", "GB", "DE", "FR", "IT", "ES", "NL", "BE", "CH", "AT",
        "CZ", "PL", "RO", "BG", "CY", "IL", "EG", "TR", "GE", "AE",
        "SA", "SE", "DK", "IE", "PT",
    },
    "icelandair": {
        "IS", "US", "CA", "GB", "DE", "FR", "NL", "DK", "SE", "NO",
        "FI", "ES", "IT", "CH", "BE", "IE", "PT", "PL", "CZ", "GL",
    },
    "aircanada": {
        "CA", "US", "MX", "GB", "IE", "FR", "DE", "IT", "ES", "PT",
        "NL", "BE", "CH", "AT", "DK", "SE", "NO", "PL", "CZ", "HU",
        "HR", "GR", "IS", "JP", "KR", "CN", "HK", "TW", "IN",
        "AU", "NZ", "BR", "AR", "CL", "CO", "PE",
        "DO", "JM", "CU", "BB", "TT", "BS", "CR", "PA", "GT", "BZ",
        "AE", "IL",
    },
    "finnair": {
        "FI", "SE", "NO", "DK", "EE", "LV", "LT", "GB", "IE", "FR",
        "DE", "IT", "ES", "PT", "NL", "BE", "CH", "AT", "PL", "CZ",
        "HU", "RO", "BG", "HR", "GR", "CY", "TR",
        "JP", "KR", "CN", "HK", "TH", "SG", "IN",
        "US",
    },
    "tap": {
        "PT", "ES", "FR", "DE", "IT", "GB", "IE", "NL", "BE", "CH",
        "AT", "LU", "DK", "SE", "NO", "FI", "PL", "CZ", "HU", "RO",
        "GR", "HR", "BG", "TR", "MA", "TN", "CV",
        "BR", "US", "CA", "MX", "VE", "CO",
        "AO", "MZ", "GW", "SN", "GH",
    },
    "sas": {
        "SE", "NO", "DK", "FI", "IS", "GB", "IE", "FR", "DE", "IT",
        "ES", "PT", "NL", "BE", "CH", "AT", "PL", "CZ", "GR", "HR",
        "TR", "EE", "LV", "LT",
        "US", "TH",
    },
    "wingo": {
        "CO", "PA", "VE", "EC", "PE", "MX", "CU", "DO", "JM", "CW",
        "AW", "GT", "CR",
    },
    "skyairline": {
        "CL", "PE", "BR", "AR", "UY",
    },
    "arajet": {
        "DO", "CO", "MX", "GT", "SV", "HN", "CR", "PA", "CU", "JM",
        "PE", "EC", "CL", "BR", "CA", "US",
    },
    "ethiopian": {
        "ET", "KE", "TZ", "UG", "RW", "DJ", "SD", "SS", "SO", "ER",
        "CD", "CG", "CM", "GA", "CI", "GH", "NG", "SN", "ML", "BF",
        "NE", "TD", "MG", "MU", "SC", "MW", "ZM", "ZW", "MZ", "BW",
        "ZA",
        "AE", "SA", "QA", "BH", "KW", "OM", "IL", "EG", "LB", "JO",
        "IN", "CN", "JP", "KR", "TH", "SG", "HK",
        "GB", "FR", "DE", "IT", "ES", "BE", "AT", "SE", "IE",
        "US", "CA", "BR", "AR",
    },
    "kenyaairways": {
        "KE", "TZ", "UG", "RW", "ET", "CD", "CG", "CM", "NG", "GH",
        "CI", "SN", "ZA", "MU", "SC", "MG", "MW", "ZM", "ZW",
        "AE", "SA", "OM", "BH", "EG",
        "IN", "CN", "TH", "HK",
        "GB", "FR", "NL", "DE", "IT",
        "US",
    },
    "royalairmaroc": {
        "MA", "FR", "ES", "IT", "DE", "GB", "NL", "BE", "PT", "CH",
        "TR", "EG", "TN", "DZ", "SN", "CI", "ML", "GH", "NG", "CM",
        "GA", "CG", "CD", "MR", "GN", "BF", "NE",
        "AE", "SA", "QA", "JO",
        "US", "CA", "BR",
    },
    "philippineairlines": {
        "PH", "JP", "KR", "CN", "HK", "TW", "SG", "MY", "TH", "VN",
        "ID", "IN", "AU",
        "AE", "SA", "QA", "BH", "KW", "OM",
        "US", "CA",
        "GB",
    },
    "airindia": {
        "IN", "AE", "SA", "QA", "KW", "BH", "OM",
        "GB", "FR", "DE", "IT", "ES", "AT", "CH", "DK", "SE", "NL",
        "US", "CA", "AU",
        "JP", "KR", "HK", "SG", "TH", "MY",
        "KE", "ET",
        "LK", "NP", "BD", "MV",
    },
    "qantas": {
        "AU", "NZ", "SG", "MY", "ID", "TH", "VN", "PH", "HK", "JP",
        "CN", "IN", "LK",
        "GB", "FR", "DE", "IT",
        "US", "CA", "CL", "AR",
        "ZA", "AE", "FJ", "PG", "NC", "NR",
    },
    "egyptair": {
        "EG", "SA", "AE", "QA", "KW", "BH", "OM", "JO", "LB", "IQ",
        "GB", "FR", "DE", "IT", "ES", "NL", "GR", "CH", "AT", "BE",
        "US", "CA",
        "IN", "CN", "JP", "TH", "KR",
        "KE", "ET", "TZ", "NG", "GH", "ZA", "SD", "TN", "DZ", "MA",
    },
    "virginaustralia": {
        "AU", "NZ", "FJ", "ID", "JP",
    },
    "airnewzealand": {
        "NZ", "AU", "FJ", "NC", "TO", "CK", "WS",
        "SG", "HK", "JP", "CN",
        "US", "CA",
        "GB",
    },
    "jal": {
        "JP", "US", "CA", "MX",
        "GB", "FR", "DE", "FI", "SE",
        "CN", "HK", "TW", "KR",
        "TH", "SG", "MY", "VN", "ID", "PH", "IN",
        "AU",
        "AE", "QA",
    },
    "garuda": {
        "ID", "SG", "MY", "TH", "PH", "VN", "AU", "JP", "KR", "CN",
        "HK", "IN", "NL", "GB", "AE", "SA",
    },
    "bangkokairways": {
        "TH", "KH", "LA", "MM", "VN", "SG", "MY", "IN", "MV", "CN",
        "HK",
    },
    "saa": {
        "ZA", "MU", "MW", "ZM", "ZW", "BW", "MZ", "NA", "SZ", "LS",
        "KE", "TZ", "UG", "ET", "GH", "NG", "SN", "CI", "CD",
        "GB", "DE", "FR",
        "US",
        "AU", "HK", "IN",
        "AE",
    },
    "aerlingus": {
        "IE", "GB", "FR", "ES", "IT", "DE", "NL", "BE", "PT", "AT",
        "CH", "PL", "CZ", "HR", "GR", "CY",
        "US", "CA",
    },
    "itaairways": {
        "IT", "FR", "DE", "GB", "ES", "NL", "BE", "CH", "AT", "GR",
        "PL", "CZ", "HU", "RO", "BG", "HR", "AL", "PT", "IE",
        "US", "BR", "AR",
        "JP", "IN",
        "AE", "IL", "EG", "TN", "DZ", "LY",
    },

    # ── OTA / aggregator connectors (global or broad regional) ──
    # OTAs are NOT filtered by route — they search across all airlines.
    # We intentionally omit them from AIRLINE_COUNTRIES so they always run.
}

# ── Airlines that operate DOMESTIC flights within a country ───────────────
# Used when origin_country == dest_country to avoid firing international
# carriers that merely fly TO/FROM that country (e.g. Emirates for US→US).
# If a country is not listed here, domestic filtering falls back to the
# general AIRLINE_COUNTRIES logic (all airlines serving that country).
DOMESTIC_AIRLINES: dict[str, set[str]] = {
    # Americas
    "US": {
        "southwest", "spirit", "frontier", "allegiant", "jetblue",
        "avelo", "breeze", "alaska", "hawaiian", "american", "united",
        "delta", "suncountry",
    },
    "CA": {"flair", "porter", "westjet", "aircanada"},
    "BR": {"gol", "azul", "latam"},
    "MX": {"volaris", "vivaaerobus"},
    "CO": {"avianca", "wingo", "latam"},
    "CL": {"jetsmart", "skyairline", "latam"},
    "AR": {"flybondi", "jetsmart"},
    # Europe
    "GB": {"easyjet", "jet2", "ryanair"},
    "ES": {"vueling", "volotea", "ryanair"},
    "IT": {"itaairways", "volotea", "ryanair"},
    "DE": {"eurowings", "ryanair"},
    "FR": {"transavia", "easyjet", "ryanair"},
    "NO": {"norwegian", "sas"},
    "SE": {"sas"},
    "DK": {"sas"},
    "GR": {"aegean"},
    "PL": {"lot", "ryanair"},
    "PT": {"tap", "ryanair"},
    "TR": {"pegasus", "turkish", "sunexpress"},
    "IE": {"aerlingus", "ryanair"},
    # Asia-Pacific
    "IN": {"indigo", "spicejet", "akasa", "airindiaexpress", "airindia"},
    "JP": {"peach", "jal", "nh"},
    "KR": {"jejuair", "twayair", "korean"},
    "TH": {"nokair", "airasia", "thai", "bangkokairways"},
    "MY": {"airasia", "malaysia", "batikair"},
    "ID": {"airasia", "batikair", "garuda"},
    "PH": {"cebupacific", "philippineairlines"},
    "CN": {"spring", "9air", "luckyair"},
    "AU": {"jetstar", "qantas", "virginaustralia"},
    "NZ": {"airnewzealand"},
    "VN": {"vietjet"},
    # Middle East / Africa
    "SA": {"flynas"},
    "AE": {"flydubai", "airarabia"},
    "EG": {"egyptair"},
    "ZA": {"flysafair", "saa"},
    "NG": {"airpeace"},
    "KE": {"kenyaairways"},
    "ET": {"ethiopian"},
    "BD": {"usbangla", "biman"},
}

# ── Regional route filtering ─────────────────────────────────────────────
# Airlines whose hub model means they ONLY connect their home region to
# other regions (intercontinental), NOT intra-regional short-haul.
# Example: Delta flies US↔Europe but NOT London→Ibiza (intra-Europe).
# These are skipped when BOTH origin and destination are in the SAME region.
_REGIONS: dict[str, set[str]] = {
    "europe": {
        "GB", "IE", "FR", "DE", "ES", "IT", "PT", "NL", "BE", "LU",
        "CH", "AT", "GR", "CZ", "SK", "PL", "HU", "HR", "SI", "RO",
        "BG", "RS", "BA", "ME", "MK", "AL", "XK", "DK", "SE", "NO",
        "FI", "IS", "EE", "LV", "LT", "CY", "MT",
    },
    "north_america": {"US", "CA", "MX"},
    "south_america": {
        "BR", "AR", "CL", "CO", "PE", "EC", "VE", "BO", "PY", "UY",
        "GY", "SR",
    },
    "east_asia": {"JP", "KR", "CN", "HK", "TW", "MO"},
    "southeast_asia": {
        "TH", "MY", "SG", "ID", "PH", "VN", "MM", "KH", "LA", "BN",
    },
    "south_asia": {"IN", "LK", "BD", "PK", "NP", "MV"},
    "middle_east": {"AE", "QA", "BH", "KW", "OM", "SA", "JO", "IL", "LB"},
    "oceania": {"AU", "NZ", "FJ", "PG"},
    "africa": {
        "ZA", "EG", "KE", "ET", "NG", "GH", "SN", "TZ", "MA", "TN",
        "DZ",
    },
}

def _get_region(country_code: str) -> str | None:
    """Return the region name for a country, or None if unknown."""
    for region, countries in _REGIONS.items():
        if country_code in countries:
            return region
    return None

# Airlines that ONLY fly intercontinental from their home hub.
# When both endpoints are in the same region these are skipped.
INTERCONTINENTAL_ONLY: set[str] = {
    # US Big 3 — fly US↔everywhere, not intra-Europe/Asia
    "american", "united", "delta",
    # Canadian
    "westjet", "aircanada",
    # South American long-haul
    "latam", "avianca",
    # Asian carriers — connect Asia↔world, not intra-Europe
    "singapore", "cathay", "korean", "thai", "malaysia",
    "garuda", "philippineairlines", "airnewzealand",
    # Middle Eastern hub carriers — connect ME↔world
    "emirates", "etihad", "qatar",
    # African long-haul
    "ethiopian", "kenyaairways", "saa", "royalairmaroc",
}


def get_relevant_connectors(
    origin: str,
    destination: str,
    connectors: list[tuple[str, type, float]],
) -> list[tuple[str, type, float]]:
    """Filter connectors to only those that could serve the given route.

    A connector is included when the airline serves BOTH the origin and
    destination countries (all our connectors search direct flights only,
    they don't build connections).  If the country lookup fails for either
    airport, all connectors are returned (safe fallback).

    Args:
        origin: IATA airport/city code (e.g. "CDG", "LON")
        destination: IATA airport/city code
        connectors: list of (source_name, connector_class, timeout) tuples

    Returns:
        Filtered list of connector tuples
    """
    origin_country = get_country(origin)
    dest_country = get_country(destination)

    # If we can't resolve either airport, run all connectors (safe fallback)
    if not origin_country or not dest_country:
        return connectors

    is_domestic = origin_country == dest_country
    domestic_set = DOMESTIC_AIRLINES.get(origin_country) if is_domestic else None

    # Regional filtering: skip intercontinental-only carriers for intra-region routes
    origin_region = _get_region(origin_country)
    dest_region = _get_region(dest_country)
    same_region = (origin_region is not None and origin_region == dest_region)

    relevant = []
    for source, cls, timeout in connectors:
        # Extract airline key from source name (e.g. "easyjet_direct" → "easyjet")
        airline_key = source.replace("_direct", "").replace("_connector", "")

        # Special: Wizzair is registered as "wizzair" but keyed as "wizz"
        if airline_key == "wizzair":
            airline_key = "wizz"

        countries = AIRLINE_COUNTRIES.get(airline_key)

        if countries is None:
            # Unknown airline / OTA — always include (safe default)
            relevant.append((source, cls, timeout))
        elif is_domestic and domestic_set is not None:
            # Domestic route with known domestic carriers — only fire those
            if airline_key in domestic_set:
                relevant.append((source, cls, timeout))
        elif same_region and airline_key in INTERCONTINENTAL_ONLY:
            # Intra-regional route — skip long-haul carriers (e.g. Delta for LON→IBZ)
            continue
        elif origin_country in countries and dest_country in countries:
            relevant.append((source, cls, timeout))
        # else: skip — airline doesn't serve both endpoints

    return relevant
