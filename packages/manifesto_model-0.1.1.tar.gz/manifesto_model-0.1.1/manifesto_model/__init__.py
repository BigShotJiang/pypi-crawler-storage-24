from __future__ import annotations

from pathlib import Path

from .inference_service import ManifestoInferenceService, load_default_service


PACKAGE_ROOT = Path(__file__).resolve().parent


def create_service(base_dir: str | Path | None = None) -> ManifestoInferenceService:
    return ManifestoInferenceService(base_dir or PACKAGE_ROOT)


def predict(
    text: str,
    country: str,
    year: int,
    *,
    top_k: int = 5,
    base_dir: str | Path | None = None,
):
    service = create_service(base_dir)
    return service.predict(text=text, country=country, year=year, top_k=top_k)


__all__ = [
    "ManifestoInferenceService",
    "PACKAGE_ROOT",
    "create_service",
    "load_default_service",
    "predict",
]
