# manifesto-model

`manifesto-model` is a Python package for multilingual manifesto policy analysis.

It provides:

- A Python inference API
- A Flask app factory for serving the model as an HTTP API
- Built-in macroeconomic lookup data from the `add/` directory

## Installation

```bash
pip install manifesto-model
```

If you are installing from the source repository:

```bash
pip install .
```

## Python usage

```python
from manifesto_model import create_service, predict

service = create_service()

result = service.predict(
    text="The government will expand industrial policy and labour training.",
    country="Japan",
    year=2026,
    top_k=5,
)

# Or use the convenience function:
result = predict(
    text="The government will expand industrial policy and labour training.",
    country="Japan",
    year=2026,
)
```

## Flask usage

```python
from manifesto_model.web import create_app

app = create_app()
```

## Command-line API server

After installation, you can start the packaged Flask server with:

```bash
manifesto-model-api
```

Environment variables:

- `PORT`
- `MODEL_PATH`
- `MODEL_REPO_ID`
- `MODEL_FILENAME`
- `HF_TOKEN`
- `TEXT_MODEL_NAME_OR_PATH`
- `TORCH_NUM_THREADS`
- `CORS_ALLOW_ORIGINS`

## Notes

- The packaged macro data currently supports years through `2026`.
- For `2024-2026`, macro variables use the expanded dataset columns, while the model year embedding falls back to the latest trained year (`2023`).
- Model weights are not bundled in the package. Use `MODEL_PATH` or Hugging Face Hub environment variables to provide them at runtime.
