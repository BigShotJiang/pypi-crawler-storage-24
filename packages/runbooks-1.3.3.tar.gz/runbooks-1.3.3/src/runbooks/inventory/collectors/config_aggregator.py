"""
Config Aggregator Collector - Org-wide resource discovery via AWS Config.

COS1-02: HITL runs `runbooks inventory collect --config-aggregator` and discovers
resources across all org accounts in <10s (vs 60s×67 accounts per-account loop).

Uses the organization-aggregator Config Aggregator to query AWS::EC2::Instance,
AWS::EC2::Volume, AWS::S3::Bucket, and other resource types via SQL-like queries.
"""

import json
import logging
import time
from typing import Any, Dict, List, Optional

import boto3
from botocore.exceptions import ClientError

from runbooks.common.rich_utils import console

logger = logging.getLogger(__name__)

CONFIG_RESOURCE_TYPES = {
    "ec2": "AWS::EC2::Instance",
    "ebs": "AWS::EC2::Volume",
    "s3": "AWS::S3::Bucket",
    "rds": "AWS::RDS::DBInstance",
    "lambda": "AWS::Lambda::Function",
    "vpc": "AWS::EC2::VPC",
    "iam_role": "AWS::IAM::Role",
    "cloudformation": "AWS::CloudFormation::Stack",
}


def detect_aggregator(session: boto3.Session, region: str = "ap-southeast-2") -> Optional[str]:
    """Detect the first available Config Aggregator in the account."""
    try:
        config_client = session.client("config", region_name=region)
        response = config_client.describe_configuration_aggregators()
        aggregators = response.get("ConfigurationAggregators", [])
        if aggregators:
            name = aggregators[0]["ConfigurationAggregatorName"]
            logger.info(f"Found Config Aggregator: {name}")
            return name
        return None
    except ClientError as e:
        logger.debug(f"Config Aggregator detection failed: {e}")
        return None


def query_config_resources(
    session: boto3.Session,
    aggregator_name: str,
    resource_type: str,
    region: str = "ap-southeast-2",
) -> List[Dict[str, Any]]:
    """Query Config Aggregator for resources of a given type using SQL expression."""
    config_client = session.client("config", region_name=region)
    query = (
        f"SELECT resourceId, resourceName, resourceType, accountId, awsRegion, configuration "
        f"WHERE resourceType = '{resource_type}'"
    )

    resources = []
    next_token = None

    while True:
        params = {
            "ConfigurationAggregatorName": aggregator_name,
            "Expression": query,
            "MaxResults": 100,
        }
        if next_token:
            params["NextToken"] = next_token

        try:
            response = config_client.select_aggregate_resource_config(**params)
        except ClientError as e:
            logger.warning(f"Config query failed for {resource_type}: {e}")
            break

        for result_str in response.get("Results", []):
            try:
                resources.append(json.loads(result_str))
            except json.JSONDecodeError:
                pass

        next_token = response.get("NextToken")
        if not next_token:
            break

    return resources


def normalize_config_result(resource: Dict[str, Any], resource_category: str) -> Dict[str, Any]:
    """Normalize a Config Aggregator result into standard inventory format."""
    return {
        "resource_id": resource.get("resourceId", ""),
        "resource_name": resource.get("resourceName", ""),
        "resource_type": resource_category,
        "account_id": resource.get("accountId", ""),
        "region": resource.get("awsRegion", ""),
        "configuration": resource.get("configuration", {}),
    }


def collect_via_aggregator(
    session: boto3.Session,
    aggregator_name: str,
    resource_types: Optional[List[str]] = None,
    region: str = "ap-southeast-2",
) -> Dict[str, Any]:
    """
    Collect inventory via Config Aggregator for org-wide discovery.

    Returns dict with 'resources' (list) and 'summary' (per-type counts).
    """
    start_time = time.time()
    types_to_query = list(CONFIG_RESOURCE_TYPES.keys()) if resource_types is None else resource_types
    all_resources = []
    summary = {}

    for category in types_to_query:
        aws_type = CONFIG_RESOURCE_TYPES.get(category)
        if not aws_type:
            logger.warning(f"Unknown resource category: {category}")
            continue

        console.print(f"[dim]Querying Config Aggregator for {category} ({aws_type})...[/dim]")
        try:
            raw_resources = query_config_resources(session, aggregator_name, aws_type, region)
            normalized = [normalize_config_result(r, category) for r in raw_resources]
            all_resources.extend(normalized)
            summary[category.upper()] = len(normalized)
            console.print(f"[green]Found {len(normalized)} {category} resources[/green]")
        except Exception as e:
            logger.warning(f"Failed to query {category}: {e}")
            summary[category.upper()] = 0

    duration = round(time.time() - start_time, 2)
    console.print(f"[dim]Config Aggregator collection completed in {duration}s[/dim]")

    return {
        "resources": all_resources,
        "summary": summary,
        "total_resources": len(all_resources),
        "duration_seconds": duration,
        "aggregator_name": aggregator_name,
        "resource_types_queried": types_to_query,
    }
