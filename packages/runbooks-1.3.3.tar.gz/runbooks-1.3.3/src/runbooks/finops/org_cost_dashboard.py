"""
Org-Level Cost Dashboard - 4-Query Parallel Pattern

COS1-01: HITL runs `runbooks finops dashboard --timeframe monthly --profile $AWS_BILLING_PROFILE`
and gets accurate multi-account cost report in <30s.

Architecture:
- Auto-detects org-level billing profile (payer account) via LINKED_ACCOUNT probe
- 4 parallel CE queries: account costs, service costs, prev account, prev service
- ThreadPoolExecutor(max_workers=4) with Semaphore(5) for CE rate limit
- Returns None if profile is not an org billing account (fallback to single-account)
"""

import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional

from runbooks.common.date_utils import DateRangeCalculator
from runbooks.common.profile_utils import create_cost_session, validate_sso_session
from runbooks.common.rich_utils import console

logger = logging.getLogger(__name__)

_CE_SEMAPHORE = threading.Semaphore(5)


def _ce_query(ce_client, params: dict) -> dict:
    """Execute a single CE query with semaphore rate limiting."""
    with _CE_SEMAPHORE:
        return ce_client.get_cost_and_usage(**params)


def _parse_grouped_costs(response: dict, metric: str) -> Dict[str, float]:
    """Parse CE response with GROUP_BY into {key: cost} dict."""
    costs: Dict[str, float] = {}
    for result in response.get("ResultsByTime", []):
        for group in result.get("Groups", []):
            key = group["Keys"][0]
            amount = float(group["Metrics"][metric]["Amount"])
            costs[key] = costs.get(key, 0) + amount
    return costs


def _build_result(
    account_costs: Dict[str, float],
    service_costs: Dict[str, float],
    prev_account_costs: Dict[str, float],
    prev_service_costs: Dict[str, float],
    current_days: int,
    previous_days: int,
    timeframe: str,
) -> Dict[str, Any]:
    """Assemble result dict matching dashboard_multi.py schema."""
    organization_total = sum(account_costs.values())
    previous_total = sum(prev_account_costs.values())

    accounts: List[Dict[str, Any]] = [
        {"id": acct_id, "name": acct_id, "status": "ACTIVE", "cost": cost}
        for acct_id, cost in account_costs.items()
        if cost > 0
    ]
    accounts.sort(key=lambda x: x["cost"], reverse=True)

    return {
        "mode": "multi-account",
        "organization_total": organization_total,
        "accounts": accounts,
        "per_account_costs": account_costs,
        "service_costs": service_costs,
        "account_count": len(account_costs),
        "active_accounts": len([c for c in account_costs.values() if c > 0]),
        "timeframe": timeframe,
        "previous_account_costs": prev_account_costs,
        "previous_service_costs": prev_service_costs,
        "previous_total": previous_total,
        "current_days": current_days,
        "previous_days": previous_days,
    }


def try_org_level_dashboard(
    profile: str,
    timeframe: str = "monthly",
    month: Optional[str] = None,
    cost_metric: str = "UnblendedCost",
    **kwargs,
) -> Optional[Dict[str, Any]]:
    """
    Attempt org-level dashboard via billing profile auto-detection.

    Makes a probe CE query grouped by LINKED_ACCOUNT (no Filter).
    On a payer account this returns all linked accounts automatically.
    Returns result dict if >1 account, else None for single-account fallback.
    """
    # Credential pre-flight: detect expired SSO before API calls
    try:
        if not validate_sso_session(profile):
            logger.debug("SSO session expired for profile %s", profile)
            console.print(
                f"[yellow]SSO session expired for profile '{profile}'. Run: aws sso login --profile={profile}[/yellow]"
            )
            return None
    except Exception:
        pass  # Non-SSO profiles don't need this check

    start_time = time.time()

    try:
        session = create_cost_session(profile_name=profile)
        ce_client = session.client("ce", region_name="ap-southeast-2")
    except (Exception, SystemExit) as e:
        logger.debug("Failed to create CE session for org probe: %s", e)
        return None

    # Calculate date ranges
    try:
        if month:
            current_range = DateRangeCalculator.month_range(month)
        elif timeframe == "monthly":
            current_range = DateRangeCalculator.month_to_date()
        else:
            current_range = DateRangeCalculator.month_to_date()

        prev_range = (
            DateRangeCalculator.previous_month(current_range)
            if month
            else DateRangeCalculator.previous_calendar_month()
        )
        cur_start, cur_end = DateRangeCalculator.format_for_aws(current_range)
        prev_start, prev_end = DateRangeCalculator.format_for_aws(prev_range)
    except Exception as e:
        logger.debug("Date range calculation failed: %s", e)
        return None

    metric = cost_metric

    # Probe: LINKED_ACCOUNT query without Filter (payer accounts return all linked)
    try:
        probe_params = {
            "TimePeriod": {"Start": cur_start, "End": cur_end},
            "Granularity": "MONTHLY",
            "Metrics": [metric],
            "GroupBy": [{"Type": "DIMENSION", "Key": "LINKED_ACCOUNT"}],
        }
        probe_response = _ce_query(ce_client, probe_params)
        account_costs = _parse_grouped_costs(probe_response, metric)
    except Exception as e:
        logger.debug("Org-level CE probe failed: %s", e)
        return None

    if len(account_costs) <= 1:
        logger.debug("Single account detected (%d), falling back", len(account_costs))
        return None

    # Org billing profile confirmed — run remaining 3 queries in parallel
    console.print(f"\n[bold cyan]📊 Org-Level Dashboard[/] [dim](auto-detected {len(account_costs)} accounts)[/]")
    console.print(f"[dim]Profile: {profile} | Period: {cur_start} to {cur_end} ({current_range.days}d)[/]")

    service_params = {
        "TimePeriod": {"Start": cur_start, "End": cur_end},
        "Granularity": "MONTHLY",
        "Metrics": [metric],
        "GroupBy": [{"Type": "DIMENSION", "Key": "SERVICE"}],
    }
    prev_account_params = {
        "TimePeriod": {"Start": prev_start, "End": prev_end},
        "Granularity": "MONTHLY",
        "Metrics": [metric],
        "GroupBy": [{"Type": "DIMENSION", "Key": "LINKED_ACCOUNT"}],
    }
    prev_service_params = {
        "TimePeriod": {"Start": prev_start, "End": prev_end},
        "Granularity": "MONTHLY",
        "Metrics": [metric],
        "GroupBy": [{"Type": "DIMENSION", "Key": "SERVICE"}],
    }

    service_costs: Dict[str, float] = {}
    prev_account_costs: Dict[str, float] = {}
    prev_service_costs: Dict[str, float] = {}

    try:
        with ThreadPoolExecutor(max_workers=3) as executor:
            futures = {
                executor.submit(_ce_query, ce_client, service_params): "service",
                executor.submit(_ce_query, ce_client, prev_account_params): "prev_account",
                executor.submit(_ce_query, ce_client, prev_service_params): "prev_service",
            }
            for future in as_completed(futures):
                query_name = futures[future]
                try:
                    response = future.result()
                    parsed = _parse_grouped_costs(response, metric)
                    if query_name == "service":
                        service_costs = parsed
                    elif query_name == "prev_account":
                        prev_account_costs = parsed
                    elif query_name == "prev_service":
                        prev_service_costs = parsed
                except Exception as e:
                    logger.warning("Parallel CE query '%s' failed: %s", query_name, e)
    except Exception as e:
        logger.warning("Parallel execution failed: %s", e)

    # ACT-S6-03: EBS cost isolation — separate EBS from EC2-Other via USAGE_TYPE
    ebs_breakdown: Dict[str, float] = {}
    try:
        ebs_params = {
            "TimePeriod": {"Start": cur_start, "End": cur_end},
            "Granularity": "MONTHLY",
            "Metrics": [metric],
            "Filter": {"Dimensions": {"Key": "SERVICE", "Values": ["EC2 - Other"]}},
            "GroupBy": [{"Type": "DIMENSION", "Key": "USAGE_TYPE"}],
        }
        ebs_response = _ce_query(ce_client, ebs_params)
        ebs_breakdown = _parse_grouped_costs(ebs_response, metric)
    except Exception as e:
        logger.debug("EBS breakdown query failed (non-blocking): %s", e)

    result = _build_result(
        account_costs=account_costs,
        service_costs=service_costs,
        prev_account_costs=prev_account_costs,
        prev_service_costs=prev_service_costs,
        current_days=current_range.days,
        previous_days=prev_range.days,
        timeframe=timeframe,
    )

    # Add EBS breakdown to result for FinOps persona reports
    if ebs_breakdown:
        result["ebs_breakdown"] = ebs_breakdown

    # Add daily averages to result for downstream consumers
    org_total = result["organization_total"]
    prev_total = result["previous_total"]
    cur_days = result["current_days"]
    prev_days = result["previous_days"]
    result["current_daily_avg"] = org_total / cur_days if cur_days > 0 else 0
    result["previous_daily_avg"] = prev_total / prev_days if prev_days > 0 else 0

    active = result["active_accounts"]
    total = result["account_count"]
    console.print(f"[green]✅ Organization total: ${org_total:,.2f}[/] [dim]({active}/{total} active accounts)[/]")

    # Daily average comparison
    cur_avg = result["current_daily_avg"]
    prev_avg = result["previous_daily_avg"]
    if prev_avg > 0:
        avg_delta = ((cur_avg - prev_avg) / prev_avg) * 100
        trend = "↑" if avg_delta > 0 else "↓" if avg_delta < 0 else "→"
        style = "red" if avg_delta > 0 else "green" if avg_delta < 0 else "dim"
        console.print(
            f"[dim]Daily avg: ${cur_avg:,.2f}/day ({cur_days}d) vs ${prev_avg:,.2f}/day ({prev_days}d)[/] "
            f"[{style}]{trend} {abs(avg_delta):.1f}%[/{style}]"
        )

    result["execution_time_seconds"] = round(time.time() - start_time, 2)
    console.print(f"[dim]Execution time: {result['execution_time_seconds']}s[/dim]")

    # COS1-01: Export handling for org dashboard path
    export_formats = kwargs.get("export_formats")
    if export_formats:
        from runbooks.common import export as export_engine

        non_html_formats = [f for f in export_formats if f != "html"]
        if non_html_formats:
            export_paths = export_engine.export_to_formats(
                data=result,
                base_filename=f"org-dashboard-{profile}",
                formats=non_html_formats,
            )
            result["export_paths"] = export_paths
            console.print(f"[green]Exported to {len(export_paths)} formats[/]")

    return result
