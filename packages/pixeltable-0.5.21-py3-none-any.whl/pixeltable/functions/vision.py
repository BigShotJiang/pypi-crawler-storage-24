"""
Pixeltable UDFs for Computer Vision.

Example:
```python
import pixeltable as pxt
from pixeltable.functions import vision as pxtv

t = pxt.get_table(...)
t.select(
    pxtv.bboxes_draw(t.img, boxes=t.boxes, labels=t.labels)
).collect()
```
"""

import colorsys
import hashlib
import itertools
import re
from collections import defaultdict
from typing import Any, Literal

import numpy as np
import PIL.Image
import PIL.ImageColor
import PIL.ImageDraw
import PIL.ImageFont

import pixeltable as pxt
from pixeltable.utils.code import local_public_names


# the following function has been adapted from MMEval
# (sources at https://github.com/open-mmlab/mmeval)
# Copyright (c) OpenMMLab. All rights reserved.
def __calculate_bboxes_area(bboxes: np.ndarray) -> np.ndarray:
    """Calculate area of bounding boxes.

    Args:
        bboxes (numpy.ndarray): The bboxes with shape (n, 4) or (4, ) in 'xyxy' format.
     Returns:
        numpy.ndarray: The area of bboxes.
    """
    bboxes_w = bboxes[..., 2] - bboxes[..., 0]
    bboxes_h = bboxes[..., 3] - bboxes[..., 1]
    areas = bboxes_w * bboxes_h
    return areas


# the following function has been adapted from MMEval
# (sources at https://github.com/open-mmlab/mmeval)
# Copyright (c) OpenMMLab. All rights reserved.
def __calculate_overlaps(bboxes1: np.ndarray, bboxes2: np.ndarray) -> np.ndarray:
    """Calculate the overlap between each bbox of bboxes1 and bboxes2.

    Args:
        bboxes1 (numpy.ndarray): The bboxes with shape (n, 4) in 'xyxy' format.
        bboxes2 (numpy.ndarray): The bboxes with shape (k, 4) in 'xyxy' format.
    Returns:
        numpy.ndarray: IoUs or IoFs with shape (n, k).
    """
    bboxes1 = bboxes1.astype(np.float32)
    bboxes2 = bboxes2.astype(np.float32)
    rows = bboxes1.shape[0]
    cols = bboxes2.shape[0]
    overlaps = np.zeros((rows, cols), dtype=np.float32)

    if rows * cols == 0:
        return overlaps

    if bboxes1.shape[0] > bboxes2.shape[0]:
        # Swap bboxes for faster calculation.
        bboxes1, bboxes2 = bboxes2, bboxes1
        overlaps = np.zeros((cols, rows), dtype=np.float32)
        exchange = True
    else:
        exchange = False

    # Calculate the bboxes area.
    area1 = __calculate_bboxes_area(bboxes1)
    area2 = __calculate_bboxes_area(bboxes2)
    eps = np.finfo(np.float32).eps

    for i in range(bboxes1.shape[0]):
        x_start = np.maximum(bboxes1[i, 0], bboxes2[:, 0])
        y_start = np.maximum(bboxes1[i, 1], bboxes2[:, 1])
        x_end = np.minimum(bboxes1[i, 2], bboxes2[:, 2])
        y_end = np.minimum(bboxes1[i, 3], bboxes2[:, 3])
        overlap_w = np.maximum(x_end - x_start, 0)
        overlap_h = np.maximum(y_end - y_start, 0)
        overlap = overlap_w * overlap_h

        union = area1[i] + area2 - overlap
        union = np.maximum(union, eps)
        overlaps[i, :] = overlap / union
    return overlaps if not exchange else overlaps.T


# the following function has been adapted from MMEval
# (sources at https://github.com/open-mmlab/mmeval)
# Copyright (c) OpenMMLab. All rights reserved.
def __calculate_image_tpfp(
    pred_bboxes: np.ndarray, pred_scores: np.ndarray, gt_bboxes: np.ndarray, min_iou: float
) -> tuple[np.ndarray, np.ndarray]:
    """Calculate the true positive and false positive on an image.

    Args:
        pred_bboxes (numpy.ndarray): Predicted bboxes of this image, with
            shape (N, 5). The scores The predicted score of the bbox is
            concatenated behind the predicted bbox.
        gt_bboxes (numpy.ndarray): Ground truth bboxes of this image, with
            shape (M, 4).
        min_iou (float): The IoU threshold.

    Returns:
        tuple (tp, fp):
        tp: Shape (N,), the true positive flag of each predicted bbox on this image.
        fp: Shape (N,), the false positive flag of each predicted bbox on this image.
    """
    # Step 1. Concatenate `gt_bboxes` and `ignore_gt_bboxes`, then set
    # the `ignore_gt_flags`.
    # all_gt_bboxes = np.concatenate((gt_bboxes, ignore_gt_bboxes))
    # ignore_gt_flags = np.concatenate((np.zeros(
    #     (gt_bboxes.shape[0], 1),
    #     dtype=bool), np.ones((ignore_gt_bboxes.shape[0], 1), dtype=bool)))

    # Step 2. Initialize the `tp` and `fp` arrays.
    num_preds = pred_bboxes.shape[0]
    tp = np.zeros(num_preds, dtype=np.int8)
    fp = np.zeros(num_preds, dtype=np.int8)

    # Step 3. If there are no gt bboxes in this image, then all pred bboxes
    # within area range are false positives.
    if gt_bboxes.shape[0] == 0:
        fp[...] = 1
        return tp, fp

    # Step 4. Calculate the IoUs between the predicted bboxes and the
    # ground truth bboxes.
    ious = __calculate_overlaps(pred_bboxes, gt_bboxes)
    # For each pred bbox, the max iou with all gts.
    ious_max = ious.max(axis=1)
    # For each pred bbox, which gt overlaps most with it.
    ious_argmax = ious.argmax(axis=1)
    # Sort all pred bbox in descending order by scores.
    sorted_indices = np.argsort(-pred_scores)

    # Step 5. Count the `tp` and `fp` of each iou threshold and area range.
    # The flags that gt bboxes have been matched.
    gt_covered_flags = np.zeros(gt_bboxes.shape[0], dtype=bool)

    # Count the prediction bboxes in order of decreasing score.
    for pred_bbox_idx in sorted_indices:
        if ious_max[pred_bbox_idx] >= min_iou:
            matched_gt_idx = ious_argmax[pred_bbox_idx]
            if not gt_covered_flags[matched_gt_idx]:
                tp[pred_bbox_idx] = 1
                gt_covered_flags[matched_gt_idx] = True
            else:
                # This gt bbox has been matched and counted as fp.
                fp[pred_bbox_idx] = 1
        else:
            fp[pred_bbox_idx] = 1

    return tp, fp


@pxt.udf
def eval_detections(
    pred_bboxes: list[list[int]],
    pred_labels: list[int],
    pred_scores: list[float],
    gt_bboxes: list[list[int]],
    gt_labels: list[int],
    min_iou: float = 0.5,
) -> list[dict]:
    """
    Evaluates the performance of a set of predicted bounding boxes against a set of ground truth bounding boxes.

    Args:
        pred_bboxes: List of predicted bounding boxes, each represented as [xmin, ymin, xmax, ymax].
        pred_labels: List of predicted labels.
        pred_scores: List of predicted scores.
        gt_bboxes: List of ground truth bounding boxes, each represented as [xmin, ymin, xmax, ymax].
        gt_labels: List of ground truth labels.
        min_iou: Minimum intersection-over-union (IoU) threshold for a predicted bounding box to be
            considered a true positive.

    Returns:
        A list of dictionaries, one per label class, with the following structure:
        ```python
        {
            'min_iou': float,  # The value of `min_iou` used for the detections
            'class': int,  # The label class
            # List of 1's and 0's indicating true positives for each
            # predicted bounding box of this class
            'tp': list[int],
            # List of 1's and 0's indicating false positives for each
            # predicted bounding box of this class; `fp[n] == 1 - tp[n]`
            'fp': list[int],
            # List of predicted scores for each bounding box of this class
            'scores': list[float],
            'num_gts': int,  # Number of ground truth bounding boxes of this class
        }
        ```
    """
    class_idxs = list(set(pred_labels + gt_labels))
    result: list[dict] = []
    pred_bboxes_arr = np.asarray(pred_bboxes)
    pred_classes_arr = np.asarray(pred_labels)
    pred_scores_arr = np.asarray(pred_scores)
    gt_bboxes_arr = np.asarray(gt_bboxes)
    gt_classes_arr = np.asarray(gt_labels)
    for class_idx in class_idxs:
        pred_filter = pred_classes_arr == class_idx
        gt_filter = gt_classes_arr == class_idx
        class_pred_scores = pred_scores_arr[pred_filter]
        tp, fp = __calculate_image_tpfp(
            pred_bboxes_arr[pred_filter], class_pred_scores, gt_bboxes_arr[gt_filter], min_iou
        )
        ordered_class_pred_scores = -np.sort(-class_pred_scores)
        result.append(
            {
                'min_iou': min_iou,
                'class': class_idx,
                'tp': tp.tolist(),
                'fp': fp.tolist(),
                'scores': ordered_class_pred_scores.tolist(),
                'num_gts': gt_filter.sum().item(),
            }
        )
    return result


@pxt.uda
class mean_ap(pxt.Aggregator):
    """
    Calculates the mean average precision (mAP) over
    [`eval_detections()`][pixeltable.functions.vision.eval_detections] results.

    __Parameters:__

    - `eval_dicts` (list[dict]): List of dictionaries as returned by
        [`eval_detections()`][pixeltable.functions.vision.eval_detections].

    __Returns:__

    - A `dict[int, float]` mapping each label class to an average precision (AP) value for that class.
    """

    def __init__(self) -> None:
        self.class_tpfp: dict[int, list[dict]] = defaultdict(list)

    def update(self, eval_dicts: list[dict]) -> None:
        for eval_dict in eval_dicts:
            class_idx = eval_dict['class']
            self.class_tpfp[class_idx].append(eval_dict)

    def value(self) -> dict:
        eps = np.finfo(np.float32).eps
        result: dict[int, float] = {}
        for class_idx, tpfp in self.class_tpfp.items():
            tp = np.concatenate([x['tp'] for x in tpfp], axis=0)
            fp = np.concatenate([x['fp'] for x in tpfp], axis=0)
            num_gts = np.sum([x['num_gts'] for x in tpfp])
            scores = np.concatenate([np.asarray(x['scores']) for x in tpfp])
            sorted_idxs = np.argsort(-scores)
            tp_cumsum = tp[sorted_idxs].cumsum()
            fp_cumsum = fp[sorted_idxs].cumsum()
            precision = tp_cumsum / np.maximum(tp_cumsum + fp_cumsum, eps)
            recall = tp_cumsum / np.maximum(num_gts, eps)

            mrec = np.hstack((0, recall, 1))
            mpre = np.hstack((0, precision, 0))
            for i in range(mpre.shape[0] - 1, 0, -1):
                mpre[i - 1] = np.maximum(mpre[i - 1], mpre[i])
            ind = np.where(mrec[1:] != mrec[:-1])[0]
            ap = np.sum((mrec[ind + 1] - mrec[ind]) * mpre[ind + 1])
            result[class_idx] = ap.item()
        return result


def __create_label_colors(labels: list[Any]) -> dict[Any, str]:
    """
    Create random colors for labels such that a particular label always gets the same color.

    Returns:
        dict mapping labels to colors
    """
    distinct_labels = set(labels)
    result: dict[Any, str] = {}
    for label in distinct_labels:
        # consistent hash for the label
        label_hash = int(hashlib.md5(str(label).encode()).hexdigest(), 16)
        hue = (label_hash % 360) / 360.0
        rgb = colorsys.hsv_to_rgb(hue, 0.7, 0.95)
        hex_color = '#{:02x}{:02x}{:02x}'.format(int(rgb[0] * 255), int(rgb[1] * 255), int(rgb[2] * 255))
        result[label] = hex_color
    return result


@pxt.udf
def bboxes_draw(
    img: PIL.Image.Image,
    boxes: list[list[int]],
    *,
    labels: list[Any] | None = None,
    color: str | None = None,
    box_colors: list[str] | None = None,
    alpha: float | None = None,
    fill: bool = False,
    fill_alpha: float | None = None,
    width: int = 1,
    font: str | None = None,
    font_size: int | None = None,
) -> PIL.Image.Image:
    """
    Draws bounding boxes on the given image.

    Labels can be any type that supports `str()` and is hashable (e.g., strings, ints, etc.).

    Colors can be specified as common HTML color names (e.g., 'red') supported by PIL's
    [`ImageColor`](https://pillow.readthedocs.io/en/stable/reference/ImageColor.html#imagecolor-module) module or as
    RGB/RGBA hex codes (e.g., '#FF0000', '#FF0000FF'). If opacity isn't specified in the color string and
    `alpha`/`fill_alpha` is `None`, defaults to 1.0 for box borders and 0.5 for filled boxes.

    If no colors are specified, this function randomly assigns each label a specific color based on a hash of the label.

    Args:
        img: The image on which to draw the bounding boxes.
        boxes: List of bounding boxes, each represented as [xmin, ymin, xmax, ymax].
        labels: List of labels for each bounding box.
        color: Single color to be used for all bounding boxes and labels.
        box_colors: List of colors, one per bounding box.
        alpha: Opacity (0-1) of the bounding box borders and labels. If non-`None`, overrides any alpha in
            `color`/`box_colors`.
        fill: Whether to fill the bounding boxes with color.
        fill_alpha: Opacity (0-1) of the bounding box fill. If non-`None`, overrides any alpha in
            `color`/`box_colors`.
        width: Width of the bounding box borders.
        font: Name of a system font or path to a TrueType font file, as required by
            [`PIL.ImageFont.truetype()`](https://pillow.readthedocs.io/en/stable/reference/ImageFont.html#PIL.ImageFont.truetype).
            If `None`, uses the default provided by
            [`PIL.ImageFont.load_default()`](https://pillow.readthedocs.io/en/stable/reference/ImageFont.html#PIL.ImageFont.load_default).
        font_size: Size of the font used for labels in points. Only used in conjunction with non-`None` `font` argument.

    Returns:
        The image with bounding boxes drawn on it.
    """
    if len(boxes) == 0:
        return img

    color_params = sum([color is not None, box_colors is not None])
    if color_params > 1:
        raise ValueError("Only one of 'color' or 'box_colors' can be set")

    # ensure the number of labels matches the number of boxes
    num_boxes = len(boxes)
    if labels is None:
        labels = [None] * num_boxes
    elif len(labels) != num_boxes:
        raise ValueError('Number of boxes and labels must match')

    if box_colors is not None:
        if len(box_colors) != num_boxes:
            raise ValueError('Number of boxes and box colors must match')
    elif color is not None:
        box_colors = [color] * num_boxes
    else:
        label_colors = __create_label_colors(labels)
        box_colors = [label_colors[label] for label in labels]

    rgb_box_colors = [PIL.ImageColor.getrgb(c) for c in box_colors]
    rgba_border_colors: list[tuple[int, int, int, int]]
    if alpha is not None:
        # override any alpha in rgb_box_colors
        int_alpha = int(alpha * 255)
        rgba_border_colors = [(c[0], c[1], c[2], int_alpha) for c in rgb_box_colors]
    else:
        # default to full opacity if alpha is missing
        rgba_border_colors = [(*c, 255) if len(c) == 3 else c for c in rgb_box_colors]

    rgba_fill_colors: list[tuple[int, int, int, int]] = []
    if fill:
        if fill_alpha is not None:
            int_fill_alpha = int(fill_alpha * 255)
            rgba_fill_colors = [(c[0], c[1], c[2], int_fill_alpha) for c in rgb_box_colors]
        else:
            # default to semi-transparent if alpha is missing
            rgba_fill_colors = [(*c, 127) if len(c) == 3 else c for c in rgb_box_colors]

    # set default font if not provided
    txt_font: PIL.ImageFont.ImageFont | PIL.ImageFont.FreeTypeFont = (
        PIL.ImageFont.load_default() if font is None else PIL.ImageFont.truetype(font=font, size=font_size or 10)
    )

    img_to_draw = img.copy()
    draw = PIL.ImageDraw.Draw(img_to_draw, 'RGBA')

    # Draw bounding boxes
    for i, bbox in enumerate(boxes):
        # determine color for the current box and label
        border_color = rgba_border_colors[i % len(box_colors)]

        if fill:
            fill_color = rgba_fill_colors[i % len(box_colors)]
            draw.rectangle(bbox, outline=border_color, width=width, fill=fill_color)  # type: ignore[arg-type]
        else:
            draw.rectangle(bbox, outline=border_color, width=width)  # type: ignore[arg-type]

    # Now draw labels separately, so they are not obscured by the boxes
    for bbox, label in zip(boxes, labels):
        if label is not None:
            label_str = str(label)
            _, _, text_width, text_height = draw.textbbox((0, 0), label_str, font=txt_font)
            if bbox[1] - text_height - 2 >= 0:
                # draw text above the box
                y = bbox[1] - text_height - 2
            else:
                y = bbox[3]
            if bbox[0] + text_width + 2 < img.width:
                x = bbox[0]
            else:
                x = img.width - text_width - 2
            draw.rectangle((x, y, x + text_width + 1, y + text_height + 1), fill='black')
            draw.text((x, y), label_str, fill='white', font=txt_font)

    return img_to_draw


def _validate_bboxes(bboxes: list, error_prefix: str) -> bool:
    """Check that bboxes are either all int or all float. Return True for absolute, False for relative."""
    if not all(len(b) == 4 for b in bboxes):
        raise pxt.Error(f'{error_prefix}: each bounding box must have exactly 4 coordinates')
    is_absolute = all(isinstance(x, int) and x >= 0 for x in itertools.chain.from_iterable(bboxes))
    is_relative = all(isinstance(x, float) and 0.0 <= x <= 1.0 for x in itertools.chain.from_iterable(bboxes))
    if not (is_absolute or is_relative):
        raise pxt.Error(
            f'{error_prefix}: bounding box coordinates must be either all int (>= 0) or all float (in [0, 1])'
        )
    return is_absolute


@pxt.udf
def bboxes_convert(
    bboxes: list,  # should be list[list[int | float]]
    *,
    src_format: Literal['xyxy', 'xywh', 'cxcywh'],
    dst_format: Literal['xyxy', 'xywh', 'cxcywh'],
) -> list:
    """
    Convert a list of bounding boxes from src_format to dst_format.

    Args:
        bboxes: List of bounding boxes, each either specified with absolute pixel coordinates or relative
            coordinates in [0, 1].
        src_format: Source format, one of 'xyxy', 'xywh', 'cxcywh'.
        dst_format: Destination format, one of 'xyxy', 'xywh', 'cxcywh'.

    Returns:
        List of bounding boxes in dst_format.
    """
    if len(bboxes) == 0:
        return []

    if src_format not in ('xyxy', 'xywh', 'cxcywh'):
        raise pxt.Error(f'Invalid src_format: {src_format!r}')
    if dst_format not in ('xyxy', 'xywh', 'cxcywh'):
        raise pxt.Error(f'Invalid dst_format: {dst_format!r}')
    is_absolute = _validate_bboxes(bboxes, 'bboxes_convert()')
    if src_format == dst_format:
        return bboxes

    arr = np.array(bboxes, dtype=np.float64)
    assert arr.ndim == 2 and arr.shape[1] == 4
    c0, c1, c2, c3 = arr[:, 0], arr[:, 1], arr[:, 2], arr[:, 3]

    result: np.ndarray
    if src_format == 'xyxy' and dst_format == 'xywh':
        result = np.column_stack([c0, c1, c2 - c0, c3 - c1])
    elif src_format == 'xyxy' and dst_format == 'cxcywh':
        w, h = c2 - c0, c3 - c1
        result = np.column_stack([c0 + w / 2, c1 + h / 2, w, h])
    elif src_format == 'xywh' and dst_format == 'xyxy':
        result = np.column_stack([c0, c1, c0 + c2, c1 + c3])
    elif src_format == 'xywh' and dst_format == 'cxcywh':
        result = np.column_stack([c0 + c2 / 2, c1 + c3 / 2, c2, c3])
    elif src_format == 'cxcywh' and dst_format == 'xyxy':
        result = np.column_stack([c0 - c2 / 2, c1 - c3 / 2, c0 + c2 / 2, c1 + c3 / 2])
    else:  # cxcywh -> xywh
        result = np.column_stack([c0 - c2 / 2, c1 - c3 / 2, c2, c3])

    if is_absolute:
        # don't use round() here, it rounds to the nearest even number
        result = np.floor(result + 0.5).astype(int)
    return result.tolist()


ASPECT_RATIO_RE = re.compile(r'(\d+):(\d+)')


@pxt.udf
def bboxes_resize(
    bboxes: list,  # should be: list[list[int]] | list[list[float]]
    format: Literal['xyxy', 'xywh', 'cxcywh'],
    *,
    width: int | None = None,
    height: int | None = None,
    aspect: str | None = None,
    aspect_mode: str | None = None,  # should be Literal['crop', 'pad'] | None
) -> list:
    """
    Resize a list of bounding boxes (center-anchored):

    - to a specified width or height (the other dimension is scaled to maintain the aspect ratio)
    - to a specified aspect ratio

    Only one of `width`, `height`, or `aspect` can be specified.

    Args:
        bboxes: List of bounding boxes, each either specified with absolute pixel coordinates or relative
            coordinates in [0, 1].
        format: Format of the bounding box coordinates, one of 'xyxy', 'xywh', 'cxcywh'.
        width: Target width. Pass an `int` for absolute pixels or a `float` for relative coordinates.
        height: Target height. Pass an `int` for absolute pixels or a `float` for relative coordinates.
        aspect: Target aspect ratio. Pass a `str` like '16:9' or a `float` like 1.78.
        aspect: Target aspect ratio as a string 'W:H' (e.g., '16:9') or a `float`. Resizes either the width
            or height to match the specified aspect ratio, maintaining the other dimension. Requires `aspect_mode`.
        aspect_mode: Either 'crop' or 'pad'. Required when `aspect` is specified. If `crop`, reduces the oversized
            dimension to match the aspect ratio. If `pad`, extends the undersized dimension to match the aspect ratio.

    Returns:
        List of resized bounding boxes in the same format as the input.
    """
    if width is not None and width <= 0:
        raise pxt.Error(f'width must be positive, got {width}')
    if height is not None and height <= 0:
        raise pxt.Error(f'height must be positive, got {height}')
    aspect_f: float | None = None
    if aspect is not None:
        match = ASPECT_RATIO_RE.fullmatch(aspect)
        if match is None:
            raise pxt.Error(f'Invalid aspect ratio: {aspect!r}; expected "W:H"')
        w_val, h_val = int(match.group(1)), int(match.group(2))
        if w_val == 0 or h_val == 0:
            raise pxt.Error(f'Invalid aspect ratio: {aspect!r}; width and height must be positive')
        aspect_f = float(w_val) / float(h_val)
    return _bboxes_resize(bboxes, format, width=width, height=height, aspect=aspect_f, aspect_mode=aspect_mode)


@bboxes_resize.overload
def _(
    bboxes: list,
    format: Literal['xyxy', 'xywh', 'cxcywh'],
    *,
    width: float | None = None,
    height: float | None = None,
    aspect: float | None = None,
    aspect_mode: str | None = None,
) -> list:
    if width is not None and width <= 0:
        raise pxt.Error(f'width must be positive, got {width}')
    if height is not None and height <= 0:
        raise pxt.Error(f'height must be positive, got {height}')
    if aspect is not None and aspect <= 0:
        raise pxt.Error(f'aspect must be positive, got {aspect}')

    return _bboxes_resize(bboxes, format, width_f=width, height_f=height, aspect=aspect, aspect_mode=aspect_mode)


def _bboxes_resize(
    bboxes: list,  # should be: list[list[int]] | list[list[float]]
    format: Literal['xyxy', 'xywh', 'cxcywh'],
    *,
    width: int | None = None,
    width_f: float | None = None,
    height: int | None = None,
    height_f: float | None = None,
    aspect: float | None = None,
    aspect_mode: str | None = None,  # should be Literal['crop', 'pad'] | None
) -> list:
    if len(bboxes) == 0:
        return []

    # TODO: this is a lot of repeated per-call validation; find a way to do this at plan generation time, where possible
    assert width is None or width > 0
    assert width_f is None or width_f > 0
    assert height is None or height > 0
    assert height_f is None or height_f > 0
    assert aspect is None or aspect > 0
    if aspect_mode is not None and aspect_mode not in ['crop', 'pad']:
        raise pxt.Error(f'Invalid aspect_mode: {aspect_mode!r}; expected "crop" or "pad"')

    has_width = width is not None or width_f is not None
    has_height = height is not None or height_f is not None
    has_aspect = aspect is not None
    if has_width + has_height + has_aspect != 1:
        raise pxt.Error('Exactly one of width, height, or aspect must be specified')
    if has_aspect and aspect_mode is None:
        raise pxt.Error("aspect_mode ('crop' or 'pad') is required when aspect is specified")
    if not has_aspect and aspect_mode is not None:
        raise pxt.Error('aspect_mode is only valid when aspect is specified')

    is_absolute = _validate_bboxes(bboxes, 'bboxes_resize()')
    if is_absolute and (width_f is not None or height_f is not None):
        raise pxt.Error('bboxes_resize(): width/height require relative coordinates, but bboxes use absolute pixels')
    if not is_absolute and (width is not None or height is not None):
        raise pxt.Error(
            'bboxes_resize(): width/height require absolute pixel coordinates, but bboxes use relative coordinates'
        )
    arr = np.array(bboxes, dtype=np.float64)
    assert arr.ndim == 2 and arr.shape[1] == 4
    c0, c1, c2, c3 = arr[:, 0], arr[:, 1], arr[:, 2], arr[:, 3]

    # Convert to cx, cy, w, h
    w: np.ndarray
    h: np.ndarray
    cx: np.ndarray
    cy: np.ndarray
    if format == 'xyxy':
        w, h = c2 - c0, c3 - c1
        cx, cy = c0 + w / 2, c1 + h / 2
    elif format == 'xywh':
        w, h = c2, c3
        cx, cy = c0 + w / 2, c1 + h / 2
    elif format == 'cxcywh':
        cx, cy, w, h = c0, c1, c2, c3
    else:
        raise pxt.Error(f'Invalid format: {format!r}')

    valid = (w > 0) & (h > 0)
    orig: np.ndarray | None = None
    if not valid.all():
        # save original array for invalid boxes to pass through unchanged
        orig = arr.copy()
    # Replace invalid dimensions with 1.0 to avoid division by zero
    w = np.where(valid, w, 1.0)
    h = np.where(valid, h, 1.0)

    # Resolve the target width/height
    target_w = width if width is not None else width_f
    target_h = height if height is not None else height_f

    if target_w is not None:
        scale = target_w / w
        w = np.full_like(w, target_w)
        h *= scale
    elif target_h is not None:
        scale = target_h / h
        h = np.full_like(h, target_h)
        w *= scale
    else:
        current_aspect = w / h
        if aspect_mode == 'crop':
            # Reduce the oversized dimension
            too_wide = current_aspect > aspect
            new_w = np.where(too_wide, h * aspect, w)
            new_h = np.where(too_wide, h, w / aspect)
        else:  # pad
            # Extend the undersized dimension
            too_wide = current_aspect > aspect
            new_w = np.where(too_wide, w, h * aspect)
            new_h = np.where(too_wide, w / aspect, h)
        w, h = new_w, new_h

    # Convert back to original format.
    # For absolute coordinates, round w/h first, then derive positions from rounded
    # dimensions so that x2-x1==round(w) (xyxy) and x+w is consistent (xywh).
    if is_absolute:
        # don't use round() here, it rounds to the nearest even number
        w = np.floor(w + 0.5)
        h = np.floor(h + 0.5)

    if format == 'xyxy':
        if is_absolute:
            x1 = np.floor(cx - w / 2 + 0.5)
            y1 = np.floor(cy - h / 2 + 0.5)
            result = np.column_stack([x1, y1, x1 + w, y1 + h]).astype(int)
        else:
            result = np.column_stack([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2])
    elif format == 'xywh':
        if is_absolute:
            x1 = np.floor(cx - w / 2 + 0.5)
            y1 = np.floor(cy - h / 2 + 0.5)
            result = np.column_stack([x1, y1, w, h]).astype(int)
        else:
            result = np.column_stack([cx - w / 2, cy - h / 2, w, h])
    else:  # cxcywh
        result = np.column_stack([cx, cy, w, h])
        if is_absolute:
            result = np.floor(result + 0.5).astype(int)

    if not valid.all():
        # leave invalid boxes as-is
        result[~valid] = orig[~valid]
    return result.tolist()


@pxt.udf
def bboxes_scale(
    bboxes: list,
    format: Literal['xyxy', 'xywh', 'cxcywh'],
    *,
    factor: float | None = None,
    x_factor: float | None = None,
    y_factor: float | None = None,
) -> list:
    """
    Re-scale a list of bounding boxes (center-anchored).

    Args:
        bboxes: List of bounding boxes, each either specified with absolute pixel coordinates or relative
            coordinates in [0, 1].
        format: Format of the bounding box coordinates, one of 'xyxy', 'xywh', 'cxcywh'.
        factor: Scale factor to apply to both box dimensions.
        x_factor: Scale factor to apply to the box width.
        y_factor: Scale factor to apply to the box height.

    Returns:
        List of scaled bounding boxes in the same format as the input.
    """
    raise NotImplementedError()


@pxt.udf
def bboxes_pad(
    bboxes: list,
    format: Literal['xyxy', 'xywh', 'cxcywh'],
    *,
    top: int | None = None,
    bottom: int | None = None,
    left: int | None = None,
    right: int | None = None,
    x: int | None = None,
    y: int | None = None,
) -> list:
    """
    Pad a list of bounding boxes.

    Args:
        bboxes: List of bounding boxes, each either specified with absolute pixel coordinates or relative
            coordinates in [0, 1].
        format: Format of the bounding box coordinates, one of 'xyxy', 'xywh', 'cxcywh'.
        top: Amount to pad at the top.
        bottom: Amount to pad at the bottom.
        left: Amount to pad at the left.
        right: Amount to pad at the right.
        x: Amount to pad at the left and right.
        y: Amount to pad at the top and bottom.

    Returns:
        List of padded bounding boxes in the same format as the input.
    """
    raise NotImplementedError()


@pxt.udf
def bboxes_clip_to_canvas(
    bboxes: list,
    format: Literal['xyxy', 'xywh', 'cxcywh'],
    *,
    width: int | None = None,
    height: int | None = None,
    min_visibility: float = 0.0,
    min_area: float = 0.0,
) -> list:
    """
    Clip a list of bounding boxes to a canvas of specified size.

    Args:
        bboxes: List of bounding boxes, each either specified with absolute pixel coordinates or relative
            coordinates in [0, 1].
        format: Format of the bounding box coordinates, one of 'xyxy', 'xywh', 'cxcywh'.
        width: Canvas width in absolute pixels.
        height: Canvas height in absolute pixels.
        min_visibility: Minimum fraction of the bounding box that must be visible after clipping. If the visibility
            is less than this value, returns None.
        min_area: Minimum area of the bounding box after clipping. If the area is less than this value, returns None.

    Returns:
        List of clipped bounding boxes in the same format as the input.
    """
    raise NotImplementedError()


@pxt.udf
def bboxes_crop_canvas(
    bboxes: list,
    format: Literal['xyxy', 'xywh', 'cxcywh'],
    *,
    canvas_region: list,
    canvas_region_format: Literal['xyxy', 'xywh', 'cxcywh'],
    canvas_width: int | None = None,
    canvas_height: int | None = None,
) -> list:
    """
    Adjust a list of bounding boxes to account for a canvas crop.

    Args:
        bboxes: List of bounding boxes, each either specified with absolute pixel coordinates or relative
            coordinates in [0, 1].
        format: Format of the bounding box coordinates, one of 'xyxy', 'xywh', 'cxcywh'.
        canvas_width: Canvas width.
        canvas_height: Canvas height.
        canvas_region: Canvas region that was cropped, either specified with absolute pixel coordinates or relative
            coordinates, in the format specified by `canvas_region_format`.
        canvas_region_format: Format of the `canvas_region` coordinates, one of 'xyxy', 'xywh', 'cxcywh'.

    Returns:
        List of adjusted bounding boxes in the same format as the input. They can extend beyond the canvas boundaries.
    """
    raise NotImplementedError()


@pxt.udf
def bboxes_resize_canvas(
    bboxes: list,
    format: Literal['xyxy', 'xywh', 'cxcywh'],
    *,
    new_canvas_width: int | None = None,
    new_canvas_height: int | None = None,
    canvas_scale: float | None = None,
    canvas_scale_x: float | None = None,
    canvas_scale_y: float | None = None,
    canvas_width: int | None = None,
    canvas_height: int | None = None,
) -> list:
    """
    Adjust a list of bounding boxes to account for a canvas resize. The resize operation can be expressed

    - as absolute pixel dimensions (new_canvas_width, new_canvas_height)
    - as relative dimensions (canvas_scale, canvas_scale_x, canvas_scale_y)

    Args:
        bboxes: List of bounding boxes, each either specified with absolute pixel coordinates or relative
            coordinates in [0, 1].
        format: Format of the bounding box coordinates, one of 'xyxy', 'xywh', 'cxcywh'.
        new_canvas_width: New canvas width in absolute pixels. Requires canvas_width/canvas_height to be specified.
        new_canvas_height: New canvas height in absolute pixels. Requires canvas_width/canvas_height to be specified.
        canvas_scale: Scale factor to apply to both canvas dimensions.
        canvas_scale_x: Scale factor to apply to the canvas width.
        canvas_scale_y: Scale factor to apply to the canvas height.
        canvas_width: Original canvas width in absolute pixels.
        canvas_height: Original canvas height in absolute pixels.

    Returns:
        List of adjusted bounding boxes in the same format as the input.
    """
    raise NotImplementedError()


def _get_contours(mask: np.ndarray, thickness: int = 1) -> np.ndarray:
    """Get contour mask with specified thickness."""
    assert mask.dtype == bool
    # find interior pixels: those with all 8 neighbors in the mask (8: include diagonals)
    padded = np.pad(mask, 1, mode='constant', constant_values=False)
    interior = (
        padded[1:-1, 1:-1]
        & padded[:-2, 1:-1]
        & padded[2:, 1:-1]
        & padded[1:-1, :-2]
        & padded[1:-1, 2:]
        & padded[:-2, :-2]
        & padded[:-2, 2:]
        & padded[2:, :-2]
        & padded[2:, 2:]
    )
    boundaries = mask & ~interior

    for _ in range(thickness - 1):
        # binary dilation to all 8 neighbors
        padded = np.pad(boundaries, 1, mode='constant', constant_values=False)
        boundaries = (
            padded[1:-1, 1:-1]
            | padded[:-2, 1:-1]
            | padded[2:, 1:-1]
            | padded[1:-1, :-2]
            | padded[1:-1, 2:]
            | padded[:-2, :-2]
            | padded[:-2, 2:]
            | padded[2:, :-2]
            | padded[2:, 2:]
        )

    return boundaries


@pxt.udf
def overlay_segmentation(
    img: PIL.Image.Image,
    segmentation: pxt.Array[(None, None), np.int32],
    *,
    alpha: float = 0.5,
    background: int = 0,
    segment_colors: list[str] | None = None,
    draw_contours: bool = True,
    contour_thickness: int = 1,
) -> PIL.Image.Image:
    """
    Overlays a colored segmentation map on an image.

    Colors can be specified as common HTML color names (e.g., 'red') supported by PIL's
    [`ImageColor`](https://pillow.readthedocs.io/en/stable/reference/ImageColor.html#imagecolor-module) module or as
    RGB hex codes (e.g., '#FF0000').

    If no colors are specified, this function randomly assigns each segment a specific color based on a hash of its id.

    Args:
        img: Input image.
        segmentation: 2D array of the same shape as `img` where each pixel value is a segment id.
        alpha: Blend factor for the overlay (0.0 = only original image, 1.0 = only segmentation colors).
        background: Segment id to treat as background (not overlaid with color, showing the original
            image through).
        segment_colors: List of colors, one per segment id. If the list is shorter than the number of segments, the
            remaining segments will be assigned colors automatically.
        draw_contours: If True, draw contours around each segment with full opacity.
        contour_thickness: Thickness of the contour lines in pixels.

    Returns:
        The image with the colored segmentation overlay.
    """

    if segmentation.shape != (img.height, img.width):
        raise ValueError(
            f'Segmentation shape {segmentation.shape} does not match image dimensions ({img.height}, {img.width})'
        )
    segment_ids = sorted(int(sid) for sid in np.unique(segmentation) if sid != background)
    if segment_colors is None:
        segment_colors = []
    missing_ids = segment_ids[len(segment_colors) :]
    auto_colors = __create_label_colors(missing_ids)
    color_map = {**auto_colors, **dict(zip(segment_ids, segment_colors))}

    segment_alpha = int(alpha * 255)

    overlay_array = np.zeros((img.height, img.width, 4), dtype=np.uint8)
    segment_colors = {id: PIL.ImageColor.getrgb(color_map[id]) for id in segment_ids}
    for segment_id in segment_ids:
        rgb = segment_colors[segment_id]
        mask = segmentation == segment_id
        overlay_array[mask] = (*rgb, segment_alpha)
        if draw_contours:
            contour_mask = _get_contours(mask, contour_thickness)
            overlay_array[contour_mask] = (*rgb, 255)

    overlay = PIL.Image.fromarray(overlay_array, mode='RGBA')
    img_rgba = img.convert('RGBA')
    result = PIL.Image.alpha_composite(img_rgba, overlay)
    return result.convert('RGB')


__all__ = local_public_names(__name__)


def __dir__() -> list[str]:
    return __all__
