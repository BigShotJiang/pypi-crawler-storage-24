"""
+==============================================================+
|          AGENTE LOCAL DE AUTOMAÇÃO DESKTOP                   |
|          UI Automation API + Grok xAI                        |
|          Comando principal: seu-agente                       |
+==============================================================+

Comandos disponíveis:
  seu-agente start          → Inicia o agente em background
  seu-agente stop           → Para o agente
  seu-agente status         → Mostra o status atual
  seu-agente config         → Configura URL do servidor e chave API
  seu-agente logs           → Mostra os logs em tempo real
  seu-agente scan           → Escaneia e mostra os apps instalados
  seu-agente restart        → Reinicia o agente
"""

import typer
import asyncio
import websockets
import json
import os
import sys
import time
import signal
import threading
import subprocess
import platform
from pathlib import Path
from typing import Optional
from loguru import logger

# Corrige encoding no terminal Windows (evita erro com emojis/unicode)
if sys.platform == "win32":
    import io
    if hasattr(sys.stdout, "buffer"):
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "buffer"):
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")

# ─────────────────────────────────────────────
# IMPORTS CONDICIONAIS (apenas Windows)
# ─────────────────────────────────────────────
IS_WINDOWS = platform.system() == "Windows"

if IS_WINDOWS:
    import psutil
    import winreg
    import uiautomation as auto
    import pywinauto
    import pyautogui
    import mss
    from PIL import Image
else:
    print("[AVISO]  AVISO: Este agente foi projetado para Windows 10/11.")
    print("    Algumas funcionalidades não estarão disponíveis nesta plataforma.")

# ─────────────────────────────────────────────
# CONFIGURAÇÃO DE PATHS E ARQUIVOS
# ─────────────────────────────────────────────
APP_DIR     = Path.home() / ".seu-agente"        # ~/.seu-agente/
CONFIG_FILE = APP_DIR / "config.json"             # configurações
PID_FILE    = APP_DIR / "agent.pid"               # PID do processo
LOG_FILE    = APP_DIR / "agent.log"               # arquivo de log

# Garantir que a pasta existe
APP_DIR.mkdir(parents=True, exist_ok=True)

# ─────────────────────────────────────────────
# CONFIGURAÇÃO DO LOGGER
# ─────────────────────────────────────────────
logger.remove()
logger.add(
    LOG_FILE,
    rotation="5 MB",
    retention="7 days",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level:<8} | {message}",
    level="DEBUG"
)
logger.add(
    sys.stderr,
    format="<green>{time:HH:mm:ss}</green> | <level>{level:<8}</level> | {message}",
    level="INFO"
)

# ─────────────────────────────────────────────
# CLI — PONTO DE ENTRADA
# ─────────────────────────────────────────────
app = typer.Typer(
    name="ad06-agent",
    help="Ad06 Agent -- Agente de automacao desktop (UI Automation + Grok xAI)",
    add_completion=False,
    rich_markup_mode=None,
    pretty_exceptions_enable=False,
)


# ==============================================
# UTILITÁRIOS
# ==============================================

def carregar_config() -> dict:
    """Lê o arquivo de configuração."""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    return {
        "server_url": "",
        "api_key": "",
        "porta_local": 8765,
        "autostart": False,
        "log_level": "INFO"
    }


def salvar_config(config: dict):
    """Salva o arquivo de configuração."""
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)


def ler_pid() -> Optional[int]:
    """Lê o PID do agente salvo em arquivo."""
    if PID_FILE.exists():
        try:
            return int(PID_FILE.read_text().strip())
        except:
            return None
    return None


def salvar_pid(pid: int):
    """Salva o PID do processo do agente."""
    PID_FILE.write_text(str(pid))


def remover_pid():
    """Remove o arquivo de PID."""
    if PID_FILE.exists():
        PID_FILE.unlink()


def agente_esta_rodando() -> bool:
    """Verifica se o agente está em execução."""
    if not IS_WINDOWS:
        return False
    pid = ler_pid()
    if pid is None:
        return False
    try:
        proc = psutil.Process(pid)
        return proc.is_running() and proc.status() != psutil.STATUS_ZOMBIE
    except psutil.NoSuchProcess:
        remover_pid()
        return False


def configuracao_valida(config: dict) -> bool:
    """Verifica se a configuração mínima está presente."""
    return bool(config.get("server_url"))


# ==============================================
# MAPEAMENTO DO AMBIENTE
# ==============================================

def mapear_apps_instalados() -> list:
    """Escaneia o registro do Windows e retorna apps instalados."""
    if not IS_WINDOWS:
        return []

    apps = []
    chaves = [
        r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
        r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
    ]

    for chave_path in chaves:
        try:
            chave = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, chave_path)
            total = winreg.QueryInfoKey(chave)[0]
            for i in range(total):
                try:
                    sub_nome = winreg.EnumKey(chave, i)
                    sub = winreg.OpenKey(chave, sub_nome)
                    nome, _ = winreg.QueryValueEx(sub, "DisplayName")
                    try:
                        path, _ = winreg.QueryValueEx(sub, "InstallLocation")
                    except:
                        path = ""
                    apps.append({"nome": nome, "path": path})
                except:
                    continue
        except:
            continue

    return apps


def mapear_processos() -> list:
    """Lista todos os processos em execução."""
    if not IS_WINDOWS:
        return []

    processos = []
    for p in psutil.process_iter(["pid", "name", "exe", "status"]):
        try:
            processos.append({
                "pid":    p.info["pid"],
                "nome":   p.info["name"],
                "exe":    p.info["exe"] or "",
                "status": p.info["status"]
            })
        except:
            continue
    return processos


def mapear_janelas() -> list:
    """Lista todas as janelas abertas com seus elementos de acessibilidade."""
    if not IS_WINDOWS:
        return []

    janelas = []
    try:
        for janela in auto.GetRootControl().GetChildren():
            try:
                rect = janela.BoundingRectangle
                janelas.append({
                    "nome":    janela.Name,
                    "tipo":    janela.ControlTypeName,
                    "classe":  janela.ClassName,
                    "pid":     janela.ProcessId,
                    "rect": {
                        "x":      rect.left,
                        "y":      rect.top,
                        "largura": rect.width(),
                        "altura":  rect.height()
                    }
                })
            except:
                continue
    except Exception as e:
        logger.warning(f"Erro ao mapear janelas: {e}")

    return janelas


def mapear_tela() -> dict:
    """Retorna informações da resolução e monitores."""
    if not IS_WINDOWS:
        return {}

    import ctypes
    user32 = ctypes.windll.user32
    return {
        "largura": user32.GetSystemMetrics(0),
        "altura":  user32.GetSystemMetrics(1),
        "dpi":     user32.GetDpiForSystem(),
        "monitores": len(psutil.disk_partitions())
    }


def mapear_ambiente_completo() -> dict:
    """Monta o mapa completo do ambiente do computador."""
    logger.info("Iniciando mapeamento completo do ambiente...")

    ambiente = {
        "sistema": {
            "os":           platform.system(),
            "versao":       platform.version(),
            "arquitetura":  platform.architecture()[0],
            "hostname":     platform.node(),
            "python":       platform.python_version()
        },
        "tela":              mapear_tela(),
        "apps_instalados":   mapear_apps_instalados(),
        "processos":         mapear_processos(),
        "janelas_abertas":   mapear_janelas(),
        "timestamp":         time.strftime("%Y-%m-%d %H:%M:%S")
    }

    logger.info(
        f"Mapeamento concluído — "
        f"{len(ambiente['apps_instalados'])} apps | "
        f"{len(ambiente['processos'])} processos | "
        f"{len(ambiente['janelas_abertas'])} janelas"
    )
    return ambiente


# ==============================================
# MOTOR DE EXECUÇÃO — UI AUTOMATION API
# ==============================================

class MotorExecucao:
    """Motor híbrido: UI Automation como principal, visão como fallback."""

    def abrir_aplicativo(self, app: str) -> dict:
        """Abre um aplicativo pelo nome ou caminho."""
        if not IS_WINDOWS:
            return {"status": "erro", "detalhe": "Requer Windows"}

        # Verificar se já está rodando
        for proc in psutil.process_iter(["name"]):
            try:
                if app.lower().replace(".exe", "") in proc.info["name"].lower():
                    logger.info(f"App '{app}' já está em execução")
                    return {"status": "ja_aberto", "app": app}
            except:
                continue

        # Abrir o app
        try:
            subprocess.Popen(app, shell=True)
            time.sleep(2)
            logger.success(f"App '{app}' aberto com sucesso")
            return {"status": "ok", "app": app}
        except Exception as e:
            logger.error(f"Erro ao abrir '{app}': {e}")
            return {"status": "erro", "detalhe": str(e)}

    def executar_acao(self, janela_nome: str, acao: dict) -> dict:
        """
        Executa ação via UI Automation API.
        Se falhar, sinaliza para usar fallback visual.
        """
        if not IS_WINDOWS:
            return {"status": "erro", "detalhe": "Requer Windows"}

        try:
            # Encontrar a janela
            janela = auto.WindowControl(Name=janela_nome, searchDepth=1)
            if not janela.Exists(maxSearchSeconds=5):
                return {"status": "janela_nao_encontrada", "janela": janela_nome}

            tipo = acao.get("tipo")
            logger.debug(f"Executando '{tipo}' na janela '{janela_nome}'")

            # ── Clicar em botão
            if tipo == "clicar_botao":
                btn = janela.ButtonControl(Name=acao["elemento"])
                if not btn.Exists(maxSearchSeconds=3):
                    return {"status": "elemento_nao_encontrado", "elemento": acao["elemento"]}
                btn.Click()
                logger.success(f"Clique em botão '{acao['elemento']}' — OK")
                return {"status": "ok", "acao": tipo, "elemento": acao["elemento"]}

            # ── Digitar texto
            elif tipo == "digitar_texto":
                campo = janela.EditControl(Name=acao.get("elemento", ""))
                campo.Click()
                campo.SetValue(acao["texto"])
                logger.success(f"Texto digitado — OK")
                return {"status": "ok", "acao": tipo}

            # ── Navegar em menu
            elif tipo == "clicar_menu":
                menu = janela.MenuControl(Name=acao["menu"])
                menu.Click()
                time.sleep(0.4)
                item = janela.MenuItemControl(Name=acao["item"])
                item.Click()
                logger.success(f"Menu '{acao['menu']} > {acao['item']}' — OK")
                return {"status": "ok", "acao": tipo}

            # ── Selecionar item de lista
            elif tipo == "selecionar_lista":
                lista = janela.ListControl(Name=acao.get("elemento", ""))
                item = lista.ListItemControl(Name=acao["valor"])
                item.Click()
                logger.success(f"Item '{acao['valor']}' selecionado — OK")
                return {"status": "ok", "acao": tipo}

            # ── Pressionar tecla
            elif tipo == "pressionar_tecla":
                janela.SendKeys(acao["tecla"])
                logger.success(f"Tecla '{acao['tecla']}' pressionada — OK")
                return {"status": "ok", "acao": tipo}

            # ── Verificar se elemento existe
            elif tipo == "verificar_elemento":
                el = janela.Control(Name=acao["elemento"])
                existe = el.Exists(maxSearchSeconds=3)
                return {"status": "ok", "existe": existe, "elemento": acao["elemento"]}

            else:
                return {"status": "tipo_desconhecido", "tipo": tipo}

        except Exception as e:
            logger.warning(f"UI Automation falhou: {e} — Acionando fallback visual")
            return {
                "status": "falha_ui_automation",
                "erro": str(e),
                "requer_visao": True
            }

    def capturar_tela(self) -> str:
        """Captura screenshot e retorna em base64."""
        if not IS_WINDOWS:
            return ""

        import base64
        import io

        with mss.mss() as sct:
            shot = sct.grab(sct.monitors[1])
            img = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            encoded = base64.b64encode(buf.getvalue()).decode()
            logger.debug("Screenshot capturada")
            return encoded

    def fallback_visual(self, x: int, y: int, acao: str = "clicar") -> dict:
        """Fallback por coordenadas quando UI Automation falha."""
        if not IS_WINDOWS:
            return {"status": "erro", "detalhe": "Requer Windows"}

        try:
            if acao == "clicar":
                pyautogui.moveTo(x, y, duration=0.3)
                pyautogui.click()
                logger.success(f"Clique visual em ({x}, {y}) — OK")
                return {"status": "ok", "acao": "clique_visual", "coords": [x, y]}

            elif acao == "duplo_clique":
                pyautogui.doubleClick(x, y)
                return {"status": "ok", "acao": "duplo_clique_visual"}

            elif acao == "clicar_direito":
                pyautogui.rightClick(x, y)
                return {"status": "ok", "acao": "clique_direito_visual"}

        except Exception as e:
            logger.error(f"Fallback visual falhou: {e}")
            return {"status": "falha_total", "erro": str(e)}


# ==============================================
# WEBSOCKET — BRIDGE COM O SERVIDOR
# ==============================================

motor = MotorExecucao()


async def websocket_handler(websocket):
    """Gerencia a conexão WebSocket com o servidor."""
    logger.info(f"Servidor conectado: {websocket.remote_address}")

    # Enviar mapa do ambiente ao conectar
    try:
        ambiente = mapear_ambiente_completo()
        await websocket.send(json.dumps({
            "tipo":  "ambiente",
            "dados": ambiente
        }))
        logger.info("Mapa do ambiente enviado ao servidor")
    except Exception as e:
        logger.error(f"Erro ao enviar ambiente: {e}")

    # Loop de recebimento de comandos
    try:
        async for mensagem in websocket:
            try:
                cmd = json.loads(mensagem)
                tipo = cmd.get("tipo")
                logger.info(f"Comando recebido: {tipo}")

                # ── Abrir aplicativo
                if tipo == "abrir_app":
                    resultado = motor.abrir_aplicativo(cmd.get("app", ""))

                # ── Executar ação via UI Automation
                elif tipo == "executar_acao":
                    resultado = motor.executar_acao(
                        cmd.get("janela", ""),
                        cmd.get("acao", {})
                    )
                    # Se falhou → capturar tela para o Grok analisar
                    if resultado.get("requer_visao"):
                        resultado["screenshot"] = motor.capturar_tela()

                # ── Capturar tela sob demanda
                elif tipo == "capturar_tela":
                    resultado = {
                        "tipo":    "screenshot",
                        "imagem":  motor.capturar_tela()
                    }

                # ── Re-escanear ambiente
                elif tipo == "mapear_ambiente":
                    resultado = {
                        "tipo":  "ambiente",
                        "dados": mapear_ambiente_completo()
                    }

                # ── Fallback visual com coordenadas do Grok
                elif tipo == "fallback_visual":
                    resultado = motor.fallback_visual(
                        cmd.get("x", 0),
                        cmd.get("y", 0),
                        cmd.get("acao_visual", "clicar")
                    )

                # ── Ping de keepalive
                elif tipo == "ping":
                    resultado = {"tipo": "pong", "ts": time.time()}

                else:
                    resultado = {"status": "tipo_desconhecido", "tipo": tipo}

                await websocket.send(json.dumps(resultado))

            except json.JSONDecodeError as e:
                logger.error(f"JSON inválido recebido: {e}")
                await websocket.send(json.dumps({
                    "status": "erro",
                    "detalhe": "JSON inválido"
                }))

    except websockets.exceptions.ConnectionClosed:
        logger.warning("Conexão com o servidor encerrada")
    except Exception as e:
        logger.error(f"Erro no handler WebSocket: {e}")


async def iniciar_websocket(porta: int, server_url: str):
    """Inicia o servidor WebSocket local."""
    logger.info(f"Agente WebSocket iniciando na porta {porta}...")

    async with websockets.serve(websocket_handler, "localhost", porta):
        logger.success(f"[OK] Agente ativo em ws://localhost:{porta}")
        logger.success(f"[OK] Conectado ao servidor: {server_url}")
        await asyncio.Future()  # roda para sempre


def _run_agent(config: dict):
    """Roda o agente em thread separada."""
    asyncio.run(iniciar_websocket(
        config.get("porta_local", 8765),
        config.get("server_url", "")
    ))


# ==============================================
# REGISTRO NO STARTUP DO WINDOWS
# ==============================================

def registrar_startup():
    """Registra o agente para iniciar automaticamente com o Windows."""
    if not IS_WINDOWS:
        return
    try:
        chave = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0,
            winreg.KEY_SET_VALUE
        )
        caminho_exe = sys.executable
        winreg.SetValueEx(chave, "SeuAgenteDesktop", 0, winreg.REG_SZ,
                          f'"{caminho_exe}" -m seu_agente.main start')
        logger.info("Agente registrado no startup do Windows")
    except Exception as e:
        logger.warning(f"Não foi possível registrar no startup: {e}")


def remover_startup():
    """Remove o agente do startup do Windows."""
    if not IS_WINDOWS:
        return
    try:
        chave = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0,
            winreg.KEY_SET_VALUE
        )
        winreg.DeleteValue(chave, "SeuAgenteDesktop")
        logger.info("Agente removido do startup do Windows")
    except:
        pass


# ==============================================
# COMANDOS CLI
# ==============================================

@app.command()
def start(
    background: bool = typer.Option(False, "--background", "-b",
                                    help="Iniciar em background (modo silencioso)"),
    autostart:  bool = typer.Option(False, "--autostart", "-a",
                                    help="Iniciar automaticamente com o Windows")
):
    """
    >  Inicia o agente de automação desktop.
    """
    typer.echo("\n[AGENTE] Agente de Automação Desktop — UI Automation API + Grok xAI")
    typer.echo("-" * 60)

    # Verificar se já está rodando
    if agente_esta_rodando():
        typer.echo("[AVISO]  O agente já está em execução.")
        typer.echo(f"   PID: {ler_pid()}")
        typer.echo("   Use 'seu-agente status' para mais detalhes.\n")
        raise typer.Exit(1)

    # Verificar configuração
    config = carregar_config()
    if not configuracao_valida(config):
        typer.echo("[ERRO] Configuração incompleta!")
        typer.echo("   Execute primeiro: seu-agente config --url https://seusite.com\n")
        raise typer.Exit(1)

    # Verificar Windows
    if not IS_WINDOWS:
        typer.echo("[ERRO] Este agente requer Windows 10 ou Windows 11.")
        raise typer.Exit(1)

    typer.echo(f"   Servidor: {config['server_url']}")
    typer.echo(f"   Porta local: {config.get('porta_local', 8765)}")
    typer.echo(f"   Log: {LOG_FILE}")

    # Registrar startup se solicitado
    if autostart:
        registrar_startup()
        typer.echo("   [OK] Registrado no startup do Windows")

    # Salvar PID
    salvar_pid(os.getpid())

    typer.echo("\n[OK] Agente iniciado com sucesso!")
    typer.echo("   Pressione Ctrl+C para parar.\n")

    # Handler para Ctrl+C
    def ao_encerrar(sig, frame):
        typer.echo("\n[STOP] Encerrando agente...")
        remover_pid()
        logger.info("Agente encerrado pelo usuário")
        sys.exit(0)

    signal.signal(signal.SIGINT, ao_encerrar)
    if IS_WINDOWS:
        signal.signal(signal.SIGTERM, ao_encerrar)

    # Iniciar WebSocket
    logger.info("="*50)
    logger.info("AGENTE INICIADO")
    logger.info("="*50)

    try:
        _run_agent(config)
    except Exception as e:
        logger.error(f"Erro fatal: {e}")
        remover_pid()
        raise


@app.command()
def stop():
    """
    [STOP]  Para o agente em execução.
    """
    typer.echo("\n[STOP]  Parando o agente...")

    if not agente_esta_rodando():
        typer.echo("[AVISO]  O agente não está em execução.\n")
        raise typer.Exit(0)

    pid = ler_pid()
    try:
        proc = psutil.Process(pid)
        proc.terminate()
        proc.wait(timeout=5)
        remover_pid()
        remover_startup()
        typer.echo(f"[OK] Agente parado com sucesso (PID: {pid})\n")
        logger.info(f"Agente encerrado via comando stop (PID: {pid})")
    except psutil.TimeoutExpired:
        proc.kill()
        remover_pid()
        typer.echo("[OK] Agente forçado a parar.\n")
    except Exception as e:
        typer.echo(f"[ERRO] Erro ao parar o agente: {e}\n")
        remover_pid()


@app.command()
def restart():
    """
    [RELOAD]  Reinicia o agente.
    """
    typer.echo("\n[RELOAD] Reiniciando o agente...")
    stop()
    time.sleep(1)
    start()


@app.command()
def status():
    """
    [STATUS]  Mostra o status atual do agente.
    """
    typer.echo("\n[STATUS] Status do Agente de Automação")
    typer.echo("-" * 45)

    config = carregar_config()
    rodando = agente_esta_rodando()

    # Status geral
    if rodando:
        pid = ler_pid()
        typer.echo(f"  Status     : [OK] RODANDO (PID: {pid})")
        if IS_WINDOWS:
            try:
                proc = psutil.Process(pid)
                mem = proc.memory_info().rss / 1024 / 1024
                cpu = proc.cpu_percent(interval=0.5)
                typer.echo(f"  CPU        : {cpu:.1f}%")
                typer.echo(f"  Memória    : {mem:.1f} MB")
                typer.echo(f"  Iniciado   : {time.strftime('%H:%M:%S', time.localtime(proc.create_time()))}")
            except:
                pass
    else:
        typer.echo(f"  Status     : [STOP] PARADO")

    # Configuração
    typer.echo(f"\n  Servidor   : {config.get('server_url') or '[AVISO]  não configurado'}")
    typer.echo(f"  Porta local: {config.get('porta_local', 8765)}")
    typer.echo(f"  Log level  : {config.get('log_level', 'INFO')}")

    # Sistema
    typer.echo(f"\n  OS         : {platform.system()} {platform.version()[:20]}")
    typer.echo(f"  Python     : {platform.python_version()}")
    typer.echo(f"  Config     : {CONFIG_FILE}")
    typer.echo(f"  Log        : {LOG_FILE}")

    # Ambiente (se rodando)
    if rodando and IS_WINDOWS:
        try:
            n_processos = len(list(psutil.process_iter()))
            n_janelas   = len(auto.GetRootControl().GetChildren())
            typer.echo(f"\n  Processos  : {n_processos}")
            typer.echo(f"  Janelas    : {n_janelas}")
        except:
            pass

    typer.echo("")


@app.command()
def config(
    url:    Optional[str] = typer.Option(None, "--url",    "-u", help="URL do servidor (ex: https://seusite.com)"),
    key:    Optional[str] = typer.Option(None, "--key",    "-k", help="Chave API do servidor"),
    porta:  Optional[int] = typer.Option(None, "--porta",  "-p", help="Porta local do WebSocket (padrão: 8765)"),
    nivel:  Optional[str] = typer.Option(None, "--nivel",  "-n", help="Nível de log: DEBUG, INFO, WARNING"),
    reset:  bool          = typer.Option(False, "--reset",        help="Resetar todas as configurações"),
    mostrar:bool          = typer.Option(False, "--mostrar",      help="Mostrar configuração atual")
):
    """
    [CONFIG]  Configura o agente (URL do servidor, chave API, porta local).
    """
    cfg = carregar_config()

    if reset:
        cfg = {
            "server_url":   "",
            "api_key":      "",
            "porta_local":  8765,
            "autostart":    False,
            "log_level":    "INFO"
        }
        salvar_config(cfg)
        typer.echo("[OK] Configurações resetadas para o padrão.\n")
        return

    if mostrar:
        typer.echo("\n[CONFIG]  Configuração atual:")
        typer.echo("-" * 40)
        typer.echo(f"  URL servidor : {cfg.get('server_url') or '(não definida)'}")
        chave = cfg.get("api_key", "")
        typer.echo(f"  API Key      : {'*' * len(chave) if chave else '(não definida)'}")
        typer.echo(f"  Porta local  : {cfg.get('porta_local', 8765)}")
        typer.echo(f"  Log level    : {cfg.get('log_level', 'INFO')}")
        typer.echo(f"  Autostart    : {'Sim' if cfg.get('autostart') else 'Não'}\n")
        return

    # Aplicar mudanças
    alterado = False

    if url:
        cfg["server_url"] = url.rstrip("/")
        typer.echo(f"[OK] URL do servidor: {url}")
        alterado = True

    if key:
        cfg["api_key"] = key
        typer.echo("[OK] Chave API configurada")
        alterado = True

    if porta:
        cfg["porta_local"] = porta
        typer.echo(f"[OK] Porta local: {porta}")
        alterado = True

    if nivel:
        nivel = nivel.upper()
        if nivel in ["DEBUG", "INFO", "WARNING", "ERROR"]:
            cfg["log_level"] = nivel
            typer.echo(f"[OK] Log level: {nivel}")
            alterado = True
        else:
            typer.echo("[ERRO] Nível inválido. Use: DEBUG, INFO, WARNING ou ERROR")

    if alterado:
        salvar_config(cfg)
        typer.echo(f"\n[SAVE] Configurações salvas em: {CONFIG_FILE}\n")
    else:
        typer.echo("[INFO]  Nenhuma configuração alterada.")
        typer.echo("   Use --mostrar para ver a configuração atual.")
        typer.echo("   Use --help para ver as opções disponíveis.\n")


@app.command()
def logs(
    linhas: int  = typer.Option(50,    "--linhas",  "-n", help="Número de linhas a mostrar"),
    seguir: bool = typer.Option(False, "--seguir",  "-f", help="Seguir log em tempo real (como tail -f)")
):
    """
    [LOG]  Mostra os logs do agente.
    """
    if not LOG_FILE.exists():
        typer.echo("[AVISO]  Nenhum log encontrado ainda.\n")
        raise typer.Exit(0)

    if seguir:
        typer.echo(f"[LOG] Seguindo logs em tempo real (Ctrl+C para sair)...\n")
        try:
            with open(LOG_FILE, "r", encoding="utf-8") as f:
                f.seek(0, 2)  # ir para o final
                while True:
                    linha = f.readline()
                    if linha:
                        typer.echo(linha, nl=False)
                    else:
                        time.sleep(0.3)
        except KeyboardInterrupt:
            typer.echo("\n")
    else:
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            todas = f.readlines()
        ultimas = todas[-linhas:]
        typer.echo(f"\n[LOG] Últimas {len(ultimas)} linhas do log:\n")
        typer.echo("-" * 60)
        for linha in ultimas:
            typer.echo(linha, nl=False)
        typer.echo("-" * 60 + "\n")


@app.command()
def scan(
    salvar: bool = typer.Option(False, "--salvar", "-s",
                                help="Salvar resultado em ambiente.json")
):
    """
    [SCAN]  Escaneia o computador e mostra apps, processos e janelas abertas.
    """
    typer.echo("\n[SCAN] Escaneando ambiente do computador...")
    typer.echo("-" * 50)

    if not IS_WINDOWS:
        typer.echo("[ERRO] Requer Windows 10 ou 11.\n")
        raise typer.Exit(1)

    ambiente = mapear_ambiente_completo()

    typer.echo(f"\n[APPS] Apps instalados    : {len(ambiente['apps_instalados'])}")
    typer.echo(f"[CONFIG]  Processos rodando  : {len(ambiente['processos'])}")
    typer.echo(f"🪟 Janelas abertas    : {len(ambiente['janelas_abertas'])}")

    tela = ambiente.get("tela", {})
    typer.echo(f"[TELA]  Resolução          : {tela.get('largura')}x{tela.get('altura')} @ {tela.get('dpi')} DPI")

    # Mostrar janelas abertas
    typer.echo("\n🪟 Janelas abertas agora:")
    for j in ambiente["janelas_abertas"]:
        if j["nome"]:
            typer.echo(f"   • {j['nome']} [{j['classe']}]")

    if salvar:
        saida = APP_DIR / "ambiente.json"
        with open(saida, "w", encoding="utf-8") as f:
            json.dump(ambiente, f, ensure_ascii=False, indent=2)
        typer.echo(f"\n[SAVE] Resultado salvo em: {saida}")

    typer.echo("")


# ==============================================
# ENTRY POINT
# ==============================================

def cli():
    """Entry point registrado no setup.py."""
    app()


if __name__ == "__main__":
    cli()
