# Ad06 Agent — Agente de Automacao Desktop
__version__ = "1.0.1"
__author__  = "Adielson Sousa"