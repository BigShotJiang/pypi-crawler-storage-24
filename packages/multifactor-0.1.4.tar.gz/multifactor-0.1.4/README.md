# MultiFactor
`MultiFactor`는 멀티팩터 전략을 구현하고 분석할 수 있도록 돕는 파이썬 라이브러리입니다.

## 주요 기능
* FinanceDataReader 기반의 빠르고 안정적인 금융 데이터 수집
* 사용자 맞춤형 팩터(가치, 모멘텀, 퀄리티 등) 점수 산출
* 직관적인 데이터프레임(DataFrame) 형태의 결과물 반환

## 설치 방법
```bash
pip install MultiFactor
```

### 테스트 코드 

#### 1. 패키지 불러오기
from MultiFactor import MultiFactor

# 2. 객체 생성 (시가총액 상위 5개 종목)
mf = MultiFactor(N=5)

# 3. 종목 코드 생성
df = mf.get_stockinfo()  # 데이터프레임 
stock_list = mf.get_stockinfo(dtype='dic')  # 딕셔너리 

# 4. 데이터 수집 및 점수 계산 실행
data_mast = mf.get_score()

# 5. 가중치 부여하기 (기본값: '균등')
data_mast_weighted = mf.get_score_adj_weight(data_mast, weight='가치성장')

# 4. 종합 순위에 따라 N개의 그룹으로 나누어 종목명 출력
mf.get_Ngroup(data_mast, Ngroup=2)

# 5. 지표별로 데이터 수집 후 종합점수 산정
data_mom = mf.get_momentum(stock_list) 
data_val = mf.get_value(stock_list)    
data_fin = mf.get_quality(stock_list) 
data_mast = mf.get_score_by_data(data_mom, data_val, data_fin)

# 6. 종목 1개 팩터 수집  (삼성전자) 
mf.get_momentum_one('005930')
mf.get_value_one('005930')   
mf.get_quality_one('005930')