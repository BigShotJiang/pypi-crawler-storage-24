from __future__ import annotations

from pathlib import Path

import pytest
from dbetto import AttrsDict

from legendsimflow import aggregate as agg
from legendsimflow.exceptions import SimflowConfigError


def test_simid_aggregates(fresh_config):
    config = fresh_config
    assert agg.get_simid_njobs(config, "birds_nest_K40") == 2

    val = agg.gen_list_of_simid_inputs(config, "stp", "birds_nest_K40")
    assert isinstance(val, list)
    assert len(val) == 1

    val = agg.gen_list_of_simid_outputs(config, "stp", "birds_nest_K40")
    assert isinstance(val, list)
    assert len(val) == 2

    val = agg.gen_list_of_simid_outputs(config, "vtx", "birds_nest_K40")
    assert isinstance(val, list)
    assert len(val) == 2

    config.benchmark.enabled = True
    config.benchmark.n_primaries.stp = 999

    assert agg.get_simid_njobs(config, "birds_nest_K40") == 1


def test_simid_harvesting(config):
    simids = agg.gen_list_of_all_simids(config)
    assert isinstance(simids, type({}.keys()))
    assert all(isinstance(s, str) for s in simids)
    assert len(simids) == 11


def test_simid_outputs(config):
    outputs = agg.gen_list_of_all_simid_outputs(config, "stp")
    assert isinstance(outputs, list)
    assert all(isinstance(s, Path) for s in outputs)
    assert len(outputs) == sum(
        [agg.get_simid_njobs(config, s) for s in agg.gen_list_of_all_simids(config)]
    )


def test_process_simlist_is_cumulative(config):
    # evt must include vtx/stp/opt/hit outputs for the same simid
    simid = "birds_nest_K40"
    targets_evt = agg.process_simlist(config, simlist=[f"evt.{simid}"])

    targets_stp = agg.process_simlist(config, simlist=[f"stp.{simid}"])
    targets_opt = agg.process_simlist(config, simlist=[f"opt.{simid}"])
    targets_hit = agg.process_simlist(config, simlist=[f"hit.{simid}"])

    assert targets_evt != []
    assert set(targets_stp).issubset(targets_evt)
    assert set(targets_opt).issubset(targets_evt)
    assert set(targets_hit).issubset(targets_evt)

    assert not set(targets_evt).issubset(targets_hit)
    assert not set(targets_evt).issubset(targets_opt)

    # cvt must include evt outputs (and therefore also lower tiers)
    simid2 = "pen_plates_Ra224_to_Pb208"
    targets_cvt = agg.process_simlist(config, simlist=[f"cvt.{simid2}"])
    targets_evt2 = agg.process_simlist(config, simlist=[f"evt.{simid2}"])

    assert targets_cvt != []
    assert set(targets_evt2).issubset(targets_cvt)


def test_process_simlist_is_cumulative_make_steps(config):
    make_steps = ["stp", "evt"]
    simid = "birds_nest_K40"
    targets_evt = agg.process_simlist(
        config, simlist=[f"evt.{simid}"], make_steps=make_steps
    )
    targets_stp = agg.process_simlist(
        config, simlist=[f"stp.{simid}"], make_steps=["stp"]
    )
    targets_opt = agg.process_simlist(
        config, simlist=[f"opt.{simid}"], make_steps=["opt"]
    )
    targets_hit = agg.process_simlist(
        config, simlist=[f"hit.{simid}"], make_steps=["hit"]
    )

    assert targets_evt != []
    assert set(targets_stp).issubset(targets_evt)

    assert not set(targets_opt).issubset(targets_evt)
    assert not set(targets_hit).issubset(targets_evt)


@pytest.mark.parametrize("step", ["vtx", "par"])
def test_process_simlist_rejects_non_simid_steps(config, step):
    with pytest.raises(SimflowConfigError):
        agg.process_simlist(config, simlist=[f"{step}.birds_nest_K40"])


def test_hpge_harvesting(config):
    cry = agg.crystal_meta(
        config, config.metadata.hardware.detectors.germanium.diodes.V99000A
    )
    assert isinstance(cry, AttrsDict)
    assert cry.name == "000"
    assert cry.order == "99"

    assert agg.start_key(config, "l200-p02-r005-phy") == "20220602T000000Z"

    assert agg.gen_list_of_hpges_valid_for_modeling(config, "l200-p02-r005-phy") == [
        "V99000A"
    ]

    hpges = agg.gen_list_of_all_hpges_valid_for_modeling(config)
    assert isinstance(hpges, dict)
    assert sorted(hpges.keys()) == [
        "l200-p02-r000-phy",
        "l200-p02-r001-phy",
        "l200-p02-r002-phy",
        "l200-p02-r003-phy",
        "l200-p02-r004-phy",
        "l200-p02-r005-phy",
        "l200-p02-r006-phy",
        "l200-p02-r007-phy",
    ]
    # now returns dict[str, int] (hpge -> voltage)
    assert hpges["l200-p02-r000-phy"] == {"V99000A": 4200}


def test_runlist_harvesting(config):
    assert agg.gen_list_of_all_runids(config) == {
        f"l200-p02-r00{i}-phy" for i in range(8)
    }


def test_dtmap_stuff(config):
    runid = "l200-p02-r000-phy"
    simid = "stp.pen_plates_Ra224_to_Pb208"

    dtmaps = agg.gen_list_of_dtmaps(config, runid)
    assert len(dtmaps) == 1
    # check that the dtmap filename contains the voltage
    assert "4200V" in str(dtmaps[0])

    assert len(agg.gen_list_of_merged_dtmaps(config, simid)) == 1
    assert len(agg.gen_list_of_dtmap_plots_outputs(config, simid)) == 1


def test_hpge_voltage_functions(config):
    runid = "l200-p02-r000-phy"

    # test get_hpge_voltage
    voltage = agg.get_hpge_voltage(config, "V99000A", runid)
    assert voltage == 4200
    assert isinstance(voltage, int)


def test_currmod_stuff(config):
    runid = "l200-p02-r000-phy"
    simid = "stp.pen_plates_Ra224_to_Pb208"

    assert len(agg.gen_list_of_currmods(config, runid)) == 1
    assert len(agg.gen_list_of_merged_currmods(config, simid)) == 1
    assert len(agg.gen_list_of_currmod_plots_outputs(config, simid)) == 1


def test_tier_evt_stuff(config):
    files = agg.gen_list_of_all_tier_cvt_outputs(config)
    assert len(files) == 11


def test_usability_harvesting(config):
    usability = agg.gen_list_of_all_usabilities(config)
    assert isinstance(usability, dict)
    for v in usability.values():
        assert isinstance(v, dict)

    assert sorted(usability.keys()) == [
        "l200-p02-r000-phy",
        "l200-p02-r001-phy",
        "l200-p02-r002-phy",
        "l200-p02-r003-phy",
        "l200-p02-r004-phy",
        "l200-p02-r005-phy",
        "l200-p02-r006-phy",
        "l200-p02-r007-phy",
    ]
    # now returns dict[str, int] (hpge -> usability)
    assert usability["l200-p02-r000-phy"] == {"V99000A": "on", "B99000A": "on"}
