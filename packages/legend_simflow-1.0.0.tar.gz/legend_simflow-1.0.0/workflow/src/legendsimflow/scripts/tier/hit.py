# ruff: noqa: I002

# Copyright (C) 2025 Luigi Pertoldi <gipert@pm.me>,
#
# This program is free software: you can redistribute it and/or modify it under
# the terms of the GNU Lesser General Public License as published by the Free
# Software Foundation, either version 3 of the License, or (at your option) any
# later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more
# details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import awkward as ak
import legenddataflowscripts as ldfs
import legenddataflowscripts.utils
import lgdo
import numpy as np
import pint
import pyg4ometry
import pygeomhpges
import pygeomtools
import reboost.hpge.psd
import reboost.hpge.surface
import reboost.hpge.utils
import reboost.math.functions
import reboost.math.stats
import reboost.spms
from dbetto import AttrsDict
from dbetto.utils import load_dict
from lgdo import lh5
from lgdo.lh5 import LH5Iterator

from legendsimflow import hpge_pars, nersc, patterns, utils
from legendsimflow import metadata as mutils
from legendsimflow import reboost as reboost_utils
from legendsimflow.profile import make_profiler
from legendsimflow.tcm import build_tcm

args = nersc.dvs_ro_snakemake(snakemake)  # noqa: F821

stp_file = args.input.stp_file
jobid = args.wildcards.jobid
hit_file = args.output[0]
gdml_file = args.input.geom
log_file = args.log[0]
metadata = args.config.metadata
hpge_dtmap_files = args.input.hpge_dtmaps
hpge_currmods_files = args.input.hpge_currmods
# hpge_eresmods_files = args.input.hpge_eresmods
# hpge_aoeresmods_files = args.input.hpge_aoeresmods
# hpge_psdcuts_files = args.input.hpge_psdcuts
simstat_part_file = args.input.simstat_part_file[0]
l200data = args.config.paths.l200data
usabilities = AttrsDict(load_dict(args.input.detector_usabilities[0]))

hit_file, move2cfs = nersc.make_on_scratch(args.config, hit_file)

BUFFER_LEN = "500*MB"

u = pint.UnitRegistry()


def DEFAULT_ENERGY_RES_FUNC(energy):
    return 2.5 * np.sqrt(energy / 2039)  # FWHM


def DEFAULT_AoE_RES_FUNC(energy):
    return 0.01 * np.sqrt(energy / 2039)


DEFAULT_PSD_CUTS = AttrsDict(
    {
        "aoe": {
            "low_side": -1.5,
            "high_side": 3,
        }
    }
)


# setup logging
log = ldfs.utils.build_log(metadata.simprod.config.logging, log_file)
perf_block, print_perf, _ = make_profiler()

# load the geometry and retrieve registered sensitive volume tables
with perf_block("load_pygeom()"):
    geom = pyg4ometry.gdml.Reader(gdml_file).getRegistry()
sens_tables = pygeomtools.detectors.get_all_senstables(geom)

# determine list of stp tables in the stp file
ondisk_stp_tables = {}
for tbl in lh5.ls(stp_file, "stp/*"):
    # ignore table names that start with underscore
    if not tbl.removeprefix("stp/").startswith("_"):
        ondisk_stp_tables[tbl] = False

partitions = load_dict(simstat_part_file)[f"job_{jobid}"]

# load TCM, to be used to chunk the event statistics according to the run partitioning
msg = "loading TCM"
log.debug(msg)
tcm = lh5.read_as("tcm", stp_file, library="ak")

# extract the detector origin
det_loc = lh5.read("detector_origins", stp_file)
# convert to right format and add units
# FIXME: units should be already present, to be fixed in remage
det_loc = {
    k: [v[field].value for field in ("xloc", "yloc", "zloc")] * u.m
    for k, v in det_loc.items()
}

# loop over the partitions for this file
for runid_idx, (runid, evt_idx_range) in enumerate(partitions.items()):
    msg = (
        f"processing partition corresponding to {runid} "
        f"[{runid_idx + 1}/{len(partitions)}], event range {evt_idx_range}"
    )
    log.info(msg)

    msg = "loading energy resolution parameters"
    log.debug(msg)
    eresmod_pars_file = patterns.output_eresmod_filename(
        snakemake.config,  # noqa: F821
        runid=runid,
    )
    eresmod_pars_all = load_dict(eresmod_pars_file)
    energy_res_func = hpge_pars.build_energy_res_func_dict(
        l200data,
        metadata,
        runid,
        energy_res_pars=eresmod_pars_all,
    )  # FWHM

    msg = "loading A/E resolution parameters"
    log.debug(msg)
    aoeresmod_pars_file = patterns.output_aoeresmod_filename(
        snakemake.config,  # noqa: F821
        runid=runid,
    )
    aoeresmod_pars_all = load_dict(aoeresmod_pars_file)
    aoe_res_func = hpge_pars.build_aoe_res_func_dict(
        l200data,
        metadata,
        runid,
        aoe_res_pars=aoeresmod_pars_all,
    )

    msg = "loading current pulse model parameters"
    log.debug(msg)
    currmod_pars_file = patterns.output_currmod_merged_filename(
        snakemake.config,  # noqa: F821
        runid=runid,
    )
    currmod_pars_all = AttrsDict(load_dict(currmod_pars_file))

    msg = "loading PSD cut values"
    log.debug(msg)
    psdcuts_file = patterns.output_psdcuts_filename(
        snakemake.config,  # noqa: F821
        runid=runid,
    )
    psdcuts_all = load_dict(psdcuts_file)

    # loop over the sensitive volume tables registered in the geometry
    for det_idx, (det_name, geom_meta) in enumerate(sens_tables.items()):
        msg = f"looking for data from sensitive volume table {det_name} (uid={geom_meta.uid})..."
        log.debug(msg)

        stp_table_name = f"stp/{det_name}"

        # only process the HPGe output
        if geom_meta.detector_type != "germanium":
            # no bookkeeping of this table
            ondisk_stp_tables.pop(stp_table_name, None)
            continue

        if stp_table_name not in ondisk_stp_tables:
            msg = (
                f"detector {det_name} not found in {stp_file}. "
                "possibly because it was not read-out or there were no hits recorded"
            )
            log.warning(msg)

            continue

        # get the usability
        usability = usabilities[runid][det_name]
        if usability is None:
            usability = "on"

        msg = "looking for indices of hit table rows to read..."
        log.debug(msg)
        with perf_block("get_remage_hit_range()"):
            i_start, n_entries = reboost_utils.get_remage_hit_range(
                tcm, det_name, geom_meta.uid, evt_idx_range
            )

        # initialize the stp file iterator
        # NOTE: if the entry list is empty, there will be no processing but an
        # empty output table will be nonetheless created. this is important for
        # the buil_tcm() step at the end

        iterator = LH5Iterator(
            stp_file,
            stp_table_name,
            i_start=i_start,
            n_entries=n_entries,
            buffer_len=BUFFER_LEN,
        )

        msg = f"processing the {det_name} output table [{det_idx + 1}/{len(sens_tables)}]..."
        log.info(msg)

        log.debug("creating an pygeomhpges.HPGe object")
        pyobj = pygeomhpges.make_hpge(
            geom_meta.metadata, registry=None, allow_cylindrical_asymmetry=False
        )

        fccd = mutils.get_sanitized_fccd(metadata, det_name)

        # NOTE: we don't use the script arg but we use the (known) file patterns. more robust
        dt_map = reboost_utils.load_hpge_dtmaps(snakemake.config, det_name, runid)  # noqa: F821

        # load parameters of the current model
        pars = currmod_pars_all.get(det_name, None)
        currmod_pars = (
            pars.get("current_pulse_pars", None) if pars is not None else None
        )

        # iterate over input data
        for lgdo_chunk in iterator:
            chunk = lgdo_chunk.view_as("ak", with_units=True)

            with perf_block("distance_to_surface()"):
                _distance_to_nplus = reboost.hpge.surface.distance_to_surface(
                    chunk.xloc,
                    chunk.yloc,
                    chunk.zloc,
                    pyobj,
                    det_loc[det_name],
                    distances_precompute=chunk.dist_to_surf,
                    precompute_cutoff=(fccd + 1),
                    surface_type="nplus",
                )

            with perf_block("piecewise_linear_activeness()"):
                _activeness = reboost.math.functions.piecewise_linear_activeness(
                    _distance_to_nplus,
                    fccd_in_mm=fccd,
                    dlf=0.5,
                )

            edep_active = chunk.edep * _activeness
            energy_true = ak.sum(edep_active, axis=-1)

            # pars strategy: complain if detector is ON and there are no pars
            # otherwise use defaults and warn
            # TODO: move to a separate function to clean up

            if det_name in energy_res_func:
                energy_res = energy_res_func[det_name](energy_true)

            elif usability == "on":
                msg = (
                    f"{det_name} is marked as ON but no energy resolution"
                    "curves are available. this is unacceptable!"
                )
                raise RuntimeError(msg)
            else:
                msg = (
                    f"{det_name} is marked as '{usability}' and no "
                    "energy resolution curves are available. "
                    "using default values"
                )
                log.warning(msg)
                energy_res = DEFAULT_ENERGY_RES_FUNC(energy_true)

            if det_name in aoe_res_func:
                aoe_res = aoe_res_func[det_name](energy_true)
                psdcuts = AttrsDict(
                    utils.sanitize_dict_with_defaults(
                        psdcuts_all[det_name],
                        DEFAULT_PSD_CUTS,
                    )
                )
            else:
                msg = (
                    f"{det_name} is marked as '{usability}' and no "
                    "A/E resolution curves are available. using default values"
                )
                log.warning(msg)
                aoe_res = DEFAULT_AoE_RES_FUNC(energy_true)

            if det_name in psdcuts_all:
                psdcuts = AttrsDict(
                    utils.sanitize_dict_with_defaults(
                        psdcuts_all[det_name],
                        DEFAULT_PSD_CUTS,
                    )
                )
            else:
                msg = (
                    f"{det_name} is marked as '{usability}' and no "
                    "PSD cut values are available. using default values"
                )
                log.warning(msg)
                psdcuts = DEFAULT_PSD_CUTS

            # smear energy with detector resolution
            energy = reboost_utils.gauss_smear(
                energy_true,
                energy_res / 2.35482,
            )

            # PSD: if the drift time map is none, it means that we don't
            # have the detector model to simulate PSD in a more advanced
            # way

            # default to NaN
            _drift_time = ak.full_like(chunk.xloc, fill_value=np.nan)
            aoe = np.full(len(chunk), np.nan)
            aoe_class = np.full(len(chunk), np.nan)
            is_single_site = np.full(len(chunk), False)
            t_max = np.full(len(chunk), np.nan)

            if dt_map is not None and currmod_pars is not None:
                msg = "computing PSD observables"
                log.info(msg)

                with perf_block("hpge_corrected_drift_time()"):
                    _drift_time = reboost_utils.hpge_corrected_drift_time(
                        chunk, dt_map, det_loc[det_name]
                    )
                utils.check_nans_leq(_drift_time, "_drift_time", 0.01)

                with perf_block("hpge_max_current()"):
                    _a_max_true = reboost_utils.hpge_max_current(
                        edep_active, _drift_time, currmod_pars
                    )
                utils.check_nans_leq(_a_max_true, "_a_max_true", 0.01)

                # Apply current resolution smearing based on configured A/E noise parameters
                _a_max = reboost_utils.gauss_smear(
                    _a_max_true, pars.current_reso / pars.mean_aoe
                )

                # finally calculate A/E, comparable to the A/E in data
                # corrected for energy dependence
                aoe = _a_max / energy

                # ...and A/E classifier
                # NOTE: we use the resolution determined from data here instead
                # of the intrinsic simulated ones due to noise
                aoe_class = (aoe - 1) / aoe_res

                # ...and PSD flag
                is_single_site = (aoe_class > psdcuts.aoe.low_side) & (
                    aoe_class < psdcuts.aoe.high_side
                )

                # also calculate drift time at A position
                # FIXME: this is wasting compute resources, max_current should
                # return (maxA, t_maxA)
                with perf_block("hpge_max_current()"):
                    t_max = reboost_utils.hpge_max_current(
                        edep_active, _drift_time, currmod_pars, return_mode="max_time"
                    )

            out_table = reboost_utils.make_output_chunk(lgdo_chunk)

            out_table.add_field("energy", lgdo.Array(energy, attrs={"units": "keV"}))
            out_table.add_field(
                "drift_time_amax", lgdo.Array(t_max, attrs={"units": "ns"})
            )
            out_table.add_field("aoe_raw", lgdo.Array(aoe))
            out_table.add_field("aoe", lgdo.Array(aoe_class))
            out_table.add_field("is_single_site", lgdo.Array(is_single_site))

            _, period, run, _ = mutils.parse_runid(runid)
            field_vals = [period, run, mutils.encode_usability(usability)]
            for i, field in enumerate(["period", "run", "usability"]):
                out_table.add_field(
                    field,
                    lgdo.Array(np.full(shape=len(chunk), fill_value=field_vals[i])),
                )

            with perf_block("write_chunk()"):
                reboost_utils.write_chunk(
                    out_table,
                    f"/hit/{det_name}",
                    hit_file,
                    geom_meta.uid,
                )

        # this table has been processed
        ondisk_stp_tables[stp_table_name] = True

# sanity check that all the stp tables were processed. this is important for
# TCM consistency across all tiers later on
not_done = [k for k, v in ondisk_stp_tables.items() if not v]
if not_done:
    msg = f"stp tables {not_done} were not processed!"
    raise RuntimeError(msg)

log.debug("building the TCM")
build_tcm(hit_file, hit_file)

with perf_block("move_to_cfs()"):
    move2cfs()

print_perf()
