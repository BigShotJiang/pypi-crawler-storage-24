# ruff: noqa: I002

# Copyright (C) 2025 Luigi Pertoldi <gipert@pm.me>,
#
# This program is free software: you can redistribute it and/or modify it under
# the terms of the GNU Lesser General Public License as published by the Free
# Software Foundation, either version 3 of the License, or (at your option) any
# later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more
# details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import dbetto
import legenddataflowscripts as ldfs
import legenddataflowscripts.utils
import numpy as np
from matplotlib.backends.backend_pdf import PdfPages
from reboost.hpge.psd import _current_pulse_model as current_pulse_model

from legendsimflow import hpge_pars, nersc, utils
from legendsimflow import metadata as mutils
from legendsimflow.plot import decorate

args = nersc.dvs_ro_snakemake(snakemake)  # noqa: F821

config = args.config

if "l200data" not in args.config.paths:
    msg = "Cannot extract current pars without setting the path to the l200data in the simconfig file."
    raise KeyError(msg)

l200data = args.config.paths.l200data

runid = args.wildcards.runid
hpge = args.wildcards.hpge_detector
metadata = args.config.metadata
pars_file = args.output.pars_file
plot_file = args.output.plot_file

# use just a single waveform
single_waveform = True

log_file = args.log[0]

# setup logging
logger = ldfs.utils.build_log(metadata.simprod.config.logging, log_file)
hit_tier_name = utils.get_hit_tier_name(l200data)

msg = f"... determined hit tier name is {hit_tier_name}"
logger.info(msg)
logger.info("... looking up the fit inputs")

msg = f"... using a single waveform? {single_waveform}"
logger.info(msg)

raw_wf_pairs, dsp_cfg_file, all_dts, selected_dts = hpge_pars.lookup_currmod_fit_inputs(
    l200data,
    metadata,
    runid,
    hpge,
    hit_tier_name,
    max_waveforms=1 if single_waveform else 100,
)

lh5_group = mutils._get_lh5_table(
    metadata,
    raw_wf_pairs[0][0],
    hpge,
    "raw",
    runid,
)

logger.info("... fetching %d current pulse(s)", len(raw_wf_pairs))
times_list, current_list = hpge_pars.get_current_pulses(
    raw_wf_pairs, lh5_group, str(dsp_cfg_file)
)

logger.info("... fitting the current pulse(s) to extract the model")
popt, x, y = hpge_pars.fit_currmod(times_list, current_list)

# now plot
logger.info("... plotting the fit result")

with PdfPages(plot_file) as pdf:
    logger.info("... plotting drift-time selection")

    fig, _ = hpge_pars.plot_dt_selection(all_dts, selected_dts)
    fig.suptitle(f"{hpge} in {runid}: drift-time selection for current-pulse fit")
    decorate(fig)
    pdf.savefig()

    fig, ax = hpge_pars.plot_currmod_fit_result(times_list, current_list, x, y)

    ax.set_xlim(-1200, 1200)
    fig.suptitle(f"{hpge} in {runid}: current waveform fit result")
    decorate(fig)
    pdf.savefig()

    # also save with a narrower range
    ax.set_xlim(-400, 300)
    pdf.savefig()

    logger.info("... adding the mean aoe")

    popt_dict = utils._curve_fit_popt_to_dict(popt)
    mean_aoe = hpge_pars.estimate_mean_aoe(popt)

    logger.info("... estimating effect of noise")

    files = hpge_pars.lookup_file_paths(l200data, runid, hit_tier_name=hit_tier_name)

    temp = current_pulse_model(np.linspace(-500, 1000, 1501), *popt)

    noise_wfs = hpge_pars.get_noise_waveforms(
        files.raw,
        files.hit,
        lh5_group,
        str(dsp_cfg_file),
        "curr_av",
        length=len(temp),
        maximum_number=100000,
    )

    logger.info("... plot noise waveforms")
    fig, ax = hpge_pars.plot_noise_waveforms(noise_wfs, temp, norm=mean_aoe * 2000)
    fig.suptitle(f"{hpge} in {runid}: noise waveforms")
    decorate(fig)
    pdf.savefig()

    a_max = hpge_pars.get_waveform_maxima(temp, noise_wfs, norm=mean_aoe * 2000)

    # now do the plot
    fit_result = hpge_pars.fit_noise_gauss(a_max, bins=1000)
    fig, ax = hpge_pars.plot_gauss_fit(a_max, fit_result, nominal_val=mean_aoe * 2000)
    fig.suptitle(f"{hpge} in {runid}: noise waveforms fit result")
    decorate(fig)
    pdf.savefig()

    logger.info("... saving outputs")
    dbetto.utils.write_dict(
        {
            "current_pulse_pars": popt_dict,
            "mean_aoe": mean_aoe,
            "current_reso": fit_result.values["sigma"],
        },
        pars_file,
    )
