# Copyright (C) 2025 Luigi Pertoldi <gipert@pm.me>
#
# This program is free software: you can redistribute it and/or modify it under
# the terms of the GNU Lesser General Public License as published by the Free
# Software Foundation, either version 3 of the License, or (at your option) any
# later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more
# details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
from __future__ import annotations

import functools
import logging
import re
from collections.abc import Callable
from pathlib import Path
from typing import Any

import hist
import numpy as np
from dbetto import AttrsDict, TextDB
from iminuit import Minuit, cost
from legendmeta import LegendMetadata
from lgdo import lh5
from matplotlib import pyplot as plt
from numpy.typing import ArrayLike, NDArray
from pygama.math.distributions import gaussian
from reboost.hpge.psd import _current_pulse_model as current_pulse_model

from . import metadata as mutils
from . import utils
from .utils import get_dict_value as _getpar

log = logging.getLogger(__name__)


def lookup_currmod_fit_data(
    hit_files: list[str | Path],
    lh5_group: str,
    ewin_center: float = 1593,
    ewin_width: float = 10,
    max_waveforms: int = 1,
    get_drift_time: bool = True,
) -> tuple[list[tuple[int, int]], NDArray, NDArray]:
    """Extract the indices of the events to fit.

    Considers events with ``abs(A/E) < 1.5`` and finds up to ``max_waveforms``
    events closest to the median drift time.  Returns a list of
    ``(event_index, file_index)`` pairs, sorted from closest to farthest from
    the median, with at most ``max_waveforms`` entries, together with the full
    and selected drift-time arrays for diagnostic purposes.

    Parameters
    ----------
    hit_files
        tier-hit files used to determine the best indices.
    lh5_group
        where the tier-hit data is found in the files.
    ewin_center
        center of the energy window to use for the event search (same units as
        in data).
    ewin_width
        width of the energy window to use for the event search (same units as
        in data).
    max_waveforms
        maximum number of waveforms to return.
    get_drift_time
        Read also drift time to select waveforms.

    Returns
    -------
    pairs
        list of ``(event_index, file_index)`` tuples, sorted by proximity to
        the median drift time.
    all_dts
        all drift-time values for events passing the energy and A/E cuts.
    selected_dts
        drift-time values for the selected subset of events.
    """
    if max_waveforms < 1:
        msg = f"{max_waveforms} must be strictly greater than 0."
        raise ValueError(msg)

    idxs = []
    dts = []

    if len(hit_files) == 0:
        msg = "Cannot proceed without at least one hit data-file!"
        raise ValueError(msg)

    for file in hit_files:
        energy = lh5.read(f"{lh5_group}/cuspEmax_ctc_cal", file).view_as("np")
        aoe = lh5.read(f"{lh5_group}/AoE_Classifier", file).view_as("np")

        # get drift time
        if get_drift_time:
            dt_eff = lh5.read(f"{lh5_group}/dt_eff", file).view_as("np")
        else:
            dt_eff = np.zeros_like(aoe)

        idx = np.where((abs(energy - ewin_center) < ewin_width / 2) & (abs(aoe) < 1.5))[
            0
        ]
        idxs.append(idx)
        dts.append(dt_eff[idx])

    # flatten all events and build file-index array
    counts = [len(d) for d in dts]
    flat_dts = np.concatenate(dts) if dts else np.array([])
    flat_idxs = np.concatenate(idxs) if idxs else np.array([], dtype=int)
    flat_file_idxs = np.concatenate(
        [np.full(c, i, dtype=int) for i, c in enumerate(counts)]
    )

    if len(flat_dts) == 0:
        msg = "no data found in the considered hit files"
        raise ValueError(msg)

    med = float(np.median(flat_dts))
    distances = np.abs(flat_dts - med)
    sort_order = np.argsort(distances)[:max_waveforms]

    pairs = [(int(flat_idxs[i]), int(flat_file_idxs[i])) for i in sort_order]
    selected_dts = flat_dts[sort_order]

    return pairs, flat_dts, selected_dts


def fit_currmod(times_list: list[NDArray], current_list: list[NDArray]) -> tuple:
    """Fit the model to multiple raw HPGe current pulses simultaneously.

    Normalises each waveform by its peak amplitude and uses
    :func:`iminuit.Minuit` to minimise the summed RMS residual across all
    waveforms simultaneously.  Fitting multiple waveforms provides a more
    robust estimate of the pulse-shape parameters than fitting a single event.

    Parameters
    ----------
    times_list
        list of timestep arrays, one per waveform.
    current_list
        list of current-value arrays, one per waveform.

    Returns
    -------
    Tuple of the best-fit parameters (as a NumPy array), and arrays of the
    best-fit model (time and current) evaluated around the peak.
    """
    if len(times_list) == 0:
        msg = "times_list must not be empty"
        raise ValueError(msg)
    if len(current_list) == 0:
        msg = "current_list must not be empty"
        raise ValueError(msg)
    if len(times_list) != len(current_list):
        msg = "times_list and current_list must have the same length"
        raise ValueError(msg)

    # Validate each (t, A) pair and collect peak amplitudes.
    peak_values: list[float] = []

    for idx, (t, A) in enumerate(zip(times_list, current_list, strict=True)):
        t_arr = np.asarray(t)
        A_arr = np.asarray(A)

        if t_arr.shape != A_arr.shape:
            msg = (
                "times_list and current_list elements must have matching shapes; "
                f"mismatch at index {idx}: t.shape={t_arr.shape}, A.shape={A_arr.shape}"
            )
            raise ValueError(msg)

        if t_arr.size == 0:
            msg = f"Waveform at index {idx} is empty"
            raise ValueError(msg)

        peak = float(np.max(A_arr))
        if not np.isfinite(peak) or peak == 0.0:
            msg = (
                "Each waveform must have a finite, non-zero peak amplitude; "
                f"invalid peak {peak!r} at index {idx}"
            )
            raise ValueError(msg)

        peak_values.append(peak)

    # Normalise each waveform by its peak amplitude so that all contribute
    # equally to the cost regardless of their absolute ADC scale.
    peak_amplitudes = np.array(peak_values, dtype=float)
    mean_peak = float(np.mean(peak_amplitudes))
    normalised_wfs = [A / p for A, p in zip(current_list, peak_amplitudes, strict=True)]

    # Use the first waveform to determine the time window and initial peak location.
    t_ref = times_list[0]
    A_ref_norm = normalised_wfs[0]
    maxi = int(np.argmax(A_ref_norm))
    max_t = float(t_ref[maxi])

    low = max_t - 1000
    high = max_t + 1000

    n_wfs = len(times_list)

    msg = f"Fitting using {n_wfs}"
    log.info(msg)

    # Initial parameter guesses: height = 1 (normalised), max_t at detected peak.
    p0 = [1.0, max_t, 60.0, 0.6, 100.0, 0.2, 60.0]
    limits_lo = [0.0, max_t - 100.0, 1.0, 0.0, 1.0, 0.0, 1.0]
    limits_hi = [2.0, max_t + 100.0, 500.0, 1.0, 800.0, 1.0, 800.0]

    def total_mse(height, t0, s1, r1, w2, r2, w3):
        total = 0.0
        for t, A_norm in zip(times_list, normalised_wfs, strict=True):
            mask = (t > low) & (t < high)
            if not np.any(mask):
                continue
            model = current_pulse_model(t[mask], height, t0, s1, r1, w2, r2, w3)
            total += float(np.sum((A_norm[mask] - model) ** 2)) / len(mask)
        return total

    m = Minuit(total_mse, *p0)
    for i in range(7):
        m.limits[i] = (limits_lo[i], limits_hi[i])

    m.migrad()

    popt = np.array(m.values)
    # The fit was performed on normalised waveforms (each divided by its peak),
    # so the fitted height is dimensionless (≈ 1).  Multiply by mean_peak to
    # convert back to the original ADC scale expected by downstream code.
    popt[0] = popt[0] * mean_peak

    x = np.linspace(low, high, 2000)
    y = current_pulse_model(x, *popt)

    return popt, x, y


def fit_noise_gauss(
    data: ArrayLike,
    bins: int,
    *,
    fit_range: tuple | None = None,
    sigma_range: tuple | None = None,
) -> Minuit:
    """Fit the data to a Gaussian to extract the resolution.

    Performs a binned maximum likelihood fit using `minuit`.

    Parameters
    ----------
    data
        an array of the data to fit.
    bins
        The number of bins.
    fit_result
        The results of the `iminuit` fit.
    fit_range
        The range to use for the fit, if `None` this is determined from the data as +/- 5 standard deviations round the mean.
    sigma_range
        The range of sigma values for the fit, if `None` is determined from the data.

    Returns
    -------
        The minuit object holding the fit results.

    """
    if fit_range is None:
        fit_range = (np.mean(data) - 5 * np.std(data), np.mean(data) + 5 * np.std(data))

    if sigma_range is None:
        sigma_range = (0.1 * np.std(data), 10 * np.std(data))

    n, xe = np.histogram(data, bins=bins, range=fit_range)
    c = cost.BinnedNLL(n, xe, gaussian.cdf_norm)

    # initialise the fit
    m_norm = Minuit(
        c,
        x_lo=fit_range[0],
        x_hi=fit_range[1],
        mu=(fit_range[0] + fit_range[1]) / 2,
        sigma=(sigma_range[0] + sigma_range[1]) / 2,
    )

    # set parameters
    m_norm.fixed["x_lo", "x_hi"] = True
    m_norm.limits["mu"] = fit_range
    m_norm.limits["sigma"] = sigma_range

    # perform the fit
    m_norm.migrad()
    m_norm.hesse()

    return m_norm


def plot_noise_waveforms(noise: ArrayLike, temp: ArrayLike, norm: float = 1) -> tuple:
    """Plot the waveforms with noise and the noise alone."""
    temp = norm * temp / np.max(temp)

    fig, axs = plt.subplots(2, 1, figsize=(6, 4), sharex=True)

    for idx, wf in enumerate(noise[0:20]):
        axs[0].plot(wf + temp, label=("noise + current template" if idx == 0 else None))
        axs[1].plot(wf, label=("noise" if idx == 0 else None))

    axs[1].set_xlabel("time [sample]")

    axs[0].set_ylabel("waveform")
    axs[1].set_ylabel("waveform")

    axs[0].legend()
    axs[1].legend()

    return fig, axs


def plot_gauss_fit(
    data: ArrayLike,
    fit_result: Minuit,
    fit_range: tuple | None = None,
    bins: int = 100,
    nominal_val: float | None = None,
) -> tuple:
    """Plot the result of the Gaussian fit.

    Parameters
    ----------
    data
        an array of the data to fit.
    fit_result
        the result of the Gaussian fit.
    bins
        The number of bins.
    fit_range
        The range to use for the fit, if `None` this is determined from the data as +/- 5 standard deviations round the mean.
    nominal_val
        The nominal mean to add as a line on the plot.

    """
    if fit_range is None:
        fit_range = (np.mean(data) - 5 * np.std(data), np.mean(data) + 5 * np.std(data))

    fig, ax = plt.subplots(figsize=(6, 4))

    ax.hist(data, bins=bins, range=fit_range, alpha=0.8, density=True)

    x = np.linspace(*fit_range, 10000)

    ax.plot(
        x,
        gaussian.pdf_norm(
            x,
            x_lo=fit_result.values["x_lo"],
            x_hi=fit_result.values["x_hi"],
            mu=fit_result.values["mu"],
            sigma=fit_result.values["sigma"],
        ),
        label="Fit",
    )

    if nominal_val is not None:
        ax.axvline(nominal_val, color="red", linestyle="--", label="Nominal value")

    ax.set_xlabel("A$_{max}$ [arb]")
    ax.set_ylabel("Prob [arb.]")
    ax.legend()

    ax.set_yscale("linear")
    ax.get_legend().set_title(r"$\sigma$" + f" = {fit_result.values['sigma']:.2f}")

    return fig, ax


def get_current_pulse(
    raw_file: Path | str,
    lh5_group: str,
    idx: int,
    dsp_config: str,
    dsp_output: str = "curr_av",
    align: str = "tp_aoe_max",
) -> tuple:
    """Extract the current pulse.

    Parameters
    ----------
    raw_file
        path to the raw tier file.
    lh5_group
        where to find the waveform table.
    idx
        the index of the waveform to read.
    dsp_config
        the :mod:`dspeed` configuration file defining the DSP processing chain
        to estimate the current pulse.
    dsp_output
        the name of the DSP output corresponding to the current pulse.
    align
        DSP value around which the pulses are aligned.

    """
    # HACK: importing this messes up pint registries
    from dspeed.vis import WaveformBrowser  # noqa: PLC0415

    browser = WaveformBrowser(
        str(raw_file),
        lh5_group,
        dsp_config=dsp_config,
        lines=[dsp_output],
        align=align,
    )

    browser.find_entry(idx)

    t = browser.lines[dsp_output][0].get_xdata()
    A = browser.lines[dsp_output][0].get_ydata()

    return t, A


def get_current_pulses(
    raw_file_idx_pairs: list[tuple[Path | str, int]],
    lh5_group: str,
    dsp_config: str | None,
    dsp_output: str = "curr_av",
    align: str | None = "tp_aoe_max",
) -> tuple[list[NDArray], list[NDArray]]:
    """Extract current pulses for multiple events.

    Calls :func:`get_current_pulse` for each ``(raw_file, idx)`` pair and
    returns the results as two parallel lists.

    Parameters
    ----------
    raw_file_idx_pairs
        list of ``(raw_file, idx)`` pairs.
    lh5_group
        where to find the waveform table.
    dsp_config
        the :mod:`dspeed` configuration file defining the DSP processing chain
        to estimate the current pulse.
    dsp_output
        the name of the DSP output corresponding to the current pulse.
    align
        DSP value around which the pulses are aligned.

    Returns
    -------
    times_list
        list of timestep arrays.
    current_list
        list of current-value arrays.
    """
    times_list = []
    current_list = []
    for raw_file, idx in raw_file_idx_pairs:
        t, A = get_current_pulse(
            raw_file, lh5_group, idx, dsp_config, dsp_output, align
        )
        times_list.append(t)
        current_list.append(A)
    return times_list, current_list


def get_noise_waveforms(
    raw_files: list,
    hit_files: list,
    lh5_group: str,
    dsp_config: str,
    dsp_output: str,
    *,
    threshold: float = 5,
    length: int = 1000,
    maximum_number: int | None = None,
    energy_var: str = "cuspEmax_cal",
) -> NDArray:
    """Extract a matrix of noise waveforms, after applying some DSP processing.

    The waveforms are only those with energy less than `threshold` and are the
    result of the dsp processing defined in `config_path` with output variable
    `dsp_output`.

    Parameters
    ----------
    raw_files
        List of paths to raw files.
    hit_files
        List of paths to hit files.
    lh5_group
        The name of the lh5_group to find the waveform table in.
    dsp_config
        the :mod:`dspeed` configuration file defining the DSP processing chain
        to estimate the current pulse.
    dsp_output
        the name of the DSP output corresponding to the current pulse.
    energy_var
        the name of the energy variable to use for thresholding.
    threshold
        energy threshold to apply to select the noise waveforms
    maximum_number
        Number of waveforms to extract.
    length
        length of noise waveform to extract (takes the first `N` samples).

    Returns
    -------
    a 2D array of the waveforms.

    """
    from dspeed.vis import WaveformBrowser  # noqa: PLC0415

    waveforms = []

    for raw_file, hit_file in zip(raw_files, hit_files, strict=True):
        browser = WaveformBrowser(
            str(raw_file), lh5_group, dsp_config=dsp_config, lines=[dsp_output]
        )
        energies = lh5.read(
            f"{lh5_group.replace('raw', 'hit')}/{energy_var}", hit_file
        ).view_as("np")

        # only look at low energy
        indices = np.where(energies < threshold)

        for idx in indices[0]:
            browser.find_entry(idx, append=False)

            waveform = browser.lines[dsp_output][0].get_ydata()
            waveforms.append(waveform[:length].reshape(1, length))

            if maximum_number is not None and len(waveforms) >= maximum_number:
                return np.concatenate(waveforms, axis=0)

    return np.concatenate(waveforms, axis=0)


def plot_currmod_fit_result(
    t: list[NDArray], A: list[NDArray], model_t: NDArray, model_A: NDArray
) -> tuple:
    """Plot the best fit results."""
    fig, ax = plt.subplots(figsize=(6, 4))

    for idx, (t_tmp, A_tmp) in enumerate(zip(t, A, strict=True)):
        if idx > 100:
            log.warning("Only plotting the first 100 waveforms")
            break

        ax.plot(
            t_tmp,
            A_tmp,
            linewidth=1.5,
            color="grey",
            alpha=0.3,
            label="Current signal" if idx == 0 else None,
        )
    ax.plot(model_t, model_A, label="Model", color="tab:red")

    ax.legend()

    ax.set_xlabel("Time [ns]")
    ax.set_ylabel("Current [ADC]")

    return fig, ax


def plot_dt_selection(all_dts: NDArray, selected_dts: NDArray) -> tuple:
    """Plot the drift-time distribution and highlight the selected waveforms.

    Draws a histogram of *all* drift-time values (passing the energy and A/E
    cuts) using the :mod:`hist` package and overlays a shaded band that spans
    the range of drift times of the events chosen for the current-pulse fit.

    Parameters
    ----------
    all_dts
        Drift-time values for every event that passes the energy and A/E cuts.
    selected_dts
        Drift-time values for the subset of events selected for fitting.

    Returns
    -------
    fig
        The :class:`matplotlib.figure.Figure`.
    ax
        The :class:`matplotlib.axes.Axes`.
    """
    fig, ax = plt.subplots(figsize=(6, 4))

    if len(all_dts) > 0:
        dt_min = float(np.min(all_dts))
        dt_max = float(np.max(all_dts))
        n_bins = max(10, min(100, int(len(all_dts) / 5)))
        h = hist.new.Reg(n_bins, dt_min - 1, dt_max + 1, name="dt_eff [ns]").Double()
        h.fill(all_dts)
        h.plot(ax=ax, yerr=False)

    if len(selected_dts) > 0:
        sel_min = float(np.min(selected_dts))
        sel_max = float(np.max(selected_dts))
        ax.axvspan(
            sel_min,
            sel_max,
            alpha=0.4,
            color="tab:orange",
            label=f"selected ({len(selected_dts)} wfs, "
            f"dt_eff [{sel_min:.0f}, {sel_max:.0f}] ns)",
        )

    ax.set_xlabel("Drift time [ns]")
    ax.set_ylabel("Counts")
    if len(selected_dts) > 0:
        ax.legend()

    return fig, ax


def estimate_mean_aoe(popt: list, energy: float = 1593) -> float:
    """Estimate the maximum aoe from the parameters of the `current_pulse_model` `popt`."""
    # get the maximum of the template
    x = np.linspace(-1000, 3000, 4001)
    temp = current_pulse_model(x, *popt)

    return float(np.max(temp) / energy)


def get_waveform_maxima(
    template: ArrayLike, noise_wfs: ArrayLike, *, norm: float = 1
) -> NDArray:
    """Extract the maximum of each waveform based on combining the `template` with each waveform in `noise_wfs`.

    Note
    ----
    The length of the template must be the same as the waveforms in `noise_wfs`

    Parameters
    ----------
    template
        The template of the waveform to use.
    noise_wfs
        2D array of each noise waveform.
    norm
        The normalisation for the template.

    """
    # normalise the template
    template = norm * template / np.max(template)

    maximum = np.max(noise_wfs + template, axis=1)

    # remove nan
    maximum = maximum[~np.isnan(maximum)]

    # remove far outliers
    return maximum[abs(maximum - np.mean(maximum)) < np.std(maximum) * 5]


def lookup_file_paths(l200data: str, runid: str, hit_tier_name: str) -> AttrsDict:
    """Lookup the paths to the `hit` and `raw` files."""
    _, period, run, data_type = re.split(r"\W+", runid)

    if isinstance(l200data, str):
        l200data = Path(l200data)

    df_cfg = utils.lookup_dataflow_config(l200data).paths

    hit_path = df_cfg[f"tier_{hit_tier_name}"]
    hit_files = list((hit_path / data_type / period / run).glob("*.lh5"))

    if hit_files == []:
        msg = f"no LH5 files found in {hit_path / data_type / period / run}"
        raise RuntimeError(msg)

    raw_files = [
        Path(
            str(hit_file)
            .replace(str(hit_path), str(df_cfg.tier_raw))
            .replace(hit_tier_name, "raw")
        )
        for hit_file in hit_files
    ]

    return AttrsDict({"raw": raw_files, "hit": hit_files})


def lookup_currmod_fit_inputs(
    l200data: str | Path,
    metadata: LegendMetadata,
    runid: str,
    hpge: str,
    hit_tier_name: str = "hit",
    max_waveforms: int = 100,
) -> tuple[list[tuple[Path, int]], Path, NDArray, NDArray]:
    """Find raw files, event indices and the DSP configuration file.

    Parameters
    ----------
    l200data
        The path to the L200 data production cycle.
    metadata
        The metadata instance
    runid
        LEGEND-200 run identifier, must be of the form `{EXPERIMENT}-{PERIOD}-{RUN}-{TYPE}`.
    hpge
        name of the HPGe detector
    hit_tier_name
        name of the hit tier. This is typically "hit" or "pht".
    max_waveforms
        maximum number of waveforms to return.

    Returns
    -------
    raw_wf_pairs
        list of ``(raw_file, event_index)`` pairs, up to ``max_waveforms``.
    dsp_cfg_file
        path to the DSP configuration file.
    all_dts
        all drift-time values for events passing the energy and A/E cuts.
    selected_dts
        drift-time values for the selected subset of events.
    """
    if isinstance(l200data, str):
        l200data = Path(l200data)

    df_cfg = utils.lookup_dataflow_config(l200data).paths

    # get the reference cal run
    cal_runid = mutils.reference_cal_run(metadata, runid)
    _, period, run, _ = re.split(r"\W+", cal_runid)

    msg = f"inferred reference calibration run: {cal_runid}"
    log.debug(msg)

    hit_path = df_cfg[f"tier_{hit_tier_name}"]
    msg = f"looking for hit tier files in {hit_path / 'cal' / period / run}/*"
    log.debug(msg)

    hit_files = list((hit_path / "cal" / period / run).glob("*"))

    if len(hit_files) == 0:
        msg = f"no hit tier files found in {hit_path}/cal/{period}/{run}"
        raise ValueError(msg)

    dsp_cfg_regex = r"l200-*-r%-T%-ICPC-dsp_proc_chain.*"
    dsp_cfg_files = list(
        (l200data / "inputs/dataprod/config/tier_dsp").glob(dsp_cfg_regex)
    )

    if dsp_cfg_files == []:
        dsp_cfg_files = list(
            (l200data / "inputs/dataprod/config/tier/dsp").glob(dsp_cfg_regex)
        )

    if len(dsp_cfg_files) != 1:
        msg = f"could not find a suitable dsp config file in {l200data} (or multiple found)"
        raise RuntimeError(msg)

    lh5_group = mutils._get_lh5_table(metadata, hit_files[0], hpge, "hit", runid)

    msg = "looking for best events to fit"
    log.debug(msg)

    wf_pairs, all_dts, selected_dts = lookup_currmod_fit_data(
        hit_files, lh5_group, max_waveforms=max_waveforms
    )

    raw_path = df_cfg.tier_raw
    raw_wf_pairs = []
    for wf_idx, file_idx in wf_pairs:
        hit_file = hit_files[file_idx]
        raw_file = (
            raw_path / str(hit_file.relative_to(hit_path)).replace(hit_tier_name, "raw")
        ).resolve()
        raw_wf_pairs.append((raw_file, wf_idx))

    msg = "determined %d raw file/event pairs for simultaneous fitting"
    log.debug(msg, len(raw_wf_pairs))

    return raw_wf_pairs, dsp_cfg_files[0], all_dts, selected_dts


def _lookup_generated_pars_file(
    l200data: str | Path,
    metadata: LegendMetadata,
    runid: str,
    *,
    hit_tier_name: str = "hit",
    pars_db: TextDB | None = None,
) -> tuple[Any, Any]:
    if hit_tier_name not in ("hit", "pht"):
        raise NotImplementedError

    if isinstance(l200data, str):
        l200data = Path(l200data)

    # get the paths to generated parameters
    if pars_db is None:
        pars_db = utils.init_generated_pars_db(l200data, tier=hit_tier_name, lazy=True)

    msg = f"loading {hit_tier_name} pars of production {l200data}"
    log.debug(msg)

    # get the pars file at the correct timestamp
    tstamp = mutils.runinfo(metadata, runid).start_key
    chmap = metadata.hardware.configuration.channelmaps.on(tstamp)
    pars_file = pars_db.on(tstamp)

    return pars_file, chmap


def lookup_energy_res_metadata(
    l200data: str | Path,
    metadata: LegendMetadata,
    runid: str,
    *,
    hit_tier_name: str = "hit",
    pars_db: TextDB | None = None,
) -> AttrsDict:
    r"""Lookup the measured HPGe energy resolution metadata from LEGEND-200 data.

    The metadata refers to the following model:

    .. math::

        \text{FWHM}(E) = \sqrt{a + bE}

    where :math:`E` is in keV.

    Returns
    -------
    Mapping of HPGe name to metadata dictionary.

    Parameters
    ----------
    l200data
        The path to the L200 data production cycle.
    metadata
        The metadata instance
    runid
        LEGEND-200 run identifier, must be of the form `{EXPERIMENT}-{PERIOD}-{RUN}-{TYPE}`.
    hit_tier_name
        name of the hit tier. This is typically "hit" or "pht".
    pars_db
        optional existing *non-lazy* instance of
        ``TextDB(".../path/to/prod/generated/par_{hit_tier_name}")``.

    """
    pars_file, chmap = _lookup_generated_pars_file(
        l200data,
        metadata,
        runid,
        hit_tier_name=hit_tier_name,
        pars_db=pars_db,
    )

    out_dict = {}
    for key, detmeta in pars_file.items():
        # handle data prod formats
        hpge = (
            chmap.map("daq.rawid")[int(key[2:])].name if key.startswith("ch") else key
        )

        if hit_tier_name == "pht":
            meta = _getpar(
                detmeta, "results.partition_ecal.cuspEmax_ctc_cal.eres_linear"
            )
        elif hit_tier_name == "hit":
            meta = _getpar(detmeta, "results.ecal.cuspEmax_ctc_cal.eres_linear")

        if meta is not None:
            out_dict[hpge] = meta

    return AttrsDict(out_dict)


def lookup_aoe_res_metadata(
    l200data: str | Path,
    metadata: LegendMetadata,
    runid: str,
    *,
    hit_tier_name: str = "hit",
    pars_db: TextDB | None = None,
) -> AttrsDict:
    r"""Lookup the measured A/E resolution metadata from LEGEND-200 data.

    The metadata refers to the following model:

    .. math::

        \sigma_\text{A/E}(E) = \sqrt{a + (b/E)^c}

    where :math:`E` is in keV.

    Returns
    -------
    Mapping of HPGe name to metadata dictionary.

    Parameters
    ----------
    l200data
        The path to the L200 data production cycle.
    metadata
        The metadata instance
    runid
        LEGEND-200 run identifier, must be of the form `{EXPERIMENT}-{PERIOD}-{RUN}-{TYPE}`.
    hit_tier_name
        name of the hit tier. This is typically "hit" or "pht".
    pars_db
        optional existing *non-lazy* instance of
        ``TextDB(".../path/to/prod/generated/par_{hit_tier_name}")``.

    """
    pars_file, chmap = _lookup_generated_pars_file(
        l200data,
        metadata,
        runid,
        hit_tier_name=hit_tier_name,
        pars_db=pars_db,
    )

    out_dict = {}
    for key, detmeta in pars_file.items():
        # handle data prod formats
        hpge = (
            chmap.map("daq.rawid")[int(key[2:])].name if key.startswith("ch") else key
        )
        par = _getpar(detmeta, "results.aoe.correction_fit_results.SigmaFits")
        if par is not None:
            out_dict[hpge] = par

    return AttrsDict(out_dict)


def build_energy_res_func(function: str) -> Callable:
    """Energy resolution function builder."""
    if function == "FWHMLinear":
        return lambda energy, a, b: (a + b * energy) ** 0.5
    if function == "FWHMQuadratic":
        return lambda energy, a, b, c: (a + b * energy + c * energy * energy) ** 0.5

    raise NotImplementedError


def build_aoe_res_func(function: str) -> Callable:
    """A/E resolution function builder."""
    if function == "SigmaFit":
        return lambda energy, a, b, c: (a + (b / (energy + 10**-99)) ** c) ** (0.5)

    raise NotImplementedError


def build_energy_res_func_dict(
    l200data: str | Path,
    metadata: LegendMetadata,
    runid: str,
    *,
    hit_tier_name: str = "hit",
    energy_res_pars: dict | AttrsDict | None = None,
) -> dict[str, Callable]:
    r"""Build energy resolution functions for each HPGe detector in a LEGEND-200 run.

    Returns
    -------
    Mapping of HPGe name to energy resolution function (FWHM), where energy is
    expected in units of keV.

    Parameters
    ----------
    l200data
        The path to the L200 data production cycle.
    metadata
        The metadata instance
    runid
        LEGEND-200 run identifier, must be of the form `{EXPERIMENT}-{PERIOD}-{RUN}-{TYPE}`.
    hit_tier_name
        name of the hit tier. This is typically "hit" or "pht".
    energy_res_pars
        from :func:`lookup_energy_res_metadata`.

    """
    if energy_res_pars is None:
        energy_res_pars = lookup_energy_res_metadata(
            l200data,
            metadata,
            runid,
            hit_tier_name=hit_tier_name,
        )

    if not isinstance(energy_res_pars, AttrsDict):
        energy_res_pars = AttrsDict(energy_res_pars)

    _func_full = build_energy_res_func("FWHMLinear")

    energy_res_sigma_func = {}
    for hpge, meta in energy_res_pars.items():
        # use functools.partial correctly freeze the parameters into the function
        base = functools.partial(
            _func_full,
            a=meta.parameters.a,
            b=meta.parameters.b,
        )

        def _eres(E, base=base):
            return base(E)

        msg = f"measured FWHM for {hpge} at 2 MeV is ~{_eres(2000)} keV"
        log.debug(msg)

        energy_res_sigma_func[hpge] = _eres

    return energy_res_sigma_func


def build_aoe_res_func_dict(
    l200data: str | Path,
    metadata: LegendMetadata,
    runid: str,
    *,
    hit_tier_name: str = "hit",
    aoe_res_pars: dict | AttrsDict | None = None,
) -> dict[str, Callable]:
    r"""Build A/E resolution functions for each HPGe detector in a LEGEND-200 run.

    Returns
    -------
    Mapping of HPGe name to A/E resolution as a function of energy, where
    energy is expected in units of keV.

    Parameters
    ----------
    l200data
        The path to the L200 data production cycle.
    metadata
        The metadata instance
    runid
        LEGEND-200 run identifier, must be of the form `{EXPERIMENT}-{PERIOD}-{RUN}-{TYPE}`.
    hit_tier_name
        name of the hit tier. This is typically "hit" or "pht".
    aoe_res_pars
        from :func:`lookup_aoe_res_metadata`.

    """
    if aoe_res_pars is None:
        aoe_res_pars = lookup_aoe_res_metadata(
            l200data,
            metadata,
            runid,
            hit_tier_name=hit_tier_name,
        )

    if not isinstance(aoe_res_pars, AttrsDict):
        aoe_res_pars = AttrsDict(aoe_res_pars)

    _func_full = build_aoe_res_func("SigmaFit")

    aoe_res_sigma_func = {}
    for hpge, meta in aoe_res_pars.items():
        # use functools.partial correctly freeze the parameters into the function
        base = functools.partial(
            _func_full,
            a=meta.pars.a,
            b=meta.pars.b,
            c=meta.pars.c,
        )

        def _aoeres(E, base=base):
            return base(E)

        msg = f"measured A/E (corrected) resolution for {hpge} at 2 MeV is ~{_aoeres(2000)}"
        log.debug(msg)

        aoe_res_sigma_func[hpge] = _aoeres

    return aoe_res_sigma_func


def lookup_psd_cut_values(
    l200data: str | Path,
    metadata: LegendMetadata,
    runid: str,
    *,
    hit_tier_name: str = "hit",
    pars_db: TextDB | None = None,
) -> AttrsDict:
    r"""Lookup the measured PSD cut values from LEGEND-200 data.

    Returns
    -------
    Mapping of HPGe name to metadata dictionary.

    Parameters
    ----------
    l200data
        The path to the L200 data production cycle.
    metadata
        The metadata instance
    runid
        LEGEND-200 run identifier, must be of the form `{EXPERIMENT}-{PERIOD}-{RUN}-{TYPE}`.
    hit_tier_name
        name of the hit tier. This is typically "hit" or "pht".
    pars_db
        optional existing *non-lazy* instance of
        ``TextDB(".../path/to/prod/generated/par_{hit_tier_name}")``.

    """
    pars_file, chmap = _lookup_generated_pars_file(
        l200data,
        metadata,
        runid,
        hit_tier_name=hit_tier_name,
        pars_db=pars_db,
    )

    out_dict = {}
    for key, detmeta in pars_file.items():
        # handle data prod formats
        hpge = (
            chmap.map("daq.rawid")[int(key[2:])].name if key.startswith("ch") else key
        )
        out_dict[hpge] = {
            "aoe": {
                "low_side": _getpar(detmeta, "results.aoe.low_cut"),
                "high_side": _getpar(detmeta, "results.aoe.high_cut"),
            }
        }

    return AttrsDict(out_dict)
