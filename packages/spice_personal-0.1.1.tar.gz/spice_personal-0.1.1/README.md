# spice-personal

`spice-personal` is the SPICE Personal reference product package.

It provides:
- the personal advisory CLI
- personal domain assets and profile scaffolding
- reference wrappers (OpenRouter model + execution agents)

This package depends on `spice-runtime`.
