"""Packaged personal DomainSpec assets."""
