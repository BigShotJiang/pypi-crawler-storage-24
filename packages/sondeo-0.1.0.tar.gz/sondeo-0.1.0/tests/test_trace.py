"""Tests for Sondeo call tracing."""

from sondeo.profiler.logging import clear_events
from sondeo.profiler.trace import clear_results, get_results, trace


def test_trace_collects_and_stores_results() -> None:
    clear_results()
    clear_events()

    def nested() -> int:
        return sum(range(5_000))

    with trace(filter_stdlib=False) as result:
        nested()

    assert result.total_calls > 0
    assert result.elapsed_ms > 0
    assert result.correlation_id is not None

    stored = get_results()
    assert len(stored) == 1
    assert stored[0].elapsed_ms > 0
    assert stored[0].correlation_id is not None

    clear_results()
    clear_events()
