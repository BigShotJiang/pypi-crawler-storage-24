"""Tests for sondeo memory profiling."""

from sondeo.profiler.logging import clear_events
from sondeo.profiler.memory import clear_results, get_results, memprof


def test_memprof_decorator():
    clear_results()
    clear_events()

    @memprof
    def allocate():
        return [0] * 100_000

    result = allocate()
    assert len(result) == 100_000

    results = get_results()
    assert len(results) == 1
    assert "allocate" in results[0].name
    assert results[0].peak_mb >= 0
    assert results[0].correlation_id is not None
    clear_results()
    clear_events()
