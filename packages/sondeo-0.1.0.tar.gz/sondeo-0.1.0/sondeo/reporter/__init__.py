"""Report generators — console, JSON, Markdown, and Cacao UI."""
