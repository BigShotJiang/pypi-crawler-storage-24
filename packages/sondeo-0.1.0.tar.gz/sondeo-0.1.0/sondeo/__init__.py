"""
Sondeo - A lightweight Python code profiler and log reporter.

Inspect execution time, memory, call stacks, and bottlenecks
with minimal overhead. Zero dependencies by default.
"""

from __future__ import annotations

from sondeo.profiler.logging import log
from sondeo.profiler.memory import memprof
from sondeo.profiler.timer import profile, timer
from sondeo.profiler.trace import trace
from sondeo.reporter.console import report

__all__ = [
    "profile",
    "timer",
    "memprof",
    "log",
    "trace",
    "report",
]
