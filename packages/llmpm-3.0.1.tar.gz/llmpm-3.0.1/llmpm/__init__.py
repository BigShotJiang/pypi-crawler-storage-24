"""llmpm — LLM Package Manager."""

__version__ = "3.0.1"
__author__ = "llmpm contributors"
