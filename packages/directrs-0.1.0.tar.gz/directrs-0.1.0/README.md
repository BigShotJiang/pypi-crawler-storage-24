# directrs

**DirectRS** — extract geometry from decision trees to build piecewise-linear models.

Based on Agus Sudjianto's paper *"Linear Models Hiding Inside Your Decision Tree"*.

## Installation

```bash
pixi install
```

## Usage

```bash
# Classification
pixi run cli train --task classification --input data.csv --target target --output-dir output/

# Regression
pixi run cli train --task regression --input data.csv --target target --output-dir output/

# Predict
pixi run cli predict --model model.pkl --input new_data.csv --output predictions.csv
```

## Run tests

```bash
pixi run test
```
