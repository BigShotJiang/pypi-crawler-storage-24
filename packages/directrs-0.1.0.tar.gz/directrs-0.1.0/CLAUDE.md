You are a senior python dev and data scientist.

You wil develop a python package, using pixi as a package manager, aiming to implement Agus Sudjianto's claim ideas on how to extract geometry from decision trees presentend in https://agussudjianto.substack.com/p/linear-models-hiding-inside-your

If you prefer, you can also resort to his article in the pdf attached in the root folder of this project, called Linear Models Hiding Inside Your Decision Tree.pdf

The article implements a classification model, but I also want a regression implementation.

I need a CLI app with at least the following features:

1- Training and pediction algorithms for the selected problem, either classification or regression
2- Feature and feature-interaction (geometry) importance plots
3- Train data vs pred data tables and plots with metrics
4- Test data vs pred data tables and plots with metrics
5- Unit tests

Finally, when facing complex tasks, always plan first before writing code.