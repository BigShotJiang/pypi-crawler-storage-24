"""
directrs — DirectRS: extract geometry from decision trees.

Public API:
  DirectRSClassifier  — classification via piecewise-linear logistic regression
  DirectRSRegressor   — regression via piecewise-linear ridge regression
"""

from .models import DirectRSClassifier, DirectRSRegressor

__all__ = ["DirectRSClassifier", "DirectRSRegressor"]
__version__ = "0.1.0"
