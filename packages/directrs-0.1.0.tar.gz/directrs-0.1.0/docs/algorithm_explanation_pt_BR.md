# Como o DirectRS Funciona

A ideia central: uma árvore de decisão aprende implicitamente uma *geometria* do espaço de features ao dividi-lo em regiões. O DirectRS torna essa geometria explícita e a utiliza como entrada para um modelo linear simples.

---

## Passo 1: Treinar uma Árvore de Decisão

Primeiro, uma árvore padrão (CART) é treinada nos dados. A árvore particiona o espaço de features em **folhas** — cada folha é um hiperetângulo definido pela conjunção de todas as divisões ao longo do caminho da raiz até aquela folha.

---

## Passo 2: Extrair a Geometria (a matriz G)

Para cada folha ℓ, definem-se:

- **p_ℓ ∈ {0,1}^d** — um vetor indicador binário: `p_ℓ[j] = 1` se a feature `j` foi usada em alguma divisão ao longo do caminho até a folha ℓ, `0` caso contrário.
- **v_ℓ** — o valor de predição da folha (probabilidade de classe ou média do alvo).
- **w_ℓ** — a fração das amostras de treino que caem na folha ℓ.

A **matriz de geometria** G ∈ ℝ^(d×d) agrega o quanto cada feature (e cada par de features) *importa* ao longo de todas as folhas, ponderada pela importância de cada folha:

```
G = Σ_ℓ  w_ℓ · (v_ℓ - v̄)² · outer(p_ℓ, p_ℓ)
```

G[i,j] é grande quando as features i e j estão ambas ativas em folhas cujas predições diferem muito da média global. Isso captura a **co-ocorrência de features em regiões preditivas** — ou seja, quais features interagem para produzir as decisões da árvore.

---

## Passo 3: Calcular a Matriz de Esticamento S'

G é simétrica e semi-definida positiva, portanto possui uma raiz quadrada via decomposição em autovalores:

```
G = Q Λ Qᵀ  →  S' = Q · clamp(Λ, 0)^(1/2) · Qᵀ
```

S' é um **mapa linear** que "estica" o espaço de entrada ao longo das direções que a árvore considerou discriminativas. Direções correspondentes a autovalores nulos são colapsadas — essas direções não contribuem para a predição.

---

## Passo 4: Construir o Embedding Φ(x)

Para uma nova entrada x, identifica-se a folha ℓ*(x) em que ela cai. Em seguida, constrói-se um vetor de features com estrutura de blocos:

```
Φ(x) ∈ ℝ^(L × (d+1))
```

O bloco correspondente à folha ℓ*(x) é preenchido com `[1, S'x]` (um viés + a entrada geometricamente esticada). Todos os outros blocos são zero.

Esse embedding diz: *"x caiu na folha ℓ*, e aqui está como x se parece na geometria local àquela folha."*

---

## Passo 5: Ajustar um Modelo Linear sobre Φ

- **Classificação**: Regressão Logística sobre Φ(x)
- **Regressão**: Regressão Ridge sobre Φ(x)

O modelo final é **linearmente por partes**: dentro de cada folha, a predição é uma função linear da entrada esticada. Entre folhas, diferentes funções lineares se aplicam, cada uma calibrada pelos coeficientes do modelo linear global para o bloco daquela folha.

---

## Passo 6: Predição para uma Nova Entrada x

```
x  →  [árvore roteia x até a folha ℓ*]  →  Φ(x)  →  modelo linear  →  ŷ
```

1. Percorre-se x pela árvore treinada para encontrar sua folha ℓ*.
2. Calcula-se `S'x` (estica x pela geometria).
3. Coloca-se `[1, S'x]` no bloco ℓ* de um vetor de zeros → Φ(x).
4. Aplica-se os pesos do modelo linear ajustado a Φ(x) → saída.

---

## Importâncias das Features

Dado que Φ possui estrutura conhecida:

- **Importância de feature**: soma dos pesos lineares absolutos para cada feature original j ao longo de todos os blocos de folhas (o quanto a feature j contribui quando esticada e mapeada?).
- **Importância de interação entre features**: G[i,j] quantifica diretamente com que frequência as features i e j aparecem juntas em folhas preditivas — os elementos fora da diagonal de G são as importâncias de interação.

---

## O Insight Central

Uma árvore de decisão pura não é diferenciável e ignora a *magnitude* de x dentro de uma folha (apenas a região importa). O DirectRS recupera um modelo diferenciável, linear por regiões, que:

1. Respeita a partição do espaço definida pela árvore
2. Utiliza os valores reais das features (e não apenas "em qual caixa estou?")
3. Possui coeficientes interpretáveis associados a direções geometricamente significativas
