import base64
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from flowra.llm import (
    AssistantMessage,
    ImageBlock,
    LLMRequest,
    SystemMessage,
    TextBlock,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)
from flowra.llm.providers.openai import OpenAIProvider


@pytest.fixture
def mock_client() -> AsyncMock:
    client = AsyncMock()
    completion = MagicMock()
    choice = MagicMock()
    choice.message.content = "Hello!"
    choice.message.tool_calls = None
    choice.finish_reason = "stop"
    completion.choices = [choice]
    completion.usage = MagicMock()
    completion.usage.prompt_tokens = 10
    completion.usage.completion_tokens = 5
    completion.usage.prompt_tokens_details = None
    completion.usage.model_dump.return_value = {
        "prompt_tokens": 10,
        "completion_tokens": 5,
        "total_tokens": 15,
    }
    client.chat.completions.create.return_value = completion
    return client


@pytest.fixture
def provider(mock_client: AsyncMock) -> OpenAIProvider:
    return OpenAIProvider(client=mock_client)


class TestSystemMessageValidation:
    async def test_system_messages_at_start_are_ok(self, provider: OpenAIProvider, mock_client: AsyncMock) -> None:
        request = LLMRequest(
            model="gpt-4",
            messages=[
                SystemMessage(blocks=[TextBlock(text="system1")]),
                SystemMessage(blocks=[TextBlock(text="system2")]),
                UserMessage(blocks=[TextBlock(text="hello")]),
            ],
        )
        await provider.call(request)

        call_kwargs = mock_client.chat.completions.create.call_args.kwargs
        messages = call_kwargs["messages"]
        assert messages[0] == {"role": "system", "content": "system1"}
        assert messages[1] == {"role": "system", "content": "system2"}
        assert messages[2]["role"] == "user"


class TestConstructorValidation:
    def test_no_args_raises_value_error(self) -> None:
        with pytest.raises(ValueError, match="Either 'client' or 'api_key' must be provided"):
            OpenAIProvider()


class TestSchemaStrictTransformation:
    async def test_simple_schema_gets_strict_properties(self, provider: OpenAIProvider, mock_client: AsyncMock) -> None:
        """Simple schema gets additionalProperties: false and all properties in required."""
        schema: dict[str, Any] = {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "integer"},
            },
            "required": ["name"],
        }
        request = LLMRequest(
            model="test",
            messages=[UserMessage(blocks=[TextBlock(text="json please")])],
            json_schema=schema,
        )
        await provider.call(request)

        call_kwargs = mock_client.chat.completions.create.call_args.kwargs
        response_format = call_kwargs["response_format"]
        strict_schema = response_format["json_schema"]["schema"]

        assert strict_schema["additionalProperties"] is False
        assert sorted(strict_schema["required"]) == ["age", "name"]
        assert response_format["json_schema"]["strict"] is True

    async def test_optional_properties_wrapped_with_null(
        self, provider: OpenAIProvider, mock_client: AsyncMock
    ) -> None:
        """Optional properties (not in required) get wrapped in anyOf with null."""
        schema: dict[str, Any] = {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "nickname": {"type": "string"},
            },
            "required": ["name"],
        }
        request = LLMRequest(
            model="test",
            messages=[UserMessage(blocks=[TextBlock(text="json please")])],
            json_schema=schema,
        )
        await provider.call(request)

        call_kwargs = mock_client.chat.completions.create.call_args.kwargs
        strict_schema = call_kwargs["response_format"]["json_schema"]["schema"]

        # "nickname" was not in original required, should be wrapped with anyOf null
        nickname_prop = strict_schema["properties"]["nickname"]
        assert "anyOf" in nickname_prop
        null_types = [item for item in nickname_prop["anyOf"] if item.get("type") == "null"]
        assert len(null_types) == 1

    async def test_nested_objects_processed_recursively(self, provider: OpenAIProvider, mock_client: AsyncMock) -> None:
        """Nested objects are recursively processed with additionalProperties: false."""
        schema: dict[str, Any] = {
            "type": "object",
            "properties": {
                "address": {
                    "type": "object",
                    "properties": {
                        "street": {"type": "string"},
                    },
                },
            },
        }
        request = LLMRequest(
            model="test",
            messages=[UserMessage(blocks=[TextBlock(text="json please")])],
            json_schema=schema,
        )
        await provider.call(request)

        call_kwargs = mock_client.chat.completions.create.call_args.kwargs
        strict_schema = call_kwargs["response_format"]["json_schema"]["schema"]

        nested = strict_schema["properties"]["address"]
        # The nested object might be inside anyOf since "address" is optional
        obj_schema = next(s for s in nested["anyOf"] if s.get("type") == "object") if "anyOf" in nested else nested
        assert obj_schema["additionalProperties"] is False

    async def test_ref_nodes_with_extra_keys_stripped(self, provider: OpenAIProvider, mock_client: AsyncMock) -> None:
        """$ref nodes with extra keys (default, description) are stripped."""
        schema: dict[str, Any] = {
            "type": "object",
            "properties": {
                "item": {
                    "$ref": "#/$defs/Item",
                    "default": None,
                    "description": "An item",
                },
            },
            "required": ["item"],
            "$defs": {
                "Item": {
                    "type": "object",
                    "properties": {"value": {"type": "string"}},
                },
            },
        }
        request = LLMRequest(
            model="test",
            messages=[UserMessage(blocks=[TextBlock(text="json please")])],
            json_schema=schema,
        )
        await provider.call(request)

        call_kwargs = mock_client.chat.completions.create.call_args.kwargs
        strict_schema = call_kwargs["response_format"]["json_schema"]["schema"]
        item_prop = strict_schema["properties"]["item"]

        # Extra keys should be stripped from $ref
        assert "default" not in item_prop
        assert "description" not in item_prop
        assert "$ref" in item_prop


class TestImageBlockConversion:
    async def test_image_block_converted_to_image_url(self, provider: OpenAIProvider, mock_client: AsyncMock) -> None:
        """ImageBlock in UserMessage is converted to OpenAI image_url format with data URI."""
        image_data = b"\x89PNG\r\n\x1a\n"
        request = LLMRequest(
            model="gpt-4",
            messages=[
                UserMessage(
                    blocks=[
                        ImageBlock(data=image_data, media_type="image/png"),
                    ]
                ),
            ],
        )
        await provider.call(request)

        call_kwargs = mock_client.chat.completions.create.call_args.kwargs
        messages = call_kwargs["messages"]
        assert len(messages) == 1
        content = messages[0]["content"]
        # With only an image block, content should be a list (not simplified to string)
        assert isinstance(content, list)
        assert len(content) == 1
        img = content[0]
        assert img["type"] == "image_url"
        expected_b64 = base64.b64encode(image_data).decode()
        assert img["image_url"]["url"] == f"data:image/png;base64,{expected_b64}"


class TestToolResultIsError:
    async def test_tool_result_with_is_error_prepends_error_prefix(
        self, provider: OpenAIProvider, mock_client: AsyncMock
    ) -> None:
        """ToolResultBlock with is_error=True prepends 'Error: ' to content."""
        request = LLMRequest(
            model="gpt-4",
            messages=[
                UserMessage(blocks=[TextBlock(text="call the tool")]),
                AssistantMessage(
                    blocks=[
                        ToolUseBlock(id="call_1", name="my_tool", input={"x": 1}),
                    ]
                ),
                UserMessage(
                    blocks=[
                        ToolResultBlock(tool_use_id="call_1", content="something broke", is_error=True),
                    ]
                ),
            ],
        )
        await provider.call(request)

        call_kwargs = mock_client.chat.completions.create.call_args.kwargs
        messages = call_kwargs["messages"]
        # Find the tool role message
        tool_msgs = [m for m in messages if m.get("role") == "tool"]
        assert len(tool_msgs) == 1
        assert tool_msgs[0]["content"] == "Error: something broke"
        assert tool_msgs[0]["tool_call_id"] == "call_1"
