import dataclasses

from ...llm import AssistantMessage, Message, Usage

__all__ = ["LLMCallResult", "LLMCallSpec"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class LLMCallSpec:
    messages: list[Message]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class LLMCallResult:
    message: AssistantMessage
    usage: Usage | None = None
    elapsed: float = 0.0
