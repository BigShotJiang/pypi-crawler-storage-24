import dataclasses

__all__ = [
    "TextDeltaEvent",
    "ThinkingDeltaEvent",
]


@dataclasses.dataclass(slots=True, kw_only=True)
class TextDeltaEvent:
    """Emitted during streaming for each text chunk.

    Observation-only — use for real-time text display.
    Registering a handler enables streaming mode automatically.
    """

    text: str


@dataclasses.dataclass(slots=True, kw_only=True)
class ThinkingDeltaEvent:
    """Emitted during streaming for each thinking chunk.

    Observation-only — use for real-time thinking display.
    Registering a handler enables streaming mode automatically.
    """

    text: str
