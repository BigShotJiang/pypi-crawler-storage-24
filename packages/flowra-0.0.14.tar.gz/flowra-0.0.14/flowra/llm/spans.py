"""Span types for LLM interactions — shared across agents."""

import dataclasses

from .blocks import ToolResultBlock, ToolUseBlock
from .request import LLMRequest
from .response import LLMResponse

__all__ = ["LLMCallSpan", "ToolCallSpan"]


# Mutable: request set at open, response set before close.
@dataclasses.dataclass(slots=True, kw_only=True)
class LLMCallSpan:
    request: LLMRequest
    response: LLMResponse | None = None


# Mutable: tool_use set at open, result set before close.
@dataclasses.dataclass(slots=True, kw_only=True)
class ToolCallSpan:
    tool_use: ToolUseBlock
    result: ToolResultBlock | None = None
