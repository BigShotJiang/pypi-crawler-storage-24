# Package `flowra.ext`

Optional integrations with external services. Each integration requires
its own extra dependency.

## MLflow tracing (`flowra.ext.mlflow`)

Maps flowra span-hooks to MLflow traces for observability.

**Install:** `pip install flowra[mlflow]`

```python
from flowra.agent import HookSubscription
from flowra.ext.mlflow import install_mlflow_tracing

hooks = HookSubscription()
install_mlflow_tracing(hooks, experiment_name="my-experiment")
# pass hooks to AgentRuntime via services={HookSubscription: hooks, ...}
```

### What gets traced

| Span type | MLflow span type | Default |
|-----------|-----------------|---------|
| `AgentSpan` | AGENT | on |
| `StepSpan` | CHAIN | **off** (verbose) |
| `LLMCallSpan` | CHAT_MODEL | on |
| `ToolCallSpan` | TOOL | on |

LLM call spans use OpenAI-compatible message format — MLflow renders them
with the structured chat UI (separate system prompt, messages, tools, usage).

### Parameters

```python
install_mlflow_tracing(
    hooks,
    experiment_name="flowra",        # MLflow experiment (created if missing)
    session_id="chat-session-123",   # group traces into a session
    trace_agents=True,               # AgentSpan
    trace_steps=False,               # StepSpan (usually too verbose)
    trace_llm_calls=True,            # LLMCallSpan
    trace_tool_calls=True,           # ToolCallSpan
)
```

### Session tracking

Pass `session_id` to group multi-turn chat traces into one MLflow session.
Each `runtime.run()` call creates a separate trace; all traces with the same
session ID appear together in MLflow's "Chat sessions" view.

```python
# Static ID
install_mlflow_tracing(hooks, session_id="my-session-42")

# Dynamic (e.g. from runtime's session)
install_mlflow_tracing(hooks, session_id=lambda: current_session_id)
```

### Preview protocol (`__preview__`)

MLflow's session list shows a short preview of each trace's input/output.
By default, `str(spec)` / `str(result)` is used — which produces the Python
repr (e.g. `ChatSpec(user_message='...', metadata=None)`).

Objects implementing `__preview__() -> str` get clean text instead:

```python
@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class MySpec:
    query: str
    options: dict[str, Any] | None = None

    def __preview__(self) -> str:
        return self.query
```

Built-in implementations: `ChatSpec`, `ChatResult`, `ToolLoopSpec`, `ToolLoopResult`.

### Viewing traces

```bash
# Start MLflow UI
uv run mlflow ui --port 5050
# Open http://localhost:5050
```

### Example

```bash
# Console chat with MLflow tracing
make chat --mlflow --cache

# TUI chat with MLflow tracing
make chat-tui --mlflow
```
