# Package `flowra.agent`

Agent framework: define agents as state machines, run them with crash recovery.

All public symbols are available from the package root:

```python
from flowra.agent import (
    # Defining agents
    Agent,                      # Base class: Agent[Spec, Result]
    step,                       # Decorator: @step, @step(entry=True)
    step_arg,                   # Module with markers: step_arg.SPEC, step_arg.CHILD
    agent_arg,                  # Module with markers: agent_arg.SPEC, agent_arg.SERVICE

    # Persistent storage (slots)
    AgentStore,                 # Slot factory passed to __init__
    Scalar,                     # Single mutable value
    AppendOnlyList,             # Append-only persistent list
    FORK,                       # Storage key: child gets independent copy
    NEW_SCOPE,                  # Storage key: child gets fresh slot

    # Dependency injection
    ServiceLocator,             # DI container: resolve services by type

    # Control flow
    GotoStep,                   # Tail-call to another step
    CallStep,                   # Call step, return result
    GotoAgent,                  # Tail-call to another agent
    CallAgent,                  # Call agent, return result
    AgentDefinitionRef,         # Reference to agent by name or class

    # Parallel execution
    Spawn,                      # Launch parallel children
    SpawnChild,                 # One child: agent + spec
    ChildOutput,                # Result from a completed child
    WhenAll,                    # Strategy: wait for all
    WhenAny,                    # Strategy: first wins, cancel rest
    WhenN,                      # Strategy: wait for N, cancel rest

    # Events
    Event,                      # Typed event envelope
    HookSubscription,           # Register event handlers (user-facing)
    HookEmitter,               # Emit events (agent-facing, injected by runtime)
    ExecutionContext,            # Event context: where in the agent tree
    ExecutionFrame,             # One frame in the execution stack
    AgentInfo,                  # Agent identity in the hierarchy

    # Interrupts and timeouts
    InterruptToken,             # Cooperative cancellation
    Interrupted,                # Return value when interrupted
    InterruptedError,           # Exception raised by InterruptToken.check()
    InterruptTokenSource,       # Create/manage interrupt tokens
    with_interrupt,             # Wrap async iterator with interrupt support
    timeout,                    # Shortcut: spawn a timeout child
    TimeoutExpired,             # Return value when timeout fires

    # Running agents
    AgentRuntime,               # Main entry: run(), resume(), interrupt()
    InMemorySessionStorage,     # In-memory storage (tests, simple cases)
    FileSessionStorage,         # File-based storage (crash recovery)
    # Named,                    # (planned) Wrapper: Named(AgentClass, "custom_name")
)
```

**36 public symbols** (37 when `Named` is added). Do NOT import from internal
submodules — always import from `flowra.agent`.

## Quick start

Define an agent:

```python
from dataclasses import dataclass
from flowra.agent import Agent, AgentStore, Scalar, step

@dataclass
class CounterSpec:
    target: int

@dataclass
class CounterResult:
    total: int

class CounterAgent(Agent[CounterSpec, CounterResult]):
    def __init__(self, store: AgentStore, spec: CounterSpec) -> None:
        self.target = spec.target
        self.count = store.slot(Scalar[int], "count")

    @step(entry=True)
    async def run(self) -> CounterResult:
        current = self.count.get(0)
        self.count.set(current + 1)
        return CounterResult(total=current + 1)
```

Run it:

```python
from flowra.agent import AgentRuntime, InMemorySessionStorage

runtime = AgentRuntime(
    agents={"counter": CounterAgent},
    storage=InMemorySessionStorage(),
)

result = await runtime.run(agent=CounterAgent, spec=CounterSpec(target=5))
```

---

## Defining agents

### `Agent`

Base class for class-based agents: `class MyAgent(Agent[Spec, Result])`.

- `Spec` — dataclass, input to the agent
- `Result` — dataclass (or simple type), final return value
- `__init__` receives `AgentStore` for creating storage slots
- Methods decorated with `@step` become agent steps

Use `None` for agents that don't need input or output:

```python
class WorkerAgent(Agent[None, WorkerResult]):  # no input spec
    ...

class FireAndForget(Agent[TaskSpec, None]):      # no return value
    ...
```

### `step`

Decorator marking methods as agent steps.

```python
@step(entry=True)           # entry point
async def start(self) -> MyResult: ...

@step                        # regular step — reached via GotoStep/CallStep
async def process(self, data: SomeData) -> MyResult: ...
```

All step parameters and return types (other than action types and `None`) must
be dataclasses — this is required for serialization. The compiler validates at
class definition time and raises `TypeError` for non-dataclass types.

### `step_arg` and `agent_arg`

Modules with parameter binding markers:

- `step_arg.SPEC` — bind step parameter to the step's input
- `step_arg.CHILD` — bind step parameter to a child's output
- `agent_arg.SPEC` — bind constructor parameter to the agent's spec
- `agent_arg.SERVICE` — bind constructor parameter to a service

Usually implicit (resolved by type), explicit markers needed only for ambiguous cases.

### Subagents

Agents can declare internal helper agents via `__subagents__`. They are registered
with namespaced names automatically (e.g., parent `"loop"` + subagent `"tool_call"`
= `"loop/tool_call"`):

```python
class ToolLoopAgent(Agent[ToolLoopSpec, ToolLoopResult]):
    __subagents__ = {"tool_call": ToolCallAgent}

    @step(entry=True)
    async def run(self, spec: ToolLoopSpec) -> Spawn:
        return Spawn(
            CallAgent(agent=ToolCallAgent, spec=ToolCallSpec(...)),
            then=self.collect,
        )
```

Subagents can be referenced by type (`CallAgent(agent=ToolCallAgent)`) or by
relative path (`"./tool_call"`, `"../sibling"`). Type-based resolution walks
the hierarchy upward from the current agent.

---

## Persistent storage (slots)

Slots survive crashes. When `AgentRuntime.resume()` is called after a crash,
slot values are restored from the session storage.

### `AgentStore`

Passed to `Agent.__init__`. Creates typed slots:

```python
def __init__(self, store: AgentStore) -> None:
    self.counter = store.slot(Scalar[int], "counter")
    self.history = store.slot(AppendOnlyList[str], "history")
```

### `Scalar[T]`

Single mutable value.

```python
self.counter.get(0)          # get with default
self.counter.set(42)         # set value
```

### `AppendOnlyList[T]`

Append-only persistent list.

```python
self.history.append("event")
items = self.history.get_all()  # list[str]
```

### `FORK` and `NEW_SCOPE`

Storage key markers passed via `storage_key=` on `GotoStep`, `CallStep`,
`GotoAgent`, `CallAgent`:

- `FORK` — child gets an independent copy of the parent's slot values
- `NEW_SCOPE` — child gets a fresh empty scope (auto-generated key)
- `"explicit-key"` — child gets a fresh scope with that key (persisted across runs)
- `None` (default) — `CallStep` shares parent's scope; `GotoStep` keeps current scope

`GotoAgent` and `CallAgent` always create a fresh scope regardless of `storage_key`.

### `flush()`

`AgentStore.flush()` persists dirty state immediately, without waiting for step end.
Use when you need a mid-step checkpoint (e.g., saving a deadline before a long wait).

**Caution:** after `flush()`, if the step crashes, on resume the step re-executes
from the beginning with already-flushed state. Guard against double-writes.

---

## Dependency injection

Constructor parameters are injected by matching type annotations. Three services
are always available without registration:

| Service          | Purpose                              |
|------------------|--------------------------------------|
| `AgentStore`     | Create storage slots, flush mid-step |
| `ServiceLocator` | Register services for descendants    |
| `InterruptToken` | Check/wait for cooperative interrupt |

Other types are resolved from `AgentRuntime(services={...})` or from parent
agents via `ServiceLocator.provide()`:

```python
class MyAgent(Agent[Spec, Result]):
    def __init__(self, store: AgentStore, llm: LLMProvider) -> None:
        # llm is resolved from services passed to AgentRuntime
        ...

runtime = AgentRuntime(
    agents={"my_agent": MyAgent},
    services={LLMProvider: my_provider},
)
```

If a parameter's type is not found in services:
- `T | None` (nullable) — receives `None`
- `T` (non-nullable) — Python raises `TypeError`

Use `agent_arg` markers when the same type could be both a spec and a service:

```python
class MyAgent(Agent[AppConfig, MyResult]):
    def __init__(
        self,
        spec: Annotated[AppConfig, agent_arg.SPEC],       # from agent spec
        service: Annotated[AppConfig, agent_arg.SERVICE],  # from services
    ) -> None: ...
```

---

## Control flow

Steps return control flow actions to transition between steps and agents.

### `GotoStep`

Tail-call to another step in the same agent. Current step is replaced (no return).

```python
@step(entry=True)
async def start(self, spec: MySpec) -> MyResult:
    return GotoStep(step=self.process, spec=SomeData(...))
```

### `CallStep`

Call another step as a child via `Spawn`. The result is delivered to the `then` step:

```python
@step(entry=True)
async def start(self, spec: MySpec) -> Spawn:
    return Spawn(CallStep(step=self.helper, spec=HelpData(...)), then=self.done)

@step
async def done(self, result: HelpResult) -> MyResult:
    return MyResult(value=result.value)
```

### `GotoAgent` / `CallAgent`

Same as GotoStep/CallStep but for other agents:

```python
return GotoAgent(agent=OtherAgent, spec=OtherSpec(...))
# CallAgent is used inside Spawn:
return Spawn(CallAgent(agent=OtherAgent, spec=OtherSpec(...)), then=self.collect)
```

### `AgentDefinitionRef`

Reference to an agent by class or name string. Used in `CallAgent`/`GotoAgent`
when the agent class isn't directly available.

---

## Parallel execution

### `Spawn`

Launch parallel children. Spawn returns control to a `then` step when children complete:

```python
@step(entry=True)
async def start(self, spec: MySpec) -> Spawn:
    return Spawn(
        WhenAny(
            CallAgent(agent=WorkerAgent, spec=WorkSpec(task="A")),
            CallAgent(agent=WorkerAgent, spec=WorkSpec(task="B")),
        ),
        then=self.collect,
    )

@step
async def collect(self, result: WorkResult) -> MyResult:
    return MyResult(winner=result)
```

### `SpawnChild`

Type alias: `CallStep | CallAgent`. Each child is either a step call or an agent call.

### `ChildOutput`

Result from a completed child. Received in the `then` step after `Spawn` completes.

### Completion strategies

| Strategy                          | Behavior                                      |
|-----------------------------------|-----------------------------------------------|
| `WhenAll(child1, child2, ...)`    | Wait for all children, return list of results |
| `WhenAny(child1, child2, ...)`    | First child to finish wins, cancel the rest   |
| `WhenN(child1, child2, ..., n=N)` | Wait for N children, cancel the rest          |

### Step parameter injection

Step parameters are bound by type matching against two sources: **step spec**
(from `GotoStep(spec=...)` or entry call) and **child outputs** (from `Spawn` children).

```python
@step
async def join(self, result: WorkerResult) -> MyResult:
    return MyResult(value=result.value)
```

Use `step_arg` markers when types are ambiguous:

| Parameter type                        | Injected value                          |
|---------------------------------------|-----------------------------------------|
| `T`                                   | First match from any source             |
| `Annotated[T, step_arg.SPEC]`         | Step spec only                          |
| `Annotated[T, step_arg.CHILD]`        | First child result matching `T`         |
| `Annotated[T, step_arg.CHILD("tag")]` | Child result with matching tag          |
| `list[T]`                             | All matching results                    |
| `T \| None`                           | Match or `None` if not found            |

---

## Events

### `Event`

Typed event envelope: `Event[T]` has two fields:
- `data: T` — the event payload
- `context: ExecutionContext` — where in the agent tree the event was emitted

### `ExecutionContext`, `ExecutionFrame`, `AgentInfo`

Every emitted event carries an `ExecutionContext` — the runtime call chain from
root to the agent that emitted the event:

- `ExecutionContext.frame` — current agent's frame
- `ExecutionContext.stack` — full path from root to current (inclusive)
- `ExecutionFrame.agent: AgentInfo` — agent identity (name, path, type)
- `ExecutionFrame.spec` — the spec passed to this agent
- `ExecutionFrame.tag` — the tag from CallAgent (if any)

Stack navigation helpers search from current frame upward:

| Method                                   | Returns                  | On miss       |
|------------------------------------------|--------------------------|---------------|
| `find_spec(spec_type)`                   | `T \| None`              | `None`        |
| `get_spec(spec_type)`                    | `T`                      | `LookupError` |
| `find_frame(*, spec_type=, agent_type=)` | `ExecutionFrame \| None` | `None`        |
| `get_frame(*, spec_type=, agent_type=)`  | `ExecutionFrame`         | `LookupError` |

### `HookSubscription`

User-facing registry for event handlers. Create it, register handlers via `on()`,
and pass it in `services` when creating `AgentRuntime`:

```python
subscription = HookSubscription()
subscription.on(MyEvent, lambda e: print(e.data))

runtime = AgentRuntime(
    agents={"my_agent": MyAgent},
    services={HookSubscription: subscription},
)
```

### `HookEmitter`

Agent-facing emitter injected by the runtime. Agents declare `hooks: HookEmitter`
in their constructor to emit events and check for handlers:

```python
class MyAgent(Agent[MySpec, MyResult]):
    def __init__(self, hooks: HookEmitter) -> None:
        self._hooks = hooks

    @step(entry=True)
    async def start(self) -> MyResult:
        await self._hooks.emit(MyEvent(value=42))
        ...
```

Use `propagate_to` on the emitter to forward events between emitters:

```python
child_emitter.propagate_to(parent_emitter)                        # forward all
child_emitter.propagate_to(parent_emitter, only=[MyEvent])        # only MyEvent
child_emitter.propagate_to(parent_emitter, exclude=[NoisyEvent])  # all except NoisyEvent
```

Used by `flowra.lib` agents to expose lifecycle events (before/after LLM calls,
tool executions, etc.).

---

## Interrupts and timeouts

### `InterruptToken`

Cooperative cancellation token. Call `.check()` in loops to detect interruption:

```python
async def long_work(self, token: InterruptToken) -> str:
    for item in items:
        token.check()  # raises InterruptedError if interrupted
        await process(item)
```

### `Interrupted`

Typed return value when an agent is interrupted (e.g., by `WhenAny` cancellation
or manual `runtime.interrupt()`).

### `InterruptTokenSource`

Creates and manages interrupt tokens. `AgentRuntime` creates one internally;
use `runtime.interrupt()` for external control. `InterruptTokenSource` is useful
when building custom execution flows outside `AgentRuntime`.

### `with_interrupt`

Wraps an async iterator to raise `InterruptedError` when an `InterruptToken` fires:

```python
async for event in with_interrupt(provider.stream(request), interrupt_token):
    process(event)
```

If the token is already interrupted, raises immediately. On interrupt, the
underlying iterator is properly closed via `aclose()`.

### `timeout`

Shortcut for creating a timeout child as a `CallAgent`:

```python
@step(entry=True)
async def start(self, spec: MySpec) -> Spawn:
    return Spawn(
        WhenAny(
            CallAgent(agent=WorkerAgent, spec=spec),
            timeout(seconds=30),
        ),
        then=self.collect,
    )

@step
async def collect(self, result: WorkResult | TimeoutExpired) -> MyResult:
    if isinstance(result, TimeoutExpired):
        ...  # handle timeout
    return MyResult(value=result)
```

### `TimeoutExpired`

Return value from `timeout()` when the timer fires.

---

## Running agents

### `Named` *(planned)*

<!-- TODO: implement Named -->
Optional wrapper to register an agent under a custom storage name:

```python
Named(MyAgent, "custom_name")
```

Without `Named`, the agent is registered under `cls.__name__` (e.g., `"MyAgent"`).
Custom names are useful when the same agent class is registered multiple times
or when you need stable storage keys that don't change with class renames.

### `AgentRuntime`

Main entry point for executing agents.

```python
runtime = AgentRuntime(
    agents={"my_agent": MyAgent, "worker": WorkerAgent},
    storage=InMemorySessionStorage(),
    services={LLMProvider: provider},   # DI services (optional)
    max_iterations=1000,                # safety limit (optional)
    timeout=300.0,                      # global timeout in seconds (optional)
)

result = await runtime.run(agent=MyAgent, spec=my_spec)  # run by type
```

<!-- TODO: implement list syntax with Named: agents=[MyAgent, Named(WorkerAgent, "worker")] -->

#### `run(agent, spec) -> Result`

Execute an agent from the entry step to completion.

#### `resume() -> Result`

Resume execution after a crash. Restores state from session storage and continues
from where it left off.

```python
if await runtime.has_pending_execution():
    result = await runtime.resume()
```

#### `interrupt()`

Request cooperative interruption of the running agent.

### Session storage

| Class                    | Description                                                   |
|--------------------------|---------------------------------------------------------------|
| `InMemorySessionStorage` | In-memory, no persistence (tests, simple cases)               |
| `FileSessionStorage`     | File-based, survives crashes (pass `base_dir` + `session_id`) |

```python
# File-based with crash recovery
storage = FileSessionStorage(base_dir="/tmp/sessions", session_id="chat_1")
runtime = AgentRuntime(agents={...}, storage=storage)

result = await runtime.run(agent=MyAgent, spec=spec)
# After crash:
result = await runtime.resume()
```

---

## Internal modules (not public)

The following are used by the runtime machinery and NOT part of the public API.
They live in internal submodules and are not re-exported from `flowra.agent`:

| Symbol            | Purpose                          |
|-------------------|----------------------------------|
| `AbstractAgent`   | Base class implementation detail |
| `AgentDefinition` | Compiled agent representation    |
| `AgentInstance`   | Running instance handle          |
| `AgentRef`        | Union of agent references        |
| `AgentRegistry`   | Agent lookup by name/class       |
| `ResolvedAgent`   | Resolved registry entry          |
| `CreateInstance`  | Factory protocol                 |
| `CallStepHandler` | Protocol for CallStep            |
| `SpawnNode`       | Spawn tree node                  |
| `StepAction`      | Union of all step returns        |
| `StepMeta`        | Step metadata                    |
| `StepRef`         | Step reference type alias        |
| `SessionStorage`  | Abstract storage interface       |
| `ChangeSet`       | Storage delta                    |

---

## Public API summary

| Symbol                   | Kind       | Description                                     |
|--------------------------|------------|-------------------------------------------------|
| `Agent`                  | class      | Base class for agents: `Agent[Spec, Result]`    |
| `step`                   | decorator  | Mark methods as agent steps                     |
| `step_arg`               | module     | Step parameter markers                          |
| `agent_arg`              | module     | Constructor parameter markers                   |
| `AgentStore`             | ABC        | Slot factory for `__init__`                     |
| `Scalar`                 | class      | Single mutable persistent value                 |
| `AppendOnlyList`         | class      | Append-only persistent list                     |
| `FORK`                   | constant   | Storage key: child gets copy                    |
| `NEW_SCOPE`              | constant   | Storage key: child gets fresh slot              |
| `ServiceLocator`         | ABC        | DI container                                    |
| `GotoStep`               | dataclass  | Tail-call to step                               |
| `CallStep`               | dataclass  | Call step, return result                        |
| `GotoAgent`              | dataclass  | Tail-call to agent                              |
| `CallAgent`              | dataclass  | Call agent, return result                       |
| `AgentDefinitionRef`     | type alias | `AgentDefinition \| type[AbstractAgent]`        |
| `Spawn`                  | dataclass  | Launch parallel children                        |
| `SpawnChild`             | type alias | `CallStep \| CallAgent`                         |
| `ChildOutput`            | dataclass  | Child result                                    |
| `WhenAll`                | dataclass  | Wait for all children                           |
| `WhenAny`                | dataclass  | First child wins                                |
| `WhenN`                  | dataclass  | Wait for N children                             |
| `Event`                  | class      | Typed event envelope                            |
| `HookSubscription`       | class      | Register event handlers (user-facing)           |
| `HookEmitter`            | class      | Emit events (agent-facing, injected by runtime) |
| `ExecutionContext`       | dataclass  | Execution metadata (current frame + stack)      |
| `ExecutionFrame`         | dataclass  | One frame in the execution stack                |
| `AgentInfo`              | dataclass  | Agent identity in the hierarchy                 |
| `InterruptToken`         | ABC        | Cooperative cancellation                        |
| `Interrupted`            | class      | Interruption return value                       |
| `InterruptedError`       | exception  | Raised by `InterruptToken.check()`              |
| `InterruptTokenSource`   | class      | Create/manage interrupt tokens                  |
| `with_interrupt`         | function   | Wrap async iterator with interrupt support      |
| `timeout`                | function   | Spawn a timeout child                           |
| `TimeoutExpired`         | dataclass  | Timeout return value                            |
| `Named`                  | dataclass  | *(planned)* Agent with custom storage name      |
| `AgentRuntime`           | class      | Execute agents                                  |
| `InMemorySessionStorage` | class      | In-memory session storage                       |
| `FileSessionStorage`     | class      | File-based session storage                      |
