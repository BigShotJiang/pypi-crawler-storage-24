# Flowing Execution Context — Research (March 2026)

Research date: 2026-03-18

## Idea

Make `ExecutionContext` available via contextvar from any code during agent execution —
not just from hook handlers, but from any service, HTTP client, middleware, etc.

## Problem

Currently `ExecutionContext` is only accessible inside hook handlers (via `Event.context`)
and inside agent steps (via DI). Code deeper in the call stack (HTTP clients, database
middleware, logging) has no way to know which agent is executing, what spec is active,
or what the execution path looks like.

## Proposed solution

Engine sets a contextvar before calling each agent step and clears/switches it after:

```python
from flowra.agent import current_execution_context

# Anywhere in code during agent execution:
ctx = current_execution_context()  # reads from contextvar
request_id = ctx.find_spec(MySpec).request_id
```

## Use cases

- **HTTP middleware**: inject `X-Request-Id`, `X-Agent-Path` headers from current context
- **Logging**: structured log fields with agent name/path without passing context explicitly
- **Metrics**: tag metrics with agent identity
- **Tracing**: OTel/MLflow span attributes from current execution context

## Key design point

This is separate from span-hooks. Both use the same switching point (engine activating
an agent), but serve different purposes:
- **Flowing context**: "who is executing right now?" — available via contextvar
- **Span-hooks**: "wrap this operation for observability" — enter/exit callbacks

Python contextvars work within a single asyncio Task. Since flowra's advance() runs
agent steps sequentially within a Task, contextvar set/reset around each step call
works correctly. For concurrent children (Spawn), each runs in its own Task via
`asyncio.gather`, so contextvars are naturally isolated.
