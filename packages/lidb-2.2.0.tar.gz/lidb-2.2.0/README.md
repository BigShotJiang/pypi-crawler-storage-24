# lidb

`lidb` is a Python library for data processing and management, providing tools for dataset handling, database operations, and data loading.

## Features

- Dataset management with dependency tracking
- Database operations (SQL, MySQL, ClickHouse)
- Data loading and scanning
- Table management
- Configuration and initialization

## Installation

```bash
pip install lidb
```

## Documentation

See [API Documentation](docs/index.md) for detailed usage.

## Quick Start

```python
from lidb import Dataset, DataLoader

# Create a dataset
my_dataset = Dataset(fn=my_function, tb="my_table")

# Load data
loader = DataLoader("my_data")
loader.get([my_dataset], beg_date="2023-01-01", end_date="2023-01-31", times=["09:30:00"])
```

## License

MIT License

## Version

2.1.17