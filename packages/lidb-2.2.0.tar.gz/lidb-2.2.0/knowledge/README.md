# lidb Knowledge Base

This directory contains the documentation for the lidb project, specifically focusing on the execution plan components. The documentation has been organized to provide a comprehensive understanding of the system's architecture and functionality.

## Documentation Structure

- **index.md**: Overview of the lidb execution plan documentation
- **database.md**: Details about database operations and SQL execution
- **dataset.md**: Information about dataset management and dependencies
- **expression.md**: Documentation on expression calculation and analysis functions
- **table.md**: Details about table management and access modes
- **utility.md**: Utility functions and helper modules

This knowledge base can be used for reference, onboarding, and as a foundation for further documentation enhancement.
