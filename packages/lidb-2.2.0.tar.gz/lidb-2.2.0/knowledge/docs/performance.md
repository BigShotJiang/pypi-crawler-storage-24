# lidb 性能优化建议

## 1. 查询优化

### 使用惰性计算

优先使用`scan()`和`LazyFrame`进行惰性计算，只在最后需要结果时才调用`collect()`。

```python
# 推荐：惰性计算
lf = lidb.scan("prices").filter(pl.col("date") > "2023-01-01")
data = lf.select("close", "volume").collect()

# 不推荐：立即计算
df = lidb.sql("SELECT close, volume FROM prices WHERE date > '2023-01-01'")
```

### 合理使用索引

利用`Dataset`类的分区功能，将常用查询条件作为分区字段。

```python
# 按日期和资产分区
def get_price_data():
    return lidb.sql("SELECT * FROM stock_prices")

price_ds = lidb.Dataset(
    fn=get_price_data,
    tb="prices",
    partitions=["date", "asset"]  # 常用查询字段
)
```

### 减少数据扫描范围

使用`get_value()`和`get_history()`方法指定精确的日期范围和过滤条件。

```python
# 只查询需要的日期和资产
data = price_ds.get_value(
    date="2023-01-01",
    asset=["000001", "000002"]
)
```

## 2. 存储优化

### 分区策略

根据数据访问模式选择合适的分区策略。

```python
# 高频数据按资产分区
hft_ds = lidb.Dataset(
    fn=get_hft_data,
    tb="hft_data",
    is_hft=True  # 自动按asset,date分区
)

# 按时间范围分区
daily_ds = lidb.Dataset(
    fn=get_daily_data,
    tb="daily_data",
    partitions=["date"]
)
```

### 数据压缩

配置Polars使用高效的数据压缩格式。

```python
# 在 ~/.config/lidb/settings.toml 中配置
[POLARS]
max_threads = 32
use_pyarrow = true
```

### 文件格式选择

使用Parquet格式存储，支持高效列式存储和压缩。

```python
# 数据自动以Parquet格式存储
lidb.put(df, "processed/prices", partitions=["date"])
```

## 3. 计算优化

### 向量化计算

使用Polars的向量化操作替代Python循环。

```python
# 使用Polars表达式进行向量化计算
qdf = lidb.from_polars(df)
result = qdf.sql(
    "ts_mean(close, 5) as ma5",
    "cs_rank(volume) as volume_rank"
)
```

### 并行处理

利用`DataLoader`的并行加载功能。

```python
loader = lidb.DataLoader("strategy")
loader.get(
    ds_list=[ds1, ds2, ds3],
    n_jobs=10,        # 并发数量
    backend="loky"    # 并发后端
)
```

### 缓存机制

合理利用`Dataset`的自动补全和缓存机制。

```python
# 数据集自动缓存已计算结果
# 通过分区存储和文件系统实现持久化缓存
```

## 4. 配置优化

### 线程数配置

根据CPU核心数配置Polars线程数。

```python
# ~/.config/lidb/settings.toml
[POLARS]
max_threads = 16  # 建议设置为CPU核心数
```

### 内存管理

控制批量处理的数据量，避免内存溢出。

```python
# 分批处理大数据
def process_large_data(dates, batch_size=30):
    for i in range(0, len(dates), batch_size):
        batch_dates = dates[i:i+batch_size]
        yield load_ds(..., batch_dates)
```

### 缓存大小

监控并调整系统缓存策略。

```python
# 监控内存使用
import psutil
print(f"Memory usage: {psutil.virtual_memory().percent}%")
```