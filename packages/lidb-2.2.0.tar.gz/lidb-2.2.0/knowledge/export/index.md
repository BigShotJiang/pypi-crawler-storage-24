# lidb Knowledge Base Documentation

## Overview

This knowledge base documentation provides detailed information about the lidb library, a Python library for data processing and management. It covers database operations, dataset management, expression calculation, table management, and utility functions.

## Module Documentation

### [Database Operations](../docs/database.md)
Details about database operations including SQL execution, data storage, and data scanning.

### [Dataset Management](../docs/dataset.md)
Information about dataset management, dependency handling, and data loading.

### [Expression Calculation](../docs/expression.md)
Documentation on expression calculation with various analysis functions.

### [Table Management](../docs/table.md)
Details about table management and access modes.

### [Utility Functions](../docs/utility.md)
Utility functions for configuration management and data parsing.

## Version Information
- Version: 2.1.17
- License: MIT