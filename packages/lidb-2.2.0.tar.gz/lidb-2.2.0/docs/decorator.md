# 装饰器

decorator模块提供用于数据集函数的装饰器。

## 函数

### `@dataset`

数据集函数的装饰器。

## 使用方法

```python
from lidb import dataset

@dataset
def my_dataset_function():
    # 函数实现
    return data
```