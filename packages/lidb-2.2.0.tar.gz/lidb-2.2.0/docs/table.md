# 表管理

表模块提供表操作和管理的类。

## 类

### `Table`

用于管理数据库表的类。

#### `__init__(self, name: str, mode: TableMode = TableMode.READ)`

初始化一个新表。

**参数**:
- `name`: 表名
- `mode`: 表访问模式 (READ, WRITE, APPEND)

---

### `TableMode`

表访问模式的枚举。

- `READ`: 只读访问
- `WRITE`: 写入访问 (覆盖)
- `APPEND`: 追加访问

---

## 使用方法

```python
from lidb import Table, TableMode

# 创建只读表
read_table = Table("my_table", mode=TableMode.READ)

# 创建写入表
write_table = Table("my_table", mode=TableMode.WRITE)
```