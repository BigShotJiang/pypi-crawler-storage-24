# 初始化和配置

init模块提供lidb库的初始化函数和配置设置。

## 函数和变量

### `NAME`

库名称: "lidb"

### `DB_PATH`

默认数据库存储路径。

### `CONFIG_PATH`

默认配置文件路径。

### `get_settings()`

获取当前库设置。

**返回**:
- 配置设置对象

---

## 使用方法

```python
from lidb import NAME, DB_PATH, CONFIG_PATH, get_settings

print(f"库名称: {NAME}")
print(f"数据库路径: {DB_PATH}")

settings = get_settings()
```