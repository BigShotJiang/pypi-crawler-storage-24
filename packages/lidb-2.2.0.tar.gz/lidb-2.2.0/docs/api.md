# API 参考

## 模块

- [database](database.md) - 数据库操作
- [dataset](dataset.md) - 数据集管理
- [table](table.md) - 表管理
- [init](init.md) - 初始化和配置
- [qdf](qdf.md) - 查询数据帧操作
- [svc](svc.md) - 数据服务
- [parse](parse.md) - 解析工具
- [decorator](decorator.md) - 装饰器

## 快速参考

```python
# 导入主要组件
from lidb import (
    Dataset,
    DataLoader,
    sql,
    put,
    scan,
    Table,
    get_settings
)
```