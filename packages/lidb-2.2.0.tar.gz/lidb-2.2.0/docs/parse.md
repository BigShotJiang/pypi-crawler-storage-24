# 解析工具

parse模块提供解析数据结构的工具函数。

## 函数

### `parse_hive_partition_structure(path: Path | str) -> pl.DataFrame`

解析Hive风格的分区目录结构并返回为DataFrame。

**参数**:
- `path`: 要解析的路径

**返回**:
- `pl.DataFrame`: 包含分区信息的DataFrame

## 使用方法

```python
from lidb import parse_hive_partition_structure

# 解析分区结构
partition_info = parse_hive_partition_structure("/path/to/partitioned/data")
print(partition_info)
```