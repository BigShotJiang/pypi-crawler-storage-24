# 查询数据帧 (QDF)

qdf模块提供查询数据帧操作的函数。

## 函数

### `from_polars(df: pl.DataFrame | pl.LazyFrame) -> QDF`

将polars DataFrame或LazyFrame转换为QDF。

**参数**:
- `df`: 输入DataFrame或LazyFrame

**返回**:
- `QDF`: 转换后的QDF对象

---

### `Expr`

用于构建查询表达式的类。

## 使用方法

```python
from lidb import from_polars, Expr
import polars as pl

# 将DataFrame转换为QDF
pdf = pl.DataFrame({"a": [1, 2, 3]})
qdf = from_polars(pdf)

# 使用Expr构建表达式
expr = Expr.col("a") + 1
```