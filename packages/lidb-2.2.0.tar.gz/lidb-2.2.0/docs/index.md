# lidb API 文档

## 概述

`lidb` 是一个用于数据处理和管理的Python库，提供数据集管理、数据库操作和数据加载等功能。

## 安装

```bash
pip install lidb
```

## 快速开始

```python
from lidb import Dataset, DataLoader

# 创建数据集
my_dataset = Dataset(fn=my_function, tb="my_table")

# 加载数据
loader = DataLoader("my_data")
loader.get([my_dataset], beg_date="2023-01-01", end_date="2023-01-31", times=["09:30:00"])
```
