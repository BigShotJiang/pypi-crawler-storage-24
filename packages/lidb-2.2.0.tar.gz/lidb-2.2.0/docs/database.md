# 数据库操作

数据库模块提供SQL执行、数据存储和数据扫描等数据库操作功能。

## 函数

### `sql(query: str, *args, **kwargs) -> pl.DataFrame`

执行SQL查询并返回结果作为DataFrame。

**参数**:
- `query`: SQL查询字符串
- `*args, **kwargs`: 查询执行的额外参数

**返回**:
- `pl.DataFrame`: 查询结果

---

### `put(data: pl.DataFrame | pl.LazyFrame, path: Path | str, partitions: list[str] = None, **kwargs)`

将数据存储到指定路径，支持分区存储。

**参数**:
- `data`: 要存储的数据 (DataFrame 或 LazyFrame)
- `path`: 存储路径
- `partitions`: 分区列列表

---

### `has(path: Path | str) -> bool`

检查指定路径的数据是否存在。

**参数**:
- `path`: 要检查的路径

**返回**:
- `bool`: 数据存在返回True，否则返回False

---

### `tb_path(tb: str | Path) -> Path`

将表名转换为存储路径。

**参数**:
- `tb`: 表名或路径

**返回**:
- `Path`: 对应的存储路径

---

### `read_mysql(query: str, *args, **kwargs) -> pl.DataFrame`

从MySQL数据库读取数据。

**参数**:
- `query`: SQL查询字符串
- `*args, **kwargs`: 数据库连接参数

**返回**:
- `pl.DataFrame`: 查询结果

---

### `write_mysql(data: pl.DataFrame, table: str, *args, **kwargs)`

将数据写入MySQL表。

**参数**:
- `data`: 要写入的数据
- `table`: 目标表名
- `*args, **kwargs`: 数据库连接参数

---

### `execute_mysql(query: str, *args, **kwargs)`

执行MySQL查询但不返回结果。

**参数**:
- `query`: SQL查询字符串
- `*args, **kwargs`: 数据库连接参数

---

### `read_ck(query: str, *args, **kwargs) -> pl.DataFrame`

从ClickHouse数据库读取数据。

**参数**:
- `query`: SQL查询字符串
- `*args, **kwargs`: 数据库连接参数

**返回**:
- `pl.DataFrame`: 查询结果

---

### `scan(path: Path | str, **kwargs) -> pl.LazyFrame`

扫描存储路径的数据而不将其加载到内存中。

**参数**:
- `path`: 要扫描的路径
- `**kwargs`: 额外的扫描参数

**返回**:
- `pl.LazyFrame`: 惰性加载的数据帧
