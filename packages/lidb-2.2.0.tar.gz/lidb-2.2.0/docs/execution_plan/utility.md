# 工具模块执行计划

## 核心功能
提供辅助功能，包括配置管理、分区解析等。

## get_settings函数
获取配置设置。

### 执行流程
1. 从配置文件路径读取设置
2. 创建Dynaconf配置对象
3. 处理读取异常
4. 返回配置对象

### 配置文件
- 默认路径：~/.config/lidb/settings.toml
- 示例内容：
```toml
[GLOBAL]
path="/path/to/db"

[POLARS]
max_threads=32
```

## parse_hive_partition_structure函数
解析Hive风格的分区目录结构。

### 执行流程
1. 转换输入路径为Path对象
2. 遍历所有匹配的文件
3. 跳过空文件
4. 解析文件的相对路径
5. 提取分区信息（key=value格式）
6. 收集所有分区组合
7. 转换为DataFrame返回

### 输入参数
- `root_path`: 根路径
- `file_pattern`: 文件匹配模式，默认"*.parquet"

### 返回值
- `polars.DataFrame`: 包含分区信息的DataFrame

## 配置覆盖机制
在初始化时读取配置文件，覆盖默认设置：
- DB_PATH：数据库存储路径
- POLARS_MAX_THREADS：Polars最大线程数

## 日志记录
使用logair库进行日志记录，所有模块都有独立的日志记录器。