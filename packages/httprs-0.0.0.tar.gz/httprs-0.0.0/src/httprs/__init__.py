def main() -> None:
    print("Hello from httprs!")
