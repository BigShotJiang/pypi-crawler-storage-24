// ═══════════════════════════════════════════════════════
//  CVC Dashboard — Agent Creator Module
// ═══════════════════════════════════════════════════════
import * as api from './api';
import type { AgentTemplate } from './types';

function esc(s: string): string {
  const d = document.createElement('div');
  d.textContent = s;
  return d.innerHTML;
}

function toast(message: string, type: 'success' | 'error' | 'info' = 'info'): void {
  (window as any).toast?.(message, type);
}

// ── Sub-tab switching ───────────────────────────────
function setupSubtabs(): void {
  document.querySelectorAll('.sdk-subtab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.sdk-subtab').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const target = (btn as HTMLElement).dataset.subtab!;
      document.querySelectorAll('.sdk-subtab-content').forEach(el => el.classList.add('hidden'));
      document.getElementById(`subtab-${target}`)?.classList.remove('hidden');
    });
  });
}

// ── Creator mode switching ──────────────────────────
function setupCreatorModes(): void {
  document.querySelectorAll('.creator-mode-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.creator-mode-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const mode = (btn as HTMLElement).dataset.mode!;
      document.querySelectorAll('.creator-panel').forEach(el => el.classList.add('hidden'));
      document.getElementById(`creator-${mode}`)?.classList.remove('hidden');
    });
  });
}

// ── Create from prompt ──────────────────────────────
function setupPromptCreator(): void {
  document.getElementById('create-from-prompt-btn')?.addEventListener('click', async () => {
    const input = document.getElementById('agent-prompt-input') as HTMLTextAreaElement;
    const prompt = input?.value.trim();
    if (!prompt) { toast('Please describe what you want the agent to do', 'error'); return; }

    const btn = document.getElementById('create-from-prompt-btn') as HTMLButtonElement;
    const resultDiv = document.getElementById('agent-prompt-result')!;
    btn.disabled = true;
    btn.textContent = '⏳ Generating…';
    resultDiv.style.display = 'none';

    try {
      const result = await api.createAgentFromPrompt(prompt);
      const t = result.template;
      resultDiv.style.display = '';
      resultDiv.innerHTML = `
        <div class="agent-preview-card">
          <h4>${esc(t.name)} <span class="tag tag-blue">${esc(t.tool_tier)}</span> <span class="tag tag-green">${esc(t.rank)}</span></h4>
          <p>${esc(t.description)}</p>
          <div class="preview-details">
            <div><strong>ID:</strong> <code>${esc(t.id)}</code></div>
            <div><strong>Squad:</strong> ${esc(t.squad)}</div>
            <div><strong>Capabilities:</strong> ${t.capabilities.map(c => `<span class="tag">${esc(c)}</span>`).join(' ')}</div>
          </div>
          <div class="preview-prompt" style="margin-top:0.5rem">
            <strong>System Prompt:</strong>
            <pre style="white-space:pre-wrap;font-size:0.8em;max-height:200px;overflow:auto">${esc(t.system_prompt)}</pre>
          </div>
          <div class="preview-actions" style="margin-top:0.75rem">
            <button class="btn btn-accent btn-sm" id="confirm-prompt-agent">✓ Register This Agent</button>
            <button class="btn btn-sm" id="edit-prompt-agent">✏️ Edit First</button>
          </div>
        </div>
      `;
      // Confirm
      document.getElementById('confirm-prompt-agent')?.addEventListener('click', async () => {
        try {
          await api.createAgent(t);
          toast(`Agent "${t.name}" created and registered!`, 'success');
          resultDiv.style.display = 'none';
          input.value = '';
          loadAgentsData();
        } catch (e) { toast((e as Error).message, 'error'); }
      });
      // Edit → switch to manual tab prefilled
      document.getElementById('edit-prompt-agent')?.addEventListener('click', () => {
        prefillManualForm(t);
        document.querySelectorAll('.creator-mode-btn').forEach(b => b.classList.remove('active'));
        document.querySelector('.creator-mode-btn[data-mode="manual"]')?.classList.add('active');
        document.querySelectorAll('.creator-panel').forEach(el => el.classList.add('hidden'));
        document.getElementById('creator-manual')?.classList.remove('hidden');
      });
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      btn.disabled = false;
      btn.textContent = '🪄 Generate Agent';
    }
  });
}

function prefillManualForm(t: AgentTemplate): void {
  setVal('agent-man-id', t.id);
  setVal('agent-man-name', t.name);
  setVal('agent-man-desc', t.description);
  setVal('agent-man-tier', t.tool_tier);
  setVal('agent-man-rank', t.rank);
  setVal('agent-man-squad', t.squad);
  setVal('agent-man-prompt', t.system_prompt);
  setVal('agent-man-model', t.model_override || '');
  setVal('agent-man-provider', t.provider_override || '');
  setChecked('agent-man-auto-share', t.auto_share_to_hive);
  setChecked('agent-man-auto-respond', t.auto_respond);
}

function setVal(id: string, value: string): void {
  const el = document.getElementById(id) as HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement;
  if (el) el.value = value;
}

function setChecked(id: string, checked: boolean): void {
  const el = document.getElementById(id) as HTMLInputElement;
  if (el) el.checked = checked;
}

// ── Manual creation ─────────────────────────────────
function setupManualCreator(): void {
  document.getElementById('create-manual-btn')?.addEventListener('click', async () => {
    const id = (document.getElementById('agent-man-id') as HTMLInputElement)?.value.trim();
    if (!id) { toast('Agent ID is required', 'error'); return; }

    const template: Partial<AgentTemplate> = {
      id,
      name: (document.getElementById('agent-man-name') as HTMLInputElement)?.value.trim() || id,
      description: (document.getElementById('agent-man-desc') as HTMLInputElement)?.value.trim(),
      system_prompt: (document.getElementById('agent-man-prompt') as HTMLTextAreaElement)?.value.trim(),
      tool_tier: (document.getElementById('agent-man-tier') as HTMLSelectElement)?.value || 'standard',
      rank: (document.getElementById('agent-man-rank') as HTMLSelectElement)?.value || 'private',
      squad: (document.getElementById('agent-man-squad') as HTMLInputElement)?.value.trim() || 'alpha',
      model_override: (document.getElementById('agent-man-model') as HTMLInputElement)?.value.trim() || '',
      provider_override: (document.getElementById('agent-man-provider') as HTMLInputElement)?.value.trim() || '',
      auto_share_to_hive: (document.getElementById('agent-man-auto-share') as HTMLInputElement)?.checked || false,
      auto_respond: (document.getElementById('agent-man-auto-respond') as HTMLInputElement)?.checked || false,
    };

    try {
      await api.createAgent(template);
      toast(`Agent "${template.name}" created!`, 'success');
      loadAgentsData();
    } catch (e) { toast((e as Error).message, 'error'); }
  });
}

// ── Load builtin templates ──────────────────────────
async function loadBuiltinTemplates(): Promise<void> {
  const grid = document.getElementById('builtin-templates-grid');
  if (!grid) return;
  try {
    const builtins = await api.getBuiltinAgents();
    if (!builtins.length) {
      grid.innerHTML = '<p class="text-muted">No built-in templates available.</p>';
      return;
    }
    grid.innerHTML = builtins.map(t => `
      <div class="template-card" data-template-id="${esc(t.id)}">
        <div class="template-name">${esc(t.name)}</div>
        <div class="template-desc">${esc(t.description)}</div>
        <div class="template-meta">
          <span class="tag tag-blue">${esc(t.tool_tier)}</span>
          <span class="tag tag-green">${esc(t.rank)}</span>
          <span class="tag">${esc(t.squad)}</span>
        </div>
        <button class="btn btn-sm btn-accent" onclick="useTemplate('${esc(t.id)}')">Use Template</button>
      </div>
    `).join('');
  } catch {
    grid.innerHTML = '<p class="text-muted">Failed to load templates.</p>';
  }
}

(window as any).useTemplate = async (id: string) => {
  try {
    const t = await api.getAgentDetail(id);
    prefillManualForm(t as AgentTemplate);
    document.querySelectorAll('.creator-mode-btn').forEach(b => b.classList.remove('active'));
    document.querySelector('.creator-mode-btn[data-mode="manual"]')?.classList.add('active');
    document.querySelectorAll('.creator-panel').forEach(el => el.classList.add('hidden'));
    document.getElementById('creator-manual')?.classList.remove('hidden');
    toast(`Template "${t.name}" loaded — customize and create`, 'info');
  } catch (e) { toast((e as Error).message, 'error'); }
};

// ── Agents table ────────────────────────────────────
async function loadAgentsTable(): Promise<void> {
  const el = document.getElementById('sdk-agents-table')!;
  try {
    const agents = await api.getHiveMindAgents().catch(() => []);
    const list = Array.isArray(agents) ? agents : ((agents as any).agents || []);
    const setText = (id: string, v: string | number) => {
      const e = document.getElementById(id);
      if (e) e.textContent = String(v);
    };
    setText('hive-agents-count', list.length);

    if (!list.length) {
      el.innerHTML = '<p class="text-muted">No agents registered.</p>';
      return;
    }
    el.innerHTML = `<table class="data-table"><thead><tr><th>ID</th><th>Name</th><th>Role</th><th>Rank</th><th>Squad</th><th>Actions</th></tr></thead><tbody>` +
      list.map(a =>
        `<tr>
          <td><code>${esc(a.agent_id)}</code></td>
          <td>${esc(a.name || '—')}</td>
          <td>${esc(a.role || '—')}</td>
          <td><span class="tag">${esc((a as any).rank || 'private')}</span></td>
          <td><span class="tag tag-blue">${esc(a.squad || '—')}</span></td>
          <td><button class="btn btn-sm btn-red" onclick="removeAgent('${esc(a.agent_id)}')">Remove</button></td>
        </tr>`
      ).join('') + '</tbody></table>';
  } catch {
    el.innerHTML = '<p class="text-muted">Failed to load agents.</p>';
  }
}

// ── Templates list ──────────────────────────────────
async function loadTemplatesList(): Promise<void> {
  const el = document.getElementById('agent-templates-list');
  if (!el) return;
  try {
    const data = await api.listAgents();
    const templates = data.templates || [];
    const setText = (id: string, v: string | number) => {
      const e = document.getElementById(id);
      if (e) e.textContent = String(v);
    };
    setText('hive-templates-count', templates.length);

    if (!templates.length) {
      el.innerHTML = '<p class="text-muted">No custom agent templates yet.</p>';
      return;
    }
    el.innerHTML = `<table class="data-table"><thead><tr><th>Name</th><th>Tier</th><th>Rank</th><th>Squad</th><th>Source</th><th>Actions</th></tr></thead><tbody>` +
      templates.map(t =>
        `<tr>
          <td><strong>${esc(t.name)}</strong><br><span class="text-muted">${esc(t.description || '').slice(0, 60)}</span></td>
          <td><span class="tag tag-blue">${esc(t.tool_tier)}</span></td>
          <td><span class="tag">${esc(t.rank)}</span></td>
          <td>${esc(t.squad)}</td>
          <td>${t.is_builtin ? '<span class="tag tag-green">built-in</span>' : `<span class="tag">${esc(t.source || 'custom')}</span>`}</td>
          <td>
            ${!t.is_builtin ? `<button class="btn btn-sm btn-red" onclick="deleteAgentTemplate('${esc(t.id)}')">Delete</button>` : ''}
          </td>
        </tr>`
      ).join('') + '</tbody></table>';
  } catch {
    el.innerHTML = '<p class="text-muted">Failed to load templates.</p>';
  }
}

(window as any).deleteAgentTemplate = async (id: string) => {
  try {
    await api.deleteAgent(id);
    toast('Agent template deleted', 'success');
    loadAgentsData();
  } catch (e) { toast((e as Error).message, 'error'); }
};

// ── Squads ──────────────────────────────────────────
async function loadSquads(): Promise<void> {
  const el = document.getElementById('squads-list');
  if (!el) return;
  try {
    const squads = await api.listSquads();
    if (!squads.length) {
      el.innerHTML = '<p class="text-muted">No squads configured.</p>';
      return;
    }
    el.innerHTML = squads.map(s => `
      <div class="squad-card">
        <h4>${esc(s.name)}</h4>
        <div class="squad-meta">
          <span class="tag tag-blue">${s.agent_count} agent${s.agent_count !== 1 ? 's' : ''}</span>
          <span class="text-muted">Branch: ${esc(s.branch)}</span>
        </div>
        <div class="squad-agents">
          ${s.agents.map((a: any) => `<span class="tag">${esc(a.agent_id || a.id || a)}</span>`).join(' ')}
        </div>
      </div>
    `).join('');
  } catch {
    el.innerHTML = '<p class="text-muted">Failed to load squads.</p>';
  }
}

function setupSquadCreator(): void {
  document.getElementById('create-squad-btn')?.addEventListener('click', () => {
    const card = document.getElementById('create-squad-card');
    if (card) card.style.display = card.style.display === 'none' ? '' : 'none';
  });

  document.getElementById('squad-submit-btn')?.addEventListener('click', async () => {
    const name = (document.getElementById('squad-name-input') as HTMLInputElement)?.value.trim();
    const agentsStr = (document.getElementById('squad-agents-input') as HTMLInputElement)?.value.trim();
    if (!name) { toast('Squad name required', 'error'); return; }
    const agents = agentsStr.split(',').map(s => s.trim()).filter(Boolean);
    try {
      await api.createSquad(name, agents);
      toast(`Squad "${name}" created`, 'success');
      const card = document.getElementById('create-squad-card');
      if (card) card.style.display = 'none';
      loadSquads();
    } catch (e) { toast((e as Error).message, 'error'); }
  });
}

// ── Main loader ─────────────────────────────────────
export async function loadAgentsData(): Promise<void> {
  await Promise.all([
    loadAgentsTable(),
    loadTemplatesList(),
    loadBuiltinTemplates(),
    loadSquads(),
  ]);
}

// ── Init ────────────────────────────────────────────
export function initAgents(): void {
  setupSubtabs();
  setupCreatorModes();
  setupPromptCreator();
  setupManualCreator();
  setupSquadCreator();
}
