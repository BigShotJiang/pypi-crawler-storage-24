class OpenvinoLayer:
    pass
