import os
import sqlite3
import tempfile
import time
from typing import cast
import unittest

import pluca
import pluca.invalidation
import pluca.memory


class TestCacheInvalidation(unittest.TestCase):

    def test_cache_enable_dependencies_default(self) -> None:
        cache = pluca.Cache(pluca.memory.Adapter())
        self.assertIs(cache.enable_dependencies, True)

    def test_cache_enable_dependencies_validation(self) -> None:
        with self.assertRaises(ValueError):
            pluca.Cache(pluca.memory.Adapter(),
                        enable_dependencies=cast(bool, 'nope'))

    def test_get_put_dependencies_cache_hit(self) -> None:
        cache = pluca.Cache(pluca.memory.Adapter())
        dependency_state = {'value': 1}
        calls = 0

        def dep() -> int:
            return dependency_state['value']

        def calc() -> str:
            nonlocal calls
            calls += 1
            return f'value-{calls}'

        self.assertEqual(
            cache.get_put('k', calc, dependency=dep),
            'value-1')
        self.assertEqual(
            cache.get_put('k', calc, dependency=dep),
            'value-1')
        self.assertEqual(calls, 1)

    def test_get_put_dependencies_recompute_on_change(self) -> None:
        cache = pluca.Cache(pluca.memory.Adapter())
        dependency_state = {'value': 1}
        calls = 0

        def dep() -> int:
            return dependency_state['value']

        def calc() -> str:
            nonlocal calls
            calls += 1
            return f'value-{calls}'

        self.assertEqual(
            cache.get_put('k', calc, dependency=dep),
            'value-1')
        dependency_state['value'] = 2
        self.assertEqual(
            cache.get_put('k', calc, dependency=dep),
            'value-2')
        self.assertEqual(calls, 2)

    def test_get_put_dependencies_max_age(self) -> None:
        cache = pluca.Cache(pluca.memory.Adapter())
        calls = 0

        def calc() -> str:
            nonlocal calls
            calls += 1
            return f'value-{calls}'

        def dep() -> int:
            return 1

        self.assertEqual(
            cache.get_put('k', calc, max_age=0, dependency=dep),
            'value-1')
        self.assertEqual(
            cache.get_put('k', calc, max_age=0, dependency=dep),
            'value-2')
        self.assertEqual(calls, 2)

    def test_decorator_dependencies(self) -> None:
        cache = pluca.Cache(pluca.memory.Adapter())
        dependency_state = {'value': 1}
        calls = 0

        def dep() -> int:
            return dependency_state['value']

        @cache(dependency=dep)
        def func(number: int) -> int:
            nonlocal calls
            calls += 1
            return number + calls

        self.assertEqual(func(1), 2)
        self.assertEqual(func(1), 2)
        dependency_state['value'] = 2
        self.assertEqual(func(1), 3)
        self.assertEqual(calls, 2)

    def test_get_put_dependency_disabled(self) -> None:
        cache = pluca.Cache(pluca.memory.Adapter(),
                            enable_dependencies=False)

        with self.assertRaises(pluca.CacheConfigurationError):
            cache.get_put('k', lambda: 'v', dependency=lambda: 1)

    def test_decorator_dependency_disabled(self) -> None:
        cache = pluca.Cache(pluca.memory.Adapter(),
                            enable_dependencies=False)

        @cache(dependency=lambda: 1)
        def func() -> str:
            return 'v'

        with self.assertRaises(pluca.CacheConfigurationError):
            func()

    def test_set_max_age_updates_dependency_companion(self) -> None:
        cache = pluca.Cache(pluca.memory.Adapter())
        state = {'value': 1}
        calls = 0

        def dep() -> int:
            return state['value']

        def calc() -> str:
            nonlocal calls
            calls += 1
            return f'value-{calls}'

        self.assertEqual(
            cache.get_put('k', calc, max_age=0.1, dependency=dep),
            'value-1')

        time.sleep(0.05)
        cache.set_max_age('k', max_age=1)
        time.sleep(0.2)

        self.assertEqual(
            cache.get_put('k', calc, dependency=dep),
            'value-1')
        self.assertEqual(calls, 1)


class TestInvalidationHelpers(unittest.TestCase):

    def test_file_mtime_missing(self) -> None:
        probe = pluca.invalidation.file_mtime('/definitely/not/found',
                                              missing='missing')
        self.assertEqual(probe(), 'missing')

    def test_file_mtime_updates(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = os.path.join(temp, 'data.txt')
            with open(path, 'w', encoding='utf-8') as file_obj:
                file_obj.write('v1')

            probe = pluca.invalidation.file_mtime(path)
            first = probe()

            time.sleep(0.01)
            with open(path, 'w', encoding='utf-8') as file_obj:
                file_obj.write('v2')

            second = probe()
            self.assertNotEqual(first, second)

    def test_sqlite_scalar(self) -> None:
        conn = sqlite3.connect(':memory:')
        self.addCleanup(conn.close)

        conn.execute('CREATE TABLE cache_dep (version INTEGER)')
        conn.execute('INSERT INTO cache_dep (version) VALUES (1)')
        conn.commit()

        probe = pluca.invalidation.sqlite_scalar(
            conn,
            'SELECT version FROM cache_dep LIMIT 1')

        self.assertEqual(probe(), 1)

        conn.execute('UPDATE cache_dep SET version = 2')
        conn.commit()

        self.assertEqual(probe(), 2)

    def test_env_var(self) -> None:
        name = 'PLUCA_TEST_INVALIDATION_ENV'
        old = os.environ.get(name)
        self.addCleanup(self._restore_env, name, old)

        probe = pluca.invalidation.env_var(name, default='unset')

        os.environ.pop(name, None)
        self.assertEqual(probe(), 'unset')

        os.environ[name] = 'set'
        self.assertEqual(probe(), 'set')

    @staticmethod
    def _restore_env(name: str, old: str | None) -> None:
        if old is None:
            os.environ.pop(name, None)
        else:
            os.environ[name] = old

    def test_combine(self) -> None:
        combined = pluca.invalidation.combine(lambda: 1, lambda: 'a')
        first = combined()
        second = combined()
        self.assertEqual(first, second)
        self.assertEqual(first[0], pluca.invalidation.CombineOperator.OR)

    def test_combine_requires_probes(self) -> None:
        with self.assertRaises(ValueError):
            pluca.invalidation.combine()

    def test_get_put_with_combined_dependency(self) -> None:
        cache = pluca.Cache(pluca.memory.Adapter())
        state = {'a': 1, 'b': 'x'}
        calls = 0

        def calc() -> str:
            nonlocal calls
            calls += 1
            return f'value-{calls}'

        combined = pluca.invalidation.combine(
            lambda: state['a'],
            lambda: state['b'])

        self.assertEqual(cache.get_put('k', calc, dependency=combined),
                         'value-1')
        self.assertEqual(cache.get_put('k', calc, dependency=combined),
                         'value-1')
        state['b'] = 'y'
        self.assertEqual(cache.get_put('k', calc, dependency=combined),
                         'value-2')

    def test_get_put_with_combined_dependency_and_operator(self) -> None:
        cache = pluca.Cache(pluca.memory.Adapter())
        state = {'a': 1, 'b': 'x'}
        calls = 0

        def calc() -> str:
            nonlocal calls
            calls += 1
            return f'value-{calls}'

        combined = pluca.invalidation.combine(
            lambda: state['a'],
            lambda: state['b'],
            operator=pluca.invalidation.CombineOperator.AND)

        self.assertEqual(cache.get_put('k', calc, dependency=combined),
                         'value-1')

        state['a'] = 2
        self.assertEqual(cache.get_put('k', calc, dependency=combined),
                         'value-1')

        state['b'] = 'y'
        self.assertEqual(cache.get_put('k', calc, dependency=combined),
                         'value-2')
