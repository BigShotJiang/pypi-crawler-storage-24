import dbm
import tempfile
import unittest
from pathlib import Path
from typing import Any

import pluca
import pluca.dbm
from pluca.test import AdapterTester


class _TestMixin:
    _tempdir: tempfile.TemporaryDirectory  # type: ignore [type-arg]

    def _open_db(self) -> None:
        assert self._tempdir is not None

        self._db = dbm.open(f'{self._tempdir.name}/test', 'n')

    def tearDown(self) -> None:
        self._db.close()

    def get_adapter(self) -> pluca.dbm.Adapter:
        return pluca.dbm.Adapter(self._db)

    @classmethod
    def setUpClass(cls) -> None:
        cls._tempdir = tempfile.TemporaryDirectory()

    @classmethod
    def tearDownClass(cls) -> None:
        cls._tempdir.cleanup()


class TestDbm(_TestMixin, AdapterTester, unittest.TestCase):

    def setUp(self) -> None:
        self._open_db()

    def test_put_max_age_zero(self) -> None:
        cache = self.get_cache()
        cache.put('foo', 'bar', max_age=0)
        with self.assertRaises(KeyError):
            cache.get('foo')


class TestGeneric(unittest.TestCase):

    def test_constructor_accept_filename(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            cache = pluca.Cache(pluca.dbm.Adapter(f'{tempdir}/db'))
            cache.put('foo', 'bar')
            self.assertEqual('bar', cache.get('foo'))

    def test_constructor_accept_path(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            cache = pluca.Cache(pluca.dbm.Adapter(Path(tempdir) / 'db'))
            cache.put('foo', 'bar')
            self.assertEqual('bar', cache.get('foo'))

    def test_backend_error_reraised_with_cause(self) -> None:
        class _BrokenDbm:
            def __setitem__(self, key: Any, value: Any) -> None:
                _ = (key, value)
                raise OSError('disk full')

            def close(self) -> None:
                return None

        cache = pluca.Cache(pluca.dbm.Adapter(_BrokenDbm()))

        with self.assertRaises(pluca.CacheBackendError) as ctx:
            cache.put('foo', 'bar')

        self.assertIsInstance(ctx.exception.__cause__, OSError)

    def test_shutdown_does_not_close_external_db(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            db = dbm.open(f'{tempdir}/db', 'n')

            cache = pluca.Cache(pluca.dbm.Adapter(db))
            cache.put('foo', 'bar')
            cache.shutdown()

            db[b'probe'] = b'1'
            self.assertEqual(db[b'probe'], b'1')
            db.close()
