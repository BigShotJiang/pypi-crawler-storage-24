from __future__ import annotations

import multiprocessing
from multiprocessing.managers import DictProxy, SyncManager
import unittest
from typing import Any, cast

import pluca
import pluca.multiprocessing
from pluca.test import AdapterTester


class TestMultiprocessing(AdapterTester, unittest.TestCase):
    _manager: SyncManager

    @classmethod
    def setUpClass(cls) -> None:
        cls._manager = multiprocessing.Manager()

    @classmethod
    def tearDownClass(cls) -> None:
        cls._manager.shutdown()

    def get_adapter(self) -> pluca.multiprocessing.Adapter:
        shared_dict: DictProxy[Any, tuple[bytes, float | None]] = (
            self._manager.dict()
        )
        return pluca.multiprocessing.Adapter(shared_dict=shared_dict)

    def test_put_max_age_zero(self) -> None:
        cache = self.get_cache()
        cache.put('foo', 'bar', max_age=0)
        with self.assertRaises(KeyError):
            cache.get('foo')


class TestMultiprocessingGeneric(unittest.TestCase):

    def test_shared_storage_between_cache_instances(self) -> None:
        manager = multiprocessing.Manager()
        try:
            shared_dict: DictProxy[Any, tuple[bytes, float | None]] = (
                manager.dict()
            )
            cache1 = pluca.Cache(
                pluca.multiprocessing.Adapter(shared_dict=shared_dict)
            )
            cache2 = pluca.Cache(
                pluca.multiprocessing.Adapter(shared_dict=shared_dict)
            )

            cache1.put('k', 'v')

            self.assertEqual(cache2.get('k'), 'v')
        finally:
            manager.shutdown()

    def test_shutdown_does_not_shutdown_external_dict(self) -> None:
        manager = multiprocessing.Manager()
        try:
            shared_dict: DictProxy[Any, tuple[bytes, float | None]] = (
                manager.dict()
            )
            cache = pluca.Cache(
                pluca.multiprocessing.Adapter(shared_dict=shared_dict)
            )
            cache.put('foo', 'bar')

            cache.shutdown()

            shared_dict['probe'] = (b'1', None)
            self.assertEqual(shared_dict['probe'], (b'1', None))
        finally:
            manager.shutdown()

    def test_constructor_requires_dictproxy(self) -> None:
        with self.assertRaises(ValueError):
            pluca.multiprocessing.Adapter(shared_dict=cast(Any, {}))
