from __future__ import annotations

from collections.abc import Iterable, Mapping
import multiprocessing
from multiprocessing.managers import DictProxy, SyncManager
import pickle
import time
from typing import Any, cast

import pluca


class MultiprocessingAdapter:
    """Multiprocessing manager-dict cache adapter for pluca.

    Args:
        shared_dict: Shared dictionary proxy created by
            ``multiprocessing.Manager().dict()``. If omitted, a new manager
            and shared dictionary are created and owned by this adapter.

    """

    def __init__(
        self,
        shared_dict: DictProxy[Any, tuple[bytes, float | None]] | None = None
    ) -> None:
        if shared_dict is not None and not isinstance(shared_dict, DictProxy):
            raise ValueError('shared_dict must be a multiprocessing DictProxy')

        self._manager: SyncManager | None = None
        self._owns_manager = shared_dict is None

        if shared_dict is None:
            self._manager = multiprocessing.Manager()
            shared_dict = cast(DictProxy[Any, tuple[bytes, float | None]],
                               self._manager.dict())

        assert shared_dict is not None
        self._storage = shared_dict

    def put_mapped(self, mkey: Any, value: Any,
                   max_age: float | None = None) -> None:
        expires = None if max_age is None else time.time() + max_age
        try:
            self._storage[mkey] = (pickle.dumps(value), expires)
        except (EOFError, OSError) as ex:
            raise pluca.CacheBackendError(
                'Multiprocessing backend failed during put'
            ) from ex

    def get_mapped(self, mkey: Any) -> Any:
        try:
            payload, expires = self._storage[mkey]
        except (EOFError, OSError) as ex:
            raise pluca.CacheBackendError(
                'Multiprocessing backend failed during get'
            ) from ex

        if expires is not None and expires <= time.time():
            try:
                del self._storage[mkey]
            except KeyError:
                pass
            except (EOFError, OSError) as ex:
                raise pluca.CacheBackendError(
                    'Multiprocessing backend failed during expired cleanup'
                ) from ex
            raise KeyError(mkey)

        return pickle.loads(payload)

    def remove_mapped(self, mkey: Any) -> None:
        try:
            _payload, expires = self._storage[mkey]
            del self._storage[mkey]
        except (EOFError, OSError) as ex:
            raise pluca.CacheBackendError(
                'Multiprocessing backend failed during remove'
            ) from ex

        if expires is not None and expires <= time.time():
            raise KeyError(mkey)

    def set_max_age_mapped(self, mkey: Any,
                           max_age: float | None = None) -> None:
        try:
            _payload, expires = self._storage[mkey]
        except (EOFError, OSError) as ex:
            raise pluca.CacheBackendError(
                'Multiprocessing backend failed during set_max_age read'
            ) from ex

        if expires is not None and expires <= time.time():
            try:
                del self._storage[mkey]
            except KeyError:
                pass
            except (EOFError, OSError) as ex:
                raise pluca.CacheBackendError(
                    'Multiprocessing backend failed during expired cleanup'
                ) from ex
            raise KeyError(mkey)

        new_expires = None if max_age is None else time.time() + max_age
        try:
            self._storage[mkey] = (_payload, new_expires)
        except (EOFError, OSError) as ex:
            raise pluca.CacheBackendError(
                'Multiprocessing backend failed during set_max_age write'
            ) from ex

    def flush(self) -> None:
        try:
            self._storage.clear()
        except (EOFError, OSError) as ex:
            raise pluca.CacheBackendError(
                'Multiprocessing backend failed during flush'
            ) from ex

    def has_mapped(self, mkey: Any) -> bool:
        try:
            _payload, expires = self._storage[mkey]
        except KeyError:
            return False
        except (EOFError, OSError) as ex:
            raise pluca.CacheBackendError(
                'Multiprocessing backend failed during has'
            ) from ex

        if expires is None or expires > time.time():
            return True

        try:
            del self._storage[mkey]
        except KeyError:
            pass
        except (EOFError, OSError) as ex:
            raise pluca.CacheBackendError(
                'Multiprocessing backend failed during expired cleanup'
            ) from ex

        return False

    def put_many_mapped(self,
                        data: Mapping[Any, Any] | Iterable[tuple[Any, Any]],
                        max_age: float | None = None) -> None:
        if isinstance(data, Mapping):
            data = data.items()

        for mkey, value in data:
            self.put_mapped(mkey, value, max_age)

    def get_many_mapped(self, keys: Iterable[Any],
                        default: Any = ...) -> list[tuple[Any, Any]]:
        data = []
        for mkey in keys:
            try:
                value = self.get_mapped(mkey)
            except KeyError:
                if default is Ellipsis:
                    continue
                value = default
            data.append((mkey, value))
        return data

    def remove_many_mapped(self, keys: Iterable[Any]) -> None:
        for mkey in keys:
            try:
                self.remove_mapped(mkey)
            except KeyError:
                pass

    def gc(self) -> None:
        """Delete expired entries from shared storage."""
        now = time.time()
        try:
            keys = tuple(self._storage.keys())
            for key in keys:
                _payload, expires = self._storage[key]
                if expires is not None and expires <= now:
                    del self._storage[key]
        except KeyError:
            pass
        except (EOFError, OSError) as ex:
            raise pluca.CacheBackendError(
                'Multiprocessing backend failed during gc'
            ) from ex

    def shutdown(self) -> None:
        """Shutdown owned manager resources, if any."""
        if not self._owns_manager or self._manager is None:
            return

        try:
            self._manager.shutdown()
        except (EOFError, OSError) as ex:
            raise pluca.CacheBackendError(
                'Multiprocessing backend failed during shutdown'
            ) from ex


Adapter = MultiprocessingAdapter
