
import argparse
import dbm.dumb
import gc
import multiprocessing
import os
import random
import string
import sys
import time
import tempfile
from typing import Any, NamedTuple
from collections.abc import Callable

import pluca
import pluca.file
import pluca.memory
import pluca.multiprocessing
import pluca.null
import pluca.sqlite3
import pluca.dbm


class _ATuple(NamedTuple):
    attr1: str
    attr2: float


class _Durations(NamedTuple):
    put: float
    get: float
    get_miss: float
    get_mixed: float
    init_teardown: float


class _Random(random.Random):

    def __init__(self) -> None:
        super().__init__(12345)  # NB: fixed seed.

    def random_string(self) -> str:
        return ''.join(self.choice(string.ascii_letters) for i in range(50))

    def random_tuple(self) -> tuple[Any, ...]:
        data = [
            self.randint(-1_000_000, 1_000_000),
            self.random_string(),
            _ATuple(attr1=self.random_string(), attr2=self.random()),
            self.random(),
            True,
            False,
        ]
        self.shuffle(data)
        return tuple(data)


def _get_data(nr: int) -> list[tuple[tuple[Any, ...], tuple[Any, ...]]]:
    data = []
    prng = _Random()
    for _ in range(nr):
        data.append((prng.random_tuple(), prng.random_tuple()))
    return data


def _get_miss_data(
    data: list[tuple[tuple[Any, ...], tuple[Any, ...]]]
) -> list[tuple[tuple[Any, ...], tuple[Any, ...]]]:
    return [
        (key + ('__pluca_benchmark_miss__',), value)
        for key, value in data
    ]


def _warm_up(adapter_factory: Callable[..., Any],
             hit_item: tuple[tuple[Any, ...], tuple[Any, ...]],
             miss_item: tuple[tuple[Any, ...], tuple[Any, ...]],
             **kwargs: Any) -> None:
    cache = pluca.Cache(adapter_factory(**kwargs))
    hit_key, hit_value = hit_item
    miss_key, miss_value = miss_item
    cache.put(hit_key, hit_value)
    cache.get(hit_key, hit_value)
    cache.get(miss_key, miss_value)
    cache.flush()
    cache.shutdown()

    cache = pluca.Cache(adapter_factory(**kwargs))
    cache.put(hit_key, hit_value, 0)
    cache.get(hit_key, hit_value)
    cache.shutdown()


def _run_benchmark(entries: int,
                   adapter_factory: Callable[..., Any],
                   data: list[tuple[tuple[Any, ...], tuple[Any, ...]]],
                   miss_data: list[tuple[tuple[Any, ...], tuple[Any, ...]]],
                   prng: _Random,
                   **kwargs: Any) -> _Durations:
    gc.collect()
    init_teardown_duration = 0.0
    init_start = time.perf_counter()
    cache = pluca.Cache(adapter_factory(**kwargs))
    init_teardown_duration += time.perf_counter() - init_start
    put_start = time.perf_counter()
    for key, value in data:
        cache.put(key, value)
    put_end = time.perf_counter()

    get_start = time.perf_counter()
    for key, value in data:
        cache.get(key, value)
    get_end = time.perf_counter()

    get_miss_start = time.perf_counter()
    for key, value in miss_data:
        cache.get(key, value)
    get_miss_end = time.perf_counter()

    teardown_start = time.perf_counter()
    cache.flush()
    del cache
    gc.collect()
    init_teardown_duration += time.perf_counter() - teardown_start

    exp = [(0 if prng.random() > 0.5 else None) for _ in range(entries)]
    init_start = time.perf_counter()
    cache = pluca.Cache(adapter_factory(**kwargs))
    init_teardown_duration += time.perf_counter() - init_start
    get_mixed_start = time.perf_counter()
    for i, (key, value) in enumerate(data):
        cache.put(key, value, exp[i])
        cache.get(key, value)
    get_mixed_end = time.perf_counter()

    teardown_start = time.perf_counter()
    cache.shutdown()
    init_teardown_duration += time.perf_counter() - teardown_start

    gc.collect()

    return _Durations(
        put=put_end - put_start,
        get=get_end - get_start,
        get_miss=get_miss_end - get_miss_start,
        get_mixed=get_mixed_end - get_mixed_start,
        init_teardown=init_teardown_duration,
    )


def print_header(entries: int) -> None:
    unm = os.uname()
    print(
        f'\nBenchmarking pluca {pluca.__version__} with {entries:,} '
        'cache entries on\n'
        f'Python {sys.version} ({sys.implementation.name})\n'
        f'and {unm.sysname} {unm.release} ({unm.machine})\n'
        '                            put()         get()      put()+get()'
        '    get() 50%\n'
        'Cache                   secs     op/s secs     op/s secs     op/s'
        ' secs     op/s\n'
        '----------------------- ------------- ------------- -------------'
        ' -------------\n',
        end=''
    )


def benchmark(name: str, entries: int,
              adapter_factory: Callable[..., Any], **kwargs: Any) -> None:
    prng = _Random()

    data = _get_data(entries)
    miss_data = _get_miss_data(data)

    if data and miss_data:
        _warm_up(adapter_factory, data[0], miss_data[0], **kwargs)

    gc_enabled = gc.isenabled()

    gc.disable()
    try:
        durations = _run_benchmark(entries, adapter_factory, data, miss_data,
                                   prng, **kwargs)
    finally:
        if gc_enabled:
            gc.enable()

    print(f'{name:22.22} '
          f'{durations.put:4.1f} {entries / durations.put:9,.1f}'
          f'{durations.get:4.1f} {entries / durations.get:9,.1f}'
          f'{durations.get_miss:4.1f} {entries / durations.get_miss:9,.1f}'
          f'{durations.get_mixed:4.1f} {entries / durations.get_mixed:9,.1f}'
          )
    print(f'{"":22} init/teardown: {durations.init_teardown:4.1f} secs')


def _main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('-e', '--entries',
                        type=int,
                        help='Cache entries to test (default: %(default)d)',
                        default=10_000)
    args = parser.parse_args()

    print_header(args.entries)

    benchmark('File lock=None', args.entries, pluca.file.Adapter,
              locking=None)

    if os.name != 'nt':
        benchmark('File lock=flock', args.entries,
                  pluca.file.Adapter, locking='flock')

    if os.name == 'nt':
        benchmark('File lock=msvcrt', args.entries,
                  pluca.file.Adapter, locking='msvcrt')

    benchmark('File lock=mkdir', args.entries,
              pluca.file.Adapter, locking='mkdir')

    benchmark('Memory unbounded', args.entries, pluca.memory.Adapter)
    benchmark(f'Memory {args.entries // 2:,}',
              args.entries, pluca.memory.Adapter,
              max_entries=args.entries // 2)
    benchmark(f'Memory {args.entries // 2:,} prune=20%',
              args.entries, pluca.memory.Adapter,
              max_entries=args.entries // 2,
              prune=int(args.entries * 0.2))

    with multiprocessing.Manager() as manager:
        benchmark('MP Manager().dict()',
                  args.entries, pluca.multiprocessing.Adapter,
                  shared_dict=manager.dict())

    benchmark('Null', args.entries, pluca.null.Adapter)

    with tempfile.NamedTemporaryFile() as ctx:
        benchmark('SQLite file',
                  args.entries, pluca.sqlite3.Adapter, filename=ctx.name)

    with tempfile.NamedTemporaryFile() as ctx:
        benchmark('SQLite file autocommit',
                  args.entries, pluca.sqlite3.Adapter,
                  filename=ctx.name, isolation_level=None)

    with tempfile.NamedTemporaryFile() as ctx:
        benchmark('SQLite file WAL',
                  args.entries, pluca.sqlite3.Adapter,
                  filename=ctx.name, pragma={'journal_mode': 'WAL'})

    benchmark('SQLite :memory:',
              args.entries, pluca.sqlite3.Adapter, filename=':memory:')

    with tempfile.TemporaryDirectory() as tempdir:
        dbd = dbm.dumb.open(f'{tempdir}/db', 'n')
        benchmark('DBM dumb', args.entries, pluca.dbm.Adapter, db=dbd)
        dbd.close()


if __name__ == '__main__':
    _main()
