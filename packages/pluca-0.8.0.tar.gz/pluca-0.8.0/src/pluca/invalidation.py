"""Helpers for dependency-based cache invalidation."""

import os
from collections.abc import Callable, Iterable
from enum import Enum
import hashlib
from pathlib import Path
import sqlite3
from typing import Any


class CombineOperator(Enum):
    """Operators available for combined dependency probes."""

    OR = 1
    AND = 2


def _tokenize(value: Any) -> str:
    algo = hashlib.sha1()
    algo.update(repr(value).encode('utf-8'))
    return algo.hexdigest()


def file_mtime(path: str | Path,
               *,
               nanoseconds: bool = True,
               missing: Any = None) -> Callable[[], Any]:
    """Build a dependency probe from file modification time.

    Args:
        path: File path to monitor.
        nanoseconds: Return ``st_mtime_ns`` when ``True``, otherwise
            ``st_mtime``.
        missing: Value returned when the file does not exist.

    Returns:
        A zero-argument callable that reads file mtime.

    """
    file_path = Path(path)

    def probe() -> Any:
        try:
            stat = file_path.stat()
        except FileNotFoundError:
            return missing

        if nanoseconds:
            return stat.st_mtime_ns
        return stat.st_mtime

    return probe


def sqlite_scalar(connection: sqlite3.Connection,
                  query: str,
                  params: Iterable[Any] = ()) -> Callable[[], Any]:
    """Build a dependency probe from a SQLite scalar query.

    Args:
        connection: SQLite connection used to execute ``query``.
        query: SQL statement returning a single row/column.
        params: Positional parameters passed to ``query``.

    Returns:
        A zero-argument callable returning the first column of the first row,
        or ``None`` when no rows are returned.

    """
    query_params = tuple(params)

    def probe() -> Any:
        cursor = connection.cursor()
        cursor.execute(query, query_params)
        row = cursor.fetchone()
        cursor.close()
        if row is None:
            return None
        return row[0]

    return probe


def env_var(name: str,
            default: str | None = None) -> Callable[[], str | None]:
    """Build a dependency probe from an environment variable.

    Args:
        name: Environment variable name.
        default: Value returned when ``name`` is not defined.

    Returns:
        A zero-argument callable that reads ``name`` from ``os.environ``.

    """
    def probe() -> str | None:
        return os.environ.get(name, default)

    return probe


def combine(*probes: Callable[[], Any],
            operator: CombineOperator = CombineOperator.OR
            ) -> Callable[[], tuple[CombineOperator, int]]:
    """Combine dependency probes into a single dependency callable.

    Args:
        *probes: Dependency callables.
        operator: Invalidation operator.

    Returns:
        A zero-argument callable returning a token that only changes
        according to ``operator`` semantics.

    """
    if not probes:
        raise ValueError('combine() requires at least one probe')

    baseline: tuple[str, ...] | None = None
    pending_changed: list[bool] = []
    version = 0

    def combined() -> tuple[CombineOperator, int]:
        nonlocal baseline, pending_changed, version

        current = tuple(_tokenize(probe()) for probe in probes)

        if baseline is None:
            baseline = current
            pending_changed = [False] * len(current)
            return operator, version

        changed = tuple(cur != base for cur, base in zip(current, baseline))

        if operator is CombineOperator.OR:
            if any(changed):
                version += 1
                baseline = current
                pending_changed = [False] * len(current)
            return operator, version

        for idx, is_changed in enumerate(changed):
            pending_changed[idx] = is_changed

        if all(pending_changed):
            version += 1
            baseline = current
            pending_changed = [False] * len(current)

        return operator, version

    return combined
