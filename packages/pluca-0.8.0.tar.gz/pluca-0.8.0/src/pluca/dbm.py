from collections.abc import Iterable, Mapping
import dbm
import pickle
import time
from pathlib import Path
from typing import Any, NamedTuple

import pluca

_DBM_EXCEPTIONS = dbm.error


class _Entry(NamedTuple):
    value: Any
    expires: float | None

    @property
    def is_fresh(self) -> bool:
        return self.expires is None or self.expires > time.time()


class DbmAdapter:
    """DBM cache adapter for pluca.

    Args:
        db: DBM filename/path or an already opened DBM-like object.
            When an opened object is provided, it is not closed by this
            adapter during shutdown.

    """

    def __init__(self, db: Any):
        self._owns_db = isinstance(db, (str, Path))
        try:
            if isinstance(db, str):
                self.dbm = dbm.open(db, 'c')
            elif isinstance(db, Path):
                self.dbm = dbm.open(str(db), 'c')
            else:
                self.dbm = db
        except _DBM_EXCEPTIONS as ex:
            raise pluca.CacheBackendError(
                'DBM backend failed during initialization'
            ) from ex

    def put_mapped(self, mkey: Any, value: Any,
                   max_age: float | None = None) -> None:
        expires = None if max_age is None else time.time() + max_age
        try:
            self.dbm[mkey] = pickle.dumps(_Entry(value, expires))
        except _DBM_EXCEPTIONS as ex:
            raise pluca.CacheBackendError(
                'DBM backend failed during put'
            ) from ex

    def get_mapped(self, mkey: Any) -> Any:
        try:
            entry = pickle.loads(self.dbm[mkey])
        except KeyError:
            raise
        except _DBM_EXCEPTIONS as ex:
            raise pluca.CacheBackendError(
                'DBM backend failed during get'
            ) from ex
        if not entry.is_fresh:
            try:
                del self.dbm[mkey]
            except _DBM_EXCEPTIONS as ex:
                raise pluca.CacheBackendError(
                    'DBM backend failed during expired entry cleanup'
                ) from ex
            raise KeyError(mkey)
        return entry.value

    def remove_mapped(self, mkey: Any) -> None:
        try:
            del self.dbm[mkey]
        except KeyError:
            raise
        except _DBM_EXCEPTIONS as ex:
            raise pluca.CacheBackendError(
                'DBM backend failed during remove'
            ) from ex

    def set_max_age_mapped(self, mkey: Any,
                           max_age: float | None = None) -> None:
        try:
            entry = pickle.loads(self.dbm[mkey])
        except KeyError:
            raise
        except _DBM_EXCEPTIONS as ex:
            raise pluca.CacheBackendError(
                'DBM backend failed during set_max_age read'
            ) from ex
        if not entry.is_fresh:
            try:
                del self.dbm[mkey]
            except _DBM_EXCEPTIONS as ex:
                raise pluca.CacheBackendError(
                    'DBM backend failed during expired entry cleanup'
                ) from ex
            raise KeyError(mkey)

        expires = None if max_age is None else time.time() + max_age
        try:
            self.dbm[mkey] = pickle.dumps(_Entry(entry.value, expires))
        except _DBM_EXCEPTIONS as ex:
            raise pluca.CacheBackendError(
                'DBM backend failed during set_max_age write'
            ) from ex

    def flush(self) -> None:
        try:
            for key in self.dbm.keys():
                del self.dbm[key]
        except _DBM_EXCEPTIONS as ex:
            raise pluca.CacheBackendError(
                'DBM backend failed during flush'
            ) from ex

    def has_mapped(self, mkey: Any) -> bool:
        try:
            return mkey in self.dbm
        except _DBM_EXCEPTIONS as ex:
            raise pluca.CacheBackendError(
                'DBM backend failed during has'
            ) from ex

    def put_many_mapped(self,
                        data: Mapping[Any, Any] | Iterable[tuple[Any, Any]],
                        max_age: float | None = None) -> None:
        raise NotImplementedError

    def get_many_mapped(self, keys: Iterable[Any],
                        default: Any = ...) -> list[tuple[Any, Any]]:
        raise NotImplementedError

    def remove_many_mapped(self, keys: Iterable[Any]) -> None:
        raise NotImplementedError

    def gc(self) -> None:
        """Delete expired entries and compact the DBM store when possible."""
        try:
            for key in self.dbm.keys():
                entry = pickle.loads(self.dbm[key])
                if not entry.is_fresh:
                    del self.dbm[key]

            try:
                self.dbm.reorganize()  # type: ignore[attr-defined]
            except AttributeError:
                pass
        except _DBM_EXCEPTIONS as ex:
            raise pluca.CacheBackendError(
                'DBM backend failed during gc'
            ) from ex

    def shutdown(self) -> None:
        """Close the underlying DBM database handle."""
        if not self._owns_db:
            return

        try:
            self.dbm.close()
        except _DBM_EXCEPTIONS as ex:
            raise pluca.CacheBackendError(
                'DBM backend failed during shutdown'
            ) from ex


Adapter = DbmAdapter
