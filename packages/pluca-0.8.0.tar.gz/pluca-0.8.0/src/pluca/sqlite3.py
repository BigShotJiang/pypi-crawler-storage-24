import pickle
import re
import sqlite3
import time
from collections.abc import Iterable, Mapping
from typing import Any

import pluca

_VALID_IDENTIFIER = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')


def _validate_identifier(name: str, kind: str) -> str:
    if not _VALID_IDENTIFIER.fullmatch(name):
        raise ValueError(f'Invalid SQLite {kind} identifier: {name!r}')
    return name


class SQLite3Adapter:
    """SQLite3 cache adapter for pluca.

    Args:
        filename: SQLite database filename or ``':memory:'``.
        pragma: Optional SQLite PRAGMA settings applied during
            initialization.
        **kwargs: Extra keyword arguments forwarded to
            ``sqlite3.connect()``.

    """

    def __init__(self,
                 filename: str,
                 pragma: Mapping[str, str | float | bool] | None = None,
                 **kwargs: Any) -> None:
        try:
            self._conn = sqlite3.connect(filename, **kwargs)
        except sqlite3.Error as ex:
            raise pluca.CacheBackendError(
                'SQLite backend failed during connect'
            ) from ex
        self._table = 'cache'
        self._k_col = 'k'
        self._v_col = 'v'
        self._exp_col = 'expires'
        self._ph = '?'

        _validate_identifier(self._table, 'table')
        _validate_identifier(self._k_col, 'column')
        _validate_identifier(self._v_col, 'column')
        _validate_identifier(self._exp_col, 'column')

        try:
            if pragma:
                for name, value in pragma.items():
                    _validate_identifier(name, 'PRAGMA')
                    self._conn.execute(f'PRAGMA {name} = {value!r}')

            self._conn.execute(f'CREATE TABLE IF NOT EXISTS {self._table} ('
                               f'{self._k_col} VARCHAR PRIMARY KEY, '
                               f'{self._v_col} BLOB NOT NULL, '
                               f'{self._exp_col} FLOAT) '
                               'WITHOUT ROWID')
        except sqlite3.Error as ex:
            raise pluca.CacheBackendError(
                'SQLite backend failed during initialization'
            ) from ex

        self.filename = filename

    def _commit(self) -> None:
        if not self._conn.in_transaction:
            return
        try:
            self._conn.commit()
        except sqlite3.Error as ex:
            raise pluca.CacheBackendError(
                'SQLite backend failed during commit'
            ) from ex

    def put_mapped(self, mkey: Any, value: Any,
                   max_age: float | None = None) -> None:
        svalue = pickle.dumps(value)
        expires = None if max_age is None else time.time() + max_age

        try:
            cur = self._conn.cursor()
            cur.execute(f'INSERT INTO {self._table} '
                        f'({self._k_col}, {self._v_col}, {self._exp_col}) '
                        f'VALUES ({self._ph}, {self._ph}, {self._ph}) '
                        f'ON CONFLICT({self._k_col}) DO UPDATE SET '
                        f'{self._v_col} = {self._ph}, '
                        f'{self._exp_col} = {self._ph}',
                        (mkey, svalue, expires, svalue, expires))
            cur.close()
        except sqlite3.Error as ex:
            raise pluca.CacheBackendError(
                'SQLite backend failed during put'
            ) from ex
        self._commit()

    def put_many_mapped(self,
                        data: Mapping[Any, Any] | Iterable[tuple[Any, Any]],
                        max_age: float | None = None) -> None:
        if isinstance(data, Mapping):
            data = data.items()

        expires = None if max_age is None else time.time() + max_age
        values = []
        for mkey, value in data:
            svalue = pickle.dumps(value)
            values.append((mkey, svalue, expires, svalue, expires))

        if not values:
            return

        started_transaction = False
        try:
            if not self._conn.in_transaction:
                self._conn.execute('BEGIN')
                started_transaction = True

            cur = self._conn.cursor()
            cur.executemany(f'INSERT INTO {self._table} '
                            f'({self._k_col}, {self._v_col}, {self._exp_col}) '
                            f'VALUES ({self._ph}, {self._ph}, {self._ph}) '
                            f'ON CONFLICT({self._k_col}) DO UPDATE SET '
                            f'{self._v_col} = {self._ph}, '
                            f'{self._exp_col} = {self._ph}',
                            values)
            cur.close()
        except sqlite3.Error as ex:
            if started_transaction and self._conn.in_transaction:
                try:
                    self._conn.rollback()
                except sqlite3.Error:
                    pass
            raise pluca.CacheBackendError(
                'SQLite backend failed during put_many'
            ) from ex

        self._commit()

    def get_mapped(self, mkey: Any) -> Any:
        try:
            cur = self._conn.cursor()
            cur.execute(f'SELECT {self._v_col}, {self._exp_col} '
                        f'FROM {self._table} '
                        f'WHERE {self._k_col} = {self._ph} '
                        f'AND ({self._exp_col} IS NULL '
                        f'OR {self._exp_col} > {self._ph})',
                        (mkey, time.time()))
            row = cur.fetchone()
            cur.close()
        except sqlite3.Error as ex:
            raise pluca.CacheBackendError(
                'SQLite backend failed during get'
            ) from ex
        if not row:
            raise KeyError(mkey)
        return pickle.loads(row[0])

    def get_many_mapped(self, keys: Iterable[Any],
                        default: Any = ...) -> list[tuple[Any, Any]]:
        all_mkeys = list(dict.fromkeys(keys))
        if not all_mkeys:
            return []

        in_list = ', '.join([self._ph] * len(all_mkeys))
        args: list[Any] = list(all_mkeys)
        args.append(time.time())

        values_by_key: dict[Any, Any] = {}

        try:
            cur = self._conn.cursor()
            cur.execute(f'SELECT {self._k_col}, {self._v_col} '
                        f'FROM {self._table} '
                        f'WHERE {self._k_col} IN ({in_list}) '
                        f'AND ({self._exp_col} IS NULL '
                        f'OR {self._exp_col} > {self._ph})',
                        tuple(args))

            for row in cur.fetchall():
                values_by_key[row[0]] = pickle.loads(row[1])

            cur.close()
        except sqlite3.Error as ex:
            raise pluca.CacheBackendError(
                'SQLite backend failed during get_many'
            ) from ex

        if default is not Ellipsis:
            for key in all_mkeys:
                if key not in values_by_key:
                    values_by_key[key] = default

        result = []
        for key in all_mkeys:
            if key in values_by_key:
                result.append((key, values_by_key[key]))
        return result

    def remove_mapped(self, mkey: Any) -> None:
        try:
            cur = self._conn.cursor()
            cur.execute(f'DELETE FROM {self._table} '
                        f'WHERE {self._k_col} = {self._ph}',
                        (mkey,))
            rowcount = cur.rowcount
            cur.close()
        except sqlite3.Error as ex:
            raise pluca.CacheBackendError(
                'SQLite backend failed during remove'
            ) from ex
        self._commit()
        if rowcount == 0:
            raise KeyError(mkey)

    def set_max_age_mapped(self, mkey: Any,
                           max_age: float | None = None) -> None:
        expires = None if max_age is None else time.time() + max_age

        try:
            cur = self._conn.cursor()
            cur.execute(f'UPDATE {self._table} '
                        f'SET {self._exp_col} = {self._ph} '
                        f'WHERE {self._k_col} = {self._ph} '
                        f'AND ({self._exp_col} IS NULL '
                        f'OR {self._exp_col} > {self._ph})',
                        (expires, mkey, time.time()))
            rowcount = cur.rowcount
            cur.close()
        except sqlite3.Error as ex:
            raise pluca.CacheBackendError(
                'SQLite backend failed during set_max_age'
            ) from ex
        self._commit()

        if rowcount == 0:
            raise KeyError(mkey)

    def remove_many_mapped(self, keys: Iterable[Any]) -> None:
        items = tuple(keys)
        if not items:
            return

        try:
            cur = self._conn.cursor()
            cur.execute(f'DELETE FROM {self._table} '
                        f'WHERE {self._k_col} '
                        f'IN ({", ".join([self._ph] * len(items))})',
                        items)
            cur.close()
        except sqlite3.Error as ex:
            raise pluca.CacheBackendError(
                'SQLite backend failed during remove_many'
            ) from ex
        self._commit()

    def flush(self) -> None:
        try:
            cur = self._conn.cursor()
            cur.execute(f'DELETE FROM {self._table}')
            cur.close()
        except sqlite3.Error as ex:
            raise pluca.CacheBackendError(
                'SQLite backend failed during flush'
            ) from ex
        self._commit()

    def has_mapped(self, mkey: Any) -> bool:
        try:
            cur = self._conn.cursor()
            cur.execute('SELECT EXISTS('
                        f'SELECT * FROM {self._table} '
                        f'WHERE {self._k_col} = {self._ph} '
                        f'AND ({self._exp_col} IS NULL '
                        f'OR {self._exp_col} > {self._ph}))',
                        (mkey, time.time()))
            has = bool(cur.fetchone()[0])
            cur.close()
            return has
        except sqlite3.Error as ex:
            raise pluca.CacheBackendError(
                'SQLite backend failed during has'
            ) from ex

    def gc(self) -> None:
        """Delete expired rows, commit, and optimize the database."""
        try:
            cur = self._conn.cursor()
            cur.execute(f'DELETE FROM {self._table} '
                        f'WHERE {self._exp_col} <= {self._ph}',
                        (time.time(),))
            cur.close()
        except sqlite3.Error as ex:
            raise pluca.CacheBackendError(
                'SQLite backend failed during gc'
            ) from ex
        self._commit()
        try:
            self._conn.execute('PRAGMA optimize')
        except sqlite3.Error as ex:
            raise pluca.CacheBackendError(
                'SQLite backend failed during gc optimize'
            ) from ex

    def shutdown(self) -> None:
        """Close the SQLite connection."""
        try:
            self._conn.close()
        except sqlite3.Error as ex:
            raise pluca.CacheBackendError(
                'SQLite backend failed during shutdown'
            ) from ex


Adapter = SQLite3Adapter
