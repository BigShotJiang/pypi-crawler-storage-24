from __future__ import annotations

import enum
import warnings
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Any, Generic, Iterator, NamedTuple, Self, TypeVar

import numpy as np
import pandas as pd
from ccy.core.daycounter import ActAct, DayCounter
from pydantic import BaseModel, Field
from typing_extensions import Annotated, Doc

from quantflow.utils import plot
from quantflow.utils.dates import utcnow
from quantflow.utils.interest_rates import rate_from_spot_and_forward
from quantflow.utils.numbers import ZERO, Number, sigfig, to_decimal, to_decimal_or_none

from .bs import black_price, implied_black_volatility
from .inputs import (
    DefaultVolSecurity,
    ForwardInput,
    OptionInput,
    OptionType,
    Side,
    SpotInput,
    VolSecurityType,
    VolSurfaceInput,
    VolSurfaceInputs,
    VolSurfaceSecurity,
)

INITIAL_VOL = 0.5
default_day_counter = ActAct()


S = TypeVar("S", bound=VolSurfaceSecurity)


class OptionSelection(enum.Enum):
    """Option selection method

    This enum is used to select which one between calls and puts are used
    for calculating implied volatility and other operations
    """

    best = enum.auto()
    """Select the best bid/ask options.

    These are the options which are Out of the Money, where their
    intrinsic value is zero"""
    call = enum.auto()
    """Select the call options only"""
    put = enum.auto()
    """Select the put options only"""


class Price(BaseModel, Generic[S]):
    security: S = Field(description="The underlying security of the price")
    bid: Decimal = Field(description="Bid price")
    ask: Decimal = Field(description="Ask price")

    @property
    def mid(self) -> Decimal:
        return (self.bid + self.ask) / 2


class SpotPrice(Price[S]):
    open_interest: Decimal = Field(
        default=ZERO, description="Open interest of the spot price"
    )
    volume: Decimal = Field(default=ZERO, description="Volume of the spot price")

    def inputs(self) -> SpotInput:
        return SpotInput(
            bid=self.bid,
            ask=self.ask,
            open_interest=self.open_interest,
            volume=self.volume,
        )


class FwdPrice(Price[S]):
    maturity: datetime = Field(description="Maturity date of the forward price")
    open_interest: Decimal = Field(
        default=ZERO, description="Open interest of the forward price"
    )
    volume: Decimal = Field(default=ZERO, description="Volume of the forward price")

    def inputs(self) -> ForwardInput:
        return ForwardInput(
            bid=self.bid,
            ask=self.ask,
            maturity=self.maturity,
            open_interest=self.open_interest,
            volume=self.volume,
        )


class OptionMetadata(BaseModel):
    strike: Decimal = Field(description="Strike price of the option")
    option_type: OptionType = Field(description="Type of the option, call or put")
    maturity: datetime = Field(description="Maturity date of the option")
    forward: Decimal = Field(
        default=ZERO, description="Forward price of the underlying"
    )
    ttm: float = Field(default=0, description="Time to maturity in years")
    open_interest: Decimal = Field(
        default=ZERO, description="Open interest of the option"
    )
    volume: Decimal = Field(default=ZERO, description="Volume of the option")


class OptionPrice(BaseModel):
    """Represents the price of an option quoted in the market along with
    its metadata and implied volatility information."""

    price: Decimal = Field(
        description="Price of the option as a percentage of the forward price"
    )
    meta: OptionMetadata = Field(description="Metadata of the option price")
    implied_vol: float = Field(
        default=0, description="Implied volatility of the option"
    )
    side: Side = Field(
        default=Side.bid, description="Side of the market for the option price"
    )
    converged: bool = Field(
        default=True, description="Flag indicating if implied vol calculation converged"
    )

    @classmethod
    def create(
        cls,
        strike: Number,
        *,
        price: Number = ZERO,
        implied_vol: float = INITIAL_VOL,
        forward: Number | None = None,
        ref_date: datetime | None = None,
        maturity: datetime | None = None,
        day_counter: DayCounter | None = None,
        option_type: OptionType = OptionType.call,
        open_interest: Number = ZERO,
        volume: Number = ZERO,
    ) -> OptionPrice:
        """Create an option price

        mainly used for testing
        """
        ref_date = ref_date or utcnow()
        maturity = maturity or ref_date + timedelta(days=365)
        day_counter = day_counter or default_day_counter
        return cls(
            price=to_decimal(price),
            implied_vol=implied_vol,
            meta=OptionMetadata(
                strike=to_decimal(strike),
                forward=to_decimal(forward or strike),
                option_type=option_type,
                maturity=maturity,
                ttm=day_counter.dcf(ref_date, maturity),
                open_interest=to_decimal(open_interest),
                volume=to_decimal(volume),
            ),
        )

    @property
    def strike(self) -> Decimal:
        return self.meta.strike

    @property
    def forward(self) -> Decimal:
        return self.meta.forward

    @property
    def maturity(self) -> datetime:
        return self.meta.maturity

    @property
    def ttm(self) -> float:
        return self.meta.ttm

    @property
    def option_type(self) -> OptionType:
        return self.meta.option_type

    @property
    def open_interest(self) -> Decimal:
        return self.meta.open_interest

    @property
    def volume(self) -> Decimal:
        return self.meta.volume

    @property
    def moneyness(self) -> float:
        return float(np.log(float(self.strike / self.forward)))

    @property
    def price_bp(self) -> Decimal:
        return self.price * 10000

    @property
    def forward_price(self) -> Decimal:
        return self.forward * self.price

    @property
    def price_intrinsic(self) -> Decimal:
        if self.option_type.is_call():
            return max(self.forward - self.strike, ZERO) / self.forward
        else:
            return max(self.strike - self.forward, ZERO) / self.forward

    @property
    def price_time(self) -> Decimal:
        return self.price - self.price_intrinsic

    @property
    def call_price(self) -> Decimal:
        """call price

        use put-call parity to calculate the call price if a put
        """
        if self.option_type.is_call():
            return self.price
        else:
            return self.price + 1 - self.strike / self.forward

    @property
    def put_price(self) -> Decimal:
        """put price

        use put-call parity to calculate the put price if a call
        """
        if self.option_type.is_call():
            return self.price - 1 + self.strike / self.forward
        else:
            return self.price

    def can_price(self, converged: bool, select: OptionSelection) -> bool:
        """Check if the option price can be used for implied volatility calculation"""
        if self.price_time > ZERO and not np.isnan(self.implied_vol):
            if not self.converged and converged is True:
                return False
            if select == OptionSelection.best:
                return self.price_intrinsic == ZERO
            return True
        return False

    def calculate_price(self) -> OptionPrice:
        self.price = Decimal(
            sigfig(
                black_price(
                    np.asarray(self.moneyness),
                    self.implied_vol,
                    self.ttm,
                    1 if self.option_type.is_call() else -1,
                ).sum(),
                8,
            )
        )
        return self

    def info_dict(self) -> dict[str, Any]:
        return dict(
            strike=float(self.strike),
            forward=float(self.forward),
            maturity=self.maturity,
            moneyness=self.moneyness,
            moneyness_ttm=self.moneyness / np.sqrt(self.ttm),
            ttm=self.ttm,
            implied_vol=self.implied_vol,
            price=float(self.price),
            price_bp=float(self.price_bp),
            forward_price=float(self.forward_price),
            type=str(self.option_type),
            side=str(self.side),
            open_interest=float(self.open_interest),
            volume=float(self.volume),
        )


class OptionArrays(NamedTuple):
    options: list[OptionPrice]
    moneyness: np.ndarray
    price: np.ndarray
    ttm: np.ndarray
    implied_vol: np.ndarray
    call_put: np.ndarray


class OptionPrices(BaseModel, Generic[S]):
    security: S = Field(description="The underlying security of the option prices")
    meta: OptionMetadata = Field(description="Metadata for the option prices")
    bid: OptionPrice = Field(description="Bid option price")
    ask: OptionPrice = Field(description="Ask option price")

    def prices(
        self,
        forward: Annotated[Decimal, Doc("Forward price of the underlying asset")],
        ttm: Annotated[float, Doc("Time to maturity in years")],
        *,
        select: Annotated[
            OptionSelection, Doc("Option selection method")
        ] = OptionSelection.best,
        initial_vol: Annotated[
            float, Doc("Initial volatility for the root finding algorithm")
        ] = INITIAL_VOL,
        converged: Annotated[bool, Doc("Whether the calculation has converged")] = True,
    ) -> Iterator[OptionPrice]:
        """Iterator over bid/ask option prices"""
        self.meta.forward = forward
        self.meta.ttm = ttm
        for o in (self.bid, self.ask):
            o.meta.forward = forward
            o.meta.ttm = ttm
            if not o.implied_vol:
                o.implied_vol = initial_vol
            if o.can_price(converged, select):
                yield o

    def inputs(self) -> OptionInput:
        """Convert the option prices to an OptionInput instance"""
        return OptionInput(
            bid=self.bid.price,
            ask=self.ask.price,
            open_interest=self.meta.open_interest,
            volume=self.meta.volume,
            strike=self.meta.strike,
            maturity=self.meta.maturity,
            option_type=self.meta.option_type,
            iv_bid=to_decimal_or_none(
                None if np.isnan(self.bid.implied_vol) else self.bid.implied_vol
            ),
            iv_ask=to_decimal_or_none(
                None if np.isnan(self.ask.implied_vol) else self.ask.implied_vol
            ),
        )


class Strike(BaseModel, Generic[S]):
    """Option prices for a single strike"""

    strike: Decimal = Field(description="Strike price of the options")
    call: OptionPrices[S] | None = Field(
        default=None, description="Call option prices for the strike"
    )
    put: OptionPrices[S] | None = Field(
        default=None, description="Put option prices for the strike"
    )

    def option_prices(
        self,
        forward: Annotated[Decimal, Doc("Forward price of the underlying asset")],
        ttm: Annotated[float, Doc("Time to maturity in years")],
        *,
        select: Annotated[
            OptionSelection, Doc("Option selection method")
        ] = OptionSelection.best,
        initial_vol: Annotated[
            float, Doc("Initial volatility for the root finding algorithm")
        ] = INITIAL_VOL,
        converged: Annotated[bool, Doc("Whether the calculation has converged")] = True,
    ) -> Iterator[OptionPrice]:
        if select != OptionSelection.put and self.call:
            yield from self.call.prices(
                forward,
                ttm,
                select=select,
                initial_vol=initial_vol,
                converged=converged,
            )
        if select != OptionSelection.call and self.put:
            yield from self.put.prices(
                forward,
                ttm,
                select=select,
                initial_vol=initial_vol,
                converged=converged,
            )


class VolCrossSection(BaseModel, Generic[S], arbitrary_types_allowed=True):
    """Represents a cross section of a volatility surface at a specific maturity."""

    maturity: datetime
    """Maturity date of the cross section"""
    forward: FwdPrice[S]
    """Forward price of the underlying asset at the time of the cross section"""
    strikes: tuple[Strike[S], ...]
    """Tuple of sorted strikes and their corresponding option prices"""
    day_counter: DayCounter = default_day_counter
    """Day counter for time to maturity calculations - by default it uses Act/Act"""

    def ttm(self, ref_date: datetime) -> float:
        """Time to maturity in years"""
        return self.day_counter.dcf(ref_date, self.maturity)

    def info_dict(self, ref_date: datetime, spot: SpotPrice[S]) -> dict:
        """Return a dictionary with information about the cross section"""
        return dict(
            maturity=self.maturity,
            ttm=self.ttm(ref_date),
            forward=self.forward.mid,
            basis=self.forward.mid - spot.mid,
            rate_percent=rate_from_spot_and_forward(
                spot.mid, self.forward.mid, self.maturity - ref_date
            ).percent,
            open_interest=self.forward.open_interest,
            volume=self.forward.volume,
        )

    def option_prices(
        self,
        ref_date: Annotated[
            datetime, Doc("Reference date for time to maturity calculation")
        ],
        *,
        select: Annotated[
            OptionSelection, Doc("Option selection method")
        ] = OptionSelection.best,
        initial_vol: Annotated[
            float, Doc("Initial volatility for the root finding algorithm")
        ] = INITIAL_VOL,
        converged: Annotated[bool, Doc("Whether the calculation has converged")] = True,
    ) -> Iterator[OptionPrice]:
        """Iterator over option prices in the cross section"""
        for s in self.strikes:
            yield from s.option_prices(
                self.forward.mid,
                self.ttm(ref_date),
                select=select,
                initial_vol=initial_vol,
                converged=converged,
            )

    def securities(self) -> Iterator[FwdPrice[S] | OptionPrices[S]]:
        """Return a list of all securities in the cross section"""
        yield self.forward
        for strike in self.strikes:
            if strike.call is not None:
                yield strike.call
            if strike.put is not None:
                yield strike.put


class VolSurface(BaseModel, Generic[S], arbitrary_types_allowed=True):
    """Represents a volatility surface, which captures the implied volatility of an
    option for different strikes and maturities.

    Key Concepts:

    * **Implied Volatility:** The market's expectation of future volatility, derived
        from the price of an option using a pricing model (e.g., Black-Scholes).
    * **Strike Price:** The price at which the underlying asset can be bought
        (call option) or sold (put option) at the option's expiry.
    * **Time to Maturity:** The time remaining until the option's expiration date.
    * **Volatility Smile/Skew:** The often-observed phenomenon where implied
        volatility varies across different strike prices for the same maturity.
        Typically, it forms a "smile" or "skew" shape.

    This class provides a structure for storing and manipulating volatility
    surface data. It can be used for various tasks, such as:

    * **Option pricing and risk management:** Using the surface to determine the
        appropriate volatility input for pricing models.
    * **Volatility arbitrage:** Identifying mispricings in options by comparing
        market prices to model prices derived from the surface.
    * **Market analysis:** Understanding market sentiment and expectations of
        future volatility.
    """

    ref_date: datetime
    """Reference date for the volatility surface"""
    asset: str
    """Name of the underlying asset"""
    spot: SpotPrice[S]
    """Spot price of the underlying asset"""
    maturities: tuple[VolCrossSection[S], ...]
    """Sorted tuple of :class:`.VolCrossSection` for different maturities"""
    day_counter: DayCounter = default_day_counter
    """Day counter for time to maturity calculations - by default it uses Act/Act"""
    tick_size_forwards: Decimal | None = None
    """Tick size for rounding forward and spot prices - optional"""
    tick_size_options: Decimal | None = None
    """Tick size for rounding option prices - optional"""

    def securities(self) -> Iterator[SpotPrice[S] | FwdPrice[S] | OptionPrices[S]]:
        """Iterator over all securities in the volatility surface"""
        yield self.spot
        for maturity in self.maturities:
            yield from maturity.securities()

    def inputs(self) -> VolSurfaceInputs:
        """Convert the volatility surface to a
        [VolSurfaceInputs][quantflow.options.inputs.VolSurfaceInputs] instance"""
        return VolSurfaceInputs(
            asset=self.asset,
            ref_date=self.ref_date,
            inputs=list(s.inputs() for s in self.securities()),
        )

    def term_structure(self) -> pd.DataFrame:
        """Return the term structure of the volatility surface"""
        return pd.DataFrame(
            cross.info_dict(self.ref_date, self.spot) for cross in self.maturities
        )

    def trim(self, num_maturities: int) -> Self:
        """Create a new volatility surface with the last `num_maturities` maturities"""
        return self.model_copy(
            update=dict(maturities=self.maturities[-num_maturities:])
        )

    def option_prices(
        self,
        *,
        select: Annotated[
            OptionSelection, Doc("Option selection method")
        ] = OptionSelection.best,
        index: Annotated[
            int | None, Doc("Index of the cross section to use, if None use all")
        ] = None,
        initial_vol: Annotated[
            float, Doc("Initial volatility for the root finding algorithm")
        ] = INITIAL_VOL,
        converged: Annotated[
            bool,
            Doc(
                "Returns options with converged implied volatility "
                "calculation only if True"
            ),
        ] = True,
    ) -> Iterator[OptionPrice]:
        """Iterator over selected option prices in the surface"""
        if index is not None:
            yield from self.maturities[index].option_prices(
                self.ref_date,
                select=select,
                initial_vol=initial_vol,
                converged=converged,
            )
        else:
            for maturity in self.maturities:
                yield from maturity.option_prices(
                    self.ref_date,
                    select=select,
                    initial_vol=initial_vol,
                    converged=converged,
                )

    def option_list(
        self,
        *,
        select: OptionSelection = OptionSelection.best,
        index: int | None = None,
        converged: bool = True,
    ) -> list[OptionPrice]:
        "List of selected option prices in the surface"
        return list(self.option_prices(select=select, index=index, converged=converged))

    def bs(
        self,
        *,
        select: Annotated[
            OptionSelection, Doc("Option selection method")
        ] = OptionSelection.best,
        index: Annotated[
            int | None, Doc("Index of the cross section to use, if None use all")
        ] = None,
        initial_vol: Annotated[
            float, Doc("Initial volatility for the root finding algorithm")
        ] = INITIAL_VOL,
    ) -> list[OptionPrice]:
        """Calculate Black-Scholes implied volatility for all options
        in the surface.
        For some options, the implied volatility calculation may not converge,
        in this case the implied volatility is not
        calculated correctly and the option is marked as not converged.
        """
        d = self.as_array(
            select=select,
            index=index,
            initial_vol=initial_vol,
            converged=False,
        )
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result = implied_black_volatility(
                k=d.moneyness,
                price=d.price,
                ttm=d.ttm,
                initial_sigma=d.implied_vol,
                call_put=d.call_put,
            )
        for option, implied_vol, converged in zip(
            d.options, result.root, result.converged
        ):
            option.implied_vol = float(implied_vol)
            option.converged = converged
        return d.options

    def calc_bs_prices(
        self,
        *,
        select: Annotated[
            OptionSelection, Doc("Option selection method")
        ] = OptionSelection.best,
        index: Annotated[
            int | None, Doc("Index of the cross section to use, if None use all")
        ] = None,
    ) -> np.ndarray:
        """calculate Black-Scholes prices for all options in the surface"""
        d = self.as_array(select=select, index=index)
        return black_price(k=d.moneyness, sigma=d.implied_vol, ttm=d.ttm, s=d.call_put)

    def options_df(
        self,
        *,
        select: Annotated[
            OptionSelection, Doc("Option selection method")
        ] = OptionSelection.best,
        index: Annotated[
            int | None, Doc("Index of the cross section to use, if None use all")
        ] = None,
        initial_vol: Annotated[
            float, Doc("Initial volatility for the root finding algorithm")
        ] = INITIAL_VOL,
        converged: Annotated[bool, Doc("Whether the calculation has converged")] = True,
    ) -> pd.DataFrame:
        """Time frame of Black-Scholes call input data"""
        data = self.option_prices(
            select=select,
            index=index,
            initial_vol=initial_vol,
            converged=converged,
        )
        return pd.DataFrame([d.info_dict() for d in data])

    def as_array(
        self,
        *,
        select: Annotated[
            OptionSelection, Doc("Option selection method")
        ] = OptionSelection.best,
        index: Annotated[
            int | None, Doc("Index of the cross section to use, if None use all")
        ] = None,
        initial_vol: Annotated[
            float, Doc("Initial volatility for the root finding algorithm")
        ] = INITIAL_VOL,
        converged: Annotated[bool, Doc("Whether the calculation has converged")] = True,
    ) -> OptionArrays:
        """Organize option prices in a numpy arrays for black volatility calculation"""
        options = list(
            self.option_prices(
                select=select,
                index=index,
                initial_vol=initial_vol,
                converged=converged,
            )
        )
        moneyness = []
        ttm = []
        price = []
        vol = []
        call_put = []
        for option in options:
            moneyness.append(float(option.moneyness))
            price.append(float(option.price))
            ttm.append(float(option.ttm))
            vol.append(float(option.implied_vol))
            call_put.append(1 if option.option_type.is_call() else -1)
        return OptionArrays(
            options=options,
            moneyness=np.array(moneyness),
            price=np.array(price),
            ttm=np.array(ttm),
            implied_vol=np.array(vol),
            call_put=np.array(call_put),
        )

    def disable_outliers(self, quantile: float = 0.99, repeat: int = 2) -> VolSurface:
        for _ in range(repeat):
            option_prices = self.option_list()
            implied_vols = [o.implied_vol for o in option_prices]
            exclude_above = np.quantile(implied_vols, quantile)
            for option in option_prices:
                if option.implied_vol > exclude_above:
                    option.converged = False
        return self

    def plot(
        self,
        *,
        index: int | None = None,
        select: OptionSelection = OptionSelection.best,
        **kwargs: Any,
    ) -> Any:
        """Plot the volatility surface"""
        df = self.options_df(index=index, select=select)
        return plot.plot_vol_surface(df, **kwargs)

    def plot3d(
        self,
        *,
        select: OptionSelection = OptionSelection.best,
        **kwargs: Any,
    ) -> Any:
        """Plot the volatility surface"""
        df = self.options_df(select=select)
        return plot.plot_vol_surface_3d(df, **kwargs)


class VolCrossSectionLoader(BaseModel, Generic[S], arbitrary_types_allowed=True):
    maturity: datetime = Field(description="Maturity date of the cross section")
    forward: FwdPrice[S] | None = Field(
        default=None,
        description=(
            "Forward price of the underlying asset at the time of the cross section"
        ),
    )
    strikes: dict[Decimal, Strike[S]] = Field(
        default_factory=dict,
        description="Dictionary of strikes and their corresponding option prices",
    )
    day_counter: DayCounter = Field(
        default=default_day_counter,
        description=(
            "Day counter for time to maturity calculations "
            "- by default it uses Act/Act"
        ),
    )

    def add_option(
        self,
        strike: Decimal,
        option_type: OptionType,
        security: S,
        bid: Decimal = ZERO,
        ask: Decimal = ZERO,
        open_interest: Decimal = ZERO,
        volume: Decimal = ZERO,
    ) -> None:
        if strike not in self.strikes:
            self.strikes[strike] = Strike(strike=strike)
        meta = OptionMetadata(
            strike=strike,
            option_type=option_type,
            maturity=self.maturity,
            open_interest=open_interest,
            volume=volume,
        )
        option = OptionPrices(
            security=security,
            meta=meta,
            bid=OptionPrice(price=bid, meta=meta, side=Side.bid),
            ask=OptionPrice(price=ask, meta=meta, side=Side.ask),
        )
        if option_type.is_call():
            self.strikes[strike].call = option
        else:
            self.strikes[strike].put = option

    def cross_section(self) -> VolCrossSection[S] | None:
        if self.forward is None or self.forward.mid == ZERO:
            return None
        strikes = []
        for strike in sorted(self.strikes):
            sk = self.strikes[strike]
            if sk.call is None and sk.put is None:
                continue
            strikes.append(sk)
        return (
            VolCrossSection(
                maturity=self.maturity,
                forward=self.forward,
                strikes=tuple(strikes),
                day_counter=self.day_counter,
            )
            if strikes
            else None
        )


class GenericVolSurfaceLoader(BaseModel, Generic[S], arbitrary_types_allowed=True):
    """Helper class to build a volatility surface from a list of securities"""

    asset: str = Field(default="", description="Name of the underlying asset")
    spot: SpotPrice[S] | None = Field(
        default=None, description="Spot price of the underlying asset"
    )
    maturities: dict[datetime, VolCrossSectionLoader[S]] = Field(
        default_factory=dict,
        description=(
            "Dictionary of maturities and their corresponding cross section loaders"
        ),
    )
    day_counter: DayCounter = Field(
        default=default_day_counter,
        description=(
            "Day counter for time to maturity calculations "
            "by default it uses Act/Act"
        ),
    )
    """Day counter for time to maturity calculations - by default it uses Act/Act"""
    tick_size_forwards: Decimal | None = Field(
        default=None,
        description="Tick size for rounding forward and spot prices - optional",
    )
    tick_size_options: Decimal | None = Field(
        default=None, description="Tick size for rounding option prices - optional"
    )
    exclude_open_interest: Decimal | None = Field(
        default=None,
        description="Exclude options with open interest at or below this value",
    )
    exclude_volume: Decimal | None = Field(
        default=None, description="Exclude options with volume at or below this value"
    )

    def get_or_create_maturity(self, maturity: datetime) -> VolCrossSectionLoader[S]:
        if maturity not in self.maturities:
            self.maturities[maturity] = VolCrossSectionLoader(
                maturity=maturity,
                day_counter=self.day_counter,
            )
        return self.maturities[maturity]

    def add_spot(
        self,
        security: S,
        bid: Decimal = ZERO,
        ask: Decimal = ZERO,
        open_interest: Decimal = ZERO,
        volume: Decimal = ZERO,
    ) -> None:
        """Add a spot to the volatility surface loader"""
        if security.vol_surface_type() != VolSecurityType.spot:
            raise ValueError("Security is not a spot")
        self.spot = SpotPrice(
            security=security,
            bid=bid,
            ask=ask,
            open_interest=open_interest,
            volume=volume,
        )

    def add_forward(
        self,
        security: S,
        maturity: datetime,
        bid: Decimal = ZERO,
        ask: Decimal = ZERO,
        open_interest: Decimal = ZERO,
        volume: Decimal = ZERO,
    ) -> None:
        """Add a forward to the volatility surface loader"""
        if security.vol_surface_type() != VolSecurityType.forward:
            raise ValueError("Security is not a forward")
        self.get_or_create_maturity(maturity=maturity).forward = FwdPrice(
            security=security,
            bid=bid,
            ask=ask,
            maturity=maturity,
            open_interest=open_interest,
            volume=volume,
        )

    def add_option(
        self,
        security: S,
        strike: Decimal,
        maturity: datetime,
        option_type: OptionType,
        bid: Decimal = ZERO,
        ask: Decimal = ZERO,
        open_interest: Decimal = ZERO,
        volume: Decimal = ZERO,
    ) -> None:
        """Add an option to the volatility surface loader"""
        if security.vol_surface_type() != VolSecurityType.option:
            raise ValueError("Security is not an option")
        if self.exclude_volume is not None and volume <= self.exclude_volume:
            return
        if (
            self.exclude_open_interest is not None
            and open_interest <= self.exclude_open_interest
        ):
            return
        self.get_or_create_maturity(maturity=maturity).add_option(
            strike=strike,
            option_type=option_type,
            security=security,
            bid=bid,
            ask=ask,
            open_interest=open_interest,
            volume=volume,
        )

    def surface(self, ref_date: datetime | None = None) -> VolSurface[S]:
        """Build a volatility surface from the provided data"""
        if not self.spot or self.spot.mid == ZERO:
            raise ValueError("No spot price provided")
        maturities = []
        for maturity in sorted(self.maturities):
            if section := self.maturities[maturity].cross_section():
                maturities.append(section)
        return VolSurface(
            asset=self.asset,
            ref_date=ref_date or utcnow(),
            spot=self.spot,
            maturities=tuple(maturities),
            day_counter=self.day_counter,
            tick_size_forwards=self.tick_size_forwards,
            tick_size_options=self.tick_size_options,
        )


class VolSurfaceLoader(GenericVolSurfaceLoader[DefaultVolSecurity]):
    """A volatility surface loader"""

    def add(self, input: VolSurfaceInput) -> None:
        """Add a volatility security input to the loader

        :params input: The input data for the security,
            it can be spot, forward or option
        """
        if isinstance(input, SpotInput):
            self.add_spot(
                DefaultVolSecurity.spot(),
                bid=input.bid,
                ask=input.ask,
                open_interest=input.open_interest,
                volume=input.volume,
            )
        elif isinstance(input, ForwardInput):
            self.add_forward(
                DefaultVolSecurity.forward(),
                maturity=input.maturity,
                bid=input.bid,
                ask=input.ask,
                open_interest=input.open_interest,
                volume=input.volume,
            )
        elif isinstance(input, OptionInput):
            self.add_option(
                DefaultVolSecurity.option(),
                strike=input.strike,
                option_type=input.option_type,
                maturity=input.maturity,
                bid=input.bid,
                ask=input.ask,
                open_interest=input.open_interest,
                volume=input.volume,
            )
        else:
            raise ValueError(f"Unknown input type {type(input)}")


def surface_from_inputs(inputs: VolSurfaceInputs) -> VolSurface[DefaultVolSecurity]:
    loader = VolSurfaceLoader()
    for input in inputs.inputs:
        loader.add(input)
    return loader.surface(ref_date=inputs.ref_date)
