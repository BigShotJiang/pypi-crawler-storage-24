# EWMA


::: quantflow.ta.EWMA
