"""
                GNU GENERAL PUBLIC LICENSE
                  Version 3, 29 June 2007

KOSWAT, from the dutch combination of words `Kosts-Wat` (what are the costs)
Copyright (C) 2025 Stichting Deltares

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from shapely.geometry.point import Point

from koswat.dike.characteristic_points.characteristic_points import CharacteristicPoints
from koswat.dike.koswat_profile_protocol import KoswatProfileProtocol
from koswat.dike.layers.layers_wrapper import KoswatLayersWrapper
from koswat.dike.profile.koswat_input_profile_base import KoswatInputProfileBase


@dataclass
class KoswatProfileBase(KoswatProfileProtocol):
    """
    Basic definition and implementation of a `KoswatProfileProtocol`. It represents the initial koswat profile being provided by the user from which further calculations will be made.
    """

    input_data: KoswatInputProfileBase = None
    characteristic_points: CharacteristicPoints = None
    layers_wrapper: KoswatLayersWrapper = None
    location: Point | None = None

    @property
    def points(self) -> list[Point]:
        """
        The combination of points from both water and polder sides.

        Returns:
            list[Point]: A total of eight points comforming the `KoswatProfile`.
        """
        if not self.characteristic_points:
            return []
        return self.characteristic_points.points

    @property
    def profile_width(self) -> float:
        """
        The profile extent from the lowest (left-most) x-coordinate to the largest (right-most) x-coordinate from a dike geometry polygon.

        Returns:
            float: Total width.
        """
        if not self.points:
            return math.nan

        # This assumes coordinates are ordered based on the 'x' coordinate
        # as they come from our `CharacteristicPoints.points` property method.

        return self.points[-1].x - self.points[0].x

    @property
    def polderside_width(self) -> float:
        """
        The profile extent on the polderside from
        x-coordinate of point 4 of the (old) profile (assumed to be 0)
        to the largest (right-most) x-coordinate of the (reinforced) profile.

        Returns:
            float: Polderside width.
        """
        return self.points[-1].x

    @property
    def profile_height(self) -> float:
        """
        The profile highest point (largest y-coordinate).

        Returns:
            float: Greatest y-coordinate.
        """
        if not self.points:
            return math.nan
        return max(_p.y for _p in self.points if _p)
