"""
                    GNU GENERAL PUBLIC LICENSE
                      Version 3, 29 June 2007

    KOSWAT, from the dutch combination of words `Kosts-Wat` (what are the costs)
    Copyright (C) 2025 Stichting Deltares

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from typing import Any, Protocol, runtime_checkable

from matplotlib import pyplot


@runtime_checkable
class KoswatPlotProtocol(Protocol):
    koswat_object: Any
    subplot: pyplot.axes

    def plot(self, *args, **kwargs) -> pyplot.axes:
        """
        Plots a `koswat_object` into the provided plot `ax` with the requested `*args` and `**kwargs`.

        Returns:
            pyplot.axes: Canvas with plotted `koswat_object`.
        """
        pass
