"""
                    GNU GENERAL PUBLIC LICENSE
                      Version 3, 29 June 2007

    KOSWAT, from the dutch combination of words `Kosts-Wat` (what are the costs)
    Copyright (C) 2025 Stichting Deltares

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import logging
from dataclasses import dataclass

from koswat.dike_reinforcements.reinforcement_profile.reinforcement_profile_protocol import (
    ReinforcementProfileProtocol,
)
from koswat.strategies.order_strategy.order_cluster import OrderCluster
from koswat.strategies.order_strategy.order_strategy_base import OrderStrategyBase
from koswat.strategies.strategy_location_reinforcement import (
    StrategyLocationReinforcement,
)


@dataclass
class OrderStrategyClustering(OrderStrategyBase):
    """
    Applies clustering, to the whole collection of reinforcements
    (`location_reinforcements: list[StrategyLocationReinforcement]`).
    The result of the `apply` method will be the locations with the best
    reinforcement fit (lowest index from `reinforcement_order`) that fulfills the
    `reinforcement_min_length` requirement.
    """

    reinforcement_order: list[type[ReinforcementProfileProtocol]]
    reinforcement_min_length: float

    def _get_reinforcement_order_clusters(
        self,
        location_reinforcements: list[StrategyLocationReinforcement],
    ) -> list[OrderCluster]:
        _added_clusters = []
        for _cluster in self._get_reinforcement_groupings(location_reinforcements):
            _last_added = OrderCluster(
                reinforcement_idx=_cluster[0],
                location_reinforcements=_cluster[1],
                left_neighbor=_added_clusters[-1] if any(_added_clusters) else None,
            )
            if isinstance(_last_added.left_neighbor, OrderCluster):
                _last_added.left_neighbor.right_neighbor = _last_added
            _added_clusters.append(_last_added)
        return _added_clusters

    def _get_non_compliant_clusters(
        self, target_reinforcement_idx: int, available_clusters: list[OrderCluster]
    ) -> list[OrderCluster]:
        return list(
            filter(
                lambda x: not x.is_compliant(
                    self.reinforcement_min_length, self.reinforcement_order[-1]
                )
                and x.reinforcement_idx == target_reinforcement_idx,
                available_clusters,
            )
        )

    def apply(
        self, location_reinforcements: list[StrategyLocationReinforcement]
    ) -> None:
        _available_clusters = self._get_reinforcement_order_clusters(
            location_reinforcements
        )
        _reinforcements_order_max_idx = len(self.reinforcement_order) - 1
        for _target_idx, _reinforcement_type in enumerate(
            self.reinforcement_order[:-1]
        ):
            _non_compliant_clusters = self._get_non_compliant_clusters(
                _target_idx, _available_clusters
            )
            logging.info(
                "Non-compliant clusters found for {}: {}".format(
                    _reinforcement_type.output_name, len(_non_compliant_clusters)
                )
            )
            for _cluster in _non_compliant_clusters:
                if _cluster.is_compliant(
                    self.reinforcement_min_length, _reinforcements_order_max_idx
                ):
                    continue
                _stronger_cluster = _cluster.get_stronger_cluster()
                # Update selected measures for locations in this cluster.
                _stronger_cluster.extend_cluster(_cluster)
                _available_clusters.pop(_available_clusters.index(_cluster))
