"""
                    GNU GENERAL PUBLIC LICENSE
                      Version 3, 29 June 2007

    KOSWAT, from the dutch combination of words `Kosts-Wat` (what are the costs)
    Copyright (C) 2025 Stichting Deltares

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field

from koswat.cost_report.multi_location_profile import MultiLocationProfileCostReport
from koswat.dike_reinforcements.reinforcement_profile.reinforcement_profile_protocol import (
    ReinforcementProfileProtocol,
)
from koswat.strategies.strategy_location_reinforcement import (
    StrategyLocationReinforcement,
)


@dataclass
class KoswatSummary:
    """
    Represents the summary of the KOSWAT analysis.
    """

    locations_profile_report_list: list[MultiLocationProfileCostReport] = field(
        default_factory=lambda: []
    )
    reinforcement_per_locations: list[StrategyLocationReinforcement] = field(
        default_factory=lambda: []
    )
    reinforcement_order: list[type[ReinforcementProfileProtocol]] = field(
        default_factory=lambda: []
    )

    def get_report_by_profile(
        self, profile_type: type[ReinforcementProfileProtocol]
    ) -> MultiLocationProfileCostReport | None:
        """
        Get the report for a specific profile type.

        Args:
            profile_type (type[ReinforcementProfileProtocol]): Type of reinforcement profile.

        Returns:
            MultiLocationProfileCostReport | None: Report for the profile type.
        """
        return next(
            (
                _report
                for _report in self.locations_profile_report_list
                if isinstance(
                    _report.profile_cost_report.reinforced_profile, profile_type
                )
            ),
            None,
        )

    def get_infrastructure_costs(
        self,
    ) -> dict[type[ReinforcementProfileProtocol], tuple[float, float]]:
        """
        Gets the infrastructure costs for each profile type
        for those locations for which the profile type is selected.

        Returns:
            dict[type[ReinforcementProfileProtocol], tuple[float, float]]:
                infrastructure costs without and with surtax per reinforcement type.
        """
        _infra_costs_per_reinforcement = defaultdict(tuple)

        # Get the infra cost tuples (without and with surtax) for each location.
        _infra_costs_dict = defaultdict(list)
        for _loc in self.reinforcement_per_locations:
            _infra_costs_dict[_loc.current_selected_measure].append(
                _loc.get_infrastructure_costs(_loc.current_selected_measure)
            )

        # Sum the infra costs for each reinforcement type.
        for _rt, _infra_costs in _infra_costs_dict.items():
            _infra_costs, _infra_costs_with_surtax = zip(*_infra_costs)
            _infra_costs_per_reinforcement[_rt] = (
                sum(_infra_costs),
                sum(_infra_costs_with_surtax),
            )

        return dict(_infra_costs_per_reinforcement)
