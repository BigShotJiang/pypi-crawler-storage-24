import asyncio

from src.SimpleRule34 import Rule34Api

api = Rule34Api(api_key="3cb81d49b14a1f834f442c020d429bef836c3c2c29b8cc345f961d4c85d72daa07d970cd422059c2333d229da0efc38179057373f1da8d267126d542acdf74d6", user_id=5260076)

async def foo(_id):
    p = await api.post.get_list(tags=["genshin_impact"], page=0, amount=10)
    for post in p:
        print(post.id)
    return p[-1].id

async def main():
    await foo(122)



if __name__ == '__main__':
    asyncio.run(main())