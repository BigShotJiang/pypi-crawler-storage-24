"""Parser registry for mapping geotechnical firms to their parsers."""

from __future__ import annotations

from typing import Optional

from geotech_report_extraction.parsers.base import BaseBoringLogParser
from geotech_report_extraction.parsers.generic import GenericParser
from geotech_report_extraction.parsers.langan_di import LanganDIParser
from geotech_report_extraction.parsers.schnabel_di import SchnabelDIParser
from geotech_report_extraction.pdf_parser import PDFContent

# Registry of firm name -> parser class (for PDF extraction)
# Uses GenericParser as fallback; legacy firm-specific PDF parsers moved to _legacy/
_PARSERS: dict[str, type[BaseBoringLogParser]] = {
    "langan": LanganDIParser,
    "schnabel": SchnabelDIParser,
}

# Registry for DI JSON extraction (purpose-built DI parsers)
_DI_PARSERS: dict[str, type[BaseBoringLogParser]] = {
    "langan": LanganDIParser,
    "schnabel": SchnabelDIParser,
}


def detect_firm(pdf_content: PDFContent) -> Optional[str]:
    """Detect the geotechnical firm from PDF content.

    Returns:
        Lowercase firm key (e.g., 'langan', 'schnabel') or None.
    """
    return pdf_content.detected_firm


def get_parser(firm: Optional[str] = None) -> BaseBoringLogParser:
    """Get the appropriate parser for a firm.

    Uses firm-specific parsers when available, falls back to the
    GenericParser for unrecognized or unspecified firms.

    Args:
        firm: Firm identifier (e.g., 'langan', 'schnabel').
              If None or unrecognized, uses the GenericParser.

    Returns:
        An instance of the appropriate parser.
    """
    if firm is None:
        return GenericParser()

    firm_lower = firm.lower()
    parser_cls = _PARSERS.get(firm_lower)
    if parser_cls is None:
        return GenericParser()
    return parser_cls()


def get_di_parser(firm: Optional[str] = None) -> BaseBoringLogParser:
    """Get the appropriate DI-specific parser for a firm.

    DI parsers are purpose-built for Azure Document Intelligence JSON data,
    using exact column positions measured from actual DI exports. Falls back
    to the standard PDF parser if no DI-specific parser exists.

    Args:
        firm: Firm identifier (e.g., 'schnabel').

    Returns:
        An instance of the DI-specific or standard parser.
    """
    if firm is not None:
        firm_lower = firm.lower()
        di_parser_cls = _DI_PARSERS.get(firm_lower)
        if di_parser_cls is not None:
            return di_parser_cls()

    # Fall back to standard parser
    return get_parser(firm)
