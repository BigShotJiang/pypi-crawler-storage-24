"""Geotechnical Report Extraction Library.

Extract borehole log data from PDF geotechnical reports
(Langan Engineering, Schnabel Engineering) and output DIGGS 2.6 XML.

Supports pluggable LLM backends for vision extraction:

    # Default: Anthropic Claude
    result = extract_report("report.pdf", use_vision=True,
                            vision_api_key="sk-...")

    # Palantir Funhouse (GPT-4o/4.1 via fh_prompter)
    from geotech_report_extraction import FunhouseBackend
    result = extract_report("report.pdf",
                            llm_backend=FunhouseBackend(model="gpt-4.1"))
"""

from geotech_report_extraction.extract import extract_report
from geotech_report_extraction.llm_backend import (
    AnthropicBackend,
    FunhouseBackend,
    LLMBackend,
)
from geotech_report_extraction.models import Borehole, BoreholeLog, Project

__version__ = "0.5.5"
__all__ = [
    "extract_report",
    "Borehole",
    "BoreholeLog",
    "Project",
    "LLMBackend",
    "AnthropicBackend",
    "FunhouseBackend",
]
