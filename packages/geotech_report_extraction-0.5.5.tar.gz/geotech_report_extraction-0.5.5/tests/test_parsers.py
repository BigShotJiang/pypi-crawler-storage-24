"""Tests for boring log parsers."""

from geotech_report_extraction.models import SampleType, SPTBlowCounts
from geotech_report_extraction.parsers.base import BaseBoringLogParser
from geotech_report_extraction.parsers.langan_di import LanganDIParser
from geotech_report_extraction.parsers.schnabel_di import SchnabelDIParser
from geotech_report_extraction.parsers.registry import get_parser
from geotech_report_extraction.pdf_parser import PageContent


class TestBaseParser:
    """Test base parser utility methods."""

    def test_parse_blow_counts_three_part(self):
        spt = BaseBoringLogParser.parse_blow_counts("5-8-12")
        assert spt is not None
        assert spt.first_6in == 5
        assert spt.second_6in == 8
        assert spt.third_6in == 12
        assert spt.n_value == 20
        assert spt.refusal is False

    def test_parse_blow_counts_with_slash(self):
        spt = BaseBoringLogParser.parse_blow_counts("3/6/9")
        assert spt is not None
        assert spt.first_6in == 3
        assert spt.second_6in == 6
        assert spt.third_6in == 9
        assert spt.n_value == 15

    def test_parse_blow_counts_refusal(self):
        spt = BaseBoringLogParser.parse_blow_counts("20-30-50/4\"")
        assert spt is not None
        assert spt.refusal is True

    def test_parse_blow_counts_single_n_value(self):
        spt = BaseBoringLogParser.parse_blow_counts("25")
        assert spt is not None
        assert spt.n_value == 25

    def test_parse_blow_counts_empty(self):
        assert BaseBoringLogParser.parse_blow_counts("") is None
        assert BaseBoringLogParser.parse_blow_counts("   ") is None

    def test_parse_depth(self):
        assert BaseBoringLogParser.parse_depth("10.5") == 10.5
        assert BaseBoringLogParser.parse_depth("25'") == 25.0
        assert BaseBoringLogParser.parse_depth("0") == 0.0
        assert BaseBoringLogParser.parse_depth("") is None
        assert BaseBoringLogParser.parse_depth(None) is None

    def test_parse_date(self):
        d = BaseBoringLogParser.parse_date("01/15/2024")
        assert d is not None
        assert d.year == 2024
        assert d.month == 1
        assert d.day == 15

    def test_parse_date_two_digit_year(self):
        d = BaseBoringLogParser.parse_date("03/20/24")
        assert d is not None
        assert d.year == 2024

    def test_parse_date_invalid(self):
        assert BaseBoringLogParser.parse_date("not a date") is None
        assert BaseBoringLogParser.parse_date("") is None


class TestLanganDIParser:
    def test_firm_name(self):
        parser = LanganDIParser()
        assert parser.firm_name == "Langan Engineering"


class TestSchnabelDIParser:
    def test_firm_name(self):
        parser = SchnabelDIParser()
        assert parser.firm_name == "Schnabel Engineering"


class TestRegistry:
    def test_get_langan_parser(self):
        parser = get_parser("langan")
        assert isinstance(parser, LanganDIParser)

    def test_get_schnabel_parser(self):
        parser = get_parser("schnabel")
        assert isinstance(parser, SchnabelDIParser)

    def test_get_parser_case_insensitive(self):
        parser = get_parser("Langan")
        assert isinstance(parser, LanganDIParser)

    def test_get_parser_default(self):
        from geotech_report_extraction.parsers.generic import GenericParser
        parser = get_parser(None)
        assert isinstance(parser, GenericParser)

    def test_get_parser_unknown_falls_back_to_generic(self):
        from geotech_report_extraction.parsers.generic import GenericParser
        parser = get_parser("unknown_firm")
        assert isinstance(parser, GenericParser)


class TestGenericParser:
    def test_firm_name(self):
        from geotech_report_extraction.parsers.generic import GenericParser
        parser = GenericParser()
        assert parser.firm_name == "Generic"

    def test_parse_boring_log_empty_pages(self):
        from geotech_report_extraction.parsers.generic import GenericParser
        import pytest
        parser = GenericParser()
        with pytest.raises(ValueError):
            parser.parse_boring_log([])

    def test_parse_header_depth(self):
        from geotech_report_extraction.parsers.generic import GenericParser
        parser = GenericParser()
        page = PageContent(
            page_number=1,
            text="Boring Log B-1\nDepth: 50.5 ft\nElev: 120.3\n",
            boring_id="B-1",
        )
        header = parser._parse_header(page)
        assert header["depth"] == 50.5
        assert header["elevation"] == 120.3

    def test_parse_header_terminated(self):
        from geotech_report_extraction.parsers.generic import GenericParser
        parser = GenericParser()
        page = PageContent(
            page_number=1,
            text="Boring Terminated at 26.5 Feet\n",
            boring_id="B-1",
        )
        header = parser._parse_header(page)
        assert header["depth"] == 26.5

    def test_parse_sample_type(self):
        from geotech_report_extraction.parsers.generic import GenericParser
        assert GenericParser._parse_sample_type("SS") == SampleType.SPLIT_SPOON
        assert GenericParser._parse_sample_type("ST") == SampleType.SHELBY_TUBE
        assert GenericParser._parse_sample_type("RB") == SampleType.ROCK_CORE
        assert GenericParser._parse_sample_type("SA") == SampleType.AUGER
        assert GenericParser._parse_sample_type("XX") is None

    def test_is_new_layer(self):
        from geotech_report_extraction.parsers.generic import GenericParser
        assert GenericParser._is_new_layer("SAND, fine to medium")
        assert GenericParser._is_new_layer("CLAY, brown, stiff")
        assert GenericParser._is_new_layer("FILL - LEAN CLAY")
        assert GenericParser._is_new_layer("SILTY SAND with gravel")
        assert not GenericParser._is_new_layer("trace sand and gravel")
        assert not GenericParser._is_new_layer("with some organics")

    def test_build_soil_layer_uscs(self):
        from geotech_report_extraction.parsers.generic import GenericParser
        from geotech_report_extraction.models import USCSClassification
        parser = GenericParser()
        layer = parser._build_soil_layer(5.0, 10.0, ["LEAN CLAY CL", "brown, stiff"])
        assert layer is not None
        assert layer.uscs_classification == USCSClassification.CL
        assert layer.color == "brown"
        assert layer.depth_top_ft == 5.0
        assert layer.depth_bottom_ft == 10.0

    def test_build_soil_layer_empty(self):
        from geotech_report_extraction.parsers.generic import GenericParser
        parser = GenericParser()
        assert parser._build_soil_layer(0.0, None, []) is None

    def test_build_soil_layer_uscs_parenthesized(self):
        """Parenthesized USCS codes like '(CL)' should take priority over
        accidental word matches like SP in 'SANDY'."""
        from geotech_report_extraction.parsers.generic import GenericParser
        from geotech_report_extraction.models import USCSClassification
        parser = GenericParser()
        # "SANDY LEAN CLAY (CL)" — SP appears in "SANDY" but (CL) is explicit
        layer = parser._build_soil_layer(
            0.0, 10.0, ["SANDY LEAN CLAY (CL), brown, stiff"]
        )
        assert layer is not None
        assert layer.uscs_classification == USCSClassification.CL

    def test_build_soil_layer_uscs_dual_parenthesized(self):
        """Dual USCS codes like '(SP-SM)' should fall back to the
        primary classification (SP) since the enum has single codes only."""
        from geotech_report_extraction.parsers.generic import GenericParser
        from geotech_report_extraction.models import USCSClassification
        parser = GenericParser()
        layer = parser._build_soil_layer(
            0.0, 5.0, ["SILTY SAND (SP-SM), brown"]
        )
        assert layer is not None
        assert layer.uscs_classification == USCSClassification.SP

    def test_detect_depth_scale_linear(self):
        """Detect linear depth scale from page with evenly-spaced depth labels."""
        from geotech_report_extraction.parsers.generic import GenericParser
        # Create a page with depth labels at known y-positions
        # Scale: depth = 0.05 * y - 5.0, so y=100→0ft, y=200→5ft, y=300→10ft
        page = PageContent(
            page_number=1,
            text="Boring Log B-1\n",
            boring_id="B-1",
            width=612.0,
            height=792.0,
            words=[
                {"text": "0", "x0": 50.0, "top": 100.0, "x1": 60.0, "bottom": 110.0},
                {"text": "5", "x0": 50.0, "top": 200.0, "x1": 60.0, "bottom": 210.0},
                {"text": "10", "x0": 50.0, "top": 300.0, "x1": 60.0, "bottom": 310.0},
                {"text": "15", "x0": 50.0, "top": 400.0, "x1": 60.0, "bottom": 410.0},
                {"text": "20", "x0": 50.0, "top": 500.0, "x1": 60.0, "bottom": 510.0},
            ],
        )
        scale = GenericParser._detect_depth_scale(page)
        assert scale is not None
        scale_m, scale_b = scale
        # Check that the scale correctly maps y-positions to depths
        assert abs(scale_m * 100 + scale_b - 0.0) < 0.5
        assert abs(scale_m * 300 + scale_b - 10.0) < 0.5
        assert abs(scale_m * 500 + scale_b - 20.0) < 0.5

    def test_detect_depth_scale_no_data(self):
        """No scale detected when page has no depth-like numbers."""
        from geotech_report_extraction.parsers.generic import GenericParser
        page = PageContent(
            page_number=1,
            text="No numeric data here\n",
            width=612.0,
            height=792.0,
            words=[
                {"text": "SAND", "x0": 100.0, "top": 200.0, "x1": 150.0, "bottom": 210.0},
            ],
        )
        assert GenericParser._detect_depth_scale(page) is None

    def test_detect_depth_scale_rejects_nonlinear(self):
        """Non-monotonic or non-linear sequences should be rejected."""
        from geotech_report_extraction.parsers.generic import GenericParser
        # Values that are NOT monotonically increasing
        page = PageContent(
            page_number=1,
            text="test\n",
            width=612.0,
            height=792.0,
            words=[
                {"text": "20", "x0": 50.0, "top": 100.0, "x1": 60.0, "bottom": 110.0},
                {"text": "10", "x0": 50.0, "top": 200.0, "x1": 60.0, "bottom": 210.0},
                {"text": "30", "x0": 50.0, "top": 300.0, "x1": 60.0, "bottom": 310.0},
            ],
        )
        assert GenericParser._detect_depth_scale(page) is None

    def test_find_stacked_blow_count_columns(self):
        """Three adjacent columns of varied integers should be detected as stacked blow counts."""
        from geotech_report_extraction.parsers.generic import GenericParser
        # Simulate TxDOT-style layout: 3 columns at x=490, 516, 539
        # Each has 3+ values at similar y-positions (different blow counts)
        words = [
            # Depth column (x=37, should be excluded)
            {"text": "5", "x0": 37.0, "top": 310.0, "x1": 47.0, "bottom": 320.0},
            {"text": "10", "x0": 37.0, "top": 396.0, "x1": 47.0, "bottom": 406.0},
            {"text": "15", "x0": 37.0, "top": 482.0, "x1": 47.0, "bottom": 492.0},
            {"text": "20", "x0": 37.0, "top": 569.0, "x1": 47.0, "bottom": 579.0},
            # 1st 6-inch column (x~490)
            {"text": "18", "x0": 490.0, "top": 408.0, "x1": 505.0, "bottom": 418.0},
            {"text": "16", "x0": 490.0, "top": 494.0, "x1": 505.0, "bottom": 504.0},
            {"text": "35", "x0": 490.0, "top": 619.0, "x1": 505.0, "bottom": 629.0},
            # 2nd 6-inch column (x~516)
            {"text": "38", "x0": 516.0, "top": 408.0, "x1": 531.0, "bottom": 418.0},
            {"text": "43", "x0": 516.0, "top": 494.0, "x1": 531.0, "bottom": 504.0},
            {"text": "67", "x0": 516.0, "top": 619.0, "x1": 531.0, "bottom": 629.0},
            # 3rd 6-inch column (x~539)
            {"text": "18", "x0": 539.0, "top": 408.0, "x1": 554.0, "bottom": 418.0},
            {"text": "26", "x0": 539.0, "top": 494.0, "x1": 554.0, "bottom": 504.0},
            {"text": "32", "x0": 539.0, "top": 619.0, "x1": 554.0, "bottom": 629.0},
        ]
        width = 612.0
        depth_xs = [37.0 / width] * 4  # depth column at x~0.06
        stacked = GenericParser._find_stacked_blow_count_columns(
            words, width, depth_xs
        )
        assert stacked is not None
        assert len(stacked) >= 1
        # Should find a group of 3 columns
        assert len(stacked[0]) == 3
