"""Tests for DI-specific boring log parsers (Schnabel + Langan).

Covers Tier 1 (pure functions) and Tier 2 (mock PageContent) methods
for both SchnabelDIParser and LanganDIParser.
"""

import pytest

from geotech_report_extraction.models import (
    MoistureCondition,
    Sample,
    SampleType,
    SoilLayer,
    SPTBlowCounts,
    USCSClassification,
)
from geotech_report_extraction.parsers.schnabel_di import SchnabelDIParser
from geotech_report_extraction.parsers.langan_di import LanganDIParser
from geotech_report_extraction.pdf_parser import PageContent


# ═══════════════════════════════════════════════════════════════════════
# SchnabelDIParser Tests
# ═══════════════════════════════════════════════════════════════════════


class TestSchnabelParseNumeric:
    def test_integer(self):
        assert SchnabelDIParser._parse_numeric("10") == 10.0

    def test_float(self):
        assert SchnabelDIParser._parse_numeric("4.50") == 4.5

    def test_with_whitespace(self):
        assert SchnabelDIParser._parse_numeric("  7.2  ") == 7.2

    def test_empty(self):
        assert SchnabelDIParser._parse_numeric("") is None
        assert SchnabelDIParser._parse_numeric(None) is None

    def test_non_numeric(self):
        assert SchnabelDIParser._parse_numeric("abc") is None
        assert SchnabelDIParser._parse_numeric("12.3.4") is None

    def test_negative_ignored(self):
        # Schnabel regex uses ^-?(\d+\.?\d*)$ but captures group(1) without sign
        result = SchnabelDIParser._parse_numeric("-5.0")
        assert result == 5.0


class TestSchnabelParseBlowCountsPlus:
    def test_standard_three_part(self):
        spt = SchnabelDIParser._parse_blow_counts_plus("2+4+6")
        assert spt.first_6in == 2
        assert spt.second_6in == 4
        assert spt.third_6in == 6
        assert spt.n_value == 10
        assert spt.refusal is False

    def test_with_spaces(self):
        spt = SchnabelDIParser._parse_blow_counts_plus("5 + 8 + 12")
        assert spt.n_value == 20

    def test_refusal_high_n(self):
        spt = SchnabelDIParser._parse_blow_counts_plus("15+25+30")
        assert spt.n_value == 55
        assert spt.refusal is True

    def test_dash_separated(self):
        spt = SchnabelDIParser._parse_blow_counts_plus("3-6-9")
        assert spt.first_6in == 3
        assert spt.n_value == 15

    def test_slash_separated(self):
        spt = SchnabelDIParser._parse_blow_counts_plus("4/8/12")
        assert spt.n_value == 20

    def test_refusal_keyword(self):
        spt = SchnabelDIParser._parse_blow_counts_plus("ref")
        assert spt.refusal is True

    def test_empty(self):
        assert SchnabelDIParser._parse_blow_counts_plus("") is None
        assert SchnabelDIParser._parse_blow_counts_plus(None) is None

    def test_woh(self):
        spt = SchnabelDIParser._parse_blow_counts_plus("WOH")
        assert spt.refusal is True


class TestSchnabelCleanSampleNo:
    def test_valid_number(self):
        assert SchnabelDIParser._clean_sample_no("1") == "1"
        assert SchnabelDIParser._clean_sample_no("12") == "12"

    def test_strips_whitespace(self):
        assert SchnabelDIParser._clean_sample_no("  3  ") == "3"

    def test_rejects_header_words(self):
        assert SchnabelDIParser._clean_sample_no("depth") is None
        assert SchnabelDIParser._clean_sample_no("wl") is None
        assert SchnabelDIParser._clean_sample_no("no.") is None

    def test_rejects_continuation_marker(self):
        assert SchnabelDIParser._clean_sample_no("- 8") is None
        assert SchnabelDIParser._clean_sample_no("-") is None

    def test_empty(self):
        assert SchnabelDIParser._clean_sample_no("") is None
        assert SchnabelDIParser._clean_sample_no(None) is None


class TestSchnabelIsHeaderText:
    def test_header_words(self):
        assert SchnabelDIParser._is_header_text("depth") is True
        assert SchnabelDIParser._is_header_text("DESCRIPTION") is True
        assert SchnabelDIParser._is_header_text("sampling") is True
        assert SchnabelDIParser._is_header_text("blows/ft.") is True

    def test_non_header(self):
        assert SchnabelDIParser._is_header_text("SAND") is False
        assert SchnabelDIParser._is_header_text("brown") is False
        assert SchnabelDIParser._is_header_text("4.50") is False


class TestSchnabelIsNewLayerDescription:
    def test_soil_types(self):
        assert SchnabelDIParser._is_new_layer_description("SAND, brown, fine") is True
        assert SchnabelDIParser._is_new_layer_description("CLAY, gray, stiff") is True
        assert SchnabelDIParser._is_new_layer_description("FILL: gravel and sand") is True
        assert SchnabelDIParser._is_new_layer_description("WEATHERED ROCK") is True
        assert SchnabelDIParser._is_new_layer_description("FAT CLAY, dark brown") is True

    def test_continuation_lines(self):
        assert SchnabelDIParser._is_new_layer_description("with trace gravel") is False
        assert SchnabelDIParser._is_new_layer_description("fine to medium") is False
        assert SchnabelDIParser._is_new_layer_description("3.5") is False


class TestSchnabelInterpolateDepth:
    """Test depth interpolation using calibration points."""

    def setup_method(self):
        self.parser = SchnabelDIParser()
        # Simple linear scale: y=100->depth=0, y=300->depth=10, y=500->depth=20
        self.scale = [(100.0, 0.0), (300.0, 10.0), (500.0, 20.0)]

    def test_exact_match(self):
        assert self.parser._interpolate_depth(100.0, self.scale) == 0.0
        assert self.parser._interpolate_depth(300.0, self.scale) == 10.0
        assert self.parser._interpolate_depth(500.0, self.scale) == 20.0

    def test_interpolation(self):
        result = self.parser._interpolate_depth(200.0, self.scale)
        assert abs(result - 5.0) < 0.01

    def test_extrapolation_below(self):
        result = self.parser._interpolate_depth(600.0, self.scale)
        assert abs(result - 25.0) < 0.01

    def test_extrapolation_above_clamped(self):
        # Above first point should clamp to >= 0
        result = self.parser._interpolate_depth(50.0, self.scale)
        assert result >= 0.0

    def test_negative_clamp(self):
        # Far above should clamp to 0, not go negative
        result = self.parser._interpolate_depth(0.0, self.scale)
        assert result >= 0.0

    def test_empty_scale(self):
        assert self.parser._interpolate_depth(100.0, []) is None

    def test_single_point(self):
        result = self.parser._interpolate_depth(200.0, [(100.0, 5.0)])
        assert result == 5.0


class TestSchnabelBuildSoilLayer:
    def setup_method(self):
        self.parser = SchnabelDIParser()

    def test_basic_layer_meters(self):
        layer = self.parser._build_soil_layer(
            2.0, 5.0, ["SAND, brown, medium dense"], "m"
        )
        assert layer is not None
        assert abs(layer.depth_top_ft - 2.0 * 3.28084) < 0.01
        assert layer.color == "brown"
        assert "SAND" in layer.description

    def test_basic_layer_feet(self):
        layer = self.parser._build_soil_layer(
            10.0, 20.0, ["CLAY, gray, stiff"], "ft"
        )
        assert layer is not None
        assert layer.depth_top_ft == 10.0
        assert layer.depth_bottom_ft == 20.0
        assert layer.color == "gray"

    def test_uscs_extraction(self):
        layer = self.parser._build_soil_layer(
            0.0, 5.0, ["SAND, brown, SP"], "ft"
        )
        assert layer.uscs_classification == USCSClassification.SP

    def test_moisture_extraction(self):
        layer = self.parser._build_soil_layer(
            0.0, 5.0, ["SAND, brown, moist"], "ft"
        )
        assert layer.moisture == MoistureCondition.MOIST

    def test_empty_description(self):
        assert self.parser._build_soil_layer(0.0, 5.0, [], "ft") is None
        assert self.parser._build_soil_layer(0.0, 5.0, ["   "], "ft") is None

    def test_multi_line(self):
        layer = self.parser._build_soil_layer(
            0.0, 5.0, ["SAND, brown,", "fine to medium,", "dense"], "ft"
        )
        assert "fine to medium" in layer.description


class TestSchnabelGroupWordsByRow:
    def setup_method(self):
        self.parser = SchnabelDIParser()

    def test_groups_close_y(self):
        words = [
            {"text": "A", "x0": 10, "top": 100.0, "x1": 20, "bottom": 110},
            {"text": "B", "x0": 50, "top": 101.0, "x1": 60, "bottom": 111},
            {"text": "C", "x0": 10, "top": 200.0, "x1": 20, "bottom": 210},
        ]
        rows = self.parser._group_words_by_row(words)
        assert len(rows) == 2
        # First row should have 2 words, second row 1
        row_sizes = sorted([len(v) for v in rows.values()])
        assert row_sizes == [1, 2]

    def test_empty(self):
        rows = self.parser._group_words_by_row([])
        assert len(rows) == 0


class TestSchnabelDetectUnit:
    def setup_method(self):
        self.parser = SchnabelDIParser()

    def test_meters(self):
        page = PageContent(
            page_number=1,
            text="Depth (m)\nSample Data",
            boring_id="SB-1",
        )
        assert self.parser._detect_unit(page) == "m"

    def test_feet(self):
        page = PageContent(
            page_number=1,
            text="Depth (ft)\nSample Data",
            boring_id="SB-1",
        )
        assert self.parser._detect_unit(page) == "ft"

    def test_default_meters(self):
        page = PageContent(
            page_number=1,
            text="Boring Log Data",
            boring_id="SB-1",
        )
        # Default for Schnabel is meters
        assert self.parser._detect_unit(page) == "m"


class TestSchnabelInferTotalDepth:
    def test_with_samples(self):
        samples = [
            Sample(depth_top_ft=0.0, depth_bottom_ft=5.0),
            Sample(depth_top_ft=10.0, depth_bottom_ft=15.0),
            Sample(depth_top_ft=20.0, depth_bottom_ft=26.5),
        ]
        assert SchnabelDIParser._infer_total_depth(samples) == 26.5

    def test_empty(self):
        assert SchnabelDIParser._infer_total_depth([]) == 0.0


# ═══════════════════════════════════════════════════════════════════════
# LanganDIParser Tests
# ═══════════════════════════════════════════════════════════════════════


class TestLanganParseNumeric:
    def test_integer(self):
        assert LanganDIParser._parse_numeric("10") == 10.0

    def test_float(self):
        assert LanganDIParser._parse_numeric("4.50") == 4.5

    def test_positive_sign(self):
        # Langan regex allows +/- prefix
        assert LanganDIParser._parse_numeric("+1200.5") == 1200.5

    def test_empty(self):
        assert LanganDIParser._parse_numeric("") is None
        assert LanganDIParser._parse_numeric(None) is None

    def test_non_numeric(self):
        assert LanganDIParser._parse_numeric("abc") is None


class TestLanganCleanSampleNo:
    def test_standard_formats(self):
        assert LanganDIParser._clean_sample_no("S1") == "S1"
        assert LanganDIParser._clean_sample_no("S-1") == "S-1"
        assert LanganDIParser._clean_sample_no("G1") == "G1"

    def test_bare_digit(self):
        assert LanganDIParser._clean_sample_no("1") == "1"
        assert LanganDIParser._clean_sample_no("12") == "12"

    def test_rejects_header_words(self):
        assert LanganDIParser._clean_sample_no("depth") is None
        assert LanganDIParser._clean_sample_no("sample") is None
        assert LanganDIParser._clean_sample_no("(m)") is None
        assert LanganDIParser._clean_sample_no("ss") is None

    def test_rejects_special_chars(self):
        assert LanganDIParser._clean_sample_no("-5") is None
        assert LanganDIParser._clean_sample_no("(CL)") is None
        assert LanganDIParser._clean_sample_no("[SC]") is None

    def test_rejects_description_fragments(self):
        # Anything that doesn't look like a sample ID
        assert LanganDIParser._clean_sample_no("SAND") is None
        assert LanganDIParser._clean_sample_no("brown") is None

    def test_empty(self):
        assert LanganDIParser._clean_sample_no("") is None
        assert LanganDIParser._clean_sample_no(None) is None


class TestLanganParseSampleType:
    def test_known_types(self):
        assert LanganDIParser._parse_sample_type("SS") == SampleType.SPLIT_SPOON
        assert LanganDIParser._parse_sample_type("GRAB") == SampleType.GRAB
        assert LanganDIParser._parse_sample_type("ST") == SampleType.SHELBY_TUBE
        assert LanganDIParser._parse_sample_type("RC") == SampleType.ROCK_CORE
        assert LanganDIParser._parse_sample_type("AU") == SampleType.AUGER
        assert LanganDIParser._parse_sample_type("CS") == SampleType.CONTINUOUS
        assert LanganDIParser._parse_sample_type("CONT") == SampleType.CONTINUOUS
        assert LanganDIParser._parse_sample_type("NR") == SampleType.NO_RECOVERY

    def test_case_insensitive(self):
        assert LanganDIParser._parse_sample_type("ss") == SampleType.SPLIT_SPOON
        assert LanganDIParser._parse_sample_type("grab") == SampleType.GRAB

    def test_unknown_returns_other(self):
        assert LanganDIParser._parse_sample_type("XYZ") == SampleType.OTHER

    def test_empty(self):
        assert LanganDIParser._parse_sample_type("") is None
        assert LanganDIParser._parse_sample_type(None) is None


class TestLanganExtractUSCS:
    def test_brackets(self):
        assert LanganDIParser._extract_uscs_from_description(
            "SAND, brown, medium dense [SP]"
        ) == USCSClassification.SP

    def test_brackets_dual(self):
        # Dual classification: takes first part
        result = LanganDIParser._extract_uscs_from_description(
            "SILTY SAND [SP-SM]"
        )
        assert result == USCSClassification.SP

    def test_parentheses(self):
        assert LanganDIParser._extract_uscs_from_description(
            "(CH) FAT CLAY, dark brown"
        ) == USCSClassification.CH

    def test_standalone(self):
        assert LanganDIParser._extract_uscs_from_description(
            "LEAN CLAY CL, brown"
        ) == USCSClassification.CL

    def test_no_uscs(self):
        assert LanganDIParser._extract_uscs_from_description(
            "brown, medium dense, with trace gravel"
        ) is None


class TestLanganIsValidProjectName:
    def test_valid_names(self):
        assert LanganDIParser._is_valid_project_name("New Embassy Compound") is True
        assert LanganDIParser._is_valid_project_name("Kampala NEC") is True

    def test_rejects_headings(self):
        assert LanganDIParser._is_valid_project_name("DESCRIPTION") is False
        assert LanganDIParser._is_valid_project_name("INFORMATION") is False
        assert LanganDIParser._is_valid_project_name("NUMBER") is False
        assert LanganDIParser._is_valid_project_name("SYMBOL") is False

    def test_rejects_short(self):
        assert LanganDIParser._is_valid_project_name("") is False
        assert LanganDIParser._is_valid_project_name("AB") is False


class TestLanganIsHeaderText:
    def test_header_words(self):
        assert LanganDIParser._is_header_text("depth") is True
        assert LanganDIParser._is_header_text("DESCRIPTION") is True
        assert LanganDIParser._is_header_text("bl/15cm") is True
        assert LanganDIParser._is_header_text("(blows/30cm)") is True
        assert LanganDIParser._is_header_text("scale") is True

    def test_non_header(self):
        assert LanganDIParser._is_header_text("SAND") is False
        assert LanganDIParser._is_header_text("4.50") is False


class TestLanganIsNewLayerDescription:
    def test_soil_types(self):
        assert LanganDIParser._is_new_layer_description("SAND, brown, fine") is True
        assert LanganDIParser._is_new_layer_description("CLAY, gray, stiff") is True
        assert LanganDIParser._is_new_layer_description("LATERITE, red") is True
        assert LanganDIParser._is_new_layer_description("DARK brown sandy clay") is True

    def test_continuation_lines(self):
        assert LanganDIParser._is_new_layer_description("with trace gravel") is False
        assert LanganDIParser._is_new_layer_description("fine to medium") is False

    def test_brackets_parens(self):
        # Lines starting with ( or [ are continuation
        assert LanganDIParser._is_new_layer_description("(continued)") is False
        assert LanganDIParser._is_new_layer_description("[SC]") is False


class TestLanganInterpolateDepth:
    def setup_method(self):
        self.parser = LanganDIParser()
        self.scale = [(100.0, 0.0), (300.0, 10.0), (500.0, 20.0)]

    def test_exact_match(self):
        assert self.parser._interpolate_depth(100.0, self.scale) == 0.0
        assert self.parser._interpolate_depth(300.0, self.scale) == 10.0

    def test_interpolation(self):
        result = self.parser._interpolate_depth(200.0, self.scale)
        assert abs(result - 5.0) < 0.01

    def test_extrapolation_below(self):
        result = self.parser._interpolate_depth(600.0, self.scale)
        assert abs(result - 25.0) < 0.01

    def test_negative_clamp(self):
        result = self.parser._interpolate_depth(0.0, self.scale)
        assert result >= 0.0

    def test_empty_scale(self):
        assert self.parser._interpolate_depth(100.0, []) is None

    def test_single_point(self):
        assert self.parser._interpolate_depth(200.0, [(100.0, 5.0)]) == 5.0


class TestLanganBuildSPTFromBlows:
    def test_three_blows(self):
        blows = [(100.0, 3), (105.0, 6), (110.0, 9)]
        spt = LanganDIParser._build_spt_from_blows(blows, [])
        assert spt.first_6in == 3
        assert spt.second_6in == 6
        assert spt.third_6in == 9
        assert spt.n_value == 15  # 6 + 9
        assert spt.refusal is False

    def test_three_blows_with_n_value(self):
        blows = [(100.0, 3), (105.0, 6), (110.0, 9)]
        n_vals = [(107.0, "15")]
        spt = LanganDIParser._build_spt_from_blows(blows, n_vals)
        assert spt.n_value == 15

    def test_refusal_n_value(self):
        blows = [(100.0, 20), (105.0, 25), (110.0, 30)]
        n_vals = [(107.0, "50/24-")]
        spt = LanganDIParser._build_spt_from_blows(blows, n_vals)
        assert spt.refusal is True

    def test_two_blows(self):
        blows = [(100.0, 5), (105.0, 8)]
        spt = LanganDIParser._build_spt_from_blows(blows, [])
        assert spt.first_6in == 5
        assert spt.second_6in == 8

    def test_one_blow(self):
        blows = [(100.0, 12)]
        spt = LanganDIParser._build_spt_from_blows(blows, [])
        assert spt.first_6in == 12

    def test_n_value_only(self):
        spt = LanganDIParser._build_spt_from_blows([], [(100.0, "25")])
        assert spt.n_value == 25

    def test_no_data(self):
        assert LanganDIParser._build_spt_from_blows([], []) is None

    def test_high_n_is_refusal(self):
        blows = [(100.0, 15), (105.0, 25), (110.0, 30)]
        n_vals = [(107.0, "55")]
        spt = LanganDIParser._build_spt_from_blows(blows, n_vals)
        assert spt.refusal is True


class TestLanganBuildSoilLayer:
    def setup_method(self):
        self.parser = LanganDIParser()

    def test_meters_conversion(self):
        layer = self.parser._build_soil_layer(
            3.0, 6.0, ["SAND, brown, medium dense [SP]"], "m"
        )
        assert layer is not None
        assert abs(layer.depth_top_ft - 3.0 * 3.28084) < 0.01
        assert layer.uscs_classification == USCSClassification.SP
        assert layer.color == "brown"

    def test_feet_no_conversion(self):
        layer = self.parser._build_soil_layer(
            10.0, 20.0, ["CLAY, gray, stiff"], "ft"
        )
        assert layer.depth_top_ft == 10.0
        assert layer.depth_bottom_ft == 20.0

    def test_none_depth_top(self):
        layer = self.parser._build_soil_layer(
            None, 5.0, ["FILL, gravel"], "ft"
        )
        assert layer.depth_top_ft == 0.0

    def test_empty_description(self):
        assert self.parser._build_soil_layer(0.0, 5.0, [], "ft") is None


class TestLanganDeduplicateSamples:
    def test_removes_duplicates(self):
        samples = [
            Sample(sample_number="S1", depth_top_ft=5.0, depth_bottom_ft=6.5),
            Sample(sample_number="S1", depth_top_ft=5.0, depth_bottom_ft=6.5),
        ]
        result = LanganDIParser._deduplicate_samples(samples)
        assert len(result) == 1

    def test_keeps_one_with_more_data(self):
        s1 = Sample(sample_number="S1", depth_top_ft=5.0, depth_bottom_ft=6.5)
        s2 = Sample(
            sample_number="S1", depth_top_ft=5.0, depth_bottom_ft=6.5,
            spt=SPTBlowCounts(n_value=15),
        )
        result = LanganDIParser._deduplicate_samples([s1, s2])
        assert len(result) == 1
        assert result[0].spt is not None

    def test_different_samples_kept(self):
        samples = [
            Sample(sample_number="S1", depth_top_ft=5.0, depth_bottom_ft=6.5),
            Sample(sample_number="S2", depth_top_ft=10.0, depth_bottom_ft=11.5),
        ]
        result = LanganDIParser._deduplicate_samples(samples)
        assert len(result) == 2

    def test_empty(self):
        assert LanganDIParser._deduplicate_samples([]) == []


class TestLanganDeduplicateLayers:
    def test_removes_duplicates(self):
        layers = [
            SoilLayer(depth_top_ft=0.0, depth_bottom_ft=5.0, description="SAND, brown, medium dense"),
            SoilLayer(depth_top_ft=0.0, depth_bottom_ft=5.0, description="SAND, brown, medium dense"),
        ]
        result = LanganDIParser._deduplicate_layers(layers)
        assert len(result) == 1

    def test_keeps_different_layers(self):
        layers = [
            SoilLayer(depth_top_ft=0.0, depth_bottom_ft=5.0, description="SAND, brown"),
            SoilLayer(depth_top_ft=5.0, depth_bottom_ft=10.0, description="CLAY, gray"),
        ]
        result = LanganDIParser._deduplicate_layers(layers)
        assert len(result) == 2

    def test_empty(self):
        assert LanganDIParser._deduplicate_layers([]) == []


class TestLanganInferTotalDepth:
    def test_with_samples(self):
        samples = [
            Sample(depth_top_ft=0.0, depth_bottom_ft=5.0),
            Sample(depth_top_ft=10.0, depth_bottom_ft=15.0),
            Sample(depth_top_ft=20.0, depth_bottom_ft=30.0),
        ]
        assert LanganDIParser._infer_total_depth(samples) == 30.0

    def test_empty(self):
        assert LanganDIParser._infer_total_depth([]) == 0.0


class TestLanganDetectUnit:
    def setup_method(self):
        self.parser = LanganDIParser()

    def test_meters(self):
        page = PageContent(
            page_number=1,
            text="Depth Scale (m)\nSample Data",
            boring_id="LB-1",
        )
        assert self.parser._detect_unit(page) == "m"

    def test_feet(self):
        page = PageContent(
            page_number=1,
            text="Depth (ft)\nSample Data",
            boring_id="SB-1",
        )
        assert self.parser._detect_unit(page) == "ft"


class TestLanganGroupWordsByRow:
    def setup_method(self):
        self.parser = LanganDIParser()

    def test_groups_close_y(self):
        words = [
            {"text": "A", "x0": 10, "top": 100.0, "x1": 20, "bottom": 110},
            {"text": "B", "x0": 50, "top": 101.5, "x1": 60, "bottom": 111},
            {"text": "C", "x0": 10, "top": 200.0, "x1": 20, "bottom": 210},
        ]
        rows = self.parser._group_words_by_row(words)
        assert len(rows) == 2

    def test_custom_tolerance(self):
        words = [
            {"text": "A", "x0": 10, "top": 100.0, "x1": 20, "bottom": 110},
            {"text": "B", "x0": 50, "top": 108.0, "x1": 60, "bottom": 118},
        ]
        # Default tolerance should separate these
        rows_default = self.parser._group_words_by_row(words)
        # Wider tolerance should group them
        rows_wide = self.parser._group_words_by_row(words, tolerance=10.0)
        assert len(rows_wide) <= len(rows_default)
