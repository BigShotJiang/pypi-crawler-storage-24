# kDrive Uploader

A small tool to programmatically upload files to [kDrive drop boxes](https://www.infomaniak.com/en/support/faq/2386/manage-kdrive-drop-boxes), used by the author as a poor man's backup solution.

## Quickstart

First install with `pip` then run:

```bash
pip install kdrive-uploader

# upload all files in current folder
kdrive-uploader 0000000/00000000-0000-0000-0000-000000000000

# upload a specific file
kdrive-uploader 0000000/00000000-0000-0000-0000-000000000000 README.md
```

The link can either be just the last part containing the ids as above or a full kDrive drop box link (in the shape `https://kdrive.infomaniak.com/app/collaborate/0000000/00000000-0000-0000-0000-000000000000`).

You can also run it directly using `uv`:

```bash
uvx kdrive-uploader --help
```

Or with docker (still using `uv`):

```bash
docker run --rm --workdir /io -v .:/io -v uv-cache:/root/ ghcr.io/astral-sh/uv:alpine uvx kdrive-uploader --help
```

## Manual

```
Usage: kdrive-uploader [OPTIONS] LINK [PATH]

╭─ Arguments ────────────────────────────────────────────────────────────────────────────────────────╮
│ *    link      TEXT    [required]                                                                  │
│      path      [PATH]  [default: .]                                                                │
╰────────────────────────────────────────────────────────────────────────────────────────────────────╯
╭─ Options ──────────────────────────────────────────────────────────────────────────────────────────╮
│ --first-name                    TEXT  [default: kdrive]                                            │
│ --last-name                     TEXT  [default: uploader]                                          │
│ --email                         TEXT  [default: kdrive-uploader@ik.me]                             │
│ --dry-run       --no-dry-run          [default: no-dry-run]                                        │
│ --help                                Show this message and exit.                                  │
╰────────────────────────────────────────────────────────────────────────────────────────────────────╯
```

## Dev/quickstart

```bash
# create dev env
uv sync --dev

# test
cd test_data
uv run kdrive-uploader 0000000/00000000-0000-0000-0000-000000000000
```
