# Guide resources package
