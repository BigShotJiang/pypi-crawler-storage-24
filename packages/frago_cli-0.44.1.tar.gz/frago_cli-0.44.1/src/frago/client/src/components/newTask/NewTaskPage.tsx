import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { Compass, Bot, FileCode, Play } from 'lucide-react';
import { useAppStore } from '@/stores/appStore';
import { getWebSocketClient } from '@/api/websocket';
import { recordDirectoriesFromText } from '@/utils/recentDirectories';
import type { ConsoleMessage } from '@/types/console';
import { toUnifiedMessage } from '@/types/message';
import NewTaskControls from './NewTaskControls';
import { MessageList } from '@/components/shared';
import NewTaskInput from './NewTaskInput';
import * as httpApi from '@/api/client';

export default function NewTaskPage() {
  const { t } = useTranslation();
  const {
    showToast,
    // Console state from global store (used for in-page streaming before redirect)
    consoleInternalId,
    consoleMessages,
    consoleIsRunning,
    consoleScrollPosition,
    // Console actions
    setConsoleInternalId,
    setConsoleSessionId,
    addConsoleMessage,
    updateLastConsoleMessage,
    updateConsoleMessageByToolCallId,
    setConsoleIsRunning,
    setConsoleScrollPosition,
    clearConsole,
    // Agent attached session
    setAgentAttachedId,
  } = useAppStore();

  // Local state for input (no need to persist draft)
  const [inputValue, setInputValue] = useState('');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Restore scroll position on mount
  useEffect(() => {
    if (consoleScrollPosition > 0 && scrollContainerRef.current) {
      scrollContainerRef.current.scrollTop = consoleScrollPosition;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Only run on mount

  // Save scroll position on unmount
  useEffect(() => {
    return () => {
      const container = scrollContainerRef.current;
      if (container) {
        setConsoleScrollPosition(container.scrollTop);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Only run on unmount

  // Restore session from localStorage on initial load (after page refresh)
  useEffect(() => {
    const restoreSession = async () => {
      // Skip if we already have a session in memory
      if (useAppStore.getState().consoleInternalId) return;

      try {
        const storedInternalId = localStorage.getItem('frago_console_internal_id');
        if (!storedInternalId) return;

        // Validate session still exists on backend (attached session)
        const response = await fetch(`/api/agent/attached/${storedInternalId}/info`);
        if (response.ok) {
          const info = await response.json();
          setConsoleInternalId(storedInternalId);
          if (info.session_id) {
            setConsoleSessionId(info.session_id);
          }
          setConsoleIsRunning(info.running === true);
        } else {
          // Session not found, clear localStorage
          localStorage.removeItem('frago_console_internal_id');
          localStorage.removeItem('frago_console_session_id');
        }
      } catch {
        localStorage.removeItem('frago_console_internal_id');
        localStorage.removeItem('frago_console_session_id');
      }
    };
    restoreSession();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Only run on initial mount

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [consoleMessages]);

  // Use ref to track internalId for WebSocket handler (avoids stale closure)
  const internalIdRef = useRef<string | null>(null);
  useEffect(() => {
    internalIdRef.current = consoleInternalId;
  }, [consoleInternalId]);

  // Memoize the WebSocket message handler to use latest store actions
  const handleWebSocketMessage = useCallback((data: Record<string, unknown>) => {
    // Filter messages by internal_id
    const currentInternalId = internalIdRef.current;
    const msgInternalId = data.internal_id as string | undefined;

    // Skip if message has internal_id that doesn't match ours
    if (msgInternalId && currentInternalId && msgInternalId !== currentInternalId) return;

    const messages = useAppStore.getState().consoleMessages;

    switch (data.type) {
      case 'agent_user_message':
        // User message already added locally
        break;

      case 'agent_text_delta': {
        // Streaming assistant response
        const last = messages[messages.length - 1];
        if (last?.type === 'assistant' && !last.done) {
          // Update existing streaming message
          updateLastConsoleMessage({
            content: last.content + (data.content as string),
            done: data.done as boolean,
          });
        } else if (!data.done) {
          // Start new streaming message
          addConsoleMessage({
            type: 'assistant',
            content: data.content as string,
            timestamp: new Date().toISOString(),
            done: false,
          });
        }
        break;
      }

      case 'agent_tool_executing':
        // Tool is executing
        addConsoleMessage({
          type: 'tool_call',
          content: JSON.stringify(data.parameters, null, 2),
          timestamp: new Date().toISOString(),
          tool_name: data.tool_name as string,
          tool_call_id: data.tool_call_id as string,
          metadata: { status: 'executing' },
        });
        break;

      case 'agent_tool_result':
        // Tool result received
        updateConsoleMessageByToolCallId(data.tool_call_id as string, {
          type: 'tool_result',
          metadata: {
            status: data.success ? 'success' : 'error',
            result: data.content,
          },
        });
        break;

      case 'agent_session_status':
        if (data.status === 'completed') {
          setConsoleIsRunning(false);
          // Ensure last message is marked as done
          const lastMsg = useAppStore.getState().consoleMessages.slice(-1)[0];
          if (lastMsg && lastMsg.type === 'assistant' && !lastMsg.done) {
            updateLastConsoleMessage({ done: true });
          }
        }
        break;

      case 'agent_session_resolved': {
        // Backend resolved the real Claude session ID
        const internalId = data.internal_id as string;
        const realSessionId = data.session_id as string;
        if (internalId === currentInternalId && realSessionId) {
          setConsoleSessionId(realSessionId);
          localStorage.setItem('frago_console_session_id', realSessionId);
        }
        break;
      }
    }
  }, [setConsoleSessionId, addConsoleMessage, updateLastConsoleMessage, updateConsoleMessageByToolCallId, setConsoleIsRunning]);

  // Subscribe to WebSocket messages using global client
  useEffect(() => {
    const client = getWebSocketClient();

    // Subscribe to all messages and filter agent-related ones
    const unsubscribe = client.on('*', (message) => {
      handleWebSocketMessage(message as unknown as Record<string, unknown>);
    });

    return () => {
      unsubscribe();
    };
  }, [handleWebSocketMessage]);

  const handleSend = async () => {
    if (!inputValue.trim()) return;

    // Record directories from the input
    recordDirectoriesFromText(inputValue);

    const userMessage: ConsoleMessage = {
      type: 'user',
      content: inputValue,
      timestamp: new Date().toISOString(),
    };

    // Add user message immediately
    addConsoleMessage(userMessage);
    setInputValue('');

    try {
      if (!consoleInternalId) {
        // Start new attached session
        const data = await httpApi.startAgentAttached(inputValue);
        // Store internal_id for API calls; real session_id comes via WebSocket
        setConsoleInternalId(data.internal_id);
        setConsoleIsRunning(true);
        // Store the attached ID for TaskDetail to use
        setAgentAttachedId(data.internal_id);
        localStorage.setItem('frago_console_internal_id', data.internal_id);
        showToast('Session started', 'success');
      } else {
        // Continue existing session using internal_id
        await httpApi.sendAgentAttachedMessage(consoleInternalId, inputValue);
      }
    } catch (error) {
      console.error('Failed to send message:', error);
      showToast('Failed to send message', 'error');
    }
  };

  const handleStop = async () => {
    if (!consoleInternalId) return;

    try {
      await httpApi.stopAgentAttached(consoleInternalId);

      setConsoleIsRunning(false);
      setConsoleInternalId(null);
      setConsoleSessionId(null);
      setAgentAttachedId(null);
      showToast('Session stopped', 'success');
    } catch (error) {
      console.error('Failed to stop session:', error);
      showToast('Failed to stop session', 'error');
    }
  };

  const handleNewSession = () => {
    clearConsole();
    setAgentAttachedId(null);
    setInputValue('');
  };

  // Convert ConsoleMessage[] to UnifiedMessage[]
  const unifiedMessages = useMemo(
    () => consoleMessages.map((msg, index) => toUnifiedMessage(msg, index)),
    [consoleMessages]
  );

  // Quick action handlers - prefill input with prompt template
  const quickActions = [
    { icon: Compass, label: t('console.quickActions.explore'), prompt: t('console.quickActions.explorePrompt') },
    { icon: Bot, label: t('console.quickActions.automate'), prompt: t('console.quickActions.automatePrompt') },
    { icon: FileCode, label: t('console.quickActions.createRecipe'), prompt: t('console.quickActions.createRecipePrompt') },
    { icon: Play, label: t('console.quickActions.testRecipe'), prompt: t('console.quickActions.testRecipePrompt') },
  ];

  const handleQuickAction = (prompt: string) => {
    setInputValue(prompt);
  };

  // Welcome screen for empty state
  const welcomeScreen = (
    <div className="welcome-screen">
      <div className="welcome-header">
        {/* Logo */}
        <img src="/icons/logo-128.png" alt="frago" className="welcome-logo-img" />
        <h1 className="welcome-headline">{t('console.welcomeHeadline')}</h1>
        <p className="welcome-subheadline">{t('console.welcomeSubheadline')}</p>
      </div>

      {/* Capsule toggle button */}
      <div className="approval-toggle mt-scaled-6">
        <button type="button" className="approval-toggle-option active">
          {t('console.autoApprove')}
        </button>
        <button
          type="button"
          className="approval-toggle-option disabled"
          title={t('console.manualApproveDisabledHint')}
          disabled
        >
          {t('console.manualApprove')}
        </button>
      </div>

      {/* Input area - inside welcome screen */}
      <div className="welcome-input-section">
        <NewTaskInput
          value={inputValue}
          onChange={setInputValue}
          onSend={handleSend}
          disabled={consoleIsRunning}
          placeholder={t('console.startConversation')}
        />
      </div>

      {/* Quick Actions */}
      <div className="quick-actions">
        {quickActions.map((action) => (
          <button
            key={action.label}
            type="button"
            className="quick-action-btn"
            onClick={() => handleQuickAction(action.prompt)}
            title={action.prompt}
          >
            <action.icon className="quick-action-icon" />
            <span>{action.label}</span>
          </button>
        ))}
      </div>
    </div>
  );

  return (
    <div className="flex flex-col h-full overflow-hidden gap-4 p-scaled-4">
      {/* Controls */}
      <div className="shrink-0">
        <NewTaskControls
          isRunning={consoleIsRunning}
          onNewSession={handleNewSession}
          onStop={handleStop}
        />
      </div>

      {/* Message area or Welcome screen */}
      {consoleMessages.length === 0 ? (
        <div className="flex-1 min-h-0 overflow-hidden flex flex-col">
          {welcomeScreen}
        </div>
      ) : (
        <>
          <div ref={scrollContainerRef} className="flex-1 min-h-0 card overflow-hidden flex flex-col overflow-y-auto">
            <MessageList
              messages={unifiedMessages}
              messagesEndRef={messagesEndRef}
              gap="space-y-4"
            />
          </div>

          {/* Input area - at bottom when has messages */}
          <div className="shrink-0">
            <NewTaskInput
              value={inputValue}
              onChange={setInputValue}
              onSend={handleSend}
              disabled={consoleIsRunning && consoleMessages[consoleMessages.length - 1]?.type === 'assistant' && !consoleMessages[consoleMessages.length - 1]?.done}
              placeholder={t('console.continueConversation')}
            />
          </div>
        </>
      )}
    </div>
  );
}
