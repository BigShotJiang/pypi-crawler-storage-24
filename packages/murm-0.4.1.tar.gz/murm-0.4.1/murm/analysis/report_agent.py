"""
Report generation agent.

Offers two modes: basic and expert.
- Basic: Assembly of evidence into a single prompt for a quick, robust prediction.
- Expert: A multi-step structured synthesis pipeline (Metrics Analysis -> Trace Analysis -> 
          Graph Grounding -> Final Synthesis) providing 10x deeper insight than standard.
          This handles complex reasoning without brittle ReACT loops that fail on diverse providers.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

from murm.graph.engine import KnowledgeGraph
from murm.graph.embedder import Embedder
from murm.llm.provider import LLMProvider
from murm.simulation.trace import TraceWriter

logger = logging.getLogger(__name__)

_REPORT_SYSTEM = (
    "You are a rigorous, highly-professional social science analyst. "
    "Write a structured prediction report grounded exclusively in the simulation evidence provided. "
    "Be direct and concrete. Make a specific prediction. Do not hedge excessively. "
    "CRITICAL NOTICES ON FORMATTING: \n"
    "1. NEVER use any emojis or emoticons under any circumstances.\n"
    "2. NEVER use markdown bolding (**text**) or italics (*text*). Use pure plain text only.\n"
    "3. NEVER use dramatic conversational filler, stylistic decorators, or AI cliches. Provide clean, academic, intelligence-grade text."
)


class ReportAgent:
    def __init__(
        self,
        llm:              LLMProvider,
        graph:            KnowledgeGraph,
        embedder:         Embedder,
        trace:            TraceWriter,
        metrics_summary:  dict,
        simulation_config: dict,
    ) -> None:
        self._llm     = llm
        self._graph   = graph
        self._embedder = embedder
        self._trace   = trace
        self._metrics = metrics_summary
        self._config  = simulation_config

    async def generate(self, prediction_question: str, mode: str = "basic") -> str:
        ctx = self._assemble_context(prediction_question)
        if mode == "expert":
            return await self._generate_expert(prediction_question, ctx)
        return await self._generate_basic(prediction_question, ctx)

    async def _generate_basic(self, prediction_question: str, ctx: dict) -> str:
        prompt = _build_report_prompt(prediction_question, ctx)

        logger.info("Generating basic report for: %s", prediction_question[:80])
        try:
            report = await self._llm.complete(
                messages=[
                    {"role": "system", "content": _REPORT_SYSTEM},
                    {"role": "user",   "content": prompt},
                ],
                temperature=0.3,
                max_tokens=3000,
            )
            return report.strip() or "Report generation returned an empty response."
        except Exception as exc:
            logger.error("Report generation failed: %s", exc)
            return _fallback_report(prediction_question, ctx, str(exc))

    async def _generate_expert(self, prediction_question: str, ctx: dict) -> str:
        # Identify injections (God Mode)
        injection_summary = "\n".join(ctx.get('injections', [])) or "None (Baseline Run)"

        try:
            # Step 1: Deep Metrics Analysis
            metrics_prompt = f"Analyze these simulation metrics for anomalies, turning points, and convergence patterns:\n{json.dumps(ctx['metrics'], indent=2)}\nOpinion trend:\n{json.dumps(ctx['opinion_trend'], indent=2)}"
            metrics_analysis = await self._llm.complete([{"role": "user", "content": metrics_prompt}], max_tokens=1000)
            
            # Step 2: Agent Discourse Trace Analysis
            trace_str = "\n".join(ctx['trace_sample'])
            trace_prompt = f"Analyze this agent discourse trace. Identify key arguments, influencer impacts, and moments where opinions shifted:\n{trace_str}"
            trace_analysis = await self._llm.complete([{"role": "user", "content": trace_prompt}], max_tokens=1000)

            # Step 3: Graph Grounding
            graph_str = "\n".join(ctx['graph_entities'])
            graph_prompt = f"Correlate the discourse with these factual entities from the source document. What entities drove the debate?\n{graph_str}"
            graph_analysis = await self._llm.complete([{"role": "user", "content": graph_prompt}], max_tokens=1000)

            # Step 4: Final Comprehensive Synthesis
            synth_prompt = f"""PREDICTION QUESTION: {prediction_question}

You are an elite intelligence analyst drafting an exhaustive, thesis-level prediction report. Synthesize the findings of your sub-agents into a massive, highly detailed final report.

METRICS ANALYSIS: {metrics_analysis}
DISCOURSE ANALYSIS: {trace_analysis}
FACTUAL GROUNDING: {graph_analysis}
GOD MODE INTERVENTIONS: {injection_summary}

Write an incredibly comprehensive, in-depth thesis report with the following structure. Do not hold back on detail. Exceed standard lengths. Include sub-bullets where helpful.

## Executive Summary
Provide a powerful, direct answer to the prediction question. Outline the core trajectory of the simulation in 2-3 substantial paragraphs.

## Key Themes & Findings
Identify the top 3-5 macro themes that defined the simulation. What overarching narratives dominated the population's shifting opinions?

## Deep Evidence & Metrics Breakdown
Provide a meticulous breakdown of the quantitative metrics (Entropy, Polarization, Velocity). Explain exactly what these numbers mean in the context of the prediction.

## Discourse & Influencer Analysis
Who drove the conversation? What specific arguments gained traction, and when did the major turning points occur? Detail the memetic spread of ideas.

## Contextual Grounding & Entity Impact
How did the specific factual entities from the source material shape the debate? Which entities acted as catalysts for opinion shifts?

## Impact of Theoretical Interventions
Contrast the baseline trajectory against any God Mode injections. How resilient was the population's consensus to external shocks?

## Leading Indicators & Warning Signs
What statistical or narrative signals emerged that observers should watch out for in the real world to track this prediction?

## Actionable Takeaways & Strategic Suggestions
Provide concrete, pragmatic suggestions based on the emergent dynamics. What should the stakeholders do next?

## Confidence Assessment & Limitations
Score: [write a number 0-100]
Provide a strict, critical justification for this score. Outline the strategic vulnerabilities and real-world factors the simulation failed to capture.
"""
            report = await self._llm.complete([{"role": "system", "content": _REPORT_SYSTEM}, {"role": "user", "content": synth_prompt}], temperature=0.4, max_tokens=4000)
            return report.strip()
        except Exception as exc:
            logger.error("Expert report generation failed: %s", exc)
            return _fallback_report(prediction_question, ctx, str(exc))

    def _assemble_context(self, question: str) -> dict:
        # Read all trace actions
        all_actions: list[dict] = []
        try:
            all_actions = self._trace.read_all()
        except Exception:
            pass

        # Subsample evenly for the prompt (40 actions max to stay within token budget)
        n = min(40, len(all_actions))
        step = max(1, len(all_actions) // n) if n else 1
        sampled = all_actions[::step][:n]

        # Build opinion trend by round
        by_round: dict[int, list[str]] = {}
        for a in all_actions:
            r = a.get("round", 0)
            op = a.get("opinion_shift") or a.get("current_opinion", "")
            if op:
                by_round.setdefault(r, []).append(op)

        opinion_trend: dict[str, str] = {}
        for r, ops in sorted(by_round.items()):
            counts: dict[str, int] = {}
            for o in ops:
                counts[o] = counts.get(o, 0) + 1
            opinion_trend[f"round_{r}"] = max(counts, key=counts.get) if counts else "neutral"

        # Top entities from graph
        graph_entities: list[str] = []
        try:
            for n in (self._graph.get_all_nodes() or [])[:10]:
                s = n.get("summary", "")[:80]
                graph_entities.append(f"{n.get('name','')} ({n.get('entity_type','')}): {s}")
        except Exception:
            pass

        # Format trace sample
        trace_lines = []
        for a in sampled:
            c = (a.get("content") or "")[:120]
            if c:
                op = a.get("opinion_shift") or ""
                trace_lines.append(f"R{a.get('round','?')} [{op}]: {c}")

        # Identify injections (God Mode)
        injections = []
        for a in all_actions:
            if a.get("action_type") == "external_event" or a.get("author_id") == "GodMode":
                injections.append(f"Round {a.get('round')}: {a.get('content')}")

        return {
            "metrics":        self._metrics,
            "opinion_trend":  opinion_trend,
            "trace_sample":   trace_lines,
            "graph_entities": graph_entities,
            "injections":     injections,
            "n_agents":       self._config.get("n_agents", "?"),
            "n_rounds":       self._config.get("n_rounds", "?"),
            "total_actions":  len(all_actions),
        }


def _build_report_prompt(question: str, ctx: dict) -> str:
    metrics_str = json.dumps(ctx["metrics"], indent=2) if ctx["metrics"] else "(no metrics)"
    trend_str   = json.dumps(ctx["opinion_trend"], indent=2) if ctx["opinion_trend"] else "(no trend data)"
    trace_str   = "\n".join(ctx["trace_sample"]) if ctx["trace_sample"] else "(no trace data)"
    graph_str   = "\n".join(ctx["graph_entities"]) if ctx["graph_entities"] else "(no graph data)"

    return f"""PREDICTION QUESTION: {question}

SIMULATION PARAMETERS:
Agents: {ctx['n_agents']}  |  Rounds: {ctx['n_rounds']}  |  Total actions: {ctx['total_actions']}

FINAL EMERGENCE METRICS:
{metrics_str}

DOMINANT OPINION BY ROUND (tracks how collective stance shifted):
{trend_str}

REPRESENTATIVE AGENT POSTS FROM SIMULATION:
{trace_str}

KNOWLEDGE GRAPH ENTITIES:
{graph_str}

Write a very detailed, thorough analytical prediction report with EXACTLY these five sections. Do not use brief summaries; write expansive, multi-paragraph analyses for each section.

## Prediction
State your direct, specific answer to the prediction question in a comprehensive opening analysis. Commit to a direction. Explore the nuances of why the simulation naturally gravitated toward this outcome.

## Evidence & Quantitative Dynamics
Cite specific metrics (entropy trajectory, polarization, velocity) and quote specific agent behaviors from the trace that support your prediction. Analyze the velocity of opinion changes and the fragmentation (entropy) of the crowd in extreme detail.

## Emergence Analysis & Turning Points
What complex collective dynamics emerged from the agent interactions? Did opinion shift, stabilize, or split into factions? Identify the precise turning points or dominant arguments that broke echo chambers or solidified consensus.

## Confidence Assessment
Score: [write a number 0-100]
Justify the score rigorously based on consensus strength, entropy stability, and how consistent the simulation results were across rounds. Discuss the margin of error.

## Limitations & Edge Cases
What real-world factors, irrational behaviors, or exogenous shocks are not captured by this simulation that could completely alter the prediction? Be hyper-critical of the simulation's boundaries."""


def _fallback_report(question: str, ctx: dict, error: str) -> str:
    """Minimal data-only report when the LLM call fails entirely."""
    metrics = ctx.get("metrics") or {}
    trend   = ctx.get("opinion_trend") or {}
    last_r  = max(trend.keys(), default="—") if trend else "—"
    dominant = trend.get(last_r, "unknown").replace("_", " ") if trend else "unknown"

    return f"""## Prediction
Based on raw simulation data, the dominant stance at the end of the simulation was **{dominant}**.
Full LLM analysis was unavailable (error: {error}).

## Evidence
Agents: {ctx.get('n_agents')} | Rounds: {ctx.get('n_rounds')} | Actions: {ctx.get('total_actions', 0)}
Final metrics: {json.dumps(metrics, indent=2)}

## Emergence Analysis
Opinion trend across rounds:
{json.dumps(trend, indent=2)}

## Confidence Assessment
Score: 20
Raw simulation data only — LLM-based analysis was not available.

## Limitations
The report was generated from raw data without LLM analysis due to an error.
Please retry the report generation or check your API key and server logs."""