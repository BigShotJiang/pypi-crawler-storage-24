"""Agent-facing MCP tools."""

import json
import logging
import secrets
from urllib.parse import parse_qs, urlparse

import httpx
from docket import Docket
from mcp.shared.exceptions import McpError

from docketeer.plugins import PluginUnavailable
from docketeer.tools import ToolContext, registry
from docketeer.vault import SecretEnvRef, SecretResolutionError, resolve_env

from . import config
from .manager import manager
from .oauth import (
    REDIRECT_URI,
    PendingOAuth,
    _generate_pkce,
    build_authorization_url,
    discover_oauth_metadata,
    exchange_code,
    register_client,
)

log = logging.getLogger(__name__)


async def _check_auth_required(url: str) -> bool:
    """Probe an HTTP MCP server to see if it returns 401."""
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(url, timeout=10)
            return resp.status_code == 401
    except httpx.HTTPError:
        return False


def current_docket() -> Docket:
    """Resolve the current Docket from dependencies."""
    from docketeer.dependencies import _docket_var

    return _docket_var.get()


@registry.tool(emoji=":electric_plug:")
async def list_mcp_servers(ctx: ToolContext) -> str:
    """List configured MCP servers and their connection status."""
    servers = config.load_servers()
    if not servers:
        return "No MCP servers configured."

    connected = manager.connected_servers()
    lines = []
    for name, cfg in servers.items():
        kind = cfg.command if cfg.is_stdio else cfg.url
        status = (
            f"connected ({connected[name]} tools)"
            if name in connected
            else "disconnected"
        )
        lines.append(f"- **{name}**: `{kind}` — {status}")
    return "\n".join(lines)


@registry.tool(emoji=":electric_plug:")
async def connect_mcp_server(
    ctx: ToolContext,
    name: str,
    client_id: str = "",
    client_secret: str = "",
    scopes: str = "",
) -> str:
    """Connect to a configured MCP server and discover its tools. Secret
    env vars and auth tokens are resolved from the vault automatically —
    you don't need to read or pass raw secret values. If the server
    requires OAuth, returns an authorization URL for the user.

    name: server name from the configuration
    client_id: pre-configured OAuth client ID (optional, skips registration)
    client_secret: pre-configured OAuth client secret (optional)
    scopes: OAuth scopes to request (optional)
    """
    if manager.is_connected(name):
        return f"Already connected to {name!r}."

    manager.set_search(ctx.search)
    servers = config.load_servers()
    cfg = servers.get(name)
    if not cfg:
        return f"No server configured with name {name!r}."

    # Resolve any secret env refs before connecting
    resolved_env: dict[str, str] | None = None
    has_secrets = any(isinstance(v, SecretEnvRef) for v in cfg.env.values())
    if cfg.env:
        if has_secrets and not ctx.vault:
            return f"Server {name!r} has secret env vars but no vault is configured."
        if has_secrets:
            try:
                resolved_env = await resolve_env(cfg.env, ctx.vault)
            except SecretResolutionError as e:
                return str(e)
        else:
            resolved_env = {k: str(v) for k, v in cfg.env.items()}

    # If config has an auth secret, resolve from vault and connect with bearer
    if cfg.auth:
        if not ctx.vault:
            return f"Server {name!r} requires auth but no vault is configured."
        try:
            token = await ctx.vault.resolve(cfg.auth)
        except (SecretResolutionError, PluginUnavailable) as e:
            return f"Failed to resolve auth secret {cfg.auth!r}: {e}"

        try:
            tools = await manager.connect(
                name,
                cfg,
                ctx.executor,
                ctx.workspace,
                auth=token,
                resolved_env=resolved_env,
            )
        except (ValueError, OSError, McpError) as e:
            log.warning("Failed to connect to MCP server %r", name, exc_info=True)
            return f"Failed to connect to {name!r}: {e}"

        if not tools:
            return f"Connected to {name!r} — no tools found."
        lines = [f"Connected to {name!r} — {len(tools)} tools:"]
        for t in tools:
            lines.append(f"- **{t.name}**: {t.description}")
        return "\n".join(lines)

    # For HTTP servers without auth config, check if auth is required
    if cfg.is_http:
        auth_required = await _check_auth_required(cfg.url)
        if auth_required:
            return await _start_oauth_flow(name, cfg, client_id, client_secret, scopes)

    # No auth needed — connect normally
    try:
        tools = await manager.connect(
            name,
            cfg,
            ctx.executor,
            ctx.workspace,
            resolved_env=resolved_env,
        )
    except (ValueError, OSError, McpError) as e:
        log.warning("Failed to connect to MCP server %r", name, exc_info=True)
        return f"Failed to connect to {name!r}: {e}"

    if not tools:
        return f"Connected to {name!r} — no tools found."

    lines = [f"Connected to {name!r} — {len(tools)} tools:"]
    for t in tools:
        lines.append(f"- **{t.name}**: {t.description}")
    return "\n".join(lines)


async def _start_oauth_flow(
    name: str,
    cfg: config.MCPServerConfig,
    client_id: str,
    client_secret: str,
    scopes: str,
) -> str:
    """Discover OAuth metadata, register if needed, store pending state."""
    try:
        auth_ep, token_ep, reg_ep, discovered_scopes = await discover_oauth_metadata(
            cfg.url
        )
    except (RuntimeError, httpx.HTTPError) as e:
        return f"OAuth discovery failed for {name!r}: {e}"

    effective_scopes = scopes or discovered_scopes or ""

    if not client_id:
        if reg_ep:
            try:
                client_id, client_secret = await register_client(
                    reg_ep, REDIRECT_URI, f"docketeer-{name}", effective_scopes
                )
            except (RuntimeError, httpx.HTTPError) as e:
                return f"Client registration failed for {name!r}: {e}"
        else:
            return (
                f"Server {name!r} requires OAuth but has no registration endpoint. "
                f"Provide client_id (and client_secret) when connecting."
            )

    verifier, challenge = _generate_pkce()
    state = secrets.token_urlsafe(32)

    pending = PendingOAuth(
        server_url=cfg.url,
        authorization_endpoint=auth_ep,
        token_endpoint=token_ep,
        code_verifier=verifier,
        code_challenge=challenge,
        state=state,
        redirect_uri=REDIRECT_URI,
        client_id=client_id,
        client_secret=client_secret,
        scopes=effective_scopes,
    )

    manager._pending_oauth[name] = pending
    auth_url = build_authorization_url(pending)

    return (
        f"Authorization needed for {name!r}.\n\n"
        f"Send this URL to the user:\n{auth_url}\n\n"
        f"After they authorize, use `mcp_oauth_complete` with the redirect URL."
    )


@registry.tool(emoji=":electric_plug:")
async def mcp_oauth_complete(
    ctx: ToolContext,
    server: str,
    redirect_url: str,
    token_secret: str,
) -> str:
    """Complete an OAuth flow by exchanging the authorization code for tokens.

    server: the MCP server name from the pending OAuth flow
    redirect_url: the full redirect URL the user was sent to (contains code and state)
    token_secret: vault secret path to store the access token (e.g. mcp/github/token)
    """
    if not ctx.vault:
        return "No vault configured — cannot store OAuth tokens."

    pending = manager._pending_oauth.get(server)
    if not pending:
        return f"No pending OAuth flow found for {server!r}."

    # Parse code and state from redirect URL
    parsed = urlparse(redirect_url)
    params = parse_qs(parsed.query)
    code = params.get("code", [""])[0]
    state = params.get("state", [""])[0]

    if not code:
        return "No authorization code found in the redirect URL."

    if not secrets.compare_digest(state, pending.state):
        return "State mismatch — the redirect URL doesn't match the pending flow."

    # Exchange code for tokens
    try:
        tokens = await exchange_code(pending, code)
    except (RuntimeError, httpx.HTTPError) as e:
        return f"Token exchange failed: {e}"

    access_token = str(tokens.get("access_token", ""))
    if not access_token:
        return "Token exchange succeeded but no access_token in response."

    # Store access token in vault
    await ctx.vault.store(token_secret, access_token)

    # Update server config with auth secret path
    servers = config.load_servers()
    cfg = servers.get(server)
    if cfg:
        cfg.auth = token_secret
        config.save_server(cfg)

    # Clean up pending state
    del manager._pending_oauth[server]

    # Handle refresh token if present
    refresh_token = str(tokens.get("refresh_token", ""))
    if refresh_token:
        await ctx.vault.store(f"{token_secret}/refresh", refresh_token)
        await ctx.vault.store(f"{token_secret}/client_id", pending.client_id)
        await ctx.vault.store(f"{token_secret}/client_secret", pending.client_secret)
        await ctx.vault.store(f"{token_secret}/token_endpoint", pending.token_endpoint)

        expires_in = int(str(tokens.get("expires_in", 3600)))
        try:
            await _schedule_token_refresh(
                token_secret,
                pending.token_endpoint,
                pending.client_id,
                pending.client_secret,
                expires_in,
            )
        except (RuntimeError, LookupError):
            log.warning("Could not schedule token refresh", exc_info=True)

    return f"OAuth complete for {server!r}. Token stored at {token_secret!r}."


async def _schedule_token_refresh(
    token_secret: str,
    token_endpoint: str,
    client_id: str,
    client_secret: str,
    expires_in: int,
) -> None:
    """Schedule a one-shot refresh task before the token expires."""
    from datetime import datetime, timedelta

    from .tasks import mcp_oauth_refresh

    docket = current_docket()
    fire_at = datetime.now().astimezone() + timedelta(seconds=max(expires_in - 300, 60))
    await docket.add(
        mcp_oauth_refresh, when=fire_at, key=f"mcp-refresh-{token_secret}"
    )(
        token_secret=token_secret,
        token_endpoint=token_endpoint,
        client_id=client_id,
        client_secret=client_secret,
        expires_in=expires_in,
    )


@registry.tool(emoji=":electric_plug:")
async def disconnect_mcp_server(ctx: ToolContext, name: str) -> str:
    """Disconnect from a connected MCP server.

    name: server name to disconnect
    """
    if not manager.is_connected(name):
        return f"Not connected to {name!r}."
    await manager.disconnect(name)
    return f"Disconnected from {name!r}."


@registry.tool(emoji=":electric_plug:")
async def search_mcp_tools(ctx: ToolContext, query: str, server: str = "") -> str:
    """Semantic search across MCP server tools. Searches all configured
    servers, including disconnected ones.

    query: natural language description of the capability you need
    server: optional server name to limit the search to
    """
    manager.set_search(ctx.search)
    await manager.reindex_from_cache()
    index = ctx.search.get_index("mcp-tools")
    results = await index.search(query, limit=20)
    if server:
        results = [r for r in results if r.path.startswith(f"{server}/")]
    if not results:
        return f"No tools matching {query!r}."

    connected = manager.connected_servers()
    hits = results[:10]
    lines: list[str] = []
    for r in hits:
        srv, tool_name = r.path.split("/", 1)
        status = "connected" if srv in connected else "disconnected"
        lines.append(f"  {srv}/{tool_name} ({status}, score: {r.score:.3f})")
        snippet = r.snippet.replace("\n", " ")[:120]
        lines.append(f"    {snippet}")
    return f"{len(hits)} result(s):\n" + "\n".join(lines)


@registry.tool(emoji=":electric_plug:")
async def use_mcp_tool(
    ctx: ToolContext, server: str, tool: str, arguments: dict | str | None = None
) -> str:
    """Call a tool on a connected MCP server.

    server: server name
    tool: tool name on that server
    arguments: tool arguments as a dict
    """
    if isinstance(arguments, str):
        try:
            arguments = json.loads(arguments)
        except json.JSONDecodeError:
            return f"Error calling {server}/{tool}: invalid JSON in arguments"
    try:
        return await manager.call_tool(server, tool, arguments or {})
    except (ValueError, OSError, McpError) as e:
        return f"Error calling {server}/{tool}: {e}"


@registry.tool(emoji=":electric_plug:")
async def add_mcp_server(
    ctx: ToolContext,
    name: str,
    command: str = "",
    args: list[str] | None = None,
    env: dict[str, str | dict[str, str]] | None = None,
    url: str = "",
    headers: dict[str, str] | None = None,
    network_access: bool = False,
) -> str:
    """Save a new MCP server configuration. Environment variables can
    reference vault secrets, which are resolved automatically at connect
    time — you never need to read or handle the raw secret values yourself.

    Workflow: use list_secrets to find available credentials, then pass
    them as {"secret": "vault/path"} in env. For bearer-token auth, set
    the auth field on the server config (done automatically by OAuth, or
    manually via store_secret + config update).

    name: identifier for the server
    command: executable to run (for stdio servers)
    args: command arguments
    env: environment variables — values are either plain strings or
        {"secret": "vault/path"} objects for vault-backed secrets. Example:
        {"TZ": "UTC", "API_KEY": {"secret": "mcp/my-server/api-key"}}
    url: server URL (for HTTP servers)
    headers: HTTP headers
    network_access: whether the server needs network access (stdio only)
    """
    if not command and not url:
        return "Must provide either command (stdio) or url (HTTP)."

    env_dict = config._parse_env(env or {})

    cfg = config.MCPServerConfig(
        name=name,
        command=command,
        args=args or [],
        env=env_dict,
        url=url,
        headers=headers or {},
        network_access=network_access,
    )
    try:
        config.save_server(cfg)
    except ValueError as e:
        return str(e)

    kind = f"command `{command}`" if command else f"url `{url}`"
    return f"Saved server {name!r} ({kind})."


@registry.tool(emoji=":electric_plug:")
async def remove_mcp_server(ctx: ToolContext, name: str) -> str:
    """Remove an MCP server configuration.

    name: server name to remove
    """
    if manager.is_connected(name):
        await manager.disconnect(name)

    servers = config.load_servers()
    cfg = servers.get(name)
    if cfg and cfg.auth:
        try:
            docket = current_docket()
            await docket.cancel(f"mcp-refresh-{cfg.auth}")
        except Exception:
            log.debug("Could not cancel refresh task for %s", name, exc_info=True)

    await manager.deindex_server(name)
    config.remove_tool_catalog(name)

    if config.remove_server(name):
        return f"Removed server {name!r}."
    return f"No server configured with name {name!r}."
