"""Diagnostics fuzzing tests.

Property-based tests for error message generation:
- All error codes produce non-empty messages
- Template placeholders are substituted correctly
- No crashes on edge cases

Note: This file is marked with pytest.mark.fuzz and is excluded from normal
test runs. Run via: ./scripts/fuzz.sh or pytest -m fuzz
"""

from __future__ import annotations

import pytest
from hypothesis import event, given, settings
from hypothesis import strategies as st

from ftllexengine.diagnostics import (
    Diagnostic,
    DiagnosticCode,
    DiagnosticFormatter,
    ErrorCategory,
    ErrorTemplate,
    FrozenErrorContext,
    FrozenFluentError,
    SourceSpan,
    ValidationError,
    ValidationResult,
    ValidationWarning,
)
from ftllexengine.runtime.bundle import FluentBundle
from tests.strategies import (
    diagnostics as gen_diagnostics,
)
from tests.strategies import (
    frozen_error_contexts,
    frozen_fluent_errors,
    source_spans,
    validation_errors,
    validation_results,
    validation_warnings,
)

# Mark all tests in this file as fuzzing tests
pytestmark = pytest.mark.fuzz


# -----------------------------------------------------------------------------
# Property Tests: Error Code Coverage
# -----------------------------------------------------------------------------


class TestErrorCodeProperties:
    """Property tests for error code handling."""

    def test_all_error_codes_exist(self) -> None:
        """All DiagnosticCode values are defined."""
        codes = list(DiagnosticCode)
        assert len(codes) > 0
        for code in codes:
            assert isinstance(code.value, int)
            assert isinstance(code.name, str)

    @given(st.sampled_from(list(DiagnosticCode)))
    @settings(deadline=None)
    def test_diagnostic_creation(self, code: DiagnosticCode) -> None:
        """Property: Diagnostics can be created for any code."""
        diagnostic = Diagnostic(
            code=code,
            message="Test message",
            severity="error",
        )

        event(f"diagnostic_code={code.name}")
        assert diagnostic.code == code
        assert diagnostic.message == "Test message"
        assert diagnostic.severity in ("error", "warning")
        event("outcome=diagnostic_created")


# -----------------------------------------------------------------------------
# Property Tests: Error Message Formatting
# -----------------------------------------------------------------------------


class TestErrorMessageProperties:
    """Property tests for error message formatting."""

    @given(st.text(min_size=1, max_size=100))
    @settings(deadline=None)
    def test_reference_error_formatting(self, msg: str) -> None:
        """Property: Reference errors format properly."""
        error = FrozenFluentError(msg, ErrorCategory.REFERENCE)

        event(f"error_category={error.category.name}")
        error_str = str(error)
        assert isinstance(error_str, str)
        assert len(error_str) > 0
        event("outcome=error_formatted")

    @given(st.lists(st.text(min_size=1, max_size=20), min_size=2, max_size=10))
    @settings(deadline=None)
    def test_cyclic_error_formatting(self, path: list[str]) -> None:
        """Property: Cyclic errors format with full path."""
        # Create a Diagnostic using the ErrorTemplate
        diagnostic = ErrorTemplate.cyclic_reference(path)
        error = FrozenFluentError(
            diagnostic.message, ErrorCategory.CYCLIC, diagnostic=diagnostic
        )

        event(f"error_category={error.category.name}")
        event(f"path_length={len(path)}")

        error_str = str(error)
        assert isinstance(error_str, str)
        # Should mention cycle
        assert "cycle" in error_str.lower() or "circular" in error_str.lower()
        event("outcome=cycle_error_formatted")

    @given(st.text(min_size=1, max_size=100))
    @settings(deadline=None)
    def test_resolution_error_formatting(self, detail: str) -> None:
        """Property: Resolution errors format properly."""
        error = FrozenFluentError(detail, ErrorCategory.RESOLUTION)

        error_str = str(error)
        assert isinstance(error_str, str)
        event(f"error_category={error.category.name}")
        event(f"detail_len={len(detail)}")


# -----------------------------------------------------------------------------
# Property Tests: ErrorTemplate Methods
# -----------------------------------------------------------------------------


class TestErrorTemplateProperties:
    """Property tests for ErrorTemplate factory methods."""

    @given(st.text(alphabet="abcdefghijklmnopqrstuvwxyz", min_size=1, max_size=50))
    @settings(deadline=None)
    def test_message_not_found_template(self, msg_id: str) -> None:
        """Property: message_not_found creates valid Diagnostic."""
        diagnostic = ErrorTemplate.message_not_found(msg_id)

        event("template=message_not_found")
        assert isinstance(diagnostic, Diagnostic)
        assert diagnostic.code == DiagnosticCode.MESSAGE_NOT_FOUND
        assert msg_id in diagnostic.message
        event("outcome=template_created")

    @given(st.text(alphabet="abcdefghijklmnopqrstuvwxyz", min_size=1, max_size=20))
    @settings(deadline=None)
    def test_term_not_found_template(self, term_id: str) -> None:
        """Property: term_not_found creates valid Diagnostic."""
        diagnostic = ErrorTemplate.term_not_found(term_id)

        assert isinstance(diagnostic, Diagnostic)
        assert diagnostic.code == DiagnosticCode.TERM_NOT_FOUND
        assert term_id in diagnostic.message
        event("template=term_not_found")

    @given(st.text(alphabet="abcdefghijklmnopqrstuvwxyz", min_size=1, max_size=20))
    @settings(deadline=None)
    def test_variable_not_provided_template(self, var_name: str) -> None:
        """Property: variable_not_provided creates valid Diagnostic."""
        diagnostic = ErrorTemplate.variable_not_provided(var_name)

        assert isinstance(diagnostic, Diagnostic)
        assert diagnostic.code == DiagnosticCode.VARIABLE_NOT_PROVIDED
        assert var_name in diagnostic.message
        event("template=variable_not_provided")


# -----------------------------------------------------------------------------
# Property Tests: Diagnostic Integration
# -----------------------------------------------------------------------------


class TestDiagnosticIntegration:
    """Property tests for diagnostic integration with bundle."""

    @given(st.text(alphabet="abcdefghijklmnopqrstuvwxyz", min_size=1, max_size=20))
    @settings(deadline=None)
    def test_missing_message_diagnostic(self, msg_id: str) -> None:
        """Property: Missing messages produce diagnostics.

        strict=False: tests the soft-error return contract — errors are
        returned in the tuple, not raised as FormattingIntegrityError.
        """
        bundle = FluentBundle("en-US", strict=False)
        bundle.add_resource("other = value")

        _, errors = bundle.format_pattern(msg_id)

        # For missing messages, should have errors
        if msg_id != "other":
            assert len(errors) > 0
            # Each error should be a proper error object
            for error in errors:
                assert isinstance(error, FrozenFluentError)
            event("outcome=missing_msg_error")
        else:
            event("outcome=msg_found")

    @given(st.text(alphabet="abcdefghijklmnopqrstuvwxyz", min_size=1, max_size=20))
    @settings(deadline=None)
    def test_missing_variable_diagnostic(self, var_name: str) -> None:
        """Property: Missing variables produce diagnostics.

        strict=False: tests the soft-error return contract — missing variable
        errors are returned in the tuple, not raised as FormattingIntegrityError.
        """
        bundle = FluentBundle("en-US", strict=False)
        bundle.add_resource(f"msg = Hello {{ ${var_name} }}")

        result, errors = bundle.format_pattern("msg", {})

        # Should have error for missing variable
        assert isinstance(result, str)
        event(f"error_count={len(errors)}")
        if errors:
            event("outcome=missing_var_diagnostic")
        else:
            event("outcome=missing_var_no_diagnostic")

    def test_syntax_error_diagnostic(self) -> None:
        """Syntax errors in resource produce diagnostics.

        strict=False: add_resource with syntax errors returns junk silently;
        strict=True raises SyntaxIntegrityError, testing a different contract.
        """
        bundle = FluentBundle("en-US", strict=False)

        # This should produce parse errors (junk)
        bundle.add_resource("!invalid = syntax here")

        # Valid message should still work
        bundle.add_resource("valid = This works")
        result, _ = bundle.format_pattern("valid")

        assert result == "This works"

    def test_cycle_error_diagnostic(self) -> None:
        """Cyclic references produce diagnostics.

        strict=False: cycle errors are returned in the tuple, not raised.
        """
        bundle = FluentBundle("en-US", strict=False)
        bundle.add_resource(
            """
a = { b }
b = { a }
"""
        )

        _, errors = bundle.format_pattern("a")

        assert len(errors) > 0
        # Should have cyclic reference error
        assert any(
            isinstance(e, FrozenFluentError) and e.category == ErrorCategory.CYCLIC
            for e in errors
        )


class TestDiagnosticFormatter:
    """Property tests for diagnostic formatter."""

    @given(st.sampled_from(list(DiagnosticCode)))
    @settings(deadline=None)
    def test_formatter_handles_all_codes(self, code: DiagnosticCode) -> None:
        """Property: Formatter handles all diagnostic codes."""
        diagnostic = Diagnostic(
            code=code,
            message="Test message",
            severity="error",
        )

        formatter = DiagnosticFormatter()
        formatted = formatter.format(diagnostic)

        event(f"code={code.name}")
        assert isinstance(formatted, str)
        assert len(formatted) > 0
        event("outcome=diagnostic_formatted")

    @given(st.sampled_from(["error", "warning"]))
    @settings(deadline=None)
    def test_formatter_severity_levels(self, severity: str) -> None:
        """Property: Formatter handles all severity levels."""
        diagnostic = Diagnostic(
            code=DiagnosticCode.MESSAGE_NOT_FOUND,
            message="Test",
            severity=severity,  # type: ignore[arg-type]
        )

        formatter = DiagnosticFormatter()
        formatted = formatter.format(diagnostic)

        assert isinstance(formatted, str)
        event(f"severity={severity}")


# -----------------------------------------------------------------------------
# Edge Case Tests
# -----------------------------------------------------------------------------


class TestDiagnosticEdgeCases:
    """Tests for diagnostic edge cases."""

    def test_empty_message_id(self) -> None:
        """Empty message ID handling.

        strict=False: invalid-ID errors are returned in the tuple, not raised.
        """
        bundle = FluentBundle("en-US", strict=False)
        bundle.add_resource("msg = value")

        # Empty string as message ID
        result, errors = bundle.format_pattern("")

        assert isinstance(result, str)
        assert len(errors) > 0

    def test_unicode_in_error_message(self) -> None:
        """Unicode characters in error context.

        strict=False: missing-message error returned in tuple, not raised.
        """
        bundle = FluentBundle("en-US", strict=False)
        bundle.add_resource("msg = value")

        # Unicode message ID
        result, _ = bundle.format_pattern("nonexistent")

        assert isinstance(result, str)

    @given(st.text(min_size=1, max_size=200))
    @settings(deadline=None)
    def test_long_message_in_diagnostic(self, long_text: str) -> None:
        """Property: Long text in diagnostics doesn't crash."""
        error = FrozenFluentError(long_text, ErrorCategory.REFERENCE)
        error_str = str(error)
        assert isinstance(error_str, str)
        event(f"text_len={len(long_text)}")

    def test_special_characters_in_error(self) -> None:
        """Special characters in error messages."""
        special_chars = ["<script>", "${cmd}", "\x00", "\n\r\t", "\\", '"']

        for char in special_chars:
            error = FrozenFluentError(f"test{char}id", ErrorCategory.REFERENCE)
            error_str = str(error)
            assert isinstance(error_str, str)


# -----------------------------------------------------------------------------
# Strategy-Driven Property Tests (for HypoFuzz event coverage)
# -----------------------------------------------------------------------------


class TestDiagnosticStrategyProperties:
    """Property tests using diagnostics strategies for HypoFuzz coverage.

    Each test exercises one strategy function to ensure its events fire
    during --deep --metrics runs: diag_span_size, diag_ctx_fields,
    diag_severity, diag_has_span, diag_verr_location, diag_vwarn_severity,
    diag_vresult_valid, diag_frozen_error_variant, diag_error_cat.
    """

    @given(span=source_spans())
    @settings(deadline=None)
    def test_source_span_invariants(self, span: SourceSpan) -> None:
        """Property: source_spans() produces structurally valid SourceSpan."""
        event(f"outcome=span_range={span.end - span.start}")
        assert span.start >= 0
        assert span.end >= span.start
        assert span.line >= 1
        assert span.column >= 1

    @given(ctx=frozen_error_contexts())
    @settings(deadline=None)
    def test_frozen_error_context_invariants(
        self, ctx: FrozenErrorContext
    ) -> None:
        """Property: frozen_error_contexts() produces valid FrozenErrorContext."""
        event(f"outcome=has_locale={bool(ctx.locale_code)}")
        assert isinstance(ctx.input_value, str)
        assert isinstance(ctx.locale_code, str)
        assert isinstance(ctx.fallback_value, str)

    @given(diag=gen_diagnostics())
    @settings(deadline=None)
    def test_diagnostic_invariants(self, diag: Diagnostic) -> None:
        """Property: diagnostics() produces valid Diagnostic objects."""
        event(f"outcome=has_span={diag.span is not None}")
        assert isinstance(diag.message, str)
        assert diag.severity in ("error", "warning")
        assert isinstance(diag.code, DiagnosticCode)

    @given(verr=validation_errors())
    @settings(deadline=None)
    def test_validation_error_invariants(self, verr: ValidationError) -> None:
        """Property: validation_errors() produces valid ValidationError objects."""
        has_loc = verr.line is not None
        event(f"outcome=has_location={has_loc}")
        assert isinstance(verr.message, str)
        assert isinstance(verr.code, DiagnosticCode)

    @given(vwarn=validation_warnings())
    @settings(deadline=None)
    def test_validation_warning_invariants(
        self, vwarn: ValidationWarning
    ) -> None:
        """Property: validation_warnings() produces valid ValidationWarning objects."""
        event(f"outcome=severity={vwarn.severity.value}")
        assert isinstance(vwarn.message, str)
        assert isinstance(vwarn.code, DiagnosticCode)

    @given(vresult=validation_results())
    @settings(deadline=None)
    def test_validation_result_invariants(
        self, vresult: ValidationResult
    ) -> None:
        """Property: validation_results() produces valid ValidationResult objects."""
        event(f"outcome=is_valid={vresult.is_valid}")
        assert isinstance(vresult.errors, tuple)
        assert isinstance(vresult.warnings, tuple)
        if vresult.is_valid:
            assert len(vresult.errors) == 0

    @given(err=frozen_fluent_errors())
    @settings(deadline=None)
    def test_frozen_fluent_error_invariants(
        self, err: FrozenFluentError
    ) -> None:
        """Property: frozen_fluent_errors() produces valid FrozenFluentError."""
        event(f"outcome=has_diagnostic={err.diagnostic is not None}")
        assert isinstance(str(err), str)
        assert len(str(err)) > 0
        assert isinstance(err.category, ErrorCategory)
