"""Fluent built-in functions with Python-native APIs.

Implements NUMBER, DATETIME, and CURRENCY functions with locale-aware formatting.
Uses snake_case parameters (PEP 8) with FTL camelCase bridge.

Architecture:
    - Python functions use snake_case (PEP 8 compliant)
    - FunctionRegistry bridges to FTL camelCase
    - FTL files still use camelCase syntax
    - No N802/N803 violations!
    - Locale-aware via LocaleContext (thread-safe, CLDR-based)

Canonical import path: ``from ftllexengine.runtime import number_format, currency_format``
(and similar). All public functions are re-exported from ``ftllexengine.runtime.__all__``.
Importing from this private submodule (``ftllexengine.runtime.functions``) is unsupported
and may break without notice.

Example:
    # Python API (snake_case):
    number_format(Decimal('1234.5'), "en-US", minimum_fraction_digits=2)

    # FTL file (camelCase):
    price = { $amount NUMBER(minimumFractionDigits: 2) }

    # Bridge handles the conversion automatically!

Python 3.13+. Uses Babel for i18n.
"""

from __future__ import annotations

import functools
import logging
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from datetime import date, datetime
    from decimal import Decimal

from ftllexengine.core.babel_compat import get_babel_numbers
from ftllexengine.core.value_types import (
    FluentNumber,
    _make_fluent_number,
)

from .function_bridge import _FTL_REQUIRES_LOCALE_ATTR, FunctionRegistry
from .locale_context import LocaleContext

__all__ = ["create_default_registry", "get_shared_registry"]

logger = logging.getLogger(__name__)


def number_format(
    value: int | Decimal,
    locale_code: str = "en-US",
    *,
    minimum_fraction_digits: int = 0,
    maximum_fraction_digits: int = 3,
    use_grouping: bool = True,
    pattern: str | None = None,
    numbering_system: str = "latn",
) -> FluentNumber:
    """Format number with locale-specific separators.

    Python-native API with snake_case parameters. FunctionRegistry bridges
    to FTL camelCase (minimumFractionDigits → minimum_fraction_digits).

    Args:
        value: Number to format (int or Decimal). float is not accepted;
            use Decimal(str(float_val)) to convert at system boundaries.
        locale_code: BCP 47 locale identifier (e.g., 'en-US', 'de-DE')
        minimum_fraction_digits: Minimum decimal places (default: 0)
        maximum_fraction_digits: Maximum decimal places (default: 3)
        use_grouping: Use thousands separator (default: True)
        pattern: Custom number pattern (overrides CLDR defaults)
            Examples:
            - "#,##0.00": Always show 2 decimals
            - "#,##0.00;(#,##0.00)": Negatives in parentheses (accounting)
            - "0.000": Scientific notation with 3 decimals
        numbering_system: CLDR numbering system identifier (default: "latn").
            Controls which numeral glyphs are used in the output.
            Examples: "latn" (0-9), "arab" (Arabic-Indic), "deva" (Devanagari).
            FTL: NUMBER($n, numberingSystem: "arab")

    Returns:
        FluentNumber with formatted string and computed precision for plural matching

    Examples:
        >>> from decimal import Decimal
        >>> number_format(Decimal('1234.5'), "en-US")
        FluentNumber(value=Decimal('1234.5'), formatted='1,234.5', precision=1)
        >>> number_format(Decimal('1234.5'), "de-DE")
        FluentNumber(value=Decimal('1234.5'), formatted='1.234,5', precision=1)
        >>> number_format(Decimal('1234.5'), "lv-LV")
        FluentNumber(value=Decimal('1234.5'), formatted='1 234,5', precision=1)
        >>> number_format(42, "en-US", minimum_fraction_digits=2)
        FluentNumber(value=42, formatted='42.00', precision=2)
        >>> number_format(Decimal('-1234.56'), "en-US", pattern="#,##0.00;(#,##0.00)")
        FluentNumber(value=Decimal('-1234.56'), formatted='(1,234.56)', precision=2)

    FTL Usage:
        price = { $amount NUMBER(minimumFractionDigits: 2) }
        accounting = { $amount NUMBER(pattern: "#,##0.00;(#,##0.00)") }

    Thread Safety:
        Thread-safe. Uses Babel (no global locale state mutation).

    CLDR Compliance:
        Implements CLDR formatting rules via Babel.
        Matches Intl.NumberFormat semantics.
        Custom patterns follow Babel number pattern syntax.

    Precision Calculation:
        The precision (CLDR v operand) is computed from the ACTUAL formatted
        string, not from the minimum_fraction_digits parameter. This ensures
        correct plural category matching:
        - number_format(Decimal('1.2'), min=0, max=3) -> "1.2" with precision=1 (not 0)
        - number_format(Decimal('1.0'), min=0, max=3) -> "1" with precision=0
        - number_format(1, min=2, max=2) -> "1.00" with precision=2
    """
    babel_numbers = get_babel_numbers()
    get_decimal_symbol = babel_numbers.get_decimal_symbol
    parse_pattern = babel_numbers.parse_pattern

    # Delegate to LocaleContext (immutable, thread-safe)
    # create() always returns LocaleContext with en_US fallback for invalid locales
    ctx = LocaleContext.create(locale_code)
    formatted = ctx.format_number(
        value,
        minimum_fraction_digits=minimum_fraction_digits,
        maximum_fraction_digits=maximum_fraction_digits,
        use_grouping=use_grouping,
        pattern=pattern,
        numbering_system=numbering_system,
    )

    # Compute actual visible precision from formatted string (CLDR v operand).
    # Use the decimal symbol for the active numbering system so precision counting
    # is correct for non-Latin numeral systems (e.g., "arab" uses U+066B not ASCII dot).
    decimal_symbol = get_decimal_symbol(ctx.babel_locale, numbering_system=numbering_system)

    # When a custom pattern is provided, extract max fraction digits from pattern
    # metadata to cap precision. This prevents literal digit suffixes (ICU
    # single-quote syntax like "0.0'5'") from inflating the v operand.
    max_frac: int | None = None
    if pattern is not None:
        try:
            parsed = parse_pattern(pattern)
            # frac_prec is (min_frac, max_frac) tuple
            max_frac = parsed.frac_prec[1]
        except (ValueError, AttributeError):
            # Malformed pattern: fall back to uncapped counting.
            # Babel format_number already handled the pattern successfully,
            # so parse_pattern failure is unexpected but not fatal.
            # Logged at WARNING: the formatted output is correct, but the
            # CLDR v operand (plural precision) may be inflated when the
            # pattern uses ICU single-quote literals (e.g., "0.0'5'").
            # Financial applications should inspect this warning.
            logger.warning(
                "parse_pattern failed for NUMBER pattern %r; "
                "precision capping disabled — CLDR v operand may be inflated",
                pattern,
            )

    return _make_fluent_number(
        value,
        formatted=formatted,
        decimal_symbol=decimal_symbol,
        max_fraction_digits=max_frac,
    )


def datetime_format(
    value: date | datetime | str,
    locale_code: str = "en-US",
    *,
    date_style: Literal["short", "medium", "long", "full"] = "medium",
    time_style: Literal["short", "medium", "long", "full"] | None = None,
    pattern: str | None = None,
) -> str:
    """Format date or datetime with locale-specific formatting.

    Python-native API with snake_case parameters. FunctionRegistry bridges
    to FTL camelCase (dateStyle → date_style, timeStyle → time_style).

    Args:
        value: date, datetime, or ISO 8601 string. Plain date objects are
            accepted; when time_style or pattern is also requested, the date
            is promoted to midnight datetime (00:00:00, no tzinfo).
        locale_code: BCP 47 locale identifier (e.g., 'en-US', 'de-DE')
        date_style: Date format style (default: "medium")
        time_style: Time format style (default: None - date only)
        pattern: Custom datetime pattern (overrides CLDR defaults)
            Examples:
            - "yyyy-MM-dd": ISO 8601 date (2025-01-28)
            - "HH:mm:ss": 24-hour time (14:30:00)
            - "MMM d, yyyy": Short month name (Jan 28, 2025)
            - "EEEE, MMMM d, yyyy": Full format (Monday, January 28, 2025)

    Returns:
        Formatted date/datetime string

    Examples:
        >>> from datetime import date, datetime, UTC
        >>> dt = datetime(2025, 10, 27, tzinfo=UTC)
        >>> datetime_format(dt, "en-US", date_style="short")
        '10/27/25'
        >>> datetime_format(dt, "de-DE", date_style="short")
        '27.10.25'
        >>> dt_with_time = datetime(2025, 10, 27, 14, 30, tzinfo=UTC)
        >>> datetime_format(dt_with_time, "en-US", date_style="medium", time_style="short")
        'Oct 27, 2025, 2:30 PM'
        >>> datetime_format(dt, "en-US", pattern="yyyy-MM-dd")
        '2025-10-27'
        >>> datetime_format(date(2025, 10, 27), "en-US", date_style="short")
        '10/27/25'

    FTL Usage:
        today = { $date DATETIME(dateStyle: "short") }
        timestamp = { $time DATETIME(dateStyle: "medium", timeStyle: "short") }
        iso-date = { $date DATETIME(pattern: "yyyy-MM-dd") }

    Thread Safety:
        Thread-safe. Uses Babel (no global locale state mutation).

    CLDR Compliance:
        Implements CLDR formatting rules via Babel.
        Matches Intl.DateTimeFormat semantics.
        Custom patterns follow Babel datetime pattern syntax.
    """
    # Delegate to LocaleContext (immutable, thread-safe)
    # create() always returns LocaleContext with en_US fallback for invalid locales
    ctx = LocaleContext.create(locale_code)
    return ctx.format_datetime(
        value,
        date_style=date_style,
        time_style=time_style,
        pattern=pattern,
    )


def currency_format(
    value: int | Decimal,
    locale_code: str = "en-US",
    *,
    currency: str,
    currency_display: Literal["symbol", "code", "name"] = "symbol",
    pattern: str | None = None,
    use_grouping: bool = True,
    currency_digits: bool = True,
    numbering_system: str = "latn",
) -> FluentNumber:
    """Format currency with locale-specific formatting.

    Python-native API with snake_case parameters. FunctionRegistry bridges
    to FTL camelCase (currencyDisplay → currency_display).

    Args:
        value: Monetary amount (int or Decimal). float is not accepted;
            use Decimal(str(float_val)) to convert at system boundaries.
        locale_code: BCP 47 locale identifier (e.g., 'en-US', 'de-DE')
        currency: ISO 4217 currency code (EUR, USD, JPY, BHD, etc.)
        currency_display: Display style (default: "symbol")
            - "symbol": Use currency symbol
            - "code": Use currency code (EUR, USD, JPY)
            - "name": Use currency name (euros, dollars, yen)
        pattern: Custom currency pattern (overrides currency_display).
            CLDR currency pattern placeholders per Babel/CLDR spec.
        use_grouping: Use thousands separator (default: True).
            FTL: CURRENCY($n, currency: "USD", useGrouping: false)
        currency_digits: Use ISO 4217 decimal places for the currency
            (default: True). When False, no automatic decimal place adjustment
            is applied. Has no effect when ``pattern`` is provided.
            FTL: CURRENCY($n, currency: "JPY", currencyDigits: false)
        numbering_system: CLDR numbering system identifier (default: "latn").
            Controls which numeral glyphs are used in the output.
            Examples: "latn" (0-9), "arab" (Arabic-Indic), "deva" (Devanagari).
            FTL: CURRENCY($n, currency: "USD", numberingSystem: "arab")

    Returns:
        FluentNumber with formatted currency string and computed precision.
        Returning FluentNumber enables CURRENCY results to be used as selectors
        in plural/select expressions, matching NUMBER() behavior.

    Examples:
        >>> from decimal import Decimal
        >>> currency_format(Decimal('123.45'), "en-US", currency="EUR")
        FluentNumber(value=Decimal('123.45'), formatted='€123.45', precision=2)
        >>> currency_format(Decimal('123.45'), "lv-LV", currency="EUR")
        FluentNumber(value=Decimal('123.45'), formatted='123,45 €', precision=2)
        >>> currency_format(12345, "ja-JP", currency="JPY")
        FluentNumber(value=12345, formatted='¥12,345', precision=0)
        >>> currency_format(Decimal('123.456'), "ar-BH", currency="BHD")
        FluentNumber(value=Decimal('123.456'), formatted='123.456 د.ب.', precision=3)

    FTL Usage:
        price = { CURRENCY($amount, currency: "EUR") }
        price-code = { CURRENCY($amount, currency: $code, currencyDisplay: "code") }
        price-name = { CURRENCY($amount, currency: "EUR", currencyDisplay: "name") }

        # CURRENCY can now be used as a selector (returns FluentNumber):
        items = { CURRENCY($count, currency: "USD") ->
            [one] One dollar item
           *[other] Multiple dollar items
        }

    Thread Safety:
        Thread-safe. Uses Babel (no global locale state mutation).

    CLDR Compliance:
        Implements CLDR formatting rules via Babel.
        Matches Intl.NumberFormat with style: 'currency'.
        Automatically applies currency-specific decimal places:
        - JPY, KRW: 0 decimals
        - BHD, KWD, OMR: 3 decimals
        - Most others: 2 decimals

    Precision Calculation:
        The precision (CLDR v operand) is computed from the ACTUAL formatted
        string, not from ISO 4217 defaults. This ensures correct plural category
        matching for custom patterns or locales that deviate from standard
        decimal places.
    """
    babel_numbers = get_babel_numbers()
    get_decimal_symbol = babel_numbers.get_decimal_symbol
    parse_pattern = babel_numbers.parse_pattern

    # Delegate to LocaleContext (immutable, thread-safe)
    # create() always returns LocaleContext with en_US fallback for invalid locales
    ctx = LocaleContext.create(locale_code)
    formatted = ctx.format_currency(
        value,
        currency=currency,
        currency_display=currency_display,
        pattern=pattern,
        use_grouping=use_grouping,
        currency_digits=currency_digits,
        numbering_system=numbering_system,
    )

    # Compute actual visible precision from formatted string (CLDR v operand).
    # Use the decimal symbol for the active numbering system so precision counting
    # is correct for non-Latin numeral systems (e.g., "arab" uses U+066B not ASCII dot).
    decimal_symbol = get_decimal_symbol(ctx.babel_locale, numbering_system=numbering_system)

    # When a custom pattern is provided, extract max fraction digits from pattern
    # metadata to cap precision. Same rationale as number_format().
    max_frac: int | None = None
    if pattern is not None:
        try:
            parsed = parse_pattern(pattern)
            max_frac = parsed.frac_prec[1]
        except (ValueError, AttributeError):
            # Logged at WARNING: same rationale as number_format — the
            # formatted output is correct but the CLDR v operand may be
            # inflated for patterns with ICU single-quote literals.
            # Financial applications should inspect this warning.
            logger.warning(
                "parse_pattern failed for CURRENCY pattern %r; "
                "precision capping disabled — CLDR v operand may be inflated",
                pattern,
            )

    return _make_fluent_number(
        value,
        formatted=formatted,
        decimal_symbol=decimal_symbol,
        max_fraction_digits=max_frac,
    )


# Mark built-in functions that require locale injection.
# This attribute is checked by FunctionRegistry.should_inject_locale() to determine
# whether to append the bundle's locale to the function call arguments.
# The constant _FTL_REQUIRES_LOCALE_ATTR is imported from function_bridge.py
# to ensure a single source of truth.


def _mark_locale_required(func: object) -> None:
    """Mark a function as requiring locale injection.

    Args:
        func: Function to mark with _ftl_requires_locale = True
    """
    setattr(func, _FTL_REQUIRES_LOCALE_ATTR, True)


def is_builtin_with_locale_requirement(func: object) -> bool:
    """Check if a callable is a built-in function requiring locale injection.

    This is the canonical way to check locale injection requirements,
    avoiding circular imports by using function attributes instead of
    comparing callable identity.

    Args:
        func: Callable to check

    Returns:
        True if func has _ftl_requires_locale = True, False otherwise
    """
    return getattr(func, _FTL_REQUIRES_LOCALE_ATTR, False) is True


# Mark built-in functions at module load time
_mark_locale_required(number_format)
_mark_locale_required(datetime_format)
_mark_locale_required(currency_format)


def create_default_registry() -> FunctionRegistry:
    """Create a new FunctionRegistry with built-in FTL functions registered.

    Returns a fresh, isolated registry instance containing the standard Fluent
    functions (NUMBER, DATETIME, CURRENCY). Each call returns a new instance,
    ensuring no shared mutable state between different FluentBundle instances.

    Returns:
        FunctionRegistry with NUMBER, DATETIME, and CURRENCY functions registered.

    Example:
        >>> registry = create_default_registry()
        >>> "NUMBER" in registry
        True
        >>> "DATETIME" in registry
        True
        >>> "CURRENCY" in registry
        True

    Use Case:
        FluentBundle uses this internally to create isolated function registries.
        Users who need custom registries can call this and then modify the result:

        >>> registry = create_default_registry()
        >>> registry.register(my_custom_func, ftl_name="CUSTOM")
        >>> bundle = FluentBundle("en", functions=registry)

    See Also:
        get_shared_registry: Returns a shared cached registry for performance.
    """
    registry = FunctionRegistry()

    # Register NUMBER function with camelCase parameter mapping
    registry.register(number_format, ftl_name="NUMBER")

    # Register DATETIME function with camelCase parameter mapping
    registry.register(datetime_format, ftl_name="DATETIME")

    # Register CURRENCY function with camelCase parameter mapping
    registry.register(currency_format, ftl_name="CURRENCY")

    return registry


@functools.lru_cache(maxsize=1)
def _create_shared_registry() -> FunctionRegistry:
    """Thread-safe singleton factory for shared registry.

    Uses lru_cache to ensure thread-safe initialization. The cache guarantees
    that only one registry is ever created, even under concurrent access.
    """
    registry = create_default_registry()
    registry.freeze()  # Protect from accidental modification
    return registry


def get_shared_registry() -> FunctionRegistry:
    """Get a shared, frozen FunctionRegistry with built-in functions.

    Returns a module-level cached registry instance that can be shared across
    multiple FluentBundle instances. This avoids the overhead of creating and
    registering functions for each bundle.

    Immutability:
        The returned registry is FROZEN. Calling register() on it will raise
        TypeError. This prevents accidental pollution of the shared singleton.
        To add custom functions, use copy() or create_default_registry().

    Thread Safety:
        Fully thread-safe. Uses functools.lru_cache internally to guarantee
        that concurrent calls always return the same instance without race
        conditions. The registry is frozen, so writes are not possible.
        For custom functions, use create_default_registry() to get a fresh,
        isolated copy.

    Performance:
        Using the shared registry avoids:
        - Creating a new FunctionRegistry object per bundle
        - Re-registering NUMBER, DATETIME, CURRENCY for each bundle
        - Memory overhead of duplicate function metadata

        For applications with many bundles (e.g., one per locale), this provides
        significant memory and initialization savings.

    Returns:
        Frozen shared FunctionRegistry with NUMBER, DATETIME, and CURRENCY.

    Raises:
        TypeError: If you attempt to call register() on the returned registry.

    Example:
        >>> # Efficient: Share registry across multiple bundles
        >>> shared = get_shared_registry()
        >>> bundle_en = FluentBundle("en", functions=shared)
        >>> bundle_de = FluentBundle("de", functions=shared)
        >>> bundle_fr = FluentBundle("fr", functions=shared)
        >>>
        >>> # Registry is frozen - attempting to modify raises TypeError
        >>> shared.register(my_func)  # Raises TypeError!
        >>>
        >>> # To add custom functions, use copy() to get unfrozen copy:
        >>> my_registry = shared.copy()
        >>> my_registry.register(my_custom_func, ftl_name="CUSTOM")

    See Also:
        create_default_registry: Creates a new unfrozen registry for customization.
    """
    return _create_shared_registry()
