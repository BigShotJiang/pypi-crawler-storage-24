# FixErr AI CLI

An AI-powered CLI tool that explains programming errors instantly.

## Installation

pip install fixerr-ai

## Usage

fixerr "ModuleNotFoundError: numpy"

## Features

- AI error explanation
- Clipboard error detection
- Log file analysis
- Pipe terminal errors
- Copy fix command automatically