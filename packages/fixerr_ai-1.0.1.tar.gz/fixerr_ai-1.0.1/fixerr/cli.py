import sys
import argparse
import pyperclip
from rich.console import Console
from rich.panel import Panel
from .ai_engine import explain_error

console = Console()


def read_stdin():
    """Read piped input"""
    if not sys.stdin.isatty():
        return sys.stdin.read().strip()
    return None


import re

def extract_fix_command(text):
    """
    Extract install commands from AI response
    """

    patterns = [
        r"pip install [a-zA-Z0-9_\-\.]+",
        r"python -m pip install [a-zA-Z0-9_\-\.]+",
        r"npm install [a-zA-Z0-9_\-\.]+",
        r"apt install [a-zA-Z0-9_\-\.]+",
        r"conda install [a-zA-Z0-9_\-\.]+",
        r"brew install [a-zA-Z0-9_\-\.]+"
    ]

    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            return match.group()

    return None
def main():

    parser = argparse.ArgumentParser(
        description="AI CLI tool that explains programming errors"
    )

    parser.add_argument("error", nargs="*", help="Error message")
    parser.add_argument("--paste", action="store_true", help="Read error from clipboard")
    parser.add_argument("--file", type=str, help="Read error from log file")
    parser.add_argument("--copy-fix", action="store_true", help="Copy suggested fix command to clipboard")
    args = parser.parse_args()

    error_message = None

# ---------- Clipboard Mode ----------
    if args.paste:
        error_message = pyperclip.paste()

        console.print("\n[bold cyan]Analyzing error with AI...[/bold cyan]\n")

        explanation = explain_error(error_message)

        console.print(
            Panel(
            explanation,
            title="AI Error Explanation",
            border_style="green"
            )
        )

        return

    # 2️⃣ File mode
    elif args.file:
        try:
            with open(args.file, "r") as f:
                error_message = f.read()
        except Exception as e:
            console.print(f"[red]Error reading file:[/red] {e}")
            sys.exit(1)

    # 3️⃣ Pipe mode
    else:
        piped = read_stdin()
        if piped:
            error_message = piped
        else:
            error_message = " ".join(args.error)

    if not error_message:
        console.print("[red]No error message provided.[/red]")
        console.print("Usage examples:")
        console.print("fixerr \"ModuleNotFoundError: numpy\"")
        console.print("fixerr --paste")
        console.print("fixerr --file error.log")
        sys.exit(1)

    console.print("\n[bold cyan]Analyzing error with AI...[/bold cyan]\n")
    error_message = error_message[:2000]
    explanation = explain_error(error_message)

    console.print(
        Panel(
            explanation,
            title="AI Error Explanation",
            border_style="green"
            )
        )

# Copy fix command if requested
    if args.copy_fix:
        command = extract_fix_command(explanation)

        if command:
            pyperclip.copy(command)
            console.print(f"\n[green]Copied fix command to clipboard:[/green] {command}")
        else:
            console.print("\n[yellow]No fix command detected to copy.[/yellow]")
        return
    if len(sys.argv) < 2:
        console.print("[red]Usage:[/red] fixerr \"your error message\"")
        sys.exit(1)

    error_message = " ".join(sys.argv[1:])

    console.print("\n[bold cyan]Analyzing error with AI...[/bold cyan]\n")

    result = explain_error(error_message)

    console.print(
        Panel(
            result,
            title="AI Error Explanation",
            border_style="green"
        )
    )