import os
from groq import Groq

client = Groq(api_key=os.getenv("GROQ_API_KEY"))

def explain_error(error_message):

    prompt = f"""
You are an expert programming assistant.

A developer encountered this error:

{error_message}

Explain clearly:

1. What the error means
2. Why it happens
3. Possible fixes
4. Exact commands to solve it

Make explanation beginner friendly.
"""

    response = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    return response.choices[0].message.content