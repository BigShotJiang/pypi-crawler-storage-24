from setuptools import setup, find_packages

setup(
    name="fixerr-ai",
    version="1.0.1",
    packages=find_packages(),
    install_requires=[
        "groq",
        "rich",
        "pyperclip"
    ],
    entry_points={
        "console_scripts": [
            "fixerr=fixerr.cli:main",
        ],
    },
    author="Sumedh Acharya",
    description="AI CLI tool that explains programming errors instantly",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/soulkiller95/SumedhFixerr",
    python_requires=">=3.8",
)