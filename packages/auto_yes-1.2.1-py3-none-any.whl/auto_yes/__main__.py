from auto_yes.wrapper import main
main()
