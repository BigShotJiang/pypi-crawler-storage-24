"""Locate the platform-specific Go binary and exec into it."""
import os
import platform
import sys


def _detect_platform():
    """Return (os, arch) matching goreleaser naming."""
    system = platform.system().lower()  # linux, darwin, windows
    machine = platform.machine().lower()

    if machine in ("x86_64", "amd64"):
        arch = "amd64"
    elif machine in ("aarch64", "arm64"):
        arch = "arm64"
    else:
        arch = machine

    return system, arch


def _find_binary():
    plat_os, plat_arch = _detect_platform()
    ext = ".exe" if plat_os == "windows" else ""
    binary_name = f"auto-yes{ext}"

    # 1. Platform-specific subdirectory inside wheel
    #    e.g., auto_yes/bin/linux_amd64/auto-yes
    pkg_dir = os.path.dirname(__file__)
    candidate = os.path.join(pkg_dir, "bin", f"{plat_os}_{plat_arch}", binary_name)
    if os.path.isfile(candidate):
        return candidate

    # 2. Flat bin/ directory (legacy single-platform wheel)
    candidate = os.path.join(pkg_dir, "bin", binary_name)
    if os.path.isfile(candidate):
        return candidate

    # 3. Search PATH
    for d in os.environ.get("PATH", "").split(os.pathsep):
        p = os.path.join(d, binary_name)
        if os.path.isfile(p):
            return p

    raise FileNotFoundError(
        f"auto-yes binary not found for {plat_os}/{plat_arch}. "
        f"Reinstall: pip install --force-reinstall auto-yes"
    )


def main():
    binary = _find_binary()
    if sys.platform == "win32":
        import subprocess
        sys.exit(subprocess.run([binary] + sys.argv[1:]).returncode)
    else:
        os.execvp(binary, [binary] + sys.argv[1:])
