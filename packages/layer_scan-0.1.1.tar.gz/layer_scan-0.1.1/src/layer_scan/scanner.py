"""Core scanning engine — orchestrates (i, j) configuration search.

The scanner iterates over valid (i, j) pairs, applies layer duplication
to the model's forward pass, evaluates using the selected probe, and
collects scores into a heatmap-ready matrix.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeRemainingColumn,
)

from layer_scan.config import DuplicationConfig, ScanConfig, ScanResult
from layer_scan.scoring import ScoreResult, aggregate_scores

if TYPE_CHECKING:
    from layer_scan.backends.base import Backend
    from layer_scan.probes.base import Probe


@dataclass
class ScanReport:
    """Complete report from a scan run.

    Args:
        scan_config: The configuration used for this scan.
        results: All individual (i, j) results.
        baseline_score: Score of the unmodified model (i=j, no duplication).
        heatmap_matrix: 2D numpy array of scores indexed by (i, j).
        top_configs: Top-k best configurations.
        total_time_seconds: Wall-clock time for the full scan.
    """

    scan_config: ScanConfig
    results: list[ScanResult]
    baseline_score: float
    baseline_uncertainty: float
    heatmap_matrix: np.ndarray
    uncertainty_matrix: np.ndarray
    top_configs: list[ScanResult]
    total_time_seconds: float
    total_layers: int
    metadata: dict[str, object] = field(default_factory=dict)


def _generate_configs(
    total_layers: int,
    min_block_size: int,
    step: int,
    skip_early: int,
    skip_late: int,
) -> list[DuplicationConfig]:
    """Generate all valid (i, j) configurations to scan."""
    configs = []
    i_start = skip_early
    j_end = total_layers - skip_late

    for i in range(i_start, j_end, step):
        for j in range(i + min_block_size, j_end + 1, step):
            configs.append(
                DuplicationConfig(i=i, j=j, total_layers=total_layers)
            )

    return configs


def _generate_sparse_configs(
    total_layers: int,
    min_block_size: int,
    sparse_step: int,
    skip_early: int,
    skip_late: int,
) -> list[DuplicationConfig]:
    """Generate sparse (i, j) configurations for initial exploration."""
    configs = []
    i_start = skip_early
    j_end = total_layers - skip_late

    for i in range(i_start, j_end, sparse_step):
        for j in range(i + min_block_size, j_end + 1, sparse_step):
            configs.append(
                DuplicationConfig(i=i, j=j, total_layers=total_layers)
            )

    return configs


def run_scan(
    backend: Backend,
    probe: Probe,
    scan_config: ScanConfig,
) -> ScanReport:
    """Execute a full scan over (i, j) configurations.

    Args:
        backend: The model backend to use for inference.
        probe: The evaluation probe providing test samples.
        scan_config: Scan configuration parameters.

    Returns:
        ScanReport with all results, heatmap matrix, and top configs.
    """
    total_layers = backend.get_total_layers()
    samples = probe.get_samples(count=scan_config.batch_size)
    token_ids, score_values = probe.get_score_token_ids(backend.get_tokenizer())

    # Step 1: Baseline (no duplication)
    baseline_scores = _evaluate_config(
        backend=backend,
        config=None,
        samples=samples,
        score_token_ids=token_ids,
        score_values=score_values,
    )
    baseline_score, baseline_uncertainty = aggregate_scores(baseline_scores)

    # Step 2: Generate configs
    if scan_config.sparse_first:
        configs = _generate_sparse_configs(
            total_layers=total_layers,
            min_block_size=scan_config.min_block_size,
            sparse_step=scan_config.sparse_step,
            skip_early=scan_config.skip_early,
            skip_late=scan_config.skip_late,
        )
    else:
        configs = _generate_configs(
            total_layers=total_layers,
            min_block_size=scan_config.min_block_size,
            step=scan_config.step,
            skip_early=scan_config.skip_early,
            skip_late=scan_config.skip_late,
        )

    # Step 3: Scan all configs
    results: list[ScanResult] = []
    heatmap = np.full((total_layers, total_layers + 1), np.nan)
    uncertainty_map = np.full((total_layers, total_layers + 1), np.nan)

    start_time = time.time()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        MofNCompleteColumn(),
        TimeRemainingColumn(),
    ) as progress:
        task = progress.add_task(
            f"Scanning {len(configs)} configs (baseline={baseline_score:.3f})",
            total=len(configs),
        )

        for config in configs:
            t0 = time.time()
            score_results = _evaluate_config(
                backend=backend,
                config=config,
                samples=samples,
                score_token_ids=token_ids,
                score_values=score_values,
            )
            elapsed = time.time() - t0

            score, unc = aggregate_scores(score_results)

            result = ScanResult(
                config=config,
                score=score,
                uncertainty=unc,
                per_sample_scores=[r.expected_score for r in score_results],
                metadata={"eval_time_seconds": elapsed},
            )
            results.append(result)
            heatmap[config.i, config.j] = score
            uncertainty_map[config.i, config.j] = unc

            progress.update(task, advance=1)

    total_time = time.time() - start_time

    # Step 4: Rank and select top-k
    sorted_results = sorted(results, key=lambda r: r.score, reverse=True)
    top_configs = sorted_results[: scan_config.top_k]

    return ScanReport(
        scan_config=scan_config,
        results=results,
        baseline_score=baseline_score,
        baseline_uncertainty=baseline_uncertainty,
        heatmap_matrix=heatmap,
        uncertainty_matrix=uncertainty_map,
        top_configs=top_configs,
        total_time_seconds=total_time,
        total_layers=total_layers,
        metadata={
            "configs_scanned": len(configs),
            "samples_per_config": len(samples),
            "probe": probe.name,
        },
    )


def _evaluate_config(
    backend: Backend,
    config: DuplicationConfig | None,
    samples: list,
    score_token_ids: list[int],
    score_values: list[float],
) -> list[ScoreResult]:
    """Evaluate a single (i, j) configuration on all probe samples.

    Args:
        backend: Model backend.
        config: Duplication config, or None for baseline (no duplication).
        samples: Probe samples to evaluate.
        score_token_ids: Token IDs for scoring.
        score_values: Numeric values for each score token.

    Returns:
        List of ScoreResult for each sample.
    """
    from layer_scan.scoring import score_from_logits

    results = []
    for sample in samples:
        logits = backend.forward_with_duplication(
            text=sample.full_text,
            duplication_config=config,
        )
        result = score_from_logits(
            logits=logits,
            score_token_ids=score_token_ids,
            score_values=score_values,
        )
        results.append(result)

    return results
