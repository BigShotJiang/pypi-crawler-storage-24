"""CLI entry point for layer-scan.

Usage:
    layer-scan scan --model <path> --probe math
    layer-scan scan --model <path> --probe json --backend exllamav2
    layer-scan scan --model <path> --probe custom --custom-probe my_probe.json
"""

from __future__ import annotations

import logging
from pathlib import Path

import typer
from rich.console import Console

from layer_scan import __version__
from rich.panel import Panel

app = typer.Typer(
    name="layer-scan",
    help="Automated LLM layer duplication configuration scanner",
    add_completion=False,
)
console = Console()


def _setup_logging(verbose: bool) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )


def _load_probe(probe_name: str, custom_probe_path: str | None = None):
    """Load the specified probe by name."""
    from layer_scan.probes.custom import CustomProbe
    from layer_scan.probes.eq_probe import EqProbe
    from layer_scan.probes.json_probe import JsonProbe
    from layer_scan.probes.math_probe import MathProbe

    builtin_probes = {
        "math": MathProbe,
        "eq": EqProbe,
        "json": JsonProbe,
    }

    if probe_name == "custom":
        if not custom_probe_path:
            console.print("[red]--custom-probe required when --probe=custom[/red]")
            raise typer.Exit(1)
        return CustomProbe(custom_probe_path)

    if probe_name in builtin_probes:
        return builtin_probes[probe_name]()

    console.print(f"[red]Unknown probe: {probe_name}[/red]")
    console.print(f"Available probes: {', '.join(builtin_probes.keys())}, custom")
    raise typer.Exit(1)


def _load_backend(backend_name: str):
    """Load the specified inference backend."""
    if backend_name == "transformers":
        from layer_scan.backends.transformers_backend import TransformersBackend

        return TransformersBackend()
    elif backend_name == "exllamav2":
        from layer_scan.backends.exllamav2 import ExLlamaV2Backend

        return ExLlamaV2Backend()
    else:
        console.print(f"[red]Unknown backend: {backend_name}[/red]")
        console.print("Available backends: transformers, exllamav2")
        raise typer.Exit(1)


@app.command()
def scan(
    model: str = typer.Option(..., "--model", "-m", help="Model path or HuggingFace ID"),
    probe: str = typer.Option("math", "--probe", "-p", help="Probe name: math, eq, json, custom"),
    backend: str = typer.Option(
        "transformers", "--backend", "-b", help="Backend: transformers, exllamav2",
    ),
    min_block: int = typer.Option(7, "--min-block", help="Minimum duplicated block size"),
    step: int = typer.Option(1, "--step", "-s", help="Step size for scanning i and j"),
    skip_early: int = typer.Option(0, "--skip-early", help="Skip N early layers"),
    skip_late: int = typer.Option(0, "--skip-late", help="Skip N late layers"),
    batch_size: int = typer.Option(16, "--batch-size", help="Samples per evaluation"),
    top_k: int = typer.Option(5, "--top-k", "-k", help="Number of top configs to report"),
    output: str = typer.Option("./results", "--output", "-o", help="Output directory"),
    sparse_first: bool = typer.Option(
        False, "--sparse-first", help="Do sparse scan first, then refine",
    ),
    sparse_step: int = typer.Option(4, "--sparse-step", help="Step size for sparse scanning"),
    custom_probe: str = typer.Option(None, "--custom-probe", help="Path to custom probe JSON file"),
    dtype: str = typer.Option("float16", "--dtype", help="Model dtype: float16, bfloat16, float32"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose logging"),
    gpu_split: str = typer.Option(
        None, "--gpu-split", help="GPU memory split in MB, e.g. '22000,22000'",
    ),
    export_mergekit: str = typer.Option(
        None, "--export-mergekit", help="Export top config as mergekit YAML",
    ),
) -> None:
    """Scan layer duplication configurations and generate heatmap."""
    _setup_logging(verbose)

    from layer_scan.config import ScanConfig
    from layer_scan.heatmap import generate_heatmap, generate_summary_text, save_results_json
    from layer_scan.scanner import run_scan

    console.print(
        Panel(
            f"[bold]layer-scan v{__version__}[/bold]\n"
            f"Model: {model}\n"
            f"Probe: {probe}\n"
            f"Backend: {backend}\n"
            f"Min block: {min_block} | Step: {step}",
            title="Configuration",
        )
    )

    # Load probe and backend
    probe_instance = _load_probe(probe, custom_probe)
    backend_instance = _load_backend(backend)

    # Parse GPU split
    backend_kwargs = {"dtype": dtype}
    if gpu_split:
        backend_kwargs["gpu_split"] = [int(x.strip()) for x in gpu_split.split(",")]

    console.print("[bold cyan]Loading model...[/bold cyan]")
    backend_instance.load(model, **backend_kwargs)

    total_layers = backend_instance.get_total_layers()
    console.print(f"[green]Model loaded: {total_layers} layers[/green]")

    # Validate probe
    probe_instance.validate(backend_instance.get_tokenizer())
    console.print(f"[green]Probe '{probe}' validated[/green]")

    # Build scan config
    scan_config = ScanConfig(
        model_path=model,
        probe_name=probe,
        min_block_size=min_block,
        step=step,
        skip_early=skip_early,
        skip_late=skip_late,
        batch_size=batch_size,
        output_dir=output,
        backend=backend,
        dtype=dtype,
        top_k=top_k,
        sparse_first=sparse_first,
        sparse_step=sparse_step,
        custom_probe_path=custom_probe,
    )

    # Run scan
    console.print("[bold cyan]Starting scan...[/bold cyan]")
    report = run_scan(
        backend=backend_instance,
        probe=probe_instance,
        scan_config=scan_config,
    )

    # Output results
    output_dir = Path(output)
    output_dir.mkdir(parents=True, exist_ok=True)

    summary = generate_summary_text(report)
    console.print(summary)

    heatmap_path = generate_heatmap(
        report,
        output_dir / "heatmap.html",
    )
    console.print(f"\n[green]Heatmap: {heatmap_path}[/green]")

    json_path = save_results_json(report, output_dir / "results.json")
    console.print(f"[green]Results: {json_path}[/green]")

    # Export mergekit YAML if requested
    if export_mergekit:
        from layer_scan.export import export_mergekit_yaml

        yaml_content = export_mergekit_yaml(report, model)
        mergekit_path = Path(export_mergekit)
        mergekit_path.parent.mkdir(parents=True, exist_ok=True)
        mergekit_path.write_text(yaml_content)
        console.print(f"[green]mergekit YAML: {mergekit_path}[/green]")

    # Cleanup
    backend_instance.cleanup()
    console.print("[dim]Done.[/dim]")


@app.command()
def probes() -> None:
    """List available evaluation probes."""
    from layer_scan.probes.eq_probe import EqProbe
    from layer_scan.probes.json_probe import JsonProbe
    from layer_scan.probes.math_probe import MathProbe

    console.print("[bold]Available Probes:[/bold]\n")

    for probe_cls in [MathProbe, EqProbe, JsonProbe]:
        p = probe_cls()
        samples = p.get_samples()
        console.print(f"  [cyan]{p.name}[/cyan]")
        console.print(f"    {p.description}")
        console.print(f"    Samples: {len(samples)}")
        console.print()

    console.print("  [cyan]custom[/cyan]")
    console.print("    Load from JSON file with --custom-probe <path>")


@app.command()
def version() -> None:
    """Show version."""
    from layer_scan import __version__

    console.print(f"layer-scan v{__version__}")


def main() -> None:
    app()


if __name__ == "__main__":
    main()
