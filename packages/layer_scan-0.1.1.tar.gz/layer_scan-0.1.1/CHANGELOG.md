# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-03-11

### Added

- Core scanning engine with configurable (i, j) layer duplication
- Logit distribution scoring (deterministic, no sampling)
- Three built-in probes: math, eq (emotional intelligence), json (format compliance)
- Custom probe support via JSON files
- Two inference backends: HuggingFace Transformers and ExLlamaV2
- Interactive Plotly HTML heatmap visualization
- mergekit passthrough YAML export (`--export-mergekit`)
- Sparse-first two-pass scanning (`--sparse-first`)
- CLI with `scan`, `probes`, and `version` commands
- Input validation for ScanConfig parameters
- Comprehensive test suite (smoke, black-box, white-box, boundary, stress)
- CI/CD with GitHub Actions (lint, test, PyPI publish)
