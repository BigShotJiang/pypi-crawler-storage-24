"""Smoke tests for offidized Python bindings.

Verifies that all exported types import, construct, and perform basic
round-trip operations. These tests don't need real Office files — they
exercise the in-memory create/save/load path.
"""

import zipfile

import offidized


# ---------------------------------------------------------------------------
# Import completeness
# ---------------------------------------------------------------------------


def test_all_exports_importable():
    """Every name in __all__ should be an attribute of the module."""
    for name in offidized.__all__:
        assert hasattr(offidized, name), f"offidized.{name} not found"


def test_all_exports_are_not_none():
    """Every export should resolve to a real object (not accidentally None)."""
    for name in offidized.__all__:
        obj = getattr(offidized, name)
        assert obj is not None, f"offidized.{name} is None"


def _rewrite_docx_part_xml(path, part_name, transform):
    with zipfile.ZipFile(path, "r") as src:
        parts = {name: src.read(name) for name in src.namelist()}
    xml = parts[part_name].decode("utf-8")
    parts[part_name] = transform(xml).encode("utf-8")
    with zipfile.ZipFile(path, "w") as dst:
        for name, data in parts.items():
            dst.writestr(name, data)


def _rewrite_docx_document_xml(path, transform):
    _rewrite_docx_part_xml(path, "word/document.xml", transform)


# ---------------------------------------------------------------------------
# xlsx
# ---------------------------------------------------------------------------


def test_workbook_create_and_sheet_names():
    wb = offidized.Workbook()
    names = wb.sheet_names()
    assert isinstance(names, list)
    # New workbook starts empty; add a sheet to use it
    assert len(names) == 0


def test_workbook_add_sheet():
    wb = offidized.Workbook()
    wb.add_sheet("Sales")
    names = wb.sheet_names()
    assert "Sales" in names


def test_workbook_roundtrip_bytes():
    wb = offidized.Workbook()
    wb.add_sheet("Data")
    data = wb.to_bytes()
    assert isinstance(data, bytes)
    assert len(data) > 0

    wb2 = offidized.Workbook.from_bytes(data)
    assert "Data" in wb2.sheet_names()


def test_worksheet_cell_value():
    wb = offidized.Workbook()
    wb.add_sheet("Sheet1")
    ws = wb.sheet("Sheet1")
    ws.set_cell_value("A1", "hello")
    assert ws.cell_value("A1") == "hello"


def test_worksheet_cell_types():
    wb = offidized.Workbook()
    wb.add_sheet("Sheet1")
    ws = wb.sheet("Sheet1")

    ws.set_cell_value("A1", "text")
    ws.set_cell_value("A2", 42)
    ws.set_cell_value("A3", 3.14)
    ws.set_cell_value("A4", True)

    assert ws.cell_value("A1") == "text"
    assert ws.cell_value("A2") == 42
    assert ws.cell_value("A3") == 3.14
    assert ws.cell_value("A4") is True


def test_worksheet_cell_formula():
    wb = offidized.Workbook()
    wb.add_sheet("Sheet1")
    ws = wb.sheet("Sheet1")
    ws.set_cell_formula("B1", "=A1+1")
    formula = ws.cell_formula("B1")
    # Rust stores without leading '='; accept either form
    assert formula in ("=A1+1", "A1+1")


def test_workbook_save_and_open(tmp_path):
    path = str(tmp_path / "test.xlsx")
    wb = offidized.Workbook()
    wb.add_sheet("Sheet1")
    ws = wb.sheet("Sheet1")
    ws.set_cell_value("A1", "roundtrip")
    wb.save(path)

    wb2 = offidized.Workbook.open(path)
    ws2 = wb2.sheet("Sheet1")
    assert ws2.cell_value("A1") == "roundtrip"


def test_xlsx_cell_wrapper():
    wb = offidized.Workbook()
    wb.add_sheet("Sheet1")
    ws = wb.sheet("Sheet1")
    ws.set_cell_value("C3", 99)
    cell = ws.cell("C3")
    assert cell.value() == 99
    assert cell.reference() == "C3"


def test_xlsx_style_construct():
    style = offidized.XlsxStyle()
    style.set_number_format("0.00")
    assert style.number_format() == "0.00"


def test_xlsx_font_construct():
    font = offidized.XlsxFont()
    font.name = "Arial"
    font.bold = True
    font.size = "12"
    assert font.name == "Arial"
    assert font.bold is True
    assert font.size == "12"


def test_xlsx_fill_construct():
    fill = offidized.XlsxFill()
    fill.pattern = "solid"
    fill.foreground_color = "FF0000FF"
    assert fill.pattern == "solid"


def test_xlsx_border_construct():
    border = offidized.XlsxBorder()
    border.left_style = "thin"
    border.left_color = "FF000000"
    assert border.left_style == "thin"


def test_xlsx_alignment_construct():
    alignment = offidized.XlsxAlignment()
    alignment.horizontal = "center"
    alignment.wrap_text = True
    assert alignment.horizontal == "center"
    assert alignment.wrap_text is True


def test_worksheet_merged_ranges():
    wb = offidized.Workbook()
    wb.add_sheet("Sheet1")
    ws = wb.sheet("Sheet1")
    ws.add_merged_range("A1:B2")
    ranges = ws.merged_ranges()
    assert len(ranges) == 1
    assert "A1" in ranges[0]


# ---------------------------------------------------------------------------
# docx
# ---------------------------------------------------------------------------


def test_document_create():
    doc = offidized.Document()
    assert doc is not None


def test_document_add_paragraph():
    doc = offidized.Document()
    doc.add_paragraph("Hello, world!")
    paras = doc.paragraphs()
    texts = [p.text() for p in paras]
    assert "Hello, world!" in texts


def test_document_add_heading():
    doc = offidized.Document()
    doc.add_heading("Title", 1)
    paras = doc.paragraphs()
    assert len(paras) >= 1


def test_document_roundtrip_bytes():
    doc = offidized.Document()
    doc.add_paragraph("test content")
    data = doc.to_bytes()
    assert isinstance(data, bytes)
    assert len(data) > 0

    doc2 = offidized.Document.from_bytes(data)
    texts = [p.text() for p in doc2.paragraphs()]
    assert "test content" in texts


def test_document_save_and_open(tmp_path):
    path = str(tmp_path / "test.docx")
    doc = offidized.Document()
    doc.add_paragraph("roundtrip")
    doc.save(path)

    doc2 = offidized.Document.open(path)
    texts = [p.text() for p in doc2.paragraphs()]
    assert "roundtrip" in texts


def test_docx_paragraph_runs():
    doc = offidized.Document()
    doc.add_paragraph("some text")
    paras = doc.paragraphs()
    para = [p for p in paras if p.text() == "some text"][0]
    runs = para.runs()
    assert len(runs) >= 1
    assert runs[0].text() == "some text"


def test_docx_run_formatting():
    doc = offidized.Document()
    doc.add_paragraph("bold text")
    paras = doc.paragraphs()
    para = [p for p in paras if p.text() == "bold text"][0]
    run = para.runs()[0]
    run.set_bold(True)
    assert run.is_bold() is True


def test_docx_add_table():
    doc = offidized.Document()
    doc.add_table(2, 3)
    tables = doc.tables()
    assert len(tables) >= 1


def test_docx_table_cell_text():
    doc = offidized.Document()
    doc.add_table(2, 2)
    table = doc.tables()[0]
    table.set_cell_text(0, 0, "hello")
    assert table.cell_text(0, 0) == "hello"


def test_docx_section():
    doc = offidized.Document()
    section = doc.section()
    assert section is not None
    # New empty doc may not have page size set; just verify the accessor works
    section.page_width_twips()  # returns int or None


def test_docx_document_properties():
    doc = offidized.Document()
    props = doc.document_properties()
    assert props is not None


def test_docx_compare_marks_simple_moved_header_paragraphs_as_moves(tmp_path):
    original_path = str(tmp_path / "compare-header-move-original.docx")
    revised_path = str(tmp_path / "compare-header-move-revised.docx")
    compared_path = str(tmp_path / "compare-header-move-compared.docx")

    original = offidized.Document()
    original.section().set_header_text("placeholder")
    original.save(original_path)
    _rewrite_docx_part_xml(
        original_path,
        "word/header1.xml",
        lambda xml: xml.replace(
            """<w:p>
    <w:r>
      <w:t>placeholder</w:t>
    </w:r>
  </w:p>""",
            """<w:p><w:r><w:t>Intro</w:t></w:r></w:p><w:p><w:r><w:t>Moved header paragraph</w:t></w:r></w:p><w:p><w:r><w:t>Stable tail</w:t></w:r></w:p>""",
        ),
    )

    revised = offidized.Document()
    revised.section().set_header_text("placeholder")
    revised.save(revised_path)
    _rewrite_docx_part_xml(
        revised_path,
        "word/header1.xml",
        lambda xml: xml.replace(
            """<w:p>
    <w:r>
      <w:t>placeholder</w:t>
    </w:r>
  </w:p>""",
            """<w:p><w:r><w:t>Intro</w:t></w:r></w:p><w:p><w:r><w:t>Stable tail</w:t></w:r></w:p><w:p><w:r><w:t>Moved header paragraph</w:t></w:r></w:p>""",
        ),
    )

    compared = offidized.Document.compare(original_path, revised_path, "Comparer")
    compared.save(compared_path)

    with zipfile.ZipFile(compared_path, "r") as package:
        header_xml = package.read("word/header1.xml").decode("utf-8")
    assert "w:moveFromRangeStart" in header_xml
    assert "w:moveFromRangeEnd" in header_xml
    assert "w:moveToRangeStart" in header_xml
    assert "w:moveToRangeEnd" in header_xml
    assert "<w:moveFrom w:id=" in header_xml
    assert "<w:moveTo w:id=" in header_xml
    assert 'w:author="Comparer"' in header_xml
    assert 'w:date="2000-01-01T00:00:00Z"' in header_xml

    reopened = offidized.Document.open(compared_path)
    revisions = reopened.revisions()
    assert any(
        revision[5] == "header/default/paragraph:1"
        and revision[1] == "move_from"
        and revision[4] == "Moved header paragraph"
        for revision in revisions
    )
    assert any(
        revision[5] == "header/default/paragraph:3"
        and revision[1] == "move_to"
        and revision[4] == "Moved header paragraph"
        for revision in revisions
    )



def test_docx_compare_marks_simple_moved_body_table_cell_paragraphs_with_move_ranges(tmp_path):
    original_path = str(tmp_path / "compare-body-table-cell-move-original.docx")
    revised_path = str(tmp_path / "compare-body-table-cell-move-revised.docx")
    compared_path = str(tmp_path / "compare-body-table-cell-move-compared.docx")

    original = offidized.Document()
    original.add_table(1, 1).set_cell_text(0, 0, "placeholder")
    original.save(original_path)
    _rewrite_docx_part_xml(
        original_path,
        "word/document.xml",
        lambda xml: xml.replace(
            """<w:p>
            <w:r>
              <w:t>placeholder</w:t>
            </w:r>
          </w:p>""",
            """<w:p><w:r><w:t>Intro</w:t></w:r></w:p><w:p><w:r><w:t>Moved cell paragraph</w:t></w:r></w:p><w:p><w:r><w:t>Stable tail</w:t></w:r></w:p>""",
        ),
    )

    revised = offidized.Document()
    revised.add_table(1, 1).set_cell_text(0, 0, "placeholder")
    revised.save(revised_path)
    _rewrite_docx_part_xml(
        revised_path,
        "word/document.xml",
        lambda xml: xml.replace(
            """<w:p>
            <w:r>
              <w:t>placeholder</w:t>
            </w:r>
          </w:p>""",
            """<w:p><w:r><w:t>Intro</w:t></w:r></w:p><w:p><w:r><w:t>Stable tail</w:t></w:r></w:p><w:p><w:r><w:t>Moved cell paragraph</w:t></w:r></w:p>""",
        ),
    )

    compared = offidized.Document.compare(original_path, revised_path, "Comparer")
    compared.save(compared_path)

    with zipfile.ZipFile(compared_path, "r") as package:
        document_xml = package.read("word/document.xml").decode("utf-8")
    assert "w:moveFromRangeStart" in document_xml
    assert "w:moveFromRangeEnd" in document_xml
    assert "w:moveToRangeStart" in document_xml
    assert "w:moveToRangeEnd" in document_xml
    assert "<w:moveFrom w:id=" in document_xml
    assert "<w:moveTo w:id=" in document_xml
    assert 'w:author="Comparer"' in document_xml
    assert 'w:date="2000-01-01T00:00:00Z"' in document_xml

    reopened = offidized.Document.open(compared_path)
    revisions = reopened.revisions()
    assert any(
        revision[5] == "body/table:0/cell:0,0/paragraph:1"
        and revision[1] == "move_from"
        and revision[4] == "Moved cell paragraph"
        for revision in revisions
    )
    assert any(
        revision[5] == "body/table:0/cell:0,0/paragraph:3"
        and revision[1] == "move_to"
        and revision[4] == "Moved cell paragraph"
        for revision in revisions
    )



def test_docx_compare_marks_moved_body_paragraphs_as_moves_even_with_style_change(tmp_path):
    original_path = str(tmp_path / "compare-move-style-original.docx")
    revised_path = str(tmp_path / "compare-move-style-revised.docx")
    compared_path = str(tmp_path / "compare-move-style-compared.docx")

    original = offidized.Document()
    original.add_paragraph("Intro")
    original.add_paragraph("Moved paragraph")
    original.add_paragraph("Stable tail")
    original.save(original_path)

    revised = offidized.Document()
    revised.add_paragraph("Intro")
    revised.add_paragraph("Stable tail")
    revised.add_heading("Moved paragraph", 1)
    revised.save(revised_path)

    compared = offidized.Document.compare(original_path, revised_path, "Comparer")
    compared.save(compared_path)

    with zipfile.ZipFile(compared_path, "r") as package:
        document_xml = package.read("word/document.xml").decode("utf-8")
    assert '<w:pStyle w:val="Heading1"/>' in document_xml
    assert "<w:rPr>\n          <w:moveTo" in document_xml

    reopened = offidized.Document.open(compared_path)
    revisions = reopened.revisions()
    assert any(
        revision[5] == "body/paragraph:1"
        and revision[1] == "move_from"
        and revision[4] == "Moved paragraph"
        for revision in revisions
    )
    assert any(
        revision[5] == "body/paragraph:3"
        and revision[1] == "move_to"
        and revision[4] == "Moved paragraph"
        for revision in revisions
    )



def test_docx_compare_builds_basic_redline(tmp_path):
    original_path = str(tmp_path / "compare-original.docx")
    revised_path = str(tmp_path / "compare-revised.docx")
    compared_path = str(tmp_path / "compare-redline.docx")

    original = offidized.Document()
    original.add_paragraph("Alpha Gamma")
    original.save(original_path)

    revised = offidized.Document()
    revised.add_paragraph("Alpha Beta")
    revised.save(revised_path)

    compared = offidized.Document.compare(original_path, revised_path, "Comparer")
    compared.save(compared_path)

    reopened = offidized.Document.open(compared_path)
    revisions = reopened.revisions()
    assert len(revisions) == 2
    assert any(revision[1] == "insertion" and revision[4] == "Beta" for revision in revisions)
    assert any(revision[1] == "deletion" and revision[4] == "Gamma" for revision in revisions)


def test_docx_compare_redlines_header_and_note_paragraph_parts(tmp_path):
    original_path = str(tmp_path / "compare-nonbody-original.docx")
    revised_path = str(tmp_path / "compare-nonbody-revised.docx")
    compared_path = str(tmp_path / "compare-nonbody-redline.docx")

    original = offidized.Document()
    original.section().set_header_text("Header Alpha")
    original.add_footnote(1, "Foot Alpha")
    original.save(original_path)

    revised = offidized.Document()
    revised.section().set_header_text("Header Beta")
    revised.add_footnote(1, "Foot Beta")
    revised.save(revised_path)

    compared = offidized.Document.compare(original_path, revised_path, "Comparer")
    compared.save(compared_path)

    reopened = offidized.Document.open(compared_path)
    revisions = reopened.revisions()
    assert any(revision[5] == "header/default/paragraph:0" and revision[1] == "deletion" for revision in revisions)
    assert any(revision[5] == "header/default/paragraph:0" and revision[1] == "insertion" for revision in revisions)
    assert any(revision[5] == "footnote:1/paragraph:0" and revision[1] == "deletion" for revision in revisions)
    assert any(revision[5] == "footnote:1/paragraph:0" and revision[1] == "insertion" for revision in revisions)


def test_docx_compare_redlines_body_table_cells(tmp_path):
    original_path = str(tmp_path / "compare-body-table-original.docx")
    revised_path = str(tmp_path / "compare-body-table-revised.docx")
    compared_path = str(tmp_path / "compare-body-table-redline.docx")

    original = offidized.Document()
    original.add_table(1, 1).set_cell_text(0, 0, "Budget Q1")
    original.save(original_path)

    revised = offidized.Document()
    revised.add_table(1, 1).set_cell_text(0, 0, "Budget Q2")
    revised.save(revised_path)

    compared = offidized.Document.compare(original_path, revised_path, "Comparer")
    compared.save(compared_path)

    reopened = offidized.Document.open(compared_path)
    revisions = reopened.revisions()
    assert any(
        revision[5] == "body/table:0/cell:0,0/paragraph:0"
        and revision[1] == "deletion"
        and revision[4] == "1"
        for revision in revisions
    )
    assert any(
        revision[5] == "body/table:0/cell:0,0/paragraph:0"
        and revision[1] == "insertion"
        and revision[4] == "2"
        for revision in revisions
    )



def test_docx_compare_redlines_supported_non_body_table_parts(tmp_path):
    original_path = str(tmp_path / "compare-nonbody-table-original.docx")
    revised_path = str(tmp_path / "compare-nonbody-table-revised.docx")
    compared_path = str(tmp_path / "compare-nonbody-table-redline.docx")

    original = offidized.Document()
    original.section().set_header_text("placeholder")
    original.add_footnote(1, "placeholder")
    original.add_endnote(1, "placeholder")
    original.save(original_path)
    _rewrite_docx_part_xml(
        original_path,
        "word/header1.xml",
        lambda xml: xml.replace(
            """<w:p>
    <w:r>
      <w:t>placeholder</w:t>
    </w:r>
  </w:p>""",
            """<w:tbl>
    <w:tblPr/>
    <w:tblGrid>
      <w:gridCol w:w="4320"/>
    </w:tblGrid>
    <w:tr>
      <w:tc>
        <w:p>
          <w:r>
            <w:t>Header Alpha</w:t>
          </w:r>
        </w:p>
      </w:tc>
    </w:tr>
  </w:tbl>""",
            1,
        ),
    )
    _rewrite_docx_part_xml(
        original_path,
        "word/footnotes.xml",
        lambda xml: xml.replace(
            """<w:p>
      <w:r>
        <w:t>placeholder</w:t>
      </w:r>
    </w:p>""",
            """<w:tbl>
      <w:tblPr/>
      <w:tblGrid>
        <w:gridCol w:w="4320"/>
      </w:tblGrid>
      <w:tr>
        <w:tc>
          <w:p>
            <w:r>
              <w:t>Foot Alpha</w:t>
            </w:r>
          </w:p>
        </w:tc>
      </w:tr>
    </w:tbl>""",
            1,
        ),
    )
    _rewrite_docx_part_xml(
        original_path,
        "word/endnotes.xml",
        lambda xml: xml.replace(
            """<w:p>
      <w:r>
        <w:t>placeholder</w:t>
      </w:r>
    </w:p>""",
            """<w:tbl>
      <w:tblPr/>
      <w:tblGrid>
        <w:gridCol w:w="4320"/>
      </w:tblGrid>
      <w:tr>
        <w:tc>
          <w:p>
            <w:r>
              <w:t>End Alpha</w:t>
            </w:r>
          </w:p>
        </w:tc>
      </w:tr>
    </w:tbl>""",
            1,
        ),
    )

    revised = offidized.Document()
    revised.section().set_header_text("placeholder")
    revised.add_footnote(1, "placeholder")
    revised.add_endnote(1, "placeholder")
    revised.save(revised_path)
    _rewrite_docx_part_xml(
        revised_path,
        "word/header1.xml",
        lambda xml: xml.replace(
            """<w:p>
    <w:r>
      <w:t>placeholder</w:t>
    </w:r>
  </w:p>""",
            """<w:tbl>
    <w:tblPr/>
    <w:tblGrid>
      <w:gridCol w:w="4320"/>
    </w:tblGrid>
    <w:tr>
      <w:tc>
        <w:p>
          <w:r>
            <w:t>Header Beta</w:t>
          </w:r>
        </w:p>
      </w:tc>
    </w:tr>
  </w:tbl>""",
            1,
        ),
    )
    _rewrite_docx_part_xml(
        revised_path,
        "word/footnotes.xml",
        lambda xml: xml.replace(
            """<w:p>
      <w:r>
        <w:t>placeholder</w:t>
      </w:r>
    </w:p>""",
            """<w:tbl>
      <w:tblPr/>
      <w:tblGrid>
        <w:gridCol w:w="4320"/>
      </w:tblGrid>
      <w:tr>
        <w:tc>
          <w:p>
            <w:r>
              <w:t>Foot Beta</w:t>
            </w:r>
          </w:p>
        </w:tc>
      </w:tr>
    </w:tbl>""",
            1,
        ),
    )
    _rewrite_docx_part_xml(
        revised_path,
        "word/endnotes.xml",
        lambda xml: xml.replace(
            """<w:p>
      <w:r>
        <w:t>placeholder</w:t>
      </w:r>
    </w:p>""",
            """<w:tbl>
      <w:tblPr/>
      <w:tblGrid>
        <w:gridCol w:w="4320"/>
      </w:tblGrid>
      <w:tr>
        <w:tc>
          <w:p>
            <w:r>
              <w:t>End Beta</w:t>
            </w:r>
          </w:p>
        </w:tc>
      </w:tr>
    </w:tbl>""",
            1,
        ),
    )

    compared = offidized.Document.compare(original_path, revised_path, "Comparer")
    compared.save(compared_path)

    reopened = offidized.Document.open(compared_path)
    revisions = reopened.revisions()
    assert any(
        revision[5] == "header/default/table:0/cell:0,0/paragraph:0"
        and revision[1] == "deletion"
        and revision[4] == "Alpha"
        for revision in revisions
    )
    assert any(
        revision[5] == "header/default/table:0/cell:0,0/paragraph:0"
        and revision[1] == "insertion"
        and revision[4] == "Beta"
        for revision in revisions
    )
    assert any(
        revision[5] == "footnote:1/table:0/cell:0,0/paragraph:0"
        and revision[1] == "deletion"
        and revision[4] == "Alpha"
        for revision in revisions
    )
    assert any(
        revision[5] == "endnote:1/table:0/cell:0,0/paragraph:0"
        and revision[1] == "insertion"
        and revision[4] == "Beta"
        for revision in revisions
    )



def test_docx_compare_redlines_simple_drawing_text_box_content(tmp_path):
    original_path = str(tmp_path / "compare-drawing-textbox-original.docx")
    revised_path = str(tmp_path / "compare-drawing-textbox-revised.docx")
    compared_path = str(tmp_path / "compare-drawing-textbox-redline.docx")

    original = offidized.Document()
    original.add_paragraph("placeholder")
    original.save(original_path)
    _rewrite_docx_document_xml(
        original_path,
        lambda xml: xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Drawing Alpha</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        ),
    )

    revised = offidized.Document()
    revised.add_paragraph("placeholder")
    revised.save(revised_path)
    _rewrite_docx_document_xml(
        revised_path,
        lambda xml: xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Drawing Beta</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        ),
    )

    compared = offidized.Document.compare(original_path, revised_path, "Comparer")
    compared.save(compared_path)

    reopened = offidized.Document.open(compared_path)
    revisions = reopened.revisions()
    assert any(
        revision[5] == "body/paragraph:0"
        and revision[1] == "deletion"
        and revision[4] == "Alpha"
        for revision in revisions
    )
    assert any(
        revision[5] == "body/paragraph:0"
        and revision[1] == "insertion"
        and revision[4] == "Beta"
        for revision in revisions
    )



def test_docx_compare_redlines_supported_non_body_text_box_parts(tmp_path):
    original_path = str(tmp_path / "compare-nonbody-textbox-original.docx")
    revised_path = str(tmp_path / "compare-nonbody-textbox-revised.docx")
    compared_path = str(tmp_path / "compare-nonbody-textbox-redline.docx")

    original = offidized.Document()
    original.section().set_header_text("placeholder")
    original.add_footnote(1, "placeholder")
    original.save(original_path)
    _rewrite_docx_part_xml(
        original_path,
        "word/header1.xml",
        lambda xml: xml.replace(
            "<w:r>\n      <w:t>placeholder</w:t>\n    </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Header Alpha</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        ),
    )
    _rewrite_docx_part_xml(
        original_path,
        "word/footnotes.xml",
        lambda xml: xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Foot Alpha</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        ),
    )

    revised = offidized.Document()
    revised.section().set_header_text("placeholder")
    revised.add_footnote(1, "placeholder")
    revised.save(revised_path)
    _rewrite_docx_part_xml(
        revised_path,
        "word/header1.xml",
        lambda xml: xml.replace(
            "<w:r>\n      <w:t>placeholder</w:t>\n    </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Header Beta</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        ),
    )
    _rewrite_docx_part_xml(
        revised_path,
        "word/footnotes.xml",
        lambda xml: xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Foot Beta</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        ),
    )

    compared = offidized.Document.compare(original_path, revised_path, "Comparer")
    compared.save(compared_path)

    reopened = offidized.Document.open(compared_path)
    revisions = reopened.revisions()
    assert any(
        revision[5] == "header/default/paragraph:0"
        and revision[1] == "deletion"
        and revision[4] == "Alpha"
        for revision in revisions
    )
    assert any(
        revision[5] == "header/default/paragraph:0"
        and revision[1] == "insertion"
        and revision[4] == "Beta"
        for revision in revisions
    )
    assert any(
        revision[5] == "footnote:1/paragraph:0"
        and revision[1] == "deletion"
        and revision[4] == "Alpha"
        for revision in revisions
    )
    assert any(
        revision[5] == "footnote:1/paragraph:0"
        and revision[1] == "insertion"
        and revision[4] == "Beta"
        for revision in revisions
    )



def test_docx_compare_marks_simple_moved_body_text_box_paragraphs_as_moves(tmp_path):
    original_path = str(tmp_path / "compare-body-textbox-move-original.docx")
    revised_path = str(tmp_path / "compare-body-textbox-move-revised.docx")
    compared_path = str(tmp_path / "compare-body-textbox-move-compared.docx")

    original = offidized.Document()
    original.add_paragraph("Intro")
    original.add_paragraph("placeholder")
    original.add_paragraph("Stable tail")
    original.save(original_path)
    _rewrite_docx_document_xml(
        original_path,
        lambda xml: xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Moved textbox paragraph</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        ),
    )

    revised = offidized.Document()
    revised.add_paragraph("Intro")
    revised.add_paragraph("Stable tail")
    revised.add_paragraph("placeholder")
    revised.save(revised_path)
    _rewrite_docx_document_xml(
        revised_path,
        lambda xml: xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Moved textbox paragraph</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        ),
    )

    compared = offidized.Document.compare(original_path, revised_path, "Comparer")
    compared.save(compared_path)

    with zipfile.ZipFile(compared_path, "r") as package:
        document_xml = package.read("word/document.xml").decode("utf-8")
    assert "w:moveFromRangeStart" in document_xml
    assert "w:moveToRangeStart" in document_xml
    assert "<w:moveFrom w:id=" in document_xml
    assert "<w:moveTo w:id=" in document_xml

    reopened = offidized.Document.open(compared_path)
    revisions = reopened.revisions()
    assert any(
        revision[5] == "body/paragraph:1"
        and revision[1] == "move_from"
        and revision[4] == "Moved textbox paragraph"
        for revision in revisions
    )
    assert any(
        revision[5] == "body/paragraph:3"
        and revision[1] == "move_to"
        and revision[4] == "Moved textbox paragraph"
        for revision in revisions
    )



def test_docx_compare_marks_simple_moved_header_text_box_paragraphs_as_moves(tmp_path):
    original_path = str(tmp_path / "compare-header-textbox-move-original.docx")
    revised_path = str(tmp_path / "compare-header-textbox-move-revised.docx")
    compared_path = str(tmp_path / "compare-header-textbox-move-compared.docx")

    original = offidized.Document()
    original.section().set_header_text("placeholder")
    original.save(original_path)
    _rewrite_docx_part_xml(
        original_path,
        "word/header1.xml",
        lambda xml: xml.replace(
            """<w:p>
    <w:r>
      <w:t>placeholder</w:t>
    </w:r>
  </w:p>""",
            """<w:p><w:r><w:t>Intro</w:t></w:r></w:p><w:p><w:r><w:drawing><wp:inline xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape"><a:graphic><a:graphicData uri="http://schemas.microsoft.com/office/word/2010/wordprocessingShape"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Moved header textbox paragraph</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p><w:p><w:r><w:t>Stable tail</w:t></w:r></w:p>""",
        ),
    )

    revised = offidized.Document()
    revised.section().set_header_text("placeholder")
    revised.save(revised_path)
    _rewrite_docx_part_xml(
        revised_path,
        "word/header1.xml",
        lambda xml: xml.replace(
            """<w:p>
    <w:r>
      <w:t>placeholder</w:t>
    </w:r>
  </w:p>""",
            """<w:p><w:r><w:t>Intro</w:t></w:r></w:p><w:p><w:r><w:t>Stable tail</w:t></w:r></w:p><w:p><w:r><w:drawing><wp:inline xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape"><a:graphic><a:graphicData uri="http://schemas.microsoft.com/office/word/2010/wordprocessingShape"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Moved header textbox paragraph</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>""",
        ),
    )

    compared = offidized.Document.compare(original_path, revised_path, "Comparer")
    compared.save(compared_path)

    with zipfile.ZipFile(compared_path, "r") as package:
        header_xml = package.read("word/header1.xml").decode("utf-8")
    assert "w:moveFromRangeStart" in header_xml
    assert "w:moveToRangeStart" in header_xml
    assert "<w:moveFrom w:id=" in header_xml
    assert "<w:moveTo w:id=" in header_xml

    reopened = offidized.Document.open(compared_path)
    revisions = reopened.revisions()
    assert any(
        revision[5] == "header/default/paragraph:1"
        and revision[1] == "move_from"
        and revision[4] == "Moved header textbox paragraph"
        for revision in revisions
    )
    assert any(
        revision[5] == "header/default/paragraph:3"
        and revision[1] == "move_to"
        and revision[4] == "Moved header textbox paragraph"
        for revision in revisions
    )



def test_docx_compare_marks_simple_moved_body_paragraphs_as_moves(tmp_path):
    original_path = str(tmp_path / "compare-move-original.docx")
    revised_path = str(tmp_path / "compare-move-revised.docx")
    compared_path = str(tmp_path / "compare-move-compared.docx")

    original = offidized.Document()
    original.add_paragraph("Intro")
    original.add_paragraph("Moved paragraph")
    original.add_paragraph("Stable tail")
    original.save(original_path)

    revised = offidized.Document()
    revised.add_paragraph("Intro")
    revised.add_paragraph("Stable tail")
    revised.add_paragraph("Moved paragraph")
    revised.save(revised_path)

    compared = offidized.Document.compare(original_path, revised_path, "Comparer")
    compared.save(compared_path)

    with zipfile.ZipFile(compared_path, "r") as package:
        document_xml = package.read("word/document.xml").decode("utf-8")
    assert "w:moveFrom" in document_xml
    assert "w:moveTo" in document_xml
    assert "w:moveFromRangeStart" in document_xml
    assert "w:moveToRangeStart" in document_xml
    assert 'w:author="Comparer" w:date="2000-01-01T00:00:00Z"' in document_xml
    assert "<w:rPr>\n          <w:moveFrom" in document_xml
    assert "<w:rPr>\n          <w:moveTo" in document_xml

    reopened = offidized.Document.open(compared_path)
    revisions = reopened.revisions()
    assert any(
        revision[5] == "body/paragraph:1"
        and revision[1] == "move_from"
        and revision[4] == "Moved paragraph"
        for revision in revisions
    )
    assert any(
        revision[5] == "body/paragraph:3"
        and revision[1] == "move_to"
        and revision[4] == "Moved paragraph"
        for revision in revisions
    )
    assert not any(
        revision[4] == "Moved paragraph"
        and revision[1] in {"insertion", "deletion"}
        for revision in revisions
    )



def test_docx_compare_aligns_inserted_paragraphs(tmp_path):
    original_path = str(tmp_path / "compare-insert-original.docx")
    revised_path = str(tmp_path / "compare-insert-revised.docx")
    compared_path = str(tmp_path / "compare-insert-redline.docx")

    original = offidized.Document()
    original.add_paragraph("Intro")
    original.add_paragraph("Stable tail")
    original.save(original_path)

    revised = offidized.Document()
    revised.add_paragraph("Intro")
    revised.add_paragraph("New middle paragraph")
    revised.add_paragraph("Stable tail")
    revised.save(revised_path)

    compared = offidized.Document.compare(original_path, revised_path, "Comparer")
    compared.save(compared_path)

    reopened = offidized.Document.open(compared_path)
    revisions = reopened.revisions()
    assert len(revisions) == 1
    assert revisions[0][1] == "insertion"
    assert revisions[0][4] == "New middle paragraph"
    assert reopened.paragraph(2).text() == "Stable tail"


def test_docx_tracked_changes_roundtrip(tmp_path):
    path = str(tmp_path / "tracked.docx")
    accepted_path = str(tmp_path / "tracked-accepted.docx")

    doc = offidized.Document()
    para = doc.add_paragraph("Alpha")
    para.add_inserted_text(" Beta", "Reviewer", "2026-03-24T12:00:00Z")
    para.add_deleted_text(" Gamma", "Reviewer", None)
    doc.save(path)

    doc2 = offidized.Document.open(path)
    revisions = doc2.revisions()
    assert len(revisions) == 2
    assert revisions[0][1] == "insertion"
    assert revisions[0][4] == " Beta"
    assert revisions[1][1] == "deletion"
    assert revisions[1][4] == " Gamma"

    counts = doc2.accept_revisions(author="Reviewer", kinds=["insertion", "deletion"])
    assert counts == (1, 1)
    doc2.save(accepted_path)

    doc3 = offidized.Document.open(accepted_path)
    assert doc3.revisions() == []
    assert any("Alpha Beta" in p.text() for p in doc3.paragraphs())


def _inject_supported_part_revisions(path):
    _rewrite_docx_document_xml(
        path,
        lambda xml: xml.replace(
            """<w:r>\n        <w:t>Body</w:t>\n      </w:r>""",
            """<w:r>\n        <w:t>Body</w:t>\n      </w:r>\n      <w:ins w:id=\"1\" w:author=\"Reviewer\">\n        <w:r>\n          <w:t xml:space=\"preserve\"> Added</w:t>\n        </w:r>\n      </w:ins>""",
            1,
        ),
    )
    _rewrite_docx_part_xml(
        path,
        "word/header1.xml",
        lambda xml: xml.replace(
            """<w:r>\n      <w:t>Header</w:t>\n    </w:r>""",
            """<w:r>\n      <w:t>Header</w:t>\n    </w:r>\n    <w:ins w:id=\"2\" w:author=\"Reviewer\">\n      <w:r>\n        <w:t xml:space=\"preserve\"> Added</w:t>\n      </w:r>\n    </w:ins>""",
            1,
        ),
    )
    _rewrite_docx_part_xml(
        path,
        "word/footer1.xml",
        lambda xml: xml.replace(
            """<w:r>\n      <w:t>Footer Keep</w:t>\n    </w:r>""",
            """<w:r>\n      <w:t>Footer Keep</w:t>\n    </w:r>\n    <w:del w:id=\"3\" w:author=\"Reviewer\">\n      <w:r>\n        <w:delText xml:space=\"preserve\"> Remove</w:delText>\n      </w:r>\n    </w:del>""",
            1,
        ),
    )
    _rewrite_docx_part_xml(
        path,
        "word/footnotes.xml",
        lambda xml: xml.replace(
            """<w:r>\n        <w:t>Footnote</w:t>\n      </w:r>""",
            """<w:r>\n        <w:t>Footnote</w:t>\n      </w:r>\n      <w:ins w:id=\"4\" w:author=\"Reviewer\">\n        <w:r>\n          <w:t xml:space=\"preserve\"> Added</w:t>\n        </w:r>\n      </w:ins>""",
            1,
        ),
    )
    _rewrite_docx_part_xml(
        path,
        "word/endnotes.xml",
        lambda xml: xml.replace(
            """<w:r>\n        <w:t>Endnote Keep</w:t>\n      </w:r>""",
            """<w:r>\n        <w:t>Endnote Keep</w:t>\n      </w:r>\n      <w:del w:id=\"5\" w:author=\"Reviewer\">\n        <w:r>\n          <w:delText xml:space=\"preserve\"> Remove</w:delText>\n        </w:r>\n      </w:del>""",
            1,
        ),
    )


def test_docx_revisions_include_supported_non_body_parts(tmp_path):
    path = str(tmp_path / "tracked-supported-parts.docx")

    doc = offidized.Document()
    doc.add_paragraph("Body")
    section = doc.section()
    section.set_header_text("Header")
    section.set_footer_text("Footer Keep")
    doc.add_footnote(7, "Footnote")
    doc.add_endnote(9, "Endnote Keep")
    doc.save(path)

    _inject_supported_part_revisions(path)

    reopened = offidized.Document.open(path)
    revisions = reopened.revisions()
    assert len(revisions) == 5
    assert any(revision[5] == "body/paragraph:0" and revision[4] == " Added" for revision in revisions)
    assert any(revision[5] == "header/default/paragraph:0" and revision[4] == " Added" for revision in revisions)
    assert any(revision[5] == "footer/default/paragraph:0" and revision[4] == " Remove" for revision in revisions)
    assert any(revision[5] == "footnote:7/paragraph:0" and revision[4] == " Added" for revision in revisions)
    assert any(revision[5] == "endnote:9/paragraph:0" and revision[4] == " Remove" for revision in revisions)


def test_docx_accept_reject_revisions_reach_supported_non_body_parts(tmp_path):
    path = str(tmp_path / "tracked-supported-parts.docx")
    accepted_path = str(tmp_path / "tracked-supported-parts-accepted.docx")
    rejected_path = str(tmp_path / "tracked-supported-parts-rejected.docx")

    doc = offidized.Document()
    doc.add_paragraph("Body")
    section = doc.section()
    section.set_header_text("Header")
    section.set_footer_text("Footer Keep")
    doc.add_footnote(7, "Footnote")
    doc.add_endnote(9, "Endnote Keep")
    doc.save(path)

    _inject_supported_part_revisions(path)

    accepted = offidized.Document.open(path)
    assert accepted.accept_revisions() == (3, 2)
    accepted.save(accepted_path)

    accepted_reopened = offidized.Document.open(accepted_path)
    assert accepted_reopened.revisions() == []
    assert any("Body Added" in p.text() for p in accepted_reopened.paragraphs())
    assert accepted_reopened.section().header_text() == "Header Added"
    assert accepted_reopened.section().footer_text() == "Footer Keep"
    assert accepted_reopened.footnotes() == [(7, "Footnote Added")]
    assert accepted_reopened.endnotes() == [(9, "Endnote Keep")]

    rejected = offidized.Document.open(path)
    assert rejected.reject_revisions() == (3, 2)
    rejected.save(rejected_path)

    rejected_reopened = offidized.Document.open(rejected_path)
    assert rejected_reopened.revisions() == []
    assert any(p.text() == "Body" for p in rejected_reopened.paragraphs())
    assert rejected_reopened.section().header_text() == "Header"
    assert rejected_reopened.section().footer_text() == "Footer Keep Remove"
    assert rejected_reopened.footnotes() == [(7, "Footnote")]
    assert rejected_reopened.endnotes() == [(9, "Endnote Keep Remove")]


def _inject_supported_table_revisions(path):
    _rewrite_docx_document_xml(
        path,
        lambda xml: xml.replace(
            """<w:r>
              <w:t>BodyCell</w:t>
            </w:r>""",
            """<w:r>
              <w:t>BodyCell</w:t>
            </w:r><w:ins w:id="21" w:author="Reviewer"><w:r><w:t xml:space="preserve"> Added</w:t></w:r></w:ins>""",
            1,
        ),
    )
    _rewrite_docx_part_xml(
        path,
        "word/header1.xml",
        lambda xml: xml.replace(
            """<w:r>
            <w:t>HeaderCell Keep</w:t>
          </w:r>""",
            """<w:r>
            <w:t>HeaderCell Keep</w:t>
          </w:r><w:del w:id="22" w:author="Reviewer"><w:r><w:delText xml:space="preserve"> Drop</w:delText></w:r></w:del>""",
            1,
        ),
    )


def test_docx_revisions_include_property_change_revisions_across_supported_parts(tmp_path):
    path = str(tmp_path / "property-revisions.docx")

    doc = offidized.Document()
    doc.add_paragraph("BodyBase")
    doc.section().set_header_text("HeaderBase")
    doc.add_footnote(1, "placeholder")
    doc.save(path)
    _rewrite_docx_document_xml(
        path,
        lambda xml: xml.replace(
            "<w:p>\n      <w:r>\n        <w:t>BodyBase</w:t>\n      </w:r>\n    </w:p>",
            "<w:p><w:pPr><w:pPrChange w:id=\"61\" w:author=\"Reviewer\"><w:pPr><w:jc w:val=\"center\"/></w:pPr></w:pPrChange></w:pPr><w:r><w:t>BodyBase</w:t></w:r></w:p>",
        ),
    )
    _rewrite_docx_part_xml(
        path,
        "word/header1.xml",
        lambda xml: xml.replace(
            "<w:r>\n      <w:t>HeaderBase</w:t>\n    </w:r>",
            "<w:r><w:rPr><w:rPrChange w:id=\"62\" w:author=\"Reviewer\"><w:rPr><w:b/></w:rPr></w:rPrChange></w:rPr><w:t>HeaderBase</w:t></w:r>",
        ),
    )
    _rewrite_docx_part_xml(
        path,
        "word/footnotes.xml",
        lambda xml: xml.replace(
            """<w:p>
      <w:r>
        <w:t>placeholder</w:t>
      </w:r>
    </w:p>""",
            """<w:tbl>
      <w:tblPr/>
      <w:tblGrid>
        <w:gridCol w:w="4320"/>
      </w:tblGrid>
      <w:tr>
        <w:tc><w:tcPr><w:tcPrChange w:id="63" w:author="Reviewer"><w:tcPr><w:shd w:fill="FFFF00"/></w:tcPr></w:tcPrChange></w:tcPr><w:p><w:r><w:t>CellBase</w:t></w:r></w:p></w:tc>
      </w:tr>
    </w:tbl>""",
        ),
    )

    reopened = offidized.Document.open(path)
    revisions = reopened.revisions()
    assert any(
        revision[5] == "body/paragraph:0"
        and revision[1] == "property_change"
        and revision[4] == "pPrChange"
        for revision in revisions
    )
    assert any(
        revision[5] == "header/default/paragraph:0"
        and revision[1] == "property_change"
        and revision[4] == "rPrChange"
        for revision in revisions
    )
    assert any(
        revision[5] == "footnote:1/table:0/cell:0,0"
        and revision[1] == "property_change"
        and revision[4] == "tcPrChange"
        for revision in revisions
    )



def test_docx_accept_reject_property_change_revisions_across_supported_parts(tmp_path):
    path = str(tmp_path / "property-revisions-transform.docx")
    accept_path = str(tmp_path / "property-revisions-accepted.docx")
    reject_path = str(tmp_path / "property-revisions-rejected.docx")

    doc = offidized.Document()
    doc.add_paragraph("BodyBase")
    doc.section().set_header_text("HeaderBase")
    doc.add_footnote(1, "placeholder")
    doc.save(path)

    _rewrite_docx_document_xml(
        path,
        lambda xml: xml.replace(
            """<w:p>
      <w:r>
        <w:t>BodyBase</w:t>
      </w:r>
    </w:p>""",
            """<w:p><w:pPr><w:jc w:val="right"/><w:pPrChange w:id="81" w:author="Reviewer"><w:pPr><w:jc w:val="center"/></w:pPr></w:pPrChange></w:pPr><w:r><w:t>BodyBase</w:t></w:r></w:p>""",
        ),
    )
    _rewrite_docx_part_xml(
        path,
        "word/header1.xml",
        lambda xml: xml.replace(
            "<w:r>\n      <w:t>HeaderBase</w:t>\n    </w:r>",
            "<w:r><w:rPr><w:b/><w:rPrChange w:id=\"82\" w:author=\"Reviewer\"><w:rPr><w:i/></w:rPr></w:rPrChange></w:rPr><w:t>HeaderBase</w:t></w:r>",
        ),
    )
    _rewrite_docx_part_xml(
        path,
        "word/footnotes.xml",
        lambda xml: xml.replace(
            """<w:p>
      <w:r>
        <w:t>placeholder</w:t>
      </w:r>
    </w:p>""",
            """<w:tbl><w:tblPr/><w:tblGrid><w:gridCol w:w="4320"/></w:tblGrid><w:tr><w:tc><w:tcPr><w:shd w:val="clear" w:color="auto" w:fill="FF0000"/><w:tcPrChange w:id="83" w:author="Reviewer"><w:tcPr><w:shd w:val="clear" w:color="auto" w:fill="FFFF00"/></w:tcPr></w:tcPrChange></w:tcPr><w:p><w:r><w:t>CellBase</w:t></w:r></w:p></w:tc></w:tr></w:tbl>""",
        ),
    )

    accepted = offidized.Document.open(path)
    report = accepted.accept_revisions(kinds=["property_change"])
    assert report == (0, 0)
    accepted.save(accept_path)
    with zipfile.ZipFile(accept_path, "r") as package:
        document_xml = package.read("word/document.xml").decode("utf-8")
        header_xml = package.read("word/header1.xml").decode("utf-8")
        footnotes_xml = package.read("word/footnotes.xml").decode("utf-8")
    assert 'w:jc w:val="right"' in document_xml
    assert "pPrChange" not in document_xml
    assert "<w:b/>" in header_xml
    assert "rPrChange" not in header_xml
    assert 'w:fill="FF0000"' in footnotes_xml
    assert "tcPrChange" not in footnotes_xml

    rejected = offidized.Document.open(path)
    report = rejected.reject_revisions(kinds=["property_change"])
    assert report == (0, 0)
    rejected.save(reject_path)
    with zipfile.ZipFile(reject_path, "r") as package:
        document_xml = package.read("word/document.xml").decode("utf-8")
        header_xml = package.read("word/header1.xml").decode("utf-8")
        footnotes_xml = package.read("word/footnotes.xml").decode("utf-8")
    assert 'w:jc w:val="center"' in document_xml
    assert 'w:jc w:val="right"' not in document_xml
    assert "pPrChange" not in document_xml
    assert "<w:i/>" in header_xml
    assert "<w:b/>" not in header_xml
    assert "rPrChange" not in header_xml
    assert 'w:fill="FFFF00"' in footnotes_xml
    assert 'w:fill="FF0000"' not in footnotes_xml
    assert "tcPrChange" not in footnotes_xml



def test_docx_move_revisions_are_reported_and_transformed_across_supported_parts(tmp_path):
    path = str(tmp_path / "move-revisions.docx")
    accept_path = str(tmp_path / "move-revisions-accepted.docx")
    reject_path = str(tmp_path / "move-revisions-rejected.docx")

    doc = offidized.Document()
    doc.add_paragraph("BodyBase")
    doc.section().set_header_text("HeaderBase")
    doc.add_footnote(1, "placeholder")
    doc.save(path)

    _rewrite_docx_document_xml(
        path,
        lambda xml: xml.replace(
            "<w:r>\n        <w:t>BodyBase</w:t>\n      </w:r>",
            "<w:r><w:t>BodyBase</w:t></w:r><w:moveFrom w:id=\"71\" w:author=\"Reviewer\"><w:r><w:t xml:space=\"preserve\"> Old</w:t></w:r></w:moveFrom><w:moveTo w:id=\"72\" w:author=\"Reviewer\"><w:r><w:t xml:space=\"preserve\"> New</w:t></w:r></w:moveTo>",
        ),
    )
    _rewrite_docx_part_xml(
        path,
        "word/header1.xml",
        lambda xml: xml.replace(
            "<w:r>\n      <w:t>HeaderBase</w:t>\n    </w:r>",
            "<w:r><w:t>HeaderBase</w:t></w:r><w:moveFrom w:id=\"73\" w:author=\"Reviewer\"><w:r><w:t xml:space=\"preserve\"> Gone</w:t></w:r></w:moveFrom><w:moveTo w:id=\"74\" w:author=\"Reviewer\"><w:r><w:t xml:space=\"preserve\"> Here</w:t></w:r></w:moveTo>",
        ),
    )
    _rewrite_docx_part_xml(
        path,
        "word/footnotes.xml",
        lambda xml: xml.replace(
            """<w:p>
      <w:r>
        <w:t>placeholder</w:t>
      </w:r>
    </w:p>""",
            """<w:tbl><w:tblPr/><w:tblGrid><w:gridCol w:w="4320"/></w:tblGrid><w:tr><w:tc><w:p><w:r><w:t>CellBase</w:t></w:r><w:moveFrom w:id="75" w:author="Reviewer"><w:r><w:t xml:space="preserve"> Away</w:t></w:r></w:moveFrom><w:moveTo w:id="76" w:author="Reviewer"><w:r><w:t xml:space="preserve"> Back</w:t></w:r></w:moveTo></w:p></w:tc></w:tr></w:tbl>""",
        ),
    )

    reopened = offidized.Document.open(path)
    revisions = reopened.revisions()
    assert any(
        revision[5] == "body/paragraph:0"
        and revision[1] == "move_from"
        and revision[4] == " Old"
        for revision in revisions
    )
    assert any(
        revision[5] == "body/paragraph:0"
        and revision[1] == "move_to"
        and revision[4] == " New"
        for revision in revisions
    )
    assert any(
        revision[5] == "header/default/paragraph:0"
        and revision[1] == "move_from"
        and revision[4] == " Gone"
        for revision in revisions
    )
    assert any(
        revision[5] == "footnote:1/table:0/cell:0,0/paragraph:0"
        and revision[1] == "move_to"
        and revision[4] == " Back"
        for revision in revisions
    )

    accepted = offidized.Document.open(path)
    report = accepted.accept_revisions()
    assert report == (3, 3)
    accepted.save(accept_path)
    with zipfile.ZipFile(accept_path, "r") as package:
        document_xml = package.read("word/document.xml").decode("utf-8")
        header_xml = package.read("word/header1.xml").decode("utf-8")
        footnotes_xml = package.read("word/footnotes.xml").decode("utf-8")
    assert " New" in document_xml
    assert " Old" not in document_xml
    assert " Here" in header_xml
    assert " Gone" not in header_xml
    assert " Back" in footnotes_xml
    assert " Away" not in footnotes_xml

    rejected = offidized.Document.open(path)
    report = rejected.reject_revisions()
    assert report == (3, 3)
    rejected.save(reject_path)
    with zipfile.ZipFile(reject_path, "r") as package:
        document_xml = package.read("word/document.xml").decode("utf-8")
        header_xml = package.read("word/header1.xml").decode("utf-8")
        footnotes_xml = package.read("word/footnotes.xml").decode("utf-8")
    assert " Old" in document_xml
    assert " New" not in document_xml
    assert " Gone" in header_xml
    assert " Here" not in header_xml
    assert " Away" in footnotes_xml
    assert " Back" not in footnotes_xml



def test_docx_tbl_grid_change_revisions_are_reported_and_transformed(tmp_path):
    path = str(tmp_path / "tbl-grid-change.docx")
    accept_path = str(tmp_path / "tbl-grid-change-accepted.docx")
    reject_path = str(tmp_path / "tbl-grid-change-rejected.docx")

    doc = offidized.Document()
    table = doc.add_table(1, 2)
    table.set_column_widths_twips([2400, 3600])
    table.cell(0, 0).set_text("Left")
    table.cell(0, 1).set_text("Right")
    doc.save(path)

    _rewrite_docx_document_xml(
        path,
        lambda xml: xml.replace(
            """<w:tblGrid>
        <w:gridCol w:w="2400"/>
        <w:gridCol w:w="3600"/>
      </w:tblGrid>""",
            '<w:tblGrid><w:gridCol w:w="2400"/><w:gridCol w:w="3600"/><w:tblGridChange w:id="101" w:author="Reviewer"><w:tblGrid><w:gridCol w:w="1800"/><w:gridCol w:w="4200"/></w:tblGrid></w:tblGridChange></w:tblGrid>',
        ),
    )

    reopened = offidized.Document.open(path)
    revisions = reopened.revisions()
    assert any(
        revision[5] == "body/table:0"
        and revision[1] == "property_change"
        and revision[4] == "tblGridChange"
        for revision in revisions
    )

    accepted = offidized.Document.open(path)
    report = accepted.accept_revisions(kinds=["property_change"])
    assert report == (0, 0)
    accepted.save(accept_path)
    with zipfile.ZipFile(accept_path, "r") as package:
        document_xml = package.read("word/document.xml").decode("utf-8")
    assert "tblGridChange" not in document_xml
    reopened_accepted = offidized.Document.open(accept_path)
    assert reopened_accepted.table(0).column_widths_twips() == [2400, 3600]

    rejected = offidized.Document.open(path)
    report = rejected.reject_revisions(kinds=["property_change"])
    assert report == (0, 0)
    rejected.save(reject_path)
    with zipfile.ZipFile(reject_path, "r") as package:
        document_xml = package.read("word/document.xml").decode("utf-8")
    assert "tblGridChange" not in document_xml
    reopened_rejected = offidized.Document.open(reject_path)
    assert reopened_rejected.table(0).column_widths_twips() == [1800, 4200]



def test_docx_move_range_markers_are_listed_and_removed_by_accept_reject(tmp_path):
    path = str(tmp_path / "move-range-markers.docx")
    accept_path = str(tmp_path / "move-range-markers-accepted.docx")
    reject_path = str(tmp_path / "move-range-markers-rejected.docx")

    doc = offidized.Document()
    doc.add_paragraph("BodyBase")
    doc.section().set_header_text("HeaderBase")
    doc.save(path)

    _rewrite_docx_document_xml(
        path,
        lambda xml: xml.replace(
            "<w:r>\n        <w:t>BodyBase</w:t>\n      </w:r>",
            "<w:moveFromRangeStart w:id=\"91\"/><w:r><w:t>BodyBase</w:t></w:r><w:moveFromRangeEnd w:id=\"91\"/>",
        ),
    )
    _rewrite_docx_part_xml(
        path,
        "word/header1.xml",
        lambda xml: xml.replace(
            "<w:r>\n      <w:t>HeaderBase</w:t>\n    </w:r>",
            "<w:moveToRangeStart w:id=\"92\"/><w:r><w:t>HeaderBase</w:t></w:r><w:moveToRangeEnd w:id=\"92\"/>",
        ),
    )

    reopened = offidized.Document.open(path)
    revisions = reopened.revisions()
    assert any(
        revision[5] == "body/paragraph:0"
        and revision[1] == "move_from"
        and revision[4] == "moveFromRangeStart"
        for revision in revisions
    )
    assert any(
        revision[5] == "header/default/paragraph:0"
        and revision[1] == "move_to"
        and revision[4] == "moveToRangeEnd"
        for revision in revisions
    )

    accepted = offidized.Document.open(path)
    report = accepted.accept_revisions(kinds=["move_from", "move_to"])
    assert report == (0, 0)
    accepted.save(accept_path)
    with zipfile.ZipFile(accept_path, "r") as package:
        document_xml = package.read("word/document.xml").decode("utf-8")
        header_xml = package.read("word/header1.xml").decode("utf-8")
    assert "moveFromRangeStart" not in document_xml
    assert "moveFromRangeEnd" not in document_xml
    assert "moveToRangeStart" not in header_xml
    assert "moveToRangeEnd" not in header_xml

    rejected = offidized.Document.open(path)
    report = rejected.reject_revisions(kinds=["move_from", "move_to"])
    assert report == (0, 0)
    rejected.save(reject_path)
    with zipfile.ZipFile(reject_path, "r") as package:
        document_xml = package.read("word/document.xml").decode("utf-8")
        header_xml = package.read("word/header1.xml").decode("utf-8")
    assert "moveFromRangeStart" not in document_xml
    assert "moveFromRangeEnd" not in document_xml
    assert "moveToRangeStart" not in header_xml
    assert "moveToRangeEnd" not in header_xml



def test_docx_revisions_include_table_cell_paragraphs(tmp_path):
    path = str(tmp_path / "tracked-table-parts.docx")

    doc = offidized.Document()
    table = doc.add_table(1, 1)
    table.set_cell_text(0, 0, "BodyCell")
    header = doc.section()
    # Re-fetch mutable section wrapper for header content creation.
    header.set_header_text("placeholder")
    doc.save(path)
    # Replace placeholder header content with a table-bearing header document.
    _rewrite_docx_part_xml(
        path,
        "word/header1.xml",
        lambda xml: xml.replace(
            """<w:p>\n    <w:r>\n      <w:t>placeholder</w:t>\n    </w:r>\n  </w:p>""",
            """<w:tbl>\n    <w:tblPr/>\n    <w:tblGrid>\n      <w:gridCol w:w=\"4320\"/>\n    </w:tblGrid>\n    <w:tr>\n      <w:tc>\n        <w:p>\n          <w:r>\n            <w:t>HeaderCell Keep</w:t>\n          </w:r>\n        </w:p>\n      </w:tc>\n    </w:tr>\n  </w:tbl>""",
            1,
        ),
    )
    _inject_supported_table_revisions(path)

    reopened = offidized.Document.open(path)
    revisions = reopened.revisions()
    assert any(revision[5] == "body/table:0/cell:0,0/paragraph:0" and revision[4] == " Added" for revision in revisions)
    assert any(revision[5] == "header/default/table:0/cell:0,0/paragraph:0" and revision[4] == " Drop" for revision in revisions)


def test_docx_accept_reject_revisions_reach_supported_table_cells(tmp_path):
    path = str(tmp_path / "tracked-table-parts.docx")
    accepted_path = str(tmp_path / "tracked-table-parts-accepted.docx")
    rejected_path = str(tmp_path / "tracked-table-parts-rejected.docx")

    doc = offidized.Document()
    table = doc.add_table(1, 1)
    table.set_cell_text(0, 0, "BodyCell")
    header = doc.section()
    header.set_header_text("placeholder")
    doc.save(path)
    _rewrite_docx_part_xml(
        path,
        "word/header1.xml",
        lambda xml: xml.replace(
            """<w:p>\n    <w:r>\n      <w:t>placeholder</w:t>\n    </w:r>\n  </w:p>""",
            """<w:tbl>\n    <w:tblPr/>\n    <w:tblGrid>\n      <w:gridCol w:w=\"4320\"/>\n    </w:tblGrid>\n    <w:tr>\n      <w:tc>\n        <w:p>\n          <w:r>\n            <w:t>HeaderCell Keep</w:t>\n          </w:r>\n        </w:p>\n      </w:tc>\n    </w:tr>\n  </w:tbl>""",
            1,
        ),
    )
    _inject_supported_table_revisions(path)

    accepted = offidized.Document.open(path)
    assert accepted.accept_revisions() == (1, 1)
    accepted.save(accepted_path)
    accepted_reopened = offidized.Document.open(accepted_path)
    assert accepted_reopened.revisions() == []
    assert accepted_reopened.table(0).cell(0, 0).text() == "BodyCell Added"
    with zipfile.ZipFile(accepted_path, "r") as package:
        header_xml = package.read("word/header1.xml").decode("utf-8")
    assert "HeaderCell Keep" in header_xml
    assert "Drop" not in header_xml

    rejected = offidized.Document.open(path)
    assert rejected.reject_revisions() == (1, 1)
    rejected.save(rejected_path)
    rejected_reopened = offidized.Document.open(rejected_path)
    assert rejected_reopened.revisions() == []
    assert rejected_reopened.table(0).cell(0, 0).text() == "BodyCell"
    with zipfile.ZipFile(rejected_path, "r") as package:
        header_xml = package.read("word/header1.xml").decode("utf-8")
    assert "HeaderCell Keep" in header_xml
    assert " Drop" in header_xml
    assert "w:del" not in header_xml


def _inject_note_table_revisions(path):
    _rewrite_docx_part_xml(
        path,
        "word/footnotes.xml",
        lambda xml: xml.replace(
            "</w:r>\n          </w:p>",
            "</w:r><w:ins w:id=\"31\" w:author=\"Reviewer\"><w:r><w:t xml:space=\"preserve\"> Added</w:t></w:r></w:ins>\n          </w:p>",
            1,
        ),
    )
    _rewrite_docx_part_xml(
        path,
        "word/endnotes.xml",
        lambda xml: xml.replace(
            "</w:r>\n          </w:p>",
            "</w:r><w:del w:id=\"32\" w:author=\"Reviewer\"><w:r><w:delText xml:space=\"preserve\"> Drop</w:delText></w:r></w:del>\n          </w:p>",
            1,
        ),
    )


def test_docx_revisions_include_footnote_endnote_table_cell_paragraphs(tmp_path):
    path = str(tmp_path / "tracked-note-table-parts.docx")

    doc = offidized.Document()
    doc.add_footnote(7, "FootCell")
    doc.add_endnote(9, "EndCell Keep")
    doc.save(path)

    _rewrite_docx_part_xml(
        path,
        "word/footnotes.xml",
        lambda xml: xml.replace(
            """<w:p>
      <w:r>
        <w:t>FootCell</w:t>
      </w:r>
    </w:p>""",
            """<w:tbl>
      <w:tblPr/>
      <w:tblGrid>
        <w:gridCol w:w="4320"/>
      </w:tblGrid>
      <w:tr>
        <w:tc>
          <w:p>
            <w:r>
              <w:t>FootCell</w:t>
            </w:r>
          </w:p>
        </w:tc>
      </w:tr>
    </w:tbl>""",
            1,
        ),
    )
    _rewrite_docx_part_xml(
        path,
        "word/endnotes.xml",
        lambda xml: xml.replace(
            """<w:p>
      <w:r>
        <w:t>EndCell Keep</w:t>
      </w:r>
    </w:p>""",
            """<w:tbl>
      <w:tblPr/>
      <w:tblGrid>
        <w:gridCol w:w="4320"/>
      </w:tblGrid>
      <w:tr>
        <w:tc>
          <w:p>
            <w:r>
              <w:t>EndCell Keep</w:t>
            </w:r>
          </w:p>
        </w:tc>
      </w:tr>
    </w:tbl>""",
            1,
        ),
    )
    _inject_note_table_revisions(path)

    reopened = offidized.Document.open(path)
    revisions = reopened.revisions()
    assert any(revision[5] == "footnote:7/table:0/cell:0,0/paragraph:0" and revision[4] == " Added" for revision in revisions)
    assert any(revision[5] == "endnote:9/table:0/cell:0,0/paragraph:0" and revision[4] == " Drop" for revision in revisions)


def test_docx_accept_reject_revisions_reach_footnote_endnote_table_cells(tmp_path):
    path = str(tmp_path / "tracked-note-table-parts.docx")
    accepted_path = str(tmp_path / "tracked-note-table-parts-accepted.docx")
    rejected_path = str(tmp_path / "tracked-note-table-parts-rejected.docx")

    doc = offidized.Document()
    doc.add_footnote(7, "FootCell")
    doc.add_endnote(9, "EndCell Keep")
    doc.save(path)

    _rewrite_docx_part_xml(
        path,
        "word/footnotes.xml",
        lambda xml: xml.replace(
            """<w:p>
      <w:r>
        <w:t>FootCell</w:t>
      </w:r>
    </w:p>""",
            """<w:tbl>
      <w:tblPr/>
      <w:tblGrid>
        <w:gridCol w:w="4320"/>
      </w:tblGrid>
      <w:tr>
        <w:tc>
          <w:p>
            <w:r>
              <w:t>FootCell</w:t>
            </w:r>
          </w:p>
        </w:tc>
      </w:tr>
    </w:tbl>""",
            1,
        ),
    )
    _rewrite_docx_part_xml(
        path,
        "word/endnotes.xml",
        lambda xml: xml.replace(
            """<w:p>
      <w:r>
        <w:t>EndCell Keep</w:t>
      </w:r>
    </w:p>""",
            """<w:tbl>
      <w:tblPr/>
      <w:tblGrid>
        <w:gridCol w:w="4320"/>
      </w:tblGrid>
      <w:tr>
        <w:tc>
          <w:p>
            <w:r>
              <w:t>EndCell Keep</w:t>
            </w:r>
          </w:p>
        </w:tc>
      </w:tr>
    </w:tbl>""",
            1,
        ),
    )
    _inject_note_table_revisions(path)

    accepted = offidized.Document.open(path)
    assert accepted.accept_revisions() == (1, 1)
    accepted.save(accepted_path)
    accepted_reopened = offidized.Document.open(accepted_path)
    assert accepted_reopened.revisions() == []
    assert accepted_reopened.footnotes() == [(7, "FootCell Added")]
    assert accepted_reopened.endnotes() == [(9, "EndCell Keep")]

    rejected = offidized.Document.open(path)
    assert rejected.reject_revisions() == (1, 1)
    rejected.save(rejected_path)
    rejected_reopened = offidized.Document.open(rejected_path)
    assert rejected_reopened.revisions() == []
    assert rejected_reopened.footnotes() == [(7, "FootCell")]
    assert rejected_reopened.endnotes() == [(9, "EndCell Keep Drop")]


def test_docx_add_comment_to_paragraph(tmp_path):
    path = str(tmp_path / "commented.docx")

    doc = offidized.Document()
    para = doc.add_paragraph("Needs review")
    comment_id = para.add_comment(
        "Reviewer",
        "Clarify this promise.",
        "2026-03-24T13:00:00Z",
    )
    assert comment_id == 0
    doc.save(path)

    reopened = offidized.Document.open(path)
    comments = reopened.comments()
    assert len(comments) == 1
    assert comments[0][0] == 0
    assert comments[0][1] == "Reviewer"
    assert comments[0][2] == "Clarify this promise."


def test_docx_add_comment_range_to_paragraph(tmp_path):
    path = str(tmp_path / "commented-range.docx")

    doc = offidized.Document()
    para = doc.add_paragraph("Alpha Beta Gamma")
    comment_id = para.add_comment_range(
        6,
        10,
        "Reviewer",
        "Look at Beta only.",
        "2026-03-24T14:00:00Z",
    )
    assert comment_id == 0
    doc.save(path)

    reopened = offidized.Document.open(path)
    comments = reopened.comments()
    assert len(comments) == 1
    assert comments[0][2] == "Look at Beta only."
    assert reopened.paragraph(0).text() == "Alpha Beta Gamma"


def test_docx_review_text_simple_api(tmp_path):
    path = str(tmp_path / "reviewed-text.docx")

    doc = offidized.Document()
    para = doc.add_paragraph("Alpha Beta Gamma")
    comment_id = para.review_text(
        "Beta",
        "Reviewer",
        "Check this word.",
        "yellow",
        "2026-03-24T15:00:00Z",
    )
    assert comment_id == 0
    doc.save(path)

    reopened = offidized.Document.open(path)
    comments = reopened.comments()
    assert len(comments) == 1
    assert comments[0][2] == "Check this word."
    runs = reopened.paragraph(0).runs()
    assert any(run.text() == "Beta" and run.highlight_color() == "yellow" for run in runs)


def test_docx_document_review_text_simple_api(tmp_path):
    path = str(tmp_path / "reviewed-document-text.docx")

    doc = offidized.Document()
    doc.add_paragraph("Intro")
    doc.add_paragraph("Please review Beta here.")
    doc.add_paragraph("Beta appears later too.")
    comment_id = doc.review_text(
        "Beta",
        "Reviewer",
        "Check the first Beta.",
        "yellow",
        "2026-03-24T16:00:00Z",
    )
    assert comment_id == 0
    doc.save(path)

    reopened = offidized.Document.open(path)
    comments = reopened.comments()
    assert len(comments) == 1
    assert comments[0][2] == "Check the first Beta."
    second_runs = reopened.paragraph(1).runs()
    third_runs = reopened.paragraph(2).runs()
    assert any(run.text() == "Beta" and run.highlight_color() == "yellow" for run in second_runs)
    assert not any(run.text() == "Beta" and run.highlight_color() == "yellow" for run in third_runs)


def test_docx_apply_reviews_batch_helper(tmp_path):
    path = str(tmp_path / "reviewed-batch.docx")

    doc = offidized.Document()
    doc.add_paragraph("Please review Beta here.")
    doc.add_paragraph("Whole paragraph")
    comment_ids = doc.apply_reviews(
        [
            {"text": "Beta"},
            {"paragraph": 1, "comment": "Paragraph review.", "highlight": "cyan"},
        ],
        author="Reviewer",
        comment="Default review.",
        highlight_color="yellow",
        date="2026-03-24T16:05:00Z",
        comments_only_protection=True,
    )
    assert comment_ids == [0, 1]
    doc.save(path)

    reopened = offidized.Document.open(path)
    comments = reopened.comments()
    assert len(comments) == 2
    assert comments[0][2] == "Default review."
    assert comments[1][2] == "Paragraph review."
    first_runs = reopened.paragraph(0).runs()
    second_runs = reopened.paragraph(1).runs()
    assert any(run.text() == "Beta" and run.highlight_color() == "yellow" for run in first_runs)
    assert any(
        run.text() == "Whole paragraph" and run.highlight_color() == "cyan"
        for run in second_runs
    )
    assert reopened.protection() == ("comments", True)


def test_docx_review_text_with_existing_comments_and_fields(tmp_path):
    path = str(tmp_path / "reviewed-existing-comments-fields.docx")

    doc = offidized.Document()
    doc.add_paragraph("Alpha Beta Gamma")
    doc.add_comment_to_paragraph_text(
        0,
        "Alpha",
        "Reviewer",
        "Existing note.",
        "2026-03-24T16:10:00Z",
    )
    doc.save(path)

    _rewrite_docx_document_xml(
        path,
        lambda xml: xml.replace(
            "<w:r><w:t>Beta</w:t></w:r>",
            "<w:r><w:fldChar w:fldCharType=\"begin\"/><w:instrText>PAGE</w:instrText><w:fldChar w:fldCharType=\"separate\"/><w:t>Beta</w:t><w:fldChar w:fldCharType=\"end\"/></w:r>",
            1,
        ),
    )

    reopened = offidized.Document.open(path)
    comment_id = reopened.review_text(
        "Beta",
        "Reviewer",
        "Field result review.",
        "yellow",
        "2026-03-24T16:15:00Z",
    )
    assert comment_id == 1
    reopened.save(path)

    reopened_again = offidized.Document.open(path)
    comments = reopened_again.comments()
    assert len(comments) == 2
    runs = reopened_again.paragraph(0).runs()
    assert any(run.highlight_color() == "yellow" for run in runs)


def test_docx_review_text_matches_simple_vml_text_box_content(tmp_path):
    path = str(tmp_path / "reviewed-textbox.docx")

    doc = offidized.Document()
    doc.add_paragraph("placeholder")
    doc.save(path)

    _rewrite_docx_document_xml(
        path,
        lambda xml: xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:pict xmlns:v=\"urn:schemas-microsoft-com:vml\"><v:shape id=\"TextBox1\"><v:textbox><w:txbxContent><w:p><w:r><w:t>Textbox Beta</w:t></w:r></w:p></w:txbxContent></v:textbox></v:shape></w:pict></w:r>",
        ),
    )

    reviewed = offidized.Document.open(path)
    comment_id = reviewed.review_text(
        "Beta",
        "Reviewer",
        "Review textbox content.",
        "yellow",
        "2026-03-24T20:20:00Z",
    )
    assert comment_id == 0
    reviewed.save(path)

    reopened = offidized.Document.open(path)
    assert len(reopened.comments()) == 1
    with zipfile.ZipFile(path, "r") as package:
        document_xml = package.read("word/document.xml").decode("utf-8")
    assert "w:txbxContent" in document_xml
    assert 'w:commentRangeStart w:id="0"' in document_xml
    assert 'w:commentRangeEnd w:id="0"' in document_xml
    assert 'w:commentReference w:id="0"' in document_xml
    assert 'w:highlight w:val="yellow"' in document_xml



def test_docx_review_text_matches_simple_drawingml_text_box_content(tmp_path):
    path = str(tmp_path / "reviewed-drawing-textbox.docx")

    doc = offidized.Document()
    doc.add_paragraph("placeholder")
    doc.save(path)

    _rewrite_docx_document_xml(
        path,
        lambda xml: xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Drawing Beta</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        ),
    )

    reviewed = offidized.Document.open(path)
    comment_id = reviewed.review_text(
        "Beta",
        "Reviewer",
        "Review drawing textbox content.",
        "yellow",
        "2026-03-24T20:25:00Z",
    )
    assert comment_id == 0
    reviewed.save(path)

    reopened = offidized.Document.open(path)
    assert len(reopened.comments()) == 1
    with zipfile.ZipFile(path, "r") as package:
        document_xml = package.read("word/document.xml").decode("utf-8")
    assert "<w:drawing>" in document_xml
    assert "w:txbxContent" in document_xml
    assert 'w:commentRangeStart w:id="0"' in document_xml
    assert 'w:commentRangeEnd w:id="0"' in document_xml
    assert 'w:commentReference w:id="0"' in document_xml
    assert 'w:highlight w:val="yellow"' in document_xml



def test_docx_revisions_include_and_transform_drawing_text_box_content(tmp_path):
    path = str(tmp_path / "drawing-textbox-revisions.docx")
    accept_path = str(tmp_path / "drawing-textbox-revisions-accepted.docx")
    reject_path = str(tmp_path / "drawing-textbox-revisions-rejected.docx")

    doc = offidized.Document()
    doc.add_paragraph("placeholder")
    doc.save(path)

    _rewrite_docx_document_xml(
        path,
        lambda xml: xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Base</w:t></w:r><w:ins w:id=\"41\" w:author=\"Reviewer\"><w:r><w:t xml:space=\"preserve\"> Added</w:t></w:r></w:ins><w:del w:id=\"42\" w:author=\"Reviewer\"><w:r><w:delText xml:space=\"preserve\"> Drop</w:delText></w:r></w:del></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        ),
    )

    reopened = offidized.Document.open(path)
    revisions = reopened.revisions()
    assert any(
        revision[5] == "body/paragraph:0"
        and revision[1] == "insertion"
        and revision[4] == " Added"
        for revision in revisions
    )
    assert any(
        revision[5] == "body/paragraph:0"
        and revision[1] == "deletion"
        and revision[4] == " Drop"
        for revision in revisions
    )

    accepted = offidized.Document.open(path)
    report = accepted.accept_revisions()
    assert report == (1, 1)
    accepted.save(accept_path)
    with zipfile.ZipFile(accept_path, "r") as package:
        accepted_xml = package.read("word/document.xml").decode("utf-8")
    assert "Base" in accepted_xml
    assert " Added" in accepted_xml
    assert "w:ins" not in accepted_xml
    assert "w:del" not in accepted_xml
    assert " Drop" not in accepted_xml

    rejected = offidized.Document.open(path)
    report = rejected.reject_revisions()
    assert report == (1, 1)
    rejected.save(reject_path)
    with zipfile.ZipFile(reject_path, "r") as package:
        rejected_xml = package.read("word/document.xml").decode("utf-8")
    assert "Base" in rejected_xml
    assert " Drop" in rejected_xml
    assert "w:ins" not in rejected_xml
    assert "w:del" not in rejected_xml
    assert " Added" not in rejected_xml



def test_docx_review_text_preserves_bookmarks(tmp_path):
    path = str(tmp_path / "reviewed-bookmark.docx")

    doc = offidized.Document()
    doc.add_paragraph("Alpha Beta Gamma")
    doc.save(path)

    _rewrite_docx_document_xml(
        path,
        lambda xml: xml.replace(
            "Alpha Beta Gamma",
            "Alpha </w:t></w:r><w:bookmarkStart w:id=\"7\" w:name=\"beta_mark\"/><w:r><w:t>Beta</w:t></w:r><w:bookmarkEnd w:id=\"7\"/><w:r><w:t> Gamma",
            1,
        ),
    )

    reopened = offidized.Document.open(path)
    comment_id = reopened.review_text(
        "Beta",
        "Reviewer",
        "Bookmark-safe review.",
        "yellow",
        "2026-03-24T16:20:00Z",
    )
    assert comment_id == 0
    reopened.save(path)

    with zipfile.ZipFile(path, "r") as package:
        xml = package.read("word/document.xml").decode("utf-8")
    assert "bookmarkStart" in xml
    assert "bookmarkEnd" in xml


def test_docx_review_text_matches_across_hyperlink_runs(tmp_path):
    path = str(tmp_path / "reviewed-hyperlink-runs.docx")

    doc = offidized.Document()
    para = doc.add_paragraph("Alpha ")
    run = para.add_run("Be")
    run.set_bold(True)
    para.add_hyperlink("ta", "https://example.com")
    para.add_run(" Gamma")
    comment_id = para.review_text(
        "Beta",
        "Reviewer",
        "Check mixed-format Beta.",
        "yellow",
        "2026-03-24T16:30:00Z",
    )
    assert comment_id == 0
    doc.save(path)

    reopened = offidized.Document.open(path)
    comments = reopened.comments()
    assert len(comments) == 1
    runs = reopened.paragraph(0).runs()
    assert any(
        run.text() == "Be" and run.highlight_color() == "yellow" for run in runs
    )
    assert any(
        run.text() == "ta"
        and run.highlight_color() == "yellow"
        and run.hyperlink() == "https://example.com"
        for run in runs
    )


def test_docx_document_review_text_matches_across_revision_boundaries(tmp_path):
    path = str(tmp_path / "reviewed-revision-span.docx")

    doc = offidized.Document()
    doc.add_paragraph("Intro")
    para = doc.add_paragraph("Alpha ")
    run = para.add_run("Be")
    run.set_bold(True)
    para.add_inserted_text("ta", "Editor", "2026-03-24T16:45:00Z")
    para.add_run(" Gamma")
    comment_id = doc.review_text(
        "Beta",
        "Reviewer",
        "Check revised Beta.",
        "yellow",
        "2026-03-24T17:00:00Z",
    )
    assert comment_id == 0
    doc.save(path)

    reopened = offidized.Document.open(path)
    comments = reopened.comments()
    assert len(comments) == 1
    revisions = reopened.revisions()
    assert any(revision[4] == "ta" for revision in revisions)


def test_docx_document_review_all_text_simple_api(tmp_path):
    path = str(tmp_path / "review-all-text.docx")

    doc = offidized.Document()
    doc.add_paragraph("Alpha Beta Gamma")
    doc.add_paragraph("No target here")
    doc.add_paragraph("Beta appears again")
    comment_ids = doc.review_all_text(
        "Beta",
        "Reviewer",
        "Review all Beta occurrences.",
        "yellow",
        "2026-03-24T17:00:00Z",
    )
    assert comment_ids == [0, 1]
    doc.save(path)

    reopened = offidized.Document.open(path)
    comments = reopened.comments()
    assert len(comments) == 2
    assert all(comment[2] == "Review all Beta occurrences." for comment in comments)
    first_runs = reopened.paragraph(0).runs()
    third_runs = reopened.paragraph(2).runs()
    assert any(run.text() == "Beta" and run.highlight_color() == "yellow" for run in first_runs)
    assert any(run.text() == "Beta" and run.highlight_color() == "yellow" for run in third_runs)


def test_docx_review_text_reaches_headers_footers_footnotes_and_endnotes(tmp_path):
    path = str(tmp_path / "review-supported-parts.docx")

    doc = offidized.Document()
    doc.add_paragraph("Body intro")
    section = doc.section()
    section.set_header_text("Header Beta")
    section.set_footer_text("Footer Beta")
    doc.add_footnote(1, "Footnote Beta")
    doc.add_endnote(1, "Endnote Beta")
    comment_id = doc.review_text(
        "Beta",
        "Reviewer",
        "Review supported parts.",
        "yellow",
        "2026-03-24T18:30:00Z",
    )
    assert comment_id == 0
    doc.save(path)

    reopened = offidized.Document.open(path)
    assert len(reopened.comments()) == 1
    with zipfile.ZipFile(path, "r") as package:
        header_xml = package.read("word/header1.xml").decode("utf-8")
    assert "w:highlight w:val=\"yellow\"" in header_xml


def test_docx_review_all_text_reaches_supported_non_body_parts(tmp_path):
    path = str(tmp_path / "review-all-supported-parts.docx")

    doc = offidized.Document()
    doc.add_paragraph("Body Beta")
    section = doc.section()
    section.set_header_text("Header Beta")
    section.set_footer_text("Footer Beta")
    doc.add_footnote(1, "Footnote Beta")
    doc.add_endnote(1, "Endnote Beta")
    comment_ids = doc.review_all_text(
        "Beta",
        "Reviewer",
        "Review every supported-part Beta.",
        "yellow",
        "2026-03-24T18:35:00Z",
    )
    assert len(comment_ids) == 5
    doc.save(path)

    reopened = offidized.Document.open(path)
    assert len(reopened.comments()) == 5
    with zipfile.ZipFile(path, "r") as package:
        footnotes_xml = package.read("word/footnotes.xml").decode("utf-8")
        endnotes_xml = package.read("word/endnotes.xml").decode("utf-8")
    assert "w:highlight w:val=\"yellow\"" in footnotes_xml
    assert "w:highlight w:val=\"yellow\"" in endnotes_xml


def test_docx_review_text_reaches_supported_table_parts(tmp_path):
    path = str(tmp_path / "review-supported-table-parts.docx")

    doc = offidized.Document()
    doc.add_table(1, 1).set_cell_text(0, 0, "BodyTable Beta")
    section = doc.section()
    section.set_header_text("placeholder")
    doc.add_footnote(1, "placeholder")
    doc.add_endnote(1, "placeholder")
    doc.save(path)

    _rewrite_docx_part_xml(
        path,
        "word/header1.xml",
        lambda xml: xml.replace(
            """<w:p>
    <w:r>
      <w:t>placeholder</w:t>
    </w:r>
  </w:p>""",
            """<w:tbl>
    <w:tblPr/>
    <w:tblGrid>
      <w:gridCol w:w="4320"/>
    </w:tblGrid>
    <w:tr>
      <w:tc>
        <w:p>
          <w:r>
            <w:t>HeaderTable Beta</w:t>
          </w:r>
        </w:p>
      </w:tc>
    </w:tr>
  </w:tbl>""",
            1,
        ),
    )
    _rewrite_docx_part_xml(
        path,
        "word/footnotes.xml",
        lambda xml: xml.replace(
            """<w:p>
      <w:r>
        <w:t>placeholder</w:t>
      </w:r>
    </w:p>""",
            """<w:tbl>
      <w:tblPr/>
      <w:tblGrid>
        <w:gridCol w:w="4320"/>
      </w:tblGrid>
      <w:tr>
        <w:tc>
          <w:p>
            <w:r>
              <w:t>FootTable Beta</w:t>
            </w:r>
          </w:p>
        </w:tc>
      </w:tr>
    </w:tbl>""",
            1,
        ),
    )
    _rewrite_docx_part_xml(
        path,
        "word/endnotes.xml",
        lambda xml: xml.replace(
            """<w:p>
      <w:r>
        <w:t>placeholder</w:t>
      </w:r>
    </w:p>""",
            """<w:tbl>
      <w:tblPr/>
      <w:tblGrid>
        <w:gridCol w:w="4320"/>
      </w:tblGrid>
      <w:tr>
        <w:tc>
          <w:p>
            <w:r>
              <w:t>EndTable Beta</w:t>
            </w:r>
          </w:p>
        </w:tc>
      </w:tr>
    </w:tbl>""",
            1,
        ),
    )

    reviewed = offidized.Document.open(path)
    comment_id = reviewed.review_text(
        "Beta",
        "Reviewer",
        "Review supported table parts.",
        "yellow",
        "2026-03-24T19:10:00Z",
    )
    assert comment_id == 0
    reviewed.save(path)

    reopened = offidized.Document.open(path)
    assert len(reopened.comments()) == 1
    with zipfile.ZipFile(path, "r") as package:
        document_xml = package.read("word/document.xml").decode("utf-8")
    assert "w:highlight w:val=\"yellow\"" in document_xml


def test_docx_review_all_text_reaches_supported_table_parts(tmp_path):
    path = str(tmp_path / "review-all-supported-table-parts.docx")

    doc = offidized.Document()
    doc.add_table(1, 1).set_cell_text(0, 0, "BodyTable Beta")
    section = doc.section()
    section.set_header_text("placeholder")
    doc.add_footnote(1, "placeholder")
    doc.add_endnote(1, "placeholder")
    doc.save(path)

    _rewrite_docx_part_xml(
        path,
        "word/header1.xml",
        lambda xml: xml.replace(
            """<w:p>
    <w:r>
      <w:t>placeholder</w:t>
    </w:r>
  </w:p>""",
            """<w:tbl>
    <w:tblPr/>
    <w:tblGrid>
      <w:gridCol w:w="4320"/>
    </w:tblGrid>
    <w:tr>
      <w:tc>
        <w:p>
          <w:r>
            <w:t>HeaderTable Beta</w:t>
          </w:r>
        </w:p>
      </w:tc>
    </w:tr>
  </w:tbl>""",
            1,
        ),
    )
    _rewrite_docx_part_xml(
        path,
        "word/footnotes.xml",
        lambda xml: xml.replace(
            """<w:p>
      <w:r>
        <w:t>placeholder</w:t>
      </w:r>
    </w:p>""",
            """<w:tbl>
      <w:tblPr/>
      <w:tblGrid>
        <w:gridCol w:w="4320"/>
      </w:tblGrid>
      <w:tr>
        <w:tc>
          <w:p>
            <w:r>
              <w:t>FootTable Beta</w:t>
            </w:r>
          </w:p>
        </w:tc>
      </w:tr>
    </w:tbl>""",
            1,
        ),
    )
    _rewrite_docx_part_xml(
        path,
        "word/endnotes.xml",
        lambda xml: xml.replace(
            """<w:p>
      <w:r>
        <w:t>placeholder</w:t>
      </w:r>
    </w:p>""",
            """<w:tbl>
      <w:tblPr/>
      <w:tblGrid>
        <w:gridCol w:w="4320"/>
      </w:tblGrid>
      <w:tr>
        <w:tc>
          <w:p>
            <w:r>
              <w:t>EndTable Beta</w:t>
            </w:r>
          </w:p>
        </w:tc>
      </w:tr>
    </w:tbl>""",
            1,
        ),
    )

    reviewed = offidized.Document.open(path)
    comment_ids = reviewed.review_all_text(
        "Beta",
        "Reviewer",
        "Review every supported table-part Beta.",
        "yellow",
        "2026-03-24T19:15:00Z",
    )
    assert len(comment_ids) == 4
    reviewed.save(path)

    reopened = offidized.Document.open(path)
    assert len(reopened.comments()) == 4
    with zipfile.ZipFile(path, "r") as package:
        footnotes_xml = package.read("word/footnotes.xml").decode("utf-8")
        endnotes_xml = package.read("word/endnotes.xml").decode("utf-8")
    assert "w:highlight w:val=\"yellow\"" in footnotes_xml
    assert "w:highlight w:val=\"yellow\"" in endnotes_xml


def test_docx_table_cell_review_text_simple_api(tmp_path):
    path = str(tmp_path / "review-table-cell.docx")

    doc = offidized.Document()
    table = doc.add_table(1, 2)
    table.set_cell_text(0, 0, "Alpha Beta Gamma")
    table.set_cell_text(0, 1, "Other")
    cell = table.cell(0, 0)
    comment_id = cell.review_text(
        "Beta",
        "Reviewer",
        "Review this cell text.",
        "yellow",
        "2026-03-24T18:00:00Z",
    )
    assert comment_id == 0
    doc.save(path)

    reopened = offidized.Document.open(path)
    comments = reopened.comments()
    assert len(comments) == 1
    assert comments[0][2] == "Review this cell text."
    assert reopened.table(0).cell(0, 0).text() == "Alpha Beta Gamma"


def test_docx_table_cell_review_text_matches_mixed_runs_and_revisions(tmp_path):
    path = str(tmp_path / "review-table-cell-rich.docx")

    doc = offidized.Document()
    table = doc.add_table(1, 1)
    table.set_cell_text(0, 0, "Alpha Beta Gamma")
    doc.save(path)

    _rewrite_docx_document_xml(
        path,
        lambda xml: xml.replace(
            "Alpha Beta Gamma",
            "Alpha </w:t></w:r><w:r><w:rPr><w:b/></w:rPr><w:t>Be</w:t></w:r><w:ins w:id=\"9\" w:author=\"Editor\" w:date=\"2026-03-24T17:45:00Z\"><w:r><w:t>ta</w:t></w:r></w:ins><w:r><w:t xml:space=\"preserve\"> Gamma",
            1,
        ),
    )

    reopened = offidized.Document.open(path)
    cell = reopened.table(0).cell(0, 0)
    comment_id = cell.review_text(
        "Beta",
        "Reviewer",
        "Review mixed cell text.",
        "yellow",
        "2026-03-24T18:05:00Z",
    )
    assert comment_id == 0
    reopened.save(path)

    reopened_again = offidized.Document.open(path)
    assert reopened_again.table(0).cell(0, 0).text() == "Alpha Beta Gamma"
    assert len(reopened_again.comments()) == 1


def test_docx_table_cell_review_text_matches_multi_paragraph_rich_cell(tmp_path):
    path = str(tmp_path / "review-table-cell-multi-paragraph.docx")

    doc = offidized.Document()
    table = doc.add_table(1, 1)
    table.set_cell_text(0, 0, "Alpha Beta Gamma")
    doc.save(path)

    _rewrite_docx_document_xml(
        path,
        lambda xml: xml.replace(
            "Alpha Beta Gamma",
            "Alpha</w:t></w:r></w:p><w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Be</w:t></w:r><w:ins w:id=\"11\" w:author=\"Editor\" w:date=\"2026-03-24T18:10:00Z\"><w:r><w:t>ta</w:t></w:r></w:ins><w:r><w:t xml:space=\"preserve\"> Gamma",
            1,
        ),
    )

    reopened = offidized.Document.open(path)
    cell = reopened.table(0).cell(0, 0)
    comment_id = cell.review_text(
        "Beta",
        "Reviewer",
        "Review second paragraph Beta.",
        "yellow",
        "2026-03-24T18:15:00Z",
    )
    assert comment_id == 0
    reopened.save(path)

    reopened_again = offidized.Document.open(path)
    assert reopened_again.table(0).cell(0, 0).text() == "Alpha\nBeta Gamma"
    assert len(reopened_again.comments()) == 1


# ---------------------------------------------------------------------------
# pptx
# ---------------------------------------------------------------------------


def test_presentation_create():
    pres = offidized.Presentation()
    assert pres is not None


def test_presentation_add_slide():
    pres = offidized.Presentation()
    pres.add_slide()
    assert pres.slide_count() >= 1


def test_presentation_roundtrip_file(tmp_path):
    path = str(tmp_path / "roundtrip.pptx")
    pres = offidized.Presentation()
    pres.add_slide()
    pres.save(path)

    pres2 = offidized.Presentation.open(path)
    assert pres2.slide_count() >= 1


def test_presentation_save_and_open(tmp_path):
    path = str(tmp_path / "test.pptx")
    pres = offidized.Presentation()
    pres.add_slide()
    pres.save(path)

    pres2 = offidized.Presentation.open(path)
    assert pres2.slide_count() >= 1


def test_slide_show_settings_construct():
    settings = offidized.SlideShowSettings()
    assert settings is not None


def test_custom_show_construct():
    show = offidized.CustomShow("My Show")
    assert show.name() == "My Show"
    show.set_name("Renamed")
    assert show.name() == "Renamed"


def test_slide_transition_construct():
    transition = offidized.SlideTransition("fade")
    assert transition is not None


# ---------------------------------------------------------------------------
# Error types
# ---------------------------------------------------------------------------


def test_error_types_exist():
    """All error types are importable and are exception classes."""
    for name in [
        "OffidizedError",
        "OffidizedIoError",
        "OffidizedValueError",
        "OffidizedUnsupportedError",
        "OffidizedRuntimeError",
    ]:
        cls = getattr(offidized, name)
        assert isinstance(cls, type)
        assert issubclass(cls, BaseException)


def test_workbook_open_nonexistent_raises():
    try:
        offidized.Workbook.open("/nonexistent/path.xlsx")
        assert False, "should have raised"
    except Exception:
        pass  # any error is fine — just verify it doesn't silently succeed


def test_document_open_nonexistent_raises():
    try:
        offidized.Document.open("/nonexistent/path.docx")
        assert False, "should have raised"
    except Exception:
        pass


def test_presentation_open_nonexistent_raises():
    try:
        offidized.Presentation.open("/nonexistent/path.pptx")
        assert False, "should have raised"
    except Exception:
        pass
