"""Basic headless tracked-changes workflow with offidized.

Run from the repo root:

    cd crates/offidized-py
    uv run python examples/docx/08_redline_review.py
"""

from pathlib import Path

from offidized import Document

OUT = Path("08_redline_review")
OUT.mkdir(exist_ok=True)

original_path = OUT / "original.docx"
revised_path = OUT / "revised.docx"
redline_path = OUT / "redline.docx"
accepted_path = OUT / "accepted.docx"

# Build two simple documents.
original = Document()
original.add_paragraph("Alpha Gamma")
original.add_paragraph("Stable paragraph")
original.save(str(original_path))

revised = Document()
revised.add_paragraph("Alpha Beta")
revised.add_paragraph("Stable paragraph")
revised.save(str(revised_path))

# Compare them into a redlined result.
redline = Document.compare(str(original_path), str(revised_path), author="Proposal Bot")
redline.review_all_text(
    "Beta",
    "Proposal Bot",
    "Consider whether each changed Beta needs legal review.",
    "yellow",
)
redline.save(str(redline_path))

print("Revisions:")
for revision in redline.revisions():
    print(revision)

# Accept the generated revisions.
counts = redline.accept_revisions(author="Proposal Bot")
print("Accepted:", counts)
redline.save(str(accepted_path))

print(f"Wrote: {original_path}")
print(f"Wrote: {revised_path}")
print(f"Wrote: {redline_path}")
print(f"Wrote: {accepted_path}")
