"""Layout-safer proposal review workflow with comments/highlights instead of tracked changes.

Run from the repo root:

    cd crates/offidized-py
    uv run python examples/docx/09_proposal_review_safe.py
"""

from pathlib import Path

from offidized import Document

OUT = Path("09_proposal_review_safe")
OUT.mkdir(exist_ok=True)

source_path = OUT / "source.docx"
reviewed_path = OUT / "reviewed.docx"

source = Document()
source.add_paragraph("Executive Summary")
source.add_paragraph(
    "Acme Advisory provides strategic communications, organizational branding, public affairs, and internal communications support for the program office."
)
source.add_paragraph(
    "Use or disclosure of data contained on this sheet is subject to the restriction on the title page of this proposal."
)
source.save(str(source_path))

reviewed = Document.open(str(source_path))
reviewed.apply_reviews(
    [
        {
            "text": "strategic communications",
            "comment": "Verify this claim against the latest past-performance source before submission.",
            "highlight": "yellow",
        },
        {
            "text": "public affairs",
            "comment": "Consider tightening this wording for evaluator clarity.",
            "highlight": "cyan",
        },
    ],
    author="Proposal Bot",
    comments_only_protection=True,
)
reviewed.save(str(reviewed_path))

print(f"Wrote: {source_path}")
print(f"Wrote: {reviewed_path}")
