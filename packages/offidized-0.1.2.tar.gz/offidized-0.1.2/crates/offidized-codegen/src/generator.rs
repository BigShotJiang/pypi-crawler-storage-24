use std::fs;
use std::path::{Path, PathBuf};

use anyhow::{Context, Result};

use crate::schema::{
    OpenXmlSdkData, PartChildDefinition, PartDefinition, PartPaths, SchematronRule,
    TypedElementDescriptor, TypedElementKind, ValidationAttributeDescriptor,
    ValidationElementDescriptor, ValidationParticleDescriptor, ValidationParticleKind,
    ValidationValidatorArgument, ValidationValidatorDescriptor, ValidationValidatorKind,
    CUSTOM_PROPERTIES_URI, DOC_PROPS_VTYPES_URI, DRAWINGML_2010_MAIN_URI, DRAWINGML_2012_MAIN_URI,
    DRAWINGML_CHART_DRAWING_2010_URI, DRAWINGML_CHART_DRAWING_URI, DRAWINGML_CHART_URI,
    DRAWINGML_DIAGRAM_URI, DRAWINGML_LOCKED_CANVAS_URI, DRAWINGML_MAIN_URI,
    DRAWINGML_PICTURE_2010_URI, DRAWINGML_PICTURE_URI, DRAWINGML_SPREADSHEET_DRAWING_URI,
    DRAWINGML_WORDPROCESSING_DRAWING_URI, EXTENDED_PROPERTIES_URI, OFFICE_MATH_URI,
    PRESENTATIONML_2010_URI, PRESENTATIONML_MAIN_URI, SPREADSHEETML_2010_URI,
    SPREADSHEETML_MAIN_URI, VML_URI, WORDPROCESSINGML_2010_URI, WORDPROCESSINGML_2012_URI,
    WORDPROCESSINGML_MAIN_URI, WORDPROCESSING_CANVAS_2010_URI, WORDPROCESSING_DRAWING_2010_URI,
    WORDPROCESSING_DRAWING_2012_URI, WORDPROCESSING_GROUP_2010_URI, WORDPROCESSING_SHAPE_2010_URI,
};

const SPREADSHEET_MODULE_FILE: &str = "spreadsheetml_main_registry.rs";
const SPREADSHEET_TYPED_API_MODULE_FILE: &str = "spreadsheetml_main_typed_api.rs";
const SPREADSHEET_VALIDATION_MODULE_FILE: &str = "spreadsheetml_main_validation.rs";
const WORD_MODULE_FILE: &str = "wordprocessingml_main_registry.rs";
const WORD_TYPED_API_MODULE_FILE: &str = "wordprocessingml_main_typed_api.rs";
const WORD_VALIDATION_MODULE_FILE: &str = "wordprocessingml_main_validation.rs";
const PRESENTATION_MODULE_FILE: &str = "presentationml_main_registry.rs";
const PRESENTATION_TYPED_API_MODULE_FILE: &str = "presentationml_main_typed_api.rs";
const PRESENTATION_VALIDATION_MODULE_FILE: &str = "presentationml_main_validation.rs";
const SUPPLEMENTAL_VALIDATION_MODULE_FILE: &str = "supplemental_validation.rs";
const SCHEMATRON_MODULE_FILE: &str = "schematron_registry.rs";
const NAMESPACE_REGISTRY_MODULE_FILE: &str = "namespace_registry.rs";
const SHARED_PARTS_MODULE_FILE: &str = "shared_part_registry.rs";
const SUPPLEMENTAL_VALIDATION_URIS: &[&str] = &[
    DRAWINGML_MAIN_URI,
    DRAWINGML_2010_MAIN_URI,
    DRAWINGML_2012_MAIN_URI,
    DRAWINGML_LOCKED_CANVAS_URI,
    DRAWINGML_PICTURE_URI,
    DRAWINGML_PICTURE_2010_URI,
    DRAWINGML_CHART_URI,
    DRAWINGML_CHART_DRAWING_URI,
    DRAWINGML_CHART_DRAWING_2010_URI,
    DRAWINGML_DIAGRAM_URI,
    DRAWINGML_SPREADSHEET_DRAWING_URI,
    DRAWINGML_WORDPROCESSING_DRAWING_URI,
    WORDPROCESSING_DRAWING_2010_URI,
    WORDPROCESSING_DRAWING_2012_URI,
    CUSTOM_PROPERTIES_URI,
    EXTENDED_PROPERTIES_URI,
    DOC_PROPS_VTYPES_URI,
    OFFICE_MATH_URI,
    VML_URI,
    WORDPROCESSING_CANVAS_2010_URI,
    WORDPROCESSING_GROUP_2010_URI,
    WORDPROCESSING_SHAPE_2010_URI,
    WORDPROCESSINGML_2010_URI,
    WORDPROCESSINGML_2012_URI,
    SPREADSHEETML_2010_URI,
    PRESENTATIONML_2010_URI,
];

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct GeneratorOutput {
    pub files: Vec<PathBuf>,
}

pub fn generate_schema_registries<P: AsRef<Path>>(
    data: &OpenXmlSdkData,
    output_dir: P,
) -> Result<GeneratorOutput> {
    let output_dir = output_dir.as_ref();
    fs::create_dir_all(output_dir)
        .with_context(|| format!("failed to create {}", output_dir.display()))?;

    let spreadsheet_entries = data.main_namespace_typed_elements(SPREADSHEETML_MAIN_URI)?;
    let spreadsheet_validation_entries =
        data.main_namespace_validation_descriptors(SPREADSHEETML_MAIN_URI)?;
    let word_entries = data.main_namespace_typed_elements(WORDPROCESSINGML_MAIN_URI)?;
    let word_validation_entries =
        data.main_namespace_validation_descriptors(WORDPROCESSINGML_MAIN_URI)?;
    let presentation_entries = data.main_namespace_typed_elements(PRESENTATIONML_MAIN_URI)?;
    let presentation_validation_entries =
        data.main_namespace_validation_descriptors(PRESENTATIONML_MAIN_URI)?;
    let mut supplemental_validation_entries = Vec::new();
    for uri in SUPPLEMENTAL_VALIDATION_URIS {
        supplemental_validation_entries.extend(data.main_namespace_validation_descriptors(uri)?);
    }

    let spreadsheet_module = render_typed_registry_module(
        "SpreadsheetML",
        SPREADSHEETML_MAIN_URI,
        "x",
        "SPREADSHEETML_MAIN_REGISTRY",
        &spreadsheet_entries,
    );
    let spreadsheet_typed_api_module =
        render_typed_api_module("SpreadsheetML", "spreadsheetml_main", &spreadsheet_entries);
    let spreadsheet_validation_module = render_validation_registry_module(
        "SpreadsheetML",
        "SPREADSHEETML_MAIN_VALIDATION_REGISTRY",
        &spreadsheet_validation_entries,
    );
    let word_module = render_typed_registry_module(
        "WordprocessingML",
        WORDPROCESSINGML_MAIN_URI,
        "w",
        "WORDPROCESSINGML_MAIN_REGISTRY",
        &word_entries,
    );
    let word_typed_api_module =
        render_typed_api_module("WordprocessingML", "wordprocessingml_main", &word_entries);
    let word_validation_module = render_validation_registry_module(
        "WordprocessingML",
        "WORDPROCESSINGML_MAIN_VALIDATION_REGISTRY",
        &word_validation_entries,
    );
    let presentation_module = render_typed_registry_module(
        "PresentationML",
        PRESENTATIONML_MAIN_URI,
        "p",
        "PRESENTATIONML_MAIN_REGISTRY",
        &presentation_entries,
    );
    let presentation_typed_api_module = render_typed_api_module(
        "PresentationML",
        "presentationml_main",
        &presentation_entries,
    );
    let presentation_validation_module = render_validation_registry_module(
        "PresentationML",
        "PRESENTATIONML_MAIN_VALIDATION_REGISTRY",
        &presentation_validation_entries,
    );
    let supplemental_validation_module = render_validation_registry_module(
        "Supplemental OOXML namespaces",
        "SUPPLEMENTAL_VALIDATION_REGISTRY",
        &supplemental_validation_entries,
    );
    let schematron_module = render_schematron_registry_module(&data.schematrons);
    let namespace_registry_module = render_namespace_registry_module(data);
    let shared_parts_module = render_part_registry_module(data);

    let spreadsheet_path = output_dir.join(SPREADSHEET_MODULE_FILE);
    let spreadsheet_typed_api_path = output_dir.join(SPREADSHEET_TYPED_API_MODULE_FILE);
    let spreadsheet_validation_path = output_dir.join(SPREADSHEET_VALIDATION_MODULE_FILE);
    let word_path = output_dir.join(WORD_MODULE_FILE);
    let word_typed_api_path = output_dir.join(WORD_TYPED_API_MODULE_FILE);
    let word_validation_path = output_dir.join(WORD_VALIDATION_MODULE_FILE);
    let presentation_path = output_dir.join(PRESENTATION_MODULE_FILE);
    let presentation_typed_api_path = output_dir.join(PRESENTATION_TYPED_API_MODULE_FILE);
    let presentation_validation_path = output_dir.join(PRESENTATION_VALIDATION_MODULE_FILE);
    let supplemental_validation_path = output_dir.join(SUPPLEMENTAL_VALIDATION_MODULE_FILE);
    let schematron_path = output_dir.join(SCHEMATRON_MODULE_FILE);
    let namespace_registry_path = output_dir.join(NAMESPACE_REGISTRY_MODULE_FILE);
    let parts_path = output_dir.join(SHARED_PARTS_MODULE_FILE);

    write_module_file(&spreadsheet_path, &spreadsheet_module)?;
    write_module_file(&spreadsheet_typed_api_path, &spreadsheet_typed_api_module)?;
    write_module_file(&spreadsheet_validation_path, &spreadsheet_validation_module)?;
    write_module_file(&word_path, &word_module)?;
    write_module_file(&word_typed_api_path, &word_typed_api_module)?;
    write_module_file(&word_validation_path, &word_validation_module)?;
    write_module_file(&presentation_path, &presentation_module)?;
    write_module_file(&presentation_typed_api_path, &presentation_typed_api_module)?;
    write_module_file(
        &presentation_validation_path,
        &presentation_validation_module,
    )?;
    write_module_file(
        &supplemental_validation_path,
        &supplemental_validation_module,
    )?;
    write_module_file(&schematron_path, &schematron_module)?;
    write_module_file(&namespace_registry_path, &namespace_registry_module)?;
    write_module_file(&parts_path, &shared_parts_module)?;

    Ok(GeneratorOutput {
        files: vec![
            spreadsheet_path,
            spreadsheet_typed_api_path,
            spreadsheet_validation_path,
            word_path,
            word_typed_api_path,
            word_validation_path,
            presentation_path,
            presentation_typed_api_path,
            presentation_validation_path,
            supplemental_validation_path,
            schematron_path,
            namespace_registry_path,
            parts_path,
        ],
    })
}

fn write_module_file(path: &Path, contents: &str) -> Result<()> {
    fs::write(path, contents).with_context(|| format!("failed to write {}", path.display()))
}

fn render_typed_registry_module(
    label: &str,
    namespace_uri: &str,
    namespace_prefix: &str,
    registry_const_name: &str,
    entries: &[TypedElementDescriptor],
) -> String {
    let mut entries = entries.to_vec();
    entries.sort_by(|left, right| {
        left.schema_path
            .cmp(&right.schema_path)
            .then(left.class_name.cmp(&right.class_name))
    });

    let mut out = String::new();
    out.push_str("// @generated by offidized-codegen. Do not edit manually.\n");
    out.push_str(&format!(
        "// Typed-element registry for {label} main namespace.\n\n"
    ));
    out.push_str("use std::collections::BTreeMap;\n\n");
    out.push_str("use quick_xml::events::{BytesEnd, BytesStart, Event};\n");
    out.push_str("use quick_xml::{Reader, Writer};\n\n");
    out.push_str("use crate::catalog::TypedElementXmlError;\n");
    out.push_str("use crate::raw::RawXmlNode;\n\n");
    out.push_str("#[derive(Debug, Clone, Copy, PartialEq, Eq)]\n");
    out.push_str("pub enum TypedElementKind {\n");
    out.push_str("    Leaf,\n");
    out.push_str("    Composite,\n");
    out.push_str("    TypedLeaf,\n");
    out.push_str("}\n\n");
    out.push_str("#[derive(Debug, Clone, Copy, PartialEq, Eq)]\n");
    out.push_str("pub struct TypedElementDescriptor {\n");
    out.push_str("    pub class_name: &'static str,\n");
    out.push_str("    pub qualified_name: &'static str,\n");
    out.push_str("    pub schema_path: &'static str,\n");
    out.push_str("    pub type_kind: TypedElementKind,\n");
    out.push_str("    pub known_attributes: &'static [&'static str],\n");
    out.push_str("}\n\n");
    out.push_str(&format!(
        "pub const NAMESPACE_URI: &str = {};\n",
        rust_string(namespace_uri)
    ));
    out.push_str(&format!(
        "pub const NAMESPACE_PREFIX: &str = {};\n\n",
        rust_string(namespace_prefix)
    ));
    out.push_str(&format!(
        "pub const {registry_const_name}: &[TypedElementDescriptor] = &[\n"
    ));

    for entry in entries {
        out.push_str("    TypedElementDescriptor {\n");
        out.push_str(&format!(
            "        class_name: {},\n",
            rust_string(&entry.class_name)
        ));
        out.push_str(&format!(
            "        qualified_name: {},\n",
            rust_string(&entry.qualified_name)
        ));
        out.push_str(&format!(
            "        schema_path: {},\n",
            rust_string(&entry.schema_path)
        ));
        out.push_str(&format!(
            "        type_kind: {},\n",
            rust_typed_element_kind(entry.type_kind)
        ));
        out.push_str(&format!(
            "        known_attributes: {},\n",
            rust_static_string_slice(&entry.known_attributes)
        ));
        out.push_str("    },\n");
    }

    out.push_str("];\n\n");
    out.push_str("#[derive(Debug, Clone)]\n");
    out.push_str("pub struct TypedElement {\n");
    out.push_str("    pub descriptor: &'static TypedElementDescriptor,\n");
    out.push_str("    pub known_attrs: BTreeMap<String, String>,\n");
    out.push_str("    pub unknown_attrs: Vec<(String, String)>,\n");
    out.push_str("    pub unknown_children: Vec<RawXmlNode>,\n");
    out.push_str("}\n\n");
    out.push_str("impl TypedElement {\n");
    out.push_str("    #[must_use]\n");
    out.push_str("    pub fn new(descriptor: &'static TypedElementDescriptor) -> Self {\n");
    out.push_str("        Self {\n");
    out.push_str("            descriptor,\n");
    out.push_str("            known_attrs: BTreeMap::new(),\n");
    out.push_str("            unknown_attrs: Vec::new(),\n");
    out.push_str("            unknown_children: Vec::new(),\n");
    out.push_str("        }\n");
    out.push_str("    }\n\n");
    out.push_str(
        "    pub fn from_xml_snippet(snippet: &str) -> Result<Self, TypedElementXmlError> {\n",
    );
    out.push_str("        let mut reader = Reader::from_str(snippet);\n");
    out.push_str("        reader.config_mut().trim_text(false);\n");
    out.push_str("        let mut buffer = Vec::new();\n\n");
    out.push_str("        loop {\n");
    out.push_str("            match reader.read_event_into(&mut buffer)? {\n");
    out.push_str("                Event::Start(start) => {\n");
    out.push_str("                    let start = start.to_owned();\n");
    out.push_str("                    return parse_non_empty_root(&mut reader, &start);\n");
    out.push_str("                }\n");
    out.push_str("                Event::Empty(start) => {\n");
    out.push_str("                    let start = start.to_owned();\n");
    out.push_str("                    return parse_empty_root(&start);\n");
    out.push_str("                }\n");
    out.push_str(
        "                Event::Eof => return Err(TypedElementXmlError::MissingRootElement),\n",
    );
    out.push_str("                _ => {}\n");
    out.push_str("            }\n");
    out.push_str("            buffer.clear();\n");
    out.push_str("        }\n");
    out.push_str("    }\n\n");
    out.push_str("    pub fn from_xml_snippet_for_descriptor(\n");
    out.push_str("        descriptor: &'static TypedElementDescriptor,\n");
    out.push_str("        snippet: &str,\n");
    out.push_str("    ) -> Result<Self, TypedElementXmlError> {\n");
    out.push_str("        let parsed = Self::from_xml_snippet(snippet)?;\n");
    out.push_str("        if parsed.descriptor.qualified_name != descriptor.qualified_name {\n");
    out.push_str("            return Err(TypedElementXmlError::UnexpectedRoot {\n");
    out.push_str("                expected: descriptor.qualified_name,\n");
    out.push_str("                found: parsed.descriptor.qualified_name.to_owned(),\n");
    out.push_str("            });\n");
    out.push_str("        }\n");
    out.push_str("        Ok(parsed)\n");
    out.push_str("    }\n\n");
    out.push_str("    pub fn to_xml_snippet(&self) -> Result<String, TypedElementXmlError> {\n");
    out.push_str("        let mut writer = Writer::new(Vec::new());\n");
    out.push_str("        let mut start = BytesStart::new(self.descriptor.qualified_name);\n");
    out.push_str("        for (key, value) in &self.known_attrs {\n");
    out.push_str("            start.push_attribute((key.as_str(), value.as_str()));\n");
    out.push_str("        }\n");
    out.push_str("        for (key, value) in &self.unknown_attrs {\n");
    out.push_str("            start.push_attribute((key.as_str(), value.as_str()));\n");
    out.push_str("        }\n\n");
    out.push_str("        if self.unknown_children.is_empty() {\n");
    out.push_str("            writer.write_event(Event::Empty(start))?;\n");
    out.push_str("        } else {\n");
    out.push_str("            writer.write_event(Event::Start(start))?;\n");
    out.push_str("            for child in &self.unknown_children {\n");
    out.push_str("                child.write_to(&mut writer)?;\n");
    out.push_str("            }\n");
    out.push_str("            writer.write_event(Event::End(BytesEnd::new(self.descriptor.qualified_name)))?;\n");
    out.push_str("        }\n\n");
    out.push_str("        Ok(String::from_utf8(writer.into_inner())?)\n");
    out.push_str("    }\n");
    out.push_str("}\n\n");
    out.push_str("#[must_use]\n");
    out.push_str("pub fn find_descriptor_by_class(class_name: &str) -> Option<&'static TypedElementDescriptor> {\n");
    out.push_str(&format!(
        "    {registry_const_name}.iter().find(|descriptor| descriptor.class_name == class_name)\n"
    ));
    out.push_str("}\n\n");
    out.push_str("#[must_use]\n");
    out.push_str("pub fn find_descriptor_by_qualified_name(\n");
    out.push_str("    qualified_name: &str,\n");
    out.push_str(") -> Option<&'static TypedElementDescriptor> {\n");
    out.push_str(&format!(
        "    {registry_const_name}.iter().find(|descriptor| descriptor.qualified_name == qualified_name)\n"
    ));
    out.push_str("}\n\n");
    out.push_str("#[must_use]\n");
    out.push_str("pub fn new_typed_element_by_class(class_name: &str) -> Option<TypedElement> {\n");
    out.push_str("    find_descriptor_by_class(class_name).map(TypedElement::new)\n");
    out.push_str("}\n\n");
    out.push_str("#[must_use]\n");
    out.push_str("pub fn new_typed_element_by_qualified_name(qualified_name: &str) -> Option<TypedElement> {\n");
    out.push_str("    find_descriptor_by_qualified_name(qualified_name).map(TypedElement::new)\n");
    out.push_str("}\n\n");
    out.push_str(
        "pub fn parse_typed_element_for_class(class_name: &str, snippet: &str) -> Result<TypedElement, TypedElementXmlError> {\n",
    );
    out.push_str("    let descriptor = find_descriptor_by_class(class_name)\n");
    out.push_str(
        "        .ok_or_else(|| TypedElementXmlError::UnknownClassName(class_name.to_owned()))?;\n",
    );
    out.push_str("    TypedElement::from_xml_snippet_for_descriptor(descriptor, snippet)\n");
    out.push_str("}\n\n");
    out.push_str("fn parse_empty_root(start: &BytesStart<'_>) -> Result<TypedElement, TypedElementXmlError> {\n");
    out.push_str("    let descriptor = descriptor_for_start(start)?;\n");
    out.push_str("    let (known_attrs, unknown_attrs) = split_attributes(start, descriptor);\n");
    out.push_str("    Ok(TypedElement {\n");
    out.push_str("        descriptor,\n");
    out.push_str("        known_attrs,\n");
    out.push_str("        unknown_attrs,\n");
    out.push_str("        unknown_children: Vec::new(),\n");
    out.push_str("    })\n");
    out.push_str("}\n\n");
    out.push_str("fn parse_non_empty_root<R: std::io::BufRead>(\n");
    out.push_str("    reader: &mut Reader<R>,\n");
    out.push_str("    start: &BytesStart<'_>,\n");
    out.push_str(") -> Result<TypedElement, TypedElementXmlError> {\n");
    out.push_str("    let descriptor = descriptor_for_start(start)?;\n");
    out.push_str("    let (known_attrs, unknown_attrs) = split_attributes(start, descriptor);\n");
    out.push_str(
        "    let unknown_children = read_unknown_children(reader, start.name().as_ref())?;\n",
    );
    out.push_str("    Ok(TypedElement {\n");
    out.push_str("        descriptor,\n");
    out.push_str("        known_attrs,\n");
    out.push_str("        unknown_attrs,\n");
    out.push_str("        unknown_children,\n");
    out.push_str("    })\n");
    out.push_str("}\n\n");
    out.push_str("fn descriptor_for_start(\n");
    out.push_str("    start: &BytesStart<'_>,\n");
    out.push_str(") -> Result<&'static TypedElementDescriptor, TypedElementXmlError> {\n");
    out.push_str(
        "    let qualified_name = String::from_utf8_lossy(start.name().as_ref()).into_owned();\n",
    );
    out.push_str("    find_descriptor_by_qualified_name(&qualified_name)\n");
    out.push_str("        .ok_or(TypedElementXmlError::UnknownQualifiedName(qualified_name))\n");
    out.push_str("}\n\n");
    out.push_str("fn split_attributes(\n");
    out.push_str("    start: &BytesStart<'_>,\n");
    out.push_str("    descriptor: &'static TypedElementDescriptor,\n");
    out.push_str(") -> (BTreeMap<String, String>, Vec<(String, String)>) {\n");
    out.push_str("    let mut known_attrs = BTreeMap::new();\n");
    out.push_str("    let mut unknown_attrs = Vec::new();\n\n");
    out.push_str("    for attribute in start.attributes().filter_map(Result::ok) {\n");
    out.push_str(
        "        let raw_name = String::from_utf8_lossy(attribute.key.as_ref()).into_owned();\n",
    );
    out.push_str(
        "        let normalized_name = raw_name.strip_prefix(':').unwrap_or(&raw_name);\n",
    );
    out.push_str("        let value = attribute\n");
    out.push_str("            .unescape_value()\n");
    out.push_str(
        "            .unwrap_or_else(|_| String::from_utf8_lossy(attribute.value.as_ref()))\n",
    );
    out.push_str("            .into_owned();\n");
    out.push_str("        if descriptor\n");
    out.push_str("            .known_attributes\n");
    out.push_str("            .binary_search(&normalized_name)\n");
    out.push_str("            .is_ok()\n");
    out.push_str("        {\n");
    out.push_str("            known_attrs.insert(normalized_name.to_owned(), value);\n");
    out.push_str("        } else {\n");
    out.push_str("            unknown_attrs.push((raw_name, value));\n");
    out.push_str("        }\n");
    out.push_str("    }\n\n");
    out.push_str("    (known_attrs, unknown_attrs)\n");
    out.push_str("}\n\n");
    out.push_str("fn read_unknown_children<R: std::io::BufRead>(\n");
    out.push_str("    reader: &mut Reader<R>,\n");
    out.push_str("    root_name: &[u8],\n");
    out.push_str(") -> Result<Vec<RawXmlNode>, TypedElementXmlError> {\n");
    out.push_str("    let mut children = Vec::new();\n");
    out.push_str("    let mut buffer = Vec::new();\n\n");
    out.push_str("    loop {\n");
    out.push_str("        match reader.read_event_into(&mut buffer)? {\n");
    out.push_str("            Event::Start(start) => {\n");
    out.push_str("                let start = start.to_owned();\n");
    out.push_str("                children.push(RawXmlNode::read_element(reader, &start)?);\n");
    out.push_str("            }\n");
    out.push_str("            Event::Empty(start) => {\n");
    out.push_str(
        "                let name = String::from_utf8_lossy(start.name().as_ref()).into_owned();\n",
    );
    out.push_str("                let attributes = start\n");
    out.push_str("                    .attributes()\n");
    out.push_str("                    .filter_map(Result::ok)\n");
    out.push_str("                    .map(|attribute| {\n");
    out.push_str("                        let key = String::from_utf8_lossy(attribute.key.as_ref()).into_owned();\n");
    out.push_str("                        let value = attribute\n");
    out.push_str("                            .unescape_value()\n");
    out.push_str("                            .unwrap_or_else(|_| String::from_utf8_lossy(attribute.value.as_ref()))\n");
    out.push_str("                            .into_owned();\n");
    out.push_str("                        (key, value)\n");
    out.push_str("                    })\n");
    out.push_str("                    .collect();\n");
    out.push_str("                children.push(RawXmlNode::Element {\n");
    out.push_str("                    name,\n");
    out.push_str("                    attributes,\n");
    out.push_str("                    children: Vec::new(),\n");
    out.push_str("                });\n");
    out.push_str("            }\n");
    out.push_str("            Event::Text(text) => {\n");
    out.push_str(
        "                let content = text.xml_content().map_err(quick_xml::Error::from)?.into_owned();\n",
    );
    out.push_str("                if !content.trim().is_empty() {\n");
    out.push_str("                    children.push(RawXmlNode::Text(content));\n");
    out.push_str("                }\n");
    out.push_str("            }\n");
    out.push_str("            Event::GeneralRef(reference) => {\n");
    out.push_str(
        "                let reference = reference.decode().map_err(quick_xml::Error::from)?;\n",
    );
    out.push_str(
        "                children.push(RawXmlNode::RawBytes(format!(\"&{};\", reference).into_bytes()));\n",
    );
    out.push_str("            }\n");
    out.push_str("            Event::CData(text) => {\n");
    out.push_str("                children.push(RawXmlNode::CData(String::from_utf8_lossy(text.as_ref()).into_owned()));\n");
    out.push_str("            }\n");
    out.push_str("            Event::End(end) if end.name().as_ref() == root_name => {\n");
    out.push_str("                break;\n");
    out.push_str("            }\n");
    out.push_str("            Event::Eof => return Err(TypedElementXmlError::UnexpectedEof),\n");
    out.push_str("            _ => {}\n");
    out.push_str("        }\n");
    out.push_str("        buffer.clear();\n");
    out.push_str("    }\n\n");
    out.push_str("    Ok(children)\n");
    out.push_str("}\n");
    out
}

fn render_validation_registry_module(
    label: &str,
    registry_const_name: &str,
    entries: &[ValidationElementDescriptor],
) -> String {
    let mut entries = entries.to_vec();
    entries.sort_by(|left, right| {
        left.schema_path
            .cmp(&right.schema_path)
            .then(left.class_name.cmp(&right.class_name))
    });

    let mut out = String::new();
    out.push_str("// @generated by offidized-codegen. Do not edit manually.\n");
    out.push_str(&format!(
        "// Validation metadata registry for {label} main namespace.\n\n"
    ));
    out.push_str("#[derive(Debug, Clone, Copy, PartialEq, Eq)]\n");
    out.push_str("pub enum TypedElementKind {\n");
    out.push_str("    Leaf,\n");
    out.push_str("    Composite,\n");
    out.push_str("    TypedLeaf,\n");
    out.push_str("}\n\n");
    out.push_str("#[derive(Debug, Clone, Copy, PartialEq, Eq)]\n");
    out.push_str("pub enum ValidationValidatorKind {\n");
    out.push_str("    Required,\n");
    out.push_str("    String,\n");
    out.push_str("    Number,\n");
    out.push_str("    Enum,\n");
    out.push_str("    OfficeVersion,\n");
    out.push_str("}\n\n");
    out.push_str("#[derive(Debug, Clone, Copy, PartialEq, Eq)]\n");
    out.push_str("pub enum ValidationParticleKind {\n");
    out.push_str("    Element,\n");
    out.push_str("    Sequence,\n");
    out.push_str("    Choice,\n");
    out.push_str("    All,\n");
    out.push_str("    Group,\n");
    out.push_str("    Any,\n");
    out.push_str("}\n\n");
    out.push_str("#[derive(Debug, Clone, Copy, PartialEq, Eq)]\n");
    out.push_str("pub struct ValidationValidatorArgument {\n");
    out.push_str("    pub argument_type: &'static str,\n");
    out.push_str("    pub name: Option<&'static str>,\n");
    out.push_str("    pub value: &'static str,\n");
    out.push_str("}\n\n");
    out.push_str("#[derive(Debug, Clone, Copy, PartialEq, Eq)]\n");
    out.push_str("pub struct ValidationValidatorDescriptor {\n");
    out.push_str("    pub kind: ValidationValidatorKind,\n");
    out.push_str("    pub simple_type: Option<&'static str>,\n");
    out.push_str("    pub union_id: Option<i32>,\n");
    out.push_str("    pub is_initial_version: bool,\n");
    out.push_str("    pub arguments: &'static [ValidationValidatorArgument],\n");
    out.push_str("    pub enum_values: &'static [&'static str],\n");
    out.push_str("}\n\n");
    out.push_str("#[derive(Debug, Clone, Copy, PartialEq, Eq)]\n");
    out.push_str("pub struct ValidationAttributeDescriptor {\n");
    out.push_str("    pub q_name: &'static str,\n");
    out.push_str("    pub normalized_q_name: &'static str,\n");
    out.push_str("    pub value_type: Option<&'static str>,\n");
    out.push_str("    pub version: Option<&'static str>,\n");
    out.push_str("    pub validators: &'static [ValidationValidatorDescriptor],\n");
    out.push_str("    pub enum_values: &'static [&'static str],\n");
    out.push_str("}\n\n");
    out.push_str("#[derive(Debug, Clone, Copy, PartialEq, Eq)]\n");
    out.push_str("pub struct ValidationParticleDescriptor {\n");
    out.push_str("    pub kind: ValidationParticleKind,\n");
    out.push_str("    pub schema_name: Option<&'static str>,\n");
    out.push_str("    pub qualified_name: Option<&'static str>,\n");
    out.push_str("    pub min_occurs: u32,\n");
    out.push_str("    pub max_occurs: Option<u32>,\n");
    out.push_str("    pub initial_version: Option<&'static str>,\n");
    out.push_str("    pub items: &'static [ValidationParticleDescriptor],\n");
    out.push_str("}\n\n");
    out.push_str("#[derive(Debug, Clone, Copy, PartialEq, Eq)]\n");
    out.push_str("pub struct ValidationElementDescriptor {\n");
    out.push_str("    pub class_name: &'static str,\n");
    out.push_str("    pub schema_name: &'static str,\n");
    out.push_str("    pub qualified_name: &'static str,\n");
    out.push_str("    pub schema_path: &'static str,\n");
    out.push_str("    pub version: Option<&'static str>,\n");
    out.push_str("    pub type_kind: TypedElementKind,\n");
    out.push_str("    pub attributes: &'static [ValidationAttributeDescriptor],\n");
    out.push_str("    pub validators: &'static [ValidationValidatorDescriptor],\n");
    out.push_str("    pub particle: Option<ValidationParticleDescriptor>,\n");
    out.push_str("}\n\n");
    out.push_str(&format!(
        "pub const {registry_const_name}: &[ValidationElementDescriptor] = &[\n"
    ));

    for entry in entries {
        out.push_str("    ValidationElementDescriptor {\n");
        out.push_str(&format!(
            "        class_name: {},\n",
            rust_string(&entry.class_name)
        ));
        out.push_str(&format!(
            "        schema_name: {},\n",
            rust_string(&entry.schema_name)
        ));
        out.push_str(&format!(
            "        qualified_name: {},\n",
            rust_string(&entry.qualified_name)
        ));
        out.push_str(&format!(
            "        schema_path: {},\n",
            rust_string(&entry.schema_path)
        ));
        out.push_str(&format!(
            "        version: {},\n",
            rust_option_string(entry.version.as_deref())
        ));
        out.push_str(&format!(
            "        type_kind: {},\n",
            rust_typed_element_kind(entry.type_kind)
        ));
        out.push_str(&format!(
            "        attributes: {},\n",
            rust_validation_attributes(&entry.attributes)
        ));
        out.push_str(&format!(
            "        validators: {},\n",
            rust_validation_validators(&entry.validators)
        ));
        out.push_str(&format!(
            "        particle: {},\n",
            rust_validation_particle_option(entry.particle.as_ref())
        ));
        out.push_str("    },\n");
    }

    out.push_str("];\n\n");
    out.push_str("#[must_use]\n");
    out.push_str("pub fn find_descriptor_by_class(class_name: &str) -> Option<&'static ValidationElementDescriptor> {\n");
    out.push_str(&format!(
        "    {registry_const_name}.iter().find(|descriptor| descriptor.class_name == class_name)\n"
    ));
    out.push_str("}\n\n");
    out.push_str("#[must_use]\n");
    out.push_str("pub fn find_descriptor_by_qualified_name(\n");
    out.push_str("    qualified_name: &str,\n");
    out.push_str(") -> Option<&'static ValidationElementDescriptor> {\n");
    out.push_str(&format!(
        "    {registry_const_name}.iter().find(|descriptor| descriptor.qualified_name == qualified_name)\n"
    ));
    out.push_str("}\n");
    out
}

fn rust_validation_attributes(attributes: &[ValidationAttributeDescriptor]) -> String {
    if attributes.is_empty() {
        return "&[]".to_string();
    }

    let rendered = attributes
        .iter()
        .map(|attribute| {
            format!(
                "ValidationAttributeDescriptor {{ q_name: {}, normalized_q_name: {}, value_type: {}, version: {}, validators: {}, enum_values: {} }}",
                rust_string(&attribute.q_name),
                rust_string(&attribute.normalized_q_name),
                rust_option_string(attribute.value_type.as_deref()),
                rust_option_string(attribute.version.as_deref()),
                rust_validation_validators(&attribute.validators),
                rust_static_string_slice(&attribute.enum_values),
            )
        })
        .collect::<Vec<_>>()
        .join(", ");
    format!("&[{rendered}]")
}

fn rust_validation_validators(validators: &[ValidationValidatorDescriptor]) -> String {
    if validators.is_empty() {
        return "&[]".to_string();
    }

    let rendered = validators
        .iter()
        .map(|validator| {
            format!(
                "ValidationValidatorDescriptor {{ kind: {}, simple_type: {}, union_id: {}, is_initial_version: {}, arguments: {}, enum_values: {} }}",
                rust_validation_validator_kind(validator.kind),
                rust_option_string(validator.simple_type.as_deref()),
                rust_optional_i32(validator.union_id),
                if validator.is_initial_version { "true" } else { "false" },
                rust_validation_validator_arguments(&validator.arguments),
                rust_static_string_slice(&validator.enum_values),
            )
        })
        .collect::<Vec<_>>()
        .join(", ");
    format!("&[{rendered}]")
}

fn rust_validation_validator_arguments(arguments: &[ValidationValidatorArgument]) -> String {
    if arguments.is_empty() {
        return "&[]".to_string();
    }

    let rendered = arguments
        .iter()
        .map(|argument| {
            format!(
                "ValidationValidatorArgument {{ argument_type: {}, name: {}, value: {} }}",
                rust_string(&argument.argument_type),
                rust_option_string(argument.name.as_deref()),
                rust_string(&argument.value),
            )
        })
        .collect::<Vec<_>>()
        .join(", ");
    format!("&[{rendered}]")
}

fn rust_validation_particle_option(particle: Option<&ValidationParticleDescriptor>) -> String {
    particle
        .map(|particle| format!("Some({})", rust_validation_particle(particle)))
        .unwrap_or_else(|| "None".to_string())
}

fn rust_validation_particle(particle: &ValidationParticleDescriptor) -> String {
    format!(
        "ValidationParticleDescriptor {{ kind: {}, schema_name: {}, qualified_name: {}, min_occurs: {}, max_occurs: {}, initial_version: {}, items: {} }}",
        rust_validation_particle_kind(particle.kind),
        rust_option_string(particle.schema_name.as_deref()),
        rust_option_string(particle.qualified_name.as_deref()),
        particle.min_occurs,
        rust_optional_u32(particle.max_occurs),
        rust_option_string(particle.initial_version.as_deref()),
        rust_validation_particles(&particle.items),
    )
}

fn rust_validation_particles(items: &[ValidationParticleDescriptor]) -> String {
    if items.is_empty() {
        return "&[]".to_string();
    }

    let rendered = items
        .iter()
        .map(rust_validation_particle)
        .collect::<Vec<_>>()
        .join(", ");
    format!("&[{rendered}]")
}

fn rust_validation_validator_kind(kind: ValidationValidatorKind) -> &'static str {
    match kind {
        ValidationValidatorKind::Required => "ValidationValidatorKind::Required",
        ValidationValidatorKind::String => "ValidationValidatorKind::String",
        ValidationValidatorKind::Number => "ValidationValidatorKind::Number",
        ValidationValidatorKind::Enum => "ValidationValidatorKind::Enum",
        ValidationValidatorKind::OfficeVersion => "ValidationValidatorKind::OfficeVersion",
    }
}

fn rust_validation_particle_kind(kind: ValidationParticleKind) -> &'static str {
    match kind {
        ValidationParticleKind::Element => "ValidationParticleKind::Element",
        ValidationParticleKind::Sequence => "ValidationParticleKind::Sequence",
        ValidationParticleKind::Choice => "ValidationParticleKind::Choice",
        ValidationParticleKind::All => "ValidationParticleKind::All",
        ValidationParticleKind::Group => "ValidationParticleKind::Group",
        ValidationParticleKind::Any => "ValidationParticleKind::Any",
    }
}

fn rust_optional_i32(value: Option<i32>) -> String {
    value
        .map(|value| format!("Some({value})"))
        .unwrap_or_else(|| "None".to_string())
}

fn rust_optional_u32(value: Option<u32>) -> String {
    value
        .map(|value| format!("Some({value})"))
        .unwrap_or_else(|| "None".to_string())
}

fn render_schematron_registry_module(rules: &[SchematronRule]) -> String {
    let mut rules = rules.to_vec();
    rules.sort_by(|left, right| {
        left.context
            .cmp(&right.context)
            .then(left.test.cmp(&right.test))
            .then(left.app.cmp(&right.app))
    });

    let mut out = String::new();
    out.push_str("// @generated by offidized-codegen. Do not edit manually.\n");
    out.push_str("// OOXML schematron/semantic rules from Open-XML-SDK `schematrons.json`.\n\n");
    out.push_str("#[derive(Debug, Clone, Copy, PartialEq, Eq)]\n");
    out.push_str("pub struct SchematronRuleEntry {\n");
    out.push_str("    pub context: &'static str,\n");
    out.push_str("    pub test: &'static str,\n");
    out.push_str("    pub app: &'static str,\n");
    out.push_str("    pub version: Option<&'static str>,\n");
    out.push_str("}\n\n");
    out.push_str("pub const SCHEMATRON_RULES: &[SchematronRuleEntry] = &[\n");

    for rule in rules {
        out.push_str("    SchematronRuleEntry {\n");
        out.push_str(&format!(
            "        context: {},\n",
            rust_string(&rule.context)
        ));
        out.push_str(&format!("        test: {},\n", rust_string(&rule.test)));
        out.push_str(&format!("        app: {},\n", rust_string(&rule.app)));
        out.push_str(&format!(
            "        version: {},\n",
            rust_option_string(rule.version.as_deref())
        ));
        out.push_str("    },\n");
    }

    out.push_str("];\n");
    out
}

fn render_typed_api_module(
    label: &str,
    registry_module_name: &str,
    entries: &[TypedElementDescriptor],
) -> String {
    let mut entries = entries.to_vec();
    entries.sort_by(|left, right| {
        left.class_name
            .cmp(&right.class_name)
            .then(left.schema_path.cmp(&right.schema_path))
    });

    let unique_entries = entries.into_iter().fold(Vec::new(), |mut acc, entry| {
        if acc
            .iter()
            .all(|candidate: &TypedElementDescriptor| candidate.class_name != entry.class_name)
        {
            acc.push(entry);
        }
        acc
    });

    let mut out = String::new();
    out.push_str("// @generated by offidized-codegen. Do not edit manually.\n");
    out.push_str(&format!(
        "// Per-element typed wrapper API for {label} main namespace.\n\n"
    ));
    out.push_str(&format!("use super::{registry_module_name} as registry;\n"));
    out.push_str("use crate::catalog::TypedElementXmlError;\n\n");
    out.push_str("pub type TypedElement = registry::TypedElement;\n");
    out.push_str("pub type TypedElementDescriptor = registry::TypedElementDescriptor;\n\n");

    for entry in unique_entries {
        let struct_name = rust_type_ident(&entry.class_name);
        out.push_str("#[derive(Debug, Clone)]\n");
        out.push_str(&format!("pub struct {struct_name} {{\n"));
        out.push_str("    inner: TypedElement,\n");
        out.push_str("}\n\n");
        out.push_str(&format!("impl {struct_name} {{\n"));
        out.push_str(
            "    pub fn descriptor() -> Result<&'static TypedElementDescriptor, TypedElementXmlError> {\n",
        );
        out.push_str(&format!(
            "        registry::find_descriptor_by_class({})\n",
            rust_string(&entry.class_name)
        ));
        out.push_str(&format!(
            "            .ok_or_else(|| TypedElementXmlError::UnknownClassName({}.to_owned()))\n",
            rust_string(&entry.class_name)
        ));
        out.push_str("    }\n\n");
        out.push_str("    pub fn new() -> Result<Self, TypedElementXmlError> {\n");
        out.push_str("        Ok(Self {\n");
        out.push_str("            inner: TypedElement::new(Self::descriptor()?),\n");
        out.push_str("        })\n");
        out.push_str("    }\n\n");
        out.push_str(
            "    pub fn from_typed_element(inner: TypedElement) -> Result<Self, TypedElementXmlError> {\n",
        );
        out.push_str("        let descriptor = Self::descriptor()?;\n");
        out.push_str("        if inner.descriptor.qualified_name != descriptor.qualified_name {\n");
        out.push_str("            return Err(TypedElementXmlError::UnexpectedRoot {\n");
        out.push_str("                expected: descriptor.qualified_name,\n");
        out.push_str("                found: inner.descriptor.qualified_name.to_owned(),\n");
        out.push_str("            });\n");
        out.push_str("        }\n");
        out.push_str("        Ok(Self { inner })\n");
        out.push_str("    }\n\n");
        out.push_str("    pub fn parse(snippet: &str) -> Result<Self, TypedElementXmlError> {\n");
        out.push_str(&format!(
            "        registry::parse_typed_element_for_class({}, snippet)\n",
            rust_string(&entry.class_name)
        ));
        out.push_str("            .map(|inner| Self { inner })\n");
        out.push_str("    }\n\n");
        out.push_str("    pub fn to_xml(&self) -> Result<String, TypedElementXmlError> {\n");
        out.push_str("        self.inner.to_xml_snippet()\n");
        out.push_str("    }\n\n");
        out.push_str("    #[must_use]\n");
        out.push_str("    pub fn inner(&self) -> &TypedElement {\n");
        out.push_str("        &self.inner\n");
        out.push_str("    }\n\n");
        out.push_str("    #[must_use]\n");
        out.push_str("    pub fn inner_mut(&mut self) -> &mut TypedElement {\n");
        out.push_str("        &mut self.inner\n");
        out.push_str("    }\n\n");
        out.push_str("    #[must_use]\n");
        out.push_str("    pub fn into_inner(self) -> TypedElement {\n");
        out.push_str("        self.inner\n");
        out.push_str("    }\n");

        for (attribute_name, method_suffix) in known_attribute_methods(&entry.known_attributes) {
            out.push_str("\n    #[must_use]\n");
            out.push_str(&format!(
                "    pub fn {method_suffix}(&self) -> Option<&str> {{\n"
            ));
            out.push_str(&format!(
                "        self.inner.known_attrs.get({}).map(String::as_str)\n",
                rust_string(&attribute_name)
            ));
            out.push_str("    }\n\n");
            out.push_str(&format!(
                "    pub fn set_{method_suffix}(&mut self, value: impl Into<String>) -> &mut Self {{\n"
            ));
            out.push_str("        self.inner\n");
            out.push_str("            .known_attrs\n");
            out.push_str(&format!(
                "            .insert({}.to_owned(), value.into());\n",
                rust_string(&attribute_name)
            ));
            out.push_str("        self\n");
            out.push_str("    }\n\n");
            out.push_str(&format!(
                "    pub fn clear_{method_suffix}(&mut self) -> &mut Self {{\n"
            ));
            out.push_str(&format!(
                "        self.inner.known_attrs.remove({});\n",
                rust_string(&attribute_name)
            ));
            out.push_str("        self\n");
            out.push_str("    }\n");
        }

        out.push_str("}\n\n");
    }

    out
}

fn render_namespace_registry_module(data: &OpenXmlSdkData) -> String {
    let mut namespaces = data.namespaces.clone();
    namespaces.sort_by(|left, right| {
        left.prefix
            .cmp(&right.prefix)
            .then(left.uri.cmp(&right.uri))
    });

    let mut out = String::new();
    out.push_str("// @generated by offidized-codegen. Do not edit manually.\n");
    out.push_str("// OOXML namespace registry from Open-XML-SDK `namespaces.json`.\n\n");
    out.push_str("#[derive(Debug, Clone, Copy, PartialEq, Eq)]\n");
    out.push_str("pub struct NamespaceRegistryEntry {\n");
    out.push_str("    pub prefix: &'static str,\n");
    out.push_str("    pub uri: &'static str,\n");
    out.push_str("    pub version: Option<&'static str>,\n");
    out.push_str("}\n\n");
    out.push_str("pub const NAMESPACE_REGISTRY: &[NamespaceRegistryEntry] = &[\n");

    for namespace in namespaces {
        out.push_str("    NamespaceRegistryEntry {\n");
        out.push_str(&format!(
            "        prefix: {},\n",
            rust_string(&namespace.prefix)
        ));
        out.push_str(&format!("        uri: {},\n", rust_string(&namespace.uri)));
        out.push_str(&format!(
            "        version: {},\n",
            rust_option_string(namespace.version.as_deref())
        ));
        out.push_str("    },\n");
    }

    out.push_str("];\n\n");
    out.push_str("#[must_use]\n");
    out.push_str("pub fn find_uri_by_prefix(prefix: &str) -> Option<&'static str> {\n");
    out.push_str("    NAMESPACE_REGISTRY\n");
    out.push_str("        .iter()\n");
    out.push_str("        .find(|entry| entry.prefix == prefix)\n");
    out.push_str("        .map(|entry| entry.uri)\n");
    out.push_str("}\n\n");
    out.push_str("#[must_use]\n");
    out.push_str("pub fn find_prefix_by_uri(uri: &str) -> Option<&'static str> {\n");
    out.push_str("    NAMESPACE_REGISTRY\n");
    out.push_str("        .iter()\n");
    out.push_str("        .find(|entry| entry.uri == uri)\n");
    out.push_str("        .map(|entry| entry.prefix)\n");
    out.push_str("}\n");
    out
}

fn render_part_registry_module(data: &OpenXmlSdkData) -> String {
    let mut parts = data.parts.values().cloned().collect::<Vec<_>>();
    parts.sort_by(|left, right| left.name.cmp(&right.name));

    let mut out = String::new();
    out.push_str("// @generated by offidized-codegen. Do not edit manually.\n");
    out.push_str("// Shared OOXML part registry from Open-XML-SDK `parts/*.json`.\n\n");
    out.push_str("#[derive(Debug, Clone, Copy, PartialEq, Eq)]\n");
    out.push_str("pub struct PartChildRegistryEntry {\n");
    out.push_str("    pub name: &'static str,\n");
    out.push_str("    pub api_name: Option<&'static str>,\n");
    out.push_str("    pub has_fixed_content: bool,\n");
    out.push_str("    pub is_data_part_reference: bool,\n");
    out.push_str("    pub is_special_embedded_part: bool,\n");
    out.push_str("    pub max_occurs_great_than_one: bool,\n");
    out.push_str("    pub min_occurs_is_non_zero: bool,\n");
    out.push_str("}\n\n");
    out.push_str("#[derive(Debug, Clone, Copy, PartialEq, Eq)]\n");
    out.push_str("pub struct PartPathRegistryEntry {\n");
    out.push_str("    pub general: Option<&'static str>,\n");
    out.push_str("    pub excel: Option<&'static str>,\n");
    out.push_str("    pub word: Option<&'static str>,\n");
    out.push_str("    pub power_point: Option<&'static str>,\n");
    out.push_str("}\n\n");
    out.push_str("#[derive(Debug, Clone, Copy, PartialEq, Eq)]\n");
    out.push_str("pub struct PartRegistryEntry {\n");
    out.push_str("    pub name: &'static str,\n");
    out.push_str("    pub base: &'static str,\n");
    out.push_str("    pub relationship_type: Option<&'static str>,\n");
    out.push_str("    pub target: Option<&'static str>,\n");
    out.push_str("    pub root: Option<&'static str>,\n");
    out.push_str("    pub root_element: Option<&'static str>,\n");
    out.push_str("    pub content_type: Option<&'static str>,\n");
    out.push_str("    pub extension: Option<&'static str>,\n");
    out.push_str("    pub version: Option<&'static str>,\n");
    out.push_str("    pub paths: PartPathRegistryEntry,\n");
    out.push_str("    pub children: &'static [PartChildRegistryEntry],\n");
    out.push_str("}\n\n");
    out.push_str("pub const SHARED_PART_REGISTRY: &[PartRegistryEntry] = &[\n");

    for part in parts {
        out.push_str(&render_part_entry(&part));
    }

    out.push_str("];\n");
    out
}

fn render_part_entry(part: &PartDefinition) -> String {
    let mut out = String::new();
    out.push_str("    PartRegistryEntry {\n");
    out.push_str(&format!("        name: {},\n", rust_string(&part.name)));
    out.push_str(&format!("        base: {},\n", rust_string(&part.base)));
    out.push_str(&format!(
        "        relationship_type: {},\n",
        rust_option_string(part.relationship_type.as_deref())
    ));
    out.push_str(&format!(
        "        target: {},\n",
        rust_option_string(part.target.as_deref())
    ));
    out.push_str(&format!(
        "        root: {},\n",
        rust_option_string(part.root.as_deref())
    ));
    out.push_str(&format!(
        "        root_element: {},\n",
        rust_option_string(part.root_element.as_deref())
    ));
    out.push_str(&format!(
        "        content_type: {},\n",
        rust_option_string(part.content_type.as_deref())
    ));
    out.push_str(&format!(
        "        extension: {},\n",
        rust_option_string(part.extension.as_deref())
    ));
    out.push_str(&format!(
        "        version: {},\n",
        rust_option_string(part.version.as_deref())
    ));
    out.push_str("        paths: ");
    out.push_str(&render_part_paths(&part.paths));
    out.push_str(",\n");
    out.push_str("        children: &[\n");

    for child in &part.children {
        out.push_str(&render_part_child_entry(child));
    }

    out.push_str("        ],\n");
    out.push_str("    },\n");
    out
}

fn render_part_paths(paths: &PartPaths) -> String {
    format!(
        "PartPathRegistryEntry {{ general: {}, excel: {}, word: {}, power_point: {} }}",
        rust_option_string(paths.general.as_deref()),
        rust_option_string(paths.excel.as_deref()),
        rust_option_string(paths.word.as_deref()),
        rust_option_string(paths.power_point.as_deref())
    )
}

fn render_part_child_entry(child: &PartChildDefinition) -> String {
    let mut out = String::new();
    out.push_str("            PartChildRegistryEntry {\n");
    out.push_str(&format!(
        "                name: {},\n",
        rust_string(&child.name)
    ));
    out.push_str(&format!(
        "                api_name: {},\n",
        rust_option_string(child.api_name.as_deref())
    ));
    out.push_str(&format!(
        "                has_fixed_content: {},\n",
        child.has_fixed_content
    ));
    out.push_str(&format!(
        "                is_data_part_reference: {},\n",
        child.is_data_part_reference
    ));
    out.push_str(&format!(
        "                is_special_embedded_part: {},\n",
        child.is_special_embedded_part
    ));
    out.push_str(&format!(
        "                max_occurs_great_than_one: {},\n",
        child.max_occurs_great_than_one
    ));
    out.push_str(&format!(
        "                min_occurs_is_non_zero: {},\n",
        child.min_occurs_is_non_zero
    ));
    out.push_str("            },\n");
    out
}

fn rust_type_ident(value: &str) -> String {
    let mut ident = String::new();
    for (index, ch) in value.chars().enumerate() {
        if ch.is_ascii_alphanumeric() || ch == '_' {
            if index == 0 && ch.is_ascii_digit() {
                ident.push('_');
            }
            ident.push(ch);
        } else if !ident.ends_with('_') {
            ident.push('_');
        }
    }
    while ident.ends_with('_') {
        ident.pop();
    }
    if ident.is_empty() {
        ident.push_str("GeneratedElement");
    }
    if is_rust_keyword(&ident) {
        ident.push('_');
    }
    ident
}

fn known_attribute_methods(attributes: &[String]) -> Vec<(String, String)> {
    let mut used_method_names = std::collections::BTreeSet::new();
    attributes
        .iter()
        .map(|attribute_name| {
            let base_name = rust_method_ident(attribute_name);
            let mut method_name = if is_reserved_wrapper_method_name(&base_name) {
                format!("{base_name}_attr")
            } else {
                base_name
            };

            if !used_method_names.insert(method_name.clone()) {
                let base = method_name.clone();
                let mut suffix = 2usize;
                loop {
                    let candidate = format!("{base}_{suffix}");
                    if used_method_names.insert(candidate.clone()) {
                        method_name = candidate;
                        break;
                    }
                    suffix += 1;
                }
            }

            (attribute_name.clone(), method_name)
        })
        .collect()
}

fn rust_method_ident(value: &str) -> String {
    let mut ident = String::new();
    let mut needs_underscore = false;

    for ch in value.chars() {
        if ch.is_ascii_alphanumeric() {
            if needs_underscore && !ident.is_empty() && !ident.ends_with('_') {
                ident.push('_');
            }
            ident.push(ch.to_ascii_lowercase());
            needs_underscore = false;
        } else {
            needs_underscore = true;
        }
    }

    while ident.ends_with('_') {
        ident.pop();
    }

    if ident.is_empty() {
        ident.push_str("attribute");
    }
    if ident.starts_with(|ch: char| ch.is_ascii_digit()) {
        ident.insert(0, '_');
    }
    if is_rust_keyword(&ident) {
        ident.push('_');
    }
    ident
}

fn is_reserved_wrapper_method_name(method_name: &str) -> bool {
    matches!(
        method_name,
        "descriptor"
            | "new"
            | "from_typed_element"
            | "parse"
            | "to_xml"
            | "inner"
            | "inner_mut"
            | "into_inner"
    )
}

fn is_rust_keyword(identifier: &str) -> bool {
    matches!(
        identifier,
        "as" | "break"
            | "const"
            | "continue"
            | "crate"
            | "else"
            | "enum"
            | "extern"
            | "false"
            | "fn"
            | "for"
            | "if"
            | "impl"
            | "in"
            | "let"
            | "loop"
            | "match"
            | "mod"
            | "move"
            | "mut"
            | "pub"
            | "ref"
            | "return"
            | "self"
            | "Self"
            | "static"
            | "struct"
            | "super"
            | "trait"
            | "true"
            | "type"
            | "unsafe"
            | "use"
            | "where"
            | "while"
            | "async"
            | "await"
            | "dyn"
            | "abstract"
            | "become"
            | "box"
            | "do"
            | "final"
            | "macro"
            | "override"
            | "priv"
            | "typeof"
            | "unsized"
            | "virtual"
            | "yield"
            | "try"
    )
}

fn rust_string(value: &str) -> String {
    format!("{value:?}")
}

fn rust_static_string_slice(values: &[String]) -> String {
    if values.is_empty() {
        "&[]".to_owned()
    } else {
        let inner = values
            .iter()
            .map(|value| rust_string(value))
            .collect::<Vec<_>>()
            .join(", ");
        format!("&[{inner}]")
    }
}

fn rust_option_string(value: Option<&str>) -> String {
    value.map_or_else(
        || "None".to_owned(),
        |inner| format!("Some({})", rust_string(inner)),
    )
}

fn rust_typed_element_kind(kind: TypedElementKind) -> &'static str {
    match kind {
        TypedElementKind::Leaf => "TypedElementKind::Leaf",
        TypedElementKind::Composite => "TypedElementKind::Composite",
        TypedElementKind::TypedLeaf => "TypedElementKind::TypedLeaf",
    }
}

#[cfg(test)]
#[allow(clippy::panic_in_result_fn)]
mod tests {
    use std::fs;
    use std::path::PathBuf;

    use anyhow::Result;

    use crate::schema::load_openxml_sdk_data;

    use super::{
        generate_schema_registries, NAMESPACE_REGISTRY_MODULE_FILE, PRESENTATION_MODULE_FILE,
        PRESENTATION_TYPED_API_MODULE_FILE, PRESENTATION_VALIDATION_MODULE_FILE,
        SCHEMATRON_MODULE_FILE, SHARED_PARTS_MODULE_FILE, SPREADSHEET_MODULE_FILE,
        SPREADSHEET_TYPED_API_MODULE_FILE, SPREADSHEET_VALIDATION_MODULE_FILE,
        SUPPLEMENTAL_VALIDATION_MODULE_FILE, WORD_MODULE_FILE, WORD_TYPED_API_MODULE_FILE,
        WORD_VALIDATION_MODULE_FILE,
    };

    #[test]
    fn generator_writes_expected_registry_files() -> Result<()> {
        let Some(data_root) = test_data_root_if_present() else {
            eprintln!("SKIP: Open-XML-SDK reference data not found");
            return Ok(());
        };
        let data = load_openxml_sdk_data(data_root)?;
        let temp_dir = tempfile::tempdir()?;

        let output = generate_schema_registries(&data, temp_dir.path())?;

        assert_eq!(output.files.len(), 13);
        assert!(output.files.iter().all(|path| path.exists()));

        let generated_names = output
            .files
            .iter()
            .filter_map(|path| path.file_name().and_then(|name| name.to_str()))
            .collect::<Vec<_>>();
        assert!(generated_names.contains(&SPREADSHEET_MODULE_FILE));
        assert!(generated_names.contains(&SPREADSHEET_TYPED_API_MODULE_FILE));
        assert!(generated_names.contains(&SPREADSHEET_VALIDATION_MODULE_FILE));
        assert!(generated_names.contains(&WORD_MODULE_FILE));
        assert!(generated_names.contains(&WORD_TYPED_API_MODULE_FILE));
        assert!(generated_names.contains(&WORD_VALIDATION_MODULE_FILE));
        assert!(generated_names.contains(&PRESENTATION_MODULE_FILE));
        assert!(generated_names.contains(&PRESENTATION_TYPED_API_MODULE_FILE));
        assert!(generated_names.contains(&PRESENTATION_VALIDATION_MODULE_FILE));
        assert!(generated_names.contains(&SUPPLEMENTAL_VALIDATION_MODULE_FILE));
        assert!(generated_names.contains(&NAMESPACE_REGISTRY_MODULE_FILE));
        assert!(generated_names.contains(&SHARED_PARTS_MODULE_FILE));

        Ok(())
    }

    #[test]
    fn generated_main_modules_contain_expected_entries() -> Result<()> {
        let Some(data_root) = test_data_root_if_present() else {
            eprintln!("SKIP: Open-XML-SDK reference data not found");
            return Ok(());
        };
        let data = load_openxml_sdk_data(data_root)?;
        let temp_dir = tempfile::tempdir()?;
        generate_schema_registries(&data, temp_dir.path())?;

        let spreadsheet_source = fs::read_to_string(temp_dir.path().join(SPREADSHEET_MODULE_FILE))?;
        assert!(spreadsheet_source.contains(
            "pub const NAMESPACE_URI: &str = \"http://schemas.openxmlformats.org/spreadsheetml/2006/main\";"
        ));
        assert!(spreadsheet_source.contains("pub struct TypedElementDescriptor"));
        assert!(spreadsheet_source.contains("pub enum TypedElementKind"));
        assert!(spreadsheet_source.contains("pub struct TypedElement"));
        assert!(spreadsheet_source.contains("pub known_attrs: BTreeMap<String, String>"));
        assert!(spreadsheet_source.contains("pub unknown_attrs: Vec<(String, String)>"));
        assert!(spreadsheet_source.contains("pub unknown_children: Vec<RawXmlNode>"));
        assert!(spreadsheet_source.contains("pub fn from_xml_snippet"));
        assert!(spreadsheet_source.contains("pub fn to_xml_snippet"));
        assert!(spreadsheet_source.contains("class_name: \"Workbook\""));
        assert!(spreadsheet_source.contains("qualified_name: \"x:workbook\""));
        assert!(spreadsheet_source.contains("schema_path: \"/x:workbook\""));
        assert!(spreadsheet_source.contains("type_kind: TypedElementKind::Composite"));
        assert!(spreadsheet_source.contains("known_attributes: "));
        assert!(!spreadsheet_source.contains("part_class_name"));

        let word_source = fs::read_to_string(temp_dir.path().join(WORD_MODULE_FILE))?;
        assert!(word_source.contains(
            "pub const NAMESPACE_URI: &str = \"http://schemas.openxmlformats.org/wordprocessingml/2006/main\";"
        ));
        assert!(word_source.contains("class_name: \"Document\""));
        assert!(word_source.contains("qualified_name: \"w:document\""));
        assert!(word_source.contains("type_kind: TypedElementKind::Composite"));
        assert!(word_source.contains("class_name: \"Text\""));
        assert!(word_source.contains("qualified_name: \"w:t\""));
        assert!(word_source.contains("type_kind: TypedElementKind::TypedLeaf"));
        assert!(word_source.contains("\"xml:space\""));

        let presentation_source =
            fs::read_to_string(temp_dir.path().join(PRESENTATION_MODULE_FILE))?;
        assert!(presentation_source.contains(
            "pub const NAMESPACE_URI: &str = \"http://schemas.openxmlformats.org/presentationml/2006/main\";"
        ));
        assert!(presentation_source.contains("class_name: \"Presentation\""));
        assert!(presentation_source.contains("qualified_name: \"p:presentation\""));
        assert!(presentation_source.contains("type_kind: TypedElementKind::Composite"));
        assert!(presentation_source.contains("class_name: \"SlideAll\""));
        assert!(presentation_source.contains("qualified_name: \"p:sldAll\""));
        assert!(presentation_source.contains("type_kind: TypedElementKind::Leaf"));

        let spreadsheet_typed_api_source =
            fs::read_to_string(temp_dir.path().join(SPREADSHEET_TYPED_API_MODULE_FILE))?;
        assert!(spreadsheet_typed_api_source.contains("pub struct Workbook"));
        assert!(spreadsheet_typed_api_source.contains("pub fn descriptor()"));
        assert!(spreadsheet_typed_api_source.contains("pub fn parse(snippet: &str)"));
        assert!(spreadsheet_typed_api_source.contains("pub fn to_xml(&self)"));
        assert!(spreadsheet_typed_api_source.contains("pub fn conformance(&self)"));
        assert!(spreadsheet_typed_api_source.contains("pub fn set_conformance("));
        assert!(spreadsheet_typed_api_source.contains("pub fn clear_conformance("));

        let word_typed_api_source =
            fs::read_to_string(temp_dir.path().join(WORD_TYPED_API_MODULE_FILE))?;
        assert!(word_typed_api_source.contains("pub struct Document"));
        assert!(word_typed_api_source.contains("pub fn parse(snippet: &str)"));
        assert!(word_typed_api_source.contains("pub fn to_xml(&self)"));
        assert!(word_typed_api_source.contains("pub struct Text"));
        assert!(word_typed_api_source.contains("pub fn xml_space(&self)"));

        let presentation_typed_api_source =
            fs::read_to_string(temp_dir.path().join(PRESENTATION_TYPED_API_MODULE_FILE))?;
        assert!(presentation_typed_api_source.contains("pub struct Presentation"));
        assert!(presentation_typed_api_source.contains("pub fn parse(snippet: &str)"));
        assert!(presentation_typed_api_source.contains("pub fn to_xml(&self)"));

        let spreadsheet_validation_source =
            fs::read_to_string(temp_dir.path().join(SPREADSHEET_VALIDATION_MODULE_FILE))?;
        assert!(spreadsheet_validation_source.contains("pub struct ValidationElementDescriptor"));
        assert!(spreadsheet_validation_source.contains("SPREADSHEETML_MAIN_VALIDATION_REGISTRY"));
        assert!(spreadsheet_validation_source.contains("class_name: \"Workbook\""));
        assert!(spreadsheet_validation_source.contains("qualified_name: \"x:workbook\""));

        let word_validation_source =
            fs::read_to_string(temp_dir.path().join(WORD_VALIDATION_MODULE_FILE))?;
        assert!(word_validation_source.contains("WORDPROCESSINGML_MAIN_VALIDATION_REGISTRY"));
        assert!(word_validation_source.contains("class_name: \"Document\""));
        assert!(word_validation_source.contains("ValidationParticleKind::Sequence"));
        assert!(word_validation_source.contains("ValidationValidatorKind::Required"));

        let presentation_validation_source =
            fs::read_to_string(temp_dir.path().join(PRESENTATION_VALIDATION_MODULE_FILE))?;
        assert!(presentation_validation_source.contains("PRESENTATIONML_MAIN_VALIDATION_REGISTRY"));
        assert!(presentation_validation_source.contains("class_name: \"Presentation\""));
        assert!(presentation_validation_source.contains("bookmarkIdSeed"));

        let supplemental_validation_source =
            fs::read_to_string(temp_dir.path().join(SUPPLEMENTAL_VALIDATION_MODULE_FILE))?;
        assert!(supplemental_validation_source.contains("SUPPLEMENTAL_VALIDATION_REGISTRY"));
        assert!(supplemental_validation_source.contains("class_name: \"ChartSpace\""));
        assert!(supplemental_validation_source.contains("qualified_name: \"c:chartSpace\""));
        assert!(supplemental_validation_source.contains("qualified_name: \"pic:pic\""));
        assert!(supplemental_validation_source.contains("schema_name: \"pic:CT_Picture/pic:pic\""));
        assert!(supplemental_validation_source.contains("qualified_name: \"a14:contentPart\""));
        assert!(supplemental_validation_source
            .contains("schema_name: \"a14:CT_GvmlContentPart/a14:contentPart\""));
        assert!(supplemental_validation_source.contains("qualified_name: \"a15:signatureLine\""));
        assert!(supplemental_validation_source
            .contains("schema_name: \"a15:CT_SignatureLine/a15:signatureLine\""));
        assert!(supplemental_validation_source.contains("qualified_name: \"pic14:style\""));
        assert!(
            supplemental_validation_source.contains("schema_name: \"a:CT_ShapeStyle/pic14:style\"")
        );
        assert!(supplemental_validation_source.contains("qualified_name: \"lc:lockedCanvas\""));
        assert!(supplemental_validation_source
            .contains("schema_name: \"a:CT_GvmlGroupShape/lc:lockedCanvas\""));
        assert!(supplemental_validation_source.contains("class_name: \"RelativeAnchorSize\""));
        assert!(supplemental_validation_source.contains("qualified_name: \"cdr:relSizeAnchor\""));
        assert!(supplemental_validation_source.contains("class_name: \"ContentPart\""));
        assert!(supplemental_validation_source.contains("qualified_name: \"cdr14:contentPart\""));
        assert!(supplemental_validation_source.contains("class_name: \"Paragraph\""));
        assert!(supplemental_validation_source.contains("qualified_name: \"a:p\""));
        assert!(supplemental_validation_source.contains("class_name: \"WordprocessingShape\""));
        assert!(supplemental_validation_source.contains("qualified_name: \"wps:wsp\""));
        assert!(supplemental_validation_source
            .contains("schema_name: \"wps:CT_WordprocessingShape/wps:wsp\""));
        assert!(supplemental_validation_source.contains("class_name: \"WordprocessingCanvas\""));
        assert!(supplemental_validation_source.contains("qualified_name: \"wpc:wpc\""));
        assert!(supplemental_validation_source
            .contains("schema_name: \"wpc:CT_WordprocessingCanvas/wpc:wpc\""));
        assert!(supplemental_validation_source.contains("class_name: \"WordprocessingGroup\""));
        assert!(supplemental_validation_source.contains("qualified_name: \"wpg:wgp\""));
        assert!(supplemental_validation_source
            .contains("schema_name: \"wpg:CT_WordprocessingGroup/wpg:wgp\""));
        assert!(supplemental_validation_source.contains("class_name: \"RelativeWidth\""));
        assert!(supplemental_validation_source.contains("qualified_name: \"wp14:sizeRelH\""));
        assert!(supplemental_validation_source
            .contains("schema_name: \"wp14:CT_SizeRelH/wp14:sizeRelH\""));
        assert!(supplemental_validation_source.contains("class_name: \"WebVideoProperty\""));
        assert!(supplemental_validation_source.contains("qualified_name: \"wp15:webVideoPr\""));
        assert!(supplemental_validation_source
            .contains("schema_name: \"wp15:CT_WebVideoPr/wp15:webVideoPr\""));
        assert!(supplemental_validation_source.contains("class_name: \"Appearance\""));
        assert!(supplemental_validation_source.contains("qualified_name: \"w15:appearance\""));
        assert!(supplemental_validation_source
            .contains("schema_name: \"w15:CT_SdtAppearance/w15:appearance\""));
        assert!(supplemental_validation_source.contains("class_name: \"Properties\""));
        assert!(supplemental_validation_source.contains("qualified_name: \"op:Properties\""));
        assert!(supplemental_validation_source.contains("qualified_name: \"ap:Properties\""));
        assert!(supplemental_validation_source.contains("class_name: \"VTVector\""));
        assert!(supplemental_validation_source.contains("qualified_name: \"vt:vector\""));
        assert!(supplemental_validation_source.contains("class_name: \"Fraction\""));
        assert!(supplemental_validation_source.contains("qualified_name: \"m:f\""));
        assert!(supplemental_validation_source.contains("class_name: \"Shape\""));
        assert!(supplemental_validation_source.contains("qualified_name: \"v:shape\""));

        let schematron_source = fs::read_to_string(temp_dir.path().join(SCHEMATRON_MODULE_FILE))?;
        assert!(schematron_source.contains("pub const SCHEMATRON_RULES"));
        assert!(schematron_source.contains("context: \"x:sheet\""));
        assert!(schematron_source.contains("count(distinct-values(lower-case(//x:sheet/@x:name))) = count(lower-case(//x:sheet/@x:name))"));

        let namespace_registry_source =
            fs::read_to_string(temp_dir.path().join(NAMESPACE_REGISTRY_MODULE_FILE))?;
        assert!(namespace_registry_source.contains("pub const NAMESPACE_REGISTRY"));
        assert!(namespace_registry_source.contains("prefix: \"a\""));
        assert!(namespace_registry_source
            .contains("uri: \"http://schemas.openxmlformats.org/drawingml/2006/main\""));

        Ok(())
    }

    #[test]
    fn generated_shared_part_registry_contains_known_parts() -> Result<()> {
        let Some(data_root) = test_data_root_if_present() else {
            eprintln!("SKIP: Open-XML-SDK reference data not found");
            return Ok(());
        };
        let data = load_openxml_sdk_data(data_root)?;
        let temp_dir = tempfile::tempdir()?;
        generate_schema_registries(&data, temp_dir.path())?;

        let parts_source = fs::read_to_string(temp_dir.path().join(SHARED_PARTS_MODULE_FILE))?;
        assert!(parts_source.contains("pub const SHARED_PART_REGISTRY: &[PartRegistryEntry] = &["));
        assert!(parts_source.contains("name: \"WorkbookPart\""));
        assert!(parts_source.contains(
            "relationship_type: Some(\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\")"
        ));
        assert!(parts_source.contains("name: \"MainDocumentPart\""));
        assert!(parts_source.contains("name: \"PresentationPart\""));

        Ok(())
    }

    fn test_data_root_if_present() -> Option<PathBuf> {
        let root = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../offidized-schema/data");
        root.exists().then_some(root)
    }
}
