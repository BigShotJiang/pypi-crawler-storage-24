use std::collections::{BTreeMap, BTreeSet};
use std::fs;
use std::path::{Path, PathBuf};

use anyhow::{bail, Context, Result};
use serde::de::DeserializeOwned;
use serde::Deserialize;

pub const SPREADSHEETML_MAIN_URI: &str =
    "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
pub const WORDPROCESSINGML_MAIN_URI: &str =
    "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
pub const PRESENTATIONML_MAIN_URI: &str =
    "http://schemas.openxmlformats.org/presentationml/2006/main";
pub const DRAWINGML_MAIN_URI: &str = "http://schemas.openxmlformats.org/drawingml/2006/main";
pub const DRAWINGML_LOCKED_CANVAS_URI: &str =
    "http://schemas.openxmlformats.org/drawingml/2006/lockedCanvas";
pub const DRAWINGML_PICTURE_URI: &str = "http://schemas.openxmlformats.org/drawingml/2006/picture";
pub const DRAWINGML_PICTURE_2010_URI: &str =
    "http://schemas.microsoft.com/office/drawing/2010/picture";
pub const DRAWINGML_CHART_URI: &str = "http://schemas.openxmlformats.org/drawingml/2006/chart";
pub const DRAWINGML_CHART_DRAWING_URI: &str =
    "http://schemas.openxmlformats.org/drawingml/2006/chartDrawing";
pub const DRAWINGML_CHART_DRAWING_2010_URI: &str =
    "http://schemas.microsoft.com/office/drawing/2010/chartDrawing";
pub const DRAWINGML_2010_MAIN_URI: &str = "http://schemas.microsoft.com/office/drawing/2010/main";
pub const DRAWINGML_2012_MAIN_URI: &str = "http://schemas.microsoft.com/office/drawing/2012/main";
pub const DRAWINGML_DIAGRAM_URI: &str = "http://schemas.openxmlformats.org/drawingml/2006/diagram";
pub const DRAWINGML_SPREADSHEET_DRAWING_URI: &str =
    "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing";
pub const DRAWINGML_WORDPROCESSING_DRAWING_URI: &str =
    "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing";
pub const CUSTOM_PROPERTIES_URI: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/custom-properties";
pub const EXTENDED_PROPERTIES_URI: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties";
pub const DOC_PROPS_VTYPES_URI: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes";
pub const OFFICE_MATH_URI: &str = "http://schemas.openxmlformats.org/officeDocument/2006/math";
pub const VML_URI: &str = "urn:schemas-microsoft-com:vml";
pub const WORDPROCESSING_SHAPE_2010_URI: &str =
    "http://schemas.microsoft.com/office/word/2010/wordprocessingShape";
pub const WORDPROCESSING_CANVAS_2010_URI: &str =
    "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas";
pub const WORDPROCESSING_DRAWING_2010_URI: &str =
    "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing";
pub const WORDPROCESSING_DRAWING_2012_URI: &str =
    "http://schemas.microsoft.com/office/word/2012/wordprocessingDrawing";
pub const WORDPROCESSING_GROUP_2010_URI: &str =
    "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup";
pub const WORDPROCESSINGML_2010_URI: &str = "http://schemas.microsoft.com/office/word/2010/wordml";
pub const WORDPROCESSINGML_2012_URI: &str = "http://schemas.microsoft.com/office/word/2012/wordml";
pub const SPREADSHEETML_2010_URI: &str =
    "http://schemas.microsoft.com/office/spreadsheetml/2009/9/main";
pub const PRESENTATIONML_2010_URI: &str =
    "http://schemas.microsoft.com/office/powerpoint/2010/main";

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TypedElementKind {
    Leaf,
    Composite,
    TypedLeaf,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TypedElementDescriptor {
    pub class_name: String,
    pub qualified_name: String,
    pub schema_path: String,
    pub type_kind: TypedElementKind,
    pub known_attributes: Vec<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ValidationValidatorKind {
    Required,
    String,
    Number,
    Enum,
    OfficeVersion,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ValidationValidatorArgument {
    pub argument_type: String,
    pub name: Option<String>,
    pub value: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ValidationValidatorDescriptor {
    pub kind: ValidationValidatorKind,
    pub simple_type: Option<String>,
    pub union_id: Option<i32>,
    pub is_initial_version: bool,
    pub arguments: Vec<ValidationValidatorArgument>,
    pub enum_values: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ValidationAttributeDescriptor {
    pub q_name: String,
    pub normalized_q_name: String,
    pub value_type: Option<String>,
    pub version: Option<String>,
    pub validators: Vec<ValidationValidatorDescriptor>,
    pub enum_values: Vec<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ValidationParticleKind {
    Element,
    Sequence,
    Choice,
    All,
    Group,
    Any,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ValidationParticleDescriptor {
    pub kind: ValidationParticleKind,
    pub schema_name: Option<String>,
    pub qualified_name: Option<String>,
    pub min_occurs: u32,
    pub max_occurs: Option<u32>,
    pub initial_version: Option<String>,
    pub items: Vec<ValidationParticleDescriptor>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ValidationElementDescriptor {
    pub class_name: String,
    pub schema_name: String,
    pub qualified_name: String,
    pub schema_path: String,
    pub version: Option<String>,
    pub type_kind: TypedElementKind,
    pub attributes: Vec<ValidationAttributeDescriptor>,
    pub validators: Vec<ValidationValidatorDescriptor>,
    pub particle: Option<ValidationParticleDescriptor>,
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
pub struct NamespaceRecord {
    #[serde(rename = "Prefix")]
    pub prefix: String,
    #[serde(rename = "Uri")]
    pub uri: String,
    #[serde(rename = "Version", default)]
    pub version: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
pub struct TypedNamespaceRecord {
    #[serde(rename = "Prefix")]
    pub prefix: String,
    #[serde(rename = "Namespace")]
    pub namespace: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
pub struct TypedSchemaEntry {
    #[serde(rename = "Name")]
    pub name: String,
    #[serde(rename = "ClassName")]
    pub class_name: String,
    #[serde(rename = "PartClassName", default)]
    pub part_class_name: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
pub struct SchematronRule {
    #[serde(rename = "Context")]
    pub context: String,
    #[serde(rename = "Test")]
    pub test: String,
    #[serde(rename = "App")]
    pub app: String,
    #[serde(rename = "Version", default)]
    pub version: Option<String>,
}

impl TypedSchemaEntry {
    #[must_use]
    pub fn type_name(&self) -> Option<&str> {
        self.name.split_once('/').map(|(type_name, _)| type_name)
    }

    #[must_use]
    pub fn qualified_name(&self) -> Option<&str> {
        self.name
            .split_once('/')
            .and_then(|(_, qualified_name)| (!qualified_name.is_empty()).then_some(qualified_name))
    }

    #[must_use]
    pub fn element_prefix(&self) -> Option<&str> {
        let segment = self.qualified_name().or_else(|| self.type_name())?;
        segment.split_once(':').map(|(prefix, _)| prefix)
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
struct SchemaRecord {
    #[serde(rename = "TargetNamespace")]
    target_namespace: String,
    #[serde(rename = "Types", default)]
    types: Vec<SchemaTypeRecord>,
    #[serde(rename = "Enums", default)]
    enums: Vec<SchemaEnumRecord>,
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
struct SchemaTypeRecord {
    #[serde(rename = "Name")]
    name: String,
    #[serde(rename = "ClassName")]
    class_name: String,
    #[serde(rename = "BaseClass", default)]
    base_class: Option<String>,
    #[serde(rename = "Version", default)]
    version: Option<String>,
    #[serde(rename = "IsLeafElement", default)]
    is_leaf_element: bool,
    #[serde(rename = "IsLeafText", default)]
    is_leaf_text: bool,
    #[serde(rename = "Attributes", default)]
    attributes: Vec<SchemaAttributeRecord>,
    #[serde(rename = "Validators", default)]
    validators: Vec<SchemaValidatorRecord>,
    #[serde(rename = "Particle", default)]
    particle: Option<SchemaParticleRecord>,
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
struct SchemaAttributeRecord {
    #[serde(rename = "QName")]
    q_name: String,
    #[serde(rename = "Type", default)]
    value_type: Option<String>,
    #[serde(rename = "Version", default)]
    version: Option<String>,
    #[serde(rename = "Validators", default)]
    validators: Vec<SchemaValidatorRecord>,
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
struct SchemaEnumRecord {
    #[serde(rename = "Type")]
    type_name: String,
    #[serde(rename = "Name")]
    name: String,
    #[serde(rename = "Facets", default)]
    facets: Vec<SchemaEnumFacetRecord>,
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
struct SchemaEnumFacetRecord {
    #[serde(rename = "Value")]
    value: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
struct SchemaValidatorRecord {
    #[serde(rename = "Name")]
    name: String,
    #[serde(rename = "Type", default)]
    validator_type: Option<String>,
    #[serde(rename = "UnionId", default)]
    union_id: Option<i32>,
    #[serde(rename = "IsInitialVersion", default)]
    is_initial_version: bool,
    #[serde(rename = "Arguments", default)]
    arguments: Vec<SchemaValidatorArgumentRecord>,
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
struct SchemaValidatorArgumentRecord {
    #[serde(rename = "Type")]
    argument_type: String,
    #[serde(rename = "Name", default)]
    name: Option<String>,
    #[serde(rename = "Value")]
    value: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
struct SchemaParticleRecord {
    #[serde(rename = "Kind", default)]
    kind: Option<String>,
    #[serde(rename = "Name", default)]
    name: Option<String>,
    #[serde(rename = "Occurs", default)]
    occurs: Vec<SchemaOccursRecord>,
    #[serde(rename = "InitialVersion", default)]
    initial_version: Option<String>,
    #[serde(rename = "Items", default)]
    items: Vec<SchemaParticleRecord>,
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
struct SchemaOccursRecord {
    #[serde(rename = "Min", default)]
    min: Option<u32>,
    #[serde(rename = "Max", default)]
    max: Option<u32>,
}

#[derive(Debug, Clone, PartialEq, Eq, Default, Deserialize)]
pub struct PartPaths {
    #[serde(rename = "General", default)]
    pub general: Option<String>,
    #[serde(rename = "Excel", default)]
    pub excel: Option<String>,
    #[serde(rename = "Word", default)]
    pub word: Option<String>,
    #[serde(rename = "PowerPoint", default)]
    pub power_point: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
pub struct PartChildDefinition {
    #[serde(rename = "Name")]
    pub name: String,
    #[serde(rename = "ApiName", default)]
    pub api_name: Option<String>,
    #[serde(rename = "HasFixedContent", default)]
    pub has_fixed_content: bool,
    #[serde(rename = "IsDataPartReference", default)]
    pub is_data_part_reference: bool,
    #[serde(rename = "IsSpecialEmbeddedPart", default)]
    pub is_special_embedded_part: bool,
    #[serde(rename = "MaxOccursGreatThanOne", default)]
    pub max_occurs_great_than_one: bool,
    #[serde(rename = "MinOccursIsNonZero", default)]
    pub min_occurs_is_non_zero: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
pub struct PartDefinition {
    #[serde(rename = "Name")]
    pub name: String,
    #[serde(rename = "Base")]
    pub base: String,
    #[serde(rename = "RelationshipType", default)]
    pub relationship_type: Option<String>,
    #[serde(rename = "Target", default)]
    pub target: Option<String>,
    #[serde(rename = "Root", default)]
    pub root: Option<String>,
    #[serde(rename = "RootElement", default)]
    pub root_element: Option<String>,
    #[serde(rename = "ContentType", default)]
    pub content_type: Option<String>,
    #[serde(rename = "Extension", default)]
    pub extension: Option<String>,
    #[serde(rename = "Version", default)]
    pub version: Option<String>,
    #[serde(rename = "Paths", default)]
    pub paths: PartPaths,
    #[serde(rename = "Children", default)]
    pub children: Vec<PartChildDefinition>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OpenXmlSdkData {
    pub namespaces: Vec<NamespaceRecord>,
    pub typed_namespaces: Vec<TypedNamespaceRecord>,
    pub typed_schemas: BTreeMap<String, Vec<TypedSchemaEntry>>,
    pub schema_type_kinds: BTreeMap<String, BTreeMap<String, TypedElementKind>>,
    pub schema_known_attributes: BTreeMap<String, BTreeMap<String, Vec<String>>>,
    pub schematrons: Vec<SchematronRule>,
    pub parts: BTreeMap<String, PartDefinition>,
    schema_records: BTreeMap<String, SchemaRecord>,
}

impl OpenXmlSdkData {
    #[must_use]
    pub fn namespace_prefix_for_uri(&self, uri: &str) -> Option<&str> {
        self.namespaces
            .iter()
            .find(|namespace| namespace.uri == uri)
            .map(|namespace| namespace.prefix.as_str())
    }

    #[must_use]
    pub fn typed_entries_for_uri(&self, uri: &str) -> Option<&[TypedSchemaEntry]> {
        let typed_stem = typed_file_stem_for_uri(uri);
        self.typed_schemas.get(&typed_stem).map(Vec::as_slice)
    }

    pub fn main_namespace_entries(&self, uri: &str) -> Result<Vec<TypedSchemaEntry>> {
        let prefix = self
            .namespace_prefix_for_uri(uri)
            .with_context(|| format!("missing namespace prefix for URI: {uri}"))?;

        let entries = self
            .typed_entries_for_uri(uri)
            .with_context(|| format!("missing typed schema entries for URI: {uri}"))?;

        let filtered = entries
            .iter()
            .filter(|entry| entry.element_prefix() == Some(prefix))
            .cloned()
            .collect::<Vec<_>>();

        if filtered.is_empty() {
            bail!("no typed entries matched namespace prefix `{prefix}` for URI `{uri}`");
        }

        Ok(filtered)
    }

    pub fn main_namespace_typed_elements(&self, uri: &str) -> Result<Vec<TypedElementDescriptor>> {
        let entries = self.main_namespace_entries(uri)?;
        let type_kinds = self
            .schema_type_kinds
            .get(uri)
            .with_context(|| format!("missing schema type metadata for URI: {uri}"))?;
        let known_attributes = self
            .schema_known_attributes
            .get(uri)
            .with_context(|| format!("missing schema attribute metadata for URI: {uri}"))?;

        let mut descriptors = entries
            .into_iter()
            .filter_map(|entry| {
                let qualified_name = entry.qualified_name()?.to_owned();
                let schema_path = format!("/{qualified_name}");
                let type_kind = type_kinds
                    .get(&entry.name)
                    .copied()
                    .or_else(|| infer_type_kind_from_type_name(entry.type_name()))
                    .unwrap_or(TypedElementKind::Composite);
                let known_attributes = known_attributes
                    .get(&entry.name)
                    .or_else(|| {
                        entry
                            .qualified_name()
                            .and_then(|name| known_attributes.get(name))
                    })
                    .cloned()
                    .unwrap_or_default();

                Some(TypedElementDescriptor {
                    class_name: entry.class_name,
                    qualified_name,
                    schema_path,
                    type_kind,
                    known_attributes,
                })
            })
            .collect::<Vec<_>>();

        if descriptors.is_empty() {
            bail!("no typed element entries found for URI `{uri}`");
        }

        descriptors.sort_by(|left, right| {
            left.schema_path
                .cmp(&right.schema_path)
                .then(left.class_name.cmp(&right.class_name))
        });

        Ok(descriptors)
    }

    pub fn main_namespace_validation_descriptors(
        &self,
        uri: &str,
    ) -> Result<Vec<ValidationElementDescriptor>> {
        let entries = self.main_namespace_entries(uri)?;
        let type_kinds = self
            .schema_type_kinds
            .get(uri)
            .with_context(|| format!("missing schema type metadata for URI: {uri}"))?;
        let schema = self
            .schema_records
            .get(uri)
            .with_context(|| format!("missing schema record for URI: {uri}"))?;
        let enum_values_by_type = derive_schema_enum_values(&schema.enums);

        let mut descriptors = entries
            .into_iter()
            .filter_map(|entry| {
                let qualified_name = entry.qualified_name()?.to_owned();
                let schema_path = format!("/{qualified_name}");
                let type_kind = type_kinds
                    .get(&entry.name)
                    .copied()
                    .or_else(|| infer_type_kind_from_type_name(entry.type_name()))
                    .unwrap_or(TypedElementKind::Composite);
                let type_record = schema
                    .types
                    .iter()
                    .find(|record| record.name == entry.name)?;
                let attributes = type_record
                    .attributes
                    .iter()
                    .map(|attribute| {
                        let enum_values = attribute
                            .value_type
                            .as_deref()
                            .map(|value_type| {
                                derive_enum_values_for_attribute_type(
                                    value_type,
                                    &enum_values_by_type,
                                )
                            })
                            .unwrap_or_default();
                        ValidationAttributeDescriptor {
                            q_name: attribute.q_name.clone(),
                            normalized_q_name: normalize_schema_qname(&attribute.q_name),
                            value_type: attribute.value_type.clone(),
                            version: attribute.version.clone(),
                            validators: convert_validators(
                                &attribute.validators,
                                &enum_values_by_type,
                            ),
                            enum_values,
                        }
                    })
                    .collect::<Vec<_>>();

                Some(ValidationElementDescriptor {
                    class_name: entry.class_name,
                    schema_name: entry.name,
                    qualified_name,
                    schema_path,
                    version: type_record.version.clone(),
                    type_kind,
                    attributes,
                    validators: convert_validators(&type_record.validators, &enum_values_by_type),
                    particle: type_record.particle.as_ref().map(convert_particle),
                })
            })
            .collect::<Vec<_>>();

        if descriptors.is_empty() {
            bail!("no validation descriptors found for URI `{uri}`");
        }

        descriptors.sort_by(|left, right| {
            left.schema_path
                .cmp(&right.schema_path)
                .then(left.class_name.cmp(&right.class_name))
        });

        Ok(descriptors)
    }
}

pub fn load_openxml_sdk_data<P: AsRef<Path>>(data_root: P) -> Result<OpenXmlSdkData> {
    let data_root = data_root.as_ref();

    let namespaces_path = data_root.join("namespaces.json");
    let namespaces = read_json_file::<Vec<NamespaceRecord>>(&namespaces_path)
        .with_context(|| format!("failed to parse {}", display_path(&namespaces_path)))?;

    let typed_root = data_root.join("typed");
    let (typed_namespaces, typed_schemas) = load_typed_data(&typed_root)?;

    let schemas_root = data_root.join("schemas");
    let schema_records = load_schema_records(&schemas_root)?;
    let schema_type_kinds = load_schema_type_kinds(&schema_records);
    let schema_known_attributes = load_schema_known_attributes(&schema_records);

    let schematrons_path = data_root.join("schematrons.json");
    let schematrons = read_json_file::<Vec<SchematronRule>>(&schematrons_path)
        .with_context(|| format!("failed to parse {}", display_path(&schematrons_path)))?;

    let parts_root = data_root.join("parts");
    let parts = load_parts(&parts_root)?;

    Ok(OpenXmlSdkData {
        namespaces,
        typed_namespaces,
        typed_schemas,
        schema_type_kinds,
        schema_known_attributes,
        schematrons,
        parts,
        schema_records,
    })
}

fn normalize_typed_stem_key(value: &str) -> String {
    let mut normalized = String::with_capacity(value.len());
    for ch in value.chars() {
        if ch.is_ascii_alphanumeric() {
            normalized.push(ch);
        } else {
            normalized.push('_');
        }
    }
    normalized
}

#[must_use]
pub fn typed_file_stem_for_uri(uri: &str) -> String {
    let without_scheme = uri
        .strip_prefix("http://")
        .or_else(|| uri.strip_prefix("https://"))
        .or_else(|| uri.strip_prefix("urn:"))
        .unwrap_or(uri);

    normalize_typed_stem_key(without_scheme)
}

fn load_typed_data(
    typed_root: &Path,
) -> Result<(
    Vec<TypedNamespaceRecord>,
    BTreeMap<String, Vec<TypedSchemaEntry>>,
)> {
    let typed_files = collect_json_files(typed_root)?;
    let mut typed_namespaces = None;
    let mut typed_schemas = BTreeMap::new();

    for typed_file in typed_files {
        let file_name = typed_file
            .file_name()
            .and_then(|name| name.to_str())
            .with_context(|| format!("invalid UTF-8 file name: {}", display_path(&typed_file)))?;

        if file_name == "namespaces.json" {
            let records = read_json_file::<Vec<TypedNamespaceRecord>>(&typed_file)
                .with_context(|| format!("failed to parse {}", display_path(&typed_file)))?;
            typed_namespaces = Some(records);
            continue;
        }

        let entries = read_json_file::<Vec<TypedSchemaEntry>>(&typed_file)
            .with_context(|| format!("failed to parse {}", display_path(&typed_file)))?;
        let stem = typed_file
            .file_stem()
            .and_then(|name| name.to_str())
            .with_context(|| format!("invalid UTF-8 file stem: {}", display_path(&typed_file)))?;

        let normalized_stem = normalize_typed_stem_key(stem);
        if typed_schemas
            .insert(stem.to_owned(), entries.clone())
            .is_some()
        {
            bail!("duplicate typed schema file stem: {stem}");
        }
        if normalized_stem != stem && typed_schemas.contains_key(&normalized_stem) {
            bail!("duplicate normalized typed schema file stem: {normalized_stem}");
        }
        if normalized_stem != stem {
            typed_schemas.insert(normalized_stem, entries);
        }
    }

    let typed_namespaces =
        typed_namespaces.context("missing required typed/namespaces.json file")?;

    Ok((typed_namespaces, typed_schemas))
}

fn load_parts(parts_root: &Path) -> Result<BTreeMap<String, PartDefinition>> {
    let part_files = collect_json_files(parts_root)?;
    let mut parts = BTreeMap::new();

    for part_file in part_files {
        let part = read_json_file::<PartDefinition>(&part_file)
            .with_context(|| format!("failed to parse {}", display_path(&part_file)))?;

        if parts.insert(part.name.clone(), part).is_some() {
            bail!("duplicate part name in parts registry");
        }
    }

    Ok(parts)
}

fn load_schema_records(schemas_root: &Path) -> Result<BTreeMap<String, SchemaRecord>> {
    let schema_files = collect_json_files(schemas_root)?;
    let mut schemas = BTreeMap::new();

    for schema_file in schema_files {
        let schema = read_json_file::<SchemaRecord>(&schema_file)
            .with_context(|| format!("failed to parse {}", display_path(&schema_file)))?;

        if schemas
            .insert(schema.target_namespace.clone(), schema)
            .is_some()
        {
            bail!("duplicate schema namespace metadata in schemas root");
        }
    }

    Ok(schemas)
}

fn load_schema_type_kinds(
    schema_records: &BTreeMap<String, SchemaRecord>,
) -> BTreeMap<String, BTreeMap<String, TypedElementKind>> {
    schema_records
        .iter()
        .map(|(uri, schema)| (uri.clone(), derive_schema_type_kinds(&schema.types)))
        .collect()
}

fn load_schema_known_attributes(
    schema_records: &BTreeMap<String, SchemaRecord>,
) -> BTreeMap<String, BTreeMap<String, Vec<String>>> {
    schema_records
        .iter()
        .map(|(uri, schema)| (uri.clone(), derive_schema_known_attributes(&schema.types)))
        .collect()
}

fn derive_schema_type_kinds(types: &[SchemaTypeRecord]) -> BTreeMap<String, TypedElementKind> {
    let mut type_by_class_name = BTreeMap::new();
    for schema_type in types {
        type_by_class_name
            .entry(schema_type.class_name.clone())
            .or_insert_with(|| schema_type.clone());
    }

    let mut memo = BTreeMap::new();
    let mut kind_by_name = BTreeMap::new();
    for schema_type in types {
        if let Some(kind) = resolve_type_kind(
            &schema_type.class_name,
            &type_by_class_name,
            &mut memo,
            &mut Vec::new(),
        ) {
            kind_by_name.insert(schema_type.name.clone(), kind);
        }
    }

    kind_by_name
}

fn derive_schema_known_attributes(types: &[SchemaTypeRecord]) -> BTreeMap<String, Vec<String>> {
    let mut type_by_class_name = BTreeMap::new();
    for schema_type in types {
        type_by_class_name
            .entry(schema_type.class_name.clone())
            .or_insert_with(|| schema_type.clone());
    }

    let mut resolved_by_class_name = BTreeMap::new();
    let mut known_attributes = BTreeMap::<String, BTreeSet<String>>::new();

    for schema_type in types {
        let attributes = resolve_known_attributes(
            &schema_type.class_name,
            &type_by_class_name,
            &mut resolved_by_class_name,
            &mut Vec::new(),
        );

        merge_known_attributes(
            &mut known_attributes,
            schema_type.name.clone(),
            attributes.clone(),
        );

        if let Some((_, qualified_name)) = schema_type.name.split_once('/') {
            merge_known_attributes(
                &mut known_attributes,
                qualified_name.to_owned(),
                attributes.clone(),
            );
        }
    }

    known_attributes
        .into_iter()
        .map(|(name, attributes)| (name, attributes.into_iter().collect()))
        .collect()
}

fn resolve_known_attributes(
    class_name: &str,
    type_by_class_name: &BTreeMap<String, SchemaTypeRecord>,
    resolved_by_class_name: &mut BTreeMap<String, BTreeSet<String>>,
    visiting: &mut Vec<String>,
) -> BTreeSet<String> {
    if let Some(cached) = resolved_by_class_name.get(class_name) {
        return cached.clone();
    }

    if visiting.iter().any(|current| current == class_name) {
        return BTreeSet::new();
    }

    let Some(schema_type) = type_by_class_name.get(class_name) else {
        return BTreeSet::new();
    };
    visiting.push(class_name.to_owned());

    let mut attributes = schema_type
        .attributes
        .iter()
        .filter_map(|attribute| normalize_attribute_q_name(&attribute.q_name))
        .collect::<BTreeSet<_>>();

    if let Some(base_class) = schema_type.base_class.as_deref() {
        attributes.extend(resolve_known_attributes(
            base_class,
            type_by_class_name,
            resolved_by_class_name,
            visiting,
        ));
    }

    let _ = visiting.pop();
    resolved_by_class_name.insert(class_name.to_owned(), attributes.clone());
    attributes
}

fn normalize_attribute_q_name(q_name: &str) -> Option<String> {
    let normalized = q_name.strip_prefix(':').unwrap_or(q_name).trim();
    (!normalized.is_empty()).then_some(normalized.to_owned())
}

fn merge_known_attributes(
    known_attributes: &mut BTreeMap<String, BTreeSet<String>>,
    key: String,
    attrs: BTreeSet<String>,
) {
    known_attributes
        .entry(key)
        .and_modify(|existing| existing.extend(attrs.iter().cloned()))
        .or_insert(attrs);
}

fn resolve_type_kind(
    class_name: &str,
    type_by_class_name: &BTreeMap<String, SchemaTypeRecord>,
    memo: &mut BTreeMap<String, Option<TypedElementKind>>,
    visiting: &mut Vec<String>,
) -> Option<TypedElementKind> {
    if let Some(cached) = memo.get(class_name) {
        return *cached;
    }

    if visiting.iter().any(|current| current == class_name) {
        return None;
    }

    let schema_type = type_by_class_name.get(class_name)?;
    visiting.push(class_name.to_owned());

    let kind = direct_type_kind(schema_type).or_else(|| {
        schema_type.base_class.as_deref().and_then(|base_class| {
            resolve_type_kind(base_class, type_by_class_name, memo, visiting)
        })
    });

    let _ = visiting.pop();
    memo.insert(class_name.to_owned(), kind);
    kind
}

fn direct_type_kind(schema_type: &SchemaTypeRecord) -> Option<TypedElementKind> {
    if schema_type.is_leaf_text
        || schema_type.base_class.as_deref() == Some("OpenXmlLeafTextElement")
    {
        return Some(TypedElementKind::TypedLeaf);
    }

    if schema_type.is_leaf_element
        || schema_type.base_class.as_deref() == Some("OpenXmlLeafElement")
    {
        return Some(TypedElementKind::Leaf);
    }

    if schema_type.base_class.as_deref() == Some("OpenXmlCompositeElement") {
        return Some(TypedElementKind::Composite);
    }

    None
}

fn infer_type_kind_from_type_name(type_name: Option<&str>) -> Option<TypedElementKind> {
    let type_name = type_name?;

    if type_name.starts_with("xsd:") || type_name.starts_with("xs:") || type_name.contains(":ST_") {
        return Some(TypedElementKind::TypedLeaf);
    }

    if type_name.contains(":CT_") {
        return Some(TypedElementKind::Composite);
    }

    None
}

fn derive_schema_enum_values(enums: &[SchemaEnumRecord]) -> BTreeMap<String, Vec<String>> {
    let mut enum_values = BTreeMap::new();
    for schema_enum in enums {
        enum_values.insert(
            schema_enum.type_name.clone(),
            schema_enum
                .facets
                .iter()
                .map(|facet| facet.value.clone())
                .collect(),
        );
        enum_values.insert(
            schema_enum.name.clone(),
            schema_enum
                .facets
                .iter()
                .map(|facet| facet.value.clone())
                .collect(),
        );
    }
    enum_values
}

fn derive_enum_values_for_attribute_type(
    value_type: &str,
    enum_values_by_type: &BTreeMap<String, Vec<String>>,
) -> Vec<String> {
    if let Some(enum_name) = value_type
        .strip_prefix("EnumValue<")
        .and_then(|rest| rest.strip_suffix('>'))
        .and_then(|rest| rest.rsplit('.').next())
    {
        return enum_values_by_type
            .get(enum_name)
            .cloned()
            .unwrap_or_default();
    }

    enum_values_by_type
        .get(value_type)
        .cloned()
        .unwrap_or_default()
}

fn convert_validators(
    validators: &[SchemaValidatorRecord],
    enum_values_by_type: &BTreeMap<String, Vec<String>>,
) -> Vec<ValidationValidatorDescriptor> {
    validators
        .iter()
        .filter_map(|validator| {
            let kind = match validator.name.as_str() {
                "RequiredValidator" => ValidationValidatorKind::Required,
                "StringValidator" => ValidationValidatorKind::String,
                "NumberValidator" => ValidationValidatorKind::Number,
                "EnumValidator" => ValidationValidatorKind::Enum,
                "OfficeVersionValidator" => ValidationValidatorKind::OfficeVersion,
                _ => return None,
            };
            let enum_values = validator
                .validator_type
                .as_deref()
                .and_then(|validator_type| enum_values_by_type.get(validator_type))
                .cloned()
                .unwrap_or_default();
            Some(ValidationValidatorDescriptor {
                kind,
                simple_type: validator.validator_type.clone(),
                union_id: validator.union_id,
                is_initial_version: validator.is_initial_version,
                arguments: validator
                    .arguments
                    .iter()
                    .map(|argument| ValidationValidatorArgument {
                        argument_type: argument.argument_type.clone(),
                        name: argument.name.clone(),
                        value: argument.value.clone(),
                    })
                    .collect(),
                enum_values,
            })
        })
        .collect()
}

fn convert_particle(record: &SchemaParticleRecord) -> ValidationParticleDescriptor {
    let (min_occurs, max_occurs) = normalize_occurs(&record.occurs);
    let qualified_name = record
        .name
        .as_deref()
        .and_then(extract_qualified_name)
        .map(str::to_owned);
    let kind = match record.kind.as_deref() {
        Some("Sequence") => ValidationParticleKind::Sequence,
        Some("Choice") => ValidationParticleKind::Choice,
        Some("All") => ValidationParticleKind::All,
        Some("Group") => ValidationParticleKind::Group,
        Some("Any") => ValidationParticleKind::Any,
        Some(_) => ValidationParticleKind::Element,
        None => ValidationParticleKind::Element,
    };

    ValidationParticleDescriptor {
        kind,
        schema_name: record.name.clone(),
        qualified_name,
        min_occurs,
        max_occurs,
        initial_version: record.initial_version.clone(),
        items: record.items.iter().map(convert_particle).collect(),
    }
}

fn normalize_occurs(occurs: &[SchemaOccursRecord]) -> (u32, Option<u32>) {
    match occurs.first() {
        Some(record) => (record.min.unwrap_or(0), record.max),
        None => (1, Some(1)),
    }
}

fn extract_qualified_name(schema_name: &str) -> Option<&str> {
    schema_name
        .split_once('/')
        .and_then(|(_, qualified_name)| (!qualified_name.is_empty()).then_some(qualified_name))
}

fn normalize_schema_qname(q_name: &str) -> String {
    q_name.strip_prefix(':').unwrap_or(q_name).to_owned()
}

fn collect_json_files(root: &Path) -> Result<Vec<PathBuf>> {
    let mut files = fs::read_dir(root)
        .with_context(|| format!("failed to read directory {}", display_path(root)))?
        .collect::<std::result::Result<Vec<_>, _>>()
        .with_context(|| format!("failed to enumerate directory {}", display_path(root)))?
        .into_iter()
        .map(|entry| entry.path())
        .filter(|path| path.extension().and_then(|ext| ext.to_str()) == Some("json"))
        .collect::<Vec<_>>();

    files.sort_unstable();
    Ok(files)
}

fn read_json_file<T: DeserializeOwned>(path: &Path) -> Result<T> {
    let bytes = fs::read(path).with_context(|| format!("failed to read {}", display_path(path)))?;
    serde_json::from_slice::<T>(&bytes)
        .with_context(|| format!("failed to deserialize {}", display_path(path)))
}

fn display_path(path: &Path) -> String {
    path.to_string_lossy().into_owned()
}

#[cfg(test)]
#[allow(clippy::panic_in_result_fn)]
mod tests {
    use std::path::PathBuf;

    use anyhow::Result;

    use super::{
        load_openxml_sdk_data, typed_file_stem_for_uri, OpenXmlSdkData, TypedElementKind,
        TypedSchemaEntry, ValidationParticleKind, ValidationValidatorKind, CUSTOM_PROPERTIES_URI,
        DOC_PROPS_VTYPES_URI, DRAWINGML_2010_MAIN_URI, DRAWINGML_2012_MAIN_URI,
        DRAWINGML_CHART_DRAWING_2010_URI, DRAWINGML_CHART_DRAWING_URI, DRAWINGML_CHART_URI,
        DRAWINGML_LOCKED_CANVAS_URI, DRAWINGML_MAIN_URI, DRAWINGML_PICTURE_2010_URI,
        DRAWINGML_PICTURE_URI, EXTENDED_PROPERTIES_URI, OFFICE_MATH_URI, PRESENTATIONML_MAIN_URI,
        SPREADSHEETML_MAIN_URI, VML_URI, WORDPROCESSINGML_2012_URI, WORDPROCESSINGML_MAIN_URI,
        WORDPROCESSING_CANVAS_2010_URI, WORDPROCESSING_DRAWING_2010_URI,
        WORDPROCESSING_DRAWING_2012_URI, WORDPROCESSING_GROUP_2010_URI,
        WORDPROCESSING_SHAPE_2010_URI,
    };

    #[test]
    fn load_openxml_sdk_data_reads_expected_sections() -> Result<()> {
        let Some(data_root) = test_data_root_if_present() else {
            eprintln!("SKIP: Open-XML-SDK reference data not found");
            return Ok(());
        };
        let data = load_openxml_sdk_data(data_root)?;

        assert!(!data.namespaces.is_empty());
        assert!(!data.typed_namespaces.is_empty());
        assert!(!data.typed_schemas.is_empty());
        assert!(!data.schema_type_kinds.is_empty());
        assert!(!data.schema_known_attributes.is_empty());
        assert!(!data.schematrons.is_empty());
        assert!(!data.parts.is_empty());

        assert_eq!(
            data.namespace_prefix_for_uri(SPREADSHEETML_MAIN_URI),
            Some("x")
        );
        assert_eq!(
            data.namespace_prefix_for_uri(WORDPROCESSINGML_MAIN_URI),
            Some("w")
        );
        assert_eq!(
            data.namespace_prefix_for_uri(PRESENTATIONML_MAIN_URI),
            Some("p")
        );

        assert!(data
            .typed_schemas
            .contains_key(&typed_file_stem_for_uri(SPREADSHEETML_MAIN_URI)));
        assert!(data
            .typed_schemas
            .contains_key(&typed_file_stem_for_uri(WORDPROCESSINGML_MAIN_URI)));
        assert!(data
            .typed_schemas
            .contains_key(&typed_file_stem_for_uri(PRESENTATIONML_MAIN_URI)));
        assert!(data.schema_type_kinds.contains_key(SPREADSHEETML_MAIN_URI));
        assert!(data
            .schema_type_kinds
            .contains_key(WORDPROCESSINGML_MAIN_URI));
        assert!(data.schema_type_kinds.contains_key(PRESENTATIONML_MAIN_URI));
        assert!(data
            .schema_known_attributes
            .contains_key(SPREADSHEETML_MAIN_URI));
        assert!(data
            .schema_known_attributes
            .contains_key(WORDPROCESSINGML_MAIN_URI));
        assert!(data
            .schema_known_attributes
            .contains_key(PRESENTATIONML_MAIN_URI));

        assert!(data.parts.contains_key("WorkbookPart"));
        assert!(data.parts.contains_key("MainDocumentPart"));
        assert!(data.parts.contains_key("PresentationPart"));
        assert!(data
            .schematrons
            .iter()
            .any(|rule| rule.context == "x:sheet"));

        Ok(())
    }

    #[test]
    fn typed_schema_entry_extracts_prefix_from_composite_name() {
        let entry = TypedSchemaEntry {
            name: "xsd:string/p:attrName".to_string(),
            class_name: "AttributeName".to_string(),
            part_class_name: None,
        };
        assert_eq!(entry.type_name(), Some("xsd:string"));
        assert_eq!(entry.qualified_name(), Some("p:attrName"));
        assert_eq!(entry.element_prefix(), Some("p"));

        let no_colon = TypedSchemaEntry {
            name: "plainIdentifier".to_string(),
            class_name: "Plain".to_string(),
            part_class_name: None,
        };
        assert_eq!(no_colon.type_name(), None);
        assert_eq!(no_colon.qualified_name(), None);
        assert_eq!(no_colon.element_prefix(), None);
    }

    #[test]
    fn main_namespace_entries_are_filtered_by_prefix() -> Result<()> {
        let Some(data_root) = test_data_root_if_present() else {
            eprintln!("SKIP: Open-XML-SDK reference data not found");
            return Ok(());
        };
        let data: OpenXmlSdkData = load_openxml_sdk_data(data_root)?;

        let all_presentation_entries = data
            .typed_entries_for_uri(PRESENTATIONML_MAIN_URI)
            .map_or(0, |entries| entries.len());
        let main_entries = data.main_namespace_entries(PRESENTATIONML_MAIN_URI)?;

        assert!(!main_entries.is_empty());
        assert!(main_entries
            .iter()
            .all(|entry| entry.element_prefix() == Some("p")));
        assert!(all_presentation_entries > main_entries.len());

        Ok(())
    }

    #[test]
    fn main_namespace_typed_elements_include_kind_and_paths() -> Result<()> {
        let Some(data_root) = test_data_root_if_present() else {
            eprintln!("SKIP: Open-XML-SDK reference data not found");
            return Ok(());
        };
        let data: OpenXmlSdkData = load_openxml_sdk_data(data_root)?;

        let spreadsheet = data.main_namespace_typed_elements(SPREADSHEETML_MAIN_URI)?;
        let workbook = spreadsheet
            .iter()
            .find(|entry| entry.class_name == "Workbook")
            .expect("Workbook typed descriptor should exist");
        assert_eq!(workbook.qualified_name, "x:workbook");
        assert_eq!(workbook.schema_path, "/x:workbook");
        assert_eq!(workbook.type_kind, TypedElementKind::Composite);

        let word = data.main_namespace_typed_elements(WORDPROCESSINGML_MAIN_URI)?;
        let text = word
            .iter()
            .find(|entry| entry.class_name == "Text")
            .expect("Wordprocessing Text typed descriptor should exist");
        assert_eq!(text.qualified_name, "w:t");
        assert_eq!(text.type_kind, TypedElementKind::TypedLeaf);
        assert!(text.known_attributes.contains(&"xml:space".to_string()));

        let presentation = data.main_namespace_typed_elements(PRESENTATIONML_MAIN_URI)?;
        let slide_all = presentation
            .iter()
            .find(|entry| entry.class_name == "SlideAll")
            .expect("SlideAll typed descriptor should exist");
        assert_eq!(slide_all.qualified_name, "p:sldAll");
        assert_eq!(slide_all.type_kind, TypedElementKind::Leaf);

        Ok(())
    }

    #[test]
    fn main_namespace_validation_descriptors_include_particles_and_validators() -> Result<()> {
        let Some(data_root) = test_data_root_if_present() else {
            eprintln!("SKIP: Open-XML-SDK reference data not found");
            return Ok(());
        };
        let data: OpenXmlSdkData = load_openxml_sdk_data(data_root)?;

        let word = data.main_namespace_validation_descriptors(WORDPROCESSINGML_MAIN_URI)?;
        let document = word
            .iter()
            .find(|entry| entry.class_name == "Document")
            .expect("Document validation descriptor should exist");
        assert_eq!(document.qualified_name, "w:document");
        assert!(document.particle.is_some());
        assert_eq!(
            document.particle.as_ref().map(|particle| particle.kind),
            Some(ValidationParticleKind::Sequence)
        );

        let track_change = word
            .iter()
            .find(|entry| entry.class_name == "CellMerge")
            .expect("CellMerge validation descriptor should exist");
        let author = track_change
            .attributes
            .iter()
            .find(|attribute| attribute.normalized_q_name == "w:author")
            .expect("w:author validation descriptor should exist");
        assert!(author
            .validators
            .iter()
            .any(|validator| validator.kind == ValidationValidatorKind::Required));
        assert!(author
            .validators
            .iter()
            .any(|validator| validator.kind == ValidationValidatorKind::String));

        let table_caption = word
            .iter()
            .find(|entry| entry.class_name == "TableCaption")
            .expect("TableCaption validation descriptor should exist");
        assert_eq!(table_caption.version.as_deref(), Some("Office2010"));

        let workbook = data.main_namespace_validation_descriptors(SPREADSHEETML_MAIN_URI)?;
        let workbook_root = workbook
            .iter()
            .find(|entry| entry.class_name == "Workbook")
            .expect("Workbook validation descriptor should exist");
        let file_version = workbook_root
            .particle
            .as_ref()
            .and_then(|particle| particle.items.first())
            .expect("Workbook particle should have a first child");
        assert_eq!(
            file_version.qualified_name.as_deref(),
            Some("x:fileVersion")
        );
        assert_eq!(file_version.min_occurs, 0);
        assert_eq!(file_version.max_occurs, Some(1));

        let drawing = data.main_namespace_validation_descriptors(DRAWINGML_MAIN_URI)?;
        let text_paragraph = drawing
            .iter()
            .find(|entry| entry.class_name == "Paragraph")
            .expect("DrawingML Paragraph validation descriptor should exist");
        assert_eq!(text_paragraph.qualified_name, "a:p");

        let custom_properties =
            data.main_namespace_validation_descriptors(CUSTOM_PROPERTIES_URI)?;
        let custom_root = custom_properties
            .iter()
            .find(|entry| entry.class_name == "Properties")
            .expect("custom properties validation descriptor should exist");
        assert_eq!(custom_root.qualified_name, "op:Properties");
        assert!(custom_root.particle.is_some());

        let extended_properties =
            data.main_namespace_validation_descriptors(EXTENDED_PROPERTIES_URI)?;
        let app_properties = extended_properties
            .iter()
            .find(|entry| entry.class_name == "Properties")
            .expect("extended properties validation descriptor should exist");
        assert_eq!(app_properties.qualified_name, "ap:Properties");
        assert!(app_properties.particle.is_some());

        let variant_types = data.main_namespace_validation_descriptors(DOC_PROPS_VTYPES_URI)?;
        let vector = variant_types
            .iter()
            .find(|entry| entry.class_name == "VTVector")
            .expect("docPropsVTypes VTVector validation descriptor should exist");
        assert_eq!(vector.qualified_name, "vt:vector");
        assert!(vector
            .attributes
            .iter()
            .any(|attribute| attribute.normalized_q_name == "baseType"));
        assert!(vector
            .attributes
            .iter()
            .any(|attribute| attribute.normalized_q_name == "size"));

        let math = data.main_namespace_validation_descriptors(OFFICE_MATH_URI)?;
        let fraction = math
            .iter()
            .find(|entry| entry.class_name == "Fraction")
            .expect("Office Math Fraction validation descriptor should exist");
        assert_eq!(fraction.qualified_name, "m:f");
        assert!(fraction.particle.is_some());

        let vml = data.main_namespace_validation_descriptors(VML_URI)?;
        let shape = vml
            .iter()
            .find(|entry| entry.class_name == "Shape")
            .expect("VML Shape validation descriptor should exist");
        assert_eq!(shape.qualified_name, "v:shape");
        assert!(shape.particle.is_some());

        let wps = data.main_namespace_validation_descriptors(WORDPROCESSING_SHAPE_2010_URI)?;
        let wordprocessing_shape = wps
            .iter()
            .find(|entry| entry.class_name == "WordprocessingShape")
            .expect("WordprocessingShape validation descriptor should exist");
        assert_eq!(wordprocessing_shape.qualified_name, "wps:wsp");
        assert!(wordprocessing_shape.particle.is_some());

        let wpc = data.main_namespace_validation_descriptors(WORDPROCESSING_CANVAS_2010_URI)?;
        let wordprocessing_canvas = wpc
            .iter()
            .find(|entry| entry.class_name == "WordprocessingCanvas")
            .expect("WordprocessingCanvas validation descriptor should exist");
        assert_eq!(wordprocessing_canvas.qualified_name, "wpc:wpc");
        assert!(wordprocessing_canvas.particle.is_some());

        let wpg = data.main_namespace_validation_descriptors(WORDPROCESSING_GROUP_2010_URI)?;
        let wordprocessing_group = wpg
            .iter()
            .find(|entry| entry.class_name == "WordprocessingGroup")
            .expect("WordprocessingGroup validation descriptor should exist");
        assert_eq!(wordprocessing_group.qualified_name, "wpg:wgp");
        assert!(wordprocessing_group.particle.is_some());

        let wp14 = data.main_namespace_validation_descriptors(WORDPROCESSING_DRAWING_2010_URI)?;
        let relative_width = wp14
            .iter()
            .find(|entry| entry.class_name == "RelativeWidth")
            .expect("WordprocessingDrawing 2010 RelativeWidth descriptor should exist");
        assert_eq!(relative_width.qualified_name, "wp14:sizeRelH");
        assert!(relative_width.particle.is_some());

        let wp15 = data.main_namespace_validation_descriptors(WORDPROCESSING_DRAWING_2012_URI)?;
        let web_video_property = wp15
            .iter()
            .find(|entry| entry.class_name == "WebVideoProperty")
            .expect("WordprocessingDrawing 2012 WebVideoProperty descriptor should exist");
        assert_eq!(web_video_property.qualified_name, "wp15:webVideoPr");
        assert!(!web_video_property.attributes.is_empty());

        let w15 = data.main_namespace_validation_descriptors(WORDPROCESSINGML_2012_URI)?;
        let appearance = w15
            .iter()
            .find(|entry| entry.class_name == "Appearance")
            .expect("WordprocessingML 2012 Appearance descriptor should exist");
        assert_eq!(appearance.qualified_name, "w15:appearance");
        assert!(!appearance.attributes.is_empty());

        let picture = data.main_namespace_validation_descriptors(DRAWINGML_PICTURE_URI)?;
        let picture_root = picture
            .iter()
            .find(|entry| entry.qualified_name == "pic:pic")
            .expect("DrawingML picture root validation descriptor should exist");
        assert_eq!(picture_root.class_name, "Picture");
        assert!(picture_root.particle.is_some());

        let drawing_2010 = data.main_namespace_validation_descriptors(DRAWINGML_2010_MAIN_URI)?;
        let gvml_content_part = drawing_2010
            .iter()
            .find(|entry| entry.class_name == "GvmlContentPart")
            .expect("DrawingML 2010 GvmlContentPart descriptor should exist");
        assert_eq!(gvml_content_part.qualified_name, "a14:contentPart");
        assert!(gvml_content_part.particle.is_some());

        let drawing_2012 = data.main_namespace_validation_descriptors(DRAWINGML_2012_MAIN_URI)?;
        let signature_line = drawing_2012
            .iter()
            .find(|entry| entry.class_name == "SignatureLine")
            .expect("DrawingML 2012 SignatureLine descriptor should exist");
        assert_eq!(signature_line.qualified_name, "a15:signatureLine");
        assert!(!signature_line.attributes.is_empty());

        let picture_2010 =
            data.main_namespace_validation_descriptors(DRAWINGML_PICTURE_2010_URI)?;
        let picture_style = picture_2010
            .iter()
            .find(|entry| entry.class_name == "ShapeStyle")
            .expect("DrawingML picture 2010 ShapeStyle descriptor should exist");
        assert_eq!(picture_style.qualified_name, "pic14:style");
        assert!(picture_style.particle.is_some());

        let locked_canvas =
            data.main_namespace_validation_descriptors(DRAWINGML_LOCKED_CANVAS_URI)?;
        let locked_canvas_root = locked_canvas
            .iter()
            .find(|entry| entry.class_name == "LockedCanvas")
            .expect("LockedCanvas descriptor should exist");
        assert_eq!(locked_canvas_root.qualified_name, "lc:lockedCanvas");
        assert!(locked_canvas_root.particle.is_some());

        let chart_drawing =
            data.main_namespace_validation_descriptors(DRAWINGML_CHART_DRAWING_URI)?;
        let rel_size_anchor = chart_drawing
            .iter()
            .find(|entry| entry.class_name == "RelativeAnchorSize")
            .expect("ChartDrawing RelativeAnchorSize validation descriptor should exist");
        assert_eq!(rel_size_anchor.qualified_name, "cdr:relSizeAnchor");
        assert!(rel_size_anchor.particle.is_some());

        let chart_drawing_2010 =
            data.main_namespace_validation_descriptors(DRAWINGML_CHART_DRAWING_2010_URI)?;
        let content_part = chart_drawing_2010
            .iter()
            .find(|entry| entry.class_name == "ContentPart")
            .expect("ChartDrawing 2010 ContentPart validation descriptor should exist");
        assert_eq!(content_part.qualified_name, "cdr14:contentPart");

        let chart = data.main_namespace_validation_descriptors(DRAWINGML_CHART_URI)?;
        let chart_space = chart
            .iter()
            .find(|entry| entry.class_name == "ChartSpace")
            .expect("ChartSpace validation descriptor should exist");
        assert_eq!(chart_space.qualified_name, "c:chartSpace");
        assert!(chart_space.particle.is_some());

        let presentation = data.main_namespace_validation_descriptors(PRESENTATIONML_MAIN_URI)?;
        let presentation_root = presentation
            .iter()
            .find(|entry| entry.class_name == "Presentation")
            .expect("Presentation validation descriptor should exist");
        let bookmark_seed = presentation_root
            .attributes
            .iter()
            .find(|attribute| attribute.normalized_q_name == "bookmarkIdSeed")
            .expect("bookmarkIdSeed validation descriptor should exist");
        assert!(bookmark_seed
            .validators
            .iter()
            .any(|validator| validator.kind == ValidationValidatorKind::Number));
        assert!(presentation_root
            .attributes
            .iter()
            .find(|attribute| attribute.normalized_q_name == "conformance")
            .is_some_and(|attribute| !attribute.enum_values.is_empty()));

        Ok(())
    }

    fn test_data_root_if_present() -> Option<PathBuf> {
        let root = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../offidized-schema/data");
        root.exists().then_some(root)
    }
}
