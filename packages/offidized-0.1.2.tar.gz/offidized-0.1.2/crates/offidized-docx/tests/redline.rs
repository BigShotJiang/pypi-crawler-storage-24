//! Redline / tracked-changes tests for offidized-docx.

#![allow(clippy::unwrap_used)]
#![allow(clippy::expect_used)]
#![allow(clippy::panic)]

use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;

use offidized_docx::{Document, FieldCode, ParagraphAlignment, RevisionFilter, RevisionKind};
use offidized_opc::Package;
use tempfile::{tempdir, TempDir};

fn reference_root() -> PathBuf {
    let manifest_dir = Path::new(env!("CARGO_MANIFEST_DIR"));
    manifest_dir.join("../../references")
}

fn openxml_asset(relative_path: &str) -> PathBuf {
    reference_root()
        .join("Open-XML-SDK/test/DocumentFormat.OpenXml.Tests.Assets/assets")
        .join(relative_path)
}

fn local_real_world_docx_fixture() -> Option<PathBuf> {
    std::env::var_os("OFFIDIZED_LOCAL_REAL_WORLD_DOCX").map(PathBuf::from)
}

#[derive(Debug)]
enum TestWorkspace {
    Temp(TempDir),
    Persistent(PathBuf),
}

impl TestWorkspace {
    fn path(&self) -> &Path {
        match self {
            Self::Temp(dir) => dir.path(),
            Self::Persistent(path) => path.as_path(),
        }
    }
}

fn local_real_world_output_root() -> Option<PathBuf> {
    if let Some(path) = std::env::var_os("OFFIDIZED_LOCAL_REAL_WORLD_OUTPUT_DIR") {
        return Some(PathBuf::from(path));
    }

    std::env::var_os("OFFIDIZED_KEEP_LOCAL_REAL_WORLD_OUTPUTS").map(|_| {
        let manifest_dir = Path::new(env!("CARGO_MANIFEST_DIR"));
        manifest_dir.join("../../artifacts/local-real-world")
    })
}

fn local_real_world_workspace(label: &str) -> TestWorkspace {
    if let Some(root) = local_real_world_output_root() {
        let path = root.join(label);
        fs::create_dir_all(&path).expect("create persistent local real-world output dir");
        eprintln!(
            "preserving local real-world outputs in `{}`",
            path.display()
        );
        return TestWorkspace::Persistent(path);
    }

    TestWorkspace::Temp(tempdir().expect("create tempdir"))
}

fn skip_if_missing(path: &Path) -> bool {
    if !path.is_file() {
        eprintln!("skipping: fixture not found at `{}`", path.display());
        true
    } else {
        false
    }
}

fn document_xml(path: &Path) -> String {
    let package = Package::open(path).expect("open package");
    let part = package
        .get_part("/word/document.xml")
        .expect("document.xml part should exist");
    String::from_utf8_lossy(part.data.as_bytes()).into_owned()
}

fn comments_xml(path: &Path) -> String {
    let package = Package::open(path).expect("open package");
    let part = package
        .get_part("/word/comments.xml")
        .expect("comments.xml part should exist");
    String::from_utf8_lossy(part.data.as_bytes()).into_owned()
}

fn part_xml(path: &Path, part_uri: &str) -> String {
    let package = Package::open(path).expect("open package");
    let part = package
        .get_part(part_uri)
        .unwrap_or_else(|| panic!("{part_uri} part should exist"));
    String::from_utf8_lossy(part.data.as_bytes()).into_owned()
}

fn rewrite_part_xml(path: &Path, part_uri: &str, transform: impl FnOnce(String) -> String) {
    let mut package = Package::open(path).expect("open package for xml rewrite");
    let mut part = package
        .get_part(part_uri)
        .unwrap_or_else(|| panic!("{part_uri} part should exist"))
        .clone();
    let updated = transform(String::from_utf8_lossy(part.data.as_bytes()).into_owned());
    part.feed_data(updated.into_bytes());
    package.set_part(part);
    package.save(path).expect("save rewritten package");
}

fn rewrite_document_xml(path: &Path, transform: impl FnOnce(String) -> String) {
    rewrite_part_xml(path, "/word/document.xml", transform);
}

fn count_tag(xml: &str, tag_name: &str) -> usize {
    let needle = format!("<{tag_name}");
    xml.match_indices(needle.as_str())
        .filter(|(idx, _)| {
            let next = xml
                .as_bytes()
                .get(idx.saturating_add(needle.len()))
                .copied();
            matches!(next, Some(b' ') | Some(b'>') | Some(b'/'))
        })
        .count()
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum OpenXmlValidatorOutcome {
    Clean,
    Errors(usize),
    Failed(String),
}

fn openxml_sdk_validation_enabled() -> bool {
    std::env::var_os("OFFIDIZED_ENABLE_OPENXML_SDK_VALIDATION").is_some()
}

fn openxml_sdk_validator_project() -> Option<PathBuf> {
    if let Some(path) = std::env::var_os("OFFIDIZED_OPENXML_SDK_VALIDATOR_PROJECT") {
        return Some(PathBuf::from(path));
    }

    let manifest_dir = Path::new(env!("CARGO_MANIFEST_DIR"));
    Some(manifest_dir.join("../../tools/openxml-sdk-validator/openxml-sdk-validator.csproj"))
}

fn run_openxml_sdk_validator(path: &Path) -> Option<OpenXmlValidatorOutcome> {
    if !openxml_sdk_validation_enabled() {
        return None;
    }

    let validator_project = openxml_sdk_validator_project()?;
    if !validator_project.is_file() {
        eprintln!(
            "skipping Open XML SDK validation for `{}` because validator project is missing at `{}`",
            path.display(),
            validator_project.display()
        );
        return None;
    }

    let output = match Command::new("dotnet")
        .arg("run")
        .arg("-q")
        .arg("--project")
        .arg(&validator_project)
        .arg("--")
        .arg(path)
        .output()
    {
        Ok(output) => output,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
            eprintln!(
                "skipping Open XML SDK validation for `{}` because `dotnet` is unavailable",
                path.display()
            );
            return None;
        }
        Err(error) => panic!("failed to invoke dotnet validator: {error}"),
    };

    if output.status.success() {
        return Some(OpenXmlValidatorOutcome::Clean);
    }

    let stdout = String::from_utf8_lossy(&output.stdout).into_owned();
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    if let Some(count) = stdout
        .lines()
        .find_map(|line| line.strip_prefix("errors="))
        .and_then(|value| value.trim().parse::<usize>().ok())
    {
        return Some(OpenXmlValidatorOutcome::Errors(count));
    }

    Some(OpenXmlValidatorOutcome::Failed(format!(
        "stdout:\n{}\n\nstderr:\n{}",
        stdout, stderr
    )))
}

fn assert_openxml_sdk_validator_clean(path: &Path) {
    let Some(outcome) = run_openxml_sdk_validator(path) else {
        return;
    };
    assert_eq!(
        outcome,
        OpenXmlValidatorOutcome::Clean,
        "Open XML SDK validation failed for `{}`: {:?}",
        path.display(),
        outcome
    );
}

fn sanitize_fixture_label(label: &str) -> String {
    label
        .chars()
        .map(|ch| {
            if ch.is_ascii_alphanumeric() {
                ch.to_ascii_lowercase()
            } else {
                '-'
            }
        })
        .collect::<String>()
}

fn validator_score(outcome: &OpenXmlValidatorOutcome) -> usize {
    match outcome {
        OpenXmlValidatorOutcome::Clean => 0,
        OpenXmlValidatorOutcome::Errors(count) => *count,
        OpenXmlValidatorOutcome::Failed(_) => usize::MAX / 4,
    }
}

fn run_local_real_world_validation_regression(fixture_path: &Path, label: &str) {
    let label = sanitize_fixture_label(label);
    let workspace = local_real_world_workspace(label.as_str());
    let dirty_path = workspace.path().join(format!("{label}-open-save.docx"));
    let revised_path = workspace.path().join(format!("{label}-revised.docx"));
    let compared_path = workspace.path().join(format!("{label}-compared.docx"));
    let baseline = run_openxml_sdk_validator(fixture_path);

    let mut dirty = Document::open(fixture_path)
        .unwrap_or_else(|_| panic!("open `{}` for dirty save", fixture_path.display()));
    dirty.add_paragraph(format!(
        "validator-backed dirty-save regression marker for {label}"
    ));
    dirty
        .save(&dirty_path)
        .unwrap_or_else(|_| panic!("save dirty path for `{}`", fixture_path.display()));

    let mut revised = Document::open(fixture_path)
        .unwrap_or_else(|_| panic!("open `{}` for revise", fixture_path.display()));
    revised.add_heading(format!("{label} regression amendment"), 1);
    revised.add_paragraph(
        "This revision exists only to exercise real-world compare validation coverage in tests.",
    );
    revised
        .save(&revised_path)
        .unwrap_or_else(|_| panic!("save revised path for `{}`", fixture_path.display()));

    let compared = Document::compare(fixture_path, &revised_path, "Regression Bot")
        .unwrap_or_else(|_| panic!("compare fixture `{}`", fixture_path.display()));
    compared
        .save(&compared_path)
        .unwrap_or_else(|_| panic!("save compared path for `{}`", fixture_path.display()));

    if let Some(baseline) = baseline {
        for output_path in [&dirty_path, &revised_path, &compared_path] {
            let outcome = run_openxml_sdk_validator(output_path).unwrap_or_else(|| {
                panic!(
                    "validator unexpectedly unavailable while checking `{}`",
                    output_path.display()
                )
            });
            assert!(
                validator_score(&outcome) <= validator_score(&baseline),
                "validator outcome regressed for fixture `{}` on `{}`: baseline={:?}, output={:?}",
                fixture_path.display(),
                output_path.display(),
                baseline,
                outcome
            );
        }
    }

    let reopened = Document::open(&compared_path)
        .unwrap_or_else(|_| panic!("reopen compared `{}`", fixture_path.display()));
    assert!(
        !reopened.revisions().is_empty(),
        "real-world compare should produce revisions for `{}`",
        fixture_path.display()
    );
}

fn build_document_with_supported_part_revisions() -> Document {
    let mut document = Document::new();

    let body_insert = document.new_revision_metadata("Reviewer");
    document
        .add_paragraph("Body")
        .add_inserted_text(" Added", body_insert);

    let header_insert = document.new_revision_metadata("Reviewer");
    document
        .section_mut()
        .ensure_header()
        .add_paragraph("Header")
        .add_inserted_text(" Added", header_insert);

    let footer_delete = document.new_revision_metadata("Reviewer");
    document
        .section_mut()
        .ensure_footer()
        .add_paragraph("Footer Keep")
        .add_deleted_text(" Remove", footer_delete);

    document.add_footnote(offidized_docx::Footnote::from_text(7, "Footnote"));
    let footnote_insert = document.new_revision_metadata("Reviewer");
    document.footnotes_mut()[0].paragraphs_mut()[0].add_inserted_text(" Added", footnote_insert);

    document.add_endnote(offidized_docx::Endnote::from_text(9, "Endnote Keep"));
    let endnote_delete = document.new_revision_metadata("Reviewer");
    document.endnotes_mut()[0].paragraphs_mut()[0].add_deleted_text(" Remove", endnote_delete);

    document
}

#[test]
fn dirty_roundtrip_preserves_existing_tracked_changes() {
    let src = openxml_asset(
        "TestDataStorage/v2FxTestFiles/wordprocessing/mixed features/BackgroundReport - THE WORKING GROUP ON INTERNET GOVERNANCE.docx",
    );
    if skip_if_missing(&src) {
        return;
    }

    let original_xml = document_xml(&src);
    let original_del_count = count_tag(&original_xml, "w:del");
    let original_ins_count = count_tag(&original_xml, "w:ins");
    assert_eq!(
        original_del_count, 0,
        "fixture should not contain tracked deletions"
    );
    assert!(
        original_ins_count > 0,
        "fixture should contain tracked insertions"
    );
    let original_doc = Document::open(&src).expect("open fixture document");
    assert!(
        original_doc
            .revisions()
            .iter()
            .any(|revision| revision.kind == RevisionKind::Insertion),
        "fixture should expose at least one insertion through the high-level API"
    );

    let mut modified = Document::open(&src).expect("open for modification");
    modified.add_paragraph("__REDLINE_DIRTY_SENTINEL__");

    let temp = tempdir().expect("create tempdir");
    let output = temp.path().join("roundtripped.docx");
    modified.save(&output).expect("save modified redline docx");

    let roundtripped_xml = document_xml(&output);
    let roundtripped_del_count = count_tag(&roundtripped_xml, "w:del");
    let roundtripped_ins_count = count_tag(&roundtripped_xml, "w:ins");
    assert_eq!(roundtripped_del_count, original_del_count);
    assert_eq!(roundtripped_ins_count, original_ins_count);

    assert!(
        roundtripped_xml
            .contains("<w:ins w:id=\"2\" w:author=\"karen\" w:date=\"2005-06-21T16:50:00Z\"/>"),
        "tracked insertion should survive the dirty roundtrip"
    );

    let reopened = Document::open(&output).expect("reopen roundtripped docx");
    assert_eq!(reopened.revisions().len(), original_doc.revisions().len());
}

#[test]
fn programmatic_insertions_and_deletions_roundtrip_and_reopen() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("programmatic-redline.docx");
    let dirty_path = temp.path().join("programmatic-redline-dirty.docx");

    let mut document = Document::new();
    let inserted = document.new_revision_metadata_with_date("Reviewer", "2026-03-24T12:00:00Z");
    let deleted = document.new_revision_metadata("Reviewer");
    assert_ne!(inserted.id, deleted.id, "revision ids should be unique");
    let paragraph = document.add_paragraph("Alpha");
    paragraph.add_inserted_text(" Beta", inserted.clone());
    paragraph.add_deleted_text(" Gamma", deleted.clone());

    document
        .save(&path)
        .expect("save programmatic redline docx");

    let xml = document_xml(&path);
    assert_eq!(count_tag(&xml, "w:ins"), 1);
    assert_eq!(count_tag(&xml, "w:del"), 1);
    assert!(
        xml.contains("<w:t>Alpha</w:t>"),
        "base run should be present"
    );
    assert!(xml.contains("<w:ins"), "insertion should be serialized");
    assert!(xml.contains("<w:del"), "deletion should be serialized");

    let alpha_index = xml.find("Alpha").expect("Alpha text should exist");
    let ins_index = xml.find("<w:ins").expect("insertion tag should exist");
    let del_index = xml.find("<w:del").expect("deletion tag should exist");
    assert!(
        alpha_index < ins_index,
        "insertion should follow the base run"
    );
    assert!(ins_index < del_index, "deletion should follow insertion");

    let reopened = Document::open(&path).expect("reopen programmatic redline docx");
    let revisions = reopened.revisions();
    assert_eq!(revisions.len(), 2);
    assert_eq!(revisions[0].kind, RevisionKind::Insertion);
    assert_eq!(revisions[0].id, Some(inserted.id));
    assert_eq!(revisions[0].author.as_deref(), Some("Reviewer"));
    assert_eq!(revisions[0].date.as_deref(), Some("2026-03-24T12:00:00Z"));
    assert_eq!(revisions[0].text, " Beta");
    assert_eq!(revisions[1].kind, RevisionKind::Deletion);
    assert_eq!(revisions[1].id, Some(deleted.id));
    assert_eq!(revisions[1].author.as_deref(), Some("Reviewer"));
    assert_eq!(revisions[1].text, " Gamma");

    let mut dirty_reopened = Document::open(&path).expect("open redline docx for dirty save");
    dirty_reopened.add_paragraph("Tail");
    dirty_reopened
        .save(&dirty_path)
        .expect("save dirty redline docx");

    let dirty_xml = document_xml(&dirty_path);
    assert_eq!(count_tag(&dirty_xml, "w:ins"), 1);
    assert_eq!(count_tag(&dirty_xml, "w:del"), 1);
    assert!(dirty_xml.contains(" Beta"));
    assert!(dirty_xml.contains(" Gamma"));
}

#[test]
fn compare_builds_basic_redline_document() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp.path().join("original.docx");
    let revised_path = temp.path().join("revised.docx");
    let compared_path = temp.path().join("compared.docx");

    let mut original = Document::new();
    original.add_paragraph("Alpha Gamma");
    original.add_paragraph("Stable");
    original.save(&original_path).expect("save original docx");

    let mut revised = Document::new();
    revised.add_paragraph("Alpha Beta");
    revised.add_paragraph("Stable");
    revised.save(&revised_path).expect("save revised docx");

    let compared = Document::compare(&original_path, &revised_path, "Comparer")
        .expect("compare documents into redline");
    compared.save(&compared_path).expect("save compared docx");

    let compared_xml = document_xml(&compared_path);
    assert_eq!(count_tag(&compared_xml, "w:ins"), 1);
    assert_eq!(count_tag(&compared_xml, "w:del"), 1);
    assert!(compared_xml.contains("Alpha "));
    assert!(compared_xml.contains("Beta"));
    assert!(compared_xml.contains("Gamma"));

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert_eq!(revisions.len(), 2);
    assert!(revisions
        .iter()
        .any(|r| r.kind == RevisionKind::Insertion && r.text == "Beta"));
    assert!(revisions
        .iter()
        .any(|r| r.kind == RevisionKind::Deletion && r.text == "Gamma"));
}

#[test]
fn compare_marks_moved_body_paragraphs_as_moves_even_with_style_change() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp.path().join("original-move-style-compare.docx");
    let revised_path = temp.path().join("revised-move-style-compare.docx");
    let compared_path = temp.path().join("compared-move-style-compare.docx");

    let mut original = Document::new();
    original.add_paragraph("Intro");
    original.add_paragraph("Moved paragraph");
    original.add_paragraph("Stable tail");
    original.save(&original_path).expect("save original docx");

    let mut revised = Document::new();
    revised.add_paragraph("Intro");
    revised.add_paragraph("Stable tail");
    revised.add_heading("Moved paragraph", 1);
    revised.save(&revised_path).expect("save revised docx");

    let compared = Document::compare(&original_path, &revised_path, "Comparer")
        .expect("compare moved body paragraphs with style change");
    compared.save(&compared_path).expect("save compared docx");

    let compared_xml = document_xml(&compared_path);
    assert!(compared_xml.contains("<w:pStyle w:val=\"Heading1\"/>"));
    assert!(compared_xml.contains("<w:rPr>\n          <w:moveTo"));

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:1"
            && revision.kind == RevisionKind::MoveFrom
            && revision.text == "Moved paragraph"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:3"
            && revision.kind == RevisionKind::MoveTo
            && revision.text == "Moved paragraph"
    }));
    assert_eq!(reopened.paragraphs()[3].heading_level(), Some(1));
}

#[test]
fn compare_marks_simple_moved_header_paragraphs_as_moves() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp.path().join("original-header-move-compare.docx");
    let revised_path = temp.path().join("revised-header-move-compare.docx");
    let compared_path = temp.path().join("compared-header-move-compare.docx");

    let mut original = Document::new();
    original
        .section_mut()
        .ensure_header()
        .add_paragraph("Intro");
    original
        .section_mut()
        .ensure_header()
        .add_paragraph("Moved header paragraph");
    original
        .section_mut()
        .ensure_header()
        .add_paragraph("Stable tail");
    original.save(&original_path).expect("save original docx");

    let mut revised = Document::new();
    revised.section_mut().ensure_header().add_paragraph("Intro");
    revised
        .section_mut()
        .ensure_header()
        .add_paragraph("Stable tail");
    revised
        .section_mut()
        .ensure_header()
        .add_paragraph("Moved header paragraph");
    revised.save(&revised_path).expect("save revised docx");

    let compared = Document::compare(&original_path, &revised_path, "Comparer")
        .expect("compare moved header paragraphs");
    compared.save(&compared_path).expect("save compared docx");

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "header/default/paragraph:1"
            && revision.kind == RevisionKind::MoveFrom
            && revision.text == "Moved header paragraph"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "header/default/paragraph:3"
            && revision.kind == RevisionKind::MoveTo
            && revision.text == "Moved header paragraph"
    }));

    let header_xml = part_xml(&compared_path, "/word/header1.xml");
    assert!(header_xml.contains("w:moveFromRangeStart"));
    assert!(header_xml.contains("w:moveFromRangeEnd"));
    assert!(header_xml.contains("w:moveToRangeStart"));
    assert!(header_xml.contains("w:moveToRangeEnd"));
    assert!(header_xml.contains("<w:moveFrom w:id="));
    assert!(header_xml.contains("<w:moveTo w:id="));
    assert!(header_xml.contains("w:author=\"Comparer\""));
    assert!(header_xml.contains("w:date=\"2000-01-01T00:00:00Z\""));
}

#[test]
fn compare_marks_simple_moved_footnote_paragraphs_with_move_ranges() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp.path().join("original-footnote-move-compare.docx");
    let revised_path = temp.path().join("revised-footnote-move-compare.docx");
    let compared_path = temp.path().join("compared-footnote-move-compare.docx");

    let mut original = Document::new();
    let mut original_footnote = offidized_docx::Footnote::new(1);
    original_footnote.add_paragraph("Intro");
    original_footnote.add_paragraph("Moved footnote paragraph");
    original_footnote.add_paragraph("Stable tail");
    original.add_footnote(original_footnote);
    original.save(&original_path).expect("save original docx");

    let mut revised = Document::new();
    let mut revised_footnote = offidized_docx::Footnote::new(1);
    revised_footnote.add_paragraph("Intro");
    revised_footnote.add_paragraph("Stable tail");
    revised_footnote.add_paragraph("Moved footnote paragraph");
    revised.add_footnote(revised_footnote);
    revised.save(&revised_path).expect("save revised docx");

    let compared = Document::compare(&original_path, &revised_path, "Comparer")
        .expect("compare moved footnote paragraphs");
    compared.save(&compared_path).expect("save compared docx");

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "footnote:1/paragraph:1"
            && revision.kind == RevisionKind::MoveFrom
            && revision.text == "Moved footnote paragraph"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "footnote:1/paragraph:3"
            && revision.kind == RevisionKind::MoveTo
            && revision.text == "Moved footnote paragraph"
    }));

    let footnote_xml = part_xml(&compared_path, "/word/footnotes.xml");
    assert!(footnote_xml.contains("w:moveFromRangeStart"));
    assert!(footnote_xml.contains("w:moveFromRangeEnd"));
    assert!(footnote_xml.contains("w:moveToRangeStart"));
    assert!(footnote_xml.contains("w:moveToRangeEnd"));
    assert!(footnote_xml.contains("<w:moveFrom w:id="));
    assert!(footnote_xml.contains("<w:moveTo w:id="));
    assert!(footnote_xml.contains("w:author=\"Comparer\""));
    assert!(footnote_xml.contains("w:date=\"2000-01-01T00:00:00Z\""));
}

#[test]
fn compare_marks_simple_moved_body_table_cell_paragraphs_with_move_ranges() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp
        .path()
        .join("original-body-table-cell-move-compare.docx");
    let revised_path = temp
        .path()
        .join("revised-body-table-cell-move-compare.docx");
    let compared_path = temp
        .path()
        .join("compared-body-table-cell-move-compare.docx");

    let mut original = Document::new();
    original.add_table(1, 1).set_cell_text(0, 0, "placeholder");
    original.save(&original_path).expect("save original docx");
    rewrite_document_xml(&original_path, |xml| {
        xml.replace(
            "<w:p>\n            <w:r>\n              <w:t>placeholder</w:t>\n            </w:r>\n          </w:p>",
            "<w:p><w:r><w:t>Intro</w:t></w:r></w:p><w:p><w:r><w:t>Moved cell paragraph</w:t></w:r></w:p><w:p><w:r><w:t>Stable tail</w:t></w:r></w:p>",
        )
    });

    let mut revised = Document::new();
    revised.add_table(1, 1).set_cell_text(0, 0, "placeholder");
    revised.save(&revised_path).expect("save revised docx");
    rewrite_document_xml(&revised_path, |xml| {
        xml.replace(
            "<w:p>\n            <w:r>\n              <w:t>placeholder</w:t>\n            </w:r>\n          </w:p>",
            "<w:p><w:r><w:t>Intro</w:t></w:r></w:p><w:p><w:r><w:t>Stable tail</w:t></w:r></w:p><w:p><w:r><w:t>Moved cell paragraph</w:t></w:r></w:p>",
        )
    });

    let compared = Document::compare(&original_path, &revised_path, "Comparer")
        .expect("compare moved body table-cell paragraphs");
    compared.save(&compared_path).expect("save compared docx");

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/table:0/cell:0,0/paragraph:1"
            && revision.kind == RevisionKind::MoveFrom
            && revision.text == "Moved cell paragraph"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/table:0/cell:0,0/paragraph:3"
            && revision.kind == RevisionKind::MoveTo
            && revision.text == "Moved cell paragraph"
    }));

    let document_xml = part_xml(&compared_path, "/word/document.xml");
    assert!(document_xml.contains("w:moveFromRangeStart"));
    assert!(document_xml.contains("w:moveFromRangeEnd"));
    assert!(document_xml.contains("w:moveToRangeStart"));
    assert!(document_xml.contains("w:moveToRangeEnd"));
    assert!(document_xml.contains("<w:moveFrom w:id="));
    assert!(document_xml.contains("<w:moveTo w:id="));
    assert!(document_xml.contains("w:author=\"Comparer\""));
    assert!(document_xml.contains("w:date=\"2000-01-01T00:00:00Z\""));
}

#[test]
fn compare_redlines_header_and_note_paragraph_parts() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp.path().join("original-nonbody-compare.docx");
    let revised_path = temp.path().join("revised-nonbody-compare.docx");
    let compared_path = temp.path().join("compared-nonbody-compare.docx");

    let mut original = Document::new();
    original
        .section_mut()
        .ensure_header()
        .add_paragraph("Header Alpha");
    original.add_footnote(offidized_docx::Footnote::from_text(1, "Foot Alpha"));
    original.save(&original_path).expect("save original docx");

    let mut revised = Document::new();
    revised
        .section_mut()
        .ensure_header()
        .add_paragraph("Header Beta");
    revised.add_footnote(offidized_docx::Footnote::from_text(1, "Foot Beta"));
    revised.save(&revised_path).expect("save revised docx");

    let compared = Document::compare_with_date(
        &original_path,
        &revised_path,
        "Reviewer",
        Some("2026-03-24T20:00:00Z".to_string()),
    )
    .expect("compare non-body paragraph parts");
    compared.save(&compared_path).expect("save compared docx");

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "header/default/paragraph:0" && revision.kind == RevisionKind::Deletion
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "header/default/paragraph:0"
            && revision.kind == RevisionKind::Insertion
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "footnote:1/paragraph:0" && revision.kind == RevisionKind::Deletion
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "footnote:1/paragraph:0" && revision.kind == RevisionKind::Insertion
    }));
}

#[test]
fn compare_redlines_body_table_cells() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp.path().join("original-body-table-compare.docx");
    let revised_path = temp.path().join("revised-body-table-compare.docx");
    let compared_path = temp.path().join("compared-body-table-compare.docx");

    let mut original = Document::new();
    original.add_table(1, 1).set_cell_text(0, 0, "Budget Q1");
    original.save(&original_path).expect("save original docx");

    let mut revised = Document::new();
    revised.add_table(1, 1).set_cell_text(0, 0, "Budget Q2");
    revised.save(&revised_path).expect("save revised docx");

    let compared = Document::compare_with_date(
        &original_path,
        &revised_path,
        "Reviewer",
        Some("2026-03-24T20:05:00Z".to_string()),
    )
    .expect("compare body table cells");
    compared.save(&compared_path).expect("save compared docx");

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/table:0/cell:0,0/paragraph:0"
            && revision.kind == RevisionKind::Deletion
            && revision.text == "1"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/table:0/cell:0,0/paragraph:0"
            && revision.kind == RevisionKind::Insertion
            && revision.text == "2"
    }));
}

#[test]
fn compare_redlines_supported_non_body_table_parts() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp.path().join("original-nonbody-table-compare.docx");
    let revised_path = temp.path().join("revised-nonbody-table-compare.docx");
    let compared_path = temp.path().join("compared-nonbody-table-compare.docx");

    let mut original = Document::new();
    original
        .section_mut()
        .ensure_header()
        .add_table(1, 1)
        .set_cell_text(0, 0, "Header Alpha");
    let mut original_footnote = offidized_docx::Footnote::new(1);
    original_footnote
        .add_table(1, 1)
        .set_cell_text(0, 0, "Foot Alpha");
    original.add_footnote(original_footnote);
    let mut original_endnote = offidized_docx::Endnote::new(1);
    original_endnote
        .add_table(1, 1)
        .set_cell_text(0, 0, "End Alpha");
    original.add_endnote(original_endnote);
    original.save(&original_path).expect("save original docx");

    let mut revised = Document::new();
    revised
        .section_mut()
        .ensure_header()
        .add_table(1, 1)
        .set_cell_text(0, 0, "Header Beta");
    let mut revised_footnote = offidized_docx::Footnote::new(1);
    revised_footnote
        .add_table(1, 1)
        .set_cell_text(0, 0, "Foot Beta");
    revised.add_footnote(revised_footnote);
    let mut revised_endnote = offidized_docx::Endnote::new(1);
    revised_endnote
        .add_table(1, 1)
        .set_cell_text(0, 0, "End Beta");
    revised.add_endnote(revised_endnote);
    revised.save(&revised_path).expect("save revised docx");

    let compared = Document::compare_with_date(
        &original_path,
        &revised_path,
        "Reviewer",
        Some("2026-03-24T20:10:00Z".to_string()),
    )
    .expect("compare non-body table parts");
    compared.save(&compared_path).expect("save compared docx");

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "header/default/table:0/cell:0,0/paragraph:0"
            && revision.kind == RevisionKind::Deletion
            && revision.text == "Alpha"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "header/default/table:0/cell:0,0/paragraph:0"
            && revision.kind == RevisionKind::Insertion
            && revision.text == "Beta"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "footnote:1/table:0/cell:0,0/paragraph:0"
            && revision.kind == RevisionKind::Deletion
            && revision.text == "Alpha"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "endnote:1/table:0/cell:0,0/paragraph:0"
            && revision.kind == RevisionKind::Insertion
            && revision.text == "Beta"
    }));
}

#[test]
fn compare_redlines_simple_drawing_text_box_content() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp.path().join("original-drawing-textbox-compare.docx");
    let revised_path = temp.path().join("revised-drawing-textbox-compare.docx");
    let compared_path = temp.path().join("compared-drawing-textbox-compare.docx");

    let mut original = Document::new();
    original.add_paragraph("placeholder");
    original.save(&original_path).expect("save original docx");
    rewrite_document_xml(&original_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Drawing Alpha</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });

    let mut revised = Document::new();
    revised.add_paragraph("placeholder");
    revised.save(&revised_path).expect("save revised docx");
    rewrite_document_xml(&revised_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Drawing Beta</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });

    let compared = Document::compare_with_date(
        &original_path,
        &revised_path,
        "Reviewer",
        Some("2026-03-24T20:30:00Z".to_string()),
    )
    .expect("compare drawing textbox content");
    compared.save(&compared_path).expect("save compared docx");

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:0"
            && revision.kind == RevisionKind::Deletion
            && revision.text == "Alpha"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:0"
            && revision.kind == RevisionKind::Insertion
            && revision.text == "Beta"
    }));
}

#[test]
fn compare_redlines_multi_paragraph_vml_text_box_content() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp.path().join("original-multi-vml-textbox-compare.docx");
    let revised_path = temp.path().join("revised-multi-vml-textbox-compare.docx");
    let compared_path = temp.path().join("compared-multi-vml-textbox-compare.docx");

    let mut original = Document::new();
    original.add_paragraph("placeholder");
    original.save(&original_path).expect("save original docx");
    let first_paragraph = "<w:p w:rsidR=\"00111111\"><w:r><w:t>Lead</w:t></w:r></w:p>";
    let original_middle = "<w:p w:rsidR=\"00222222\"><w:r><w:t>Alpha</w:t></w:r></w:p>";
    let last_paragraph = "<w:p w:rsidR=\"00333333\"><w:r><w:t>Tail</w:t></w:r></w:p>";
    rewrite_document_xml(&original_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            format!(
                "<w:r><w:pict xmlns:v=\"urn:schemas-microsoft-com:vml\"><v:shape id=\"TextBox1\"><v:textbox><w:txbxContent>{first_paragraph}{original_middle}{last_paragraph}</w:txbxContent></v:textbox></v:shape></w:pict></w:r>"
            )
            .as_str(),
        )
    });

    let mut revised = Document::new();
    revised.add_paragraph("placeholder");
    revised.save(&revised_path).expect("save revised docx");
    let revised_middle = "<w:p w:rsidR=\"00222222\"><w:r><w:t>Beta</w:t></w:r></w:p>";
    rewrite_document_xml(&revised_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            format!(
                "<w:r><w:pict xmlns:v=\"urn:schemas-microsoft-com:vml\"><v:shape id=\"TextBox1\"><v:textbox><w:txbxContent>{first_paragraph}{revised_middle}{last_paragraph}</w:txbxContent></v:textbox></v:shape></w:pict></w:r>"
            )
            .as_str(),
        )
    });

    let compared = Document::compare_with_date(
        &original_path,
        &revised_path,
        "Reviewer",
        Some("2026-03-26T12:10:00Z".to_string()),
    )
    .expect("compare multi-paragraph VML textbox content");
    compared.save(&compared_path).expect("save compared docx");

    let compared_xml = document_xml(&compared_path);
    assert!(compared_xml.contains("w:t>Lead</w:t>"));
    assert!(compared_xml.contains("w:t>Tail</w:t>"));
    assert!(compared_xml.contains("<w:del"));
    assert!(compared_xml.contains("Alpha"));
    assert!(compared_xml.contains("<w:ins"));
    assert!(compared_xml.contains("Beta"));

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:0"
            && revision.kind == RevisionKind::Deletion
            && revision.text == "Alpha"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:0"
            && revision.kind == RevisionKind::Insertion
            && revision.text == "Beta"
    }));
}

#[test]
fn compare_redlines_multi_paragraph_drawing_text_box_content() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp
        .path()
        .join("original-multi-drawing-textbox-compare.docx");
    let revised_path = temp
        .path()
        .join("revised-multi-drawing-textbox-compare.docx");
    let compared_path = temp
        .path()
        .join("compared-multi-drawing-textbox-compare.docx");

    let mut original = Document::new();
    original.add_paragraph("placeholder");
    original.save(&original_path).expect("save original docx");
    let first_paragraph = "<w:p w:rsidR=\"00111111\"><w:r><w:t>Lead</w:t></w:r></w:p>";
    let original_middle = "<w:p w:rsidR=\"00222222\"><w:r><w:t>Alpha</w:t></w:r></w:p>";
    let last_paragraph = "<w:p w:rsidR=\"00333333\"><w:r><w:t>Tail</w:t></w:r></w:p>";
    rewrite_document_xml(&original_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            format!(
                "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent>{first_paragraph}{original_middle}{last_paragraph}</w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>"
            )
            .as_str(),
        )
    });

    let mut revised = Document::new();
    revised.add_paragraph("placeholder");
    revised.save(&revised_path).expect("save revised docx");
    let revised_middle = "<w:p w:rsidR=\"00222222\"><w:r><w:t>Beta</w:t></w:r></w:p>";
    rewrite_document_xml(&revised_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            format!(
                "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent>{first_paragraph}{revised_middle}{last_paragraph}</w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>"
            )
            .as_str(),
        )
    });

    let compared = Document::compare_with_date(
        &original_path,
        &revised_path,
        "Reviewer",
        Some("2026-03-26T12:15:00Z".to_string()),
    )
    .expect("compare multi-paragraph drawing textbox content");
    compared.save(&compared_path).expect("save compared docx");

    let compared_xml = document_xml(&compared_path);
    assert!(compared_xml.contains("w:t>Lead</w:t>"));
    assert!(compared_xml.contains("w:t>Tail</w:t>"));
    assert!(compared_xml.contains("<w:del"));
    assert!(compared_xml.contains("Alpha"));
    assert!(compared_xml.contains("<w:ins"));
    assert!(compared_xml.contains("Beta"));

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:0"
            && revision.kind == RevisionKind::Deletion
            && revision.text == "Alpha"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:0"
            && revision.kind == RevisionKind::Insertion
            && revision.text == "Beta"
    }));
}

#[test]
fn compare_redlines_vml_text_box_content_with_tab_run() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp.path().join("original-vml-textbox-tab-compare.docx");
    let revised_path = temp.path().join("revised-vml-textbox-tab-compare.docx");
    let compared_path = temp.path().join("compared-vml-textbox-tab-compare.docx");

    let mut original = Document::new();
    original.add_paragraph("placeholder");
    original.save(&original_path).expect("save original docx");
    rewrite_document_xml(&original_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:pict xmlns:v=\"urn:schemas-microsoft-com:vml\"><v:shape id=\"TextBox1\"><v:textbox><w:txbxContent><w:p><w:r><w:t>Label</w:t><w:tab/><w:t>Alpha</w:t></w:r></w:p></w:txbxContent></v:textbox></v:shape></w:pict></w:r>",
        )
    });

    let mut revised = Document::new();
    revised.add_paragraph("placeholder");
    revised.save(&revised_path).expect("save revised docx");
    rewrite_document_xml(&revised_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:pict xmlns:v=\"urn:schemas-microsoft-com:vml\"><v:shape id=\"TextBox1\"><v:textbox><w:txbxContent><w:p><w:r><w:t>Label</w:t><w:tab/><w:t>Beta</w:t></w:r></w:p></w:txbxContent></v:textbox></v:shape></w:pict></w:r>",
        )
    });

    let compared = Document::compare_with_date(
        &original_path,
        &revised_path,
        "Reviewer",
        Some("2026-03-26T12:40:00Z".to_string()),
    )
    .expect("compare VML textbox tab content");
    compared.save(&compared_path).expect("save compared docx");

    let compared_xml = document_xml(&compared_path);
    assert!(compared_xml.contains("<w:tab/>"));
    assert!(compared_xml.contains("<w:del"));
    assert!(compared_xml.contains("Alpha"));
    assert!(compared_xml.contains("<w:ins"));
    assert!(compared_xml.contains("Beta"));
}

#[test]
fn compare_redlines_drawing_text_box_content_with_break_run() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp
        .path()
        .join("original-drawing-textbox-break-compare.docx");
    let revised_path = temp
        .path()
        .join("revised-drawing-textbox-break-compare.docx");
    let compared_path = temp
        .path()
        .join("compared-drawing-textbox-break-compare.docx");

    let mut original = Document::new();
    original.add_paragraph("placeholder");
    original.save(&original_path).expect("save original docx");
    rewrite_document_xml(&original_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Alpha</w:t><w:br/><w:t>Beta</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });

    let mut revised = Document::new();
    revised.add_paragraph("placeholder");
    revised.save(&revised_path).expect("save revised docx");
    rewrite_document_xml(&revised_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Alpha</w:t><w:br/><w:t>Gamma</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });

    let compared = Document::compare_with_date(
        &original_path,
        &revised_path,
        "Reviewer",
        Some("2026-03-26T12:45:00Z".to_string()),
    )
    .expect("compare drawing textbox break content");
    compared.save(&compared_path).expect("save compared docx");

    let compared_xml = document_xml(&compared_path);
    assert!(compared_xml.contains("<w:br/>"));
    assert!(compared_xml.contains("<w:del"));
    assert!(compared_xml.contains("Beta"));
    assert!(compared_xml.contains("<w:ins"));
    assert!(compared_xml.contains("Gamma"));
}

#[test]
fn compare_redlines_drawing_text_box_hyperlink_content() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp
        .path()
        .join("original-drawing-textbox-hyperlink-compare.docx");
    let revised_path = temp
        .path()
        .join("revised-drawing-textbox-hyperlink-compare.docx");
    let compared_path = temp
        .path()
        .join("compared-drawing-textbox-hyperlink-compare.docx");

    let mut original = Document::new();
    original.add_paragraph("placeholder");
    original.save(&original_path).expect("save original docx");
    rewrite_document_xml(&original_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Lead </w:t></w:r><w:hyperlink r:id=\"rIdHyper1\"><w:r><w:t>Go Alpha</w:t></w:r></w:hyperlink><w:r><w:t> Tail</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });

    let mut revised = Document::new();
    revised.add_paragraph("placeholder");
    revised.save(&revised_path).expect("save revised docx");
    rewrite_document_xml(&revised_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Lead </w:t></w:r><w:hyperlink r:id=\"rIdHyper1\"><w:r><w:t>Go Beta</w:t></w:r></w:hyperlink><w:r><w:t> Tail</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });

    let compared = Document::compare_with_date(
        &original_path,
        &revised_path,
        "Reviewer",
        Some("2026-03-26T13:05:00Z".to_string()),
    )
    .expect("compare drawing textbox hyperlink content");
    compared.save(&compared_path).expect("save compared docx");

    let compared_xml = document_xml(&compared_path);
    assert!(compared_xml.contains("<w:hyperlink r:id=\"rIdHyper1\">"));
    assert!(compared_xml.contains("<w:del"));
    assert!(compared_xml.contains("Alpha"));
    assert!(compared_xml.contains("<w:ins"));
    assert!(compared_xml.contains("Beta"));
}

#[test]
fn compare_redlines_drawing_text_box_preserves_perm_markers() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp
        .path()
        .join("original-drawing-textbox-perm-compare.docx");
    let revised_path = temp
        .path()
        .join("revised-drawing-textbox-perm-compare.docx");
    let compared_path = temp
        .path()
        .join("compared-drawing-textbox-perm-compare.docx");

    let mut original = Document::new();
    original.add_paragraph("placeholder");
    original.save(&original_path).expect("save original docx");
    rewrite_document_xml(&original_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:permStart w:id=\"7\" w:edGrp=\"everyone\"/><w:r><w:t>Alpha</w:t></w:r><w:permEnd w:id=\"7\"/></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });

    let mut revised = Document::new();
    revised.add_paragraph("placeholder");
    revised.save(&revised_path).expect("save revised docx");
    rewrite_document_xml(&revised_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:permStart w:id=\"7\" w:edGrp=\"everyone\"/><w:r><w:t>Beta</w:t></w:r><w:permEnd w:id=\"7\"/></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });

    let compared = Document::compare_with_date(
        &original_path,
        &revised_path,
        "Reviewer",
        Some("2026-03-26T12:55:00Z".to_string()),
    )
    .expect("compare drawing textbox permission content");
    compared.save(&compared_path).expect("save compared docx");

    let compared_xml = document_xml(&compared_path);
    assert!(compared_xml.contains("w:permStart w:id=\"7\" w:edGrp=\"everyone\""));
    assert!(compared_xml.contains("w:permEnd w:id=\"7\""));
    assert!(compared_xml.contains("<w:del"));
    assert!(compared_xml.contains("Alpha"));
    assert!(compared_xml.contains("<w:ins"));
    assert!(compared_xml.contains("Beta"));
}

#[test]
fn compare_redlines_drawing_text_box_with_soft_hyphen_run() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp
        .path()
        .join("original-drawing-textbox-soft-hyphen-compare.docx");
    let revised_path = temp
        .path()
        .join("revised-drawing-textbox-soft-hyphen-compare.docx");
    let compared_path = temp
        .path()
        .join("compared-drawing-textbox-soft-hyphen-compare.docx");

    let mut original = Document::new();
    original.add_paragraph("placeholder");
    original.save(&original_path).expect("save original docx");
    rewrite_document_xml(&original_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Alpha</w:t><w:softHyphen/><w:t>Beta</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });

    let mut revised = Document::new();
    revised.add_paragraph("placeholder");
    revised.save(&revised_path).expect("save revised docx");
    rewrite_document_xml(&revised_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Alpha</w:t><w:softHyphen/><w:t>Gamma</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });

    let compared = Document::compare_with_date(
        &original_path,
        &revised_path,
        "Reviewer",
        Some("2026-03-26T12:57:00Z".to_string()),
    )
    .expect("compare drawing textbox soft-hyphen content");
    compared.save(&compared_path).expect("save compared docx");

    let compared_xml = document_xml(&compared_path);
    assert!(compared_xml.contains("<w:softHyphen/>"));
    assert!(compared_xml.contains("<w:del"));
    assert!(compared_xml.contains("Beta"));
    assert!(compared_xml.contains("<w:ins"));
    assert!(compared_xml.contains("Gamma"));
}

#[test]
fn compare_redlines_vml_text_box_preserves_bookmark_markers() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp
        .path()
        .join("original-vml-textbox-bookmark-compare.docx");
    let revised_path = temp
        .path()
        .join("revised-vml-textbox-bookmark-compare.docx");
    let compared_path = temp
        .path()
        .join("compared-vml-textbox-bookmark-compare.docx");

    let mut original = Document::new();
    original.add_paragraph("placeholder");
    original.save(&original_path).expect("save original docx");
    rewrite_document_xml(&original_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:pict xmlns:v=\"urn:schemas-microsoft-com:vml\"><v:shape id=\"TextBox1\"><v:textbox><w:txbxContent><w:p><w:bookmarkStart w:id=\"7\" w:name=\"TbxMark\"/><w:r><w:t>Alpha</w:t></w:r><w:bookmarkEnd w:id=\"7\"/></w:p></w:txbxContent></v:textbox></v:shape></w:pict></w:r>",
        )
    });

    let mut revised = Document::new();
    revised.add_paragraph("placeholder");
    revised.save(&revised_path).expect("save revised docx");
    rewrite_document_xml(&revised_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:pict xmlns:v=\"urn:schemas-microsoft-com:vml\"><v:shape id=\"TextBox1\"><v:textbox><w:txbxContent><w:p><w:bookmarkStart w:id=\"7\" w:name=\"TbxMark\"/><w:r><w:t>Beta</w:t></w:r><w:bookmarkEnd w:id=\"7\"/></w:p></w:txbxContent></v:textbox></v:shape></w:pict></w:r>",
        )
    });

    let compared = Document::compare_with_date(
        &original_path,
        &revised_path,
        "Reviewer",
        Some("2026-03-24T20:31:00Z".to_string()),
    )
    .expect("compare VML textbox bookmark content");
    compared.save(&compared_path).expect("save compared docx");

    let compared_xml = document_xml(&compared_path);
    assert!(compared_xml.contains("w:bookmarkStart w:id=\"7\" w:name=\"TbxMark\""));
    assert!(compared_xml.contains("w:bookmarkEnd w:id=\"7\""));
    assert!(compared_xml.contains("<w:del"));
    assert!(compared_xml.contains("Alpha"));
    assert!(compared_xml.contains("<w:ins"));
    assert!(compared_xml.contains("Beta"));

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:0"
            && revision.kind == RevisionKind::Deletion
            && revision.text == "Alpha"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:0"
            && revision.kind == RevisionKind::Insertion
            && revision.text == "Beta"
    }));
}

#[test]
fn compare_redlines_drawing_text_box_preserves_move_range_markers() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp
        .path()
        .join("original-drawing-textbox-move-compare.docx");
    let revised_path = temp
        .path()
        .join("revised-drawing-textbox-move-compare.docx");
    let compared_path = temp
        .path()
        .join("compared-drawing-textbox-move-compare.docx");

    let mut original = Document::new();
    original.add_paragraph("placeholder");
    original.save(&original_path).expect("save original docx");
    rewrite_document_xml(&original_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:moveFromRangeStart w:id=\"8\"/><w:r><w:t>Alpha</w:t></w:r><w:moveFromRangeEnd w:id=\"8\"/></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });

    let mut revised = Document::new();
    revised.add_paragraph("placeholder");
    revised.save(&revised_path).expect("save revised docx");
    rewrite_document_xml(&revised_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:moveFromRangeStart w:id=\"8\"/><w:r><w:t>Beta</w:t></w:r><w:moveFromRangeEnd w:id=\"8\"/></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });

    let compared = Document::compare_with_date(
        &original_path,
        &revised_path,
        "Reviewer",
        Some("2026-03-24T20:32:00Z".to_string()),
    )
    .expect("compare drawing textbox move content");
    compared.save(&compared_path).expect("save compared docx");

    let compared_xml = document_xml(&compared_path);
    assert!(compared_xml.contains("w:moveFromRangeStart w:id=\"8\""));
    assert!(compared_xml.contains("w:moveFromRangeEnd w:id=\"8\""));
    assert!(compared_xml.contains("<w:del"));
    assert!(compared_xml.contains("Alpha"));
    assert!(compared_xml.contains("<w:ins"));
    assert!(compared_xml.contains("Beta"));

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:0"
            && revision.kind == RevisionKind::Deletion
            && revision.text == "Alpha"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:0"
            && revision.kind == RevisionKind::Insertion
            && revision.text == "Beta"
    }));
}

#[test]
fn compare_redlines_supported_non_body_text_box_parts() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp.path().join("original-nonbody-textbox-compare.docx");
    let revised_path = temp.path().join("revised-nonbody-textbox-compare.docx");
    let compared_path = temp.path().join("compared-nonbody-textbox-compare.docx");

    let mut original = Document::new();
    original
        .section_mut()
        .ensure_header()
        .add_paragraph("placeholder");
    original.add_footnote(offidized_docx::Footnote::from_text(1, "placeholder"));
    original.save(&original_path).expect("save original docx");
    rewrite_part_xml(&original_path, "/word/header1.xml", |xml| {
        xml.replace(
            "<w:r>\n      <w:t>placeholder</w:t>\n    </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Header Alpha</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });
    rewrite_part_xml(&original_path, "/word/footnotes.xml", |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Foot Alpha</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });

    let mut revised = Document::new();
    revised
        .section_mut()
        .ensure_header()
        .add_paragraph("placeholder");
    revised.add_footnote(offidized_docx::Footnote::from_text(1, "placeholder"));
    revised.save(&revised_path).expect("save revised docx");
    rewrite_part_xml(&revised_path, "/word/header1.xml", |xml| {
        xml.replace(
            "<w:r>\n      <w:t>placeholder</w:t>\n    </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Header Beta</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });
    rewrite_part_xml(&revised_path, "/word/footnotes.xml", |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Foot Beta</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });

    let compared = Document::compare_with_date(
        &original_path,
        &revised_path,
        "Reviewer",
        Some("2026-03-24T20:35:00Z".to_string()),
    )
    .expect("compare non-body textbox content");
    compared.save(&compared_path).expect("save compared docx");

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "header/default/paragraph:0"
            && revision.kind == RevisionKind::Deletion
            && revision.text == "Alpha"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "header/default/paragraph:0"
            && revision.kind == RevisionKind::Insertion
            && revision.text == "Beta"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "footnote:1/paragraph:0"
            && revision.kind == RevisionKind::Deletion
            && revision.text == "Alpha"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "footnote:1/paragraph:0"
            && revision.kind == RevisionKind::Insertion
            && revision.text == "Beta"
    }));
}

#[test]
fn compare_marks_simple_moved_body_text_box_paragraphs_as_moves() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp.path().join("original-body-textbox-move-compare.docx");
    let revised_path = temp.path().join("revised-body-textbox-move-compare.docx");
    let compared_path = temp.path().join("compared-body-textbox-move-compare.docx");

    let mut original = Document::new();
    original.add_paragraph("Intro");
    original.add_paragraph("placeholder");
    original.add_paragraph("Stable tail");
    original.save(&original_path).expect("save original docx");
    rewrite_document_xml(&original_path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Moved textbox paragraph</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });

    let mut revised = Document::new();
    revised.add_paragraph("Intro");
    revised.add_paragraph("Stable tail");
    revised.add_paragraph("placeholder");
    revised.save(&revised_path).expect("save revised docx");
    rewrite_document_xml(&revised_path, |xml| {
        xml.replacen(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Moved textbox paragraph</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
            1,
        )
    });

    let compared = Document::compare(&original_path, &revised_path, "Comparer")
        .expect("compare moved body textbox paragraphs");
    compared.save(&compared_path).expect("save compared docx");

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:1"
            && revision.kind == RevisionKind::MoveFrom
            && revision.text == "Moved textbox paragraph"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:3"
            && revision.kind == RevisionKind::MoveTo
            && revision.text == "Moved textbox paragraph"
    }));

    let xml = document_xml(&compared_path);
    assert!(xml.contains("w:moveFromRangeStart"));
    assert!(xml.contains("w:moveToRangeStart"));
    assert!(xml.contains("<w:moveFrom w:id="));
    assert!(xml.contains("<w:moveTo w:id="));
}

#[test]
fn compare_marks_simple_moved_header_text_box_paragraphs_as_moves() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp
        .path()
        .join("original-header-textbox-move-compare.docx");
    let revised_path = temp.path().join("revised-header-textbox-move-compare.docx");
    let compared_path = temp
        .path()
        .join("compared-header-textbox-move-compare.docx");

    let mut original = Document::new();
    original
        .section_mut()
        .ensure_header()
        .add_paragraph("Intro");
    original
        .section_mut()
        .ensure_header()
        .add_paragraph("placeholder");
    original
        .section_mut()
        .ensure_header()
        .add_paragraph("Stable tail");
    original.save(&original_path).expect("save original docx");
    rewrite_part_xml(&original_path, "/word/header1.xml", |xml| {
        xml.replace(
            "<w:r>\n      <w:t>placeholder</w:t>\n    </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Moved header textbox paragraph</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });

    let mut revised = Document::new();
    revised.section_mut().ensure_header().add_paragraph("Intro");
    revised
        .section_mut()
        .ensure_header()
        .add_paragraph("Stable tail");
    revised
        .section_mut()
        .ensure_header()
        .add_paragraph("placeholder");
    revised.save(&revised_path).expect("save revised docx");
    rewrite_part_xml(&revised_path, "/word/header1.xml", |xml| {
        xml.replacen(
            "<w:r>\n      <w:t>placeholder</w:t>\n    </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Moved header textbox paragraph</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
            1,
        )
    });

    let compared = Document::compare(&original_path, &revised_path, "Comparer")
        .expect("compare moved header textbox paragraphs");
    compared.save(&compared_path).expect("save compared docx");

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "header/default/paragraph:1"
            && revision.kind == RevisionKind::MoveFrom
            && revision.text == "Moved header textbox paragraph"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "header/default/paragraph:3"
            && revision.kind == RevisionKind::MoveTo
            && revision.text == "Moved header textbox paragraph"
    }));

    let header_xml = part_xml(&compared_path, "/word/header1.xml");
    assert!(header_xml.contains("w:moveFromRangeStart"));
    assert!(header_xml.contains("w:moveToRangeStart"));
    assert!(header_xml.contains("<w:moveFrom w:id="));
    assert!(header_xml.contains("<w:moveTo w:id="));
}

#[test]
fn compare_aligns_inserted_paragraphs_without_redlining_following_matches() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp.path().join("original-insert.docx");
    let revised_path = temp.path().join("revised-insert.docx");
    let compared_path = temp.path().join("compared-insert.docx");

    let mut original = Document::new();
    original.add_paragraph("Intro");
    original.add_paragraph("Stable tail");
    original.save(&original_path).expect("save original docx");

    let mut revised = Document::new();
    revised.add_paragraph("Intro");
    revised.add_paragraph("New middle paragraph");
    revised.add_paragraph("Stable tail");
    revised.save(&revised_path).expect("save revised docx");

    let compared = Document::compare(&original_path, &revised_path, "Comparer")
        .expect("compare documents into redline");
    compared.save(&compared_path).expect("save compared docx");

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert_eq!(revisions.len(), 1);
    assert_eq!(revisions[0].kind, RevisionKind::Insertion);
    assert_eq!(revisions[0].text, "New middle paragraph");
    assert_eq!(reopened.paragraphs()[2].text(), "Stable tail");
}

#[test]
fn compare_anchors_small_body_paragraph_edit_before_inserted_following_paragraph() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp.path().join("original-small-body-edit-anchor.docx");
    let revised_path = temp.path().join("revised-small-body-edit-anchor.docx");
    let compared_path = temp.path().join("compared-small-body-edit-anchor.docx");

    let mut original = Document::new();
    original.add_paragraph("Intro Alpha");
    original.add_paragraph("Stable tail");
    original.save(&original_path).expect("save original docx");

    let mut revised = Document::new();
    revised.add_paragraph("Intro Beta");
    revised.add_paragraph("New middle paragraph");
    revised.add_paragraph("Stable tail");
    revised.save(&revised_path).expect("save revised docx");

    let compared = Document::compare(&original_path, &revised_path, "Comparer")
        .expect("compare small body edit before inserted paragraph");
    compared.save(&compared_path).expect("save compared docx");

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:0"
            && revision.kind == RevisionKind::Deletion
            && revision.text == "Alpha"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:0"
            && revision.kind == RevisionKind::Insertion
            && revision.text == "Beta"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:1"
            && revision.kind == RevisionKind::Insertion
            && revision.text == "New middle paragraph"
    }));
    assert!(!revisions
        .iter()
        .any(|revision| revision.text == "Intro Alpha"));
    assert!(!revisions
        .iter()
        .any(|revision| revision.text == "Intro Beta"));
    assert_eq!(reopened.paragraphs()[2].text(), "Stable tail");
}

#[test]
fn compare_anchors_small_header_paragraph_edit_before_inserted_following_paragraph() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp.path().join("original-small-header-edit-anchor.docx");
    let revised_path = temp.path().join("revised-small-header-edit-anchor.docx");
    let compared_path = temp.path().join("compared-small-header-edit-anchor.docx");

    let mut original = Document::new();
    original
        .section_mut()
        .ensure_header()
        .add_paragraph("Intro Alpha");
    original
        .section_mut()
        .ensure_header()
        .add_paragraph("Stable tail");
    original.save(&original_path).expect("save original docx");

    let mut revised = Document::new();
    revised
        .section_mut()
        .ensure_header()
        .add_paragraph("Intro Beta");
    revised
        .section_mut()
        .ensure_header()
        .add_paragraph("New middle paragraph");
    revised
        .section_mut()
        .ensure_header()
        .add_paragraph("Stable tail");
    revised.save(&revised_path).expect("save revised docx");

    let compared = Document::compare(&original_path, &revised_path, "Comparer")
        .expect("compare small header edit before inserted paragraph");
    compared.save(&compared_path).expect("save compared docx");

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "header/default/paragraph:0"
            && revision.kind == RevisionKind::Deletion
            && revision.text == "Alpha"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "header/default/paragraph:0"
            && revision.kind == RevisionKind::Insertion
            && revision.text == "Beta"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "header/default/paragraph:1"
            && revision.kind == RevisionKind::Insertion
            && revision.text == "New middle paragraph"
    }));
    assert!(!revisions
        .iter()
        .any(|revision| revision.text == "Intro Alpha"));
    assert!(!revisions
        .iter()
        .any(|revision| revision.text == "Intro Beta"));
    let header = reopened.section().header().expect("header");
    assert_eq!(header.paragraphs()[2].text(), "Stable tail");
}

#[test]
fn compare_aligns_style_changed_body_paragraph_before_inserted_following_paragraph() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp.path().join("original-style-align.docx");
    let revised_path = temp.path().join("revised-style-align.docx");
    let compared_path = temp.path().join("compared-style-align.docx");

    let mut original = Document::new();
    original.add_paragraph("Intro");
    original.add_paragraph("Styled anchor");
    original.add_paragraph("Stable tail");
    original.save(&original_path).expect("save original docx");

    let mut revised = Document::new();
    revised.add_paragraph("Intro");
    revised.add_paragraph("Styled anchor").set_style_id("Quote");
    revised.add_paragraph("New middle paragraph");
    revised.add_paragraph("Stable tail");
    revised.save(&revised_path).expect("save revised docx");

    let compared = Document::compare(&original_path, &revised_path, "Comparer")
        .expect("compare style-changed paragraph before insertion");
    compared.save(&compared_path).expect("save compared docx");

    let compared_xml = document_xml(&compared_path);
    assert!(compared_xml.contains("<w:pStyle w:val=\"Quote\"/>"));
    assert_eq!(count_tag(&compared_xml, "w:ins"), 1);
    assert!(
        !compared_xml.contains("<w:del><w:r><w:delText>Styled anchor</w:delText></w:r></w:del>")
    );

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert_eq!(revisions.len(), 1);
    assert_eq!(revisions[0].kind, RevisionKind::Insertion);
    assert_eq!(revisions[0].text, "New middle paragraph");
    assert_eq!(reopened.paragraphs()[1].text(), "Styled anchor");
    assert_eq!(reopened.paragraphs()[3].text(), "Stable tail");
}

#[test]
fn compare_aligns_style_changed_header_paragraph_before_inserted_following_paragraph() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp.path().join("original-header-style-align.docx");
    let revised_path = temp.path().join("revised-header-style-align.docx");
    let compared_path = temp.path().join("compared-header-style-align.docx");

    let mut original = Document::new();
    original
        .section_mut()
        .ensure_header()
        .add_paragraph("Intro");
    original
        .section_mut()
        .ensure_header()
        .add_paragraph("Styled anchor");
    original
        .section_mut()
        .ensure_header()
        .add_paragraph("Stable tail");
    original.save(&original_path).expect("save original docx");

    let mut revised = Document::new();
    revised.section_mut().ensure_header().add_paragraph("Intro");
    revised
        .section_mut()
        .ensure_header()
        .add_paragraph("Styled anchor")
        .set_style_id("Quote");
    revised
        .section_mut()
        .ensure_header()
        .add_paragraph("New middle paragraph");
    revised
        .section_mut()
        .ensure_header()
        .add_paragraph("Stable tail");
    revised.save(&revised_path).expect("save revised docx");

    let compared = Document::compare(&original_path, &revised_path, "Comparer")
        .expect("compare style-changed header paragraph before insertion");
    compared.save(&compared_path).expect("save compared docx");

    let header_xml = part_xml(&compared_path, "/word/header1.xml");
    assert!(header_xml.contains("<w:pStyle w:val=\"Quote\"/>"));
    assert_eq!(count_tag(&header_xml, "w:ins"), 1);
    assert!(!header_xml.contains("<w:del><w:r><w:delText>Styled anchor</w:delText></w:r></w:del>"));

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let header = reopened.section().header().expect("header");
    assert_eq!(header.paragraphs()[1].text(), "Styled anchor");
    assert_eq!(header.paragraphs()[3].text(), "Stable tail");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "header/default/paragraph:2"
            && revision.kind == RevisionKind::Insertion
            && revision.text == "New middle paragraph"
    }));
}

#[test]
fn compare_marks_simple_moved_body_paragraphs_as_moves() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp.path().join("original-move-compare.docx");
    let revised_path = temp.path().join("revised-move-compare.docx");
    let compared_path = temp.path().join("compared-move-compare.docx");

    let mut original = Document::new();
    original.add_paragraph("Intro");
    original.add_paragraph("Moved paragraph");
    original.add_paragraph("Stable tail");
    original.save(&original_path).expect("save original docx");

    let mut revised = Document::new();
    revised.add_paragraph("Intro");
    revised.add_paragraph("Stable tail");
    revised.add_paragraph("Moved paragraph");
    revised.save(&revised_path).expect("save revised docx");

    let compared = Document::compare(&original_path, &revised_path, "Comparer")
        .expect("compare moved body paragraphs");
    compared.save(&compared_path).expect("save compared docx");

    let compared_xml = document_xml(&compared_path);
    assert!(compared_xml.contains("w:moveFrom"));
    assert!(compared_xml.contains("w:moveTo"));
    assert!(compared_xml.contains("w:moveFromRangeStart"));
    assert!(compared_xml.contains("w:moveToRangeStart"));
    assert!(compared_xml.contains("w:moveFromRangeStart w:id=\""));
    assert!(compared_xml.contains("w:author=\"Comparer\" w:date=\"2000-01-01T00:00:00Z\""));
    assert!(compared_xml.contains("<w:rPr>\n          <w:moveFrom"));
    assert!(compared_xml.contains("<w:rPr>\n          <w:moveTo"));

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:1"
            && revision.kind == RevisionKind::MoveFrom
            && revision.text == "Moved paragraph"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:3"
            && revision.kind == RevisionKind::MoveTo
            && revision.text == "Moved paragraph"
    }));
    assert!(!revisions.iter().any(|revision| {
        revision.text == "Moved paragraph"
            && matches!(
                revision.kind,
                RevisionKind::Insertion | RevisionKind::Deletion
            )
    }));
}

#[test]
fn compare_uses_table_anchors_for_deleted_paragraphs() {
    let temp = tempdir().expect("create tempdir");
    let original_path = temp.path().join("original-table-anchor.docx");
    let revised_path = temp.path().join("revised-table-anchor.docx");
    let compared_path = temp.path().join("compared-table-anchor.docx");

    let mut original = Document::new();
    original.add_paragraph("Intro");
    original.add_paragraph("Removed before table");
    let original_table = original.add_table(1, 1);
    assert!(original_table.set_cell_text(0, 0, "Cell"));
    original.add_paragraph("After table");
    original.save(&original_path).expect("save original docx");

    let mut revised = Document::new();
    revised.add_paragraph("Intro");
    let revised_table = revised.add_table(1, 1);
    assert!(revised_table.set_cell_text(0, 0, "Cell"));
    revised.add_paragraph("After table");
    revised.save(&revised_path).expect("save revised docx");

    let compared = Document::compare(&original_path, &revised_path, "Comparer")
        .expect("compare documents into redline");
    compared.save(&compared_path).expect("save compared docx");

    let compared_xml = document_xml(&compared_path);
    let deletion_index = compared_xml
        .find("Removed before table")
        .expect("deleted paragraph text should exist");
    let table_index = compared_xml.find("<w:tbl>").expect("table should exist");
    assert!(
        deletion_index < table_index,
        "deletion should stay before table"
    );

    let reopened = Document::open(&compared_path).expect("reopen compared docx");
    let revisions = reopened.revisions();
    assert_eq!(revisions.len(), 1);
    assert_eq!(revisions[0].kind, RevisionKind::Deletion);
    assert_eq!(revisions[0].text, "Removed before table");
    assert_eq!(
        reopened.paragraphs().last().map(|p| p.text()),
        Some("After table".to_string())
    );
}

#[test]
fn paragraph_comments_roundtrip_with_word_visible_anchors() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("commented.docx");
    let dirty_path = temp.path().join("commented-dirty.docx");

    let mut document = Document::new();
    document.add_paragraph("Commented paragraph");
    let comment_id = document
        .add_comment_to_paragraph_with_date(
            0,
            "Reviewer",
            "Please tighten this language.",
            Some("2026-03-24T13:00:00Z"),
        )
        .expect("add paragraph comment");
    assert_eq!(comment_id, 0);
    document.save(&path).expect("save commented docx");

    let xml = document_xml(&path);
    assert_eq!(count_tag(&xml, "w:commentRangeStart"), 1);
    assert_eq!(count_tag(&xml, "w:commentRangeEnd"), 1);
    assert_eq!(count_tag(&xml, "w:commentReference"), 1);
    assert!(xml.contains("w:commentRangeStart w:id=\"0\""));
    assert!(xml.contains("w:commentReference w:id=\"0\""));

    let comments = comments_xml(&path);
    assert!(comments.contains("Please tighten this language."));
    assert!(comments.contains("w:author=\"Reviewer\""));
    assert!(comments.contains("w:date=\"2026-03-24T13:00:00Z\""));

    let package = Package::open(&path).expect("open commented package");
    let document_part = package
        .get_part("/word/document.xml")
        .expect("document.xml part should exist");
    assert!(document_part.relationships.iter().any(|rel| rel.rel_type
        == "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments"));

    let reopened = Document::open(&path).expect("reopen commented docx");
    assert_eq!(reopened.comments().len(), 1);
    assert_eq!(reopened.comments()[0].id(), 0);
    assert_eq!(
        reopened.comments()[0].text(),
        "Please tighten this language."
    );
    assert_eq!(reopened.paragraphs()[0].comment_range_start_ids(), &[0]);
    assert_eq!(reopened.paragraphs()[0].comment_range_end_ids(), &[0]);

    let mut dirty_reopened = reopened;
    dirty_reopened.add_paragraph("Tail");
    dirty_reopened
        .save(&dirty_path)
        .expect("save dirty commented docx");
    let dirty_xml = document_xml(&dirty_path);
    let dirty_comments = comments_xml(&dirty_path);
    assert_eq!(count_tag(&dirty_xml, "w:commentReference"), 1);
    assert!(dirty_comments.contains("Please tighten this language."));
}

#[test]
fn paragraph_comments_can_anchor_character_ranges() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("commented-range.docx");
    let dirty_path = temp.path().join("commented-range-dirty.docx");

    let mut document = Document::new();
    document.add_paragraph("Alpha Beta Gamma");
    let comment_id = document
        .add_comment_to_paragraph_range_with_date(
            0,
            6,
            10,
            "Reviewer",
            "Review just Beta.",
            Some("2026-03-24T14:00:00Z"),
        )
        .expect("add range comment");
    assert_eq!(comment_id, 0);
    document.save(&path).expect("save range-commented docx");

    let xml = document_xml(&path);
    let start_index = xml
        .find("<w:commentRangeStart w:id=\"0\"/>")
        .expect("comment range start should exist");
    let beta_index = xml.find("Beta").expect("selected text should exist");
    let end_index = xml
        .find("<w:commentRangeEnd w:id=\"0\"/>")
        .expect("comment range end should exist");
    let gamma_index = xml.find("Gamma").expect("suffix text should exist");
    assert!(start_index < beta_index);
    assert!(beta_index < end_index);
    assert!(end_index < gamma_index);
    assert_eq!(count_tag(&xml, "w:commentReference"), 1);

    let reopened = Document::open(&path).expect("reopen range-commented docx");
    assert_eq!(reopened.comments().len(), 1);
    assert_eq!(reopened.comments()[0].text(), "Review just Beta.");
    assert_eq!(reopened.paragraphs()[0].text(), "Alpha Beta Gamma");

    let mut dirty_reopened = reopened;
    dirty_reopened.add_paragraph("Tail");
    dirty_reopened
        .save(&dirty_path)
        .expect("save dirty range-commented docx");
    let dirty_xml = document_xml(&dirty_path);
    let dirty_start_index = dirty_xml
        .find("<w:commentRangeStart w:id=\"0\"/>")
        .expect("comment range start should survive dirty save");
    let dirty_beta_index = dirty_xml
        .find("Beta")
        .expect("beta should survive dirty save");
    let dirty_end_index = dirty_xml
        .find("<w:commentRangeEnd w:id=\"0\"/>")
        .expect("comment range end should survive dirty save");
    assert!(dirty_start_index < dirty_beta_index);
    assert!(dirty_beta_index < dirty_end_index);
}

#[test]
fn review_paragraph_text_adds_highlight_and_comment() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("reviewed-text.docx");

    let mut document = Document::new();
    document.add_paragraph("Alpha Beta Gamma");
    let comment_id = document
        .review_paragraph_text_with_date(
            0,
            "Beta",
            "Reviewer",
            "Check this word.",
            Some("yellow"),
            Some("2026-03-24T15:00:00Z"),
        )
        .expect("review paragraph text");
    assert_eq!(comment_id, 0);
    document.save(&path).expect("save reviewed text docx");

    let reopened = Document::open(&path).expect("reopen reviewed text docx");
    assert_eq!(reopened.comments().len(), 1);
    assert_eq!(reopened.comments()[0].text(), "Check this word.");
    let runs = reopened.paragraphs()[0].runs();
    assert!(runs
        .iter()
        .any(|run| run.text() == "Beta" && run.highlight_color() == Some("yellow")));
}

#[test]
fn review_paragraph_text_matches_across_styled_runs_and_hyperlinks() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("reviewed-hyperlink-runs.docx");

    let mut document = Document::new();
    let paragraph = document.add_paragraph("");
    paragraph.set_runs(Vec::new());
    paragraph.add_run("Alpha ");
    paragraph.add_run("Be").set_bold(true);
    paragraph.add_hyperlink("ta", "https://example.com");
    paragraph.add_run(" Gamma");

    let comment_id = document
        .review_paragraph_text_with_date(
            0,
            "Beta",
            "Reviewer",
            "Check mixed-format Beta.",
            Some("yellow"),
            Some("2026-03-24T16:00:00Z"),
        )
        .expect("review mixed-format paragraph text");
    assert_eq!(comment_id, 0);
    document
        .save(&path)
        .expect("save mixed-format reviewed docx");

    let reopened = Document::open(&path).expect("reopen mixed-format reviewed docx");
    assert_eq!(reopened.comments().len(), 1);
    let runs = reopened.paragraphs()[0].runs();
    assert!(runs
        .iter()
        .any(|run| run.text() == "Be" && run.highlight_color() == Some("yellow") && run.is_bold()));
    assert!(runs.iter().any(|run| {
        run.text() == "ta"
            && run.highlight_color() == Some("yellow")
            && run.hyperlink() == Some("https://example.com")
    }));
}

#[test]
fn review_text_matches_across_revision_boundaries() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("reviewed-revision-span.docx");

    let mut document = Document::new();
    let revision = document.new_revision_metadata_with_date("Editor", "2026-03-24T16:30:00Z");
    let paragraph = document.add_paragraph("");
    paragraph.set_runs(Vec::new());
    paragraph.add_run("Alpha ");
    paragraph.add_run("Be").set_bold(true);
    paragraph.add_inserted_text("ta", revision);
    paragraph.add_run(" Gamma");

    let comment_id = document
        .review_text_with_date(
            "Beta",
            "Reviewer",
            "Check revised Beta.",
            Some("yellow"),
            Some("2026-03-24T16:45:00Z"),
        )
        .expect("review text across revision boundary");
    assert_eq!(comment_id, 0);
    document
        .save(&path)
        .expect("save revision-span reviewed docx");

    let xml = document_xml(&path);
    assert!(xml.contains("<w:commentRangeStart w:id=\"0\"/>"));
    assert!(xml.contains("<w:commentRangeEnd w:id=\"0\"/>"));
    assert!(xml.contains("<w:ins"));
    assert!(
        xml.contains("Check revised Beta.") || comments_xml(&path).contains("Check revised Beta.")
    );
    assert!(xml.contains("w:highlight w:val=\"yellow\""));

    let reopened = Document::open(&path).expect("reopen revision-span reviewed docx");
    assert_eq!(reopened.comments().len(), 1);
    assert!(reopened
        .revisions()
        .iter()
        .any(|revision| revision.text.contains("ta")));
}

#[test]
fn review_paragraph_text_with_existing_comment_markers() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("reviewed-existing-comment.docx");

    let mut document = Document::new();
    document.add_paragraph("Alpha Beta Gamma");
    document
        .add_comment_to_paragraph_text_with_date(
            0,
            "Alpha",
            "Reviewer",
            "Existing note.",
            Some("2026-03-24T17:15:00Z"),
        )
        .expect("add existing comment");
    let second_comment_id = document
        .review_paragraph_text_with_date(
            0,
            "Beta",
            "Reviewer",
            "New Beta note.",
            Some("yellow"),
            Some("2026-03-24T17:20:00Z"),
        )
        .expect("add second review comment");
    assert_eq!(second_comment_id, 1);
    document
        .save(&path)
        .expect("save existing-comment review docx");

    let xml = document_xml(&path);
    assert!(xml.contains("<w:commentRangeStart w:id=\"0\"/>"));
    assert!(xml.contains("<w:commentRangeStart w:id=\"1\"/>"));
    assert!(xml.contains("w:highlight w:val=\"yellow\""));

    let reopened = Document::open(&path).expect("reopen existing-comment review docx");
    assert_eq!(reopened.comments().len(), 2);
    assert_eq!(reopened.comments()[0].text(), "Existing note.");
    assert_eq!(reopened.comments()[1].text(), "New Beta note.");
}

#[test]
fn review_paragraph_text_preserves_bookmark_markers() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("reviewed-bookmark.docx");

    let mut document = Document::new();
    document.add_paragraph("Alpha Beta Gamma");
    document.save(&path).expect("save bookmark base docx");

    rewrite_document_xml(&path, |xml| {
        xml.replacen(
            "Alpha Beta Gamma",
            "Alpha </w:t></w:r><w:bookmarkStart w:id=\"7\" w:name=\"beta_mark\"/><w:r><w:t>Beta</w:t></w:r><w:bookmarkEnd w:id=\"7\"/><w:r><w:t> Gamma",
            1,
        )
    });

    let mut reopened = Document::open(&path).expect("open bookmark docx");
    reopened
        .review_paragraph_text_with_date(
            0,
            "Beta",
            "Reviewer",
            "Bookmark-safe review.",
            Some("yellow"),
            Some("2026-03-24T17:30:00Z"),
        )
        .expect("review bookmark paragraph text");
    reopened.save(&path).expect("save bookmark review docx");

    let xml = document_xml(&path);
    assert!(xml.contains("w:bookmarkStart w:id=\"7\" w:name=\"beta_mark\""));
    assert!(xml.contains("w:bookmarkEnd w:id=\"7\""));
    assert!(xml.contains("w:commentRangeStart w:id=\"0\""));
}

#[test]
fn review_paragraph_text_keeps_comment_markers_inside_bookmark_boundaries() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("reviewed-bookmark-order.docx");

    let mut document = Document::new();
    document.add_paragraph("Alpha Beta Gamma");
    document.save(&path).expect("save bookmark base docx");

    rewrite_document_xml(&path, |xml| {
        xml.replacen(
            "Alpha Beta Gamma",
            "Alpha </w:t></w:r><w:bookmarkStart w:id=\"7\" w:name=\"beta_mark\"/><w:r><w:t>Beta</w:t></w:r><w:bookmarkEnd w:id=\"7\"/><w:r><w:t> Gamma",
            1,
        )
    });

    let mut reopened = Document::open(&path).expect("open bookmark docx");
    reopened
        .add_comment_to_paragraph_range_with_date(
            0,
            6,
            10,
            "Reviewer",
            "Bookmark bounded comment.",
            Some("2026-03-24T17:31:00Z"),
        )
        .expect("comment bookmark paragraph range");
    reopened.save(&path).expect("save bookmark comment docx");

    let xml = document_xml(&path);
    let bookmark_start = xml
        .find("<w:bookmarkStart w:id=\"7\" w:name=\"beta_mark\"/>")
        .expect("bookmark start");
    let comment_start = xml
        .find("<w:commentRangeStart w:id=\"0\"/>")
        .expect("comment start");
    let beta = xml.find("Beta").expect("beta text");
    let comment_end = xml
        .find("<w:commentRangeEnd w:id=\"0\"/>")
        .expect("comment end");
    let bookmark_end = xml
        .find("<w:bookmarkEnd w:id=\"7\"/>")
        .expect("bookmark end");
    assert!(bookmark_start < comment_start);
    assert!(comment_start < beta);
    assert!(beta < comment_end);
    assert!(comment_end < bookmark_end);
}

#[test]
fn review_paragraph_text_preserves_existing_comment_marker_boundary_order() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("reviewed-existing-comment-order.docx");

    let mut document = Document::new();
    document.add_paragraph("Alpha Beta Gamma");
    document
        .add_comment_to_paragraph_text_with_date(
            0,
            "Alpha",
            "Reviewer",
            "Existing note.",
            Some("2026-03-24T17:15:00Z"),
        )
        .expect("add existing comment");
    document.save(&path).expect("save existing comment docx");

    let mut reopened = Document::open(&path).expect("reopen existing comment docx");
    reopened
        .add_comment_to_paragraph_range_with_date(
            0,
            6,
            10,
            "Reviewer",
            "Second Beta note.",
            Some("2026-03-24T17:32:00Z"),
        )
        .expect("add second comment");
    reopened
        .save(&path)
        .expect("save updated existing comment docx");

    let xml = document_xml(&path);
    let existing_reference = xml
        .find("<w:commentReference w:id=\"0\"/>")
        .expect("existing comment reference");
    let new_comment_start = xml
        .find("<w:commentRangeStart w:id=\"1\"/>")
        .expect("new comment start");
    let beta = xml.find("Beta").expect("beta text");
    assert!(existing_reference < new_comment_start);
    assert!(new_comment_start < beta);
}

#[test]
fn review_text_matches_simple_vml_text_box_content() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("review-textbox.docx");

    let mut document = Document::new();
    document.add_paragraph("placeholder");
    document.save(&path).expect("save textbox docx");

    rewrite_document_xml(&path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:pict xmlns:v=\"urn:schemas-microsoft-com:vml\"><v:shape id=\"TextBox1\"><v:textbox><w:txbxContent><w:p><w:r><w:t>Textbox Beta</w:t></w:r></w:p></w:txbxContent></v:textbox></v:shape></w:pict></w:r>",
        )
    });

    let mut reopened = Document::open(&path).expect("open textbox docx");
    let comment_id = reopened
        .review_text_with_date(
            "Beta",
            "Reviewer",
            "Review textbox content.",
            Some("yellow"),
            Some("2026-03-24T20:20:00Z"),
        )
        .expect("review textbox text");
    assert_eq!(comment_id, 0);
    reopened.save(&path).expect("save reviewed textbox docx");

    let document_xml = part_xml(&path, "/word/document.xml");
    assert!(document_xml.contains("w:txbxContent"));
    assert!(document_xml.contains("w:commentRangeStart w:id=\"0\""));
    assert!(document_xml.contains("w:commentRangeEnd w:id=\"0\""));
    assert!(document_xml.contains("w:commentReference w:id=\"0\""));
    assert!(document_xml.contains("w:highlight w:val=\"yellow\""));

    let reopened = Document::open(&path).expect("reopen reviewed textbox docx");
    assert_eq!(reopened.comments().len(), 1);
}

#[test]
fn review_text_matches_simple_drawingml_text_box_content() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("review-drawing-textbox.docx");

    let mut document = Document::new();
    document.add_paragraph("placeholder");
    document.save(&path).expect("save drawing textbox docx");

    rewrite_document_xml(&path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Drawing Beta</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });

    let mut reopened = Document::open(&path).expect("open drawing textbox docx");
    let comment_id = reopened
        .review_text_with_date(
            "Beta",
            "Reviewer",
            "Review drawing textbox content.",
            Some("yellow"),
            Some("2026-03-24T20:25:00Z"),
        )
        .expect("review drawing textbox text");
    assert_eq!(comment_id, 0);
    reopened
        .save(&path)
        .expect("save reviewed drawing textbox docx");

    let document_xml = part_xml(&path, "/word/document.xml");
    assert!(document_xml.contains("<w:drawing>"));
    assert!(document_xml.contains("w:txbxContent"));
    assert!(document_xml.contains("w:commentRangeStart w:id=\"0\""));
    assert!(document_xml.contains("w:commentRangeEnd w:id=\"0\""));
    assert!(document_xml.contains("w:commentReference w:id=\"0\""));
    assert!(document_xml.contains("w:highlight w:val=\"yellow\""));

    let reopened = Document::open(&path).expect("reopen reviewed drawing textbox docx");
    assert_eq!(reopened.comments().len(), 1);
}

#[test]
fn review_text_matches_multi_paragraph_vml_text_box_content() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("review-multi-vml-textbox.docx");

    let mut document = Document::new();
    document.add_paragraph("placeholder");
    document.save(&path).expect("save textbox docx");

    let first_paragraph = "<w:p w:rsidR=\"00111111\"><w:r><w:t>Lead</w:t></w:r></w:p>";
    let middle_paragraph = "<w:p w:rsidR=\"00222222\"><w:r><w:t>Textbox Beta</w:t></w:r></w:p>";
    let last_paragraph = "<w:p w:rsidR=\"00333333\"><w:r><w:t>Tail</w:t></w:r></w:p>";
    rewrite_document_xml(&path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            format!(
                "<w:r><w:pict xmlns:v=\"urn:schemas-microsoft-com:vml\"><v:shape id=\"TextBox1\"><v:textbox><w:txbxContent>{first_paragraph}{middle_paragraph}{last_paragraph}</w:txbxContent></v:textbox></v:shape></w:pict></w:r>"
            )
            .as_str(),
        )
    });

    let mut reopened = Document::open(&path).expect("open multi-paragraph VML textbox docx");
    let comment_id = reopened
        .review_text_with_date(
            "Beta",
            "Reviewer",
            "Review multi-paragraph textbox content.",
            Some("yellow"),
            Some("2026-03-26T12:00:00Z"),
        )
        .expect("review multi-paragraph VML textbox text");
    assert_eq!(comment_id, 0);
    reopened
        .save(&path)
        .expect("save reviewed VML textbox docx");

    let document_xml = part_xml(&path, "/word/document.xml");
    assert!(document_xml.contains(first_paragraph));
    assert!(document_xml.contains(last_paragraph));
    assert!(document_xml.contains("w:commentRangeStart w:id=\"0\""));
    assert!(document_xml.contains("w:highlight w:val=\"yellow\""));

    let reopened = Document::open(&path).expect("reopen reviewed VML textbox docx");
    assert_eq!(reopened.comments().len(), 1);
}

#[test]
fn review_text_matches_multi_paragraph_drawingml_text_box_content() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("review-multi-drawing-textbox.docx");

    let mut document = Document::new();
    document.add_paragraph("placeholder");
    document.save(&path).expect("save drawing textbox docx");

    let first_paragraph = "<w:p w:rsidR=\"00111111\"><w:r><w:t>Lead</w:t></w:r></w:p>";
    let middle_paragraph = "<w:p w:rsidR=\"00222222\"><w:r><w:t>Drawing Beta</w:t></w:r></w:p>";
    let last_paragraph = "<w:p w:rsidR=\"00333333\"><w:r><w:t>Tail</w:t></w:r></w:p>";
    rewrite_document_xml(&path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            format!(
                "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent>{first_paragraph}{middle_paragraph}{last_paragraph}</w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>"
            )
            .as_str(),
        )
    });

    let mut reopened = Document::open(&path).expect("open multi-paragraph drawing textbox docx");
    let comment_id = reopened
        .review_text_with_date(
            "Beta",
            "Reviewer",
            "Review multi-paragraph drawing textbox content.",
            Some("yellow"),
            Some("2026-03-26T12:05:00Z"),
        )
        .expect("review multi-paragraph drawing textbox text");
    assert_eq!(comment_id, 0);
    reopened
        .save(&path)
        .expect("save reviewed drawing textbox docx");

    let document_xml = part_xml(&path, "/word/document.xml");
    assert!(document_xml.contains(first_paragraph));
    assert!(document_xml.contains(last_paragraph));
    assert!(document_xml.contains("w:commentRangeStart w:id=\"0\""));
    assert!(document_xml.contains("w:highlight w:val=\"yellow\""));

    let reopened = Document::open(&path).expect("reopen reviewed drawing textbox docx");
    assert_eq!(reopened.comments().len(), 1);
}

#[test]
fn review_text_matches_vml_text_box_content_with_tab_run() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("review-textbox-tab.docx");

    let mut document = Document::new();
    document.add_paragraph("placeholder");
    document.save(&path).expect("save textbox docx");

    rewrite_document_xml(&path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:pict xmlns:v=\"urn:schemas-microsoft-com:vml\"><v:shape id=\"TextBox1\"><v:textbox><w:txbxContent><w:p><w:r><w:t>Label</w:t><w:tab/><w:t>Textbox Beta</w:t></w:r></w:p></w:txbxContent></v:textbox></v:shape></w:pict></w:r>",
        )
    });

    let mut reopened = Document::open(&path).expect("open textbox docx");
    let comment_id = reopened
        .review_text_with_date(
            "Beta",
            "Reviewer",
            "Review textbox tab content.",
            Some("yellow"),
            Some("2026-03-26T12:30:00Z"),
        )
        .expect("review textbox tab text");
    assert_eq!(comment_id, 0);
    reopened.save(&path).expect("save reviewed textbox docx");

    let document_xml = part_xml(&path, "/word/document.xml");
    assert!(document_xml.contains("<w:tab/>"));
    assert!(document_xml.contains("w:commentRangeStart w:id=\"0\""));
    assert!(document_xml.contains("w:highlight w:val=\"yellow\""));
}

#[test]
fn review_text_matches_drawingml_text_box_content_with_break_run() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("review-drawing-textbox-break.docx");

    let mut document = Document::new();
    document.add_paragraph("placeholder");
    document.save(&path).expect("save drawing textbox docx");

    rewrite_document_xml(&path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Alpha</w:t><w:br/><w:t>Drawing Beta</w:t></w:r></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });

    let mut reopened = Document::open(&path).expect("open drawing textbox docx");
    let comment_id = reopened
        .review_text_with_date(
            "Beta",
            "Reviewer",
            "Review drawing textbox break content.",
            Some("yellow"),
            Some("2026-03-26T12:35:00Z"),
        )
        .expect("review drawing textbox break text");
    assert_eq!(comment_id, 0);
    reopened
        .save(&path)
        .expect("save reviewed drawing textbox docx");

    let document_xml = part_xml(&path, "/word/document.xml");
    assert!(document_xml.contains("<w:br/>"));
    assert!(document_xml.contains("w:commentRangeStart w:id=\"0\""));
    assert!(document_xml.contains("w:highlight w:val=\"yellow\""));
}

#[test]
fn review_text_matches_vml_text_box_hyperlink_content() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("review-textbox-hyperlink.docx");

    let mut document = Document::new();
    document.add_paragraph("placeholder");
    document.save(&path).expect("save textbox docx");

    rewrite_document_xml(&path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:pict xmlns:v=\"urn:schemas-microsoft-com:vml\"><v:shape id=\"TextBox1\"><v:textbox><w:txbxContent><w:p><w:r><w:t>Lead </w:t></w:r><w:hyperlink r:id=\"rIdHyper1\"><w:r><w:t>Go Beta</w:t></w:r></w:hyperlink><w:r><w:t> Tail</w:t></w:r></w:p></w:txbxContent></v:textbox></v:shape></w:pict></w:r>",
        )
    });

    let mut reopened = Document::open(&path).expect("open textbox docx");
    let comment_id = reopened
        .review_text_with_date(
            "Beta",
            "Reviewer",
            "Review textbox hyperlink content.",
            Some("yellow"),
            Some("2026-03-26T13:00:00Z"),
        )
        .expect("review textbox hyperlink text");
    assert_eq!(comment_id, 0);
    reopened.save(&path).expect("save reviewed textbox docx");

    let document_xml = part_xml(&path, "/word/document.xml");
    assert!(document_xml.contains("<w:hyperlink r:id=\"rIdHyper1\">"));
    assert!(document_xml.contains("w:commentRangeStart w:id=\"0\""));
    assert!(document_xml.contains("w:highlight w:val=\"yellow\""));
}

#[test]
fn review_text_matches_vml_text_box_with_prooferr_markers() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("review-textbox-prooferr.docx");

    let mut document = Document::new();
    document.add_paragraph("placeholder");
    document.save(&path).expect("save textbox docx");

    rewrite_document_xml(&path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:pict xmlns:v=\"urn:schemas-microsoft-com:vml\"><v:shape id=\"TextBox1\"><v:textbox><w:txbxContent><w:p><w:proofErr w:type=\"spellStart\"/><w:r><w:t>Textbox Beta</w:t></w:r><w:proofErr w:type=\"spellEnd\"/></w:p></w:txbxContent></v:textbox></v:shape></w:pict></w:r>",
        )
    });

    let mut reopened = Document::open(&path).expect("open textbox docx");
    let comment_id = reopened
        .review_text_with_date(
            "Beta",
            "Reviewer",
            "Review textbox proofing content.",
            Some("yellow"),
            Some("2026-03-26T12:50:00Z"),
        )
        .expect("review textbox proofing text");
    assert_eq!(comment_id, 0);
    reopened.save(&path).expect("save reviewed textbox docx");

    let document_xml = part_xml(&path, "/word/document.xml");
    assert!(document_xml.contains("w:proofErr w:type=\"spellStart\""));
    assert!(document_xml.contains("w:proofErr w:type=\"spellEnd\""));
    assert!(document_xml.contains("w:commentRangeStart w:id=\"0\""));
    assert!(document_xml.contains("w:highlight w:val=\"yellow\""));
}

#[test]
fn review_text_matches_vml_text_box_with_no_break_hyphen() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("review-textbox-no-break-hyphen.docx");

    let mut document = Document::new();
    document.add_paragraph("placeholder");
    document.save(&path).expect("save textbox docx");

    rewrite_document_xml(&path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:pict xmlns:v=\"urn:schemas-microsoft-com:vml\"><v:shape id=\"TextBox1\"><v:textbox><w:txbxContent><w:p><w:r><w:t>co</w:t><w:noBreakHyphen/><w:t>operate Beta</w:t></w:r></w:p></w:txbxContent></v:textbox></v:shape></w:pict></w:r>",
        )
    });

    let mut reopened = Document::open(&path).expect("open textbox docx");
    let comment_id = reopened
        .review_text_with_date(
            "Beta",
            "Reviewer",
            "Review textbox no-break-hyphen content.",
            Some("yellow"),
            Some("2026-03-26T12:52:00Z"),
        )
        .expect("review textbox no-break-hyphen text");
    assert_eq!(comment_id, 0);
    reopened.save(&path).expect("save reviewed textbox docx");

    let document_xml = part_xml(&path, "/word/document.xml");
    assert!(document_xml.contains("<w:noBreakHyphen/>"));
    assert!(document_xml.contains("w:commentRangeStart w:id=\"0\""));
    assert!(document_xml.contains("w:highlight w:val=\"yellow\""));
}

#[test]
fn review_text_matches_simple_vml_text_box_content_with_move_markers() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("review-textbox-moves.docx");

    let mut document = Document::new();
    document.add_paragraph("placeholder");
    document.save(&path).expect("save textbox docx");

    rewrite_document_xml(&path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:pict xmlns:v=\"urn:schemas-microsoft-com:vml\"><v:shape id=\"TextBox1\"><v:textbox><w:txbxContent><w:p><w:moveFromRangeStart w:id=\"7\"/><w:r><w:t>Textbox Beta</w:t></w:r><w:moveFromRangeEnd w:id=\"7\"/></w:p></w:txbxContent></v:textbox></v:shape></w:pict></w:r>",
        )
    });

    let mut reopened = Document::open(&path).expect("open textbox docx");
    let comment_id = reopened
        .review_text_with_date(
            "Beta",
            "Reviewer",
            "Review textbox move content.",
            Some("yellow"),
            Some("2026-03-24T20:26:00Z"),
        )
        .expect("review textbox move text");
    assert_eq!(comment_id, 0);
    reopened.save(&path).expect("save reviewed textbox docx");

    let document_xml = part_xml(&path, "/word/document.xml");
    assert!(document_xml.contains("w:moveFromRangeStart w:id=\"7\""));
    assert!(document_xml.contains("w:moveFromRangeEnd w:id=\"7\""));
    assert!(document_xml.contains("w:commentRangeStart w:id=\"0\""));
    assert!(document_xml.contains("w:commentReference w:id=\"0\""));
    assert!(document_xml.contains("w:highlight w:val=\"yellow\""));
}

#[test]
fn review_text_matches_simple_drawingml_text_box_content_with_move_markers() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("review-drawing-textbox-moves.docx");

    let mut document = Document::new();
    document.add_paragraph("placeholder");
    document.save(&path).expect("save drawing textbox docx");

    rewrite_document_xml(&path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:moveToRangeStart w:id=\"8\"/><w:r><w:t>Drawing Beta</w:t></w:r><w:moveToRangeEnd w:id=\"8\"/></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });

    let mut reopened = Document::open(&path).expect("open drawing textbox docx");
    let comment_id = reopened
        .review_text_with_date(
            "Beta",
            "Reviewer",
            "Review drawing textbox move content.",
            Some("yellow"),
            Some("2026-03-24T20:27:00Z"),
        )
        .expect("review drawing textbox move text");
    assert_eq!(comment_id, 0);
    reopened
        .save(&path)
        .expect("save reviewed drawing textbox docx");

    let document_xml = part_xml(&path, "/word/document.xml");
    assert!(document_xml.contains("w:moveToRangeStart w:id=\"8\""));
    assert!(document_xml.contains("w:moveToRangeEnd w:id=\"8\""));
    assert!(document_xml.contains("w:commentRangeStart w:id=\"0\""));
    assert!(document_xml.contains("w:commentReference w:id=\"0\""));
    assert!(document_xml.contains("w:highlight w:val=\"yellow\""));
}

#[test]
fn revisions_include_and_transform_drawing_text_box_content() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("drawing-textbox-revisions.docx");
    let accept_path = temp.path().join("drawing-textbox-revisions-accepted.docx");
    let reject_path = temp.path().join("drawing-textbox-revisions-rejected.docx");

    let mut document = Document::new();
    document.add_paragraph("placeholder");
    document
        .save(&path)
        .expect("save drawing textbox revisions docx");

    rewrite_document_xml(&path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>placeholder</w:t>\n      </w:r>",
            "<w:r><w:drawing><wp:inline xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:txbx><w:txbxContent><w:p><w:r><w:t>Base</w:t></w:r><w:ins w:id=\"41\" w:author=\"Reviewer\"><w:r><w:t xml:space=\"preserve\"> Added</w:t></w:r></w:ins><w:del w:id=\"42\" w:author=\"Reviewer\"><w:r><w:delText xml:space=\"preserve\"> Drop</w:delText></w:r></w:del></w:p></w:txbxContent></wps:txbx></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>",
        )
    });

    let reopened = Document::open(&path).expect("open drawing textbox revisions docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:0"
            && revision.kind == RevisionKind::Insertion
            && revision.text == " Added"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:0"
            && revision.kind == RevisionKind::Deletion
            && revision.text == " Drop"
    }));

    let mut accepted = Document::open(&path).expect("reopen drawing textbox revisions docx");
    let report = accepted.accept_revisions();
    assert_eq!(report.insertions, 1);
    assert_eq!(report.deletions, 1);
    accepted
        .save(&accept_path)
        .expect("save accepted drawing textbox revisions docx");
    let accepted_xml = part_xml(&accept_path, "/word/document.xml");
    assert!(accepted_xml.contains("Base"));
    assert!(accepted_xml.contains(" Added"));
    assert!(!accepted_xml.contains("w:ins"));
    assert!(!accepted_xml.contains("w:del"));
    assert!(!accepted_xml.contains(" Drop"));

    let mut rejected = Document::open(&path).expect("reopen drawing textbox revisions docx");
    let report = rejected.reject_revisions();
    assert_eq!(report.insertions, 1);
    assert_eq!(report.deletions, 1);
    rejected
        .save(&reject_path)
        .expect("save rejected drawing textbox revisions docx");
    let rejected_xml = part_xml(&reject_path, "/word/document.xml");
    assert!(rejected_xml.contains("Base"));
    assert!(rejected_xml.contains(" Drop"));
    assert!(!rejected_xml.contains("w:ins"));
    assert!(!rejected_xml.contains("w:del"));
    assert!(!rejected_xml.contains(" Added"));
}

#[test]
fn review_paragraph_text_matches_field_result() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("reviewed-field.docx");

    let mut document = Document::new();
    let paragraph = document.add_paragraph("");
    paragraph.add_run("Alpha ");
    let field_run = paragraph.add_run("");
    field_run.set_field_code(FieldCode::new("PAGE", "Beta"));
    paragraph.add_run(" Gamma");

    let comment_id = document
        .review_paragraph_text_with_date(
            0,
            "Beta",
            "Reviewer",
            "Field result review.",
            Some("yellow"),
            Some("2026-03-24T17:40:00Z"),
        )
        .expect("review paragraph field result");
    assert_eq!(comment_id, 0);
    document.save(&path).expect("save reviewed field docx");

    let reopened = Document::open(&path).expect("reopen reviewed field docx");
    assert_eq!(reopened.comments().len(), 1);
    assert!(reopened.paragraphs()[0]
        .runs()
        .iter()
        .any(|run| run.field_code().is_some() && run.highlight_color() == Some("yellow")));
}

#[test]
fn review_table_cell_text_matches_across_mixed_runs_and_revisions() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("reviewed-table-cell-rich.docx");

    let mut document = Document::new();
    let table = document.add_table(1, 1);
    assert!(table.set_cell_text(0, 0, "Alpha Beta Gamma"));
    document.save(&path).expect("save rich-table base docx");

    rewrite_document_xml(&path, |xml| {
        xml.replacen(
            "Alpha Beta Gamma",
            "Alpha </w:t></w:r><w:r><w:rPr><w:b/></w:rPr><w:t>Be</w:t></w:r><w:ins w:id=\"9\" w:author=\"Editor\" w:date=\"2026-03-24T17:45:00Z\"><w:r><w:t>ta</w:t></w:r></w:ins><w:r><w:t xml:space=\"preserve\"> Gamma",
            1,
        )
    });

    let mut reopened = Document::open(&path).expect("open rich-table docx");
    let comment_id = reopened
        .review_table_cell_text_with_date(
            0,
            0,
            0,
            "Beta",
            "Reviewer",
            "Review mixed cell text.",
            Some("yellow"),
            Some("2026-03-24T17:50:00Z"),
        )
        .expect("review mixed table cell text");
    assert_eq!(comment_id, 0);
    reopened.save(&path).expect("save rich-table review docx");

    let xml = document_xml(&path);
    assert!(xml.contains("<w:ins"));
    assert!(xml.contains("w:commentRangeStart w:id=\"0\""));
    assert!(xml.contains("w:highlight w:val=\"yellow\""));

    let reopened_again = Document::open(&path).expect("reopen rich-table review docx");
    assert_eq!(reopened_again.comments().len(), 1);
    assert_eq!(
        reopened_again.tables()[0].cell(0, 0).expect("cell").text(),
        "Alpha Beta Gamma"
    );
}

#[test]
fn document_review_text_finds_first_matching_paragraph() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("reviewed-document-text.docx");

    let mut document = Document::new();
    document.add_paragraph("Intro");
    document.add_paragraph("Please review Beta here.");
    document.add_paragraph("Beta appears later too.");
    let comment_id = document
        .review_text_with_date(
            "Beta",
            "Reviewer",
            "Check the first Beta.",
            Some("yellow"),
            Some("2026-03-24T16:00:00Z"),
        )
        .expect("review first match in document");
    assert_eq!(comment_id, 0);
    document
        .save(&path)
        .expect("save reviewed document text docx");

    let reopened = Document::open(&path).expect("reopen reviewed document text docx");
    assert_eq!(reopened.comments().len(), 1);
    assert_eq!(reopened.comments()[0].text(), "Check the first Beta.");
    let second_para_runs = reopened.paragraphs()[1].runs();
    assert!(second_para_runs
        .iter()
        .any(|run| run.text() == "Beta" && run.highlight_color() == Some("yellow")));
    let third_para_runs = reopened.paragraphs()[2].runs();
    assert!(!third_para_runs
        .iter()
        .any(|run| run.text() == "Beta" && run.highlight_color() == Some("yellow")));
}

#[test]
fn review_all_text_marks_all_matching_paragraphs() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("review-all-text.docx");

    let mut document = Document::new();
    document.add_paragraph("Alpha Beta Gamma");
    document.add_paragraph("No target here");
    document.add_paragraph("Beta appears again");
    let comment_ids = document
        .review_all_text_with_date(
            "Beta",
            "Reviewer",
            "Review all Beta occurrences.",
            Some("yellow"),
            Some("2026-03-24T17:00:00Z"),
        )
        .expect("review all text");
    assert_eq!(comment_ids, vec![0, 1]);
    document.save(&path).expect("save review-all-text docx");

    let reopened = Document::open(&path).expect("reopen review-all-text docx");
    assert_eq!(reopened.comments().len(), 2);
    assert_eq!(
        reopened.comments()[0].text(),
        "Review all Beta occurrences."
    );
    assert_eq!(
        reopened.comments()[1].text(),
        "Review all Beta occurrences."
    );
    assert!(reopened.paragraphs()[0]
        .runs()
        .iter()
        .any(|run| run.text() == "Beta" && run.highlight_color() == Some("yellow")));
    assert!(reopened.paragraphs()[2]
        .runs()
        .iter()
        .any(|run| run.text() == "Beta" && run.highlight_color() == Some("yellow")));
    assert!(!reopened.paragraphs()[1]
        .runs()
        .iter()
        .any(|run| run.highlight_color() == Some("yellow")));
}

#[test]
fn review_text_falls_back_to_headers_footers_footnotes_and_endnotes() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("review-supported-parts.docx");

    let mut document = Document::new();
    document.add_paragraph("Body intro");
    document
        .section_mut()
        .ensure_header()
        .add_paragraph("Header Beta");
    document
        .section_mut()
        .ensure_footer()
        .add_paragraph("Footer Beta");
    document.add_footnote(offidized_docx::Footnote::from_text(1, "Footnote Beta"));
    document.add_endnote(offidized_docx::Endnote::from_text(1, "Endnote Beta"));

    let comment_id = document
        .review_text_with_date(
            "Beta",
            "Reviewer",
            "Review supported parts.",
            Some("yellow"),
            Some("2026-03-24T18:30:00Z"),
        )
        .expect("review first supported-part match");
    assert_eq!(comment_id, 0);
    document
        .save(&path)
        .expect("save supported-parts review docx");

    let reopened = Document::open(&path).expect("reopen supported-parts review docx");
    assert_eq!(reopened.comments().len(), 1);
    let header_runs = reopened.section().header().expect("header").paragraphs()[0].runs();
    assert!(header_runs
        .iter()
        .any(|run| run.text() == "Beta" && run.highlight_color() == Some("yellow")));
}

#[test]
fn review_all_text_reaches_supported_non_body_parts() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("review-all-supported-parts.docx");

    let mut document = Document::new();
    document.add_paragraph("Body Beta");
    document
        .section_mut()
        .ensure_header()
        .add_paragraph("Header Beta");
    document
        .section_mut()
        .ensure_footer()
        .add_paragraph("Footer Beta");
    document.add_footnote(offidized_docx::Footnote::from_text(1, "Footnote Beta"));
    document.add_endnote(offidized_docx::Endnote::from_text(1, "Endnote Beta"));

    let comment_ids = document
        .review_all_text_with_date(
            "Beta",
            "Reviewer",
            "Review every supported-part Beta.",
            Some("yellow"),
            Some("2026-03-24T18:35:00Z"),
        )
        .expect("review all supported-part matches");
    assert_eq!(comment_ids.len(), 5);
    document
        .save(&path)
        .expect("save all supported-parts review docx");

    let reopened = Document::open(&path).expect("reopen all supported-parts review docx");
    assert_eq!(reopened.comments().len(), 5);
    assert!(reopened.footnotes()[0].paragraphs()[0]
        .runs()
        .iter()
        .any(|run| run.text() == "Beta" && run.highlight_color() == Some("yellow")));
    assert!(reopened.endnotes()[0].paragraphs()[0]
        .runs()
        .iter()
        .any(|run| run.text() == "Beta" && run.highlight_color() == Some("yellow")));
}

#[test]
fn review_text_reaches_supported_table_parts() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("review-supported-table-parts.docx");

    let mut document = Document::new();
    document
        .add_table(1, 1)
        .set_cell_text(0, 0, "BodyTable Beta");
    document
        .section_mut()
        .ensure_header()
        .add_table(1, 1)
        .set_cell_text(0, 0, "HeaderTable Beta");
    let mut footnote = offidized_docx::Footnote::new(1);
    footnote
        .add_table(1, 1)
        .set_cell_text(0, 0, "FootTable Beta");
    document.add_footnote(footnote);
    let mut endnote = offidized_docx::Endnote::new(1);
    endnote.add_table(1, 1).set_cell_text(0, 0, "EndTable Beta");
    document.add_endnote(endnote);

    let comment_id = document
        .review_text_with_date(
            "Beta",
            "Reviewer",
            "Review supported table parts.",
            Some("yellow"),
            Some("2026-03-24T19:10:00Z"),
        )
        .expect("review first supported table-part match");
    assert_eq!(comment_id, 0);
    document
        .save(&path)
        .expect("save supported table-part review docx");

    let reopened = Document::open(&path).expect("reopen supported table-part review docx");
    assert_eq!(reopened.comments().len(), 1);
    let body_cell = reopened.tables()[0].cell(0, 0).expect("body cell");
    assert_eq!(body_cell.highlight_ranges().len(), 1);
}

#[test]
fn review_all_text_reaches_supported_table_parts() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("review-all-supported-table-parts.docx");

    let mut document = Document::new();
    document
        .add_table(1, 1)
        .set_cell_text(0, 0, "BodyTable Beta");
    document
        .section_mut()
        .ensure_header()
        .add_table(1, 1)
        .set_cell_text(0, 0, "HeaderTable Beta");
    let mut footnote = offidized_docx::Footnote::new(1);
    footnote
        .add_table(1, 1)
        .set_cell_text(0, 0, "FootTable Beta");
    document.add_footnote(footnote);
    let mut endnote = offidized_docx::Endnote::new(1);
    endnote.add_table(1, 1).set_cell_text(0, 0, "EndTable Beta");
    document.add_endnote(endnote);

    let comment_ids = document
        .review_all_text_with_date(
            "Beta",
            "Reviewer",
            "Review every supported table-part Beta.",
            Some("yellow"),
            Some("2026-03-24T19:15:00Z"),
        )
        .expect("review all supported table-part matches");
    assert_eq!(comment_ids.len(), 4);
    document
        .save(&path)
        .expect("save all supported table-part review docx");

    let reopened = Document::open(&path).expect("reopen all supported table-part review docx");
    assert_eq!(reopened.comments().len(), 4);
    assert_eq!(
        reopened.tables()[0]
            .cell(0, 0)
            .expect("body cell")
            .highlight_ranges()
            .len(),
        1
    );
    assert_eq!(
        reopened.section().header().expect("header").tables()[0]
            .cell(0, 0)
            .expect("header cell")
            .highlight_ranges()
            .len(),
        1
    );
    let footnote_xml = part_xml(&path, "/word/footnotes.xml");
    let endnote_xml = part_xml(&path, "/word/endnotes.xml");
    assert!(footnote_xml.contains("w:highlight w:val=\"yellow\""));
    assert!(endnote_xml.contains("w:highlight w:val=\"yellow\""));
}

#[test]
fn review_table_cell_text_adds_comment_and_highlight() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("review-table-cell.docx");

    let mut document = Document::new();
    let table = document.add_table(1, 2);
    assert!(table.set_cell_text(0, 0, "Alpha Beta Gamma"));
    assert!(table.set_cell_text(0, 1, "Other"));
    let comment_id = document
        .review_table_cell_text_with_date(
            0,
            0,
            0,
            "Beta",
            "Reviewer",
            "Review this cell text.",
            Some("yellow"),
            Some("2026-03-24T18:00:00Z"),
        )
        .expect("review table cell text");
    assert_eq!(comment_id, 0);
    document.save(&path).expect("save reviewed table cell docx");

    let xml = document_xml(&path);
    assert!(
        xml.contains("Review this cell text.")
            || comments_xml(&path).contains("Review this cell text.")
    );
    assert!(xml.contains("<w:commentRangeStart w:id=\"0\"/>"));
    assert!(xml.contains("<w:commentRangeEnd w:id=\"0\"/>"));
    assert!(xml.contains("w:highlight w:val=\"yellow\""));

    let reopened = Document::open(&path).expect("reopen reviewed table cell docx");
    assert_eq!(reopened.comments().len(), 1);
    assert_eq!(reopened.comments()[0].text(), "Review this cell text.");
    let reopened_cell = reopened.tables()[0].cell(0, 0).expect("cell");
    assert_eq!(reopened_cell.text(), "Alpha Beta Gamma");
    assert_eq!(reopened_cell.comment_anchors().len(), 1);
    assert!(reopened_cell
        .highlight_ranges()
        .iter()
        .any(|range| range.color() == "yellow"));
}

#[test]
fn review_table_cell_text_matches_across_multiple_paragraphs() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("reviewed-table-cell-multi-paragraph.docx");

    let mut document = Document::new();
    let table = document.add_table(1, 1);
    assert!(table.set_cell_text(0, 0, "Alpha Beta Gamma"));
    document
        .save(&path)
        .expect("save multi-paragraph table base docx");

    rewrite_document_xml(&path, |xml| {
        xml.replacen(
            "Alpha Beta Gamma",
            "Alpha</w:t></w:r></w:p><w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Be</w:t></w:r><w:ins w:id=\"11\" w:author=\"Editor\" w:date=\"2026-03-24T18:10:00Z\"><w:r><w:t>ta</w:t></w:r></w:ins><w:r><w:t xml:space=\"preserve\"> Gamma",
            1,
        )
    });

    let mut reopened = Document::open(&path).expect("open multi-paragraph rich table docx");
    let comment_id = reopened
        .review_table_cell_text_with_date(
            0,
            0,
            0,
            "Beta",
            "Reviewer",
            "Review second paragraph Beta.",
            Some("yellow"),
            Some("2026-03-24T18:15:00Z"),
        )
        .expect("review multi-paragraph table cell text");
    assert_eq!(comment_id, 0);
    reopened
        .save(&path)
        .expect("save multi-paragraph rich table review docx");

    let xml = document_xml(&path);
    assert!(xml.contains("<w:p>"));
    assert!(xml.contains("<w:ins"));
    assert!(xml.contains("w:commentRangeStart w:id=\"0\""));
    assert!(xml.contains("w:highlight w:val=\"yellow\""));

    let reopened_again =
        Document::open(&path).expect("reopen multi-paragraph rich table review docx");
    let cell = reopened_again.tables()[0].cell(0, 0).expect("cell");
    assert_eq!(cell.text(), "Alpha\nBeta Gamma");
    assert_eq!(reopened_again.comments().len(), 1);
}

#[test]
fn review_table_cell_text_preserves_untouched_sibling_paragraph_xml() {
    let temp = tempdir().expect("create tempdir");
    let path = temp
        .path()
        .join("reviewed-table-cell-sibling-preserve.docx");

    let mut document = Document::new();
    let table = document.add_table(1, 1);
    assert!(table.set_cell_text(0, 0, "Alpha Beta Gamma"));
    document.save(&path).expect("save table base docx");

    let original_paragraph = "<w:p>\n            <w:r>\n              <w:t>Alpha Beta Gamma</w:t>\n            </w:r>\n          </w:p>";
    let first_paragraph =
        "<w:p w:rsidR=\"00111111\"><w:r><w:rPr><w:b/></w:rPr><w:t>Lead</w:t></w:r></w:p>";
    let middle_paragraph = "<w:p w:rsidR=\"00222222\"><w:r><w:t>Alpha Beta Gamma</w:t></w:r></w:p>";
    let last_paragraph =
        "<w:p w:rsidR=\"00333333\"><w:r><w:rPr><w:i/></w:rPr><w:t>Tail</w:t></w:r></w:p>";
    rewrite_document_xml(&path, |xml| {
        xml.replacen(
            original_paragraph,
            format!("{first_paragraph}{middle_paragraph}{last_paragraph}").as_str(),
            1,
        )
    });

    let mut reopened = Document::open(&path).expect("open table sibling preserve docx");
    let comment_id = reopened
        .review_table_cell_text_with_date(
            0,
            0,
            0,
            "Beta",
            "Reviewer",
            "Review middle paragraph Beta.",
            Some("yellow"),
            Some("2026-03-24T18:16:00Z"),
        )
        .expect("review table cell text");
    assert_eq!(comment_id, 0);
    reopened
        .save(&path)
        .expect("save table sibling preserve docx");

    let xml = document_xml(&path);
    assert!(xml.contains(first_paragraph));
    assert!(xml.contains(last_paragraph));
    assert!(xml.contains("w:commentRangeStart w:id=\"0\""));
    assert!(xml.contains("w:highlight w:val=\"yellow\""));
}

#[test]
fn comment_table_cell_text_preserves_untouched_sibling_paragraph_xml() {
    let temp = tempdir().expect("create tempdir");
    let path = temp
        .path()
        .join("commented-table-cell-sibling-preserve.docx");

    let mut document = Document::new();
    let table = document.add_table(1, 1);
    assert!(table.set_cell_text(0, 0, "Alpha Beta Gamma"));
    document.save(&path).expect("save table base docx");

    let original_paragraph = "<w:p>\n            <w:r>\n              <w:t>Alpha Beta Gamma</w:t>\n            </w:r>\n          </w:p>";
    let first_paragraph =
        "<w:p w:rsidR=\"00111111\"><w:r><w:rPr><w:b/></w:rPr><w:t>Lead</w:t></w:r></w:p>";
    let middle_paragraph = "<w:p w:rsidR=\"00222222\"><w:r><w:t>Alpha Beta Gamma</w:t></w:r></w:p>";
    let last_paragraph =
        "<w:p w:rsidR=\"00333333\"><w:r><w:rPr><w:i/></w:rPr><w:t>Tail</w:t></w:r></w:p>";
    rewrite_document_xml(&path, |xml| {
        xml.replacen(
            original_paragraph,
            format!("{first_paragraph}{middle_paragraph}{last_paragraph}").as_str(),
            1,
        )
    });

    let mut reopened = Document::open(&path).expect("open table sibling comment docx");
    let comment_id = reopened
        .add_comment_to_table_cell_text_with_date(
            0,
            0,
            0,
            "Beta",
            "Reviewer",
            "Comment middle paragraph Beta.",
            Some("2026-03-24T18:17:00Z"),
        )
        .expect("comment table cell text");
    assert_eq!(comment_id, 0);
    reopened
        .save(&path)
        .expect("save table sibling comment docx");

    let xml = document_xml(&path);
    assert!(xml.contains(first_paragraph));
    assert!(xml.contains(last_paragraph));
    assert!(xml.contains("w:commentRangeStart w:id=\"0\""));
    assert!(xml.contains("w:commentReference w:id=\"0\""));
}

#[test]
fn review_table_cell_text_preserves_raw_non_paragraph_tc_siblings() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("reviewed-table-cell-raw-siblings.docx");

    let mut document = Document::new();
    let table = document.add_table(1, 1);
    assert!(table.set_cell_text(0, 0, "Alpha Beta Gamma"));
    document.save(&path).expect("save table base docx");

    let original_paragraph = "<w:p>\n            <w:r>\n              <w:t>Alpha Beta Gamma</w:t>\n            </w:r>\n          </w:p>";
    let first_paragraph = "<w:p w:rsidR=\"00111111\"><w:r><w:t>Lead</w:t></w:r></w:p>";
    let middle_paragraph = "<w:p w:rsidR=\"00222222\"><w:r><w:t>Alpha Beta Gamma</w:t></w:r></w:p>";
    let last_paragraph = "<w:p w:rsidR=\"00333333\"><w:r><w:t>Tail</w:t></w:r></w:p>";
    let proof_start = "<w:proofErr w:type=\"spellStart\"/>";
    let proof_end = "<w:proofErr w:type=\"spellEnd\"/>";
    let perm_start = "<w:permStart w:id=\"7\" w:edGrp=\"everyone\"/>";
    let perm_end = "<w:permEnd w:id=\"7\"/>";
    rewrite_document_xml(&path, |xml| {
        xml.replacen(
            original_paragraph,
            format!(
                "{first_paragraph}{proof_start}{proof_end}{middle_paragraph}{perm_start}{perm_end}{last_paragraph}"
            )
            .as_str(),
            1,
        )
    });

    let mut reopened = Document::open(&path).expect("open table raw sibling review docx");
    let comment_id = reopened
        .review_table_cell_text_with_date(
            0,
            0,
            0,
            "Beta",
            "Reviewer",
            "Review middle paragraph Beta.",
            Some("yellow"),
            Some("2026-03-24T19:05:00Z"),
        )
        .expect("review table cell text with raw siblings");
    assert_eq!(comment_id, 0);
    reopened
        .save(&path)
        .expect("save table raw sibling review docx");

    let xml = document_xml(&path);
    assert!(xml.contains(first_paragraph));
    assert!(xml.contains(last_paragraph));
    assert!(xml.contains(proof_start));
    assert!(xml.contains(proof_end));
    assert!(xml.contains(perm_start));
    assert!(xml.contains(perm_end));
    assert!(xml.contains("w:commentRangeStart w:id=\"0\""));
    assert!(xml.contains("w:highlight w:val=\"yellow\""));

    let first_index = xml.find(first_paragraph).expect("first paragraph");
    let proof_start_index = xml.find(proof_start).expect("proof start");
    let proof_end_index = xml.find(proof_end).expect("proof end");
    let perm_start_index = xml.find(perm_start).expect("perm start");
    let perm_end_index = xml.find(perm_end).expect("perm end");
    let last_index = xml.find(last_paragraph).expect("last paragraph");
    assert!(first_index < proof_start_index);
    assert!(proof_start_index < proof_end_index);
    assert!(proof_end_index < perm_start_index);
    assert!(perm_start_index < perm_end_index);
    assert!(perm_end_index < last_index);

    let reopened_again = Document::open(&path).expect("reopen table raw sibling review docx");
    let cell = reopened_again.tables()[0].cell(0, 0).expect("cell");
    assert_eq!(cell.text(), "Lead\nAlpha Beta Gamma\nTail");
}

#[test]
fn highlight_table_cell_text_preserves_raw_non_paragraph_tc_siblings() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("highlighted-table-cell-raw-siblings.docx");

    let mut document = Document::new();
    let table = document.add_table(1, 1);
    assert!(table.set_cell_text(0, 0, "Alpha Beta Gamma"));
    document.save(&path).expect("save table base docx");

    let original_paragraph = "<w:p>\n            <w:r>\n              <w:t>Alpha Beta Gamma</w:t>\n            </w:r>\n          </w:p>";
    let first_paragraph = "<w:p w:rsidR=\"00111111\"><w:r><w:t>Lead</w:t></w:r></w:p>";
    let middle_paragraph = "<w:p w:rsidR=\"00222222\"><w:r><w:t>Alpha Beta Gamma</w:t></w:r></w:p>";
    let last_paragraph = "<w:p w:rsidR=\"00333333\"><w:r><w:t>Tail</w:t></w:r></w:p>";
    let proof_start = "<w:proofErr w:type=\"spellStart\"/>";
    let proof_end = "<w:proofErr w:type=\"spellEnd\"/>";
    rewrite_document_xml(&path, |xml| {
        xml.replacen(
            original_paragraph,
            format!("{first_paragraph}{proof_start}{proof_end}{middle_paragraph}{last_paragraph}")
                .as_str(),
            1,
        )
    });

    let mut reopened = Document::open(&path).expect("open table raw sibling highlight docx");
    reopened
        .highlight_table_cell_text(0, 0, 0, "Beta", "yellow")
        .expect("highlight table cell text with raw siblings");
    reopened
        .save(&path)
        .expect("save table raw sibling highlight docx");

    let xml = document_xml(&path);
    assert!(xml.contains(first_paragraph));
    assert!(xml.contains(last_paragraph));
    assert!(xml.contains(proof_start));
    assert!(xml.contains(proof_end));
    assert!(xml.contains("w:highlight w:val=\"yellow\""));

    let first_index = xml.find(first_paragraph).expect("first paragraph");
    let proof_start_index = xml.find(proof_start).expect("proof start");
    let proof_end_index = xml.find(proof_end).expect("proof end");
    let last_index = xml.find(last_paragraph).expect("last paragraph");
    assert!(first_index < proof_start_index);
    assert!(proof_start_index < proof_end_index);
    assert!(proof_end_index < last_index);
}

#[test]
fn revisions_include_supported_non_body_parts() {
    let document = build_document_with_supported_part_revisions();
    let revisions = document.revisions();

    assert_eq!(revisions.len(), 5);
    assert!(revisions
        .iter()
        .any(|revision| revision.location == "body/paragraph:0" && revision.text == " Added"));
    assert!(revisions.iter().any(|revision| {
        revision.location == "header/default/paragraph:0" && revision.text == " Added"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "footer/default/paragraph:0" && revision.text == " Remove"
    }));
    assert!(
        revisions
            .iter()
            .any(|revision| revision.location == "footnote:7/paragraph:0"
                && revision.text == " Added")
    );
    assert!(
        revisions
            .iter()
            .any(|revision| revision.location == "endnote:9/paragraph:0"
                && revision.text == " Remove")
    );
}

#[test]
fn accept_and_reject_revisions_reach_supported_non_body_parts() {
    let temp = tempdir().expect("create tempdir");
    let accept_path = temp.path().join("accepted-supported-parts.docx");
    let reject_path = temp.path().join("rejected-supported-parts.docx");

    let mut accepted = build_document_with_supported_part_revisions();
    let report = accepted.accept_revisions();
    assert_eq!(report.insertions, 3);
    assert_eq!(report.deletions, 2);
    accepted
        .save(&accept_path)
        .expect("save accepted supported-parts docx");

    let accepted_reopened =
        Document::open(&accept_path).expect("reopen accepted supported-parts docx");
    assert!(accepted_reopened.revisions().is_empty());
    assert!(accepted_reopened
        .section()
        .header()
        .expect("header")
        .paragraphs()[0]
        .text()
        .contains("Header Added"));
    assert!(accepted_reopened
        .section()
        .footer()
        .expect("footer")
        .paragraphs()[0]
        .text()
        .contains("Footer Keep"));
    assert!(!accepted_reopened
        .section()
        .footer()
        .expect("footer")
        .paragraphs()[0]
        .text()
        .contains("Remove"));
    assert!(accepted_reopened.footnotes()[0].paragraphs()[0]
        .text()
        .contains("Footnote Added"));
    assert!(accepted_reopened.endnotes()[0].paragraphs()[0]
        .text()
        .contains("Endnote Keep"));
    assert!(!accepted_reopened.endnotes()[0].paragraphs()[0]
        .text()
        .contains("Remove"));
    assert_eq!(
        count_tag(&part_xml(&accept_path, "/word/header1.xml"), "w:ins"),
        0
    );
    assert_eq!(
        count_tag(&part_xml(&accept_path, "/word/footer1.xml"), "w:del"),
        0
    );
    assert_eq!(
        count_tag(&part_xml(&accept_path, "/word/footnotes.xml"), "w:ins"),
        0
    );
    assert_eq!(
        count_tag(&part_xml(&accept_path, "/word/endnotes.xml"), "w:del"),
        0
    );

    let mut rejected = build_document_with_supported_part_revisions();
    let report = rejected.reject_revisions();
    assert_eq!(report.insertions, 3);
    assert_eq!(report.deletions, 2);
    rejected
        .save(&reject_path)
        .expect("save rejected supported-parts docx");

    let rejected_reopened =
        Document::open(&reject_path).expect("reopen rejected supported-parts docx");
    assert!(rejected_reopened.revisions().is_empty());
    assert_eq!(
        rejected_reopened
            .section()
            .header()
            .expect("header")
            .paragraphs()[0]
            .text(),
        "Header"
    );
    assert_eq!(
        rejected_reopened
            .section()
            .footer()
            .expect("footer")
            .paragraphs()[0]
            .text(),
        "Footer Keep Remove"
    );
    assert_eq!(
        rejected_reopened.footnotes()[0].paragraphs()[0].text(),
        "Footnote"
    );
    assert_eq!(
        rejected_reopened.endnotes()[0].paragraphs()[0].text(),
        "Endnote Keep Remove"
    );
    assert_eq!(
        count_tag(&part_xml(&reject_path, "/word/header1.xml"), "w:ins"),
        0
    );
    assert_eq!(
        count_tag(&part_xml(&reject_path, "/word/footer1.xml"), "w:del"),
        0
    );
    assert_eq!(
        count_tag(&part_xml(&reject_path, "/word/footnotes.xml"), "w:ins"),
        0
    );
    assert_eq!(
        count_tag(&part_xml(&reject_path, "/word/endnotes.xml"), "w:del"),
        0
    );
}

#[test]
fn revisions_include_property_change_revisions_across_supported_parts() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("property-revisions.docx");

    let mut document = Document::new();
    document.add_paragraph("BodyBase");
    document
        .section_mut()
        .ensure_header()
        .add_paragraph("HeaderBase");
    document.add_footnote(offidized_docx::Footnote::from_text(1, "placeholder"));
    document.save(&path).expect("save property revisions docx");

    rewrite_document_xml(&path, |xml| {
        xml.replace(
            "<w:p>\n      <w:r>\n        <w:t>BodyBase</w:t>\n      </w:r>\n    </w:p>",
            "<w:p><w:pPr><w:pPrChange w:id=\"61\" w:author=\"Reviewer\"><w:pPr><w:jc w:val=\"center\"/></w:pPr></w:pPrChange></w:pPr><w:r><w:t>BodyBase</w:t></w:r></w:p>",
        )
    });
    rewrite_part_xml(&path, "/word/header1.xml", |xml| {
        xml.replace(
            "<w:r>\n      <w:t>HeaderBase</w:t>\n    </w:r>",
            "<w:r><w:rPr><w:rPrChange w:id=\"62\" w:author=\"Reviewer\"><w:rPr><w:b/></w:rPr></w:rPrChange></w:rPr><w:t>HeaderBase</w:t></w:r>",
        )
    });
    rewrite_part_xml(&path, "/word/footnotes.xml", |xml| {
        xml.replace(
            "<w:p>\n      <w:r>\n        <w:t>placeholder</w:t>\n      </w:r>\n    </w:p>",
            "<w:tbl><w:tblPr/><w:tblGrid><w:gridCol w:w=\"4320\"/></w:tblGrid><w:tr><w:tc><w:tcPr><w:tcPrChange w:id=\"63\" w:author=\"Reviewer\"><w:tcPr><w:shd w:fill=\"FFFF00\"/></w:tcPr></w:tcPrChange></w:tcPr><w:p><w:r><w:t>CellBase</w:t></w:r></w:p></w:tc></w:tr></w:tbl>",
        )
    });

    let reopened = Document::open(&path).expect("reopen property revisions docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:0"
            && revision.kind == RevisionKind::PropertyChange
            && revision.text == "pPrChange"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "header/default/paragraph:0"
            && revision.kind == RevisionKind::PropertyChange
            && revision.text == "rPrChange"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "footnote:1/table:0/cell:0,0"
            && revision.kind == RevisionKind::PropertyChange
            && revision.text == "tcPrChange"
    }));
}

#[test]
fn accept_and_reject_property_change_revisions_across_supported_parts() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("property-revisions-transform.docx");
    let accept_path = temp.path().join("property-revisions-accepted.docx");
    let reject_path = temp.path().join("property-revisions-rejected.docx");

    let mut document = Document::new();
    let body = document.add_paragraph("BodyBase");
    body.set_alignment(ParagraphAlignment::Right);
    let header = document
        .section_mut()
        .ensure_header()
        .add_paragraph("HeaderBase");
    header.runs_mut()[0].set_bold(true);
    let mut footnote = offidized_docx::Footnote::new(1);
    let cell = footnote
        .add_table(1, 1)
        .cell_mut(0, 0)
        .expect("cell must exist");
    cell.set_text("CellBase");
    cell.set_shading_color("FF0000");
    document.add_footnote(footnote);
    document.save(&path).expect("save property transform docx");

    rewrite_document_xml(&path, |xml| {
        xml.replace(
            "<w:jc w:val=\"right\"/>",
            "<w:jc w:val=\"right\"/><w:pPrChange w:id=\"81\" w:author=\"Reviewer\"><w:pPr><w:jc w:val=\"center\"/></w:pPr></w:pPrChange>",
        )
    });
    rewrite_part_xml(&path, "/word/header1.xml", |xml| {
        xml.replace(
            "<w:b/>",
            "<w:b/><w:rPrChange w:id=\"82\" w:author=\"Reviewer\"><w:rPr><w:i/></w:rPr></w:rPrChange>",
        )
    });
    rewrite_part_xml(&path, "/word/footnotes.xml", |xml| {
        xml.replace(
            "<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"FF0000\"/>",
            "<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"FF0000\"/><w:tcPrChange w:id=\"83\" w:author=\"Reviewer\"><w:tcPr><w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"FFFF00\"/></w:tcPr></w:tcPrChange>",
        )
    });

    let mut accepted = Document::open(&path).expect("open property transform docx");
    let report = accepted.accept_revisions_filtered(&RevisionFilter::with_kinds(vec![
        RevisionKind::PropertyChange,
    ]));
    assert_eq!(report.insertions, 0);
    assert_eq!(report.deletions, 0);
    accepted
        .save(&accept_path)
        .expect("save accepted property transform docx");
    let accepted_xml = part_xml(&accept_path, "/word/document.xml");
    let accepted_header_xml = part_xml(&accept_path, "/word/header1.xml");
    let accepted_footnote_xml = part_xml(&accept_path, "/word/footnotes.xml");
    assert!(accepted_xml.contains("w:jc w:val=\"right\""));
    assert!(!accepted_xml.contains("pPrChange"));
    assert!(accepted_header_xml.contains("<w:b/>"));
    assert!(!accepted_header_xml.contains("rPrChange"));
    assert!(accepted_footnote_xml.contains("w:fill=\"FF0000\""));
    assert!(!accepted_footnote_xml.contains("tcPrChange"));

    let mut rejected = Document::open(&path).expect("open property transform docx for reject");
    let report = rejected.reject_revisions_filtered(&RevisionFilter::with_kinds(vec![
        RevisionKind::PropertyChange,
    ]));
    assert_eq!(report.insertions, 0);
    assert_eq!(report.deletions, 0);
    rejected
        .save(&reject_path)
        .expect("save rejected property transform docx");
    let rejected_xml = part_xml(&reject_path, "/word/document.xml");
    let rejected_header_xml = part_xml(&reject_path, "/word/header1.xml");
    let rejected_footnote_xml = part_xml(&reject_path, "/word/footnotes.xml");
    assert!(rejected_xml.contains("w:jc w:val=\"center\""));
    assert!(!rejected_xml.contains("w:jc w:val=\"right\""));
    assert!(!rejected_xml.contains("pPrChange"));
    assert!(rejected_header_xml.contains("<w:i/>"));
    assert!(!rejected_header_xml.contains("<w:b/>"));
    assert!(!rejected_header_xml.contains("rPrChange"));
    assert!(rejected_footnote_xml.contains("w:fill=\"FFFF00\""));
    assert!(!rejected_footnote_xml.contains("w:fill=\"FF0000\""));
    assert!(!rejected_footnote_xml.contains("tcPrChange"));

    let reopened = Document::open(&reject_path).expect("reopen rejected property transform docx");
    assert_eq!(
        reopened.paragraphs()[0].alignment(),
        Some(ParagraphAlignment::Center)
    );
    let header_run = &reopened
        .section()
        .header()
        .expect("header should exist")
        .paragraphs()[0]
        .runs()[0];
    assert!(header_run.is_italic());
    assert!(!header_run.is_bold());
    assert_eq!(
        reopened.footnotes()[0].tables()[0]
            .cell(0, 0)
            .expect("cell should exist")
            .shading_color(),
        Some("FFFF00")
    );
}

#[test]
fn move_revisions_are_reported_and_transformed_across_supported_parts() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("move-revisions.docx");
    let accept_path = temp.path().join("move-revisions-accepted.docx");
    let reject_path = temp.path().join("move-revisions-rejected.docx");

    let mut document = Document::new();
    document.add_paragraph("BodyBase");
    document
        .section_mut()
        .ensure_header()
        .add_paragraph("HeaderBase");
    document.add_footnote(offidized_docx::Footnote::from_text(1, "placeholder"));
    document.save(&path).expect("save move revisions docx");

    rewrite_document_xml(&path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>BodyBase</w:t>\n      </w:r>",
            "<w:r><w:t>BodyBase</w:t></w:r><w:moveFrom w:id=\"71\" w:author=\"Reviewer\"><w:r><w:t xml:space=\"preserve\"> Old</w:t></w:r></w:moveFrom><w:moveTo w:id=\"72\" w:author=\"Reviewer\"><w:r><w:t xml:space=\"preserve\"> New</w:t></w:r></w:moveTo>",
        )
    });
    rewrite_part_xml(&path, "/word/header1.xml", |xml| {
        xml.replace(
            "<w:r>\n      <w:t>HeaderBase</w:t>\n    </w:r>",
            "<w:r><w:t>HeaderBase</w:t></w:r><w:moveFrom w:id=\"73\" w:author=\"Reviewer\"><w:r><w:t xml:space=\"preserve\"> Gone</w:t></w:r></w:moveFrom><w:moveTo w:id=\"74\" w:author=\"Reviewer\"><w:r><w:t xml:space=\"preserve\"> Here</w:t></w:r></w:moveTo>",
        )
    });
    rewrite_part_xml(&path, "/word/footnotes.xml", |xml| {
        xml.replace(
            "<w:p>\n      <w:r>\n        <w:t>placeholder</w:t>\n      </w:r>\n    </w:p>",
            "<w:tbl><w:tblPr/><w:tblGrid><w:gridCol w:w=\"4320\"/></w:tblGrid><w:tr><w:tc><w:p><w:r><w:t>CellBase</w:t></w:r><w:moveFrom w:id=\"75\" w:author=\"Reviewer\"><w:r><w:t xml:space=\"preserve\"> Away</w:t></w:r></w:moveFrom><w:moveTo w:id=\"76\" w:author=\"Reviewer\"><w:r><w:t xml:space=\"preserve\"> Back</w:t></w:r></w:moveTo></w:p></w:tc></w:tr></w:tbl>",
        )
    });

    let reopened = Document::open(&path).expect("reopen move revisions docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:0"
            && revision.kind == RevisionKind::MoveFrom
            && revision.text == " Old"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:0"
            && revision.kind == RevisionKind::MoveTo
            && revision.text == " New"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "header/default/paragraph:0"
            && revision.kind == RevisionKind::MoveFrom
            && revision.text == " Gone"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "footnote:1/table:0/cell:0,0/paragraph:0"
            && revision.kind == RevisionKind::MoveTo
            && revision.text == " Back"
    }));

    let mut accepted = Document::open(&path).expect("open move revisions docx");
    let report = accepted.accept_revisions();
    assert_eq!(report.insertions, 3);
    assert_eq!(report.deletions, 3);
    accepted
        .save(&accept_path)
        .expect("save accepted move revisions docx");
    let accepted_xml = part_xml(&accept_path, "/word/document.xml");
    let accepted_header_xml = part_xml(&accept_path, "/word/header1.xml");
    let accepted_footnote_xml = part_xml(&accept_path, "/word/footnotes.xml");
    assert!(accepted_xml.contains(" New"));
    assert!(!accepted_xml.contains(" Old"));
    assert!(accepted_header_xml.contains(" Here"));
    assert!(!accepted_header_xml.contains(" Gone"));
    assert!(accepted_footnote_xml.contains(" Back"));
    assert!(!accepted_footnote_xml.contains(" Away"));

    let mut rejected = Document::open(&path).expect("open move revisions docx");
    let report = rejected.reject_revisions();
    assert_eq!(report.insertions, 3);
    assert_eq!(report.deletions, 3);
    rejected
        .save(&reject_path)
        .expect("save rejected move revisions docx");
    let rejected_xml = part_xml(&reject_path, "/word/document.xml");
    let rejected_header_xml = part_xml(&reject_path, "/word/header1.xml");
    let rejected_footnote_xml = part_xml(&reject_path, "/word/footnotes.xml");
    assert!(rejected_xml.contains(" Old"));
    assert!(!rejected_xml.contains(" New"));
    assert!(rejected_header_xml.contains(" Gone"));
    assert!(!rejected_header_xml.contains(" Here"));
    assert!(rejected_footnote_xml.contains(" Away"));
    assert!(!rejected_footnote_xml.contains(" Back"));
}

#[test]
fn revisions_include_body_and_header_table_cell_paragraphs() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("table-revisions.docx");

    let mut document = Document::new();
    document.add_table(1, 1).set_cell_text(0, 0, "BodyCell");
    document
        .section_mut()
        .ensure_header()
        .add_table(1, 1)
        .set_cell_text(0, 0, "HeaderCell Keep");
    document.save(&path).expect("save table revisions docx");

    rewrite_document_xml(&path, |xml| {
        xml.replace(
            "<w:r>\n              <w:t>BodyCell</w:t>\n            </w:r>",
            "<w:r>\n              <w:t>BodyCell</w:t>\n            </w:r><w:ins w:id=\"21\" w:author=\"Reviewer\"><w:r><w:t xml:space=\"preserve\"> Added</w:t></w:r></w:ins>",
        )
    });
    rewrite_part_xml(&path, "/word/header1.xml", |xml| {
        xml.replace(
            "<w:r>\n            <w:t>HeaderCell Keep</w:t>\n          </w:r>",
            "<w:r>\n            <w:t>HeaderCell Keep</w:t>\n          </w:r><w:del w:id=\"22\" w:author=\"Reviewer\"><w:r><w:delText xml:space=\"preserve\"> Drop</w:delText></w:r></w:del>",
        )
    });

    let reopened = Document::open(&path).expect("reopen table revisions docx");
    let revisions = reopened.revisions();
    assert_eq!(revisions.len(), 2);
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/table:0/cell:0,0/paragraph:0" && revision.text == " Added"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "header/default/table:0/cell:0,0/paragraph:0"
            && revision.text == " Drop"
    }));
}

#[test]
fn tbl_grid_change_revisions_are_reported_and_transformed() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("tbl-grid-change.docx");
    let accept_path = temp.path().join("tbl-grid-change-accepted.docx");
    let reject_path = temp.path().join("tbl-grid-change-rejected.docx");

    let mut document = Document::new();
    let table = document.add_table(1, 2);
    table.set_column_widths_twips(vec![2400, 3600]);
    table.set_cell_text(0, 0, "Left");
    table.set_cell_text(0, 1, "Right");
    document.save(&path).expect("save tblGridChange docx");

    rewrite_document_xml(&path, |xml| {
        xml.replace(
            "<w:tblGrid>\n        <w:gridCol w:w=\"2400\"/>\n        <w:gridCol w:w=\"3600\"/>\n      </w:tblGrid>",
            "<w:tblGrid><w:gridCol w:w=\"2400\"/><w:gridCol w:w=\"3600\"/><w:tblGridChange w:id=\"101\" w:author=\"Reviewer\"><w:tblGrid><w:gridCol w:w=\"1800\"/><w:gridCol w:w=\"4200\"/></w:tblGrid></w:tblGridChange></w:tblGrid>",
        )
    });

    let reopened = Document::open(&path).expect("reopen tblGridChange docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/table:0"
            && revision.kind == RevisionKind::PropertyChange
            && revision.text == "tblGridChange"
    }));

    let mut accepted = Document::open(&path).expect("open tblGridChange docx for accept");
    let report = accepted.accept_revisions_filtered(&RevisionFilter::with_kinds(vec![
        RevisionKind::PropertyChange,
    ]));
    assert_eq!(report.insertions, 0);
    assert_eq!(report.deletions, 0);
    accepted
        .save(&accept_path)
        .expect("save accepted tblGridChange docx");
    let accepted_xml = part_xml(&accept_path, "/word/document.xml");
    assert!(!accepted_xml.contains("tblGridChange"));
    let reopened_accepted = Document::open(&accept_path).expect("reopen accepted tblGridChange");
    assert_eq!(
        reopened_accepted.tables()[0].column_widths_twips(),
        &[2400, 3600]
    );

    let mut rejected = Document::open(&path).expect("open tblGridChange docx for reject");
    let report = rejected.reject_revisions_filtered(&RevisionFilter::with_kinds(vec![
        RevisionKind::PropertyChange,
    ]));
    assert_eq!(report.insertions, 0);
    assert_eq!(report.deletions, 0);
    rejected
        .save(&reject_path)
        .expect("save rejected tblGridChange docx");
    let rejected_xml = part_xml(&reject_path, "/word/document.xml");
    assert!(!rejected_xml.contains("tblGridChange"));
    let reopened_rejected = Document::open(&reject_path).expect("reopen rejected tblGridChange");
    assert_eq!(
        reopened_rejected.tables()[0].column_widths_twips(),
        &[1800, 4200]
    );
}

#[test]
fn move_range_markers_are_listed_and_removed_by_accept_reject() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("move-range-markers.docx");
    let accept_path = temp.path().join("move-range-markers-accepted.docx");
    let reject_path = temp.path().join("move-range-markers-rejected.docx");

    let mut document = Document::new();
    document.add_paragraph("BodyBase");
    document
        .section_mut()
        .ensure_header()
        .add_paragraph("HeaderBase");
    document.save(&path).expect("save move range markers docx");

    rewrite_document_xml(&path, |xml| {
        xml.replace(
            "<w:r>\n        <w:t>BodyBase</w:t>\n      </w:r>",
            "<w:moveFromRangeStart w:id=\"91\"/><w:r><w:t>BodyBase</w:t></w:r><w:moveFromRangeEnd w:id=\"91\"/>",
        )
    });
    rewrite_part_xml(&path, "/word/header1.xml", |xml| {
        xml.replace(
            "<w:r>\n      <w:t>HeaderBase</w:t>\n    </w:r>",
            "<w:moveToRangeStart w:id=\"92\"/><w:r><w:t>HeaderBase</w:t></w:r><w:moveToRangeEnd w:id=\"92\"/>",
        )
    });

    let reopened = Document::open(&path).expect("open move range markers docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "body/paragraph:0"
            && revision.kind == RevisionKind::MoveFrom
            && revision.text == "moveFromRangeStart"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "header/default/paragraph:0"
            && revision.kind == RevisionKind::MoveTo
            && revision.text == "moveToRangeEnd"
    }));

    let mut accepted = Document::open(&path).expect("open move range markers docx for accept");
    let report = accepted.accept_revisions_filtered(&RevisionFilter::with_kinds(vec![
        RevisionKind::MoveFrom,
        RevisionKind::MoveTo,
    ]));
    assert_eq!(report.insertions, 0);
    assert_eq!(report.deletions, 0);
    assert!(!accepted.revisions().iter().any(|revision| {
        matches!(
            revision.text.as_str(),
            "moveFromRangeStart" | "moveFromRangeEnd" | "moveToRangeStart" | "moveToRangeEnd"
        )
    }));
    accepted
        .save(&accept_path)
        .expect("save accepted move range markers docx");
    let accepted_xml = part_xml(&accept_path, "/word/document.xml");
    let accepted_header_xml = part_xml(&accept_path, "/word/header1.xml");
    assert!(!accepted_xml.contains("moveFromRangeStart"));
    assert!(!accepted_xml.contains("moveFromRangeEnd"));
    assert!(!accepted_header_xml.contains("moveToRangeStart"));
    assert!(!accepted_header_xml.contains("moveToRangeEnd"));

    let mut rejected = Document::open(&path).expect("open move range markers docx for reject");
    let report = rejected.reject_revisions_filtered(&RevisionFilter::with_kinds(vec![
        RevisionKind::MoveFrom,
        RevisionKind::MoveTo,
    ]));
    assert_eq!(report.insertions, 0);
    assert_eq!(report.deletions, 0);
    rejected
        .save(&reject_path)
        .expect("save rejected move range markers docx");
    let rejected_xml = part_xml(&reject_path, "/word/document.xml");
    let rejected_header_xml = part_xml(&reject_path, "/word/header1.xml");
    assert!(!rejected_xml.contains("moveFromRangeStart"));
    assert!(!rejected_xml.contains("moveFromRangeEnd"));
    assert!(!rejected_header_xml.contains("moveToRangeStart"));
    assert!(!rejected_header_xml.contains("moveToRangeEnd"));
}

#[test]
fn accept_and_reject_revisions_reach_supported_table_cells() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("table-revisions.docx");
    let accept_path = temp.path().join("table-revisions-accepted.docx");
    let reject_path = temp.path().join("table-revisions-rejected.docx");

    let mut document = Document::new();
    document.add_table(1, 1).set_cell_text(0, 0, "BodyCell");
    document
        .section_mut()
        .ensure_header()
        .add_table(1, 1)
        .set_cell_text(0, 0, "HeaderCell Keep");
    document.save(&path).expect("save table revisions docx");

    rewrite_document_xml(&path, |xml| {
        xml.replace(
            "<w:r>\n              <w:t>BodyCell</w:t>\n            </w:r>",
            "<w:r>\n              <w:t>BodyCell</w:t>\n            </w:r><w:ins w:id=\"21\" w:author=\"Reviewer\"><w:r><w:t xml:space=\"preserve\"> Added</w:t></w:r></w:ins>",
        )
    });
    rewrite_part_xml(&path, "/word/header1.xml", |xml| {
        xml.replace(
            "<w:r>\n            <w:t>HeaderCell Keep</w:t>\n          </w:r>",
            "<w:r>\n            <w:t>HeaderCell Keep</w:t>\n          </w:r><w:del w:id=\"22\" w:author=\"Reviewer\"><w:r><w:delText xml:space=\"preserve\"> Drop</w:delText></w:r></w:del>",
        )
    });

    let mut accepted = Document::open(&path).expect("open table revisions docx");
    let report = accepted.accept_revisions();
    assert_eq!(report.insertions, 1);
    assert_eq!(report.deletions, 1);
    accepted
        .save(&accept_path)
        .expect("save accepted table revisions docx");

    let accepted_reopened =
        Document::open(&accept_path).expect("reopen accepted table revisions docx");
    assert!(accepted_reopened.revisions().is_empty());
    assert_eq!(
        accepted_reopened.tables()[0]
            .cell(0, 0)
            .expect("body cell")
            .text(),
        "BodyCell Added"
    );
    assert_eq!(
        accepted_reopened
            .section()
            .header()
            .expect("header")
            .tables()[0]
            .cell(0, 0)
            .expect("header cell")
            .text(),
        "HeaderCell Keep"
    );

    let mut rejected = Document::open(&path).expect("open table revisions docx for reject");
    let report = rejected.reject_revisions();
    assert_eq!(report.insertions, 1);
    assert_eq!(report.deletions, 1);
    rejected
        .save(&reject_path)
        .expect("save rejected table revisions docx");

    let rejected_reopened =
        Document::open(&reject_path).expect("reopen rejected table revisions docx");
    assert!(rejected_reopened.revisions().is_empty());
    assert_eq!(
        rejected_reopened.tables()[0]
            .cell(0, 0)
            .expect("body cell")
            .text(),
        "BodyCell"
    );
    assert_eq!(
        rejected_reopened
            .section()
            .header()
            .expect("header")
            .tables()[0]
            .cell(0, 0)
            .expect("header cell")
            .text(),
        "HeaderCell Keep Drop"
    );
}

#[test]
fn revisions_include_footnote_and_endnote_table_cell_paragraphs() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("note-table-revisions.docx");

    let mut document = Document::new();
    let mut footnote = offidized_docx::Footnote::new(7);
    footnote.add_table(1, 1).set_cell_text(0, 0, "FootCell");
    document.add_footnote(footnote);
    let mut endnote = offidized_docx::Endnote::new(9);
    endnote.add_table(1, 1).set_cell_text(0, 0, "EndCell Keep");
    document.add_endnote(endnote);
    document
        .save(&path)
        .expect("save note table revisions docx");

    rewrite_part_xml(&path, "/word/footnotes.xml", |xml| {
        xml.replacen(
            "</w:r>\n          </w:p>",
            "</w:r><w:ins w:id=\"31\" w:author=\"Reviewer\"><w:r><w:t xml:space=\"preserve\"> Added</w:t></w:r></w:ins>\n          </w:p>",
            1,
        )
    });
    rewrite_part_xml(&path, "/word/endnotes.xml", |xml| {
        xml.replacen(
            "</w:r>\n          </w:p>",
            "</w:r><w:del w:id=\"32\" w:author=\"Reviewer\"><w:r><w:delText xml:space=\"preserve\"> Drop</w:delText></w:r></w:del>\n          </w:p>",
            1,
        )
    });

    let reopened = Document::open(&path).expect("reopen note table revisions docx");
    let revisions = reopened.revisions();
    assert!(revisions.iter().any(|revision| {
        revision.location == "footnote:7/table:0/cell:0,0/paragraph:0" && revision.text == " Added"
    }));
    assert!(revisions.iter().any(|revision| {
        revision.location == "endnote:9/table:0/cell:0,0/paragraph:0" && revision.text == " Drop"
    }));
}

#[test]
fn accept_and_reject_revisions_reach_footnote_and_endnote_table_cells() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("note-table-revisions.docx");
    let accept_path = temp.path().join("note-table-revisions-accepted.docx");
    let reject_path = temp.path().join("note-table-revisions-rejected.docx");

    let mut document = Document::new();
    let mut footnote = offidized_docx::Footnote::new(7);
    footnote.add_table(1, 1).set_cell_text(0, 0, "FootCell");
    document.add_footnote(footnote);
    let mut endnote = offidized_docx::Endnote::new(9);
    endnote.add_table(1, 1).set_cell_text(0, 0, "EndCell Keep");
    document.add_endnote(endnote);
    document
        .save(&path)
        .expect("save note table revisions docx");

    rewrite_part_xml(&path, "/word/footnotes.xml", |xml| {
        xml.replacen(
            "</w:r>\n          </w:p>",
            "</w:r><w:ins w:id=\"31\" w:author=\"Reviewer\"><w:r><w:t xml:space=\"preserve\"> Added</w:t></w:r></w:ins>\n          </w:p>",
            1,
        )
    });
    rewrite_part_xml(&path, "/word/endnotes.xml", |xml| {
        xml.replacen(
            "</w:r>\n          </w:p>",
            "</w:r><w:del w:id=\"32\" w:author=\"Reviewer\"><w:r><w:delText xml:space=\"preserve\"> Drop</w:delText></w:r></w:del>\n          </w:p>",
            1,
        )
    });

    let mut accepted = Document::open(&path).expect("open note table revisions docx");
    let report = accepted.accept_revisions();
    assert_eq!(report.insertions, 1);
    assert_eq!(report.deletions, 1);
    accepted
        .save(&accept_path)
        .expect("save accepted note table revisions docx");
    let accepted_reopened =
        Document::open(&accept_path).expect("reopen accepted note table revisions docx");
    assert!(accepted_reopened.revisions().is_empty());
    assert_eq!(accepted_reopened.footnotes()[0].text(), "FootCell Added");
    assert_eq!(accepted_reopened.endnotes()[0].text(), "EndCell Keep");

    let mut rejected = Document::open(&path).expect("open note table revisions docx for reject");
    let report = rejected.reject_revisions();
    assert_eq!(report.insertions, 1);
    assert_eq!(report.deletions, 1);
    rejected
        .save(&reject_path)
        .expect("save rejected note table revisions docx");
    let rejected_reopened =
        Document::open(&reject_path).expect("reopen rejected note table revisions docx");
    assert!(rejected_reopened.revisions().is_empty());
    assert_eq!(rejected_reopened.footnotes()[0].text(), "FootCell");
    assert_eq!(rejected_reopened.endnotes()[0].text(), "EndCell Keep Drop");
}

#[test]
fn filtered_accept_and_reject_revisions() {
    let temp = tempdir().expect("create tempdir");
    let path = temp.path().join("filtered.docx");

    let mut document = Document::new();
    let alpha_insert = document.new_revision_metadata("Alice");
    let alpha_delete = document.new_revision_metadata("Alice");
    let beta_insert = document.new_revision_metadata("Bob");
    let beta_delete = document.new_revision_metadata("Bob");
    document
        .add_paragraph("Base")
        .add_inserted_text(" AliceIns", alpha_insert)
        .add_deleted_text(" AliceDel", alpha_delete)
        .add_inserted_text(" BobIns", beta_insert)
        .add_deleted_text(" BobDel", beta_delete);

    let report = document.accept_revisions_filtered(&RevisionFilter::by_author("Alice"));
    assert_eq!(report.insertions, 1);
    assert_eq!(report.deletions, 1);
    let remaining = document.revisions();
    assert_eq!(remaining.len(), 2);
    assert!(remaining
        .iter()
        .all(|revision| revision.author.as_deref() == Some("Bob")));

    let report = document
        .reject_revisions_filtered(&RevisionFilter::with_kinds(vec![RevisionKind::Deletion]));
    assert_eq!(report.insertions, 0);
    assert_eq!(report.deletions, 1);
    document.save(&path).expect("save filtered docx");

    let reopened = Document::open(&path).expect("reopen filtered docx");
    let remaining = reopened.revisions();
    assert_eq!(remaining.len(), 1);
    assert_eq!(remaining[0].kind, RevisionKind::Insertion);
    assert_eq!(remaining[0].author.as_deref(), Some("Bob"));
}

#[test]
fn accept_and_reject_programmatic_revisions() {
    let temp = tempdir().expect("create tempdir");
    let accept_path = temp.path().join("accepted.docx");
    let reject_path = temp.path().join("rejected.docx");

    let mut accepted = Document::new();
    let inserted = accepted.new_revision_metadata("Reviewer");
    let deleted = accepted.new_revision_metadata("Reviewer");
    let paragraph = accepted.add_paragraph("Alpha");
    paragraph.add_inserted_text(" Beta", inserted);
    paragraph.add_deleted_text(" Gamma", deleted);
    let report = accepted.accept_revisions();
    assert_eq!(report.insertions, 1);
    assert_eq!(report.deletions, 1);
    accepted.save(&accept_path).expect("save accepted docx");
    let accepted_reopened = Document::open(&accept_path).expect("reopen accepted docx");
    assert!(accepted_reopened.revisions().is_empty());
    let accepted_texts = accepted_reopened
        .paragraphs()
        .iter()
        .map(|p| p.text())
        .collect::<Vec<_>>();
    assert!(accepted_texts
        .iter()
        .any(|text| text.contains("Alpha Beta")));
    let accepted_xml = document_xml(&accept_path);
    assert_eq!(count_tag(&accepted_xml, "w:ins"), 0);
    assert_eq!(count_tag(&accepted_xml, "w:del"), 0);

    let mut rejected = Document::new();
    let inserted = rejected.new_revision_metadata("Reviewer");
    let deleted = rejected.new_revision_metadata("Reviewer");
    let paragraph = rejected.add_paragraph("Alpha");
    paragraph.add_inserted_text(" Beta", inserted);
    paragraph.add_deleted_text(" Gamma", deleted);
    let report = rejected.reject_revisions();
    assert_eq!(report.insertions, 1);
    assert_eq!(report.deletions, 1);
    rejected.save(&reject_path).expect("save rejected docx");
    let rejected_reopened = Document::open(&reject_path).expect("reopen rejected docx");
    assert!(rejected_reopened.revisions().is_empty());
    let rejected_texts = rejected_reopened
        .paragraphs()
        .iter()
        .map(|p| p.text())
        .collect::<Vec<_>>();
    assert!(rejected_texts
        .iter()
        .any(|text| text.contains("Alpha Gamma")));
    let rejected_xml = document_xml(&reject_path);
    assert_eq!(count_tag(&rejected_xml, "w:ins"), 0);
    assert_eq!(count_tag(&rejected_xml, "w:del"), 0);
}

#[test]
fn local_real_world_noop_roundtrip_is_byte_identical_if_available() {
    let Some(fixture_path) = local_real_world_docx_fixture() else {
        return;
    };
    if skip_if_missing(&fixture_path) {
        return;
    }

    let workspace = local_real_world_workspace("local-real-world-noop");
    let noop_path = workspace
        .path()
        .join("local-real-world-noop-open-save.docx");

    let document =
        Document::open(&fixture_path).expect("open local real-world fixture for noop save");
    document
        .save(&noop_path)
        .expect("save local real-world noop path");

    let original_bytes = fs::read(&fixture_path).expect("read original fixture bytes");
    let saved_bytes = fs::read(&noop_path).expect("read noop output bytes");
    assert_eq!(saved_bytes, original_bytes);
    eprintln!("noop output: {}", noop_path.display());
}

#[test]
fn local_real_world_validation_regression_if_available() {
    let Some(fixture_path) = local_real_world_docx_fixture() else {
        return;
    };
    if skip_if_missing(&fixture_path) {
        return;
    }

    run_local_real_world_validation_regression(&fixture_path, "local-real-world");

    let workspace = local_real_world_workspace("local-real-world-strict");
    let dirty_path = workspace
        .path()
        .join("local-real-world-strict-open-save.docx");
    let revised_path = workspace
        .path()
        .join("local-real-world-strict-revised.docx");
    let compared_path = workspace
        .path()
        .join("local-real-world-strict-compared.docx");

    let mut dirty =
        Document::open(&fixture_path).expect("open local real-world fixture for dirty save");
    dirty.add_paragraph("strict validator-backed dirty-save regression marker");
    dirty
        .save(&dirty_path)
        .expect("save local real-world dirty path");
    assert_openxml_sdk_validator_clean(&dirty_path);

    let mut revised =
        Document::open(&fixture_path).expect("open local real-world fixture for revise");
    revised.add_heading("Amendment C — Regression Coverage", 1);
    revised.add_paragraph(
        "This revision exists only to exercise real-world compare validation coverage in tests.",
    );
    revised
        .save(&revised_path)
        .expect("save local real-world revised path");
    assert_openxml_sdk_validator_clean(&revised_path);

    let compared = Document::compare(&fixture_path, &revised_path, "Regression Bot")
        .expect("compare local real-world fixture");
    compared
        .save(&compared_path)
        .expect("save local real-world compared path");
    assert_openxml_sdk_validator_clean(&compared_path);

    eprintln!("dirty output: {}", dirty_path.display());
    eprintln!("revised output: {}", revised_path.display());
    eprintln!("compared output: {}", compared_path.display());
}
