use crate::image::{FloatingImage, InlineImage};
use crate::revision::{build_deleted_text_node, build_inserted_text_node, RevisionMetadata};
use crate::run::{Run, UnderlineType};
use offidized_opc::RawXmlNode;

/// Line spacing rule for a paragraph (`w:lineRule` attribute on `w:spacing`).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LineSpacingRule {
    /// Spacing is automatically determined by the consumer (default). The value
    /// in `line_spacing_twips` is interpreted as 240ths of a line.
    Auto,
    /// Spacing is an exact value in twips. Lines taller than the value are clipped.
    Exact,
    /// Spacing is at least the given value in twips. Lines taller than the value
    /// expand the spacing.
    AtLeast,
}

impl LineSpacingRule {
    pub(crate) fn from_xml_value(value: &str) -> Option<Self> {
        match value {
            "auto" => Some(Self::Auto),
            "exact" => Some(Self::Exact),
            "atLeast" => Some(Self::AtLeast),
            _ => None,
        }
    }

    pub(crate) fn to_xml_value(self) -> &'static str {
        match self {
            Self::Auto => "auto",
            Self::Exact => "exact",
            Self::AtLeast => "atLeast",
        }
    }
}

/// Paragraph alignment.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ParagraphAlignment {
    Left,
    Center,
    Right,
    Justified,
}

impl ParagraphAlignment {
    pub(crate) fn from_xml_value(value: &str) -> Option<Self> {
        match value {
            "left" | "start" => Some(Self::Left),
            "center" => Some(Self::Center),
            "right" | "end" => Some(Self::Right),
            "both" | "justify" => Some(Self::Justified),
            _ => None,
        }
    }

    pub(crate) fn to_xml_value(self) -> &'static str {
        match self {
            Self::Left => "left",
            Self::Center => "center",
            Self::Right => "right",
            Self::Justified => "both",
        }
    }
}

/// Tab stop alignment within a paragraph.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TabStopAlignment {
    /// Left-aligned tab stop.
    Left,
    /// Center-aligned tab stop.
    Center,
    /// Right-aligned tab stop.
    Right,
    /// Decimal-aligned tab stop.
    Decimal,
    /// Bar tab stop.
    Bar,
    /// Clear an inherited tab stop at this position.
    Clear,
}

impl TabStopAlignment {
    pub(crate) fn from_xml_value(value: &str) -> Option<Self> {
        match value {
            "left" | "start" => Some(Self::Left),
            "center" => Some(Self::Center),
            "right" | "end" => Some(Self::Right),
            "decimal" | "num" => Some(Self::Decimal),
            "bar" => Some(Self::Bar),
            "clear" => Some(Self::Clear),
            _ => None,
        }
    }

    pub(crate) fn to_xml_value(self) -> &'static str {
        match self {
            Self::Left => "left",
            Self::Center => "center",
            Self::Right => "right",
            Self::Decimal => "decimal",
            Self::Bar => "bar",
            Self::Clear => "clear",
        }
    }
}

/// Tab stop leader character.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TabStopLeader {
    /// No leader.
    None,
    /// Dot leader.
    Dot,
    /// Hyphen leader.
    Hyphen,
    /// Underscore leader.
    Underscore,
    /// Heavy leader (thick line).
    Heavy,
    /// Middle dot leader.
    MiddleDot,
}

impl TabStopLeader {
    pub(crate) fn from_xml_value(value: &str) -> Option<Self> {
        match value {
            "none" => Some(Self::None),
            "dot" => Some(Self::Dot),
            "hyphen" => Some(Self::Hyphen),
            "underscore" => Some(Self::Underscore),
            "heavy" => Some(Self::Heavy),
            "middleDot" => Some(Self::MiddleDot),
            _ => None,
        }
    }

    pub(crate) fn to_xml_value(self) -> &'static str {
        match self {
            Self::None => "none",
            Self::Dot => "dot",
            Self::Hyphen => "hyphen",
            Self::Underscore => "underscore",
            Self::Heavy => "heavy",
            Self::MiddleDot => "middleDot",
        }
    }
}

/// A single tab stop definition in a paragraph.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TabStop {
    position_twips: u32,
    alignment: TabStopAlignment,
    leader: Option<TabStopLeader>,
    /// Whether this is a numbering tab (`w:tab` with `w:val="num"`-like behaviour flag).
    num_tab: bool,
}

impl TabStop {
    /// Create a new tab stop at the given position with alignment.
    pub fn new(position_twips: u32, alignment: TabStopAlignment) -> Self {
        Self {
            position_twips,
            alignment,
            leader: None,
            num_tab: false,
        }
    }

    /// Create a new tab stop with a leader character.
    pub fn with_leader(
        position_twips: u32,
        alignment: TabStopAlignment,
        leader: TabStopLeader,
    ) -> Self {
        Self {
            position_twips,
            alignment,
            leader: Some(leader),
            num_tab: false,
        }
    }

    /// Tab stop position, in twips.
    pub fn position_twips(&self) -> u32 {
        self.position_twips
    }

    /// Set tab stop position, in twips.
    pub fn set_position_twips(&mut self, position: u32) {
        self.position_twips = position;
    }

    /// Tab stop alignment.
    pub fn alignment(&self) -> TabStopAlignment {
        self.alignment
    }

    /// Set tab stop alignment.
    pub fn set_alignment(&mut self, alignment: TabStopAlignment) {
        self.alignment = alignment;
    }

    /// Tab stop leader character.
    pub fn leader(&self) -> Option<TabStopLeader> {
        self.leader
    }

    /// Set tab stop leader character.
    pub fn set_leader(&mut self, leader: TabStopLeader) {
        self.leader = Some(leader);
    }

    /// Clear leader character.
    pub fn clear_leader(&mut self) {
        self.leader = None;
    }

    /// Whether this tab stop is a numbering tab.
    pub fn num_tab(&self) -> bool {
        self.num_tab
    }

    /// Set whether this tab stop is a numbering tab.
    pub fn set_num_tab(&mut self, num_tab: bool) {
        self.num_tab = num_tab;
    }
}

/// A single border edge definition for a paragraph border.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct ParagraphBorder {
    line_type: Option<String>,
    size_eighth_points: Option<u16>,
    color: Option<String>,
    space_points: Option<u32>,
}

impl ParagraphBorder {
    /// Create a border with the given line type.
    pub fn new(line_type: impl Into<String>) -> Self {
        let mut border = Self::default();
        border.set_line_type(line_type);
        border
    }

    /// Border line type (e.g., `"single"`, `"double"`, `"dotted"`).
    pub fn line_type(&self) -> Option<&str> {
        self.line_type.as_deref()
    }

    /// Set border line type.
    pub fn set_line_type(&mut self, line_type: impl Into<String>) {
        self.line_type = normalize_optional_text(line_type.into());
    }

    /// Clear border line type.
    pub fn clear_line_type(&mut self) {
        self.line_type = None;
    }

    /// Border size in eighth-points.
    pub fn size_eighth_points(&self) -> Option<u16> {
        self.size_eighth_points
    }

    /// Set border size in eighth-points.
    pub fn set_size_eighth_points(&mut self, size: u16) {
        self.size_eighth_points = Some(size);
    }

    /// Clear border size.
    pub fn clear_size_eighth_points(&mut self) {
        self.size_eighth_points = None;
    }

    /// Border color, uppercase hex without `#`.
    pub fn color(&self) -> Option<&str> {
        self.color.as_deref()
    }

    /// Set border color.
    pub fn set_color(&mut self, color: impl Into<String>) {
        self.color = normalize_color_value(color.into().as_str());
    }

    /// Clear border color.
    pub fn clear_color(&mut self) {
        self.color = None;
    }

    /// Space between border and text, in points.
    pub fn space_points(&self) -> Option<u32> {
        self.space_points
    }

    /// Set space between border and text, in points.
    pub fn set_space_points(&mut self, space: u32) {
        self.space_points = Some(space);
    }

    /// Clear space.
    pub fn clear_space_points(&mut self) {
        self.space_points = None;
    }

    pub(crate) fn set_line_type_option(&mut self, line_type: Option<String>) {
        self.line_type = line_type.and_then(normalize_optional_text);
    }
}

/// Paragraph border collection (`w:pBdr`).
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct ParagraphBorders {
    top: Option<ParagraphBorder>,
    left: Option<ParagraphBorder>,
    bottom: Option<ParagraphBorder>,
    right: Option<ParagraphBorder>,
    between: Option<ParagraphBorder>,
}

impl ParagraphBorders {
    /// Create an empty border set.
    pub fn new() -> Self {
        Self::default()
    }

    /// Top border.
    pub fn top(&self) -> Option<&ParagraphBorder> {
        self.top.as_ref()
    }

    /// Set top border.
    pub fn set_top(&mut self, border: ParagraphBorder) {
        self.top = Some(border);
    }

    /// Clear top border.
    pub fn clear_top(&mut self) {
        self.top = None;
    }

    /// Left border.
    pub fn left(&self) -> Option<&ParagraphBorder> {
        self.left.as_ref()
    }

    /// Set left border.
    pub fn set_left(&mut self, border: ParagraphBorder) {
        self.left = Some(border);
    }

    /// Clear left border.
    pub fn clear_left(&mut self) {
        self.left = None;
    }

    /// Bottom border.
    pub fn bottom(&self) -> Option<&ParagraphBorder> {
        self.bottom.as_ref()
    }

    /// Set bottom border.
    pub fn set_bottom(&mut self, border: ParagraphBorder) {
        self.bottom = Some(border);
    }

    /// Clear bottom border.
    pub fn clear_bottom(&mut self) {
        self.bottom = None;
    }

    /// Right border.
    pub fn right(&self) -> Option<&ParagraphBorder> {
        self.right.as_ref()
    }

    /// Set right border.
    pub fn set_right(&mut self, border: ParagraphBorder) {
        self.right = Some(border);
    }

    /// Clear right border.
    pub fn clear_right(&mut self) {
        self.right = None;
    }

    /// Between border (between consecutive paragraphs with same settings).
    pub fn between(&self) -> Option<&ParagraphBorder> {
        self.between.as_ref()
    }

    /// Set between border.
    pub fn set_between(&mut self, border: ParagraphBorder) {
        self.between = Some(border);
    }

    /// Clear between border.
    pub fn clear_between(&mut self) {
        self.between = None;
    }

    /// Clear all borders.
    pub fn clear(&mut self) {
        *self = Self::default();
    }

    pub(crate) fn is_empty(&self) -> bool {
        self.top.is_none()
            && self.left.is_none()
            && self.bottom.is_none()
            && self.right.is_none()
            && self.between.is_none()
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum ParagraphContentItem {
    Run(usize),
    UnknownChild(usize),
    CommentRangeStart(u32),
    CommentRangeEnd(u32),
    CommentReference(u32),
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct CommentReferenceContext {
    id: u32,
    run: Run,
}

/// A paragraph in a Word document.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct Paragraph {
    runs: Vec<Run>,
    content_order: Vec<ParagraphContentItem>,
    heading_level: Option<u8>,
    style_id: Option<String>,
    alignment: Option<ParagraphAlignment>,
    spacing_before_twips: Option<u32>,
    spacing_after_twips: Option<u32>,
    line_spacing_twips: Option<u32>,
    indent_left_twips: Option<u32>,
    indent_right_twips: Option<u32>,
    indent_first_line_twips: Option<u32>,
    indent_hanging_twips: Option<u32>,
    numbering_num_id: Option<u32>,
    numbering_ilvl: Option<u8>,
    tab_stops: Vec<TabStop>,
    borders: ParagraphBorders,
    shading_color: Option<String>,
    shading_pattern: Option<String>,
    shading_color_attribute: Option<String>,
    line_spacing_rule: Option<LineSpacingRule>,
    before_autospacing: Option<bool>,
    after_autospacing: Option<bool>,
    keep_next: bool,
    keep_lines: bool,
    /// Whether a page break is inserted before this paragraph (`w:pageBreakBefore`).
    page_break_before: bool,
    /// Whether contextual spacing is enabled (`w:contextualSpacing`).
    /// When true, spacing between paragraphs of the same style is suppressed.
    contextual_spacing: bool,
    widow_control: Option<bool>,
    /// Outline level for this paragraph (`w:outlineLvl`), values 0-9.
    /// Used to define heading levels for table-of-contents generation.
    outline_level: Option<u8>,
    /// Bidirectional (RTL) paragraph direction (`w:bidi`).
    bidi: bool,
    /// Comment range start ids associated with this paragraph.
    comment_range_start_ids: Vec<u32>,
    /// Comment range end ids associated with this paragraph.
    comment_range_end_ids: Vec<u32>,
    /// Comment reference ids serialized as `w:commentReference` runs.
    comment_reference_ids: Vec<u32>,
    /// Preserved original run context for existing `w:commentReference` runs.
    comment_reference_contexts: Vec<CommentReferenceContext>,
    /// Section properties attached to this paragraph (for section breaks).
    /// When present, this paragraph is the last paragraph of a non-final section.
    section_properties: Option<Box<crate::section::Section>>,
    /// Extra attributes from the original `<w:p>` element, preserved on rewrite.
    extra_attributes: Vec<(String, String)>,
    unknown_children: Vec<RawXmlNode>,
    unknown_property_children: Vec<RawXmlNode>,
}

impl Paragraph {
    /// Create an empty paragraph.
    pub fn new() -> Self {
        Self::default()
    }

    /// Create a paragraph initialized with one text run.
    pub fn from_text(text: impl Into<String>) -> Self {
        let mut paragraph = Self::new();
        paragraph.add_run(text);
        paragraph
    }

    /// Create a heading paragraph.
    pub fn heading(text: impl Into<String>, level: u8) -> Self {
        let mut paragraph = Self::from_text(text);
        paragraph.heading_level = Some(level.clamp(1, 9));
        paragraph
    }

    /// Add a run and return a mutable reference to it.
    pub fn add_run(&mut self, text: impl Into<String>) -> &mut Run {
        self.runs.push(Run::new(text));
        let idx = self.runs.len().saturating_sub(1);
        self.content_order.push(ParagraphContentItem::Run(idx));
        &mut self.runs[idx]
    }

    pub(crate) fn push_run(&mut self, run: Run) {
        self.runs.push(run);
        let idx = self.runs.len().saturating_sub(1);
        self.content_order.push(ParagraphContentItem::Run(idx));
    }

    /// Add a run with an explicit character style identifier.
    pub fn add_run_with_style(
        &mut self,
        text: impl Into<String>,
        style_id: impl Into<String>,
    ) -> &mut Run {
        let run = self.add_run(text);
        run.set_style_id(style_id);
        run
    }

    /// Add a hyperlink run and return a mutable reference to it.
    pub fn add_hyperlink(
        &mut self,
        text: impl Into<String>,
        hyperlink: impl Into<String>,
    ) -> &mut Run {
        let run = self.add_run(text);
        run.set_hyperlink(hyperlink);
        run
    }

    /// Add an inline image run and return a mutable reference to it.
    pub fn add_inline_image(
        &mut self,
        image_index: usize,
        width_emu: u32,
        height_emu: u32,
    ) -> &mut Run {
        let run = self.add_run("");
        run.set_inline_image(InlineImage::new(image_index, width_emu, height_emu));
        run
    }

    /// Add a floating image run and return a mutable reference to it.
    pub fn add_floating_image(
        &mut self,
        image_index: usize,
        width_emu: u32,
        height_emu: u32,
    ) -> &mut Run {
        let run = self.add_run("");
        run.set_floating_image(FloatingImage::new(image_index, width_emu, height_emu));
        run
    }

    /// Append tracked inserted text (`w:ins`) to this paragraph.
    pub fn add_inserted_text(
        &mut self,
        text: impl Into<String>,
        metadata: RevisionMetadata,
    ) -> &mut Self {
        let text = text.into();
        let node = build_inserted_text_node(text.as_str(), &metadata);
        self.push_unknown_child(node);
        self
    }

    /// Append tracked deleted text (`w:del`) to this paragraph.
    pub fn add_deleted_text(
        &mut self,
        text: impl Into<String>,
        metadata: RevisionMetadata,
    ) -> &mut Self {
        let text = text.into();
        let node = build_deleted_text_node(text.as_str(), &metadata);
        self.push_unknown_child(node);
        self
    }

    /// All runs in this paragraph.
    pub fn runs(&self) -> &[Run] {
        &self.runs
    }

    /// Mutable access to all runs.
    pub fn runs_mut(&mut self) -> &mut [Run] {
        &mut self.runs
    }

    /// Replace all runs with a single run containing the given text.
    pub fn set_text(&mut self, text: impl Into<String>) {
        self.runs.clear();
        self.runs.push(Run::new(text));
        let mut reordered = vec![ParagraphContentItem::Run(0)];
        reordered.extend(self.content_order.iter().filter_map(|item| match item {
            ParagraphContentItem::UnknownChild(index) => {
                Some(ParagraphContentItem::UnknownChild(*index))
            }
            ParagraphContentItem::CommentRangeStart(id) => {
                Some(ParagraphContentItem::CommentRangeStart(*id))
            }
            ParagraphContentItem::CommentRangeEnd(id) => {
                Some(ParagraphContentItem::CommentRangeEnd(*id))
            }
            ParagraphContentItem::CommentReference(id) => {
                Some(ParagraphContentItem::CommentReference(*id))
            }
            ParagraphContentItem::Run(_) => None,
        }));
        self.content_order = reordered;
    }

    /// Replace all runs with the given vector of runs.
    ///
    /// Any existing runs (and their unknown children) are dropped.
    pub fn set_runs(&mut self, runs: Vec<Run>) {
        self.runs = runs;
        let mut reordered = (0..self.runs.len())
            .map(ParagraphContentItem::Run)
            .collect::<Vec<_>>();
        reordered.extend(self.content_order.iter().filter_map(|item| match item {
            ParagraphContentItem::UnknownChild(index) => {
                Some(ParagraphContentItem::UnknownChild(*index))
            }
            ParagraphContentItem::CommentRangeStart(id) => {
                Some(ParagraphContentItem::CommentRangeStart(*id))
            }
            ParagraphContentItem::CommentRangeEnd(id) => {
                Some(ParagraphContentItem::CommentRangeEnd(*id))
            }
            ParagraphContentItem::CommentReference(id) => {
                Some(ParagraphContentItem::CommentReference(*id))
            }
            ParagraphContentItem::Run(_) => None,
        }));
        self.content_order = reordered;
    }

    /// Heading level when this paragraph is a heading.
    pub fn heading_level(&self) -> Option<u8> {
        self.heading_level
    }

    pub(crate) fn set_heading_level(&mut self, heading_level: Option<u8>) {
        self.heading_level = heading_level.map(|level| level.clamp(1, 9));
    }

    /// Paragraph style identifier (`w:pStyle`).
    pub fn style_id(&self) -> Option<&str> {
        self.style_id.as_deref()
    }

    /// Set paragraph style identifier (`w:pStyle`).
    pub fn set_style_id(&mut self, style_id: impl Into<String>) {
        let style_id = style_id.into();
        let trimmed = style_id.trim();
        self.style_id = if trimmed.is_empty() {
            None
        } else {
            Some(trimmed.to_string())
        };
    }

    /// Clear paragraph style identifier.
    pub fn clear_style_id(&mut self) {
        self.style_id = None;
    }

    pub(crate) fn set_style_id_option(&mut self, style_id: Option<String>) {
        self.style_id = style_id.and_then(|value| {
            let trimmed = value.trim();
            if trimmed.is_empty() {
                None
            } else {
                Some(trimmed.to_string())
            }
        });
    }

    /// Paragraph alignment.
    pub fn alignment(&self) -> Option<ParagraphAlignment> {
        self.alignment
    }

    /// Set paragraph alignment.
    pub fn set_alignment(&mut self, alignment: ParagraphAlignment) {
        self.alignment = Some(alignment);
    }

    /// Clear paragraph alignment.
    pub fn clear_alignment(&mut self) {
        self.alignment = None;
    }

    /// Spacing before paragraph, in twips.
    pub fn spacing_before_twips(&self) -> Option<u32> {
        self.spacing_before_twips
    }

    /// Set spacing before paragraph, in twips.
    pub fn set_spacing_before_twips(&mut self, value: u32) {
        self.spacing_before_twips = Some(value);
    }

    /// Clear spacing before paragraph.
    pub fn clear_spacing_before_twips(&mut self) {
        self.spacing_before_twips = None;
    }

    /// Spacing after paragraph, in twips.
    pub fn spacing_after_twips(&self) -> Option<u32> {
        self.spacing_after_twips
    }

    /// Set spacing after paragraph, in twips.
    pub fn set_spacing_after_twips(&mut self, value: u32) {
        self.spacing_after_twips = Some(value);
    }

    /// Clear spacing after paragraph.
    pub fn clear_spacing_after_twips(&mut self) {
        self.spacing_after_twips = None;
    }

    /// Line spacing for this paragraph, in twips.
    pub fn line_spacing_twips(&self) -> Option<u32> {
        self.line_spacing_twips
    }

    /// Set line spacing, in twips.
    pub fn set_line_spacing_twips(&mut self, value: u32) {
        self.line_spacing_twips = Some(value);
    }

    /// Clear line spacing.
    pub fn clear_line_spacing_twips(&mut self) {
        self.line_spacing_twips = None;
    }

    /// Line spacing rule (`w:lineRule` attribute on `w:spacing`).
    /// Controls how the `line_spacing_twips` value is interpreted.
    pub fn line_spacing_rule(&self) -> Option<LineSpacingRule> {
        self.line_spacing_rule
    }

    /// Set line spacing rule.
    pub fn set_line_spacing_rule(&mut self, rule: LineSpacingRule) {
        self.line_spacing_rule = Some(rule);
    }

    /// Clear line spacing rule (use default).
    pub fn clear_line_spacing_rule(&mut self) {
        self.line_spacing_rule = None;
    }

    /// Whether automatic spacing before paragraph is enabled (`w:beforeAutospacing`).
    pub fn before_autospacing(&self) -> Option<bool> {
        self.before_autospacing
    }

    /// Set automatic spacing before paragraph.
    pub fn set_before_autospacing(&mut self, value: bool) {
        self.before_autospacing = Some(value);
    }

    /// Clear automatic spacing before paragraph.
    pub fn clear_before_autospacing(&mut self) {
        self.before_autospacing = None;
    }

    /// Whether automatic spacing after paragraph is enabled (`w:afterAutospacing`).
    pub fn after_autospacing(&self) -> Option<bool> {
        self.after_autospacing
    }

    /// Set automatic spacing after paragraph.
    pub fn set_after_autospacing(&mut self, value: bool) {
        self.after_autospacing = Some(value);
    }

    /// Clear automatic spacing after paragraph.
    pub fn clear_after_autospacing(&mut self) {
        self.after_autospacing = None;
    }

    /// Left indentation, in twips.
    pub fn indent_left_twips(&self) -> Option<u32> {
        self.indent_left_twips
    }

    /// Set left indentation, in twips.
    pub fn set_indent_left_twips(&mut self, value: u32) {
        self.indent_left_twips = Some(value);
    }

    /// Clear left indentation.
    pub fn clear_indent_left_twips(&mut self) {
        self.indent_left_twips = None;
    }

    /// Right indentation, in twips.
    pub fn indent_right_twips(&self) -> Option<u32> {
        self.indent_right_twips
    }

    /// Set right indentation, in twips.
    pub fn set_indent_right_twips(&mut self, value: u32) {
        self.indent_right_twips = Some(value);
    }

    /// Clear right indentation.
    pub fn clear_indent_right_twips(&mut self) {
        self.indent_right_twips = None;
    }

    /// First-line indentation, in twips.
    pub fn indent_first_line_twips(&self) -> Option<u32> {
        self.indent_first_line_twips
    }

    /// Set first-line indentation, in twips.
    pub fn set_indent_first_line_twips(&mut self, value: u32) {
        self.indent_first_line_twips = Some(value);
    }

    /// Clear first-line indentation.
    pub fn clear_indent_first_line_twips(&mut self) {
        self.indent_first_line_twips = None;
    }

    /// Hanging indentation, in twips.
    pub fn indent_hanging_twips(&self) -> Option<u32> {
        self.indent_hanging_twips
    }

    /// Set hanging indentation, in twips.
    pub fn set_indent_hanging_twips(&mut self, value: u32) {
        self.indent_hanging_twips = Some(value);
    }

    /// Clear hanging indentation.
    pub fn clear_indent_hanging_twips(&mut self) {
        self.indent_hanging_twips = None;
    }

    /// Numbering definition id for this paragraph (`w:numId`).
    pub fn numbering_num_id(&self) -> Option<u32> {
        self.numbering_num_id
    }

    /// Numbering indentation level for this paragraph (`w:ilvl`).
    pub fn numbering_ilvl(&self) -> Option<u8> {
        self.numbering_ilvl
    }

    /// Set paragraph list numbering (`w:numPr`).
    pub fn set_numbering(&mut self, num_id: u32, ilvl: u8) {
        self.numbering_num_id = Some(num_id);
        self.numbering_ilvl = Some(ilvl);
    }

    /// Remove paragraph list numbering (`w:numPr`).
    pub fn clear_numbering(&mut self) {
        self.numbering_num_id = None;
        self.numbering_ilvl = None;
    }

    /// Set the bullet/numbering indentation level without changing the num ID.
    ///
    /// This is a convenience for adjusting the nesting level of an already-numbered paragraph.
    pub fn set_bullet_level(&mut self, level: u32) {
        self.numbering_ilvl = Some(level as u8);
    }

    pub(crate) fn set_numbering_num_id(&mut self, num_id: Option<u32>) {
        self.numbering_num_id = num_id;
    }

    pub(crate) fn set_numbering_ilvl(&mut self, ilvl: Option<u8>) {
        self.numbering_ilvl = ilvl;
    }

    /// Tab stops for this paragraph (`w:tabs`).
    pub fn tab_stops(&self) -> &[TabStop] {
        &self.tab_stops
    }

    /// Add a tab stop.
    pub fn add_tab_stop(&mut self, tab_stop: TabStop) {
        self.tab_stops.push(tab_stop);
    }

    /// Replace all tab stops.
    pub fn set_tab_stops(&mut self, tab_stops: Vec<TabStop>) {
        self.tab_stops = tab_stops;
    }

    /// Clear all tab stops.
    pub fn clear_tab_stops(&mut self) {
        self.tab_stops.clear();
    }

    /// Paragraph borders (`w:pBdr`).
    pub fn borders(&self) -> &ParagraphBorders {
        &self.borders
    }

    /// Mutable paragraph borders.
    pub fn borders_mut(&mut self) -> &mut ParagraphBorders {
        &mut self.borders
    }

    /// Set paragraph borders.
    pub fn set_borders(&mut self, borders: ParagraphBorders) {
        self.borders = borders;
    }

    /// Clear all paragraph borders.
    pub fn clear_borders(&mut self) {
        self.borders.clear();
    }

    /// Paragraph shading fill color (`w:shd w:fill`), uppercase hex without `#`.
    pub fn shading_color(&self) -> Option<&str> {
        self.shading_color.as_deref()
    }

    /// Set paragraph shading fill color.
    pub fn set_shading_color(&mut self, color: impl Into<String>) {
        self.shading_color = normalize_color_value(color.into().as_str());
    }

    /// Clear paragraph shading fill color.
    pub fn clear_shading_color(&mut self) {
        self.shading_color = None;
    }

    /// Paragraph shading pattern (`w:shd w:val`), e.g. `"clear"`.
    pub fn shading_pattern(&self) -> Option<&str> {
        self.shading_pattern.as_deref()
    }

    /// Set paragraph shading pattern.
    pub fn set_shading_pattern(&mut self, pattern: impl Into<String>) {
        self.shading_pattern = normalize_optional_text(pattern.into());
    }

    /// Clear paragraph shading pattern.
    pub fn clear_shading_pattern(&mut self) {
        self.shading_pattern = None;
    }

    pub(crate) fn set_shading_color_option(&mut self, color: Option<String>) {
        self.shading_color = color;
    }

    pub(crate) fn set_shading_pattern_option(&mut self, pattern: Option<String>) {
        self.shading_pattern = pattern;
    }

    /// The `w:color` attribute on paragraph shading (`w:shd`).
    ///
    /// This is the foreground/pattern color, not the fill. Returns `None` when the
    /// attribute was not present in the original XML.
    pub fn shading_color_attribute(&self) -> Option<&str> {
        self.shading_color_attribute.as_deref()
    }

    /// Set the `w:color` attribute for paragraph shading.
    pub fn set_shading_color_attribute(&mut self, color: impl Into<String>) {
        let color = color.into();
        self.shading_color_attribute = if color.trim().is_empty() {
            None
        } else {
            Some(color)
        };
    }

    /// Clear the shading `w:color` attribute (defaults to `"auto"` on serialize).
    pub fn clear_shading_color_attribute(&mut self) {
        self.shading_color_attribute = None;
    }

    pub(crate) fn set_shading_color_attribute_option(&mut self, color: Option<String>) {
        self.shading_color_attribute = color;
    }

    /// Whether this paragraph should keep with the next paragraph (`w:keepNext`).
    pub fn keep_next(&self) -> bool {
        self.keep_next
    }

    /// Set keep with next paragraph.
    pub fn set_keep_next(&mut self, keep_next: bool) {
        self.keep_next = keep_next;
    }

    /// Whether all lines of this paragraph should stay on the same page (`w:keepLines`).
    pub fn keep_lines(&self) -> bool {
        self.keep_lines
    }

    /// Set keep lines together.
    pub fn set_keep_lines(&mut self, keep_lines: bool) {
        self.keep_lines = keep_lines;
    }

    /// Whether a page break is inserted before this paragraph (`w:pageBreakBefore`).
    pub fn page_break_before(&self) -> bool {
        self.page_break_before
    }

    /// Set page break before paragraph.
    pub fn set_page_break_before(&mut self, page_break_before: bool) {
        self.page_break_before = page_break_before;
    }

    /// Whether contextual spacing is enabled for this paragraph (`w:contextualSpacing`).
    /// When true, spacing between paragraphs of the same style is suppressed.
    pub fn contextual_spacing(&self) -> bool {
        self.contextual_spacing
    }

    /// Set contextual spacing.
    pub fn set_contextual_spacing(&mut self, contextual_spacing: bool) {
        self.contextual_spacing = contextual_spacing;
    }

    /// Outline level for this paragraph (`w:outlineLvl`), values 0-9.
    /// Used to define heading levels for table-of-contents generation.
    pub fn outline_level(&self) -> Option<u8> {
        self.outline_level
    }

    /// Set outline level (clamped to 0-9).
    pub fn set_outline_level(&mut self, level: u8) {
        self.outline_level = Some(level.clamp(0, 9));
    }

    /// Clear outline level.
    pub fn clear_outline_level(&mut self) {
        self.outline_level = None;
    }

    /// Widow/orphan control for this paragraph (`w:widowControl`).
    /// `None` means use default (typically enabled), `Some(true)` enables, `Some(false)` disables.
    pub fn widow_control(&self) -> Option<bool> {
        self.widow_control
    }

    /// Set widow/orphan control.
    pub fn set_widow_control(&mut self, widow_control: bool) {
        self.widow_control = Some(widow_control);
    }

    /// Clear explicit widow/orphan control (use default).
    pub fn clear_widow_control(&mut self) {
        self.widow_control = None;
    }

    /// Whether this paragraph has bidirectional (RTL) direction (`w:bidi`).
    pub fn is_bidi(&self) -> bool {
        self.bidi
    }

    /// Set bidirectional (RTL) paragraph direction.
    pub fn set_bidi(&mut self, bidi: bool) {
        self.bidi = bidi;
    }

    /// Comment range start ids associated with this paragraph.
    pub fn comment_range_start_ids(&self) -> &[u32] {
        &self.comment_range_start_ids
    }

    /// Add a comment range start id.
    pub fn add_comment_range_start(&mut self, comment_id: u32) {
        self.comment_range_start_ids.push(comment_id);
    }

    /// Clear all comment range start ids.
    pub fn clear_comment_range_starts(&mut self) {
        self.comment_range_start_ids.clear();
    }

    /// Comment range end ids associated with this paragraph.
    pub fn comment_range_end_ids(&self) -> &[u32] {
        &self.comment_range_end_ids
    }

    /// Add a comment range end id.
    pub fn add_comment_range_end(&mut self, comment_id: u32) {
        self.comment_range_end_ids.push(comment_id);
    }

    /// Clear all comment range end ids.
    pub fn clear_comment_range_ends(&mut self) {
        self.comment_range_end_ids.clear();
    }

    /// Comment reference ids serialized as `w:commentReference` runs.
    pub fn comment_reference_ids(&self) -> &[u32] {
        &self.comment_reference_ids
    }

    /// Add a comment reference id.
    pub fn add_comment_reference(&mut self, comment_id: u32) {
        self.comment_reference_ids.push(comment_id);
    }

    /// Clear all comment reference ids.
    pub fn clear_comment_references(&mut self) {
        self.comment_reference_ids.clear();
        self.comment_reference_contexts.clear();
    }

    pub(crate) fn anchor_comment_to_char_range(
        &mut self,
        comment_id: u32,
        char_start: usize,
        char_end: usize,
    ) -> Result<(), String> {
        let total_chars = self.reviewable_text()?.chars().count();
        if char_start > char_end || char_end > total_chars {
            return Err(format!(
                "comment character range {char_start}..{char_end} is out of bounds for paragraph length {total_chars}"
            ));
        }

        if total_chars > 0 && char_start == 0 && char_end == total_chars {
            self.anchor_comment_to_full_paragraph(comment_id);
        } else {
            self.rewrite_text_range(char_start, char_end, None, Some(comment_id))?;
        }

        if !self.comment_range_start_ids.contains(&comment_id) {
            self.comment_range_start_ids.push(comment_id);
        }
        if !self.comment_range_end_ids.contains(&comment_id) {
            self.comment_range_end_ids.push(comment_id);
        }
        if !self.comment_reference_ids.contains(&comment_id) {
            self.comment_reference_ids.push(comment_id);
        }
        Ok(())
    }

    fn anchor_comment_to_full_paragraph(&mut self, comment_id: u32) {
        if !self.comment_range_start_ids.contains(&comment_id) {
            self.comment_range_start_ids.push(comment_id);
        }
        if !self.comment_range_end_ids.contains(&comment_id) {
            self.comment_range_end_ids.push(comment_id);
        }
        if !self.comment_reference_ids.contains(&comment_id) {
            self.comment_reference_ids.push(comment_id);
        }

        self.content_order
            .insert(0, ParagraphContentItem::CommentRangeStart(comment_id));
        self.content_order
            .push(ParagraphContentItem::CommentRangeEnd(comment_id));
        self.content_order
            .push(ParagraphContentItem::CommentReference(comment_id));
    }

    pub(crate) fn highlight_char_range(
        &mut self,
        char_start: usize,
        char_end: usize,
        color: &str,
    ) -> Result<(), String> {
        let total_chars = self.reviewable_text()?.chars().count();
        if char_start >= char_end || char_end > total_chars {
            return Err(format!(
                "highlight character range {char_start}..{char_end} is out of bounds for paragraph length {total_chars}"
            ));
        }

        self.rewrite_text_range(char_start, char_end, Some(color), None)
    }

    pub(crate) fn reviewable_text(&self) -> Result<String, String> {
        let mut text = String::new();

        for item in &self.content_order {
            match item {
                ParagraphContentItem::Run(index) => {
                    let run = self.runs.get(*index).ok_or_else(|| {
                        format!("paragraph content references missing run at index {index}")
                    })?;
                    ensure_run_supports_text_range_ops(run)?;
                    text.push_str(run_reviewable_text(run)?.as_str());
                }
                ParagraphContentItem::UnknownChild(index) => {
                    let node = self.unknown_children.get(*index).ok_or_else(|| {
                        format!(
                            "paragraph content references missing unknown child at index {index}"
                        )
                    })?;
                    text.push_str(extract_supported_unknown_child_text(node)?.as_str());
                }
                ParagraphContentItem::CommentRangeStart(_)
                | ParagraphContentItem::CommentRangeEnd(_)
                | ParagraphContentItem::CommentReference(_) => {}
            }
        }

        Ok(text)
    }

    pub(crate) fn reviewable_text_char_range(
        &self,
        target_text: &str,
    ) -> Result<Option<(usize, usize)>, String> {
        let text = self.reviewable_text()?;
        Ok(find_text_char_range_in_string(text.as_str(), target_text))
    }

    pub(crate) fn can_rewrite_supported_textbox_compare(
        &self,
        prefix: &str,
        deleted: &str,
        inserted: &str,
        suffix: &str,
    ) -> bool {
        let Some(run_index) = self.supported_textbox_compare_run_index() else {
            return false;
        };
        let Some(run) = self.runs.get(run_index) else {
            return false;
        };
        let dummy_deleted = RevisionMetadata::new(0, "");
        let dummy_inserted = RevisionMetadata::new(0, "");
        rewrite_textbox_compare_unknown_child(
            run.unknown_children(),
            prefix,
            (!deleted.is_empty()).then_some((deleted, &dummy_deleted)),
            (!inserted.is_empty()).then_some((inserted, &dummy_inserted)),
            suffix,
        )
        .is_ok()
    }

    pub(crate) fn rewrite_supported_textbox_compare(
        &mut self,
        prefix: &str,
        deleted: Option<(&str, &RevisionMetadata)>,
        inserted: Option<(&str, &RevisionMetadata)>,
        suffix: &str,
    ) -> Result<bool, String> {
        let Some(run_index) = self.supported_textbox_compare_run_index() else {
            return Ok(false);
        };
        let Some(run) = self.runs.get_mut(run_index) else {
            return Ok(false);
        };
        let rewritten = rewrite_textbox_compare_unknown_child(
            run.unknown_children(),
            prefix,
            deleted,
            inserted,
            suffix,
        )?;
        run.set_unknown_children(vec![rewritten]);
        Ok(true)
    }

    pub(crate) fn can_rewrite_supported_plain_compare(
        &self,
        prefix: &str,
        inserted: &str,
        suffix: &str,
    ) -> bool {
        if !self.unknown_children.is_empty()
            || !self.comment_range_start_ids.is_empty()
            || !self.comment_range_end_ids.is_empty()
            || !self.comment_reference_ids.is_empty()
            || !self.comment_reference_contexts.is_empty()
        {
            return false;
        }
        if self
            .content_order
            .iter()
            .any(|item| !matches!(item, ParagraphContentItem::Run(_)))
        {
            return false;
        }
        if self.text() != [prefix, inserted, suffix].concat() {
            return false;
        }
        self.runs.iter().all(run_supports_plain_compare_rewrite)
    }

    pub(crate) fn rewrite_supported_plain_compare(
        &mut self,
        prefix: &str,
        deleted: Option<(&str, &RevisionMetadata)>,
        inserted: Option<(&str, &RevisionMetadata)>,
        suffix: &str,
    ) -> Result<bool, String> {
        if !self.can_rewrite_supported_plain_compare(
            prefix,
            inserted.map_or("", |(text, _)| text),
            suffix,
        ) {
            return Ok(false);
        }

        let paragraph_text = self.text();
        let change_start = prefix.chars().count();
        let paragraph_len = paragraph_text.chars().count();
        let suffix_len = suffix.chars().count();
        if change_start > paragraph_len || suffix_len > paragraph_len {
            return Ok(false);
        }
        let change_end = paragraph_len.saturating_sub(suffix_len);
        if change_start > change_end {
            return Ok(false);
        }

        let original_runs = self.runs.clone();
        let original_content_order = self.content_order.clone();
        let mut new_runs = Vec::new();
        let mut new_unknown_children = Vec::new();
        let mut new_content_order = Vec::new();

        append_plain_compare_range_content(
            &original_runs,
            &original_content_order,
            0,
            change_start,
            &mut new_runs,
            &mut new_content_order,
        )?;
        let deleted_template_run = deleted
            .and_then(|(text, _)| (!text.is_empty()).then_some(()))
            .and_then(|_| {
                find_run_for_compare_boundary(&original_runs, &original_content_order, change_start)
            });
        if let Some((deleted_text, metadata)) = deleted {
            if !deleted_text.is_empty() {
                new_unknown_children.push(deleted_template_run.map_or_else(
                    || build_deleted_text_node(deleted_text, metadata),
                    |run| build_formatted_deleted_text_node(run, deleted_text, metadata),
                ));
                new_content_order.push(ParagraphContentItem::UnknownChild(
                    new_unknown_children.len().saturating_sub(1),
                ));
            }
        }
        let inserted_template_run = inserted
            .and_then(|(text, _)| (!text.is_empty()).then_some(()))
            .and_then(|_| {
                find_run_for_compare_boundary(&original_runs, &original_content_order, change_start)
            });
        if let Some((inserted_text, metadata)) = inserted {
            if !inserted_text.is_empty() {
                new_unknown_children.push(inserted_template_run.map_or_else(
                    || build_inserted_text_node(inserted_text, metadata),
                    |run| build_formatted_inserted_text_node(run, inserted_text, metadata),
                ));
                new_content_order.push(ParagraphContentItem::UnknownChild(
                    new_unknown_children.len().saturating_sub(1),
                ));
            }
        }
        append_plain_compare_range_content(
            &original_runs,
            &original_content_order,
            change_end,
            paragraph_len,
            &mut new_runs,
            &mut new_content_order,
        )?;

        if new_runs.is_empty() && new_unknown_children.is_empty() {
            new_runs.push(Run::new(""));
            new_content_order.push(ParagraphContentItem::Run(0));
        }

        self.runs = new_runs;
        self.unknown_children = new_unknown_children;
        self.content_order = new_content_order;
        self.comment_range_start_ids.clear();
        self.comment_range_end_ids.clear();
        self.comment_reference_ids.clear();
        self.comment_reference_contexts.clear();
        Ok(true)
    }

    fn supported_textbox_compare_run_index(&self) -> Option<usize> {
        if !self.unknown_children.is_empty() {
            return None;
        }

        let mut supported_run_index = None;
        for (run_index, run) in self.runs.iter().enumerate() {
            let is_supported_textbox_run = run.field_code().is_none()
                && run.field_simple().is_none()
                && extract_supported_textbox_run_text(run).is_ok();
            if is_supported_textbox_run {
                if supported_run_index.is_some() {
                    return None;
                }
                supported_run_index = Some(run_index);
                continue;
            }

            if !run.text().is_empty()
                || run.field_code().is_some()
                || run.field_simple().is_some()
                || run.inline_image().is_some()
                || run.floating_image().is_some()
                || run.footnote_reference_id().is_some()
                || run.endnote_reference_id().is_some()
                || run.has_tab()
                || run.has_break()
                || !run.unknown_children().is_empty()
                || !run.unknown_property_children().is_empty()
            {
                return None;
            }
        }

        supported_run_index
    }

    fn rewrite_text_range(
        &mut self,
        char_start: usize,
        char_end: usize,
        highlight_color: Option<&str>,
        comment_id: Option<u32>,
    ) -> Result<(), String> {
        let old_runs = self.runs.clone();
        let old_unknown_children = self.unknown_children.clone();
        let old_content_order = self.content_order.clone();

        let mut new_runs = Vec::new();
        let mut new_unknown_children = Vec::new();
        let mut new_content_order = Vec::new();
        let mut global_cursor = 0_usize;
        let mut inserted_start = false;
        let mut inserted_end = false;

        for item in old_content_order {
            match item {
                ParagraphContentItem::Run(index) => {
                    let run = old_runs.get(index).ok_or_else(|| {
                        format!("paragraph content references missing run at index {index}")
                    })?;
                    ensure_run_supports_text_range_ops(run)?;
                    rewrite_run_segments(
                        run,
                        &mut new_runs,
                        &mut new_content_order,
                        &mut global_cursor,
                        char_start,
                        char_end,
                        highlight_color,
                        comment_id,
                        &mut inserted_start,
                        &mut inserted_end,
                    )?;
                }
                ParagraphContentItem::UnknownChild(index) => {
                    let node = old_unknown_children.get(index).ok_or_else(|| {
                        format!(
                            "paragraph content references missing unknown child at index {index}"
                        )
                    })?;
                    rewrite_unknown_child_segments(
                        node,
                        &mut new_unknown_children,
                        &mut new_content_order,
                        &mut global_cursor,
                        char_start,
                        char_end,
                        highlight_color,
                        comment_id,
                        &mut inserted_start,
                        &mut inserted_end,
                    )?;
                }
                ParagraphContentItem::CommentRangeStart(existing_comment_id) => {
                    if let Some(comment_id) = comment_id {
                        insert_comment_end_markers_at_boundary(
                            &mut new_content_order,
                            &global_cursor,
                            char_end,
                            comment_id,
                            &mut inserted_start,
                            &mut inserted_end,
                        );
                    }
                    new_content_order
                        .push(ParagraphContentItem::CommentRangeStart(existing_comment_id));
                    if let Some(comment_id) = comment_id {
                        insert_comment_start_markers_at_boundary(
                            &mut new_content_order,
                            &global_cursor,
                            char_start,
                            char_end,
                            comment_id,
                            &mut inserted_start,
                            &mut inserted_end,
                        );
                    }
                }
                ParagraphContentItem::CommentRangeEnd(existing_comment_id) => {
                    if let Some(comment_id) = comment_id {
                        insert_comment_end_markers_at_boundary(
                            &mut new_content_order,
                            &global_cursor,
                            char_end,
                            comment_id,
                            &mut inserted_start,
                            &mut inserted_end,
                        );
                    }
                    new_content_order
                        .push(ParagraphContentItem::CommentRangeEnd(existing_comment_id));
                    if let Some(comment_id) = comment_id {
                        insert_comment_start_markers_at_boundary(
                            &mut new_content_order,
                            &global_cursor,
                            char_start,
                            char_end,
                            comment_id,
                            &mut inserted_start,
                            &mut inserted_end,
                        );
                    }
                }
                ParagraphContentItem::CommentReference(existing_comment_id) => {
                    if let Some(comment_id) = comment_id {
                        insert_comment_end_markers_at_boundary(
                            &mut new_content_order,
                            &global_cursor,
                            char_end,
                            comment_id,
                            &mut inserted_start,
                            &mut inserted_end,
                        );
                    }
                    new_content_order
                        .push(ParagraphContentItem::CommentReference(existing_comment_id));
                    if let Some(comment_id) = comment_id {
                        insert_comment_start_markers_at_boundary(
                            &mut new_content_order,
                            &global_cursor,
                            char_start,
                            char_end,
                            comment_id,
                            &mut inserted_start,
                            &mut inserted_end,
                        );
                    }
                }
            }
        }

        if let Some(comment_id) = comment_id {
            if !inserted_start && char_start == global_cursor {
                new_content_order.push(ParagraphContentItem::CommentRangeStart(comment_id));
                inserted_start = true;
                if char_start == char_end && !inserted_end {
                    new_content_order.push(ParagraphContentItem::CommentRangeEnd(comment_id));
                    new_content_order.push(ParagraphContentItem::CommentReference(comment_id));
                    inserted_end = true;
                }
            }
            if inserted_start && !inserted_end && char_end == global_cursor {
                new_content_order.push(ParagraphContentItem::CommentRangeEnd(comment_id));
                new_content_order.push(ParagraphContentItem::CommentReference(comment_id));
                inserted_end = true;
            }
            if !inserted_start || !inserted_end {
                return Err(
                    "failed to place comment markers at requested character range".to_string(),
                );
            }
        }

        self.runs = new_runs;
        self.unknown_children = new_unknown_children;
        self.content_order = new_content_order;
        Ok(())
    }

    pub(crate) fn ordered_comment_markers_present(&self) -> bool {
        self.content_order.iter().any(|item| {
            matches!(
                item,
                ParagraphContentItem::CommentRangeStart(_)
                    | ParagraphContentItem::CommentRangeEnd(_)
                    | ParagraphContentItem::CommentReference(_)
            )
        })
    }

    /// Section properties attached to this paragraph (for section breaks).
    /// When present, this paragraph is the last paragraph of a non-final section.
    pub fn section_properties(&self) -> Option<&crate::section::Section> {
        self.section_properties.as_deref()
    }

    /// Set section properties for this paragraph (creating a section break).
    pub fn set_section_properties(&mut self, section: crate::section::Section) {
        self.section_properties = Some(Box::new(section));
    }

    /// Clear section properties from this paragraph.
    pub fn clear_section_properties(&mut self) {
        self.section_properties = None;
    }

    #[allow(dead_code)]
    pub(crate) fn set_section_properties_option(
        &mut self,
        section: Option<crate::section::Section>,
    ) {
        self.section_properties = section.map(Box::new);
    }

    pub(crate) fn has_properties(&self) -> bool {
        self.heading_level.is_some()
            || self.style_id.is_some()
            || self.alignment.is_some()
            || self.spacing_before_twips.is_some()
            || self.spacing_after_twips.is_some()
            || self.line_spacing_twips.is_some()
            || self.indent_left_twips.is_some()
            || self.indent_right_twips.is_some()
            || self.indent_first_line_twips.is_some()
            || self.indent_hanging_twips.is_some()
            || self.numbering_num_id.is_some()
            || self.numbering_ilvl.is_some()
            || !self.tab_stops.is_empty()
            || !self.borders.is_empty()
            || self.shading_color.is_some()
            || self.line_spacing_rule.is_some()
            || self.before_autospacing.is_some()
            || self.after_autospacing.is_some()
            || self.keep_next
            || self.keep_lines
            || self.page_break_before
            || self.contextual_spacing
            || self.widow_control.is_some()
            || self.outline_level.is_some()
            || self.bidi
            || self.section_properties.is_some()
            || !self.unknown_property_children.is_empty()
    }

    pub(crate) fn content_order(&self) -> &[ParagraphContentItem] {
        self.content_order.as_slice()
    }

    pub(crate) fn unknown_children(&self) -> &[RawXmlNode] {
        self.unknown_children.as_slice()
    }

    pub(crate) fn push_comment_range_start_marker(&mut self, comment_id: u32) {
        self.comment_range_start_ids.push(comment_id);
        self.content_order
            .push(ParagraphContentItem::CommentRangeStart(comment_id));
    }

    pub(crate) fn push_comment_range_end_marker(&mut self, comment_id: u32) {
        self.comment_range_end_ids.push(comment_id);
        self.content_order
            .push(ParagraphContentItem::CommentRangeEnd(comment_id));
    }

    pub(crate) fn push_comment_reference_marker(&mut self, comment_id: u32) {
        self.comment_reference_ids.push(comment_id);
        self.content_order
            .push(ParagraphContentItem::CommentReference(comment_id));
    }

    pub(crate) fn push_comment_reference_marker_with_context(&mut self, comment_id: u32, run: Run) {
        self.comment_reference_ids.push(comment_id);
        self.comment_reference_contexts
            .retain(|context| context.id != comment_id);
        self.comment_reference_contexts
            .push(CommentReferenceContext {
                id: comment_id,
                run,
            });
        self.content_order
            .push(ParagraphContentItem::CommentReference(comment_id));
    }

    pub(crate) fn prepend_unknown_child(&mut self, node: RawXmlNode) {
        self.unknown_children.push(node);
        let idx = self.unknown_children.len().saturating_sub(1);
        self.content_order
            .insert(0, ParagraphContentItem::UnknownChild(idx));
    }

    pub(crate) fn push_unknown_child(&mut self, node: RawXmlNode) {
        self.unknown_children.push(node);
        let idx = self.unknown_children.len().saturating_sub(1);
        self.content_order
            .push(ParagraphContentItem::UnknownChild(idx));
    }

    pub(crate) fn comment_reference_run(&self, comment_id: u32) -> Option<&Run> {
        self.comment_reference_contexts
            .iter()
            .rev()
            .find(|context| context.id == comment_id)
            .map(|context| &context.run)
    }

    pub(crate) fn extra_attributes(&self) -> &[(String, String)] {
        self.extra_attributes.as_slice()
    }

    pub(crate) fn set_extra_attributes(&mut self, attributes: Vec<(String, String)>) {
        self.extra_attributes = attributes;
    }

    pub(crate) fn unknown_property_children(&self) -> &[RawXmlNode] {
        self.unknown_property_children.as_slice()
    }

    pub(crate) fn set_unknown_property_children(&mut self, children: Vec<RawXmlNode>) {
        self.unknown_property_children = children;
    }

    pub(crate) fn replace_properties_with_raw_children(&mut self, children: Vec<RawXmlNode>) {
        let defaults = Self::default();
        self.heading_level = defaults.heading_level;
        self.style_id = defaults.style_id;
        self.alignment = defaults.alignment;
        self.spacing_before_twips = defaults.spacing_before_twips;
        self.spacing_after_twips = defaults.spacing_after_twips;
        self.line_spacing_twips = defaults.line_spacing_twips;
        self.indent_left_twips = defaults.indent_left_twips;
        self.indent_right_twips = defaults.indent_right_twips;
        self.indent_first_line_twips = defaults.indent_first_line_twips;
        self.indent_hanging_twips = defaults.indent_hanging_twips;
        self.numbering_num_id = defaults.numbering_num_id;
        self.numbering_ilvl = defaults.numbering_ilvl;
        self.tab_stops = defaults.tab_stops;
        self.borders = defaults.borders;
        self.shading_color = defaults.shading_color;
        self.shading_pattern = defaults.shading_pattern;
        self.shading_color_attribute = defaults.shading_color_attribute;
        self.line_spacing_rule = defaults.line_spacing_rule;
        self.before_autospacing = defaults.before_autospacing;
        self.after_autospacing = defaults.after_autospacing;
        self.keep_next = defaults.keep_next;
        self.keep_lines = defaults.keep_lines;
        self.page_break_before = defaults.page_break_before;
        self.contextual_spacing = defaults.contextual_spacing;
        self.widow_control = defaults.widow_control;
        self.outline_level = defaults.outline_level;
        self.bidi = defaults.bidi;
        self.section_properties = defaults.section_properties;
        self.unknown_property_children = children;
    }

    pub(crate) fn push_unknown_property_child(&mut self, node: RawXmlNode) {
        self.unknown_property_children.push(node);
    }

    pub(crate) fn clear_content_for_rewrite(&mut self) {
        self.runs.clear();
        self.content_order.clear();
        self.unknown_children.clear();
        self.comment_range_start_ids.clear();
        self.comment_range_end_ids.clear();
        self.comment_reference_ids.clear();
        self.comment_reference_contexts.clear();
    }

    pub(crate) fn transform_unknown_children<F>(&mut self, mut transform: F)
    where
        F: FnMut(RawXmlNode) -> Vec<RawXmlNode>,
    {
        let old_unknown_children = std::mem::take(&mut self.unknown_children);
        let old_content_order = std::mem::take(&mut self.content_order);

        let mut remapped_indices = Vec::with_capacity(old_unknown_children.len());
        for node in old_unknown_children {
            let mut replacement_indices = Vec::new();
            for replacement in transform(node) {
                self.unknown_children.push(replacement);
                replacement_indices.push(self.unknown_children.len().saturating_sub(1));
            }
            remapped_indices.push(replacement_indices);
        }

        let mut new_content_order = Vec::with_capacity(old_content_order.len());
        for item in old_content_order {
            match item {
                ParagraphContentItem::Run(index) => {
                    new_content_order.push(ParagraphContentItem::Run(index));
                }
                ParagraphContentItem::UnknownChild(index) => {
                    if let Some(indices) = remapped_indices.get(index) {
                        for new_index in indices {
                            new_content_order.push(ParagraphContentItem::UnknownChild(*new_index));
                        }
                    }
                }
                ParagraphContentItem::CommentRangeStart(id) => {
                    new_content_order.push(ParagraphContentItem::CommentRangeStart(id));
                }
                ParagraphContentItem::CommentRangeEnd(id) => {
                    new_content_order.push(ParagraphContentItem::CommentRangeEnd(id));
                }
                ParagraphContentItem::CommentReference(id) => {
                    new_content_order.push(ParagraphContentItem::CommentReference(id));
                }
            }
        }
        self.content_order = new_content_order;
    }

    /// Concatenated plain text for this paragraph.
    pub fn text(&self) -> String {
        let mut text = String::new();
        for run in &self.runs {
            text.push_str(run.text());
        }
        text
    }
}

fn ensure_run_supports_text_range_ops(run: &Run) -> Result<(), String> {
    if run.inline_image().is_some()
        || run.floating_image().is_some()
        || run.footnote_reference_id().is_some()
        || run.endnote_reference_id().is_some()
        || run.field_simple().is_some()
        || run.has_tab()
        || run.has_break()
        || !run.unknown_property_children().is_empty()
    {
        return Err(
            "cannot add character-level review markup to paragraph with non-text runs".to_string(),
        );
    }

    if !run.unknown_children().is_empty() {
        if !run.text().is_empty() || run.field_code().is_some() {
            return Err(
                "cannot add character-level review markup to paragraph with mixed raw-XML and text runs"
                    .to_string(),
            );
        }
        extract_supported_textbox_run_text(run)?;
    }

    Ok(())
}

fn run_supports_plain_compare_rewrite(run: &Run) -> bool {
    run.inline_image().is_none()
        && run.floating_image().is_none()
        && run.footnote_reference_id().is_none()
        && run.endnote_reference_id().is_none()
        && run.field_simple().is_none()
        && run.field_code().is_none()
        && !run.has_tab()
        && !run.has_break()
        && run.unknown_children().is_empty()
}

fn find_run_for_compare_boundary<'a>(
    runs: &'a [Run],
    content_order: &[ParagraphContentItem],
    char_offset: usize,
) -> Option<&'a Run> {
    let mut cursor = 0_usize;
    let mut last_run = None;
    for item in content_order {
        let ParagraphContentItem::Run(index) = item else {
            continue;
        };
        let run = runs.get(*index)?;
        let run_len = run.text().chars().count();
        if run_len == 0 {
            last_run = Some(run);
            continue;
        }
        let run_end = cursor.saturating_add(run_len);
        if (cursor..=run_end).contains(&char_offset) {
            return Some(run);
        }
        cursor = run_end;
        last_run = Some(run);
    }
    last_run
}

fn build_formatted_inserted_text_node(
    run: &Run,
    text: &str,
    metadata: &RevisionMetadata,
) -> RawXmlNode {
    build_formatted_revision_text_node(run, "w:ins", "w:t", text, metadata)
}

fn build_formatted_deleted_text_node(
    run: &Run,
    text: &str,
    metadata: &RevisionMetadata,
) -> RawXmlNode {
    build_formatted_revision_text_node(run, "w:del", "w:delText", text, metadata)
}

fn build_formatted_revision_text_node(
    run: &Run,
    revision_name: &str,
    text_name: &str,
    text: &str,
    metadata: &RevisionMetadata,
) -> RawXmlNode {
    let mut revision_attributes = vec![
        ("w:id".to_string(), metadata.id.to_string()),
        ("w:author".to_string(), metadata.author.clone()),
    ];
    if let Some(date) = &metadata.date {
        revision_attributes.push(("w:date".to_string(), date.clone()));
    }

    let mut run_children = Vec::new();
    if let Some(rpr) = build_run_properties_node(run) {
        run_children.push(rpr);
    }
    let mut text_attributes = Vec::new();
    if text.starts_with(char::is_whitespace) || text.ends_with(char::is_whitespace) {
        text_attributes.push(("xml:space".to_string(), "preserve".to_string()));
    }
    run_children.push(RawXmlNode::Element {
        name: text_name.to_string(),
        attributes: text_attributes,
        children: vec![RawXmlNode::Text(text.to_string())],
    });

    RawXmlNode::Element {
        name: revision_name.to_string(),
        attributes: revision_attributes,
        children: vec![RawXmlNode::Element {
            name: "w:r".to_string(),
            attributes: run.extra_attributes().to_vec(),
            children: run_children,
        }],
    }
}

fn build_run_properties_node(run: &Run) -> Option<RawXmlNode> {
    let mut children = Vec::new();

    if let Some(style_id) = run.style_id() {
        children.push(RawXmlNode::Element {
            name: "w:rStyle".to_string(),
            attributes: vec![("w:val".to_string(), style_id.to_string())],
            children: Vec::new(),
        });
    }

    let has_font = run.font_family_ascii().is_some()
        || run.font_family_h_ansi().is_some()
        || run.font_family_cs().is_some()
        || run.font_family_east_asia().is_some()
        || run.font_family().is_some();
    if has_font {
        let fallback = run.font_family();
        let mut attributes = Vec::new();
        if let Some(value) = run.font_family_ascii().or(fallback) {
            attributes.push(("w:ascii".to_string(), value.to_string()));
        }
        if let Some(value) = run.font_family_h_ansi().or(fallback) {
            attributes.push(("w:hAnsi".to_string(), value.to_string()));
        }
        if let Some(value) = run.font_family_cs().or(fallback) {
            attributes.push(("w:cs".to_string(), value.to_string()));
        }
        if let Some(value) = run.font_family_east_asia() {
            attributes.push(("w:eastAsia".to_string(), value.to_string()));
        }
        children.push(RawXmlNode::Element {
            name: "w:rFonts".to_string(),
            attributes,
            children: Vec::new(),
        });
    }

    if run.is_bold() {
        children.push(RawXmlNode::Element {
            name: "w:b".to_string(),
            attributes: Vec::new(),
            children: Vec::new(),
        });
    }
    if run.is_italic() {
        children.push(RawXmlNode::Element {
            name: "w:i".to_string(),
            attributes: Vec::new(),
            children: Vec::new(),
        });
    }
    if run.is_all_caps() {
        children.push(RawXmlNode::Element {
            name: "w:caps".to_string(),
            attributes: Vec::new(),
            children: Vec::new(),
        });
    }
    if run.is_small_caps() {
        children.push(RawXmlNode::Element {
            name: "w:smallCaps".to_string(),
            attributes: Vec::new(),
            children: Vec::new(),
        });
    }
    if run.is_strikethrough() {
        children.push(RawXmlNode::Element {
            name: "w:strike".to_string(),
            attributes: Vec::new(),
            children: Vec::new(),
        });
    }
    if run.is_double_strikethrough() {
        children.push(RawXmlNode::Element {
            name: "w:dstrike".to_string(),
            attributes: Vec::new(),
            children: Vec::new(),
        });
    }
    if run.is_outline() {
        children.push(RawXmlNode::Element {
            name: "w:outline".to_string(),
            attributes: Vec::new(),
            children: Vec::new(),
        });
    }
    if run.is_shadow() {
        children.push(RawXmlNode::Element {
            name: "w:shadow".to_string(),
            attributes: Vec::new(),
            children: Vec::new(),
        });
    }
    if run.is_emboss() {
        children.push(RawXmlNode::Element {
            name: "w:emboss".to_string(),
            attributes: Vec::new(),
            children: Vec::new(),
        });
    }
    if run.is_imprint() {
        children.push(RawXmlNode::Element {
            name: "w:imprint".to_string(),
            attributes: Vec::new(),
            children: Vec::new(),
        });
    }
    if run.is_hidden() {
        children.push(RawXmlNode::Element {
            name: "w:vanish".to_string(),
            attributes: Vec::new(),
            children: Vec::new(),
        });
    }
    if run.color().is_some() || run.theme_color().is_some() {
        let mut attributes = Vec::new();
        if let Some(value) = run.color() {
            attributes.push(("w:val".to_string(), value.to_string()));
        }
        if let Some(value) = run.theme_color() {
            attributes.push(("w:themeColor".to_string(), value.to_string()));
        }
        if let Some(value) = run.theme_shade() {
            attributes.push(("w:themeShade".to_string(), value.to_string()));
        }
        if let Some(value) = run.theme_tint() {
            attributes.push(("w:themeTint".to_string(), value.to_string()));
        }
        children.push(RawXmlNode::Element {
            name: "w:color".to_string(),
            attributes,
            children: Vec::new(),
        });
    }
    if let Some(value) = run.character_spacing_twips() {
        children.push(RawXmlNode::Element {
            name: "w:spacing".to_string(),
            attributes: vec![("w:val".to_string(), value.to_string())],
            children: Vec::new(),
        });
    }
    if let Some(value) = run.font_size_half_points() {
        children.push(RawXmlNode::Element {
            name: "w:sz".to_string(),
            attributes: vec![("w:val".to_string(), value.to_string())],
            children: Vec::new(),
        });
    }
    if let Some(value) = run.highlight_color() {
        children.push(RawXmlNode::Element {
            name: "w:highlight".to_string(),
            attributes: vec![("w:val".to_string(), value.to_string())],
            children: Vec::new(),
        });
    }
    if let Some(value) = run.underline_type() {
        let underline_value = match value {
            UnderlineType::Single => "single",
            UnderlineType::Double => "double",
            UnderlineType::Thick => "thick",
            UnderlineType::Dotted => "dotted",
            UnderlineType::DottedHeavy => "dottedHeavy",
            UnderlineType::Dash => "dash",
            UnderlineType::DashedHeavy => "dashedHeavy",
            UnderlineType::DashLong => "dashLong",
            UnderlineType::DashLongHeavy => "dashLongHeavy",
            UnderlineType::DashDot => "dotDash",
            UnderlineType::DashDotHeavy => "dashDotHeavy",
            UnderlineType::DashDotDot => "dotDotDash",
            UnderlineType::DashDotDotHeavy => "dashDotDotHeavy",
            UnderlineType::Wavy => "wave",
            UnderlineType::WavyHeavy => "wavyHeavy",
            UnderlineType::WavyDouble => "wavyDouble",
            UnderlineType::Words => "words",
        };
        children.push(RawXmlNode::Element {
            name: "w:u".to_string(),
            attributes: vec![("w:val".to_string(), underline_value.to_string())],
            children: Vec::new(),
        });
    }
    if run.is_subscript() {
        children.push(RawXmlNode::Element {
            name: "w:vertAlign".to_string(),
            attributes: vec![("w:val".to_string(), "subscript".to_string())],
            children: Vec::new(),
        });
    } else if run.is_superscript() {
        children.push(RawXmlNode::Element {
            name: "w:vertAlign".to_string(),
            attributes: vec![("w:val".to_string(), "superscript".to_string())],
            children: Vec::new(),
        });
    }
    if run.is_rtl() {
        children.push(RawXmlNode::Element {
            name: "w:rtl".to_string(),
            attributes: Vec::new(),
            children: Vec::new(),
        });
    }
    children.extend(run.unknown_property_children().iter().cloned());

    (!children.is_empty()).then_some(RawXmlNode::Element {
        name: "w:rPr".to_string(),
        attributes: Vec::new(),
        children,
    })
}

fn append_plain_compare_range_content(
    runs: &[Run],
    content_order: &[ParagraphContentItem],
    range_start: usize,
    range_end: usize,
    new_runs: &mut Vec<Run>,
    new_content_order: &mut Vec<ParagraphContentItem>,
) -> Result<(), String> {
    if range_start >= range_end {
        return Ok(());
    }

    let mut global_cursor = 0_usize;
    for item in content_order {
        let ParagraphContentItem::Run(index) = item else {
            return Err("unsupported paragraph content for compare rewrite".to_string());
        };
        let run = runs
            .get(*index)
            .ok_or_else(|| format!("paragraph content references missing run at index {index}"))?;
        if !run_supports_plain_compare_rewrite(run) {
            return Err("unsupported run for compare rewrite".to_string());
        }
        let run_text = run.text();
        let run_len = run_text.chars().count();
        if run_len == 0 {
            continue;
        }

        let overlap_start = range_start.max(global_cursor);
        let overlap_end = range_end.min(global_cursor.saturating_add(run_len));
        if overlap_start < overlap_end {
            let local_start = overlap_start.saturating_sub(global_cursor);
            let local_end = overlap_end.saturating_sub(global_cursor);
            let segment_text = run_text
                .chars()
                .skip(local_start)
                .take(local_end.saturating_sub(local_start))
                .collect::<String>();
            let mut segment_run = run.clone();
            segment_run.set_text(segment_text);
            new_runs.push(segment_run);
            new_content_order.push(ParagraphContentItem::Run(new_runs.len().saturating_sub(1)));
        }
        global_cursor = global_cursor.saturating_add(run_len);
    }

    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn rewrite_run_segments(
    run: &Run,
    new_runs: &mut Vec<Run>,
    new_content_order: &mut Vec<ParagraphContentItem>,
    global_cursor: &mut usize,
    char_start: usize,
    char_end: usize,
    highlight_color: Option<&str>,
    comment_id: Option<u32>,
    inserted_start: &mut bool,
    inserted_end: &mut bool,
) -> Result<(), String> {
    if !run.unknown_children().is_empty() {
        return rewrite_textbox_run_segments(
            run,
            new_runs,
            new_content_order,
            global_cursor,
            char_start,
            char_end,
            highlight_color,
            comment_id,
            inserted_start,
            inserted_end,
        );
    }

    let run_text = run_reviewable_text(run)?;
    let run_len = run_text.chars().count();

    if let Some(comment_id) = comment_id {
        if !*inserted_start && char_start == *global_cursor {
            new_content_order.push(ParagraphContentItem::CommentRangeStart(comment_id));
            *inserted_start = true;
            if char_start == char_end && !*inserted_end {
                new_content_order.push(ParagraphContentItem::CommentRangeEnd(comment_id));
                new_content_order.push(ParagraphContentItem::CommentReference(comment_id));
                *inserted_end = true;
            }
        }
    }

    if run_len == 0 {
        new_runs.push(run.clone());
        new_content_order.push(ParagraphContentItem::Run(new_runs.len().saturating_sub(1)));
        return Ok(());
    }

    let boundaries = segment_boundaries(*global_cursor, run_len, char_start, char_end);
    let run_chars = run_text.chars().collect::<Vec<_>>();
    for window in boundaries.windows(2) {
        let segment_start = window[0];
        let segment_end = window[1];
        if segment_start == segment_end {
            continue;
        }

        let global_segment_start = global_cursor.saturating_add(segment_start);
        let global_segment_end = global_cursor.saturating_add(segment_end);

        if let Some(comment_id) = comment_id {
            if !*inserted_start && char_start == global_segment_start {
                new_content_order.push(ParagraphContentItem::CommentRangeStart(comment_id));
                *inserted_start = true;
                if char_start == char_end && !*inserted_end {
                    new_content_order.push(ParagraphContentItem::CommentRangeEnd(comment_id));
                    new_content_order.push(ParagraphContentItem::CommentReference(comment_id));
                    *inserted_end = true;
                }
            }
        }

        let segment_text = run_chars[segment_start..segment_end]
            .iter()
            .collect::<String>();
        let mut segment_run = run.clone();
        if let Some(field_code) = run.field_code() {
            let mut field_code = field_code.clone();
            field_code.set_result(segment_text.as_str());
            segment_run.set_field_code(field_code);
            segment_run.set_text("");
        } else {
            segment_run.set_text(segment_text);
        }
        if let Some(color) = highlight_color {
            if global_segment_start >= char_start && global_segment_end <= char_end {
                segment_run.set_highlight_color(color);
            }
        }
        new_runs.push(segment_run);
        new_content_order.push(ParagraphContentItem::Run(new_runs.len().saturating_sub(1)));

        if let Some(comment_id) = comment_id {
            if *inserted_start && !*inserted_end && char_end == global_segment_end {
                new_content_order.push(ParagraphContentItem::CommentRangeEnd(comment_id));
                new_content_order.push(ParagraphContentItem::CommentReference(comment_id));
                *inserted_end = true;
            }
        }
    }

    *global_cursor = global_cursor.saturating_add(run_len);
    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn rewrite_textbox_run_segments(
    run: &Run,
    new_runs: &mut Vec<Run>,
    new_content_order: &mut Vec<ParagraphContentItem>,
    global_cursor: &mut usize,
    char_start: usize,
    char_end: usize,
    highlight_color: Option<&str>,
    comment_id: Option<u32>,
    inserted_start: &mut bool,
    inserted_end: &mut bool,
) -> Result<(), String> {
    let run_text = extract_supported_textbox_run_text(run)?;
    let run_len = run_text.chars().count();
    if run_len == 0 {
        new_runs.push(run.clone());
        new_content_order.push(ParagraphContentItem::Run(new_runs.len().saturating_sub(1)));
        return Ok(());
    }

    let local_start = char_start.saturating_sub(*global_cursor).min(run_len);
    let local_end = char_end.saturating_sub(*global_cursor).min(run_len);
    let mut segment_run = run.clone();
    segment_run.set_text("");
    segment_run.set_unknown_children(vec![clone_textbox_unknown_child_segment(
        run.unknown_children(),
        local_start,
        local_end,
        highlight_color,
        comment_id,
    )?]);
    new_runs.push(segment_run);
    new_content_order.push(ParagraphContentItem::Run(new_runs.len().saturating_sub(1)));

    if comment_id.is_some() {
        *inserted_start = true;
        *inserted_end = true;
    }

    *global_cursor = global_cursor.saturating_add(run_len);
    Ok(())
}

fn extract_supported_textbox_run_text(run: &Run) -> Result<String, String> {
    if run.unknown_children().len() != 1 {
        return Err(
            "cannot add character-level review markup to run with multiple unsupported raw XML children"
                .to_string(),
        );
    }
    extract_supported_textbox_text(run.unknown_children()[0].clone())
}

fn extract_supported_textbox_text(node: RawXmlNode) -> Result<String, String> {
    let RawXmlNode::Element { name, children, .. } = node else {
        return Err("unsupported raw XML text-box content".to_string());
    };
    if xml_local_name(name.as_str()) == "txbxContent" {
        return extract_supported_textbox_content_text(children.as_slice());
    }
    for child in children {
        if let Ok(text) = extract_supported_textbox_text(child) {
            return Ok(text);
        }
    }
    Err("unsupported raw XML child; expected VML text box content".to_string())
}

fn extract_supported_textbox_content_text(children: &[RawXmlNode]) -> Result<String, String> {
    let paragraphs = children
        .iter()
        .filter(|child| matches!(child, RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "p"))
        .collect::<Vec<_>>();
    if paragraphs.is_empty() {
        return Err("text box content does not contain any supported paragraphs".to_string());
    }

    let mut text = String::new();
    for (index, paragraph) in paragraphs.iter().enumerate() {
        if index > 0 {
            text.push('\n');
        }
        text.push_str(extract_supported_textbox_paragraph_text(paragraph)?.as_str());
    }
    Ok(text)
}

fn is_supported_textbox_paragraph_marker(node: &RawXmlNode) -> bool {
    let RawXmlNode::Element { name, .. } = node else {
        return false;
    };
    matches!(
        xml_local_name(name.as_str()),
        "commentRangeStart"
            | "commentRangeEnd"
            | "bookmarkStart"
            | "bookmarkEnd"
            | "moveFromRangeStart"
            | "moveFromRangeEnd"
            | "moveToRangeStart"
            | "moveToRangeEnd"
            | "proofErr"
            | "permStart"
            | "permEnd"
    )
}

fn extract_supported_textbox_paragraph_text(node: &RawXmlNode) -> Result<String, String> {
    let RawXmlNode::Element { name, children, .. } = node else {
        return Err("unsupported text-box paragraph content".to_string());
    };
    if xml_local_name(name.as_str()) != "p" {
        return Err("unsupported text-box content outside paragraph".to_string());
    }

    let mut text = String::new();
    for child in children {
        match child {
            RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "pPr" => {}
            _ if is_supported_textbox_paragraph_marker(child) => {}
            RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "r" => {
                text.push_str(extract_supported_textbox_run_text_node(child)?.as_str());
            }
            RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "hyperlink" => {
                text.push_str(extract_supported_textbox_hyperlink_text_node(child)?.as_str());
            }
            RawXmlNode::Text(value) | RawXmlNode::CData(value) if value.trim().is_empty() => {}
            RawXmlNode::Element { name, .. } => {
                return Err(format!(
                    "unsupported text-box paragraph child `{}`; only simple runs and hyperlinks are currently supported",
                    name
                ));
            }
            RawXmlNode::Text(_) | RawXmlNode::CData(_) => {
                return Err("unsupported direct text inside text-box paragraph".to_string());
            }
            RawXmlNode::RawBytes(_) => {
                return Err("unsupported raw-byte text-box paragraph child".to_string());
            }
        }
    }
    Ok(text)
}

fn extract_supported_textbox_hyperlink_text_node(node: &RawXmlNode) -> Result<String, String> {
    let RawXmlNode::Element { name, children, .. } = node else {
        return Err("unsupported text-box hyperlink content".to_string());
    };
    if xml_local_name(name.as_str()) != "hyperlink" {
        return Err("unsupported text-box content outside hyperlink".to_string());
    }

    let mut text = String::new();
    for child in children {
        match child {
            RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "r" => {
                text.push_str(extract_supported_textbox_run_text_node(child)?.as_str());
            }
            RawXmlNode::Text(value) | RawXmlNode::CData(value) if value.trim().is_empty() => {}
            RawXmlNode::Element { name, .. } => {
                return Err(format!(
                    "unsupported text-box hyperlink child `{}`; only simple runs are currently supported",
                    name
                ));
            }
            RawXmlNode::Text(_) | RawXmlNode::CData(_) => {
                return Err("unsupported direct text inside text-box hyperlink".to_string());
            }
            RawXmlNode::RawBytes(_) => {
                return Err("unsupported raw-byte text-box hyperlink child".to_string());
            }
        }
    }
    Ok(text)
}

fn extract_supported_textbox_run_text_node(node: &RawXmlNode) -> Result<String, String> {
    let RawXmlNode::Element { name, children, .. } = node else {
        return Err("unsupported text-box run content".to_string());
    };
    if xml_local_name(name.as_str()) != "r" {
        return Err("unsupported text-box content outside run".to_string());
    }

    let mut text = String::new();
    for child in children {
        match child {
            RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "rPr" => {}
            RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "t" => {
                text.push_str(collect_raw_text(child).as_str());
            }
            RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "tab" => {
                text.push('\t');
            }
            RawXmlNode::Element { name, .. }
                if matches!(xml_local_name(name.as_str()), "br" | "cr") =>
            {
                text.push('\n');
            }
            RawXmlNode::Element { name, .. }
                if xml_local_name(name.as_str()) == "noBreakHyphen" =>
            {
                text.push('-');
            }
            RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "softHyphen" => {
                text.push('\u{00AD}');
            }
            RawXmlNode::Element { name, .. }
                if xml_local_name(name.as_str()) == "commentReference" => {}
            RawXmlNode::Text(value) | RawXmlNode::CData(value) if value.trim().is_empty() => {}
            RawXmlNode::Element { name, .. } => {
                return Err(format!(
                    "unsupported text-box run child `{}`; only simple text/tab/break runs are currently supported",
                    name
                ));
            }
            RawXmlNode::Text(_) | RawXmlNode::CData(_) => {
                return Err("unsupported direct text inside text-box run".to_string());
            }
            RawXmlNode::RawBytes(_) => {
                return Err("unsupported raw-byte text-box run child".to_string());
            }
        }
    }
    Ok(text)
}

fn clone_textbox_unknown_child_segment(
    nodes: &[RawXmlNode],
    char_start: usize,
    char_end: usize,
    highlight_color: Option<&str>,
    comment_id: Option<u32>,
) -> Result<RawXmlNode, String> {
    let Some(node) = nodes.first() else {
        return Err("missing text-box raw XML child".to_string());
    };
    let (rewritten, found) =
        rewrite_textbox_node_segment(node, char_start, char_end, highlight_color, comment_id)?;
    if found {
        Ok(rewritten)
    } else {
        Err("unsupported raw XML child; expected VML text box content".to_string())
    }
}

fn rewrite_textbox_node_segment(
    node: &RawXmlNode,
    char_start: usize,
    char_end: usize,
    highlight_color: Option<&str>,
    comment_id: Option<u32>,
) -> Result<(RawXmlNode, bool), String> {
    let RawXmlNode::Element {
        name,
        attributes,
        children,
    } = node
    else {
        return Ok((node.clone(), false));
    };

    if xml_local_name(name.as_str()) == "txbxContent" {
        let rewritten = rewrite_textbox_content_segment(
            name.as_str(),
            attributes.as_slice(),
            children.as_slice(),
            char_start,
            char_end,
            highlight_color,
            comment_id,
        )?;
        return Ok((rewritten, true));
    }

    let mut rewritten_children = Vec::with_capacity(children.len());
    let mut found = false;
    for child in children {
        let (rewritten_child, child_found) =
            rewrite_textbox_node_segment(child, char_start, char_end, highlight_color, comment_id)?;
        rewritten_children.push(rewritten_child);
        found |= child_found;
    }
    Ok((
        RawXmlNode::Element {
            name: name.clone(),
            attributes: attributes.clone(),
            children: rewritten_children,
        },
        found,
    ))
}

fn rewrite_textbox_content_segment(
    name: &str,
    attributes: &[(String, String)],
    children: &[RawXmlNode],
    char_start: usize,
    char_end: usize,
    highlight_color: Option<&str>,
    comment_id: Option<u32>,
) -> Result<RawXmlNode, String> {
    let (target_child_index, local_start, local_end) =
        locate_supported_textbox_paragraph_range(children, char_start, char_end)?;

    let mut rewritten_children = Vec::with_capacity(children.len());
    for (index, child) in children.iter().enumerate() {
        if index == target_child_index {
            rewritten_children.push(clone_textbox_paragraph_segment(
                child,
                local_start,
                local_end,
                highlight_color,
                comment_id,
            )?);
        } else {
            rewritten_children.push(child.clone());
        }
    }

    Ok(RawXmlNode::Element {
        name: name.to_string(),
        attributes: attributes.to_vec(),
        children: rewritten_children,
    })
}

fn locate_supported_textbox_paragraph_range(
    children: &[RawXmlNode],
    char_start: usize,
    char_end: usize,
) -> Result<(usize, usize, usize), String> {
    let mut cursor = 0_usize;
    let mut paragraph_indexes = Vec::new();
    for (index, child) in children.iter().enumerate() {
        if !matches!(child, RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "p")
        {
            continue;
        }
        paragraph_indexes.push(index);
    }
    if paragraph_indexes.is_empty() {
        return Err("text box content does not contain any supported paragraphs".to_string());
    }

    for (paragraph_position, child_index) in paragraph_indexes.iter().copied().enumerate() {
        let paragraph = &children[child_index];
        let paragraph_len = extract_supported_textbox_paragraph_text(paragraph)?
            .chars()
            .count();
        let paragraph_start = cursor;
        let paragraph_end = cursor.saturating_add(paragraph_len);
        if char_start >= paragraph_start && char_end <= paragraph_end {
            return Ok((
                child_index,
                char_start.saturating_sub(paragraph_start),
                char_end.saturating_sub(paragraph_start),
            ));
        }
        cursor = paragraph_end;
        if paragraph_position + 1 < paragraph_indexes.len() {
            cursor = cursor.saturating_add(1);
        }
    }

    Err(
        "multi-paragraph text-box review currently requires the selected range to stay within a single paragraph"
            .to_string(),
    )
}

fn clone_textbox_paragraph_segment(
    node: &RawXmlNode,
    char_start: usize,
    char_end: usize,
    highlight_color: Option<&str>,
    comment_id: Option<u32>,
) -> Result<RawXmlNode, String> {
    let RawXmlNode::Element {
        name,
        attributes,
        children,
    } = node
    else {
        return Err("unsupported text-box paragraph content".to_string());
    };
    if xml_local_name(name.as_str()) != "p" {
        return Err("unsupported text-box content outside paragraph".to_string());
    }

    let mut new_children = Vec::new();
    let mut cursor = 0_usize;
    let mut inserted_comment_start = false;
    let mut inserted_comment_end = false;

    for child in children {
        match child {
            RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "pPr" => {
                new_children.push(child.clone());
            }
            _ if is_supported_textbox_paragraph_marker(child) => {
                new_children.push(child.clone());
            }
            RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "r" => {
                let run_text = extract_supported_textbox_run_text_node(child)?;
                let run_len = run_text.chars().count();
                let boundaries = segment_boundaries(cursor, run_len, char_start, char_end);
                for window in boundaries.windows(2) {
                    let segment_start = window[0];
                    let segment_end = window[1];
                    if segment_start == segment_end {
                        continue;
                    }
                    let global_segment_start = cursor.saturating_add(segment_start);
                    let global_segment_end = cursor.saturating_add(segment_end);
                    if let Some(id) = comment_id {
                        if !inserted_comment_start && char_start == global_segment_start {
                            new_children.push(build_comment_range_start_node(id));
                            inserted_comment_start = true;
                        }
                    }
                    new_children.push(clone_textbox_run_with_text(
                        child,
                        segment_start,
                        segment_end,
                        highlight_color.filter(|_| {
                            global_segment_start >= char_start && global_segment_end <= char_end
                        }),
                    )?);
                    if let Some(id) = comment_id {
                        if inserted_comment_start
                            && !inserted_comment_end
                            && char_end == global_segment_end
                        {
                            new_children.push(build_comment_range_end_node(id));
                            new_children.push(build_comment_reference_run_node(id));
                            inserted_comment_end = true;
                        }
                    }
                }
                cursor = cursor.saturating_add(run_len);
            }
            RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "hyperlink" => {
                let hyperlink_text = extract_supported_textbox_hyperlink_text_node(child)?;
                let hyperlink_len = hyperlink_text.chars().count();
                let boundaries = segment_boundaries(cursor, hyperlink_len, char_start, char_end);
                for window in boundaries.windows(2) {
                    let segment_start = window[0];
                    let segment_end = window[1];
                    if segment_start == segment_end {
                        continue;
                    }
                    let global_segment_start = cursor.saturating_add(segment_start);
                    let global_segment_end = cursor.saturating_add(segment_end);
                    if let Some(id) = comment_id {
                        if !inserted_comment_start && char_start == global_segment_start {
                            new_children.push(build_comment_range_start_node(id));
                            inserted_comment_start = true;
                        }
                    }
                    new_children.push(clone_textbox_hyperlink_with_text(
                        child,
                        segment_start,
                        segment_end,
                        highlight_color.filter(|_| {
                            global_segment_start >= char_start && global_segment_end <= char_end
                        }),
                    )?);
                    if let Some(id) = comment_id {
                        if inserted_comment_start
                            && !inserted_comment_end
                            && char_end == global_segment_end
                        {
                            new_children.push(build_comment_range_end_node(id));
                            new_children.push(build_comment_reference_run_node(id));
                            inserted_comment_end = true;
                        }
                    }
                }
                cursor = cursor.saturating_add(hyperlink_len);
            }
            RawXmlNode::Text(value) | RawXmlNode::CData(value) if value.trim().is_empty() => {}
            RawXmlNode::Element { name, .. } => {
                return Err(format!(
                    "unsupported text-box paragraph child `{}`; only simple runs are currently supported",
                    name
                ));
            }
            RawXmlNode::Text(_) | RawXmlNode::CData(_) => {
                return Err("unsupported direct text inside text-box paragraph".to_string());
            }
            RawXmlNode::RawBytes(_) => {
                return Err("unsupported raw-byte text-box paragraph child".to_string());
            }
        }
    }

    Ok(RawXmlNode::Element {
        name: name.clone(),
        attributes: attributes.clone(),
        children: new_children,
    })
}

fn clone_textbox_hyperlink_with_text(
    node: &RawXmlNode,
    char_start: usize,
    char_end: usize,
    highlight_color: Option<&str>,
) -> Result<RawXmlNode, String> {
    let RawXmlNode::Element {
        name,
        attributes,
        children,
    } = node
    else {
        return Err("unsupported text-box hyperlink content".to_string());
    };
    if xml_local_name(name.as_str()) != "hyperlink" {
        return Err("unsupported text-box content outside hyperlink".to_string());
    }

    let mut new_children = Vec::new();
    let mut cursor = 0_usize;
    for child in children {
        match child {
            RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "r" => {
                let run_text = extract_supported_textbox_run_text_node(child)?;
                let run_len = run_text.chars().count();
                let overlap_start = char_start.max(cursor);
                let overlap_end = char_end.min(cursor.saturating_add(run_len));
                if overlap_start < overlap_end {
                    let local_start = overlap_start.saturating_sub(cursor);
                    let local_end = overlap_end.saturating_sub(cursor);
                    new_children.push(clone_textbox_run_with_text(
                        child,
                        local_start,
                        local_end,
                        highlight_color,
                    )?);
                }
                cursor = cursor.saturating_add(run_len);
            }
            RawXmlNode::Text(value) | RawXmlNode::CData(value) if value.trim().is_empty() => {}
            RawXmlNode::Element { name, .. } => {
                return Err(format!(
                    "unsupported text-box hyperlink child `{}`; only simple runs are currently supported",
                    name
                ));
            }
            RawXmlNode::Text(_) | RawXmlNode::CData(_) => {
                return Err("unsupported direct text inside text-box hyperlink".to_string());
            }
            RawXmlNode::RawBytes(_) => {
                return Err("unsupported raw-byte text-box hyperlink child".to_string());
            }
        }
    }

    Ok(RawXmlNode::Element {
        name: name.clone(),
        attributes: attributes.clone(),
        children: new_children,
    })
}

fn clone_textbox_run_with_text(
    node: &RawXmlNode,
    char_start: usize,
    char_end: usize,
    highlight_color: Option<&str>,
) -> Result<RawXmlNode, String> {
    let RawXmlNode::Element {
        name,
        attributes,
        children,
    } = node
    else {
        return Err("unsupported text-box run content".to_string());
    };
    if xml_local_name(name.as_str()) != "r" {
        return Err("unsupported text-box content outside run".to_string());
    }

    let mut rpr_child = None;
    let mut content_children = Vec::new();
    let mut cursor = 0_usize;
    for child in children {
        match child {
            RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "rPr" => {
                rpr_child = Some(if let Some(color) = highlight_color {
                    clone_rpr_with_highlight(child, color)?
                } else {
                    child.clone()
                });
            }
            RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "t" => {
                let child_text = collect_raw_text(child);
                let child_len = child_text.chars().count();
                let overlap_start = char_start.max(cursor);
                let overlap_end = char_end.min(cursor.saturating_add(child_len));
                if overlap_start < overlap_end {
                    let local_start = overlap_start.saturating_sub(cursor);
                    let local_end = overlap_end.saturating_sub(cursor);
                    let segment_text = slice_chars(child_text.as_str(), local_start, local_end);
                    content_children
                        .push(clone_text_element_with_text(child, segment_text.as_str())?);
                }
                cursor = cursor.saturating_add(child_len);
            }
            RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "tab" => {
                let overlap_start = char_start.max(cursor);
                let overlap_end = char_end.min(cursor.saturating_add(1));
                if overlap_start < overlap_end {
                    content_children.push(child.clone());
                }
                cursor = cursor.saturating_add(1);
            }
            RawXmlNode::Element { name, .. }
                if matches!(xml_local_name(name.as_str()), "br" | "cr") =>
            {
                let overlap_start = char_start.max(cursor);
                let overlap_end = char_end.min(cursor.saturating_add(1));
                if overlap_start < overlap_end {
                    content_children.push(child.clone());
                }
                cursor = cursor.saturating_add(1);
            }
            RawXmlNode::Element { name, .. }
                if matches!(
                    xml_local_name(name.as_str()),
                    "noBreakHyphen" | "softHyphen"
                ) =>
            {
                let overlap_start = char_start.max(cursor);
                let overlap_end = char_end.min(cursor.saturating_add(1));
                if overlap_start < overlap_end {
                    content_children.push(child.clone());
                }
                cursor = cursor.saturating_add(1);
            }
            RawXmlNode::Element { name, .. }
                if xml_local_name(name.as_str()) == "commentReference" => {}
            RawXmlNode::Text(value) | RawXmlNode::CData(value) if value.trim().is_empty() => {}
            RawXmlNode::Element { name, .. } => {
                return Err(format!(
                    "unsupported text-box run child `{}`; only simple text/tab/break runs are currently supported",
                    name
                ));
            }
            RawXmlNode::Text(_) | RawXmlNode::CData(_) => {
                return Err("unsupported direct text inside text-box run".to_string());
            }
            RawXmlNode::RawBytes(_) => {
                return Err("unsupported raw-byte text-box run child".to_string());
            }
        }
    }

    let mut new_children = Vec::new();
    if let Some(rpr_child) = rpr_child {
        new_children.push(rpr_child);
    } else if let Some(color) = highlight_color {
        new_children.push(build_highlight_rpr_node(color));
    }
    new_children.extend(content_children);

    Ok(RawXmlNode::Element {
        name: name.clone(),
        attributes: attributes.clone(),
        children: new_children,
    })
}

fn build_comment_range_start_node(comment_id: u32) -> RawXmlNode {
    RawXmlNode::Element {
        name: "w:commentRangeStart".to_string(),
        attributes: vec![("w:id".to_string(), comment_id.to_string())],
        children: Vec::new(),
    }
}

fn build_comment_range_end_node(comment_id: u32) -> RawXmlNode {
    RawXmlNode::Element {
        name: "w:commentRangeEnd".to_string(),
        attributes: vec![("w:id".to_string(), comment_id.to_string())],
        children: Vec::new(),
    }
}

fn build_comment_reference_run_node(comment_id: u32) -> RawXmlNode {
    RawXmlNode::Element {
        name: "w:r".to_string(),
        attributes: Vec::new(),
        children: vec![
            RawXmlNode::Element {
                name: "w:rPr".to_string(),
                attributes: Vec::new(),
                children: vec![RawXmlNode::Element {
                    name: "w:rStyle".to_string(),
                    attributes: vec![("w:val".to_string(), "CommentReference".to_string())],
                    children: Vec::new(),
                }],
            },
            RawXmlNode::Element {
                name: "w:commentReference".to_string(),
                attributes: vec![("w:id".to_string(), comment_id.to_string())],
                children: Vec::new(),
            },
        ],
    }
}

fn rewrite_textbox_compare_unknown_child(
    nodes: &[RawXmlNode],
    prefix: &str,
    deleted: Option<(&str, &RevisionMetadata)>,
    inserted: Option<(&str, &RevisionMetadata)>,
    suffix: &str,
) -> Result<RawXmlNode, String> {
    let Some(node) = nodes.first() else {
        return Err("missing text-box raw XML child".to_string());
    };
    if nodes.len() != 1 {
        return Err(
            "only runs with a single text-box raw XML child are currently supported".to_string(),
        );
    }
    let (rewritten, found) = rewrite_textbox_node_compare(node, prefix, deleted, inserted, suffix)?;
    if found {
        Ok(rewritten)
    } else {
        Err("unsupported raw XML child; expected text box content".to_string())
    }
}

fn rewrite_textbox_node_compare(
    node: &RawXmlNode,
    prefix: &str,
    deleted: Option<(&str, &RevisionMetadata)>,
    inserted: Option<(&str, &RevisionMetadata)>,
    suffix: &str,
) -> Result<(RawXmlNode, bool), String> {
    let RawXmlNode::Element {
        name,
        attributes,
        children,
    } = node
    else {
        return Ok((node.clone(), false));
    };

    if xml_local_name(name.as_str()) == "txbxContent" {
        let rewritten = rewrite_textbox_content_compare(
            name.as_str(),
            attributes.as_slice(),
            children.as_slice(),
            prefix,
            deleted,
            inserted,
            suffix,
        )?;
        return Ok((rewritten, true));
    }

    let mut rewritten_children = Vec::with_capacity(children.len());
    let mut found = false;
    for child in children {
        let (rewritten_child, child_found) =
            rewrite_textbox_node_compare(child, prefix, deleted, inserted, suffix)?;
        rewritten_children.push(rewritten_child);
        found |= child_found;
    }
    Ok((
        RawXmlNode::Element {
            name: name.clone(),
            attributes: attributes.clone(),
            children: rewritten_children,
        },
        found,
    ))
}

fn rewrite_textbox_content_compare(
    name: &str,
    attributes: &[(String, String)],
    children: &[RawXmlNode],
    prefix: &str,
    deleted: Option<(&str, &RevisionMetadata)>,
    inserted: Option<(&str, &RevisionMetadata)>,
    suffix: &str,
) -> Result<RawXmlNode, String> {
    if deleted.is_some_and(|(text, _)| text.contains('\n'))
        || inserted.is_some_and(|(text, _)| text.contains('\n'))
    {
        return Err(
            "multi-paragraph textbox compare currently requires the changed fragment to stay within a single paragraph"
                .to_string(),
        );
    }

    let target_text = extract_supported_textbox_content_text(children)?;
    let change_start = prefix.chars().count();
    let target_len = target_text.chars().count();
    let suffix_len = suffix.chars().count();
    if change_start > target_len || suffix_len > target_len {
        return Err("textbox compare range is out of bounds for target content".to_string());
    }
    let change_end = target_len.saturating_sub(suffix_len);
    if change_start > change_end {
        return Err("textbox compare range is inconsistent with target content".to_string());
    }

    let (target_index, local_start, local_end) =
        locate_supported_textbox_paragraph_range(children, change_start, change_end)?;
    let paragraph_text = extract_supported_textbox_paragraph_text(&children[target_index])?;
    let local_prefix = slice_chars(paragraph_text.as_str(), 0, local_start);
    let local_suffix = slice_chars(
        paragraph_text.as_str(),
        local_end,
        paragraph_text.chars().count(),
    );

    let mut new_children = Vec::with_capacity(children.len());
    for (index, child) in children.iter().enumerate() {
        if index == target_index {
            new_children.push(clone_textbox_paragraph_compare_content(
                child,
                local_prefix.as_str(),
                deleted,
                inserted,
                local_suffix.as_str(),
            )?);
        } else {
            new_children.push(child.clone());
        }
    }

    Ok(RawXmlNode::Element {
        name: name.to_string(),
        attributes: attributes.to_vec(),
        children: new_children,
    })
}

fn clone_textbox_paragraph_compare_content(
    node: &RawXmlNode,
    prefix: &str,
    deleted: Option<(&str, &RevisionMetadata)>,
    inserted: Option<(&str, &RevisionMetadata)>,
    suffix: &str,
) -> Result<RawXmlNode, String> {
    let RawXmlNode::Element {
        name,
        attributes,
        children,
    } = node
    else {
        return Err("unsupported text-box paragraph content".to_string());
    };
    if xml_local_name(name.as_str()) != "p" {
        return Err("unsupported text-box content outside paragraph".to_string());
    }

    let paragraph_text = extract_supported_textbox_paragraph_text(node)?;
    let change_start = prefix.chars().count();
    let change_end = paragraph_text
        .chars()
        .count()
        .saturating_sub(suffix.chars().count());

    let mut new_children = Vec::new();
    let mut leading_markers = Vec::new();
    let mut trailing_markers = Vec::new();
    let mut seen_text_content = false;

    for child in children {
        match child {
            RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "pPr" => {
                new_children.push(child.clone());
            }
            _ if is_supported_textbox_paragraph_marker(child) => {
                if seen_text_content {
                    trailing_markers.push(child.clone());
                } else {
                    leading_markers.push(child.clone());
                }
            }
            RawXmlNode::Element { name, .. }
                if matches!(xml_local_name(name.as_str()), "r" | "hyperlink") =>
            {
                seen_text_content = true;
            }
            RawXmlNode::Text(value) | RawXmlNode::CData(value) if value.trim().is_empty() => {}
            RawXmlNode::Element { name, .. } => {
                return Err(format!(
                    "unsupported text-box paragraph child `{}`; only simple runs are currently supported",
                    name
                ));
            }
            RawXmlNode::Text(_) | RawXmlNode::CData(_) => {
                return Err("unsupported direct text inside text-box paragraph".to_string());
            }
            RawXmlNode::RawBytes(_) => {
                return Err("unsupported raw-byte text-box paragraph child".to_string());
            }
        }
    }

    new_children.extend(leading_markers);
    new_children.extend(clone_textbox_paragraph_range_content(
        children,
        0,
        change_start,
    )?);
    if let Some((deleted_text, metadata)) = deleted {
        if !deleted_text.is_empty() {
            new_children.push(build_deleted_text_node(deleted_text, metadata));
        }
    }
    if let Some((inserted_text, metadata)) = inserted {
        if !inserted_text.is_empty() {
            new_children.push(build_inserted_text_node(inserted_text, metadata));
        }
    }
    new_children.extend(clone_textbox_paragraph_range_content(
        children,
        change_end,
        paragraph_text.chars().count(),
    )?);
    new_children.extend(trailing_markers);
    if new_children.is_empty() {
        new_children.push(build_plain_text_run_node(""));
    }

    Ok(RawXmlNode::Element {
        name: name.clone(),
        attributes: attributes.clone(),
        children: new_children,
    })
}

fn build_plain_text_run_node(text: &str) -> RawXmlNode {
    let mut text_attributes = Vec::new();
    if text.starts_with(' ') || text.ends_with(' ') {
        text_attributes.push(("xml:space".to_string(), "preserve".to_string()));
    }
    RawXmlNode::Element {
        name: "w:r".to_string(),
        attributes: Vec::new(),
        children: vec![RawXmlNode::Element {
            name: "w:t".to_string(),
            attributes: text_attributes,
            children: vec![RawXmlNode::Text(text.to_string())],
        }],
    }
}

fn clone_textbox_paragraph_range_content(
    children: &[RawXmlNode],
    range_start: usize,
    range_end: usize,
) -> Result<Vec<RawXmlNode>, String> {
    if range_start >= range_end {
        return Ok(Vec::new());
    }

    let mut new_children = Vec::new();
    let mut cursor = 0_usize;
    for child in children {
        let RawXmlNode::Element { name, .. } = child else {
            continue;
        };
        match xml_local_name(name.as_str()) {
            "r" => {
                let run_text = extract_supported_textbox_run_text_node(child)?;
                let run_len = run_text.chars().count();
                let overlap_start = range_start.max(cursor);
                let overlap_end = range_end.min(cursor.saturating_add(run_len));
                if overlap_start < overlap_end {
                    let local_start = overlap_start.saturating_sub(cursor);
                    let local_end = overlap_end.saturating_sub(cursor);
                    new_children.push(clone_textbox_run_with_text(
                        child,
                        local_start,
                        local_end,
                        None,
                    )?);
                }
                cursor = cursor.saturating_add(run_len);
            }
            "hyperlink" => {
                let hyperlink_text = extract_supported_textbox_hyperlink_text_node(child)?;
                let hyperlink_len = hyperlink_text.chars().count();
                let overlap_start = range_start.max(cursor);
                let overlap_end = range_end.min(cursor.saturating_add(hyperlink_len));
                if overlap_start < overlap_end {
                    let local_start = overlap_start.saturating_sub(cursor);
                    let local_end = overlap_end.saturating_sub(cursor);
                    new_children.push(clone_textbox_hyperlink_with_text(
                        child,
                        local_start,
                        local_end,
                        None,
                    )?);
                }
                cursor = cursor.saturating_add(hyperlink_len);
            }
            _ => {}
        }
    }

    Ok(new_children)
}

fn insert_comment_start_markers_at_boundary(
    new_content_order: &mut Vec<ParagraphContentItem>,
    global_cursor: &usize,
    char_start: usize,
    char_end: usize,
    comment_id: u32,
    inserted_start: &mut bool,
    inserted_end: &mut bool,
) {
    if !*inserted_start && char_start == *global_cursor {
        new_content_order.push(ParagraphContentItem::CommentRangeStart(comment_id));
        *inserted_start = true;
        if char_start == char_end && !*inserted_end {
            new_content_order.push(ParagraphContentItem::CommentRangeEnd(comment_id));
            new_content_order.push(ParagraphContentItem::CommentReference(comment_id));
            *inserted_end = true;
        }
    }
}

fn insert_comment_end_markers_at_boundary(
    new_content_order: &mut Vec<ParagraphContentItem>,
    global_cursor: &usize,
    char_end: usize,
    comment_id: u32,
    inserted_start: &mut bool,
    inserted_end: &mut bool,
) {
    if *inserted_start && !*inserted_end && char_end == *global_cursor {
        new_content_order.push(ParagraphContentItem::CommentRangeEnd(comment_id));
        new_content_order.push(ParagraphContentItem::CommentReference(comment_id));
        *inserted_end = true;
    }
}

#[allow(clippy::too_many_arguments)]
fn rewrite_unknown_child_segments(
    node: &RawXmlNode,
    new_unknown_children: &mut Vec<RawXmlNode>,
    new_content_order: &mut Vec<ParagraphContentItem>,
    global_cursor: &mut usize,
    char_start: usize,
    char_end: usize,
    highlight_color: Option<&str>,
    comment_id: Option<u32>,
    inserted_start: &mut bool,
    inserted_end: &mut bool,
) -> Result<(), String> {
    let node_text = extract_supported_unknown_child_text(node)?;
    let node_len = node_text.chars().count();

    if node_len == 0 {
        if let Some(comment_id) = comment_id {
            insert_comment_end_markers_at_boundary(
                new_content_order,
                global_cursor,
                char_end,
                comment_id,
                inserted_start,
                inserted_end,
            );
        }
        new_unknown_children.push(node.clone());
        new_content_order.push(ParagraphContentItem::UnknownChild(
            new_unknown_children.len().saturating_sub(1),
        ));
        if let Some(comment_id) = comment_id {
            insert_comment_start_markers_at_boundary(
                new_content_order,
                global_cursor,
                char_start,
                char_end,
                comment_id,
                inserted_start,
                inserted_end,
            );
        }
        return Ok(());
    }

    if let Some(comment_id) = comment_id {
        if !*inserted_start && char_start == *global_cursor {
            new_content_order.push(ParagraphContentItem::CommentRangeStart(comment_id));
            *inserted_start = true;
            if char_start == char_end && !*inserted_end {
                new_content_order.push(ParagraphContentItem::CommentRangeEnd(comment_id));
                new_content_order.push(ParagraphContentItem::CommentReference(comment_id));
                *inserted_end = true;
            }
        }
    }

    let boundaries = segment_boundaries(*global_cursor, node_len, char_start, char_end);
    let local_highlight = highlight_color.map(|color| {
        (
            char_start.saturating_sub(*global_cursor).min(node_len),
            char_end.saturating_sub(*global_cursor).min(node_len),
            color,
        )
    });
    let segment_nodes = split_supported_unknown_child_node(node, &boundaries, local_highlight)?;

    for (window, segment_node) in boundaries.windows(2).zip(segment_nodes) {
        let segment_start = window[0];
        let segment_end = window[1];
        if segment_start == segment_end {
            continue;
        }

        let global_segment_start = global_cursor.saturating_add(segment_start);
        let global_segment_end = global_cursor.saturating_add(segment_end);

        if let Some(comment_id) = comment_id {
            if !*inserted_start && char_start == global_segment_start {
                new_content_order.push(ParagraphContentItem::CommentRangeStart(comment_id));
                *inserted_start = true;
                if char_start == char_end && !*inserted_end {
                    new_content_order.push(ParagraphContentItem::CommentRangeEnd(comment_id));
                    new_content_order.push(ParagraphContentItem::CommentReference(comment_id));
                    *inserted_end = true;
                }
            }
        }

        new_unknown_children.push(segment_node);
        new_content_order.push(ParagraphContentItem::UnknownChild(
            new_unknown_children.len().saturating_sub(1),
        ));

        if let Some(comment_id) = comment_id {
            if *inserted_start && !*inserted_end && char_end == global_segment_end {
                new_content_order.push(ParagraphContentItem::CommentRangeEnd(comment_id));
                new_content_order.push(ParagraphContentItem::CommentReference(comment_id));
                *inserted_end = true;
            }
        }
    }

    *global_cursor = global_cursor.saturating_add(node_len);
    Ok(())
}

fn segment_boundaries(
    global_cursor: usize,
    segment_len: usize,
    char_start: usize,
    char_end: usize,
) -> Vec<usize> {
    let local_start = char_start.saturating_sub(global_cursor).min(segment_len);
    let local_end = char_end.saturating_sub(global_cursor).min(segment_len);
    let mut boundaries = vec![0_usize, segment_len];
    if char_start >= global_cursor && char_start <= global_cursor.saturating_add(segment_len) {
        boundaries.push(local_start);
    }
    if char_end >= global_cursor && char_end <= global_cursor.saturating_add(segment_len) {
        boundaries.push(local_end);
    }
    boundaries.sort_unstable();
    boundaries.dedup();
    boundaries
}

fn extract_supported_unknown_child_text(node: &RawXmlNode) -> Result<String, String> {
    let RawXmlNode::Element { name, children, .. } = node else {
        return Err("cannot add character-level review markup to paragraph with unsupported raw XML children".to_string());
    };

    let local_name = xml_local_name(name.as_str());
    if matches!(
        local_name,
        "bookmarkStart"
            | "bookmarkEnd"
            | "moveFromRangeStart"
            | "moveFromRangeEnd"
            | "moveToRangeStart"
            | "moveToRangeEnd"
    ) {
        return Ok(String::new());
    }

    if local_name == "r" {
        return extract_supported_revision_run_text(node, "t");
    }

    let text_element_local = match local_name {
        "ins" => "t",
        "del" => "delText",
        _ => {
            return Err(format!(
                "cannot add character-level review markup to paragraph with unsupported raw XML child `{}`",
                name
            ));
        }
    };

    let mut text = String::new();
    for child in children {
        text.push_str(extract_supported_revision_run_text(child, text_element_local)?.as_str());
    }
    Ok(text)
}

fn extract_supported_revision_run_text(
    node: &RawXmlNode,
    text_element_local: &str,
) -> Result<String, String> {
    let RawXmlNode::Element { name, children, .. } = node else {
        return Err("unsupported revision content outside run element".to_string());
    };
    if xml_local_name(name.as_str()) != "r" {
        return Err(format!(
            "unsupported revision child `{}`; only simple text runs are currently supported",
            name
        ));
    }

    let mut text = None;
    for child in children {
        match child {
            RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "rPr" => {}
            RawXmlNode::Element { name, .. }
                if xml_local_name(name.as_str()) == text_element_local =>
            {
                text = Some(collect_raw_text(child));
            }
            RawXmlNode::Text(value) | RawXmlNode::CData(value) if value.trim().is_empty() => {}
            RawXmlNode::Element { name, .. } => {
                return Err(format!(
                    "unsupported revision run child `{}`; only simple text runs are currently supported",
                    name
                ));
            }
            RawXmlNode::RawBytes(_) => {
                return Err(
                    "unsupported revision run with raw XML bytes in text-level review helper"
                        .to_string(),
                );
            }
            RawXmlNode::Text(_) | RawXmlNode::CData(_) => {
                return Err(
                    "unsupported revision run with direct text outside the expected text element"
                        .to_string(),
                );
            }
        }
    }

    Ok(text.unwrap_or_default())
}

fn split_supported_unknown_child_node(
    node: &RawXmlNode,
    boundaries: &[usize],
    local_highlight: Option<(usize, usize, &str)>,
) -> Result<Vec<RawXmlNode>, String> {
    let RawXmlNode::Element {
        name,
        attributes,
        children,
    } = node
    else {
        return Err("unsupported raw XML child for text-level review helper".to_string());
    };

    if xml_local_name(name.as_str()) == "r" {
        let run_text = extract_supported_revision_run_text(node, "t")?;
        let mut segments = Vec::new();
        for window in boundaries.windows(2) {
            let segment_start = window[0];
            let segment_end = window[1];
            if segment_start == segment_end {
                continue;
            }
            let segment_highlight = local_highlight.and_then(|(start, end, color)| {
                (segment_start >= start && segment_end <= end).then_some(color)
            });
            let segment_text = slice_chars(run_text.as_str(), segment_start, segment_end);
            segments.push(clone_revision_run_with_text(
                node,
                segment_text.as_str(),
                "t",
                segment_highlight,
            )?);
        }
        return Ok(segments);
    }

    let text_element_local = match xml_local_name(name.as_str()) {
        "ins" => "t",
        "del" => "delText",
        _ => {
            return Err(format!(
                "cannot split unsupported raw XML child `{}` for text-level review helper",
                name
            ));
        }
    };

    let mut revision_runs = Vec::new();
    for child in children {
        revision_runs.push(RevisionRunTemplate {
            node: child.clone(),
            text: extract_supported_revision_run_text(child, text_element_local)?,
        });
    }

    let mut segments = Vec::new();
    for window in boundaries.windows(2) {
        let segment_start = window[0];
        let segment_end = window[1];
        if segment_start == segment_end {
            continue;
        }

        let segment_highlight = local_highlight.and_then(|(start, end, color)| {
            (segment_start >= start && segment_end <= end).then_some(color)
        });

        let mut segment_children = Vec::new();
        let mut cursor = 0_usize;
        for revision_run in &revision_runs {
            let run_len = revision_run.text.chars().count();
            let overlap_start = segment_start.max(cursor);
            let overlap_end = segment_end.min(cursor.saturating_add(run_len));
            if overlap_start < overlap_end {
                let local_start = overlap_start.saturating_sub(cursor);
                let local_end = overlap_end.saturating_sub(cursor);
                let segment_text = slice_chars(revision_run.text.as_str(), local_start, local_end);
                segment_children.push(clone_revision_run_with_text(
                    &revision_run.node,
                    segment_text.as_str(),
                    text_element_local,
                    segment_highlight,
                )?);
            }
            cursor = cursor.saturating_add(run_len);
        }

        segments.push(RawXmlNode::Element {
            name: name.clone(),
            attributes: attributes.clone(),
            children: segment_children,
        });
    }

    Ok(segments)
}

fn clone_revision_run_with_text(
    node: &RawXmlNode,
    segment_text: &str,
    text_element_local: &str,
    highlight_color: Option<&str>,
) -> Result<RawXmlNode, String> {
    let RawXmlNode::Element {
        name,
        attributes,
        children,
    } = node
    else {
        return Err("unsupported revision content outside run element".to_string());
    };
    if xml_local_name(name.as_str()) != "r" {
        return Err(format!(
            "unsupported revision child `{}`; only simple text runs are currently supported",
            name
        ));
    }

    let mut new_children = Vec::new();
    let mut saw_rpr = false;
    let mut saw_text = false;

    for child in children {
        match child {
            RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "rPr" => {
                saw_rpr = true;
                new_children.push(if let Some(color) = highlight_color {
                    clone_rpr_with_highlight(child, color)?
                } else {
                    child.clone()
                });
            }
            RawXmlNode::Element { name, .. }
                if xml_local_name(name.as_str()) == text_element_local =>
            {
                saw_text = true;
                new_children.push(clone_text_element_with_text(child, segment_text)?);
            }
            RawXmlNode::Text(value) | RawXmlNode::CData(value) if value.trim().is_empty() => {
                new_children.push(child.clone());
            }
            RawXmlNode::Element { name, .. } => {
                return Err(format!(
                    "unsupported revision run child `{}`; only simple text runs are currently supported",
                    name
                ));
            }
            RawXmlNode::RawBytes(_) => {
                return Err(
                    "unsupported revision run with raw XML bytes in text-level review helper"
                        .to_string(),
                );
            }
            RawXmlNode::Text(_) | RawXmlNode::CData(_) => {
                return Err(
                    "unsupported revision run with direct text outside the expected text element"
                        .to_string(),
                );
            }
        }
    }

    if !saw_text {
        return Err("unsupported revision run without text element".to_string());
    }

    if let Some(color) = highlight_color {
        if !saw_rpr {
            new_children.insert(0, build_highlight_rpr_node(color));
        }
    }

    Ok(RawXmlNode::Element {
        name: name.clone(),
        attributes: attributes.clone(),
        children: new_children,
    })
}

fn clone_text_element_with_text(node: &RawXmlNode, text: &str) -> Result<RawXmlNode, String> {
    let RawXmlNode::Element {
        name,
        attributes,
        children: _,
    } = node
    else {
        return Err("expected text element while rewriting revision run".to_string());
    };

    let mut new_attributes = attributes
        .iter()
        .filter(|(key, _)| xml_local_name(key.as_str()) != "space")
        .cloned()
        .collect::<Vec<_>>();
    if text.starts_with(char::is_whitespace) || text.ends_with(char::is_whitespace) {
        new_attributes.push(("xml:space".to_string(), "preserve".to_string()));
    }

    Ok(RawXmlNode::Element {
        name: name.clone(),
        attributes: new_attributes,
        children: vec![RawXmlNode::Text(text.to_string())],
    })
}

fn clone_rpr_with_highlight(node: &RawXmlNode, color: &str) -> Result<RawXmlNode, String> {
    let RawXmlNode::Element {
        name,
        attributes,
        children,
    } = node
    else {
        return Err("expected rPr element while rewriting revision run".to_string());
    };
    if xml_local_name(name.as_str()) != "rPr" {
        return Err("expected rPr element while rewriting revision run".to_string());
    }

    let mut new_children = Vec::new();
    let mut replaced_highlight = false;
    for child in children {
        match child {
            RawXmlNode::Element { name, .. } if xml_local_name(name.as_str()) == "highlight" => {
                if !replaced_highlight {
                    new_children.push(build_highlight_node(color));
                    replaced_highlight = true;
                }
            }
            _ => new_children.push(child.clone()),
        }
    }
    if !replaced_highlight {
        new_children.push(build_highlight_node(color));
    }

    Ok(RawXmlNode::Element {
        name: name.clone(),
        attributes: attributes.clone(),
        children: new_children,
    })
}

fn build_highlight_rpr_node(color: &str) -> RawXmlNode {
    RawXmlNode::Element {
        name: "w:rPr".to_string(),
        attributes: Vec::new(),
        children: vec![build_highlight_node(color)],
    }
}

fn build_highlight_node(color: &str) -> RawXmlNode {
    RawXmlNode::Element {
        name: "w:highlight".to_string(),
        attributes: vec![("w:val".to_string(), color.to_string())],
        children: Vec::new(),
    }
}

fn collect_raw_text(node: &RawXmlNode) -> String {
    match node {
        RawXmlNode::Text(text) | RawXmlNode::CData(text) => text.clone(),
        RawXmlNode::Element { children, .. } => children.iter().map(collect_raw_text).collect(),
        RawXmlNode::RawBytes(_) => String::new(),
    }
}

fn slice_chars(text: &str, start: usize, end: usize) -> String {
    text.chars()
        .skip(start)
        .take(end.saturating_sub(start))
        .collect()
}

fn xml_local_name(name: &str) -> &str {
    name.rsplit(':').next().unwrap_or(name)
}

fn find_text_char_range_in_string(haystack: &str, needle: &str) -> Option<(usize, usize)> {
    if needle.is_empty() {
        return None;
    }
    let byte_start = haystack.find(needle)?;
    let byte_end = byte_start.saturating_add(needle.len());
    let char_start = haystack[..byte_start].chars().count();
    let char_end = haystack[..byte_end].chars().count();
    Some((char_start, char_end))
}

fn run_reviewable_text(run: &Run) -> Result<String, String> {
    if let Some(field_code) = run.field_code() {
        Ok(field_code.result().to_string())
    } else if !run.unknown_children().is_empty() {
        extract_supported_textbox_run_text(run)
    } else {
        Ok(run.text().to_string())
    }
}

#[derive(Debug, Clone)]
struct RevisionRunTemplate {
    node: RawXmlNode,
    text: String,
}

fn normalize_optional_text(value: String) -> Option<String> {
    let trimmed = value.trim();
    if trimmed.is_empty() {
        None
    } else {
        Some(trimmed.to_string())
    }
}

fn normalize_color_value(value: &str) -> Option<String> {
    let trimmed = value.trim();
    let normalized = trimmed.trim_start_matches('#').to_ascii_uppercase();
    if normalized.is_empty() || normalized == "AUTO" {
        None
    } else {
        Some(normalized)
    }
}

#[cfg(test)]
mod tests {
    use super::{
        LineSpacingRule, Paragraph, ParagraphAlignment, ParagraphBorder, ParagraphBorders, TabStop,
        TabStopAlignment, TabStopLeader,
    };
    use crate::image::{FloatingImage, InlineImage};

    #[test]
    fn creates_paragraph_from_text() {
        let paragraph = Paragraph::from_text("Hello world");

        assert_eq!(paragraph.text(), "Hello world");
        assert_eq!(paragraph.runs().len(), 1);
        assert_eq!(paragraph.runs()[0].text(), "Hello world");
        assert_eq!(paragraph.heading_level(), None);
        assert_eq!(paragraph.style_id(), None);
        assert_eq!(paragraph.alignment(), None);
        assert_eq!(paragraph.spacing_before_twips(), None);
        assert_eq!(paragraph.spacing_after_twips(), None);
        assert_eq!(paragraph.line_spacing_twips(), None);
        assert_eq!(paragraph.indent_left_twips(), None);
        assert_eq!(paragraph.indent_right_twips(), None);
        assert_eq!(paragraph.indent_first_line_twips(), None);
        assert_eq!(paragraph.indent_hanging_twips(), None);
        assert_eq!(paragraph.numbering_num_id(), None);
        assert_eq!(paragraph.numbering_ilvl(), None);
    }

    #[test]
    fn paragraph_formatting_and_hyperlinks_can_be_set() {
        let mut paragraph = Paragraph::new();
        paragraph.set_style_id("BodyText");
        paragraph.set_alignment(ParagraphAlignment::Justified);
        paragraph.set_spacing_before_twips(120);
        paragraph.set_spacing_after_twips(80);
        paragraph.set_line_spacing_twips(300);
        paragraph.set_indent_left_twips(240);
        paragraph.set_indent_right_twips(60);
        paragraph.set_indent_first_line_twips(180);
        paragraph.set_indent_hanging_twips(90);
        paragraph.set_numbering(42, 2);

        paragraph.add_hyperlink("offidized", "https://example.com");
        paragraph.add_inline_image(0, 640_000, 480_000);
        paragraph.add_floating_image(1, 720_000, 540_000);

        assert_eq!(paragraph.style_id(), Some("BodyText"));
        assert_eq!(paragraph.alignment(), Some(ParagraphAlignment::Justified));
        assert_eq!(paragraph.spacing_before_twips(), Some(120));
        assert_eq!(paragraph.spacing_after_twips(), Some(80));
        assert_eq!(paragraph.line_spacing_twips(), Some(300));
        assert_eq!(paragraph.indent_left_twips(), Some(240));
        assert_eq!(paragraph.indent_right_twips(), Some(60));
        assert_eq!(paragraph.indent_first_line_twips(), Some(180));
        assert_eq!(paragraph.indent_hanging_twips(), Some(90));
        assert_eq!(paragraph.numbering_num_id(), Some(42));
        assert_eq!(paragraph.numbering_ilvl(), Some(2));
        assert_eq!(paragraph.runs()[0].hyperlink(), Some("https://example.com"));
        assert_eq!(
            paragraph.runs()[1]
                .inline_image()
                .map(InlineImage::image_index),
            Some(0)
        );
        assert_eq!(
            paragraph.runs()[2]
                .floating_image()
                .map(FloatingImage::image_index),
            Some(1)
        );
    }

    #[test]
    fn add_run_with_style_sets_character_style() {
        let mut paragraph = Paragraph::new();

        paragraph.add_run_with_style("Styled", "Emphasis");

        assert_eq!(paragraph.runs().len(), 1);
        assert_eq!(paragraph.runs()[0].text(), "Styled");
        assert_eq!(paragraph.runs()[0].style_id(), Some("Emphasis"));
    }

    #[test]
    fn paragraph_style_id_can_be_cleared() {
        let mut paragraph = Paragraph::new();
        paragraph.set_style_id("Quote");
        assert_eq!(paragraph.style_id(), Some("Quote"));
        paragraph.clear_style_id();
        assert_eq!(paragraph.style_id(), None);
    }

    #[test]
    fn tab_stops_can_be_added_and_cleared() {
        let mut paragraph = Paragraph::new();
        assert!(paragraph.tab_stops().is_empty());

        paragraph.add_tab_stop(TabStop::new(720, TabStopAlignment::Left));
        paragraph.add_tab_stop(TabStop::with_leader(
            4320,
            TabStopAlignment::Right,
            TabStopLeader::Dot,
        ));

        assert_eq!(paragraph.tab_stops().len(), 2);
        assert_eq!(paragraph.tab_stops()[0].position_twips(), 720);
        assert_eq!(paragraph.tab_stops()[0].alignment(), TabStopAlignment::Left);
        assert_eq!(paragraph.tab_stops()[0].leader(), None);
        assert_eq!(paragraph.tab_stops()[1].position_twips(), 4320);
        assert_eq!(
            paragraph.tab_stops()[1].alignment(),
            TabStopAlignment::Right
        );
        assert_eq!(paragraph.tab_stops()[1].leader(), Some(TabStopLeader::Dot));

        paragraph.clear_tab_stops();
        assert!(paragraph.tab_stops().is_empty());
    }

    #[test]
    fn paragraph_borders_can_be_set_and_cleared() {
        let mut paragraph = Paragraph::new();
        assert!(paragraph.borders().is_empty());

        let mut top = ParagraphBorder::new("single");
        top.set_size_eighth_points(8);
        top.set_color("#FF0000");
        top.set_space_points(1);
        paragraph.borders_mut().set_top(top);

        assert_eq!(
            paragraph
                .borders()
                .top()
                .and_then(ParagraphBorder::line_type),
            Some("single")
        );
        assert_eq!(
            paragraph
                .borders()
                .top()
                .and_then(ParagraphBorder::size_eighth_points),
            Some(8)
        );
        assert_eq!(
            paragraph.borders().top().and_then(ParagraphBorder::color),
            Some("FF0000")
        );
        assert_eq!(
            paragraph
                .borders()
                .top()
                .and_then(ParagraphBorder::space_points),
            Some(1)
        );

        paragraph.clear_borders();
        assert!(paragraph.borders().is_empty());
    }

    #[test]
    fn paragraph_shading_can_be_set_and_cleared() {
        let mut paragraph = Paragraph::new();
        assert_eq!(paragraph.shading_color(), None);

        paragraph.set_shading_color("#FFAA00");
        assert_eq!(paragraph.shading_color(), Some("FFAA00"));

        paragraph.set_shading_pattern("clear");
        assert_eq!(paragraph.shading_pattern(), Some("clear"));

        paragraph.clear_shading_color();
        paragraph.clear_shading_pattern();
        assert_eq!(paragraph.shading_color(), None);
        assert_eq!(paragraph.shading_pattern(), None);
    }

    #[test]
    fn keep_next_and_keep_lines_and_widow_control() {
        let mut paragraph = Paragraph::new();
        assert!(!paragraph.keep_next());
        assert!(!paragraph.keep_lines());
        assert_eq!(paragraph.widow_control(), None);

        paragraph.set_keep_next(true);
        paragraph.set_keep_lines(true);
        paragraph.set_widow_control(false);

        assert!(paragraph.keep_next());
        assert!(paragraph.keep_lines());
        assert_eq!(paragraph.widow_control(), Some(false));

        paragraph.set_keep_next(false);
        paragraph.set_keep_lines(false);
        paragraph.clear_widow_control();

        assert!(!paragraph.keep_next());
        assert!(!paragraph.keep_lines());
        assert_eq!(paragraph.widow_control(), None);
    }

    #[test]
    fn tab_stop_alignment_xml_roundtrip() {
        assert_eq!(
            TabStopAlignment::from_xml_value("left"),
            Some(TabStopAlignment::Left)
        );
        assert_eq!(
            TabStopAlignment::from_xml_value("center"),
            Some(TabStopAlignment::Center)
        );
        assert_eq!(
            TabStopAlignment::from_xml_value("right"),
            Some(TabStopAlignment::Right)
        );
        assert_eq!(
            TabStopAlignment::from_xml_value("decimal"),
            Some(TabStopAlignment::Decimal)
        );
        assert_eq!(
            TabStopAlignment::from_xml_value("bar"),
            Some(TabStopAlignment::Bar)
        );
        assert_eq!(
            TabStopAlignment::from_xml_value("clear"),
            Some(TabStopAlignment::Clear)
        );
        assert_eq!(TabStopAlignment::from_xml_value("invalid"), None);

        assert_eq!(TabStopAlignment::Left.to_xml_value(), "left");
        assert_eq!(TabStopAlignment::Right.to_xml_value(), "right");
    }

    #[test]
    fn tab_stop_leader_xml_roundtrip() {
        assert_eq!(
            TabStopLeader::from_xml_value("dot"),
            Some(TabStopLeader::Dot)
        );
        assert_eq!(
            TabStopLeader::from_xml_value("hyphen"),
            Some(TabStopLeader::Hyphen)
        );
        assert_eq!(
            TabStopLeader::from_xml_value("underscore"),
            Some(TabStopLeader::Underscore)
        );
        assert_eq!(
            TabStopLeader::from_xml_value("none"),
            Some(TabStopLeader::None)
        );
        assert_eq!(TabStopLeader::from_xml_value("invalid"), None);

        assert_eq!(TabStopLeader::Dot.to_xml_value(), "dot");
        assert_eq!(TabStopLeader::Hyphen.to_xml_value(), "hyphen");
    }

    #[test]
    fn new_properties_affect_has_properties() {
        let mut paragraph = Paragraph::new();
        assert!(!paragraph.has_properties());

        paragraph.set_keep_next(true);
        assert!(paragraph.has_properties());
        paragraph.set_keep_next(false);
        assert!(!paragraph.has_properties());

        paragraph.set_keep_lines(true);
        assert!(paragraph.has_properties());
        paragraph.set_keep_lines(false);

        paragraph.set_widow_control(false);
        assert!(paragraph.has_properties());
        paragraph.clear_widow_control();

        paragraph.add_tab_stop(TabStop::new(720, TabStopAlignment::Left));
        assert!(paragraph.has_properties());
        paragraph.clear_tab_stops();

        paragraph
            .borders_mut()
            .set_top(ParagraphBorder::new("single"));
        assert!(paragraph.has_properties());
        paragraph.clear_borders();

        paragraph.set_shading_color("FFAA00");
        assert!(paragraph.has_properties());
        paragraph.clear_shading_color();

        assert!(!paragraph.has_properties());
    }

    #[test]
    fn paragraph_section_properties_can_be_set_and_cleared() {
        use crate::section::Section;

        let mut paragraph = Paragraph::new();
        assert_eq!(paragraph.section_properties(), None);

        let mut section = Section::new();
        section.set_page_size_twips(12_240, 15_840);
        paragraph.set_section_properties(section);
        assert!(paragraph.section_properties().is_some());
        assert_eq!(
            paragraph
                .section_properties()
                .and_then(|s| s.page_width_twips()),
            Some(12_240)
        );

        paragraph.clear_section_properties();
        assert_eq!(paragraph.section_properties(), None);
    }

    #[test]
    fn paragraph_borders_between_can_be_set() {
        let mut borders = ParagraphBorders::new();
        borders.set_between(ParagraphBorder::new("single"));
        assert_eq!(
            borders.between().and_then(ParagraphBorder::line_type),
            Some("single")
        );
        borders.clear_between();
        assert_eq!(borders.between(), None);
    }

    #[test]
    fn bidi_can_be_set_and_read() {
        let mut paragraph = Paragraph::new();
        assert!(!paragraph.is_bidi());

        paragraph.set_bidi(true);
        assert!(paragraph.is_bidi());
        assert!(paragraph.has_properties());

        paragraph.set_bidi(false);
        assert!(!paragraph.is_bidi());
    }

    #[test]
    fn bidi_affects_has_properties() {
        let mut paragraph = Paragraph::new();
        assert!(!paragraph.has_properties());

        paragraph.set_bidi(true);
        assert!(paragraph.has_properties());

        paragraph.set_bidi(false);
        assert!(!paragraph.has_properties());
    }

    #[test]
    fn comment_range_start_ids_can_be_added_and_cleared() {
        let mut paragraph = Paragraph::new();
        assert!(paragraph.comment_range_start_ids().is_empty());

        paragraph.add_comment_range_start(1);
        paragraph.add_comment_range_start(5);
        assert_eq!(paragraph.comment_range_start_ids(), &[1, 5]);

        paragraph.clear_comment_range_starts();
        assert!(paragraph.comment_range_start_ids().is_empty());
    }

    #[test]
    fn comment_range_end_ids_can_be_added_and_cleared() {
        let mut paragraph = Paragraph::new();
        assert!(paragraph.comment_range_end_ids().is_empty());

        paragraph.add_comment_range_end(1);
        paragraph.add_comment_range_end(5);
        assert_eq!(paragraph.comment_range_end_ids(), &[1, 5]);

        paragraph.clear_comment_range_ends();
        assert!(paragraph.comment_range_end_ids().is_empty());
    }

    #[test]
    fn comment_reference_ids_can_be_added_and_cleared() {
        let mut paragraph = Paragraph::new();
        assert!(paragraph.comment_reference_ids().is_empty());

        paragraph.add_comment_reference(2);
        paragraph.add_comment_reference(8);
        assert_eq!(paragraph.comment_reference_ids(), &[2, 8]);

        paragraph.clear_comment_references();
        assert!(paragraph.comment_reference_ids().is_empty());
    }

    #[test]
    fn page_break_before_can_be_set_and_read() {
        let mut paragraph = Paragraph::new();
        assert!(!paragraph.page_break_before());

        paragraph.set_page_break_before(true);
        assert!(paragraph.page_break_before());
        assert!(paragraph.has_properties());

        paragraph.set_page_break_before(false);
        assert!(!paragraph.page_break_before());
        assert!(!paragraph.has_properties());
    }

    #[test]
    fn line_spacing_rule_can_be_set_and_cleared() {
        let mut paragraph = Paragraph::new();
        assert_eq!(paragraph.line_spacing_rule(), None);

        paragraph.set_line_spacing_rule(LineSpacingRule::Exact);
        assert_eq!(paragraph.line_spacing_rule(), Some(LineSpacingRule::Exact));
        assert!(paragraph.has_properties());

        paragraph.set_line_spacing_rule(LineSpacingRule::AtLeast);
        assert_eq!(
            paragraph.line_spacing_rule(),
            Some(LineSpacingRule::AtLeast)
        );

        paragraph.set_line_spacing_rule(LineSpacingRule::Auto);
        assert_eq!(paragraph.line_spacing_rule(), Some(LineSpacingRule::Auto));

        paragraph.clear_line_spacing_rule();
        assert_eq!(paragraph.line_spacing_rule(), None);
        assert!(!paragraph.has_properties());
    }

    #[test]
    fn line_spacing_rule_xml_roundtrip() {
        assert_eq!(
            LineSpacingRule::from_xml_value("auto"),
            Some(LineSpacingRule::Auto)
        );
        assert_eq!(
            LineSpacingRule::from_xml_value("exact"),
            Some(LineSpacingRule::Exact)
        );
        assert_eq!(
            LineSpacingRule::from_xml_value("atLeast"),
            Some(LineSpacingRule::AtLeast)
        );
        assert_eq!(LineSpacingRule::from_xml_value("invalid"), None);

        assert_eq!(LineSpacingRule::Auto.to_xml_value(), "auto");
        assert_eq!(LineSpacingRule::Exact.to_xml_value(), "exact");
        assert_eq!(LineSpacingRule::AtLeast.to_xml_value(), "atLeast");
    }

    #[test]
    fn outline_level_can_be_set_and_cleared() {
        let mut paragraph = Paragraph::new();
        assert_eq!(paragraph.outline_level(), None);

        paragraph.set_outline_level(0);
        assert_eq!(paragraph.outline_level(), Some(0));
        assert!(paragraph.has_properties());

        paragraph.set_outline_level(5);
        assert_eq!(paragraph.outline_level(), Some(5));

        paragraph.set_outline_level(9);
        assert_eq!(paragraph.outline_level(), Some(9));

        paragraph.clear_outline_level();
        assert_eq!(paragraph.outline_level(), None);
        assert!(!paragraph.has_properties());
    }

    #[test]
    fn outline_level_is_clamped_to_valid_range() {
        let mut paragraph = Paragraph::new();

        paragraph.set_outline_level(15);
        assert_eq!(paragraph.outline_level(), Some(9));

        paragraph.set_outline_level(255);
        assert_eq!(paragraph.outline_level(), Some(9));
    }

    #[test]
    fn contextual_spacing_can_be_set_and_read() {
        let mut paragraph = Paragraph::new();
        assert!(!paragraph.contextual_spacing());

        paragraph.set_contextual_spacing(true);
        assert!(paragraph.contextual_spacing());
        assert!(paragraph.has_properties());

        paragraph.set_contextual_spacing(false);
        assert!(!paragraph.contextual_spacing());
        assert!(!paragraph.has_properties());
    }
}
