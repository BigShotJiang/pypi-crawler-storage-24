use offidized_opc::RawXmlNode;

/// Metadata attached to a tracked revision (`w:ins`, `w:del`).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RevisionMetadata {
    /// Revision identifier (`w:id`).
    pub id: u32,
    /// Revision author (`w:author`).
    pub author: String,
    /// Optional revision timestamp (`w:date`) in ISO 8601 format.
    pub date: Option<String>,
}

impl RevisionMetadata {
    /// Create revision metadata with the given id and author.
    pub fn new(id: u32, author: impl Into<String>) -> Self {
        Self {
            id,
            author: author.into(),
            date: None,
        }
    }

    /// Create revision metadata with an explicit timestamp.
    pub fn with_date(id: u32, author: impl Into<String>, date: impl Into<String>) -> Self {
        Self {
            id,
            author: author.into(),
            date: Some(date.into()),
        }
    }
}

/// High-level tracked revision kind.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RevisionKind {
    /// Inserted content (`w:ins`).
    Insertion,
    /// Deleted content (`w:del`).
    Deletion,
    /// Move-from content (`w:moveFrom`).
    MoveFrom,
    /// Move-to content (`w:moveTo`).
    MoveTo,
    /// Property/format change metadata (`*PrChange`, `tblGridChange`).
    PropertyChange,
}

/// Summary of a tracked revision discovered in a document.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RevisionSummary {
    /// Revision identifier, if present.
    pub id: Option<u32>,
    /// Revision type.
    pub kind: RevisionKind,
    /// Revision author, if present.
    pub author: Option<String>,
    /// Revision timestamp, if present.
    pub date: Option<String>,
    /// Plain text carried by the revision.
    pub text: String,
    /// Human-readable location within the document.
    pub location: String,
}

/// Filter used for selective accept/reject operations.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct RevisionFilter {
    /// Restrict matching revisions to this author.
    pub author: Option<String>,
    /// Restrict matching revisions to these kinds. Empty means all kinds.
    pub kinds: Vec<RevisionKind>,
}

impl RevisionFilter {
    /// Match all revisions.
    pub fn all() -> Self {
        Self::default()
    }

    /// Match revisions authored by the given author.
    pub fn by_author(author: impl Into<String>) -> Self {
        Self {
            author: Some(author.into()),
            kinds: Vec::new(),
        }
    }

    /// Match only the provided revision kinds.
    pub fn with_kinds(kinds: Vec<RevisionKind>) -> Self {
        Self {
            author: None,
            kinds,
        }
    }

    pub(crate) fn matches(&self, kind: RevisionKind, author: Option<&str>) -> bool {
        if let Some(expected_author) = &self.author {
            if author != Some(expected_author.as_str()) {
                return false;
            }
        }
        self.kinds.is_empty() || self.kinds.contains(&kind)
    }
}

/// Counts of revisions transformed by accept/reject operations.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct RevisionTransformReport {
    /// Number of insertions processed.
    pub insertions: usize,
    /// Number of deletions processed.
    pub deletions: usize,
}

pub(crate) struct PropertyChildrenTransform {
    pub(crate) children: Vec<RawXmlNode>,
    pub(crate) restored_previous_state: bool,
}

pub(crate) fn build_inserted_text_node(text: &str, metadata: &RevisionMetadata) -> RawXmlNode {
    build_revision_node("w:ins", "w:t", text, metadata)
}

pub(crate) fn build_deleted_text_node(text: &str, metadata: &RevisionMetadata) -> RawXmlNode {
    build_revision_node("w:del", "w:delText", text, metadata)
}

pub(crate) fn build_move_from_range_end_node(id: u32) -> RawXmlNode {
    build_revision_marker_node("w:moveFromRangeEnd", id)
}

pub(crate) fn build_move_to_range_end_node(id: u32) -> RawXmlNode {
    build_revision_marker_node("w:moveToRangeEnd", id)
}

pub(crate) fn collect_revision_summaries(
    node: &RawXmlNode,
    location: &str,
    summaries: &mut Vec<RevisionSummary>,
) {
    if let Some(kind) = revision_kind_for_node(node) {
        let (id, author, date) = revision_metadata_from_node(node);
        let mut text = collect_text(node);
        if text.is_empty() {
            if let RawXmlNode::Element { name, .. } = node {
                let local = local_name(name);
                if kind == RevisionKind::PropertyChange || is_move_range_marker_name(local) {
                    text = local.to_string();
                }
            }
        }
        summaries.push(RevisionSummary {
            id,
            kind,
            author,
            date,
            text,
            location: location.to_string(),
        });
    }

    if let RawXmlNode::Element { children, .. } = node {
        for child in children {
            collect_revision_summaries(child, location, summaries);
        }
    }
}

pub(crate) fn max_revision_id(node: &RawXmlNode) -> u32 {
    let mut max_id = 0_u32;
    if let Some(id) = revision_metadata_from_node(node).0 {
        max_id = id;
    }
    if let RawXmlNode::Element { children, .. } = node {
        for child in children {
            max_id = max_id.max(max_revision_id(child));
        }
    }
    max_id
}

pub(crate) fn accept_revision_node(
    node: RawXmlNode,
    report: &mut RevisionTransformReport,
) -> Vec<RawXmlNode> {
    transform_revision_node(node, true, None, report)
}

pub(crate) fn accept_revision_node_filtered(
    node: RawXmlNode,
    filter: &RevisionFilter,
    report: &mut RevisionTransformReport,
) -> Vec<RawXmlNode> {
    transform_revision_node(node, true, Some(filter), report)
}

pub(crate) fn reject_revision_node(
    node: RawXmlNode,
    report: &mut RevisionTransformReport,
) -> Vec<RawXmlNode> {
    transform_revision_node(node, false, None, report)
}

pub(crate) fn reject_revision_node_filtered(
    node: RawXmlNode,
    filter: &RevisionFilter,
    report: &mut RevisionTransformReport,
) -> Vec<RawXmlNode> {
    transform_revision_node(node, false, Some(filter), report)
}

pub(crate) fn transform_property_container_children(
    container_local_name: &str,
    children: Vec<RawXmlNode>,
    accept: bool,
    filter: Option<&RevisionFilter>,
    report: &mut RevisionTransformReport,
) -> PropertyChildrenTransform {
    if !accept {
        let matched_snapshot = children.iter().rev().find_map(|child| {
            let author = property_change_author(child);
            (matches_property_change_node(child, container_local_name)
                && filter.is_none_or(|filter| filter.matches(RevisionKind::PropertyChange, author)))
            .then(|| snapshot_children_from_property_change(child, container_local_name))
            .flatten()
        });

        if let Some(snapshot_children) = matched_snapshot {
            return PropertyChildrenTransform {
                children: snapshot_children
                    .into_iter()
                    .flat_map(|child| transform_revision_node(child, accept, filter, report))
                    .collect(),
                restored_previous_state: true,
            };
        }
    }

    let mut transformed_children = Vec::new();
    for child in children {
        let author = property_change_author(&child);
        if matches_property_change_node(&child, container_local_name)
            && filter.is_none_or(|filter| filter.matches(RevisionKind::PropertyChange, author))
        {
            if accept {
                continue;
            }
            transformed_children.push(child);
            continue;
        }
        transformed_children.extend(transform_revision_node(child, accept, filter, report));
    }

    PropertyChildrenTransform {
        children: transformed_children,
        restored_previous_state: false,
    }
}

fn build_revision_marker_node(name: &str, id: u32) -> RawXmlNode {
    RawXmlNode::Element {
        name: name.to_string(),
        attributes: vec![("w:id".to_string(), id.to_string())],
        children: Vec::new(),
    }
}

fn build_revision_node(
    revision_name: &str,
    text_name: &str,
    text: &str,
    metadata: &RevisionMetadata,
) -> RawXmlNode {
    let mut revision_attributes = vec![
        ("w:id".to_string(), metadata.id.to_string()),
        ("w:author".to_string(), metadata.author.clone()),
    ];
    if let Some(date) = &metadata.date {
        revision_attributes.push(("w:date".to_string(), date.clone()));
    }

    let mut text_attributes = Vec::new();
    if text.starts_with(' ') || text.ends_with(' ') {
        text_attributes.push(("xml:space".to_string(), "preserve".to_string()));
    }

    RawXmlNode::Element {
        name: revision_name.to_string(),
        attributes: revision_attributes,
        children: vec![RawXmlNode::Element {
            name: "w:r".to_string(),
            attributes: Vec::new(),
            children: vec![RawXmlNode::Element {
                name: text_name.to_string(),
                attributes: text_attributes,
                children: vec![RawXmlNode::Text(text.to_string())],
            }],
        }],
    }
}

fn revision_kind_for_node(node: &RawXmlNode) -> Option<RevisionKind> {
    match node {
        RawXmlNode::Element { name, .. } if local_name(name) == "ins" => {
            Some(RevisionKind::Insertion)
        }
        RawXmlNode::Element { name, .. } if local_name(name) == "del" => {
            Some(RevisionKind::Deletion)
        }
        RawXmlNode::Element { name, .. }
            if matches!(
                local_name(name),
                "moveFrom" | "moveFromRangeStart" | "moveFromRangeEnd"
            ) =>
        {
            Some(RevisionKind::MoveFrom)
        }
        RawXmlNode::Element { name, .. }
            if matches!(
                local_name(name),
                "moveTo" | "moveToRangeStart" | "moveToRangeEnd"
            ) =>
        {
            Some(RevisionKind::MoveTo)
        }
        RawXmlNode::Element { name, .. } if is_property_change_name(local_name(name)) => {
            Some(RevisionKind::PropertyChange)
        }
        _ => None,
    }
}

fn transform_revision_node(
    node: RawXmlNode,
    accept: bool,
    filter: Option<&RevisionFilter>,
    report: &mut RevisionTransformReport,
) -> Vec<RawXmlNode> {
    match node {
        RawXmlNode::Element {
            name,
            attributes,
            children,
        } => match local_name(name.as_str()) {
            "ins" => {
                let author = attributes
                    .iter()
                    .find(|(key, _)| local_name(key.as_str()) == "author")
                    .map(|(_, value)| value.as_str());
                if filter.is_some_and(|filter| !filter.matches(RevisionKind::Insertion, author)) {
                    return vec![RawXmlNode::Element {
                        name,
                        attributes,
                        children,
                    }];
                }
                report.insertions = report.insertions.saturating_add(1);
                if accept {
                    children
                } else {
                    Vec::new()
                }
            }
            "del" => {
                let author = attributes
                    .iter()
                    .find(|(key, _)| local_name(key.as_str()) == "author")
                    .map(|(_, value)| value.as_str());
                if filter.is_some_and(|filter| !filter.matches(RevisionKind::Deletion, author)) {
                    return vec![RawXmlNode::Element {
                        name,
                        attributes,
                        children,
                    }];
                }
                report.deletions = report.deletions.saturating_add(1);
                if accept {
                    Vec::new()
                } else {
                    children
                        .into_iter()
                        .map(rewrite_deleted_content_for_rejection)
                        .collect()
                }
            }
            "moveFrom" => {
                let author = attributes
                    .iter()
                    .find(|(key, _)| local_name(key.as_str()) == "author")
                    .map(|(_, value)| value.as_str());
                if filter.is_some_and(|filter| !filter.matches(RevisionKind::MoveFrom, author)) {
                    return vec![RawXmlNode::Element {
                        name,
                        attributes,
                        children,
                    }];
                }
                report.deletions = report.deletions.saturating_add(1);
                if accept {
                    Vec::new()
                } else {
                    children
                        .into_iter()
                        .map(rewrite_deleted_content_for_rejection)
                        .collect()
                }
            }
            "moveTo" => {
                let author = attributes
                    .iter()
                    .find(|(key, _)| local_name(key.as_str()) == "author")
                    .map(|(_, value)| value.as_str());
                if filter.is_some_and(|filter| !filter.matches(RevisionKind::MoveTo, author)) {
                    return vec![RawXmlNode::Element {
                        name,
                        attributes,
                        children,
                    }];
                }
                report.insertions = report.insertions.saturating_add(1);
                if accept {
                    children
                } else {
                    Vec::new()
                }
            }
            "moveFromRangeStart" | "moveFromRangeEnd" => {
                if filter.is_some_and(|filter| !filter.matches(RevisionKind::MoveFrom, None)) {
                    return vec![RawXmlNode::Element {
                        name,
                        attributes,
                        children,
                    }];
                }
                Vec::new()
            }
            "moveToRangeStart" | "moveToRangeEnd" => {
                if filter.is_some_and(|filter| !filter.matches(RevisionKind::MoveTo, None)) {
                    return vec![RawXmlNode::Element {
                        name,
                        attributes,
                        children,
                    }];
                }
                Vec::new()
            }
            _ if is_property_container_name(local_name(name.as_str())) => {
                let transformed = transform_property_container_children(
                    local_name(name.as_str()),
                    children,
                    accept,
                    filter,
                    report,
                );
                vec![RawXmlNode::Element {
                    name,
                    attributes,
                    children: transformed.children,
                }]
            }
            _ => vec![RawXmlNode::Element {
                name,
                attributes,
                children: children
                    .into_iter()
                    .flat_map(|child| transform_revision_node(child, accept, filter, report))
                    .collect(),
            }],
        },
        other => vec![other],
    }
}

fn rewrite_deleted_content_for_rejection(node: RawXmlNode) -> RawXmlNode {
    match node {
        RawXmlNode::Element {
            name,
            attributes,
            children,
        } => {
            let rewritten_name = if local_name(name.as_str()) == "delText" {
                if let Some((prefix, _)) = name.rsplit_once(':') {
                    format!("{prefix}:t")
                } else {
                    "t".to_string()
                }
            } else {
                name
            };
            let rewritten_attributes = attributes
                .into_iter()
                .filter(|(key, _)| local_name(key.as_str()) != "rsidDel")
                .collect();
            let rewritten_children = children
                .into_iter()
                .map(rewrite_deleted_content_for_rejection)
                .collect();
            RawXmlNode::Element {
                name: rewritten_name,
                attributes: rewritten_attributes,
                children: rewritten_children,
            }
        }
        other => other,
    }
}

fn is_property_container_name(name: &str) -> bool {
    matches!(name, "pPr" | "rPr" | "tblPr" | "tcPr" | "trPr" | "sectPr")
}

fn is_move_range_marker_name(name: &str) -> bool {
    matches!(
        name,
        "moveFromRangeStart" | "moveFromRangeEnd" | "moveToRangeStart" | "moveToRangeEnd"
    )
}

fn matches_property_change_node(node: &RawXmlNode, container_local_name: &str) -> bool {
    let RawXmlNode::Element { name, .. } = node else {
        return false;
    };
    local_name(name.as_str()) == format!("{container_local_name}Change")
}

fn property_change_author(node: &RawXmlNode) -> Option<&str> {
    let RawXmlNode::Element { attributes, .. } = node else {
        return None;
    };
    attributes
        .iter()
        .find(|(key, _)| local_name(key.as_str()) == "author")
        .map(|(_, value)| value.as_str())
}

fn snapshot_children_from_property_change(
    node: &RawXmlNode,
    container_local_name: &str,
) -> Option<Vec<RawXmlNode>> {
    let RawXmlNode::Element { children, .. } = node else {
        return None;
    };
    children.iter().find_map(|child| {
        let RawXmlNode::Element { name, children, .. } = child else {
            return None;
        };
        (local_name(name.as_str()) == container_local_name).then(|| children.clone())
    })
}

fn revision_metadata_from_node(node: &RawXmlNode) -> (Option<u32>, Option<String>, Option<String>) {
    let RawXmlNode::Element { attributes, .. } = node else {
        return (None, None, None);
    };

    let mut id = None;
    let mut author = None;
    let mut date = None;

    for (key, value) in attributes {
        match local_name(key) {
            "id" => id = value.parse::<u32>().ok(),
            "author" => author = Some(value.clone()),
            "date" => date = Some(value.clone()),
            _ => {}
        }
    }

    (id, author, date)
}

fn collect_text(node: &RawXmlNode) -> String {
    match node {
        RawXmlNode::Text(text) | RawXmlNode::CData(text) => text.clone(),
        RawXmlNode::Element { children, .. } => {
            let mut text = String::new();
            for child in children {
                text.push_str(collect_text(child).as_str());
            }
            text
        }
        RawXmlNode::RawBytes(_) => String::new(),
    }
}

fn is_property_change_name(name: &str) -> bool {
    name.ends_with("PrChange") || matches!(name, "tblGridChange")
}

fn local_name(name: &str) -> &str {
    name.rsplit(':').next().unwrap_or(name)
}

#[cfg(test)]
mod tests {
    use offidized_opc::RawXmlNode;

    use super::{
        build_deleted_text_node, build_inserted_text_node, collect_revision_summaries,
        max_revision_id, transform_property_container_children, RevisionKind, RevisionMetadata,
        RevisionTransformReport,
    };

    #[test]
    fn inserted_revision_node_contains_metadata_and_text() {
        let meta = RevisionMetadata::with_date(7, "Reviewer", "2026-03-24T12:00:00Z");
        let node = build_inserted_text_node(" Added", &meta);
        let mut summaries = Vec::new();
        collect_revision_summaries(&node, "body/paragraph:0", &mut summaries);
        assert_eq!(summaries.len(), 1);
        assert_eq!(summaries[0].id, Some(7));
        assert_eq!(summaries[0].kind, RevisionKind::Insertion);
        assert_eq!(summaries[0].author.as_deref(), Some("Reviewer"));
        assert_eq!(summaries[0].date.as_deref(), Some("2026-03-24T12:00:00Z"));
        assert_eq!(summaries[0].text, " Added");
        assert_eq!(max_revision_id(&node), 7);
    }

    #[test]
    fn deleted_revision_node_contains_metadata_and_text() {
        let meta = RevisionMetadata::new(9, "Reviewer");
        let node = build_deleted_text_node("Removed", &meta);
        let mut summaries = Vec::new();
        collect_revision_summaries(&node, "body/paragraph:1", &mut summaries);
        assert_eq!(summaries.len(), 1);
        assert_eq!(summaries[0].kind, RevisionKind::Deletion);
        assert_eq!(summaries[0].text, "Removed");
        assert_eq!(summaries[0].location, "body/paragraph:1");
    }

    #[test]
    fn property_change_revision_summary_uses_element_name_when_no_text() {
        let node = RawXmlNode::Element {
            name: "w:rPrChange".to_string(),
            attributes: vec![
                ("w:id".to_string(), "11".to_string()),
                ("w:author".to_string(), "Reviewer".to_string()),
            ],
            children: vec![RawXmlNode::Element {
                name: "w:rPr".to_string(),
                attributes: Vec::new(),
                children: vec![RawXmlNode::Element {
                    name: "w:b".to_string(),
                    attributes: Vec::new(),
                    children: Vec::new(),
                }],
            }],
        };
        let mut summaries = Vec::new();
        collect_revision_summaries(&node, "body/paragraph:0", &mut summaries);
        assert_eq!(summaries.len(), 1);
        assert_eq!(summaries[0].kind, RevisionKind::PropertyChange);
        assert_eq!(summaries[0].text, "rPrChange");
        assert_eq!(max_revision_id(&node), 11);
    }

    #[test]
    fn move_revision_summary_reports_move_kind_and_text() {
        let node = RawXmlNode::Element {
            name: "w:moveTo".to_string(),
            attributes: vec![
                ("w:id".to_string(), "12".to_string()),
                ("w:author".to_string(), "Reviewer".to_string()),
            ],
            children: vec![RawXmlNode::Element {
                name: "w:r".to_string(),
                attributes: Vec::new(),
                children: vec![RawXmlNode::Element {
                    name: "w:t".to_string(),
                    attributes: Vec::new(),
                    children: vec![RawXmlNode::Text("Moved".to_string())],
                }],
            }],
        };
        let mut summaries = Vec::new();
        collect_revision_summaries(&node, "body/paragraph:0", &mut summaries);
        assert_eq!(summaries.len(), 1);
        assert_eq!(summaries[0].kind, RevisionKind::MoveTo);
        assert_eq!(summaries[0].text, "Moved");
        assert_eq!(max_revision_id(&node), 12);
    }

    #[test]
    fn move_range_marker_summary_uses_marker_name() {
        let node = RawXmlNode::Element {
            name: "w:moveFromRangeStart".to_string(),
            attributes: vec![("w:id".to_string(), "15".to_string())],
            children: Vec::new(),
        };
        let mut summaries = Vec::new();
        collect_revision_summaries(&node, "body/paragraph:0", &mut summaries);
        assert_eq!(summaries.len(), 1);
        assert_eq!(summaries[0].kind, RevisionKind::MoveFrom);
        assert_eq!(summaries[0].text, "moveFromRangeStart");
        assert_eq!(max_revision_id(&node), 15);
    }

    #[test]
    fn rejecting_property_change_restores_snapshot_children() {
        let mut report = RevisionTransformReport::default();
        let transformed = transform_property_container_children(
            "rPr",
            vec![RawXmlNode::Element {
                name: "w:rPrChange".to_string(),
                attributes: vec![("w:author".to_string(), "Reviewer".to_string())],
                children: vec![RawXmlNode::Element {
                    name: "w:rPr".to_string(),
                    attributes: Vec::new(),
                    children: vec![RawXmlNode::Element {
                        name: "w:i".to_string(),
                        attributes: Vec::new(),
                        children: Vec::new(),
                    }],
                }],
            }],
            false,
            None,
            &mut report,
        );
        assert!(transformed.restored_previous_state);
        assert_eq!(transformed.children.len(), 1);
        assert!(matches!(
            &transformed.children[0],
            RawXmlNode::Element { name, .. } if name == "w:i"
        ));
    }
}
