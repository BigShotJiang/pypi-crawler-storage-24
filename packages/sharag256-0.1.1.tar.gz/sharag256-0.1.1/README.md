# Sharag256

Custom hashing algorithm combining SHA-256 compression with complex mathematical randomization.

## Installation
```bash
pip install sharag256
