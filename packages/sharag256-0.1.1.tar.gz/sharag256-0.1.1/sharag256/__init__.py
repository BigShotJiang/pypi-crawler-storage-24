from .core import patentmethod

__version__ = "0.1.0"
__all__ = ['patentmethod']
