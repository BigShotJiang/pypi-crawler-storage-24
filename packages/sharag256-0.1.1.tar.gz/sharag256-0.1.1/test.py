from sharag256 import patentmethod
import time

# Your original test
message = "anantehucnjldsnciejur380480-2=@#459mo-dlsanantehucnjldsnciejur380480-2=@#459mo-dlsgauranshi003003lavyabirthdayllllllllllanantehucnjldsnciejur380480-2=@#459mo-dlsanantehucnjldsnciejur380480-2=@#459mo-dlsgauranshi003003lavyabirthdayllllllllll"
start_time = time.time()
hashed = patentmethod(message)
end_time = time.time()

print("✅ Package installed successfully!")
print("Message length:", len(message))
print("Hash:", hashed)
print("Length:", len(hashed))
print("Time (ns):", (end_time - start_time) * 1e9)

# More tests
test_cases = [
    "hello",
    "1234567890abcdef",
    b"binary\x00data",  # Bytes input
    ""  # Empty string
]

for i, test in enumerate(test_cases, 1):
    result = patentmethod(test)
    print(f"\nTest {i}: '{test}' → {result[:16]}...")
