class SnapchatAuthError(Exception):
    """Raised when there is an authentication error with Snapchat API"""
    pass

class SnapchatApiError(Exception):
    """Raised when there is a general API error with Snapchat API"""
    pass
