SNAPCHAT_SERVER_URL = "https://adsapi.snapchat.com/v1"
SNAPCHAT_OAUTH_CREDENTIALS_KIND = "snapchat-oauth-credentials"
SNAPCHAT_TOKEN_URL = "https://accounts.snapchat.com/login/oauth2/access_token"
