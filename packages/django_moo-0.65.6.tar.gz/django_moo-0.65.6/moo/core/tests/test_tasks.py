import logging
import warnings
import pytest
from django.test import override_settings

from .. import code, tasks
from ..models import Object, Verb


@pytest.mark.django_db(transaction=True, reset_sequences=True)
def test_simple_async_verb(t_init: Object, t_wizard: Object, caplog: pytest.LogCaptureFixture):
    printed = []

    def _writer(msg):
        printed.append(msg)

    verb = Verb.objects.get(names__name="test-async-verbs")
    verb.invoked_name = "test-async-verbs"
    verb.invoked_object = verb.origin
    with caplog.at_level(logging.INFO, "moo.core.tasks.background"):
        with code.ContextManager(t_wizard, _writer):
            verb()
    assert printed == [1]
    counter = 1
    for line in caplog.text.split("\n"):
        # Celery just loves emitting this when using the in-memory test broker, so ignore it
        if line.endswith("Reverting to default 'localhost'"):
            continue
        if not line:
            continue
        if "succeeded in" in line:
            continue
        counter += 1
        assert line.endswith(str(counter))


@pytest.mark.django_db(transaction=True, reset_sequences=True)
def test_simple_async_verb_callback(t_init: Object, t_wizard: Object, caplog: pytest.LogCaptureFixture):
    verb = Verb.objects.get(names__name="test-async-verb")
    callback = Verb.objects.get(names__name="test-async-verb-callback")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=RuntimeWarning)
        with caplog.at_level(logging.INFO, "moo.core.tasks.background"):
            tasks.invoke_verb(caller_id=t_wizard.pk, this_id=verb.origin.pk, verb_name=verb.name(), callback_verb_name=callback.name(), callback_this_id=callback.origin.pk)
    counter = 0
    for line in caplog.text.split("\n"):
        # Celery just loves emitting this when using the in-memory test broker, so ignore it
        if line.endswith("Reverting to default 'localhost'"):
            continue
        if not line:
            continue
        if "succeeded in" in line:
            continue
        counter += 1
        assert line.endswith(str(counter))
