"""MCP server — composition root.

Wires: SqlitePageRepository + ObsidianVaultStore + SqliteEmbeddingStore
→ PageService, LinkService, SearchService, GraphService
→ MCP tools
"""
import re
import struct
import subprocess

from mcp.server.fastmcp import FastMCP

from locram.adapters.db import init_db
from locram.adapters.ollama_provider import OllamaEmbeddingProvider
from locram.adapters.sqlite_embedding_store import SqliteEmbeddingStore
from locram.adapters.sqlite_page_repo import SqlitePageRepository
from locram.config import (
    LOCRAM_EMBED_MODEL,
    LOCRAM_EMBED_PROVIDER,
    LOCRAM_EMBED_URL,
)
from locram.interfaces.embedding_provider import EmbeddingProvider
from locram.models.page import Page
from locram.services.graph_service import GraphService
from locram.services.link_service import LinkService
from locram.services.page_service import PageService
from locram.services.search_service import SearchService
from locram.vault.attachments import get_attachment as _get_attachment
from locram.vault.attachments import save_attachment as _save_attachment
from locram.vault.mermaid import render_mermaid as _render_mermaid
from locram.vault.writer import ObsidianVaultStore

init_db()

_repo    = SqlitePageRepository()
_vault   = ObsidianVaultStore()
_embed   = SqliteEmbeddingStore()
_pages   = PageService(_repo, _vault)
_links   = LinkService(_repo, _vault)
_graph   = GraphService(_repo)


_provider: EmbeddingProvider | None = (
    OllamaEmbeddingProvider(base_url=LOCRAM_EMBED_URL, model=LOCRAM_EMBED_MODEL)
    if LOCRAM_EMBED_PROVIDER.lower() == "ollama" and LOCRAM_EMBED_MODEL
    else None
)
_search   = SearchService(_repo, embedding_store=_embed, provider=_provider)

_vault.setup_obsidian()

mcp = FastMCP(
    "locram",
    instructions="""locram is a local Zettelkasten knowledge base (SQLite + Obsidian vault).

## Note types
- fleeting   : quick raw capture (default)
- note-taking: structured note, being refined
- permanent  : finished atomic idea — ONE idea per note
- structure  : Map of Content — organises a topic via links (not maturity)
- hub        : domain entry point — links to structure notes (not maturity)

## Link types (12, directional with auto-inverse)
- related         → symmetric
- extends / extended_by
- supports / supported_by
- contradicts / contradicted_by
- refines / refined_by
- questions / questioned_by
- reference       → unidirectional (no inverse)

## Graph navigation
When get_page returns connected_to or sub_items — call get_page on those IDs
to explore the knowledge graph.

## inline_mentions
[[wikilinks]] in note content are resolved at read time (derived, not stored).
""",
)


@mcp.tool()
def create_page(
    title: str,
    content: str = "",
    type: str = "fleeting",
    subject: list[str] | None = None,
    tags: list[str] | None = None,
    parent_id: str | None = None,
    review_interval_days: int = 7,
) -> dict:
    """Create a new note in the Zettelkasten."""
    page = _pages.create_page(
        title=title, content=content, type=type,
        subject=subject, tags=tags, parent_id=parent_id,
        review_interval_days=review_interval_days,
    )
    return page_to_dict(page)


@mcp.tool()
def get_page(identifier: str) -> dict:
    """Get a note with full graph context (parent, sub_items, connected_to, inline_mentions).

    identifier: page_id (ULID) or exact page title. If a title matches multiple pages,
    returns an error asking to use page_id instead.
    """
    try:
        page = _pages.get_page_by_identifier(identifier)
    except ValueError as e:
        return {"error": str(e)}
    if page is None:
        return {"error": f"Page '{identifier}' not found"}
    return page_to_dict(page)


@mcp.tool()
def update_page(
    page_id: str,
    title: str | None = None,
    content: str | None = None,
    type: str | None = None,
    status: str | None = None,
    subject: list[str] | None = None,
    tags: list[str] | None = None,
    parent_id: str | None = None,
    review_interval_days: int | None = None,
) -> dict:
    """Partially update a note. Only provided fields are changed.

    Pass only the fields you want to update — omitted fields are unchanged.
    """
    fields = {
        k: v for k, v in {
            "title": title,
            "content": content,
            "type": type,
            "status": status,
            "subject": subject,
            "tags": tags,
            "parent_id": parent_id,
            "review_interval_days": review_interval_days,
        }.items() if v is not None
    }
    if not fields:
        return {"error": "No fields to update"}
    page = _pages.update_page(page_id, **fields)
    if page is None:
        return {"error": f"Page {page_id} not found"}
    return page_to_dict(page)


@mcp.tool()
def delete_page(page_id: str, hard: bool = False) -> dict:
    """Delete a note. Default: soft delete (status=to_delete). hard=True: permanent."""
    ok = _pages.delete_page(page_id, hard=hard)
    return {"deleted": ok, "hard": hard}


@mcp.tool()
def list_pages(
    status: str | None = None,
    type: str | None = None,
    subject: str | None = None,
    tag: str | None = None,
    since_days: int | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[dict]:
    """List notes with optional filters.

    since_days: filter to pages updated in the last N days.
    Useful for reviewing recent captures (e.g. since_days=7 for last week).
    """
    return _pages.list_pages(
        status=status, type=type, subject=subject,
        tag=tag, since_days=since_days, limit=limit, offset=offset,
    )


@mcp.tool()
def search(query: str, limit: int = 20) -> list[dict]:
    """Full-text search (FTS5 BM25) across title and content."""
    return _search.search(query, limit=limit)


@mcp.tool()
def replace_in_page(page_id: str, old_text: str, new_text: str) -> dict:
    """Find-and-replace exact text fragment in note content."""
    page = _repo.get(page_id)
    if page is None:
        return {"error": f"Page {page_id} not found"}
    if old_text not in page.content:
        return {"error": "Text not found in page content"}
    new_content = page.content.replace(old_text, new_text, 1)
    _pages.update_page(page_id, content=new_content)
    return {"updated": True, "id": page_id}


@mcp.tool()
def update_section(page_id: str, heading: str, new_content: str) -> dict:
    """Replace a markdown section (identified by heading) with new content."""
    page = _repo.get(page_id)
    if page is None:
        return {"error": f"Page {page_id} not found"}

    pattern = rf"(#+\s*{re.escape(heading)}\s*\n)(.*?)(?=\n#+\s|\Z)"
    if not re.search(pattern, page.content, re.DOTALL):
        return {"error": f"Section '{heading}' not found"}

    new_body = re.sub(
        pattern,
        lambda m: m.group(1) + new_content + "\n",
        page.content,
        count=1,
        flags=re.DOTALL,
    )
    _pages.update_page(page_id, content=new_body)
    return {"updated": True, "id": page_id}


@mcp.tool()
def link_pages(
    source_id: str,
    target_id: str,
    link_type: str = "related",
) -> dict:
    """Create a typed directional link. Auto-creates inverse if applicable.

    link_type: related | extends | extended_by | supports | supported_by |
               contradicts | contradicted_by | refines | refined_by |
               questions | questioned_by | reference
    """
    return _links.link_pages(source_id, target_id, link_type)


@mcp.tool()
def unlink_pages(
    source_id: str,
    target_id: str,
    link_type: str | None = None,
) -> dict:
    """Remove link(s). link_type=None removes all links between the pair."""
    return _links.unlink_pages(source_id, target_id, link_type)


@mcp.tool()
def set_parent(child_id: str, parent_id: str | None) -> dict:
    """Set or clear the vertical parent of a note."""
    return _links.set_parent(child_id, parent_id)


@mcp.tool()
def batch_link(links: list[dict]) -> dict:
    """Create multiple typed links in one call.

    links: [{source_id, target_id, link_type}, ...]
    Returns: {created: int, skipped: int, errors: list[str]}
    """
    return _links.batch_link(links)


@mcp.tool()
def find_orphaned_notes(limit: int = 50) -> list[dict]:
    """Notes with zero links and no parent — candidates for connecting."""
    return _graph.find_orphaned(limit=limit)


@mcp.tool()
def find_central_notes(limit: int = 20) -> list[dict]:
    """Most-linked notes — hub ideas in the knowledge graph."""
    return _graph.find_central(limit=limit)


@mcp.tool()
def find_similar_notes(page_id: str, limit: int = 10) -> list[dict]:
    """Find note-to-note neighbors.

    Uses semantic nearest neighbors when the note has a current-model content embedding.
    Falls back to lexical title-based FTS similarity otherwise.
    Returns hits annotated with sources=['semantic'] or sources=['fts'].
    """
    return _search.find_similar(page_id, limit=limit)


@mcp.tool()
def find_due_for_review(limit: int = 50) -> list[dict]:
    """Notes past their review date — for night agent maintenance."""
    return _graph.find_due_for_review(limit=limit)


@mcp.tool()
def get_graph_summary(limit: int = 500) -> dict:
    """Graph stats + topology: page count, type distribution, all pages and links.
    Hard limit: 500 pages. Set limit lower for faster response."""
    return _graph.get_graph_summary(limit=limit)


@mcp.tool()
def promote_page(page_id: str) -> dict:
    """Promote note maturity: fleeting → note-taking → permanent.
    Cannot promote structure/hub (classification types — use update_page instead).
    Cannot demote."""
    return _pages.promote_page(page_id)


@mcp.tool()
def mark_reviewed(page_id: str) -> dict:
    """Mark a note as reviewed without changing its content.

    Call this after reviewing a note and confirming it is accurate and up to date.
    Resets the review countdown: next_review_at = now + review_interval_days.
    Use find_due_for_review to get the review queue.
    """
    return _pages.mark_reviewed(page_id)


@mcp.tool()
def get_attachment(filename: str) -> dict:
    """Read a file from vault/attachments/ and return base64-encoded content."""
    data = _get_attachment(filename)
    if data is None:
        return {"error": f"Attachment '{filename}' not found"}
    return {"filename": filename, "data_b64": data}


@mcp.tool()
def save_attachment(filename: str, data_b64: str) -> dict:
    """Save a base64-encoded file to vault/attachments/."""
    path = _save_attachment(filename, data_b64)
    return {"saved": True, "path": str(path)}


@mcp.tool()
def render_mermaid(name: str, diagram: str, output_format: str = "svg") -> dict:
    """Render a Mermaid diagram to vault/attachments/<name>.<output_format>.

    name: plain filename stem — no extension, no path separators (e.g. 'my-diagram').
    diagram: Mermaid diagram text without the ```mermaid fences.
    output_format: 'svg' (default) or 'png'.

    The rendered file is saved to vault/attachments/ and can be embedded in a note
    as ![[<name>.<output_format>]].
    Requires mmdc on PATH: npm install -g @mermaid-js/mermaid-cli
    """
    try:
        path = _render_mermaid(diagram, name, output_format)
        return {
            "rendered": True,
            "path": str(path),
            "filename": path.name,
            "embed": f"![[{path.name}]]",
        }
    except FileNotFoundError as error:
        return {"error": str(error)}
    except subprocess.TimeoutExpired as timeout_error:
        return {"error": f"mmdc timed out after {timeout_error.timeout}s"}
    except (ValueError, RuntimeError) as error:
        return {"error": str(error)}


@mcp.tool()
def store_embedding(
    page_id: str,
    embedding: list[float],
    model: str,
    field: str = "content",
) -> dict:
    """Store an embedding vector for a page field.

    field: 'content' | 'meta' | 'summary'
    One active model per field (UPSERT — replaces previous vector).
    """
    raw = struct.pack(f"<{len(embedding)}f", *embedding)
    _embed.store(page_id, field, raw, model, len(embedding))
    return {"stored": True, "page_id": page_id, "field": field, "dimension": len(embedding)}


@mcp.tool()
def find_unembedded(limit: int = 100, model: str | None = None) -> list[str]:
    """List page IDs needing embedding.

    Without model: returns pages with no content embedding at all (any model).
    With model (or auto-detected from LOCRAM_EMBED_MODEL): returns pages missing
    or stale for that specific model — safe to use after switching models.
    """
    effective_model = model or LOCRAM_EMBED_MODEL or None
    return _embed.find_unembedded(limit=limit, model=effective_model)


@mcp.tool()
def find_stale_embeddings(model: str, limit: int = 100) -> list[str]:
    """List active page IDs with missing or outdated embeddings for a given model."""
    return _embed.find_stale_embeddings(model=model, limit=limit)


@mcp.tool()
def semantic_search(query: str, limit: int = 20) -> dict:
    """Vector-only retrieval over embedded notes.

    Returns results ranked by cosine distance, coverage metadata, and an optional
    warning when the DB contains embeddings from a different model.
    Requires LOCRAM_EMBED_PROVIDER=ollama, LOCRAM_EMBED_URL, LOCRAM_EMBED_MODEL.
    """
    return _search.semantic_search(query, limit=limit)


@mcp.tool()
def hybrid_search(query: str, limit: int = 20) -> dict:
    """FTS5 + vector retrieval merged with Reciprocal Rank Fusion.

    Falls back to lexical-only results when semantic capability is not configured.
    Returns merged results with sources=['fts','semantic'], coverage metadata,
    and an optional model-mismatch warning.
    """
    return _search.hybrid_search(query, limit=limit)


def page_to_dict(page: Page) -> dict:
    return {
        "id":                   page.id,
        "title":                page.title,
        "content":              page.content,
        "type":                 page.type.value,
        "status":               page.status.value,
        "subject":              page.subject,
        "tags":                 page.tags,
        "parent_id":            page.parent_id,
        "content_hash":         page.content_hash,
        "review_interval_days": page.review_interval_days,
        "reviewed_at":          page.reviewed_at,
        "created_at":           page.created_at,
        "updated_at":           page.updated_at,
        "parent":               page.parent,
        "sub_items":            page.sub_items,
        "connected_to":         page.connected_to,
        "inline_mentions":      page.inline_mentions,
        "next_review_at":       page.next_review_at,
    }


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
