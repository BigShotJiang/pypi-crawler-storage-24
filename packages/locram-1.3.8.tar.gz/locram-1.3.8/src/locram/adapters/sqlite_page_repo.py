import hashlib
import json
import sqlite3
from datetime import UTC, datetime
from pathlib import Path

from ulid import ULID

from locram.adapters.db import get_connection
from locram.config import DB_PATH
from locram.interfaces.page_repository import PageRepository
from locram.models.enums import LinkType, PageStatus, PageType
from locram.models.link import Link
from locram.models.page import Page


def now_iso() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def content_hash(content: str) -> str:
    return hashlib.md5(content.encode()).hexdigest()


def safe_fts_query(query: str) -> str:
    """Escape arbitrary user input into a safe FTS5 phrase query."""
    escaped = query.replace('"', '""').strip()
    return f'"{escaped}"'


class SqlitePageRepository(PageRepository):

    def __init__(self, db_path: Path = DB_PATH) -> None:
        self._db_path = db_path

    @property
    def db_path(self) -> Path:
        return self._db_path

    def _row_to_page(self, row: sqlite3.Row) -> Page:
        return Page(
            id=row["id"],
            title=row["title"],
            content=row["content"],
            type=PageType(row["type"]),
            status=PageStatus(row["status"]),
            subject=json.loads(row["subject"]),
            tags=json.loads(row["tags"]),
            parent_id=row["parent_id"],
            content_hash=row["content_hash"],
            review_interval_days=row["review_interval_days"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            reviewed_at=row["reviewed_at"],
        )

    def get(self, page_id: str) -> Page | None:
        with get_connection(self._db_path) as conn:
            row = conn.execute(
                "SELECT * FROM pages WHERE id = ?", (page_id,)
            ).fetchone()
            return self._row_to_page(row) if row else None

    def create(self, page: Page) -> Page:
        page.id = page.id or str(ULID())
        page.created_at = page.created_at or now_iso()
        page.updated_at = now_iso()
        page.content_hash = content_hash(page.content)
        with get_connection(self._db_path) as conn:
            conn.execute(
                """INSERT INTO pages
                   (id, title, content, type, status, subject, tags,
                    parent_id, content_hash, review_interval_days, created_at, updated_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    page.id, page.title, page.content,
                    page.type.value, page.status.value,
                    json.dumps(page.subject), json.dumps(page.tags),
                    page.parent_id, page.content_hash,
                    page.review_interval_days, page.created_at, page.updated_at,
                ),
            )
        return page

    def update(self, page_id: str, **fields) -> Page | None:
        page = self.get(page_id)
        if page is None:
            return None

        allowed = {
            "title", "content", "type", "status", "subject",
            "tags", "parent_id", "review_interval_days",
        }
        sets, vals = [], []
        for k, v in fields.items():
            if k not in allowed:
                continue
            if k == "type":
                v = PageType(v).value
            elif k == "status":
                v = PageStatus(v).value
            elif k in ("subject", "tags"):
                v = json.dumps(v if isinstance(v, list) else [])
            sets.append(f"{k} = ?")
            vals.append(v)

        if "content" in fields:
            sets.append("content_hash = ?")
            vals.append(content_hash(fields["content"]))
            sets.append("reviewed_at = ?")
            vals.append(None)

        sets.append("updated_at = ?")
        vals.append(now_iso())
        vals.append(page_id)

        with get_connection(self._db_path) as conn:
            conn.execute(
                f"UPDATE pages SET {', '.join(sets)} WHERE id = ?", vals
            )
        return self.get(page_id)

    def mark_reviewed(self, page_id: str) -> bool:
        with get_connection(self._db_path) as conn:
            cur = conn.execute(
                "UPDATE pages SET reviewed_at = ? WHERE id = ?",
                (now_iso(), page_id),
            )
            return cur.rowcount > 0

    def delete(self, page_id: str, hard: bool = False) -> bool:
        with get_connection(self._db_path) as conn:
            if hard:
                cur = conn.execute("DELETE FROM pages WHERE id = ?", (page_id,))
            else:
                cur = conn.execute(
                    "UPDATE pages SET status = 'to_delete', updated_at = ? WHERE id = ?",
                    (now_iso(), page_id),
                )
            return cur.rowcount > 0

    def list_pages(
        self,
        status: str | None = None,
        type: str | None = None,
        subject: str | None = None,
        tag: str | None = None,
        since_days: int | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict]:
        sql = (
            "SELECT id, title, type, status, subject, tags, parent_id, updated_at"
            " FROM pages WHERE 1=1"
        )
        params: list = []

        if status:
            sql += " AND status = ?"
            params.append(status)
        else:
            sql += " AND status != 'to_delete'"

        if type:
            sql += " AND type = ?"
            params.append(type)

        if subject:
            sql += " AND EXISTS (SELECT 1 FROM json_each(subject) WHERE value = ?)"
            params.append(subject)

        if tag:
            sql += " AND EXISTS (SELECT 1 FROM json_each(tags) WHERE value = ?)"
            params.append(tag)

        if since_days is not None:
            sql += " AND updated_at >= datetime('now', '-' || ? || ' days')"
            params.append(since_days)

        sql += " ORDER BY updated_at DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])

        with get_connection(self._db_path) as conn:
            rows = conn.execute(sql, params).fetchall()
            result = []
            for r in rows:
                d = dict(r)
                d["subject"] = json.loads(d.get("subject") or "[]")
                d["tags"] = json.loads(d.get("tags") or "[]")
                result.append(d)
            return result

    def search_fts(self, query: str, limit: int = 20) -> list[dict]:
        fts_query = safe_fts_query(query)
        with get_connection(self._db_path) as conn:
            rows = conn.execute(
                """SELECT p.id, p.title, p.type, p.status,
                          snippet(pages_fts, 1, '<b>', '</b>', '…', 32) AS snippet,
                          rank
                   FROM pages_fts
                   JOIN pages p ON pages_fts.rowid = p.rowid
                   WHERE pages_fts MATCH ?
                     AND p.status != 'to_delete'
                   ORDER BY rank
                   LIMIT ?""",
                (fts_query, limit),
            ).fetchall()
            return [dict(r) for r in rows]

    def create_link(self, source_id: str, target_id: str, link_type: LinkType) -> bool:
        """Returns True if link was inserted, False if it already existed (INSERT OR IGNORE)."""
        with get_connection(self._db_path) as conn:
            cur = conn.execute(
                """INSERT OR IGNORE INTO links (source_id, target_id, link_type)
                   VALUES (?, ?, ?)""",
                (source_id, target_id, link_type.value),
            )
            return cur.rowcount > 0

    def delete_link(self, source_id: str, target_id: str, link_type: LinkType | None) -> None:
        with get_connection(self._db_path) as conn:
            if link_type is None:
                conn.execute(
                    "DELETE FROM links WHERE source_id = ? AND target_id = ?",
                    (source_id, target_id),
                )
            else:
                conn.execute(
                    "DELETE FROM links WHERE source_id = ? AND target_id = ? AND link_type = ?",
                    (source_id, target_id, link_type.value),
                )

    def get_links(self, page_id: str) -> list[Link]:
        with get_connection(self._db_path) as conn:
            rows = conn.execute(
                "SELECT * FROM links WHERE source_id = ? OR target_id = ?",
                (page_id, page_id),
            ).fetchall()
            return [
                Link(
                    source_id=r["source_id"],
                    target_id=r["target_id"],
                    link_type=LinkType(r["link_type"]),
                    created_at=r["created_at"],
                )
                for r in rows
            ]

    def set_parent(self, child_id: str, parent_id: str | None) -> None:
        with get_connection(self._db_path) as conn:
            conn.execute(
                "UPDATE pages SET parent_id = ?, updated_at = ? WHERE id = ?",
                (parent_id, now_iso(), child_id),
            )

    def get_children(self, parent_id: str) -> list[dict]:
        with get_connection(self._db_path) as conn:
            rows = conn.execute(
                """SELECT id, title, type FROM pages
                   WHERE parent_id = ? AND status != 'to_delete'
                   ORDER BY title""",
                (parent_id,),
            ).fetchall()
            return [dict(r) for r in rows]

    def find_by_title(self, title: str) -> list[dict]:
        with get_connection(self._db_path) as conn:
            rows = conn.execute(
                """SELECT id, title FROM pages
                   WHERE title = ? AND status != 'to_delete'
                   ORDER BY created_at ASC, id ASC""",
                (title,),
            ).fetchall()
            return [dict(r) for r in rows]

    def get_page_briefs(self, ids: list[str]) -> dict[str, dict]:
        if not ids:
            return {}
        placeholders = ",".join("?" for _ in ids)
        with get_connection(self._db_path) as conn:
            rows = conn.execute(
                f"SELECT id, title, type FROM pages WHERE id IN ({placeholders})",
                ids,
            ).fetchall()
            return {r["id"]: dict(r) for r in rows}

    def find_orphaned(self, limit: int = 50) -> list[dict]:
        with get_connection(self._db_path) as conn:
            rows = conn.execute(
                """SELECT id, title, type, updated_at FROM pages
                   WHERE status = 'active'
                     AND parent_id IS NULL
                     AND id NOT IN (SELECT source_id FROM links)
                     AND id NOT IN (SELECT target_id FROM links)
                   ORDER BY updated_at DESC
                   LIMIT ?""",
                (limit,),
            ).fetchall()
            return [dict(r) for r in rows]

    def find_central(self, limit: int = 20) -> list[dict]:
        with get_connection(self._db_path) as conn:
            rows = conn.execute(
                """SELECT p.id, p.title, p.type,
                          COUNT(*) AS link_degree
                   FROM pages p
                   JOIN (
                       SELECT source_id AS page_id FROM links
                       UNION ALL
                       SELECT target_id FROM links
                   ) l ON p.id = l.page_id
                   WHERE p.status = 'active'
                   GROUP BY p.id
                   ORDER BY link_degree DESC
                   LIMIT ?""",
                (limit,),
            ).fetchall()
            return [dict(r) for r in rows]

    def find_due_for_review(self, limit: int = 50) -> list[dict]:
        now = now_iso()
        with get_connection(self._db_path) as conn:
            rows = conn.execute(
                """SELECT id, title, type, updated_at, reviewed_at,
                          review_interval_days,
                          datetime(
                              COALESCE(reviewed_at, updated_at),
                              '+' || review_interval_days || ' days'
                          ) AS next_review_at
                   FROM pages
                   WHERE status = 'active'
                     AND datetime(
                             COALESCE(reviewed_at, updated_at),
                             '+' || review_interval_days || ' days'
                         ) <= ?
                   ORDER BY next_review_at ASC
                   LIMIT ?""",
                (now, limit),
            ).fetchall()
            return [dict(r) for r in rows]

    def get_all_pages_summary(self, limit: int = 500) -> list[dict]:
        with get_connection(self._db_path) as conn:
            rows = conn.execute(
                """SELECT id, title, type, status, parent_id
                   FROM pages
                   WHERE status != 'to_delete'
                   ORDER BY updated_at DESC
                   LIMIT ?""",
                (limit,),
            ).fetchall()
            return [dict(r) for r in rows]

    def get_all_links(self, limit: int = 500) -> list[dict]:
        with get_connection(self._db_path) as conn:
            rows = conn.execute(
                "SELECT source_id, target_id, link_type FROM links LIMIT ?",
                (limit,),
            ).fetchall()
            return [dict(r) for r in rows]
