"""Tests für kinofilm_manager.core – Business-Logik."""

import pytest

from kinofilm_manager.core import (
    build_ac3_language_map,
    is_ac3,
    is_dts,
    is_subtitle_compatible,
    should_skip_dts,
    get_channels,
    get_tag,
    get_bitrate_for_stream,
    make_ac3_title,
)


# ── is_dts ────────────────────────────────────────────────────────


class TestIsDts:
    def test_dts_core(self):
        assert is_dts({"codec_name": "dts", "profile": ""}) is True

    def test_dts_hd(self):
        assert is_dts({"codec_name": "dts", "profile": "DTS-HD HRA"}) is True

    def test_dts_hd_ma(self):
        assert is_dts({"codec_name": "dts", "profile": "DTS-HD MA"}) is True

    def test_dtshd_codec_name(self):
        assert is_dts({"codec_name": "dts-hd", "profile": ""}) is True

    def test_ac3_is_not_dts(self):
        assert is_dts({"codec_name": "ac3", "profile": ""}) is False

    def test_aac_is_not_dts(self):
        assert is_dts({"codec_name": "aac", "profile": ""}) is False

    def test_empty_stream(self):
        assert is_dts({}) is False


# ── is_ac3 ────────────────────────────────────────────────────────


class TestIsAc3:
    def test_ac3(self):
        assert is_ac3({"codec_name": "ac3"}) is True

    def test_eac3(self):
        assert is_ac3({"codec_name": "eac3"}) is True

    def test_a52(self):
        assert is_ac3({"codec_name": "a52"}) is True

    def test_dts_is_not_ac3(self):
        assert is_ac3({"codec_name": "dts"}) is False

    def test_aac_is_not_ac3(self):
        assert is_ac3({"codec_name": "aac"}) is False


# ── is_subtitle_compatible ────────────────────────────────────────


class TestIsSubtitleCompatible:
    def test_subrip(self):
        assert is_subtitle_compatible({"codec_name": "subrip"}) is True

    def test_pgs(self):
        assert is_subtitle_compatible({"codec_name": "hdmv_pgs_subtitle"}) is True

    def test_ass(self):
        assert is_subtitle_compatible({"codec_name": "ass"}) is True

    def test_dvd_subtitle_not_compatible(self):
        assert is_subtitle_compatible({"codec_name": "dvd_subtitle"}) is False

    def test_unknown_not_compatible(self):
        assert is_subtitle_compatible({"codec_name": "unknown_format"}) is False


# ── build_ac3_language_map ────────────────────────────────────────


class TestBuildAc3LanguageMap:
    def test_single_ac3_track(self):
        streams = [{"codec_name": "ac3", "channels": 6, "tags": {"language": "eng"}}]
        assert build_ac3_language_map(streams) == {"eng": 6}

    def test_stereo_and_surround(self):
        """Zwei AC3-Spuren gleicher Sprache: die grössere Kanalanzahl gewinnt."""
        streams = [
            {"codec_name": "ac3", "channels": 2, "tags": {"language": "ger"}},
            {"codec_name": "ac3", "channels": 6, "tags": {"language": "ger"}},
        ]
        assert build_ac3_language_map(streams) == {"ger": 6}

    def test_multiple_languages(self):
        streams = [
            {"codec_name": "ac3", "channels": 6, "tags": {"language": "ger"}},
            {"codec_name": "ac3", "channels": 2, "tags": {"language": "eng"}},
        ]
        result = build_ac3_language_map(streams)
        assert result == {"ger": 6, "eng": 2}

    def test_und_language_excluded(self):
        """Undefinierte Sprache wird nicht in die Map aufgenommen."""
        streams = [{"codec_name": "ac3", "channels": 6, "tags": {"language": "und"}}]
        assert build_ac3_language_map(streams) == {}

    def test_dts_tracks_ignored(self):
        """DTS-Spuren werden nicht als AC3 gezählt."""
        streams = [
            {"codec_name": "dts", "channels": 6, "tags": {"language": "ger"}},
            {"codec_name": "ac3", "channels": 2, "tags": {"language": "eng"}},
        ]
        assert build_ac3_language_map(streams) == {"eng": 2}

    def test_empty_streams(self):
        assert build_ac3_language_map([]) == {}


# ── should_skip_dts ───────────────────────────────────────────────


class TestShouldSkipDts:
    def test_skip_when_ac3_same_channels(self):
        """DTS 5.1 wird übersprungen wenn AC3 5.1 gleicher Sprache vorhanden."""
        stream = {"codec_name": "dts", "channels": 6, "tags": {"language": "ger"}}
        ac3_map = {"ger": 6}
        assert should_skip_dts(stream, ac3_map) is True

    def test_no_skip_when_ac3_fewer_channels(self):
        """AC3 2.0 ersetzt KEINE DTS 5.1 – Kernfall für den Bugfix."""
        stream = {"codec_name": "dts", "channels": 6, "tags": {"language": "ger"}}
        ac3_map = {"ger": 2}
        assert should_skip_dts(stream, ac3_map) is False

    def test_no_skip_when_no_ac3(self):
        """Keine AC3-Spur vorhanden → nicht überspringen."""
        stream = {"codec_name": "dts", "channels": 6, "tags": {"language": "ger"}}
        ac3_map = {}
        assert should_skip_dts(stream, ac3_map) is False

    def test_no_skip_when_different_language(self):
        """AC3 für andere Sprache → nicht überspringen."""
        stream = {"codec_name": "dts", "channels": 6, "tags": {"language": "ger"}}
        ac3_map = {"eng": 6}
        assert should_skip_dts(stream, ac3_map) is False

    def test_no_skip_for_undefined_language(self):
        """Undefinierte Sprache → nie überspringen (sicherer Default)."""
        stream = {"codec_name": "dts", "channels": 6, "tags": {"language": "und"}}
        ac3_map = {"und": 6}
        assert should_skip_dts(stream, ac3_map) is False

    def test_no_skip_for_empty_language(self):
        """Leere Sprache → nie überspringen."""
        stream = {"codec_name": "dts", "channels": 6, "tags": {}}
        ac3_map = {"": 6}
        assert should_skip_dts(stream, ac3_map) is False

    def test_dts_71_with_ac3_51(self):
        """DTS 7.1 (8ch → AC3 max 6ch/5.1) wird übersprungen wenn AC3 5.1 vorhanden."""
        stream = {"codec_name": "dts", "channels": 8, "tags": {"language": "eng"}}
        ac3_map = {"eng": 6}
        assert should_skip_dts(stream, ac3_map) is True


# ── make_ac3_title ────────────────────────────────────────────────


class TestMakeAc3Title:
    def test_dts_51(self):
        stream = {"channels": 6, "tags": {"title": "DTS 5.1"}}
        assert make_ac3_title(stream) == "AC3 5.1"

    def test_dts_hd_hra_71(self):
        stream = {"channels": 8, "tags": {"title": "DTS-HD HRA 7.1"}}
        assert make_ac3_title(stream) == "AC3 5.1 (von DTS-HD HRA 7.1)"

    def test_dts_hd_ma_71(self):
        stream = {"channels": 8, "tags": {"title": "DTS-HD MA 7.1"}}
        assert make_ac3_title(stream) == "AC3 5.1 (von DTS-HD MA 7.1)"

    def test_stereo(self):
        stream = {"channels": 2, "tags": {"title": "DTS Stereo"}}
        assert make_ac3_title(stream) == "AC3 2.0"

    def test_mono(self):
        stream = {"channels": 1, "tags": {"title": "Commentary"}}
        assert make_ac3_title(stream) == "AC3 1.0"

    def test_no_title(self):
        stream = {"channels": 6, "tags": {}}
        assert make_ac3_title(stream) == "AC3 5.1"


# ── get_channels / get_tag / get_bitrate_for_stream ──────────────


class TestHelpers:
    def test_get_channels_default(self):
        assert get_channels({}) == 2

    def test_get_channels_from_stream(self):
        assert get_channels({"channels": 8}) == 8

    def test_get_tag_present(self):
        assert get_tag({"tags": {"language": "ger"}}, "language") == "ger"

    def test_get_tag_missing(self):
        assert get_tag({}, "language") == ""

    def test_get_tag_default(self):
        assert get_tag({}, "language", "?") == "?"

    def test_bitrate_51(self):
        stream = {"channels": 6}
        assert get_bitrate_for_stream(stream) == "640k"

    def test_bitrate_stereo(self):
        stream = {"channels": 2}
        assert get_bitrate_for_stream(stream) == "192k"

    def test_bitrate_override(self):
        stream = {"channels": 6}
        assert get_bitrate_for_stream(stream, "448k") == "448k"
