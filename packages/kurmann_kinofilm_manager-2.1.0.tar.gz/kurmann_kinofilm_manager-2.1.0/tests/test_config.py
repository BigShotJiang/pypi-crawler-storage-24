"""Tests für persistente CLI-Konfiguration."""

from pathlib import Path

import pytest

from kinofilm_manager.config import (
    CliConfig,
    ConfigError,
    get_config_path,
    load_config,
    parse_config_value,
    save_config,
)


class TestConfigPath:
    def test_uses_xdg_config_home_when_set(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "xdg"))
        path = get_config_path()
        assert path == tmp_path / "xdg" / "kinofilm-manager" / "config.toml"


class TestLoadAndSaveConfig:
    def test_roundtrip(self, tmp_path: Path):
        config_path = tmp_path / "config.toml"
        config = CliConfig(
            bitrate="448k",
            dry_run=True,
            verbose=False,
            artwork_provider="tmdb",
            tmdb_api_key="secret",
        )

        save_config(config, config_path)

        loaded = load_config(config_path)
        assert loaded == config

    def test_missing_file_returns_empty_config(self, tmp_path: Path):
        config = load_config(tmp_path / "missing.toml")
        assert config == CliConfig()

    def test_rejects_unknown_keys(self, tmp_path: Path):
        config_path = tmp_path / "config.toml"
        config_path.write_text('provider = "tmdb"\n', encoding="utf-8")

        with pytest.raises(ConfigError, match="Unbekannte Konfigurationsschlüssel"):
            load_config(config_path)

    def test_rejects_invalid_bitrate(self, tmp_path: Path):
        config_path = tmp_path / "config.toml"
        config_path.write_text('bitrate = "fast"\n', encoding="utf-8")

        with pytest.raises(ConfigError, match="Ungültige Bitrate"):
            load_config(config_path)


class TestParseConfigValue:
    @pytest.mark.parametrize(
        ("raw_value", "expected"),
        [
            ("true", True),
            ("yes", True),
            ("1", True),
            ("false", False),
            ("no", False),
            ("0", False),
        ],
    )
    def test_bool_values(self, raw_value: str, expected: bool):
        assert parse_config_value("verbose", raw_value) is expected

    def test_invalid_bool_value(self):
        with pytest.raises(ConfigError, match="Ungültiger Wert für 'verbose'"):
            parse_config_value("verbose", "maybe")

    def test_artwork_provider(self):
        assert parse_config_value("artwork_provider", "tmdb") == "tmdb"

    def test_invalid_artwork_provider(self):
        with pytest.raises(ConfigError, match="Ungültiger Provider"):
            parse_config_value("artwork_provider", "other")

    def test_tmdb_api_key(self):
        assert parse_config_value("tmdb_api_key", "abc123") == "abc123"
