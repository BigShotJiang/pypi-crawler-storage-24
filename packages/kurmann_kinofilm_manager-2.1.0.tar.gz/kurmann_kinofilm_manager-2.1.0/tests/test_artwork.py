"""Tests für Artwork-Parsing und Workflow."""

from pathlib import Path

import pytest

from kinofilm_manager.artwork_parser import ParsedVideoName, build_fanart_filename, parse_video_filename
from kinofilm_manager.artwork_provider import ArtworkCandidate
from kinofilm_manager.artwork_workflow import fetch_artwork_workflow


class FakeProvider:
    def __init__(self, candidates: list[ArtworkCandidate], image_bytes: bytes = b"jpg-data"):
        self.candidates = candidates
        self.image_bytes = image_bytes

    def search_movie(self, title: str, year: int | None = None, language: str | None = None) -> list[ArtworkCandidate]:
        return list(self.candidates)

    def download_backdrop(self, candidate: ArtworkCandidate) -> bytes:
        if not candidate.backdrop_url:
            raise RuntimeError("Kein Fanart vorhanden.")
        return self.image_bytes


class TestParseVideoFilename:
    def test_parses_title_and_year(self):
        assert parse_video_filename(Path("Frozen (2013).m4v")) == ParsedVideoName(title="Frozen", year=2013)

    def test_allows_parentheses_in_title(self):
        parsed = parse_video_filename(Path("Birdman (or The Unexpected Virtue of Ignorance) (2014).mkv"))
        assert parsed.title == "Birdman (or The Unexpected Virtue of Ignorance)"
        assert parsed.year == 2014

    def test_rejects_invalid_pattern(self):
        with pytest.raises(ValueError, match="Dateiname muss dem Schema"):
            parse_video_filename(Path("Frozen-2013.mkv"))

    def test_rejects_unsupported_extension(self):
        with pytest.raises(ValueError, match="Nicht unterstützte Video-Dateiendung"):
            parse_video_filename(Path("Frozen (2013).avi"))

    def test_builds_infuse_filename(self):
        assert build_fanart_filename("Frozen", 2013) == "Frozen (2013)-fanart.jpg"


class TestFetchArtworkWorkflow:
    def test_aborts_on_ambiguous_result_without_interactive(self, tmp_path: Path):
        provider = FakeProvider(
            [
                ArtworkCandidate(1, "Frozen", 2013, "Frozen", "", "https://image/1.jpg"),
                ArtworkCandidate(2, "Frozen", 2010, "Frozen", "", "https://image/2.jpg"),
            ]
        )

        result = fetch_artwork_workflow(tmp_path / "Frozen (2013).m4v", provider)

        assert result.success is False
        assert result.output_path == tmp_path / "Frozen (2013)-fanart.jpg"
        assert [option.label for option in result.selection_options] == ["Frozen (2013)", "Frozen (2010)"]

    def test_downloads_selected_backdrop(self, tmp_path: Path):
        video_path = tmp_path / "Frozen (2013).m4v"
        video_path.write_text("video", encoding="utf-8")
        provider = FakeProvider([ArtworkCandidate(1, "Frozen", 2013, "Frozen", "", "https://image/1.jpg")])

        result = fetch_artwork_workflow(video_path, provider)

        assert result.success is True
        assert result.output_path == tmp_path / "Frozen (2013)-fanart.jpg"
        assert result.output_path.read_bytes() == b"jpg-data"

    def test_dry_run_does_not_write_file(self, tmp_path: Path):
        video_path = tmp_path / "Frozen (2013).m4v"
        video_path.write_text("video", encoding="utf-8")
        provider = FakeProvider([ArtworkCandidate(1, "Frozen", 2013, "Frozen", "", "https://image/1.jpg")])

        result = fetch_artwork_workflow(video_path, provider, dry_run=True)

        assert result.success is True
        assert result.output_path == tmp_path / "Frozen (2013)-fanart.jpg"
        assert result.output_path.exists() is False

    def test_uses_explicit_title_and_year(self, tmp_path: Path):
        video_path = tmp_path / "ignored-name.mp4"
        video_path.write_text("video", encoding="utf-8")
        provider = FakeProvider([ArtworkCandidate(1, "Frozen", 2013, "Frozen", "", "https://image/1.jpg")])

        result = fetch_artwork_workflow(video_path, provider, title="Frozen", year=2013, dry_run=True)

        assert result.success is True
        assert result.output_path == tmp_path / "Frozen (2013)-fanart.jpg"
