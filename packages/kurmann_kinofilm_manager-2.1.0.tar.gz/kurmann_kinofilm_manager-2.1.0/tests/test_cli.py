"""Tests für die Typer-CLI."""

from pathlib import Path

from typer.testing import CliRunner

from kinofilm_manager.api import ArtworkFetchResult, ArtworkSelection, ConvertResult, RuntimeOptions
from kinofilm_manager.cli import app
from kinofilm_manager.config import CliConfig, save_config

runner = CliRunner()


class TestConfigCommand:
    def test_set_get_and_list(self, monkeypatch, tmp_path: Path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "xdg"))

        result = runner.invoke(app, ["config", "set", "bitrate", "448k"])
        assert result.exit_code == 0
        assert "bitrate = 448k" in result.stdout

        result = runner.invoke(app, ["config", "get", "bitrate"])
        assert result.exit_code == 0
        assert result.stdout.strip() == "448k"

        result = runner.invoke(app, ["config", "list"])
        assert result.exit_code == 0
        assert "bitrate = 448k" in result.stdout
        assert "dry_run = <unset>" in result.stdout
        assert "verbose = <unset>" in result.stdout
        assert "artwork_provider = <unset>" in result.stdout
        assert "tmdb_api_key = <unset>" in result.stdout

    def test_get_unset_value_shows_hint(self, monkeypatch, tmp_path: Path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "xdg"))

        result = runner.invoke(app, ["config", "get", "bitrate"])
        assert result.exit_code == 1
        assert "config set bitrate 448k" in result.stderr


class TestConvertCommand:
    def test_uses_persisted_runtime_options(self, monkeypatch, tmp_path: Path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "xdg"))
        save_config(CliConfig(bitrate="448k"), (tmp_path / "xdg" / "kinofilm-manager" / "config.toml"))

        captured: dict[str, object] = {}

        def fake_convert(request, runtime_options=None):
            captured["request"] = request
            captured["runtime_options"] = runtime_options
            return ConvertResult(
                success=True,
                output_path=tmp_path / "output.mkv",
                converted_count=1,
                output_size_mb=1.0,
            )

        monkeypatch.setattr("kinofilm_manager.cli.convert", fake_convert)

        input_file = tmp_path / "input.mkv"
        input_file.write_text("dummy", encoding="utf-8")

        result = runner.invoke(app, ["convert", str(input_file)])
        assert result.exit_code == 0
        assert result.stdout.strip() == str(tmp_path / "output.mkv")
        assert isinstance(captured["runtime_options"], RuntimeOptions)
        assert captured["runtime_options"].bitrate == "448k"
        assert captured["runtime_options"].dry_run is False

    def test_cli_option_overrides_persisted_bitrate(self, monkeypatch, tmp_path: Path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "xdg"))
        save_config(CliConfig(bitrate="448k"), (tmp_path / "xdg" / "kinofilm-manager" / "config.toml"))

        captured: dict[str, object] = {}

        def fake_convert(request, runtime_options=None):
            captured["runtime_options"] = runtime_options
            return ConvertResult(
                success=True,
                output_path=tmp_path / "output.mkv",
                converted_count=1,
                output_size_mb=1.0,
            )

        monkeypatch.setattr("kinofilm_manager.cli.convert", fake_convert)

        input_file = tmp_path / "input.mkv"
        input_file.write_text("dummy", encoding="utf-8")

        result = runner.invoke(app, ["convert", str(input_file), "--bitrate", "640k"])
        assert result.exit_code == 0
        assert captured["runtime_options"].bitrate == "640k"


class TestArtworkFetchCommand:
    def test_uses_persisted_provider_and_api_key(self, monkeypatch, tmp_path: Path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "xdg"))
        save_config(
            CliConfig(artwork_provider="tmdb", tmdb_api_key="secret-key"),
            (tmp_path / "xdg" / "kinofilm-manager" / "config.toml"),
        )

        captured: dict[str, object] = {}

        def fake_fetch_artwork(request, runtime_options=None, selection_index=None):
            captured["request"] = request
            captured["runtime_options"] = runtime_options
            captured["selection_index"] = selection_index
            return ArtworkFetchResult(
                success=True,
                output_path=tmp_path / "Frozen (2013)-fanart.jpg",
                selected_title="Frozen (2013)",
            )

        monkeypatch.setattr("kinofilm_manager.cli.fetch_artwork", fake_fetch_artwork)

        input_file = tmp_path / "Frozen (2013).m4v"
        input_file.write_text("dummy", encoding="utf-8")

        result = runner.invoke(app, ["artwork", "fetch", str(input_file)])
        assert result.exit_code == 0
        assert result.stdout.strip() == str(tmp_path / "Frozen (2013)-fanart.jpg")
        assert isinstance(captured["runtime_options"], RuntimeOptions)
        assert captured["runtime_options"].artwork_provider == "tmdb"
        assert captured["runtime_options"].tmdb_api_key == "secret-key"
        assert captured["runtime_options"].interactive is False

    def test_lists_ambiguous_matches_and_aborts_without_interactive(self, monkeypatch, tmp_path: Path):
        def fake_fetch_artwork(request, runtime_options=None, selection_index=None):
            return ArtworkFetchResult(
                success=False,
                output_path=tmp_path / "Frozen (2013)-fanart.jpg",
                selection_options=[
                    ArtworkSelection(index=1, label="Frozen (2013)", has_backdrop=True),
                    ArtworkSelection(index=2, label="Frozen II (2019)", has_backdrop=True),
                ],
                error_message="Mehrdeutiger Treffer. Mit --interactive erneut ausführen.",
            )

        monkeypatch.setattr("kinofilm_manager.cli.fetch_artwork", fake_fetch_artwork)

        input_file = tmp_path / "Frozen (2013).m4v"
        input_file.write_text("dummy", encoding="utf-8")

        result = runner.invoke(app, ["artwork", "fetch", str(input_file)])
        assert result.exit_code == 1
        assert "Mehrere Treffer gefunden" in result.stderr
        assert "1. Frozen (2013)" in result.stderr
        assert "2. Frozen II (2019)" in result.stderr

    def test_interactive_selection_retries_with_choice(self, monkeypatch, tmp_path: Path):
        calls: list[int | None] = []

        def fake_fetch_artwork(request, runtime_options=None, selection_index=None):
            calls.append(selection_index)
            if selection_index is None:
                return ArtworkFetchResult(
                    success=False,
                    output_path=tmp_path / "Frozen (2013)-fanart.jpg",
                    selection_options=[
                        ArtworkSelection(index=1, label="Frozen (2013)", has_backdrop=True),
                        ArtworkSelection(index=2, label="Frozen Fever (2015)", has_backdrop=False),
                    ],
                    error_message="Mehrdeutiger Treffer. Auswahl erforderlich.",
                )
            return ArtworkFetchResult(
                success=True,
                output_path=tmp_path / "Frozen (2013)-fanart.jpg",
                selected_title="Frozen (2013)",
            )

        monkeypatch.setattr("kinofilm_manager.cli.fetch_artwork", fake_fetch_artwork)

        input_file = tmp_path / "Frozen (2013).m4v"
        input_file.write_text("dummy", encoding="utf-8")

        result = runner.invoke(app, ["artwork", "fetch", str(input_file), "--interactive"], input="1\n")
        assert result.exit_code == 0
        assert result.stdout.strip() == str(tmp_path / "Frozen (2013)-fanart.jpg")
        assert calls == [None, 1]
