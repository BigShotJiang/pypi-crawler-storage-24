"""
core.py – Business-Logik für die DTS→AC3 Konvertierung.

Enthält alle Funktionen zur Stream-Analyse, Codec-Erkennung,
FFmpeg-Befehlsaufbau und Metadaten-Verwaltung.

Keine print()-Aufrufe, keine sys.exit()-Aufrufe.
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path


# ── Konstanten ────────────────────────────────────────────────────

# Codecs die als DTS gelten und konvertiert werden
DTS_CODECS = {"dts", "dts-hd", "dtshd"}

# Codecs die als AC3 gelten (für Duplikat-Erkennung)
AC3_CODECS = {"ac3", "eac3", "a52"}

# pan-Filter für 7.1 → 5.1 Downmix
# SL/SR vollständig auf BL/BR gemischt (0.7 um Clipping zu vermeiden)
# FL/FR bleiben unverändert
PAN_71_TO_51 = (
    "pan=5.1|"
    "FL=FL|"
    "FR=FR|"
    "FC=FC|"
    "LFE=LFE|"
    "BL=BL+0.7*SL|"
    "BR=BR+0.7*SR"
)

# Untertitel-Codecs die in MKV kopiert werden können
MKV_COMPATIBLE_SUBTITLE_CODECS = {
    "subrip", "srt", "ass", "ssa", "webvtt",
    "hdmv_pgs_subtitle", "pgssub",
    "dvb_subtitle", "dvb_teletext",
    "mov_text", "tx3g",
}

# Bitrate-Map: Kanalanzahl → AC3-Bitrate
BITRATE_MAP = {
    1: "192k",
    2: "192k",
    6: "640k",  # 5.1
    8: "640k",  # 7.1 – AC3 max ist 640k
}
DEFAULT_BITRATE = "640k"


# ── Codec-Erkennung ──────────────────────────────────────────────


def is_dts(stream: dict) -> bool:
    """Prüft ob ein Stream ein DTS-Codec ist."""
    codec = stream.get("codec_name", "").lower()
    profile = stream.get("profile", "").lower()
    return codec in DTS_CODECS or "dts" in codec or "dts" in profile


def is_ac3(stream: dict) -> bool:
    """Prüft ob ein Stream ein AC3/E-AC3-Codec ist."""
    codec = stream.get("codec_name", "").lower()
    return codec in AC3_CODECS


def is_subtitle_compatible(stream: dict) -> bool:
    """Prüft ob ein Untertitel-Stream in MKV kopiert werden kann."""
    codec = stream.get("codec_name", "").lower()
    return codec in MKV_COMPATIBLE_SUBTITLE_CODECS


# ── Hilfsfunktionen ──────────────────────────────────────────────


def get_channels(stream: dict) -> int:
    """Gibt die Kanalanzahl eines Audio-Streams zurück."""
    return int(stream.get("channels", 2) or 2)


def get_tag(stream: dict, key: str, default: str = "") -> str:
    """Liest einen Tag-Wert aus einem Stream."""
    return stream.get("tags", {}).get(key, default)


def get_delay_ms(stream: dict) -> float:
    """Ermittelt den Tonversatz eines Streams in Millisekunden."""
    start_time = float(stream.get("start_time", 0) or 0)
    return round(start_time * 1000, 2)


def get_bitrate_for_stream(stream: dict, override: str | None = None) -> str:
    """Bestimmt die AC3-Zielbitrate."""
    if override:
        return override
    channels = get_channels(stream)
    return BITRATE_MAP.get(channels, DEFAULT_BITRATE)


# ── Analyse ───────────────────────────────────────────────────────


def run_ffprobe(path: Path) -> dict:
    """
    Liest alle Stream-Informationen mit ffprobe aus.

    Raises:
        RuntimeError: wenn ffprobe fehlschlägt.
    """
    cmd = [
        "ffprobe",
        "-v", "quiet",
        "-print_format", "json",
        "-show_streams",
        "-show_format",
        str(path),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"ffprobe fehlgeschlagen:\n{result.stderr}")
    return json.loads(result.stdout)


def analyze_streams(probe_data: dict) -> tuple[list, list, list, list]:
    """
    Analysiert alle Streams und teilt sie in vier Gruppen:
    - video_streams
    - audio_streams
    - subtitle_streams (MKV-kompatibel)
    - skipped_subtitle_streams (inkompatibel, werden weggelassen)
    """
    video_streams: list[dict] = []
    audio_streams: list[dict] = []
    subtitle_streams: list[dict] = []
    skipped_subtitle_streams: list[dict] = []

    for stream in probe_data.get("streams", []):
        codec_type = stream.get("codec_type", "")
        if codec_type == "video":
            video_streams.append(stream)
        elif codec_type == "audio":
            audio_streams.append(stream)
        elif codec_type == "subtitle":
            if is_subtitle_compatible(stream):
                subtitle_streams.append(stream)
            else:
                skipped_subtitle_streams.append(stream)

    return video_streams, audio_streams, subtitle_streams, skipped_subtitle_streams


def build_ac3_language_map(audio_streams: list) -> dict[str, int]:
    """
    Gibt ein Dict zurück: Sprache → maximale Kanalanzahl der vorhandenen AC3-Spuren.
    Sprache 'und' (undefiniert) wird nicht aufgenommen – sicherer Default.
    """
    ac3_map: dict[str, int] = {}
    for s in audio_streams:
        if is_ac3(s):
            lang = get_tag(s, "language").lower()
            if lang and lang != "und":
                channels = get_channels(s)
                ac3_map[lang] = max(ac3_map.get(lang, 0), channels)
    return ac3_map


def should_skip_dts(stream: dict, ac3_language_map: dict[str, int]) -> bool:
    """
    Gibt True zurück wenn diese DTS-Spur übersprungen werden soll,
    weil bereits eine AC3-Spur gleicher Sprache mit mindestens gleicher
    Kanalanzahl vorhanden ist.

    Eine AC3 2.0 Spur ersetzt keine DTS 5.1 Spur – nur AC3 5.1 zählt als
    vollwertige Entsprechung für Mehrkanal-DTS.

    Spuren ohne Sprach-Tag werden nie übersprungen.
    """
    lang = get_tag(stream, "language").lower()
    if not lang or lang == "und":
        return False
    if lang not in ac3_language_map:
        return False
    # Ziel-Kanalanzahl der DTS-Spur nach Konvertierung (AC3 max 6ch/5.1)
    dts_target_channels = min(get_channels(stream), 6)
    ac3_max_channels = ac3_language_map[lang]
    return ac3_max_channels >= dts_target_channels


# ── Metadaten ─────────────────────────────────────────────────────


def make_ac3_title(stream: dict) -> str:
    """
    Generiert einen neuen Titel-Tag für eine konvertierte AC3-Spur.
    Beispiele:
      DTS 5.1        → AC3 5.1
      DTS-HD HRA 7.1 → AC3 5.1 (von DTS-HD HRA 7.1)
      DTS-HD MA 7.1  → AC3 5.1 (von DTS-HD MA 7.1)
    """
    original_title = get_tag(stream, "title")
    channels = get_channels(stream)
    # AC3 ist immer maximal 5.1
    ac3_channels = "5.1" if channels >= 6 else ("2.0" if channels == 2 else "1.0")
    base = f"AC3 {ac3_channels}"

    if original_title:
        # Nur Herkunft anhängen wenn der Originaltitel mehr Info enthält
        if "hd" in original_title.lower() or "ma" in original_title.lower() or "hra" in original_title.lower():
            return f"{base} (von {original_title})"
    return base


def append_metadata(cmd: list, video: list, audio: list, subtitle: list) -> list:
    """Fügt Stream-Metadaten (Sprache, Titel) zum FFmpeg-Befehl hinzu."""
    cmd += ["-map_metadata", "-1"]

    audio_offset = len(video)
    subtitle_offset = audio_offset + len(audio)

    for i, s in enumerate(video):
        lang = get_tag(s, "language")
        title = get_tag(s, "title")
        if lang:
            cmd += [f"-metadata:s:{i}", f"language={lang}"]
        if title:
            cmd += [f"-metadata:s:{i}", f"title={title}"]

    for i, s in enumerate(audio):
        stream_idx = audio_offset + i
        lang = get_tag(s, "language")
        title = make_ac3_title(s) if is_dts(s) else get_tag(s, "title")
        if lang:
            cmd += [f"-metadata:s:{stream_idx}", f"language={lang}"]
        if title:
            cmd += [f"-metadata:s:{stream_idx}", f"title={title}"]

    for i, s in enumerate(subtitle):
        stream_idx = subtitle_offset + i
        lang = get_tag(s, "language")
        title = get_tag(s, "title")
        if lang:
            cmd += [f"-metadata:s:{stream_idx}", f"language={lang}"]
        if title:
            cmd += [f"-metadata:s:{stream_idx}", f"title={title}"]

    return cmd


# ── FFmpeg-Befehlsaufbau ─────────────────────────────────────────


def build_ffmpeg_command(
    input_path: Path,
    output_path: Path,
    video: list,
    audio: list,
    subtitle: list,
    ac3_language_map: dict[str, int],
    bitrate_override: str | None = None,
) -> list[str]:
    """Baut den vollständigen FFmpeg-Befehl zusammen."""

    cmd = ["ffmpeg", "-y", "-i", str(input_path)]

    # ── Bestimme welche Audio-Spuren tatsächlich gemappt werden ─
    # DTS-Spuren mit vorhandener AC3-Sprache und gleicher Kanalanzahl werden weggelassen
    mapped_audio = [
        s for s in audio
        if not (is_dts(s) and should_skip_dts(s, ac3_language_map))
    ]

    # ── Map-Argumente ────────────────────────────────────────
    for s in video:
        cmd += ["-map", f"0:{s['index']}"]
    for s in mapped_audio:
        cmd += ["-map", f"0:{s['index']}"]
    for s in subtitle:
        cmd += ["-map", f"0:{s['index']}"]

    # ── Codec-Argumente ──────────────────────────────────────
    # Video: immer copy
    for i in range(len(video)):
        cmd += [f"-c:v:{i}", "copy"]

    # Audio: DTS → AC3 (mit 7.1 Downmix falls nötig), Rest → copy
    filter_complex_parts: list[str] = []
    audio_filter_map: dict[int, str] = {}  # mapped_audio index → filter label

    for i, s in enumerate(mapped_audio):
        if is_dts(s):
            channels = get_channels(s)
            bitrate = get_bitrate_for_stream(s, bitrate_override)
            cmd += [f"-c:a:{i}", "ac3", f"-b:a:{i}", bitrate]

            if channels >= 8:
                # 7.1 → 5.1 via pan-Filter
                label = f"a{i}pan"
                filter_complex_parts.append(f"[0:a:{i}]{PAN_71_TO_51}[{label}]")
                audio_filter_map[i] = label
        else:
            cmd += [f"-c:a:{i}", "copy"]

    # Subtitle: immer copy
    for i in range(len(subtitle)):
        cmd += [f"-c:s:{i}", "copy"]

    # filter_complex nur einfügen wenn 7.1 Downmix nötig
    if filter_complex_parts:
        cmd = _rebuild_cmd_with_filters(
            input_path, output_path,
            video, mapped_audio, subtitle,
            ac3_language_map, bitrate_override,
            filter_complex_parts, audio_filter_map,
        )
        return cmd

    # ── Metadaten ────────────────────────────────────────────
    cmd = append_metadata(cmd, video, mapped_audio, subtitle)

    # ── Tonversatz ───────────────────────────────────────────
    cmd += ["-avoid_negative_ts", "make_zero"]
    cmd += [str(output_path)]

    return cmd


def _rebuild_cmd_with_filters(
    input_path: Path,
    output_path: Path,
    video: list,
    mapped_audio: list,
    subtitle: list,
    ac3_language_map: dict[str, int],
    bitrate_override: str | None,
    filter_complex_parts: list,
    audio_filter_map: dict,
) -> list[str]:
    """
    Baut FFmpeg-Befehl neu auf wenn filter_complex benötigt wird (7.1 Downmix).
    filter_complex und reguläre -map können nicht gemischt werden für dieselbe Spur.
    """
    cmd = ["ffmpeg", "-y", "-i", str(input_path)]
    cmd += ["-filter_complex", ";".join(filter_complex_parts)]

    # Video maps
    for s in video:
        cmd += ["-map", f"0:{s['index']}"]

    # Audio maps: gefilterte Spuren via Label, Rest via Index
    for i, s in enumerate(mapped_audio):
        if i in audio_filter_map:
            cmd += ["-map", f"[{audio_filter_map[i]}]"]
        else:
            cmd += ["-map", f"0:{s['index']}"]

    # Subtitle maps
    for s in subtitle:
        cmd += ["-map", f"0:{s['index']}"]

    # Codecs
    for i in range(len(video)):
        cmd += [f"-c:v:{i}", "copy"]

    for i, s in enumerate(mapped_audio):
        if is_dts(s):
            bitrate = get_bitrate_for_stream(s, bitrate_override)
            cmd += [f"-c:a:{i}", "ac3", f"-b:a:{i}", bitrate]
        else:
            cmd += [f"-c:a:{i}", "copy"]

    for i in range(len(subtitle)):
        cmd += [f"-c:s:{i}", "copy"]

    cmd = append_metadata(cmd, video, mapped_audio, subtitle)
    cmd += ["-avoid_negative_ts", "make_zero"]
    cmd += [str(output_path)]
    return cmd
