"""Provider-Abstraktion und TMDB-Client für Fanart."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Protocol
from urllib.parse import urlencode
from urllib.request import urlopen


@dataclass(frozen=True, slots=True)
class ArtworkCandidate:
    """Ein möglicher Film-Treffer eines Artwork-Providers."""

    provider_id: int
    title: str
    year: int | None
    original_title: str
    overview: str
    backdrop_url: str | None

    @property
    def label(self) -> str:
        """Menschenlesbares Label für CLI-Ausgaben."""
        year = self.year if self.year is not None else "????"
        label = f"{self.title} ({year})"
        if self.original_title and self.original_title != self.title:
            label += f" – {self.original_title}"
        return label


class ArtworkProvider(Protocol):
    """Minimale Schnittstelle für Artwork-Provider."""

    def search_movie(self, title: str, year: int | None = None, language: str | None = None) -> list[ArtworkCandidate]:
        """Sucht einen Film."""

    def download_backdrop(self, candidate: ArtworkCandidate) -> bytes:
        """Lädt ein Fanart-Bild für einen Kandidaten."""


class TmdbArtworkProvider:
    """Kleiner TMDB-Client für Filmsuche und Backdrop-Download."""

    api_base_url = "https://api.themoviedb.org/3"
    image_base_url = "https://image.tmdb.org/t/p/original"

    def __init__(self, api_key: str):
        if not api_key.strip():
            raise ValueError("TMDB API Key darf nicht leer sein.")
        self.api_key = api_key.strip()

    def search_movie(self, title: str, year: int | None = None, language: str | None = None) -> list[ArtworkCandidate]:
        params = {"api_key": self.api_key, "query": title}
        if year is not None:
            params["year"] = str(year)
        if language:
            params["language"] = language

        payload = self._get_json("/search/movie", params)
        candidates: list[ArtworkCandidate] = []
        for item in payload.get("results", []):
            backdrop_path = item.get("backdrop_path")
            candidates.append(
                ArtworkCandidate(
                    provider_id=int(item.get("id", 0)),
                    title=item.get("title") or item.get("name") or title,
                    year=_extract_year(item.get("release_date")),
                    original_title=item.get("original_title") or "",
                    overview=item.get("overview") or "",
                    backdrop_url=(self.image_base_url + backdrop_path) if backdrop_path else None,
                )
            )
        return candidates

    def download_backdrop(self, candidate: ArtworkCandidate) -> bytes:
        if not candidate.backdrop_url:
            raise RuntimeError(f"Kein Fanart für '{candidate.label}' verfügbar.")
        with urlopen(candidate.backdrop_url) as response:
            return response.read()

    def _get_json(self, path: str, params: dict[str, str]) -> dict:
        url = f"{self.api_base_url}{path}?{urlencode(params)}"
        with urlopen(url) as response:
            return json.loads(response.read().decode("utf-8"))


def _extract_year(release_date: str | None) -> int | None:
    prefix = (release_date or "")[:4]
    try:
        return int(prefix)
    except ValueError:
        return None
