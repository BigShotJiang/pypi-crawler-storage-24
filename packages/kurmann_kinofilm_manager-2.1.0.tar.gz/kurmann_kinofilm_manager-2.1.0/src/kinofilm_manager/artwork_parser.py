"""Parsing für Artwork-Fetching anhand von Video-Dateinamen."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

_VIDEO_EXTENSIONS = {".m4v", ".mkv", ".mp4"}
_TITLE_YEAR_PATTERN = re.compile(r"^(?P<title>.+?) \((?P<year>\d{4})\)$")


@dataclass(frozen=True, slots=True)
class ParsedVideoName:
    """Erkannte Metadaten aus einem Video-Dateinamen."""

    title: str
    year: int


def parse_video_filename(path: Path) -> ParsedVideoName:
    """Parst `<Titel (Jahr)>.<ext>` aus einem Video-Dateinamen."""
    suffix = path.suffix.lower()
    if suffix not in _VIDEO_EXTENSIONS:
        supported = ", ".join(sorted(_VIDEO_EXTENSIONS))
        raise ValueError(f"Nicht unterstützte Video-Dateiendung '{suffix}'. Unterstützt: {supported}")

    match = _TITLE_YEAR_PATTERN.fullmatch(path.stem)
    if not match:
        raise ValueError(
            "Dateiname muss dem Schema '<Titel (Jahr)>.m4v/.mkv/.mp4' entsprechen."
        )

    title = match.group("title").strip()
    year = int(match.group("year"))
    if not title:
        raise ValueError("Filmtitel im Dateinamen darf nicht leer sein.")

    return ParsedVideoName(title=title, year=year)


def build_fanart_filename(title: str, year: int) -> str:
    """Erzeugt den Infuse-kompatiblen Fanart-Dateinamen."""
    return f"{title} ({year})-fanart.jpg"
