"""
cli.py – typer-basierte CLI für kinofilm-manager.

Gemäss Architekturprinzip v1.1.0:
- Ergebnisse auf stdout (pipeline-freundlich)
- Rich-Ausgaben (Stream-Analyse, Fortschritt) auf stderr
- --verbose für zusätzliche Diagnoseinfos (FFmpeg-Befehl) auf stderr
"""

from __future__ import annotations

from pathlib import Path

import click
import typer
from rich.console import Console

from kinofilm_manager.api import (
    ArtworkFetchRequest,
    ArtworkFetchResult,
    ConvertRequest,
    ConvertResult,
    RuntimeOptions,
    StreamInfo,
    convert,
    fetch_artwork,
)
from kinofilm_manager.config import (
    CliConfig,
    ConfigError,
    format_config_value,
    load_config,
    normalize_config_key,
    parse_config_value,
    save_config,
    supported_config_keys,
)

app = typer.Typer(
    name="kinofilm-manager",
    no_args_is_help=True,
)
config_app = typer.Typer(
    no_args_is_help=True,
    help="Verwaltet persistente CLI-Konfiguration unter ~/.config/kinofilm-manager/config.toml.",
)
artwork_app = typer.Typer(
    no_args_is_help=True,
    invoke_without_command=True,
    help="Lädt Infuse-kompatibles Fanart passend zur Videodatei.",
)
app.add_typer(config_app, name="config")
app.add_typer(artwork_app, name="artwork")


@app.callback()
def main() -> None:
    """CLI-Tool zur Konvertierung von DTS/DTS-HD Audiospuren in MKV-Dateien zu AC3."""

# Alle Rich-Ausgaben auf stderr (Diagnose/Status)
stderr_console = Console(stderr=True)


def _format_stream_line(info: StreamInfo, ac3_language_map: dict[str, int]) -> str:
    """Formatiert eine Stream-Zeile für die Analyse-Ausgabe."""
    codec = info.codec_name.upper()
    profile_str = f" / {info.profile}" if info.profile else ""
    lang = info.language or "?"
    title_str = f" / {info.title}" if info.title else ""

    if info.codec_type == "video":
        return f"  Video    #{info.index}: {codec}"

    if info.codec_type == "audio":
        channels_str = f" | {info.channels}ch"

        if info.action == "skip":
            ac3_ch = ac3_language_map.get(lang.lower(), 0)
            ac3_label = f"{ac3_ch - 1}.1" if ac3_ch > 2 else f"{ac3_ch}.0"
            action_str = f" → ÜBERSPRUNGEN (AC3 {ac3_label} gleicher Sprache vorhanden)"
        elif info.action == "downmix":
            action_str = " → AC3 5.1 (7.1 Downmix via pan-Filter)"
        elif info.action == "convert":
            action_str = " → wird zu AC3 konvertiert"
        else:
            action_str = ""

        return f"  Audio    #{info.index}: {codec}{profile_str} | {lang}{title_str}{channels_str}{action_str}"

    if info.codec_type == "subtitle":
        if info.action == "skip_subtitle":
            return f"  Subtitle #{info.index}: {codec} | {lang}{title_str} → ÜBERSPRUNGEN (nicht MKV-kompatibel)"
        return f"  Subtitle #{info.index}: {codec} | {lang}{title_str}"

    return f"  #{info.index}: {codec}"


def _print_stream_analysis(result: ConvertResult) -> None:
    """Gibt die Stream-Analyse auf stderr aus."""
    # AC3-Language-Map rekonstruieren aus den Stream-Infos für die Anzeige
    ac3_map: dict[str, int] = {}
    for s in result.streams:
        if s.codec_type == "audio" and s.codec_name.lower() in {"ac3", "eac3", "a52"}:
            lang = s.language.lower()
            if lang and lang != "und":
                ac3_map[lang] = max(ac3_map.get(lang, 0), s.channels)

    stderr_console.print("\n── Stream-Analyse ──────────────────────────────────")
    for info in result.streams:
        stderr_console.print(_format_stream_line(info, ac3_map))
    for info in result.skipped_subtitle_streams:
        stderr_console.print(_format_stream_line(info, ac3_map))
    stderr_console.print("────────────────────────────────────────────────────\n")


def _load_cli_config_or_exit() -> CliConfig:
    """Lädt die CLI-Konfiguration oder beendet mit verständlicher Fehlermeldung."""
    try:
        return load_config()
    except ConfigError as exc:
        stderr_console.print(f"[bold red]\\[FEHLER][/bold red] {exc}")
        raise typer.Exit(code=1) from exc


def _print_artwork_selection_options(result: ArtworkFetchResult) -> None:
    """Gibt Auswahloptionen für mehrdeutige Artwork-Treffer auf stderr aus."""
    stderr_console.print("\n[INFO] Mehrere Treffer gefunden:")
    for option in result.selection_options:
        backdrop = "Fanart" if option.has_backdrop else "kein Fanart"
        stderr_console.print(f"  {option.index}. {option.label} [{backdrop}]")


def _prompt_for_selection(result: ArtworkFetchResult) -> int:
    """Fragt interaktiv nach dem gewünschten Treffer."""
    max_index = len(result.selection_options)
    stdin = click.get_text_stream("stdin")
    while True:
        typer.echo("Bitte Treffer auswählen: ", err=True, nl=False)
        raw_value = stdin.readline().strip()
        try:
            selection = int(raw_value)
        except ValueError:
            typer.echo(f"Ungültige Eingabe '{raw_value}'. Bitte 1 bis {max_index} eingeben.", err=True)
            continue
        if 1 <= selection <= max_index:
            return selection
        typer.echo(f"Ungültige Eingabe '{raw_value}'. Bitte 1 bis {max_index} eingeben.", err=True)


@config_app.command("set")
def config_set(
    key: str = typer.Argument(..., help="Konfigurationsschlüssel, z.B. bitrate"),
    value: str = typer.Argument(..., help="Neuer Wert für den Konfigurationsschlüssel"),
) -> None:
    """Setzt einen persistenten Konfigurationswert."""
    try:
        normalized_key = normalize_config_key(key)
        parsed_value = parse_config_value(normalized_key, value)
        config = load_config()
        setattr(config, normalized_key, parsed_value)
        save_config(config)
    except ConfigError as exc:
        stderr_console.print(f"[bold red]\\[FEHLER][/bold red] {exc}")
        raise typer.Exit(code=1) from exc

    typer.echo(f"{normalized_key} = {format_config_value(parsed_value)}")


@config_app.command("get")
def config_get(
    key: str = typer.Argument(..., help="Konfigurationsschlüssel, z.B. bitrate"),
) -> None:
    """Liest einen persistierten Konfigurationswert."""
    try:
        normalized_key = normalize_config_key(key)
        config = load_config()
    except ConfigError as exc:
        stderr_console.print(f"[bold red]\\[FEHLER][/bold red] {exc}")
        raise typer.Exit(code=1) from exc

    value = getattr(config, normalized_key)
    if value is None:
        example = "448k" if normalized_key == "bitrate" else "true"
        stderr_console.print(
            f"[bold red]\\[FEHLER][/bold red] Konfigurationswert '{normalized_key}' ist nicht gesetzt. "
            f"Setze ihn mit `kinofilm-manager config set {normalized_key} {example}`."
        )
        raise typer.Exit(code=1)

    typer.echo(format_config_value(value))


@config_app.command("list")
def config_list() -> None:
    """Listet alle unterstützten Konfigurationsschlüssel und ihre Werte."""
    config = _load_cli_config_or_exit()
    for key in supported_config_keys():
        value = getattr(config, key)
        typer.echo(f"{key} = {format_config_value(value)}")


@app.command("convert")
def convert_cmd(
    input_file: Path = typer.Argument(
        ...,
        help="Eingabe MKV-Datei",
        exists=True,
        readable=True,
    ),
    output: Path | None = typer.Option(
        None,
        "--output", "-o",
        help="Ausgabe MKV-Datei (Standard: <input>_ac3.mkv)",
    ),
    bitrate: str | None = typer.Option(
        None,
        "--bitrate", "-b",
        help="AC3-Bitrate für alle konvertierten Spuren (z.B. 448k, 640k)",
    ),
    dry_run: bool | None = typer.Option(
        None,
        "--dry-run/--no-dry-run",
        help="Zeigt Analyse und FFmpeg-Befehl, erstellt keine Datei",
    ),
    verbose: bool | None = typer.Option(
        None,
        "--verbose/--no-verbose", "-v",
        help="Zusätzliche Diagnoseinformationen auf stderr",
    ),
) -> None:
    """Konvertiert DTS/DTS-HD Audiospuren in MKV-Dateien zu AC3."""
    config = _load_cli_config_or_exit()
    effective_dry_run = dry_run if dry_run is not None else bool(config.dry_run)
    effective_verbose = verbose if verbose is not None else bool(config.verbose)
    effective_bitrate = bitrate if bitrate is not None else config.bitrate

    request = ConvertRequest(input_path=input_file, output_path=output)
    runtime_options = RuntimeOptions(
        bitrate=effective_bitrate,
        dry_run=effective_dry_run,
    )

    stderr_console.print(f"\nEingabe:  {input_file.resolve()}")
    if output:
        stderr_console.print(f"Ausgabe:  {output}")

    # convert() führt Analyse + Konvertierung in einem Schritt durch.
    # FFmpeg-Output erscheint während der Ausführung direkt auf stderr.
    result = convert(request, runtime_options=runtime_options)

    # Stream-Analyse immer auf stderr ausgeben
    _print_stream_analysis(result)

    # ── Fehler ───────────────────────────────────────────────
    if not result.success:
        stderr_console.print(f"[bold red]\\[FEHLER][/bold red] {result.error_message}")
        raise typer.Exit(code=1)

    # ── Keine DTS-Spuren ─────────────────────────────────────
    if result.converted_count == 0:
        stderr_console.print(f"\\[INFO] {result.error_message}")
        raise typer.Exit(code=0)

    # ── Status ───────────────────────────────────────────────
    if result.skipped_count > 0:
        stderr_console.print(
            f"\\[INFO] {result.skipped_count} DTS-Spur(en) übersprungen "
            "(AC3 mit gleicher Kanalanzahl bereits vorhanden)"
        )

    stderr_console.print(
        f"\\[INFO] {result.converted_count} DTS-Spur(en) "
        f"{'würden' if effective_dry_run else 'wurden'} zu AC3 konvertiert."
    )

    # ── Verbose: FFmpeg-Befehl ───────────────────────────────
    if (effective_verbose or effective_dry_run) and result.ffmpeg_command:
        stderr_console.print("\nFFmpeg-Befehl:")
        stderr_console.print("  " + " \\\n    ".join(result.ffmpeg_command))

    # ── Dry-Run ──────────────────────────────────────────────
    if effective_dry_run:
        stderr_console.print("\n\\[DRY-RUN] Keine Datei wurde erstellt.")
        raise typer.Exit(code=0)

    # ── Ergebnis ─────────────────────────────────────────────
    if result.output_path and result.output_size_mb is not None:
        stderr_console.print(
            f"\n✓ Fertig: {result.output_path} ({result.output_size_mb:.1f} MB)"
        )
        # Ergebnis-Pfad auf stdout (pipeline-freundlich)
        print(str(result.output_path))

    # ── Warnung: übersprungene Untertitel ─────────────────────
    if result.skipped_subtitle_streams:
        stderr_console.print(
            f"\n⚠️  {len(result.skipped_subtitle_streams)} Untertitel-Spur(en) "
            "wurden weggelassen (nicht MKV-kompatibel):"
        )
        for s in result.skipped_subtitle_streams:
            title_str = f" / {s.title}" if s.title else ""
            stderr_console.print(
                f"   #{s.index}: {s.codec_name.upper()} | {s.language or '?'}{title_str}"
            )
        stderr_console.print(
            "   → DVD-Untertitel (dvd_subtitle) können nur aus VOB/MKV "
            "in Subler als Bitmaps importiert werden."
        )


@artwork_app.callback()
def artwork_main() -> None:
    """Artwork-Subcommands für Fanart-Fetching."""


@artwork_app.command("fetch")
def artwork_fetch_cmd(
    video_file: Path = typer.Argument(
        ...,
        help="Videodatei im Schema '<Titel (Jahr)>.m4v/.mkv/.mp4'",
        exists=True,
        readable=True,
    ),
    title: str | None = typer.Option(
        None,
        "--title",
        help="Alternativer Filmtitel statt Parsing aus dem Dateinamen.",
    ),
    year: int | None = typer.Option(
        None,
        "--year",
        help="Erscheinungsjahr für die Suche (erforderlich mit --title).",
    ),
    dry_run: bool | None = typer.Option(
        None,
        "--dry-run/--no-dry-run",
        help="Prüft den Workflow, lädt aber keine Datei herunter.",
    ),
    language: str | None = typer.Option(
        None,
        "--language",
        help="Sprache für die TMDB-Suche, z.B. de-DE oder en-US.",
    ),
    provider: str | None = typer.Option(
        None,
        "--provider",
        help="Artwork-Provider (derzeit nur tmdb).",
    ),
    tmdb_api_key: str | None = typer.Option(
        None,
        "--tmdb-api-key",
        help="TMDB API Key; überschreibt den konfigurierten Wert.",
    ),
    interactive: bool = typer.Option(
        False,
        "--interactive/--no-interactive",
        help="Erlaubt eine interaktive Auswahl bei mehrdeutigen Treffern.",
    ),
) -> None:
    """Lädt Infuse-kompatibles Fanart passend zur Videodatei."""
    if (title is None) != (year is None):
        stderr_console.print("[bold red]\\[FEHLER][/bold red] --title und --year müssen zusammen verwendet werden.")
        raise typer.Exit(code=1)

    config = _load_cli_config_or_exit()
    effective_dry_run = dry_run if dry_run is not None else bool(config.dry_run)
    effective_provider = provider if provider is not None else (config.artwork_provider or "tmdb")
    effective_tmdb_api_key = tmdb_api_key if tmdb_api_key is not None else config.tmdb_api_key

    stderr_console.print(f"\nEingabe:  {video_file.resolve()}")
    stderr_console.print(f"[INFO] Artwork-Provider: {effective_provider}")
    if effective_dry_run:
        stderr_console.print("[INFO] Dry-Run aktiviert.")

    request = ArtworkFetchRequest(video_path=video_file, title=title, year=year)
    runtime_options = RuntimeOptions(
        dry_run=effective_dry_run,
        interactive=interactive,
        language=language,
        artwork_provider=effective_provider,
        tmdb_api_key=effective_tmdb_api_key,
    )
    result = fetch_artwork(request, runtime_options=runtime_options)

    if result.selection_options:
        _print_artwork_selection_options(result)
        if interactive:
            selection = _prompt_for_selection(result)
            result = fetch_artwork(
                request,
                runtime_options=runtime_options,
                selection_index=selection,
            )

    if not result.success:
        stderr_console.print(f"[bold red]\\[FEHLER][/bold red] {result.error_message}")
        raise typer.Exit(code=1)

    if result.selected_title:
        stderr_console.print(f"[INFO] Gewählter Treffer: {result.selected_title}")
    if effective_dry_run:
        stderr_console.print("[DRY-RUN] Keine Datei wurde erstellt.")

    if result.output_path:
        typer.echo(str(result.output_path))


if __name__ == "__main__":
    app()
