"""
config.py – Persistente CLI-Konfiguration für kinofilm-manager.

Speichert reine CLI-Defaults XDG-konform unter:
~/.config/kinofilm-manager/config.toml
"""

from __future__ import annotations

import json
import os
import re
import tomllib
from dataclasses import dataclass
from pathlib import Path

_BITRATE_PATTERN = re.compile(r"[1-9]\d*k")

_CONFIG_HELP: dict[str, str] = {
    "bitrate": "AC3-Bitrate für konvertierte Spuren, z.B. 448k oder 640k.",
    "dry_run": "Default für --dry-run/--no-dry-run.",
    "verbose": "Default für --verbose/--no-verbose.",
    "artwork_provider": "Default-Provider für `artwork fetch` (derzeit nur tmdb).",
    "tmdb_api_key": "TMDB API Key für `artwork fetch`.",
}

_BOOL_TRUE_VALUES = {"1", "true", "yes", "on"}
_BOOL_FALSE_VALUES = {"0", "false", "no", "off"}


class ConfigError(ValueError):
    """Fehler beim Lesen, Validieren oder Schreiben der Konfiguration."""


@dataclass(slots=True)
class CliConfig:
    """Persistente Default-Werte für die CLI."""

    bitrate: str | None = None
    dry_run: bool | None = None
    verbose: bool | None = None
    artwork_provider: str | None = None
    tmdb_api_key: str | None = None


def supported_config_keys() -> tuple[str, ...]:
    """Gibt die unterstützten Konfigurationsschlüssel in stabiler Reihenfolge zurück."""
    return tuple(_CONFIG_HELP)


def get_config_help(key: str) -> str:
    """Liefert die Beschreibung für einen unterstützten Konfigurationsschlüssel."""
    normalized_key = normalize_config_key(key)
    return _CONFIG_HELP[normalized_key]


def normalize_config_key(key: str) -> str:
    """Normalisiert und validiert einen Konfigurationsschlüssel."""
    normalized_key = key.strip().lower().replace("-", "_")
    if normalized_key not in _CONFIG_HELP:
        supported = ", ".join(supported_config_keys())
        raise ConfigError(
            f"Unbekannter Konfigurationsschlüssel '{key}'. "
            f"Unterstützt: {supported}"
        )
    return normalized_key


def get_config_path() -> Path:
    """Ermittelt den XDG-konformen Pfad zur Konfigurationsdatei."""
    config_home = os.environ.get("XDG_CONFIG_HOME")
    base_dir = Path(config_home).expanduser() if config_home else Path.home() / ".config"
    return base_dir / "kinofilm-manager" / "config.toml"


def load_config(path: Path | None = None) -> CliConfig:
    """Lädt die persistente CLI-Konfiguration."""
    config_path = path or get_config_path()
    if not config_path.exists():
        return CliConfig()

    try:
        data = tomllib.loads(config_path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as exc:
        raise ConfigError(
            f"Ungültige Konfiguration in {config_path}: {exc}"
        ) from exc

    if not isinstance(data, dict):
        raise ConfigError(f"Ungültige Konfiguration in {config_path}: Root muss TOML-Table sein.")

    unknown_keys = sorted(set(data) - set(supported_config_keys()))
    if unknown_keys:
        raise ConfigError(
            f"Unbekannte Konfigurationsschlüssel in {config_path}: {', '.join(unknown_keys)}"
        )

    return CliConfig(
        bitrate=_load_value(data, "bitrate"),
        dry_run=_load_value(data, "dry_run"),
        verbose=_load_value(data, "verbose"),
        artwork_provider=_load_value(data, "artwork_provider"),
        tmdb_api_key=_load_value(data, "tmdb_api_key"),
    )


def save_config(config: CliConfig, path: Path | None = None) -> Path:
    """Schreibt die Konfiguration atomar ersetzbar an den Zielpfad."""
    config_path = path or get_config_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(serialize_config(config), encoding="utf-8")
    return config_path


def serialize_config(config: CliConfig) -> str:
    """Serialisiert die Konfiguration als flaches TOML."""
    lines: list[str] = []
    for key in supported_config_keys():
        value = getattr(config, key)
        if value is None:
            continue
        if isinstance(value, bool):
            rendered_value = "true" if value else "false"
        else:
            rendered_value = json.dumps(value)
        lines.append(f"{key} = {rendered_value}")
    return "\n".join(lines) + ("\n" if lines else "")


def parse_config_value(key: str, raw_value: str) -> str | bool:
    """Parst einen Shell-/CLI-Wert für einen unterstützten Konfigurationsschlüssel."""
    normalized_key = normalize_config_key(key)
    if normalized_key == "bitrate":
        return validate_config_value(normalized_key, raw_value)
    if normalized_key in {"artwork_provider", "tmdb_api_key"}:
        return validate_config_value(normalized_key, raw_value)

    lowered_value = raw_value.strip().lower()
    if lowered_value in _BOOL_TRUE_VALUES:
        return True
    if lowered_value in _BOOL_FALSE_VALUES:
        return False

    raise ConfigError(
        f"Ungültiger Wert für '{normalized_key}': '{raw_value}'. "
        "Erlaubt sind true/false, yes/no, on/off oder 1/0."
    )


def validate_config_value(key: str, value: object) -> str | bool:
    """Validiert einen bereits geparsten Konfigurationswert."""
    normalized_key = normalize_config_key(key)

    if normalized_key == "bitrate":
        if not isinstance(value, str) or not _BITRATE_PATTERN.fullmatch(value):
            raise ConfigError(
                f"Ungültige Bitrate '{value}'. Erwartet wird ein Wert wie 448k oder 640k."
            )
        return value

    if normalized_key == "artwork_provider":
        if not isinstance(value, str) or value.strip().lower() != "tmdb":
            raise ConfigError(
                f"Ungültiger Provider '{value}'. Unterstützt wird derzeit nur 'tmdb'."
            )
        return "tmdb"

    if normalized_key == "tmdb_api_key":
        if not isinstance(value, str) or not value.strip():
            raise ConfigError("TMDB API Key darf nicht leer sein.")
        return value.strip()

    if not isinstance(value, bool):
        raise ConfigError(
            f"Ungültiger Wert für '{normalized_key}': {value!r}. Erwartet wird true oder false."
        )
    return value


def format_config_value(value: str | bool | None) -> str:
    """Formatiert einen Konfigurationswert für CLI-Ausgaben."""
    if value is None:
        return "<unset>"
    if isinstance(value, bool):
        return "true" if value else "false"
    return value


def _load_value(data: dict[str, object], key: str) -> str | bool | None:
    if key not in data:
        return None
    return validate_config_value(key, data[key])
