"""Workflow für Artwork-Fetching."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from kinofilm_manager.artwork_parser import ParsedVideoName, build_fanart_filename, parse_video_filename
from kinofilm_manager.artwork_provider import ArtworkCandidate, ArtworkProvider


@dataclass(frozen=True, slots=True)
class ArtworkSelectionOption:
    """Darstellung eines auswählbaren Treffers."""

    index: int
    label: str
    has_backdrop: bool


@dataclass(slots=True)
class ArtworkWorkflowResult:
    """Ergebnis des Artwork-Workflows."""

    success: bool
    output_path: Path | None = None
    parsed_video: ParsedVideoName | None = None
    candidates: list[ArtworkCandidate] = field(default_factory=list)
    selection_options: list[ArtworkSelectionOption] = field(default_factory=list)
    selected_candidate: ArtworkCandidate | None = None
    downloaded_bytes: bytes | None = None
    error_message: str | None = None


def fetch_artwork_workflow(
    video_path: Path,
    provider: ArtworkProvider,
    *,
    title: str | None = None,
    year: int | None = None,
    dry_run: bool = False,
    interactive: bool = False,
    language: str | None = None,
    selection_index: int | None = None,
) -> ArtworkWorkflowResult:
    """Orchestriert Parsing, Provider-Suche, Auswahl und Download."""
    parsed_video = (
        ParsedVideoName(title=title, year=year)
        if title is not None and year is not None
        else parse_video_filename(video_path)
    )
    output_path = video_path.parent / build_fanart_filename(parsed_video.title, parsed_video.year)

    candidates = provider.search_movie(parsed_video.title, parsed_video.year, language)
    if not candidates:
        return ArtworkWorkflowResult(
            success=False,
            output_path=output_path,
            parsed_video=parsed_video,
            error_message=f"Kein Treffer für '{parsed_video.title} ({parsed_video.year})' gefunden.",
        )

    selected_candidate: ArtworkCandidate | None = None
    if len(candidates) == 1:
        selected_candidate = candidates[0]
    elif selection_index is not None:
        if selection_index < 1 or selection_index > len(candidates):
            return ArtworkWorkflowResult(
                success=False,
                output_path=output_path,
                parsed_video=parsed_video,
                candidates=candidates,
                selection_options=_build_selection_options(candidates),
                error_message=f"Ungültige Auswahl: {selection_index}.",
            )
        selected_candidate = candidates[selection_index - 1]
    elif not interactive:
        return ArtworkWorkflowResult(
            success=False,
            output_path=output_path,
            parsed_video=parsed_video,
            candidates=candidates,
            selection_options=_build_selection_options(candidates),
            error_message="Mehrdeutiger Treffer. Mit --interactive erneut ausführen.",
        )
    else:
        return ArtworkWorkflowResult(
            success=False,
            output_path=output_path,
            parsed_video=parsed_video,
            candidates=candidates,
            selection_options=_build_selection_options(candidates),
            error_message="Mehrdeutiger Treffer. Auswahl erforderlich.",
        )

    if selected_candidate is None:
        return ArtworkWorkflowResult(
            success=False,
            output_path=output_path,
            parsed_video=parsed_video,
            candidates=candidates,
            error_message="Kein gültiger Treffer ausgewählt.",
        )

    if not selected_candidate.backdrop_url:
        return ArtworkWorkflowResult(
            success=False,
            output_path=output_path,
            parsed_video=parsed_video,
            candidates=candidates,
            selected_candidate=selected_candidate,
            error_message=f"Für '{selected_candidate.label}' ist kein Fanart verfügbar.",
        )

    if dry_run:
        return ArtworkWorkflowResult(
            success=True,
            output_path=output_path,
            parsed_video=parsed_video,
            candidates=candidates,
            selected_candidate=selected_candidate,
        )

    image_bytes = provider.download_backdrop(selected_candidate)
    output_path.write_bytes(image_bytes)
    return ArtworkWorkflowResult(
        success=True,
        output_path=output_path,
        parsed_video=parsed_video,
        candidates=candidates,
        selected_candidate=selected_candidate,
        downloaded_bytes=image_bytes,
    )


def _build_selection_options(candidates: list[ArtworkCandidate]) -> list[ArtworkSelectionOption]:
    return [
        ArtworkSelectionOption(
            index=index,
            label=candidate.label,
            has_backdrop=bool(candidate.backdrop_url),
        )
        for index, candidate in enumerate(candidates, start=1)
    ]
