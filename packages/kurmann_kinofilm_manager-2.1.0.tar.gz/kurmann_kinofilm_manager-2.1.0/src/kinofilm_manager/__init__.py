"""kinofilm_manager – CLI-Tool zur Konvertierung von DTS/DTS-HD Audiospuren in MKV-Dateien zu AC3."""

__version__ = "2.1.0"
