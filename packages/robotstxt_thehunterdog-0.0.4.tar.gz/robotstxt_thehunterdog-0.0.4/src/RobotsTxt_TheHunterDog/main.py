import re
import requests

allowed = []
disallowed = []
sitemap = []
user_agent = None

def init_robots_txt(request_user_agent, robots_txt_content = None, robots_txt_url = None):
    global user_agent
    user_agent = request_user_agent
    user_agent_found = False
    if robots_txt_content is None:
        if robots_txt_url is None:
            raise Exception(
                "robots_txt_content or robots_txt_url must be provided"
            )
        robots_txt_content = requests.get(robots_txt_url)

    for line in robots_txt_content.text.split("\n"):
        if user_agent_found:
            if line.find("User-agent") == -1:
                print(line)
                if __is_disallow_label(line):
                    disallowed.append(__get_value_from_label(line))
                elif __is_allow_label(line):
                    allowed.append(__get_value_from_label(line))
            else:
                user_agent_found = False

        if __is_user_agent_label(line):
            if __get_value_from_label(line).lower() == f"{request_user_agent}".lower() or __get_value_from_label(line).lower() == f"User-agent: *".lower():
                user_agent_found = True
        elif __is_sitemap_label(line):
            sitemap.append(__get_value_from_label(line))
        else:
            continue

def make_get_request(url, headers = None):
    if headers is None:
        headers = {"User-Agent": user_agent}
    if re.compile("|".join(disallowed)).search(url):
        raise Exception(f"url {url} is disallowed")
    return requests.get(url, headers=headers)

def __get_value_from_label(line) -> str:
    return line[line.find(":"):].replace(":","").strip()

def __is_disallow_label(line) -> bool:
    acceptable_labels = ["disallow", "dissalow", "disalow", "diasllow", "disallaw"]
    return line.lower().find(tuple(acceptable_labels)) != -1
def __is_allow_label(line) -> bool:
    acceptable_labels = ["allow", "alow", "allo"]
    return line.lower().find(tuple(acceptable_labels)) != -1
def __is_sitemap_label(line) -> bool:
    acceptable_labels = ["sitemap", "sitmap", "sitemaps"]
    return line.lower().find(tuple(acceptable_labels)) != -1
def __is_user_agent_label(line) -> bool:
    acceptable_labels = ["user-agent", "useragent", "user-agents", "useragents"]
    return line.lower().find(tuple(acceptable_labels)) != -1
