import RobotsTxt_TheHunterDog
USER_AGENT = "GOOGLEBOT"
RobotsTxt_TheHunterDog.init_robots_txt(USER_AGENT, robots_txt_url = "https://www.google.com/robots.txt")
RobotsTxt_TheHunterDog.make_get_request("https://www.google.com")
