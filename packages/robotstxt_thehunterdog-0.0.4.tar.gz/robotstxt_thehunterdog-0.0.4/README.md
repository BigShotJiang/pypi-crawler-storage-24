# RobotsTxt

## Description
The project is a robots.txt parser. The parser is written in Python, easy to use and has small improvements for typos. The project is open source and encourages contributions and ideas for improvements.

## Usage
The usage of the package is simple. first you have to init the parser.
```python
USER_AGENT = "GOOGLEBOT"
RobotsTxt_TheHunterDog.initRobotsTxt(USER_AGENT, robots_txt_url = "https://www.google.com/robots.txt")
```
when it has been initailized the allowed and disallowd list has been parsed and stored. Each get request must be checked against the list. this is being done with the built in make get request function.
```python
RobotsTxt_TheHunterDog.main.makeRequest("https://www.google.com")
```
The user agent that has been initailized will be used for each get request made using the function.

## Contributing
Pull requests are welcome, for major changes please open an issue first to discuss what you would like to change. Issues are also welcome to report bugs, request features or suggest improvements.

## License
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
