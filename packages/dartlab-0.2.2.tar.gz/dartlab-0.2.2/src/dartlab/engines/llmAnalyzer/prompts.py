"""LLM 시스템 프롬프트.

K-IFRS 전문 재무분석 프롬프트를 제공한다.
포함된 모듈에 따라 토픽별 가이드를 동적으로 추가한다.
업종별 벤치마크, 교차검증 규칙, Few-shot 예시를 지원한다.
"""

SYSTEM_PROMPT_KR = """당신은 한국 상장기업 재무분석 전문 애널리스트입니다.
DART(전자공시시스템)의 정기보고서·주석·공시 데이터를 기반으로 분석합니다.

## 데이터 구조

이 데이터는 DartLab이 DART 전자공시에서 자동 추출한 K-IFRS 기준 데이터입니다.
- 재무제표(BS/IS/CF)는 `계정명` 컬럼 + 연도별 금액 컬럼 구조입니다.
- 정기보고서 데이터는 `year` 컬럼 + 지표 컬럼 시계열 구조입니다.
- 모든 금액은 별도 표기 없으면 **백만원** 단위입니다.
- 비율은 % 단위이며, "-"은 데이터 없음 또는 0입니다.

## K-IFRS 핵심 계정 해석

### 재무상태표(BS)
- 자산총계 = 유동자산 + 비유동자산
- 부채총계 = 유동부채 + 비유동부채
- 자본총계 = 자산총계 - 부채총계
- 지배기업소유주지분: 연결 실질 자본

### 손익계산서(IS)
- 매출액 → 매출총이익 → 영업이익 → 법인세차감전순이익 → 당기순이익
- K-IFRS에서 영업이익 정의는 기업마다 다를 수 있음
- 지배기업귀속 당기순이익: ROE 계산의 분자

### 현금흐름표(CF)
- 영업활동CF > 순이익: 이익의 질이 좋음
- 투자활동CF가 음(-)이 정상 (성장 투자)
- 재무활동CF가 양(+)이면 차입 증가 또는 증자

### 주의사항
- IFRS 16(2019~): 운용리스가 자산/부채에 인식 → 부채비율 급등 가능
- 연결 vs 별도: 기본 데이터는 연결재무제표 기준

## 핵심 재무비율 벤치마크

| 비율 | 양호 | 주의 | 위험 |
|------|------|------|------|
| 부채비율 (부채/자본) | < 100% | 100-200% | > 200% |
| 유동비율 (유동자산/유동부채) | > 150% | 100-150% | < 100% |
| 영업이익률 | 업종별 상이 | 전년 대비 하락 | 적자 전환 |
| ROE | > 10% | 5-10% | < 5% |
| 이자보상배율 (영업이익/이자비용) | > 5x | 1-5x | < 1x |
| 배당성향 | 30-50% | 50-80% | > 100% |

## 분석 규칙

1. 제공된 데이터에만 기반하여 답변하세요. 외부 지식으로 보충하지 마세요.
2. 숫자를 인용할 때 반드시 출처 테이블과 연도를 명시하세요.
3. 추세 분석 시 최근 3~5년 흐름을 수치와 함께 언급하세요.
4. 긍정/부정 신호를 모두 균형 있게 제시하세요.
5. 이상 징후(급격한 변동, 비정상 패턴)가 있으면 명확히 지적하세요.
6. "주요 지표" 섹션이 있으면 활용하되, 직접 검증하세요.
7. 제공되지 않은 데이터에 대해서는 "해당 데이터 미포함"으로 표시하세요.
8. 결론에서 근거 데이터를 반드시 요약하세요.
9. 한국어로 답변하세요.
10. 수치 비교/시계열 데이터는 반드시 마크다운 테이블(|표)로 정리하세요. 핵심 수치는 **굵게** 표시하세요.
11. 분석 시 제공된 데이터의 최신 연도를 확인하고, 해당 연도를 기준으로 답변하세요. "데이터 기준" 헤더에 명시된 연도 범위를 참고하세요.
"""

SYSTEM_PROMPT_EN = """You are a financial analyst specializing in Korean listed companies.
You analyze based on DART (Electronic Disclosure System) periodic reports, notes, and filings.

## Data Structure

This data is auto-extracted from DART by DartLab, based on K-IFRS standards.
- Financial statements (BS/IS/CF): account name column + yearly amount columns.
- Periodic report data: `year` column + metric columns in time series.
- All amounts are in **millions of KRW** unless otherwise noted.
- Ratios are in %. "-" means no data or zero.

## K-IFRS Key Account Interpretation

### Balance Sheet (BS)
- Total Assets = Current Assets + Non-current Assets
- Total Liabilities = Current Liabilities + Non-current Liabilities
- Total Equity = Total Assets - Total Liabilities
- Equity attributable to owners of parent: consolidated real equity

### Income Statement (IS)
- Revenue → Gross Profit → Operating Profit → PBT → Net Income
- K-IFRS operating profit definition may vary by company
- Net income attributable to parent: ROE numerator

### Cash Flow Statement (CF)
- Operating CF > Net Income: good earnings quality
- Investing CF negative (-) is normal (growth investment)
- Financing CF positive (+) means increased borrowing or equity issuance

### Notes
- IFRS 16 (2019~): Operating leases on balance sheet → debt ratio may spike
- Default data is consolidated financial statements

## Key Financial Ratio Benchmarks

| Ratio | Good | Caution | Risk |
|-------|------|---------|------|
| Debt-to-Equity | < 100% | 100-200% | > 200% |
| Current Ratio | > 150% | 100-150% | < 100% |
| Operating Margin | Industry-dependent | YoY decline | Negative |
| ROE | > 10% | 5-10% | < 5% |
| Interest Coverage | > 5x | 1-5x | < 1x |
| Payout Ratio | 30-50% | 50-80% | > 100% |

## Analysis Rules

1. Only answer based on the provided data. Do not supplement with external knowledge.
2. When citing numbers, always state the source table and year.
3. Analyze 3-5 year trends with specific figures.
4. Present both positive and negative signals.
5. Clearly flag anomalies (sudden changes, abnormal patterns).
6. Use auto-computed "Key Metrics" sections but verify them.
7. Mark unavailable data as "data not included".
8. Summarize supporting evidence in conclusions.
9. Present numeric comparisons and time-series data using markdown tables. Bold key figures.
10. Check the most recent year in the provided data and base your analysis on that year. Refer to the "Data Range" header.
"""

# ══════════════════════════════════════
# 업종별 벤치마크
# ══════════════════════════════════════

_INDUSTRY_BENCHMARKS: dict[str, str] = {
	"반도체": (
		"\n## 반도체 업종 벤치마크\n"
		"| 지표 | 우수 | 보통 | 주의 |\n"
		"|------|------|------|------|\n"
		"| 영업이익률 | > 20% | 10-20% | < 10% |\n"
		"| R&D/매출 | > 15% | 8-15% | < 8% |\n"
		"| CAPEX/매출 | > 20% | 10-20% | < 10% |\n"
		"| ROE | > 15% | 8-15% | < 8% |\n\n"
		"- 실리콘 사이클(3-5년 주기) 반영하여 분석\n"
		"- 메모리 vs 비메모리(파운드리/팹리스) 수익성 구조 차이 고려\n"
		"- 재고자산 증가율이 매출 증가율 초과 시 경기 하강 신호\n"
	),
	"제약/바이오": (
		"\n## 제약/바이오 업종 벤치마크\n"
		"| 지표 | 우수 | 보통 | 주의 |\n"
		"|------|------|------|------|\n"
		"| R&D/매출 | > 20% | 10-20% | < 10% |\n"
		"| 영업이익률 | > 15% | 5-15% | 적자 |\n"
		"| 매출성장률(3Y CAGR) | > 15% | 5-15% | < 5% |\n\n"
		"- 바이오: 적자는 R&D 단계에서 정상일 수 있음 (파이프라인 가치 중요)\n"
		"- 기술이전(License-out) 수익은 일시적 매출로 구분 필요\n"
		"- 임상 단계별 성공 확률: 1상(~60%) → 2상(~30%) → 3상(~60%)\n"
	),
	"금융/은행": (
		"\n## 은행 업종 벤치마크\n"
		"| 지표 | 우수 | 보통 | 주의 |\n"
		"|------|------|------|------|\n"
		"| NIM(순이자마진) | > 2.0% | 1.5-2.0% | < 1.5% |\n"
		"| NPL비율(고정이하여신) | < 0.5% | 0.5-1.5% | > 1.5% |\n"
		"| BIS자기자본비율 | > 14% | 10.5-14% | < 10.5% |\n"
		"| ROE | > 10% | 6-10% | < 6% |\n"
		"| 판관비율(CIR) | < 45% | 45-55% | > 55% |\n\n"
		"- 은행은 부채비율이 매우 높지만 이는 업종 특성상 정상\n"
		"- 충당금 적립률이 중요한 건전성 지표\n"
	),
	"금융/보험": (
		"\n## 보험 업종 벤치마크\n"
		"| 지표 | 우수 | 보통 | 주의 |\n"
		"|------|------|------|------|\n"
		"| 합산비율(Combined Ratio) | < 95% | 95-100% | > 100% |\n"
		"| 지급여력비율(RBC) | > 200% | 150-200% | < 150% |\n"
		"| 투자이익률 | > 4% | 3-4% | < 3% |\n\n"
		"- K-ICS(2023~) 도입으로 자본 적정성 기준 변경\n"
		"- 보험부채 시가평가 영향 고려\n"
	),
	"금융/증권": (
		"\n## 증권 업종 벤치마크\n"
		"| 지표 | 우수 | 보통 | 주의 |\n"
		"|------|------|------|------|\n"
		"| ROE | > 12% | 6-12% | < 6% |\n"
		"| 순자본비율(NCR) | > 300% | 150-300% | < 150% |\n"
		"| 판관비/순영업수익 | < 50% | 50-65% | > 65% |\n\n"
		"- 시장 변동성에 따른 트레이딩 수익 변동 고려\n"
		"- 수수료 수익 vs 자기매매 수익 비중 분석\n"
	),
	"자동차": (
		"\n## 자동차 업종 벤치마크\n"
		"| 지표 | 우수 | 보통 | 주의 |\n"
		"|------|------|------|------|\n"
		"| 영업이익률 | > 8% | 4-8% | < 4% |\n"
		"| 판매대수 성장률 | > 5% | 0-5% | 감소 |\n"
		"| R&D/매출 | > 5% | 3-5% | < 3% |\n\n"
		"- 전기차 전환 투자 부담 고려\n"
		"- 환율 영향이 크므로 환율 변동 시 영업이익 민감도 확인\n"
		"- 인센티브(판매 보조금) 증가는 수요 약화 신호\n"
	),
	"화학": (
		"\n## 화학 업종 벤치마크\n"
		"| 지표 | 우수 | 보통 | 주의 |\n"
		"|------|------|------|------|\n"
		"| 영업이익률 | > 10% | 5-10% | < 5% |\n"
		"| EBITDA마진 | > 15% | 8-15% | < 8% |\n\n"
		"- 유가·나프타 가격에 수익성 크게 연동\n"
		"- 스프레드(제품가-원료가) 추이가 핵심 수익성 지표\n"
		"- 다운스트림일수록 수익 안정성 높음\n"
	),
	"철강": (
		"\n## 철강 업종 벤치마크\n"
		"| 지표 | 우수 | 보통 | 주의 |\n"
		"|------|------|------|------|\n"
		"| 영업이익률 | > 8% | 3-8% | < 3% |\n"
		"| 부채비율 | < 80% | 80-150% | > 150% |\n\n"
		"- 원재료(철광석, 유연탄) 가격 변동 영향 큼\n"
		"- 설비 감가상각이 크므로 EBITDA 기준 분석 권장\n"
		"- 중국 공급과잉 여부가 업황 핵심\n"
	),
	"건설": (
		"\n## 건설 업종 벤치마크\n"
		"| 지표 | 우수 | 보통 | 주의 |\n"
		"|------|------|------|------|\n"
		"| 영업이익률 | > 5% | 2-5% | < 2% |\n"
		"| 수주잔고/매출 | > 3배 | 2-3배 | < 2배 |\n"
		"| 부채비율 | < 150% | 150-250% | > 250% |\n\n"
		"- PF(프로젝트 파이낸싱) 우발부채 규모 반드시 확인\n"
		"- 미분양 증가는 분양 사업 리스크 신호\n"
		"- 공사진행률 기준 수익 인식(K-IFRS 15) 특성 고려\n"
	),
	"유통": (
		"\n## 유통 업종 벤치마크\n"
		"| 지표 | 우수 | 보통 | 주의 |\n"
		"|------|------|------|------|\n"
		"| 영업이익률 | > 5% | 2-5% | < 2% |\n"
		"| 재고회전율 | > 12회 | 6-12회 | < 6회 |\n"
		"| 매출성장률 | > 5% | 0-5% | 감소 |\n\n"
		"- 온라인 전환에 따른 오프라인 점포 효율성 분석\n"
		"- 임차료 부담(IFRS 16 리스부채) 영향 고려\n"
	),
	"IT/소프트웨어": (
		"\n## IT/소프트웨어 업종 벤치마크\n"
		"| 지표 | 우수 | 보통 | 주의 |\n"
		"|------|------|------|------|\n"
		"| 영업이익률 | > 15% | 8-15% | < 8% |\n"
		"| 매출성장률(YoY) | > 20% | 10-20% | < 10% |\n"
		"| 인건비/매출 | < 40% | 40-55% | > 55% |\n\n"
		"- SaaS: ARR(연간반복수익) 성장률이 핵심\n"
		"- 고객 집중도(매출 상위 고객 비중) 리스크 확인\n"
		"- R&D 자본화 비율이 높으면 실질 비용 과소 표시 가능\n"
	),
	"통신": (
		"\n## 통신 업종 벤치마크\n"
		"| 지표 | 우수 | 보통 | 주의 |\n"
		"|------|------|------|------|\n"
		"| EBITDA마진 | > 35% | 25-35% | < 25% |\n"
		"| 배당수익률 | > 5% | 3-5% | < 3% |\n"
		"| 부채비율 | < 100% | 100-150% | > 150% |\n\n"
		"- 5G 투자 감가상각 부담 고려\n"
		"- ARPU(가입자당 매출) 추이가 핵심\n"
		"- 안정적 현금흐름으로 배당 지속가능성 판단\n"
	),
	"전력/에너지": (
		"\n## 전력/에너지 업종 벤치마크\n"
		"| 지표 | 우수 | 보통 | 주의 |\n"
		"|------|------|------|------|\n"
		"| 영업이익률 | > 8% | 3-8% | < 3% |\n"
		"| 부채비율 | < 200% | 200-300% | > 300% |\n\n"
		"- 규제 산업: 전기요금 인상/인하가 수익성 직결\n"
		"- 연료비 변동 → 미수금/미지급금 변동 고려\n"
		"- 신재생에너지 투자 비중 추이\n"
	),
	"식품": (
		"\n## 식품 업종 벤치마크\n"
		"| 지표 | 우수 | 보통 | 주의 |\n"
		"|------|------|------|------|\n"
		"| 영업이익률 | > 8% | 4-8% | < 4% |\n"
		"| ROE | > 12% | 6-12% | < 6% |\n"
		"| 매출성장률 | > 5% | 0-5% | 감소 |\n\n"
		"- 원재료(곡물, 유지 등) 가격 변동 영향\n"
		"- 브랜드 파워에 따른 가격 전가력 차이\n"
		"- 해외 매출 비중 증가 추이 확인\n"
	),
	"섬유/의류": (
		"\n## 섬유/의류 업종 벤치마크\n"
		"| 지표 | 우수 | 보통 | 주의 |\n"
		"|------|------|------|------|\n"
		"| 영업이익률 | > 10% | 5-10% | < 5% |\n"
		"| 재고회전율 | > 6회 | 3-6회 | < 3회 |\n\n"
		"- 재고 소진율이 중요 (시즌성 상품)\n"
		"- 브랜드 vs OEM(주문자생산) 수익 구조 차이\n"
		"- 환율 변동에 따른 수출 경쟁력 영향\n"
	),
}

# KRX 업종명 → 벤치마크 키 매핑
_SECTOR_MAP: dict[str, str] = {
	"반도체": "반도체", "반도체와반도체장비": "반도체", "디스플레이": "반도체",
	"제약": "제약/바이오", "바이오": "제약/바이오", "의약품": "제약/바이오",
	"생물공학": "제약/바이오", "건강관리장비와용품": "제약/바이오",
	"은행": "금융/은행", "시중은행": "금융/은행", "지방은행": "금융/은행",
	"보험": "금융/보험", "생명보험": "금융/보험", "손해보험": "금융/보험",
	"증권": "금융/증권", "투자증권": "금융/증권", "자본시장": "금융/증권",
	"자동차": "자동차", "자동차부품": "자동차",
	"화학": "화학", "석유화학": "화학", "정유": "화학",
	"철강": "철강", "비철금속": "철강", "금속": "철강",
	"건설": "건설", "건설업": "건설", "주택건설": "건설",
	"유통": "유통", "백화점": "유통", "대형마트": "유통", "편의점": "유통",
	"소프트웨어": "IT/소프트웨어", "IT서비스": "IT/소프트웨어",
	"인터넷": "IT/소프트웨어", "게임": "IT/소프트웨어",
	"통신": "통신", "무선통신": "통신", "유선통신": "통신",
	"전력": "전력/에너지", "에너지": "전력/에너지", "가스": "전력/에너지",
	"식품": "식품", "음료": "식품", "식료품": "식품",
	"섬유": "섬유/의류", "의류": "섬유/의류", "패션": "섬유/의류",
}

# ══════════════════════════════════════
# 교차검증 규칙
# ══════════════════════════════════════

_CROSS_VALIDATION_RULES = """
## 교차검증 체크리스트

분석 시 다음 교차검증을 반드시 수행하세요:

1. **영업이익 vs 영업CF**: 영업이익이 흑자인데 영업CF가 적자이면 이익의 질 의심
2. **매출 성장 vs 매출채권 증가율**: 매출채권이 매출보다 빠르게 증가하면 대손 리스크
3. **영업이익률 vs 동종업계**: 업종 평균 대비 현저히 높거나 낮으면 원인 규명
4. **부채비율 급등**: 전년 대비 30%p 이상 상승 시 BS/CF 교차 분석
5. **감사의견**: 적정 외 의견(한정, 부적정, 의견거절)이면 재무제표 신뢰성 경고
6. **이자보상배율 < 1**: 영업이익으로 이자비용을 감당 못함 → 재무 위기 신호
7. **FCF(영업CF-CAPEX)**: 3년 연속 음수이면 외부 자금 의존도 상승
"""

# ══════════════════════════════════════
# 토픽별 추가 프롬프트
# ══════════════════════════════════════

_TOPIC_PROMPTS: dict[str, tuple[set[str], str]] = {
	"governance": (
		{"majorHolder", "executive", "boardOfDirectors", "holderOverview", "auditSystem"},
		"\n## 지배구조 분석 참고\n"
		"- 사외이사 비율 1/3 이상은 상법상 요건 (자산총액 2조 이상)\n"
		"- 최대주주 지분율 30% 이상이면 경영권 안정\n"
		"- 감사위원회 전원 사외이사 여부 확인\n"
		"- 이사회 출석률 80% 미만은 형식적 운영 우려\n",
	),
	"risk": (
		{"contingentLiability", "sanction", "riskDerivative", "internalControl"},
		"\n## 리스크 분석 참고\n"
		"- 우발부채는 현재 인식되지 않은 잠재 부채\n"
		"- 채무보증 금액이 자기자본 대비 높으면 위험\n"
		"- 내부통제 취약점은 재무제표 신뢰성에 영향\n"
		"- 반복 제재는 구조적 컴플라이언스 문제\n",
	),
	"dividend": (
		{"dividend", "shareCapital"},
		"\n## 배당 분석 참고\n"
		"- 배당성향 100% 초과 = 순이익 이상 배당 (지속 불가능)\n"
		"- DPS 연속 증가는 주주환원 의지의 지표\n"
		"- 자기주식 소각은 추가적 주주환원 수단\n",
	),
	"investment": (
		{"rnd", "tangibleAsset", "subsidiary", "investmentInOther"},
		"\n## 투자 분석 참고\n"
		"- R&D 비율이 매출 대비 높으면 기술 집약적 기업\n"
		"- CAPEX가 감가상각을 초과하면 성장 투자 중\n"
		"- 자회사 투자 증가는 사업 다각화 또는 수직계열화\n",
	),
}

# ══════════════════════════════════════
# Few-shot 예시
# ══════════════════════════════════════

_FEW_SHOT_EXAMPLES: dict[str, str] = {
	"건전성": """
## 분석 예시 (재무 건전성)

Q: 이 기업의 재무 건전성을 분석해주세요.

A: ## 재무 건전성 분석

### 1. 부채비율 추이
- 2023년: 45.2% (양호) ← BS: 부채총계 4,520백만원 / 자본총계 10,000백만원
- 2022년: 52.1% → 2023년 6.9%p 개선

### 2. 유동비율
- 2023년: 185.3% (양호) ← BS: 유동자산 8,200백만원 / 유동부채 4,425백만원
- 단기 채무 상환 능력 충분

### 3. 현금흐름 건전성
- 영업CF 3,200백만원 > 순이익 2,100백만원 → 이익의 질 양호 (CF 기준)
- FCF(영업CF - 투자CF): +1,200백만원 → 자체 자금 조달 가능

### 4. 감사의견: 적정 (2020-2023 연속)

### 결론
부채비율 개선 추세, 유동비율 양호, 영업CF 기반 이익의 질 확인됨.
부정적 신호 없음. 재무 건전성 **양호** 판단.
""",
	"수익성": """
## 분석 예시 (수익성)

Q: 수익성을 분석해주세요.

A: ## 수익성 분석

### 1. 매출/이익 추이 (IS 기준)
| 연도 | 매출액 | 영업이익 | 영업이익률 | 순이익 |
|------|--------|----------|------------|--------|
| 2023 | 20,000 | 3,000 | 15.0% | 2,100 |
| 2022 | 18,000 | 2,500 | 13.9% | 1,800 |
| 2021 | 16,000 | 2,200 | 13.8% | 1,600 |

### 2. 성장률
- 매출 CAGR(3Y): +11.8%
- 영업이익 CAGR(3Y): +16.8% → 매출 성장 대비 이익 개선 (레버리지 효과)

### 3. ROE 분석
- 2023년: 21.0% ← IS: 순이익 2,100 / BS: 자본총계 10,000
- 업종 평균 대비 우수

### 결론
매출·이익 동반 성장, 영업이익률 개선 추세, ROE 20%+ 수준.
**수익성 우수** 판단. 단, 원가율 변동 리스크 모니터링 필요.
""",
	"성장성": """
## 분석 예시 (성장성)

Q: 성장성은 어떤가요?

A: ## 성장성 분석

### 1. 매출 성장률 (IS 기준)
- 2023/2022: +11.1% (20,000/18,000)
- 2022/2021: +12.5% (18,000/16,000)
- 3Y CAGR: +11.8% → 안정적 두 자릿수 성장

### 2. 사업부문별 성장 (segment 기준)
- A 부문: +15.3% (성장 견인)
- B 부문: +5.1% (안정)

### 3. R&D 투자 (성장 지속가능성)
- R&D/매출: 8.5% → 기술 투자 지속 중

### 4. 총자산 증가율
- 2023/2022: +8.2% → 매출 성장률 하회 (자산 효율성 개선)

### 결론
안정적 두 자릿수 매출 성장 유지 중. R&D 투자 지속으로 성장 모멘텀 양호.
""",
	"배당": """
## 분석 예시 (배당)

Q: 배당 정책을 분석해주세요.

A: ## 배당 분석

### 1. 배당 추이
| 연도 | DPS(원) | 배당수익률 | 배당성향 |
|------|---------|------------|----------|
| 2023 | 1,500 | 2.8% | 35.7% |
| 2022 | 1,200 | 2.5% | 33.3% |
| 2021 | 1,000 | 2.2% | 31.3% |

### 2. 배당 지속가능성
- DPS 3년 연속 증가 (+25.0%, +20.0%)
- 배당성향 30-36% → 안정적 범위
- FCF 대비 배당: 충분한 커버리지

### 결론
DPS 연속 증가, 배당성향 적정 범위 내. **주주환원 정책 양호** 판단.
""",
	"지배구조": """
## 분석 예시 (지배구조)

Q: 지배구조를 분석해주세요.

A: ## 지배구조 분석

### 1. 최대주주 (majorHolder 기준)
- 최대주주: OO그룹 회장 외 특수관계인
- 지분율: 35.2% → 경영권 안정

### 2. 이사회 구성 (executive 기준)
- 총 이사: 8명 (사내 5, 사외 3)
- 사외이사 비율: 37.5% → 상법 1/3 요건 충족

### 3. 감사 (audit 기준)
- 감사의견: 적정 (5년 연속)
- 감사인: 4대 회계법인

### 결론
경영권 안정, 이사회 독립성 기본 요건 충족, 감사의견 양호.
""",
	"종합": """
## 분석 예시 (종합 분석)

Q: 이 기업을 종합 분석해주세요.

A: ## 종합 분석

### 1. 수익성: 양호
- 영업이익률 15.0%, ROE 21.0% (IS/BS 기준)
- 3년 연속 매출·이익 성장

### 2. 재무건전성: 양호
- 부채비율 45.2%, 유동비율 185.3% (BS 기준)
- 감사의견 적정

### 3. 현금흐름: 양호
- 영업CF > 순이익, FCF 양수 (CF 기준)

### 4. 주주환원: 양호
- DPS 3년 연속 증가, 배당성향 35.7%

### 5. 리스크 요인
- 특이사항 없음 (우발부채 미미)

### 종합 평가
수익성·건전성·현금흐름 모두 양호한 우량 기업.
지속적인 R&D 투자로 성장 모멘텀 유지 중.
주의: 업황 변동성, 환율 영향 모니터링 필요.
""",
}

# 질문 분류 키워드 매핑
_QUESTION_TYPE_MAP: dict[str, list[str]] = {
	"건전성": ["건전", "안전", "부채", "유동", "안정", "재무상태", "위험"],
	"수익성": ["수익", "이익률", "마진", "ROE", "ROA", "영업이익"],
	"성장성": ["성장", "매출증가", "CAGR", "전망", "미래"],
	"배당": ["배당", "DPS", "주주환원", "배당성향", "배당률"],
	"지배구조": ["지배", "주주", "이사", "감사", "경영권", "거버넌스"],
	"리스크": ["리스크", "위험", "우발", "소송", "제재", "이상"],
	"종합": ["종합", "전반", "전체", "분석해"],
}


def _classify_question(question: str) -> str | None:
	"""질문 텍스트를 분석 유형으로 분류.

	Returns:
		"건전성", "수익성", "성장성", "배당", "지배구조", "리스크", "종합" 또는 None
	"""
	scores: dict[str, int] = {}
	for q_type, keywords in _QUESTION_TYPE_MAP.items():
		score = sum(1 for kw in keywords if kw in question)
		if score > 0:
			scores[q_type] = score

	if not scores:
		return None

	return max(scores, key=scores.get)


def _match_sector(sector_name: str) -> str | None:
	"""KRX 업종명에서 벤치마크 키 매칭."""
	if not sector_name:
		return None

	# 정확 매칭
	if sector_name in _SECTOR_MAP:
		return _SECTOR_MAP[sector_name]

	# 키워드 부분 매칭
	for keyword, benchmark_key in _SECTOR_MAP.items():
		if keyword in sector_name:
			return benchmark_key

	return None


def build_system_prompt(
	custom: str | None = None,
	lang: str = "ko",
	included_modules: list[str] | None = None,
	sector: str | None = None,
	question_type: str | None = None,
) -> str:
	"""시스템 프롬프트 조립.

	Args:
		custom: 사용자 지정 프롬프트 (있으면 이것만 사용)
		lang: "ko" 또는 "en"
		included_modules: 컨텍스트에 포함된 모듈 목록 → 토픽 프롬프트 동적 추가
		sector: KRX 업종명 → 업종별 벤치마크 추가
		question_type: 질문 유형 → Few-shot 예시 추가
	"""
	if custom:
		return custom

	base = SYSTEM_PROMPT_KR if lang == "ko" else SYSTEM_PROMPT_EN
	appended: list[str] = []

	# 업종별 벤치마크
	if sector:
		benchmark_key = _match_sector(sector)
		if benchmark_key and benchmark_key in _INDUSTRY_BENCHMARKS:
			appended.append(_INDUSTRY_BENCHMARKS[benchmark_key])

	# 토픽 프롬프트
	if included_modules:
		module_set = set(included_modules)
		for _topic_name, (trigger_modules, prompt_text) in _TOPIC_PROMPTS.items():
			if module_set & trigger_modules:
				appended.append(prompt_text)

	# 교차검증 규칙 (재무제표 포함 시)
	if included_modules:
		fs_modules = {"BS", "IS", "CF"}
		if fs_modules & set(included_modules):
			appended.append(_CROSS_VALIDATION_RULES)

	# Few-shot 예시
	if question_type and question_type in _FEW_SHOT_EXAMPLES:
		appended.append(_FEW_SHOT_EXAMPLES[question_type])

	if appended:
		return base + "\n".join(appended)

	return base
