Ramp Parameters
===============

CTSChamberRampParameters
------------------------

.. autoclass:: cts_chamber.CTSChamberRampParameters
   :members:
   :undoc-members:
   :show-inheritance:

   Configuration and status information for temperature and humidity ramp operations.

   **Example Usage:**

   .. code-block:: python

      # Configure a new temperature ramp
      chamber.ramp_to_temperature(
          target=50.0,
          rate_up=2.0,
          rate_down=1.5
      )

      # Get current ramp parameters
      temp_ramp = chamber.get_temperature_ramp_information()

      print(f"Temperature ramp active: {temp_ramp.ramp_active}")
      print(f"Target temperature: {temp_ramp.ramp_target}°C")
      print(f"Ramp up rate: {temp_ramp.ramp_rate_up} K/min")
