Exceptions
==========

Communication and Command Exceptions
------------------------------------

CTSChamberCommunicationError
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoexception:: cts_chamber.CTSChamberCommunicationError
   :show-inheritance:

   Raised when communication cannot be established with the CTS chamber. This typically
   occurs when the physical connection is lost, the device is not responding, or
   there are issues with the communication protocol.

   **Possible Causes:**

   * Serial port disconnected or in use by another application
   * Device powered off or unresponsive

CTSChamberCommandError
~~~~~~~~~~~~~~~~~~~~~~

.. autoexception:: cts_chamber.CTSChamberCommandError
   :show-inheritance:

   Raised when there is an error in a command sent or a response received from the CTS chamber.


CTSChamberOperationTimeoutError
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoexception:: cts_chamber.CTSChamberOperationTimeoutError
   :show-inheritance:

   Raised when a command to the CTS chamber times out. This occurs when the chamber
   does not respond within the configured timeout period.

   **Possible Causes:**

   * Chamber is busy processing a previous command
   * Communication timeout set too low for the operation
   * Device malfunction or heavy computational load

**Exception Hierarchy:**

.. code-block:: text

   Exception
   ├── CTSChamberCommunicationError
   ├── CTSChamberCommandError
   └── CTSChamberOperationTimeoutError
