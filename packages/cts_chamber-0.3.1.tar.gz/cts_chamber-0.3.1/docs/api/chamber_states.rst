Chamber States
==============

CTSState
--------

.. autoclass:: cts_chamber.CTSState
   :members:
   :exclude-members: __init__
   :show-inheritance:

   Represents the current state of the CTS environmental chamber, including operational status
   information, humidity control status, and errors.

CTSStateError
-------------

.. autoclass:: cts_chamber.CTSStateError
   :members:
   :undoc-members:
   :show-inheritance:

   Enumeration of possible error states that can occur in the CTS chamber.
