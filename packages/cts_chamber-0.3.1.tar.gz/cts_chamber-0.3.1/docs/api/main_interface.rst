Main Interface
==============

CTSChamber
----------

.. autoclass:: cts_chamber.CTSChamber
   :members:
   :undoc-members:
   :show-inheritance:

   The main class for controlling CTS environmental chambers. This class provides methods
   for setting temperature and humidity, reading chamber state, and managing ramp operations.

   **Key Features:**

   * Temperature and humidity control
   * State monitoring and error detection
   * Ramp parameter management
   * Communication via RS-232
   * Support for multiple CTS chamber models

   **Example Usage:**

   .. code-block:: python

      from cts_chamber import CTSChamber, CTSChamberModel

      # Connect to chamber via serial port
      chamber = CTSChamber(
          serial_device="/dev/ttyUSB0",
      )

      # Set temperature and humidity
      chamber.set_temperature(25.0)
      chamber.set_humidity(50.0)

      # Read current temperature and temperature setpoint
      current, set_point = chamber.get_temperature()
      print(f"Current temperture is {current} °C")
      print(f"Setpoint is {set_point} °C")
