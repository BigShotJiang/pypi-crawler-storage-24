Constants
=========

CTSChamberModel
---------------

.. autoclass:: cts_chamber.CTSChamberModel
   :members:
   :undoc-members:
   :show-inheritance:

   Enumeration of supported CTS environmental chamber models.

   **Supported Models:**

   * **C_40**: CTS C-40/... environmental chamber series
   * **C_65**: CTS C-65/... environmental chamber series
   * **C_70**: CTS C-70/... environmental chamber series

   Each model may have different operational characteristics, temperature/humidity
   ranges, and communication protocols. The chamber model affects internal
   parameter validation.

   **Example Usage:**

   .. code-block:: python

      from cts_chamber import CTSChamber, CTSChamberModel

      # Specify chamber model during initialization
      chamber_c40 = CTSChamber(
          serial_device="/dev/ttyUSB0",
          chamber_model=CTSChamberModel.C_40
      )

      chamber_c65 = CTSChamber(
          serial_device="/dev/ttyUSB1",
          chamber_model=CTSChamberModel.C_65
      )

      # Check the configured model
      print(f"Using chamber model: {chamber_c40.chamber_model.value}")
