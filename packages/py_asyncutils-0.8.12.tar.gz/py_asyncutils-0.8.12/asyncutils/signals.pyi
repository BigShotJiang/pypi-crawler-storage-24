from ._internal.protocols import ValidExcType
from _collections_abc import Callable, Awaitable
from signal import Signals
from typing import Literal, overload
from asyncio.events import AbstractEventLoop
from logging import Logger
__all__ = 'wait_for_signal',
@overload
async def wait_for_signal[T](processor: Callable[[Signals], Awaitable[T]], *S: int, timeout: float|None=..., raise_on_timeout: Literal[True], loop: AbstractEventLoop|None=..., possible_errors: tuple[ValidExcType, ...]=..., default_on_processor_failure: T, logger: Logger=...) -> T: ...
@overload
async def wait_for_signal[T](processor: Callable[[Signals], Awaitable[T]], *S: int, timeout: float|None=..., raise_on_timeout: Literal[True], loop: AbstractEventLoop|None=..., possible_errors: tuple[ValidExcType, ...]=..., logger: Logger=...) -> T|None: ...
@overload
async def wait_for_signal[T](processor: Callable[[Signals], Awaitable[T]], *S: int, timeout: float|None=..., raise_on_timeout: Literal[False]=..., loop: AbstractEventLoop|None=..., possible_errors: tuple[ValidExcType, ...]=..., logger: Logger=...) -> T|None: ...
@overload
async def wait_for_signal[T](processor: Callable[[Signals], Awaitable[T]], *S: int, timeout: float|None=..., raise_on_timeout: Literal[False]=..., loop: AbstractEventLoop|None=..., possible_errors: tuple[ValidExcType, ...]=..., default_on_processor_failure: T, logger: Logger=...) -> T|None: ...
@overload
async def wait_for_signal[T](processor: Callable[[Signals], T], *S: int, timeout: float|None=..., raise_on_timeout: Literal[True], loop: AbstractEventLoop|None=..., possible_errors: tuple[ValidExcType, ...]=..., default_on_processor_failure: T, logger: Logger=...) -> T: ...
@overload
async def wait_for_signal[T](processor: Callable[[Signals], T], *S: int, timeout: float|None=..., raise_on_timeout: Literal[True], loop: AbstractEventLoop|None=..., possible_errors: tuple[ValidExcType, ...]=..., logger: Logger=...) -> T|None: ...
@overload
async def wait_for_signal[T](processor: Callable[[Signals], T], *S: int, timeout: float|None=..., raise_on_timeout: Literal[False]=..., loop: AbstractEventLoop|None=..., possible_errors: tuple[ValidExcType, ...]=..., logger: Logger=...) -> T|None: ...
@overload
async def wait_for_signal[T](processor: Callable[[Signals], T], *S: int, timeout: float|None=..., raise_on_timeout: Literal[False]=..., loop: AbstractEventLoop|None=..., possible_errors: tuple[ValidExcType, ...]=..., default_on_processor_failure: T, logger: Logger=...) -> T|None:
    '''Wait for a signal to be signaled within `timeout`. `processor` is a function, preferrably returning an awaitable, that takes the signals specified by the variadic positional arguments.
    If `raise_on_timeout` is True, throw TimeoutError on timeout. Otherwise, return None.
    If `loop` was passed, the add_signal_handler and remove_signal_handler methods of that event loop will be used.
    Errors whose types are included in `possible_errors` cause the logger `logger` to emit an error and the function to return `default_on_processor_failure` (or None if not passed).
    Some info related to the progress of the wait also goes to the logger.
    The return value of the processor is returned through this function.'''