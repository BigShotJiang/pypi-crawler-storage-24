"""
Example usage of the ValenceAI plugin for LiveKit Agents.

This example demonstrates how to use the ValenceAI plugin to detect emotions
in real-time audio streams using the LiveKit Agents framework.
"""

from livekit.agents import AgentSession, Agent, RoomInputOptions
from livekit.plugins import deepgram, valenceai


class MyAgent(Agent):
    def __init__(self):
        super().__init__(
            instructions="You are a helpful assistant. Respond to user emotions appropriately.",
        )


async def entrypoint(ctx):
    # Initialize the emotion-aware STT
    emotion_stt = valenceai.STT(
        underlying_stt=deepgram.STT(),  # or any LiveKit-compatible STT
        # api_key="...",  # or set VALENCE_API_KEY env var
        model="4emotions",
        min_confidence=0.3,
    )

    session = AgentSession(
        stt=emotion_stt,
    )

    await session.start(
        agent=MyAgent(),
        room=ctx.room,
        room_input_options=RoomInputOptions(),
    )
