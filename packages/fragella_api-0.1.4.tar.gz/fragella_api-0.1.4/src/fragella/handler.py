from typing import Optional

import requests


class FragellaHandler:
    def __init__(self, api_key: str, session: Optional[requests.Session] = None):
        self.api_key = api_key
        self.session = session if session else requests.session()
        self.url = "https://api.fragella.com/api/v1"
        self.session.headers.update({"x-api-key": self.api_key})

    def usage(self):
        res = self.session.get(url=f"{self.url}/usage")
        res.raise_for_status()
        return res.json()

    def search_fragance(self, fragance: str, limit: int = 5):
        res = self.session.get(
            url=f"{self.url}/fragrances", params={"search": fragance, "limit": limit}
        )
        res.raise_for_status()
        return res.json()

    def match(self, matches: dict):
        res = self.session.get(url=f"{self.url}/fragrances/match", params=matches)
        res.raise_for_status()
        return res.json()

    def similar(self, name: str, limit: int = 5):
        res = self.session.get(
            url=f"{self.url}/fragrances/similar", params={"name": name, "limit": limit}
        )
        res.raise_for_status()
        return res.json()

    def retrieve_by_brand(self, brand: str, limit: int = 5):
        res = self.session.get(
            url=f"{self.url}/brands/{brand}", params={"limit": limit}
        )
        res.raise_for_status()
        return res.json()

    def search_notes(self, note: str, limit: int = 5):
        res = self.session.get(
            url=f"{self.url}/notes", params={"search": note, "limit": limit}
        )
        res.raise_for_status()
        return res.json()

    def search_accords(self, accord: str, limit: int = 5):
        res = self.session.get(
            url=f"{self.url}/accords", params={"search": accord, "limit": limit}
        )
        res.raise_for_status()
        return res.json()
