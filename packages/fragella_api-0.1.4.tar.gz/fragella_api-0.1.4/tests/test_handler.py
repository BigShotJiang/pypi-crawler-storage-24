import pytest
import requests
import requests_mock

from src.fragella import FragellaHandler


class TestHandler(FragellaHandler): ...


@pytest.fixture
def adapter():
    adapter = requests_mock.Adapter()
    yield adapter


@pytest.fixture
def mock_session(adapter):
    print("Setting up mock session")
    session = requests.Session()
    session.mount("https://", adapter)
    yield session


@pytest.fixture
def handler(mock_session):
    print("Creating base class...")
    handler = TestHandler("testapikey", session=mock_session)
    yield handler
    print("Tearing down....")


# TODO: setip class to make test shorter
# class TestFragellaHandler:

#     @pytest.fixture(scope="class", autouse=True)
#     def setup_adapter(self):
#         adapter = requests_mock.Adapter()
#         yield adapter

#     @pytest.fixture(scope="class", autouse=True)
#     def setup_session(self, adapter):


def test_usage(handler: TestHandler, adapter):
    mock_data = {
        "plan": "payg",
        "billing_period": {
            "start": "2026-03-03T15:34:34.439Z",
            "end": "2026-04-03T15:34:34.438Z",
        },
        "limit": {
            "total_effective_limit": "",
            "base_limit": "",
            "carried_over_from_previous_period": 0,
        },
        "usage": {"requests_made": 420, "requests_remaining": ""},
    }
    adapter.register_uri("GET", "https://api.fragella.com/api/v1/usage", json=mock_data)

    result = handler.usage()
    assert result == mock_data


def test_search_fragance(handler: TestHandler, adapter): ...
