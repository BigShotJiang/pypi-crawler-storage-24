# chai_gacha

A powerful and easy-to-use Python package for calculating gacha drop rates, soft pity mechanics, and currency planning for your favorite anime games.

## Installation

You can install this package via pip:

```bash
pip install chai_gacha
```

## Features and Usage

Here are the main functions available in this package:

### 1. Pity Rate Calculator
Calculate the exact probability of getting at least one rare item after N pulls.

```python
import chai_gacha

# Calculate chance of getting an SSR (1% drop rate) in 50 pulls
chance = chai_gacha.calculate_pity_rate(0.01, 50)
print(f"Chance to get SSR: {chance}%")
```

### 2. Soft Pity Drop Rate
Check the exact drop rate at a specific pull, factoring in soft pity mechanics.

```python
import chai_gacha

base_rate = 0.006     # 0.6% base rate
soft_pity = 74        # Soft pity starts at pull 74
hard_pity = 90        # Guaranteed at pull 90
current_pull = 75

# Calculate rate for pull number 75
rate = chai_gacha.calculate_current_pull_rate(current_pull, base_rate, soft_pity, hard_pity)
print(f"Drop rate at pull 75: {rate}%")
```

### 3. Currency Planner
Plan your premium currency for the upcoming banners.

```python
import chai_gacha

my_gems = 10000
pull_cost = 160
hard_pity = 90

# Check how many pulls you can do
pulls = chai_gacha.convert_currency_to_pulls(my_gems, pull_cost)

# Calculate max gems needed if you lose the 50/50
max_gems_needed = chai_gacha.calculate_max_currency_needed(hard_pity, pull_cost, is_guaranteed_next=False)
```