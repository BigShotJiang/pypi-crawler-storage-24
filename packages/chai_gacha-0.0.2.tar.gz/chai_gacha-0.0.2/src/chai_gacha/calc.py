# Calculate the exact probability of not getting a rare item after N pulls
def calculate_pity_rate(base_rate: float, pulls: int) -> float:
    # Failure rate is 1 minus the base rate
    failure_rate = 1.0 - base_rate
    
    # Total failure probability after N pulls
    total_failure = failure_rate ** pulls
    
    # Probability of getting at least one rare item
    success_chance = (1.0 - total_failure) * 100.0
    
    return round(success_chance, 2)

# Calculate the exact drop rate for a specific pull number considering soft pity mechanics
def calculate_current_pull_rate(current_pull: int, base_rate: float, soft_pity_start: int, hard_pity: int) -> float:
    # If the pull is at or beyond hard pity, the drop is guaranteed (100% chance)
    if current_pull >= hard_pity:
        return 100.0
        
    # If the pull is before soft pity starts, it uses the normal base rate
    if current_pull < soft_pity_start:
        return round(base_rate * 100.0, 2)
        
    # Calculate the linearly increased rate during the soft pity phase
    rate_increase_step = (1.0 - base_rate) / (hard_pity - soft_pity_start + 1)
    pulls_in_soft_pity = current_pull - soft_pity_start + 1
    
    current_rate = base_rate + (rate_increase_step * pulls_in_soft_pity)
    
    # Return the percentage rounded to two decimal places
    return round(current_rate * 100.0, 2)

# Convert total premium currency into the exact number of available pulls
def convert_currency_to_pulls(currency_amount: int, cost_per_pull: int) -> int:
    # Using integer division (//) to get the exact whole number of pulls without decimals
    return currency_amount // cost_per_pull

# Calculate the absolute maximum currency required to guarantee the featured banner character
def calculate_max_currency_needed(hard_pity: int, cost_per_pull: int, is_guaranteed_next: bool) -> int:
    # If the next SSR is guaranteed to be the featured character, we only need 1 hard pity
    if is_guaranteed_next:
        max_pulls = hard_pity
    # If it's a 50/50 chance, we might lose once and need 2 hard pities in the worst-case scenario
    else:
        max_pulls = hard_pity * 2
        
    return max_pulls * cost_per_pull    