# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class RestorePtrReq:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'ptrdname': 'object'
    }

    attribute_map = {
        'ptrdname': 'ptrdname'
    }

    def __init__(self, ptrdname=None):
        r"""RestorePtrReq

        The model defined in huaweicloud sdk

        :param ptrdname: 反向解析记录对应的域名。  此处值为null。
        :type ptrdname: object
        """
        
        

        self._ptrdname = None
        self.discriminator = None

        self.ptrdname = ptrdname

    @property
    def ptrdname(self):
        r"""Gets the ptrdname of this RestorePtrReq.

        反向解析记录对应的域名。  此处值为null。

        :return: The ptrdname of this RestorePtrReq.
        :rtype: object
        """
        return self._ptrdname

    @ptrdname.setter
    def ptrdname(self, ptrdname):
        r"""Sets the ptrdname of this RestorePtrReq.

        反向解析记录对应的域名。  此处值为null。

        :param ptrdname: The ptrdname of this RestorePtrReq.
        :type ptrdname: object
        """
        self._ptrdname = ptrdname

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, RestorePtrReq):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
