# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowPublicZoneNameServerResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'nameservers': 'list[Nameserver]'
    }

    attribute_map = {
        'nameservers': 'nameservers'
    }

    def __init__(self, nameservers=None):
        r"""ShowPublicZoneNameServerResponse

        The model defined in huaweicloud sdk

        :param nameservers: **参数解释：** 查询公网域名的名称服务器响应。 **取值范围：** 不涉及。
        :type nameservers: list[:class:`huaweicloudsdkdns.v2.Nameserver`]
        """
        
        super().__init__()

        self._nameservers = None
        self.discriminator = None

        if nameservers is not None:
            self.nameservers = nameservers

    @property
    def nameservers(self):
        r"""Gets the nameservers of this ShowPublicZoneNameServerResponse.

        **参数解释：** 查询公网域名的名称服务器响应。 **取值范围：** 不涉及。

        :return: The nameservers of this ShowPublicZoneNameServerResponse.
        :rtype: list[:class:`huaweicloudsdkdns.v2.Nameserver`]
        """
        return self._nameservers

    @nameservers.setter
    def nameservers(self, nameservers):
        r"""Sets the nameservers of this ShowPublicZoneNameServerResponse.

        **参数解释：** 查询公网域名的名称服务器响应。 **取值范围：** 不涉及。

        :param nameservers: The nameservers of this ShowPublicZoneNameServerResponse.
        :type nameservers: list[:class:`huaweicloudsdkdns.v2.Nameserver`]
        """
        self._nameservers = nameservers

    def to_dict(self):
        import warnings
        warnings.warn("ShowPublicZoneNameServerResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowPublicZoneNameServerResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
