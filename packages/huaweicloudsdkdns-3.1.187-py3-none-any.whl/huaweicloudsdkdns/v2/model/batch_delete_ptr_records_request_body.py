# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class BatchDeletePtrRecordsRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'floatingip_ids': 'list[str]'
    }

    attribute_map = {
        'floatingip_ids': 'floatingip_ids'
    }

    def __init__(self, floatingip_ids=None):
        r"""BatchDeletePtrRecordsRequestBody

        The model defined in huaweicloud sdk

        :param floatingip_ids: 待删除反向解析记录ID列表。 最多支持50个。
        :type floatingip_ids: list[str]
        """
        
        

        self._floatingip_ids = None
        self.discriminator = None

        if floatingip_ids is not None:
            self.floatingip_ids = floatingip_ids

    @property
    def floatingip_ids(self):
        r"""Gets the floatingip_ids of this BatchDeletePtrRecordsRequestBody.

        待删除反向解析记录ID列表。 最多支持50个。

        :return: The floatingip_ids of this BatchDeletePtrRecordsRequestBody.
        :rtype: list[str]
        """
        return self._floatingip_ids

    @floatingip_ids.setter
    def floatingip_ids(self, floatingip_ids):
        r"""Sets the floatingip_ids of this BatchDeletePtrRecordsRequestBody.

        待删除反向解析记录ID列表。 最多支持50个。

        :param floatingip_ids: The floatingip_ids of this BatchDeletePtrRecordsRequestBody.
        :type floatingip_ids: list[str]
        """
        self._floatingip_ids = floatingip_ids

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, BatchDeletePtrRecordsRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
