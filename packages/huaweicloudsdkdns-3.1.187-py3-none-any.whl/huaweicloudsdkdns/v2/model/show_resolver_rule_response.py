# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowResolverRuleResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'resolver_rule': 'ShowResolverRuleRespParam'
    }

    attribute_map = {
        'resolver_rule': 'resolver_rule'
    }

    def __init__(self, resolver_rule=None):
        r"""ShowResolverRuleResponse

        The model defined in huaweicloud sdk

        :param resolver_rule: 
        :type resolver_rule: :class:`huaweicloudsdkdns.v2.ShowResolverRuleRespParam`
        """
        
        super().__init__()

        self._resolver_rule = None
        self.discriminator = None

        if resolver_rule is not None:
            self.resolver_rule = resolver_rule

    @property
    def resolver_rule(self):
        r"""Gets the resolver_rule of this ShowResolverRuleResponse.

        :return: The resolver_rule of this ShowResolverRuleResponse.
        :rtype: :class:`huaweicloudsdkdns.v2.ShowResolverRuleRespParam`
        """
        return self._resolver_rule

    @resolver_rule.setter
    def resolver_rule(self, resolver_rule):
        r"""Sets the resolver_rule of this ShowResolverRuleResponse.

        :param resolver_rule: The resolver_rule of this ShowResolverRuleResponse.
        :type resolver_rule: :class:`huaweicloudsdkdns.v2.ShowResolverRuleRespParam`
        """
        self._resolver_rule = resolver_rule

    def to_dict(self):
        import warnings
        warnings.warn("ShowResolverRuleResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowResolverRuleResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
