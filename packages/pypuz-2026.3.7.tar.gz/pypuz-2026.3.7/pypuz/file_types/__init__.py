"""
This module contains parsers and writers for various crossword file formats.
"""
