"""dx — developer experience CLI for Docker Compose projects."""

__version__ = "0.4.0"
