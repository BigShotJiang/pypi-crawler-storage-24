"""Command implementations for the dx CLI.

Project-agnostic: uses ComposeCatalog for service discovery and
auto-detects service types from the filesystem.
"""

from __future__ import annotations

import json
import os
import re
import signal
import subprocess
import sys
import time
from pathlib import Path
from urllib.error import URLError
from urllib.request import Request, urlopen

from dx.compose import ComposeCatalog, ServiceInfo, port_env_var
from dx.output import info, warn, error, success, header, dim
from dx.ports import (
    PortManager,
    PROXY_PORT,
    start_proxy_foreground,
    start_proxy_daemon,
    stop_proxy_daemon,
    hosts_setup,
    hosts_remove,
    hosts_status,
)


def _run(
    cmd: list[str],
    cwd: str | Path | None = None,
    check: bool = True,
    env: dict[str, str] | None = None,
) -> int:
    """Run a command, forwarding output to the terminal."""
    run_env = None
    if env:
        run_env = {**os.environ, **env}
    try:
        result = subprocess.run(cmd, cwd=cwd, env=run_env)
        if check and result.returncode != 0:
            error(
                f"Command failed (exit {result.returncode}): {' '.join(str(c) for c in cmd[:4])}..."
            )
            sys.exit(result.returncode)
        return result.returncode
    except FileNotFoundError:
        error(f"Command not found: {cmd[0]}")
        sys.exit(1)
    except KeyboardInterrupt:
        return 130


def _exec(cmd: list[str], cwd: str | Path | None = None) -> None:
    """Replace the current process with a command (for long-running commands like logs)."""
    if cwd:
        os.chdir(cwd)
    os.execvp(cmd[0], cmd)


# ---------------------------------------------------------------------------
# Docker lifecycle commands
# ---------------------------------------------------------------------------


def _ensure_nginx_conf(root: Path) -> None:
    """Generate nginx.conf from template if it doesn't exist."""
    conf = root / "infra" / "nginx" / "nginx.conf"
    tpl = root / "infra" / "nginx" / "nginx.conf.tpl"
    if conf.exists() or not tpl.exists():
        return
    api_key = os.environ.get("CLICKSTACK_API_KEY", "placeholder")
    content = tpl.read_text().replace("__CLICKSTACK_API_KEY__", api_key)
    conf.write_text(content)


def _post_up(
    catalog: ComposeCatalog, dev: bool = False, port_env: dict[str, str] | None = None
) -> None:
    """Run post-startup hooks (init clickstack if present, restart gateway)."""
    # Only run clickstack init if the project uses it
    if catalog.has_service("clickstack-app"):
        _run_init_clickstack(catalog.root, quiet=True)

    # Restart api-gateway if it exists
    if catalog.has_service("api-gateway"):
        file_args = catalog.all_compose_file_args(dev=dev)
        restart_cmd = ["docker", "compose"] + file_args + ["restart", "api-gateway"]
        _run(restart_cmd, cwd=catalog.root, check=False, env=port_env)

    # Start proxy daemon if we allocated ports
    if port_env:
        start_proxy_daemon(catalog.root / ".dx")


def _extract_port_var(host_expr: str, service_name: str) -> tuple[str, str | None]:
    """Extract the env var name and default from a port host expression.

    Returns (env_var_name, default_port).
    "${AUTH_SERVICE_PORT:-8180}" -> ("AUTH_SERVICE_PORT", "8180")
    "${SERVICE_DATA_PORT:-8084}" -> ("SERVICE_DATA_PORT", "8084")
    "8084" (hardcoded) -> ("SERVICE_DATA_PORT", None)  (generated from service name)
    """
    m = re.match(r"^\$\{([^:}]+)(?::-([\d]+))?\}$", host_expr)
    if m:
        return m.group(1), m.group(2)
    # Hardcoded port — generate env var name from convention
    return port_env_var(service_name), None


def _all_ports_env(catalog: ComposeCatalog) -> dict[str, str]:
    """Allocate ports for ALL services with port mappings, not just the targeted ones.

    This is needed because compose files reference each other (services -> infra)
    and all env vars must be resolved even for services not being started.

    Respects existing env var names in compose files (e.g. AUTH_SERVICE_PORT).
    Handles services with multiple port mappings (e.g. infra services).
    """
    all_services_with_ports = [
        s for s in catalog.all_services if s in catalog._port_mappings
    ]
    if not all_services_with_ports:
        return {}

    state_dir = catalog.root / ".dx"
    pm = PortManager(state_dir)

    # Build a flat list of (env_var_name, service_name, default_port) for all port mappings
    port_entries: list[tuple[str, str, str | None]] = []
    for svc_name in all_services_with_ports:
        port_list = catalog._port_mappings.get(svc_name, [])
        if not port_list:
            continue
        if len(port_list) == 1:
            # Single port — use the service name as the reservation key
            host_expr = port_list[0][0]
            var_name, default = _extract_port_var(host_expr, svc_name)
            port_entries.append((var_name, svc_name, default))
        else:
            # Multiple ports — use the env var name as the reservation key
            for host_expr, container_port in port_list:
                var_name, default = _extract_port_var(host_expr, svc_name)
                # For hardcoded multi-port services, disambiguate with container port
                if default is None:
                    var_name = (
                        f"{svc_name.upper().replace('-', '_')}_{container_port}_PORT"
                    )
                    default = host_expr if host_expr.isdigit() else None
                port_entries.append((var_name, var_name, default))

    # Resolve ports: single-port services use service name, multi-port use var name
    resolve_keys = list(dict.fromkeys(entry[1] for entry in port_entries))
    port_assignments = pm.resolve(resolve_keys)

    env_vars: dict[str, str] = {}
    for var_name, resolve_key, _ in port_entries:
        if resolve_key in port_assignments:
            env_vars[var_name] = str(port_assignments[resolve_key])

    pm.write_env_file(port_assignments, state_dir / ".env")
    return env_vars


def _print_service_ports(
    services: list[str], port_env: dict[str, str], catalog: ComposeCatalog
) -> None:
    """Print port assignments for a set of targeted services."""
    for svc_name in services:
        port_list = catalog._port_mappings.get(svc_name, [])
        if not port_list:
            continue
        for host_expr, container_port in port_list:
            var_name, _ = _extract_port_var(host_expr, svc_name)
            port = port_env.get(var_name)
            if port:
                info(
                    f"  {svc_name} -> :{port}  (http://{svc_name}.dx.localhost:{PROXY_PORT})"
                )
                break  # Only show first port per service in summary


def cmd_up(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Start services in prod mode."""
    follow_logs = "--logs" in targets
    targets = [t for t in targets if t != "--logs"]

    services = catalog.resolve(targets)
    _ensure_nginx_conf(catalog.root)

    # Allocate ports for all services (compose needs all vars resolved)
    port_env = _all_ports_env(catalog)

    # Print assigned ports for targeted services
    _print_service_ports(services, port_env, catalog)

    cmd = catalog.compose_cmd(services, "up", "-d", "--build")
    _run(cmd, cwd=catalog.root, env=port_env)
    _post_up(catalog, dev=False, port_env=port_env)

    if follow_logs:
        logs_cmd = catalog.compose_cmd(services, "logs", "-f")
        _exec(logs_cmd, cwd=catalog.root)


def cmd_dev(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Start services in dev mode with hot-reload overlays."""
    follow_logs = "--logs" in targets
    targets = [t for t in targets if t != "--logs"]

    services = catalog.resolve(targets)
    _ensure_nginx_conf(catalog.root)

    port_env = _all_ports_env(catalog)

    _print_service_ports(services, port_env, catalog)

    cmd = catalog.compose_cmd(services, "up", "-d", "--build", dev=True)
    _run(cmd, cwd=catalog.root, env=port_env)
    _post_up(catalog, dev=True, port_env=port_env)

    if follow_logs:
        logs_cmd = catalog.compose_cmd(services, "logs", "-f")
        _exec(logs_cmd, cwd=catalog.root)


def cmd_down(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Stop and remove containers."""
    services = catalog.resolve(targets)
    cmd = catalog.compose_cmd(services, "down")
    _run(cmd, cwd=catalog.root)


def cmd_reset(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Stop containers and wipe volumes."""
    services = catalog.resolve(targets)
    cmd = catalog.compose_cmd(services, "down", "-v", "--remove-orphans")
    _run(cmd, cwd=catalog.root)


def cmd_restart(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Restart containers."""
    services = catalog.resolve(targets)
    cmd = catalog.compose_cmd(services, "restart")
    _run(cmd, cwd=catalog.root)


def cmd_logs(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Stream container logs (replaces current process)."""
    services = catalog.resolve(targets)
    cmd = catalog.compose_cmd(services, "logs", "-f")
    _exec(cmd, cwd=catalog.root)


def cmd_exec(catalog: ComposeCatalog, args: list[str]) -> None:
    """Execute a command inside a running container.

    Usage: dx exec [--it] <service> [command...]
    The --it flag allocates a pseudo-TTY and keeps stdin open (interactive mode).
    """
    interactive = False
    filtered: list[str] = []
    for a in args:
        if a in ("--it", "-it"):
            interactive = True
        else:
            filtered.append(a)

    if not filtered:
        error("Usage: dx exec [--it] <service> [command...]")
        sys.exit(1)

    service = catalog.resolve([filtered[0]])[0]
    run_cmd = filtered[1:] if len(filtered) > 1 else ["sh"]

    file_args = catalog.all_compose_file_args()
    cmd = ["docker", "compose"] + file_args + ["exec"]
    if interactive:
        cmd += ["-it"]
    cmd += [service] + run_cmd
    _exec(cmd, cwd=catalog.root)


def cmd_sh(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Open an interactive shell in a running container.

    Tries bash first, falls back to sh.
    Usage: dx sh <service>
    """
    if not targets:
        error("Usage: dx sh <service>")
        sys.exit(1)

    service = catalog.resolve([targets[0]])[0]
    file_args = catalog.all_compose_file_args()

    # Try bash first, fall back to sh
    bash_cmd = (
        ["docker", "compose"] + file_args + ["exec", "-it", service, "bash"]
    )
    rc = _run(bash_cmd, cwd=catalog.root, check=False)
    if rc != 0:
        info("bash not available, falling back to sh...")
        sh_cmd = (
            ["docker", "compose"] + file_args + ["exec", "-it", service, "sh"]
        )
        _exec(sh_cmd, cwd=catalog.root)


def cmd_inspect(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Show detailed container information via docker inspect.

    Usage: dx inspect <service> [--format <go-template>]
    """
    fmt = None
    filtered: list[str] = []
    i = 0
    while i < len(targets):
        if targets[i] in ("--format", "-f") and i + 1 < len(targets):
            fmt = targets[i + 1]
            i += 2
        else:
            filtered.append(targets[i])
            i += 1

    if not filtered:
        error("Usage: dx inspect <service> [--format <go-template>]")
        sys.exit(1)

    services = catalog.resolve(filtered)
    file_args = catalog.all_compose_file_args()

    # Get compose container names via `docker compose ps -q`
    for svc in services:
        ps_cmd = ["docker", "compose"] + file_args + ["ps", "-q", svc]
        result = subprocess.run(
            ps_cmd, cwd=catalog.root, capture_output=True, text=True
        )
        container_ids = result.stdout.strip().splitlines()
        if not container_ids:
            warn(f"No running container found for {svc}")
            continue
        inspect_cmd = ["docker", "inspect"]
        if fmt:
            inspect_cmd += ["--format", fmt]
        inspect_cmd += container_ids
        _run(inspect_cmd, cwd=catalog.root)


def cmd_ps(catalog: ComposeCatalog) -> None:
    """Show running containers."""
    cmd = ["docker", "compose"] + catalog.all_compose_file_args() + ["ps"]
    _run(cmd, cwd=catalog.root)


def cmd_pull(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Pull images."""
    services = catalog.resolve(targets)
    cmd = catalog.compose_cmd(services, "pull")
    _run(cmd, cwd=catalog.root)


def cmd_reload(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Recompile a service inside its dev container.

    For Java: runs mvn compile inside the container.
    """
    if not targets:
        error("Usage: dx reload <service>")
        sys.exit(1)

    service = catalog.resolve(targets)[0]
    si = catalog.service_info.get(service)

    if si and si.service_type == "java":
        cmd = (
            ["docker", "compose"]
            + catalog.all_compose_file_args(dev=True)
            + [
                "exec",
                service,
                "mvn",
                "compile",
                "-pl",
                "server",
                "-am",
                "-B",
                "-s",
                "/root/.m2/settings.xml",
            ]
        )
    else:
        # Generic: just restart the container
        warn(f"No reload strategy for {service} — restarting container instead")
        cmd = (
            ["docker", "compose"]
            + catalog.all_compose_file_args(dev=True)
            + [
                "restart",
                service,
            ]
        )

    _run(cmd, cwd=catalog.root)


# ---------------------------------------------------------------------------
# Build / Test / Lint (auto-detected)
# ---------------------------------------------------------------------------


def _find_common_java(root: Path) -> Path | None:
    """Find common Java libs directory if it exists."""
    candidate = root / "common" / "java"
    if candidate.is_dir() and (candidate / "pom.xml").exists():
        return candidate
    return None


def cmd_build(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Build services locally."""
    if not targets:
        targets = ["all"]

    for target in targets:
        if target == "all":
            info("Building all services...")
            common = _find_common_java(catalog.root)
            if common:
                info("Building common Java libs...")
                _run(["mvn", "install", "-DskipTests"], cwd=common)
            for si in catalog.service_info.values():
                if si.service_type and si.service_type != "python":
                    _build_service(si)
            continue

        if target == "common":
            common = _find_common_java(catalog.root)
            if common:
                info("Building common Java libs...")
                _run(["mvn", "install", "-DskipTests"], cwd=common)
            else:
                warn("No common/java directory found")
            continue

        # Resolve and build individual targets
        resolved = catalog.resolve([target])
        for svc_name in resolved:
            si = catalog.service_info.get(svc_name)
            if si and si.service_type:
                _build_service(si)
            elif si:
                warn(f"Skipping {svc_name}: could not detect service type")
            else:
                warn(f"Unknown target: {svc_name}")


def _build_service(si: ServiceInfo) -> None:
    if not si.directory or not si.directory.exists():
        warn(f"Skipping {si.name}: directory not found")
        return

    info(f"Building {si.name} ({si.service_type})...")
    if si.service_type == "java":
        _run(["mvn", "clean", "install", "-DskipTests", "-B"], cwd=si.directory)
    elif si.service_type == "node":
        _run(["pnpm", "install", "--frozen-lockfile"], cwd=si.directory)
        _run(["pnpm", "build"], cwd=si.directory)
    elif si.service_type == "python":
        warn(f"Skipping {si.name}: Python services have no build step")


def cmd_test(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Run tests for services inside Docker containers."""
    if not targets:
        targets = ["all"]

    port_env = _all_ports_env(catalog)

    for target in targets:
        if target == "all":
            info("Running all tests...")
            for si in catalog.service_info.values():
                if si.service_type:
                    _test_service(catalog, si, port_env)
            continue

        # Type-based targets: "python", "java", "node"
        if target in ("python", "java", "node"):
            for si in catalog.services_of_type(target):
                _test_service(catalog, si, port_env)
            continue

        resolved = catalog.resolve([target])
        for svc_name in resolved:
            si = catalog.service_info.get(svc_name)
            if si and si.service_type:
                _test_service(catalog, si, port_env)
            else:
                warn(f"Cannot test {svc_name}: no directory or type detected")


def _test_service(
    catalog: ComposeCatalog, si: ServiceInfo, port_env: dict[str, str]
) -> None:
    if not si.directory or not si.directory.exists():
        warn(f"Skipping {si.name}: directory not found")
        return

    info(f"Testing {si.name} ({si.service_type})...")

    if si.service_type == "java":
        # Run mvn test inside the dev container (has Maven + GCP auth + shared libs)
        file_args = catalog.compose_file_args([si.name], dev=True)
        cmd = (
            ["docker", "compose"]
            + file_args
            + [
                "run",
                "--rm",
                "--build",
                si.name,
                "mvn",
                "test",
                "-B",
                "-s",
                "/root/.m2/settings.xml",
            ]
        )
        _run(cmd, cwd=catalog.root, env=port_env)

    elif si.service_type == "python":
        # Run pytest inside the container (has GDAL, all pip deps).
        # Install test extras (pytest, httpx) before running.
        file_args = catalog.compose_file_args([si.name], dev=True)
        test_script = "pip install -q pytest httpx && python -m pytest"
        cmd = (
            ["docker", "compose"]
            + file_args
            + [
                "run",
                "--rm",
                "--build",
                si.name,
                "sh",
                "-c",
                test_script,
            ]
        )
        _run(cmd, cwd=catalog.root, env=port_env)

    elif si.service_type == "node":
        _run(["pnpm", "test", "--run"], cwd=si.directory)


def cmd_lint(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Run linters."""
    if not targets:
        info("Running all linters...")
        _run(["pre-commit", "run", "--all-files"], cwd=catalog.root, check=False)
        return

    for target in targets:
        if target == "all":
            _run(["pre-commit", "run", "--all-files"], cwd=catalog.root, check=False)

        elif target == "python":
            info("Linting Python services...")
            python_dirs = [
                si.relative_dir
                for si in catalog.services_of_type("python")
                if si.directory and si.directory.exists()
            ]
            if python_dirs:
                _run(["ruff", "check"] + python_dirs, cwd=catalog.root, check=False)
                _run(
                    ["ruff", "format", "--check"] + python_dirs,
                    cwd=catalog.root,
                    check=False,
                )
            else:
                warn("No Python services found")

        elif target in ("frontend", "node"):
            info("Linting Node services...")
            for si in catalog.services_of_type("node"):
                if si.directory and si.directory.exists():
                    _run(["pnpm", "lint"], cwd=si.directory, check=False)

        else:
            resolved = catalog.resolve([target])
            for svc_name in resolved:
                si = catalog.service_info.get(svc_name)
                if si and si.service_type == "node" and si.directory:
                    _run(["pnpm", "lint"], cwd=si.directory, check=False)
                elif si and si.service_type == "python" and si.directory:
                    _run(
                        ["ruff", "check", si.relative_dir],
                        cwd=catalog.root,
                        check=False,
                    )
                    _run(
                        ["ruff", "format", "--check", si.relative_dir],
                        cwd=catalog.root,
                        check=False,
                    )
                else:
                    warn(f"No linter configured for: {svc_name}")


# ---------------------------------------------------------------------------
# Init (ClickStack / HyperDX) — only runs if project uses it
# ---------------------------------------------------------------------------

HDX_API = "http://localhost:8000"
HDX_EMAIL = "admin@lepton.local"
HDX_PASSWORD = "L3pt0n!Obs3rv3#2025"


def _http_request(
    url: str, method: str = "GET", data: dict | None = None, cookies: dict | None = None
) -> tuple[int, str, dict]:
    """Make an HTTP request using urllib. Returns (status, body, response_cookies)."""
    body = json.dumps(data).encode() if data else None
    headers = {"Content-Type": "application/json"} if data else {}
    if cookies:
        headers["Cookie"] = "; ".join(f"{k}={v}" for k, v in cookies.items())

    req = Request(url, data=body, headers=headers, method=method)
    try:
        resp = urlopen(req, timeout=10)
        resp_body = resp.read().decode()
        resp_cookies = {}
        for header_val in resp.headers.get_all("Set-Cookie") or []:
            parts = header_val.split(";")[0].split("=", 1)
            if len(parts) == 2:
                resp_cookies[parts[0].strip()] = parts[1].strip()
        return resp.status, resp_body, resp_cookies
    except URLError as e:
        if hasattr(e, "code"):
            return e.code, getattr(e, "read", lambda: b"")(), {}
        raise


def _run_init_clickstack(root: Path, quiet: bool = False) -> None:
    """Initialize ClickStack/HyperDX — register user, get API key, update config."""
    if not quiet:
        info(f"Waiting for ClickStack API at {HDX_API}...")

    for attempt in range(60):
        try:
            status, _, _ = _http_request(f"{HDX_API}/health")
            if status == 200:
                break
        except Exception:
            pass
        if attempt == 0 and not quiet:
            info("Waiting for ClickStack API...")
        time.sleep(2)
    else:
        if not quiet:
            warn("ClickStack API did not become ready — skipping init")
        return

    if not quiet:
        info("ClickStack API is ready.")

    try:
        status, body, _ = _http_request(f"{HDX_API}/installation")
        is_existing = '"isTeamExisting":true' in body
    except Exception:
        if not quiet:
            warn("Could not check ClickStack installation status")
        return

    cookies: dict = {}
    if not is_existing:
        if not quiet:
            info(f"Registering initial user ({HDX_EMAIL})...")
        try:
            status, _, cookies = _http_request(
                f"{HDX_API}/register/password",
                "POST",
                {
                    "email": HDX_EMAIL,
                    "password": HDX_PASSWORD,
                    "confirmPassword": HDX_PASSWORD,
                },
            )
            if status != 200:
                if not quiet:
                    warn(f"Registration returned HTTP {status}")
                return
        except Exception as e:
            if not quiet:
                warn(f"Registration failed: {e}")
            return
    else:
        if not quiet:
            info("Team exists — logging in...")
        try:
            status, _, cookies = _http_request(
                f"{HDX_API}/login/password",
                "POST",
                {"email": HDX_EMAIL, "password": HDX_PASSWORD},
            )
            if not (200 <= status < 400):
                if not quiet:
                    warn(f"Login returned HTTP {status}")
                return
        except Exception as e:
            if not quiet:
                warn(f"Login failed: {e}")
            return

    try:
        status, body, _ = _http_request(f"{HDX_API}/team", cookies=cookies)
        match = re.search(r'"apiKey":"([^"]+)"', body)
        if not match:
            if not quiet:
                warn("Could not extract API key from team response")
            return
        api_key = match.group(1)
    except Exception as e:
        if not quiet:
            warn(f"Failed to fetch team info: {e}")
        return

    if not quiet:
        info(f"Ingestion key: {api_key}")

    env_file = root / ".env"
    if env_file.exists():
        content = env_file.read_text()
        if "CLICKSTACK_API_KEY=" in content:
            content = re.sub(
                r"^CLICKSTACK_API_KEY=.*$",
                f"CLICKSTACK_API_KEY={api_key}",
                content,
                flags=re.MULTILINE,
            )
        else:
            content += f"\nCLICKSTACK_API_KEY={api_key}\n"
        env_file.write_text(content)
    else:
        env_file.write_text(f"CLICKSTACK_API_KEY={api_key}\n")

    tpl = root / "infra" / "nginx" / "nginx.conf.tpl"
    out = root / "infra" / "nginx" / "nginx.conf"
    if tpl.exists():
        out.write_text(tpl.read_text().replace("__CLICKSTACK_API_KEY__", api_key))

    if not quiet:
        success("ClickStack initialized — dashboard at http://localhost:8080")


def cmd_init(catalog: ComposeCatalog) -> None:
    """Run ClickStack initialization."""
    if not catalog.has_service("clickstack-app"):
        warn("This project does not use ClickStack (no clickstack-app service found)")
        return
    _run_init_clickstack(catalog.root, quiet=False)
    if catalog.has_service("api-gateway"):
        restart_cmd = (
            ["docker", "compose"]
            + catalog.all_compose_file_args()
            + ["restart", "api-gateway"]
        )
        _run(restart_cmd, cwd=catalog.root, check=False)


# ---------------------------------------------------------------------------
# List / Validate / Vite
# ---------------------------------------------------------------------------


def cmd_list(catalog: ComposeCatalog, targets: list[str]) -> None:
    """List all services by group."""
    groups_to_show = targets if targets else list(catalog.groups.keys())
    for group in groups_to_show:
        services = catalog.groups.get(group)
        if services is None:
            canonical = catalog._aliases.get(group)
            if canonical:
                services = catalog.groups.get(canonical)
                group = canonical
        if services is None:
            warn(f"Unknown group: {group}")
            continue
        header(group)
        for svc in services:
            si = catalog.service_info.get(svc)
            svc_dir = si.relative_dir if si else ""
            svc_type = f"[{si.service_type}]" if si and si.service_type else ""
            print(f"  {svc:<35s} {dim(svc_dir):<35s} {dim(svc_type)}")


def cmd_validate(catalog: ComposeCatalog) -> None:
    """Run harness validation."""
    script = catalog.root / "scripts" / "validate-harness.sh"
    if script.exists():
        _run(["bash", str(script)], cwd=catalog.root)
    else:
        error("scripts/validate-harness.sh not found")
        sys.exit(1)


def cmd_vite(catalog: ComposeCatalog, action: str) -> None:
    """Manage vite dev server as a background daemon."""
    state_dir = catalog.root / ".dx"
    pid_file = state_dir / "vite.pid"
    log_file = state_dir / "vite.log"

    # Find the first node app directory
    node_apps = [si for si in catalog.services_of_type("node") if si.group == "apps"]
    if not node_apps:
        error("No Node.js app found to run vite")
        sys.exit(1)
    app_dir = node_apps[0].directory

    if not action:
        error("Usage: dx vite start|stop|logs")
        sys.exit(1)

    if action == "start":
        if pid_file.exists():
            try:
                pid = int(pid_file.read_text().strip())
                os.kill(pid, 0)
                info(f"Vite already running (PID {pid})")
                return
            except (OSError, ValueError):
                pid_file.unlink(missing_ok=True)

        state_dir.mkdir(parents=True, exist_ok=True)
        log_fh = open(log_file, "w")
        proc = subprocess.Popen(
            ["pnpm", "dev"],
            cwd=app_dir,
            stdout=log_fh,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        pid_file.write_text(str(proc.pid))
        success(f"Vite started (PID {proc.pid}), logs at {log_file}")

    elif action == "stop":
        if not pid_file.exists():
            warn("No vite PID file found")
            return
        try:
            pid = int(pid_file.read_text().strip())
            os.kill(pid, signal.SIGTERM)
            success(f"Vite stopped (PID {pid})")
        except (OSError, ValueError) as e:
            warn(f"Could not stop vite: {e}")
        finally:
            pid_file.unlink(missing_ok=True)

    elif action == "logs":
        if not log_file.exists():
            warn("No vite log file found")
            return
        _exec(["tail", "-f", str(log_file)])

    else:
        error(f"Unknown vite action: {action}")
        error("Usage: dx vite start|stop|logs")
        sys.exit(1)


# ---------------------------------------------------------------------------
# Port commands
# ---------------------------------------------------------------------------


def cmd_ports(catalog: ComposeCatalog, args: list[str]) -> None:
    """Port management commands."""
    state_dir = catalog.root / ".dx"
    pm = PortManager(state_dir)

    if not args:
        pm.status(catalog)
        return

    action = args[0]
    if action == "pin":
        if len(args) != 3:
            error("Usage: dx ports pin <service> <port>")
            sys.exit(1)
        try:
            port = int(args[2])
        except ValueError:
            error("Port must be a number")
            sys.exit(1)
        pm.pin(args[1], port)

    elif action == "reset":
        service = args[1] if len(args) > 1 else None
        pm.clear(service)

    else:
        error(f"Unknown ports action: {action}")
        error("Usage: dx ports [pin <service> <port> | reset [service]]")
        sys.exit(1)


def cmd_proxy(catalog: ComposeCatalog, args: list[str]) -> None:
    """Proxy management commands."""
    state_dir = catalog.root / ".dx"
    pm = PortManager(state_dir)

    if not args:
        error("Usage: dx proxy start|stop")
        sys.exit(1)

    action = args[0]
    if action == "start":
        start_proxy_daemon(state_dir)
    elif action == "stop":
        stop_proxy_daemon(state_dir)
    elif action == "--foreground":
        start_proxy_foreground(pm)
    else:
        error(f"Unknown proxy action: {action}")
        sys.exit(1)


def cmd_hosts(catalog: ComposeCatalog, args: list[str]) -> None:
    """Manage DNS entries for *.dx.localhost resolution."""
    if not args:
        hosts_status()
        return

    action = args[0]
    if action == "setup":
        service_names = list(catalog.service_info.keys())
        hosts_setup(service_names)
    elif action == "remove":
        hosts_remove()
    elif action == "status":
        hosts_status()
    else:
        error(f"Unknown hosts action: {action}")
        error("Usage: dx hosts [setup|remove|status]")
        sys.exit(1)
