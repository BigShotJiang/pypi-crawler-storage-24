#ifndef GMP_ERROR_H
#define GMP_ERROR_H

#include <signal.h>
#include <setjmp.h>

#define __ObjName(o) \
    (PyModule_Check(o) ? PyModule_GetName((PyObject *) (o)) : \
     Py_TYPE(o)->tp_name)
#define __GMPErr(obj, meth) \
    do { \
        PyObject *type, *value, *tb; \
        \
        PyErr_Fetch(&type, &value, &tb); \
        (void) PyErr_Format( \
            type,  "%s.%s(): %S", __ObjName(obj), meth, \
            value ? value : Py_None \
            ); \
    } while (0)
#define __FUNC__ (strchr(__func__, '_') + 1)

#define __GMPLibCheckErr(env) \
    do { \
	if (sigsetjmp(env, SIGFPE) == SIGFPE) \
	    return NULL; \
	gmp_errno = GMP_ERROR_NONE; \
    } while (0)

#define __GMPLibCheckErrInt(env, rcode)		\
    do { \
	if (sigsetjmp(env, SIGFPE) == SIGFPE) \
	    return rcode; \
	gmp_errno = GMP_ERROR_NONE; \
    } while (0)

#define GMP_ERROR_CAPI_NAME "gmp_error_capi"
#define GMP_ERROR_CAPSULE_NAME \
    (MODS_DIR "." "gmp_error" "." GMP_ERROR_CAPI_NAME)

#ifndef GMP_ERROR_PYMODULE

static void **gmp_error_capi;

#define GMPLibErrHandler ((void (*)(int, sigjmp_buf)) gmp_error_capi[0])

static int
gmp_error_import_capi(void)
{
    gmp_error_capi = (void **) PyCapsule_Import(GMP_ERROR_CAPSULE_NAME, 0);
    return gmp_error_capi ? 0 : -1;
}

#endif /* GMP_ERROR_PYMODULE */

#endif /* GMP_ERROR_H */
