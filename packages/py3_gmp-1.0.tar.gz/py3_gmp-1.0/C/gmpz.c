/*****************************************************************************
 * INCLUDED FILES & MACRO DEFINITIONS
 *****************************************************************************/

#define PY_SSIZE_T_CLEAN
#include <Python.h>

#include <fcntl.h>
#include <gmp.h>

#include <gmp_error.h>

typedef void (*binary_op_t)(mpz_t, const mpz_t, const mpz_t);
typedef void (*binary_op_ui_t)(mpz_t, const mpz_t, mp_bitcnt_t);

static PyTypeObject GMPZType;

/*****************************************************************************
 * OBJECT(s) DEFINITION(s)
 *****************************************************************************/

typedef struct {
    PyObject_HEAD
    mpz_t mpz;
} GMPZObject;
#define GMPZObject_Check(o) Py_IS_TYPE(o, &GMPZType)

/*****************************************************************************
 * LOCAL VARIABLES DECLARATIONS
 *****************************************************************************/

static PyObject *GMPZErr;
static sigjmp_buf __env;
static gmp_randstate_t state;

/*****************************************************************************
 * LOCAL FUNCTIONS DECLARATIONS
 *****************************************************************************/

static PyObject *mpz_to_GMPZ(mpz_t);
static int pyobj_to_mpz(PyObject *, int, mpz_ptr *);
static int pyobjs_to_mpzs(PyObject **, int, int, mpz_ptr **, int **);
static void mpzs_free(mpz_ptr *, int, int *);
static PyObject *GMPZNumber_op(PyObject *, PyObject *, const char *);
static PyObject *GMPZNumber_shift(PyObject *, PyObject *, const char *);
static int GMPZ_cmp(PyObject *, PyObject *);
static PyObject *GMPZ_gcd_lcm(PyObject *, PyObject *, const char *);
static void GMP_randclear(void);
static void GMPZLibErrHandler(int);

/*****************************************************************************
 * EXPORTED FUNCTIONS DECLARATIONS
 *****************************************************************************/

/*****************************************************************************
 * GMPZObject OBJECT
 *****************************************************************************/

/* DOC */

PyDoc_STRVAR(GMPZObjectDoc, "Python wrapper for `mpz_t'");

/* METHODS */

PyDoc_STRVAR(
    GMPZObjectDoc_probab_prime_p, "Python wrapper for `mpz_probab_prime_p()'"
    );

static PyObject *
GMPZObject_probab_prime_p(GMPZObject *self, PyObject *args)
{
    int rcode, reps = 24;
    
    if (!PyArg_ParseTuple(args, "|i", &reps))
	return NULL;
    if (reps < 15 || reps > 50) {
	PyErr_SetString(PyExc_ValueError, "arg1 must in range [15-50]");
	__GMPErr(self, __FUNC__);
	return NULL;
    }
    __GMPLibCheckErr(__env);
    rcode = mpz_probab_prime_p(self->mpz, reps);
    return Py_BuildValue("i", rcode);
}

PyDoc_STRVAR(
    GMPZObjectDoc_nextprime, "Python wrapper for `mpz_nextprime()'"
    );

static PyObject *
GMPZObject_nextprime(GMPZObject *self)
{
    mpz_t p;
    PyObject *ret;

    mpz_init(p);
    __GMPLibCheckErr(__env);
    mpz_nextprime(p, self->mpz);
    ret = mpz_to_GMPZ(p);
    mpz_clear(p);
    return ret;
}

PyDoc_STRVAR(
    GMPZObjectDoc_prevprime, "Python wrapper for `mpz_prevprime()'"
    );

static PyObject *
GMPZObject_prevprime(GMPZObject *self)
{
    int rcode;
    mpz_t p;
    PyObject *ret;

     mpz_init(p);
     __GMPLibCheckErr(__env);
     rcode = mpz_prevprime(p, self->mpz);
     if (!rcode) {
	 Py_INCREF(Py_None);
	 ret = Py_None;
     }
     else
	 ret = mpz_to_GMPZ(p);
     mpz_clear(p);
     return Py_BuildValue("(Oi)", ret, rcode);
}

PyDoc_STRVAR(GMPZObjectDoc_root, "Python wrapper for `mpz_root()'");

static PyObject *
GMPZObject_root(GMPZObject *self, PyObject *args)
{
    int rcode;
    unsigned long n;
    mpz_t rop;
    PyObject *ret, *exact;
    
    if (!PyArg_ParseTuple(args, "k", &n))
	return NULL;
    mpz_init(rop);
    __GMPLibCheckErr(__env);
    rcode = mpz_root(rop, self->mpz, n);
    ret = mpz_to_GMPZ(rop);
    mpz_clear(rop);
    exact = rcode ? Py_True : Py_False;
    Py_INCREF(exact);
    return Py_BuildValue("(OO)", ret, exact);
}

PyDoc_STRVAR(GMPZObjectDoc_rootrem, "Python wrapper for `mpz_rootrem()'");

static PyObject *
GMPZObject_rootrem(GMPZObject *self, PyObject *args)
{
    unsigned long n;
    mpz_t root, rem;
    PyObject *py_root, *py_rem;
    
    if (!PyArg_ParseTuple(args, "k", &n))
	return NULL;
    mpz_inits(root, rem, NULL);
    __GMPLibCheckErr(__env);
    mpz_rootrem(root, rem, self->mpz, n);
    py_root = mpz_to_GMPZ(root);
    py_rem =  mpz_to_GMPZ(rem);
    mpz_clears(root, rem, NULL);
    return Py_BuildValue("(OO)", py_root, py_rem);
}

PyDoc_STRVAR(GMPZObjectDoc_sqrt, "Python wrapper for `mpz_sqrt()'");

static PyObject *
GMPZObject_sqrt(GMPZObject *self)
{
    mpz_t rop;
    PyObject *ret;

    mpz_init(rop);
    __GMPLibCheckErr(__env);
    mpz_sqrt(rop, self->mpz);
    ret = mpz_to_GMPZ(rop);
    mpz_clear(rop);
    return ret;
}

PyDoc_STRVAR(GMPZObjectDoc_sqrtrem, "Python wrapper for `mpz_sqrtrem()'");

static PyObject *
GMPZObject_sqrtrem(GMPZObject *self)
{
    mpz_t root, rem;
    PyObject *py_root, *py_rem;

    mpz_inits(root, rem, NULL);
    __GMPLibCheckErr(__env);
    mpz_sqrtrem(root, rem, self->mpz);
    py_root = mpz_to_GMPZ(root);
    py_rem = mpz_to_GMPZ(rem);
    mpz_clears(root, rem, NULL);
    return Py_BuildValue("(OO)", py_root, py_rem);
}

PyDoc_STRVAR(
    GMPZObjectDoc_perfect_power_p,
    "Python wrapper for `mpz_perfect_power_p()'"
    );

static PyObject *
GMPZObject_perfect_power_p(GMPZObject *self)
{
    int rcode;
    
    __GMPLibCheckErr(__env);
    rcode = mpz_perfect_power_p(self->mpz);
    if (rcode)
	Py_RETURN_TRUE;
    Py_RETURN_FALSE;
}

PyDoc_STRVAR(
    GMPZObjectDoc_perfect_square_p,
    "Python wrapper for `mpz_perfect_square_p()'"
    );

static PyObject *
GMPZObject_perfect_square_p(GMPZObject *self)
{
    int rcode;
    
    __GMPLibCheckErr(__env);
    rcode = mpz_perfect_square_p(self->mpz);
    if (rcode)
	Py_RETURN_TRUE;
    Py_RETURN_FALSE;
}

PyDoc_STRVAR(GMPZObjectDoc_setbit, "Python wrapper for `mpz_setbit()'");

static PyObject *
GMPZObject_setbit(GMPZObject *self, PyObject *args)
{
    unsigned long idx;
    
    if (!PyArg_ParseTuple(args, "k", &idx))
	return NULL;
    __GMPLibCheckErr(__env);
    mpz_setbit(self->mpz, idx);
    Py_RETURN_NONE;
}

PyDoc_STRVAR(GMPZObjectDoc_clrbit, "Python wrapper for `mpz_clrbit()'");

static PyObject *
GMPZObject_clrbit(GMPZObject *self, PyObject *args)
{
    unsigned long idx;
    
    if (!PyArg_ParseTuple(args, "k", &idx))
	return NULL;
    __GMPLibCheckErr(__env);
    mpz_clrbit(self->mpz, idx);
    Py_RETURN_NONE;
}

PyDoc_STRVAR(GMPZObjectDoc_combit, "Python wrapper for `mpz_combit()'");

static PyObject *
GMPZObject_combit(GMPZObject *self, PyObject *args)
{
    unsigned long idx;
    
    if (!PyArg_ParseTuple(args, "k", &idx))
	return NULL;
    __GMPLibCheckErr(__env);
    mpz_combit(self->mpz, idx);
    Py_RETURN_NONE;
}

PyDoc_STRVAR(GMPZObjectDoc_tstbit, "Python wrapper for `mpz_tstbit()'");

static PyObject *
GMPZObject_tstbit(GMPZObject *self, PyObject *args)
{
    int rcode;
    unsigned long idx;
    
    if (!PyArg_ParseTuple(args, "k", &idx))
	return NULL;
    __GMPLibCheckErr(__env);
    rcode = mpz_tstbit(self->mpz, idx);
    if (rcode)
	Py_RETURN_TRUE;
    Py_RETURN_FALSE;
}

PyDoc_STRVAR(GMPZObjectDoc_popcount, "Python wrapper for `mpz_popcount()'");

static PyObject *
GMPZObject_popcount(GMPZObject *self)
{
    unsigned long count;
    
    __GMPLibCheckErr(__env);
    count = mpz_popcount(self->mpz);
    return Py_BuildValue("k", count);
}

PyDoc_STRVAR(GMPZObjectDoc_scan0, "Python wrapper for `mpz_scan0()'");

static PyObject *
GMPZObject_scan0(GMPZObject *self, PyObject *args)
{
    unsigned long sbit = 0, ret;
    
    if (!PyArg_ParseTuple(args, "|k", &sbit))
	return NULL;
    __GMPLibCheckErr(__env);
    ret = mpz_scan0(self->mpz, sbit);
    return Py_BuildValue("k", ret);
}

PyDoc_STRVAR(GMPZObjectDoc_scan1, "Python wrapper for `mpz_scan1()'");

static PyObject *
GMPZObject_scan1(GMPZObject *self, PyObject *args)
{
    unsigned long sbit = 0, ret;
    
    if (!PyArg_ParseTuple(args, "|k", &sbit))
	return NULL;
    __GMPLibCheckErr(__env);
    ret = mpz_scan1(self->mpz, sbit);
    return Py_BuildValue("k", ret);
}

PyDoc_STRVAR(GMPZObjectDoc_sizeinbase, "Python wrapper for `mpz_sizeinbase()'");

static PyObject *
GMPZObject_sizeinbase(GMPZObject *self, PyObject *args)
{
    int base = 10;
    Py_ssize_t ret;
    
    if (!PyArg_ParseTuple(args, "|i", &base))
	return NULL;
    if (base < 2 || base > 62) {
	PyErr_SetString(
	    PyExc_ValueError, "arg1 must be an integer in range [2-62]"
	    );
	__GMPErr(self, __FUNC__);
	return NULL;
    }
    __GMPLibCheckErr(__env);
    ret = mpz_sizeinbase(self->mpz, base);
    return Py_BuildValue("n", ret);
}

PyDoc_STRVAR(GMPZObjectDoc_get_str, "Python wrapper for `mpz_get_str()'");

static PyObject *
GMPZObject_get_str(GMPZObject *self, PyObject *args)
{
    int base = 10;

    if (!PyArg_ParseTuple(args, "|i", &base))
	return NULL;
    if ((base < 2 || base > 62) && (base < -36 || base > -2)) {
	PyErr_SetString(
	    PyExc_ValueError,
	    "arg1 must be an integer in interval [2, 62] or in interval "
	    "[-36, -2]"
	    );
	__GMPErr(self, __FUNC__);
	return NULL;
    }
    size_t size = mpz_sizeinbase(self->mpz, base) + 4, offset;
    char buf[size];

    switch (base) {
    case 2:
	sprintf(buf, "0b");
	offset = 2;
	break;
    case 8:
	sprintf(buf, "0o");
	offset = 2;
	break;
    case 16:
	sprintf(buf, "0x");
	offset = 2;
	break;
    default:
	offset = 0;
    }
    (void) mpz_get_str(buf + offset, base, self->mpz);
    return PyUnicode_FromFormat("%s", buf);
}


static PyMethodDef GMPZObjectMethods[] = {
    {"probab_prime_p", (PyCFunction) GMPZObject_probab_prime_p,
     METH_VARARGS, GMPZObjectDoc_probab_prime_p},
    {"nextprime", (PyCFunction) GMPZObject_nextprime,
     METH_NOARGS, GMPZObjectDoc_nextprime},
    {"prevprime", (PyCFunction) GMPZObject_prevprime,
     METH_NOARGS, GMPZObjectDoc_prevprime},
    {"root", (PyCFunction) GMPZObject_root,
     METH_VARARGS, GMPZObjectDoc_root},
    {"rootrem", (PyCFunction) GMPZObject_rootrem,
     METH_VARARGS, GMPZObjectDoc_rootrem},
    {"sqrt", (PyCFunction) GMPZObject_sqrt,
     METH_NOARGS, GMPZObjectDoc_sqrt},
    {"sqrtrem", (PyCFunction) GMPZObject_sqrtrem,
     METH_NOARGS, GMPZObjectDoc_sqrtrem},
    {"perfect_power_p", (PyCFunction) GMPZObject_perfect_power_p,
     METH_NOARGS, GMPZObjectDoc_perfect_power_p},
    {"perfect_square_p", (PyCFunction) GMPZObject_perfect_square_p,
     METH_NOARGS, GMPZObjectDoc_perfect_square_p},
    {"setbit", (PyCFunction) GMPZObject_setbit,
     METH_VARARGS, GMPZObjectDoc_setbit},
    {"clrbit", (PyCFunction) GMPZObject_clrbit,
     METH_VARARGS, GMPZObjectDoc_clrbit},
    {"combit", (PyCFunction) GMPZObject_combit,
     METH_VARARGS, GMPZObjectDoc_combit},
    {"tstbit", (PyCFunction) GMPZObject_tstbit,
     METH_VARARGS, GMPZObjectDoc_tstbit},
    {"popcount", (PyCFunction) GMPZObject_popcount,
     METH_NOARGS, GMPZObjectDoc_popcount},
    {"scan0", (PyCFunction) GMPZObject_scan0,
     METH_VARARGS, GMPZObjectDoc_scan0},
    {"scan1", (PyCFunction) GMPZObject_scan1,
     METH_VARARGS, GMPZObjectDoc_scan1},
    {"sizeinbase", (PyCFunction) GMPZObject_sizeinbase,
     METH_VARARGS, GMPZObjectDoc_sizeinbase},
    {"get_str", (PyCFunction) GMPZObject_get_str,
     METH_VARARGS, GMPZObjectDoc_get_str},
    {NULL, NULL, 0, NULL}
};

/* NUMBER METHODS */

static PyObject *
GMPZNumber_add(PyObject *op1, PyObject *op2)
{
    return GMPZNumber_op(op1, op2, "add");
}

static PyObject *
GMPZNumber_sub(PyObject *op1, PyObject *op2)
{
    return GMPZNumber_op(op1, op2, "sub");
}

static PyObject *
GMPZNumber_mul(PyObject *op1, PyObject *op2)
{
    return GMPZNumber_op(op1, op2, "mul");
}

static PyObject *
GMPZNumber_fdiv_q(PyObject *op1, PyObject *op2)
{
    return GMPZNumber_op(op1, op2, "fdiv_q");
}

static PyObject *
GMPZNumber_negative(PyObject *op)
{
    mpz_t rop;
    PyObject *ret;

    mpz_init(rop);
    __GMPLibCheckErr(__env);
    mpz_neg(rop, ((GMPZObject *)op)->mpz);
    ret = mpz_to_GMPZ(rop);
    mpz_clear(rop);
    return ret;
}

static PyObject *
GMPZNumber_positive(PyObject *op)
{
    mpz_t rop;
    PyObject *ret;

    mpz_init(rop);
    __GMPLibCheckErr(__env);
    mpz_set(rop, ((GMPZObject *)op)->mpz);
    ret = mpz_to_GMPZ(rop);
    mpz_clear(rop);
    return ret;
}

static PyObject *
GMPZNumber_abs(PyObject *op)
{
    mpz_t rop;
    PyObject *ret;

    mpz_init(rop);
    __GMPLibCheckErr(__env);
    mpz_abs(rop, ((GMPZObject *)op)->mpz);
    ret = mpz_to_GMPZ(rop);
    mpz_clear(rop);
    return ret;
}

static PyObject *
GMPZNumber_fdiv_r(PyObject *op1, PyObject *op2)
{
    return GMPZNumber_op(op1, op2, "fdiv_r");
}

static PyObject *
GMPZNumber_and(PyObject *op1, PyObject *op2)
{
    return GMPZNumber_op(op1, op2, "and");
}

static PyObject *
GMPZNumber_or(PyObject *op1, PyObject *op2)
{
    return GMPZNumber_op(op1, op2, "or");
}

static PyObject *
GMPZNumber_xor(PyObject *op1, PyObject *op2)
{
    return GMPZNumber_op(op1, op2, "xor");
}

static PyObject *
GMPZNumber_invert(PyObject *op)
{
    mpz_t rop;
    PyObject *ret;

    mpz_init(rop);
    __GMPLibCheckErr(__env);
    mpz_com(rop, ((GMPZObject *)op)->mpz);
    ret = mpz_to_GMPZ(rop);
    mpz_clear(rop);
    return ret;
}

static PyObject *
GMPZNumber_lshift(PyObject *op1, PyObject *op2)
{
    return GMPZNumber_shift(op1, op2, "left");
}

static PyObject *
GMPZNumber_rshift(PyObject *op1, PyObject *op2)
{
    return GMPZNumber_shift(op1, op2, "right");
}

static PyObject *
GMPZNumber_power(PyObject *op1, PyObject *op2, PyObject *op3)
{
    mpz_t rop;
    PyObject *ret;

    if (op3 == Py_None) {
	unsigned long exp;
	
	if (!GMPZObject_Check(op1) || !PyLong_Check(op2))
	    Py_RETURN_NOTIMPLEMENTED;
	exp = PyLong_AsUnsignedLong(op2);
	if (exp == (unsigned long) -1 && PyErr_Occurred())
	    return NULL;
	mpz_init(rop);
	__GMPLibCheckErr(__env);
	mpz_pow_ui(rop, ((GMPZObject *)op1)->mpz, exp);
	ret = mpz_to_GMPZ(rop);
	mpz_clear(rop);
    }
    else {
	int ecode, *rcode;
	mpz_ptr *ptrs;
	PyObject *ops[] = {op1, op2, op3};

	ecode = pyobjs_to_mpzs(ops, 3, 0, &ptrs, &rcode);
	if (ecode == -2)
	    return NULL;
	if (ecode == -1)
	    Py_RETURN_NOTIMPLEMENTED;
	mpz_init(rop);
	__GMPLibCheckErr(__env);
	mpz_powm(rop, ptrs[0], ptrs[1], ptrs[2]);
	ret = mpz_to_GMPZ(rop);
	mpz_clear(rop);
	mpzs_free(ptrs, 3, rcode);
    }
    return ret;
}

static PyObject *
GMPZNumber_int(PyObject *op)
{
    mpz_srcptr ptr =  ((GMPZObject *)op)->mpz;
    size_t size = mpz_sizeinbase(ptr, 10) + 2;
    char buf[size];

    (void) gmp_sprintf(buf, "%Zd", ptr);
    return PyLong_FromString(buf, NULL, 10);
}

static PyObject *
GMPZNumber_divmod(PyObject *op1, PyObject *op2)
{
    PyObject *q, *r;

    q = GMPZNumber_fdiv_q(op1, op2);
    if (!q)
	return NULL;
    r = GMPZNumber_fdiv_r(op1, op2);
    if (!r) {
	Py_DECREF(q);
	return NULL;
    }
    return Py_BuildValue("(OO)", q, r);
}

static int
GMPZNumber_bool(PyObject *op)
{
    return mpz_sgn(((GMPZObject *)op)->mpz);
}

static PyNumberMethods GMPZNumberMethods = {
    .nb_add = GMPZNumber_add,
    .nb_subtract = GMPZNumber_sub,
    .nb_multiply = GMPZNumber_mul,
    .nb_floor_divide = GMPZNumber_fdiv_q,
    .nb_negative = GMPZNumber_negative,
    .nb_positive = GMPZNumber_positive,
    .nb_absolute = GMPZNumber_abs,
    .nb_remainder = GMPZNumber_fdiv_r,
    .nb_and = GMPZNumber_and,
    .nb_or = GMPZNumber_or,
    .nb_xor = GMPZNumber_xor,
    .nb_invert = GMPZNumber_invert,
    .nb_lshift = GMPZNumber_lshift,
    .nb_rshift = GMPZNumber_rshift,
    .nb_power = GMPZNumber_power,
    .nb_int = GMPZNumber_int,
    .nb_index = GMPZNumber_int,
    .nb_divmod = GMPZNumber_divmod,
    .nb_bool = GMPZNumber_bool
};

/* MEMBERS */

/* GET/SET */

static PyObject *
GMPZObject_get_sgn(GMPZObject *self, void *closure)
{
    int sgn;

    sgn = mpz_sgn(self->mpz);
    return Py_BuildValue("i", sgn);
}

static PyObject *
GMPZObject_is_even(GMPZObject *self, void *closure)
{
    int rcode;

    rcode = mpz_even_p(self->mpz);
    if (rcode)
	Py_RETURN_TRUE;
    Py_RETURN_FALSE;
}

static PyObject *
GMPZObject_is_odd(GMPZObject *self, void *closure)
{
    int rcode;

    rcode = mpz_odd_p(self->mpz);
    if (rcode)
	Py_RETURN_TRUE;
    Py_RETURN_FALSE;
}

static PyObject *
GMPZObject_is_pow_of_2(GMPZObject *self, void *closure)
{
    unsigned long rcode;

    rcode = mpz_popcount(self->mpz) == 1;
    if (rcode)
	Py_RETURN_TRUE;
    Py_RETURN_FALSE;
}

static PyGetSetDef GMPZObjetGetSet[] = {
    {"sgn", (getter) GMPZObject_get_sgn, NULL,
     "mpz sign: +1, 0 or-1", NULL},
    {"is_even", (getter) GMPZObject_is_even, NULL,
     "True if z is even, False otherwise", NULL},
    {"is_odd", (getter) GMPZObject_is_odd, NULL,
     "True if z is odd, False otherwise", NULL},
    {"is_pow_of_2", (getter) GMPZObject_is_pow_of_2, NULL,
     "True if z is a power of 2, False otherwise", NULL},
    {NULL, NULL, NULL, NULL, NULL}
};

/* OBJECT COMPARISON */

static PyObject *
GMPZObject_richcmp(PyObject *z1, PyObject *z2, int op)
{
    int c = 0, cmp;

    if (!(GMPZObject_Check(z1) && GMPZObject_Check(z2)) &&
	!(GMPZObject_Check(z1) && PyLong_Check(z2)) &&
	!(PyLong_Check(z1) && GMPZObject_Check(z2))) {
	(void) PyErr_Format(
	    PyExc_TypeError, "can't compare `%s' and `%s'",
	    Py_TYPE(z1)->tp_name, Py_TYPE(z2)->tp_name
	    );
	return NULL;
    }
    cmp = GMPZ_cmp(z1, z2);
    if (cmp == 0xffff)
	return NULL;
    switch (op) {
    case Py_LT:
	c = cmp < 0;
	break;
    case Py_LE:
	c = cmp <= 0;
	break;
    case Py_EQ:
	c = cmp == 0;
	break;
    case Py_NE:
	c = cmp != 0;
	break;
    case Py_GT:
	c = cmp > 0;
	break;
    case Py_GE:
	c = cmp >= 0;
	break;
    }
    if (c)
	Py_RETURN_TRUE;
    Py_RETURN_FALSE;
 }

/* SPECIAL METHODS */

static void
GMPZObject_dealloc(GMPZObject *self)
{
    mpz_clear(self->mpz);
    Py_TYPE(self)->tp_free((PyObject *) self);
}

static PyObject *
GMPZObject_str(GMPZObject *self)
{
    size_t size = mpz_sizeinbase(self->mpz, 10) + 2;
    char buf[size];

    (void) gmp_sprintf(buf, "%Zd", self->mpz);
    return PyUnicode_FromFormat("%s", buf);
}

static int
GMPZObject_init(GMPZObject *self, PyObject *args, PyObject *kwds)
{
    PyObject *arg = NULL;
    int base = 0;
    
    if (!PyArg_ParseTuple(args, "|Oi", &arg, &base))
	return -1;
    if (!arg)
	return 0;
    if (PyUnicode_Check(arg)) {
	const char *op;

	op = PyUnicode_AsUTF8(arg);
	if (!op) {
	    __GMPErr(self, __FUNC__);
	    return -1;
	}
	if (mpz_set_str(self->mpz, op, base) < 0) {
	    PyErr_SetString(PyExc_ValueError, "invalid number");
	    __GMPErr(self, __FUNC__);
	    return -1;
	}
	return 0;
    }
    if (PyFloat_Check(arg)) {
	double op;

	op = PyFloat_AsDouble(arg);
	if (op == -1.0 && PyErr_Occurred()) {
	    __GMPErr(self, __FUNC__);
	    return -1;
	}
	mpz_set_d(self->mpz, op);
	return 0;
    }
    int rcode;
    mpz_ptr ptr;

    rcode = pyobj_to_mpz(arg, 0, &ptr);
    if (rcode >= 0) {
	__GMPLibCheckErrInt(__env, -1);
	mpz_set(self->mpz, ptr);
	if (rcode == 1) {
	    mpz_clear(ptr);
	    PyMem_Free(ptr);
	}
	return 0;
    }
    else
	return -1;
    PyErr_SetString(
	PyExc_TypeError, "arg1 must be an instance of `mpz', `int', `str' "
	"or `float'"
	);
    __GMPErr(self, __FUNC__);
    return -1;
}

static PyObject *
GMPZObject_new(PyTypeObject *type, PyObject *args, PyObject *kwds)
{
    GMPZObject *self;
    
    self = (GMPZObject *) type->tp_alloc(type, 0);
    if (self)
	 mpz_init(self->mpz);
    return (PyObject *) self;
}

/* TYPE */

static PyTypeObject GMPZType = {
    PyVarObject_HEAD_INIT(NULL, 0)
    .tp_name = "mpz",
    .tp_doc = GMPZObjectDoc,
    .tp_basicsize = sizeof(GMPZObject),
    .tp_flags = Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE,
    .tp_as_number = &GMPZNumberMethods,
    .tp_richcompare = GMPZObject_richcmp,
    .tp_str = (reprfunc) GMPZObject_str,
    .tp_repr = (reprfunc) GMPZObject_str,
    .tp_methods = GMPZObjectMethods,
    .tp_getset = GMPZObjetGetSet,
    .tp_init = (initproc) GMPZObject_init,
    .tp_new = GMPZObject_new,
    .tp_dealloc = (destructor) GMPZObject_dealloc,
};

/*****************************************************************************
 * MODULE METHODS
 *****************************************************************************/

PyDoc_STRVAR(GMPZDoc_gcd, "Python wrapper for `mpz_gcd()'");

static PyObject *
GMPZ_gcd(PyObject *self, PyObject *args)
{
    PyObject *op1, *op2;
    
    if (!PyArg_ParseTuple(args, "OO", &op1, &op2))
	return NULL;
    return GMPZ_gcd_lcm(op1, op2, "gcd");
}

PyDoc_STRVAR(GMPZDoc_gcdext, "Python wrapper for `mpz_gcdext()'");

static PyObject *
GMPZ_gcdext(PyObject *self, PyObject *args)
{
    int ecode, *rcode;
    mpz_ptr *ptrs;
    mpz_t g, s, t;
    PyObject *ops[2], *py_g, *py_s, *py_t;
    
    if (!PyArg_ParseTuple(args, "OO", &ops[0], &ops[1]))
	return NULL;
    ecode = pyobjs_to_mpzs(ops, 2, 1, &ptrs, &rcode);
    if (ecode < 0)
	return NULL;
    mpz_inits(g, s, t, NULL);
    __GMPLibCheckErr(__env);
    mpz_gcdext(g, s, t, ptrs[0], ptrs[1]);
    py_g = mpz_to_GMPZ(g);
    py_s = mpz_to_GMPZ(s);
    py_t = mpz_to_GMPZ(t);
    mpz_clears(g, t, s, NULL);
    mpzs_free(ptrs, 2, rcode);
    return Py_BuildValue("OOO", py_g, py_s, py_t);
}

PyDoc_STRVAR(GMPZDoc_lcm, "Python wrapper for `mpz_lcm()'");

static PyObject *
GMPZ_lcm(PyObject *self, PyObject *args)
{
    PyObject *op1, *op2;
    
    if (!PyArg_ParseTuple(args, "OO", &op1, &op2))
	return NULL;
    return GMPZ_gcd_lcm(op1, op2, "lcm");
}

PyDoc_STRVAR(GMPZDoc_divisible_p, "Python wrapper for `mpz_divisible_p()'");

static PyObject *
GMPZ_divisible_p(PyObject *self, PyObject *args)
{
    int ecode, *rcode, ret;
    mpz_ptr *ptrs;
    PyObject *ops[2];
    
    if (!PyArg_ParseTuple(args, "OO", &ops[0], &ops[1]))
	return NULL;
    ecode = pyobjs_to_mpzs(ops, 2, 1, &ptrs, &rcode);
    if (ecode < 0)
	return NULL;
    __GMPLibCheckErr(__env);
    ret = mpz_divisible_p(ptrs[0], ptrs[1]);
    mpzs_free(ptrs, 2, rcode);
    if (ret)
	Py_RETURN_TRUE;
    Py_RETURN_FALSE;
}

PyDoc_STRVAR(
    GMPZDoc_divisible_2exp_p, "Python wrapper for `mpz_divisible_2exp_p()'"
    );

static PyObject *
GMPZ_divisible_2exp_p(PyObject *self, PyObject *args)
{
    int ecode, ret;
    unsigned long d;
    mpz_ptr ptr;
    PyObject *op;
    
    if (!PyArg_ParseTuple(args, "Ok", &op, &d))
	return NULL;
    ecode = pyobj_to_mpz(op, 1, &ptr);
    if (ecode < 0)
	return NULL;
    __GMPLibCheckErr(__env);
    ret = mpz_divisible_2exp_p(ptr, d);
    if (ecode == 1) {
	mpz_clear(ptr);
	PyMem_Free(ptr);
    }
    if (ret)
	Py_RETURN_TRUE;
    Py_RETURN_FALSE;
}

PyDoc_STRVAR(
    GMPZDoc_congruent_p, "Python wrapper for `mpz_congruent[_ui]_p()'"
    );

static PyObject *
GMPZ_congruent_p(PyObject *self, PyObject *args)
{
    int ecode, *rcode, ret;
    mpz_ptr *ptrs;
    PyObject *ops[3];
    
    if (!PyArg_ParseTuple(args, "OOO", &ops[0], &ops[1], &ops[2]))
	return NULL;
    ecode = pyobjs_to_mpzs(ops, 3, 1, &ptrs, &rcode);
    if (ecode < 0)
	return NULL;
    __GMPLibCheckErr(__env);
    ret = mpz_congruent_p(ptrs[0], ptrs[1], ptrs[2]);
    mpzs_free(ptrs, 3, rcode);
    if (ret)
	Py_RETURN_TRUE;
    Py_RETURN_FALSE;
}

PyDoc_STRVAR(
    GMPZDoc_congruent_2exp_p, "Python wrapper for `mpz_congruent_2exp_p()'"
    );

static PyObject *
GMPZ_congruent_2exp_p(PyObject *self, PyObject *args)
{
    int ecode, *rcode, ret;
    unsigned long d;
    mpz_ptr *ptrs;
    PyObject *ops[2];
    
    if (!PyArg_ParseTuple(args, "OOk", &ops[0], &ops[1], &d))
	return NULL;
    ecode = pyobjs_to_mpzs(ops, 2, 1, &ptrs, &rcode);
    if (ecode < 0)
	return NULL;
    __GMPLibCheckErr(__env);
    ret = mpz_congruent_2exp_p(ptrs[0], ptrs[1], d);
    mpzs_free(ptrs, 2, rcode);
    if (ret)
	Py_RETURN_TRUE;
    Py_RETURN_FALSE;
}

PyDoc_STRVAR(GMPZDoc_jacobi, "Python wrapper for `mpz_jacobi()'");

static PyObject *
GMPZ_jacobi(PyObject *self, PyObject *args)
{
    int ecode, *rcode, ret;
    mpz_ptr *ptrs;
    PyObject *ops[2];
    
    if (!PyArg_ParseTuple(args, "OO", &ops[0], &ops[1]))
	return NULL;
    ecode = pyobjs_to_mpzs(ops, 2, 1, &ptrs, &rcode);
    if (ecode < 0)
	return NULL;
    if (!mpz_odd_p(ptrs[1])) {
	mpzs_free(ptrs, 2, rcode);
	PyErr_SetString(PyExc_ValueError, "arg2 must be odd");
	__GMPErr(self, __FUNC__);
	return NULL;
    }
    __GMPLibCheckErr(__env);
    ret = mpz_jacobi(ptrs[0], ptrs[1]);
    mpzs_free(ptrs, 2, rcode);
    return Py_BuildValue("i", ret);
}

PyDoc_STRVAR(GMPZDoc_legendre, "Python wrapper for `mpz_legendre()'");

static PyObject *
GMPZ_legendre(PyObject *self, PyObject *args)
{
    int ecode, *rcode, ret;
    mpz_ptr *ptrs;
    PyObject *ops[2];
    
    if (!PyArg_ParseTuple(args, "OO", &ops[0], &ops[1]))
	return NULL;
    ecode = pyobjs_to_mpzs(ops, 2, 1, &ptrs, &rcode);
    if (ecode < 0)
	return NULL;
    if (mpz_cmp_ui(ptrs[1], 2) <= 0 || !mpz_probab_prime_p(ptrs[1], 24)) {
	mpzs_free(ptrs, 2, rcode);
	PyErr_SetString(
	    PyExc_ValueError, "arg2 must be an odd positive prime"
	    );
	__GMPErr(self, __FUNC__);
	return NULL;
    }
    __GMPLibCheckErr(__env);
    ret = mpz_legendre(ptrs[0], ptrs[1]);
    mpzs_free(ptrs, 2, rcode);
    return Py_BuildValue("i", ret);
}

PyDoc_STRVAR(GMPZDoc_kronecker, "Python wrapper for `mpz_kronecker()'");

static PyObject *
GMPZ_kronecker(PyObject *self, PyObject *args)
{
    int ecode, *rcode, ret;
    mpz_ptr *ptrs;
    PyObject *ops[2];
    
    if (!PyArg_ParseTuple(args, "OO", &ops[0], &ops[1]))
	return NULL;
    ecode = pyobjs_to_mpzs(ops, 2, 1, &ptrs, &rcode);
    if (ecode < 0)
	return NULL;
    __GMPLibCheckErr(__env);
    ret = mpz_legendre(ptrs[0], ptrs[1]);
    mpzs_free(ptrs, 2, rcode);
    return Py_BuildValue("i", ret);
}

PyDoc_STRVAR(GMPZDoc_invert, "Python wrapper for `mpz_invert()'");

static PyObject *
GMPZ_invert(PyObject *self, PyObject *args)
{
    int ecode, *rcode;
    mpz_ptr *ptrs;
    mpz_t rop;
    PyObject *ops[2], *ret;
    
    if (!PyArg_ParseTuple(args, "OO", &ops[0], &ops[1]))
	return NULL;
    ecode = pyobjs_to_mpzs(ops, 2, 1, &ptrs, &rcode);
    if (ecode < 0)
	return NULL;
    if (!mpz_sgn(ptrs[1])) {
	mpzs_free(ptrs, 2, rcode);
	PyErr_SetString(PyExc_ValueError, "arg2 cannot be zero");
	__GMPErr(self, __FUNC__);
	return NULL;
    }
    mpz_init(rop);
    __GMPLibCheckErr(__env);
    ecode = mpz_invert(rop, ptrs[0], ptrs[1]);
    if (!ecode) {
	mpz_clear(rop);
	mpzs_free(ptrs, 2, rcode);
	Py_RETURN_NONE;
    }
    ret = mpz_to_GMPZ(rop);
    mpz_clear(rop);
    mpzs_free(ptrs, 2, rcode);
    return ret;
}

PyDoc_STRVAR(GMPZDoc_randseed_ui, "Python wrapper for `gmp_randseed_ui()'");

static PyObject *
GMPZ_randseed_ui(PyObject *self)
{
    int fd;
    unsigned long seed;

    fd = open("/dev/random", O_RDONLY);
    if (fd < 0)
	time((time_t *) &seed);
    else {
	ssize_t noc;

	noc = read(fd, &seed, sizeof(seed));
	if (noc < 0 || noc != sizeof(seed))
	    time((time_t *) &seed);
	(void) close(fd);
    }
    __GMPLibCheckErr(__env);
    gmp_randseed_ui(state, seed);
    Py_RETURN_NONE;
}

PyDoc_STRVAR(GMPZDoc_urandomb_ui, "Python wrapper for `gmp_urandomb_ui()'");

static PyObject *
GMPZ_urandomb_ui(PyObject *self, PyObject *args)
{
    unsigned long n, r;
    size_t nbits = sizeof(n) << 3;
    
    if (!PyArg_ParseTuple(args, "k", &n))
	return NULL;
    if (n > nbits) {
	(void) PyErr_Format(PyExc_ValueError, "arg1 must <= %zu", nbits);
	__GMPErr(self, __FUNC__);
	return NULL;
    }
    __GMPLibCheckErr(__env);
    r = gmp_urandomb_ui(state, n);
    return Py_BuildValue("k", r);
}

PyDoc_STRVAR(GMPZDoc_urandomm_ui, "Python wrapper for `gmp_urandomm_ui()'");

static PyObject *
GMPZ_urandomm_ui(PyObject *self, PyObject *args)
{
    unsigned long n, r;
    
    if (!PyArg_ParseTuple(args, "k", &n))
	return NULL;
    __GMPLibCheckErr(__env);
    r = gmp_urandomm_ui(state, n);
    return Py_BuildValue("k", r);
}

PyDoc_STRVAR(GMPZDoc_fac_ui, "Python wrapper for `mpz_fac_ui()'");

static PyObject *
GMPZ_fac_ui(PyObject *self, PyObject *args)
{
    unsigned long n;
    mpz_t rop;
    PyObject *ret;
    
    if (!PyArg_ParseTuple(args, "k", &n))
	return NULL;
    mpz_init(rop);
    __GMPLibCheckErr(__env);
    mpz_fac_ui(rop, n);
    ret = mpz_to_GMPZ(rop);
    mpz_clear(rop);
    return ret;
}

PyDoc_STRVAR(GMPZDoc_2fac_ui, "Python wrapper for `mpz_2fac_ui()'");

static PyObject *
GMPZ_2fac_ui(PyObject *self, PyObject *args)
{
    unsigned long n;
    mpz_t rop;
    PyObject *ret;
    
    if (!PyArg_ParseTuple(args, "k", &n))
	return NULL;
    mpz_init(rop);
    __GMPLibCheckErr(__env);
    mpz_2fac_ui(rop, n);
    ret = mpz_to_GMPZ(rop);
    mpz_clear(rop);
    return ret;
}

PyDoc_STRVAR(GMPZDoc_mfac_uiui, "Python wrapper for `mpz_mfac_uiui()'");

static PyObject *
GMPZ_mfac_uiui(PyObject *self, PyObject *args)
{
    unsigned long n, m;
    mpz_t rop;
    PyObject *ret;
    
    if (!PyArg_ParseTuple(args, "kk", &n, &m))
	return NULL;
    mpz_init(rop);
    __GMPLibCheckErr(__env);
    mpz_mfac_uiui(rop, n, m);
    ret = mpz_to_GMPZ(rop);
    mpz_clear(rop);
    return ret;
}

PyDoc_STRVAR(GMPZDoc_primorial_ui, "Python wrapper for `mpz_primorial_ui()'");

static PyObject *
GMPZ_primorial_ui(PyObject *self, PyObject *args)
{
    unsigned long n;
    mpz_t rop;
    PyObject *ret;
    
    if (!PyArg_ParseTuple(args, "k", &n))
	return NULL;
    mpz_init(rop);
    __GMPLibCheckErr(__env);
    mpz_primorial_ui(rop, n);
    ret = mpz_to_GMPZ(rop);
    mpz_clear(rop);
    return ret;
}

PyDoc_STRVAR(GMPZDoc_bin_ui, "Python wrapper for `mpz_bin_ui[ui]()'");

static PyObject *
GMPZ_bin_ui(PyObject *self, PyObject *args)
{
    unsigned long k;
    mpz_t rop;
    PyObject *op, *ret;
    
    if (!PyArg_ParseTuple(args, "Ok", &op, &k))
	return NULL;
    mpz_init(rop);
    if (GMPZObject_Check(op)) {
	__GMPLibCheckErr(__env);
	mpz_bin_ui(rop, ((GMPZObject *) op)->mpz, k);
    }
    else if (PyLong_Check(op)) {
	unsigned long n;

	n = PyLong_AsUnsignedLong(op);
	if (n == (unsigned long) -1 && PyErr_Occurred())
	    return NULL;
	__GMPLibCheckErr(__env);
	mpz_bin_uiui(rop, n, k);
    }
    else {
	mpz_clear(rop);
	(void) PyErr_Format(
	    PyExc_TypeError, "arg1 has an incorrect `%s' type",
	    Py_TYPE(op)->tp_name
	    );
	__GMPErr(self, __FUNC__);
	return NULL;
    }
    ret = mpz_to_GMPZ(rop);
    mpz_clear(rop);
    return ret;
}

PyDoc_STRVAR(GMPZDoc_remove, "Python wrapper for `mpz_remove()'");

static PyObject *
GMPZ_remove(PyObject *self, PyObject *args)
{
    unsigned long occ;
    int ecode, *rcode;
    mpz_ptr *ptrs;
    mpz_t rop;
    PyObject *ops[2], *ret;
    
    if (!PyArg_ParseTuple(args, "OO", &ops[0], &ops[1]))
	return NULL;
    ecode = pyobjs_to_mpzs(ops, 2, 1, &ptrs, &rcode);
    if (ecode < 0)
	return NULL;
    mpz_init(rop);
    __GMPLibCheckErr(__env);
    occ = mpz_remove(rop, ptrs[0], ptrs[1]);
    ret = mpz_to_GMPZ(rop);
    mpz_clear(rop);
    mpzs_free(ptrs, 2, rcode);
    return Py_BuildValue("Ok", ret, occ);
}

PyDoc_STRVAR(GMPZDoc_hamdist, "Python wrapper for `mpz_hamdist()'");

static PyObject *
GMPZ_hamdist(PyObject *self, PyObject *args)
{
    unsigned long dist;
    int ecode, *rcode;
    mpz_ptr *ptrs;
    PyObject *ops[2];
    
    if (!PyArg_ParseTuple(args, "OO", &ops[0], &ops[1]))
	return NULL;
    ecode = pyobjs_to_mpzs(ops, 2, 1, &ptrs, &rcode);
    if (ecode < 0)
	return NULL;
    __GMPLibCheckErr(__env);
    dist = mpz_hamdist(ptrs[0], ptrs[1]);
    mpzs_free(ptrs, 2, rcode);
    return Py_BuildValue("k", dist);
}

static PyMethodDef GMPZMethods[] = {
    {"gcd", (PyCFunction) GMPZ_gcd, METH_VARARGS, GMPZDoc_gcd},
    {"gcdext", (PyCFunction) GMPZ_gcdext, METH_VARARGS, GMPZDoc_gcdext},
    {"lcm", (PyCFunction) GMPZ_lcm, METH_VARARGS, GMPZDoc_lcm},
    {"divisible_p", (PyCFunction) GMPZ_divisible_p, METH_VARARGS,
     GMPZDoc_divisible_p},
    {"divisible_2exp_p", (PyCFunction) GMPZ_divisible_2exp_p, METH_VARARGS,
     GMPZDoc_divisible_2exp_p},
    {"congruent_p", (PyCFunction) GMPZ_congruent_p, METH_VARARGS,
     GMPZDoc_congruent_p},
    {"congruent_2exp_p", (PyCFunction) GMPZ_congruent_2exp_p, METH_VARARGS,
     GMPZDoc_congruent_2exp_p},
    {"jacobi", (PyCFunction) GMPZ_jacobi, METH_VARARGS, GMPZDoc_jacobi},
    {"legendre", (PyCFunction) GMPZ_legendre, METH_VARARGS, GMPZDoc_legendre},
    {"kronecker", (PyCFunction) GMPZ_kronecker, METH_VARARGS,
     GMPZDoc_kronecker},
    {"invert", (PyCFunction) GMPZ_invert, METH_VARARGS, GMPZDoc_invert},
    {"randseed_ui", (PyCFunction) GMPZ_randseed_ui, METH_NOARGS,
     GMPZDoc_randseed_ui},
    {"urandomb_ui", (PyCFunction) GMPZ_urandomb_ui, METH_VARARGS,
     GMPZDoc_urandomb_ui},
    {"urandomm_ui", (PyCFunction) GMPZ_urandomm_ui, METH_VARARGS,
     GMPZDoc_urandomm_ui},
    {"fac_ui", (PyCFunction) GMPZ_fac_ui, METH_VARARGS, GMPZDoc_fac_ui},
    {"fac2_ui", (PyCFunction) GMPZ_2fac_ui, METH_VARARGS, GMPZDoc_2fac_ui},
    {"mfac_uiui", (PyCFunction) GMPZ_mfac_uiui, METH_VARARGS,
     GMPZDoc_mfac_uiui},
    {"primorial_ui", (PyCFunction) GMPZ_primorial_ui, METH_VARARGS,
     GMPZDoc_primorial_ui},
    {"bin_ui", (PyCFunction) GMPZ_bin_ui, METH_VARARGS, GMPZDoc_bin_ui},
    {"remove", (PyCFunction) GMPZ_remove, METH_VARARGS, GMPZDoc_remove},
    {"hamdist", (PyCFunction) GMPZ_hamdist, METH_VARARGS, GMPZDoc_hamdist},
    {NULL, NULL, 0, NULL}
};

/*****************************************************************************
 * MODULE INITIALIZATION
 *****************************************************************************/

PyDoc_STRVAR(
    GMPZDoc,
    "Python wrapper for `GNU MP library' - C module `" MODS_DIR "." "gmpz'"
    );

static PyModuleDef GMPZModule = {
    .m_base = PyModuleDef_HEAD_INIT,
    .m_name = MODS_DIR "." "gmpz",
    .m_doc = GMPZDoc,
    .m_size = -1,
    .m_methods = GMPZMethods
};

PyMODINIT_FUNC
PyInit_gmpz(void)
{
    PyObject* m;

    
    if (gmp_error_import_capi() < 0)
	return NULL;
    if (PyType_Ready(&GMPZType) < 0)
        return NULL;
    m = PyModule_Create(&GMPZModule);
    if (!m)
	return NULL;
    GMPZErr = PyErr_NewException(
	"gmpz.GMPZError" , NULL, NULL);
    Py_INCREF(GMPZErr);
    if (PyModule_AddObject(
	    m, "GMPZError", (PyObject *) GMPZErr) < 0) {
	Py_DECREF(m);
        return NULL;
    }
    Py_INCREF(&GMPZType);
    if (PyModule_AddObject(m, GMPZType.tp_name, (PyObject *) &GMPZType) < 0) {
	Py_DECREF(&GMPZType);
	Py_DECREF(GMPZErr);
	Py_DECREF(m);
        return NULL;
    }
    PyOS_setsig(SIGFPE, GMPZLibErrHandler);
    gmp_randinit_default(state);
    (void) Py_AtExit(GMP_randclear);
    return m;
}

/*****************************************************************************
 * LOCAL FUNCTION DEFINITIONS
 *****************************************************************************/

static PyObject *
mpz_to_GMPZ(mpz_t z)
{
    PyObject *ret;

    ret = GMPZType.tp_new(&GMPZType, NULL, NULL);
    if (!ret)
	return NULL;
    mpz_set(((GMPZObject *) ret)->mpz, z);
    return ret;
}

static int
pyobj_to_mpz(PyObject *obj, int idx, mpz_ptr *ptr)
{
    if (GMPZObject_Check(obj)) {
	*ptr = ((GMPZObject *) obj)->mpz;
	return 0;
    }
    if (PyLong_Check(obj)) {
	const char *str;
	PyObject *py_str;

	py_str = PyObject_Str(obj);
	if (!py_str)
	    return -2;
	str = PyUnicode_AsUTF8(py_str);
	if (!str) {
	    Py_DECREF(py_str);
	    return -2;
	}
	*ptr = PyMem_Malloc(sizeof(mpz_t));
	if (!*ptr) {
	    Py_DECREF(py_str);
	    (void) PyErr_NoMemory();
	    return -2;
	}
	mpz_init(*ptr);
	__GMPLibCheckErrInt(__env, -2);
	mpz_set_str(*ptr, str, 10);
	Py_DECREF(py_str);
	return 1;
    }
    if (idx > 0)
	(void) PyErr_Format(
	    PyExc_TypeError, "arg%d has an incorrect `%s' type", idx,
	    Py_TYPE(obj)->tp_name
	    );
    return -1;
}

static int
pyobjs_to_mpzs(PyObject **objs, int len, int flg, mpz_ptr **ptrs, int **rcode)
{
    int *r, ecode = 0;
    mpz_ptr *p;
    
    *ptrs = PyMem_Calloc(len, sizeof(**ptrs));
    if (!*ptrs) {
	(void) PyErr_NoMemory();
	return -2;
    }
    *rcode = PyMem_Calloc(len, sizeof(int));
    if (!*rcode) {
	PyMem_Free(*ptrs);
	(void) PyErr_NoMemory();
	return -2;
    }
    p = *ptrs;
    r = *rcode;
    for (PyObject **o = objs; o - objs < len; o++, p++, r++) {
	*r = pyobj_to_mpz(*o, flg ? r - *rcode + 1 : 0, p);
	if (*r < 0) {
	    ecode = *r;
	    mpzs_free(*ptrs, len, *rcode);
	    break;
	}
    }
    return ecode;
}

static void
mpzs_free(mpz_ptr *ptrs, int len, int *rcode)
{
    int *r = rcode;

    for (mpz_ptr *p = ptrs; p - ptrs < len; p++, r++)
	if (*r == 1) {
	    mpz_clear(*p);
	    PyMem_Free(*p);
	}
    PyMem_Free(ptrs);
    PyMem_Free(rcode);
}

static PyObject *
GMPZNumber_op(PyObject *op1, PyObject *op2, const char *op_name)
{
    PyObject *ops[] = {op1, op2}, *ret;
    mpz_ptr *ptrs;
    int *rcode, ecode;
    mpz_t rop;
    binary_op_t op = NULL;

    ecode = pyobjs_to_mpzs(ops, 2, 1, &ptrs, &rcode);
    if (ecode == -2)
	return NULL;
    if (ecode == -1)
	Py_RETURN_NOTIMPLEMENTED;
    if (!strcmp(op_name, "add"))
	op = mpz_add;
    else if (!strcmp(op_name, "sub"))
	op = mpz_sub;
    else if (!strcmp(op_name, "mul"))
	op = mpz_mul;
    else if (!strcmp(op_name, "fdiv_q"))
	op = mpz_fdiv_q;
    else if (!strcmp(op_name, "fdiv_r"))
	op = mpz_fdiv_r;
    else if (!strcmp(op_name, "and"))
	op = mpz_and;
    else if (!strcmp(op_name, "or"))
	op = mpz_ior;
    else if (!strcmp(op_name, "xor"))
	op = mpz_xor;
    mpz_init(rop);
    __GMPLibCheckErr(__env);
    op(rop, ptrs[0], ptrs[1]);
    ret = mpz_to_GMPZ(rop);
    mpz_clear(rop);
    mpzs_free(ptrs, 2, rcode);
    return ret;
}

static PyObject *
GMPZNumber_shift(PyObject *op1, PyObject *op2, const char *dir)
{
    mpz_t rop;
    unsigned long shift;
    binary_op_ui_t op;
    PyObject *ret;

    if (!GMPZObject_Check(op1) || !PyLong_Check(op2))
	Py_RETURN_NOTIMPLEMENTED;
    shift = PyLong_AsUnsignedLong(op2);
    if (shift == (unsigned long) -1 && PyErr_Occurred())
	return NULL;
    if (!strcmp(dir, "left"))
	op = mpz_mul_2exp;
    else
	op = mpz_fdiv_q_2exp;	
     mpz_init(rop);
    __GMPLibCheckErr(__env);
    op(rop, ((GMPZObject *)op1)->mpz, shift);
    ret = mpz_to_GMPZ(rop);
    mpz_clear(rop);
    return ret;
}

static int
GMPZ_cmp(PyObject *op1, PyObject *op2)
{
    mpz_ptr *ptrs;
    int ecode, *rcode;
    PyObject *ops[] = {op1, op2};

    ecode = pyobjs_to_mpzs(ops, 2, 0, &ptrs, &rcode);
    if (ecode < 0)
	return 0xffff;
    __GMPLibCheckErrInt(__env, 0xffff);
    ecode = mpz_cmp(ptrs[0], ptrs[1]);
    mpzs_free(ptrs, 2, rcode);
    return ecode;
}

static PyObject *
GMPZ_gcd_lcm(PyObject *op1, PyObject *op2, const char *op_name)
{
    mpz_ptr *ptrs;
    int ecode, *rcode;
    mpz_t rop;
    PyObject *ret, *ops[] = {op1, op2};
    binary_op_t op;

    ecode = pyobjs_to_mpzs(ops, 2, 1, &ptrs, &rcode);
    if (ecode < 0)
	return NULL;
    if (!strcmp(op_name, "gcd"))
	op = mpz_gcd;
    else
	op = mpz_lcm;   
    mpz_init(rop);
    __GMPLibCheckErr(__env);
    op(rop, ptrs[0], ptrs[1]);
    ret = mpz_to_GMPZ(rop);
    mpz_clear(rop);
    mpzs_free(ptrs, 2, rcode);
    return ret;
}

static void
GMP_randclear(void)
{
    gmp_randclear(state);
}

static void
GMPZLibErrHandler(int sig)
{
    GMPLibErrHandler(sig, __env);
}

/*****************************************************************************
 * EXPORTED FUNCTIONS DEFINITIONS
 *****************************************************************************/
