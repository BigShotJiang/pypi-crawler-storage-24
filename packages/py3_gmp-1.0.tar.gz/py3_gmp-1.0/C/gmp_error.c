/*****************************************************************************
 * INCLUDED FILES & MACRO DEFINITIONS
 *****************************************************************************/

#define PY_SSIZE_T_CLEAN
#include <Python.h>

#include <gmp.h>

#define GMP_ERROR_PYMODULE
#include <gmp_error.h>

/*****************************************************************************
 * OBJECT(s) DEFINITION(s)
 *****************************************************************************/

/*****************************************************************************
 * LOCAL VARIABLES DECLARATIONS
 *****************************************************************************/

PyObject *GMPErrUnsupportedArgument;
PyObject *GMPErrDivisionByZero;
PyObject *GMPErrSqrtOfNegative;
PyObject *GMPErrInvalidArgument;
PyObject *GMPErrMPZOverflow;

/*****************************************************************************
 * LOCAL FUNCTIONS DECLARATIONS
 *****************************************************************************/

/*****************************************************************************
 * EXPORTED FUNCTIONS DECLARATIONS
 *****************************************************************************/

static void GMPLibErrHandler(int, sigjmp_buf);

/*****************************************************************************
 * MODULE METHODS
 *****************************************************************************/

/*****************************************************************************
 * MODULE INITIALIZATION
 *****************************************************************************/

PyDoc_STRVAR(
    GMPLibErrDoc,
    "Module to manage GNU MP library errors `" MODS_DIR "." "gmp_error'"
    );

static PyModuleDef GMPLibErrModule = {
    PyModuleDef_HEAD_INIT,
    .m_name = MODS_DIR "." "gmp_error",
    .m_doc = GMPLibErrDoc,
    .m_size = -1,
};

PyMODINIT_FUNC
PyInit_gmp_error(void)
{
    PyObject* m, *gmp_error_capi_obj;
    static void *gmp_error_capi[] = {
	GMPLibErrHandler
    };

    m = PyModule_Create(&GMPLibErrModule);
    if (!m) {
	return NULL;
    }
    gmp_error_capi_obj = PyCapsule_New(
        (void *) gmp_error_capi, GMP_ERROR_CAPSULE_NAME, NULL);
    if (!gmp_error_capi_obj) {
	Py_DECREF(m);
        return NULL;
    }
    if (PyModule_AddObject(m, GMP_ERROR_CAPI_NAME, gmp_error_capi_obj) < 0) {
        Py_DECREF(gmp_error_capi_obj);
        Py_DECREF(m);
        return NULL;
    }
    GMPErrUnsupportedArgument = PyErr_NewException(
	 MODS_DIR "." "gmp_error", NULL, NULL);
    Py_INCREF(GMPErrUnsupportedArgument);
    if (PyModule_AddObject(
	    m, "GMPErrUnsupportedArgument", GMPErrUnsupportedArgument) < 0) {
	Py_DECREF(gmp_error_capi_obj);
	Py_DECREF(m);
        return NULL;
    }
    GMPErrDivisionByZero = PyErr_NewException(
	 MODS_DIR "." "gmp_error", NULL, NULL);
    Py_INCREF(GMPErrDivisionByZero);
    if (PyModule_AddObject(
	    m, "GMPErrDivisionByZero", GMPErrDivisionByZero) < 0) {
	Py_DECREF(GMPErrUnsupportedArgument);
	Py_DECREF(gmp_error_capi_obj);
	Py_DECREF(m);
        return NULL;
    }
    GMPErrSqrtOfNegative = PyErr_NewException(
	 MODS_DIR "." "gmp_error", NULL, NULL);
    Py_INCREF(GMPErrSqrtOfNegative);
    if (PyModule_AddObject(
	    m, "GMPErrSqrtOfNegative", GMPErrSqrtOfNegative) < 0) {
	Py_DECREF(GMPErrDivisionByZero);
	Py_DECREF(GMPErrUnsupportedArgument);
	Py_DECREF(gmp_error_capi_obj);
	Py_DECREF(m);
        return NULL;
    }
    GMPErrInvalidArgument = PyErr_NewException(
	 MODS_DIR "." "gmp_error", NULL, NULL);
    Py_INCREF(GMPErrInvalidArgument);
    if (PyModule_AddObject(
	    m, "GMPErrInvalidArgument", GMPErrInvalidArgument) < 0) {
	Py_DECREF(GMPErrSqrtOfNegative);
	Py_DECREF(GMPErrDivisionByZero);
	Py_DECREF(GMPErrUnsupportedArgument);
	Py_DECREF(gmp_error_capi_obj);
	Py_DECREF(m);
        return NULL;
    }
    GMPErrMPZOverflow = PyErr_NewException(
	 MODS_DIR "." "gmp_error", NULL, NULL);
    Py_INCREF(GMPErrMPZOverflow);
    if (PyModule_AddObject(
	    m, "GMPErrMPZOverflow", GMPErrMPZOverflow) < 0) {
	Py_DECREF(GMPErrInvalidArgument);
	Py_DECREF(GMPErrSqrtOfNegative);
	Py_DECREF(GMPErrDivisionByZero);
	Py_DECREF(GMPErrUnsupportedArgument);
	Py_DECREF(gmp_error_capi_obj);
	Py_DECREF(m);
        return NULL;
    }
    return m;
}

/*****************************************************************************
 * LOCAL FUNCTION DEFINITIONS
 *****************************************************************************/

/*****************************************************************************
 * EXPORTED FUNCTIONS DEFINITIONS
 *****************************************************************************/

static void
GMPLibErrHandler(int sig, sigjmp_buf env)
{
    const char *msg = "unexpected error";
    PyObject *exc = NULL;
    
    switch (gmp_errno) {
    case GMP_ERROR_UNSUPPORTED_ARGUMENT:
	exc = GMPErrUnsupportedArgument;
	msg = "unsupported argument";
	break;
    case GMP_ERROR_DIVISION_BY_ZERO:
	exc = GMPErrDivisionByZero;
	msg = "division by zero";
	break;
    case GMP_ERROR_SQRT_OF_NEGATIVE:
	exc = GMPErrSqrtOfNegative;
	msg = "square root of negative";
	break;
    case GMP_ERROR_INVALID_ARGUMENT:
	exc = GMPErrInvalidArgument;
	msg = "invalid argument";
	break;
    case GMP_ERROR_MPZ_OVERFLOW:
	exc = GMPErrMPZOverflow;
	msg = "MPZ overflow";
	break;
    }
    if (!exc)
	PyErr_SetString(PyExc_RuntimeError, msg);
    else
	(void) PyErr_Format(exc, "%s (gmp_errno=%d)", msg, gmp_errno);
    siglongjmp(env, sig);
}

