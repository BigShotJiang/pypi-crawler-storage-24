#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import setuptools, sys

from setuptools.command.build_ext import build_ext

MOD_NAME = 'gmp'
MODS_DIR = f'_{MOD_NAME}'

LIBGMP = 'gmp'
LIBGMP_VERSION_MIN = '6.3.0'

def _check_for_lgmp():
    from ctypes import CDLL, c_char_p
    from ctypes.util import find_library

    print(f"Checking for GNU MP library `-l{LIBGMP}'... ", flush=True,  end='')
    lib_name = find_library(LIBGMP)
    if lib_name is None:
        print(f"\nFAILED: can't find library `-l{LIBGMP}'", file=sys.stderr)
        sys.exit(1)
    print('Ok.')
    try:
        print(f"Checking for GNU MP library version'... ", flush=True,  end='')
        lib_gmp = CDLL(lib_name)
        version = c_char_p.in_dll(lib_gmp, '__gmp_version')
        version = version.value.decode()
        split = lambda v: [int(i) for i in v.split('.')]
        if split(version) < split(LIBGMP_VERSION_MIN):
            print(
                f"\nFAILED: version `{version}' is too old, must be newer "
                f"than `{LIBGMP_VERSION_MIN}'.", file=sys.stderr
            )
            sys.exit(1)
        print(f'{version}.')
    except Exception as err:
        print(err)
        print("\nFAILED: unexpected error, can't retreive library version.")
        sys.exit(1)

def check_for_lgmp(cmd_subclass):
    old_run = cmd_subclass.run
    
    def new_run(self):
        _check_for_lgmp()
        old_run(self)
        
    cmd_subclass.run = new_run
    return cmd_subclass

@check_for_lgmp
class CmdBuildExt(build_ext):
    pass

def extension(ext):
    return setuptools.Extension(
        '.'.join((MODS_DIR, ext['name'])),
        sources=[f"C/{ext['name']}.c"],
        include_dirs=['C', '/usr/local/include'],
        libraries=[LIBGMP],
        depends=ext['depends'],
        define_macros=[
            ('MOD_NAME', f'"{MOD_NAME}"'),
            ('MODS_DIR', f'"{MODS_DIR}"')
        ]
    )

EXTENSIONS = (
    {'name': 'gmpz', 'depends': ['C/gmp_error.h']},
    {'name': 'gmp_error', 'depends': ['C/gmp_error.h']},
)

setuptools.setup(
    py_modules=[MOD_NAME], 
    packages=setuptools.find_packages(),
    ext_modules=[extension(e) for e in EXTENSIONS],
    cmdclass={'build_ext': CmdBuildExt}
)
