#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from _gmp.gmp_error import *
from _gmp.gmpz import *

if __name__ == '__main__':
    pass
