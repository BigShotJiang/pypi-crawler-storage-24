from blinker import Signal
from flask import url_for
from flask_babel import LazyString
from flask_storage.mongo import ImageField
from mongoengine import PULL, Q
from mongoengine.errors import ValidationError
from mongoengine.fields import (
    BooleanField,
    DateTimeField,
    GenericEmbeddedDocumentField,
    ListField,
    MapField,
    ReferenceField,
    StringField,
)
from mongoengine.signals import post_save, pre_save
from werkzeug.utils import cached_property

from udata.api_fields import field, generate_fields
from udata.core.activity.models import Auditable
from udata.core.dataset.api_fields import dataset_fields
from udata.core.linkable import Linkable
from udata.core.metrics.helpers import get_stock_metrics
from udata.core.owned import Owned, OwnedQuerySet
from udata.core.reuse.api_fields import BIGGEST_IMAGE_SIZE, reuse_permissions_fields
from udata.core.storages import default_image_basename, images
from udata.frontend.markdown import mdstrip
from udata.i18n import lazy_gettext as _
from udata.models import Badge, BadgeMixin, BadgesList, WithMetrics
from udata.mongo.datetime_fields import Datetimed
from udata.mongo.document import UDataDocument as Document
from udata.mongo.errors import FieldValidationError
from udata.mongo.extras_fields import ExtrasField
from udata.mongo.slug_fields import SlugField
from udata.mongo.taglist_field import TagListField
from udata.mongo.url_field import URLField
from udata.uris import cdata_url
from udata.utils import hash_url

from .constants import IMAGE_MAX_SIZE, IMAGE_SIZES, REUSE_TOPICS, REUSE_TYPES

__all__ = ("Reuse",)

BADGES: dict[str, LazyString] = {}


class ReuseQuerySet(OwnedQuerySet):
    def visible(self):
        return self(private__ne=True, datasets__0__exists=True, deleted=None)

    def hidden(self):
        return self(Q(private=True) | Q(datasets__0__exists=False) | Q(deleted__ne=None))


def check_url_does_not_exists(url, **_kwargs):
    """Ensure a reuse URL is not yet registered"""
    if url and Reuse.url_exists(url):
        raise FieldValidationError(_("This URL is already registered"), field="url")


# Uses __badges__ (not available_badges) so that existing badges in DB
# remain valid even if they are hidden via settings.
# Uses a standalone function (not a model method) because ReuseBadge is
# defined before Reuse in the file — Reuse is resolved lazily at call time.
def validate_badge(value):
    if value not in Reuse.__badges__.keys():
        raise ValidationError("Unknown badge type")


class ReuseBadge(Badge):
    kind = StringField(required=True, validation=validate_badge)


class ReuseBadgeMixin(BadgeMixin):
    badges = field(BadgesList(ReuseBadge), **BadgeMixin.default_badges_list_params)
    __badges__ = BADGES


@generate_fields(
    searchable=True,
    additional_sorts=[
        {"key": "datasets", "value": "metrics.datasets"},
        {"key": "followers", "value": "metrics.followers"},
        {"key": "views", "value": "metrics.views"},
    ],
    nested_filters={"organization_badge": "organization.badges"},
    mask="*,datasets{id,title,uri,page}",
)
class Reuse(
    Datetimed, Auditable, WithMetrics, ReuseBadgeMixin, Linkable, Owned, Document[ReuseQuerySet]
):
    title = field(
        StringField(required=True),
        sortable=True,
        show_as_ref=True,
    )
    slug = field(
        SlugField(max_length=255, required=True, populate_from="title", update=True, follow=True),
        readonly=True,
        auditable=False,
    )
    description = field(
        StringField(required=True),
        markdown=True,
    )
    type = field(
        StringField(required=True, choices=list(REUSE_TYPES)),
        filterable={},
    )
    url = field(
        URLField(required=True),
        description="The remote URL (website)",
        checks=[check_url_does_not_exists],
    )
    urlhash = StringField(required=True, unique=True)
    image_url = StringField()
    image = field(
        ImageField(
            fs=images,
            basename=default_image_basename,
            max_size=IMAGE_MAX_SIZE,
            thumbnails=IMAGE_SIZES,
        ),
        readonly=True,
        show_as_ref=True,
        thumbnail_info={
            "size": BIGGEST_IMAGE_SIZE,
        },
    )
    datasets = field(
        ListField(
            field(
                ReferenceField("Dataset", reverse_delete_rule=PULL),
                nested_fields=dataset_fields,
            ),
        ),
        filterable={
            "key": "dataset",
        },
    )
    dataservices = field(
        ListField(
            field(ReferenceField("Dataservice", reverse_delete_rule=PULL)),
        ),
        filterable={
            "key": "dataservice",
        },
    )
    tags = field(
        TagListField(),
        filterable={
            "key": "tag",
        },
    )
    topic = field(
        StringField(required=True, choices=list(REUSE_TOPICS)),
        filterable={},
    )

    private = field(BooleanField(default=False), filterable={})

    ext = MapField(GenericEmbeddedDocumentField())
    extras = field(ExtrasField(), auditable=False)

    featured = field(
        BooleanField(),
        filterable={},
        readonly=True,
        auditable=False,
    )
    deleted = field(
        DateTimeField(),
        auditable=False,
    )
    archived = field(
        DateTimeField(),
    )

    def __str__(self):
        return self.title or ""

    __metrics_keys__ = [
        "discussions",
        "discussions_open",
        "datasets",
        "followers",
        "followers_by_months",
        "views",
    ]

    meta = {
        "indexes": [
            "$title",
            "created_at",
            "last_modified",
            "metrics.datasets",
            "metrics.followers",
            "metrics.views",
            "urlhash",
        ]
        + Owned.meta["indexes"],
        "ordering": ["-created_at"],
        "queryset_class": ReuseQuerySet,
        "auto_create_index_on_save": True,
    }

    before_save = Signal()
    after_save = Signal()
    on_create = Signal()
    on_update = Signal()
    before_delete = Signal()
    after_delete = Signal()
    on_delete = Signal()

    verbose_name = _("reuse")

    @classmethod
    def pre_save(cls, sender, document, **kwargs):
        # Emit before_save
        cls.before_save.send(document)

    def self_web_url(self, **kwargs):
        return cdata_url(f"/reuses/{self._link_id(**kwargs)}", **kwargs)

    def self_api_url(self, **kwargs):
        return url_for(
            "api.reuse", reuse=self._link_id(**kwargs), **self._self_api_url_kwargs(**kwargs)
        )

    @field(description="Link to the API endpoint for this reuse", show_as_ref=True)
    def uri(self, *args, **kwargs):
        return self.self_api_url(*args, **kwargs)

    @field(description="Link to the udata web page for this reuse", show_as_ref=True)
    def page(self, *args, **kwargs):
        return self.self_web_url(*args, **kwargs)

    @property
    @field(
        nested_fields=reuse_permissions_fields,
    )
    def permissions(self):
        from udata.core.dataset.permissions import OwnableReadPermission

        from .permissions import ReuseEditPermission

        return {
            "delete": ReuseEditPermission(self),
            "edit": ReuseEditPermission(self),
            "read": OwnableReadPermission(self),
        }

    @property
    def is_visible(self):
        return not self.is_hidden

    @property
    def is_hidden(self):
        return len(self.datasets) == 0 or self.private or self.deleted

    @property
    def type_label(self):
        return REUSE_TYPES[self.type]

    @property
    def topic_label(self):
        return REUSE_TOPICS[self.topic]

    def clean(self):
        super(Reuse, self).clean()
        """Auto populate urlhash from url"""
        if not self.urlhash or "url" in self._get_changed_fields():
            self.urlhash = hash_url(self.url)

    @classmethod
    def get(cls, id_or_slug):
        obj = cls.objects(slug=id_or_slug).first()
        return obj or cls.objects.get_or_404(id=id_or_slug)

    @classmethod
    def url_exists(cls, url):
        urlhash = hash_url(url)
        return cls.objects(urlhash=urlhash).count() > 0

    @cached_property
    def json_ld(self):
        result = {
            "@context": "http://schema.org",
            "@type": "CreativeWork",
            "alternateName": self.slug,
            "dateCreated": self.created_at.isoformat(),
            "dateModified": self.last_modified.isoformat(),
            "url": self.url_for(),
            "name": self.title,
            "isBasedOnUrl": self.url,
        }

        if self.description:
            result["description"] = mdstrip(self.description)

        if self.organization:
            author = self.organization.json_ld
        elif self.owner:
            author = self.owner.json_ld
        else:
            author = None

        if author:
            result["author"] = author

        return result

    @property
    def views_count(self):
        return self.metrics.get("views", 0)

    def count_datasets(self):
        self.metrics["datasets"] = len(self.datasets)
        self.save(signal_kwargs={"ignores": ["post_save"]})

    def count_discussions(self):
        from udata.models import Discussion

        self.metrics["discussions"] = Discussion.objects(subject=self).count()
        self.metrics["discussions_open"] = Discussion.objects(subject=self, closed=None).count()
        self.save(signal_kwargs={"ignores": ["post_save"]})

    def count_followers(self):
        from udata.models import Follow

        self.metrics["followers"] = Follow.objects(until=None).followers(self).count()
        self.metrics["followers_by_months"] = get_stock_metrics(
            Follow.objects(following=self), date_label="since"
        )
        self.save(signal_kwargs={"ignores": ["post_save"]})


pre_save.connect(Reuse.pre_save, sender=Reuse)
post_save.connect(Reuse.post_save, sender=Reuse)
