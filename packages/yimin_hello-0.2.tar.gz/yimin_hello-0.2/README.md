Since the publication of the first edition of this book, both through teaching the
material it covers and as a result of receiving helpful comments from colleagues,
we have become aware of the desirability of changes in a number of areas.
The most important of these is that the mathematical preparation of current
senior college and university entrants is now less thorough than it used to be.
To match this, we decided to include a preliminary chapter covering areas such
as polynomial equations, trigonometric identities, coordinate geometry, partial
fractions, binomial expansions, necessary and sufficient condition and proof by
induction and contradiction.