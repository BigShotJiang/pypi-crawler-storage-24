from setuptools import setup, find_packages

setup(
    name = 'yimin_hello',
    version='0.2',
    packages=find_packages(),
    entry_points = {
        "console_scripts": [
            "yimin-hello = yimin_hello:hello",
        ],
    },
    install_requires=[
        # Add dependencies here
        # e.g. 'numpy >= 1.11.1'
    ]


)