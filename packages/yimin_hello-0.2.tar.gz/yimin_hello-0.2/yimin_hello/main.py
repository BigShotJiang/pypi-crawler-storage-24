# main.py

def hello():
    print ("Hello from Yimin")