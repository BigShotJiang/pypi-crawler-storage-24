# cyclonedds-idl

`cyclonedds-idl` is a pure-Python extraction of the `cyclonedds.idl` runtime from
[Eclipse Cyclone DDS Python](https://github.com/eclipse-cyclonedds/cyclonedds-python).

This package is for code that needs the Python IDL/CDR layer only, [see the IDL documentation](https://cyclonedds.io/docs/cyclonedds-python/latest/idl.html).
It does **not** ship:
- the DDS runtime bindings
- native extensions
- bundled Cyclone DDS shared libraries
- CLI tools
- DDS-XTypes metadata support

## Install

```bash
pip install cyclonedds_idl
```

## Example

```python
from dataclasses import dataclass
import cyclonedds_idl as idl

@dataclass
class KeyValue(idl.IdlStruct, typename="diagnostic_msgs/msg/KeyValue"):
    key: str
    value: str

msg = KeyValue(key="mode", value="walk")
blob = msg.serialize()
msg2 = KeyValue.deserialize(blob)
assert msg2 == msg
```

## Notes on compatibility

This is **not** a drop-in replacement for the full `cyclonedds` package. The import
path is `cyclonedds_idl`, not `cyclonedds.idl`.

The code is copied from the upstream `cyclonedds.idl` package from
`eclipse-cyclonedds/cyclonedds-python` and preserves the upstream license notices.
