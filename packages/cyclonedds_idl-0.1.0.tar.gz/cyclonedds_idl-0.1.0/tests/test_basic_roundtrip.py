from dataclasses import dataclass

import cyclonedds_idl


@dataclass
class Example(cyclonedds_idl.IdlStruct):
    someint: int = 0
    somestr: str = ""


def test_roundtrip():
    msg = Example()
    msg.someint = 42
    msg.somestr = "hello"
    data = msg.serialize()
    out = Example.deserialize(data)
    assert out == msg

def test_roundtrip2():
    msg = Example(someint=42, somestr="hello")
    data = msg.serialize()
    out = Example.deserialize(data)
    assert out == msg
