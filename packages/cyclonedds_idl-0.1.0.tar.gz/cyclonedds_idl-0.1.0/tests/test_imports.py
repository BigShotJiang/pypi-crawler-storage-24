import cyclonedds_idl as idl
import cyclonedds_idl.types as types
import cyclonedds_idl.annotations as annotations


def test_exports():
    assert hasattr(idl, "IdlStruct")
    assert hasattr(types, "array")
    assert hasattr(annotations, "key")
