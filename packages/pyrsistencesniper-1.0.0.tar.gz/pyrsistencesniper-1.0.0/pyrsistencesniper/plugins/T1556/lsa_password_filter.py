"""Detect LSA password filter DLL persistence (T1556.002).

LSA Notification Packages are loaded by LSASS on every password change.
A non-default package beyond 'scecli' may intercept plaintext passwords
before they are hashed, providing credential-access persistence.
"""

from __future__ import annotations

from pyrsistencesniper.core.models import (
    CheckDefinition,
    FilterRule,
    HiveScope,
    RegistryTarget,
)
from pyrsistencesniper.plugins import register_plugin
from pyrsistencesniper.plugins.base import PersistencePlugin


@register_plugin
class LsaPasswordFilter(PersistencePlugin):
    """Check for non-default LSA Notification Packages in the SYSTEM hive."""

    definition = CheckDefinition(
        id="lsa_password_filter",
        technique="LSA Password Filter",
        mitre_id="T1556.002",
        description=(
            "LSA password filter DLLs (Notification Packages) are called "
            "on every password change. A non-default package (beyond "
            "'scecli') may capture plaintext passwords before they are "
            "hashed."
        ),
        references=("https://attack.mitre.org/techniques/T1556/002/",),
        targets=(
            RegistryTarget(
                path=r"SYSTEM\{controlset}\Control\Lsa",
                values="Notification Packages",
                scope=HiveScope.HKLM,
            ),
        ),
        allow=(
            FilterRule(
                reason="Default Windows Security Configuration Engine",
                value_matches=r"^scecli$",
            ),
        ),
    )
