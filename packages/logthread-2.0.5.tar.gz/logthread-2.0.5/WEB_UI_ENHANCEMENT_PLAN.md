# Web UI Enhancement Plan

## Current State
The LogThread Web UI (`src/logthread/web/`) has:
- ✅ FastAPI backend with comprehensive routes
- ✅ React/TypeScript frontend with graph visualization
- ✅ LogThread branding (logo, title)
- ✅ Basic graph explorer, analysis, and Cypher query interface

## Issues to Address

### 1. Backend Already Uses LogThread Commands ✅
The web backend **already integrates** with LogThread's core functionality:
- `routes/graph.py` - Graph queries (uses storage backend directly)
- `routes/search.py` - Symbol search (uses storage backend)
- `routes/analysis.py` - Dead code, coupling, health metrics
- `routes/cypher.py` - Raw Cypher queries
- `routes/diff.py` - Branch comparison
- `routes/processes.py` - Execution flows
- `routes/dependencies.py` - Dependency analysis
- `routes/ai.py` - AI-powered features

The backend doesn't call CLI commands directly - it uses the same underlying `LadybugBackend` storage that the CLI uses. This is the correct architecture.

### 2. UX Improvements Needed

#### A. Professional Polish
- [ ] Add loading states with better feedback
- [ ] Improve error handling and user messages
- [ ] Add tooltips and help text
- [ ] Better empty states (already added for Code Explorer!)
- [ ] Consistent spacing and typography

#### B. Enhanced Features
- [ ] **Quick Actions Panel**: Add a command palette (⌘K) for quick access
- [ ] **Status Dashboard**: Show indexing status, last updated, project stats
- [ ] **Search Improvements**: Better search UI with filters and suggestions
- [ ] **Context Menu**: Right-click actions on nodes/symbols
- [ ] **Export Options**: Export graphs, reports, documentation
- [ ] **Settings Panel**: User preferences, theme options

#### C. Better Navigation
- [ ] Breadcrumbs for navigation history
- [ ] Recent symbols/files list
- [ ] Bookmarks/favorites
- [ ] Split view for comparing symbols

#### D. Enhanced Visualizations
- [ ] Minimap for large graphs
- [ ] Better node clustering visualization
- [ ] Timeline view for git history
- [ ] Dependency tree view
- [ ] Architecture diagrams

## Implementation Priority

### Phase 1: Core UX (High Priority)
1. ✅ Fix migration error for new directories
2. ✅ Update branding from AXON to LogThread
3. [ ] Add comprehensive loading states
4. [ ] Improve error messages
5. [ ] Add command palette (⌘K)

### Phase 2: Enhanced Features (Medium Priority)
1. [ ] Status dashboard
2. [ ] Better search UI
3. [ ] Context menus
4. [ ] Export functionality

### Phase 3: Advanced Features (Lower Priority)
1. [ ] Split view
2. [ ] Bookmarks
3. [ ] Advanced visualizations
4. [ ] Theme customization

## Technical Notes

### Backend Architecture (Correct ✅)
```
CLI Commands → Core Functions → LadybugBackend
                    ↑
Web API Routes ─────┘
```

Both CLI and Web UI use the same storage backend. No need to call CLI commands from web routes.

### Frontend Stack
- React 18 with TypeScript
- Vite for build/dev
- D3.js for graph visualization
- Zustand for state management
- Lucide React for icons
- JetBrains Mono font

### API Endpoints Already Available
- `GET /api/graph/overview` - Graph statistics
- `GET /api/graph/nodes` - All nodes
- `GET /api/graph/node/{id}` - Node details
- `POST /api/search/query` - Search symbols
- `GET /api/analysis/dead-end` - Dead code report
- `GET /api/analysis/coupling` - Coupling analysis
- `POST /api/cypher` - Execute Cypher query
- `GET /api/processes` - Execution flows
- `GET /api/dependencies` - Dependency tree

## Next Steps

1. **Immediate**: Test the migration fix
2. **Short-term**: Add loading states and better error handling
3. **Medium-term**: Implement command palette and status dashboard
4. **Long-term**: Advanced visualizations and features

## Files to Modify

### Frontend Components
- `src/logthread/web/frontend/src/components/layout/Header.tsx` - Add status info
- `src/logthread/web/frontend/src/components/explorer/` - Enhance explorer UI
- `src/logthread/web/frontend/src/components/analysis/` - Improve analysis views
- `src/logthread/web/frontend/src/stores/` - Add new state management

### Backend Routes (if needed)
- `src/logthread/web/routes/analysis.py` - Add more analysis endpoints
- `src/logthread/web/routes/graph.py` - Enhance graph queries

### Styling
- `src/logthread/web/frontend/src/index.css` - Update design system
- Component-specific styles as needed
