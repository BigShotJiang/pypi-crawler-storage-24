#!/bin/bash
# LogThread Cloud API - Endpoint Testing Script
# Run this after starting the API with: uvicorn app.main:app --reload

BASE_URL="http://localhost:8000"
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo "Testing LogThread Cloud API Endpoints..."
echo "========================================="
echo ""

# Test 1: Health Check
echo -n "Testing /health... "
response=$(curl -s -w "\n%{http_code}" "$BASE_URL/health")
http_code=$(echo "$response" | tail -n1)
body=$(echo "$response" | head -n1)

if [ "$http_code" -eq 200 ]; then
    echo -e "${GREEN}✓ PASS${NC} (200)"
    echo "  Response: $body"
else
    echo -e "${RED}✗ FAIL${NC} ($http_code)"
fi
echo ""

# Test 2: Status
echo -n "Testing /status... "
response=$(curl -s -w "\n%{http_code}" "$BASE_URL/status")
http_code=$(echo "$response" | tail -n1)
body=$(echo "$response" | head -n1)

if [ "$http_code" -eq 200 ]; then
    echo -e "${GREEN}✓ PASS${NC} (200)"
    echo "  Response: $body"
else
    echo -e "${RED}✗ FAIL${NC} ($http_code)"
fi
echo ""

# Test 3: CLI Version
echo -n "Testing /cli/latest-version... "
response=$(curl -s -w "\n%{http_code}" "$BASE_URL/cli/latest-version")
http_code=$(echo "$response" | tail -n1)
body=$(echo "$response" | head -n1)

if [ "$http_code" -eq 200 ]; then
    echo -e "${GREEN}✓ PASS${NC} (200)"
    echo "  Response: $body"
else
    echo -e "${RED}✗ FAIL${NC} ($http_code)"
fi
echo ""

# Test 4: Model Proxy - List Models
echo -n "Testing /model-proxy/v1/models... "
response=$(curl -s -w "\n%{http_code}" "$BASE_URL/model-proxy/v1/models")
http_code=$(echo "$response" | tail -n1)
body=$(echo "$response" | head -n1)

if [ "$http_code" -eq 200 ]; then
    echo -e "${GREEN}✓ PASS${NC} (200)"
    echo "  Response: $body"
else
    echo -e "${RED}✗ FAIL${NC} ($http_code)"
fi
echo ""

# Test 5: Registry - List Packages
echo -n "Testing /registry/packages... "
response=$(curl -s -w "\n%{http_code}" "$BASE_URL/registry/packages")
http_code=$(echo "$response" | tail -n1)
body=$(echo "$response" | head -n1)

if [ "$http_code" -eq 200 ]; then
    echo -e "${GREEN}✓ PASS${NC} (200)"
    echo "  Response: $body"
else
    echo -e "${RED}✗ FAIL${NC} ($http_code)"
fi
echo ""

# Test 6: Versions
echo -n "Testing /versions... "
response=$(curl -s -w "\n%{http_code}" "$BASE_URL/versions")
http_code=$(echo "$response" | tail -n1)
body=$(echo "$response" | head -n1)

if [ "$http_code" -eq 200 ]; then
    echo -e "${GREEN}✓ PASS${NC} (200)"
    echo "  Response: $body"
else
    echo -e "${RED}✗ FAIL${NC} ($http_code)"
fi
echo ""

echo "========================================="
echo "Test suite completed!"
echo ""
echo "To test authenticated endpoints, you'll need to:"
echo "1. Set up authentication in cloud-api"
echo "2. Get an API token"
echo "3. Add -H 'Authorization: Bearer <token>' to the curl commands"
