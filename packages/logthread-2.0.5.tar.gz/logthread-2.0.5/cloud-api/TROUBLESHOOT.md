# Log Thread Cloud API Troubleshooting

## Site Not Loading - Quick Fix

Run these commands on your production server:

### 1. Check Container Status
```bash
cd /home/opc/logthread/cloud-api
docker compose ps
```

**Expected**: Container should show "Up" status  
**If Down**: Container crashed, check logs in step 2

### 2. Check Container Logs
```bash
docker compose logs --tail=50 api
```

**Look for**:
- Import errors (missing dependencies)
- Database connection errors
- Configuration errors
- Port binding issues

### 3. Check if Port 8000 is Listening
```bash
netstat -tlnp | grep 8000
```

**Expected**: Should show something like:
```
tcp        0      0 127.0.0.1:8000          0.0.0.0:*               LISTEN      12345/docker-proxy
```

**If Nothing**: Container isn't running or not binding to port

### 4. Test Direct Connection
```bash
curl -v http://127.0.0.1:8000/health
```

**Expected**: `{"status":"healthy"}`  
**If Connection Refused**: Container not running  
**If Timeout**: Container running but app crashed

### 5. Rebuild Container (if needed)
```bash
cd /home/opc/logthread/cloud-api

# Stop and remove
docker compose down

# Rebuild with no cache
docker compose build --no-cache

# Start
docker compose up -d

# Watch logs
docker compose logs -f api
```

### 6. Check Environment Variables
```bash
cd /home/opc/logthread/cloud-api
cat .env | grep -v "SECRET\|KEY" | head -20
```

**Required variables**:
- `DATABASE_URL` - Must be valid PostgreSQL connection
- `JWT_SECRET_KEY` - Any random string
- `STRIPE_SECRET_KEY` - From Stripe dashboard
- `STRIPE_PUBLISHABLE_KEY` - From Stripe dashboard
- `STRIPE_WEBHOOK_SECRET` - From Stripe webhook config
- `STRIPE_PRICE_ID` - Your $4.99/month price ID
- `APP_URL` - https://logthread.dev
- `API_URL` - https://api.logthread.dev

### 7. Check Database Connection
```bash
# From inside container
docker compose exec api python -c "
from app.database import engine
import asyncio
async def test():
    async with engine.begin() as conn:
        result = await conn.execute('SELECT 1')
        print('Database connected:', result.scalar())
asyncio.run(test())
"
```

### 8. Check Nginx
```bash
# Test nginx config
nginx -t

# Reload nginx
systemctl reload nginx

# Check nginx logs
tail -f /var/log/nginx/error.log
```

---

## Common Issues

### Issue: "email_validator not installed"
**Fix**: Already fixed in latest code. Rebuild container:
```bash
docker compose build --no-cache
docker compose up -d
```

### Issue: Database connection failed
**Symptoms**: Container starts but crashes immediately  
**Fix**: Check DATABASE_URL in .env file
```bash
# Test connection manually
psql "postgresql://user:pass@host:5432/dbname"
```

### Issue: Port 8000 already in use
**Symptoms**: Container fails to start with "address already in use"  
**Fix**: Find and kill the process
```bash
lsof -ti:8000 | xargs kill -9
docker compose up -d
```

### Issue: Static files not found
**Symptoms**: CSS/JS not loading  
**Fix**: Ensure static directory exists
```bash
mkdir -p /home/opc/logthread/cloud-api/static
docker compose restart api
```

### Issue: Templates not found
**Symptoms**: 500 error when accessing pages  
**Fix**: Check templates directory exists
```bash
ls -la /home/opc/logthread/cloud-api/app/templates/
```

Should show:
- base.html
- index.html
- login.html
- register.html
- pricing.html
- dashboard.html
- device.html

---

## Quick Health Check Script

Save as `health-check.sh`:

```bash
#!/bin/bash
echo "=== Log Thread Health Check ==="
echo ""

echo "1. Container Status:"
docker compose ps
echo ""

echo "2. Port 8000 Listening:"
netstat -tlnp | grep 8000
echo ""

echo "3. Health Endpoint:"
curl -s http://127.0.0.1:8000/health
echo ""

echo "4. Recent Logs:"
docker compose logs --tail=20 api
echo ""

echo "=== End Health Check ==="
```

Run with: `bash health-check.sh`

---

## If All Else Fails

1. **Check if database exists and is accessible**
2. **Verify all environment variables are set**
3. **Look at container logs for specific error**
4. **Try running locally first to isolate issue**

Contact: Share the output of `docker compose logs api` for help
