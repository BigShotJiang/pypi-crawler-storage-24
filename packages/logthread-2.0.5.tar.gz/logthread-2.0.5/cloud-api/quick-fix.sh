#!/bin/bash
# Quick fix script for Log Thread deployment issues

set -e

echo "=== Log Thread Quick Fix ==="
echo ""

# Navigate to project directory
cd /home/opc/logthread/cloud-api

echo "1. Stopping existing containers..."
docker compose down

echo ""
echo "2. Pulling latest changes..."
git pull origin main || echo "No git repo or already up to date"

echo ""
echo "3. Checking .env file..."
if [ ! -f .env ]; then
    echo "ERROR: .env file not found!"
    echo "Please create .env file with required variables"
    exit 1
fi

echo "Required variables check:"
grep -q "DATABASE_URL" .env && echo "✓ DATABASE_URL found" || echo "✗ DATABASE_URL missing"
grep -q "JWT_SECRET_KEY" .env && echo "✓ JWT_SECRET_KEY found" || echo "✗ JWT_SECRET_KEY missing"
grep -q "STRIPE_SECRET_KEY" .env && echo "✓ STRIPE_SECRET_KEY found" || echo "✗ STRIPE_SECRET_KEY missing"
grep -q "STRIPE_PRICE_ID" .env && echo "✓ STRIPE_PRICE_ID found" || echo "✗ STRIPE_PRICE_ID missing"

echo ""
echo "4. Creating static directory..."
mkdir -p static

echo ""
echo "5. Rebuilding container (this may take a few minutes)..."
docker compose build --no-cache

echo ""
echo "6. Starting container..."
docker compose up -d

echo ""
echo "7. Waiting for container to start..."
sleep 5

echo ""
echo "8. Checking container status..."
docker compose ps

echo ""
echo "9. Testing health endpoint..."
sleep 2
curl -s http://127.0.0.1:8000/health || echo "Health check failed - container may still be starting"

echo ""
echo "10. Showing recent logs..."
docker compose logs --tail=30 api

echo ""
echo "=== Fix Complete ==="
echo ""
echo "Check if site is accessible:"
echo "  curl http://127.0.0.1:8000/"
echo ""
echo "If still not working, check logs:"
echo "  docker compose logs -f api"
