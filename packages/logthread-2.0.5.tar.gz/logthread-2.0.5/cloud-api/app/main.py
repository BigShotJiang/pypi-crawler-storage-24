from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse

from .routers import auth, device, billing, graph, model_proxy, registry, analytics, misc, control_plane, ide
from .config import get_settings

settings = get_settings()

BASE_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = BASE_DIR / "static"
TEMPLATES_DIR = Path(__file__).resolve().parent / "templates"

app = FastAPI(
    title="LogThread API",
    description="Code Intelligence Platform API with Knowledge Graph",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(device.router)
app.include_router(billing.router)
app.include_router(graph.router)
app.include_router(model_proxy.router)
app.include_router(registry.router)
app.include_router(analytics.router)
app.include_router(misc.router)
app.include_router(control_plane.router)
app.include_router(ide.router)

if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(
        request, "index.html", {"stripe_key": settings.stripe_publishable_key}
    )


@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse(request, "login.html")


@app.get("/register", response_class=HTMLResponse)
async def register_page(request: Request):
    return templates.TemplateResponse(request, "register.html")


@app.get("/pricing", response_class=HTMLResponse)
async def pricing_page(request: Request):
    return templates.TemplateResponse(
        request, "pricing.html", {"stripe_key": settings.stripe_publishable_key}
    )


@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard_page(request: Request):
    return templates.TemplateResponse(request, "dashboard.html")


@app.get("/device", response_class=HTMLResponse)
async def device_auth_page(request: Request, code: str = None):
    return templates.TemplateResponse(
        request, "device.html", {"device_code": code}
    )


@app.get("/explore/{repo_id}", response_class=HTMLResponse)
async def explore_graph_page(request: Request, repo_id: str):
    return templates.TemplateResponse(
        request, "explore.html", {"repo_id": repo_id}
    )


@app.get("/terms", response_class=HTMLResponse)
async def terms_page(request: Request):
    return templates.TemplateResponse(request, "terms.html")


@app.get("/privacy", response_class=HTMLResponse)
async def privacy_page(request: Request):
    return templates.TemplateResponse(request, "privacy.html")


@app.get("/settings", response_class=HTMLResponse)
async def settings_page(request: Request):
    return templates.TemplateResponse(request, "settings.html")


@app.get("/settings/billing", response_class=HTMLResponse)
async def billing_settings_page(request: Request):
    return templates.TemplateResponse(
        request, "billing_settings.html", {"stripe_key": settings.stripe_publishable_key}
    )


@app.get("/organizations/new", response_class=HTMLResponse)
async def new_organization_page(request: Request):
    return templates.TemplateResponse(request, "new_organization.html")


@app.get("/agents", response_class=HTMLResponse)
async def agents_page(request: Request):
    return templates.TemplateResponse(request, "agents.html")


@app.get("/agents/devboxes")
async def list_devboxes():
    """List available devboxes/agents - must be before /{agent_id} route"""
    return {
        "devboxes": [],
        "total": 0
    }


@app.get("/agents/{agent_id}", response_class=HTMLResponse)
async def agent_detail_page(request: Request, agent_id: str):
    return templates.TemplateResponse(
        request, "agent_detail.html", {"agent_id": agent_id}
    )


@app.get("/health")
async def health():
    return {"status": "healthy"}
