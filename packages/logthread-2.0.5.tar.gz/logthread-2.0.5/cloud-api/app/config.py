from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    database_url: str
    jwt_secret_key: str
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 10080
    
    stripe_secret_key: str = ""
    stripe_publishable_key: str = ""
    stripe_webhook_secret: str = ""
    stripe_price_id: str = ""
    
    resend_api_key: str = ""
    from_email: str = "hello@logthread.dev"
    
    storage_provider: str = "oci"
    
    oci_config_file: str = "~/.oci/config"
    oci_config_profile: str = "DEFAULT"
    oci_auth: str = "config"
    oci_namespace: str = ""
    oci_bucket: str = "logthread-graphs"
    oci_compartment_id: str = ""
    
    aws_access_key_id: str = ""
    aws_secret_access_key: str = ""
    aws_region: str = "us-east-1"
    s3_bucket: str = "logthread-graphs"
    
    app_url: str = "https://logthread.dev"
    api_url: str = "https://api.logthread.dev"

    class Config:
        env_file = ".env"
        extra = "ignore"


@lru_cache()
def get_settings() -> Settings:
    return Settings()
