from fastapi import APIRouter, HTTPException, Depends
from typing import Optional, Dict, Any
from pydantic import BaseModel

from ..services.auth import get_current_user

router = APIRouter(prefix="/registry", tags=["registry"])


class ConfigPackage(BaseModel):
    name: str
    version: str
    config: Dict[str, Any]
    description: Optional[str] = None
    author: Optional[str] = None


class PackageMetadata(BaseModel):
    name: str
    version: str
    description: Optional[str] = None
    author: Optional[str] = None


# In-memory storage (replace with database in production)
configs_db: Dict[str, ConfigPackage] = {}
packages_db: Dict[str, PackageMetadata] = {}


@router.get("/configs/{config_id}")
async def get_config(config_id: str):
    """
    Fetch a configuration by ID from the registry.
    Used by Continue extension to load remote configs.
    """
    if config_id not in configs_db:
        raise HTTPException(status_code=404, detail="Config not found")
    
    return configs_db[config_id]


@router.post("/configs")
async def create_config(
    config: ConfigPackage,
    current_user: dict = Depends(get_current_user),
):
    """
    Publish a configuration to the registry.
    Requires authentication.
    """
    config_id = f"{config.name}-{config.version}"
    configs_db[config_id] = config
    
    return {
        "id": config_id,
        "name": config.name,
        "version": config.version,
        "message": "Config published successfully",
    }


@router.get("/packages/{package_name}")
async def get_package(package_name: str):
    """
    Get package metadata from the registry.
    """
    if package_name not in packages_db:
        raise HTTPException(status_code=404, detail="Package not found")
    
    return packages_db[package_name]


@router.post("/packages")
async def create_package(
    package: PackageMetadata,
    current_user: dict = Depends(get_current_user),
):
    """
    Publish a package to the registry.
    Requires authentication.
    """
    packages_db[package.name] = package
    
    return {
        "name": package.name,
        "version": package.version,
        "message": "Package published successfully",
    }


@router.get("/packages")
async def list_packages(
    search: Optional[str] = None,
    limit: int = 20,
):
    """
    List available packages in the registry.
    """
    packages = list(packages_db.values())
    
    if search:
        packages = [p for p in packages if search.lower() in p.name.lower()]
    
    return {
        "packages": packages[:limit],
        "total": len(packages),
    }
