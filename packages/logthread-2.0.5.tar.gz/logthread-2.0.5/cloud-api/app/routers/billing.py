from fastapi import APIRouter, Depends, HTTPException, Request, Header
from sqlalchemy.ext.asyncio import AsyncSession

from ..database import get_db
from ..services import auth, billing

router = APIRouter(prefix="/billing", tags=["billing"])


@router.post("/checkout")
async def create_checkout(request: Request, db: AsyncSession = Depends(get_db)):
    """Create Stripe checkout session"""
    auth_header = request.headers.get("Authorization")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    token = auth_header.split(" ")[1]
    payload = auth.decode_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    user = await auth.get_user_by_id(db, payload["sub"])
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    
    checkout_url = await billing.create_checkout_session(db, user)
    if not checkout_url:
        raise HTTPException(status_code=503, detail="Billing not configured")
    
    return {"checkout_url": checkout_url}


@router.post("/portal")
async def create_portal(request: Request, db: AsyncSession = Depends(get_db)):
    """Create Stripe customer portal session for subscription management"""
    auth_header = request.headers.get("Authorization")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    token = auth_header.split(" ")[1]
    payload = auth.decode_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    user = await auth.get_user_by_id(db, payload["sub"])
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    
    portal_url = await billing.create_portal_session(db, user)
    if not portal_url:
        raise HTTPException(status_code=503, detail="Billing not configured")
    
    return {"portal_url": portal_url}


@router.post("/webhook")
async def stripe_webhook(
    request: Request,
    stripe_signature: str = Header(None, alias="Stripe-Signature"),
    db: AsyncSession = Depends(get_db)
):
    """Handle Stripe webhooks"""
    payload = await request.body()
    
    if not stripe_signature:
        raise HTTPException(status_code=400, detail="Missing signature")
    
    success = await billing.handle_webhook(db, payload, stripe_signature)
    
    if not success:
        raise HTTPException(status_code=400, detail="Webhook processing failed")
    
    return {"received": True}
