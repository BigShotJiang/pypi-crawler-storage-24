from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel

from ..database import get_db
from ..services import auth
from ..config import get_settings

router = APIRouter(prefix="/device", tags=["device"])
settings = get_settings()


class DeviceAuthRequest(BaseModel):
    device_name: str = "Log Thread CLI"
    device_type: str = "cli"


class DeviceAuthResponse(BaseModel):
    device_code: str
    verification_url: str
    expires_in: int = 900


class DeviceTokenRequest(BaseModel):
    device_code: str


class DeviceTokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_email: str


@router.post("/auth", response_model=DeviceAuthResponse)
async def initiate_device_auth(req: DeviceAuthRequest, db: AsyncSession = Depends(get_db)):
    """Initiate device authorization flow (for CLI/MCP login)"""
    session = await auth.create_device_session(db, req.device_name, req.device_type)
    
    return DeviceAuthResponse(
        device_code=session.device_code,
        verification_url=f"{settings.app_url}/device?code={session.device_code}",
        expires_in=900,
    )


@router.post("/token", response_model=DeviceTokenResponse)
async def get_device_token(req: DeviceTokenRequest, db: AsyncSession = Depends(get_db)):
    """Poll for device authorization status"""
    session = await auth.get_device_session(db, req.device_code)
    
    if not session:
        raise HTTPException(status_code=404, detail="Device session not found")
    
    if not session.is_verified:
        raise HTTPException(status_code=400, detail="authorization_pending")
    
    if not session.access_token:
        raise HTTPException(status_code=400, detail="Authorization failed")
    
    user = await auth.get_user_by_id(db, str(session.user_id))
    
    return DeviceTokenResponse(
        access_token=session.access_token,
        user_email=user.email,
    )


@router.post("/authorize")
async def authorize_device(req: DeviceTokenRequest, request: Request, db: AsyncSession = Depends(get_db)):
    """Authorize a device (called from web UI after user login)"""
    auth_header = request.headers.get("Authorization")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    token = auth_header.split(" ")[1]
    payload = auth.decode_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    user = await auth.get_user_by_id(db, payload["sub"])
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    
    # Check subscription
    if not await auth.is_subscription_active(db, str(user.id)):
        raise HTTPException(status_code=402, detail="Active subscription required")
    
    session = await auth.authorize_device(db, req.device_code, str(user.id))
    if not session:
        raise HTTPException(status_code=404, detail="Device session not found")
    
    return {"message": "Device authorized successfully"}


@router.post("/validate")
async def validate_device_token(request: Request, db: AsyncSession = Depends(get_db)):
    """Validate a device token and return subscription status"""
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    token = auth_header.split(" ")[1]
    
    # Check if it's an API key
    if token.startswith("lt_"):
        user = await auth.validate_api_key(db, token)
        if not user:
            raise HTTPException(status_code=401, detail="Invalid or expired API key")
    else:
        payload = auth.decode_token(token)
        if not payload:
            raise HTTPException(status_code=401, detail="Invalid token")
        
        user = await auth.get_user_by_id(db, payload["sub"])
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        
        if not await auth.is_subscription_active(db, str(user.id)):
            raise HTTPException(status_code=402, detail="Subscription expired")
    
    return {
        "valid": True,
        "user_id": str(user.id),
        "email": user.email,
    }
