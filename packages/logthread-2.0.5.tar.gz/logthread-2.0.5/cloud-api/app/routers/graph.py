from __future__ import annotations

import gzip
import io
import json
import logging
import re
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, Form, HTTPException, Request, UploadFile, File
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..database import get_db
from ..services import auth
from ..services.auth import get_current_user
from ..services.storage import get_storage
from ..models import Repository
from ..config import get_settings

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/graph", tags=["graph"])
settings = get_settings()

# In-memory manifest cache  {repo_id: manifest_dict}
_manifest_cache: dict[str, dict] = {}
TRACE_REL_TYPES = {
    "calls",
    "imports",
    "defines",
    "depends_on",
    "uses_library",
    "queries_table",
    "queries_column",
    "has_column",
    "handles_route",
    "protected_by",
    "uses_type",
}
TRACE_TRAVERSABLE_TYPES = {
    "Function",
    "Method",
    "Class",
    "Interface",
    "TypeAlias",
    "File",
    "Module",
    "ApiEndpoint",
    "DbTable",
    "DbColumn",
}


class SyncRequest(BaseModel):
    repo_name: str
    repo_path_hash: str
    symbols_count: int
    edges_count: int
    files_count: int


# ── Helpers ──────────────────────────────────────────────────────────────────

def _chunk_key(user_id: str, repo_id: str, chunk_type: str, index: int) -> str:
    return f"graphs/{user_id}/{repo_id}/{chunk_type}_{index}.json.gz"


def _manifest_key(user_id: str, repo_id: str) -> str:
    return f"graphs/{user_id}/{repo_id}/manifest.json"


async def _load_manifest(user_id: str, repo_id: str) -> Optional[dict]:
    """Load manifest from cache or cloud storage."""
    if repo_id in _manifest_cache:
        return _manifest_cache[repo_id]
    storage = get_storage()
    try:
        key = _manifest_key(user_id, repo_id)
        raw = storage.download(key)  # returns bytes
        if raw:
            manifest = json.loads(raw)
            _manifest_cache[repo_id] = manifest
            return manifest
    except Exception:
        pass
    return None


async def _load_chunk(user_id: str, repo_id: str, chunk_type: str, index: int) -> list:
    """Download and decompress a node/edge chunk from storage."""
    storage = get_storage()
    key = _chunk_key(user_id, repo_id, chunk_type, index)
    try:
        raw = storage.download(key)
        if raw:
            return json.loads(gzip.decompress(raw))
    except Exception:
        pass
    return []


def _is_api_like(name: str, node_index: dict[str, dict]) -> bool:
    node_meta = node_index.get(name) or {}
    if node_meta.get("t") == "ApiEndpoint":
        return True
    return bool(re.match(r"^(GET|POST|PUT|PATCH|DELETE|USE):", name or "", re.IGNORECASE))


async def _load_all_edge_chunks(user_id: str, repo_id: str, manifest: dict) -> list[dict]:
    edges: list[dict] = []
    for i in range(manifest.get("edge_chunks", 0)):
        edges.extend(await _load_chunk(user_id, repo_id, "edges", i))
    return edges


def _build_node_payload(name: str, node_index: dict[str, dict]) -> Optional[dict]:
    idx = node_index.get(name)
    if not idx:
        return None
    return {
        "name": name,
        "type": idx.get("t", ""),
        "file": idx.get("f", ""),
    }


def _should_keep_node(name: str, node_index: dict[str, dict], counts: dict[tuple[str, str], int], limit: int = 10) -> bool:
    idx = node_index.get(name) or {}
    node_type = idx.get("t", "")
    node_file = idx.get("f", "")
    if node_type not in {"Function", "Method", "DbTable", "DbColumn"}:
        return True
    key = (node_file, node_type)
    used = counts.get(key, 0)
    if used >= limit:
        return False
    counts[key] = used + 1
    return True


def _build_trace_subgraph(
    focal: str,
    node_index: dict[str, dict],
    edges: list[dict],
    *,
    max_depth: int,
) -> tuple[list[dict], list[dict]]:
    outgoing: dict[str, list[dict]] = {}
    incoming: dict[str, list[dict]] = {}
    for edge in edges:
        if edge.get("rel") not in TRACE_REL_TYPES:
            continue
        outgoing.setdefault(edge.get("from", ""), []).append(edge)
        incoming.setdefault(edge.get("to", ""), []).append(edge)

    kept_nodes: set[str] = {focal}
    kept_edges: list[dict] = []
    seen_edges: set[tuple[str, str, str]] = set()
    frontier = [focal]
    visited = {focal}
    file_counts: dict[tuple[str, str], int] = {}

    for depth in range(max_depth):
        if not frontier:
            break
        next_frontier: list[str] = []
        for current in frontier:
            for edge in outgoing.get(current, [])[: 20 if depth == 0 else 10]:
                target = edge.get("to", "")
                if not target:
                    continue
                if target not in kept_nodes and not _should_keep_node(target, node_index, file_counts):
                    continue
                edge_key = (edge.get("from", ""), edge.get("rel", ""), target)
                if edge_key not in seen_edges:
                    kept_edges.append(edge)
                    seen_edges.add(edge_key)
                kept_nodes.add(edge.get("from", ""))
                kept_nodes.add(target)
                target_type = (node_index.get(target) or {}).get("t", "")
                if target not in visited and target_type in TRACE_TRAVERSABLE_TYPES:
                    visited.add(target)
                    next_frontier.append(target)

            if depth == 0:
                for edge in incoming.get(current, [])[:12]:
                    edge_key = (edge.get("from", ""), edge.get("rel", ""), edge.get("to", ""))
                    if edge_key not in seen_edges:
                        kept_edges.append(edge)
                        seen_edges.add(edge_key)
                    if edge.get("from"):
                        kept_nodes.add(edge["from"])
                    if edge.get("to"):
                        kept_nodes.add(edge["to"])

        frontier = next_frontier[:12]

    node_payloads = [
        payload
        for name in kept_nodes
        if (payload := _build_node_payload(name, node_index)) is not None
    ]
    return node_payloads, kept_edges


# ── Routes ───────────────────────────────────────────────────────────────────

@router.get("/repos")
async def list_repos(db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    result = await db.execute(
        select(Repository)
        .where(Repository.user_id == user.id)
        .order_by(Repository.updated_at.desc())
    )
    repos = result.scalars().all()
    return {
        "repositories": [
            {
                "id": str(r.id),
                "name": r.name,
                "symbols_count": r.symbols_count,
                "edges_count": r.edges_count,
                "files_count": r.files_count,
                "last_analyzed": r.last_analyzed.isoformat() if r.last_analyzed else None,
                "has_cloud_data": bool(r.graph_data_url),
            }
            for r in repos
        ]
    }


@router.post("/sync")
async def sync_repo_metadata(
    req: SyncRequest,
    db: AsyncSession = Depends(get_db),
    user=Depends(get_current_user),
):
    result = await db.execute(
        select(Repository).where(
            Repository.user_id == user.id,
            Repository.path_hash == req.repo_path_hash,
        )
    )
    repo = result.scalar_one_or_none()
    if not repo:
        repo = Repository(
            user_id=user.id,
            name=req.repo_name,
            path_hash=req.repo_path_hash,
        )
        db.add(repo)

    repo.name = req.repo_name
    repo.symbols_count = req.symbols_count
    repo.edges_count = req.edges_count
    repo.files_count = req.files_count
    repo.last_analyzed = datetime.utcnow()

    await db.commit()
    await db.refresh(repo)
    return {"id": str(repo.id)}


@router.post("/upload-chunk/{repo_id}", status_code=201)
async def upload_chunk(
    repo_id: str,
    file: UploadFile = File(...),
    chunk_type: str = Form(...),   # "nodes" | "edges" | "manifest"
    index: int = Form(0),
    hash: str = Form(""),
    db: AsyncSession = Depends(get_db),
    user=Depends(get_current_user),
):
    """Accept a single chunk (nodes, edges, or manifest) and store it."""
    result = await db.execute(
        select(Repository).where(
            Repository.id == repo_id,
            Repository.user_id == user.id,
        )
    )
    repo = result.scalar_one_or_none()
    if not repo:
        raise HTTPException(status_code=404, detail="Repository not found")

    storage = get_storage()
    data = await file.read()
    uid = str(user.id)

    if chunk_type == "manifest":
        key = _manifest_key(uid, repo_id)
        storage.upload_bytes(key, data, content_type="application/json")
        # Invalidate cache so next read picks up new data
        _manifest_cache.pop(repo_id, None)
        # Mark repo as having cloud data
        repo.graph_data_url = f"manifest:{key}"
        await db.commit()
    else:
        # nodes_N.json.gz  or  edges_N.json.gz
        key = _chunk_key(uid, repo_id, chunk_type, index)
        storage.upload_bytes(key, data, content_type="application/gzip")

    return {"ok": True, "key": key}


@router.get("/data/{repo_id}")
async def get_graph_data(
    repo_id: str,
    db: AsyncSession = Depends(get_db),
    user=Depends(get_current_user),
):
    """Return manifest (node index + stats) — lightweight, no chunk download."""
    result = await db.execute(
        select(Repository).where(
            Repository.id == repo_id,
            Repository.user_id == user.id,
        )
    )
    repo = result.scalar_one_or_none()
    if not repo:
        raise HTTPException(status_code=404, detail="Repository not found")

    manifest = await _load_manifest(str(user.id), repo_id)
    if not manifest:
        return {
            "repo_id": repo_id,
            "name": repo.name,
            "has_graph_data": False,
            "symbols_count": repo.symbols_count or 0,
            "edges_count": repo.edges_count or 0,
            "nodes": [],
        }

    return {
        "repo_id": repo_id,
        "name": repo.name,
        "has_graph_data": True,
        "version": manifest.get("version", ""),
        "symbols_count": manifest.get("total_nodes", repo.symbols_count or 0),
        "edges_count": manifest.get("total_edges", repo.edges_count or 0),
        "node_chunks": manifest.get("node_chunks", 0),
        "edge_chunks": manifest.get("edge_chunks", 0),
        "nodes": manifest.get("nodes", []),  # lightweight index (name/type/file)
    }


@router.get("/nodes/{repo_id}")
async def get_nodes(
    repo_id: str,
    chunk: int = 0,
    db: AsyncSession = Depends(get_db),
    user=Depends(get_current_user),
):
    """Download a single node chunk (full detail: id/name/type/file/line/sig)."""
    result = await db.execute(
        select(Repository).where(
            Repository.id == repo_id,
            Repository.user_id == user.id,
        )
    )
    if not result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Repository not found")

    nodes = await _load_chunk(str(user.id), repo_id, "nodes", chunk)
    return {"chunk": chunk, "nodes": nodes}


@router.get("/edges/{repo_id}")
async def get_edges(
    repo_id: str,
    chunk: int = 0,
    db: AsyncSession = Depends(get_db),
    user=Depends(get_current_user),
):
    """Download a single edge chunk."""
    result = await db.execute(
        select(Repository).where(
            Repository.id == repo_id,
            Repository.user_id == user.id,
        )
    )
    if not result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Repository not found")

    edges = await _load_chunk(str(user.id), repo_id, "edges", chunk)
    return {"chunk": chunk, "edges": edges}


@router.get("/symbol/{repo_id}/{name:path}")
async def get_symbol(
    repo_id: str,
    name: str,
    db: AsyncSession = Depends(get_db),
    user=Depends(get_current_user),
):
    """Return full detail for a single symbol plus its direct connections."""
    result = await db.execute(
        select(Repository).where(
            Repository.id == repo_id,
            Repository.user_id == user.id,
        )
    )
    if not result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Repository not found")

    uid = str(user.id)
    manifest = await _load_manifest(uid, repo_id)
    if not manifest:
        raise HTTPException(status_code=404, detail="Graph data not synced yet")

    # Find symbol in node chunks
    node_detail: Optional[dict] = None
    for i in range(manifest.get("node_chunks", 0)):
        chunk_nodes = await _load_chunk(uid, repo_id, "nodes", i)
        for n in chunk_nodes:
            if n.get("name") == name:
                node_detail = n
                break
        if node_detail:
            break

    if not node_detail:
        raise HTTPException(status_code=404, detail=f"Symbol '{name}' not found")

    # Collect callers / callees and related relationships from edge chunks
    callers: list[str] = []
    callees: list[str] = []
    type_refs: list[str] = []
    libraries: list[str] = []
    tables: list[str] = []
    columns: list[str] = []
    related_files: list[str] = []
    for i in range(manifest.get("edge_chunks", 0)):
        chunk_edges = await _load_chunk(uid, repo_id, "edges", i)
        for e in chunk_edges:
            if e.get("to") == name:
                callers.append(e.get("from", ""))
            if e.get("from") == name:
                callees.append(e.get("to", ""))
                rel = e.get("rel", "")
                if rel == "uses_type":
                    type_refs.append(e.get("to", ""))
                elif rel == "uses_library":
                    libraries.append(e.get("to", ""))
                elif rel == "queries_table":
                    tables.append(e.get("to", ""))
                elif rel in {"queries_column", "has_column"}:
                    columns.append(e.get("to", ""))

    seen_related = set(callers + callees + type_refs + libraries + tables + columns)
    for related_name in seen_related:
        idx = next((n for n in manifest.get("nodes", []) if n.get("n") == related_name), None)
        if idx and idx.get("f"):
            related_files.append(idx["f"])

    return {
        **node_detail,
        "callers": callers[:50],
        "callees": callees[:50],
        "type_refs": list(dict.fromkeys(type_refs))[:30],
        "libraries": list(dict.fromkeys(libraries))[:30],
        "tables": list(dict.fromkeys(tables))[:30],
        "columns": list(dict.fromkeys(columns))[:40],
        "related_files": list(dict.fromkeys(related_files))[:30],
        "callers_count": len(callers),
        "callees_count": len(callees),
    }


@router.get("/neighbors/{repo_id}/{name:path}")
async def get_neighbors(
    repo_id: str,
    name: str,
    db: AsyncSession = Depends(get_db),
    user=Depends(get_current_user),
):
    """Return a focused graph neighborhood with deeper tracing for APIs."""
    result = await db.execute(
        select(Repository).where(
            Repository.id == repo_id,
            Repository.user_id == user.id,
        )
    )
    if not result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Repository not found")

    uid = str(user.id)
    manifest = await _load_manifest(uid, repo_id)
    if not manifest:
        raise HTTPException(status_code=404, detail="Graph data not synced yet")

    node_index = {n["n"]: n for n in manifest.get("nodes", [])}
    edge_list = await _load_all_edge_chunks(uid, repo_id, manifest)
    result_nodes, local_edges = _build_trace_subgraph(
        name,
        node_index,
        edge_list,
        max_depth=4 if _is_api_like(name, node_index) else 2,
    )

    return {
        "focal": name,
        "nodes": result_nodes,
        "edges": local_edges,
    }


@router.get("/search/{repo_id}")
async def search_symbols(
    repo_id: str,
    q: str = "",
    limit: int = 40,
    db: AsyncSession = Depends(get_db),
    user=Depends(get_current_user),
):
    """Fast symbol search using the manifest node index (no chunk download)."""
    result = await db.execute(
        select(Repository).where(
            Repository.id == repo_id,
            Repository.user_id == user.id,
        )
    )
    if not result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Repository not found")

    manifest = await _load_manifest(str(user.id), repo_id)
    if not manifest:
        return {"symbols": []}

    q_lower = q.lower()
    matches = []
    for n in manifest.get("nodes", []):
        if not q or q_lower in n.get("n", "").lower() or q_lower in n.get("f", "").lower():
            matches.append({"name": n["n"], "type": n.get("t", ""), "file": n.get("f", "")})
            if len(matches) >= limit:
                break

    return {"symbols": matches}
