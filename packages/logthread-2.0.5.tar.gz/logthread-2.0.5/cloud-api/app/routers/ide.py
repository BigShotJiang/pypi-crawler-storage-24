from fastapi import APIRouter, HTTPException, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel
from typing import Optional, List

from ..database import get_db
from ..services import auth
from ..config import get_settings

router = APIRouter(prefix="/ide", tags=["ide"])
settings = get_settings()


class PolicyResponse(BaseModel):
    allowedWorkspacePaths: List[str] = []
    disallowAnonymousTelemetry: bool = False


class CreditStatus(BaseModel):
    optedIntoFreeTrial: bool = False
    creditBalance: float = 0.0
    hasCredits: bool = False


class Organization(BaseModel):
    id: str
    name: str
    slug: str
    is_owner: bool = False


class Assistant(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    organization_id: Optional[str] = None


@router.get("/policy")
async def get_policy(request: Request):
    """
    Get IDE security policy configuration.
    Used by Continue extension for workspace permissions.
    """
    return PolicyResponse(
        allowedWorkspacePaths=[],
        disallowAnonymousTelemetry=False
    )


@router.get("/credits")
async def get_credits(request: Request):
    """
    Get user credit status for IDE.
    Returns credit balance and free trial info.
    """
    auth_header = request.headers.get("Authorization")
    
    # If not authenticated, return default
    if not auth_header:
        return CreditStatus()
    
    try:
        token = auth_header.split(" ")[1] if " " in auth_header else auth_header
        payload = auth.decode_token(token)
        
        if not payload:
            return CreditStatus()
        
        # TODO: Implement actual credit tracking
        return CreditStatus(
            optedIntoFreeTrial=False,
            creditBalance=0.0,
            hasCredits=False
        )
    except Exception:
        return CreditStatus()


@router.get("/list-organizations")
async def list_organizations(
    request: Request,
    db: AsyncSession = Depends(get_db)
):
    """
    List organizations the user belongs to.
    Used by Continue extension for org selection.
    """
    auth_header = request.headers.get("Authorization")
    
    # Return personal org by default
    default_orgs = [
        Organization(
            id="personal",
            name="Personal",
            slug="personal",
            is_owner=True
        )
    ]
    
    if not auth_header:
        return default_orgs
    
    try:
        token = auth_header.split(" ")[1] if " " in auth_header else auth_header
        payload = auth.decode_token(token)
        
        if not payload:
            return default_orgs
        
        user = await auth.get_user_by_id(db, payload["sub"])
        if not user:
            return default_orgs
        
        # TODO: Implement actual organization membership tracking
        # For now, return personal org
        return [
            Organization(
                id="personal",
                name="Personal",
                slug="personal",
                is_owner=True
            )
        ]
    except Exception:
        return default_orgs


@router.get("/list-assistants")
async def list_assistants(
    request: Request,
    organization_id: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    List AI assistants/profiles available to the user.
    Used by Continue extension for assistant selection.
    """
    auth_header = request.headers.get("Authorization")
    
    # Return default assistant
    default_assistants = [
        Assistant(
            id="default",
            name="LogThread Assistant",
            description="AI coding assistant with knowledge graph",
            organization_id=organization_id or "personal"
        )
    ]
    
    if not auth_header:
        return default_assistants
    
    try:
        token = auth_header.split(" ")[1] if " " in auth_header else auth_header
        payload = auth.decode_token(token)
        
        if not payload:
            return default_assistants
        
        user = await auth.get_user_by_id(db, payload["sub"])
        if not user:
            return default_assistants
        
        # TODO: Implement actual assistant/profile management
        return default_assistants
    except Exception:
        return default_assistants
