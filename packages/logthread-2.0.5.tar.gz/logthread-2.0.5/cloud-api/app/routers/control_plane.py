from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel
from typing import Optional, List

from ..database import get_db
from ..services import auth
from ..config import get_settings

router = APIRouter(prefix="/control-plane", tags=["control-plane"])
settings = get_settings()


class CreditStatus(BaseModel):
    optedIntoFreeTrial: bool = False
    creditBalance: float = 0.0
    hasCredits: bool = False
    usageHistory: List[dict] = []


class Environment(BaseModel):
    name: str
    apiUrl: str
    appUrl: str


class SessionInfo(BaseModel):
    account: dict
    accessToken: str
    authType: str


@router.get("/credit-status")
async def get_credit_status(
    request: Request,
    db: AsyncSession = Depends(get_db)
):
    """Get user credit status and usage information"""
    auth_header = request.headers.get("Authorization")
    if not auth_header:
        return CreditStatus()
    
    try:
        token = auth_header.split(" ")[1]
        payload = auth.decode_token(token)
        if not payload:
            return CreditStatus()
        
        user = await auth.get_user_by_id(db, payload["sub"])
        if not user:
            return CreditStatus()
        
        # TODO: Implement actual credit tracking
        # For now, return default values
        return CreditStatus(
            optedIntoFreeTrial=False,
            creditBalance=0.0,
            hasCredits=False,
            usageHistory=[]
        )
    except Exception:
        return CreditStatus()


@router.get("/environment")
async def get_environment():
    """Get control plane environment configuration"""
    return Environment(
        name="production",
        apiUrl=f"https://api.{settings.app_url.replace('https://', '')}",
        appUrl=settings.app_url
    )


@router.get("/session-info")
async def get_session_info(
    request: Request,
    db: AsyncSession = Depends(get_db)
):
    """Get current user session information"""
    auth_header = request.headers.get("Authorization")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    token = auth_header.split(" ")[1]
    payload = auth.decode_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    user = await auth.get_user_by_id(db, payload["sub"])
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    
    return SessionInfo(
        account={
            "id": user.email,
            "email": user.email,
            "name": user.name or user.email,
        },
        accessToken=token,
        authType="workos"
    )
