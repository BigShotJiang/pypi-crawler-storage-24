from fastapi import APIRouter, HTTPException, Depends
from typing import Optional, Dict, Any, List
from pydantic import BaseModel
from datetime import datetime

from ..services.auth import get_current_user

router = APIRouter(prefix="/proxy/analytics", tags=["analytics"])


class AnalyticsEvent(BaseModel):
    event: str
    properties: Optional[Dict[str, Any]] = None
    timestamp: Optional[str] = None
    user_id: Optional[str] = None
    session_id: Optional[str] = None


class UsageStats(BaseModel):
    total_requests: int
    total_tokens: int
    models_used: Dict[str, int]
    time_period: str


# In-memory event storage (replace with database in production)
events_db: List[AnalyticsEvent] = []


@router.post("/{workspace_id}/capture")
async def capture_event(
    workspace_id: str,
    event: AnalyticsEvent,
):
    """
    Capture analytics events from Continue extension.
    Tracks model usage, feature usage, errors, etc.
    """
    # Add timestamp if not provided
    if not event.timestamp:
        event.timestamp = datetime.utcnow().isoformat()
    
    # Store event (in production, send to analytics service like PostHog/Mixpanel)
    events_db.append(event)
    
    return {
        "status": "success",
        "event_id": f"evt_{len(events_db)}",
        "workspace_id": workspace_id,
    }


@router.get("/usage")
async def get_usage_stats(
    current_user: dict = Depends(get_current_user),
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
):
    """
    Get usage statistics for the authenticated user.
    Returns model usage, token consumption, etc.
    """
    # Filter events for this user
    user_events = [e for e in events_db if e.user_id == current_user.get("id")]
    
    # Calculate stats
    models_used = {}
    for event in user_events:
        if event.properties and "model" in event.properties:
            model = event.properties["model"]
            models_used[model] = models_used.get(model, 0) + 1
    
    return {
        "total_events": len(user_events),
        "models_used": models_used,
        "time_period": f"{start_date or 'all_time'}",
    }


@router.get("/stats")
async def get_analytics_stats(
    current_user: dict = Depends(get_current_user),
    event_type: Optional[str] = None,
):
    """
    Get detailed analytics statistics.
    """
    user_events = [e for e in events_db if e.user_id == current_user.get("id")]
    
    if event_type:
        user_events = [e for e in user_events if e.event == event_type]
    
    # Group events by type
    events_by_type = {}
    for event in user_events:
        events_by_type[event.event] = events_by_type.get(event.event, 0) + 1
    
    return {
        "total_events": len(user_events),
        "events_by_type": events_by_type,
        "recent_events": user_events[-10:],  # Last 10 events
    }
