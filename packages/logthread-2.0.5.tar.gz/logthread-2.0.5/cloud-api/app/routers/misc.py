from fastapi import APIRouter, HTTPException
from typing import Optional, Dict, Any
from pydantic import BaseModel
import os

router = APIRouter(tags=["misc"])


class VersionInfo(BaseModel):
    version: str
    download_url: str
    release_notes: Optional[str] = None


@router.get("/cli/latest-version")
async def get_latest_cli_version():
    """
    Return the latest CLI version for update checks.
    Used by the Continue CLI to check for updates.
    """
    # In production, fetch from GitHub releases or version service
    return {
        "version": "0.9.0",
        "download_url": "https://logthread.dev/downloads/cli/latest",
        "release_notes": "https://logthread.dev/changelog",
    }


@router.get("/health")
async def health_check():
    """
    Health check endpoint for monitoring.
    """
    return {
        "status": "healthy",
        "service": "logthread-api",
        "version": "1.0.0",
    }


@router.get("/status")
async def service_status():
    """
    Detailed service status including dependencies.
    """
    return {
        "api": "operational",
        "database": "operational",
        "auth": "operational",
        "model_proxy": "operational",
        "timestamp": "2024-01-01T00:00:00Z",
    }


@router.get("/versions")
async def get_all_versions():
    """
    Get version information for all LogThread components.
    """
    return {
        "api": "1.0.0",
        "cli": "0.9.0",
        "vscode_extension": "2.0.17",
        "intellij_extension": "1.5.0",
        "sdk_python": "0.8.0",
        "sdk_typescript": "0.8.0",
    }
