import stripe
from datetime import datetime
from typing import Optional
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..models import User, Subscription

settings = get_settings()

if settings.stripe_secret_key:
    stripe.api_key = settings.stripe_secret_key


async def get_or_create_stripe_customer(db: AsyncSession, user: User) -> Optional[str]:
    if not settings.stripe_secret_key:
        return None
    
    sub = await db.execute(select(Subscription).where(Subscription.user_id == user.id))
    subscription = sub.scalar_one_or_none()
    
    if subscription and subscription.stripe_customer_id:
        return subscription.stripe_customer_id
    
    customer = stripe.Customer.create(
        email=user.email,
        name=user.name,
        metadata={"user_id": str(user.id)},
    )
    
    if not subscription:
        subscription = Subscription(user_id=user.id, stripe_customer_id=customer.id)
        db.add(subscription)
    else:
        subscription.stripe_customer_id = customer.id
    
    await db.commit()
    return customer.id


async def create_checkout_session(db: AsyncSession, user: User) -> Optional[str]:
    if not settings.stripe_secret_key:
        return None
    
    customer_id = await get_or_create_stripe_customer(db, user)
    
    session = stripe.checkout.Session.create(
        customer=customer_id,
        payment_method_types=["card"],
        line_items=[{
            "price": settings.stripe_price_id,
            "quantity": 1,
        }],
        mode="subscription",
        success_url=f"{settings.app_url}/dashboard?checkout=success",
        cancel_url=f"{settings.app_url}/pricing?checkout=canceled",
        metadata={"user_id": str(user.id)},
    )
    
    return session.url


async def create_portal_session(db: AsyncSession, user: User) -> Optional[str]:
    if not settings.stripe_secret_key:
        return None
    
    customer_id = await get_or_create_stripe_customer(db, user)
    
    session = stripe.billing_portal.Session.create(
        customer=customer_id,
        return_url=f"{settings.app_url}/dashboard",
    )
    
    return session.url


async def handle_webhook(db: AsyncSession, payload: bytes, signature: str) -> bool:
    if not settings.stripe_webhook_secret:
        return False
    
    try:
        event = stripe.Webhook.construct_event(
            payload, signature, settings.stripe_webhook_secret
        )
    except Exception:
        return False

    if event["type"] == "checkout.session.completed":
        session = event["data"]["object"]
        user_id = session.get("metadata", {}).get("user_id")
        if user_id:
            await activate_subscription(db, user_id, session.get("subscription"))

    elif event["type"] == "customer.subscription.updated":
        sub_data = event["data"]["object"]
        await update_subscription_status(db, sub_data)

    elif event["type"] == "customer.subscription.deleted":
        sub_data = event["data"]["object"]
        await cancel_subscription(db, sub_data["id"])

    elif event["type"] == "invoice.payment_failed":
        invoice = event["data"]["object"]
        customer_id = invoice.get("customer")
        await mark_subscription_past_due(db, customer_id)

    return True


async def activate_subscription(db: AsyncSession, user_id: str, stripe_subscription_id: str):
    if not stripe_subscription_id:
        return
    
    result = await db.execute(select(Subscription).where(Subscription.user_id == user_id))
    subscription = result.scalar_one_or_none()
    
    if not subscription:
        subscription = Subscription(user_id=user_id)
        db.add(subscription)
    
    stripe_sub = stripe.Subscription.retrieve(stripe_subscription_id)
    
    subscription.stripe_subscription_id = stripe_subscription_id
    subscription.status = "active"
    
    if stripe_sub.get("items", {}).get("data"):
        subscription.stripe_price_id = stripe_sub["items"]["data"][0]["price"]["id"]
    
    if stripe_sub.get("current_period_start"):
        subscription.current_period_start = datetime.fromtimestamp(stripe_sub["current_period_start"])
    if stripe_sub.get("current_period_end"):
        subscription.current_period_end = datetime.fromtimestamp(stripe_sub["current_period_end"])
    
    await db.commit()


async def update_subscription_status(db: AsyncSession, sub_data: dict):
    result = await db.execute(
        select(Subscription).where(Subscription.stripe_subscription_id == sub_data["id"])
    )
    subscription = result.scalar_one_or_none()
    
    if subscription:
        subscription.status = sub_data["status"]
        subscription.current_period_end = datetime.fromtimestamp(sub_data["current_period_end"])
        subscription.cancel_at_period_end = sub_data.get("cancel_at_period_end", False)
        await db.commit()


async def cancel_subscription(db: AsyncSession, stripe_subscription_id: str):
    result = await db.execute(
        select(Subscription).where(Subscription.stripe_subscription_id == stripe_subscription_id)
    )
    subscription = result.scalar_one_or_none()
    
    if subscription:
        subscription.status = "canceled"
        subscription.canceled_at = datetime.utcnow()
        await db.commit()


async def mark_subscription_past_due(db: AsyncSession, stripe_customer_id: str):
    result = await db.execute(
        select(Subscription).where(Subscription.stripe_customer_id == stripe_customer_id)
    )
    subscription = result.scalar_one_or_none()
    
    if subscription:
        subscription.status = "past_due"
        await db.commit()
