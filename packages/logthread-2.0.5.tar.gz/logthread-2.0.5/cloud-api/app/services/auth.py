from datetime import datetime, timedelta
from typing import Optional
import secrets
import hashlib

import bcrypt
from jose import jwt, JWTError
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi import Depends, HTTPException, Header

from ..config import get_settings
from ..models import User, Subscription, APIKey, DeviceSession
from ..database import get_db

settings = get_settings()


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')


def verify_password(plain: str, hashed: str) -> bool:
    return bcrypt.checkpw(plain.encode('utf-8'), hashed.encode('utf-8'))


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=settings.access_token_expire_minutes))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.jwt_secret_key, algorithm=settings.jwt_algorithm)


def decode_token(token: str) -> Optional[dict]:
    try:
        return jwt.decode(token, settings.jwt_secret_key, algorithms=[settings.jwt_algorithm])
    except JWTError:
        return None


def generate_api_key() -> tuple[str, str, str]:
    """Generate API key, returns (full_key, prefix, hash)"""
    key = secrets.token_urlsafe(32)
    prefix = f"lt_{key[:8]}"
    key_hash = hashlib.sha256(key.encode()).hexdigest()
    return f"lt_{key}", prefix, key_hash


def verify_api_key(key: str, key_hash: str) -> bool:
    if not key.startswith("lt_"):
        return False
    computed_hash = hashlib.sha256(key[3:].encode()).hexdigest()
    return computed_hash == key_hash


def generate_device_code() -> str:
    return secrets.token_urlsafe(32)


async def get_user_by_email(db: AsyncSession, email: str) -> Optional[User]:
    result = await db.execute(select(User).where(User.email == email.lower()))
    return result.scalar_one_or_none()


async def get_user_by_id(db: AsyncSession, user_id: str) -> Optional[User]:
    result = await db.execute(select(User).where(User.id == user_id))
    return result.scalar_one_or_none()


async def create_user(db: AsyncSession, email: str, password: str, name: str = None) -> User:
    user = User(
        email=email.lower(),
        password_hash=hash_password(password),
        name=name,
        verification_token=secrets.token_urlsafe(32),
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)
    return user


async def verify_email(db: AsyncSession, token: str) -> Optional[User]:
    result = await db.execute(select(User).where(User.verification_token == token))
    user = result.scalar_one_or_none()
    if user:
        user.email_verified = True
        user.verification_token = None
        await db.commit()
    return user


async def get_subscription(db: AsyncSession, user_id: str) -> Optional[Subscription]:
    result = await db.execute(select(Subscription).where(Subscription.user_id == user_id))
    return result.scalar_one_or_none()


async def is_subscription_active(db: AsyncSession, user_id: str) -> bool:
    sub = await get_subscription(db, user_id)
    if not sub:
        return False
    return sub.status == "active" and (
        sub.current_period_end is None or sub.current_period_end > datetime.utcnow()
    )


async def create_api_key_for_user(db: AsyncSession, user_id: str, name: str = "Default") -> tuple[str, APIKey]:
    full_key, prefix, key_hash = generate_api_key()
    api_key = APIKey(
        user_id=user_id,
        key_hash=key_hash,
        key_prefix=prefix,
        name=name,
    )
    db.add(api_key)
    await db.commit()
    await db.refresh(api_key)
    return full_key, api_key


async def validate_api_key(db: AsyncSession, key: str) -> Optional[User]:
    if not key or not key.startswith("lt_"):
        return None
    
    prefix = f"lt_{key[3:11]}"
    result = await db.execute(
        select(APIKey).where(APIKey.key_prefix == prefix, APIKey.is_active == True)
    )
    api_key = result.scalar_one_or_none()
    
    if not api_key or not verify_api_key(key, api_key.key_hash):
        return None
    
    # Update last used
    api_key.last_used = datetime.utcnow()
    await db.commit()
    
    # Check subscription
    if not await is_subscription_active(db, str(api_key.user_id)):
        return None
    
    return await get_user_by_id(db, str(api_key.user_id))


async def create_device_session(db: AsyncSession, device_name: str, device_type: str) -> DeviceSession:
    session = DeviceSession(
        device_code=generate_device_code(),
        device_name=device_name,
        device_type=device_type,
    )
    db.add(session)
    await db.commit()
    await db.refresh(session)
    return session


async def get_device_session(db: AsyncSession, device_code: str) -> Optional[DeviceSession]:
    result = await db.execute(select(DeviceSession).where(DeviceSession.device_code == device_code))
    return result.scalar_one_or_none()


async def authorize_device(db: AsyncSession, device_code: str, user_id: str) -> Optional[DeviceSession]:
    session = await get_device_session(db, device_code)
    if not session:
        return None
    
    session.user_id = user_id
    session.is_verified = True
    session.access_token = create_access_token({"sub": str(user_id), "device": str(session.id)})
    session.expires_at = datetime.utcnow() + timedelta(days=30)
    await db.commit()
    await db.refresh(session)
    return session


async def get_current_user(
    authorization: Optional[str] = Header(None),
    db: AsyncSession = Depends(get_db)
) -> User:
    """FastAPI dependency to get current authenticated user from Bearer token or API key"""
    if not authorization:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    # Try Bearer token (JWT)
    if authorization.startswith("Bearer "):
        token = authorization.split("Bearer ")[1]
        
        # Try API key first
        if token.startswith("lt_"):
            user = await validate_api_key(db, token)
            if user:
                return user
        
        # Try JWT token
        payload = decode_token(token)
        if payload:
            user = await get_user_by_id(db, payload["sub"])
            if user:
                return user
    
    raise HTTPException(status_code=401, detail="Invalid authentication credentials")
