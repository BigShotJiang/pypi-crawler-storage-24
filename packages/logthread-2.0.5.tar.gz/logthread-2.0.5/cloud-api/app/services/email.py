import logging
import resend
from ..config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

if settings.resend_api_key:
    resend.api_key = settings.resend_api_key


async def send_verification_email(email: str, token: str):
    if not settings.resend_api_key:
        logger.warning(f"Email not configured. Verification token for {email}: {token}")
        return
    
    verify_url = f"{settings.api_url}/auth/verify?token={token}"
    
    resend.Emails.send({
        "from": settings.from_email,
        "to": email,
        "subject": "Verify your Log Thread account",
        "html": f"""
        <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto; padding: 40px 20px;">
            <div style="text-align: center; margin-bottom: 32px;">
                <h1 style="color: #6366f1; margin: 0; font-size: 28px;">Log Thread</h1>
                <p style="color: #64748b; margin: 8px 0 0 0;">Code Intelligence Platform</p>
            </div>
            
            <h2 style="color: #1e293b; margin-bottom: 16px;">Verify your email</h2>
            <p style="color: #475569; line-height: 1.6;">
                Thanks for signing up! Click the button below to verify your email and activate your account.
            </p>
            
            <div style="text-align: center; margin: 32px 0;">
                <a href="{verify_url}" style="background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); color: white; padding: 14px 32px; border-radius: 8px; text-decoration: none; font-weight: 600; display: inline-block;">
                    Verify Email
                </a>
            </div>
            
            <p style="color: #94a3b8; font-size: 14px;">
                If you didn't create an account, you can safely ignore this email.
            </p>
        </div>
        """
    })


async def send_welcome_email(email: str, name: str = None):
    if not settings.resend_api_key:
        logger.warning(f"Email not configured. Skipping welcome email for {email}")
        return
    
    resend.Emails.send({
        "from": settings.from_email,
        "to": email,
        "subject": "Welcome to Log Thread! 🚀",
        "html": f"""
        <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto; padding: 40px 20px;">
            <div style="text-align: center; margin-bottom: 32px;">
                <h1 style="color: #6366f1; margin: 0; font-size: 28px;">Log Thread</h1>
            </div>
            
            <h2 style="color: #1e293b; margin-bottom: 16px;">Welcome{f', {name}' if name else ''}! 🎉</h2>
            
            <p style="color: #475569; line-height: 1.6;">
                Your subscription is now active. You're ready to experience intelligent code understanding that makes every AI coding assistant smarter.
            </p>
            
            <h3 style="color: #1e293b; margin-top: 24px;">Quick Start</h3>
            <ol style="color: #475569; line-height: 1.8;">
                <li>Install the CLI: <code style="background: #f1f5f9; padding: 2px 6px; border-radius: 4px;">pip install logthread</code></li>
                <li>Login: <code style="background: #f1f5f9; padding: 2px 6px; border-radius: 4px;">logthread login</code></li>
                <li>Analyze your project: <code style="background: #f1f5f9; padding: 2px 6px; border-radius: 4px;">logthread analyze .</code></li>
                <li>Start the server: <code style="background: #f1f5f9; padding: 2px 6px; border-radius: 4px;">logthread serve --watch</code></li>
            </ol>
            
            <p style="color: #475569; line-height: 1.6; margin-top: 24px;">
                Add Log Thread to your Cursor/Windsurf MCP config, and watch your AI assistant become dramatically more accurate.
            </p>
            
            <div style="text-align: center; margin: 32px 0;">
                <a href="{settings.app_url}/dashboard" style="background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); color: white; padding: 14px 32px; border-radius: 8px; text-decoration: none; font-weight: 600; display: inline-block;">
                    Go to Dashboard
                </a>
            </div>
            
            <p style="color: #94a3b8; font-size: 14px; text-align: center;">
                Questions? Reply to this email — we read every message.
            </p>
        </div>
        """
    })


async def send_subscription_canceled_email(email: str):
    if not settings.resend_api_key:
        logger.warning(f"Email not configured. Skipping cancellation email for {email}")
        return
    
    resend.Emails.send({
        "from": settings.from_email,
        "to": email,
        "subject": "Your Log Thread subscription has ended",
        "html": f"""
        <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto; padding: 40px 20px;">
            <div style="text-align: center; margin-bottom: 32px;">
                <h1 style="color: #6366f1; margin: 0; font-size: 28px;">Log Thread</h1>
            </div>
            
            <h2 style="color: #1e293b; margin-bottom: 16px;">We're sorry to see you go</h2>
            
            <p style="color: #475569; line-height: 1.6;">
                Your Log Thread subscription has ended. Your code intelligence features are now disabled.
            </p>
            
            <p style="color: #475569; line-height: 1.6;">
                If you change your mind, you can resubscribe anytime and pick up right where you left off.
            </p>
            
            <div style="text-align: center; margin: 32px 0;">
                <a href="{settings.app_url}/pricing" style="background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); color: white; padding: 14px 32px; border-radius: 8px; text-decoration: none; font-weight: 600; display: inline-block;">
                    Resubscribe
                </a>
            </div>
            
            <p style="color: #94a3b8; font-size: 14px;">
                We'd love to know why you canceled. Reply to this email with any feedback.
            </p>
        </div>
        """
    })
