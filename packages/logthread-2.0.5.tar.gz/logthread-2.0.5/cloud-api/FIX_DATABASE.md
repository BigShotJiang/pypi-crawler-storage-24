# Database Connection Fix

## Problem
Container can't connect to PostgreSQL on host machine because `127.0.0.1` refers to the container itself, not the host.

## Solution

### Option 1: Update docker-compose.yml (Recommended)

I've already updated the file. Now run on your server:

```bash
cd /home/opc/logthread/cloud-api

# Stop container
docker compose down

# Restart with new config
docker compose up -d

# Watch logs
docker compose logs -f api
```

### Option 2: Use .env file instead

If the docker-compose change doesn't work, update your `.env` file:

```bash
cd /home/opc/logthread/cloud-api

# Edit .env file
nano .env

# Change DATABASE_URL to use host.docker.internal:
DATABASE_URL=postgresql+asyncpg://prolxpsa:7d53d6fd04696b329ea7@host.docker.internal:5432/logthread
```

Then restart:
```bash
docker compose down
docker compose up -d
```

### Option 3: Use host network mode

If neither works, modify `docker-compose.yml`:

```yaml
services:
  api:
    build: .
    network_mode: "host"
    env_file:
      - .env
```

Then in `.env`:
```
DATABASE_URL=postgresql+asyncpg://prolxpsa:7d53d6fd04696b329ea7@127.0.0.1:5432/logthread
```

## Verify PostgreSQL is Accessible

```bash
# Check if PostgreSQL is listening on 5432
netstat -tlnp | grep 5432

# Should show something like:
# tcp        0      0 127.0.0.1:5432          0.0.0.0:*               LISTEN      1234/postgres

# If it only shows 127.0.0.1, PostgreSQL needs to listen on all interfaces
# Edit postgresql.conf:
sudo nano /var/lib/pgsql/data/postgresql.conf

# Change:
listen_addresses = '*'

# Edit pg_hba.conf to allow container connections:
sudo nano /var/lib/pgsql/data/pg_hba.conf

# Add this line:
host    logthread    prolxpsa    172.16.0.0/12    md5

# Restart PostgreSQL:
sudo systemctl restart postgresql
```

## Test Connection from Container

```bash
# Enter the container
docker compose exec api bash

# Try to connect to database
python -c "
import asyncio
import asyncpg

async def test():
    try:
        conn = await asyncpg.connect(
            'postgresql://prolxpsa:7d53d6fd04696b329ea7@host.docker.internal:5432/logthread'
        )
        print('✓ Database connected successfully!')
        await conn.close()
    except Exception as e:
        print(f'✗ Connection failed: {e}')

asyncio.run(test())
"
```

## After Fix

Once the database connects, you should see:
- No more `ConnectionRefusedError` in logs
- Registration should work
- Users can create accounts

Test by visiting: https://logthread.dev/register
