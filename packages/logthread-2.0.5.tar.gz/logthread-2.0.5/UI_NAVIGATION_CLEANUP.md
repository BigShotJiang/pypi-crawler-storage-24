# UI Navigation Cleanup

## Changes Made

### 1. Removed Duplicate Navigation from Header
**Problem**: Navigation tabs (Explorer, Analysis, Query) appeared in both the Header and Sidebar, creating redundancy.

**Solution**: Removed the navigation tabs from the Header, keeping only:
- Logo and brand
- Node/edge statistics
- Action buttons (Search, Reindex, Theme Toggle, Settings)

This creates a cleaner, less cluttered interface with navigation consolidated in the Sidebar.

### 2. Renamed "Cypher" to "Query" in Sidebar
**Problem**: "Cypher" is technical jargon that may not be immediately clear to all users.

**Solution**: 
- Changed label from "Cypher" to "Query"
- Updated keyboard shortcut from "G C" to "G Q"
- Kept the same icon (code brackets)

## Files Modified

### `src/logthread/web/frontend/src/components/layout/Header.tsx`
- Removed `tabs` array and navigation rendering
- Removed unused imports: `Command`, `Activity`, `cn`, `ActiveView`
- Removed `activeView` and `setActiveView` from store
- Simplified to focus on branding and actions only

### `src/logthread/web/frontend/src/components/layout/Sidebar.tsx`
- Updated "Cypher" label to "Query"
- Updated keyboard shortcut from "G C" to "G Q"

## New UI Layout

```
┌─────────────────────────────────────────────────────────┐
│  Logo  │  Stats  │           │  Search  Theme  Settings │  Header
├────────┴─────────┴───────────┴──────────────────────────┤
│        │                                                 │
│ Nav    │                                                 │
│ ├─ Ex  │                                                 │
│ ├─ An  │           Main Content Area                    │
│ └─ Qu  │                                                 │
│        │                                                 │
│ Set    │                                                 │
└────────┴─────────────────────────────────────────────────┘
```

## Benefits

1. **Cleaner Header**: More space for branding and essential actions
2. **Single Source of Navigation**: All view switching happens in the Sidebar
3. **Better UX**: Users know exactly where to go for navigation
4. **Clearer Labels**: "Query" is more intuitive than "Cypher"
5. **Consistent Shortcuts**: G E (Explorer), G A (Analysis), G Q (Query)

## Build Status
✓ Build completed successfully
✓ No TypeScript errors
✓ Bundle size: ~630KB

## Testing
Run `logthread web` and verify:
- Header shows only logo, stats, and action buttons
- Sidebar shows navigation items: Explorer, Analysis, Query
- Clicking sidebar items switches views correctly
- Keyboard shortcuts work (G E, G A, G Q)
