from __future__ import annotations

from pathlib import Path

import pytest

from logthread.core.storage.ladybug_backend import LadybugBackend


@pytest.fixture()
def ladybug_backend(tmp_path: Path) -> LadybugBackend:
    """Provide an initialised LadybugBackend in a temporary directory."""
    db_path = tmp_path / "test_db"
    b = LadybugBackend()
    b.initialize(db_path)
    yield b
    b.close()
