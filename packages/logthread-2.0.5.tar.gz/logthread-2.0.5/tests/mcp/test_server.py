from __future__ import annotations


def test_mcp_local_mode_does_not_require_subscription(monkeypatch) -> None:
    monkeypatch.delenv("LOGTHREAD_REQUIRE_SUBSCRIPTION", raising=False)

    from logthread.mcp import server as mcp_server

    monkeypatch.setattr(
        "logthread.mcp.server.require_subscription",
        lambda: (False, "should not be called"),
    )

    allowed, message = mcp_server._validate_mcp_access()
    assert allowed is True
    assert message == ""


def test_mcp_subscription_gate_can_be_reenabled(monkeypatch) -> None:
    monkeypatch.setenv("LOGTHREAD_REQUIRE_SUBSCRIPTION", "1")

    from logthread.mcp import server as mcp_server

    monkeypatch.setattr(
        "logthread.mcp.server.require_subscription",
        lambda: (False, "subscription required"),
    )

    allowed, message = mcp_server._validate_mcp_access()
    assert allowed is False
    assert "subscription" in message
