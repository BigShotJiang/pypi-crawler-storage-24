from __future__ import annotations

import json
from pathlib import Path

from logthread.core.graph.graph import KnowledgeGraph
from logthread.core.graph.model import GraphNode, NodeLabel, generate_id
from logthread.core.intelligence.traces import build_trace_catalog


def _file_node(path: str, *, language: str = "") -> GraphNode:
    return GraphNode(
        id=generate_id(NodeLabel.FILE, path),
        label=NodeLabel.FILE,
        name=Path(path).name,
        file_path=path,
        language=language,
    )


def test_trace_catalog_resolves_recursive_package_script_to_vite_entry(tmp_path: Path) -> None:
    repo = tmp_path
    (repo / "package.json").write_text(
        json.dumps(
            {
                "name": "web",
                "scripts": {
                    "start": "npm run dev",
                    "dev": "vite",
                },
            }
        ),
        encoding="utf-8",
    )

    graph = KnowledgeGraph()
    entry = _file_node("src/main.tsx", language="tsx")
    graph.add_node(entry)

    catalog = build_trace_catalog(graph, repo)

    manifest = next(item for item in catalog if item["kind"] == "manifest")
    assert manifest["rootNodeId"] == entry.id
    assert manifest["title"] == "start: main.tsx"


def test_trace_catalog_resolves_angular_workspace_browser_entry(tmp_path: Path) -> None:
    repo = tmp_path
    (repo / "package.json").write_text(
        json.dumps({"scripts": {"start": "ng serve"}}),
        encoding="utf-8",
    )
    (repo / "angular.json").write_text(
        json.dumps(
            {
                "projects": {
                    "app": {
                        "architect": {
                            "build": {
                                "options": {
                                    "browser": "src/main.ts",
                                }
                            }
                        }
                    }
                }
            }
        ),
        encoding="utf-8",
    )

    graph = KnowledgeGraph()
    entry = _file_node("src/main.ts", language="typescript")
    graph.add_node(entry)

    catalog = build_trace_catalog(graph, repo)

    manifest = next(item for item in catalog if item["kind"] == "manifest")
    assert manifest["rootNodeId"] == entry.id
    assert "package.json script" in manifest["subtitle"]


def test_trace_catalog_resolves_python_uvicorn_command_entry(tmp_path: Path) -> None:
    repo = tmp_path
    (repo / "pyproject.toml").write_text(
        """
[tool.hatch.envs.default.scripts]
serve = "uvicorn app.main:app --reload"
""".strip(),
        encoding="utf-8",
    )

    graph = KnowledgeGraph()
    entry = _file_node("src/app/main.py", language="python")
    graph.add_node(entry)

    catalog = build_trace_catalog(graph, repo)

    manifest = next(item for item in catalog if item["kind"] == "manifest")
    assert manifest["rootNodeId"] == entry.id
    assert manifest["title"] == "serve: main.py"


def test_trace_catalog_resolves_executable_csproj_program(tmp_path: Path) -> None:
    repo = tmp_path
    app_dir = repo / "src" / "App"
    app_dir.mkdir(parents=True)
    (app_dir / "App.csproj").write_text(
        """
<Project Sdk="Microsoft.NET.Sdk.Web">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
  </PropertyGroup>
</Project>
""".strip(),
        encoding="utf-8",
    )

    graph = KnowledgeGraph()
    entry = _file_node("src/App/Program.cs", language="csharp")
    graph.add_node(entry)

    catalog = build_trace_catalog(graph, repo)

    manifest = next(item for item in catalog if item["kind"] == "manifest")
    assert manifest["rootNodeId"] == entry.id
    assert manifest["title"] == "App: Program.cs"
