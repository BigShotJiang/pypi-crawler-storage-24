from __future__ import annotations

from logthread.core.graph.graph import KnowledgeGraph
from logthread.core.graph.model import GraphNode, NodeLabel, RelType, generate_id
from logthread.core.ingestion.api_and_db_phase import process_api_and_db
from logthread.core.ingestion.parser_phase import FileParseData
from logthread.core.parsers.base import (
    ApiEndpointInfo,
    ImportInfo,
    ParseResult,
    SqlQueryInfo,
    SymbolInfo,
)


def test_process_api_and_db_links_router_mounts_and_imported_controller_handlers() -> None:
    graph = KnowledgeGraph()

    for file_path in ("src/index.js", "src/routes/orders.js", "src/controllers/orders.js"):
        graph.add_node(
            GraphNode(
                id=generate_id(NodeLabel.FILE, file_path),
                label=NodeLabel.FILE,
                name=file_path.rsplit("/", 1)[-1],
                file_path=file_path,
            )
        )

    controller_id = generate_id(NodeLabel.FUNCTION, "src/controllers/orders.js", "getOrder")
    graph.add_node(
        GraphNode(
            id=controller_id,
            label=NodeLabel.FUNCTION,
            name="getOrder",
            file_path="src/controllers/orders.js",
            start_line=12,
            end_line=20,
        )
    )

    parse_data = [
        FileParseData(
            file_path="src/index.js",
            language="javascript",
            parse_result=ParseResult(
                imports=[
                    ImportInfo(module="./routes/orders", names=["ordersRouter"], is_relative=True),
                ],
                api_endpoints=[
                    ApiEndpointInfo(
                        method="USE",
                        path="/api/orders",
                        handler_names=["ordersRouter"],
                        line=8,
                        framework="express",
                    )
                ],
            ),
        ),
        FileParseData(
            file_path="src/routes/orders.js",
            language="javascript",
            parse_result=ParseResult(
                imports=[
                    ImportInfo(module="../controllers/orders", names=["ordersController"], is_relative=True),
                ],
                api_endpoints=[
                    ApiEndpointInfo(
                        method="GET",
                        path="/:id",
                        handler_names=["ordersController.getOrder"],
                        line=4,
                        framework="express",
                    )
                ],
            ),
        ),
        FileParseData(
            file_path="src/controllers/orders.js",
            language="javascript",
            parse_result=ParseResult(
                symbols=[
                    SymbolInfo(
                        name="getOrder",
                        kind="function",
                        start_line=12,
                        end_line=20,
                        content="function getOrder(req, res) {}",
                    )
                ],
            ),
        ),
    ]

    process_api_and_db(parse_data, graph)

    mounted_endpoint_id = generate_id(NodeLabel.API_ENDPOINT, "src/index.js", "USE:/api/orders")
    nested_endpoint_id = generate_id(NodeLabel.API_ENDPOINT, "src/routes/orders.js", "GET:/:id")
    router_file_id = generate_id(NodeLabel.FILE, "src/routes/orders.js")
    controller_file_id = generate_id(NodeLabel.FILE, "src/controllers/orders.js")

    outgoing_mount = graph.get_outgoing(mounted_endpoint_id, RelType.DEPENDS_ON)
    assert any(rel.target == router_file_id for rel in outgoing_mount)

    outgoing_nested = graph.get_outgoing(nested_endpoint_id, RelType.DEPENDS_ON)
    assert any(rel.target == controller_file_id for rel in outgoing_nested)

    incoming_route = graph.get_incoming(nested_endpoint_id, RelType.HANDLES_ROUTE)
    assert any(rel.source == controller_id for rel in incoming_route)


def test_process_api_and_db_links_sql_queries_to_tables_and_columns() -> None:
    graph = KnowledgeGraph()

    file_id = generate_id(NodeLabel.FILE, "src/orders.py")
    graph.add_node(
        GraphNode(
            id=file_id,
            label=NodeLabel.FILE,
            name="orders.py",
            file_path="src/orders.py",
        )
    )

    function_id = generate_id(NodeLabel.FUNCTION, "src/orders.py", "get_order")
    graph.add_node(
        GraphNode(
            id=function_id,
            label=NodeLabel.FUNCTION,
            name="get_order",
            file_path="src/orders.py",
            start_line=10,
            end_line=30,
        )
    )

    parse_data = [
        FileParseData(
            file_path="schema.sql",
            language="sql",
            parse_result=ParseResult(
                db_tables=[],
            ),
        ),
        FileParseData(
            file_path="src/orders.py",
            language="python",
            parse_result=ParseResult(
                sql_queries=[
                    SqlQueryInfo(
                        sql_text="SELECT orders.id, orders.customer_id FROM orders WHERE orders.id = ?",
                        tables_referenced=["orders"],
                        columns_referenced=["orders.id", "orders.customer_id"],
                        line=12,
                    )
                ],
            ),
        ),
    ]

    orders_table_id = generate_id(NodeLabel.DB_TABLE, "schema.sql", "orders")
    orders_id_col = generate_id(NodeLabel.DB_COLUMN, "schema.sql", "orders.id")
    orders_customer_col = generate_id(NodeLabel.DB_COLUMN, "schema.sql", "orders.customer_id")
    graph.add_node(
        GraphNode(
            id=orders_table_id,
            label=NodeLabel.DB_TABLE,
            name="orders",
            file_path="schema.sql",
        )
    )
    graph.add_node(
        GraphNode(
            id=orders_id_col,
            label=NodeLabel.DB_COLUMN,
            name="id",
            file_path="schema.sql",
            properties={"table": "orders", "datatype": "uuid"},
        )
    )
    graph.add_node(
        GraphNode(
            id=orders_customer_col,
            label=NodeLabel.DB_COLUMN,
            name="customer_id",
            file_path="schema.sql",
            properties={"table": "orders", "datatype": "uuid"},
        )
    )

    process_api_and_db(parse_data, graph)

    table_edges = graph.get_outgoing(function_id, RelType.QUERIES_TABLE)
    assert any(rel.target == orders_table_id for rel in table_edges)

    column_edges = graph.get_outgoing(function_id, RelType.QUERIES_COLUMN)
    assert any(rel.target == orders_id_col for rel in column_edges)
    assert any(rel.target == orders_customer_col for rel in column_edges)
