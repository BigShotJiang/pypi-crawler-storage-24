from __future__ import annotations

from pathlib import Path

import pytest

from logthread.core.intelligence.dependencies import build_dependency_intelligence
from logthread.core.storage.paths import get_project_cache_dir


def test_build_dependency_intelligence_writes_cache_for_slots_dataclass(
    tmp_path: Path,
    monkeypatch,
) -> None:
    monkeypatch.setenv("LOGTHREAD_ENABLE_EXTERNAL_DEPENDENCY_INTELLIGENCE", "1")
    monkeypatch.setattr("logthread.core.storage.paths.get_app_data_dir", lambda: tmp_path / "appdata")
    monkeypatch.setattr(
        "logthread.core.intelligence.dependencies._fetch_latest_version",
        lambda client, language, package_name: "2.0.0",
    )
    monkeypatch.setattr(
        "logthread.core.intelligence.dependencies._fetch_vulnerabilities",
        lambda client, language, package_name, version: ([{"id": "OSV-1", "summary": "sample"}], "osv.dev"),
    )

    result = build_dependency_intelligence(
        tmp_path,
        [{"dep_id": "external_dep:python:requests", "name": "requests", "language": "python", "version": "1.0.0"}],
        refresh=True,
    )

    assert result["external_dep:python:requests"].latest_version == "2.0.0"
    cache_file = get_project_cache_dir(tmp_path) / "dependency_intelligence.json"
    assert cache_file.exists()


def test_build_dependency_intelligence_respects_disabled_external_policy(
    tmp_path: Path,
    monkeypatch,
) -> None:
    monkeypatch.delenv("LOGTHREAD_ENABLE_EXTERNAL_DEPENDENCY_INTELLIGENCE", raising=False)
    monkeypatch.setattr(
        "logthread.core.intelligence.dependencies._fetch_latest_version",
        lambda *args, **kwargs: pytest.fail("external version lookup should not run"),
    )
    monkeypatch.setattr(
        "logthread.core.intelligence.dependencies._fetch_vulnerabilities",
        lambda *args, **kwargs: pytest.fail("external vulnerability lookup should not run"),
    )

    result = build_dependency_intelligence(
        tmp_path,
        [{"dep_id": "external_dep:python:requests", "name": "requests", "language": "python", "version": "1.0.0"}],
        refresh=True,
    )

    intel = result["external_dep:python:requests"]
    assert intel.latest_version is None
    assert intel.advisory_count == 0
    assert intel.lookup_error is not None
    assert "disabled by policy" in intel.lookup_error.lower()
