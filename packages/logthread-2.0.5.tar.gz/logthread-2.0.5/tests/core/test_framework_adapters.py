from __future__ import annotations

from logthread.core.frameworks.adapters import apply_framework_adapters
from logthread.core.parsers.base import ParseResult


def _adapt(language: str, content: str) -> ParseResult:
    result = ParseResult()
    apply_framework_adapters(language, "test.file", content, result)
    return result


def test_nest_controller_routes_are_detected() -> None:
    result = _adapt(
        "typescript",
        """\
@Controller('/users')
export class UsersController {
  @UseGuards(AuthGuard)
  @Get(':id')
  async getById() {}
}
""",
    )

    assert len(result.api_endpoints) == 1
    endpoint = result.api_endpoints[0]
    assert endpoint.framework == "nest"
    assert endpoint.method == "GET"
    assert endpoint.path == "/users/:id"
    assert endpoint.handler_names == ["AuthGuard", "UsersController.getById"]


def test_angular_routes_are_detected() -> None:
    result = _adapt(
        "typescript",
        """\
const routes: Routes = [
  { path: 'dashboard', component: DashboardComponent },
];
""",
    )

    assert len(result.api_endpoints) == 1
    endpoint = result.api_endpoints[0]
    assert endpoint.framework == "angular"
    assert endpoint.method == "VIEW"
    assert endpoint.path == "/dashboard"
    assert endpoint.handler_names == ["DashboardComponent"]


def test_django_urlpatterns_are_detected() -> None:
    result = _adapt(
        "python",
        """\
urlpatterns = [
    path("health/", views.health),
]
""",
    )

    assert len(result.api_endpoints) == 1
    endpoint = result.api_endpoints[0]
    assert endpoint.framework == "django"
    assert endpoint.method == "ANY"
    assert endpoint.path == "/health/"
    assert endpoint.handler_names == ["views.health"]


def test_spring_routes_are_detected() -> None:
    result = _adapt(
        "java",
        """\
@RestController
@RequestMapping("/api/orders")
class OrdersController {
    @GetMapping("/{id}")
    public Order getOrder() { return null; }
}
""",
    )

    assert len(result.api_endpoints) == 1
    endpoint = result.api_endpoints[0]
    assert endpoint.framework == "spring"
    assert endpoint.method == "GET"
    assert endpoint.path == "/api/orders/{id}"
    assert endpoint.handler_names == ["OrdersController.getOrder"]


def test_aspnet_routes_are_detected() -> None:
    result = _adapt(
        "csharp",
        """\
[ApiController]
[Route("api/[controller]")]
public class OrdersController : ControllerBase
{
    [HttpGet("{id}")]
    public IActionResult Get() => Ok();
}
""",
    )

    assert len(result.api_endpoints) == 1
    endpoint = result.api_endpoints[0]
    assert endpoint.framework == "asp.net"
    assert endpoint.method == "GET"
    assert endpoint.path == "/api/Orders/{id}"
    assert endpoint.handler_names == ["OrdersController.Get"]


def test_gin_routes_are_detected() -> None:
    result = _adapt(
        "go",
        """\
api := router.Group("/api")
api.GET("/orders/:id", getOrder)
""",
    )

    assert len(result.api_endpoints) == 1
    endpoint = result.api_endpoints[0]
    assert endpoint.framework == "gin"
    assert endpoint.method == "GET"
    assert endpoint.path == "/api/orders/:id"
    assert endpoint.handler_names == ["getOrder"]


def test_rails_routes_are_detected() -> None:
    result = _adapt(
        "ruby",
        """\
Rails.application.routes.draw do
  get "/login", to: "sessions#new"
  resources :orders
end
""",
    )

    paths = {(endpoint.method, endpoint.path) for endpoint in result.api_endpoints}
    assert ("GET", "/login") in paths
    assert ("GET", "/orders/:id") in paths


def test_laravel_routes_are_detected() -> None:
    result = _adapt(
        "php",
        """\
Route::get('/orders/{id}', [OrderController::class, 'show']);
""",
    )

    assert len(result.api_endpoints) == 1
    endpoint = result.api_endpoints[0]
    assert endpoint.framework == "laravel"
    assert endpoint.method == "GET"
    assert endpoint.path == "/orders/{id}"
    assert endpoint.handler_names == ["OrderController.show"]


def test_rust_routes_are_detected() -> None:
    result = _adapt(
        "rust",
        """\
#[get("/health")]
fn health() {}

let app = Router::new().route("/users/:id", get(show_user));
""",
    )

    paths = {(endpoint.framework, endpoint.method, endpoint.path, tuple(endpoint.handler_names)) for endpoint in result.api_endpoints}
    assert ("rocket", "GET", "/health", ("health",)) in paths
    assert ("axum", "GET", "/users/:id", ("show_user",)) in paths
