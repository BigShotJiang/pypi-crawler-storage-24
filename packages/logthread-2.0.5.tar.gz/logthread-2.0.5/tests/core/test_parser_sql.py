from __future__ import annotations

from logthread.core.parsers.sql_lang import SqlParser, extract_sql_lineage

SQL_FUNCTION = """\
CREATE OR REPLACE FUNCTION public.get_telemetry_data(
    p_organization_id uuid
)
RETURNS json
LANGUAGE plpgsql
AS $BODY$
DECLARE
  query_text text;
BEGIN
  query_text := 'SELECT id, event_type, organization_id FROM public.telemetry WHERE organization_id = $1';
  query_text := query_text || ' AND event_timestamp >= $2';
  RETURN query_text::json;
END;
$BODY$;
"""


class TestSqlParserFunctions:
    def test_parse_sql_function_creates_symbol_and_lineage(self) -> None:
        parser = SqlParser()

        result = parser.parse(SQL_FUNCTION, "db/functions.sql")

        assert [symbol.name for symbol in result.symbols] == ["get_telemetry_data"]
        assert result.symbols[0].signature.startswith("CREATE OR REPLACE FUNCTION public.get_telemetry_data(")

        assert len(result.sql_queries) == 1
        query = result.sql_queries[0]
        assert query.caller_name == "get_telemetry_data"
        assert "telemetry" in query.tables_referenced
        assert "telemetry.organization_id" in query.columns_referenced
        assert "telemetry.event_timestamp" in query.columns_referenced

    def test_parse_sql_function_keeps_create_table_parsing(self) -> None:
        parser = SqlParser()
        content = (
            SQL_FUNCTION
            + "\n"
            + "CREATE TABLE public.telemetry (\n"
            + "  id uuid primary key,\n"
            + "  organization_id uuid,\n"
            + "  event_timestamp timestamptz\n"
            + ");\n"
        )

        result = parser.parse(content, "db/schema.sql")

        assert len(result.db_tables) == 1
        assert result.db_tables[0].name == "telemetry"
        assert {column["name"] for column in result.db_tables[0].columns} == {
            "id",
            "organization_id",
            "event_timestamp",
        }

    def test_ignores_postgres_admin_and_procedural_statements_without_warning_noise(self, caplog) -> None:
        parser = SqlParser()
        content = (
            "GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA lightrag TO prolxpsa;\n"
            "DO $$\n"
            "BEGIN\n"
            "  IF EXISTS (\n"
            "    SELECT 1 FROM information_schema.columns WHERE table_schema = 'public'\n"
            "  ) THEN\n"
            "    RAISE NOTICE 'Migration complete';\n"
            "  END IF;\n"
            "END $$;\n"
        )

        with caplog.at_level("WARNING", logger="sqlglot"):
            result = parser.parse(content, "db/migration.sql")

        assert result.db_tables == []
        assert result.sql_queries == []
        assert extract_sql_lineage(content) == ([], [])
        assert "contains unsupported syntax" not in caplog.text
