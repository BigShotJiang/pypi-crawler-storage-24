from __future__ import annotations

from pathlib import Path

from logthread.core.intelligence.edit_contract import build_edit_contract_packet


def test_build_edit_contract_packet_uses_root_project_and_lockfile_truth(tmp_path: Path) -> None:
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "auth.ts").write_text(
        "import { db } from './db/connection';\n"
        "export function validateToken(user: User, token: string) {\n"
        "  const client = db();\n"
        "  const cachedUser = user;\n"
        "  return cachedUser;\n"
        "}\n",
        encoding="utf-8",
    )
    (tmp_path / "package.json").write_text(
        '{"name":"sample-app","dependencies":{"pg":"^8.11.0"}}',
        encoding="utf-8",
    )
    (tmp_path / "package-lock.json").write_text(
        '{"packages":{"":{"dependencies":{"pg":"^8.11.0"}},"node_modules/pg":{"version":"8.11.5"}}}',
        encoding="utf-8",
    )

    packet = build_edit_contract_packet(
        tmp_path,
        {
            "objective": "fix token validation",
            "anchor": {
                "id": "function:src/auth.ts:validateToken",
                "label": "function",
                "name": "validateToken",
                "filePath": "src/auth.ts",
                "startLine": 2,
                "endLine": 5,
                "signature": "validateToken(user: User, token: string)",
                "language": "typescript",
            },
            "confidence": {"tier": "T2", "score": 0.86},
            "exactTargets": [
                {
                    "id": "function:src/auth.ts:validateToken",
                    "label": "function",
                    "name": "validateToken",
                    "filePath": "src/auth.ts",
                    "startLine": 2,
                    "endLine": 5,
                    "signature": "validateToken(user: User, token: string)",
                    "language": "typescript",
                }
            ],
            "avoidSymbols": [],
            "existingDependencies": ["pg"],
            "affected": {"apis": [], "tables": [], "components": [], "tests": []},
            "unresolvedAmbiguities": [],
            "errors": [],
        },
    )

    assert packet["kind"] == "edit_contract"
    assert packet["scopedTargets"][0]["projectName"] == "sample-app"
    assert packet["scopedTargets"][0]["variables"][0]["name"] == "client"
    assert packet["dependencyTruth"]["relevantPackages"][0]["resolvedVersion"] == "8.11.5"
