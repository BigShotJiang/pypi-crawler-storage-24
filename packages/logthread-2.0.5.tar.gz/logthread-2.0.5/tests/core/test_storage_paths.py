from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

from logthread.core.storage.paths import get_all_projects


def test_get_all_projects_merges_registry_and_legacy_sources(tmp_path: Path) -> None:
    app_dir = tmp_path / ".logthread_test"
    repo_from_registry = tmp_path / "registry-repo"
    repo_from_legacy = tmp_path / "legacy-repo"
    repo_from_registry.mkdir()
    repo_from_legacy.mkdir()

    app_dir.mkdir(parents=True)
    (app_dir / "registry.json").write_text(
        json.dumps({
            "version": 1,
            "projects": [
                {
                    "id": "registry-id",
                    "name": "registry-repo",
                    "path": str(repo_from_registry),
                    "symbols": 10,
                    "files": 2,
                    "updated_at": "2026-03-26T12:00:00+00:00",
                }
            ],
        }),
        encoding="utf-8",
    )

    legacy_dir = tmp_path / ".logthread" / "repos" / "legacy-repo"
    legacy_dir.mkdir(parents=True)
    (legacy_dir / "meta.json").write_text(
        json.dumps({
            "name": "legacy-repo",
            "path": str(repo_from_legacy),
            "stats": {"symbols": 20, "files": 4},
            "last_indexed_at": "2026-03-26T13:00:00+00:00",
        }),
        encoding="utf-8",
    )

    with patch("logthread.core.storage.paths.get_app_data_dir", return_value=app_dir):
        with patch("logthread.core.storage.paths.Path.home", return_value=tmp_path):
            projects = get_all_projects()

    paths = {project["path"] for project in projects}
    assert str(repo_from_registry.resolve()) in paths
    assert str(repo_from_legacy.resolve()) in paths
    assert len(projects) == 2
