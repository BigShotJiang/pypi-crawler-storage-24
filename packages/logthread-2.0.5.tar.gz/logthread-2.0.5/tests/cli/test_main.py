from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from logthread import __version__
from logthread.cli.main import _register_in_global_registry, app

runner = CliRunner()


@pytest.fixture(autouse=True)
def suppress_update_notice(request, tmp_path):
    if request.node.get_closest_marker("allow_update_notice"):
        yield
        return
    with patch("logthread.cli.main._maybe_notify_update"):
        # Force all centralized storage to be local to the test's tmp_path
        # to avoid polluting the user's real Library/Application Support
        with patch("logthread.core.storage.paths.get_app_data_dir", return_value=tmp_path / ".logthread_test"):
            with patch("logthread.core.storage.paths.get_project_dir", side_effect=lambda p: p / ".logthread"):
                yield


@pytest.fixture(autouse=True)
def fake_runtime_secret_store(monkeypatch: "pytest.MonkeyPatch"):
    store: dict[tuple[str, str, str], dict] = {}

    def _store(repo_path: Path, namespace: str, item_id: str, payload: dict) -> None:
        store[(str(repo_path.resolve()), namespace, item_id)] = dict(payload)

    def _load(repo_path: Path, namespace: str, item_id: str) -> dict | None:
        payload = store.get((str(repo_path.resolve()), namespace, item_id))
        return dict(payload) if payload is not None else None

    def _delete(repo_path: Path, namespace: str, item_id: str) -> None:
        store.pop((str(repo_path.resolve()), namespace, item_id), None)

    monkeypatch.setattr("logthread.core.intelligence.runtime_logs.store_secret", _store)
    monkeypatch.setattr("logthread.core.intelligence.runtime_logs.load_secret", _load)
    monkeypatch.setattr("logthread.core.intelligence.runtime_logs.delete_secret", _delete)
    return store


class TestVersion:
    def test_version_long_flag(self) -> None:
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0


class TestUpdateNotifier:
    @pytest.mark.allow_update_notice
    def test_shows_update_notice_for_normal_command(self) -> None:
        with patch("logthread.cli.main._get_latest_version", return_value="9.9.9"):
            result = runner.invoke(app, ["list"])
        assert result.exit_code == 0
        assert "Update available" in result.output

    @pytest.mark.allow_update_notice
    def test_skips_update_notice_for_serve(self) -> None:
        with patch("logthread.cli.main._get_latest_version", return_value="9.9.9"):
            with patch("asyncio.run"):
                result = runner.invoke(app, ["serve"])
        assert result.exit_code == 0
        assert "Update available" not in result.output

    def test_version_short_flag(self) -> None:
        result = runner.invoke(app, ["-v"])
        assert result.exit_code == 0
        assert f"Log Thread v{__version__}" in result.output

    def test_version_exit_code(self) -> None:
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0


class TestHelp:
    def test_help_exit_code(self) -> None:
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0

    def test_help_shows_app_name(self) -> None:
        result = runner.invoke(app, ["--help"])
        assert "Log Thread" in result.output

    def test_help_lists_commands(self) -> None:
        result = runner.invoke(app, ["--help"])
        expected_commands = [
            "analyze",
            "capabilities",
            "edit-contract",
            "logs",
            "status",
            "list",
            "clean",
            "query",
            "context",
            "impact",
            "dead-code",
            "cypher",
            "setup",
            "watch",
            "diff",
            "mcp",
            "host",
        ]
        for cmd in expected_commands:
            assert cmd in result.output, f"Command '{cmd}' not found in --help output"


class TestStatus:
    def test_status_no_index(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["status"])
        assert result.exit_code == 1
        assert "No index found" in result.output

    def test_status_with_index(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        logthread_dir = tmp_path / ".logthread"
        logthread_dir.mkdir()
        meta = {
            "version": "0.1.0",
            "stats": {
                "files": 10,
                "symbols": 42,
                "relationships": 100,
                "clusters": 3,
                "flows": 0,
                "dead_code": 5,
                "coupled_pairs": 0,
            },
            "last_indexed_at": "2025-01-15T10:00:00+00:00",
        }
        (logthread_dir / "meta.json").write_text(json.dumps(meta), encoding="utf-8")

        result = runner.invoke(app, ["status"])
        assert result.exit_code == 0
        assert "Index status for" in result.output
        assert "0.1.0" in result.output
        assert "10" in result.output  # files
        assert "42" in result.output  # symbols
        assert "100" in result.output  # relationships

    def test_status_shows_language_and_framework_breakdown(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        logthread_dir = tmp_path / ".logthread"
        logthread_dir.mkdir()
        meta = {
            "version": "0.1.0",
            "stats": {
                "files": 10,
                "symbols": 42,
                "relationships": 100,
                "api_endpoints": 4,
                "db_tables": 2,
            },
            "languages": {
                "python": 6,
                "javascript": 4,
            },
            "api_frameworks": {
                "fastapi": 3,
                "express": 1,
            },
            "last_indexed_at": "2025-01-15T10:00:00+00:00",
        }
        (logthread_dir / "meta.json").write_text(json.dumps(meta), encoding="utf-8")

        result = runner.invoke(app, ["status"])
        assert result.exit_code == 0
        assert "Languages:" in result.output
        assert "python=6" in result.output
        assert "javascript=4" in result.output
        assert "API frameworks:" in result.output
        assert "fastapi=3" in result.output
        assert "express=1" in result.output


class TestCapabilities:
    def test_capabilities_command(self) -> None:
        result = runner.invoke(app, ["capabilities"])
        assert result.exit_code == 0
        assert "Native language support:" in result.output
        assert "python" in result.output
        assert "typescript" in result.output
        assert "Recommended external semantic engines:" in result.output
        assert "Pyright" in result.output
        assert "tsserver" in result.output


class TestTrustCommands:
    def test_confidence_report_with_storage(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        mock_storage = MagicMock()
        with patch("logthread.cli.main._load_storage", return_value=mock_storage):
            with patch("logthread.mcp.tools.handle_confidence_report", return_value="Confidence Report\n===="):
                with patch(
                    "logthread.mcp.tools.build_confidence_report_packet",
                    return_value={"kind": "confidence_report", "tierCounts": {"T2": 1}},
                ):
                    result = runner.invoke(app, ["confidence-report"])
        assert result.exit_code == 0
        assert "Confidence Report" in result.output
        assert "confidence_report" in result.output

    def test_change_risk_with_storage(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        mock_storage = MagicMock()
        diff_path = tmp_path / "sample.diff"
        diff_path.write_text(
            "diff --git a/src/app.py b/src/app.py\n"
            "--- a/src/app.py\n"
            "+++ b/src/app.py\n"
            "@@ -1,1 +1,1 @@\n"
            "-old\n"
            "+new\n",
            encoding="utf-8",
        )
        with patch("logthread.cli.main._load_storage", return_value=mock_storage):
            with patch("logthread.mcp.tools.handle_review_risk", return_value="PR Risk Assessment"):
                with patch(
                    "logthread.mcp.tools.build_change_risk_packet",
                    return_value={"kind": "change_risk", "risk": {"level": "LOW", "score": 10}},
                ):
                    result = runner.invoke(app, ["change-risk", "--diff-file", str(diff_path)])
        assert result.exit_code == 0
        assert "PR Risk Assessment" in result.output
        assert "change_risk" in result.output or "change-risk" in result.output

    def test_edit_contract_with_storage(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        mock_storage = MagicMock()
        with patch("logthread.cli.main._load_storage", return_value=mock_storage):
            with patch("logthread.mcp.tools.handle_agent_safe_edit_contract", return_value="Agent-Safe Edit Contract"):
                with patch(
                    "logthread.mcp.tools.build_agent_safe_edit_contract_packet",
                    return_value={"kind": "edit_contract", "summary": "ready"},
                ):
                    result = runner.invoke(app, ["edit-contract", "fix auth validation", "--symbol", "validate"])
        assert result.exit_code == 0
        assert "Agent-Safe Edit Contract" in result.output
        assert "edit_contract" in result.output or "edit-contract" in result.output


class TestRuntimeLogsCommands:
    def test_logs_help_lists_subcommands(self) -> None:
        result = runner.invoke(app, ["logs", "--help"])
        assert result.exit_code == 0
        assert "list-connectors" in result.output
        assert "connect" in result.output
        assert "query" in result.output

    def test_logs_connect_and_list(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(
            app,
            [
                "logs",
                "connect",
                "--name",
                "Prod Loki",
                "--provider",
                "loki",
                "--base-url",
                "https://loki.example.com",
                "--bearer-token",
                "secret-token",
                "--source",
                "prod",
            ],
        )
        assert result.exit_code == 0
        assert "Saved runtime connector" in result.output

        list_result = runner.invoke(app, ["logs", "list-connectors"])
        assert list_result.exit_code == 0
        assert "Prod Loki" in list_result.output
        assert "https://loki.example.com" in list_result.output

    def test_logs_query_outputs_runtime_packet(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        with patch("logthread.cli.main._load_storage", return_value=MagicMock()) as mock_loader:
            mock_loader.return_value.load_graph.return_value = MagicMock()
            with patch(
                "logthread.cli.main.query_runtime_logs",
                return_value={
                    "connector": {"name": "Prod Loki"},
                    "stats": {"events": 3, "patterns": 1, "sequences": 1},
                    "answers": [{"title": "Top repeating failure pattern", "body": "boom", "evidence": ["3 events"]}],
                },
            ):
                result = runner.invoke(app, ["logs", "query", "connector-1", "error", "--hours", "2"])
        assert result.exit_code == 0
        assert "Runtime analysis for" in result.output
        assert "Top repeating failure pattern" in result.output


class TestListRepos:
    def test_list_calls_handle_list_repos(self) -> None:
        with patch(
            "logthread.mcp.tools.handle_list_repos",
            return_value="Indexed repositories (1):\n\n  1. my-project",
        ):
            result = runner.invoke(app, ["list"])
        assert result.exit_code == 0
        assert "my-project" in result.output

    def test_list_no_repos(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        with patch(
            "logthread.mcp.tools.handle_list_repos",
            return_value="No indexed repositories found.",
        ):
            result = runner.invoke(app, ["list"])
        assert result.exit_code == 0
        assert "No indexed repositories found" in result.output


class TestClean:
    def test_clean_no_index(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["clean", "--force"])
        assert result.exit_code == 1
        assert "No index found" in result.output

    def test_clean_with_force(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        logthread_dir = tmp_path / ".logthread"
        logthread_dir.mkdir()
        (logthread_dir / "meta.json").write_text("{}", encoding="utf-8")

        result = runner.invoke(app, ["clean", "--force"])
        assert result.exit_code == 0
        assert "Deleted" in result.output
        assert not logthread_dir.exists()

    def test_clean_aborted(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        logthread_dir = tmp_path / ".logthread"
        logthread_dir.mkdir()
        (logthread_dir / "meta.json").write_text("{}", encoding="utf-8")

        result = runner.invoke(app, ["clean"], input="n\n")
        assert result.exit_code == 0
        assert logthread_dir.exists()  # Not deleted


class TestQuery:
    def test_query_no_index(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["query", "find classes"])
        assert result.exit_code == 1
        assert "No index found" in result.output

    def test_query_with_storage(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        mock_storage = MagicMock()
        with patch("logthread.cli.main._load_storage", return_value=mock_storage):
            with patch(
                "logthread.mcp.tools.handle_query",
                return_value="1. MyClass (Class) -- src/main.py",
            ):
                result = runner.invoke(app, ["query", "find classes"])
        assert result.exit_code == 0
        assert "MyClass" in result.output


class TestContext:
    def test_context_no_index(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["context", "MyClass"])
        assert result.exit_code == 1
        assert "No index found" in result.output

    def test_context_with_storage(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        mock_storage = MagicMock()
        with patch("logthread.cli.main._load_storage", return_value=mock_storage):
            with patch(
                "logthread.mcp.tools.handle_context",
                return_value="Symbol: MyClass (Class)\nFile: src/main.py:1-50",
            ):
                result = runner.invoke(app, ["context", "MyClass"])
        assert result.exit_code == 0
        assert "MyClass" in result.output


class TestImpact:
    def test_impact_no_index(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["impact", "MyClass.method"])
        assert result.exit_code == 1
        assert "No index found" in result.output

    def test_impact_with_storage(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        mock_storage = MagicMock()
        with patch("logthread.cli.main._load_storage", return_value=mock_storage):
            with patch(
                "logthread.mcp.tools.handle_impact",
                return_value="Impact analysis for: MyClass.method",
            ):
                result = runner.invoke(app, ["impact", "MyClass.method", "--depth", "5"])
        assert result.exit_code == 0
        assert "Impact analysis" in result.output

    def test_impact_default_depth(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        mock_storage = MagicMock()
        with patch("logthread.cli.main._load_storage", return_value=mock_storage):
            with patch(
                "logthread.mcp.tools.handle_impact",
                return_value="Impact analysis for: foo",
            ):
                result = runner.invoke(app, ["impact", "foo"])
        assert result.exit_code == 0


class TestDeadCode:
    def test_dead_code_no_index(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["dead-code"])
        assert result.exit_code == 1
        assert "No index found" in result.output

    def test_dead_code_with_storage(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        mock_storage = MagicMock()
        with patch("logthread.cli.main._load_storage", return_value=mock_storage):
            with patch(
                "logthread.mcp.tools.handle_dead_code",
                return_value="No dead code detected.",
            ):
                result = runner.invoke(app, ["dead-code"])
        assert result.exit_code == 0
        assert "No dead code detected" in result.output


class TestCypher:
    def test_cypher_no_index(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["cypher", "MATCH (n) RETURN n"])
        assert result.exit_code == 1
        assert "No index found" in result.output

    def test_cypher_with_storage(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        mock_storage = MagicMock()
        with patch("logthread.cli.main._load_storage", return_value=mock_storage):
            with patch(
                "logthread.mcp.tools.handle_cypher",
                return_value="Results (3 rows):\n\n  1. foo",
            ):
                result = runner.invoke(app, ["cypher", "MATCH (n) RETURN n"])
        assert result.exit_code == 0
        assert "Results" in result.output


class TestSetup:
    def test_setup_no_flags_shows_both(self) -> None:
        result = runner.invoke(app, ["setup"])
        assert result.exit_code == 0
        assert "Claude Code" in result.output
        assert "Cursor" in result.output
        assert '"logthread"' in result.output
        assert '"serve"' in result.output

    def test_setup_claude_only(self) -> None:
        result = runner.invoke(app, ["setup", "--claude"])
        assert result.exit_code == 0
        assert "Claude Code" in result.output
        assert "Cursor" not in result.output

    def test_setup_cursor_only(self) -> None:
        result = runner.invoke(app, ["setup", "--cursor"])
        assert result.exit_code == 0
        assert "Cursor" in result.output
        assert "Claude Code" not in result.output

    def test_setup_both_flags(self) -> None:
        result = runner.invoke(app, ["setup", "--claude", "--cursor"])
        assert result.exit_code == 0
        assert "Claude Code" in result.output
        assert "Cursor" in result.output


class TestMcp:
    def test_mcp_command_exists(self) -> None:
        result = runner.invoke(app, ["mcp", "--help"])
        assert result.exit_code == 0
        assert "MCP server" in result.output or "stdio" in result.output.lower()

    def test_mcp_calls_server_main(self) -> None:
        import asyncio as real_asyncio

        with patch.object(real_asyncio, "run") as mock_run:
            result = runner.invoke(app, ["mcp"])
        assert result.exit_code == 0
        mock_run.assert_called_once()


class TestServe:
    def test_serve_command_exists(self) -> None:
        result = runner.invoke(app, ["serve", "--help"])
        assert result.exit_code == 0
        assert "watch" in result.output.lower()

    def test_serve_without_watch_delegates_to_mcp(self) -> None:
        import asyncio as real_asyncio

        with patch.object(real_asyncio, "run") as mock_run:
            result = runner.invoke(app, ["serve"])
        assert result.exit_code == 0
        mock_run.assert_called_once()

    def test_serve_with_watch_proxies_to_host(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        import asyncio as real_asyncio

        monkeypatch.chdir(tmp_path)
        with patch(
            "logthread.cli.main._ensure_host_running",
            return_value={"host_url": "http://127.0.0.1:8420", "mcp_url": "http://127.0.0.1:8420/mcp"},
        ) as mock_ensure:
            with patch.object(real_asyncio, "run") as mock_run:
                result = runner.invoke(app, ["serve", "--watch"])
        assert result.exit_code == 0
        mock_ensure.assert_called_once()
        mock_run.assert_called_once()


class TestHost:
    def test_host_command_exists(self) -> None:
        result = runner.invoke(app, ["host", "--help"])
        assert result.exit_code == 0
        assert "HTTP MCP" in result.output or "shared" in result.output.lower()


class TestUi:
    def test_ui_attaches_to_running_host(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        with patch(
            "logthread.cli.main._get_live_host_info",
            return_value={"host_url": "http://127.0.0.1:8420", "mcp_url": "http://127.0.0.1:8420/mcp"},
        ):
            with patch("webbrowser.open") as mock_open:
                result = runner.invoke(app, ["ui"])
        assert result.exit_code == 0
        assert "http://127.0.0.1:8420" in result.output
        mock_open.assert_called_once_with("http://127.0.0.1:8420")

    def test_ui_direct_skips_host_attach(self, tmp_path: Path, monkeypatch: "pytest.MonkeyPatch") -> None:
        monkeypatch.chdir(tmp_path)
        # Don't create the database directory itself, only the parent project dir
        (tmp_path / ".logthread").mkdir(parents=True, exist_ok=True)
        with patch("logthread.cli.main._get_live_host_info") as mock_host_info:
            with patch("logthread.cli.main._run_shared_host") as mock_run_shared:
                result = runner.invoke(app, ["ui", "--direct", "--no-open"])
        assert result.exit_code == 0
        mock_host_info.assert_not_called()
        mock_run_shared.assert_called_once()


class TestWatch:
    def test_watch_command_exists(self) -> None:
        result = runner.invoke(app, ["watch", "--help"])
        assert result.exit_code == 0
        assert "Watch mode" in result.output or "re-index" in result.output.lower()

    def test_diff_command_exists(self) -> None:
        result = runner.invoke(app, ["diff", "--help"])
        assert result.exit_code == 0
        assert "branch" in result.output.lower()


class TestGenerate:
    def test_generate_accepts_custom_project_name(self, tmp_path: Path) -> None:
        repo_path = tmp_path / "backend"
        repo_path.mkdir()
        (repo_path / ".logthread" / "ladybug").mkdir(parents=True)
        (repo_path / "app.py").write_text("print('hello')\n", encoding="utf-8")

        storage = MagicMock()
        pipeline_result = MagicMock()
        pipeline_result.files = 1
        pipeline_result.symbols = 2
        pipeline_result.relationships = 3
        pipeline_result.clusters = 0
        pipeline_result.processes = 0
        pipeline_result.dead_code = 0
        pipeline_result.coupled_pairs = 0
        pipeline_result.embeddings = 0
        pipeline_result.api_endpoints = 0
        pipeline_result.db_tables = 0
        pipeline_result.language_counts = {}
        pipeline_result.api_frameworks = {}
        pipeline_result.semantic_summary = {}
        pipeline_result.duration_seconds = 0.5

        with patch("logthread.cli.main.LadybugBackend", return_value=storage):
            with patch("logthread.cli.main.run_pipeline", return_value=(MagicMock(), pipeline_result)):
                with patch("logthread.config.ignore.load_gitignore", return_value=None):
                    with patch("logthread.core.ingestion.walker.walk_repo", return_value=[]):
                        with patch("logthread.cli.main.cleanup_legacy_files"):
                            with patch("logthread.cli.main.Path.home", return_value=tmp_path):
                                result = runner.invoke(
                                    app,
                                    ["generate", str(repo_path), "--full", "--name", "Meeting Agent Backend"],
                                )

        assert result.exit_code == 0
        meta = json.loads((repo_path / ".logthread" / "meta.json").read_text(encoding="utf-8"))
        assert meta["name"] == "Meeting Agent Backend"

        registry = json.loads((tmp_path / ".logthread_test" / "registry.json").read_text(encoding="utf-8"))
        assert registry["projects"][0]["name"] == "Meeting Agent Backend"


# Multi-repo registry


class TestRegisterInGlobalRegistry:
    def test_first_registration(self, tmp_path: Path) -> None:
        repo_path = tmp_path / "my-project"
        repo_path.mkdir()

        meta = {"name": "my-project", "path": str(repo_path), "stats": {}}

        with patch("logthread.cli.main.Path.home", return_value=tmp_path):
            # _register_in_global_registry uses Path.home() / ".logthread" / "repos"
            _register_in_global_registry(meta, repo_path)

        slot = tmp_path / ".logthread" / "repos" / "my-project"
        assert slot.exists()
        written = json.loads((slot / "meta.json").read_text())
        assert written["name"] == "my-project"
        assert written["slug"] == "my-project"
        assert written["path"] == str(repo_path)

    def test_same_repo_re_registered(self, tmp_path: Path) -> None:
        repo_path = tmp_path / "my-project"
        repo_path.mkdir()
        meta = {"name": "my-project", "path": str(repo_path), "stats": {}}

        with patch("logthread.cli.main.Path.home", return_value=tmp_path):
            _register_in_global_registry(meta, repo_path)
            _register_in_global_registry(meta, repo_path)

        # Only one directory should exist
        registry = tmp_path / ".logthread" / "repos"
        entries = list(registry.iterdir())
        assert len(entries) == 1
        assert entries[0].name == "my-project"

    def test_name_collision_different_repos(self, tmp_path: Path) -> None:
        repo_a = tmp_path / "workspace-a" / "myapp"
        repo_b = tmp_path / "workspace-b" / "myapp"
        repo_a.mkdir(parents=True)
        repo_b.mkdir(parents=True)

        meta_a = {"name": "myapp", "path": str(repo_a), "stats": {}}
        meta_b = {"name": "myapp", "path": str(repo_b), "stats": {}}

        with patch("logthread.cli.main.Path.home", return_value=tmp_path):
            _register_in_global_registry(meta_a, repo_a)
            _register_in_global_registry(meta_b, repo_b)

        registry = tmp_path / ".logthread" / "repos"
        entries = sorted([e.name for e in registry.iterdir()])
        assert len(entries) == 2
        # One should be "myapp", the other "myapp-<hash>"
        assert entries[0] == "myapp"
        assert entries[1].startswith("myapp-")

    def test_stale_entry_cleanup(self, tmp_path: Path) -> None:
        repo_path = tmp_path / "myapp"
        repo_path.mkdir()

        # Manually create a stale entry under a hash slug
        registry = tmp_path / ".logthread" / "repos"
        stale = registry / "myapp-abcd1234"
        stale.mkdir(parents=True)
        stale_meta = {"name": "myapp", "path": str(repo_path)}
        (stale / "meta.json").write_text(json.dumps(stale_meta))

        meta = {"name": "myapp", "path": str(repo_path), "stats": {}}
        with patch("logthread.cli.main.Path.home", return_value=tmp_path):
            _register_in_global_registry(meta, repo_path)

        # Stale entry should be cleaned up
        assert not stale.exists()
        # New entry under bare name should exist
        assert (registry / "myapp" / "meta.json").exists()

    def test_corrupt_existing_meta_json(self, tmp_path: Path) -> None:
        registry = tmp_path / ".logthread" / "repos" / "myapp"
        registry.mkdir(parents=True)
        (registry / "meta.json").write_text("not valid json!")

        repo_path = tmp_path / "myapp"
        repo_path.mkdir()
        meta = {"name": "myapp", "path": str(repo_path), "stats": {}}

        with patch("logthread.cli.main.Path.home", return_value=tmp_path):
            _register_in_global_registry(meta, repo_path)

        # Should claim the slot (no crash)
        written = json.loads((registry / "meta.json").read_text())
        assert written["path"] == str(repo_path)

    def test_registry_dir_created_if_missing(self, tmp_path: Path) -> None:
        repo_path = tmp_path / "myapp"
        repo_path.mkdir()
        meta = {"name": "myapp", "path": str(repo_path), "stats": {}}

        # Ensure no .logthread dir exists
        assert not (tmp_path / ".logthread").exists()

        with patch("logthread.cli.main.Path.home", return_value=tmp_path):
            _register_in_global_registry(meta, repo_path)

        assert (tmp_path / ".logthread" / "repos" / "myapp" / "meta.json").exists()
