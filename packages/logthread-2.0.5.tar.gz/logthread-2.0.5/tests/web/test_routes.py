from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from logthread.core.graph.graph import KnowledgeGraph
from logthread.core.graph.model import (
    GraphNode,
    GraphRelationship,
    NodeLabel,
    RelType,
)


@pytest.fixture(autouse=True)
def fake_runtime_secret_store(monkeypatch: pytest.MonkeyPatch):
    store: dict[tuple[str, str, str], dict] = {}

    def _store(repo_path: Path, namespace: str, item_id: str, payload: dict) -> None:
        store[(str(repo_path.resolve()), namespace, item_id)] = dict(payload)

    def _load(repo_path: Path, namespace: str, item_id: str) -> dict | None:
        payload = store.get((str(repo_path.resolve()), namespace, item_id))
        return dict(payload) if payload is not None else None

    def _delete(repo_path: Path, namespace: str, item_id: str) -> None:
        store.pop((str(repo_path.resolve()), namespace, item_id), None)

    monkeypatch.setattr("logthread.core.intelligence.runtime_logs.store_secret", _store)
    monkeypatch.setattr("logthread.core.intelligence.runtime_logs.load_secret", _load)
    monkeypatch.setattr("logthread.core.intelligence.runtime_logs.delete_secret", _delete)
    return store


def _make_app(
    storage: MagicMock,
    repo_path: Path | None = None,
    watch: bool = False,
) -> FastAPI:
    """Build a FastAPI app with a mocked storage backend.

    Instead of calling ``create_app`` (which needs a real Ladybug path),
    this replicates the app assembly from ``app.py`` but injects a mock
    storage directly.
    """
    from logthread.web.routes.analysis import router as analysis_router
    from logthread.web.routes.cypher import router as cypher_router
    from logthread.web.routes.dependencies import router as dependencies_router
    from logthread.web.routes.diff import router as diff_router
    from logthread.web.routes.events import router as events_router
    from logthread.web.routes.files import router as files_router
    from logthread.web.routes.graph import router as graph_router
    from logthread.web.routes.host import router as host_router
    from logthread.web.routes.platform import router as platform_router
    from logthread.web.routes.processes import router as processes_router
    from logthread.web.routes.projects import router as projects_router
    from logthread.web.routes.runtime import router as runtime_router
    from logthread.web.routes.search import router as search_router
    from logthread.web.routes.traces import router as traces_router

    app = FastAPI()
    app.state.storage = storage
    app.state.repo_path = repo_path
    app.state.event_listeners = None
    app.state.watch = watch
    app.state.host_url = "http://127.0.0.1:8420"
    app.state.mcp_url = "http://127.0.0.1:8420/mcp"
    app.state.mode = "host" if watch else "standalone"

    app.include_router(graph_router)
    app.include_router(host_router)
    app.include_router(search_router)
    app.include_router(analysis_router)
    app.include_router(files_router)
    app.include_router(cypher_router)
    app.include_router(dependencies_router)
    app.include_router(diff_router)
    app.include_router(processes_router)
    app.include_router(events_router)
    app.include_router(platform_router)
    app.include_router(projects_router)
    app.include_router(runtime_router)
    app.include_router(traces_router)

    return app


def _sample_node(
    node_id: str = "function:src/app.py:main",
    label: NodeLabel = NodeLabel.FUNCTION,
    name: str = "main",
    file_path: str = "src/app.py",
    start_line: int = 1,
    end_line: int = 20,
    **kwargs,
) -> GraphNode:
    return GraphNode(
        id=node_id,
        label=label,
        name=name,
        file_path=file_path,
        start_line=start_line,
        end_line=end_line,
        **kwargs,
    )


def _sample_edge(
    edge_id: str = "calls:main->helper",
    rel_type: RelType = RelType.CALLS,
    source: str = "function:src/app.py:main",
    target: str = "function:src/utils.py:helper",
    **props,
) -> GraphRelationship:
    return GraphRelationship(
        id=edge_id,
        type=rel_type,
        source=source,
        target=target,
        properties=props,
    )


@pytest.fixture
def mock_storage() -> MagicMock:
    """Create a MagicMock that mimics StorageBackend with sane defaults."""
    storage = MagicMock()

    # Default: empty graph
    graph = KnowledgeGraph()
    storage.load_graph.return_value = graph

    # Default: node lookup returns None (tests override as needed)
    storage.get_node.return_value = None
    storage.get_callers_with_confidence.return_value = []
    storage.get_callees_with_confidence.return_value = []
    storage.get_type_refs.return_value = []
    storage.get_process_memberships.return_value = {}
    storage.traverse_with_depth.return_value = []
    storage.execute_raw.return_value = []

    return storage


@pytest.fixture
def client(mock_storage: MagicMock) -> TestClient:
    """Create a TestClient with mocked storage and no repo_path."""
    app = _make_app(mock_storage)
    return TestClient(app)


@pytest.fixture
def client_with_repo(mock_storage: MagicMock, tmp_path: Path) -> TestClient:
    """Create a TestClient with mocked storage and a real repo_path."""
    app = _make_app(mock_storage, repo_path=tmp_path, watch=True)
    return TestClient(app)


class TestGraphEndpoint:
    def test_empty_graph(self, client: TestClient) -> None:
        response = client.get("/graph")
        assert response.status_code == 200
        data = response.json()
        assert "nodes" in data
        assert "edges" in data
        assert data["nodes"] == []
        assert data["edges"] == []

    def test_graph_with_nodes_and_edges(
        self, mock_storage: MagicMock, client: TestClient
    ) -> None:
        node = _sample_node()
        edge = _sample_edge(confidence=0.9)
        graph = KnowledgeGraph()
        graph.add_node(node)
        graph.add_node(
            _sample_node(
                node_id="function:src/utils.py:helper",
                name="helper",
                file_path="src/utils.py",
            )
        )
        graph.add_relationship(edge)
        mock_storage.load_graph.return_value = graph

        response = client.get("/graph")
        assert response.status_code == 200
        data = response.json()
        assert len(data["nodes"]) == 2
        assert len(data["edges"]) == 1
        assert data["total"] == 2  # total node count

        # Verify node serialization shape (camelCase)
        n = data["nodes"][0]
        assert "id" in n
        assert "label" in n
        assert "name" in n
        assert "filePath" in n
        assert "startLine" in n
        assert "endLine" in n
        assert "isDead" in n
        assert "isEntryPoint" in n
        assert "isExported" in n

        # Verify edge serialization shape
        e = data["edges"][0]
        assert "id" in e
        assert "type" in e
        assert "source" in e
        assert "target" in e
        assert "confidence" in e

    def test_graph_load_failure(
        self, mock_storage: MagicMock, client: TestClient
    ) -> None:
        mock_storage.load_graph.side_effect = RuntimeError("DB error")
        response = client.get("/graph")
        assert response.status_code == 500


class TestOverviewEndpoint:
    def test_empty_overview(self, client: TestClient) -> None:
        response = client.get("/overview")
        assert response.status_code == 200
        data = response.json()
        assert "nodesByLabel" in data
        assert "edgesByType" in data
        assert "totalNodes" in data
        assert "totalEdges" in data
        assert data["totalNodes"] == 0
        assert data["totalEdges"] == 0

    def test_overview_with_data(
        self, mock_storage: MagicMock, client: TestClient
    ) -> None:
        # First call: node counts, second call: edge counts
        mock_storage.execute_raw.side_effect = [
            [["Function", 42], ["Class", 10]],
            [["calls", 100], ["imports", 30]],
        ]

        response = client.get("/overview")
        assert response.status_code == 200
        data = response.json()
        assert data["totalNodes"] == 52
        assert data["totalEdges"] == 130


class TestTraceEndpoints:
    def test_trace_catalog_lists_api_and_entry_surfaces(
        self,
        mock_storage: MagicMock,
        tmp_path: Path,
    ) -> None:
        graph = KnowledgeGraph()
        file_node = _sample_node(
            node_id="file:src/api/orders.ts:",
            label=NodeLabel.FILE,
            name="orders.ts",
            file_path="src/api/orders.ts",
        )
        endpoint = _sample_node(
            node_id="api_endpoint:src/api/orders.ts:GET:/orders",
            label=NodeLabel.API_ENDPOINT,
            name="GET:/orders",
            file_path="src/api/orders.ts",
            properties={"http_method": "GET", "path": "/orders", "framework": "express"},
        )
        handler = _sample_node(
            node_id="function:src/api/orders.ts:listOrders",
            name="listOrders",
            file_path="src/api/orders.ts",
            is_entry_point=True,
            language="typescript",
        )
        graph.add_node(file_node)
        graph.add_node(endpoint)
        graph.add_node(handler)
        graph.add_relationship(
            GraphRelationship(
                id="defines:file->endpoint",
                type=RelType.DEFINES,
                source=file_node.id,
                target=endpoint.id,
            )
        )
        graph.add_relationship(
            GraphRelationship(
                id="handles:handler->endpoint",
                type=RelType.HANDLES_ROUTE,
                source=handler.id,
                target=endpoint.id,
            )
        )
        mock_storage.load_graph.return_value = graph

        client = TestClient(_make_app(mock_storage, repo_path=tmp_path))
        response = client.get("/traces/catalog")

        assert response.status_code == 200
        entries = response.json()["entries"]
        assert any(entry["kind"] == "api" and entry["rootNodeId"] == endpoint.id for entry in entries)
        assert any(entry["rootNodeId"] == handler.id for entry in entries)

    def test_trace_packet_returns_focused_request_path(
        self,
        mock_storage: MagicMock,
        tmp_path: Path,
    ) -> None:
        graph = KnowledgeGraph()
        file_node = _sample_node(
            node_id="file:src/api/orders.ts:",
            label=NodeLabel.FILE,
            name="orders.ts",
            file_path="src/api/orders.ts",
        )
        endpoint = _sample_node(
            node_id="api_endpoint:src/api/orders.ts:GET:/orders",
            label=NodeLabel.API_ENDPOINT,
            name="GET:/orders",
            file_path="src/api/orders.ts",
            properties={"http_method": "GET", "path": "/orders", "framework": "express"},
        )
        handler = _sample_node(
            node_id="function:src/api/orders.ts:listOrders",
            name="listOrders",
            file_path="src/api/orders.ts",
            language="typescript",
        )
        query_fn = _sample_node(
            node_id="function:src/data/orders.ts:fetchOrders",
            name="fetchOrders",
            file_path="src/data/orders.ts",
            language="typescript",
        )
        data_file = _sample_node(
            node_id="file:src/data/orders.ts:",
            label=NodeLabel.FILE,
            name="orders.ts",
            file_path="src/data/orders.ts",
        )
        dep = _sample_node(
            node_id="external_dep:npm:pg",
            label=NodeLabel.EXTERNAL_DEP,
            name="pg",
            language="npm",
        )
        table = _sample_node(
            node_id="db_table:db/schema.sql:orders",
            label=NodeLabel.DB_TABLE,
            name="orders",
            file_path="db/schema.sql",
        )
        column = _sample_node(
            node_id="db_column:db/schema.sql:orders.id",
            label=NodeLabel.DB_COLUMN,
            name="id",
            file_path="db/schema.sql",
            properties={"table": "orders"},
        )

        for node in (file_node, endpoint, handler, query_fn, data_file, dep, table, column):
            graph.add_node(node)

        graph.add_relationship(GraphRelationship(id="defines:file->endpoint", type=RelType.DEFINES, source=file_node.id, target=endpoint.id))
        graph.add_relationship(GraphRelationship(id="defines:file->handler", type=RelType.DEFINES, source=file_node.id, target=handler.id))
        graph.add_relationship(GraphRelationship(id="defines:datafile->query", type=RelType.DEFINES, source=data_file.id, target=query_fn.id))
        graph.add_relationship(GraphRelationship(id="handles:handler->endpoint", type=RelType.HANDLES_ROUTE, source=handler.id, target=endpoint.id))
        graph.add_relationship(GraphRelationship(id="calls:handler->query", type=RelType.CALLS, source=handler.id, target=query_fn.id))
        graph.add_relationship(GraphRelationship(id="queries:query->table", type=RelType.QUERIES_TABLE, source=query_fn.id, target=table.id))
        graph.add_relationship(GraphRelationship(id="querycol:query->column", type=RelType.QUERIES_COLUMN, source=query_fn.id, target=column.id))
        graph.add_relationship(GraphRelationship(id="hascol:table->column", type=RelType.HAS_COLUMN, source=table.id, target=column.id))
        graph.add_relationship(GraphRelationship(id="depends:file->dep", type=RelType.DEPENDS_ON, source=file_node.id, target=dep.id))

        mock_storage.load_graph.return_value = graph

        client = TestClient(_make_app(mock_storage, repo_path=tmp_path))
        response = client.get(f"/traces/{endpoint.id}", params={"lens": "data", "max_depth": 5})

        assert response.status_code == 200
        payload = response.json()
        assert payload["title"] == "GET /orders"
        assert payload["stats"]["calls"] == 1
        assert payload["stats"]["dataAccess"] >= 2
        node_labels = {node["id"]: node["label"] for node in payload["nodes"]}
        assert handler.id in node_labels
        assert query_fn.id in node_labels
        assert table.id in node_labels
        assert column.id in node_labels
        assert dep.id in node_labels


class TestRuntimeEndpoints:
    def test_runtime_connector_crud_and_query(
        self,
        mock_storage: MagicMock,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        graph = KnowledgeGraph()
        graph.add_node(
            _sample_node(
                node_id="api_endpoint:src/api/orders.ts:GET:/orders",
                label=NodeLabel.API_ENDPOINT,
                name="GET:/orders",
                file_path="src/api/orders.ts",
                properties={"path": "/orders"},
            )
        )
        graph.add_node(
            _sample_node(
                node_id="file:src/api/orders.ts:",
                label=NodeLabel.FILE,
                name="orders.ts",
                file_path="src/api/orders.ts",
            )
        )
        graph.add_node(
            _sample_node(
                node_id="db_table:db/schema.sql:orders",
                label=NodeLabel.DB_TABLE,
                name="orders",
                file_path="db/schema.sql",
            )
        )
        mock_storage.load_graph.return_value = graph

        monkeypatch.setattr(
            "logthread.core.intelligence.runtime_logs._fetch_provider_logs",
            lambda *_args, **_kwargs: [
                {
                    "timestamp": "1711711711000000000",
                    "line": 'level=error msg="order query failed for user 42" trace_id=abc-123 route=/orders code.filepath=src/api/orders.ts sql="select * from orders"',
                    "labels": {"service": "orders-api"},
                }
            ],
        )

        client = TestClient(_make_app(mock_storage, repo_path=tmp_path, watch=True))

        save_response = client.post(
            "/runtime/connectors",
            json={
                "name": "Prod Loki",
                "provider": "loki",
                "base_url": "https://loki.example.com",
                "credentials": {"bearer_token": "secret-token"},
                "correlation_hints": ["workflow_id"],
                "default_source": "prod",
                "verify_tls": True,
            },
        )
        assert save_response.status_code == 200
        connector_id = save_response.json()["connector"]["id"]
        assert save_response.json()["connector"]["correlationHints"] == ["workflow_id"]

        list_response = client.get("/runtime/connectors")
        assert list_response.status_code == 200
        assert list_response.json()["connectors"][0]["name"] == "Prod Loki"
        assert list_response.json()["connectors"][0]["correlationHints"] == ["workflow_id"]

        query_response = client.post(
            "/runtime/query",
            json={
                "connectorId": connector_id,
                "query": '{service="orders-api"} |= "error"',
                "hours": 2,
                "limit": 20,
            },
        )
        assert query_response.status_code == 200
        packet = query_response.json()["packet"]
        assert packet["stats"]["events"] == 1
        assert packet["patterns"][0]["related"]["apis"][0]["name"] == "GET:/orders"
        assert packet["patterns"][0]["related"]["tables"][0]["name"] == "orders"
        assert packet["sequences"][0]["linkageMode"] == "explicit"
        assert packet["events"][0]["linkReason"]

        latest_response = client.get("/runtime/latest")
        assert latest_response.status_code == 200
        assert latest_response.json()["packet"]["stats"]["events"] == 1


class TestPlatformRoutes:
    def test_capabilities_route(self, client: TestClient) -> None:
        response = client.get("/platform/capabilities")
        assert response.status_code == 200
        data = response.json()
        assert "report" in data
        assert "packet" in data
        assert data["packet"]["kind"] == "language_capabilities"

    def test_confidence_report_route(self, mock_storage: MagicMock, client: TestClient) -> None:
        graph = KnowledgeGraph()
        graph.add_node(
            _sample_node(
                language="python",
                properties={"capability_tier": "T2", "confidence_score": 0.82},
            )
        )
        mock_storage.load_graph.return_value = graph
        response = client.get("/platform/confidence-report")
        assert response.status_code == 200
        data = response.json()
        assert data["packet"]["kind"] == "confidence_report"
        assert data["packet"]["tierCounts"]["T2"] == 1

    def test_context_packet_route(self, mock_storage: MagicMock, client: TestClient) -> None:
        mock_storage.get_node.return_value = _sample_node(
            node_id="function:src/app.py:validate",
            name="validate",
            language="python",
            properties={"capability_tier": "T2", "confidence_score": 0.82},
        )
        response = client.get("/platform/context/validate")
        assert response.status_code == 200
        data = response.json()
        assert data["packet"]["kind"] == "symbol_context"
        assert data["packet"]["target"]["name"] == "validate"

    def test_implementation_brief_route(self, mock_storage: MagicMock, client: TestClient) -> None:
        with patch("logthread.web.routes.platform.mcp_tools.handle_implementation_brief", return_value="Implementation Brief"):
            with patch(
                "logthread.web.routes.platform.mcp_tools.build_implementation_brief_packet",
                return_value={"kind": "implementation_brief", "summary": "ready"},
            ):
                response = client.post(
                    "/platform/implementation-brief",
                    json={"query": "fix auth validation", "symbol": "validate"},
                )
        assert response.status_code == 200
        data = response.json()
        assert data["brief"] == "Implementation Brief"
        assert data["packet"]["kind"] == "implementation_brief"

    def test_edit_contract_route(self, mock_storage: MagicMock, tmp_path: Path) -> None:
        app = _make_app(mock_storage, repo_path=tmp_path)
        client = TestClient(app)
        with patch("logthread.web.routes.platform.mcp_tools.handle_agent_safe_edit_contract", return_value="Agent-Safe Edit Contract"):
            with patch(
                "logthread.web.routes.platform.mcp_tools.build_agent_safe_edit_contract_packet",
                return_value={"kind": "edit_contract", "summary": "ready", "dependencyTruth": {"projects": [], "relevantPackages": [], "missingLockfiles": []}, "crossProjectImpact": {"ownerProjects": [], "impactedProjects": []}, "safeEditChecklist": [], "unresolvedAmbiguities": [], "errors": []},
            ):
                response = client.post(
                    "/platform/edit-contract",
                    json={"query": "fix auth validation", "symbol": "validate"},
                )
        assert response.status_code == 200
        data = response.json()
        assert data["contract"] == "Agent-Safe Edit Contract"
        assert data["packet"]["kind"] == "edit_contract"

    def test_workspace_map_route(self, mock_storage: MagicMock, tmp_path: Path) -> None:
        app = _make_app(mock_storage, repo_path=tmp_path)
        client = TestClient(app)
        with patch("logthread.web.routes.platform.mcp_tools.handle_workspace_map", return_value="Workspace Map"):
            with patch(
                "logthread.web.routes.platform.mcp_tools.build_workspace_map",
                return_value={"kind": "workspace_map", "projects": [], "references": [], "workspaceManagers": [], "unresolvedAmbiguities": []},
            ):
                response = client.get("/platform/workspace-map")
        assert response.status_code == 200
        data = response.json()
        assert data["report"] == "Workspace Map"
        assert data["packet"]["kind"] == "workspace_map"

    def test_change_risk_route(self, mock_storage: MagicMock, client: TestClient) -> None:
        diff = (
            "diff --git a/src/app.py b/src/app.py\n"
            "--- a/src/app.py\n"
            "+++ b/src/app.py\n"
            "@@ -1,1 +1,1 @@\n"
            "-old\n"
            "+new\n"
        )
        with patch("logthread.web.routes.platform.mcp_tools.handle_review_risk", return_value="PR Risk Assessment"):
            with patch("logthread.web.routes.platform.mcp_tools.handle_diff_impact", return_value="Comprehensive Diff Impact Analysis"):
                with patch(
                    "logthread.web.routes.platform.mcp_tools.build_change_risk_packet",
                    return_value={"kind": "change_risk", "risk": {"level": "LOW", "score": 10}},
                ):
                    response = client.post("/platform/change-risk", json={"diff": diff, "depth": 3})
        assert response.status_code == 200
        data = response.json()
        assert data["packet"]["kind"] == "change_risk"
        assert data["report"] == "PR Risk Assessment"
        assert data["impact"] == "Comprehensive Diff Impact Analysis"

    def test_working_diff_route(self, mock_storage: MagicMock, tmp_path: Path) -> None:
        app = _make_app(mock_storage, repo_path=tmp_path)
        client = TestClient(app)

        with patch("logthread.web.routes.platform.mcp_tools.get_current_git_diff", return_value="diff --git a/a.py b/a.py\n"):
            response = client.get("/platform/working-diff")

        assert response.status_code == 200
        data = response.json()
        assert data["source"] == "working_tree"
        assert data["hasChanges"] is True
        assert data["changedFiles"] == 1

    def test_change_risk_uses_working_tree_when_diff_missing(self, mock_storage: MagicMock, tmp_path: Path) -> None:
        app = _make_app(mock_storage, repo_path=tmp_path)
        client = TestClient(app)

        with patch("logthread.web.routes.platform.mcp_tools.get_current_git_diff", return_value="diff --git a/a.py b/a.py\n"):
            with patch("logthread.web.routes.platform.mcp_tools.handle_review_risk", return_value="PR Risk Assessment"):
                with patch("logthread.web.routes.platform.mcp_tools.handle_diff_impact", return_value="Comprehensive Diff Impact Analysis"):
                    with patch(
                        "logthread.web.routes.platform.mcp_tools.build_change_risk_packet",
                        return_value={"kind": "change_risk", "risk": {"level": "LOW", "score": 10}},
                    ):
                        response = client.post("/platform/change-risk", json={"depth": 3})

        assert response.status_code == 200
        data = response.json()
        assert data["source"] == "working_tree"
        assert data["hasChanges"] is True
        assert data["packet"]["kind"] == "change_risk"


class TestProjectsRoutes:
    def test_projects_route_includes_current_repo_when_registry_is_empty(self, mock_storage: MagicMock, tmp_path: Path) -> None:
        app = _make_app(mock_storage, repo_path=tmp_path)
        client = TestClient(app)

        with patch("logthread.web.routes.projects.get_all_projects", return_value=[]):
            with patch("logthread.web.routes.projects.get_db_path", return_value=tmp_path / "ladybug"):
                response = client.get("/projects")

        assert response.status_code == 200
        data = response.json()
        assert data["current_path"] == str(tmp_path.resolve())
        assert len(data["projects"]) == 1
        assert data["projects"][0]["is_current"] is True


class TestHostEndpoint:
    def test_host_info(self, client_with_repo: TestClient, tmp_path: Path) -> None:
        response = client_with_repo.get("/host")
        assert response.status_code == 200
        data = response.json()
        assert data["repoPath"] == str(tmp_path)
        assert data["hostUrl"] == "http://127.0.0.1:8420"
        assert data["mcpUrl"] == "http://127.0.0.1:8420/mcp"


class TestNodeEndpoint:
    def test_node_not_found(self, client: TestClient) -> None:
        response = client.get("/node/nonexistent:id")
        assert response.status_code == 404

    def test_node_with_context(
        self, mock_storage: MagicMock, client: TestClient
    ) -> None:
        target_node = _sample_node()
        caller_node = _sample_node(
            node_id="function:src/cli.py:run",
            name="run",
            file_path="src/cli.py",
        )
        callee_node = _sample_node(
            node_id="function:src/utils.py:helper",
            name="helper",
            file_path="src/utils.py",
        )
        type_ref_node = _sample_node(
            node_id="class:src/models.py:User",
            label=NodeLabel.CLASS,
            name="User",
            file_path="src/models.py",
        )

        mock_storage.get_node.return_value = target_node
        mock_storage.get_callers_with_confidence.return_value = [
            (caller_node, 1.0)
        ]
        mock_storage.get_callees_with_confidence.return_value = [
            (callee_node, 0.8)
        ]
        mock_storage.get_type_refs.return_value = [type_ref_node]
        mock_storage.get_process_memberships.return_value = {}

        response = client.get("/node/function:src/app.py:main")
        assert response.status_code == 200
        data = response.json()

        assert "node" in data
        assert data["node"]["name"] == "main"
        assert "callers" in data
        assert len(data["callers"]) == 1
        assert data["callers"][0]["confidence"] == 1.0
        assert "callees" in data
        assert len(data["callees"]) == 1
        assert data["callees"][0]["confidence"] == 0.8
        assert "typeRefs" in data
        assert len(data["typeRefs"]) == 1
        assert "processMemberships" in data


class TestSearchEndpoint:
    def test_search_returns_results(
        self, mock_storage: MagicMock, client: TestClient
    ) -> None:
        from logthread.core.storage.base import SearchResult

        search_results = [
            SearchResult(
                node_id="function:src/auth.py:validate",
                score=0.95,
                node_name="validate",
                file_path="src/auth.py",
                label="function",
                snippet="def validate(user): ...",
            ),
        ]

        with patch("logthread.web.routes.search.hybrid_search", return_value=search_results):
            with patch("logthread.web.routes.search.embed_query", return_value=None):
                response = client.post(
                    "/search", json={"query": "validate", "limit": 10}
                )

        assert response.status_code == 200
        data = response.json()
        assert "results" in data
        assert len(data["results"]) == 1

        r = data["results"][0]
        assert r["nodeId"] == "function:src/auth.py:validate"
        assert r["score"] == 0.95
        assert r["name"] == "validate"
        assert r["filePath"] == "src/auth.py"
        assert r["label"] == "function"
        assert r["snippet"] == "def validate(user): ..."

    def test_search_empty_results(
        self, mock_storage: MagicMock, client: TestClient
    ) -> None:
        with patch("logthread.web.routes.search.hybrid_search", return_value=[]):
            with patch("logthread.web.routes.search.embed_query", return_value=None):
                response = client.post(
                    "/search", json={"query": "nonexistent", "limit": 5}
                )

        assert response.status_code == 200
        data = response.json()
        assert data["results"] == []

    def test_search_failure(
        self, mock_storage: MagicMock, client: TestClient
    ) -> None:
        with patch(
            "logthread.web.routes.search.hybrid_search",
            side_effect=RuntimeError("search error"),
        ):
            with patch("logthread.web.routes.search.embed_query", return_value=None):
                response = client.post(
                    "/search", json={"query": "test"}
                )

        assert response.status_code == 500


class TestDeadCodeEndpoint:
    def test_no_dead_code(self, client: TestClient) -> None:
        response = client.get("/dead-code")
        assert response.status_code == 200
        data = response.json()
        assert data["total"] == 0
        assert data["byFile"] == {}

    def test_dead_code_found(
        self, mock_storage: MagicMock, client: TestClient
    ) -> None:
        mock_storage.execute_raw.return_value = [
            ["id1", "unused_func", "src/old.py", 10, "Function"],
            ["id2", "stale_helper", "src/old.py", 25, "Function"],
            ["id3", "OldModel", "src/models.py", 5, "Class"],
        ]

        response = client.get("/dead-code")
        assert response.status_code == 200
        data = response.json()
        assert data["total"] == 3
        assert "src/old.py" in data["byFile"]
        assert len(data["byFile"]["src/old.py"]) == 2
        assert "src/models.py" in data["byFile"]
        assert data["byFile"]["src/old.py"][0]["reason"]

    def test_dead_code_query_failure(
        self, mock_storage: MagicMock, client: TestClient
    ) -> None:
        mock_storage.execute_raw.side_effect = RuntimeError("DB error")
        response = client.get("/dead-code")
        assert response.status_code == 500


class TestDependenciesEndpoint:
    def test_dependencies_intelligence(
        self, mock_storage: MagicMock, tmp_path: Path
    ) -> None:
        app = _make_app(mock_storage, repo_path=tmp_path)
        client = TestClient(app)
        graph = KnowledgeGraph()
        graph.add_node(
            _sample_node(
                node_id="file:src/app.tsx",
                label=NodeLabel.FILE,
                name="app.tsx",
                file_path="src/app.tsx",
            )
        )
        graph.add_node(
            GraphNode(
                id="external_dep:npm:react",
                label=NodeLabel.EXTERNAL_DEP,
                name="react",
                language="npm",
                properties={"version": "^18.2.0"},
            )
        )
        graph.add_relationship(
            GraphRelationship(
                id="file:src/app.tsx->external_dep:npm:react",
                type=RelType.DEPENDS_ON,
                source="file:src/app.tsx",
                target="external_dep:npm:react",
            )
        )
        mock_storage.load_graph.return_value = graph

        with patch(
            "logthread.web.routes.dependencies.build_dependency_intelligence",
            return_value={
                "external_dep:npm:react": MagicMock(
                    latest_version="19.0.0",
                    update_available=True,
                    update_kind="major",
                    advisory_count=1,
                    advisories=[{"id": "GHSA-123", "summary": "Example advisory", "aliases": [], "severity": "high"}],
                    vulnerability_source="osv.dev",
                    lookup_error=None,
                )
            },
        ):
            response = client.get("/dependencies")

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["update_available"] is True
        assert data[0]["advisory_count"] == 1
        assert data[0]["latest_version"] == "19.0.0"


class TestCouplingEndpoint:
    def test_no_coupling(self, client: TestClient) -> None:
        response = client.get("/coupling")
        assert response.status_code == 200
        data = response.json()
        assert "pairs" in data
        assert data["pairs"] == []

    def test_coupling_with_data(
        self, mock_storage: MagicMock, client: TestClient
    ) -> None:
        mock_storage.execute_raw.return_value = [
            ["FileA", "src/a.py", "FileB", "src/b.py", 0.85, 12],
        ]

        response = client.get("/coupling")
        assert response.status_code == 200
        data = response.json()
        assert len(data["pairs"]) == 1
        pair = data["pairs"][0]
        assert pair["fileA"] == "src/a.py"
        assert pair["fileB"] == "src/b.py"
        assert pair["strength"] == 0.85
        assert pair["coChanges"] == 12


class TestHealthEndpoint:
    def test_health_returns_score_and_breakdown(
        self, mock_storage: MagicMock, client: TestClient
    ) -> None:
        # The health endpoint makes exactly 5 execute_raw calls:
        # 1. Dead code UNION ALL (3 rows: Function, Method, Class)
        # 2. Coupling strengths (rows of [strength])
        # 3. Community count (1 row)
        # 4. Avg confidence (1 row)
        # 5. Coverage UNION ALL (2 rows: Function, Method)
        mock_storage.execute_raw.side_effect = [
            [[100, 5], [50, 0], [20, 0]],  # dead code: Function/Method/Class [count, dead]
            [[0.5], [0.3]],                  # coupling strengths
            [[3]],                           # community count
            [[0.9]],                         # avg confidence
            [[50, 10], [30, 5]],            # coverage: Function/Method [callable, in_process]
        ]

        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["score"] > 0
        assert "breakdown" in data
        breakdown = data["breakdown"]
        assert "deadCode" in breakdown
        assert "coupling" in breakdown
        assert "modularity" in breakdown
        assert "confidence" in breakdown
        assert "coverage" in breakdown
        assert breakdown["deadCode"] > 90  # very few dead symbols
        assert breakdown["coupling"] == 100.0  # no high coupling

    def test_health_handles_empty_db(self, client: TestClient) -> None:
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert "score" in data
        assert "breakdown" in data


class TestCommunitiesEndpoint:
    def test_no_communities(self, client: TestClient) -> None:
        response = client.get("/communities")
        assert response.status_code == 200
        data = response.json()
        assert "communities" in data
        assert data["communities"] == []

    def test_communities_with_data(
        self, mock_storage: MagicMock, client: TestClient
    ) -> None:
        mock_storage.execute_raw.return_value = [
            ["community:auth", "Auth Module", None, ["func:login", "func:register"]],
        ]

        response = client.get("/communities")
        assert response.status_code == 200
        data = response.json()
        assert len(data["communities"]) == 1
        comm = data["communities"][0]
        assert comm["id"] == "community:auth"
        assert comm["name"] == "Auth Module"
        assert comm["memberCount"] == 2
        assert comm["cohesion"] is None
        assert len(comm["members"]) == 2


class TestProcessesEndpoint:
    def test_no_processes(self, client: TestClient) -> None:
        response = client.get("/processes")
        assert response.status_code == 200
        data = response.json()
        assert "processes" in data
        assert data["processes"] == []

    def test_processes_with_data(
        self, mock_storage: MagicMock, client: TestClient
    ) -> None:
        mock_storage.execute_raw.return_value = [
            ["process:login-flow", "Login Flow",
             ["func:validate", "func:auth"], [1, 2]],
        ]

        response = client.get("/processes")
        assert response.status_code == 200
        data = response.json()
        assert len(data["processes"]) == 1
        proc = data["processes"][0]
        assert proc["name"] == "Login Flow"
        assert proc["kind"] is None
        assert proc["stepCount"] == 2
        assert len(proc["steps"]) == 2
        assert proc["steps"][0]["nodeId"] == "func:validate"
        assert proc["steps"][0]["stepNumber"] == 1


class TestCypherEndpoint:
    def test_valid_query(
        self, mock_storage: MagicMock, client: TestClient
    ) -> None:
        mock_storage.execute_raw.return_value = [
            ["main", "src/app.py", 1],
            ["helper", "src/utils.py", 5],
        ]

        response = client.post(
            "/cypher",
            json={"query": "MATCH (n) RETURN n.name, n.file_path, n.start_line"},
        )
        assert response.status_code == 200
        data = response.json()
        assert "columns" in data
        assert "rows" in data
        assert "rowCount" in data
        assert "durationMs" in data
        assert data["rowCount"] == 2
        assert len(data["rows"]) == 2
        assert isinstance(data["durationMs"], (int, float))

    def test_empty_results(
        self, mock_storage: MagicMock, client: TestClient
    ) -> None:
        mock_storage.execute_raw.return_value = []

        response = client.post(
            "/cypher",
            json={"query": "MATCH (n:Nonexistent) RETURN n"},
        )
        assert response.status_code == 200
        data = response.json()
        assert data["rowCount"] == 0
        assert data["rows"] == []

    def test_null_results(
        self, mock_storage: MagicMock, client: TestClient
    ) -> None:
        mock_storage.execute_raw.return_value = None

        response = client.post(
            "/cypher",
            json={"query": "MATCH (n:Nonexistent) RETURN n"},
        )
        assert response.status_code == 200
        data = response.json()
        assert data["rowCount"] == 0

    def test_write_query_blocked_create(self, client: TestClient) -> None:
        response = client.post(
            "/cypher",
            json={"query": "CREATE (n:Test {name: 'test'})"},
        )
        assert response.status_code == 400
        assert "read-only" in response.json()["detail"].lower()

    def test_write_query_blocked_delete(self, client: TestClient) -> None:
        response = client.post(
            "/cypher",
            json={"query": "MATCH (n) DELETE n"},
        )
        assert response.status_code == 400

    def test_write_query_blocked_set(self, client: TestClient) -> None:
        response = client.post(
            "/cypher",
            json={"query": "MATCH (n) SET n.name = 'hacked'"},
        )
        assert response.status_code == 400

    def test_write_query_blocked_drop(self, client: TestClient) -> None:
        response = client.post(
            "/cypher",
            json={"query": "DROP TABLE Node"},
        )
        assert response.status_code == 400

    def test_write_query_blocked_merge(self, client: TestClient) -> None:
        response = client.post(
            "/cypher",
            json={"query": "MERGE (n:Test {name: 'x'})"},
        )
        assert response.status_code == 400

    def test_write_query_blocked_detach(self, client: TestClient) -> None:
        response = client.post(
            "/cypher",
            json={"query": "MATCH (n) DETACH DELETE n"},
        )
        assert response.status_code == 400

    def test_write_query_blocked_case_insensitive(
        self, client: TestClient
    ) -> None:
        response = client.post(
            "/cypher",
            json={"query": "match (n) delete n"},
        )
        assert response.status_code == 400

    def test_write_keyword_in_comment_allowed(self, client: TestClient) -> None:
        mock_storage = client.app.state.storage
        mock_storage.execute_raw.return_value = [["ok"]]
        response = client.post("/cypher", json={"query": "MATCH (n) /* CREATE */ RETURN n"})
        assert response.status_code == 200

    def test_write_keyword_outside_comment_blocked(self, client: TestClient) -> None:
        response = client.post("/cypher", json={"query": "/* harmless */ CREATE (n:Test)"})
        assert response.status_code == 400

    def test_write_query_blocked_remove(self, client: TestClient) -> None:
        response = client.post("/cypher", json={"query": "MATCH (n) REMOVE n.name"})
        assert response.status_code == 400

    def test_write_query_blocked_install(self, client: TestClient) -> None:
        response = client.post("/cypher", json={"query": "INSTALL httpfs"})
        assert response.status_code == 400

    def test_write_query_blocked_load(self, client: TestClient) -> None:
        response = client.post("/cypher", json={"query": "LOAD FROM 'file.csv'"})
        assert response.status_code == 400

    def test_write_query_blocked_copy(self, client: TestClient) -> None:
        response = client.post("/cypher", json={"query": "COPY Node FROM 'file.csv'"})
        assert response.status_code == 400

    def test_query_execution_failure(
        self, mock_storage: MagicMock, client: TestClient
    ) -> None:
        mock_storage.execute_raw.side_effect = RuntimeError("Syntax error in query")
        response = client.post(
            "/cypher",
            json={"query": "MATCH (n) RETURN invalid"},
        )
        assert response.status_code == 400
        assert "Syntax error" in response.json()["detail"]

    def test_columns_extracted_from_return(
        self, mock_storage: MagicMock, client: TestClient
    ) -> None:
        mock_storage.execute_raw.return_value = [["test", 42]]

        response = client.post(
            "/cypher",
            json={"query": "MATCH (n) RETURN n.name AS name, count(n)"},
        )
        assert response.status_code == 200
        data = response.json()
        assert "name" in data["columns"]


class TestTreeEndpoint:
    def test_empty_tree(self, client: TestClient) -> None:
        response = client.get("/tree")
        assert response.status_code == 200
        data = response.json()
        assert "tree" in data
        assert data["tree"] == []

    def test_tree_with_files(
        self, mock_storage: MagicMock, client: TestClient
    ) -> None:
        mock_storage.execute_raw.side_effect = [
            # File nodes
            [
                ["file:src/app.py", "app.py", "src/app.py", "python"],
                ["file:src/utils.py", "utils.py", "src/utils.py", "python"],
            ],
            # Folder nodes
            [],
            # Symbol counts
            [["src/app.py", 5], ["src/utils.py", 3]],
        ]

        response = client.get("/tree")
        assert response.status_code == 200
        data = response.json()
        assert len(data["tree"]) >= 1

        # Should have a "src" folder at root
        src_folder = next(
            (item for item in data["tree"] if item["name"] == "src"), None
        )
        assert src_folder is not None
        assert src_folder["type"] == "folder"
        assert "children" in src_folder


class TestFileEndpoint:
    def test_no_repo_path(self, client: TestClient) -> None:
        response = client.get("/file?path=src/app.py")
        assert response.status_code == 400
        assert "repo_path" in response.json()["detail"].lower()

    def test_file_not_found(
        self, client_with_repo: TestClient
    ) -> None:
        response = client_with_repo.get("/file?path=nonexistent.py")
        assert response.status_code == 404

    def test_file_found(
        self, mock_storage: MagicMock, tmp_path: Path
    ) -> None:
        # Create a real file in the tmp repo
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        test_file = src_dir / "app.py"
        test_file.write_text("def main():\n    pass\n", encoding="utf-8")

        app = _make_app(mock_storage, repo_path=tmp_path)
        client = TestClient(app)

        response = client.get("/file?path=src/app.py")
        assert response.status_code == 200
        data = response.json()
        assert data["path"] == "src/app.py"
        assert "def main()" in data["content"]
        assert data["language"] == "python"

    def test_path_traversal_blocked(
        self, mock_storage: MagicMock, tmp_path: Path
    ) -> None:
        app = _make_app(mock_storage, repo_path=tmp_path)
        client = TestClient(app)

        response = client.get("/file?path=../../etc/passwd")
        assert response.status_code == 400
        assert "traversal" in response.json()["detail"].lower()


class TestDiffEndpoint:
    def test_no_repo_path(self, client: TestClient) -> None:
        response = client.post("/diff", json={"base": "main", "compare": "feature"})
        assert response.status_code == 400
        assert "repo_path" in response.json()["detail"].lower()

    def test_diff_success(
        self, mock_storage: MagicMock, tmp_path: Path
    ) -> None:
        from dataclasses import dataclass
        from dataclasses import field as dc_field

        @dataclass
        class FakeDiffResult:
            added_nodes: list = dc_field(default_factory=list)
            removed_nodes: list = dc_field(default_factory=list)
            modified_nodes: list = dc_field(default_factory=list)
            added_relationships: list = dc_field(default_factory=list)
            removed_relationships: list = dc_field(default_factory=list)

        added_node = _sample_node(
            node_id="function:src/new.py:new_func",
            name="new_func",
            file_path="src/new.py",
        )
        fake_result = FakeDiffResult(added_nodes=[added_node])

        app = _make_app(mock_storage, repo_path=tmp_path)
        client = TestClient(app)

        with patch("logthread.web.routes.diff.diff_branches", return_value=fake_result):
            response = client.post(
                "/diff", json={"base": "main", "compare": "feature"}
            )

        assert response.status_code == 200
        data = response.json()
        assert "added" in data
        assert "removed" in data
        assert "modified" in data
        assert "addedEdges" in data
        assert "removedEdges" in data
        assert len(data["added"]) == 1
        assert data["added"][0]["name"] == "new_func"

    def test_diff_with_modified_nodes(
        self, mock_storage: MagicMock, tmp_path: Path
    ) -> None:
        from dataclasses import dataclass
        from dataclasses import field as dc_field

        base_node = _sample_node(
            node_id="function:src/utils.py:helper",
            name="helper",
            file_path="src/utils.py",
        )
        current_node = _sample_node(
            node_id="function:src/utils.py:helper",
            name="helper",
            file_path="src/utils.py",
        )
        current_node.content = "def helper(): return 42"

        @dataclass
        class FakeModifiedResult:
            added_nodes: list = dc_field(default_factory=list)
            removed_nodes: list = dc_field(default_factory=list)
            modified_nodes: list = dc_field(default_factory=list)
            added_relationships: list = dc_field(default_factory=list)
            removed_relationships: list = dc_field(default_factory=list)

        fake_result = FakeModifiedResult(modified_nodes=[(base_node, current_node)])

        app = _make_app(mock_storage, repo_path=tmp_path)
        client = TestClient(app)

        with patch("logthread.web.routes.diff.diff_branches", return_value=fake_result):
            response = client.post(
                "/diff", json={"base": "main", "compare": "dev"}
            )

        assert response.status_code == 200
        data = response.json()
        assert len(data["modified"]) == 1
        assert "before" in data["modified"][0]
        assert "after" in data["modified"][0]

    def test_diff_value_error(
        self, mock_storage: MagicMock, tmp_path: Path
    ) -> None:
        app = _make_app(mock_storage, repo_path=tmp_path)
        client = TestClient(app)

        with patch(
            "logthread.web.routes.diff.diff_branches",
            side_effect=ValueError("Invalid branch range"),
        ):
            response = client.post(
                "/diff", json={"base": "main", "compare": "nonexistent"}
            )

        assert response.status_code == 400


class TestReindexEndpoint:
    def test_reindex_no_repo_path(self, client: TestClient) -> None:
        response = client.post("/reindex")
        assert response.status_code == 400

    def test_reindex_not_in_watch_mode(
        self, mock_storage: MagicMock
    ) -> None:
        app = _make_app(mock_storage, repo_path=Path("/tmp/fake"), watch=False)
        client = TestClient(app)
        response = client.post("/reindex")
        assert response.status_code == 400
        assert "watch" in response.json()["detail"].lower()

    def test_reindex_success(self, client_with_repo: TestClient) -> None:
        with patch("logthread.web.routes.analysis.run_pipeline"):
            response = client_with_repo.post("/reindex")

        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "started"


class TestImpactEndpoint:
    def test_node_not_found(self, client: TestClient) -> None:
        response = client.get("/impact/nonexistent:id")
        assert response.status_code == 404

    def test_impact_with_affected(
        self, mock_storage: MagicMock, client: TestClient
    ) -> None:
        target = _sample_node()
        affected = _sample_node(
            node_id="function:src/cli.py:run",
            name="run",
            file_path="src/cli.py",
        )

        mock_storage.get_node.return_value = target
        mock_storage.traverse_with_depth.return_value = [(affected, 1)]

        response = client.get("/impact/function:src/app.py:main")
        assert response.status_code == 200
        data = response.json()
        assert "target" in data
        assert "affected" in data
        assert "depths" in data
        assert data["affected"] == 1
        assert data["target"]["name"] == "main"


class TestEventsEndpoint:
    def test_events_endpoint_exists(self, client: TestClient) -> None:
        # SSE endpoints return a streaming response. With no event_queue
        # (non-watch mode), the generator exits immediately.
        response = client.get("/events")
        # sse-starlette returns 200 for SSE responses
        assert response.status_code == 200
