from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

from starlette.routing import Mount

from logthread.runtime import LogThreadRuntime
from logthread.web.app import create_app


def test_create_app_mounts_streamable_mcp_as_asgi_app(tmp_path: Path) -> None:
    runtime = LogThreadRuntime(storage=MagicMock(), repo_path=tmp_path, owns_storage=False)
    app = create_app(
        db_path=tmp_path / "dummy.ladybug",
        repo_path=tmp_path,
        runtime=runtime,
        mount_mcp=True,
        mount_frontend=False,
    )

    mcp_mounts = [
        route
        for route in app.router.routes
        if isinstance(route, Mount) and route.path == "/mcp"
    ]
    assert mcp_mounts, "Expected /mcp to be mounted as an ASGI app"
