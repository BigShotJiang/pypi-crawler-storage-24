#!/bin/bash
# Setup script for LogThread MCP server in Kiro

set -e

echo "🚀 LogThread MCP Server Setup for Kiro"
echo "========================================"
echo ""

# Check if logthread is installed
if ! command -v logthread &> /dev/null; then
    echo "❌ LogThread CLI not found"
    echo ""
    echo "Please install LogThread first:"
    echo "  pip install logthread"
    echo "  # or"
    echo "  uv pip install logthread"
    echo ""
    exit 1
fi

echo "✓ LogThread CLI found: $(which logthread)"
echo "✓ Version: $(logthread --version 2>&1 | head -1)"
echo ""

# Check if Kiro settings directory exists
KIRO_SETTINGS_DIR="$HOME/.kiro/settings"
if [ ! -d "$KIRO_SETTINGS_DIR" ]; then
    echo "📁 Creating Kiro settings directory..."
    mkdir -p "$KIRO_SETTINGS_DIR"
fi

# Backup existing mcp.json if it exists
MCP_CONFIG="$KIRO_SETTINGS_DIR/mcp.json"
if [ -f "$MCP_CONFIG" ]; then
    BACKUP="$MCP_CONFIG.backup.$(date +%Y%m%d_%H%M%S)"
    echo "📦 Backing up existing config to: $BACKUP"
    cp "$MCP_CONFIG" "$BACKUP"
fi

# Copy the new configuration
echo "📝 Installing LogThread MCP configuration..."
cp kiro-mcp-config.json "$MCP_CONFIG"

echo ""
echo "✅ Configuration installed successfully!"
echo ""
echo "📍 Config location: $MCP_CONFIG"
echo ""
echo "Next steps:"
echo "  1. Restart Kiro or reload MCP servers"
echo "  2. Analyze your workspace: cd /path/to/project && logthread analyze"
echo "  3. Verify in Kiro: Open MCP Server view and check 'logthread' is connected"
echo ""
echo "For more details, see: KIRO_MCP_SETUP.md"
echo ""
