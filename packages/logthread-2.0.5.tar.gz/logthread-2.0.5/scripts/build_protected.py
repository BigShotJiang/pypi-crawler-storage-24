#!/usr/bin/env python3
"""Build script for creating protected/obfuscated distribution of Log Thread.

This script creates a protected build using PyArmor for code obfuscation
and Cython for performance-critical modules.

Usage:
    pip install pyarmor cython
    python scripts/build_protected.py

Output:
    dist/logthread-<version>-protected-py3-none-any.whl
"""

import os
import shutil
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
SRC_DIR = PROJECT_ROOT / "src" / "logthread"
BUILD_DIR = PROJECT_ROOT / "build_protected"
DIST_DIR = PROJECT_ROOT / "dist"

CRITICAL_MODULES = [
    "cloud/auth.py",
    "cloud/client.py",
    "mcp/server.py",
    "core/storage/paths.py",
]


def check_dependencies():
    """Check if required build tools are installed."""
    try:
        import pyarmor
        print(f"✓ PyArmor {pyarmor.__version__}")
    except ImportError:
        print("✗ PyArmor not installed. Run: pip install pyarmor")
        sys.exit(1)


def clean_build():
    """Remove previous build artifacts."""
    if BUILD_DIR.exists():
        shutil.rmtree(BUILD_DIR)
    BUILD_DIR.mkdir(parents=True)
    print("✓ Cleaned build directory")


def copy_source():
    """Copy source files to build directory."""
    dest = BUILD_DIR / "src" / "logthread"
    shutil.copytree(SRC_DIR, dest)
    print(f"✓ Copied source to {dest}")
    return dest


def obfuscate_critical_modules(src_path: Path):
    """Obfuscate critical modules using PyArmor."""
    print("\n→ Obfuscating critical modules...")
    
    for module_path in CRITICAL_MODULES:
        full_path = src_path / module_path
        if not full_path.exists():
            print(f"  ⚠ Skipping {module_path} (not found)")
            continue
        
        print(f"  • Obfuscating {module_path}")
        
        result = subprocess.run(
            [
                sys.executable, "-m", "pyarmor", "gen",
                "--output", str(full_path.parent),
                "--obf-code", "2",
                "--obf-module", "1", 
                "--assert-call",
                "--assert-import",
                "--restrict",
                str(full_path),
            ],
            capture_output=True,
            text=True,
        )
        
        if result.returncode != 0:
            print(f"    ✗ Failed: {result.stderr}")
        else:
            print(f"    ✓ Done")


def inject_license_check(src_path: Path):
    """Inject additional license verification into critical modules."""
    init_file = src_path / "__init__.py"
    
    license_check = '''
import os as _os
import sys as _sys

def _v():
    try:
        from logthread.cloud.client import require_subscription
        _r, _e = require_subscription()
        if not _r:
            _sys.stderr.write(f"\\n⚠️  {_e}\\n")
            _sys.stderr.write("Visit https://logthread.dev to subscribe.\\n\\n")
    except Exception:
        pass

if not _os.environ.get("_LT_SKIP_CHECK"):
    _v()
'''
    
    content = init_file.read_text()
    if "_v()" not in content:
        content = content + license_check
        init_file.write_text(content)
        print("✓ Injected license verification")


def add_runtime_checks(src_path: Path):
    """Add runtime integrity checks to prevent tampering."""
    check_file = src_path / "_integrity.py"
    
    check_code = '''
"""Runtime integrity verification for Log Thread."""

import hashlib
import sys
from pathlib import Path

_CHECKSUMS = {}

def _compute_checksum(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()[:16]

def verify_integrity() -> bool:
    """Verify that critical files haven't been tampered with."""
    try:
        pkg_dir = Path(__file__).parent
        for rel_path, expected in _CHECKSUMS.items():
            full_path = pkg_dir / rel_path
            if full_path.exists():
                actual = _compute_checksum(full_path)
                if actual != expected:
                    return False
        return True
    except Exception:
        return True

if not verify_integrity():
    sys.stderr.write("\\n⚠️  Integrity check failed. Package may be corrupted.\\n")
    sys.stderr.write("Please reinstall: pip install --force-reinstall logthread\\n\\n")
'''
    
    check_file.write_text(check_code)
    print("✓ Added runtime integrity checks")


def build_wheel(src_path: Path):
    """Build the protected wheel package."""
    print("\n→ Building wheel...")
    
    pyproject = PROJECT_ROOT / "pyproject.toml"
    build_pyproject = BUILD_DIR / "pyproject.toml"
    shutil.copy(pyproject, build_pyproject)
    
    readme = PROJECT_ROOT / "README.md"
    if readme.exists():
        shutil.copy(readme, BUILD_DIR / "README.md")
    
    result = subprocess.run(
        [sys.executable, "-m", "build", "--wheel"],
        cwd=BUILD_DIR,
        capture_output=True,
        text=True,
    )
    
    if result.returncode != 0:
        print(f"✗ Build failed: {result.stderr}")
        sys.exit(1)
    
    wheel_dir = BUILD_DIR / "dist"
    for wheel in wheel_dir.glob("*.whl"):
        dest = DIST_DIR / wheel.name.replace(".whl", "-protected.whl")
        shutil.copy(wheel, dest)
        print(f"✓ Created {dest}")


def main():
    print("=" * 60)
    print("Log Thread Protected Build")
    print("=" * 60)
    
    check_dependencies()
    clean_build()
    src_path = copy_source()
    obfuscate_critical_modules(src_path)
    inject_license_check(src_path)
    add_runtime_checks(src_path)
    build_wheel(src_path)
    
    print("\n" + "=" * 60)
    print("Build complete!")
    print("=" * 60)


if __name__ == "__main__":
    main()
