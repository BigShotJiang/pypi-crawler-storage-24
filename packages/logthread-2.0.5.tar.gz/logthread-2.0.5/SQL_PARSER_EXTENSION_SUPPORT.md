# SQL Parser Extension Support

## Problem
The LogThread SQL parser was generating warnings when encountering PostgreSQL and DuckDB extension management commands:
- `CREATE EXTENSION IF NOT EXISTS "uuid-ossp"`
- `CREATE EXTENSION IF NOT EXISTS "pgcrypto"`
- `LOAD EXTENSION fts`

These warnings appeared as:
```
'LOAD EXTENSION fts' contains unsupported syntax. Falling back to parsing as a 'Command'.
```

## Solution
Added comprehensive support for extension statements in the SQL parser by:

### 1. Added Extension Statement Regex Pattern
```python
_EXTENSION_STATEMENT = re.compile(
    r"(?is)\b(?:CREATE\s+EXTENSION|LOAD\s+EXTENSION)\b.*?(?:;|$)"
)
```

### 2. Strip Extension Statements Before Parsing
Updated three key functions to remove extension statements before they reach sqlglot:

- `_strip_function_spans()`: Strips extension statements along with other unsupported admin statements
- `extract_sql_lineage()`: Cleans SQL before parsing for table/column references
- `_parse_with_sqlglot()`: Cleans SQL before parsing CREATE TABLE statements

### 3. Suppress sqlglot Warnings
Added `error_level=ErrorLevel.IGNORE` parameter to all `sqlglot.parse()` calls to suppress warnings about unsupported syntax.

## Changes Made

### File: `src/logthread/core/parsers/sql_lang.py`

1. **Import ErrorLevel** (lines 23-31):
```python
try:
    import sqlglot
    from sqlglot import expressions as sqlglot_exp
    from sqlglot.errors import ErrorLevel
except Exception:
    sqlglot = None
    sqlglot_exp = None
    ErrorLevel = None
```

2. **Added regex pattern** (lines 46-48):
```python
_EXTENSION_STATEMENT = re.compile(
    r"(?is)\b(?:CREATE\s+EXTENSION|LOAD\s+EXTENSION)\b.*?(?:;|$)"
)
```

3. **Updated _strip_function_spans()** (lines 205-207):
```python
stripped = _UNSUPPORTED_PG_ADMIN_STATEMENT.sub("\n", stripped)
stripped = _EXTENSION_STATEMENT.sub("\n", stripped)
return stripped
```

4. **Updated extract_sql_lineage()** (lines 343-351):
```python
# Strip extension statements before parsing
cleaned_sql = _EXTENSION_STATEMENT.sub("\n", sql)
try:
    found_tables: list[str] = []
    found_columns: list[str] = []
    # Use IGNORE error level to suppress warnings
    for statement in sqlglot.parse(cleaned_sql, read="postgres", 
                                   error_level=ErrorLevel.IGNORE if ErrorLevel else None):
```

5. **Updated _parse_with_sqlglot()** (lines 491-498):
```python
# Strip extension statements before parsing
cleaned_content = _EXTENSION_STATEMENT.sub("\n", content)
try:
    # Use IGNORE error level to suppress warnings
    statements = sqlglot.parse(cleaned_content, read="postgres",
                              error_level=ErrorLevel.IGNORE if ErrorLevel else None)
```

## Testing

Tested with:
1. Sample SQL files containing extension statements - ✅ No warnings
2. `cloud-api/schema.sql` with PostgreSQL extensions - ✅ Parsed 6 tables successfully
3. Direct parser tests - ✅ No stderr output

## Result

Extension management commands are now:
- Silently skipped during parsing (they don't create tables/columns to track)
- Don't generate any warnings or errors
- Don't interfere with normal CREATE TABLE parsing

The `logthread generate --full` command will no longer show warnings about unsupported extension syntax.
