# Capabilities Command Removal

## Overview
Removed the `logthread capabilities` command from the CLI as it exposes internal/development information that is not useful for end users.

## Changes Made

### 1. Removed Command (`src/logthread/cli/main.py`)
- Removed `capabilities()` command function
- Removed import of `format_capabilities_report` from `logthread.config.capabilities`

### 2. What Was Removed
The command displayed:
- Native language support details (status, API framework detection, type support, DB support)
- Recommended external semantic engines (tree-sitter, tsserver, Pyright, gopls, etc.)
- Recommended architecture details

### 3. Why It Was Removed
- **Internal Information**: The output was primarily useful for developers, not end users
- **Confusing**: Users don't need to know about "semantic engines" or "tree-sitter"
- **Maintenance Burden**: Keeping this information up-to-date adds unnecessary work
- **Not Actionable**: Users can't do anything with this information
- **Better Alternatives**: Language support is documented in README.md

## What Remains

### User-Facing Language Information
The README.md already lists supported languages:
```
Python • TypeScript • JavaScript • Go • Java • C# • Ruby • Rust • C • C++ • PHP • Kotlin • Swift • Dart • Perl • SQL
```

This is sufficient for users to know what's supported.

### Internal Code (Preserved)
- `src/logthread/config/capabilities.py` - Still exists for internal use
- `format_capabilities_report()` function - Can be used in development/debugging

## Impact

### ✅ Cleaner CLI
- Removed command that exposed internal implementation details
- Simplified user-facing interface

### ✅ No Breaking Changes for Users
- This was an informational command with no side effects
- Users who ran it were likely confused by the output
- No functionality is lost

### ✅ Better User Experience
- Users see only actionable commands
- Documentation (README) provides language support info
- Less clutter in `logthread --help`

## Verification

```bash
# Verify command is removed
logthread --help | grep capabilities
# Should return nothing

# Verify help output is clean
logthread --help
# Should show only user-facing commands
```

## Alternative for Developers

If developers need to see capabilities information:

1. **Check the code**: `src/logthread/config/capabilities.py`
2. **Run in Python**:
   ```python
   from logthread.config.capabilities import format_capabilities_report
   print(format_capabilities_report())
   ```
3. **Check documentation**: Language support is in README.md

## Related Changes

This is part of the open-source preparation cleanup:
- Removing internal/development commands
- Simplifying user-facing CLI
- Focusing on core functionality
- Improving documentation over command output

## Summary

The `capabilities` command has been removed from the CLI. Language support information is available in the README.md, and the internal capabilities module remains for development use if needed.
