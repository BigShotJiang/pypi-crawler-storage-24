# Project Switcher Fix - Registry Location Issue

## Problem
The Project Switcher was showing 0 projects even though `logthread list` command showed 5 indexed projects.

## Root Cause
The issue was a mismatch between storage locations:

1. **Old format**: Projects were stored in `~/.logthread/repos/*/meta.json`
2. **New format**: Code was looking in platform-specific location:
   - macOS: `~/Library/Application Support/logthread/repos/`
   - Linux: `~/.local/share/logthread/repos/`
   - Windows: `%APPDATA%/logthread/repos/`

The `logthread list` command was correctly reading from `~/.logthread/repos/`, but the new `get_all_projects()` function was only checking the platform-specific location.

## Solution
Updated `get_all_projects()` in `src/logthread/core/storage/paths.py` to check both locations:

1. First tries new `registry.json` format (future-proof)
2. Falls back to scanning both:
   - Platform-specific location (`get_app_data_dir() / "repos"`)
   - Legacy location (`~/.logthread/repos/`)
3. Deduplicates projects by path to avoid showing the same project twice

## Changes Made

### File: `src/logthread/core/storage/paths.py`
- Updated `get_all_projects()` to check legacy `~/.logthread/repos/` location
- Added deduplication logic to handle projects in multiple locations
- Maintained backward compatibility with old format

### File: `src/logthread/cli/main.py`
- Added `register_project` import
- Simplified `_register_in_global_registry()` to use `register_project()`
- Updated `_build_meta()` to include top-level `files` and `symbols` fields
- Fixed incremental update path to register projects
- Fixed "no changes" path to update registry

## Testing
```bash
# Test that projects are found
python3 -c "
from logthread.core.storage.paths import get_all_projects
projects = get_all_projects()
print(f'Found {len(projects)} projects')
"
# Output: Found 5 projects
```

## Result
The Project Switcher now correctly displays all 5 indexed projects:
1. logthread (1098 symbols, 140 files)
2. sample game (30 symbols, 2 files)
3. logthread (3204 symbols, 212 files)
4. proctored-backend (1085 symbols, 308 files)
5. Supertonic-TTS-WebGPU (61 symbols, 11 files)

## Future Improvements
- Migrate old `~/.logthread/repos/` to new `registry.json` format on first access
- Use only platform-specific locations for new installations
- Provide migration tool for users to consolidate storage locations
