# Google Gemini AI Integration

LogThread uses Google's latest **Gemini AI SDK** (`google-genai`) for intelligent code modifications with native tool calling support.

## What's New

### ✅ Migrated to New Gemini SDK

**Old:** `google-generativeai` (legacy)  
**New:** `google-genai` (GA - General Availability)

**Benefits:**
- Official GA release with long-term support
- Improved developer experience with centralized Client
- Better error handling and type safety
- Native tool calling support
- Consistent with Google's latest best practices

### ✅ Open Source Ready

All cloud-related features have been removed for open-source release:
- ❌ No login/logout commands
- ❌ No cloud sync functionality  
- ❌ No subscription checks
- ✅ Fully self-contained and local
- ✅ Your code never leaves your machine

## Features

### 🤖 Google Gemini Integration
- **Latest Models**: Support for Gemini 2.0 Flash (Experimental), 1.5 Pro, 1.5 Flash, and 1.5 Flash-8B
- **Native Tool Calling**: Advanced code analysis using Gemini's function calling capabilities
- **Context-Aware**: Leverages LogThread's code graph for better understanding

### 🔐 Secure API Key Management
- **Local Storage**: API keys stored securely in your project directory (`~/.logthread/projects/{project_id}/gemini_api_key.txt`)
- **Never Transmitted**: Keys never sent to LogThread servers
- **UI Configuration**: Easy setup through the Settings modal

### 🛠️ Tool Calling Support
- **Advanced Analysis**: Enable tools to let Gemini analyze dependencies and find related code
- **Intelligent Modifications**: Better code changes by understanding your codebase structure
- **Transparent**: See which tools were used for each modification

## Getting Started

### 1. Get Your Gemini API Key

Visit [Google AI Studio](https://aistudio.google.com/app/apikey) to get your free API key.

**Free Tier Includes:**
- 15 requests per minute
- 1,500 requests per day
- 1 million requests per month

### 2. Configure in LogThread

1. Open LogThread UI
2. Click the **Settings** button (⚙️) in the header
3. Enter your Gemini API key
4. Select your preferred model (default: Gemini 2.0 Flash)
5. Click **Save API Key**

### 3. Use AI Modifications

1. Select any node in the graph
2. Go to the **AI** tab in the detail panel
3. Enter your modification instruction
4. (Optional) Enable **Use advanced tools** for better analysis
5. Click **Generate with Gemini**
6. Review the proposed changes
7. Click **Apply to File** to save

## API Endpoints

### Get Configuration
```http
GET /api/ai/config
```

Response:
```json
{
  "has_key": true,
  "model": "gemini-2.0-flash-exp",
  "provider": "gemini"
}
```

### Set API Key
```http
POST /api/ai/config
Content-Type: application/json

{
  "api_key": "your-api-key",
  "model": "gemini-2.0-flash-exp"
}
```

### Delete API Key
```http
DELETE /api/ai/config
```

### Suggest Code Modification
```http
POST /api/ai/suggest
Content-Type: application/json

{
  "file_path": "src/main.py",
  "instruction": "Add error handling",
  "context": "Additional context from code graph",
  "use_tools": true
}
```

Response:
```json
{
  "file_path": "src/main.py",
  "original_content": "...",
  "suggested_content": "...",
  "diff": "...",
  "tool_calls": [
    {
      "name": "analyze_dependencies",
      "args": {"symbol": "main"}
    }
  ]
}
```

## Python API

### Basic Usage (New SDK)

```python
from logthread.core.ai.llm import AIClient, AIProviderConfig

# Configure with API key
config = AIProviderConfig(
    api_key="your-gemini-api-key",
    model="gemini-2.0-flash-exp"
)

client = AIClient(config)

# Simple modification
new_content = client.suggest_edit(
    instruction="Add type hints to all functions",
    file_path="src/utils.py",
    file_content=original_content,
    context="This is a utility module"
)
```

### With Tool Calling (New SDK)

```python
# Advanced modification with tools
result = client.suggest_edit_with_tools(
    instruction="Refactor this function to use async/await",
    file_path="src/api.py",
    file_content=original_content,
    context="API handler module",
    tools=[...]  # Optional: provide custom tool definitions
)

print(result["content"])  # Modified code
print(result["tool_calls"])  # List of tools used
```

### Direct SDK Usage

You can also use the new `google-genai` SDK directly:

```python
from google import genai
from google.genai import types

# Create client
client = genai.Client(api_key="your-api-key")

# Generate content
response = client.models.generate_content(
    model='gemini-2.0-flash-exp',
    contents='Explain this code...',
    config=types.GenerateContentConfig(
        temperature=0.2,
        max_output_tokens=2048,
    )
)

print(response.text)
```

## Environment Variables

You can also configure via environment variables:

```bash
export LOGTHREAD_GEMINI_API_KEY="your-api-key"
export LOGTHREAD_AI_MODEL="gemini-2.0-flash-exp"
```

## Available Models

| Model | Description | Best For |
|-------|-------------|----------|
| `gemini-2.0-flash-exp` | Latest experimental model | Cutting-edge features, fastest |
| `gemini-1.5-pro` | Most capable model | Complex reasoning, large codebases |
| `gemini-1.5-flash` | Fast and efficient | Quick modifications, smaller files |
| `gemini-1.5-flash-8b` | Lightweight | Simple tasks, high volume |

## Tool Calling

When **Use advanced tools** is enabled, Gemini can:

- Analyze symbol dependencies
- Find related code across the codebase
- Check for breaking changes
- Understand call hierarchies
- Validate modifications against the code graph

This results in more accurate and safer code modifications.

## Security

- API keys are stored with `0600` permissions (owner read/write only)
- Keys are never logged or transmitted to LogThread servers
- Each project has its own isolated API key storage
- Keys can be deleted at any time through the UI

## Migration from OpenAI/Anthropic

LogThread previously supported OpenAI and Anthropic. The new version exclusively uses Google Gemini for:

- **Better Performance**: Faster response times with Gemini 2.0 Flash
- **Native Tool Calling**: Built-in function calling support
- **Cost Effective**: Generous free tier (15 req/min, 1.5K/day, 1M/month)
- **Latest Features**: Access to cutting-edge AI capabilities
- **No Cloud Lock-in**: Fully local, open-source solution

### Migration Steps

1. Get a Gemini API key from [Google AI Studio](https://aistudio.google.com/app/apikey)
2. Open Settings in LogThread UI
3. Enter your Gemini API key
4. Select your preferred model
5. Your existing workflows continue to work!

### SDK Migration

If you were using the old `google-generativeai` library:

**Old Code:**
```python
import google.generativeai as genai

genai.configure(api_key="your-key")
model = genai.GenerativeModel('gemini-2.0-flash')
response = model.generate_content("Hello")
```

**New Code:**
```python
from google import genai

client = genai.Client(api_key="your-key")
response = client.models.generate_content(
    model='gemini-2.0-flash',
    contents="Hello"
)
```

See the [official migration guide](https://ai.google.dev/gemini-api/docs/migrate) for more details.

## Troubleshooting

### "API key not configured"
- Open Settings and enter your Gemini API key
- Verify the key is valid at [Google AI Studio](https://aistudio.google.com/app/apikey)

### "Rate limit exceeded"
- Free tier: 15 requests/minute, 1,500/day
- Wait a moment and try again
- Consider upgrading to a paid plan for higher limits

### "Model not found"
- Ensure you're using a valid model name
- Check [Google AI documentation](https://ai.google.dev/models/gemini) for available models

## Learn More

- [Google Gemini Documentation](https://ai.google.dev/docs)
- [Gemini API Pricing](https://ai.google.dev/pricing)
- [LogThread Documentation](https://logthread.dev/docs)
