import * as vscode from 'vscode';
import { LogThreadService } from '../services/logthread';

// ── Internal → display label maps (never expose implementation details) ──────

const NODE_DISPLAY: Record<string, { label: string; short: string; color: string }> = {
    Function:      { label: 'Function',     short: 'fn',    color: '#56d364' },
    Method:        { label: 'Method',       short: 'fn',    color: '#56d364' },
    Class:         { label: 'Class',        short: 'class', color: '#58a6ff' },
    Interface:     { label: 'Interface',    short: 'iface', color: '#bc8cff' },
    TypeAlias:     { label: 'Type',         short: 'type',  color: '#63e2b7' },
    Variable:      { label: 'Variable',     short: 'var',   color: '#ff9f43' },
    Constant:      { label: 'Variable',     short: 'var',   color: '#ff9f43' },
    Folder:        { label: 'Folder',       short: 'dir',   color: '#64748b' },
    Module:        { label: 'File',         short: 'file',  color: '#8b949e' },
    File:          { label: 'File',         short: 'file',  color: '#8b949e' },
    ExternalDep:   { label: 'Dependency',   short: 'dep',   color: '#6e7681' },
    ApiEndpoint:   { label: 'API Route',    short: 'api',   color: '#f97316' },
    DbTable:       { label: 'DB Table',     short: 'db',    color: '#06b6d4' },
    DbColumn:      { label: 'DB Column',    short: 'col',   color: '#22d3ee' },
};
const NODE_DISPLAY_DEFAULT = { label: 'Symbol', short: '•', color: '#aaaaaa' };

const EDGE_DISPLAY: Record<string, { label: string; color: string }> = {
    calls:          { label: 'calls',         color: '#56d364' },
    uses_type:      { label: 'uses',          color: '#58a6ff' },
    implements:     { label: 'implements',    color: '#bc8cff' },
    inherits:       { label: 'extends',       color: '#ff9f43' },
    imports:        { label: 'imports',       color: '#63e2b7' },
    exports:        { label: 'exports',       color: '#f0c674' },
    defines:        { label: 'defines',       color: '#94a3b8' },
    handles_route:  { label: 'handles',       color: '#f97316' },
    protected_by:   { label: 'auth',          color: '#ef4444' },
    queries_table:  { label: 'queries',       color: '#06b6d4' },
    queries_column: { label: 'touches col',   color: '#22d3ee' },
    has_column:     { label: 'has column',    color: '#67e8f9' },
    depends_on:     { label: 'depends on',    color: '#6e7681' },
    uses_library:   { label: 'uses lib',      color: '#d2a8ff' },
};
const EDGE_DEFAULT = { label: 'related', color: '#444' };

function nodeInfo(type: string) { return NODE_DISPLAY[type] || NODE_DISPLAY_DEFAULT; }
function edgeInfo(rel: string)  { return EDGE_DISPLAY[rel]  || EDGE_DEFAULT; }

export class GraphViewProvider implements vscode.WebviewViewProvider {
    private webviewView?: vscode.WebviewView;
    public panelWebview?: vscode.Webview;

    constructor(
        private context: vscode.ExtensionContext,
        private logthreadService: LogThreadService
    ) {}

    public getHtmlForPanel(webview: vscode.Webview): string {
        return this.getHtmlContent();
    }

    public attachPanel(panel: vscode.WebviewPanel): void {
        this.panelWebview = panel.webview;
        panel.webview.onDidReceiveMessage(async (msg) => {
            switch (msg.type) {
                case 'navigateTo':      await this.handleNavigateTo(msg.nodeId);  break;
                case 'openFile':        await this.handleOpenFile(msg.nodeId);    break;
                case 'runImpactAnalysis': await this.handleImpactAnalysis(msg.nodeId); break;
                case 'search':          await this.handleSearch(msg.query);       break;
                case 'loadDefaultGraph': await this.loadDefaultGraph();           break;
                case 'loadMoreLinks':   await this.handleNavigateTo(msg.nodeId, msg.expansionLevel || 2, false); break;
                case 'cloudSync':       await this.handleCloudSync();             break;
                case 'openFullGraph':   await this.openFullGraph();               break;
            }
        });
        panel.onDidDispose(() => {
            this.panelWebview = undefined;
        });
        // Send initial graph data to the panel
        this.loadDefaultGraph();
    }

    public sendStatusUpdate(status: string, message: string): void {
        const msg = { type: 'statusUpdate', status, message };
        this.webviewView?.webview.postMessage(msg);
        this.panelWebview?.postMessage(msg);
    }

    public sendGraphStats(symbols: number): void {
        const msg = { type: 'graphStats', symbols };
        this.webviewView?.webview.postMessage(msg);
        this.panelWebview?.postMessage(msg);
    }

    // ── Load overview graph (called after analysis) ───────────────────────────
    public async loadDefaultGraph(): Promise<void> {
        if (!this.webviewView && !this.panelWebview) return;
        try {
            let nodes: any[] = [];
            let edges: any[] = [];

            // Priority 1: Try to get entry points and their dependencies
            // Entry points: main functions, API endpoints, exported functions, CLI entry points
            for (const q of [
                // Get API endpoints and their immediate dependencies
                "MATCH (n:ApiEndpoint)-[r:CodeRelation]->(m) WHERE r.rel_type IN ['calls', 'queries_table', 'queries_column', 'uses_library', 'depends_on', 'has_column'] RETURN n.id AS src_id, n.name AS src_name, labels(n)[0] AS src_type, r.rel_type AS rel, m.id AS tgt_id, m.name AS tgt_name, labels(m)[0] AS tgt_type, n.file_path AS src_file, m.file_path AS tgt_file LIMIT 50",
                // Get main/entry functions and their call graph
                "MATCH (n)-[r:CodeRelation]->(m) WHERE (n.name =~ '.*main.*' OR n.name =~ '.*entry.*' OR n.name =~ '.*init.*' OR n.name =~ '.*start.*') AND (n:Function OR n:Method) AND r.rel_type IN ['calls', 'uses_type', 'imports'] RETURN n.id AS src_id, n.name AS src_name, labels(n)[0] AS src_type, r.rel_type AS rel, m.id AS tgt_id, m.name AS tgt_name, labels(m)[0] AS tgt_type, n.file_path AS src_file, m.file_path AS tgt_file LIMIT 50",
                // Get exported functions and classes (public API)
                "MATCH (n)-[r:CodeRelation]->(m) WHERE r.rel_type = 'exports' RETURN n.id AS src_id, n.name AS src_name, labels(n)[0] AS src_type, r.rel_type AS rel, m.id AS tgt_id, m.name AS tgt_name, labels(m)[0] AS tgt_type, n.file_path AS src_file, m.file_path AS tgt_file LIMIT 40",
            ]) {
                try {
                    const raw = await this.logthreadService.runCypher(q);
                    const result = this.parseCypherGraphResult(raw);
                    if (result.nodes.length > 0) { 
                        nodes = result.nodes; 
                        edges = result.edges; 
                        break; 
                    }
                } catch { /* try next */ }
            }

            // Priority 2: If no entry points found, get general overview
            if (nodes.length === 0) {
                for (const q of [
                    "MATCH (n)-[r:CodeRelation]->(m) WHERE (n:Function OR n:Method OR n:Class OR n:Interface OR n:ApiEndpoint OR n:DbTable OR n:DbColumn OR n:File) AND (r.rel_type = 'calls' OR r.rel_type = 'imports' OR r.rel_type = 'extends' OR r.rel_type = 'implements' OR r.rel_type = 'uses_library' OR r.rel_type = 'depends_on' OR r.rel_type = 'handles_route' OR r.rel_type = 'queries_table' OR r.rel_type = 'queries_column' OR r.rel_type = 'has_column') RETURN n.id AS src_id, n.name AS src_name, labels(n)[0] AS src_type, r.rel_type AS rel, m.id AS tgt_id, m.name AS tgt_name, labels(m)[0] AS tgt_type, n.file_path AS src_file, m.file_path AS tgt_file LIMIT 80",
                    "MATCH (n)-[r:CodeRelation]->(m) WHERE (n:Function OR n:Method OR n:Class OR n:Interface OR n:ApiEndpoint OR n:DbTable OR n:DbColumn) RETURN n.id AS src_id, n.name AS src_name, labels(n)[0] AS src_type, r.rel_type AS rel, m.id AS tgt_id, m.name AS tgt_name, labels(m)[0] AS tgt_type, n.file_path AS src_file, m.file_path AS tgt_file LIMIT 60",
                ]) {
                    try {
                        const raw = await this.logthreadService.runCypher(q);
                        const result = this.parseCypherGraphResult(raw);
                        if (result.nodes.length > 0) { nodes = result.nodes; edges = result.edges; break; }
                    } catch { /* try next */ }
                }
            }

            // Fallback: collect all symbol nodes per table (avoids unsupported MATCH (n) without label)
            if (nodes.length === 0) {
                for (const table of ['ApiEndpoint', 'Function', 'Method', 'Class', 'Interface', 'DbTable', 'DbColumn', 'ExternalDep', 'Variable']) {
                    try {
                        const raw = await this.logthreadService.runCypher(
                            `MATCH (n:${table}) WHERE n.name IS NOT NULL RETURN n.id AS id, n.name AS name, '${table}' AS type, n.file_path AS file LIMIT 20`
                        );
                        nodes = nodes.concat(this.parseSimpleNodeResult(raw));
                    } catch { /* skip this table */ }
                }
            }

            // Mark entry points for special rendering
            nodes.forEach(n => {
                n.isEntryPoint = n.type === 'ApiEndpoint' || 
                                 (n.type === 'Function' && (((n.name || n.id).includes('main')) || ((n.name || n.id).includes('entry')) || ((n.name || n.id).includes('init')) || ((n.name || n.id).includes('start'))));
            });

            const overview = this.buildOverviewGraph(nodes, edges);

            const graphMsg = {
                type: 'graphData',
                nodes: overview.nodes.map(n => this.enrichNode(n)),
                edges: overview.edges.map(e => this.enrichEdge(e)),
                title: 'Overview',
                isRoot: true,
                summary: {
                    mode: 'overview',
                    nodeCount: overview.nodes.length,
                    edgeCount: overview.edges.length,
                },
            };
            this.webviewView?.webview.postMessage(graphMsg);
            this.panelWebview?.postMessage(graphMsg);
        } catch { /* silently handle */ }
    }

    // ── Navigate into a node's neighborhood ───────────────────────────────────
    private async handleNavigateTo(nodeId: string, expansionLevel: number = 1, _pushHistory: boolean = true): Promise<void> {
        if (!nodeId || (!this.webviewView && !this.panelWebview)) return;
        try {
            const context = await this.logthreadService.getContext(nodeId).catch(() => null);
            const { nodes, edges, summary } = await this.buildNeighborhoodGraph(nodeId, context, expansionLevel);
            const nodeDetails = await this.buildNodeDetails(nodeId, nodes, edges, context, summary);
            const navMsg = {
                type: 'graphData',
                nodes: nodes.map(n => this.enrichNode(n)),
                edges: edges.map(e => this.enrichEdge(e)),
                title: nodeDetails?.name || context?.name || nodeId,
                focusNode: nodeId,
                isRoot: false,
                nodeDetails,
                summary: {
                    mode: 'focus',
                    nodeCount: nodes.length,
                    edgeCount: edges.length,
                    expansionLevel,
                    hasMore: summary.hasMore,
                },
            };
            this.webviewView?.webview.postMessage(navMsg);
            this.panelWebview?.postMessage(navMsg);
        } catch { /* silently handle */ }
    }

    private async buildNeighborhoodGraph(nodeId: string, context: any, expansionLevel: number): Promise<{ nodes: any[]; edges: any[]; summary: any }> {
        const nodeMap = new Map<string, any>();
        const edges: any[] = [];
        let hasMore = false;

        if (this.isApiLikeNode(nodeId, context)) {
            const traceSummary = await this.collectApiTrace(nodeId, nodeMap, edges, expansionLevel);
            hasMore = traceSummary.hasMore;
        } else {
            const safe = this.escapeCypherString(nodeId);
            const limit = expansionLevel >= 2 ? 60 : 30;
            for (const q of [
                `MATCH (n)-[r:CodeRelation]->(m) WHERE n.id = "${safe}" RETURN n.id AS src_id, n.name AS src_name, labels(n)[0] AS src_type, r.rel_type AS rel, m.id AS tgt_id, m.name AS tgt_name, labels(m)[0] AS tgt_type, n.file_path AS src_file, m.file_path AS tgt_file LIMIT ${limit + 1}`,
                `MATCH (n)-[r:CodeRelation]->(m) WHERE m.id = "${safe}" RETURN n.id AS src_id, n.name AS src_name, labels(n)[0] AS src_type, r.rel_type AS rel, m.id AS tgt_id, m.name AS tgt_name, labels(m)[0] AS tgt_type, n.file_path AS src_file, m.file_path AS tgt_file LIMIT ${Math.floor(limit * 0.66) + 1}`,
            ]) {
                try {
                    const raw = await this.logthreadService.runCypher(q);
                    const result = this.parseCypherGraphResult(raw);
                    if (result.edges.length >= limit) hasMore = true;
                    this.mergeGraphResult(result, nodeMap, edges);
                } catch { /* try next */ }
            }
        }

        if (!nodeMap.has(nodeId)) {
            nodeMap.set(nodeId, {
                id: nodeId,
                name: context?.name || nodeId,
                type: context?.type || 'Function',
                file: context?.filePath || '',
                isEntryPoint: context?.type === 'ApiEndpoint',
            });
        }

        return {
            nodes: Array.from(nodeMap.values()),
            edges,
            summary: { hasMore, expansionLevel },
        };
    }

    private async collectApiTrace(nodeId: string, nodeMap: Map<string, any>, edges: any[], expansionLevel: number): Promise<{ hasMore: boolean }> {
        const relFilter = "['calls', 'imports', 'defines', 'depends_on', 'uses_library', 'queries_table', 'queries_column', 'has_column', 'handles_route', 'protected_by', 'uses_type']";
        const traversableTypes = new Set(['Function', 'Method', 'Class', 'Interface', 'TypeAlias', 'Module', 'File', 'ApiEndpoint', 'DbTable', 'DbColumn', 'ExternalDep']);
        const expanded = new Set<string>();
        let frontier = [nodeId];
        let hasMore = false;
        const maxDepth = Math.min(2 + Math.max(1, expansionLevel), 5);

        for (let depth = 0; depth < maxDepth && frontier.length > 0; depth++) {
            const nextFrontier = new Set<string>();

            for (const current of frontier) {
                if (expanded.has(current)) continue;
                expanded.add(current);

                const safe = this.escapeCypherString(current);
                const limit = depth === 0 ? (expansionLevel >= 2 ? 32 : 18) : (expansionLevel >= 2 ? 18 : 10);

                try {
                    const nodeMatch = `MATCH (n)-[r:CodeRelation]->(m) WHERE n.id = "${safe}"`;
                    const raw = await this.logthreadService.runCypher(
                        `${nodeMatch} AND r.rel_type IN ${relFilter} RETURN n.id AS src_id, n.name AS src_name, labels(n)[0] AS src_type, r.rel_type AS rel, m.id AS tgt_id, m.name AS tgt_name, labels(m)[0] AS tgt_type, n.file_path AS src_file, m.file_path AS tgt_file LIMIT ${limit + 1}`
                    );
                    const result = this.parseCypherGraphResult(raw);
                    if (result.edges.length >= limit) hasMore = true;
                    this.mergeGraphResult(result, nodeMap, edges);

                    for (const edge of result.edges) {
                        const target = nodeMap.get(edge.to);
                        if (target && traversableTypes.has(target.type) && !expanded.has(target.id)) {
                            nextFrontier.add(target.id);
                        }
                    }
                } catch { /* skip branch */ }

                if (depth === 0) {
                    try {
                        const incomingRaw = await this.logthreadService.runCypher(
                            `MATCH (n)-[r:CodeRelation]->(m) WHERE m.id = "${safe}" AND r.rel_type IN ['handles_route', 'protected_by', 'calls', 'depends_on', 'imports', 'defines'] RETURN n.id AS src_id, n.name AS src_name, labels(n)[0] AS src_type, r.rel_type AS rel, m.id AS tgt_id, m.name AS tgt_name, labels(m)[0] AS tgt_type, n.file_path AS src_file, m.file_path AS tgt_file LIMIT 13`
                        );
                        const incomingResult = this.parseCypherGraphResult(incomingRaw);
                        if (incomingResult.edges.length >= 12) hasMore = true;
                        this.mergeGraphResult(incomingResult, nodeMap, edges);
                    } catch { /* no incoming */ }
                }
            }

            frontier = Array.from(nextFrontier).slice(0, depth === 0 ? 12 : 8);
        }

        return { hasMore };
    }

    private isApiLikeNode(nodeId: string, context: any): boolean {
        if (context?.type === 'ApiEndpoint') return true;
        if (/^api_endpoint:/i.test(nodeId)) return true;
        return /^(GET|POST|PUT|PATCH|DELETE|USE|VIEW|ANY):/i.test(context?.name || '');
    }

    private mergeGraphResult(result: { nodes: any[]; edges: any[] }, nodeMap: Map<string, any>, edges: any[]): void {
        for (const node of result.nodes) {
            const existing = nodeMap.get(node.id);
            nodeMap.set(node.id, { ...(existing || {}), ...node });
        }
        for (const edge of result.edges) {
            if (!edges.find((existing) => existing.from === edge.from && existing.to === edge.to && existing.label === edge.label)) {
                edges.push(edge);
            }
        }
    }

    private escapeCypherString(value: string): string {
        return String(value || '').replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    }

    private buildOverviewGraph(nodes: any[], edges: any[]): { nodes: any[]; edges: any[] } {
        if (nodes.length <= 30) return { nodes, edges };

        const nodeMap = new Map(nodes.map((node) => [node.id, node]));
        const degree = new Map<string, number>();
        nodes.forEach((node) => degree.set(node.id, 0));
        edges.forEach((edge) => {
            degree.set(edge.from, (degree.get(edge.from) || 0) + 1);
            degree.set(edge.to, (degree.get(edge.to) || 0) + 1);
        });

        const keep = new Set<string>();
        const typeBuckets = new Map<string, any[]>();
        for (const node of nodes) {
            if (node.isEntryPoint) keep.add(node.id);
            const bucket = typeBuckets.get(node.type || 'Unknown') || [];
            bucket.push(node);
            typeBuckets.set(node.type || 'Unknown', bucket);
        }

        for (const bucket of typeBuckets.values()) {
            bucket.sort((a, b) => (degree.get(b.id) || 0) - (degree.get(a.id) || 0));
            for (const node of bucket.slice(0, 5)) keep.add(node.id);
        }

        const ranked = nodes
            .slice()
            .sort((a, b) => (degree.get(b.id) || 0) - (degree.get(a.id) || 0));
        for (const node of ranked) {
            if (keep.size >= 32) break;
            keep.add(node.id);
        }

        const bridgeCounts = new Map<string, number>();
        for (const edge of edges) {
            const fromKept = keep.has(edge.from);
            const toKept = keep.has(edge.to);
            if (fromKept !== toKept) {
                const bridgeId = fromKept ? edge.to : edge.from;
                bridgeCounts.set(bridgeId, (bridgeCounts.get(bridgeId) || 0) + 1);
            }
        }
        for (const [bridgeId] of Array.from(bridgeCounts.entries()).sort((a, b) => b[1] - a[1]).slice(0, 8)) {
            keep.add(bridgeId);
        }

        const filteredEdges = edges.filter((edge) => keep.has(edge.from) && keep.has(edge.to));
        const connectedIds = new Set<string>();
        filteredEdges.forEach((edge) => {
            connectedIds.add(edge.from);
            connectedIds.add(edge.to);
        });

        const filteredNodes = Array.from(keep)
            .filter((id) => connectedIds.has(id) || (nodeMap.get(id)?.isEntryPoint))
            .map((id) => nodeMap.get(id))
            .filter(Boolean) as any[];

        return {
            nodes: filteredNodes,
            edges: filteredEdges.slice(0, 72),
        };
    }

    private async buildNodeDetails(nodeId: string, nodes: any[], edges: any[], existingContext?: any, summary?: any): Promise<any> {
        const focal = nodes.find((node) => node.id === nodeId) || { id: nodeId, name: existingContext?.name || nodeId, type: 'Function', file: '' };
        const incoming = this.collectNeighborObjects(nodeId, nodes, edges, 'in');
        const outgoing = this.collectNeighborObjects(nodeId, nodes, edges, 'out');
        const typeLinks = this.collectTypedReachableNodes(nodeId, nodes, edges, new Set(['Class', 'Interface', 'TypeAlias']), 2, 12);
        const tables = this.collectTypedReachableNodes(nodeId, nodes, edges, new Set(['DbTable']), 4, 12);
        const columns = this.collectTypedReachableNodes(nodeId, nodes, edges, new Set(['DbColumn']), 5, 16);
        const files = this.collectTypedReachableNodes(nodeId, nodes, edges, new Set(['File', 'Module']), 3, 10);
        const libraries = this.collectTypedReachableNodes(nodeId, nodes, edges, new Set(['ExternalDep']), 3, 10);

        try {
            const [context, impact] = await Promise.all([
                existingContext ? Promise.resolve(existingContext) : this.logthreadService.getContext(nodeId),
                this.logthreadService.getImpact(nodeId, 3),
            ]);

            return {
                id: nodeId,
                name: focal.name || context?.name || nodeId,
                type: context?.type || focal.type || 'Symbol',
                file: context?.filePath || focal.file || '',
                signature: context?.signature || '',
                callers: incoming.slice(0, 20),
                callees: outgoing.slice(0, 20),
                typeRefs: typeLinks,
                tables,
                columns,
                files,
                libraries,
                impact: impact ? {
                    affectedCount: impact.affectedCount,
                    direct: impact.direct?.length || 0,
                    indirect: impact.indirect?.length || 0,
                    transitive: impact.transitive?.length || 0,
                } : null,
                hasMore: !!summary?.hasMore,
                expansionLevel: summary?.expansionLevel || 1,
            };
        } catch {
            return {
                id: nodeId,
                name: focal.name || nodeId,
                type: focal.type || 'Symbol',
                file: focal.file || '',
                signature: '',
                callers: incoming,
                callees: outgoing,
                typeRefs: typeLinks,
                tables,
                columns,
                files,
                libraries,
                impact: null,
                hasMore: !!summary?.hasMore,
                expansionLevel: summary?.expansionLevel || 1,
            };
        }
    }

    private collectNeighborObjects(nodeId: string, nodes: any[], edges: any[], direction: 'in' | 'out'): any[] {
        const lookup = new Map(nodes.map((node) => [node.id, node]));
        const seen = new Set<string>();
        const ordered: any[] = [];
        for (const edge of edges) {
            const otherId = direction === 'in'
                ? (edge.to === nodeId ? edge.from : '')
                : (edge.from === nodeId ? edge.to : '');
            if (!otherId || seen.has(otherId)) continue;
            const node = lookup.get(otherId);
            if (!node) continue;
            seen.add(otherId);
            ordered.push(this.enrichNode(node));
        }
        return ordered;
    }

    private collectTypedReachableNodes(nodeId: string, nodes: any[], edges: any[], targetTypes: Set<string>, maxDepth: number, limit: number): any[] {
        const lookup = new Map(nodes.map((node) => [node.id, node]));
        const seenNodes = new Set<string>([nodeId]);
        const found = new Set<string>();
        let frontier = [nodeId];
        const ordered: any[] = [];

        for (let depth = 0; depth < maxDepth && frontier.length > 0 && ordered.length < limit; depth++) {
            const next: string[] = [];
            for (const current of frontier) {
                for (const edge of edges) {
                    let neighborId = '';
                    if (edge.from === current) neighborId = edge.to;
                    else if (edge.to === current) neighborId = edge.from;
                    if (!neighborId || seenNodes.has(neighborId)) continue;
                    seenNodes.add(neighborId);
                    const neighbor = lookup.get(neighborId);
                    if (!neighbor) continue;
                    if (targetTypes.has(neighbor.type) && !found.has(neighborId)) {
                        found.add(neighborId);
                        ordered.push(this.enrichNode(neighbor));
                        if (ordered.length >= limit) break;
                    }
                    next.push(neighborId);
                }
                if (ordered.length >= limit) break;
            }
            frontier = next;
        }

        return ordered;
    }

    // ── Enrich nodes/edges with display-friendly metadata ────────────────────
    private enrichNode(n: any) {
        const info = nodeInfo(n.type || '');
        const title = this.resolveNodeTitle(n);
        const subtitle = this.resolveNodeSubtitle(n);
        return {
            ...n,
            displayLabel: info.label,
            shortLabel:   info.short,
            color:        info.color,
            isEntryPoint: n.isEntryPoint || false,
            title,
            subtitle,
        };
    }
    private enrichEdge(e: any) {
        const info = edgeInfo(e.label || e.rel || '');
        return {
            ...e,
            displayLabel: info.label,
            color:        info.color,
        };
    }

    private resolveNodeTitle(n: any): string {
        const filePath = String(n.file || '');
        const fileName = filePath ? filePath.split('/').pop() || filePath : '';
        if (n.type === 'File' || n.type === 'Module') return fileName || n.name || n.id;
        if (n.type === 'Folder') return fileName || n.name || n.id;
        if (n.type === 'DbColumn') {
            const tableName = n.table || '';
            return tableName ? `${tableName}.${n.name || n.id}` : (n.name || n.id);
        }
        return n.name || n.id;
    }

    private resolveNodeSubtitle(n: any): string {
        const filePath = String(n.file || '');
        if (n.type === 'File' || n.type === 'Module') return filePath;
        if (n.type === 'ApiEndpoint') return filePath || (n.type || 'API Route');
        if (n.type === 'DbTable' || n.type === 'DbColumn') return filePath || 'database';
        return filePath || (n.type || 'Symbol');
    }

    // ── Cypher result parsers ─────────────────────────────────────────────────
    private parseSimpleNodeResult(raw: string): any[] {
        const nodes: any[] = [];
        for (const line of raw.split('\n')) {
            const t = line.trim();
            if (!t || t.startsWith('Results') || t.startsWith('---') || t.startsWith('name') || t.startsWith('id')) continue;
            const m = t.match(/^\d+\.\s*([^\|]+)\s*\|\s*([^\|]+)\s*\|\s*([^\|]+)\s*\|\s*(.*)?$/);
            if (m) {
                const id = m[1].trim();
                const name = m[2].trim();
                if (id && id !== 'None') nodes.push({ id, name, type: m[3].trim(), file: m[4]?.trim() || '' });
                continue;
            }
            if (t.startsWith('{')) {
                try {
                    const obj = JSON.parse(t);
                    if (obj.id || obj.name) nodes.push({ id: obj.id || obj.name, name: obj.name || obj.id, type: obj.type || 'Unknown', file: obj.file_path || '' });
                } catch { /* skip */ }
            }
        }
        return nodes;
    }

    private parseCypherGraphResult(raw: string): { nodes: any[]; edges: any[] } {
        const nodeMap = new Map<string, any>();
        const edges: any[] = [];
        for (const line of raw.split('\n')) {
            const t = line.trim();
            if (!t || t.startsWith('Results') || t.startsWith('---') || t.startsWith('src')) continue;
            // 9-col: src_id | src_name | src_type | rel | tgt_id | tgt_name | tgt_type | src_file | tgt_file
            let m = t.match(/^\d+\.\s*([^\|]+)\s*\|\s*([^\|]+)\s*\|\s*([^\|]+)\s*\|\s*([^\|]+)\s*\|\s*([^\|]+)\s*\|\s*([^\|]+)\s*\|\s*([^\|]+)(?:\s*\|\s*([^\|]*))?(?:\s*\|\s*(.*))?$/);
            if (m) {
                const [, srcId, srcName, srcType, rel, tgtId, tgtName, tgtType, srcFile, tgtFile] = m;
                const s = srcId.trim(), tt = tgtId.trim();
                if (s && s !== 'None' && tt && tt !== 'None') {
                    if (!nodeMap.has(s)) nodeMap.set(s, { id: s, name: srcName.trim(), type: srcType.trim(), file: srcFile?.trim() || '' });
                    if (!nodeMap.has(tt)) nodeMap.set(tt, { id: tt, name: tgtName.trim(), type: tgtType.trim(), file: tgtFile?.trim() || '' });
                    edges.push({ from: s, to: tt, label: rel.trim() });
                }
            }
        }
        return { nodes: Array.from(nodeMap.values()), edges };
    }

    // ── WebviewView wiring ────────────────────────────────────────────────────
    resolveWebviewView(
        webviewView: vscode.WebviewView,
        _context: vscode.WebviewViewResolveContext,
        _token: vscode.CancellationToken
    ): void {
        this.webviewView = webviewView;
        webviewView.webview.options = { enableScripts: true, localResourceRoots: [this.context.extensionUri] };
        webviewView.webview.html = this.getHtmlContent();

        webviewView.webview.onDidReceiveMessage(async (msg) => {
            switch (msg.type) {
                case 'navigateTo':      await this.handleNavigateTo(msg.nodeId);  break;
                case 'openFile':        await this.handleOpenFile(msg.nodeId);    break;
                case 'runImpactAnalysis': await this.handleImpactAnalysis(msg.nodeId); break;
                case 'search':          await this.handleSearch(msg.query);       break;
                case 'loadDefaultGraph': await this.loadDefaultGraph();           break;
                case 'loadMoreLinks':   await this.handleNavigateTo(msg.nodeId, msg.expansionLevel || 2, false); break;
                case 'cloudSync':       await this.handleCloudSync();             break;
                case 'openFullGraph':   await this.openFullGraph();               break;
            }
        });
    }

    private async handleOpenFile(nodeId: string): Promise<void> {
        if (!nodeId) return;
        try {
            const context = await this.logthreadService.getContext(nodeId);
            if (context?.filePath) {
                let fp = context.filePath;
                const folders = vscode.workspace.workspaceFolders;
                if (folders && !fp.startsWith('/')) fp = vscode.Uri.joinPath(folders[0].uri, fp).fsPath;
                const doc  = await vscode.workspace.openTextDocument(fp);
                const editor = await vscode.window.showTextDocument(doc);
                const line = Math.max(0, (context.startLine || 1) - 1);
                const pos  = new vscode.Position(line, 0);
                editor.selection = new vscode.Selection(pos, pos);
                editor.revealRange(new vscode.Range(pos, pos), vscode.TextEditorRevealType.InCenter);
            }
        } catch { /* node may not have a source file */ }
    }

    private async handleSearch(query: string): Promise<void> {
        const results = await this.logthreadService.query(query, 10);
        const searchMsg = { type: 'searchResults', results };
        this.webviewView?.webview.postMessage(searchMsg);
        this.panelWebview?.postMessage(searchMsg);
    }

    private async handleImpactAnalysis(nodeId: string): Promise<void> {
        if (!nodeId) return;
        try {
            const impact = await this.logthreadService.getImpact(nodeId);
            if (!impact) {
                vscode.window.showInformationMessage(`No impact data found for ${nodeId}`);
                return;
            }

            const panel = vscode.window.createWebviewPanel(
                'logthreadImpact',
                `Impact Analysis: ${nodeId}`,
                vscode.ViewColumn.Two,
                { enableScripts: true }
            );
            panel.webview.html = this.generateImpactHtml(impact);
        } catch {
            vscode.window.showErrorMessage(`Could not load impact analysis for ${nodeId}`);
        }
    }

    private async openFullGraph(): Promise<void> {
        const folders = vscode.workspace.workspaceFolders;
        try {
            const url = folders ? this.logthreadService.getCloudExploreUrl(folders[0].uri.fsPath) : 'https://logthread.dev/dashboard';
            vscode.env.openExternal(vscode.Uri.parse(url));
        } catch {
            vscode.env.openExternal(vscode.Uri.parse('https://logthread.dev/dashboard'));
        }
    }

    private async handleCloudSync(): Promise<void> {
        const folders = vscode.workspace.workspaceFolders;
        if (!folders) { vscode.window.showWarningMessage('No workspace folder open'); return; }
        if (!this.logthreadService.isLoggedIn) {
            const r = await vscode.window.showInformationMessage('Log in to sync your code map', 'Login');
            if (r === 'Login') await this.logthreadService.login();
            return;
        }
        if (!this.logthreadService.hasCloudSyncConsent()) {
            const c = await vscode.window.showInformationMessage(
                'Sync your code map to Log Thread Cloud?\n\nYour source code is never uploaded — only the structural map is synced.',
                { modal: true }, 'View Terms', 'View Privacy', 'I Agree'
            );
            if (c === 'View Terms')    { vscode.env.openExternal(vscode.Uri.parse('https://logthread.dev/terms'));   return; }
            if (c === 'View Privacy')  { vscode.env.openExternal(vscode.Uri.parse('https://logthread.dev/privacy')); return; }
            if (c !== 'I Agree')       return;
            this.logthreadService.saveCloudSyncConsent();
        }
        await vscode.window.withProgress(
            { location: vscode.ProgressLocation.Notification, title: 'Syncing code map…', cancellable: false },
            async () => {
                try {
                    const ok = await this.logthreadService.syncToCloud(folders[0].uri.fsPath);
                    if (ok) {
                        const url = this.logthreadService.getCloudExploreUrl(folders[0].uri.fsPath);
                        vscode.window.showInformationMessage('Code map synced!', 'Open in Browser')
                            .then(s => { if (s === 'Open in Browser') vscode.env.openExternal(vscode.Uri.parse(url)); });
                    } else {
                        vscode.window.showErrorMessage('Sync failed. Check the output panel for details.');
                    }
                } catch {
                    vscode.window.showErrorMessage('Sync failed. Check the output panel for details.');
                }
            }
        );
    }

    private generateImpactHtml(impact: any): string {
        const directCallers = impact.direct?.map((s: string) => `<li class="direct">${s}</li>`).join('') || '';
        const indirectCallers = impact.indirect?.map((s: string) => `<li class="indirect">${s}</li>`).join('') || '';
        const transitive = impact.transitive?.map((s: string) => `<li class="transitive">${s}</li>`).join('') || '';

        return `<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: var(--vscode-font-family); padding: 20px; color: var(--vscode-foreground); background: var(--vscode-editor-background); }
        h1, h2 { color: var(--vscode-foreground); }
        ul { list-style: none; padding: 0; margin: 0; }
        li { padding: 8px 12px; margin: 4px 0; border-radius: 4px; }
        .direct { background: rgba(239, 68, 68, 0.2); border-left: 3px solid #ef4444; }
        .indirect { background: rgba(245, 158, 11, 0.2); border-left: 3px solid #f59e0b; }
        .transitive { background: rgba(59, 130, 246, 0.2); border-left: 3px solid #3b82f6; }
        .section { margin-bottom: 24px; }
        .count { color: var(--vscode-descriptionForeground); font-size: 12px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <h1>Impact Analysis: ${impact.symbol}</h1>
    <p class="count">Total affected: ${impact.affectedCount} symbols</p>

    <div class="section">
        <h2>Direct Callers</h2>
        <ul>${directCallers || '<li>None</li>'}</ul>
    </div>

    <div class="section">
        <h2>Indirect Callers</h2>
        <ul>${indirectCallers || '<li>None</li>'}</ul>
    </div>

    <div class="section">
        <h2>Transitive Review Set</h2>
        <ul>${transitive || '<li>None</li>'}</ul>
    </div>
</body>
</html>`;
    }

    // ── HTML / JS graph renderer ──────────────────────────────────────────────
    private getHtmlContent(): string {
        return `<!DOCTYPE html><html><head><style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:var(--vscode-font-family);background:var(--vscode-editor-background);color:var(--vscode-foreground);height:100vh;display:flex;flex-direction:column;overflow:hidden;font-size:12px}
.empty-state{display:none;flex-direction:column;align-items:center;justify-content:center;height:100%;padding:20px;text-align:center}
.empty-state.visible{display:flex}
.empty-icon{width:64px;height:64px;margin-bottom:16px;opacity:.5}
.empty-title{font-size:14px;font-weight:600;margin-bottom:8px;color:var(--vscode-foreground)}
.empty-message{font-size:12px;color:var(--vscode-descriptionForeground);margin-bottom:20px;line-height:1.5;max-width:280px}
.empty-button{background:var(--vscode-button-background);color:var(--vscode-button-foreground);border:none;padding:8px 16px;border-radius:4px;cursor:pointer;font-size:12px;font-family:inherit;font-weight:500;display:flex;align-items:center;gap:8px;transition:background .1s}
.empty-button:hover{background:var(--vscode-button-hoverBackground)}
.empty-button svg{width:16px;height:16px}
.topbar{display:flex;align-items:center;gap:6px;padding:5px 8px;border-bottom:1px solid var(--vscode-panel-border);flex-shrink:0;min-height:32px}
.back-btn{background:transparent;border:1px solid var(--vscode-panel-border);color:var(--vscode-foreground);border-radius:3px;padding:2px 8px;font-size:11px;cursor:pointer;font-family:inherit;opacity:.6;transition:opacity .1s}
.back-btn:hover{opacity:1;background:var(--vscode-toolbar-hoverBackground)}
.back-btn:disabled{opacity:.2;cursor:not-allowed}
.breadcrumb{flex:1;font-size:10.5px;color:var(--vscode-descriptionForeground);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.breadcrumb span{cursor:pointer;padding:1px 3px;border-radius:2px;transition:background .1s}
.breadcrumb span:hover{background:var(--vscode-toolbar-hoverBackground);color:var(--vscode-foreground)}
.breadcrumb .sep{opacity:.35;padding:0 2px;cursor:default}
.status-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0}
.status-dot.ready{background:#56d364}
.status-dot.analyzing{background:#f0c674;animation:blink 1s ease-in-out infinite}
.status-dot.error{background:#f85149}
@keyframes blink{0%,100%{opacity:.3}50%{opacity:1}}
.search-wrap{padding:5px 8px;border-bottom:1px solid var(--vscode-panel-border);flex-shrink:0}
.search-wrap input{width:100%;background:var(--vscode-input-background);color:var(--vscode-input-foreground);border:1px solid var(--vscode-input-border,var(--vscode-panel-border));border-radius:4px;padding:4px 8px;font-size:11.5px;font-family:inherit}
.search-wrap input:focus{outline:1px solid var(--vscode-focusBorder)}
.search-wrap input::placeholder{color:var(--vscode-descriptionForeground);opacity:.5}
.graph-area{flex:1;position:relative;min-height:0;display:flex}
.graph-canvas-wrap{position:relative;flex:1;min-width:0;overflow:hidden}
#gc{width:100%;height:100%;display:block;cursor:grab;position:relative;z-index:1}
#gc:active{cursor:grabbing}
.sr{position:absolute;top:0;left:0;right:0;bottom:0;background:var(--vscode-editor-background);overflow-y:auto;z-index:10;padding:4px;display:none}
.sri{padding:6px 10px;border-radius:4px;cursor:pointer;margin-bottom:2px}
.sri:hover{background:var(--vscode-list-hoverBackground)}
.sri-name{font-weight:600;font-size:12px}
.sri-type{font-size:10px;color:var(--vscode-descriptionForeground);margin-left:6px;font-weight:400}
.sri-path{font-size:10px;color:var(--vscode-descriptionForeground);opacity:.6;margin-top:1px}
.tip{position:absolute;background:var(--vscode-editorHoverWidget-background,var(--vscode-editor-background));border:1px solid var(--vscode-editorHoverWidget-border,var(--vscode-panel-border));border-radius:6px;padding:8px 11px;font-size:11px;pointer-events:none;z-index:20;display:none;max-width:240px;box-shadow:0 4px 12px rgba(0,0,0,.35)}
.tip-name{font-weight:700;margin-bottom:2px;word-break:break-all;font-size:12px}
.tip-badge{font-size:9px;padding:1px 6px;border-radius:10px;display:inline-block;font-weight:700;letter-spacing:.4px;text-transform:uppercase;margin-bottom:5px}
.tip-file{font-size:10px;opacity:.55;word-break:break-all;margin-bottom:4px;font-family:monospace}
.tip-hint{font-size:9.5px;opacity:.4;margin-top:3px;border-top:1px solid rgba(255,255,255,.07);padding-top:4px}
.legend{position:absolute;bottom:40px;right:8px;display:flex;flex-direction:column;gap:4px;opacity:.75;pointer-events:none;background:rgba(0,0,0,.2);border-radius:5px;padding:6px 8px}
.li{display:flex;align-items:center;gap:5px;font-size:9.5px;color:var(--vscode-descriptionForeground)}
.ld{width:9px;height:9px;border-radius:50%;flex-shrink:0}
.view-badge{position:absolute;top:10px;left:10px;z-index:12;background:rgba(17,24,39,.9);border:1px solid rgba(148,163,184,.28);color:#dbeafe;padding:5px 10px;border-radius:999px;font-size:10px;font-weight:700;letter-spacing:.3px;text-transform:uppercase}
.loader{position:absolute;inset:0;display:none;align-items:center;justify-content:center;z-index:22;background:linear-gradient(180deg, rgba(2,6,23,.66), rgba(15,23,42,.78));backdrop-filter:blur(4px)}
.loader.visible{display:flex}
.loader-card{padding:18px 20px;border-radius:14px;border:1px solid rgba(125,211,252,.22);background:rgba(15,23,42,.92);box-shadow:0 16px 32px rgba(0,0,0,.25);min-width:220px}
.loader-row{display:flex;align-items:center;gap:12px}
.spinner{width:22px;height:22px;border-radius:50%;border:2px solid rgba(148,163,184,.24);border-top-color:#7dd3fc;animation:spin 1s linear infinite}
.loader-title{font-size:12px;font-weight:700;color:#e0f2fe}
.loader-copy{margin-top:6px;font-size:11px;color:#94a3b8}
@keyframes spin{to{transform:rotate(360deg)}}
.inspector{width:320px;max-width:42%;border-left:1px solid var(--vscode-panel-border);background:linear-gradient(180deg, rgba(15,23,42,.72), rgba(2,6,23,.88));display:none;flex-direction:column;overflow:hidden;position:relative;z-index:30;pointer-events:auto}
.inspector.visible{display:flex}
.inspector-head{padding:14px 14px 10px;border-bottom:1px solid rgba(148,163,184,.14)}
.inspector-kicker{font-size:10px;letter-spacing:.28em;text-transform:uppercase;color:#7dd3fc;margin-bottom:6px}
.inspector-title{font-size:16px;font-weight:700;line-height:1.25;word-break:break-word}
.inspector-sub{margin-top:6px;font-size:11px;color:var(--vscode-descriptionForeground);word-break:break-word}
.inspector-body{padding:12px 14px 16px;overflow:auto;display:flex;flex-direction:column;gap:14px}
.summary-card{padding:10px 12px;border:1px solid rgba(148,163,184,.16);border-radius:10px;background:rgba(15,23,42,.45)}
.summary-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
.summary-stat{padding:8px 9px;border-radius:8px;background:rgba(30,41,59,.55)}
.summary-stat strong{display:block;font-size:14px;color:#f8fafc}
.summary-stat span{display:block;margin-top:3px;font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:#94a3b8}
.section-title{font-size:10px;letter-spacing:.18em;text-transform:uppercase;color:#7dd3fc;margin-bottom:8px}
.action-row{display:flex;flex-wrap:wrap;gap:8px}
.action-row button{background:rgba(37,99,235,.18);color:#dbeafe;border:1px solid rgba(96,165,250,.35);padding:7px 10px;border-radius:8px;cursor:pointer;font-size:11px;font-weight:600}
.action-row button:hover{background:rgba(37,99,235,.28)}
.node-list{display:flex;flex-direction:column;gap:6px}
.node-link{display:flex;justify-content:space-between;gap:10px;align-items:center;padding:8px 9px;border-radius:8px;background:rgba(15,23,42,.4);border:1px solid rgba(148,163,184,.12);cursor:pointer;color:var(--vscode-foreground);font-size:11px;text-align:left}
.node-link:hover{background:rgba(30,41,59,.65)}
.node-link small{color:var(--vscode-descriptionForeground);font-size:10px}
.empty-note{font-size:11px;color:var(--vscode-descriptionForeground)}
.footer{padding:5px 8px;border-top:1px solid var(--vscode-panel-border);display:flex;gap:5px;flex-shrink:0}
.footer button{flex:1;background:var(--vscode-button-secondaryBackground);color:var(--vscode-button-secondaryForeground);border:none;padding:4px 6px;border-radius:4px;cursor:pointer;font-size:10.5px;font-family:inherit;font-weight:500;transition:background .1s}
.footer button:hover{background:var(--vscode-button-secondaryHoverBackground)}
.footer button.primary{background:var(--vscode-button-background);color:var(--vscode-button-foreground)}
.footer button.primary:hover{background:var(--vscode-button-hoverBackground)}
</style></head><body>

<div class="empty-state visible" id="emptyState">
  <svg class="empty-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <circle cx="12" cy="5" r="2" stroke-width="2"/>
    <circle cx="5" cy="12" r="2" stroke-width="2"/>
    <circle cx="19" cy="12" r="2" stroke-width="2"/>
    <circle cx="12" cy="19" r="2" stroke-width="2"/>
    <line x1="12" y1="7" x2="5" y2="10" stroke-width="1.5"/>
    <line x1="12" y1="7" x2="19" y2="10" stroke-width="1.5"/>
    <line x1="12" y1="17" x2="5" y2="14" stroke-width="1.5"/>
    <line x1="12" y1="17" x2="19" y2="14" stroke-width="1.5"/>
  </svg>
  <div class="empty-title">Code Explorer</div>
  <div class="empty-message">Visualize your codebase as an interactive graph. Analyze workspace to get started.</div>
  <button class="empty-button" onclick="vscode.postMessage({type:'loadDefaultGraph'})">
    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
    </svg>
    Open Code Explorer
  </button>
</div>

<div class="topbar" id="mainView" style="display:none">
  <button class="back-btn" id="backBtn" disabled onclick="goBack()">&#8592; Back</button>
  <div class="breadcrumb" id="breadcrumb"><span onclick="goHome()">Overview</span></div>
  <div class="status-dot ready" id="statusDot" title="Ready"></div>
</div>
<div class="search-wrap" style="display:none">
  <input type="text" id="searchInp" placeholder="Search functions, classes, variables&#8230;" />
</div>
<div class="graph-area" style="display:none">
  <div class="graph-canvas-wrap">
    <canvas id="gc"></canvas>
    <div class="sr" id="sr"></div>
    <div class="tip" id="tip"></div>
    <div class="loader" id="loader">
      <div class="loader-card">
        <div class="loader-row">
          <div class="spinner"></div>
          <div class="loader-title" id="loaderTitle">Loading code map…</div>
        </div>
        <div class="loader-copy" id="loaderCopy">Building the next graph view.</div>
      </div>
    </div>
    <div class="view-badge" id="viewBadge">Overview Map</div>
    <div class="legend" id="legend" style="display:none">
      <div class="li"><div class="ld" style="background:#56d364"></div>function / method</div>
      <div class="li"><div class="ld" style="background:#58a6ff"></div>class</div>
      <div class="li"><div class="ld" style="background:#bc8cff"></div>interface</div>
      <div class="li"><div class="ld" style="background:#63e2b7"></div>type</div>
      <div class="li"><div class="ld" style="background:#ff9f43"></div>variable</div>
      <div class="li"><div class="ld" style="background:#8b949e"></div>file / module</div>
      <div class="li"><div class="ld" style="background:#f97316"></div>API route</div>
      <div class="li"><div class="ld" style="background:#06b6d4"></div>DB table</div>
      <div class="li"><div class="ld" style="background:#d2a8ff"></div>library / dep</div>
    </div>
  </div>
  <aside class="inspector" id="inspector">
    <div class="inspector-head">
      <div class="inspector-kicker" id="inspectorKicker">Overview</div>
      <div class="inspector-title" id="inspectorTitle">Code Explorer</div>
      <div class="inspector-sub" id="inspectorSub">Select a node to see its neighborhood, impact, and actions.</div>
    </div>
    <div class="inspector-body" id="inspectorBody"></div>
  </aside>
</div>
<div class="footer" style="display:none">
  <button onclick="vscode.postMessage({type:'loadDefaultGraph'})">Overview</button>
  <button onclick="vscode.postMessage({type:'cloudSync'})">Sync</button>
  <button class="primary" onclick="vscode.postMessage({type:'openFullGraph'})">Open Full Map</button>
</div>

<script>
var vscode    = acquireVsCodeApi();
var emptyState = document.getElementById('emptyState');
var mainView  = document.getElementById('mainView');
var gc        = document.getElementById('gc');
var ctx       = gc.getContext('2d');
var tip       = document.getElementById('tip');
var sr        = document.getElementById('sr');
var leg       = document.getElementById('legend');
var backBtn   = document.getElementById('backBtn');
var breadcrumb= document.getElementById('breadcrumb');
var statusDot = document.getElementById('statusDot');
var searchInp = document.getElementById('searchInp');
var viewBadge = document.getElementById('viewBadge');
var inspector = document.getElementById('inspector');
var inspectorKicker = document.getElementById('inspectorKicker');
var inspectorTitle = document.getElementById('inspectorTitle');
var inspectorSub = document.getElementById('inspectorSub');
var inspectorBody = document.getElementById('inspectorBody');
var loader = document.getElementById('loader');
var loaderTitle = document.getElementById('loaderTitle');
var loaderCopy = document.getElementById('loaderCopy');

var nodes = [];
var edges = [];
var selNode = null;
var hovNode = null;
var currentFocusId = null;
var currentDetails = null;
var currentSummary = null;
var layoutMode = 'overview';
var offsetX = 0;
var offsetY = 0;
var scale = 1;
var dragging = false;
var dragNode = null;
var lastMx = { x: 0, y: 0 };
var clickNode = null;
var clickTime = 0;
var navHistory = [];
var currentTitle = 'Overview';

function snapshotState() {
    return {
        nodes: JSON.parse(JSON.stringify(nodes)),
        edges: JSON.parse(JSON.stringify(edges)),
        title: currentTitle,
        focusId: currentFocusId,
        details: currentDetails ? JSON.parse(JSON.stringify(currentDetails)) : null,
        summary: currentSummary ? JSON.parse(JSON.stringify(currentSummary)) : null
    };
}

function goBack() {
    if (navHistory.length === 0) return;
    var prev = navHistory.pop();
    currentTitle = prev.title || 'Overview';
    backBtn.disabled = navHistory.length === 0;
    updateBreadcrumb();
    applyGraphData(prev.nodes || [], prev.edges || [], prev.focusId || null, prev.details || null, prev.summary || null);
}

function goHome() {
    navHistory = [];
    currentFocusId = null;
    currentDetails = null;
    currentSummary = null;
    backBtn.disabled = true;
    updateBreadcrumb();
    setStatus('analyzing', 'Loading overview', 'Rebuilding the overview map for the workspace.');
    vscode.postMessage({ type: 'loadDefaultGraph' });
}

function updateBreadcrumb() {
    var parts = navHistory.map(function(h) { return h.title; });
    parts.push(currentTitle);
    var html = '';
    for (var i = 0; i < parts.length; i++) {
        if (i > 0) html += '<span class="sep">&#8250;</span>';
        var t = parts[i];
        var safe = esc(t.length > 22 ? t.slice(0, 20) + '..' : t);
        if (i === parts.length - 1) {
            html += '<span style="color:var(--vscode-foreground);opacity:.9;cursor:default">' + safe + '</span>';
        } else {
            html += '<span onclick="jumpHistory(' + i + ')">' + safe + '</span>';
        }
    }
    breadcrumb.innerHTML = html;
}

function jumpHistory(idx) {
    var target = navHistory[idx];
    if (!target) return;
    navHistory = navHistory.slice(0, idx);
    currentTitle = target.title || 'Overview';
    backBtn.disabled = navHistory.length === 0;
    updateBreadcrumb();
    applyGraphData(target.nodes || [], target.edges || [], target.focusId || null, target.details || null, target.summary || null);
}

function esc(s) {
    return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function lighten(hex, amount) {
    if (!hex || hex.length < 7) return hex || '#6e7681';
    var r = parseInt(hex.slice(1, 3), 16);
    var g = parseInt(hex.slice(3, 5), 16);
    var b = parseInt(hex.slice(5, 7), 16);
    r = Math.min(255, Math.round(r + (255 - r) * amount));
    g = Math.min(255, Math.round(g + (255 - g) * amount));
    b = Math.min(255, Math.round(b + (255 - b) * amount));
    return '#' + r.toString(16).padStart(2, '0') + g.toString(16).padStart(2, '0') + b.toString(16).padStart(2, '0');
}

function compactLabel(nodeOrText) {
    if (!nodeOrText) return '?';
    var raw = typeof nodeOrText === 'object'
        ? String(nodeOrText.title || nodeOrText.name || nodeOrText.id || '')
        : String(nodeOrText);
    if (/^(GET|POST|PUT|PATCH|DELETE|USE|VIEW|ANY):/i.test(raw)) {
        var method = raw.split(':')[0];
        var route = raw.slice(method.length + 1).split('/').filter(Boolean).slice(-2).join('/');
        raw = method + ':' + (route || '/');
    }
    return raw.length > 20 ? raw.slice(0, 19) + '…' : raw;
}

function laneForNode(n) {
    if (n.isEntryPoint) return 'entry';
    switch (n.type) {
        case 'ApiEndpoint': return 'entry';
        case 'Function':
        case 'Method': return 'execution';
        case 'Class':
        case 'Interface':
        case 'TypeAlias': return 'shape';
        case 'DbTable': return 'data';
        case 'ExternalDep': return 'dependency';
        case 'Module':
        case 'File': return 'file';
        default: return 'execution';
    }
}

function nodeById(id) {
    for (var i = 0; i < nodes.length; i++) {
        if (nodes[i].id === id) return nodes[i];
    }
    return null;
}

function computeDegreeMap() {
    var deg = {};
    nodes.forEach(function(n) { deg[n.id] = 0; });
    edges.forEach(function(e) {
        if (deg[e.from] !== undefined) deg[e.from] += 1;
        if (deg[e.to] !== undefined) deg[e.to] += 1;
    });
    return deg;
}

function neighborSetFor(id) {
    var set = {};
    edges.forEach(function(e) {
        if (e.from === id) set[e.to] = true;
        if (e.to === id) set[e.from] = true;
    });
    return set;
}

function placeArc(list, startAngle, endAngle, baseRadius, centerX, centerY) {
    if (!list.length) return;
    var span = endAngle - startAngle;
    var perRing = Math.max(5, Math.floor(Math.abs(span) / 0.42));
    for (var i = 0; i < list.length; i++) {
        var ring = Math.floor(i / perRing);
        var countInRing = Math.min(perRing, list.length - ring * perRing);
        var posInRing = i - ring * perRing;
        var angle = countInRing === 1
            ? startAngle + span / 2
            : startAngle + span * (posInRing + 0.5) / countInRing;
        var radius = baseRadius + ring * 118;
        list[i].x = centerX + Math.cos(angle) * radius;
        list[i].y = centerY + Math.sin(angle) * radius;
    }
}

function layoutOverview() {
    var order = ['entry', 'execution', 'shape', 'data', 'dependency', 'file'];
    var degree = computeDegreeMap();
    var indexMap = {};
    var incoming = {};
    nodes.forEach(function(n) {
        indexMap[n.id] = 0;
        incoming[n.id] = [];
    });
    edges.forEach(function(e) {
        if (incoming[e.to]) incoming[e.to].push(e.from);
        if (incoming[e.from]) incoming[e.from].push(e.to);
    });

    var lanes = {};
    order.forEach(function(k) { lanes[k] = []; });
    nodes.forEach(function(n) { lanes[laneForNode(n)].push(n); });

    order.forEach(function(key) {
        lanes[key].sort(function(a, b) {
            return (degree[b.id] || 0) - (degree[a.id] || 0) || String(a.id).localeCompare(String(b.id));
        });
        lanes[key].forEach(function(n, idx) { indexMap[n.id] = idx; });
    });

    for (var sweep = 0; sweep < 6; sweep++) {
        order.forEach(function(key) {
            lanes[key].sort(function(a, b) {
                var aRefs = incoming[a.id] || [];
                var bRefs = incoming[b.id] || [];
                var aScore = aRefs.length ? aRefs.reduce(function(sum, id) { return sum + (indexMap[id] || 0); }, 0) / aRefs.length : (degree[a.id] || 0) * -1;
                var bScore = bRefs.length ? bRefs.reduce(function(sum, id) { return sum + (indexMap[id] || 0); }, 0) / bRefs.length : (degree[b.id] || 0) * -1;
                return aScore - bScore;
            });
            lanes[key].forEach(function(n, idx) { indexMap[n.id] = idx; });
        });
    }

    var colGap = 240;
    var rowGap = 118;
    var xStart = 0;
    order.forEach(function(key, col) {
        var lane = lanes[key];
        if (!lane.length) return;
        var laneHeight = (lane.length - 1) * rowGap;
        lane.forEach(function(n, idx) {
            n.x = xStart + col * colGap;
            n.y = idx * rowGap - laneHeight / 2;
        });
    });
}

function layoutFocus360(focusId) {
    var focus = nodeById(focusId);
    if (!focus) return;
    focus.x = 0;
    focus.y = 0;

    var incoming = [];
    var outgoing = [];
    var both = [];
    var ambient = [];

    nodes.forEach(function(n) {
        if (n.id === focusId) return;
        var hasIn = false;
        var hasOut = false;
        edges.forEach(function(e) {
            if (e.from === n.id && e.to === focusId) hasIn = true;
            if (e.from === focusId && e.to === n.id) hasOut = true;
        });
        if (hasIn && hasOut) both.push(n);
        else if (hasIn) incoming.push(n);
        else if (hasOut) outgoing.push(n);
        else ambient.push(n);
    });

    placeArc(incoming, Math.PI * 0.72, Math.PI * 1.28, 190, 0, 0);
    placeArc(outgoing, -Math.PI * 0.28, Math.PI * 0.28, 190, 0, 0);
    placeArc(both, Math.PI * 1.45, Math.PI * 1.95, 160, 0, 0);
    placeArc(ambient, Math.PI * 0.15, Math.PI * 0.85, 300, 0, 0);
}

function fitGraphToViewport() {
    if (!nodes.length) {
        offsetX = 0;
        offsetY = 0;
        scale = 1;
        return;
    }

    var W = gc.width / devicePixelRatio;
    var H = gc.height / devicePixelRatio;
    var inspectorWidth = inspector.classList.contains('visible') ? Math.max(280, inspector.getBoundingClientRect().width || 320) : 0;
    var left = 32;
    var right = W - 32 - inspectorWidth;
    var top = 28;
    var bottom = H - 28;

    var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    nodes.forEach(function(n) {
        minX = Math.min(minX, n.x - n.r - 36);
        minY = Math.min(minY, n.y - n.r - 36);
        maxX = Math.max(maxX, n.x + n.r + 90);
        maxY = Math.max(maxY, n.y + n.r + 48);
    });

    var graphW = Math.max(1, maxX - minX);
    var graphH = Math.max(1, maxY - minY);
    var sx = Math.max(0.18, (right - left) / graphW);
    var sy = Math.max(0.18, (bottom - top) / graphH);
    scale = Math.min(layoutMode === 'focus' ? 1.15 : 0.92, sx, sy);

    var graphCx = (minX + maxX) / 2;
    var graphCy = (minY + maxY) / 2;
    var viewCx = (left + right) / 2;
    var viewCy = (top + bottom) / 2;
    offsetX = viewCx - graphCx * scale;
    offsetY = viewCy - graphCy * scale;
}

function renderNodeList(title, items, label) {
    var html = '<div><div class="section-title">' + title + '</div>';
    if (!items || !items.length) {
        html += '<div class="empty-note">No connected nodes in this direction.</div></div>';
        return html;
    }
    html += '<div class="node-list">';
    items.forEach(function(item) {
        var nodeId = item.id || item.name || item;
        var titleText = item.title || item.name || item;
        var metaText = item.subtitle || label;
        html += '<button class="node-link" data-nodeid="' + esc(nodeId) + '"><span>' + esc(titleText) + '</span><small>' + esc(metaText) + '</small></button>';
    });
    html += '</div></div>';
    return html;
}

function renderInspector() {
    if (!currentFocusId || !currentDetails) {
        inspector.classList.remove('visible');
        inspectorKicker.textContent = 'Overview';
        inspectorTitle.textContent = 'Code Explorer';
        inspectorSub.textContent = 'Click any node to open a 360-degree neighborhood with actions and impact analysis.';
        var nodesCount = currentSummary && currentSummary.nodeCount ? currentSummary.nodeCount : nodes.length;
        var edgesCount = currentSummary && currentSummary.edgeCount ? currentSummary.edgeCount : edges.length;
        inspectorBody.innerHTML =
            '<div class="summary-card">' +
            '<div class="summary-grid">' +
            '<div class="summary-stat"><strong>' + nodesCount + '</strong><span>Visible Nodes</span></div>' +
            '<div class="summary-stat"><strong>' + edgesCount + '</strong><span>Visible Edges</span></div>' +
            '</div></div>' +
            '<div class="summary-card">' +
            '<div class="section-title">How To Use It</div>' +
            '<div class="empty-note">The overview is intentionally filtered so the map stays readable. Single-click a node to pivot into its 360 view. Double-click a node to open the source file.</div>' +
            '</div>';
        return;
    }

    inspector.classList.add('visible');
    inspectorKicker.textContent = '360 View';
    inspectorTitle.textContent = currentDetails.name || currentDetails.id || currentFocusId;
    inspectorSub.textContent = (currentDetails.type || 'Symbol') + (currentDetails.file ? '  •  ' + currentDetails.file : '');

    var impact = currentDetails.impact;
    var impactCard = impact
        ? '<div class="summary-card"><div class="section-title">Impact Summary</div><div class="summary-grid">' +
          '<div class="summary-stat"><strong>' + impact.affectedCount + '</strong><span>Total</span></div>' +
          '<div class="summary-stat"><strong>' + impact.direct + '</strong><span>Direct</span></div>' +
          '<div class="summary-stat"><strong>' + impact.indirect + '</strong><span>Indirect</span></div>' +
          '<div class="summary-stat"><strong>' + impact.transitive + '</strong><span>Review</span></div>' +
          '</div></div>'
        : '<div class="summary-card"><div class="section-title">Impact Summary</div><div class="empty-note">Impact data is not available for this symbol yet.</div></div>';

    inspectorBody.innerHTML =
        '<div class="action-row">' +
        '<button data-action="open-file">Open File</button>' +
        '<button data-action="impact">Impact Analysis</button>' +
        '<button data-action="overview">Back To Overview</button>' +
        (currentDetails.hasMore ? '<button data-action="load-more">Load More Links</button>' : '') +
        '</div>' +
        impactCard +
        renderNodeList('Upstream Callers', currentDetails.callers || [], 'caller') +
        renderNodeList('Downstream Dependencies', currentDetails.callees || [], 'dependency') +
        renderNodeList('Type Links', currentDetails.typeRefs || [], 'type') +
        renderNodeList('Database Tables', currentDetails.tables || [], 'table') +
        renderNodeList('Database Columns', currentDetails.columns || [], 'column') +
        renderNodeList('Related Files', currentDetails.files || [], 'file') +
        renderNodeList('Libraries', currentDetails.libraries || [], 'dependency') +
        (currentDetails.hasMore
            ? '<div class="summary-card"><div class="section-title">Progressive Loading</div><div class="empty-note">This neighborhood is partially loaded to keep the editor responsive. Use <strong>Load More Links</strong> to expand deeper into connected code, tables, and columns.</div></div>'
            : '');
}

function applyGraphData(newNodes, newEdges, focusId, details, summary) {
    currentFocusId = focusId;
    currentDetails = details;
    currentSummary = summary;

    nodes = newNodes.map(function(n) {
        return Object.assign({}, n, { x: 0, y: 0, r: 22, isFocus: n.id === focusId });
    });
    edges = newEdges.filter(function(e) {
        return newNodes.some(function(n) { return n.id === e.from; }) && newNodes.some(function(n) { return n.id === e.to; });
    });
    selNode = null;
    hovNode = null;
    leg.style.display = nodes.length ? 'flex' : 'none';

    var degree = computeDegreeMap();
    nodes.forEach(function(n) {
        var d = degree[n.id] || 0;
        n.r = Math.max(18, Math.min(44, 20 + d * 1.8 + (n.isEntryPoint ? 8 : 0) + (n.id === focusId ? 10 : 0)));
    });

    renderInspector();
    layoutMode = focusId ? 'focus' : 'overview';
    viewBadge.textContent = focusId ? '360 Neighborhood' : 'Overview Map';

    if (layoutMode === 'focus') layoutFocus360(focusId);
    else layoutOverview();

    fitGraphToViewport();
    draw();
}

function drawLabelPill(text, x, y, color, alignRight) {
    var font = '10px ' + (getComputedStyle(document.body).fontFamily || 'sans-serif');
    ctx.font = font;
    var textW = ctx.measureText(text).width;
    var padX = 8;
    var padY = 5;
    var width = textW + padX * 2;
    var height = 20;
    var boxX = alignRight ? x - width : x;
    var boxY = y - height / 2;

    ctx.beginPath();
    ctx.roundRect(boxX, boxY, width, height, 10);
    ctx.fillStyle = 'rgba(2,6,23,0.82)';
    ctx.fill();
    ctx.strokeStyle = color;
    ctx.globalAlpha = 0.45;
    ctx.stroke();
    ctx.globalAlpha = 1;
    ctx.fillStyle = '#e5eefc';
    ctx.textAlign = alignRight ? 'right' : 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, alignRight ? boxX + width - padX : boxX + padX, y + 0.5);
}

function draw() {
    var W = gc.width / devicePixelRatio;
    var H = gc.height / devicePixelRatio;
    ctx.clearRect(0, 0, W, H);

    if (!nodes.length) {
        ctx.fillStyle = '#94a3b8';
        ctx.font = '12px ' + (getComputedStyle(document.body).fontFamily || 'sans-serif');
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('No data — run Log Thread: Analyze Workspace first', W / 2, H / 2 - 10);
        ctx.globalAlpha = 0.65;
        ctx.font = '10px ' + (getComputedStyle(document.body).fontFamily || 'sans-serif');
        ctx.fillText('Then reopen the overview or click Sync after analysis completes.', W / 2, H / 2 + 12);
        ctx.globalAlpha = 1;
        return;
    }

    ctx.save();
    ctx.translate(offsetX, offsetY);
    ctx.scale(scale, scale);

    var active = currentFocusId ? nodeById(currentFocusId) : (hovNode || selNode);
    var activeNeighbors = active ? neighborSetFor(active.id) : {};

    if (layoutMode === 'focus' && active) {
        ctx.beginPath();
        ctx.arc(active.x, active.y, 120, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(125,211,252,0.14)';
        ctx.lineWidth = 1.2;
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(active.x, active.y, 240, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(125,211,252,0.09)';
        ctx.stroke();
    }

    edges.forEach(function(e) {
        var from = nodeById(e.from);
        var to = nodeById(e.to);
        if (!from || !to) return;
        var dx = to.x - from.x;
        var dy = to.y - from.y;
        var dist = Math.sqrt(dx * dx + dy * dy) || 1;
        var ux = dx / dist;
        var uy = dy / dist;
        var sx = from.x + ux * from.r;
        var sy = from.y + uy * from.r;
        var ex = to.x - ux * (to.r + 8);
        var ey = to.y - uy * (to.r + 8);
        var curve = layoutMode === 'focus' ? 0.08 : 0.16;
        var px = -uy * dist * curve;
        var py = ux * dist * curve;
        var cp1x = sx + dx * 0.35 + px;
        var cp1y = sy + dy * 0.35 + py;
        var cp2x = ex - dx * 0.35 + px;
        var cp2y = ey - dy * 0.35 + py;
        var isHot = active && (e.from === active.id || e.to === active.id);

        ctx.beginPath();
        ctx.moveTo(sx, sy);
        ctx.bezierCurveTo(cp1x, cp1y, cp2x, cp2y, ex, ey);
        ctx.strokeStyle = e.color || '#6ea8fe';
        ctx.globalAlpha = isHot ? 0.72 : (layoutMode === 'focus' ? 0.26 : 0.18);
        ctx.lineWidth = isHot ? 2 : 1.3;
        ctx.stroke();

        var tax = ex - cp2x;
        var tay = ey - cp2y;
        var tlen = Math.sqrt(tax * tax + tay * tay) || 1;
        var tx = tax / tlen;
        var ty = tay / tlen;
        ctx.beginPath();
        ctx.moveTo(ex, ey);
        ctx.lineTo(ex - tx * 9 + ty * 4, ey - ty * 9 - tx * 4);
        ctx.lineTo(ex - tx * 9 - ty * 4, ey - ty * 9 + tx * 4);
        ctx.closePath();
        ctx.fillStyle = e.color || '#6ea8fe';
        ctx.globalAlpha = isHot ? 0.8 : 0.35;
        ctx.fill();
        ctx.globalAlpha = 1;
    });

    nodes.forEach(function(n) {
        var isSel = selNode && selNode.id === n.id;
        var isHov = hovNode && hovNode.id === n.id;
        var isFocus = currentFocusId && currentFocusId === n.id;
        var muted = active && active.id !== n.id && !activeNeighbors[n.id] && !isFocus;
        var alpha = muted ? 0.22 : 1;
        var color = n.color || '#58a6ff';
        var glow = isFocus ? 20 : (isHov ? 14 : (n.isEntryPoint ? 10 : 7));

        ctx.save();
        ctx.globalAlpha = alpha;
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r + (isFocus ? 16 : 8), 0, Math.PI * 2);
        ctx.fillStyle = color;
        ctx.globalAlpha = alpha * (isFocus ? 0.2 : 0.08);
        ctx.fill();

        ctx.shadowColor = color;
        ctx.shadowBlur = glow;
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
        var grad = ctx.createRadialGradient(n.x - n.r * 0.35, n.y - n.r * 0.4, n.r * 0.05, n.x, n.y, n.r);
        grad.addColorStop(0, lighten(color, 0.3));
        grad.addColorStop(1, color);
        ctx.fillStyle = grad;
        ctx.globalAlpha = alpha * 0.94;
        ctx.fill();
        ctx.shadowBlur = 0;

        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
        ctx.strokeStyle = isFocus || isSel || isHov ? '#ffffff' : 'rgba(255,255,255,0.3)';
        ctx.globalAlpha = alpha * (isFocus || isSel || isHov ? 0.9 : 0.4);
        ctx.lineWidth = isFocus ? 2.4 : 1.3;
        ctx.stroke();
        ctx.globalAlpha = alpha;
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = '600 ' + (n.r > 30 ? 11 : 10) + 'px ' + (getComputedStyle(document.body).fontFamily || 'sans-serif');
        ctx.fillText(compactLabel(n), n.x, n.y);
        ctx.restore();

        var shouldLabel = layoutMode === 'focus' || isHov || isSel || isFocus || n.isEntryPoint || n.r > 30 || scale > 0.9;
        if (shouldLabel) {
            var alignRight = currentFocusId ? n.x > 0 : false;
            drawLabelPill(compactLabel(n), n.x + (alignRight ? -(n.r + 10) : n.r + 10), n.y, color, alignRight);
        }
    });

    ctx.restore();
}

function nodeAt(mx, my) {
    var x = (mx - offsetX) / scale;
    var y = (my - offsetY) / scale;
    for (var i = nodes.length - 1; i >= 0; i--) {
        var n = nodes[i];
        var dx = x - n.x;
        var dy = y - n.y;
        if (dx * dx + dy * dy <= (n.r + 6) * (n.r + 6)) return n;
    }
    return null;
}

function openNeighborhood(nodeId) {
    if (!nodeId) return;
    var node = nodeById(nodeId);
    navHistory.push(snapshotState());
    currentTitle = node && (node.title || node.name) ? (node.title || node.name) : nodeId;
    backBtn.disabled = false;
    updateBreadcrumb();
    tip.style.display = 'none';
    setStatus('analyzing', 'Tracing dependencies', 'Walking callers, files, libraries, and tables for this node.');
    vscode.postMessage({ type: 'navigateTo', nodeId: nodeId });
}

gc.addEventListener('mousedown', function(e) {
    var rect = gc.getBoundingClientRect();
    var n = nodeAt(e.clientX - rect.left, e.clientY - rect.top);
    if (n) {
        selNode = n;
        dragNode = n;
        clickNode = n;
        clickTime = Date.now();
        draw();
    } else {
        dragging = true;
        selNode = null;
        draw();
    }
    lastMx = { x: e.clientX, y: e.clientY };
});

gc.addEventListener('mousemove', function(e) {
    var rect = gc.getBoundingClientRect();
    var mx = e.clientX - rect.left;
    var my = e.clientY - rect.top;
    if (dragNode) {
        var moved = Math.abs(e.clientX - lastMx.x) + Math.abs(e.clientY - lastMx.y);
        if (moved > 4) clickNode = null;
        dragNode.x += (e.clientX - lastMx.x) / scale;
        dragNode.y += (e.clientY - lastMx.y) / scale;
        lastMx = { x: e.clientX, y: e.clientY };
        draw();
        return;
    }
    if (dragging) {
        offsetX += e.clientX - lastMx.x;
        offsetY += e.clientY - lastMx.y;
        lastMx = { x: e.clientX, y: e.clientY };
        draw();
        return;
    }
    var n = nodeAt(mx, my);
    if (n !== hovNode) {
        hovNode = n;
        gc.style.cursor = n ? 'pointer' : 'grab';
        if (n) {
            var inbound = edges.filter(function(edge) { return edge.to === n.id; }).length;
            var outbound = edges.filter(function(edge) { return edge.from === n.id; }).length;
            tip.style.display = 'block';
            tip.style.left = (mx + 14) + 'px';
            tip.style.top = Math.max(8, my - 74) + 'px';
            tip.innerHTML =
                '<div class="tip-name">' + esc(n.title || n.name || n.id) + '</div>' +
                '<div class="tip-badge" style="background:' + (n.color || '#444') + '22;color:' + (n.color || '#aaa') + '">' + esc(n.displayLabel || n.type || 'symbol') + '</div>' +
                ((n.subtitle || n.file) ? '<div class="tip-file">' + esc(n.subtitle || n.file) + '</div>' : '') +
                '<div style="font-size:10px;opacity:.58;margin-bottom:3px">' + inbound + ' upstream  •  ' + outbound + ' downstream</div>' +
                '<div class="tip-hint">Click for 360 neighborhood<br>Double-click to open source</div>';
        } else {
            tip.style.display = 'none';
        }
        draw();
    } else if (n) {
        tip.style.left = (mx + 14) + 'px';
        tip.style.top = Math.max(8, my - 74) + 'px';
    }
});

gc.addEventListener('mouseup', function() {
    var n = clickNode;
    clickNode = null;
    dragNode = null;
    dragging = false;
    if (n && (Date.now() - clickTime) < 420) openNeighborhood(n.id);
});

gc.addEventListener('dblclick', function(e) {
    var rect = gc.getBoundingClientRect();
    var n = nodeAt(e.clientX - rect.left, e.clientY - rect.top);
    if (n) vscode.postMessage({ type: 'openFile', nodeId: n.id });
});

gc.addEventListener('mouseleave', function() {
    dragNode = null;
    dragging = false;
    hovNode = null;
    tip.style.display = 'none';
    draw();
});

gc.addEventListener('wheel', function(e) {
    e.preventDefault();
    var rect = gc.getBoundingClientRect();
    var mx = e.clientX - rect.left;
    var my = e.clientY - rect.top;
    var zoom = e.deltaY < 0 ? 1.12 : 0.9;
    var nextScale = Math.max(0.12, Math.min(8, scale * zoom));
    offsetX = mx - (mx - offsetX) * (nextScale / scale);
    offsetY = my - (my - offsetY) * (nextScale / scale);
    scale = nextScale;
    draw();
}, { passive: false });

inspectorBody.addEventListener('click', function(e) {
    var target = e.target.closest('[data-nodeid],[data-action]');
    if (!target) return;
    var nodeId = target.getAttribute('data-nodeid');
    var action = target.getAttribute('data-action');
    if (nodeId) {
        openNeighborhood(nodeId);
        return;
    }
    if (action === 'open-file' && currentFocusId) vscode.postMessage({ type: 'openFile', nodeId: currentFocusId });
    if (action === 'impact' && currentFocusId) vscode.postMessage({ type: 'runImpactAnalysis', nodeId: currentFocusId });
    if (action === 'overview') goHome();
    if (action === 'load-more' && currentFocusId) {
        setStatus('analyzing', 'Loading more links', 'Expanding the neighborhood with deeper linked code and data flow.');
        vscode.postMessage({ type: 'loadMoreLinks', nodeId: currentFocusId, expansionLevel: (currentDetails && currentDetails.expansionLevel ? currentDetails.expansionLevel : 1) + 1 });
    }
});

var searchTimer;
searchInp.addEventListener('input', function() {
    clearTimeout(searchTimer);
    var q = this.value.trim();
    if (q.length < 2) {
        sr.style.display = 'none';
        return;
    }
    searchTimer = setTimeout(function() {
        vscode.postMessage({ type: 'search', query: q });
    }, 260);
});
searchInp.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        this.value = '';
        sr.style.display = 'none';
    }
});

function setStatus(s, title, copy) {
    statusDot.className = 'status-dot ' + s;
    statusDot.title = s === 'ready' ? 'Ready' : s === 'analyzing' ? 'Loading...' : 'Error';
    if (s === 'analyzing') {
        loader.classList.add('visible');
        loaderTitle.textContent = title || 'Loading code map…';
        loaderCopy.textContent = copy || 'Building the next graph view.';
    } else {
        loader.classList.remove('visible');
    }
}

function resize() {
    var r = gc.parentElement.getBoundingClientRect();
    gc.width = r.width * devicePixelRatio;
    gc.height = r.height * devicePixelRatio;
    gc.style.width = r.width + 'px';
    gc.style.height = r.height + 'px';
    ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
    if (nodes.length) fitGraphToViewport();
    draw();
}
window.addEventListener('resize', resize);
setTimeout(resize, 40);

window.addEventListener('message', function(ev) {
    var m = ev.data;
    switch (m.type) {
        case 'graphData':
            if (m.nodes && m.nodes.length > 0) {
                emptyState.classList.remove('visible');
                mainView.style.display = 'flex';
                document.querySelector('.search-wrap').style.display = 'block';
                document.querySelector('.graph-area').style.display = 'flex';
                document.querySelector('.footer').style.display = 'flex';
            }
            if (m.isRoot) {
                navHistory = [];
                backBtn.disabled = true;
            }
            currentTitle = m.title || 'Overview';
            updateBreadcrumb();
            applyGraphData(m.nodes || [], m.edges || [], m.focusNode || null, m.nodeDetails || null, m.summary || null);
            setStatus('ready');
            sr.style.display = 'none';
            break;
        case 'searchResults':
            if (!m.results || !m.results.length) {
                sr.innerHTML = '<div style="padding:12px;text-align:center;color:var(--vscode-descriptionForeground)">No results</div>';
            } else {
                sr.innerHTML = m.results.map(function(r) {
                    return '<div class="sri" data-id="' + esc(r.name || '') + '">' +
                        '<div class="sri-name">' + esc(r.name || '') + '<span class="sri-type">' + esc(r.type || '') + '</span></div>' +
                        '<div class="sri-path">' + esc(r.filePath || '') + '</div>' +
                        '</div>';
                }).join('');
                sr.querySelectorAll('.sri').forEach(function(el) {
                    el.addEventListener('click', function() {
                        var id = this.getAttribute('data-id');
                        if (!id) return;
                        searchInp.value = '';
                        sr.style.display = 'none';
                        openNeighborhood(id);
                    });
                });
            }
            sr.style.display = 'block';
            break;
        case 'statusUpdate':
            setStatus(m.status, m.message, m.message);
            break;
        case 'graphStats':
            setStatus('ready');
            break;
    }
});

updateBreadcrumb();
renderInspector();
setStatus('analyzing', 'Loading code map…', 'Preparing the initial workspace overview.');
vscode.postMessage({ type: 'loadDefaultGraph' });
</script></body></html>`;
    }
}
