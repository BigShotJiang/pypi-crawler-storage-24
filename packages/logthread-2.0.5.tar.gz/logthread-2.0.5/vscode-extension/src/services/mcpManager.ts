import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';

interface MCPServerConfig {
    command: string;
    args?: string[];
    env?: Record<string, string>;
}

interface MCPConfig {
    mcpServers: Record<string, MCPServerConfig>;
}

type ConnectionState = 'disconnected' | 'connecting' | 'connected';

/** Wrap a promise with a timeout */
function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
    let timer: ReturnType<typeof setTimeout>;
    const timeout = new Promise<never>((_, rej) => {
        timer = setTimeout(() => rej(new Error(`${label}: timed out after ${ms}ms`)), ms);
    });
    return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

export class MCPManager {
    private clients     = new Map<string, Client>();
    private outputChannel: vscode.OutputChannel;

    // ── LogThread server reconnect state ────────────────────────────────────
    private ltWorkspacePath = '';
    private ltState: ConnectionState = 'disconnected';
    private ltReadyPromise: Promise<void> | null = null;
    private ltReadyResolve: (() => void) | null = null;
    private ltReadyReject:  ((e: Error) => void) | null = null;
    private ltRetryCount  = 0;
    private ltRetryTimer: ReturnType<typeof setTimeout> | null = null;
    private ltTransport: StdioClientTransport | null = null;
    private disposed = false;
    private intentionalClose = false;

    constructor(private context: vscode.ExtensionContext) {
        this.outputChannel = vscode.window.createOutputChannel('LogThread MCP');
    }

    private log(msg: string): void {
        const ts = new Date().toISOString().slice(11, 23);
        this.outputChannel.appendLine(`[${ts}] ${msg}`);
    }

    // ── Public API ───────────────────────────────────────────────────────────

    async initialize(workspacePath: string): Promise<void> {
        this.log(`initialize() — workspace=${workspacePath}`);
        this.log(`  state: ltState=${this.ltState}, intentionalClose=${this.intentionalClose}, disposed=${this.disposed}`);
        this.ltWorkspacePath = workspacePath;

        // Clean up any existing LogThread connection before reconnecting.
        // This prevents race conditions where an old onclose handler fires
        // and schedules a competing reconnect while we're initializing.
        if (this.ltRetryTimer) {
            clearTimeout(this.ltRetryTimer);
            this.ltRetryTimer = null;
        }
        const oldClient = this.clients.get('logthread');
        if (oldClient) {
            this.intentionalClose = true;
            try { await oldClient.close(); } catch { /* ignore */ }
            this.clients.delete('logthread');
        }
        this.forceKillTransport();
        this.ltState = 'disconnected';

        this.disposed        = false;
        this.intentionalClose = false;
        this.ltRetryCount    = 0;
        this.ltReadyPromise  = null;
        this.ltReadyResolve  = null;
        this.ltReadyReject   = null;

        await this.connectLogThread();

        const config = this.loadConfig(workspacePath);
        if (config) {
            for (const [name, cfg] of Object.entries(config.mcpServers)) {
                try { await this.connectServer(name, cfg); } catch { /* skip */ }
            }
        }
    }

    async callTool(
        serverName: string,
        toolName: string,
        args: Record<string, unknown>
    ): Promise<any> {
        this.log(`callTool(${serverName}, ${toolName}) — ltState=${this.ltState}, hasClient=${this.clients.has(serverName)}`);

        // For the logthread server, wait up to 8 s for (re)connection.
        // Keep this short — if MCP isn't up in 8s, fail fast and let the caller
        // handle gracefully rather than blocking the whole AI pipeline for 30s.
        if (serverName === 'logthread' && this.ltState !== 'connected') {
            this.log(`  callTool: not connected, waiting up to 8s...`);
            await this.waitForLogThread(8_000);
            this.log(`  callTool: wait done, ltState=${this.ltState}`);
        }

        const client = this.clients.get(serverName);
        if (!client) {
            this.log(`  callTool: NO CLIENT — keys=[${[...this.clients.keys()]}]`);
            throw new Error(`MCP server '${serverName}' not connected`);
        }

        try {
            // Per-call timeout: 30s — prevents hanging forever if server dies mid-call
            const result = await withTimeout(
                client.callTool({ name: toolName, arguments: args }),
                30_000,
                `callTool(${toolName})`
            );
            this.log(`  callTool: ${toolName} OK`);
            return result;
        } catch (error: any) {
            this.log(`  callTool: ${toolName} failed: ${error}`);
            const errStr = String(error);
            // Transient transport failures — retry once after reconnect.
            // Note: -32000 errors are server-side (e.g. logthread_query crashing on embedding load)
            // and should NOT be retried — the retry would just crash the server again.
            const isTransportFailure =
                errStr.includes('Not connected') ||
                errStr.includes('timed out') ||
                (errStr.includes('Connection closed') && !errStr.includes('-32000'));
            if (serverName === 'logthread' && isTransportFailure) {
                this.log('  callTool: transient — triggering reconnect + single retry');
                // Force-reset state so reconnect actually happens
                this.clients.delete(serverName);
                this.ltState = 'disconnected';
                this.forceKillTransport();
                this.ltRetryCount = 0;
                this.scheduleReconnect();
                try {
                    await this.waitForLogThread(30_000);
                    const retryClient = this.clients.get(serverName);
                    if (retryClient) {
                        return await withTimeout(
                            retryClient.callTool({ name: toolName, arguments: args }),
                            30_000,
                            `callTool-retry(${toolName})`
                        );
                    }
                } catch (retryErr) {
                    this.log(`  callTool: retry also failed: ${retryErr}`);
                }
            }
            throw error;
        }
    }

    async listTools(serverName?: string): Promise<Array<{ server: string; name: string; description?: string }>> {
        const tools: Array<{ server: string; name: string; description?: string }> = [];
        const entries = serverName
            ? (this.clients.has(serverName) ? [[serverName, this.clients.get(serverName)!] as [string, Client]] : [])
            : Array.from(this.clients.entries());

        for (const [name, client] of entries) {
            try {
                const result = await client.listTools();
                for (const tool of result.tools) {
                    tools.push({ server: name, name: tool.name, description: tool.description });
                }
            } catch { /* skip */ }
        }
        return tools;
    }

    getClient(serverName: string): Client | undefined { return this.clients.get(serverName); }

    isConnected(serverName: string): boolean {
        return serverName === 'logthread'
            ? this.ltState === 'connected'
            : this.clients.has(serverName);
    }

    async dispose(): Promise<void> {
        this.log(`dispose() — ltState=${this.ltState}`);
        this.intentionalClose = true;
        this.disposed = true;

        if (this.ltRetryTimer) {
            clearTimeout(this.ltRetryTimer);
            this.ltRetryTimer = null;
        }

        for (const [name, client] of this.clients.entries()) {
            try { await client.close(); } catch { /* ignore */ }
            this.log(`  dispose: closed '${name}'`);
        }
        this.clients.clear();
        this.forceKillTransport();

        this.ltState = 'disconnected';
        this.ltReadyPromise = null;
        this.log('  dispose: done');
    }

    disposeChannel(): void {
        this.outputChannel.dispose();
    }

    // ── LogThread server connection ──────────────────────────────────────────

    private async connectLogThread(): Promise<void> {
        this.log(`connectLogThread() — ltState=${this.ltState}`);
        if (this.ltState === 'connecting') {
            this.log('  already connecting, skip');
            return;
        }
        this.ltState = 'connecting';

        this.ltReadyPromise = new Promise<void>((res, rej) => {
            this.ltReadyResolve = res;
            this.ltReadyReject  = rej;
        });

        try {
            this.log(`  spawning "logthread mcp" cwd=${this.ltWorkspacePath}`);
            const transport = new StdioClientTransport({
                command: 'logthread',
                args: ['mcp'],
                env: { ...process.env as Record<string, string>, LOGTHREAD_WORKSPACE: this.ltWorkspacePath },
                cwd: this.ltWorkspacePath
            });

            const client = new Client(
                { name: 'logthread-vscode', version: '1.0.0' },
                { capabilities: {} }
            );

            await withTimeout(client.connect(transport), 15_000, 'MCP handshake');
            this.ltTransport = transport;

            const pid = transport.pid;
            this.log(`  handshake OK — pid=${pid ?? 'unknown'}`);

            // Capture stderr if available
            if (transport.stderr) {
                transport.stderr.on('data', (chunk: Buffer) => {
                    for (const line of chunk.toString().trim().split('\n')) {
                        if (line) this.log(`  [server] ${line}`);
                    }
                });
            }

            // Health check
            this.log('  running listTools() health check...');
            const tools = await withTimeout(client.listTools(), 10_000, 'health check');
            this.log(`  health check OK — ${tools.tools.length} tools`);

            // Hook lifecycle events AFTER health check
            (client as any).onclose = () => {
                if (this.intentionalClose) {
                    this.log('  client.onclose (intentional, ignoring)');
                    return;
                }
                this.log('  client.onclose — reconnecting');
                this.clients.delete('logthread');
                this.ltState = 'disconnected';
                this.ltTransport = null;
                this.ltRetryCount = 0;  // reset so first reconnect uses the minimum delay
                this.ltReadyPromise = new Promise<void>((res, rej) => {
                    this.ltReadyResolve = res;
                    this.ltReadyReject  = rej;
                });
                this.scheduleReconnect();
            };
            (client as any).onerror = (err: Error) => {
                if (this.intentionalClose) return;
                this.log(`  client.onerror: ${err.message}`);
            };

            this.clients.set('logthread', client);
            this.ltState = 'connected';
            this.ltRetryCount = 0;
            this.ltReadyResolve?.();
            this.log('✓ LogThread MCP connected');
        } catch (error) {
            this.forceKillTransport();
            this.ltState = 'disconnected';
            this.ltReadyReject?.(error instanceof Error ? error : new Error(String(error)));
            this.log(`✗ connectLogThread FAILED: ${error}`);
            throw error;
        }
    }

    private scheduleReconnect(): void {
        if (this.disposed || this.intentionalClose) {
            this.log(`scheduleReconnect: skipped (disposed=${this.disposed}, intentional=${this.intentionalClose})`);
            return;
        }
        if (this.ltRetryTimer) return;

        if (!this.ltReadyPromise || this.ltState === 'connected') {
            this.ltReadyPromise = new Promise<void>((res, rej) => {
                this.ltReadyResolve = res;
                this.ltReadyReject  = rej;
            });
        }

        const delay = Math.min(500 * Math.pow(2, this.ltRetryCount), 15_000);
        this.ltRetryCount++;
        this.log(`scheduleReconnect: attempt #${this.ltRetryCount} in ${(delay / 1000).toFixed(1)}s`);

        this.ltRetryTimer = setTimeout(async () => {
            this.ltRetryTimer = null;
            try {
                await this.connectLogThread();
            } catch {
                this.scheduleReconnect();
            }
        }, delay);
    }

    private async waitForLogThread(timeoutMs: number): Promise<void> {
        this.log(`waitForLogThread(${timeoutMs}ms) — ltState=${this.ltState}`);
        if (this.ltState === 'connected') return;

        const deadline = Date.now() + timeoutMs;

        if (this.ltState === 'disconnected' && !this.ltRetryTimer && !this.ltReadyPromise) {
            this.log('  no reconnect in flight, starting one');
            this.ltRetryCount = 0;
            this.scheduleReconnect();
        }

        let iter = 0;
        while (Date.now() < deadline) {
            iter++;
            const promise = this.ltReadyPromise;
            if (!promise) {
                await new Promise(r => setTimeout(r, 200));
                continue;
            }

            const remaining = deadline - Date.now();
            if (remaining <= 0) break;

            try {
                const timeout = new Promise<never>((_, rej) =>
                    setTimeout(() => rej(new Error('__timeout__')), remaining)
                );
                await Promise.race([promise, timeout]);
                this.log(`  waitForLogThread: resolved after ${iter} iterations`);
                return;
            } catch (err) {
                if (String(err).includes('__timeout__')) {
                    this.log(`  waitForLogThread: TIMED OUT`);
                    throw new Error(`MCP reconnect timed out after ${timeoutMs}ms`);
                }
                this.log(`  waitForLogThread: attempt failed, retrying... (${err})`);
                await new Promise(r => setTimeout(r, 200));
            }
        }
        throw new Error(`MCP reconnect timed out after ${timeoutMs}ms`);
    }

    private forceKillTransport(): void {
        if (!this.ltTransport) return;
        // Use the public .pid getter (returns null after close)
        const pid = this.ltTransport.pid;
        if (pid) {
            try { process.kill(pid, 'SIGKILL'); } catch { /* already dead */ }
            this.log(`  forceKill: SIGKILL pid=${pid}`);
        }
        this.ltTransport = null;
    }

    // ── User-defined extra MCP servers ───────────────────────────────────────

    private loadConfig(workspacePath: string): MCPConfig | null {
        const candidates = [
            path.join(workspacePath, '.logthread', 'mcp_config.json'),
            path.join(workspacePath, 'mcp_config.json')
        ];
        for (const p of candidates) {
            if (fs.existsSync(p)) {
                try { return JSON.parse(fs.readFileSync(p, 'utf-8')); } catch { /* skip */ }
            }
        }
        return null;
    }

    private async connectServer(name: string, config: MCPServerConfig): Promise<void> {
        const env: Record<string, string> = {};
        for (const [k, v] of Object.entries(process.env)) {
            if (v !== undefined) env[k] = v;
        }
        if (config.env) Object.assign(env, config.env);

        const transport = new StdioClientTransport({
            command: config.command,
            args: config.args || [],
            env
        });
        const client = new Client(
            { name: `logthread-vscode-${name}`, version: '1.0.0' },
            { capabilities: {} }
        );
        await client.connect(transport);
        this.clients.set(name, client);
        this.log(`✓ ${name} MCP server connected`);
    }
}
