import * as vscode from 'vscode';
import { spawn, ChildProcess, execSync } from 'child_process';
import * as path from 'path';
import * as os from 'os';
import * as fs from 'fs';
import * as crypto from 'crypto';
import { MCPManager } from './mcpManager';

export interface SymbolContext {
    name: string;
    type: string;
    filePath: string;
    startLine: number;
    endLine: number;
    callers: string[];
    callees: string[];
    typeRefs: string[];
    community?: string;
    isDead: boolean;
    signature?: string;
}

export interface ImpactResult {
    symbol: string;
    affectedCount: number;
    direct: string[];
    indirect: string[];
    transitive: string[];
}

export interface EntryPoint {
    name: string;
    type: 'route' | 'cli' | 'main' | 'public_api';
    path: string;
    method?: string; // HTTP method for routes
    handler?: string; // Handler function name
    line?: number;
}

export interface GraphContext {
    symbols: SymbolContext[];
    relationships: Array<{
        from: string;
        to: string;
        type: string;
        confidence: number;
    }>;
    relevantCode: Array<{
        path: string;
        content: string;
        startLine: number;
        endLine: number;
    }>;
    entryPoints?: EntryPoint[];
}

export class LogThreadService {
    private mcpProcess: ChildProcess | null = null;
    private outputChannel: vscode.OutputChannel;
    private isIndexed: boolean = false;
    private _isLoggedIn: boolean = false;
    private _userEmail: string | null = null;
    private mcpManager: MCPManager | null = null;

    // Reindex debounce state — batches rapid file-change events into one reindex
    private reindexTimer: ReturnType<typeof setTimeout> | null = null;
    private reindexInProgress = false;
    private static readonly REINDEX_DEBOUNCE_MS = 10_000; // 10s quiet period

    constructor(private context: vscode.ExtensionContext) {
        this.outputChannel = vscode.window.createOutputChannel('Log Thread');
        this.mcpManager = new MCPManager(context);
        this.checkAuthStatus();
    }

    /** Write a line to the shared 'Log Thread' output channel. */
    log(msg: string): void {
        this.outputChannel.appendLine(msg);
    }

    /** Whether the graph is available (indexed + MCP connected or at least indexed). */
    isGraphAvailable(): boolean {
        if (this.mcpManager?.isConnected('logthread')) return true;
        return this.isIndexed;
    }

    get isLoggedIn(): boolean {
        return this._isLoggedIn;
    }

    get userEmail(): string | null {
        return this._userEmail;
    }

    private getConfigDir(): string {
        return path.join(os.homedir(), '.logthread');
    }

    async checkAuthStatus(): Promise<boolean> {
        try {
            const configDir = this.getConfigDir();
            const authPath = path.join(configDir, 'auth.json');

            if (fs.existsSync(authPath)) {
                const configData = JSON.parse(fs.readFileSync(authPath, 'utf-8'));
                this._isLoggedIn = !!configData.token;
                this._userEmail = configData.email || null;
                return this._isLoggedIn;
            }
            return false;
        } catch (error) {
            /* auth error — not user-actionable, suppress */ void error;
            return false;
        }
    }

    async login(): Promise<boolean> {
        const terminal = vscode.window.createTerminal({ name: 'Log Thread Login', shellPath: process.platform === 'win32' ? 'cmd.exe' : '/bin/sh' });
        terminal.show();
        terminal.sendText('logthread login');

        return new Promise((resolve) => {
            const disposable = vscode.window.onDidCloseTerminal(async (closedTerminal) => {
                if (closedTerminal === terminal) {
                    disposable.dispose();
                    await this.checkAuthStatus();
                    resolve(this._isLoggedIn);
                }
            });

            const pollInterval = setInterval(async () => {
                const wasLoggedIn = this._isLoggedIn;
                await this.checkAuthStatus();
                if (!wasLoggedIn && this._isLoggedIn) {
                    clearInterval(pollInterval);
                    vscode.window.showInformationMessage(`Logged in as ${this._userEmail}`);
                }
            }, 3000);

            setTimeout(() => clearInterval(pollInterval), 300000);
        });
    }

    async logout(): Promise<void> {
        return new Promise((resolve, reject) => {
            const process = spawn('logthread', ['logout'], {
                stdio: ['pipe', 'pipe', 'pipe']
            });

            process.on('close', () => {
                this._isLoggedIn = false;
                this._userEmail = null;
                resolve();
            });

            process.on('error', reject);
        });
    }

    hasCloudSyncConsent(): boolean {
        try {
            const configDir = this.getConfigDir();
            const consentPath = path.join(configDir, 'cloud_consent.json');
            return fs.existsSync(consentPath);
        } catch {
            return false;
        }
    }

    saveCloudSyncConsent(): void {
        try {
            const configDir = this.getConfigDir();
            if (!fs.existsSync(configDir)) {
                fs.mkdirSync(configDir, { recursive: true });
            }
            const consentPath = path.join(configDir, 'cloud_consent.json');
            const consentData = {
                tos_agreed: true,
                privacy_agreed: true,
                timestamp: new Date().toISOString()
            };
            fs.writeFileSync(consentPath, JSON.stringify(consentData, null, 2), 'utf-8');
        } catch (error) {
            this.outputChannel.appendLine(`Error saving consent: ${error}`);
        }
    }

    async syncToCloud(workspacePath: string): Promise<boolean> {
        return new Promise((resolve, reject) => {
            const process = spawn('logthread', ['sync'], {
                cwd: workspacePath,
                stdio: ['pipe', 'pipe', 'pipe']
            });

            let output = '';
            process.stdout?.on('data', (data: Buffer) => {
                output += data.toString();
                this.outputChannel.appendLine(data.toString());
            });

            process.stderr?.on('data', (_data: Buffer) => { /* suppress */ });

            process.on('close', (code: number | null) => {
                resolve(code === 0);
            });

            process.on('error', reject);
        });
    }

    getCloudExploreUrl(workspacePath: string): string {
        try {
            const configDir = this.getConfigDir();
            const projectId = this.getProjectId(workspacePath);
            const metaPath = path.join(configDir, 'projects', projectId, 'meta.json');

            if (fs.existsSync(metaPath)) {
                const meta = JSON.parse(fs.readFileSync(metaPath, 'utf-8'));
                if (meta.cloud_repo_id) {
                    return `https://logthread.dev/explore/${meta.cloud_repo_id}`;
                }
            }
        } catch (error) {
            this.outputChannel.appendLine(`Error getting cloud URL: ${error}`);
        }
        return 'https://logthread.dev/dashboard';
    }

    private getProjectId(workspacePath: string): string {
        return crypto.createHash('sha256').update(workspacePath).digest('hex').substring(0, 16);
    }

    /** Start the MCP server immediately if the workspace is already indexed. */
    async startMcpIfIndexed(workspacePath: string): Promise<void> {
        const indexed = this.isWorkspaceIndexed(workspacePath);
        this.outputChannel.appendLine(`Log Thread: startMcpIfIndexed — workspace=${workspacePath}, indexed=${indexed}, hasMcpManager=${!!this.mcpManager}`);
        if (indexed && this.mcpManager) {
            try {
                await this.mcpManager.initialize(workspacePath);
                this.isIndexed = true;
                this.outputChannel.appendLine('Log Thread: MCP server started (existing index found)');
            } catch (err) {
                this.outputChannel.appendLine(`Log Thread: startMcpIfIndexed failed (non-fatal) — ${err}`);
            }
        }
    }

    /**
     * Check whether logthread has already indexed this workspace.
     * The CLI stores its DB under ~/Library/Application Support/logthread/projects/
     * (macOS) or ~/.local/share/logthread/projects/ (Linux), NOT inside the workspace.
     * We also check ~/.logthread/repos/ which contains per-repo metadata.
     */
    private isWorkspaceIndexed(workspacePath: string): boolean {
        try {
            // Fast check: ~/.logthread/repos/<name>/meta.json with matching path
            const reposDir = path.join(os.homedir(), '.logthread', 'repos');
            if (fs.existsSync(reposDir)) {
                for (const entry of fs.readdirSync(reposDir)) {
                    const metaPath = path.join(reposDir, entry, 'meta.json');
                    if (fs.existsSync(metaPath)) {
                        try {
                            const meta = JSON.parse(fs.readFileSync(metaPath, 'utf-8'));
                            if (meta.path === workspacePath || meta._repo_path === workspacePath) {
                                return true;
                            }
                        } catch { /* skip invalid meta */ }
                    }
                }
            }
            // Fallback: check if logthread status exits 0 (slower — spawns a process)
            try {
                const { execSync } = require('child_process');
                execSync('logthread status', { cwd: workspacePath, stdio: 'ignore', timeout: 5000 });
                return true;
            } catch {
                return false;
            }
        } catch {
            return false;
        }
    }

    async analyzeWorkspace(workspacePath: string): Promise<void> {
        this.outputChannel.show();
        this.outputChannel.appendLine('Log Thread: Analyzing workspace...');

        // No need to dispose MCP — the server uses a ConnectionLease that
        // auto-releases the DB lock after 3s of idle.  The CLI analyze command
        // retries for up to 6s so it will acquire the lock once the lease expires.

        return new Promise((resolve, reject) => {
            const homeDir = os.homedir();
            const extraPaths = [
                path.join(homeDir, '.pyenv', 'shims'),
                path.join(homeDir, '.local', 'bin'),
                '/usr/local/bin',
                '/opt/homebrew/bin'
            ];
            const currentPath = process.env.PATH || '';
            const enhancedPath = [...extraPaths, currentPath].join(path.delimiter);

            const proc = spawn('logthread', ['analyze', workspacePath], {
                cwd: workspacePath,
                env: { ...process.env, PATH: enhancedPath },
                shell: process.platform === 'win32'
            });

            let allOutput = '';

            proc.stdout?.on('data', (data: Buffer) => {
                const text = data.toString();
                allOutput += text;
                const line = text.trim();
                if (line && !line.match(/kuzu|cypher|mcp|sql|bolt|neo4j|debug|trace/i)) {
                    this.outputChannel.appendLine(line);
                }
            });

            proc.stderr?.on('data', (data: Buffer) => {
                const text = data.toString();
                allOutput += text;
                const line = text.trim();
                if (line) {
                    this.outputChannel.appendLine(`  ⚠ ${line}`);
                }
            });

            proc.on('close', async (code: number | null) => {
                if (code === 0) {
                    this.isIndexed = true;
                    try {
                        // Short wait for WAL flush, then (re)start MCP
                        await new Promise(r => setTimeout(r, 2000));
                        await this.mcpManager?.initialize(workspacePath);
                        this.outputChannel.appendLine('Log Thread: Analysis complete ✓');
                    } catch (err) {
                        this.outputChannel.appendLine(`Log Thread: MCP reconnect deferred — ${err}`);
                    }
                    resolve();
                } else {
                    const cleaned = allOutput.replace(/\[\/?[a-z\s]+\]/gi, '').trim();
                    const errorLines = cleaned.split('\n').filter(l =>
                        /error|not logged|subscription|login|failed|exception|traceback|locked|database/i.test(l)
                    );
                    const reason = errorLines.length > 0
                        ? errorLines.slice(0, 3).join(' | ').trim()
                        : `exit code ${code}`;
                    this.outputChannel.appendLine(`Log Thread: analyze failed — ${reason}`);
                    reject(new Error(reason));
                }
            });

            proc.on('error', (error: Error) => {
                this.outputChannel.appendLine(`Log Thread: spawn error — ${error.message}`);
                reject(error);
            });
        });
    }

    async clearAndReindex(workspacePath: string): Promise<void> {
        this.outputChannel.show();
        this.outputChannel.appendLine('Log Thread: Clearing index...');
        this.isIndexed = false;

        // Dispose MCP for clean — we're deleting the entire DB so the lease
        // pattern alone isn't enough; we need no readers at all.
        if (this.mcpManager) {
            try { await this.mcpManager.dispose(); } catch { /* ignore */ }
        }

        const homeDir = os.homedir();
        const extraPaths = [
            path.join(homeDir, '.pyenv', 'shims'),
            path.join(homeDir, '.local', 'bin'),
            '/usr/local/bin',
            '/opt/homebrew/bin'
        ];
        const enhancedPath = [...extraPaths, process.env.PATH || ''].join(path.delimiter);
        const spawnEnv = { ...process.env, PATH: enhancedPath };

        await new Promise<void>((resolve) => {
            const cleanProc = spawn('logthread', ['clean', '--force'], {
                cwd: workspacePath,
                env: spawnEnv,
                shell: process.platform === 'win32'
            });
            cleanProc.stdout?.on('data', (d: Buffer) => this.outputChannel.appendLine(d.toString().trim()));
            cleanProc.stderr?.on('data', (d: Buffer) => this.outputChannel.appendLine(`  ⚠ ${d.toString().trim()}`));
            cleanProc.on('close', () => resolve());
            cleanProc.on('error', () => resolve());
        });

        this.outputChannel.appendLine('Log Thread: Index cleared. Starting fresh analysis...');
        await this.analyzeWorkspace(workspacePath);
    }

    async getContext(symbol: string, retries: number = 2): Promise<SymbolContext | null> {
        for (let attempt = 0; attempt <= retries; attempt++) {
            try {
                const result = await this.callMcpTool('logthread_context', { symbol });
                return this.parseContextResult(result);
            } catch {
                if (attempt === retries) return null;
                await new Promise(resolve => setTimeout(resolve, 100));
            }
        }
        return null;
    }

    async getImpact(symbol: string, depth: number = 3): Promise<ImpactResult | null> {
        try {
            const result = await this.callMcpTool('logthread_impact', { symbol, depth });
            return this.parseImpactResult(result, symbol);
        } catch {
            return null;
        }
    }

    async getContextForPosition(
        filePath: string,
        line: number,
        character: number,
        depth: number = 3
    ): Promise<GraphContext | null> {
        try {
            // Get file context first
            const fileContext = await this.callMcpTool('logthread_file_context', {
                file_path: filePath
            });

            // Find the symbol at the position
            const symbols = this.parseFileContext(fileContext);
            const currentSymbol = symbols.find(s =>
                line >= s.startLine && line <= s.endLine
            );

            if (!currentSymbol) {
                return null;
            }

            // Get full context for the symbol
            const context = await this.getContext(currentSymbol.name);
            if (!context) {
                return null;
            }

            // Build comprehensive graph context
            const graphContext: GraphContext = {
                symbols: [context],
                relationships: [],
                relevantCode: [],
                entryPoints: []
            };

            const visited = new Set<string>([context.name]);
            const symbolQueue: Array<{name: string; currentDepth: number; direction: 'caller' | 'callee' | 'type'}> = [];

            // Queue initial neighbors
            context.callers.forEach(caller => 
                symbolQueue.push({name: caller, currentDepth: 1, direction: 'caller'})
            );
            context.callees.forEach(callee => 
                symbolQueue.push({name: callee, currentDepth: 1, direction: 'callee'})
            );
            context.typeRefs.forEach(typeRef => 
                symbolQueue.push({name: typeRef, currentDepth: 1, direction: 'type'})
            );

            // BFS traversal to build complete graph
            while (symbolQueue.length > 0 && graphContext.symbols.length < 100) {
                const {name: symbolName, currentDepth, direction} = symbolQueue.shift()!;
                
                if (visited.has(symbolName) || currentDepth > depth) {
                    continue;
                }
                
                visited.add(symbolName);
                
                const symbolContext = await this.getContext(symbolName);
                if (!symbolContext) continue;

                graphContext.symbols.push(symbolContext);

                // Add relationship based on direction
                if (direction === 'caller') {
                    graphContext.relationships.push({
                        from: symbolName,
                        to: context.name,
                        type: 'CALLS',
                        confidence: 1.0
                    });
                } else if (direction === 'callee') {
                    graphContext.relationships.push({
                        from: context.name,
                        to: symbolName,
                        type: 'CALLS',
                        confidence: 1.0
                    });
                } else if (direction === 'type') {
                    graphContext.relationships.push({
                        from: context.name,
                        to: symbolName,
                        type: 'USES_TYPE',
                        confidence: 1.0
                    });
                }

                // Continue traversal if within depth limit
                if (currentDepth < depth) {
                    // Add transitive callers (who calls this caller?)
                    symbolContext.callers.slice(0, 10).forEach(caller => {
                        if (!visited.has(caller)) {
                            symbolQueue.push({name: caller, currentDepth: currentDepth + 1, direction: 'caller'});
                        }
                    });

                    // Add transitive callees (what does this callee call?)
                    symbolContext.callees.slice(0, 10).forEach(callee => {
                        if (!visited.has(callee)) {
                            symbolQueue.push({name: callee, currentDepth: currentDepth + 1, direction: 'callee'});
                        }
                    });

                    // Add type references
                    symbolContext.typeRefs.slice(0, 5).forEach(typeRef => {
                        if (!visited.has(typeRef)) {
                            symbolQueue.push({name: typeRef, currentDepth: currentDepth + 1, direction: 'type'});
                        }
                    });
                }
            }

            // Fetch entry points to show complete flow
            const entryPoints = await this.getEntryPoints('all');
            graphContext.entryPoints = entryPoints.filter(ep => 
                graphContext.symbols.some(s => s.name === ep.name || s.filePath === ep.path)
            );

            // Add cross-references between collected symbols
            for (const symbol of graphContext.symbols) {
                for (const callee of symbol.callees) {
                    if (visited.has(callee) && !graphContext.relationships.some(
                        r => r.from === symbol.name && r.to === callee && r.type === 'CALLS'
                    )) {
                        graphContext.relationships.push({
                            from: symbol.name,
                            to: callee,
                            type: 'CALLS',
                            confidence: 0.9
                        });
                    }
                }

                for (const typeRef of symbol.typeRefs) {
                    if (visited.has(typeRef) && !graphContext.relationships.some(
                        r => r.from === symbol.name && r.to === typeRef && r.type === 'USES_TYPE'
                    )) {
                        graphContext.relationships.push({
                            from: symbol.name,
                            to: typeRef,
                            type: 'USES_TYPE',
                            confidence: 0.8
                        });
                    }
                }
            }

            return graphContext;
        } catch (error) {
            void error; // internal
            return null;
        }
    }

    async runCypher(query: string): Promise<string> {
        return this.callMcpTool('logthread_cypher', { query });
    }

    async getEntryPoints(type: 'web_routes' | 'cli_commands' | 'main_functions' | 'public_api' | 'all' = 'all'): Promise<EntryPoint[]> {
        const entryPoints: EntryPoint[] = [];

        try {
            let query = '';

            if (type === 'web_routes' || type === 'all') {
                // Find HTTP route handlers
                query = `
                    MATCH (n)
                    WHERE (n:Function OR n:Method) 
                    AND (n.name =~ '.*[Cc]ontroller.*' OR n.name =~ '.*[Hh]andler.*' OR n.name =~ '.*[Rr]oute.*')
                    RETURN n.name AS name, n.file_path AS path, n.start_line AS line, 'route' AS type
                    LIMIT 50
                `;
                const routeResult = await this.runCypher(query);
                const parsed = this.parseEntryPointsFromCypher(routeResult, 'route');
                entryPoints.push(...parsed);
            }

            if (type === 'main_functions' || type === 'all') {
                // Find main entry points
                query = `
                    MATCH (n:Function)
                    WHERE n.name IN ['main', 'Main', 'run', 'start', 'init', 'execute']
                    OR n.name =~ '.*main.*'
                    RETURN n.name AS name, n.file_path AS path, n.start_line AS line, 'main' AS type
                    LIMIT 50
                `;
                const mainResult = await this.runCypher(query);
                const parsed = this.parseEntryPointsFromCypher(mainResult, 'main');
                entryPoints.push(...parsed);
            }

            if (type === 'cli_commands' || type === 'all') {
                // Find CLI command handlers
                query = `
                    MATCH (n)
                    WHERE (n:Function OR n:Method)
                    AND (n.name =~ '.*[Cc]ommand.*' OR n.name =~ '.*[Cc]li.*')
                    RETURN n.name AS name, n.file_path AS path, n.start_line AS line, 'cli' AS type
                    LIMIT 50
                `;
                const cliResult = await this.runCypher(query);
                const parsed = this.parseEntryPointsFromCypher(cliResult, 'cli');
                entryPoints.push(...parsed);
            }

            if (type === 'public_api' || type === 'all') {
                // Find public API functions (exported functions/classes)
                query = `
                    MATCH (n)
                    WHERE (n:Function OR n:Class)
                    AND (n.visibility = 'public' OR n.exported = true)
                    RETURN n.name AS name, n.file_path AS path, n.start_line AS line, 'public_api' AS type
                    LIMIT 50
                `;
                const apiResult = await this.runCypher(query);
                const parsed = this.parseEntryPointsFromCypher(apiResult, 'public_api');
                entryPoints.push(...parsed);
            }

        } catch (error) {
            /* suppress internal errors */ void error;
        }

        return entryPoints;
    }

    /**
     * Get comprehensive graph context for a symbol including all related nodes
     * up to the specified depth. This provides the complete end-to-end picture.
     */
    async getComprehensiveGraph(symbolName: string, maxDepth: number = 4, maxNodes: number = 200): Promise<GraphContext | null> {
        try {
            const graphContext: GraphContext = {
                symbols: [],
                relationships: [],
                relevantCode: [],
                entryPoints: []
            };

            const visited = new Set<string>();
            const symbolQueue: Array<{name: string; depth: number}> = [{name: symbolName, depth: 0}];
            
            // BFS to collect all related symbols
            while (symbolQueue.length > 0 && graphContext.symbols.length < maxNodes) {
                const {name, depth} = symbolQueue.shift()!;
                
                if (visited.has(name) || depth > maxDepth) {
                    continue;
                }
                
                visited.add(name);
                
                const context = await this.getContext(name);
                if (!context) continue;

                graphContext.symbols.push(context);

                // Add all relationships from this symbol
                context.callers.forEach(caller => {
                    graphContext.relationships.push({
                        from: caller,
                        to: name,
                        type: 'CALLS',
                        confidence: 1.0
                    });
                    if (!visited.has(caller) && depth < maxDepth) {
                        symbolQueue.push({name: caller, depth: depth + 1});
                    }
                });

                context.callees.forEach(callee => {
                    graphContext.relationships.push({
                        from: name,
                        to: callee,
                        type: 'CALLS',
                        confidence: 1.0
                    });
                    if (!visited.has(callee) && depth < maxDepth) {
                        symbolQueue.push({name: callee, depth: depth + 1});
                    }
                });

                context.typeRefs.forEach(typeRef => {
                    graphContext.relationships.push({
                        from: name,
                        to: typeRef,
                        type: 'USES_TYPE',
                        confidence: 0.9
                    });
                    if (!visited.has(typeRef) && depth < maxDepth) {
                        symbolQueue.push({name: typeRef, depth: depth + 1});
                    }
                });
            }

            // Fetch related database tables and API endpoints via Cypher
            const relatedNodesQuery = `
                MATCH (n)-[r:CodeRelation]-(m)
                WHERE n.name IN [${Array.from(visited).map(s => `"${s.replace(/"/g, '\\"')}"`).join(', ')}]
                AND (m:DbTable OR m:DbColumn OR m:ApiEndpoint OR m:ExternalDep)
                RETURN DISTINCT m.name AS name, m.file_path AS filePath, labels(m)[0] AS type, 
                       m.start_line AS startLine, m.end_line AS endLine
                LIMIT 50
            `;

            try {
                const relatedResult = await this.runCypher(relatedNodesQuery);
                const relatedSymbols = this.parseQueryResult(relatedResult);
                
                for (const relatedSymbol of relatedSymbols) {
                    if (!visited.has(relatedSymbol.name)) {
                        graphContext.symbols.push(relatedSymbol);
                        visited.add(relatedSymbol.name);
                    }
                }
            } catch {
                // Continue without related nodes if query fails
            }

            // Get entry points that connect to this graph
            const entryPoints = await this.getEntryPoints('all');
            graphContext.entryPoints = entryPoints.filter(ep => 
                visited.has(ep.name)
            );

            // Deduplicate relationships
            const relationshipKeys = new Set<string>();
            graphContext.relationships = graphContext.relationships.filter(rel => {
                const key = `${rel.from}:${rel.to}:${rel.type}`;
                if (relationshipKeys.has(key)) return false;
                relationshipKeys.add(key);
                return true;
            });

            return graphContext;
        } catch (error) {
            this.outputChannel.appendLine(`Error getting comprehensive graph: ${error}`);
            return null;
        }
    }

    /**
     * Get the complete execution path from entry points to a target symbol.
     * This shows the end-to-end flow through the codebase.
     */
    async getExecutionPath(targetSymbol: string): Promise<GraphContext | null> {
        try {
            // First, get all entry points
            const entryPoints = await this.getEntryPoints('all');
            
            if (entryPoints.length === 0) {
                // Fallback to comprehensive graph if no entry points found
                return this.getComprehensiveGraph(targetSymbol, 5, 300);
            }

            const graphContext: GraphContext = {
                symbols: [],
                relationships: [],
                relevantCode: [],
                entryPoints: entryPoints
            };

            const visited = new Set<string>();
            
            // For each entry point, trace paths to the target
            for (const entryPoint of entryPoints.slice(0, 10)) {
                const pathContext = await this.tracePath(entryPoint.name, targetSymbol, visited);
                
                if (pathContext) {
                    graphContext.symbols.push(...pathContext.symbols);
                    graphContext.relationships.push(...pathContext.relationships);
                }
            }

            // Also add the target's immediate neighborhood
            const targetContext = await this.getContext(targetSymbol);
            if (targetContext && !visited.has(targetSymbol)) {
                graphContext.symbols.push(targetContext);
                visited.add(targetSymbol);

                // Add immediate neighbors
                for (const callee of targetContext.callees.slice(0, 15)) {
                    const calleeContext = await this.getContext(callee);
                    if (calleeContext && !visited.has(callee)) {
                        graphContext.symbols.push(calleeContext);
                        visited.add(callee);
                        graphContext.relationships.push({
                            from: targetSymbol,
                            to: callee,
                            type: 'CALLS',
                            confidence: 1.0
                        });
                    }
                }
            }

            // Deduplicate
            const symbolMap = new Map<string, SymbolContext>();
            graphContext.symbols.forEach(s => symbolMap.set(s.name, s));
            graphContext.symbols = Array.from(symbolMap.values());

            const relationshipKeys = new Set<string>();
            graphContext.relationships = graphContext.relationships.filter(rel => {
                const key = `${rel.from}:${rel.to}:${rel.type}`;
                if (relationshipKeys.has(key)) return false;
                relationshipKeys.add(key);
                return true;
            });

            return graphContext;
        } catch (error) {
            this.outputChannel.appendLine(`Error getting execution path: ${error}`);
            return null;
        }
    }

    /**
     * Trace a path from source to target symbol using BFS.
     */
    private async tracePath(source: string, target: string, globalVisited: Set<string>): Promise<GraphContext | null> {
        const pathContext: GraphContext = {
            symbols: [],
            relationships: [],
            relevantCode: []
        };

        const visited = new Set<string>([source]);
        const queue: Array<{name: string; path: string[]}> = [{name: source, path: [source]}];
        const maxPathLength = 8;
        let foundPath = false;

        while (queue.length > 0 && !foundPath) {
            const {name, path} = queue.shift()!;
            
            if (path.length > maxPathLength) continue;

            const context = await this.getContext(name);
            if (!context) continue;

            if (!globalVisited.has(name)) {
                pathContext.symbols.push(context);
                globalVisited.add(name);
            }

            // Check if we reached the target
            if (name === target) {
                foundPath = true;
                break;
            }

            // Explore callees
            for (const callee of context.callees) {
                if (!visited.has(callee)) {
                    visited.add(callee);
                    queue.push({name: callee, path: [...path, callee]});
                    
                    pathContext.relationships.push({
                        from: name,
                        to: callee,
                        type: 'CALLS',
                        confidence: 1.0
                    });

                    if (callee === target) {
                        foundPath = true;
                        const calleeContext = await this.getContext(callee);
                        if (calleeContext && !globalVisited.has(callee)) {
                            pathContext.symbols.push(calleeContext);
                            globalVisited.add(callee);
                        }
                        break;
                    }
                }
            }
        }

        return foundPath ? pathContext : null;
    }

    private parseEntryPointsFromCypher(result: string, defaultType: EntryPoint['type']): EntryPoint[] {
        const entryPoints: EntryPoint[] = [];
        const lines = result.split('\n');

        for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed || trimmed.startsWith('Results') || trimmed.startsWith('---')) continue;

            // Pattern: "1. name | path | line | type"
            const match = trimmed.match(/^\d+\.\s*([^\|]+)\s*\|\s*([^\|]+)\s*\|\s*(\d+)\s*\|\s*(\w+)/);
            if (match) {
                entryPoints.push({
                    name: match[1].trim(),
                    path: match[2].trim(),
                    line: parseInt(match[3], 10),
                    type: (match[4].trim() as EntryPoint['type']) || defaultType
                });
            }
        }

        return entryPoints;
    }

    async query(searchQuery: string, limit: number = 50): Promise<SymbolContext[]> {
        // logthread_query uses embedding/semantic search which consistently crashes the MCP server
        // with -32000 "Connection closed". Use Cypher keyword matching instead — reliable and fast.
        try {
            const words = searchQuery
                .replace(/[^\w\s]/g, ' ')
                .split(/\s+/)
                .filter(w => w.length > 2)
                .slice(0, 3);
            if (words.length === 0) return [];

            // Case-insensitive name match across Function, Method, Class nodes
            const conditions = words.map(w =>
                `n.name =~ '(?i).*${w.replace(/'/g, "\\'")}.*'`
            ).join(' OR ');

            const cypher = `MATCH (n) WHERE (n:Function OR n:Class OR n:Method OR n:Interface OR n:Variable OR n:ApiEndpoint OR n:DbTable OR n:ExternalDep) AND (${conditions}) RETURN n.name AS name, n.file_path AS filePath, n.start_line AS startLine, n.end_line AS endLine, labels(n)[0] AS type LIMIT ${limit}`;
            const result = await this.callMcpTool('logthread_cypher', { query: cypher });
            return this.parseQueryResult(result);
        } catch {
            return [];
        }
    }

    /**
     * Schedule a debounced incremental reindex.
     * All file-change events within REINDEX_DEBOUNCE_MS of each other are
     * collapsed into a single reindex run.  The actual reindex follows the
     * same MCP lifecycle as analyzeWorkspace: ConnectionLease handles lock, reinitialize MCP after.
     */
    async reindexFile(_filePath: string): Promise<void> {
        if (this.reindexTimer) clearTimeout(this.reindexTimer);
        this.reindexTimer = setTimeout(() => {
            this.reindexTimer = null;
            this._doReindex().catch(() => { });
        }, LogThreadService.REINDEX_DEBOUNCE_MS);
    }

    private async _doReindex(): Promise<void> {
        if (this.reindexInProgress) return;
        if (!this._isLoggedIn) return; // skip silently if not authenticated

        const folders = vscode.workspace.workspaceFolders;
        if (!folders || folders.length === 0) return;
        const workspacePath = folders[0].uri.fsPath;

        this.reindexInProgress = true;
        this.outputChannel.appendLine('Log Thread: incremental reindex triggered by file change...');
        try {
            // No need to dispose MCP — the server uses a ConnectionLease that
            // auto-releases the DB lock after 3s of idle.  The CLI analyze command
            // retries for up to 6s so it will acquire the lock once the lease expires.
            const homeDir = os.homedir();
            const extraPaths = [
                path.join(homeDir, '.pyenv', 'shims'),
                path.join(homeDir, '.local', 'bin'),
                '/usr/local/bin',
                '/opt/homebrew/bin'
            ];
            const enhancedPath = [...extraPaths, process.env.PATH || ''].join(path.delimiter);

            const code = await new Promise<number | null>((resolve) => {
                const proc = spawn('logthread', ['analyze', workspacePath], {
                    cwd: workspacePath,
                    env: { ...process.env, PATH: enhancedPath },
                    stdio: 'ignore',
                });
                proc.on('close', resolve);
                proc.on('error', () => resolve(null));
            });

            if (code === 0) {
                this.isIndexed = true;
                this.outputChannel.appendLine('Log Thread: incremental reindex complete ✓');
                // Short wait for WAL flush, then reinitialize MCP with fresh DB state
                await new Promise(r => setTimeout(r, 2000));
                await this.mcpManager?.initialize(workspacePath).catch((err) => {
                    this.outputChannel.appendLine(`Log Thread: MCP reconnect after reindex deferred — ${err}`);
                });
            } else {
                this.outputChannel.appendLine(`Log Thread: incremental reindex exited with code ${code}`);
            }
        } catch (err) {
            this.outputChannel.appendLine(`Log Thread: incremental reindex error — ${err}`);
        } finally {
            this.reindexInProgress = false;
        }
    }

    async removeFile(_filePath: string): Promise<void> {
        // Treat a deleted file the same as a changed file — schedule a debounced reindex.
        // logthread analyze (incremental) will automatically drop symbols for missing files.
        await this.reindexFile(_filePath);
    }

    async callMcpTool(toolName: string, args: Record<string, unknown>): Promise<string> {
        return this.callMcpToolDirect('logthread', toolName, args);
    }

    async callMcpToolDirect(serverName: string, toolName: string, args: Record<string, unknown>): Promise<string> {
        if (!this.mcpManager) {
            throw new Error('MCP Manager not initialized');
        }

        const connected = this.mcpManager.isConnected(serverName);
        this.outputChannel.appendLine(`Log Thread: callMcpTool(${toolName}) — connected=${connected}, graphAvailable=${this.isGraphAvailable()}`);

        try {
            const t0 = Date.now();
            const result = await this.mcpManager.callTool(serverName, toolName, args);
            this.outputChannel.appendLine(`Log Thread: callMcpTool(${toolName}) OK in ${Date.now() - t0}ms`);

            if (result.content && Array.isArray(result.content)) {
                return result.content.map((c: any) => c.type === 'text' ? c.text : JSON.stringify(c)).join('\n');
            }

            return typeof result === 'string' ? result : JSON.stringify(result);
        } catch (error) {
            this.outputChannel.appendLine(`Log Thread: callMcpTool(${toolName}) FAILED: ${error}`);
            throw error;
        }
    }

    async getMcpManager(): Promise<MCPManager | null> {
        return this.mcpManager;
    }

    private normalizeNodeType(raw: string): string {
        const cleaned = String(raw || '').trim();
        if (!cleaned) return '';
        return cleaned
            .split(/[\s_]+/)
            .map(part => part ? part.charAt(0).toUpperCase() + part.slice(1).toLowerCase() : '')
            .join('');
    }

    private parseContextResult(result: string): SymbolContext | null {
        try {
            const lines = result.split('\n');
            const context: Partial<SymbolContext> = {
                callers: [],
                callees: [],
                typeRefs: [],
                isDead: false
            };
            let currentSection = '';

            for (const line of lines) {
                const trimmed = line.trim();
                if (!trimmed) continue;

                const symbolMatch = trimmed.match(/^Symbol:\s+(.+?)\s+\(([^)]+)\)$/);
                if (symbolMatch) {
                    context.name = symbolMatch[1].trim();
                    context.type = this.normalizeNodeType(symbolMatch[2]);
                    currentSection = '';
                    continue;
                }

                const fileMatch = trimmed.match(/^File:\s+(.+?)(?::(\d+)-(\d+))?$/);
                if (fileMatch) {
                    context.filePath = fileMatch[1].trim();
                    context.startLine = parseInt(fileMatch[2] || '0', 10);
                    context.endLine = parseInt(fileMatch[3] || '0', 10);
                    currentSection = '';
                    continue;
                }

                if (/^Callers \(\d+\):$/.test(trimmed)) {
                    currentSection = 'callers';
                    continue;
                }
                if (/^Callees \(\d+\):$/.test(trimmed)) {
                    currentSection = 'callees';
                    continue;
                }
                if (/^Type references \(\d+\):$/.test(trimmed)) {
                    currentSection = 'typeRefs';
                    continue;
                }
                if (trimmed === 'Dependency trace:') {
                    currentSection = 'trace';
                    continue;
                }
                if (/^(Direct links|Depth \d+):$/.test(trimmed)) {
                    continue;
                }

                const arrowMatch = trimmed.match(/^->\s+(.+?)(?:\s{2,}.*)?$/);
                if (arrowMatch) {
                    const refName = arrowMatch[1].trim();
                    if (currentSection === 'callers') {
                        context.callers?.push(refName);
                    } else if (currentSection === 'callees') {
                        context.callees?.push(refName);
                    } else if (currentSection === 'typeRefs') {
                        context.typeRefs?.push(refName);
                    }
                    continue;
                }

                const traceMatch = trimmed.match(/^- .*?--[^>]+-->\s+(.+?)\s+\([^)]+\)(?:\s{2,}.*)?$/);
                if (traceMatch && currentSection === 'trace') {
                    const refName = traceMatch[1].trim();
                    if (refName && !context.callees?.includes(refName)) {
                        context.callees?.push(refName);
                    }
                }
            }

            if (!context.name) {
                return null;
            }

            context.type = this.normalizeNodeType(context.type || '');
            return context as SymbolContext;
        } catch {
            return null;
        }
    }

    private parseImpactResult(result: string, symbol: string): ImpactResult {
        const impact: ImpactResult = {
            symbol,
            affectedCount: 0,
            direct: [],
            indirect: [],
            transitive: []
        };

        // Parse the CLI output
        const lines = result.split('\n');
        let currentSection = '';

        for (const line of lines) {
            if (line.includes('Depth 1') || line.includes('Direct')) {
                currentSection = 'direct';
            } else if (line.includes('Depth 2') || line.includes('Indirect')) {
                currentSection = 'indirect';
            } else if (line.includes('Depth 3') || line.includes('Transitive')) {
                currentSection = 'transitive';
            } else if (line.trim().startsWith('-') || line.trim().startsWith('•')) {
                const symbolName = line.replace(/[-•]/g, '').trim();
                if (symbolName && currentSection) {
                    impact[currentSection as 'direct' | 'indirect' | 'transitive'].push(symbolName);
                }
            }
        }

        impact.affectedCount = impact.direct.length + impact.indirect.length + impact.transitive.length;
        return impact;
    }

    private parseFileContext(result: string): SymbolContext[] {
        // Parse file context from CLI output
        return [];
    }

    private parseQueryResult(result: string): SymbolContext[] {
        const symbols: SymbolContext[] = [];
        try {
            const lines = result.split('\n');

            for (const line of lines) {
                const trimmed = line.trim();
                if (!trimmed || trimmed.startsWith('Results') || trimmed.startsWith('Query returned')) continue;

                // Match Cypher row format: "1. name | filePath | startLine | endLine | type"
                // This is what handle_cypher() returns from the MCP tool
                const cypherMatch = trimmed.match(/^\d+\.\s+([^\|]+)\s*\|\s*([^\|]+)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\w+)/);
                if (cypherMatch) {
                    const name = cypherMatch[1].trim();
                    if (name && name !== 'None') {
                        symbols.push({
                            name,
                            filePath: cypherMatch[2].trim(),
                            startLine: parseInt(cypherMatch[3], 10),
                            endLine: parseInt(cypherMatch[4], 10),
                            type: cypherMatch[5].trim(),
                            callers: [],
                            callees: [],
                            typeRefs: [],
                            isDead: false
                        });
                    }
                    continue;
                }

                // Match CLI format: "1. CloudAuth (Class) -- src/logthread/cloud/auth.py"
                const cliMatch = trimmed.match(/^\d+\.\s+([\w.]+)\s+\(([^)]+)\)\s+--\s+(.+)$/);
                if (cliMatch) {
                    const filePath = cliMatch[3].trim();
                    symbols.push({
                        name: cliMatch[1],
                        type: cliMatch[2],
                        filePath: filePath,
                        startLine: 0,
                        endLine: 0,
                        callers: [],
                        callees: [],
                        typeRefs: [],
                        isDead: false
                    });
                    continue;
                }

                // Match patterns like "- symbol_name (Function) in path/to/file.py:123"
                const symbolMatch = trimmed.match(/^[-•●]\s*([\w.]+)\s*\(([^)]+)\)\s*(?:in\s+)?([^:]+)?:?(\d+)?/);
                if (symbolMatch) {
                    symbols.push({
                        name: symbolMatch[1],
                        type: symbolMatch[2],
                        filePath: symbolMatch[3] || '',
                        startLine: parseInt(symbolMatch[4] || '0', 10),
                        endLine: parseInt(symbolMatch[4] || '0', 10),
                        callers: [],
                        callees: [],
                        typeRefs: [],
                        isDead: false
                    });
                    continue;
                }

                // Match table-like format: "name | type | file:line"
                const tableMatch = trimmed.match(/^([\w.]+)\s*\|\s*([\w]+)\s*\|\s*([^:]+):(\d+)/);
                if (tableMatch) {
                    symbols.push({
                        name: tableMatch[1],
                        type: tableMatch[2],
                        filePath: tableMatch[3],
                        startLine: parseInt(tableMatch[4], 10),
                        endLine: parseInt(tableMatch[4], 10),
                        callers: [],
                        callees: [],
                        typeRefs: [],
                        isDead: false
                    });
                    continue;
                }

                // Match JSON-like output
                if (trimmed.startsWith('{') && trimmed.includes('"name"')) {
                    try {
                        const parsed = JSON.parse(trimmed);
                        symbols.push({
                            name: parsed.name || '',
                            type: parsed.type || parsed.label || 'Unknown',
                            filePath: parsed.file_path || parsed.filePath || '',
                            startLine: parsed.start_line || parsed.startLine || 0,
                            endLine: parsed.end_line || parsed.endLine || 0,
                            callers: [],
                            callees: [],
                            typeRefs: [],
                            isDead: parsed.is_dead || false
                        });
                    } catch {
                        // Not valid JSON, skip
                    }
                }
            }
        } catch (error) {
            void error; // internal
        }

        return symbols;
    }

    async dispose(): Promise<void> {
        if (this.reindexTimer) {
            clearTimeout(this.reindexTimer);
            this.reindexTimer = null;
        }
        if (this.mcpProcess) {
            this.mcpProcess.kill();
            this.mcpProcess = null;
        }
        if (this.mcpManager) {
            await this.mcpManager.dispose();
            this.mcpManager.disposeChannel();
        }
        this.outputChannel.dispose();
    }
}
