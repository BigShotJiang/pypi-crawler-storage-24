/**
 * Context Cache Service
 * Caches fetched context within a conversation to minimize redundant API calls and save tokens
 */

export interface CachedContext {
    type: 'symbol' | 'file' | 'cypher' | 'entry_points';
    key: string;
    data: any;
    timestamp: number;
    tokens: number; // Approximate token count
}

export class ContextCache {
    private cache: Map<string, CachedContext> = new Map();
    private maxCacheSize = 50; // Maximum number of cached items
    private maxAge = 30 * 60 * 1000; // 30 minutes

    /**
     * Generate cache key from query parameters
     */
    private generateKey(type: string, query: string, params?: Record<string, any>): string {
        const paramStr = params ? JSON.stringify(params) : '';
        return `${type}:${query}:${paramStr}`;
    }

    /**
     * Store context in cache
     */
    set(type: CachedContext['type'], query: string, data: any, params?: Record<string, any>): void {
        const key = this.generateKey(type, query, params);
        
        // Estimate tokens (rough approximation: 1 token ≈ 4 characters)
        const dataStr = typeof data === 'string' ? data : JSON.stringify(data);
        const tokens = Math.ceil(dataStr.length / 4);

        this.cache.set(key, {
            type,
            key,
            data,
            timestamp: Date.now(),
            tokens
        });

        // Enforce size limit (LRU eviction)
        if (this.cache.size > this.maxCacheSize) {
            const firstKey = this.cache.keys().next().value;
            if (firstKey) {
                this.cache.delete(firstKey);
            }
        }
    }

    /**
     * Retrieve cached context
     */
    get(type: CachedContext['type'], query: string, params?: Record<string, any>): any | null {
        const key = this.generateKey(type, query, params);
        const cached = this.cache.get(key);

        if (!cached) {
            return null;
        }

        // Check if expired
        if (Date.now() - cached.timestamp > this.maxAge) {
            this.cache.delete(key);
            return null;
        }

        return cached.data;
    }

    /**
     * Check if context is cached
     */
    has(type: CachedContext['type'], query: string, params?: Record<string, any>): boolean {
        return this.get(type, query, params) !== null;
    }

    /**
     * Get cache summary for system message
     */
    getSummary(): string {
        const items = Array.from(this.cache.values());
        const totalTokens = items.reduce((sum, item) => sum + item.tokens, 0);
        
        const byType = items.reduce((acc, item) => {
            acc[item.type] = (acc[item.type] || 0) + 1;
            return acc;
        }, {} as Record<string, number>);

        const summary = [
            `**Cached Context** (${items.length} items, ~${totalTokens} tokens saved):`
        ];

        for (const [type, count] of Object.entries(byType)) {
            const examples = items
                .filter(i => i.type === type)
                .slice(0, 3)
                .map(i => {
                    const keyParts = i.key.split(':');
                    return keyParts[1] || keyParts[0];
                });
            summary.push(`- ${type}: ${count} (e.g., ${examples.join(', ')})`);
        }

        return summary.join('\n');
    }

    /**
     * Clear all cached context
     */
    clear(): void {
        this.cache.clear();
    }

    /**
     * Clear expired entries
     */
    clearExpired(): void {
        const now = Date.now();
        for (const [key, value] of this.cache.entries()) {
            if (now - value.timestamp > this.maxAge) {
                this.cache.delete(key);
            }
        }
    }

    /**
     * Get all cached keys for debugging
     */
    getKeys(): string[] {
        return Array.from(this.cache.keys());
    }

    /**
     * Remove specific cached item
     */
    invalidate(type: CachedContext['type'], query: string, params?: Record<string, any>): void {
        const key = this.generateKey(type, query, params);
        this.cache.delete(key);
    }

    /**
     * Invalidate all items of a specific type
     */
    invalidateType(type: CachedContext['type']): void {
        for (const [key, value] of this.cache.entries()) {
            if (value.type === type) {
                this.cache.delete(key);
            }
        }
    }
}

// Singleton instance
export const contextCache = new ContextCache();
