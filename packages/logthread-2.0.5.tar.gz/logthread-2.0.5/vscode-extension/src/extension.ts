import * as vscode from 'vscode';
import * as path from 'path';
import { LogThreadService } from './services/logthread';
import { GraphViewProvider } from './views/graphView';

let logthreadService: LogThreadService;

export async function activate(context: vscode.ExtensionContext) {
    console.log('Log Thread extension activating...');

    // Initialize services
    logthreadService = new LogThreadService(context);

    // Register view providers
    const graphViewProvider = new GraphViewProvider(context, logthreadService);
    context.subscriptions.push(
        vscode.window.registerWebviewViewProvider('logthread.codeExplorer', graphViewProvider, {
            webviewOptions: {
                retainContextWhenHidden: true,
            },
        })
    );

    // Register commands
    context.subscriptions.push(
        vscode.commands.registerCommand('logthread.analyze', async () => {
            if (!logthreadService.isLoggedIn) {
                const login = await vscode.window.showWarningMessage(
                    'Log Thread: Please log in to analyze your workspace.',
                    'Login'
                );
                if (login === 'Login') {
                    await vscode.commands.executeCommand('logthread.login');
                }
                return;
            }
            await analyzeWorkspace();
        }),

        vscode.commands.registerCommand('logthread.showGraph', async () => {
            await vscode.commands.executeCommand('logthread.openGraphPanel');
        }),

        vscode.commands.registerCommand('logthread.impactAnalysis', async () => {
            const editor = vscode.window.activeTextEditor;
            if (!editor) return;

            const position = editor.selection.active;
            const wordRange = editor.document.getWordRangeAtPosition(position);
            if (!wordRange) return;

            const symbol = editor.document.getText(wordRange);
            const impact = await logthreadService.getImpact(symbol);
            
            if (impact) {
                vscode.window.showInformationMessage(
                    `Impact Analysis: ${impact.affectedCount} symbols affected`,
                    'Show Details'
                ).then(selection => {
                    if (selection === 'Show Details') {
                        showImpactDetails(impact);
                    }
                });
            }
        }),

        vscode.commands.registerCommand('logthread.openGraphPanel', () => {
            const panel = vscode.window.createWebviewPanel(
                'logthreadGraph',
                'Code Explorer',
                vscode.ViewColumn.Beside,
                { enableScripts: true, localResourceRoots: [context.extensionUri] }
            );
            panel.webview.html = graphViewProvider.getHtmlForPanel(panel.webview);
            graphViewProvider.attachPanel(panel);
        }),

        vscode.commands.registerCommand('logthread.login', async () => {
            try {
                const success = await logthreadService.login();
                if (success) {
                    vscode.window.showInformationMessage(`Logged in as ${logthreadService.userEmail}`);
                }
            } catch (error) {
                vscode.window.showErrorMessage('Login failed. Please try again.');
            }
        }),

        vscode.commands.registerCommand('logthread.logout', async () => {
            await logthreadService.logout();
            vscode.window.showInformationMessage('Logged out from Log Thread');
        }),

        vscode.commands.registerCommand('logthread.clearAndReindex', async () => {
            const workspaceFolders = vscode.workspace.workspaceFolders;
            if (!workspaceFolders) {
                vscode.window.showWarningMessage('No workspace folder open');
                return;
            }

            const confirm = await vscode.window.showWarningMessage(
                'This will delete the local index and rebuild it from scratch. Continue?',
                { modal: true },
                'Clear & Reindex'
            );
            if (confirm !== 'Clear & Reindex') return;

            await vscode.window.withProgress(
                {
                    location: vscode.ProgressLocation.Notification,
                    title: 'Log Thread: Clearing and reindexing...',
                    cancellable: false
                },
                async () => {
                    try {
                        await logthreadService.clearAndReindex(workspaceFolders[0].uri.fsPath);
                        vscode.window.showInformationMessage('Log Thread: Reindex complete ✓');
                    } catch (error: any) {
                        vscode.window.showErrorMessage(`Log Thread: Reindex failed — ${error?.message || error}`);
                    }
                }
            );
        }),

        vscode.commands.registerCommand('logthread.cloudSync', async () => {
            const workspaceFolders = vscode.workspace.workspaceFolders;
            if (!workspaceFolders) {
                vscode.window.showWarningMessage('No workspace folder open');
                return;
            }

            if (!logthreadService.isLoggedIn) {
                const login = await vscode.window.showInformationMessage(
                    'You need to log in to sync to Log Thread Cloud',
                    'Login'
                );
                if (login === 'Login') {
                    await vscode.commands.executeCommand('logthread.login');
                }
                return;
            }

            if (!logthreadService.hasCloudSyncConsent()) {
                const consent = await vscode.window.showInformationMessage(
                    'To sync to Log Thread Cloud, you must agree to our Terms of Service and Privacy Policy.\n\nYour code is NOT uploaded. Only the graph structure (symbols, relationships) is synced.',
                    { modal: true },
                    'View Terms',
                    'View Privacy',
                    'I Agree'
                );

                if (consent === 'View Terms') {
                    vscode.env.openExternal(vscode.Uri.parse('https://logthread.dev/terms'));
                    return;
                }
                if (consent === 'View Privacy') {
                    vscode.env.openExternal(vscode.Uri.parse('https://logthread.dev/privacy'));
                    return;
                }
                if (consent !== 'I Agree') {
                    return;
                }
                
                logthreadService.saveCloudSyncConsent();
            }

            await vscode.window.withProgress(
                {
                    location: vscode.ProgressLocation.Notification,
                    title: 'Syncing to Log Thread Cloud...',
                    cancellable: false
                },
                async () => {
                    const success = await logthreadService.syncToCloud(workspaceFolders[0].uri.fsPath);
                    if (success) {
                        vscode.window.showInformationMessage('Successfully synced to Log Thread Cloud!');
                    } else {
                        vscode.window.showErrorMessage('Failed to sync. Check the output for details.');
                    }
                }
            );
        })
    );

    const config = vscode.workspace.getConfiguration('logthread');
    const workspaceFolders = vscode.workspace.workspaceFolders;

    // Start MCP immediately for already-indexed workspaces.
    // The MCP server now uses ConnectionLease so it never holds the DB lock
    // idle — analyze can run concurrently without conflict.
    if (workspaceFolders) {
        for (const folder of workspaceFolders) {
            await logthreadService.startMcpIfIndexed(folder.uri.fsPath);
        }
    }

    const shouldAutoAnalyze = config.get('autoIndex') && await logthreadService.checkAuthStatus();
    if (shouldAutoAnalyze) {
        // Run analysis in background — don't block extension activation / chat loading
        analyzeWorkspace().catch(err => {
            console.log('Log Thread: auto-analyze failed:', err);
        });
    }

    // Always-on file watcher — reindex any changed source file automatically.
    // Debounced per-file so rapid saves (auto-save, formatter, AI edits) don't
    // queue up dozens of concurrent reindex processes.
    {
        const DEBOUNCE_MS = 1500;
        const pending = new Map<string, ReturnType<typeof setTimeout>>();
        const IGNORE = /node_modules|\.git|\.logthread|dist\/|build\/|out\/|__pycache__|\.next/;

        const schedule = (fsPath: string, action: 'reindex' | 'remove') => {
            if (IGNORE.test(fsPath)) return;
            const existing = pending.get(fsPath);
            if (existing) clearTimeout(existing);
            pending.set(fsPath, setTimeout(() => {
                pending.delete(fsPath);
                if (action === 'remove') {
                    logthreadService.removeFile(fsPath).catch(() => {});
                } else {
                    logthreadService.reindexFile(fsPath).catch(() => {});
                }
            }, DEBOUNCE_MS));
        };

        // Broad pattern — catch all common source languages
        const watcher = vscode.workspace.createFileSystemWatcher(
            '**/*.{ts,tsx,js,jsx,mjs,cjs,py,go,java,cs,rs,cpp,c,h,rb,swift,kt,scala,vue,svelte}'
        );

        watcher.onDidChange(uri => schedule(uri.fsPath, 'reindex'));
        watcher.onDidCreate(uri => schedule(uri.fsPath, 'reindex'));
        watcher.onDidDelete(uri => schedule(uri.fsPath, 'remove'));

        context.subscriptions.push(watcher);
    }

    // Sync Code Explorer with active editor
    context.subscriptions.push(
        vscode.window.onDidChangeActiveTextEditor(editor => {
            if (editor && editor.document.uri.scheme === 'file') {
                const fileName = path.basename(editor.document.uri.fsPath);
                // Send a search command to highlight/find the file in the graph panel
                graphViewProvider.panelWebview?.postMessage({
                    type: 'search',
                    query: fileName
                });
            }
        })
    );

    console.log('Log Thread extension activated');
}

async function analyzeWorkspace(graphView?: GraphViewProvider): Promise<void> {
    const workspaceFolders = vscode.workspace.workspaceFolders;
    if (!workspaceFolders || workspaceFolders.length === 0) {
        vscode.window.showWarningMessage('No workspace folder open');
        return;
    }

    graphView?.sendStatusUpdate('analyzing', 'Analyzing workspace...');

    await vscode.window.withProgress(
        {
            location: vscode.ProgressLocation.Notification,
            title: 'Log Thread: Analyzing workspace...',
            cancellable: true
        },
        async (progress, token) => {
            try {
                for (const folder of workspaceFolders) {
                    if (token.isCancellationRequested) break;

                    progress.report({ message: `Indexing ${folder.name}...` });
                    graphView?.sendStatusUpdate('analyzing', `Indexing ${folder.name}...`);
                    
                    await logthreadService.analyzeWorkspace(folder.uri.fsPath);
                }

                graphView?.sendStatusUpdate('ready', 'Analysis complete');
                await graphView?.loadDefaultGraph();
                vscode.window.showInformationMessage('Log Thread: Workspace analysis complete');
            } catch (error: any) {
                const errorMsg = error?.message || 'Unknown error';
                const isAuthError = /not logged in|login|subscription|authenticate/i.test(errorMsg);
                if (isAuthError) {
                    graphView?.sendStatusUpdate('error', 'Login required');
                    vscode.window.showWarningMessage(
                        'Log Thread: Please log in to index your workspace.',
                        'Login'
                    ).then(sel => {
                        if (sel === 'Login') {
                            vscode.commands.executeCommand('logthread.login');
                        }
                    });
                } else if (errorMsg.includes('lock')) {
                    graphView?.sendStatusUpdate('error', 'Database locked - close other processes');
                    vscode.window.showErrorMessage(
                        'Log Thread: Database is locked. Close other logthread processes and try again.'
                    );
                } else {
                    graphView?.sendStatusUpdate('error', 'Analysis failed');
                    vscode.window.showErrorMessage(`Log Thread: Analysis failed - ${errorMsg}`);
                }
            }
        }
    );
}

function showImpactDetails(impact: any): void {
    const panel = vscode.window.createWebviewPanel(
        'logthreadImpact',
        'Impact Analysis',
        vscode.ViewColumn.Two,
        { enableScripts: true }
    );

    panel.webview.html = generateImpactHtml(impact);
}

function generateImpactHtml(impact: any): string {
    const directCallers = impact.direct?.map((s: string) => `<li class="direct">${s}</li>`).join('') || '';
    const indirectCallers = impact.indirect?.map((s: string) => `<li class="indirect">${s}</li>`).join('') || '';
    const transitive = impact.transitive?.map((s: string) => `<li class="transitive">${s}</li>`).join('') || '';

    return `<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: var(--vscode-font-family); padding: 20px; }
        h2 { color: var(--vscode-foreground); }
        ul { list-style: none; padding: 0; }
        li { padding: 8px 12px; margin: 4px 0; border-radius: 4px; }
        .direct { background: rgba(239, 68, 68, 0.2); border-left: 3px solid #ef4444; }
        .indirect { background: rgba(245, 158, 11, 0.2); border-left: 3px solid #f59e0b; }
        .transitive { background: rgba(59, 130, 246, 0.2); border-left: 3px solid #3b82f6; }
        .section { margin-bottom: 24px; }
        .count { color: var(--vscode-descriptionForeground); font-size: 12px; }
    </style>
</head>
<body>
    <h1>Impact Analysis: ${impact.symbol}</h1>
    <p class="count">Total affected: ${impact.affectedCount} symbols</p>
    
    <div class="section">
        <h2>🔴 Direct Callers (will break)</h2>
        <ul>${directCallers || '<li>None</li>'}</ul>
    </div>
    
    <div class="section">
        <h2>🟡 Indirect Callers (may break)</h2>
        <ul>${indirectCallers || '<li>None</li>'}</ul>
    </div>
    
    <div class="section">
        <h2>🔵 Transitive (review)</h2>
        <ul>${transitive || '<li>None</li>'}</ul>
    </div>
</body>
</html>`;
}

export function deactivate() {
    if (logthreadService) {
        logthreadService.dispose();
    }
}
