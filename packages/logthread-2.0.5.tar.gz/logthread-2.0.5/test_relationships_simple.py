#!/usr/bin/env python3
"""
Simple test to verify LogThread is extracting relationships properly
by directly querying the database without MCP dependencies.
"""

import json
import os
import sys

# Try to find .logthread directory
possible_paths = [
    os.path.join('.', '.logthread', 'meta.json'),
    os.path.join('..', '.logthread', 'meta.json'),
    os.path.join(os.path.dirname(__file__), '.logthread', 'meta.json'),
]

meta_path = None
for path in possible_paths:
    if os.path.exists(path):
        meta_path = path
        break

if not meta_path:
    print("❌ No .logthread/meta.json found")
    print("   Searched in:")
    for path in possible_paths:
        print(f"     - {os.path.abspath(path)}")
    print("\n   Run 'logthread analyze' first")
    sys.exit(1)

print(f"📂 Found database at: {os.path.abspath(meta_path)}\n")

with open(meta_path, 'r') as f:
    meta = json.load(f)

print("="*70)
print("LOGTHREAD DATABASE STATISTICS")
print("="*70)

stats = meta.get('stats', {})

print(f"\n📊 Overall Statistics:")
print(f"   Files:          {stats.get('files', 0):,}")
print(f"   Symbols:        {stats.get('symbols', 0):,}")
print(f"   Relationships:  {stats.get('relationships', 0):,}")
print(f"   API Endpoints:  {stats.get('api_endpoints', 0):,}")
print(f"   DB Tables:      {stats.get('db_tables', 0):,}")
print(f"   Clusters:       {stats.get('clusters', 0):,}")
print(f"   Flows:          {stats.get('flows', 0):,}")
print(f"   Dead Code:      {stats.get('dead_code', 0):,}")

# Calculate relationship density
symbols = stats.get('symbols', 0)
relationships = stats.get('relationships', 0)

if symbols > 0:
    avg_rels = relationships / symbols
    print(f"\n📈 Relationship Density:")
    print(f"   Average relationships per symbol: {avg_rels:.2f}")
    
    if avg_rels < 1:
        print(f"   ⚠️  LOW - Most symbols are isolated")
        status = "INCOMPLETE"
    elif avg_rels < 3:
        print(f"   ⚠️  MODERATE - Some relationships missing")
        status = "PARTIAL"
    elif avg_rels < 5:
        print(f"   ✓ GOOD - Decent relationship coverage")
        status = "GOOD"
    else:
        print(f"   ✅ EXCELLENT - Comprehensive relationship coverage")
        status = "EXCELLENT"
else:
    print(f"\n❌ No symbols found in database")
    status = "EMPTY"

print(f"\n🗂️  Languages:")
languages = meta.get('languages', {})
for lang, count in sorted(languages.items(), key=lambda x: x[1], reverse=True):
    print(f"   {lang:15s}: {count:4d} files")

print(f"\n🌐 API Frameworks:")
frameworks = meta.get('api_frameworks', {})
if frameworks:
    for fw, count in sorted(frameworks.items(), key=lambda x: x[1], reverse=True):
        print(f"   {fw:15s}: {count:4d} endpoints")
else:
    print(f"   None detected")

print(f"\n⏰ Last Indexed:")
last_indexed = meta.get('last_indexed_at', 'Unknown')
print(f"   {last_indexed}")

print("\n" + "="*70)
print("RELATIONSHIP QUALITY ASSESSMENT")
print("="*70)

# Assess relationship quality
quality_checks = []

# Check 1: Relationship density
if avg_rels >= 3:
    quality_checks.append(("✅", "Good relationship density (avg >= 3)"))
else:
    quality_checks.append(("⚠️ ", f"Low relationship density (avg = {avg_rels:.2f})"))

# Check 2: API endpoints
if stats.get('api_endpoints', 0) > 0:
    quality_checks.append(("✅", f"API endpoints detected ({stats.get('api_endpoints', 0)})"))
else:
    quality_checks.append(("ℹ️ ", "No API endpoints detected"))

# Check 3: Database tables
if stats.get('db_tables', 0) > 0:
    quality_checks.append(("✅", f"Database tables detected ({stats.get('db_tables', 0)})"))
else:
    quality_checks.append(("ℹ️ ", "No database tables detected"))

# Check 4: Clusters (communities)
if stats.get('clusters', 0) > 5:
    quality_checks.append(("✅", f"Good code organization ({stats.get('clusters', 0)} clusters)"))
else:
    quality_checks.append(("ℹ️ ", f"Limited clustering ({stats.get('clusters', 0)} clusters)"))

# Check 5: Flows (execution paths)
if stats.get('flows', 0) > 10:
    quality_checks.append(("✅", f"Multiple execution flows detected ({stats.get('flows', 0)})"))
else:
    quality_checks.append(("ℹ️ ", f"Few execution flows ({stats.get('flows', 0)})"))

print()
for icon, message in quality_checks:
    print(f"{icon} {message}")

print("\n" + "="*70)
print("END-TO-END PICTURE ASSESSMENT")
print("="*70)

# Overall assessment
if status == "EXCELLENT":
    print("\n✅ EXCELLENT: CLI is extracting comprehensive relationships")
    print("   • High relationship density indicates complete graph")
    print("   • Multiple entry points and flows detected")
    print("   • Database contains end-to-end execution paths")
    print("\n   ✓ Ready for comprehensive graph visualization")
    print("   ✓ AI will have complete context for code generation")
    print("   ✓ Impact analysis will show full blast radius")
    
elif status == "GOOD":
    print("\n✓ GOOD: CLI is extracting solid relationships")
    print("   • Decent relationship coverage")
    print("   • Most symbols are connected")
    print("   • Some execution paths may be incomplete")
    print("\n   ✓ Suitable for graph visualization")
    print("   ⚠️  Some context may be missing for AI")
    
elif status == "PARTIAL":
    print("\n⚠️  PARTIAL: Relationships are incomplete")
    print("   • Low relationship density")
    print("   • Many isolated symbols")
    print("   • Execution paths may be fragmented")
    print("\n   Recommendations:")
    print("   1. Check if all source files were analyzed")
    print("   2. Verify language parsers are working")
    print("   3. Consider re-running: logthread clean && logthread analyze")
    
elif status == "INCOMPLETE":
    print("\n❌ INCOMPLETE: Relationships are severely lacking")
    print("   • Very low relationship density")
    print("   • Most symbols are isolated")
    print("   • No meaningful execution paths")
    print("\n   Action required:")
    print("   1. Re-run analysis: logthread clean && logthread analyze")
    print("   2. Check for errors in analysis output")
    print("   3. Verify supported languages are being parsed")
    
else:
    print("\n❌ EMPTY: No data in database")
    print("   Run: logthread analyze")

print("\n" + "="*70)

# Test specific relationship queries via file inspection
print("\nTesting relationship extraction capabilities...")
print("(This would require MCP server or direct DB access)")
print("\nTo test relationships in detail, use:")
print("  1. logthread context <symbol_name>")
print("  2. logthread impact <symbol_name>")
print("  3. logthread cypher 'MATCH (n)-[r]->(m) RETURN n,r,m LIMIT 10'")

print("\n" + "="*70)
