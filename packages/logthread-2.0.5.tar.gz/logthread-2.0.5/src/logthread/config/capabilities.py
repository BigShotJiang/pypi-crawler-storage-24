"""Language and framework support metadata for Log Thread.

This centralizes what the product natively supports today and which
commercially-usable external engines are the best fit for deeper semantic
analysis. Keeping this in code lets the CLI, UI, and docs stay aligned.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class LanguageCapability:
    language: str
    status: str
    native_parser: bool
    api_discovery: str
    type_flow: str
    db_mapping: str
    ui_frameworks: tuple[str, ...] = ()
    tier: str = "T0"
    semantic_engine: str | None = None
    framework_adapters: tuple[str, ...] = ()
    database_providers: tuple[str, ...] = ()


@dataclass(frozen=True)
class DatabaseCapability:
    provider: str
    kind: str
    tier: str
    lineage: str
    discovery: str
    adapters: tuple[str, ...] = ()


@dataclass(frozen=True)
class ExternalEngine:
    name: str
    role: str
    license: str
    url: str
    recommended_for: tuple[str, ...]


NATIVE_LANGUAGE_CAPABILITIES: tuple[LanguageCapability, ...] = (
    LanguageCapability(
        language="python",
        status="native",
        native_parser=True,
        api_discovery="FastAPI/Flask decorator routes (partial)",
        type_flow="basic annotations",
        db_mapping="SQLAlchemy-ish models + SQL strings (partial)",
        ui_frameworks=(),
        tier="T2",
        semantic_engine="Pyright",
        framework_adapters=("fastapi", "flask", "django"),
        database_providers=("postgres", "mysql", "sqlserver", "sqlite", "mongodb", "dynamodb"),
    ),
    LanguageCapability(
        language="typescript",
        status="native",
        native_parser=True,
        api_discovery="Express/Fastify-style routes (partial)",
        type_flow="basic function/type refs",
        db_mapping="SQL strings + dependency graph (partial)",
        ui_frameworks=("react", "next.js", "angular", "vue", "svelte"),
        tier="T2",
        semantic_engine="tsserver",
        framework_adapters=("express", "fastify", "nestjs", "next.js", "angular"),
        database_providers=("postgres", "mysql", "sqlserver", "mongodb", "dynamodb"),
    ),
    LanguageCapability(
        language="tsx",
        status="native",
        native_parser=True,
        api_discovery="Express/Fastify-style routes in mixed TSX repos (partial)",
        type_flow="basic function/type refs",
        db_mapping="indirect only",
        ui_frameworks=("react", "next.js"),
        tier="T2",
        semantic_engine="tsserver",
        framework_adapters=("react", "next.js"),
        database_providers=("postgres", "mysql", "sqlserver", "mongodb"),
    ),
    LanguageCapability(
        language="javascript",
        status="native",
        native_parser=True,
        api_discovery="Express/Fastify-style routes (partial)",
        type_flow="limited inference",
        db_mapping="SQL strings + dependency graph (partial)",
        ui_frameworks=("react", "next.js", "vue", "svelte"),
        tier="T2",
        semantic_engine="tsserver",
        framework_adapters=("express", "fastify", "nestjs", "react"),
        database_providers=("postgres", "mysql", "sqlserver", "mongodb", "dynamodb"),
    ),
    LanguageCapability(
        language="go",
        status="native",
        native_parser=True,
        api_discovery="not yet framework-aware",
        type_flow="basic symbols/imports/calls",
        db_mapping="SQL strings only",
        tier="T1",
        semantic_engine="gopls",
        framework_adapters=("gin", "echo", "fiber"),
        database_providers=("postgres", "mysql", "sqlserver"),
    ),
    LanguageCapability(
        language="java",
        status="native",
        native_parser=True,
        api_discovery="not yet Spring/JAX-RS aware",
        type_flow="basic symbols/imports/calls",
        db_mapping="SQL strings only",
        tier="T1",
        framework_adapters=("spring",),
        database_providers=("postgres", "mysql", "sqlserver"),
    ),
    LanguageCapability(
        language="csharp",
        status="native",
        native_parser=True,
        api_discovery="not yet ASP.NET aware",
        type_flow="basic symbols/imports/calls",
        db_mapping="SQL strings only",
        tier="T2",
        semantic_engine="Roslyn",
        framework_adapters=("asp.net",),
        database_providers=("sqlserver", "postgres", "mysql", "dynamodb"),
    ),
    LanguageCapability(
        language="ruby",
        status="native",
        native_parser=True,
        api_discovery="not yet Rails aware",
        type_flow="basic symbols/imports/calls",
        db_mapping="SQL strings only",
        tier="T1",
        framework_adapters=("rails",),
        database_providers=("postgres", "mysql"),
    ),
    LanguageCapability(
        language="sql",
        status="native",
        native_parser=True,
        api_discovery="n/a",
        type_flow="schema only",
        db_mapping="DDL tables/columns",
        tier="T2",
        semantic_engine="SQLGlot",
        database_providers=("postgres", "mysql", "sqlserver", "sqlite"),
    ),
    LanguageCapability(
        language="rust",
        status="experimental",
        native_parser=False,
        api_discovery="syntax only today; semantic/framework support planned (Axum/Actix/Rocket)",
        type_flow="semantic engine planned",
        db_mapping="planned",
        tier="T0",
        semantic_engine="rust-analyzer",
        framework_adapters=("axum", "actix", "rocket"),
    ),
    LanguageCapability(
        language="php",
        status="experimental",
        native_parser=False,
        api_discovery="syntax only today; framework support planned (Laravel/Symfony)",
        type_flow="semantic engine planned",
        db_mapping="planned",
        tier="T0",
        framework_adapters=("laravel", "symfony"),
    ),
    LanguageCapability(
        language="kotlin",
        status="experimental",
        native_parser=False,
        api_discovery="syntax only today; framework support planned (Spring/Ktor)",
        type_flow="semantic engine planned",
        db_mapping="planned",
        tier="T0",
        framework_adapters=("spring", "ktor"),
    ),
    LanguageCapability(
        language="swift",
        status="experimental",
        native_parser=False,
        api_discovery="syntax only today; framework support planned (Vapor)",
        type_flow="semantic engine planned",
        db_mapping="planned",
        tier="T0",
        framework_adapters=("vapor",),
    ),
    LanguageCapability(
        language="cpp",
        status="experimental",
        native_parser=False,
        api_discovery="syntax only today",
        type_flow="semantic engine planned",
        db_mapping="planned",
        tier="T0",
    ),
)


EXTERNAL_ENGINES: tuple[ExternalEngine, ...] = (
    ExternalEngine(
        name="tree-sitter / tree-sitter-language-pack",
        role="syntax parsing across many languages without per-language glue code",
        license="MIT / permissive bundled grammars",
        url="https://github.com/kreuzberg-dev/tree-sitter-language-pack",
        recommended_for=("rust", "php", "kotlin", "swift", "cpp", "scala", "elixir"),
    ),
    ExternalEngine(
        name="tsserver",
        role="JS/TS semantic definitions, references, framework-aware navigation",
        license="Apache-2.0",
        url="https://github.com/microsoft/TypeScript/wiki/Standalone-Server-%28tsserver%29",
        recommended_for=("javascript", "typescript", "tsx", "react", "angular", "next.js"),
    ),
    ExternalEngine(
        name="Pyright",
        role="Python type analysis, symbol resolution, and richer cross-file navigation",
        license="MIT",
        url="https://github.com/microsoft/pyright",
        recommended_for=("python", "fastapi", "flask", "django"),
    ),
    ExternalEngine(
        name="gopls",
        role="Go semantic navigation and package-aware symbol resolution",
        license="BSD-3-Clause",
        url="https://github.com/golang/tools/tree/master/gopls",
        recommended_for=("go", "gin", "echo", "fiber"),
    ),
    ExternalEngine(
        name="Roslyn",
        role="C# / .NET semantic model, ASP.NET route/source generation awareness",
        license="MIT",
        url="https://github.com/dotnet/roslyn",
        recommended_for=("csharp", "asp.net"),
    ),
    ExternalEngine(
        name="rust-analyzer",
        role="Rust semantic navigation and type-driven symbol resolution",
        license="MIT OR Apache-2.0",
        url="https://github.com/rust-lang/rust-analyzer",
        recommended_for=("rust", "axum", "actix", "rocket"),
    ),
    ExternalEngine(
        name="SQLGlot",
        role="dialect-aware SQL parsing for table/column lineage and type checks",
        license="MIT",
        url="https://github.com/tobymao/sqlglot",
        recommended_for=("postgres", "mysql", "sqlite", "snowflake"),
    ),
)

DATABASE_CAPABILITIES: tuple[DatabaseCapability, ...] = (
    DatabaseCapability(
        provider="postgres",
        kind="sql",
        tier="T2",
        lineage="DDL, SQLGlot parsing, ORM and query linkage",
        discovery="Tables, columns, joins, SQL validation",
        adapters=("sqlalchemy", "prisma", "typeorm", "sequelize", "knex"),
    ),
    DatabaseCapability(
        provider="mysql",
        kind="sql",
        tier="T2",
        lineage="DDL, SQLGlot parsing, ORM and query linkage",
        discovery="Tables, columns, joins, SQL validation",
        adapters=("sequelize", "typeorm", "knex"),
    ),
    DatabaseCapability(
        provider="sqlserver",
        kind="sql",
        tier="T2",
        lineage="DDL, SQLGlot parsing, ORM and query linkage",
        discovery="Tables, columns, stored-procedure-aware mapping planned",
        adapters=("ef core", "dapper"),
    ),
    DatabaseCapability(
        provider="mongodb",
        kind="nosql",
        tier="T1",
        lineage="Collection and model inference from code and SDK usage",
        discovery="Model names, collection names, repository/data-layer links",
        adapters=("mongoose",),
    ),
    DatabaseCapability(
        provider="dynamodb",
        kind="nosql",
        tier="T1",
        lineage="Table and item access inference from SDK usage and model names",
        discovery="Table names, key usage, service/data-layer links",
        adapters=("aws-sdk", "boto3"),
    ),
)

_LANGUAGE_ALIASES = {
    "js": "javascript",
    "jsx": "javascript",
    "ts": "typescript",
    "py": "python",
    "c#": "csharp",
    "cs": "csharp",
    "mssql": "sqlserver",
    "postgresql": "postgres",
}

_TIER_ORDER = {"T0": 0, "T1": 1, "T2": 2, "T3": 3}


def native_capabilities() -> tuple[LanguageCapability, ...]:
    return NATIVE_LANGUAGE_CAPABILITIES


def external_engines() -> tuple[ExternalEngine, ...]:
    return EXTERNAL_ENGINES


def database_capabilities() -> tuple[DatabaseCapability, ...]:
    return DATABASE_CAPABILITIES


def normalize_language_key(language: str) -> str:
    key = (language or "").strip().lower()
    return _LANGUAGE_ALIASES.get(key, key)


def get_language_capability(language: str) -> LanguageCapability | None:
    key = normalize_language_key(language)
    for item in NATIVE_LANGUAGE_CAPABILITIES:
        if item.language == key:
            return item
    return None


def tier_rank(tier: str) -> int:
    return _TIER_ORDER.get((tier or "T0").upper(), 0)


def build_capability_registry() -> dict[str, object]:
    return {
        "tiers": {
            "T0": "Syntax and discovery coverage only",
            "T1": "Framework and entry-point aware",
            "T2": "Semantic or data-lineage aware",
            "T3": "Runtime-confirmed",
        },
        "languages": [
            {
                "language": item.language,
                "status": item.status,
                "tier": item.tier,
                "nativeParser": item.native_parser,
                "apiDiscovery": item.api_discovery,
                "typeFlow": item.type_flow,
                "dbMapping": item.db_mapping,
                "semanticEngine": item.semantic_engine,
                "uiFrameworks": list(item.ui_frameworks),
                "frameworkAdapters": list(item.framework_adapters),
                "databaseProviders": list(item.database_providers),
            }
            for item in NATIVE_LANGUAGE_CAPABILITIES
        ],
        "databases": [
            {
                "provider": item.provider,
                "kind": item.kind,
                "tier": item.tier,
                "lineage": item.lineage,
                "discovery": item.discovery,
                "adapters": list(item.adapters),
            }
            for item in DATABASE_CAPABILITIES
        ],
        "externalEngines": [
            {
                "name": engine.name,
                "role": engine.role,
                "license": engine.license,
                "url": engine.url,
                "recommendedFor": list(engine.recommended_for),
            }
            for engine in EXTERNAL_ENGINES
        ],
        "coreLanguages": ["python", "typescript", "tsx", "javascript", "csharp", "sql"],
        "coreDatastores": ["postgres", "mysql", "sqlserver", "mongodb", "dynamodb"],
    }


def format_capabilities_report() -> str:
    lines: list[str] = []
    lines.append("Native language support:")
    for item in NATIVE_LANGUAGE_CAPABILITIES:
        flags = [
            f"status={item.status}",
            f"tier={item.tier}",
            f"api={item.api_discovery}",
            f"types={item.type_flow}",
            f"db={item.db_mapping}",
        ]
        if item.semantic_engine:
            flags.append(f"semantic={item.semantic_engine}")
        if item.ui_frameworks:
            flags.append(f"ui={', '.join(item.ui_frameworks)}")
        if item.framework_adapters:
            flags.append(f"frameworks={', '.join(item.framework_adapters)}")
        if item.database_providers:
            flags.append(f"stores={', '.join(item.database_providers)}")
        lines.append(f"  - {item.language}: " + " | ".join(flags))

    lines.append("")
    lines.append("Database and lineage support:")
    for item in DATABASE_CAPABILITIES:
        adapters = f" | adapters={', '.join(item.adapters)}" if item.adapters else ""
        lines.append(
            f"  - {item.provider}: kind={item.kind} | tier={item.tier} | "
            f"lineage={item.lineage} | discovery={item.discovery}{adapters}"
        )

    lines.append("")
    lines.append("Recommended external semantic engines:")
    for engine in EXTERNAL_ENGINES:
        langs = ", ".join(engine.recommended_for)
        lines.append(
            f"  - {engine.name}: {engine.role} | license={engine.license} | "
            f"for={langs} | {engine.url}"
        )

    lines.append("")
    lines.append("Recommended architecture:")
    lines.append("  - Keep Tree-sitter for fast cross-language syntax indexing and graph bootstrapping.")
    lines.append("  - Add optional semantic backends per ecosystem (tsserver, Pyright, gopls, Roslyn, rust-analyzer).")
    lines.append("  - Normalize outputs into one graph schema: symbols, definitions, references, routes, types, tables, columns.")
    lines.append("  - Use SQL parsing plus ORM/model extraction to connect API payloads to DB tables and column types.")
    return "\n".join(lines)
