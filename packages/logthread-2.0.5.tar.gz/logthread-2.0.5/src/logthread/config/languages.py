"""Language detection based on file extensions."""

from __future__ import annotations

from pathlib import Path

SUPPORTED_EXTENSIONS: dict[str, str] = {
    ".py": "python",
    ".ts": "typescript",
    ".tsx": "tsx",
    ".js": "javascript",
    ".jsx": "javascript",
    ".mjs": "javascript",
    ".cjs": "javascript",
    ".go": "go",
    ".java": "java",
    ".cs": "csharp",
    ".rb": "ruby",
    ".sql": "sql",
    ".rs": "rust",
    ".php": "php",
    ".kt": "kotlin",
    ".kts": "kotlin",
    ".swift": "swift",
    ".c": "c",
    ".h": "c",
    ".cpp": "cpp",
    ".cc": "cpp",
    ".cxx": "cpp",
    ".hpp": "cpp",
    ".hh": "cpp",
    ".dart": "dart",
    ".pl": "perl",
    ".pm": "perl",
}

def get_language(file_path: str | Path) -> str | None:
    """Return the language name for *file_path* based on its extension.

    Returns ``None`` when the extension is not in :data:`SUPPORTED_EXTENSIONS`.
    """
    suffix = Path(file_path).suffix
    return SUPPORTED_EXTENSIONS.get(suffix)

def is_supported(file_path: str | Path) -> bool:
    """Return ``True`` if *file_path* has a supported extension."""
    return Path(file_path).suffix in SUPPORTED_EXTENSIONS
