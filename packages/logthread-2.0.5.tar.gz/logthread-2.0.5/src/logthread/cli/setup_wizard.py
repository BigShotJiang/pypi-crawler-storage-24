"""Interactive setup wizard for LogThread."""

from __future__ import annotations

import json
import platform
from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.table import Table

console = Console()


class SetupWizard:
    """Interactive setup wizard for configuring LogThread with AI assistants."""

    # Supported AI assistants with their config paths
    ASSISTANTS = {
        "cursor": {
            "name": "Cursor",
            "config_paths": {
                "darwin": Path.home() / ".cursor" / "mcp.json",
                "linux": Path.home() / ".cursor" / "mcp.json",
                "windows": Path.home() / "AppData" / "Roaming" / "Cursor" / "User" / "mcp.json",
            },
        },
        "windsurf": {
            "name": "Windsurf (Codeium)",
            "config_paths": {
                "darwin": Path.home() / ".codeium" / "windsurf" / "mcp_config.json",
                "linux": Path.home() / ".codeium" / "windsurf" / "mcp_config.json",
                "windows": Path.home() / "AppData" / "Roaming" / "Codeium" / "windsurf" / "mcp_config.json",
            },
        },
        "claude": {
            "name": "Claude Desktop",
            "config_paths": {
                "darwin": Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json",
                "linux": Path.home() / ".config" / "Claude" / "claude_desktop_config.json",
                "windows": Path.home() / "AppData" / "Roaming" / "Claude" / "claude_desktop_config.json",
            },
        },
        "kiro": {
            "name": "Kiro",
            "config_paths": {
                "darwin": Path.home() / ".kiro" / "settings" / "mcp.json",
                "linux": Path.home() / ".kiro" / "settings" / "mcp.json",
                "windows": Path.home() / "AppData" / "Roaming" / "Kiro" / "settings" / "mcp.json",
            },
        },
        "vscode": {
            "name": "VS Code",
            "config_paths": {
                "darwin": Path.home() / "Library" / "Application Support" / "Code" / "User" / "settings.json",
                "linux": Path.home() / ".config" / "Code" / "User" / "settings.json",
                "windows": Path.home() / "AppData" / "Roaming" / "Code" / "User" / "settings.json",
            },
        },
        "cline": {
            "name": "Cline",
            "config_paths": {
                "darwin": Path.home() / ".cline" / "mcp.json",
                "linux": Path.home() / ".cline" / "mcp.json",
                "windows": Path.home() / "AppData" / "Roaming" / "Cline" / "mcp.json",
            },
        },
    }

    def __init__(self):
        self.system = platform.system().lower()
        if self.system == "darwin":
            self.platform_key = "darwin"
        elif self.system == "linux":
            self.platform_key = "linux"
        else:
            self.platform_key = "windows"

    def detect_installed_assistants(self) -> list[str]:
        """Detect which AI assistants are installed on the system."""
        installed = []

        for key, assistant in self.ASSISTANTS.items():
            config_path = assistant["config_paths"].get(self.platform_key)
            if config_path and (config_path.exists() or config_path.parent.exists()):
                installed.append(key)

        return installed

    def run(self, project_path: Optional[Path] = None) -> bool:
        """Run the interactive setup wizard."""
        console.print(Panel.fit(
            "[bold cyan]LogThread Setup Wizard[/bold cyan]\n"
            "Configure LogThread with your AI assistant",
            border_style="cyan"
        ))
        console.print()

        # Detect installed assistants
        installed = self.detect_installed_assistants()

        if not installed:
            console.print("[yellow]⚠ No AI assistants detected on your system.[/yellow]")
            console.print("You can still configure manually later.")
            return False

        # Show detected assistants
        table = Table(title="Detected AI Assistants", show_header=True)
        table.add_column("Assistant", style="cyan")
        table.add_column("Status", style="green")

        for key in installed:
            table.add_row(self.ASSISTANTS[key]["name"], "✓ Detected")

        console.print(table)
        console.print()

        # Ask which assistant to configure
        if len(installed) == 1:
            selected = installed[0]
            console.print(f"[cyan]Configuring {self.ASSISTANTS[selected]['name']}...[/cyan]")
        else:
            console.print("[bold]Which assistant would you like to configure?[/bold]")
            for i, key in enumerate(installed, 1):
                console.print(f"  {i}. {self.ASSISTANTS[key]['name']}")

            choice = Prompt.ask(
                "Enter number",
                choices=[str(i) for i in range(1, len(installed) + 1)],
                default="1"
            )
            selected = installed[int(choice) - 1]

        console.print()

        # Get project path
        if project_path is None:
            project_path = Path(Prompt.ask(
                "[bold]Enter the absolute path to your project[/bold]",
                default=str(Path.cwd())
            ))

        # Configure the selected assistant
        success = self._configure_assistant(selected, project_path)

        if success:
            console.print()
            console.print(Panel.fit(
                f"[bold green]✓ Successfully configured {self.ASSISTANTS[selected]['name']}![/bold green]\n\n"
                f"Restart {self.ASSISTANTS[selected]['name']} to start using LogThread.",
                border_style="green"
            ))
            return True
        else:
            console.print()
            console.print("[bold red]✗ Configuration failed. Please configure manually.[/bold red]")
            return False

    def _configure_assistant(self, assistant_key: str, project_path: Path) -> bool:
        """Configure a specific AI assistant."""
        assistant = self.ASSISTANTS[assistant_key]
        config_path = assistant["config_paths"][self.platform_key]

        # Create config directory if it doesn't exist
        config_path.parent.mkdir(parents=True, exist_ok=True)

        # Load existing config or create new
        if config_path.exists():
            try:
                with open(config_path, 'r') as f:
                    config = json.load(f)
            except json.JSONDecodeError:
                config = {}
        else:
            config = {}

        # Add LogThread MCP server configuration
        if "mcpServers" not in config:
            config["mcpServers"] = {}

        config["mcpServers"]["logthread"] = {
            "command": "logthread",
            "args": ["serve", "--watch", "--path", str(project_path.absolute())],
            "disabled": False,
        }

        # Write config back
        try:
            with open(config_path, 'w') as f:
                json.dump(config, f, indent=2)
            return True
        except Exception as e:
            console.print(f"[red]Error writing config: {e}[/red]")
            return False

    def show_manual_config(self, project_path: Path):
        """Show manual configuration instructions."""
        console.print(Panel.fit(
            "[bold cyan]Manual Configuration[/bold cyan]\n\n"
            "Add this to your AI assistant's MCP configuration:\n\n"
            f'[yellow]{{\n'
            f'  "mcpServers": {{\n'
            f'    "logthread": {{\n'
            f'      "command": "logthread",\n'
            f'      "args": ["serve", "--watch", "--path", "{project_path.absolute()}"],\n'
            f'      "disabled": false\n'
            f'    }}\n'
            f'  }}\n'
            f'}}[/yellow]',
            border_style="cyan"
        ))


def run_setup_wizard(project_path: Optional[Path] = None) -> bool:
    """Run the interactive setup wizard."""
    wizard = SetupWizard()
    return wizard.run(project_path)
