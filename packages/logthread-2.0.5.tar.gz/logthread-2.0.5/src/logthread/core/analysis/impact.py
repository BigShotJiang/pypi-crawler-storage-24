import logging
from collections import deque
from dataclasses import dataclass

from logthread.core.graph.model import GraphNode, NodeLabel
from logthread.core.storage.ladybug_backend import LadybugBackend

logger = logging.getLogger(__name__)


@dataclass
class ImpactReport:
    """Represents the impact radius of a change to a specific node."""
    target_node: GraphNode
    impacted_endpoints: list[GraphNode]
    impacted_tables: list[GraphNode]
    impacted_components: list[GraphNode]

    @property
    def total_impact_size(self) -> int:
        return len(self.impacted_endpoints) + len(self.impacted_tables) + len(self.impacted_components)

    @property
    def risk_score(self) -> int:
        """Calculate a risk score from 1-10.
        
        Score is weighted by:
        - Impacted Endpoints (High weight)
        - Unique components
        - Total depth (more things further away = higher complexity)
        """
        if not self.target_node:
            return 1

        score = 0
        score += len(self.impacted_endpoints) * 3
        score += len(self.impacted_components) * 1

        # Scale to 1-10
        return min(10, max(1, score // 2))


class ImpactAnalyzer:
    """Analyzes the system graph to determine the impact of code changes.
    
    Answers the question: "What breaks or behaves differently if I change X?"
    """

    def __init__(self, backend: LadybugBackend) -> None:
        self.backend = backend

    def analyze_impact(self, node_id: str, max_depth: int = 10) -> ImpactReport:
        """Analyze the impact radius of a node up to a maximum depth.
        
        Traverses inbound dependencies (callers, type references) to find
        all higher-level components, entry points, and database tables
        that depend on this node.
        """
        target = self.backend.get_node(node_id)
        if not target:
            raise ValueError(f"Node not found in graph: {node_id}")

        visited: set[str] = {node_id}
        queue: deque[tuple[GraphNode, int]] = deque([(target, 0)])

        endpoints: dict[str, GraphNode] = {}
        tables: dict[str, GraphNode] = {}
        components: dict[str, GraphNode] = {}

        while queue:
            current_node, depth = queue.popleft()

            # Record impact
            if current_node.id != target.id:
                if current_node.is_entry_point:
                    endpoints[current_node.id] = current_node
                elif current_node.label == NodeLabel.DB_TABLE:
                    tables[current_node.id] = current_node
                else:
                    components[current_node.id] = current_node

            if depth >= max_depth:
                continue

            # Fetch all impacted nodes (comprehensive traversal)
            try:
                impactors = self.backend.get_impacted_nodes(current_node.id)
            except Exception as e:
                logger.warning(f"Failed to get impacted nodes for {current_node.id}: {e}")
                impactors = []

            for dep in impactors:
                if dep.id not in visited:
                    visited.add(dep.id)
                    queue.append((dep, depth + 1))

        return ImpactReport(
            target_node=target,
            impacted_endpoints=list(endpoints.values()),
            impacted_tables=list(tables.values()),
            impacted_components=list(components.values()),
        )
