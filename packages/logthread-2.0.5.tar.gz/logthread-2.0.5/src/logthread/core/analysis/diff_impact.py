from dataclasses import dataclass, field

from logthread.core.analysis.impact import ImpactAnalyzer, ImpactReport
from logthread.core.diff import StructuralDiff


@dataclass
class DiffImpactReport:
    """Aggregated impact of all changes in a structural diff."""
    diff: StructuralDiff
    node_impacts: dict[str, ImpactReport] = field(default_factory=dict)

    # Aggregated unique nodes affected
    impacted_endpoints: set[str] = field(default_factory=set)
    impacted_tables: set[str] = field(default_factory=set)
    impacted_components: set[str] = field(default_factory=set)

    def add_node_impact(self, node_id: str, report: ImpactReport) -> None:
        self.node_impacts[node_id] = report
        for ep in report.impacted_endpoints:
            self.impacted_endpoints.add(ep.name)
        for tbl in report.impacted_tables:
            self.impacted_tables.add(tbl.name)
        for comp in report.impacted_components:
            self.impacted_components.add(comp.name)


def generate_diff_impact(diff: StructuralDiff, analyzer: ImpactAnalyzer) -> DiffImpactReport:
    """Generate a comprehensive impact report for a structural diff.
    
    Uses the ImpactAnalyzer to find downstream impacts of modified and removed nodes.
    Added nodes don't typically have existing dependents so they are just tracked for the diff.
    """
    report = DiffImpactReport(diff=diff)

    # We evaluate impact based on nodes that changed.
    nodes_to_analyze: list[str] = []

    for base_node, current_node in diff.modified_nodes:
        nodes_to_analyze.append(current_node.id)

    for removed_node in diff.removed_nodes:
        nodes_to_analyze.append(removed_node.id)

    for added_node in diff.added_nodes:
        # Added nodes might be used by existing nodes if the user added them and updated
        # other files. We check their impact too.
        nodes_to_analyze.append(added_node.id)

    for node_id in nodes_to_analyze:
        try:
            impact = analyzer.analyze_impact(node_id)
            report.add_node_impact(node_id, impact)
        except ValueError:
            # Node might not exist in the active backend if it was removed in the diff
            # but hasn't synced, or is part of a temporary diff branch.
            # We skip gracefully.
            pass

    return report
