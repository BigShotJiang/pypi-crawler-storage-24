"""Run optional semantic analyzers and normalize their output."""

from __future__ import annotations

import json
import os
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class SemanticFinding:
    engine: str
    severity: str
    file_path: str
    line: int
    column: int
    code: str
    message: str


@dataclass
class SemanticEngineStatus:
    available: bool
    command: str = ""
    detail: str = ""


@dataclass
class SemanticReport:
    engines: dict[str, SemanticEngineStatus] = field(default_factory=dict)
    findings: list[SemanticFinding] = field(default_factory=list)

    def summary(self) -> dict[str, Any]:
        severity_counts: dict[str, int] = {}
        engine_counts: dict[str, int] = {}
        for finding in self.findings:
            severity_counts[finding.severity] = severity_counts.get(finding.severity, 0) + 1
            engine_counts[finding.engine] = engine_counts.get(finding.engine, 0) + 1
        return {
            "engines": {
                name: {
                    "available": status.available,
                    "command": status.command,
                    "detail": status.detail,
                }
                for name, status in self.engines.items()
            },
            "findings": len(self.findings),
            "by_severity": severity_counts,
            "by_engine": engine_counts,
        }


def run_semantic_analysis(repo_path: Path, language_counts: dict[str, int]) -> SemanticReport:
    report = SemanticReport()

    ts_backend = TsserverBackend(repo_path)
    py_backend = PyrightBackend(repo_path)
    roslyn_backend = RoslynBackend(repo_path)

    for backend in (ts_backend, py_backend, roslyn_backend):
        status = backend.discover()
        report.engines[backend.name] = status
        if status.available:
            report.findings.extend(backend.analyze(language_counts))

    return report


class TsserverBackend:
    name = "tsserver"

    def __init__(self, repo_path: Path) -> None:
        self.repo_path = repo_path

    def discover(self) -> SemanticEngineStatus:
        env_override = os.environ.get("TSSERVER_PATH")
        if env_override and Path(env_override).exists():
            return SemanticEngineStatus(True, command=env_override, detail="env:TSSERVER_PATH")

        for candidate in self.repo_path.glob("**/node_modules/typescript/lib/tsserver.js"):
            return SemanticEngineStatus(True, command=str(candidate.resolve()), detail="local typescript")

        return SemanticEngineStatus(False, detail="typescript/tsserver not found")

    def analyze(self, language_counts: dict[str, int]) -> list[SemanticFinding]:
        if not any(language_counts.get(lang, 0) for lang in ("javascript", "typescript", "tsx")):
            return []

        status = self.discover()
        if not status.available or not status.command:
            return []

        typescript_js = str(Path(status.command).with_name("typescript.js"))
        script = r"""
const fs = require('fs');
const path = require('path');
const ts = require(process.argv[2]);
const repoRoot = process.argv[3];

function collectFiles(dir, acc) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === 'node_modules' || entry.name === '.git' || entry.name === '.logthread' || entry.name === 'dist' || entry.name === 'build' || entry.name === 'out' || entry.name === '.next') continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      collectFiles(full, acc);
      continue;
    }
    if (/\.(ts|tsx|js|jsx|mjs|cjs)$/.test(entry.name)) acc.push(full);
  }
}

let rootNames = [];
let options = { allowJs: true, checkJs: true, noEmit: true, skipLibCheck: true, jsx: ts.JsxEmit.Preserve };
const configPath = ts.findConfigFile(repoRoot, ts.sys.fileExists, 'tsconfig.json');
if (configPath) {
  const configFile = ts.readConfigFile(configPath, ts.sys.readFile);
  const parsed = ts.parseJsonConfigFileContent(configFile.config, ts.sys, path.dirname(configPath));
  rootNames = parsed.fileNames;
  options = { ...options, ...parsed.options };
} else {
  collectFiles(repoRoot, rootNames);
}
const program = ts.createProgram(rootNames, options);
const diagnostics = ts.getPreEmitDiagnostics(program);
const out = diagnostics.map((diag) => {
  const file = diag.file ? path.relative(repoRoot, diag.file.fileName) : '';
  const pos = diag.file && typeof diag.start === 'number' ? diag.file.getLineAndCharacterOfPosition(diag.start) : { line: 0, character: 0 };
  return {
    file,
    line: pos.line + 1,
    column: pos.character + 1,
    severity: ts.DiagnosticCategory[diag.category].toLowerCase(),
    code: String(diag.code || ''),
    message: ts.flattenDiagnosticMessageText(diag.messageText, '\n'),
  };
});
console.log(JSON.stringify(out));
"""
        try:
            proc = subprocess.run(
                ["node", "-e", script, typescript_js, str(self.repo_path)],
                capture_output=True,
                text=True,
                timeout=30,
                cwd=self.repo_path,
            )
            if proc.returncode != 0 and not proc.stdout.strip():
                return []
            payload = json.loads(proc.stdout or "[]")
        except Exception:
            return []

        findings: list[SemanticFinding] = []
        for item in payload:
            file_path = str(item.get("file", "")).strip()
            if not file_path:
                continue
            findings.append(
                SemanticFinding(
                    engine=self.name,
                    severity=str(item.get("severity", "warning")),
                    file_path=file_path,
                    line=int(item.get("line", 0) or 0),
                    column=int(item.get("column", 0) or 0),
                    code=str(item.get("code", "")),
                    message=str(item.get("message", "")).strip(),
                )
            )
        return findings


class PyrightBackend:
    name = "pyright"

    def __init__(self, repo_path: Path) -> None:
        self.repo_path = repo_path

    def discover(self) -> SemanticEngineStatus:
        for cmd in ("pyright",):
            path = shutil_which(cmd)
            if path:
                return SemanticEngineStatus(True, command=path, detail="pyright cli")
        return SemanticEngineStatus(False, detail="pyright not found")

    def analyze(self, language_counts: dict[str, int]) -> list[SemanticFinding]:
        if not language_counts.get("python"):
            return []
        status = self.discover()
        if not status.available or not status.command:
            return []
        try:
            proc = subprocess.run(
                [status.command, "--outputjson"],
                capture_output=True,
                text=True,
                timeout=45,
                cwd=self.repo_path,
            )
            payload = json.loads(proc.stdout or "{}")
        except Exception:
            return []

        findings: list[SemanticFinding] = []
        for item in payload.get("generalDiagnostics", []) or []:
            file_path = item.get("file", "")
            if file_path:
                try:
                    file_path = str(Path(file_path).resolve().relative_to(self.repo_path.resolve()))
                except Exception:
                    file_path = str(file_path)
            rng = item.get("range", {}) or {}
            start = rng.get("start", {}) or {}
            findings.append(
                SemanticFinding(
                    engine=self.name,
                    severity=str(item.get("severity", "warning")).lower(),
                    file_path=file_path,
                    line=int(start.get("line", 0)) + 1,
                    column=int(start.get("character", 0)) + 1,
                    code=str(item.get("rule", item.get("code", ""))),
                    message=str(item.get("message", "")).strip(),
                )
            )
        return findings


class RoslynBackend:
    name = "roslyn"

    def __init__(self, repo_path: Path) -> None:
        self.repo_path = repo_path

    def discover(self) -> SemanticEngineStatus:
        dotnet = shutil_which("dotnet")
        if not dotnet:
            return SemanticEngineStatus(False, detail="dotnet not found")
        if any(self.repo_path.glob("*.sln")) or any(self.repo_path.glob("**/*.csproj")):
            return SemanticEngineStatus(True, command=dotnet, detail="dotnet build / Roslyn")
        return SemanticEngineStatus(False, detail="no .sln or .csproj found")

    def analyze(self, language_counts: dict[str, int]) -> list[SemanticFinding]:
        if not language_counts.get("csharp"):
            return []
        status = self.discover()
        if not status.available or not status.command:
            return []
        try:
            proc = subprocess.run(
                [status.command, "build", "--nologo", "-v:q"],
                capture_output=True,
                text=True,
                timeout=60,
                cwd=self.repo_path,
            )
        except Exception:
            return []
        findings: list[SemanticFinding] = []
        pattern = re.compile(
            r"^(?P<file>.+?)\((?P<line>\d+),(?P<col>\d+)\):\s+"
            r"(?P<severity>error|warning)\s+(?P<code>[A-Z]{2}\d+):\s+(?P<message>.+)$"
        )
        for raw_line in (proc.stdout + "\n" + proc.stderr).splitlines():
            match = pattern.match(raw_line.strip())
            if not match:
                continue
            file_path = match.group("file")
            try:
                file_path = str(Path(file_path).resolve().relative_to(self.repo_path.resolve()))
            except Exception:
                pass
            findings.append(
                SemanticFinding(
                    engine=self.name,
                    severity=match.group("severity"),
                    file_path=file_path,
                    line=int(match.group("line")),
                    column=int(match.group("col")),
                    code=match.group("code"),
                    message=match.group("message").strip(),
                )
            )
        return findings


def shutil_which(name: str) -> str | None:
    from shutil import which

    return which(name)
