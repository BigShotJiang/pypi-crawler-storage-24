"""Semantic analysis integrations for external language engines."""

from .runner import run_semantic_analysis

__all__ = ["run_semantic_analysis"]
