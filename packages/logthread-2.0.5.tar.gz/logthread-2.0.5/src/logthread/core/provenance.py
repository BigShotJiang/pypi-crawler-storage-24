"""Shared provenance and confidence helpers for graph entities."""

from __future__ import annotations

import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from logthread.config.capabilities import get_language_capability, tier_rank
from logthread.core.graph.graph import KnowledgeGraph
from logthread.core.graph.model import GraphNode, GraphRelationship, NodeLabel

DEFAULT_SOURCE_SYSTEM = "logthread.indexer"
DEFAULT_SOURCE_ID = "logthread.pipeline"
_TIER_SCORE = {
    "T0": 0.35,
    "T1": 0.58,
    "T2": 0.82,
    "T3": 0.96,
}


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def detect_commit_sha(repo_path: Path) -> str | None:
    try:
        completed = subprocess.run(
            ["git", "-C", str(repo_path), "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            timeout=2,
            check=False,
        )
    except OSError:
        return None
    if completed.returncode != 0:
        return None
    commit = completed.stdout.strip()
    return commit or None


def _normalize_tier(tier: str | None) -> str:
    value = (tier or "T0").upper()
    return value if value in _TIER_SCORE else "T0"


def max_tier(*tiers: str | None) -> str:
    return max((_normalize_tier(item) for item in tiers), key=tier_rank)


def min_tier(*tiers: str | None) -> str:
    return min((_normalize_tier(item) for item in tiers), key=tier_rank)


def tier_confidence_score(tier: str | None) -> float:
    return _TIER_SCORE[_normalize_tier(tier)]


def infer_node_capability_tier(node: GraphNode) -> str:
    props = node.properties or {}
    if props.get("runtime_confirmed"):
        return "T3"
    if node.label in {NodeLabel.DB_TABLE, NodeLabel.DB_COLUMN}:
        provider = str(props.get("provider") or props.get("database_provider") or "").lower()
        if provider in {"postgres", "mysql", "sqlserver", "mssql", "sqlite"}:
            return "T2"
        if provider in {"mongodb", "dynamodb"}:
            return "T1"
        return "T2" if node.language.lower() == "sql" else "T1"
    if node.label in {NodeLabel.COMMUNITY, NodeLabel.PROCESS}:
        return "T1"

    capability = get_language_capability(node.language)
    tier = capability.tier if capability else "T0"

    if node.label == NodeLabel.API_ENDPOINT and props.get("framework"):
        return max_tier(tier, "T1")
    if node.label in {NodeLabel.FILE, NodeLabel.FOLDER}:
        return max_tier(tier, "T0")
    return tier


def infer_node_confidence_score(node: GraphNode) -> float:
    props = node.properties or {}
    if "confidence_score" in props:
        try:
            return float(props["confidence_score"])
        except (TypeError, ValueError):
            pass
    return tier_confidence_score(props.get("capability_tier") or infer_node_capability_tier(node))


def ensure_node_provenance(node: GraphNode, *, repo_path: Path, observed_at: str, commit_sha: str | None) -> None:
    props = node.properties or {}
    node.properties = props
    props.setdefault("source_system", DEFAULT_SOURCE_SYSTEM)
    props.setdefault("source_id", node.id)
    props.setdefault("observed_at", observed_at)
    props.setdefault("last_verified_at", observed_at)
    if commit_sha:
        props.setdefault("commit_sha", commit_sha)
    props.setdefault("repo_path", str(repo_path))
    tier = props.setdefault("capability_tier", infer_node_capability_tier(node))
    props.setdefault("confidence_score", infer_node_confidence_score(node))
    props.setdefault("confidence_label", f"{tier} ({tier_confidence_score(tier):.2f})")


def ensure_relationship_provenance(
    rel: GraphRelationship,
    source_node: GraphNode | None,
    target_node: GraphNode | None,
    *,
    observed_at: str | None,
    commit_sha: str | None,
) -> None:
    props = rel.properties or {}
    rel.properties = props

    src_props = source_node.properties if source_node else {}
    tgt_props = target_node.properties if target_node else {}
    rel_commit = (
        props.get("commit_sha")
        or src_props.get("commit_sha")
        or tgt_props.get("commit_sha")
        or commit_sha
    )
    rel_observed = (
        props.get("observed_at")
        or src_props.get("observed_at")
        or tgt_props.get("observed_at")
        or observed_at
        or utc_now_iso()
    )
    rel_verified = (
        props.get("last_verified_at")
        or src_props.get("last_verified_at")
        or tgt_props.get("last_verified_at")
        or observed_at
        or utc_now_iso()
    )
    rel_tier = props.get("capability_tier") or min_tier(
        src_props.get("capability_tier"),
        tgt_props.get("capability_tier"),
    )
    rel_confidence = props.get("confidence")
    try:
        score = float(rel_confidence) if rel_confidence is not None else min(
            float(src_props.get("confidence_score", 1.0)),
            float(tgt_props.get("confidence_score", 1.0)),
        )
    except (TypeError, ValueError):
        score = tier_confidence_score(rel_tier)

    props.setdefault("source_system", DEFAULT_SOURCE_SYSTEM)
    props.setdefault("source_id", rel.id or f"{rel.type.value}:{rel.source}->{rel.target}")
    props.setdefault("observed_at", rel_observed)
    props.setdefault("last_verified_at", rel_verified)
    if rel_commit:
        props.setdefault("commit_sha", rel_commit)
    props.setdefault("capability_tier", _normalize_tier(rel_tier))
    props.setdefault("confidence_score", score)


def apply_graph_provenance(graph: KnowledgeGraph, repo_path: Path) -> None:
    observed_at = utc_now_iso()
    commit_sha = detect_commit_sha(repo_path)

    for node in graph.iter_nodes():
        ensure_node_provenance(node, repo_path=repo_path, observed_at=observed_at, commit_sha=commit_sha)

    for rel in graph.iter_relationships():
        ensure_relationship_provenance(
            rel,
            graph.get_node(rel.source),
            graph.get_node(rel.target),
            observed_at=observed_at,
            commit_sha=commit_sha,
        )


def serialize_provenance(props: dict[str, Any] | None, *, fallback_source_id: str = "") -> dict[str, Any]:
    payload = props or {}
    return {
        "sourceSystem": payload.get("source_system", DEFAULT_SOURCE_SYSTEM),
        "sourceId": payload.get("source_id") or fallback_source_id,
        "observedAt": payload.get("observed_at"),
        "commitSha": payload.get("commit_sha"),
        "capabilityTier": _normalize_tier(payload.get("capability_tier")),
        "lastVerifiedAt": payload.get("last_verified_at"),
        "repoPath": payload.get("repo_path"),
    }


def serialize_confidence(props: dict[str, Any] | None, *, fallback_tier: str = "T0") -> dict[str, Any]:
    payload = props or {}
    tier = _normalize_tier(payload.get("capability_tier") or fallback_tier)
    try:
        score = float(payload.get("confidence_score", tier_confidence_score(tier)))
    except (TypeError, ValueError):
        score = tier_confidence_score(tier)
    return {
        "tier": tier,
        "score": score,
        "label": payload.get("confidence_label") or f"{tier} ({score:.2f})",
    }
