"""External dependency extraction from package manifests."""

from __future__ import annotations

import json
import logging
from pathlib import Path

from logthread.core.graph.graph import KnowledgeGraph
from logthread.core.graph.model import GraphNode, GraphRelationship, NodeLabel, RelType, generate_id

logger = logging.getLogger(__name__)

def process_dependencies(repo_path: Path, graph: KnowledgeGraph) -> int:
    """Find package manifests in the tree and create EXTERNAL_DEP nodes.
    
    Returns:
        The number of external dependencies found.
    """
    count = 0

    # 1. Python (requirements.txt, pyproject.toml)
    for path in repo_path.rglob("requirements.txt"):
        if ".venv" in path.parts or "venv" in path.parts or "node_modules" in path.parts:
            continue
        count += _parse_requirements_txt(path, repo_path, graph)

    for path in repo_path.rglob("pyproject.toml"):
        if ".venv" in path.parts or "venv" in path.parts or "node_modules" in path.parts:
            continue
        count += _parse_pyproject_toml(path, repo_path, graph)

    # 2. Node.js (package.json)
    for path in repo_path.rglob("package.json"):
        if "node_modules" in path.parts:
            continue
        count += _parse_package_json(path, repo_path, graph)

    # 3. Go (go.mod)
    for path in repo_path.rglob("go.mod"):
        if "vendor" in path.parts:
            continue
        count += _parse_go_mod(path, repo_path, graph)

    # 4. Ruby (Gemfile)
    for path in repo_path.rglob("Gemfile"):
        count += _parse_gemfile(path, repo_path, graph)

    # 5. C# (.csproj)
    for path in repo_path.rglob("*.csproj"):
        count += _parse_csproj(path, repo_path, graph)

    return count

def _add_dep(
    name: str, version: str, language: str,
    manifest_path: Path, repo_path: Path, graph: KnowledgeGraph
) -> None:
    """Create the EXTERNAL_DEP node and a DEPENDS_ON edge from the manifest file."""
    if not name:
        return

    rel_manifest_path = str(manifest_path.relative_to(repo_path)).replace("\\", "/")

    # The dep node ID is global per repository
    dep_id = f"{NodeLabel.EXTERNAL_DEP.value}:{language}:{name}"

    if not graph.get_node(dep_id):
        graph.add_node(
            GraphNode(
                id=dep_id,
                label=NodeLabel.EXTERNAL_DEP,
                name=name,
                language=language,
                properties={"version": version},
            )
        )

    # Link the manifest file to the dependency
    file_id = generate_id(NodeLabel.FILE, rel_manifest_path)
    if graph.get_node(file_id):
        # The file depends on the external package
        edge_id = f"{file_id}->{dep_id}"
        graph.add_relationship(
            GraphRelationship(
                id=edge_id,
                type=RelType.DEPENDS_ON,
                source=file_id,
                target=dep_id,
            )
        )

def _parse_requirements_txt(path: Path, repo_path: Path, graph: KnowledgeGraph) -> int:
    count = 0
    try:
        content = path.read_text(encoding="utf-8")
        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("-"):
                continue

            # Simple parsing: take everything before ==, >=, <=, ~, !
            name = line
            version = ""
            for op in ("==", ">=", "<=", "~=", "!="):
                if op in name:
                    parts = name.split(op, 1)
                    name = parts[0].strip()
                    version = op + parts[1].strip()
                    break

            # Strip extras like [dev]
            if "[" in name:
                name = name.split("[")[0].strip()

            _add_dep(name, version, "python", path, repo_path, graph)
            count += 1
    except Exception as e:
        logger.warning(f"Error parsing {path}: {e}")
    return count

def _parse_pyproject_toml(path: Path, repo_path: Path, graph: KnowledgeGraph) -> int:
    count = 0
    try:
        # Fallback simple parser for dependencies since tomli might not be available
        content = path.read_text(encoding="utf-8")
        in_deps = False

        for line in content.splitlines():
            line = line.strip()
            if line.startswith("["):
                in_deps = "dependencies]" in line or "requires]" in line
                continue

            if in_deps and line.startswith('"') or line.startswith("'"):
                # e.g. "typer>=0.15.0",
                dep_str = line.strip(",\"'")

                name = dep_str
                version = ""
                for op in ("==", ">=", "<=", "~=", "!="):
                    if op in name:
                        parts = name.split(op, 1)
                        name = parts[0].strip()
                        version = op + parts[1].strip()
                        break

                if "[" in name:
                    name = name.split("[")[0].strip()

                if name:
                    _add_dep(name, version, "python", path, repo_path, graph)
                    count += 1

    except Exception as e:
        logger.warning(f"Error parsing {path}: {e}")
    return count

def _parse_package_json(path: Path, repo_path: Path, graph: KnowledgeGraph) -> int:
    count = 0
    try:
        content = path.read_text(encoding="utf-8")
        data = json.loads(content)

        for section in ("dependencies", "devDependencies", "peerDependencies"):
            deps = data.get(section, {})
            for name, version in deps.items():
                _add_dep(name, str(version), "npm", path, repo_path, graph)
                count += 1
    except Exception as e:
        logger.warning(f"Error parsing {path}: {e}")
    return count

def _parse_go_mod(path: Path, repo_path: Path, graph: KnowledgeGraph) -> int:
    count = 0
    try:
        content = path.read_text(encoding="utf-8")
        in_require = False

        for line in content.splitlines():
            line = line.strip()
            if line.startswith("require ("):
                in_require = True
                continue
            if line == ")":
                in_require = False
                continue

            if in_require or line.startswith("require "):
                # require github.com/foo/bar v1.2.3 // indirect
                clean_line = line.replace("require ", "").strip()
                parts = clean_line.split()
                if len(parts) >= 2:
                    name = parts[0]
                    version = parts[1]
                    _add_dep(name, version, "go", path, repo_path, graph)
                    count += 1
    except Exception as e:
        logger.warning(f"Error parsing {path}: {e}")
    return count

def _parse_gemfile(path: Path, repo_path: Path, graph: KnowledgeGraph) -> int:
    count = 0
    try:
        content = path.read_text(encoding="utf-8")
        for line in content.splitlines():
            line = line.strip()
            if line.startswith("gem "):
                parts = line.replace("gem ", "").split(",")
                if parts:
                    name = parts[0].strip().strip("\"'")
                    version = parts[1].strip().strip("\"'") if len(parts) > 1 else ""
                    _add_dep(name, version, "ruby", path, repo_path, graph)
                    count += 1
    except Exception as e:
        logger.warning(f"Error parsing {path}: {e}")
    return count

def _parse_csproj(path: Path, repo_path: Path, graph: KnowledgeGraph) -> int:
    count = 0
    try:
        content = path.read_text(encoding="utf-8")
        # simple xml parsing
        for line in content.splitlines():
            if "<PackageReference" in line and "Include=" in line:
                # <PackageReference Include="Newtonsoft.Json" Version="13.0.1" />
                try:
                    inc_start = line.find('Include="') + 9
                    inc_end = line.find('"', inc_start)
                    name = line[inc_start:inc_end]

                    version = ""
                    if "Version=" in line:
                        v_start = line.find('Version="') + 9
                        v_end = line.find('"', v_start)
                        version = line[v_start:v_end]

                    if name:
                        _add_dep(name, version, "nuget", path, repo_path, graph)
                        count += 1
                except ValueError:
                    continue
    except Exception as e:
        logger.warning(f"Error parsing {path}: {e}")
    return count
