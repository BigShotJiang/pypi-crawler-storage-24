"""Phase: API endpoint and database table ingestion.

Processes ParseResult.api_endpoints, sql_queries, and db_tables extracted by
the language parsers to build richer graph nodes and relationships:

- API_ENDPOINT nodes for each detected HTTP route (Express/Flask/FastAPI)
- DB_TABLE nodes for each CREATE TABLE found in .sql files or inline DDL
- HANDLES_ROUTE edges: handler functions → API_ENDPOINT
- PROTECTED_BY edges: API_ENDPOINT → middleware function nodes
- QUERIES_TABLE edges: function → DB_TABLE (from SQL call sites)
"""

from __future__ import annotations

import logging

from logthread.core.graph.graph import KnowledgeGraph
from logthread.core.graph.model import (
    GraphNode,
    GraphRelationship,
    NodeLabel,
    RelType,
    generate_id,
)
from logthread.core.ingestion.imports import (
    _detect_source_roots,
    build_file_index,
    resolve_import_path,
)
from logthread.core.ingestion.parser_phase import FileParseData
from logthread.core.ingestion.symbol_lookup import build_name_index

logger = logging.getLogger(__name__)


def process_api_and_db(
    parse_data: list[FileParseData],
    graph: KnowledgeGraph,
) -> None:
    """Ingest API endpoints, DB tables, and their relationships into *graph*.

    Call this after :func:`process_parsing` so that Function/Method symbol
    nodes already exist and can be linked via HANDLES_ROUTE / QUERIES_TABLE.
    """
    # Build a name index over functions and methods for fast lookup
    func_labels = (NodeLabel.FUNCTION, NodeLabel.METHOD, NodeLabel.CLASS)
    name_index = build_name_index(graph, func_labels)
    file_index = build_file_index(graph)
    source_roots = _detect_source_roots(file_index)
    callable_index = _build_callable_index(graph, func_labels)

    _ingest_db_tables(parse_data, graph)
    _ingest_api_endpoints(
        parse_data,
        graph,
        name_index,
        callable_index,
        file_index,
        source_roots,
    )
    _ingest_sql_queries(parse_data, graph, name_index)


# ── DB Table ingestion ────────────────────────────────────────────────────────


def _ingest_db_tables(
    parse_data: list[FileParseData],
    graph: KnowledgeGraph,
) -> None:
    """Create DB_TABLE nodes from schema definitions found in SQL files."""
    seen_tables: set[str] = set()

    for fd in parse_data:
        for tbl in fd.parse_result.db_tables:
            table_key = tbl.name.lower()
            if table_key in seen_tables:
                continue
            seen_tables.add(table_key)

            node_id = generate_id(NodeLabel.DB_TABLE, fd.file_path, tbl.name)
            file_id = generate_id(NodeLabel.FILE, fd.file_path)

            graph.add_node(
                GraphNode(
                    id=node_id,
                    label=NodeLabel.DB_TABLE,
                    name=tbl.name,
                    file_path=fd.file_path,
                    start_line=tbl.line,
                    language=fd.language,
                )
            )

            # FILE --defines--> DB_TABLE
            graph.add_relationship(
                GraphRelationship(
                    id=f"defines:{file_id}->{node_id}",
                    type=RelType.DEFINES,
                    source=file_id,
                    target=node_id,
                )
            )

            # Ingest DB_COLUMN nodes
            for col in tbl.columns:
                col_name = col.get("name", "unknown")
                col_type = col.get("type", "")
                col_id = generate_id(NodeLabel.DB_COLUMN, fd.file_path, f"{tbl.name}.{col_name}")

                graph.add_node(
                    GraphNode(
                        id=col_id,
                        label=NodeLabel.DB_COLUMN,
                        name=col_name,
                        file_path=fd.file_path,
                        start_line=tbl.line,
                        language=fd.language,
                        properties={
                            "datatype": col_type,
                            "table": tbl.name,
                        },
                    )
                )

                # DB_TABLE --has_column--> DB_COLUMN
                graph.add_relationship(
                    GraphRelationship(
                        id=f"has_column:{node_id}->{col_id}",
                        type=RelType.HAS_COLUMN,
                        source=node_id,
                        target=col_id,
                    )
                )

            logger.debug(
                "DB_TABLE %s (%d columns) from %s",
                tbl.name,
                len(tbl.columns),
                fd.file_path,
            )


# ── API Endpoint ingestion ────────────────────────────────────────────────────

def _ingest_api_endpoints(
    parse_data: list[FileParseData],
    graph: KnowledgeGraph,
    name_index: dict[str, list[str]],
    callable_index: dict[tuple[str, str], list[str]],
    file_index: dict[str, str],
    source_roots: set[str],
) -> None:
    """Create API_ENDPOINT nodes and link handler/middleware functions."""
    for fd in parse_data:
        import_targets = _resolve_import_targets(fd, file_index, source_roots)
        for ep in fd.parse_result.api_endpoints:
            ep_name = f"{ep.method}:{ep.path}"
            node_id = generate_id(NodeLabel.API_ENDPOINT, fd.file_path, ep_name)
            file_id = generate_id(NodeLabel.FILE, fd.file_path)

            graph.add_node(
                GraphNode(
                    id=node_id,
                    label=NodeLabel.API_ENDPOINT,
                    name=ep_name,
                    file_path=fd.file_path,
                    start_line=ep.line,
                    language=fd.language,
                    properties={
                        "http_method": ep.method,
                        "path": ep.path,
                        "handlers": ep.handler_names,
                        "framework": ep.framework,
                    },
                )
            )

            # FILE --defines--> API_ENDPOINT
            graph.add_relationship(
                GraphRelationship(
                    id=f"defines:{file_id}->{node_id}",
                    type=RelType.DEFINES,
                    source=file_id,
                    target=node_id,
                )
            )

            # Always connect the endpoint back to its defining file so focused
            # API traces can pivot from a route to the file and then into local
            # sibling routes, handlers, imports, and DB usage.
            graph.add_relationship(
                GraphRelationship(
                    id=f"depends_on:{node_id}->{file_id}:source",
                    type=RelType.DEPENDS_ON,
                    source=node_id,
                    target=file_id,
                    properties={"kind": "source_file"},
                )
            )

            # Wire handlers: first = main handler, rest treated as middleware
            for i, handler_name in enumerate(ep.handler_names):
                if handler_name == "<anonymous>":
                    continue
                is_middleware = i < len(ep.handler_names) - 1
                func_id, target_file_id = _resolve_endpoint_binding(
                    handler_name,
                    fd.file_path,
                    name_index,
                    callable_index,
                    import_targets,
                    graph,
                )

                if target_file_id:
                    graph.add_relationship(
                        GraphRelationship(
                            id=f"depends_on:{node_id}->{target_file_id}:{i}",
                            type=RelType.DEPENDS_ON,
                            source=node_id,
                            target=target_file_id,
                            properties={
                                "binding": handler_name,
                                "role": "middleware" if is_middleware else "handler",
                            },
                        )
                    )

                if func_id is None:
                    continue

                if is_middleware:
                    # endpoint --protected_by--> middleware function
                    graph.add_relationship(
                        GraphRelationship(
                            id=f"protected_by:{node_id}->{func_id}:{i}",
                            type=RelType.PROTECTED_BY,
                            source=node_id,
                            target=func_id,
                            properties={"order": i},
                        )
                    )
                else:
                    # handler --handles_route--> endpoint
                    graph.add_relationship(
                        GraphRelationship(
                            id=f"handles_route:{func_id}->{node_id}",
                            type=RelType.HANDLES_ROUTE,
                            source=func_id,
                            target=node_id,
                        )
                    )

            logger.debug(
                "API_ENDPOINT %s %s from %s", ep.method, ep.path, fd.file_path
            )


def _build_callable_index(
    graph: KnowledgeGraph,
    labels: tuple[NodeLabel, ...],
) -> dict[tuple[str, str], list[str]]:
    index: dict[tuple[str, str], list[str]] = {}
    for label in labels:
        for node in graph.get_nodes_by_label(label):
            index.setdefault((node.file_path, node.name), []).append(node.id)
    return index


def _resolve_import_targets(
    file_data: FileParseData,
    file_index: dict[str, str],
    source_roots: set[str],
) -> dict[str, str]:
    targets: dict[str, str] = {}
    for imp in file_data.parse_result.imports:
        target_id = resolve_import_path(file_data.file_path, imp, file_index, source_roots)
        if target_id is None:
            continue
        for name in imp.names:
            if name:
                targets[name] = target_id
        if imp.alias:
            targets[imp.alias] = target_id
    return targets


def _resolve_endpoint_binding(
    binding: str,
    file_path: str,
    name_index: dict[str, list[str]],
    callable_index: dict[tuple[str, str], list[str]],
    import_targets: dict[str, str],
    graph: KnowledgeGraph,
) -> tuple[str | None, str | None]:
    binding = binding.strip()
    if not binding:
        return None, None

    receiver = ""
    symbol_name = binding
    if "." in binding:
        receiver, _, symbol_name = binding.rpartition(".")
        receiver = receiver.strip()
        symbol_name = symbol_name.strip()

    imported_file_id = import_targets.get(receiver or binding)
    imported_file_path = ""
    if imported_file_id:
        imported_file = graph.get_node(imported_file_id)
        imported_file_path = imported_file.file_path if imported_file else ""

    if imported_file_path:
        scoped = callable_index.get((imported_file_path, symbol_name))
        if scoped:
            return scoped[0], imported_file_id
        if receiver:
            class_scoped = [
                nid
                for nid in scoped or []
                if (candidate := graph.get_node(nid)) is not None and candidate.class_name == receiver
            ]
            if class_scoped:
                return class_scoped[0], imported_file_id

    local_scoped = callable_index.get((file_path, symbol_name))
    if local_scoped:
        if receiver:
            class_local = [
                nid
                for nid in local_scoped
                if (candidate := graph.get_node(nid)) is not None and candidate.class_name == receiver
            ]
            if class_local:
                return class_local[0], imported_file_id
        return local_scoped[0], imported_file_id

    candidates = name_index.get(symbol_name, [])
    if imported_file_path:
        for nid in candidates:
            node = graph.get_node(nid)
            if node is not None and node.file_path == imported_file_path:
                if receiver and node.class_name and node.class_name != receiver and node.name != receiver:
                    continue
                return nid, imported_file_id

    for nid in candidates:
        node = graph.get_node(nid)
        if node is not None and node.file_path == file_path:
            if receiver and node.class_name and node.class_name != receiver and node.name != receiver:
                continue
            return nid, imported_file_id

    if receiver:
        for nid in candidates:
            node = graph.get_node(nid)
            if node is not None and (node.class_name == receiver or node.name == receiver):
                return nid, imported_file_id

    if candidates:
        return candidates[0], imported_file_id

    return None, imported_file_id


# ── SQL query relationship ingestion ─────────────────────────────────────────


def _ingest_sql_queries(
    parse_data: list[FileParseData],
    graph: KnowledgeGraph,
    name_index: dict[str, list[str]],
) -> None:
    """Create SQL lineage edges from SQL call sites to DB tables and columns."""
    # Build a table name → DB_TABLE node id index
    table_index: dict[str, str] = {}
    column_index: dict[tuple[str, str], str] = {}
    for node in graph.iter_nodes():
        if node.label == NodeLabel.DB_TABLE:
            table_index[node.name.lower()] = node.id
        elif node.label == NodeLabel.DB_COLUMN:
            table_name = str(node.properties.get("table", "")).lower()
            column_index[(table_name, node.name.lower())] = node.id

    if not table_index:
        logger.debug("No DB_TABLE nodes found; skipping SQL query relationship pass")
        return

    for fd in parse_data:
        for sq in fd.parse_result.sql_queries:
            # Find the enclosing function node for the file
            file_funcs = [
                node.id
                for label in (NodeLabel.FUNCTION, NodeLabel.METHOD)
                for node in graph.get_nodes_by_label(label)
                if node.file_path == fd.file_path
            ]
            # Pick the function that contains the query's line number
            caller_id: str | None = None
            for nid in file_funcs:
                n = graph.get_node(nid)
                if n and n.start_line <= sq.line <= n.end_line:
                    caller_id = nid
                    break
            # Fallback: use the file node itself
            if caller_id is None:
                caller_id = generate_id(NodeLabel.FILE, fd.file_path)

            for tbl_name in sq.tables_referenced:
                tbl_id = table_index.get(tbl_name.lower())
                if tbl_id is None:
                    logger.debug(
                        "SQL query at %s:%d references unknown table %r",
                        fd.file_path,
                        sq.line,
                        tbl_name,
                    )
                    continue

                rel_id = f"queries_table:{caller_id}->{tbl_id}:{sq.line}"
                graph.add_relationship(
                    GraphRelationship(
                        id=rel_id,
                        type=RelType.QUERIES_TABLE,
                        source=caller_id,
                        target=tbl_id,
                        properties={"line": sq.line, "sql_preview": sq.sql_text[:120]},
                    )
                )

            for col_ref in sq.columns_referenced:
                table_name = ""
                column_name = col_ref
                if "." in col_ref:
                    table_name, column_name = col_ref.split(".", 1)
                elif len(sq.tables_referenced) == 1:
                    table_name = sq.tables_referenced[0]
                if not table_name or not column_name:
                    continue

                col_id = column_index.get((table_name.lower(), column_name.lower()))
                if col_id is None:
                    continue

                rel_id = f"queries_column:{caller_id}->{col_id}:{sq.line}:{column_name.lower()}"
                graph.add_relationship(
                    GraphRelationship(
                        id=rel_id,
                        type=RelType.QUERIES_COLUMN,
                        source=caller_id,
                        target=col_id,
                        properties={"line": sq.line, "sql_preview": sq.sql_text[:120]},
                    )
                )
