"""Git repository discovery utilities."""

from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def find_git_root(start_path: Path) -> Path | None:
    """Find the git repository root by searching upward from start_path.
    
    Args:
        start_path: Directory to start searching from.
        
    Returns:
        Path to the git repository root, or None if not found.
    """
    current = start_path.resolve()
    
    # Search upward through parent directories
    while current != current.parent:
        git_dir = current / ".git"
        if git_dir.exists():
            return current
        current = current.parent
    
    # Check root directory
    git_dir = current / ".git"
    if git_dir.exists():
        return current
    
    return None


def find_git_repos_in_subdirs(start_path: Path, max_depth: int = 3) -> list[Path]:
    """Find git repositories in subdirectories.
    
    Args:
        start_path: Directory to start searching from.
        max_depth: Maximum depth to search (default: 3).
        
    Returns:
        List of paths to git repository roots.
    """
    repos: list[Path] = []
    
    def _search(path: Path, depth: int) -> None:
        if depth > max_depth:
            return
        
        try:
            for item in path.iterdir():
                if not item.is_dir():
                    continue
                
                # Skip hidden directories except .git
                if item.name.startswith(".") and item.name != ".git":
                    continue
                
                # Skip common non-repo directories
                if item.name in {"node_modules", "venv", ".venv", "__pycache__", "dist", "build"}:
                    continue
                
                # Check if this is a git repo
                git_dir = item / ".git"
                if git_dir.exists():
                    repos.append(item)
                    # Don't search inside found repos
                    continue
                
                # Recurse into subdirectories
                _search(item, depth + 1)
        except PermissionError:
            # Skip directories we can't access
            pass
    
    _search(start_path, 0)
    return repos


def discover_git_repositories(start_path: Path, max_depth: int = 3) -> dict[str, list[Path]]:
    """Discover all accessible git repositories.
    
    Searches both upward (parent directories) and downward (subdirectories)
    from the start path.
    
    Args:
        start_path: Directory to start searching from.
        max_depth: Maximum depth to search in subdirectories (default: 3).
        
    Returns:
        Dictionary with 'parent' and 'subdirs' keys containing lists of repository paths.
    """
    result: dict[str, list[Path]] = {
        "parent": [],
        "subdirs": [],
    }
    
    # Search upward for parent git repo
    parent_repo = find_git_root(start_path)
    if parent_repo:
        result["parent"].append(parent_repo)
    
    # Search downward for git repos in subdirectories
    subdir_repos = find_git_repos_in_subdirs(start_path, max_depth)
    result["subdirs"] = subdir_repos
    
    return result
