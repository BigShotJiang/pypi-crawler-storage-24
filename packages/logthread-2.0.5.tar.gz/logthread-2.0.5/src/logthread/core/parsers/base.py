"""Base parser interface and shared data structures.

Defines the intermediate representation produced by language-specific parsers
before the data is mapped into the knowledge graph.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class SymbolInfo:
    """A parsed symbol (function, class, method, etc.)."""

    name: str
    kind: str  # "function", "class", "method", "interface", "type_alias", "enum"
    start_line: int
    end_line: int
    content: str
    signature: str = ""
    class_name: str = ""  # for methods: the owning class
    decorators: list[str] = field(default_factory=list)  # e.g. ["staticmethod", "server.list_tools"]

@dataclass
class ImportInfo:
    """A parsed import statement.

    Contract:
    - ``module``: the source module path (e.g. ``"os.path"``, ``"./utils"``).
    - ``names``: the symbols being imported from *module* (e.g. ``["join", "exists"]``).
      For ``import numpy as np``, ``names=["numpy"]`` (the last segment of the module),
      NOT the alias.  For ``from os.path import join``, ``names=["join"]``.
    - ``alias``: the local binding name when the import is aliased
      (e.g. ``"np"`` for ``import numpy as np``, ``""`` otherwise).
      Import resolution uses ``module`` to locate the target file; ``alias`` is
      only relevant for local-name lookups by callers.
    """

    module: str  # the module path (e.g., "os.path", "./utils")
    names: list[str] = field(default_factory=list)  # imported names (e.g., ["join", "exists"])
    is_relative: bool = False
    alias: str = ""  # local binding name when aliased (e.g. "np" for "import numpy as np")

@dataclass
class CallInfo:
    """A parsed function call."""

    name: str  # the called function/method name
    line: int
    receiver: str = ""  # for method calls: the object (e.g., "self", "user")
    arguments: list[str] = field(default_factory=list)  # bare identifier arguments (callbacks)

@dataclass
class TypeRef:
    """A parsed type annotation reference."""

    name: str  # the type name (e.g., "User", "list", "str")
    kind: str  # "param", "return", "variable"
    line: int
    param_name: str = ""  # for param types: the parameter name

@dataclass
class ApiEndpointInfo:
    """A detected HTTP API endpoint (Express/Flask/FastAPI route)."""

    method: str           # HTTP verb: GET, POST, PUT, DELETE, PATCH, USE
    path: str             # route path e.g. "/api/auth/login"
    handler_names: list[str]  # middleware + handler function names in order
    line: int
    framework: str = "express"  # express, flask, fastapi, …

@dataclass
class SqlQueryInfo:
    """A detected SQL query call site within application code."""

    sql_text: str              # the raw SQL string (may be partial for templates)
    tables_referenced: list[str]  # table names extracted from the SQL
    line: int
    columns_referenced: list[str] = field(default_factory=list)  # table.column or bare column names
    caller_name: str = ""      # enclosing function/method name, if known

@dataclass
class DbTableInfo:
    """A database table definition extracted from a SQL file or inline DDL."""

    name: str                   # table name (lowercased)
    columns: list[dict]         # [{"name": str, "type": str, "constraints": list[str]}]
    source_file: str
    line: int

@dataclass
class ParseResult:
    """Complete parse result for a single file."""

    symbols: list[SymbolInfo] = field(default_factory=list)
    imports: list[ImportInfo] = field(default_factory=list)
    calls: list[CallInfo] = field(default_factory=list)
    type_refs: list[TypeRef] = field(default_factory=list)
    heritage: list[tuple[str, str, str]] = field(
        default_factory=list
    )  # (class_name, kind, parent_name) where kind is "extends" or "implements"
    exports: list[str] = field(default_factory=list)  # names from __all__ or export statements
    api_endpoints: list[ApiEndpointInfo] = field(default_factory=list)
    sql_queries: list[SqlQueryInfo] = field(default_factory=list)
    db_tables: list[DbTableInfo] = field(default_factory=list)

class LanguageParser(ABC):
    """Base interface for language-specific parsers."""

    @abstractmethod
    def parse(self, content: str, file_path: str) -> ParseResult: ...
