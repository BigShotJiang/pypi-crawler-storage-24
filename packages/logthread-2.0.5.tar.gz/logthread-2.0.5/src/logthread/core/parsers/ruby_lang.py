"""Ruby language parser using tree-sitter.

Extracts classes, modules, methods, require/require_relative imports,
method calls, and class inheritance from Ruby source files.
"""

from __future__ import annotations

import tree_sitter_ruby as tsruby
from tree_sitter import Language, Node, Parser

from logthread.core.parsers.base import (
    CallInfo,
    ImportInfo,
    LanguageParser,
    ParseResult,
    SymbolInfo,
)

RUBY_LANGUAGE = Language(tsruby.language())


class RubyParser(LanguageParser):
    """Parses Ruby source code using tree-sitter."""

    def __init__(self) -> None:
        self._parser = Parser(RUBY_LANGUAGE)

    def parse(self, content: str, file_path: str) -> ParseResult:
        tree = self._parser.parse(content.encode("utf-8"))
        result = ParseResult()
        self._walk(tree.root_node, content, result, class_name="", module_name="")
        return result

    def _walk(
        self, node: Node, content: str, result: ParseResult,
        class_name: str, module_name: str,
    ) -> None:
        for child in node.children:
            match child.type:
                case "class":
                    self._extract_class(child, content, result, module_name)
                case "module":
                    self._extract_module(child, content, result, module_name)
                case "method":
                    self._extract_method(child, content, result, class_name)
                case "singleton_method":
                    self._extract_singleton_method(child, content, result, class_name)
                case "call":
                    self._extract_call_or_require(child, content, result)
                case _:
                    self._walk(child, content, result, class_name, module_name)

    # ---- Classes ----

    def _extract_class(
        self, node: Node, content: str, result: ParseResult,
        module_name: str,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return

        name = name_node.text.decode("utf-8")
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        node_content = content[node.start_byte : node.end_byte]

        result.symbols.append(
            SymbolInfo(
                name=name, kind="class",
                start_line=start_line, end_line=end_line,
                content=node_content,
            )
        )

        # Heritage: class Foo < Bar
        superclass = node.child_by_field_name("superclass")
        if superclass:
            for child in superclass.children:
                if child.type != "<":
                    parent_name = child.text.decode("utf-8")
                    result.heritage.append((name, "extends", parent_name))
                    break

        # Walk body
        body = node.child_by_field_name("body")
        if body:
            self._walk(body, content, result, class_name=name, module_name=module_name)
            self._extract_calls_recursive(body, result)

    # ---- Modules ----

    def _extract_module(
        self, node: Node, content: str, result: ParseResult,
        module_name: str,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return

        name = name_node.text.decode("utf-8")
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        node_content = content[node.start_byte : node.end_byte]

        result.symbols.append(
            SymbolInfo(
                name=name, kind="class",  # modules are class-like in Ruby
                start_line=start_line, end_line=end_line,
                content=node_content,
            )
        )

        body = node.child_by_field_name("body")
        if body:
            self._walk(body, content, result, class_name=name, module_name=name)
            self._extract_calls_recursive(body, result)

    # ---- Methods ----

    def _extract_method(
        self, node: Node, content: str, result: ParseResult,
        class_name: str,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return

        name = name_node.text.decode("utf-8")
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        node_content = content[node.start_byte : node.end_byte]
        signature = self._build_method_signature(node, name)

        kind = "method" if class_name else "function"

        result.symbols.append(
            SymbolInfo(
                name=name, kind=kind,
                start_line=start_line, end_line=end_line,
                content=node_content,
                signature=signature,
                class_name=class_name,
            )
        )

        body = node.child_by_field_name("body")
        if body:
            self._walk(body, content, result, class_name="", module_name="")

    def _extract_singleton_method(
        self, node: Node, content: str, result: ParseResult,
        class_name: str,
    ) -> None:
        """Handle `def self.method_name`."""
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return

        name = name_node.text.decode("utf-8")
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        node_content = content[node.start_byte : node.end_byte]
        signature = self._build_method_signature(node, f"self.{name}")

        result.symbols.append(
            SymbolInfo(
                name=name, kind="method",
                start_line=start_line, end_line=end_line,
                content=node_content,
                signature=signature,
                class_name=class_name,
            )
        )

        body = node.child_by_field_name("body")
        if body:
            self._walk(body, content, result, class_name="", module_name="")

    # ---- Requires / Calls ----

    def _extract_call_or_require(
        self, node: Node, content: str, result: ParseResult,
    ) -> None:
        """Handle both regular calls and require/require_relative."""
        method_node = node.child_by_field_name("method")
        if method_node is None:
            return

        method_name = method_node.text.decode("utf-8")

        if method_name in ("require", "require_relative"):
            self._extract_require(node, method_name, result)
            return

        # Regular call
        receiver_node = node.child_by_field_name("receiver")
        line = node.start_point[0] + 1
        arguments = self._extract_identifier_arguments(node)

        receiver = ""
        if receiver_node:
            receiver = self._root_identifier(receiver_node)

        result.calls.append(
            CallInfo(
                name=method_name,
                line=line,
                receiver=receiver,
                arguments=arguments,
            )
        )

    def _extract_require(
        self, node: Node, kind: str, result: ParseResult,
    ) -> None:
        """Handle `require 'foo'` or `require_relative 'foo'`."""
        args = node.child_by_field_name("arguments")
        if args is None:
            return

        module = ""
        for child in args.children:
            if child.type == "argument_list":
                for arg in child.children:
                    if arg.type == "string":
                        module = self._string_value(arg)
                        break
                break
            elif child.type == "string":
                module = self._string_value(child)
                break

        if not module:
            return

        is_relative = kind == "require_relative" or module.startswith(".")

        parts = module.replace("/", ".").split(".")
        imported_name = parts[-1] if parts else module

        result.imports.append(
            ImportInfo(
                module=module,
                names=[imported_name],
                is_relative=is_relative,
            )
        )

    # ---- Recursive call extraction ----

    def _extract_calls_recursive(self, node: Node, result: ParseResult) -> None:
        if node.type == "call":
            method_node = node.child_by_field_name("method")
            if method_node:
                method_name = method_node.text.decode("utf-8")
                if method_name not in ("require", "require_relative"):
                    receiver_node = node.child_by_field_name("receiver")
                    line = node.start_point[0] + 1
                    arguments = self._extract_identifier_arguments(node)
                    receiver = ""
                    if receiver_node:
                        receiver = self._root_identifier(receiver_node)
                    result.calls.append(
                        CallInfo(
                            name=method_name,
                            line=line,
                            receiver=receiver,
                            arguments=arguments,
                        )
                    )

        for child in node.children:
            self._extract_calls_recursive(child, result)

    # ---- Helpers ----

    @staticmethod
    def _build_method_signature(node: Node, name: str) -> str:
        params = node.child_by_field_name("parameters")
        sig = f"def {name}"
        if params:
            sig += params.text.decode("utf-8")
        return sig

    @staticmethod
    def _extract_identifier_arguments(node: Node) -> list[str]:
        args = node.child_by_field_name("arguments")
        if args is None:
            return []
        identifiers: list[str] = []
        for child in args.children:
            if child.type == "identifier":
                identifiers.append(child.text.decode("utf-8"))
            elif child.type == "argument_list":
                for sub in child.children:
                    if sub.type == "identifier":
                        identifiers.append(sub.text.decode("utf-8"))
        return identifiers

    @staticmethod
    def _root_identifier(node: Node) -> str:
        current = node
        while current is not None:
            if current.type == "identifier":
                return current.text.decode("utf-8")
            if current.type == "constant":
                return current.text.decode("utf-8")
            if current.children:
                current = current.children[0]
            else:
                break
        return ""

    @staticmethod
    def _string_value(string_node: Node) -> str:
        """Extract string content from a Ruby string literal."""
        for child in string_node.children:
            if child.type == "string_content":
                return child.text.decode("utf-8")
        text = string_node.text.decode("utf-8")
        if len(text) >= 2 and text[0] in ("'", '"') and text[-1] in ("'", '"'):
            return text[1:-1]
        return text
