"""Optional parser support backed by tree-sitter-language-pack.

This is intentionally best-effort. It gives Log Thread a wider syntax net for
popular languages without forcing us to hand-maintain individual tree-sitter
bindings before we can even index a repository.
"""

from __future__ import annotations

from typing import Callable

from logthread.core.parsers.base import (
    CallInfo,
    ImportInfo,
    LanguageParser,
    ParseResult,
    SymbolInfo,
)

try:
    from tree_sitter_language_pack import get_parser as _get_language_pack_parser
except Exception:  # pragma: no cover - optional dependency
    _get_language_pack_parser = None


_DYNAMIC_LANGUAGE_KEYS: frozenset[str] = frozenset({
    "rust",
    "php",
    "kotlin",
    "swift",
    "c",
    "cpp",
    "dart",
    "perl",
})

_CLASS_LIKE_TYPES: frozenset[str] = frozenset({
    "class_declaration",
    "class_definition",
    "class_specifier",
    "struct_item",
    "struct_specifier",
    "enum_item",
    "enum_specifier",
    "interface_declaration",
    "trait_item",
    "impl_item",
})

_FUNCTION_LIKE_TYPES: frozenset[str] = frozenset({
    "function_item",
    "function_declaration",
    "function_definition",
    "method_declaration",
    "method_definition",
    "constructor_declaration",
})

_IMPORT_LIKE_TYPES: frozenset[str] = frozenset({
    "use_declaration",
    "namespace_use_declaration",
    "import_declaration",
    "import_statement",
    "include_expression",
    "preproc_include",
})

_CALL_LIKE_TYPES: frozenset[str] = frozenset({
    "call_expression",
    "function_call_expression",
    "invocation_expression",
})

_IDENTIFIER_LIKE_TYPES: frozenset[str] = frozenset({
    "identifier",
    "type_identifier",
    "field_identifier",
    "property_identifier",
    "name",
})


def has_language_pack() -> bool:
    return _get_language_pack_parser is not None


def get_dynamic_parser_factory(language: str) -> Callable[[], LanguageParser] | None:
    if language not in _DYNAMIC_LANGUAGE_KEYS or not has_language_pack():
        return None
    return lambda: GenericLanguagePackParser(language)


class GenericLanguagePackParser(LanguageParser):
    """Best-effort symbol/import/call extraction for dynamic languages."""

    def __init__(self, language: str) -> None:
        if _get_language_pack_parser is None:
            raise ValueError("tree-sitter-language-pack is not installed")
        self.language = language
        self._parser = _get_language_pack_parser(language)

    def parse(self, content: str, file_path: str) -> ParseResult:
        tree = self._parser.parse(content.encode("utf-8"))
        result = ParseResult()
        self._walk(tree.root_node, result, class_name="")
        return result

    def _walk(self, node, result: ParseResult, class_name: str) -> None:
        ntype = node.type

        if ntype in _CLASS_LIKE_TYPES:
            symbol = self._build_symbol(node, kind="class", class_name="")
            if symbol is not None:
                result.symbols.append(symbol)
                class_name = symbol.name
        elif ntype in _FUNCTION_LIKE_TYPES:
            kind = "method" if class_name else "function"
            symbol = self._build_symbol(node, kind=kind, class_name=class_name)
            if symbol is not None:
                result.symbols.append(symbol)
        elif ntype in _IMPORT_LIKE_TYPES:
            imp = self._build_import(node)
            if imp is not None:
                result.imports.append(imp)
        elif ntype in _CALL_LIKE_TYPES:
            call = self._build_call(node)
            if call is not None:
                result.calls.append(call)

        for child in node.children:
            self._walk(child, result, class_name)

    def _build_symbol(self, node, *, kind: str, class_name: str) -> SymbolInfo | None:
        name = self._extract_name(node)
        if not name:
            return None
        content = node.text.decode("utf-8")
        return SymbolInfo(
            name=name,
            kind=kind,
            start_line=node.start_point[0] + 1,
            end_line=node.end_point[0] + 1,
            content=content,
            signature=content.split("{", 1)[0][:240].strip(),
            class_name=class_name,
        )

    def _build_import(self, node) -> ImportInfo | None:
        text = node.text.decode("utf-8").strip()
        if not text:
            return None
        cleaned = text.replace("use ", "").replace("import ", "").replace("include ", "")
        cleaned = cleaned.replace("#include", "").strip().strip(";")
        if not cleaned:
            return None
        module = cleaned.strip('"<>').strip()
        if not module:
            return None
        leaf = module.split("/")[-1].split("::")[-1].split(".")[-1]
        return ImportInfo(
            module=module,
            names=[leaf] if leaf else [],
            is_relative=module.startswith("."),
        )

    def _build_call(self, node) -> CallInfo | None:
        func = node.child_by_field_name("function") or node.child_by_field_name("callee")
        target = func.text.decode("utf-8") if func is not None else ""
        if not target:
            return None
        receiver = ""
        name = target
        for sep in ("::", "->", "."):
            if sep in target:
                receiver, _, name = target.rpartition(sep)
                break
        name = name.strip()
        if not name:
            return None
        return CallInfo(name=name, line=node.start_point[0] + 1, receiver=receiver.strip())

    def _extract_name(self, node) -> str:
        for field in ("name", "declarator"):
            field_node = node.child_by_field_name(field)
            if field_node is not None:
                nested_name = self._extract_name(field_node)
                if nested_name:
                    return nested_name

        for child in node.children:
            if child.type in _IDENTIFIER_LIKE_TYPES:
                return child.text.decode("utf-8")
            nested_name = self._extract_name_shallow(child)
            if nested_name:
                return nested_name
        return ""

    def _extract_name_shallow(self, node) -> str:
        if node.type in _IDENTIFIER_LIKE_TYPES:
            return node.text.decode("utf-8")
        return ""
