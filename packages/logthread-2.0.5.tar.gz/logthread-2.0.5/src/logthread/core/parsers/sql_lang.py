"""SQL parser — extracts schema definitions from .sql files.

Uses regex-based parsing (no tree-sitter SQL grammar needed) to extract:
- CREATE TABLE statements → DbTableInfo with column definitions
- SQL table references from DML (SELECT/INSERT/UPDATE/DELETE) → for cross-file validation

The parser is intentionally tolerant: it strips comments and normalises
whitespace so that real-world SQL files (migrations, dumps) parse cleanly.
"""

from __future__ import annotations

import logging
import re

from logthread.core.parsers.base import (
    DbTableInfo,
    LanguageParser,
    ParseResult,
    SqlQueryInfo,
    SymbolInfo,
)

try:
    import sqlglot
    from sqlglot import expressions as sqlglot_exp
    from sqlglot.errors import ErrorLevel
except Exception:  # pragma: no cover - optional dependency
    sqlglot = None
    sqlglot_exp = None
    ErrorLevel = None

_SQLGLOT_UNSUPPORTED_COMMAND_WARNING = "contains unsupported syntax. Falling back to parsing as a 'Command'."


class _SqlglotCommandWarningFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        return _SQLGLOT_UNSUPPORTED_COMMAND_WARNING not in record.getMessage()


if sqlglot is not None:
    _sqlglot_logger = logging.getLogger("sqlglot")
    if not getattr(_sqlglot_logger, "_logthread_command_filter", False):
        _sqlglot_logger.addFilter(_SqlglotCommandWarningFilter())
        _sqlglot_logger._logthread_command_filter = True  # type: ignore[attr-defined]

# ── Normalisation helpers ─────────────────────────────────────────────────────

_LINE_COMMENT = re.compile(r"--[^\n]*")
_BLOCK_COMMENT = re.compile(r"/\*.*?\*/", re.DOTALL)
_MULTI_SPACE = re.compile(r"[ \t]+")
_CREATE_FUNCTION_HEAD = re.compile(
    r"CREATE\s+(?:OR\s+REPLACE\s+)?FUNCTION\s+"
    r"(?P<name>(?:\"[^\"]+\"|[a-zA-Z_]\w*)(?:\.(?:\"[^\"]+\"|[a-zA-Z_]\w*))?)\s*\(",
    re.IGNORECASE,
)
_FUNCTION_AS_DOLLAR = re.compile(
    r"\bAS\s+(?P<tag>\$[A-Za-z_0-9]*\$)",
    re.IGNORECASE,
)
_UNSUPPORTED_PG_ADMIN_STATEMENT = re.compile(
    r"(?is)\b(?:ALTER\s+FUNCTION|GRANT\s+EXECUTE\s+ON\s+FUNCTION)\b.*?;"
)
_EXTENSION_STATEMENT = re.compile(
    r"(?is)\b(?:CREATE\s+EXTENSION|LOAD\s+EXTENSION)\b.*?(?:;|$)"
)
_DOLLAR_QUOTED_BLOCK = re.compile(
    r"(?P<tag>\$[A-Za-z_0-9]*\$)(?P<body>.*?)(?P=tag)",
    re.DOTALL,
)
_SINGLE_QUOTED_STRING = re.compile(r"'((?:''|[^'])*)'", re.DOTALL)
_DIRECT_DML_STATEMENT = re.compile(
    r"(?is)(?:RETURN\s+QUERY\s+)?((?:WITH|SELECT|INSERT|UPDATE|DELETE)\b.*?;)"
)
_NON_LINEAGE_PREFIX = re.compile(
    r"(?is)^\s*(?:"
    r"DO\b|"
    r"GRANT\b|"
    r"REVOKE\b|"
    r"ALTER\b|"
    r"ALTER\s+DEFAULT\s+PRIVILEGES\b|"
    r"COMMENT\s+ON\b|"
    r"CREATE\b|"
    r"CREATE\s+TYPE\b|"
    r"DROP\b|"
    r"ALTER\s+TYPE\b|"
    r"DROP\s+TYPE\b|"
    r"IF\b|"
    r"BEGIN\b|"
    r"RAISE\b|"
    r"PERFORM\b|"
    r"TRUNCATE\b"
    r")"
)
_SQL_KEYWORD = re.compile(
    r"\b(?:WITH|SELECT|INSERT|UPDATE|DELETE|FROM|JOIN|WHERE|GROUP\s+BY|ORDER\s+BY|LIMIT|OFFSET|AND\s+[a-zA-Z_]\w*)\b",
    re.IGNORECASE,
)


def _clean_sql(text: str) -> str:
    """Strip SQL comments and collapse whitespace."""
    text = _BLOCK_COMMENT.sub(" ", text)
    text = _LINE_COMMENT.sub("", text)
    text = _MULTI_SPACE.sub(" ", text)
    return text


def _find_matching_paren(text: str, start: int) -> int:
    """Return the index of the matching ``)`` for the ``(`` at *start*."""
    depth = 0
    in_single_quote = False
    i = start
    while i < len(text):
        ch = text[i]
        if in_single_quote:
            if ch == "'" and (i + 1 >= len(text) or text[i + 1] != "'"):
                in_single_quote = False
            elif ch == "'" and i + 1 < len(text) and text[i + 1] == "'":
                i += 1
        elif ch == "'":
            in_single_quote = True
        elif ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return -1


def _normalize_identifier(identifier: str) -> str:
    cleaned = identifier.strip().strip('"')
    if "." in cleaned:
        cleaned = cleaned.rsplit(".", 1)[-1]
    return cleaned


def _collect_sql_like_fragments(body: str) -> list[tuple[str, int]]:
    """Return SQL-like fragments from a PL/pgSQL function body."""
    fragments: list[tuple[str, int]] = []

    for match in _DOLLAR_QUOTED_BLOCK.finditer(body):
        sql_text = match.group("body").strip()
        if _SQL_KEYWORD.search(sql_text):
            fragments.append((sql_text, match.start("body")))

    for match in _SINGLE_QUOTED_STRING.finditer(body):
        sql_text = match.group(1).replace("''", "'").strip()
        if _SQL_KEYWORD.search(sql_text):
            fragments.append((sql_text, match.start(1)))

    sanitized = _DOLLAR_QUOTED_BLOCK.sub(" ", body)
    sanitized = _SINGLE_QUOTED_STRING.sub(" ", sanitized)
    for match in _DIRECT_DML_STATEMENT.finditer(sanitized):
        sql_text = match.group(1).strip()
        if _SQL_KEYWORD.search(sql_text):
            fragments.append((sql_text, match.start(1)))

    deduped: list[tuple[str, int]] = []
    seen: set[str] = set()
    for sql_text, offset in fragments:
        key = " ".join(sql_text.split()).lower()
        if not key or key in seen:
            continue
        seen.add(key)
        deduped.append((sql_text, offset))
    return deduped


def _extract_sql_functions(content: str) -> list[dict[str, object]]:
    """Extract PostgreSQL function definitions and inner SQL lineage hints."""
    functions: list[dict[str, object]] = []
    pos = 0
    while match := _CREATE_FUNCTION_HEAD.search(content, pos):
        args_start = match.end() - 1
        args_end = _find_matching_paren(content, args_start)
        if args_end == -1:
            pos = match.end()
            continue

        as_match = _FUNCTION_AS_DOLLAR.search(content, args_end)
        if as_match is None:
            pos = args_end + 1
            continue

        tag = as_match.group("tag")
        body_start = as_match.end("tag")
        body_end = content.find(tag, body_start)
        if body_end == -1:
            pos = args_end + 1
            continue

        statement_end = content.find(";", body_end + len(tag))
        if statement_end == -1:
            statement_end = body_end + len(tag) - 1

        qualified_name = match.group("name")
        function_name = _normalize_identifier(qualified_name)
        statement_text = content[match.start() : statement_end + 1]
        body = content[body_start:body_end]
        start_line = content[: match.start()].count("\n") + 1
        signature = content[match.start() : args_end + 1].strip()
        fragments = _collect_sql_like_fragments(body)
        aggregate_sql = "\n".join(fragment for fragment, _ in fragments)

        functions.append(
            {
                "name": function_name,
                "qualified_name": qualified_name.replace('"', ""),
                "statement_text": statement_text,
                "body": body,
                "start_line": start_line,
                "end_line": content[: statement_end + 1].count("\n") + 1,
                "signature": signature,
                "fragments": fragments,
                "aggregate_sql": aggregate_sql,
                "span": (match.start(), statement_end + 1),
            }
        )
        pos = statement_end + 1

    return functions


def _strip_function_spans(content: str, functions: list[dict[str, object]]) -> str:
    """Replace function bodies with whitespace so other SQL parses cleanly."""
    if not functions:
        return content

    pieces: list[str] = []
    cursor = 0
    for fn in functions:
        start, end = fn["span"]
        pieces.append(content[cursor:start])
        pieces.append("\n" * content[start:end].count("\n"))
        cursor = end
    pieces.append(content[cursor:])
    stripped = "".join(pieces)
    # Remove unsupported admin statements and extension commands
    stripped = _UNSUPPORTED_PG_ADMIN_STATEMENT.sub("\n", stripped)
    stripped = _EXTENSION_STATEMENT.sub("\n", stripped)
    return stripped


def _looks_like_lineage_query(sql: str) -> bool:
    cleaned = _clean_sql(_EXTENSION_STATEMENT.sub("\n", sql)).strip()
    if not cleaned:
        return False
    if _NON_LINEAGE_PREFIX.match(cleaned):
        return False
    return True


# ── CREATE TABLE parser ───────────────────────────────────────────────────────

# Matches:  CREATE [TEMP] TABLE [IF NOT EXISTS] name (  …  )
_CREATE_TABLE = re.compile(
    r"CREATE\s+(?:TEMP(?:ORARY)?\s+)?TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?"
    r"(?:\"?(?P<schema>[a-zA-Z_]\w*)\"?\.)?"          # optional schema prefix
    r"\"?(?P<name>[a-zA-Z_]\w*)\"?\s*"
    r"\((?P<body>[^;]+?)\)\s*(?:;|$)",
    re.IGNORECASE | re.DOTALL,
)

# Column definition inside a CREATE TABLE body.
# Matches: column_name  type  [constraints …]
# Stops at a comma that is not inside parentheses.
_COL_DEF = re.compile(
    r"^\s*(?:\"?(?P<col>[a-zA-Z_]\w*)\"?)\s+(?P<type>[a-zA-Z_]\w+(?:\s*\([^)]*\))?)"
    r"(?P<constraints>[^,]*)?",
    re.IGNORECASE,
)

# Inline or table-level constraint keywords to skip as column names
_CONSTRAINT_KEYWORDS = frozenset(
    {"primary", "unique", "check", "foreign", "constraint", "index", "key"}
)

_SQL_CONSTRAINT_TOKENS = re.compile(
    r"\b(NOT NULL|NULL|PRIMARY KEY|UNIQUE|DEFAULT|REFERENCES|CHECK|AUTO_INCREMENT|AUTOINCREMENT|SERIAL|GENERATED)\b",
    re.IGNORECASE,
)


def _split_top_level_commas(text: str) -> list[str]:
    """Split *text* on commas that are not inside parentheses."""
    parts: list[str] = []
    depth = 0
    current: list[str] = []
    for ch in text:
        if ch == "(":
            depth += 1
            current.append(ch)
        elif ch == ")":
            depth -= 1
            current.append(ch)
        elif ch == "," and depth == 0:
            parts.append("".join(current).strip())
            current = []
        else:
            current.append(ch)
    if current:
        parts.append("".join(current).strip())
    return [p for p in parts if p]


def _parse_columns(body: str) -> list[dict]:
    """Parse column definitions from a CREATE TABLE body."""
    columns: list[dict] = []
    for part in _split_top_level_commas(body):
        part = part.strip()
        if not part:
            continue
        m = _COL_DEF.match(part)
        if m is None:
            continue
        col_name = m.group("col")
        if col_name.lower() in _CONSTRAINT_KEYWORDS:
            continue  # table-level constraint, not a column
        col_type = m.group("type").strip()
        constraints_text = m.group("constraints") or ""
        constraints = [
            tok.upper()
            for tok in _SQL_CONSTRAINT_TOKENS.findall(constraints_text)
        ]
        columns.append(
            {"name": col_name.lower(), "type": col_type, "constraints": constraints}
        )
    return columns


# ── Table reference extractor (for DML queries) ──────────────────────────────

_FROM_CLAUSE = re.compile(
    r"\b(?:FROM|JOIN|INTO|UPDATE)\s+(?:\"?[a-zA-Z_]\w*\"?\.)?"
    r"\"?(?P<table>[a-zA-Z_]\w*)\"?\b",
    re.IGNORECASE,
)
_COLUMN_REF = re.compile(
    r"\b(?:(?P<table>[a-zA-Z_]\w*)\.)?\"?(?P<column>[a-zA-Z_]\w*)\"?\b",
    re.IGNORECASE,
)
_COLUMN_SKIP = frozenset(
    {
        "select",
        "from",
        "where",
        "join",
        "left",
        "right",
        "inner",
        "outer",
        "on",
        "into",
        "update",
        "delete",
        "insert",
        "values",
        "set",
        "and",
        "or",
        "not",
        "null",
        "true",
        "false",
        "count",
        "sum",
        "avg",
        "min",
        "max",
        "distinct",
        "as",
        "case",
        "when",
        "then",
        "else",
        "end",
        "group",
        "order",
        "by",
        "limit",
        "offset",
    }
)


def extract_sql_lineage(sql: str) -> tuple[list[str], list[str]]:
    """Return (tables, columns) referenced in a DML query."""
    if not _looks_like_lineage_query(sql):
        return [], []

    if sqlglot is not None and sqlglot_exp is not None:
        # Strip extension statements before parsing to avoid sqlglot warnings
        cleaned_sql = _EXTENSION_STATEMENT.sub("\n", sql)
        try:
            found_tables: list[str] = []
            found_columns: list[str] = []
            # Use IGNORE error level to suppress warnings about unsupported syntax
            for statement in sqlglot.parse(cleaned_sql, read="postgres", error_level=ErrorLevel.IGNORE if ErrorLevel else None):
                aliases: dict[str, str] = {}
                for table in statement.find_all(sqlglot_exp.Table):
                    name = table.name.lower() if table.name else ""
                    if name:
                        found_tables.append(name)
                        alias = getattr(table, "alias", "") or ""
                        if alias:
                            aliases[str(alias).lower()] = name
                for column in statement.find_all(sqlglot_exp.Column):
                    col_name = column.name.lower() if getattr(column, "name", None) else ""
                    if not col_name or col_name == "*":
                        continue
                    table_name = column.table.lower() if getattr(column, "table", None) else ""
                    if table_name:
                        table_name = aliases.get(table_name, table_name)
                        found_columns.append(f"{table_name}.{col_name}")
                    else:
                        found_columns.append(col_name)
            if found_tables or found_columns:
                tables = list(dict.fromkeys(found_tables))
                columns = _qualify_columns(list(dict.fromkeys(found_columns)), tables)
                return tables, columns
        except Exception:
            pass

    cleaned = _clean_sql(sql)
    found = [m.group("table").lower() for m in _FROM_CLAUSE.finditer(cleaned)]
    # Exclude SQL keywords that look like table names
    _SQL_KEYWORDS = frozenset(
        {"select", "set", "where", "on", "using", "lateral", "values", "returning"}
    )
    tables = [t for t in dict.fromkeys(found) if t not in _SQL_KEYWORDS]

    columns: list[str] = []
    for match in _COLUMN_REF.finditer(cleaned):
        table_name = (match.group("table") or "").lower()
        column_name = (match.group("column") or "").lower()
        if not column_name or column_name in _COLUMN_SKIP or column_name == "*":
            continue
        if table_name and table_name in _COLUMN_SKIP:
            table_name = ""
        columns.append(f"{table_name}.{column_name}" if table_name else column_name)

    return tables, _qualify_columns(list(dict.fromkeys(columns)), tables)


def extract_tables_from_query(sql: str) -> list[str]:
    """Return table names referenced in a DML query (SELECT/INSERT/UPDATE/DELETE)."""
    tables, _ = extract_sql_lineage(sql)
    return tables


def _qualify_columns(columns: list[str], tables: list[str]) -> list[str]:
    if len(tables) != 1:
        return columns
    table_name = tables[0]
    qualified: list[str] = []
    for item in columns:
        if "." in item:
            qualified.append(item)
        else:
            qualified.append(f"{table_name}.{item}")
    return qualified


# ── LanguageParser implementation ─────────────────────────────────────────────


class SqlParser(LanguageParser):
    """Parse .sql files and extract table schema definitions."""

    def parse(self, content: str, file_path: str) -> ParseResult:
        result = ParseResult()
        functions = _extract_sql_functions(content)
        for fn in functions:
            result.symbols.append(
                SymbolInfo(
                    name=str(fn["name"]),
                    kind="function",
                    start_line=int(fn["start_line"]),
                    end_line=int(fn["end_line"]),
                    content=str(fn["statement_text"]),
                    signature=str(fn["signature"]),
                )
            )

            aggregate_sql = str(fn["aggregate_sql"])
            if aggregate_sql.strip():
                collected_tables: list[str] = []
                collected_columns: list[str] = []
                for fragment, _ in fn["fragments"]:
                    tables, columns = extract_sql_lineage(fragment)
                    collected_tables.extend(tables)
                    collected_columns.extend(columns)

                tables = list(dict.fromkeys(collected_tables))
                columns = _qualify_columns(list(dict.fromkeys(collected_columns)), tables)
                if tables or columns:
                    result.sql_queries.append(
                        SqlQueryInfo(
                            sql_text=aggregate_sql,
                            tables_referenced=tables,
                            columns_referenced=columns,
                            line=int(fn["start_line"]),
                            caller_name=str(fn["name"]),
                        )
                    )

        parseable_content = _strip_function_spans(content, functions)
        if sqlglot is not None and sqlglot_exp is not None:
            parsed = self._parse_with_sqlglot(parseable_content, file_path, original_content=content)
            result.db_tables.extend(parsed.db_tables)
            if result.db_tables:
                return result

        cleaned = _clean_sql(parseable_content)
        original_lines = content.splitlines()

        for m in _CREATE_TABLE.finditer(cleaned):
            name = m.group("name").lower()
            body = m.group("body")
            columns = _parse_columns(body)

            # Approximate source line by scanning original content
            line = self._approx_line(content, name)

            result.db_tables.append(
                DbTableInfo(
                    name=name,
                    columns=columns,
                    source_file=file_path,
                    line=line,
                )
            )
            _ = original_lines  # satisfy linter

        return result

    @staticmethod
    def _parse_with_sqlglot(content: str, file_path: str, original_content: str | None = None) -> ParseResult:
        result = ParseResult()
        # Strip extension statements before parsing to avoid sqlglot warnings
        cleaned_content = _EXTENSION_STATEMENT.sub("\n", content)
        try:
            # Use IGNORE error level to suppress warnings about unsupported syntax
            statements = sqlglot.parse(cleaned_content, read="postgres", error_level=ErrorLevel.IGNORE if ErrorLevel else None)
        except Exception:
            return result

        for statement in statements:
            if not isinstance(statement, sqlglot_exp.Create):
                continue
            if str(statement.args.get("kind", "")).upper() != "TABLE":
                continue
            table_expr = statement.this
            table_name = table_expr.name.lower() if getattr(table_expr, "name", None) else ""
            if not table_name:
                continue

            columns: list[dict] = []
            schema = statement.args.get("expression")
            if schema is not None:
                for col_def in schema.find_all(sqlglot_exp.ColumnDef):
                    col_name = col_def.this.name.lower() if getattr(col_def.this, "name", None) else ""
                    if not col_name:
                        continue
                    kind = col_def.args.get("kind")
                    constraints = []
                    for constraint in col_def.args.get("constraints", []) or []:
                        constraint_kind = constraint.args.get("kind")
                        if constraint_kind is not None:
                            constraints.append(constraint_kind.sql().upper())
                    columns.append(
                        {
                            "name": col_name,
                            "type": kind.sql() if kind is not None else "unknown",
                            "constraints": constraints,
                        }
                    )

            result.db_tables.append(
                DbTableInfo(
                    name=table_name,
                    columns=columns,
                    source_file=file_path,
                    line=SqlParser._approx_line(original_content or content, table_name),
                )
            )

        return result

    @staticmethod
    def _approx_line(content: str, table_name: str) -> int:
        """Return the 1-based line number where *table_name* first appears."""
        pat = re.compile(
            rf"\bCREATE\b[^;]*\b{re.escape(table_name)}\b", re.IGNORECASE
        )
        m = pat.search(content)
        if m is None:
            return 1
        return content[: m.start()].count("\n") + 1
