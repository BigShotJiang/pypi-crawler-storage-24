"""Go language parser using tree-sitter.

Extracts functions, methods, structs, interfaces, imports, calls,
type references, and struct embedding from Go source files.
"""

from __future__ import annotations

import tree_sitter_go as tsgo
from tree_sitter import Language, Node, Parser

from logthread.core.parsers.base import (
    CallInfo,
    ImportInfo,
    LanguageParser,
    ParseResult,
    SymbolInfo,
    TypeRef,
)

GO_LANGUAGE = Language(tsgo.language())

_BUILTIN_TYPES: frozenset[str] = frozenset({
    "int", "int8", "int16", "int32", "int64",
    "uint", "uint8", "uint16", "uint32", "uint64",
    "float32", "float64", "complex64", "complex128",
    "string", "bool", "byte", "rune", "error",
    "any", "comparable",
})


class GoParser(LanguageParser):
    """Parses Go source code using tree-sitter."""

    def __init__(self) -> None:
        self._parser = Parser(GO_LANGUAGE)

    def parse(self, content: str, file_path: str) -> ParseResult:
        tree = self._parser.parse(content.encode("utf-8"))
        result = ParseResult()
        self._walk(tree.root_node, content, result)
        return result

    def _walk(self, node: Node, content: str, result: ParseResult) -> None:
        for child in node.children:
            match child.type:
                case "function_declaration":
                    self._extract_function(child, content, result)
                case "method_declaration":
                    self._extract_method(child, content, result)
                case "type_declaration":
                    self._extract_type_declaration(child, content, result)
                case "import_declaration":
                    self._extract_imports(child, result)
                case "call_expression":
                    self._extract_call(child, result)
                case _:
                    self._walk(child, content, result)

    # ---- Functions ----

    def _extract_function(
        self, node: Node, content: str, result: ParseResult
    ) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return

        name = name_node.text.decode("utf-8")
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        node_content = content[node.start_byte : node.end_byte]
        signature = self._build_func_signature(node, name)

        result.symbols.append(
            SymbolInfo(
                name=name,
                kind="function",
                start_line=start_line,
                end_line=end_line,
                content=node_content,
                signature=signature,
            )
        )

        self._extract_func_types(node, result)
        body = node.child_by_field_name("body")
        if body:
            self._extract_calls_recursive(body, result)

    # ---- Methods ----

    def _extract_method(
        self, node: Node, content: str, result: ParseResult
    ) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return

        name = name_node.text.decode("utf-8")
        receiver_name = self._get_receiver_type(node)
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        node_content = content[node.start_byte : node.end_byte]
        signature = self._build_func_signature(node, name)

        result.symbols.append(
            SymbolInfo(
                name=name,
                kind="method",
                start_line=start_line,
                end_line=end_line,
                content=node_content,
                signature=signature,
                class_name=receiver_name,
            )
        )

        self._extract_func_types(node, result)
        body = node.child_by_field_name("body")
        if body:
            self._extract_calls_recursive(body, result)

    def _get_receiver_type(self, method_node: Node) -> str:
        """Extract the receiver type name from a method declaration."""
        receiver = method_node.child_by_field_name("receiver")
        if receiver is None:
            return ""
        # parameter_list -> parameter_declaration -> type
        for child in receiver.children:
            if child.type == "parameter_declaration":
                type_node = child.child_by_field_name("type")
                if type_node is not None:
                    return self._extract_type_identifier(type_node)
        return ""

    # ---- Type declarations ----

    def _extract_type_declaration(
        self, node: Node, content: str, result: ParseResult
    ) -> None:
        """Handle `type X struct { ... }`, `type X interface { ... }`, etc."""
        for child in node.children:
            if child.type == "type_spec":
                self._extract_type_spec(child, content, result)

    def _extract_type_spec(
        self, node: Node, content: str, result: ParseResult
    ) -> None:
        name_node = node.child_by_field_name("name")
        type_node = node.child_by_field_name("type")
        if name_node is None or type_node is None:
            return

        name = name_node.text.decode("utf-8")
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        node_content = content[node.start_byte : node.end_byte]

        if type_node.type == "struct_type":
            result.symbols.append(
                SymbolInfo(
                    name=name, kind="class",
                    start_line=start_line, end_line=end_line,
                    content=node_content,
                )
            )
            self._extract_struct_embeddings(name, type_node, result)
        elif type_node.type == "interface_type":
            result.symbols.append(
                SymbolInfo(
                    name=name, kind="interface",
                    start_line=start_line, end_line=end_line,
                    content=node_content,
                )
            )
            self._extract_interface_embeddings(name, type_node, result)
        else:
            # type alias
            result.symbols.append(
                SymbolInfo(
                    name=name, kind="type_alias",
                    start_line=start_line, end_line=end_line,
                    content=node_content,
                )
            )

    def _extract_struct_embeddings(
        self, struct_name: str, struct_node: Node, result: ParseResult
    ) -> None:
        """Extract embedded structs from field declarations."""
        field_list = struct_node.child_by_field_name("fields") or struct_node
        for child in field_list.children:
            if child.type == "field_declaration":
                # An embedded field has a type but no name
                name_node = child.child_by_field_name("name")
                type_node = child.child_by_field_name("type")
                if type_node is not None:
                    type_name = self._extract_type_identifier(type_node)
                    if type_name and type_name not in _BUILTIN_TYPES:
                        if name_node is None:
                            # Embedded struct
                            result.heritage.append(
                                (struct_name, "extends", type_name)
                            )
                        else:
                            # Typed field — add as type ref
                            result.type_refs.append(
                                TypeRef(
                                    name=type_name,
                                    kind="variable",
                                    line=type_node.start_point[0] + 1,
                                )
                            )

    def _extract_interface_embeddings(
        self, iface_name: str, iface_node: Node, result: ParseResult
    ) -> None:
        """Extract embedded interfaces from an interface type."""
        for child in iface_node.children:
            if child.type == "type_identifier":
                result.heritage.append(
                    (iface_name, "extends", child.text.decode("utf-8"))
                )
            elif child.type == "qualified_type":
                result.heritage.append(
                    (iface_name, "extends", child.text.decode("utf-8"))
                )

    # ---- Imports ----

    def _extract_imports(self, node: Node, result: ParseResult) -> None:
        """Handle import declarations (single and grouped)."""
        for child in node.children:
            if child.type == "import_spec":
                self._extract_import_spec(child, result)
            elif child.type == "import_spec_list":
                for spec in child.children:
                    if spec.type == "import_spec":
                        self._extract_import_spec(spec, result)

    def _extract_import_spec(self, node: Node, result: ParseResult) -> None:
        path_node = node.child_by_field_name("path")
        name_node = node.child_by_field_name("name")

        if path_node is None:
            return

        module = self._string_value(path_node)
        if not module:
            return

        alias = ""
        if name_node is not None:
            alias = name_node.text.decode("utf-8")

        # The imported name is the last segment of the import path
        parts = module.rstrip("/").split("/")
        imported_name = alias if alias and alias != "." else parts[-1]

        result.imports.append(
            ImportInfo(
                module=module,
                names=[imported_name],
                is_relative=module.startswith("."),
                alias=alias,
            )
        )

    # ---- Calls ----

    def _extract_calls_recursive(self, node: Node, result: ParseResult) -> None:
        """Recursively find all call expressions in the AST subtree."""
        if node.type == "call_expression":
            self._extract_call(node, result)

        for child in node.children:
            self._extract_calls_recursive(child, result)

    def _extract_call(self, node: Node, result: ParseResult) -> None:
        func_node = node.child_by_field_name("function")
        if func_node is None:
            return

        line = node.start_point[0] + 1
        arguments = self._extract_identifier_arguments(node)

        if func_node.type == "identifier":
            result.calls.append(
                CallInfo(
                    name=func_node.text.decode("utf-8"),
                    line=line,
                    arguments=arguments,
                )
            )
        elif func_node.type == "selector_expression":
            field = func_node.child_by_field_name("field")
            operand = func_node.child_by_field_name("operand")
            if field is not None:
                receiver = ""
                if operand is not None:
                    receiver = self._root_identifier(operand)
                result.calls.append(
                    CallInfo(
                        name=field.text.decode("utf-8"),
                        line=line,
                        receiver=receiver,
                        arguments=arguments,
                    )
                )

    # ---- Type references ----

    def _extract_func_types(self, func_node: Node, result: ParseResult) -> None:
        """Extract parameter and return types from a function."""
        params = func_node.child_by_field_name("parameters")
        if params:
            for child in params.children:
                if child.type == "parameter_declaration":
                    type_node = child.child_by_field_name("type")
                    name_node = child.child_by_field_name("name")
                    if type_node:
                        type_name = self._extract_type_identifier(type_node)
                        if type_name and type_name not in _BUILTIN_TYPES:
                            param_name = ""
                            if name_node:
                                param_name = name_node.text.decode("utf-8")
                            result.type_refs.append(
                                TypeRef(
                                    name=type_name,
                                    kind="param",
                                    line=type_node.start_point[0] + 1,
                                    param_name=param_name,
                                )
                            )

        # Return type
        ret = func_node.child_by_field_name("result")
        if ret:
            type_name = self._extract_type_identifier(ret)
            if type_name and type_name not in _BUILTIN_TYPES:
                result.type_refs.append(
                    TypeRef(
                        name=type_name,
                        kind="return",
                        line=ret.start_point[0] + 1,
                    )
                )

    # ---- Helpers ----

    def _build_func_signature(self, node: Node, name: str) -> str:
        """Build func name(params) return_type."""
        params = node.child_by_field_name("parameters")
        result_node = node.child_by_field_name("result")
        sig = f"func {name}"
        if params:
            sig += params.text.decode("utf-8")
        if result_node:
            sig += " " + result_node.text.decode("utf-8")
        return sig

    @staticmethod
    def _extract_type_identifier(type_node: Node) -> str:
        """Extract a type name from a type node, handling pointers and slices."""
        if type_node.type == "type_identifier":
            return type_node.text.decode("utf-8")
        if type_node.type == "qualified_type":
            # pkg.Type — return just Type
            field = type_node.child_by_field_name("name")
            if field:
                return field.text.decode("utf-8")
            return type_node.text.decode("utf-8")
        if type_node.type == "pointer_type":
            inner = type_node.child_by_field_name("type") or (
                type_node.children[-1] if type_node.children else None
            )
            if inner:
                return GoParser._extract_type_identifier(inner)
        if type_node.type == "slice_type":
            element = type_node.child_by_field_name("element")
            if element:
                return GoParser._extract_type_identifier(element)
        if type_node.type == "parameter_list":
            # func return (Type, error) — return first non-builtin type
            for child in type_node.children:
                if child.type == "parameter_declaration":
                    t = child.child_by_field_name("type")
                    if t:
                        name = GoParser._extract_type_identifier(t)
                        if name and name not in _BUILTIN_TYPES:
                            return name
        # Fallback: first type_identifier descendant
        return GoParser._find_first_type_identifier(type_node)

    @staticmethod
    def _find_first_type_identifier(node: Node) -> str:
        if node.type == "type_identifier":
            return node.text.decode("utf-8")
        for child in node.children:
            found = GoParser._find_first_type_identifier(child)
            if found:
                return found
        return ""

    @staticmethod
    def _extract_identifier_arguments(call_node: Node) -> list[str]:
        args_node = call_node.child_by_field_name("arguments")
        if args_node is None:
            return []
        identifiers: list[str] = []
        for child in args_node.children:
            if child.type == "identifier":
                identifiers.append(child.text.decode("utf-8"))
        return identifiers

    @staticmethod
    def _root_identifier(node: Node) -> str:
        current = node
        while current is not None:
            if current.type == "identifier":
                return current.text.decode("utf-8")
            if current.children:
                current = current.children[0]
            else:
                break
        return ""

    @staticmethod
    def _string_value(string_node: Node) -> str:
        text = string_node.text.decode("utf-8")
        if len(text) >= 2 and text[0] == '"' and text[-1] == '"':
            return text[1:-1]
        if len(text) >= 2 and text[0] == '`' and text[-1] == '`':
            return text[1:-1]
        return text
