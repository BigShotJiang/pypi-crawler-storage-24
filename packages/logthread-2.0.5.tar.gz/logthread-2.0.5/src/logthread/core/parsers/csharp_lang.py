"""C# language parser using tree-sitter.

Extracts classes, interfaces, enums, structs, methods, using directives,
invocations, type references, and inheritance from C# source files.
"""

from __future__ import annotations

import tree_sitter_c_sharp as tscsharp
from tree_sitter import Language, Node, Parser

from logthread.core.parsers.base import (
    CallInfo,
    ImportInfo,
    LanguageParser,
    ParseResult,
    SymbolInfo,
    TypeRef,
)

CSHARP_LANGUAGE = Language(tscsharp.language())

_BUILTIN_TYPES: frozenset[str] = frozenset({
    "int", "long", "short", "byte", "float", "double",
    "decimal", "char", "bool", "string", "void", "object",
    "dynamic", "var", "nint", "nuint",
})

# Node types that declare a class-like construct
_CLASS_LIKE_TYPES = frozenset({
    "class_declaration",
    "record_declaration",
    "struct_declaration",
})


class CSharpParser(LanguageParser):
    """Parses C# source code using tree-sitter."""

    def __init__(self) -> None:
        self._parser = Parser(CSHARP_LANGUAGE)

    def parse(self, content: str, file_path: str) -> ParseResult:
        tree = self._parser.parse(content.encode("utf-8"))
        result = ParseResult()
        self._walk(tree.root_node, content, result, class_name="")
        return result

    def _walk(
        self, node: Node, content: str, result: ParseResult, class_name: str,
    ) -> None:
        for child in node.children:
            ntype = child.type

            if ntype in _CLASS_LIKE_TYPES:
                self._extract_class(child, content, result)
            elif ntype == "interface_declaration":
                self._extract_interface(child, content, result)
            elif ntype == "enum_declaration":
                self._extract_enum(child, content, result)
            elif ntype == "method_declaration":
                self._extract_method(child, content, result, class_name)
            elif ntype == "constructor_declaration":
                self._extract_constructor(child, content, result, class_name)
            elif ntype == "using_directive":
                self._extract_using(child, result)
            elif ntype == "invocation_expression":
                self._extract_call(child, result)
            elif ntype == "object_creation_expression":
                self._extract_new(child, result)
            elif ntype == "namespace_declaration" or ntype == "file_scoped_namespace_declaration":
                # Walk into namespace body
                self._walk(child, content, result, class_name)
            elif ntype == "declaration_list":
                self._walk(child, content, result, class_name)
            else:
                self._walk(child, content, result, class_name)

    # ---- Classes / Structs / Records ----

    def _extract_class(
        self, node: Node, content: str, result: ParseResult,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return

        name = name_node.text.decode("utf-8")
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        node_content = content[node.start_byte : node.end_byte]

        kind = "class"
        if node.type == "struct_declaration":
            kind = "class"  # structs map to "class" in our model

        result.symbols.append(
            SymbolInfo(
                name=name, kind=kind,
                start_line=start_line, end_line=end_line,
                content=node_content,
            )
        )

        # Heritage: base_list contains extends and implements
        self._extract_base_list(name, node, result)

        body = node.child_by_field_name("body")
        if body:
            self._walk(body, content, result, class_name=name)
            self._extract_calls_recursive(body, result)

    # ---- Interfaces ----

    def _extract_interface(
        self, node: Node, content: str, result: ParseResult,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return

        name = name_node.text.decode("utf-8")
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        node_content = content[node.start_byte : node.end_byte]

        result.symbols.append(
            SymbolInfo(
                name=name, kind="interface",
                start_line=start_line, end_line=end_line,
                content=node_content,
            )
        )

        self._extract_base_list(name, node, result)

        body = node.child_by_field_name("body")
        if body:
            self._walk(body, content, result, class_name=name)

    # ---- Enums ----

    def _extract_enum(
        self, node: Node, content: str, result: ParseResult,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return

        name = name_node.text.decode("utf-8")
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        node_content = content[node.start_byte : node.end_byte]

        result.symbols.append(
            SymbolInfo(
                name=name, kind="enum",
                start_line=start_line, end_line=end_line,
                content=node_content,
            )
        )

    # ---- Methods ----

    def _extract_method(
        self, node: Node, content: str, result: ParseResult, class_name: str,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return

        name = name_node.text.decode("utf-8")
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        node_content = content[node.start_byte : node.end_byte]
        signature = self._build_method_signature(node, name)

        kind = "method" if class_name else "function"

        result.symbols.append(
            SymbolInfo(
                name=name, kind=kind,
                start_line=start_line, end_line=end_line,
                content=node_content,
                signature=signature,
                class_name=class_name,
            )
        )

        self._extract_method_types(node, result)

    def _extract_constructor(
        self, node: Node, content: str, result: ParseResult, class_name: str,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return

        name = name_node.text.decode("utf-8")
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        node_content = content[node.start_byte : node.end_byte]
        signature = self._build_method_signature(node, name)

        result.symbols.append(
            SymbolInfo(
                name=name, kind="method",
                start_line=start_line, end_line=end_line,
                content=node_content,
                signature=signature,
                class_name=class_name,
            )
        )

    # ---- Heritage ----

    def _extract_base_list(
        self, type_name: str, node: Node, result: ParseResult,
    ) -> None:
        """Extract base types from the : base_list after a class/struct/interface name."""
        for child in node.children:
            if child.type == "base_list":
                for base_child in child.children:
                    if base_child.type in (
                        "identifier", "generic_name",
                        "qualified_name",
                    ):
                        parent = self._extract_type_name_from_node(base_child)
                        if parent:
                            # In C#, first base type could be class or interface
                            # We just record "extends" for all
                            result.heritage.append(
                                (type_name, "extends", parent)
                            )
                    # Handle predefined_type and other type nodes
                    elif base_child.is_named and base_child.type not in (
                        ",", ":", "comment"
                    ):
                        parent = self._extract_type_name_from_node(base_child)
                        if parent and parent not in _BUILTIN_TYPES:
                            result.heritage.append(
                                (type_name, "extends", parent)
                            )

    # ---- Using / Imports ----

    def _extract_using(self, node: Node, result: ParseResult) -> None:
        """Handle `using System.Collections.Generic;`."""
        for child in node.children:
            if child.type in ("qualified_name", "identifier"):
                full_path = child.text.decode("utf-8")
                parts = full_path.split(".")
                module = ".".join(parts[:-1]) if len(parts) > 1 else full_path
                name = parts[-1]
                result.imports.append(
                    ImportInfo(
                        module=module,
                        names=[name],
                        is_relative=False,
                    )
                )
                break
            elif child.type == "using_directive":
                # Nested — recurse
                self._extract_using(child, result)

    # ---- Calls ----

    def _extract_calls_recursive(self, node: Node, result: ParseResult) -> None:
        if node.type == "invocation_expression":
            self._extract_call(node, result)
        elif node.type == "object_creation_expression":
            self._extract_new(node, result)

        for child in node.children:
            self._extract_calls_recursive(child, result)

    def _extract_call(self, node: Node, result: ParseResult) -> None:
        func_node = node.child_by_field_name("function")
        if func_node is None:
            # Sometimes the first child is the function
            if node.children:
                func_node = node.children[0]
        if func_node is None:
            return

        line = node.start_point[0] + 1
        arguments = self._extract_identifier_arguments(node)

        if func_node.type == "member_access_expression":
            name_node = func_node.child_by_field_name("name")
            expr_node = func_node.child_by_field_name("expression")
            if name_node:
                receiver = ""
                if expr_node:
                    receiver = self._root_identifier(expr_node)
                result.calls.append(
                    CallInfo(
                        name=name_node.text.decode("utf-8"),
                        line=line,
                        receiver=receiver,
                        arguments=arguments,
                    )
                )
        elif func_node.type == "identifier":
            result.calls.append(
                CallInfo(
                    name=func_node.text.decode("utf-8"),
                    line=line,
                    arguments=arguments,
                )
            )
        elif func_node.type == "generic_name":
            ident = func_node.child_by_field_name("name")
            if ident:
                result.calls.append(
                    CallInfo(
                        name=ident.text.decode("utf-8"),
                        line=line,
                        arguments=arguments,
                    )
                )

    def _extract_new(self, node: Node, result: ParseResult) -> None:
        type_node = node.child_by_field_name("type")
        if type_node is None:
            return

        type_name = self._extract_type_name_from_node(type_node)
        if not type_name:
            return

        line = node.start_point[0] + 1
        arguments = self._extract_identifier_arguments(node)

        result.calls.append(
            CallInfo(
                name=type_name,
                line=line,
                arguments=arguments,
            )
        )

    # ---- Type references ----

    def _extract_method_types(self, node: Node, result: ParseResult) -> None:
        # Return type
        ret_type = node.child_by_field_name("type")
        if ret_type:
            type_name = self._extract_type_name_from_node(ret_type)
            if type_name and type_name not in _BUILTIN_TYPES:
                result.type_refs.append(
                    TypeRef(
                        name=type_name,
                        kind="return",
                        line=ret_type.start_point[0] + 1,
                    )
                )

        # Parameters
        params = node.child_by_field_name("parameters")
        if params:
            for child in params.children:
                if child.type == "parameter":
                    type_node = child.child_by_field_name("type")
                    name_node = child.child_by_field_name("name")
                    if type_node:
                        type_name = self._extract_type_name_from_node(type_node)
                        if type_name and type_name not in _BUILTIN_TYPES:
                            param_name = ""
                            if name_node:
                                param_name = name_node.text.decode("utf-8")
                            result.type_refs.append(
                                TypeRef(
                                    name=type_name,
                                    kind="param",
                                    line=type_node.start_point[0] + 1,
                                    param_name=param_name,
                                )
                            )

    # ---- Helpers ----

    @staticmethod
    def _extract_type_name_from_node(node: Node) -> str:
        """Extract the primary type name from a type node."""
        if node.type in ("identifier", "type_identifier"):
            return node.text.decode("utf-8")
        if node.type == "generic_name":
            ident = node.child_by_field_name("name")
            if ident:
                return ident.text.decode("utf-8")
        if node.type == "qualified_name":
            parts = node.text.decode("utf-8").split(".")
            return parts[-1]
        if node.type == "predefined_type":
            return node.text.decode("utf-8")
        if node.type == "nullable_type":
            for child in node.children:
                if child.type != "?":
                    return CSharpParser._extract_type_name_from_node(child)
        if node.type == "array_type":
            for child in node.children:
                name = CSharpParser._extract_type_name_from_node(child)
                if name:
                    return name
        # Fallback
        for child in node.children:
            if child.type in ("identifier", "type_identifier", "generic_name"):
                return CSharpParser._extract_type_name_from_node(child)
        return ""

    def _build_method_signature(self, node: Node, name: str) -> str:
        params = node.child_by_field_name("parameters")
        ret_type = node.child_by_field_name("type")
        sig = ""
        if ret_type:
            sig += ret_type.text.decode("utf-8") + " "
        sig += name
        if params:
            sig += params.text.decode("utf-8")
        return sig

    @staticmethod
    def _extract_identifier_arguments(node: Node) -> list[str]:
        args_node = node.child_by_field_name("arguments")
        if args_node is None:
            # Try argument_list
            for child in node.children:
                if child.type == "argument_list":
                    args_node = child
                    break
        if args_node is None:
            return []
        identifiers: list[str] = []
        for child in args_node.children:
            if child.type == "identifier":
                identifiers.append(child.text.decode("utf-8"))
            elif child.type == "argument":
                for sub in child.children:
                    if sub.type == "identifier":
                        identifiers.append(sub.text.decode("utf-8"))
        return identifiers

    @staticmethod
    def _root_identifier(node: Node) -> str:
        current = node
        while current is not None:
            if current.type == "identifier":
                return current.text.decode("utf-8")
            if current.children:
                current = current.children[0]
            else:
                break
        return ""
