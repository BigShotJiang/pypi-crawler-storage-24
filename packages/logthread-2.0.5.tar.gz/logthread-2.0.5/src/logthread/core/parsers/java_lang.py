"""Java language parser using tree-sitter.

Extracts classes, interfaces, enums, methods, imports, calls,
type references, and extends/implements heritage from Java source files.
"""

from __future__ import annotations

import tree_sitter_java as tsjava
from tree_sitter import Language, Node, Parser

from logthread.core.parsers.base import (
    CallInfo,
    ImportInfo,
    LanguageParser,
    ParseResult,
    SymbolInfo,
    TypeRef,
)

JAVA_LANGUAGE = Language(tsjava.language())

_BUILTIN_TYPES: frozenset[str] = frozenset({
    "int", "long", "short", "byte", "float", "double",
    "char", "boolean", "void", "String", "Object",
    "Integer", "Long", "Short", "Byte", "Float", "Double",
    "Character", "Boolean", "Void",
})


class JavaParser(LanguageParser):
    """Parses Java source code using tree-sitter."""

    def __init__(self) -> None:
        self._parser = Parser(JAVA_LANGUAGE)

    def parse(self, content: str, file_path: str) -> ParseResult:
        tree = self._parser.parse(content.encode("utf-8"))
        result = ParseResult()
        self._walk(tree.root_node, content, result, class_name="")
        return result

    def _walk(
        self, node: Node, content: str, result: ParseResult, class_name: str,
    ) -> None:
        for child in node.children:
            match child.type:
                case "class_declaration":
                    self._extract_class(child, content, result)
                case "interface_declaration":
                    self._extract_interface(child, content, result)
                case "enum_declaration":
                    self._extract_enum(child, content, result)
                case "method_declaration":
                    self._extract_method(child, content, result, class_name)
                case "constructor_declaration":
                    self._extract_constructor(child, content, result, class_name)
                case "import_declaration":
                    self._extract_import(child, result)
                case "method_invocation":
                    self._extract_call(child, result)
                case "object_creation_expression":
                    self._extract_new(child, result)
                case _:
                    self._walk(child, content, result, class_name)

    # ---- Classes ----

    def _extract_class(
        self, node: Node, content: str, result: ParseResult
    ) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return

        name = name_node.text.decode("utf-8")
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        node_content = content[node.start_byte : node.end_byte]

        decorators = self._extract_annotations(node)

        result.symbols.append(
            SymbolInfo(
                name=name, kind="class",
                start_line=start_line, end_line=end_line,
                content=node_content,
                decorators=decorators,
            )
        )

        # Heritage: extends
        superclass = node.child_by_field_name("superclass")
        if superclass:
            parent_name = self._extract_type_name(superclass)
            if parent_name:
                result.heritage.append((name, "extends", parent_name))

        # Heritage: implements
        interfaces = node.child_by_field_name("interfaces")
        if interfaces:
            for child in interfaces.children:
                if child.type == "type_identifier" or child.type == "generic_type":
                    iface_name = self._extract_type_name(child)
                    if iface_name:
                        result.heritage.append((name, "implements", iface_name))

        # Walk class body
        body = node.child_by_field_name("body")
        if body:
            self._walk(body, content, result, class_name=name)
            self._extract_calls_recursive(body, result)

    # ---- Interfaces ----

    def _extract_interface(
        self, node: Node, content: str, result: ParseResult
    ) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return

        name = name_node.text.decode("utf-8")
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        node_content = content[node.start_byte : node.end_byte]

        decorators = self._extract_annotations(node)

        result.symbols.append(
            SymbolInfo(
                name=name, kind="interface",
                start_line=start_line, end_line=end_line,
                content=node_content,
                decorators=decorators,
            )
        )

        # extends (interfaces can extend other interfaces)
        extends = node.child_by_field_name("extends")
        if extends is None:
            # Sometimes it's under "interfaces" for extends_interfaces
            for child in node.children:
                if child.type == "extends_interfaces":
                    extends = child
                    break

        if extends:
            for child in extends.children:
                if child.type in ("type_identifier", "generic_type"):
                    parent_name = self._extract_type_name(child)
                    if parent_name:
                        result.heritage.append((name, "extends", parent_name))

        body = node.child_by_field_name("body")
        if body:
            self._walk(body, content, result, class_name=name)

    # ---- Enums ----

    def _extract_enum(
        self, node: Node, content: str, result: ParseResult
    ) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return

        name = name_node.text.decode("utf-8")
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        node_content = content[node.start_byte : node.end_byte]

        result.symbols.append(
            SymbolInfo(
                name=name, kind="enum",
                start_line=start_line, end_line=end_line,
                content=node_content,
            )
        )

        body = node.child_by_field_name("body")
        if body:
            self._walk(body, content, result, class_name=name)

    # ---- Methods ----

    def _extract_method(
        self, node: Node, content: str, result: ParseResult, class_name: str,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return

        name = name_node.text.decode("utf-8")
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        node_content = content[node.start_byte : node.end_byte]
        signature = self._build_method_signature(node, name)
        decorators = self._extract_annotations(node)

        kind = "method" if class_name else "function"

        result.symbols.append(
            SymbolInfo(
                name=name, kind=kind,
                start_line=start_line, end_line=end_line,
                content=node_content,
                signature=signature,
                class_name=class_name,
                decorators=decorators,
            )
        )

        self._extract_method_types(node, name, result)

    def _extract_constructor(
        self, node: Node, content: str, result: ParseResult, class_name: str,
    ) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return

        name = name_node.text.decode("utf-8")
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        node_content = content[node.start_byte : node.end_byte]
        signature = self._build_method_signature(node, name)

        result.symbols.append(
            SymbolInfo(
                name=name, kind="method",
                start_line=start_line, end_line=end_line,
                content=node_content,
                signature=signature,
                class_name=class_name,
            )
        )

    # ---- Imports ----

    def _extract_import(self, node: Node, result: ParseResult) -> None:
        """Handle import declarations like `import java.util.List;`."""
        is_static = False
        for child in node.children:
            if child.type == "static":
                is_static = True

        # Get the scoped_identifier or identifier
        for child in node.children:
            if child.type in ("scoped_identifier", "identifier"):
                full_path = child.text.decode("utf-8")
                parts = full_path.split(".")
                module = ".".join(parts[:-1]) if len(parts) > 1 else full_path
                name = parts[-1]

                result.imports.append(
                    ImportInfo(
                        module=module,
                        names=[name],
                        is_relative=False,
                    )
                )
                break
            elif child.type == "asterisk":
                # import java.util.*
                # Find the scoped_identifier before the asterisk
                for sibling in node.children:
                    if sibling.type == "scoped_identifier":
                        module = sibling.text.decode("utf-8")
                        result.imports.append(
                            ImportInfo(
                                module=module,
                                names=["*"],
                                is_relative=False,
                            )
                        )
                        break

    # ---- Calls ----

    def _extract_calls_recursive(self, node: Node, result: ParseResult) -> None:
        if node.type == "method_invocation":
            self._extract_call(node, result)
        elif node.type == "object_creation_expression":
            self._extract_new(node, result)

        for child in node.children:
            self._extract_calls_recursive(child, result)

    def _extract_call(self, node: Node, result: ParseResult) -> None:
        name_node = node.child_by_field_name("name")
        obj_node = node.child_by_field_name("object")

        if name_node is None:
            return

        name = name_node.text.decode("utf-8")
        line = node.start_point[0] + 1
        receiver = ""
        if obj_node:
            receiver = self._root_identifier(obj_node)
        arguments = self._extract_identifier_arguments(node)

        result.calls.append(
            CallInfo(
                name=name,
                line=line,
                receiver=receiver,
                arguments=arguments,
            )
        )

    def _extract_new(self, node: Node, result: ParseResult) -> None:
        """Handle `new ClassName(args)`."""
        type_node = node.child_by_field_name("type")
        if type_node is None:
            return

        type_name = self._extract_type_name(type_node)
        if not type_name:
            return

        line = node.start_point[0] + 1
        arguments = self._extract_identifier_arguments(node)

        result.calls.append(
            CallInfo(
                name=type_name,
                line=line,
                arguments=arguments,
            )
        )

    # ---- Type references ----

    def _extract_method_types(
        self, node: Node, method_name: str, result: ParseResult
    ) -> None:
        """Extract parameter types and return type from a method."""
        # Parameters
        params = node.child_by_field_name("parameters")
        if params:
            for child in params.children:
                if child.type == "formal_parameter":
                    type_node = child.child_by_field_name("type")
                    name_node = child.child_by_field_name("name")
                    if type_node:
                        type_name = self._extract_type_name(type_node)
                        if type_name and type_name not in _BUILTIN_TYPES:
                            param_name = ""
                            if name_node:
                                param_name = name_node.text.decode("utf-8")
                            result.type_refs.append(
                                TypeRef(
                                    name=type_name,
                                    kind="param",
                                    line=type_node.start_point[0] + 1,
                                    param_name=param_name,
                                )
                            )

        # Return type
        ret_type = node.child_by_field_name("type")
        if ret_type:
            type_name = self._extract_type_name(ret_type)
            if type_name and type_name not in _BUILTIN_TYPES:
                result.type_refs.append(
                    TypeRef(
                        name=type_name,
                        kind="return",
                        line=ret_type.start_point[0] + 1,
                    )
                )

    # ---- Helpers ----

    @staticmethod
    def _extract_annotations(node: Node) -> list[str]:
        """Extract annotation names from a declaration."""
        annotations: list[str] = []
        for child in node.children:
            if child.type == "marker_annotation":
                name_node = child.child_by_field_name("name")
                if name_node:
                    annotations.append(name_node.text.decode("utf-8"))
            elif child.type == "annotation":
                name_node = child.child_by_field_name("name")
                if name_node:
                    annotations.append(name_node.text.decode("utf-8"))
            elif child.type == "modifiers":
                for sub in child.children:
                    if sub.type in ("marker_annotation", "annotation"):
                        name_node = sub.child_by_field_name("name")
                        if name_node:
                            annotations.append(name_node.text.decode("utf-8"))
        return annotations

    @staticmethod
    def _extract_type_name(type_node: Node) -> str:
        """Extract the primary type name from a type node."""
        if type_node.type == "type_identifier":
            return type_node.text.decode("utf-8")
        if type_node.type == "generic_type":
            for child in type_node.children:
                if child.type == "type_identifier":
                    return child.text.decode("utf-8")
        if type_node.type == "scoped_type_identifier":
            # e.g., Map.Entry -> Entry
            name = type_node.child_by_field_name("name")
            if name:
                return name.text.decode("utf-8")
        if type_node.type == "array_type":
            element = type_node.child_by_field_name("element")
            if element:
                return JavaParser._extract_type_name(element)
        # Fallback
        for child in type_node.children:
            if child.type == "type_identifier":
                return child.text.decode("utf-8")
        return ""

    def _build_method_signature(self, node: Node, name: str) -> str:
        params = node.child_by_field_name("parameters")
        ret_type = node.child_by_field_name("type")
        sig = ""
        if ret_type:
            sig += ret_type.text.decode("utf-8") + " "
        sig += name
        if params:
            sig += params.text.decode("utf-8")
        return sig

    @staticmethod
    def _extract_identifier_arguments(call_node: Node) -> list[str]:
        args_node = call_node.child_by_field_name("arguments")
        if args_node is None:
            return []
        identifiers: list[str] = []
        for child in args_node.children:
            if child.type == "identifier":
                identifiers.append(child.text.decode("utf-8"))
        return identifiers

    @staticmethod
    def _root_identifier(node: Node) -> str:
        current = node
        while current is not None:
            if current.type == "identifier":
                return current.text.decode("utf-8")
            if current.children:
                current = current.children[0]
            else:
                break
        return ""
