"""Framework-specific adapters for route and entry-point discovery."""

from .adapters import apply_framework_adapters

__all__ = ["apply_framework_adapters"]
