"""Framework adapters that enrich ParseResult with ecosystem-specific routes.

These adapters are intentionally heuristic rather than compiler-perfect.
They close the biggest product gap first: discovering entry points in the
frameworks developers actually use, even when the base language parser only
knows syntax-level symbols.
"""

from __future__ import annotations

import re

from logthread.core.parsers.base import ApiEndpointInfo, ParseResult

_HTTP_METHODS = {"get", "post", "put", "patch", "delete", "options", "head", "any", "use", "all"}


def apply_framework_adapters(
    language: str,
    file_path: str,
    content: str,
    result: ParseResult,
) -> None:
    if language in {"javascript", "typescript", "tsx"}:
        _adapt_nest_routes(content, result)
        _adapt_angular_routes(content, result)
    elif language == "python":
        _adapt_django_routes(content, result)
    elif language == "java":
        _adapt_spring_routes(content, result)
    elif language == "csharp":
        _adapt_aspnet_routes(content, result)
    elif language == "go":
        _adapt_gin_routes(content, result)
    elif language == "ruby":
        _adapt_rails_routes(content, result)
    elif language == "php":
        _adapt_laravel_routes(content, result)
    elif language == "rust":
        _adapt_rust_routes(content, result)

    result.api_endpoints = _dedupe_api_endpoints(result.api_endpoints)


def _dedupe_api_endpoints(endpoints: list[ApiEndpointInfo]) -> list[ApiEndpointInfo]:
    seen: set[tuple[str, str, tuple[str, ...], int, str]] = set()
    deduped: list[ApiEndpointInfo] = []
    for endpoint in endpoints:
        key = (
            endpoint.method,
            endpoint.path,
            tuple(endpoint.handler_names),
            endpoint.line,
            endpoint.framework,
        )
        if key in seen:
            continue
        seen.add(key)
        deduped.append(endpoint)
    return deduped


def _append_endpoint(
    result: ParseResult,
    *,
    method: str,
    path: str,
    handlers: list[str],
    line: int,
    framework: str,
) -> None:
    path = _normalize_path(path)
    handlers = [handler for handler in handlers if handler]
    if not path:
        return
    result.api_endpoints.append(
        ApiEndpointInfo(
            method=method.upper(),
            path=path,
            handler_names=handlers,
            line=max(1, line),
            framework=framework,
        )
    )


def _normalize_path(path: str) -> str:
    raw = str(path or "").strip()
    if not raw:
        return "/"
    raw = raw.strip("`").strip()
    if raw.startswith(("'", '"')) and raw.endswith(("'", '"')) and len(raw) >= 2:
        raw = raw[1:-1]
    raw = raw.strip()
    raw = raw or "/"
    if not raw.startswith("/"):
        raw = "/" + raw
    raw = re.sub(r"/{2,}", "/", raw)
    return raw


def _join_path(*parts: str) -> str:
    path = "/".join(part.strip("/") for part in parts if part and part.strip("/"))
    return _normalize_path(path or "/")


def _extract_first_string(raw: str) -> str:
    match = re.search(r"""['"]([^'"]*)['"]""", raw or "")
    return match.group(1) if match else ""


def _line_for_offset(content: str, offset: int) -> int:
    return content[:offset].count("\n") + 1


def _identifiers_from_args(raw: str) -> list[str]:
    return re.findall(r"\b([A-Z_a-z][A-Z_a-z0-9]*)\b", raw or "")


def _camelize(name: str) -> str:
    return "".join(part[:1].upper() + part[1:] for part in re.split(r"[_/]", name) if part)


def _adapt_nest_routes(content: str, result: ParseResult) -> None:
    pending_controller = ""
    pending_http: tuple[str, str] | None = None
    pending_guards: list[str] = []
    current_class = ""
    current_base = ""
    class_depth = 0

    for line_no, line in enumerate(content.splitlines(), start=1):
        ctrl_match = re.search(r"@Controller\(([^)]*)\)", line)
        if ctrl_match:
            pending_controller = _extract_first_string(ctrl_match.group(1))
            continue

        guard_match = re.search(r"@Use(?:Guards|Interceptors|Pipes)\(([^)]*)\)", line)
        if guard_match:
            pending_guards.extend(_identifiers_from_args(guard_match.group(1)))
            continue

        http_match = re.search(
            r"@(Get|Post|Put|Patch|Delete|Options|Head|All)\(([^)]*)\)",
            line,
        )
        if http_match:
            pending_http = (http_match.group(1).upper(), _extract_first_string(http_match.group(2)))
            continue

        class_match = re.search(r"\bclass\s+([A-Z][A-Za-z0-9_]*)\b", line)
        if class_match:
            current_class = class_match.group(1)
            current_base = pending_controller
            pending_controller = ""
            class_depth = line.count("{") - line.count("}")
            continue

        if current_class:
            class_depth += line.count("{") - line.count("}")
            if pending_http:
                method_match = re.search(
                    r"^\s*(?:public|private|protected|static|async|readonly|\s)*([A-Za-z_][A-Za-z0-9_]*)\s*\(",
                    line,
                )
                if method_match:
                    method_name = method_match.group(1)
                    _append_endpoint(
                        result,
                        method=pending_http[0],
                        path=_join_path(current_base, pending_http[1]),
                        handlers=pending_guards + [f"{current_class}.{method_name}"],
                        line=line_no,
                        framework="nest",
                    )
                    pending_http = None
                    pending_guards = []
            if class_depth <= 0:
                current_class = ""
                current_base = ""
                pending_http = None
                pending_guards = []


def _adapt_angular_routes(content: str, result: ParseResult) -> None:
    pattern = re.compile(
        r"path\s*:\s*['\"]([^'\"]*)['\"][\s\S]{0,240}?"
        r"(?:component\s*:\s*([A-Z][A-Za-z0-9_]*)|loadComponent\s*:\s*[\s\S]{0,160}?\.([A-Z][A-Za-z0-9_]*))",
        re.MULTILINE,
    )
    for match in pattern.finditer(content):
        component = match.group(2) or match.group(3) or ""
        if not component:
            continue
        _append_endpoint(
            result,
            method="VIEW",
            path=match.group(1) or "/",
            handlers=[component],
            line=_line_for_offset(content, match.start()),
            framework="angular",
        )


def _adapt_django_routes(content: str, result: ParseResult) -> None:
    path_pattern = re.compile(
        r"\b(?:path|re_path)\(\s*(?:r)?['\"]([^'\"]*)['\"]\s*,\s*([^,\n)]+)",
    )
    for match in path_pattern.finditer(content):
        target = match.group(2).strip()
        handler = ""
        if "include(" in target:
            include_match = re.search(r"include\(\s*['\"]([^'\"]+)['\"]", target)
            handler = include_match.group(1) if include_match else target
        elif ".as_view()" in target:
            handler = target.split(".as_view()", 1)[0].strip()
        else:
            handler = re.sub(r"[^\w.]+$", "", target)
        _append_endpoint(
            result,
            method="ANY",
            path=match.group(1) or "/",
            handlers=[handler],
            line=_line_for_offset(content, match.start()),
            framework="django",
        )


def _adapt_spring_routes(content: str, result: ParseResult) -> None:
    pending_base = ""
    pending_http: tuple[str, str] | None = None
    current_class = ""
    current_base = ""
    class_depth = 0

    for line_no, line in enumerate(content.splitlines(), start=1):
        base_match = re.search(r"@RequestMapping\(([^)]*)\)", line)
        if base_match and not current_class:
            pending_base = _extract_first_string(base_match.group(1))
            continue

        http_match = re.search(
            r"@(GetMapping|PostMapping|PutMapping|PatchMapping|DeleteMapping|RequestMapping)\(([^)]*)\)",
            line,
        )
        if http_match:
            anno = http_match.group(1)
            raw_args = http_match.group(2)
            path = _extract_first_string(raw_args)
            method = "ANY"
            if anno != "RequestMapping":
                method = anno.replace("Mapping", "").replace("Get", "GET").replace("Post", "POST").replace("Put", "PUT").replace("Patch", "PATCH").replace("Delete", "DELETE").upper()
            else:
                req_method = re.search(r"RequestMethod\.(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)", raw_args)
                if req_method:
                    method = req_method.group(1)
            pending_http = (method, path)
            continue

        class_match = re.search(r"\bclass\s+([A-Z][A-Za-z0-9_]*)\b", line)
        if class_match:
            current_class = class_match.group(1)
            current_base = pending_base
            pending_base = ""
            class_depth = line.count("{") - line.count("}")
            continue

        if current_class:
            class_depth += line.count("{") - line.count("}")
            if pending_http:
                method_match = re.search(
                    r"^\s*(?:public|private|protected|static|final|synchronized|default|\s)*[A-Za-z0-9_<>,\[\]\s]+\s+([a-zA-Z_][A-Za-z0-9_]*)\s*\(",
                    line,
                )
                if method_match:
                    _append_endpoint(
                        result,
                        method=pending_http[0],
                        path=_join_path(current_base, pending_http[1]),
                        handlers=[f"{current_class}.{method_match.group(1)}"],
                        line=line_no,
                        framework="spring",
                    )
                    pending_http = None
            if class_depth <= 0:
                current_class = ""
                current_base = ""
                pending_http = None


def _adapt_aspnet_routes(content: str, result: ParseResult) -> None:
    pending_base = ""
    pending_http: tuple[str, str] | None = None
    current_class = ""
    current_base = ""
    class_depth = 0

    for match in re.finditer(
        r"\b(?:app|group)\.Map(Get|Post|Put|Patch|Delete)\(\s*\"([^\"]+)\"\s*,\s*([A-Za-z_][A-Za-z0-9_.]*)",
        content,
    ):
        _append_endpoint(
            result,
            method=match.group(1),
            path=match.group(2),
            handlers=[match.group(3)],
            line=_line_for_offset(content, match.start()),
            framework="asp.net",
        )

    for line_no, line in enumerate(content.splitlines(), start=1):
        route_match = re.search(r"\[Route\(([^)]*)\)\]", line)
        if route_match and not current_class:
            pending_base = _extract_first_string(route_match.group(1))
            continue

        http_match = re.search(
            r"\[(HttpGet|HttpPost|HttpPut|HttpPatch|HttpDelete)(?:\(([^)]*)\))?\]",
            line,
        )
        if http_match:
            method = http_match.group(1).replace("Http", "")
            path = _extract_first_string(http_match.group(2) or "")
            pending_http = (method, path)
            continue

        class_match = re.search(r"\bclass\s+([A-Z][A-Za-z0-9_]*)\b", line)
        if class_match:
            current_class = class_match.group(1)
            current_base = pending_base
            pending_base = ""
            class_depth = line.count("{") - line.count("}")
            continue

        if current_class:
            class_depth += line.count("{") - line.count("}")
            if pending_http:
                method_match = re.search(
                    r"^\s*(?:public|private|protected|internal|async|virtual|override|static|\s)+[<>\w\[\],?\s]+\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(",
                    line,
                )
                if method_match:
                    base = current_base.replace("[controller]", current_class.removesuffix("Controller"))
                    _append_endpoint(
                        result,
                        method=pending_http[0],
                        path=_join_path(base, pending_http[1]),
                        handlers=[f"{current_class}.{method_match.group(1)}"],
                        line=line_no,
                        framework="asp.net",
                    )
                    pending_http = None
            if class_depth <= 0:
                current_class = ""
                current_base = ""
                pending_http = None


def _adapt_gin_routes(content: str, result: ParseResult) -> None:
    groups: dict[str, str] = {}
    for line_no, line in enumerate(content.splitlines(), start=1):
        group_match = re.search(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*:=\s*([A-Za-z_][A-Za-z0-9_]*)\.Group\(\s*\"([^\"]*)\"", line)
        if group_match:
            parent = groups.get(group_match.group(2), "")
            groups[group_match.group(1)] = _join_path(parent, group_match.group(3))
            continue

        route_match = re.search(
            r"\b([A-Za-z_][A-Za-z0-9_]*)\.(GET|POST|PUT|PATCH|DELETE|Any)\(\s*\"([^\"]+)\"\s*,\s*([A-Za-z_][A-Za-z0-9_.]*)",
            line,
        )
        if route_match:
            group_name = route_match.group(1)
            base = groups.get(group_name, "")
            _append_endpoint(
                result,
                method=route_match.group(2),
                path=_join_path(base, route_match.group(3)),
                handlers=[route_match.group(4)],
                line=line_no,
                framework="gin",
            )


def _adapt_rails_routes(content: str, result: ParseResult) -> None:
    direct_pattern = re.compile(
        r"\b(get|post|put|patch|delete)\s+['\"]([^'\"]+)['\"](?:\s*,\s*to:\s*['\"]([^#'\"]+)#([^'\"]+)['\"])?",
    )
    for match in direct_pattern.finditer(content):
        controller = match.group(3) or ""
        action = match.group(4) or ""
        handler = f"{_camelize(controller)}Controller.{action}" if controller and action else action
        _append_endpoint(
            result,
            method=match.group(1),
            path=match.group(2),
            handlers=[handler] if handler else [],
            line=_line_for_offset(content, match.start()),
            framework="rails",
        )

    resources_pattern = re.compile(r"\bresources\s+:([A-Za-z_][A-Za-z0-9_]*)")
    for match in resources_pattern.finditer(content):
        resource = match.group(1)
        controller = f"{_camelize(resource)}Controller"
        base = _join_path(resource)
        line = _line_for_offset(content, match.start())
        for method, path, action in (
            ("GET", base, "index"),
            ("POST", base, "create"),
            ("GET", _join_path(resource, ":id"), "show"),
            ("PATCH", _join_path(resource, ":id"), "update"),
            ("DELETE", _join_path(resource, ":id"), "destroy"),
        ):
            _append_endpoint(
                result,
                method=method,
                path=path,
                handlers=[f"{controller}.{action}"],
                line=line,
                framework="rails",
            )


def _adapt_laravel_routes(content: str, result: ParseResult) -> None:
    route_pattern = re.compile(
        r"Route::(get|post|put|patch|delete|any)\(\s*['\"]([^'\"]+)['\"]\s*,\s*([^)]+)\)",
    )
    for match in route_pattern.finditer(content):
        handler_raw = match.group(3).strip()
        handler = ""
        array_handler = re.search(r"\[\s*([A-Za-z_\\][A-Za-z0-9_\\]*)::class\s*,\s*['\"]([A-Za-z_][A-Za-z0-9_]*)['\"]\s*\]", handler_raw)
        if array_handler:
            controller = array_handler.group(1).split("\\")[-1]
            handler = f"{controller}.{array_handler.group(2)}"
        else:
            action_handler = re.search(r"([A-Za-z_\\][A-Za-z0-9_\\]*)@([A-Za-z_][A-Za-z0-9_]*)", handler_raw)
            if action_handler:
                controller = action_handler.group(1).split("\\")[-1]
                handler = f"{controller}.{action_handler.group(2)}"
        _append_endpoint(
            result,
            method=match.group(1),
            path=match.group(2),
            handlers=[handler] if handler else [],
            line=_line_for_offset(content, match.start()),
            framework="laravel",
        )


def _adapt_rust_routes(content: str, result: ParseResult) -> None:
    pending_http: tuple[str, str] | None = None

    for line_no, line in enumerate(content.splitlines(), start=1):
        attr_match = re.search(r"#\[(get|post|put|patch|delete|head|options)\(\"([^\"]+)\"", line)
        if attr_match:
            pending_http = (attr_match.group(1), attr_match.group(2))
            continue
        if pending_http:
            fn_match = re.search(r"\bfn\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(", line)
            if fn_match:
                _append_endpoint(
                    result,
                    method=pending_http[0],
                    path=pending_http[1],
                    handlers=[fn_match.group(1)],
                    line=line_no,
                    framework="rocket",
                )
                pending_http = None

    for match in re.finditer(r'route\(\s*"([^"]+)"\s*,\s*([^\n;]+)\)', content):
        route_path = match.group(1)
        handler_expr = match.group(2)
        method_handlers = re.findall(r"\b(get|post|put|patch|delete)\(([^)]+)\)", handler_expr)
        for method, handler in method_handlers:
            _append_endpoint(
                result,
                method=method,
                path=route_path,
                handlers=[handler.strip()],
                line=_line_for_offset(content, match.start()),
                framework="axum",
            )
