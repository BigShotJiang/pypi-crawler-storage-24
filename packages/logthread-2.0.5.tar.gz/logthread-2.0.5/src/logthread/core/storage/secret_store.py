"""Secure secret storage helpers with OS keychain support."""

from __future__ import annotations

import importlib.util
import json
import logging
import platform
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

_SERVICE_NAME = "logthread"


class SecretStoreUnavailable(RuntimeError):
    """Raised when no secure secret backend is available."""


def secret_account(repo_path: Path, namespace: str, item_id: str) -> str:
    return f"{namespace}:{repo_path.resolve()}:{item_id}"


def store_secret(repo_path: Path, namespace: str, item_id: str, payload: dict) -> None:
    secret = json.dumps(payload)
    account = secret_account(repo_path, namespace, item_id)

    if _has_keyring():
        _keyring_set(account, secret)
        return

    system = platform.system()
    if system == "Darwin":
        _macos_set(account, secret)
        return
    if system == "Linux":
        _linux_set(account, secret)
        return

    raise SecretStoreUnavailable("No secure OS keychain backend is available for storing secrets.")


def load_secret(repo_path: Path, namespace: str, item_id: str) -> dict | None:
    account = secret_account(repo_path, namespace, item_id)

    secret: str | None = None
    if _has_keyring():
        secret = _keyring_get(account)
    else:
        system = platform.system()
        if system == "Darwin":
            secret = _macos_get(account)
        elif system == "Linux":
            secret = _linux_get(account)
        else:
            raise SecretStoreUnavailable("No secure OS keychain backend is available for loading secrets.")

    if not secret:
        return None
    try:
        payload = json.loads(secret)
    except json.JSONDecodeError:
        logger.warning("Stored secret payload was not valid JSON for %s", account)
        return None
    return payload if isinstance(payload, dict) else None


def delete_secret(repo_path: Path, namespace: str, item_id: str) -> None:
    account = secret_account(repo_path, namespace, item_id)

    if _has_keyring():
        _keyring_delete(account)
        return

    system = platform.system()
    if system == "Darwin":
        _macos_delete(account)
        return
    if system == "Linux":
        _linux_delete(account)
        return

    raise SecretStoreUnavailable("No secure OS keychain backend is available for deleting secrets.")


def _has_keyring() -> bool:
    return importlib.util.find_spec("keyring") is not None


def _keyring_module():
    import keyring  # type: ignore
    return keyring


def _keyring_set(account: str, secret: str) -> None:
    try:
        _keyring_module().set_password(_SERVICE_NAME, account, secret)
    except Exception as exc:  # pragma: no cover - backend-specific
        raise SecretStoreUnavailable(f"Keyring set failed: {exc}") from exc


def _keyring_get(account: str) -> str | None:
    try:
        return _keyring_module().get_password(_SERVICE_NAME, account)
    except Exception as exc:  # pragma: no cover - backend-specific
        raise SecretStoreUnavailable(f"Keyring lookup failed: {exc}") from exc


def _keyring_delete(account: str) -> None:
    keyring = _keyring_module()
    try:
        keyring.delete_password(_SERVICE_NAME, account)
    except keyring.errors.PasswordDeleteError:  # type: ignore[attr-defined]
        return
    except Exception as exc:  # pragma: no cover - backend-specific
        raise SecretStoreUnavailable(f"Keyring delete failed: {exc}") from exc


def _macos_set(account: str, secret: str) -> None:
    subprocess.run(
        ["security", "add-generic-password", "-U", "-s", _SERVICE_NAME, "-a", account, "-w", secret],
        check=True,
        capture_output=True,
        text=True,
    )


def _macos_get(account: str) -> str | None:
    completed = subprocess.run(
        ["security", "find-generic-password", "-s", _SERVICE_NAME, "-a", account, "-w"],
        check=False,
        capture_output=True,
        text=True,
    )
    if completed.returncode != 0:
        return None
    return completed.stdout.strip() or None


def _macos_delete(account: str) -> None:
    subprocess.run(
        ["security", "delete-generic-password", "-s", _SERVICE_NAME, "-a", account],
        check=False,
        capture_output=True,
        text=True,
    )


def _linux_set(account: str, secret: str) -> None:
    subprocess.run(
        ["secret-tool", "store", "--label", f"{_SERVICE_NAME}:{account}", "service", _SERVICE_NAME, "account", account],
        input=secret,
        check=True,
        capture_output=True,
        text=True,
    )


def _linux_get(account: str) -> str | None:
    completed = subprocess.run(
        ["secret-tool", "lookup", "service", _SERVICE_NAME, "account", account],
        check=False,
        capture_output=True,
        text=True,
    )
    if completed.returncode != 0:
        return None
    return completed.stdout.strip() or None


def _linux_delete(account: str) -> None:
    # secret-tool does not offer a stable delete API across distros, so overwrite with empty
    # payload if direct deletion is not available.
    subprocess.run(
        ["secret-tool", "clear", "service", _SERVICE_NAME, "account", account],
        check=False,
        capture_output=True,
        text=True,
    )
