"""Database configuration and multi-backend support for LogThread."""

from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import Optional


class DatabaseType(Enum):
    """Supported database backends."""
    LADYBUG = "ladybug"
    NEO4J = "neo4j"
    FALKORDB = "falkordb"
    FALKORDB_REMOTE = "falkordb-remote"


class DatabaseConfig:
    """Configuration for database connection."""

    def __init__(
        self,
        db_type: DatabaseType = DatabaseType.LADYBUG,
        path: Optional[Path] = None,
        uri: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        database: str = "neo4j",
    ):
        self.db_type = db_type
        self.path = path
        self.uri = uri
        self.username = username
        self.password = password
        self.database = database

    @classmethod
    def from_env(cls) -> DatabaseConfig:
        """Create config from environment variables."""
        import os

        db_type_str = os.getenv("LOGTHREAD_DB_TYPE", "ladybug").lower()
        db_type = DatabaseType(db_type_str)

        if db_type == DatabaseType.LADYBUG:
            path_str = os.getenv("LOGTHREAD_DB_PATH")
            return cls(
                db_type=db_type,
                path=Path(path_str) if path_str else None,
            )
        elif db_type in (DatabaseType.NEO4J, DatabaseType.FALKORDB_REMOTE):
            return cls(
                db_type=db_type,
                uri=os.getenv("LOGTHREAD_DB_URI", "bolt://localhost:7687"),
                username=os.getenv("LOGTHREAD_DB_USERNAME", "neo4j"),
                password=os.getenv("LOGTHREAD_DB_PASSWORD", "password"),
                database=os.getenv("LOGTHREAD_DB_DATABASE", "neo4j"),
            )
        else:  # FALKORDB
            path_str = os.getenv("LOGTHREAD_DB_PATH")
            return cls(
                db_type=db_type,
                path=Path(path_str) if path_str else None,
            )

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "db_type": self.db_type.value,
            "path": str(self.path) if self.path else None,
            "uri": self.uri,
            "username": self.username,
            "database": self.database,
        }
