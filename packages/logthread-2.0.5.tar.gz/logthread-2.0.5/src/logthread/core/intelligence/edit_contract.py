"""Agent-safe edit contracts built from graph context plus file-local evidence."""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

from logthread.core.graph.model import GraphNode
from logthread.core.ingestion.parser_phase import parse_file
from logthread.core.intelligence.lockfiles import build_lockfile_truth
from logthread.core.intelligence.workspace import build_workspace_map

logger = logging.getLogger(__name__)


def _safe_read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return ""


def _infer_language(node: GraphNode) -> str:
    if node.language:
        return node.language
    suffix = Path(node.file_path).suffix.lower()
    return {
        ".py": "python",
        ".ts": "typescript",
        ".tsx": "tsx",
        ".js": "javascript",
        ".jsx": "javascript",
        ".go": "go",
        ".cs": "csharp",
        ".java": "java",
        ".rb": "ruby",
        ".sql": "sql",
    }.get(suffix, "")


def _identifier_words(text: str) -> set[str]:
    return set(re.findall(r"[A-Za-z_][A-Za-z0-9_]*", text))


def _split_signature_params(signature: str) -> list[str]:
    if not signature or "(" not in signature or ")" not in signature:
        return []
    start = signature.find("(") + 1
    end = signature.rfind(")")
    raw = signature[start:end]
    parts: list[str] = []
    current: list[str] = []
    depth = 0
    for char in raw:
        if char in "([{<":
            depth += 1
        elif char in ")]}>":
            depth = max(0, depth - 1)
        if char == "," and depth == 0:
            item = "".join(current).strip()
            if item:
                parts.append(item)
            current = []
            continue
        current.append(char)
    tail = "".join(current).strip()
    if tail:
        parts.append(tail)
    return parts


def _extract_parameters(node: GraphNode) -> list[dict[str, Any]]:
    parameters: list[dict[str, Any]] = []
    for raw in _split_signature_params(node.signature):
        candidate = raw.split("=", 1)[0].strip()
        if not candidate or candidate in {"self", "cls"}:
            continue

        name = candidate
        type_hint = ""
        if ":" in candidate:
            name, type_hint = [part.strip() for part in candidate.split(":", 1)]
        elif " " in candidate:
            parts = candidate.split()
            name = parts[-1].strip()
            type_hint = " ".join(parts[:-1]).strip()

        name = name.lstrip("*&")
        if not name:
            continue
        parameters.append({
            "name": name,
            "typeHint": type_hint,
            "source": "signature",
        })
    return parameters


def _extract_import_bindings(language: str, content: str, parse_result: Any, scope_words: set[str]) -> list[dict[str, Any]]:
    imports: list[dict[str, Any]] = []
    for item in getattr(parse_result, "imports", []):
        candidates = [item.alias] if item.alias else []
        candidates.extend(item.names)
        if not candidates:
            candidates = [item.module.split("/")[-1].split(".")[-1]]
        if scope_words and not any(candidate in scope_words for candidate in candidates if candidate):
            continue
        imports.append({
            "module": item.module,
            "names": [name for name in item.names if name],
            "alias": item.alias or "",
            "source": language or "parser",
        })
    return imports[:16]


def _extract_local_variables(language: str, scope_lines: list[str], line_offset: int) -> list[dict[str, Any]]:
    patterns = {
        "typescript": [
            re.compile(r"\b(?:const|let|var)\s+([A-Za-z_$][A-Za-z0-9_$]*)"),
            re.compile(r"\b([A-Za-z_$][A-Za-z0-9_$]*)\s*:\s*[A-Za-z_$][A-Za-z0-9_<>,.$\[\]?| ]*\s*="),
        ],
        "tsx": [
            re.compile(r"\b(?:const|let|var)\s+([A-Za-z_$][A-Za-z0-9_$]*)"),
            re.compile(r"\b([A-Za-z_$][A-Za-z0-9_$]*)\s*:\s*[A-Za-z_$][A-Za-z0-9_<>,.$\[\]?| ]*\s*="),
        ],
        "javascript": [
            re.compile(r"\b(?:const|let|var)\s+([A-Za-z_$][A-Za-z0-9_$]*)"),
        ],
        "python": [
            re.compile(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*(?::[^=]+)?="),
        ],
        "go": [
            re.compile(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*:?="),
        ],
        "csharp": [
            re.compile(r"\b(?:var|[A-Za-z_][A-Za-z0-9_<>,.?]*)\s+([A-Za-z_][A-Za-z0-9_]*)\s*="),
        ],
        "java": [
            re.compile(r"\b(?:final\s+)?[A-Za-z_][A-Za-z0-9_<>,.?]*\s+([A-Za-z_][A-Za-z0-9_]*)\s*="),
        ],
        "ruby": [
            re.compile(r"^\s*([a-z_][A-Za-z0-9_]*)\s*="),
        ],
    }
    seen: set[str] = set()
    variables: list[dict[str, Any]] = []
    for index, line in enumerate(scope_lines, start=line_offset):
        for pattern in patterns.get(language, []):
            for match in pattern.finditer(line):
                name = match.group(1).strip()
                if name in seen or name in {"return", "if", "for", "while"}:
                    continue
                seen.add(name)
                variables.append({
                    "name": name,
                    "line": index,
                    "source": "local_binding",
                })
    return variables[:24]


def _filter_type_refs(parse_result: Any, start_line: int, end_line: int) -> list[dict[str, Any]]:
    refs: list[dict[str, Any]] = []
    for ref in getattr(parse_result, "type_refs", []):
        if ref.line < start_line or ref.line > end_line:
            continue
        refs.append({
            "name": ref.name,
            "kind": ref.kind,
            "line": ref.line,
            "paramName": getattr(ref, "param_name", "") or "",
        })
    return refs[:24]


def _filter_calls(parse_result: Any, start_line: int, end_line: int) -> list[dict[str, Any]]:
    calls: list[dict[str, Any]] = []
    for call in getattr(parse_result, "calls", []):
        if call.line < start_line or call.line > end_line:
            continue
        calls.append({
            "name": call.name,
            "line": call.line,
            "receiver": getattr(call, "receiver", "") or "",
        })
    return calls[:24]


def _best_matching_project(workspace_packet: dict[str, Any], file_path: str) -> dict[str, Any] | None:
    normalized = file_path.strip().replace("\\", "/")
    candidates: list[dict[str, Any]] = []
    for project in workspace_packet.get("projects", []):
        raw_root = (project.get("rootPath") or "").replace("\\", "/").strip()
        root = raw_root.strip("./")
        if raw_root in {"", "."}:
            candidates.append(project)
            continue
        if normalized == root or normalized.startswith(f"{root}/"):
            candidates.append(project)
    if not candidates:
        return None
    return max(candidates, key=lambda item: len((item.get("rootPath") or "").replace("\\", "/")))


def _collect_project_ids(workspace_packet: dict[str, Any], file_paths: list[str]) -> set[str]:
    project_ids: set[str] = set()
    for file_path in file_paths:
        project = _best_matching_project(workspace_packet, file_path)
        if project:
            project_ids.add(project["id"])
    return project_ids


def _collect_cross_project_impact(
    workspace_packet: dict[str, Any],
    *,
    owner_project_ids: set[str],
    impacted_file_paths: list[str],
) -> dict[str, Any]:
    projects = {project["id"]: project for project in workspace_packet.get("projects", [])}
    directly_impacted_ids = _collect_project_ids(workspace_packet, impacted_file_paths)
    impacted_projects: dict[str, dict[str, Any]] = {}

    for project_id in owner_project_ids | directly_impacted_ids:
        project = projects.get(project_id)
        if not project:
            continue
        impacted_projects[project_id] = {
            "projectId": project_id,
            "projectName": project["name"],
            "projectKind": project["kind"],
            "reason": "direct_file_impact" if project_id in directly_impacted_ids else "owner_project",
        }

    for ref in workspace_packet.get("references", []):
        source_id = ref["sourceProjectId"]
        target_id = ref["targetProjectId"]
        if source_id in owner_project_ids and target_id in projects:
            impacted_projects.setdefault(target_id, {
                "projectId": target_id,
                "projectName": projects[target_id]["name"],
                "projectKind": projects[target_id]["kind"],
                "reason": f"outgoing_{ref['type']}",
            })
        if target_id in owner_project_ids and source_id in projects:
            impacted_projects.setdefault(source_id, {
                "projectId": source_id,
                "projectName": projects[source_id]["name"],
                "projectKind": projects[source_id]["kind"],
                "reason": f"incoming_{ref['type']}",
            })

    return {
        "ownerProjects": [
            {
                "projectId": project_id,
                "projectName": projects[project_id]["name"],
                "projectKind": projects[project_id]["kind"],
                "rootPath": projects[project_id]["rootPath"],
            }
            for project_id in sorted(owner_project_ids)
            if project_id in projects
        ],
        "impactedProjects": sorted(impacted_projects.values(), key=lambda item: item["projectName"].lower()),
    }


def build_scope_contract(node: GraphNode, repo_path: Path, workspace_packet: dict[str, Any]) -> dict[str, Any]:
    language = _infer_language(node)
    file_path = repo_path / node.file_path
    content = _safe_read(file_path)
    if not content:
        return {
            "nodeId": node.id,
            "nodeName": node.name,
            "filePath": node.file_path,
            "projectId": None,
            "projectName": None,
            "scopeKind": node.label.value,
            "parameters": _extract_parameters(node),
            "imports": [],
            "variables": [],
            "typeReferences": [],
            "localCalls": [],
            "editHints": ["Source file could not be loaded, so scope evidence is incomplete."],
        }

    try:
        parse_result = parse_file(node.file_path, content, language).parse_result if language else None
    except Exception:
        logger.debug("Failed to build scope contract parse for %s", node.file_path, exc_info=True)
        parse_result = None

    lines = content.splitlines()
    start_line = max(1, node.start_line or 1)
    end_line = min(len(lines), node.end_line or len(lines))
    if start_line > len(lines) or start_line > end_line:
        start_line = 1
        end_line = len(lines)
    scope_lines = lines[start_line - 1:end_line]
    scope_text = "\n".join(scope_lines) if scope_lines else node.content
    scope_words = _identifier_words(scope_text)

    parameters = _extract_parameters(node)
    imports = _extract_import_bindings(language, content, parse_result, scope_words) if parse_result else []
    variables = _extract_local_variables(language, scope_lines, start_line)
    type_references = _filter_type_refs(parse_result, start_line, end_line) if parse_result else []
    local_calls = _filter_calls(parse_result, start_line, end_line) if parse_result else []

    type_by_line = {item["line"]: item["name"] for item in type_references if item["kind"] == "variable"}
    for variable in variables:
        variable["typeHint"] = type_by_line.get(variable["line"], "")

    project = _best_matching_project(workspace_packet, node.file_path)
    edit_hints = [
        f"Pin edits to {node.file_path}:{start_line}-{end_line} instead of editing same-named symbols elsewhere.",
    ]
    if parameters:
        edit_hints.append(
            "Preserve in-scope parameter contracts before introducing new globals or helpers."
        )
    if local_calls:
        edit_hints.append(
            "Prefer reusing local call sites already present in this scope before importing another implementation."
        )

    return {
        "nodeId": node.id,
        "nodeName": node.name,
        "filePath": node.file_path,
        "projectId": project["id"] if project else None,
        "projectName": project["name"] if project else None,
        "scopeKind": node.label.value,
        "parameters": parameters,
        "imports": imports,
        "variables": variables,
        "typeReferences": type_references,
        "localCalls": local_calls,
        "editHints": edit_hints,
    }


def build_edit_contract_packet(
    repo_path: Path,
    implementation_brief_packet: dict[str, Any],
) -> dict[str, Any]:
    """Build an agent-safe edit contract from an existing implementation brief."""
    repo_path = repo_path.resolve()
    workspace_packet = build_workspace_map(repo_path)
    exact_targets = implementation_brief_packet.get("exactTargets", [])
    affected = implementation_brief_packet.get("affected", {})
    exact_file_paths = [item.get("filePath", "") for item in exact_targets if item.get("filePath")]
    impacted_file_paths = [
        item.get("filePath", "")
        for bucket in affected.values()
        for item in bucket
        if item.get("filePath")
    ]
    owner_project_ids = _collect_project_ids(workspace_packet, exact_file_paths)
    dependency_truth = build_lockfile_truth(repo_path, workspace_packet, project_ids=owner_project_ids or None)

    scoped_targets: list[dict[str, Any]] = []
    unresolved = list(implementation_brief_packet.get("unresolvedAmbiguities", []))
    for item in exact_targets[:6]:
        graph_node = GraphNode(
            id=item["id"],
            label=type("LabelProxy", (), {"value": item["label"]})(),  # type: ignore[arg-type]
            name=item["name"],
            file_path=item.get("filePath", "") or "",
            start_line=item.get("startLine", 0) or 0,
            end_line=item.get("endLine", 0) or 0,
            signature=item.get("signature", "") or "",
            language=item.get("language", "") or "",
        )
        scoped_targets.append(build_scope_contract(graph_node, repo_path, workspace_packet))

    relevant_dependency_names = {item.lower() for item in implementation_brief_packet.get("existingDependencies", [])}
    relevant_packages: list[dict[str, Any]] = []
    for project in dependency_truth.get("projects", []):
        for dependency in project.get("dependencies", []):
            if relevant_dependency_names and dependency["name"].lower() not in relevant_dependency_names:
                continue
            relevant_packages.append({
                **dependency,
                "projectId": project["projectId"],
                "projectName": project["projectName"],
                "packageManager": project["packageManager"],
                "lockfilePath": project["lockfilePath"],
            })

    if dependency_truth.get("missingLockfiles"):
        unresolved.extend(dependency_truth["missingLockfiles"])

    if not relevant_packages and implementation_brief_packet.get("existingDependencies"):
        unresolved.append(
            "Manifest dependencies were detected near the target, but no exact lockfile-backed versions were resolved for those packages."
        )

    cross_project = _collect_cross_project_impact(
        workspace_packet,
        owner_project_ids=owner_project_ids,
        impacted_file_paths=exact_file_paths + impacted_file_paths,
    )

    checklist = [
        "Edit the anchored symbol in place before creating a new helper, service, or wrapper.",
        "Keep changes inside the listed file and line ranges unless a directly impacted project is explicitly part of the task.",
        "Reuse the variables, imports, and local call sites already present in scope before adding new dependencies or alternate implementations.",
    ]
    if relevant_packages:
        checklist.append("Use the resolved package versions from the selected lockfiles as the source of truth for dependency choices.")
    if cross_project.get("impactedProjects"):
        checklist.append("Review cross-project dependents before changing shared contracts, DTOs, package exports, or public service methods.")

    anchor = implementation_brief_packet.get("anchor")
    summary = "No anchor resolved."
    if anchor:
        summary = (
            f"Contract pinned to {anchor['name']} in {anchor.get('filePath') or 'the current repo'} with "
            f"{len(scoped_targets)} scoped targets, {len(relevant_packages)} lockfile-backed dependencies, "
            f"and {len(cross_project.get('impactedProjects', []))} project-level impact signals."
        )

    return {
        "kind": "edit_contract",
        "objective": implementation_brief_packet.get("objective", ""),
        "summary": summary,
        "anchor": anchor,
        "confidence": implementation_brief_packet.get("confidence", {"tier": "T0", "score": 0.0}),
        "exactTargets": exact_targets,
        "avoidSymbols": implementation_brief_packet.get("avoidSymbols", []),
        "scopedTargets": scoped_targets,
        "dependencyTruth": {
            "projects": dependency_truth.get("projects", []),
            "relevantPackages": relevant_packages,
            "missingLockfiles": dependency_truth.get("missingLockfiles", []),
        },
        "crossProjectImpact": cross_project,
        "safeEditChecklist": checklist,
        "unresolvedAmbiguities": unresolved,
        "errors": list(implementation_brief_packet.get("errors", [])),
    }
