"""Dependency intelligence helpers for vulnerabilities and update signals."""

from __future__ import annotations

import hashlib
import json
import logging
import os
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any
from urllib.parse import quote

import httpx

from logthread.core.storage.paths import get_project_cache_dir

logger = logging.getLogger(__name__)

_CACHE_TTL_SECONDS = 60 * 60 * 6

_ECOSYSTEM_BY_LANGUAGE = {
    "python": "PyPI",
    "npm": "npm",
    "nuget": "NuGet",
    "go": "Go",
    "ruby": "RubyGems",
}


def external_dependency_intelligence_enabled() -> bool:
    value = os.getenv("LOGTHREAD_ENABLE_EXTERNAL_DEPENDENCY_INTELLIGENCE", "").strip().lower()
    return value in {"1", "true", "yes", "on"}


@dataclass(slots=True)
class DependencyIntel:
    latest_version: str | None = None
    update_available: bool = False
    update_kind: str | None = None
    advisories: list[dict[str, Any]] | None = None
    advisory_count: int = 0
    vulnerability_source: str | None = None
    lookup_error: str | None = None


def _normalize_version(version: str | None) -> str:
    if not version:
        return ""
    cleaned = version.strip()
    for prefix in ("==", ">=", "<=", "~=", "!=", "^", "~", "v", "V"):
        if cleaned.startswith(prefix):
            cleaned = cleaned[len(prefix):].strip()
    if cleaned.startswith("="):
        cleaned = cleaned[1:].strip()
    cleaned = cleaned.split(" ")[0].strip()
    cleaned = cleaned.strip(",;")
    return cleaned


def _parse_numeric_version(version: str | None) -> tuple[int, ...]:
    cleaned = _normalize_version(version)
    if not cleaned:
        return ()

    parts: list[int] = []
    for chunk in cleaned.replace("-", ".").split("."):
        digits = "".join(ch for ch in chunk if ch.isdigit())
        if digits:
            parts.append(int(digits))
        else:
            break
    return tuple(parts)


def _classify_update_kind(current: str | None, latest: str | None) -> str | None:
    current_parts = _parse_numeric_version(current)
    latest_parts = _parse_numeric_version(latest)
    if not current_parts or not latest_parts or latest_parts <= current_parts:
        return None
    if len(current_parts) >= 1 and len(latest_parts) >= 1 and latest_parts[0] != current_parts[0]:
        return "major"
    if len(current_parts) >= 2 and len(latest_parts) >= 2 and latest_parts[1] != current_parts[1]:
        return "minor"
    if len(current_parts) >= 3 and len(latest_parts) >= 3 and latest_parts[2] != current_parts[2]:
        return "patch"
    return "available"


def _cache_key_for_dependencies(dependencies: list[dict[str, Any]]) -> str:
    stable_payload = [
        {
            "name": item.get("name", ""),
            "language": item.get("language", ""),
            "version": item.get("version", ""),
        }
        for item in sorted(dependencies, key=lambda item: (str(item.get("language", "")), str(item.get("name", ""))))
    ]
    digest = hashlib.sha256(json.dumps(stable_payload, sort_keys=True).encode("utf-8")).hexdigest()
    return digest[:16]


def _read_cache(repo_path: Path, cache_key: str) -> dict[str, Any] | None:
    cache_file = get_project_cache_dir(repo_path) / "dependency_intelligence.json"
    if not cache_file.exists():
        return None
    try:
        payload = json.loads(cache_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None

    if payload.get("cache_key") != cache_key:
        return None
    fetched_at = int(payload.get("fetched_at", 0) or 0)
    import time
    if time.time() - fetched_at > _CACHE_TTL_SECONDS:
        return None
    return payload


def _write_cache(repo_path: Path, cache_key: str, intelligence: dict[str, Any]) -> None:
    cache_file = get_project_cache_dir(repo_path) / "dependency_intelligence.json"
    import time
    payload = {
        "cache_key": cache_key,
        "fetched_at": int(time.time()),
        "intelligence": intelligence,
    }
    try:
        cache_file.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    except OSError:
        logger.debug("Failed to write dependency intelligence cache", exc_info=True)


def _fetch_latest_version(client: httpx.Client, language: str, package_name: str) -> str | None:
    ecosystem = language.lower()
    if ecosystem == "python":
        response = client.get(f"https://pypi.org/pypi/{quote(package_name)}/json")
        response.raise_for_status()
        return str(response.json().get("info", {}).get("version") or "").strip() or None
    if ecosystem == "npm":
        response = client.get(f"https://registry.npmjs.org/{quote(package_name, safe='@/')}/latest")
        response.raise_for_status()
        return str(response.json().get("version") or "").strip() or None
    if ecosystem == "nuget":
        response = client.get(f"https://api.nuget.org/v3-flatcontainer/{package_name.lower()}/index.json")
        response.raise_for_status()
        versions = response.json().get("versions") or []
        return str(versions[-1]).strip() if versions else None
    if ecosystem == "go":
        response = client.get(f"https://proxy.golang.org/{quote(package_name, safe='/')}/@latest")
        response.raise_for_status()
        return str(response.json().get("Version") or "").strip() or None
    if ecosystem == "ruby":
        response = client.get(f"https://rubygems.org/api/v1/gems/{quote(package_name)}.json")
        response.raise_for_status()
        return str(response.json().get("version") or "").strip() or None
    return None


def _fetch_vulnerabilities(
    client: httpx.Client,
    language: str,
    package_name: str,
    version: str,
) -> tuple[list[dict[str, Any]], str | None]:
    ecosystem = _ECOSYSTEM_BY_LANGUAGE.get(language.lower())
    if not ecosystem:
        return [], None

    payload: dict[str, Any] = {
        "package": {"name": package_name, "ecosystem": ecosystem},
    }
    normalized_version = _normalize_version(version)
    if normalized_version:
        payload["version"] = normalized_version

    response = client.post("https://api.osv.dev/v1/query", json=payload)
    response.raise_for_status()
    vulns = response.json().get("vulns") or []

    advisories: list[dict[str, Any]] = []
    for vuln in vulns:
        aliases = [str(alias) for alias in vuln.get("aliases", [])]
        advisory_id = str(vuln.get("id") or aliases[0] if aliases else "")
        summary = str(vuln.get("summary") or vuln.get("details") or "").strip()
        severity = None
        db_specific = vuln.get("database_specific")
        if isinstance(db_specific, dict):
            severity = db_specific.get("severity")
        advisories.append({
            "id": advisory_id,
            "summary": summary[:240],
            "aliases": aliases[:8],
            "severity": severity,
        })
    return advisories, "osv.dev"


def build_dependency_intelligence(
    repo_path: Path,
    dependencies: list[dict[str, Any]],
    *,
    refresh: bool = False,
) -> dict[str, DependencyIntel]:
    """Resolve vulnerability and update signals for project dependencies."""
    if not dependencies:
        return {}

    if not external_dependency_intelligence_enabled():
        message = (
            "External dependency intelligence disabled by policy. "
            "Set LOGTHREAD_ENABLE_EXTERNAL_DEPENDENCY_INTELLIGENCE=1 to enable CVE and version lookups."
        )
        return {
            str(dep.get("dep_id") or ""): DependencyIntel(
                advisories=[],
                advisory_count=0,
                lookup_error=message,
            )
            for dep in dependencies
            if str(dep.get("dep_id") or "")
        }

    cache_key = _cache_key_for_dependencies(dependencies)
    if not refresh:
        cached = _read_cache(repo_path, cache_key)
        if cached:
            return {
                dep_id: DependencyIntel(**payload)
                for dep_id, payload in (cached.get("intelligence") or {}).items()
            }

    results: dict[str, DependencyIntel] = {}
    transport = httpx.HTTPTransport(retries=1)
    with httpx.Client(timeout=httpx.Timeout(6.0, read=8.0), transport=transport) as client:
        for dep in dependencies:
            dep_id = str(dep.get("dep_id") or "")
            name = str(dep.get("name") or "")
            language = str(dep.get("language") or "")
            version = str(dep.get("version") or "")
            intel = DependencyIntel(advisories=[])

            try:
                latest = _fetch_latest_version(client, language, name)
                intel.latest_version = latest
                normalized_current = _normalize_version(version)
                normalized_latest = _normalize_version(latest)
                intel.update_available = bool(
                    normalized_current and normalized_latest and normalized_current != normalized_latest
                )
                intel.update_kind = _classify_update_kind(normalized_current, normalized_latest)
            except Exception as exc:
                logger.debug("Latest version lookup failed for %s: %s", name, exc)
                intel.lookup_error = "Could not resolve latest package version"

            try:
                advisories, source = _fetch_vulnerabilities(client, language, name, version)
                intel.advisories = advisories
                intel.advisory_count = len(advisories)
                intel.vulnerability_source = source
            except Exception as exc:
                logger.debug("Vulnerability lookup failed for %s: %s", name, exc)
                if intel.lookup_error is None:
                    intel.lookup_error = "Could not resolve vulnerability intelligence"

            results[dep_id] = intel

    _write_cache(
        repo_path,
        cache_key,
        {dep_id: asdict(intel) for dep_id, intel in results.items()},
    )
    return results
