"""Focused entry-trace helpers for developer-readable graph exploration."""

from __future__ import annotations

import json
import re
import shlex
import xml.etree.ElementTree as ET
from collections import defaultdict, deque
from pathlib import Path
from typing import Any

from logthread.core.graph.graph import KnowledgeGraph
from logthread.core.graph.model import GraphNode, GraphRelationship, NodeLabel, RelType, generate_id

try:
    import tomllib
except Exception:  # pragma: no cover - Python <3.11 fallback
    tomllib = None

TRACE_LENSES = {"balanced", "data"}

_ENTRY_FILE_NAMES = {
    "program.cs",
    "startup.cs",
    "manage.py",
    "__main__.py",
    "main.py",
    "app.py",
    "server.py",
    "server.js",
    "server.ts",
    "main.js",
    "main.ts",
    "app.js",
    "app.ts",
    "index.js",
    "index.ts",
}
_NODE_ENTRY_SCRIPT = re.compile(
    r"(?:(?:node|tsx|ts-node|tsx-esm|bun|deno|python(?:3)?|uv\s+run)\s+)?"
    r"(?P<path>[\w./\\-]+\.(?:js|mjs|cjs|ts|tsx|jsx|py))\b"
)
_PYTHON_ENTRY_SUFFIXES = ("main.py", "app.py", "__main__.py", "manage.py")
_DOTNET_ENTRY_SUFFIXES = ("Program.cs", "Startup.cs")
_FILE_ROOT_IMPORT_LIMIT = 12
_JS_ENTRY_CANDIDATES = (
    "src/main.tsx",
    "src/main.ts",
    "src/main.jsx",
    "src/main.js",
    "src/index.tsx",
    "src/index.ts",
    "src/index.jsx",
    "src/index.js",
    "main.tsx",
    "main.ts",
    "main.jsx",
    "main.js",
    "index.tsx",
    "index.ts",
    "index.jsx",
    "index.js",
)
_NEXT_ENTRY_CANDIDATES = (
    "src/app/page.tsx",
    "src/app/page.jsx",
    "app/page.tsx",
    "app/page.jsx",
    "src/pages/index.tsx",
    "src/pages/index.jsx",
    "src/pages/index.ts",
    "src/pages/index.js",
    "pages/index.tsx",
    "pages/index.jsx",
    "pages/index.ts",
    "pages/index.js",
)
_NEST_ENTRY_CANDIDATES = ("src/main.ts", "src/main.js", "main.ts", "main.js")
_PYTHON_APP_CANDIDATES = (
    "src/main.py",
    "main.py",
    "src/app.py",
    "app.py",
    "src/manage.py",
    "manage.py",
    "src/asgi.py",
    "asgi.py",
    "src/wsgi.py",
    "wsgi.py",
)
_GO_ENTRY_CANDIDATES = ("cmd/main.go", "cmd/server/main.go", "main.go")
_RUBY_ENTRY_CANDIDATES = ("config/routes.rb", "config/application.rb", "bin/rails", "app/controllers/application_controller.rb")


def build_trace_catalog(graph: KnowledgeGraph, repo_path: Path | None) -> list[dict[str, Any]]:
    """Return developer-friendly entry surfaces that can drive focused traces."""
    file_nodes = _file_index(graph)
    symbol_index = _symbol_index(graph)
    items: list[dict[str, Any]] = []
    seen_roots: set[str] = set()

    for node in sorted(graph.get_nodes_by_label(NodeLabel.API_ENDPOINT), key=_endpoint_sort_key):
        items.append(
            _catalog_item(
                node,
                kind="api",
                title=node.name.replace(":", " ", 1),
                subtitle=_api_subtitle(node),
                tags=[str(node.properties.get("framework", "") or "").lower(), "request"],
                score=400,
            )
        )
        seen_roots.add(node.id)

    manifest_items = _discover_manifest_entries(repo_path, file_nodes, symbol_index)
    for item in manifest_items:
        root_node_id = str(item.get("rootNodeId", ""))
        if root_node_id and root_node_id not in seen_roots:
            seen_roots.add(root_node_id)
            items.append(item)

    for node in sorted(_entry_symbols(graph), key=_symbol_sort_key):
        if node.id in seen_roots:
            continue
        items.append(
            _catalog_item(
                node,
                kind="runtime",
                title=node.name,
                subtitle=_runtime_subtitle(node),
                tags=["entry point", node.language.lower() if node.language else "code"],
                score=250,
            )
        )
        seen_roots.add(node.id)

    for node in sorted(_entry_files(graph), key=lambda n: (n.file_path, n.name)):
        if node.id in seen_roots:
            continue
        items.append(
            _catalog_item(
                node,
                kind="bootstrap",
                title=node.name,
                subtitle=_bootstrap_subtitle(node),
                tags=["bootstrap", node.language.lower() if node.language else "file"],
                score=180,
            )
        )
        seen_roots.add(node.id)

    items.sort(key=lambda item: (-int(item["score"]), str(item["title"]).lower(), str(item["filePath"]).lower()))
    return items


def build_trace_packet(
    graph: KnowledgeGraph,
    root_node_id: str,
    *,
    lens: str = "balanced",
    max_depth: int = 5,
) -> dict[str, Any]:
    """Build a focused trace packet starting from an entry surface."""
    selected_lens = lens if lens in TRACE_LENSES else "balanced"
    root = graph.get_node(root_node_id)
    if root is None:
        raise KeyError(root_node_id)

    trace_nodes: dict[str, GraphNode] = {}
    trace_edges: dict[str, GraphRelationship] = {}
    layers: dict[int, list[str]] = defaultdict(list)
    visited_depth: dict[str, int] = {root.id: 0}
    queue: deque[tuple[str, int, bool]] = deque([(root.id, 0, root.label == NodeLabel.FILE)])

    def add_node(node: GraphNode, depth: int) -> None:
        if node.id not in trace_nodes:
            trace_nodes[node.id] = node
        if node.id not in layers[depth]:
            layers[depth].append(node.id)

    def add_edge(edge: GraphRelationship) -> None:
        trace_edges[edge.id] = edge

    def enqueue(node: GraphNode, depth: int, *, expand_file: bool = False) -> None:
        current = visited_depth.get(node.id)
        if current is None or depth < current:
            visited_depth[node.id] = depth
            queue.append((node.id, depth, expand_file))
        add_node(node, depth)

    add_node(root, 0)

    while queue:
        node_id, depth, expand_file = queue.popleft()
        node = graph.get_node(node_id)
        if node is None:
            continue

        if node.label != NodeLabel.FILE:
            _attach_source_file(graph, node, depth, add_node, add_edge)

        if depth >= max_depth:
            continue

        for rel, other, next_depth, next_expand_file in _iter_trace_neighbors(
            graph,
            node,
            depth,
            expand_file=expand_file,
            lens=selected_lens,
        ):
            add_edge(rel)
            enqueue(other, next_depth, expand_file=next_expand_file)

    boundary_nodes = {
        "libraries": _collect_boundary_nodes(trace_nodes, NodeLabel.EXTERNAL_DEP),
        "tables": _collect_boundary_nodes(trace_nodes, NodeLabel.DB_TABLE),
        "columns": _collect_boundary_nodes(trace_nodes, NodeLabel.DB_COLUMN),
        "files": _collect_boundary_nodes(trace_nodes, NodeLabel.FILE),
    }
    ordered_layers = [
        {"depth": depth, "nodeIds": node_ids}
        for depth, node_ids in sorted(layers.items(), key=lambda item: item[0])
    ]

    return {
        "kind": "entry_trace",
        "traceId": root.id,
        "lens": selected_lens,
        "title": _trace_title(root),
        "subtitle": _trace_subtitle(root),
        "rootNodeId": root.id,
        "stats": {
            "nodes": len(trace_nodes),
            "edges": len(trace_edges),
            "files": len(boundary_nodes["files"]),
            "calls": sum(1 for rel in trace_edges.values() if rel.type == RelType.CALLS),
            "dataAccess": sum(
                1
                for rel in trace_edges.values()
                if rel.type in {RelType.QUERIES_TABLE, RelType.QUERIES_COLUMN, RelType.HAS_COLUMN}
            ),
            "dependencies": sum(
                1
                for rel in trace_edges.values()
                if graph.get_node(rel.target) and graph.get_node(rel.target).label == NodeLabel.EXTERNAL_DEP
            ),
            "maxDepth": max((item["depth"] for item in ordered_layers), default=0),
        },
        "layers": ordered_layers,
        "boundaries": boundary_nodes,
        "nodes": list(trace_nodes.values()),
        "edges": list(trace_edges.values()),
    }


def _iter_trace_neighbors(
    graph: KnowledgeGraph,
    node: GraphNode,
    depth: int,
    *,
    expand_file: bool,
    lens: str,
) -> list[tuple[GraphRelationship, GraphNode, int, bool]]:
    neighbors: list[tuple[GraphRelationship, GraphNode, int, bool]] = []

    def add_from_relationship(rel: GraphRelationship, other_id: str, next_depth: int, *, next_expand_file: bool = False) -> None:
        other = graph.get_node(other_id)
        if other is None:
            return
        neighbors.append((rel, other, next_depth, next_expand_file))

    if node.label == NodeLabel.API_ENDPOINT:
        for rel in graph.get_incoming(node.id, RelType.HANDLES_ROUTE):
            add_from_relationship(rel, rel.source, depth + 1)
        for rel in graph.get_outgoing(node.id, RelType.PROTECTED_BY):
            add_from_relationship(rel, rel.target, depth + 1)
        for rel in graph.get_outgoing(node.id, RelType.DEPENDS_ON):
            add_from_relationship(rel, rel.target, depth + 1, next_expand_file=_is_file(graph, rel.target))
        return neighbors

    if node.label in {NodeLabel.FUNCTION, NodeLabel.METHOD, NodeLabel.CLASS}:
        for rel_type in (RelType.CALLS, RelType.QUERIES_TABLE, RelType.QUERIES_COLUMN):
            for rel in graph.get_outgoing(node.id, rel_type):
                add_from_relationship(rel, rel.target, depth + 1)
        for rel in graph.get_incoming(node.id, RelType.HANDLES_ROUTE):
            add_from_relationship(rel, rel.source, depth + 1)
        if lens == "data":
            for rel in graph.get_outgoing(node.id, RelType.USES_TYPE):
                add_from_relationship(rel, rel.target, depth + 1)
        return neighbors

    if node.label == NodeLabel.DB_TABLE:
        if lens == "data":
            for rel in graph.get_outgoing(node.id, RelType.HAS_COLUMN):
                add_from_relationship(rel, rel.target, depth + 1)
        return neighbors

    if node.label == NodeLabel.FILE:
        for rel in graph.get_outgoing(node.id, RelType.DEPENDS_ON):
            add_from_relationship(rel, rel.target, depth + 1, next_expand_file=_is_file(graph, rel.target))

        if expand_file:
            define_edges = graph.get_outgoing(node.id, RelType.DEFINES)
            for rel in define_edges:
                target = graph.get_node(rel.target)
                if target is None:
                    continue
                if target.label in {
                    NodeLabel.FUNCTION,
                    NodeLabel.METHOD,
                    NodeLabel.CLASS,
                    NodeLabel.API_ENDPOINT,
                }:
                    add_from_relationship(rel, rel.target, depth + 1)

            import_edges = graph.get_outgoing(node.id, RelType.IMPORTS)[:_FILE_ROOT_IMPORT_LIMIT]
            for rel in import_edges:
                add_from_relationship(rel, rel.target, depth + 1, next_expand_file=True)
        return neighbors

    return neighbors


def _attach_source_file(
    graph: KnowledgeGraph,
    node: GraphNode,
    depth: int,
    add_node: Any,
    add_edge: Any,
) -> None:
    if not node.file_path:
        return
    file_id = generate_id(NodeLabel.FILE, node.file_path)
    file_node = graph.get_node(file_id)
    if file_node is None:
        return
    add_node(file_node, depth)
    for rel in graph.get_incoming(node.id, RelType.DEFINES):
        if rel.source == file_id:
            add_edge(rel)
            break
    for rel in graph.get_outgoing(file_id, RelType.DEPENDS_ON):
        target = graph.get_node(rel.target)
        if target is None:
            continue
        if target.label == NodeLabel.EXTERNAL_DEP:
            add_node(target, depth + 1)
            add_edge(rel)


def _collect_boundary_nodes(trace_nodes: dict[str, GraphNode], label: NodeLabel) -> list[GraphNode]:
    return sorted(
        [node for node in trace_nodes.values() if node.label == label],
        key=lambda node: (node.name.lower(), node.file_path.lower()),
    )


def _catalog_item(
    node: GraphNode,
    *,
    kind: str,
    title: str,
    subtitle: str,
    tags: list[str],
    score: int,
) -> dict[str, Any]:
    return {
        "id": f"{kind}:{node.id}",
        "kind": kind,
        "title": title,
        "subtitle": subtitle,
        "rootNodeId": node.id,
        "filePath": node.file_path,
        "language": node.language,
        "score": score,
        "tags": [tag for tag in tags if tag],
    }


def _entry_symbols(graph: KnowledgeGraph) -> list[GraphNode]:
    nodes: list[GraphNode] = []
    for label in (NodeLabel.FUNCTION, NodeLabel.METHOD, NodeLabel.CLASS):
        for node in graph.get_nodes_by_label(label):
            if node.is_entry_point:
                nodes.append(node)
    return nodes


def _entry_files(graph: KnowledgeGraph) -> list[GraphNode]:
    files: list[GraphNode] = []
    for node in graph.get_nodes_by_label(NodeLabel.FILE):
        lower_name = node.name.lower()
        lower_path = node.file_path.lower()
        if lower_name in _ENTRY_FILE_NAMES or lower_path.endswith(_PYTHON_ENTRY_SUFFIXES) or lower_path.endswith(_DOTNET_ENTRY_SUFFIXES):
            files.append(node)
    return files


def _discover_manifest_entries(
    repo_path: Path | None,
    file_nodes: dict[str, GraphNode],
    symbol_index: dict[tuple[str, str], list[GraphNode]],
) -> list[dict[str, Any]]:
    if repo_path is None or not repo_path.exists():
        return []
    items: list[dict[str, Any]] = []
    items.extend(_discover_node_manifest_entries(repo_path, file_nodes))
    items.extend(_discover_pyproject_entries(repo_path, file_nodes, symbol_index))
    items.extend(_discover_dotnet_entries(repo_path, file_nodes))
    items.extend(_discover_common_runtime_entries(file_nodes))
    return items


def _discover_node_manifest_entries(repo_path: Path, file_nodes: dict[str, GraphNode]) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for package_json in repo_path.rglob("package.json"):
        if "node_modules" in package_json.parts:
            continue
        try:
            data = json.loads(package_json.read_text(encoding="utf-8"))
        except Exception:
            continue
        scripts = data.get("scripts", {}) if isinstance(data, dict) else {}
        if not isinstance(scripts, dict):
            continue
        package_name = str(data.get("name", "") or "").strip()
        for script_name in ("start", "dev", "serve", "preview", "start:dev", "start:prod"):
            root_node = _resolve_package_script_entry(
                repo_path,
                package_json.parent,
                script_name,
                scripts,
                file_nodes,
            )
            if root_node is None:
                continue
            items.append(
                _catalog_item(
                    root_node,
                    kind="manifest",
                    title=f"{script_name}: {root_node.name}",
                    subtitle=f"package.json script{f' · {package_name}' if package_name else ''} · {root_node.file_path}",
                    tags=["manifest", "node", script_name, package_name],
                    score=320,
                )
            )
    return items


def _discover_pyproject_entries(
    repo_path: Path,
    file_nodes: dict[str, GraphNode],
    symbol_index: dict[tuple[str, str], list[GraphNode]],
) -> list[dict[str, Any]]:
    if tomllib is None:
        return []

    items: list[dict[str, Any]] = []
    for pyproject in repo_path.rglob("pyproject.toml"):
        try:
            data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
        except Exception:
            continue

        scripts: dict[str, Any] = {}
        project_scripts = (((data.get("project") or {}).get("scripts")) or {})
        poetry_scripts = ((((data.get("tool") or {}).get("poetry") or {}).get("scripts")) or {})
        if isinstance(project_scripts, dict):
            scripts.update(project_scripts)
        if isinstance(poetry_scripts, dict):
            scripts.update(poetry_scripts)
        pdm_scripts = ((((data.get("tool") or {}).get("pdm") or {}).get("scripts")) or {})
        if isinstance(pdm_scripts, dict):
            scripts.update({name: value for name, value in pdm_scripts.items() if isinstance(value, str)})

        for script_name, target in scripts.items():
            if not isinstance(target, str) or ":" not in target:
                continue
            module_name, symbol_name = target.split(":", 1)
            candidate = _resolve_python_script_target(repo_path, module_name, symbol_name, file_nodes, symbol_index)
            if candidate is None:
                continue
            items.append(
                _catalog_item(
                    candidate,
                    kind="manifest",
                    title=f"{script_name}: {candidate.name}",
                    subtitle=f"pyproject script · {candidate.file_path}",
                    tags=["manifest", "python", script_name],
                    score=320,
                )
            )
        items.extend(_discover_python_command_entries(pyproject.parent, data, file_nodes))
    return items


def _discover_dotnet_entries(repo_path: Path, file_nodes: dict[str, GraphNode]) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for csproj in repo_path.rglob("*.csproj"):
        try:
            root = ET.fromstring(csproj.read_text(encoding="utf-8"))
        except Exception:
            continue

        sdk = str(root.attrib.get("Sdk", "") or "")
        output_type = ""
        assembly_name = csproj.stem
        for elem in root.iter():
            tag = elem.tag.rsplit("}", 1)[-1]
            text = (elem.text or "").strip()
            if tag == "OutputType" and text:
                output_type = text
            elif tag == "AssemblyName" and text:
                assembly_name = text

        is_executable = output_type.lower() in {"exe", "winexe"} or "Microsoft.NET.Sdk.Web" in sdk
        if not is_executable:
            continue

        project_dir = csproj.parent
        root_node = (
            _resolve_file_candidate(repo_path, project_dir, "Program.cs", file_nodes)
            or _resolve_file_candidate(repo_path, project_dir, "Startup.cs", file_nodes)
        )
        if root_node is None:
            continue

        items.append(
            _catalog_item(
                root_node,
                kind="manifest",
                title=f"{assembly_name}: {root_node.name}",
                subtitle=f".csproj executable · {root_node.file_path}",
                tags=["manifest", "dotnet", "csproj", sdk.replace('.', ' ')],
                score=340,
            )
        )
    return items


def _discover_common_runtime_entries(file_nodes: dict[str, GraphNode]) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    runtime_candidates = [
        ("bootstrap", "frontend", _JS_ENTRY_CANDIDATES, 200),
        ("bootstrap", "next", _NEXT_ENTRY_CANDIDATES, 220),
        ("bootstrap", "nest", _NEST_ENTRY_CANDIDATES, 220),
        ("bootstrap", "python", _PYTHON_APP_CANDIDATES, 210),
        ("bootstrap", "go", _GO_ENTRY_CANDIDATES, 190),
        ("bootstrap", "ruby", _RUBY_ENTRY_CANDIDATES, 180),
    ]
    seen: set[str] = set()
    for kind, tag, candidates, score in runtime_candidates:
        for candidate in candidates:
            node = file_nodes.get(candidate)
            if node is None or node.id in seen:
                continue
            seen.add(node.id)
            items.append(
                _catalog_item(
                    node,
                    kind=kind,
                    title=node.name,
                    subtitle=_bootstrap_subtitle(node),
                    tags=["bootstrap", tag],
                    score=score,
                )
            )
    return items


def _resolve_python_script_target(
    repo_path: Path,
    module_name: str,
    symbol_name: str,
    file_nodes: dict[str, GraphNode],
    symbol_index: dict[tuple[str, str], list[GraphNode]],
) -> GraphNode | None:
    module_path = module_name.replace(".", "/")
    candidates = [f"{module_path}.py", f"src/{module_path}.py", f"{module_path}/__init__.py", f"src/{module_path}/__init__.py"]
    for candidate in candidates:
        rel_path = candidate.replace("\\", "/")
        symbol_candidates = symbol_index.get((rel_path, symbol_name.lower()), [])
        if symbol_candidates:
            return symbol_candidates[0]
        file_node = file_nodes.get(rel_path)
        if file_node is not None:
            return file_node
    return None


def _resolve_file_candidate(
    repo_path: Path,
    base_dir: Path,
    raw_path: str,
    file_nodes: dict[str, GraphNode],
) -> GraphNode | None:
    raw_path = raw_path.strip().strip("\"'")
    if not raw_path:
        return None
    candidate_path = (base_dir / raw_path).resolve()
    if not candidate_path.exists():
        candidate_path = (repo_path / raw_path).resolve()
    try:
        rel_path = str(candidate_path.relative_to(repo_path)).replace("\\", "/")
    except Exception:
        rel_path = raw_path.replace("\\", "/").lstrip("./")
    return _lookup_file_node(file_nodes, rel_path)


def _file_index(graph: KnowledgeGraph) -> dict[str, GraphNode]:
    return {
        node.file_path.replace("\\", "/"): node
        for node in graph.get_nodes_by_label(NodeLabel.FILE)
        if node.file_path
    }


def _symbol_index(graph: KnowledgeGraph) -> dict[tuple[str, str], list[GraphNode]]:
    index: dict[tuple[str, str], list[GraphNode]] = defaultdict(list)
    for label in (NodeLabel.FUNCTION, NodeLabel.METHOD, NodeLabel.CLASS):
        for node in graph.get_nodes_by_label(label):
            if node.file_path and node.name:
                index[(node.file_path.replace("\\", "/"), node.name.lower())].append(node)
    return index


def _endpoint_sort_key(node: GraphNode) -> tuple[str, str]:
    method = str(node.properties.get("http_method", ""))
    path = str(node.properties.get("path", node.name))
    return (path.lower(), method.lower(), node.file_path.lower())


def _symbol_sort_key(node: GraphNode) -> tuple[str, str, int]:
    return (node.file_path.lower(), node.name.lower(), node.start_line)


def _trace_title(node: GraphNode) -> str:
    if node.label == NodeLabel.API_ENDPOINT:
        return node.name.replace(":", " ", 1)
    return node.name


def _trace_subtitle(node: GraphNode) -> str:
    if node.label == NodeLabel.API_ENDPOINT:
        return _api_subtitle(node)
    if node.label == NodeLabel.FILE:
        return _bootstrap_subtitle(node)
    return _runtime_subtitle(node)


def _resolve_package_script_entry(
    repo_path: Path,
    package_dir: Path,
    script_name: str,
    scripts: dict[str, Any],
    file_nodes: dict[str, GraphNode],
    *,
    seen: set[str] | None = None,
) -> GraphNode | None:
    if seen is None:
        seen = set()
    if script_name in seen:
        return None
    seen.add(script_name)

    command = scripts.get(script_name)
    if not isinstance(command, str):
        return None
    return _resolve_js_command_entry(repo_path, package_dir, command, scripts, file_nodes, seen=seen)


def _resolve_js_command_entry(
    repo_path: Path,
    package_dir: Path,
    command: str,
    scripts: dict[str, Any],
    file_nodes: dict[str, GraphNode],
    *,
    seen: set[str],
) -> GraphNode | None:
    for segment in re.split(r"\s*(?:&&|\|\|)\s*", command):
        resolved = _resolve_js_command_segment(repo_path, package_dir, segment.strip(), scripts, file_nodes, seen=seen)
        if resolved is not None:
            return resolved
    return None


def _resolve_js_command_segment(
    repo_path: Path,
    package_dir: Path,
    command: str,
    scripts: dict[str, Any],
    file_nodes: dict[str, GraphNode],
    *,
    seen: set[str],
) -> GraphNode | None:
    if not command:
        return None

    try:
        tokens = shlex.split(command)
    except Exception:
        tokens = command.split()
    if not tokens:
        return None

    script_ref = _extract_nested_script_name(tokens)
    if script_ref:
        nested = _resolve_package_script_entry(repo_path, package_dir, script_ref, scripts, file_nodes, seen=seen)
        if nested is not None:
            return nested

    for token in tokens:
        if token.endswith((".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs")):
            direct = _resolve_file_candidate(repo_path, package_dir, token, file_nodes)
            if direct is not None:
                return direct

    lowered = [token.lower() for token in tokens]
    if "next" in lowered:
        return _first_existing_candidate(repo_path, package_dir, _NEXT_ENTRY_CANDIDATES, file_nodes)
    if "nest" in lowered:
        return _first_existing_candidate(repo_path, package_dir, _NEST_ENTRY_CANDIDATES, file_nodes)
    if "react-scripts" in lowered or "vite" in lowered:
        return _first_existing_candidate(repo_path, package_dir, _JS_ENTRY_CANDIDATES, file_nodes)
    if "ng" in lowered or "nx" in lowered:
        angular_entry = _resolve_angular_workspace_entry(repo_path, package_dir, file_nodes)
        if angular_entry is not None:
            return angular_entry
        return _first_existing_candidate(repo_path, package_dir, _JS_ENTRY_CANDIDATES, file_nodes)

    if any(token in lowered for token in ("node", "tsx", "ts-node", "bun", "deno")):
        match = _NODE_ENTRY_SCRIPT.search(command)
        if match:
            return _resolve_file_candidate(repo_path, package_dir, match.group("path"), file_nodes)

    return None


def _extract_nested_script_name(tokens: list[str]) -> str | None:
    option_with_value = {"--filter", "--workspace", "--cwd", "--dir", "-C"}
    cleaned: list[str] = []
    skip_next = False
    for token in tokens:
        if skip_next:
            skip_next = False
            continue
        if token in option_with_value:
            skip_next = True
            continue
        if token.startswith("--") and "=" in token:
            continue
        if token.startswith("--"):
            continue
        cleaned.append(token)
    if not cleaned:
        return None

    if len(cleaned) >= 3 and cleaned[0] in {"npm", "pnpm", "bun"} and cleaned[1] == "run":
        return cleaned[2]
    if len(cleaned) >= 2 and cleaned[0] == "yarn" and cleaned[1] in {"run", "npm"}:
        return cleaned[2] if len(cleaned) >= 3 else None
    if len(cleaned) >= 4 and cleaned[0] == "yarn" and cleaned[1] == "workspace":
        return cleaned[3] if len(cleaned) >= 4 else None
    if len(cleaned) >= 2 and cleaned[0] in {"pnpm", "yarn"} and cleaned[1] not in {"dlx", "exec", "workspace"}:
        return cleaned[1]
    return None


def _resolve_angular_workspace_entry(repo_path: Path, package_dir: Path, file_nodes: dict[str, GraphNode]) -> GraphNode | None:
    workspace_file = package_dir / "angular.json"
    if not workspace_file.exists():
        workspace_file = repo_path / "angular.json"
    if not workspace_file.exists():
        return None

    try:
        data = json.loads(workspace_file.read_text(encoding="utf-8"))
    except Exception:
        return None

    projects = data.get("projects", {}) if isinstance(data, dict) else {}
    if not isinstance(projects, dict):
        return None
    for project in projects.values():
        if not isinstance(project, dict):
            continue
        targets = project.get("architect") or project.get("targets") or {}
        if not isinstance(targets, dict):
            continue
        build = targets.get("build", {})
        if not isinstance(build, dict):
            continue
        options = build.get("options", {})
        if not isinstance(options, dict):
            continue
        for key in ("browser", "main"):
            entry = options.get(key)
            if isinstance(entry, str):
                node = _resolve_file_candidate(repo_path, workspace_file.parent, entry, file_nodes)
                if node is not None:
                    return node
    return None


def _discover_python_command_entries(base_dir: Path, data: dict[str, Any], file_nodes: dict[str, GraphNode]) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    commands: list[tuple[str, str]] = []

    uv_scripts = ((((data.get("tool") or {}).get("uv") or {}).get("scripts")) or {})
    if isinstance(uv_scripts, dict):
        commands.extend((name, value) for name, value in uv_scripts.items() if isinstance(value, str))

    hatch_envs = ((((data.get("tool") or {}).get("hatch") or {}).get("envs")) or {})
    if isinstance(hatch_envs, dict):
        for env in hatch_envs.values():
            if not isinstance(env, dict):
                continue
            scripts = env.get("scripts", {})
            if isinstance(scripts, dict):
                commands.extend((name, value) for name, value in scripts.items() if isinstance(value, str))

    for script_name, command in commands:
        node = _resolve_python_command_entry(base_dir, command, file_nodes)
        if node is None:
            continue
        items.append(
            _catalog_item(
                node,
                kind="manifest",
                title=f"{script_name}: {node.name}",
                subtitle=f"pyproject command · {node.file_path}",
                tags=["manifest", "python", script_name],
                score=315,
            )
        )

    return items


def _resolve_python_command_entry(base_dir: Path, command: str, file_nodes: dict[str, GraphNode]) -> GraphNode | None:
    match = re.search(r"(?:uvicorn|gunicorn)\s+([A-Za-z0-9_./]+):([A-Za-z_][A-Za-z0-9_]*)", command)
    if match:
        module_path = match.group(1).replace(".", "/")
        for candidate in (f"{module_path}.py", f"src/{module_path}.py", f"{module_path}/__init__.py", f"src/{module_path}/__init__.py"):
            node = _lookup_file_node(file_nodes, candidate)
            if node is not None:
                return node

    file_match = re.search(r"\b([\w./-]+\.py)\b", command)
    if file_match:
        raw = file_match.group(1)
        for candidate in (raw, f"src/{raw}", Path(raw).name):
            node = _lookup_file_node(file_nodes, candidate.replace("\\", "/"))
            if node is not None:
                return node

    for candidate in _PYTHON_APP_CANDIDATES:
        node = _lookup_file_node(file_nodes, candidate)
        if node is not None:
            return node
    return None


def _first_existing_candidate(
    repo_path: Path,
    base_dir: Path,
    candidates: tuple[str, ...],
    file_nodes: dict[str, GraphNode],
) -> GraphNode | None:
    for candidate in candidates:
        node = _resolve_file_candidate(repo_path, base_dir, candidate, file_nodes)
        if node is not None:
            return node
    return None


def _lookup_file_node(file_nodes: dict[str, GraphNode], candidate: str) -> GraphNode | None:
    normalized = candidate.replace("\\", "/").lstrip("./")
    direct = file_nodes.get(normalized)
    if direct is not None:
        return direct

    suffix_matches = [
        node
        for path, node in file_nodes.items()
        if path == normalized or path.endswith(f"/{normalized}")
    ]
    if len(suffix_matches) == 1:
        return suffix_matches[0]
    return None


def _api_subtitle(node: GraphNode) -> str:
    framework = str(node.properties.get("framework", "") or "").strip()
    parts = [framework] if framework else []
    if node.file_path:
        parts.append(node.file_path)
    return " · ".join(parts) if parts else "API endpoint"


def _runtime_subtitle(node: GraphNode) -> str:
    parts = [node.language] if node.language else []
    parts.append(node.file_path)
    return " · ".join(part for part in parts if part)


def _bootstrap_subtitle(node: GraphNode) -> str:
    parts = ["bootstrap"]
    if node.language:
        parts.append(node.language)
    if node.file_path:
        parts.append(node.file_path)
    return " · ".join(parts)


def _is_file(graph: KnowledgeGraph, node_id: str) -> bool:
    node = graph.get_node(node_id)
    return bool(node and node.label == NodeLabel.FILE)
