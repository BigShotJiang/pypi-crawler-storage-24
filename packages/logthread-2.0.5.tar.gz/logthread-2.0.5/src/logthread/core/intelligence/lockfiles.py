"""Lockfile-aware dependency truth for edit planning."""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def _read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return ""


def _safe_relative(path: Path, root: Path) -> str:
    try:
        return str(path.relative_to(root)).replace("\\", "/")
    except ValueError:
        return str(path).replace("\\", "/")


def _normalize_dep_name(name: str) -> str:
    return name.strip().lower()


def _parse_requirements_versions(path: Path) -> dict[str, str]:
    versions: dict[str, str] = {}
    for line in _read_text(path).splitlines():
        candidate = line.strip()
        if not candidate or candidate.startswith("#") or candidate.startswith("-"):
            continue
        if "==" not in candidate:
            continue
        name, version = candidate.split("==", 1)
        normalized = _normalize_dep_name(name.split("[", 1)[0])
        if normalized:
            versions[normalized] = version.strip()
    return versions


def _parse_poetry_lock(path: Path) -> dict[str, str]:
    versions: dict[str, str] = {}
    name: str | None = None
    version: str | None = None
    for raw_line in _read_text(path).splitlines():
        line = raw_line.strip()
        if line == "[[package]]":
            if name and version:
                versions[_normalize_dep_name(name)] = version
            name = None
            version = None
            continue
        if line.startswith("name = "):
            name = line.split("=", 1)[1].strip().strip("\"'")
        elif line.startswith("version = "):
            version = line.split("=", 1)[1].strip().strip("\"'")
    if name and version:
        versions[_normalize_dep_name(name)] = version
    return versions


def _parse_package_lock(path: Path) -> dict[str, dict[str, str]]:
    try:
        data = json.loads(_read_text(path) or "{}")
    except json.JSONDecodeError:
        logger.debug("Failed to parse package-lock.json: %s", path, exc_info=True)
        return {}

    root_requested = data.get("packages", {}).get("", {}).get("dependencies", {})
    if not isinstance(root_requested, dict):
        root_requested = data.get("dependencies", {})
    package_entries = data.get("packages", {})

    resolved: dict[str, dict[str, str]] = {}
    for name, requested_version in root_requested.items():
        dep_name = str(name)
        package_key = f"node_modules/{dep_name}"
        package_data = package_entries.get(package_key, {})
        resolved[dep_name.lower()] = {
            "requestedVersion": str(requested_version),
            "resolvedVersion": str(package_data.get("version") or requested_version),
            "source": "package-lock.json",
        }
    return resolved


def _parse_yarn_lock(path: Path) -> dict[str, dict[str, str]]:
    text = _read_text(path)
    if not text:
        return {}

    resolved: dict[str, dict[str, str]] = {}
    entry_key: str | None = None
    entry_version: str | None = None

    def flush() -> None:
        nonlocal entry_key, entry_version
        if not entry_key or not entry_version:
            entry_key = None
            entry_version = None
            return
        selectors = [item.strip().strip("\"'") for item in entry_key.split(",")]
        for selector in selectors:
            package_name = _package_name_from_yarn_selector(selector)
            if package_name:
                resolved[package_name.lower()] = {
                    "requestedVersion": selector,
                    "resolvedVersion": entry_version,
                    "source": "yarn.lock",
                }
        entry_key = None
        entry_version = None

    for raw_line in text.splitlines():
        if raw_line and not raw_line.startswith(" "):
            flush()
            if raw_line.rstrip().endswith(":"):
                entry_key = raw_line.rstrip()[:-1]
            continue
        stripped = raw_line.strip()
        if stripped.startswith("version "):
            entry_version = stripped.split(" ", 1)[1].strip().strip("\"'")
    flush()
    return resolved


def _package_name_from_yarn_selector(selector: str) -> str:
    selector = selector.strip().strip("\"'")
    if not selector:
        return ""
    if selector.startswith("@"):
        second_at = selector.find("@", 1)
        if second_at > 0:
            return selector[:second_at]
        return selector
    if "@" in selector:
        return selector.rsplit("@", 1)[0]
    return selector


def _parse_pnpm_lock(path: Path) -> dict[str, dict[str, dict[str, str]]]:
    text = _read_text(path)
    if not text:
        return {}

    importers: dict[str, dict[str, dict[str, str]]] = {}
    section = ""
    current_importer: str | None = None
    current_dep_group = ""
    current_dep_name: str | None = None

    for raw_line in text.splitlines():
        if not raw_line.strip():
            continue
        if re.match(r"^[^\s].*:\s*$", raw_line):
            section = raw_line.strip()[:-1]
            current_importer = None
            current_dep_group = ""
            current_dep_name = None
            continue
        if section != "importers":
            continue

        importer_match = re.match(r"^  ([^:\n]+):\s*$", raw_line)
        if importer_match:
            current_importer = importer_match.group(1).strip()
            importers.setdefault(current_importer, {})
            current_dep_group = ""
            current_dep_name = None
            continue

        group_match = re.match(r"^    (dependencies|devDependencies|optionalDependencies|peerDependencies):\s*$", raw_line)
        if group_match:
            current_dep_group = group_match.group(1)
            current_dep_name = None
            continue

        dep_match = re.match(r"^      ([^:\n]+):\s*$", raw_line)
        if dep_match and current_importer and current_dep_group:
            current_dep_name = dep_match.group(1).strip()
            importers[current_importer].setdefault(current_dep_name.lower(), {
                "requestedVersion": "",
                "resolvedVersion": "",
                "source": "pnpm-lock.yaml",
                "group": current_dep_group,
            })
            continue

        if not (current_importer and current_dep_group and current_dep_name):
            continue

        spec_match = re.match(r"^        specifier:\s+(.+)$", raw_line)
        if spec_match:
            importers[current_importer][current_dep_name.lower()]["requestedVersion"] = spec_match.group(1).strip().strip("\"'")
            continue

        version_match = re.match(r"^        version:\s+(.+)$", raw_line)
        if version_match:
            value = version_match.group(1).strip().strip("\"'")
            importers[current_importer][current_dep_name.lower()]["resolvedVersion"] = re.split(r"[ (]", value, maxsplit=1)[0]

    return importers


def _parse_packages_lock(path: Path) -> dict[str, dict[str, str]]:
    try:
        data = json.loads(_read_text(path) or "{}")
    except json.JSONDecodeError:
        logger.debug("Failed to parse packages.lock.json: %s", path, exc_info=True)
        return {}

    versions: dict[str, dict[str, str]] = {}

    def visit(mapping: dict[str, Any]) -> None:
        for name, payload in mapping.items():
            if not isinstance(payload, dict):
                continue
            resolved_version = str(payload.get("resolved") or payload.get("version") or "")
            requested_version = str(payload.get("requested") or payload.get("version") or "")
            versions[name.lower()] = {
                "requestedVersion": requested_version,
                "resolvedVersion": resolved_version,
                "source": "packages.lock.json",
            }
            nested = payload.get("dependencies")
            if isinstance(nested, dict):
                visit(nested)

    dependencies = data.get("dependencies")
    if isinstance(dependencies, dict):
        visit(dependencies)
    return versions


def _detect_project_lockfile(repo_path: Path, project: dict[str, Any]) -> tuple[str | None, Path | None]:
    root = repo_path / project["rootPath"]
    manifest = repo_path / project["manifestPath"]
    language = project.get("language")

    if language == "npm":
        candidates = [
            ("npm", root / "package-lock.json"),
            ("pnpm", repo_path / "pnpm-lock.yaml"),
            ("yarn", repo_path / "yarn.lock"),
        ]
    elif language == "python":
        candidates = [
            ("poetry", root / "poetry.lock"),
            ("requirements", root / "requirements.txt"),
        ]
    elif language == "csharp":
        candidates = [
            ("nuget", manifest.with_name("packages.lock.json")),
            ("nuget", root / "packages.lock.json"),
        ]
    else:
        return (None, None)

    for manager, path in candidates:
        if path.exists():
            return (manager, path)
    return (None, None)


def build_lockfile_truth(
    repo_path: Path,
    workspace_packet: dict[str, Any],
    *,
    project_ids: set[str] | None = None,
) -> dict[str, Any]:
    """Return resolved dependency truth for selected workspace projects."""
    repo_path = repo_path.resolve()
    target_projects = [
        project
        for project in workspace_packet.get("projects", [])
        if project_ids is None or project["id"] in project_ids
    ]

    project_truth: list[dict[str, Any]] = []
    missing_lockfiles: list[str] = []

    pnpm_cache: dict[str, dict[str, dict[str, dict[str, str]]]] = {}

    for project in target_projects:
        manager, lockfile_path = _detect_project_lockfile(repo_path, project)
        dependencies = project.get("dependencies") or {}
        resolved_entries: list[dict[str, Any]] = []

        if manager is None or lockfile_path is None:
            if dependencies:
                missing_lockfiles.append(
                    f"{project['name']} ({project['rootPath']}) has manifest dependencies but no supported lockfile for exact version truth."
                )
            project_truth.append({
                "projectId": project["id"],
                "projectName": project["name"],
                "projectKind": project["kind"],
                "rootPath": project["rootPath"],
                "manifestPath": project["manifestPath"],
                "packageManager": None,
                "lockfilePath": None,
                "dependencies": [],
            })
            continue

        if manager == "npm":
            resolved_versions = _parse_package_lock(lockfile_path)
        elif manager == "yarn":
            resolved_versions = _parse_yarn_lock(lockfile_path)
        elif manager == "poetry":
            poetry_versions = _parse_poetry_lock(lockfile_path)
            resolved_versions = {
                name: {
                    "requestedVersion": dependencies.get(name, ""),
                    "resolvedVersion": version,
                    "source": "poetry.lock",
                }
                for name, version in poetry_versions.items()
            }
        elif manager == "requirements":
            requirement_versions = _parse_requirements_versions(lockfile_path)
            resolved_versions = {
                name: {
                    "requestedVersion": dependencies.get(name, ""),
                    "resolvedVersion": version,
                    "source": "requirements.txt",
                }
                for name, version in requirement_versions.items()
            }
        elif manager == "nuget":
            resolved_versions = _parse_packages_lock(lockfile_path)
        elif manager == "pnpm":
            cache_key = str(lockfile_path.resolve())
            if cache_key not in pnpm_cache:
                pnpm_cache[cache_key] = _parse_pnpm_lock(lockfile_path)
            importers = pnpm_cache[cache_key]
            importer_key = "."
            if project["rootPath"] not in ("", "."):
                importer_key = project["rootPath"].replace("\\", "/")
            resolved_versions = importers.get(importer_key) or importers.get(".") or {}
        else:
            resolved_versions = {}

        for dep_name, requested_version in dependencies.items():
            resolved = resolved_versions.get(_normalize_dep_name(dep_name), {})
            resolved_entries.append({
                "name": dep_name,
                "requestedVersion": str(requested_version or resolved.get("requestedVersion") or ""),
                "resolvedVersion": str(resolved.get("resolvedVersion") or ""),
                "source": resolved.get("source") or _safe_relative(lockfile_path, repo_path),
                "isResolved": bool(resolved.get("resolvedVersion")),
            })

        project_truth.append({
            "projectId": project["id"],
            "projectName": project["name"],
            "projectKind": project["kind"],
            "rootPath": project["rootPath"],
            "manifestPath": project["manifestPath"],
            "packageManager": manager,
            "lockfilePath": _safe_relative(lockfile_path, repo_path),
            "dependencies": sorted(resolved_entries, key=lambda item: item["name"].lower()),
        })

    return {
        "kind": "lockfile_truth",
        "repoPath": str(repo_path),
        "projects": project_truth,
        "missingLockfiles": missing_lockfiles,
    }
