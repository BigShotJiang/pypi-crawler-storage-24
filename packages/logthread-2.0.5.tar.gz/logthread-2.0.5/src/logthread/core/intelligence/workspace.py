"""Workspace-level project/reference discovery for monorepos and multi-project repos."""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def _safe_relative(path: Path, root: Path) -> str:
    try:
        return str(path.relative_to(root)).replace("\\", "/")
    except ValueError:
        return str(path).replace("\\", "/")


def _read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return ""


def _extract_pyproject_name(content: str) -> str | None:
    project_match = re.search(r"(?ms)^\[project\].*?^name\s*=\s*[\"']([^\"']+)[\"']", content)
    if project_match:
        return project_match.group(1).strip()
    poetry_match = re.search(r"(?ms)^\[tool\.poetry\].*?^name\s*=\s*[\"']([^\"']+)[\"']", content)
    if poetry_match:
        return poetry_match.group(1).strip()
    return None


def _extract_pyproject_dependencies(content: str) -> list[str]:
    names: list[str] = []
    for match in re.finditer(r"(?ms)^\[project\].*?^dependencies\s*=\s*\[(.*?)\]", content):
        block = match.group(1)
        for item in re.findall(r"[\"']([^\"']+)[\"']", block):
            dep = re.split(r"[<>=!~ \[]", item, maxsplit=1)[0].strip()
            if dep:
                names.append(dep)
    poetry_block = re.search(r"(?ms)^\[tool\.poetry\.dependencies\](.*?)(?:^\[|\Z)", content)
    if poetry_block:
        for line in poetry_block.group(1).splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            name = line.split("=", 1)[0].strip().strip("\"'")
            if name and name.lower() != "python":
                names.append(name)
    return names


def _extract_csproj_name(path: Path, content: str) -> str:
    for tag in ("AssemblyName", "PackageId", "RootNamespace"):
        match = re.search(rf"<{tag}>([^<]+)</{tag}>", content)
        if match and match.group(1).strip():
            return match.group(1).strip()
    return path.stem


def _extract_csproj_refs(path: Path, content: str) -> list[Path]:
    refs: list[Path] = []
    for match in re.finditer(r'<ProjectReference[^>]*Include="([^"]+)"', content):
        candidate = (path.parent / match.group(1)).resolve()
        refs.append(candidate)
    return refs


def _extract_package_json_deps(data: dict[str, Any]) -> dict[str, str]:
    deps: dict[str, str] = {}
    for section in ("dependencies", "devDependencies", "peerDependencies", "optionalDependencies"):
        raw = data.get(section)
        if isinstance(raw, dict):
            for name, version in raw.items():
                deps[str(name)] = str(version)
    return deps


def _scan_solution_memberships(repo_path: Path) -> dict[str, list[str]]:
    memberships: dict[str, list[str]] = {}
    for sln in repo_path.rglob("*.sln"):
        text = _read_text(sln)
        if not text:
            continue
        solution_name = sln.stem
        for match in re.finditer(r'Project\([^\n]+\)\s*=\s*"[^"]+",\s*"([^"]+\.csproj)"', text):
            proj_path = (sln.parent / match.group(1)).resolve()
            memberships.setdefault(str(proj_path), []).append(solution_name)
    return memberships


def build_workspace_map(repo_path: Path) -> dict[str, Any]:
    """Build a structured map of internal projects and project references."""
    repo_path = repo_path.resolve()
    projects: list[dict[str, Any]] = []
    project_index_by_name: dict[str, str] = {}
    project_index_by_manifest: dict[str, str] = {}
    workspace_managers: list[dict[str, str]] = []
    references: list[dict[str, Any]] = []
    unresolved: list[str] = []

    if (repo_path / "pnpm-workspace.yaml").exists():
        workspace_managers.append({
            "name": "pnpm",
            "path": "pnpm-workspace.yaml",
            "detail": "Workspace root detected",
        })
    if (repo_path / "package-lock.json").exists():
        workspace_managers.append({
            "name": "npm",
            "path": "package-lock.json",
            "detail": "npm lockfile detected",
        })
    if (repo_path / "yarn.lock").exists():
        workspace_managers.append({
            "name": "yarn",
            "path": "yarn.lock",
            "detail": "Yarn workspace-compatible lockfile detected",
        })
    if any(repo_path.glob("*.sln")):
        workspace_managers.append({
            "name": ".NET solution",
            "path": _safe_relative(next(repo_path.glob("*.sln")), repo_path),
            "detail": "Solution file detected",
        })

    solution_memberships = _scan_solution_memberships(repo_path)

    for path in repo_path.rglob("package.json"):
        if "node_modules" in path.parts:
            continue
        try:
            data = json.loads(_read_text(path) or "{}")
        except json.JSONDecodeError:
            logger.debug("Failed to parse package.json: %s", path, exc_info=True)
            continue
        name = str(data.get("name") or path.parent.name).strip()
        project_id = f"npm:{_safe_relative(path.parent, repo_path)}"
        record = {
            "id": project_id,
            "name": name,
            "kind": "npm_package",
            "language": "npm",
            "rootPath": _safe_relative(path.parent, repo_path),
            "manifestPath": _safe_relative(path, repo_path),
            "dependencies": _extract_package_json_deps(data),
            "solutionMemberships": [],
        }
        projects.append(record)
        project_index_by_name[name] = project_id
        project_index_by_manifest[str(path.resolve())] = project_id

    for path in repo_path.rglob("pyproject.toml"):
        if ".venv" in path.parts or "venv" in path.parts or "node_modules" in path.parts:
            continue
        content = _read_text(path)
        if not content:
            continue
        name = _extract_pyproject_name(content) or path.parent.name
        project_id = f"python:{_safe_relative(path.parent, repo_path)}"
        record = {
            "id": project_id,
            "name": name,
            "kind": "python_package",
            "language": "python",
            "rootPath": _safe_relative(path.parent, repo_path),
            "manifestPath": _safe_relative(path, repo_path),
            "dependencies": {dep: "" for dep in _extract_pyproject_dependencies(content)},
            "solutionMemberships": [],
        }
        projects.append(record)
        project_index_by_name.setdefault(name, project_id)
        project_index_by_manifest[str(path.resolve())] = project_id

    for path in repo_path.rglob("go.mod"):
        if "vendor" in path.parts:
            continue
        content = _read_text(path)
        module_match = re.search(r"(?m)^module\s+(.+)$", content)
        name = module_match.group(1).strip() if module_match else path.parent.name
        project_id = f"go:{_safe_relative(path.parent, repo_path)}"
        record = {
            "id": project_id,
            "name": name,
            "kind": "go_module",
            "language": "go",
            "rootPath": _safe_relative(path.parent, repo_path),
            "manifestPath": _safe_relative(path, repo_path),
            "dependencies": {},
            "solutionMemberships": [],
        }
        projects.append(record)
        project_index_by_name.setdefault(name, project_id)
        project_index_by_manifest[str(path.resolve())] = project_id

    csproj_refs: dict[str, list[Path]] = {}
    for path in repo_path.rglob("*.csproj"):
        content = _read_text(path)
        if not content:
            continue
        name = _extract_csproj_name(path, content)
        project_id = f"dotnet:{_safe_relative(path, repo_path)}"
        record = {
            "id": project_id,
            "name": name,
            "kind": "dotnet_project",
            "language": "csharp",
            "rootPath": _safe_relative(path.parent, repo_path),
            "manifestPath": _safe_relative(path, repo_path),
            "dependencies": {},
            "solutionMemberships": solution_memberships.get(str(path.resolve()), []),
        }
        projects.append(record)
        project_index_by_name.setdefault(name, project_id)
        project_index_by_manifest[str(path.resolve())] = project_id
        csproj_refs[project_id] = _extract_csproj_refs(path, content)

    seen_refs: set[tuple[str, str, str]] = set()

    for project in projects:
        source_id = project["id"]
        for dep_name, version in (project.get("dependencies") or {}).items():
            target_id = project_index_by_name.get(dep_name)
            if not target_id or target_id == source_id:
                continue
            ref_type = "workspace_dependency" if str(version).startswith("workspace:") else "internal_dependency"
            key = (source_id, target_id, ref_type)
            if key in seen_refs:
                continue
            seen_refs.add(key)
            references.append({
                "sourceProjectId": source_id,
                "targetProjectId": target_id,
                "type": ref_type,
                "via": dep_name,
            })

    for source_id, targets in csproj_refs.items():
        for target_path in targets:
            target_id = project_index_by_manifest.get(str(target_path))
            if not target_id:
                unresolved.append(
                    f"{source_id} references {_safe_relative(target_path, repo_path)} but the target project was not indexed in this workspace scan."
                )
                continue
            key = (source_id, target_id, "project_reference")
            if key in seen_refs:
                continue
            seen_refs.add(key)
            references.append({
                "sourceProjectId": source_id,
                "targetProjectId": target_id,
                "type": "project_reference",
                "via": _safe_relative(target_path, repo_path),
            })

    project_names = {item["id"]: item["name"] for item in projects}
    outgoing: dict[str, list[dict[str, Any]]] = {item["id"]: [] for item in projects}
    incoming_count: dict[str, int] = {item["id"]: 0 for item in projects}

    for ref in references:
        outgoing.setdefault(ref["sourceProjectId"], []).append({
            "targetProjectId": ref["targetProjectId"],
            "targetName": project_names.get(ref["targetProjectId"], ref["targetProjectId"]),
            "type": ref["type"],
            "via": ref["via"],
        })
        incoming_count[ref["targetProjectId"]] = incoming_count.get(ref["targetProjectId"], 0) + 1

    enriched_projects = [
        {
            **item,
            "internalReferenceCount": len(outgoing.get(item["id"], [])),
            "incomingReferenceCount": incoming_count.get(item["id"], 0),
            "outgoingReferences": sorted(
                outgoing.get(item["id"], []),
                key=lambda ref: (ref["targetName"], ref["type"]),
            ),
        }
        for item in sorted(projects, key=lambda item: (item["kind"], item["rootPath"]))
    ]

    summary = (
        f"Detected {len(enriched_projects)} internal projects and {len(references)} internal references "
        f"across {len(workspace_managers)} workspace manager or solution signals."
    )
    return {
        "kind": "workspace_map",
        "summary": summary,
        "repoPath": str(repo_path),
        "workspaceManagers": workspace_managers,
        "projects": enriched_projects,
        "references": references,
        "unresolvedAmbiguities": unresolved,
    }

