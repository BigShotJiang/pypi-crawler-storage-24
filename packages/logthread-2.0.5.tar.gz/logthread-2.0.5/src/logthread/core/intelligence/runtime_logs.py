"""Runtime log intelligence for provider-backed local analysis."""

from __future__ import annotations

import hashlib
import json
import logging
import re
import shlex
import time
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import httpx

from logthread.core.graph.graph import KnowledgeGraph
from logthread.core.graph.model import GraphNode, NodeLabel
from logthread.core.parsers.sql_lang import extract_tables_from_query
from logthread.core.provenance import (
    infer_node_capability_tier,
    serialize_confidence,
    serialize_provenance,
)
from logthread.core.storage.paths import get_project_cache_dir, get_project_dir
from logthread.core.storage.secret_store import (
    SecretStoreUnavailable,
    delete_secret,
    load_secret,
    store_secret,
)

logger = logging.getLogger(__name__)

_MAX_EVENTS = 400
_MAX_PATTERN_MATCHES = 6
_STOPWORDS = {
    "the", "and", "for", "with", "this", "that", "from", "into", "your", "http",
    "https", "user", "users", "null", "none", "true", "false", "error", "warn",
    "info", "debug", "request", "response", "failed", "failure", "exception",
    "message", "trace", "span", "session", "query", "service", "route", "path",
    "code", "line", "file", "function", "class", "level", "status", "value",
    "data", "json", "api", "log", "logs", "runtime", "local", "remote", "provider",
}
_UUID_RE = re.compile(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\b", re.I)
_HEX_RE = re.compile(r"\b0x[a-f0-9]+\b", re.I)
_NUMBER_RE = re.compile(r"\b\d+\b")
_PATH_RE = re.compile(r"(?:[A-Za-z]:)?[/~][A-Za-z0-9._/\-]+")
_QUOTED_RE = re.compile(r'(["\']).*?\1')
_TOKEN_RE = re.compile(r"[a-zA-Z][a-zA-Z0-9_.:/-]{2,}")
_ROUTE_RE = re.compile(r"\b(?:GET|POST|PUT|PATCH|DELETE|OPTIONS|HEAD)\s+(/[A-Za-z0-9_./:-]+)")
_JS_STACK_RE = re.compile(r"at\s+(?P<fn>[A-Za-z0-9_$.<>-]+)?\s*\(?(?P<path>[^():\s]+(?:/[^():\s]+)+):\d+:\d+\)?")
_PY_STACK_RE = re.compile(r'File "(?P<path>[^"]+)", line \d+, in (?P<fn>[A-Za-z0-9_<>]+)')
_LEVEL_RE = re.compile(r"\b(trace|debug|info|warning|warn|error|fatal|critical)\b", re.I)
_SQL_TABLE_RE = re.compile(r"\b(?:from|join|update|into|table)\s+([A-Za-z_][A-Za-z0-9_.]*)", re.I)
_SENSITIVE_KEY_RE = re.compile(r"(password|passwd|secret|token|api[_-]?key|authorization|cookie|session|email|phone|ssn)", re.I)
_TRACEPARENT_RE = re.compile(r"\b[0-9a-f]{2}-(?P<trace>[0-9a-f]{32})-(?P<span>[0-9a-f]{16})-[0-9a-f]{2}\b", re.I)
_B3_RE = re.compile(
    r"\b(?P<trace>[0-9a-f]{16,32})-(?P<span>[0-9a-f]{16})(?:-[0-9a-f]+)?(?:-(?P<parent>[0-9a-f]{16}))?\b",
    re.I,
)
_AWS_TRACE_ROOT_RE = re.compile(r"\bRoot=1-(?P<epoch>[0-9a-f]{8})-(?P<trace>[0-9a-f]{24})\b", re.I)
_AWS_TRACE_PARENT_RE = re.compile(r"\bParent=(?P<parent>[0-9a-f]{16})\b", re.I)

_PROVIDER_CATALOG: dict[str, dict[str, Any]] = {
    "loki": {
        "label": "Grafana Loki",
        "authFields": ["bearer_token"],
        "defaultBaseUrl": "https://loki.example.com",
        "queryHelp": "Use LogQL, for example `{service=\"api\"} |= \"error\"`.",
    },
    "datadog": {
        "label": "Datadog Logs",
        "authFields": ["api_key", "app_key"],
        "defaultBaseUrl": "https://api.datadoghq.com",
        "queryHelp": "Use Datadog log search syntax, for example `service:api status:error`.",
    },
    "splunk": {
        "label": "Splunk",
        "authFields": ["username", "password"],
        "defaultBaseUrl": "https://splunk.example.com",
        "queryHelp": "Use Splunk search syntax, for example `index=main error`.",
    },
    "sumologic": {
        "label": "Sumo Logic",
        "authFields": ["access_id", "access_key"],
        "defaultBaseUrl": "https://api.us2.sumologic.com",
        "queryHelp": "Use Sumo query syntax, for example `_sourceCategory=api error`.",
    },
}


@dataclass(slots=True)
class RuntimeConnector:
    id: str
    name: str
    provider: str
    base_url: str
    credential_fields: list[str]
    credentials: dict[str, str]
    correlation_hints: list[str]
    default_source: str | None = None
    verify_tls: bool = True
    created_at: str | None = None
    updated_at: str | None = None


@dataclass(slots=True)
class NormalizedLogEvent:
    id: str
    provider: str
    timestamp: str
    level: str
    message: str
    service: str | None
    env: str | None
    host: str | None
    source: str | None
    route: str | None
    path: str | None
    method: str | None
    status_code: int | None
    trace_id: str | None
    span_id: str | None
    parent_span_id: str | None
    correlation_id: str | None
    request_id: str | None
    session_id: str | None
    user_id: str | None
    logger: str | None
    exception_type: str | None
    latency_ms: float | None
    db_statement: str | None
    db_tables: list[str]
    code_files: list[str]
    code_functions: list[str]
    structured_kind: str
    attributes: dict[str, Any]
    raw: dict[str, Any]
    template: str
    keywords: list[str]
    schema_signature: str


def list_runtime_providers() -> list[dict[str, Any]]:
    return [
        {
            "id": provider_id,
            "label": config["label"],
            "authFields": config["authFields"],
            "defaultBaseUrl": config["defaultBaseUrl"],
            "queryHelp": config["queryHelp"],
        }
        for provider_id, config in _PROVIDER_CATALOG.items()
    ]


def list_runtime_connectors(repo_path: Path) -> list[dict[str, Any]]:
    return [_serialize_connector(record) for record in _load_connectors(repo_path)]


def save_runtime_connector(
    repo_path: Path,
    *,
    connector_id: str | None,
    name: str,
    provider: str,
    base_url: str,
    credentials: dict[str, str],
    correlation_hints: list[str] | None = None,
    default_source: str | None = None,
    verify_tls: bool = True,
) -> dict[str, Any]:
    provider_key = provider.strip().lower()
    if provider_key not in _PROVIDER_CATALOG:
        raise ValueError(f"Unsupported provider: {provider}")
    if not name.strip():
        raise ValueError("Connector name is required")
    if not base_url.strip():
        raise ValueError("Base URL is required")

    records = _load_connectors(repo_path)
    required = _PROVIDER_CATALOG[provider_key]["authFields"]
    now = datetime.now(tz=timezone.utc).isoformat()
    normalized_credentials = {
        key: str(value).strip()
        for key, value in credentials.items()
        if str(value).strip()
    }
    normalized_hints = sorted({hint.strip() for hint in (correlation_hints or []) if hint.strip()})

    if connector_id:
        for record in records:
            if record.id == connector_id:
                merged_credentials = dict(record.credentials)
                merged_credentials.update(normalized_credentials)
                missing = [field for field in required if not str(merged_credentials.get(field, "")).strip()]
                if missing:
                    raise ValueError(f"Missing credentials: {', '.join(missing)}")
                record.name = name.strip()
                record.provider = provider_key
                record.base_url = base_url.rstrip("/")
                record.credential_fields = sorted(merged_credentials.keys())
                record.credentials = merged_credentials
                record.correlation_hints = normalized_hints
                record.default_source = default_source.strip() if default_source else None
                record.verify_tls = verify_tls
                record.updated_at = now
                _save_connectors(repo_path, records)
                return _serialize_connector(record)

    missing = [field for field in required if not str(normalized_credentials.get(field, "")).strip()]
    if missing:
        raise ValueError(f"Missing credentials: {', '.join(missing)}")

    record = RuntimeConnector(
        id=connector_id or _stable_connector_id(repo_path, name, provider_key, base_url),
        name=name.strip(),
        provider=provider_key,
        base_url=base_url.rstrip("/"),
        credential_fields=sorted(normalized_credentials.keys()),
        credentials=normalized_credentials,
        correlation_hints=normalized_hints,
        default_source=default_source.strip() if default_source else None,
        verify_tls=verify_tls,
        created_at=now,
        updated_at=now,
    )
    records.append(record)
    _save_connectors(repo_path, records)
    return _serialize_connector(record)


def delete_runtime_connector(repo_path: Path, connector_id: str) -> bool:
    records = _load_connectors(repo_path)
    kept = [record for record in records if record.id != connector_id]
    if len(kept) == len(records):
        return False
    try:
        delete_secret(repo_path, "runtime-connector", connector_id)
    except SecretStoreUnavailable:
        logger.warning("Secure secret backend unavailable while deleting connector %s", connector_id)
    _save_connectors(repo_path, kept)
    return True


def test_runtime_connector(repo_path: Path, connector_id: str) -> dict[str, Any]:
    connector = _get_connector(repo_path, connector_id)
    started = time.time()
    with _build_client(connector) as client:
        provider = connector.provider
        if provider == "loki":
            response = client.get(
                _provider_url(connector, "/loki/api/v1/labels"),
                params={"start": int((time.time() - 300) * 1_000_000_000), "end": int(time.time() * 1_000_000_000)},
            )
            response.raise_for_status()
        elif provider == "datadog":
            response = client.get(_provider_url(connector, "/api/v1/validate"))
            response.raise_for_status()
        elif provider == "splunk":
            response = client.get(
                _provider_url(connector, "/services/server/info"),
                params={"output_mode": "json"},
            )
            response.raise_for_status()
        elif provider == "sumologic":
            response = client.get(_provider_url(connector, "/api/v1/collectors"), params={"limit": 1, "offset": 0})
            response.raise_for_status()
        else:
            raise ValueError(f"Unsupported provider: {provider}")

    return {
        "ok": True,
        "connectorId": connector.id,
        "provider": connector.provider,
        "latencyMs": int((time.time() - started) * 1000),
    }


def get_latest_runtime_analysis(repo_path: Path) -> dict[str, Any] | None:
    cache_path = _analysis_cache_path(repo_path)
    if not cache_path.exists():
        return None
    try:
        return json.loads(cache_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def query_runtime_logs(
    repo_path: Path,
    graph: KnowledgeGraph,
    *,
    connector_id: str,
    query: str,
    start_time: str | None = None,
    end_time: str | None = None,
    hours: int = 2,
    limit: int = 150,
    source: str | None = None,
) -> dict[str, Any]:
    connector = _get_connector(repo_path, connector_id)
    window_end = _parse_datetime(end_time) or datetime.now(tz=timezone.utc)
    window_start = _parse_datetime(start_time) or (window_end - timedelta(hours=max(hours, 1)))
    bounded_limit = max(1, min(limit, _MAX_EVENTS))
    previous_packet = get_latest_runtime_analysis(repo_path)

    raw_events = _fetch_provider_logs(
        connector,
        query=query,
        start_time=window_start,
        end_time=window_end,
        limit=bounded_limit,
        source=source or connector.default_source,
    )
    normalized = [_normalize_event(connector.provider, item, correlation_hints=connector.correlation_hints) for item in raw_events]
    normalized = [event for event in normalized if event.message]
    normalized.sort(key=lambda event: event.timestamp, reverse=True)

    graph_lookup = _build_graph_lookup(graph)
    pattern_map: dict[str, dict[str, Any]] = {}
    field_counts: Counter[str] = Counter()
    service_counts: Counter[str] = Counter()
    route_counts: Counter[str] = Counter()
    level_counts: Counter[str] = Counter()
    keyword_counts: Counter[str] = Counter()
    trace_groups: dict[str, dict[str, Any]] = {}
    schema_groups: dict[str, dict[str, Any]] = {}
    sensitive_signals: dict[str, dict[str, Any]] = {}
    json_events = 0
    structured_events = 0
    trace_linked_events = 0
    span_linked_events = 0
    service_linked_events = 0
    route_linked_events = 0
    exception_events = 0
    code_hint_events = 0
    correlation_linked_events = 0
    inferred_linked_events = 0

    event_rows: list[dict[str, Any]] = []
    for event in normalized:
        if event.structured_kind == "json":
            json_events += 1
        if event.attributes:
            structured_events += 1
        for field in event.attributes:
            field_counts[field] += 1
        if event.service:
            service_counts[event.service] += 1
        if event.route:
            route_counts[event.route] += 1
        level_counts[event.level] += 1
        for keyword in event.keywords:
            keyword_counts[keyword] += 1
        if event.trace_id:
            trace_linked_events += 1
        if event.span_id:
            span_linked_events += 1
        if event.request_id or event.correlation_id or event.session_id:
            correlation_linked_events += 1
        if event.service:
            service_linked_events += 1
        if event.route or event.path:
            route_linked_events += 1
        if event.exception_type:
            exception_events += 1
        if event.code_files or event.code_functions or event.db_tables:
            code_hint_events += 1

        correlation = _correlate_event(graph_lookup, event)
        journey_link = _infer_journey_link(event)
        if journey_link and journey_link["linkageMode"] == "derived":
            inferred_linked_events += 1
        event_row = {
            "id": event.id,
            "timestamp": event.timestamp,
            "level": event.level,
            "message": event.message,
            "service": event.service,
            "env": event.env,
            "host": event.host,
            "source": event.source,
            "route": event.route,
            "method": event.method,
            "statusCode": event.status_code,
            "traceId": event.trace_id,
            "spanId": event.span_id,
            "parentSpanId": event.parent_span_id,
            "correlationId": event.correlation_id,
            "requestId": event.request_id,
            "sessionId": event.session_id,
            "userId": event.user_id,
            "logger": event.logger,
            "exceptionType": event.exception_type,
            "latencyMs": event.latency_ms,
            "structuredKind": event.structured_kind,
            "keywords": event.keywords,
            "attributes": event.attributes,
            "dbTables": event.db_tables,
            "codeFiles": event.code_files,
            "codeFunctions": event.code_functions,
            "correlationType": journey_link["correlationType"] if journey_link else None,
            "linkageMode": journey_link["linkageMode"] if journey_link else "none",
            "linkConfidence": journey_link["confidence"] if journey_link else "low",
            "linkReason": journey_link["linkReason"] if journey_link else "No correlation identifiers or stable runtime dimensions were found for this event.",
            "related": correlation,
        }
        event_rows.append(event_row)

        schema_bucket = schema_groups.setdefault(
            event.schema_signature,
            {
                "signature": event.schema_signature,
                "count": 0,
                "structuredKind": event.structured_kind,
                "fields": Counter(),
                "services": Counter(),
                "levels": Counter(),
                "patternIds": Counter(),
            },
        )
        schema_bucket["count"] += 1
        schema_bucket["levels"][event.level] += 1
        if event.service:
            schema_bucket["services"][event.service] += 1
        for field in event.attributes.keys():
            schema_bucket["fields"][field] += 1

        bucket = pattern_map.setdefault(
            event.template,
            {
                "id": hashlib.sha1(event.template.encode("utf-8")).hexdigest()[:12],
                "template": event.template,
                "sampleMessage": event.message,
                "count": 0,
                "firstSeen": event.timestamp,
                "lastSeen": event.timestamp,
                "levels": Counter(),
                "services": Counter(),
                "routes": Counter(),
                "exceptions": Counter(),
                "keywords": Counter(),
                "structuredFields": Counter(),
                "sampleEventIds": [],
                "related": {"apis": {}, "files": {}, "tables": {}, "dependencies": {}},
            },
        )
        bucket["count"] += 1
        bucket["levels"][event.level] += 1
        if event.service:
            bucket["services"][event.service] += 1
        if event.route:
            bucket["routes"][event.route] += 1
        if event.exception_type:
            bucket["exceptions"][event.exception_type] += 1
        for keyword in event.keywords:
            bucket["keywords"][keyword] += 1
        for field in list(event.attributes.keys())[:20]:
            bucket["structuredFields"][field] += 1
        if len(bucket["sampleEventIds"]) < 6:
            bucket["sampleEventIds"].append(event.id)
        bucket["firstSeen"] = min(bucket["firstSeen"], event.timestamp)
        bucket["lastSeen"] = max(bucket["lastSeen"], event.timestamp)
        for key in ("apis", "files", "tables", "dependencies"):
            for node in correlation[key]:
                bucket["related"][key][node["id"]] = node

        if journey_link:
            sequence = trace_groups.setdefault(
                journey_link["key"],
                {
                    "correlationId": journey_link["correlationId"],
                    "correlationType": journey_link["correlationType"],
                    "linkageMode": journey_link["linkageMode"],
                    "linkReason": journey_link["linkReason"],
                    "confidence": journey_link["confidence"],
                    "count": 0,
                    "firstSeen": event.timestamp,
                    "lastSeen": event.timestamp,
                    "levels": Counter(),
                    "services": Counter(),
                    "routes": Counter(),
                    "patternIds": Counter(),
                    "related": {"apis": {}, "files": {}, "tables": {}, "dependencies": {}},
                    "events": [],
                },
            )
            sequence["count"] += 1
            sequence["levels"][event.level] += 1
            if event.service:
                sequence["services"][event.service] += 1
            if event.route:
                sequence["routes"][event.route] += 1
            sequence["patternIds"][bucket["id"]] += 1
            sequence["firstSeen"] = min(sequence["firstSeen"], event.timestamp)
            sequence["lastSeen"] = max(sequence["lastSeen"], event.timestamp)
            for key in ("apis", "files", "tables", "dependencies"):
                for node in correlation[key]:
                    sequence["related"][key][node["id"]] = node
            sequence["events"].append(
                {
                    "id": event.id,
                    "timestamp": event.timestamp,
                    "level": event.level,
                    "message": event.message,
                    "service": event.service,
                    "route": event.route or event.path,
                    "statusCode": event.status_code,
                    "exceptionType": event.exception_type,
                    "latencyMs": event.latency_ms,
                    "traceId": event.trace_id,
                    "requestId": event.request_id,
                    "sessionId": event.session_id,
                    "correlationId": event.correlation_id,
                    "linkageMode": journey_link["linkageMode"],
                    "linkReason": journey_link["linkReason"],
                    "related": correlation,
                }
            )

        for field, value in _detect_sensitive_values(event.attributes, event.message):
            signal = sensitive_signals.setdefault(
                field,
                {"field": field, "kind": _sensitive_kind(field), "count": 0, "examples": []},
            )
            signal["count"] += 1
            if len(signal["examples"]) < 3 and value not in signal["examples"]:
                signal["examples"].append(value)

    patterns = [
        {
            "id": bucket["id"],
            "template": bucket["template"],
            "sampleMessage": bucket["sampleMessage"],
            "count": bucket["count"],
            "firstSeen": bucket["firstSeen"],
            "lastSeen": bucket["lastSeen"],
            "levels": _counter_list(bucket["levels"]),
            "services": _counter_list(bucket["services"]),
            "routes": _counter_list(bucket["routes"]),
            "exceptions": _counter_list(bucket["exceptions"]),
            "keywords": _counter_list(bucket["keywords"], limit=10),
            "structuredFields": _counter_list(bucket["structuredFields"], limit=12),
            "sampleEventIds": bucket["sampleEventIds"],
            "related": {
                key: list(bucket["related"][key].values())[:_MAX_PATTERN_MATCHES]
                for key in ("apis", "files", "tables", "dependencies")
            },
        }
        for bucket in pattern_map.values()
    ]
    patterns.sort(key=lambda item: (-item["count"], item["template"]))

    for pattern in patterns:
        schema_bucket = schema_groups.get(
            next(
                (
                    normalized_event.schema_signature
                    for normalized_event in normalized
                    if normalized_event.template == pattern["template"]
                ),
                "plain",
            )
        )
        if schema_bucket:
            schema_bucket["patternIds"][pattern["id"]] += pattern["count"]

    sequences = [
        {
            "correlationId": sequence["correlationId"],
            "correlationType": sequence["correlationType"],
            "linkageMode": sequence["linkageMode"],
            "linkReason": sequence["linkReason"],
            "confidence": sequence["confidence"],
            "count": sequence["count"],
            "firstSeen": sequence["firstSeen"],
            "lastSeen": sequence["lastSeen"],
            "durationSeconds": _sequence_duration_seconds(sequence["firstSeen"], sequence["lastSeen"]),
            "errorCount": sum(sequence["levels"].get(level, 0) for level in ("error", "fatal", "critical")),
            "avgLatencyMs": _sequence_avg_latency(sequence["events"]),
            "maxLatencyMs": _sequence_max_latency(sequence["events"]),
            "rootCauseSummary": _sequence_root_cause(sequence["events"]),
            "levels": _counter_list(sequence["levels"]),
            "services": _counter_list(sequence["services"], limit=5),
            "routes": _counter_list(sequence["routes"], limit=5),
            "patternIds": _counter_list(sequence["patternIds"], limit=6),
            "related": {
                key: list(sequence["related"][key].values())[:_MAX_PATTERN_MATCHES]
                for key in ("apis", "files", "tables", "dependencies")
            },
            "events": _sequence_timeline(sequence["events"]),
        }
        for sequence in trace_groups.values()
    ]
    sequences.sort(key=lambda item: (-item["count"], item["correlationId"]))

    schemas = [
        {
            "signature": signature,
            "count": bucket["count"],
            "structuredKind": bucket["structuredKind"],
            "fields": _counter_list(bucket["fields"], limit=16),
            "services": _counter_list(bucket["services"], limit=5),
            "levels": _counter_list(bucket["levels"], limit=5),
            "patternIds": _counter_list(bucket["patternIds"], limit=6),
        }
        for signature, bucket in schema_groups.items()
    ]
    schemas.sort(key=lambda item: (-item["count"], item["signature"]))

    errors = level_counts.get("error", 0) + level_counts.get("fatal", 0) + level_counts.get("critical", 0)
    baseline = _compare_against_baseline(previous_packet, patterns, connector.id, query)
    semantic_coverage = {
        "traceIdRate": round(trace_linked_events / len(event_rows), 3) if event_rows else 0.0,
        "spanIdRate": round(span_linked_events / len(event_rows), 3) if event_rows else 0.0,
        "correlationIdRate": round(correlation_linked_events / len(event_rows), 3) if event_rows else 0.0,
        "inferredLinkRate": round(inferred_linked_events / len(event_rows), 3) if event_rows else 0.0,
        "serviceRate": round(service_linked_events / len(event_rows), 3) if event_rows else 0.0,
        "routeRate": round(route_linked_events / len(event_rows), 3) if event_rows else 0.0,
        "exceptionRate": round(exception_events / len(event_rows), 3) if event_rows else 0.0,
        "codeHintRate": round(code_hint_events / len(event_rows), 3) if event_rows else 0.0,
    }
    instrumentation_findings = _build_instrumentation_findings(
        semantic_coverage,
        schemas=schemas,
        sensitive_signals=list(sensitive_signals.values()),
        events=event_rows,
    )
    packet = {
        "kind": "runtime_log_analysis",
        "connector": _serialize_connector(connector),
        "correlationConfig": {
            "customHints": connector.correlation_hints,
            "standardHints": [
                "traceparent",
                "b3",
                "x-b3-traceid",
                "x-request-id",
                "x-correlation-id",
                "x-amzn-trace-id",
            ],
        },
        "query": {
            "text": query,
            "startTime": window_start.isoformat(),
            "endTime": window_end.isoformat(),
            "hours": hours,
            "limit": bounded_limit,
            "source": source or connector.default_source,
        },
        "stats": {
            "events": len(event_rows),
            "patterns": len(patterns),
            "sequences": len(sequences),
            "explicitSequences": sum(1 for item in sequences if item["linkageMode"] == "explicit"),
            "inferredSequences": sum(1 for item in sequences if item["linkageMode"] == "derived"),
            "services": len(service_counts),
            "routes": len(route_counts),
            "structuredRate": round(structured_events / len(event_rows), 3) if event_rows else 0.0,
            "jsonRate": round(json_events / len(event_rows), 3) if event_rows else 0.0,
            "errorRate": round(errors / len(event_rows), 3) if event_rows else 0.0,
        },
        "semanticCoverage": semantic_coverage,
        "baselineComparison": baseline,
        "schemaGroups": schemas[:12],
        "instrumentationFindings": instrumentation_findings,
        "sensitiveSignals": sorted(sensitive_signals.values(), key=lambda item: (-item["count"], item["field"]))[:16],
        "answers": _build_answers(patterns, sequences, event_rows, baseline=baseline, semantic_coverage=semantic_coverage),
        "fieldCoverage": _counter_list(field_counts, limit=24),
        "services": _counter_list(service_counts, limit=12),
        "routes": _counter_list(route_counts, limit=12),
        "levels": _counter_list(level_counts, limit=8),
        "keywordGroups": _build_keyword_groups(patterns, keyword_counts),
        "patterns": patterns[:30],
        "sequences": sequences[:20],
        "events": event_rows[:80],
        "warnings": [] if event_rows else ["The query returned no logs in the selected time window."],
    }
    _analysis_cache_path(repo_path).write_text(json.dumps(packet, indent=2) + "\n", encoding="utf-8")
    return packet


def _connectors_path(repo_path: Path) -> Path:
    return get_project_dir(repo_path) / "runtime_connectors.json"


def _analysis_cache_path(repo_path: Path) -> Path:
    return get_project_cache_dir(repo_path) / "runtime_latest_analysis.json"


def _stable_connector_id(repo_path: Path, name: str, provider: str, base_url: str) -> str:
    digest = hashlib.sha1(f"{repo_path.resolve()}::{provider}::{base_url}::{name}".encode("utf-8")).hexdigest()
    return digest[:16]


def _load_connectors(repo_path: Path) -> list[RuntimeConnector]:
    path = _connectors_path(repo_path)
    if not path.exists():
        return []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    if not isinstance(payload, list):
        return []
    records: list[RuntimeConnector] = []
    migrated = False
    for item in payload:
        if not isinstance(item, dict):
            continue
        item = dict(item)
        connector_id = str(item.get("id") or "")
        stored_credentials = item.pop("credentials", None)
        credential_fields = item.pop("credential_fields", None)
        if stored_credentials is not None:
            try:
                if connector_id:
                    store_secret(repo_path, "runtime-connector", connector_id, stored_credentials)
                    migrated = True
            except SecretStoreUnavailable:
                logger.warning("Secure secret backend unavailable; legacy connector credentials could not be migrated.")
            credential_fields = sorted(
                str(key) for key, value in (stored_credentials or {}).items() if str(value).strip()
            )
        if not isinstance(credential_fields, list):
            credential_fields = []
        correlation_hints = item.pop("correlation_hints", None)
        if not isinstance(correlation_hints, list):
            correlation_hints = []
        secret_payload: dict[str, str] = {}
        if connector_id:
            try:
                secret_payload = load_secret(repo_path, "runtime-connector", connector_id) or {}
            except SecretStoreUnavailable as exc:
                logger.warning("Secure secret backend unavailable while loading runtime connector: %s", exc)
        try:
            records.append(
                RuntimeConnector(
                    **item,
                    credential_fields=[str(field) for field in credential_fields],
                    credentials={str(key): str(value) for key, value in secret_payload.items() if str(value).strip()},
                    correlation_hints=[str(field) for field in correlation_hints if str(field).strip()],
                )
            )
        except TypeError:
            continue
    if migrated:
        _save_connectors(repo_path, records)
    return records


def _save_connectors(repo_path: Path, connectors: list[RuntimeConnector]) -> None:
    path = _connectors_path(repo_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    serialized: list[dict[str, Any]] = []
    for connector in connectors:
        try:
            store_secret(repo_path, "runtime-connector", connector.id, connector.credentials)
        except SecretStoreUnavailable as exc:
            raise RuntimeError(f"Secure secret storage is unavailable: {exc}") from exc
        serialized.append(
            {
                "id": connector.id,
                "name": connector.name,
                "provider": connector.provider,
                "base_url": connector.base_url,
                "credential_fields": connector.credential_fields,
                "correlation_hints": connector.correlation_hints,
                "default_source": connector.default_source,
                "verify_tls": connector.verify_tls,
                "created_at": connector.created_at,
                "updated_at": connector.updated_at,
            }
        )
    path.write_text(json.dumps(serialized, indent=2) + "\n", encoding="utf-8")


def _serialize_connector(connector: RuntimeConnector) -> dict[str, Any]:
    auth_summary = []
    for key in connector.credential_fields:
        value = connector.credentials.get(key, "")
        if not value:
            continue
        masked = f"{value[:4]}...{value[-4:]}" if len(value) > 8 else "configured"
        auth_summary.append(f"{key}: {masked}")
    return {
        "id": connector.id,
        "name": connector.name,
        "provider": connector.provider,
        "providerLabel": _PROVIDER_CATALOG.get(connector.provider, {}).get("label", connector.provider),
        "baseUrl": connector.base_url,
        "correlationHints": connector.correlation_hints,
        "defaultSource": connector.default_source,
        "verifyTls": connector.verify_tls,
        "authSummary": auth_summary,
        "createdAt": connector.created_at,
        "updatedAt": connector.updated_at,
    }


def _get_connector(repo_path: Path, connector_id: str) -> RuntimeConnector:
    for connector in _load_connectors(repo_path):
        if connector.id == connector_id:
            return connector
    raise ValueError(f"Unknown runtime connector: {connector_id}")


def _provider_url(connector: RuntimeConnector, suffix: str) -> str:
    return f"{connector.base_url.rstrip('/')}{suffix}"


def _build_client(connector: RuntimeConnector) -> httpx.Client:
    headers: dict[str, str] = {"Accept": "application/json"}
    auth = None
    if connector.provider == "loki":
        token = connector.credentials.get("bearer_token")
        if token:
            headers["Authorization"] = f"Bearer {token}"
    elif connector.provider == "datadog":
        headers["DD-API-KEY"] = connector.credentials.get("api_key", "")
        headers["DD-APPLICATION-KEY"] = connector.credentials.get("app_key", "")
    elif connector.provider == "splunk":
        auth = (connector.credentials.get("username", ""), connector.credentials.get("password", ""))
    elif connector.provider == "sumologic":
        auth = (connector.credentials.get("access_id", ""), connector.credentials.get("access_key", ""))

    transport = httpx.HTTPTransport(retries=1, verify=connector.verify_tls)
    return httpx.Client(
        timeout=httpx.Timeout(10.0, read=30.0),
        transport=transport,
        headers=headers,
        auth=auth,
    )


def _parse_datetime(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _fetch_provider_logs(
    connector: RuntimeConnector,
    *,
    query: str,
    start_time: datetime,
    end_time: datetime,
    limit: int,
    source: str | None,
) -> list[dict[str, Any]]:
    with _build_client(connector) as client:
        if connector.provider == "loki":
            return _fetch_loki_logs(client, connector, query, start_time, end_time, limit)
        if connector.provider == "datadog":
            return _fetch_datadog_logs(client, connector, query, start_time, end_time, limit, source)
        if connector.provider == "splunk":
            return _fetch_splunk_logs(client, connector, query, start_time, end_time, limit)
        if connector.provider == "sumologic":
            return _fetch_sumologic_logs(client, connector, query, start_time, end_time, limit)
    raise ValueError(f"Unsupported provider: {connector.provider}")


def _fetch_loki_logs(
    client: httpx.Client,
    connector: RuntimeConnector,
    query: str,
    start_time: datetime,
    end_time: datetime,
    limit: int,
) -> list[dict[str, Any]]:
    response = client.get(
        _provider_url(connector, "/loki/api/v1/query_range"),
        params={
            "query": query,
            "start": int(start_time.timestamp() * 1_000_000_000),
            "end": int(end_time.timestamp() * 1_000_000_000),
            "limit": limit,
            "direction": "backward",
        },
    )
    response.raise_for_status()
    payload = response.json()
    rows: list[dict[str, Any]] = []
    for stream in payload.get("data", {}).get("result", []):
        labels = stream.get("stream", {}) or {}
        for raw_ts, line in stream.get("values", []):
            rows.append({"timestamp": raw_ts, "line": line, "labels": labels})
    return rows[:limit]


def _fetch_datadog_logs(
    client: httpx.Client,
    connector: RuntimeConnector,
    query: str,
    start_time: datetime,
    end_time: datetime,
    limit: int,
    source: str | None,
) -> list[dict[str, Any]]:
    body: dict[str, Any] = {
        "filter": {
            "from": start_time.isoformat(),
            "to": end_time.isoformat(),
            "query": query,
        },
        "sort": "timestamp",
        "page": {"limit": limit},
    }
    if source:
        body["filter"]["indexes"] = [source]
    response = client.post(_provider_url(connector, "/api/v2/logs/events/search"), json=body)
    response.raise_for_status()
    return list(response.json().get("data", []) or [])[:limit]


def _fetch_splunk_logs(
    client: httpx.Client,
    connector: RuntimeConnector,
    query: str,
    start_time: datetime,
    end_time: datetime,
    limit: int,
) -> list[dict[str, Any]]:
    response = client.post(
        _provider_url(connector, "/services/search/jobs/export"),
        data={
            "search": query if query.lstrip().startswith("search") else f"search {query}",
            "output_mode": "json",
            "earliest_time": start_time.isoformat(),
            "latest_time": end_time.isoformat(),
            "count": str(limit),
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    response.raise_for_status()
    rows: list[dict[str, Any]] = []
    for line in response.text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            payload = json.loads(line)
        except json.JSONDecodeError:
            continue
        result = payload.get("result")
        if isinstance(result, dict):
            rows.append(result)
    return rows[:limit]


def _fetch_sumologic_logs(
    client: httpx.Client,
    connector: RuntimeConnector,
    query: str,
    start_time: datetime,
    end_time: datetime,
    limit: int,
) -> list[dict[str, Any]]:
    create_response = client.post(
        _provider_url(connector, "/api/v1/search/jobs"),
        json={
            "query": query,
            "from": start_time.isoformat().replace("+00:00", "Z"),
            "to": end_time.isoformat().replace("+00:00", "Z"),
            "timeZone": "UTC",
        },
    )
    create_response.raise_for_status()
    job = create_response.json()
    job_id = job.get("id")
    if not job_id:
        return []
    status = "GATHERING RESULTS"
    deadline = time.time() + 20.0
    while time.time() < deadline:
        poll_response = client.get(_provider_url(connector, f"/api/v1/search/jobs/{job_id}"))
        poll_response.raise_for_status()
        status = str(poll_response.json().get("state") or "")
        if status.upper() in {"DONE GATHERING RESULTS", "CANCELLED", "FORCE PAUSED"}:
            break
        time.sleep(0.8)
    result_response = client.get(
        _provider_url(connector, f"/api/v1/search/jobs/{job_id}/messages"),
        params={"limit": limit, "offset": 0},
    )
    result_response.raise_for_status()
    return list(result_response.json().get("messages", []) or [])[:limit]


def _normalize_event(provider: str, raw: dict[str, Any], *, correlation_hints: list[str] | None = None) -> NormalizedLogEvent:
    if provider == "loki":
        timestamp = _coerce_timestamp(raw.get("timestamp"))
        labels = raw.get("labels", {}) if isinstance(raw.get("labels"), dict) else {}
        parsed = _parse_payload(raw.get("line"))
        combined = dict(labels)
        combined.update(parsed["attributes"])
        message = parsed["message"] or str(raw.get("line") or "")
        source = labels.get("job") or labels.get("source") or labels.get("filename")
    elif provider == "datadog":
        attrs = raw.get("attributes", {}) if isinstance(raw.get("attributes"), dict) else {}
        nested = attrs.get("attributes")
        combined = dict(attrs)
        if isinstance(nested, dict):
            combined.update(_flatten_dict(nested))
        parsed = _parse_payload(attrs.get("message") or raw)
        combined.update(parsed["attributes"])
        message = parsed["message"] or str(attrs.get("message") or "")
        timestamp = _coerce_timestamp(attrs.get("timestamp"))
        source = attrs.get("service") or attrs.get("source")
    elif provider == "splunk":
        combined = _flatten_dict(raw)
        parsed = _parse_payload(raw.get("_raw") or raw.get("message") or raw)
        combined.update(parsed["attributes"])
        message = parsed["message"] or str(raw.get("_raw") or raw.get("message") or "")
        timestamp = _coerce_timestamp(raw.get("_time") or raw.get("time"))
        source = raw.get("source")
    elif provider == "sumologic":
        payload = raw.get("map") if isinstance(raw.get("map"), dict) else raw
        combined = _flatten_dict(payload if isinstance(payload, dict) else {})
        parsed = _parse_payload(payload.get("_raw") if isinstance(payload, dict) else raw)
        combined.update(parsed["attributes"])
        message = parsed["message"] or str((payload or {}).get("_raw") if isinstance(payload, dict) else raw)
        timestamp = _coerce_timestamp((payload or {}).get("_messagetime") if isinstance(payload, dict) else None)
        source = (payload or {}).get("_sourceName") if isinstance(payload, dict) else None
    else:
        combined = _flatten_dict(raw)
        parsed = _parse_payload(raw)
        combined.update(parsed["attributes"])
        message = parsed["message"] or json.dumps(raw)
        timestamp = datetime.now(tz=timezone.utc).isoformat()
        source = None

    code_files, code_functions = _extract_code_hints(message, combined)
    db_statement = _first_value(
        combined,
        "db.statement",
        "db.statement.text",
        "sql",
        "query",
        "attributes.db.statement",
    )
    db_tables = list(dict.fromkeys(_extract_db_tables(db_statement, message)))
    exception_type = _extract_exception_type(message, combined)
    route = _first_value(
        combined,
        "http.route",
        "route",
        "resource_name",
        "request.route",
        "attributes.http.route",
        "attributes.route",
    ) or _extract_route(message)
    path = _first_value(
        combined,
        "http.path",
        "path",
        "url.path",
        "request.path",
        "attributes.http.path",
    ) or route
    method = _normalize_method(_first_value(combined, "http.method", "method", "attributes.http.method"))
    status_code = _coerce_int(_first_value(combined, "http.status_code", "status", "status_code", "attributes.http.status_code"))
    level = _normalize_level(_first_value(combined, "level", "status", "severity", "status_text") or message)
    trace_id = _first_value(
        combined,
        "trace_id",
        "trace.id",
        "dd.trace_id",
        "attributes.trace_id",
        "x_b3_traceid",
        "x-b3-traceid",
        "attributes.x_b3_traceid",
    )
    span_id = _first_value(
        combined,
        "span_id",
        "span.id",
        "dd.span_id",
        "attributes.span_id",
        "x_b3_spanid",
        "x-b3-spanid",
        "attributes.x_b3_spanid",
    )
    parent_span_id = _first_value(
        combined,
        "parent_span_id",
        "parent.span_id",
        "span.parent_id",
        "attributes.parent_span_id",
    )
    b3_context = _parse_b3(_first_value(combined, "b3", "attributes.b3", "headers.b3") or message)
    if b3_context:
        trace_id = trace_id or b3_context["traceId"]
        span_id = span_id or b3_context["spanId"]
        parent_span_id = parent_span_id or b3_context.get("parentSpanId")
    traceparent = _first_value(
        combined,
        "traceparent",
        "headers.traceparent",
        "attributes.traceparent",
        "otel.traceparent",
    )
    trace_context = _parse_traceparent(traceparent or message)
    if trace_context:
        trace_id = trace_id or trace_context["traceId"]
        span_id = span_id or trace_context["spanId"]
    xray_context = _parse_aws_trace_header(_first_value(combined, "x-amzn-trace-id", "x_amzn_trace_id", "attributes.x_amzn_trace_id") or message)
    if xray_context:
        trace_id = trace_id or xray_context["traceId"]
        parent_span_id = parent_span_id or xray_context.get("parentSpanId")
    custom_values = _extract_custom_correlation_values(combined, message, correlation_hints or [])
    if not trace_id:
        trace_id = custom_values.get("trace")
    if not span_id:
        span_id = custom_values.get("span")
    if not parent_span_id:
        parent_span_id = custom_values.get("parent")
    correlation_id = _first_value(
        combined,
        "correlation_id",
        "correlation.id",
        "x_correlation_id",
        "x-correlation-id",
        "attributes.correlation_id",
        "aws_request_id",
    ) or custom_values.get("correlation") or _extract_message_id(message, "correlation_id", "correlation-id", "correlation id", "correlationId")
    request_id = _first_value(
        combined,
        "request_id",
        "request.id",
        "x_request_id",
        "x-request-id",
        "attributes.request_id",
    ) or custom_values.get("request") or _extract_message_id(message, "request_id", "request-id", "request id", "requestId")
    session_id = _first_value(combined, "session_id", "session.id", "attributes.session_id") or custom_values.get("session")
    user_id = _first_value(combined, "user.id", "user_id", "attributes.user.id", "attributes.user_id")
    logger_name = _first_value(combined, "logger", "logger.name", "attributes.logger", "module", "component")
    service = _first_value(
        combined,
        "service",
        "service.name",
        "dd.service",
        "attributes.service",
        "application",
    )
    env = _first_value(combined, "env", "environment", "deployment.environment", "attributes.env")
    host = _first_value(combined, "host", "host.name", "hostname", "attributes.host")
    latency_ms = _extract_latency_ms(combined, message)

    template = _canonicalize_template(message)
    keywords = _extract_keywords(f"{exception_type or ''} {message}")
    return NormalizedLogEvent(
        id=hashlib.sha1(f"{provider}:{timestamp}:{message}".encode("utf-8")).hexdigest()[:16],
        provider=provider,
        timestamp=timestamp,
        level=level,
        message=message[:2000],
        service=service,
        env=env,
        host=host,
        source=source,
        route=route,
        path=path,
        method=method,
        status_code=status_code,
        trace_id=trace_id,
        span_id=span_id,
        parent_span_id=parent_span_id,
        correlation_id=correlation_id,
        request_id=request_id,
        session_id=session_id,
        user_id=user_id,
        logger=logger_name,
        exception_type=exception_type,
        latency_ms=latency_ms,
        db_statement=db_statement,
        db_tables=db_tables,
        code_files=code_files,
        code_functions=code_functions,
        structured_kind=parsed["kind"],
        attributes=combined,
        raw=raw,
        template=template,
        keywords=keywords,
        schema_signature=_schema_signature(parsed["kind"], combined),
    )


def _parse_payload(raw: Any) -> dict[str, Any]:
    if isinstance(raw, dict):
        attrs = _flatten_dict(raw)
        message = _first_value(attrs, "message", "msg", "event", "log", "body") or json.dumps(raw)
        return {"kind": "json", "attributes": attrs, "message": message}

    if isinstance(raw, list):
        return {"kind": "json", "attributes": {"items": raw}, "message": json.dumps(raw)}

    line = str(raw or "").strip()
    if not line:
        return {"kind": "plain", "attributes": {}, "message": ""}

    if line.startswith("{") or line.startswith("["):
        try:
            parsed = json.loads(line)
        except json.JSONDecodeError:
            parsed = None
        if parsed is not None:
            return _parse_payload(parsed)

    parsed_logfmt = _parse_logfmt(line)
    if parsed_logfmt:
        attrs = _flatten_dict(parsed_logfmt)
        message = _first_value(attrs, "message", "msg", "event", "error") or line
        nested_message = str(message).strip()
        if nested_message.startswith("{"):
            try:
                nested_json = json.loads(nested_message)
            except json.JSONDecodeError:
                nested_json = None
            if isinstance(nested_json, dict):
                attrs.update(_flatten_dict(nested_json))
                message = _first_value(attrs, "message", "msg", "event", "error") or line
                return {"kind": "json", "attributes": attrs, "message": message}
        return {"kind": "logfmt", "attributes": attrs, "message": str(message)}

    return {"kind": "plain", "attributes": {}, "message": line}


def _parse_logfmt(line: str) -> dict[str, str]:
    if "=" not in line:
        return {}
    try:
        parts = shlex.split(line, posix=True)
    except ValueError:
        return {}
    parsed: dict[str, str] = {}
    for token in parts:
        if "=" not in token:
            continue
        key, value = token.split("=", 1)
        key = key.strip()
        if not key:
            continue
        parsed[key] = value.strip()
    return parsed


def _parse_traceparent(value: str | None) -> dict[str, str] | None:
    if not value:
        return None
    match = _TRACEPARENT_RE.search(value)
    if not match:
        return None
    return {
        "traceId": match.group("trace").lower(),
        "spanId": match.group("span").lower(),
    }


def _parse_b3(value: str | None) -> dict[str, str] | None:
    if not value:
        return None
    match = _B3_RE.search(value)
    if not match:
        return None
    payload = {
        "traceId": match.group("trace").lower(),
        "spanId": match.group("span").lower(),
    }
    parent = match.groupdict().get("parent")
    if parent:
        payload["parentSpanId"] = parent.lower()
    return payload


def _parse_aws_trace_header(value: str | None) -> dict[str, str] | None:
    if not value:
        return None
    root = _AWS_TRACE_ROOT_RE.search(value)
    if not root:
        return None
    payload = {
        "traceId": f"{root.group('epoch')}{root.group('trace')}".lower(),
    }
    parent = _AWS_TRACE_PARENT_RE.search(value)
    if parent:
        payload["parentSpanId"] = parent.group("parent").lower()
    return payload


def _flatten_dict(value: dict[str, Any], prefix: str = "") -> dict[str, Any]:
    flat: dict[str, Any] = {}
    for key, item in value.items():
        joined = f"{prefix}.{key}" if prefix else str(key)
        if isinstance(item, dict):
            flat.update(_flatten_dict(item, joined))
        else:
            flat[joined] = item
            if not prefix:
                flat[str(key)] = item
    return flat


def _first_value(attrs: dict[str, Any], *keys: str) -> str | None:
    for key in keys:
        if key in attrs:
            value = attrs[key]
            if value is None:
                continue
            text = str(value).strip()
            if text:
                return text
    return None


def _extract_message_id(message: str, *labels: str) -> str | None:
    for label in labels:
        pattern = re.compile(rf"\b{re.escape(label)}\b[\s:=]+(?P<value>[A-Za-z0-9._:/-]{{6,}})", re.I)
        match = pattern.search(message)
        if match:
            return match.group("value")
    return None


def _hint_aliases(hint: str) -> list[str]:
    raw = hint.strip()
    if not raw:
        return []
    variants = {
        raw,
        raw.replace("-", "_"),
        raw.replace("_", "-"),
        raw.replace(".", "_"),
        raw.replace(".", "-"),
        raw.replace("-", "."),
        raw.replace("_", "."),
    }
    return [item for item in variants if item]


def _extract_custom_correlation_values(attrs: dict[str, Any], message: str, hints: list[str]) -> dict[str, str]:
    values: dict[str, str] = {}
    for hint in hints:
        lowered = hint.lower().strip()
        if not lowered:
            continue
        value = None
        for key in _hint_aliases(lowered):
            value = _first_value(attrs, key, f"attributes.{key}", f"headers.{key}")
            if value:
                break
            value = _extract_message_id(message, key)
            if value:
                break
        if not value:
            continue
        if "trace" in lowered and "parent" not in lowered:
            values.setdefault("trace", value)
        elif "span" in lowered and "parent" in lowered:
            values.setdefault("parent", value)
        elif "span" in lowered:
            values.setdefault("span", value)
        elif "request" in lowered:
            values.setdefault("request", value)
        elif "session" in lowered:
            values.setdefault("session", value)
        else:
            values.setdefault("correlation", value)
    return values


def _coerce_int(value: str | None) -> int | None:
    if value is None:
        return None
    digits = "".join(ch for ch in str(value) if ch.isdigit())
    if not digits:
        return None
    try:
        return int(digits)
    except ValueError:
        return None


def _coerce_timestamp(value: Any) -> str:
    if value is None:
        return datetime.now(tz=timezone.utc).isoformat()
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(float(value), tz=timezone.utc).isoformat()
    text = str(value).strip()
    if text.isdigit():
        scale = 1.0
        if len(text) > 13:
            scale = 1_000_000_000.0
        elif len(text) > 10:
            scale = 1000.0
        return datetime.fromtimestamp(int(text) / scale, tz=timezone.utc).isoformat()
    parsed = _parse_datetime(text)
    if parsed is not None:
        return parsed.isoformat()
    return datetime.now(tz=timezone.utc).isoformat()


def _normalize_level(value: str) -> str:
    match = _LEVEL_RE.search(value)
    if not match:
        return "info"
    level = match.group(1).lower()
    if level == "warn":
        return "warning"
    return level


def _normalize_method(value: str | None) -> str | None:
    if not value:
        return None
    method = value.strip().upper()
    if method in {"GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"}:
        return method
    return None


def _extract_route(message: str) -> str | None:
    match = _ROUTE_RE.search(message)
    if match:
        return match.group(1)
    path_match = re.search(r"\b(/[A-Za-z0-9_./:-]{2,})\b", message)
    if path_match:
        return path_match.group(1)
    return None


def _extract_exception_type(message: str, attrs: dict[str, Any]) -> str | None:
    from_attrs = _first_value(attrs, "error.kind", "error.type", "exception.type", "exception_type")
    if from_attrs:
        return from_attrs
    match = re.search(r"\b([A-Z][A-Za-z0-9_]*(?:Error|Exception))\b", message)
    if match:
        return match.group(1)
    return None


def _extract_latency_ms(attrs: dict[str, Any], message: str) -> float | None:
    candidates = [
        _first_value(
            attrs,
            "duration_ms",
            "duration.ms",
            "latency_ms",
            "response_time_ms",
            "elapsed_ms",
            "attributes.duration_ms",
            "attributes.latency_ms",
        ),
        _first_value(attrs, "duration", "elapsed", "response_time", "attributes.duration"),
    ]
    for candidate in candidates:
        parsed = _coerce_latency(candidate)
        if parsed is not None:
            return parsed

    patterns = [
        re.compile(r"\b(?P<value>\d+(?:\.\d+)?)\s*ms\b", re.I),
        re.compile(r"\b(?P<value>\d+(?:\.\d+)?)\s*s(?:ec(?:onds?)?)?\b", re.I),
    ]
    for index, pattern in enumerate(patterns):
        match = pattern.search(message)
        if not match:
            continue
        value = float(match.group("value"))
        return round(value * 1000, 2) if index == 1 else round(value, 2)
    return None


def _coerce_latency(value: str | None) -> float | None:
    if value is None:
        return None
    text = str(value).strip().lower()
    if not text:
        return None
    multiplier = 1.0
    if text.endswith("ms"):
        text = text[:-2].strip()
    elif text.endswith("s"):
        text = text[:-1].strip()
        multiplier = 1000.0
    try:
        return round(float(text) * multiplier, 2)
    except ValueError:
        digits = re.search(r"\d+(?:\.\d+)?", text)
        if not digits:
            return None
        return round(float(digits.group(0)) * multiplier, 2)


def _extract_db_tables(db_statement: str | None, message: str) -> list[str]:
    tables: list[str] = []
    if db_statement:
        try:
            tables.extend(extract_tables_from_query(db_statement))
        except Exception:
            logger.debug("SQL table extraction failed", exc_info=True)
        for match in _SQL_TABLE_RE.finditer(db_statement):
            tables.append(match.group(1).split(".")[-1])
    if not tables:
        for match in _SQL_TABLE_RE.finditer(message):
            tables.append(match.group(1).split(".")[-1])
    seen: set[str] = set()
    ordered: list[str] = []
    for table in tables:
        normalized = table.strip('"').strip("'").strip()
        if normalized and normalized not in seen:
            seen.add(normalized)
            ordered.append(normalized)
    return ordered


def _extract_code_hints(message: str, attrs: dict[str, Any]) -> tuple[list[str], list[str]]:
    files: list[str] = []
    functions: list[str] = []
    direct_path = _first_value(attrs, "code.filepath", "file", "file.path", "source.file")
    direct_fn = _first_value(attrs, "code.function", "function", "function.name", "source.function")
    if direct_path:
        files.append(direct_path)
    if direct_fn:
        functions.append(direct_fn)

    for regex in (_JS_STACK_RE, _PY_STACK_RE):
        for match in regex.finditer(message):
            path = match.groupdict().get("path")
            fn = match.groupdict().get("fn")
            if path:
                files.append(path)
            if fn:
                functions.append(fn)

    for path in _PATH_RE.findall(message):
        if any(path.endswith(ext) for ext in (".py", ".ts", ".tsx", ".js", ".jsx", ".cs", ".go", ".rb", ".java")):
            files.append(path)

    return _unique(files), _unique(functions)


def _infer_journey_link(event: NormalizedLogEvent) -> dict[str, str] | None:
    if event.trace_id:
        return {
            "key": f"trace:{event.trace_id}",
            "correlationId": event.trace_id,
            "correlationType": "trace",
            "linkageMode": "explicit",
            "confidence": "high",
            "linkReason": "Grouped by shared trace_id propagated through the request path.",
        }
    if event.request_id:
        return {
            "key": f"request:{event.request_id}",
            "correlationId": event.request_id,
            "correlationType": "request",
            "linkageMode": "explicit",
            "confidence": "high",
            "linkReason": "Grouped by shared request_id emitted across the same request chain.",
        }
    if event.correlation_id:
        return {
            "key": f"correlation:{event.correlation_id}",
            "correlationId": event.correlation_id,
            "correlationType": "correlation",
            "linkageMode": "explicit",
            "confidence": "medium",
            "linkReason": "Grouped by a shared correlation identifier captured in the log payload.",
        }
    if event.session_id:
        return {
            "key": f"session:{event.session_id}",
            "correlationId": event.session_id,
            "correlationType": "session",
            "linkageMode": "explicit",
            "confidence": "medium",
            "linkReason": "Grouped by shared session_id, which likely reflects the same user flow.",
        }

    dimensions: list[str] = []
    signature_parts: list[str] = []
    if event.service:
        dimensions.append(f"service {event.service}")
        signature_parts.append(f"service:{event.service.lower()}")
    route = event.route or event.path
    if route:
        normalized_route = _normalize_route(route)
        dimensions.append(f"route {normalized_route}")
        signature_parts.append(f"route:{normalized_route}")
    if event.logger:
        logger_name = event.logger.rsplit(".", 1)[-1].lower()
        dimensions.append(f"logger {logger_name}")
        signature_parts.append(f"logger:{logger_name}")
    if event.db_tables:
        table_name = event.db_tables[0].lower()
        dimensions.append(f"table {table_name}")
        signature_parts.append(f"table:{table_name}")
    if len(signature_parts) < 2:
        return None

    bucket_time = _parse_datetime(event.timestamp) or datetime.now(tz=timezone.utc)
    time_bucket = int(bucket_time.timestamp() // 30)
    signature_parts.append(f"template:{event.template}")
    signature = "::".join([str(time_bucket), *signature_parts])
    derived_id = hashlib.sha1(signature.encode("utf-8")).hexdigest()[:12]
    dimension_text = ", ".join(dimensions[:3])
    return {
        "key": f"derived:{derived_id}",
        "correlationId": f"inferred-{derived_id}",
        "correlationType": "inferred",
        "linkageMode": "derived",
        "confidence": "medium" if route and event.service else "low",
        "linkReason": f"Grouped by shared {dimension_text} and a matching log template inside the same 30-second window.",
    }


def _canonicalize_template(message: str) -> str:
    template = message.strip()
    if not template:
        return "(empty)"
    template = _UUID_RE.sub("{uuid}", template)
    template = _HEX_RE.sub("{hex}", template)
    template = _QUOTED_RE.sub('"str"', template)
    template = _PATH_RE.sub("{path}", template)
    template = _NUMBER_RE.sub("{n}", template)
    template = re.sub(r"\s+", " ", template)
    return template[:240]


def _extract_keywords(text: str) -> list[str]:
    counts: Counter[str] = Counter()
    for token in _TOKEN_RE.findall(text.lower()):
        normalized = token.strip("._:-/")
        if len(normalized) < 3 or normalized in _STOPWORDS or normalized.startswith("http"):
            continue
        counts[normalized] += 1
    return [token for token, _count in counts.most_common(8)]


def _schema_signature(kind: str, attrs: dict[str, Any]) -> str:
    if not attrs:
        return f"{kind}:plain"
    keys = sorted(set(list(attrs.keys())[:40]))
    if not keys:
        return f"{kind}:plain"
    joined = ",".join(keys[:12])
    if len(keys) > 12:
        joined += ",+"
    return f"{kind}:{joined}"


def _build_graph_lookup(graph: KnowledgeGraph) -> dict[str, Any]:
    api_by_path: dict[str, list[GraphNode]] = defaultdict(list)
    file_by_suffix: dict[str, list[GraphNode]] = defaultdict(list)
    table_by_name: dict[str, list[GraphNode]] = defaultdict(list)
    dep_by_name: dict[str, list[GraphNode]] = defaultdict(list)
    function_by_name: dict[str, list[GraphNode]] = defaultdict(list)
    for node in graph.iter_nodes():
        if node.label == NodeLabel.API_ENDPOINT:
            path = str(node.properties.get("path") or node.name or "").strip()
            if path:
                api_by_path[_normalize_route(path)].append(node)
        elif node.label == NodeLabel.FILE:
            suffix = node.file_path.replace("\\", "/")
            if suffix:
                file_by_suffix[suffix.lower()].append(node)
                file_by_suffix[Path(suffix).name.lower()].append(node)
        elif node.label == NodeLabel.DB_TABLE:
            table_by_name[node.name.lower()].append(node)
        elif node.label == NodeLabel.EXTERNAL_DEP:
            dep_by_name[node.name.lower()].append(node)
        elif node.label in {NodeLabel.FUNCTION, NodeLabel.METHOD, NodeLabel.CLASS}:
            function_by_name[node.name.lower()].append(node)
    return {
        "api_by_path": api_by_path,
        "file_by_suffix": file_by_suffix,
        "table_by_name": table_by_name,
        "dep_by_name": dep_by_name,
        "function_by_name": function_by_name,
    }


def _correlate_event(graph_lookup: dict[str, Any], event: NormalizedLogEvent) -> dict[str, list[dict[str, Any]]]:
    apis: dict[str, GraphNode] = {}
    files: dict[str, GraphNode] = {}
    tables: dict[str, GraphNode] = {}
    dependencies: dict[str, GraphNode] = {}

    if event.route or event.path:
        for route in filter(None, [event.route, event.path]):
            normalized_route = _normalize_route(route or "")
            for node in graph_lookup["api_by_path"].get(normalized_route, []):
                apis[node.id] = node

    for file_hint in event.code_files:
        normalized = file_hint.replace("\\", "/").lower()
        candidates = graph_lookup["file_by_suffix"].get(normalized, [])
        if not candidates:
            candidates = graph_lookup["file_by_suffix"].get(Path(normalized).name.lower(), [])
        for node in candidates[:4]:
            files[node.id] = node

    for function_name in event.code_functions:
        for node in graph_lookup["function_by_name"].get(function_name.lower(), [])[:2]:
            files[node.id] = node

    for table_name in event.db_tables:
        for node in graph_lookup["table_by_name"].get(table_name.lower(), [])[:4]:
            tables[node.id] = node

    for keyword in event.keywords:
        for node in graph_lookup["dep_by_name"].get(keyword.lower(), [])[:2]:
            dependencies[node.id] = node

    if event.logger:
        logger_token = event.logger.rsplit(".", 1)[-1].lower()
        for node in graph_lookup["dep_by_name"].get(logger_token, [])[:2]:
            dependencies[node.id] = node

    return {
        "apis": [_serialize_runtime_packet_node(node) for node in list(apis.values())[:_MAX_PATTERN_MATCHES]],
        "files": [_serialize_runtime_packet_node(node) for node in list(files.values())[:_MAX_PATTERN_MATCHES]],
        "tables": [_serialize_runtime_packet_node(node) for node in list(tables.values())[:_MAX_PATTERN_MATCHES]],
        "dependencies": [_serialize_runtime_packet_node(node) for node in list(dependencies.values())[:_MAX_PATTERN_MATCHES]],
    }


def _serialize_runtime_packet_node(node: GraphNode) -> dict[str, Any]:
    return {
        "id": node.id,
        "label": node.label.value,
        "name": node.name,
        "filePath": node.file_path,
        "startLine": node.start_line,
        "endLine": node.end_line,
        "signature": node.signature,
        "language": node.language,
        "isEntryPoint": node.is_entry_point,
        "isDead": node.is_dead,
        "provenance": serialize_provenance(node.properties, fallback_source_id=node.id),
        "confidence": serialize_confidence(node.properties, fallback_tier=infer_node_capability_tier(node)),
    }


def _normalize_route(route: str) -> str:
    normalized = route.strip().lower()
    normalized = re.sub(r"/\d+(?=/|$)", "/:id", normalized)
    normalized = _UUID_RE.sub(":id", normalized)
    return normalized


def _counter_list(counter: Counter[str], *, limit: int = 10) -> list[dict[str, Any]]:
    return [{"value": value, "count": count} for value, count in counter.most_common(limit)]


def _sequence_duration_seconds(first_seen: str, last_seen: str) -> int:
    start = _parse_datetime(first_seen)
    end = _parse_datetime(last_seen)
    if start is None or end is None:
        return 0
    return max(0, int((end - start).total_seconds()))


def _sequence_timeline(events: list[dict[str, Any]]) -> list[dict[str, Any]]:
    ordered = sorted(events, key=lambda item: item["timestamp"])
    return ordered[:8]


def _sequence_avg_latency(events: list[dict[str, Any]]) -> float | None:
    values = [float(event["latencyMs"]) for event in events if event.get("latencyMs") is not None]
    if not values:
        return None
    return round(sum(values) / len(values), 2)


def _sequence_max_latency(events: list[dict[str, Any]]) -> float | None:
    values = [float(event["latencyMs"]) for event in events if event.get("latencyMs") is not None]
    if not values:
        return None
    return round(max(values), 2)


def _sequence_root_cause(events: list[dict[str, Any]]) -> str:
    if not events:
        return "No runtime events were linked into this journey."
    ordered = sorted(events, key=lambda item: item["timestamp"])
    candidate = next(
        (event for event in reversed(ordered) if event["level"] in {"error", "fatal", "critical"}),
        ordered[-1],
    )
    fragments: list[str] = []
    if candidate.get("exceptionType"):
        fragments.append(str(candidate["exceptionType"]))
    if candidate.get("route"):
        fragments.append(f"around {candidate['route']}")
    tables = (candidate.get("related") or {}).get("tables") or []
    files = (candidate.get("related") or {}).get("files") or []
    if tables:
        fragments.append(f"hitting table {tables[0]['name']}")
    elif files:
        fragments.append(f"inside {files[0]['name']}")
    if not fragments:
        return candidate.get("message") or "No clear root cause summary yet."
    return "Likely root cause: " + " ".join(fragments)


def _build_keyword_groups(patterns: list[dict[str, Any]], keyword_counts: Counter[str]) -> list[dict[str, Any]]:
    groups: list[dict[str, Any]] = []
    for keyword, count in keyword_counts.most_common(16):
        related = [
            {
                "id": pattern["id"],
                "template": pattern["template"],
                "count": pattern["count"],
            }
            for pattern in patterns
            if any(entry["value"] == keyword for entry in pattern["keywords"])
        ][:6]
        groups.append({"keyword": keyword, "count": count, "relatedPatterns": related})
    return groups


def _detect_sensitive_values(attrs: dict[str, Any], message: str) -> list[tuple[str, str]]:
    hits: list[tuple[str, str]] = []
    for field, value in attrs.items():
        if not _SENSITIVE_KEY_RE.search(field):
            continue
        text = str(value).strip()
        if not text:
            continue
        hits.append((field, _mask_sensitive_value(field, text)))
    email_match = re.search(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", message, re.I)
    if email_match:
        hits.append(("message.email", _mask_sensitive_value("email", email_match.group(0))))
    bearer_match = re.search(r"Bearer\s+[A-Za-z0-9._\-]+", message, re.I)
    if bearer_match:
        hits.append(("message.authorization", "Bearer ***"))
    return hits


def _mask_sensitive_value(field: str, value: str) -> str:
    lowered = field.lower()
    if "email" in lowered:
        parts = value.split("@", 1)
        if len(parts) == 2:
            return f"{parts[0][:2]}***@{parts[1]}"
    if len(value) <= 8:
        return "***"
    return f"{value[:3]}***{value[-2:]}"


def _sensitive_kind(field: str) -> str:
    lowered = field.lower()
    if "email" in lowered:
        return "pii"
    if "phone" in lowered or "ssn" in lowered:
        return "pii"
    if "password" in lowered or "secret" in lowered or "token" in lowered or "key" in lowered:
        return "credential"
    return "sensitive"


def _compare_against_baseline(
    previous_packet: dict[str, Any] | None,
    patterns: list[dict[str, Any]],
    connector_id: str,
    query: str,
) -> dict[str, Any]:
    if not previous_packet:
        return {"available": False, "summary": "No previous runtime analysis cached for comparison.", "newPatterns": [], "regressions": []}

    previous_connector_id = str((previous_packet.get("connector") or {}).get("id") or "")
    previous_query = str((previous_packet.get("query") or {}).get("text") or "")
    previous_map = {
        item.get("template"): item
        for item in previous_packet.get("patterns", []) or []
        if item.get("template")
    }
    current_map = {item["template"]: item for item in patterns}
    new_patterns = []
    regressions = []
    for template, current in current_map.items():
        previous = previous_map.get(template)
        if previous is None:
            new_patterns.append(
                {
                    "id": current["id"],
                    "template": template,
                    "count": current["count"],
                    "sampleMessage": current["sampleMessage"],
                }
            )
            continue
        previous_count = int(previous.get("count") or 0)
        delta = current["count"] - previous_count
        if delta >= max(3, previous_count):
            regressions.append(
                {
                    "id": current["id"],
                    "template": template,
                    "count": current["count"],
                    "previousCount": previous_count,
                    "delta": delta,
                }
            )

    summary_parts = []
    if previous_connector_id and previous_connector_id != connector_id:
        summary_parts.append("Compared against a previous analysis from a different connector.")
    if previous_query and previous_query != query:
        summary_parts.append("Compared against a previous analysis run with a different query.")
    if not summary_parts:
        summary_parts.append("Compared against the most recent runtime analysis for this repository.")
    return {
        "available": True,
        "summary": " ".join(summary_parts),
        "newPatterns": sorted(new_patterns, key=lambda item: -item["count"])[:8],
        "regressions": sorted(regressions, key=lambda item: -item["delta"])[:8],
    }


def _build_instrumentation_findings(
    semantic_coverage: dict[str, float],
    *,
    schemas: list[dict[str, Any]],
    sensitive_signals: list[dict[str, Any]],
    events: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    if semantic_coverage["traceIdRate"] < 0.35:
        findings.append(
            {
                "severity": "high",
                "title": "Trace correlation is thin",
                "detail": "Only a small share of logs carried trace IDs, which weakens request reconstruction and runtime-to-code pivots.",
            }
        )
    if semantic_coverage["correlationIdRate"] < 0.4:
        findings.append(
            {
                "severity": "medium",
                "title": "Request and correlation IDs are sparse",
                "detail": "Most events are missing request_id or correlation_id, so LogThread has to fall back to inferred journeys more often than ideal.",
            }
        )
    if semantic_coverage["serviceRate"] < 0.6:
        findings.append(
            {
                "severity": "medium",
                "title": "Service identity is inconsistent",
                "detail": "A large share of events is missing service.name or equivalent service metadata.",
            }
        )
    if semantic_coverage["routeRate"] < 0.4:
        findings.append(
            {
                "severity": "medium",
                "title": "Route or path metadata is sparse",
                "detail": "HTTP route/path fields are missing on most events, so API-level drilldown is weaker than it could be.",
            }
        )
    if schemas and schemas[0]["structuredKind"] == "plain" and schemas[0]["count"] >= max(10, len(events) // 2):
        findings.append(
            {
                "severity": "medium",
                "title": "Plain text logs dominate this slice",
                "detail": "Most events arrived without machine-readable fields. JSON or key-value logging would improve grouping, faceting, and graph correlation.",
            }
        )
    if sensitive_signals:
        findings.append(
            {
                "severity": "medium",
                "title": "Sensitive fields detected in the analyzed slice",
                "detail": "Credentials or PII-like fields were present in these logs. Add redaction before central ingestion or persistence.",
            }
        )
    if semantic_coverage["inferredLinkRate"] > 0.35:
        findings.append(
            {
                "severity": "low",
                "title": "A large share of journeys are inferred",
                "detail": "LogThread still linked many events successfully, but those links came from matching service, route, logger, or table hints rather than explicit propagation fields.",
            }
        )
    if not findings:
        findings.append(
            {
                "severity": "low",
                "title": "Instrumentation shape looks healthy",
                "detail": "This slice already includes enough structured and correlated fields for LogThread to reconstruct useful runtime paths.",
            }
        )
    return findings[:5]


def _build_answers(
    patterns: list[dict[str, Any]],
    sequences: list[dict[str, Any]],
    events: list[dict[str, Any]],
    *,
    baseline: dict[str, Any],
    semantic_coverage: dict[str, float],
) -> list[dict[str, Any]]:
    answers: list[dict[str, Any]] = []
    if not patterns:
        return answers

    top_pattern = patterns[0]
    apis = top_pattern["related"]["apis"]
    tables = top_pattern["related"]["tables"]
    files = top_pattern["related"]["files"]
    answers.append(
        {
            "title": "Top repeating failure pattern",
            "body": top_pattern["sampleMessage"],
            "evidence": [
                f"{top_pattern['count']} events matched this pattern",
                f"Top levels: {', '.join(entry['value'] for entry in top_pattern['levels'][:3]) or 'n/a'}",
                f"Likely APIs: {', '.join(node['name'] for node in apis[:3]) or 'no direct route match'}",
            ],
        }
    )

    if tables or files:
        answers.append(
            {
                "title": "Likely code and data surfaces",
                "body": "LogThread matched this log set back to the indexed graph so you can jump straight to the likely code path.",
                "evidence": [
                    f"Files: {', '.join(node['filePath'] for node in files[:3]) or 'none'}",
                    f"Tables: {', '.join(node['name'] for node in tables[:3]) or 'none'}",
                ],
            }
        )

    if sequences:
        top_sequence = sequences[0]
        answers.append(
            {
                "title": "Strongest linked runtime journey",
                "body": f"{top_sequence['correlationType'].title()} `{top_sequence['correlationId']}` groups the densest sequence in this window.",
                "evidence": [
                    f"{top_sequence['count']} events in the chain",
                    f"Link mode: {top_sequence['linkageMode']} ({top_sequence['confidence']} confidence)",
                    f"Routes: {', '.join(entry['value'] for entry in top_sequence['routes'][:3]) or 'none'}",
                    f"Services: {', '.join(entry['value'] for entry in top_sequence['services'][:3]) or 'none'}",
                ],
            }
        )

    if baseline.get("available") and baseline.get("newPatterns"):
        newest = baseline["newPatterns"][0]
        answers.append(
            {
                "title": "New failure signature since the last analysis",
                "body": newest["sampleMessage"],
                "evidence": [
                    f"New pattern count: {newest['count']}",
                    baseline.get("summary") or "Compared with the previous runtime slice.",
                ],
            }
        )

    structured = sum(1 for event in events if event["structuredKind"] != "plain")
    answers.append(
        {
            "title": "Structured signal quality",
            "body": "The more structured the logs are, the more precisely LogThread can align runtime evidence back to code and data boundaries.",
            "evidence": [
                f"{structured}/{len(events)} events carried structured fields",
                f"{sum(1 for event in events if event['traceId'])} events included trace IDs",
                f"{sum(1 for event in events if event['requestId'])} events included request IDs",
                f"{sum(1 for event in events if event.get('correlationId'))} events included correlation IDs",
            ],
        }
    )
    answers.append(
        {
            "title": "Semantic coverage for runtime pivots",
            "body": "Trace, service, route, and exception fields determine how precisely LogThread can turn logs into code-aware explanations.",
            "evidence": [
                f"trace_id coverage: {round(semantic_coverage['traceIdRate'] * 100)}%",
                f"correlation_id coverage: {round(semantic_coverage['correlationIdRate'] * 100)}%",
                f"inferred journey rate: {round(semantic_coverage['inferredLinkRate'] * 100)}%",
                f"service coverage: {round(semantic_coverage['serviceRate'] * 100)}%",
                f"route coverage: {round(semantic_coverage['routeRate'] * 100)}%",
            ],
        }
    )
    return answers[:5]


def _unique(items: list[str]) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []
    for item in items:
        normalized = item.strip()
        if normalized and normalized not in seen:
            seen.add(normalized)
            ordered.append(normalized)
    return ordered
