"""Knowledge graph data model for Log Thread.

Defines the core node and relationship types that represent code-level
entities (files, functions, classes, etc.) and the edges between them
(calls, imports, contains, etc.).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class NodeLabel(Enum):
    """Labels for graph nodes representing code-level entities."""

    FILE = "file"
    FOLDER = "folder"
    FUNCTION = "function"
    CLASS = "class"
    METHOD = "method"
    INTERFACE = "interface"
    TYPE_ALIAS = "type_alias"
    ENUM = "enum"
    COMMUNITY = "community"
    PROCESS = "process"
    EXTERNAL_DEP = "external_dep"
    API_ENDPOINT = "api_endpoint"  # HTTP route node (method + path)
    DB_TABLE = "db_table"          # database table from SQL DDL or schema
    DB_COLUMN = "db_column"        # database column

class RelType(Enum):
    """Relationship types connecting graph nodes."""

    CONTAINS = "contains"
    DEFINES = "defines"
    CALLS = "calls"
    IMPORTS = "imports"
    EXTENDS = "extends"
    IMPLEMENTS = "implements"
    MEMBER_OF = "member_of"
    STEP_IN_PROCESS = "step_in_process"
    USES_TYPE = "uses_type"
    EXPORTS = "exports"
    COUPLED_WITH = "coupled_with"
    DEPENDS_ON = "depends_on"
    USES_LIBRARY = "uses_library"      # file → external_dep (code imports the library)
    HANDLES_ROUTE = "handles_route"    # function → api_endpoint (is the handler for)
    PROTECTED_BY = "protected_by"      # api_endpoint → function (middleware guard)
    QUERIES_TABLE = "queries_table"    # function → db_table (reads/writes the table)
    QUERIES_COLUMN = "queries_column"  # function → db_column (reads/writes the column)
    HAS_COLUMN = "has_column"          # db_table → db_column

def generate_id(label: NodeLabel, file_path: str, symbol_name: str = "") -> str:
    """Produce a deterministic node ID.

    Format: ``{label.value}:{file_path}:{symbol_name}``

    Args:
        label: The node label enum member.
        file_path: Path to the file the symbol belongs to.
        symbol_name: Optional name of the symbol within the file.

    Returns:
        A colon-separated string suitable for use as a graph node ID.
    """
    normalized = file_path.replace("\\", "/")
    return f"{label.value}:{normalized}:{symbol_name}"

@dataclass
class GraphNode:
    """A node in the knowledge graph representing a code entity.

    ``id``, ``label``, and ``name`` are required. All other fields carry
    sensible defaults so callers only need to supply what they know.
    """

    id: str
    label: NodeLabel
    name: str

    file_path: str = ""
    start_line: int = 0
    end_line: int = 0
    content: str = ""
    signature: str = ""
    language: str = ""
    class_name: str = ""

    is_dead: bool = False
    is_entry_point: bool = False
    is_exported: bool = False

    properties: dict[str, Any] = field(default_factory=dict)

@dataclass
class GraphRelationship:
    """A directed edge in the knowledge graph.

    ``id``, ``type``, ``source``, and ``target`` are required.
    """

    id: str
    type: RelType
    source: str
    target: str

    properties: dict[str, Any] = field(default_factory=dict)
