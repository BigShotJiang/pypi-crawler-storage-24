"""LLM Interface for Log Thread AI code modifications using Google Gemini."""

import logging
import os
from typing import Any, Optional

logger = logging.getLogger(__name__)


class AIIntegrationUnavailable(RuntimeError):
    """Raised when optional hosted AI dependencies are not installed."""


def ai_sdk_available() -> bool:
    try:
        from google import genai  # noqa: F401
    except ImportError:
        return False
    return True

class AIProviderConfig:
    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None):
        self.provider = "gemini"  # Now exclusively using Gemini
        self.api_key = api_key or os.getenv("LOGTHREAD_GEMINI_API_KEY", "")
        self.model = model or os.getenv("LOGTHREAD_AI_MODEL", "gemini-2.0-flash-exp")


class AIClient:
    def __init__(self, config: Optional[AIProviderConfig] = None):
        self.config = config or AIProviderConfig()

        if not self.config.api_key:
            logger.warning("LOGTHREAD_GEMINI_API_KEY is not set. AI modify features will fail.")

        self._setup_client()

    def _setup_client(self):
        """Initialize Google Gemini client using the new google-genai SDK."""
        try:
            from google import genai
            from google.genai import types

            # Create client with API key
            self.client = genai.Client(api_key=self.config.api_key)
            self.types = types
        except ImportError:
            message = "Hosted AI support is optional. Install it with: pip install 'logthread[ai]'"
            logger.error(message)
            raise AIIntegrationUnavailable(message)
        except Exception as e:
            logger.error(f"Failed to initialize Gemini client: {e}")
            raise

    def suggest_edit(self, instruction: str, file_path: str, file_content: str, context: str = "") -> str:
        """Call Gemini to get a suggested code modification."""

        system_instruction = (
            "You are an expert AI software engineer. You are given a specific instruction to modify a file.\n"
            "Respond ONLY with the complete updated file content. Do not include markdown code block formatting like ```python, "
            "do not include explanations, do not include diff blocks. Just the raw, valid code file content."
        )

        user_prompt = (
            f"File to modify: {file_path}\n"
            f"Task: {instruction}\n\n"
        )
        if context:
            user_prompt += f"Supporting Graph Context:\n{context}\n\n"

        user_prompt += f"Original File Content:\n{file_content}\n"

        try:
            # Use the new SDK's generate_content method
            response = self.client.models.generate_content(
                model=self.config.model,
                contents=user_prompt,
                config=self.types.GenerateContentConfig(
                    system_instruction=system_instruction,
                    temperature=0.2,  # Lower temperature for more consistent code generation
                )
            )

            content = response.text

            # Ensure no markdown blocks
            return self._strip_markdown(content)
        except Exception as e:
            logger.error(f"Error calling Gemini: {e}")
            raise

    def suggest_edit_with_tools(
        self,
        instruction: str,
        file_path: str,
        file_content: str,
        context: str = "",
        tools: Optional[list[Any]] = None
    ) -> dict:
        """Call Gemini with tool calling support for advanced code modifications.
        
        Args:
            instruction: The modification instruction
            file_path: Path to the file being modified
            file_content: Current content of the file
            context: Additional graph context
            tools: List of tool definitions for Gemini to use
            
        Returns:
            Dict with 'content' (modified code) and optional 'tool_calls' (list of tool invocations)
        """
        system_instruction = (
            "You are an expert AI software engineer with access to code analysis tools. "
            "When modifying code, you can use the provided tools to understand dependencies, "
            "find related symbols, and ensure your changes are safe.\n\n"
            "After using tools to gather information, respond with the complete updated file content. "
            "Do not include markdown code blocks, explanations, or diff blocks. Just the raw code."
        )

        user_prompt = (
            f"File to modify: {file_path}\n"
            f"Task: {instruction}\n\n"
        )
        if context:
            user_prompt += f"Supporting Graph Context:\n{context}\n\n"

        user_prompt += f"Original File Content:\n{file_content}\n"

        try:
            # Use the new SDK with tools
            config_dict = {
                'system_instruction': system_instruction,
                'temperature': 0.2,
            }

            if tools:
                config_dict['tools'] = tools

            response = self.client.models.generate_content(
                model=self.config.model,
                contents=user_prompt,
                config=self.types.GenerateContentConfig(**config_dict)
            )

            result = {
                "content": self._strip_markdown(response.text) if response.text else "",
                "tool_calls": []
            }

            # Extract tool calls if any (new SDK structure)
            if hasattr(response, 'candidates') and response.candidates:
                for candidate in response.candidates:
                    if hasattr(candidate, 'content') and hasattr(candidate.content, 'parts'):
                        for part in candidate.content.parts:
                            if hasattr(part, 'function_call') and part.function_call:
                                result["tool_calls"].append({
                                    "name": part.function_call.name,
                                    "args": dict(part.function_call.args) if hasattr(part.function_call, 'args') else {}
                                })

            return result
        except Exception as e:
            logger.error(f"Error calling Gemini with tools: {e}")
            raise

    def _strip_markdown(self, content: str) -> str:
        """Strip markdown code blocks if the model stubbornly included them."""
        lines = content.splitlines()
        if not lines:
            return content

        if lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].startswith("```"):
            lines = lines[:-1]

        return "\n".join(lines)
