"""Local-only usage tracking."""

import json
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from .auth import CONFIG_DIR, CloudAuth


@dataclass
class UsageLimits:
    """Local-only limits model."""
    max_repos: int
    max_symbols_per_repo: int
    cloud_sync: bool
    priority_support: bool
    team_features: bool


TIER_LIMITS = {
    "local": UsageLimits(
        max_repos=-1,
        max_symbols_per_repo=-1,
        cloud_sync=False,
        priority_support=False,
        team_features=False,
    ),
}


class UsageTracker:
    """Track and enforce usage limits."""

    def __init__(self, auth: Optional[CloudAuth] = None):
        self.auth = auth or CloudAuth()
        self.usage_path = CONFIG_DIR / "usage.json"
        self._usage = self._load_usage()

    def _load_usage(self) -> dict:
        if self.usage_path.exists():
            try:
                return json.loads(self.usage_path.read_text())
            except Exception:
                pass
        return {
            "repos": [],
            "queries_today": 0,
            "queries_date": datetime.utcnow().date().isoformat(),
            "total_queries": 0,
            "total_analyses": 0,
        }

    def _save_usage(self) -> None:
        self.usage_path.parent.mkdir(parents=True, exist_ok=True)
        self.usage_path.write_text(json.dumps(self._usage, indent=2))

    @property
    def limits(self) -> UsageLimits:
        return TIER_LIMITS["local"]

    def get_stats(self) -> dict:
        """Get current usage statistics."""
        return {
            "tier": self.auth.tier,
            "repos_indexed": len(self._usage.get("repos", [])),
            "repos_limit": self.limits.max_repos,
            "total_queries": self._usage.get("total_queries", 0),
            "total_analyses": self._usage.get("total_analyses", 0),
            "cloud_sync_enabled": self.limits.cloud_sync,
        }

    def can_index_repo(self, repo_path: str) -> tuple[bool, str]:
        """Check if user can index another repo."""
        repos = self._usage.get("repos", [])

        # Already indexed - always allow re-index
        if repo_path in repos:
            return True, ""

        # Check limit
        return True, ""

    def record_repo_indexed(self, repo_path: str) -> None:
        """Record that a repo was indexed."""
        repos = self._usage.get("repos", [])
        if repo_path not in repos:
            repos.append(repo_path)
            self._usage["repos"] = repos

        self._usage["total_analyses"] = self._usage.get("total_analyses", 0) + 1
        self._save_usage()

    def record_query(self) -> None:
        """Record a query."""
        today = datetime.utcnow().date().isoformat()

        if self._usage.get("queries_date") != today:
            self._usage["queries_date"] = today
            self._usage["queries_today"] = 0

        self._usage["queries_today"] = self._usage.get("queries_today", 0) + 1
        self._usage["total_queries"] = self._usage.get("total_queries", 0) + 1
        self._save_usage()

    def get_upgrade_prompt(self) -> str:
        """Get contextual upgrade prompt based on usage."""
        stats = self.get_stats()

        return ""
