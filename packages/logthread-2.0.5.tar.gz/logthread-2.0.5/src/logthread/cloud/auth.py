"""Local-only auth shim.

The current LogThread build does not authenticate against LogThread-owned
services.
"""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Optional

CLOUD_API_URL = ""
CONFIG_DIR = Path.home() / ".logthread"


class CloudAuth:
    def __init__(self):
        self.config_path = CONFIG_DIR / "cloud.json"
        self._token: Optional[str] = None
        self._user_id: Optional[str] = None
        self._tier: str = "local"

    @property
    def is_authenticated(self) -> bool:
        return False

    @property
    def is_pro(self) -> bool:
        return False

    @property
    def user_id(self) -> Optional[str]:
        return self._user_id

    @property
    def tier(self) -> str:
        return self._tier

    def get_anonymous_id(self) -> str:
        machine_id_path = CONFIG_DIR / ".machine_id"
        if machine_id_path.exists():
            return machine_id_path.read_text().strip()
        anonymous_id = hashlib.sha256(str(CONFIG_DIR).encode("utf-8")).hexdigest()[:16]
        machine_id_path.parent.mkdir(parents=True, exist_ok=True)
        machine_id_path.write_text(anonymous_id)
        return anonymous_id

    async def login(self, email: str) -> dict:
        _ = email
        return {"ok": False, "message": "Hosted login is disabled in this local-only build."}

    async def verify_token(self, token: str) -> bool:
        _ = token
        return False

    def logout(self) -> None:
        self._token = None
        self._user_id = None
        self._tier = "local"
        if self.config_path.exists():
            try:
                self.config_path.unlink()
            except OSError:
                pass
