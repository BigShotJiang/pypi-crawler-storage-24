"""Local-only cloud compatibility shim.

The current LogThread build does not communicate with LogThread-owned hosted
services. These helpers remain only to preserve the old import surface while
returning local-safe defaults.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

CONFIG_DIR = Path.home() / ".logthread"
AUTH_FILE = CONFIG_DIR / "auth.json"


class CloudClient:
    """Compatibility shim for the retired cloud client."""

    def __init__(self, api_url: str = ""):
        self.api_url = api_url
        self._token: Optional[str] = None
        self._email: Optional[str] = None

    @property
    def is_authenticated(self) -> bool:
        return False

    @property
    def email(self) -> Optional[str]:
        return self._email

    @property
    def token(self) -> Optional[str]:
        return self._token

    def clear_auth(self) -> None:
        self._token = None
        self._email = None
        if AUTH_FILE.exists():
            try:
                AUTH_FILE.unlink()
            except OSError:
                pass

    def device_login(self, device_name: str = "Log Thread CLI") -> bool:
        _ = device_name
        return False

    def validate_subscription(self) -> tuple[bool, str]:
        return True, ""

    def sync_repo_metadata(
        self,
        repo_name: str,
        repo_path_hash: str,
        symbols_count: int,
        edges_count: int,
        files_count: int,
    ) -> Optional[str]:
        _ = (repo_name, repo_path_hash, symbols_count, edges_count, files_count)
        return None

    def upload_graph_json(
        self,
        repo_id: str,
        nodes: list[dict],
        edges: list[dict],
        prev_hash: Optional[str] = None,
        progress_cb=None,
    ) -> tuple[bool, str, str]:
        _ = (repo_id, nodes, edges, prev_hash, progress_cb)
        return False, "Cloud upload is disabled in this local-only build.", ""


_client: Optional[CloudClient] = None


def get_client() -> CloudClient:
    global _client  # noqa: PLW0603
    if _client is None:
        _client = CloudClient()
    return _client


def require_subscription() -> tuple[bool, str]:
    """Local builds never require a subscription."""
    return True, ""
