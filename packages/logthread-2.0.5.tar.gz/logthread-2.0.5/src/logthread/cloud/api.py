"""Log Thread Cloud API backend specification.

This module defines the API endpoints needed for the cloud backend.
Deploy this as a separate service (FastAPI recommended).

Required Infrastructure:
- PostgreSQL for user data
- Redis for rate limiting  
- Stripe for payments
- PostHog or similar for analytics
"""

from dataclasses import dataclass


@dataclass
class CloudAPISpec:
    """API specification for Log Thread Cloud backend."""

    # Authentication endpoints
    AUTH_ENDPOINTS = {
        "POST /auth/magic-link": "Send magic link email for passwordless auth",
        "GET /auth/verify": "Verify JWT token and return user info",
        "POST /auth/refresh": "Refresh access token",
    }

    # Billing endpoints (Stripe integration)
    BILLING_ENDPOINTS = {
        "GET /billing/subscription": "Get current subscription status",
        "POST /billing/checkout": "Create Stripe checkout session",
        "POST /billing/portal": "Create Stripe customer portal session",
        "POST /billing/webhook": "Handle Stripe webhooks",
    }

    # Telemetry endpoints
    TELEMETRY_ENDPOINTS = {
        "POST /telemetry/events": "Batch ingest telemetry events",
        "GET /telemetry/stats": "Get usage statistics (Pro+)",
    }

    # Graph sync endpoints (Pro+)
    SYNC_ENDPOINTS = {
        "POST /sync/upload": "Upload graph snapshot",
        "GET /sync/download/{repo_id}": "Download graph snapshot",
        "GET /sync/repos": "List synced repositories",
    }

    # Team endpoints (Enterprise)
    TEAM_ENDPOINTS = {
        "GET /team/members": "List team members",
        "POST /team/invite": "Invite team member",
        "GET /team/usage": "Team-wide usage statistics",
    }


# Database schema (PostgreSQL)
SCHEMA_SQL = '''
-- Users
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    tier VARCHAR(50) DEFAULT 'free',
    stripe_customer_id VARCHAR(255),
    anonymous_id VARCHAR(64)
);

-- Subscriptions
CREATE TABLE subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),
    stripe_subscription_id VARCHAR(255),
    status VARCHAR(50),
    current_period_end TIMESTAMP,
    cancel_at_period_end BOOLEAN DEFAULT FALSE
);

-- Telemetry events
CREATE TABLE events (
    id BIGSERIAL PRIMARY KEY,
    user_id UUID REFERENCES users(id),
    anonymous_id VARCHAR(64),
    event VARCHAR(255) NOT NULL,
    properties JSONB,
    timestamp TIMESTAMP DEFAULT NOW()
);

-- Synced graphs (Pro+)
CREATE TABLE graphs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),
    repo_name VARCHAR(255),
    repo_hash VARCHAR(64),
    snapshot_url VARCHAR(512),
    symbols_count INTEGER,
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Teams (Enterprise)
CREATE TABLE teams (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255),
    owner_id UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE team_members (
    team_id UUID REFERENCES teams(id),
    user_id UUID REFERENCES users(id),
    role VARCHAR(50) DEFAULT 'member',
    PRIMARY KEY (team_id, user_id)
);

-- Indexes
CREATE INDEX idx_events_user_id ON events(user_id);
CREATE INDEX idx_events_timestamp ON events(timestamp);
CREATE INDEX idx_graphs_user_id ON graphs(user_id);
'''


# Key metrics to track
METRICS_TO_TRACK = [
    # Acquisition
    "cli_install",           # pip install logthread
    "first_analyze",         # First successful analysis
    "extension_install",     # VS Code extension installed

    # Activation
    "mcp_connected",         # MCP server connected to Cursor/Windsurf
    "query_executed",        # Search/context/impact query
    "ui_opened",             # Web UI launched

    # Retention
    "daily_active",          # Daily active usage
    "weekly_repos_indexed",  # Repos indexed per week

    # Revenue
    "upgrade_prompt_shown",  # Showed upgrade prompt
    "checkout_started",      # Started checkout
    "subscription_created",  # Successful conversion
    "subscription_canceled", # Churn
]
