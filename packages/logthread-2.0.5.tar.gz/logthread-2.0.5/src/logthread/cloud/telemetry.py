"""Local-only telemetry shim.

Telemetry is disabled in the current build so no LogThread-owned endpoints are
contacted from the CLI, MCP server, or UI host.
"""

from __future__ import annotations

from typing import Optional


class Telemetry:
    def __init__(self):
        self._enabled = False

    def disable(self) -> None:
        self._enabled = False

    def enable(self) -> None:
        self._enabled = False

    def track(self, event: str, properties: Optional[dict] = None) -> None:
        _ = (event, properties)
        return None


_telemetry: Optional[Telemetry] = None


def get_telemetry() -> Telemetry:
    global _telemetry  # noqa: PLW0603
    if _telemetry is None:
        _telemetry = Telemetry()
    return _telemetry


def track(event: str, properties: Optional[dict] = None) -> None:
    _ = (event, properties)
    return None
