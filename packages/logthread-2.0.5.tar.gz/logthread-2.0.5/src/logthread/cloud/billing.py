"""Local-only billing shim."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class Subscription:
    tier: str
    status: str
    current_period_end: str
    cancel_at_period_end: bool


class BillingClient:
    def __init__(self, api_url: str = ""):
        self.api_url = api_url

    async def get_subscription(self, token: str) -> Optional[Subscription]:
        _ = token
        return None

    async def create_checkout_session(
        self,
        token: str,
        price_key: str = "pro_monthly",
    ) -> Optional[str]:
        _ = (token, price_key)
        return None

    async def create_portal_session(self, token: str) -> Optional[str]:
        _ = token
        return None


def get_pricing_table() -> str:
    return "Hosted billing is disabled in this local-only build."
