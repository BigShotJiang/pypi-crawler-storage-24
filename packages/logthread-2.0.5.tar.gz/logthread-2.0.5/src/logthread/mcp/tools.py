"""MCP tool handler implementations for Log Thread.

Each function accepts a storage backend and the tool-specific arguments,
performs the appropriate query, and returns a human-readable string suitable
for inclusion in an MCP ``TextContent`` response.
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
from collections import deque
from pathlib import Path
from typing import Any

from logthread.config.capabilities import build_capability_registry, format_capabilities_report
from logthread.core.analysis.impact import ImpactAnalyzer
from logthread.core.intelligence.edit_contract import build_edit_contract_packet
from logthread.core.intelligence.workspace import build_workspace_map
from logthread.core.cypher_guard import WRITE_KEYWORDS, sanitize_cypher
from logthread.core.embeddings.embedder import embed_query
from logthread.core.storage.base import SearchResult
from logthread.core.graph.model import GraphNode, NodeLabel
from logthread.core.ingestion.community import export_to_igraph
from logthread.core.ingestion.dead_code import _is_test_file
from logthread.core.parsers.sql_lang import extract_tables_from_query
from logthread.core.provenance import (
    infer_node_capability_tier,
    serialize_confidence,
    serialize_provenance,
    tier_rank,
)
from logthread.core.search.hybrid import hybrid_search
from logthread.core.storage.base import StorageBackend
from logthread.core.storage.ladybug_backend import escape_cypher as _escape_cypher
from logthread.mcp.resources import get_dead_code_list

logger = logging.getLogger(__name__)

MAX_TRAVERSE_DEPTH = 10
TRACE_REL_TYPES = (
    "calls",
    "imports",
    "defines",
    "depends_on",
    "uses_library",
    "queries_table",
    "queries_column",
    "has_column",
    "handles_route",
    "protected_by",
    "uses_type",
)
TRACE_TRAVERSABLE_LABELS = {
    "function",
    "method",
    "class",
    "interface",
    "type_alias",
    "file",
    "module",
    "api_endpoint",
    "db_table",
    "db_column",
}

_SAFE_PATH = re.compile(r"^[a-zA-Z0-9._/\-\s]+$")


def _confidence_tag(confidence: float) -> str:
    """Return a visual confidence indicator for edge display."""
    if confidence >= 0.9:
        return ""
    if confidence >= 0.5:
        return " (~)"
    return " (?)"


def _serialize_packet_node(node: GraphNode | None) -> dict[str, Any] | None:
    if node is None:
        return None
    return {
        "id": node.id,
        "label": node.label.value,
        "name": node.name,
        "filePath": node.file_path,
        "startLine": node.start_line,
        "endLine": node.end_line,
        "signature": node.signature,
        "language": node.language,
        "isEntryPoint": node.is_entry_point,
        "isDead": node.is_dead,
        "provenance": serialize_provenance(node.properties, fallback_source_id=node.id),
        "confidence": serialize_confidence(
            node.properties,
            fallback_tier=infer_node_capability_tier(node),
        ),
    }


def _limit_packet_nodes(nodes: list[GraphNode], limit: int = 12) -> list[dict[str, Any]]:
    return [_serialize_packet_node(node) for node in nodes[:limit] if node is not None]


def _collect_test_impacts(
    storage: StorageBackend,
    changed_nodes: list[GraphNode],
    *,
    depth: int,
) -> list[GraphNode]:
    tests: dict[str, GraphNode] = {}
    for node in changed_nodes:
        try:
            impacted = storage.traverse_with_depth(node.id, depth, direction="callers")
        except Exception:
            impacted = []
        for candidate, _hop in impacted:
            if _is_test_file(candidate.file_path) or candidate.name.startswith("test"):
                tests[candidate.id] = candidate
    return list(tests.values())


def build_symbol_context_packet(storage: StorageBackend, symbol: str) -> dict[str, Any]:
    packet: dict[str, Any] = {
        "kind": "symbol_context",
        "query": symbol,
        "summary": "",
        "target": None,
        "repo": {},
        "confidence": {"tier": "T0", "score": 0.0},
        "files": [],
        "relatedSymbols": [],
        "affected": {"apis": [], "tables": [], "components": [], "tests": []},
        "unresolvedAmbiguities": [],
        "errors": [],
    }
    if not symbol or not symbol.strip():
        packet["summary"] = "No symbol provided."
        packet["errors"] = ["A symbol is required to build a context packet."]
        return packet

    results = _resolve_symbol(storage, symbol)
    if not results:
        packet["summary"] = f"Symbol '{symbol}' was not found."
        packet["errors"] = [f"Symbol '{symbol}' is not indexed in the current project."]
        return packet

    node = storage.get_node(results[0].node_id)
    if node is None:
        packet["summary"] = f"Symbol '{symbol}' was not found."
        packet["errors"] = [f"Symbol '{symbol}' resolved to a missing graph node."]
        return packet

    try:
        callers_raw = storage.get_callers_with_confidence(node.id)
    except (AttributeError, TypeError):
        callers_raw = [(c, 1.0) for c in storage.get_callers(node.id)]
    try:
        callees_raw = storage.get_callees_with_confidence(node.id)
    except (AttributeError, TypeError):
        callees_raw = [(c, 1.0) for c in storage.get_callees(node.id)]
    type_refs = storage.get_type_refs(node.id)

    try:
        impact = ImpactAnalyzer(storage).analyze_impact(node.id, max_depth=3)
        impacted_endpoints = impact.impacted_endpoints
        impacted_tables = impact.impacted_tables
        impacted_components = impact.impacted_components
    except Exception:
        impacted_endpoints = []
        impacted_tables = []
        impacted_components = []

    related_nodes = [node]
    related_nodes.extend(item[0] for item in callers_raw)
    related_nodes.extend(item[0] for item in callees_raw)
    related_nodes.extend(type_refs)

    confidence = serialize_confidence(
        node.properties,
        fallback_tier=infer_node_capability_tier(node),
    )
    provenance = serialize_provenance(node.properties, fallback_source_id=node.id)
    packet["summary"] = (
        f"{node.name} has {len(callers_raw)} callers, {len(callees_raw)} callees, "
        f"and {len(impacted_endpoints) + len(impacted_tables)} high-signal downstream impacts."
    )
    packet["target"] = _serialize_packet_node(node)
    packet["repo"] = {
        "repoPath": provenance.get("repoPath"),
        "commitSha": provenance.get("commitSha"),
        "observedAt": provenance.get("observedAt"),
        "lastVerifiedAt": provenance.get("lastVerifiedAt"),
    }
    packet["confidence"] = confidence
    packet["files"] = sorted({n.file_path for n in related_nodes if n and n.file_path})
    packet["relatedSymbols"] = _limit_packet_nodes(related_nodes, limit=16)
    packet["affected"] = {
        "apis": _limit_packet_nodes(impacted_endpoints),
        "tables": _limit_packet_nodes(impacted_tables),
        "components": _limit_packet_nodes(impacted_components),
        "tests": _limit_packet_nodes(_collect_test_impacts(storage, [node], depth=3)),
    }

    unresolved: list[str] = []
    if tier_rank(confidence["tier"]) < tier_rank("T2"):
        unresolved.append(
            f"{node.language or node.label.value} is below T2 confidence; validate this context before editing critical paths."
        )
    if not provenance.get("commitSha"):
        unresolved.append("Repository commit SHA is unavailable, so freshness cannot be pinned to a specific revision.")
    packet["unresolvedAmbiguities"] = unresolved
    return packet


def build_change_risk_packet(storage: StorageBackend, diff: str, depth: int = 3) -> dict[str, Any]:
    changed_files = _parse_diff_files(diff)
    diff_stats = _parse_diff_stats(diff)
    packet: dict[str, Any] = {
        "kind": "change_risk",
        "summary": "",
        "risk": {"level": "LOW", "score": 0},
        "confidence": {"tier": "T0", "score": 0.0},
        "repo": {},
        "changedFiles": [],
        "changedSymbols": [],
        "affected": {"apis": [], "tables": [], "components": [], "tests": []},
        "unresolvedAmbiguities": [],
        "errors": [],
    }
    if not diff.strip():
        packet["summary"] = "No diff provided."
        packet["errors"] = ["A git diff is required to compute change risk."]
        return packet
    if not changed_files:
        packet["summary"] = "No changed files could be parsed from the diff."
        packet["errors"] = ["The provided diff did not contain parseable file hunks."]
        return packet

    changed_nodes: dict[str, GraphNode] = {}
    for file_path, ranges in changed_files.items():
        if not _SAFE_PATH.match(file_path):
            continue
        rows = storage.execute_raw(
            f"MATCH (n) WHERE n.file_path = '{_escape_cypher(file_path)}' "
            f"AND n.start_line > 0 "
            f"RETURN n.id, n.name, n.start_line, n.end_line"
        ) or []
        for row in rows:
            node_id = row[0] or ""
            start_line = row[2] or 0
            end_line = row[3] or 0
            if any(start_line <= end and end_line >= start for start, end in ranges):
                node = storage.get_node(node_id)
                if node is not None:
                    changed_nodes[node.id] = node

    changed_node_list = list(changed_nodes.values())
    impacted_endpoints: dict[str, GraphNode] = {}
    impacted_tables: dict[str, GraphNode] = {}
    impacted_components: dict[str, GraphNode] = {}
    for node in changed_node_list:
        try:
            report = ImpactAnalyzer(storage).analyze_impact(node.id, max_depth=depth)
        except Exception:
            continue
        impacted_endpoints.update({item.id: item for item in report.impacted_endpoints})
        impacted_tables.update({item.id: item for item in report.impacted_tables})
        impacted_components.update({item.id: item for item in report.impacted_components})

    impacted_tests = _collect_test_impacts(storage, changed_node_list, depth=depth)
    risk_score = min(
        100,
        len(changed_node_list) * 5
        + len(impacted_endpoints) * 8
        + len(impacted_tables) * 6
        + len(impacted_components) * 2
        + len(impacted_tests) * 3,
    )
    if risk_score >= 70:
        risk_level = "HIGH"
    elif risk_score >= 40:
        risk_level = "MEDIUM"
    else:
        risk_level = "LOW"

    tiers = [
        serialize_confidence(
            node.properties,
            fallback_tier=infer_node_capability_tier(node),
        )["tier"]
        for node in changed_node_list
    ]
    min_tier = min(tiers, key=tier_rank) if tiers else "T0"
    avg_confidence = (
        sum(
            serialize_confidence(
                node.properties,
                fallback_tier=infer_node_capability_tier(node),
            )["score"]
            for node in changed_node_list
        ) / len(changed_node_list)
        if changed_node_list
        else 0.0
    )
    first_node = changed_node_list[0] if changed_node_list else None
    first_provenance = serialize_provenance(
        first_node.properties if first_node else {},
        fallback_source_id=first_node.id if first_node else "",
    )
    packet["summary"] = (
        f"{risk_level} risk across {len(changed_files)} files, {len(changed_node_list)} changed symbols, "
        f"{len(impacted_endpoints)} APIs, and {len(impacted_tables)} data entities."
    )
    packet["risk"] = {"level": risk_level, "score": risk_score}
    packet["confidence"] = {"tier": min_tier, "score": round(avg_confidence, 3)}
    packet["repo"] = {
        "repoPath": first_provenance.get("repoPath"),
        "commitSha": first_provenance.get("commitSha"),
        "observedAt": first_provenance.get("observedAt"),
        "lastVerifiedAt": first_provenance.get("lastVerifiedAt"),
    }
    packet["changedFiles"] = [
        {
            "path": file_path,
            "lineRanges": ranges,
            "stats": diff_stats.get(file_path, {"additions": 0, "deletions": 0}),
        }
        for file_path, ranges in changed_files.items()
    ]
    packet["changedSymbols"] = _limit_packet_nodes(changed_node_list, limit=24)
    packet["affected"] = {
        "apis": _limit_packet_nodes(list(impacted_endpoints.values()), limit=16),
        "tables": _limit_packet_nodes(list(impacted_tables.values()), limit=16),
        "components": _limit_packet_nodes(list(impacted_components.values()), limit=16),
        "tests": _limit_packet_nodes(impacted_tests, limit=16),
    }

    unresolved: list[str] = []
    if tier_rank(min_tier) < tier_rank("T2"):
        unresolved.append(
            "One or more changed symbols are below T2 confidence, so impact and risk results may miss semantic edges."
        )
    if not changed_node_list:
        unresolved.append("The diff touched files, but no indexed symbols matched the changed line ranges.")
    if not first_provenance.get("commitSha"):
        unresolved.append("No commit SHA is attached to the indexed graph, so this analysis cannot be tied to a specific revision.")
    packet["unresolvedAmbiguities"] = unresolved
    return packet


def build_confidence_report_packet(storage: StorageBackend) -> dict[str, Any]:
    graph = storage.load_graph()
    tiers = {"T0": 0, "T1": 0, "T2": 0, "T3": 0}
    low_confidence: list[GraphNode] = []
    languages: dict[str, int] = {}
    for node in graph.iter_nodes():
        confidence = serialize_confidence(
            node.properties,
            fallback_tier=infer_node_capability_tier(node),
        )
        tiers[confidence["tier"]] = tiers.get(confidence["tier"], 0) + 1
        if node.language:
            languages[node.language] = languages.get(node.language, 0) + 1
        if confidence["score"] < 0.7:
            low_confidence.append(node)

    summary = (
        f"{tiers.get('T2', 0) + tiers.get('T3', 0)} nodes are T2+ ready; "
        f"{len(low_confidence)} nodes remain in low-confidence territory."
    )
    return {
        "kind": "confidence_report",
        "summary": summary,
        "tierCounts": tiers,
        "languages": languages,
        "lowConfidenceNodes": _limit_packet_nodes(low_confidence, limit=20),
    }


def build_language_capabilities_packet() -> dict[str, Any]:
    registry = build_capability_registry()
    registry["kind"] = "language_capabilities"
    registry["summary"] = (
        "Broad discovery coverage is available early, but only T2+ stacks should be treated as high-trust for edit planning."
    )
    return registry


def _search_nodes(storage: StorageBackend, query: str, *, limit: int) -> list[GraphNode]:
    if not query.strip():
        return []

    try:
        query_embedding = embed_query(query)
    except Exception:
        query_embedding = None

    results: list[SearchResult] = []
    try:
        results = hybrid_search(query, storage, query_embedding=query_embedding, limit=limit)
    except Exception:
        try:
            results = storage.fts_search(query, limit=limit)
        except Exception:
            results = []

    nodes: list[GraphNode] = []
    seen: set[str] = set()
    for result in results:
        if not result.node_id or result.node_id in seen:
            continue
        node = storage.get_node(result.node_id)
        if node is None:
            continue
        seen.add(node.id)
        nodes.append(node)
    return nodes


def _dedupe_nodes(nodes: list[GraphNode]) -> list[GraphNode]:
    seen: set[str] = set()
    deduped: list[GraphNode] = []
    for node in nodes:
        if node.id in seen:
            continue
        seen.add(node.id)
        deduped.append(node)
    return deduped


def _find_same_name_nodes(storage: StorageBackend, name: str, *, limit: int = 8) -> list[GraphNode]:
    if not name.strip():
        return []
    results: list[SearchResult] = []
    if hasattr(storage, "exact_name_search"):
        try:
            results = storage.exact_name_search(name, limit=limit)
        except Exception:
            results = []
    nodes: list[GraphNode] = []
    for result in results:
        node = storage.get_node(result.node_id)
        if node is not None:
            nodes.append(node)
    return _dedupe_nodes(nodes)


def _collect_file_dependencies(storage: StorageBackend, file_paths: list[str]) -> list[str]:
    libraries: set[str] = set()
    for file_path in file_paths:
        if not file_path or not _SAFE_PATH.match(file_path):
            continue
        query = (
            f"MATCH (f:File)-[:DEPENDS_ON]->(d:ExternalDep) "
            f"WHERE f.file_path = '{_escape_cypher(file_path)}' "
            "RETURN DISTINCT d.name"
        )
        try:
            rows = storage.execute_raw(query) or []
        except Exception:
            continue
        for row in rows:
            if row and row[0]:
                libraries.add(str(row[0]))
    return sorted(libraries)


def build_implementation_brief_packet(
    storage: StorageBackend,
    query: str,
    *,
    symbol: str = "",
    max_candidates: int = 8,
) -> dict[str, Any]:
    packet: dict[str, Any] = {
        "kind": "implementation_brief",
        "objective": query,
        "summary": "",
        "anchor": None,
        "confidence": {"tier": "T0", "score": 0.0},
        "exactTargets": [],
        "reuseCandidates": [],
        "avoidSymbols": [],
        "existingDependencies": [],
        "affected": {"apis": [], "tables": [], "components": [], "tests": []},
        "implementationSteps": [],
        "unresolvedAmbiguities": [],
        "errors": [],
    }

    if not query.strip() and not symbol.strip():
        packet["summary"] = "No implementation objective was provided."
        packet["errors"] = ["Provide a natural-language objective or an anchor symbol."]
        return packet

    anchor_node: GraphNode | None = None
    if symbol.strip():
        resolved = _resolve_symbol(storage, symbol)
        if resolved:
            anchor_node = storage.get_node(resolved[0].node_id)

    search_nodes = _search_nodes(storage, query or symbol, limit=max_candidates)
    if anchor_node is None and search_nodes:
        anchor_node = search_nodes[0]

    if anchor_node is None:
        packet["summary"] = "No indexed target matched the requested implementation objective."
        packet["errors"] = ["LogThread could not resolve a high-signal edit target from the current graph."]
        return packet

    try:
        callers_raw = storage.get_callers_with_confidence(anchor_node.id)
    except (AttributeError, TypeError):
        callers_raw = []
    try:
        callees_raw = storage.get_callees_with_confidence(anchor_node.id)
    except (AttributeError, TypeError):
        callees_raw = []
    try:
        type_refs = storage.get_type_refs(anchor_node.id)
    except Exception:
        type_refs = []

    exact_targets = _dedupe_nodes([anchor_node, *search_nodes])[:max_candidates]
    reuse_candidates = _dedupe_nodes(
        [item[0] for item in callees_raw if item and item[0] is not None]
        + type_refs
        + search_nodes[1:]
    )[:max_candidates]

    same_name_nodes = [node for node in _find_same_name_nodes(storage, anchor_node.name) if node.id != anchor_node.id]
    exact_target_files = sorted({node.file_path for node in exact_targets if node.file_path})
    existing_dependencies = _collect_file_dependencies(storage, exact_target_files)[:16]

    impacted_endpoints: dict[str, GraphNode] = {}
    impacted_tables: dict[str, GraphNode] = {}
    impacted_components: dict[str, GraphNode] = {}
    for node in exact_targets[:4]:
        try:
            report = ImpactAnalyzer(storage).analyze_impact(node.id, max_depth=3)
        except Exception:
            continue
        impacted_endpoints.update({item.id: item for item in report.impacted_endpoints})
        impacted_tables.update({item.id: item for item in report.impacted_tables})
        impacted_components.update({item.id: item for item in report.impacted_components})
    impacted_tests = _collect_test_impacts(storage, exact_targets[:4], depth=3)

    confidence = serialize_confidence(
        anchor_node.properties,
        fallback_tier=infer_node_capability_tier(anchor_node),
    )

    steps = [
        f"Edit the existing anchor symbol '{anchor_node.name}' in {anchor_node.file_path or 'the indexed target file'} before creating new parallel code.",
    ]
    if reuse_candidates:
        reuse_summary = ", ".join(node.name for node in reuse_candidates[:4])
        steps.append(f"Reuse nearby indexed logic where possible: {reuse_summary}.")
    if existing_dependencies:
        deps_summary = ", ".join(existing_dependencies[:6])
        steps.append(f"Stay within the existing dependency stack in this area: {deps_summary}.")
    if impacted_endpoints or impacted_tables or impacted_tests:
        steps.append(
            f"Validate downstream impact across {len(impacted_endpoints)} APIs, {len(impacted_tables)} data entities, and {len(impacted_tests)} tests."
        )
    if same_name_nodes:
        steps.append("Avoid similarly named symbols in other files unless the change explicitly spans those implementations.")

    unresolved: list[str] = []
    if tier_rank(confidence["tier"]) < tier_rank("T2"):
        unresolved.append(
            f"{anchor_node.language or anchor_node.label.value} is below T2 confidence, so semantic edit guidance may miss some scope boundaries."
        )
    if len(same_name_nodes) > 0:
        unresolved.append(
            f"{len(same_name_nodes)} other symbols share the name '{anchor_node.name}', so the assistant should pin edits to exact file paths."
        )
    if not existing_dependencies:
        unresolved.append("No existing dependency context was found for the target files, so library reuse guidance may be incomplete.")

    packet["summary"] = (
        f"Anchor '{anchor_node.name}' resolved with {len(exact_targets)} exact targets, "
        f"{len(reuse_candidates)} reuse candidates, and {len(impacted_endpoints) + len(impacted_tables)} downstream high-signal impacts."
    )
    packet["anchor"] = _serialize_packet_node(anchor_node)
    packet["confidence"] = confidence
    packet["exactTargets"] = _limit_packet_nodes(exact_targets, limit=max_candidates)
    packet["reuseCandidates"] = _limit_packet_nodes(reuse_candidates, limit=max_candidates)
    packet["avoidSymbols"] = _limit_packet_nodes(same_name_nodes, limit=8)
    packet["existingDependencies"] = existing_dependencies
    packet["affected"] = {
        "apis": _limit_packet_nodes(list(impacted_endpoints.values()), limit=16),
        "tables": _limit_packet_nodes(list(impacted_tables.values()), limit=16),
        "components": _limit_packet_nodes(list(impacted_components.values()), limit=16),
        "tests": _limit_packet_nodes(impacted_tests, limit=16),
    }
    packet["implementationSteps"] = steps
    packet["unresolvedAmbiguities"] = unresolved
    return packet


def handle_implementation_brief(
    storage: StorageBackend,
    query: str,
    *,
    symbol: str = "",
    max_candidates: int = 8,
) -> str:
    packet = build_implementation_brief_packet(storage, query, symbol=symbol, max_candidates=max_candidates)
    if packet["errors"]:
        return f"Implementation brief unavailable: {packet['errors'][0]}"

    lines = [
        "Implementation Brief",
        "====================",
        packet["summary"],
        "",
    ]
    anchor = packet.get("anchor")
    if anchor:
        lines.append(f"Anchor: {anchor['name']} ({anchor['label']})")
        if anchor.get("filePath"):
            lines.append(f"File: {anchor['filePath']}:{anchor.get('startLine') or 0}")
        lines.append(f"Confidence: {packet['confidence']['tier']} ({packet['confidence']['score']:.2f})")
        lines.append("")
    if packet["exactTargets"]:
        lines.append("Exact edit targets:")
        for node in packet["exactTargets"][:6]:
            lines.append(f"  • {node['name']} — {node['filePath']}")
        lines.append("")
    if packet["reuseCandidates"]:
        lines.append("Reuse before rewrite:")
        for node in packet["reuseCandidates"][:6]:
            lines.append(f"  • {node['name']} — {node['filePath']}")
        lines.append("")
    if packet["existingDependencies"]:
        lines.append("Existing dependencies in target area:")
        for dep in packet["existingDependencies"][:8]:
            lines.append(f"  • {dep}")
        lines.append("")
    if packet["implementationSteps"]:
        lines.append("Guardrails:")
        for step in packet["implementationSteps"]:
            lines.append(f"  • {step}")
        lines.append("")
    if packet["unresolvedAmbiguities"]:
        lines.append("Ambiguities:")
        for item in packet["unresolvedAmbiguities"]:
            lines.append(f"  • {item}")
    return "\n".join(lines).strip()


def build_agent_safe_edit_contract_packet(
    storage: StorageBackend,
    repo_path: Path,
    query: str,
    *,
    symbol: str = "",
    max_candidates: int = 8,
) -> dict[str, Any]:
    implementation_brief_packet = build_implementation_brief_packet(
        storage,
        query,
        symbol=symbol,
        max_candidates=max_candidates,
    )
    if implementation_brief_packet["errors"]:
        return {
            "kind": "edit_contract",
            "objective": query,
            "summary": implementation_brief_packet["summary"],
            "anchor": None,
            "confidence": {"tier": "T0", "score": 0.0},
            "exactTargets": [],
            "avoidSymbols": [],
            "scopedTargets": [],
            "dependencyTruth": {"projects": [], "relevantPackages": [], "missingLockfiles": []},
            "crossProjectImpact": {"ownerProjects": [], "impactedProjects": []},
            "safeEditChecklist": [],
            "unresolvedAmbiguities": [],
            "errors": implementation_brief_packet["errors"],
        }
    return build_edit_contract_packet(repo_path, implementation_brief_packet)


def handle_agent_safe_edit_contract(
    storage: StorageBackend,
    repo_path: Path,
    query: str,
    *,
    symbol: str = "",
    max_candidates: int = 8,
) -> str:
    packet = build_agent_safe_edit_contract_packet(
        storage,
        repo_path,
        query,
        symbol=symbol,
        max_candidates=max_candidates,
    )
    if packet["errors"]:
        return f"Agent-safe edit contract unavailable: {packet['errors'][0]}"

    lines = [
        "Agent-Safe Edit Contract",
        "========================",
        packet["summary"],
        "",
    ]
    anchor = packet.get("anchor")
    if anchor:
        lines.append(f"Anchor: {anchor['name']} ({anchor['label']})")
        if anchor.get("filePath"):
            lines.append(f"File: {anchor['filePath']}:{anchor.get('startLine') or 0}")
        lines.append(f"Confidence: {packet['confidence']['tier']} ({packet['confidence']['score']:.2f})")
        lines.append("")

    if packet["scopedTargets"]:
        lines.append("Scoped targets:")
        for target in packet["scopedTargets"][:4]:
            details = [
                f"params={len(target['parameters'])}",
                f"vars={len(target['variables'])}",
                f"calls={len(target['localCalls'])}",
            ]
            lines.append(f"  • {target['nodeName']} — {target['filePath']} [{', '.join(details)}]")
        lines.append("")

    relevant_packages = packet.get("dependencyTruth", {}).get("relevantPackages", [])
    if relevant_packages:
        lines.append("Lockfile-backed dependencies:")
        for item in relevant_packages[:8]:
            resolved = item.get("resolvedVersion") or "unresolved"
            lines.append(
                f"  • {item['name']} — {resolved} ({item.get('packageManager') or 'manifest'})"
            )
        lines.append("")

    impacted_projects = packet.get("crossProjectImpact", {}).get("impactedProjects", [])
    if impacted_projects:
        lines.append("Cross-project impact:")
        for item in impacted_projects[:8]:
            lines.append(f"  • {item['projectName']} — {item['reason']}")
        lines.append("")

    if packet["safeEditChecklist"]:
        lines.append("Checklist:")
        for item in packet["safeEditChecklist"]:
            lines.append(f"  • {item}")
        lines.append("")

    if packet["unresolvedAmbiguities"]:
        lines.append("Ambiguities:")
        for item in packet["unresolvedAmbiguities"][:10]:
            lines.append(f"  • {item}")
    return "\n".join(lines).strip()


def handle_workspace_map(repo_path: Path) -> str:
    packet = build_workspace_map(repo_path)
    lines = [
        "Workspace Map",
        "=============",
        packet["summary"],
        "",
    ]
    if packet["workspaceManagers"]:
        lines.append("Workspace signals:")
        for item in packet["workspaceManagers"]:
            lines.append(f"  • {item['name']} — {item['path']}")
        lines.append("")
    if packet["projects"]:
        lines.append("Projects:")
        for project in packet["projects"][:20]:
            lines.append(
                f"  • {project['name']} ({project['kind']}) — {project['rootPath']} "
                f"[outgoing {project['internalReferenceCount']}, incoming {project['incomingReferenceCount']}]"
            )
        lines.append("")
    if packet["references"]:
        lines.append("Internal references:")
        project_names = {item["id"]: item["name"] for item in packet["projects"]}
        for ref in packet["references"][:20]:
            lines.append(
                f"  • {project_names.get(ref['sourceProjectId'], ref['sourceProjectId'])} -> "
                f"{project_names.get(ref['targetProjectId'], ref['targetProjectId'])} "
                f"({ref['type']})"
            )
        lines.append("")
    if packet["unresolvedAmbiguities"]:
        lines.append("Ambiguities:")
        for item in packet["unresolvedAmbiguities"][:10]:
            lines.append(f"  • {item}")
    return "\n".join(lines).strip()


def _resolve_symbol(storage: StorageBackend, symbol: str) -> list:
    """Resolve a symbol name to search results, preferring exact name matches."""
    direct = None
    prefix = symbol.split(":", 1)[0] if symbol else ""
    if prefix in {label.value for label in NodeLabel}:
        direct = storage.get_node(symbol)
    if isinstance(direct, GraphNode):
        class _DirectResult:
            def __init__(self, node_id: str) -> None:
                self.node_id = node_id
        return [_DirectResult(direct.id)]
    if hasattr(storage, "exact_name_search"):
        results = storage.exact_name_search(symbol, limit=1)
        if results:
            return results
    return storage.fts_search(symbol, limit=1)


def _is_api_like_symbol(node: GraphNode | None, symbol: str) -> bool:
    if node is not None and node.label == NodeLabel.API_ENDPOINT:
        return True
    return bool(re.match(r"^(GET|POST|PUT|PATCH|DELETE|USE):", symbol or "", re.IGNORECASE))


def _collect_trace_edges(
    storage: StorageBackend,
    start_node: GraphNode,
    *,
    max_depth: int,
) -> tuple[dict[str, GraphNode], list[dict[str, Any]], dict[str, int]]:
    node_map: dict[str, GraphNode] = {start_node.id: start_node}
    edge_rows: list[dict[str, Any]] = []
    depths: dict[str, int] = {start_node.id: 0}
    visited: set[str] = {start_node.id}
    frontier: list[str] = [start_node.id]
    include_incoming = _is_api_like_symbol(start_node, start_node.name)

    for depth in range(max_depth):
        if not frontier:
            break
        next_frontier: list[str] = []

        for current_id in frontier:
            safe_id = _escape_cypher(current_id)
            limit = 20 if depth == 0 else 10
            queries = [
                (
                    f"MATCH (src)-[r:CodeRelation]->(tgt) "
                    f"WHERE src.id = '{safe_id}' "
                    f"AND r.rel_type IN {list(TRACE_REL_TYPES)} "
                    f"RETURN src.id, src.name, labels(src)[0], src.file_path, "
                    f"r.rel_type, tgt.id, tgt.name, labels(tgt)[0], tgt.file_path "
                    f"LIMIT {limit}"
                ),
            ]
            if include_incoming and depth == 0:
                queries.append(
                    f"MATCH (src)-[r:CodeRelation]->(tgt) "
                    f"WHERE tgt.id = '{safe_id}' "
                    f"AND r.rel_type IN ['handles_route', 'protected_by', 'calls', 'depends_on', 'imports', 'defines'] "
                    f"RETURN src.id, src.name, labels(src)[0], src.file_path, "
                    f"r.rel_type, tgt.id, tgt.name, labels(tgt)[0], tgt.file_path "
                    f"LIMIT 12"
                )

            for query in queries:
                try:
                    rows = storage.execute_raw(query) or []
                except Exception:
                    continue
                for row in rows:
                    src_id = row[0] or ""
                    src_name = row[1] or ""
                    src_label = str(row[2] or "").lower()
                    src_file = row[3] or ""
                    rel_type = row[4] or ""
                    tgt_id = row[5] or ""
                    tgt_name = row[6] or ""
                    tgt_label = str(row[7] or "").lower()
                    tgt_file = row[8] or ""
                    if not src_id or not tgt_id:
                        continue

                    if src_id not in node_map:
                        src_node = storage.get_node(src_id)
                        if src_node is None:
                            continue
                        node_map[src_id] = src_node
                    if tgt_id not in node_map:
                        tgt_node = storage.get_node(tgt_id)
                        if tgt_node is None:
                            continue
                        node_map[tgt_id] = tgt_node

                    if not any(
                        existing["from_id"] == src_id and existing["to_id"] == tgt_id and existing["rel"] == rel_type
                        for existing in edge_rows
                    ):
                        edge_rows.append(
                            {
                                "from_id": src_id,
                                "from_name": src_name,
                                "from_label": src_label,
                                "from_file": src_file,
                                "rel": rel_type,
                                "to_id": tgt_id,
                                "to_name": tgt_name,
                                "to_label": tgt_label,
                                "to_file": tgt_file,
                            }
                        )

                    if tgt_id not in visited and tgt_label in TRACE_TRAVERSABLE_LABELS:
                        visited.add(tgt_id)
                        depths[tgt_id] = depth + 1
                        next_frontier.append(tgt_id)

        frontier = next_frontier[:12]

    return node_map, edge_rows, depths

def handle_list_repos(registry_dir: Path | None = None) -> str:
    """List indexed repositories by scanning for .logthread directories.

    Scans the global registry directory (defaults to ``~/.logthread/repos``) for
    project metadata files and returns a formatted summary.

    Args:
        registry_dir: Directory containing repo metadata. If ``None``,
            defaults to ``~/.logthread/repos``.

    Returns:
        Formatted list of indexed repositories with stats, or a message
        indicating none were found.
    """
    use_cwd_fallback = registry_dir is None
    if registry_dir is None:
        registry_dir = Path.home() / ".logthread" / "repos"

    repos: list[dict[str, Any]] = []

    if registry_dir.exists():
        for meta_file in registry_dir.glob("*/meta.json"):
            try:
                data = json.loads(meta_file.read_text())
                repos.append(data)
            except (json.JSONDecodeError, OSError):
                continue

    if not repos and use_cwd_fallback:
        cwd_logthread = Path.cwd() / ".logthread" / "meta.json"
        if cwd_logthread.exists():
            try:
                data = json.loads(cwd_logthread.read_text())
                repos.append(data)
            except (json.JSONDecodeError, OSError):
                pass

    if not repos:
        return "No indexed repositories found. Run `logthread analyze` on a project first."

    lines = [f"Indexed repositories ({len(repos)}):"]
    lines.append("")
    for i, repo in enumerate(repos, 1):
        name = repo.get("name", "unknown")
        path = repo.get("path", "")
        stats = repo.get("stats", {})
        files = stats.get("files", "?")
        symbols = stats.get("symbols", "?")
        relationships = stats.get("relationships", "?")
        lines.append(f"  {i}. {name}")
        lines.append(f"     Path: {path}")
        lines.append(f"     Files: {files}  Symbols: {symbols}  Relationships: {relationships}")
        lines.append("")

    return "\n".join(lines)

def _group_by_process(
    results: list,
    storage: StorageBackend,
) -> dict[str, list]:
    """Map search results to their parent execution processes."""
    if not results:
        return {}

    node_ids = [r.node_id for r in results]
    try:
        node_to_process = storage.get_process_memberships(node_ids)
    except AttributeError:
        return {}

    groups: dict[str, list] = {}
    for r in results:
        pname = node_to_process.get(r.node_id)
        if pname:
            groups.setdefault(pname, []).append(r)

    return groups


def _format_query_results(results: list, groups: dict[str, list]) -> str:
    """Format search results with process grouping.

    Results belonging to a process appear under a labelled section.
    Remaining results appear in an "Other results" section.
    """
    grouped_ids: set[str] = {r.node_id for group in groups.values() for r in group}
    ungrouped = [r for r in results if r.node_id not in grouped_ids]

    lines: list[str] = []
    counter = 1

    for process_name, proc_results in groups.items():
        lines.append(f"=== {process_name} ===")
        for r in proc_results:
            label = r.label.title() if r.label else "Unknown"
            lines.append(f"{counter}. {r.node_name} ({label}) -- {r.file_path}")
            if r.snippet:
                snippet = r.snippet[:200].replace("\n", " ").strip()
                lines.append(f"   {snippet}")
            counter += 1
        lines.append("")

    if ungrouped:
        if groups:
            lines.append("=== Other results ===")
        for r in ungrouped:
            label = r.label.title() if r.label else "Unknown"
            lines.append(f"{counter}. {r.node_name} ({label}) -- {r.file_path}")
            if r.snippet:
                snippet = r.snippet[:200].replace("\n", " ").strip()
                lines.append(f"   {snippet}")
            counter += 1
        lines.append("")

    lines.append("Next: Use context() on a specific symbol for the full picture.")
    return "\n".join(lines)


def handle_query(storage: StorageBackend, query: str, limit: int = 20) -> str:
    """Execute hybrid search and format results, grouped by execution process.

    Args:
        storage: The storage backend to search against.
        query: Text search query.
        limit: Maximum number of results (default 20, capped at 100).

    Returns:
        Formatted search results grouped by process, with file, name, label,
        and snippet for each result.
    """
    limit = max(1, min(limit, 100))

    query_embedding = embed_query(query)
    if query_embedding is None:
        logger.warning("embed_query returned None; falling back to FTS-only search")

    results = hybrid_search(query, storage, query_embedding=query_embedding, limit=limit)
    if not results:
        return f"No results found for '{query}'."

    groups = _group_by_process(results, storage)
    return _format_query_results(results, groups)

def handle_context(storage: StorageBackend, symbol: str) -> str:
    """Provide a 360-degree view of a symbol.

    Looks up the symbol by name via full-text search, then retrieves its
    callers, callees, and type references.

    Args:
        storage: The storage backend.
        symbol: The symbol name to look up.

    Returns:
        Formatted view including callers, callees, type refs, and guidance.
    """
    if not symbol or not symbol.strip():
        return "Error: 'symbol' parameter is required and cannot be empty."

    results = _resolve_symbol(storage, symbol)
    if not results:
        return f"Symbol '{symbol}' not found."

    node = storage.get_node(results[0].node_id)
    if not node:
        return f"Symbol '{symbol}' not found."

    label_display = node.label.value.title() if node.label else "Unknown"
    lines = [f"Symbol: {node.name} ({label_display})"]
    lines.append(f"File: {node.file_path}:{node.start_line}-{node.end_line}")

    if node.signature:
        lines.append(f"Signature: {node.signature}")

    if node.is_dead:
        lines.append("Status: DEAD CODE (unreachable)")

    try:
        callers_raw = storage.get_callers_with_confidence(node.id)
    except (AttributeError, TypeError):
        callers_raw = [(c, 1.0) for c in storage.get_callers(node.id)]

    if callers_raw:
        lines.append(f"\nCallers ({len(callers_raw)}):")
        for c, conf in callers_raw:
            tag = _confidence_tag(conf)
            lines.append(f"  -> {c.name}  {c.file_path}:{c.start_line}{tag}")

    try:
        callees_raw = storage.get_callees_with_confidence(node.id)
    except (AttributeError, TypeError):
        callees_raw = [(c, 1.0) for c in storage.get_callees(node.id)]

    if callees_raw:
        lines.append(f"\nCallees ({len(callees_raw)}):")
        for c, conf in callees_raw:
            tag = _confidence_tag(conf)
            lines.append(f"  -> {c.name}  {c.file_path}:{c.start_line}{tag}")

    type_refs = storage.get_type_refs(node.id)
    if type_refs:
        lines.append(f"\nType references ({len(type_refs)}):")
        for t in type_refs:
            lines.append(f"  -> {t.name}  {t.file_path}")

    escaped_id = _escape_cypher(node.id)
    heritage_rows = storage.execute_raw(
        f"MATCH (n)-[r:CodeRelation]->(parent) "
        f"WHERE n.id = '{escaped_id}' "
        f"AND r.rel_type IN ['extends', 'implements'] "
        f"RETURN parent.name, parent.file_path, r.rel_type"
    ) or []
    if heritage_rows:
        lines.append(f"\nHeritage ({len(heritage_rows)}):")
        for row in heritage_rows:
            parent_name = row[0] or "?"
            parent_file = row[1] or "?"
            rel = row[2] or "?"
            lines.append(f"  -> {rel}: {parent_name}  {parent_file}")

    if node.file_path:
        escaped_fp = _escape_cypher(node.file_path)
        import_rows = storage.execute_raw(
            f"MATCH (a:File)-[r:CodeRelation]->(b:File) "
            f"WHERE b.file_path = '{escaped_fp}' "
            f"AND r.rel_type = 'imports' "
            f"RETURN a.file_path ORDER BY a.file_path"
        ) or []
        if import_rows:
            importers = [r[0] for r in import_rows if r[0]]
            lines.append(f"\nImported by ({len(importers)}):")
            for imp in importers:
                lines.append(f"  -> {imp}")

    trace_depth = 4 if _is_api_like_symbol(node, symbol) else 2
    try:
        _, trace_edges, trace_depths = _collect_trace_edges(storage, node, max_depth=trace_depth)
    except Exception:
        trace_edges, trace_depths = [], {node.id: 0}

    if trace_edges:
        grouped: dict[int, list[str]] = {}
        seen_lines: set[str] = set()
        for edge in trace_edges:
            target_depth = trace_depths.get(edge["to_id"], 1)
            if target_depth <= 0:
                continue
            descriptor = (
                f"  - {edge['from_name']} --{edge['rel']}--> {edge['to_name']} "
                f"({edge['to_label'] or 'symbol'})"
            )
            if edge["to_file"]:
                descriptor += f"  {edge['to_file']}"
            if descriptor in seen_lines:
                continue
            seen_lines.add(descriptor)
            grouped.setdefault(target_depth, []).append(descriptor)

        if grouped:
            lines.append("\nDependency trace:")
            for depth in sorted(grouped):
                title = "Direct links" if depth == 1 else f"Depth {depth}"
                lines.append(f"  {title}:")
                for item in grouped[depth][:12]:
                    lines.append(item)

    lines.append("")
    lines.append("Next: Use impact() if planning changes to this symbol.")
    return "\n".join(lines)

_DEPTH_LABELS: dict[int, str] = {
    1: "Direct callers (will break)",
    2: "Indirect (may break)",
}


def handle_impact(storage: StorageBackend, symbol: str, depth: int = 3) -> str:
    """Analyse the blast radius of changing a symbol, grouped by hop depth.

    Uses BFS traversal through CALLS edges to find all affected symbols
    up to the specified depth, then groups results by distance.

    Args:
        storage: The storage backend.
        symbol: The symbol name to analyse.
        depth: Maximum traversal depth (default 3).

    Returns:
        Formatted impact analysis with depth-grouped sections.
    """
    if not symbol or not symbol.strip():
        return "Error: 'symbol' parameter is required and cannot be empty."

    depth = max(1, min(depth, MAX_TRAVERSE_DEPTH))

    results = _resolve_symbol(storage, symbol)
    if not results:
        return f"Symbol '{symbol}' not found."

    start_node = storage.get_node(results[0].node_id)
    if not start_node:
        return f"Symbol '{symbol}' not found."

    analyzer = ImpactAnalyzer(storage) if isinstance(storage, object) else None
    conf_lookup = {
        node.id: conf for node, conf in storage.get_callers_with_confidence(start_node.id)
    } if hasattr(storage, "get_callers_with_confidence") else {}

    visited: set[str] = {start_node.id}
    queue: deque[tuple[GraphNode, int]] = deque([(start_node, 0)])
    by_depth: dict[int, list[GraphNode]] = {}
    impacted_endpoints: dict[str, GraphNode] = {}
    impacted_tables: dict[str, GraphNode] = {}

    while queue:
        current_node, current_depth = queue.popleft()
        if current_depth >= depth:
            continue

        try:
            impacted = storage.get_impacted_nodes(current_node.id)  # type: ignore[attr-defined]
        except Exception:
            impacted = []
        if not isinstance(impacted, list):
            impacted = []

        for impacted_node in impacted:
            if impacted_node.id in visited:
                continue
            visited.add(impacted_node.id)
            next_depth = current_depth + 1
            by_depth.setdefault(next_depth, []).append(impacted_node)
            if impacted_node.is_entry_point or impacted_node.label == NodeLabel.API_ENDPOINT:
                impacted_endpoints[impacted_node.id] = impacted_node
            if impacted_node.label == NodeLabel.DB_TABLE:
                impacted_tables[impacted_node.id] = impacted_node
            queue.append((impacted_node, next_depth))

    if not by_depth:
        try:
            legacy = storage.traverse_with_depth(start_node.id, depth, direction="callers")
        except Exception:
            legacy = []
        for node_obj, hop in legacy:
            by_depth.setdefault(hop, []).append(node_obj)

    if not by_depth:
        return f"No upstream callers found for '{symbol}'."

    total = sum(len(nodes) for nodes in by_depth.values())
    label_display = start_node.label.value.title()
    lines = [f"Impact analysis for: {start_node.name} ({label_display})"]
    lines.append(f"Depth: {depth} | Total: {total} symbols")

    for d in sorted(by_depth.keys()):
        depth_label = _DEPTH_LABELS.get(d, "Transitive (review)")
        lines.append(f"\nDepth {d} — {depth_label}:")
        for node in by_depth[d]:
            label = node.label.value.title() if node.label else "Unknown"
            conf = conf_lookup.get(node.id) if d == 1 else None
            suffix = f"  (confidence: {conf:.2f})" if conf is not None else ""
            lines.append(f"- {node.name} ({label}) -- {node.file_path}:{node.start_line}{suffix}")

    if impacted_endpoints:
        lines.append(f"\nCritical entry points ({len(impacted_endpoints)}):")
        for endpoint in sorted(impacted_endpoints.values(), key=lambda n: n.name)[:20]:
            lines.append(f"- {endpoint.name} (API Endpoint) -- {endpoint.file_path}:{endpoint.start_line}")
    if impacted_tables:
        lines.append(f"\nImpacted tables ({len(impacted_tables)}):")
        for table in sorted(impacted_tables.values(), key=lambda n: n.name)[:20]:
            lines.append(f"- {table.name} (DB Table) -- {table.file_path}:{table.start_line}")

    if analyzer is not None:
        try:
            report = analyzer.analyze_impact(start_node.id, max_depth=depth)
            if report.impacted_endpoints and not impacted_endpoints:
                lines.append(f"\nCritical entry points ({len(report.impacted_endpoints)}):")
                for endpoint in sorted(report.impacted_endpoints, key=lambda n: n.name)[:20]:
                    lines.append(f"- {endpoint.name} (API Endpoint) -- {endpoint.file_path}:{endpoint.start_line}")
            if report.impacted_tables and not impacted_tables:
                lines.append(f"\nImpacted tables ({len(report.impacted_tables)}):")
                for table in sorted(report.impacted_tables, key=lambda n: n.name)[:20]:
                    lines.append(f"- {table.name} (DB Table) -- {table.file_path}:{table.start_line}")
        except Exception:
            logger.debug("ImpactAnalyzer summary failed", exc_info=True)

    lines.append("")
    lines.append("Tip: Review each affected symbol before making changes.")
    return "\n".join(lines)

def handle_dead_code(storage: StorageBackend) -> str:
    """List all symbols marked as dead code.

    Delegates to :func:`~logthread.mcp.resources.get_dead_code_list` for the
    shared query and formatting.

    Args:
        storage: The storage backend.

    Returns:
        Formatted list of dead code symbols grouped by file.
    """
    return get_dead_code_list(storage)

_DIFF_FILE_PATTERN = re.compile(r"^diff --git a/(.+?) b/(.+?)$", re.MULTILINE)
_DIFF_HUNK_PATTERN = re.compile(r"^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@", re.MULTILINE)


def _parse_diff_files(diff: str) -> dict[str, list[tuple[int, int]]]:
    """Parse a git diff and return {file_path: [(start, end), ...]}."""
    changed_files: dict[str, list[tuple[int, int]]] = {}
    current_file: str | None = None

    for line in diff.split("\n"):
        file_match = _DIFF_FILE_PATTERN.match(line)
        if file_match:
            current_file = file_match.group(2)
            if current_file not in changed_files:
                changed_files[current_file] = []
            continue

        hunk_match = _DIFF_HUNK_PATTERN.match(line)
        if hunk_match and current_file is not None:
            start = int(hunk_match.group(1))
            count = max(1, int(hunk_match.group(2) or "1"))
            changed_files[current_file].append((start, start + count - 1))

    return changed_files


def _parse_diff_stats(diff: str) -> dict[str, dict[str, int]]:
    """Parse diff and return statistics per file: {file_path: {additions, deletions}}."""
    stats: dict[str, dict[str, int]] = {}
    current_file: str | None = None

    for line in diff.split("\n"):
        file_match = _DIFF_FILE_PATTERN.match(line)
        if file_match:
            current_file = file_match.group(2)
            if current_file not in stats:
                stats[current_file] = {"additions": 0, "deletions": 0}
            continue

        if current_file is not None:
            if line.startswith("+") and not line.startswith("+++"):
                stats[current_file]["additions"] += 1
            elif line.startswith("-") and not line.startswith("---"):
                stats[current_file]["deletions"] += 1

    return stats


def handle_detect_changes(storage: StorageBackend, diff: str) -> str:
    """Map git diff output to affected symbols.

    Parses the diff to find changed files and line ranges, then queries
    the storage backend to identify which symbols those lines belong to.

    Args:
        storage: The storage backend.
        diff: Raw git diff output string.

    Returns:
        Formatted list of affected symbols per changed file with statistics.
    """
    if not diff.strip():
        return "Empty diff provided."

    changed_files = _parse_diff_files(diff)
    diff_stats = _parse_diff_stats(diff)

    if not changed_files:
        return "Could not parse any changed files from the diff."

    # Calculate totals
    total_additions = sum(stats["additions"] for stats in diff_stats.values())
    total_deletions = sum(stats["deletions"] for stats in diff_stats.values())

    lines = ["Git Diff Analysis"]
    lines.append("=" * 50)
    lines.append(f"Changed files: {len(changed_files)}")
    lines.append(f"Total additions: +{total_additions} lines")
    lines.append(f"Total deletions: -{total_deletions} lines")
    lines.append("")
    
    total_affected = 0
    affected_by_type: dict[str, int] = {}

    for file_path, ranges in changed_files.items():
        affected_symbols = []
        if not _SAFE_PATH.match(file_path):
            logger.warning("Skipping unsafe file path in diff: %r", file_path)
            lines.append(f"  {file_path}:")
            lines.append("    (skipped: path contains unsafe characters)")
            lines.append("")
            continue

        # Get file stats
        file_stats = diff_stats.get(file_path, {"additions": 0, "deletions": 0})
        
        rows = storage.execute_raw(
            f"MATCH (n) WHERE n.file_path = '{_escape_cypher(file_path)}' "
            f"AND n.start_line > 0 "
            f"RETURN n.id, n.name, n.file_path, n.start_line, n.end_line"
        ) or []
        
        for row in rows:
            node_id = row[0] or ""
            name = row[1] or ""
            start_line = row[3] or 0
            end_line = row[4] or 0
            label_prefix = node_id.split(":", 1)[0] if node_id else ""
            label_title = label_prefix.title()
            
            for start, end in ranges:
                if start_line <= end and end_line >= start:
                    affected_symbols.append((name, label_title, start_line, end_line))
                    affected_by_type[label_title] = affected_by_type.get(label_title, 0) + 1
                    break

        lines.append(f"  {file_path} (+{file_stats['additions']} -{file_stats['deletions']}):")
        if affected_symbols:
            for sym_name, label, s_line, e_line in affected_symbols:
                lines.append(f"    - {sym_name} ({label}) lines {s_line}-{e_line}")
                total_affected += 1
        else:
            lines.append("    (no indexed symbols in changed lines)")
        lines.append("")

    lines.append("=" * 50)
    lines.append(f"Total affected symbols: {total_affected}")
    
    if affected_by_type:
        lines.append("")
        lines.append("Breakdown by type:")
        for symbol_type, count in sorted(affected_by_type.items(), key=lambda x: -x[1]):
            lines.append(f"  - {symbol_type}: {count}")
    
    lines.append("")
    lines.append("💡 Next steps:")
    lines.append("  • Use impact() to see downstream effects")
    lines.append("  • Use test_impact() to find affected tests")
    lines.append("  • Use review_risk() for comprehensive risk assessment")
    
    return "\n".join(lines)


def handle_diff_impact(storage: StorageBackend, diff: str, depth: int = 3) -> str:
    """Parse git diff and return a comprehensive impact report for all modified symbols."""
    if not diff.strip():
        return "Empty diff provided."

    changed_files = _parse_diff_files(diff)
    diff_stats = _parse_diff_stats(diff)
    
    if not changed_files:
        return "Could not parse any changed files from the diff."

    # Calculate totals
    total_additions = sum(stats["additions"] for stats in diff_stats.values())
    total_deletions = sum(stats["deletions"] for stats in diff_stats.values())
    
    changed_node_ids = set()
    changed_symbols_info = []

    for file_path, ranges in changed_files.items():
        if not _SAFE_PATH.match(file_path):
            continue

        rows = storage.execute_raw(
            f"MATCH (n) WHERE n.file_path = '{_escape_cypher(file_path)}' "
            f"AND n.start_line > 0 "
            f"RETURN n.id, n.name, n.start_line, n.end_line"
        ) or []

        for row in rows:
            node_id = row[0] or ""
            node_name = row[1] or ""
            start_line = row[2] or 0
            end_line = row[3] or 0
            for start, end in ranges:
                if start_line <= end and end_line >= start:
                    changed_node_ids.add(node_id)
                    changed_symbols_info.append((node_name, file_path))
                    break

    if not changed_node_ids:
        return "No indexed symbols were modified in this diff."

    from logthread.core.analysis.impact import ImpactAnalyzer
    analyzer = ImpactAnalyzer(storage)

    impacted_endpoints = set()
    impacted_tables = set()
    impacted_classes = set()
    all_downstream = set()

    lines = ["Comprehensive Diff Impact Analysis"]
    lines.append("=" * 60)
    lines.append(f"Analysis depth: {depth} levels")
    lines.append(f"Changed files: {len(changed_files)}")
    lines.append(f"Code changes: +{total_additions} -{total_deletions} lines")
    lines.append(f"Modified symbols: {len(changed_node_ids)}")
    lines.append("")

    # Analyze impact for each changed symbol
    for node_id in changed_node_ids:
        try:
            impact = analyzer.analyze_impact(node_id, max_depth=depth)
            
            # Collect impacted entities
            for ep in impact.impacted_endpoints:
                impacted_endpoints.add(ep.name)
            for tbl in impact.impacted_tables:
                impacted_tables.add(tbl.name)
            for cls in impact.impacted_components:
                if getattr(cls, 'label', '') == "Class":
                    impacted_classes.add(cls.name)
            
            # Track all downstream symbols
            for node in impact.downstream_nodes:
                all_downstream.add(node.name)
                
        except Exception as e:
            logger.debug(f"Impact analysis failed for {node_id}: {e}")
            pass

    # Calculate risk score
    risk_score = 0
    risk_factors = []
    
    # Factor 1: Number of changed symbols (0-30 points)
    symbol_risk = min(30, len(changed_node_ids) * 3)
    risk_score += symbol_risk
    if len(changed_node_ids) > 5:
        risk_factors.append(f"High number of changed symbols ({len(changed_node_ids)})")
    
    # Factor 2: Downstream impact (0-40 points)
    downstream_risk = min(40, len(all_downstream) * 2)
    risk_score += downstream_risk
    if len(all_downstream) > 10:
        risk_factors.append(f"Wide downstream impact ({len(all_downstream)} symbols)")
    
    # Factor 3: Critical systems (0-30 points)
    if impacted_endpoints:
        risk_score += min(20, len(impacted_endpoints) * 5)
        risk_factors.append(f"Affects {len(impacted_endpoints)} API endpoint(s)")
    if impacted_tables:
        risk_score += min(10, len(impacted_tables) * 5)
        risk_factors.append(f"Affects {len(impacted_tables)} database table(s)")
    
    risk_score = min(100, risk_score)
    
    # Risk level
    if risk_score >= 70:
        risk_level = "🔴 HIGH"
        risk_color = "high"
    elif risk_score >= 40:
        risk_level = "🟡 MEDIUM"
        risk_color = "medium"
    else:
        risk_level = "🟢 LOW"
        risk_color = "low"

    lines.append(f"Risk Assessment: {risk_level} (Score: {risk_score}/100)")
    if risk_factors:
        lines.append("")
        lines.append("Risk factors:")
        for factor in risk_factors:
            lines.append(f"  • {factor}")
    lines.append("")
    lines.append("=" * 60)
    lines.append("")

    # Detailed impact breakdown
    if impacted_endpoints:
        lines.append(f"⚠️  Impacted API Endpoints ({len(impacted_endpoints)}):")
        for ep in sorted(impacted_endpoints)[:10]:  # Limit to 10
            lines.append(f"  • {ep}")
        if len(impacted_endpoints) > 10:
            lines.append(f"  ... and {len(impacted_endpoints) - 10} more")
        lines.append("")

    if impacted_tables:
        lines.append(f"🗄️  Impacted Database Tables ({len(impacted_tables)}):")
        for tbl in sorted(impacted_tables):
            lines.append(f"  • {tbl}")
        lines.append("")

    if impacted_classes:
        lines.append(f"📦 Impacted Classes/Components ({len(impacted_classes)}):")
        for cls in sorted(impacted_classes)[:10]:  # Limit to 10
            lines.append(f"  • {cls}")
        if len(impacted_classes) > 10:
            lines.append(f"  ... and {len(impacted_classes) - 10} more")
        lines.append("")

    if all_downstream:
        lines.append(f"🔗 Total Downstream Symbols: {len(all_downstream)}")
        lines.append("")

    if not (impacted_endpoints or impacted_tables or impacted_classes):
        lines.append("✅ No critical downstream impacts detected within specified depth.")
        lines.append("")

    # Recommendations
    lines.append("=" * 60)
    lines.append("📋 Recommendations:")
    lines.append("")
    
    if risk_score >= 70:
        lines.append("  🔴 HIGH RISK - Proceed with caution:")
        lines.append("    • Require thorough code review")
        lines.append("    • Run comprehensive test suite")
        lines.append("    • Consider breaking into smaller changes")
        lines.append("    • Deploy with rollback plan ready")
    elif risk_score >= 40:
        lines.append("  🟡 MEDIUM RISK - Standard precautions:")
        lines.append("    • Code review recommended")
        lines.append("    • Run relevant test suites")
        lines.append("    • Monitor after deployment")
    else:
        lines.append("  🟢 LOW RISK - Standard workflow:")
        lines.append("    • Basic code review")
        lines.append("    • Run unit tests")
        lines.append("    • Safe to merge")
    
    lines.append("")
    lines.append("💡 Next steps:")
    lines.append("  • Run: test_impact() to identify affected tests")
    lines.append("  • Run: coupling() on changed files to check co-change patterns")
    lines.append("  • Run: validate_edit() after making changes")

    return "\n".join(lines)


def handle_db_schema(storage: StorageBackend) -> str:
    """Query the database schema representing tables, columns, and datatypes."""
    rows = storage.execute_raw(
        "MATCH (t:DbTable) "
        "OPTIONAL MATCH (t)-[r:CodeRelation]->(c:DbColumn) "
        "WHERE r.rel_type = 'has_column' "
        "RETURN t.name, c.name, c.properties_json "
        "ORDER BY t.name, c.name"
    ) or []

    if not rows:
        return "No database schema definitions found in the codebase."

    schema = {}
    for row in rows:
        t_name = row[0]
        c_name = row[1]
        c_props_json = row[2]
        
        if not t_name:
            continue
        if t_name not in schema:
            schema[t_name] = []
        
        if c_name:
            # Extract datatype from properties JSON
            c_type = "unknown"
            if c_props_json:
                try:
                    import json as _json
                    c_props = _json.loads(c_props_json) if isinstance(c_props_json, str) else c_props_json
                    c_type = c_props.get("datatype", "unknown")
                except (_json.JSONDecodeError, AttributeError):
                    pass
            
            schema[t_name].append((c_name, c_type))

    lines = ["Database Schema Overview"]
    lines.append("=" * 40)
    lines.append("")

    for table, columns in schema.items():
        lines.append(f"Table: {table}")
        if not columns:
            lines.append("  (No columns extracted)")
        else:
            for c_name, c_type in columns:
                lines.append(f"  - {c_name} : {c_type}")
        lines.append("")

    return "\n".join(lines).strip()

def handle_cypher(storage: StorageBackend, query: str) -> str:
    """Execute a raw Cypher query and return formatted results.

    Only read-only queries are allowed.  Queries containing write keywords
    (DELETE, DROP, CREATE, SET, etc.) are rejected.

    Args:
        storage: The storage backend.
        query: The Cypher query string.

    Returns:
        Formatted query results, or an error message if execution fails.
    """
    # Strip comments so write keywords hidden inside comment blocks are detected.
    cleaned_query = sanitize_cypher(query)
    if WRITE_KEYWORDS.search(cleaned_query):
        return (
            "Query rejected: only read-only queries (MATCH/RETURN) are allowed. "
            "Write operations (DELETE, DROP, CREATE, SET, MERGE) are not permitted."
        )

    try:
        rows = storage.execute_raw(query)
    except Exception as exc:
        return f"Cypher query failed: {exc}"

    if not rows:
        return "Query returned no results."

    lines = [f"Results ({len(rows)} rows):"]
    lines.append("")
    for i, row in enumerate(rows, 1):
        formatted_values = [str(v) for v in row]
        lines.append(f"  {i}. {' | '.join(formatted_values)}")

    return "\n".join(lines)


def handle_coupling(
    storage: StorageBackend, file_path: str, min_strength: float = 0.3
) -> str:
    """Query temporal coupling for a file and flag hidden dependencies."""
    if not file_path or not file_path.strip():
        return "Error: 'file_path' parameter is required and cannot be empty."

    file_path = file_path.strip()
    if not _SAFE_PATH.match(file_path):
        return "Error: file path contains unsafe characters."

    escaped = _escape_cypher(file_path)
    try:
        rows = storage.execute_raw(
            f"MATCH (a:File)-[r:COUPLED_WITH]-(b:File) "
            f"WHERE a.file_path = '{escaped}' "
            f"RETURN b.file_path, r.strength, r.co_changes "
            f"ORDER BY r.strength DESC"
        ) or []
    except Exception as e:
        if "COUPLED_WITH" in str(e) or "does not exist" in str(e):
            return "No temporal coupling data available. Run 'logthread analyze' with git history enabled."
        raise

    rows = [r for r in rows if (r[1] or 0) >= min_strength]

    if not rows:
        return f"No temporal coupling found for '{file_path}' (min strength: {min_strength})."

    import_rows = storage.execute_raw(
        f"MATCH (a:File)-[r:CodeRelation]->(b:File) "
        f"WHERE a.file_path = '{escaped}' AND r.rel_type = 'imports' "
        f"RETURN b.file_path"
    ) or []
    imported_files = {r[0] for r in import_rows}

    lines = [f"Temporal coupling for: {file_path}"]
    lines.append("=" * 48)
    lines.append("")

    for i, row in enumerate(rows, 1):
        coupled_path = row[0] or "?"
        strength = row[1] or 0.0
        co_changes = row[2] or 0
        has_import = coupled_path in imported_files
        import_flag = "imports: yes" if has_import else "imports: no \u26a0\ufe0f"
        lines.append(
            f"  {i}. {coupled_path}  strength: {strength:.2f}  "
            f"co_changes: {co_changes}  ({import_flag})"
        )

    lines.append("")
    hidden = [r[0] for r in rows if r[0] not in imported_files]
    if hidden:
        lines.append(
            f"\u26a0\ufe0f {len(hidden)} file(s) have hidden dependencies (no static import)."
        )
    return "\n".join(lines)


def handle_call_path(
    storage: StorageBackend, from_symbol: str, to_symbol: str, max_depth: int = 10
) -> str:
    """Find the shortest call chain between two symbols via BFS."""
    if not from_symbol or not from_symbol.strip():
        return "Error: 'from_symbol' parameter is required and cannot be empty."
    if not to_symbol or not to_symbol.strip():
        return "Error: 'to_symbol' parameter is required and cannot be empty."

    max_depth = max(1, min(max_depth, MAX_TRAVERSE_DEPTH))

    from_results = _resolve_symbol(storage, from_symbol)
    if not from_results:
        return f"Source symbol '{from_symbol}' not found."

    to_results = _resolve_symbol(storage, to_symbol)
    if not to_results:
        return f"Target symbol '{to_symbol}' not found."

    src_node = storage.get_node(from_results[0].node_id)
    tgt_node = storage.get_node(to_results[0].node_id)
    if not src_node or not tgt_node:
        return "Could not resolve one or both symbols."

    if src_node.id == tgt_node.id:
        return f"Source and target are the same symbol: {src_node.name}"

    parent: dict[str, str] = {}
    queue: deque[tuple[str, int]] = deque([(src_node.id, 0)])
    visited: set[str] = {src_node.id}

    found = False
    while queue:
        current_id, depth = queue.popleft()
        if depth >= max_depth:
            continue

        for callee in storage.get_callees(current_id):
            if callee.id in visited:
                continue
            visited.add(callee.id)
            parent[callee.id] = current_id

            if callee.id == tgt_node.id:
                found = True
                break

            queue.append((callee.id, depth + 1))

        if found:
            break

    if not found:
        return (
            f"No call path found from '{src_node.name}' to '{tgt_node.name}' "
            f"within {max_depth} hops."
        )

    path_ids: list[str] = []
    node_id = tgt_node.id
    while node_id is not None:
        path_ids.append(node_id)
        node_id = parent.get(node_id)
    path_ids.reverse()

    hop_count = len(path_ids) - 1
    path_names = []
    lines = []
    for i, nid in enumerate(path_ids, 1):
        node = storage.get_node(nid)
        if node:
            label = node.label.value.title() if node.label else "Unknown"
            path_names.append(node.name)
            lines.append(f"  {i}. {node.name} ({label}) — {node.file_path}:{node.start_line}")
        else:
            path_names.append(nid)
            lines.append(f"  {i}. {nid}")

    header = f"Call path: {' → '.join(path_names)} ({hop_count} hop{'s' if hop_count != 1 else ''})"
    return header + "\n\n" + "\n".join(lines)


def handle_communities(
    storage: StorageBackend, community: str | None = None
) -> str:
    """List communities or drill into a specific one."""
    if community:
        escaped = _escape_cypher(community)
        try:
            rows = storage.execute_raw(
                f"MATCH (n)-[:MEMBER_OF]->(c:Community) "
                f"WHERE c.name = '{escaped}' "
                f"RETURN n.name, label(n), n.file_path, n.start_line, "
                f"n.is_entry_point, n.is_exported "
                f"ORDER BY n.file_path, n.start_line"
            ) or []
        except Exception as e:
            if "MEMBER_OF" in str(e) or "does not exist" in str(e):
                return "Community detection not available. Run 'logthread analyze' to generate communities."
            raise

        if not rows:
            return f"Community '{community}' not found or has no members."

        lines = [f"Community: {community}"]
        lines.append(f"Members ({len(rows)}):")
        lines.append("")
        for row in rows:
            name = row[0] or "?"
            label = row[1] or "Unknown"
            file_path = row[2] or "?"
            start_line = row[3] or 0
            is_entry = row[4] if len(row) > 4 else False
            is_exported = row[5] if len(row) > 5 else False
            tags = []
            if is_entry:
                tags.append("entry point")
            if is_exported:
                tags.append("exported")
            tag_str = f"  [{', '.join(tags)}]" if tags else ""
            lines.append(f"  - {name} ({label}) — {file_path}:{start_line}{tag_str}")

        return "\n".join(lines)

    rows = storage.execute_raw(
        "MATCH (c:Community) "
        "RETURN c.name, c.cohesion, c.properties_json "
        "ORDER BY c.cohesion DESC"
    ) or []

    if not rows:
        return "No communities detected. Run indexing with community detection enabled."

    lines = [f"Communities ({len(rows)} detected):"]
    lines.append("")
    for i, row in enumerate(rows, 1):
        name = row[0] or "?"
        cohesion = row[1] or 0.0
        props_raw = row[2] or "{}"
        try:
            props = json.loads(props_raw) if isinstance(props_raw, str) else props_raw
        except (json.JSONDecodeError, TypeError):
            props = {}
        symbol_count = props.get("symbol_count", "?")
        lines.append(f"  {i}. {name}  (cohesion: {cohesion:.2f}, {symbol_count} symbols)")

    try:
        cross_procs = storage.execute_raw(
            "MATCH (n)-[:STEP_IN_PROCESS]->(p:Process), (n)-[:MEMBER_OF]->(c:Community) "
            "WITH p.name AS proc, collect(DISTINCT c.name) AS comms "
            "WHERE size(comms) > 1 "
            "RETURN proc, comms"
        ) or []
    except Exception:
        cross_procs = []

    if cross_procs:
        lines.append("")
        lines.append("Cross-community processes:")
        for row in cross_procs:
            proc_name = row[0] or "?"
            comms = row[1] if len(row) > 1 else []
            comm_str = " → ".join(comms) if isinstance(comms, list) else str(comms)
            lines.append(f"  - {proc_name} ({comm_str})")

    return "\n".join(lines)


def handle_explain(storage: StorageBackend, symbol: str) -> str:
    """Produce a narrative explanation of a symbol."""
    if not symbol or not symbol.strip():
        return "Error: 'symbol' parameter is required and cannot be empty."

    results = _resolve_symbol(storage, symbol)
    if not results:
        return f"Symbol '{symbol}' not found."

    node = storage.get_node(results[0].node_id)
    if not node:
        return f"Symbol '{symbol}' not found."

    label_display = node.label.value.title() if node.label else "Unknown"
    lines = [f"Explanation: {node.name} ({label_display})"]
    lines.append("=" * 48)
    lines.append("")

    roles = []
    if node.is_entry_point:
        roles.append("Entry point")
    if node.is_exported:
        roles.append("Exported")
    if node.is_dead:
        roles.append("Dead code (unreachable)")
    if roles:
        lines.append(f"Role: {', '.join(roles)}")

    lines.append(f"Location: {node.file_path}:{node.start_line}-{node.end_line}")

    if node.signature:
        lines.append(f"Signature: {node.signature}")

    escaped_id = _escape_cypher(node.id)
    try:
        comm_rows = storage.execute_raw(
            f"MATCH (n)-[:MEMBER_OF]->(c:Community) "
            f"WHERE n.id = '{escaped_id}' "
            f"RETURN c.name"
        ) or []
    except Exception:
        comm_rows = []
    if comm_rows:
        comm_name = comm_rows[0][0] or "?"
        lines.append(f"Community: {comm_name}")

    lines.append("")

    callers = storage.get_callers_with_confidence(node.id)
    callees = storage.get_callees_with_confidence(node.id)

    if callers:
        caller_names = ", ".join(c.name for c, _ in callers[:5])
        suffix = f" (+{len(callers) - 5} more)" if len(callers) > 5 else ""
        lines.append(f"Called by {len(callers)}: {caller_names}{suffix}")
    else:
        lines.append("Called by: nothing (root or dead)")

    if callees:
        callee_names = ", ".join(c.name for c, _ in callees[:5])
        suffix = f" (+{len(callees) - 5} more)" if len(callees) > 5 else ""
        lines.append(f"Calls {len(callees)}: {callee_names}{suffix}")
    else:
        lines.append("Calls: nothing (leaf)")

    try:
        proc_rows = storage.execute_raw(
            f"MATCH (n)-[:STEP_IN_PROCESS]->(p:Process) "
            f"WHERE n.id = '{escaped_id}' "
            f"RETURN p.name"
        ) or []
    except Exception:
        proc_rows = []
    if proc_rows:
        lines.append("")
        lines.append("Process flows through this symbol:")
        for row in proc_rows:
            proc_name = row[0] or "?"
            lines.append(f"  - {proc_name}")

    return "\n".join(lines)


def handle_review_risk(storage: StorageBackend, diff: str) -> str:
    """Assess PR risk by synthesizing multiple graph signals."""
    if not diff.strip():
        return "Empty diff provided."

    changed_files = _parse_diff_files(diff)
    if not changed_files:
        return "Could not parse any changed files from the diff."

    changed_file_set = set(changed_files.keys())
    all_affected_symbols: list[tuple[str, str, str, int]] = []
    entry_points_hit = 0
    total_dependents = 0

    for file_path, ranges in changed_files.items():
        if not _SAFE_PATH.match(file_path):
            continue
        escaped = _escape_cypher(file_path)
        rows = storage.execute_raw(
            f"MATCH (n) WHERE n.file_path = '{escaped}' "
            f"AND n.start_line > 0 "
            f"RETURN n.id, n.name, n.file_path, n.start_line, n.end_line"
        ) or []

        for row in rows:
            node_id = row[0] or ""
            name = row[1] or ""
            start_line = row[3] or 0
            end_line = row[4] or 0
            label_prefix = node_id.split(":", 1)[0].title() if node_id else ""

            hit = any(start_line <= end and end_line >= start for start, end in ranges)
            if not hit:
                continue

            node = storage.get_node(node_id)
            dep_count = 0
            if node:
                deps = storage.traverse_with_depth(node.id, 2, direction="callers")
                dep_count = len(deps)
                if node.is_entry_point:
                    entry_points_hit += 1

            total_dependents += dep_count
            all_affected_symbols.append((name, label_prefix, file_path, dep_count))

    missing_cochange: list[tuple[str, str, float]] = []
    for file_path in changed_files:
        if not _SAFE_PATH.match(file_path):
            continue
        escaped = _escape_cypher(file_path)
        try:
            coupling_rows = storage.execute_raw(
                f"MATCH (a:File)-[r:COUPLED_WITH]-(b:File) "
                f"WHERE a.file_path = '{escaped}' AND r.strength >= 0.5 "
                f"RETURN b.file_path, r.strength"
            ) or []
        except Exception:
            coupling_rows = []
        for row in coupling_rows:
            coupled_file = row[0] or ""
            strength = row[1] or 0.0
            if coupled_file not in changed_file_set:
                missing_cochange.append((coupled_file, file_path, strength))

    communities_touched: set[str] = set()
    for name, label, file_path, _ in all_affected_symbols:
        escaped = _escape_cypher(f"{label.lower()}:{file_path}:{name}")
        try:
            comm_rows = storage.execute_raw(
                f"MATCH (n)-[:MEMBER_OF]->(c:Community) "
                f"WHERE n.id = '{escaped}' RETURN c.name"
            ) or []
        except Exception:
            comm_rows = []
        for row in comm_rows:
            if row[0]:
                communities_touched.add(row[0])

    score = entry_points_hit + len(missing_cochange) + total_dependents // 10
    if len(communities_touched) > 1:
        score += 2
    score = min(score, 10)

    if score <= 3:
        level = "LOW"
    elif score <= 6:
        level = "MEDIUM"
    else:
        level = "HIGH"

    lines = ["PR Risk Assessment"]
    lines.append("=" * 48)
    lines.append(f"Risk: {level} (score: {score}/10)")
    lines.append("")

    if all_affected_symbols:
        lines.append(f"Changed symbols ({len(all_affected_symbols)}):")
        for name, label, fp, deps in all_affected_symbols:
            tags = []
            if deps > 0:
                tags.append(f"{deps} downstream dependents")
            tag_str = f"  [{', '.join(tags)}]" if tags else ""
            lines.append(f"  - {name} ({label}) — {fp}{tag_str}")
    else:
        lines.append("No indexed symbols in changed lines.")

    if missing_cochange:
        lines.append("")
        lines.append("⚠️ Missing co-change files (usually change together):")
        for missing, coupled_with, strength in missing_cochange:
            lines.append(f"  - {missing} (strength: {strength:.2f} with {coupled_with})")

    if len(communities_touched) > 1:
        lines.append("")
        lines.append(f"Community boundary crossings: {len(communities_touched)}")
        lines.append(f"  Spans: {', '.join(sorted(communities_touched))}")

    return "\n".join(lines)


def handle_file_context(storage: StorageBackend, file_path: str) -> str:
    """Provide comprehensive context for a single file."""
    if not file_path or not file_path.strip():
        return "Error: 'file_path' parameter is required and cannot be empty."

    file_path = file_path.strip()
    if not _SAFE_PATH.match(file_path):
        return "Error: file path contains unsafe characters."

    escaped = _escape_cypher(file_path)

    sym_rows = storage.execute_raw(
        f"MATCH (n) WHERE n.file_path = '{escaped}' AND n.start_line > 0 "
        f"RETURN n.name, label(n), n.start_line, n.is_dead, n.is_entry_point, n.is_exported "
        f"ORDER BY n.start_line"
    ) or []

    imports_out = storage.execute_raw(
        f"MATCH (a:File)-[r:CodeRelation]->(b:File) "
        f"WHERE a.file_path = '{escaped}' AND r.rel_type = 'imports' "
        f"RETURN b.file_path ORDER BY b.file_path"
    ) or []

    imports_in = storage.execute_raw(
        f"MATCH (a:File)-[r:CodeRelation]->(b:File) "
        f"WHERE b.file_path = '{escaped}' AND r.rel_type = 'imports' "
        f"RETURN a.file_path ORDER BY a.file_path"
    ) or []

    try:
        coupling_rows = storage.execute_raw(
            f"MATCH (a:File)-[r:COUPLED_WITH]-(b:File) "
            f"WHERE a.file_path = '{escaped}' "
            f"RETURN b.file_path, r.strength, r.co_changes "
            f"ORDER BY r.strength DESC LIMIT 5"
        ) or []
    except Exception:
        coupling_rows = []

    dead_rows = storage.execute_raw(
        f"MATCH (n) WHERE n.is_dead = true AND n.file_path = '{escaped}' "
        f"RETURN n.name, n.start_line, label(n)"
    ) or []

    try:
        comm_rows = storage.execute_raw(
            f"MATCH (n)-[r:CodeRelation]->(c:Community) "
            f"WHERE n.file_path = '{escaped}' AND r.rel_type = 'member_of' "
            f"RETURN c.name, count(n) ORDER BY count(n) DESC"
        ) or []
    except Exception:
        comm_rows = []

    if not sym_rows and not imports_out and not imports_in:
        return f"No data found for file '{file_path}'. Is it indexed?"

    lines = [f"File: {file_path}"]
    lines.append("=" * 48)

    if sym_rows:
        lines.append("")
        lines.append(f"Symbols ({len(sym_rows)}):")
        for row in sym_rows:
            name = row[0] or "?"
            label = row[1] or "Unknown"
            start_line = row[2] or 0
            is_dead = row[3] if len(row) > 3 else False
            is_entry = row[4] if len(row) > 4 else False
            is_exported = row[5] if len(row) > 5 else False
            tags = []
            if is_entry:
                tags.append("entry point")
            if is_exported:
                tags.append("exported")
            if is_dead:
                tags.append("dead")
            tag_str = f"  [{', '.join(tags)}]" if tags else ""
            lines.append(f"  - {name} ({label}) line {start_line}{tag_str}")

    if imports_out:
        out_paths = [r[0] for r in imports_out if r[0]]
        lines.append("")
        lines.append(f"Imports ({len(out_paths)}): {', '.join(out_paths)}")

    if imports_in:
        in_paths = [r[0] for r in imports_in if r[0]]
        lines.append(f"Imported by ({len(in_paths)}): {', '.join(in_paths)}")

    if coupling_rows:
        lines.append("")
        lines.append(f"Coupled files ({len(coupling_rows)}):")
        for row in coupling_rows:
            coupled_path = row[0] or "?"
            strength = row[1] or 0.0
            co_changes = row[2] or 0
            lines.append(f"  - {coupled_path}  strength: {strength:.2f}  co_changes: {co_changes}")

    if dead_rows:
        lines.append("")
        lines.append(f"Dead code ({len(dead_rows)}):")
        for row in dead_rows:
            name = row[0] or "?"
            start_line = row[1] or 0
            label = row[2] or "Unknown"
            lines.append(f"  - {name} ({label}) line {start_line}")

    if comm_rows:
        lines.append("")
        comm_parts = [f"{r[0]} ({r[1]} symbols)" for r in comm_rows if r[0]]
        lines.append(f"Communities: {', '.join(comm_parts)}")

    return "\n".join(lines)


def handle_cycles(storage: StorageBackend, min_size: int = 2) -> str:
    """Detect circular dependencies using strongly connected components."""
    min_size = max(2, min_size)

    try:
        graph = storage.load_graph()
    except Exception as exc:
        return f"Error loading graph: {exc}"

    ig_graph, index_to_node_id = export_to_igraph(graph)

    if ig_graph.vcount() == 0:
        return "No symbols in the graph to analyze."

    sccs = ig_graph.connected_components(mode="strong")

    cycles = [
        list(component)
        for component in sccs
        if len(component) >= min_size
    ]

    if not cycles:
        return "No circular dependencies detected."

    cycles.sort(key=len, reverse=True)

    lines = [f"Circular Dependencies ({len(cycles)} groups)"]
    lines.append("=" * 48)

    for i, component in enumerate(cycles, 1):
        node_ids = [index_to_node_id[idx] for idx in component if idx in index_to_node_id]
        nodes = [graph.get_node(nid) for nid in node_ids]
        nodes = [n for n in nodes if n is not None]

        severity = "CRITICAL" if len(nodes) >= 5 else ""
        size_label = f" — {severity}" if severity else ""
        lines.append(f"\nCycle {i} ({len(nodes)} symbols){size_label}:")
        for node in nodes:
            label = node.label.value.title() if node.label else "Unknown"
            lines.append(
                f"  - {node.name} ({label}) — "
                f"{node.file_path}:{node.start_line}"
            )

    return "\n".join(lines)


def handle_test_impact(
    storage: StorageBackend,
    diff: str = "",
    symbols: list[str] | None = None,
) -> str:
    """Find tests likely affected by code changes."""
    changed_symbol_ids: list[tuple[str, str]] = []

    if diff and diff.strip():
        changed_files = _parse_diff_files(diff)
        for file_path, ranges in changed_files.items():
            if not _SAFE_PATH.match(file_path):
                continue
            escaped = _escape_cypher(file_path)
            rows = storage.execute_raw(
                f"MATCH (n) WHERE n.file_path = '{escaped}' "
                f"AND n.start_line > 0 "
                f"RETURN n.id, n.name, n.start_line, n.end_line"
            ) or []
            for row in rows:
                node_id = row[0] or ""
                name = row[1] or ""
                start_line = row[2] or 0
                end_line = row[3] or 0
                hit = any(start_line <= end and end_line >= start for start, end in ranges)
                if hit:
                    changed_symbol_ids.append((node_id, name))

    elif symbols:
        for sym_name in symbols:
            results = _resolve_symbol(storage, sym_name)
            if results:
                node = storage.get_node(results[0].node_id)
                if node:
                    changed_symbol_ids.append((node.id, node.name))

    else:
        return "Error: provide either 'diff' or 'symbols' parameter."

    if not changed_symbol_ids:
        return "No changed symbols found."

    test_hits: dict[str, list[tuple[str, str, int]]] = {}

    for sym_id, sym_name in changed_symbol_ids:
        for caller, depth in storage.traverse_with_depth(sym_id, 4, direction="callers"):
            if _is_test_file(caller.file_path):
                test_hits.setdefault(caller.file_path, []).append(
                    (caller.name, sym_name, depth)
                )

    if not test_hits:
        return (
            f"No test files found in the call graph of {len(changed_symbol_ids)} "
            f"changed symbol(s). Tests may not directly call these symbols."
        )

    lines = ["Test Impact Analysis"]
    lines.append("=" * 48)
    lines.append(f"Changed symbols: {len(changed_symbol_ids)}")
    lines.append("")

    direct_files: dict[str, list[tuple[str, str, int]]] = {}
    transitive_files: dict[str, list[tuple[str, str, int]]] = {}

    for test_file, hits in sorted(test_hits.items()):
        for test_name, source_sym, depth in hits:
            if depth <= 2:
                direct_files.setdefault(test_file, []).append((test_name, source_sym, depth))
            else:
                transitive_files.setdefault(test_file, []).append((test_name, source_sym, depth))

    total_tests = sum(len(v) for v in test_hits.values())

    if direct_files:
        lines.append(f"Affected tests ({total_tests}):")
        for test_file, hits in sorted(direct_files.items()):
            lines.append(f"  {test_file}:")
            seen = set()
            for test_name, source_sym, depth in hits:
                key = (test_name, source_sym)
                if key not in seen:
                    seen.add(key)
                    lines.append(f"    - {test_name} (calls: {source_sym})")
        lines.append("")

    if transitive_files:
        lines.append("Tests with indirect coverage (depth 3+):")
        for test_file, hits in sorted(transitive_files.items()):
            lines.append(f"  {test_file}:")
            seen = set()
            for test_name, source_sym, depth in hits:
                key = (test_name, source_sym)
                if key not in seen:
                    seen.add(key)
                    lines.append(f"    - {test_name} (transitive via: {source_sym})")

    return "\n".join(lines)


# ── API endpoint listing ──────────────────────────────────────────────────────


def handle_api_endpoints(storage: StorageBackend, path_filter: str = "") -> str:
    """List all indexed HTTP API endpoints with their handlers and middleware."""
    try:
        rows = storage.execute_raw(
            "MATCH (f:File)-[r:CodeRelation]->(ep:ApiEndpoint) "
            "WHERE r.rel_type = 'defines' "
            "RETURN ep.name, ep.properties_json, f.file_path ORDER BY ep.name"
        )
    except Exception:
        rows = []

    if not rows:
        return "No API endpoints found. Re-index the project to populate routes."

    lines = ["API Endpoints", "=" * 60]
    count = 0
    for row in rows:
        if not isinstance(row, dict):
            continue
        name = row.get("ep.name") or row.get("name", "?")
        props_raw = row.get("ep.properties_json") or row.get("properties_json") or "{}"
        try:
            props = json.loads(props_raw) if isinstance(props_raw, str) else (props_raw or {})
        except Exception:
            props = {}
        method = props.get("http_method", "?")
        path = props.get("path", name)
        handlers = props.get("handlers", [])
        file_path = row.get("f.file_path") or row.get("file_path", "")
        if path_filter and path_filter not in path:
            continue
        count += 1
        lines.append(f"\n{method}  {path}")
        lines.append(f"  File: {file_path}")
        if handlers:
            lines.append(f"  Chain: {' → '.join(h for h in handlers if h)}")

    if count == 0:
        return f"No endpoints matching filter {path_filter!r}."

    lines.insert(1, f"({count} endpoints found)")
    return "\n".join(lines)


# ── SQL query validation ──────────────────────────────────────────────────────


def handle_validate_query(storage: StorageBackend, sql: str) -> str:
    """Validate a SQL query against the indexed database schema.

    Extracts table references from *sql* and verifies them against DB_TABLE
    nodes in the graph, so agents can self-correct before executing bad queries.
    """
    if not sql or not sql.strip():
        return "No SQL provided."

    tables_in_query = extract_tables_from_query(sql)
    if not tables_in_query:
        return "No table references detected in the provided SQL."

    known_tables: dict[str, dict] = {}
    try:
        rows = storage.query(
            "MATCH (t:DbTable) RETURN t.name, t.properties_json",
            limit=500,
        )
        for row in (rows or []):
            if isinstance(row, dict):
                tname = (row.get("t.name") or "").lower()
                props_raw = row.get("t.properties_json") or "{}"
                try:
                    props = json.loads(props_raw) if isinstance(props_raw, str) else (props_raw or {})
                except Exception:
                    props = {}
                if tname:
                    known_tables[tname] = props
    except Exception:
        pass

    lines = ["SQL Validation Report", "=" * 50]
    lines.append(f"Tables in query: {', '.join(tables_in_query)}\n")

    valid: list[str] = []
    invalid: list[str] = []

    for tbl in tables_in_query:
        key = tbl.lower()
        if key in known_tables:
            valid.append(tbl)
            col_names = known_tables[key].get("column_names", [])
            cols_str = ", ".join(col_names[:10]) + ("…" if len(col_names) > 10 else "")
            lines.append(f"  ✓ {tbl}  ({len(col_names)} columns: {cols_str})" if col_names else f"  ✓ {tbl}")
        else:
            invalid.append(tbl)
            suggestions = [k for k in known_tables if tbl.lower() in k or k in tbl.lower()]
            hint = f" — did you mean: {', '.join(suggestions[:3])}?" if suggestions else " — not in schema"
            lines.append(f"  ✗ {tbl}{hint}")

    lines.append("")
    if invalid:
        lines.append(
            f"⚠️  {len(invalid)} table(s) not found in schema: {', '.join(invalid)}\n"
            "   Fix the table names before running this query."
        )
    else:
        lines.append("✓ All table references are valid.")

    if not known_tables:
        lines.append("\nNote: No DB_TABLE nodes indexed. Add .sql schema files and re-index.")

    return "\n".join(lines)


def handle_language_capabilities() -> str:
    """Return the current language and datastore capability report."""
    return format_capabilities_report()


def handle_confidence_report(storage: StorageBackend) -> str:
    """Return a human-readable summary of graph trust tiers and weak spots."""
    packet = build_confidence_report_packet(storage)
    lines = ["Confidence Report", "=" * 50]
    lines.append(packet["summary"])
    lines.append("")
    lines.append("Tier counts:")
    for tier in ("T3", "T2", "T1", "T0"):
        lines.append(f"  - {tier}: {packet['tierCounts'].get(tier, 0)}")
    low_confidence = packet.get("lowConfidenceNodes") or []
    if low_confidence:
        lines.append("")
        lines.append("Low-confidence nodes:")
        for node in low_confidence[:10]:
            confidence = node.get("confidence", {})
            lines.append(
                f"  - {node.get('name')} ({node.get('label')}) — {node.get('filePath')} "
                f"[{confidence.get('tier', 'T0')}, {confidence.get('score', 0):.2f}]"
            )
    return "\n".join(lines)


# ── Post-edit dead-end detection ─────────────────────────────────────────────


def handle_validate_edit(
    storage: StorageBackend,
    file_path: str = "",
    symbols: list[str] | None = None,
) -> str:
    """After an edit, trace the symbol tree and report broken references.

    Detects dead-end calls (missing targets), dead code, and SQL references to
    non-existent tables so the AI agent can self-correct immediately.
    """
    lines = ["Post-Edit Validation", "=" * 50]
    if file_path:
        lines.append(f"File: {file_path}\n")

    issues: list[str] = []

    # Dead code introduced or already present in the file
    try:
        dead_q = "MATCH (n) WHERE n.is_dead = true"
        if file_path:
            safe_fp = _escape_cypher(file_path)
            dead_q += f" AND n.file_path = '{safe_fp}'"
        dead_q += " RETURN n.name, n.label, n.start_line LIMIT 20"
        dead_nodes = storage.query(dead_q, limit=20)
        for row in (dead_nodes or []):
            if isinstance(row, dict):
                name = row.get("n.name", "?")
                label = row.get("n.label", "")
                line = row.get("n.start_line", "")
                issues.append(f"  ⚠ Dead code: {label} '{name}' line {line} — unreachable")
    except Exception:
        pass

    # Low-confidence outbound calls (possible renamed/deleted target)
    try:
        call_q = "MATCH (src)-[r:CALLS]->(tgt) WHERE r.confidence < 0.3"
        if file_path:
            safe_fp = _escape_cypher(file_path)
            call_q += f" AND src.file_path = '{safe_fp}'"
        call_q += " RETURN src.name, tgt.name, r.confidence LIMIT 30"
        low_conf = storage.query(call_q, limit=30)
        for row in (low_conf or []):
            if isinstance(row, dict):
                src = row.get("src.name", "?")
                tgt = row.get("tgt.name", "?")
                conf = row.get("r.confidence", 0)
                issues.append(
                    f"  ⚠ '{src}' → '{tgt}' (confidence {conf:.0%}) — target may be renamed/missing"
                )
    except Exception:
        pass

    # Specific symbol checks
    if symbols:
        for sym in symbols:
            ctx = handle_context(storage, sym)
            if "not found" in ctx.lower():
                issues.append(f"  ✗ Symbol '{sym}' not found — deleted or renamed")

    lines.append("")
    if issues:
        lines.append(f"{len(issues)} issue(s) detected:\n")
        lines.extend(issues)
        lines.append(
            "\nAction: Fix the flagged references, then re-run validation to confirm."
        )
    else:
        lines.append("✓ No broken references detected after edit.")

    return "\n".join(lines)


def handle_dependencies(
    storage: StorageBackend,
    file_path: str = "",
    library: str = "",
) -> str:
    """List external library dependencies with version info and usage locations.

    Can filter by file (show deps used by that file) or by library name
    (show which files use that library). With no filters, shows all deps.
    """
    lines = ["External Dependencies", "=" * 50]

    if library:
        safe_lib = _escape_cypher(library)
        try:
            dep_q = (
                f"MATCH (dep:ExternalDep) WHERE dep.name =~ '(?i).*{safe_lib}.*' "
                f"RETURN dep.id, dep.name, dep.language, dep.properties_json "
                f"LIMIT 10"
            )
            dep_rows = storage.query(dep_q, limit=10)
            if not dep_rows:
                return f"No external dependency matching '{library}' found in the index."

            for dep_row in (dep_rows or []):
                if not isinstance(dep_row, dict):
                    continue
                dep_name = dep_row.get("dep.name", "?")
                dep_lang = dep_row.get("dep.language", "?")
                dep_id = dep_row.get("dep.id", "")
                props_json = dep_row.get("dep.properties_json", "{}")
                try:
                    props = json.loads(props_json) if props_json else {}
                except Exception:
                    props = {}
                version = props.get("version", "")
                lines.append(f"\n{dep_name} ({dep_lang})" + (f" {version}" if version else ""))

                safe_id = _escape_cypher(dep_id)
                manifest_q = (
                    f"MATCH (f:File)-[r:CodeRelation]->(dep:ExternalDep) "
                    f"WHERE dep.id = '{safe_id}' AND r.rel_type = 'depends_on' "
                    f"RETURN f.file_path LIMIT 5"
                )
                mf_rows = storage.query(manifest_q, limit=5)
                if mf_rows:
                    lines.append("  Declared in:")
                    for mf in mf_rows:
                        if isinstance(mf, dict):
                            lines.append(f"    - {mf.get('f.file_path', '?')}")

                usage_q = (
                    f"MATCH (f:File)-[r:CodeRelation]->(dep:ExternalDep) "
                    f"WHERE dep.id = '{safe_id}' AND r.rel_type = 'uses_library' "
                    f"RETURN f.file_path, r.symbols LIMIT 30"
                )
                usage_rows = storage.query(usage_q, limit=30)
                if usage_rows:
                    lines.append("  Used in code:")
                    for ur in usage_rows:
                        if isinstance(ur, dict):
                            fp = ur.get("f.file_path", "?")
                            syms = ur.get("r.symbols", "")
                            sym_info = f" (imports: {syms})" if syms else ""
                            lines.append(f"    - {fp}{sym_info}")
        except Exception as e:
            lines.append(f"Error querying dependencies: {e}")

    elif file_path:
        safe_fp = _escape_cypher(file_path)
        lines.append(f"File: {file_path}\n")
        try:
            q = (
                f"MATCH (f:File)-[r:CodeRelation]->(dep:ExternalDep) "
                f"WHERE f.file_path = '{safe_fp}' AND r.rel_type = 'uses_library' "
                f"RETURN dep.name, dep.language, dep.properties_json, r.symbols "
                f"ORDER BY dep.name LIMIT 50"
            )
            rows = storage.query(q, limit=50)
            if not rows:
                lines.append("No external library usage detected for this file.")
            else:
                lines.append(f"{len(rows)} libraries used:\n")
                for row in rows:
                    if not isinstance(row, dict):
                        continue
                    name = row.get("dep.name", "?")
                    lang = row.get("dep.language", "")
                    syms = row.get("r.symbols", "")
                    props_json = row.get("dep.properties_json", "{}")
                    try:
                        props = json.loads(props_json) if props_json else {}
                    except Exception:
                        props = {}
                    ver = props.get("version", "")
                    ver_str = f" {ver}" if ver else ""
                    sym_str = f" — imports: {syms}" if syms else ""
                    lines.append(f"  {name}{ver_str} ({lang}){sym_str}")
        except Exception as e:
            lines.append(f"Error: {e}")

    else:
        try:
            q = (
                "MATCH (dep:ExternalDep) "
                "RETURN dep.name, dep.language, dep.properties_json "
                "ORDER BY dep.language, dep.name LIMIT 100"
            )
            rows = storage.query(q, limit=100)
            if not rows:
                lines.append("No external dependencies indexed.")
            else:
                lines.append(f"{len(rows)} dependencies found:\n")
                current_lang = ""
                for row in rows:
                    if not isinstance(row, dict):
                        continue
                    name = row.get("dep.name", "?")
                    lang = row.get("dep.language", "?")
                    props_json = row.get("dep.properties_json", "{}")
                    try:
                        props = json.loads(props_json) if props_json else {}
                    except Exception:
                        props = {}
                    ver = props.get("version", "")
                    if lang != current_lang:
                        current_lang = lang
                        lines.append(f"\n  [{lang.upper()}]")
                    ver_str = f" {ver}" if ver else ""
                    lines.append(f"    {name}{ver_str}")

                usage_q = (
                    "MATCH (f:File)-[r:CodeRelation]->(dep:ExternalDep) "
                    "WHERE r.rel_type = 'uses_library' "
                    "RETURN dep.name, count(f) AS usage_count "
                    "ORDER BY usage_count DESC LIMIT 20"
                )
                usage_rows = storage.query(usage_q, limit=20)
                if usage_rows:
                    lines.append("\n  Most used libraries:")
                    for ur in usage_rows:
                        if isinstance(ur, dict):
                            lines.append(
                                f"    {ur.get('dep.name', '?')} "
                                f"({ur.get('usage_count', 0)} files)"
                            )
        except Exception as e:
            lines.append(f"Error: {e}")

    return "\n".join(lines)
def get_current_git_diff(repo_path: Path | None = None) -> str:
    """Return the combined diff of staged and unstaged changes against HEAD."""
    target_repo = (repo_path or Path.cwd()).resolve()
    try:
        result = subprocess.run(
            ["git", "-C", str(target_repo), "diff", "HEAD"],
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout
    except Exception as e:
        logger.debug(f"Failed to get git diff: {e}")
        return ""


def handle_unstaged_impact(storage: StorageBackend, depth: int = 3, repo_path: Path | None = None) -> str:
    """Assess impact of current working tree changes (uncommitted)."""
    diff = get_current_git_diff(repo_path)
    if not diff.strip():
        return "No uncommitted changes detected (clean working tree)."

    report = handle_diff_impact(storage, diff, depth=depth)

    # Prepend a header
    lines = ["Uncommitted Changes Impact Preview"]
    lines.append("-" * 40)
    lines.append(report)
    return "\n".join(lines)
