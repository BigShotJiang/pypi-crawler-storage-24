"""MCP server for Log Thread — exposes code intelligence tools over stdio and HTTP.

Registers fifteen tools and three resources that give AI agents and MCP clients
access to the Log Thread knowledge graph.  Uses a short-lived connection lease
pattern so the database lock is only held during query execution, never idle.

Usage::

    # MCP server only
    logthread mcp

    # MCP server with live file watching (recommended)
    logthread serve --watch
"""

from __future__ import annotations

import asyncio
import atexit
import json
import logging
import os
import signal
import threading
import time
from collections.abc import Callable
from pathlib import Path

from mcp.server import Server
from mcp.server.fastmcp.server import StreamableHTTPASGIApp
from mcp.server.stdio import stdio_server
from mcp.server.streamable_http_manager import StreamableHTTPSessionManager
from mcp.types import Resource, TextContent, Tool

from logthread.cloud.client import require_subscription
from logthread.core.storage.ladybug_backend import LadybugBackend
from logthread.core.storage.paths import get_app_data_dir, get_db_path, migrate_legacy_storage
from logthread.mcp.resources import get_dead_code_list, get_overview, get_schema
from logthread.mcp.tools import (
    MAX_TRAVERSE_DEPTH,
    handle_agent_safe_edit_contract,
    handle_api_endpoints,
    handle_call_path,
    handle_confidence_report,
    handle_communities,
    handle_context,
    handle_coupling,
    handle_cycles,
    handle_cypher,
    handle_db_schema,
    handle_dead_code,
    handle_dependencies,
    handle_detect_changes,
    handle_diff_impact,
    handle_explain,
    handle_file_context,
    handle_impact,
    handle_implementation_brief,
    handle_language_capabilities,
    handle_list_repos,
    handle_query,
    handle_review_risk,
    handle_test_impact,
    handle_unstaged_impact,
    handle_validate_edit,
    handle_validate_query,
    handle_workspace_map,
)

logger = logging.getLogger(__name__)

server = Server("logthread")

# ── Injected storage (from ``logthread serve --watch``) ──
_storage: LadybugBackend | None = None
_lock: asyncio.Lock | None = None

_db_path: Path | None = None


def _subscription_gate_enabled() -> bool:
    value = os.getenv("LOGTHREAD_REQUIRE_SUBSCRIPTION", "").strip().lower()
    return value in {"1", "true", "yes", "on"}


def _validate_mcp_access() -> tuple[bool, str]:
    if not _subscription_gate_enabled():
        return True, ""
    return require_subscription()


# ── Connection Lease Manager ─────────────────────────────────────────────────
# Opens a read-only DB connection on demand, keeps it alive for a short idle
# window (LEASE_TTL_SECONDS), then auto-closes to release the file lock.
# This allows ``logthread analyze`` to acquire the write lock between queries.

LEASE_TTL_SECONDS = 3.0

class _ConnectionLease:
    __slots__ = ("_db_path", "_backend", "_lock", "_last_use", "_closer", "_closed")

    def __init__(self) -> None:
        self._db_path: Path | None = None
        self._backend: LadybugBackend | None = None
        self._lock = threading.Lock()
        self._last_use: float = 0.0
        self._closer: threading.Timer | None = None
        self._closed = False

    def set_db_path(self, p: Path) -> None:
        self._db_path = p

    def acquire(self) -> LadybugBackend:
        with self._lock:
            if self._closer is not None:
                self._closer.cancel()
                self._closer = None

            if self._backend is None or self._backend._conn is None:
                if self._db_path is None or not self._db_path.exists():
                    raise FileNotFoundError(
                        "Workspace not indexed yet. Run 'logthread analyze' first."
                    )
                st = LadybugBackend()
                st.initialize(self._db_path, read_only=True, max_retries=3, retry_delay=0.3)
                self._backend = st
                logger.debug("ConnectionLease: opened read-only connection")

            self._last_use = time.monotonic()
            return self._backend

    def release(self) -> None:
        with self._lock:
            self._last_use = time.monotonic()
            if self._closer is not None:
                self._closer.cancel()
            self._closer = threading.Timer(LEASE_TTL_SECONDS, self._expire)
            self._closer.daemon = True
            self._closer.start()

    def _expire(self) -> None:
        with self._lock:
            elapsed = time.monotonic() - self._last_use
            if elapsed < LEASE_TTL_SECONDS:
                return
            self._do_close()

    def _do_close(self) -> None:
        if self._backend is not None:
            try:
                self._backend.close()
            except Exception:
                pass
            self._backend = None
            logger.debug("ConnectionLease: closed (lock released)")

    def force_close(self) -> None:
        with self._lock:
            if self._closer is not None:
                self._closer.cancel()
                self._closer = None
            self._do_close()
            self._closed = True


_lease = _ConnectionLease()
_async_lock: asyncio.Lock | None = None


def _get_async_lock() -> asyncio.Lock:
    global _async_lock  # noqa: PLW0603
    if _async_lock is None:
        _async_lock = asyncio.Lock()
    return _async_lock


def _resolve_db_path() -> Path:
    global _db_path  # noqa: PLW0603
    if _db_path is None:
        repo_path = Path.cwd()
        migrate_legacy_storage(repo_path)
        _db_path = get_db_path(repo_path)
        _lease.set_db_path(_db_path)
    return _db_path


def set_storage(storage: LadybugBackend) -> None:
    """Inject a pre-initialised storage backend (e.g. from ``logthread serve --watch``)."""
    global _storage  # noqa: PLW0603
    _storage = storage


def set_lock(lock: asyncio.Lock) -> None:
    """Inject a shared lock for coordinating storage access with the file watcher."""
    global _lock  # noqa: PLW0603
    _lock = lock


async def _with_storage(fn: Callable[[LadybugBackend], str]) -> str:
    """Run *fn* against the appropriate storage backend.

    Priority:
    1. Injected persistent backend (``logthread serve --watch``) — uses its own lock.
    2. Connection lease — opened per-request, auto-closed after idle timeout.
       Protected by an async lock to prevent concurrent database lock contention.
    """
    if _storage is not None:
        if _lock is not None:
            async with _lock:
                return await asyncio.to_thread(fn, _storage)
        return await asyncio.to_thread(fn, _storage)

    _resolve_db_path()

    async with _get_async_lock():
        def _run() -> str:
            st = _lease.acquire()
            try:
                return fn(st)
            finally:
                _lease.release()

        return await asyncio.to_thread(_run)


# ── Single-Instance PID Lock ─────────────────────────────────────────────────
# Prevents multiple MCP server processes from running for the same workspace.
# Lock file: <app_data>/mcp_<workspace_hash>.lock

def _get_lock_path() -> Path:
    db = _resolve_db_path()
    lock_name = f"mcp_{db.parent.name}.lock"
    return get_app_data_dir() / lock_name


def _is_pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def acquire_instance_lock() -> bool:
    """Try to become the single MCP instance for this workspace.

    Returns True if lock acquired (we are the primary).
    Returns False if another live instance already holds the lock.
    """
    lock_path = _get_lock_path()
    lock_path.parent.mkdir(parents=True, exist_ok=True)

    if lock_path.exists():
        try:
            data = json.loads(lock_path.read_text())
            other_pid = data.get("pid", 0)
            if other_pid and _is_pid_alive(other_pid) and other_pid != os.getpid():
                logger.info(
                    "MCP instance already running (pid=%d), reusing", other_pid
                )
                return False
        except (json.JSONDecodeError, OSError, KeyError):
            pass

    lock_path.write_text(json.dumps({
        "pid": os.getpid(),
        "workspace": str(Path.cwd()),
        "started_at": time.time(),
    }))
    atexit.register(_release_instance_lock)
    return True


def _release_instance_lock() -> None:
    try:
        lock_path = _get_lock_path()
        if lock_path.exists():
            data = json.loads(lock_path.read_text())
            if data.get("pid") == os.getpid():
                lock_path.unlink(missing_ok=True)
                logger.debug("Released MCP instance lock")
    except Exception:
        pass


def cleanup_stale_locks() -> None:
    """Remove lock files for dead processes."""
    app_dir = get_app_data_dir()
    for lock_file in app_dir.glob("mcp_*.lock"):
        try:
            data = json.loads(lock_file.read_text())
            pid = data.get("pid", 0)
            if pid and not _is_pid_alive(pid):
                lock_file.unlink(missing_ok=True)
        except (json.JSONDecodeError, OSError):
            lock_file.unlink(missing_ok=True)


TOOLS: list[Tool] = [
    Tool(
        name="logthread_list_repos",
        description="List all indexed repositories with their stats.",
        inputSchema={
            "type": "object",
            "properties": {},
        },
    ),
    Tool(
        name="logthread_query",
        description=(
            "Search the knowledge graph using hybrid (keyword + vector) search. "
            "Returns ranked symbols matching the query."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query text.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of results (default 20).",
                    "default": 20,
                },
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="logthread_language_capabilities",
        description=(
            "Describe language, framework, datastore, and trust-tier support. "
            "Use this before relying on LogThread for high-stakes edits in a given stack."
        ),
        inputSchema={
            "type": "object",
            "properties": {},
        },
    ),
    Tool(
        name="logthread_context",
        description=(
            "Get a 360-degree view of a symbol: callers, callees, type references, "
            "and community membership."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "symbol": {
                    "type": "string",
                    "description": "Name of the symbol to look up.",
                },
            },
            "required": ["symbol"],
        },
    ),
    Tool(
        name="logthread_implementation_brief",
        description=(
            "Turn an implementation request into exact edit targets, reuse candidates, "
            "existing dependency context, and ambiguity guardrails for AI-assisted changes."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Natural-language implementation objective.",
                },
                "symbol": {
                    "type": "string",
                    "description": "Optional exact symbol to anchor the plan.",
                    "default": "",
                },
                "max_candidates": {
                    "type": "integer",
                    "description": "Maximum number of exact/reuse candidates to surface.",
                    "default": 8,
                    "minimum": 1,
                    "maximum": 16,
                },
            },
        },
    ),
    Tool(
        name="logthread_edit_contract",
        description=(
            "Build an agent-safe edit contract with exact symbol binding, scope-level evidence, "
            "lockfile-backed dependency truth, and cross-project impact warnings."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Natural-language implementation objective.",
                },
                "symbol": {
                    "type": "string",
                    "description": "Optional exact symbol to anchor the contract.",
                    "default": "",
                },
                "max_candidates": {
                    "type": "integer",
                    "description": "Maximum number of exact scoped targets to surface.",
                    "default": 8,
                    "minimum": 1,
                    "maximum": 16,
                },
            },
        },
    ),
    Tool(
        name="logthread_impact",
        description=(
            "Blast radius analysis: find all symbols affected by changing a given symbol."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "symbol": {
                    "type": "string",
                    "description": "Name of the symbol to analyse.",
                },
                "depth": {
                    "type": "integer",
                    "description": f"Maximum traversal depth (default 3, max {MAX_TRAVERSE_DEPTH}).",
                    "default": 3,
                    "minimum": 1,
                    "maximum": MAX_TRAVERSE_DEPTH,
                },
            },
            "required": ["symbol"],
        },
    ),
    Tool(
        name="logthread_confidence_report",
        description=(
            "Summarize graph trust coverage by tier and highlight low-confidence nodes "
            "that should not be trusted for high-risk AI edits."
        ),
        inputSchema={
            "type": "object",
            "properties": {},
        },
    ),
    Tool(
        name="logthread_workspace_map",
        description=(
            "Scan the current repository for internal projects, workspace packages, solution members, "
            "and project-to-project references so AI can understand multi-project codebases."
        ),
        inputSchema={
            "type": "object",
            "properties": {},
        },
    ),
    Tool(
        name="logthread_dead_code",
        description="List all symbols detected as dead (unreachable) code.",
        inputSchema={
            "type": "object",
            "properties": {},
        },
    ),
    Tool(
        name="logthread_detect_changes",
        description=(
            "Parse a git diff and map changed files/lines to affected symbols "
            "in the knowledge graph."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "diff": {
                    "type": "string",
                    "description": "Raw git diff output.",
                },
            },
            "required": ["diff"],
        },
    ),
    Tool(
        name="logthread_cypher",
        description="Execute a raw Cypher query against the knowledge graph.",
        inputSchema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Cypher query string.",
                },
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="logthread_coupling",
        description=(
            "Show files temporally coupled with a given file. "
            "Reveals hidden dependencies from git co-change patterns."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Path to the file to analyze coupling for.",
                },
                "min_strength": {
                    "type": "number",
                    "description": "Minimum coupling strength threshold (default 0.3).",
                    "default": 0.3,
                },
            },
            "required": ["file_path"],
        },
    ),
    Tool(
        name="logthread_communities",
        description=(
            "List detected code communities (Leiden clusters) or drill into "
            "a specific community to see its members."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "community": {
                    "type": "string",
                    "description": "Optional community name to drill into. Omit to list all.",
                },
            },
        },
    ),
    Tool(
        name="logthread_explain",
        description=(
            "Get a narrative explanation of a symbol: its role, community, "
            "process flows, and relationships summarized for onboarding."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "symbol": {
                    "type": "string",
                    "description": "Name of the symbol to explain.",
                },
            },
            "required": ["symbol"],
        },
    ),
    Tool(
        name="logthread_review_risk",
        description=(
            "PR risk assessment: analyzes a git diff to find affected symbols, "
            "missing co-change files, community boundary crossings, and "
            "downstream blast radius. Returns a risk score."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "diff": {
                    "type": "string",
                    "description": "Raw git diff output.",
                },
            },
            "required": ["diff"],
        },
    ),
    Tool(
        name="logthread_call_path",
        description=(
            "Find the shortest call chain between two symbols. "
            "Uses BFS over CALLS edges."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "from_symbol": {
                    "type": "string",
                    "description": "Name of the source symbol.",
                },
                "to_symbol": {
                    "type": "string",
                    "description": "Name of the target symbol.",
                },
                "max_depth": {
                    "type": "integer",
                    "description": f"Maximum hops (default 10, max {MAX_TRAVERSE_DEPTH}).",
                    "default": 10,
                    "minimum": 1,
                    "maximum": MAX_TRAVERSE_DEPTH,
                },
            },
            "required": ["from_symbol", "to_symbol"],
        },
    ),
    Tool(
        name="logthread_file_context",
        description=(
            "Get comprehensive context for a file: symbols, imports, "
            "coupling, dead code, and community membership in one call."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Path to the file to analyze.",
                },
            },
            "required": ["file_path"],
        },
    ),
    Tool(
        name="logthread_test_impact",
        description=(
            "Find tests likely affected by code changes. Accepts a git diff "
            "or symbol names, traces callers to find test files."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "diff": {
                    "type": "string",
                    "description": "Raw git diff output.",
                },
                "symbols": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of symbol names to check.",
                },
            },
        },
    ),
    Tool(
        name="logthread_cycles",
        description=(
            "Detect circular dependencies using strongly connected "
            "component analysis. Returns cycle groups sorted by size."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "min_size": {
                    "type": "integer",
                    "description": "Minimum cycle size to report (default 2).",
                    "default": 2,
                    "minimum": 2,
                },
            },
        },
    ),
    Tool(
        name="logthread_api_endpoints",
        description=(
            "List all indexed HTTP API endpoints (Express, Flask, FastAPI routes) "
            "with their handler functions, middleware chain, and file locations."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "path_filter": {
                    "type": "string",
                    "description": "Optional substring to filter endpoints by path (e.g. '/api/auth').",
                    "default": "",
                },
            },
        },
    ),
    Tool(
        name="logthread_validate_query",
        description=(
            "Validate a SQL query against the indexed database schema. "
            "Checks that all table names exist in the schema and suggests corrections "
            "for any unknown tables. Use this before writing or executing any SQL."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "sql": {
                    "type": "string",
                    "description": "The SQL statement to validate.",
                },
            },
            "required": ["sql"],
        },
    ),
    Tool(
        name="logthread_validate_edit",
        description=(
            "After editing a file, trace the symbol tree to detect broken references: "
            "dead code, low-confidence calls (renamed/deleted targets), and SQL queries "
            "referencing non-existent tables. Use this after every code edit to self-correct."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Path to the recently edited file (relative to repo root).",
                    "default": "",
                },
                "symbols": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional list of specific symbol names to validate.",
                },
            },
        },
    ),
    Tool(
        name="logthread_dependencies",
        description=(
            "List external library dependencies (npm packages, PyPI packages, Go modules, etc.) "
            "with version info. Filter by file path to see what a file imports, or by library "
            "name to see which files use it. Shows the full dependency tree from package manifests "
            "and code-level import usage."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Show libraries used by this file (relative to repo root).",
                    "default": "",
                },
                "library": {
                    "type": "string",
                    "description": "Show usage of a specific library (e.g. 'react', 'django', 'express').",
                    "default": "",
                },
            },
        },
    ),
    Tool(
        name="logthread_diff_impact",
        description=(
            "Parse a git diff and return an impact report for all modified symbols. "
            "Helps understand the downstream blast radius of a set of changes."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "diff": {
                    "type": "string",
                    "description": "Raw git diff output.",
                },
                "depth": {
                    "type": "integer",
                    "description": f"Maximum traversal depth (default 3, max {MAX_TRAVERSE_DEPTH}).",
                    "default": 3,
                    "minimum": 1,
                    "maximum": MAX_TRAVERSE_DEPTH,
                },
            },
            "required": ["diff"],
        },
    ),
    Tool(
        name="logthread_unstaged_impact",
        description=(
            "Assess the impact of current uncommitted/unstaged changes in the working tree. "
            "Returns a preview of affected APIs, tables, and components."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "depth": {
                    "type": "integer",
                    "description": f"Maximum traversal depth (default 3, max {MAX_TRAVERSE_DEPTH}).",
                    "default": 3,
                    "minimum": 1,
                    "maximum": MAX_TRAVERSE_DEPTH,
                },
            },
        },
    ),
    Tool(
        name="logthread_db_schema",
        description="List all indexed database tables and their columns.",
        inputSchema={
            "type": "object",
            "properties": {},
        },
    ),
]

@server.list_tools()
async def list_tools() -> list[Tool]:
    """Return the list of available Log Thread tools."""
    return TOOLS

def _dispatch_tool(name: str, arguments: dict, storage: LadybugBackend) -> str:
    if name == "logthread_list_repos":
        return handle_list_repos()
    elif name == "logthread_query":
        return handle_query(storage, arguments.get("query", ""), limit=arguments.get("limit", 20))
    elif name == "logthread_language_capabilities":
        return handle_language_capabilities()
    elif name == "logthread_context":
        return handle_context(storage, arguments.get("symbol", ""))
    elif name == "logthread_implementation_brief":
        return handle_implementation_brief(
            storage,
            arguments.get("query", ""),
            symbol=arguments.get("symbol", ""),
            max_candidates=arguments.get("max_candidates", 8),
        )
    elif name == "logthread_edit_contract":
        return handle_agent_safe_edit_contract(
            storage,
            Path.cwd(),
            arguments.get("query", ""),
            symbol=arguments.get("symbol", ""),
            max_candidates=arguments.get("max_candidates", 8),
        )
    elif name == "logthread_impact":
        return handle_impact(storage, arguments.get("symbol", ""), depth=arguments.get("depth", 3))
    elif name == "logthread_confidence_report":
        return handle_confidence_report(storage)
    elif name == "logthread_workspace_map":
        return handle_workspace_map(Path.cwd())
    elif name == "logthread_dead_code":
        return handle_dead_code(storage)
    elif name == "logthread_detect_changes":
        return handle_detect_changes(storage, arguments.get("diff", ""))
    elif name == "logthread_cypher":
        return handle_cypher(storage, arguments.get("query", ""))
    elif name == "logthread_coupling":
        return handle_coupling(
            storage, arguments.get("file_path", ""),
            min_strength=arguments.get("min_strength", 0.3),
        )
    elif name == "logthread_communities":
        return handle_communities(storage, community=arguments.get("community"))
    elif name == "logthread_explain":
        return handle_explain(storage, arguments.get("symbol", ""))
    elif name == "logthread_review_risk":
        return handle_review_risk(storage, arguments.get("diff", ""))
    elif name == "logthread_call_path":
        return handle_call_path(
            storage,
            arguments.get("from_symbol", ""),
            arguments.get("to_symbol", ""),
            max_depth=arguments.get("max_depth", 10),
        )
    elif name == "logthread_file_context":
        return handle_file_context(storage, arguments.get("file_path", ""))
    elif name == "logthread_test_impact":
        return handle_test_impact(
            storage,
            diff=arguments.get("diff", ""),
            symbols=arguments.get("symbols"),
        )
    elif name == "logthread_cycles":
        return handle_cycles(
            storage, min_size=arguments.get("min_size", 2),
        )
    elif name == "logthread_api_endpoints":
        return handle_api_endpoints(storage, path_filter=arguments.get("path_filter", ""))
    elif name == "logthread_validate_query":
        return handle_validate_query(storage, arguments.get("sql", ""))
    elif name == "logthread_validate_edit":
        return handle_validate_edit(
            storage,
            file_path=arguments.get("file_path", ""),
            symbols=arguments.get("symbols"),
        )
    elif name == "logthread_dependencies":
        return handle_dependencies(
            storage,
            file_path=arguments.get("file_path", ""),
            library=arguments.get("library", ""),
        )
    elif name == "logthread_diff_impact":
        return handle_diff_impact(
            storage, arguments.get("diff", ""), depth=arguments.get("depth", 3)
        )
    elif name == "logthread_unstaged_impact":
        return handle_unstaged_impact(storage, depth=arguments.get("depth", 3))
    elif name == "logthread_db_schema":
        return handle_db_schema(storage)
    else:
        return f"Unknown tool: {name}"


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Dispatch a tool call to the appropriate handler."""
    is_valid, error_msg = _validate_mcp_access()
    if not is_valid:
        return [TextContent(
            type="text",
            text=f"⚠️ MCP access blocked\n\n{error_msg}"
        )]

    try:
        result = await _with_storage(lambda st: _dispatch_tool(name, arguments, st))
    except Exception as exc:
        logger.exception("Tool %s raised an unhandled exception", name)
        result = f"Internal error: {exc}"

    return [TextContent(type="text", text=result)]

@server.list_resources()
async def list_resources() -> list[Resource]:
    """Return the list of available Log Thread resources."""
    return [
        Resource(
            uri="logthread://overview",
            name="Codebase Overview",
            description="High-level statistics about the indexed codebase.",
            mimeType="text/plain",
        ),
        Resource(
            uri="logthread://dead-code",
            name="Dead Code Report",
            description="List of all symbols flagged as unreachable.",
            mimeType="text/plain",
        ),
        Resource(
            uri="logthread://schema",
            name="Graph Schema",
            description="Description of the Log Thread knowledge graph schema.",
            mimeType="text/plain",
        ),
        Resource(
            uri="logthread://language-capabilities",
            name="Language Capabilities",
            description="Current language, datastore, and trust-tier support matrix.",
            mimeType="text/plain",
        ),
    ]

def _dispatch_resource(uri_str: str, storage: LadybugBackend) -> str:
    if uri_str == "logthread://overview":
        return get_overview(storage)
    if uri_str == "logthread://dead-code":
        return get_dead_code_list(storage)
    if uri_str == "logthread://schema":
        return get_schema()
    if uri_str == "logthread://language-capabilities":
        return handle_language_capabilities()
    return f"Unknown resource: {uri_str}"


@server.read_resource()
async def read_resource(uri) -> str:
    """Read the contents of an Log Thread resource."""
    is_valid, error_msg = _validate_mcp_access()
    if not is_valid:
        return f"⚠️ MCP access blocked\n\n{error_msg}"

    uri_str = str(uri)
    return await _with_storage(lambda st: _dispatch_resource(uri_str, st))

async def main() -> None:
    """Run the Log Thread MCP server over stdio transport."""
    cleanup_stale_locks()

    if not acquire_instance_lock():
        logger.info("Another MCP instance is running; this process will exit cleanly.")
        return

    def _shutdown(signum: int, _frame: object) -> None:
        _lease.force_close()
        _release_instance_lock()
        raise SystemExit(0)

    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, _shutdown)

    try:
        async with stdio_server() as (read, write):
            await server.run(read, write, server.create_initialization_options())
    finally:
        _lease.force_close()
        _release_instance_lock()


def create_streamable_http_app() -> tuple[StreamableHTTPSessionManager, StreamableHTTPASGIApp]:
    """Create a streamable HTTP transport for the existing MCP server."""
    session_manager = StreamableHTTPSessionManager(app=server)
    return session_manager, StreamableHTTPASGIApp(session_manager)

if __name__ == "__main__":
    asyncio.run(main())
