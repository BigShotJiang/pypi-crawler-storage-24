"""Log Thread MCP server — exposes code intelligence tools to AI agents."""
