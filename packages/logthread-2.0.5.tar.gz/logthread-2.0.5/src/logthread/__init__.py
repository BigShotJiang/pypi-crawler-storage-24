"""Log Thread — AI-powered code intelligence with graph context."""

from __future__ import annotations

from importlib import metadata
from importlib.metadata import PackageNotFoundError
from pathlib import Path

try:  # When installed as a package
    __version__ = metadata.version("logthread")
except PackageNotFoundError:  # Fallback for local source usage
    try:
        pyproject_path = Path(__file__).resolve().parents[2] / "pyproject.toml"
        import tomllib  # Python 3.11+

        with pyproject_path.open("rb") as f:  # type: ignore[attr-defined]
            __version__ = tomllib.load(f)["project"]["version"]
    except Exception:  # pragma: no cover - final fallback
        __version__ = "0.0.0"

__all__ = ["__version__"]
