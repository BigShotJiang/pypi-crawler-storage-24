"""Export LogThread visualizations as standalone HTML files."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LogThread - {title}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0f0f23 0%, #1a1a2e 100%);
            color: #e0e0e0;
            overflow: hidden;
        }}
        
        #container {{
            width: 100vw;
            height: 100vh;
            position: relative;
        }}
        
        #graph {{
            width: 100%;
            height: 100%;
        }}
        
        #info-panel {{
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(26, 26, 46, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            padding: 20px;
            max-width: 400px;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            display: none;
        }}
        
        #info-panel.visible {{
            display: block;
        }}
        
        #info-panel h2 {{
            color: #64ffda;
            margin-bottom: 15px;
            font-size: 1.2em;
        }}
        
        #info-panel .property {{
            margin: 10px 0;
            padding: 8px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 6px;
        }}
        
        #info-panel .label {{
            color: #888;
            font-size: 0.85em;
            text-transform: uppercase;
            letter-spacing: 1px;
        }}
        
        #info-panel .value {{
            color: #e0e0e0;
            margin-top: 4px;
            font-family: 'Courier New', monospace;
        }}
        
        #search-box {{
            position: absolute;
            top: 20px;
            left: 20px;
            background: rgba(26, 26, 46, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 12px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
        }}
        
        #search-input {{
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 6px;
            padding: 8px 12px;
            color: #e0e0e0;
            font-size: 14px;
            width: 300px;
            outline: none;
        }}
        
        #search-input:focus {{
            border-color: #64ffda;
        }}
        
        .node {{
            cursor: pointer;
            transition: all 0.3s ease;
        }}
        
        .node:hover {{
            filter: brightness(1.5);
        }}
        
        .link {{
            stroke: rgba(100, 255, 218, 0.3);
            stroke-width: 1.5px;
        }}
        
        .node-label {{
            font-size: 10px;
            fill: #e0e0e0;
            pointer-events: none;
            text-anchor: middle;
        }}
    </style>
</head>
<body>
    <div id="container">
        <div id="search-box">
            <input type="text" id="search-input" placeholder="Search symbols..." />
        </div>
        <div id="graph"></div>
        <div id="info-panel">
            <h2 id="info-title">Node Details</h2>
            <div id="info-content"></div>
        </div>
    </div>
    
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <script>
        const data = {data_json};
        
        const width = window.innerWidth;
        const height = window.innerHeight;
        
        const svg = d3.select("#graph")
            .append("svg")
            .attr("width", width)
            .attr("height", height);
        
        const g = svg.append("g");
        
        // Zoom behavior
        const zoom = d3.zoom()
            .scaleExtent([0.1, 10])
            .on("zoom", (event) => {{
                g.attr("transform", event.transform);
            }});
        
        svg.call(zoom);
        
        // Color scale for node types
        const colorScale = d3.scaleOrdinal()
            .domain(["function", "class", "method", "interface", "file"])
            .range(["#64ffda", "#ff6b9d", "#ffd93d", "#6bcf7f", "#a78bfa"]);
        
        // Create force simulation
        const simulation = d3.forceSimulation(data.nodes)
            .force("link", d3.forceLink(data.edges).id(d => d.id).distance(100))
            .force("charge", d3.forceManyBody().strength(-300))
            .force("center", d3.forceCenter(width / 2, height / 2))
            .force("collision", d3.forceCollide().radius(30));
        
        // Create links
        const link = g.append("g")
            .selectAll("line")
            .data(data.edges)
            .join("line")
            .attr("class", "link");
        
        // Create nodes
        const node = g.append("g")
            .selectAll("circle")
            .data(data.nodes)
            .join("circle")
            .attr("class", "node")
            .attr("r", d => d.label === "class" ? 12 : 8)
            .attr("fill", d => colorScale(d.label))
            .call(d3.drag()
                .on("start", dragstarted)
                .on("drag", dragged)
                .on("end", dragended))
            .on("click", showNodeInfo);
        
        // Create labels
        const label = g.append("g")
            .selectAll("text")
            .data(data.nodes)
            .join("text")
            .attr("class", "node-label")
            .text(d => d.name)
            .attr("dy", 20);
        
        // Update positions on simulation tick
        simulation.on("tick", () => {{
            link
                .attr("x1", d => d.source.x)
                .attr("y1", d => d.source.y)
                .attr("x2", d => d.target.x)
                .attr("y2", d => d.target.y);
            
            node
                .attr("cx", d => d.x)
                .attr("cy", d => d.y);
            
            label
                .attr("x", d => d.x)
                .attr("y", d => d.y);
        }});
        
        // Drag functions
        function dragstarted(event, d) {{
            if (!event.active) simulation.alphaTarget(0.3).restart();
            d.fx = d.x;
            d.fy = d.y;
        }}
        
        function dragged(event, d) {{
            d.fx = event.x;
            d.fy = event.y;
        }}
        
        function dragended(event, d) {{
            if (!event.active) simulation.alphaTarget(0);
            d.fx = null;
            d.fy = null;
        }}
        
        // Show node info panel
        function showNodeInfo(event, d) {{
            const panel = document.getElementById("info-panel");
            const title = document.getElementById("info-title");
            const content = document.getElementById("info-content");
            
            title.textContent = d.name;
            
            let html = '';
            html += `<div class="property"><div class="label">Type</div><div class="value">${{d.label}}</div></div>`;
            if (d.filePath) html += `<div class="property"><div class="label">File</div><div class="value">${{d.filePath}}</div></div>`;
            if (d.startLine) html += `<div class="property"><div class="label">Line</div><div class="value">${{d.startLine}}</div></div>`;
            if (d.signature) html += `<div class="property"><div class="label">Signature</div><div class="value">${{d.signature}}</div></div>`;
            if (d.isDead) html += `<div class="property"><div class="label">Status</div><div class="value" style="color: #ff6b9d;">Dead Code</div></div>`;
            
            content.innerHTML = html;
            panel.classList.add("visible");
        }}
        
        // Search functionality
        const searchInput = document.getElementById("search-input");
        searchInput.addEventListener("input", (e) => {{
            const query = e.target.value.toLowerCase();
            
            node.attr("opacity", d => {{
                if (!query) return 1;
                return d.name.toLowerCase().includes(query) ? 1 : 0.2;
            }});
            
            label.attr("opacity", d => {{
                if (!query) return 1;
                return d.name.toLowerCase().includes(query) ? 1 : 0.2;
            }});
        }});
        
        // Close info panel when clicking outside
        svg.on("click", (event) => {{
            if (event.target.tagName === "svg") {{
                document.getElementById("info-panel").classList.remove("visible");
            }}
        }});
    </script>
</body>
</html>
"""


def export_graph_html(
    nodes: list[dict[str, Any]],
    edges: list[dict[str, Any]],
    output_path: Path,
    title: str = "Code Graph",
) -> None:
    """Export graph visualization as standalone HTML file.
    
    Args:
        nodes: List of node dictionaries with id, name, label, etc.
        edges: List of edge dictionaries with source, target, type
        output_path: Path where HTML file should be saved
        title: Title for the visualization
    """
    html_content = build_graph_html(nodes=nodes, edges=edges, title=title)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html_content, encoding="utf-8")


def build_graph_html(
    nodes: list[dict[str, Any]],
    edges: list[dict[str, Any]],
    title: str = "Code Graph",
) -> str:
    """Build a standalone HTML graph visualization as a string."""
    graph_data = {
        "nodes": nodes,
        "edges": edges,
    }
    return HTML_TEMPLATE.format(
        title=title,
        data_json=json.dumps(graph_data, indent=2),
    )


def export_impact_html(
    target_node: dict[str, Any],
    affected_nodes: list[dict[str, Any]],
    output_path: Path,
) -> None:
    """Export impact analysis as standalone HTML visualization.
    
    Args:
        target_node: The node being analyzed
        affected_nodes: List of nodes affected by changes to target
        output_path: Path where HTML file should be saved
    """
    # Create nodes and edges for visualization
    nodes = [target_node] + affected_nodes
    edges = [
        {"source": node["id"], "target": target_node["id"], "type": "impacts"}
        for node in affected_nodes
    ]

    html_content = build_impact_html(target_node=target_node, affected_nodes=affected_nodes)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html_content, encoding="utf-8")


def build_impact_html(
    target_node: dict[str, Any],
    affected_nodes: list[dict[str, Any]],
) -> str:
    """Build a standalone HTML impact visualization as a string."""
    nodes = [target_node] + affected_nodes
    edges = [
        {"source": node["id"], "target": target_node["id"], "type": "impacts"}
        for node in affected_nodes
    ]
    return build_graph_html(
        nodes=nodes,
        edges=edges,
        title=f"Impact Analysis: {target_node['name']}",
    )
