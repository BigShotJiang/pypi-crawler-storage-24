"""MCP-powered tool routes — expose LogThread MCP capabilities via REST API."""

from __future__ import annotations

import logging
from typing import Optional

from fastapi import APIRouter, Body, HTTPException, Query, Request

from logthread.mcp import tools as mcp_tools

logger = logging.getLogger(__name__)

router = APIRouter(tags=["mcp-tools"])


@router.get("/context/{symbol:path}")
async def get_context(symbol: str, request: Request) -> dict:
    """Get 360-degree context view of a symbol using MCP handle_context."""
    storage = request.app.state.storage

    try:
        result = mcp_tools.handle_context(storage, symbol)
        return {"symbol": symbol, "context": result}
    except Exception as exc:
        logger.error("Context query failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/explain/{symbol:path}")
async def explain_symbol(symbol: str, request: Request) -> dict:
    """Get narrative explanation of a symbol using MCP handle_explain."""
    storage = request.app.state.storage

    try:
        result = mcp_tools.handle_explain(storage, symbol)
        return {"symbol": symbol, "explanation": result}
    except Exception as exc:
        logger.error("Explain query failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/call-path")
async def get_call_path(
    from_symbol: str = Query(..., description="Source symbol name"),
    to_symbol: str = Query(..., description="Target symbol name"),
    max_depth: int = Query(default=10, ge=1, le=10),
    request: Request = None,
) -> dict:
    """Find shortest call path between two symbols using MCP handle_call_path."""
    storage = request.app.state.storage

    try:
        result = mcp_tools.handle_call_path(storage, from_symbol, to_symbol, max_depth)
        return {
            "fromSymbol": from_symbol,
            "toSymbol": to_symbol,
            "path": result
        }
    except Exception as exc:
        logger.error("Call path query failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/test-impact")
async def get_test_impact(
    diff: str = Query(default="", description="Git diff output"),
    symbols: Optional[list[str]] = Query(default=None, description="List of symbol names"),
    request: Request = None,
) -> dict:
    """Find tests affected by code changes using MCP handle_test_impact."""
    storage = request.app.state.storage

    try:
        result = mcp_tools.handle_test_impact(storage, diff=diff, symbols=symbols)
        return {"testImpact": result}
    except Exception as exc:
        logger.error("Test impact query failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/cycles")
async def get_cycles(
    min_size: int = Query(default=2, ge=2, description="Minimum cycle size"),
    request: Request = None,
) -> dict:
    """Detect circular dependencies using MCP handle_cycles."""
    storage = request.app.state.storage

    try:
        result = mcp_tools.handle_cycles(storage, min_size)
        return {"cycles": result}
    except Exception as exc:
        logger.error("Cycles detection failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/validate-query")
async def validate_sql_query(
    request: Request,
    sql: str = Body(..., embed=True, description="SQL query to validate"),
) -> dict:
    """Validate SQL query against indexed schema using MCP handle_validate_query."""
    storage = request.app.state.storage

    try:
        result = mcp_tools.handle_validate_query(storage, sql)
        return {"sql": sql, "validation": result}
    except Exception as exc:
        logger.error("SQL validation failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/validate-edit")
async def validate_edit(
    request: Request,
    file_path: str = Body(default="", embed=True, description="File path that was edited"),
    symbols: Optional[list[str]] = Body(default=None, embed=True, description="Symbol names to validate"),
) -> dict:
    """Validate edit for broken references using MCP handle_validate_edit."""
    storage = request.app.state.storage

    try:
        result = mcp_tools.handle_validate_edit(storage, file_path=file_path, symbols=symbols)
        return {"validation": result}
    except Exception as exc:
        logger.error("Edit validation failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/api-endpoints")
async def list_api_endpoints(
    path_filter: str = Query(default="", description="Filter endpoints by path substring"),
    request: Request = None,
) -> dict:
    """List all indexed API endpoints using MCP handle_api_endpoints."""
    storage = request.app.state.storage

    try:
        result = mcp_tools.handle_api_endpoints(storage, path_filter)
        return {"endpoints": result}
    except Exception as exc:
        logger.error("API endpoints query failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/review-risk")
async def review_pr_risk(
    request: Request,
    diff: str = Body(..., embed=True, description="Git diff output for PR"),
) -> dict:
    """Assess PR risk using MCP handle_review_risk."""
    storage = request.app.state.storage

    try:
        result = mcp_tools.handle_review_risk(storage, diff)
        return {"risk": result}
    except Exception as exc:
        logger.error("PR risk review failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/file-context/{file_path:path}")
async def get_file_context(file_path: str, request: Request) -> dict:
    """Get comprehensive file context using MCP handle_file_context."""
    storage = request.app.state.storage

    try:
        result = mcp_tools.handle_file_context(storage, file_path)
        return {"filePath": file_path, "context": result}
    except Exception as exc:
        logger.error("File context query failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/diff-impact")
async def get_diff_impact(
    request: Request,
    diff: str = Body(..., embed=True, description="Git diff output"),
    depth: int = Body(default=3, embed=True, ge=1, le=10),
) -> dict:
    """Get impact analysis for a diff using MCP handle_diff_impact."""
    storage = request.app.state.storage

    try:
        result = mcp_tools.handle_diff_impact(storage, diff, depth)
        return {"impact": result}
    except Exception as exc:
        logger.error("Diff impact analysis failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc)) from exc
