"""Runtime log intelligence routes."""

from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from logthread.core.intelligence.runtime_logs import (
    delete_runtime_connector,
    get_latest_runtime_analysis,
    list_runtime_connectors,
    list_runtime_providers,
    query_runtime_logs,
    save_runtime_connector,
    test_runtime_connector,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/runtime", tags=["runtime"])


class RuntimeConnectorPayload(BaseModel):
    id: str | None = None
    name: str
    provider: str
    base_url: str
    credentials: dict[str, str]
    correlation_hints: list[str] = Field(default_factory=list)
    default_source: str | None = None
    verify_tls: bool = True


class RuntimeQueryPayload(BaseModel):
    connector_id: str = Field(alias="connectorId")
    query: str
    start_time: str | None = Field(default=None, alias="startTime")
    end_time: str | None = Field(default=None, alias="endTime")
    hours: int = Field(default=2, ge=1, le=168)
    limit: int = Field(default=150, ge=1, le=400)
    source: str | None = None

    model_config = {"populate_by_name": True}


def _require_repo_path(request: Request):
    repo_path = request.app.state.repo_path
    if repo_path is None:
        raise HTTPException(status_code=400, detail="Repository path is not configured.")
    return repo_path


@router.get("/providers")
def get_runtime_providers() -> dict:
    return {"providers": list_runtime_providers()}


@router.get("/connectors")
def get_runtime_connectors(request: Request) -> dict:
    repo_path = _require_repo_path(request)
    return {"connectors": list_runtime_connectors(repo_path)}


@router.post("/connectors")
def upsert_runtime_connector(payload: RuntimeConnectorPayload, request: Request) -> dict:
    repo_path = _require_repo_path(request)
    try:
        connector = save_runtime_connector(
            repo_path,
            connector_id=payload.id,
            name=payload.name,
            provider=payload.provider,
            base_url=payload.base_url,
            credentials=payload.credentials,
            correlation_hints=payload.correlation_hints,
            default_source=payload.default_source,
            verify_tls=payload.verify_tls,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.error("Failed to save runtime connector: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to save runtime connector.") from exc
    return {"connector": connector}


@router.delete("/connectors/{connector_id}")
def remove_runtime_connector(connector_id: str, request: Request) -> dict:
    repo_path = _require_repo_path(request)
    deleted = delete_runtime_connector(repo_path, connector_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Runtime connector not found.")
    return {"deleted": True}


@router.post("/connectors/{connector_id}/test")
def test_connector(connector_id: str, request: Request) -> dict:
    repo_path = _require_repo_path(request)
    try:
        return test_runtime_connector(repo_path, connector_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        logger.error("Runtime connector test failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.get("/latest")
def get_latest_runtime_packet(request: Request) -> dict:
    repo_path = _require_repo_path(request)
    packet = get_latest_runtime_analysis(repo_path)
    return {"packet": packet}


@router.post("/query")
def run_runtime_query(payload: RuntimeQueryPayload, request: Request) -> dict:
    repo_path = _require_repo_path(request)
    try:
        graph = request.app.state.storage.load_graph()
        packet = query_runtime_logs(
            repo_path,
            graph,
            connector_id=payload.connector_id,
            query=payload.query,
            start_time=payload.start_time,
            end_time=payload.end_time,
            hours=payload.hours,
            limit=payload.limit,
            source=payload.source,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.error("Runtime query failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    return {"packet": packet}
