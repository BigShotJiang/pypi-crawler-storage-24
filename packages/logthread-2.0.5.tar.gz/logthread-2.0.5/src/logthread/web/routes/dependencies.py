"""API routes for external dependencies."""

from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from logthread.core.intelligence.dependencies import build_dependency_intelligence
from logthread.core.graph.model import NodeLabel, RelType

router = APIRouter(prefix="/dependencies", tags=["dependencies"])

class DependencyUsage(BaseModel):
    file_id: str
    file_path: str

class DependencyResponse(BaseModel):
    dep_id: str
    name: str
    language: str
    version: str
    ecosystem: str | None = None
    latest_version: str | None = None
    update_available: bool = False
    update_kind: str | None = None
    advisory_count: int = 0
    advisories: list[dict] = Field(default_factory=list)
    vulnerability_source: str | None = None
    intel_error: str | None = None
    used_by: list[DependencyUsage]

@router.get("", response_model=list[DependencyResponse])
def get_all_dependencies(request: Request):
    """Get all external dependencies and the files that use them."""
    storage = request.app.state.storage
    try:
        graph = storage.load_graph()
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to load dependency graph") from exc

    deps: dict[str, DependencyResponse] = {}
    for node in graph.get_nodes_by_label(NodeLabel.EXTERNAL_DEP):
        deps[node.id] = DependencyResponse(
            dep_id=node.id,
            name=node.name,
            language=node.language,
            version=node.properties.get("version", ""),
            used_by=[],
        )

    for edge in graph.get_relationships_by_type(RelType.DEPENDS_ON):
        dep = deps.get(edge.target)
        if dep is None:
            continue
        f_node = graph.get_node(edge.source)
        if f_node is None:
            continue
        dep.used_by.append(
            DependencyUsage(
                file_id=f_node.id,
                file_path=f_node.file_path or f_node.name,
            )
        )

    return _enrich_dependencies(request, list(deps.values()))


def _enrich_dependencies(request: Request, items: list[DependencyResponse]) -> list[DependencyResponse]:
    repo_path = request.app.state.repo_path
    if repo_path is None:
        return items

    intelligence = build_dependency_intelligence(
        Path(repo_path).resolve(),
        [
            {
                "dep_id": item.dep_id,
                "name": item.name,
                "language": item.language,
                "version": item.version,
            }
            for item in items
        ],
    )

    ecosystem_map = {
        "python": "PyPI",
        "npm": "npm",
        "nuget": "NuGet",
        "go": "Go",
        "ruby": "RubyGems",
    }

    enriched: list[DependencyResponse] = []
    for item in items:
        intel = intelligence.get(item.dep_id)
        enriched.append(
            DependencyResponse(
                dep_id=item.dep_id,
                name=item.name,
                language=item.language,
                version=item.version,
                ecosystem=ecosystem_map.get(item.language.lower()),
                latest_version=intel.latest_version if intel else None,
                update_available=intel.update_available if intel else False,
                update_kind=intel.update_kind if intel else None,
                advisory_count=intel.advisory_count if intel else 0,
                advisories=intel.advisories or [] if intel else [],
                vulnerability_source=intel.vulnerability_source if intel else None,
                intel_error=intel.lookup_error if intel else None,
                used_by=item.used_by,
            )
        )

    return enriched
