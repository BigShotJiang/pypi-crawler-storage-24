"""Focused trace routes for developer-readable graph exploration."""

from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, HTTPException, Query, Request

from logthread.core.intelligence.traces import build_trace_catalog, build_trace_packet
from logthread.web.routes.graph import _serialize_edge, _serialize_node

router = APIRouter(tags=["traces"])


@router.get("/traces/catalog")
def get_trace_catalog(request: Request) -> dict:
    graph = request.app.state.storage.load_graph()
    repo_path = getattr(request.app.state, "repo_path", None)
    repo = Path(repo_path).resolve() if repo_path else None
    return {"entries": build_trace_catalog(graph, repo)}


@router.get("/traces/{root_node_id:path}")
def get_trace(
    root_node_id: str,
    request: Request,
    lens: str = Query("balanced", pattern="^(balanced|data)$"),
    max_depth: int = Query(5, ge=1, le=10),
) -> dict:
    graph = request.app.state.storage.load_graph()
    repo_path = getattr(request.app.state, "repo_path", None)
    repo = Path(repo_path).resolve() if repo_path else None

    try:
        packet = build_trace_packet(graph, root_node_id, lens=lens, max_depth=max_depth)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Trace root not found") from exc

    return {
        **packet,
        "root": _serialize_node(graph.get_node(packet["rootNodeId"])),
        "nodes": [_serialize_node(node) for node in packet["nodes"]],
        "edges": [
            _serialize_edge(edge, graph.get_node(edge.source), graph.get_node(edge.target))
            for edge in packet["edges"]
        ],
        "boundaries": {
            key: [_serialize_node(node) for node in value]
            for key, value in packet["boundaries"].items()
        },
        "repoPath": str(repo) if repo else None,
    }
