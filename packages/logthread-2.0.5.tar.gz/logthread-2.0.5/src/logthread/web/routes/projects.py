"""Projects route — list and switch between indexed repositories."""

from __future__ import annotations

import logging
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from logthread.core.storage.paths import get_all_projects, get_db_path, load_project_meta

logger = logging.getLogger(__name__)

router = APIRouter(tags=["projects"])


class ProjectInfo(BaseModel):
    """Information about an indexed project."""

    id: str
    name: str
    path: str
    symbols: int
    files: int
    updated_at: str
    is_current: bool
    has_index: bool


@router.get("/projects")
def list_projects(request: Request) -> dict:
    """List all indexed projects from the global registry.
    
    Returns a list of projects with their metadata and indicates which
    one is currently active.
    """
    try:
        projects = get_all_projects()
        current_repo_path = request.app.state.repo_path
        current_path_str = str(current_repo_path.resolve()) if current_repo_path else None
        
        result = []
        seen_paths: set[str] = set()
        for project in projects:
            project_path = Path(project["path"])
            project_path_str = str(project_path.resolve())
            if project_path_str in seen_paths:
                continue
            seen_paths.add(project_path_str)
            
            # Check if the project has an actual index
            db_path = get_db_path(project_path)
            has_index = db_path.exists()
            
            # Load fresh metadata if available
            meta = load_project_meta(project_path)
            if meta:
                symbols = meta.get("symbols", project.get("symbols", 0))
                files = meta.get("files", project.get("files", 0))
                updated_at = meta.get("_updated_at", project.get("updated_at", ""))
            else:
                symbols = project.get("symbols", 0)
                files = project.get("files", 0)
                updated_at = project.get("updated_at", "")
            
            result.append({
                "id": project["id"],
                "name": project.get("name", project_path.name),
                "path": project_path_str,
                "symbols": symbols,
                "files": files,
                "updated_at": updated_at,
                "is_current": project_path_str == current_path_str,
                "has_index": has_index,
            })

        if current_path_str and current_path_str not in seen_paths:
            current_project_path = Path(current_path_str)
            current_db_path = get_db_path(current_project_path)
            current_meta = load_project_meta(current_project_path) or {}
            current_stats = current_meta.get("stats", {}) if isinstance(current_meta.get("stats"), dict) else {}
            result.append({
                "id": current_meta.get("_project_id") or current_project_path.name,
                "name": current_meta.get("name", current_project_path.name),
                "path": current_path_str,
                "symbols": current_meta.get("symbols", current_stats.get("symbols", 0)),
                "files": current_meta.get("files", current_stats.get("files", 0)),
                "updated_at": current_meta.get("_updated_at", current_meta.get("last_indexed_at", "")),
                "is_current": True,
                "has_index": current_db_path.exists(),
            })
        
        # Keep the active repo visible first, then recent projects.
        result.sort(key=lambda p: (not p["is_current"], p["name"].lower(), p["path"]))
        result.sort(key=lambda p: p["updated_at"], reverse=True)
        result.sort(key=lambda p: not p["is_current"])
        
        return {
            "projects": result,
            "current_path": current_path_str,
        }
    except Exception as exc:
        logger.error("Failed to list projects: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to list projects") from exc


class SwitchProjectRequest(BaseModel):
    """Request body for switching projects."""
    project_path: str


@router.post("/projects/switch")
async def switch_project(body: SwitchProjectRequest, request: Request) -> dict:
    """Switch to a different indexed project without restarting the server.
    
    This works because all project data is stored in centralized location.
    """
    project_path = Path(body.project_path)
    
    if not project_path.exists():
        raise HTTPException(status_code=400, detail=f"Project path does not exist: {project_path}")
    
    # Check if project has an index
    db_path = get_db_path(project_path)
    if not db_path.exists():
        raise HTTPException(status_code=400, detail=f"Project has no index: {project_path}")
    
    try:
        # Close current storage
        current_storage = request.app.state.storage
        if current_storage:
            current_storage.close()
        
        # Open new storage
        from logthread.core.storage.ladybug_backend import LadybugBackend
        new_storage = LadybugBackend()
        new_storage.initialize(db_path, read_only=True)
        
        # Update app state
        request.app.state.storage = new_storage
        request.app.state.repo_path = project_path
        
        # Update runtime if it exists
        if hasattr(request.app.state, 'runtime') and request.app.state.runtime:
            request.app.state.runtime.storage = new_storage
            request.app.state.runtime.repo_path = project_path
        
        return {
            "success": True,
            "message": f"Switched to project: {project_path.name}",
            "project_path": str(project_path),
        }
    except Exception as exc:
        logger.error("Failed to switch project: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to switch project: {str(exc)}") from exc
