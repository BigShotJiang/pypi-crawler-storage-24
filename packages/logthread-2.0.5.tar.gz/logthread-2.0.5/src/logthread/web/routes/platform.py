"""Platform intelligence routes for structured trust-aware packets."""

from __future__ import annotations

import logging
from pathlib import Path

from fastapi import APIRouter, Body, HTTPException, Request

from logthread.mcp import tools as mcp_tools

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/platform", tags=["platform"])


def _count_changed_files(diff: str) -> int:
    return sum(1 for line in diff.splitlines() if line.startswith("diff --git "))


@router.get("/capabilities")
async def get_capabilities() -> dict:
    try:
        packet = mcp_tools.build_language_capabilities_packet()
        return {
            "report": mcp_tools.handle_language_capabilities(),
            "packet": packet,
        }
    except Exception as exc:
        logger.error("Capabilities query failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/context/{symbol:path}")
async def get_context_packet(symbol: str, request: Request) -> dict:
    storage = request.app.state.storage
    try:
        return {
            "symbol": symbol,
            "context": mcp_tools.handle_context(storage, symbol),
            "packet": mcp_tools.build_symbol_context_packet(storage, symbol),
        }
    except Exception as exc:
        logger.error("Context packet query failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/implementation-brief")
async def get_implementation_brief(
    request: Request,
    query: str = Body(default="", embed=True, description="Natural-language implementation objective"),
    symbol: str = Body(default="", embed=True, description="Optional exact symbol anchor"),
    max_candidates: int = Body(default=8, embed=True, ge=1, le=16),
) -> dict:
    storage = request.app.state.storage
    try:
        return {
            "brief": mcp_tools.handle_implementation_brief(
                storage,
                query,
                symbol=symbol,
                max_candidates=max_candidates,
            ),
            "packet": mcp_tools.build_implementation_brief_packet(
                storage,
                query,
                symbol=symbol,
                max_candidates=max_candidates,
            ),
        }
    except Exception as exc:
        logger.error("Implementation brief query failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/edit-contract")
async def get_edit_contract(
    request: Request,
    query: str = Body(default="", embed=True, description="Natural-language implementation objective"),
    symbol: str = Body(default="", embed=True, description="Optional exact symbol anchor"),
    max_candidates: int = Body(default=8, embed=True, ge=1, le=16),
) -> dict:
    storage = request.app.state.storage
    repo_path = request.app.state.repo_path
    if repo_path is None:
        raise HTTPException(status_code=400, detail="No repo_path configured")

    try:
        resolved_repo_path = Path(repo_path).resolve()
        return {
            "contract": mcp_tools.handle_agent_safe_edit_contract(
                storage,
                resolved_repo_path,
                query,
                symbol=symbol,
                max_candidates=max_candidates,
            ),
            "packet": mcp_tools.build_agent_safe_edit_contract_packet(
                storage,
                resolved_repo_path,
                query,
                symbol=symbol,
                max_candidates=max_candidates,
            ),
        }
    except Exception as exc:
        logger.error("Edit contract query failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/workspace-map")
async def get_workspace_map(request: Request) -> dict:
    repo_path = request.app.state.repo_path
    if repo_path is None:
        raise HTTPException(status_code=400, detail="No repo_path configured")

    try:
        resolved_repo_path = Path(repo_path).resolve()
        return {
            "report": mcp_tools.handle_workspace_map(resolved_repo_path),
            "packet": mcp_tools.build_workspace_map(resolved_repo_path),
        }
    except Exception as exc:
        logger.error("Workspace map query failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/working-diff")
async def get_working_diff(request: Request) -> dict:
    repo_path = request.app.state.repo_path
    if repo_path is None:
        raise HTTPException(status_code=400, detail="No repo_path configured")

    try:
        resolved_repo_path = Path(repo_path).resolve()
        diff = mcp_tools.get_current_git_diff(resolved_repo_path)
        return {
            "source": "working_tree",
            "repoPath": str(resolved_repo_path),
            "diff": diff,
            "hasChanges": bool(diff.strip()),
            "changedFiles": _count_changed_files(diff),
        }
    except Exception as exc:
        logger.error("Working diff query failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/change-risk")
async def get_change_risk_packet(
    request: Request,
    diff: str | None = Body(default=None, embed=True, description="Git diff output to analyze"),
    depth: int = Body(default=3, embed=True, ge=1, le=10),
    use_working_tree: bool = Body(default=True, embed=True),
) -> dict:
    storage = request.app.state.storage
    repo_path = request.app.state.repo_path
    try:
        resolved_diff = diff or ""
        source = "provided"
        if use_working_tree and not resolved_diff.strip() and repo_path is not None:
            resolved_diff = mcp_tools.get_current_git_diff(Path(repo_path).resolve())
            source = "working_tree"
        return {
            "source": source,
            "diff": resolved_diff,
            "hasChanges": bool(resolved_diff.strip()),
            "report": mcp_tools.handle_review_risk(storage, resolved_diff),
            "impact": mcp_tools.handle_diff_impact(storage, resolved_diff, depth),
            "packet": mcp_tools.build_change_risk_packet(storage, resolved_diff, depth),
        }
    except Exception as exc:
        logger.error("Change risk packet query failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/confidence-report")
async def get_confidence_report(request: Request) -> dict:
    storage = request.app.state.storage
    try:
        return {
            "report": mcp_tools.handle_confidence_report(storage),
            "packet": mcp_tools.build_confidence_report_packet(storage),
        }
    except Exception as exc:
        logger.error("Confidence report query failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc)) from exc
