"""Graph API routes — full graph, node detail, overview stats."""

from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException, Request

from logthread.core.graph.model import GraphNode, GraphRelationship, NodeLabel
from logthread.core.provenance import (
    ensure_relationship_provenance,
    infer_node_capability_tier,
    serialize_confidence,
    serialize_provenance,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["graph"])


def _serialize_node(node: GraphNode) -> dict:
    """Convert a GraphNode to a camelCase dict for the frontend."""
    return {
        "id": node.id,
        "label": node.label.value,
        "name": node.name,
        "filePath": node.file_path,
        "startLine": node.start_line,
        "endLine": node.end_line,
        "signature": node.signature,
        "language": node.language,
        "className": node.class_name,
        "isDead": node.is_dead,
        "isEntryPoint": node.is_entry_point,
        "isExported": node.is_exported,
        "properties": node.properties,
        "provenance": serialize_provenance(node.properties, fallback_source_id=node.id),
        "confidence": serialize_confidence(
            node.properties,
            fallback_tier=infer_node_capability_tier(node),
        ),
    }


def _serialize_edge(
    rel: GraphRelationship,
    source_node: GraphNode | None = None,
    target_node: GraphNode | None = None,
) -> dict:
    """Convert a GraphRelationship to a camelCase dict for the frontend."""
    ensure_relationship_provenance(
        rel,
        source_node,
        target_node,
        observed_at=(source_node.properties or {}).get("observed_at") if source_node else None,
        commit_sha=(source_node.properties or {}).get("commit_sha") if source_node else None,
    )
    return {
        "id": rel.id,
        "type": rel.type.value,
        "source": rel.source,
        "target": rel.target,
        "confidence": rel.properties.get("confidence", 1.0),
        "confidenceScore": rel.properties.get(
            "confidence_score",
            rel.properties.get("confidence", 1.0),
        ),
        "strength": rel.properties.get("strength"),
        "stepNumber": rel.properties.get("step_number"),
        "provenance": serialize_provenance(rel.properties, fallback_source_id=rel.id),
    }


@router.get("/graph")
def get_graph(request: Request) -> dict:
    """Load the full knowledge graph and serialize all nodes and edges."""
    storage = request.app.state.storage
    try:
        graph = storage.load_graph()
    except Exception as exc:
        logger.error("Failed to load graph: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to load graph") from exc

    nodes = [_serialize_node(n) for n in graph.iter_nodes()]
    edges = [
        _serialize_edge(r, graph.get_node(r.source), graph.get_node(r.target))
        for r in graph.iter_relationships()
    ]

    return {"nodes": nodes, "edges": edges, "total": len(nodes)}


@router.get("/node/{node_id:path}")
def get_node(node_id: str, request: Request) -> dict:
    """Get a single node with its callers, callees, type refs, and process memberships."""
    if len(node_id) > 500:
        raise HTTPException(status_code=400, detail="Node ID too long")

    storage = request.app.state.storage

    node = storage.get_node(node_id)
    if node is None:
        raise HTTPException(status_code=404, detail="Node not found")

    callers = [
        {"node": _serialize_node(n), "confidence": conf}
        for n, conf in storage.get_callers_with_confidence(node_id)
    ]

    callees = [
        {"node": _serialize_node(n), "confidence": conf}
        for n, conf in storage.get_callees_with_confidence(node_id)
    ]

    type_refs = [_serialize_node(n) for n in storage.get_type_refs(node_id)]

    process_memberships = storage.get_process_memberships([node_id])

    return {
        "node": _serialize_node(node),
        "callers": callers,
        "callees": callees,
        "typeRefs": type_refs,
        "processMemberships": process_memberships,
    }


@router.get("/overview")
def get_overview(request: Request) -> dict:
    """Return aggregate counts of nodes by label, edges by type, and totals."""
    storage = request.app.state.storage

    nodes_by_label: dict[str, int] = {}
    total_nodes = 0
    valid_labels = {label.value for label in NodeLabel}
    label_aliases = {
        "apiendpoint": "api_endpoint",
        "dbtable": "db_table",
        "dbcolumn": "db_column",
        "externaldep": "external_dep",
        "typealias": "type_alias",
    }
    try:
        rows = storage.execute_raw(
            "MATCH (n) RETURN labels(n), count(n) ORDER BY count(n) DESC"
        )
        for row in rows or []:
            raw_label = row[0] if row else "Unknown"
            if isinstance(raw_label, list) and raw_label:
                label = raw_label[0].lower()
            else:
                label = str(raw_label).lower()
            count = row[1] if len(row) > 1 else 0
            label = label_aliases.get(label, label)
            if label not in valid_labels:
                continue
            nodes_by_label[label] = count
            total_nodes += count
    except Exception:
        logger.warning("Failed to query node counts", exc_info=True)

    edges_by_type: dict[str, int] = {}
    total_edges = 0
    try:
        rows = storage.execute_raw(
            "MATCH ()-[r:CodeRelation]->() RETURN r.rel_type, count(r) ORDER BY count(r) DESC"
        )
        for row in rows or []:
            rel_type = row[0] if row else "Unknown"
            count = row[1] if len(row) > 1 else 0
            edges_by_type[str(rel_type)] = count
            total_edges += count
    except Exception:
        logger.warning("Failed to query edge counts", exc_info=True)

    capability_tiers = {"T0": 0, "T1": 0, "T2": 0, "T3": 0}
    languages: dict[str, int] = {}
    source_systems: dict[str, int] = {}
    latest_observed_at: str | None = None
    latest_verified_at: str | None = None
    commit_sha: str | None = None
    try:
        graph = storage.load_graph()
        for node in graph.iter_nodes():
            props = node.properties or {}
            tier = str(props.get("capability_tier") or infer_node_capability_tier(node)).upper()
            capability_tiers[tier] = capability_tiers.get(tier, 0) + 1
            if node.language:
                languages[node.language] = languages.get(node.language, 0) + 1

            source = str(props.get("source_system") or "logthread.indexer")
            source_systems[source] = source_systems.get(source, 0) + 1

            observed_at = props.get("observed_at")
            if observed_at and (latest_observed_at is None or str(observed_at) > latest_observed_at):
                latest_observed_at = str(observed_at)
            verified_at = props.get("last_verified_at")
            if verified_at and (latest_verified_at is None or str(verified_at) > latest_verified_at):
                latest_verified_at = str(verified_at)
            if commit_sha is None and props.get("commit_sha"):
                commit_sha = str(props.get("commit_sha"))
    except Exception:
        logger.warning("Failed to compute provenance overview", exc_info=True)

    return {
        "nodesByLabel": nodes_by_label,
        "edgesByType": edges_by_type,
        "totalNodes": total_nodes,
        "totalEdges": total_edges,
        "capabilityTiers": capability_tiers,
        "languages": languages,
        "provenance": {
            "sourceSystems": source_systems,
            "lastObservedAt": latest_observed_at,
            "lastVerifiedAt": latest_verified_at,
            "commitSha": commit_sha,
        },
    }
