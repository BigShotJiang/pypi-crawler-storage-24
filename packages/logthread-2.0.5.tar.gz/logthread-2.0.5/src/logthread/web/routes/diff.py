"""Branch diff route — structural comparison between two git refs."""

from __future__ import annotations

import logging
import re
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, field_validator

from logthread.core.diff import diff_branches
from logthread.core.git_utils import discover_git_repositories
from logthread.web.routes.graph import _serialize_edge, _serialize_node

logger = logging.getLogger(__name__)

router = APIRouter(tags=["diff"])

# Allow only safe characters in git refs: alphanumerics, dots, slashes,
# hyphens, tildes, carets, at-signs, and braces. Rejects shell meta-chars.
_SAFE_REF = re.compile(r"^[a-zA-Z0-9._/\-~^@{}]+$")


class DiffRequest(BaseModel):
    """Body for the POST /diff endpoint."""

    base: str
    compare: str
    repoPath: str | None = None  # Optional: use a different repo path

    @field_validator("base", "compare")
    @classmethod
    def validate_ref(cls, v: str) -> str:
        if not v or not _SAFE_REF.match(v):
            raise ValueError("Invalid git ref")
        if v.startswith("-"):
            raise ValueError("Git ref cannot start with -")
        return v


@router.post("/diff")
def compute_diff(body: DiffRequest, request: Request) -> dict:
    """Compare two branches structurally and return added/removed/modified entities."""
    # Use provided repo path or fall back to configured repo_path
    if body.repoPath:
        repo_path = Path(body.repoPath)
    else:
        repo_path = request.app.state.repo_path
    
    if repo_path is None:
        raise HTTPException(status_code=400, detail="No repo_path configured")

    branch_range = f"{body.base}..{body.compare}"

    try:
        result = diff_branches(repo_path, branch_range)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except RuntimeError as exc:
        # Extract more helpful error message
        error_msg = str(exc)
        if "not a git repository" in error_msg.lower():
            raise HTTPException(
                status_code=400,
                detail=f"Not a git repository: {repo_path}. The server must be started from within a git repository directory."
            ) from exc
        elif "unknown revision" in error_msg.lower() or "bad revision" in error_msg.lower():
            raise HTTPException(
                status_code=400,
                detail=f"Branch '{body.base}' not found. Please check the branch name."
            ) from exc
        raise HTTPException(status_code=500, detail=error_msg) from exc
    except Exception as exc:
        logger.error("Diff failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Diff operation failed") from exc

    return {
        "added": [_serialize_node(n) for n in result.added_nodes],
        "removed": [_serialize_node(n) for n in result.removed_nodes],
        "modified": [
            {"before": _serialize_node(base), "after": _serialize_node(current)}
            for base, current in result.modified_nodes
        ],
        "addedEdges": [_serialize_edge(r) for r in result.added_relationships],
        "removedEdges": [_serialize_edge(r) for r in result.removed_relationships],
    }


@router.get("/git-repos")
def discover_repos(request: Request) -> dict:
    """Discover git repositories accessible from the current repo_path.
    
    Returns repositories found in parent directories and subdirectories.
    """
    repo_path = request.app.state.repo_path
    if repo_path is None:
        # If no repo_path configured, use current working directory
        from pathlib import Path
        repo_path = Path.cwd()
    
    try:
        discovered = discover_git_repositories(repo_path, max_depth=3)
        
        return {
            "current": str(repo_path),
            "isGitRepo": (repo_path / ".git").exists(),
            "parent": [str(p) for p in discovered["parent"]],
            "subdirs": [str(p) for p in discovered["subdirs"]],
        }
    except Exception as exc:
        logger.error("Failed to discover git repos: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to discover git repositories") from exc
