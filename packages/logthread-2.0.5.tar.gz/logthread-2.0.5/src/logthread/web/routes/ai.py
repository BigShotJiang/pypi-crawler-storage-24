"""API routes for AI code modifications using Google Gemini."""

import difflib
import logging
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from logthread.core.ai.llm import AIClient, AIIntegrationUnavailable, AIProviderConfig, ai_sdk_available
from logthread.core.storage.paths import get_project_dir

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/ai", tags=["ai"])

class SuggestRequest(BaseModel):
    file_path: str
    instruction: str
    context: str = ""
    use_tools: bool = False

class SuggestResponse(BaseModel):
    file_path: str
    original_content: str
    suggested_content: str
    diff: str
    tool_calls: list[dict] = []

class ApplyRequest(BaseModel):
    file_path: str
    suggested_content: str

class ApplyResponse(BaseModel):
    success: bool
    message: str

class APIKeyRequest(BaseModel):
    api_key: str
    model: Optional[str] = None

class APIKeyResponse(BaseModel):
    success: bool
    message: str
    has_key: bool
    model: str

class ConfigResponse(BaseModel):
    has_key: bool
    model: str
    available: bool
    install_hint: str | None = None
    provider: str = "gemini"

def _generate_diff(original: str, modified: str, fromfile: str, tofile: str) -> str:
    """Generate a unified diff between two strings."""
    original_lines = original.splitlines(keepends=True)
    modified_lines = modified.splitlines(keepends=True)

    diff = list(difflib.unified_diff(
        original_lines,
        modified_lines,
        fromfile=fromfile,
        tofile=tofile,
        n=3
    ))
    return "".join(diff)

def _get_api_key_path(repo_path: Path) -> Path:
    """Get the path to the API key storage file."""
    project_dir = get_project_dir(repo_path)
    return project_dir / "gemini_api_key.txt"

def _save_api_key(repo_path: Path, api_key: str, model: str) -> None:
    """Save API key and model to secure storage."""
    key_path = _get_api_key_path(repo_path)
    key_path.parent.mkdir(parents=True, exist_ok=True)

    # Store both key and model
    content = f"{api_key}\n{model}"
    key_path.write_text(content, encoding="utf-8")

    # Set restrictive permissions (owner read/write only)
    key_path.chmod(0o600)

def _load_api_key(repo_path: Path) -> tuple[Optional[str], str]:
    """Load API key and model from storage."""
    key_path = _get_api_key_path(repo_path)
    if not key_path.exists():
        return None, "gemini-2.0-flash-exp"

    try:
        content = key_path.read_text(encoding="utf-8").strip()
        lines = content.split("\n")
        api_key = lines[0] if lines else None
        model = lines[1] if len(lines) > 1 else "gemini-2.0-flash-exp"
        return api_key, model
    except Exception as e:
        logger.error(f"Failed to load API key: {e}")
        return None, "gemini-2.0-flash-exp"

@router.get("/config", response_model=ConfigResponse)
def get_config(request: Request):
    """Get current AI configuration."""
    repo_path = request.app.state.repo_path
    if repo_path is None:
        raise HTTPException(status_code=400, detail="Repository path is not configured.")

    api_key, model = _load_api_key(repo_path)

    return ConfigResponse(
        has_key=api_key is not None and len(api_key) > 0,
        model=model,
        available=ai_sdk_available(),
        install_hint=None if ai_sdk_available() else "Install optional AI support with: pip install 'logthread[ai]'",
        provider="gemini"
    )

@router.post("/config", response_model=APIKeyResponse)
def set_api_key(req: APIKeyRequest, request: Request):
    """Set Gemini API key and model."""
    repo_path = request.app.state.repo_path
    if repo_path is None:
        raise HTTPException(status_code=400, detail="Repository path is not configured.")

    if not req.api_key or len(req.api_key.strip()) == 0:
        raise HTTPException(status_code=400, detail="API key cannot be empty.")

    model = req.model or "gemini-2.0-flash-exp"

    try:
        _save_api_key(repo_path, req.api_key.strip(), model)
        return APIKeyResponse(
            success=True,
            message="API key saved successfully",
            has_key=True,
            model=model
        )
    except Exception as e:
        logger.error(f"Failed to save API key: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to save API key: {e}")

@router.delete("/config", response_model=APIKeyResponse)
def delete_api_key(request: Request):
    """Delete stored API key."""
    repo_path = request.app.state.repo_path
    if repo_path is None:
        raise HTTPException(status_code=400, detail="Repository path is not configured.")

    key_path = _get_api_key_path(repo_path)
    if key_path.exists():
        key_path.unlink()

    return APIKeyResponse(
        success=True,
        message="API key deleted",
        has_key=False,
        model="gemini-2.0-flash-exp"
    )

@router.post("/suggest", response_model=SuggestResponse)
def suggest_edit(
    req: SuggestRequest,
    request: Request
):
    """Ask Gemini AI to suggest an edit for a specific file."""
    repo_path = request.app.state.repo_path
    if repo_path is None:
        raise HTTPException(status_code=400, detail="Repository path is not configured.")

    # Load API key from storage
    api_key, model = _load_api_key(repo_path)
    if not api_key:
        raise HTTPException(
            status_code=400,
            detail="Gemini API key not configured. Please set your API key in settings."
        )

    abs_path = repo_path / req.file_path
    if not abs_path.is_file():
        raise HTTPException(status_code=404, detail=f"File not found: {req.file_path}")

    try:
        content = abs_path.read_text(encoding="utf-8")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to read file: {e}")

    # Create AI client with stored credentials
    config = AIProviderConfig(api_key=api_key, model=model)
    try:
        client = AIClient(config)
    except AIIntegrationUnavailable as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    # Get suggestion from Gemini
    try:
        if req.use_tools:
            # Use tool calling for advanced modifications
            result = client.suggest_edit_with_tools(
                instruction=req.instruction,
                file_path=req.file_path,
                file_content=content,
                context=req.context
            )
            new_content = result["content"]
            tool_calls = result.get("tool_calls", [])
        else:
            # Simple modification without tools
            new_content = client.suggest_edit(
                instruction=req.instruction,
                file_path=req.file_path,
                file_content=content,
                context=req.context
            )
            tool_calls = []
    except AIIntegrationUnavailable as e:
        logger.error(f"Gemini SDK unavailable: {e}")
        raise HTTPException(status_code=503, detail=str(e)) from e
    except Exception as e:
        logger.error(f"Gemini API error: {e}")
        raise HTTPException(status_code=500, detail=f"Gemini AI service failed: {e}")

    # Generate diff
    diff_text = _generate_diff(
        original=content,
        modified=new_content,
        fromfile=f"a/{req.file_path}",
        tofile=f"b/{req.file_path}"
    )

    return SuggestResponse(
        file_path=req.file_path,
        original_content=content,
        suggested_content=new_content,
        diff=diff_text,
        tool_calls=tool_calls
    )

@router.post("/apply", response_model=ApplyResponse)
def apply_edit(
    req: ApplyRequest,
    request: Request
):
    """Apply the suggested edit to the file on disk."""
    repo_path = request.app.state.repo_path
    if repo_path is None:
        raise HTTPException(status_code=400, detail="Repository path is not configured.")

    abs_path = repo_path / req.file_path
    if not abs_path.exists():
        raise HTTPException(status_code=404, detail=f"File not found: {req.file_path}")

    try:
        abs_path.write_text(req.suggested_content, encoding="utf-8")
        return ApplyResponse(
            success=True,
            message=f"Successfully updated {req.file_path}"
        )
    except Exception as e:
        logger.error(f"Failed to write changes to {abs_path}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to apply changes: {e}")
