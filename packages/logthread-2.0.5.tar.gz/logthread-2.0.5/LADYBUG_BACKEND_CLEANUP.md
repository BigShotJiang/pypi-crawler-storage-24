# Ladybug Backend Cleanup Summary

## Overview
Cleaned up all references to KuzuDB and ensured LogThread exclusively uses Ladybug as the backend database.

## Background
LogThread originally used KuzuDB as its embedded graph database. The project has since migrated to LadybugDB (which is based on KuzuDB but with enhancements). This cleanup ensures all code, comments, and configuration consistently reference Ladybug instead of Kuzu.

## Changes Made

### 1. Database Configuration (`src/logthread/core/storage/database_config.py`)
- Changed `DatabaseType.KUZU` → `DatabaseType.LADYBUG`
- Updated default database type from `"kuzu"` to `"ladybug"`
- Updated environment variable default: `LOGTHREAD_DB_TYPE` now defaults to `"ladybug"`
- Updated conditional checks to use `DatabaseType.LADYBUG`

### 2. Code Comments and Documentation

**Updated files:**
- `src/logthread/mcp/resources.py` - Comment about label format
- `src/logthread/core/storage/ladybug_backend.py` - Module docstring
- `src/logthread/core/storage/base.py` - Protocol docstring
- `src/logthread/web/routes/dependencies.py` - Query comments
- `tests/web/test_routes.py` - Test docstring
- `tests/conftest.py` - Fixture name and docstring

**Changes:**
- "KuzuDB" → "Ladybug" or "LadybugDB"
- "Kuzu" → "Ladybug"
- References to "formerly KuzuDB" removed

### 3. Test Data (`tests/`)
- `tests/core/test_dead_code.py` - Changed test class name from `KuzuBackend` to `LadybugBackend`
- `tests/mcp/test_tools.py` - Changed test data from `KuzuBackend` to `LadybugBackend`
- `tests/conftest.py` - Renamed fixture from `kuzu_backend` to `ladybug_backend`

### 4. Backward Compatibility
**Preserved in `src/logthread/core/storage/ladybug_backend.py`:**
```python
# Backward-compatible alias so existing code importing KuzuBackend still works.
KuzuBackend = LadybugBackend
```

This alias ensures any external code or plugins that import `KuzuBackend` will continue to work.

## Database Directory Migration

The code already handles migration from old Kuzu directories to Ladybug:

**In `src/logthread/core/storage/paths.py`:**
- Checks for legacy `kuzu` directory
- Automatically renames to `ladybug` directory
- Logs the migration

**Directory structure:**
```
.logthread/
├── ladybug/          # Current database directory
│   ├── nodes/
│   └── rels/
└── kuzu/             # Legacy (auto-migrated if found)
```

## Environment Variables

### Updated Defaults
- `LOGTHREAD_DB_TYPE`: Now defaults to `"ladybug"` (was `"kuzu"`)

### Supported Values
- `"ladybug"` - Embedded Ladybug database (default)
- `"neo4j"` - Neo4j database
- `"falkordb"` - FalkorDB embedded
- `"falkordb-remote"` - FalkorDB remote

### Other Environment Variables (unchanged)
- `LOGTHREAD_DB_PATH` - Path to database directory
- `LOGTHREAD_DB_URI` - URI for remote databases
- `LOGTHREAD_DB_USERNAME` - Username for remote databases
- `LOGTHREAD_DB_PASSWORD` - Password for remote databases
- `LOGTHREAD_DB_DATABASE` - Database name for remote databases

## Impact Assessment

### ✅ No Breaking Changes
- Backward-compatible alias `KuzuBackend = LadybugBackend` preserved
- Automatic directory migration from `kuzu/` to `ladybug/`
- Environment variable `LOGTHREAD_DB_TYPE=kuzu` still works (enum value exists)

### ✅ Improved Consistency
- All code now consistently references Ladybug
- Comments and documentation are accurate
- Test data uses correct naming

### ✅ Future-Proof
- Clear separation from upstream KuzuDB project
- Easier to maintain and explain to contributors
- Consistent branding

## Verification

To verify the changes:

```bash
# Check for remaining Kuzu references (should only find backward-compat alias)
grep -r "Kuzu" src/logthread/ --include="*.py" | grep -v "KuzuBackend = LadybugBackend"

# Check environment variable handling
python -c "from logthread.core.storage.database_config import DatabaseConfig; print(DatabaseConfig.from_env().db_type)"

# Verify database directory
ls -la .logthread/
# Should show 'ladybug' directory
```

## Migration Guide for Users

### For Existing Users
No action required. The migration is automatic:
1. Old `kuzu` directories are automatically renamed to `ladybug`
2. Environment variables continue to work
3. Code using `KuzuBackend` continues to work via alias

### For New Users
- Database is stored in `.logthread/ladybug/` by default
- No configuration needed for embedded database
- Use `LOGTHREAD_DB_TYPE=ladybug` (or omit for default)

### For Developers
- Import `LadybugBackend` instead of `KuzuBackend` in new code
- Use `DatabaseType.LADYBUG` in configuration
- Update documentation to reference Ladybug

## Related Files

### Core Backend Files
- `src/logthread/core/storage/ladybug_backend.py` - Main backend implementation
- `src/logthread/core/storage/database_config.py` - Configuration
- `src/logthread/core/storage/paths.py` - Path management and migration
- `src/logthread/core/storage/base.py` - Storage protocol

### Test Files
- `tests/conftest.py` - Test fixtures
- `tests/core/test_dead_code.py` - Dead code analysis tests
- `tests/mcp/test_tools.py` - MCP tools tests
- `tests/web/test_routes.py` - Web route tests

## Technical Details

### Database Technology
- **Ladybug**: Embedded graph database based on KuzuDB
- **Query Language**: Cypher
- **Storage**: Local file-based (no server required)
- **Performance**: Optimized for code analysis workloads

### Why Ladybug?
1. **Embedded**: No separate database server needed
2. **Fast**: Optimized for graph queries
3. **Cypher**: Standard graph query language
4. **Portable**: Single directory, easy to backup/move
5. **Open Source**: Based on open-source KuzuDB

## Future Considerations

### Potential Enhancements
1. Add Ladybug-specific optimizations
2. Implement custom indexes for code analysis
3. Add database statistics and monitoring
4. Optimize schema for common query patterns

### Deprecation Timeline
The `KuzuBackend` alias should be maintained for at least:
- 2-3 major versions
- 6-12 months
- Until usage analytics show minimal adoption

After deprecation period:
1. Add deprecation warning
2. Update migration guide
3. Remove alias in next major version

## Summary

All references to KuzuDB have been updated to Ladybug while maintaining backward compatibility. The codebase now consistently uses Ladybug terminology, making it clearer for contributors and users that LogThread uses LadybugDB as its embedded graph database backend.
