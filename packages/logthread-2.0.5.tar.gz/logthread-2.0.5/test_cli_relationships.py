#!/usr/bin/env python3
"""
Test script to verify LogThread CLI is properly extracting relationships
and providing complete end-to-end picture.
"""

import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

try:
    from logthread.core.storage.ladybug_backend import LadybugBackend
    from logthread.core.models import NodeType, RelationType
    
    print("✓ Successfully imported LogThread modules")
    
    # Open the database
    db_path = os.path.join(os.path.dirname(__file__), '.logthread', 'ladybug')
    print(f"\n📂 Opening database: {db_path}")
    
    backend = LadybugBackend(db_path)
    
    # Test 1: Get basic statistics
    print("\n" + "="*60)
    print("TEST 1: Database Statistics")
    print("="*60)
    
    # Count nodes by type
    node_types = {}
    for node_type in NodeType:
        try:
            query = f"MATCH (n:{node_type.value}) RETURN count(n) as count"
            result = backend.run_cypher(query)
            if result and len(result) > 0:
                count = result[0].get('count', 0)
                if count > 0:
                    node_types[node_type.value] = count
        except:
            pass
    
    print("\nNode counts by type:")
    for node_type, count in sorted(node_types.items(), key=lambda x: x[1], reverse=True):
        print(f"  {node_type:20s}: {count:5d}")
    
    total_nodes = sum(node_types.values())
    print(f"\n  {'TOTAL':20s}: {total_nodes:5d}")
    
    # Count relationships by type
    print("\n" + "="*60)
    print("TEST 2: Relationship Statistics")
    print("="*60)
    
    rel_types = {}
    for rel_type in RelationType:
        try:
            query = f"MATCH ()-[r:{rel_type.value}]->() RETURN count(r) as count"
            result = backend.run_cypher(query)
            if result and len(result) > 0:
                count = result[0].get('count', 0)
                if count > 0:
                    rel_types[rel_type.value] = count
        except:
            pass
    
    print("\nRelationship counts by type:")
    for rel_type, count in sorted(rel_types.items(), key=lambda x: x[1], reverse=True):
        print(f"  {rel_type:20s}: {count:5d}")
    
    total_rels = sum(rel_types.values())
    print(f"\n  {'TOTAL':20s}: {total_rels:5d}")
    
    # Test 3: Sample a function and its relationships
    print("\n" + "="*60)
    print("TEST 3: Sample Function Relationships")
    print("="*60)
    
    # Find a function with many relationships
    query = """
    MATCH (f:Function)-[r]-(n)
    WITH f, count(r) as rel_count
    WHERE rel_count > 5
    RETURN f.name as name, f.file_path as file, rel_count
    ORDER BY rel_count DESC
    LIMIT 1
    """
    result = backend.run_cypher(query)
    
    if result and len(result) > 0:
        sample = result[0]
        func_name = sample['name']
        func_file = sample['file']
        rel_count = sample['rel_count']
        
        print(f"\nSample function: {func_name}")
        print(f"File: {func_file}")
        print(f"Total relationships: {rel_count}")
        
        # Get detailed relationships
        query = f"""
        MATCH (f:Function {{name: "{func_name}"}})-[r]->(n)
        RETURN type(r) as rel_type, labels(n)[0] as target_type, n.name as target_name
        LIMIT 20
        """
        relationships = backend.run_cypher(query)
        
        print(f"\nOutgoing relationships (first 20):")
        for rel in relationships:
            print(f"  {func_name} --[{rel['rel_type']}]--> {rel['target_name']} ({rel['target_type']})")
        
        # Get incoming relationships
        query = f"""
        MATCH (n)-[r]->(f:Function {{name: "{func_name}"}})
        RETURN type(r) as rel_type, labels(n)[0] as source_type, n.name as source_name
        LIMIT 20
        """
        relationships = backend.run_cypher(query)
        
        print(f"\nIncoming relationships (first 20):")
        for rel in relationships:
            print(f"  {rel['source_name']} ({rel['source_type']}) --[{rel['rel_type']}]--> {func_name}")
    
    # Test 4: Check for entry points
    print("\n" + "="*60)
    print("TEST 4: Entry Points")
    print("="*60)
    
    # API endpoints
    query = """
    MATCH (n:ApiEndpoint)
    RETURN n.name as name, n.file_path as file
    LIMIT 10
    """
    result = backend.run_cypher(query)
    
    print(f"\nAPI Endpoints (first 10):")
    for ep in result:
        print(f"  {ep['name']} - {ep['file']}")
    
    # Main functions
    query = """
    MATCH (f:Function)
    WHERE f.name =~ '.*main.*' OR f.name IN ['main', 'run', 'start', 'init']
    RETURN f.name as name, f.file_path as file
    LIMIT 10
    """
    result = backend.run_cypher(query)
    
    print(f"\nMain functions (first 10):")
    for func in result:
        print(f"  {func['name']} - {func['file']}")
    
    # Test 5: Check for complete paths
    print("\n" + "="*60)
    print("TEST 5: End-to-End Path Example")
    print("="*60)
    
    # Find a path from an API endpoint to a database table
    query = """
    MATCH path = (api:ApiEndpoint)-[*1..5]->(table:DbTable)
    WITH path, length(path) as path_length
    ORDER BY path_length
    LIMIT 1
    RETURN [node in nodes(path) | {name: node.name, type: labels(node)[0]}] as nodes,
           [rel in relationships(path) | type(rel)] as rels
    """
    result = backend.run_cypher(query)
    
    if result and len(result) > 0:
        path = result[0]
        nodes = path['nodes']
        rels = path['rels']
        
        print(f"\nFound path from API endpoint to database table:")
        for i, node in enumerate(nodes):
            print(f"  {node['name']} ({node['type']})")
            if i < len(rels):
                print(f"    └─[{rels[i]}]→")
    else:
        print("\nNo direct path found from API endpoint to database table")
        print("Trying alternative path...")
        
        # Try finding any multi-hop path
        query = """
        MATCH path = (start)-[*2..4]->(end)
        WHERE (start:ApiEndpoint OR start:Function) 
        AND (end:DbTable OR end:Function)
        WITH path, length(path) as path_length
        ORDER BY path_length
        LIMIT 1
        RETURN [node in nodes(path) | {name: node.name, type: labels(node)[0]}] as nodes,
               [rel in relationships(path) | type(rel)] as rels
        """
        result = backend.run_cypher(query)
        
        if result and len(result) > 0:
            path = result[0]
            nodes = path['nodes']
            rels = path['rels']
            
            print(f"\nFound alternative path:")
            for i, node in enumerate(nodes):
                print(f"  {node['name']} ({node['type']})")
                if i < len(rels):
                    print(f"    └─[{rels[i]}]→")
    
    # Test 6: Verify relationship completeness
    print("\n" + "="*60)
    print("TEST 6: Relationship Completeness Check")
    print("="*60)
    
    # Check for orphaned nodes (nodes with no relationships)
    query = """
    MATCH (n)
    WHERE NOT (n)--()
    RETURN labels(n)[0] as type, count(n) as count
    """
    result = backend.run_cypher(query)
    
    print("\nOrphaned nodes (no relationships):")
    total_orphaned = 0
    for row in result:
        count = row['count']
        total_orphaned += count
        print(f"  {row['type']:20s}: {count:5d}")
    
    orphan_percentage = (total_orphaned / total_nodes * 100) if total_nodes > 0 else 0
    print(f"\nTotal orphaned: {total_orphaned} ({orphan_percentage:.1f}% of all nodes)")
    
    if orphan_percentage < 10:
        print("✓ Good: Most nodes have relationships")
    elif orphan_percentage < 30:
        print("⚠ Warning: Significant number of orphaned nodes")
    else:
        print("✗ Issue: Too many orphaned nodes - relationships may be incomplete")
    
    # Summary
    print("\n" + "="*60)
    print("SUMMARY")
    print("="*60)
    
    print(f"\n✓ Total nodes: {total_nodes}")
    print(f"✓ Total relationships: {total_rels}")
    print(f"✓ Average relationships per node: {total_rels / total_nodes:.1f}")
    print(f"✓ Orphaned nodes: {total_orphaned} ({orphan_percentage:.1f}%)")
    
    if total_rels > 0 and orphan_percentage < 20:
        print("\n✅ CLI is properly extracting relationships!")
        print("✅ Database contains comprehensive end-to-end picture")
    else:
        print("\n⚠️  Relationships may be incomplete")
        print("⚠️  Consider re-running analysis")
    
    backend.close()
    
except ImportError as e:
    print(f"✗ Import error: {e}")
    print("\nMissing dependencies. Please install:")
    print("  pip install real-ladybug")
    sys.exit(1)
except Exception as e:
    print(f"✗ Error: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
