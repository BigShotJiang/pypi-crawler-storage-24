# LogThread MCP Server Setup for Kiro

This guide explains how to configure the LogThread MCP server in Kiro to enable AI-powered code intelligence with graph context.

## Quick Setup

1. **Copy the configuration** from `kiro-mcp-config.json` to your Kiro MCP settings:
   ```bash
   cp kiro-mcp-config.json ~/.kiro/settings/mcp.json
   ```

2. **Restart Kiro** or reload the MCP servers from the command palette:
   - Open Command Palette (Cmd+Shift+P / Ctrl+Shift+P)
   - Search for "MCP: Reconnect Servers"

3. **Verify the server is running**:
   - Open the MCP Server view in Kiro's side panel
   - You should see "logthread" listed as a connected server

## Configuration Details

The LogThread MCP server provides the following tools:

### Core Tools (Auto-approved)
- `logthread_context` - Get 360° view of a symbol with callers, callees, and type refs
- `logthread_query` - Search for symbols using semantic/keyword search
- `logthread_cypher` - Run custom Cypher queries on the code graph
- `logthread_impact` - Analyze blast radius of changing a symbol
- `logthread_file_context` - Get all symbols in a file
- `logthread_call_path` - Find execution path between two symbols

### Analysis Tools (Auto-approved)
- `logthread_api_endpoints` - List all API endpoints in the codebase
- `logthread_dependencies` - Analyze file or library dependencies
- `logthread_communities` - Get code clusters/communities
- `logthread_dead_end` - Find unreachable code
- `logthread_coupling` - Detect change coupling between files
- `logthread_cycles` - Find circular dependencies

### Validation Tools (Auto-approved)
- `logthread_explain` - Get AI explanation of a symbol
- `logthread_validate_query` - Validate SQL queries against schema
- `logthread_validate_edit` - Validate code edits for safety
- `logthread_detect_changes` - Detect what changed in a diff
- `logthread_review_risk` - Assess risk of code changes
- `logthread_test_impact` - Find tests affected by changes

## Prerequisites

1. **LogThread CLI must be installed**:
   ```bash
   pip install logthread
   # or
   uv pip install logthread
   ```

2. **Workspace must be analyzed**:
   ```bash
   cd /path/to/your/project
   logthread generate
   ```

3. **Verify installation**:
   ```bash
   logthread --version
   logthread mcp --help
   ```

## How It Works

1. **MCP Server**: Kiro starts the LogThread MCP server using `logthread mcp` command
2. **Database**: The server reads from `.logthread/ladybug` database in your workspace
3. **Tools**: AI can call any of the LogThread tools to get code context
4. **Auto-approval**: Listed tools are auto-approved (no confirmation needed)

## Usage in Kiro

Once configured, the AI in Kiro can automatically use LogThread tools:

### Example 1: Understanding a Function
```
User: "Explain what the processPayment function does"

AI uses: logthread_context("processPayment")
→ Gets callers, callees, type refs, file location
→ Provides comprehensive explanation with full context
```

### Example 2: Impact Analysis
```
User: "What will break if I change the User class?"

AI uses: logthread_impact("User", depth=3)
→ Gets all affected symbols up to 3 hops away
→ Shows direct, indirect, and transitive impacts
```

### Example 3: Finding Execution Paths
```
User: "How does the API endpoint reach the database?"

AI uses: 
1. logthread_api_endpoints() → Find API endpoints
2. logthread_call_path("POST:/api/users", "users_table") → Trace path
→ Shows complete execution flow from API to DB
```

### Example 4: Code Search
```
User: "Find all authentication functions"

AI uses: logthread_query("authentication", limit=20)
→ Returns relevant symbols with semantic search
```

## Troubleshooting

### Server Not Connecting

1. **Check if LogThread is installed**:
   ```bash
   which logthread
   logthread --version
   ```

2. **Check if workspace is analyzed**:
   ```bash
   ls -la .logthread/
   # Should see: ladybug, meta.json
   ```

3. **Test MCP server manually**:
   ```bash
   logthread mcp
   # Should start and wait for input (Ctrl+C to exit)
   ```

4. **Check Kiro logs**:
   - Open Output panel in Kiro
   - Select "MCP Servers" from dropdown
   - Look for connection errors

### Database Locked Error

If you see "database is locked" errors:

1. **Close other LogThread processes**:
   ```bash
   ps aux | grep logthread
   kill <pid>
   ```

2. **Restart the MCP server** from Kiro's MCP Server view

3. **The server uses connection leasing** to auto-release locks after 3s of idle

### No Data / Empty Results

1. **Re-analyze the workspace**:
   ```bash
   logthread generate
   ```

2. **Check database statistics**:
   ```bash
   python3 test_relationships_simple.py
   ```

3. **Verify relationships are extracted** (should see 3+ avg relationships per symbol)

## Advanced Configuration

### Custom Environment Variables

Add environment variables to the MCP config:

```json
{
  "mcpServers": {
    "logthread": {
      "command": "logthread",
      "args": ["mcp"],
      "env": {
        "LOGTHREAD_LOG_LEVEL": "DEBUG",
        "LOGTHREAD_MAX_DEPTH": "5"
      },
      "disabled": false,
      "autoApprove": [...]
    }
  }
}
```

### Workspace-Specific Configuration

Create `.kiro/settings/mcp.json` in your workspace for project-specific settings:

```json
{
  "mcpServers": {
    "logthread": {
      "command": "logthread",
      "args": ["mcp"],
      "env": {
        "LOGTHREAD_DB_PATH": "/custom/path/to/.logthread/ladybug"
      },
      "disabled": false,
      "autoApprove": [...]
    }
  }
}
```

### Disable Auto-Approval

Remove tools from `autoApprove` array to require manual confirmation:

```json
{
  "mcpServers": {
    "logthread": {
      "command": "logthread",
      "args": ["mcp"],
      "env": {},
      "disabled": false,
      "autoApprove": [
        "logthread_context",
        "logthread_query"
      ]
    }
  }
}
```

## Integration with Enhanced Graph Methods

The MCP server works seamlessly with the enhanced TypeScript methods:

1. **`getComprehensiveGraph()`** - Uses `logthread_context` + `logthread_cypher` to build complete graphs
2. **`getExecutionPath()`** - Uses `logthread_api_endpoints` + `logthread_call_path` to trace flows
3. **`getContextForPosition()`** - Uses `logthread_file_context` + `logthread_context` for deep context

These methods automatically call the MCP tools to fetch comprehensive relationship data.

## Benefits

✅ **Complete Context**: AI gets full code graph context for better suggestions
✅ **Impact Analysis**: Understand blast radius before making changes
✅ **Code Navigation**: Trace execution paths through the codebase
✅ **Semantic Search**: Find relevant code using natural language
✅ **Validation**: Validate SQL queries and code edits before applying
✅ **Dead Code Detection**: Identify unreachable code
✅ **Dependency Analysis**: Understand module and library dependencies

## Next Steps

1. Copy the configuration to `~/.kiro/settings/mcp.json`
2. Restart Kiro
3. Analyze your workspace: `logthread generate`
4. Try asking the AI: "Show me the call graph for the main function"

The AI will automatically use LogThread tools to provide comprehensive answers with full code context!
