# Double-Click Modal Feature

## Overview
Implemented double-click functionality on graph nodes to open the DetailPanel (Context, Impact, Code, Processes, AI tabs) in a full-screen modal dialog.

## Changes Made

### 1. View Store Updates (`src/logthread/web/frontend/src/stores/viewStore.ts`)
- Added `detailModalOpen: boolean` state
- Added `setDetailModalOpen(open: boolean)` action
- Added `toggleDetailModal()` action
- Modal state is managed globally through Zustand store

### 2. DetailPanel Component (`src/logthread/web/frontend/src/components/detail/DetailPanel.tsx`)
- Removed local `useState` for modal state
- Now uses `useViewStore` for `detailModalOpen` state
- Modal can be opened via:
  - Maximize button in sidebar (existing)
  - Double-click on graph nodes (new)
- Modal displays at 90vw x 90vh with dark overlay
- All 5 tabs available in modal: Context, Impact, Code, Processes, AI

### 3. GraphCanvas Component (`src/logthread/web/frontend/src/components/graph/GraphCanvas.tsx`)
- Added double-click detection logic in `onMouseUp` handler
- Tracks last clicked node and timestamp
- Double-click threshold: 300ms
- On double-click:
  - Opens DetailPanel modal via `useViewStore.getState().setDetailModalOpen(true)`
  - Node remains selected
- Single click behavior unchanged (selects node)

### 4. Double-Click Implementation Details
```typescript
// Variables for double-click detection
let lastClickTime = 0;
let lastClickedNode: string | null = null;
const DOUBLE_CLICK_THRESHOLD = 300; // ms

// In onMouseUp handler
if (draggedNode) {
  if (dx < DRAG_THRESHOLD && dy < DRAG_THRESHOLD) {
    const now = Date.now();
    // Check for double-click
    if (lastClickedNode === draggedNode && (now - lastClickTime) < DOUBLE_CLICK_THRESHOLD) {
      // Double-click detected - open modal
      useViewStore.getState().setDetailModalOpen(true);
      lastClickTime = 0;
      lastClickedNode = null;
    } else {
      // Single click - select and unpin
      selectNode(draggedNode);
      lastClickTime = now;
      lastClickedNode = draggedNode;
    }
    graph.removeNodeAttribute(draggedNode, 'fixed');
  }
}
```

## User Experience

### Single Click on Node
- Selects the node
- Shows details in right sidebar
- Node is unpinned after selection

### Double Click on Node
- Opens full-screen modal with node details
- Modal shows all 5 tabs: Context, Impact, Code, Processes, AI
- Better for detailed analysis with more screen space
- Click outside modal or X button to close
- "Show in Sidebar" button to return to sidebar view

### Click on Background
- Deselects current node
- Clears highlights
- Resets double-click tracking

## Benefits
1. **Better UX**: Users can quickly expand to full-screen view for detailed analysis
2. **More Screen Space**: Modal provides 90% of viewport for content
3. **Intuitive**: Double-click is a natural gesture for "open" or "expand"
4. **Flexible**: Users can choose between sidebar or modal view
5. **Consistent**: Same content in both views, just different layouts

## Files Modified
- `src/logthread/web/frontend/src/stores/viewStore.ts`
- `src/logthread/web/frontend/src/components/detail/DetailPanel.tsx`
- `src/logthread/web/frontend/src/components/graph/GraphCanvas.tsx`

## Build Status
✅ Frontend built successfully with all changes applied
