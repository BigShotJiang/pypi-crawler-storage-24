# Command Rename Summary

## Overview
This document summarizes the command name changes made to LogThread CLI for better clarity and consistency.

## Command Changes

### 1. `analyze` → `generate`
**Rationale:** The command generates/builds a knowledge graph index of the codebase, making "generate" more descriptive of what it does.

**Old command:**
```bash
logthread analyze .
```

**New command:**
```bash
logthread generate .
```

### 2. `dead-code` → `dead-end`
**Rationale:** More intuitive naming that better describes unreachable code paths.

**Old command:**
```bash
logthread dead-code
```

**New command:**
```bash
logthread dead-end
```

### 3. New Command: `analyze-diff`
**Purpose:** Analyze git diff and show affected symbols in the knowledge graph.

**Usage:**
```bash
# Compare current branch against main
logthread analyze-diff

# Analyze only unstaged changes
logthread analyze-diff --unstaged

# Analyze staged changes
logthread analyze-diff --staged

# Compare against a different branch
logthread analyze-diff --target develop

# Include downstream impact analysis
logthread analyze-diff --impact --depth 5
```

**Features:**
- Requires git repository
- Compares changes against target branch (default: main)
- Shows which symbols are affected by changes
- Optional impact analysis showing downstream effects
- Supports staged, unstaged, and branch comparison modes

## Files Updated

### CLI Implementation
- `src/logthread/cli/main.py` - Command definitions and help text

### Documentation
- `README.md` - Quick start, CLI reference, examples
- `CONTRIBUTING.md` - Language parser verification command
- `DEPLOYMENT.md` - Usage instructions
- `OPENSOURCE_PREP_SUMMARY.md` - Core functionality examples
- `MCP_SETUP_SUMMARY.md` - Setup instructions
- `KIRO_MCP_SETUP.md` - Kiro integration guide
- `SQL_PARSER_EXTENSION_SUPPORT.md` - Command reference
- `WEB_UI_ENHANCEMENT_PLAN.md` - API endpoint naming

## Internal References (Unchanged)

The following internal references remain unchanged as they are implementation details:
- Database field names: `dead_code` count in stats
- Python function names: `handle_dead_code()` in MCP tools
- API endpoints: `/api/analysis/dead-code` (internal)
- Variable names: `result.dead_code`, `stats['dead_code']`

## Migration Guide for Users

### For CLI Users
Replace old commands with new ones:
```bash
# Old → New
logthread analyze .      → logthread generate .
logthread dead-code      → logthread dead-end
```

### For MCP Server Users
No changes required. The MCP server tools remain the same:
- `logthread_dead_code` (MCP tool name unchanged)
- All other MCP tools unchanged

### For API Users
No breaking changes. Internal API endpoints maintain backward compatibility.

## Testing Recommendations

1. Test basic indexing:
   ```bash
   logthread generate .
   ```

2. Test dead code detection:
   ```bash
   logthread dead-end
   ```

3. Test new git diff analysis:
   ```bash
   logthread analyze-diff
   logthread analyze-diff --unstaged
   logthread analyze-diff --staged
   logthread analyze-diff --impact
   ```

4. Verify MCP server still works:
   ```bash
   logthread serve --watch
   ```

## Backward Compatibility

The old command names are NOT aliased for backward compatibility. Users must update their scripts and workflows to use the new command names.

This is acceptable for an open-source release as it's a clean break from any previous versions.
