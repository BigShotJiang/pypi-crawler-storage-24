# Sidebar Fixes - Theme Support & Layout

## Issues Fixed

### 1. Theme Switching Not Working
**Problem**: Sidebar was using Tailwind classes like `bg-bg-surface` instead of CSS custom properties, preventing theme switching.

**Solution**: Replaced all Tailwind color classes with inline styles using CSS custom properties:
- `bg-bg-surface` → `style={{ backgroundColor: 'var(--bg-surface)' }}`
- `text-text-secondary` → `style={{ color: 'var(--text-secondary)' }}`
- `border-border` → `style={{ borderColor: 'var(--border)' }}`

This ensures colors update dynamically when the theme changes.

### 2. Font Not Using Design System
**Problem**: Font styles were inconsistent with the design system.

**Solution**: 
- Added `font-medium text-sm` classes to navigation buttons
- Removed hardcoded font weights
- System now uses the font family defined in `index.css`: `-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Noto Sans', Helvetica, Arial, sans-serif`

### 3. Gap Between Sidebar and Explorer
**Problem**: Sidebar was positioned relatively, causing layout issues with the main content area.

**Solution**:
- Changed sidebar to `position: fixed` with `top-14` (below header)
- Added `z-10` for proper layering
- Updated main content margin from `60px/240px` to `64px/240px` to match sidebar width
- Sidebar now properly positioned: `fixed left-0 top-14 bottom-0`

### 4. Hover States Not Working
**Problem**: Hover states weren't applying correctly with Tailwind classes.

**Solution**: Added inline event handlers for hover states:
```tsx
onMouseEnter={(e) => {
  e.currentTarget.style.backgroundColor = 'var(--bg-hover)';
  e.currentTarget.style.color = 'var(--text-primary)';
}}
onMouseLeave={(e) => {
  e.currentTarget.style.backgroundColor = 'transparent';
  e.currentTarget.style.color = 'var(--text-secondary)';
}}
```

## Changes Made

### Files Modified

#### `src/logthread/web/frontend/src/components/layout/Sidebar.tsx`
- Changed positioning from relative to fixed
- Replaced all Tailwind color classes with CSS custom properties
- Added proper hover state handlers
- Updated width from `w-64` to `w-60` for better proportions
- Simplified header to just show collapse toggle
- Added proper font styling

#### `src/logthread/web/frontend/src/App.tsx`
- Updated main content margin to `64px/240px` (collapsed/expanded)
- Added `background: var(--bg-primary)` to root div for theme support
- Added `relative` positioning to flex container

## Theme Integration

The sidebar now properly responds to theme changes:

### Dark Theme (default)
- Background: `#161b22`
- Text: `#e6edf3` (primary), `#8b949e` (secondary)
- Borders: `#30363d`
- Active state: `#2d333b` with `#58a6ff` accent

### Light Theme
- Background: `#ffffff`
- Text: `#1f2328` (primary), `#656d76` (secondary)
- Borders: `#d0d7de`
- Active state: `#f6f8fa` with `#0969da` accent

## Layout Structure

```
┌─────────────────────────────────────────┐
│           Header (fixed, h-14)          │
├──────────┬──────────────────────────────┤
│          │                              │
│ Sidebar  │      Main Content            │
│ (fixed)  │      (margin-left: 64/240px) │
│ w-16/60  │                              │
│          │                              │
│          │                              │
└──────────┴──────────────────────────────┘
```

## Testing

Build completed successfully:
- ✓ TypeScript compilation passed
- ✓ Vite build completed
- ✓ No errors or warnings
- ✓ Bundle size: ~631KB (main chunk)

## Next Steps

To test the fixes:
1. Run `logthread web` to start the web UI
2. Click the theme toggle in the header (sun/moon icon)
3. Verify sidebar colors change with theme
4. Test sidebar collapse/expand functionality
5. Check that there's no gap between sidebar and explorer
6. Verify hover states work on navigation items
