# Project Switcher Feature

## Overview
Implemented a comprehensive project/repository switcher in the top bar that displays all indexed repositories from the centralized `~/.logthread/` storage and allows users to easily view and switch between different projects.

## Features

### 1. Project Switcher Component
- **Dropdown Interface**: Clean dropdown in the header showing current project
- **Project List**: Displays all indexed projects with metadata
- **Visual Indicators**: 
  - Current project highlighted with "CURRENT" badge
  - Projects without indexes show "NO INDEX" warning
  - Git folder icon for visual identification

### 2. Project Information Display
For each project, shows:
- **Project Name**: Display name of the repository
- **Full Path**: Complete file system path
- **Statistics**: 
  - Number of symbols indexed
  - Number of files analyzed
  - Last updated timestamp (with relative time: "2h ago", "3d ago", etc.)
- **Status**: Whether it's the current project and if it has a valid index

### 3. Smart Sorting
- Projects sorted by last updated time (most recent first)
- Current project always visible at top when selected
- Easy to find recently worked-on projects

### 4. Refresh Capability
- Manual refresh button to reload project list
- Automatically loads on component mount
- Shows loading spinner during refresh

## Implementation Details

### Backend Changes

#### New Module: `src/logthread/web/routes/projects.py`
```python
@router.get("/projects")
def list_projects(request: Request) -> dict
    # Lists all indexed projects from global registry
    # Returns project metadata with current status
    # Checks for valid indexes
```

Features:
- Reads from global registry at `~/.logthread/registry.json`
- Validates index existence for each project
- Loads fresh metadata from project meta files
- Marks current project based on server's repo_path

#### Updated: `src/logthread/web/app.py`
- Registered `projects_router` with `/api` prefix
- Projects endpoint available at `/api/projects`

### Frontend Changes

#### New Component: `src/logthread/web/frontend/src/components/shared/ProjectSwitcher.tsx`
Features:
- Dropdown UI with project list
- Automatic loading on mount
- Manual refresh capability
- Relative time formatting ("2h ago", "3d ago")
- Click handling with switch instructions
- Loading and error states
- Responsive design with proper z-indexing

#### Updated: `src/logthread/web/frontend/src/components/layout/Header.tsx`
- Added ProjectSwitcher between logo and stats
- Integrated seamlessly with existing header layout

#### Updated: `src/logthread/web/frontend/src/api/client.ts`
```typescript
projectsApi.list() // New endpoint to fetch all projects
```

## User Experience

### Viewing Projects
1. Click the project dropdown in the header (shows current project name)
2. See list of all indexed projects with their details
3. Current project is highlighted
4. Projects without indexes are marked with warning

### Switching Projects
When clicking a non-current project:
1. Alert shows with instructions:
   ```
   To switch to "project-name", restart the server:
   
   cd /path/to/project
   logthread host
   ```
2. User restarts server from desired project directory
3. UI automatically reflects new current project

### Refresh Projects
- Click refresh icon in dropdown header
- Reloads project list from server
- Updates all metadata and status

## Storage Structure

Projects are stored in centralized location:
```
~/.logthread/
├── registry.json          # Global list of all indexed projects
└── projects/
    ├── project1_abc123/
    │   ├── meta.json      # Project metadata
    │   └── ladybug/       # Graph database
    └── project2_def456/
        ├── meta.json
        └── ladybug/
```

### Registry Format
```json
{
  "version": 1,
  "projects": [
    {
      "id": "myproject_abc123",
      "name": "My Project",
      "path": "/Users/user/projects/myproject",
      "symbols": 1234,
      "files": 56,
      "updated_at": "2026-03-26T10:30:00"
    }
  ]
}
```

## Benefits

1. **Multi-Project Workflow**: Easy visibility into all indexed projects
2. **Quick Context**: See project stats without switching
3. **Centralized Management**: All projects in one place (`~/.logthread/`)
4. **Clean Project Directories**: No `.logthread/` folders in project roots
5. **Status Awareness**: Know which projects have valid indexes
6. **Recent Activity**: See when projects were last updated

## Technical Notes

- Project list loaded on-demand (not on every page load)
- Registry automatically updated when projects are indexed
- Project IDs are stable hashes of repository paths
- Supports multiple projects with same name (different paths)
- Graceful handling of missing or corrupted indexes
- Relative time formatting for better UX

## Future Enhancements

Potential improvements:
- **Hot Switching**: Switch projects without server restart (load different database)
- **Project Search**: Filter projects by name or path
- **Project Groups**: Organize projects into workspaces
- **Recent Projects**: Quick access to recently used projects
- **Project Actions**: Reindex, delete, or export from dropdown
- **Project Icons**: Custom icons or colors for projects
- **Keyboard Shortcuts**: Quick project switching with hotkeys

## Files Modified

### Backend
- `src/logthread/web/routes/projects.py` (new)
- `src/logthread/web/app.py`

### Frontend
- `src/logthread/web/frontend/src/components/shared/ProjectSwitcher.tsx` (new)
- `src/logthread/web/frontend/src/components/layout/Header.tsx`
- `src/logthread/web/frontend/src/api/client.ts`

## Related Features

This feature complements:
- **Smart Git Repository Discovery**: Find and select repos for Branch Diff
- **Centralized Storage**: All data in `~/.logthread/` instead of project directories
- **Global Registry**: Single source of truth for all indexed projects
