# Git Diff Analysis Feature

## Overview

LogThread's git diff analysis feature provides comprehensive impact assessment of code changes by mapping git diffs to your knowledge graph. This helps you understand the full scope of your changes before committing or merging.

## Command: `logthread analyze-diff`

### Basic Usage

```bash
# Analyze changes in current branch vs main
logthread analyze-diff

# Analyze unstaged changes only
logthread analyze-diff --unstaged

# Analyze staged changes only
logthread analyze-diff --staged

# Compare against a different branch
logthread analyze-diff --target develop
```

### Advanced Analysis

```bash
# Include downstream impact analysis
logthread analyze-diff --impact

# Deeper impact analysis (up to 10 levels)
logthread analyze-diff --impact --depth 5

# Show affected test files
logthread analyze-diff --tests

# Show file coupling patterns
logthread analyze-diff --coupling

# Comprehensive analysis (all features)
logthread analyze-diff --full
```

## Features

### 1. Basic Symbol Detection

Shows which symbols (functions, classes, methods) are affected by your changes:

```
Git Diff Analysis
==================================================
Changed files: 3
Total additions: +45 lines
Total deletions: -12 lines

  src/api/users.py (+23 -5):
    - get_user (Function) lines 45-67
    - update_user (Function) lines 89-112

  src/models/user.py (+15 -4):
    - User (Class) lines 12-89
    - validate_email (Method) lines 34-42

  src/tests/test_users.py (+7 -3):
    - test_get_user (Function) lines 15-28

==================================================
Total affected symbols: 5

Breakdown by type:
  - Function: 3
  - Class: 1
  - Method: 1
```

### 2. Impact Analysis (`--impact`)

Provides comprehensive downstream impact assessment with risk scoring:

```
Comprehensive Diff Impact Analysis
============================================================
Analysis depth: 3 levels
Changed files: 3
Code changes: +45 -12 lines
Modified symbols: 5

Risk Assessment: 🟡 MEDIUM (Score: 52/100)

Risk factors:
  • Wide downstream impact (15 symbols)
  • Affects 2 API endpoint(s)
  • Affects 1 database table(s)

============================================================

⚠️  Impacted API Endpoints (2):
  • GET /api/users/{id}
  • PUT /api/users/{id}

🗄️  Impacted Database Tables (1):
  • users

📦 Impacted Classes/Components (8):
  • UserController
  • UserService
  • AuthMiddleware
  • UserRepository
  ... and 4 more

🔗 Total Downstream Symbols: 15

============================================================
📋 Recommendations:

  🟡 MEDIUM RISK - Standard precautions:
    • Code review recommended
    • Run relevant test suites
    • Monitor after deployment

💡 Next steps:
  • Run: test_impact() to identify affected tests
  • Run: coupling() on changed files to check co-change patterns
  • Run: validate_edit() after making changes
```

### 3. Risk Scoring

The risk score (0-100) is calculated based on:

- **Changed symbols (0-30 points)**: More changed symbols = higher risk
- **Downstream impact (0-40 points)**: More affected downstream symbols = higher risk
- **Critical systems (0-30 points)**: Affecting APIs or databases increases risk

**Risk Levels:**
- 🟢 **LOW (0-39)**: Safe to merge with basic review
- 🟡 **MEDIUM (40-69)**: Requires standard precautions
- 🔴 **HIGH (70-100)**: Proceed with caution, thorough review needed

### 4. Test Impact Analysis (`--tests`)

Identifies which test files should be run based on your changes:

```
Analyzing test impact...

Test Impact Analysis
==================================================
Tests likely affected by changes:

  src/tests/test_users.py
    - test_get_user
    - test_update_user
    - test_user_validation

  src/tests/integration/test_user_api.py
    - test_user_endpoints
    - test_user_authentication

Total test files: 2
Total test functions: 5

Recommendation: Run these tests before committing
```

### 5. File Coupling Analysis (`--coupling`)

Shows files that are frequently changed together (temporal coupling):

```
Analyzing file coupling patterns...

File Coupling for: src/api/users.py
==================================================
Files frequently changed together:

  src/models/user.py (coupling: 0.85)
    - Changed together in 17 of 20 commits
    - Strong coupling detected

  src/services/user_service.py (coupling: 0.65)
    - Changed together in 13 of 20 commits
    - Moderate coupling

  src/tests/test_users.py (coupling: 0.45)
    - Changed together in 9 of 20 commits

⚠️  Warning: High coupling with src/models/user.py
Consider reviewing that file even if not in this diff.
```

### 6. Comprehensive Analysis (`--full`)

Combines all analyses into a single comprehensive report:
- Symbol detection
- Impact analysis with risk scoring
- Test impact
- File coupling patterns

## Use Cases

### Pre-Commit Review

```bash
# Before committing, check what you're changing
logthread analyze-diff --unstaged --full
```

### Pull Request Assessment

```bash
# Assess PR risk before requesting review
logthread analyze-diff --target main --impact
```

### Pre-Merge Validation

```bash
# Before merging, understand full impact
logthread analyze-diff --target main --full
```

### Test Planning

```bash
# Identify which tests to run
logthread analyze-diff --tests
```

### Code Review Preparation

```bash
# Get comprehensive analysis for review
logthread analyze-diff --full > review-notes.txt
```

## Integration with CI/CD

### GitHub Actions Example

```yaml
name: Impact Analysis

on: [pull_request]

jobs:
  analyze:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
        with:
          fetch-depth: 0  # Need full history for analysis
      
      - name: Install LogThread
        run: pip install logthread
      
      - name: Generate knowledge graph
        run: logthread generate .
      
      - name: Analyze PR impact
        run: |
          logthread analyze-diff --target ${{ github.base_ref }} --full > impact-report.txt
          cat impact-report.txt
      
      - name: Comment on PR
        uses: actions/github-script@v6
        with:
          script: |
            const fs = require('fs');
            const report = fs.readFileSync('impact-report.txt', 'utf8');
            github.rest.issues.createComment({
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: '## Impact Analysis\n\n```\n' + report + '\n```'
            });
```

### GitLab CI Example

```yaml
impact-analysis:
  stage: test
  script:
    - pip install logthread
    - logthread generate .
    - logthread analyze-diff --target $CI_MERGE_REQUEST_TARGET_BRANCH_NAME --full
  only:
    - merge_requests
```

## Requirements

- Git repository (command checks for `.git` directory)
- Indexed codebase (`logthread generate .` must be run first)
- Valid git branches for comparison

## Limitations

- Only analyzes indexed symbols (run `logthread generate .` to update index)
- Requires git history for coupling analysis
- Impact depth limited to 10 levels (configurable with `--depth`)
- File coupling requires at least 5 commits of history

## Tips

1. **Run after indexing**: Always run `logthread generate .` before analyzing diffs to ensure up-to-date results

2. **Use appropriate depth**: Higher depth (5-10) gives more complete impact but takes longer

3. **Check coupling regularly**: File coupling patterns help identify architectural issues

4. **Automate in CI**: Add to your CI pipeline for automatic PR risk assessment

5. **Combine with other tools**: Use alongside `logthread diff` for structural comparison

## Related Commands

- `logthread generate .` - Index your codebase
- `logthread diff main..feature` - Structural branch comparison
- `logthread impact <symbol>` - Analyze impact of specific symbol
- `logthread dead-end` - Find unreachable code

## Troubleshooting

### "Not a git repository"
Ensure you're in a git repository with a `.git` directory.

### "No index found"
Run `logthread generate .` first to create the knowledge graph.

### "Target branch does not exist"
Verify the branch name with `git branch -a`.

### "No differences found"
Your working directory matches the target branch. Make some changes or check a different branch.

### Empty or incomplete results
Re-index your codebase: `logthread generate .`

## Examples

### Example 1: Quick Pre-Commit Check

```bash
$ logthread analyze-diff --unstaged

Git Diff Analysis
==================================================
Changed files: 1
Total additions: +5 lines
Total deletions: -2 lines

  src/utils/helpers.py (+5 -2):
    - format_date (Function) lines 23-35

==================================================
Total affected symbols: 1

Breakdown by type:
  - Function: 1

💡 Next steps:
  • Use impact() to see downstream effects
  • Use test_impact() to find affected tests
```

### Example 2: High-Risk Change Detection

```bash
$ logthread analyze-diff --impact

Comprehensive Diff Impact Analysis
============================================================
Analysis depth: 3 levels
Changed files: 5
Code changes: +234 -89 lines
Modified symbols: 12

Risk Assessment: 🔴 HIGH (Score: 78/100)

Risk factors:
  • High number of changed symbols (12)
  • Wide downstream impact (45 symbols)
  • Affects 8 API endpoint(s)
  • Affects 3 database table(s)

============================================================
📋 Recommendations:

  🔴 HIGH RISK - Proceed with caution:
    • Require thorough code review
    • Run comprehensive test suite
    • Consider breaking into smaller changes
    • Deploy with rollback plan ready
```

## Best Practices

1. **Analyze before committing**: Catch issues early
2. **Use `--full` for PRs**: Get comprehensive view before requesting review
3. **Monitor risk scores**: High scores indicate need for extra caution
4. **Check coupling**: Identify files that should be reviewed together
5. **Run affected tests**: Use `--tests` to identify test coverage gaps
6. **Automate in CI**: Make impact analysis part of your workflow
7. **Keep index updated**: Re-run `logthread generate .` after major changes

## Future Enhancements

Planned features for future releases:
- Community boundary crossing detection
- Automatic test selection and execution
- Integration with code review tools
- Historical risk trend analysis
- ML-based risk prediction
- Automatic rollback recommendations
