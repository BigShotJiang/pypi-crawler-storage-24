# Contributing to LogThread

Thanks for your interest in contributing. This guide will save you time.

---

## The Golden Rule

**Open an issue before writing code.**

PRs without a linked, approved issue will be closed immediately — no exceptions.

### Why?

We've had contributors spend days building features we didn't want, or submit 13 PRs in a row without ever discussing their approach. The issue step takes 5 minutes and prevents wasted effort on both sides.

### The Workflow

```
1. Open an issue          →  Describe the problem and your proposed solution
2. Discussion             →  Maintainer reviews and may suggest changes
3. Issue gets `approved`  →  Green light to write code
4. Open a PR              →  Link the issue with "Closes #123"
5. Review & iterate       →  Address feedback
6. Merge                  →  🎉
```

**Exception:** Typo fixes, broken links, and doc corrections under 5 lines don't need an issue.

---

## What We Want

- Bug fixes with clear reproduction steps
- Performance improvements with benchmarks
- New language parser support (discuss scope first)
- Test coverage for edge cases
- Documentation that fixes actual confusion

## What Gets Closed Without Review

- PRs without a linked approved issue
- PRs bundling unrelated changes
- Stacked PR chains (open one PR, not thirteen)
- PRs adding project config files (.cursorrules, CLAUDE.md, etc.)
- Bulk AI-generated submissions from new contributors
- PRs where the author can't explain their changes

---

## Development Setup

```bash
git clone https://github.com/logthread/logthread.git
cd logthread
pip install -e ".[dev]"

# Run tests
pytest

# Lint
ruff check src/ tests/
ruff format src/ tests/
```

Requires Python 3.11+ and is intended to support Python 3.14 as well.

---

## PR Requirements

### 1. One logical change per PR
Don't mix a bug fix with a feature with test refactoring. Keep it focused.

### 2. Tests are mandatory
- Bug fixes need regression tests
- New features need coverage
- Run the full suite: `pytest --tb=short`

### 3. Pass linting
```bash
ruff check src/ tests/ --fix
ruff format src/ tests/
```

### 4. Write a real description
Use the PR template. Explain what changed and why. Link the issue.

### 5. Keep diffs clean
- Don't reformat files you didn't change
- Don't add docstrings to unrelated functions
- Don't rename variables in code you didn't touch

---

## On AI-Assisted Contributions

We don't ban AI tools, but we hold AI-assisted PRs to a higher standard.

- You must understand every line. We will ask questions.
- "Claude wrote it" is not an answer to "why this approach?"
- Clean up AI-generated commit messages
- Bulk-generating PRs without prior engagement is noise, not contribution

---

## Code Style

- Follow existing patterns (if parsers use `_extract_*`, yours should too)
- No premature abstractions (three similar lines > a helper function)
- Type hints on public APIs, skip them on obvious locals
- Comments only where logic isn't self-evident

---

## Adding a Language Parser

Common contribution. Expected process:

1. **Open an issue** with language name and scope (what constructs you'll extract)
2. Create `src/logthread/core/ingestion/languages/<lang>.py` following `python.py` or `typescript.py`
3. Register in `src/logthread/core/ingestion/languages/__init__.py`
4. Add tree-sitter grammar to `pyproject.toml`
5. Write tests in `tests/core/test_parser_<lang>.py`
6. Verify: `logthread analyze <test-repo>` should index the new language

---

## Commit Messages

```
<type>: <short description>

<optional body explaining why>
```

**Types:** `fix`, `feat`, `test`, `refactor`, `docs`, `chore`

Keep subject under 72 characters. Explain the "why" in the body.

---

## Review Process

- Maintainers review within a few days
- Expect questions and change requests (this is normal)
- PRs with no response for 2 weeks may be closed
- Engage with feedback — abandoned PRs get closed

---

## License

By contributing, you agree your contributions are licensed under the MIT License.
