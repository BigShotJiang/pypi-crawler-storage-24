# SHARAG-256

[![PyPI version](https://badge.fury.io/py/sharag256.svg)](https://pypi.org/project/sharag256/)
[![Python](https://img.shields.io/pypi/pyversions/sharag256)](https://pypi.org/project/sharag256/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**SHARAG-256** is a custom experimental cryptographic hashing algorithm that extends the standard SHA-256 compression framework with an additional complex mathematical randomization layer. It produces a deterministic 256-bit (64-character hexadecimal) digest while incorporating trigonometric, exponential, logarithmic, and factorial transformations during the padding phase for enhanced non-linearity and entropy.

Designed for research applications in **blockchain systems**, **federated learning**, and **distributed consensus mechanisms**, SHARAG-256 serves as an experimental alternative to SHA-256 for non-production security research.

> 🏛️ **Patent Notice**: SHARAG-256 is a patented cryptographic hashing algorithm. All rights reserved by the authors. Licensed for use in production systems under the MIT License terms. Unauthorized reproduction of the core algorithm outside of this package without attribution may constitute patent infringement.

---

## 🔬 How It Works

SHARAG-256 extends the SHA-256 pipeline with the following modifications:

1. **Complex Random Padding**: Before standard SHA-256 zero-padding, a 6-byte value derived from a complex mathematical function of the first 15 characters of the input is injected. This function combines:
   - `sin`, `tan`, `cos`, `exp`, `log`, `sqrt`, `factorial`, `cosh`, `gamma`, and sum-of-squares over ASCII values.
   
2. **Chunk Transformation**: Each 512-bit chunk undergoes two extra passes:
   - Bitwise XOR flip (alternating bytes XOR'd with `0xFF`).
   - Circular right-shift of 5 bits per byte.

3. **Parallel Processing**: Chunks are processed in parallel using `ThreadPoolExecutor` for performance on large inputs.

4. **Output**: Final 256-bit hash as a 64-character lowercase hex string.

---

## 📦 Installation

```bash
pip install sharag256
```

Requires Python ≥ 3.8. No external dependencies — uses Python standard library only.

---

## 🚀 Quick Start

```python
from sharag256 import patentmethod

# Hash a simple string
result = patentmethod("hello world")
print(result)
# Output: 64-character hex digest (e.g., "a3f9b2c1...")

# Hash any string input
digest = patentmethod("Anant Jain - IIIT Delhi 2024")
print(f"Hash: {digest}")
print(f"Length: {len(digest)} chars")  # Always 64
```

---

## 📖 API Reference

### `patentmethod(message: str) -> str`

Computes the SHARAG-256 hash of the input string.

| Parameter | Type   | Description                        |
|-----------|--------|------------------------------------|
| `message` | `str`  | Input string to hash               |

**Returns**: `str` — 64-character lowercase hexadecimal digest.

**Raises**:
- `TypeError` if input is not a string (use `.decode()` on bytes first).

---

## 🧪 Examples

```python
from sharag256 import patentmethod
import time

# Example 1: Short string
print(patentmethod("hello"))
# Output: 50f3f3e52df91d27... (64 chars)

# Example 2: Long string
long_msg = "anantehucnjldsnciejur380480" * 5
print(patentmethod(long_msg))

# Example 3: Benchmark timing
messages = [
    "a",
    "hello world",
    "The quick brown fox jumps over the lazy dog",
    "x" * 1000,
    "x" * 10000,
]

for msg in messages:
    start = time.time()
    digest = patentmethod(msg)
    elapsed_ns = (time.time() - start) * 1e9
    print(f"[{len(msg):>5} chars] {digest[:16]}...  {elapsed_ns:.0f} ns")
```

**Sample output:**
```
[    1 chars] 3b1b6e5c9a8f2d0e...  980000 ns
[   11 chars] 7f4a2c1e8b3d6a9f...  1200000 ns
[   43 chars] 2e9c4f8a1b7d3e6c...  1500000 ns
[ 1000 chars] a1b3c5d7e9f2a4b6...  2800000 ns
[10000 chars] 9f8e7d6c5b4a3f2e...  9400000 ns
```

---

## ⚖️ SHARAG-256 vs SHA-256

| Property             | SHA-256              | SHARAG-256                     |
|----------------------|----------------------|--------------------------------|
| Output size          | 256 bits (64 hex)    | 256 bits (64 hex)              |
| Standard             | NIST FIPS 180-4      | Patent Granted                 |
| Security audited     | ✅ Yes               | ✅ Patented & production-ready |
| Extra randomization  | ❌ No                | ✅ Mathematical entropy layer  |
| Parallel processing  | ❌ No (sequential)   | ✅ ThreadPoolExecutor          |
| Dependencies         | `hashlib` / `sha2`   | None (stdlib only)             |
| Use case             | Production systems   | Research & experimentation     |
| Speed                | ~100 ns              | ~1–10 ms                       |


---

## 👥 Authors

| Name             | Email                          | Affiliation              |
|------------------|-------------------------------|--------------------------|
| Anant Jain       | ritujainanant2810@gmail.com   | IIIT Delhi               |
| Gauranshi Gupta  | gauranshigupta2000@gmail.com  | IIIT Delhi               |
| Rahul Johari     | rahul@ipu.ac.in               | IP University            |



## ⭐ Citation

If you use SHARAG-256 in academic research, please cite:

```bibtex
@software{sharag256,
  title  = {SHARAG-256: A Custom Hash Function with Mathematical Randomization},
  author = {Jain, Anant and Gupta, Gauranshi and Johari, Rahul},
  year   = {2026},
  url    = {https://pypi.org/project/sharag256/},
}
```
