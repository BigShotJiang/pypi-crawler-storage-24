from __future__ import annotations

from enum import Enum
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field

from noqa_runner.domain.models.platform import Platform
from noqa_runner.domain.models.state.expected_result import ExpectedResult
from noqa_runner.domain.models.state.flow import FlowItem, FlowItemRaw
from noqa_runner.domain.models.state.step import Step


class TestStatus(str, Enum):
    """Test status matching backend enum values"""

    RUNNING = "running"
    PASSED = "passed"
    FAILED = "failed"
    ERRORED = "errored"
    CANCELLED = "cancelled"


def merge_dicts(current: dict, update: dict) -> dict:
    result = current.copy()
    result.update(update)
    return result


class State(BaseModel):
    model_config = ConfigDict(
        arbitrary_types_allowed=True, use_enum_values=True, validate_assignment=True
    )

    case_name: str | None = None
    flows: list[FlowItem | FlowItemRaw] = Field(default_factory=list)
    test_id: str | None = None

    app_name: str | None = None
    app_description: str | None = None
    bundle_id: str | None = None
    app_context: str | None = None

    platform: Platform = Platform.IOS

    status: TestStatus = TestStatus.RUNNING
    result_summary: str | None = None

    steps: Annotated[dict[int, Step], merge_dicts] = Field(default_factory=dict)

    def sorted_steps(self, reverse: bool = False) -> list[Step]:
        """Get steps sorted by step number"""
        if not self.steps:
            return []
        sorted_step_numbers = sorted(self.steps.keys(), reverse=reverse)
        return [self.steps[num] for num in sorted_step_numbers]

    @property
    def expected_results(self) -> list[ExpectedResult]:
        """Get all ExpectedResult objects from all flows"""
        return [
            flow.result
            for flow in self.flows
            if isinstance(flow, FlowItem) and isinstance(flow.result, ExpectedResult)
        ]

    @property
    def current_step(self) -> Step | None:
        """Get current (last) step"""
        sorted_steps = self.sorted_steps()
        return sorted_steps[-1] if sorted_steps else None

    @property
    def previous_step(self) -> Step | None:
        """Get previous step"""
        sorted_steps = self.sorted_steps()
        return sorted_steps[-2] if len(sorted_steps) >= 2 else None

    def export_dict(self) -> dict:
        """Export test data for external systems"""
        steps_by_flow: dict[int, list[dict]] = {}
        for step in self.sorted_steps():
            step_dict = {
                "screen": (
                    {
                        "resolution": step.screen.resolution,
                        "screenshot_url": step.screen.screenshot_url,
                    }
                    if step.screen
                    else None
                ),
                "reasoning": (
                    step.action_data.reasoning.model_dump()
                    if step.action_data
                    and hasattr(step.action_data.reasoning, "model_dump")
                    else (step.action_data.reasoning if step.action_data else None)
                ),
                "action": (
                    step.action_data.action.model_dump() if step.action_data else None
                ),
                "action_description": (
                    step.action_data.action_description if step.action_data else None
                ),
            }

            flow_num = (
                step.action_data.reasoning.next_action_flow
                if step.action_data
                and hasattr(step.action_data.reasoning, "next_action_flow")
                else len(self.flows) or 1
            )
            steps_by_flow.setdefault(flow_num, []).append(step_dict)

        flows = []
        for i, flow in enumerate(self.flows, start=1):
            flow_dict = {
                "instructions": flow.instructions,
                "expected_result": (
                    flow.result.model_dump()
                    if flow.result and hasattr(flow.result, "model_dump")
                    else flow.result
                ),
                "steps": steps_by_flow.get(i, []),
            }
            flows.append(flow_dict)

        return {
            "test_id": self.test_id,
            "case_name": self.case_name,
            "flows": flows,
            "status": self.status,
            "message": self.result_summary,
        }
