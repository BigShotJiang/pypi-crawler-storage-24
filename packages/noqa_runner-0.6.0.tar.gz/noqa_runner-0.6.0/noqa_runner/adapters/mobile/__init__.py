from __future__ import annotations

from noqa_runner.adapters.mobile.appium_adapter import AppiumClient

__all__ = ["AppiumClient"]
