from __future__ import annotations

from noqa_runner.adapters.storage.local_storage_adapter import LocalStorageAdapter

__all__ = ["LocalStorageAdapter"]
