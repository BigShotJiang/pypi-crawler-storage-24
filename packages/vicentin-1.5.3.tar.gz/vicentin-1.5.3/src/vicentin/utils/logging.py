import logging
import threading
from contextlib import contextmanager

_depth_context = threading.local()


def get_depth():
    return getattr(_depth_context, "depth", 0)


def increment_depth():
    _depth_context.depth = get_depth() + 1


def decrement_depth():
    _depth_context.depth = max(0, get_depth() - 1)


@contextmanager
def log_scope(name=None):
    """Context manager to handle indentation and entry/exit logs."""
    if name:
        info(f"==> {name}")

    increment_depth()
    try:
        yield
    finally:
        decrement_depth()


logger = logging.getLogger("vicentin")
logger.addHandler(logging.NullHandler())


def log(msg, level=logging.INFO):
    """Logs a message with the correct indentation based on recursion depth."""
    indent = "\t" * get_depth()
    logger.log(level, f"{indent}{msg}")


def debug(msg):
    log(msg, logging.DEBUG)


def info(msg):
    log(msg, logging.INFO)


def warn(msg):
    log(msg, logging.WARNING)


def error(msg):
    log(msg, logging.ERROR)


# --- Colorful Formatter ---


class Formatter(logging.Formatter):
    """Refined formatter with a sophisticated color palette for optimization traces."""

    # ANSI Escape Codes (Extended 256-color palette for "prettier" shades)
    GREEN_BOLD = "\033[1;32m"  # Success/Entry points
    BLUE_LIGHT = "\033[38;5;111m"  # Standard Info/Iterations
    GREY_DIM = "\033[38;5;244m"  # Debug/Sub-steps
    YELLOW_SOFT = "\033[38;5;222m"  # Warnings
    RED_SOFT = "\033[38;5;203m"  # Errors
    RESET = "\033[0m"

    # Map levels to colors
    FORMATS = {
        logging.DEBUG: GREY_DIM + "%(message)s" + RESET,
        logging.INFO: BLUE_LIGHT + "%(message)s" + RESET,
        logging.WARNING: YELLOW_SOFT + "⚠ %(message)s" + RESET,
        logging.ERROR: RED_SOFT + "✖ %(message)s" + RESET,
    }

    def format(self, record):
        # Apply Bold Green specifically to the Dispatcher scopes
        if "==>" in record.msg:
            record.msg = f"{self.GREEN_BOLD}{record.msg}{self.RESET}"

        log_fmt = self.FORMATS.get(record.levelno, self.RESET + "%(message)s")
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)


# --- Library Setup Helper ---


def setup_logging(level=logging.INFO):
    """Configures the library-wide logger with the refined Formatter."""
    handler = logging.StreamHandler()
    handler.setFormatter(Formatter())

    if logger.hasHandlers():
        logger.handlers.clear()

    logger.addHandler(handler)
    logger.setLevel(level)
