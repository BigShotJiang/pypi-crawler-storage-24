from typing import Any, Optional

from vicentin.kernels import Kernel
from vicentin.utils import Dispatcher


class LaplacianKernel(Kernel):
    def __init__(
        self, X: Optional[Any] = None, gamma: Optional[float] = None, **kwargs
    ):
        self.gamma = gamma
        self._auto_gamma = gamma is None

        super().__init__(X, **kwargs)

        self.disp_l1_dist = Dispatcher(False)
        self.disp_exp = Dispatcher(False)

        try:
            import numpy as np

            def np_l1_dist(x, y):
                if y is None:
                    y = x

                return np.sum(np.abs(x[:, None, :] - y[None, :, :]), axis=2)

            self.disp_l1_dist.register("numpy", np_l1_dist)
            self.disp_exp.register("numpy", np.exp)
        except ImportError:
            pass

        try:
            import torch

            def torch_l1_dist(x, y):
                if y is None:
                    y = x

                return torch.cdist(x, y, p=1.0)

            self.disp_l1_dist.register("torch", torch_l1_dist)
            self.disp_exp.register("torch", torch.exp)
        except ImportError:
            pass

    def set_X(self, X: Any):
        super().set_X(X)

        if self._auto_gamma:
            self.gamma = 1 / (X.shape[1] * X.var())

    def _compute(self, x: Any, y: Optional[Any] = None) -> Any:
        if self.gamma is None:
            raise RuntimeError("gamma is None.")

        self.disp_l1_dist.detect_backend(x)
        self.disp_exp.detect_backend(x)

        if getattr(x, "ndim", 1) == 1:
            x = x[None, :]
        if y is not None and getattr(y, "ndim", 1) == 1:
            y = y[None, :]

        dists = self.disp_l1_dist(x, y)
        return self.disp_exp(-self.gamma * dists).squeeze()
