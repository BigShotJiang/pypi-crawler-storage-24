import argparse, json
from .extractor import extract_palette
from .palette_image import create_palette_image
from .utils import save_palette_json
from .color_naming import load_palette

def main():
    p = argparse.ArgumentParser(
        description=(
            "Extract a color palette from an image using K-Means clustering. "
            "Colors are sorted by dominance (most dominant first). "
            "Outputs RGB or HEX colors with their dominance percentage, "
            "and optionally saves a JSON file and/or a PNG palette image."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "examples:\n"
            "  colorpalette logo.png --colors 6 --format hex --json palette.json --png palette.png\n"
            "  colorpalette logo.png --ignore-white --ignore-black --json palette.json\n"
            "  colorpalette logo.png --ignore-white --white-threshold 220 --colors 8\n"
            "  colorpalette logo.png --name-colors --palette pantone.json --format hex"
        ),
    )
    p.add_argument("image_path", help="Path to the input image file")
    p.add_argument("--colors", type=int, default=5, metavar="N",
                   help="Number of colors to extract (default: 5)")
    p.add_argument("--format", choices=["rgb", "hex"], default="rgb",
                   help="Output color format: 'rgb' or 'hex' (default: rgb)")
    p.add_argument("--json", metavar="PATH",
                   help="Save palette and dominance data to a JSON file")
    p.add_argument("--png", metavar="PATH",
                   help="Save a PNG swatch image of the extracted palette")
    p.add_argument("--name-colors", action="store_true",
                   help="Match each color to the closest name in the provided --palette file")
    p.add_argument("--palette", metavar="PATH",
                   help="Path to a color naming palette JSON (e.g. Pantone). Required with --name-colors")
    p.add_argument("--ignore-white", action="store_true",
                   help="Exclude near-white pixels before extraction (see --white-threshold)")
    p.add_argument("--ignore-black", action="store_true",
                   help="Exclude near-black pixels before extraction (see --black-threshold)")
    p.add_argument("--white-threshold", type=int, default=240, metavar="0-255",
                   help="Pixels with all RGB channels >= this value are considered white (default: 240)")
    p.add_argument("--black-threshold", type=int, default=15, metavar="0-255",
                   help="Pixels with all RGB channels <= this value are considered black (default: 15)")
    args = p.parse_args()

    naming = None
    if args.name_colors and args.palette:
        naming = load_palette(json.load(open(args.palette)))

    colors, names, dominance = extract_palette(
        args.image_path,
        args.colors,
        args.format,
        naming,
        ignore_white=args.ignore_white,
        ignore_black=args.ignore_black,
        white_threshold=args.white_threshold,
        black_threshold=args.black_threshold,
    )

    print("Extracted colors (sorted by dominance):")
    for color, pct in zip(colors, dominance):
        print(f"  {color}  {pct}%")

    if names:
        print("Color names:")
        print(names)

    if args.json:
        save_palette_json(colors, args.json, names, dominance)
        print(f"Saved JSON -> {args.json}")

    if args.png:
        create_palette_image(colors, args.png)
        print(f"Saved PNG -> {args.png}")
