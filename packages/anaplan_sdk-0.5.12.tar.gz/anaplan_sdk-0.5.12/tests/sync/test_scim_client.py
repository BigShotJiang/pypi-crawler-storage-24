from anaplan_sdk import Client
from anaplan_sdk.models.scim import (
    MetaWithDates,
    NameInput,
    Remove,
    Replace,
    ReplaceUserInput,
    Resource,
    Schema,
    ServiceProviderConfig,
    User,
    field,
)
from tests.conftest import PyVersionConfig


def test_get_service_provider_config(client: Client) -> None:
    conf = client.scim.get_service_provider_config()
    assert isinstance(conf, ServiceProviderConfig)


def test_get_resource_types(client: Client) -> None:
    res_types = client.scim.get_resource_types()
    assert isinstance(res_types, list)
    assert all(isinstance(r, Resource) for r in res_types)


def test_get_resource_schemas(client: Client) -> None:
    schemas = client.scim.get_resource_schemas()
    assert isinstance(schemas, list)
    assert all(isinstance(s, Schema) for s in schemas)


def test_get_users(client: Client) -> None:
    users = client.scim.get_users()
    assert isinstance(users, list)
    assert all(isinstance(u, User) for u in users)


def test_get_user_filtered(client: Client, name: str = "test.user@valantic.com") -> None:
    users = client.scim.get_users(field("userName") == name)
    assert isinstance(users, list)
    assert all(isinstance(u, User) for u in users)
    assert all(u.user_name == name for u in users)


def test_get_user(client: Client, config: PyVersionConfig) -> None:
    user = client.scim.get_user(config.scim_user_id)
    assert isinstance(user, User)
    assert user.id == config.scim_user_id
    assert isinstance(user.meta, MetaWithDates)


def test_replace_user(client: Client, config: PyVersionConfig) -> None:
    user = client.scim.replace_user(
        config.scim_user_id,
        ReplaceUserInput(
            id=config.scim_user_id,
            name=NameInput(given_name="Test", family_name="User"),
            user_name="test.user@valantic.com",
        ),
    )
    assert isinstance(user, User)
    assert user.id == config.scim_user_id
    assert user.name.given_name == "Test"
    assert user.name.family_name == "User"


def test_create_update_user(client: Client, config: PyVersionConfig) -> None:
    user = client.scim.update_user(
        config.scim_user_id, [Replace(path="active", value=False), Remove(path="entitlements")]
    )
    assert isinstance(user, User)
    assert user.id == config.scim_user_id
    assert user.active is False
    assert user.entitlements == []
