"""Lettera - A typewriter-inspired journaling application."""

__version__ = "0.1.0"
