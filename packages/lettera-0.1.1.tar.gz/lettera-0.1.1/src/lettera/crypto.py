"""Encryption utilities for Lettera entries.

Uses AES-256-GCM with PBKDF2HMAC key derivation.
Encrypted file format:
    LETTERA_ENC:v1:<base64(salt)>:<base64(nonce + ciphertext)>
"""

import base64
import os

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

HEADER_PREFIX = "LETTERA_ENC:v1:"
_SALT_BYTES = 16
_NONCE_BYTES = 12
_KEY_BYTES = 32
_PBKDF2_ITERATIONS = 480_000


def _derive_key(passphrase: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=_KEY_BYTES,
        salt=salt,
        iterations=_PBKDF2_ITERATIONS,
    )
    return kdf.derive(passphrase.encode("utf-8"))


def is_encrypted(content: str) -> bool:
    return content.startswith(HEADER_PREFIX)


def encrypt_content(passphrase: str, plaintext: str) -> str:
    salt = os.urandom(_SALT_BYTES)
    nonce = os.urandom(_NONCE_BYTES)
    key = _derive_key(passphrase, salt)
    aesgcm = AESGCM(key)
    ciphertext = aesgcm.encrypt(nonce, plaintext.encode("utf-8"), None)
    salt_b64 = base64.b64encode(salt).decode("ascii")
    payload_b64 = base64.b64encode(nonce + ciphertext).decode("ascii")
    return f"{HEADER_PREFIX}{salt_b64}:{payload_b64}"


def decrypt_content(passphrase: str, encrypted: str) -> str:
    """Decrypt an encrypted entry string.

    Raises ValueError if the passphrase is wrong or the content is corrupt.
    """
    if not encrypted.startswith(HEADER_PREFIX):
        raise ValueError("Not an encrypted entry")
    rest = encrypted[len(HEADER_PREFIX):]
    parts = rest.split(":")
    if len(parts) != 2:
        raise ValueError("Malformed encrypted entry")
    salt = base64.b64decode(parts[0])
    payload = base64.b64decode(parts[1])
    nonce = payload[:_NONCE_BYTES]
    ciphertext = payload[_NONCE_BYTES:]
    key = _derive_key(passphrase, salt)
    aesgcm = AESGCM(key)
    try:
        plaintext_bytes = aesgcm.decrypt(nonce, ciphertext, None)
    except Exception:
        raise ValueError("Decryption failed — wrong passphrase or corrupted entry")
    return plaintext_bytes.decode("utf-8")
