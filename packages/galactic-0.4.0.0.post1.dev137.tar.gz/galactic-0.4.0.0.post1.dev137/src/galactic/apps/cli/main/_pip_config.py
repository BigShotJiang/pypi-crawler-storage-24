"""
Utilities for pip configuration.
"""

from __future__ import annotations

import os
import re
import shutil
import sys
from configparser import ConfigParser
from pathlib import Path
from typing import TYPE_CHECKING
from urllib.parse import quote, unquote, urlsplit, urlunsplit

import platformdirs

if TYPE_CHECKING:
    from collections.abc import Mapping


PIP_CONFIG_FILE_ENV_VAR = "PIP_CONFIG_FILE"
VIRTUAL_ENV_ENV_VAR = "VIRTUAL_ENV"
CONDA_PREFIX_ENV_VAR = "CONDA_PREFIX"
WINDOWS_PIP_CONFIG_FILENAME = "pip.ini"
UNIX_PIP_CONFIG_FILENAME = "pip.conf"
INDEX_HOSTNAME = "www.thegalactic.org"
PACKAGE_INDEX_URL = "https://www.thegalactic.org/pypi/public/simple/"
GLOBAL_SECTION = "global"
EXTRA_INDEX_URL_OPTION = "extra-index-url"


def pip_config_filename() -> str:
    """
    Return the pip configuration filename for the current platform.

    Returns
    -------
    str
        ``pip.ini`` on Windows, ``pip.conf`` elsewhere.

    """
    if sys.platform.startswith("win"):
        return WINDOWS_PIP_CONFIG_FILENAME
    return UNIX_PIP_CONFIG_FILENAME


def resolve_pip_config_path(
    *,
    env: Mapping[str, str] | None = None,
) -> Path:
    """
    Resolve the pip configuration file path.

    The resolution follows this priority order:

    1. ``PIP_CONFIG_FILE`` environment variable (explicit override).
    3. ``CONDA_PREFIX`` — path inside the active conda environment.
    2. ``VIRTUAL_ENV`` — path inside the active virtual environment.
    4. User-level config directory resolved by :mod:`platformdirs`.

    Parameters
    ----------
    env
        Environment variables mapping. Defaults to :data:`os.environ`.

    Returns
    -------
    Path
        The path to the pip configuration file.

    """
    environment: Mapping[str, str] = env if env is not None else os.environ
    filename = pip_config_filename()

    # Priority 1: explicit override
    if pip_config_file := environment.get(PIP_CONFIG_FILE_ENV_VAR):
        return Path(pip_config_file)

    # Priority 2: inside a conda environment
    if conda_prefix := environment.get(CONDA_PREFIX_ENV_VAR):
        return Path(conda_prefix) / filename

    # Priority 3: inside a virtual environment
    if virtual_env := environment.get(VIRTUAL_ENV_ENV_VAR):
        return Path(virtual_env) / filename

    # Priority 4: user-level config resolved by platformdirs
    return platformdirs.user_config_path("pip") / filename


def build_package_index_url(password: str, username: str = "__token__") -> str:
    """
    Build the authenticated GALACTIC package index URL.

    Parameters
    ----------
    password
        Password to embed in the URL.
    username
        Username to embed in the URL (``__token__`` by default).

    Returns
    -------
    str
        The package index URL with credentials embedded.

    """
    return with_url_credentials(PACKAGE_INDEX_URL, username=username, password=password)


def list_extra_index_urls(path: Path) -> list[str]:
    """
    Return configured ``extra-index-url`` entries from a pip config file.

    Parameters
    ----------
    path
        Path to the pip configuration file.

    Returns
    -------
    list[str]
        Parsed URL entries, in file order.

    """
    if not path.exists():
        return []

    config = ConfigParser(interpolation=None)
    config.read(path, encoding="utf-8")
    existing_raw = config.get(GLOBAL_SECTION, EXTRA_INDEX_URL_OPTION, fallback="")
    return [url for raw in existing_raw.splitlines() for url in raw.split() if url]


def with_url_credentials(url: str, *, username: str, password: str) -> str:
    """
    Return ``url`` with explicit credentials in its netloc.

    Parameters
    ----------
    url
        Base URL to update.
    username
        Username to inject.
    password
        Password to inject.

    Returns
    -------
    str
        URL containing ``username:password`` credentials.

    """
    parsed = urlsplit(url)
    if not parsed.scheme or not parsed.hostname:
        return url

    user = quote(username, safe="")
    secret = quote(password, safe="")

    host = _as_text(parsed.hostname)
    if parsed.port is not None:
        host = f"{host}:{parsed.port}"
    if user:
        host = f"{user}:{secret}@{host}"

    scheme = _as_text(parsed.scheme)
    path = _as_text(parsed.path)
    query = _as_text(parsed.query)
    fragment = _as_text(parsed.fragment)

    return urlunsplit((scheme, host, path, query, fragment))


def redact_url_credentials(url: str) -> str:
    """
    Return ``url`` without embedded credentials.

    Parameters
    ----------
    url
        URL potentially containing ``username:password``.

    Returns
    -------
    str
        URL with user-info stripped from netloc.

    """
    parsed = urlsplit(url)
    if not parsed.scheme or not parsed.hostname:
        return url

    host = _as_text(parsed.hostname)
    if parsed.port is not None:
        host = f"{host}:{parsed.port}"

    scheme = _as_text(parsed.scheme)
    path = _as_text(parsed.path)
    query = _as_text(parsed.query)
    fragment = _as_text(parsed.fragment)
    return urlunsplit((scheme, host, path, query, fragment))


def extract_url_username(url: str) -> str | None:
    """
    Extract the username embedded in ``url`` credentials.

    Parameters
    ----------
    url
        URL that may contain user-info.

    Returns
    -------
    str | None
        Decoded username when present, otherwise ``None``.

    """
    parsed = urlsplit(url)
    if parsed.username is None:
        return None
    username = unquote(_as_text(parsed.username))
    return username or None


def is_galactic_url_configured(path: Path) -> bool:
    """
    Check whether a GALACTIC index URL is already present in a pip config file.

    Parameters
    ----------
    path
        Path to the pip configuration file.

    Returns
    -------
    bool
        ``True`` if at least one ``extra-index-url`` entry references
        :data:`INDEX_HOSTNAME`, ``False`` otherwise (including when the file
        does not exist).

    """
    return any(INDEX_HOSTNAME in url for url in list_extra_index_urls(path))


def write_pip_extra_index_url(
    username: str,
    password: str,
    path: Path,
    target_url: str | None = None,
) -> str:
    """
    Write the GALACTIC extra index URL to a pip configuration file.

    Parameters
    ----------
    username
        Username to store in the authenticated URL.
    password
        Password to store in the authenticated URL.
    path
        Path to the pip configuration file.
    target_url
        Existing URL to update. If ``None``, use the GALACTIC URL when no
        ``extra-index-url`` is configured.

    Returns
    -------
    str
        Final URL that has been configured with credentials.

    """
    all_urls = list_extra_index_urls(path)

    selected_url = target_url
    if selected_url is None and not all_urls:
        selected_url = PACKAGE_INDEX_URL
    elif selected_url is None and len(all_urls) == 1:
        selected_url = all_urls[0]

    if selected_url is None:
        raise ValueError(
            "target_url must be provided when multiple URLs are configured",
        )

    configured_url = with_url_credentials(
        selected_url,
        username=username,
        password=password,
    )

    updated = False
    for index, url in enumerate(all_urls):
        if url == selected_url:
            all_urls[index] = configured_url
            updated = True
            break

    if not updated:
        all_urls.append(configured_url)

    new_content = _upsert_extra_index_url_option(
        original_content=path.read_text(encoding="utf-8") if path.exists() else "",
        urls=all_urls,
    )

    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        backup_path = path.with_name(f"{path.name}.old")
        shutil.copy2(path, backup_path)
    path.write_text(new_content, encoding="utf-8")

    return configured_url


# pylint: disable=too-many-locals, too-many-branches
def _upsert_extra_index_url_option(*, original_content: str, urls: list[str]) -> str:
    """Update only `[global].extra-index-url` while preserving surrounding text."""
    newline = _detect_newline(original_content)
    section_re = re.compile(r"^\s*\[(?P<name>[^\]]+)\]\s*$", re.IGNORECASE)
    option_re = re.compile(r"^(?P<indent>\s*)extra-index-url\s*=.*$", re.IGNORECASE)

    lines = original_content.splitlines(keepends=True)
    section_start: int | None = None
    section_end = len(lines)

    for index, line in enumerate(lines):
        match = section_re.match(line.rstrip("\r\n"))
        if match and match.group("name").strip().lower() == GLOBAL_SECTION:
            section_start = index
            for after in range(index + 1, len(lines)):
                if section_re.match(lines[after].rstrip("\r\n")):
                    section_end = after
                    break
            break

    replacement = _render_extra_index_option_lines(
        urls,
        newline=newline,
        indent="",
    )

    if section_start is None:
        if lines and not lines[-1].endswith(("\n", "\r")):
            lines[-1] = lines[-1] + newline
        if lines and lines[-1].strip():
            lines.append(newline)
        lines.append(f"[{GLOBAL_SECTION}]{newline}")
        lines.extend(replacement)
        return "".join(lines)

    option_start: int | None = None
    option_end = section_end
    option_indent = ""
    for index in range(section_start + 1, section_end):
        stripped = lines[index].rstrip("\r\n")
        match = option_re.match(stripped)
        if match:
            option_start = index
            option_indent = match.group("indent")
            for after in range(index + 1, section_end):
                candidate = lines[after].rstrip("\r\n")
                if not candidate:
                    continue
                if candidate.startswith((" ", "\t")):
                    continue
                if section_re.match(candidate):
                    break
                option_end = after
                break
            else:
                option_end = section_end
            break

    if option_start is None:
        insertion_at = section_end
        if insertion_at > section_start + 1 and lines[insertion_at - 1].strip():
            lines.insert(insertion_at, newline)
            insertion_at += 1
        lines[insertion_at:insertion_at] = _render_extra_index_option_lines(
            urls,
            newline=newline,
            indent="",
        )
        return "".join(lines)

    lines[option_start:option_end] = _rewrite_option_block_preserving_positions(
        lines[option_start:option_end],
        urls,
        newline=newline,
        option_indent=option_indent,
    )
    return "".join(lines)


def _render_extra_index_option_lines(
    urls: list[str],
    *,
    newline: str,
    indent: str,
) -> list[str]:
    if len(urls) == 1:
        return [f"{indent}{EXTRA_INDEX_URL_OPTION} = {urls[0]}{newline}"]
    rendered = [f"{indent}{EXTRA_INDEX_URL_OPTION} ={newline}"]
    rendered.extend(f"{indent}    {url}{newline}" for url in urls)
    return rendered


def _rewrite_option_block_preserving_positions(
    original_option_lines: list[str],
    urls: list[str],
    *,
    newline: str,
    option_indent: str,
) -> list[str]:
    """Rewrite URL lines in an option block while keeping other lines unchanged."""
    if not original_option_lines:
        return _render_extra_index_option_lines(
            urls,
            newline=newline,
            indent=option_indent,
        )

    url_slots: list[tuple[str, str]] = []
    passthrough: dict[int, str] = {}

    first = original_option_lines[0].rstrip("\r\n")
    first_match = re.match(
        r"^(?P<prefix>\s*extra-index-url\s*=\s*)(?P<value>.*)$",
        first,
        re.IGNORECASE,
    )
    if first_match is None:
        return _render_extra_index_option_lines(
            urls,
            newline=newline,
            indent=option_indent,
        )

    first_value = first_match.group("value").strip()
    first_prefix = first_match.group("prefix")
    if _is_url_value_line(first_value):
        url_slots.append((first_prefix, "first"))
    else:
        passthrough[0] = (
            f"{first_prefix}{newline}" if not first_value else f"{first}{newline}"
        )

    for index, raw_line in enumerate(original_option_lines[1:], start=1):
        line = raw_line.rstrip("\r\n")
        stripped = line.strip()
        if not stripped or stripped.startswith(("#", ";")):
            passthrough[index] = f"{line}{newline}"
            continue
        indent_match = re.match(r"^(\s*)", line)
        slot_prefix = indent_match.group(1) if indent_match else ""
        url_slots.append((slot_prefix, "cont"))

    result: list[str] = []
    url_index = 0
    total_lines = len(original_option_lines)
    slot_index = 0

    for index in range(total_lines):
        if index in passthrough:
            result.append(passthrough[index])
            continue
        if url_index >= len(urls):
            slot_index += 1
            continue
        prefix = url_slots[slot_index][0]
        result.append(f"{prefix}{urls[url_index]}{newline}")
        url_index += 1
        slot_index += 1

    while url_index < len(urls):
        if url_slots:
            base_prefix = url_slots[-1][0]
            continuation_prefix = (
                base_prefix if base_prefix.strip() else f"{option_indent}    "
            )
        else:
            continuation_prefix = f"{option_indent}    "
        result.append(f"{continuation_prefix}{urls[url_index]}{newline}")
        url_index += 1

    if result and not result[0].lower().lstrip().startswith("extra-index-url"):
        return _render_extra_index_option_lines(
            urls,
            newline=newline,
            indent=option_indent,
        )

    return result


def _is_url_value_line(value: str) -> bool:
    if not value:
        return False
    return not value.startswith(("#", ";"))


def _detect_newline(content: str) -> str:
    if "\r\n" in content:
        return "\r\n"
    return "\n"


def _as_text(value: str | bytes | None) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode()
    return value
