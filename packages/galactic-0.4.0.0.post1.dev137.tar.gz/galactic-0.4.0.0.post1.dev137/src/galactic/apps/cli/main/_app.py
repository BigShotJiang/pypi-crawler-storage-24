"""
Main app module.
"""

from __future__ import annotations

import os
from typing import Any, ClassVar

import rich_click as click

from galactic.helpers.core import detect_plugins

from ._pip_config import (
    extract_url_username,
    list_extra_index_urls,
    redact_url_credentials,
    resolve_pip_config_path,
    write_pip_extra_index_url,
)


# pylint: disable=too-few-public-methods
class AppStyles:
    """
    Styles used in application.

    Attributes
    ----------
    ERROR
        Style for errors (``{"fg": "red", "bold": True}`` by default).
    WARNING
        Style for warnings (``{"fg": "yellow", "bold": True}`` by default).
    INFO
        Style for informations (``{"fg": "bright_magenta"}`` by default).
    COMMENT
        Style for comments (``{"fg": "green"}`` by default).
    QUESTION
        Style for questions (``{"fg": "cyan"}`` by default).
    """

    ERROR: ClassVar[dict[str, Any]] = {"fg": "red", "bold": True}
    WARNING: ClassVar[dict[str, Any]] = {"fg": "yellow", "bold": True}
    INFO: ClassVar[dict[str, Any]] = {"fg": "bright_magenta"}
    COMMENT: ClassVar[dict[str, Any]] = {"fg": "green"}
    QUESTION: ClassVar[dict[str, Any]] = {"fg": "cyan"}


def error(text: str, **kwargs: Any) -> None:
    """
    Display an error message.

    Parameters
    ----------
    text
        Text to display
    **kwargs
        Additional parameters passed to click.secho

    """
    click.secho(text, **AppStyles.ERROR, **kwargs)


def info(text: str, **kwargs: Any) -> None:
    """
    Display an info message.

    Parameters
    ----------
    text
        Text to display
    **kwargs
        Additional parameters passed to click.secho

    """
    click.secho(text, **AppStyles.INFO, **kwargs)


def warning(text: str, **kwargs: Any) -> None:
    """
    Display a warning.

    Parameters
    ----------
    text
        Text to display
    **kwargs
        Additional parameters passed to click.secho

    """
    click.secho(text, **AppStyles.WARNING, **kwargs)


def comment(text: str, **kwargs: Any) -> None:
    """
    Display a comment.

    Parameters
    ----------
    text
        Text to display
    **kwargs
        Additional parameters passed to click.secho

    """
    click.secho(text, **AppStyles.COMMENT, **kwargs)


def prompt(text: str, **kwargs: Any) -> Any:
    """
    Prompt the user.

    Parameters
    ----------
    text
        Text to display
    **kwargs
        Additional parameters passed to click.prompt

    """
    return click.prompt(click.style(text, **AppStyles.QUESTION), **kwargs)


def confirm(text: str, **kwargs: Any) -> bool:
    """
    Prompt the user for a confirmation.

    Parameters
    ----------
    text
        Text to display
    **kwargs
        Additional parameters passed to click.confirm

    """
    return click.confirm(click.style(text, **AppStyles.QUESTION), **kwargs)


def prompt_password_with_confirmation(text: str) -> str:
    """
    Prompt a hidden password twice and allow empty values.

    Parameters
    ----------
    text
        Prompt displayed for the first password entry.

    Returns
    -------
    str
        Confirmed password.

    """
    while True:
        password = prompt(
            text,
            default="",
            hide_input=True,
            show_default=False,
            type=str,
        )
        confirmation = prompt(
            "Confirm password",
            default="",
            hide_input=True,
            show_default=False,
            type=str,
        )
        if password == confirmation:
            return password
        error("Passwords do not match. Please retry.")


# pylint: disable=too-few-public-methods
class AppEnvVars:
    """
    Environment variables.

    Attributes
    ----------
    NO_COLOR
        Name of environment variable for no-color.
    FORCE_COLOR
        Name of environment variable for force color.
    """

    # https://no-color.org
    NO_COLOR = "NO_COLOR"
    FORCE_COLOR = "FORCE_COLOR"


class Group(click.Group):  # type: ignore[misc]
    """
    Group class for the GALACTIC app.

    It does two things:

    * it detects plugins from the galactic.apps.cli.main group.
    * it adds an epilog to all added commands.
    """

    _plugins_detected = False

    @classmethod
    def detect_plugins(cls) -> None:
        """
        Detect plugins from the galactic.apps.cli.main group.
        """
        if not cls._plugins_detected:
            detect_plugins(group="galactic.apps.cli.main")
            cls._plugins_detected = True

    def list_commands(self, ctx: click.Context) -> list[str]:
        """
        List commands in the group.

        Parameters
        ----------
        ctx
            The click context

        Returns
        -------
        list[str]
            List of command names in the group

        """
        self.detect_plugins()
        return super().list_commands(ctx)

    def get_command(self, ctx: click.Context, cmd_name: str) -> click.Command | None:
        """
        Get a command by name.

        Parameters
        ----------
        ctx
            The click context
        cmd_name
            The name of the command to get

        Returns
        -------
        click.Command | None
            The command if found, otherwise None

        """
        self.detect_plugins()
        return super().get_command(ctx, cmd_name)

    def add_command(self, cmd: click.Command, name: str | None = None) -> None:
        """
        Add a command to the group.

        This method also sets the epilog of the command to the application's epilog.
        It is useful for commands that are part of the application and should
        inherit the application's epilog.

        Parameters
        ----------
        cmd
            The command to add
        name
            The name of the command (if None, the name of the command is used)

        """
        cmd.epilog = cmd.epilog or application.epilog
        super().add_command(cmd, name)


@click.version_option(package_name="galactic")  # type: ignore[untyped-decorator]
@click.group(  # type: ignore[untyped-decorator]
    name="galactic",
    cls=Group,
    epilog="GAlois LAttices, Concept Theory, Implicational systems and Closures.",
)
@click.pass_context  # type: ignore[untyped-decorator]
def application(ctx: click.Context) -> int:
    """
    GALACTIC main application.
    """
    if os.environ.get(AppEnvVars.NO_COLOR) == "1":
        ctx.color = False
    elif os.environ.get(AppEnvVars.FORCE_COLOR) == "1":
        ctx.color = True
    return 0


@application.command()  # type: ignore[untyped-decorator]
def config() -> None:
    """
    Configure access to the GALACTIC package index.
    """
    config_path = resolve_pip_config_path()
    backup_path = config_path.with_name(f"{config_path.name}.old")
    had_existing_config = config_path.exists()
    existing_urls = list_extra_index_urls(config_path)

    selected_url: str | None = None
    if len(existing_urls) > 1:
        info("Several extra-index-url entries were found:")
        for idx, url in enumerate(existing_urls, start=1):
            comment(f"{idx}. {redact_url_credentials(url)}")
        selected_index = prompt(
            "Which index URL do you want to configure?",
            default=1,
            type=click.IntRange(min=1, max=len(existing_urls)),
            show_default=True,
        )
        selected_url = existing_urls[selected_index - 1]
    elif len(existing_urls) == 1:
        selected_url = existing_urls[0]

    if selected_url is not None and not confirm(
        "Index URL already present in "
        f"{config_path}: {redact_url_credentials(selected_url)}. "
        "Update credentials?",
        default=False,
    ):
        return

    default_username = extract_url_username(selected_url) if selected_url else None
    username = prompt(
        "Username",
        default=default_username or "__token__",
        show_default=True,
        type=str,
    )
    password = prompt_password_with_confirmation(
        "Password (hit enter if you have no password)",
    )
    write_pip_extra_index_url(username, password, config_path, selected_url)
    if had_existing_config:
        warning(f"Previous configuration stored in {backup_path}.")
    info(f"Stored credentials in {config_path}.")
