# База даних користувачів
data = []

class User:
    """Базовий клас користувача для регістрації

    :param login: Логін користувача
    :type login: str

    :param password: Пароль користувача
    :type password: str
    """
    def __init__(self,
                 login,
                 password):
        """Ініціалізація класу User

        """
        self.login = login
        self.__password = password


def registration():
    """Функція регістрації

    :return: None
    """
    user_login = input("Логін:")
    user_password = input("Пароль:")

    if user_login not in data:
        user = User(user_login,user_password)
        data.append(user)
        print("Зареєстручались успішно")


def login(user_type:str):
    """ Вхід до системи певного типу користувачів

    :param user_type: Тип користувача наявні типи admin client
    :type user_type: str

    :return: Знайдений користувач або None
    :trype: User

    """
    pass
