from setuptools import setup

setup(
   name='egen111222new_daily_project',
   version='1.0',
   description='A useful module',
   packages=['project'],  #same as name
)
