# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
# SPDX-License-Identifier: MPL-2.0

from __future__ import annotations
from typing import TYPE_CHECKING

from VeraGridEngine.IO.base.units import UnitMultiplier, UnitSymbol
from VeraGridEngine.IO.cim.cgmes.cgmes_v3_0_0.devices.power_system_resource import PowerSystemResource
from VeraGridEngine.IO.cim.cgmes.cgmes_property import CgmesProperty
if TYPE_CHECKING:
	from VeraGridEngine.IO.cim.cgmes.cgmes_v3_0_0.devices.solar_generating_unit import SolarGeneratingUnit

class SolarPowerPlant(PowerSystemResource):
	LOCAL_CGMES_PROPERTIES: tuple[CgmesProperty, ...] = (
		CgmesProperty(property_name='SolarGeneratingUnits', class_type='SolarGeneratingUnit', multiplier=UnitMultiplier.none, unit=UnitSymbol.none, description='''A solar generating unit or units may be a member of a solar power plant.''', profiles=[]),
	)
	__slots__ = ('SolarGeneratingUnits',)
	def __init__(self, rdfid='', tpe='SolarPowerPlant'):
		PowerSystemResource.__init__(self, rdfid, tpe)

		self.SolarGeneratingUnits: SolarGeneratingUnit | None = None
