# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.  
# SPDX-License-Identifier: MPL-2.0

from __future__ import annotations
from typing import TYPE_CHECKING

from VeraGridEngine.IO.base.units import UnitMultiplier, UnitSymbol
from VeraGridEngine.IO.cim.cgmes.cgmes_v3_0_0.devices.identified_object import IdentifiedObject
from VeraGridEngine.IO.cim.cgmes.cgmes_property import CgmesProperty
if TYPE_CHECKING:
	from VeraGridEngine.IO.cim.cgmes.cgmes_v3_0_0.devices.location import Location

class CoordinateSystem(IdentifiedObject):
	LOCAL_CGMES_PROPERTIES: tuple[CgmesProperty, ...] = (
		CgmesProperty(property_name='crsUrn', class_type=str, multiplier=UnitMultiplier.none, unit=UnitSymbol.none, description='''A Uniform Resource Name (URN) for the coordinate reference system (crs) used to define 'Location.PositionPoints'.
An example would be the European Petroleum Survey Group (EPSG) code for a coordinate reference system, defined in URN under the Open Geospatial Consortium (OGC) namespace as: urn:ogc:def:crs:EPSG::XXXX, where XXXX is an EPSG code (a full list of codes can be found at the EPSG Registry web site http://www.epsg-registry.org/). To define the coordinate system as being WGS84 (latitude, longitude) using an EPSG OGC, this attribute would be urn:ogc:def:crs:EPSG::4236.
A profile should limit this code to a set of allowed URNs agreed to by all sending and receiving parties.''', profiles=[]),
		CgmesProperty(property_name='Locations', class_type='Location', multiplier=UnitMultiplier.none, unit=UnitSymbol.none, description='''All locations described with position points in this coordinate system.''', profiles=[]),
	)
	__slots__ = ('crsUrn', 'Locations')
	def __init__(self, rdfid='', tpe='CoordinateSystem'):
		IdentifiedObject.__init__(self, rdfid, tpe)

		self.crsUrn: str = None

		self.Locations: Location | None = None
