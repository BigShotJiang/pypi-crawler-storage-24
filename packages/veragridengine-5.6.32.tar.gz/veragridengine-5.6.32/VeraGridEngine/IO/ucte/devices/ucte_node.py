# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
# SPDX-License-Identifier: MPL-2.0
from __future__ import annotations

from VeraGridEngine.IO.ucte.devices.ucte_base import sub_int, sub_str, sub_float, try_int, try_float
from VeraGridEngine.basic_structures import Logger

UCTE_VOLTAGE_MAP = {
    "0": 750,
    "1": 380,
    "2": 220,
    "3": 150,
    "4": 120,
    "5": 110,
    "6": 70,
    "7": 27,
    "8": 330,
    "9": 500,
    "A": 26,
    "B": 25,
    "C": 24,
    "D": 23,
    "E": 22,
    "F": 21,
    "G": 20,
    "H": 19,
    "I": 18,
    "J": 17,
    "K": 15.7,
    "L": 15,
    "M": 13.7,
    "N": 13,
    "O": 12,
    "P": 11,
    "Q": 9.8,
    "R": 9,
    "S": 8,
    "T": 7,
    "U": 6,
    "V": 5,
    "W": 4,
    "X": 3,
    "Y": 2,
    "Z": 1,
}


def try_parse_voltage(val: str | float, name: str, logger: Logger) -> float:
    """

    :return:
    """
    val2 = UCTE_VOLTAGE_MAP.get(val, None)
    if val2 is None:
        try:
            f = float(val)
        except ValueError as e:
            logger.add_error('Could not parse UCTE voltage',
                             device=name, value=f"'{val}'")
            return 1.0

        if f > 0.0:
            logger.add_warning('UCTE Voltage was not provided as a value from the standard, but directly as a float',
                               device=name,
                               value=f"'{val}'")
            return f
        else:
            logger.add_error('Provided UCTE voltage is zero',
                             device=name,
                             value=f"'{val} -> {f}'")
            return 1.0
    else:
        return val2


class UcteNode:
    """
    UcteNode
    """

    def __init__(self):

        self.current_country = ""

        self.node_code = ""  # 0-7: Node (code)
        self.geo_name = ""  # 9-20: Geographical name
        self.status = 0  # 22: Status: 0 = real, 1 = equivalent

        # Node type code (0 = P and Q constant (PQ node);
        # 1 = Q and θ constant, 2 = P and U constant(PU node),
        # 3 = U and θ constant(global slack node, only one in the whole network))
        self.node_type = 0  # 24: Node type code

        self.voltage = 10.0  # 26-31: Voltage (reference value, kV)

        self.active_load = 0.0  # 33-39: Active load (MW)
        self.reactive_load = 0.0  # 41-47: Reactive load (MVAr)

        self.active_gen = 0.0  # 49-55: Active power generation (MW)
        self.reactive_gen = 0.0  # 57-63: Reactive power generation (MVAr)

        self.min_gen_mw = 0.0  # 65-71: Minimum permissible generation (MW) *
        self.max_gen_mw = 0.0  # 73-79: Maximum permissible generation (MW) *
        self.min_gen_mvar = 0.0  # 81-87: Minimum permissible generation (MVAr) *
        self.max_gen_mvar = 0.0  # 89-95: Maximum permissible generation (MVAr) *

        self.static_primary_control = 0.0  # 97-101: Static of primary control (%) *

        self.nominal_power_primary_control = 0.0  # 103-109: Nominal power for primary control (MW) *

        self.short_circuit_power = 0.0  # 111-117: Three-phase short circuit power (MVA) **

        self.xr_ratio = 0.0  # 119-125: X/R ratio **

        # Power plant type *
        # H: hydro, N: nuclear, L: lignite,
        # C: hard coal, G: gas, O: oil, W: wind, F: further
        self.plant_type = ""  # 127: Power plant type (e.g., H: hydro, N: nuclear)

    def has_load(self) -> bool:
        """

        :return:
        """
        return self.active_load != 0.0 or self.reactive_load != 0.0

    def has_gen(self) -> bool:
        """

        :return:
        """
        return self.active_gen != 0.0 or self.reactive_gen != 0.0

    def parse(self, line: str, logger: Logger):
        """

        :param line:
        :param logger:
        :return:
        """

        device = "Node"

        voltage_code = line[26:32].strip()
        if voltage_code != "" and len(line) == 129:
            # Things may seem canonical
            self.node_code = sub_str(line, 0, 8, device, "node_code", logger)
            self.geo_name = sub_str(line, 9, 21, device, "geo_name", logger)
            self.status = sub_int(line, 22, 23, device, "status", logger)
            self.node_type = sub_int(line, 24, 25, device, "node_type", logger)
            self.voltage = try_parse_voltage(val=line[26:32].strip(), name=self.node_code, logger=logger)
            self.active_load = sub_float(line, 33, 40, device, "active_load", logger)
            self.reactive_load = sub_float(line, 41, 48, device, "reactive_load", logger)
            self.active_gen = sub_float(line, 49, 56, device, "active_gen", logger)
            self.reactive_gen = sub_float(line, 57, 64, device, "reactive_gen", logger)
            self.min_gen_mw = sub_float(line, 65, 72, device, "min_gen_mw", logger, -9999.0)
            self.max_gen_mw = sub_float(line, 73, 80, device, "max_gen_mw", logger, 9999.0)
            self.min_gen_mvar = sub_float(line, 81, 88, device, "min_gen_mvar", logger, -9999.0)
            self.max_gen_mvar = sub_float(line, 89, 96, device, "max_gen_mvar", logger, 9999.0)
            self.static_primary_control = sub_float(line, 97, 102, device, "static_primary_control", logger)
            self.nominal_power_primary_control = sub_float(line, 103, 110, device, "nominal_power_primary_control",
                                                           logger)
            self.short_circuit_power = sub_float(line, 111, 118, device, "short_circuit_power", logger)
            self.xr_ratio = sub_float(line, 119, 126, device, "xr_ratio", logger)
            self.plant_type = sub_str(line, 127, 128, device, "plant_type", logger)
        else:

            if len(line) != 129:
                logger.add_warning("Non canonical line length",
                                   device_class=device,
                                   value=len(line),
                                   expected_value=128)
            elif voltage_code == "":
                logger.add_warning("Incorrect line formatting impede finding the voltage code",
                                   device_class=device,
                                   value=line, )

            chunks = line.split()

            if len(chunks) >= 1:
                self.node_code = chunks[0]

            if len(chunks) >= 2:
                self.geo_name = chunks[1]

            if len(chunks) >= 3:
                self.status = try_int(chunks[2], device, "status", logger)

            if len(chunks) >= 4:
                self.node_type = try_int(chunks[3], device, "node_type", logger)

            if len(chunks) >= 5:
                self.voltage = try_parse_voltage(val=chunks[4], name=self.node_code, logger=logger)

            if len(chunks) >= 6:
                self.active_load = try_float(chunks[5], device, "active_load", logger)

            if len(chunks) >= 7:
                self.reactive_load = try_float(chunks[6], device, "reactive_load", logger)

            if len(chunks) >= 8:
                self.active_gen = try_float(chunks[7], device, "active_gen", logger)

            if len(chunks) >= 9:
                self.reactive_gen = try_float(chunks[8], device, "reactive_gen", logger)

            if len(chunks) >= 10:
                self.min_gen_mw = try_float(chunks[9], device, "min_gen_mw", logger, -9999.0)

            if len(chunks) >= 11:
                self.max_gen_mw = try_float(chunks[10], device, "max_gen_mw", logger, 9999.0)

            if len(chunks) >= 12:
                self.min_gen_mvar = try_float(chunks[11], device, "min_gen_mvar", logger, -9999.0)

            if len(chunks) >= 13:
                self.max_gen_mvar = try_float(chunks[12], device, "max_gen_mvar", logger, 9999.0)

            if len(chunks) >= 14:
                self.static_primary_control = try_float(chunks[13], device, "static_primary_control", logger)

            if len(chunks) >= 15:
                self.nominal_power_primary_control = try_float(chunks[14], device, "nominal_power_primary_control",
                                                               logger)

            if len(chunks) >= 16:
                self.short_circuit_power = try_float(chunks[15], device, "short_circuit_power", logger)

            if len(chunks) >= 17:
                self.xr_ratio = try_float(chunks[16], device, "xr_ratio", logger)

            if len(chunks) >= 18:
                self.plant_type = try_float(chunks[17], device, "plant_type", logger)

        if self.min_gen_mw > self.max_gen_mw:
            # switch order
            self.max_gen_mw, self.min_gen_mw = self.min_gen_mw, self.max_gen_mw

        if self.min_gen_mvar > self.max_gen_mvar:
            # switch order
            self.max_gen_mvar, self.min_gen_mvar = self.min_gen_mvar, self.max_gen_mvar

        if self.active_gen > self.max_gen_mw:
            self.max_gen_mw = self.active_gen

        if self.active_gen < self.min_gen_mw:
            self.min_gen_mw = self.active_gen

        if self.reactive_gen > self.max_gen_mvar:
            self.max_gen_mvar = self.reactive_gen

        if self.reactive_gen < self.min_gen_mvar:
            self.min_gen_mvar = self.reactive_gen
