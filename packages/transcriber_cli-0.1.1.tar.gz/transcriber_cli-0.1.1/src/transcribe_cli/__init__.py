"""transcribe-cli — modular audio transcription with pluggable providers."""

__version__ = "0.1.1"
