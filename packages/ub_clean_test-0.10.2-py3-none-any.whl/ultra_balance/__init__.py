__version__ = '0.10.2'         
__author__ = 'pengyeqin'

def hello():
    print("Hello from ub-clean-test!")