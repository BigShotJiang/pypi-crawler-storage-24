"""Household resource for the NemlAI SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nemlai.client import NemlAI


class HouseholdResource:
    """Access household information."""

    def __init__(self, client: "NemlAI") -> None:
        self._client = client

    def info(self) -> str:
        """GET ``/cli/api/household`` -- show household details."""
        return self._client._get("/cli/api/household")
