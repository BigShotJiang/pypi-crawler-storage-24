"""Standalone auth helpers (signup) for the NemlAI SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nemlai.client import NemlAI


def signup(
    client: "NemlAI",
    name: str,
    email: str,
    password: str,
    nemlig_email: str,
    nemlig_password: str,
    invite_code: str = "",
) -> str:
    """POST ``/cli/api/auth/signup`` -- create a new account.

    WARNING: This transmits your Nemlig.com credentials to the NemlAI server,
    where they are stored to fetch your order history. Only proceed if you
    trust the NemlAI service with your Nemlig credentials.

    Parameters
    ----------
    client:
        An (unauthenticated) :class:`NemlAI` instance used to reach the server.
    name:
        Display name for the new account.
    email:
        Login email.
    password:
        Login password.
    nemlig_email:
        Nemlig.com account email.
    nemlig_password:
        Nemlig.com account password.
    invite_code:
        Optional invite code.

    Returns the parsed response body on success.
    """
    payload: dict = {
        "name": name,
        "email": email,
        "password": password,
        "nemlig_email": nemlig_email,
        "nemlig_password": nemlig_password,
    }
    if invite_code:
        payload["invite_code"] = invite_code
    return client._post("/cli/api/auth/signup", json=payload)
