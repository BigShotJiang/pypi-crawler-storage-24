"""Settings resource for the NemlAI SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from nemlai.client import NemlAI


class SettingsResource:
    """View and update user settings."""

    def __init__(self, client: "NemlAI") -> None:
        self._client = client

    def show(self) -> str:
        """GET ``/cli/api/settings`` -- show current settings."""
        return self._client._get("/cli/api/settings")

    _VALID_SETTINGS = {"budget", "size", "household_id", "user_id", "notifications"}

    def update(self, **kwargs: Any) -> str:
        """PUT ``/cli/api/settings`` -- update a setting.

        Pass ``key`` and ``value`` as keyword arguments.
        """
        unknown = set(kwargs.keys()) - self._VALID_SETTINGS
        if unknown:
            raise ValueError(f"Unknown settings: {', '.join(sorted(unknown))}")
        return self._client._put("/cli/api/settings", json=kwargs)
