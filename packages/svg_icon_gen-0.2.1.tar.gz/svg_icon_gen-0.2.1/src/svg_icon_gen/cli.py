#!/usr/bin/env python3
"""
Usage:
  Single file:  svg-icon-gen logo.svg
  Batch:        svg-icon-gen icon1.svg icon2.svg icon3.svg
  Glob:         svg-icon-gen assets/*.svg

Options:
  --ico-only      Generate ICO files only
  --mac-only      Generate macOS Template icons only
  --png-only      Generate PNG files only
  --no-dark       Skip dark theme variants
  --png-sizes     Comma-separated PNG sizes (default: 16,32,64,128,256,512)
  --out-dir       Root output directory (default: same directory as SVG)
"""

import argparse
import io
import os
import sys

import cairosvg
from PIL import Image, ImageOps


def svg_to_pil(svg_path: str, size: tuple[int, int]) -> Image.Image:
    """Rasterize an SVG at the given size and return a PIL RGBA image."""
    png_data = cairosvg.svg2png(
        url=svg_path,
        output_width=size[0],
        output_height=size[1],
    )
    return Image.open(io.BytesIO(png_data)).convert("RGBA")


def make_inverted(img: Image.Image) -> Image.Image:
    """Invert RGB channels while preserving the original alpha channel."""
    r, g, b, a = img.split()
    inv = ImageOps.invert(Image.merge("RGB", (r, g, b)))
    ir, ig, ib = inv.split()
    return Image.merge("RGBA", (ir, ig, ib, a))


def make_ico(img: Image.Image, output_path: str) -> None:
    """Save a multi-resolution ICO file from a single source image."""
    sizes = [(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
    frames = [img.resize(s, Image.Resampling.LANCZOS) for s in sizes]
    frames[0].save(
        output_path,
        format="ICO",
        append_images=frames[1:],
        sizes=sizes,
    )


def make_mac_template(
    svg_path: str,
    mac_size: tuple[int, int],
    inner_size: tuple[int, int],
    output_path: str,
    dark: bool = False,
) -> None:
    """
    Generate a macOS menu bar Template icon.

    dark=False: black pixels, transparent background.
                The system automatically adapts this for both light and dark
                menu bars when the file is named *Template.png.
    dark=True:  white pixels, for frameworks (e.g. Electron) that require
                an explicit white icon for dark menu bars.
    """
    rendered = svg_to_pil(svg_path, inner_size)
    canvas = Image.new("RGBA", mac_size, (0, 0, 0, 0))
    offset = (
        (mac_size[0] - inner_size[0]) // 2,
        (mac_size[1] - inner_size[1]) // 2,
    )
    canvas.paste(rendered, offset, rendered)

    fill_color = (255, 255, 255) if dark else (0, 0, 0)
    new_pixels = []
    for r, g, b, a in canvas.getdata():
        avg = (r + g + b) / 3
        alpha = a if (dark and avg >= 128) or (not dark and avg < 128) else 0
        new_pixels.append((*fill_color, alpha))

    canvas.putdata(new_pixels)
    canvas.save(output_path)


def process_svg(svg_path: str, args: argparse.Namespace) -> None:
    """Convert a single SVG file into all requested icon formats."""
    if not os.path.exists(svg_path):
        print(f"  ✗ File not found: {svg_path}")
        return

    stem = os.path.splitext(os.path.basename(svg_path))[0]

    # Output goes into a subfolder named after the SVG file
    base_root = args.out_dir if args.out_dir else os.path.dirname(os.path.abspath(svg_path))
    out_dir = os.path.join(base_root, stem)
    os.makedirs(out_dir, exist_ok=True)

    print(f"\n▶ {svg_path}  →  {out_dir}/")

    # Pre-render both light and dark base images at a high resolution
    base_light = svg_to_pil(svg_path, (512, 512))
    base_dark  = make_inverted(base_light) if not args.no_dark else None

    # ICO
    if not args.mac_only and not args.png_only:
        make_ico(base_light, os.path.join(out_dir, f"{stem}.ico"))
        print(f"  ✅ {stem}.ico")
        if base_dark is not None:
            make_ico(base_dark, os.path.join(out_dir, f"{stem}_dark.ico"))
            print(f"  ✅ {stem}_dark.ico")

    # macOS Template icons (black for system auto-adapt, white for dark menu bars)
    if not args.ico_only and not args.png_only:
        for suffix, dark_flag in [("", False), ("_dark", True)]:
            if dark_flag and args.no_dark:
                continue
            for scale, mac_sz, inner_sz in [
                ("",    (22, 22), (18, 18)),
                ("@2x", (44, 44), (36, 36)),
            ]:
                fname = f"{stem}_mac_template{suffix}{scale}.png"
                make_mac_template(
                    svg_path,
                    mac_sz,
                    inner_sz,
                    os.path.join(out_dir, fname),
                    dark=dark_flag,
                )
            label = "white (dark menu bar)" if dark_flag else "black (system auto-adapt)"
            print(f"  ✅ macOS template {label} x2  (1x + @2x)")

    # PNG exports for each size and theme
    if not args.ico_only and not args.mac_only:
        png_sizes = [int(s) for s in args.png_sizes.split(",")]
        for theme, img in [("light", base_light), ("dark", base_dark)]:
            if img is None:
                continue
            theme_dir = os.path.join(out_dir, "png", theme)
            os.makedirs(theme_dir, exist_ok=True)
            for s in png_sizes:
                img.resize((s, s), Image.Resampling.LANCZOS).save(
                    os.path.join(theme_dir, f"{stem}_{s}x{s}.png")
                )
        sizes_str = ", ".join(str(s) for s in png_sizes)
        themes = "light + dark" if not args.no_dark else "light only"
        print(f"  ✅ PNG {themes}  [{sizes_str}]")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Batch SVG converter: ICO / macOS Template / PNG",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument("svgs", nargs="+", metavar="FILE.svg", help="One or more SVG files")
    p.add_argument("--ico-only",  action="store_true", help="Generate ICO files only")
    p.add_argument("--mac-only",  action="store_true", help="Generate macOS Template icons only")
    p.add_argument("--png-only",  action="store_true", help="Generate PNG files only")
    p.add_argument("--no-dark",   action="store_true", help="Skip dark theme variants")
    p.add_argument("--png-sizes", default="16,32,64,128,256,512",
                   metavar="SIZES", help="Comma-separated PNG sizes (default: 16,32,64,128,256,512)")
    p.add_argument("--out-dir",   default=None, metavar="DIR",
                   help="Root output directory (default: same directory as each SVG)")
    return p


def main() -> None:
    if len(sys.argv) == 1:
        build_parser().print_help()
        sys.exit(0)

    args = build_parser().parse_args()

    exclusive = sum([args.ico_only, args.mac_only, args.png_only])
    if exclusive > 1:
        print("Error: --ico-only, --mac-only, and --png-only are mutually exclusive.")
        sys.exit(1)

    total = len(args.svgs)
    print(f"{total} file(s) to process")

    for svg in args.svgs:
        process_svg(svg, args)

    print("\n🎉 All done")


if __name__ == "__main__":
    main()
