from __future__ import annotations

import typer

from openrssgate.client import OpenRSSGateClient, format_json


def register(app: typer.Typer) -> None:
    @app.command("list")
    def list_sources(
        keyword: str | None = typer.Option(default=None),
        lang: str | None = typer.Option(None, "--lang"),
        source_type: str | None = typer.Option(None, "--type"),
        category: str | None = typer.Option(default=None),
        tag: str | None = typer.Option(default=None),
        page: int = typer.Option(default=1, min=1),
        limit: int = typer.Option(default=20, min=1, max=100),
        json_output: bool = typer.Option(False, "--json"),
    ) -> None:
        client = OpenRSSGateClient()
        payload = client.list_sources(
            keyword=keyword,
            language=lang,
            type=source_type,
            category=category,
            tag=tag,
            page=page,
            limit=limit,
        )

        if json_output:
            typer.echo(format_json(payload))
            return

        items = payload.get("items", [])
        if not items:
            typer.echo("No sources found.")
            return

        for item in items:
            tags = ", ".join(item.get("tags", [])) or "-"
            categories = ", ".join(item.get("categories", [])) or "-"
            typer.echo(
                f"{item['title']} [{item.get('language') or '-'} / {item.get('type') or '-'} / {categories}]"
            )
            typer.echo(f"  id: {item['id']}")
            typer.echo(f"  site: {item['site_url']}")
            typer.echo(f"  rss: {item['rss_url']}")
            typer.echo(f"  tags: {tags}")
            typer.echo(f"  last fetched: {item.get('last_fetched_at') or '-'}")
