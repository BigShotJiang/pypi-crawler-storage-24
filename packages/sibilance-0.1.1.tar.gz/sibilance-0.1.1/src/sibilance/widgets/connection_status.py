"""Connection status indicator widget.

Shows a small indicator in the header area showing WebSocket connection state.
"""

from __future__ import annotations

from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import Label


class ConnectionStatus(Widget):
    """Minimal connection status: green dot when connected, red when not."""

    DEFAULT_CSS = """
    ConnectionStatus {
        height: 1;
        width: auto;
        padding: 0 1;
    }
    ConnectionStatus .conn-label {
        width: auto;
    }
    """

    connected: reactive[bool] = reactive(False)

    def compose(self):  # type: ignore[override]
        yield Label(
            "[#ff6b6b]○ disconnected[/]",
            markup=True,
            classes="conn-label",
            id="conn-label",
        )

    def watch_connected(self, is_connected: bool) -> None:
        try:
            label = self.query_one("#conn-label", Label)
            if is_connected:
                label.update("[#6bcb77]● connected[/]")
            else:
                label.update("[#ff6b6b]○ disconnected[/]")
        except Exception:
            pass
