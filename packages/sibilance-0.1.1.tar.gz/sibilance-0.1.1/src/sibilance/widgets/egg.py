"""ASCII egg renderer for the hatching ceremony.

Four crack stages (0-3) rendered as Rich markup.
Simplified from the server's procedural PNG renderer.
"""

from __future__ import annotations

# ── Egg Palettes ──────────────────────────────────────────────────────────

PALETTES = [
    {"name": "Amber Warmth", "shell": "#c8a564", "glow": "#ffc864", "crack": "#ffe0a0"},
    {"name": "Twilight Violet", "shell": "#7850a0", "glow": "#8ca0ff", "crack": "#c8a0ff"},
    {"name": "Seafoam Tide", "shell": "#64b4aa", "glow": "#64f0dc", "crack": "#a0ffe0"},
    {"name": "Ember Heart", "shell": "#a03c3c", "glow": "#ff8c32", "crack": "#ffb464"},
    {"name": "Moonstone", "shell": "#b4b9c3", "glow": "#dce6ff", "crack": "#ffffff"},
    {"name": "Forest Moss", "shell": "#508c46", "glow": "#c8b450", "crack": "#e0d080"},
]


# ── ASCII Art Stages ──────────────────────────────────────────────────────

# Each stage is a list of strings. Placeholders:
#   {s} = shell color, {g} = glow color, {c} = crack color, {d} = dim

_EGG_STAGE_0 = [
    "        {s}▄████▄{d}",
    "      {s}▄██{g}░░░░{s}██▄{d}",
    "     {s}██{g}░░░░░░░░{s}██{d}",
    "    {s}██{g}░░░░░░░░░░{s}██{d}",
    "    {s}██{g}░░░░░░░░░░{s}██{d}",
    "    {s}██{g}░░░░░░░░░░{s}██{d}",
    "     {s}██{g}░░░░░░░░{s}██{d}",
    "      {s}▀██{g}░░░░{s}██▀{d}",
    "        {s}▀████▀{d}",
]

_EGG_STAGE_1 = [
    "        {s}▄████▄{d}",
    "      {s}▄██{g}░░{c}╱{g}░{s}██▄{d}",
    "     {s}██{g}░░░{c}╱{g}░░░░{s}██{d}",
    "    {s}██{g}░░░░░░░░░░{s}██{d}",
    "    {s}██{g}░░░░░░░░░░{s}██{d}",
    "    {s}██{g}░░░░░░░░░░{s}██{d}",
    "     {s}██{g}░░░░░░░░{s}██{d}",
    "      {s}▀██{g}░░░░{s}██▀{d}",
    "        {s}▀████▀{d}",
]

_EGG_STAGE_2 = [
    "        {s}▄█{c}╱{s}██▄{d}",
    "      {s}▄█{c}╱{s}█{g}░░{c}╲{g}░{s}██▄{d}",
    "     {s}██{g}░{c}╱{g}░░{c}╲{g}░░░{s}██{d}",
    "    {s}██{g}░░░░{c}╲{g}░░░░░{s}██{d}",
    "    {s}██{g}░░░░░{c}╱{g}░░░░{s}██{d}",
    "    {s}██{g}░░░{c}╱{g}░░░░░░{s}██{d}",
    "     {s}██{g}░{c}╱{g}░░░░░░{s}██{d}",
    "      {s}▀██{g}░░░░{s}██▀{d}",
    "        {s}▀████▀{d}",
]

_EGG_STAGE_3 = [
    "        {s}▄█{c}╱ ╲{s}▄{d}",
    "      {s}▄{c}╱ {s}█{g}░{c}╲ ╱{g}░{s}█▄{d}",
    "     {s}█{c}╱{g}░{c}╱  ╲{g}░░░{s}██{d}",
    "    {s}██{g}░{c}╱ ╱  ╲{g}░░░{s}██{d}",
    "    {s}██{g}░░{c}╱  ╱ ╲{g}░░{s}██{d}",
    "    {s}██{g}░{c}╱ ╱{g}░░░{c}╲{g}░░{s}██{d}",
    "     {s}██{c}╱{g}░░░░░░{s}██{d}",
    "      {s}▀█{c}╲{g}░░{c}╱{s}██▀{d}",
    "        {s}▀{c}╲╱{s}█▀{d}",
]

STAGES = [_EGG_STAGE_0, _EGG_STAGE_1, _EGG_STAGE_2, _EGG_STAGE_3]


def render_egg(palette_index: int = 0, crack_stage: int = 0) -> str:
    """Render an egg as Rich markup text.

    Args:
        palette_index: Index into PALETTES (0-5).
        crack_stage: Crack stage 0 (intact) through 3 (breaking).

    Returns:
        Rich markup string for the egg.
    """
    pal = PALETTES[palette_index % len(PALETTES)]
    stage = STAGES[max(0, min(3, crack_stage))]

    lines: list[str] = []
    for template in stage:
        line = template.format(
            s=f"[{pal['shell']}]",
            g=f"[{pal['glow']}]",
            c=f"[{pal['crack']}]",
            d="[/]",
        )
        lines.append(line)

    return "\n".join(lines)
