"""Sibilance — A living creature in your terminal."""

__version__ = "0.1.0"
