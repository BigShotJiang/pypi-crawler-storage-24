"""Theme manager for the Sibilance TUI.

Provides custom theme definitions and automatic day/night cycling
based on the world clock period.

Uses Textual's built-in Theme system: register themes at app startup,
then switch with `app.theme = "sibilance-midnight"`.
"""

from __future__ import annotations

from typing import Literal

from textual.theme import Theme

ThemeName = Literal["sibilance-midnight", "sibilance-dawn", "sibilance-dusk"]

# ── Theme definitions ────────────────────────────────────────────────

SIBILANCE_THEMES: dict[ThemeName, Theme] = {
    "sibilance-midnight": Theme(
        name="sibilance-midnight",
        primary="#7b68ee",       # medium slate blue
        secondary="#2a2a3e",     # border-dim
        warning="#ffd93d",       # gold
        error="#ff6b6b",         # coral
        success="#6bcb77",       # green
        accent="#ffd93d",        # warm accent
        foreground="#c8c8e0",    # primary text
        background="#0a0a0f",    # deep void
        surface="#12121a",       # panel
        panel="#1a1a2e",         # elevated surface
        dark=True,
    ),
    "sibilance-dawn": Theme(
        name="sibilance-dawn",
        primary="#d4a24e",       # golden accent
        secondary="#3e3528",     # warm border
        warning="#ffd93d",       # gold
        error="#e06040",         # warm coral
        success="#6bcb77",       # green
        accent="#ffd93d",        # warm accent
        foreground="#e0d8c8",    # warm text
        background="#1a1510",    # warm dark
        surface="#231e16",       # warm panel
        panel="#2e2518",         # warm surface
        dark=True,
    ),
    "sibilance-dusk": Theme(
        name="sibilance-dusk",
        primary="#e86848",       # sunset orange
        secondary="#352840",     # violet border
        warning="#ffaa3d",       # amber
        error="#ff6b6b",         # coral
        success="#6bcb77",       # green
        accent="#ffaa3d",        # amber accent
        foreground="#d8c8e0",    # violet text
        background="#120a14",    # deep violet
        surface="#1a1020",       # violet panel
        panel="#251830",         # violet surface
        dark=True,
    ),
}

# Map world periods to themes for automatic cycling
PERIOD_THEME: dict[str, ThemeName] = {
    "dawn": "sibilance-dawn",
    "morning": "sibilance-dawn",
    "afternoon": "sibilance-dawn",
    "dusk": "sibilance-dusk",
    "evening": "sibilance-midnight",
    "night": "sibilance-midnight",
}

DEFAULT_THEME: ThemeName = "sibilance-midnight"


def theme_for_period(period: str) -> ThemeName:
    """Return the appropriate theme for a world clock period."""
    return PERIOD_THEME.get(period, DEFAULT_THEME)
