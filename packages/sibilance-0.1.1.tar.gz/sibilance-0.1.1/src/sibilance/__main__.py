"""Entry point for `python -m sibilance` or the `sibilance` CLI command."""

from sibilance.app import SibilanceApp


def main() -> None:
    app = SibilanceApp()
    app.run()


if __name__ == "__main__":
    main()
