# Sibilance TUI

A living creature in your terminal — built with [Textual](https://textual.textualize.io/).

## Install

```bash
pip install sibilance
```

## Run

```bash
sibilance
# or
creature
# or
python -m sibilance
```

## Keybindings

| Key | Action |
|-----|--------|
| `d` | Dashboard |
| `c` | Chat |
| `j` | Journal |
| `f` | Friends |
| `w` | World |
| `t` | Den |
| `s` | Sleep |
| `a` | Account |
| `?` | Help |
| `Esc` | Back |
| `q` | Quit |
| `Ctrl+P` | Command palette |

## Web Mode

Serve the TUI as a web application:

```bash
pip install sibilance[serve]
python serve.py
# Open http://localhost:8000
```

Custom host/port via environment:

```bash
SIBILANCE_HOST=0.0.0.0 SIBILANCE_PORT=9000 python serve.py
```

## Standalone Binary

```bash
pip install pyinstaller
pyinstaller sibilance.spec
./dist/sibilance
```

## Docker

```bash
docker build -t sibilance-tui .
docker run -p 8000:8000 sibilance-tui
```

## Deploy to Fly.io

```bash
fly launch --copy-config
fly deploy
```

## Development

```bash
pip install -e ".[serve]"
sibilance
```
