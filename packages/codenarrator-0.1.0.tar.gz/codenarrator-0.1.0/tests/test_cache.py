"""Tests for cache module."""

from pathlib import Path

from codenarrator.core.cache import CacheManager


def test_cache_creation(tmp_path: Path):
    """Test cache manager creation."""
    cache = CacheManager(tmp_path)

    assert cache.cache_path == tmp_path / ".narrator" / "cache.json"
    assert cache._cache["version"] == 1


def test_file_hash_operations(tmp_path: Path):
    """Test file hash storage and retrieval."""
    cache = CacheManager(tmp_path)

    # Set file hash
    cache.set_file_hash(
        "src/main.py",
        "abc123",
        output_files=["docs/api/main.md"],
    )

    # Get file hash
    assert cache.get_file_hash("src/main.py") == "abc123"
    assert cache.get_output_files_for_source("src/main.py") == ["docs/api/main.md"]


def test_changed_files_detection(tmp_path: Path):
    """Test detection of changed files."""
    cache = CacheManager(tmp_path)

    # Set initial hashes
    cache.set_file_hash("file1.py", "hash1")
    cache.set_file_hash("file2.py", "hash2")

    # Check for changes
    current = {
        "file1.py": "hash1",  # Unchanged
        "file2.py": "hash3",  # Changed
        "file3.py": "hash4",  # New
    }

    changed = cache.get_changed_files(current)

    assert "file1.py" not in changed
    assert "file2.py" in changed
    assert "file3.py" in changed


def test_deleted_files_detection(tmp_path: Path):
    """Test detection of deleted files."""
    cache = CacheManager(tmp_path)

    # Set initial hashes
    cache.set_file_hash("file1.py", "hash1")
    cache.set_file_hash("file2.py", "hash2")

    # Current files (file2.py deleted)
    current = {
        "file1.py": "hash1",
    }

    deleted = cache.get_deleted_files(current)

    assert "file2.py" in deleted
    assert "file1.py" not in deleted


def test_issue_tracking(tmp_path: Path):
    """Test issue tracking in cache."""
    cache = CacheManager(tmp_path)

    # Add processed issues
    cache.add_processed_issue_ids([1, 2, 3])

    assert 1 in cache.get_processed_issue_ids()
    assert 2 in cache.get_processed_issue_ids()

    # Add more issues
    cache.add_processed_issue_ids([4, 5])

    assert len(cache.get_processed_issue_ids()) == 5


def test_stats_tracking(tmp_path: Path):
    """Test statistics tracking."""
    cache = CacheManager(tmp_path)

    cache.add_token_usage(100)
    cache.add_token_usage(50)
    cache.increment_run_count()

    stats = cache.get_stats()

    assert stats["total_tokens_used"] == 150
    assert stats["total_runs"] == 1


def test_cache_save_and_load(tmp_path: Path):
    """Test cache persistence."""
    cache1 = CacheManager(tmp_path)
    cache1.set_file_hash("test.py", "hash123")
    cache1.add_token_usage(500)
    cache1.save()

    # Load cache again
    cache2 = CacheManager(tmp_path)

    assert cache2.get_file_hash("test.py") == "hash123"
    assert cache2.get_stats()["total_tokens_used"] == 500


def test_cache_clear(tmp_path: Path):
    """Test cache clearing."""
    cache = CacheManager(tmp_path)
    cache.set_file_hash("test.py", "hash")
    cache.save()

    cache.clear()

    assert cache.get_file_hash("test.py") is None
    assert not cache.cache_path.exists()
