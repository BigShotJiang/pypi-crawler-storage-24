"""Tests for configuration module."""

from pathlib import Path

from codenarrator.core.config import (
    AnalysisConfig,
    Config,
    FAQConfig,
    LocalizationConfig,
    ProviderConfig,
    load_config,
)


def test_default_config():
    """Test default configuration values."""
    config = Config()

    assert config.version == 1
    assert config.provider.type == "openai"
    assert config.provider.model == "gpt-4o"
    assert "python" in config.analysis.languages
    assert config.localization.enabled is True


def test_provider_config():
    """Test provider configuration."""
    config = ProviderConfig(
        type="anthropic",
        model="claude-3-opus-20240229",
        api_key="test-key",
    )

    assert config.type == "anthropic"
    assert config.model == "claude-3-opus-20240229"
    assert config.api_key == "test-key"


def test_analysis_config():
    """Test analysis configuration."""
    config = AnalysisConfig(
        languages=["python", "typescript"],
        include_private=True,
    )

    assert "python" in config.languages
    assert "typescript" in config.languages
    assert config.include_private is True


def test_faq_config():
    """Test FAQ configuration."""
    config = FAQConfig(
        github_repo="owner/repo",
        labels=["bug", "question"],
        days_back=60,
    )

    assert config.github_repo == "owner/repo"
    assert "bug" in config.labels
    assert config.days_back == 60


def test_localization_config():
    """Test localization configuration."""
    config = LocalizationConfig(
        enabled=True,
        languages=["ru", "zh"],
        preserve_code=True,
    )

    assert config.enabled is True
    assert "ru" in config.languages
    assert "zh" in config.languages


def test_load_config_from_dict():
    """Test loading configuration from dictionary."""
    data = {
        "version": 1,
        "provider": {
            "type": "ollama",
            "model": "llama3",
        },
        "analysis": {
            "languages": ["python"],
        },
    }

    config = Config(**data)

    assert config.provider.type == "ollama"
    assert config.provider.model == "llama3"
    assert config.analysis.languages == ["python"]


def test_load_config_from_yaml(tmp_path: Path):
    """Test loading configuration from YAML file."""
    yaml_content = """
version: 1
provider:
  type: anthropic
  model: claude-3-sonnet
analysis:
  languages:
    - python
    - javascript
"""
    config_file = tmp_path / ".narrator.yaml"
    config_file.write_text(yaml_content)

    config = load_config(tmp_path, config_file)

    assert config.provider.type == "anthropic"
    assert config.provider.model == "claude-3-sonnet"
    assert "python" in config.analysis.languages
    assert "javascript" in config.analysis.languages


def test_load_config_missing_file(tmp_path: Path):
    """Test loading configuration when file doesn't exist."""
    config = load_config(tmp_path, tmp_path / "nonexistent.yaml")

    # Should return default config
    assert config.version == 1
    assert config.provider.type == "openai"
