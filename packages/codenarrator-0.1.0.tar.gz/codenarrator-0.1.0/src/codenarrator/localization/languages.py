"""Supported languages for localization."""

# Supported language codes
SUPPORTED_LANGUAGES = {
    "en",  # English (base)
    "ru",  # Russian
    "zh",  # Chinese (Simplified)
    "es",  # Spanish
    "fr",  # French
    "de",  # German
    "ja",  # Japanese
    "ko",  # Korean
    "pt",  # Portuguese
    "it",  # Italian
}

# Language names in English
LANGUAGE_NAMES = {
    "en": "English",
    "ru": "Russian",
    "zh": "Chinese (Simplified)",
    "es": "Spanish",
    "fr": "French",
    "de": "German",
    "ja": "Japanese",
    "ko": "Korean",
    "pt": "Portuguese",
    "it": "Italian",
}

# File suffixes for localized documentation
LANGUAGE_SUFFIX = {
    "en": "",        # English is default, no suffix
    "ru": ".ru",
    "zh": ".cn",     # Chinese uses .cn
    "es": ".es",
    "fr": ".fr",
    "de": ".de",
    "ja": ".ja",
    "ko": ".ko",
    "pt": ".pt",
    "it": ".it",
}

# Common technical terms to preserve
TECHNICAL_TERMS = {
    "API",
    "SDK",
    "CLI",
    "REST",
    "GraphQL",
    "HTTP",
    "HTTPS",
    "JSON",
    "XML",
    "YAML",
    "Docker",
    "Kubernetes",
    "Git",
    "GitHub",
    "npm",
    "pip",
    "Python",
    "JavaScript",
    "TypeScript",
    "Rust",
    "Go",
    "Java",
    "SQL",
    "NoSQL",
    "WebSocket",
    "OAuth",
    "JWT",
    "CI/CD",
    "DevOps",
    "SaaS",
    "PaaS",
    "IaaS",
}
