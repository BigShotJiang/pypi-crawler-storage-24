"""Localization module for CodeNarrator."""

from codenarrator.localization.languages import LANGUAGE_NAMES, SUPPORTED_LANGUAGES
from codenarrator.localization.translator import Translator

__all__ = ["Translator", "SUPPORTED_LANGUAGES", "LANGUAGE_NAMES"]
