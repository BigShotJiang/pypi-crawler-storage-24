"""Translator module for documentation localization."""

import re
from pathlib import Path

from codenarrator.core.config import Config
from codenarrator.localization.languages import (
    LANGUAGE_SUFFIX,
    SUPPORTED_LANGUAGES,
    TECHNICAL_TERMS,
)
from codenarrator.providers.base import BaseProvider


class Translator:
    """Translate documentation to multiple languages."""

    def __init__(self, provider: BaseProvider, config: Config):
        """
        Initialize translator.

        Args:
            provider: AI provider for translation
            config: Configuration object
        """
        self.provider = provider
        self.config = config

    async def translate(
        self,
        content: str,
        target_language: str,
        preserve_code: bool = True,
        preserve_terms: list[str] | None = None,
    ) -> str:
        """
        Translate content to target language.

        Args:
            content: Content to translate
            target_language: Target language code
            preserve_code: Whether to preserve code blocks
            preserve_terms: Additional terms to preserve

        Returns:
            Translated content
        """
        if target_language not in SUPPORTED_LANGUAGES:
            raise ValueError(f"Unsupported language: {target_language}")

        # Combine default and custom preserve terms
        all_terms = list(TECHNICAL_TERMS)
        if preserve_terms:
            all_terms.extend(preserve_terms)

        if preserve_code:
            # Extract code blocks and replace with placeholders
            content, code_blocks = self._extract_code_blocks(content)

        # Translate using AI
        translated = await self.provider.translate(
            text=content,
            target_language=target_language,
            preserve_code=preserve_code,
            preserve_terms=all_terms,
        )

        if preserve_code:
            # Restore code blocks
            translated = self._restore_code_blocks(translated, code_blocks)

        return translated

    def _extract_code_blocks(self, content: str) -> tuple[str, list[str]]:
        """
        Extract code blocks and replace with placeholders.

        Returns:
            Tuple of (content with placeholders, list of code blocks)
        """
        code_blocks = []
        placeholder_template = "___CODE_BLOCK_{}___"

        # Match fenced code blocks
        pattern = r"```[\s\S]*?```"

        def replace(match):
            idx = len(code_blocks)
            code_blocks.append(match.group(0))
            return placeholder_template.format(idx)

        modified = re.sub(pattern, replace, content)

        # Also match inline code
        inline_pattern = r"`[^`]+`"

        def replace_inline(match):
            idx = len(code_blocks)
            code_blocks.append(match.group(0))
            return placeholder_template.format(idx)

        modified = re.sub(inline_pattern, replace_inline, modified)

        return modified, code_blocks

    def _restore_code_blocks(self, content: str, code_blocks: list[str]) -> str:
        """Restore code blocks from placeholders."""
        for idx, block in enumerate(code_blocks):
            placeholder = f"___CODE_BLOCK_{idx}___"
            content = content.replace(placeholder, block)
        return content

    async def translate_file(
        self,
        source_path: Path,
        target_language: str,
        output_path: Path | None = None,
    ) -> Path:
        """
        Translate a documentation file.

        Args:
            source_path: Path to source file
            target_language: Target language code
            output_path: Optional output path (auto-generated if not provided)

        Returns:
            Path to translated file
        """
        content = source_path.read_text(encoding="utf-8")

        translated = await self.translate(
            content=content,
            target_language=target_language,
            preserve_code=self.config.localization.preserve_code,
            preserve_terms=self.config.localization.preserve_terms,
        )

        # Generate output path if not provided
        if not output_path:
            suffix = LANGUAGE_SUFFIX.get(target_language, f".{target_language}")
            stem = source_path.stem

            # Remove existing language suffix if present
            for lang_suffix in LANGUAGE_SUFFIX.values():
                if lang_suffix and stem.endswith(lang_suffix):
                    stem = stem[: -len(lang_suffix)]
                    break

            output_path = source_path.parent / f"{stem}{suffix}{source_path.suffix}"

        # Write translated content
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(translated, encoding="utf-8")

        return output_path

    async def translate_all(
        self,
        docs_dir: Path,
        target_languages: list[str] | None = None,
        file_patterns: list[str] | None = None,
    ) -> dict[str, list[Path]]:
        """
        Translate all documentation files.

        Args:
            docs_dir: Documentation directory
            target_languages: Languages to translate to (uses config if not provided)
            file_patterns: File patterns to match (default: *.md)

        Returns:
            Dictionary mapping language codes to lists of created files
        """
        target_languages = target_languages or self.config.localization.languages
        file_patterns = file_patterns or ["*.md"]

        results: dict[str, list[Path]] = {lang: [] for lang in target_languages}

        # Find all matching files
        for pattern in file_patterns:
            for source_file in docs_dir.rglob(pattern):
                # Skip already translated files
                if self._is_localized_file(source_file):
                    continue

                # Translate to each target language
                for lang in target_languages:
                    try:
                        output_file = await self.translate_file(
                            source_path=source_file,
                            target_language=lang,
                        )
                        results[lang].append(output_file)
                    except Exception as e:
                        # Log error but continue with other files
                        print(f"Error translating {source_file} to {lang}: {e}")

        return results

    def _is_localized_file(self, file_path: Path) -> bool:
        """Check if a file is already a localized version."""
        stem = file_path.stem

        for lang_suffix in LANGUAGE_SUFFIX.values():
            if lang_suffix and stem.endswith(lang_suffix):
                return True

        return False

    def get_localized_filename(
        self,
        original_name: str,
        language: str,
    ) -> str:
        """
        Generate localized filename.

        Args:
            original_name: Original filename
            language: Target language code

        Returns:
            Localized filename
        """
        path = Path(original_name)
        suffix = LANGUAGE_SUFFIX.get(language, f".{language}")
        stem = path.stem

        # Remove existing language suffix if present
        for lang_suffix in LANGUAGE_SUFFIX.values():
            if lang_suffix and stem.endswith(lang_suffix):
                stem = stem[: -len(lang_suffix)]
                break

        return f"{stem}{suffix}{path.suffix}"
