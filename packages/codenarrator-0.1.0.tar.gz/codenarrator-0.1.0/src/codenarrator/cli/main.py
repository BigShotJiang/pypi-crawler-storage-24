"""Main CLI module with Typer commands."""

from pathlib import Path

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from codenarrator import __version__
from codenarrator.core.config import Config, load_config
from codenarrator.core.project import ProjectScanner

app = typer.Typer(
    name="codenarrator",
    help="CLI utility for automatic documentation generation from source code and GitHub Issues using AI.",
    add_completion=False,
)
console = Console()


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        console.print(f"[bold blue]CodeNarrator[/bold blue] version {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        False,
        "--version",
        "-v",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    """CodeNarrator - Auto-Doc Generator."""
    pass


@app.command()
def init(
    path: Path = typer.Argument(
        ".",
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        help="Path to the project directory.",
    ),
    provider: str = typer.Option(
        "openai",
        "--provider",
        "-p",
        help="AI provider to use (openai, anthropic, ollama).",
    ),
    model: str = typer.Option(
        "gpt-4o",
        "--model",
        "-m",
        help="Model to use for analysis.",
    ),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output directory for documentation (default: docs/).",
    ),
    languages: str | None = typer.Option(
        None,
        "--languages",
        "-l",
        help="Comma-separated list of target languages for localization (e.g., ru,zh,es).",
    ),
    config_file: Path | None = typer.Option(
        None,
        "--config",
        "-c",
        help="Path to configuration file.",
    ),
) -> None:
    """
    Initialize documentation for a project.

    Performs full analysis of the project and creates the /docs folder
    with README, API documentation, and architecture diagrams.
    """
    console.print(f"[bold green]Initializing CodeNarrator for:[/bold green] {path.absolute()}")

    # Load or create configuration
    config = _load_or_create_config(path, config_file, provider, model, output, languages)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        # Scan project
        task = progress.add_task("Scanning project structure...", total=None)
        scanner = ProjectScanner(path, config)
        project_info = scanner.scan()
        progress.update(task, description=f"Found {len(project_info.source_files)} source files")

        # TODO: Run code analysis
        progress.update(task, description="Analyzing code...")

        # TODO: Generate README
        progress.update(task, description="Generating README...")

        # TODO: Generate API documentation
        progress.update(task, description="Generating API documentation...")

        # TODO: Generate architecture diagrams
        progress.update(task, description="Generating architecture diagrams...")

        # TODO: Generate localization if enabled
        if config.localization.enabled:
            progress.update(task, description="Generating localizations...")

    console.print("\n[bold green]✓[/bold green] Documentation initialized successfully!")
    console.print(f"  Output directory: [blue]{config.output.docs_dir}[/blue]")


@app.command()
def update(
    path: Path = typer.Argument(
        ".",
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        help="Path to the project directory.",
    ),
    incremental: bool = typer.Option(
        True,
        "--incremental/--full",
        help="Update only changed files (incremental) or regenerate all (full).",
    ),
    config_file: Path | None = typer.Option(
        None,
        "--config",
        "-c",
        help="Path to configuration file.",
    ),
) -> None:
    """
    Update documentation incrementally.

    Only updates sections for files that have changed since the last run,
    saving tokens and time.
    """
    console.print(f"[bold blue]Updating documentation for:[/bold blue] {path.absolute()}")

    # Load configuration
    load_config(path, config_file)

    if incremental:
        console.print("[dim]Running in incremental mode...[/dim]")
        # TODO: Load cache and detect changes
    else:
        console.print("[dim]Running full regeneration...[/dim]")

    # TODO: Implement update logic

    console.print("\n[bold green]✓[/bold green] Documentation updated successfully!")


@app.command()
def faq_sync(
    path: Path = typer.Argument(
        ".",
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        help="Path to the project directory.",
    ),
    repo: str | None = typer.Option(
        None,
        "--repo",
        "-r",
        help="GitHub repository in format 'owner/repo'.",
    ),
    days: int = typer.Option(
        30,
        "--days",
        "-d",
        help="Number of days to look back for closed issues.",
    ),
    labels: str | None = typer.Option(
        None,
        "--labels",
        help="Comma-separated list of issue labels to filter (e.g., bug,question).",
    ),
    config_file: Path | None = typer.Option(
        None,
        "--config",
        "-c",
        help="Path to configuration file.",
    ),
) -> None:
    """
    Sync FAQ from GitHub Issues.

    Fetches closed issues, clusters similar problems, and generates
    FAQ entries with answers based on issue discussions and fixes.
    """
    console.print("[bold blue]Syncing FAQ from GitHub Issues...[/bold blue]")

    # Load configuration
    config = load_config(path, config_file)

    # Determine repository
    github_repo = repo or config.faq.github_repo
    if not github_repo:
        console.print("[red]Error: No GitHub repository specified. Use --repo or configure in .narrator.yaml[/red]")
        raise typer.Exit(1)

    console.print(f"  Repository: [blue]{github_repo}[/blue]")
    console.print(f"  Looking back: [blue]{days}[/blue] days")

    # Parse labels
    labels.split(",") if labels else config.faq.labels

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Fetching issues from GitHub...", total=None)

        # TODO: Implement FAQ sync
        progress.update(task, description="Clustering similar issues...")
        progress.update(task, description="Generating FAQ entries...")

    console.print("\n[bold green]✓[/bold green] FAQ synced successfully!")


@app.command()
def config(
    path: Path = typer.Argument(
        ".",
        exists=True,
        file_okay=False,
        dir_okay=True,
        help="Path to the project directory.",
    ),
    show: bool = typer.Option(
        False,
        "--show",
        "-s",
        help="Show current configuration.",
    ),
) -> None:
    """
    Manage CodeNarrator configuration.

    Creates a default .narrator.yaml configuration file in the project directory.
    """
    config_path = path / ".narrator.yaml"

    if show:
        if config_path.exists():
            console.print("[bold]Current configuration:[/bold]\n")
            console.print(config_path.read_text())
        else:
            console.print("[yellow]No configuration file found.[/yellow]")
        return

    if config_path.exists():
        console.print("[yellow]Configuration file already exists.[/yellow]")
        overwrite = typer.confirm("Overwrite?", default=False)
        if not overwrite:
            raise typer.Exit()

    # Create default config
    _create_default_config(config_path)
    console.print(f"[bold green]✓[/bold green] Created configuration file: {config_path}")


def _load_or_create_config(
    path: Path,
    config_file: Path | None,
    provider: str,
    model: str,
    output: Path | None,
    languages: str | None,
) -> Config:
    """Load existing config or create from CLI arguments."""
    if config_file and config_file.exists():
        return load_config(path, config_file)

    # Check for default config file
    default_config = path / ".narrator.yaml"
    if default_config.exists():
        return load_config(path, default_config)

    # Create config from CLI arguments
    from codenarrator.core.config import (
        AnalysisConfig,
        FAQConfig,
        LocalizationConfig,
        OutputConfig,
        ProviderConfig,
    )

    return Config(
        provider=ProviderConfig(type=provider, model=model),
        analysis=AnalysisConfig(),
        faq=FAQConfig(),
        localization=LocalizationConfig(
            enabled=languages is not None,
            languages=languages.split(",") if languages else [],
        ),
        output=OutputConfig(
            docs_dir=str(output) if output else "docs",
        ),
    )


def _create_default_config(config_path: Path) -> None:
    """Create a default configuration file."""
    default_config = """# CodeNarrator Configuration
# https://github.com/codenarrator/codenarrator

version: 1

# Project settings (auto-detected if not specified)
project:
  name: null
  description: null
  entry_points:
    - main.py
    - src/**/__init__.py

# AI Provider configuration
provider:
  type: openai          # openai | anthropic | ollama
  model: gpt-4o         # Model for code analysis
  translation_model: gpt-4o-mini  # Model for translations

# Code analysis settings
analysis:
  languages:
    - python
    - javascript
  ignore:
    - node_modules/**
    - .venv/**
    - "**/tests/**"
    - "**/__pycache__/**"
  include_private: false

# FAQ generation settings
faq:
  github_repo: null     # Format: owner/repo
  labels:
    - bug
    - question
    - help wanted
  days_back: 30

# Localization settings
localization:
  enabled: true
  languages:
    - ru
    - zh
    - es
  preserve_code: true

# Output settings
output:
  docs_dir: docs
  readme_template: default
"""
    config_path.write_text(default_config)


if __name__ == "__main__":
    app()
