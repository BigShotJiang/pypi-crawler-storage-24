"""CLI module for CodeNarrator."""

from codenarrator.cli.main import app

__all__ = ["app"]
