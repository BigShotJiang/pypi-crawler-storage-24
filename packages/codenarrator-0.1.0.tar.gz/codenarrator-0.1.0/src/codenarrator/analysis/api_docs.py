"""API documentation generator module."""

from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape

from codenarrator.analysis.parser import ParsedModule
from codenarrator.core.config import Config
from codenarrator.providers.base import AnalysisResult, BaseProvider


class ApiDocsGenerator:
    """Generate API documentation from parsed code."""

    def __init__(self, provider: BaseProvider, config: Config):
        """
        Initialize API docs generator.

        Args:
            provider: AI provider for content generation
            config: Configuration object
        """
        self.provider = provider
        self.config = config
        self.env = Environment(
            loader=FileSystemLoader(Path(__file__).parent / "templates"),
            autoescape=select_autoescape(default=False),
        )

    async def generate_module_docs(
        self,
        module_name: str,
        parsed: ParsedModule,
        analysis: AnalysisResult | None = None,
    ) -> str:
        """
        Generate API documentation for a module.

        Args:
            module_name: Name of the module
            parsed: Parsed module information
            analysis: Optional AI analysis result

        Returns:
            Generated API documentation in Markdown
        """
        # Use AI to enhance documentation if analysis is available
        if analysis:
            return await self.provider.generate_api_docs(
                module_name=module_name,
                analysis=analysis,
                include_private=self.config.analysis.include_private,
            )

        # Fallback to template-based generation
        return self._generate_from_parsed(module_name, parsed)

    def _generate_from_parsed(self, module_name: str, parsed: ParsedModule) -> str:
        """Generate documentation from parsed code without AI."""
        sections = []

        # Module header
        sections.append(f"# `{module_name}`\n")

        # Module docstring
        if parsed.module_docstring:
            sections.append(f"\n{parsed.module_docstring}\n")

        # Functions
        if parsed.functions:
            sections.append("\n## Functions\n")
            for func in parsed.functions:
                if not self.config.analysis.include_private and func.is_private:
                    continue
                sections.append(self._format_function(func))

        # Classes
        if parsed.classes:
            sections.append("\n## Classes\n")
            for cls in parsed.classes:
                if not self.config.analysis.include_private and cls.is_private:
                    continue
                sections.append(self._format_class(cls))

        return "\n".join(sections)

    def _format_function(self, func) -> str:
        """Format a function for documentation."""
        lines = []

        # Function signature
        params_str = ", ".join(
            f"{p['name']}" + (f": {p['type']}" if p.get("type") else "") + (f" = {p['default']}" if p.get("default") else "")
            for p in func.parameters
        )

        async_str = "async " if func.is_async else ""
        return_str = f" -> {func.return_type}" if func.return_type else ""

        lines.append(f"### `{async_str}{func.name}({params_str}){return_str}`\n")

        # Decorators
        if func.decorators:
            lines.append("**Decorators:** " + ", ".join(func.decorators) + "\n")

        # Docstring
        if func.docstring:
            lines.append(f"\n{func.docstring}\n")

        # Parameters
        if func.parameters:
            lines.append("\n**Parameters:**\n")
            for p in func.parameters:
                param_line = f"- `{p['name']}`"
                if p.get("type"):
                    param_line += f" (`{p['type']}`)"
                if p.get("default"):
                    param_line += f" — default: `{p['default']}`"
                lines.append(param_line)

        # Return type
        if func.return_type:
            lines.append(f"\n**Returns:** `{func.return_type}`\n")

        return "\n".join(lines)

    def _format_class(self, cls) -> str:
        """Format a class for documentation."""
        lines = []

        # Class signature
        bases_str = f"({', '.join(cls.bases)})" if cls.bases else ""
        lines.append(f"### `class {cls.name}{bases_str}`\n")

        # Decorators
        if cls.decorators:
            lines.append("**Decorators:** " + ", ".join(cls.decorators) + "\n")

        # Docstring
        if cls.docstring:
            lines.append(f"\n{cls.docstring}\n")

        # Attributes
        if cls.attributes:
            lines.append("\n**Attributes:**\n")
            for attr in cls.attributes:
                lines.append(f"- `{attr['name']}`: `{attr.get('value', '')}`")

        # Methods
        if cls.methods:
            lines.append("\n**Methods:**\n")
            for method in cls.methods:
                if not self.config.analysis.include_private and method.is_private:
                    continue
                method_str = self._format_method(method)
                lines.append(method_str)

        return "\n".join(lines)

    def _format_method(self, method) -> str:
        """Format a method for documentation."""
        params_str = ", ".join(
            f"{p['name']}" + (f" = {p['default']}" if p.get("default") else "")
            for p in method.parameters
        )

        async_str = "async " if method.is_async else ""
        return_str = f" -> {method.return_type}" if method.return_type else ""

        line = f"- `{async_str}{method.name}({params_str}){return_str}`"

        if method.docstring:
            # First line of docstring as summary
            summary = method.docstring.split("\n")[0]
            line += f" — {summary}"

        return line

    async def generate_index(
        self,
        modules: dict[str, ParsedModule],
        output_dir: Path,
    ) -> str:
        """
        Generate an index page for all API modules.

        Args:
            modules: Dictionary of module names to parsed modules
            output_dir: Output directory for relative links

        Returns:
            Generated index content
        """
        lines = ["# API Reference\n"]
        lines.append("This section provides detailed API documentation for all modules.\n")
        lines.append("## Modules\n")

        for module_name, parsed in sorted(modules.items()):
            # Create relative link
            link = module_name.replace("/", "-").replace(".py", "")
            description = parsed.module_docstring.split("\n")[0] if parsed.module_docstring else ""
            lines.append(f"- [`{module_name}`](./{link}.md) — {description}")

        return "\n".join(lines)
