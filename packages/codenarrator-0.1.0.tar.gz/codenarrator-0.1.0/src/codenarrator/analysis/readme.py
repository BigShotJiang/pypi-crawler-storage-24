"""README generator module."""

from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape

from codenarrator.core.config import Config
from codenarrator.core.project import ProjectInfo
from codenarrator.providers.base import AnalysisResult, BaseProvider


class ReadmeGenerator:
    """Generate README.md from project analysis."""

    def __init__(self, provider: BaseProvider, config: Config):
        """
        Initialize README generator.

        Args:
            provider: AI provider for content generation
            config: Configuration object
        """
        self.provider = provider
        self.config = config
        self.env = Environment(
            loader=FileSystemLoader(Path(__file__).parent / "templates"),
            autoescape=select_autoescape(default=False),
        )

    async def generate(
        self,
        project_info: ProjectInfo,
        entry_analysis: dict[str, AnalysisResult],
        examples: list[str],
    ) -> str:
        """
        Generate README.md content.

        Args:
            project_info: Scanned project information
            entry_analysis: Analysis results for entry points
            examples: Extracted usage examples

        Returns:
            Generated README content
        """
        # Combine entry point analyses
        combined_analysis = self._combine_analyses(entry_analysis)

        # Generate README using AI
        readme_content = await self.provider.generate_readme(
            project_name=project_info.name,
            description=project_info.description or combined_analysis.description,
            entry_point_analysis=combined_analysis,
            dependencies=project_info.dependencies,
            examples=examples,
        )

        # Post-process content
        readme_content = self._post_process(readme_content, project_info)

        return readme_content

    def _combine_analyses(self, analyses: dict[str, AnalysisResult]) -> AnalysisResult:
        """Combine multiple analysis results into one."""
        if not analyses:
            return AnalysisResult(
                description="",
                summary="",
                functions=[],
                classes=[],
                imports=[],
                examples=[],
            )

        if len(analyses) == 1:
            return list(analyses.values())[0]

        # Combine all analyses
        combined = AnalysisResult(
            description="",
            summary="",
            functions=[],
            classes=[],
            imports=[],
            examples=[],
        )

        descriptions = []
        summaries = []

        for name, analysis in analyses.items():
            if analysis.description:
                descriptions.append(f"**{name}**: {analysis.description}")
            if analysis.summary:
                summaries.append(analysis.summary)
            combined.functions.extend(analysis.functions)
            combined.classes.extend(analysis.classes)
            combined.imports.extend(analysis.imports)
            combined.examples.extend(analysis.examples)

        combined.description = "\n\n".join(descriptions)
        combined.summary = summaries[0] if summaries else ""

        return combined

    def _post_process(self, content: str, project_info: ProjectInfo) -> str:
        """Post-process README content."""
        # Add badges if not present
        if "[!" not in content:
            badges = self._generate_badges(project_info)
            content = badges + "\n\n" + content

        # Ensure license section
        if "## License" not in content.lower() and project_info.license_file:
            content += f"\n\n## License\n\nThis project is licensed under the terms specified in the {project_info.license_file} file."

        return content

    def _generate_badges(self, project_info: ProjectInfo) -> str:
        """Generate status badges for README."""
        badges = []

        # Python version badge
        if "python" in project_info.dependencies:
            badges.append("![Python](https://img.shields.io/badge/python-3.11+-blue.svg)")

        # License badge
        if project_info.license_file:
            badges.append("![License](https://img.shields.io/badge/license-MIT-green.svg)")

        # Documentation badge
        badges.append("![Docs](https://img.shields.io/badge/docs-generated-brightgreen.svg)")

        return " ".join(badges)

    def generate_minimal(self, project_info: ProjectInfo) -> str:
        """Generate minimal README without AI (fallback)."""
        template = self.env.get_template("readme_minimal.md.j2")

        return template.render(
            name=project_info.name,
            description=project_info.description or "A software project.",
            dependencies=project_info.dependencies,
            has_readme=project_info.readme_exists,
        )
