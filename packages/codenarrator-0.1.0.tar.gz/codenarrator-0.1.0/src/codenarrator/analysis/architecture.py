"""Architecture documentation generator with Mermaid diagrams."""

from collections import defaultdict
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape

from codenarrator.analysis.parser import ParsedModule
from codenarrator.core.config import Config
from codenarrator.providers.base import AnalysisResult, BaseProvider


class ArchitectureGenerator:
    """Generate architecture documentation with Mermaid diagrams."""

    def __init__(self, provider: BaseProvider, config: Config):
        """
        Initialize architecture generator.

        Args:
            provider: AI provider for content generation
            config: Configuration object
        """
        self.provider = provider
        self.config = config
        self.env = Environment(
            loader=FileSystemLoader(Path(__file__).parent / "templates"),
            autoescape=select_autoescape(default=False),
        )

    async def generate(
        self,
        modules: dict[str, ParsedModule],
        analyses: dict[str, AnalysisResult] | None = None,
    ) -> str:
        """
        Generate architecture documentation.

        Args:
            modules: Dictionary of module names to parsed modules
            analyses: Optional AI analysis results

        Returns:
            Generated architecture documentation
        """
        # Build dependency graph
        dependencies = self._build_dependency_graph(modules)

        # Generate using AI if analyses available
        if analyses:
            return await self.provider.generate_architecture(
                modules=analyses,
                dependencies=dependencies,
            )

        # Fallback to template-based generation
        return self._generate_from_modules(modules, dependencies)

    def _build_dependency_graph(
        self,
        modules: dict[str, ParsedModule],
    ) -> dict[str, list[str]]:
        """
        Build a dependency graph from parsed modules.

        Args:
            modules: Dictionary of module names to parsed modules

        Returns:
            Dictionary mapping module names to their dependencies
        """
        dependencies = defaultdict(set)
        module_names = set(modules.keys())

        for module_name, parsed in modules.items():
            for imp in parsed.imports:
                # Try to match internal modules
                for target in module_names:
                    if target in imp.module or any(target in n for n in imp.names):
                        dependencies[module_name].add(target)

        # Convert sets to lists
        return {k: list(v) for k, v in dependencies.items()}

    def _generate_from_modules(
        self,
        modules: dict[str, ParsedModule],
        dependencies: dict[str, list[str]],
    ) -> str:
        """Generate architecture documentation without AI."""
        sections = []

        # Header
        sections.append("# Architecture\n")
        sections.append("This document describes the architecture of the project.\n")

        # Overview
        sections.append("## Overview\n")
        sections.append(f"The project consists of {len(modules)} modules.\n")

        # Mermaid diagram
        sections.append("## Module Dependencies\n")
        sections.append("```mermaid")
        sections.append(self._generate_mermaid_diagram(modules, dependencies))
        sections.append("```\n")

        # Module descriptions
        sections.append("## Modules\n")
        for module_name, parsed in sorted(modules.items()):
            sections.append(self._format_module_section(module_name, parsed))

        # Data flow
        sections.append("## Data Flow\n")
        sections.append(self._describe_data_flow(modules, dependencies))

        return "\n".join(sections)

    def _generate_mermaid_diagram(
        self,
        modules: dict[str, ParsedModule],
        dependencies: dict[str, list[str]],
    ) -> str:
        """Generate Mermaid flowchart for module dependencies."""
        lines = ["flowchart TD"]

        # Add nodes
        for module_name in modules:
            node_id = self._get_node_id(module_name)
            label = Path(module_name).stem
            lines.append(f"    {node_id}[{label}]")

        # Add edges
        for module_name, deps in dependencies.items():
            source_id = self._get_node_id(module_name)
            for dep in deps:
                target_id = self._get_node_id(dep)
                lines.append(f"    {source_id} --> {target_id}")

        return "\n".join(lines)

    def _get_node_id(self, module_name: str) -> str:
        """Convert module name to valid Mermaid node ID."""
        return module_name.replace("/", "_").replace(".", "_").replace("-", "_")

    def _format_module_section(self, module_name: str, parsed: ParsedModule) -> str:
        """Format a module section for documentation."""
        lines = []

        lines.append(f"### {module_name}\n")

        if parsed.module_docstring:
            lines.append(f"{parsed.module_docstring}\n")

        # Statistics
        lines.append("**Contents:**")
        if parsed.functions:
            lines.append(f"- {len(parsed.functions)} functions")
        if parsed.classes:
            lines.append(f"- {len(parsed.classes)} classes")
        lines.append("")

        # Key exports
        if parsed.functions or parsed.classes:
            lines.append("**Key components:**")
            for func in parsed.functions[:5]:  # Limit to first 5
                if not func.is_private:
                    lines.append(f"- `{func.name}()`")
            for cls in parsed.classes[:5]:
                if not cls.is_private:
                    lines.append(f"- `{cls.name}`")
            lines.append("")

        return "\n".join(lines)

    def _describe_data_flow(
        self,
        modules: dict[str, ParsedModule],
        dependencies: dict[str, list[str]],
    ) -> str:
        """Generate data flow description."""
        lines = []

        # Find entry points (modules with no incoming dependencies)
        all_deps = set()
        for deps in dependencies.values():
            all_deps.update(deps)

        entry_points = [m for m in modules if m not in all_deps]

        if entry_points:
            lines.append("**Entry Points:**")
            for ep in entry_points:
                lines.append(f"- `{ep}`")
            lines.append("")

        # Find core modules (most dependencies)
        dep_counts = defaultdict(int)
        for deps in dependencies.values():
            for dep in deps:
                dep_counts[dep] += 1

        core_modules = sorted(dep_counts.items(), key=lambda x: x[1], reverse=True)[:5]

        if core_modules:
            lines.append("**Core Modules** (most referenced):")
            for module, count in core_modules:
                lines.append(f"- `{module}` (referenced {count} times)")
            lines.append("")

        return "\n".join(lines)

    def generate_sequence_diagram(
        self,
        flow_name: str,
        steps: list[dict[str, str]],
    ) -> str:
        """
        Generate a Mermaid sequence diagram.

        Args:
            flow_name: Name of the flow
            steps: List of steps with 'from', 'to', 'message' keys

        Returns:
            Mermaid sequence diagram code
        """
        lines = ["sequenceDiagram", f"    title {flow_name}"]

        participants = set()
        for step in steps:
            participants.add(step["from"])
            participants.add(step["to"])

        for participant in sorted(participants):
            lines.append(f"    participant {participant}")

        for step in steps:
            lines.append(f"    {step['from']}->>{step['to']}: {step['message']}")

        return "\n".join(lines)

    def generate_class_diagram(
        self,
        modules: dict[str, ParsedModule],
    ) -> str:
        """
        Generate a Mermaid class diagram.

        Args:
            modules: Dictionary of module names to parsed modules

        Returns:
            Mermaid class diagram code
        """
        lines = ["classDiagram"]

        for _module_name, parsed in modules.items():
            for cls in parsed.classes:
                if cls.is_private and not self.config.analysis.include_private:
                    continue

                class_name = cls.name

                # Add class with attributes
                for attr in cls.attributes:
                    attr_name = attr.get("name", "")
                    lines.append(f"    class {class_name} {{")
                    lines.append(f"        +{attr_name}")
                    lines.append("    }")

                # Add methods
                for method in cls.methods:
                    if method.is_private and not self.config.analysis.include_private:
                        continue
                    visibility = "-" if method.is_private else "+"
                    params = ", ".join(p["name"] for p in method.parameters)
                    lines.append(f"    {class_name} : {visibility}{method.name}({params})")

                # Add inheritance
                for base in cls.bases:
                    lines.append(f"    {base} <|-- {class_name}")

        return "\n".join(lines)
