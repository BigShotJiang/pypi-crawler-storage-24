"""Code parser using Tree-sitter for AST analysis."""

from dataclasses import dataclass, field
from pathlib import Path

from tree_sitter import Language, Parser

# Language mappings for Tree-sitter
LANGUAGE_MODULES = {
    "python": "tree_sitter_python",
    "javascript": "tree_sitter_javascript",
    "typescript": "tree_sitter_typescript",
    # Add more languages as needed
}


@dataclass
class FunctionInfo:
    """Information about a parsed function."""

    name: str
    parameters: list[dict[str, str]]
    return_type: str | None = None
    docstring: str | None = None
    body: str | None = None
    line_start: int = 0
    line_end: int = 0
    is_async: bool = False
    is_private: bool = False
    decorators: list[str] = field(default_factory=list)


@dataclass
class ClassInfo:
    """Information about a parsed class."""

    name: str
    bases: list[str] = field(default_factory=list)
    methods: list[FunctionInfo] = field(default_factory=list)
    attributes: list[dict[str, str]] = field(default_factory=list)
    docstring: str | None = None
    line_start: int = 0
    line_end: int = 0
    is_private: bool = False
    decorators: list[str] = field(default_factory=list)


@dataclass
class ImportInfo:
    """Information about an import statement."""

    module: str
    names: list[str] = field(default_factory=list)
    alias: str | None = None
    is_from: bool = False


@dataclass
class ParsedModule:
    """Result of parsing a source file."""

    file_path: Path
    language: str
    functions: list[FunctionInfo] = field(default_factory=list)
    classes: list[ClassInfo] = field(default_factory=list)
    imports: list[ImportInfo] = field(default_factory=list)
    module_docstring: str | None = None
    variables: list[dict[str, str]] = field(default_factory=list)
    exports: list[str] = field(default_factory=list)


class CodeParser:
    """Parse source code using Tree-sitter."""

    def __init__(self, languages: list[str] | None = None):
        """
        Initialize the code parser.

        Args:
            languages: List of languages to support (default: python, javascript)
        """
        self.languages = languages or ["python", "javascript"]
        self._parsers: dict[str, Parser] = {}
        self._init_parsers()

    def _init_parsers(self) -> None:
        """Initialize Tree-sitter parsers for configured languages."""
        for lang in self.languages:
            try:
                module_name = LANGUAGE_MODULES.get(lang)
                if module_name:
                    import importlib

                    module = importlib.import_module(module_name)
                    language = Language(module.language())
                    parser = Parser(language)
                    self._parsers[lang] = parser
            except ImportError:
                # Language not available, skip
                pass

    def parse_file(self, file_path: Path, language: str | None = None) -> ParsedModule:
        """
        Parse a source file and extract structure.

        Args:
            file_path: Path to the source file
            language: Language of the file (auto-detected if not provided)

        Returns:
            ParsedModule with extracted information
        """
        # Detect language from extension
        if not language:
            language = self._detect_language(file_path)

        if language not in self._parsers:
            return ParsedModule(file_path=file_path, language=language or "unknown")

        # Read file content
        content = file_path.read_bytes()
        parser = self._parsers[language]

        # Parse the content
        tree = parser.parse(content)
        root = tree.root_node

        # Extract information based on language
        if language == "python":
            return self._parse_python(file_path, content, root)
        elif language in ("javascript", "typescript"):
            return self._parse_javascript(file_path, content, root)
        else:
            return ParsedModule(file_path=file_path, language=language)

    def _detect_language(self, file_path: Path) -> str | None:
        """Detect language from file extension."""
        ext_map = {
            ".py": "python",
            ".js": "javascript",
            ".jsx": "javascript",
            ".ts": "typescript",
            ".tsx": "typescript",
        }
        return ext_map.get(file_path.suffix)

    def _parse_python(self, file_path: Path, content: bytes, root) -> ParsedModule:
        """Parse Python source code."""
        module = ParsedModule(file_path=file_path, language="python")

        # Get module docstring
        module.module_docstring = self._get_python_docstring(content, root)

        for child in root.children:
            node_type = child.type

            if node_type == "function_definition":
                func = self._parse_python_function(content, child)
                module.functions.append(func)

            elif node_type == "class_definition":
                cls = self._parse_python_class(content, child)
                module.classes.append(cls)

            elif node_type == "import_statement":
                imp = self._parse_python_import(content, child)
                module.imports.append(imp)

            elif node_type == "import_from_statement":
                imp = self._parse_python_from_import(content, child)
                module.imports.append(imp)

            elif node_type == "expression_statement":
                # Check for module-level variable assignments
                if child.children and child.children[0].type == "assignment":
                    var = self._parse_python_variable(content, child.children[0])
                    module.variables.append(var)

        return module

    def _get_python_docstring(self, content: bytes, root) -> str | None:
        """Extract module-level docstring."""
        if root.children:
            first_child = root.children[0]
            if first_child.type == "expression_statement":
                expr = first_child.children[0] if first_child.children else None
                if expr and expr.type == "string":
                    return self._get_node_text(content, expr).strip("\"'")
        return None

    def _parse_python_function(self, content: bytes, node) -> FunctionInfo:
        """Parse a Python function definition."""
        name = ""
        params = []
        return_type = None
        docstring = None
        decorators = []
        is_async = False

        for child in node.children:
            if child.type == "identifier":
                name = self._get_node_text(content, child)
            elif child.type == "parameters":
                params = self._parse_python_params(content, child)
            elif child.type == "type":
                return_type = self._get_node_text(content, child)
            elif child.type == "block":
                # Get docstring from first expression in block
                if child.children:
                    first = child.children[0]
                    if first.type == "expression_statement":
                        expr = first.children[0] if first.children else None
                        if expr and expr.type == "string":
                            docstring = self._get_node_text(content, expr).strip("\"'")
            elif child.type == "decorator":
                decorators.append(self._get_node_text(content, child))

        # Check for async
        if "async" in self._get_node_text(content, node).split("(")[0]:
            is_async = True

        return FunctionInfo(
            name=name,
            parameters=params,
            return_type=return_type,
            docstring=docstring,
            line_start=node.start_point[0] + 1,
            line_end=node.end_point[0] + 1,
            is_async=is_async,
            is_private=name.startswith("_"),
            decorators=decorators,
        )

    def _parse_python_params(self, content: bytes, node) -> list[dict[str, str]]:
        """Parse function parameters."""
        params = []
        for child in node.children:
            if child.type == "identifier":
                params.append({"name": self._get_node_text(content, child), "type": "", "default": ""})
            elif child.type == "typed_parameter":
                param = {"name": "", "type": "", "default": ""}
                for pchild in child.children:
                    if pchild.type == "identifier":
                        param["name"] = self._get_node_text(content, pchild)
                    elif pchild.type == "type":
                        param["type"] = self._get_node_text(content, pchild)
                params.append(param)
            elif child.type == "default_parameter":
                param = {"name": "", "type": "", "default": ""}
                for pchild in child.children:
                    if pchild.type == "identifier":
                        param["name"] = self._get_node_text(content, pchild)
                    elif pchild.type == "type":
                        param["type"] = self._get_node_text(content, pchild)
                    elif pchild.type not in ("=", ":"):
                        param["default"] = self._get_node_text(content, pchild)
                params.append(param)
        return params

    def _parse_python_class(self, content: bytes, node) -> ClassInfo:
        """Parse a Python class definition."""
        name = ""
        bases = []
        methods = []
        attributes = []
        docstring = None
        decorators = []

        for child in node.children:
            if child.type == "identifier":
                name = self._get_node_text(content, child)
            elif child.type == "argument_list":
                # Base classes
                for arg in child.children:
                    if arg.type == "identifier":
                        bases.append(self._get_node_text(content, arg))
            elif child.type == "block":
                # Parse class body
                if child.children:
                    first = child.children[0]
                    if first.type == "expression_statement":
                        expr = first.children[0] if first.children else None
                        if expr and expr.type == "string":
                            docstring = self._get_node_text(content, expr).strip("\"'")

                for block_child in child.children:
                    if block_child.type == "function_definition":
                        method = self._parse_python_function(content, block_child)
                        methods.append(method)
                    elif block_child.type == "expression_statement":
                        # Class attributes
                        if block_child.children and block_child.children[0].type == "assignment":
                            attr = self._parse_python_variable(content, block_child.children[0])
                            attributes.append(attr)
            elif child.type == "decorator":
                decorators.append(self._get_node_text(content, child))

        return ClassInfo(
            name=name,
            bases=bases,
            methods=methods,
            attributes=attributes,
            docstring=docstring,
            line_start=node.start_point[0] + 1,
            line_end=node.end_point[0] + 1,
            is_private=name.startswith("_"),
            decorators=decorators,
        )

    def _parse_python_import(self, content: bytes, node) -> ImportInfo:
        """Parse an import statement."""
        names = []
        for child in node.children:
            if child.type == "dotted_name":
                names.append(self._get_node_text(content, child))
            elif child.type == "aliased_import":
                for achild in child.children:
                    if achild.type == "dotted_name":
                        name = self._get_node_text(content, achild)
                    elif achild.type == "identifier":
                        self._get_node_text(content, achild)
                names.append(name)

        return ImportInfo(
            module=names[0] if names else "",
            names=names,
        )

    def _parse_python_from_import(self, content: bytes, node) -> ImportInfo:
        """Parse a from...import statement."""
        module = ""
        names = []

        for child in node.children:
            if child.type == "dotted_name":
                module = self._get_node_text(content, child)
            elif child.type == "import_list":
                for imp in child.children:
                    if imp.type == "identifier" or imp.type == "dotted_name":
                        names.append(self._get_node_text(content, imp))

        return ImportInfo(
            module=module,
            names=names,
            is_from=True,
        )

    def _parse_python_variable(self, content: bytes, node) -> dict[str, str]:
        """Parse a variable assignment."""
        name = ""
        value = ""

        for child in node.children:
            if child.type == "identifier":
                name = self._get_node_text(content, child)
            elif child.type not in ("=", ":"):
                value = self._get_node_text(content, child)

        return {"name": name, "value": value}

    def _parse_javascript(self, file_path: Path, content: bytes, root) -> ParsedModule:
        """Parse JavaScript/TypeScript source code."""
        module = ParsedModule(file_path=file_path, language="javascript")

        for child in root.children:
            node_type = child.type

            if node_type == "function_declaration":
                func = self._parse_js_function(content, child)
                module.functions.append(func)

            elif node_type == "class_declaration":
                cls = self._parse_js_class(content, child)
                module.classes.append(cls)

            elif node_type == "import_statement":
                imp = self._parse_js_import(content, child)
                module.imports.append(imp)

            elif node_type == "export_statement":
                # Track exports
                for echild in child.children:
                    if echild.type == "identifier":
                        module.exports.append(self._get_node_text(content, echild))

        return module

    def _parse_js_function(self, content: bytes, node) -> FunctionInfo:
        """Parse a JavaScript function definition."""
        name = ""
        params = []
        is_async = False

        for child in node.children:
            if child.type == "identifier":
                name = self._get_node_text(content, child)
            elif child.type == "formal_parameters":
                params = self._parse_js_params(content, child)
            elif child.type == "async":
                is_async = True

        return FunctionInfo(
            name=name,
            parameters=params,
            line_start=node.start_point[0] + 1,
            line_end=node.end_point[0] + 1,
            is_async=is_async,
            is_private=name.startswith("_"),
        )

    def _parse_js_params(self, content: bytes, node) -> list[dict[str, str]]:
        """Parse JavaScript function parameters."""
        params = []
        for child in node.children:
            if child.type == "identifier":
                params.append({"name": self._get_node_text(content, child), "type": "", "default": ""})
            elif child.type == "assignment_pattern":
                param = {"name": "", "type": "", "default": ""}
                for pchild in child.children:
                    if pchild.type == "identifier":
                        param["name"] = self._get_node_text(content, pchild)
                    elif pchild.type != "=":
                        param["default"] = self._get_node_text(content, pchild)
                params.append(param)
        return params

    def _parse_js_class(self, content: bytes, node) -> ClassInfo:
        """Parse a JavaScript class definition."""
        name = ""
        bases = []
        methods = []

        for child in node.children:
            if child.type == "identifier":
                name = self._get_node_text(content, child)
            elif child.type == "class_heritage":
                for hchild in child.children:
                    if hchild.type == "identifier":
                        bases.append(self._get_node_text(content, hchild))
            elif child.type == "class_body":
                for bchild in child.children:
                    if bchild.type == "method_definition":
                        method = self._parse_js_method(content, bchild)
                        methods.append(method)

        return ClassInfo(
            name=name,
            bases=bases,
            methods=methods,
            line_start=node.start_point[0] + 1,
            line_end=node.end_point[0] + 1,
            is_private=name.startswith("_"),
        )

    def _parse_js_method(self, content: bytes, node) -> FunctionInfo:
        """Parse a JavaScript class method."""
        name = ""
        params = []
        is_async = False

        for child in node.children:
            if child.type == "property_identifier":
                name = self._get_node_text(content, child)
            elif child.type == "formal_parameters":
                params = self._parse_js_params(content, child)

        return FunctionInfo(
            name=name,
            parameters=params,
            line_start=node.start_point[0] + 1,
            line_end=node.end_point[0] + 1,
            is_async=is_async,
            is_private=name.startswith("_"),
        )

    def _parse_js_import(self, content: bytes, node) -> ImportInfo:
        """Parse a JavaScript import statement."""
        module = ""
        names = []

        for child in node.children:
            if child.type == "string":
                module = self._get_node_text(content, child).strip("\"'")
            elif child.type == "import_clause":
                for cchild in child.children:
                    if cchild.type == "identifier":
                        names.append(self._get_node_text(content, cchild))
                    elif cchild.type == "named_imports":
                        for nchild in cchild.children:
                            if nchild.type == "import_specifier":
                                for schild in nchild.children:
                                    if schild.type == "identifier":
                                        names.append(self._get_node_text(content, schild))

        return ImportInfo(
            module=module,
            names=names,
            is_from=True,
        )

    def _get_node_text(self, content: bytes, node) -> str:
        """Get text content of a node."""
        return content[node.start_byte : node.end_byte].decode("utf-8", errors="replace")
