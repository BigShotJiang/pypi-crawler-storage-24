"""Issue clustering module for grouping similar issues."""


from codenarrator.providers.base import BaseProvider, Issue, IssueCluster


class IssueClusterizer:
    """Cluster similar issues using AI."""

    def __init__(self, provider: BaseProvider, max_clusters: int = 10):
        """
        Initialize clusterizer.

        Args:
            provider: AI provider for clustering
            max_clusters: Maximum number of clusters to create
        """
        self.provider = provider
        self.max_clusters = max_clusters

    async def cluster(self, issues: list[Issue]) -> list[IssueCluster]:
        """
        Cluster issues into groups of similar problems.

        Args:
            issues: List of issues to cluster

        Returns:
            List of issue clusters
        """
        if not issues:
            return []

        # Use AI provider for clustering
        return await self.provider.cluster_issues(
            issues=issues,
            max_clusters=self.max_clusters,
        )

    def _simple_cluster(self, issues: list[Issue]) -> list[IssueCluster]:
        """
        Simple keyword-based clustering as fallback.

        This is used when AI is not available.
        """
        # Group by common keywords in titles
        keyword_groups: dict[str, list[Issue]] = {}
        ungrouped: list[Issue] = []

        # Common issue keywords
        keywords = [
            "error",
            "bug",
            "crash",
            "install",
            "import",
            "config",
            "performance",
            "memory",
            "timeout",
            "connection",
        ]

        for issue in issues:
            title_lower = issue.title.lower()
            matched = False

            for keyword in keywords:
                if keyword in title_lower:
                    if keyword not in keyword_groups:
                        keyword_groups[keyword] = []
                    keyword_groups[keyword].append(issue)
                    matched = True
                    break

            if not matched:
                ungrouped.append(issue)

        # Convert to clusters
        clusters = []

        for keyword, group in keyword_groups.items():
            if group:
                clusters.append(
                    IssueCluster(
                        representative_issue=group[0],
                        similar_issues=group[1:],
                        topic=f"Issues related to {keyword}",
                    )
                )

        # Add ungrouped as individual clusters (up to limit)
        remaining = self.max_clusters - len(clusters)
        for issue in ungrouped[:remaining]:
            clusters.append(
                IssueCluster(
                    representative_issue=issue,
                    similar_issues=[],
                    topic=issue.title,
                )
            )

        return clusters[:self.max_clusters]
