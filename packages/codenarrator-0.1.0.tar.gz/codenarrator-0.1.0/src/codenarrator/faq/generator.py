"""FAQ generator module."""

from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape

from codenarrator.core.config import Config
from codenarrator.faq.cluster import IssueClusterizer
from codenarrator.faq.github_client import GitHubClient
from codenarrator.providers.base import BaseProvider, FAQEntry


class FAQGenerator:
    """Generate FAQ from GitHub Issues."""

    def __init__(
        self,
        provider: BaseProvider,
        config: Config,
        github_client: GitHubClient | None = None,
    ):
        """
        Initialize FAQ generator.

        Args:
            provider: AI provider for content generation
            config: Configuration object
            github_client: Optional GitHub client (created if not provided)
        """
        self.provider = provider
        self.config = config
        self.github_client = github_client
        self.clusterizer = IssueClusterizer(
            provider=provider,
            max_clusters=20,  # Allow more clusters for FAQ
        )
        self.env = Environment(
            loader=FileSystemLoader(Path(__file__).parent.parent / "analysis" / "templates"),
            autoescape=select_autoescape(default=False),
        )

    async def generate(
        self,
        repo: str | None = None,
        labels: list[str] | None = None,
        days_back: int | None = None,
        max_issues: int | None = None,
    ) -> str:
        """
        Generate FAQ from GitHub Issues.

        Args:
            repo: GitHub repository (owner/repo format)
            labels: Issue labels to filter
            days_back: Days to look back
            max_issues: Maximum issues to process

        Returns:
            Generated FAQ content in Markdown
        """
        # Use config defaults
        repo = repo or self.config.faq.github_repo
        labels = labels or self.config.faq.labels
        days_back = days_back or self.config.faq.days_back
        max_issues = max_issues or self.config.faq.max_issues

        if not repo:
            raise ValueError("GitHub repository not specified")

        # Parse owner/repo
        owner, repo_name = repo.split("/")

        # Create client if needed
        client = self.github_client or GitHubClient()

        try:
            # Fetch issues
            issues = await client.fetch_closed_issues(
                owner=owner,
                repo=repo_name,
                labels=labels,
                days_back=days_back,
                max_issues=max_issues,
            )

            if not issues:
                return "# FAQ\n\nNo issues found for the specified criteria.\n"

            # Cluster issues
            clusters = await self.clusterizer.cluster(issues)

            # Generate FAQ entries
            entries = []
            for cluster in clusters:
                entry = await self.provider.generate_faq_entry(cluster)
                entries.append(entry)

            # Format as Markdown
            return self._format_faq(entries, repo)

        finally:
            if not self.github_client:
                await client.client.aclose()

    def _format_faq(self, entries: list[FAQEntry], repo: str) -> str:
        """Format FAQ entries as Markdown."""
        lines = ["# Frequently Asked Questions\n"]
        lines.append(f"Generated from [GitHub Issues](https://github.com/{repo})\n")
        lines.append("---\n")

        # Table of contents
        lines.append("## Questions\n")
        for i, entry in enumerate(entries, 1):
            # Create anchor link
            anchor = self._create_anchor(entry.question)
            lines.append(f"{i}. [{entry.question}](#{anchor})")
        lines.append("")

        # Questions and answers
        lines.append("---\n")
        for i, entry in enumerate(entries, 1):
            anchor = self._create_anchor(entry.question)
            lines.append(f"### {i}. {entry.question} {{#{anchor}}}\n")
            lines.append(entry.answer)
            lines.append("")

            # Add references
            if entry.related_pr or entry.related_commit:
                lines.append("**References:**")
                if entry.related_pr:
                    lines.append(f"- Fixed in [PR #{entry.related_pr}](https://github.com/{repo}/pull/{entry.related_pr})")
                if entry.related_commit:
                    lines.append(f"- Commit [{entry.related_commit[:7]}](https://github.com/{repo}/commit/{entry.related_commit})")
                lines.append("")

            # Add related issues
            if entry.related_issues:
                issues_str = ", ".join(
                    f"[#{iid}](https://github.com/{repo}/issues/{iid})"
                    for iid in entry.related_issues[:5]
                )
                lines.append(f"**Related Issues:** {issues_str}\n")

            lines.append("---\n")

        return "\n".join(lines)

    def _create_anchor(self, text: str) -> str:
        """Create a Markdown anchor from text."""
        # Simple slugification
        anchor = text.lower()
        anchor = "".join(c if c.isalnum() or c == "-" else "-" for c in anchor)
        while "--" in anchor:
            anchor = anchor.replace("--", "-")
        return anchor.strip("-")

    async def update_existing(
        self,
        existing_content: str,
        new_entries: list[FAQEntry],
        repo: str,
    ) -> str:
        """
        Update existing FAQ with new entries.

        Args:
            existing_content: Existing FAQ content
            new_entries: New FAQ entries to add
            repo: GitHub repository

        Returns:
            Updated FAQ content
        """
        # For now, just append new entries
        # A more sophisticated approach would merge similar questions

        if not new_entries:
            return existing_content

        lines = [existing_content]
        lines.append("\n---\n")
        lines.append("## Recently Added\n")

        for entry in new_entries:
            lines.append(f"### {entry.question}\n")
            lines.append(entry.answer)
            lines.append("")

            if entry.related_pr:
                lines.append(f"**Fixed in:** [PR #{entry.related_pr}](https://github.com/{repo}/pull/{entry.related_pr})\n")

        return "\n".join(lines)
