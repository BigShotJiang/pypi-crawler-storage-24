"""GitHub API client for fetching issues."""

import os
from datetime import datetime, timedelta

import httpx

from codenarrator.providers.base import Issue


class GitHubClient:
    """Client for interacting with GitHub API."""

    API_URL = "https://api.github.com"

    def __init__(self, token: str | None = None):
        """
        Initialize GitHub client.

        Args:
            token: GitHub personal access token (optional but recommended)
        """
        self.token = token or os.getenv("GITHUB_TOKEN")
        self.client = httpx.AsyncClient(
            base_url=self.API_URL,
            timeout=30.0,
        )
        if self.token:
            self.client.headers["Authorization"] = f"Bearer {self.token}"

    async def fetch_closed_issues(
        self,
        owner: str,
        repo: str,
        labels: list[str] | None = None,
        days_back: int = 30,
        max_issues: int = 100,
    ) -> list[Issue]:
        """
        Fetch closed issues from a repository.

        Args:
            owner: Repository owner
            repo: Repository name
            labels: Filter by labels
            days_back: Number of days to look back
            max_issues: Maximum number of issues to fetch

        Returns:
            List of Issue objects
        """
        since = (datetime.utcnow() - timedelta(days=days_back)).isoformat() + "Z"

        params = {
            "state": "closed",
            "since": since,
            "per_page": min(max_issues, 100),
            "sort": "updated",
            "direction": "desc",
        }

        if labels:
            params["labels"] = ",".join(labels)

        issues = []
        page = 1

        while len(issues) < max_issues:
            params["page"] = page

            response = await self.client.get(
                f"/repos/{owner}/{repo}/issues",
                params=params,
            )
            response.raise_for_status()

            data = response.json()
            if not data:
                break

            for item in data:
                # Skip pull requests (they appear in issues endpoint)
                if "pull_request" in item:
                    continue

                issue = await self._parse_issue(item, owner, repo)
                issues.append(issue)

                if len(issues) >= max_issues:
                    break

            page += 1

        return issues

    async def _parse_issue(self, item: dict, owner: str, repo: str) -> Issue:
        """Parse GitHub API response into Issue object."""
        # Fetch comments
        comments = await self._fetch_comments(owner, repo, item["number"])

        # Try to find linked PR or commit
        pr_number, commit_sha = await self._find_linked_fix(
            owner, repo, item["number"], item.get("body", "") or ""
        )

        return Issue(
            id=item["number"],
            title=item["title"],
            body=item.get("body"),
            labels=[label["name"] for label in item.get("labels", [])],
            comments=comments,
            closed_at=item.get("closed_at"),
            pr_number=pr_number,
            commit_sha=commit_sha,
        )

    async def _fetch_comments(
        self,
        owner: str,
        repo: str,
        issue_number: int,
    ) -> list[str]:
        """Fetch comments for an issue."""
        try:
            response = await self.client.get(
                f"/repos/{owner}/{repo}/issues/{issue_number}/comments",
            )
            response.raise_for_status()

            data = response.json()
            return [comment["body"] for comment in data if comment.get("body")]
        except httpx.HTTPError:
            return []

    async def _find_linked_fix(
        self,
        owner: str,
        repo: str,
        issue_number: int,
        body: str,
    ) -> tuple[int | None, str | None]:
        """
        Try to find linked PR or commit that fixed the issue.

        Returns:
            Tuple of (pr_number, commit_sha)
        """
        pr_number = None
        commit_sha = None

        # Check for closing keywords in body/comments
        closing_keywords = ["fixes", "fix", "closes", "close", "resolves", "resolve"]

        # Look for PR number in timeline events
        try:
            response = await self.client.get(
                f"/repos/{owner}/{repo}/issues/{issue_number}/timeline",
                params={"per_page": 100},
            )
            response.raise_for_status()

            for event in response.json():
                if event.get("event") == "cross-referenced":
                    # Check if this is a PR reference
                    if "issue" in event:
                        ref = event["issue"]
                        if "pull_request" in ref:
                            pr_number = ref["number"]
                            break

                elif event.get("event") == "closed":
                    # Check commit SHA
                    if event.get("commit_id"):
                        commit_sha = event["commit_id"]

        except httpx.HTTPError:
            pass

        # Also check body for patterns like "Fixed by #123"
        import re

        for keyword in closing_keywords:
            pattern = rf"{keyword}\s+#(\d+)"
            match = re.search(pattern, body, re.IGNORECASE)
            if match:
                pr_number = int(match.group(1))
                break

        return pr_number, commit_sha

    async def get_rate_limit(self) -> dict:
        """Get current rate limit status."""
        response = await self.client.get("/rate_limit")
        response.raise_for_status()
        return response.json()

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.client.aclose()
