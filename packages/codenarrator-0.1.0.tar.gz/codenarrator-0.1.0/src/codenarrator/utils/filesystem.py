"""Filesystem utilities for CodeNarrator."""

from pathlib import Path


def ensure_dir(path: str | Path) -> Path:
    """
    Ensure a directory exists, creating it if necessary.

    Args:
        path: Directory path

    Returns:
        Path object for the directory
    """
    dir_path = Path(path)
    dir_path.mkdir(parents=True, exist_ok=True)
    return dir_path


def write_file(
    path: str | Path,
    content: str,
    encoding: str = "utf-8",
) -> Path:
    """
    Write content to a file, creating parent directories if needed.

    Args:
        path: File path
        content: Content to write
        encoding: File encoding

    Returns:
        Path object for the file
    """
    file_path = Path(path)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    file_path.write_text(content, encoding=encoding)
    return file_path


def read_file(
    path: str | Path,
    encoding: str = "utf-8",
) -> str:
    """
    Read content from a file.

    Args:
        path: File path
        encoding: File encoding

    Returns:
        File content as string
    """
    return Path(path).read_text(encoding=encoding)


def get_relative_path(
    file_path: Path,
    base_path: Path,
) -> str:
    """
    Get relative path from base to file.

    Args:
        file_path: Target file path
        base_path: Base directory path

    Returns:
        Relative path as string
    """
    try:
        return str(file_path.relative_to(base_path))
    except ValueError:
        return str(file_path)


def find_files(
    directory: Path,
    patterns: list[str],
    exclude_patterns: list[str] | None = None,
) -> list[Path]:
    """
    Find files matching patterns in a directory.

    Args:
        directory: Directory to search
        patterns: Glob patterns to match
        exclude_patterns: Patterns to exclude

    Returns:
        List of matching file paths
    """
    import fnmatch

    exclude_patterns = exclude_patterns or []
    files = []

    for pattern in patterns:
        for match in directory.rglob(pattern):
            # Check exclusions
            relative = str(match.relative_to(directory))
            excluded = False

            for exclude in exclude_patterns:
                if fnmatch.fnmatch(relative, exclude):
                    excluded = True
                    break

            if not excluded:
                files.append(match)

    return sorted(set(files))


def copy_file(
    source: Path,
    destination: Path,
) -> Path:
    """
    Copy a file, creating parent directories if needed.

    Args:
        source: Source file path
        destination: Destination file path

    Returns:
        Destination path
    """
    import shutil

    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    return destination


def get_file_hash(file_path: Path) -> str:
    """
    Calculate SHA256 hash of a file.

    Args:
        file_path: Path to file

    Returns:
        Hexadecimal hash string
    """
    import hashlib

    sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha256.update(chunk)
    return sha256.hexdigest()
