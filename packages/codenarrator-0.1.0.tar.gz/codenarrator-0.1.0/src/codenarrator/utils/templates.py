"""Template loading and rendering utilities."""

from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, PackageLoader, select_autoescape


class TemplateLoader:
    """Load and render Jinja2 templates."""

    def __init__(self, template_dir: Path | None = None):
        """
        Initialize template loader.

        Args:
            template_dir: Optional custom template directory
        """
        self.template_dir = template_dir

        if template_dir:
            self.env = Environment(
                loader=FileSystemLoader(template_dir),
                autoescape=select_autoescape(default=False),
            )
        else:
            # Use package loader for built-in templates
            self.env = Environment(
                loader=PackageLoader("codenarrator.analysis", "templates"),
                autoescape=select_autoescape(default=False),
            )

    def render(self, template_name: str, context: dict[str, Any]) -> str:
        """
        Render a template with context.

        Args:
            template_name: Name of the template file
            context: Dictionary of variables for the template

        Returns:
            Rendered template content
        """
        template = self.env.get_template(template_name)
        return template.render(**context)

    def render_string(self, template_string: str, context: dict[str, Any]) -> str:
        """
        Render a template string with context.

        Args:
            template_string: Template content as string
            context: Dictionary of variables for the template

        Returns:
            Rendered content
        """
        template = self.env.from_string(template_string)
        return template.render(**context)

    def list_templates(self) -> list[str]:
        """List available templates."""
        return self.env.list_templates()

    def add_filter(self, name: str, func: Any) -> None:
        """
        Add a custom Jinja2 filter.

        Args:
            name: Filter name
            func: Filter function
        """
        self.env.filters[name] = func

    def add_global(self, name: str, value: Any) -> None:
        """
        Add a global variable to all templates.

        Args:
            name: Variable name
            value: Variable value
        """
        self.env.globals[name] = value


# Built-in template filters
def code_block_filter(code: str, language: str = "") -> str:
    """Format code as a fenced code block."""
    return f"```{language}\n{code}\n```"


def link_filter(text: str, url: str) -> str:
    """Format as Markdown link."""
    return f"[{text}]({url})"


def bold_filter(text: str) -> str:
    """Format as bold text."""
    return f"**{text}**"


def italic_filter(text: str) -> str:
    """Format as italic text."""
    return f"*{text}*"


def inline_code_filter(code: str) -> str:
    """Format as inline code."""
    return f"`{code}`"
