"""Factory for creating AI providers."""

import os

from codenarrator.core.config import Config
from codenarrator.providers.base import BaseProvider


def create_provider(config: Config) -> BaseProvider:
    """
    Create an AI provider based on configuration.

    Args:
        config: Configuration object

    Returns:
        Configured provider instance

    Raises:
        ValueError: If provider type is not supported
    """
    provider_type = config.provider.type
    model = config.provider.model
    api_key = config.provider.api_key
    base_url = config.provider.base_url

    # Try to get API key from environment if not in config
    if not api_key:
        api_key = _get_env_api_key(provider_type)

    if provider_type == "openai":
        from codenarrator.providers.openai_provider import OpenAIProvider

        return OpenAIProvider(model=model, api_key=api_key, base_url=base_url)

    elif provider_type == "anthropic":
        from codenarrator.providers.anthropic_provider import AnthropicProvider

        return AnthropicProvider(model=model, api_key=api_key, base_url=base_url)

    elif provider_type == "ollama":
        from codenarrator.providers.ollama_provider import OllamaProvider

        # Ollama typically runs locally
        if not base_url:
            base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
        return OllamaProvider(model=model, base_url=base_url)

    else:
        raise ValueError(f"Unsupported provider type: {provider_type}")


def _get_env_api_key(provider_type: str) -> str | None:
    """Get API key from environment variables."""
    env_vars = {
        "openai": ["ZAI_API_KEY", "OPENAI_API_KEY"],  # ZAI_API_KEY for Z.AI GLM models (checked first)
        "anthropic": ["ANTHROPIC_API_KEY"],
        "ollama": [],  # Ollama doesn't need API key
    }

    for var in env_vars.get(provider_type, []):
        key = os.getenv(var)
        if key:
            return key

    return None
