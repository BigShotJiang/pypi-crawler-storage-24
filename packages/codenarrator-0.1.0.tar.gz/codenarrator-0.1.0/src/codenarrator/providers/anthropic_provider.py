"""Anthropic Claude provider implementation."""

import json

from anthropic import AsyncAnthropic

from codenarrator.providers.base import (
    AnalysisResult,
    BaseProvider,
    FAQEntry,
    Issue,
    IssueCluster,
)


class AnthropicProvider(BaseProvider):
    """Anthropic Claude API provider implementation."""

    def __init__(
        self,
        model: str = "claude-3-opus-20240229",
        api_key: str | None = None,
        base_url: str | None = None,
    ):
        """
        Initialize Anthropic provider.

        Args:
            model: Anthropic model to use (claude-3-opus, claude-3-sonnet, etc.)
            api_key: Anthropic API key
            base_url: Optional base URL for API
        """
        super().__init__(model, api_key, base_url)
        self.client = AsyncAnthropic(api_key=api_key, base_url=base_url)

    async def analyze_code(
        self,
        code: str,
        language: str,
        prompt: str | None = None,
    ) -> AnalysisResult:
        """Analyze source code using Anthropic Claude."""
        system_prompt = """You are an expert code analyst. Analyze the provided code and extract:
1. A brief description of what the code does
2. A one-line summary
3. All functions with their signatures, parameters, return types, and descriptions
4. All classes with their methods and attributes
5. All imports
6. Usage examples if found in docstrings or comments

Respond in JSON format with keys: description, summary, functions, classes, imports, examples"""

        user_prompt = prompt or f"""Analyze this {language} code:

```{language}
{code}
```

Provide a comprehensive analysis in JSON format."""

        response = await self.client.messages.create(
            model=self.model,
            max_tokens=4096,
            system=system_prompt,
            messages=[{"role": "user", "content": user_prompt}],
        )

        self._add_tokens(response.usage.input_tokens + response.usage.output_tokens)

        content = response.content[0].text
        # Extract JSON from response
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0]
        elif "```" in content:
            content = content.split("```")[1].split("```")[0]

        result = json.loads(content.strip())
        return AnalysisResult(
            description=result.get("description", ""),
            summary=result.get("summary", ""),
            functions=result.get("functions", []),
            classes=result.get("classes", []),
            imports=result.get("imports", []),
            examples=result.get("examples", []),
        )

    async def generate_readme(
        self,
        project_name: str,
        description: str,
        entry_point_analysis: AnalysisResult,
        dependencies: dict[str, list[str]],
        examples: list[str],
    ) -> str:
        """Generate README.md content."""
        system_prompt = """You are a technical documentation writer. Generate a comprehensive README.md file.
Include sections: Description, Installation, Quick Start, Usage Examples, API Reference, Contributing, License.
Use proper Markdown formatting with headers, code blocks, and badges where appropriate."""

        deps_str = "\n".join(
            f"- {lang}: {', '.join(deps)}" for lang, deps in dependencies.items()
        )
        examples_str = "\n\n".join(f"```\n{ex}\n```" for ex in examples) if examples else "No examples available."

        user_prompt = f"""Generate a README.md for the project:

Project Name: {project_name}
Description: {description}

Entry Point Analysis:
{entry_point_analysis.description}

Dependencies:
{deps_str}

Usage Examples:
{examples_str}

Generate a complete, professional README.md in Markdown format."""

        response = await self.client.messages.create(
            model=self.model,
            max_tokens=4096,
            system=system_prompt,
            messages=[{"role": "user", "content": user_prompt}],
        )

        self._add_tokens(response.usage.input_tokens + response.usage.output_tokens)
        return response.content[0].text

    async def generate_api_docs(
        self,
        module_name: str,
        analysis: AnalysisResult,
        include_private: bool = False,
    ) -> str:
        """Generate API documentation for a module."""
        system_prompt = """You are an API documentation writer. Generate clear, comprehensive API documentation.
Include descriptions for all parameters, return values, and exceptions. Use proper Markdown formatting."""

        functions = analysis.functions
        classes = analysis.classes

        if not include_private:
            functions = [f for f in functions if not f.get("name", "").startswith("_")]
            classes = [c for c in classes if not c.get("name", "").startswith("_")]

        user_prompt = f"""Generate API documentation for module: {module_name}

Module Description: {analysis.description}

Functions:
{json.dumps(functions, indent=2)}

Classes:
{json.dumps(classes, indent=2)}

Generate comprehensive API documentation in Markdown format."""

        response = await self.client.messages.create(
            model=self.model,
            max_tokens=4096,
            system=system_prompt,
            messages=[{"role": "user", "content": user_prompt}],
        )

        self._add_tokens(response.usage.input_tokens + response.usage.output_tokens)
        return response.content[0].text

    async def generate_architecture(
        self,
        modules: dict[str, AnalysisResult],
        dependencies: dict[str, list[str]],
    ) -> str:
        """Generate architecture documentation with Mermaid diagrams."""
        system_prompt = """You are a software architect. Generate architecture documentation with Mermaid diagrams.
Include:
1. An overview of the system architecture
2. A Mermaid flowchart showing module relationships
3. Description of data flow
4. Key design patterns used"""

        modules_desc = "\n".join(
            f"- {name}: {mod.summary}" for name, mod in modules.items()
        )
        deps_desc = "\n".join(
            f"- {mod} depends on: {', '.join(deps) if deps else 'none'}"
            for mod, deps in dependencies.items()
        )

        user_prompt = f"""Generate architecture documentation for a project with these modules:

Modules:
{modules_desc}

Dependencies:
{deps_desc}

Generate architecture documentation with Mermaid diagrams in Markdown format."""

        response = await self.client.messages.create(
            model=self.model,
            max_tokens=4096,
            system=system_prompt,
            messages=[{"role": "user", "content": user_prompt}],
        )

        self._add_tokens(response.usage.input_tokens + response.usage.output_tokens)
        return response.content[0].text

    async def translate(
        self,
        text: str,
        target_language: str,
        preserve_code: bool = True,
        preserve_terms: list[str] | None = None,
    ) -> str:
        """Translate text to target language."""
        language_names = {
            "ru": "Russian",
            "zh": "Chinese (Simplified)",
            "es": "Spanish",
            "fr": "French",
            "de": "German",
            "ja": "Japanese",
            "ko": "Korean",
            "pt": "Portuguese",
        }

        target_name = language_names.get(target_language, target_language)

        system_prompt = f"""You are a professional translator specializing in technical documentation.
Translate the provided text to {target_name}.
{'Do NOT translate code blocks - keep them exactly as is.' if preserve_code else ''}
{'Do NOT translate these technical terms: ' + ', '.join(preserve_terms) if preserve_terms else ''}
Maintain all Markdown formatting, links, and structure."""

        response = await self.client.messages.create(
            model=self.model,
            max_tokens=4096,
            system=system_prompt,
            messages=[{"role": "user", "content": text}],
        )

        self._add_tokens(response.usage.input_tokens + response.usage.output_tokens)
        return response.content[0].text

    async def cluster_issues(
        self,
        issues: list[Issue],
        max_clusters: int = 10,
    ) -> list[IssueCluster]:
        """Cluster similar issues together."""
        if not issues:
            return []

        system_prompt = f"""You are an expert at analyzing and categorizing software issues.
Group the provided issues into at most {max_clusters} clusters based on similarity.
For each cluster, identify:
1. The most representative issue
2. A brief topic description
3. All similar issues

Respond in JSON format as a list of clusters with keys: representative_id, topic, similar_ids"""

        issues_data = [
            {
                "id": issue.id,
                "title": issue.title,
                "labels": issue.labels,
            }
            for issue in issues
        ]

        user_prompt = f"""Cluster these GitHub issues:

{json.dumps(issues_data, indent=2)}

Return a JSON list of clusters."""

        response = await self.client.messages.create(
            model=self.model,
            max_tokens=4096,
            system=system_prompt,
            messages=[{"role": "user", "content": user_prompt}],
        )

        self._add_tokens(response.usage.input_tokens + response.usage.output_tokens)

        content = response.content[0].text
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0]
        elif "```" in content:
            content = content.split("```")[1].split("```")[0]

        result = json.loads(content.strip())
        clusters = result.get("clusters", result) if isinstance(result, dict) else result

        issue_map = {issue.id: issue for issue in issues}
        issue_clusters = []

        for cluster_data in clusters[:max_clusters]:
            rep_id = cluster_data.get("representative_id")
            similar_ids = cluster_data.get("similar_ids", [])

            if rep_id and rep_id in issue_map:
                similar_issues = [issue_map[i] for i in similar_ids if i in issue_map]
                issue_clusters.append(
                    IssueCluster(
                        representative_issue=issue_map[rep_id],
                        similar_issues=similar_issues,
                        topic=cluster_data.get("topic", ""),
                    )
                )

        return issue_clusters

    async def generate_faq_entry(
        self,
        cluster: IssueCluster,
    ) -> FAQEntry:
        """Generate a FAQ entry from an issue cluster."""
        system_prompt = """You are a technical support expert. Generate a clear FAQ entry based on GitHub issues.
The question should be concise and the answer should be helpful and actionable.
Include references to any PRs or commits that fixed the issue."""

        issue = cluster.representative_issue
        similar_titles = [i.title for i in cluster.similar_issues[:3]]

        user_prompt = f"""Generate a FAQ entry based on this issue cluster:

Main Issue: {issue.title}
Body: {issue.body or 'No description'}
Labels: {', '.join(issue.labels)}
Comments: {' | '.join(issue.comments[:3])}
Related PR: {issue.pr_number}
Related Commit: {issue.commit_sha}

Similar Issues: {', '.join(similar_titles)}

Generate a JSON object with: question, answer, related_issues (list of IDs), related_pr, related_commit."""

        response = await self.client.messages.create(
            model=self.model,
            max_tokens=2048,
            system=system_prompt,
            messages=[{"role": "user", "content": user_prompt}],
        )

        self._add_tokens(response.usage.input_tokens + response.usage.output_tokens)

        content = response.content[0].text
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0]
        elif "```" in content:
            content = content.split("```")[1].split("```")[0]

        result = json.loads(content.strip())
        return FAQEntry(
            question=result.get("question", issue.title),
            answer=result.get("answer", ""),
            related_issues=result.get("related_issues", [issue.id]),
            related_pr=result.get("related_pr", issue.pr_number),
            related_commit=result.get("related_commit", issue.commit_sha),
        )

    async def complete(
        self,
        prompt: str,
        system_prompt: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2000,
    ) -> str:
        """Generic completion method."""
        messages = [{"role": "user", "content": prompt}]

        kwargs = {
            "model": self.model,
            "max_tokens": max_tokens,
            "messages": messages,
        }

        if system_prompt:
            kwargs["system"] = system_prompt

        response = await self.client.messages.create(**kwargs)

        self._add_tokens(response.usage.input_tokens + response.usage.output_tokens)
        return response.content[0].text
