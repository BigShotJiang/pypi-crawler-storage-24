"""Base provider interface for AI providers."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


@dataclass
class Issue:
    """Represents a GitHub issue."""

    id: int
    title: str
    body: str | None
    labels: list[str]
    comments: list[str]
    closed_at: str | None
    pr_number: int | None = None
    commit_sha: str | None = None


@dataclass
class IssueCluster:
    """Represents a cluster of similar issues."""

    representative_issue: Issue
    similar_issues: list[Issue]
    topic: str


@dataclass
class AnalysisResult:
    """Result of code analysis."""

    description: str
    summary: str
    functions: list[dict[str, Any]]
    classes: list[dict[str, Any]]
    imports: list[str]
    examples: list[str]


@dataclass
class FAQEntry:
    """Represents a FAQ entry."""

    question: str
    answer: str
    related_issues: list[int]
    related_pr: int | None = None
    related_commit: str | None = None


class BaseProvider(ABC):
    """Abstract base class for AI providers."""

    def __init__(
        self,
        model: str,
        api_key: str | None = None,
        base_url: str | None = None,
    ):
        """
        Initialize the provider.

        Args:
            model: Model identifier to use
            api_key: API key for authentication
            base_url: Optional base URL for API (for proxies or local models)
        """
        self.model = model
        self.api_key = api_key
        self.base_url = base_url
        self._total_tokens = 0

    @abstractmethod
    async def analyze_code(
        self,
        code: str,
        language: str,
        prompt: str | None = None,
    ) -> AnalysisResult:
        """
        Analyze source code and extract documentation.

        Args:
            code: Source code to analyze
            language: Programming language of the code
            prompt: Optional custom prompt for analysis

        Returns:
            AnalysisResult with extracted information
        """
        pass

    @abstractmethod
    async def generate_readme(
        self,
        project_name: str,
        description: str,
        entry_point_analysis: AnalysisResult,
        dependencies: dict[str, list[str]],
        examples: list[str],
    ) -> str:
        """
        Generate README.md content.

        Args:
            project_name: Name of the project
            description: Project description
            entry_point_analysis: Analysis of entry point files
            dependencies: Dictionary of dependencies by language
            examples: List of usage examples

        Returns:
            Generated README content in Markdown
        """
        pass

    @abstractmethod
    async def generate_api_docs(
        self,
        module_name: str,
        analysis: AnalysisResult,
        include_private: bool = False,
    ) -> str:
        """
        Generate API documentation for a module.

        Args:
            module_name: Name of the module
            analysis: Analysis result for the module
            include_private: Whether to include private members

        Returns:
            Generated API documentation in Markdown
        """
        pass

    @abstractmethod
    async def generate_architecture(
        self,
        modules: dict[str, AnalysisResult],
        dependencies: dict[str, list[str]],
    ) -> str:
        """
        Generate architecture documentation with Mermaid diagrams.

        Args:
            modules: Dictionary mapping module names to their analysis
            dependencies: Dictionary of module dependencies

        Returns:
            Generated architecture documentation with Mermaid diagrams
        """
        pass

    @abstractmethod
    async def translate(
        self,
        text: str,
        target_language: str,
        preserve_code: bool = True,
        preserve_terms: list[str] | None = None,
    ) -> str:
        """
        Translate text to target language.

        Args:
            text: Text to translate
            target_language: Target language code (e.g., 'ru', 'zh', 'es')
            preserve_code: Whether to preserve code blocks
            preserve_terms: Technical terms to preserve

        Returns:
            Translated text
        """
        pass

    @abstractmethod
    async def cluster_issues(
        self,
        issues: list[Issue],
        max_clusters: int = 10,
    ) -> list[IssueCluster]:
        """
        Cluster similar issues together.

        Args:
            issues: List of issues to cluster
            max_clusters: Maximum number of clusters to create

        Returns:
            List of issue clusters
        """
        pass

    @abstractmethod
    async def generate_faq_entry(
        self,
        cluster: IssueCluster,
    ) -> FAQEntry:
        """
        Generate a FAQ entry from an issue cluster.

        Args:
            cluster: Cluster of similar issues

        Returns:
            Generated FAQ entry
        """
        pass

    @abstractmethod
    async def complete(
        self,
        prompt: str,
        system_prompt: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2000,
    ) -> str:
        """
        Generic completion method.

        Args:
            prompt: User prompt
            system_prompt: Optional system prompt
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate

        Returns:
            Generated text
        """
        pass

    def get_total_tokens(self) -> int:
        """Get total tokens used across all requests."""
        return self._total_tokens

    def reset_token_count(self) -> None:
        """Reset token counter."""
        self._total_tokens = 0

    def _add_tokens(self, tokens: int) -> None:
        """Add to token counter."""
        self._total_tokens += tokens
