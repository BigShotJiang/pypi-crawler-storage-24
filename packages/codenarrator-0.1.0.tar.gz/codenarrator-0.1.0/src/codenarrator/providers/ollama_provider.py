"""Ollama provider implementation for local models."""

import json

import httpx

from codenarrator.providers.base import (
    AnalysisResult,
    BaseProvider,
    FAQEntry,
    Issue,
    IssueCluster,
)


class OllamaProvider(BaseProvider):
    """Ollama local model provider implementation."""

    def __init__(
        self,
        model: str = "llama3",
        api_key: str | None = None,
        base_url: str = "http://localhost:11434",
    ):
        """
        Initialize Ollama provider.

        Args:
            model: Ollama model to use (llama3, codellama, mistral, etc.)
            api_key: Not used for Ollama (local)
            base_url: Ollama API URL
        """
        super().__init__(model, api_key, base_url)
        self.client = httpx.AsyncClient(base_url=base_url, timeout=300.0)

    async def _generate(
        self,
        prompt: str,
        system_prompt: str | None = None,
        temperature: float = 0.7,
        format_type: str | None = None,
    ) -> str:
        """Generate completion using Ollama API."""
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": temperature,
            },
        }

        if system_prompt:
            payload["system"] = system_prompt

        if format_type:
            payload["format"] = format_type

        response = await self.client.post("/api/generate", json=payload)
        response.raise_for_status()

        data = response.json()
        self._add_tokens(data.get("eval_count", 0) + data.get("prompt_eval_count", 0))
        return data.get("response", "")

    async def analyze_code(
        self,
        code: str,
        language: str,
        prompt: str | None = None,
    ) -> AnalysisResult:
        """Analyze source code using Ollama."""
        system_prompt = """You are an expert code analyst. Analyze the provided code and extract:
1. A brief description of what the code does
2. A one-line summary
3. All functions with their signatures, parameters, return types, and descriptions
4. All classes with their methods and attributes
5. All imports
6. Usage examples if found in docstrings or comments

Respond ONLY in JSON format with keys: description, summary, functions, classes, imports, examples"""

        user_prompt = prompt or f"""Analyze this {language} code:

```{language}
{code}
```

Provide a comprehensive analysis in JSON format."""

        response = await self._generate(
            prompt=user_prompt,
            system_prompt=system_prompt,
            temperature=0.3,
            format_type="json",
        )

        result = json.loads(response)
        return AnalysisResult(
            description=result.get("description", ""),
            summary=result.get("summary", ""),
            functions=result.get("functions", []),
            classes=result.get("classes", []),
            imports=result.get("imports", []),
            examples=result.get("examples", []),
        )

    async def generate_readme(
        self,
        project_name: str,
        description: str,
        entry_point_analysis: AnalysisResult,
        dependencies: dict[str, list[str]],
        examples: list[str],
    ) -> str:
        """Generate README.md content."""
        system_prompt = """You are a technical documentation writer. Generate a comprehensive README.md file.
Include sections: Description, Installation, Quick Start, Usage Examples, API Reference, Contributing, License.
Use proper Markdown formatting with headers, code blocks, and badges where appropriate."""

        deps_str = "\n".join(
            f"- {lang}: {', '.join(deps)}" for lang, deps in dependencies.items()
        )
        examples_str = "\n\n".join(f"```\n{ex}\n```" for ex in examples) if examples else "No examples available."

        user_prompt = f"""Generate a README.md for the project:

Project Name: {project_name}
Description: {description}

Entry Point Analysis:
{entry_point_analysis.description}

Dependencies:
{deps_str}

Usage Examples:
{examples_str}

Generate a complete, professional README.md in Markdown format."""

        return await self._generate(
            prompt=user_prompt,
            system_prompt=system_prompt,
            temperature=0.5,
        )

    async def generate_api_docs(
        self,
        module_name: str,
        analysis: AnalysisResult,
        include_private: bool = False,
    ) -> str:
        """Generate API documentation for a module."""
        system_prompt = """You are an API documentation writer. Generate clear, comprehensive API documentation.
Include descriptions for all parameters, return values, and exceptions. Use proper Markdown formatting."""

        functions = analysis.functions
        classes = analysis.classes

        if not include_private:
            functions = [f for f in functions if not f.get("name", "").startswith("_")]
            classes = [c for c in classes if not c.get("name", "").startswith("_")]

        user_prompt = f"""Generate API documentation for module: {module_name}

Module Description: {analysis.description}

Functions:
{json.dumps(functions, indent=2)}

Classes:
{json.dumps(classes, indent=2)}

Generate comprehensive API documentation in Markdown format."""

        return await self._generate(
            prompt=user_prompt,
            system_prompt=system_prompt,
            temperature=0.3,
        )

    async def generate_architecture(
        self,
        modules: dict[str, AnalysisResult],
        dependencies: dict[str, list[str]],
    ) -> str:
        """Generate architecture documentation with Mermaid diagrams."""
        system_prompt = """You are a software architect. Generate architecture documentation with Mermaid diagrams.
Include:
1. An overview of the system architecture
2. A Mermaid flowchart showing module relationships
3. Description of data flow
4. Key design patterns used"""

        modules_desc = "\n".join(
            f"- {name}: {mod.summary}" for name, mod in modules.items()
        )
        deps_desc = "\n".join(
            f"- {mod} depends on: {', '.join(deps) if deps else 'none'}"
            for mod, deps in dependencies.items()
        )

        user_prompt = f"""Generate architecture documentation for a project with these modules:

Modules:
{modules_desc}

Dependencies:
{deps_desc}

Generate architecture documentation with Mermaid diagrams in Markdown format."""

        return await self._generate(
            prompt=user_prompt,
            system_prompt=system_prompt,
            temperature=0.4,
        )

    async def translate(
        self,
        text: str,
        target_language: str,
        preserve_code: bool = True,
        preserve_terms: list[str] | None = None,
    ) -> str:
        """Translate text to target language."""
        language_names = {
            "ru": "Russian",
            "zh": "Chinese (Simplified)",
            "es": "Spanish",
            "fr": "French",
            "de": "German",
            "ja": "Japanese",
            "ko": "Korean",
            "pt": "Portuguese",
        }

        target_name = language_names.get(target_language, target_language)

        system_prompt = f"""You are a professional translator specializing in technical documentation.
Translate the provided text to {target_name}.
{'Do NOT translate code blocks - keep them exactly as is.' if preserve_code else ''}
{'Do NOT translate these technical terms: ' + ', '.join(preserve_terms) if preserve_terms else ''}
Maintain all Markdown formatting, links, and structure."""

        return await self._generate(
            prompt=text,
            system_prompt=system_prompt,
            temperature=0.3,
        )

    async def cluster_issues(
        self,
        issues: list[Issue],
        max_clusters: int = 10,
    ) -> list[IssueCluster]:
        """Cluster similar issues together."""
        if not issues:
            return []

        system_prompt = f"""You are an expert at analyzing and categorizing software issues.
Group the provided issues into at most {max_clusters} clusters based on similarity.
For each cluster, identify:
1. The most representative issue
2. A brief topic description
3. All similar issues

Respond ONLY in JSON format as a list of clusters with keys: representative_id, topic, similar_ids"""

        issues_data = [
            {
                "id": issue.id,
                "title": issue.title,
                "labels": issue.labels,
            }
            for issue in issues
        ]

        user_prompt = f"""Cluster these GitHub issues:

{json.dumps(issues_data, indent=2)}

Return a JSON list of clusters."""

        response = await self._generate(
            prompt=user_prompt,
            system_prompt=system_prompt,
            temperature=0.3,
            format_type="json",
        )

        result = json.loads(response)
        clusters = result.get("clusters", result) if isinstance(result, dict) else result

        issue_map = {issue.id: issue for issue in issues}
        issue_clusters = []

        for cluster_data in clusters[:max_clusters]:
            rep_id = cluster_data.get("representative_id")
            similar_ids = cluster_data.get("similar_ids", [])

            if rep_id and rep_id in issue_map:
                similar_issues = [issue_map[i] for i in similar_ids if i in issue_map]
                issue_clusters.append(
                    IssueCluster(
                        representative_issue=issue_map[rep_id],
                        similar_issues=similar_issues,
                        topic=cluster_data.get("topic", ""),
                    )
                )

        return issue_clusters

    async def generate_faq_entry(
        self,
        cluster: IssueCluster,
    ) -> FAQEntry:
        """Generate a FAQ entry from an issue cluster."""
        system_prompt = """You are a technical support expert. Generate a clear FAQ entry based on GitHub issues.
The question should be concise and the answer should be helpful and actionable.
Include references to any PRs or commits that fixed the issue.
Respond ONLY in JSON format."""

        issue = cluster.representative_issue
        similar_titles = [i.title for i in cluster.similar_issues[:3]]

        user_prompt = f"""Generate a FAQ entry based on this issue cluster:

Main Issue: {issue.title}
Body: {issue.body or 'No description'}
Labels: {', '.join(issue.labels)}
Comments: {' | '.join(issue.comments[:3])}
Related PR: {issue.pr_number}
Related Commit: {issue.commit_sha}

Similar Issues: {', '.join(similar_titles)}

Generate a JSON object with: question, answer, related_issues (list of IDs), related_pr, related_commit."""

        response = await self._generate(
            prompt=user_prompt,
            system_prompt=system_prompt,
            temperature=0.4,
            format_type="json",
        )

        result = json.loads(response)
        return FAQEntry(
            question=result.get("question", issue.title),
            answer=result.get("answer", ""),
            related_issues=result.get("related_issues", [issue.id]),
            related_pr=result.get("related_pr", issue.pr_number),
            related_commit=result.get("related_commit", issue.commit_sha),
        )

    async def complete(
        self,
        prompt: str,
        system_prompt: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2000,
    ) -> str:
        """Generic completion method."""
        return await self._generate(
            prompt=prompt,
            system_prompt=system_prompt,
            temperature=temperature,
        )

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.client.aclose()
