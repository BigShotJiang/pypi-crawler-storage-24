"""
CodeNarrator - CLI utility for automatic documentation generation.

Transforms source code and GitHub Issues into clear, up-to-date,
and multilingual documentation using AI.
"""

__version__ = "0.1.0"
__author__ = "CodeNarrator Team"
__license__ = "MIT"
