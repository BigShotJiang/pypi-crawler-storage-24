"""Project scanning and file management."""

import fnmatch
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class SourceFile:
    """Represents a source file in the project."""

    path: Path
    relative_path: str
    language: str
    size_bytes: int
    hash: str | None = None

    @property
    def extension(self) -> str:
        """Get file extension."""
        return self.path.suffix


@dataclass
class ProjectInfo:
    """Information about the scanned project."""

    root_path: Path
    name: str
    description: str | None = None
    source_files: list[SourceFile] = field(default_factory=list)
    entry_points: list[Path] = field(default_factory=list)
    dependencies: dict[str, list[str]] = field(default_factory=dict)
    readme_exists: bool = False
    license_file: str | None = None

    def get_files_by_language(self, language: str) -> list[SourceFile]:
        """Get all source files for a specific language."""
        return [f for f in self.source_files if f.language == language]


class ProjectScanner:
    """Scans project structure and collects file information."""

    LANGUAGE_MAP = {
        ".py": "python",
        ".js": "javascript",
        ".jsx": "javascript",
        ".ts": "typescript",
        ".tsx": "typescript",
        ".go": "go",
        ".rs": "rust",
        ".java": "java",
        ".kt": "kotlin",
        ".rb": "ruby",
        ".php": "php",
        ".c": "c",
        ".cpp": "cpp",
        ".h": "c",
        ".hpp": "cpp",
        ".cs": "csharp",
        ".swift": "swift",
    }

    PACKAGE_FILES = {
        "pyproject.toml": "python",
        "requirements.txt": "python",
        "setup.py": "python",
        "package.json": "javascript",
        "Cargo.toml": "rust",
        "go.mod": "go",
        "pom.xml": "java",
        "Gemfile": "ruby",
        "composer.json": "php",
    }

    def __init__(self, project_path: Path, config: "Config"):  # type: ignore
        """
        Initialize project scanner.

        Args:
            project_path: Root path of the project
            config: Configuration object
        """
        self.project_path = project_path.resolve()
        self.config = config

    def scan(self) -> ProjectInfo:
        """
        Scan the project and return information about it.

        Returns:
            ProjectInfo with all collected data
        """
        info = ProjectInfo(
            root_path=self.project_path,
            name=self._detect_project_name(),
            description=self._detect_description(),
        )

        # Scan source files
        info.source_files = self._scan_source_files()

        # Find entry points
        info.entry_points = self._find_entry_points()

        # Detect dependencies
        info.dependencies = self._detect_dependencies()

        # Check for existing docs
        info.readme_exists = (self.project_path / "README.md").exists()

        # Detect license
        info.license_file = self._detect_license()

        return info

    def _detect_project_name(self) -> str:
        """Detect project name from various sources."""
        # Check pyproject.toml
        pyproject = self.project_path / "pyproject.toml"
        if pyproject.exists():
            try:
                import tomllib

                with open(pyproject, "rb") as f:
                    data = tomllib.load(f)
                    if "project" in data and "name" in data["project"]:
                        return data["project"]["name"]
                    if "tool" in data and "poetry" in data["tool"]:
                        return data["tool"]["poetry"].get("name", self.project_path.name)
            except Exception:
                pass

        # Check package.json
        package_json = self.project_path / "package.json"
        if package_json.exists():
            try:
                import json

                with open(package_json) as f:
                    data = json.load(f)
                    if "name" in data:
                        return data["name"]
            except Exception:
                pass

        return self.project_path.name

    def _detect_description(self) -> str | None:
        """Detect project description from various sources."""
        # Check pyproject.toml
        pyproject = self.project_path / "pyproject.toml"
        if pyproject.exists():
            try:
                import tomllib

                with open(pyproject, "rb") as f:
                    data = tomllib.load(f)
                    if "project" in data and "description" in data["project"]:
                        return data["project"]["description"]
                    if "tool" in data and "poetry" in data["tool"]:
                        return data["tool"]["poetry"].get("description")
            except Exception:
                pass

        # Check package.json
        package_json = self.project_path / "package.json"
        if package_json.exists():
            try:
                import json

                with open(package_json) as f:
                    data = json.load(f)
                    return data.get("description")
            except Exception:
                pass

        return None

    def _scan_source_files(self) -> list[SourceFile]:
        """Scan all source files in the project."""
        source_files = []

        for file_path in self.project_path.rglob("*"):
            if not file_path.is_file():
                continue

            # Check if file should be ignored
            if self._should_ignore(file_path):
                continue

            # Check if it's a source file
            language = self.LANGUAGE_MAP.get(file_path.suffix)
            if language and language in self.config.analysis.languages:
                relative_path = str(file_path.relative_to(self.project_path))
                source_files.append(
                    SourceFile(
                        path=file_path,
                        relative_path=relative_path,
                        language=language,
                        size_bytes=file_path.stat().st_size,
                    )
                )

        return source_files

    def _should_ignore(self, file_path: Path) -> bool:
        """Check if a file should be ignored based on config."""
        relative_path = str(file_path.relative_to(self.project_path))

        for pattern in self.config.analysis.ignore:
            # Handle both glob patterns and simple patterns
            if fnmatch.fnmatch(relative_path, pattern):
                return True
            if fnmatch.fnmatch(file_path.name, pattern):
                return True
            # Handle ** patterns
            if "**" in pattern:
                parts = pattern.split("**")
                if len(parts) == 2:
                    prefix, suffix = parts
                    if prefix and not relative_path.startswith(prefix):
                        continue
                    if suffix and not relative_path.endswith(suffix.strip("*")):
                        continue
                    return True

        return False

    def _find_entry_points(self) -> list[Path]:
        """Find entry point files in the project."""
        entry_points = []

        for pattern in self.config.project.entry_points:
            # Handle glob patterns
            if "*" in pattern:
                matches = list(self.project_path.glob(pattern))
                entry_points.extend(matches)
            else:
                path = self.project_path / pattern
                if path.exists():
                    entry_points.append(path)

        return list(set(entry_points))  # Remove duplicates

    def _detect_dependencies(self) -> dict[str, list[str]]:
        """Detect project dependencies from package files."""
        dependencies = {}

        for filename, language in self.PACKAGE_FILES.items():
            file_path = self.project_path / filename
            if file_path.exists():
                deps = self._parse_dependencies(file_path, filename)
                if deps:
                    dependencies[language] = deps

        return dependencies

    def _parse_dependencies(self, file_path: Path, filename: str) -> list[str]:
        """Parse dependencies from a package file."""
        deps = []

        if filename == "requirements.txt":
            try:
                content = file_path.read_text()
                for line in content.splitlines():
                    line = line.strip()
                    if line and not line.startswith("#"):
                        deps.append(line.split("==")[0].split(">=")[0].split("<")[0])
            except Exception:
                pass

        elif filename == "package.json":
            try:
                import json

                with open(file_path) as f:
                    data = json.load(f)
                    deps = list(data.get("dependencies", {}).keys())
                    deps.extend(data.get("devDependencies", {}).keys())
            except Exception:
                pass

        elif filename == "pyproject.toml":
            try:
                import tomllib

                with open(file_path, "rb") as f:
                    data = tomllib.load(f)
                    # Poetry format
                    if "tool" in data and "poetry" in data["tool"]:
                        deps = list(data["tool"]["poetry"].get("dependencies", {}).keys())
                        deps.extend(data["tool"]["poetry"].get("dev-dependencies", {}).keys())
                    # PEP 621 format
                    elif "project" in data:
                        deps = [d.split("[")[0] for d in data["project"].get("dependencies", [])]
            except Exception:
                pass

        return deps

    def _detect_license(self) -> str | None:
        """Detect license file in the project."""
        license_patterns = ["LICENSE", "LICENSE.md", "LICENSE.txt", "license", "LICENCE"]

        for pattern in license_patterns:
            path = self.project_path / pattern
            if path.exists():
                return pattern

        return None

    def get_changed_files(self, cache: dict[str, str]) -> list[SourceFile]:
        """
        Get files that have changed since the last run.

        Args:
            cache: Dictionary mapping file paths to their hashes

        Returns:
            List of changed or new files
        """
        import hashlib

        changed = []
        for source_file in self._scan_source_files():
            # Calculate hash
            content = source_file.path.read_bytes()
            file_hash = hashlib.sha256(content).hexdigest()
            source_file.hash = file_hash

            # Check if changed
            cached_hash = cache.get(source_file.relative_path)
            if cached_hash != file_hash:
                changed.append(source_file)

        return changed
