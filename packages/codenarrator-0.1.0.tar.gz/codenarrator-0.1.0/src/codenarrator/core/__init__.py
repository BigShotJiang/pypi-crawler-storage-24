"""Core module for CodeNarrator."""

from codenarrator.core.config import Config, load_config
from codenarrator.core.project import ProjectScanner

__all__ = ["Config", "load_config", "ProjectScanner"]
