"""Configuration management for CodeNarrator."""

from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, Field


class ProjectConfig(BaseModel):
    """Project-specific configuration."""

    name: str | None = Field(default=None, description="Project name (auto-detected if not specified)")
    description: str | None = Field(default=None, description="Project description")
    entry_points: list[str] = Field(
        default=["main.py", "src/**/__init__.py", "index.js", "src/index.ts"],
        description="Entry points for analysis",
    )


class ProviderConfig(BaseModel):
    """AI Provider configuration."""

    type: Literal["openai", "anthropic", "ollama"] = Field(default="openai", description="AI provider type")
    model: str = Field(default="gpt-4o", description="Model for code analysis")
    translation_model: str = Field(default="gpt-4o-mini", description="Model for translations")
    api_key: str | None = Field(default=None, description="API key (can also use env vars)")
    base_url: str | None = Field(
        default=None,
        description="Base URL for API (useful for Ollama or proxies)",
    )


class AnalysisConfig(BaseModel):
    """Code analysis configuration."""

    languages: list[str] = Field(
        default=["python", "javascript"],
        description="Languages to parse with Tree-sitter",
    )
    ignore: list[str] = Field(
        default=[
            "node_modules/**",
            ".venv/**",
            "venv/**",
            "**/tests/**",
            "**/__pycache__/**",
            "**/.git/**",
            "**/dist/**",
            "**/build/**",
        ],
        description="Glob patterns to ignore",
    )
    include_private: bool = Field(
        default=False,
        description="Include private methods and classes in documentation",
    )
    include_tests: bool = Field(
        default=False,
        description="Include test files in analysis",
    )


class FAQConfig(BaseModel):
    """FAQ generation configuration."""

    github_repo: str | None = Field(
        default=None,
        description="GitHub repository in format 'owner/repo'",
    )
    labels: list[str] = Field(
        default=["bug", "question", "help wanted"],
        description="Issue labels to include",
    )
    days_back: int = Field(
        default=30,
        description="Number of days to look back for closed issues",
        ge=1,
        le=365,
    )
    max_issues: int = Field(
        default=100,
        description="Maximum number of issues to process",
        ge=10,
        le=500,
    )


class LocalizationConfig(BaseModel):
    """Localization configuration."""

    enabled: bool = Field(default=True, description="Enable localization")
    languages: list[str] = Field(
        default=["ru", "zh", "es"],
        description="Target languages for translation",
    )
    preserve_code: bool = Field(
        default=True,
        description="Preserve code blocks without translation",
    )
    preserve_terms: list[str] = Field(
        default=["API", "SDK", "CLI", "REST", "GraphQL", "Docker", "Kubernetes"],
        description="Technical terms to preserve without translation",
    )


class OutputConfig(BaseModel):
    """Output configuration."""

    docs_dir: str = Field(default="docs", description="Output directory for documentation")
    readme_template: str = Field(
        default="default",
        description="Template name or path for README generation",
    )
    api_template: str = Field(
        default="default",
        description="Template name or path for API documentation",
    )
    architecture_template: str = Field(
        default="default",
        description="Template name or path for architecture documentation",
    )


class Config(BaseModel):
    """Main configuration model for CodeNarrator."""

    version: int = Field(default=1, description="Configuration version")
    project: ProjectConfig = Field(default_factory=ProjectConfig)
    provider: ProviderConfig = Field(default_factory=ProviderConfig)
    analysis: AnalysisConfig = Field(default_factory=AnalysisConfig)
    faq: FAQConfig = Field(default_factory=FAQConfig)
    localization: LocalizationConfig = Field(default_factory=LocalizationConfig)
    output: OutputConfig = Field(default_factory=OutputConfig)

    # CLI overrides (not stored in YAML)
    provider_override: str = Field(default="openai", exclude=True)
    model_override: str = Field(default="gpt-4o", exclude=True)


def load_config(project_path: Path, config_file: Path | None = None) -> Config:
    """
    Load configuration from YAML file.

    Args:
        project_path: Path to the project directory
        config_file: Optional path to configuration file

    Returns:
        Config object with loaded or default values
    """
    config_path = config_file or project_path / ".narrator.yaml"

    if not config_path.exists():
        return Config()

    with open(config_path, encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}

    # Flatten nested structure for Pydantic
    config_data = {
        "version": data.get("version", 1),
        "project": data.get("project", {}),
        "provider": data.get("provider", {}),
        "analysis": data.get("analysis", {}),
        "faq": data.get("faq", {}),
        "localization": data.get("localization", {}),
        "output": data.get("output", {}),
    }

    return Config(**config_data)


def save_config(config: Config, config_path: Path) -> None:
    """
    Save configuration to YAML file.

    Args:
        config: Config object to save
        config_path: Path to save configuration file
    """
    # Convert to dict, excluding override fields
    data = config.model_dump(exclude={"provider_override", "model_override"})

    with open(config_path, "w", encoding="utf-8") as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False)


def get_default_config_content() -> str:
    """Return default configuration file content."""
    return """# CodeNarrator Configuration
# https://github.com/codenarrator/codenarrator

version: 1

# Project settings (auto-detected if not specified)
project:
  name: null
  description: null
  entry_points:
    - main.py
    - src/**/__init__.py

# AI Provider configuration
provider:
  type: openai          # openai | anthropic | ollama
  model: gpt-4o         # Model for code analysis
  translation_model: gpt-4o-mini  # Model for translations

# Code analysis settings
analysis:
  languages:
    - python
    - javascript
  ignore:
    - node_modules/**
    - .venv/**
    - "**/tests/**"
    - "**/__pycache__/**"
  include_private: false

# FAQ generation settings
faq:
  github_repo: null     # Format: owner/repo
  labels:
    - bug
    - question
    - help wanted
  days_back: 30

# Localization settings
localization:
  enabled: true
  languages:
    - ru
    - zh
    - es
  preserve_code: true

# Output settings
output:
  docs_dir: docs
  readme_template: default
"""
