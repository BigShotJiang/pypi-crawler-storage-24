"""Cache management for incremental updates."""

import json
from datetime import datetime
from pathlib import Path
from typing import Any


class CacheManager:
    """Manages cache for incremental documentation updates."""

    CACHE_DIR = ".narrator"
    CACHE_FILE = "cache.json"

    def __init__(self, project_path: Path):
        """
        Initialize cache manager.

        Args:
            project_path: Root path of the project
        """
        self.project_path = project_path
        self.cache_path = project_path / self.CACHE_DIR / self.CACHE_FILE
        self._cache: dict[str, Any] = {}
        self._load()

    def _load(self) -> None:
        """Load cache from disk."""
        if self.cache_path.exists():
            try:
                with open(self.cache_path, encoding="utf-8") as f:
                    self._cache = json.load(f)
            except (OSError, json.JSONDecodeError):
                self._cache = self._create_empty_cache()
        else:
            self._cache = self._create_empty_cache()

    def _create_empty_cache(self) -> dict[str, Any]:
        """Create an empty cache structure."""
        return {
            "version": 1,
            "last_run": None,
            "files": {},
            "issues": {
                "last_sync": None,
                "processed_ids": [],
            },
            "stats": {
                "total_tokens_used": 0,
                "total_runs": 0,
            },
        }

    def save(self) -> None:
        """Save cache to disk."""
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        self._cache["last_run"] = datetime.utcnow().isoformat()

        with open(self.cache_path, "w", encoding="utf-8") as f:
            json.dump(self._cache, f, indent=2)

    def get_file_hash(self, relative_path: str) -> str | None:
        """
        Get cached hash for a file.

        Args:
            relative_path: Relative path to the file

        Returns:
            Cached hash or None if not cached
        """
        file_cache = self._cache["files"].get(relative_path, {})
        return file_cache.get("hash")

    def set_file_hash(
        self,
        relative_path: str,
        file_hash: str,
        output_files: list[str] | None = None,
    ) -> None:
        """
        Set cached hash for a file.

        Args:
            relative_path: Relative path to the file
            file_hash: SHA256 hash of the file content
            output_files: List of output files generated from this source
        """
        self._cache["files"][relative_path] = {
            "hash": file_hash,
            "analyzed_at": datetime.utcnow().isoformat(),
            "output_files": output_files or [],
        }

    def get_changed_files(self, current_files: dict[str, str]) -> dict[str, str]:
        """
        Get files that have changed or are new.

        Args:
            current_files: Dictionary mapping relative paths to their current hashes

        Returns:
            Dictionary of changed/new files with their hashes
        """
        changed = {}

        for path, hash_value in current_files.items():
            cached_hash = self.get_file_hash(path)
            if cached_hash != hash_value:
                changed[path] = hash_value

        return changed

    def get_deleted_files(self, current_files: dict[str, str]) -> list[str]:
        """
        Get files that have been deleted since last run.

        Args:
            current_files: Dictionary mapping relative paths to their current hashes

        Returns:
            List of deleted file paths
        """
        cached_files = set(self._cache["files"].keys())
        current = set(current_files.keys())
        return list(cached_files - current)

    def get_output_files_for_source(self, relative_path: str) -> list[str]:
        """
        Get output files generated from a source file.

        Args:
            relative_path: Relative path to the source file

        Returns:
            List of output file paths
        """
        file_cache = self._cache["files"].get(relative_path, {})
        return file_cache.get("output_files", [])

    # Issue-related cache methods
    def get_last_issue_sync(self) -> str | None:
        """Get timestamp of last issue sync."""
        return self._cache["issues"].get("last_sync")

    def set_last_issue_sync(self, timestamp: str) -> None:
        """Set timestamp of last issue sync."""
        self._cache["issues"]["last_sync"] = timestamp

    def get_processed_issue_ids(self) -> list[int]:
        """Get list of already processed issue IDs."""
        return self._cache["issues"].get("processed_ids", [])

    def add_processed_issue_ids(self, issue_ids: list[int]) -> None:
        """Add issue IDs to the processed list."""
        existing = set(self._cache["issues"].get("processed_ids", []))
        existing.update(issue_ids)
        self._cache["issues"]["processed_ids"] = list(existing)

    # Stats methods
    def add_token_usage(self, tokens: int) -> None:
        """Add to total token usage counter."""
        self._cache["stats"]["total_tokens_used"] = (
            self._cache["stats"].get("total_tokens_used", 0) + tokens
        )

    def increment_run_count(self) -> None:
        """Increment total run counter."""
        self._cache["stats"]["total_runs"] = self._cache["stats"].get("total_runs", 0) + 1

    def get_stats(self) -> dict[str, Any]:
        """Get cache statistics."""
        return self._cache.get("stats", {})

    def clear(self) -> None:
        """Clear the cache."""
        self._cache = self._create_empty_cache()
        if self.cache_path.exists():
            self.cache_path.unlink()

    def remove_file(self, relative_path: str) -> None:
        """
        Remove a file from the cache.

        Args:
            relative_path: Relative path to the file
        """
        self._cache["files"].pop(relative_path, None)
