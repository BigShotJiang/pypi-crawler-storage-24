"""Entry point for running codenarrator as a module."""

from codenarrator.cli.main import app

if __name__ == "__main__":
    app()
