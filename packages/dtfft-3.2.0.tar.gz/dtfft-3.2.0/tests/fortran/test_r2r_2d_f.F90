!------------------------------------------------------------------------------------------------
! Copyright (c) 2021 - 2025, Oleg Shatrov
! All rights reserved.
! This file is part of dtFFT library.

! dtFFT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! dtFFT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program.  If not, see <https://www.gnu.org/licenses/>.
!------------------------------------------------------------------------------------------------
#include "dtfft_config.h"
program test_r2r_2d
use iso_c_binding
use iso_fortran_env
use dtfft
use test_utils
#if defined(DTFFT_WITH_CUDA)
use dtfft_interface_cuda_runtime
#endif
#include "_dtfft_cuda.h"
#include "_dtfft_mpi.h"
#include "dtfft.f03"
implicit none
  type(c_ptr) :: check
  real(real64),  pointer :: in(:,:), out(:,:)
  integer(int64) :: scaler, alloc_size, in_size, out_size
  integer(int32), parameter :: nx = 8, ny = 12
  integer(int32) :: comm_size, comm_rank, ierr
  type(dtfft_plan_r2r_t) :: plan
  integer(int32) :: in_counts(2), out_counts(2)
  real(real64) :: tf, tb
  type(dtfft_r2r_kind_t) :: kinds(2)
  type(dtfft_executor_t) :: executor
  type(dtfft_config_t) :: config
#if defined(DTFFT_WITH_CUDA)
  type(dtfft_platform_t) :: platform
#endif

  call MPI_Init(ierr)
  call MPI_Comm_size(MPI_COMM_WORLD, comm_size, ierr)
  call MPI_Comm_rank(MPI_COMM_WORLD, comm_rank, ierr)

  if(comm_rank == 0) then
    write(output_unit, '(a)') "----------------------------------------"
    write(output_unit, '(a)') "|       dtFFT test: r2r_2d             |"
    write(output_unit, '(a)') "----------------------------------------"
    write(output_unit, '(a, i0, a, i0)') 'Nx = ',nx, ', Ny = ',ny
    write(output_unit, '(a, i0)') 'Number of processors: ', comm_size
    write(output_unit, '(a)') "----------------------------------------"
  endif

  call attach_gpu_to_process()

  kinds(:) = DTFFT_DCT_1
  executor = DTFFT_EXECUTOR_NONE

#if defined (DTFFT_WITH_FFTW)
  executor = DTFFT_EXECUTOR_FFTW3
#endif

#if defined(DTFFT_WITH_CUDA)
  block
    character(len=5) :: platform_env
    integer(int32) :: env_len

    call get_environment_variable("DTFFT_PLATFORM", platform_env, env_len)

    if ( env_len == 0 .or. trim(adjustl(platform_env)) == "cuda" ) then
# if defined( DTFFT_WITH_VKFFT )
      executor = DTFFT_EXECUTOR_VKFFT
# endif
    endif
  endblock
#endif

  if ( executor == DTFFT_EXECUTOR_NONE ) then
    scaler = 1
  else
    scaler = 4 * (nx - 1) * (ny - 1)
  endif

  config = dtfft_config_t()
  config%enable_mpi_backends = .true.
  call dtfft_set_config(config, error_code=ierr); DTFFT_CHECK(ierr)

  call plan%create([nx, ny], kinds=kinds, effort=DTFFT_EXHAUSTIVE, executor=executor, error_code=ierr); DTFFT_CHECK(ierr)
  call plan%report(error_code=ierr); DTFFT_CHECK(ierr)
  call plan%get_local_sizes(in_counts=in_counts, out_counts=out_counts, alloc_size=alloc_size, error_code=ierr); DTFFT_CHECK(ierr)

  call plan%mem_alloc(alloc_size, in, in_counts, error_code=ierr); DTFFT_CHECK(ierr)
  call plan%mem_alloc(alloc_size, out, out_counts, error_code=ierr); DTFFT_CHECK(ierr)

  in_size = product(in_counts)
  out_size = product(out_counts)

  check = mem_alloc_host(in_size * DOUBLE_STORAGE_SIZE)
  call setTestValuesDouble(check, in_size)

#if defined(DTFFT_WITH_CUDA)
  platform = plan%get_platform(error_code=ierr); DTFFT_CHECK(ierr)
  call doubleH2D(check, c_loc(in), in_size, platform%val)
#else
  call doubleH2D(check, c_loc(in), in_size)
#endif

  tf = 0.0_real64 - MPI_Wtime()
  call plan%execute(in, out, DTFFT_EXECUTE_FORWARD, error_code=ierr); DTFFT_CHECK(ierr)
#if defined(DTFFT_WITH_CUDA)
  if ( platform == DTFFT_PLATFORM_CUDA ) then
    CUDA_CALL( cudaDeviceSynchronize() )
  endif
#endif
  tf = tf + MPI_Wtime()

#if defined(DTFFT_WITH_CUDA)
  call scaleDouble(executor%val, c_loc(out), out_size, scaler, platform%val, NULL_STREAM)
#else
  call scaleDouble(executor%val, c_loc(out), out_size, scaler)
#endif

  tb = 0.0_real64 - MPI_Wtime()
  call plan%execute(out, in, DTFFT_EXECUTE_BACKWARD, error_code=ierr); DTFFT_CHECK(ierr)
#if defined(DTFFT_WITH_CUDA)
  if ( platform == DTFFT_PLATFORM_CUDA ) then
    CUDA_CALL( cudaDeviceSynchronize() )
  endif
#endif
  tb = tb + MPI_Wtime()

#if defined(DTFFT_WITH_CUDA) && !defined(DTFFT_WITH_MOCK_ENABLED)
  call checkAndReportDouble(int(nx * ny, int64), tf, tb, c_loc(in), in_size, check, platform%val)
#else
  call checkAndReportDouble(int(nx * ny, int64), tf, tb, c_loc(in), in_size, check)
#endif

  call plan%mem_free(in)
  call plan%mem_free(out)
  call mem_free_host(check)

  call plan%destroy()
  call MPI_Finalize(ierr)
end program test_r2r_2d