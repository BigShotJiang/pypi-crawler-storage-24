# Scan Fixtures

Test fixtures for `portolan scan` — the directory scanning and validation command.

## Purpose

These fixtures test **directory structure detection**, not file content parsing. The `scan` command analyzes directories to identify:

- Geospatial files that can be imported
- Structural issues (multiple primary assets, invalid filenames, etc.)
- Files that should be skipped (unsupported formats, sidecars)

**What we're testing:**
- Directory traversal and file discovery
- Issue detection and severity classification
- Sidecar file association (`.dbf`, `.prj`, `.shx` with `.shp`)
- Filename validation

**What we're NOT testing:**
- File content validity (that's `dataset add`'s job)
- Geometry correctness (upstream library's job)
- Format conversion (geoparquet-io/rio-cogeo's job)

## Fixture Directories

| Directory | Scenario | Expected Behavior |
|-----------|----------|-------------------|
| `clean_flat/` | 3 independent files | Clean scan, no warnings |
| `multiple_primaries/` | 3 primary assets in one dir | Warning: ambiguous structure |
| `complete_shapefile/` | Full shapefile set | Recognized as single dataset |
| `incomplete_shapefile/` | `.shp` missing `.dbf` | Error: incomplete shapefile |
| `invalid_chars/` | Filenames with `()` and accents | Warning: invalid characters |
| `mixed_formats/` | Raster + vector together | Info: mixed format types |
| `nested/` | Hierarchical `category/year/` structure | Depth detection |
| `three_level_nested/` | 3+ level nesting `GAUL_L2/by_country/XXX/` | Deep collection ID inference |
| `mixed_depths/` | Shallow + nested collections in same catalog | Mixed depth handling |
| `geoparquet_with_companions/` | GeoParquet + plain Parquet companion | Companion file detection |
| `multiple_geoparquet/` | Two GeoParquet files in same dir | Multiple geo-primary warning |
| `deep_nested/` | 5+ levels of nesting | Extreme depth handling |
| `flat_collection/` | Multiple files at root level | ADR-0031 flat pattern |
| `unsupported/` | `.csv`, `.mxd` + one valid file | Skip unsupported, find valid |
| `duplicate_basenames/` | `argentina.geojson` + `Argentina.geojson` | Warning: case collision |

## Fixture Details

### `clean_flat/`

Happy path: a directory with independent, valid geospatial files.

| File | Format | Size | Source |
|------|--------|------|--------|
| `example.parquet` | GeoParquet | 30KB | Unknown origin (from Downloads) |
| `argentina.geojson` | GeoJSON | 10KB | Unknown origin (from Downloads) |
| `seaLevelDistanceGeoJSON.geojson` | GeoJSON | 2KB | Unknown origin (from Downloads) |

**Tests:** Basic file discovery, extension filtering, no false positives.

### `multiple_primaries/`

Three GeoJSON files that could each be a "primary" dataset — ambiguous whether they should be separate datasets or one collection.

| File | Format | Size | Source |
|------|--------|------|--------|
| `la_plata_L1.geojson` | GeoJSON | ~400B | Derived from La Plata, Argentina admin boundaries (Level 1) |
| `la_plata_L2.geojson` | GeoJSON | ~550B | Derived from La Plata, Argentina admin boundaries (Level 2) |
| `la_plata_L3.geojson` | GeoJSON | ~400B | Derived from La Plata, Argentina admin boundaries (Level 3) |

**Note:** These were simplified from larger source files using `ST_Simplify(geom, 0.01)` and limited to 1 feature each.

**Tests:** Detection of multiple primary assets in same directory, appropriate warning generation.

### `complete_shapefile/`

A valid, complete ESRI Shapefile with all required sidecar files.

| File | Purpose |
|------|---------|
| `radios_sample.shp` | Geometry |
| `radios_sample.dbf` | Attributes |
| `radios_sample.shx` | Spatial index |
| `radios_sample.prj` | Projection/CRS |

**Source:** Subset of Argentina census radios (Radios_2022), limited to 5 features via `ogr2ogr`.

**Tests:** Shapefile sidecar association, recognition as single dataset (not 4 separate files).

### `incomplete_shapefile/`

An ESRI Shapefile missing its `.dbf` file (attribute table).

| File | Present |
|------|---------|
| `radios_sample.shp` | Yes |
| `radios_sample.dbf` | **No** |
| `radios_sample.shx` | Yes |
| `radios_sample.prj` | Yes |

**Tests:** Error detection for incomplete shapefile, clear error message.

### `invalid_chars/`

Files with characters that may cause issues on some filesystems or in URLs.

| File | Issue |
|------|-------|
| `data (copy).parquet` | Parentheses and spaces |
| `données.geojson` | Non-ASCII character (French accent) |

**Tests:** Filename validation, warning generation, suggested fixes.

### `mixed_formats/`

Raster and vector files in the same directory — not necessarily wrong, but worth noting.

| File | Format |
|------|--------|
| `example.parquet` | Vector (GeoParquet) |
| `ID1_N80_W170_RP10_depth_reclass.tif` | Raster (GeoTIFF) |

**Source:** Raster is flood depth data from unknown source (from Downloads).

**Tests:** Mixed format detection, info-level suggestion (not error or warning).

### `nested/`

Hierarchical directory structure mimicking real-world organization.

```
nested/
├── census/
│   ├── 2020/
│   │   └── boundaries.geojson
│   └── 2022/
│       └── boundaries.geojson
└── imagery/
    └── 2024/
        └── flood_depth.tif
```

**Tests:** Recursive scanning, depth detection, `--depth` flag mapping.

### `unsupported/`

Mix of unsupported and supported formats.

| File | Format | Supported? |
|------|--------|------------|
| `argentina.geojson` | GeoJSON | Yes |
| `metadata.csv` | CSV | No |
| `project.mxd` | ArcMap project | No |

**Tests:** Skip unsupported formats, still find valid files, report skipped count.

### `duplicate_basenames/`

Two files with the same base name but different case.

| File | Notes |
|------|-------|
| `argentina.geojson` | Lowercase |
| `Argentina.geojson` | Uppercase |

**Note:** On case-insensitive filesystems (macOS, Windows), these would collide. On Linux they coexist but may cause confusion when generating IDs.

**Tests:** Case collision detection, unique ID generation.

### `three_level_nested/`

Three-level directory nesting for testing ADR-0032 nested catalog support.

```
three_level_nested/
└── GAUL_L2/
    └── by_country/
        ├── AFG/
        │   └── AFG.parquet
        └── ALB/
            └── ALB.parquet
```

| File | Format | Size | Source |
|------|--------|------|--------|
| `AFG.parquet` | GeoParquet | ~9KB | GAUL 2024 L2 admin boundaries (Saint Barthélemy, renamed) |
| `ALB.parquet` | GeoParquet | ~79KB | GAUL 2024 L2 admin boundaries (Svalbard, renamed) |

**Source:** [GAUL 2024](https://data.apps.fao.org/catalog/dataset/global-administrative-unit-layers-gaul) - Global Administrative Unit Layers from FAO. Small island territories selected for minimal file size.

**Tests:** Collection ID inference returns `GAUL_L2/by_country/AFG`, `GAUL_L2/by_country/ALB`.

### `mixed_depths/`

Shallow and deeply nested collections coexisting in the same catalog root.

```
mixed_depths/
├── shallow_collection/
│   └── data.parquet
└── theme/
    └── nested_collection/
        └── data.parquet
```

| File | Format | Size | Source |
|------|--------|------|--------|
| `shallow_collection/data.parquet` | GeoParquet | ~67KB | Den Haag bomenrij (tree rows) |
| `theme/nested_collection/data.parquet` | GeoParquet | ~56KB | Den Haag peilbuizen (monitoring wells) |

**Source:** [Den Haag Open Data](https://denhaag.dataplatform.nl/) - Municipality of The Hague, Netherlands environmental datasets.

**Tests:** Collection IDs: `shallow_collection` and `theme/nested_collection` detected correctly.

### `geoparquet_with_companions/`

One GeoParquet primary + plain Parquet companion file (valid per ADR-0031).

```
geoparquet_with_companions/
├── data.parquet          <- GeoParquet (primary, has geo metadata)
└── lookup.parquet        <- Plain Parquet (companion, no geo metadata)
```

| File | Format | Size | Source |
|------|--------|------|--------|
| `data.parquet` | GeoParquet | ~13KB | Den Haag luchtkwaliteit_meetpunten (air quality monitoring points) |
| `lookup.parquet` | Plain Parquet | ~1KB | Synthetic (3-row lookup table, no geometry) |

**Tests:** `is_geoparquet()` distinguishes primary from companion. No "multiple primaries" warning.

### `multiple_geoparquet/`

Two GeoParquet files in the same directory — triggers "multiple geo-primaries" warning.

```
multiple_geoparquet/
├── milieuzone.parquet
└── peilbuizen.parquet
```

| File | Format | Size | Source |
|------|--------|------|--------|
| `milieuzone.parquet` | GeoParquet | ~21KB | Den Haag milieuzone (environmental zone boundaries) |
| `peilbuizen.parquet` | GeoParquet | ~56KB | Den Haag peilbuizen (groundwater monitoring wells) |

**Source:** [Den Haag Open Data](https://denhaag.dataplatform.nl/)

**Tests:** Warning: "Multiple primary geo-assets in same directory". Suggestion: reorganize.

### `deep_nested/`

Extreme nesting (5+ levels) for testing depth limits.

```
deep_nested/
└── level1/
    └── level2/
        ├── shallow_collection/
        │   └── data.parquet
        └── level3/
            └── level4/
                └── level5/
                    └── data.parquet
```

| File | Format | Size | Source |
|------|--------|------|--------|
| `level5/data.parquet` | GeoParquet | ~13KB | Den Haag luchtkwaliteit_meetpunten |
| `shallow_collection/data.parquet` | GeoParquet | ~21KB | Den Haag milieuzone |

**Source:** [Den Haag Open Data](https://denhaag.dataplatform.nl/)

**Tests:** Collection ID: `level1/level2/level3/level4/level5` (no artificial depth limits).

### `flat_collection/`

Multiple GeoParquet files at root level — tests ADR-0031 flat collection pattern.

```
flat_collection/
├── bomenrij.parquet
├── milieuzone.parquet
└── peilbuizen.parquet
```

| File | Format | Size | Source |
|------|--------|------|--------|
| `bomenrij.parquet` | GeoParquet | ~67KB | Den Haag tree rows |
| `milieuzone.parquet` | GeoParquet | ~21KB | Den Haag environmental zone |
| `peilbuizen.parquet` | GeoParquet | ~56KB | Den Haag monitoring wells |

**Source:** [Den Haag Open Data](https://denhaag.dataplatform.nl/)

**Tests:** All files at collection level. Warning: multiple primaries (unless organized as partitioned).

## Fixture Size

Total size: ~850KB (~40 files)

All fixtures are small enough to commit to git. No network dependencies during tests.

## Runtime-Created Fixtures

Some edge cases cannot be represented as static fixtures committed to git. These are created at test runtime using `pytest`'s `tmp_path` fixture.

### Permission Edge Cases

**Why runtime?** Files with restrictive permissions (e.g., `chmod 000`) cannot be committed to git and would break `git clone` for everyone.

**Test scenarios (in `tests/unit/test_scan.py::TestPermissionEdgeCases`):**

| Scenario | How Created | What It Tests |
|----------|-------------|---------------|
| No-execute directory | `os.chmod(dir, 0o644)` | Files inside cannot be stat'd |
| Stat failures | Symlinks + follow mode | OSError handling during walk |

**Platform notes:**
- Tests skip on Windows (`@pytest.mark.skipif(sys.platform == "win32", ...)`)
- Linux `os.scandir()` may succeed on no-execute dirs but `stat()` fails
- Cleanup restores permissions even if tests fail

### Symlink Edge Cases

**Why runtime?** Git doesn't preserve symlinks portably across platforms.

**Test scenarios (in `tests/unit/test_scan.py::TestBrokenSymlinkEdgeCases`):**

| Scenario | How Created | What It Tests |
|----------|-------------|---------------|
| Broken symlink | `path.symlink_to(nonexistent)` | Warning emitted for dangling links |
| Valid symlink | `path.symlink_to(real_file)` | Followed when `follow_symlinks=True` |
| Symlink chain | Multiple chained symlinks | Deep chains resolved correctly |
| Broken ignored | Broken + `follow_symlinks=False` | No warning when not following |

**Platform notes:**
- Tests skip on Windows
- Broken symlinks have `is_file(follow_symlinks=True) = False`
- `BROKEN_SYMLINK` issue type added for these cases

## Adding New Fixtures

1. Identify the structural scenario you need to test
2. Create minimal files (prefer <10KB per file, <100KB per directory)
3. Add directory to this README with explanation
4. Update `tests/conftest.py` with pytest fixtures if needed
5. Ensure fixture tests **structure**, not **content** (content testing belongs in `tests/fixtures/vector/` etc.)

**For runtime fixtures:** If your scenario cannot be static (permissions, symlinks, race conditions), document it in the "Runtime-Created Fixtures" section above and implement in the appropriate test class.

## Provenance Notes

### Known Sources

| Source | License | Fixtures Using |
|--------|---------|----------------|
| [GAUL 2024](https://data.apps.fao.org/catalog/dataset/global-administrative-unit-layers-gaul) | CC BY-NC-SA 3.0 IGO | `three_level_nested/` |
| [Den Haag Open Data](https://denhaag.dataplatform.nl/) | Public Domain / CC0 | `mixed_depths/`, `geoparquet_with_companions/`, `multiple_geoparquet/`, `deep_nested/`, `flat_collection/` |
| [INDEC Argentina](https://www.indec.gob.ar/) | Public Domain | `complete_shapefile/`, `incomplete_shapefile/` |

### Unknown Sources

Most source data came from `~/Downloads/spatial/` — a collection of geospatial files accumulated over time. Original sources include:

- **La Plata boundaries:** Administrative boundaries for La Plata, Argentina (unknown exact source)
- **Radios_2022:** Argentina 2022 census radios (INDEC)
- **Flood depth raster:** Unknown source, appears to be flood modeling output
- **Other files:** Various small files of unknown provenance, kept because they're valid examples of their formats

If exact provenance matters for a specific test, document it when you add the test.

### Adding New Fixtures from Real Data

When copying from `~/Documents/dev/portolan/portolan-test-data/`:

1. **Prefer smallest files** — Use `find ... -name "*.parquet" -size -500k` to find sub-500KB files
2. **Document the source** — Add to the provenance table above
3. **Check licenses** — Ensure data can be redistributed
4. **Rename if helpful** — Use descriptive names that match the test case
