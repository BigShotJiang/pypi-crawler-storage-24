"""
kinlyze/exceptions.py
Custom exception hierarchy for clear, actionable error messages.
"""


class KinlyzeError(Exception):
    """Base exception. All Kinlyze errors inherit from this."""
    pass


class GitNotFoundError(KinlyzeError):
    """Git binary not found on PATH."""
    def __str__(self):
        return (
            "Git is not installed or not on your PATH.\n"
            "  Install: https://git-scm.com/downloads"
        )


class NotARepoError(KinlyzeError):
    """Path is not a git repository."""
    def __init__(self, path: str):
        self.path = path

    def __str__(self):
        return (
            f"Not a git repository: {self.path}\n"
            "  Run this command inside a git repository, or use --repo <path>."
        )


class EmptyRepoError(KinlyzeError):
    """Repository has no commits."""
    def __str__(self):
        return (
            "This repository has no commits yet.\n"
            "  Kinlyze needs at least one commit to analyze."
        )


class NoDataError(KinlyzeError):
    """No analyzable data found for the given window."""
    def __init__(self, days: int):
        self.days = days

    def __str__(self):
        return (
            f"No commits found in the last {self.days} days.\n"
            f"  Try: kinlyze --days {self.days * 2}"
        )


class GitCommandError(KinlyzeError):
    """A git command returned a non-zero exit code."""
    def __init__(self, cmd: str, stderr: str):
        self.cmd    = cmd
        self.stderr = stderr

    def __str__(self):
        return (
            f"Git command failed: git {self.cmd}\n"
            f"  {self.stderr.strip()}"
        )
