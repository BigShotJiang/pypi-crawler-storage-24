"""
kinlyze — Analyze the kin behind your code.
Map knowledge concentration risk in any Git repository.

CLI usage:
    kinlyze
    kinlyze --repo /path/to/repo
    kinlyze --days 180
    kinlyze --json

Programmatic usage:
    from kinlyze.scoring import analyze_repo
    data = analyze_repo("/path/to/repo", since_days=365)
"""

__version__ = "0.1.0"
__author__  = "Kinlyze"
__url__     = "https://kinlyze.com"
