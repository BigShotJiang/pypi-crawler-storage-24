# kinlyze

**Analyze the kin behind your code.**

Map knowledge concentration risk in any Git repository — find your bus factor before someone quits and takes it with them.

```
pip install kinlyze
cd your-repo
kinlyze
```

Zero dependencies. Reads local Git history only. Nothing leaves your machine.

---

## What it shows

```
  KNOWLEDGE HEAT MAP
  ──────────────────────────────────────────────────────────────────
  MODULE                               BF    PRIMARY OWNER          OWNS
  ──────────────────────────────────────────────────────────────────
  🔴 src/payments                      1     Sarah K                ████████████ 94%
  🟠 src/auth                          2     Marcus R               ████████░░░░ 71%
  🟡 src/api                           2     Mixed                  ██████░░░░░░ 38%
  🟢 src/core                          4     Various                ███░░░░░░░░░ 22%
  🟢 src/utils                         5     Various                ██░░░░░░░░░░ 18%

  DEVELOPER DEPARTURE RISK
  ──────────────────────────────────────────────────────────────────
  DEVELOPER                    KNOWLEDGE %       IF THEY LEAVE...
  ──────────────────────────────────────────────────────────────────
  Sarah K                      ████████████ 31%  ⚠  CRITICAL — immediate risk
  Marcus R                     ████████░░░░ 19%  ▲  HIGH — significant disruption
  James L                      █████░░░░░░░ 12%  ●  MEDIUM — notable knowledge loss

  ⚠  ACTION REQUIRED
  ──────────────────────────────────────────────────────────────────
  → src/payments has bus factor 1. Sarah K holds 94% of knowledge.
    Recommendation: pair programming, code walkthroughs, or documentation sprint.
```

---

## Install

```bash
pip install kinlyze
```

Requires Python 3.8+ and Git installed. No other dependencies.

---

## Usage

```bash
# Analyze current directory
kinlyze

# Analyze a specific repo
kinlyze --repo /path/to/your/repo

# Only look at the last 6 months
kinlyze --days 180

# Show only the 10 riskiest modules
kinlyze --top 10

# Plain output (no color, great for CI)
kinlyze --no-color

# Raw JSON output for scripting
kinlyze --json

# Pipe to a file
kinlyze --no-color > report.txt
```

---

## How it works

Kinlyze reads your local `.git` commit history — no API keys, no GitHub access, no network requests. Everything runs on your machine.

**Ownership score per file per developer:**
```
score = (commit_score × 0.40) + (exclusivity × 0.40) + (criticality × 0.20)
```

- **Commit score** — recency-weighted. A commit last week counts 3× more than one 8 months ago.
- **Exclusivity** — what % of this file's activity does this developer own?
- **Criticality** — files matching payment/auth/core patterns score higher.

**Bus factor** = minimum developers whose removal causes ≥50% knowledge loss in a module.

---

## Privacy

- Reads only local Git metadata (author emails, dates, file paths, commit counts)
- Never reads file contents or diffs
- Nothing is sent to any server
- Fully offline

---

## License

MIT © [Kinlyze](https://kinlyze.com)
