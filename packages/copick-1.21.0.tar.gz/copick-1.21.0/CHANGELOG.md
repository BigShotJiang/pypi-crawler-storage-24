# Changelog

## [1.21.0](https://github.com/copick/copick/compare/copick-v1.20.0...copick-v1.21.0) (2026-03-27)


### ✨ Features

* Add ability to recover broken connections (e.g. ssh) ([#225](https://github.com/copick/copick/issues/225)) ([63de18b](https://github.com/copick/copick/commit/63de18beb5ee22d70c600ca5e9f2253191418ee8))


### 🐞 Bug Fixes

* bump black from 26.1.0 to 26.3.0 ([#214](https://github.com/copick/copick/issues/214)) ([7304993](https://github.com/copick/copick/commit/7304993b466f2c5e53d2c11a1b16f669baebdae4))
* bump black from 26.3.0 to 26.3.1 ([#218](https://github.com/copick/copick/issues/218)) ([4365f6d](https://github.com/copick/copick/commit/4365f6d900f4a4b072f2fac2186306a1a9a94d76))
* bump chanzuckerberg/github-actions from 6.13.0 to 6.13.2 ([#205](https://github.com/copick/copick/issues/205)) ([9b10a6d](https://github.com/copick/copick/commit/9b10a6dc702377ebdfe2045a20f6211b42618deb))
* bump chanzuckerberg/github-actions from 6.13.2 to 6.14.0 ([#211](https://github.com/copick/copick/issues/211)) ([acc9e36](https://github.com/copick/copick/commit/acc9e365063748d8673a6f221337896374221b5b))
* bump chanzuckerberg/github-actions from 6.14.0 to 6.15.0 ([#223](https://github.com/copick/copick/issues/223)) ([f31b22c](https://github.com/copick/copick/commit/f31b22c19741453130bfcc1ff1de6d1d31f7440d))
* bump cryoet-data-portal from 4.6.1 to 4.7.0 ([#222](https://github.com/copick/copick/issues/222)) ([97611a2](https://github.com/copick/copick/commit/97611a25aff7810fbb5a4e63dca1571fd3987fe4))
* bump mkdocs-material from 9.7.1 to 9.7.3 ([#207](https://github.com/copick/copick/issues/207)) ([7bbbfd0](https://github.com/copick/copick/commit/7bbbfd065551bfc0e636aed94d9c3ce0fcee01f0))
* bump mkdocs-material from 9.7.3 to 9.7.4 ([#216](https://github.com/copick/copick/issues/216)) ([03dd3e6](https://github.com/copick/copick/commit/03dd3e68fc7e3de8f8eeb1a931c4a5640801db93))
* bump mkdocs-material from 9.7.4 to 9.7.5 ([#221](https://github.com/copick/copick/issues/221)) ([980caca](https://github.com/copick/copick/commit/980caca8de48fbcca4e7ae15333a4136c993afa5))
* bump requests from 2.32.5 to 2.33.0 ([#224](https://github.com/copick/copick/issues/224)) ([c820414](https://github.com/copick/copick/commit/c820414b15e7548f528d3607674220859d8438ad))
* bump rich from 14.3.2 to 14.3.3 ([#203](https://github.com/copick/copick/issues/203)) ([66d65c0](https://github.com/copick/copick/commit/66d65c0e3f1fbde21cd01672007c973ff201d3c1))
* bump ruff from 0.15.0 to 0.15.4 ([#209](https://github.com/copick/copick/issues/209)) ([97cd16c](https://github.com/copick/copick/commit/97cd16cadd419bf7298611e344017b60711b9868))
* bump ruff from 0.15.4 to 0.15.5 ([#213](https://github.com/copick/copick/issues/213)) ([3bb2da2](https://github.com/copick/copick/commit/3bb2da2a692d912dc433d9da12ce0ed20e585310))
* bump textual from 7.5.0 to 8.0.1 ([#208](https://github.com/copick/copick/issues/208)) ([f37bc34](https://github.com/copick/copick/commit/f37bc34f59a7021eb1c1a5595199e8641316e5cd))
* bump textual from 8.0.1 to 8.0.2 ([#215](https://github.com/copick/copick/issues/215)) ([263864f](https://github.com/copick/copick/commit/263864f61392fa5ae21ed930d810c1c223f3f391))
* bump textual from 8.0.2 to 8.1.1 ([#219](https://github.com/copick/copick/issues/219)) ([9b22fac](https://github.com/copick/copick/commit/9b22facb54e575c4f37f847c1df511bcd75caa3c))
* bump tornado from 6.5.4 to 6.5.5 ([#217](https://github.com/copick/copick/issues/217)) ([7c5f70a](https://github.com/copick/copick/commit/7c5f70a8ef5caf5519a8372994405f0a43b83902))
* bump trimesh from 4.11.2 to 4.11.3 ([#212](https://github.com/copick/copick/issues/212)) ([70af15d](https://github.com/copick/copick/commit/70af15d577bd3944a73f1c4dc0c85b2531a5b259))

## [1.20.0](https://github.com/copick/copick/compare/copick-v1.19.0...copick-v1.20.0) (2026-02-13)


### ✨ Features

* Add import/export commands and API ([#170](https://github.com/copick/copick/issues/170)) ([eaa2ec6](https://github.com/copick/copick/commit/eaa2ec6878a7b7f8d8513b6b432ee3403a9eccbf))


### 🐞 Bug Fixes

* bump cryptography from 45.0.4 to 46.0.5 ([#195](https://github.com/copick/copick/issues/195)) ([5311cc3](https://github.com/copick/copick/commit/5311cc344b0cc10149bfef6e4c6faeb0f889d54a))
* bump pillow from 11.3.0 to 12.1.1 ([#196](https://github.com/copick/copick/issues/196)) ([0ca3441](https://github.com/copick/copick/commit/0ca34410999c3fe46569a1366ba7633afe37f881))
* Fix tests badge in readme.  ([#198](https://github.com/copick/copick/issues/198)) ([4f12036](https://github.com/copick/copick/commit/4f12036244720b3c9ef63134d3883c52001e585c))

## [1.19.0](https://github.com/copick/copick/compare/copick-v1.18.0...copick-v1.19.0) (2026-02-11)


### ✨ Features

* Add chimerax-copick tutorial ([#192](https://github.com/copick/copick/issues/192)) ([8967b2e](https://github.com/copick/copick/commit/8967b2edd0d4e269ba3f7d834ae4198c69460346))
* Add copick MCP docs. ([#182](https://github.com/copick/copick/issues/182)) ([f172f41](https://github.com/copick/copick/commit/f172f41cbd60e8e115c7527ad85e3815c74a1ccd))
* Global cache for cryoET data portal annotations/tomograms ([#194](https://github.com/copick/copick/issues/194)) ([135add9](https://github.com/copick/copick/commit/135add9a61bc7c9e4bfab474350d93e1b163e89b))
* Remove Python 3.9 support. ([#185](https://github.com/copick/copick/issues/185)) ([1ca3806](https://github.com/copick/copick/commit/1ca3806f9403aa7f08bbc81757e2ebd2255f50fe))


### 🐞 Bug Fixes

* Add mcp tutorial to docs pages.  ([#184](https://github.com/copick/copick/issues/184)) ([08637d3](https://github.com/copick/copick/commit/08637d31e8f9b6596518debcff9fb21dc122f504))
* bump black from 25.1.0 to 26.1.0 ([#191](https://github.com/copick/copick/issues/191)) ([2fa248e](https://github.com/copick/copick/commit/2fa248edd52665fe9be493ff0c1209c1698eee51))
* bump click from 8.2.1 to 8.3.1 ([#188](https://github.com/copick/copick/issues/188)) ([2de8268](https://github.com/copick/copick/commit/2de8268743d92f6588e82ed31a242182730f63b7))
* bump mkdocs-material from 9.6.14 to 9.7.1 ([#187](https://github.com/copick/copick/issues/187)) ([cf41fe6](https://github.com/copick/copick/commit/cf41fe684e97831d54b15586f6294c769c69f242))
* bump pandas from 2.3.2 to 2.3.3 ([#189](https://github.com/copick/copick/issues/189)) ([36d5066](https://github.com/copick/copick/commit/36d5066aa739236832bb2b798b458c3e1922e556))
* bump s3fs from 2025.10.0 to 2026.2.0 ([#190](https://github.com/copick/copick/issues/190)) ([018e7e6](https://github.com/copick/copick/commit/018e7e61647c3c6a08ff3a699865753948552edc))

## [1.18.0](https://github.com/copick/copick/compare/copick-v1.17.2...copick-v1.18.0) (2026-02-06)


### ✨ Features

* Add download entrypoint. ([#176](https://github.com/copick/copick/issues/176)) ([531dc68](https://github.com/copick/copick/commit/531dc68cc8e4360d997f079b8c0508d2ffec6835))


### 🐞 Bug Fixes

* bump aiohttp from 3.12.13 to 3.13.3 ([#166](https://github.com/copick/copick/issues/166)) ([8913194](https://github.com/copick/copick/commit/8913194773b942f9255f5c61f188f182864acc79))
* bump cryoet-data-portal from 4.4.1 to 4.6.1 ([#179](https://github.com/copick/copick/issues/179)) ([2e7561f](https://github.com/copick/copick/commit/2e7561ff1da35b242f71fcb058f97facd84ff262))
* bump pillow from 11.2.1 to 11.3.0 ([#173](https://github.com/copick/copick/issues/173)) ([c513713](https://github.com/copick/copick/commit/c513713f9f80ab4cbaa2001eade356c1a49a4705))
* bump pooch from 1.8.2 to 1.9.0 ([#177](https://github.com/copick/copick/issues/177)) ([2f7854f](https://github.com/copick/copick/commit/2f7854f2bfa4c7ed81ca157a4aa1876bce5eff71))
* bump pre-commit from 4.2.0 to 4.3.0 ([#167](https://github.com/copick/copick/issues/167)) ([17ac929](https://github.com/copick/copick/commit/17ac92958cbd3b38cda77b7363fdb93e6ca818e4))
* bump psutil from 7.0.0 to 7.2.1 ([#169](https://github.com/copick/copick/issues/169)) ([c39886e](https://github.com/copick/copick/commit/c39886e20d5ee84faa9eeb9e8d60b35135d6a8cd))
* bump psutil from 7.2.1 to 7.2.2 ([#178](https://github.com/copick/copick/issues/178)) ([01e008e](https://github.com/copick/copick/commit/01e008e5060d33cc6e309de0f76631aff525d0eb))
* bump pymdown-extensions from 10.15 to 10.16.1 ([#172](https://github.com/copick/copick/issues/172)) ([63420f2](https://github.com/copick/copick/commit/63420f24faec306a1d9f6f7762790c631b0aa100))
* bump rich from 14.0.0 to 14.3.1 ([#168](https://github.com/copick/copick/issues/168)) ([6fbd40b](https://github.com/copick/copick/commit/6fbd40bd5f1aba0217e2b2679120b42b6e74b57e))
* bump s3fs from 2025.5.1 to 2025.10.0 ([#180](https://github.com/copick/copick/issues/180)) ([2d9c3ad](https://github.com/copick/copick/commit/2d9c3ad091150fb55ae5030fa55ed08685aa6c87))
* bump tqdm from 4.67.1 to 4.67.2 ([#181](https://github.com/copick/copick/issues/181)) ([87fd2da](https://github.com/copick/copick/commit/87fd2da9eae2f4b871fea7a8cc7bc224578e0631))
* bump virtualenv from 20.31.2 to 20.36.1 ([#165](https://github.com/copick/copick/issues/165)) ([7f24b42](https://github.com/copick/copick/commit/7f24b42ab0a84779bbc80bc2cb07ad9de542a3d2))
* Make copick-mcp appear in terminal logs. ([#175](https://github.com/copick/copick/issues/175)) ([a257dea](https://github.com/copick/copick/commit/a257dea8d66d8097da269a3af8478ade2a238aee))

## [1.17.2](https://github.com/copick/copick/compare/copick-v1.17.1...copick-v1.17.2) (2026-01-26)


### 🐞 Bug Fixes

* bump chanzuckerberg/github-actions from 6.11.1 to 6.13.0 ([#164](https://github.com/copick/copick/issues/164)) ([cefda08](https://github.com/copick/copick/commit/cefda08b2c9eb9ef05f02abc59b3df4aa20d2b01))


### 🧹 Miscellaneous Chores

* add zenodo DOI badge. ([#159](https://github.com/copick/copick/issues/159)) ([1e060f6](https://github.com/copick/copick/commit/1e060f68ac56bdb8d8be4c0e8c44ffc25da0b966))

## [1.17.1](https://github.com/copick/copick/compare/copick-v1.17.0...copick-v1.17.1) (2025-12-03)


### 🐞 Bug Fixes

* bump actions/checkout from 5 to 6 ([#156](https://github.com/copick/copick/issues/156)) ([23a69a6](https://github.com/copick/copick/commit/23a69a648471bb958557d0829b9bf9b05b453438))
* bump chanzuckerberg/github-actions from 6.10.0 to 6.11.1 ([#155](https://github.com/copick/copick/issues/155)) ([03d0f47](https://github.com/copick/copick/commit/03d0f47e7de28da94be1e4738cf0770c20170a4d))


### 🧹 Miscellaneous Chores

* bump version to create zenodo DOI ([#157](https://github.com/copick/copick/issues/157)) ([6896da3](https://github.com/copick/copick/commit/6896da31e869b06514e4cfee9e01dbf11fd54d1a))

## [1.17.0](https://github.com/copick/copick/compare/copick-v1.16.0...copick-v1.17.0) (2025-10-17)


### ✨ Features

* Switch to rich for logging and progress bars. ([#150](https://github.com/copick/copick/issues/150)) ([a0b9e4d](https://github.com/copick/copick/commit/a0b9e4dea0a48d72fb42f5cd8f7202a776da35b5))


### 🐞 Bug Fixes

* Add rich dependency. ([#152](https://github.com/copick/copick/issues/152)) ([90ddf5e](https://github.com/copick/copick/commit/90ddf5e59f41947203ca1a82b6fbb5dc869c471d))
* Repair cp, mv, rm behavior ([#149](https://github.com/copick/copick/issues/149)) ([d9d652f](https://github.com/copick/copick/commit/d9d652f534311287fcc1257063db3b02fc9968f7))

## [1.16.0](https://github.com/copick/copick/compare/copick-v1.15.0...copick-v1.16.0) (2025-10-16)


### ✨ Features

* Add copick setup group ([#146](https://github.com/copick/copick/issues/146)) ([50138c2](https://github.com/copick/copick/commit/50138c232fa95f0590b51b59fa7f00795f4ad2e1))
* Add data management commands ([#147](https://github.com/copick/copick/issues/147)) ([b23fd40](https://github.com/copick/copick/commit/b23fd403d95e8fc29788f76b919e1d05086b1686))
* Organize top-level copick CLI ([#148](https://github.com/copick/copick/issues/148)) ([8d07358](https://github.com/copick/copick/commit/8d0735817abdc9ac999173610417a97a6b6f539a))


### 🐞 Bug Fixes

* bump astral-sh/setup-uv from 6 to 7 ([#143](https://github.com/copick/copick/issues/143)) ([ab98cdc](https://github.com/copick/copick/commit/ab98cdc8f1a1b2b08d22102bb62c62ad4e7c2040))
* Raise error if unknown config type is passed. ([#144](https://github.com/copick/copick/issues/144)) ([e1aa599](https://github.com/copick/copick/commit/e1aa59983cd84e068a6103cc24e97d0f4e7c982c))

## [1.15.0](https://github.com/copick/copick/compare/copick-v1.14.0...copick-v1.15.0) (2025-10-10)


### ✨ Features

* Add command that prepares copick data for deposition on the cryoET data portal. ([#141](https://github.com/copick/copick/issues/141)) ([0f7ffd0](https://github.com/copick/copick/commit/0f7ffd0436fae9b21c79859b03cf8ce626c33261))
* Define a URI scheme for identifying copick entities.  ([#140](https://github.com/copick/copick/issues/140)) ([265e247](https://github.com/copick/copick/commit/265e247db9a43efa1d579d9659d54a62cf581336))


### 🐞 Bug Fixes

* bump actions/setup-python from 5 to 6 ([#134](https://github.com/copick/copick/issues/134)) ([3355810](https://github.com/copick/copick/commit/3355810a285bdcf8e5f0eec95215f9751f436ba2))
* bump chanzuckerberg/github-actions from 6.6.0 to 6.8.1 ([#135](https://github.com/copick/copick/issues/135)) ([dcd6e02](https://github.com/copick/copick/commit/dcd6e02772bc3ad64ebd3762d697455e366ce20e))
* bump chanzuckerberg/github-actions from 6.8.1 to 6.9.0 ([#139](https://github.com/copick/copick/issues/139)) ([db4cdb6](https://github.com/copick/copick/commit/db4cdb6d4bcf0dca2617e85d0f2f073e1a7d0b63))
* bump chanzuckerberg/github-actions from 6.9.0 to 6.10.0 ([#142](https://github.com/copick/copick/issues/142)) ([21406a6](https://github.com/copick/copick/commit/21406a6c66385976d408c1b93d8d2e181ca66dcc))
* Consistently show help when no args provided. ([#137](https://github.com/copick/copick/issues/137)) ([b03299e](https://github.com/copick/copick/commit/b03299e9520548475b84f5c11050f4c18619044b))
* Improve warnings when using copick to RELION-friendly DataFrame method ([#138](https://github.com/copick/copick/issues/138)) ([9d68f50](https://github.com/copick/copick/commit/9d68f5015f9398b9516bc6085619a23afdf21765))

## [1.14.0](https://github.com/copick/copick/compare/copick-v1.13.0...copick-v1.14.0) (2025-09-11)


### ✨ Features

* More output for copick info, include versioned plugins in copick CLI logs.  ([#130](https://github.com/copick/copick/issues/130)) ([6b74e70](https://github.com/copick/copick/commit/6b74e70b8f2e4be013c48b9e0e9552b448d00a2c))


### 🐞 Bug Fixes

* Suppress sshfs logs ([#133](https://github.com/copick/copick/issues/133)) ([86f6da9](https://github.com/copick/copick/commit/86f6da96f3b7fc62b9233dc18b86ab4758305238))


### 🧹 Miscellaneous Chores

* Improve gh-actions execution. ([#131](https://github.com/copick/copick/issues/131)) ([b922ab1](https://github.com/copick/copick/commit/b922ab1038e82f6c5b89f33eab26b01dacb2c323))

## [1.13.0](https://github.com/copick/copick/compare/copick-v1.12.0...copick-v1.13.0) (2025-09-05)


### ✨ Features

* Add 'logical' CLI entrypoint for plugins.  ([#127](https://github.com/copick/copick/issues/127)) ([6feb68f](https://github.com/copick/copick/commit/6feb68f03b7316ee3fd321f85e7dd1299e1661ca))

## [1.12.0](https://github.com/copick/copick/compare/copick-v1.11.0...copick-v1.12.0) (2025-08-29)


### ✨ Features

* add RELION particles.star starfile dataframe and CopickPicks conversion ([#123](https://github.com/copick/copick/issues/123)) ([cf37305](https://github.com/copick/copick/commit/cf3730565c393dddfa1ee702447ecf8000d4b021))
* Functional API and CLI commands for gathering statistics. ([#124](https://github.com/copick/copick/issues/124)) ([fadd9ee](https://github.com/copick/copick/commit/fadd9eef3e2e93c8a8fb92150a25fee6bc8df0e0))


### 🐞 Bug Fixes

* bump actions/checkout from 4 to 5 ([#121](https://github.com/copick/copick/issues/121)) ([7d89aed](https://github.com/copick/copick/commit/7d89aedb2b40c82103b7025559c37d3aac64abed))
* bump chanzuckerberg/github-actions from 6.4.0 to 6.5.0 ([#119](https://github.com/copick/copick/issues/119)) ([a9d1889](https://github.com/copick/copick/commit/a9d18890d969835548c9a8269d9f215fbe702348))
* bump chanzuckerberg/github-actions from 6.5.0 to 6.6.0 ([#122](https://github.com/copick/copick/issues/122)) ([bdb677d](https://github.com/copick/copick/commit/bdb677d505caafd75f6e71acddd2436bdf2c3cdb))
* Fix docs examples for `get_*` API ([#126](https://github.com/copick/copick/issues/126)) ([900ebf7](https://github.com/copick/copick/commit/900ebf7077426d42c773ac325ab08a94eeb38445))


### 📝 Documentation

* Update docs to reflect fix in pip==25.2 ([#120](https://github.com/copick/copick/issues/120)) ([9e12e0b](https://github.com/copick/copick/commit/9e12e0b8900d32815571b370f2713b82065dc764))

## [1.11.0](https://github.com/copick/copick/compare/copick-v1.10.0...copick-v1.11.0) (2025-07-22)


### ✨ Features

* Allow custom metadata on pickable objects ([#117](https://github.com/copick/copick/issues/117)) ([0f4cd98](https://github.com/copick/copick/commit/0f4cd9871d3c68db6858601451d595059cd6dc14))


### 🐞 Bug Fixes

* Minor docs fixes. ([#115](https://github.com/copick/copick/issues/115)) ([91f92b8](https://github.com/copick/copick/commit/91f92b83cf36112ef31b335b37b2eea783659abe))

## [1.10.0](https://github.com/copick/copick/compare/copick-v1.9.0...copick-v1.10.0) (2025-07-21)


### ✨ Features

* Add sync command and CLI ([#113](https://github.com/copick/copick/issues/113)) ([ea28cd7](https://github.com/copick/copick/commit/ea28cd7481d526da8686498c81424009b6cfbc82))

## [1.9.0](https://github.com/copick/copick/compare/copick-v1.8.2...copick-v1.9.0) (2025-07-17)


### ✨ Features

* Add an option allowing extracting run names from filenames ([#111](https://github.com/copick/copick/issues/111)) ([3293545](https://github.com/copick/copick/commit/32935452b46f28cc4f046866d84c5810f359b87b))

## [1.8.2](https://github.com/copick/copick/compare/copick-v1.8.1...copick-v1.8.2) (2025-07-16)


### 🐞 Bug Fixes

* Fix overwrite option on CLI ([#109](https://github.com/copick/copick/issues/109)) ([8232aaf](https://github.com/copick/copick/commit/8232aaf983ad32a0c0c6198cd121e7cd313febb3))

## [1.8.1](https://github.com/copick/copick/compare/copick-v1.8.0...copick-v1.8.1) (2025-07-16)


### 🐞 Bug Fixes

* Make sshfs a core dependency and update docs. ([#107](https://github.com/copick/copick/issues/107)) ([3e5645d](https://github.com/copick/copick/commit/3e5645d35b1db732d1f39e2d1177de674c772be3))

## [1.8.0](https://github.com/copick/copick/compare/copick-v1.7.0...copick-v1.8.0) (2025-07-16)


### ✨ Features

* More CLI groups exposed for entry points from other packages. ([#103](https://github.com/copick/copick/issues/103)) ([f99bb3f](https://github.com/copick/copick/commit/f99bb3f3fa97b8f3b30d4fa54f58bc29f9cd5d64))

## [1.7.0](https://github.com/copick/copick/compare/copick-v1.6.1...copick-v1.7.0) (2025-07-16)


### ✨ Features

* Add ability to add objects. ([#101](https://github.com/copick/copick/issues/101)) ([ee19667](https://github.com/copick/copick/commit/ee196679fc9a198e166a5e8a9baf64882e216a5f))


### 🐞 Bug Fixes

* remove requirement for providing objects when generating a local config project ([#99](https://github.com/copick/copick/issues/99)) ([7a0045d](https://github.com/copick/copick/commit/7a0045d61a42d59e8f6502b4c76f360c7f313bf6))
* Store OME metadata correctly. ([#105](https://github.com/copick/copick/issues/105)) ([144457b](https://github.com/copick/copick/commit/144457bc2041e17b24a48b5bae42ac7e6ae3a190))


### ⚡️ Performance Improvements

* Add parallel processing support for tomogram and segmentation import ([#102](https://github.com/copick/copick/issues/102)) ([944f77c](https://github.com/copick/copick/commit/944f77c359b47c273e3dc59a5376f353b9997ebe))
* Optimize imports to make importing copick quicker and keep CLI snappy ([#104](https://github.com/copick/copick/issues/104)) ([e115d78](https://github.com/copick/copick/commit/e115d781992bd65a3dc06640d17317c2b0d1eeb9))

## [1.6.1](https://github.com/copick/copick/compare/copick-v1.6.0...copick-v1.6.1) (2025-07-08)


### 🐞 Bug Fixes

* bump actions/checkout from 3 to 4 ([#96](https://github.com/copick/copick/issues/96)) ([8f43b4a](https://github.com/copick/copick/commit/8f43b4a29841637d4be4f8be9a435b8d9418cd67))
* bump actions/setup-python from 4 to 5 ([#95](https://github.com/copick/copick/issues/95)) ([08cae6c](https://github.com/copick/copick/commit/08cae6c06cd7f73dc012ec3e32670507916526da))
* bump asdf-vm/actions from 3 to 4 ([#97](https://github.com/copick/copick/issues/97)) ([422969e](https://github.com/copick/copick/commit/422969eb4427145cc11a140450cb58699f0df29c))

## [1.6.0](https://github.com/copick/copick/compare/copick-v1.5.0...copick-v1.6.0) (2025-07-08)


### ✨ Features

* Improved CLI setup. ([#94](https://github.com/copick/copick/issues/94)) ([cce061a](https://github.com/copick/copick/commit/cce061af908a03fe3e76fd9ee817afc63ade9289))


### 🐞 Bug Fixes

* Bump chanzuckerberg/github-actions from 1.5.0 to 6.4.0 ([#91](https://github.com/copick/copick/issues/91)) ([2e225d9](https://github.com/copick/copick/commit/2e225d9bee80d045d38751e69e4a323e020af899))


### 📝 Documentation

* improve setup docs  ([#93](https://github.com/copick/copick/issues/93)) ([4644a2f](https://github.com/copick/copick/commit/4644a2f3cdb9f29b2adbef3ee2afee66f4f99c6c))

## [1.5.0](https://github.com/copick/copick/compare/copick-v1.4.0...copick-v1.5.0) (2025-06-21)


### ✨ Features

* Generate Config Files for the Dataportal Through CLI ([#77](https://github.com/copick/copick/issues/77)) ([7b1daaf](https://github.com/copick/copick/commit/7b1daafc10c8a39e839e577786cf5619902d9246))

## [1.4.0](https://github.com/copick/copick/compare/copick-v1.3.0...copick-v1.4.0) (2025-06-21)


### ✨ Features

* Add utility to generate empty-picks for a new copick project ([#79](https://github.com/copick/copick/issues/79)) ([d5d5030](https://github.com/copick/copick/commit/d5d50307b82bf230b9dfbe81a09b7c9416b63a79))

## [1.3.0](https://github.com/copick/copick/compare/copick-v1.2.0...copick-v1.3.0) (2025-06-21)


### ✨ Features

* Allow querying copick tomograms with portal metadata ([b1920f6](https://github.com/copick/copick/commit/b1920f60e93e542be75d07ec43fbed2c09e71983))
* Switch to uv for test workflows and activate codecov ([#80](https://github.com/copick/copick/issues/80)) ([1eb0212](https://github.com/copick/copick/commit/1eb02128b153b154cfbab18c11537333544dd208))


### 🐞 Bug Fixes

* changes for smbfs caused duplications with localfs ([fa94e38](https://github.com/copick/copick/commit/fa94e38aefedce1d96bf5e5c294639cadc03ea7a))
* Fix point initialization and loading ([#81](https://github.com/copick/copick/issues/81)) ([7205c24](https://github.com/copick/copick/commit/7205c24516b7699f84a5a96e3e55050a6adf50d6))
* Make cryoET data portal implementation compatible with python 3.9 ([f87688b](https://github.com/copick/copick/commit/f87688b07c92504040d92b997fdaa65dd054676a))
* Reading annotations with shape type "Point" from portal and portal project autogen. ([0a13aec](https://github.com/copick/copick/commit/0a13aeccb2ea5fef827efb5fbb2395eb43e4dfff))


### 🧹 Miscellaneous Chores

* Add conventional commit action. ([#86](https://github.com/copick/copick/issues/86)) ([9f8708f](https://github.com/copick/copick/commit/9f8708f4a7f0ad8b83828b3162bbb24bc40f6293))
* Bump astral-sh/setup-uv from 5 to 6 ([#85](https://github.com/copick/copick/issues/85)) ([503415d](https://github.com/copick/copick/commit/503415d344571ba6e3b022736f6edccb7c58c193))
* Bump peaceiris/actions-gh-pages from 3 to 4 ([#83](https://github.com/copick/copick/issues/83)) ([d5b286a](https://github.com/copick/copick/commit/d5b286ac7061d11ca212bc57efdbbb6338e35d78))
* Update README.md ([#88](https://github.com/copick/copick/issues/88)) ([38f1e79](https://github.com/copick/copick/commit/38f1e7971cafd864c85f198d3a9ad8c7d6492e29))
