[](){#CopickObject}
::: copick.models.CopickObject
