[](){#CopickRun}
::: copick.models.CopickRun
