from signalslabs_mcp.server import main

main()
