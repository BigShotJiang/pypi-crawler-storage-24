"""SignalsLabs MCP — Geopolitical intelligence for Claude Code."""
