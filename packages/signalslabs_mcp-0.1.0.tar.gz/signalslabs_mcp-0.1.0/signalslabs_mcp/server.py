"""
SignalsLabs MCP Server — Geopolitical intelligence for Claude Code.
Connects to the SignalsLabs API at signalslabs.net.
"""

import os
import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    "SignalsLabs",
    description="AI-powered geopolitical intelligence. Get real-time signals, intelligence briefs, and event analysis for macro trading and risk assessment.",
)

API_BASE = os.getenv("SIGNALSLABS_API_URL", "https://signalslabs.net")
API_KEY = os.getenv("SIGNALSLABS_API_KEY", "")


def _headers() -> dict:
    h = {"Content-Type": "application/json"}
    if API_KEY:
        h["Authorization"] = f"Bearer {API_KEY}"
    return h


@mcp.tool()
async def get_signals(
    region: str = "",
    min_severity: int = 0,
    limit: int = 20,
) -> str:
    """
    Get current geopolitical signals ranked by market impact.

    Args:
        region: Filter by region (e.g., "Europe", "Middle East", "Asia"). Empty = all.
        min_severity: Minimum severity score (0-10). Default 0 = all signals.
        limit: Max number of signals to return. Default 20.

    Returns ranked signals with: event summary, severity, affected assets,
    confidence score, and source attribution.
    """
    params = {"limit": limit}
    if region:
        params["region"] = region
    if min_severity > 0:
        params["min_severity"] = min_severity

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(
            f"{API_BASE}/api/signals",
            params=params,
            headers=_headers(),
        )
        resp.raise_for_status()
        return resp.text


@mcp.tool()
async def get_brief(
    topic: str = "",
    date: str = "",
) -> str:
    """
    Get an intelligence brief — a PM-ready analysis of current geopolitical events.

    Args:
        topic: Focus topic (e.g., "Taiwan strait", "oil supply", "NATO"). Empty = daily overview.
        date: Date for the brief (YYYY-MM-DD). Empty = today.

    Returns a structured brief with: key events, market implications,
    asset impact map, risk scenarios, and recommended actions.
    """
    params = {}
    if topic:
        params["topic"] = topic
    if date:
        params["date"] = date

    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.get(
            f"{API_BASE}/api/brief",
            params=params,
            headers=_headers(),
        )
        resp.raise_for_status()
        return resp.text


@mcp.tool()
async def analyze_event(
    event: str,
) -> str:
    """
    Deep analysis of a specific geopolitical event or scenario.

    Args:
        event: Description of the event to analyze (e.g., "Iran nuclear deal collapse",
               "China Taiwan military exercises", "OPEC production cut").

    Returns multi-order impact analysis:
    - Direct market impact (1st order)
    - Second-order effects (supply chains, alliances)
    - Third-order effects (long-term structural shifts)
    - Affected assets with direction and confidence
    - Historical analogues and backtested outcomes
    """
    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post(
            f"{API_BASE}/api/classify",
            json={"text": event},
            headers=_headers(),
        )
        resp.raise_for_status()
        return resp.text


def main():
    mcp.run()


if __name__ == "__main__":
    main()
