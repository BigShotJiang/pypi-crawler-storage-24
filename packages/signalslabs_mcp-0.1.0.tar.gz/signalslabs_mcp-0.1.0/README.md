# SignalsLabs MCP

AI-powered geopolitical intelligence for Claude Code.

## Tools

| Tool | Description |
|------|-------------|
| `get_signals` | Get current geopolitical signals ranked by market impact |
| `get_brief` | Get PM-ready intelligence briefs on current events |
| `analyze_event` | Deep multi-order impact analysis of any geopolitical event |

## Install

```bash
/plugin install signalslabs@claude-plugins-official
```

Or manually:
```bash
uvx signalslabs-mcp
```

## Configuration

Set your API key:
```
SIGNALSLABS_API_KEY=your-key-here
```

Get a free API key at [signalslabs.net](https://signalslabs.net).

## Examples

Ask Claude:
- "What are the top geopolitical signals right now?"
- "Give me a brief on the Middle East situation"
- "Analyze the market impact of China-Taiwan escalation"
- "What geopolitical risks should I watch for European energy markets?"
