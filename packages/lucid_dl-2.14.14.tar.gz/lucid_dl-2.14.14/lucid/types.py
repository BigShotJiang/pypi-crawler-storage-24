from typing import (
    Any,
    Callable,
    Protocol,
    Self,
    Sequence,
    Literal,
    TypeAlias,
    TYPE_CHECKING,
    runtime_checkable,
)
from collections import OrderedDict
import re

import numpy as np
import mlx.core as mx

_DeviceType = Literal["cpu", "gpu"]

_Scalar = int | float | complex
_NumPyArray: TypeAlias = np.ndarray
_MLXArray: TypeAlias = mx.array

_TensorData = _NumPyArray | _MLXArray

_Gradient = _NumPyArray | _MLXArray | None

_ArrayOrScalar = _Scalar | list[_Scalar] | _NumPyArray | _MLXArray

_BuiltinNumeric = type[bool | int | float | complex]

_ShapeLike = list[int] | tuple[int]

_IndexLike = int | slice | Sequence[int]

_ArrayLike = list | _NumPyArray | _MLXArray
_ArrayLikeInt = int | Sequence[int | tuple[int, int]]

_OptimClosure = Callable[[], Any]

_EinopsPattern = str


@runtime_checkable
class _TensorLike(Protocol):
    dtype: Any
    requires_grad: bool
    is_free: bool
    device: _DeviceType
    shape: Any
    data: Any
    grad: Any
    keep_grad: bool
    is_leaf: bool
    size: Any

    _op: object | None
    _prev: list[_TensorLike]
    _backward_op: Any
    _backward_hooks: Any
    _version: int

    def to(self, device: _DeviceType) -> None: ...

    def free(self) -> None: ...

    def new_tensor(self) -> _TensorLike: ...

    def is_cpu(self) -> bool: ...

    def is_gpu(self) -> bool: ...

    def clear_node(self, clear_op: bool = True) -> None: ...

    def backward(
        self, retain_grad: bool = False, retain_graph: bool = False
    ) -> None: ...


@runtime_checkable
class _ModuleHookable(Protocol):
    def register_forward_pre_hook(
        self, hook: Callable, *, with_kwargs: bool = False
    ) -> Callable: ...

    def register_forward_hook(
        self, hook: Callable, *, with_kwargs: bool = False
    ) -> Callable: ...

    def register_backward_hook(self, hook: Callable) -> Callable: ...

    def register_full_backward_pre_hook(self, hook: Callable) -> Callable: ...

    def register_full_backward_hook(self, hook: Callable) -> Callable: ...

    def register_state_dict_pre_hook(self, hook: Callable) -> Callable: ...

    def register_state_dict_hook(self, hook: Callable) -> Callable: ...

    def register_load_state_dict_pre_hook(self, hook: Callable) -> Callable: ...

    def register_load_state_dict_post_hook(self, hook: Callable) -> Callable: ...


_ForwardPreHook: TypeAlias = Callable[
    [_ModuleHookable, tuple[Any, ...]], tuple[Any, ...] | None
]
_ForwardPreHookKwargs: TypeAlias = Callable[
    [_ModuleHookable, tuple[Any, ...], dict[str, Any]],
    tuple[tuple[Any, ...], dict[str, Any]] | None,
]
_ForwardHook: TypeAlias = Callable[[_ModuleHookable, tuple[Any, ...], Any], Any | None]
_ForwardHookKwargs: TypeAlias = Callable[
    [_ModuleHookable, tuple[Any, ...], dict[str, Any], Any], Any | None
]

_BackwardHook: TypeAlias = Callable[[_TensorLike, _NumPyArray], None]
_FullBackwardPreHook: TypeAlias = Callable[
    [_ModuleHookable, tuple[_NumPyArray | None, ...]],
    tuple[_NumPyArray | None, ...] | None,
]
_FullBackwardHook: TypeAlias = Callable[
    [_ModuleHookable, tuple[_NumPyArray | None, ...], tuple[_NumPyArray | None, ...]],
    tuple[_NumPyArray | None, ...] | None,
]

_StateDictPreHook: TypeAlias = Callable[[_ModuleHookable, str, bool], None]
_StateDictHook: TypeAlias = Callable[[_ModuleHookable, OrderedDict, str, bool], None]

_LoadStateDictPreHook: TypeAlias = Callable[[_ModuleHookable, OrderedDict, bool], None]
_LoadStateDictPostHook: TypeAlias = Callable[
    [_ModuleHookable, set[str], set[str], bool], None
]


class Numeric:
    def __init__(
        self, base_dtype: type[int | float | complex], bits: int | None
    ) -> None:
        self.base_dtype = base_dtype
        self.base_str = base_dtype.__name__
        self.bits = bits

        self._np_dtype: type | None = None
        self._mlx_dtype: type | None = None

        if bits is not None:
            self._np_dtype = getattr(np, self.base_str + str(bits))
            bits_mlx = bits
            if (
                mx.default_device().type is mx.DeviceType.gpu
                and self.base_dtype is float
                and bits == 64
            ):
                bits_mlx = 32
            self._mlx_dtype = getattr(mx, self.base_str + str(bits_mlx))

    @property
    def cpu(self) -> type | None:
        return self._np_dtype

    @property
    def gpu(self) -> type | None:
        return self._mlx_dtype

    @property
    def is_bit_free(self) -> bool:
        return self.bits is None

    def parse(self, device: _DeviceType) -> type | None:
        if device == "cpu":
            return self.cpu
        else:
            return self.gpu

    def auto_parse(self, data_dtype: type, device: _DeviceType) -> type | None:
        bits = self._dtype_bits(data_dtype)
        new_dtype = self.base_dtype.__name__ + str(bits)

        return getattr(np if device == "cpu" else mx, new_dtype, None)

    def _dtype_bits(self, dtype: type) -> int:
        if isinstance(dtype, (np.dtype, type)) and hasattr(dtype, "itemsize"):
            return np.dtype(dtype).itemsize * 8

        if isinstance(dtype, (mx.Dtype, type)):
            return dtype.size * 8

        if isinstance(dtype, str):
            try:
                return np.dtype(dtype).itemsize * 8
            except TypeError:
                return dtype.size * 8

        raise TypeError(f"Unsupported dtype: {dtype}")

    def __eq__(self, other: Self) -> bool:
        if self.base_dtype is not other.base_dtype:
            return False
        if self.is_bit_free:
            return True if other.is_bit_free else False
        return True if other.is_bit_free or self.bits == other.bits else False

    def __hash__(self) -> int:
        return hash(str(self))

    def __str__(self) -> str:
        return self.base_dtype.__name__ + (str(self.bits) if self.bits else "")

    def __repr__(self) -> str:
        return (
            f"(base_dtype={self.base_dtype.__name__}, bits={self.bits},"
            + f" _np_dtype={self.cpu}, _mlx_dtype={self.gpu})",
        )[0]


Int = Numeric(int, None)
Int8 = Numeric(int, bits=8)
Int16 = Numeric(int, bits=16)
Int32 = Numeric(int, bits=32)
Int64 = Numeric(int, bits=64)

Char = Int8
Short = Int16
Long = Int64

Float = Numeric(float, None)
Float16 = Numeric(float, bits=16)
Float32 = Numeric(float, bits=32)
Float64 = Numeric(float, bits=64)

Half = Float16
Double = Float64

Complex = Numeric(complex, None)
Complex64 = Numeric(complex, bits=64)

numeric_dict = {
    "int": {"8": Int8, "16": Int16, "32": Int32, "64": Int64},
    "float": {"16": Float16, "32": Float32, "64": Float64},
    "complex": {"64": Complex64},
}


def to_numeric_type(data_dtype: type) -> Numeric:
    str_dtype = str(data_dtype).split(".")[-1]

    name = re.findall(r"[a-z]+", str_dtype)[0]
    bits = re.findall(r"\d+", str_dtype)[0]

    return numeric_dict[name][bits]
