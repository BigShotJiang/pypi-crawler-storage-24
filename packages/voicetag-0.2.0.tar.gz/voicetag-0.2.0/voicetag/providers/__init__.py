"""STT provider implementations."""
