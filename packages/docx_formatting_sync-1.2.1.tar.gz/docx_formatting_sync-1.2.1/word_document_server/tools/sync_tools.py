"""
Synchronization tools for Word Document Server (docx-sync-mcp).

These tools enable paragraph-level formatting operations with word-count validation.
The key invariant: formatting operations must never change word count.
"""
import os
from typing import List, Optional, Dict, Any
from docx import Document
from docx.shared import Pt

from word_document_server.utils.file_utils import check_file_writeable, ensure_docx_extension
from word_document_server.core.formatting import (
    validate_word_count_unchanged,
    normalize_paragraph_runs,
    extract_paragraph_formatting,
    apply_paragraph_formatting,
    copy_formatting_between_paragraphs,
    copy_mixed_formatting,
    format_first_word_of_paragraph,
    compare_paragraph_formatting,
    count_words,
)


async def format_paragraph(
    filename: str,
    paragraph_index: int,
    font_name: Optional[str] = None,
    font_size: Optional[int] = None,
    bold: Optional[bool] = None,
    italic: Optional[bool] = None,
    underline: Optional[bool] = None,
    color: Optional[str] = None,
    line_spacing: Optional[float] = None,
) -> str:
    """
    Format an entire paragraph with uniform formatting.

    This tool normalizes all runs in the paragraph and applies consistent
    formatting. The word count is guaranteed to remain unchanged.

    IMPORTANT: This tool destroys any existing mixed formatting (e.g., bold first
    word followed by normal text). To preserve mixed formatting, use
    `format_paragraph_first_word` for labels or `copy_paragraph_formatting` to
    copy from a reference paragraph.

    UNITS:
        - font_size: Points (pt), e.g., 12 for 12pt text
        - line_spacing: Twips (1/20 of a point). Common values:
          240 = single spacing, 360 = 1.5 spacing, 480 = double spacing
        - color: Hex RGB string, e.g., '000000' for black, 'FF0000' for red

    Args:
        filename: Path to the Word document
        paragraph_index: Index of the paragraph (0-based)
        font_name: Font family (e.g., 'Times New Roman', 'Arial')
        font_size: Font size in points (e.g., 12, 14)
        bold: Set text bold (True/False)
        italic: Set text italic (True/False)
        underline: Set text underlined (True/False)
        color: Text color as hex RGB (e.g., '000000' for black, 'FF0000' for red)
        line_spacing: Line spacing in twips (240=single, 360=1.5, 480=double)

    Returns:
        Success message or error description
    """
    filename = ensure_docx_extension(filename)

    try:
        paragraph_index = int(paragraph_index)
        if font_size is not None:
            font_size = int(font_size)
        if line_spacing is not None:
            line_spacing = float(line_spacing)
    except (ValueError, TypeError) as e:
        return f"Invalid parameter: {str(e)}"

    if not os.path.exists(filename):
        return f"Document {filename} does not exist"

    is_writeable, error_message = check_file_writeable(filename)
    if not is_writeable:
        return f"Cannot modify document: {error_message}"

    try:
        doc = Document(filename)

        if paragraph_index < 0 or paragraph_index >= len(doc.paragraphs):
            return f"Invalid paragraph index. Document has {len(doc.paragraphs)} paragraphs (0-{len(doc.paragraphs)-1})."

        paragraph = doc.paragraphs[paragraph_index]
        words_before = count_words(paragraph.text)

        # Normalize runs to ensure uniform formatting
        normalize_paragraph_runs(paragraph)

        # Apply formatting
        apply_paragraph_formatting(
            paragraph,
            font_name=font_name,
            font_size=font_size,
            bold=bold,
            italic=italic,
            underline=underline,
            color=color,
            line_spacing=line_spacing,
        )

        doc.save(filename)

        # Verify word count unchanged
        doc_verify = Document(filename)
        paragraph_verify = doc_verify.paragraphs[paragraph_index]
        words_after = count_words(paragraph_verify.text)

        if words_before != words_after:
            return f"ERROR: Word count changed from {words_before} to {words_after}"

        formatting_desc = []
        if font_name:
            formatting_desc.append(f"font='{font_name}'")
        if font_size:
            formatting_desc.append(f"size={font_size}pt")
        if bold is not None:
            formatting_desc.append(f"bold={bold}")
        if italic is not None:
            formatting_desc.append(f"italic={italic}")
        if underline is not None:
            formatting_desc.append(f"underline={underline}")
        if color:
            formatting_desc.append(f"color={color}")
        if line_spacing:
            formatting_desc.append(f"line_spacing={line_spacing}")

        desc = ", ".join(formatting_desc) if formatting_desc else "no changes"
        return f"Paragraph {paragraph_index} formatted ({desc}). Word count: {words_after}"

    except Exception as e:
        return f"Failed to format paragraph: {str(e)}"


async def copy_paragraph_formatting(
    source_filename: str,
    source_paragraph_index: int,
    target_filename: str,
    target_paragraph_index: int,
    include_style: bool = True,
    include_alignment: bool = True,
    include_spacing: bool = True,
) -> str:
    """
    Copy all formatting from a source paragraph to a target paragraph.

    This copies:
    - Paragraph style (Heading 4, Normal, etc.)
    - Font family and size
    - Bold, italic, underline
    - Text color
    - Line spacing
    - Alignment
    - Space before/after

    The word count of the target paragraph is guaranteed to remain unchanged.

    Args:
        source_filename: Path to the source Word document
        source_paragraph_index: Index of the source paragraph (0-based)
        target_filename: Path to the target Word document
        target_paragraph_index: Index of the target paragraph (0-based)
        include_style: Whether to copy paragraph style (default: True)
        include_alignment: Whether to copy alignment (default: True)
        include_spacing: Whether to copy line spacing and space before/after (default: True)

    Returns:
        Success message or error description
    """
    source_filename = ensure_docx_extension(source_filename)
    target_filename = ensure_docx_extension(target_filename)

    try:
        source_paragraph_index = int(source_paragraph_index)
        target_paragraph_index = int(target_paragraph_index)
    except (ValueError, TypeError):
        return "Invalid parameter: paragraph indices must be integers"

    if not os.path.exists(source_filename):
        return f"Source document {source_filename} does not exist"
    if not os.path.exists(target_filename):
        return f"Target document {target_filename} does not exist"

    is_writeable, error_message = check_file_writeable(target_filename)
    if not is_writeable:
        return f"Cannot modify target document: {error_message}"

    try:
        source_doc = Document(source_filename)
        target_doc = Document(target_filename)

        if source_paragraph_index < 0 or source_paragraph_index >= len(source_doc.paragraphs):
            return f"Invalid source paragraph index. Document has {len(source_doc.paragraphs)} paragraphs."
        if target_paragraph_index < 0 or target_paragraph_index >= len(target_doc.paragraphs):
            return f"Invalid target paragraph index. Document has {len(target_doc.paragraphs)} paragraphs."

        source_para = source_doc.paragraphs[source_paragraph_index]
        target_para = target_doc.paragraphs[target_paragraph_index]

        words_before = count_words(target_para.text)

        # Copy formatting (with mixed formatting support)
        copy_mixed_formatting(
            source_para,
            target_para,
            include_style=include_style,
            include_alignment=include_alignment,
            include_spacing=include_spacing,
        )

        target_doc.save(target_filename)

        # Verify word count unchanged
        doc_verify = Document(target_filename)
        para_verify = doc_verify.paragraphs[target_paragraph_index]
        words_after = count_words(para_verify.text)

        if words_before != words_after:
            return f"ERROR: Word count changed from {words_before} to {words_after}"

        return (
            f"Formatting copied from {source_filename}:{source_paragraph_index} "
            f"to {target_filename}:{target_paragraph_index}. "
            f"Word count: {words_after}"
        )

    except Exception as e:
        return f"Failed to copy formatting: {str(e)}"


async def format_paragraph_first_word(
    filename: str,
    paragraph_index: int,
    font_name: Optional[str] = None,
    font_size: Optional[int] = None,
    bold: Optional[bool] = None,
    italic: Optional[bool] = None,
    underline: Optional[bool] = None,
) -> str:
    """
    Format only the first word of a paragraph (e.g., "Background:", "Abstract:").

    This is useful for formatting labels at the start of paragraphs.
    The word count is guaranteed to remain unchanged.

    Args:
        filename: Path to the Word document
        paragraph_index: Index of the paragraph (0-based)
        font_name: Font family (e.g., 'Times New Roman')
        font_size: Font size in points
        bold: Set text bold (True/False)
        italic: Set text italic (True/False)
        underline: Set text underlined (True/False)

    Returns:
        Success message or error description
    """
    filename = ensure_docx_extension(filename)

    try:
        paragraph_index = int(paragraph_index)
        if font_size is not None:
            font_size = int(font_size)
    except (ValueError, TypeError):
        return "Invalid parameter: paragraph_index and font_size must be integers"

    if not os.path.exists(filename):
        return f"Document {filename} does not exist"

    is_writeable, error_message = check_file_writeable(filename)
    if not is_writeable:
        return f"Cannot modify document: {error_message}"

    try:
        doc = Document(filename)

        if paragraph_index < 0 or paragraph_index >= len(doc.paragraphs):
            return f"Invalid paragraph index. Document has {len(doc.paragraphs)} paragraphs."

        paragraph = doc.paragraphs[paragraph_index]
        words_before = count_words(paragraph.text)

        # Get the first word for the success message
        first_word = paragraph.text.split()[0] if paragraph.text.split() else ""

        # Format only the first word
        format_first_word_of_paragraph(
            paragraph,
            font_name=font_name,
            font_size=font_size,
            bold=bold,
            italic=italic,
        )

        doc.save(filename)

        # Verify word count unchanged
        doc_verify = Document(filename)
        para_verify = doc_verify.paragraphs[paragraph_index]
        words_after = count_words(para_verify.text)

        if words_before != words_after:
            return f"ERROR: Word count changed from {words_before} to {words_after}"

        formatting_desc = []
        if font_name:
            formatting_desc.append(f"font='{font_name}'")
        if font_size:
            formatting_desc.append(f"size={font_size}pt")
        if bold is not None:
            formatting_desc.append(f"bold={bold}")
        if italic is not None:
            formatting_desc.append(f"italic={italic}")
        if underline is not None:
            formatting_desc.append(f"underline={underline}")

        desc = ", ".join(formatting_desc) if formatting_desc else "no changes"
        return f"First word '{first_word}' formatted ({desc}). Word count: {words_after}"

    except Exception as e:
        return f"Failed to format first word: {str(e)}"


async def sync_document_formatting(
    reference_filename: str,
    target_filename: str,
    paragraph_mappings: List[Dict[str, int]],
) -> str:
    """
    Synchronize formatting from a reference document to a target document.

    This copies formatting from specified paragraphs in the reference document
    to corresponding paragraphs in the target document.

    Args:
        reference_filename: Path to the reference Word document (source of formatting)
        target_filename: Path to the target Word document (to be formatted)
        paragraph_mappings: List of mappings, each with 'ref_index' and 'target_index'
                           Example: [{"ref_index": 0, "target_index": 0}, ...]

    Returns:
        Success message with details of what was synced
    """
    reference_filename = ensure_docx_extension(reference_filename)
    target_filename = ensure_docx_extension(target_filename)

    if not os.path.exists(reference_filename):
        return f"Reference document {reference_filename} does not exist"
    if not os.path.exists(target_filename):
        return f"Target document {target_filename} does not exist"

    is_writeable, error_message = check_file_writeable(target_filename)
    if not is_writeable:
        return f"Cannot modify target document: {error_message}"

    try:
        ref_doc = Document(reference_filename)
        target_doc = Document(target_filename)

        results = []
        errors = []

        for mapping in paragraph_mappings:
            ref_idx = mapping.get('ref_index')
            target_idx = mapping.get('target_index')

            if ref_idx is None or target_idx is None:
                errors.append(f"Invalid mapping: {mapping}")
                continue

            try:
                ref_idx = int(ref_idx)
                target_idx = int(target_idx)
            except (ValueError, TypeError):
                errors.append(f"Invalid indices in mapping: {mapping}")
                continue

            if ref_idx < 0 or ref_idx >= len(ref_doc.paragraphs):
                errors.append(f"Reference paragraph index {ref_idx} out of range")
                continue
            if target_idx < 0 or target_idx >= len(target_doc.paragraphs):
                errors.append(f"Target paragraph index {target_idx} out of range")
                continue

            ref_para = ref_doc.paragraphs[ref_idx]
            target_para = target_doc.paragraphs[target_idx]

            words_before = count_words(target_para.text)

            # Copy formatting (with mixed formatting support)
            copy_mixed_formatting(ref_para, target_para)

            results.append(f"Para {ref_idx} → {target_idx}")

        target_doc.save(target_filename)

        # Verify all paragraphs
        doc_verify = Document(target_filename)
        for mapping in paragraph_mappings:
            target_idx = mapping.get('target_index')
            if target_idx is not None:
                try:
                    target_idx = int(target_idx)
                    para = doc_verify.paragraphs[target_idx]
                    words_after = count_words(para.text)
                    # We can't easily get words_before here, but the copy function
                    # doesn't modify text content, so it should be fine
                except (ValueError, IndexError):
                    pass

        result_msg = f"Synced {len(results)} paragraphs from {reference_filename} to {target_filename}"
        if results:
            result_msg += f". Mappings: {', '.join(results)}"
        if errors:
            result_msg += f". Errors: {', '.join(errors)}"

        return result_msg

    except Exception as e:
        return f"Failed to sync document formatting: {str(e)}"


async def compare_document_formatting(
    reference_filename: str,
    target_filename: str,
    paragraph_pairs: Optional[List[Dict[str, int]]] = None,
) -> str:
    """
    Compare formatting between two documents.

    Returns a detailed comparison of formatting differences.

    Args:
        reference_filename: Path to the reference Word document
        target_filename: Path to the target Word document
        paragraph_pairs: Optional list of paragraph index pairs to compare.
                        If None, compares all paragraphs pairwise.
                        Example: [{"ref_index": 0, "target_index": 0}, ...]

    Returns:
        Detailed comparison report
    """
    reference_filename = ensure_docx_extension(reference_filename)
    target_filename = ensure_docx_extension(target_filename)

    if not os.path.exists(reference_filename):
        return f"Reference document {reference_filename} does not exist"
    if not os.path.exists(target_filename):
        return f"Target document {target_filename} does not exist"

    try:
        ref_doc = Document(reference_filename)
        target_doc = Document(target_filename)

        # If no pairs specified, create pairwise mapping for min length
        if paragraph_pairs is None:
            min_paras = min(len(ref_doc.paragraphs), len(target_doc.paragraphs))
            paragraph_pairs = [
                {"ref_index": i, "target_index": i}
                for i in range(min_paras)
            ]

        matches = 0
        differences = []

        for pair in paragraph_pairs:
            ref_idx = pair.get('ref_index')
            target_idx = pair.get('target_index')

            if ref_idx is None or target_idx is None:
                continue

            try:
                ref_idx = int(ref_idx)
                target_idx = int(target_idx)
            except (ValueError, TypeError):
                continue

            if ref_idx >= len(ref_doc.paragraphs):
                differences.append(f"Ref para {ref_idx}: Does not exist")
                continue
            if target_idx >= len(target_doc.paragraphs):
                differences.append(f"Target para {target_idx}: Does not exist")
                continue

            ref_para = ref_doc.paragraphs[ref_idx]
            target_para = target_doc.paragraphs[target_idx]

            is_equal, diff = compare_paragraph_formatting(ref_para, target_para)

            if is_equal:
                matches += 1
            else:
                diff_summary = ", ".join(
                    f"{k}: {v['reference']} vs {v['target']}"
                    for k, v in diff.items()
                )
                differences.append(f"Para {ref_idx} vs {target_idx}: {diff_summary}")

        total_compared = len(paragraph_pairs)
        result = f"Formatting comparison: {matches}/{total_compared} paragraphs match\n"

        if differences:
            result += "\nDifferences found:\n" + "\n".join(f"  - {d}" for d in differences)
        else:
            result += "\nNo formatting differences found!"

        return result

    except Exception as e:
        return f"Failed to compare documents: {str(e)}"


async def extract_formatting_spec(filename: str, paragraph_index: Optional[int] = None) -> str:
    """
    Extract a formatting specification from a document.

    This creates a machine-readable specification of the formatting
    that can be used to replicate it in other documents.

    Args:
        filename: Path to the Word document
        paragraph_index: Optional specific paragraph to extract. If None,
                        extracts formatting for all paragraphs.

    Returns:
        JSON-like string with formatting specification
    """
    filename = ensure_docx_extension(filename)

    if not os.path.exists(filename):
        return f"Document {filename} does not exist"

    try:
        doc = Document(filename)

        if paragraph_index is not None:
            try:
                paragraph_index = int(paragraph_index)
            except (ValueError, TypeError):
                return "Invalid paragraph_index: must be an integer"

            if paragraph_index < 0 or paragraph_index >= len(doc.paragraphs):
                return f"Invalid paragraph index. Document has {len(doc.paragraphs)} paragraphs."

            para = doc.paragraphs[paragraph_index]
            fmt = extract_paragraph_formatting(para)
            fmt['text_preview'] = para.text[:50] + "..." if len(para.text) > 50 else para.text

            return f"Paragraph {paragraph_index} formatting:\n{str(fmt)}"

        else:
            # Extract for all paragraphs
            specs = []
            for i, para in enumerate(doc.paragraphs):
                fmt = extract_paragraph_formatting(para)
                fmt['index'] = i
                fmt['text_preview'] = para.text[:50] + "..." if len(para.text) > 50 else para.text
                specs.append(fmt)

            result = f"Document formatting specification ({len(specs)} paragraphs):\n"
            for spec in specs:
                result += f"\nPara {spec['index']}: {spec['style']} | {spec['font_name']} {spec['font_size']}pt"
                if spec.get('bold'):
                    result += " | bold"
                if spec.get('italic'):
                    result += " | italic"
                result += f"\n  Preview: {spec['text_preview'][:60]}"

            return result

    except Exception as e:
        return f"Failed to extract formatting spec: {str(e)}"
