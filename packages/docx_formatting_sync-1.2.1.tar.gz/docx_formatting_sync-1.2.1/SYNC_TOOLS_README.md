# docx-sync-mcp: Paragraph-Level Formatting Tools

This extension adds paragraph-level formatting synchronization tools to the Office Word MCP Server with a critical guarantee: **formatting operations never change word count**.

## New Tools

### 1. `format_paragraph`
Format an entire paragraph with uniform formatting.

```python
# Format paragraph 0 with Times New Roman, 14pt, bold
format_paragraph(
    filename="document.docx",
    paragraph_index=0,
    font_name="Times New Roman",
    font_size=14,
    bold=True,
    line_spacing=480  # Double spacing
)
```

**Guarantee:** Word count before = Word count after

---

### 2. `copy_paragraph_formatting`
Copy all formatting from a source paragraph to a target paragraph.

```python
# Copy formatting from reference to work document
copy_paragraph_formatting(
    source_filename="reference.docx",
    source_paragraph_index=0,
    target_filename="work.docx",
    target_paragraph_index=0
)
```

**Copies:**
- Paragraph style (Heading 4, Normal, etc.)
- Font family and size
- Bold, italic, underline
- Text color
- Line spacing
- Alignment
- Space before/after

**Guarantee:** Word count before = Word count after

---

### 3. `format_paragraph_first_word`
Format only the first word of a paragraph (e.g., "Background:", "Abstract:").

```python
# Make the first word bold and larger
format_paragraph_first_word(
    filename="document.docx",
    paragraph_index=5,
    font_name="Times New Roman",
    font_size=14,
    bold=True
)
```

**Guarantee:** Word count before = Word count after

---

### 4. `sync_document_formatting`
One-shot sync of formatting from reference document to target document.

```python
# Sync all paragraphs from reference to target
sync_document_formatting(
    reference_filename="reference.docx",
    target_filename="work.docx",
    paragraph_mappings=[
        {"ref_index": 0, "target_index": 0},  # Title
        {"ref_index": 1, "target_index": 1},  # Authors
        {"ref_index": 2, "target_index": 2},  # Affiliations
        {"ref_index": 4, "target_index": 4},  # Abstract label
        {"ref_index": 5, "target_index": 5},  # Background
    ]
)
```

**Guarantee:** Word count before = Word count after for all mapped paragraphs

---

### 5. `compare_document_formatting`
Compare formatting between two documents.

```python
# Compare formatting between documents
compare_document_formatting(
    reference_filename="reference.docx",
    target_filename="work.docx",
    paragraph_pairs=[
        {"ref_index": 0, "target_index": 0},
        {"ref_index": 1, "target_index": 1},
    ]
)
```

**Returns:** Detailed comparison report showing any formatting differences

---

### 6. `extract_formatting_spec`
Extract a formatting specification from a document.

```python
# Extract formatting spec for all paragraphs
extract_formatting_spec(filename="reference.docx")

# Extract for a specific paragraph
extract_formatting_spec(filename="reference.docx", paragraph_index=0)
```

**Returns:** Machine-readable formatting specification

---

## Use Case: Format Synchronization

The primary use case is synchronizing formatting from a reference document to an edited document:

```python
# 1. Extract formatting from reference
extract_formatting_spec("reference.docx")

# 2. Sync formatting to work document
sync_document_formatting(
    reference_filename="reference.docx",
    target_filename="work.docx",
    paragraph_mappings=[
        {"ref_index": i, "target_index": i}
        for i in range(6)  # Map paragraphs 0-5
    ]
)

# 3. Verify formatting matches
compare_document_formatting("reference.docx", "work.docx")
```

---

## Implementation Details

### Word Count Validation
Every formatting tool validates that the word count remains unchanged:

```python
def validate_word_count_unchanged(operation_name: str):
    """Decorator that validates word count doesn't change."""
    def decorator(func):
        @wraps(func)
        def wrapper(filename: str, paragraph_index: int, *args, **kwargs):
            # Get word count before
            words_before = count_words(paragraph.text)

            # Perform operation
            result = func(filename, paragraph_index, *args, **kwargs)

            # Verify word count after
            words_after = count_words(paragraph.text)
            assert words_before == words_after

            return result
        return wrapper
    return decorator
```

### Run Normalization
DOCX documents often have fragmented runs. The tools normalize runs before applying formatting:

```python
def normalize_paragraph_runs(paragraph):
    """Consolidate all runs into a single run."""
    full_text = paragraph.text
    # Remove all runs
    for run in list(paragraph.runs):
        run._element.getparent().remove(run._element)
    # Create single run with full text
    if full_text:
        paragraph.add_run(full_text)
```

---

## Testing

Run the tests:

```bash
cd Office-Word-MCP-Server
uv run pytest tests/test_sync_tools.py -v
```

Or with standard pytest:

```bash
pytest tests/test_sync_tools.py -v
```

---

## Error Handling

All tools return descriptive error messages:

- `"Document not found"` - File doesn't exist
- `"Invalid paragraph index"` - Index out of range
- `"Cannot modify document"` - File permissions
- `"ERROR: Word count changed"` - Critical invariant violation (should never happen)

---

## Benefits Over Existing Tools

| Existing Tool | New Sync Tool | Improvement |
|---------------|---------------|-------------|
| `format_text` with start_pos/end_pos | `format_paragraph` | No position tracking needed |
| Multiple `format_text` calls per paragraph | Single `format_paragraph` call | 1 call instead of 10-50 |
| Manual style + font + size application | `copy_paragraph_formatting` | Copies all formatting at once |
| Manual comparison of documents | `compare_document_formatting` | Automated diff report |
| No word count validation | Built-in validation | Guaranteed content preservation |

---

## Files Added

- `word_document_server/core/formatting.py` - Core formatting utilities
- `word_document_server/tools/sync_tools.py` - Sync tool implementations
- `tests/test_sync_tools.py` - Unit tests
- `SYNC_TOOLS_README.md` - This documentation
