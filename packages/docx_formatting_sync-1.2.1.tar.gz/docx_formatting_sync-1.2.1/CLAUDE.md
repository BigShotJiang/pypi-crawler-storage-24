# Office Word MCP Server - Development Guidelines

## Core Principle: Conservative Approach

When improving this project, **conservative approaches are strongly encouraged**. This means:

### Preferred
- **Documentation improvements** over code changes
- **Small, targeted fixes** over refactors
- **Clear warnings** in docstrings over behavioral changes
- **Deterministic/hacky solutions** over flexible abstractions

### Discouraged
- Adding new tools or features unless absolutely necessary
- Renaming parameters or changing APIs
- Complex validation logic with many edge cases
- Abstractions that add indirection

## Example Decision Matrix

| Problem | Conservative Solution | Non-Preferred Solution |
|---------|----------------------|------------------------|
| Users confused about units | Add clear docstring documentation | Add unit conversion parameters |
| Tool destroys mixed formatting | Document this behavior with warning | Add preserve_mixed_formatting parameter |
| Line spacing bug | One-line fix with comment | New validation system + named values |

## When in Doubt

1. Can this be solved with better documentation? → Do that first
2. Can this be a 5-line fix? → Prefer over a 50-line solution
3. Does this change existing behavior? → Avoid unless fixing bugs
4. Does this add maintenance burden? → Probably not worth it

## Bug Fixes Are Always Welcome

Actual bugs (like incorrect unit conversions) should be fixed with minimal code changes and clear comments explaining the fix.
