"""
Tests for sync tools (docx-sync-mcp).

These tests verify that:
1. Formatting operations don't change word count
2. Paragraph-level formatting works correctly
3. Copy formatting works between documents
4. Comparison tools work correctly
"""
import pytest
import os
import tempfile
import asyncio
from docx import Document
from docx.shared import Pt

from word_document_server.tools.sync_tools import (
    format_paragraph,
    copy_paragraph_formatting,
    format_paragraph_first_word,
    sync_document_formatting,
    compare_document_formatting,
    extract_formatting_spec,
)
from word_document_server.core.formatting import count_words


def run_async(coro):
    """Helper to run async functions in tests."""
    return asyncio.run(coro)


class TestFormatParagraph:
    """Tests for format_paragraph tool."""

    @pytest.fixture
    def temp_doc(self):
        """Create a temporary document for testing."""
        with tempfile.NamedTemporaryFile(suffix='.docx', delete=False) as f:
            doc = Document()
            doc.add_paragraph("This is a test paragraph with five words.")
            doc.add_paragraph("Second paragraph here.")
            doc.save(f.name)
            yield f.name
            os.unlink(f.name)

    def test_format_paragraph_word_count_preserved(self, temp_doc):
        """Test that word count is preserved during formatting."""
        doc = Document(temp_doc)
        words_before = count_words(doc.paragraphs[0].text)

        result = run_async(format_paragraph(
            temp_doc, 0,
            font_name="Times New Roman",
            font_size=14,
            bold=True
        ))

        assert "ERROR" not in result
        assert f"Word count: {words_before}" in result

        doc = Document(temp_doc)
        words_after = count_words(doc.paragraphs[0].text)
        assert words_before == words_after

    def test_format_paragraph_applies_font(self, temp_doc):
        """Test that font is applied correctly."""
        result = run_async(format_paragraph(
            temp_doc, 0,
            font_name="Times New Roman",
            font_size=12
        ))

        assert "ERROR" not in result

        doc = Document(temp_doc)
        paragraph = doc.paragraphs[0]
        # After normalization, should have single run
        assert len(paragraph.runs) == 1
        assert paragraph.runs[0].font.name == "Times New Roman"

    def test_format_paragraph_invalid_index(self, temp_doc):
        """Test handling of invalid paragraph index."""
        result = run_async(format_paragraph(temp_doc, 999, font_name="Arial"))
        assert "Invalid paragraph index" in result


class TestCopyParagraphFormatting:
    """Tests for copy_paragraph_formatting tool."""

    @pytest.fixture
    def temp_docs(self):
        """Create two temporary documents for testing."""
        with tempfile.NamedTemporaryFile(suffix='.docx', delete=False) as f1:
            with tempfile.NamedTemporaryFile(suffix='.docx', delete=False) as f2:
                # Source doc with formatted paragraph
                source = Document()
                para1 = source.add_paragraph("Source paragraph text.")
                para1.style = 'Heading 1'
                for run in para1.runs:
                    run.font.name = "Times New Roman"
                    run.font.size = Pt(14)
                    run.bold = True
                source.save(f1.name)

                # Target doc with unformatted paragraph
                target = Document()
                target.add_paragraph("Target paragraph text here.")
                target.save(f2.name)

                yield f1.name, f2.name

                os.unlink(f1.name)
                os.unlink(f2.name)

    def test_copy_formatting_preserves_word_count(self, temp_docs):
        """Test that copying formatting doesn't change word count."""
        source_file, target_file = temp_docs

        doc = Document(target_file)
        words_before = count_words(doc.paragraphs[0].text)

        result = run_async(copy_paragraph_formatting(
            source_file, 0,
            target_file, 0
        ))

        assert "ERROR" not in result

        doc = Document(target_file)
        words_after = count_words(doc.paragraphs[0].text)
        assert words_before == words_after

    def test_copy_formatting_applies_style(self, temp_docs):
        """Test that paragraph style is copied."""
        source_file, target_file = temp_docs

        result = run_async(copy_paragraph_formatting(
            source_file, 0,
            target_file, 0
        ))

        assert "ERROR" not in result

        doc = Document(target_file)
        assert doc.paragraphs[0].style.name == 'Heading 1'


class TestFormatParagraphFirstWord:
    """Tests for format_paragraph_first_word tool."""

    @pytest.fixture
    def temp_doc(self):
        """Create a temporary document for testing."""
        with tempfile.NamedTemporaryFile(suffix='.docx', delete=False) as f:
            doc = Document()
            doc.add_paragraph("Background: This is the rest of the paragraph.")
            doc.save(f.name)
            yield f.name
            os.unlink(f.name)

    def test_format_first_word_preserves_word_count(self, temp_doc):
        """Test that formatting first word doesn't change word count."""
        doc = Document(temp_doc)
        words_before = count_words(doc.paragraphs[0].text)

        result = run_async(format_paragraph_first_word(
            temp_doc, 0,
            font_name="Times New Roman",
            font_size=14,
            bold=True
        ))

        assert "ERROR" not in result

        doc = Document(temp_doc)
        words_after = count_words(doc.paragraphs[0].text)
        assert words_before == words_after

    def test_format_first_word_targets_first_word(self, temp_doc):
        """Test that only the first word is formatted."""
        result = run_async(format_paragraph_first_word(
            temp_doc, 0,
            bold=True
        ))

        assert "ERROR" not in result
        assert "First word 'Background:'" in result


class TestSyncDocumentFormatting:
    """Tests for sync_document_formatting tool."""

    @pytest.fixture
    def temp_docs(self):
        """Create two temporary documents for testing."""
        with tempfile.NamedTemporaryFile(suffix='.docx', delete=False) as f1:
            with tempfile.NamedTemporaryFile(suffix='.docx', delete=False) as f2:
                # Source doc with formatted paragraphs
                source = Document()
                para1 = source.add_paragraph("Title paragraph.")
                para1.style = 'Heading 1'
                para2 = source.add_paragraph("Body paragraph here.")
                para2.style = 'Normal'
                source.save(f1.name)

                # Target doc with unformatted paragraphs
                target = Document()
                target.add_paragraph("Different title text.")
                target.add_paragraph("Different body text here.")
                target.save(f2.name)

                yield f1.name, f2.name

                os.unlink(f1.name)
                os.unlink(f2.name)

    def test_sync_multiple_paragraphs(self, temp_docs):
        """Test syncing formatting across multiple paragraphs."""
        source_file, target_file = temp_docs

        mappings = [
            {"ref_index": 0, "target_index": 0},
            {"ref_index": 1, "target_index": 1},
        ]

        result = run_async(sync_document_formatting(
            source_file, target_file, mappings
        ))

        assert "Synced 2 paragraphs" in result

        doc = Document(target_file)
        assert doc.paragraphs[0].style.name == 'Heading 1'
        assert doc.paragraphs[1].style.name == 'Normal'


class TestCompareDocumentFormatting:
    """Tests for compare_document_formatting tool."""

    @pytest.fixture
    def temp_docs(self):
        """Create two temporary documents for testing."""
        with tempfile.NamedTemporaryFile(suffix='.docx', delete=False) as f1:
            with tempfile.NamedTemporaryFile(suffix='.docx', delete=False) as f2:
                doc1 = Document()
                para1 = doc1.add_paragraph("Same text here.")
                para1.style = 'Heading 1'
                doc1.save(f1.name)

                doc2 = Document()
                para2 = doc2.add_paragraph("Different text content.")
                para2.style = 'Heading 1'
                doc2.save(f2.name)

                yield f1.name, f2.name

                os.unlink(f1.name)
                os.unlink(f2.name)

    def test_compare_same_formatting(self, temp_docs):
        """Test comparing documents with same formatting."""
        doc1, doc2 = temp_docs

        result = run_async(compare_document_formatting(doc1, doc2))

        assert "1/1 paragraphs match" in result or "formatting differences" in result.lower()


class TestExtractFormattingSpec:
    """Tests for extract_formatting_spec tool."""

    @pytest.fixture
    def temp_doc(self):
        """Create a temporary document for testing."""
        with tempfile.NamedTemporaryFile(suffix='.docx', delete=False) as f:
            doc = Document()
            para = doc.add_paragraph("Test paragraph content.")
            para.style = 'Heading 1'
            doc.save(f.name)
            yield f.name
            os.unlink(f.name)

    def test_extract_single_paragraph(self, temp_doc):
        """Test extracting formatting for a single paragraph."""
        result = run_async(extract_formatting_spec(temp_doc, 0))

        assert "Paragraph 0 formatting" in result
        assert "Heading 1" in result or "Normal" in result

    def test_extract_all_paragraphs(self, temp_doc):
        """Test extracting formatting for all paragraphs."""
        result = run_async(extract_formatting_spec(temp_doc))

        assert "Document formatting specification" in result
        assert "1 paragraphs" in result or "paragraphs" in result


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
