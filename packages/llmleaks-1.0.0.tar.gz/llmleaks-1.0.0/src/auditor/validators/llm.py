import httpx
from auditor.core.base import Validator


class OpenAIValidator(Validator):
    """Validates OpenAI API keys by querying the models endpoint."""
    
    name = "openai"
    
    async def validate(self, client: httpx.AsyncClient, key: str) -> bool:
        try:
            response = await client.get(
                "https://api.openai.com/v1/models",
                headers={"Authorization": f"Bearer {key}"}
            )
            return response.status_code == 200
        except httpx.HTTPError:
            return False


class AnthropicValidator(Validator):
    """Validates Anthropic (Claude) API keys."""
    
    name = "anthropic"
    
    async def validate(self, client: httpx.AsyncClient, key: str) -> bool:
        headers = {
            "x-api-key": key,
            "anthropic-version": "2023-06-01"
        }
        try:
            response = await client.get(
                "https://api.anthropic.com/v1/models",
                headers=headers
            )
            return response.status_code == 200
        except httpx.HTTPError:
            return False


class GeminiValidator(Validator):
    """Validates Google Gemini API keys."""
    
    name = "gemini"
    
    async def validate(self, client: httpx.AsyncClient, key: str) -> bool:
        try:
            response = await client.get(
                f"https://generativelanguage.googleapis.com/v1beta/models?key={key}"
            )
            return response.status_code == 200
        except httpx.HTTPError:
            return False


class DeepSeekValidator(Validator):
    """Validates DeepSeek API keys."""
    
    name = "deepseek"
    
    async def validate(self, client: httpx.AsyncClient, key: str) -> bool:
        try:
            response = await client.get(
                "https://api.deepseek.com/models",
                headers={"Authorization": f"Bearer {key}"}
            )
            return response.status_code == 200
        except httpx.HTTPError:
            return False


class GroqValidator(Validator):
    """Validates Groq API keys."""
    
    name = "groq"
    
    async def validate(self, client: httpx.AsyncClient, key: str) -> bool:
        try:
            response = await client.get(
                "https://api.groq.com/openai/v1/models",
                headers={"Authorization": f"Bearer {key}"}
            )
            return response.status_code == 200
        except httpx.HTTPError:
            return False


class PerplexityValidator(Validator):
    """Validates Perplexity API keys."""
    
    name = "perplexity"
    
    async def validate(self, client: httpx.AsyncClient, key: str) -> bool:
        headers = {
            "Authorization": f"Bearer {key}",
            "Accept": "application/json"
        }
        try:
            response = await client.get(
                "https://api.perplexity.ai/models",
                headers=headers
            )
            # 401 indicates invalid key, 200 or 400 means valid authentication
            return response.status_code in (200, 400)
        except httpx.HTTPError:
            return False


class HuggingFaceValidator(Validator):
    """Validates Hugging Face API tokens."""
    
    name = "huggingface"
    
    async def validate(self, client: httpx.AsyncClient, key: str) -> bool:
        try:
            response = await client.get(
                "https://huggingface.co/api/whoami-v2",
                headers={"Authorization": f"Bearer {key}"}
            )
            return response.status_code == 200
        except httpx.HTTPError:
            return False
