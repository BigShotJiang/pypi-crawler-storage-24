from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="sentryix",
    version="1.0.0",
    author="Sentryix",
    author_email="sales@sentryix.ai",
    description="Verify AI agent actions before execution. EU AI Act compliant.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://sentinelvault-deploy.vercel.app",
    project_urls={
        "Documentation": "https://sentinelvault-deploy.vercel.app/dashboard",
        "Source":         "https://github.com/sentryix/sentryix-python",
        "Tracker":        "https://github.com/sentryix/sentryix-python/issues",
    },
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[],          # zero dependencies — stdlib only
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Security",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    keywords=[
        "ai", "agent", "governance", "security", "llm",
        "eu-ai-act", "compliance", "guardrails", "prompt-injection"
    ],
)
