# Changelog

All notable changes to this project are documented in this file.

## [0.3.2] - 2026-03-13

### Fixed
- Updated README banner/divider image URLs to `github.com/.../raw/...` paths for more reliable rendering in private-repo GitHub views.
- Replaced the last remaining relative divider image path in README with an absolute URL for PyPI rendering consistency.

### Changed
- Bumped package/runtime version surfaces from `0.3.1` to `0.3.2`.

## [0.3.1] - 2026-03-13

### Changed
- Updated security contact email to `ravi.open.source.projects@gmail.com`.
- Updated README file links/images to absolute GitHub URLs for correct rendering on PyPI project pages.
- Bumped package/runtime version surfaces from `0.3.0` to `0.3.1`.

## [0.3.0] - 2026-03-12

### Added
- Exported `NeurovaultConfig`, `EntityType`, and `NeurovaultError` at package root for downstream integration.
- Added `py.typed` marker for typed-package support.

### Changed
- Aligned package metadata version to `0.3.0`.
- Removed vendored `src/chronos` source from this repository; CHRONOS is now consumed via dependency (`chronos-memory`) only.
- Removed `chronos` CLI script from this package.

### Security
- Replaced unsafe pickle loading in vector index persistence.
- Hardened bootstrap auth flow with mandatory bootstrap token.
- Updated websocket token checks to timing-safe comparison.
- Defaulted federation and websocket bind hosts to `127.0.0.1`.
- Replaced insecure temporary file patterns in sensors.

### Fixed
- Corrected Prometheus counter vs gauge type declarations.
- Reworked migration version comparisons to avoid lexical ordering errors.
- Added platform guard for calendar integration on non-macOS systems.

## [0.2.0] - 2026-03-10

### Added
- Expanded consolidation pipeline and graph-aware search paths.
- Added mobile API and websocket event streaming surfaces.

## [0.1.0] - 2026-03-08

### Added
- Initial NeuroVault engine, CLI, storage, sensors, and cognitive pipeline.
