# CertiSigma Python SDK

Official Python client for the [CertiSigma](https://certisigma.ch) cryptographic attestation API.

## Installation

```bash
pip install certisigma
```

Or from source:

```bash
cd sdk/python
pip install -e .
```

## Quick Start

```python
from certisigma import CertiSigmaClient

client = CertiSigmaClient(api_key="cs_live_your_key_here")

# Attest a SHA-256 hash
result = client.attest("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
print(f"Attestation: {result.id} at {result.timestamp}")
print(f"ECDSA signature: {result.signature}")

# Verify
check = client.verify("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
print(f"Exists: {check.exists}, Level: {check.level}")
```

## File Hashing Helper

```python
result = client.attest_file("/path/to/document.pdf")
print(f"Attested: {result.hash_hex}")
```

## Async Support

```python
import asyncio
from certisigma import AsyncCertiSigmaClient

async def main():
    async with AsyncCertiSigmaClient(api_key="cs_live_xxx") as client:
        result = await client.attest("abcdef..." * 4 + "0" * 16)
        print(result.id)

asyncio.run(main())
```

## Batch Operations

```python
# Attest up to 100 hashes in one call
batch = client.batch_attest(
    ["aabb..." * 4, "ccdd..." * 4],
    source="monthly-invoices"
)
print(f"Created: {batch.created}, Existing: {batch.existing}")

# Verify batch
results = client.batch_verify(["aabb..." * 4, "ccdd..." * 4])
print(f"Found: {results.found}/{results.count}")
```

## Metadata Management

```python
# Update claim metadata
result = client.update_metadata("att_1234", source="pipeline-v2", extra_data={"project": "alpha"})

# Soft-delete claim
client.delete_metadata("att_1234")

# Get evidence
evidence = client.get_evidence("att_1234")
print(evidence.level, evidence.t0)
```

## Client-Side Encryption (Zero Knowledge)

Requires: `pip install certisigma[crypto]`

```python
from certisigma.crypto import generate_key, encrypt_metadata, decrypt_metadata

# Generate a key (store securely — server never sees it)
key = generate_key()

# Encrypt before sending
encrypted = encrypt_metadata({"secret": "classified"}, key)
result = client.attest(hash_hex, extra_data=encrypted, client_encrypted=True)

# Decrypt after retrieving
plaintext = decrypt_metadata(result.extra_data, key)
```

## Error Handling

```python
from certisigma import (
    CertiSigmaError,
    AuthenticationError,
    RateLimitError,
    QuotaExceededError,
)

try:
    client.attest(hash_hex)
except AuthenticationError:
    print("Invalid API key")
except RateLimitError as e:
    print(f"Rate limited, retry after {e.retry_after}s")
except QuotaExceededError:
    print("Monthly quota reached")
except CertiSigmaError as e:
    print(f"API error {e.status_code}: {e}")
```

## Configuration

| Parameter | Default | Description |
|-----------|---------|-------------|
| `api_key` | (required) | Bearer token (`cs_live_...`) |
| `base_url` | `https://api.certisigma.ch` | API endpoint |
| `timeout` | `30.0` | Request timeout in seconds |

## Requirements

- Python 3.10+
- `httpx` >= 0.25.0
- `cryptography` >= 44.0.0 (optional, for `certisigma.crypto`)

## License

MIT — Ten Sigma Sagl, Lugano, Switzerland
