"""Inngest function: scrape last 500 commits per Karpathy repo.

Actual output path structure (org prefix is preserved from the API):
  raw_data/commits/karpathy/{repo}/{sha}.json
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path

import httpx
import inngest

from pipeline.inngest_client import client

TRIGGER_EVENT = "pipeline/scrape.github.commits"

REPOS = [
    "karpathy/micrograd",
    "karpathy/nanoGPT",
    "karpathy/minbpe",
    "karpathy/llm.c",
    "karpathy/ng-video-lecture",
]

MAX_COMMITS = 500
PAGE_SIZE = 100  # GitHub max per page

RAW_DATA_ROOT = Path("raw_data/commits")

GITHUB_API = "https://api.github.com"


def _headers() -> dict[str, str]:
    return {
        "Authorization": f"Bearer {os.environ['GITHUB_TOKEN']}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }


def _dest(repo: str, sha: str) -> Path:
    return RAW_DATA_ROOT / repo / f"{sha}.json"


def _fetch_commit_list(repo: str) -> list[str]:
    """Return up to MAX_COMMITS SHAs for the repo, handling pagination."""
    shas: list[str] = []
    page = 1
    with httpx.Client(headers=_headers(), timeout=30) as http:
        while len(shas) < MAX_COMMITS:
            resp = http.get(
                f"{GITHUB_API}/repos/{repo}/commits",
                params={"per_page": PAGE_SIZE, "page": page},
            )
            if resp.status_code == 429:
                retry_after = int(resp.headers.get("Retry-After", "60"))
                raise inngest.RetryAfterError("GitHub rate-limited", retry_after)
            resp.raise_for_status()
            batch = resp.json()
            if not batch:
                break
            shas.extend(item["sha"] for item in batch)
            if len(batch) < PAGE_SIZE:
                break
            page += 1

    return shas[:MAX_COMMITS]


def _fetch_commit(repo: str, sha: str) -> None:
    """Fetch a single commit with its diff and write to disk."""
    dest = _dest(repo, sha)
    if dest.exists():
        return

    with httpx.Client(headers=_headers(), timeout=60) as http:
        resp = http.get(f"{GITHUB_API}/repos/{repo}/commits/{sha}")
        if resp.status_code == 429:
            retry_after = int(resp.headers.get("Retry-After", "60"))
            raise inngest.RetryAfterError("GitHub rate-limited", retry_after)
        resp.raise_for_status()
        data = resp.json()

    commit_obj = data.get("commit", {})
    author = commit_obj.get("author", {})

    record = {
        "repo": repo,
        "sha": sha,
        "message": commit_obj.get("message", ""),
        "date": author.get("date", ""),
        "author": author.get("name", ""),
        "author_email": author.get("email", ""),
        "files": [
            {
                "filename": f.get("filename"),
                "status": f.get("status"),
                "additions": f.get("additions"),
                "deletions": f.get("deletions"),
                "patch": f.get("patch", ""),
            }
            for f in data.get("files", [])
        ],
        "scraped_at": datetime.now(timezone.utc).isoformat(),
    }

    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(record, indent=2))


@client.create_function(
    fn_id="scrape-github-commits",
    name="Scrape GitHub Commits",
    trigger=inngest.TriggerEvent(event=TRIGGER_EVENT),
    retries=5,
)
async def scrape_github_commits(ctx: inngest.Context) -> dict:
    results: dict[str, int] = {}

    for repo in REPOS:
        repo_slug = repo.replace("/", "-")

        shas: list[str] = await ctx.step.run(
            f"list-commits-{repo_slug}",
            lambda r=repo: _fetch_commit_list(r),
        )

        saved = 0
        for sha in shas:
            if _dest(repo, sha).exists():
                continue

            await ctx.step.run(
                f"fetch-commit-{repo_slug}-{sha}",
                lambda r=repo, s=sha: _fetch_commit(r, s),
            )
            saved += 1

        results[repo] = saved

    return results
