"""Scrape Karpathy commits where the message signals an actual coding decision.

Filters to commits whose message contains any of the OPINION_KEYWORDS — these
are the ones where he's simplifying, removing, refactoring, or otherwise making
an explicit coding judgement. Merges and readme fixes are skipped.

Output: raw_data/commits_opinionated/karpathy/{repo}/{sha}.json
"""

from __future__ import annotations

import json
import os
import time
from datetime import datetime, timezone
from math import ceil
from pathlib import Path

import httpx
from dotenv import load_dotenv

load_dotenv()

REPOS = [
    "karpathy/micrograd",
    "karpathy/nanoGPT",
    "karpathy/minbpe",
    "karpathy/llm.c",
    "karpathy/ng-video-lecture",
]

OPINION_KEYWORDS = [
    "simplify",
    "remove",
    "clean",
    "refactor",
    "just ",
    "unnecessary",
    "too ",
    "rewrite",
    "fix",
    "improve",
    "rename",
]

MAX_COMMITS = 500
PAGE_SIZE = 100

RAW_DATA_ROOT = Path("raw_data/commits_opinionated")
GITHUB_API = "https://api.github.com"


def _wait_for_rate_limit(resp: httpx.Response) -> None:
    """Sleep until GitHub's rate-limit window resets, then return."""
    reset_ts = resp.headers.get("X-RateLimit-Reset")
    if reset_ts:
        wait = max(0, ceil(int(reset_ts) - time.time())) + 1
    else:
        wait = int(resp.headers.get("Retry-After", "60"))
    print(f"  rate-limited (HTTP {resp.status_code}), sleeping {wait}s …")
    time.sleep(wait)


def _headers() -> dict[str, str]:
    token = os.environ.get("GITHUB_TOKEN", "")
    h = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    if token:
        h["Authorization"] = f"Bearer {token}"
    return h


def _is_opinionated(message: str) -> bool:
    low = message.lower()
    return any(kw in low for kw in OPINION_KEYWORDS)


def _dest(repo: str, sha: str) -> Path:
    return RAW_DATA_ROOT / repo / f"{sha}.json"


def _fetch_commit_list(http: httpx.Client, repo: str) -> list[dict]:
    """Return up to MAX_COMMITS commit stubs (sha + message) for the repo."""
    commits: list[dict] = []
    page = 1
    while len(commits) < MAX_COMMITS:
        resp = http.get(
            f"{GITHUB_API}/repos/{repo}/commits",
            params={"per_page": PAGE_SIZE, "page": page},
        )
        if resp.status_code in (403, 429):
            _wait_for_rate_limit(resp)
            continue
        resp.raise_for_status()
        batch = resp.json()
        if not batch:
            break
        for item in batch:
            commits.append({
                "sha": item["sha"],
                "message": item["commit"]["message"],
            })
        if len(batch) < PAGE_SIZE:
            break
        page += 1

    return commits[:MAX_COMMITS]


def _fetch_commit(http: httpx.Client, repo: str, sha: str) -> None:
    """Fetch full commit diff and write to disk."""
    dest = _dest(repo, sha)
    if dest.exists():
        return

    while True:
        resp = http.get(f"{GITHUB_API}/repos/{repo}/commits/{sha}")
        if resp.status_code in (403, 429):
            _wait_for_rate_limit(resp)
            continue
        resp.raise_for_status()
        data = resp.json()
        break

    commit_obj = data.get("commit", {})
    author = commit_obj.get("author", {})

    record = {
        "repo": repo,
        "sha": sha,
        "message": commit_obj.get("message", ""),
        "date": author.get("date", ""),
        "author": author.get("name", ""),
        "author_email": author.get("email", ""),
        "files": [
            {
                "filename": f.get("filename"),
                "status": f.get("status"),
                "additions": f.get("additions"),
                "deletions": f.get("deletions"),
                "patch": f.get("patch", ""),
            }
            for f in data.get("files", [])
        ],
        "scraped_at": datetime.now(timezone.utc).isoformat(),
    }

    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(record, indent=2))


def run() -> None:
    token = os.environ.get("GITHUB_TOKEN", "")
    print(f"GITHUB_TOKEN: {token[:8]}..." if token else "GITHUB_TOKEN: (not set)")

    with httpx.Client(headers=_headers(), timeout=60) as http:
        for repo in REPOS:
            print(f"\n{repo}")
            commits = _fetch_commit_list(http, repo)
            opinionated = [c for c in commits if _is_opinionated(c["message"])]
            print(f"  {len(commits)} commits fetched, {len(opinionated)} opinionated")

            saved = 0
            skipped = 0
            for c in opinionated:
                sha = c["sha"]
                if _dest(repo, sha).exists():
                    skipped += 1
                    continue
                print(f"  {sha[:7]} {c['message'].splitlines()[0][:60]}")
                _fetch_commit(http, repo, sha)
                saved += 1

            print(f"  saved {saved}, skipped {skipped} already on disk")


if __name__ == "__main__":
    run()
