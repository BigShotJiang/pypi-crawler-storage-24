"""Inngest function: scrape .py and .c files from Karpathy's GitHub repos.

Actual output path structure (org prefix is preserved from the API):
  raw_data/github_source/karpathy/{repo}/{filepath}
  raw_data/github_source/karpathy/{repo}/{filepath}.meta.json
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path

import httpx
import inngest
from dotenv import load_dotenv

from pipeline.inngest_client import client

load_dotenv()

TRIGGER_EVENT = "pipeline/scrape.github.source"

REPOS = [
    "karpathy/micrograd",
    "karpathy/nanoGPT",
    "karpathy/minbpe",
    "karpathy/llm.c",
    "karpathy/ng-video-lecture",
]

ALLOWED_EXTENSIONS = {".py", ".c"}

RAW_DATA_ROOT = Path("raw_data/github_source")

GITHUB_API = "https://api.github.com"


def _headers() -> dict[str, str]:
    token = os.environ["GITHUB_TOKEN"]
    return {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }


def _dest(repo: str, filepath: str) -> Path:
    """Return the destination path for a file."""
    return RAW_DATA_ROOT / repo / filepath


def _meta_path(dest: Path) -> Path:
    return dest.with_suffix(dest.suffix + ".meta.json")


def _fetch_tree(repo: str) -> list[dict]:
    """Fetch the full recursive tree for the default branch."""
    # First resolve default branch
    with httpx.Client(headers=_headers(), timeout=30) as http:
        resp = http.get(f"{GITHUB_API}/repos/{repo}")
        resp.raise_for_status()
        default_branch = resp.json()["default_branch"]

        resp = http.get(
            f"{GITHUB_API}/repos/{repo}/git/trees/{default_branch}",
            params={"recursive": "1"},
        )
        resp.raise_for_status()
        return resp.json().get("tree", [])


def _fetch_file(repo: str, item: dict) -> None:
    """Download a single file and write it alongside a .meta.json sidecar."""
    filepath: str = item["path"]
    dest = _dest(repo, filepath)

    if _meta_path(dest).exists():
        return  # already scraped

    url = item["url"]  # blob API URL
    with httpx.Client(headers={**_headers(), "Accept": "application/vnd.github.raw+json"}, timeout=30) as http:
        resp = http.get(url)
        if resp.status_code == 429:
            retry_after = int(resp.headers.get("Retry-After", "60"))
            raise inngest.RetryAfterError(f"GitHub rate-limited", retry_after)
        resp.raise_for_status()
        content = resp.content

    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(content)

    meta = {
        "repo": repo,
        "filepath": filepath,
        "sha": item["sha"],
        "url": item.get("html_url", url),
        "scraped_at": datetime.now(timezone.utc).isoformat(),
    }
    _meta_path(dest).write_text(json.dumps(meta, indent=2))


@client.create_function(
    fn_id="scrape-github-source",
    name="Scrape GitHub Source",
    trigger=inngest.TriggerEvent(event=TRIGGER_EVENT),
    retries=5,
)
async def scrape_github_source(ctx: inngest.Context) -> dict:
    """Fetch all .py/.c files from Karpathy repos and persist to raw_data/."""
    results: dict[str, int] = {}

    for repo in REPOS:
        tree: list[dict] = await ctx.step.run(
            f"fetch-tree-{repo.replace('/', '-')}",
            lambda r=repo: _fetch_tree(r),
        )

        blobs = [
            item for item in tree
            if item["type"] == "blob"
            and Path(item["path"]).suffix in ALLOWED_EXTENSIONS
        ]

        saved = 0
        for item in blobs:
            filepath = item["path"]
            dest = _dest(repo, filepath)
            if _meta_path(dest).exists():
                continue

            await ctx.step.run(
                f"fetch-file-{repo.replace('/', '-')}-{filepath.replace('/', '-')}",
                lambda r=repo, i=item: _fetch_file(r, i),
            )
            saved += 1

        results[repo] = saved

    return results
