"""Single source of truth for provider and API key resolution."""

from __future__ import annotations

import os
import sys
from pathlib import Path

CONFIG_DIR = Path.home() / ".karpathy-review"
CONFIG_FILE = CONFIG_DIR / "config"
KB_DIR = CONFIG_DIR / "knowledge_base"
KB_CHROMA = KB_DIR / "chroma"


def _find_chroma_sqlite(root: Path) -> Path | None:
    """Return the directory containing chroma.sqlite3, searching root recursively."""
    for match in root.rglob("chroma.sqlite3"):
        return match.parent
    return None


def get_kb_path() -> Path:
    """Return the directory containing chroma.sqlite3, downloading from HuggingFace if needed."""
    # Fast path: already located from a previous run
    existing = _find_chroma_sqlite(KB_DIR)
    if existing:
        return existing

    print("downloading knowledge base (~50mb), one time setup...")
    from huggingface_hub import snapshot_download
    snapshot_download(
        repo_id="sree22/karpathy-review-kb",
        repo_type="dataset",
        local_dir=str(KB_DIR),
    )

    # Debug: show what landed on disk
    print(f"downloaded to: {KB_DIR}")
    for p in sorted(KB_DIR.rglob("*"))[:30]:
        print(f"  {p.relative_to(KB_DIR)}")

    chroma_dir = _find_chroma_sqlite(KB_DIR)
    if chroma_dir is None:
        raise RuntimeError(f"chroma.sqlite3 not found anywhere under {KB_DIR}")
    print(f"chroma dir: {chroma_dir}")
    return chroma_dir


def get_provider() -> str:
    """Return 'openai' or 'anthropic'. Env var > config file > default openai."""
    if p := os.environ.get("KR_PROVIDER", "").lower():
        return p
    if p := _read_config("KR_PROVIDER"):
        return p.lower()
    return "openai"


def _read_config(key_name: str) -> str:
    """Return the value of key_name from the config file, or ''."""
    if not CONFIG_FILE.exists():
        return ""
    for line in CONFIG_FILE.read_text().splitlines():
        if line.startswith(f"{key_name}="):
            value = line.split("=", 1)[1].strip()
            if value:
                return value
    return ""


def _save_config(key_name: str, value: str) -> None:
    """Write or update key_name=value in the config file."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    lines = CONFIG_FILE.read_text().splitlines() if CONFIG_FILE.exists() else []
    # replace existing line or append
    new_lines = [l for l in lines if not l.startswith(f"{key_name}=")]
    new_lines.append(f"{key_name}={value}")
    CONFIG_FILE.write_text("\n".join(new_lines) + "\n")
    CONFIG_FILE.chmod(0o600)


def get_api_key() -> str:
    """Return the LLM API key for the active provider, prompting if needed.

    Always returns the OpenAI key when provider is 'openai', or the
    Anthropic key when provider is 'anthropic'. Embeddings always use
    get_openai_key() directly since the KB was built with OpenAI.
    """
    provider = get_provider()
    if provider == "anthropic":
        return _get_key(
            config_name="ANTHROPIC_API_KEY",
            env_name="ANTHROPIC_API_KEY",
            label="Anthropic",
        )
    return _get_key(
        config_name="OPENAI_API_KEY",
        env_name="OPENAI_API_KEY",
        label="OpenAI",
    )


def get_openai_key() -> str:
    """Return OPENAI_API_KEY unconditionally (used for embeddings)."""
    return _get_key(
        config_name="OPENAI_API_KEY",
        env_name="OPENAI_API_KEY",
        label="OpenAI",
    )


def _get_key(config_name: str, env_name: str, label: str) -> str:
    # 1. config file
    key = _read_config(config_name)
    if key:
        return key

    # 2. env var
    key = os.environ.get(env_name, "")
    if key:
        return key

    # 3. prompt and persist
    print(f"{env_name} not found.")
    key = input(f"Enter your {label} API key: ").strip()
    if not key:
        print("No key provided. Exiting.")
        sys.exit(1)

    _save_config(config_name, key)
    print(f"Key saved to {CONFIG_FILE}")
    return key
