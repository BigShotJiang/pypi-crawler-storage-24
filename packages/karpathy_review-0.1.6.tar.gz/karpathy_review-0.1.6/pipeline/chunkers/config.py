from pathlib import Path

SOURCE_ROOT = Path("raw_data/github_source/karpathy")
COMMITS_ROOT = Path("raw_data/commits/karpathy")
