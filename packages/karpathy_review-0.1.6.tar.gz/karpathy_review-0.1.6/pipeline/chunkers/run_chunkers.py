"""Run all chunkers in sequence and report chunk counts."""

from pathlib import Path
import json

from pipeline.chunkers import source_chunker, commit_chunker


def _count_lines(path: Path) -> int:
    if not path.exists():
        return 0
    with path.open(encoding="utf-8") as f:
        return sum(1 for line in f if line.strip())


def main() -> None:
    print("Running source chunker...")
    source_chunker.run()
    source_count = _count_lines(source_chunker.OUTPUT_PATH)
    print(f"  source chunks: {source_count}")

    print("Running commit chunker...")
    commit_chunker.run()
    commit_count = _count_lines(commit_chunker.OUTPUT_PATH)
    print(f"  commit chunks: {commit_count}")

    print(f"\nTotal chunks: {source_count + commit_count}")


if __name__ == "__main__":
    main()
