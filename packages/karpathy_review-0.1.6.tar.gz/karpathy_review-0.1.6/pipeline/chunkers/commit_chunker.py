"""Chunk commit JSON files from COMMITS_ROOT into commit_chunks.jsonl."""

from __future__ import annotations

import json
import logging
from pathlib import Path

from pipeline.chunkers.config import COMMITS_ROOT

OUTPUT_PATH = Path("raw_data/chunks/commit_chunks.jsonl")

log = logging.getLogger(__name__)


def _build_diff(files: list[dict]) -> str:
    parts = []
    for f in files:
        patch = f.get("patch", "")
        if patch:
            parts.append(f"--- {f.get('filename', '')}\n{patch}")
    return "\n\n".join(parts)


def run():
    """
    Scans commit JSON files, builds text chunks with commit message and diff,
    and writes them line-by-line as JSON to OUTPUT_PATH.
    """
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    total = 0
    with OUTPUT_PATH.open("w", encoding="utf-8") as out:
        for path in COMMITS_ROOT.rglob("*.json"):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as e:
                log.warning("skip %s: %s", path, e)
                continue
            diff = _build_diff(data.get("files", []))
            if not diff.strip(): continue
            message = data.get("message", "").strip()
            chunk = {
                "source": "github_commits",
                "repo": data.get("repo", ""),
                "sha": data.get("sha", ""),
                "type": "commit",
                "text": f"COMMIT: {message}\n\nDIFF:\n{diff}"
            }
            out.write(json.dumps(chunk) + "\n")
            total += 1
    log.info("wrote %d chunks to %s", total, OUTPUT_PATH)

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run()
