"""Chunk source files (.py, .c) from SOURCE_ROOT into source_chunks.jsonl."""

from __future__ import annotations

import ast
import json
import logging
import re
import textwrap
from pathlib import Path

from pipeline.chunkers.config import SOURCE_ROOT

OUTPUT_PATH = Path("raw_data/chunks/source_chunks.jsonl")

log = logging.getLogger(__name__)

# Matches C function definitions that start at column 0
_C_FUNC_RE = re.compile(r"^[a-zA-Z][^\n]*\(.*\)\s*\{", re.MULTILINE)


def _chunks_from_py(source: str, repo: str, filepath: str) -> list[dict]:
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        log.warning("skip %s/%s: %s", repo, filepath, exc)
        return []

    lines = source.splitlines(keepends=True)
    chunks = []

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue
        kind = "class" if isinstance(node, ast.ClassDef) else "function"
        start = node.lineno - 1
        end = node.end_lineno  # type: ignore[attr-defined]
        text = textwrap.dedent("".join(lines[start:end]))
        chunks.append({
            "source": "github_source",
            "repo": repo,
            "filepath": filepath,
            "symbol": node.name,
            "kind": kind,
            "type": "source",
            "text": text,
        })

    return chunks


def _chunks_from_c(source: str, repo: str, filepath: str) -> list[dict]:
    matches = list(_C_FUNC_RE.finditer(source))
    if not matches:
        return []

    chunks = []
    for i, match in enumerate(matches):
        start = match.start()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(source)
        text = source[start:end].strip()

        # Extract function name: first word before '('
        name_match = re.match(r"[\w\s\*]+?(\w+)\s*\(", match.group(0))
        symbol = name_match.group(1) if name_match else match.group(0)[:32]

        chunks.append({
            "source": "github_source",
            "repo": repo,
            "filepath": filepath,
            "symbol": symbol,
            "kind": "function",
            "type": "source",
            "text": text,
        })

    return chunks


def run() -> None:
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

    total = 0
    with OUTPUT_PATH.open("w", encoding="utf-8") as out:
        for src_file in SOURCE_ROOT.rglob("*"):
            if src_file.suffix not in {".py", ".c"}:
                continue
            if src_file.name.endswith(".meta.json"):
                continue

            # repo is the directory directly under SOURCE_ROOT
            try:
                rel = src_file.relative_to(SOURCE_ROOT)
            except ValueError:
                continue
            repo = rel.parts[0]
            filepath = str(rel.as_posix())

            try:
                source = src_file.read_text(encoding="utf-8", errors="replace")
            except OSError as exc:
                log.warning("skip %s: %s", src_file, exc)
                continue

            if src_file.suffix == ".py":
                chunks = _chunks_from_py(source, repo, filepath)
            else:
                chunks = _chunks_from_c(source, repo, filepath)

            for chunk in chunks:
                out.write(json.dumps(chunk) + "\n")
                total += 1

    log.info("wrote %d chunks to %s", total, OUTPUT_PATH)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run()
