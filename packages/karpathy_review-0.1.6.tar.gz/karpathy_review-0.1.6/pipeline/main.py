"""FastAPI server: serves Inngest functions and exposes a /trigger endpoint."""

from __future__ import annotations

import inngest.fast_api
import fastapi

from pipeline.inngest_client import client
from pipeline.scrapers.github_source import scrape_github_source
from pipeline.scrapers.github_commits import scrape_github_commits

app = fastapi.FastAPI(title="karpathy-review pipeline")

inngest.fast_api.serve(app, client, [scrape_github_source, scrape_github_commits])


@app.post("/trigger")
async def trigger() -> dict:
    """Fire both scraper events."""
    await client.send(
        [
            inngest.Event(name="pipeline/scrape.github.source"),
            inngest.Event(name="pipeline/scrape.github.commits"),
        ]
    )
    return {"queued": ["pipeline/scrape.github.source", "pipeline/scrape.github.commits"]}
