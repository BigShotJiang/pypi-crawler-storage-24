"""Embed source and commit chunks into ChromaDB using OpenAI text-embedding-3-small.

Reads:
  raw_data/chunks/source_chunks.jsonl
  raw_data/chunks/commit_chunks.jsonl

Writes:
  knowledge_base/chroma  (ChromaDB persistent storage, collection: karpathy)

Requires OPENAI_API_KEY (via ~/.karpathy-review/config or env).
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
import time

import chromadb
import openai
import tiktoken

from pipeline.config import get_api_key, get_kb_path
COLLECTION_NAME = "karpathy"

EMBED_MODEL = "text-embedding-3-small"

BATCH_SIZE = 100

SOURCE_CHUNKS = Path("raw_data/chunks/source_chunks.jsonl")
COMMIT_CHUNKS = Path("raw_data/chunks/commit_chunks.jsonl")

log = logging.getLogger(__name__)


def _make_id(chunk: dict, i: int) -> str:
    return f"{chunk['type']}_{i:06d}"


_MAX_TOKENS = 8000
_ENC = tiktoken.get_encoding("cl100k_base")


def _truncate(text: str) -> str:
    tokens = _ENC.encode(text, disallowed_special=())
    return _ENC.decode(tokens[:_MAX_TOKENS]) if len(tokens) > _MAX_TOKENS else text


def _embed_batch(texts: list[str], api_key: str, max_retries: int = 8) -> list[list[float]]:
    """Call OpenAI embeddings with exponential backoff on 429. Raises on 500."""
    client = openai.OpenAI(api_key=api_key)
    truncated = [_truncate(t) for t in texts]
    delay = 5.0
    for attempt in range(max_retries):
        try:
            resp = client.embeddings.create(input=truncated, model=EMBED_MODEL)
            return [item.embedding for item in resp.data]
        except openai.RateLimitError:
            log.warning("429 rate-limited — waiting %.0fs (attempt %d/%d)", delay, attempt + 1, max_retries)
            time.sleep(delay)
            delay = min(delay * 2, 120)
    raise RuntimeError(f"Embedding failed after {max_retries} retries")


def _embed_safe(
    ids: list[str],
    texts: list[str],
    metadatas: list[dict],
    api_key: str,
) -> tuple[list[str], list[str], list[dict], list[list[float]]]:
    """Embed a batch, splitting on 500 errors. Skips single bad chunks."""
    try:
        embeddings = _embed_batch(texts, api_key)
        return ids, texts, metadatas, embeddings
    except openai.InternalServerError:
        if len(texts) == 1:
            log.warning("skipping bad chunk id=%s (500 error)", ids[0])
            return [], [], [], []
        mid = len(texts) // 2
        a_ids, a_texts, a_metas, a_embs = _embed_safe(ids[:mid], texts[:mid], metadatas[:mid], api_key)
        b_ids, b_texts, b_metas, b_embs = _embed_safe(ids[mid:], texts[mid:], metadatas[mid:], api_key)
        return a_ids + b_ids, a_texts + b_texts, a_metas + b_metas, a_embs + b_embs


def _load_chunks(path: Path) -> list[dict]:
    if not path.exists():
        log.warning("%s not found, skipping", path)
        return []
    chunks = []
    with path.open(encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                chunks.append(json.loads(line))
    return chunks


def run() -> None:
    api_key = get_api_key()

    chroma_path = get_kb_path()
    chroma_path.mkdir(parents=True, exist_ok=True)
    db = chromadb.PersistentClient(path=str(chroma_path))
    collection = db.get_or_create_collection(COLLECTION_NAME)

    existing_ids = set(collection.get(include=[])["ids"])
    log.info("%d documents already in ChromaDB", len(existing_ids))

    # NOTE: wipe knowledge_base/chroma before running to start fresh with consistent IDs
    chunks = _load_chunks(SOURCE_CHUNKS) + _load_chunks(COMMIT_CHUNKS)
    all_ids = [_make_id(c, i) for i, c in enumerate(chunks)]
    pairs = [(cid, c) for cid, c in zip(all_ids, chunks) if cid not in existing_ids]
    print(f"Chunks loaded: {len(chunks)} total, {len(pairs)} new")

    embedded = 0
    for i in range(0, len(pairs), BATCH_SIZE):
        batch = pairs[i : i + BATCH_SIZE]
        ids = [cid for cid, _ in batch]
        texts = [c["text"] for _, c in batch]
        metadatas = [{k: v for k, v in c.items() if k != "text"} for _, c in batch]
        ids, texts, metadatas, embeddings = _embed_safe(ids, texts, metadatas, api_key)

        if ids:
            collection.add(
                ids=ids,
                embeddings=embeddings,
                documents=texts,
                metadatas=metadatas,
            )

        embedded += len(ids)
        if embedded % 100 == 0 or embedded == len(pairs):
            print(f"  progress: {embedded}/{len(pairs)} embedded")

    print(f"Done. Embedded {embedded} new chunks. Collection size: {collection.count()}")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run()
