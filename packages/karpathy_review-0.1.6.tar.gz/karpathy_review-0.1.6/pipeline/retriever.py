"""Query the ChromaDB knowledge base using OpenAI text-embedding-3-small."""

from __future__ import annotations

from pathlib import Path

import chromadb
import openai

from pipeline.config import get_kb_path, get_openai_key

COLLECTION_NAME = "karpathy"
EMBED_MODEL = "text-embedding-3-small"


def query(text: str, k: int = 5) -> list[dict]:
    """Embed text with OpenAI and return the top-k matching chunks.

    Returns a list of dicts with keys: text, source, repo, type,
    and symbol (for source chunks) or sha (for commit chunks).
    """
    client = openai.OpenAI(api_key=get_openai_key())
    resp = client.embeddings.create(input=[text], model=EMBED_MODEL)
    embedding = resp.data[0].embedding

    db = chromadb.PersistentClient(path=str(get_kb_path()))
    collection = db.get_collection(COLLECTION_NAME)

    results = collection.query(query_embeddings=[embedding], n_results=k)

    chunks = []
    for doc, meta in zip(results["documents"][0], results["metadatas"][0]):
        chunk = {"text": doc, **meta}
        chunks.append(chunk)

    return chunks
