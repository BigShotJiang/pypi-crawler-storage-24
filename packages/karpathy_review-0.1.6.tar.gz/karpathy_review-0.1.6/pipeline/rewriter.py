"""Rewrite engine — rewrites flagged functions in Karpathy's style."""

from __future__ import annotations

import ast
import re
import textwrap
from pathlib import Path

import openai

from pipeline.config import get_api_key
from pipeline.retriever import query as kb_query

MODEL = "gpt-4.1"

_C_FUNC_RE = re.compile(r"^[a-zA-Z][^\n]*\(.*\)\s*\{", re.MULTILINE)

SYSTEM_PROMPT = """\
You are Andrej Karpathy rewriting code.
Be terse. Remove unnecessary abstraction. Favour clarity and simplicity.
Return ONLY the rewritten function, no explanation, no markdown fences.
""".strip()

REWRITE_PROMPT = """\
Rewrite the function below in Karpathy's style. Address this issue: {comment}

## Function to rewrite
```
{function}
```

## Relevant Karpathy code for reference
{context}

Return ONLY the rewritten function, nothing else.
""".strip()


def _collect_funcs(tree: ast.Module) -> list[tuple[int, int, str]]:
    """Explicitly collect all functions and methods: (start_lineno, end_lineno, name).

    Two-level descent: top-level functions, then methods inside each ClassDef.
    Avoids relying on ast.walk's traversal order.
    """
    funcs: list[tuple[int, int, str]] = []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            funcs.append((node.lineno, node.end_lineno, node.name))  # type: ignore[attr-defined]
        elif isinstance(node, ast.ClassDef):
            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    funcs.append((item.lineno, item.end_lineno, item.name))  # type: ignore[attr-defined]
    return funcs


def _find_function_py(code: str, line: int) -> tuple[int, int, str] | None:
    """Return (start_line, end_line, text) of the innermost function/method containing `line`."""
    code = code.lstrip('\ufeff')
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None

    file_lines = code.splitlines(keepends=True)
    funcs = _collect_funcs(tree)

    def _make_result(start: int, end: int) -> tuple[int, int, str]:
        return (start, end, textwrap.dedent("".join(file_lines[start - 1 : end])))

    # Phase 1: innermost function whose span contains the line
    best: tuple[int, int] | None = None
    for start, end, _name in funcs:
        if start <= line <= end:
            if best is None or start > best[0]:
                best = (start, end)

    if best:
        return _make_result(*best)

    # Phase 2: line fell outside all spans (e.g. on a class def line due to
    # off-by-one in reviewer's relative→absolute conversion).
    # Snap forward to the nearest function that starts after the line.
    after = [(s, e) for s, e, _ in funcs if s > line]
    if after:
        return _make_result(*min(after, key=lambda x: x[0]))

    return None


def _find_function_c(code: str, line: int) -> tuple[int, int, str] | None:
    """Return (start_line, end_line, text) of the C function containing `line`."""
    matches = list(_C_FUNC_RE.finditer(code))
    for i, match in enumerate(matches):
        start_char = match.start()
        end_char = matches[i + 1].start() if i + 1 < len(matches) else len(code)
        start_line = code[:start_char].count("\n") + 1
        end_line = code[:end_char].count("\n") + 1
        if start_line <= line <= end_line:
            return start_line, end_line, code[start_char:end_char].strip()
    return None


def _build_context(hits: list[dict]) -> str:
    parts = []
    for h in hits:
        repo = h.get("repo", "")
        filepath = h.get("filepath", h.get("sha", ""))
        citation = f"{repo}/{filepath}".strip("/")
        parts.append(f"### {citation}\n```\n{h['text'][:800]}\n```")
    return "\n\n".join(parts)


def rewrite(code: str, filename: str, comments: list[dict]) -> list[dict]:
    """For each flagged line, find its function and rewrite it.

    Returns list of {line, original, rewritten}.
    """
    client = openai.OpenAI(api_key=get_api_key())
    ext = Path(filename).suffix
    results = []
    seen_ranges: set[tuple[int, int]] = set()

    for c in comments:
        line = c["line"]
        comment = c["comment"]

        if ext == ".py":
            found = _find_function_py(code, line)
        elif ext == ".c":
            found = _find_function_c(code, line)
        else:
            continue

        if not found:
            continue

        start_line, end_line, original = found
        if (start_line, end_line) in seen_ranges:
            continue
        seen_ranges.add((start_line, end_line))

        hits = kb_query(comment, k=4)
        context = _build_context(hits)

        prompt = REWRITE_PROMPT.format(
            comment=comment,
            function=original,
            context=context,
        )

        message = client.chat.completions.create(
            model=MODEL,
            max_tokens=2048,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
        )

        rewritten = message.choices[0].message.content.strip()

        results.append({
            "line": start_line,
            "end_line": end_line,
            "original": original,
            "rewritten": rewritten,
        })

    return results
