import os

import inngest
from dotenv import load_dotenv

load_dotenv()

# Dev mode: the local Inngest dev server does not verify request signatures,
# so drop the signing key from the environment before the SDK auto-reads it.
os.environ.pop("INNGEST_SIGNING_KEY", None)

client = inngest.Inngest(
    app_id="karpathy-review",
    event_key=os.environ.get("INNGEST_EVENT_KEY"),
    is_production=False,
)
