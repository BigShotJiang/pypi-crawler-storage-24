"""Core review engine — reviews code in Karpathy's voice using RAG context."""

from __future__ import annotations

import ast
import json
import os
import re
import textwrap
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import anthropic
import openai

from pipeline.config import get_api_key, get_provider
from pipeline.retriever import query as kb_query

OPENAI_MODEL = "gpt-4.1"
ANTHROPIC_MODEL = "claude-sonnet-4-20250514"
_DEBUG = os.environ.get("KR_DEBUG") == "1"

_C_FUNC_RE = re.compile(r"^[a-zA-Z][^\n]*\(.*\)\s*\{", re.MULTILINE)

VOICE_RULES = """\
Voice rules (non-negotiable):
- lowercase, no trailing punctuation on short comments
- max one sentence per comment
- never use "consider", "perhaps", "might", "you could"
- state the problem and move on — no explanation unless a citation makes it obvious
- silence on clean code
""".strip()

# Tier 1: KB has relevant source or opinionated commit chunks.
# Ground every comment in what he actually wrote or changed.
PROMPT_TIER1 = """\
## Code to review ({filename}, line {line})
```
{chunk}
```

## Karpathy's own code (what he considers clean)
{source_context}

## Karpathy's refactoring commits (what he actually criticized and changed)
{commit_context}

Based only on the patterns and decisions shown above, identify what this code does wrong by those same standards. Cite the repo/file when you reference KB code. If the examples don't surface a problem, return [].

{voice_rules}

Respond with a JSON array. Each element: {{"line": <int>, "comment": <str>, "citation": <str or null>}}.
"line" is relative to the chunk's start line shown above.
"citation": "repo/filepath" if referencing KB code, else null.
Respond with ONLY the JSON array, no other text.
""".strip()

# Tier 2: KB returned nothing relevant. Apply universal principles cold.
PROMPT_TIER2 = """\
## Code to review ({filename}, line {line})
```
{chunk}
```

No relevant KB examples were found. Review using these universal principles only — do not invent KB citations:
- function over 20 lines → "too long. split it."
- magic number → "name it."
- thin wrapper that just calls something else → "just inline this."
- unnecessary class (no state, one method) → "why is this a class."
- verbose naming → "too long. shorten."
- dead code / unused variable → "remove."
- over-engineered logic when a simpler form exists → "too clever."
If none of these apply, return [].

{voice_rules}

Respond with a JSON array. Each element: {{"line": <int>, "comment": <str>, "citation": null}}.
"line" is relative to the chunk's start line shown above.
Respond with ONLY the JSON array, no other text.
""".strip()


def _chunks_from_py(source: str, filename: str) -> list[dict]:
    source = source.lstrip('\ufeff')
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return [{"symbol": "<module>", "line": 1, "text": source}]

    lines = source.splitlines(keepends=True)

    def _chunk(node: ast.AST) -> dict:
        start = node.lineno - 1  # type: ignore[attr-defined]
        end = node.end_lineno    # type: ignore[attr-defined]
        text = textwrap.dedent("".join(lines[start:end]))
        return {"symbol": node.name, "line": node.lineno, "text": text}  # type: ignore[attr-defined]

    chunks = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            # always emit individual functions/methods
            chunks.append(_chunk(node))
        elif isinstance(node, ast.ClassDef):
            # emit class only if it has no methods (e.g. a dataclass with just fields)
            has_methods = any(
                isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef))
                for child in ast.walk(node)
                if child is not node
            )
            if not has_methods:
                chunks.append(_chunk(node))

    return chunks


def _chunks_from_c(source: str, filename: str) -> list[dict]:
    matches = list(_C_FUNC_RE.finditer(source))
    if not matches:
        return [{"symbol": "<file>", "line": 1, "text": source}]

    lines = source.splitlines()
    chunks = []
    for i, match in enumerate(matches):
        start = match.start()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(source)
        text = source[start:end].strip()
        line_no = source[:start].count("\n") + 1
        name_match = re.match(r"[\w\s\*]+?(\w+)\s*\(", match.group(0))
        symbol = name_match.group(1) if name_match else match.group(0)[:32]
        chunks.append({"symbol": symbol, "line": line_no, "text": text})

    return chunks


def _split_chunks(code: str, filename: str) -> list[dict]:
    ext = Path(filename).suffix
    if ext == ".py":
        return _chunks_from_py(code, filename)
    elif ext == ".c":
        return _chunks_from_c(code, filename)
    else:
        return [{"symbol": "<file>", "line": 1, "text": code}]


def _build_context(hits: list[dict]) -> str:
    parts = []
    for h in hits:
        repo = h.get("repo", "")
        filepath = h.get("filepath", h.get("sha", ""))
        citation = f"{repo}/{filepath}".strip("/")
        parts.append(f"### {citation}\n```\n{h['text'][:800]}\n```")
    return "\n\n".join(parts)


def _build_commit_context(hits: list[dict]) -> str:
    """Extract commit message lines from commit-type hits."""
    parts = []
    for h in hits:
        if h.get("type") != "commit":
            continue
        sha = h.get("sha", "")
        # commit text is "COMMIT: {msg}\n\nDIFF:\n..." — grab just the message
        first_line = h["text"].splitlines()[0] if h["text"] else ""
        parts.append(f"- {first_line}" + (f" ({sha[:7]})" if sha else ""))
    return "\n".join(parts) if parts else "(none in these results)"


def _is_tier1(source_hits: list[dict], commit_hits: list[dict]) -> bool:
    """Tier 1 if we have any source chunks or opinionated commit chunks."""
    if source_hits:
        return True
    return any(h.get("source") == "github_commits_opinionated" for h in commit_hits)


def _parse_comments(raw: str) -> list[dict]:
    raw = raw.strip()
    # Strip markdown code fences if the model wrapped it
    if raw.startswith("```"):
        raw = re.sub(r"^```[a-z]*\n?", "", raw)
        raw = re.sub(r"\n?```$", "", raw)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return []


def _call_llm(prompt: str, provider: str, api_key: str) -> str:
    """Send prompt to the active provider and return the raw text response."""
    if provider == "anthropic":
        client = anthropic.Anthropic(api_key=api_key)
        msg = client.messages.create(
            model=ANTHROPIC_MODEL,
            max_tokens=1024,
            messages=[{"role": "user", "content": prompt}],
        )
        return msg.content[0].text
    else:
        client = openai.OpenAI(api_key=api_key)
        msg = client.chat.completions.create(
            model=OPENAI_MODEL,
            max_tokens=1024,
            messages=[{"role": "user", "content": prompt}],
        )
        return msg.choices[0].message.content


_OPENER_PROMPT = """\
Here are the issues found in a code review:

{issues}

Write a single casual lowercase sentence (max 10 words, no ending punctuation) summarizing what's wrong — like "ok so the attention implementation has some issues" or "few things in the forward pass" or "looks mostly fine, one thing". Sound like a person glancing at code. Only the sentence, nothing else.
""".strip()


def _generate_opener(comments: list[dict], provider: str, api_key: str) -> str:
    if not comments:
        return "looks fine"
    issues = "\n".join(f"- L{c['line']}: {c['comment']}" for c in comments)
    prompt = _OPENER_PROMPT.format(issues=issues)
    return _call_llm(prompt, provider, api_key).strip().rstrip(".")


def _review_chunk(chunk: dict, filename: str, provider: str, api_key: str) -> list[dict]:
    """Review a single chunk and return offset-adjusted comments."""
    hits = kb_query(chunk["text"], k=6)
    source_hits = [h for h in hits if h.get("type") == "source"]
    commit_hits = [h for h in hits if h.get("type") == "commit"]
    tier1 = _is_tier1(source_hits, commit_hits)

    if _DEBUG:
        print(f"\n[debug] chunk: {chunk['symbol']} (line {chunk['line']}) tier={'1' if tier1 else '2'}")
        print(f"[debug] chunk text:\n{chunk['text']}\n")
        print("[debug] kb hits:")
        for h in hits:
            score = h.get("distance", "?")
            print(f"  type={h.get('type','')} src={h.get('source','')} repo={h.get('repo','')} score={score} text={h['text'][:100]!r}")

    if tier1:
        source_context = _build_context(source_hits)
        commit_context = _build_commit_context(commit_hits)
        prompt = PROMPT_TIER1.format(
            filename=filename,
            line=chunk["line"],
            chunk=chunk["text"],
            source_context=source_context or "(none)",
            commit_context=commit_context,
            voice_rules=VOICE_RULES,
        )
    else:
        prompt = PROMPT_TIER2.format(
            filename=filename,
            line=chunk["line"],
            chunk=chunk["text"],
            voice_rules=VOICE_RULES,
        )

    if _DEBUG:
        print(f"\n[debug] prompt:\n{prompt}\n")

    raw = _call_llm(prompt, provider, api_key)
    comments = _parse_comments(raw)

    # Offset line numbers to be absolute within the file
    for c in comments:
        c["line"] = chunk["line"] + c.get("line", 1) - 1
    return comments


def review(code: str, filename: str) -> tuple[str, list[dict]]:
    """Review code and return (opener, comments) where opener is a one-line summary."""
    provider = get_provider()
    api_key = get_api_key()
    chunks = _split_chunks(code, filename)

    # Review all chunks in parallel, preserving original order
    results: list[list[dict]] = [[] for _ in chunks]
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {
            pool.submit(_review_chunk, chunk, filename, provider, api_key): i
            for i, chunk in enumerate(chunks)
        }
        for future in as_completed(futures):
            results[futures[future]] = future.result()

    all_comments = [c for chunk_comments in results for c in chunk_comments]
    opener = _generate_opener(all_comments, provider, api_key)
    return opener, all_comments
