"""karpathy-review CLI — review code in Karpathy's voice."""

from __future__ import annotations

import argparse
import difflib
import os
import sys
from pathlib import Path

from rich.columns import Columns
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm
from rich.syntax import Syntax
from rich.text import Text

from pipeline.config import CONFIG_FILE, _save_config, get_api_key, get_openai_key

console = Console()


def _apply_rewrites(path: Path, rewrites: list[dict]) -> None:
    """Show unified diff for each rewrite and apply confirmed changes."""
    for rw in sorted(rewrites, key=lambda r: r["line"], reverse=True):
        original_lines = rw["original"].splitlines(keepends=True)
        rewritten_lines = rw["rewritten"].splitlines(keepends=True)

        diff = list(difflib.unified_diff(
            original_lines,
            rewritten_lines,
            fromfile=f"{path.name} (original)",
            tofile=f"{path.name} (rewritten)",
        ))

        if not diff:
            continue

        diff_text = "".join(diff)
        ext = path.suffix.lstrip(".") or "text"
        console.print()
        console.print(
            Syntax(diff_text, "diff", theme="monokai", line_numbers=False),
            Panel.fit(
                f"[dim]function at L{rw['line']}[/dim]",
                border_style="dim",
            ),
        )

        if not Confirm.ask("[dim]apply?[/dim]", default=False):
            console.print("  [dim]skipped[/dim]")
            continue

        file_lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
        start = rw["line"] - 1
        end = rw["end_line"]
        file_lines[start:end] = rewritten_lines
        path.write_text("".join(file_lines), encoding="utf-8")
        console.print("  [green]applied[/green]")


def _review_file(path: Path) -> tuple[str, list[dict]]:
    """Review a single file and return (opener, comments). Returns ('', []) on failure."""
    from pipeline.reviewer import review
    try:
        code = path.read_text(encoding="utf-8")
    except OSError as e:
        console.print(f"  [red]could not read {path}: {e}[/red]")
        return "", []

    try:
        return review(code, path.name)
    except Exception as e:
        console.print(f"  [red]skipping {path}: {e}[/red]")
        return "", []


def _collect_files(path: Path) -> list[Path]:
    """Return all .py and .c files under path (or path itself if a file)."""
    if path.is_file():
        return [path]
    return sorted(
        p for p in path.rglob("*")
        if p.suffix in {".py", ".c"} and p.is_file()
    )


def _ensure_keys() -> None:
    """On first run (no config file), ask which provider to use then save keys."""
    kr_provider = os.environ.get("KR_PROVIDER", "").lower()

    if not CONFIG_FILE.exists() and not kr_provider:
        console.print(Panel(
            "[bold]which AI provider?[/bold]\n\n"
            "  [cyan][1][/cyan] OpenAI   [dim]gpt-4.1[/dim]\n"
            "  [cyan][2][/cyan] Anthropic [dim]claude-sonnet-4-20250514[/dim]",
            border_style="dim",
            padding=(1, 2),
        ))
        choice = console.input("[dim]choice [1/2]: [/dim]").strip()
        if choice == "2":
            kr_provider = "anthropic"
        else:
            kr_provider = "openai"
        os.environ["KR_PROVIDER"] = kr_provider
        _save_config("KR_PROVIDER", kr_provider)

    get_api_key()

    if os.environ.get("KR_PROVIDER", kr_provider) == "anthropic":
        console.print("[dim]embeddings always use OpenAI — also need your OpenAI key[/dim]")
        get_openai_key()


def _print_file_header(fp: Path) -> None:
    console.print()
    console.rule(f"[dim]{fp}[/dim]", style="dim")


def _print_comment(c: dict, kb_chunks: dict[str, str]) -> None:
    line_label = Text(f"L{c['line']}", style="yellow bold")
    comment_text = Text(f"  {c['comment']}", style="white")
    console.print(line_label, comment_text)

    citation = c.get("citation")
    if citation and citation in kb_chunks:
        snippet = kb_chunks[citation]
        console.print(
            Syntax(
                snippet[:600],
                "python",
                theme="monokai",
                line_numbers=False,
                background_color="default",
            ),
            style="dim",
        )
        console.print(f"  [dim]— {citation}[/dim]")
    elif citation:
        console.print(f"  [dim]— {citation}[/dim]")


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="karpathy-review",
        description="Review code in Karpathy's voice.",
    )
    parser.add_argument("file", help="Path to a file or directory to review")
    parser.add_argument(
        "--rewrite",
        action="store_true",
        help="After review, offer to rewrite flagged functions",
    )
    args = parser.parse_args()

    path = Path(args.file)
    if not path.exists():
        console.print(f"[red]not found: {path}[/red]")
        sys.exit(1)

    _ensure_keys()

    console.print(Panel(
        "[dim]andrej is reviewing your code...[/dim]",
        border_style="dim",
        padding=(0, 2),
    ))

    files = _collect_files(path)
    if not files:
        console.print("[dim]no .py or .c files found[/dim]")
        sys.exit(0)

    from pipeline.rewriter import rewrite

    all_file_comments: list[tuple[Path, str, list[dict]]] = []

    for fp in files:
        _print_file_header(fp)
        opener, comments = _review_file(fp)
        if not comments:
            console.print(f"  [dim]{opener}[/dim]")
            continue
        console.print(f"  [italic dim]{opener}[/italic dim]")
        console.print()
        for c in comments:
            _print_comment(c, {})
        all_file_comments.append((fp, fp.read_text(encoding="utf-8"), comments))

    if not all_file_comments:
        return

    console.print()
    if not Confirm.ask("[bold]want andrej to take over?[/bold]", default=False):
        return

    for fp, code, comments in all_file_comments:
        console.print(f"\n[dim]rewriting {fp} …[/dim]")
        rewrites = rewrite(code, fp.name, comments)
        if not rewrites:
            console.print("  [dim]nothing to rewrite[/dim]")
            continue
        _apply_rewrites(fp, rewrites)


if __name__ == "__main__":
    main()
