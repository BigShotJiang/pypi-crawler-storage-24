def main():
    print("Hello from karpathy-review!")


if __name__ == "__main__":
    main()
