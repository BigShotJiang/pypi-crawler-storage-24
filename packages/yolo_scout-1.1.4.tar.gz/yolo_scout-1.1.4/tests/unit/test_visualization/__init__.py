"""Visualization module tests."""
