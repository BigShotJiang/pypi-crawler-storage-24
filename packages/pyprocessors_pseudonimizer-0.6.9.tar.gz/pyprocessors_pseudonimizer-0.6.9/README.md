# pyprocessors-pseudonimizer

Pseudonymization processor based on [Microsoft Presidio](https://microsoft.github.io/presidio/anonymizer/).

## Requirements

- Python 3.12+
- [uv](https://github.com/astral-sh/uv) for package management

## Installation

```bash
pip install pyprocessors-pseudonimizer
```

Or with uv:

```bash
uv add pyprocessors-pseudonimizer
```

## Development setup

```bash
uv sync --extra test
```

## Running tests

```bash
uv run pytest
```

## Linting

```bash
uv run ruff check .
uv run ruff format --check .
```

## Publishing

```bash
uv build
uv publish
```

## Operators

The processor supports the following anonymization operators:

| Operator   | Description                                              |
|------------|----------------------------------------------------------|
| `mask`     | Replaces characters with a masking character             |
| `replace`  | Replaces the entity with a fixed value                   |
| `redact`   | Removes the entity completely from the text              |
| `label`    | Replaces the entity with its label name (e.g. `<person>`) |
| `identity` | Leaves the entity unchanged                              |
| `faker`    | Replaces the entity with a fake value from [Faker](https://faker.readthedocs.io/) |
