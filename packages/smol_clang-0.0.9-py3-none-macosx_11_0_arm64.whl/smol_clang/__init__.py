"""Hermetic LLVM clang+lld toolchain archives."""

__version__ = "0.0.9"

LLVM_VERSION = "22.1"

import importlib.resources
from pathlib import Path


def get_archive_path() -> Path:
    """Return the path to this platform's smol-clang archive."""
    data = importlib.resources.files("smol_clang") / "data"
    archives = [p for p in data.iterdir() if p.name.endswith(".tar.xz")]
    if not archives:
        raise FileNotFoundError("No archive found in smol_clang/data/")
    return Path(str(archives[0]))
