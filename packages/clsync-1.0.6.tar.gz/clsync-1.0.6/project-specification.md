# claude-sync — Implementation Specification

This document is the complete implementation specification for `claude-sync`. It consists of two deliverables: a **Python CLI client** and a **GitLab CI pipeline** with a synthesis script. Implement them in order as listed.

## System Overview

`claude-sync` synchronizes Claude Code knowledge across multiple development machines. Each machine pushes snapshots of its Claude Code artifacts to a shared GitLab repository. A GitLab CI pipeline runs an LLM-based synthesis (via Anthropic API) to merge the knowledge from all machines into a single consolidated version. Machines then pull and apply the consolidated result.

### Two-layer memory model

Claude Code persists knowledge in two layers, analogous to human short-term and long-term memory:

| Layer | Location | Nature | Sync strategy |
|-------|----------|--------|---------------|
| **Short-term memory** | `~/.claude/projects/{slug}/memory/` | Auto-written by Claude during sessions. Raw, potentially noisy. | Propagate latest (no synthesis) |
| **Long-term memory** | `{project}/.claude/CLAUDE.md` and `~/.claude/CLAUDE.md` | Curated, authoritative project knowledge. Loaded at session start. | Full CI synthesis pipeline |
| **Settings** | `~/.claude/settings.json` | User preferences, keybindings. | Propagate latest (no synthesis) |

The `bootstrap` command bridges the two layers: it reads short-term memory (plus session summaries) and distills it into a curated CLAUDE.md — "consolidating" ephemeral session notes into durable project knowledge. This can be run once to adopt the CLAUDE.md convention, or periodically to fold new learnings into the long-term memory.

### Components

The system has three components:
1. **Client CLI** (`claude-sync`) — installed on each dev machine, handles snapshot/push/pull/apply/bootstrap
2. **Pipeline** (`pipeline/synthesize.py`) — lives inside the GitLab sync repo, runs on CI
3. **Bootstrap** (client-side, optional) — one-time or periodic CLAUDE.md generation using the Anthropic API directly

## Repository Layout

The GitLab sync repo has this structure. The client CLI is a separate pip-installable package.

```
claude-knowledge-sync/                  # ← the GitLab repo
├── .gitlab-ci.yml
├── machines/                           # raw snapshots, one subdir per machine
│   ├── desktop/
│   │   ├── global/
│   │   │   ├── CLAUDE.md              # global instructions (if exists)
│   │   │   └── settings.json          # Claude Code settings
│   │   └── projects/
│   │       └── {project-name}/
│   │           ├── CLAUDE.md          # project instructions (if exists)
│   │           └── memory/            # Claude Code auto-memory
│   │               ├── MEMORY.md
│   │               └── {topic}.md
│   └── laptop/
│       └── ...                        # same structure
├── consolidated/                       # synthesis output
│   ├── global/
│   │   ├── CLAUDE.md
│   │   └── settings.json
│   └── projects/
│       └── {project-name}/
│           ├── CLAUDE.md
│           └── memory/
│               ├── MEMORY.md
│               └── {topic}.md
├── meta/
│   ├── sync-log.json                   # append-only log of synthesis runs
│   └── last-synthesis.json             # hashes of inputs at last synthesis
└── pipeline/
    ├── synthesize.py                   # main entry point for CI job
    ├── models.py                       # Pydantic models (shared types)
    ├── requirements.txt                # anthropic, pydantic
    └── prompts/
        ├── synthesize_claude_md.txt    # prompt template for CLAUDE.md merge
        └── synthesize_critic.txt       # prompt template for critic/hallucination check
```

The client CLI package:

```
claude-sync/                            # ← separate repo, pip-installable
├── pyproject.toml
├── README.md
├── project-specification.md            # this file
├── src/
│   └── claude_sync/
│       ├── __init__.py
│       ├── cli.py                      # typer CLI entry point
│       ├── config.py                   # config loading + validation
│       ├── claude_paths.py             # Claude Code path/slug resolution
│       ├── snapshot.py                 # local artifacts → repo machines/{id}/
│       ├── apply.py                    # consolidated/ → local artifacts
│       ├── bootstrap.py               # generate CLAUDE.md from existing artifacts
│       ├── scaffold.py                 # scaffold CI config into new sync repos
│       ├── git_ops.py                  # git wrapper (pull, push, commit)
│       ├── gitlab_api.py              # trigger pipeline, poll status
│       ├── lock.py                     # Claude Code process detection
│       ├── models.py                   # Pydantic models
│       └── templates/                  # template files for scaffold_sync_repo()
│           ├── gitlab-ci.yml
│           ├── gitignore
│           └── pipeline/
│               ├── models.py
│               ├── requirements.txt
│               ├── synthesize.py
│               └── prompts/
│                   ├── synthesize_claude_md.txt
│                   └── synthesize_critic.txt
└── tests/
    ├── test_snapshot.py
    ├── test_apply.py
    ├── test_bootstrap.py
    ├── test_claude_paths.py
    ├── test_config.py
    ├── test_git_ops.py
    ├── test_gitlab_api.py
    ├── test_lock.py
    ├── test_scaffold.py
    ├── test_synthesize.py
    └── fixtures/
        ├── machine_a/
        │   └── global/
        │       └── CLAUDE.md
        └── machine_b/
            └── global/
                └── CLAUDE.md
```

---

## Part 1: Client CLI

### 1.1 `pyproject.toml`

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "claude-sync"
version = "0.1.0"
description = "Sync Claude Code knowledge across machines via GitLab CI"
requires-python = ">=3.11"
dependencies = [
    "typer>=0.12.0",
    "pydantic>=2.0",
    "tomli>=2.0",
    "tomli-w>=1.0",
    "gitpython>=3.1.40",
    "httpx>=0.27.0",
    "rich>=13.0",
]

[project.optional-dependencies]
bootstrap = ["anthropic>=0.40.0"]
dev = ["pytest>=8.0", "anthropic>=0.40.0"]

[project.scripts]
claude-sync = "claude_sync.cli:app"
```

### 1.2 `src/claude_sync/models.py`

Define these Pydantic models:

```python
from pydantic import BaseModel
from pathlib import Path

class ClientConfig(BaseModel):
    machine_id: str

class GitLabConfig(BaseModel):
    url: str                                    # e.g. "https://gitlab.hahtse.de"
    project_id: int
    trigger_token: str = ""                     # pipeline trigger token
    access_token: str = ""                      # personal access token (read_api scope)

class RepoConfig(BaseModel):
    local_path: Path                            # local clone of sync repo

class SafetyConfig(BaseModel):
    backup_before_apply: bool = True

class ProjectsConfig(BaseModel):
    paths: list[Path] = []
    auto_discover: bool = False
    discover_roots: list[Path] = []
    discover_max_depth: int = 2                 # max directory depth to scan for .claude/

class Config(BaseModel):
    client: ClientConfig
    gitlab: GitLabConfig
    repo: RepoConfig
    projects: ProjectsConfig = ProjectsConfig()
    safety: SafetyConfig = SafetyConfig()

class SyncLogEntry(BaseModel):
    timestamp: str                              # ISO 8601
    scopes_synthesized: list[str]               # e.g. ["global", "projects/my-app"]
    machine_inputs: dict[str, dict[str, str]]   # machine_id → {scope → sha256}

class LastSynthesis(BaseModel):
    last_run: str                               # ISO 8601
    input_hashes: dict[str, dict[str, str]]     # scope → {machine_id → sha256}
```

### 1.3 `src/claude_sync/claude_paths.py`

Maps project filesystem paths to Claude Code's internal storage structure. Claude Code stores per-project data under `~/.claude/projects/{slug}/` where the slug is derived deterministically from the project's absolute path.

```python
from pathlib import Path

def project_slug(path: Path) -> str:
    """
    Convert a project filesystem path to Claude Code's internal slug.

    The slug is the absolute path, lowercased, with ':' and path separators
    replaced by '-'. This matches Claude Code's own directory naming under
    ~/.claude/projects/.

    Examples:
        C:\\dev\\claudesync       → c--dev-claudesync
        /home/user/dev/project   → -home-user-dev-project
    """
    return str(path.resolve()).lower().replace(":", "-").replace("\\", "-").replace("/", "-")

def claude_project_dir(project_path: Path) -> Path:
    """Return ~/.claude/projects/{slug}/ for a given project path."""
    return Path.home() / ".claude" / "projects" / project_slug(project_path)

def claude_memory_dir(project_path: Path) -> Path:
    """Return ~/.claude/projects/{slug}/memory/ for a given project path."""
    return claude_project_dir(project_path) / "memory"

def claude_sessions_index(project_path: Path) -> Path:
    """Return ~/.claude/projects/{slug}/sessions-index.json for a given project path."""
    return claude_project_dir(project_path) / "sessions-index.json"
```

**Important:** The slug derivation must match Claude Code's own algorithm. If Claude Code changes its naming scheme in a future version, this function must be updated to match. The current algorithm was reverse-engineered from observed directory names on Windows (`C:\dev\claudesync` → `c--dev-claudesync`).

### 1.4 `src/claude_sync/config.py`

- Config file location: `~/.claude-sync/config.toml`
- Load with `tomli`, validate with `Config` model
- Provide `load_config() -> Config` function
- Provide `save_config(config: Config)` function using `tomli_w`
- Provide `init_config(machine_id: str, gitlab_url: str, project_id: int, repo_local_path: Path, trigger_token: str = "", access_token: str = "")` that creates the config file and directory if they don't exist
- If config file does not exist, raise a clear error telling the user to run `claude-sync init`

### 1.5 `src/claude_sync/git_ops.py`

Wrapper around `git.Repo` from GitPython. All operations work on the sync repo clone at `config.repo.local_path`.

Implement these functions:

```python
def ensure_repo(config: Config) -> git.Repo:
    """Open the repo at config.repo.local_path. Raise error if not a git repo."""

def pull_rebase(repo: git.Repo) -> None:
    """git pull --rebase origin main"""

def commit_and_push(repo: git.Repo, message: str) -> bool:
    """
    Stage all changes, commit with message, push to origin main.
    Return True if there were changes to commit, False if working tree was clean.
    """

def has_changes(repo: git.Repo) -> bool:
    """Check if there are staged or unstaged changes."""
```

### 1.6 `src/claude_sync/snapshot.py`

Handles copying local Claude Code artifacts into the sync repo under `machines/{machine_id}/`.

```python
def snapshot(config: Config) -> list[str]:
    """
    Copy Claude Code artifacts from local machine to the sync repo.
    Returns list of scopes that were updated (e.g. ["global", "projects/my-app"]).

    Global artifacts:
    1. If ~/.claude/CLAUDE.md exists → {repo}/machines/{id}/global/CLAUDE.md
    2. If ~/.claude/settings.json exists → {repo}/machines/{id}/global/settings.json

    Per-project artifacts (for each registered project):
    1. If {project}/.claude/CLAUDE.md exists → {repo}/machines/{id}/projects/{name}/CLAUDE.md
    2. If ~/.claude/projects/{slug}/memory/ exists → copy all files to
       {repo}/machines/{id}/projects/{name}/memory/
       where {slug} is computed via claude_paths.project_slug(project_path)

    Compute SHA-256 of source and destination files. Skip copy if hashes match.
    """
```

If `config.projects.auto_discover` is True, scan each directory in `config.projects.discover_roots` up to `config.projects.discover_max_depth` levels deep for subdirectories containing a `.claude/` directory (not necessarily `.claude/CLAUDE.md` — a project may have Claude Code data without a CLAUDE.md file). Deduplicate by resolved absolute path.

### 1.7 `src/claude_sync/apply.py`

Handles applying consolidated results from the sync repo back to the local machine.

```python
def apply_consolidated(config: Config, skip_scopes: set[str] = set()) -> list[str]:
    """
    Copy consolidated artifacts from sync repo to local machine.
    Returns list of scopes that were applied.

    Global:
    1. Skip if "global" is in skip_scopes
    2. Copy {repo}/consolidated/global/CLAUDE.md to ~/.claude/CLAUDE.md
       (with backup if configured)
    3. Copy {repo}/consolidated/global/settings.json to ~/.claude/settings.json
       (with backup if configured)

    Per-project:
    1. Skip if scope "projects/{name}" is in skip_scopes
    2. Find the matching local project in config.projects.paths (by dir name)
       If no matching local project found, print a warning and skip.
    3. If config.safety.backup_before_apply:
       - Back up current local .claude/CLAUDE.md to .claude/backups/{ISO-timestamp}/CLAUDE.md
    4. Copy {repo}/consolidated/projects/{name}/CLAUDE.md to {project}/.claude/CLAUDE.md
    5. Copy {repo}/consolidated/projects/{name}/memory/ to
       ~/.claude/projects/{slug}/memory/
       where {slug} is computed via claude_paths.project_slug(project_path)
    """

def check_large_diff(local_file: Path, consolidated_file: Path) -> bool:
    """
    Compare local and consolidated file. Return True if more than 50%
    of lines differ (simple line-based diff). Used to trigger confirmation prompt.
    """
```

### 1.8 `src/claude_sync/lock.py`

Detect whether Claude Code is currently running.

```python
import subprocess
import platform

def is_claude_code_running() -> bool:
    """
    Check if a Claude Code process is currently running.

    On Windows: use 'tasklist' and look for 'claude' in process names.
    On Linux: use 'pgrep -f claude' or check /proc.

    Return True if Claude Code appears to be running.
    """
```

This is a best-effort check. It should not raise exceptions — return False on any error.

### 1.9 `src/claude_sync/gitlab_api.py`

Interact with the GitLab API to trigger pipelines and check their status.

```python
import httpx
import time

def trigger_pipeline(config: Config) -> int:
    """
    Trigger the synthesis pipeline via GitLab API.

    POST {config.gitlab.url}/api/v4/projects/{config.gitlab.project_id}/trigger/pipeline
    Form data: token={trigger_token}, ref=main

    The trigger token is read from config.gitlab.trigger_token.

    Return the pipeline ID from the response.
    Raise on HTTP errors with clear error message.
    """

def get_pipeline_status(config: Config, pipeline_id: int) -> str:
    """
    GET {config.gitlab.url}/api/v4/projects/{config.gitlab.project_id}/pipelines/{pipeline_id}

    Authenticate using config.gitlab.access_token via the header PRIVATE-TOKEN.
    Trigger tokens do not have API read access.

    Return the pipeline status string (e.g. "pending", "running", "success", "failed").
    Raise with a clear message if the access token is not configured.
    """

def wait_for_pipeline(config: Config, pipeline_id: int, timeout: int = 300, poll_interval: int = 10) -> str:
    """
    Poll pipeline status until it reaches a terminal state (success, failed,
    canceled) or timeout is reached.

    Print status updates to console via rich.

    Return final status string. Raise on timeout.
    """

def get_failed_job_log(config: Config, pipeline_id: int) -> str | None:
    """
    Fetch the log of the first failed job in the pipeline.
    Returns last 50 lines of the log, or None if unavailable.
    """

def _diagnose_log(log: str) -> str | None:
    """Return a human-readable hint if a known failure pattern is found."""
```

Known failure patterns detected by `_diagnose_log`:
- Push access denied (`not allowed to push`, `403` + `push`) → hint to enable Git push in CI/CD Token Access
- API key issues (`ANTHROPIC_API_KEY`, `AuthenticationError`, `invalid x-api-key`) → hint to add CI/CD variable

### 1.10 `src/claude_sync/scaffold.py`

Scaffolds CI config and pipeline scripts into a new sync repo. Called automatically by `init` after config creation.

```python
from importlib.resources import files
from pathlib import Path

_TEMPLATE_FILES: list[tuple[str, str]] = [
    (".gitlab-ci.yml", "gitlab-ci.yml"),
    (".gitignore", "gitignore"),
    ("pipeline/models.py", "pipeline/models.py"),
    ("pipeline/requirements.txt", "pipeline/requirements.txt"),
    ("pipeline/synthesize.py", "pipeline/synthesize.py"),
    ("pipeline/prompts/synthesize_claude_md.txt", "pipeline/prompts/synthesize_claude_md.txt"),
    ("pipeline/prompts/synthesize_critic.txt", "pipeline/prompts/synthesize_critic.txt"),
]

def scaffold_sync_repo(repo_path: Path) -> list[str]:
    """
    Copy CI config and pipeline scripts into the sync repo for any files not already present.
    Returns a list of relative paths that were written.

    Template files are stored in src/claude_sync/templates/ and accessed via
    importlib.resources. Files whose names start with "." are stored without the
    dot prefix to avoid build backend issues with dotfiles.
    """
```

### 1.11 `src/claude_sync/bootstrap.py`

Generates CLAUDE.md files from existing Claude Code artifacts (memory files, session summaries) using the Anthropic API directly on the client machine. This is the only client-side module that calls the Anthropic API.

Requires the `bootstrap` optional dependency: `pip install claude-sync[bootstrap]`.

```python
import json
from pathlib import Path

import anthropic

from claude_sync.claude_paths import claude_memory_dir, claude_sessions_index

MODEL = "claude-sonnet-4-20250514"
MAX_TOKENS = 8192

def gather_project_context(project_path: Path) -> dict:
    """
    Collect all available context for a project.

    Returns dict with keys (all optional, may be empty):
    - "memory_files": dict[str, str]  — filename → content from ~/.claude/projects/{slug}/memory/
    - "session_summaries": list[str]  — summary strings from sessions-index.json
    - "existing_claude_md": str | None — content of {project}/.claude/CLAUDE.md if it exists

    If no sources found at all, returns empty dict.
    """

def gather_global_context(project_paths: list[Path]) -> dict:
    """
    Collect cross-project context for generating a global CLAUDE.md.

    Returns dict with keys:
    - "all_memory_files": dict[str, dict[str, str]]  — project_name → {filename → content}
    - "all_session_summaries": dict[str, list[str]]   — project_name → [summaries]
    - "settings": str | None — content of ~/.claude/settings.json
    - "existing_claude_md": str | None — content of ~/.claude/CLAUDE.md if it exists
    """

def build_bootstrap_prompt(context: dict, scope: str) -> str:
    """
    Build the prompt for generating a CLAUDE.md from gathered context.

    scope is either "global" or "projects/{name}".

    The prompt instructs Claude to:
    1. Synthesize the accumulated memory files and session summaries
       into a well-structured CLAUDE.md
    2. Extract durable knowledge: coding conventions, project architecture,
       key decisions, tool preferences, recurring patterns
    3. Discard ephemeral information: in-progress tasks, session-specific
       context, temporary state
    4. For global scope: identify cross-project patterns and user preferences
    5. For project scope: focus on project-specific knowledge
    6. Output ONLY the markdown content, no preamble, no code fences
    """

def generate_claude_md(context: dict, scope: str, api_key: str) -> str | None:
    """
    Call the Anthropic API to generate a CLAUDE.md from context.

    Returns the generated content, or None if context is empty / generation fails.
    """

def bootstrap_project(project_path: Path, api_key: str) -> str | None:
    """
    Generate a CLAUDE.md for a single project.

    1. gather_project_context(project_path)
    2. If no sources found, return None
    3. generate_claude_md(context, f"projects/{project_path.name}", api_key)
    4. Write result to {project_path}/.claude/CLAUDE.md
    5. Return the generated content
    """

def bootstrap_global(project_paths: list[Path], api_key: str) -> str | None:
    """
    Generate a global ~/.claude/CLAUDE.md.

    1. gather_global_context(project_paths)
    2. If no sources found, return None
    3. generate_claude_md(context, "global", api_key)
    4. Write result to ~/.claude/CLAUDE.md
    5. Return the generated content
    """
```

The bootstrap prompt template lives at `src/claude_sync/prompts/bootstrap.txt`:

```
You are analyzing Claude Code session artifacts to produce a CLAUDE.md file.

CLAUDE.md is a project knowledge file loaded by Claude Code at the start of every session.
It should contain durable, actionable knowledge: coding conventions, architectural decisions,
tool configurations, workflow preferences, and key project constraints.

You will receive:
1. MEMORY FILES — notes Claude wrote during previous sessions (short-term memory)
2. SESSION SUMMARIES — one-line descriptions of past conversations

{CONTEXT_SECTIONS}

Produce a well-structured CLAUDE.md that:
- Extracts durable knowledge and recurring patterns from the source material
- Discards ephemeral information (in-progress tasks, session-specific context, temporary state)
- Uses imperative, concise, developer-focused language
- Groups related knowledge under logical markdown headers
- Does NOT invent information beyond what is present in the sources
- Does NOT include meta-commentary about the generation process

{SCOPE_INSTRUCTION}

Output ONLY the markdown content. No preamble, no code fences, no explanation.
```

Where `{SCOPE_INSTRUCTION}` is either:
- For project scope: `"Focus on knowledge specific to this project: its architecture, conventions, tooling, and key decisions."`
- For global scope: `"Focus on cross-project patterns: your user's general coding style, preferred tools, workflow habits, and environment setup."`

### 1.12 `src/claude_sync/cli.py`

Typer-based CLI. Use `rich` for console output.

```python
import typer
app = typer.Typer(name="claude-sync", help="Sync Claude Code knowledge across machines")
```

Implement these commands:

**`init`**
```
claude-sync init --machine-id TEXT --gitlab-url TEXT --project-id INT --repo-path PATH [--trigger-token TEXT] [--access-token TEXT]
```
- Create `~/.claude-sync/config.toml` with provided values
- If `--machine-id` is not provided, read the system hostname and prompt: `No --machine-id given. Use "{hostname}"? [Y/n]`. Use confirmed hostname or prompt for manual input if rejected.
- Validate that `--repo-path` exists and is a git repo (or offer to clone)
- If `--trigger-token` is not provided, prompt interactively for the GitLab pipeline trigger token
- If `--access-token` is not provided, prompt interactively for the GitLab personal access token (read_api scope)
- Both tokens are stored directly in `~/.claude-sync/config.toml` (not in environment variables)
- Validate machine ID (alphanumeric, hyphens, underscores, dots only)
- Warn if trigger token doesn't start with `glptt-` or access token doesn't start with `glpat-`
- Call `scaffold_sync_repo(repo_path)` to copy CI config and pipeline scripts into the sync repo (skips files that already exist). Offer to commit and push the scaffolded files.
- Print success message with next steps

**`add-project`**
```
claude-sync add-project PATH
```
- Resolve PATH to absolute path
- Verify `{PATH}/.claude/` exists (warn if not, but add anyway)
- Enforce that directory name matches git remote repo name (if a remote exists)
- Check for basename collision with already-registered projects (error if duplicate)
- Append to `config.projects.paths`
- Save updated config

**`remove-project`**
```
claude-sync remove-project PATH [--purge]
```
- Resolve PATH to absolute path
- Verify it is currently registered (error if not)
- Remove from `config.projects.paths` and save config
- Print a note that `machines/{machine_id}/projects/{name}/` in the sync repo is now stale
- If `--purge`: delete the local Claude data directory (`~/.claude/projects/{slug}/`)

**`move-project`**
```
claude-sync move-project OLD_PATH NEW_PATH [--rename-dir]
```
- Verify OLD_PATH is registered and NEW_PATH is not
- Check that new name matches git remote repo name (if a remote exists)
- If `--rename-dir`: rename the directory on disk from OLD_PATH to NEW_PATH
- Rename the `~/.claude/projects/` slug directory (old slug → new slug)
- Update `config.projects.paths` and save config
- If the directory name changed, print a note about stale sync repo data

**`list-projects`**
```
claude-sync list-projects
```
- List all registered projects in a table showing: path, scope name, CLAUDE.md presence, memory presence, git remote match status

**`discover`**
```
claude-sync discover --root PATH [--depth INT]
```
- Walk `PATH` up to `--depth` levels deep (default: `config.projects.discover_max_depth`, which defaults to 2). Find directories containing a `.claude/` subdirectory (not just `.claude/CLAUDE.md` — a project may have Claude Code data without a CLAUDE.md file).
- Also check `~/.claude/projects/` for a matching slug directory with a `memory/` subdir — this catches projects that have Claude Code session data even without a `.claude/` directory in the project itself.
- Enforce that directory name matches git remote repo name (skip projects that don't match)
- Check for basename collision with already-registered projects (skip duplicates)
- Print found projects
- Ask whether to add them (typer.confirm)
- Add to config if confirmed

**`bootstrap`**
```
claude-sync bootstrap [--project PATH] [--global-only] [--api-key KEY]
```
- Requires the `bootstrap` optional dependency (`pip install claude-sync[bootstrap]`). If `anthropic` is not importable, print a clear error.
- If `--api-key` is not provided, read from `ANTHROPIC_API_KEY` environment variable. If neither is available, print error and exit.
- If `--project` is given: bootstrap only that project. The project must be registered in config.
- If `--global-only` is given: bootstrap only the global `~/.claude/CLAUDE.md`.
- If neither flag: bootstrap all registered projects, then bootstrap global.
- For each target:
  1. Gather context (memory files, session summaries, existing CLAUDE.md if any)
  2. If no sources found, print warning and skip
  3. Call Anthropic API to generate CLAUDE.md
  4. If target already has a CLAUDE.md, show a diff summary and ask for confirmation before overwriting (unless `--force`)
  5. Write the generated CLAUDE.md to the appropriate location
  6. Print what was generated
- The API key is used only for this command and is NOT stored in config.

**`push`**
```
claude-sync push [--no-trigger]
```
1. Load config
2. `pull_rebase` on sync repo
3. `snapshot(config)` — copy local artifacts to repo
4. `commit_and_push` — if changes exist
5. Unless `--no-trigger`: `trigger_pipeline(config)`
6. Print summary (what was pushed, pipeline triggered or not)

**`pull`**
```
claude-sync pull [--force] [--allow-running]
```
1. Load config
2. `pull_rebase` on sync repo
3. Check `is_claude_code_running()` — if True, print warning and abort (unless `--allow-running` or `--force`)
4. For each scope with a consolidated file: if `check_large_diff` returns True, prompt for confirmation (unless `--force`). Collect rejected scopes into `skip_scopes: set[str]`.
5. `apply_consolidated(config, skip_scopes=skip_scopes)`
6. Scan all applied files for `<!-- CONFLICT:` and `<!-- UNVERIFIED:` markers. Print each as a console warning.
7. Print summary (what was applied, what was skipped)

`--allow-running` bypasses the running-process check but still confirms large diffs. `--force` skips all safety checks.

**`sync`**
```
claude-sync sync
```
1. Run `push` logic (with trigger — skipped if no local changes)
2. If pipeline triggered: `wait_for_pipeline`, abort on failure (print diagnostic hints from job log)
3. Run `pull` logic
4. Print overall summary

**`trigger`**
```
claude-sync trigger [--wait]
```
1. `trigger_pipeline(config)`
2. If `--wait`: `wait_for_pipeline` and print result

**`status`**
```
claude-sync status
```
- Read `meta/last-synthesis.json` from the sync repo
- Print last synthesis time, which scopes were synthesized, and input hashes per machine

---

## Part 2: GitLab CI Pipeline

### 2.1 `.gitlab-ci.yml`

Place this in the root of the sync repo. Deliver this file verbatim.

```yaml
stages:
  - synthesize

variables:
  PIP_CACHE_DIR: "$CI_PROJECT_DIR/.pip-cache"

.synthesis_base:
  stage: synthesize
  image: python:3.12-slim
  cache:
    paths:
      - .pip-cache/
  before_script:
    - pip install -r pipeline/requirements.txt
    - git config user.email "claude-sync@hahtse.de"
    - git config user.name "Claude Sync Bot"
    - git remote set-url origin "https://gitlab-ci-token:${CI_JOB_TOKEN}@${CI_SERVER_HOST}/${CI_PROJECT_PATH}.git"
    - git fetch origin main
    - git checkout main
    - git pull origin main
  script:
    - python pipeline/synthesize.py
    - |
      if git diff --quiet consolidated/ meta/; then
        echo "No changes after synthesis, skipping commit."
      else
        git add consolidated/ meta/
        git commit -m "synthesis: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
        git push origin main
      fi

synthesize_scheduled:
  extends: .synthesis_base
  rules:
    - if: $CI_PIPELINE_SOURCE == "schedule"

synthesize_manual:
  extends: .synthesis_base
  rules:
    - if: $CI_PIPELINE_SOURCE == "web"

synthesize_trigger:
  extends: .synthesis_base
  rules:
    - if: $CI_PIPELINE_SOURCE == "trigger"

synthesize_on_push:
  extends: .synthesis_base
  rules:
    - if: $CI_PIPELINE_SOURCE == "push"
      changes:
        - machines/**/*
```

**Pipeline loop prevention:** The synthesis job pushes back to `consolidated/` using `CI_JOB_TOKEN`, which is automatically injected by GitLab into every CI job — no extra variable or token needs to be configured. GitLab does not trigger a new pipeline when `CI_JOB_TOKEN` is used for a push. Do NOT replace this with a Personal Access Token — PAT pushes DO trigger pipelines, which would cause an endless synthesis loop.

### 2.2 `pipeline/requirements.txt`

```
anthropic>=0.40.0
pydantic>=2.0
```

### 2.3 `pipeline/models.py`

Reuse the `LastSynthesis` and `SyncLogEntry` models from the client. Since the pipeline has minimal dependencies, redefine them here (no shared package import needed):

```python
from pydantic import BaseModel

class LastSynthesis(BaseModel):
    last_run: str                               # ISO 8601
    input_hashes: dict[str, dict[str, str]]     # scope → {machine_id → sha256}

class SyncLogEntry(BaseModel):
    timestamp: str
    scopes_synthesized: list[str]
    machine_inputs: dict[str, dict[str, str]]
```

### 2.4 `pipeline/prompts/synthesize_claude_md.txt`

Deliver this file verbatim. It uses two simple placeholders replaced by `synthesize.py` via `.replace()`:
- `{MACHINE_SECTIONS}` — replaced with one block per machine (built in Python)
- `{PREVIOUS_CONSOLIDATED_SECTION}` — replaced with the previous consolidated block, or empty string

```
You are a knowledge synthesis system for a software development project.

You will receive CLAUDE.md files from multiple development machines working on the same project. These files contain project knowledge, constraints, decisions, and guidelines that Claude Code uses to maintain context.

Your task:
1. Merge all unique knowledge from all sources into a single CLAUDE.md
2. Deduplicate: if multiple files mention the same fact, keep the more precise or detailed version
3. Resolve contradictions: if two sources disagree, keep the more recent or more specific version. If you cannot determine which is correct, mark it with: <!-- CONFLICT: [description] — resolve manually -->
4. Preserve structure: maintain logical grouping with markdown headers
5. Do NOT discard information unless it is clearly a duplicate of something else in the output
6. Do NOT invent new information. Every statement in your output must originate from one of the inputs.
7. Maintain the tone and style of CLAUDE.md files: imperative, concise, developer-focused

{MACHINE_SECTIONS}

{PREVIOUS_CONSOLIDATED_SECTION}

Produce the merged CLAUDE.md content. Output ONLY the markdown content, no preamble, no code fences.
```

In `synthesize.py`, `build_prompt()` constructs `MACHINE_SECTIONS` by iterating `machine_inputs`:
```
Machine "desktop" version:
---
<content>
---

Machine "laptop" version:
---
<content>
---
```

And `PREVIOUS_CONSOLIDATED_SECTION` as either:
```
Previous consolidated version (baseline — preserve structure if possible):
---
<content>
---
```
or empty string `""` if no previous consolidated file exists. Do NOT add Jinja2 as a dependency.

### 2.5 `pipeline/synthesize.py`

This is the main entry point for the CI job. Implement as follows:

```python
"""
Main synthesis script. Runs inside GitLab CI.

Usage: python pipeline/synthesize.py

Reads machine inputs from machines/, compares with last-synthesis.json,
calls Claude API for changed scopes, writes results to consolidated/.
"""
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

import anthropic
from models import LastSynthesis, SyncLogEntry

REPO_ROOT = Path(__file__).parent.parent  # one level up from pipeline/
MACHINES_DIR = REPO_ROOT / "machines"
CONSOLIDATED_DIR = REPO_ROOT / "consolidated"
META_DIR = REPO_ROOT / "meta"
PROMPTS_DIR = Path(__file__).parent / "prompts"

MODEL = "claude-sonnet-4-20250514"
MAX_TOKENS = 8192
```

Implement these functions:

**`load_last_synthesis() -> LastSynthesis`**
- Read `META_DIR / "last-synthesis.json"`
- If file doesn't exist, return empty `LastSynthesis(last_run="", input_hashes={})`
- Parse JSON into `LastSynthesis` model

**`save_last_synthesis(meta: LastSynthesis)`**
- Write to `META_DIR / "last-synthesis.json"` as formatted JSON
- Create `META_DIR` if it doesn't exist

**`append_sync_log(entry: SyncLogEntry)`**
- Read existing `META_DIR / "sync-log.json"` (list of entries) or create empty list
- Append new entry
- Write back as formatted JSON

**`sha256_file(path: Path) -> str`**
- Return hex digest of file contents

**`discover_scopes() -> list[str]`**
- Scan `MACHINES_DIR` to find all scopes
- A scope is either `"global"` (if any machine has `global/CLAUDE.md`) or `"projects/{name}"` (if any machine has `projects/{name}/CLAUDE.md` OR `projects/{name}/memory/`)
- Return deduplicated list of scope strings

**`gather_inputs(scope: str) -> dict[str, str]`**
- For each machine directory in `MACHINES_DIR`:
  - Read `{machine_dir}/{scope}/CLAUDE.md` if it exists
  - Key = machine directory name, Value = file content as string
- Return the dict. Skip machines that don't have the file.

**`propagate_files(scope: str)`**
- Handle non-synthesized files that should be propagated by "latest wins" strategy.
- For each machine directory in `MACHINES_DIR`:
  - If `{machine_dir}/{scope}/memory/` exists, copy all files to `CONSOLIDATED_DIR/{scope}/memory/`, keeping the most recently modified version of each file when multiple machines have the same filename.
  - If scope is `"global"` and `{machine_dir}/global/settings.json` exists, copy to `CONSOLIDATED_DIR/global/settings.json` (latest wins across machines).
- After propagation, remove stale files from `CONSOLIDATED_DIR/{scope}/memory/` that no longer exist in any machine's memory directory. If no machine has any memory files, remove the entire consolidated memory directory.
- **File modification time**: Use `_git_commit_time(path)` instead of filesystem mtime. In CI, `git clone` sets all files to clone time, making mtime unreliable. `_git_commit_time` queries `git log -1 --format=%ct -- {path}` for the actual commit timestamp and falls back to `stat().st_mtime` if git history is unavailable.

**`needs_synthesis(scope: str, current_hashes: dict[str, str], last: LastSynthesis) -> bool`**
- Compare `current_hashes` for this scope against `last.input_hashes.get(scope, {})`
- Return True if they differ

**`load_prompt_template(name: str) -> str`**
- Read `PROMPTS_DIR / name` and return contents

**`build_prompt(scope: str, machine_inputs: dict[str, str], previous_consolidated: str | None) -> str`**
- Load the `synthesize_claude_md.txt` template
- Build `MACHINE_SECTIONS` string by iterating `machine_inputs`
- Build `PREVIOUS_CONSOLIDATED_SECTION` string if `previous_consolidated` is not None, else `""`
- Replace `{MACHINE_SECTIONS}` and `{PREVIOUS_CONSOLIDATED_SECTION}` in the template using `.replace()`
- Return the assembled prompt string

**`call_claude_api(prompt: str) -> str`**
- Create `anthropic.Anthropic()` client (reads `ANTHROPIC_API_KEY` from env automatically)
- Call `client.messages.create(model=MODEL, max_tokens=MAX_TOKENS, messages=[{"role": "user", "content": prompt}])`
- Extract text content from response
- Return the text

**`critic_pass(output: str, inputs: dict[str, str], scope: str = "") -> list[str]`**

Second-stage hallucination check using a separate Claude API call.

- Load `pipeline/prompts/synthesize_critic.txt` template
- Fill in `{MACHINE_SECTIONS}` (same format as synthesis prompt) and `{SYNTHESIZED_OUTPUT}`
- Call Claude API with this critic prompt
- Parse response: if it contains only `"OK"` (case-insensitive, stripped), return `[]`
- Otherwise extract lines starting with `UNVERIFIED:` and return them as a list of strings
- On any API error: print explicit warning `"WARNING: Critic validation skipped for scope '{scope}' due to API error: {error}. Output accepted without validation."` and return `[]` (fail open — don't block on critic failure)

**`pipeline/prompts/synthesize_critic.txt`** — deliver verbatim:

```
You are a fact-checking system for synthesized documentation.

You will receive:
1. SOURCE FILES from multiple machines (ground truth)
2. A SYNTHESIZED OUTPUT produced by merging those sources

Your task: identify specific claims in the synthesized output that cannot be traced to any source file.
- Do NOT suggest improvements or rewrites
- Do NOT flag reformulations or paraphrases of source content — only flag genuinely invented claims
- Do NOT flag structural choices (ordering, headers) — only flag factual content

For each suspicious claim, output exactly:
UNVERIFIED: "<exact quote from synthesized output>" — reason: <brief explanation>

If every claim in the output is traceable to at least one source, output only:
OK

{MACHINE_SECTIONS}

Synthesized output to verify:
---
{SYNTHESIZED_OUTPUT}
---
```

**`synthesize_scope(scope: str, machine_inputs: dict[str, str]) -> str | None`**
- Filter out empty inputs: remove any entries where `content.strip()` is empty. If a machine pushes an empty CLAUDE.md, treat it as "no knowledge from this machine" rather than "knowledge was intentionally cleared".
- If after filtering only one machine remains: skip the API call entirely. Copy that machine's content directly to `CONSOLIDATED_DIR / scope / "CLAUDE.md"` (create dirs as needed). Print `"Scope '{scope}': only one machine has content, copying directly (no synthesis needed)."`. Return the content.
- If after filtering zero machines remain: print warning, return None.
- Read previous consolidated file from `CONSOLIDATED_DIR / scope / "CLAUDE.md"` (may not exist)
- Build prompt via `build_prompt`
- Call Claude API → `output`
- Call `critic_pass(output, filtered, scope=scope)` → `issues` (pass the filtered inputs, not the original `machine_inputs`)
- If `len(issues) > 3`: print warning with issues, return None (too many unverifiable claims)
- If `0 < len(issues) <= 3`: embed each issue as `<!-- UNVERIFIED: ... -->` comment at end of output, print warning
- Write result to `CONSOLIDATED_DIR / scope / "CLAUDE.md"` (create dirs as needed)
- Return the output (with embedded comments if any)

**`main()`**
1. Check that `ANTHROPIC_API_KEY` is set; if not, print clear error and `sys.exit(1)`
2. Check that `MACHINES_DIR` exists and contains at least one subdirectory. If not, print `"No machine snapshots found in machines/. Nothing to synthesize."` and `sys.exit(0)`.
3. Load last synthesis metadata
4. Discover all scopes
5. For each scope:
   a. Gather CLAUDE.md inputs (for synthesis)
   b. Compute SHA-256 of each input file
   c. Always: call `propagate_files(scope)` to propagate memory/ and settings.json (latest wins)
   d. Check `needs_synthesis`; if no: skip to next scope
   e. Call `synthesize_scope`, collect result
   f. Track failed scopes (synthesis returned None or raised exception)
6. Build new `LastSynthesis` with all current hashes — but exclude failed scopes so they are retried next run
7. Save last synthesis metadata
8. If any scopes were synthesized: append to sync log
9. Print summary to stdout

Call `main()` in `if __name__ == "__main__":` block.

**Error handling:**
- If `ANTHROPIC_API_KEY` is not set, print clear error and `sys.exit(1)`
- If API call fails, print error with scope name, continue with other scopes
- If validation rejects output, print warning, skip writing that scope
- Never crash the entire pipeline on a single scope failure

---

## Implementation Order

Implement test-first. For each module, write the tests before or alongside the implementation. Each step should be a working, testable increment.

1. **Test fixtures** — create `tests/fixtures/` with sample `.claude/` structures for machine_a and machine_b
2. **Client `models.py`** — data models (no tests needed, validated by usage)
3. **Client `claude_paths.py`** + **`tests/test_claude_paths.py`** — slug derivation and path resolution
4. **Client `config.py`** + **`tests/test_config.py`** — config loading; test: load valid/invalid TOML, missing file error, save and reload, init
5. **Client `snapshot.py`** + **`tests/test_snapshot.py`** — implement and test together (including memory/ and settings.json capture, deletion tracking, auto-discover)
6. **Client `apply.py`** + **`tests/test_apply.py`** — implement and test together (including memory/ and settings.json restore, stale memory cleanup via snapshot cross-reference)
7. **Client `lock.py`** + **`tests/test_lock.py`** — Claude Code process detection (mock subprocess for both Windows tasklist and Linux pgrep paths)
8. **Client `git_ops.py`** + **`tests/test_git_ops.py`** — git wrapper (mock git.Repo for ensure_repo, pull_rebase, commit_and_push, has_changes)
9. **Client `gitlab_api.py`** + **`tests/test_gitlab_api.py`** — pipeline trigger and polling (mock httpx; test _diagnose_log pattern matching)
10. **Client `scaffold.py`** + **`tests/test_scaffold.py`** — template scaffolding (test file creation, idempotency, skip existing)
11. **Client `bootstrap.py`** + **`tests/test_bootstrap.py`** — implement and test together (mock Anthropic API)
12. **Client `cli.py`** — wire everything together into CLI commands (including `bootstrap`, project management commands)
13. **Pipeline `models.py`** and `prompts/synthesize_claude_md.txt` + `prompts/synthesize_critic.txt`
14. **Pipeline `synthesize.py`** + **`tests/test_synthesize.py`** — implement and test together (including `propagate_files`, stale file cleanup, `_git_commit_time`)
15. **`.gitlab-ci.yml`** — pipeline definition

## Decisions (No Open Questions)

These decisions are final. Do not deviate:

- **Runner executor:** Docker (`python:3.12-slim` image). The CI job does not need host access.
- **Privacy/redaction:** Not implemented in MVP. May be added later.
- **Conflict markers:** The synthesizer writes `<!-- CONFLICT: ... -->` in the output. `claude-sync pull` scans for these markers and prints them as warnings to the console.
- **Multi-project atomicity:** Per-project. Each scope is synthesized independently. One failure does not block others.
- **Machine count:** The synthesizer handles N machines dynamically by iterating `machines/*/`. No hardcoded machine count.
- **Two-layer memory model:** Short-term memory (`~/.claude/projects/{slug}/memory/`) is propagated as-is (latest wins). Long-term memory (`CLAUDE.md`) is synthesized via the CI pipeline. The `bootstrap` command bridges the two layers.
- **Bootstrap uses client-side API call:** This is the only exception to the "Anthropic API key never reaches client machines" rule. The `bootstrap` command requires an API key passed via `--api-key` flag or `ANTHROPIC_API_KEY` env var, used once and never stored in config.
- **Project slug derivation:** Must match Claude Code's own directory naming under `~/.claude/projects/`. Currently: lowercase path, replace `:` and path separators with `-`.
- **Discover finds `.claude/` dirs (not just `.claude/CLAUDE.md`):** A project may have Claude Code session data (memory, todos) without having a manually-created CLAUDE.md file. The `discover` command and `auto_discover` should find these projects too.
- **Python version:** 3.11+ required.
- **No Jinja2 dependency.** Prompt template substitution uses plain Python string operations.
- **No watchdog/daemon in MVP.** Client is always invoked manually.

## Testing Notes

**`test_claude_paths.py`**
- Test `project_slug()`: Windows path `C:\dev\claudesync` → `c--dev-claudesync`
- Test `project_slug()`: Unix path `/home/user/dev/project` → `-home-user-dev-project`
- Test `claude_project_dir()`: returns correct `~/.claude/projects/{slug}/` path
- Test `claude_memory_dir()`: returns correct `~/.claude/projects/{slug}/memory/` path

**`test_config.py`**
- Test `load_config()`: valid TOML, missing file error, invalid TOML, missing required field
- Test `save_config()`: save and reload roundtrip
- Test `init_config()`: creates file and directory

**`test_claude_paths.py`**
- Test `project_slug()`: Windows path `C:\dev\claudesync` → `c--dev-claudesync`
- Test `project_slug()`: colon replacement, backslash replacement, deterministic
- Test `claude_project_dir()`: returns correct `~/.claude/projects/{slug}/` path
- Test `claude_memory_dir()`: returns correct `~/.claude/projects/{slug}/memory/` path
- Test `claude_sessions_index()`: returns correct sessions-index.json path

**`test_snapshot.py`**
- Create a temp dir with fake `.claude/` structure (global + per-project)
- Run `snapshot()` against a fake repo dir
- Assert files appear at correct paths under `machines/{machine_id}/`
- Assert unchanged files are not re-copied (hash equality check)
- Assert changed files are re-copied
- Assert `auto_discover` finds projects when enabled
- Assert `auto_discover` respects `discover_max_depth` (projects nested deeper are not found)
- Assert `auto_discover` deduplicates (explicit + discovered)
- Assert `auto_discover` finds projects with `.claude/` dir even without CLAUDE.md
- Assert memory files from `~/.claude/projects/{slug}/memory/` are copied to `machines/{id}/projects/{name}/memory/`
- Assert `~/.claude/settings.json` is copied to `machines/{id}/global/settings.json`
- Assert deleted CLAUDE.md (global and project) is removed from the sync repo
- Assert deleted memory files and memory directory are removed from the sync repo

**`test_apply.py`**
- Create a fake `consolidated/` directory with global and project CLAUDE.md files
- Run `apply_consolidated()` and verify files land at correct local paths
- Verify backups are created under `.claude/backups/{timestamp}/`
- Verify `skip_scopes` correctly prevents applying rejected scopes
- Test `check_large_diff`: provide two files with >50% line difference, assert True; <50%, assert False; identical, assert False; both empty, assert False
- Verify memory files from `consolidated/projects/{name}/memory/` are applied to `~/.claude/projects/{slug}/memory/`
- Verify `consolidated/global/settings.json` is applied to `~/.claude/settings.json`
- Verify stale memory files (in machine snapshot but not in consolidated) are removed locally
- Verify local-only memory files (not in machine snapshot) are preserved

**`test_lock.py`**
- Mock subprocess for Windows tasklist path: claude.exe found → True, not found → False, claude-sync.exe → False
- Mock subprocess for Linux pgrep path: match found → True, no match → False, own PID filtered → False
- Exception and timeout → False (best-effort)

**`test_scaffold.py`**
- Test all template files are created in the sync repo
- Test returns correct relative paths
- Test skips files that already exist (does not overwrite)
- Test idempotent on second run (creates nothing)
- Test dotfiles stored without dot prefix are written with dot
- Test files are non-empty

**`test_git_ops.py`**
- Mock `git.Repo` for all operations
- Test `ensure_repo()`: success, InvalidGitRepositoryError → ValueError, NoSuchPathError → ValueError
- Test `pull_rebase()`: calls git pull --rebase origin main
- Test `has_changes()`: dirty → True, clean → False
- Test `commit_and_push()`: with changes (add, commit, push), without changes (no-op)

**`test_gitlab_api.py`**
- Mock httpx for all HTTP calls
- Test `trigger_pipeline()`: success (returns pipeline ID), HTTP error, missing token
- Test `get_pipeline_status()`: success, HTTP error, missing token
- Test `get_failed_job_log()`: returns last 50 lines, no failed jobs → None, API error → None, missing token → None, exception → None
- Test `_diagnose_log()`: push denied pattern, 403+push pattern, ANTHROPIC_API_KEY pattern, AuthenticationError pattern, unknown log → None
- Test `wait_for_pipeline()`: success/failed/canceled terminal states, timeout raises TimeoutError

**`test_bootstrap.py`**
- Mock `anthropic.Anthropic().messages.create`
- Test `gather_project_context()`: returns memory files and session summaries from correct paths
- Test `gather_project_context()` with empty memory dir: returns empty dict
- Test `gather_project_context()` ignores bad sessions-index.json
- Test `gather_global_context()`: aggregates across all registered projects
- Test `build_bootstrap_prompt()`: assert placeholders are replaced, scope instruction is correct
- Test `bootstrap_project()`: writes generated CLAUDE.md to correct location
- Test `bootstrap_project()` with no sources: returns None, no API call made
- Test `bootstrap_global()`: writes to `~/.claude/CLAUDE.md`
- Test `bootstrap_global()` with no sources: returns None, no API call made

**`test_synthesize.py`**
- Mock `anthropic.Anthropic().messages.create` for both synthesis and critic calls
- Test `discover_scopes()` with a populated `machines/` fixture directory
- Test `discover_scopes()` finds scopes from memory/ dirs even without CLAUDE.md
- Test `discover_scopes()` deduplicates across machines
- Test `needs_synthesis()`: returns True when hashes differ, False when equal, True when scope missing
- Test `build_prompt()`: assert `{MACHINE_SECTIONS}` and `{PREVIOUS_CONSOLIDATED_SECTION}` are replaced correctly
- Test `critic_pass()`:
  - Mock returns `"OK"` → assert empty list returned (case-insensitive)
  - Mock returns `UNVERIFIED: "..."` lines → assert list with those strings
  - Mock returns mixed lines → only UNVERIFIED lines extracted
  - Mock raises exception → assert empty list returned (fail open), warning printed
- Test `synthesize_scope()`:
  - 0 issues → file written, no comments embedded
  - 1–3 issues → file written with `<!-- UNVERIFIED: -->` comments appended
  - >3 issues → file not written, returns None
  - Single machine input → file copied directly, no API call made
  - All machine inputs empty (whitespace-only) → returns None, no API call
  - One machine empty + one non-empty → treated as single-machine case, direct copy
- Test `propagate_files()`: memory files propagated with latest-wins strategy
- Test `propagate_files()`: settings.json propagated with latest-wins strategy
- Test `propagate_files()`: distinct files from different machines are all propagated
- Test `propagate_files()`: stale memory files removed from consolidated
- Test `propagate_files()`: stale memory directory removed when no machine has memory
- Test `main()` with empty `machines/` dir → exits cleanly with message
- Test `main()` with missing ANTHROPIC_API_KEY → exits with error
- Test metadata: `last-synthesis.json` written correctly, `sync-log.json` appended

## Security: Secret Storage and Access

### Secrets inventory

| Secret | Used by | Lives in | Never in |
|--------|---------|----------|----------|
| `ANTHROPIC_API_KEY` | GitLab CI (`synthesize.py`); optionally client (`bootstrap`) | GitLab CI/CD variable; `--api-key` flag or env var for bootstrap | `~/.claude-sync/config.toml`, code, repo |
| `CI_JOB_TOKEN` | GitLab CI (`git push` in pipeline) | Auto-injected by GitLab | Needs no configuration |
| Trigger token (`glptt-...`) | Client (`trigger_pipeline`) | `~/.claude-sync/config.toml` | Code, repo, CI |
| Access token (`glpat-...`) | Client (`get_pipeline_status`) | `~/.claude-sync/config.toml` | Code, repo, CI |

### Key design property: ANTHROPIC_API_KEY is not stored on client machines

For ongoing synthesis, the Claude API is called exclusively inside the GitLab CI pipeline. Client machines only trigger the pipeline via a lightweight HTTP call. This means the Anthropic API key does not need to be distributed to or persistently stored on any developer workstation.

The one exception is the `bootstrap` command, which calls the Anthropic API directly from the client machine to generate CLAUDE.md files from existing session artifacts. The API key is provided via `--api-key` flag or `ANTHROPIC_API_KEY` environment variable — it is used for the duration of the command and is **never stored** in `~/.claude-sync/config.toml` or any other persistent file.

### GitLab CI secrets (`ANTHROPIC_API_KEY`)

Store as a GitLab CI/CD variable (Settings → CI/CD → Variables) with these flags:
- **Masked**: value is redacted from all job logs
- **Protected**: only injected into pipelines running on protected branches (`main`)
- **Expand variable reference**: leave OFF (these are literal strings, not references to other variables)

Do not store it in `.env` files, committed configs, or repository files of any kind. GitLab CI/CD variables are the correct mechanism.

**Dependency: `main` must be a protected branch.** The "Protected" variable flag only takes effect on protected branches. GitLab protects the default branch automatically, but verify this: Settings → Repository → Protected Branches — `main` must appear there. All four pipeline job types (`synthesize_scheduled`, `synthesize_manual`, `synthesize_trigger`, `synthesize_on_push`) run on `main`, so this is satisfied as long as `main` is protected. If a pipeline ever ran on an unprotected ref, the variables would be absent and the job would fail with a misleading "API key not found" error rather than a clear permission message.

### Client machine secrets (trigger token, access token)

Both tokens are stored in `~/.claude-sync/config.toml` and are provided during `claude-sync init` (either as flags or via interactive prompts). They are never stored in environment variables or shell profiles.

```toml
[gitlab]
trigger_token = "glptt-..."   # pipeline trigger token
access_token  = "glpat-..."   # personal access token (read_api scope)
```

Protect the config file:
- Mode `600` on Unix: `chmod 600 ~/.claude-sync/config.toml`
- It lives in `~/.claude-sync/`, outside any repository, and is never committed

To update a token after initial setup, edit `~/.claude-sync/config.toml` directly or re-run `claude-sync init`.

### Repository `.gitignore` rules

Add to `claude-sync/` (client repo):
```
# Never commit local config or credentials
.env
*.env
```

The config file lives in `~/.claude-sync/`, outside any repo, so no `.gitignore` entry is needed for it. But if tests or scripts ever write a local config for dev purposes, ensure it is gitignored.

For the `claude-knowledge-sync` sync repo, note that `machines/` and `consolidated/` contain your CLAUDE.md files, memory files, and settings. These describe your projects, workflows, and preferences. Do not store credentials, passwords, or API keys inside CLAUDE.md or memory files — they will be committed to the sync repo and visible to anyone with repository access.

---

## GitLab Setup Checklist (Manual, Not Automated)

These steps must be done manually by the user in the GitLab web UI:

1. Create the `claude-knowledge-sync` repo on GitLab
2. Verify `main` is a protected branch (Settings → Repository → Protected Branches) — required for protected CI/CD variables to be injected
3. Add CI/CD variable `ANTHROPIC_API_KEY` (Settings → CI/CD → Variables, masked + protected)
4. Create a Pipeline Trigger Token (Settings → CI/CD → Pipeline trigger tokens)
5. Create a Project Access Token named `claude-sync-reader` with role Maintainer and scope `read_api` (Settings → Access Tokens)
6. Run `claude-sync init` on each client machine — it will prompt for the trigger token (step 4) and access token (step 5) and store them in `~/.claude-sync/config.toml`
7. Optionally: create a Pipeline Schedule (Build → Pipeline schedules, cron `0 3 * * *`, branch `main`)
8. Ensure a GitLab Runner is available (shared or project-specific)

Note: No Deploy Token is needed. The pipeline uses `CI_JOB_TOKEN` (automatically available in all CI jobs) to push back to the repository. Deploy tokens do not support `write_repository` scope.
