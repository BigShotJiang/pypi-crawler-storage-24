"""
Main synthesis script. Runs inside GitLab CI.

Usage: python pipeline/synthesize.py

Reads machine inputs from machines/, compares with last-synthesis.json,
calls Claude API for changed scopes, writes results to consolidated/.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import anthropic

# Allow running directly from pipeline/ dir or from repo root
sys.path.insert(0, str(Path(__file__).parent))
from models import LastSynthesis, SyncLogEntry

REPO_ROOT = Path(__file__).parent.parent  # one level up from pipeline/
MACHINES_DIR = REPO_ROOT / "machines"
CONSOLIDATED_DIR = REPO_ROOT / "consolidated"
META_DIR = REPO_ROOT / "meta"
PROMPTS_DIR = Path(__file__).parent / "prompts"

MODEL = "claude-sonnet-4-20250514"
MAX_TOKENS = 8192


# ---------------------------------------------------------------------------
# Metadata helpers
# ---------------------------------------------------------------------------

def load_last_synthesis() -> LastSynthesis:
    path = META_DIR / "last-synthesis.json"
    if not path.exists():
        return LastSynthesis(last_run="", input_hashes={})
    return LastSynthesis.model_validate_json(path.read_text())


def save_last_synthesis(meta: LastSynthesis) -> None:
    META_DIR.mkdir(parents=True, exist_ok=True)
    (META_DIR / "last-synthesis.json").write_text(
        meta.model_dump_json(indent=2)
    )


def append_sync_log(entry: SyncLogEntry) -> None:
    path = META_DIR / "sync-log.json"
    META_DIR.mkdir(parents=True, exist_ok=True)
    entries = []
    if path.exists():
        entries = json.loads(path.read_text())
    entries.append(json.loads(entry.model_dump_json()))
    path.write_text(json.dumps(entries, indent=2))


# ---------------------------------------------------------------------------
# File helpers
# ---------------------------------------------------------------------------

def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _git_commit_time(path: Path) -> float:
    """
    Return the Unix timestamp of the last git commit that modified this file.
    Falls back to filesystem mtime if git history is unavailable.

    Using mtime alone is broken in CI because git clone sets all files to the
    clone time. This function queries git log for the actual commit timestamp.
    """
    try:
        rel = path.relative_to(REPO_ROOT)
        result = subprocess.run(
            ["git", "log", "-1", "--format=%ct", "--", str(rel)],
            capture_output=True, text=True, timeout=10,
            cwd=REPO_ROOT,
        )
        if result.returncode == 0 and result.stdout.strip():
            return float(result.stdout.strip())
    except Exception:
        pass
    return path.stat().st_mtime


# ---------------------------------------------------------------------------
# Scope discovery
# ---------------------------------------------------------------------------

def discover_scopes() -> list[str]:
    scopes: set[str] = set()
    if not MACHINES_DIR.exists():
        return []
    for machine_dir in MACHINES_DIR.iterdir():
        if not machine_dir.is_dir():
            continue
        global_md = machine_dir / "global" / "CLAUDE.md"
        if global_md.exists():
            scopes.add("global")
        projects_dir = machine_dir / "projects"
        if projects_dir.exists():
            for proj in projects_dir.iterdir():
                if proj.is_dir() and (
                    (proj / "CLAUDE.md").exists() or (proj / "memory").is_dir()
                ):
                    scopes.add(f"projects/{proj.name}")
    return sorted(scopes)


def gather_inputs(scope: str) -> dict[str, str]:
    inputs: dict[str, str] = {}
    if not MACHINES_DIR.exists():
        return inputs
    scope_parts = scope.split("/")
    for machine_dir in MACHINES_DIR.iterdir():
        if not machine_dir.is_dir():
            continue
        md_path = machine_dir
        for part in scope_parts:
            md_path = md_path / part
        md_path = md_path / "CLAUDE.md"
        if md_path.exists():
            inputs[machine_dir.name] = md_path.read_text(encoding="utf-8")
    return inputs


def needs_synthesis(scope: str, current_hashes: dict[str, str], last: LastSynthesis) -> bool:
    return current_hashes != last.input_hashes.get(scope, {})


# ---------------------------------------------------------------------------
# Prompt building
# ---------------------------------------------------------------------------

def load_prompt_template(name: str) -> str:
    return (PROMPTS_DIR / name).read_text(encoding="utf-8")


def build_prompt(
    scope: str,
    machine_inputs: dict[str, str],
    previous_consolidated: str | None,
) -> str:
    template = load_prompt_template("synthesize_claude_md.txt")

    machine_sections = ""
    for machine_id, content in machine_inputs.items():
        machine_sections += f'Machine "{machine_id}" version:\n---\n{content}\n---\n\n'
    machine_sections = machine_sections.rstrip()

    if previous_consolidated is not None:
        prev_section = (
            "Previous consolidated version (baseline — preserve structure if possible):\n"
            f"---\n{previous_consolidated}\n---"
        )
    else:
        prev_section = ""

    return (
        template
        .replace("{MACHINE_SECTIONS}", machine_sections)
        .replace("{PREVIOUS_CONSOLIDATED_SECTION}", prev_section)
    )


# ---------------------------------------------------------------------------
# Claude API
# ---------------------------------------------------------------------------

def call_claude_api(prompt: str) -> str:
    client = anthropic.Anthropic()
    response = client.messages.create(
        model=MODEL,
        max_tokens=MAX_TOKENS,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.content[0].text


def critic_pass(output: str, inputs: dict[str, str], scope: str = "") -> list[str]:
    """Second-stage hallucination check. Returns list of UNVERIFIED strings."""
    try:
        template = load_prompt_template("synthesize_critic.txt")

        machine_sections = ""
        for machine_id, content in inputs.items():
            machine_sections += f'Machine "{machine_id}" version:\n---\n{content}\n---\n\n'
        machine_sections = machine_sections.rstrip()

        prompt = (
            template
            .replace("{MACHINE_SECTIONS}", machine_sections)
            .replace("{SYNTHESIZED_OUTPUT}", output)
        )

        response = call_claude_api(prompt)
        if response.strip().upper() == "OK":
            return []

        return [
            line.strip()
            for line in response.splitlines()
            if line.strip().startswith("UNVERIFIED:")
        ]
    except Exception as e:
        scope_label = f" '{scope}'" if scope else ""
        print(
            f"WARNING: Critic validation skipped for scope{scope_label} due to API error: {e}. "
            "Output accepted without validation."
        )
        return []


# ---------------------------------------------------------------------------
# Propagation (latest-wins, no synthesis)
# ---------------------------------------------------------------------------

def propagate_files(scope: str) -> None:
    """
    Copy propagated files (memory/, settings.json) into consolidated/ using
    latest-wins strategy. The machine with the most recently modified files wins.

    Files propagated (if present in any machine snapshot):
    - For global scope: settings.json
    - For any scope: memory/ directory
    """
    scope_parts = scope.split("/")
    dest_scope_dir = CONSOLIDATED_DIR / Path(*scope_parts)

    # Gather all machines that have data for this scope
    machines_with_scope: list[Path] = []
    for machine_dir in MACHINES_DIR.iterdir():
        if machine_dir.is_dir() and (machine_dir / Path(*scope_parts)).is_dir():
            machines_with_scope.append(machine_dir)

    if not machines_with_scope:
        return

    # settings.json (global scope only)
    if scope == "global":
        best_settings: Path | None = None
        best_mtime = -1.0
        for machine_dir in machines_with_scope:
            candidate = machine_dir / "global" / "settings.json"
            if candidate.exists():
                mtime = _git_commit_time(candidate)
                if mtime > best_mtime:
                    best_mtime = mtime
                    best_settings = candidate
        if best_settings is not None:
            dest = dest_scope_dir / "settings.json"
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(best_settings, dest)
            print(f"Scope '{scope}': propagated settings.json from {best_settings.parent.name}")

    # memory/ directory — copy all files, newest machine wins per-file
    memory_files: dict[str, tuple[Path, float]] = {}  # rel_path -> (src, commit_time)
    for machine_dir in machines_with_scope:
        machine_memory = machine_dir / Path(*scope_parts) / "memory"
        if machine_memory.exists():
            for f in machine_memory.rglob("*"):
                if f.is_file():
                    rel = str(f.relative_to(machine_memory))
                    mtime = _git_commit_time(f)
                    if rel not in memory_files or mtime > memory_files[rel][1]:
                        memory_files[rel] = (f, mtime)

    dest_memory = dest_scope_dir / "memory"
    if memory_files:
        for rel, (src, _) in memory_files.items():
            dest_file = dest_memory / rel
            dest_file.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest_file)
        print(f"Scope '{scope}': propagated {len(memory_files)} memory file(s)")

    # Remove stale memory files from consolidated/ that no longer exist in any machine
    if dest_memory.exists():
        if not memory_files:
            shutil.rmtree(dest_memory)
            print(f"Scope '{scope}': removed stale consolidated memory directory")
        else:
            for dest_file in list(dest_memory.rglob("*")):
                if dest_file.is_file():
                    rel = str(dest_file.relative_to(dest_memory))
                    if rel not in memory_files:
                        dest_file.unlink()
                        print(f"Scope '{scope}': removed stale memory file '{rel}' from consolidated")


# ---------------------------------------------------------------------------
# Synthesis
# ---------------------------------------------------------------------------

def synthesize_scope(scope: str, machine_inputs: dict[str, str]) -> str | None:
    # Filter out empty inputs
    filtered = {k: v for k, v in machine_inputs.items() if v.strip()}

    if len(filtered) == 0:
        print(f"Warning: scope '{scope}' has no non-empty machine inputs. Skipping.")
        return None

    if len(filtered) == 1:
        machine_id, content = next(iter(filtered.items()))
        dest = CONSOLIDATED_DIR / Path(*scope.split("/")) / "CLAUDE.md"
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(content, encoding="utf-8")
        print(f"Scope '{scope}': only one machine has content, copying directly (no synthesis needed).")
        return content

    # Read previous consolidated
    prev_path = CONSOLIDATED_DIR / Path(*scope.split("/")) / "CLAUDE.md"
    previous_consolidated = prev_path.read_text(encoding="utf-8") if prev_path.exists() else None

    prompt = build_prompt(scope, filtered, previous_consolidated)
    output = call_claude_api(prompt)

    issues = critic_pass(output, filtered, scope=scope)

    if len(issues) > 3:
        print(f"Warning: scope '{scope}' rejected by critic ({len(issues)} issues):")
        for issue in issues:
            print(f"  {issue}")
        return None

    if 0 < len(issues) <= 3:
        print(f"Warning: scope '{scope}' has {len(issues)} unverified claim(s):")
        for issue in issues:
            print(f"  {issue}")
        for issue in issues:
            output += f"\n<!-- UNVERIFIED: {issue} -->"

    dest = CONSOLIDATED_DIR / Path(*scope.split("/")) / "CLAUDE.md"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(output, encoding="utf-8")
    return output


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    if not os.environ.get("ANTHROPIC_API_KEY"):
        print("ERROR: ANTHROPIC_API_KEY environment variable is not set.")
        sys.exit(1)

    if not MACHINES_DIR.exists() or not any(
        d.is_dir() for d in MACHINES_DIR.iterdir()
    ):
        print("No machine snapshots found in machines/. Nothing to synthesize.")
        sys.exit(0)

    last = load_last_synthesis()
    scopes = discover_scopes()

    synthesized_scopes: list[str] = []
    new_input_hashes: dict[str, dict[str, str]] = {}

    failed_scopes: set[str] = set()

    for scope in scopes:
        inputs = gather_inputs(scope)
        scope_parts = scope.split("/")
        current_hashes = {
            machine_id: sha256_file(MACHINES_DIR / machine_id / Path(*scope_parts) / "CLAUDE.md")
            for machine_id in inputs
        }
        new_input_hashes[scope] = current_hashes

        # Always propagate settings.json and memory/ (latest-wins, no synthesis)
        try:
            propagate_files(scope)
        except Exception as e:
            print(f"WARNING: propagation failed for scope '{scope}': {e}")

        if not needs_synthesis(scope, current_hashes, last):
            print(f"Scope '{scope}': no changes, skipping synthesis.")
            continue

        print(f"Scope '{scope}': synthesizing...")
        try:
            result = synthesize_scope(scope, inputs)
            if result is not None:
                synthesized_scopes.append(scope)
            else:
                # Synthesis returned None (e.g. critic rejected) — don't record
                # hashes so the next run retries this scope.
                failed_scopes.add(scope)
                print(f"Scope '{scope}': synthesis produced no output, will retry next run.")
        except Exception as e:
            failed_scopes.add(scope)
            print(f"ERROR: synthesis failed for scope '{scope}': {e}")

    # Don't record hashes for failed scopes so they are retried next run
    for scope in failed_scopes:
        new_input_hashes.pop(scope, None)

    now = datetime.now(timezone.utc).isoformat()
    new_meta = LastSynthesis(last_run=now, input_hashes=new_input_hashes)
    save_last_synthesis(new_meta)

    if synthesized_scopes:
        log_entry = SyncLogEntry(
            timestamp=now,
            scopes_synthesized=synthesized_scopes,
            machine_inputs={
                scope: new_input_hashes[scope]
                for scope in synthesized_scopes
            },
        )
        append_sync_log(log_entry)

    print(
        f"Done. Synthesized {len(synthesized_scopes)}/{len(scopes)} scope(s): "
        + (", ".join(synthesized_scopes) if synthesized_scopes else "none")
    )


if __name__ == "__main__":
    main()
