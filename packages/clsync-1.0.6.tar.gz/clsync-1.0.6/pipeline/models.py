from pydantic import BaseModel


class LastSynthesis(BaseModel):
    last_run: str                               # ISO 8601
    input_hashes: dict[str, dict[str, str]]     # scope → {machine_id → sha256}


class SyncLogEntry(BaseModel):
    timestamp: str
    scopes_synthesized: list[str]
    machine_inputs: dict[str, dict[str, str]]
