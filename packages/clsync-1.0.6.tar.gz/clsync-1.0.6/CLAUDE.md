# claudesync / clsync

## Tagging & Releases
- Do NOT create a git tag without explicit user confirmation first.
- Batch multiple small fixes into a single version bump + tag rather than tagging every individual change.
- Version bumps go in the same commit as the code change they belong to.
