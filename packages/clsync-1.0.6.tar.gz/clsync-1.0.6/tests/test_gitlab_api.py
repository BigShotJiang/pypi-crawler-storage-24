"""Tests for src/claude_sync/gitlab_api.py."""
import time
from unittest.mock import MagicMock, patch

import pytest

from claude_sync.gitlab_api import (
    trigger_pipeline,
    get_pipeline_status,
    get_failed_job_log,
    wait_for_pipeline,
    _diagnose_log,
)
from claude_sync.models import Config, ClientConfig, GitLabConfig, RepoConfig


def make_config(trigger_token="tok-trigger", access_token="tok-access") -> Config:
    return Config(
        client=ClientConfig(machine_id="test"),
        gitlab=GitLabConfig(
            url="https://gitlab.example.com",
            project_id=42,
            trigger_token=trigger_token,
            access_token=access_token,
        ),
        repo=RepoConfig(local_path="/tmp/repo"),
    )


# ---------------------------------------------------------------------------
# trigger_pipeline
# ---------------------------------------------------------------------------

@patch("claude_sync.gitlab_api.httpx.post")
def test_trigger_pipeline_success(mock_post):
    mock_post.return_value = MagicMock(status_code=201, json=lambda: {"id": 99})
    config = make_config()
    result = trigger_pipeline(config)
    assert result == 99
    mock_post.assert_called_once()
    call_url = mock_post.call_args[0][0]
    assert "/trigger/pipeline" in call_url


@patch("claude_sync.gitlab_api.httpx.post")
def test_trigger_pipeline_http_error(mock_post):
    mock_post.return_value = MagicMock(status_code=403, text="Forbidden")
    config = make_config()
    with pytest.raises(RuntimeError, match="403"):
        trigger_pipeline(config)


def test_trigger_pipeline_no_token():
    config = make_config(trigger_token="")
    with pytest.raises(RuntimeError, match="trigger token"):
        trigger_pipeline(config)


# ---------------------------------------------------------------------------
# get_pipeline_status
# ---------------------------------------------------------------------------

@patch("claude_sync.gitlab_api.httpx.get")
def test_get_pipeline_status_success(mock_get):
    mock_get.return_value = MagicMock(status_code=200, json=lambda: {"status": "running"})
    config = make_config()
    assert get_pipeline_status(config, 99) == "running"


@patch("claude_sync.gitlab_api.httpx.get")
def test_get_pipeline_status_http_error(mock_get):
    mock_get.return_value = MagicMock(status_code=404, text="Not Found")
    config = make_config()
    with pytest.raises(RuntimeError, match="404"):
        get_pipeline_status(config, 99)


def test_get_pipeline_status_no_token():
    config = make_config(access_token="")
    with pytest.raises(RuntimeError, match="access token"):
        get_pipeline_status(config, 99)


# ---------------------------------------------------------------------------
# get_failed_job_log
# ---------------------------------------------------------------------------

@patch("claude_sync.gitlab_api.httpx.get")
def test_get_failed_job_log_returns_last_50_lines(mock_get):
    jobs_response = MagicMock(
        status_code=200,
        json=lambda: [{"id": 10, "status": "failed"}],
    )
    trace_lines = [f"line {i}" for i in range(100)]
    trace_response = MagicMock(status_code=200, text="\n".join(trace_lines))
    mock_get.side_effect = [jobs_response, trace_response]

    config = make_config()
    log = get_failed_job_log(config, 99)
    assert log is not None
    assert log.count("\n") == 49  # 50 lines, 49 newlines


@patch("claude_sync.gitlab_api.httpx.get")
def test_get_failed_job_log_no_failed_jobs(mock_get):
    mock_get.return_value = MagicMock(
        status_code=200,
        json=lambda: [{"id": 10, "status": "success"}],
    )
    config = make_config()
    assert get_failed_job_log(config, 99) is None


@patch("claude_sync.gitlab_api.httpx.get")
def test_get_failed_job_log_jobs_api_error(mock_get):
    mock_get.return_value = MagicMock(status_code=500)
    config = make_config()
    assert get_failed_job_log(config, 99) is None


def test_get_failed_job_log_no_access_token():
    config = make_config(access_token="")
    assert get_failed_job_log(config, 99) is None


@patch("claude_sync.gitlab_api.httpx.get", side_effect=Exception("network"))
def test_get_failed_job_log_exception_returns_none(mock_get):
    config = make_config()
    assert get_failed_job_log(config, 99) is None


# ---------------------------------------------------------------------------
# _diagnose_log
# ---------------------------------------------------------------------------

def test_diagnose_push_denied():
    result = _diagnose_log("remote: not allowed to push to this repo")
    assert result is not None
    assert "push" in result.lower()


def test_diagnose_403_push():
    result = _diagnose_log("error: 403 Forbidden when trying to Push")
    assert result is not None
    assert "push" in result.lower()


def test_diagnose_api_key_missing():
    result = _diagnose_log("Error: ANTHROPIC_API_KEY not set")
    assert result is not None
    assert "API key" in result


def test_diagnose_auth_error():
    result = _diagnose_log("anthropic.AuthenticationError: invalid x-api-key")
    assert result is not None
    assert "API key" in result


def test_diagnose_unknown_log():
    assert _diagnose_log("Some random error we don't recognize") is None


def test_diagnose_empty_log():
    assert _diagnose_log("") is None


# ---------------------------------------------------------------------------
# wait_for_pipeline
# ---------------------------------------------------------------------------

@patch("claude_sync.gitlab_api.get_pipeline_status")
@patch("claude_sync.gitlab_api.time.sleep")
@patch("claude_sync.gitlab_api.console")
def test_wait_returns_on_success(mock_console, mock_sleep, mock_status):
    mock_status.side_effect = ["pending", "running", "success"]
    config = make_config()
    result = wait_for_pipeline(config, 99, timeout=60, poll_interval=1)
    assert result == "success"
    assert mock_sleep.call_count == 2  # slept twice before terminal state


@patch("claude_sync.gitlab_api.get_pipeline_status")
@patch("claude_sync.gitlab_api.time.sleep")
@patch("claude_sync.gitlab_api.console")
def test_wait_returns_on_failed(mock_console, mock_sleep, mock_status):
    mock_status.return_value = "failed"
    config = make_config()
    result = wait_for_pipeline(config, 99, timeout=60, poll_interval=1)
    assert result == "failed"


@patch("claude_sync.gitlab_api.get_pipeline_status")
@patch("claude_sync.gitlab_api.time.sleep")
@patch("claude_sync.gitlab_api.time.monotonic")
@patch("claude_sync.gitlab_api.console")
def test_wait_timeout_raises(mock_console, mock_monotonic, mock_sleep, mock_status):
    # Simulate time passing beyond deadline
    mock_monotonic.side_effect = [0, 1, 301]  # first call sets deadline=300, then 1<300, then 301>300
    mock_status.return_value = "running"
    config = make_config()
    with pytest.raises(TimeoutError, match="terminal state"):
        wait_for_pipeline(config, 99, timeout=300, poll_interval=1)


@patch("claude_sync.gitlab_api.get_pipeline_status")
@patch("claude_sync.gitlab_api.time.sleep")
@patch("claude_sync.gitlab_api.console")
def test_wait_returns_on_canceled(mock_console, mock_sleep, mock_status):
    mock_status.return_value = "canceled"
    config = make_config()
    result = wait_for_pipeline(config, 99, timeout=60, poll_interval=1)
    assert result == "canceled"
