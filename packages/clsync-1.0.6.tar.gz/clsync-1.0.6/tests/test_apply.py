import pytest
from pathlib import Path

from claude_sync.models import Config, ClientConfig, GitLabConfig, RepoConfig, ProjectsConfig, SafetyConfig
from claude_sync.apply import apply_consolidated, check_large_diff


def make_config(repo_path: Path, project_paths=None, backup=True) -> Config:
    return Config(
        client=ClientConfig(machine_id="test-machine"),
        gitlab=GitLabConfig(url="https://gitlab.example.com", project_id=1),
        repo=RepoConfig(local_path=repo_path),
        projects=ProjectsConfig(paths=project_paths or []),
        safety=SafetyConfig(backup_before_apply=backup),
    )


@pytest.fixture
def home_dir(tmp_path, monkeypatch):
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    monkeypatch.setattr(Path, "home", staticmethod(lambda: fake_home))
    return fake_home


@pytest.fixture
def repo(tmp_path):
    r = tmp_path / "repo"
    r.mkdir()
    return r


def make_consolidated(repo: Path, scope: str, content: str) -> Path:
    """Write a consolidated CLAUDE.md for the given scope."""
    parts = scope.split("/")
    dest = repo / "consolidated"
    for part in parts:
        dest = dest / part
    dest = dest / "CLAUDE.md"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(content)
    return dest


# --- apply_consolidated tests ---

def test_apply_global(home_dir, repo):
    make_consolidated(repo, "global", "# Consolidated Global")
    config = make_config(repo, backup=False)
    applied = apply_consolidated(config)

    dest = home_dir / ".claude" / "CLAUDE.md"
    assert dest.exists()
    assert dest.read_text() == "# Consolidated Global"
    assert "global" in applied


def test_apply_project(home_dir, repo, tmp_path):
    project = tmp_path / "my-proj"
    (project / ".claude").mkdir(parents=True)
    make_consolidated(repo, "projects/my-proj", "# Project Consolidated")

    config = make_config(repo, project_paths=[project], backup=False)
    applied = apply_consolidated(config)

    dest = project / ".claude" / "CLAUDE.md"
    assert dest.exists()
    assert dest.read_text() == "# Project Consolidated"
    assert "projects/my-proj" in applied


def test_backup_created_before_apply(home_dir, repo):
    # Pre-existing file
    claude_dir = home_dir / ".claude"
    claude_dir.mkdir()
    (claude_dir / "CLAUDE.md").write_text("old content")

    make_consolidated(repo, "global", "new content")
    config = make_config(repo, backup=True)
    apply_consolidated(config)

    backups = list((claude_dir / "backups").iterdir())
    assert len(backups) == 1
    backup_file = backups[0] / "CLAUDE.md"
    assert backup_file.exists()
    assert backup_file.read_text() == "old content"


def test_no_backup_when_disabled(home_dir, repo):
    claude_dir = home_dir / ".claude"
    claude_dir.mkdir()
    (claude_dir / "CLAUDE.md").write_text("old content")

    make_consolidated(repo, "global", "new content")
    config = make_config(repo, backup=False)
    apply_consolidated(config)

    assert not (claude_dir / "backups").exists()


def test_skip_scopes_global(home_dir, repo):
    make_consolidated(repo, "global", "# Should not apply")
    config = make_config(repo, backup=False)
    applied = apply_consolidated(config, skip_scopes={"global"})

    dest = home_dir / ".claude" / "CLAUDE.md"
    assert not dest.exists()
    assert "global" not in applied


def test_skip_scopes_project(home_dir, repo, tmp_path):
    project = tmp_path / "my-proj"
    (project / ".claude").mkdir(parents=True)
    make_consolidated(repo, "projects/my-proj", "# Should not apply")

    config = make_config(repo, project_paths=[project], backup=False)
    applied = apply_consolidated(config, skip_scopes={"projects/my-proj"})

    dest = project / ".claude" / "CLAUDE.md"
    assert not dest.exists()
    assert "projects/my-proj" not in applied


def test_unknown_project_warns_and_skips(home_dir, repo, capsys):
    make_consolidated(repo, "projects/unknown-proj", "# Unknown")
    config = make_config(repo, project_paths=[], backup=False)
    applied = apply_consolidated(config)

    captured = capsys.readouterr()
    assert "unknown-proj" in captured.out
    assert "projects/unknown-proj" not in applied


def test_no_consolidated_global_skipped(home_dir, repo):
    config = make_config(repo, backup=False)
    applied = apply_consolidated(config)
    assert "global" not in applied


# --- settings.json and memory/ apply tests ---

def test_apply_global_settings_json(home_dir, repo):
    (home_dir / ".claude").mkdir()
    make_consolidated(repo, "global", "# Global")
    settings_src = repo / "consolidated" / "global" / "settings.json"
    settings_src.write_text('{"theme":"dark"}')

    config = make_config(repo, backup=False)
    apply_consolidated(config)

    dest = home_dir / ".claude" / "settings.json"
    assert dest.exists()
    assert dest.read_text() == '{"theme":"dark"}'


def test_apply_project_memory(home_dir, repo, tmp_path):
    from claude_sync.claude_paths import claude_memory_dir

    project = tmp_path / "mem-proj"
    (project / ".claude").mkdir(parents=True)

    make_consolidated(repo, "projects/mem-proj", "# Proj")
    mem_src = repo / "consolidated" / "projects" / "mem-proj" / "memory" / "MEMORY.md"
    mem_src.parent.mkdir(parents=True, exist_ok=True)
    mem_src.write_text("# synced memory")

    config = make_config(repo, project_paths=[project], backup=False)

    # Patch home so claude_memory_dir resolves under tmp_path
    monkeypatch_home = home_dir  # home_dir fixture already patches Path.home
    apply_consolidated(config)

    dest = claude_memory_dir(project) / "MEMORY.md"
    assert dest.exists()
    assert dest.read_text() == "# synced memory"


def test_apply_removes_stale_memory_if_in_snapshot(home_dir, repo, tmp_path):
    """Memory files that were previously pushed but removed from consolidated should be deleted locally."""
    from claude_sync.claude_paths import claude_memory_dir

    project = tmp_path / "stale-proj"
    (project / ".claude").mkdir(parents=True)

    # Set up consolidated with one memory file
    make_consolidated(repo, "projects/stale-proj", "# Proj")
    con_mem = repo / "consolidated" / "projects" / "stale-proj" / "memory"
    con_mem.mkdir(parents=True, exist_ok=True)
    (con_mem / "MEMORY.md").write_text("# keep")

    # Set up machine snapshot with an extra file (previously pushed)
    machine_mem = repo / "machines" / "test-machine" / "projects" / "stale-proj" / "memory"
    machine_mem.mkdir(parents=True, exist_ok=True)
    (machine_mem / "MEMORY.md").write_text("# keep")
    (machine_mem / "old-notes.md").write_text("# was pushed before")

    # Pre-populate local memory with the stale file
    dest_memory = claude_memory_dir(project)
    dest_memory.mkdir(parents=True, exist_ok=True)
    (dest_memory / "MEMORY.md").write_text("# old version")
    (dest_memory / "old-notes.md").write_text("# stale local copy")

    config = make_config(repo, project_paths=[project], backup=False)
    apply_consolidated(config)

    assert (dest_memory / "MEMORY.md").read_text() == "# keep"
    assert not (dest_memory / "old-notes.md").exists()  # removed: in snapshot but not consolidated


def test_apply_preserves_local_only_memory(home_dir, repo, tmp_path):
    """Memory files that were never pushed (not in snapshot) should NOT be deleted."""
    from claude_sync.claude_paths import claude_memory_dir

    project = tmp_path / "local-proj"
    (project / ".claude").mkdir(parents=True)

    # Set up consolidated with one memory file
    make_consolidated(repo, "projects/local-proj", "# Proj")
    con_mem = repo / "consolidated" / "projects" / "local-proj" / "memory"
    con_mem.mkdir(parents=True, exist_ok=True)
    (con_mem / "MEMORY.md").write_text("# synced")

    # Machine snapshot has only MEMORY.md (no local-only.md)
    machine_mem = repo / "machines" / "test-machine" / "projects" / "local-proj" / "memory"
    machine_mem.mkdir(parents=True, exist_ok=True)
    (machine_mem / "MEMORY.md").write_text("# synced")

    # Local has an extra file that was never pushed
    dest_memory = claude_memory_dir(project)
    dest_memory.mkdir(parents=True, exist_ok=True)
    (dest_memory / "MEMORY.md").write_text("# old")
    (dest_memory / "local-only.md").write_text("# never pushed, keep me")

    config = make_config(repo, project_paths=[project], backup=False)
    apply_consolidated(config)

    assert (dest_memory / "MEMORY.md").read_text() == "# synced"
    assert (dest_memory / "local-only.md").exists()  # preserved: not in snapshot


# --- check_large_diff tests ---

def test_large_diff_returns_true(tmp_path):
    f1 = tmp_path / "a.md"
    f2 = tmp_path / "b.md"
    f1.write_text("\n".join(f"line {i}" for i in range(20)))
    f2.write_text("\n".join(f"completely different {i}" for i in range(20)))
    assert check_large_diff(f1, f2) is True


def test_small_diff_returns_false(tmp_path):
    f1 = tmp_path / "a.md"
    f2 = tmp_path / "b.md"
    lines = [f"line {i}" for i in range(20)]
    f1.write_text("\n".join(lines))
    # Change only 2 lines out of 20 — 10% different
    lines[0] = "changed line 0"
    lines[1] = "changed line 1"
    f2.write_text("\n".join(lines))
    assert check_large_diff(f1, f2) is False


def test_identical_files_returns_false(tmp_path):
    content = "# Same content\nline1\nline2\n"
    f1 = tmp_path / "a.md"
    f2 = tmp_path / "b.md"
    f1.write_text(content)
    f2.write_text(content)
    assert check_large_diff(f1, f2) is False


def test_both_empty_returns_false(tmp_path):
    f1 = tmp_path / "a.md"
    f2 = tmp_path / "b.md"
    f1.write_text("")
    f2.write_text("")
    assert check_large_diff(f1, f2) is False
