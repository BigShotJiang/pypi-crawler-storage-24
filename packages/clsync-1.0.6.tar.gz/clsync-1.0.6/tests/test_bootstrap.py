"""Tests for src/claude_sync/bootstrap.py."""
import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from claude_sync.bootstrap import (
    bootstrap_global,
    bootstrap_project,
    build_bootstrap_prompt,
    gather_global_context,
    gather_project_context,
)
from claude_sync.claude_paths import claude_memory_dir, claude_sessions_index


@pytest.fixture
def fake_home(tmp_path, monkeypatch):
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setattr(Path, "home", staticmethod(lambda: home))
    return home


@pytest.fixture
def project(tmp_path):
    p = tmp_path / "my-project"
    p.mkdir()
    (p / ".claude").mkdir()
    return p


# ---------------------------------------------------------------------------
# gather_project_context
# ---------------------------------------------------------------------------

def test_gather_project_context_empty(project, fake_home):
    ctx = gather_project_context(project)
    assert ctx == {}


def test_gather_project_context_existing_claude_md(project, fake_home):
    (project / ".claude" / "CLAUDE.md").write_text("# existing")
    ctx = gather_project_context(project)
    assert ctx["existing_claude_md"] == "# existing"


def test_gather_project_context_memory_files(project, fake_home):
    mem_dir = claude_memory_dir(project)
    mem_dir.mkdir(parents=True)
    (mem_dir / "MEMORY.md").write_text("some memory")
    ctx = gather_project_context(project)
    assert "MEMORY.md" in ctx["memory_files"]
    assert ctx["memory_files"]["MEMORY.md"] == "some memory"


def test_gather_project_context_session_summaries(project, fake_home):
    sessions = claude_sessions_index(project)
    sessions.parent.mkdir(parents=True, exist_ok=True)
    sessions.write_text(json.dumps([
        {"summary": "Built the thing"},
        {"summary": "Fixed the bug"},
    ]))
    ctx = gather_project_context(project)
    assert ctx["session_summaries"] == ["Built the thing", "Fixed the bug"]


def test_gather_project_context_ignores_bad_sessions_json(project, fake_home):
    sessions = claude_sessions_index(project)
    sessions.parent.mkdir(parents=True, exist_ok=True)
    sessions.write_text("not valid json{{{")
    ctx = gather_project_context(project)
    assert "session_summaries" not in ctx


# ---------------------------------------------------------------------------
# gather_global_context
# ---------------------------------------------------------------------------

def test_gather_global_context_empty(project, fake_home):
    ctx = gather_global_context([project])
    assert ctx == {}


def test_gather_global_context_settings(project, fake_home):
    (fake_home / ".claude").mkdir(parents=True)
    (fake_home / ".claude" / "settings.json").write_text('{"theme": "dark"}')
    ctx = gather_global_context([project])
    assert ctx["settings"] == '{"theme": "dark"}'


def test_gather_global_context_existing_claude_md(project, fake_home):
    (fake_home / ".claude").mkdir(parents=True)
    (fake_home / ".claude" / "CLAUDE.md").write_text("# global")
    ctx = gather_global_context([project])
    assert ctx["existing_claude_md"] == "# global"


def test_gather_global_context_collects_project_memory(project, fake_home):
    mem_dir = claude_memory_dir(project)
    mem_dir.mkdir(parents=True)
    (mem_dir / "MEMORY.md").write_text("project memory")
    ctx = gather_global_context([project])
    assert "my-project" in ctx["all_memory_files"]


# ---------------------------------------------------------------------------
# build_bootstrap_prompt
# ---------------------------------------------------------------------------

def test_build_bootstrap_prompt_project_scope(project, fake_home):
    ctx = {"memory_files": {"MEMORY.md": "some notes"}}
    prompt = build_bootstrap_prompt(ctx, f"projects/{project.name}")
    assert "MEMORY FILES" in prompt
    assert "some notes" in prompt
    assert "{CONTEXT_SECTIONS}" not in prompt
    assert "{SCOPE_INSTRUCTION}" not in prompt
    assert "specific to this project" in prompt


def test_build_bootstrap_prompt_global_scope(fake_home):
    ctx = {"all_session_summaries": {"proj": ["did stuff"]}}
    prompt = build_bootstrap_prompt(ctx, "global")
    assert "cross-project" in prompt
    assert "SESSION SUMMARIES" in prompt


# ---------------------------------------------------------------------------
# bootstrap_project / bootstrap_global
# ---------------------------------------------------------------------------

def test_bootstrap_project_writes_file(project, fake_home):
    mem_dir = claude_memory_dir(project)
    mem_dir.mkdir(parents=True)
    (mem_dir / "MEMORY.md").write_text("remember this")

    with patch("claude_sync.bootstrap.generate_claude_md", return_value="# Generated"):
        result = bootstrap_project(project, api_key="test-key")

    assert result == "# Generated"
    dest = project / ".claude" / "CLAUDE.md"
    assert dest.read_text() == "# Generated"


def test_bootstrap_project_no_context_returns_none(project, fake_home):
    with patch("claude_sync.bootstrap.generate_claude_md") as mock_gen:
        result = bootstrap_project(project, api_key="test-key")

    mock_gen.assert_not_called()
    assert result is None


def test_bootstrap_global_writes_file(project, fake_home):
    mem_dir = claude_memory_dir(project)
    mem_dir.mkdir(parents=True)
    (mem_dir / "MEMORY.md").write_text("global memory")

    (fake_home / ".claude").mkdir(parents=True, exist_ok=True)

    with patch("claude_sync.bootstrap.generate_claude_md", return_value="# Global"):
        result = bootstrap_global([project], api_key="test-key")

    assert result == "# Global"
    dest = fake_home / ".claude" / "CLAUDE.md"
    assert dest.read_text() == "# Global"


def test_bootstrap_global_no_context_returns_none(project, fake_home):
    with patch("claude_sync.bootstrap.generate_claude_md") as mock_gen:
        result = bootstrap_global([project], api_key="test-key")

    mock_gen.assert_not_called()
    assert result is None
