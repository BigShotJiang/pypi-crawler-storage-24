"""Tests for src/claude_sync/lock.py."""
import subprocess
from unittest.mock import MagicMock, patch

from claude_sync.lock import is_claude_code_running


# ---------------------------------------------------------------------------
# Windows path (tasklist)
# ---------------------------------------------------------------------------

@patch("claude_sync.lock.platform")
@patch("claude_sync.lock.subprocess.run")
def test_windows_claude_running(mock_run, mock_platform):
    mock_platform.system.return_value = "Windows"
    mock_run.return_value = MagicMock(
        stdout='"System Idle Process","0","Services","0","8 K"\n'
               '"claude.exe","1234","Console","1","50,000 K"\n',
    )
    assert is_claude_code_running() is True


@patch("claude_sync.lock.platform")
@patch("claude_sync.lock.subprocess.run")
def test_windows_claude_not_running(mock_run, mock_platform):
    mock_platform.system.return_value = "Windows"
    mock_run.return_value = MagicMock(
        stdout='"explorer.exe","2000","Console","1","80,000 K"\n'
               '"python.exe","3000","Console","1","40,000 K"\n',
    )
    assert is_claude_code_running() is False


@patch("claude_sync.lock.platform")
@patch("claude_sync.lock.subprocess.run")
def test_windows_ignores_claude_sync(mock_run, mock_platform):
    """claude-sync.exe should NOT match — only claude.exe."""
    mock_platform.system.return_value = "Windows"
    mock_run.return_value = MagicMock(
        stdout='"claude-sync.exe","5000","Console","1","30,000 K"\n',
    )
    assert is_claude_code_running() is False


@patch("claude_sync.lock.platform")
@patch("claude_sync.lock.subprocess.run")
def test_windows_empty_output(mock_run, mock_platform):
    mock_platform.system.return_value = "Windows"
    mock_run.return_value = MagicMock(stdout="")
    assert is_claude_code_running() is False


# ---------------------------------------------------------------------------
# Linux/macOS path (pgrep)
# ---------------------------------------------------------------------------

@patch("claude_sync.lock.platform")
@patch("claude_sync.lock.subprocess.run")
@patch("claude_sync.lock.os.getpid", return_value=100)
@patch("claude_sync.lock.os.getppid", return_value=99)
def test_linux_claude_running(mock_ppid, mock_pid, mock_run, mock_platform):
    mock_platform.system.return_value = "Linux"
    mock_run.return_value = MagicMock(
        returncode=0,
        stdout=b"5678\n",
    )
    assert is_claude_code_running() is True


@patch("claude_sync.lock.platform")
@patch("claude_sync.lock.subprocess.run")
def test_linux_pgrep_no_match(mock_run, mock_platform):
    mock_platform.system.return_value = "Linux"
    mock_run.return_value = MagicMock(returncode=1)
    assert is_claude_code_running() is False


@patch("claude_sync.lock.platform")
@patch("claude_sync.lock.subprocess.run")
@patch("claude_sync.lock.os.getpid", return_value=100)
@patch("claude_sync.lock.os.getppid", return_value=99)
def test_linux_filters_own_pid(mock_ppid, mock_pid, mock_run, mock_platform):
    """If pgrep only returns our own PID, should return False."""
    mock_platform.system.return_value = "Linux"
    mock_run.return_value = MagicMock(
        returncode=0,
        stdout=b"100\n",
    )
    assert is_claude_code_running() is False


@patch("claude_sync.lock.platform")
@patch("claude_sync.lock.subprocess.run")
@patch("claude_sync.lock.os.getpid", return_value=100)
@patch("claude_sync.lock.os.getppid", return_value=99)
def test_linux_filters_own_ppid(mock_ppid, mock_pid, mock_run, mock_platform):
    """If pgrep only returns our parent PID, should return False."""
    mock_platform.system.return_value = "Linux"
    mock_run.return_value = MagicMock(
        returncode=0,
        stdout=b"99\n",
    )
    assert is_claude_code_running() is False


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

@patch("claude_sync.lock.platform")
@patch("claude_sync.lock.subprocess.run", side_effect=Exception("boom"))
def test_exception_returns_false(mock_run, mock_platform):
    mock_platform.system.return_value = "Windows"
    assert is_claude_code_running() is False


@patch("claude_sync.lock.platform")
@patch("claude_sync.lock.subprocess.run", side_effect=subprocess.TimeoutExpired("cmd", 5))
def test_timeout_returns_false(mock_run, mock_platform):
    mock_platform.system.return_value = "Windows"
    assert is_claude_code_running() is False
