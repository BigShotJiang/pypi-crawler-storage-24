"""Tests for src/claude_sync/scaffold.py."""
from pathlib import Path

from claude_sync.scaffold import scaffold_sync_repo, _COMMON_FILES, _PROVIDER_FILES


def _all_files(provider: str = "gitlab") -> list[tuple[str, str]]:
    return _COMMON_FILES + _PROVIDER_FILES.get(provider, [])


def test_scaffold_gitlab_creates_all_files(tmp_path):
    written = scaffold_sync_repo(tmp_path, provider="gitlab")
    expected = _all_files("gitlab")
    assert len(written) == len(expected)
    for dest_rel, _ in expected:
        assert (tmp_path / dest_rel).exists(), f"Missing: {dest_rel}"


def test_scaffold_github_creates_all_files(tmp_path):
    written = scaffold_sync_repo(tmp_path, provider="github")
    expected = _all_files("github")
    assert len(written) == len(expected)
    for dest_rel, _ in expected:
        assert (tmp_path / dest_rel).exists(), f"Missing: {dest_rel}"


def test_scaffold_local_creates_no_ci_file(tmp_path):
    written = scaffold_sync_repo(tmp_path, provider="local")
    # local has no CI file — only common pipeline files
    assert ".gitlab-ci.yml" not in written
    assert ".github/workflows/synthesize.yml" not in written
    assert len(written) == len(_COMMON_FILES)


def test_scaffold_returns_relative_paths(tmp_path):
    written = scaffold_sync_repo(tmp_path, provider="gitlab")
    expected = [dest_rel for dest_rel, _ in _all_files("gitlab")]
    assert written == expected


def test_scaffold_skips_existing_files(tmp_path):
    # Pre-create one file
    gitlab_ci = tmp_path / ".gitlab-ci.yml"
    gitlab_ci.parent.mkdir(parents=True, exist_ok=True)
    gitlab_ci.write_text("# custom CI config")

    written = scaffold_sync_repo(tmp_path, provider="gitlab")
    assert ".gitlab-ci.yml" not in written
    # Pre-existing file should be untouched
    assert gitlab_ci.read_text() == "# custom CI config"


def test_scaffold_creates_nested_dirs(tmp_path):
    scaffold_sync_repo(tmp_path, provider="gitlab")
    assert (tmp_path / "pipeline" / "prompts").is_dir()
    assert (tmp_path / "pipeline" / "synthesize.py").exists()
    assert (tmp_path / "pipeline" / "models.py").exists()


def test_scaffold_github_creates_workflow_dir(tmp_path):
    scaffold_sync_repo(tmp_path, provider="github")
    assert (tmp_path / ".github" / "workflows" / "synthesize.yml").exists()


def test_scaffold_idempotent(tmp_path):
    first = scaffold_sync_repo(tmp_path, provider="gitlab")
    second = scaffold_sync_repo(tmp_path, provider="gitlab")
    assert len(second) == 0
    assert len(first) == len(_all_files("gitlab"))


def test_scaffold_files_are_non_empty(tmp_path):
    scaffold_sync_repo(tmp_path, provider="gitlab")
    for dest_rel, _ in _all_files("gitlab"):
        content = (tmp_path / dest_rel).read_bytes()
        assert len(content) > 0, f"Empty file: {dest_rel}"


def test_scaffold_dotfiles_created_correctly(tmp_path):
    """Dotfiles stored without dot prefix in templates should be written with dot."""
    scaffold_sync_repo(tmp_path, provider="gitlab")
    assert (tmp_path / ".gitlab-ci.yml").exists()
    assert (tmp_path / ".gitignore").exists()
