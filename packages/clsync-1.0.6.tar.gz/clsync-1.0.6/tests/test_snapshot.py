import pytest
from pathlib import Path

from claude_sync.models import Config, ClientConfig, GitLabConfig, RepoConfig, ProjectsConfig
from claude_sync.snapshot import snapshot


def make_config(repo_path: Path, project_paths=None, auto_discover=False,
                discover_roots=None, discover_max_depth=2) -> Config:
    return Config(
        client=ClientConfig(machine_id="test-machine"),
        gitlab=GitLabConfig(url="https://gitlab.example.com", project_id=1),
        repo=RepoConfig(local_path=repo_path),
        projects=ProjectsConfig(
            paths=project_paths or [],
            auto_discover=auto_discover,
            discover_roots=discover_roots or [],
            discover_max_depth=discover_max_depth,
        ),
    )


@pytest.fixture
def home_claude(tmp_path, monkeypatch):
    """Fake ~/.claude/ directory."""
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    monkeypatch.setattr(Path, "home", staticmethod(lambda: fake_home))
    claude_dir = fake_home / ".claude"
    claude_dir.mkdir()
    return claude_dir


@pytest.fixture
def repo(tmp_path):
    repo_path = tmp_path / "repo"
    repo_path.mkdir()
    return repo_path


def test_global_claude_md_copied(home_claude, repo):
    (home_claude / "CLAUDE.md").write_text("# Global\nsome content")
    config = make_config(repo)

    updated = snapshot(config)

    dest = repo / "machines" / "test-machine" / "global" / "CLAUDE.md"
    assert dest.exists()
    assert dest.read_text() == "# Global\nsome content"
    assert "global" in updated


def test_global_claude_md_missing_skipped(home_claude, repo):
    # No CLAUDE.md in ~/.claude/
    config = make_config(repo)
    updated = snapshot(config)
    assert "global" not in updated


def test_project_claude_md_copied(home_claude, repo, tmp_path):
    project = tmp_path / "my-project"
    (project / ".claude").mkdir(parents=True)
    (project / ".claude" / "CLAUDE.md").write_text("# Project")

    config = make_config(repo, project_paths=[project])
    updated = snapshot(config)

    dest = repo / "machines" / "test-machine" / "projects" / "my-project" / "CLAUDE.md"
    assert dest.exists()
    assert "projects/my-project" in updated


def test_unchanged_file_not_recopied(home_claude, repo):
    content = "# Global\nsome content"
    (home_claude / "CLAUDE.md").write_text(content)

    config = make_config(repo)
    snapshot(config)  # first run

    # Verify destination exists
    dest = repo / "machines" / "test-machine" / "global" / "CLAUDE.md"
    mtime_before = dest.stat().st_mtime

    updated = snapshot(config)  # second run, no changes

    assert "global" not in updated
    assert dest.stat().st_mtime == mtime_before


def test_changed_file_is_recopied(home_claude, repo):
    (home_claude / "CLAUDE.md").write_text("version 1")
    config = make_config(repo)
    snapshot(config)

    (home_claude / "CLAUDE.md").write_text("version 2")
    updated = snapshot(config)

    assert "global" in updated
    dest = repo / "machines" / "test-machine" / "global" / "CLAUDE.md"
    assert dest.read_text() == "version 2"


def test_global_settings_json_copied(home_claude, repo):
    (home_claude / "settings.json").write_text('{"theme":"dark"}')
    config = make_config(repo)

    updated = snapshot(config)

    dest = repo / "machines" / "test-machine" / "global" / "settings.json"
    assert dest.exists()
    assert dest.read_text() == '{"theme":"dark"}'
    assert "global" in updated


def test_memory_files_copied(home_claude, repo, tmp_path):
    from claude_sync.claude_paths import claude_memory_dir

    project = tmp_path / "my-proj"
    (project / ".claude").mkdir(parents=True)

    mem_dir = claude_memory_dir(project)
    mem_dir.mkdir(parents=True)
    (mem_dir / "MEMORY.md").write_text("# remember this")

    config = make_config(repo, project_paths=[project])
    updated = snapshot(config)

    dest = repo / "machines" / "test-machine" / "projects" / "my-proj" / "memory" / "MEMORY.md"
    assert dest.exists()
    assert dest.read_text() == "# remember this"
    assert "projects/my-proj" in updated


def test_deleted_global_md_removed_from_repo(home_claude, repo):
    """If CLAUDE.md is deleted locally, it should be removed from the sync repo."""
    (home_claude / "CLAUDE.md").write_text("# Global")
    config = make_config(repo)
    snapshot(config)  # first run — copies file

    dest = repo / "machines" / "test-machine" / "global" / "CLAUDE.md"
    assert dest.exists()

    # Delete locally
    (home_claude / "CLAUDE.md").unlink()
    updated = snapshot(config)

    assert "global" in updated
    assert not dest.exists()


def test_deleted_project_md_removed_from_repo(home_claude, repo, tmp_path):
    """If a project CLAUDE.md is deleted locally, it should be removed from the sync repo."""
    project = tmp_path / "my-proj"
    (project / ".claude").mkdir(parents=True)
    (project / ".claude" / "CLAUDE.md").write_text("# Project")

    config = make_config(repo, project_paths=[project])
    snapshot(config)

    dest = repo / "machines" / "test-machine" / "projects" / "my-proj" / "CLAUDE.md"
    assert dest.exists()

    (project / ".claude" / "CLAUDE.md").unlink()
    updated = snapshot(config)

    assert "projects/my-proj" in updated
    assert not dest.exists()


def test_deleted_memory_file_removed_from_repo(home_claude, repo, tmp_path):
    """If a memory file is deleted locally, it should be removed from the sync repo."""
    from claude_sync.claude_paths import claude_memory_dir

    project = tmp_path / "my-proj"
    (project / ".claude").mkdir(parents=True)

    mem_dir = claude_memory_dir(project)
    mem_dir.mkdir(parents=True)
    (mem_dir / "MEMORY.md").write_text("# remember this")
    (mem_dir / "patterns.md").write_text("# patterns")

    config = make_config(repo, project_paths=[project])
    snapshot(config)

    dest_mem = repo / "machines" / "test-machine" / "projects" / "my-proj" / "memory"
    assert (dest_mem / "MEMORY.md").exists()
    assert (dest_mem / "patterns.md").exists()

    # Delete one memory file locally
    (mem_dir / "patterns.md").unlink()
    updated = snapshot(config)

    assert "projects/my-proj" in updated
    assert (dest_mem / "MEMORY.md").exists()
    assert not (dest_mem / "patterns.md").exists()


def test_deleted_memory_dir_removed_from_repo(home_claude, repo, tmp_path):
    """If the entire memory dir is deleted locally, it should be removed from the sync repo."""
    import shutil
    from claude_sync.claude_paths import claude_memory_dir

    project = tmp_path / "my-proj"
    (project / ".claude").mkdir(parents=True)

    mem_dir = claude_memory_dir(project)
    mem_dir.mkdir(parents=True)
    (mem_dir / "MEMORY.md").write_text("# remember this")

    config = make_config(repo, project_paths=[project])
    snapshot(config)

    dest_mem = repo / "machines" / "test-machine" / "projects" / "my-proj" / "memory"
    assert dest_mem.exists()

    # Delete entire memory dir locally
    shutil.rmtree(mem_dir)
    updated = snapshot(config)

    assert "projects/my-proj" in updated
    assert not dest_mem.exists()


def test_auto_discover_finds_projects(home_claude, repo, tmp_path):
    root = tmp_path / "projects"
    root.mkdir()
    proj_a = root / "proj-a"
    (proj_a / ".claude").mkdir(parents=True)
    # No CLAUDE.md needed — auto_discover now finds any .claude/ dir
    (proj_a / ".claude" / "CLAUDE.md").write_text("# proj-a")

    config = make_config(repo, auto_discover=True, discover_roots=[root], discover_max_depth=2)
    updated = snapshot(config)

    assert "projects/proj-a" in updated


def test_auto_discover_finds_project_without_claude_md(home_claude, repo, tmp_path):
    """auto_discover should find .claude/ directories even without a CLAUDE.md."""
    root = tmp_path / "projects"
    root.mkdir()
    proj = root / "no-md-proj"
    (proj / ".claude").mkdir(parents=True)
    # No CLAUDE.md — but has a memory file
    mem_dir = home_claude.parent / ".claude" / "projects"
    # Use a fake slug approach: just verify discover picks it up
    # (actual memory snapshot is tested separately)

    config = make_config(repo, auto_discover=True, discover_roots=[root], discover_max_depth=2)
    # snapshot won't produce output (nothing to copy), but discover finds it
    from claude_sync.snapshot import _collect_project_paths
    paths = _collect_project_paths(config)
    assert any(p.name == "no-md-proj" for p in paths)


def test_auto_discover_respects_max_depth(home_claude, repo, tmp_path):
    root = tmp_path / "projects"
    root.mkdir()
    # Depth 1: root/level1/  — should be found at depth=1
    level1 = root / "level1"
    (level1 / ".claude").mkdir(parents=True)
    (level1 / ".claude" / "CLAUDE.md").write_text("# level1")
    # Depth 2: root/level1/level2/ — found at depth=2
    level2 = level1 / "level2"
    (level2 / ".claude").mkdir(parents=True)
    (level2 / ".claude" / "CLAUDE.md").write_text("# level2")
    # Depth 3: root/level1/level2/level3/ — should NOT be found at depth=2
    level3 = level2 / "level3"
    (level3 / ".claude").mkdir(parents=True)
    (level3 / ".claude" / "CLAUDE.md").write_text("# level3")

    config = make_config(repo, auto_discover=True, discover_roots=[root], discover_max_depth=2)
    updated = snapshot(config)

    assert "projects/level1" in updated
    assert "projects/level2" in updated
    assert "projects/level3" not in updated


def test_auto_discover_deduplicates(home_claude, repo, tmp_path):
    root = tmp_path / "projects"
    root.mkdir()
    proj = root / "proj"
    (proj / ".claude").mkdir(parents=True)
    (proj / ".claude" / "CLAUDE.md").write_text("# proj")

    # Pass same project both explicitly and via auto_discover
    config = make_config(
        repo,
        project_paths=[proj],
        auto_discover=True,
        discover_roots=[root],
        discover_max_depth=1,
    )
    updated = snapshot(config)

    assert updated.count("projects/proj") == 1
