# Project Guidelines

## Code Style
- Use 4 spaces for indentation in Python
- Follow PEP 8 conventions
- Maximum line length: 120 characters

## Testing
- Write tests before implementation (TDD)
- Use pytest for all tests
- Run tests with `pytest -x` to stop on first failure

## Git
- Commit messages must follow conventional commits format
- Squash commits before merging to main

## Dependencies
- Use uv for Python dependency management
- Pin all dependencies to exact versions in production
