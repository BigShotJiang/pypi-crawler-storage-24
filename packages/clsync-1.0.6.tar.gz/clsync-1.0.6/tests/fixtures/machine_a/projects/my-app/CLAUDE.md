# my-app Project Context

## Architecture
- FastAPI backend, React frontend
- PostgreSQL database, Redis for caching
- Deployed on Kubernetes

## Commands
- `make dev` — start local dev stack
- `make test` — run full test suite
- `make lint` — run ruff + mypy
