# Project Guidelines

## Code Style
- Use 4 spaces for indentation in Python
- Follow PEP 8 conventions
- Maximum line length: 100 characters

## Testing
- Write tests before implementation (TDD)
- Use pytest for all tests
- Aim for 80% coverage minimum

## Git
- Commit messages must follow conventional commits format
- Always rebase before merging
