"""
Tests for pipeline/synthesize.py.

Because synthesize.py uses REPO_ROOT-relative paths and imports from pipeline/models.py
(not the client package), we manipulate sys.path and monkeypatch module-level constants.
"""
import hashlib
import json
import sys
import types
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# Make pipeline/ importable
PIPELINE_DIR = Path(__file__).parent.parent / "pipeline"
if str(PIPELINE_DIR) not in sys.path:
    sys.path.insert(0, str(PIPELINE_DIR))

import synthesize as synth
from models import LastSynthesis, SyncLogEntry


# ---------------------------------------------------------------------------
# Helpers / fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def patch_dirs(tmp_path, monkeypatch):
    """Redirect all module-level path constants to tmp_path."""
    machines = tmp_path / "machines"
    consolidated = tmp_path / "consolidated"
    meta = tmp_path / "meta"
    machines.mkdir()
    consolidated.mkdir()
    meta.mkdir()

    monkeypatch.setattr(synth, "REPO_ROOT", tmp_path)
    monkeypatch.setattr(synth, "MACHINES_DIR", machines)
    monkeypatch.setattr(synth, "CONSOLIDATED_DIR", consolidated)
    monkeypatch.setattr(synth, "META_DIR", meta)
    return {"machines": machines, "consolidated": consolidated, "meta": meta}


def make_machine(machines_dir: Path, machine_id: str, scope: str, content: str) -> Path:
    parts = scope.split("/")
    path = machines_dir / machine_id
    for part in parts:
        path = path / part
    path = path / "CLAUDE.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    return path


def mock_api_response(text: str) -> MagicMock:
    msg = MagicMock()
    msg.content = [MagicMock(text=text)]
    return msg


# ---------------------------------------------------------------------------
# discover_scopes
# ---------------------------------------------------------------------------

def test_discover_scopes_global(patch_dirs):
    make_machine(patch_dirs["machines"], "desktop", "global", "# desktop global")
    scopes = synth.discover_scopes()
    assert "global" in scopes


def test_discover_scopes_project(patch_dirs):
    make_machine(patch_dirs["machines"], "desktop", "projects/my-app", "# my-app")
    scopes = synth.discover_scopes()
    assert "projects/my-app" in scopes


def test_discover_scopes_multiple_machines(patch_dirs):
    make_machine(patch_dirs["machines"], "desktop", "global", "# d global")
    make_machine(patch_dirs["machines"], "laptop", "global", "# l global")
    make_machine(patch_dirs["machines"], "laptop", "projects/proj", "# proj")
    scopes = synth.discover_scopes()
    assert scopes.count("global") == 1  # deduplicated
    assert "projects/proj" in scopes


def test_discover_scopes_empty(patch_dirs):
    assert synth.discover_scopes() == []


def test_discover_scopes_memory_only_no_claude_md(patch_dirs):
    """Scopes should be discovered from memory/ dirs even without CLAUDE.md."""
    machines = patch_dirs["machines"]
    mem_dir = machines / "desktop" / "projects" / "mem-only" / "memory"
    mem_dir.mkdir(parents=True)
    (mem_dir / "MEMORY.md").write_text("notes")
    scopes = synth.discover_scopes()
    assert "projects/mem-only" in scopes


# ---------------------------------------------------------------------------
# propagate_files
# ---------------------------------------------------------------------------

def test_propagate_memory_latest_wins(patch_dirs):
    """Memory files should be propagated with latest-wins per file."""
    import time
    machines = patch_dirs["machines"]

    # Desktop has an older MEMORY.md
    desk_mem = machines / "desktop" / "projects" / "proj" / "memory"
    desk_mem.mkdir(parents=True)
    (desk_mem / "MEMORY.md").write_text("desktop notes")
    # Also needs a CLAUDE.md for the scope to exist
    (machines / "desktop" / "projects" / "proj" / "CLAUDE.md").write_text("# d")

    # Ensure different mtimes
    time.sleep(0.05)

    # Laptop has a newer MEMORY.md
    lap_mem = machines / "laptop" / "projects" / "proj" / "memory"
    lap_mem.mkdir(parents=True)
    (lap_mem / "MEMORY.md").write_text("laptop notes")
    (machines / "laptop" / "projects" / "proj" / "CLAUDE.md").write_text("# l")

    synth.propagate_files("projects/proj")

    dest = patch_dirs["consolidated"] / "projects" / "proj" / "memory" / "MEMORY.md"
    assert dest.exists()
    assert dest.read_text() == "laptop notes"  # newer wins


def test_propagate_settings_json_latest_wins(patch_dirs):
    """settings.json should be propagated with latest mtime winning."""
    import time
    machines = patch_dirs["machines"]

    # Desktop has older settings
    (machines / "desktop" / "global").mkdir(parents=True)
    (machines / "desktop" / "global" / "CLAUDE.md").write_text("# d")
    (machines / "desktop" / "global" / "settings.json").write_text('{"old": true}')

    time.sleep(0.05)

    # Laptop has newer settings
    (machines / "laptop" / "global").mkdir(parents=True)
    (machines / "laptop" / "global" / "CLAUDE.md").write_text("# l")
    (machines / "laptop" / "global" / "settings.json").write_text('{"new": true}')

    synth.propagate_files("global")

    dest = patch_dirs["consolidated"] / "global" / "settings.json"
    assert dest.exists()
    assert dest.read_text() == '{"new": true}'


def test_propagate_memory_merges_distinct_files(patch_dirs):
    """When machines have different memory files, all should be propagated."""
    machines = patch_dirs["machines"]

    desk_mem = machines / "desktop" / "projects" / "proj" / "memory"
    desk_mem.mkdir(parents=True)
    (desk_mem / "patterns.md").write_text("patterns from desktop")
    (machines / "desktop" / "projects" / "proj" / "CLAUDE.md").write_text("# d")

    lap_mem = machines / "laptop" / "projects" / "proj" / "memory"
    lap_mem.mkdir(parents=True)
    (lap_mem / "debugging.md").write_text("debugging from laptop")
    (machines / "laptop" / "projects" / "proj" / "CLAUDE.md").write_text("# l")

    synth.propagate_files("projects/proj")

    dest_mem = patch_dirs["consolidated"] / "projects" / "proj" / "memory"
    assert (dest_mem / "patterns.md").read_text() == "patterns from desktop"
    assert (dest_mem / "debugging.md").read_text() == "debugging from laptop"


def test_propagate_removes_stale_memory_file(patch_dirs):
    """Memory files deleted from all machines should be removed from consolidated."""
    machines = patch_dirs["machines"]

    # First run: desktop has two memory files
    desk_mem = machines / "desktop" / "projects" / "proj" / "memory"
    desk_mem.mkdir(parents=True)
    (desk_mem / "MEMORY.md").write_text("keep me")
    (desk_mem / "old-notes.md").write_text("delete me")
    (machines / "desktop" / "projects" / "proj" / "CLAUDE.md").write_text("# d")

    synth.propagate_files("projects/proj")

    dest_mem = patch_dirs["consolidated"] / "projects" / "proj" / "memory"
    assert (dest_mem / "MEMORY.md").exists()
    assert (dest_mem / "old-notes.md").exists()

    # Second run: old-notes.md deleted from machine
    (desk_mem / "old-notes.md").unlink()
    synth.propagate_files("projects/proj")

    assert (dest_mem / "MEMORY.md").exists()
    assert not (dest_mem / "old-notes.md").exists()


def test_propagate_removes_stale_memory_dir(patch_dirs):
    """If no machine has memory, consolidated memory dir should be removed."""
    import shutil
    machines = patch_dirs["machines"]

    desk_mem = machines / "desktop" / "projects" / "proj" / "memory"
    desk_mem.mkdir(parents=True)
    (desk_mem / "MEMORY.md").write_text("temp")
    (machines / "desktop" / "projects" / "proj" / "CLAUDE.md").write_text("# d")

    synth.propagate_files("projects/proj")

    dest_mem = patch_dirs["consolidated"] / "projects" / "proj" / "memory"
    assert dest_mem.exists()

    # Remove entire memory dir from machine
    shutil.rmtree(desk_mem)
    synth.propagate_files("projects/proj")

    assert not dest_mem.exists()


# ---------------------------------------------------------------------------
# needs_synthesis
# ---------------------------------------------------------------------------

def test_needs_synthesis_true_when_hashes_differ(patch_dirs):
    last = LastSynthesis(last_run="", input_hashes={"global": {"desktop": "aaa"}})
    assert synth.needs_synthesis("global", {"desktop": "bbb"}, last) is True


def test_needs_synthesis_false_when_equal(patch_dirs):
    last = LastSynthesis(last_run="", input_hashes={"global": {"desktop": "aaa"}})
    assert synth.needs_synthesis("global", {"desktop": "aaa"}, last) is False


def test_needs_synthesis_true_when_scope_missing(patch_dirs):
    last = LastSynthesis(last_run="", input_hashes={})
    assert synth.needs_synthesis("global", {"desktop": "aaa"}, last) is True


# ---------------------------------------------------------------------------
# build_prompt
# ---------------------------------------------------------------------------

def test_build_prompt_replaces_machine_sections(patch_dirs):
    prompt = synth.build_prompt("global", {"desktop": "content A"}, None)
    assert 'Machine "desktop" version:' in prompt
    assert "content A" in prompt
    assert "{MACHINE_SECTIONS}" not in prompt


def test_build_prompt_replaces_previous_consolidated(patch_dirs):
    prompt = synth.build_prompt("global", {"desktop": "content A"}, "prev content")
    assert "prev content" in prompt
    assert "{PREVIOUS_CONSOLIDATED_SECTION}" not in prompt


def test_build_prompt_no_previous_consolidated(patch_dirs):
    prompt = synth.build_prompt("global", {"desktop": "content A"}, None)
    assert "{PREVIOUS_CONSOLIDATED_SECTION}" not in prompt
    assert "Previous consolidated" not in prompt


# ---------------------------------------------------------------------------
# critic_pass
# ---------------------------------------------------------------------------

def test_critic_pass_ok_returns_empty(patch_dirs):
    with patch.object(synth, "call_claude_api", return_value="OK"):
        result = synth.critic_pass("output text", {"m": "content"})
    assert result == []


def test_critic_pass_ok_case_insensitive(patch_dirs):
    with patch.object(synth, "call_claude_api", return_value="ok\n"):
        result = synth.critic_pass("output text", {"m": "content"})
    assert result == []


def test_critic_pass_returns_unverified_lines(patch_dirs):
    response = 'UNVERIFIED: "some claim" — reason: not in sources\nUNVERIFIED: "another" — reason: invented'
    with patch.object(synth, "call_claude_api", return_value=response):
        result = synth.critic_pass("output", {"m": "content"})
    assert len(result) == 2
    assert all(r.startswith("UNVERIFIED:") for r in result)


def test_critic_pass_ignores_non_unverified_lines(patch_dirs):
    response = "Some preamble\nUNVERIFIED: \"claim\" — reason: x\nSome other text"
    with patch.object(synth, "call_claude_api", return_value=response):
        result = synth.critic_pass("output", {"m": "content"})
    assert len(result) == 1


def test_critic_pass_api_error_returns_empty_and_warns(patch_dirs, capsys):
    with patch.object(synth, "call_claude_api", side_effect=Exception("network error")):
        result = synth.critic_pass("output", {"m": "content"}, scope="global")
    assert result == []
    captured = capsys.readouterr()
    assert "WARNING" in captured.out
    assert "network error" in captured.out


# ---------------------------------------------------------------------------
# synthesize_scope
# ---------------------------------------------------------------------------

def test_synthesize_scope_zero_issues_writes_file(patch_dirs):
    inputs = {"desktop": "# content A", "laptop": "# content B"}
    with patch.object(synth, "call_claude_api", return_value="# merged"):
        with patch.object(synth, "critic_pass", return_value=[]):
            result = synth.synthesize_scope("global", inputs)

    assert result == "# merged"
    dest = patch_dirs["consolidated"] / "global" / "CLAUDE.md"
    assert dest.exists()
    assert dest.read_text() == "# merged"


def test_synthesize_scope_one_to_three_issues_embeds_comments(patch_dirs):
    inputs = {"desktop": "# A", "laptop": "# B"}
    issues = ['UNVERIFIED: "claim" — reason: x']
    with patch.object(synth, "call_claude_api", return_value="# merged"):
        with patch.object(synth, "critic_pass", return_value=issues):
            result = synth.synthesize_scope("global", inputs)

    assert "<!-- UNVERIFIED:" in result
    dest = patch_dirs["consolidated"] / "global" / "CLAUDE.md"
    assert "<!-- UNVERIFIED:" in dest.read_text()


def test_synthesize_scope_more_than_three_issues_returns_none(patch_dirs):
    inputs = {"desktop": "# A", "laptop": "# B"}
    issues = [f'UNVERIFIED: "claim {i}"' for i in range(4)]
    with patch.object(synth, "call_claude_api", return_value="# merged"):
        with patch.object(synth, "critic_pass", return_value=issues):
            result = synth.synthesize_scope("global", inputs)

    assert result is None
    dest = patch_dirs["consolidated"] / "global" / "CLAUDE.md"
    assert not dest.exists()


def test_synthesize_scope_single_machine_copies_directly(patch_dirs):
    inputs = {"desktop": "# only machine"}
    api_mock = MagicMock()
    with patch.object(synth, "call_claude_api", api_mock):
        result = synth.synthesize_scope("global", inputs)

    api_mock.assert_not_called()
    assert result == "# only machine"
    dest = patch_dirs["consolidated"] / "global" / "CLAUDE.md"
    assert dest.read_text() == "# only machine"


def test_synthesize_scope_all_empty_returns_none(patch_dirs):
    inputs = {"desktop": "   ", "laptop": "\n\n"}
    api_mock = MagicMock()
    with patch.object(synth, "call_claude_api", api_mock):
        result = synth.synthesize_scope("global", inputs)

    api_mock.assert_not_called()
    assert result is None


def test_synthesize_scope_one_empty_one_nonempty_direct_copy(patch_dirs):
    inputs = {"desktop": "# real content", "laptop": "   "}
    api_mock = MagicMock()
    with patch.object(synth, "call_claude_api", api_mock):
        result = synth.synthesize_scope("global", inputs)

    api_mock.assert_not_called()
    assert result == "# real content"


# ---------------------------------------------------------------------------
# main()
# ---------------------------------------------------------------------------

def test_main_empty_machines_exits_cleanly(patch_dirs, monkeypatch, capsys):
    # machines dir exists but is empty (no subdirs)
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
    with pytest.raises(SystemExit) as exc_info:
        synth.main()
    assert exc_info.value.code == 0
    captured = capsys.readouterr()
    assert "No machine snapshots" in captured.out


def test_main_no_api_key_exits_with_error(patch_dirs, monkeypatch, capsys):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    with pytest.raises(SystemExit) as exc_info:
        synth.main()
    assert exc_info.value.code == 1
    captured = capsys.readouterr()
    assert "ANTHROPIC_API_KEY" in captured.out


def test_main_writes_last_synthesis_json(patch_dirs, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
    make_machine(patch_dirs["machines"], "desktop", "global", "# content")

    with patch.object(synth, "call_claude_api", return_value="# merged"):
        with patch.object(synth, "critic_pass", return_value=[]):
            synth.main()

    meta_file = patch_dirs["meta"] / "last-synthesis.json"
    assert meta_file.exists()
    data = json.loads(meta_file.read_text())
    assert data["last_run"] != ""
    assert "global" in data["input_hashes"]


def test_main_appends_sync_log(patch_dirs, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
    make_machine(patch_dirs["machines"], "desktop", "global", "# content")

    with patch.object(synth, "call_claude_api", return_value="# merged"):
        with patch.object(synth, "critic_pass", return_value=[]):
            synth.main()
            synth.main()  # run twice

    log_file = patch_dirs["meta"] / "sync-log.json"
    # Second run should not append if hashes unchanged
    entries = json.loads(log_file.read_text())
    assert isinstance(entries, list)
    assert len(entries) >= 1
