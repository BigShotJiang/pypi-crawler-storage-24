import pytest
import tomli_w
from pathlib import Path

from claude_sync.config import load_config, save_config, init_config
from claude_sync.models import Config


VALID_TOML = {
    "client": {"machine_id": "desktop"},
    "gitlab": {"url": "https://gitlab.example.com", "project_id": 42},
    "repo": {"local_path": "/tmp/sync-repo"},
}


@pytest.fixture
def config_file(tmp_path, monkeypatch):
    """Redirect CONFIG_FILE to a temp path."""
    config_dir = tmp_path / ".claude-sync"
    config_dir.mkdir()
    config_path = config_dir / "config.toml"

    import claude_sync.config as cfg_module
    monkeypatch.setattr(cfg_module, "CONFIG_DIR", config_dir)
    monkeypatch.setattr(cfg_module, "CONFIG_FILE", config_path)
    return config_path


def test_load_valid_config(config_file):
    with config_file.open("wb") as f:
        tomli_w.dump(VALID_TOML, f)

    config = load_config()
    assert config.client.machine_id == "desktop"
    assert config.gitlab.url == "https://gitlab.example.com"
    assert config.gitlab.project_id == 42
    assert config.gitlab.trigger_token == ""
    assert config.gitlab.access_token == ""
    assert config.repo.local_path == Path("/tmp/sync-repo")
    assert config.projects.paths == []
    assert config.safety.backup_before_apply is True


def test_load_missing_config_raises(config_file):
    # Don't write the file — it shouldn't exist
    with pytest.raises(FileNotFoundError, match="claude-sync init"):
        load_config()


def test_load_invalid_toml_raises(config_file):
    config_file.write_text("not valid toml ][")
    with pytest.raises(Exception):
        load_config()


def test_load_missing_required_field_raises(config_file):
    # Missing 'repo' section (still required)
    incomplete = {"client": {"machine_id": "desktop"}, "gitlab": {"url": "https://gitlab.example.com", "project_id": 1}}
    with config_file.open("wb") as f:
        tomli_w.dump(incomplete, f)
    with pytest.raises(Exception):
        load_config()


def test_save_and_reload(config_file, tmp_path):
    import claude_sync.config as cfg_module

    config = Config.model_validate(VALID_TOML)
    save_config(config)

    assert config_file.exists()
    reloaded = load_config()
    assert reloaded.client.machine_id == config.client.machine_id
    assert reloaded.gitlab.project_id == config.gitlab.project_id


def test_init_config_creates_file(config_file, tmp_path):
    repo_path = tmp_path / "repo"
    repo_path.mkdir()

    config = init_config(
        machine_id="laptop",
        gitlab_url="https://gitlab.example.com",
        project_id=7,
        repo_local_path=repo_path,
    )

    assert config_file.exists()
    assert config.client.machine_id == "laptop"
    assert config.gitlab.project_id == 7
