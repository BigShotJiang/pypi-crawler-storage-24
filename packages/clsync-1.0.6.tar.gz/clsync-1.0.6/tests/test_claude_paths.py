import sys
from pathlib import Path

import pytest

from claude_sync.claude_paths import (
    claude_memory_dir,
    claude_project_dir,
    claude_sessions_index,
    project_slug,
)


def test_project_slug_windows_path():
    # Simulate a Windows absolute path using a known string
    p = Path("C:/dev/my-project")
    slug = project_slug(p)
    # Should be lowercase, colons -> -, separators -> -
    assert ":" not in slug
    assert "\\" not in slug
    assert slug == slug.lower()


def test_project_slug_replaces_colon():
    p = Path("C:/dev/proj")
    slug = project_slug(p)
    assert "-" in slug
    assert ":" not in slug


def test_project_slug_replaces_backslash(tmp_path):
    # Use tmp_path so .resolve() works
    slug = project_slug(tmp_path)
    assert "\\" not in slug
    assert "/" not in slug


def test_project_slug_deterministic(tmp_path):
    slug1 = project_slug(tmp_path)
    slug2 = project_slug(tmp_path)
    assert slug1 == slug2


def test_claude_project_dir(tmp_path, monkeypatch):
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    monkeypatch.setattr(Path, "home", staticmethod(lambda: fake_home))

    result = claude_project_dir(tmp_path)
    slug = project_slug(tmp_path)
    assert result == fake_home / ".claude" / "projects" / slug


def test_claude_memory_dir(tmp_path, monkeypatch):
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    monkeypatch.setattr(Path, "home", staticmethod(lambda: fake_home))

    result = claude_memory_dir(tmp_path)
    assert result.name == "memory"
    assert result.parent.name == project_slug(tmp_path)


def test_claude_sessions_index(tmp_path, monkeypatch):
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    monkeypatch.setattr(Path, "home", staticmethod(lambda: fake_home))

    result = claude_sessions_index(tmp_path)
    assert result.name == "sessions-index.json"
    assert result.parent.name == project_slug(tmp_path)
