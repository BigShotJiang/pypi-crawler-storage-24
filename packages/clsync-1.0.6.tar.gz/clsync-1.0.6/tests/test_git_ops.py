"""Tests for src/claude_sync/git_ops.py."""
from pathlib import Path
from unittest.mock import MagicMock, PropertyMock, patch, call

import pytest

from claude_sync.git_ops import ensure_repo, pull_rebase, commit_and_push, has_changes
from claude_sync.models import Config, ClientConfig, GitLabConfig, RepoConfig


def make_config(repo_path: Path) -> Config:
    return Config(
        client=ClientConfig(machine_id="test"),
        gitlab=GitLabConfig(url="https://gitlab.example.com", project_id=1),
        repo=RepoConfig(local_path=repo_path),
    )


# ---------------------------------------------------------------------------
# ensure_repo
# ---------------------------------------------------------------------------

@patch("claude_sync.git_ops.git.Repo")
def test_ensure_repo_success(mock_repo_cls, tmp_path):
    mock_repo = MagicMock()
    mock_repo_cls.return_value = mock_repo
    config = make_config(tmp_path)
    result = ensure_repo(config)
    assert result is mock_repo
    mock_repo_cls.assert_called_once_with(tmp_path)


@patch("claude_sync.git_ops.git.Repo")
def test_ensure_repo_invalid_git_repo(mock_repo_cls, tmp_path):
    import git
    mock_repo_cls.side_effect = git.InvalidGitRepositoryError("bad")
    config = make_config(tmp_path)
    with pytest.raises(ValueError, match="Not a git repository"):
        ensure_repo(config)


@patch("claude_sync.git_ops.git.Repo")
def test_ensure_repo_no_such_path(mock_repo_cls, tmp_path):
    import git
    mock_repo_cls.side_effect = git.NoSuchPathError("missing")
    config = make_config(tmp_path / "nonexistent")
    with pytest.raises(ValueError, match="Path does not exist"):
        ensure_repo(config)


# ---------------------------------------------------------------------------
# pull_rebase
# ---------------------------------------------------------------------------

def test_pull_rebase_calls_git():
    mock_repo = MagicMock()
    pull_rebase(mock_repo)
    mock_repo.git.pull.assert_called_once_with("--rebase", "origin", "main")


# ---------------------------------------------------------------------------
# has_changes
# ---------------------------------------------------------------------------

def test_has_changes_true():
    mock_repo = MagicMock()
    mock_repo.is_dirty.return_value = True
    assert has_changes(mock_repo) is True
    mock_repo.is_dirty.assert_called_once_with(untracked_files=True)


def test_has_changes_false():
    mock_repo = MagicMock()
    mock_repo.is_dirty.return_value = False
    assert has_changes(mock_repo) is False


# ---------------------------------------------------------------------------
# commit_and_push
# ---------------------------------------------------------------------------

def test_commit_and_push_with_changes():
    mock_repo = MagicMock()
    mock_repo.is_dirty.return_value = True
    result = commit_and_push(mock_repo, "test commit")
    assert result is True
    mock_repo.git.add.assert_called_once_with("-A")
    mock_repo.index.commit.assert_called_once_with("test commit")
    mock_repo.git.push.assert_called_once_with("origin", "main")


def test_commit_and_push_no_changes():
    mock_repo = MagicMock()
    mock_repo.is_dirty.return_value = False
    result = commit_and_push(mock_repo, "test commit")
    assert result is False
    mock_repo.git.add.assert_not_called()
    mock_repo.index.commit.assert_not_called()
    mock_repo.git.push.assert_not_called()
