import hashlib
import shutil
from pathlib import Path

from claude_sync.claude_paths import claude_memory_dir
from claude_sync.models import Config


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()


def _copy_if_changed(src: Path, dst: Path) -> bool:
    """Copy src to dst only if content differs. Returns True if copied."""
    if dst.exists() and _sha256(src) == _sha256(dst):
        return False
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    return True


def _collect_project_paths(config: Config) -> list[Path]:
    paths = list(config.projects.paths)

    if config.projects.auto_discover:
        for root in config.projects.discover_roots:
            root = Path(root).resolve()
            max_depth = config.projects.discover_max_depth
            for entry in walk_limited(root, max_depth):
                if (entry / ".claude").is_dir():
                    paths.append(entry)

    # Deduplicate by resolved absolute path
    seen: set[Path] = set()
    result: list[Path] = []
    for p in paths:
        resolved = Path(p).resolve()
        if resolved not in seen:
            seen.add(resolved)
            result.append(resolved)
    return result


def walk_limited(root: Path, max_depth: int) -> list[Path]:
    """Yield directories up to max_depth levels below root (not including root itself)."""
    results: list[Path] = []
    if max_depth < 1:
        return results
    try:
        for child in root.iterdir():
            if child.is_symlink():
                continue
            if child.is_dir():
                results.append(child)
                if max_depth > 1:
                    results.extend(walk_limited(child, max_depth - 1))
    except PermissionError:
        pass
    return results


def snapshot(config: Config) -> list[str]:
    """
    Copy Claude Code artifacts from local machine to the sync repo.
    Returns list of scopes that were updated.

    Global artifacts:
    1. ~/.claude/CLAUDE.md        -> {repo}/machines/{id}/global/CLAUDE.md
    2. ~/.claude/settings.json    -> {repo}/machines/{id}/global/settings.json

    Per-project artifacts (for each registered project):
    1. {project}/.claude/CLAUDE.md            -> {repo}/machines/{id}/projects/{name}/CLAUDE.md
    2. ~/.claude/projects/{slug}/memory/      -> {repo}/machines/{id}/projects/{name}/memory/
    """
    machine_dir = Path(config.repo.local_path) / "machines" / config.client.machine_id
    updated: list[str] = []

    # --- Global artifacts ---
    global_updated = False

    global_md = Path.home() / ".claude" / "CLAUDE.md"
    dst_global_md = machine_dir / "global" / "CLAUDE.md"
    if global_md.exists():
        if _copy_if_changed(global_md, dst_global_md):
            global_updated = True
    elif dst_global_md.exists():
        dst_global_md.unlink()
        global_updated = True

    global_settings = Path.home() / ".claude" / "settings.json"
    dst_global_settings = machine_dir / "global" / "settings.json"
    if global_settings.exists():
        if _copy_if_changed(global_settings, dst_global_settings):
            global_updated = True
    elif dst_global_settings.exists():
        dst_global_settings.unlink()
        global_updated = True

    if global_updated:
        updated.append("global")

    # --- Per-project artifacts ---
    for project_path in _collect_project_paths(config):
        project_path = Path(project_path)
        project_name = project_path.name
        scope = f"projects/{project_name}"
        scope_updated = False

        # CLAUDE.md
        claude_md = project_path / ".claude" / "CLAUDE.md"
        dst_md = machine_dir / "projects" / project_name / "CLAUDE.md"
        if claude_md.exists():
            if _copy_if_changed(claude_md, dst_md):
                scope_updated = True
        elif dst_md.exists():
            dst_md.unlink()
            scope_updated = True

        # Memory files
        memory_src = claude_memory_dir(project_path)
        dst_memory = machine_dir / "projects" / project_name / "memory"
        if memory_src.exists():
            for mem_file in memory_src.rglob("*"):
                if mem_file.is_file():
                    rel = mem_file.relative_to(memory_src)
                    if _copy_if_changed(mem_file, dst_memory / rel):
                        scope_updated = True
            # Remove files from sync repo that no longer exist locally
            if dst_memory.exists():
                local_rels = {
                    f.relative_to(memory_src)
                    for f in memory_src.rglob("*") if f.is_file()
                }
                for dst_file in list(dst_memory.rglob("*")):
                    if dst_file.is_file() and dst_file.relative_to(dst_memory) not in local_rels:
                        dst_file.unlink()
                        scope_updated = True
        elif dst_memory.exists():
            shutil.rmtree(dst_memory)
            scope_updated = True

        if scope_updated:
            updated.append(scope)

    return updated
