import os
import platform
import subprocess
from pathlib import Path

import tomllib
import tomli_w

from claude_sync.models import Config

CONFIG_DIR = Path.home() / ".claude-sync"
CONFIG_FILE = CONFIG_DIR / "config.toml"


def load_config() -> Config:
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found at {CONFIG_FILE}. Run 'clsync init' to create it."
        )
    with CONFIG_FILE.open("rb") as f:
        data = tomllib.load(f)
    return Config.model_validate(data)


def _restrict_permissions(path: Path) -> None:
    """Restrict file access to current user only."""
    if platform.system() == "Windows":
        try:
            username = os.environ.get("USERNAME")
            if username:
                subprocess.run(
                    ["icacls", str(path), "/inheritance:r",
                     "/grant:r", f"{username}:(R,W)"],
                    capture_output=True, timeout=5,
                )
        except Exception:
            pass  # best-effort
    else:
        os.chmod(path, 0o600)


def save_config(config: Config) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    data = config.model_dump(mode="json", exclude_none=True)
    with CONFIG_FILE.open("wb") as f:
        tomli_w.dump(data, f)
    _restrict_permissions(CONFIG_FILE)


def init_config(
    machine_id: str,
    repo_local_path: Path,
    provider_type: str = "gitlab",
    gitlab_url: str = "",
    project_id: int = 0,
    trigger_token: str = "",
    access_token: str = "",
    github_token: str = "",
    github_repo: str = "",
    github_workflow_id: str = "synthesize.yml",
) -> Config:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    gitlab = None
    github = None

    if provider_type == "gitlab":
        gitlab = {
            "url": gitlab_url,
            "project_id": project_id,
            "trigger_token": trigger_token,
            "access_token": access_token,
        }
    elif provider_type == "github":
        github = {
            "token": github_token,
            "repo": github_repo,
            "workflow_id": github_workflow_id,
        }

    config = Config(
        client={"machine_id": machine_id},
        provider={"type": provider_type},
        gitlab=gitlab,
        github=github,
        repo={"local_path": repo_local_path},
    )
    save_config(config)
    return config
