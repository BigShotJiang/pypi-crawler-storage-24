"""
CI provider abstraction for triggering and polling synthesis pipelines.

Supported providers:
  gitlab  — GitLab CI pipeline trigger + polling (default)
  github  — GitHub Actions workflow dispatch
  local   — Run pipeline/synthesize.py directly as a subprocess
"""
import subprocess
import time
from datetime import datetime, timezone
from typing import Protocol, runtime_checkable

import httpx
from rich.console import Console

from claude_sync.models import Config

console = Console()

GITLAB_TERMINAL_STATES = {"success", "failed", "canceled", "skipped"}
GITHUB_SUCCESS_CONCLUSIONS = {"success"}
GITHUB_TERMINAL_CONCLUSIONS = {"success", "failure", "cancelled", "timed_out", "action_required", "skipped"}


@runtime_checkable
class CIProvider(Protocol):
    def trigger(self) -> int | None:
        """Start the synthesis pipeline. Returns a run/pipeline ID, or None for local."""
        ...

    def wait_for_completion(self, run_id: int | None, timeout: int = 300, poll_interval: int = 10) -> bool:
        """Wait until completion. Returns True on success."""
        ...

    def get_failure_diagnosis(self, run_id: int | None) -> str | None:
        """Return a human-readable hint about a known failure, or None."""
        ...


# ---------------------------------------------------------------------------
# GitLab provider
# ---------------------------------------------------------------------------

class GitLabProvider:
    def __init__(self, config: Config) -> None:
        self.config = config

    def _gitlab(self):
        if not self.config.gitlab:
            raise RuntimeError(
                "GitLab is not configured. Run 'clsync init --provider gitlab'."
            )
        return self.config.gitlab

    def trigger(self) -> int:
        gl = self._gitlab()
        if not gl.trigger_token:
            raise RuntimeError(
                "GitLab trigger token is not configured. "
                "Run 'clsync init' or set trigger_token in ~/.claude-sync/config.toml."
            )
        url = f"{gl.url}/api/v4/projects/{gl.project_id}/trigger/pipeline"
        response = httpx.post(url, data={"token": gl.trigger_token, "ref": "main"})
        if response.status_code not in (200, 201):
            raise RuntimeError(
                f"Failed to trigger pipeline: HTTP {response.status_code} — {response.text}"
            )
        return response.json()["id"]

    def wait_for_completion(self, run_id: int | None, timeout: int = 300, poll_interval: int = 10) -> bool:
        if run_id is None:
            return False
        gl = self._gitlab()
        if not gl.access_token:
            raise RuntimeError(
                "GitLab access token is not configured. "
                "Run 'clsync init' or set access_token in ~/.claude-sync/config.toml."
            )
        url = f"{gl.url}/api/v4/projects/{gl.project_id}/pipelines/{run_id}"
        headers = {"PRIVATE-TOKEN": gl.access_token}
        deadline = time.monotonic() + timeout
        last_status = ""

        while time.monotonic() < deadline:
            response = httpx.get(url, headers=headers)
            if response.status_code != 200:
                raise RuntimeError(
                    f"Failed to get pipeline status: HTTP {response.status_code} — {response.text}"
                )
            status = response.json()["status"]
            if status != last_status:
                console.print(f"Pipeline #{run_id}: [bold]{status}[/bold]")
                last_status = status
            if status in GITLAB_TERMINAL_STATES:
                return status == "success"
            time.sleep(poll_interval)

        raise TimeoutError(
            f"Pipeline #{run_id} did not reach a terminal state within {timeout}s. "
            f"Last status: {last_status}"
        )

    def get_failure_diagnosis(self, run_id: int | None) -> str | None:
        if run_id is None:
            return None
        gl = self._gitlab()
        if not gl.access_token:
            return None
        base = f"{gl.url}/api/v4/projects/{gl.project_id}"
        headers = {"PRIVATE-TOKEN": gl.access_token}
        try:
            jobs_resp = httpx.get(f"{base}/pipelines/{run_id}/jobs", headers=headers)
            if jobs_resp.status_code != 200:
                return None
            failed = [j for j in jobs_resp.json() if j.get("status") == "failed"]
            if not failed:
                return None
            job_id = failed[0]["id"]
            trace_resp = httpx.get(f"{base}/jobs/{job_id}/trace", headers=headers)
            if trace_resp.status_code != 200:
                return None
            log = trace_resp.text
        except Exception:
            return None

        return _diagnose_gitlab_log(log)


def _diagnose_gitlab_log(log: str) -> str | None:
    """Return a human-readable hint if a known failure pattern is found."""
    if "not allowed to push" in log or ("403" in log and "push" in log.lower()):
        return (
            "The CI job was denied push access.\n"
            "Fix: in your sync repo go to Settings → CI/CD → Token Access\n"
            "     and enable 'Allow Git push requests to the repository'."
        )
    if "ANTHROPIC_API_KEY" in log or "AuthenticationError" in log or "invalid x-api-key" in log.lower():
        return (
            "The Anthropic API key is missing or invalid.\n"
            "Fix: add ANTHROPIC_API_KEY as a masked CI/CD variable in your sync repo\n"
            "     under Settings → CI/CD → Variables."
        )
    return None


# ---------------------------------------------------------------------------
# GitHub Actions provider
# ---------------------------------------------------------------------------

class GitHubProvider:
    def __init__(self, config: Config) -> None:
        self.config = config
        self._dispatch_time: float = 0.0

    def _gh(self):
        if not self.config.github:
            raise RuntimeError(
                "GitHub is not configured. Run 'clsync init --provider github'."
            )
        return self.config.github

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self._gh().token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }

    def trigger(self) -> int:
        gh = self._gh()
        if not gh.token:
            raise RuntimeError(
                "GitHub token is not configured. "
                "Run 'clsync init' or set token in ~/.claude-sync/config.toml."
            )
        url = f"https://api.github.com/repos/{gh.repo}/actions/workflows/{gh.workflow_id}/dispatches"
        self._dispatch_time = time.time()
        response = httpx.post(url, headers=self._headers(), json={"ref": "main"})
        if response.status_code != 204:
            raise RuntimeError(
                f"Failed to dispatch workflow: HTTP {response.status_code} — {response.text}"
            )
        return self._find_run_id()

    def _find_run_id(self, search_timeout: int = 15) -> int:
        gh = self._gh()
        url = f"https://api.github.com/repos/{gh.repo}/actions/runs"
        deadline = time.monotonic() + search_timeout
        while time.monotonic() < deadline:
            time.sleep(2)
            resp = httpx.get(
                url, headers=self._headers(),
                params={"event": "workflow_dispatch", "per_page": 10},
            )
            if resp.status_code != 200:
                continue
            for run in resp.json().get("workflow_runs", []):
                created_str = run.get("created_at", "")
                try:
                    created = datetime.fromisoformat(created_str.replace("Z", "+00:00")).timestamp()
                except ValueError:
                    continue
                if created >= self._dispatch_time - 5:
                    return run["id"]
        raise RuntimeError(
            "Could not find the dispatched GitHub Actions run. "
            "Check the Actions tab in your repository."
        )

    def wait_for_completion(self, run_id: int | None, timeout: int = 300, poll_interval: int = 10) -> bool:
        if run_id is None:
            return False
        gh = self._gh()
        url = f"https://api.github.com/repos/{gh.repo}/actions/runs/{run_id}"
        deadline = time.monotonic() + timeout
        last_display = ""

        while time.monotonic() < deadline:
            resp = httpx.get(url, headers=self._headers())
            if resp.status_code != 200:
                time.sleep(poll_interval)
                continue
            data = resp.json()
            status = data["status"]       # queued | in_progress | completed
            conclusion = data.get("conclusion")  # success | failure | cancelled | …
            display = conclusion if status == "completed" and conclusion else status
            if display != last_display:
                console.print(f"Run #{run_id}: [bold]{display}[/bold]")
                last_display = display
            if status == "completed":
                return conclusion in GITHUB_SUCCESS_CONCLUSIONS
            time.sleep(poll_interval)

        raise TimeoutError(
            f"GitHub Actions run #{run_id} did not complete within {timeout}s. "
            f"Last status: {last_display}"
        )

    def get_failure_diagnosis(self, run_id: int | None) -> str | None:
        # GitHub Actions logs require following a signed S3 redirect; too complex for
        # automatic diagnosis. Direct the user to the web UI instead.
        if run_id is None:
            return None
        gh = self._gh()
        return (
            f"Check the Actions tab for details:\n"
            f"  https://github.com/{gh.repo}/actions/runs/{run_id}"
        )


# ---------------------------------------------------------------------------
# Local provider (runs pipeline/synthesize.py as a subprocess)
# ---------------------------------------------------------------------------

class LocalProvider:
    def __init__(self, config: Config) -> None:
        self.config = config
        self._success: bool = False

    def trigger(self) -> None:
        import os
        repo_path = self.config.repo.local_path
        if not os.environ.get("ANTHROPIC_API_KEY"):
            raise RuntimeError(
                "ANTHROPIC_API_KEY is not set. "
                "Export it before running 'clsync trigger' with the local provider."
            )
        result = subprocess.run(
            ["python", "pipeline/synthesize.py"],
            cwd=repo_path,
        )
        self._success = result.returncode == 0
        return None

    def wait_for_completion(self, run_id: int | None, timeout: int = 300, poll_interval: int = 10) -> bool:
        # synthesis already ran synchronously in trigger()
        return self._success

    def get_failure_diagnosis(self, run_id: int | None) -> str | None:
        return None


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def get_provider(config: Config) -> CIProvider:
    provider_type = config.provider.type
    if provider_type == "gitlab":
        return GitLabProvider(config)
    if provider_type == "github":
        return GitHubProvider(config)
    if provider_type == "local":
        return LocalProvider(config)
    raise ValueError(f"Unknown provider type: {provider_type!r}")
