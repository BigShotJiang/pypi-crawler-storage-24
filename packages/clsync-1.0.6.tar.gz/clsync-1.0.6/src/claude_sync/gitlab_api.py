import time

import httpx
from rich.console import Console

from claude_sync.models import Config

console = Console()

TERMINAL_STATES = {"success", "failed", "canceled", "skipped"}


def trigger_pipeline(config: Config) -> int:
    """
    Trigger the synthesis pipeline via GitLab API.
    Returns the pipeline ID.
    """
    token = config.gitlab.trigger_token
    if not token:
        raise RuntimeError(
            "GitLab trigger token is not configured. "
            "Run 'clsync init' or set trigger_token in ~/.claude-sync/config.toml."
        )

    url = (
        f"{config.gitlab.url}/api/v4/projects/{config.gitlab.project_id}/trigger/pipeline"
    )
    response = httpx.post(url, data={"token": token, "ref": "main"})

    if response.status_code not in (200, 201):
        raise RuntimeError(
            f"Failed to trigger pipeline: HTTP {response.status_code} — {response.text}"
        )

    pipeline_id: int = response.json()["id"]
    return pipeline_id


def get_pipeline_status(config: Config, pipeline_id: int) -> str:
    """
    GET pipeline status. Uses the personal access token (not trigger token).
    Returns the status string.
    """
    token = config.gitlab.access_token
    if not token:
        raise RuntimeError(
            "GitLab access token is not configured. "
            "Run 'clsync init' or set access_token in ~/.claude-sync/config.toml."
        )

    url = (
        f"{config.gitlab.url}/api/v4/projects/{config.gitlab.project_id}"
        f"/pipelines/{pipeline_id}"
    )
    response = httpx.get(url, headers={"PRIVATE-TOKEN": token})

    if response.status_code != 200:
        raise RuntimeError(
            f"Failed to get pipeline status: HTTP {response.status_code} — {response.text}"
        )

    return response.json()["status"]


def get_failed_job_log(config: Config, pipeline_id: int) -> str | None:
    """
    Fetch the log of the first failed job in the pipeline.
    Returns last 50 lines of the log, or None if unavailable.
    """
    token = config.gitlab.access_token
    if not token:
        return None

    base = f"{config.gitlab.url}/api/v4/projects/{config.gitlab.project_id}"
    headers = {"PRIVATE-TOKEN": token}

    try:
        jobs_resp = httpx.get(f"{base}/pipelines/{pipeline_id}/jobs", headers=headers)
        if jobs_resp.status_code != 200:
            return None
        failed = [j for j in jobs_resp.json() if j.get("status") == "failed"]
        if not failed:
            return None
        job_id = failed[0]["id"]
        trace_resp = httpx.get(f"{base}/jobs/{job_id}/trace", headers=headers)
        if trace_resp.status_code != 200:
            return None
        lines = trace_resp.text.splitlines()
        return "\n".join(lines[-50:])
    except Exception:
        return None


def _diagnose_log(log: str) -> str | None:
    """Return a human-readable hint if a known failure pattern is found."""
    if "not allowed to push" in log or ("403" in log and "push" in log.lower()):
        return (
            "The CI job was denied push access.\n"
            "Fix: in your sync repo go to Settings → CI/CD → Token Access\n"
            "     and enable 'Allow Git push requests to the repository'."
        )
    if "ANTHROPIC_API_KEY" in log or "AuthenticationError" in log or "invalid x-api-key" in log.lower():
        return (
            "The Anthropic API key is missing or invalid.\n"
            "Fix: add ANTHROPIC_API_KEY as a masked CI/CD variable in your sync repo\n"
            "     under Settings → CI/CD → Variables."
        )
    return None


def wait_for_pipeline(
    config: Config,
    pipeline_id: int,
    timeout: int = 300,
    poll_interval: int = 10,
) -> str:
    """
    Poll pipeline status until terminal state or timeout.
    Returns final status string.
    """
    deadline = time.monotonic() + timeout
    last_status = ""

    while time.monotonic() < deadline:
        status = get_pipeline_status(config, pipeline_id)
        if status != last_status:
            console.print(f"Pipeline #{pipeline_id}: [bold]{status}[/bold]")
            last_status = status

        if status in TERMINAL_STATES:
            return status

        time.sleep(poll_interval)

    raise TimeoutError(
        f"Pipeline #{pipeline_id} did not reach a terminal state within {timeout}s. "
        f"Last status: {last_status}"
    )
