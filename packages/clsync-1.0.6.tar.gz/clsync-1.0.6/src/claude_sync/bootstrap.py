"""
Generate CLAUDE.md files from existing Claude Code artifacts (memory files, session summaries).

This module calls the Anthropic API directly on the client machine. It requires the
'bootstrap' optional dependency: pip install clsync[bootstrap]
"""
import json
from pathlib import Path

from claude_sync.claude_paths import claude_memory_dir, claude_sessions_index

MODEL = "claude-sonnet-4-20250514"
MAX_TOKENS = 8192

_PROMPTS_DIR = Path(__file__).parent / "prompts"


def _load_prompt_template() -> str:
    return (_PROMPTS_DIR / "bootstrap.txt").read_text(encoding="utf-8")


def gather_project_context(project_path: Path) -> dict:
    """
    Collect all available context for a project.

    Returns dict with keys (all optional):
    - "memory_files": dict[str, str]  — filename -> content
    - "session_summaries": list[str]  — summaries from sessions-index.json
    - "existing_claude_md": str | None
    """
    context: dict = {}

    memory_dir = claude_memory_dir(project_path)
    if memory_dir.exists():
        memory_files: dict[str, str] = {}
        for f in sorted(memory_dir.rglob("*")):
            if f.is_file():
                try:
                    key = f.relative_to(memory_dir).as_posix()
                    memory_files[key] = f.read_text(encoding="utf-8", errors="replace")
                except OSError:
                    pass
        if memory_files:
            context["memory_files"] = memory_files

    sessions_path = claude_sessions_index(project_path)
    if sessions_path.exists():
        try:
            data = json.loads(sessions_path.read_text(encoding="utf-8"))
            summaries = [
                entry["summary"]
                for entry in (data if isinstance(data, list) else [])
                if isinstance(entry, dict) and entry.get("summary")
            ]
            if summaries:
                context["session_summaries"] = summaries
        except (OSError, json.JSONDecodeError, KeyError):
            pass

    claude_md = project_path / ".claude" / "CLAUDE.md"
    if claude_md.exists():
        try:
            context["existing_claude_md"] = claude_md.read_text(encoding="utf-8", errors="replace")
        except OSError:
            pass

    return context


def gather_global_context(project_paths: list[Path]) -> dict:
    """
    Collect cross-project context for generating a global CLAUDE.md.

    Returns dict with keys:
    - "all_memory_files": dict[str, dict[str, str]]  — project_name -> {filename -> content}
    - "all_session_summaries": dict[str, list[str]]  — project_name -> [summaries]
    - "settings": str | None
    - "existing_claude_md": str | None
    """
    context: dict = {}
    all_memory: dict[str, dict[str, str]] = {}
    all_summaries: dict[str, list[str]] = {}

    for project_path in project_paths:
        project_path = Path(project_path)
        proj_context = gather_project_context(project_path)
        name = project_path.name
        if "memory_files" in proj_context:
            all_memory[name] = proj_context["memory_files"]
        if "session_summaries" in proj_context:
            all_summaries[name] = proj_context["session_summaries"]

    if all_memory:
        context["all_memory_files"] = all_memory
    if all_summaries:
        context["all_session_summaries"] = all_summaries

    settings_path = Path.home() / ".claude" / "settings.json"
    if settings_path.exists():
        try:
            context["settings"] = settings_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            pass

    global_md = Path.home() / ".claude" / "CLAUDE.md"
    if global_md.exists():
        try:
            context["existing_claude_md"] = global_md.read_text(encoding="utf-8", errors="replace")
        except OSError:
            pass

    return context


def build_bootstrap_prompt(context: dict, scope: str) -> str:
    """Build the prompt for generating a CLAUDE.md from gathered context."""
    template = _load_prompt_template()

    sections: list[str] = []

    # Per-project context
    if "memory_files" in context:
        sections.append("## MEMORY FILES\n")
        for filename, content in context["memory_files"].items():
            sections.append(f"### {filename}\n{content}\n")

    if "session_summaries" in context:
        sections.append("## SESSION SUMMARIES\n")
        for summary in context["session_summaries"]:
            sections.append(f"- {summary}")
        sections.append("")

    if "existing_claude_md" in context and context["existing_claude_md"]:
        sections.append("## EXISTING CLAUDE.md (baseline — preserve if still accurate)\n")
        sections.append(context["existing_claude_md"])

    # Global context
    if "all_memory_files" in context:
        for project_name, files in context["all_memory_files"].items():
            sections.append(f"## MEMORY FILES — {project_name}\n")
            for filename, content in files.items():
                sections.append(f"### {filename}\n{content}\n")

    if "all_session_summaries" in context:
        for project_name, summaries in context["all_session_summaries"].items():
            sections.append(f"## SESSION SUMMARIES — {project_name}\n")
            for summary in summaries:
                sections.append(f"- {summary}")
            sections.append("")

    if "settings" in context and context["settings"]:
        sections.append("## CLAUDE CODE SETTINGS (settings.json)\n")
        sections.append(context["settings"])

    context_text = "\n".join(sections).strip()

    if scope == "global":
        scope_instruction = (
            "Focus on cross-project patterns: your user's general coding style, "
            "preferred tools, workflow habits, and environment setup."
        )
    else:
        scope_instruction = (
            "Focus on knowledge specific to this project: its architecture, "
            "conventions, tooling, and key decisions."
        )

    return (
        template
        .replace("{CONTEXT_SECTIONS}", context_text)
        .replace("{SCOPE_INSTRUCTION}", scope_instruction)
    )


def generate_claude_md(context: dict, scope: str, api_key: str) -> str | None:
    """
    Call the Anthropic API to generate a CLAUDE.md from context.

    Returns the generated content, or None if context is empty / generation fails.
    """
    if not context:
        return None

    try:
        import anthropic
    except ImportError:
        raise ImportError(
            "The 'anthropic' package is required for bootstrap. "
            "Install it with: pip install clsync[bootstrap]"
        )

    prompt = build_bootstrap_prompt(context, scope)

    client = anthropic.Anthropic(api_key=api_key)
    response = client.messages.create(
        model=MODEL,
        max_tokens=MAX_TOKENS,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.content[0].text


def bootstrap_project(project_path: Path, api_key: str) -> str | None:
    """
    Generate a CLAUDE.md for a single project.

    1. Gather context from memory/ and sessions-index.json
    2. If no sources found, return None
    3. Generate CLAUDE.md via API
    4. Write result to {project_path}/.claude/CLAUDE.md
    5. Return the generated content
    """
    project_path = Path(project_path).resolve()
    context = gather_project_context(project_path)
    if not context:
        return None

    scope = f"projects/{project_path.name}"
    result = generate_claude_md(context, scope, api_key)
    if result is None:
        return None

    dest = project_path / ".claude" / "CLAUDE.md"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(result, encoding="utf-8")
    return result


def bootstrap_global(project_paths: list[Path], api_key: str) -> str | None:
    """
    Generate a global ~/.claude/CLAUDE.md.

    1. Gather cross-project context
    2. If no sources found, return None
    3. Generate CLAUDE.md via API
    4. Write result to ~/.claude/CLAUDE.md
    5. Return the generated content
    """
    context = gather_global_context(project_paths)
    if not context:
        return None

    result = generate_claude_md(context, "global", api_key)
    if result is None:
        return None

    dest = Path.home() / ".claude" / "CLAUDE.md"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(result, encoding="utf-8")
    return result
