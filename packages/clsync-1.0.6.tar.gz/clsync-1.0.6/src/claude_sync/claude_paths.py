from pathlib import Path


def project_slug(path: Path) -> str:
    """
    Convert a project filesystem path to Claude Code's internal slug.

    The slug is the absolute path, lowercased, with ':' and path separators
    replaced by '-'. This matches Claude Code's own directory naming under
    ~/.claude/projects/.

    Examples:
        C:\\dev\\claudesync       -> c--dev-claudesync
        /home/user/dev/project   -> -home-user-dev-project
    """
    return str(path.resolve()).lower().replace(":", "-").replace("\\", "-").replace("/", "-")


def claude_project_dir(project_path: Path) -> Path:
    """Return ~/.claude/projects/{slug}/ for a given project path."""
    return Path.home() / ".claude" / "projects" / project_slug(project_path)


def claude_memory_dir(project_path: Path) -> Path:
    """Return ~/.claude/projects/{slug}/memory/ for a given project path."""
    return claude_project_dir(project_path) / "memory"


def claude_sessions_index(project_path: Path) -> Path:
    """Return ~/.claude/projects/{slug}/sessions-index.json for a given project path."""
    return claude_project_dir(project_path) / "sessions-index.json"
