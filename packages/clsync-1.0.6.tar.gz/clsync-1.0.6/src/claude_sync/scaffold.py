from importlib.resources import files
from pathlib import Path

# Files whose names start with "." are stored without the dot in the templates package
# to avoid issues with some build backends ignoring dotfiles.
_COMMON_FILES: list[tuple[str, str]] = [
    (".gitignore", "gitignore"),
    ("pipeline/models.py", "pipeline/models.py"),
    ("pipeline/requirements.txt", "pipeline/requirements.txt"),
    ("pipeline/synthesize.py", "pipeline/synthesize.py"),
    ("pipeline/prompts/synthesize_claude_md.txt", "pipeline/prompts/synthesize_claude_md.txt"),
    ("pipeline/prompts/synthesize_critic.txt", "pipeline/prompts/synthesize_critic.txt"),
]

_PROVIDER_FILES: dict[str, list[tuple[str, str]]] = {
    "gitlab": [(".gitlab-ci.yml", "gitlab-ci.yml")],
    "github": [(".github/workflows/synthesize.yml", "github-workflow.yml")],
    "local": [],
}


def scaffold_sync_repo(repo_path: Path, provider: str = "gitlab") -> list[str]:
    """
    Copy CI config and pipeline scripts into the sync repo for any files not already present.
    Returns a list of relative paths that were written.
    """
    templates = files("claude_sync") / "templates"
    written: list[str] = []

    template_files = _COMMON_FILES + _PROVIDER_FILES.get(provider, [])

    for dest_rel, src_rel in template_files:
        dest = repo_path / dest_rel
        if dest.exists():
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        resource = templates
        for part in src_rel.split("/"):
            resource = resource / part
        dest.write_bytes(resource.read_bytes())
        written.append(dest_rel)

    return written
