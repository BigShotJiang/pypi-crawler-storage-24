import difflib
import shutil
from datetime import datetime, timezone
from pathlib import Path

from rich.console import Console

from claude_sync.claude_paths import claude_memory_dir
from claude_sync.models import Config

console = Console()


def apply_consolidated(config: Config, skip_scopes: set[str] | None = None) -> list[str]:
    """
    Copy consolidated artifacts from sync repo to local machine.
    Returns list of scopes that were applied.

    Global:
    1. {repo}/consolidated/global/CLAUDE.md     -> ~/.claude/CLAUDE.md
    2. {repo}/consolidated/global/settings.json -> ~/.claude/settings.json

    Per-project:
    1. {repo}/consolidated/projects/{name}/CLAUDE.md -> {project}/.claude/CLAUDE.md
    2. {repo}/consolidated/projects/{name}/memory/   -> ~/.claude/projects/{slug}/memory/
    """
    if skip_scopes is None:
        skip_scopes = set()
    repo = Path(config.repo.local_path)
    applied: list[str] = []

    # Global
    if "global" not in skip_scopes:
        consolidated_global = repo / "consolidated" / "global"
        global_applied = False

        global_md = consolidated_global / "CLAUDE.md"
        if global_md.exists():
            dest = Path.home() / ".claude" / "CLAUDE.md"
            if config.safety.backup_before_apply and dest.exists():
                _backup(dest)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(global_md, dest)
            global_applied = True

        global_settings = consolidated_global / "settings.json"
        if global_settings.exists():
            dest = Path.home() / ".claude" / "settings.json"
            if config.safety.backup_before_apply and dest.exists():
                _backup(dest)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(global_settings, dest)
            global_applied = True

        if global_applied:
            applied.append("global")

    # Per-project
    consolidated_projects = repo / "consolidated" / "projects"
    if consolidated_projects.exists():
        for project_dir in consolidated_projects.iterdir():
            if not project_dir.is_dir():
                continue
            name = project_dir.name
            scope = f"projects/{name}"
            if scope in skip_scopes:
                continue

            local_project = _find_local_project(name, config)
            if local_project is None:
                console.print(f"[yellow]Warning: no local project found matching '{name}', skipping scope {scope}[/yellow]")
                continue

            scope_applied = False

            consolidated_md = project_dir / "CLAUDE.md"
            if consolidated_md.exists():
                dest = local_project / ".claude" / "CLAUDE.md"
                if config.safety.backup_before_apply and dest.exists():
                    _backup(dest)
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(consolidated_md, dest)
                scope_applied = True

            consolidated_memory = project_dir / "memory"
            if consolidated_memory.exists():
                dest_memory = claude_memory_dir(local_project)
                dest_memory.mkdir(parents=True, exist_ok=True)
                consolidated_rels: set[Path] = set()
                for mem_file in consolidated_memory.rglob("*"):
                    if mem_file.is_file():
                        rel = mem_file.relative_to(consolidated_memory)
                        consolidated_rels.add(rel)
                        dest_file = dest_memory / rel
                        dest_file.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(mem_file, dest_file)
                # Remove local memory files that were previously pushed but
                # are no longer in consolidated (deleted on another machine).
                # Only remove files that exist in our own snapshot — files that
                # were never pushed are left untouched.
                machine_mem = (
                    repo / "machines" / config.client.machine_id
                    / "projects" / name / "memory"
                )
                if machine_mem.exists():
                    for local_file in list(dest_memory.rglob("*")):
                        if local_file.is_file():
                            rel = local_file.relative_to(dest_memory)
                            if rel not in consolidated_rels and (machine_mem / rel).exists():
                                local_file.unlink()
                scope_applied = True

            if scope_applied:
                applied.append(scope)

    return applied


def _backup(path: Path) -> None:
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H%M%SZ")
    backup_dir = path.parent / "backups" / timestamp
    backup_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, backup_dir / path.name)


def _find_local_project(name: str, config: Config) -> Path | None:
    for p in config.projects.paths:
        if Path(p).name == name:
            return Path(p)
    return None


def check_large_diff(local_file: Path, consolidated_file: Path) -> bool:
    """
    Return True if more than 50% of lines differ between the two files.
    """
    local_lines = local_file.read_text(encoding="utf-8", errors="replace").splitlines()
    consolidated_lines = consolidated_file.read_text(encoding="utf-8", errors="replace").splitlines()

    if not local_lines and not consolidated_lines:
        return False

    matcher = difflib.SequenceMatcher(None, local_lines, consolidated_lines)
    matching = sum(block.size for block in matcher.get_matching_blocks())
    total = max(len(local_lines), len(consolidated_lines))
    differing = total - matching
    return (differing / total) > 0.5
