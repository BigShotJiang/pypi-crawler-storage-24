from pathlib import Path
from typing import Literal

from pydantic import BaseModel


class ClientConfig(BaseModel):
    machine_id: str


class ProviderConfig(BaseModel):
    type: Literal["gitlab", "github", "local"] = "gitlab"


class GitLabConfig(BaseModel):
    url: str                                    # e.g. "https://gitlab.com"
    project_id: int
    trigger_token: str = ""                     # pipeline trigger token
    access_token: str = ""                      # personal access token (read_api scope)


class GitHubConfig(BaseModel):
    token: str = ""                             # PAT with repo + actions:write scopes
    repo: str = ""                              # "owner/repo-name"
    workflow_id: str = "synthesize.yml"         # filename in .github/workflows/


class RepoConfig(BaseModel):
    local_path: Path                            # local clone of sync repo


class SafetyConfig(BaseModel):
    backup_before_apply: bool = True


class ProjectsConfig(BaseModel):
    paths: list[Path] = []
    auto_discover: bool = False
    discover_roots: list[Path] = []
    discover_max_depth: int = 2                 # max directory depth to scan for .claude/


class Config(BaseModel):
    client: ClientConfig
    provider: ProviderConfig = ProviderConfig()
    gitlab: GitLabConfig | None = None
    github: GitHubConfig | None = None
    repo: RepoConfig
    projects: ProjectsConfig = ProjectsConfig()
    safety: SafetyConfig = SafetyConfig()


class SyncLogEntry(BaseModel):
    timestamp: str                              # ISO 8601
    scopes_synthesized: list[str]               # e.g. ["global", "projects/my-app"]
    machine_inputs: dict[str, dict[str, str]]   # machine_id → {scope → sha256}


class LastSynthesis(BaseModel):
    last_run: str                               # ISO 8601
    input_hashes: dict[str, dict[str, str]]     # scope → {machine_id → sha256}
