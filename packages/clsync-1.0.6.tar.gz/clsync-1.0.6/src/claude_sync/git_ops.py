from pathlib import Path

import git

from claude_sync.models import Config


def ensure_repo(config: Config) -> git.Repo:
    """Open the repo at config.repo.local_path. Raise error if not a git repo."""
    path = Path(config.repo.local_path)
    try:
        return git.Repo(path)
    except git.InvalidGitRepositoryError:
        raise ValueError(f"Not a git repository: {path}")
    except git.NoSuchPathError:
        raise ValueError(f"Path does not exist: {path}")


def pull_rebase(repo: git.Repo) -> None:
    """git pull --rebase origin main"""
    repo.git.pull("--rebase", "origin", "main")


def commit_and_push(repo: git.Repo, message: str) -> bool:
    """
    Stage all changes, commit with message, push to origin main.
    Returns True if there were changes to commit, False if working tree was clean.
    """
    if not has_changes(repo):
        return False
    repo.git.add("-A")
    repo.index.commit(message)
    repo.git.push("origin", "main")
    return True


def has_changes(repo: git.Repo) -> bool:
    """Check if there are staged or unstaged changes (including untracked files)."""
    return repo.is_dirty(untracked_files=True)
