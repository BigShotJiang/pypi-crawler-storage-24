import re
import shutil
import socket
import subprocess
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from claude_sync.apply import apply_consolidated, check_large_diff
from claude_sync.claude_paths import claude_project_dir, project_slug
from claude_sync.config import init_config, load_config, save_config
from claude_sync.git_ops import commit_and_push, ensure_repo, pull_rebase
from claude_sync.ci_provider import get_provider
from claude_sync.lock import is_claude_code_running
from claude_sync.models import Config
from claude_sync.scaffold import scaffold_sync_repo
from claude_sync.snapshot import snapshot, walk_limited

app = typer.Typer(name="clsync", help="Sync Claude Code knowledge across machines")
console = Console()


def _deprecated_entry() -> None:
    """Entry point for the deprecated 'claude-sync' command name."""
    console.print(
        "[yellow]Warning: 'claude-sync' is deprecated. Use 'clsync' instead.[/yellow]"
    )
    app()


@app.command()
def init(
    machine_id: str = typer.Option(None, help="Unique ID for this machine"),
    provider: str = typer.Option(None, "--provider", help="CI provider: gitlab, github, or local"),
    repo_path: Path = typer.Option(..., help="Local path to the cloned sync repo"),
    # GitLab options
    gitlab_url: str = typer.Option(None, "--gitlab-url", help="GitLab instance URL, e.g. https://gitlab.example.com"),
    project_id: int = typer.Option(None, "--project-id", help="GitLab project ID of the sync repo"),
    trigger_token: str = typer.Option(None, "--trigger-token", help="GitLab pipeline trigger token"),
    access_token: str = typer.Option(None, "--access-token", help="GitLab personal access token (read_api scope)"),
    # GitHub options
    github_token: str = typer.Option(None, "--github-token", help="GitHub personal access token (repo + actions:write)"),
    github_repo: str = typer.Option(None, "--github-repo", help="GitHub repo in owner/name format"),
    github_workflow: str = typer.Option("synthesize.yml", "--github-workflow", help="Workflow filename in .github/workflows/"),
) -> None:
    """Initialize clsync configuration."""
    if machine_id is None:
        hostname = socket.gethostname()
        use_hostname = typer.confirm(f'No --machine-id given. Use "{hostname}"?', default=True)
        if use_hostname:
            machine_id = hostname
        else:
            machine_id = typer.prompt("Enter machine ID")

    machine_id = _validate_machine_id(machine_id)

    if provider is None:
        provider = typer.prompt(
            "CI provider (gitlab/github/local)",
            default="gitlab",
        ).strip().lower()
    if provider not in ("gitlab", "github", "local"):
        console.print(f"[red]Unknown provider '{provider}'. Choose gitlab, github, or local.[/red]")
        raise typer.Exit(1)

    import git as _git

    repo_path = repo_path.resolve()
    is_valid_repo = False
    if repo_path.exists():
        try:
            _git.Repo(repo_path)
            is_valid_repo = True
        except Exception:
            pass

    if not is_valid_repo:
        console.print(f"[yellow]{repo_path} is not a git repository.[/yellow]")
        if typer.confirm("Clone from a remote URL?", default=True):
            clone_url = typer.prompt("Enter the remote URL to clone from")
            console.print(f"Cloning {clone_url} into {repo_path}...")
            _git.Repo.clone_from(clone_url, repo_path)
            console.print("[green]Cloned successfully.[/green]")

    init_kwargs: dict = dict(
        machine_id=machine_id,
        repo_local_path=repo_path,
        provider_type=provider,
    )

    if provider == "gitlab":
        if gitlab_url is None:
            gitlab_url = typer.prompt("GitLab instance URL (e.g. https://gitlab.example.com)")
        if project_id is None:
            project_id = typer.prompt("GitLab project ID", type=int)
        if trigger_token is None:
            trigger_token = typer.prompt("GitLab pipeline trigger token", default="", show_default=False)
        if trigger_token and not trigger_token.startswith("glptt-"):
            console.print("[yellow]Warning: trigger token should start with 'glptt-'.[/yellow]")
        if access_token is None:
            access_token = typer.prompt("GitLab access token (read_api scope)", default="", show_default=False)
        if access_token and not access_token.startswith("glpat-"):
            console.print("[yellow]Warning: access token should start with 'glpat-'.[/yellow]")
        init_kwargs.update(
            gitlab_url=gitlab_url,
            project_id=project_id,
            trigger_token=trigger_token or "",
            access_token=access_token or "",
        )

    elif provider == "github":
        if github_token is None:
            github_token = typer.prompt("GitHub personal access token (repo + actions:write)", default="", show_default=False)
        if github_repo is None:
            github_repo = typer.prompt("GitHub repo (owner/name, e.g. hahtse/claude-knowledge-sync)")
        init_kwargs.update(
            github_token=github_token or "",
            github_repo=github_repo or "",
            github_workflow_id=github_workflow,
        )

    init_config(**init_kwargs)
    console.print(f"[green]Config created for machine '{machine_id}' using provider '{provider}'.[/green]")

    # Scaffold CI config and pipeline scripts into the sync repo if not already present.
    try:
        written = scaffold_sync_repo(repo_path, provider=provider)
        if written:
            console.print("Scaffolded CI config into sync repo:")
            for f in written:
                console.print(f"  [dim]{f}[/dim]")
            if typer.confirm("Commit and push CI config to remote?", default=True):
                repo = _git.Repo(repo_path)
                repo.git.add("-A")
                repo.index.commit("chore: add claude-sync CI pipeline config")
                repo.git.push("origin", "main")
                console.print("[green]CI config committed and pushed.[/green]")
    except Exception as exc:
        console.print(f"[yellow]Warning: could not scaffold CI config: {exc}[/yellow]")

    if provider == "local":
        console.print("[dim]Local provider: set ANTHROPIC_API_KEY before running 'clsync trigger'.[/dim]")
    elif provider == "github":
        console.print("[dim]GitHub provider: add ANTHROPIC_API_KEY as a repository secret in Settings → Secrets.[/dim]")
    elif provider == "gitlab":
        console.print("[dim]GitLab provider: add ANTHROPIC_API_KEY as a masked CI/CD variable in Settings → CI/CD → Variables.[/dim]")

    console.print("Next steps:")
    console.print("  clsync add-project PATH   — register a project")
    console.print("  clsync push               — push your first snapshot")


@app.command(name="add-project")
def add_project(
    path: Path = typer.Argument(..., help="Path to the project directory"),
) -> None:
    """Register a local project for syncing."""
    config = load_config()
    path = path.resolve()

    if not (path / ".claude").exists():
        console.print(f"[yellow]Warning: {path}/.claude/ does not exist.[/yellow]")

    # Enforce that directory name matches git remote repo name
    _check_name_matches_remote(path)

    # Check for basename collision with existing registrations
    for existing in config.projects.paths:
        if Path(existing).name == path.name and Path(existing).resolve() != path:
            console.print(
                f"[red]Error: another project named '{path.name}' is already registered "
                f"at {existing}. clsync uses directory names as scope identifiers — "
                f"duplicate names would cause conflicts.[/red]"
            )
            raise typer.Exit(1)

    if path not in [Path(p).resolve() for p in config.projects.paths]:
        config.projects.paths.append(path)
        save_config(config)
        console.print(f"[green]Added {path}[/green]")
    else:
        console.print(f"[yellow]{path} is already registered.[/yellow]")


@app.command(name="remove-project")
def remove_project(
    path: Path = typer.Argument(..., help="Path to the project directory to unregister"),
    purge: bool = typer.Option(False, "--purge", help="Also delete local Claude memory files (~/.claude/projects/{slug}/)"),
) -> None:
    """Unregister a local project from syncing."""
    config = load_config()
    path = path.resolve()

    registered = [Path(p).resolve() for p in config.projects.paths]
    if path not in registered:
        console.print(f"[red]{path} is not registered.[/red]")
        raise typer.Exit(1)

    config.projects.paths = [p for p in config.projects.paths if Path(p).resolve() != path]
    save_config(config)
    console.print(f"[green]Removed {path}[/green]")

    machine_id = config.client.machine_id
    scope_name = path.name
    console.print(
        f"[yellow]Note: machines/{machine_id}/projects/{scope_name}/ in your sync repo is now stale.\n"
        f"Delete it manually and push, or it will be ignored on the next synthesis.[/yellow]"
    )

    if purge:
        slug_dir = claude_project_dir(path)
        if slug_dir.exists():
            shutil.rmtree(slug_dir)
            console.print(f"[green]Deleted local Claude data: {slug_dir}[/green]")
        else:
            console.print(f"[dim]No local Claude data found at {slug_dir}[/dim]")


@app.command(name="move-project")
def move_project(
    old_path: Path = typer.Argument(..., help="Current registered path"),
    new_path: Path = typer.Argument(..., help="New path"),
    rename_dir: bool = typer.Option(False, "--rename-dir", help="Also rename the directory on disk"),
) -> None:
    """Move a registered project to a new path, updating config and Claude internal files."""
    config = load_config()
    old_path = old_path.resolve()
    new_path = new_path.resolve()

    registered = [Path(p).resolve() for p in config.projects.paths]
    if old_path not in registered:
        console.print(f"[red]{old_path} is not registered.[/red]")
        raise typer.Exit(1)
    if new_path in registered:
        console.print(f"[red]{new_path} is already registered.[/red]")
        raise typer.Exit(1)

    # Check new name against git remote
    target = new_path if new_path.exists() else old_path
    _check_name_matches_remote(target, new_name=new_path.name)

    # Rename filesystem directory if requested
    if rename_dir:
        if not old_path.exists():
            console.print(f"[red]Directory {old_path} does not exist — cannot rename.[/red]")
            raise typer.Exit(1)
        old_path.rename(new_path)
        console.print(f"[green]Renamed {old_path} → {new_path}[/green]")

    # Rename ~/.claude/projects/ slug
    old_slug_dir = claude_project_dir(old_path)
    new_slug_dir = claude_project_dir(new_path)
    if old_slug_dir.exists():
        old_slug_dir.rename(new_slug_dir)
        console.print(f"[green]Renamed Claude data: {old_slug_dir.name} → {new_slug_dir.name}[/green]")
    else:
        console.print(f"[dim]No Claude data found at {old_slug_dir} — skipping slug rename.[/dim]")

    # Update config
    config.projects.paths = [
        new_path if Path(p).resolve() == old_path else Path(p)
        for p in config.projects.paths
    ]
    save_config(config)
    console.print(f"[green]Config updated: {old_path} → {new_path}[/green]")

    old_name = old_path.name
    new_name = new_path.name
    if old_name != new_name:
        console.print(
            f"[yellow]Note: machines/{{machine_id}}/projects/{old_name}/ in the sync repo is now stale.\n"
            f"Run 'clsync sync' — the next push will create projects/{new_name}/ and the old one can be deleted.[/yellow]"
        )


@app.command(name="list-projects")
def list_projects() -> None:
    """List all registered projects and their sync status."""
    config = load_config()

    if not config.projects.paths:
        console.print("[yellow]No projects registered. Use 'clsync add-project PATH' to add one.[/yellow]")
        return

    table = Table("Path", "Scope name", "CLAUDE.md", "Memory", "Git remote")
    for p in config.projects.paths:
        p = Path(p)
        scope_name = p.name
        has_claude_md = "yes" if (p / ".claude" / "CLAUDE.md").exists() else "no"
        mem_dir = claude_project_dir(p) / "memory"
        try:
            has_memory = "yes" if mem_dir.exists() and any(mem_dir.iterdir()) else "no"
        except OSError:
            has_memory = "no"
        remote_match = _remote_name_matches(p)
        if remote_match is None:
            remote_col = "[dim]no remote[/dim]"
        elif remote_match:
            remote_col = "[green]ok[/green]"
        else:
            remote_name = _get_remote_repo_name(p)
            remote_col = f"[red]mismatch (remote: {remote_name})[/red]"
        display_path = str(p.parent / p.name) if len(str(p)) > 40 else str(p)
        table.add_row(display_path, scope_name, has_claude_md, has_memory, remote_col)

    console.print(table)


@app.command()
def discover(
    root: Path = typer.Option(..., help="Root directory to scan"),
    depth: int = typer.Option(None, help="Max scan depth"),
) -> None:
    """Discover projects containing a .claude/ directory and optionally add them."""
    config = load_config()
    max_depth = depth if depth is not None else config.projects.discover_max_depth

    found: list[Path] = []
    found_set: set[Path] = set()
    root = root.resolve()
    for entry in walk_limited(root, max_depth):
        resolved = entry.resolve()
        if resolved in found_set:
            continue
        # Check for .claude/ directory in the project itself
        if (entry / ".claude").is_dir():
            found.append(resolved)
            found_set.add(resolved)
            continue
        # Check ~/.claude/projects/ for a matching slug with memory/ subdir
        slug_dir = claude_project_dir(entry)
        if (slug_dir / "memory").is_dir():
            found.append(resolved)
            found_set.add(resolved)

    if not found:
        console.print("No projects found.")
        return

    console.print(f"Found {len(found)} project(s):")
    for p in found:
        console.print(f"  {p}")

    if typer.confirm("Add these projects to your config?"):
        existing = {Path(p).resolve() for p in config.projects.paths}
        added = 0
        skipped = 0
        for p in found:
            if p.resolve() not in existing:
                remote_match = _remote_name_matches(p)
                if remote_match is False:
                    remote_name = _get_remote_repo_name(p)
                    console.print(
                        f"  [yellow]Skipping {p.name}: dirname doesn't match "
                        f"remote repo name '{remote_name}'[/yellow]"
                    )
                    skipped += 1
                    continue
                # Check basename collision with already-registered projects
                existing_names = {Path(ep).name for ep in config.projects.paths}
                if p.name in existing_names:
                    console.print(
                        f"  [yellow]Skipping {p}: name '{p.name}' conflicts with "
                        f"already-registered project[/yellow]"
                    )
                    skipped += 1
                    continue
                config.projects.paths.append(p)
                added += 1
        save_config(config)
        console.print(f"[green]Added {added} project(s).[/green]")
        if skipped:
            console.print(
                f"[yellow]Skipped {skipped} project(s) due to name mismatch. "
                f"Rename directories to match git remote names.[/yellow]"
            )


@app.command()
def bootstrap(
    project: Path = typer.Option(None, help="Bootstrap only this project path"),
    global_only: bool = typer.Option(False, "--global-only", help="Bootstrap only global ~/.claude/CLAUDE.md"),
    api_key: str = typer.Option(None, "--api-key", help="Anthropic API key (or set ANTHROPIC_API_KEY env var)"),
    force: bool = typer.Option(False, "--force", help="Overwrite existing CLAUDE.md without confirmation"),
) -> None:
    """Generate CLAUDE.md files from existing Claude Code memory and session artifacts."""
    import difflib
    import os

    resolved_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
    if not resolved_key:
        console.print(
            "[red]No API key found. Provide --api-key or set ANTHROPIC_API_KEY.[/red]"
        )
        raise typer.Exit(1)

    from claude_sync.bootstrap import (
        gather_global_context,
        gather_project_context,
        generate_claude_md,
    )

    config = load_config()

    def _confirm_overwrite(dest: Path, new_content: str) -> bool:
        """Show diff summary and ask for confirmation. Returns True if should write."""
        if not dest.exists() or force:
            return True
        old_content = dest.read_text(encoding="utf-8", errors="replace")
        diff = list(difflib.unified_diff(
            old_content.splitlines(), new_content.splitlines(),
            fromfile="current", tofile="generated", lineterm="",
        ))
        if not diff:
            console.print("  No changes from existing file.")
            return False
        console.print(f"  [bold]Diff summary for {dest}:[/bold]")
        added = sum(1 for l in diff if l.startswith("+") and not l.startswith("+++"))
        removed = sum(1 for l in diff if l.startswith("-") and not l.startswith("---"))
        console.print(f"  [green]+{added} lines[/green], [red]-{removed} lines[/red]")
        return typer.confirm("  Overwrite existing CLAUDE.md?", default=True)

    if project is not None:
        project = project.resolve()
        registered = {Path(p).resolve() for p in config.projects.paths}
        if project not in registered:
            console.print(
                f"[red]{project} is not registered. Use 'clsync add-project' first.[/red]"
            )
            raise typer.Exit(1)
        console.print(f"Bootstrapping project: {project}")
        context = gather_project_context(project)
        if not context:
            console.print("[yellow]No context found for this project — nothing generated.[/yellow]")
            return
        result = generate_claude_md(context, f"projects/{project.name}", resolved_key)
        if result is None:
            console.print("[yellow]Generation returned no output.[/yellow]")
            return
        dest = project / ".claude" / "CLAUDE.md"
        if _confirm_overwrite(dest, result):
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(result, encoding="utf-8")
            console.print(f"[green]Written: {dest}[/green]")
        return

    if global_only:
        console.print("Bootstrapping global ~/.claude/CLAUDE.md")
        context = gather_global_context([Path(p) for p in config.projects.paths])
        if not context:
            console.print("[yellow]No global context found — nothing generated.[/yellow]")
            return
        result = generate_claude_md(context, "global", resolved_key)
        if result is None:
            console.print("[yellow]Generation returned no output.[/yellow]")
            return
        dest = Path.home() / ".claude" / "CLAUDE.md"
        if _confirm_overwrite(dest, result):
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(result, encoding="utf-8")
            console.print(f"[green]Written: {dest}[/green]")
        return

    # Default: bootstrap all registered projects, then global
    for p in config.projects.paths:
        p = Path(p).resolve()
        console.print(f"Bootstrapping project: {p.name}")
        context = gather_project_context(p)
        if not context:
            console.print(f"[yellow]  No context found for {p.name}, skipping.[/yellow]")
            continue
        result = generate_claude_md(context, f"projects/{p.name}", resolved_key)
        if result is None:
            console.print(f"[yellow]  Generation returned no output for {p.name}.[/yellow]")
            continue
        dest = p / ".claude" / "CLAUDE.md"
        if _confirm_overwrite(dest, result):
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(result, encoding="utf-8")
            console.print(f"[green]  Written: {dest}[/green]")

    console.print("Bootstrapping global ~/.claude/CLAUDE.md")
    context = gather_global_context([Path(p) for p in config.projects.paths])
    if not context:
        console.print("[yellow]No global context found — nothing generated.[/yellow]")
        return
    result = generate_claude_md(context, "global", resolved_key)
    if result is None:
        console.print("[yellow]Generation returned no output.[/yellow]")
        return
    dest = Path.home() / ".claude" / "CLAUDE.md"
    if _confirm_overwrite(dest, result):
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(result, encoding="utf-8")
        console.print(f"[green]Written: {dest}[/green]")


@app.command()
def push(
    no_trigger: bool = typer.Option(False, "--no-trigger", help="Skip triggering the CI pipeline"),
) -> None:
    """Push local .claude/ snapshots to the sync repo and optionally trigger synthesis."""
    config = load_config()
    repo = ensure_repo(config)

    console.print("Pulling latest from remote...")
    pull_rebase(repo)

    console.print("Taking snapshot...")
    updated = snapshot(config)
    if updated:
        console.print(f"Updated scopes: {', '.join(updated)}")
    else:
        console.print("No changes detected in local .claude/ files.")

    if updated:
        pushed = commit_and_push(repo, f"snapshot: {config.client.machine_id}")
        if pushed:
            console.print("[green]Pushed to remote.[/green]")
    else:
        console.print("Nothing to push.")

    if not no_trigger:
        if updated:
            provider = get_provider(config)
            run_id = provider.trigger()
            console.print(f"[green]Pipeline triggered (run #{run_id}).[/green]")
        else:
            console.print("[dim]No changes pushed — skipping pipeline trigger. Use 'clsync trigger' to force.[/dim]")


@app.command()
def pull(
    force: bool = typer.Option(False, "--force", help="Skip all safety checks and apply immediately"),
    allow_running: bool = typer.Option(False, "--allow-running", help="Apply even if Claude Code is running (still confirms large diffs)"),
) -> None:
    """Pull consolidated .claude/ files from the sync repo and apply them locally."""
    config = load_config()
    repo = ensure_repo(config)

    console.print("Pulling latest from remote...")
    pull_rebase(repo)

    applied, skip_scopes = _apply_with_checks(config, force=force, allow_running=allow_running)

    if applied:
        console.print(f"[green]Applied: {', '.join(applied)}[/green]")
    if skip_scopes:
        console.print(f"[yellow]Skipped: {', '.join(skip_scopes)}[/yellow]")


@app.command()
def sync(
    allow_running: bool = typer.Option(False, "--allow-running", help="Apply even if Claude Code is running."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip large-diff confirmation prompt."),
) -> None:
    """Push, trigger synthesis, wait for it to complete, then pull."""
    config = load_config()
    repo = ensure_repo(config)

    # Push
    console.print("[bold]Step 1/3: Push[/bold]")
    pull_rebase(repo)
    updated = snapshot(config)
    if updated:
        commit_and_push(repo, f"snapshot: {config.client.machine_id}")
        ci = get_provider(config)
        run_id = ci.trigger()
        console.print(f"Pipeline triggered (run #{run_id}).")

        # Wait
        console.print("[bold]Step 2/3: Waiting for pipeline...[/bold]")
        success = ci.wait_for_completion(run_id)
        if not success:
            console.print(f"[red]Pipeline run #{run_id} failed.[/red]")
            hint = ci.get_failure_diagnosis(run_id)
            if hint:
                console.print(f"[yellow]{hint}[/yellow]")
            raise typer.Exit(1)
    else:
        console.print("[dim]No local changes — skipping pipeline trigger.[/dim]")

    # Pull
    console.print("[bold]Step 3/3: Pull[/bold]")
    pull_rebase(repo)

    applied, skip_scopes = _apply_with_checks(config, force=force, allow_running=allow_running)

    console.print(f"[green]Sync complete. Applied: {', '.join(applied) or 'nothing'}[/green]")
    if skip_scopes:
        console.print(f"[yellow]Skipped: {', '.join(skip_scopes)}[/yellow]")


@app.command()
def trigger(
    wait: bool = typer.Option(False, "--wait", help="Wait for pipeline to finish"),
) -> None:
    """Trigger the synthesis pipeline."""
    config = load_config()
    ci = get_provider(config)
    run_id = ci.trigger()
    console.print(f"[green]Pipeline triggered (run #{run_id}).[/green]")

    if wait:
        success = ci.wait_for_completion(run_id)
        if success:
            console.print("[green]Pipeline succeeded.[/green]")
        else:
            console.print(f"[red]Pipeline run #{run_id} failed.[/red]")
            hint = ci.get_failure_diagnosis(run_id)
            if hint:
                console.print(f"[yellow]{hint}[/yellow]")
            raise typer.Exit(1)


@app.command()
def status() -> None:
    """Show last synthesis status from the sync repo."""
    import json
    config = load_config()
    meta_file = Path(config.repo.local_path) / "meta" / "last-synthesis.json"

    if not meta_file.exists():
        console.print("[yellow]No synthesis has run yet (last-synthesis.json not found).[/yellow]")
        raise typer.Exit(0)

    data = json.loads(meta_file.read_text(encoding="utf-8"))

    console.print(f"Last synthesis: [bold]{data.get('last_run', 'unknown')}[/bold]")

    hashes = data.get("input_hashes", {})
    if not hashes:
        console.print("No scopes synthesized.")
        return

    table = Table("Scope", "Machine", "SHA-256")
    for scope, machines in sorted(hashes.items()):
        for machine_id, sha in sorted(machines.items()):
            table.add_row(scope, machine_id, sha[:12] + "...")
    console.print(table)


# --- helpers ---

def _validate_machine_id(machine_id: str) -> str:
    """Validate machine_id contains only safe characters for use as a directory name."""
    if not machine_id:
        console.print("[red]Machine ID cannot be empty.[/red]")
        raise typer.Exit(1)
    if not re.match(r'^[a-zA-Z0-9._-]+$', machine_id):
        console.print(
            f"[red]Machine ID '{machine_id}' contains invalid characters. "
            f"Use only letters, numbers, hyphens, underscores, and dots.[/red]"
        )
        raise typer.Exit(1)
    return machine_id


def _apply_with_checks(
    config: Config, *, force: bool = False, allow_running: bool = False,
) -> tuple[list[str], set[str]]:
    """
    Shared logic for pull and sync: check safety conditions, apply consolidated
    output, warn about conflict/unverified markers.

    Returns (applied_scopes, skipped_scopes).
    """
    if not force and not allow_running and is_claude_code_running():
        console.print(
            "[yellow]Claude Code appears to be running. "
            "Applying now may cause conflicts. Use --allow-running to apply anyway, "
            "or --force to skip all checks.[/yellow]"
        )
        raise typer.Exit(1)

    skip_scopes: set[str] = set()
    consolidated_dir = Path(config.repo.local_path) / "consolidated"

    if not force and consolidated_dir.exists():
        for scope_path in _iter_consolidated_scopes(consolidated_dir):
            scope = _path_to_scope(scope_path, consolidated_dir)
            consolidated_md = scope_path / "CLAUDE.md"
            local_md = _get_local_path_for_scope(scope, config)
            if local_md and local_md.exists() and consolidated_md.exists():
                if check_large_diff(local_md, consolidated_md):
                    if not typer.confirm(
                        f"Scope '{scope}' has large changes (>50% of lines differ). Apply?"
                    ):
                        skip_scopes.add(scope)

    applied = apply_consolidated(config, skip_scopes=skip_scopes)

    for scope in applied:
        local_md = _get_local_path_for_scope(scope, config)
        if local_md and local_md.exists():
            content = local_md.read_text(encoding="utf-8", errors="replace")
            for line in content.splitlines():
                if "<!-- CONFLICT:" in line or "<!-- UNVERIFIED:" in line:
                    console.print(f"[yellow]Warning [{scope}]: {line.strip()}[/yellow]")

    return applied, skip_scopes


def _check_name_matches_remote(path: Path, new_name: str | None = None) -> None:
    """
    Check that the directory name matches the git remote repo name.
    Prints an error and exits if they differ. No-op if there's no git remote.
    """
    dir_name = new_name or path.name
    remote_name = _get_remote_repo_name(path)
    if remote_name is None:
        return  # no remote, skip check
    if dir_name != remote_name:
        console.print(
            f"[red]Error: directory is named '{dir_name}' but the git remote repo is '{remote_name}'.\n"
            f"clsync uses directory names as project scope identifiers — if this doesn't match\n"
            f"across machines, knowledge from different machines won't be merged and you'll end up\n"
            f"with duplicate scopes. Rename the directory to match the repo name and try again.[/red]"
        )
        raise typer.Exit(1)


def _get_remote_repo_name(path: Path) -> str | None:
    """Return the repository name from git remote origin URL, or None if unavailable."""
    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            cwd=path,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return None
        url = result.stdout.strip().rstrip("/")
        if url.endswith(".git"):
            url = url[:-4]
        return url.split("/")[-1].split(":")[-1]
    except Exception:
        return None


def _remote_name_matches(path: Path) -> bool | None:
    """
    Returns True if dirname matches remote name, False if not, None if no remote.
    """
    remote_name = _get_remote_repo_name(path)
    if remote_name is None:
        return None
    return path.name == remote_name


def _iter_consolidated_scopes(consolidated_dir: Path):
    global_dir = consolidated_dir / "global"
    if global_dir.is_dir():
        yield global_dir
    projects_dir = consolidated_dir / "projects"
    if projects_dir.is_dir():
        for d in projects_dir.iterdir():
            if d.is_dir():
                yield d


def _path_to_scope(scope_path: Path, consolidated_dir: Path) -> str:
    return str(scope_path.relative_to(consolidated_dir)).replace("\\", "/")


def _get_local_path_for_scope(scope: str, config: Config) -> Path | None:
    if scope == "global":
        return Path.home() / ".claude" / "CLAUDE.md"
    if scope.startswith("projects/"):
        name = scope[len("projects/"):]
        for p in config.projects.paths:
            if Path(p).name == name:
                return Path(p) / ".claude" / "CLAUDE.md"
    return None
