import os
import platform
import subprocess


def is_claude_code_running() -> bool:
    """
    Check if a Claude Code process is currently running.

    On Windows: use 'tasklist' and look for 'claude.exe' in process names.
    On Linux/macOS: use 'pgrep' for the 'claude' binary, excluding this process tree.

    Returns True if Claude Code appears to be running.
    Best-effort — returns False on any error.
    """
    try:
        system = platform.system()
        if system == "Windows":
            result = subprocess.run(
                ["tasklist", "/FO", "CSV", "/NH"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            for line in result.stdout.splitlines():
                # CSV fields are quoted: "process.exe","PID",...
                # Extract the process name (first field) for exact matching
                parts = line.strip().split(",")
                if not parts:
                    continue
                proc_name = parts[0].strip('"').lower()
                # Match claude.exe specifically, not claude-sync or other tools
                if proc_name == "claude.exe":
                    return True
            return False
        else:
            # pgrep with -x matches exact process name (not substring)
            # Exclude our own process group to avoid matching claude-sync
            result = subprocess.run(
                ["pgrep", "-x", "claude"],
                capture_output=True,
                timeout=5,
            )
            if result.returncode != 0:
                return False
            # Filter out our own PID and parent PID
            own_pid = str(os.getpid())
            own_ppid = str(os.getppid())
            pids = [
                pid.strip() for pid in result.stdout.decode().splitlines()
                if pid.strip() and pid.strip() not in (own_pid, own_ppid)
            ]
            return len(pids) > 0
    except Exception:
        return False
