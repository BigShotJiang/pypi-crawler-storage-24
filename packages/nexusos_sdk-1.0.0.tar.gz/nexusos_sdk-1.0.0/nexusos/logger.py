"""
NexusOS Logger module.
Provides structured logging with [NexusOS] prefix.
"""


class NexusLogger:
    """Simple structured logger for NexusOS SDK."""

    @staticmethod
    def info(message: str, data: str = '') -> None:
        """Log an info message."""
        print(f'[NexusOS] {message}', data)

    @staticmethod
    def error(message: str, error: Exception = None) -> None:
        """Log an error message."""
        error_str = str(error) if error else ''
        print(f'[NexusOS] ERROR: {message}', error_str)

    @staticmethod
    def warn(message: str, data: str = '') -> None:
        """Log a warning message."""
        print(f'[NexusOS] WARN: {message}', data)

    @staticmethod
    def debug(message: str, data: str = '') -> None:
        """Log a debug message (only if DEBUG env var is set)."""
        import os
        if os.getenv('DEBUG'):
            print(f'[NexusOS] DEBUG: {message}', data)
