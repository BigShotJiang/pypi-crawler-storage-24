import threading
import time
import uuid
import json
from contextlib import contextmanager
from functools import wraps
from datetime import datetime
from typing import Optional, Dict, Any, Callable

try:
    import requests
except ImportError:
    raise ImportError("requests is required. Install it with: pip install requests")


class NexusAgent:
    """
    NexusOS Agent SDK for Python.
    Monitors and logs LLM calls, HTTP requests, and tool actions.
    """

    def __init__(
        self,
        api_key: str,
        agent_id: str,
        base_url: str = 'https://nexusos-backend-7ue5.onrender.com',
        batch_size: int = 10,
        flush_interval: int = 5
    ):
        """
        Initialize a NexusOS Agent.

        Args:
            api_key: API key for NexusOS
            agent_id: Unique agent identifier
            base_url: Base URL for the NexusOS API
            batch_size: Number of logs to batch before flushing
            flush_interval: Interval in seconds to flush logs
        """
        if not api_key:
            raise ValueError('api_key is required')
        if not agent_id:
            raise ValueError('agent_id is required')

        self.api_key = api_key
        self.agent_id = agent_id
        self.base_url = base_url.rstrip('/')
        self.batch_size = batch_size
        self.flush_interval = flush_interval

        self.batch = []
        self.session_id = self._generate_session_id()
        self.lock = threading.Lock()

        self.flush_thread = None
        self.heartbeat_thread = None
        self.running = True

        self._start_flush_thread()

    def log(self, payload: dict) -> None:
        """
        Add a log event to the batch queue.
        Automatically flushes when batch reaches batch_size.

        Args:
            payload: Log event payload
        """
        log_event = {
            'timestamp': datetime.utcnow().isoformat() + 'Z',
            'sessionId': self.session_id,
            'agentId': self.agent_id,
            **self._sanitize(payload)
        }

        with self.lock:
            self.batch.append(log_event)
            if len(self.batch) >= self.batch_size:
                self._flush_batch()

    def log_llm_call(
        self,
        model: str,
        tokens_used: int,
        duration_ms: int,
        prompt: Optional[str] = None,
        response: Optional[str] = None
    ) -> None:
        """
        Log an LLM call.

        Args:
            model: LLM model name (e.g., 'gpt-4')
            tokens_used: Number of tokens used
            duration_ms: Duration in milliseconds
            prompt: Input prompt (optional)
            response: Model response (optional)
        """
        trace_id = self._generate_trace_id()
        self.log({
            'event': 'llm.call',
            'traceId': trace_id,
            'model': model,
            'prompt': prompt,
            'response': response,
            'tokensUsed': tokens_used,
            'durationMs': duration_ms
        })

    def log_http_request(
        self,
        url: str,
        method: str,
        status: int,
        duration_ms: int,
        success: bool
    ) -> None:
        """
        Log an HTTP request.

        Args:
            url: Request URL
            method: HTTP method (GET, POST, etc.)
            status: HTTP status code
            duration_ms: Duration in milliseconds
            success: Whether the request succeeded
        """
        trace_id = self._generate_trace_id()
        self.log({
            'event': 'http.request',
            'traceId': trace_id,
            'url': url,
            'method': method,
            'status': status,
            'durationMs': duration_ms,
            'success': success
        })

    def log_action(
        self,
        tool: str,
        input: Optional[Dict[str, Any]] = None,
        output: Optional[Dict[str, Any]] = None,
        duration_ms: Optional[int] = None,
        success: bool = True,
        error_message: Optional[str] = None
    ) -> None:
        """
        Log a tool action.

        Args:
            tool: Tool name
            input: Tool input (optional)
            output: Tool output (optional)
            duration_ms: Duration in milliseconds (optional)
            success: Whether the action succeeded (default: True)
            error_message: Error message if action failed (optional)
        """
        trace_id = self._generate_trace_id()
        self.log({
            'event': 'action.executed',
            'traceId': trace_id,
            'tool': tool,
            'input': input,
            'output': output,
            'durationMs': duration_ms or 0,
            'success': success,
            'errorMessage': error_message
        })

    def heartbeat(self) -> None:
        """
        Send a heartbeat signal to indicate the agent is alive.
        """
        self.log({
            'event': 'agent.heartbeat',
            'timestamp': datetime.utcnow().isoformat() + 'Z'
        })

    def is_alive(self) -> bool:
        """
        Check if the agent is alive by fetching its stats.

        Returns:
            True if agent is active, False otherwise
        """
        try:
            url = f'{self.base_url}/api/v1/agents/{self.agent_id}/stats'
            headers = {
                'Authorization': f'Bearer {self.api_key}',
                'X-Agent-ID': self.agent_id
            }
            response = requests.get(url, headers=headers, timeout=5)

            if response.status_code == 403:
                return False
            elif response.status_code == 200:
                parsed = response.json()
                # Backend wraps in { success, data: { status }, message }
                return parsed.get('data', {}).get('status') == 'active'
            else:
                return False
        except Exception:
            return False

    def start_heartbeat(self, interval: int = 60) -> None:
        """
        Start a background thread to send periodic heartbeats.

        Args:
            interval: Interval in seconds between heartbeats (default: 60)
        """
        if self.heartbeat_thread and self.heartbeat_thread.is_alive():
            return

        self.heartbeat_thread = threading.Thread(
            target=self._heartbeat_loop,
            args=(interval,),
            daemon=True
        )
        self.heartbeat_thread.start()

    @contextmanager
    def trace(self, name: str):
        """
        Context manager to trace the execution of a code block.

        Args:
            name: Name of the trace

        Yields:
            TraceContext object with set_output() method

        Example:
            with agent.trace("process_data") as t:
                result = process_data()
                t.set_output(result)
        """
        trace_id = self._generate_trace_id()
        start_time = time.time()

        self.log({
            'event': 'trace.start',
            'traceId': trace_id,
            'name': name,
            'timestamp': datetime.utcnow().isoformat() + 'Z'
        })

        context = TraceContext()

        try:
            yield context
            duration_ms = int((time.time() - start_time) * 1000)
            self.log({
                'event': 'trace.end',
                'traceId': trace_id,
                'name': name,
                'success': True,
                'durationMs': duration_ms,
                'output': context.output,
                'timestamp': datetime.utcnow().isoformat() + 'Z'
            })
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            self.log({
                'event': 'trace.end',
                'traceId': trace_id,
                'name': name,
                'success': False,
                'durationMs': duration_ms,
                'errorMessage': str(e),
                'timestamp': datetime.utcnow().isoformat() + 'Z'
            })
            raise

    def monitor(self, tool: Optional[str] = None) -> Callable:
        """
        Decorator to automatically log function execution.

        Args:
            tool: Tool name (defaults to function name if not provided)

        Returns:
            Decorated function that logs execution

        Example:
            @agent.monitor(tool="web_search")
            def search_web(query):
                return results
        """
        def decorator(func: Callable) -> Callable:
            tool_name = tool or func.__name__

            @wraps(func)
            def wrapper(*args, **kwargs):
                start_time = time.time()
                try:
                    result = func(*args, **kwargs)
                    duration_ms = int((time.time() - start_time) * 1000)
                    self.log_action(
                        tool=tool_name,
                        input={'args': str(args), 'kwargs': str(kwargs)},
                        output=result,
                        duration_ms=duration_ms,
                        success=True
                    )
                    return result
                except Exception as e:
                    duration_ms = int((time.time() - start_time) * 1000)
                    self.log_action(
                        tool=tool_name,
                        input={'args': str(args), 'kwargs': str(kwargs)},
                        duration_ms=duration_ms,
                        success=False,
                        error_message=str(e)
                    )
                    raise

            @wraps(func)
            async def async_wrapper(*args, **kwargs):
                start_time = time.time()
                try:
                    result = await func(*args, **kwargs)
                    duration_ms = int((time.time() - start_time) * 1000)
                    self.log_action(
                        tool=tool_name,
                        input={'args': str(args), 'kwargs': str(kwargs)},
                        output=result,
                        duration_ms=duration_ms,
                        success=True
                    )
                    return result
                except Exception as e:
                    duration_ms = int((time.time() - start_time) * 1000)
                    self.log_action(
                        tool=tool_name,
                        input={'args': str(args), 'kwargs': str(kwargs)},
                        duration_ms=duration_ms,
                        success=False,
                        error_message=str(e)
                    )
                    raise

            import asyncio
            if asyncio.iscoroutinefunction(func):
                return async_wrapper
            return wrapper

        return decorator

    def _flush_batch(self) -> None:
        """
        Internal: Flush the batch to the API endpoint.
        Sends each log individually to POST /api/v1/logs/ingest.
        Backend expects: { event, action, context }
        """
        if not self.batch:
            return

        batch_to_send = self.batch.copy()
        self.batch.clear()

        # Map SDK event names → backend enum values
        EVENT_MAP = {
            'llm.call':        'agent.llm_call',
            'http.request':    'agent.http_request',
            'action.executed': 'agent.action',
            'trace.start':     'agent.action',
            'trace.end':       'agent.action',
            'agent.heartbeat': 'agent.heartbeat',
        }

        def send_logs():
            url = f'{self.base_url}/api/v1/logs/ingest'
            headers = {
                'Authorization': f'Bearer {self.api_key}',
                'X-Agent-ID': self.agent_id,
                'Content-Type': 'application/json'
            }
            for log in batch_to_send:
                event = log.get('event')
                session_id = log.get('sessionId')
                timestamp = log.get('timestamp')
                mapped_event = EVENT_MAP.get(event, 'agent.action')

                # Map SDK fields → backend AuditLog action schema
                action = {}
                if event == 'llm.call':
                    action = {
                        'model':      log.get('model'),
                        'tokensUsed': log.get('tokensUsed'),
                        'durationMs': log.get('durationMs'),
                        'input':      log.get('prompt'),
                        'output':     log.get('response'),
                        'success':    True
                    }
                elif event == 'http.request':
                    action = {
                        'httpUrl':    log.get('url'),
                        'httpMethod': log.get('method'),
                        'httpStatus': log.get('status'),
                        'durationMs': log.get('durationMs'),
                        'success':    log.get('success')
                    }
                elif event == 'action.executed':
                    action = {
                        'tool':         log.get('tool'),
                        'input':        log.get('input'),
                        'output':       log.get('output'),
                        'durationMs':   log.get('durationMs'),
                        'success':      log.get('success'),
                        'errorMessage': log.get('errorMessage')
                    }

                payload = {
                    'event': mapped_event,
                    'action': action,
                    'context': {
                        'sessionId': session_id,
                        'timestamp': timestamp,
                        'ipAddress': None
                    }
                }
                try:
                    response = requests.post(url, json=payload, headers=headers, timeout=10)
                    if not response.ok:
                        print(f'[NexusOS] Failed to ingest log ({response.status_code}): {response.text}')
                except Exception as e:
                    print(f'[NexusOS] Network error ingesting log: {e}')

        thread = threading.Thread(target=send_logs, daemon=True)
        thread.start()

    def _sanitize(self, obj: Any) -> Any:
        """
        Internal: Deep-clone and remove sensitive keys.
        Removes keys containing: password, secret, key, token, auth (case-insensitive).
        """
        if obj is None or isinstance(obj, (str, int, float, bool)):
            return obj

        if isinstance(obj, list):
            return [self._sanitize(item) for item in obj]

        if isinstance(obj, dict):
            sensitive_keys = {'password', 'secret', 'apikey', 'api_key', 'token', 'auth', 'authorization', 'accesstoken', 'access_token'}
            sanitized = {}

            for key, value in obj.items():
                if key.lower() in sensitive_keys:
                    sanitized[key] = '[REDACTED]'
                else:
                    sanitized[key] = self._sanitize(value)

            return sanitized

        return obj

    def _generate_trace_id(self) -> str:
        """
        Internal: Generate a random trace ID.
        """
        return uuid.uuid4().hex

    def _generate_session_id(self) -> str:
        """
        Internal: Generate a random session ID.
        """
        return uuid.uuid4().hex

    def _start_flush_thread(self) -> None:
        """
        Internal: Start the batch flusher thread.
        """
        def flush_loop():
            while self.running:
                time.sleep(self.flush_interval)
                with self.lock:
                    if self.batch:
                        self._flush_batch()

        self.flush_thread = threading.Thread(target=flush_loop, daemon=True)
        self.flush_thread.start()

    def _heartbeat_loop(self, interval: int) -> None:
        """
        Internal: Heartbeat loop for background thread.
        """
        while self.running:
            try:
                self.heartbeat()
            except Exception as e:
                print(f'[NexusOS] Heartbeat failed: {e}')
            time.sleep(interval)

    def shutdown(self) -> None:
        """
        Shutdown the agent: stop all threads and flush remaining logs.
        """
        self.running = False

        with self.lock:
            if self.batch:
                self._flush_batch()

        if self.flush_thread and self.flush_thread.is_alive():
            self.flush_thread.join(timeout=5)

        if self.heartbeat_thread and self.heartbeat_thread.is_alive():
            self.heartbeat_thread.join(timeout=5)

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit: shutdown the agent."""
        self.shutdown()
        return False


class TraceContext:
    """Context object for trace operations."""

    def __init__(self):
        self.output = None

    def set_output(self, output: Any) -> None:
        """
        Set the output of the traced operation.

        Args:
            output: Output value to record
        """
        self.output = output
