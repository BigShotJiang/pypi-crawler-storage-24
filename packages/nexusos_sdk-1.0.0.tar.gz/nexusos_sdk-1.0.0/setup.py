from setuptools import setup, find_packages
import os

# Read the README for the PyPI long description
here = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(here, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='nexusos-sdk',
    version='1.0.0',
    description='Official Python SDK for NexusOS AI Agent Governance',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='NexusOS',
    url='https://github.com/umair24171/nexusos-dashboard',
    license='MIT',
    packages=find_packages(),
    install_requires=[
        'requests>=2.28.0',
    ],
    python_requires='>=3.8',
    keywords=[
        'nexusos', 'ai', 'agent', 'governance', 'monitoring',
        'llm', 'logging', 'observability', 'openai', 'langchain'
    ],
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
    ],
    project_urls={
        'Homepage': 'https://nexusos-landing.vercel.app',
        'Dashboard': 'https://nexusos-dashboard.vercel.app',
        'Bug Reports': 'https://github.com/umair24171/nexusos-dashboard/issues',
    },
)
