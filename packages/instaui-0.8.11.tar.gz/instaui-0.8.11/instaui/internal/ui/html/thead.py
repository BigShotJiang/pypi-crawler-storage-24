from __future__ import annotations
from typing import Any
from instaui.internal.ui.element import Element


class THead(Element):
    def __init__(
        self,
        text: str | Any | None = None,
    ):
        super().__init__("thead")
        self.props(
            {
                "innerText": text,
            }
        )
