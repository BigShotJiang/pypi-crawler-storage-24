from __future__ import annotations
from typing import Any, Optional, Union
from instaui.internal.ui.element import Element
from instaui.internal.ui.value_element import ValueElement
from instaui.internal.ui.disabled_element import DisabledElement
from ._mixins import InputEventMixin


class Input(InputEventMixin, DisabledElement, ValueElement[str]):
    def __init__(
        self,
        value: Union[str, Any, None] = None,
        *,
        model_value: Union[str, Any, None] = None,
        disabled: Optional[bool] = None,
        type: str | None = None,
    ):
        super().__init__("input", value, is_html_component=True)

        self.props({"type": type, "disabled": disabled})

        if model_value is not None:
            self.props({"value": model_value})

    def _input_event_mixin_element(self) -> Element:
        return self
