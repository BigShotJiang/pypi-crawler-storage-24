from __future__ import annotations
from instaui.internal.ui.element import Element
from instaui.internal.ui.event import EventMixin
from instaui.internal.ui.event_modifier import TEventModifier


class Dialog(Element):
    """HTML dialog element for creating modal or non-modal dialogs.

    Corresponds to the HTML <dialog> tag, supporting dialog show, close, and cancel events.
    The initial visibility of the dialog can be controlled through the open property.

    Args:
        title (str | None, optional): Dialog title. Defaults to None.
        open (bool, optional): Whether the dialog is initially open. Defaults to False.
        on_close (EventMixin | None, optional): Event handler for dialog close event. Defaults to None.
        on_cancel (EventMixin | None, optional): Event handler for dialog cancel event (triggered by ESC key). Defaults to None.
        on_show (EventMixin | None, optional): Event handler for dialog show event. Defaults to None.
    """

    def __init__(
        self,
        *,
        title: str | None = None,
        open: bool = False,
        on_close: EventMixin | None = None,
        on_cancel: EventMixin | None = None,
        on_show: EventMixin | None = None,
    ):
        super().__init__("dialog")
        self.props(
            {
                "title": title,
                "open": open,
            }
        )

        if on_close:
            self.on_close(on_close)
        if on_cancel:
            self.on_cancel(on_cancel)
        if on_show:
            self.on_show(on_show)

    def on_close(
        self,
        handler: EventMixin,
        *,
        params: list | None = None,
        modifier: list[TEventModifier] | None = None,
    ):
        """Bind dialog close event.

        Triggered when the dialog is closed via the close() method.

        Args:
            handler (EventMixin): Event handler function.
            params (list | None, optional): Parameters to pass to the handler. Defaults to None.
            modifier (list[TEventModifier] | None, optional): Event modifiers. Defaults to None.

        Returns:
            Dialog: Returns self instance for method chaining.
        """
        self.on("close", handler, params=params, modifier=modifier)
        return self

    def on_cancel(
        self,
        handler: EventMixin,
        *,
        params: list | None = None,
        modifier: list[TEventModifier] | None = None,
    ):
        """Bind dialog cancel event.

        Triggered when the user closes the dialog by pressing the ESC key.
        Note: Only modal dialogs opened with showModal() support ESC key cancellation.

        Args:
            handler (EventMixin): Event handler function.
            params (list | None, optional): Parameters to pass to the handler. Defaults to None.
            modifier (list[TEventModifier] | None, optional): Event modifiers. Defaults to None.

        Returns:
            Dialog: Returns self instance for method chaining.
        """
        self.on("cancel", handler, params=params, modifier=modifier)
        return self

    def on_show(
        self,
        handler: EventMixin,
        *,
        params: list | None = None,
        modifier: list[TEventModifier] | None = None,
    ):
        """Bind dialog show event.

        Triggered when the dialog is displayed via show() or showModal() methods.

        Args:
            handler (EventMixin): Event handler function.
            params (list | None, optional): Parameters to pass to the handler. Defaults to None.
            modifier (list[TEventModifier] | None, optional): Event modifiers. Defaults to None.

        Returns:
            Dialog: Returns self instance for method chaining.
        """
        self.on("show", handler, params=params, modifier=modifier)
        return self
