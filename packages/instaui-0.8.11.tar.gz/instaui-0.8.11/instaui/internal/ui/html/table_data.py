from __future__ import annotations
from typing import Any
from instaui.internal.ui.element import Element


class TableData(Element):
    def __init__(
        self,
        text: str | Any | None = None,
    ):
        super().__init__("td")
        self.props(
            {
                "innerText": text,
            }
        )
