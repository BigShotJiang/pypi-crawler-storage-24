"""ActionGate LangChain Integration — gate tool execution with ActionGate primitives."""

from .actiongate_langchain import GatedTool, gated_tool

__all__ = ["GatedTool", "gated_tool"]
__version__ = "0.1.0"
