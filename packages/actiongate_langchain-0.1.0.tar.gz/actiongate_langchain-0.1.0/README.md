# actiongate-langchain

Gate LangChain tool execution through [ActionGate](https://github.com/actiongate-oss/actiongate) primitives.

```
pip install actiongate-langchain
```

## Quick start

```python
from actiongate import Engine, Gate, Policy
from actiongate_langchain import gated_tool

ag = Engine()

@gated_tool(
    actiongate=ag,
    gate=Gate("tools", "search", "agent:1"),
    policy=Policy(max_calls=10, window=60),
)
def search_web(query: str) -> str:
    """Search the web for a query."""
    return api.search(query)

# Use with any LangChain agent
agent = create_react_agent(llm, [search_web], prompt)
```

The tool checks all gates before execution. If any gate blocks, it raises `ToolException` with the block reason — LangChain agents handle this automatically.

## Add more gates

```
pip install actiongate-langchain[all]
```

```python
from actiongate import Engine as AG, Gate, Policy
from budgetgate import Engine as BG, Ledger, Budget
from rulegate import Engine as RG, Rule, Ruleset, Context
from actiongate_langchain import gated_tool
from decimal import Decimal

def no_pii(ctx: Context) -> bool:
    return "ssn" not in str(ctx.kwargs).lower()

ag, bg, rg = AG(), BG(), RG()

@gated_tool(
    actiongate=ag,
    gate=Gate("tools", "search", "agent:1"),
    policy=Policy(max_calls=10, window=60),
    budgetgate=bg,
    ledger=Ledger("openai", "search", "agent:1"),
    budget=Budget(max_spend=Decimal("5.00"), window=3600),
    cost=Decimal("0.01"),
    rulegate=rg,
    rule=Rule("tools", "search"),
    ruleset=Ruleset(predicates=(no_pii,)),
)
def search_web(query: str) -> str:
    """Search the web for a query."""
    return api.search(query)
```

Gates evaluate in order: ActionGate → BudgetGate → RuleGate → execute → AuditGate.

## GatedTool class

For more control, use `GatedTool.from_function()` directly:

```python
from actiongate_langchain import GatedTool

tool = GatedTool.from_function(
    func=search_fn,
    name="search_web",
    description="Search the web",
    actiongate=ag,
    gate=Gate("tools", "search", "agent:1"),
    policy=Policy(max_calls=10, window=60),
)
```

## License

Apache-2.0. ActionGate and BudgetGate are Apache-2.0. RuleGate and AuditGate are BSL-1.1.
