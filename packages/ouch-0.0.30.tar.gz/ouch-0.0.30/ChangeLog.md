# 0.0.0
- First public release

# 0.0.2
- Fork `ouch` from `foc`.
- Add `probify`.

# 0.0.3
- bug fixes: `dmap`, `probify`, and `taskbar`.
- `dmap` supports symoblic merging and updates.

# 0.0.4
- Add `prompt` and `tmpfile`.
- Add `base58e` and `base58d`.
- Add `getext` and `stripext`.

# 0.0.5
- Fix `taskbar`, thread-safe and nested progress-bar without boilerplates.

# 0.0.6
- Add `read_conf` and `write_conf`.
- Rename `taskbar` to `tracker`.

# 0.0.7
- Hotfix for `read_conf`.

# 0.0.8
- Improve `timestamp`.
- Fix `timer`.
- Add `timeago` and `du_hs`.

# 0.0.9
- Fix `flatten`.

# 0.0.10
- Fix `tracker`.

# 0.0.11
- Add `tabulate` and `deepdict`.

# 0.0.12
- Fix a bug in `dmap`.
- Fix `neatly` and `tabulate`
- Rename `nprint` to `pp`

# 0.0.13
- Fix `probify`.

# 0.0.14
- Fix `rand`, `randn`, and `randint`.

# 0.0.15
- Fix `rand*`: follow the convention

# 0.0.16
- Fix `tracker`: `rich.Progress` no longer supports reusing existing tasks

# 0.0.17
- Add `dataq`
- Fix `flat` and `neatly`

# 0.0.19
- Hotfix: `dataq` and `neatly`

# 0.0.20
- Fix `tracker`: support Jupyter environment

# 0.0.21
- Bugfix in `timestamp`. Use `datetime.fromisoformat`.

# 0.0.22
- Fix `tracker`.

# 0.0.24
- Add `justf`. 

# 0.0.25
- Add `autocast`. 

# 0.0.26
- Update `reader` and `writier` to fully align with `open` and `zipfile`. 

# 0.0.27
- Add `CLI`, Unix style CLI builder.
- Add `red`, `green`, `yellow`, `blue`, `purple`, and `cyan` functions that wraps text in ANSI colors.

# 0.0.28
- Fix `CLI`: `add_solo_argument` method

# 0.0.29
- Fix `autocast` and `dataq`

# 0.0.30
- Fix `tabulate` and `jsutf`

