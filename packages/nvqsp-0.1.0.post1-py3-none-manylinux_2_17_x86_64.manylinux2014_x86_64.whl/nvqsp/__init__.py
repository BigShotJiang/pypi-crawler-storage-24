"""
nvQSP — GPU-accelerated RODAS4 stiff ODE solvers.

Submodules
----------
nvqsp.sparse
    Sparse RODAS4 solver for large QSP/PBPK models with sparse Jacobian
    structure (CSR format, BiCGSTAB linear solver).
nvqsp.options
    :class:`~nvqsp.options.SparseOptions` dataclass.

Quick start
-----------
::

    from nvqsp import sparse
    result = sparse.solve(A0=..., A1_csr=..., A2_csr=..., y0=..., times=...)
    # result.y: np.ndarray, shape (batch_size, n_times, neq)
"""

__version__ = "0.1.0.post1"

from . import sparse
from .options import SparseOptions

__all__ = [
    "sparse",
    "SparseOptions",
    "__version__",
]
