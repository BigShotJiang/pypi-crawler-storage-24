"""
High-level Python wrapper for the sparse RODAS4 GPU solver.

Example
-------
::

    import numpy as np
    from nvqsp import sparse
    from nvqsp.options import SparseOptions

    # Build CSR arrays for your model (or use scipy.sparse)
    A1_csr = (rowptr, col, val)        # val shape: (A1_nnz,) or (batch, A1_nnz)
    A2_csr = (rowptr, col1, col2, val) # val shape: (A2_nnz,) or (batch, A2_nnz)

    result = sparse.solve(
        A0=A0,           # (neq,) or (batch, neq)
        A1_csr=A1_csr,
        A2_csr=A2_csr,
        y0=y0,           # (neq,) or (batch, neq)
        times=times,     # (n_times,)
        doses=[(1.0, 100.0), (24.0, 100.0)],  # [(time, amount), ...]
        opts=SparseOptions(rtol=1e-6, atol=1e-9),
    )
    # result.y      : np.ndarray, shape (batch, n_times, neq)
    # result.steps  : int, total ODE steps across all patients
"""
from __future__ import annotations

import ctypes
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Sequence, Tuple, Union

import numpy as np

from .options import SparseOptions, _SparseRodas4OptionsCtypes, _sparse_opts_to_ctypes

# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------

@dataclass
class SolveResult:
    """Return value of :func:`solve`."""
    y: np.ndarray
    """Solution array, shape ``(batch_size, n_times, neq)``."""
    steps: int
    """Total ODE steps taken across all patients."""


# ---------------------------------------------------------------------------
# Library loading
# ---------------------------------------------------------------------------

def _find_lib() -> Path:
    """Locate libsparse_rodas4.so, checking package-bundled path first."""
    # 1. Bundled inside the wheel: nvqsp/lib/libsparse_rodas4.so
    pkg_lib = Path(__file__).parent / "lib" / "libsparse_rodas4.so"
    if pkg_lib.exists():
        return pkg_lib

    # 2. Environment variable override
    env = os.environ.get("QSP_ENGINE_LIB_SPARSE")
    if env:
        p = Path(env)
        if p.exists():
            return p
        raise FileNotFoundError(
            f"QSP_ENGINE_LIB_SPARSE={env!r} does not exist"
        )

    # 3. Standard system search path
    import ctypes.util
    found = ctypes.util.find_library("sparse_rodas4")
    if found:
        return Path(found)

    raise FileNotFoundError(
        "libsparse_rodas4.so not found. Either install the nvqsp wheel "
        "or set QSP_ENGINE_LIB_SPARSE to the path of the .so file."
    )


_lib_cache: Optional[ctypes.CDLL] = None


def _load_lib(lib_path: Optional[Union[str, Path]] = None) -> ctypes.CDLL:
    global _lib_cache
    if lib_path is not None:
        lib = ctypes.CDLL(str(lib_path))
        _setup_sig(lib)
        return lib
    if _lib_cache is None:
        _lib_cache = ctypes.CDLL(str(_find_lib()))
        _setup_sig(_lib_cache)
    return _lib_cache


def _setup_sig(lib: ctypes.CDLL) -> None:
    fn = lib.sparse_rodas4_solve
    fn.restype = None
    fn.argtypes = [
        ctypes.c_int,                          # batch_size
        ctypes.c_int,                          # neq
        ctypes.POINTER(ctypes.c_double),       # h_A0
        ctypes.c_int,                          # A1_nnz
        ctypes.POINTER(ctypes.c_int),          # h_A1_rowptr
        ctypes.POINTER(ctypes.c_int),          # h_A1_col
        ctypes.POINTER(ctypes.c_double),       # h_A1_val
        ctypes.c_int,                          # A2_nnz
        ctypes.POINTER(ctypes.c_int),          # h_A2_rowptr
        ctypes.POINTER(ctypes.c_int),          # h_A2_col1
        ctypes.POINTER(ctypes.c_int),          # h_A2_col2
        ctypes.POINTER(ctypes.c_double),       # h_A2_val
        ctypes.POINTER(ctypes.c_double),       # h_times
        ctypes.c_int,                          # n_times
        ctypes.POINTER(ctypes.c_double),       # h_y0
        ctypes.POINTER(ctypes.c_double),       # h_dose_times
        ctypes.POINTER(ctypes.c_double),       # h_dose_amounts
        ctypes.c_int,                          # n_doses
        ctypes.POINTER(_SparseRodas4OptionsCtypes),  # opts (NULL = defaults)
        ctypes.POINTER(ctypes.c_double),       # h_y_out
        ctypes.POINTER(ctypes.c_int),          # h_total_steps
    ]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _c_dptr(arr: np.ndarray) -> ctypes.POINTER(ctypes.c_double):
    return arr.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

def _c_iptr(arr: np.ndarray) -> ctypes.POINTER(ctypes.c_int):
    return arr.ctypes.data_as(ctypes.POINTER(ctypes.c_int))

def _require_f64(arr: np.ndarray, name: str) -> np.ndarray:
    return np.ascontiguousarray(arr, dtype=np.float64)

def _require_i32(arr: np.ndarray, name: str) -> np.ndarray:
    return np.ascontiguousarray(arr, dtype=np.int32)

def _tile_if_needed(val: np.ndarray, batch_size: int, nnz: int, name: str) -> np.ndarray:
    """
    Accept val as either:
      - 1-D (nnz,): shared across all patients → tile to (batch_size * nnz,)
      - 2-D (batch_size, nnz): per-patient → flatten to (batch_size * nnz,)
      - 1-D (batch_size * nnz,): already flat
    """
    val = _require_f64(val, name)
    if val.ndim == 1 and val.shape[0] == nnz:
        return np.tile(val, batch_size)
    if val.ndim == 2 and val.shape == (batch_size, nnz):
        return val.ravel()
    if val.ndim == 1 and val.shape[0] == batch_size * nnz:
        return val
    raise ValueError(
        f"{name}: expected shape ({nnz},), ({batch_size}, {nnz}), "
        f"or ({batch_size * nnz},); got {val.shape}"
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

CsrA1 = Tuple[np.ndarray, np.ndarray, np.ndarray]
"""``(rowptr, col, val)`` — val may be 1-D (shared) or 2-D (per-patient)."""

CsrA2 = Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]
"""``(rowptr, col1, col2, val)`` — val may be 1-D (shared) or 2-D (per-patient)."""


def solve(
    A0: np.ndarray,
    A1_csr: CsrA1,
    A2_csr: CsrA2,
    y0: np.ndarray,
    times: np.ndarray,
    doses: Optional[Sequence[Tuple[float, float]]] = None,
    opts: Optional[SparseOptions] = None,
    lib_path: Optional[Union[str, Path]] = None,
) -> SolveResult:
    """Solve a batch of stiff polynomial QSP ODEs on the GPU.

    Parameters
    ----------
    A0:
        Constant (zeroth-order) coefficient vector.  Shape ``(neq,)`` for a
        shared value across all patients, or ``(batch_size, neq)`` for
        per-patient values.
    A1_csr:
        First-order (linear) coefficient matrix in CSR format as the tuple
        ``(rowptr, col, val)``.  ``rowptr`` has shape ``(neq+1,)``;
        ``col`` has shape ``(A1_nnz,)``; ``val`` may be ``(A1_nnz,)`` for
        shared or ``(batch_size, A1_nnz)`` for per-patient.
    A2_csr:
        Second-order (bilinear) coefficient tensor in sparse format as the
        tuple ``(rowptr, col1, col2, val)``.  Same conventions as *A1_csr*
        except two column arrays.  **Must have at least one non-zero entry.**
    y0:
        Initial conditions.  Shape ``(neq,)`` for a single patient / shared
        initial condition, or ``(batch_size, neq)`` for per-patient.
    times:
        Output time points, shape ``(n_times,)``.  Must be strictly
        increasing and positive.
    doses:
        Optional dosing schedule as a sequence of ``(time, amount)`` pairs.
        Each dose adds *amount* to state index 0 at the given *time*.
        Doses at ``t ≈ 0`` (within 1e-8) are applied before integration
        starts; all others are applied mid-run (output at dose time is
        post-dose).
    opts:
        Solver options.  Pass ``None`` to use the library defaults.
    lib_path:
        Path to ``libsparse_rodas4.so``.  If ``None``, the bundled library
        is used (or the path from ``QSP_ENGINE_LIB_SPARSE``).

    Returns
    -------
    SolveResult
        ``.y``: ``np.ndarray`` of shape ``(batch_size, n_times, neq)``
        ``.steps``: total ODE steps taken across all patients
    """
    lib = _load_lib(lib_path)

    # ---- normalise A0 -------------------------------------------------------
    A0 = np.asarray(A0, dtype=np.float64)
    if A0.ndim == 1:
        neq = A0.shape[0]
        batch_from_A0 = None
    elif A0.ndim == 2:
        batch_from_A0, neq = A0.shape
    else:
        raise ValueError(f"A0 must be 1-D or 2-D, got shape {A0.shape}")

    # ---- normalise y0 -------------------------------------------------------
    y0 = np.asarray(y0, dtype=np.float64)
    if y0.ndim == 1:
        if y0.shape[0] != neq:
            raise ValueError(f"y0 length {y0.shape[0]} != neq {neq}")
        batch_from_y0 = None
    elif y0.ndim == 2:
        batch_from_y0, neq2 = y0.shape
        if neq2 != neq:
            raise ValueError(f"y0 shape {y0.shape}, expected (batch, {neq})")
    else:
        raise ValueError(f"y0 must be 1-D or 2-D, got shape {y0.shape}")

    # Resolve batch_size
    batches = [b for b in [batch_from_A0, batch_from_y0] if b is not None]
    if len(set(batches)) > 1:
        raise ValueError(f"Inconsistent batch sizes inferred from A0/y0: {batches}")
    batch_size = batches[0] if batches else 1

    # ---- CSR arrays ---------------------------------------------------------
    if len(A1_csr) != 3:
        raise ValueError("A1_csr must be (rowptr, col, val)")
    A1_rowptr, A1_col, A1_val = A1_csr
    A1_rowptr = _require_i32(A1_rowptr, "A1_rowptr")
    A1_col    = _require_i32(A1_col,    "A1_col")
    A1_nnz    = len(A1_col)
    A1_val    = _tile_if_needed(np.asarray(A1_val), batch_size, A1_nnz, "A1_val")

    if len(A2_csr) != 4:
        raise ValueError("A2_csr must be (rowptr, col1, col2, val)")
    A2_rowptr, A2_col1, A2_col2, A2_val = A2_csr
    A2_rowptr = _require_i32(A2_rowptr, "A2_rowptr")
    A2_col1   = _require_i32(A2_col1,   "A2_col1")
    A2_col2   = _require_i32(A2_col2,   "A2_col2")
    A2_nnz    = len(A2_col1)
    if A2_nnz == 0:
        raise ValueError(
            "A2_nnz must be > 0. For purely linear models, add a negligible "
            "epsilon entry: see TESTING.md §7 'API Constraints'."
        )
    A2_val = _tile_if_needed(np.asarray(A2_val), batch_size, A2_nnz, "A2_val")

    # ---- Tile A0 / y0 -------------------------------------------------------
    if A0.ndim == 1:
        A0_flat = np.tile(A0, batch_size)
    else:
        A0_flat = A0.ravel()
    A0_flat = _require_f64(A0_flat, "A0")

    if y0.ndim == 1:
        y0_flat = np.tile(y0, batch_size)
    else:
        y0_flat = y0.ravel()
    y0_flat = _require_f64(y0_flat, "y0")

    # ---- Times --------------------------------------------------------------
    times = _require_f64(np.asarray(times), "times")
    n_times = len(times)

    # ---- Doses --------------------------------------------------------------
    if doses:
        dose_times_arr   = _require_f64(np.array([d[0] for d in doses]), "dose_times")
        dose_amounts_arr = _require_f64(np.array([d[1] for d in doses]), "dose_amounts")
        n_doses = len(doses)
    else:
        dose_times_arr   = np.zeros(1, dtype=np.float64)
        dose_amounts_arr = np.zeros(1, dtype=np.float64)
        n_doses = 0

    # ---- Output buffer ------------------------------------------------------
    y_out = np.zeros(batch_size * n_times * neq, dtype=np.float64)
    total_steps = ctypes.c_int(0)

    # ---- Options ------------------------------------------------------------
    if opts is not None:
        c_opts = _sparse_opts_to_ctypes(opts)
        opts_ptr = ctypes.byref(c_opts)
    else:
        opts_ptr = None  # NULL → library uses its own defaults

    # ---- Call ---------------------------------------------------------------
    lib.sparse_rodas4_solve(
        batch_size, neq,
        _c_dptr(A0_flat),
        A1_nnz,
        _c_iptr(A1_rowptr), _c_iptr(A1_col), _c_dptr(A1_val),
        A2_nnz,
        _c_iptr(A2_rowptr), _c_iptr(A2_col1), _c_iptr(A2_col2), _c_dptr(A2_val),
        _c_dptr(times), n_times,
        _c_dptr(y0_flat),
        _c_dptr(dose_times_arr), _c_dptr(dose_amounts_arr), n_doses,
        opts_ptr,
        _c_dptr(y_out),
        ctypes.byref(total_steps),
    )

    return SolveResult(
        y=y_out.reshape(batch_size, n_times, neq),
        steps=total_steps.value,
    )
