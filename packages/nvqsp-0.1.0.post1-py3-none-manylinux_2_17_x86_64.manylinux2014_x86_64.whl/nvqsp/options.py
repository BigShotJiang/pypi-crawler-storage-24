"""
Solver options for nvQSP solvers.

Options are plain Python dataclasses.  They are converted to ctypes structs
internally when the solver is called — callers never need to touch ctypes
directly.
"""
from __future__ import annotations

import ctypes
from dataclasses import dataclass


# ---------------------------------------------------------------------------
# Sparse RODAS4 options
# ---------------------------------------------------------------------------

@dataclass
class SparseOptions:
    """Options for the sparse RODAS4 solver.

    All fields have the same meaning as :c:struct:`SparseRodas4Options` in
    ``sparse_rodas4_options.h``.  Pass ``None`` to :func:`nvqsp.sparse.solve`
    to use the library defaults (equivalent to passing ``NULL`` in C).
    """
    rtol: float = 1e-6
    """Relative ODE tolerance."""
    atol: float = 1e-12
    """Absolute ODE tolerance."""
    fac_min: float = 0.2
    """Minimum step-size factor."""
    fac_max: float = 10.0
    """Maximum step-size factor."""
    fac_safe: float = 0.9
    """Safety factor for step acceptance."""
    fac_rej: float = 0.1
    """Factor applied to step size after a rejected step."""
    max_steps: int = 20000
    """Maximum ODE steps per integration interval."""
    linsol_rtol: float = 1e-8
    """BiCGSTAB relative tolerance."""
    linsol_atol: float = 1e-12
    """BiCGSTAB absolute tolerance."""
    linsol_max_iters: int = 30
    """BiCGSTAB iteration limit."""


class _SparseRodas4OptionsCtypes(ctypes.Structure):
    """Internal ctypes mirror of ``SparseRodas4Options`` (80 bytes)."""
    _fields_ = [
        ("rtol",              ctypes.c_double),
        ("atol",              ctypes.c_double),
        ("facMin",            ctypes.c_double),
        ("facMax",            ctypes.c_double),
        ("facSafe",           ctypes.c_double),
        ("facRej",            ctypes.c_double),
        ("max_steps",         ctypes.c_int),
        ("_pad0",             ctypes.c_int),   # padding: aligns linsol_rtol to 8 bytes
        ("linsol_rtol",       ctypes.c_double),
        ("linsol_atol",       ctypes.c_double),
        ("linsol_max_iters",  ctypes.c_int),
        ("_pad1",             ctypes.c_int),   # padding: brings total to 80 bytes
    ]

assert ctypes.sizeof(_SparseRodas4OptionsCtypes) == 80, (
    f"SparseRodas4Options size mismatch: {ctypes.sizeof(_SparseRodas4OptionsCtypes)} != 80"
)


def _sparse_opts_to_ctypes(opts: SparseOptions) -> _SparseRodas4OptionsCtypes:
    s = _SparseRodas4OptionsCtypes()
    s.rtol             = opts.rtol
    s.atol             = opts.atol
    s.facMin           = opts.fac_min
    s.facMax           = opts.fac_max
    s.facSafe          = opts.fac_safe
    s.facRej           = opts.fac_rej
    s.max_steps        = opts.max_steps
    s.linsol_rtol      = opts.linsol_rtol
    s.linsol_atol      = opts.linsol_atol
    s.linsol_max_iters = opts.linsol_max_iters
    return s


