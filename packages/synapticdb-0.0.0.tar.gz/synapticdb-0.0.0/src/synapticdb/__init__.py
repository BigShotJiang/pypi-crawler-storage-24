"""Placeholder package for the SynapticDB rebrand."""

__all__ = ["__version__"]

__version__ = "0.0.0"
