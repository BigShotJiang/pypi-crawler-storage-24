# synapticdb

Placeholder package reserved for the SynapticDB rebrand.
