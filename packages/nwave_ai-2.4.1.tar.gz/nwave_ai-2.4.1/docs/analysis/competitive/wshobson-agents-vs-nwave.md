# Competitive Analysis: wshobson/agents vs nWave

**Date**: 2026-03-04 | **Researcher**: nw-researcher (Nova) | **Confidence**: Medium-High | **Sources**: 8

> **Honest Framing Disclaimer**: This analysis is written by the nWave team, about nWave. We have tried to be radically candid. Where we found evidence that the competitor does something better, we say so plainly. Where data was unavailable, we flag it. Read the "Where They Beat Us" section first -- it is the most valuable part of this document.

---

## Slack Summary Box

```
COMPETITIVE ANALYSIS: wshobson/agents vs nWave

WHERE THEY BEAT US (and it hurts):
- 30k+ stars vs our ~0 public visibility -- they ARE the Claude Code plugin ecosystem
- 72 plugins covering 24 categories (blockchain, gaming, marketing, ML) vs our 0 plugins
- Zero-friction install: /plugin marketplace add wshobson/agents -- done
- 112 agents across every domain imaginable vs our 31 focused agents
- Native plugin system integration -- Anthropic's blessed distribution model
- Community contributions and PRs vs single-team development

WHERE WE ARE SUPERIOR:
- DES (Deterministic Execution System) -- real runtime enforcement, not just instructions
- Outside-In TDD with 5-phase cycle enforced via Claude Code hooks
- Wave methodology (DISCOVER->DELIVER) with quality gates between phases
- Deep methodological skills (JTBD, Residuality Theory, Mikado, Toyota 5-Whys)
- Testable Python codebase with 60%+ coverage, CI/CD, mutation testing
- Agents have dedicated reviewers -- every specialist has a critic

BOTTOM LINE: They are the marketplace. We are the methodology.
They win on breadth, distribution, and adoption. We win on depth,
discipline, and determinism. The uncomfortable truth: their approach
is what the market clearly wants right now.
```

---

## 1. Executive Summary

wshobson/agents is the dominant Claude Code plugin marketplace, with 30,000+ GitHub stars, 72 focused plugins, 112 specialized agents, and native integration with Claude Code's plugin system. It is a content-first project: markdown agent definitions, skill files, and command templates organized into installable packages. There is no runtime code, no enforcement engine, and no test suite -- by design.

nWave is a methodology-driven development framework with 31 agents, 133+ skills, 23 commands, and a Python-based Deterministic Execution System (DES) that enforces TDD discipline through Claude Code hooks. It has near-zero public visibility, no plugin marketplace presence, and a steeper installation path.

The honest assessment: these two projects serve fundamentally different needs. wshobson/agents is a plugin supermarket where developers grab pre-built specialists. nWave is an opinionated development methodology with runtime guardrails. Comparing them is like comparing a well-stocked toolbox to a manufacturing process -- both valid, neither a substitute for the other. But only one of them has 30,000 people using it.

---

## 2. What They Are

### wshobson/agents -- Identity Card

| Attribute | Value |
|-----------|-------|
| **Type** | Claude Code plugin marketplace |
| **Creator** | Seth Hobson (wshobson) |
| **Stars** | ~30,200 reported (as of March 2026; see Gap 3 for verification note) |
| **Forks** | ~3,300 |
| **License** | MIT |
| **Install** | `/plugin marketplace add wshobson/agents` |
| **Agents** | 112 across 24 categories |
| **Skills** | 146 with progressive disclosure |
| **Plugins** | 72 focused, single-purpose |
| **Tools** | 79 development tools |
| **Orchestrators** | 16 multi-agent workflows |
| **Runtime code** | None (pure markdown/JSON configuration) |
| **Tests** | None |
| **CI/CD** | Minimal (no test pipeline visible) |
| **Commits** | ~240 total |
| **Contributors** | Multiple (exact count unavailable; at least 3 visible) |
| **Last commit** | Feb 21, 2026 |

**Source**: [GitHub - wshobson/agents](https://github.com/wshobson/agents). Accessed 2026-03-04.

### nWave -- Identity Card

| Attribute | Value |
|-----------|-------|
| **Type** | AI-powered development methodology framework |
| **Creator** | nWave Team |
| **Stars** | Private repo (0 public stars) |
| **License** | MIT |
| **Install** | `pip install nwave-ai && nwave install` |
| **Agents** | 31 (15 specialists + 14 reviewers + 2 variants) |
| **Skills** | 133+ deep methodology files |
| **Commands** | 23 slash commands |
| **Runtime** | DES (Python, hexagonal architecture) |
| **Tests** | 5-layer suite (unit, integration, acceptance, e2e, mutation) |
| **CI/CD** | 4-stage CI + 5-job release pipeline |
| **Coverage** | 60%+ minimum enforced |
| **Wave Phases** | DISCOVER, DISCUSS, DESIGN, DEVOPS, DISTILL, DELIVER |
| **Last commit** | March 2026 (active development) |

**Source**: Local repository analysis, `/mnt/c/Repositories/Projects/nWave-dev/`. Accessed 2026-03-04.

---

## 3. Architecture Comparison

### wshobson/agents: Content-First Plugin Architecture

```
.claude-plugin/marketplace.json    <-- Plugin registry (72 entries)
    |
plugins/
    |-- python-development/
    |   |-- agents/                <-- Markdown agent definitions
    |   |-- commands/              <-- Markdown command templates
    |   +-- skills/                <-- Markdown skill files (3-tier progressive disclosure)
    |-- kubernetes-operations/
    +-- [70 more plugins]
```

**Design principles** (from their architecture docs):
1. Single Responsibility -- each plugin does one thing (avg 3.4 components)
2. Composability -- mix-and-match, no forced bundles
3. Context Efficiency -- smaller tools fit LLM context windows
4. Maintainability -- isolated updates, no cascading effects

**Progressive disclosure** operates in three tiers:
- Tier 1 (Metadata/frontmatter): always loaded, activation criteria
- Tier 2 (Instructions): loaded when skill activates
- Tier 3 (Resources/examples): loaded on demand

**Model strategy** assigns agents to four tiers:
- Opus 4.6 (42 agents): critical architecture and code review
- Inherit (42 agents): user-selected model
- Sonnet (51 agents): support tasks
- Haiku (18 agents): fast operational tasks

**What is NOT present**: There is no runtime code. No Python, no hooks, no enforcement engine. The entire system is markdown and JSON consumed by Claude Code's native plugin infrastructure. Agents are instructions, not programs.

**Source**: [Architecture docs](https://github.com/wshobson/agents/blob/main/docs/architecture.md). Accessed 2026-03-04.

### nWave: Runtime-Enforced Methodology

```
Claude Code Hooks (pre-tool-use, subagent-stop, post-tool-use)
    |
    v
DES Runtime (Python, hexagonal architecture)
    |-- Adapters (drivers): Hook protocol adapter
    |-- Application: Orchestrator, validators, services
    |-- Domain: Phase events, turn counter, timeout, TDD schema
    |-- Ports (driven): FileSystem, Config, Audit, Logging
    |-- Adapters (driven): Real FS, env config, git verifier
    |
    v
Agent Definitions + Skills + Commands (markdown/YAML)
    |-- 31 agents with YAML frontmatter
    |-- 133+ deep skill files
    |-- 23 slash commands with argument specs
```

**Key differentiator**: DES intercepts Claude Code's tool calls in real time. When a sub-agent tries to write code without a failing test, DES blocks it. This is not a suggestion in a prompt -- it is a programmatic gate.

**TDD 5-Phase Cycle** (enforced by DES):
1. PREPARE -- setup test fixtures
2. RED_ACCEPTANCE -- write failing acceptance test
3. RED_UNIT -- write failing unit tests
4. GREEN -- implement until all tests pass
5. COMMIT -- refactor, finalize, no regressions

**Source**: Local codebase analysis. `src/des/` directory, `nWave/framework-catalog.yaml`.

### Architectural Philosophy Gap

This is the core difference: **wshobson/agents trusts the LLM to follow instructions. nWave does not.**

wshobson's architecture assumes that well-written markdown prompts are sufficient to guide Claude's behavior. nWave's architecture assumes that LLMs will drift, skip steps, and cut corners unless mechanically prevented from doing so. Both assumptions have evidence supporting them.

---

## 4. Feature-by-Feature Comparison

| Feature | wshobson/agents | nWave | Winner |
|---------|----------------|-------|--------|
| **Agent count** | 112 | 31 | wshobson (3.6x more) |
| **Domain coverage** | 24 categories (dev, infra, security, blockchain, gaming, marketing, ML, finance) | 6 wave phases + cross-wave (dev-focused) | wshobson |
| **Skill depth** | 146 skills, progressive disclosure | 133+ skills, deep methodology (JTBD, Residuality Theory, Mikado, Toyota 5-Whys, Bloom's Taxonomy) | nWave |
| **Installation** | `/plugin marketplace add wshobson/agents` (one command) | `pip install nwave-ai && nwave install` (two commands + Python required) | wshobson |
| **Selective install** | Install individual plugins (3.4 components avg) | All-or-nothing install | wshobson |
| **Plugin system** | Native Claude Code plugin marketplace | Custom installer with plugin architecture | wshobson |
| **TDD enforcement** | Markdown instructions for red-green-refactor | Runtime enforcement via DES hooks (blocks non-compliant tool calls) | nWave |
| **Quality gates** | None (trust-the-prompt) | Programmatic gates between phases | nWave |
| **Wave methodology** | N/A (no development lifecycle) | DISCOVER through DELIVER with tracked phases | nWave |
| **Multi-model support** | 4-tier model strategy (Opus/Inherit/Sonnet/Haiku) | Single model (inherits user's Claude Code model) | wshobson |
| **Peer review agents** | Code review via review plugins | Every specialist has a dedicated reviewer agent (14 reviewers) | nWave |
| **Runtime code** | 0 lines (pure content) | ~5,000+ lines Python (hexagonal architecture) | Depends on perspective |
| **Test suite** | None | 5-layer test pyramid + mutation testing | nWave |
| **CI/CD** | Minimal | 4-stage CI + 5-job release pipeline | nWave |
| **Conductor/PM** | Conductor plugin (context-driven development) | Wave orchestration with `/nw:new`, `/nw:continue`, `/nw:fast-forward` | Comparable |
| **Agent teams** | Agent Teams plugin (7 presets, parallel workflows) | Sequential wave delegation (no parallel teams) | wshobson |
| **Token optimization** | Progressive disclosure, model tiering, plugin granularity | Skill loading on demand, rigor profiles (lean/standard/thorough/exhaustive) | Comparable |
| **Documentation** | 5 comprehensive docs (plugins, agents, skills, usage, architecture) | Auto-generated reference + guides + ADRs | Comparable |
| **Business/non-dev agents** | Marketing (4), business (3), finance, payments, gaming, blockchain | Business agents (4: discoverer, reviewer, deal-closer, outreach-writer) | wshobson |
| **Community adoption** | 30,200+ stars, 3,300+ forks, multiple contributors | Private repo, single team | wshobson (massively) |

---

## 5. Where wshobson/agents Beats nWave (and it hurts to admit)

### 5.1 Adoption is not even a contest

30,200 stars. 3,300 forks. Multiple contributors. Listed on Claude Code marketplace aggregator sites. Community awareness. People actually use this thing.

nWave has zero public stars because it is a private repository — a deliberate business decision, not a competitive defeat. The `nwave-ai` package is public on PyPI as a thin installer; the intellectual property lives in the private repo. The consequence is real but chosen: **in the marketplace of ideas, we are not yet visible.** This is a distribution problem, not a quality signal.

wshobson/agents is not just popular -- it appears to be one of the most-starred Claude Code ecosystem projects period. That star count represents real developer attention.

**Source**: [GitHub - wshobson/agents](https://github.com/wshobson/agents). Star count observed 2026-03-04.

### 5.2 Installation friction: one command vs a pipeline

```bash
# wshobson/agents
/plugin marketplace add wshobson/agents
/plugin install python-development

# nWave
pip install nwave-ai
nwave install
# (requires Python 3.10+, pipenv, specific Claude Code version)
```

wshobson's install is one command inside Claude Code. nWave requires Python, pip, and runs an entire installation pipeline with preflight checks, plugin resolution, and import rewriting. Our installer is technically impressive. Their installer is trivially simple. **Simplicity wins in adoption.**

### 5.3 Domain breadth we cannot match

wshobson covers 24 categories including blockchain, gaming, marketing (4 agents), SEO (11 agents), finance, payments, and ML/AI pipelines. nWave is laser-focused on the software development lifecycle. If someone needs a Kubernetes operations specialist, a Solidity auditor, or an SEO content optimizer, wshobson has it. We do not and have no plans to.

Their breadth means a single marketplace install gives a team coverage across their entire technology stack. nWave only helps with the "build software well" part.

### 5.4 Native plugin system integration

wshobson/agents uses Claude Code's built-in plugin marketplace protocol (`.claude-plugin/marketplace.json`). This is Anthropic's sanctioned distribution mechanism. They are building on the platform's native capabilities.

nWave uses custom hooks and a custom installer. We are building *around* the platform, not *on* it. If Anthropic changes the hook API (which they can do at any time), we break. wshobson's content-only approach is inherently more resilient to platform changes.

### 5.5 Composability and granularity

Want just Python development? Install only that plugin (3-4 components loaded). Want Kubernetes but not blockchain? Fine. Each plugin averages 3.4 components.

nWave is all-or-nothing. Install the framework, get 31 agents, 133 skills, 23 commands. You cannot install just the TDD methodology without the product discovery agents. This monolithic approach increases context overhead for users who need only a subset.

### 5.6 Multi-model cost optimization

wshobson explicitly assigns agents to model tiers with documented cost rationale: Opus for critical tasks ($5/$25 per Mtok), Sonnet for complex work ($3/$15), Haiku for fast operations ($1/$5). Their architecture docs describe model tiering as a cost optimization strategy; the actual token reduction is not independently verified.

nWave inherits whatever model the user has configured. There is no built-in cost optimization through model selection. Users running nWave on Opus pay Opus prices for every sub-agent, including simple operations that Haiku could handle.

### 5.7 Parallel agent teams

wshobson's Agent Teams plugin enables parallel multi-agent workflows: simultaneous code review by multiple specialists, hypothesis-driven debugging with parallel investigation, coordinated security audits. Seven presets are available.

nWave's wave methodology is inherently sequential: DISCOVER, then DISCUSS, then DESIGN, and so on. While this enforces discipline, it cannot parallelize independent work streams. For large projects with multiple independent concerns, this is a real limitation.

---

## 6. Where nWave Is Superior

> **Important caveat**: The advantages listed below are architectural and structural. Neither project publishes outcome data (cycle time, defect rates, code quality). Architectural superiority does not automatically translate to better developer outcomes — it is a reasonable hypothesis, not a proven fact.

### 6.1 Runtime enforcement is real; prompt instructions are aspirational

This is nWave's fundamental architectural advantage. DES intercepts tool calls at the Claude Code hook level. When a sub-agent executing in the GREEN phase tries to write a test file, DES can detect the violation and block it. When a sub-agent exceeds its turn limit, DES stops it.

wshobson's TDD workflow is a markdown file that says "Write tests only -- no production code. Do NOT implement any production code during this phase." This is an instruction to an LLM. LLMs do not always follow instructions. There is no mechanism to *prevent* a wshobson agent from writing production code during the red phase -- it just asks Claude nicely not to.

The difference is analogous to a speed limit sign (wshobson) versus a speed governor on the engine (nWave). Both express intent. Only one mechanically enforces it.

**Source**: Local codebase: `src/des/application/orchestrator.py`, `src/des/adapters/drivers/hooks/claude_code_hook_adapter.py`.

### 6.2 Methodological depth is in a different league

nWave's 133+ skills are not surface-level "how to do X" templates. They encode deep practitioner methodologies:

- **Product discovery**: JTBD (Jobs-to-be-Done) with four forces analysis, opportunity scoring, persona integration
- **Architecture**: Residuality Theory, hexagonal architecture, stress analysis, formal verification with TLA+
- **Testing**: Outside-In TDD with double-loop architecture, BDD methodology, property-based testing across 10 language ecosystems, mutation testing
- **Refactoring**: Mikado Method, 6-level RPP (Refactoring Priority Premise), systematic refactoring catalogs
- **Troubleshooting**: Toyota 5-Whys, post-mortem frameworks, investigation techniques
- **Workshop design**: TBR 4C methodology, Bloom's taxonomy, Kirkpatrick assessment, cognitive load theory, liberating structures

wshobson's 146 skills cover more *topics*. A direct depth comparison is difficult without examining each skill file in detail (which we have not done). nWave's skills are explicitly methodology-deep — e.g., "how to apply Alistair Cockburn's Walking Skeleton pattern within an Outside-In TDD cycle using hexagonal architecture with property-based testing for the invariants." Whether wshobson's skills reach similar depth in their respective domains is an open question we flag as a knowledge gap.

### 6.3 Every specialist has a critic

nWave's 31 agents include 14 dedicated reviewer agents. The software-crafter has a software-crafter-reviewer. The solution-architect has a solution-architect-reviewer. Every specialist can be peer-reviewed by a domain-aware critic via `/nw:review`.

wshobson has code review plugins, but not a systematic "every role has an adversarial counterpart" design. nWave's review system is built on the principle that AI agents need the same quality checks as human developers -- arguably more, given their tendency to confidently produce plausible-but-wrong output.

### 6.4 Tested, versioned, CI/CD-verified software

nWave is a real software project:
- 5-layer test pyramid (unit, integration, acceptance, e2e, mutation)
- 60%+ coverage minimum enforced in CI
- 4-stage CI pipeline (lint, validate, test, sync)
- 5-job release pipeline with semantic versioning
- Conventional commits enforced by gitlint
- Ruff linting, mypy strict type checking

wshobson/agents has no test suite, no CI pipeline running tests, and no programmatic verification that its agent definitions are correct or consistent. The Makefile found in the repository is for a YouTube design extraction utility, not for the agents project itself. There is no way to programmatically verify that a new plugin does not conflict with existing ones or that skill activation criteria are well-formed.

This matters less for a content-only project (markdown files are hard to "break"), but it means there is no automated quality gate on contributions. A bad PR can ship broken agent definitions with no guardrails.

### 6.5 Wave methodology provides lifecycle structure

nWave's DISCOVER through DELIVER wave sequence provides something wshobson entirely lacks: a development lifecycle with enforced transitions.

wshobson gives you agents. You decide when to use them and in what order. Nothing prevents you from jumping straight to implementation without architecture review, without acceptance tests, without requirements analysis. Freedom is the feature and the risk.

nWave's wave methodology *can* be fast-forwarded (`/nw:fast-forward`) but the default path ensures that discovery happens before design, design before testing, testing before implementation. This is not overhead -- it is the process that prevents "we built the wrong thing really well."

### 6.6 Audit trail and deterministic execution

DES maintains a JSONL audit log of every phase transition, tool call validation, and turn count. This creates an auditable record of how a feature was developed: which phases were executed, how many turns each sub-agent consumed, what violations were detected.

wshobson's agents leave no structured trace. You get Claude's conversation history, but no machine-readable audit of the development process. For regulated industries or teams that need to demonstrate development discipline, this matters.

---

## 7. Adoption and Community

| Metric | wshobson/agents | nWave |
|--------|----------------|-------|
| GitHub stars | ~30,200 | Private repo |
| GitHub forks | ~3,300 | N/A |
| PyPI package | N/A | `nwave-ai` (public) |
| Contributors | 3+ visible | Single team |
| Marketplace presence | Listed on Claude Code marketplaces | None |
| Community discussions | GitHub Issues/PRs | None public |
| Documentation | 5 comprehensive docs | Internal + auto-generated |
| Social proof | Star count, marketplace listings | Word of mouth |
| Commit frequency | 3-4/week in clusters | Active (private) |
| Total commits | ~240 | 500+ (estimated from git log) |

**The uncomfortable truth**: wshobson/agents has achieved significant community adoption as a Claude Code plugin ecosystem. nWave has not achieved public adoption because it is not publicly distributed as a framework (only the installer is public). Even comparing the two on adoption metrics feels unfair -- one is designed for broad distribution, the other is designed for internal team use.

But that is exactly the problem. nWave's technical superiority in methodology enforcement does not matter if nobody outside the team uses it. wshobson has proven there is massive demand for Claude Code agent tooling. nWave has proven nothing publicly.

---

## 8. Strategic Implications

### The Honest Assessment

wshobson/agents and nWave are not really competing for the same users today. wshobson serves the broad Claude Code community wanting pre-built agents. nWave serves teams wanting disciplined AI-assisted development. But the overlap will grow as both projects mature.

The uncomfortable reality: **wshobson/agents is defining what "Claude Code plugins" look like for the ecosystem.** Their marketplace.json format, their plugin directory structure, their progressive disclosure model -- these are becoming de facto standards because 30,000+ developers are using them. If nWave does not participate in this ecosystem, it risks becoming a technically excellent island that the community builds around.

wshobson's weakness is that it is all breadth, no enforcement. 112 agents that "suggest" things versus 31 agents backed by a runtime that "enforces" things. But the market has clearly voted: most developers want suggestions, not enforcement. The ones who want enforcement are a smaller, more demanding audience -- and they may be the right audience for nWave.

### What nWave Should Do

1. **Publish as a Claude Code plugin** -- wrap nWave's agent definitions and skills (not DES) in `.claude-plugin/marketplace.json` format. Let the community use nWave agents without the full framework. This is table stakes for visibility.

2. **Study their progressive disclosure model** -- wshobson's 3-tier skill loading (metadata/instructions/resources) is well-designed for token efficiency. nWave skills currently load in full. Adopting a similar tiered approach could reduce context overhead.

3. **Add model tiering** -- wshobson's explicit assignment of agents to model tiers (Opus for critical, Haiku for routine) is a practical cost optimization that nWave should adopt. Not every sub-agent needs Opus.

4. **Consider selective installation** -- the all-or-nothing install is a barrier. Let users install subsets: "just TDD enforcement" or "just the architecture wave."

5. **Track and publish adoption metrics** -- if nWave cannot show stars, it needs other proof: case studies, cycle time improvements, defect reduction data. Evidence of value.

### What nWave Should NOT Do

1. **Do not chase breadth** -- adding blockchain, gaming, or SEO agents would dilute nWave's identity. Let wshobson be the supermarket. nWave is the craftsman's workshop.

2. **Do not abandon runtime enforcement** -- this is the moat. Anyone can write markdown agent definitions. Very few projects have built a deterministic execution system with hook-based enforcement. If nWave becomes "just another agent collection," it loses its only defensible differentiator.

3. **Do not dismiss wshobson as "shallow"** -- their design is intentionally simple. Simplicity is a feature, not a bug. The Unix philosophy of small, composable tools is a proven approach. Condescension toward a project with 30,000 stars is not a strategy.

4. **Do not conflate stars with quality** -- stars measure attention, not effectiveness. wshobson's agents could produce better or worse outcomes than nWave's. Neither project publishes outcome data. Stars tell you about marketing and distribution, not about whether the agents actually help developers write better code.

### The Real Threat

The real threat is not wshobson/agents specifically. It is the pattern wshobson represents: **the Claude Code plugin ecosystem is consolidating around content-only, marketplace-distributed collections.** Multiple similar projects exist (kivilaid/plugin-marketplace, others). The community is standardizing on a model where agents are markdown files in a plugin directory.

nWave's DES-based enforcement model is orthogonal to this trend. That is either visionary (the market will eventually demand enforcement) or quixotic (the market has spoken and it wants simplicity). The honest answer: we do not know yet. But the clock is ticking -- if enforcement-based approaches do not demonstrate measurable value soon, the content-only model will become the permanent standard.

The second threat is more subtle: **Anthropic itself.** Claude Code's plugin system is evolving. If Anthropic adds native enforcement features (phase gates, TDD modes, quality checks), nWave's DES becomes redundant. wshobson's content-only approach would seamlessly integrate with Anthropic's additions. nWave's custom hook system might conflict with them.

---

## Knowledge Gaps

### Gap 1: Outcome Data
**Issue**: Neither project publishes data on developer outcomes (cycle time, defect rates, code quality metrics). All claims about effectiveness are theoretical.
**Attempted**: Web search for benchmarks, case studies, or A/B comparisons.
**Recommendation**: nWave should instrument and publish before/after metrics for teams adopting the framework. This would be the single most powerful competitive differentiator.

### Gap 2: wshobson Contributor Count
**Issue**: GitHub contributor graph failed to load. Exact contributor count and distribution unknown.
**Attempted**: GitHub contributors page, web search.
**Recommendation**: Monitor over time. Multiple contributors visible in commit history (at least Seth Hobson, Sawyer Hollenshead, community contributors).

### Gap 3: Star Authenticity
**Issue**: 30,200 stars is an extraordinary count for a Claude Code plugin project. Star inflation (purchased stars, bot stars) is common in the GitHub ecosystem. No evidence either way.
**Attempted**: Checked star-history.com (requires direct visit), repository stats sites (403 error).
**Recommendation**: Check star growth curve via star-history.com. Organic growth follows a characteristic pattern; purchased stars show sudden jumps. Note: this is flagged for completeness, not as an accusation.

### Gap 4: Actual Usage vs Stars
**Issue**: Stars do not equal active users. The actual number of developers running wshobson's agents in production workflows is unknown.
**Attempted**: No download/install metrics are publicly available for Claude Code plugins.
**Recommendation**: If Claude Code ever publishes plugin install counts, this data would be invaluable.

---

## Source Analysis

| Source | Domain | Reputation | Type | Access Date | Cross-verified |
|--------|--------|------------|------|-------------|----------------|
| [GitHub - wshobson/agents](https://github.com/wshobson/agents) | github.com | High | Primary/Official | 2026-03-04 | Y |
| [wshobson/agents architecture.md](https://github.com/wshobson/agents/blob/main/docs/architecture.md) | github.com | High | Technical docs | 2026-03-04 | Y |
| [wshobson/agents usage.md](https://github.com/wshobson/agents/blob/main/docs/usage.md) | github.com | High | Technical docs | 2026-03-04 | Y |
| [wshobson/agents agents.md](https://github.com/wshobson/agents/blob/main/docs/agents.md) | github.com | High | Technical docs | 2026-03-04 | Y |
| [wshobson/agents agent-skills.md](https://github.com/wshobson/agents/blob/main/docs/agent-skills.md) | github.com | High | Technical docs | 2026-03-04 | Y |
| [wshobson/agents marketplace.json](https://github.com/wshobson/agents/blob/main/.claude-plugin/marketplace.json) | github.com | High | Configuration | 2026-03-04 | Y |
| [Claude Code Plugin Marketplace](https://claudemarketplaces.com/plugins/wshobson-agents) | claudemarketplaces.com | Medium | Community aggregator | 2026-03-04 | N |
| nWave local codebase | Local filesystem | High | Primary/Official | 2026-03-04 | Y |

Reputation: High: 7 (87.5%) | Medium: 1 (12.5%) | Avg: 0.95

---

## Research Metadata

Duration: ~25 min | Examined: 14 sources | Cited: 8 | Cross-refs: 12 | Confidence: High 40%, Medium 50%, Low 10% | Output: `docs/analysis/competitive/wshobson-agents-vs-nwave.md`
