# Effective Software Tutorials for CLI/Developer Tools: Evidence-Based Research

**Date**: 2026-02-17
**Author**: Nova (nw-researcher)
**Status**: Reviewed and approved by UX Designer

---

## 1. Tutorial Design Principles

### The "Time to Hello World" (TTFHW) is the defining metric

The single most important measure of a first tutorial's effectiveness is how quickly a user achieves their first meaningful success.

**Key findings:**

- Twilio explicitly targets enabling developers to "get up and running in 5 minutes or less" ([APIscene](https://www.apiscene.io/dx/time-to-hello-world-and-the-journey-to-developer-ltv/), [Nordic APIs](https://nordicapis.com/why-time-to-first-call-is-a-vital-api-metric/))
- Some API teams set a KPI of less than 30 minutes for a developer to get access and make their first successful call ([Nordic APIs](https://nordicapis.com/why-time-to-first-call-is-a-vital-api-metric/))
- .NET's "Hello World in 5 minutes" tutorial is explicitly designed around this benchmark ([Microsoft .NET](https://dotnet.microsoft.com/en-us/learn/dotnet/hello-world-tutorial/intro))
- Research shows that if users don't see value within their first 3 minutes, they are 80% more likely to abandon the platform ([daily.dev](https://business.daily.dev/resources/why-developers-never-finish-your-onboarding-and-how-to-fix-it/))

**Actionable principle:** Your first tutorial should deliver a visible, meaningful result in under 5 minutes. Under 3 minutes is the gold standard.

### Lessons from Stripe (industry benchmark)

1. **Outcome-focused, not feature-focused.** Documents what developers want to achieve, not what API endpoints exist. ([Moesif](https://www.moesif.com/blog/best-practices/api-product-management/the-stripe-developer-experience-and-docs-teardown/), [Apidog](https://apidog.com/blog/stripe-docs/))
2. **Personalized code samples.** Injects the user's own test API key into code examples so copy-paste actually works. ([Apidog](https://apidog.com/blog/stripe-docs/))
3. **Three-column layout.** Navigation left, explanation center, live code right. ([Apidog](https://apidog.com/blog/stripe-docs/))
4. **Interactive highlighting.** Hovering over explanation text highlights the corresponding code line. ([Apidog](https://apidog.com/blog/stripe-docs/))
5. **"A feature is not shipped until its docs are written."** Doc contributions count toward performance reviews. ([Apidog](https://apidog.com/blog/stripe-docs/))

### Appropriate scope for a first tutorial

- **One concept, one outcome.** The first tutorial should teach exactly one thing and produce one visible result.
- **5 minutes maximum.** Anything longer belongs in a follow-up tutorial.
- **Zero configuration prerequisite.** If setup takes longer than the tutorial, you have failed.

---

## 2. Time-to-First-Success Research

### The critical window

| Timeframe | Evidence | Source |
|-----------|----------|--------|
| 3 minutes | Users who don't see value in 3 min are 80% more likely to abandon | [daily.dev](https://business.daily.dev/resources/why-developers-never-finish-your-onboarding-and-how-to-fix-it/) |
| 5 minutes | Twilio's explicit TTFHW target; .NET's tutorial benchmark | [APIscene](https://www.apiscene.io/dx/time-to-hello-world-and-the-journey-to-developer-ltv/), [Microsoft](https://dotnet.microsoft.com/en-us/learn/dotnet/hello-world-tutorial/intro) |
| 30 minutes | Upper bound KPI for some API teams (signup to first call) | [Nordic APIs](https://nordicapis.com/why-time-to-first-call-is-a-vital-api-metric/) |

### Measurement advice

Use percentile distributions (p25, p50, p75, p99) to understand where developers actually struggle. In one example, average was 24 minutes but median was 3 minutes. ([APIscene](https://www.apiscene.io/dx/time-to-hello-world-and-the-journey-to-developer-ltv/))

### The three critical moments

1. **Signup** — Intent. Developer arrives.
2. **Access** — Credentials, code, and docs are provisioned.
3. **Hello World** — First successful result.

The gap between Access and Hello World is where most abandonment occurs.

---

## 3. Progressive Complexity

### The principle of progressive disclosure

Nielsen Norman Group defines progressive disclosure as "sequencing information and actions across several screens to reduce feelings of overwhelm." ([NN/g](https://www.nngroup.com/articles/progressive-disclosure/))

### Recommended tutorial sequence for CLI tools

**Level 1: Quick Start (under 5 minutes)**
- Install the tool (one command)
- Run one command that produces visible output
- Done. User has proof the tool works.

**Level 2: First Real Task (15-30 minutes)**
- Solve a real (small) problem end-to-end
- Introduce 3-5 core commands
- End with a tangible artifact the user keeps

**Level 3: Workflow Tutorial (30-60 minutes)**
- Combine multiple commands into a realistic workflow
- Introduce configuration and customization
- Cover the "daily driver" use case

**Level 4: Advanced/Reference**
- Edge cases, advanced flags, scripting integration
- Reference format is appropriate here

Each level should be completable independently.

---

## 4. Common Anti-Patterns

### Anti-Pattern 1: The "Wall of Prerequisites"
Installing 5 dependencies before typing your first command. Every prerequisite step is a dropout point. ([clig.dev](https://clig.dev/), [daily.dev](https://business.daily.dev/resources/why-developers-never-finish-your-onboarding-and-how-to-fix-it/))

### Anti-Pattern 2: Explaining before demonstrating
Long conceptual introductions before any hands-on steps. Developers learn by doing. ([Moesif](https://www.moesif.com/blog/best-practices/api-product-management/the-stripe-developer-experience-and-docs-teardown/))

### Anti-Pattern 3: Unclear progress / no milestones
Tutorials without checkpoints where the user can verify they are on track. ([Lucas F. Costa](https://www.lucasfcosta.com/blog/ux-patterns-cli-tools))

### Anti-Pattern 4: Assuming context the reader lacks
Using jargon, referencing concepts not yet introduced. ([clig.dev](https://clig.dev/))

### Anti-Pattern 5: Tutorials that rot
Code examples that don't work with the current version. ([Apidog](https://apidog.com/blog/stripe-docs/))

### Anti-Pattern 6: One giant tutorial instead of a sequence
Trying to cover everything in a single document. ([NN/g](https://www.nngroup.com/articles/progressive-disclosure/))

### Anti-Pattern 7: No copy-pasteable commands
Forcing the user to adapt example commands without clear guidance. ([Apidog](https://apidog.com/blog/stripe-docs/))

---

## 5. CLI-Specific Guidance

From [Command Line Interface Guidelines](https://clig.dev/) and [Lucas F. Costa's CLI UX patterns](https://www.lucasfcosta.com/blog/ux-patterns-cli-tools):

- **The help screen IS your getting-started guide.** `--help` must include examples, not just flag descriptions.
- **Lead with examples in help text.** Show "here is what you probably want to type" before listing all flags.
- **Print output within 100ms.** If your first command hangs with no output, users assume it is broken. Show progress indicators for anything taking more than a few seconds.
- **Interactive mode for onboarding.** Guide new users step-by-step with prompts.
- **Errors are teaching moments.** When a user makes a mistake, the error message should tell them what to do next.
- **Context-awareness.** Detect configuration and adapt rather than requiring manual setup.
- **Predictable command hierarchy.** Users should be able to guess the next command based on patterns.

---

## 6. The 10 Actionable Principles

| # | Principle | Evidence Strength |
|---|-----------|-------------------|
| 1 | First tutorial must produce a visible result in under 5 minutes | High (Twilio, .NET, Stripe, daily.dev) |
| 2 | Lead with working examples, explain after | High (Stripe, Moesif, clig.dev) |
| 3 | Every command must be copy-pasteable and work | High (Stripe, Apidog) |
| 4 | Break tutorials into progressive levels, each self-contained | High (NN/g, Django, Stripe) |
| 5 | Show expected output after every significant step | Medium (CLI UX research, clig.dev) |
| 6 | Minimize prerequisites to one install command | High (Stripe, clig.dev, daily.dev) |
| 7 | Make `--help` output useful as standalone getting-started guide | High (clig.dev, Lucas F. Costa) |
| 8 | Treat errors as teaching moments with actionable messages | High (clig.dev, Lucas F. Costa) |
| 9 | Test tutorials in CI — broken tutorials are worse than none | Medium (Stripe culture) |
| 10 | Measure TTFHW with percentiles, not averages | Medium (APIscene) |

---

## Sources

- [APIscene - Time to Hello World and Developer LTV](https://www.apiscene.io/dx/time-to-hello-world-and-the-journey-to-developer-ltv/)
- [Nordic APIs - Why Time to First Call Is a Vital API Metric](https://nordicapis.com/why-time-to-first-call-is-a-vital-api-metric/)
- [Moesif - Stripe Developer Experience Teardown](https://www.moesif.com/blog/best-practices/api-product-management/the-stripe-developer-experience-and-docs-teardown/)
- [Apidog - Why Stripe's API Docs Are the Benchmark](https://apidog.com/blog/stripe-docs/)
- [Technical Writer HQ - 12 Tips from Stripe's Documentation](https://technicalwriterhq.co/12-tips-you-can-learn-from-stripes-documentation-portal-8da41b37f85e)
- [clig.dev - Command Line Interface Guidelines](https://clig.dev/)
- [Lucas F. Costa - UX Patterns for CLI Tools](https://www.lucasfcosta.com/blog/ux-patterns-cli-tools)
- [NN/g - Progressive Disclosure](https://www.nngroup.com/articles/progressive-disclosure/)
- [IxDF - Progressive Disclosure](https://www.interaction-design.org/literature/topics/progressive-disclosure)
- [daily.dev - Why Developers Never Finish Your Onboarding](https://business.daily.dev/resources/why-developers-never-finish-your-onboarding-and-how-to-fix-it/)
- [Microsoft .NET - Hello World in 5 Minutes](https://dotnet.microsoft.com/en-us/learn/dotnet/hello-world-tutorial/intro)
- [Full Scale - Developer Onboarding Best Practices](https://fullscale.io/blog/developer-onboarding-best-practices/)

## Knowledge Gaps

- Developer tutorial completion rate data is proprietary (held by freeCodeCamp, Codecademy) and not publicly published
- Django tutorial design rationale not publicly documented
- The 3-minute and 5-minute benchmarks come from practitioner reports, not peer-reviewed academic research
