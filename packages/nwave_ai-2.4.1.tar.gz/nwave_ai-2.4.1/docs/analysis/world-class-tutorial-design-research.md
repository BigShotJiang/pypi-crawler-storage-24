# World-Class Software Tutorial Design: Evidence-Based Principles

**Date**: 2026-02-17
**Author**: Nova (nw-researcher)
**Status**: Complete
**Sources**: 35+ across academic, industry-leader, and technical documentation tiers
**Confidence**: High (most principles backed by 3+ independent sources)

---

## Executive Summary: Top 10 Actionable Principles (Ranked by Impact)

| Rank | Principle | Impact | Evidence Strength |
|------|-----------|--------|-------------------|
| 1 | **First visible result in under 5 minutes** | Critical | High (Twilio, Stripe, .NET, daily.dev, Moesif, Axway) |
| 2 | **Code first, explain after** | Critical | High (Twilio 30% completion lift, Stripe, Moesif) |
| 3 | **Copy-paste must work without modification** | Critical | High (Stripe personalized keys, Twilio tested snippets) |
| 4 | **Progressive disclosure: simple path needs zero config** | High | High (NN/g, IxDF, Apple, Google Codelabs) |
| 5 | **Show expected output at every checkpoint** | High | Medium-High (Twilio, clig.dev, Google Codelabs) |
| 6 | **Fewer words = higher completion** | High | High (Twilio 12% lift from less text, 30% lift from <20 lines) |
| 7 | **One concept, one outcome per tutorial unit** | High | High (Sweller CLT, Google Codelabs, Apple Swift Playgrounds) |
| 8 | **Errors are teaching moments, not dead ends** | Medium-High | High (clig.dev, NN/g AI onboarding, Lucas F. Costa) |
| 9 | **Scaffold within the Zone of Proximal Development** | Medium-High | High (Vygotsky/ZPD, Apple Playgrounds, Rustlings) |
| 10 | **Test tutorials as code; broken tutorials are worse than none** | Medium | Medium (Stripe culture, Twilio code-in-repo practice) |

---

## 1. Cognitive Science of Learning

### 1.1 Cognitive Load Theory (Sweller)

Cognitive Load Theory (CLT), introduced by John Sweller in 1988, establishes that working memory can hold only a small amount of information at any time. Instructional methods must avoid overloading it. CLT identifies three types of cognitive load:

- **Intrinsic load**: Complexity inherent to the material (irreducible)
- **Extraneous load**: Caused by poor instructional design (reducible -- this is the target)
- **Germane load**: Effort spent building mental schemas (desirable)

**Application to tutorials**: Every unnecessary concept, configuration step, or unexplained term adds extraneous load. The research principle "Reduce concepts: if a tutorial requires learning 5 things, find a way to make it 2" is a direct application of minimizing extraneous load.

**Sources**: [Sweller, 2011 (PDF)](https://www.emrahakman.com/wp-content/uploads/2024/10/Cognitive-Load-Sweller-2011.pdf) | [Sweller, Ayres & Kalyuga, 2011 - Springer](https://link.springer.com/article/10.1023/A:1022193728205) | [MDPI Educational Sciences, 2025](https://www.mdpi.com/2227-7102/15/4/458)

**Confidence**: High (peer-reviewed, foundational theory with decades of replication)

### 1.2 Worked Example Effect

Learners who study worked examples (step-by-step demonstrations) outperform those given equivalent problems to solve. This is one of the most replicated findings in instructional design.

**Application to tutorials**: Show the complete working code first, then explain it. Do not ask users to figure out code from descriptions. A 2024 study confirmed that CLT-based instructional materials using worked examples showed positive impact in programming education specifically.

**Sources**: [JISE 2024](https://jise.org/Volume35/n3/JISE2024v35n3pp303-312.pdf) | [Scott H. Young - CLT Applications](https://www.scotthyoung.com/blog/2022/01/04/cognitive-load-theory/) | [Sweller, 2011](https://www.emrahakman.com/wp-content/uploads/2024/10/Cognitive-Load-Sweller-2011.pdf)

**Confidence**: High (peer-reviewed, replicated in programming domain)

### 1.3 Split-Attention Effect

When learners must mentally integrate two or more sources of information presented separately (e.g., code on one screen, explanation on another; a diagram with labels in a separate legend), cognitive load increases dramatically.

**Application to tutorials**:
- Place explanations inline with the code they describe, not in a separate paragraph above or below
- Stripe's three-column layout with interactive highlighting (hover explanation = highlight code line) directly addresses this
- Never separate "what to type" from "what it means" by more than a glance

**Sources**: [Kalyuga, 2007 (PDF)](https://www.uky.edu/~gmswan3/EDC608/Kalyuga2007_Article_ExpertiseReversalEffectAndItsI.pdf) | [Sweller, 2011](https://www.emrahakman.com/wp-content/uploads/2024/10/Cognitive-Load-Sweller-2011.pdf) | [Apidog - Stripe Docs Analysis](https://apidog.com/blog/stripe-docs/)

**Confidence**: High

### 1.4 Expertise Reversal Effect

Instructional techniques that help novices become counterproductive for experts. Worked examples help beginners but slow down experienced programmers who already have relevant schemas. Detailed step-by-step guidance becomes "redundancy" that experts must mentally filter out.

**Application to tutorials**:
- Provide multiple tutorial tracks (beginner vs experienced)
- Use progressive disclosure to hide detailed explanations behind expandable sections
- The Rust Book + Rustlings model works: detailed explanation (Book) + exercise-only mode (Rustlings) serves both audiences

**Sources**: [Kalyuga, 2007 - Springer](https://link.springer.com/article/10.1007/s10648-007-9054-3) | [Kalyuga et al., 2003](https://www.tandfonline.com/doi/abs/10.1207/S15326985EP3801_4) | [Wikipedia - Expertise Reversal Effect](https://en.wikipedia.org/wiki/Expertise_reversal_effect)

**Confidence**: High (peer-reviewed, replicated across domains including programming)

### 1.5 Zone of Proximal Development (ZPD)

Vygotsky's ZPD defines the space between what a learner can do alone and what they can do with support. Effective instruction targets this zone -- tasks that are challenging enough to require guidance but not so difficult they cause frustration.

**Application to tutorials**:
- Each tutorial step should be just beyond current ability, with scaffolding provided
- Video games demonstrate this masterfully: starting within a narrow ZPD band that expands as skills grow
- Scaffolding should be gradually removed ("fading") as the user gains competence

**Sources**: [Simply Psychology - ZPD](https://www.simplypsychology.org/zone-of-proximal-development.html) | [eLearning Industry - ZPD Guide](https://elearningindustry.com/guide-to-vygotskys-zone-of-proximal-development-and-scaffolding) | [NWEA, 2025](https://www.nwea.org/blog/2025/7-ways-to-use-zpd-and-scaffolding-to-challenge-and-support-students/)

**Confidence**: High (foundational learning theory, widely applied)

---

## 2. Comparative Analysis: Best-in-Class Tutorial Systems

### 2.1 Comparative Table

| System | TTFHW | Progressive Levels | Interactive | Copy-Paste Works | Expected Output | Error Recovery | Expertise Tracks |
|--------|-------|-------------------|-------------|-------------------|-----------------|----------------|-----------------|
| **Apple Swift Playgrounds** | ~2 min | Yes (puzzle progression) | Yes (live preview) | N/A (visual) | Yes (instant) | Hints system | No (beginner-focused) |
| **Apple SwiftUI Tutorials** | ~15 min | Yes (4-part series) | Yes (Xcode live preview) | Yes | Yes (screenshots) | Partial | No |
| **Google Codelabs** | ~5-10 min | Yes (structured paths) | Partial (editor links) | Yes | Yes (screenshots) | Partial | Yes (skill levels) |
| **Stripe Docs** | ~5 min | Yes (quickstart -> guides -> API ref) | Yes (live code, test keys) | Yes (personalized keys) | Yes (API responses) | Yes (troubleshooting) | Yes (language/platform) |
| **Next.js Learn** | ~10 min | Yes (16 chapters) | Yes (in-browser) | Yes | Yes | Partial | No |
| **Rust Book + Rustlings** | ~15 min (Book), ~2 min (Rustlings) | Yes (21 chapters) | Rustlings: Yes | Yes | Yes (compiler output) | Yes (compiler errors) | Yes (Book vs Rustlings) |
| **Tour of Go** | ~3 min | Yes (4 sections) | Yes (in-browser editor) | Yes | Yes (immediate) | Partial | No |
| **Rails Getting Started** | ~15 min | Yes (scaffold -> detail) | No | Yes | Yes (screenshots) | Partial | No |
| **Django Tutorial** | ~30 min (Part 1) | Yes (7 parts) | No | Yes | Yes (screenshots) | Partial | No |

### 2.2 What the Best Share (Pattern Analysis)

**Universal patterns across top-tier tutorials (Stripe, Apple Playgrounds, Tour of Go, Google Codelabs)**:

1. **Immediate feedback loops**: Every action produces visible output within seconds. Apple Playgrounds shows results instantly. Tour of Go executes in-browser. Stripe shows API responses inline.

2. **Working code before explanation**: Stripe shows the integration code first, explains after. Google Codelabs give you the project first, then walk through it. This aligns with the worked example effect.

3. **Clear scope contract**: Each tutorial states upfront what you will build, how long it takes, and what you need to know. Google Codelabs has explicit "What you'll learn" and "What you'll need" sections.

4. **Checkpoint verification**: After each significant step, the user can verify they are on track. Stripe shows expected API responses. Apple shows expected UI states. Google Codelabs show expected screenshots.

5. **Escapable depth**: Simple path requires no configuration. Advanced options are available but not required. Stripe's quickstart works with test keys (zero config). Apple Playgrounds has hints (but you don't have to use them).

### 2.3 What Mediocre Tutorials Lack

- **No clear "done" signal**: User finishes steps but doesn't know if they succeeded
- **Explanation-heavy, action-light**: Paragraphs of theory before any code
- **Monolithic structure**: One 45-minute tutorial instead of 5 progressive modules
- **Platform-specific assumptions**: "Open your terminal" without specifying which OS
- **No expected output**: User types commands into a void

### 2.4 Deep Dives

#### Apple: Swift Playgrounds
- Teaches through puzzles with characters (Byte, Blu, Hopper) achieving goals via code
- Progressive: simple instructions -> loops -> functions -> advanced algorithms
- Instant visual feedback; code results appear as you type
- Reached #1 free education app in ~100 countries at launch
- Designed for ages 8+; proves that even complex languages can be taught progressively

**Sources**: [Apple Developer - Swift Playground](https://developer.apple.com/swift-playground/) | [Wikipedia - Swift Playgrounds](https://en.wikipedia.org/wiki/Swift_Playgrounds) | [Common Sense Education Review](https://www.commonsense.org/education/reviews/swift-playgrounds)

#### Stripe: API Documentation
- Three-column layout: navigation / explanation / live code
- Personalized code samples with user's test API key injected
- Hovering over explanation highlights corresponding code line (solves split-attention)
- "A feature is not shipped until its docs are written" -- documentation is part of the definition of done
- Performs structured UX research: records developers integrating to find friction points
- Outcome-focused: "Here's how to accept your first payment" not "Here's the Charge endpoint"

**Sources**: [Moesif - Stripe Teardown](https://www.moesif.com/blog/best-practices/api-product-management/the-stripe-developer-experience-and-docs-teardown/) | [Apidog - Stripe Docs](https://apidog.com/blog/stripe-docs/) | [Stripe Engineering Blog](https://stripe.com/blog/payment-api-design)

#### Google Codelabs
- Structured progression: each codelab builds on previous knowledge
- Focused and concise: designed for short sessions, not marathon learning
- Immediate feedback during coding helps identify and correct errors
- Multiple skill level paths (beginner to advanced)
- Tailored paths accommodate diverse skill levels

**Sources**: [Google Codelabs](https://codelabs.developers.google.com/) | [Android Developer Codelabs](https://developer.android.com/get-started/codelabs)

#### Rust Book + Rustlings
- Dual-track approach addresses expertise reversal effect directly
- The Book: comprehensive worked examples with explanation (novice-friendly)
- Rustlings: exercise-only mode where you fix broken code (expert-friendly)
- Compiler errors serve as the teaching mechanism in Rustlings (errors as teaching moments)
- Community-maintained, open source, continuously tested

**Sources**: [Tour of Rust](https://tourofrust.com/) | [GitHub - Rust Books](https://github.com/sger/RustBooks)

#### Tour of Go
- In-browser interactive editor: zero install, zero config
- Four sections with exercises concluding each section
- TTFHW of approximately 3 minutes (type code, press Run, see output)
- Multilingual support

**Sources**: [Tour of Go](https://go.dev/tour/) | [Go Learn Page](https://go.dev/learn/)

---

## 3. Tutorial UX/Design Patterns

### 3.1 Progressive Disclosure in Technical Content

Progressive disclosure defers advanced features to secondary screens, reducing cognitive load. Jakob Nielsen introduced this pattern in 1995; it remains one of the most validated UX patterns.

**Key rules for tutorials**:
- Show only primary options by default; hide advanced options behind expandable sections
- Maximum 2 levels of disclosure; beyond that, users get lost (NN/g finding)
- Tutorial equivalent: "Quick Start" is Level 1; "Configuration Guide" is Level 2; "API Reference" is Level 3
- Each level must be independently completable

**Sources**: [NN/g - Progressive Disclosure](https://www.nngroup.com/articles/progressive-disclosure/) | [IxDF - Progressive Disclosure](https://www.interaction-design.org/literature/topics/progressive-disclosure) | [The Decision Lab - Progressive Disclosure](https://thedecisionlab.com/reference-guide/design/progressive-disclosure)

**Confidence**: High (3+ independent sources, 30+ years of validation)

### 3.2 Time to First Hello World (TTFHW)

TTFHW is the single most important metric for developer platforms. Research and practitioner consensus:

| Benchmark | Target | Source |
|-----------|--------|--------|
| Gold standard | < 3 minutes | [daily.dev](https://business.daily.dev/resources/why-developers-never-finish-your-onboarding-and-how-to-fix-it/) |
| Industry target | < 5 minutes | [Twilio](https://www.apiscene.io/dx/time-to-hello-world-and-the-journey-to-developer-ltv/), [.NET](https://dotnet.microsoft.com/en-us/learn/dotnet/hello-world-tutorial/intro) |
| Acceptable upper bound | < 30 minutes (signup to first call) | [Nordic APIs](https://nordicapis.com/why-time-to-first-call-is-a-vital-api-metric/) |
| Abandonment risk | Users who don't see value in 3 min are 80% more likely to abandon | [daily.dev](https://business.daily.dev/resources/why-developers-never-finish-your-onboarding-and-how-to-fix-it/) |

**Critical insight**: Measure with percentiles, not averages. One study found average TTFHW was 24 minutes but median was 3 minutes -- the average was distorted by outliers stuck on configuration issues.

**Sources**: [Moesif - What is TTFHW](https://www.moesif.com/blog/technical/api-product-management/What-is-TTFHW/) | [APIscene](https://www.apiscene.io/dx/time-to-hello-world-and-the-journey-to-developer-ltv/) | [Nordic APIs](https://nordicapis.com/why-time-to-first-call-is-a-vital-api-metric/) | [Axway - TTFHW](https://blog.axway.com/learning-center/apis/enterprise-api-strategy/api-program-time-first-hello-world)

**Confidence**: High (6+ independent sources)

### 3.3 Signposting: Where Am I? What's Next?

Effective tutorials provide constant orientation:
- **Progress indicator**: "Step 3 of 7" or a progress bar
- **Time estimate**: "This section takes ~5 minutes"
- **"What you'll build" preview**: Show the end result at the start
- **Checkpoint markers**: "At this point, you should see..."
- **Next step preview**: "In the next section, you'll add..."

Google Codelabs uses explicit "What you'll learn" headers. Apple tutorials show the finished app upfront. Stripe shows the completed integration flow before diving into code.

### 3.4 Error Recovery

When users get stuck or diverge from the tutorial path, the tutorial must provide escape hatches:

- **"If you see this error..."** blocks after risky steps
- **Checkpoint files**: Downloadable project state at each major step (Google Codelabs does this)
- **Troubleshooting sections**: Not at the end -- inline, where errors occur
- **Reset instructions**: "If things went wrong, start fresh with: `git checkout step-3`"

### 3.5 The "Copy-Paste Must Work" Principle

Every code snippet in a tutorial must execute without modification. Implications:

- Use actual values, not placeholders like `YOUR_API_KEY_HERE` (Stripe injects real test keys)
- Test every snippet in CI (Twilio stores code examples in a separate repo and tests them)
- Specify the exact file where code should be placed
- Show the complete file context, not just the changed lines (or use clear diff notation)

**Sources**: [Apidog - Stripe Docs](https://apidog.com/blog/stripe-docs/) | [Pronovix - Twilio](https://pronovix.com/blog/5-things-learn-twilios-documentation-overhaul) | [Moesif - Stripe Teardown](https://www.moesif.com/blog/best-practices/api-product-management/the-stripe-developer-experience-and-docs-teardown/)

**Confidence**: High

### 3.6 Visual Hierarchy in Tutorial Pages

Optimal layout pattern (derived from Stripe and Google Codelabs analysis):

```
[Navigation sidebar] | [Main content area]           | [Code/output panel]
                     |                                |
                     | 1. Brief prose (2-3 sentences) | Corresponding code block
                     | 2. Expected output callout     | Terminal output
                     | 3. Explanation (collapsible)   | Annotated code
                     | 4. Next step link              |
```

**Key rules**:
- Code blocks are visually dominant (larger font, contrasting background)
- Prose is concise connective tissue between code blocks
- Expected output uses a distinct visual treatment (different background color, labeled)
- Explanations are secondary (collapsible or in a separate column)

---

## 4. Anti-Pattern Catalog

### Anti-Pattern 1: Wall of Text Before Action

**The problem**: Three paragraphs of conceptual explanation before any executable step. Developers learn by doing; they skim prose to find the first command.

**Evidence**: Twilio found tutorial completion increased 12% simply by reducing explanatory text. Developers bypass documentation to search Google/StackOverflow when prose is too long.

**Before**:
> Welcome to the FooBar SDK! FooBar is a revolutionary new approach to widget management that leverages quantum-inspired algorithms to optimize your workflow. In this tutorial, we'll explore the core concepts behind FooBar, including the Widget Lifecycle, the Observer Pattern implementation, and the Configuration Manager. Before we begin, it's important to understand that FooBar uses a declarative paradigm...
>
> [300 more words]
>
> Now let's install FooBar:
> ```
> pip install foobar
> ```

**After**:
> ```
> pip install foobar
> foobar init my-project
> cd my-project && foobar run
> ```
> You should see: `Server running on localhost:3000`
>
> **What just happened?** FooBar created a project with sensible defaults and started a local server. [Expand to learn more]

**Sources**: [Pronovix - Twilio](https://pronovix.com/blog/5-things-learn-twilios-documentation-overhaul) | [Moesif - Stripe](https://www.moesif.com/blog/best-practices/api-product-management/the-stripe-developer-experience-and-docs-teardown/)

### Anti-Pattern 2: Unexplained Magic ("Copy This, Trust Me")

**The problem**: Instructions say "add this configuration" without explaining why or what it does. Users copy-paste but have no mental model, so they cannot debug when things go wrong.

**Before**:
> Add this to your `config.yaml`:
> ```yaml
> runtime:
>   gc_interval: 250
>   pool_size: 8
>   max_retries: 3
>   backoff_multiplier: 1.5
> ```

**After**:
> Add this to your `config.yaml`:
> ```yaml
> runtime:
>   pool_size: 8  # Number of parallel workers (default: 4, increase for faster processing)
> ```
> We only need `pool_size` for now. The defaults handle everything else.
> [See all configuration options ->]

### Anti-Pattern 3: Configuration Hell Before Value

**The problem**: 15 minutes of setup (install 3 dependencies, create an account, configure environment variables, set up a database) before the user sees any output.

**Evidence**: daily.dev research shows 80% abandonment risk if value isn't visible in 3 minutes. Every prerequisite step is a dropout point.

**Fix**: Ship sensible defaults. Use SQLite instead of requiring PostgreSQL for the tutorial. Use test/demo credentials. Defer real configuration to a later tutorial.

**Sources**: [daily.dev](https://business.daily.dev/resources/why-developers-never-finish-your-onboarding-and-how-to-fix-it/) | [clig.dev](https://clig.dev/)

### Anti-Pattern 4: Assumed Knowledge Not Stated

**The problem**: Tutorial uses terms like "middleware", "schema migration", or "environment variable" without checking whether the reader knows them.

**Fix**: State prerequisites explicitly at the top: "This tutorial assumes you know: X, Y. If not, see [link]." Use a glossary tooltip for domain-specific terms.

**Sources**: [clig.dev](https://clig.dev/) | [NN/g - AI Onboarding](https://www.nngroup.com/articles/new-AI-users-onboarding/)

### Anti-Pattern 5: Stale Screenshots / Outdated Commands

**The problem**: Screenshots show a UI that changed 2 versions ago. Commands reference deprecated flags. The tutorial silently fails.

**Fix**: Test tutorials in CI. Store code examples in a separate, tested repository (Twilio's approach). Version-tag tutorials to match software versions.

**Sources**: [Pronovix - Twilio](https://pronovix.com/blog/5-things-learn-twilios-documentation-overhaul) | [Apidog - Stripe](https://apidog.com/blog/stripe-docs/)

### Anti-Pattern 6: No Escape Hatches

**The problem**: User encounters an error not covered by the tutorial. There is no troubleshooting section, no checkpoint to reset to, no way to skip the broken step.

**Fix**: After every risky step, add an "If something went wrong" callout. Provide checkpoint files/branches. Include a "Get help" link to community/support.

### Anti-Pattern 7: Only Works on Author's Machine

**The problem**: Tutorial was written on macOS with Homebrew, Python 3.12, and a specific shell. It fails silently on Windows, Linux, or different Python versions.

**Fix**: Test on all supported platforms. Use containerized/reproducible environments (Docker, devcontainers). State exact version requirements. Provide OS-specific tabs for commands that differ.

---

## 5. AI-Assisted Workflow Tutorials (Specific Recommendations)

### 5.1 The Non-Determinism Challenge

AI-powered tools produce different output on every run. This fundamentally breaks the traditional tutorial model where expected output is deterministic and verifiable.

**Key insight from Anthropic**: "Tools represent a fundamentally new software paradigm: contracts between deterministic systems and non-deterministic agents." The tutorial must prepare users for variability, not hide it.

**Sources**: [Anthropic - Writing Tools for Agents](https://www.anthropic.com/engineering/writing-tools-for-agents) | [BayTech - Non-Deterministic AI in Production](https://www.baytechconsulting.com/blog/non-deterministic-ai-in-production-2025)

### 5.2 Setting Expectations for Async/Long-Running Processes

Traditional CLI: command -> output in 2 seconds -> done.
AI agent CLI: command -> silence for 20-60 seconds -> streaming output -> approval -> next step.

Users interpret silence as failure. NN/g research confirms this for AI tools: "Participants felt confused when these tools assumed users knew how they worked."

**Recommendations**:
1. **State timing upfront**: "This step takes 30-60 seconds. You'll see progress output like..."
2. **Show a realistic example of streaming output**: Not the exact output (it varies), but the shape/format
3. **Provide a "Is it stuck?" diagnostic**: "If you see no output after 90 seconds, check..."
4. **Use progress indicators**: Any long-running step must emit feedback within 5 seconds

**Sources**: [NN/g - New AI Users Onboarding](https://www.nngroup.com/articles/new-AI-users-onboarding/) | [Anthropic - Writing Tools for Agents](https://www.anthropic.com/engineering/writing-tools-for-agents)

### 5.3 Teaching Users to Read Agent Output

Users don't control AI agent output. They must learn to:
- Distinguish informational output from action-required output
- Identify completion signals
- Recognize error states vs. normal processing pauses

**Recommendations**:
1. **Annotate example output**: Show a realistic output block with callout annotations ("This means...", "Wait for this before proceeding...")
2. **Teach the output grammar**: "Output starting with `[PHASE]` indicates a new step. `[APPROVE]` means the agent needs your input."
3. **Provide a visual legend** of output markers

### 5.4 Progressive Trust-Building with AI Tools

NN/g research shows users need to build trust incrementally:

1. **Micro-success first**: Give users a trivially small task where the AI succeeds visibly in under 2 minutes
2. **Transparent operation**: Show what the AI is doing ("Analyzing your request... Generating test... Running test...")
3. **Verify together**: After each AI action, show the user how to verify the result independently
4. **Gradually increase scope**: Micro-task -> small feature -> full workflow
5. **Acknowledge variability**: "Your output may differ slightly from this example. The important parts are: [list specific things to verify]"

**Sources**: [NN/g - New AI Users Onboarding](https://www.nngroup.com/articles/new-AI-users-onboarding/) | [NN/g - AI Literacy](https://www.nngroup.com/articles/ai-literacy/) | [McKinsey - Building AI Trust](https://www.mckinsey.com/capabilities/quantumblack/our-insights/building-ai-trust-the-key-role-of-explainability)

**Confidence**: Medium-High (NN/g research is rigorous but AI-specific tutorial research is still emerging)

### 5.5 Handling "It Worked Differently for Me"

This is the defining challenge of AI-workflow tutorials. Strategies:

1. **Define success by outcome, not exact output**: "Success means you have a file called `X` with a function that does `Y`" -- not "You should see exactly this code"
2. **Provide verification commands**: `test`, `lint`, `run` commands that validate the outcome regardless of the exact code generated
3. **Show 2-3 example variations**: "Your output might look like Example A or Example B. Both are correct because..."
4. **Include a "What if mine looks different?" FAQ** addressing common divergences

### 5.6 Interpretation (Analysis)

*[Note: This section contains the researcher's interpretation, not directly sourced claims.]*

AI-workflow tutorials require a paradigm shift from "follow these exact steps to get this exact result" to "follow this process to achieve this outcome, verifying at these checkpoints." The tutorial becomes less like a recipe and more like a cooking class where the instructor says "your sauce should be thick enough to coat a spoon" rather than "stir exactly 47 times."

This is harder to write and harder for users to follow, which makes the other principles (progressive disclosure, checkpoint verification, error recovery) even more critical for AI-workflow tutorials than for traditional ones.

---

## 6. Measurement Framework

### 6.1 Key Metrics

| Metric | Definition | Target | Source |
|--------|-----------|--------|--------|
| **TTFHW** | Time from first command to first visible success | < 5 min (< 3 min gold standard) | Twilio, Moesif, daily.dev |
| **Completion rate** | % of users who finish the tutorial | > 60% (> 70% excellent) | Chameleon 2025 Benchmark |
| **Step drop-off** | Which step loses the most users | Identify and fix top 3 | Twilio measurement practice |
| **First-step completion** | % completing Step 1 | > 80% | Twilio ("developers are more likely to finish if they succeed in step 1") |
| **Time-to-value (TTV)** | Time from signup to first real use | < 7 days | Agile Growth Labs 2025 |
| **Activation rate** | % reaching key product milestones | 30-50% | Chameleon 2025 Benchmark |

### 6.2 Benchmark Data

**Onboarding completion rates** (2025 industry benchmarks):
- Average: 19.2% (median: 10.1%) -- most onboarding is failing
- Good: 40-60%
- Excellent: 70-80%
- Best industry (FinTech): 24.5%
- Worst industry (MarTech): 12.5%
- Tours > 5 steps: completion nosedives (lose 50%+ of users)

**Impact of completion**:
- Users who complete onboarding are 80% more likely to become long-term customers
- Completers show 3x higher lifetime value
- Completers are 5x more likely to remain after 90 days

**Sources**: [Chameleon 2025 Benchmark Report](https://www.chameleon.io/benchmark-report) | [Userpilot - Onboarding Benchmarks](https://userpilot.com/blog/onboarding-checklist-completion-rate-benchmarks/) | [Agile Growth Labs 2025](https://www.agilegrowthlabs.com/blog/user-activation-rate-benchmarks-2025/)

**Confidence**: Medium-High (SaaS benchmarks, not developer-tutorial-specific; see Knowledge Gaps)

### 6.3 How Top Companies Measure

**Twilio**:
- Uses Optimizely for A/B testing tutorial formats
- Uses MixPanel and Google Analytics for funnel metrics
- Uses UserTesting for video interviews watching developers attempt tutorials
- Key finding: 62% improvement in first-message activation and 33% improvement in production launches within 7 days after onboarding redesign
- Key finding: 30% higher completion when first code example is < 20 lines

**Stripe**:
- Records developers attempting integrations to find friction points
- Documentation is part of the product development process (not an afterthought)
- Uses structured UX research with real developers

**Sources**: [Pronovix - Twilio](https://pronovix.com/blog/5-things-learn-twilios-documentation-overhaul) | [Twilio Blog - Onboarding Redesign](https://www.twilio.com/en-us/blog/developers/redesigning-twilio-onboarding-experience-whats-new) | [Moesif - Stripe](https://www.moesif.com/blog/best-practices/api-product-management/the-stripe-developer-experience-and-docs-teardown/)

### 6.4 What to Measure in a Tutorial Funnel

```
Tutorial Funnel:
                                    Measure:
  Page visit                        -> Unique visitors
  Start tutorial (first action)     -> Start rate (vs visitors)
  Complete Step 1                   -> First-step completion rate  [CRITICAL]
  Complete Step N (each step)       -> Step-by-step drop-off
  Complete tutorial                 -> Completion rate
  Next action (start another        -> Continuation rate
    tutorial, use product)
  Return within 7 days              -> Retention / activation

Per-step measurements:
  - Time spent on step
  - Error/retry rate on step
  - "Get help" clicks on step
  - Copy-paste events (are users engaging with code?)
```

### 6.5 A/B Testing Recommendations

Based on Twilio's documented practices:

1. **Test content length**: Shorter vs longer explanations (Twilio saw 12% lift from shorter)
2. **Test code-first vs explanation-first**: Which produces higher completion?
3. **Test number of steps**: Fewer, larger steps vs more, smaller steps
4. **Test interactive vs static**: In-browser execution vs copy-paste-to-terminal
5. **Test with real developers**: Video interviews watching first-time users attempt tutorials

---

## 7. Knowledge Gaps

These are areas searched but where insufficient evidence was found:

| Gap | What Was Searched | Why Insufficient |
|-----|-------------------|------------------|
| **Developer tutorial completion rates** (not SaaS onboarding) | Tutorial completion benchmarks, developer education metrics | Proprietary data held by freeCodeCamp, Codecademy, Pluralsight. Not publicly published. SaaS onboarding benchmarks are proxies, not exact. |
| **Django/Rails tutorial design rationale** | Django tutorial design pedagogy, Rails getting started guide analysis | No public documentation of the pedagogical reasoning behind these tutorials' structure. |
| **Academic research on AI-workflow tutorials** | AI tool tutorial design, non-deterministic output teaching | Field is too new (2023-2025). NN/g has initial findings but no large-scale studies yet. Most evidence is practitioner reports. |
| **Controlled experiments: tutorial format A/B tests** | A/B testing tutorial formats research controlled study | Twilio and Stripe report results but don't publish full experimental designs. No peer-reviewed controlled experiments on developer tutorial formats found. |
| **Mobile-friendly tutorial design for developers** | Developer documentation mobile design responsive code tutorials | Virtually no research specific to developer tutorials on mobile. The assumption appears to be that developers use desktops. |
| **Rust Book/Rustlings pedagogical analysis** | Rust Book pedagogy worked example effectiveness | No formal pedagogical analysis of the Rust Book's design decisions published. Community praise is abundant but anecdotal. |

---

## Sources (Complete List)

### Academic / High Reputation
- [Sweller, J. (2011). Cognitive Load Theory (PDF)](https://www.emrahakman.com/wp-content/uploads/2024/10/Cognitive-Load-Sweller-2011.pdf)
- [Sweller, J., Ayres, P., Kalyuga, S. - Cognitive Architecture and Instructional Design](https://link.springer.com/article/10.1023/A:1022193728205)
- [Kalyuga, S. (2007). Expertise Reversal Effect](https://link.springer.com/article/10.1007/s10648-007-9054-3)
- [Kalyuga, S. et al. (2003). The Expertise Reversal Effect](https://www.tandfonline.com/doi/abs/10.1207/S15326985EP3801_4)
- [JISE (2024). Self-Explanation Effect of CLT in Programming](https://jise.org/Volume35/n3/JISE2024v35n3pp303-312.pdf)
- [MDPI Educational Sciences (2025). CLT Emerging Trends](https://www.mdpi.com/2227-7102/15/4/458)
- [Vygotsky ZPD - Simply Psychology](https://www.simplypsychology.org/zone-of-proximal-development.html)

### Industry Leaders / High Reputation
- [NN/g - Progressive Disclosure](https://www.nngroup.com/articles/progressive-disclosure/)
- [NN/g - New Users Need Support with Gen-AI Tools](https://www.nngroup.com/articles/new-AI-users-onboarding/)
- [NN/g - AI Literacy Shapes GenAI Use](https://www.nngroup.com/articles/ai-literacy/)
- [IxDF - Progressive Disclosure](https://www.interaction-design.org/literature/topics/progressive-disclosure)
- [Anthropic - Writing Effective Tools for AI Agents](https://www.anthropic.com/engineering/writing-tools-for-agents)
- [McKinsey - Building AI Trust](https://www.mckinsey.com/capabilities/quantumblack/our-insights/building-ai-trust-the-key-role-of-explainability)

### Technical Documentation / Official Sources
- [Apple Developer - Swift Playground](https://developer.apple.com/swift-playground/)
- [Apple Developer - SwiftUI Tutorials](https://developer.apple.com/tutorials/swiftui)
- [Google Codelabs](https://codelabs.developers.google.com/)
- [Android Developer Codelabs](https://developer.android.com/get-started/codelabs)
- [Tour of Go](https://go.dev/tour/)
- [Next.js Learn](https://nextjs.org/learn)
- [Stripe API Tour](https://docs.stripe.com/payments-api/tour)
- [clig.dev - Command Line Interface Guidelines](https://clig.dev/)

### Developer Experience / Industry Analysis
- [Moesif - Stripe Developer Experience Teardown](https://www.moesif.com/blog/best-practices/api-product-management/the-stripe-developer-experience-and-docs-teardown/)
- [Moesif - What is TTFHW](https://www.moesif.com/blog/technical/api-product-management/What-is-TTFHW/)
- [Apidog - Why Stripe's API Docs Are the Benchmark](https://apidog.com/blog/stripe-docs/)
- [Pronovix - 5 Things to Learn from Twilio's Documentation Overhaul](https://pronovix.com/blog/5-things-learn-twilios-documentation-overhaul)
- [Twilio Blog - Redesigning Onboarding Experience](https://www.twilio.com/en-us/blog/developers/redesigning-twilio-onboarding-experience-whats-new)
- [APIscene - Time to Hello World and Developer LTV](https://www.apiscene.io/dx/time-to-hello-world-and-the-journey-to-developer-ltv/)
- [Nordic APIs - Why TTFC Is a Vital Metric](https://nordicapis.com/why-time-to-first-call-is-a-vital-api-metric/)
- [Axway - API Program TTFHW](https://blog.axway.com/learning-center/apis/enterprise-api-strategy/api-program-time-first-hello-world)
- [daily.dev - Why Developers Never Finish Your Onboarding](https://business.daily.dev/resources/why-developers-never-finish-your-onboarding-and-how-to-fix-it/)
- [Lucas F. Costa - UX Patterns for CLI Tools](https://www.lucasfcosta.com/blog/ux-patterns-cli-tools)
- [Stripe Engineering - Payments APIs: First 10 Years](https://stripe.com/blog/payment-api-design)
- [Scott H. Young - Cognitive Load Theory Applications](https://www.scotthyoung.com/blog/2022/01/04/cognitive-load-theory/)

### Benchmark Reports
- [Chameleon - User Onboarding Benchmark Report 2025](https://www.chameleon.io/benchmark-report)
- [Userpilot - Onboarding Checklist Completion Rate Benchmarks 2025](https://userpilot.com/blog/onboarding-checklist-completion-rate-benchmarks/)
- [Agile Growth Labs - User Activation Rate Benchmarks 2025](https://www.agilegrowthlabs.com/blog/user-activation-rate-benchmarks-2025/)
- [Postman - Top 25 API Onboarding Experiences](https://blog.postman.com/top-25-api-onboarding-experiences/)
- [Sendbird - Evaluating Developer Onboarding UX](https://sendbird.com/blog/evaluating-developers-onboarding-experience-ux-benchmarking-study)

### Other
- [Wikipedia - Swift Playgrounds](https://en.wikipedia.org/wiki/Swift_Playgrounds)
- [Wikipedia - Expertise Reversal Effect](https://en.wikipedia.org/wiki/Expertise_reversal_effect)
- [eLearning Industry - ZPD and Scaffolding Guide](https://elearningindustry.com/guide-to-vygotskys-zone-of-proximal-development-and-scaffolding)
- [BayTech Consulting - Non-Deterministic AI in Production](https://www.baytechconsulting.com/blog/non-deterministic-ai-in-production-2025)
- [Common Sense Education - Swift Playgrounds Review](https://www.commonsense.org/education/reviews/swift-playgrounds)
