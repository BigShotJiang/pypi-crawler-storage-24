# BriX Service Offer -- Hybrid Margin-Safe Pricing

**Alessandro Di Gioia | Michele Brissoni | Marco Consolaro**

---

## Pricing Model

Every price is derived from a **Hybrid Margin-Safe Formula** that guarantees positive margins while pricing on value delivered.

```
Price = max(Cost x Multiplier, Cost + ValueCapture% x ClientValue)
```

| Engagement Type | Formula | Min Margin | When |
|----------------|---------|------------|------|
| Diagnostics | Cost x 1.5 | 33% | Low-risk entry points |
| Capability Building | max(Cost x 1.4, Cost + 3% x Value) | 29% | Workshops, coaching, residencies |
| Enterprise Transformation | max(Cost x 1.4, Cost + 2% x Value) + Success Fee | 29% | Long-term, org-wide |

**Cost basis**: EUR 1,200/person/day fully loaded [VALIDATE: confirm against last 6 engagements including CH travel/hotel]
**ROI target**: 5-6x (sweet spot for client acceptance, source: Consulting Success)
**Success Fee**: 15% of base price, payable only if agreed KPIs hit within 6 months

---

## Course 1: Antipasti -- Organizational Alignment

*Diagnostics formula: Cost x 1.5 | Fixed 33% margin*

| # | Service | Person-Days | Cost | Price | Client Value | ROI |
|---|---------|-------------|------|-------|-------------|-----|
| 1.1 | **The Mirror** -- AI-Readiness Assessment | 4 gg (1p, 2 sett) | 4,800 | **7,200** | 50K+ | ~7x |
| 1.2 | **The X-Ray** -- Engineering Practices Audit | 10 gg (2p, 3 sett) | 12,000 | **18,000** | 100K+ | ~6x |
| 1.3 | **The Campfire** -- Leadership Alignment Workshop | 6 gg (2p, 1 sett+prep) | 7,200 | **10,800** | 75K+ | ~7x |
| 1.4 | **The Compass** -- Product Mindset Diagnostic | 4 gg (1p, 2 sett) | 4,800 | **7,200** | 48K+ | ~7x |

**Value justification (Course 1)**:
- Mirror: Enterprise with 200+ devs making wrong AI adoption decision wastes EUR 500K+ in misallocated budget (source: typical enterprise AI initiative). Conservative 10% of avoided waste = EUR 50K.
- X-Ray: Undetected bottleneck in CI/CD costs ~4h/dev/week across 50 devs = EUR 100K+/year in lost productivity.
- Campfire: Misaligned leadership delays cross-team initiatives by 3-6 months. Value of 3 months acceleration for 10-team org = EUR 75K+.
- Compass: Feature factory building wrong things at EUR 200K+/quarter. Redirecting even 25% of effort = EUR 48K+/quarter.

---

## Course 2: Primi -- Capability and Use Case Build

*Capability formula: max(Cost x 1.4, Cost + 3% x Value) | 29%+ margin | + optional Success Fee*

| # | Service | Person-Days | Cost | Price | Formula Winner | Client Value | ROI |
|---|---------|-------------|------|-------|---------------|-------------|-----|
| 2.1 | **The Dojo** -- TDD Intensive | 8 gg (2p, 3 giorni + 8 sett follow-up) | 9,600 | **13,700** | Value (13,710) | 137K | ~10x |
| 2.2 | **The Forge** -- AI-Augmented Dev | 6 gg (2p, 2 giorni + 4 sett follow-up) | 7,200 | **10,080** | Tie | 96K | ~10x |
| 2.3a | **The Residency** -- Embedded Coaching (2wk) | 10 gg (1p full-time) | 12,000 | **16,800** | Floor (16,800) | 120K | ~7x |
| 2.3b | **The Residency** -- Embedded Coaching (4wk) | 20 gg (1p full-time) | 24,000 | **33,600** | Floor (33,600) | 250K | ~7x |
| 2.4 | **The Greenhouse** -- Product Thinking | 2 gg (1p, 1 giorno + prep) | 2,400 | **3,840** | Value (3,840) | 48K | ~13x |

**Value justification (Course 2)**:
- Dojo: 8-person team reducing defect rate 30% = ~EUR 137K/year saved (fewer production incidents, less rework). Source: DORA metrics, industry benchmarks.
- Forge: Same team gaining 15% throughput via AI-augmented workflow = ~EUR 96K/year (0.15 x 8 devs x EUR 80K loaded cost).
- Residency 2wk: Practice adoption on real codebase. Conservative: 10% efficiency gain across 8-person team sustained = EUR 120K/year.
- Residency 4wk: Deeper adoption, compounding behavior change. 15% sustained gain + reduced onboarding cost for new practices = EUR 250K/year.
- Greenhouse: Redirecting 25% of team effort from wrong features to validated outcomes = EUR 48K+/quarter.

**Success Fee KPIs (Course 2, optional)**:
- Dojo: defect rate reduction >= 30%
- Forge: developer throughput increase >= 15%

---

## Course 3: Secondi -- AI-Native Enterprise Wiring

*Enterprise formula: max(Cost x 1.4, Cost + 2% x Value) + Success Fee | 29%+ margin*

| # | Service | Person-Days | Cost | Price | Formula Winner | Success Fee | Client Value | ROI |
|---|---------|-------------|------|-------|---------------|-------------|-------------|-----|
| 3.1 | **The Academy** -- Internal Training Program | ~30 gg (2p, 3-4 mesi, 40% alloc) [VALIDATE] | 36,000 | **50,400** | Floor | 7,560 | 400K+ | ~8x |
| 3.2 | **The Catalyst** -- AI Transformation Office | ~40 gg (1-2p, 6 mesi) [VALIDATE] | 48,000 | **67,200** | Floor | 10,080 | 600K+ | ~9x |
| 3.3 | **The Wiring** -- nWave Enterprise Deployment | ~25 gg (1-2p, 2-3 mesi) | 30,000 | **42,000** | Floor | 6,300 | 200K+ | ~5x |

**Value justification (Course 3)**:
- Academy: Replacing external training for 200+ devs. 3-track program delivered internally saves EUR 400K+/year vs. recurring consultant engagements. Source: internal training ROI benchmarks (ATD).
- Catalyst: AI Transformation Office coordinating adoption across 20+ teams. Avoiding duplicated tooling/effort across teams = EUR 600K+/year. Source: McKinsey AI adoption studies.
- Wiring: nWave deployment across 10+ teams. Each team saves ~EUR 20K/year in workflow standardization, reduced review cycles, enforced quality gates = EUR 200K+/year.

**Success Fee KPIs (Course 3)**:
- Academy: internal trainers certified + 2 cohorts delivered
- Catalyst: 3 AI use cases in production within 6 months
- Wiring: 3+ teams onboarded with >60% adoption

---

## A La Carte

| Service | Price | Notes |
|---------|-------|-------|
| Conference Keynote (45-60 min) | 3,600 | 1 person |
| Half-day Workshop | 6,000 | 1 person |
| Full-day Workshop | 9,600 | 1 person |
| Monthly Advisory Retainer | 3,600/month | Min 3 months, 2x 90min + async |
| AI-Readiness Portal (self-serve) | 1,200 | Automated, up to 20 respondents |

---

## CSS Chef's Recommendation (18 months)

| Phase | Timeline | Services | Investment |
|-------|----------|----------|------------|
| **1: See Clearly** | Months 1-3 | Mirror + Campfire + Compass | **25,200** |
| **2: Build Proof** | Months 4-8 | 2x Dojo + 2x Forge + Residency 4wk | **81,160** |
| **3: Wire It In** | Months 9-18 | Academy + Catalyst + Wiring + Advisory 12mo | **202,800** |
| | | **Base Total** | **309,160** |
| | | + Success Fees (if KPIs hit) | up to 23,940 |
| | | **Maximum Total** | **333,100** |

**Phase 2 breakdown**: 2x Dojo (27,400) + 2x Forge (20,160) + Residency 4wk (33,600) = 81,160

**Anchoring**: Present Phase 3 first (EUR 202,800). Phase 1 at EUR 25,200 becomes an obvious low-risk entry point.

---

## Comparison: Old vs New Pricing

| Metric | Old (Value-Based 10-20%) | New (Hybrid Margin-Safe) |
|--------|--------------------------|--------------------------|
| CSS 18-month total | EUR 202,800 - 277,200 | EUR 309,160 (+12-52%) |
| Services with negative margins | 6 of 12 (at low price) | **0** |
| Minimum margin guarantee | None (some below cost) | **29%** on every service |
| Success fee component | None | Up to EUR 23,940 |
| Client ROI range | Varies widely | **~5x - ~13x** (all above 3x threshold) |

The hybrid model increases total revenue while guaranteeing healthy margins on every single service. The success fee component reduces client risk perception and aligns incentives -- a trend validated by major consulting firms moving to performance-based pricing (McKinsey, Bain, 2025).

---

## Assumptions to Validate

| # | Assumption | Risk if Wrong | How to Validate |
|---|-----------|---------------|-----------------|
| 1 | Cost basis EUR 1,200/day is accurate for CH market | Margins shrink if actual cost is higher | Review last 6 engagement P&Ls |
| 2 | Person-day estimates match actual delivery effort | Under-scoping or over-pricing | Time-track next 2 engagements |
| 3 | Client value estimates are in the right order of magnitude | ROI claims collapse, client trust lost | Validate with 3 past client outcomes |
| 4 | Academy ~30 pd aligns with "3-4 months, 2p at 40%" | Description implies ~48 pd, not 30 | Define detailed delivery plan |
| 5 | EUR/CHF rate stable at ~0.96 | Price perception shifts | Monitor, update quarterly |

---

*All prices in EUR. CHF equivalent: multiply by 0.96.*
*Cost basis: EUR 1,200/person/day fully loaded.*
