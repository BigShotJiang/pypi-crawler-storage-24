# BriX Service Menu

**Engineering Excellence, AI-Native Transformation**

Alessandro Di Gioia | Michele Brissoni | Marco Consolaro

---

*We help engineering organizations build the muscle to thrive with AI -- not by replacing what works, but by amplifying it. Every engagement starts with understanding, never with a solution looking for a problem.*

---

## How to Read This Menu

Services are organized in three courses, designed to be consumed in sequence but available individually. Each course builds on the previous one, creating compounding value.

- **Course 1 -- Antipasti**: Low-risk, high-insight engagements. Learn where you stand.
- **Course 2 -- Primi**: Build capability and prove value with real teams on real code.
- **Course 3 -- Secondi**: Wire AI-native practices into the engineering organization permanently.

Prices reflect 10-20% of the value delivered. The pricing logic section at the end shows every calculation.

All prices in EUR. CHF equivalent: multiply by 0.96 [ASSUMPTION: EUR/CHF rate stable at ~0.96 in 2026 Q1-Q2].

---

## Course 1: Antipasti -- Organizational Alignment

*Low commitment. High signal. The goal is to see clearly before acting.*

These engagements give leadership a factual picture of where the organization stands -- technically, culturally, and in terms of AI readiness. They are designed to surface the gap between perception and reality.

---

### 1.1 The Mirror -- AI-Readiness Assessment

**Job**: "When I've just taken the reins of a large engineering organization and everyone claims they're 'doing AI,' I want an objective, data-driven picture of what's actually happening across teams, so I can make my first strategic bets with evidence instead of anecdotes."

**What it is**: A structured diagnostic of your engineering organization's readiness to adopt AI-augmented development practices, using BriX's proprietary assessment portal.

**What you get**:
- Online assessment completed by 5-15 team leads (30 min each)
- 20-page AI-Readiness Scorecard with per-team heat map across 6 dimensions (practices, tooling, culture, skills, leadership, infrastructure)
- Gap analysis: current state vs. AI-native target state
- Prioritized action roadmap (3/6/12 month horizons)
- 90-minute executive debrief with Q&A

**Duration**: 2 weeks (1 week assessment, 1 week analysis + debrief)
**BriX team**: 1 person (+ portal automation)
**Price**: EUR 4,800 -- 7,200

**Bridge**: Surfaces the specific gaps that Course 2 engagements address. Teams scoring below 40% on "practices" dimension are candidates for The Dojo (2.1). Teams scoring below 30% on "culture" are candidates for The Campfire (1.3).

---

### 1.2 The X-Ray -- Engineering Practices Audit

**Job**: "When my teams claim they do TDD and continuous delivery but production incidents keep happening, I want someone who has no political stake to tell me what's actually going on in the codebase and pipelines, so I can stop guessing and start fixing the real bottlenecks."

**What it is**: A deep-dive technical audit of how your teams actually build software -- not how they say they build it. Code review, CI/CD pipeline analysis, test coverage quality (not just quantity), deployment frequency, and incident response.

**What you get**:
- Codebase sampling across 3-5 repositories (architecture, test quality, coupling metrics)
- CI/CD pipeline audit (build times, flaky test rate, deployment frequency)
- Developer experience survey (20 questions, anonymous, benchmarked)
- 30-page Technical Practices Report with maturity scores per team
- Benchmark comparison against industry peers [ASSUMPTION: BriX maintains a benchmark dataset from prior clients]
- Half-day findings workshop with engineering leadership

**Duration**: 3 weeks (1 week data collection, 1 week analysis, 1 week reporting + workshop)
**BriX team**: 2 people
**Price**: EUR 11,000 -- 16,200

**Bridge**: Identifies which teams are ready for AI-augmented practices (Course 2) and which need foundational work first. Directly feeds into The Dojo (2.1) team selection.

---

### 1.3 The Campfire -- Leadership Alignment Workshop

**Job**: "When my engineering leaders each have a different definition of 'engineering excellence' and the resulting friction is silently killing cross-team initiatives, I want a structured way to surface those disagreements and resolve them, so I can set a unified direction without spending six months in committee."

**What it is**: A facilitated half-day session for CTO + engineering leads (6-12 people) to align on what "engineering excellence" and "AI-native" actually mean for your organization. Surfaces hidden disagreements before they become blockers.

**What you get**:
- Pre-workshop survey identifying top 5 points of internal divergence
- Facilitated half-day workshop using Wardley Mapping for technology strategy
- Written alignment charter: shared definitions, priorities, success metrics
- Decision log: what was agreed, what remains contested, who owns resolution
- 30-day follow-up check-in (1 hour)

**Duration**: Half-day workshop + 1 week prep + follow-up
**BriX team**: 2 people (1 facilitator, 1 observer/scribe)
**Price**: EUR 5,400 -- 8,400

**Bridge**: Creates the shared language and strategic alignment that makes Course 2 engagements succeed. Without this, capability-building efforts fragment along existing faction lines.

---

### 1.4 The Compass -- Product Mindset Diagnostic

**Job**: "When my teams ship features on time but nobody can tell me whether those features moved a business metric, I want to understand how deep the 'feature factory' problem really goes, so I can decide where to invest in outcome-oriented thinking before pouring money into AI acceleration."

**What it is**: An assessment of how well engineering teams understand the business impact of what they build. Measures product thinking, outcome orientation, and the gap between "feature factory" and "product team."

**What you get**:
- Structured interviews with 8-12 engineers and product managers
- Product mindset maturity assessment across 4 dimensions (outcome thinking, customer empathy, experimentation, data-driven decisions)
- 15-page diagnostic report with specific examples from your organization
- Recommended interventions mapped to maturity level
- Executive summary (2-page, board-ready)

**Duration**: 2 weeks
**BriX team**: 1 person
**Price**: EUR 4,800 -- 7,200

**Bridge**: Organizations scoring low on product mindset get more value from The Greenhouse (2.4) before The Forge (2.3). This diagnostic prevents investing in AI tooling before the team knows what outcomes to optimize for.

---

## Course 2: Primi -- Capability and Use Case Build

*Hands-on skill building. Real code. Real teams. Prove that the new way works before scaling it.*

These engagements put BriX practitioners alongside your teams, building skills through practice -- not slides. Every engagement produces measurable before/after metrics.

---

### 2.1 The Dojo -- TDD and Craftsmanship Intensive

**Job**: "When I know my teams need stronger engineering fundamentals before we can trust AI-generated code in production, I want them to learn TDD and clean code on their own codebase with expert coaches, so I can build the safety net that makes AI augmentation reliable instead of reckless."

**What it is**: A 3-day immersive workshop where one team (6-8 developers) learns Test-Driven Development, refactoring, and clean code practices by working on their own codebase -- not toy exercises.

**What you get**:
- Day 1: TDD fundamentals with katas, then applied to team's real code
- Day 2: Refactoring legacy code, test doubles, outside-in TDD
- Day 3: Team applies practices to a real feature with coaching
- Pre/post skills assessment (individual scorecards)
- Team practice guide: 12-week self-directed practice plan with weekly katas
- 3 x 1-hour follow-up coaching sessions (weeks 2, 4, 8)

**Duration**: 3 days on-site + 8 weeks follow-up
**BriX team**: 2 people (lead trainer + assistant coach)
**Price**: EUR 16,200 -- 21,600

**Bridge**: Teams that complete The Dojo are ready for The Forge (2.3) -- adding AI-augmented practices on top of solid engineering fundamentals. Without TDD discipline, AI tools amplify bad habits.

---

### 2.2 The Forge -- AI-Augmented Development Workshop

**Job**: "When my developers are already experimenting with AI coding tools but each person uses them differently and nobody knows if the output is actually good, I want a structured methodology that pairs AI with engineering discipline, so I can scale AI-assisted development with confidence instead of chaos."

**What it is**: A 2-day workshop where one team (6-8 developers) learns to use AI coding assistants effectively within a disciplined engineering workflow. Built on nWave methodology: AI amplifies craftsmanship, it does not replace it.

**What you get**:
- Day 1: AI pair programming patterns, prompt engineering for code, AI-assisted TDD (red-green-refactor with AI in the loop)
- Day 2: Team applies nWave-style workflows to a real feature -- AI generates, humans validate, tests prove correctness
- Hands-on with Claude Code, Copilot, or team's preferred AI tools
- AI effectiveness scorecard: measuring quality of AI output with and without TDD guardrails
- Team playbook: "When to use AI, when not to, and how to verify"
- 2 x 1-hour follow-up sessions (weeks 2, 4)

**Duration**: 2 days on-site + 4 weeks follow-up
**BriX team**: 2 people
**Price**: EUR 13,800 -- 19,200

**Bridge**: Teams that see measurable improvement become internal champions for scaling AI-augmented practices (Course 3). Their results are the proof case for organizational investment.

---

### 2.3 The Residency -- Embedded Coaching Sprint

**Job**: "When my team attended a workshop and learned the theory but went back to old habits within a month, I want a practitioner who works alongside them on real deliverables long enough for the new practices to become muscle memory, so I can get permanent behavior change instead of temporary enthusiasm."

**What it is**: One BriX practitioner embeds with a team for 2-4 weeks, working alongside developers on real deliverables. Not observing -- pairing. Not advising -- doing.

**What you get**:
- Full-time embedded coach for the sprint duration
- Daily pairing/mobbing sessions on production code
- Weekly progress report: practices adopted, resistance encountered, metrics moved
- End-of-sprint retrospective with team and management
- Handover document: what the team can sustain independently, what needs continued support

**Duration**: 2-4 weeks, full-time
**BriX team**: 1 person (dedicated)
**Price**: EUR 9,600 -- 19,200 (2 weeks) | EUR 16,800 -- 33,600 (4 weeks)

**Bridge**: The Residency produces the strongest practice adoption because it operates on real work, not exercises. Teams that complete a Residency are ready to mentor others (Course 3 multiplier).

---

### 2.4 The Greenhouse -- Product Thinking for Engineers

**What it is**: A 1-day workshop teaching engineers to think in outcomes, not outputs. Covers Jobs-to-be-Done, hypothesis-driven development, and measuring impact -- skills that make AI tool adoption purposeful rather than random.

**What you get**:
- Full-day workshop (8-12 participants: engineers + product managers together)
- JTBD framework applied to team's actual product/feature
- Hypothesis backlog: team's current roadmap rewritten as testable hypotheses
- Measurement plan: what to track and how to know if a feature succeeded
- Template kit for ongoing hypothesis-driven planning

**Duration**: 1 day on-site
**BriX team**: 1 person
**Price**: EUR 4,800 -- 7,200

**Bridge**: Engineers with product thinking use AI tools to optimize outcomes, not just velocity. This workshop transforms "we shipped faster with AI" into "we shipped the right thing faster with AI."

---

## Course 3: Secondi -- AI-Native Enterprise Wiring

*Organizational transformation. The practices proven in Course 2 become the way everyone works.*

These engagements scale what worked with pilot teams across the engineering organization. They require executive sponsorship and a 6-12 month commitment.

---

### 3.1 The Academy -- Internal AI-Native Training Program

**Job**: "When I need to upskill 200+ engineers but I cannot afford to fly in external trainers forever, I want to build an internal training capability that my organization owns and operates independently, so I can scale engineering excellence without scaling consulting invoices."

**What it is**: BriX designs, builds, and launches an internal training program that your organization owns and runs independently. A "train the trainers" approach that multiplies capability without multiplying consultants.

**What you get**:
- Curriculum design: 3-track program (Fundamentals, Practitioner, Champion) tailored to your tech stack and practices
- Training materials: slide decks, exercises, katas, assessment rubrics -- all branded as yours
- Train-the-trainer bootcamp: 4-6 internal trainers certified to deliver the program
- Pilot delivery: BriX co-delivers first cohort with internal trainers
- Quality assurance: BriX reviews and provides feedback on second cohort delivery
- Program playbook: scheduling, logistics, measurement, continuous improvement

**Duration**: 3-4 months (design through second cohort)
**BriX team**: 2 people (intermittent, ~40% allocation over the period)
**Price**: EUR 36,000 -- 52,800

**Bridge**: The Academy creates self-sustaining capability. Once internal trainers are certified, the organization scales training without external dependency. BriX shifts to annual refresh and quality assurance retainer.

---

### 3.2 The Catalyst -- AI Transformation Office Setup

**Job**: "When AI adoption is happening in pockets but nobody is coordinating it and every team reinvents the wheel, I want to stand up a small internal team whose job is to accelerate and standardize AI practices across engineering, so I can turn scattered experiments into an organizational capability."

**What it is**: BriX helps establish a small internal team (3-5 people) whose job is to accelerate AI adoption across engineering. Think of it as an internal dojo + innovation lab + practice community -- with structure and metrics.

**What you get**:
- Operating model for the AI Transformation Office (charter, staffing, budget, KPIs)
- Selection and onboarding of internal team members (BriX advises, client hires)
- Playbook: how to identify, pilot, measure, and scale AI use cases
- Tooling standardization: recommended AI tool stack with governance policies
- First 90-day execution plan with 3 concrete pilot use cases
- Monthly advisory check-ins for 6 months

**Duration**: 6 months (intensive first 2 months, advisory remaining 4)
**BriX team**: 1-2 people (50% first 2 months, 10% remaining 4 months)
**Price**: EUR 48,000 -- 72,000

**Bridge**: The Catalyst team becomes the permanent engine for AI-native practices. BriX transitions to annual strategic advisory.

---

### 3.3 The Wiring -- nWave Enterprise Deployment

**Job**: "When I want every team using AI-augmented workflows consistently instead of each developer doing their own thing, I want a proven framework deployed and customized to our environment, so I can encode our engineering standards into executable workflows that scale with the organization."

**What it is**: Full deployment of nWave (open-source AI workflow framework) across engineering teams, with customization for your organization's processes, tool stack, and quality gates.

**What you get**:
- nWave installation and configuration for your environment
- Custom agent definitions tailored to your architecture decisions, coding standards, and review processes
- Integration with existing CI/CD, ticketing, and communication tools
- Pilot deployment with 2-3 teams (4 weeks)
- Organization-wide rollout plan
- Admin training: how to maintain and extend nWave configurations
- 3 months of support (bug fixes, configuration tuning)

**Duration**: 2-3 months
**BriX team**: 1-2 people (intermittent)
**Price**: EUR 24,000 -- 43,200

**Bridge**: nWave becomes the infrastructure layer that encodes your engineering practices as executable workflows. Combined with The Academy (3.1), it ensures that AI-augmented practices are both taught and enforced.

---

## A La Carte -- Available Anytime

*Standalone services that complement any course or can be purchased independently.*

---

### Conference Keynote or Workshop

**Job**: "When I need to spark energy and shared understanding at our engineering offsite or conference, I want an experienced practitioner who can demonstrate AI-augmented craftsmanship live and make it tangible for 200 engineers in the room, so I can create momentum for the transformation I am leading."

**What it is**: One BriX practitioner delivers a keynote (45-60 min) or hands-on workshop (half-day or full-day) at your internal conference, offsite, or team event.

**Topics**: AI-augmented TDD, software craftsmanship in the AI era, engineering culture transformation, nWave live demo
**Price**: EUR 3,600 (keynote) | EUR 6,000 (half-day workshop) | EUR 9,600 (full-day workshop)
**BriX team**: 1 person

---

### Monthly Advisory Retainer

**Job**: "When I face recurring strategic decisions about engineering practices and AI adoption but I do not need a full-time consultant, I want a trusted advisor I can call on twice a month who already knows my organization, so I can get sharp, contextualized guidance without the overhead of a new engagement each time."

**What it is**: Ongoing access to BriX for strategic advice, practice reviews, and problem-solving. Not embedded coaching -- rather, a trusted advisor on call.

**What you get**: 2 x 90-minute sessions per month + async access (email/Slack, 24h response SLA)
**Price**: EUR 3,600/month (minimum 3 months)
**BriX team**: 1 person (named advisor)

---

### AI-Readiness Portal -- Self-Serve

**Job**: "When I suspect we are not as AI-ready as my teams claim but I am not ready to engage a consultancy yet, I want a quick, low-cost way to get a data point on where we stand, so I can decide whether a deeper assessment is worth the investment."

**What it is**: Access to BriX's online AI-readiness assessment without the consulting engagement. You run the assessment, you read the automated report.

**What you get**: Portal access for up to 20 respondents, automated scorecard with benchmarks
**Price**: EUR 1,200
**BriX team**: 0 (automated)

**Note**: For organizations that want the data before deciding whether to engage BriX. The self-serve report is useful but lacks the interpretation and prioritization that The Mirror (1.1) provides.

---

## Chef's Recommendation for CSS

*A suggested tasting menu based on what we know about CSS today.*

**Context**: CSS is a Swiss enterprise with hundreds of developers, a new CIO with XP roots, a new CEO, strong internal capability through dojo and academy programs, an internal culture divide between practitioners who embrace craftsmanship ("Crafters") and those who resist change ("Dinos"), early AI experimentation but no structured approach, and low organizational self-awareness about their actual readiness level. [ASSUMPTION: This characterization is accurate as of the Feb 2026 strategy session.]

---

### Phase 1: See Clearly (Months 1-3) -- Fully Detailed

**Strategic goal**: Give the new CIO an evidence-based picture of where CSS actually stands, and create alignment among engineering leaders on where to go.

**Month 1: The Mirror (AI-Readiness Assessment)**
- Deploy the assessment portal to 15-20 team leads across CSS divisions
- Produces the heat map that shows which teams are ready for AI-augmented practices and which are not
- Critically: surfaces the Crafter/Dino divide with data, not anecdotes
- Deliverable: 20-page scorecard + executive debrief with CIO
- Cost: EUR 7,200 (top of range -- Swiss enterprise, larger scope)

**Month 2: The Campfire (Leadership Alignment Workshop)**
- Half-day workshop with CIO + 8-10 engineering leaders
- Uses the Mirror data as input -- not abstract strategy, but "here is what your organization looks like, now what?"
- Surfaces divergent definitions of "AI-native" and "engineering excellence"
- Produces alignment charter that the CIO can use to set direction
- Cost: EUR 8,400 (top of range -- larger group, higher stakes)

**Month 3: The Compass (Product Mindset Diagnostic)**
- Assess whether CSS teams think in outcomes or outputs
- Critical for CSS because AI tools without product thinking just accelerate building the wrong thing faster
- Identifies which teams are ready for AI-augmented practices and which need product thinking first
- Cost: EUR 7,200 (top of range)

**Phase 1 Total: EUR 22,800**
**Phase 1 Value Justification**: See Pricing Logic section.

---

### Phase 2: Build Proof (Months 4-8)

**Strategic goal**: Prove AI-augmented craftsmanship works with 2-3 pilot teams, creating internal champions and measurable results.

Recommended sequence:
1. **The Dojo** with 2 pilot teams (selected using Mirror data) -- EUR 32,400 - 43,200
2. **The Forge** with the same 2 teams (AI on top of solid TDD) -- EUR 27,600 - 38,400
3. **The Residency** with 1 team (deepen adoption on production code) -- EUR 16,800 - 33,600

**Phase 2 Estimated Range: EUR 76,800 - 115,200**

---

### Phase 3: Wire It In (Months 9-18)

**Strategic goal**: Scale what worked across the organization. Make it permanent.

Recommended:
1. **The Academy** (train CSS internal trainers to deliver ongoing) -- EUR 36,000 - 52,800
2. **The Wiring** (nWave deployment, integrated with CSS tooling) -- EUR 24,000 - 43,200
3. **Monthly Advisory Retainer** (12 months strategic support) -- EUR 43,200

**Phase 3 Estimated Range: EUR 103,200 - 139,200**

---

### Full Engagement Summary

| Phase | Timeline | Investment Range (EUR) | Investment Range (CHF) |
|-------|----------|----------------------|----------------------|
| 1: See Clearly | Months 1-3 | 22,800 | 21,900 |
| 2: Build Proof | Months 4-8 | 76,800 - 115,200 | 73,700 - 110,600 |
| 3: Wire It In | Months 9-18 | 103,200 - 139,200 | 99,100 - 133,600 |
| **Total** | **18 months** | **202,800 - 277,200** | **194,700 - 266,100** |

**Anchoring note**: Present Phase 3 total first in any conversation with CSS. The EUR 103,200-139,200 range makes Phase 1's EUR 22,800 feel like a low-risk entry point -- which it is.

---

## Menu Degustazione -- Phase 1 Package

**Job**: "When I have just been appointed CIO and inherited hundreds of developers I do not know yet, I want a single engagement that gives me the full picture -- AI readiness, leadership alignment, and product maturity -- in one go with one price and one contract, so I can make my first 90-day strategic decisions with evidence instead of politics."

*The complete Phase 1 experience as a single, streamlined engagement. One contract, one price, one deliverable package.*

This package bundles The Mirror (1.1), The Campfire (1.3), and The Compass (1.4) into a single engagement with an integrated timeline and a consolidated deliverable.

**What you get**:
- Everything from The Mirror, The Campfire, and The Compass -- delivered as a unified program
- Integrated 40-page Executive Intelligence Report combining AI-readiness scorecard, leadership alignment charter, and product mindset diagnostic into a single narrative with cross-referenced findings
- Unified prioritized roadmap: instead of three separate action lists, one sequenced plan that accounts for dependencies across all three dimensions
- Single kick-off, single executive debrief (90 minutes), single 30-day follow-up
- Private CIO briefing document (4-page, board-ready): the "state of engineering" summary a new CIO can use in their first executive committee meeting

**Duration**: 2.5 months (streamlined from 3 months by overlapping data collection and running interviews in parallel with assessment analysis)

**Timeline**:
- Weeks 1-2: Mirror assessment deployed + Compass interviews begin in parallel
- Weeks 3-4: Mirror analysis + Compass analysis (concurrent)
- Week 5: Campfire workshop (uses Mirror + Compass findings as input -- richer than running Campfire without Compass data)
- Weeks 6-8: Integrated report, executive debrief, roadmap delivery
- Week 10: 30-day follow-up check-in

**BriX team**: 2 people (coordinated)

**Price**: EUR 13,200 -- 19,800

Compared to purchasing separately (EUR 15,000 -- 22,800), the package saves 12% through:
- Shared data collection (one survey period, not two)
- Combined analysis effort (cross-dimensional insights are produced once, not reconciled after)
- Single executive debrief instead of three separate presentations

**Bridge**: The Menu Degustazione is the recommended entry point for any new CIO or VP Engineering engagement. It produces everything needed to make an informed decision about Course 2 investments. For CSS specifically, this replaces the Phase 1 line items in the Chef's Recommendation with a single approval.

---

## Pricing Logic

*Every price on this menu is derived from value delivered, not cost incurred. Here is the methodology.*

### Methodology

Following value-based pricing (price = 10-20% of quantified customer value):

1. **Quantify the value** the service delivers to the client
2. **Set price at 10-20%** of that value (customer keeps 80-90% of the value)
3. **Cross-check against delivery cost** to ensure healthy margins for BriX

### BriX Cost Basis

- 3-person team, fully loaded daily cost [ASSUMPTION]: EUR 1,200/person/day (includes overhead, tools, travel buffer for Swiss market)
- This is the floor, not the pricing basis. Value-based pricing should always exceed cost-plus.

---

### Course 1 Value Calculations

**The Mirror (EUR 4,800 - 7,200)**

Value to client: An enterprise with 200+ developers making a wrong AI adoption decision wastes 6-12 months and EUR 500,000+ in misallocated training, tooling, and reorganization [ASSUMPTION: based on typical enterprise AI initiative budgets]. The Mirror prevents this by providing an evidence-based starting point.

- Conservative value of "avoiding wrong first step": EUR 50,000 (minimum redirected budget)
- Price at 10-15% of value: EUR 5,000 - 7,500
- BriX cost: ~5 person-days = EUR 6,000
- Range set: EUR 4,800 - 7,200 (lower bound compressed to stay accessible as entry point)

**The X-Ray (EUR 11,000 - 16,200)**

Value to client: Engineering practices audit identifies waste in build times, flaky tests, deployment friction, and technical debt. For a 200-developer organization:

- Average developer cost [ASSUMPTION]: CHF 150,000/year (~EUR 156,000/year) = EUR 650/day (based on 220 working days, adjusted for Swiss market)
- If audit findings improve developer effectiveness by just 2% across 200 developers: 200 x EUR 650 x 220 days x 2% = EUR 572,000/year
- Price at 2-3% of first-year value: EUR 11,440 - 17,160
- BriX cost: ~10 person-days = EUR 12,000
- Range set: EUR 11,000 - 16,200

**The Campfire (EUR 5,400 - 8,400)**

Value to client: Leadership misalignment on engineering strategy delays decisions by 3-6 months [ASSUMPTION: based on organizational behavior research on misaligned leadership teams]. For an organization investing EUR 25M/year in engineering:

- Cost of 3 months strategic drift: ~EUR 200,000 in misallocated effort [ASSUMPTION: conservative estimate, 0.8% of annual engineering spend]
- Price at 3-4% of value: EUR 6,000 - 8,000
- BriX cost: ~5 person-days = EUR 6,000
- Range set: EUR 5,400 - 8,400

**The Compass (EUR 4,800 - 7,200)**

Value to client: Teams without product mindset build features nobody uses. Industry data shows 60-80% of features are rarely or never used [ASSUMPTION: sourced from Standish Group and Pendo studies]. For a team building EUR 2M in features/year:

- Value of redirecting even 10% of wasted feature work: EUR 120,000 - 160,000
- Price at 4-5% of value: EUR 4,800 - 8,000
- BriX cost: ~4 person-days = EUR 4,800
- Range set: EUR 4,800 - 7,200

---

### Course 2 Value Calculations

**The Dojo (EUR 16,200 - 21,600)**

Value to client: TDD adoption reduces defect density by 40-90% [ASSUMPTION: sourced from Microsoft/IBM studies on TDD effectiveness]. For a team of 8 developers:

- Average developer cost [ASSUMPTION]: CHF 150,000/year (~EUR 156,000/year) = EUR 650/day
- Average time spent on bug fixes: 30% of development time [ASSUMPTION: industry average]
- 8 developers x EUR 650/day x 220 days x 30% bug-fix time = EUR 343,200/year on defects
- 40% reduction in defect time = EUR 137,280/year saved
- Price at 12-16% of first-year value: EUR 16,470 - 21,960
- BriX cost: ~8 person-days = EUR 9,600
- Range set: EUR 16,200 - 21,600

**The Forge (EUR 13,800 - 19,200)**

Value to client: AI-augmented development with proper guardrails increases developer throughput by 20-40% [ASSUMPTION: conservative range based on GitHub Copilot studies showing 25-55% faster task completion, discounted for real-world adoption friction].

- Average developer cost [ASSUMPTION]: CHF 150,000/year (~EUR 156,000/year) = EUR 650/day
- 8 developers x EUR 650/day x 220 days x 20% throughput gain = EUR 228,800/year
- Price at 6-8% of first-year value: EUR 13,730 - 18,300
- BriX cost: ~6 person-days = EUR 7,200
- Range set: EUR 13,800 - 19,200

**The Residency (EUR 9,600 - 33,600)**

Value to client: Embedded coaching produces deeper, more permanent practice adoption than workshops alone. The Residency value is the delta between "learned in workshop" and "actually uses daily."

- Workshop-only adoption rate [ASSUMPTION]: 30-40% of practices stick after 6 months
- Residency adoption rate [ASSUMPTION]: 60-80% of practices stick after 6 months
- Value delta per team: approximately 2x the ongoing savings from Dojo/Forge
- BriX cost: 10-20 person-days = EUR 12,000 - 24,000
- Range set: EUR 9,600 - 33,600 (wide range reflects 2-week vs 4-week engagement)

**The Greenhouse (EUR 4,800 - 7,200)**

Value follows same logic as The Compass. Teaching engineers product thinking redirects effort toward valuable outcomes. Priced identically to The Compass because the value mechanism is the same -- just delivered to a different audience (engineers vs. leadership).

---

### Course 3 Value Calculations

**The Academy (EUR 36,000 - 52,800)**

Value to client: An internal training program that runs for 3+ years without external dependency. Cost comparison:

- External training for 200 developers at EUR 2,000/person/year [ASSUMPTION] = EUR 400,000/year
- Internal program (after BriX setup) at EUR 50,000/year to operate [ASSUMPTION: internal trainer time + materials]
- Annual savings: EUR 350,000/year
- 3-year savings: EUR 1,050,000
- Price at 3-5% of 3-year value: EUR 31,500 - 52,500
- BriX cost: ~35 person-days over 4 months = EUR 42,000
- Range set: EUR 36,000 - 52,800

**The Catalyst (EUR 48,000 - 72,000)**

Value to client: A functioning AI Transformation Office accelerates AI adoption by 12-18 months [ASSUMPTION: based on enterprise digital transformation timelines]. For an organization spending EUR 25M/year on engineering:

- Value of 12 months faster AI adoption: conservative EUR 500,000 in earlier productivity gains [ASSUMPTION]
- Price at 10-14% of value: EUR 50,000 - 70,000
- BriX cost: ~45 person-days over 6 months = EUR 54,000
- Range set: EUR 48,000 - 72,000

**The Wiring (EUR 24,000 - 43,200)**

Value to client: nWave standardizes AI-augmented workflows, reducing the "every developer uses AI differently" problem. Consistent workflows mean consistent quality.

- Quality variance reduction [ASSUMPTION]: 15-25% fewer production incidents from inconsistent AI-generated code
- For a 200-developer org with 10 incidents/month at EUR 5,000/incident [ASSUMPTION]: EUR 600,000/year incident cost
- 20% reduction: EUR 120,000/year saved
- Price at 20-36% of first-year value: EUR 24,000 - 43,200
- BriX cost: ~25 person-days over 3 months = EUR 30,000
- Range set: EUR 24,000 - 43,200

---

### Menu Degustazione Value Calculation

**Menu Degustazione (EUR 13,200 - 19,800)**

Value to client: The combined value of Mirror + Campfire + Compass, plus the integration premium -- cross-dimensional insights that are impossible when assessments are conducted and reported separately.

- Combined separate value: EUR 50,000 (avoiding wrong AI start) + EUR 200,000 (avoiding strategic drift) + EUR 120,000 (redirecting wasted features) = EUR 370,000
- Integration premium [ASSUMPTION]: cross-referenced findings catch 10-15% more issues than siloed assessments
- Adjusted combined value: ~EUR 410,000
- Price at 3-5% of combined value: EUR 12,300 - 20,500
- Separate purchase total: EUR 15,000 - 22,800
- Package discount: 12% (justified by shared data collection and combined analysis)
- BriX cost: ~12 person-days = EUR 14,400
- Range set: EUR 13,200 - 19,800

---

## Assumption Tracker

Every [ASSUMPTION] tagged in this document is tracked here for validation.

| ID | Assumption | Impact (1-5) | Uncertainty (1-5) | Risk Score | Validation Method | Status |
|----|-----------|-------------|-------------------|------------|-------------------|--------|
| A1 | EUR/CHF rate stable at ~0.96 | 2 | 2 | 4 | Check XE.com at proposal time | untested |
| A2 | CSS characterization from Feb 2026 still accurate | 5 | 3 | 15 | Validate in first CSS conversation | untested |
| A3 | BriX fully loaded daily cost EUR 1,200/person | 4 | 2 | 8 | Verify with BriX team | untested |
| A4 | Enterprise AI initiative waste EUR 500K+ for wrong start | 4 | 4 | 16 | Research enterprise AI failure reports | untested |
| A5 | Average developer cost CHF 150,000/year (~EUR 156,000/year) in Swiss enterprise | 3 | 2 | 6 | Cross-check with Swiss salary benchmarks (Swissinfo, Robert Half CH) | untested |
| A6 | 2% effectiveness improvement from audit findings | 3 | 3 | 9 | Track in first X-Ray engagement | untested |
| A7 | Leadership misalignment causes 3-6 month delays | 3 | 3 | 9 | Validate with CIO in Campfire prep | untested |
| A8 | 60-80% of features rarely/never used | 3 | 2 | 6 | Cite Standish/Pendo studies | untested |
| A9 | TDD reduces defect density 40-90% | 4 | 2 | 8 | Cite Microsoft/IBM TDD studies | untested |
| A10 | AI tools increase throughput 20-40% with guardrails | 4 | 3 | 12 | Track in first Forge engagement | untested |
| A11 | Workshop-only adoption 30-40%, Residency 60-80% | 3 | 4 | 12 | Track across first 3 engagements | untested |
| A12 | External training cost EUR 2K/person/year | 3 | 3 | 9 | Benchmark against training market | untested |
| A13 | AI Transformation Office accelerates adoption 12-18 months | 4 | 4 | 16 | Track first Catalyst engagement | untested |
| A14 | 10 incidents/month at EUR 5K/incident average | 3 | 3 | 9 | Validate with client incident data | untested |
| A15 | BriX maintains benchmark dataset from prior clients | 3 | 4 | 12 | Verify with BriX team | untested |
| A16 | Menu Degustazione integration premium: cross-referenced findings catch 10-15% more issues | 2 | 4 | 8 | Track in first bundled engagement vs separate deliveries | untested |

**Top 3 assumptions to validate first** (highest risk scores):
1. **A4** (Risk 16): Enterprise AI initiative waste figure -- research needed
2. **A13** (Risk 16): AI Transformation Office acceleration claim -- needs case study evidence
3. **A2** (Risk 15): CSS characterization accuracy -- validate before presenting Chef's Recommendation

---

## Capacity Note

BriX is a 3-person team. Maximum concurrent engagements:

- **2 active delivery engagements** (workshops, residencies) at any time
- **1 advisory/assessment** can run in parallel with delivery
- **Lead time**: 2-4 weeks for scheduling [ASSUMPTION: no existing backlog]

This is a feature, not a bug. Limited capacity means every engagement gets senior practitioners, not junior consultants. We onboard a maximum of 2 new enterprise clients per quarter [genuine scarcity -- 3 people, finite hours].

---

*This is a living document. Prices, assumptions, and service definitions evolve as BriX delivers engagements and collects evidence. Version 1.1 -- March 2026.*
