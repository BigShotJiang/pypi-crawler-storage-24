# JTBD Analysis: Business Agents

**Feature**: business-agents
**Date**: 2026-03-04
**Analyst**: Luna (nw-product-owner)

---

## Persona: The Co-Founders

Three co-founders of a 3-person training and consulting company. They share responsibilities but have distinct operational roles. All are technical practitioners who built nWave from real expertise. They are NOT sales professionals -- they are engineers and trainers who need to sell.

### Persona: Marco Rossi

**Who**: Technical co-founder responsible for business development and partnerships
**Demographics**:
- Deep technical expertise in AI-augmented software development
- Attends 4-6 conferences/year, generates warm leads through talks and workshops
- Comfortable with CLI tools (uses nWave daily)
- Primary motivation: convert expertise into revenue without becoming a "salesperson"

**Pain Points**:
- Has warm leads from conferences but no systematic follow-up process
- Spends 2-3 hours crafting each outreach email, second-guessing tone
- No structured way to prepare for pricing negotiations with CTOs
- Loses deals because he under-prices out of anxiety about seeming "too expensive"

**Success Metrics**:
- First follow-up sent within 24 hours of meeting a lead
- Outreach sequence completed in < 30 minutes (not 2-3 hours)
- Negotiation preparation completed with confidence before every call

### Persona: Elena Ferrara

**Who**: Training lead responsible for offer design and program development
**Demographics**:
- Expert trainer with deep methodology knowledge
- Designs training programs, bootcamps, and workshop curricula
- Evaluates market positioning and pricing for training offerings
- Primary motivation: package expertise into scalable, well-priced offerings

**Pain Points**:
- Cannot articulate the business model clearly to potential partners in < 5 minutes
- Pricing decisions are gut-feel, not evidence-based (Good/Better/Best not structured)
- No Lean Canvas or Value Proposition Canvas to share with co-founders for alignment
- Spends weeks iterating on offer structure that should take days

**Success Metrics**:
- Lean Canvas produced in < 1 hour (not weeks of iteration)
- Pricing model with 3 tiers justified by value, not guesswork
- Co-founder alignment on business model within 1 session

### Persona: Davide Conti

**Who**: Consulting lead responsible for deal closing and enterprise relationships
**Demographics**:
- Senior architect background, credible with enterprise CTOs
- Handles enterprise pipeline: proposals, negotiations, SOWs
- Uncomfortable with "sales tactics" -- prefers principled, honest approach
- Primary motivation: close deals at fair value without feeling manipulative

**Pain Points**:
- Goes into negotiations without structured preparation (no BATNA analysis)
- Proposals take 3-5 days to write, mostly boilerplate he rewrites each time
- Cannot quickly calculate ROI for prospects during live conversations
- Leaves money on the table because he anchors too low

**Success Metrics**:
- Negotiation brief ready in < 1 hour before any call
- Proposal first draft generated in < 2 hours (not 3-5 days)
- Average deal size increases 20% through proper anchoring and value framing

---

## Job Stories

### JS-01: Business Model Articulation

**When** I need to explain our business model to a potential partner, investor, or enterprise prospect,
**I want to** have a clear, structured one-page canvas that shows how we create and capture value,
**so I can** communicate our positioning in under 5 minutes and get alignment from co-founders.

#### Three Dimensions
- **Functional**: Produce a Lean Canvas, Value Proposition Canvas, and ICP definition from unstructured knowledge
- **Emotional**: Feel prepared and articulate instead of fumbling through an improvised pitch
- **Social**: Be perceived as a serious, well-organized business (not "three engineers with a GitHub repo")

#### Forces Analysis
- **Push**: Elena spent 3 weeks iterating on offer structure in Google Docs. Marco pitched differently to two prospects in the same week because there was no shared model. Davide quoted different prices to similar companies.
- **Pull**: A populated Lean Canvas in 1 hour. Co-founder alignment session with concrete artifacts. Pricing model with evidence-based tiers.
- **Anxiety**: "Will the AI-generated canvas be generic boilerplate that doesn't capture our uniqueness?" "Will co-founders reject a model they didn't co-create?"
- **Habit**: Currently they discuss strategy in ad-hoc calls and scattered Google Docs. Elena maintains a mental model she hasn't written down.

**Assessment**: Switch likelihood HIGH. Strong Push (real misalignment incidents) + Strong Pull (concrete artifacts). Anxiety manageable through iterative refinement (loop, not pipeline). Habit broken by making artifacts better than scattered docs.

---

### JS-02: Signal-Based Outreach

**When** I meet a promising lead at a conference or notice a company signal (hiring surge, funding round, tech adoption),
**I want to** generate a personalized, research-backed outreach sequence that sounds like me (not a sales robot),
**so I can** book a discovery call within 2 weeks without spending hours on each email.

#### Three Dimensions
- **Functional**: Generate 3-5 email sequence + LinkedIn touchpoints personalized with verifiable business signals
- **Emotional**: Feel confident that the outreach represents genuine value, not spam
- **Social**: Be perceived as a thoughtful expert reaching out with relevant insight, not a cold-caller

#### Forces Analysis
- **Push**: Marco met 8 promising leads at PyCon last month. Followed up with 2 (the ones he had time for). The other 6 went cold. Each follow-up took 2-3 hours of agonizing over tone. Reply rate on his current emails: ~5%.
- **Pull**: Personalized sequence generated in 30 minutes. Signal-based research surfaced automatically. Reply rates of 15-25% (industry benchmark for signal-based outreach). Consistent follow-up cadence.
- **Anxiety**: "Will prospects see through AI-generated emails?" "Will it sound like every other AI spam flooding inboxes?" "What if it damages our reputation?"
- **Habit**: Marco writes each email from scratch. He has a mental template but no documented sequence. He procrastinates on follow-up because it feels salesy.

**Assessment**: Switch likelihood HIGH. Push is acute (6 lost leads from one conference is measurable revenue loss). Pull is quantifiable (15-25% vs 5% reply rate). Anxiety is the key blocker -- must be addressed through "AI prepares, human approves" and voice-matching.

---

### JS-03: Negotiation Preparation

**When** I have a discovery call or pricing negotiation scheduled with an enterprise CTO,
**I want to** have a structured negotiation brief with BATNA analysis, Ackerman sequence, and value-framing scripts,
**so I can** negotiate confidently at fair value without leaving money on the table or feeling manipulative.

#### Three Dimensions
- **Functional**: Produce negotiation brief with BATNA, ZOPA, Ackerman anchor sequence, and objection-handling scripts
- **Emotional**: Feel ethically grounded and prepared, not anxious or improvising
- **Social**: Be perceived as a credible partner who understands business value, not a desperate vendor

#### Forces Analysis
- **Push**: Davide quoted EUR 15,000 for a 3-month consulting engagement that should have been EUR 25,000. He anchored low because he had no structured preparation. Lost EUR 10,000 on a single deal. In another negotiation, a CTO asked "What's your daily rate?" and Davide gave his number first (classic anchoring mistake).
- **Pull**: Ackerman bargaining sequence pre-calculated (65% -> 85% -> 95% -> 100% of target). BATNA clearly defined before entering any negotiation. Value-based framing scripts that shift conversation from cost to ROI.
- **Anxiety**: "Tactical empathy and anchoring feel manipulative." "What if the client Googles these techniques and sees I'm using a playbook?" "Will scripted responses sound robotic?"
- **Habit**: Davide wings it. He relies on technical credibility and relationship-building. This works for small deals but fails for enterprise pricing.

**Assessment**: Switch likelihood HIGH. Push is financially quantifiable (EUR 10,000 lost on single deal). Pull directly addresses the loss. Anxiety is deeply held (ethical concerns about negotiation tactics) -- must be addressed by framing as "principled negotiation" (Fisher & Ury), not manipulation. Habit is strong but clearly failing at enterprise scale.

---

### JS-04: Strategic Quality Assurance

**When** any co-founder produces a business artifact (canvas, outreach sequence, proposal, pricing model),
**I want to** run an adversarial quality review that checks for ethical violations, credibility gaps, and numerical errors,
**so I can** catch problems before they reach a prospect and damage our reputation.

#### Three Dimensions
- **Functional**: Review artifact against ethical guidelines, factual accuracy, numerical consistency, and credibility
- **Emotional**: Feel safe knowing there's a second pair of eyes, even when working alone
- **Social**: Protect the company's reputation as honest, credible practitioners

#### Forces Analysis
- **Push**: Elena sent a proposal with a typo in the pricing (EUR 1,500 instead of EUR 15,000 -- caught before sending, but barely). Marco's outreach email claimed a case study that was actually a different company. No systematic review process -- each person self-reviews, which misses blind spots.
- **Pull**: Automated ethical boundary check (Cialdini's ethical constraint). Numerical consistency validation. Credibility cross-reference (claims match evidence). Tone analysis against brand voice.
- **Anxiety**: "Will the reviewer be too conservative and water down our messaging?" "Will it slow us down when we need to move fast?"
- **Habit**: Self-review ("I'll just read it one more time before sending"). Works OK for training materials but fails for high-stakes business communications.

**Assessment**: Switch likelihood HIGH. Push includes near-miss incidents with real reputational risk. Pull is a safety net that adds confidence. Anxiety manageable by making review fast (< 5 minutes) and configurable (strict/balanced/light). Habit easily broken because self-review has demonstrably failed.

---

## Opportunity Scoring

Scoring based on co-founder team estimates (3 respondents, treated as directional).

| # | Outcome Statement | Imp. | Sat. | Score | Priority |
|---|---|---|---|---|---|
| 1 | Minimize the time to produce a shareable business model canvas | 90% | 15% | 16.5 | Extremely Underserved |
| 2 | Minimize the likelihood of sending outreach that damages reputation | 95% | 30% | 15.5 | Extremely Underserved |
| 3 | Minimize the time to follow up with a warm lead | 85% | 20% | 14.5 | Underserved |
| 4 | Minimize the likelihood of under-pricing in enterprise negotiations | 90% | 25% | 14.5 | Underserved |
| 5 | Minimize the time to prepare a negotiation brief | 80% | 15% | 13.5 | Underserved |
| 6 | Minimize the likelihood of co-founder misalignment on pricing | 85% | 30% | 12.5 | Underserved |
| 7 | Minimize the time to generate a first-draft proposal | 75% | 20% | 11.5 | Appropriately Served |
| 8 | Minimize the likelihood of numerical errors in business artifacts | 80% | 40% | 11.2 | Appropriately Served |

**Data Quality Notes**:
- Source: team estimates (not user interviews)
- Sample size: 3 co-founders
- Confidence: Medium (small team, but they ARE the users)

### Top Opportunities (Score >= 12)

1. Business model canvas production (16.5) -- JS-01
2. Reputation-safe outreach (15.5) -- JS-02 + JS-04
3. Warm lead follow-up speed (14.5) -- JS-02
4. Enterprise pricing confidence (14.5) -- JS-03
5. Negotiation preparation (13.5) -- JS-03
6. Co-founder alignment (12.5) -- JS-01

---

## Job-to-Agent Mapping

| Job Story | Primary Agent | Supporting Agent |
|---|---|---|
| JS-01: Business Model Articulation | business-discoverer | business-reviewer |
| JS-02: Signal-Based Outreach | outreach-writer | business-reviewer |
| JS-03: Negotiation Preparation | deal-closer | business-reviewer |
| JS-04: Strategic Quality Assurance | business-reviewer | (standalone) |

All four jobs are Extremely Underserved or Underserved. All proceed to journey design.
