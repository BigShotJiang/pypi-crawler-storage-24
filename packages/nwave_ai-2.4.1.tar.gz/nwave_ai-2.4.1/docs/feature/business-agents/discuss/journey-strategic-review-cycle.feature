Feature: Strategic Review Cycle
  As a co-founder of a 3-person consultancy,
  I want every business artifact reviewed for ethical compliance, credibility, and quality
  So I can catch problems before they reach prospects and damage our reputation.

  Background:
    Given the company has 3 co-founders who produce business artifacts
    And the ethical boundary is: represent genuine value honestly, never fabricate
    And review modes are Quick (ethical + credibility), Standard (full), and Deep (full + competitive)

  # Step 1: Submit for Review

  Scenario: Artifact type auto-detected from content structure
    Given Marco has written an outreach sequence in "outreach/anna-chen-sequence.md"
    When Marco submits the file for business review
    Then the reviewer auto-detects the artifact type as "Outreach Sequence"
    And selects applicable review dimensions: ethical boundary, credibility, tone, signal verification, completeness

  Scenario: Lean Canvas detected and appropriate dimensions applied
    Given Elena has written a Lean Canvas in "business-model/lean-canvas.md"
    When Elena submits the file for business review
    Then the reviewer auto-detects the artifact type as "Lean Canvas"
    And selects applicable review dimensions: ethical boundary, credibility, numerical consistency, completeness

  Scenario: Proposal detected with full dimension coverage
    Given Davide has written a proposal in "proposals/techflow-proposal.md"
    When Davide submits the file for business review
    Then the reviewer auto-detects the artifact type as "Proposal"
    And selects applicable review dimensions: ethical boundary, credibility, numerical consistency, tone, completeness, value justification

  # Step 2: Ethical Boundary Checks

  Scenario: Fabricated testimonial detected and blocked
    Given a proposal includes "As our client Acme Corp reported, productivity increased 60%"
    And Acme Corp is not an actual client
    When the reviewer analyzes the proposal
    Then it flags the testimonial as fabricated with CRITICAL severity
    And identifies the specific text and location
    And the artifact cannot be approved until the fabrication is removed

  Scenario: False scarcity detected in outreach
    Given an email includes "We only take on 3 new clients per quarter"
    And this limit is not a real business constraint
    When the reviewer analyzes the outreach sequence
    Then it flags false scarcity as an ethical violation
    And notes: "This creates artificial urgency. If the limit is real, provide evidence."

  Scenario: Genuine value claim passes ethical check
    Given an email states "In our own development, we measured a 40% reduction in AI-related rework"
    And this is based on internal measurement
    When the reviewer analyzes the claim
    Then the ethical boundary check passes
    And notes: "First-person claim with internal evidence -- acceptable"

  Scenario: Honest competitive positioning passes ethical check
    Given a proposal states "Unlike generic AI courses, our methodology includes hands-on TDD enforcement"
    When the reviewer analyzes the competitive positioning
    Then the ethical boundary check passes
    And notes: "Factual differentiation without disparaging competitors"

  # Step 3: Credibility Checks

  Scenario: Unverifiable claim flagged with suggestion
    Given the UVP claims "The only AI workflow framework built by practitioners"
    When the reviewer checks credibility
    Then it flags "the only" as unverifiable
    And suggests: "Built by practitioners who deliver production software daily"
    And marks severity as HIGH

  Scenario: Numerical inconsistency detected in pricing
    Given the pricing model shows training at EUR 5,000/day
    And the proposal quotes training at EUR 4,500/day
    When the reviewer checks numerical consistency
    Then it flags the price discrepancy between the two artifacts
    And identifies both locations
    And asks which price is correct

  Scenario: ROI calculation verified for mathematical accuracy
    Given a proposal claims "15 engineers x 2 hours/week x 52 weeks x EUR 80/hour = EUR 124,800 annual cost"
    When the reviewer checks the calculation
    Then it verifies: 15 * 2 * 52 * 80 = 124,800
    And marks the calculation as correct
    And notes the hourly rate assumption should be stated

  # Step 4: Tone and Voice Checks (Outreach only)

  Scenario: Corporate jargon detected and flagged
    Given an outreach email includes "We'd love to leverage synergies between our organizations"
    When the reviewer checks tone
    Then it flags "leverage synergies" as corporate jargon
    And suggests: "I think there's a natural fit between what we do and your team's challenges"
    And marks severity as MEDIUM

  Scenario: Passive-aggressive break-up email flagged
    Given Touch 5 states "Since I haven't heard back, I'll assume this isn't a priority for you"
    When the reviewer checks tone
    Then it flags the passive-aggressive framing
    And suggests: reframe as genuine value-add with open door
    And provides alternative: "Sharing this case study in case it's useful down the line. Door's always open."

  # Step 5: Resolution Flow

  Scenario: Fix applied to correct location
    Given the reviewer flagged "40% improvement" in Touch 3, line 4
    When Marco chooses to fix the issue
    And the system applies the suggested reframing
    Then Touch 3 is updated at the correct location
    And the original text is preserved in the review log
    And the issue status changes to RESOLVED

  Scenario: Override logged with justification
    Given the reviewer flagged a pricing claim as potentially too high
    When Davide chooses to override with justification "Market rate confirmed by 3 competitor quotes"
    Then the override is logged in the review record
    And the justification is visible in the review summary
    And the artifact proceeds to approval despite the flag

  Scenario: Critical finding blocks skip
    Given the reviewer found a fabricated case study (CRITICAL severity)
    When the author attempts to skip the finding
    Then the system prevents skipping
    And displays: "Critical findings cannot be skipped. Fix or override with justification."
    And the artifact remains unapproved

  Scenario: All issues resolved leads to approval
    Given the reviewer found 3 issues (1 high, 2 medium)
    When the author fixes the high issue and both medium issues
    And the review is re-run
    Then the review score increases to 9/10 or higher
    And the artifact status changes to APPROVED
    And the review log shows the complete resolution history
