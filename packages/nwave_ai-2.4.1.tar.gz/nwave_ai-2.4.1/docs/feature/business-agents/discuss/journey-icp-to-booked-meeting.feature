Feature: From ICP to Booked Meeting
  As Marco Rossi, business development lead of a 3-person consultancy,
  I want to generate personalized, signal-based outreach sequences for warm leads
  So I can book discovery calls within 2 weeks without spending 3 hours per email.

  Background:
    Given Marco is a co-founder responsible for business development
    And the company's ICP is startup CTOs with 5-20 person dev teams
    And Marco met Anna Chen (CTO, TechFlow, 15 engineers) at PyCon
    And Anna mentioned frustration with AI tools producing inconsistent code quality

  # Step 1: Prospect Research

  Scenario: Signal research surfaces verifiable business intelligence
    Given Marco inputs prospect details "Anna Chen, CTO at TechFlow"
    And adds context "Met at PyCon, complained about AI quality in her 15-person team"
    When the outreach-writer researches TechFlow
    Then the profile includes at least 2 business signals from verifiable sources
    And each signal has a source attribution (e.g., "Crunchbase", "LinkedIn Jobs")
    And an inferred pain statement connects the signals to Anna's stated frustration

  Scenario: Research identifies funding signal
    Given TechFlow raised a EUR 4M Series A three months ago
    When the outreach-writer researches TechFlow
    Then the signal analysis includes the funding round with amount and date
    And notes the implication: growth pressure, budget availability for training

  Scenario: Research identifies hiring signal
    Given TechFlow has 4 open engineering positions on LinkedIn
    When the outreach-writer researches TechFlow
    Then the signal analysis includes the hiring surge
    And notes the implication: team scaling, methodology need increasing

  Scenario: Prospect is qualified against ICP criteria
    Given the ICP requires startup CTOs with 5-20 person dev teams
    And Anna Chen is CTO of a 15-person engineering team at a Series A startup
    When the prospect is evaluated against ICP criteria
    Then the prospect matches on role (CTO), team size (15), and stage (Series A)
    And the qualification score indicates high fit

  # Step 2: Generate Outreach Sequence

  Scenario: Sequence generates multi-channel touches with proper cadence
    Given Anna Chen's prospect profile has 4 verified business signals
    When the outreach-writer generates an outreach sequence
    Then the sequence contains 3-5 touches across email and LinkedIn
    And the sequence spans at least 10 days
    And no two touches are on consecutive days
    And each touch has a specific purpose (introduce, engage, demonstrate, follow-up, close/break-up)

  Scenario: First email uses PAS framework with personal context
    Given Marco met Anna at PyCon and discussed AI quality challenges
    When the outreach-writer generates Touch 1
    Then the email opens with personal context from the PyCon meeting
    And identifies the Problem (AI tools producing inconsistent quality)
    And Agitates with TechFlow-specific pressure (scaling team, Series A expectations)
    And presents the Solution as methodology, not product pitch
    And the CTA is low-commitment ("20-minute call to compare notes")

  Scenario: Each email references at least one verified signal
    Given the prospect profile includes 4 signals (funding, hiring, tech adoption, pain)
    When the outreach-writer generates all 5 touches
    Then Touch 1 references the PyCon meeting and hiring/funding signals
    And Touch 3 references the tech adoption signal (GitHub Copilot)
    And no email references signals that were not verified in Step 1

  Scenario: Voice matching preserves author style
    Given Marco's writing style is conversational and technical
    When the outreach-writer generates emails
    Then emails use first-person singular ("I", not "we at nWave")
    And avoid corporate jargon ("synergy", "leverage", "circle back", "touch base")
    And include domain-specific vocabulary appropriate for CTO audience
    And sentence length averages under 20 words

  # Step 3: Reputation Safety Review

  Scenario: Reviewer catches fabricated social proof
    Given Touch 3 claims "Our clients typically see 40% improvement in code quality"
    And the company has fewer than 5 external clients
    When the business-reviewer analyzes the outreach sequence
    Then it flags "typically see" as unsupported by client base size
    And suggests reframing to first-person: "In our own development, we measured a 40% reduction in rework"

  Scenario: Reviewer validates all signal sources
    Given Touch 1 references "Congratulations on the Series A"
    When the business-reviewer verifies the signal
    Then it confirms the Series A is publicly documented
    And notes the source and date of verification

  Scenario: Ethical boundary prevents manipulation
    Given Touch 4 includes "I noticed your competitor just adopted our methodology"
    And this is not a verified fact
    When the business-reviewer analyzes the sequence
    Then it flags this as an ethical violation (fabricated competitive pressure)
    And marks the severity as CRITICAL
    And blocks approval until the fabrication is removed

  Scenario: Approved sequence requires explicit human confirmation
    Given the outreach sequence passed business review with score 9/10
    When the system presents the approved sequence
    Then it requires Marco to explicitly confirm "approve for sending"
    And does not auto-send any email or LinkedIn action
    And each individual touch requires separate send confirmation

  # Step 4: Track & Iterate

  Scenario: Positive reply pauses sequence and triggers deal handoff
    Given Marco has sent Touches 1-2 for Anna Chen
    And Anna replies "That sounds interesting. Let's schedule a call next Thursday at 3pm"
    When Marco logs the reply in the tracking system
    Then remaining touches (3-5) are paused
    And the system suggests preparing for the call with deal-closer agent
    And Anna Chen's full prospect profile is available for deal context transfer

  Scenario: No reply triggers patient re-engagement
    Given Marco has sent all 5 touches over 14 days
    And Anna has not replied to any touch
    When 14 days pass after the final touch
    Then the system does not suggest immediate retry
    And recommends a re-engagement attempt in 30 days
    And suggests a different angle based on new business signals

  Scenario: Sequence timing adjusts for engagement signals
    Given Marco sent Touch 1 and Anna opened the email but did not reply
    And Marco sent Touch 2 (LinkedIn comment) and Anna liked it
    When Touch 3 is scheduled
    Then the system notes above-average engagement (opened + liked)
    And recommends proceeding on schedule (not accelerating)
    And suggests Touch 3 build on the LinkedIn engagement
