# Journey: From Idea to Business Model (business-discoverer)

**Job Story**: JS-01 (Business Model Articulation)
**Persona**: Elena Ferrara (Training Lead)
**Emotional Arc**: Overwhelmed -> Structured -> Aligned -> Confident

---

## Journey Flow

```
[Trigger]              [Step 1]              [Step 2]              [Step 3]              [Step 4]
Partner asks           Interview &           Generate              Review &              Share &
"what do you do?"      Discovery             Canvases              Refine                Align
and Elena fumbles          |                     |                     |                     |
                           v                     v                     v                     v
                    Structured Q&A         Lean Canvas +         Iterative loop       Co-founder
                    extracts tacit         Value Prop Canvas +   with business-       session with
                    knowledge              ICP + Pricing         reviewer             concrete
                                                                                      artifacts
Feels: Overwhelmed   Feels: Guided        Feels: Surprised      Feels: Critical      Feels: Confident
       Frustrated           Relieved             ("this is us!")        Rigorous              Aligned
```

---

## Step 1: Interview & Discovery

**Command**: `/nw:discover business-model`

**What happens**: The business-discoverer agent conducts a structured interview. It asks about customer segments, value propositions, revenue streams, channels, cost structure. It uses the Lean Canvas question framework, but adapted for a 3-person consultancy (not a VC-funded startup).

**Emotional state**: Elena enters feeling overwhelmed ("I have all this in my head but I can't articulate it"). The structured questions make her feel guided. She realizes she knows more than she thought -- the agent is surfacing tacit knowledge.

```
+-- Step 1: Business Discovery Interview ----------------------+
|                                                               |
|  nWave Business Discoverer                                    |
|  ============================                                 |
|                                                               |
|  I'll help you build a business model canvas. Let's start     |
|  with the fundamentals.                                       |
|                                                               |
|  Q1/9: Who is your ideal customer?                            |
|  Think about: role, company size, pain they're feeling,       |
|  what triggers them to look for help.                         |
|                                                               |
|  > Startup CTOs with 5-20 person dev teams who are           |
|  > frustrated that AI coding tools produce inconsistent       |
|  > quality. They've tried GitHub Copilot but want a          |
|  > methodology, not just autocomplete.                        |
|                                                               |
|  Got it. Let me probe deeper:                                 |
|  - What budget authority do they typically have?              |
|  - How do they usually find solutions like yours?             |
|  - What's the "last straw" that makes them seek training?     |
|                                                               |
|  Progress: [==--------] 1/9 sections                          |
+---------------------------------------------------------------+
```

**Shared artifacts produced**:
- `${interview_transcript}` -- raw Q&A responses
- `${customer_segments}` -- extracted ICP definition
- `${value_propositions}` -- articulated value props

---

## Step 2: Generate Canvases

**Command**: (automatic, follows interview completion)

**What happens**: From the interview data, the agent generates: (1) Lean Canvas, (2) Value Proposition Canvas, (3) Ideal Customer Profile, (4) Good/Better/Best pricing model. All populated with real data from the interview, not templates.

**Emotional state**: Elena feels surprised -- "This actually sounds like us, not generic MBA boilerplate." The artifacts are recognizable but more structured than what she had in her head.

```
+-- Step 2: Generated Lean Canvas -----------------------------+
|                                                               |
|  LEAN CANVAS: nWave Training & Consulting                     |
|  =========================================                    |
|                                                               |
|  Problem           | Solution          | Unique Value Prop    |
|  ------------------|-------------------|----------------------|
|  AI coding tools   | Wave-based TDD    | "The only AI         |
|  produce incon-    | methodology with  | workflow built by     |
|  sistent quality.  | specialized agent | practitioners, not    |
|  Teams lack        | orchestration.    | researchers."         |
|  methodology.      | Training + tools. |                      |
|                    |                   |                      |
|  Customer Segments | Channels          | Revenue Streams      |
|  ------------------|-------------------|----------------------|
|  Phase 1: Startup  | Conference talks  | Training: EUR 2-5K/d |
|  CTOs, 5-20 devs   | LinkedIn content  | Consulting: EUR 1-3K |
|  Phase 2: Mid-mkt  | Open-source SEO   | Enterprise: custom   |
|  engineering leads  | Partner referrals |                      |
|                    |                   |                      |
|  Cost Structure    | Key Metrics       |                      |
|  ------------------|-------------------|                      |
|  3 FTE salaries    | Training bookings |                      |
|  Conference travel  | Consulting MRR    |                      |
|  Infrastructure    | Open-source stars |                      |
|                                                               |
|  [Full canvas saved to business-model/lean-canvas.md]         |
|                                                               |
|  Also generated:                                              |
|    - Value Proposition Canvas                                 |
|    - Ideal Customer Profile (Phase 1)                         |
|    - Pricing Model (Good/Better/Best)                         |
|                                                               |
|  Next: Review these with /nw:review business                  |
+---------------------------------------------------------------+
```

**Shared artifacts produced**:
- `${lean_canvas}` -- populated Lean Canvas markdown
- `${value_prop_canvas}` -- Value Proposition Canvas
- `${icp_definition}` -- Ideal Customer Profile
- `${pricing_model}` -- Good/Better/Best tiers

---

## Step 3: Review & Refine (Loop)

**Command**: `/nw:review business` (invokes business-reviewer)

**What happens**: The business-reviewer runs adversarial quality checks: Are claims backed by evidence? Are numbers internally consistent? Does the pricing model pass credibility checks? Are there ethical boundary violations? It returns specific, actionable feedback.

**Emotional state**: Elena feels critical but constructive. The reviewer catches things she missed. She refines, re-runs review. This is a loop, not a pipeline -- she may cycle 2-3 times.

```
+-- Step 3: Business Review --------------------------------+
|                                                            |
|  Business Review: Lean Canvas                              |
|  ================================                          |
|                                                            |
|  Overall: 7/10 -- Good foundation, 3 issues to address    |
|                                                            |
|  [!] CREDIBILITY GAP: "The only AI workflow built by       |
|      practitioners" -- can you verify no competitors       |
|      make this claim? Suggest: "Built by practitioners     |
|      who deliver production software daily"                |
|                                                            |
|  [!] PRICING INCONSISTENCY: Training at EUR 2-5K/day      |
|      but consulting at EUR 1-3K/day. Training typically    |
|      prices lower than consulting in B2B. Verify or        |
|      justify the inversion.                                |
|                                                            |
|  [!] MISSING: Cost structure doesn't include marketing     |
|      budget. With conference-heavy channel strategy,       |
|      travel + sponsorship is likely 15-20% of revenue.     |
|                                                            |
|  [OK] Ethical check: No fabricated claims detected         |
|  [OK] Customer segments: Well-defined with clear phases    |
|  [OK] Value prop: Specific and differentiating             |
|                                                            |
|  Refine and re-run? [y/N]                                  |
+------------------------------------------------------------+
```

**Shared artifacts consumed**:
- `${lean_canvas}`, `${pricing_model}` (read for review)

**Shared artifacts produced**:
- `${review_feedback}` -- structured review with severity ratings

---

## Step 4: Share & Align

**Command**: `/nw:discover business-model --export alignment-deck`

**What happens**: Elena exports the refined artifacts as a shareable package: Lean Canvas + Value Prop Canvas + ICP + Pricing Model + Review Summary. She shares with Marco and Davide for co-founder alignment session. The artifacts provide concrete ground for discussion instead of abstract debate.

**Emotional state**: Elena feels confident. She has something concrete, reviewed, and shareable. The co-founders can react to specific artifacts instead of debating in the abstract.

```
+-- Step 4: Export Alignment Package -----------------------+
|                                                           |
|  Alignment Package: nWave Business Model                  |
|  ==========================================               |
|                                                           |
|  Exported to: docs/business/alignment-deck/               |
|                                                           |
|    1. lean-canvas.md          -- One-page business model  |
|    2. value-prop-canvas.md    -- Customer jobs & gains    |
|    3. icp-phase-1.md          -- Ideal Customer Profile   |
|    4. pricing-model.md        -- Good/Better/Best tiers   |
|    5. review-summary.md       -- Quality review results   |
|                                                           |
|  Review status: 2 iterations, 7/10 -> 9/10               |
|  Open items: 0 critical, 1 minor (marketing budget TBD)  |
|                                                           |
|  Share with co-founders for alignment session.            |
+-----------------------------------------------------------+
```

---

## Integration Checkpoints

| Checkpoint | Validation |
|---|---|
| Interview -> Canvas | All 9 Lean Canvas sections populated from interview data (no blanks) |
| Canvas -> Review | Reviewer receives complete canvas, not partial |
| Review -> Refine | Feedback is actionable and specific (not "needs improvement") |
| Refine -> Export | Only reviewed artifacts exported (review score >= 7/10) |
| Export -> Alignment | Package includes review summary for transparency |
