Feature: From Meeting to Closed Deal
  As Davide Conti, consulting lead of a 3-person consultancy,
  I want to prepare principled negotiation strategies with concrete numbers
  So I can close enterprise deals at fair value without feeling manipulative.

  Background:
    Given Davide is a co-founder with senior architect background
    And Anna Chen (CTO, TechFlow) agreed to a call after Marco's outreach
    And TechFlow has 15 engineers, raised EUR 4M Series A, and needs AI methodology
    And Davide's historical tendency is to anchor too low in pricing

  # Step 1: Build Deal Context

  Scenario: Deal context inherits from outreach prospect profile
    Given Marco's outreach-writer created a prospect profile for Anna Chen
    And the profile includes company signals, pain points, and engagement history
    When Davide initiates deal preparation for "TechFlow training + consulting"
    Then the deal profile includes all prospect data from the outreach phase
    And Davide does not need to re-enter company information
    And the deal source is tracked as "PyCon conference -> outreach sequence reply"

  Scenario: Budget estimation based on company signals
    Given TechFlow raised EUR 4M Series A and is hiring 4 engineers
    When the deal-closer estimates TechFlow's training budget
    Then the estimate references the funding round as budget capacity signal
    And provides a range (e.g., EUR 20,000-50,000 annual training budget)
    And explains the estimation methodology transparently

  Scenario: Multiple deal structure options generated
    Given the pricing model includes training at EUR 2,000-5,000/day and consulting at EUR 1,000-3,000/day
    When the deal-closer generates deal structure options
    Then at least 2 options are presented (e.g., training-only, blended)
    And each option has a price range and scope description
    And options are ordered from lowest commitment to highest value

  # Step 2: Negotiation Brief

  Scenario: BATNA analysis covers both sides
    Given Davide's walk-away point is EUR 4,000 (2-day workshop, cost-only)
    When the deal-closer generates the BATNA analysis
    Then Davide's BATNA is documented with minimum viable deal rationale
    And Anna's alternatives are listed (internal training, generic courses, do nothing)
    And each alternative is assessed for strength/weakness
    And the overall BATNA assessment is provided (e.g., "Weak BATNA -- no direct competitor")

  Scenario: Ackerman sequence calculated from target price
    Given Davide sets a target price of EUR 20,000 for the blended package
    When the deal-closer generates the Ackerman bargaining sequence
    Then the anchor is approximately 130-150% of target
    And Round 1 offers approximately 85% of the anchor
    And Round 2 offers approximately 95% of the target
    And Round 3 offers exactly the target price
    And each round includes a framing rationale and a concession to offer
    And Round 3 includes a non-monetary concession (e.g., "30 days async Slack support")

  Scenario: Value framing quantifies cost of inaction
    Given TechFlow has 15 engineers with estimated average salary of EUR 80,000
    And AI-related rework is estimated at 2 hours per week per engineer
    When the deal-closer generates value framing
    Then the annual cost of inaction is calculated at approximately EUR 125,000
    And the ROI of the engagement is displayed as a multiple (e.g., 3.1x first-year return)
    And the calculation is shown step-by-step so Davide can verify

  Scenario: Objection scripts prepared for likely pushbacks
    Given Anna's likely objections include "too expensive" and "we can train internally"
    When the deal-closer generates objection scripts
    Then at least 3 objection-response pairs are provided
    And the "too expensive" response redirects to value framing (ROI, not cost)
    And the "internal training" response addresses timeline risk
    And a "trial" option is offered as risk reduction (standalone workshop)

  Scenario: Ethical boundaries enforced in negotiation strategy
    Given the negotiation brief includes Ackerman anchoring and objection scripts
    When Davide reviews the brief
    Then no tactic relies on false information
    And no script manufactures urgency or scarcity
    And the overall framing is "mutual value creation" not "winning against the prospect"
    And the ethical boundary check status is visible in the brief

  # Step 3: Proposal & Close

  Scenario: Proposal uses prospect-specific data, not boilerplate
    Given the call with Anna went well and she requested a formal proposal
    When the deal-closer generates the proposal
    Then the executive summary references TechFlow by name and situation
    And the challenge section includes specific data points (15 engineers, 4 new hires, Q3 deadline)
    And the solution phases are mapped to TechFlow's timeline
    And no section contains placeholder text like "[Company Name]" or "[insert here]"

  Scenario: Proposal pricing aligns with negotiation outcome
    Given Davide and Anna agreed on EUR 18,500 during the call
    When the proposal is generated
    Then the investment section shows EUR 18,500
    And the ROI calculation is updated to reflect the actual agreed price
    And the payment terms are included

  Scenario: Proposal requires review before client delivery
    Given the deal-closer generates a proposal for TechFlow
    When the proposal is ready for delivery
    Then the system routes it to business-reviewer before client send
    And the proposal cannot be exported or sent until review score >= 7/10
    And the review checks ethical boundary, numerical consistency, and completeness

  # Step 4: Post-Deal Learning

  Scenario: Won deal captures effectiveness metrics
    Given Davide closes the TechFlow deal at EUR 18,500 against a target of EUR 20,000
    When Davide logs the outcome as "won"
    Then the system records: closed price, target price, percentage achieved (92.5%)
    And compares to Davide's previous comparable deal (EUR 15,000, +23% improvement)
    And records which Ackerman rounds were used and their effectiveness
    And captures Davide's notes on what worked and what to improve

  Scenario: Lost deal captures learning without blame
    Given Davide loses the TechFlow deal because Anna chose internal training
    When Davide logs the outcome as "lost" with reason "chose internal training"
    Then the system records the loss reason
    And suggests adjustments: "Internal training BATNA was underestimated. For similar prospects, probe internal capability earlier in discovery."
    And the tone is constructive, not blame-oriented
    And the learning is tagged for retrieval in future similar-prospect preparations

  Scenario: Deal history informs future BATNA calibration
    Given Davide has closed 5 deals with an average of 88% target achievement
    When the deal-closer prepares a negotiation brief for a new prospect
    Then the BATNA analysis references historical close rates
    And the Ackerman anchor is calibrated based on historical effectiveness
    And the system notes "Based on 5 previous deals, your typical close is 88% of target"
