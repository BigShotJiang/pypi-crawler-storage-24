Feature: From Idea to Business Model
  As Elena Ferrara, training lead of a 3-person consultancy,
  I want to transform my tacit business knowledge into structured canvases
  So I can align with co-founders and articulate our model to partners in under 5 minutes.

  Background:
    Given Elena is a co-founder of a 3-person training and consulting company
    And the company sells nWave training workshops at EUR 2,000-5,000 per day
    And consulting engagements at EUR 1,000-3,000 per day
    And the target market is startup CTOs with 5-20 person dev teams

  # Step 1: Interview & Discovery

  Scenario: Structured interview extracts all Lean Canvas sections
    Given Elena starts a business model discovery session
    When the business-discoverer asks about customer segments
    And Elena responds "Startup CTOs with 5-20 person dev teams frustrated with AI quality"
    And the agent asks about value propositions
    And Elena responds "Wave-based TDD methodology with specialized agent orchestration"
    And the agent continues through all 9 Lean Canvas sections
    Then all 9 sections have at least one data point from Elena's responses
    And no section is marked as blank or "TBD"

  Scenario: Interview adapts questions based on previous answers
    Given Elena identified her customer segment as "Startup CTOs, 5-20 devs"
    When the agent asks follow-up questions about this segment
    Then the questions reference the specific segment mentioned
    And probe deeper into budget authority, discovery channels, and trigger events
    And do not repeat questions already answered

  Scenario: Incomplete interview flags gaps before proceeding
    Given Elena has answered 7 of 9 interview sections
    And the "Key Metrics" and "Unfair Advantage" sections are unanswered
    When Elena requests canvas generation
    Then the agent flags the 2 missing sections
    And offers guiding questions to complete them
    And does not generate canvases until all sections are addressed

  # Step 2: Generate Canvases

  Scenario: Canvas generation produces 4 artifacts from interview data
    Given Elena completed all 9 interview sections
    When the business-discoverer generates artifacts
    Then a Lean Canvas is produced with all 9 sections populated
    And a Value Proposition Canvas shows customer jobs, pains, and gains
    And an Ideal Customer Profile defines Phase 1 target with demographic and psychographic criteria
    And a Good/Better/Best pricing model presents 3 tiers with price points

  Scenario: Generated content traces to interview answers
    Given the interview transcript includes Elena saying "Conference talks are our main channel"
    When the Lean Canvas is generated
    Then the Channels section includes "Conference talks"
    And does not include channels Elena did not mention
    And each canvas section includes a source reference to the interview answer

  Scenario: Pricing model tiers are internally consistent
    Given Elena described training at EUR 2,000-5,000 per day and consulting at EUR 1,000-3,000 per day
    When the pricing model is generated
    Then the Good tier is the lowest price point
    And the Better tier is a mid-range bundle
    And the Best tier is the premium blended package
    And each tier's price is justified by the components included

  # Step 3: Review & Refine

  Scenario: Business reviewer catches unverifiable claim
    Given the generated Lean Canvas UVP states "The only AI workflow built by practitioners"
    When Elena submits the canvas for business review
    Then the reviewer flags the UVP as a credibility gap
    And explains "Cannot verify 'the only' -- competitors may make similar claims"
    And suggests "Built by practitioners who deliver production software daily"

  Scenario: Reviewer catches pricing inconsistency
    Given the pricing model shows training at EUR 5,000/day and consulting at EUR 2,000/day
    When Elena submits the pricing model for review
    Then the reviewer flags the pricing inversion
    And notes "Training typically prices lower than consulting in B2B -- verify or justify"

  Scenario: Iterative refinement cycle improves score
    Given Elena's Lean Canvas received a review score of 7/10 with 3 issues
    When Elena fixes the UVP credibility gap
    And Elena fixes the pricing inconsistency
    And Elena adds marketing budget to cost structure
    And Elena resubmits for review
    Then the review score is 9/10 or higher
    And previously flagged issues show as resolved

  # Step 4: Share & Align

  Scenario: Export creates complete alignment package
    Given Elena's Lean Canvas has a review score of 9/10
    And the Value Proposition Canvas has a review score of 8/10
    And the ICP has a review score of 9/10
    And the pricing model has a review score of 8/10
    When Elena exports the alignment package
    Then the package contains 5 files: lean-canvas, value-prop-canvas, icp, pricing-model, review-summary
    And the review summary shows all review scores and resolved issues

  Scenario: Export blocked for artifacts below quality threshold
    Given Elena's pricing model has a review score of 5/10 with 2 critical issues
    When Elena attempts to export the alignment package
    Then the export is blocked
    And the system identifies the pricing model as below threshold (minimum 7/10)
    And suggests specific fixes for the 2 critical issues
