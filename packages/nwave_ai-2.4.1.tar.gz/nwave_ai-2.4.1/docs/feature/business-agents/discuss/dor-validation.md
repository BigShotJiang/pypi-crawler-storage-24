# Definition of Ready Validation: Business Agents

**Feature**: business-agents
**Date**: 2026-03-04
**Validator**: Luna (nw-product-owner)

---

## US-BA-001: Business Model Discovery Interview

| DoR Item | Status | Evidence |
|---|---|---|
| Problem statement clear | PASS | Elena's problem: tacit knowledge unarticulated, co-founders pitch differently, inconsistent pricing |
| User/persona identified | PASS | Elena Ferrara, training lead, 3-person consultancy, designs offerings and pricing |
| 3+ domain examples | PASS | 3 examples: happy path (full interview), edge case (vague answer), error (pricing disagreement) |
| UAT scenarios (3-7) | PASS | 4 scenarios: complete interview, incomplete section, adaptive questions, content tracing |
| AC derived from UAT | PASS | 5 AC items derived directly from scenarios |
| Right-sized (1-3 days) | PASS | Agent spec + 4 skills, ~2-3 days effort, 4 scenarios |
| Technical notes | PASS | Agent format, skill dependencies, integration points, session constraint |
| Dependencies tracked | PASS | No blockers; outputs consumed by US-BA-002, US-BA-004 |

### DoR Status: PASSED

---

## US-BA-002: Signal-Based Prospect Research

| DoR Item | Status | Evidence |
|---|---|---|
| Problem statement clear | PASS | Marco's 30-45 min manual research per prospect; 6/8 leads go cold |
| User/persona identified | PASS | Marco Rossi, business development, conferences/events, relationship-builder |
| 3+ domain examples | PASS | 3 examples: full signal research, minimal signals, ICP mismatch |
| UAT scenarios (3-7) | PASS | 3 scenarios: verified signals, low-signal assessment, ICP mismatch |
| AC derived from UAT | PASS | 5 AC items derived from scenarios |
| Right-sized (1-3 days) | PASS | Research capability + 2 skills, ~1-2 days, 3 scenarios |
| Technical notes | PASS | Skill dependencies, ICP integration, constraint (public data only) |
| Dependencies tracked | PASS | Depends on US-BA-001 (ICP definition); outputs feed US-BA-003, US-BA-004 |

### DoR Status: PASSED

---

## US-BA-003: Personalized Outreach Sequence Generation

| DoR Item | Status | Evidence |
|---|---|---|
| Problem statement clear | PASS | Marco's 2-3 hours per email, 5% reply rate, 6/8 leads lost, procrastinates |
| User/persona identified | PASS | Marco Rossi, business development, wants sequences that sound like him |
| 3+ domain examples | PASS | 3 examples: full sequence, low-signal shorter sequence, voice drift |
| UAT scenarios (3-7) | PASS | 5 scenarios: cadence, signals, voice, low-signal, CTA escalation |
| AC derived from UAT | PASS | 6 AC items covering all scenario outcomes |
| Right-sized (1-3 days) | PASS | Sequence generator + 4 skills, ~2-3 days, 5 scenarios |
| Technical notes | PASS | Skill dependencies, integration with US-BA-002, no auto-send constraint |
| Dependencies tracked | PASS | Depends on US-BA-002 (prospect_profile required input) |

### DoR Status: PASSED

---

## US-BA-004: Negotiation Brief with Ackerman Sequence

| DoR Item | Status | Evidence |
|---|---|---|
| Problem statement clear | PASS | Davide's EUR 10,000 loss from poor anchoring, no BATNA preparation |
| User/persona identified | PASS | Davide Conti, consulting lead, architect background, uncomfortable with "sales tactics" |
| 3+ domain examples | PASS | 3 examples: full Ackerman prep, strong prospect BATNA, ethical violation caught |
| UAT scenarios (3-7) | PASS | 4 scenarios: Ackerman calculation, value framing, BATNA analysis, ethical boundary |
| AC derived from UAT | PASS | 6 AC items covering all scenario outcomes |
| Right-sized (1-3 days) | PASS | Negotiation agent + 4 skills, ~2-3 days, 4 scenarios |
| Technical notes | PASS | Skill dependencies, integration with US-BA-001 + US-BA-002, ethical constraint |
| Dependencies tracked | PASS | Depends on US-BA-001 (pricing_model), US-BA-002 (prospect_profile) |

### DoR Status: PASSED

---

## US-BA-005: Proposal Generation from Deal Context

| DoR Item | Status | Evidence |
|---|---|---|
| Problem statement clear | PASS | Davide's 3-5 days per proposal, boilerplate rewriting, inconsistent quality |
| User/persona identified | PASS | Davide Conti, consulting lead, enterprise proposals |
| 3+ domain examples | PASS | 3 examples: full proposal, call modifications, placeholder detection |
| UAT scenarios (3-7) | PASS | 4 scenarios: prospect-specific, pricing alignment, review gate, modifications |
| AC derived from UAT | PASS | 6 AC items derived from scenarios |
| Right-sized (1-3 days) | PASS | Proposal generator + 3 skills, ~2 days, 4 scenarios |
| Technical notes | PASS | Skill dependencies, integration with deal context, no auto-send |
| Dependencies tracked | PASS | Depends on US-BA-004 (deal_profile, negotiation_brief) |

### DoR Status: PASSED

---

## US-BA-006: Post-Deal Learning Capture

| DoR Item | Status | Evidence |
|---|---|---|
| Problem statement clear | PASS | Davide cannot report close rate, no institutional memory, each deal from scratch |
| User/persona identified | PASS | Davide Conti, consulting lead, data-driven improvement |
| 3+ domain examples | PASS | 3 examples: won deal with metrics, lost deal with learning, skipped review |
| UAT scenarios (3-7) | PASS | 3 scenarios: won metrics, lost learning, history informs future |
| AC derived from UAT | PASS | 5 AC items derived from scenarios |
| Right-sized (1-3 days) | PASS | Learning capture + 2 skills, ~1 day, 3 scenarios |
| Technical notes | PASS | Skill dependencies, integration with negotiation brief, local storage constraint |
| Dependencies tracked | PASS | Depends on US-BA-004 (negotiation_brief for comparison) |

### DoR Status: PASSED

---

## US-BA-007: Adversarial Business Review

| DoR Item | Status | Evidence |
|---|---|---|
| Problem statement clear | PASS | Elena's EUR 1,500/15,000 typo near-miss, Marco's wrong case study, self-review fails |
| User/persona identified | PASS | All co-founders, reviewing before prospect-facing send |
| 3+ domain examples | PASS | 3 examples: standard review, quick review, critical violation |
| UAT scenarios (3-7) | PASS | 5 scenarios: auto-detect, ethical block, quick mode, override, critical skip prevention |
| AC derived from UAT | PASS | 7 AC items covering all review modes and resolution flows |
| Right-sized (1-3 days) | PASS | Review agent + 5 skills, ~3 days, 5 scenarios |
| Technical notes | PASS | Skill dependencies, cross-cutting constraint, ethical hard constraint |
| Dependencies tracked | PASS | No blockers; consumes artifacts from all other stories |

### DoR Status: PASSED

---

## US-BA-008: Cross-Agent Data Flow

| DoR Item | Status | Evidence |
|---|---|---|
| Problem statement clear | PASS | Re-entry of data between agents, pricing drift, information lost in handoff |
| User/persona identified | PASS | All co-founders, handing off between business phases |
| 3+ domain examples | PASS | 3 examples: prospect handoff, pricing update, ICP mismatch |
| UAT scenarios (3-7) | PASS | 3 scenarios: prospect transfer, pricing consistency, ICP qualification |
| AC derived from UAT | PASS | 5 AC items covering handoff and consistency |
| Right-sized (1-3 days) | PASS | Integration contracts, ~1-2 days, 3 scenarios |
| Technical notes | PASS | Enabler story, dependency chain documented, reference-by-path constraint |
| Dependencies tracked | PASS | Depends on US-BA-001, US-BA-002, US-BA-004 |

### DoR Status: PASSED

---

## Summary

| Story | DoR Status | Priority | Effort Estimate |
|---|---|---|---|
| US-BA-001: Business Model Discovery | PASSED | Must Have | 2-3 days |
| US-BA-002: Signal-Based Research | PASSED | Must Have | 1-2 days |
| US-BA-003: Outreach Sequence | PASSED | Must Have | 2-3 days |
| US-BA-004: Negotiation Brief | PASSED | Must Have | 2-3 days |
| US-BA-005: Proposal Generation | PASSED | Should Have | 2 days |
| US-BA-006: Post-Deal Learning | PASSED | Should Have | 1 day |
| US-BA-007: Adversarial Review | PASSED | Must Have | 3 days |
| US-BA-008: Cross-Agent Data Flow | PASSED | Must Have | 1-2 days |

**All 8 stories pass DoR. Ready for DESIGN wave handoff.**

### Recommended Build Order
1. US-BA-001 (Business Model Discovery) -- produces ICP and pricing, foundational
2. US-BA-007 (Adversarial Review) -- cross-cutting, needed by all other agents
3. US-BA-002 (Signal-Based Research) -- depends on ICP from US-BA-001
4. US-BA-003 (Outreach Sequence) -- depends on US-BA-002
5. US-BA-008 (Cross-Agent Data Flow) -- integration contracts, enables handoffs
6. US-BA-004 (Negotiation Brief) -- depends on US-BA-001 + US-BA-002
7. US-BA-005 (Proposal Generation) -- depends on US-BA-004
8. US-BA-006 (Post-Deal Learning) -- depends on US-BA-004, lowest priority
