# Journey: Strategic Review Cycle (business-reviewer)

**Job Story**: JS-04 (Strategic Quality Assurance)
**Persona**: All co-founders (Marco, Elena, Davide)
**Emotional Arc**: Uncertain -> Vigilant -> Reassured -> Trusted

---

## Journey Flow

```
[Trigger]              [Step 1]              [Step 2]              [Step 3]
Co-founder produces    Submit artifact       Adversarial           Accept, refine,
a business artifact    for review            review with           or override
(canvas, email,                              specific findings     with justification
proposal, pricing)         |                     |                     |
                           v                     v                     v
                    Select review mode:    Multi-dimension       Co-founder decides:
                    - Quick (ethical +     check: ethical,       fix issues, mark
                      credibility only)    credibility, numbers, as accepted, or
                    - Standard (full)      tone, completeness    override with reason
                    - Deep (+ competitive
                      positioning)

Feels: Uncertain     Feels: Exposed        Feels: Vigilant      Feels: Reassured
       "is this           ("what did I             (constructive         ("safe to send,
       good enough?"       miss?")                  criticism)            or I know why
                                                                          I'm overriding")
```

---

## Step 1: Submit Artifact for Review

**Command**: `/nw:review business [artifact-path]`

**What happens**: Any co-founder submits a business artifact -- Lean Canvas, outreach email, proposal, pricing model, pitch deck outline. They select a review mode based on urgency: Quick (2 checks, < 1 min), Standard (full review, < 5 min), Deep (+ competitive analysis, < 10 min).

```
+-- Step 1: Submit for Review ---------------------------------+
|                                                               |
|  Business Review                                              |
|  ===============                                              |
|                                                               |
|  Artifact: outreach/anna-chen-sequence.md                     |
|  Type: Outreach Sequence (auto-detected)                      |
|  Author: Marco Rossi                                          |
|                                                               |
|  Review mode:                                                 |
|    [1] Quick   -- Ethical + credibility only (< 1 min)        |
|    [2] Standard -- Full review (< 5 min)                      |
|    [3] Deep    -- Full + competitive positioning (< 10 min)   |
|                                                               |
|  Select mode [1/2/3]: 2                                       |
+---------------------------------------------------------------+
```

---

## Step 2: Multi-Dimension Review

**What happens**: The business-reviewer runs checks across multiple dimensions, tailored by artifact type.

### Review Dimensions by Artifact Type

| Dimension | Canvas | Outreach | Proposal | Pricing |
|---|---|---|---|---|
| Ethical boundary | Yes | Yes | Yes | Yes |
| Credibility check | Yes | Yes | Yes | Yes |
| Numerical consistency | Yes | -- | Yes | Yes |
| Tone & voice | -- | Yes | Yes | -- |
| Signal verification | -- | Yes | -- | -- |
| Value justification | -- | -- | Yes | Yes |
| Completeness | Yes | Yes | Yes | Yes |
| Competitive positioning | Deep only | Deep only | Deep only | Deep only |

```
+-- Step 2: Review Results ------------------------------------+
|                                                               |
|  Review: anna-chen-sequence.md (Standard Mode)                |
|  ==============================================               |
|                                                               |
|  Score: 8/10                                                  |
|                                                               |
|  ETHICAL BOUNDARY                                             |
|  [OK] No fabricated testimonials or case studies              |
|  [OK] No false scarcity or manufactured urgency               |
|  [OK] Claims represent genuine value                          |
|  [OK] Opt-out respected (no guilt-trip language)              |
|                                                               |
|  CREDIBILITY CHECK                                            |
|  [OK] "18 months of experience" -- verifiable                 |
|  [!]  "40% improvement" -- source? If internal measurement,   |
|       reframe: "In our own development, we measured..."       |
|  [OK] Series A reference -- publicly available (Crunchbase)   |
|                                                               |
|  TONE & VOICE                                                 |
|  [OK] Conversational, matches Marco's writing style           |
|  [OK] Professional but not corporate                          |
|  [!]  Touch 5 break-up email too passive-aggressive           |
|       Suggest: genuine value-add with open door               |
|                                                               |
|  SIGNAL VERIFICATION                                          |
|  [OK] Series A: confirmed (Crunchbase, 2026-01-15)            |
|  [OK] Hiring surge: confirmed (LinkedIn, 4 open positions)    |
|  [OK] Copilot adoption: confirmed (TechFlow blog, 2025-Q4)   |
|  [OK] Meetup talk: confirmed (Meetup.com, 2026-02-20)         |
|                                                               |
|  COMPLETENESS                                                 |
|  [OK] 5-touch sequence with timing                            |
|  [OK] Multi-channel (email + LinkedIn)                        |
|  [OK] CTA appropriate for each touch                          |
|                                                               |
|  Summary: 2 items to address (credibility, tone)              |
|  Estimated fix time: 5 minutes                                |
+---------------------------------------------------------------+
```

---

## Step 3: Accept, Refine, or Override

**What happens**: The co-founder sees the review results and decides: fix the issues (most common), accept as-is (if review score >= 9), or override with explicit justification (when they disagree with the reviewer's assessment). Overrides are logged -- they're valid but must be conscious decisions, not ignored warnings.

```
+-- Step 3: Review Resolution ---------------------------------+
|                                                               |
|  2 issues found. How to proceed?                              |
|                                                               |
|  Issue 1: "40% improvement" credibility                       |
|    [F] Fix -- reframe to "In our own development..."          |
|    [O] Override -- I have external data to support this       |
|    [S] Skip -- address later                                  |
|                                                               |
|  > F                                                          |
|                                                               |
|  Issue 2: Touch 5 passive-aggressive tone                     |
|    [F] Fix -- rewrite as value-add with open door             |
|    [O] Override -- I think the current tone is appropriate    |
|    [S] Skip -- address later                                  |
|                                                               |
|  > F                                                          |
|                                                               |
|  Applying fixes...                                            |
|                                                               |
|  Updated score: 9/10                                          |
|  Status: APPROVED for sending                                 |
|                                                               |
|  Review log saved to: reviews/anna-chen-sequence-review.md    |
+---------------------------------------------------------------+
```

---

## Integration Checkpoints

| Checkpoint | Validation |
|---|---|
| Any agent -> Review | Artifact path resolves and content is parseable |
| Review -> Fix | Fixes applied to correct locations in original artifact |
| Override -> Log | Override justification recorded (audit trail) |
| Review -> Approve | Score >= 7/10 for approval, >= 9/10 for auto-approve |
