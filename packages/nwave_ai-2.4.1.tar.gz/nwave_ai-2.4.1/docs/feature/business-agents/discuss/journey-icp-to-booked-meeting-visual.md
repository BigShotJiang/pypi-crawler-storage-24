# Journey: From ICP to Booked Meeting (outreach-writer)

**Job Story**: JS-02 (Signal-Based Outreach)
**Persona**: Marco Rossi (Business Development)
**Emotional Arc**: Anxious -> Guided -> Confident -> Relieved

---

## Journey Flow

```
[Trigger]              [Step 1]              [Step 2]              [Step 3]              [Step 4]
Marco meets Anna       Research the          Generate              Review for            Track &
Chen (CTO, 15-dev     prospect using         personalized          reputation            iterate
team) at PyCon and    business signals       outreach sequence     safety                sequence
exchanges cards            |                     |                     |                     |
                           v                     v                     v                     v
                    Signal analysis:       3-5 email sequence    business-reviewer     Send, wait,
                    hiring, funding,       + LinkedIn touches    checks: ethical,      follow up on
                    tech stack, pain       + timing cadence      credible, genuine     cadence
                    indicators

Feels: Anxious       Feels: Curious        Feels: Surprised      Feels: Safe          Feels: Relieved
       "I'll lose          "so that's             ("sounds like           ("no reputation      ("done in 30min,
       this lead"           their pain"            me, not AI")           risk")                not 3 hours")
```

---

## Step 1: Prospect Research

**Command**: `/nw:discover prospect "Anna Chen, TechFlow, CTO"`

**What happens**: The outreach-writer's signal research capability activates. It asks Marco what he knows from the conversation, then builds a prospect profile. It identifies business signals: TechFlow raised Series A 3 months ago, hired 4 engineers in Q1, adopted GitHub Copilot last quarter (visible from job posts and tech blog), Anna spoke about "AI quality challenges" at a local meetup.

**Emotional state**: Marco enters anxious ("I met 8 people and followed up with 2 last time"). The structured research makes him curious -- he didn't know about their Series A or the meetup talk.

```
+-- Step 1: Prospect Research ---------------------------------+
|                                                               |
|  Prospect Profile: Anna Chen, CTO @ TechFlow                 |
|  =============================================                |
|                                                               |
|  Context from Marco:                                          |
|  > Met at PyCon, she complained about AI tools producing      |
|  > inconsistent code quality. Team of 15 developers.          |
|  > Interested in methodology, not just tools.                 |
|                                                               |
|  Business Signals Detected:                                   |
|  [$$] Series A: EUR 4M raised 3 months ago (Crunchbase)       |
|  [++] Hiring surge: 4 engineers in Q1 (LinkedIn jobs)         |
|  [!!] Tech adoption: GitHub Copilot adopted Q4 (tech blog)    |
|  [**] Pain signal: Anna's meetup talk "AI Quality at Scale"   |
|                                                               |
|  Signal Strength: HIGH (4/4 indicators aligned)               |
|                                                               |
|  Inferred pain: Scaling AI-assisted development with          |
|  quality controls. Post-funding growth pressure. Need          |
|  methodology, not more tools.                                 |
|                                                               |
|  Proceed to sequence generation? [Y/n]                        |
+---------------------------------------------------------------+
```

**Shared artifacts produced**:
- `${prospect_profile}` -- name, company, role, signals, inferred pain
- `${signal_analysis}` -- categorized business signals with sources

---

## Step 2: Generate Outreach Sequence

**Command**: (automatic, follows research)

**What happens**: From the prospect profile and signal analysis, the agent generates a personalized multi-touch sequence. It uses PAS (Problem-Agitate-Solution) for the first email, BAB (Before-After-Bridge) for the follow-up, and a "break-up" email for the final touch. Each email references specific signals. Timing is spaced for trust-building (not daily spam).

**Emotional state**: Marco feels surprised -- "This actually sounds like something I would write." The voice-matching is key. The emails reference real signals (the meetup talk, the hiring surge), not generic pain points.

```
+-- Step 2: Generated Outreach Sequence -----------------------+
|                                                               |
|  Sequence: Anna Chen @ TechFlow (5 touches, 14 days)         |
|  ====================================================         |
|                                                               |
|  Touch 1 (Day 0) -- Email: Personal follow-up                |
|  Subject: "Your talk on AI quality -- resonated deeply"       |
|  --------------------------------------------------------     |
|  Anna,                                                        |
|                                                               |
|  Great meeting you at PyCon. Your point about AI tools        |
|  producing inconsistent quality hit close to home -- we       |
|  ran into the exact same wall 18 months ago.                  |
|                                                               |
|  What changed for us was moving from tool-centric to          |
|  methodology-centric AI development. Instead of hoping        |
|  Copilot gets it right, we enforce quality through            |
|  specialized agents with TDD discipline built in.             |
|                                                               |
|  Saw you're scaling the team (congrats on the Series A).      |
|  That's exactly when methodology pays off most -- before      |
|  inconsistency compounds.                                     |
|                                                               |
|  Worth a 20-minute call to compare notes?                     |
|                                                               |
|  Marco                                                        |
|  --------------------------------------------------------     |
|                                                               |
|  Touch 2 (Day 3) -- LinkedIn: Comment on her post             |
|  Touch 3 (Day 7) -- Email: Case insight (PAS framework)       |
|  Touch 4 (Day 10) -- LinkedIn: Share relevant article         |
|  Touch 5 (Day 14) -- Email: Soft close or break-up            |
|                                                               |
|  [Expand touch 2-5? / Edit any touch? / Review all?]         |
+---------------------------------------------------------------+
```

**Shared artifacts produced**:
- `${outreach_sequence}` -- 5-touch sequence with content, timing, channel
- `${email_drafts}` -- full text of each email
- `${linkedin_actions}` -- LinkedIn touch descriptions

---

## Step 3: Reputation Safety Review

**Command**: `/nw:review business` (invokes business-reviewer)

**What happens**: The business-reviewer checks each email against ethical guidelines. Does it represent genuine value? Are claims verifiable? Does it fabricate social proof? Is it signal-based or spray-and-pray? Does the tone match Marco's voice? Is the CTA appropriate (not pushy)?

**Emotional state**: Marco feels safe. The reviewer catches things like "We helped 50+ CTOs" (fabricated -- they haven't yet) and replaces with honest framing. This is the "nothing reaches an inbox without human review" principle.

```
+-- Step 3: Reputation Safety Review --------------------------+
|                                                               |
|  Outreach Review: Anna Chen Sequence                          |
|  ========================================                     |
|                                                               |
|  Overall: 8/10 -- Strong, 2 items to address                 |
|                                                               |
|  [OK] Signal-based: All claims reference verifiable signals   |
|  [OK] Tone: Matches Marco's conversational style              |
|  [OK] CTA: Appropriate ("compare notes" not "buy now")        |
|  [OK] Timing: 14-day cadence, not aggressive                  |
|                                                               |
|  [!] Touch 3: "Our clients typically see 40% improvement"     |
|      -- CREDIBILITY GAP. You don't have enough clients        |
|      for "typically." Suggest: "In our own development,       |
|      we measured a 40% reduction in rework."                  |
|                                                               |
|  [!] Touch 5: Break-up email sounds passive-aggressive.       |
|      Suggest: Reframe as genuine value-add (share a           |
|      resource) with open door, not guilt trip.                |
|                                                               |
|  Ethical check: PASSED (no fabrication, no manipulation)       |
|  Deliverability: SPF/DKIM reminder -- verify before sending   |
|                                                               |
|  Approve for sending? [y/N]                                   |
+---------------------------------------------------------------+
```

**Shared artifacts consumed**:
- `${outreach_sequence}`, `${prospect_profile}` (read for review)

**Shared artifacts produced**:
- `${review_result}` -- pass/fail with specific issues

---

## Step 4: Track & Iterate

**Command**: `/nw:discover prospect "Anna Chen" --status`

**What happens**: Marco sends the approved sequence. The agent tracks which touches have been sent and when. If Anna replies at Touch 2, the sequence adapts. If no reply after Touch 5, the agent suggests a re-engagement strategy for 30 days later (not immediately).

**Emotional state**: Marco feels relieved. The entire process took 30 minutes instead of 3 hours. He has a systematic follow-up cadence instead of ad-hoc guilt-driven emailing.

```
+-- Step 4: Sequence Tracking ---------------------------------+
|                                                               |
|  Sequence Status: Anna Chen @ TechFlow                        |
|  ==========================================                   |
|                                                               |
|  Touch 1  [SENT]     Day 0   Email        Opened: Yes        |
|  Touch 2  [SENT]     Day 3   LinkedIn     Engaged: Yes       |
|  Touch 3  [PENDING]  Day 7   Email        Scheduled           |
|  Touch 4  [QUEUED]   Day 10  LinkedIn     --                  |
|  Touch 5  [QUEUED]   Day 14  Email        --                  |
|                                                               |
|  Signal: Anna liked your LinkedIn comment (Touch 2)           |
|  Recommendation: Proceed with Touch 3 as planned.             |
|  Engagement score: 7/10 (above average)                       |
|                                                               |
|  Reply received? Log it: /nw:discover prospect "Anna Chen"    |
|    --reply "She wants to schedule a call next week"           |
|                                                               |
|  If reply: sequence pauses, shifts to deal-closer prep        |
+---------------------------------------------------------------+
```

---

## Integration Checkpoints

| Checkpoint | Validation |
|---|---|
| ICP -> Research | Prospect matches at least 2 ICP criteria from business-discoverer |
| Research -> Sequence | Every email references at least 1 verified business signal |
| Sequence -> Review | All 5 touches reviewed before any sending |
| Review -> Send | Human explicitly approves each touch (no auto-send) |
| Reply -> Deal | Positive reply triggers deal-closer preparation handoff |
