# Journey: From Meeting to Closed Deal (deal-closer)

**Job Story**: JS-03 (Negotiation Preparation)
**Persona**: Davide Conti (Consulting Lead)
**Emotional Arc**: Nervous -> Prepared -> Grounded -> Proud

---

## Journey Flow

```
[Trigger]              [Step 1]              [Step 2]              [Step 3]              [Step 4]
Anna Chen replies      Build deal            Prepare               Generate              Post-deal
"Let's talk next       context &             negotiation           proposal &            review &
Thursday 3pm"          analyze               brief                 closing               learning
                           |                     |                     |                     |
                           v                     v                     v                     v
                    Gather: prospect        BATNA + ZOPA +        Proposal draft +     Record: what
                    history, budget         Ackerman sequence +   SOW template +       worked, what
                    signals, deal size,     objection scripts +   ROI calculator       to improve
                    decision process        value framing         + ethical review      for next deal

Feels: Nervous       Feels: Focused        Feels: Grounded       Feels: Confident     Feels: Proud
       "don't want          "I can see             "I have a              "this is fair         "I held my
       to blow this"        the full picture"      principled plan"       for both sides"       value"
```

---

## Step 1: Build Deal Context

**Command**: `/nw:discover deal "Anna Chen, TechFlow, training + consulting"`

**What happens**: The deal-closer agent gathers context from the prospect profile (produced by outreach-writer), plus Davide's knowledge of the deal. It maps: decision makers, budget authority, timeline, competition, deal type (training, consulting, or blended). It identifies the decision process (who approves, what procurement looks like at a Series A company).

**Emotional state**: Davide enters nervous ("This is our biggest lead, I don't want to blow it"). The structured context-building makes him focused -- he can see the full picture of the deal landscape.

```
+-- Step 1: Deal Context Analysis -----------------------------+
|                                                               |
|  Deal Profile: TechFlow Training + Consulting                 |
|  =============================================                |
|                                                               |
|  Prospect: Anna Chen, CTO @ TechFlow (15 devs)               |
|  Source: PyCon conference -> outreach sequence (Touch 2 reply) |
|                                                               |
|  Deal Intelligence:                                           |
|  Budget signals: Series A (EUR 4M), hiring 4 engineers        |
|    -> Estimated training budget: EUR 20-50K/year              |
|    -> Decision authority: Anna (CTO) + likely CFO approval    |
|       for > EUR 10K                                           |
|                                                               |
|  Deal structure options:                                      |
|    A. Training only: 2-day workshop, EUR 4-5K                 |
|    B. Training + follow-up: Workshop + 4 coaching sessions    |
|    C. Blended: Workshop + 3-month consulting engagement       |
|                                                               |
|  Competition: Internal training, Copilot documentation,       |
|    generic AI workshops (Coursera/Udemy). No direct           |
|    methodology competitor identified.                         |
|                                                               |
|  Timeline: Q2 (post-hiring, pre-product launch pressure)      |
|                                                               |
|  Decision process: Anna evaluates -> team demo -> CFO sign-off|
+---------------------------------------------------------------+
```

**Shared artifacts produced**:
- `${deal_profile}` -- prospect, budget, timeline, competition, decision process
- `${deal_options}` -- structured deal alternatives (A/B/C)

---

## Step 2: Prepare Negotiation Brief

**Command**: `/nw:discover deal "Anna Chen" --negotiate`

**What happens**: The deal-closer builds a principled negotiation brief. It calculates: Davide's BATNA (walk-away point), Anna's likely BATNA (alternatives she has), the ZOPA (zone of possible agreement), and an Ackerman bargaining sequence. It generates value-framing scripts that shift conversation from "What's your daily rate?" to "What's the cost of 15 engineers producing inconsistent quality for 6 more months?"

**Emotional state**: Davide feels grounded. The brief frames negotiation as principled (Fisher & Ury), not manipulative. The Ackerman sequence gives him concrete numbers, not vague guidance. He knows his walk-away point before entering the room.

```
+-- Step 2: Negotiation Brief ---------------------------------+
|                                                               |
|  Negotiation Preparation: TechFlow Deal                       |
|  ===========================================                  |
|                                                               |
|  YOUR BATNA (walk-away):                                      |
|  Minimum viable deal: EUR 4,000 (2-day workshop, cost-only)   |
|  Below this, opportunity cost exceeds revenue.                |
|                                                               |
|  THEIR BATNA (alternatives):                                  |
|  - Internal training: Free but unstructured, 3-6 month lag    |
|  - Generic AI course: EUR 500/person but no methodology       |
|  - Do nothing: Continue inconsistent quality (growing cost)   |
|  Assessment: Weak BATNA. No direct competitor for methodology.|
|                                                               |
|  ZOPA: EUR 4,000 -- EUR 25,000 (blended package)              |
|                                                               |
|  ACKERMAN SEQUENCE (for Blended package, target EUR 20,000):  |
|  +---------+----------+----------------------------------+    |
|  | Round   | Offer    | Framing                          |    |
|  |---------|----------|----------------------------------|    |
|  | Anchor  | EUR 28,000 | "Our standard blended engagement  |    |
|  |         |          | for teams your size"              |    |
|  | R1 (85%)| EUR 23,800 | After listening to their concerns |    |
|  | R2 (95%)| EUR 21,300 | Include a concession (extra      |    |
|  |         |          | coaching session)                 |    |
|  | R3 (100)| EUR 20,000 | Final, precise, with non-monetary |    |
|  |         |          | add (async Slack support 30 days) |    |
|  +---------+----------+----------------------------------+    |
|                                                               |
|  VALUE FRAMING SCRIPT:                                        |
|  "If 15 engineers lose 2 hours/week to AI quality rework,     |
|  that's 1,560 hours/year -- roughly EUR 125,000 in            |
|  engineering time. Our engagement costs EUR 20,000 and         |
|  targets a 50% reduction in rework within 3 months."          |
|                                                               |
|  OBJECTION SCRIPTS:                                           |
|  "That's expensive" -> [See value frame above]                |
|  "We can train internally" -> "What's the timeline for that?  |
|    Your Series A investors expect velocity in Q2-Q3."         |
|  "Can you do a trial?" -> "Absolutely. The 2-day workshop     |
|    stands alone. Think of it as a test drive."                |
|                                                               |
|  ETHICAL BOUNDARY:                                            |
|  [OK] All claims verifiable (rework estimate from industry)   |
|  [OK] No false scarcity or manufactured urgency               |
|  [OK] Trial option offered genuinely                          |
+---------------------------------------------------------------+
```

**Shared artifacts produced**:
- `${negotiation_brief}` -- BATNA, ZOPA, Ackerman sequence
- `${value_framing}` -- ROI calculation and framing scripts
- `${objection_scripts}` -- anticipated objections with responses

---

## Step 3: Generate Proposal & Close

**Command**: `/nw:discover deal "Anna Chen" --proposal`

**What happens**: After the call (assuming it went well), the deal-closer generates a proposal document. It follows the Challenge-Solution-Impact structure. It includes: executive summary, the problem (specific to TechFlow), the solution (specific package), pricing, timeline, and terms. The business-reviewer checks it before sending.

**Emotional state**: Davide feels confident. The proposal is specific to TechFlow (not boilerplate), the pricing is justified by value (not arbitrary), and the ethical review passed.

```
+-- Step 3: Proposal Generation --------------------------------+
|                                                               |
|  Proposal: nWave Training & Consulting for TechFlow           |
|  ==================================================           |
|                                                               |
|  EXECUTIVE SUMMARY                                            |
|  TechFlow's 15-person engineering team adopted AI coding       |
|  tools in Q4 but lacks a quality methodology. With 4 new      |
|  engineers joining in Q1, inconsistency risk compounds.        |
|  We propose a blended engagement: 2-day intensive workshop    |
|  + 3-month consulting retainer to establish nWave             |
|  methodology as TechFlow's standard.                          |
|                                                               |
|  THE CHALLENGE (specific to TechFlow)                         |
|  - 15 engineers, 4 new hires, no shared AI methodology        |
|  - GitHub Copilot adopted but producing inconsistent quality  |
|  - Product launch pressure in Q3 demands velocity + quality   |
|                                                               |
|  THE SOLUTION                                                 |
|  Phase 1: 2-day workshop (all 15 engineers)                   |
|  Phase 2: 4x bi-weekly coaching sessions (team leads)         |
|  Phase 3: 3-month async support + methodology audit           |
|                                                               |
|  INVESTMENT: EUR 20,000                                       |
|  EXPECTED ROI: 50% reduction in AI-related rework             |
|    = ~EUR 62,500 annual savings (conservative)                |
|    = 3.1x return in first year                                |
|                                                               |
|  Review status: [Pending business-reviewer check]             |
|                                                               |
|  [Review now? / Edit? / Export PDF?]                          |
+---------------------------------------------------------------+
```

**Shared artifacts produced**:
- `${proposal}` -- full proposal document
- `${roi_calculation}` -- detailed ROI model

---

## Step 4: Post-Deal Review & Learning

**Command**: `/nw:discover deal "Anna Chen" --close won|lost`

**What happens**: Win or lose, Davide records the outcome. The agent captures: what worked, what didn't, how the Ackerman sequence played out, which objection scripts were used, final deal value vs target. This feeds back into the system for future deals.

**Emotional state**: Davide feels proud -- he held his value and closed at EUR 18,500 (vs his historical EUR 15,000 for similar deals). The post-deal review reinforces learning.

```
+-- Step 4: Post-Deal Review ----------------------------------+
|                                                               |
|  Deal Outcome: TechFlow -- WON                                |
|  ==============================                               |
|                                                               |
|  Target:  EUR 20,000                                          |
|  Closed:  EUR 18,500 (92.5% of target)                        |
|  Previous comparable: EUR 15,000 (+23% improvement)            |
|                                                               |
|  Ackerman sequence: Anchored at EUR 28,000. Anna countered    |
|  at EUR 15,000. Used R1 (EUR 23,800) with value frame.        |
|  Settled at EUR 18,500 with added concession (extra           |
|  coaching session).                                           |
|                                                               |
|  What worked:                                                 |
|  - Value framing shifted conversation from rate to ROI        |
|  - "Trial" option (standalone workshop) reduced risk          |
|  - Specific TechFlow data made proposal credible              |
|                                                               |
|  What to improve:                                             |
|  - R1 drop was too large (28K -> 23.8K). Next time, R1 = 90% |
|  - Should have asked about budget range earlier               |
|                                                               |
|  Learning captured for future deals.                          |
+---------------------------------------------------------------+
```

---

## Integration Checkpoints

| Checkpoint | Validation |
|---|---|
| Outreach -> Deal | Prospect profile transfers from outreach-writer output |
| Context -> Negotiation | All deal options have corresponding BATNA analysis |
| Negotiation -> Proposal | Proposal pricing matches Ackerman target (not arbitrary) |
| Proposal -> Review | Business-reviewer checks before any client-facing send |
| Close -> Learning | Win or lose, outcome captured with learning for future |
