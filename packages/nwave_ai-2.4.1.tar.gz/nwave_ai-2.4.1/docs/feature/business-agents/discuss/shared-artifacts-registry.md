# Shared Artifacts Registry: Business Agents

**Feature**: business-agents
**Date**: 2026-03-04

---

## Cross-Agent Artifact Flow

```
business-discoverer                outreach-writer               deal-closer
       |                                  |                           |
       v                                  v                           v
  icp_definition  -------->  prospect qualification         pricing reference
  pricing_model   -------->  .......................  -----> deal options
  lean_canvas     -------->  company context                value framing
       |                          |                           |
       +----------+---------------+---------------------------+
                  |
                  v
          business-reviewer
          (reviews all artifacts)
```

---

## Artifact Registry

### icp_definition

- **Source of truth**: business-discoverer interview output
- **Consumers**: outreach-writer (prospect qualification), deal-closer (deal context), alignment export
- **Owner**: business-discoverer agent
- **Integration risk**: HIGH -- ICP mismatch means outreach targets wrong prospects
- **Validation**: Prospect qualification in outreach-writer must use same criteria defined in ICP

### pricing_model

- **Source of truth**: business-discoverer generated pricing (Good/Better/Best tiers)
- **Consumers**: deal-closer (Ackerman target calibration, deal options), business-reviewer (numerical consistency), alignment export
- **Owner**: business-discoverer agent
- **Integration risk**: HIGH -- pricing inconsistency across agents destroys credibility
- **Validation**: Deal-closer deal options must reference tiers from pricing model. Proposal prices must trace to agreed negotiation outcome.

### lean_canvas

- **Source of truth**: business-discoverer generated canvas
- **Consumers**: outreach-writer (company context for personalization), business-reviewer, alignment export
- **Owner**: business-discoverer agent
- **Integration risk**: MEDIUM -- canvas informs messaging but is not client-facing
- **Validation**: Value propositions in outreach emails should be consistent with canvas UVP

### prospect_profile

- **Source of truth**: outreach-writer research step
- **Consumers**: outreach sequence generation, business-reviewer (signal verification), deal-closer (deal context)
- **Owner**: outreach-writer agent
- **Integration risk**: HIGH -- prospect data must transfer cleanly from outreach to deal phase
- **Validation**: Deal-closer must inherit all prospect data without re-entry

### signal_analysis

- **Source of truth**: outreach-writer research step
- **Consumers**: outreach sequence (email personalization), business-reviewer (signal verification)
- **Owner**: outreach-writer agent
- **Integration risk**: HIGH -- unverified signals in emails damage reputation
- **Validation**: Every signal referenced in an email must have a source in signal_analysis

### outreach_sequence

- **Source of truth**: outreach-writer generation step
- **Consumers**: business-reviewer, sequence tracker, deal-closer (engagement history)
- **Owner**: outreach-writer agent
- **Integration risk**: MEDIUM -- sequence state must be consistent between writer and tracker
- **Validation**: Reviewer must see all touches, not just first email

### negotiation_brief

- **Source of truth**: deal-closer analysis
- **Consumers**: pre-call preparation, post-deal review (effectiveness tracking)
- **Owner**: deal-closer agent
- **Integration risk**: MEDIUM -- brief informs negotiation but is not client-facing
- **Validation**: Ackerman sequence must reference pricing_model tiers

### proposal

- **Source of truth**: deal-closer generation
- **Consumers**: business-reviewer (pre-send review), client delivery
- **Owner**: deal-closer agent
- **Integration risk**: HIGH -- client-facing artifact, errors damage reputation
- **Validation**: Pricing matches negotiation outcome. ROI calculation is mathematically correct. All claims verifiable.

### review_findings

- **Source of truth**: business-reviewer analysis
- **Consumers**: fix resolution step, review log, audit trail
- **Owner**: business-reviewer agent
- **Integration risk**: LOW -- internal quality artifact
- **Validation**: Findings in resolution step must match those from review step

### deal_outcome

- **Source of truth**: user input post-negotiation
- **Consumers**: deal learning database, future BATNA calibration
- **Owner**: deal-closer agent
- **Integration risk**: LOW -- historical data, not client-facing
- **Validation**: Outcome amount recorded consistently with proposal pricing

---

## Integration Checkpoints Summary

| Checkpoint | From | To | Validation |
|---|---|---|---|
| ICP -> Prospect Qualification | business-discoverer | outreach-writer | Prospect matches >= 2 ICP criteria |
| Pricing -> Deal Options | business-discoverer | deal-closer | Deal options reference pricing model tiers |
| Prospect -> Deal Context | outreach-writer | deal-closer | Full profile transfers without re-entry |
| Signals -> Emails | outreach-writer research | outreach-writer generation | Every email signal has verified source |
| Any artifact -> Review | any agent | business-reviewer | Artifact path resolves, type detected |
| Review -> Approval | business-reviewer | sending/export | Score >= 7/10 for approval |
| Negotiation -> Proposal | deal-closer negotiation | deal-closer proposal | Pricing matches agreed outcome |
| Proposal -> Client | deal-closer | client delivery | business-reviewer approval required |

---

## Risk Assessment

| Risk | Probability | Impact | Mitigation |
|---|---|---|---|
| ICP drift (agents use different customer definitions) | Medium | High | Single source in business-discoverer, referenced by others |
| Pricing inconsistency across artifacts | Medium | High | pricing_model is single source, all agents reference it |
| Unverified signal in outreach email | Low | Critical | business-reviewer signal verification step |
| Stale prospect data in deal context | Low | Medium | Timestamp on prospect profile, refresh prompt if > 30 days |
| Fabricated claim in proposal | Low | Critical | Ethical boundary check in business-reviewer, mandatory pre-send |
