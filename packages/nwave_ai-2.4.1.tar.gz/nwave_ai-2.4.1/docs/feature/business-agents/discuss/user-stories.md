<!-- markdownlint-disable MD024 -->

# User Stories: Business Agents

**Feature**: business-agents
**Date**: 2026-03-04
**Analyst**: Luna (nw-product-owner)

---

## US-BA-001: Business Model Discovery Interview

### Problem
Elena Ferrara is a training lead at a 3-person consultancy who has deep business knowledge locked in her head. She finds it exhausting to articulate the business model on the fly -- last week she pitched differently to two potential partners because she had no shared reference. Her co-founders quote different prices to similar companies.

### Who
- Co-founder (Elena) | Designing training offerings and pricing | Wants structured business artifacts for alignment

### Solution
A structured interview agent that extracts tacit business knowledge through 9 Lean Canvas sections and generates populated canvases, ICP definition, and pricing model.

### Domain Examples
#### 1: Happy Path -- Elena builds nWave business model
Elena starts `/nw:discover business-model`. The agent asks "Who is your ideal customer?" Elena responds "Startup CTOs with 5-20 person dev teams frustrated with AI quality." The agent probes deeper: budget authority, discovery channels, trigger events. After 9 sections (30-45 minutes), all Lean Canvas sections are populated. A Lean Canvas, Value Proposition Canvas, ICP, and Good/Better/Best pricing model are generated.

#### 2: Edge Case -- Elena's answers are vague for one section
Elena answers 8 of 9 sections clearly but gives a vague answer for "Unfair Advantage" ("We're just better"). The agent flags this as insufficient, offers probing questions ("What can you do that competitors cannot replicate within 18 months?"), and does not proceed to canvas generation until the section has substantive content.

#### 3: Error -- Elena disagrees with generated pricing tiers
The generated pricing model shows training at EUR 5,000/day (Good) and EUR 12,000/day (Best). Elena thinks the Best tier is too high for Phase 1 market. She can edit the tiers directly, and the agent explains the value-based pricing rationale while accepting her override.

### UAT Scenarios (BDD)

#### Scenario: Complete interview produces 4 artifacts
Given Elena starts a business model discovery session
When she answers all 9 Lean Canvas sections with substantive responses
Then a populated Lean Canvas is generated with all 9 sections
And a Value Proposition Canvas with customer jobs, pains, and gains is generated
And an Ideal Customer Profile with demographic and psychographic criteria is generated
And a Good/Better/Best pricing model with 3 tiers is generated

#### Scenario: Incomplete section blocks generation
Given Elena has answered 8 of 9 sections
And the "Unfair Advantage" section answer is "We're just better"
When Elena requests canvas generation
Then the agent flags the vague section
And offers specific probing questions
And does not generate canvases until the section is substantively addressed

#### Scenario: Interview adapts questions to previous answers
Given Elena identified her customer as "Startup CTOs, 5-20 devs"
When the agent asks follow-up questions
Then questions reference the specific segment mentioned
And probe budget authority, discovery channels, and trigger events
And do not repeat previously answered topics

#### Scenario: Generated content traces to interview answers
Given Elena said "Conference talks are our main channel"
When the Lean Canvas is generated
Then the Channels section includes "Conference talks"
And does not include channels Elena did not mention

### Acceptance Criteria
- [ ] All 9 Lean Canvas sections have corresponding interview questions
- [ ] Vague answers are flagged with probing follow-up questions
- [ ] 4 artifacts generated: Lean Canvas, Value Prop Canvas, ICP, Pricing Model
- [ ] All generated content traces to specific interview answers
- [ ] Interview adapts questions based on previous answers

### Technical Notes
- Agent specification: YAML frontmatter + markdown (nWave agent format)
- Skills needed: lean-canvas-interview, value-prop-canvas, pricing-design, icp-builder
- Integration: outputs consumed by outreach-writer (ICP) and deal-closer (pricing)
- Constraint: interview must work in single session (no multi-session state required for MVP)

### Traceability
- **Job Story**: JS-01 (Business Model Articulation)
- **Opportunity Score**: 16.5 (Extremely Underserved)
- **Priority**: Must Have

---

## US-BA-002: Signal-Based Prospect Research

### Problem
Marco Rossi is a co-founder who meets 8-10 promising leads at each conference. He follows up with 2-3 (the ones he has time for) and the rest go cold. Each follow-up starts with research he does manually -- Googling the company, checking LinkedIn, reading their blog -- which takes 30-45 minutes per prospect before he even writes the email.

### Who
- Co-founder (Marco) | Business development through conferences and events | Wants research done for him so he can focus on relationship-building

### Solution
An automated prospect research capability that takes a name/company/context and returns a structured profile with verified business signals, inferred pain points, and ICP qualification score.

### Domain Examples
#### 1: Happy Path -- Research Anna Chen at TechFlow
Marco inputs "Anna Chen, CTO at TechFlow, met at PyCon, complained about AI quality." The agent returns: Series A (EUR 4M, 3 months ago), hiring surge (4 engineers Q1), GitHub Copilot adopted Q4, Anna's meetup talk on "AI Quality at Scale." Signal strength: HIGH (4/4 aligned). ICP match: HIGH (CTO, 15 devs, Series A).

#### 2: Edge Case -- Minimal public information
Marco inputs "Luca Bianchi, VP Engineering at SteadyBuild." The agent finds limited signals: no recent funding, no blog, LinkedIn shows 8 engineers. Signal strength: LOW (1/4). The agent notes the limitations and suggests Marco gather more context from direct conversation before investing in a full sequence.

#### 3: Error -- Prospect does not match ICP
Marco inputs "Sarah Kim, CTO at MegaCorp (2,000 engineers)." The agent notes MegaCorp is Phase 3 market (large enterprise), not Phase 1 (startup CTO, 5-20 devs). ICP match: LOW. The agent recommends deferring or adjusting approach for enterprise context.

### UAT Scenarios (BDD)

#### Scenario: Research surfaces verified business signals
Given Marco inputs "Anna Chen, CTO at TechFlow" with context from PyCon
When the outreach-writer researches the prospect
Then the profile includes at least 2 business signals with source attributions
And an inferred pain statement connects signals to the conversation context
And the signal strength is rated HIGH/MEDIUM/LOW

#### Scenario: Low-signal prospect gets honest assessment
Given Marco inputs a prospect with minimal public presence
When the outreach-writer researches the prospect
Then the profile notes the limited available signals
And signal strength is rated LOW
And the agent suggests gathering more context before committing to a full sequence

#### Scenario: ICP mismatch flagged transparently
Given Marco inputs a prospect whose company has 2,000 engineers
And the ICP defines target as 5-20 person dev teams
When the prospect is evaluated against ICP criteria
Then the mismatch is flagged with specific criteria that failed
And the agent suggests deferring or adjusting approach

### Acceptance Criteria
- [ ] Research returns structured prospect profile with name, company, role, signals, inferred pain
- [ ] Each signal has a source attribution (verifiable)
- [ ] Signal strength rated as HIGH/MEDIUM/LOW
- [ ] Prospect is qualified against ICP criteria from business-discoverer
- [ ] Low-signal and ICP-mismatch prospects get honest assessment (not forced into sequence)

### Technical Notes
- Skill needed: prospect-research, signal-analysis
- Integration: ICP criteria sourced from business-discoverer output
- Integration: prospect profile consumed by outreach sequence generator and deal-closer
- Constraint: signal research is based on publicly available information only (no scraping private data)

### Traceability
- **Job Story**: JS-02 (Signal-Based Outreach)
- **Opportunity Score**: 14.5 (Underserved)
- **Priority**: Must Have

---

## US-BA-003: Personalized Outreach Sequence Generation

### Problem
Marco Rossi spends 2-3 hours crafting each outreach email, second-guessing the tone. His current reply rate is approximately 5%. Meanwhile, 6 of 8 conference leads go cold because he cannot follow up fast enough. He procrastinates on follow-up because it feels salesy.

### Who
- Co-founder (Marco) | Generating outreach from warm leads | Wants sequences that sound like him, not a sales robot

### Solution
A sequence generator that takes a prospect profile with verified signals and produces a 3-5 touch multi-channel outreach sequence (email + LinkedIn) with personalized content, voice matching, and proper trust-building cadence.

### Domain Examples
#### 1: Happy Path -- Sequence for Anna Chen
From Anna Chen's prospect profile (4 verified signals), the agent generates a 5-touch, 14-day sequence. Touch 1: personal PyCon follow-up email referencing her AI quality concerns and TechFlow's hiring surge. Touch 2: LinkedIn comment on her post. Touch 3: PAS-framework email about methodology vs tools. Touch 4: Share relevant article on LinkedIn. Touch 5: soft close or break-up with value-add.

#### 2: Edge Case -- Low-signal prospect gets shorter sequence
Luca Bianchi has only 1 verified signal (hiring 3 engineers). The agent generates a 3-touch, 10-day sequence instead of 5 touches. The emails are less specific (no funding or tech adoption to reference) but still personalized with the conversation context Marco provided.

#### 3: Error -- Voice drift detected
The agent generates an email that includes "We'd love to leverage synergies between our organizations." Marco's writing style is conversational and technical, not corporate. The agent flags the voice drift during generation and rewrites in Marco's natural style.

### UAT Scenarios (BDD)

#### Scenario: Multi-touch sequence with proper cadence
Given Anna Chen's prospect profile has 4 verified signals
When the outreach-writer generates an outreach sequence
Then the sequence contains 3-5 touches across email and LinkedIn
And the sequence spans at least 10 days
And no two touches are on consecutive days

#### Scenario: Each email references verified signals
Given the prospect profile includes 4 signals (funding, hiring, tech adoption, pain)
When all email touches are generated
Then each email references at least 1 specific verified signal
And no email references signals that were not verified in research

#### Scenario: Voice matches author's conversational style
Given Marco's writing style is conversational and technical
When the outreach emails are generated
Then emails use first-person singular ("I" not "we at nWave")
And avoid corporate jargon
And include technical vocabulary appropriate for CTO audience

#### Scenario: Low-signal prospect gets proportionally shorter sequence
Given a prospect with only 1 verified signal
When the outreach-writer generates a sequence
Then the sequence contains 3 touches (not 5)
And the emails acknowledge limited context honestly

#### Scenario: CTA escalates appropriately across sequence
Given a 5-touch sequence is generated
When the CTAs are reviewed across all touches
Then Touch 1 has a low-commitment CTA ("compare notes")
And later touches progressively increase commitment
And the final touch offers value with open door (not guilt)

### Acceptance Criteria
- [ ] Sequence contains 3-5 touches across email and LinkedIn channels
- [ ] Cadence spans at least 10 days with no consecutive-day touches
- [ ] Each email references at least 1 verified business signal
- [ ] Voice matches author's natural writing style (no corporate jargon)
- [ ] CTA escalation is progressive and appropriate
- [ ] Low-signal prospects get proportionally shorter sequences

### Technical Notes
- Skills needed: outreach-sequence-design, pas-framework, bab-framework, voice-matching
- Integration: prospect_profile from US-BA-002 is required input
- Integration: outreach_sequence consumed by business-reviewer (US-BA-007)
- Constraint: no auto-send capability; all sends are human-initiated

### Traceability
- **Job Story**: JS-02 (Signal-Based Outreach)
- **Opportunity Score**: 15.5 (Extremely Underserved, reputation safety)
- **Priority**: Must Have

---

## US-BA-004: Negotiation Brief with Ackerman Sequence

### Problem
Davide Conti goes into pricing negotiations without structured preparation. Last quarter he quoted EUR 15,000 for a 3-month consulting engagement that should have been EUR 25,000. He anchored low because he had no BATNA analysis. In another negotiation, a CTO asked "What's your daily rate?" and Davide answered first -- a classic anchoring mistake that cost him leverage.

### Who
- Co-founder (Davide) | Enterprise deal negotiation | Wants principled strategy with concrete numbers, not manipulation

### Solution
A negotiation preparation agent that generates a BATNA analysis (both sides), ZOPA calculation, Ackerman bargaining sequence with framing rationales, value-framing scripts (ROI-based), and objection-handling scripts -- all grounded in principled negotiation (Fisher & Ury), not manipulation.

### Domain Examples
#### 1: Happy Path -- Prepare for TechFlow negotiation
Davide sets target EUR 20,000 for blended package. The agent calculates: his BATNA (EUR 4,000 minimum), Anna's BATNA (weak -- no direct competitor), ZOPA (EUR 4,000-25,000). Ackerman: anchor EUR 28,000, R1 EUR 23,800, R2 EUR 21,300, R3 EUR 20,000 with non-monetary concession (30 days Slack support). Value frame: "15 engineers x 2h rework/week = EUR 125,000/year. Investment: EUR 20,000. ROI: 3.1x."

#### 2: Edge Case -- Prospect has strong BATNA
Davide prepares for a prospect whose internal L&D team has AI training capability. The agent notes: "Prospect BATNA is strong -- they can train internally at low marginal cost. Your differentiation must focus on methodology quality and time-to-value, not cost savings. Consider offering a pilot workshop to prove value before committing to full engagement."

#### 3: Error -- Ethically questionable tactic suggested
The agent generates an objection script that includes "Your competitor just signed with us" (fabricated). The ethical boundary check catches this before it reaches Davide's brief, flags it as CRITICAL, and rewrites using honest competitive positioning.

### UAT Scenarios (BDD)

#### Scenario: Ackerman sequence from target price
Given Davide sets a target price of EUR 20,000 for the blended package
When the deal-closer generates the Ackerman sequence
Then the anchor is approximately 130-150% of target
And Round 1 is approximately 85% of anchor
And Round 2 is approximately 95% of target
And Round 3 equals the target price exactly
And each round includes a framing rationale and concession

#### Scenario: Value framing quantifies cost of inaction
Given TechFlow has 15 engineers with estimated 2 hours/week AI rework
When the deal-closer generates value framing
Then the annual cost of inaction is calculated (approximately EUR 125,000)
And the ROI is displayed as a multiple
And the calculation is transparent and verifiable

#### Scenario: BATNA covers both sides
Given Davide's walk-away is EUR 4,000 (cost-only)
When the deal-closer generates BATNA analysis
Then Davide's BATNA is documented with rationale
And the prospect's alternatives are listed with strength assessment
And the overall BATNA balance is summarized

#### Scenario: Ethical boundary prevents fabricated claims
Given the negotiation brief includes objection scripts
When the ethical boundary check runs
Then no script uses false information
And no script manufactures urgency or scarcity
And fabricated competitive claims are caught and rewritten

### Acceptance Criteria
- [ ] BATNA analysis covers both sides with rationale
- [ ] Ackerman sequence follows 65/85/95/100 pattern with framing per round
- [ ] Value framing shows transparent ROI calculation
- [ ] At least 3 objection-response pairs generated
- [ ] Ethical boundary check passes (no fabrication, no manipulation)
- [ ] Brief is usable as pre-call preparation document

### Technical Notes
- Skills needed: principled-negotiation, ackerman-bargaining, value-framing, roi-calculator
- Integration: deal_profile from prospect_profile (US-BA-002) + pricing_model (US-BA-001)
- Integration: negotiation_brief consumed by proposal generator and post-deal review
- Constraint: all negotiation tactics must pass Fisher & Ury ethical test (mutual value creation)

### Traceability
- **Job Story**: JS-03 (Negotiation Preparation)
- **Opportunity Score**: 14.5 (Underserved)
- **Priority**: Must Have

---

## US-BA-005: Proposal Generation from Deal Context

### Problem
Davide Conti spends 3-5 days writing each proposal, mostly rewriting boilerplate. Every proposal starts from scratch because he has no template system. The result is inconsistent quality -- sometimes he includes ROI calculations, sometimes he forgets. The delay between "yes, let's proceed" and "here's the proposal" loses momentum.

### Who
- Co-founder (Davide) | Generating enterprise proposals | Wants prospect-specific proposals in hours, not days

### Solution
A proposal generator that takes deal context (prospect profile, agreed terms, negotiation outcome) and produces a Challenge-Solution-Impact proposal with prospect-specific data, ROI calculation, and timeline -- requiring business-reviewer approval before client delivery.

### Domain Examples
#### 1: Happy Path -- TechFlow proposal
After a successful call, Davide requests a proposal. The agent generates: Executive Summary (TechFlow-specific), Challenge (15 engineers, AI quality, Q3 pressure), Solution (3 phases: workshop, coaching, retainer), Investment (EUR 18,500 per agreement), ROI (3.4x first-year return), Timeline (Q2 start). All sections use TechFlow-specific data.

#### 2: Edge Case -- Prospect requested modifications during call
Anna asked for the workshop to include a hands-on project with their actual codebase. Davide logs this modification. The proposal generator includes it in Phase 1 scope and adjusts timeline accordingly.

#### 3: Error -- Proposal has placeholder text
The generator fails to replace "[Company Name]" in the executive summary. The business-reviewer catches the placeholder during pre-send review and blocks approval until it's fixed.

### UAT Scenarios (BDD)

#### Scenario: Proposal is prospect-specific
Given deal context for TechFlow with agreed terms
When the proposal is generated
Then the executive summary references TechFlow by name
And the challenge section includes TechFlow data (15 engineers, Series A, Q3 pressure)
And no generic placeholder text remains

#### Scenario: Proposal pricing matches negotiation outcome
Given Davide and Anna agreed on EUR 18,500
When the proposal is generated
Then the investment section shows EUR 18,500
And the ROI calculation uses the agreed price
And payment terms are included

#### Scenario: Business review required before sending
Given a proposal is generated for TechFlow
When the proposal is marked as ready
Then it routes to business-reviewer automatically
And cannot be exported until review score >= 7/10

#### Scenario: Call modifications reflected in proposal
Given Anna requested hands-on work with TechFlow's codebase
And Davide logged this modification
When the proposal is generated
Then Phase 1 scope includes the hands-on project
And timeline reflects the additional scope

### Acceptance Criteria
- [ ] Proposal follows Challenge-Solution-Impact structure
- [ ] All sections use prospect-specific data (no placeholders)
- [ ] Pricing matches negotiation outcome exactly
- [ ] ROI calculation is mathematically correct and transparent
- [ ] Business-reviewer approval required before client delivery
- [ ] Call-specific modifications are reflected in proposal

### Technical Notes
- Skills needed: proposal-design, roi-calculator, challenge-solution-impact
- Integration: deal_profile + negotiation_brief required as inputs
- Integration: proposal consumed by business-reviewer before client send
- Constraint: no auto-send; human reviews final output before delivery

### Traceability
- **Job Story**: JS-03 (Negotiation Preparation)
- **Opportunity Score**: 11.5 (Appropriately Served)
- **Priority**: Should Have

---

## US-BA-006: Post-Deal Learning Capture

### Problem
Davide Conti has no systematic way to learn from deals. He closed 5 deals last year but cannot tell you his average close rate vs target, which objection scripts worked, or why he lost the deals he lost. Each negotiation starts from scratch without institutional memory.

### Who
- Co-founder (Davide) | Improving deal effectiveness over time | Wants data-driven improvement, not gut feel

### Solution
A post-deal recording system that captures outcome (won/lost), pricing (target vs actual), Ackerman effectiveness, what worked, what to improve, and loss reasons -- feeding back into future deal preparations.

### Domain Examples
#### 1: Happy Path -- Won deal at 92.5% of target
Davide closes TechFlow at EUR 18,500 against EUR 20,000 target. He logs: outcome=won, Ackerman anchor at EUR 28,000 was effective, value framing shifted the conversation, trial option reduced risk. The system notes +23% improvement over his previous comparable deal (EUR 15,000).

#### 2: Edge Case -- Lost deal with learning
Davide loses a deal because the prospect chose internal training. He logs: outcome=lost, reason="internal training capability." The system suggests: "Internal training BATNA was underestimated. For similar prospects, probe internal capability earlier."

#### 3: Error -- Davide skips post-deal review
Davide is busy and tries to skip the review for a small deal. The system gently prompts ("Capturing this 2-minute review improves your next negotiation. Log outcome?") but allows skip -- it's not blocking.

### UAT Scenarios (BDD)

#### Scenario: Won deal records effectiveness metrics
Given Davide closes TechFlow at EUR 18,500 against EUR 20,000 target
When he logs the outcome as won
Then the system records closed price, target, and percentage (92.5%)
And compares to previous comparable deals
And captures which tactics worked and improvements for next time

#### Scenario: Lost deal captures constructive learning
Given Davide loses a deal (prospect chose internal training)
When he logs the outcome as lost with reason
Then the system records the loss reason
And suggests adjustments to BATNA analysis for similar prospects
And the tone is constructive, not blame-oriented

#### Scenario: Deal history informs future negotiations
Given Davide has logged 5 deals with 88% average target achievement
When the deal-closer prepares a new negotiation brief
Then the BATNA analysis references historical close rates
And the Ackerman anchor is calibrated using historical data

### Acceptance Criteria
- [ ] Won and lost outcomes both capturable with structured data
- [ ] Target vs actual comparison calculated automatically
- [ ] Loss reasons captured with constructive improvement suggestions
- [ ] Historical data available for future deal preparations
- [ ] Post-deal review is encouraged but not blocking

### Technical Notes
- Skills needed: deal-outcome-capture, learning-loop
- Integration: negotiation_brief consumed for comparison; outcome feeds future preparations
- Constraint: deal data stored locally (no external CRM integration for MVP)

### Traceability
- **Job Story**: JS-03 (Negotiation Preparation)
- **Opportunity Score**: 13.5 (Underserved, via preparation improvement)
- **Priority**: Should Have

---

## US-BA-007: Adversarial Business Review

### Problem
Elena Ferrara nearly sent a proposal with EUR 1,500 instead of EUR 15,000 (typo caught last minute). Marco's outreach email claimed a case study from the wrong company. Davide's pricing was inconsistent between his canvas and his proposal. Each co-founder self-reviews, which misses blind spots. There is no systematic second pair of eyes.

### Who
- All co-founders | Reviewing business artifacts before they reach prospects | Want safety net that catches what self-review misses

### Solution
An adversarial review agent that checks any business artifact against multiple dimensions: ethical boundary (Cialdini's constraint), credibility (claims verifiable), numerical consistency, tone/voice matching, signal verification, and completeness. Supports Quick, Standard, and Deep modes.

### Domain Examples
#### 1: Happy Path -- Standard review of outreach sequence
Marco submits his 5-touch sequence for Anna Chen. Standard review checks: ethical boundary (PASS -- no fabrication), credibility (1 issue -- "typically see 40%" unsupported), tone (1 issue -- Touch 5 passive-aggressive), signal verification (PASS -- all 4 signals confirmed), completeness (PASS). Score: 8/10, 2 items to address.

#### 2: Edge Case -- Quick review for urgent send
Elena needs to send a pricing update quickly. She runs Quick review (ethical + credibility only, < 1 minute). Both pass. She sends with confidence that the minimum safety checks are met.

#### 3: Error -- Critical ethical violation caught
Davide's proposal includes "As our client Acme Corp reported, productivity increased 60%" but Acme Corp is not a client. The reviewer catches this as a fabricated testimonial (CRITICAL severity), blocks approval, and requires removal before the proposal can be sent.

### UAT Scenarios (BDD)

#### Scenario: Auto-detect artifact type and apply dimensions
Given Marco submits "outreach/anna-chen-sequence.md" for review
When the reviewer analyzes the file
Then the artifact type is detected as "Outreach Sequence"
And applicable dimensions include: ethical, credibility, tone, signal verification, completeness

#### Scenario: Ethical violation blocks approval
Given a proposal includes a fabricated case study
When the reviewer analyzes the proposal
Then the ethical boundary check fails with CRITICAL severity
And approval is blocked regardless of other dimension scores
And the specific fabrication is identified with location and evidence

#### Scenario: Quick review completes in under 1 minute
Given Elena submits a pricing update for quick review
When the reviewer runs in Quick mode
Then only ethical boundary and credibility checks are performed
And results are returned in under 1 minute

#### Scenario: Override requires justification
Given the reviewer flags a pricing claim
When the author overrides the finding
Then written justification is required
And the override is logged in the review record

#### Scenario: Critical findings cannot be skipped
Given the reviewer found a fabricated testimonial (CRITICAL)
When the author attempts to skip the finding
Then the system prevents skipping critical findings
And the artifact remains unapproved

### Acceptance Criteria
- [ ] Artifact type auto-detected from content (canvas, outreach, proposal, pricing)
- [ ] Review dimensions selected based on artifact type
- [ ] 3 review modes: Quick (< 1 min), Standard (< 5 min), Deep (< 10 min)
- [ ] Ethical boundary always checked regardless of mode
- [ ] Each finding has severity, location, and actionable recommendation
- [ ] Critical findings block approval; overrides require justification
- [ ] Fix/Override/Skip resolution flow for each finding

### Technical Notes
- Skills needed: ethical-review, credibility-check, numerical-validation, tone-analysis, signal-verification
- Integration: reviews artifacts produced by all other business agents
- Constraint: reviewer must be invocable from any agent workflow (cross-cutting)
- Constraint: ethical boundary check is non-negotiable (hard constraint from Cialdini framework)

### Traceability
- **Job Story**: JS-04 (Strategic Quality Assurance)
- **Opportunity Score**: 15.5 (Extremely Underserved)
- **Priority**: Must Have

---

## US-BA-008: Cross-Agent Data Flow

### Problem
When Marco hands off a prospect from outreach to Davide for deal closing, Davide currently has to re-ask Marco for details about the company, the signals, the engagement history. Information is lost in the handoff. Similarly, when Elena creates a pricing model, Marco's outreach and Davide's proposals should reference the same pricing -- but without explicit linking, they drift.

### Who
- All co-founders | Handing off work between business phases | Want seamless data flow without re-entry or drift

### Solution
A shared artifact registry that ensures: ICP flows from business-discoverer to outreach-writer, prospect profiles flow from outreach-writer to deal-closer, pricing model is the single source of truth referenced by all agents.

### Domain Examples
#### 1: Happy Path -- Prospect handoff from outreach to deal
Marco's outreach to Anna Chen gets a reply. Davide starts deal preparation. The deal-closer inherits Anna's full prospect profile (company, signals, pain, engagement history) without Davide re-entering any data.

#### 2: Edge Case -- Pricing model updated after outreach started
Elena updates the Good/Better/Best pricing model. Marco has already generated an outreach sequence. The system flags that the existing sequence references the old pricing and suggests review.

#### 3: Error -- ICP mismatch between agents
The business-discoverer defines ICP as "5-20 devs" but outreach-writer qualifies a 50-person team as matching. The integration checkpoint catches the mismatch during prospect qualification.

### UAT Scenarios (BDD)

#### Scenario: Prospect profile transfers from outreach to deal
Given Marco's outreach-writer created a profile for Anna Chen
When Davide starts deal preparation for Anna Chen
Then the deal profile includes all prospect data from outreach phase
And Davide does not need to re-enter company information

#### Scenario: Pricing consistency across agents
Given Elena's business-discoverer set training at EUR 2,000-5,000/day
When deal-closer generates deal options for a new prospect
Then the price ranges reference Elena's pricing model
And any deviation is flagged for review

#### Scenario: ICP qualification uses discoverer criteria
Given business-discoverer defines ICP as 5-20 person dev teams
When outreach-writer qualifies a prospect with 50 engineers
Then the ICP mismatch is flagged
And the qualification explains which criteria failed

### Acceptance Criteria
- [ ] Prospect profile flows from outreach-writer to deal-closer without re-entry
- [ ] Pricing model is single source of truth referenced by all agents
- [ ] ICP criteria from business-discoverer used for prospect qualification
- [ ] Stale data flagged when source artifact is updated after consumers reference it
- [ ] Integration checkpoints validate consistency at each handoff point

### Technical Notes
- This is an integration story -- it defines the contract between agents, not agent internals
- Depends on: US-BA-001 (pricing_model source), US-BA-002 (prospect_profile source), US-BA-004 (deal context)
- Constraint: agents must reference shared artifacts by path, not duplicate content

### Traceability
- **Job Story**: All (JS-01 through JS-04) -- cross-cutting integration
- **Opportunity Score**: N/A (enabler story)
- **Priority**: Must Have
