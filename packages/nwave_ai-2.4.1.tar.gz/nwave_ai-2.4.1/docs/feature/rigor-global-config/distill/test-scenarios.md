# Test Scenarios: Rigor Global Configuration

## Scenario Inventory

### Walking Skeletons (3)

| ID | Feature File | Scenario | User Story |
|----|-------------|----------|------------|
| WS-1 | walking-skeleton.feature | Developer's global rigor profile applies in a project with no rigor configured | US-RGC-01 |
| WS-2 | walking-skeleton.feature | Developer's project-specific rigor takes priority over global preference | US-RGC-01 |
| WS-3 | walking-skeleton.feature | New user gets sensible defaults without any configuration | US-RGC-01 |

### Milestone 1: Cascade Resolution (12 scenarios)

| ID | Scenario | Type | User Story |
|----|----------|------|------------|
| M1-01 | Project rigor present -- global rigor is completely ignored | Happy path | US-RGC-01 |
| M1-02 | No project rigor -- cascade to global rigor | Happy path | US-RGC-01 |
| M1-03 | No project rigor, no global config file -- use standard defaults | Happy path | US-RGC-01 |
| M1-04 | No project rigor, global config has no rigor key -- use standard defaults | Happy path | US-RGC-01 |
| M1-05 | Project rigor overrides all global fields without merging | Happy path | US-RGC-01 |
| M1-06 | Global rigor fields apply completely when project has no rigor | Happy path | US-RGC-01 |
| M1-07 | Corrupted global config file -- silent fallback to defaults | Error path | US-RGC-01 |
| M1-08 | Unreadable global config file -- silent fallback to defaults | Error path | US-RGC-01 |
| M1-09 | Project config has empty rigor block -- treated as project rigor present | Edge case | US-RGC-01 |
| M1-10 | Global config has partial rigor -- missing fields get standard defaults | Edge case | US-RGC-01 |
| M1-11 | Cascade resolution never raises an exception regardless of config state | Property | US-RGC-01 |
| M1-12 | Global config path is injectable for testing | Edge case | US-RGC-01 |

### Milestone 2: Rigor Scope (7 scenarios)

| ID | Scenario | Type | User Story |
|----|----------|------|------------|
| M2-01 | Global scope writes rigor to the global config file | Happy path | US-RGC-02 |
| M2-02 | Project scope writes rigor to the project config file | Happy path | US-RGC-02 |
| M2-03 | Global save preserves existing non-rigor keys in global config | Happy path | US-RGC-02 |
| M2-04 | Project save preserves existing non-rigor keys in project config | Happy path | US-RGC-02 |
| M2-05 | Global config directory created automatically on first global save | Edge case | US-RGC-02 |
| M2-06 | Global save overwrites previous global rigor profile | Happy path | US-RGC-02 |
| M2-07 | Corrupted global config is replaced on save | Error path | US-RGC-02 |

### Milestone 3: Uninstall Lifecycle (7 scenarios)

| ID | Scenario | Type | User Story |
|----|----------|------|------------|
| M3-01 | User keeps global config during uninstall | Happy path | US-RGC-03 |
| M3-02 | User deletes global config during uninstall | Happy path | US-RGC-03 |
| M3-03 | Empty global config directory is cleaned up after file deletion | Edge case | US-RGC-03 |
| M3-04 | Global config directory preserved when it contains other files | Edge case | US-RGC-03 |
| M3-05 | No global config file -- uninstall proceeds without prompt | Error path | US-RGC-03 |
| M3-06 | Force mode preserves global config without prompting | Happy path | US-RGC-03 |
| M3-07 | Dry-run mode reports global config status without modifying files | Happy path | US-RGC-03 |

## Coverage Analysis

### By user story

| Story | Walking Skeletons | Focused Scenarios | Total |
|-------|------------------|-------------------|-------|
| US-RGC-01 | 3 | 12 | 15 |
| US-RGC-02 | 0 | 7 | 7 |
| US-RGC-03 | 0 | 7 | 7 |
| **Total** | **3** | **26** | **29** |

### By scenario type

| Type | Count | Percentage |
|------|-------|------------|
| Happy path | 14 | 48% |
| Error path | 5 | 17% |
| Edge case | 8 | 28% |
| Property | 1 | 3% |
| Walking skeleton | 3 (counted separately) | -- |

### Error/edge path ratio

Error paths (5) + Edge cases (8) = 13 out of 26 focused scenarios = **50%**

This exceeds the 40% minimum threshold for error/edge coverage.

## Acceptance Criteria Traceability

### US-RGC-01 Acceptance Criteria

| AC | Scenario(s) |
|----|-------------|
| Project rigor first; if present, returns project values without reading global | WS-2, M1-01, M1-05 |
| Cascades to global when project has no rigor key | WS-1, M1-02, M1-06 |
| Falls back to defaults when both lack rigor | WS-3, M1-03, M1-04 |
| Corrupted/missing global handled silently | M1-07, M1-08, M1-11 |
| Full-block override: project rigor ignores all global fields | M1-05, M1-09 |

### US-RGC-02 Acceptance Criteria

| AC | Scenario(s) |
|----|-------------|
| Global scope writes to global-config.json using read-modify-write | M2-01, M2-03, M2-06 |
| Project scope writes to des-config.json (existing behavior) | M2-02, M2-04 |
| ~/.nwave/ directory auto-created on first global save | M2-05 |

### US-RGC-03 Acceptance Criteria

| AC | Scenario(s) |
|----|-------------|
| If found, user prompted with Keep or Delete | M3-01, M3-02 |
| Keep preserves file untouched | M3-01 |
| Delete removes file; removes dir if empty | M3-02, M3-03, M3-04 |
| No file found, no prompt shown | M3-05 |
| Force mode skips prompt, preserves | M3-06 |
| Dry-run shows what would happen | M3-07 |
