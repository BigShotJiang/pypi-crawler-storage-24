# Wave Decisions: DISTILL Wave -- Rigor Global Configuration

## Scenario Design Decisions

| Decision | Rationale |
|----------|-----------|
| 3 walking skeletons covering the 3 cascade levels | Each skeleton answers a distinct user question: "does global work?", "does project override?", "do defaults work?" |
| 12 cascade scenarios in milestone 1 | US-RGC-01 is the foundation; thorough coverage including error paths and property test |
| 7 scope scenarios in milestone 2 | Tests verify file contents after write, not interactive flow (rigor.md is markdown, not Python) |
| 7 uninstall scenarios in milestone 3 | Covers keep/delete/force/dry-run/no-file paths |
| Property-shaped scenario tagged @property | Cascade resolution must never throw -- crafter implements as PBT with config generators |
| Empty rigor block treated as "project rigor present" | Architecture says: if project has `rigor` key at all, global is ignored. Empty dict is still a key. |

## Test Infrastructure Decisions

| Decision | Rationale |
|----------|-----------|
| pytest-bdd with .feature files | Consistent with existing acceptance tests (test_hook_enforcement.feature) |
| Steps organized by domain concept (cascade, scope, uninstall) | Following test-organization-conventions: domain-first, not feature-file-first |
| Shared conftest.py with filesystem helpers | Avoids duplicating tmp_path setup across step files |
| All scenarios start with @skip | One-at-a-time TDD activation during DELIVER wave |
| US-RGC-02 tests verify file contents, not interactive flow | /nw:rigor is a markdown command; we test the observable outcome (config file state) |
| US-RGC-03 uses simulated uninstaller behavior | NWaveUninstaller.check_global_config() does not exist yet; tests define expected behavior for crafter to implement |

## Driving Port Mapping

| User Story | Driving Port | Step File |
|------------|-------------|-----------|
| US-RGC-01 | `DESConfig(config_path, *, global_config_path)` | cascade_steps.py |
| US-RGC-02 | Config file read-modify-write (simulated save) | scope_steps.py |
| US-RGC-03 | `NWaveUninstaller.check_global_config()` | uninstall_steps.py |

## Error Path Analysis

| Total focused scenarios | 26 |
|------------------------|-----|
| Error paths | 5 (19%) |
| Edge cases | 8 (31%) |
| Error + edge total | 13 (50%) |
| Target threshold | 40% |
| **Status** | **PASS** |

## Implementation Sequence for DELIVER

```
WS-3 (defaults, no global file)     -- enable first, simplest path
    |
WS-1 (global cascade)               -- adds global config reading
    |
WS-2 (project override)             -- validates short-circuit
    |
M1-01 through M1-12                 -- all cascade scenarios
    |
M2-01 through M2-07                 -- scope persistence scenarios
    |
M3-01 through M3-07                 -- uninstall lifecycle scenarios
```

## Mandate Compliance Evidence

### CM-A: Hexagonal Boundary Enforcement

All cascade_steps.py tests import and invoke through `DESConfig` (the driving port):
```
from des.adapters.driven.config.des_config import DESConfig
config = DESConfig(config_path=..., global_config_path=...)
```

No internal component imports. No `_rigor()` or `_load_json_file()` calls in tests.

### CM-B: Business Language Purity

Feature files use business terms only:
- "rigor profile", "agent model", "reviewer model" (domain terms)
- "project", "global", "standard defaults" (business context)
- Zero occurrences of: JSON, HTTP, database, API, class, method, constructor

### CM-C: Walking Skeleton + Focused Scenario Counts

- Walking skeletons: 3 (user-centric, demo-able)
- Focused scenarios: 26 (boundary coverage with test isolation)
- Total: 29 scenarios across 4 feature files
- Error/edge ratio: 50% (above 40% threshold)

## Handoff to DELIVER Wave

The software-crafter receives:

| Artifact | Location |
|----------|----------|
| Walking skeleton feature | `tests/des/acceptance/rigor_global_config/walking-skeleton.feature` |
| Cascade resolution feature | `tests/des/acceptance/rigor_global_config/milestone-1-cascade-resolution.feature` |
| Scope persistence feature | `tests/des/acceptance/rigor_global_config/milestone-2-rigor-scope.feature` |
| Uninstall lifecycle feature | `tests/des/acceptance/rigor_global_config/milestone-3-uninstall-lifecycle.feature` |
| Step definitions | `tests/des/acceptance/rigor_global_config/steps/` |
| Test scenarios inventory | `docs/feature/rigor_global_config/distill/test-scenarios.md` |
| Walking skeleton analysis | `docs/feature/rigor_global_config/distill/walking-skeleton.md` |

### Key Constraints for Crafter

1. Enable scenarios one at a time by removing @skip tag
2. Implementation order: WS-3 -> WS-1 -> WS-2 -> M1-* -> M2-* -> M3-*
3. `DESConfig` constructor must accept `global_config_path` as keyword-only parameter
4. All existing rigor tests must continue to pass unchanged
5. @property scenario M1-11 should be implemented as property-based test with hypothesis
6. US-RGC-03 step definitions simulate the uninstaller; crafter must wire to real `NWaveUninstaller.check_global_config()` when implementing
