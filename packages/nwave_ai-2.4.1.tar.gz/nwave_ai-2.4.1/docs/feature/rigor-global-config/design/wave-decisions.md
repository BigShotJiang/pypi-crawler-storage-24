# Wave Decisions: DESIGN Wave -- Rigor Global Configuration

**Review status**: Iteration 2 -- 4 reviewer gaps resolved, duplication prevention constraint added.

## Architecture Decisions

| Decision | Rationale |
|----------|-----------|
| `global_config_path` is a keyword-only injectable constructor parameter on DESConfig (after `*`) | Testability + backward compatibility: keyword-only prevents breaking existing positional callers `DESConfig(path, cwd)` |
| Default global path: `Path.home() / ".nwave" / "global-config.json"` | Parallels `~/.claude/` convention; cross-platform via `pathlib.Path.home()` |
| Same JSON schema for global config as project config | No new schema to maintain; `_load_json_file()` loads both identically |
| Full block override (no per-field merge) | See ADR-RGC-001. Profiles are cohesive units; per-field merge creates invisible hybrid states |
| `_rigor()` is the single modification point | All 7 `rigor_*` properties call `_rigor()` unchanged; cascade logic is localized |
| `_load_json_file(path)` is a single static method for all JSON config reading | Zero logic duplication: project and global configs loaded by the same function |
| Global config loaded once at DESConfig init, not lazily | Consistent with project config loading pattern; DESConfig is short-lived (one per hook invocation) |
| Uninstall `--force` auto-preserves global config without prompting | `--force` = skip all prompts; conservative with user data; follows existing `confirm_removal()` skip pattern |
| `/nw:rigor lean` (quick switch) still asks scope | User explicitly confirmed in DISCUSS wave; scope is a 2-option question, minimal friction |
| `/nw:rigor` creates `~/.nwave/` with `parents=True` on first global save | Explicit directory creation immediately before file write; mirrors `save_update_check_state()` pattern |
| ConfigPort (`src/des/ports/driven_ports/config_port.py`) is NOT modified | ConfigPort covers `get_timeout_threshold_default()` only; DESConfig does not implement it; separate concern |

## DISCUSS Wave Answers Resolved

The DISCUSS wave posed 3 questions for DESIGN. Here are the resolutions:

| Question | Resolution |
|----------|------------|
| DESConfig constructor: injectable param or class constant? | **Injectable constructor parameter** -- testability is the primary driver |
| Global config format: same schema or rigor-only? | **Same full JSON schema** as `des-config.json` -- one loading function, no new schema |
| Quick switch default scope? | **No default** -- always ask scope (user confirmed in DISCUSS wave) |

## Quality Gate Checklist

- [x] Requirements traced to components (3 user stories mapped to 3 components)
- [x] Component boundaries with clear responsibilities (DESConfig=read, rigor.md=write, uninstaller=lifecycle)
- [x] Technology choices in ADR with alternatives (ADR-RGC-001: 3 alternatives evaluated)
- [x] Quality attributes addressed (maintainability, testability, reliability, simplicity)
- [x] Dependency-inversion compliance (DESConfig is a driven adapter; global_config_path injectable keyword-only)
- [x] C4 diagrams (L1 System Context + L2 Container)
- [x] Integration patterns specified (read path, write path, uninstall lifecycle)
- [x] OSS preference validated (no new dependencies)
- [x] AC behavioral, not implementation-coupled (all AC describe observable outcomes)
- [x] No code snippets in architecture document (crafter owns implementation)
- [x] Zero logic duplication validated (Duplication Prevention section in architecture-design.md)
- [x] ConfigPort interface verified (exists at driven_ports/config_port.py; separate concern, no changes needed)
- [x] Constructor backward compatibility ensured (keyword-only parameter after `*`)
- [x] `--force` semantics documented (auto-preserve, skip prompt entirely)

## Handoff to DISTILL Wave

The acceptance-designer receives:

| Artifact | Location |
|----------|----------|
| Architecture design | `docs/feature/rigor-global-config/design/architecture-design.md` |
| ADR: cascade strategy | `docs/feature/rigor-global-config/design/adrs/ADR-RGC-001-global-config-cascade-strategy.md` |
| User stories (from DISCUSS) | `docs/feature/rigor-global-config/discuss/user-stories.md` |
| BDD scenarios (from DISCUSS) | `docs/feature/rigor-global-config/discuss/journey-rigor-global-config.feature` |
| Shared artifacts registry | `docs/feature/rigor-global-config/discuss/shared-artifacts-registry.md` |

### Delivery Order (from DISCUSS, confirmed by DESIGN)

```
US-RGC-01 (DESConfig cascade)       -- foundation, no dependencies
    |
    v
US-RGC-02 (/nw:rigor scope)         -- depends on US-RGC-01
    |
    v
US-RGC-03 (Uninstall handling)      -- depends on US-RGC-02
```

### Key Constraints for Crafter

1. `global_config_path` MUST be a keyword-only parameter (after `*` in the constructor signature) with default `Path.home() / ".nwave" / "global-config.json"`. Existing callers `DESConfig(path, cwd)` MUST NOT break.
2. **ZERO LOGIC DUPLICATION**: Refactor `_load_configuration()` into a static `_load_json_file(path)` method. Both project and global config loading MUST call this single method. Do NOT create a separate `_load_global_configuration()`.
3. `_rigor()` MUST NOT read global config when project config has a `rigor` key (short-circuit optimization)
4. All existing `rigor_*` property tests MUST continue to pass without modification
5. Rigor default values (sonnet, haiku, 5-phase, etc.) live ONLY in the `rigor_*` property `.get()` calls. They MUST NOT be duplicated in `_rigor()`, the constructor, or any config loading method.
6. `/nw:rigor` write logic MUST be described as a single parameterized procedure with `target_file` as the variable. Do NOT duplicate write instructions for global vs project scope.
7. Uninstaller `--force` mode MUST skip the global config prompt entirely and auto-preserve. Do NOT prompt under `--force`.
8. `/nw:rigor` MUST create `~/.nwave/` with `parents=True` immediately before writing `global-config.json` when the directory does not exist.
9. Development paradigm: **Functional programming** (pure functions, pipeline composition, immutability where practical)
