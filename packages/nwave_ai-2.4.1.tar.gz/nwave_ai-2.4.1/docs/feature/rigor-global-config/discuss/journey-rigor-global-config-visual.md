# Journey: Rigor Global Configuration

## Persona

Ale Donnarumma -- nWave author, works across 3-5 projects simultaneously, uses a custom rigor profile, expects tooling to respect personal defaults without per-project ceremony.

## Goal

Set a rigor profile ONCE globally and have it apply to every project automatically, with per-project override available when needed.

## Emotional Arc

- **Start**: Annoyed (friction -- must run `/nw:rigor` for every new project)
- **Middle**: In control (setting a global default feels efficient)
- **End**: Confident (new projects "just work" with the right profile)

## Happy Path Flow

```
[Trigger]               [Step 1]                [Step 2]               [Step 3]
User runs               /nw:rigor asks           User selects           Config saved
/nw:rigor               global vs project        profile + confirms     to chosen scope
                              |                       |                      |
Feels: intentional      Feels: empowered         Feels: familiar       Feels: done
```

## Step 1: Scope Selection (NEW)

```
/nw:rigor

Current profile: custom (project-level)
Global profile: none set

Where do you want to save this configuration?

  1. Globally (~/.nwave/global-config.json) -- applies to all projects
  2. This project only (.nwave/des-config.json) -- overrides global for this project

>
```

**Artifacts produced**: scope selection (global | project)
**Error path**: If `~/.nwave/` does not exist, create it (no install required for global)

## Step 2: Profile Selection (EXISTING -- unchanged)

Existing interactive or quick-switch flow from US-RIGOR-01. No changes to selection UX.

## Step 3: Config Persistence (MODIFIED)

- **If global**: Write rigor block to `~/.nwave/global-config.json`
- **If project**: Write rigor block to `.nwave/des-config.json` (existing behavior)

Summary output changes slightly:

```
Rigor profile saved: custom

  Scope:    global (~/.nwave/global-config.json)
  Applies:  all projects without a project-level rigor override

  Resolved settings:
  +-----------------------+---------------------------------------------------+
  | agent_model           | opus                                              |
  | reviewer_model        | sonnet                                            |
  | tdd_phases            | PREPARE, RED_ACCEPTANCE, RED_UNIT, GREEN, COMMIT  |
  | review_enabled        | true                                              |
  | double_review         | true                                              |
  | mutation_enabled      | false                                             |
  | refactor_pass         | true                                              |
  +-----------------------+---------------------------------------------------+
```

## Config Resolution Flow (NEW -- runtime behavior)

```
DESConfig.__init__()
    |
    v
Load .nwave/des-config.json (project)
    |
    +-- has "rigor" key? --> YES --> use project rigor (stop)
    |
    +-- NO --> Load ~/.nwave/global-config.json
                  |
                  +-- has "rigor" key? --> YES --> use global rigor
                  |
                  +-- NO --> use hardcoded standard defaults
```

**Resolution rule**: Full block override. If the project config has a `rigor` key at all, the entire global rigor block is ignored. No per-field merging.

## Uninstall Flow (NEW)

```
nwave-ai uninstall

...existing uninstall steps...

Global configuration found at ~/.nwave/global-config.json

  1. Keep global config (for future installations)
  2. Delete global config

>
```

## Error Paths

| Error | User sees | Recovery |
|-------|-----------|----------|
| `~/.nwave/` does not exist (global save) | Created automatically | None needed |
| `~/.nwave/global-config.json` invalid JSON | Backup as `.bak`, reset | Same as project corruption flow |
| `~/.nwave/global-config.json` missing (runtime) | Fall through to standard defaults | Transparent -- user never sees this |
| Project rigor key absent, global absent | Standard defaults applied | Transparent |

## Integration Checkpoints

1. **DESConfig** must cascade: project rigor -> global rigor -> defaults
2. **Wave commands** read DESConfig -- no changes needed (they already read DESConfig properties)
3. **`/nw:rigor` command** adds scope question at the start
4. **Installer** does NOT create global config (global is opt-in via `/nw:rigor`)
5. **Uninstaller** asks about global config retention
